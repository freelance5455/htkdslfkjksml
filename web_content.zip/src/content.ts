import type { PageId, TabId } from "./context";

export const logos = [
  "Northline",
  "Halcyon",
  "Kiteform",
  "Fieldnote",
  "Lumenfold",
  "Stackwell",
  "Brightharbor",
  "Copperline",
  "Meridian OS",
  "Lowtide",
];

export const cities = [
  { city: "San Francisco", tz: "America/Los_Angeles" },
  { city: "Denver", tz: "America/Denver" },
  { city: "Mexico City", tz: "America/Mexico_City" },
  { city: "New York", tz: "America/New_York" },
  { city: "Lisbon", tz: "Europe/Lisbon" },
  { city: "Nairobi", tz: "Africa/Nairobi" },
  { city: "Berlin", tz: "Europe/Berlin" },
  { city: "Bengaluru", tz: "Asia/Kolkata" },
  { city: "Singapore", tz: "Asia/Singapore" },
  { city: "Tokyo", tz: "Asia/Tokyo" },
  { city: "Sydney", tz: "Australia/Sydney" },
];

export const stats = [
  { value: 11, suffix: "h", decimals: 0, label: "returned to deep work, per engineer, each week" },
  { value: 2.4, suffix: "×", decimals: 1, label: "faster pull-request cycle after 90 days" },
  { value: 40, suffix: "%", decimals: 0, label: "fewer status meetings across distributed teams" },
  { value: 64, suffix: "", decimals: 0, label: "countries on a single engineering thread" },
];

export type Feature = {
  tab: TabId;
  title: string;
  body: string;
  kicker: string;
};

export const features: Feature[] = [
  {
    tab: "memory",
    kicker: "Context",
    title: "Repo-native memory",
    body: "Indexes the monorepo, ADRs, and the comments that actually explain intent. Answers cite files — not a vague recollection of a Slack thread.",
  },
  {
    tab: "composer",
    kicker: "Craft",
    title: "Async pair programming",
    body: "Leave a thread before you sign off. Wake up to a diff that follows your helpers, your queue contract, and the style already in the file.",
  },
  {
    tab: "pulse",
    kicker: "Rhythm",
    title: "Timezone Pulse",
    body: "Working hours are a first-class input. Standups are drafted from commits. Questions wait until a teammate’s morning, with the context already attached.",
  },
  {
    tab: "review",
    kicker: "Review",
    title: "PR intelligence",
    body: "Pre-review flags risk, names the owner who’s online, and routes the request so it doesn’t sit until the other office wakes.",
  },
  {
    tab: "memory",
    kicker: "Continuity",
    title: "Decisions that outlive the thread",
    body: "The why lives next to the code. New hires and contractors query the graph instead of pinging the one person who remembers.",
  },
  {
    tab: "composer",
    kicker: "Trust",
    title: "Private by design",
    body: "Your code is not training data. Isolated indexes, customer-managed keys, SSO, and a VPC path when procurement asks the hard question.",
  },
];

export const benefits = [
  {
    n: "01",
    title: "Deep work, protected",
    body: "Nexus absorbs the questions that used to become ‘quick syncs.’ You stay in the editor. The answer is waiting when you want it — with the files it used.",
  },
  {
    n: "02",
    title: "Onboarding without the scavenger hunt",
    body: "A contractor in week one can ask why invoice retries cap at five and get ADR-014, the incident, and the helper — not a shrug and a calendar link.",
  },
  {
    n: "03",
    title: "Reviews that don’t wait for sunrise",
    body: "Risk is flagged before a human opens the PR. The reviewer who’s actually online gets the request. The other timezone gets a summary, not a surprise.",
  },
  {
    n: "04",
    title: "One thread, every office",
    body: "Conventions, ownership, and ‘we tried that’ notes stop living in someone’s head. The repo becomes the system of record the team already wished it was.",
  },
];

export const beforeAfter = {
  before: [
    { k: "Review cycle", v: "31 hours" },
    { k: "Morning archaeology", v: "90 minutes" },
    { k: "Status meetings", v: "6 / week" },
    { k: "Where the why lives", v: "Three Slack threads" },
  ],
  after: [
    { k: "Review cycle", v: "11 hours" },
    { k: "Morning archaeology", v: "None — start in the diff" },
    { k: "Status meetings", v: "2 / week" },
    { k: "Where the why lives", v: "Cited, next to the code" },
  ],
};

export const testimonials = [
  {
    quote:
      "I used to lose the first ninety minutes reconstructing what Lisbon shipped overnight. Nexus leaves a reviewed diff and the why. I start in the code.",
    name: "Amira Okonkwo",
    role: "Staff Engineer, Halcyon",
    place: "Nairobi",
    result: "90 min returned each morning",
    photo:
      "https://images.pexels.com/photos/29852895/pexels-photo-29852895.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=640&w=640",
  },
  {
    quote:
      "Reviewer routing by timezone cut our cycle from 31 hours to 11. We stopped booking syncs that existed only to transfer context across the ocean.",
    name: "Elena Voss",
    role: "Engineering Manager, Northline",
    place: "Berlin",
    result: "31h → 11h review cycle",
    photo:
      "https://images.pexels.com/photos/32846944/pexels-photo-32846944.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=640&w=640",
  },
  {
    quote:
      "It writes like someone who has actually read our design system — because it has. Fewer style nits. More review of the thing that can break production.",
    name: "Maya Ellison",
    role: "Senior Frontend, Fieldnote",
    place: "Lisbon",
    result: "Style nits down 62%",
    photo:
      "https://images.pexels.com/photos/38197025/pexels-photo-38197025.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=640&w=640",
  },
  {
    quote:
      "Eight of us, four countries. Nexus is the ninth teammate, and the only one who has read every ADR. Onboarding a contractor took three days, not three weeks.",
    name: "Jonah Hale",
    role: "Founding Engineer, Kiteform",
    place: "Denver",
    result: "Onboarding in 3 days",
    photo:
      "https://images.pexels.com/photos/14466702/pexels-photo-14466702.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=640&w=640",
  },
];

export const plans = [
  {
    id: "Starter",
    name: "Starter",
    blurb: "For a side project, or a careful first look.",
    monthly: 0,
    annual: 0,
    cta: "Create free workspace",
    featured: false,
    features: ["1 private repository", "50 AI actions / month", "Composer in your editor", "Community forum"],
  },
  {
    id: "Pro",
    name: "Pro",
    blurb: "For engineers who ship on most days.",
    monthly: 32,
    annual: 26,
    cta: "Start 14-day trial",
    featured: true,
    features: [
      "Unlimited repositories",
      "2,000 AI actions / month",
      "Repo memory with citations",
      "PR pre-review and risk flags",
      "Personal Timezone Pulse",
      "Email support",
    ],
  },
  {
    id: "Team",
    name: "Team",
    blurb: "For distributed orgs that share a codebase.",
    monthly: 58,
    annual: 46,
    cta: "Start 14-day trial",
    featured: false,
    features: [
      "Everything in Pro",
      "Shared team memory",
      "Reviewer routing by timezone",
      "SSO, SCIM, and audit log",
      "Admin analytics",
      "Priority support",
    ],
  },
];

export const comparison = [
  { name: "Private repositories", starter: "1", pro: "Unlimited", team: "Unlimited" },
  { name: "AI actions", starter: "50 / mo", pro: "2,000 / mo", team: "Fair use" },
  { name: "Repo memory", starter: "—", pro: "Personal", team: "Shared" },
  { name: "PR pre-review", starter: "—", pro: "Yes", team: "Yes + routing" },
  { name: "Timezone Pulse", starter: "—", pro: "Personal", team: "Team hours" },
  { name: "SSO & audit log", starter: "—", pro: "—", team: "Yes" },
  { name: "VPC / self-host", starter: "—", pro: "—", team: "Enterprise" },
  { name: "Support", starter: "Community", pro: "Email", team: "Priority" },
];

export const faqs = [
  {
    q: "Does Nexus train on our code?",
    a: "No. Customer repositories are isolated and are not used to train foundation models. Drafts are generated against your index. Enterprise plans can keep that index inside your VPC, with customer-managed keys.",
  },
  {
    q: "Which editors, hosts, and languages?",
    a: "VS Code, Cursor, JetBrains, Neovim via the CLI, and a web studio. GitHub, GitLab, and Bitbucket for review. Nexus follows the patterns already in the repo — TypeScript, Python, Go, Rust, Java, Kotlin, Ruby, and whatever else you actually ship.",
  },
  {
    q: "How does the free trial work?",
    a: "14 days of Team, no card required. Connect a repo, invite teammates, and use reviewer routing and shared memory. When it ends, stay on Starter for free or pick Pro or Team. Your index remains until you delete it.",
  },
  {
    q: "What does timezone-aware actually mean?",
    a: "Nexus knows working hours. It routes a review to whoever is online, holds a question until someone’s morning, and drafts an async standup from commits — not from a meeting that half the team attends half-asleep.",
  },
  {
    q: "Can we self-host?",
    a: "Yes, on Enterprise. Helm chart, private model gateway, and keys you rotate. Most teams start on our cloud during the trial and move the index only if policy requires it.",
  },
  {
    q: "What if a suggestion is wrong?",
    a: "Every draft is a diff you can edit or reject. Nexus cites the files it used. A rejection is stored as a repo preference — it does not become a global model update, and it does not leak to another workspace.",
  },
  {
    q: "How long does onboarding take?",
    a: "Connect the host, choose repositories, and a mid-size monorepo is usually queryable within an hour. New teammates can ask ‘why is billing retried this way?’ on day one, before they’ve met the author.",
  },
  {
    q: "Will this become another notification stream?",
    a: "No. Pulse is quiet by default. Deep-work status is respected. Nexus will not ping someone who marked themselves unavailable, and standups land as a digest — not a drive-by mention.",
  },
];

export const memoryQueries = [
  {
    q: "Why do we cap retries at 5?",
    a: "ADR-014 set the cap after the November retry storm saturated the worker pool. Five attempts cover 99.2% of transient card declines without pushing the queue past the billing SLO.",
    cites: ["ADR-014", "packages/jobs/backoff.ts", "incident-2025-11-02"],
  },
  {
    q: "Who owns billing idempotency?",
    a: "Billing platform. Maya is reviewer of record during EU hours; Kenji covers APAC. CODEOWNERS already encodes it — Pulse just refuses to assign a review to someone who is asleep.",
    cites: ["CODEOWNERS", "notes/2026-01-12.md"],
  },
  {
    q: "What broke in the November incident?",
    a: "A missing idempotency key let a webhook double-enqueue invoice retries. The fix is the draft in Composer: reuse withIdempotency and add a dead-letter alert after five attempts.",
    cites: ["incident-2025-11-02", "workers/billing.ts"],
  },
];

export const reviewNotes = [
  {
    kind: "Risk",
    text: "This lookup isn’t covered by an index. The same shape pushed invoice p95 to 1.8s in March.",
    cite: "db/migrations/044_invoices.sql",
    risk: true,
  },
  {
    kind: "Context",
    text: "Matches the helper Lisbon shipped last week. No new abstraction — call backoff() and stop there.",
    cite: "packages/jobs/backoff.ts",
    risk: false,
  },
  {
    kind: "Route",
    text: "Maya is online in Lisbon and owns EU billing. Kenji is offline until 09:00 JST. Sending to Maya.",
    cite: "CODEOWNERS",
    risk: false,
  },
];

export const pulsePeople = [
  { name: "Maya", city: "Lisbon", hours: "09–18 WET", status: "Reviewing PR #482", on: true },
  { name: "Amira", city: "Nairobi", hours: "09–18 EAT", status: "Deep work · holding pings", on: true },
  { name: "Kenji", city: "Tokyo", hours: "10–19 JST", status: "Offline · back 09:00", on: false },
  { name: "Jonah", city: "Denver", hours: "09–17 MT", status: "Pairing on the indexer", on: true },
];

export const standup = [
  "Maya merged idempotency keys for invoice retry and left the dead-letter question open.",
  "Jonah narrowed the indexer memory leak to the symbol walk in packages/index.",
  "Amira asked about EU tax rounding — the answer is attached from ADR-022, not a new thread.",
];

export const posts = [
  {
    title: "How Halcyon cut review latency across nine timezones",
    date: "March 4, 2026",
    kicker: "Customer story",
    body: "Halcyon’s billing squad spans Nairobi, Lisbon, and Tokyo. Reviews were waiting on the sun. They turned on reviewer routing, kept a human as the approver, and watched median cycle time fall from 31 hours to 11 — without adding a standup.",
  },
  {
    title: "Repo memory is not chat memory",
    date: "February 11, 2026",
    kicker: "Essay",
    body: "A chat transcript forgets the file it was about. Nexus binds every answer to a path, a commit, and an ADR. When the code moves, the citation moves with it. That is the difference between a clever reply and a teammate.",
  },
  {
    title: "The meeting tax, measured",
    date: "January 20, 2026",
    kicker: "Research",
    body: "Across 140 distributed teams in the Q1 cohort, status meetings dropped 40% once Pulse digests replaced the Monday round-robin. The hours did not vanish into another tool. They showed up as uninterrupted blocks on the calendar.",
  },
];

export const changelog = [
  {
    version: "2.4",
    date: "April 2, 2026",
    title: "Timezone Pulse",
    notes: ["Reviewer routing by working hours", "Async standups drafted from commits", "Deep-work status that actually holds pings"],
  },
  {
    version: "2.3",
    date: "February 18, 2026",
    title: "Citations on every draft",
    notes: ["Inline file citations in Composer", "Rejection stored as a repo preference", "Decision graph search"],
  },
  {
    version: "2.2",
    date: "January 9, 2026",
    title: "JetBrains & the CLI",
    notes: ["JetBrains plugin", "neovim-friendly CLI", "GitLab and Bitbucket review"],
  },
];

export const services = [
  { name: "API", state: "Operational" },
  { name: "Indexer", state: "Operational" },
  { name: "Editor bridge", state: "Operational" },
  { name: "Web studio", state: "Operational" },
  { name: "SSO", state: "Operational" },
];

export type Block = { type: "p" | "h"; text: string } | { type: "list"; items: string[] };

export const pages: Record<Exclude<PageId, "careers" | "blog" | "status" | "docs">, { kicker: string; title: string; lede: string; blocks: Block[] }> = {
  about: {
    kicker: "Company",
    title: "Built by people who were tired of morning archaeology.",
    lede: "Nexus Labs started between Lisbon and Nairobi, when two staff engineers kept losing the first hour of the day to whatever the other timezone had decided overnight.",
    blocks: [
      {
        type: "p",
        text: "The repository was always the most honest record of the work. Chat was where the why went to disappear. Nexus is the workspace that puts the why back next to the diff — and respects the fact that your teammate is asleep.",
      },
      {
        type: "h",
        text: "How we work",
      },
      {
        type: "p",
        text: "We are a remote company. No headquarters theater. We dogfood Pulse, we do not schedule meetings across someone’s night, and we write ADRs for our own product the same way we ask customers to.",
      },
      {
        type: "list",
        items: [
          "Leila Mensah, CEO — previously staff engineer on a payments platform",
          "Rafael Costa, CTO — distributed systems, previously indexing code at scale",
          "Studios in no particular city. Teammates in twelve.",
        ],
      },
    ],
  },
  customers: {
    kicker: "Customers",
    title: "Teams who got their mornings back.",
    lede: "A few of the distributed engineering orgs on Nexus. Metrics are from teams active at least 90 days.",
    blocks: [
      {
        type: "h",
        text: "Halcyon · payments · 9 timezones",
      },
      {
        type: "p",
        text: "Review cycle 31h → 11h. Staff engineers in Nairobi start on a pre-reviewed diff instead of a scavenger hunt. Maya’s squad stopped holding a daily sync that existed to narrate git history.",
      },
      {
        type: "h",
        text: "Fieldnote · design systems · EU / US",
      },
      {
        type: "p",
        text: "Style nits on frontend PRs dropped 62% once Composer followed the existing tokens and lint rules. Review became about behavior again.",
      },
      {
        type: "h",
        text: "Kiteform · eight-person startup · four countries",
      },
      {
        type: "p",
        text: "Contractor onboarding fell from three weeks to three days. The decision graph replaced the ‘ask Jonah, he was here at the beginning’ bus factor.",
      },
    ],
  },
  press: {
    kicker: "Press",
    title: "Boilerplate, founders, and a human who replies.",
    lede: "Nexus AI is the AI workspace for remote software teams. It drafts diffs, pre-reviews pull requests, and carries repository context across timezones.",
    blocks: [
      {
        type: "p",
        text: "Founded in 2024 by Leila Mensah and Rafael Costa. Public beta in 2026. Headcount is intentionally small. The product is the announcement.",
      },
      {
        type: "h",
        text: "Facts you can use",
      },
      {
        type: "list",
        items: [
          "Category: developer tools / AI pair programming for distributed teams",
          "Trial: 14 days of Team, no credit card",
          "Security: isolated indexes, no training on customer code, SSO, VPC on Enterprise",
          "Press contact: press@nexus.ai — we reply within one business day",
        ],
      },
    ],
  },
  security: {
    kicker: "Security",
    title: "Your repo is not our training set.",
    lede: "Remote teams already trust us with the most sensitive artifact they have. The product is built around that, not bolted on after a questionnaire.",
    blocks: [
      {
        type: "list",
        items: [
          "Customer code and indexes are isolated per workspace",
          "We do not train foundation models on customer repositories",
          "SSO / SAML, SCIM, and audit log on Team",
          "Encryption in transit and at rest. Customer-managed keys on Enterprise",
          "VPC deployment and private model gateway when policy requires it",
          "SOC 2 Type II report available under NDA",
          "GDPR and DPA on request. Subprocessors listed in the DPA",
          "Vulnerability reports: security@nexus.ai",
        ],
      },
      {
        type: "p",
        text: "A rejection in Composer becomes a repository preference. It does not update a global model and it does not cross a workspace boundary.",
      },
    ],
  },
  changelog: {
    kicker: "Changelog",
    title: "What shipped while someone, somewhere, was asleep.",
    lede: "We write these the way we wish dependency updates were written: short, specific, and honest about behavior changes.",
    blocks: changelog.map((entry) => ({
      type: "p" as const,
      text: `${entry.version} · ${entry.date} — ${entry.title}. ${entry.notes.join(". ")}.`,
    })),
  },
  privacy: {
    kicker: "Privacy",
    title: "Privacy notice",
    lede: "This is a product privacy notice for Nexus AI, written in plain language. It is not a substitute for advice from your counsel.",
    blocks: [
      {
        type: "p",
        text: "We collect account data (name, email, role), workspace configuration, and the repository metadata required to build your index. Source code is processed to provide the service and is not sold.",
      },
      {
        type: "p",
        text: "We use trusted subprocessors for hosting, email delivery, and — if you opt in — model inference. Enterprise customers can pin inference to a private gateway. You can export or delete a workspace from settings, or by writing to privacy@nexus.ai.",
      },
      {
        type: "p",
        text: "Trial signups on this page store the details you submit so we can provision a workspace. We do not send them to a third-party broker. You can ask us to delete them at any time.",
      },
    ],
  },
  terms: {
    kicker: "Terms",
    title: "Terms of use",
    lede: "By starting a trial you agree to use Nexus for lawful engineering work, keep your credentials to yourself, and avoid uploading code you do not have the right to process.",
    blocks: [
      {
        type: "p",
        text: "The trial is provided as-is for evaluation. Paid plans are billed per active developer seat, monthly or annually. You can cancel before renewal. Downgrading does not delete your index unless you ask us to.",
      },
      {
        type: "p",
        text: "You own your code. We own the product. Suggestions are drafts, not warranties — a human still merges. Don’t misuse the service to probe other customers’ workspaces. We may suspend an account that threatens the platform.",
      },
    ],
  },
  dpa: {
    kicker: "DPA",
    title: "Data processing addendum",
    lede: "For teams who need the paperwork before the index exists.",
    blocks: [
      {
        type: "p",
        text: "Nexus Labs is the processor. You are the controller. We process repository content and account data only to provide the workspace you configure, and we flow down equivalent terms to subprocessors.",
      },
      {
        type: "list",
        items: [
          "Standard contractual clauses available for international transfers",
          "Subprocessors: cloud infrastructure, transactional email, optional model provider",
          "Deletion on termination within 30 days, unless law requires otherwise",
          "Request the signed DPA from privacy@nexus.ai or during Enterprise onboarding",
        ],
      },
    ],
  },
};

export const roles = [
  {
    title: "Product engineer",
    place: "Remote · Americas or Europe",
    summary: "TypeScript, editor integrations, and a bias for the last 10% of craft. You will dogfood Composer on your own PRs.",
  },
  {
    title: "Design engineer",
    place: "Remote · any timezone we can overlap 4 hours",
    summary: "You care about type, motion, and the feeling of a tool used eight hours a day. Portfolio over pedigree.",
  },
];

export const docSteps = [
  {
    t: "Create a workspace",
    d: "Use your work email. The trial provisions Team for 14 days — reviewer routing included, card not required.",
  },
  {
    t: "Connect the host",
    d: "GitHub, GitLab, or Bitbucket. Choose repositories. Monorepos are fine; start with the service you touch most.",
  },
  {
    t: "Wait for the index",
    d: "A mid-size repo is usually queryable within an hour. You’ll get a note when memory can answer with citations.",
  },
  {
    t: "Open Composer",
    d: "In VS Code, Cursor, JetBrains, or the web studio. Ask for a change the way you’d ask a teammate who already read the file.",
  },
  {
    t: "Invite the other timezone",
    d: "Pulse stays quiet until a second person joins. Then routing, digests, and shared memory turn on.",
  },
];
