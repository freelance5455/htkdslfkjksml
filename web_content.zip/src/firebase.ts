/**
 * Color Rush — Firebase Authentication & Firestore Service
 * Integrated with Google Sign-In and Cloud Firestore Global Leaderboard
 */

import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  getDocFromServer,
  query,
  orderBy,
  limit,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { LeaderboardEntry, PlayerProfile } from './types';

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

// Skill Error Handler
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid,
      email: auth?.currentUser?.email,
      emailVerified: auth?.currentUser?.emailVerified,
      isAnonymous: auth?.currentUser?.isAnonymous,
      tenantId: auth?.currentUser?.tenantId,
      providerInfo: auth?.currentUser?.providerData?.map((provider) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Validate connection on startup
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline, check connection.');
    }
  }
}
testConnection();

// Initial benchmark players for initial leaderboard display
const SEED_LEADERBOARD: LeaderboardEntry[] = [
  { id: 'lb-1', rank: 1, playerName: 'Kira_Rush', avatar: '🦊', score: 248, maxCombo: 34, date: 'Top' },
  { id: 'lb-2', rank: 2, playerName: 'NeonViper', avatar: '🥷', score: 215, maxCombo: 28, date: 'Top' },
  { id: 'lb-3', rank: 3, playerName: 'TokyoGamer', avatar: '🤖', score: 189, maxCombo: 24, date: 'Top' },
  { id: 'lb-4', rank: 4, playerName: 'LunaNova', avatar: '🐱', score: 164, maxCombo: 21, date: 'Top' },
  { id: 'lb-5', rank: 5, playerName: 'HyperSonic', avatar: '🐻', score: 142, maxCombo: 19, date: 'Top' },
  { id: 'lb-6', rank: 6, playerName: 'CosmicRay', avatar: '👽', score: 128, maxCombo: 17, date: 'Top' },
  { id: 'lb-7', rank: 7, playerName: 'PixelSurfer', avatar: '🦊', score: 115, maxCombo: 15, date: 'Top' },
  { id: 'lb-8', rank: 8, playerName: 'ShadowDash', avatar: '🥷', score: 98, maxCombo: 14, date: 'Top' },
  { id: 'lb-9', rank: 9, playerName: 'BlazeFox', avatar: '🐱', score: 85, maxCombo: 12, date: 'Top' },
  { id: 'lb-10', rank: 10, playerName: 'VoltSpark', avatar: '🤖', score: 74, maxCombo: 11, date: 'Top' },
];

/**
 * Sign in with Google (Popup)
 */
export async function signInWithGoogle(): Promise<{ user: User | null; profile: PlayerProfile; error?: string }> {
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const result = await signInWithPopup(auth, provider);
    const user = result.user;

    const profile: PlayerProfile = {
      uid: user.uid,
      name: user.displayName || 'Google Player',
      avatar: '🦊',
      isGoogleUser: true,
      email: user.email || undefined,
      photoUrl: user.photoURL || undefined,
    };

    // Save user profile to Firestore
    try {
      const userDocRef = doc(db, 'users', user.uid);
      await setDoc(
        userDocRef,
        {
          userId: user.uid,
          displayName: profile.name.slice(0, 50),
          email: profile.email || '',
          photoURL: profile.photoUrl || '',
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
    } catch (err) {
      console.warn('Could not sync user profile to users collection:', err);
    }

    return { user, profile };
  } catch (error: unknown) {
    const err = error as { code?: string; message?: string };
    console.error('Google Sign-In Error:', err);
    return {
      user: null,
      profile: { name: 'Runner', avatar: '🦊', isGoogleUser: false },
      error: err.code === 'auth/popup-closed-by-user' ? 'Sign-in cancelled' : (err.message || 'Google sign-in failed'),
    };
  }
}

/**
 * Sign out
 */
export async function signOutUser(): Promise<void> {
  try {
    await firebaseSignOut(auth);
  } catch (e) {
    console.warn('Firebase sign out error:', e);
  }
}

/**
 * Listen to auth state
 */
export function subscribeAuthState(callback: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, callback);
}

/**
 * Submit High Score to Global Leaderboard in Firestore
 */
export async function submitLeaderboardScore(
  profile: PlayerProfile,
  score: number,
  maxCombo: number
): Promise<{ success: boolean; error?: string }> {
  if (!auth.currentUser) {
    return { success: false, error: 'Sign in with Google to post to the Global Leaderboard' };
  }

  // Sanity validation
  if (score <= 0 || isNaN(score) || score > 1000000) {
    return { success: false, error: 'Invalid score submitted' };
  }

  const path = `leaderboard/${auth.currentUser.uid}`;
  try {
    const userRef = doc(db, 'leaderboard', auth.currentUser.uid);
    await setDoc(
      userRef,
      {
        userId: auth.currentUser.uid,
        playerName: (profile.name || 'Anonymous').slice(0, 50),
        avatar: (profile.avatar || '🦊').slice(0, 10),
        highScore: Math.floor(score),
        maxCombo: Math.floor(maxCombo),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    return { success: true };
  } catch (error) {
    try {
      handleFirestoreError(error, OperationType.WRITE, path);
    } catch {
      // Return error for UI
      return { success: false, error: 'Could not sync score to Firestore' };
    }
    return { success: false };
  }
}

/**
 * Fetch Top 100 Global Leaderboard from Firestore
 */
export async function fetchGlobalLeaderboard(currentPlayerName?: string): Promise<LeaderboardEntry[]> {
  const path = 'leaderboard';
  try {
    const q = query(collection(db, path), orderBy('highScore', 'desc'), limit(100));
    const snap = await getDocs(q);

    if (!snap.empty) {
      const currentUid = auth.currentUser?.uid;
      return snap.docs.map((docSnap, index) => {
        const d = docSnap.data();
        const isCurrent = currentUid ? docSnap.id === currentUid : (currentPlayerName ? d.playerName === currentPlayerName : false);
        return {
          id: docSnap.id,
          rank: index + 1,
          playerName: d.playerName || 'Anonymous',
          avatar: d.avatar || '🦊',
          score: Number(d.highScore) || 0,
          maxCombo: Number(d.maxCombo) || 0,
          date: 'Online',
          isCurrentPlayer: isCurrent,
        };
      });
    }
  } catch (error) {
    console.warn('Firestore leaderboard query error, using benchmark list:', error);
  }

  // If no documents yet in live database, return seeded benchmark players
  return SEED_LEADERBOARD.map((entry) => ({
    ...entry,
    isCurrentPlayer: currentPlayerName ? entry.playerName === currentPlayerName : false,
  }));
}
