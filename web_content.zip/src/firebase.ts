import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  initializeFirestore, 
  persistentLocalCache, 
  persistentMultipleTabManager 
} from 'firebase/firestore';

export const firebaseConfig = {
  apiKey: "AIzaSyBF_PMEUrEQm_iSOJIe9Xa55VeJrclqJwQ",
  authDomain: "asef-web-86bcb.firebaseapp.com",
  projectId: "asef-web-86bcb",
  storageBucket: "asef-web-86bcb.firebasestorage.app",
  messagingSenderId: "722728782925",
  appId: "1:722728782925:web:6c92597d20431325a0e004"
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

let firestoreInstance;
try {
  firestoreInstance = initializeFirestore(app, {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager()
    })
  });
} catch {
  firestoreInstance = getFirestore(app);
}

export const db = firestoreInstance;
export default app;
