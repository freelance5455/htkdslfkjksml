import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  updateDoc,
  onSnapshot,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { TrackerDataSnapshot, migrateChapterData } from './utils/trackerLogic';
import { SEED_TEST_RESULTS } from './data/batchData';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Validate connection to Firestore on boot
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
testConnection();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Defensive sanitization constants matching firebase-blueprint.json & firestore.rules
const MAX_UID_LENGTH = 128;
const UID_PATTERN = /^[a-zA-Z0-9_\-]+$/;
const DATE_PATTERN = /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/;
const MAX_STATUS_KEYS = 1000;
const MAX_SUBJECT_KEYS = 20;
const MAX_TEST_KEYS = 200;

function sanitizePayload(uid: string, snapshot: TrackerDataSnapshot) {
  const safeUid = uid.slice(0, MAX_UID_LENGTH);
  if (!UID_PATTERN.test(safeUid)) {
    throw new Error('Invalid user ID format');
  }

  // Bound statusStore to MAX_STATUS_KEYS
  const statusEntries = Object.entries(snapshot.statusStore || {}).slice(0, MAX_STATUS_KEYS);
  const safeStatusStore = Object.fromEntries(statusEntries);

  // Bound subItemStore to MAX_SUBJECT_KEYS
  const subItemEntries = Object.entries(snapshot.subItemStore || {}).slice(0, MAX_SUBJECT_KEYS);
  const safeSubItemStore = Object.fromEntries(subItemEntries);

  // Bound startedStore to MAX_SUBJECT_KEYS
  const startedEntries = Object.entries(snapshot.startedStore || {}).slice(0, MAX_SUBJECT_KEYS);
  const safeStartedStore = Object.fromEntries(startedEntries);

  // Normalize streak to always be a valid { n: int, d: string } map
  const rawN = snapshot.streak?.n ?? 0;
  const safeN = Math.max(0, Math.min(10000, Math.floor(Number(rawN) || 0)));
  const safeD = String(snapshot.streak?.d || '').slice(0, 16);
  const safeStreak = { n: safeN, d: safeD };

  // Bound testStore to MAX_TEST_KEYS
  const testEntries = Object.entries(snapshot.testStore || {}).slice(0, MAX_TEST_KEYS);
  const safeTestStore = Object.fromEntries(testEntries);

  // Validate targetDate
  const safeTargetDate = DATE_PATTERN.test(snapshot.targetDate || '')
    ? snapshot.targetDate
    : '2027-05-04';

  return {
    ownerId: safeUid,
    statusStore: safeStatusStore,
    subItemStore: safeSubItemStore,
    startedStore: safeStartedStore,
    streak: safeStreak,
    testStore: safeTestStore,
    targetDate: safeTargetDate,
  };
}

export function parseCloudDocData(raw: Record<string, any>): {
  snapshot: TrackerDataSnapshot;
  updatedAt: Date | null;
} {
  const rawStatus = raw.statusStore && typeof raw.statusStore === 'object' ? raw.statusStore : {};
  const rawSubItems =
    raw.subItemStore && typeof raw.subItemStore === 'object' ? raw.subItemStore : {};
  const rawStarted =
    raw.startedStore && typeof raw.startedStore === 'object' ? raw.startedStore : {};

  const migrated = migrateChapterData(rawStatus, rawSubItems, rawStarted);

  const rawStreak = raw.streak && typeof raw.streak === 'object' ? raw.streak : null;
  const streak =
    rawStreak && typeof rawStreak.n === 'number' && rawStreak.n > 0 && rawStreak.d
      ? { n: rawStreak.n, d: String(rawStreak.d) }
      : null;

  const testStore =
    raw.testStore && typeof raw.testStore === 'object'
      ? { ...SEED_TEST_RESULTS, ...raw.testStore }
      : SEED_TEST_RESULTS;

  const targetDate =
    typeof raw.targetDate === 'string' && DATE_PATTERN.test(raw.targetDate)
      ? raw.targetDate
      : '2027-05-04';

  let updatedAt: Date | null = null;
  if (raw.updatedAt instanceof Timestamp) {
    updatedAt = raw.updatedAt.toDate();
  }

  return {
    snapshot: {
      statusStore: migrated.statusStore,
      subItemStore: migrated.subItemStore,
      startedStore: migrated.startedStore,
      streak,
      testStore,
      targetDate,
    },
    updatedAt,
  };
}

export async function fetchCloudTrackerData(uid: string): Promise<{
  exists: boolean;
  snapshot?: TrackerDataSnapshot;
  updatedAt?: Date | null;
}> {
  const path = `userTrackers/${uid}`;
  const docRef = doc(db, 'userTrackers', uid);
  try {
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      return { exists: false };
    }
    const parsed = parseCloudDocData(snap.data());
    return {
      exists: true,
      snapshot: parsed.snapshot,
      updatedAt: parsed.updatedAt,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function saveCloudTrackerData(
  uid: string,
  data: TrackerDataSnapshot,
  docExistsHint?: boolean
): Promise<Date> {
  const path = `userTrackers/${uid}`;
  const docRef = doc(db, 'userTrackers', uid);
  const sanitized = sanitizePayload(uid, data);

  let exists = docExistsHint;
  if (exists === undefined) {
    try {
      const snap = await getDoc(docRef);
      exists = snap.exists();
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
    }
  }

  if (!exists) {
    try {
      await setDoc(docRef, {
        ...sanitized,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return new Date();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  } else {
    try {
      await updateDoc(docRef, {
        statusStore: sanitized.statusStore,
        subItemStore: sanitized.subItemStore,
        startedStore: sanitized.startedStore,
        streak: sanitized.streak,
        testStore: sanitized.testStore,
        targetDate: sanitized.targetDate,
        updatedAt: serverTimestamp(),
      });
      return new Date();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }
}

export function subscribeToCloudTrackerData(
  uid: string,
  onUpdate: (data: { snapshot: TrackerDataSnapshot; updatedAt: Date | null }) => void,
  onError?: (err: unknown) => void
) {
  const path = `userTrackers/${uid}`;
  const docRef = doc(db, 'userTrackers', uid);
  return onSnapshot(
    docRef,
    (snap) => {
      if (snap.exists() && !snap.metadata.hasPendingWrites) {
        onUpdate(parseCloudDocData(snap.data()));
      }
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
}

export async function signInWithGoogle(): Promise<User> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

export async function signOutFromGoogle(): Promise<void> {
  await signOut(auth);
}

export { onAuthStateChanged };
export type { User };
