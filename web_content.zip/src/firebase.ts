import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  Firestore,
  doc,
  getDoc
} from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';
import firebaseConfigJson from '../firebase-applet-config.json';

export const FIREBASE_PROJECT_ID =
  import.meta.env.VITE_FIREBASE_PROJECT_ID || firebaseConfigJson.projectId || 'gen-lang-client-0642412032';

export const TARGET_DATABASE_ID =
  import.meta.env.VITE_FIREBASE_DATABASE_ID ||
  firebaseConfigJson.firestoreDatabaseId ||
  'ai-studio-cubixstudiogloba-56ae10ae-a948-4558-ab74-2c1a5de01e30';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || firebaseConfigJson.apiKey,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || firebaseConfigJson.authDomain,
  projectId: FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || firebaseConfigJson.storageBucket,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || firebaseConfigJson.messagingSenderId,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || firebaseConfigJson.appId,
};

// Singleton initialization pattern
export const app: FirebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Connect strictly to the named Firestore database with persistent IndexedDB local cache for instant 0ms startup reads
function initNamedFirestore(): Firestore {
  try {
    return initializeFirestore(
      app,
      {
        localCache: persistentLocalCache({
          tabManager: persistentMultipleTabManager(),
        }),
      },
      TARGET_DATABASE_ID
    );
  } catch {
    return getFirestore(app, TARGET_DATABASE_ID);
  }
}

export const db: Firestore = initNamedFirestore();

export const auth: Auth = getAuth(app);

export const CUBIX_STORE_COLLECTION = 'cubix_store';
export const CUBIX_MAIN_DOC = 'main_store';
export const CUBIX_VOUCHES_COLLECTION = 'vouches';

export enum OperationType {
  CREATE = 'create',
  READ = 'read',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
}

export function handleFirestoreError(error: unknown, operation: OperationType, path: string): never {
  const err = error as { code?: string; message?: string };
  const errInfo = {
    operation,
    path,
    code: err.code || 'unknown',
    message: err.message || String(error),
  };
  console.error('[Firestore Error Details]', JSON.stringify(errInfo, null, 2));
  throw new Error(`Firestore ${operation} failed on "${path}": ${err.message || 'Permission denied or network failure'}`);
}

/**
 * Tests direct connectivity to the named database
 */
export async function testConnection(): Promise<{ success: boolean; message: string; databaseId: string }> {
  try {
    const testDocRef = doc(db, CUBIX_STORE_COLLECTION, CUBIX_MAIN_DOC);
    const snap = await getDoc(testDocRef);
    return {
      success: true,
      message: snap.exists() ? 'Connected and document exists' : 'Connected (document pending migration)',
      databaseId: TARGET_DATABASE_ID,
    };
  } catch (err: unknown) {
    const error = err as Error;
    return {
      success: false,
      message: error.message || 'Failed to reach named Firestore database',
      databaseId: TARGET_DATABASE_ID,
    };
  }
}
