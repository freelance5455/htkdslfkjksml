import * as THREE from 'three';

export class ThirdPersonCamera {
  constructor(camera, target) {
    this.camera = camera;
    this.target = target;

    this.offset = new THREE.Vector3(0, 1.8, -2.8);
    this.aimOffset = new THREE.Vector3(0.5, 1.5, -1.2);
    this.currentOffset = this.offset.clone();

    this.yaw = 0;
    this.pitch = 0.1;
    this.zoom = 1.0;

    this.shakeIntensity = 0;
  }

  addShake(amount) {
    this.shakeIntensity = Math.min(this.shakeIntensity + amount, 0.5);
  }

  update(delta, isAiming) {
    if (!this.target) return;

    // Smooth camera transition between default and aiming Over-The-Shoulder mode
    const targetOffset = isAiming ? this.aimOffset : this.offset;
    this.currentOffset.lerp(targetOffset, delta * 8.0);

    // Calculate rotation and position based on target player mesh position & yaw angle
    const targetPos = this.target.position.clone();
    const targetRotation = this.target.rotation.y;

    const rotatedOffset = this.currentOffset.clone();
    rotatedOffset.applyAxisAngle(new THREE.Vector3(0, 1, 0), targetRotation);

    const cameraPos = targetPos.clone().add(rotatedOffset);

    // Apply Camera Shake if any
    if (this.shakeIntensity > 0) {
      cameraPos.x += (Math.random() - 0.5) * this.shakeIntensity;
      cameraPos.y += (Math.random() - 0.5) * this.shakeIntensity;
      this.shakeIntensity = Math.max(0, this.shakeIntensity - delta * 2.0);
    }

    this.camera.position.copy(cameraPos);

    // Look at player chest/head height
    const lookAtPos = targetPos.clone().add(new THREE.Vector3(0, isAiming ? 1.4 : 1.2, 0));
    
    // Slight offset forward when looking
    const forwardVec = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), targetRotation);
    lookAtPos.add(forwardVec.multiplyScalar(2.0));

    this.camera.lookAt(lookAtPos);
  }
}
