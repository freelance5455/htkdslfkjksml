export const APP_CONFIG = {
  product: 'NIVEX',
  version: '3.1.0',
  apiVersion: 'v1',
  creator: import.meta.env.VITE_CREATOR_NAME || 'NIVEX Studio — Creator Build',
};
