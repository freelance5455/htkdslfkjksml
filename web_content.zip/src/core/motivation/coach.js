/**
 * coach.js — turns your real statistics into a daily, personal message:
 * what is going well, what to do next. Rule-based and explainable.
 */
import { thisAndLastWeek, delta } from '../stats/statsService.js';
import { overallDailyStreak } from '../../modules/discipline/habits/habitsService.js';
import { isExamMode, upcomingExams } from '../../modules/mind/subjects/subjectsService.js';
import { weeklyMastery } from '../../modules/mastery/masteryService.js';
import { weightProgress } from '../../modules/body/weight/weightService.js';
import { getDailyAffirmation } from './quotes.js';

export async function coachMessage(name = 'Abbas') {
  const { cur, prev } = await thisAndLastWeek();
  const streak = await overallDailyStreak();
  const lines = [];
  const sDelta = delta(cur.studyHours, prev.studyHours);

  if (streak >= 7) lines.push(`${streak} days in a row, ${name}. That is real discipline — protect the chain today.`);
  else if (streak >= 3) lines.push(`${streak}-day streak, ${name}. Keep it alive today.`);

  if (cur.studyHours > 0 && sDelta !== null && sDelta >= 10) lines.push(`You've studied ${cur.studyHours}h this week — up ${sDelta}% on last week. That is compounding.`);
  else if (cur.studyHours > 0 && sDelta !== null && sDelta <= -20) lines.push(`Study time is ${Math.abs(sDelta)}% below last week (${cur.studyHours}h). One focused 50-minute block today closes the gap.`);
  else if (cur.studyHours === 0) lines.push('No study logged this week yet. Start with one 25-minute Pomodoro — that is all it takes to begin.');

  if (cur.workouts >= 3) lines.push(`${cur.workouts} workouts this week — you're on target.`);
  if (cur.prayerPct >= 80) lines.push(`Prayers are ${cur.prayerPct}% on time this week — Masha'Allah. Keep it up.`);
  else if (cur.prayers > 0 && cur.prayerPct < 50) lines.push('Prayer logging is light this week — let the prayer times anchor your day.');
  if (cur.habitPct >= 80) lines.push(`Habits are at ${cur.habitPct}% this week. This is the standard.`);
  else if (cur.habitPct > 0 && cur.habitPct < 40) lines.push(`Habits are at ${cur.habitPct}% this week. Pick the easiest two and win them today.`);

  const examOn = await isExamMode();
  if (examOn) {
    const next = (await upcomingExams())[0];
    lines.unshift(next ? `Exam mode: ${next.name} is in ${next.daysLeft} days. Every focused hour now counts — past questions first, then flashcards.` : 'Exam mode is on. Protect your dawn study block and keep revising with past questions.');
  }
  try {
    const m = (await weeklyMastery()).filter((w) => w.target > 0);
    const behind = m.filter((w) => w.sessions === 0);
    if (m.length && behind.length === 0) lines.push('All your Mastery skills have been practised this week — that is how skills compound.');
    else if (behind.length && new Date().getDay() >= 4) lines.push(`${behind[0].skill.emoji} ${behind[0].skill.name} has no practice yet this week — a short ${behind[0].skill.minutes}-minute session today keeps it alive.`);
    const w = await weightProgress();
    if (w.count >= 2 && w.perWeek !== null && w.perWeek < -0.15) lines.push(`Weight is trending down about ${Math.abs(w.perWeek)} kg a week — ${w.toGo > 0 ? `${w.toGo} kg to your goal` : 'goal reached'}. Keep the walk and water.`);
  } catch { /* optional lines */ }

  const headline = lines[0] || getDailyAffirmation();
  const extra = lines.slice(1, 3);
  return { headline, extra };
}

/** One clear focus for next week, picked from this week's numbers (shown in the Weekly Review). */
export async function weeklyFocus() {
  const { cur, prev } = await thisAndLastWeek();
  const c = [];
  const sDelta = delta(cur.studyHours, prev.studyHours);
  if (cur.studyHours < 6) c.push({ p: 90, title: 'Protect your dawn deep-study block', why: `Only ${cur.studyHours}h of study this week. Two 50-minute blocks a day, right after Fajr and Qur'an, would change the whole week.` });
  else if (sDelta !== null && sDelta <= -20) c.push({ p: 85, title: 'Win back your study hours', why: `Study is ${Math.abs(sDelta)}% below last week. Put the first block back before 7 AM.` });
  if (cur.prayers > 0 && cur.prayerPct < 60) c.push({ p: 80, title: 'Let prayer times anchor your day', why: `Prayers were ${cur.prayerPct}% on time. Tap each one as you pray — it builds the rhythm everything else hangs on.` });
  if (cur.workouts < 3) c.push({ p: 70, title: 'Move 3 times next week', why: `${cur.workouts} workout${cur.workouts === 1 ? '' : 's'} this week. A 20-minute walk counts — keep it small and certain.` });
  if (cur.habitPct > 0 && cur.habitPct < 60) c.push({ p: 75, title: 'Shrink your habits, then win them', why: `Habits were ${cur.habitPct}%. Pick the three that matter most and make them easy to finish.` });
  try {
    const behind = (await weeklyMastery()).filter((w) => w.sessions === 0)[0];
    if (behind) c.push({ p: 65, title: `Give ${behind.skill.name} a slot`, why: `No ${behind.skill.name} practice this week. Attach ${behind.skill.minutes} minutes to something you already do.` });
    const w = await weightProgress();
    if (w.weighInDue || w.count === 0) c.push({ p: 60, title: 'Weigh in and look at the trend', why: 'Log your weight once a week, same time each time, and read the trend — not the day.' });
  } catch { /* optional */ }
  c.sort((a, b) => b.p - a.p);
  return c[0] || { title: 'Keep the rhythm', why: 'Your week looks steady. Repeat what worked, and do not add anything new until it feels easy.' };
}
