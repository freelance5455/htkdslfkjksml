/**
 * dateUtils.js — ALL dates in the app are LOCAL calendar days (YYYY-MM-DD).
 * (v1 used toISOString(), which is UTC and flips the "day" an hour early
 * in Nigeria — that bug is fixed here, in one place.)
 */

const pad = (n) => String(n).padStart(2, '0');

/** Date -> local 'YYYY-MM-DD'. */
export function toISO(d = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** 'YYYY-MM-DD' -> local Date at 00:00. */
export function parseISO(iso) {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export function todayISO() {
  return toISO(new Date());
}

export function addDaysISO(iso, n) {
  const d = parseISO(iso);
  d.setDate(d.getDate() + n);
  return toISO(d);
}

export function isoDaysAgo(n) {
  return addDaysISO(todayISO(), -n);
}

export function daysBetween(aISO, bISO) {
  return Math.round((parseISO(bISO) - parseISO(aISO)) / 86400000);
}

/** Sunday-start week. Accepts a Date or an ISO string. */
export function startOfWeekISO(input = new Date()) {
  const d = typeof input === 'string' ? parseISO(input) : new Date(input);
  d.setDate(d.getDate() - d.getDay());
  return toISO(d);
}

export function formatFriendlyDate(iso) {
  return parseISO(iso).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}

export function dayLabel(iso) {
  if (iso === todayISO()) return 'Today';
  if (iso === isoDaysAgo(1)) return 'Yesterday';
  return formatFriendlyDate(iso);
}

/** Last N date strings (oldest first), inclusive of today. */
export function lastNDates(n) {
  const dates = [];
  for (let i = n - 1; i >= 0; i -= 1) dates.push(isoDaysAgo(i));
  return dates;
}

export function greetingFor(date = new Date()) {
  const h = date.getHours();
  if (h < 12) return 'Good Morning';
  if (h < 17) return 'Good Afternoon';
  return 'Good Evening';
}

/** Decimal hours (e.g. 13.5) -> '1:30 PM'. */
export function formatClock(hours) {
  if (hours == null || Number.isNaN(hours)) return '--:--';
  const total = Math.round((((hours % 24) + 24) % 24) * 60);
  const hh = Math.floor(total / 60) % 24;
  const mm = total % 60;
  return `${hh % 12 || 12}:${pad(mm)} ${hh >= 12 ? 'PM' : 'AM'}`;
}

/**
 * "Never miss twice" streak. One missed day does NOT break the chain;
 * two misses in a row do. `dateSet` is a Set of completed ISO dates.
 * Returns { count, missedYesterday, atRisk }.
 */
export function gentleStreak(dateSet) {
  const today = todayISO();
  const doneToday = dateSet.has(today);
  const missedYesterday = !doneToday && !dateSet.has(addDaysISO(today, -1));
  let cursor = doneToday ? today : addDaysISO(today, -1);
  let misses = doneToday || dateSet.has(cursor) ? 0 : 1;
  if (misses === 1) cursor = addDaysISO(cursor, -1);
  let count = 0;
  for (let guard = 0; guard < 1500; guard += 1) {
    if (dateSet.has(cursor)) { count += 1; misses = 0; } else { misses += 1; if (misses >= 2) break; }
    cursor = addDaysISO(cursor, -1);
  }
  return { count, missedYesterday, atRisk: missedYesterday && count > 0 };
}

/** Plain consecutive-day streak (used where a strict count is wanted). */
export function strictStreak(dateSet) {
  let cursor = dateSet.has(todayISO()) ? todayISO() : addDaysISO(todayISO(), -1);
  let count = 0;
  while (dateSet.has(cursor)) { count += 1; cursor = addDaysISO(cursor, -1); }
  return count;
}
