/**
 * WHITE ROOM OS — Local-First Database Engine (Dexie/IndexedDB Architecture)
 * Version 9: Safe additive migration v1 -> v2 -> v3 -> v4 -> v5 -> v6 -> v7 -> v8 -> v9
 * adding Phase 9 store (`outcome_evaluations`) while preserving all Phase 0–8 stores and records.
 */

import { validateEntity } from './schema.js';

export const DB_NAME = 'WhiteRoomOS_DB';
export const DB_VERSION = 9;

export const STORE_SCHEMAS_V1 = {
  meta: { keyPath: 'id', indexes: [] },
  visions: { keyPath: 'id', indexes: [] },
  goals: { keyPath: 'id', indexes: ['visionId', 'capabilityId', 'status'] },
  capabilities: { keyPath: 'id', indexes: ['order'] },
  skills: { keyPath: 'id', indexes: ['capabilityId', 'status'] },
  subskills: { keyPath: 'id', indexes: ['skillId', 'masteryState'] },
  curriculum: { keyPath: 'id', indexes: ['skillId'] },
  resources: { keyPath: 'id', indexes: ['skillId', 'type'] },
  tasks: { keyPath: 'id', indexes: ['date', 'category', 'status', 'skillId', 'subskillId'] },
  timer_state: { keyPath: 'id', indexes: [] },
  performance_logs: { keyPath: 'id', indexes: ['taskId', 'date', 'skillId'] },
  errors: { keyPath: 'id', indexes: ['skillId', 'subskillId', 'status', 'severity'] },
  reviews: { keyPath: 'id', indexes: ['skillId', 'subskillId', 'nextReviewDate'] },
  schedule_config: { keyPath: 'id', indexes: [] },
  daily_plans: { keyPath: 'id', indexes: ['date'] },
  habits: { keyPath: 'id', indexes: ['capabilityId'] },
};

export const STORE_SCHEMAS_V2_NEW = {
  evidence: { keyPath: 'id', indexes: ['skillId', 'subskillId', 'type'] },
  tests: { keyPath: 'id', indexes: ['skillId', 'subskillId'] },
  test_attempts: { keyPath: 'id', indexes: ['testId', 'skillId', 'subskillId', 'linkedErrorId'] },
  remediations: { keyPath: 'id', indexes: ['errorId', 'skillId', 'subskillId', 'status'] },
};

export const STORE_SCHEMAS_V3_NEW = {
  learning_objectives: {
    keyPath: 'id',
    indexes: ['skillId', 'subskillId', 'goalId', 'capabilityId', 'status'],
  },
  learning_sessions: {
    keyPath: 'id',
    indexes: ['objectiveId', 'resourceId', 'skillId', 'subskillId', 'sessionType'],
  },
  recall_attempts: {
    keyPath: 'id',
    indexes: ['objectiveId', 'skillId', 'subskillId', 'sessionId'],
  },
  flashcards: {
    keyPath: 'id',
    indexes: ['objectiveId', 'skillId', 'subskillId', 'nextReviewDate', 'retentionState'],
  },
  feynman_entries: {
    keyPath: 'id',
    indexes: ['objectiveId', 'skillId', 'subskillId'],
  },
  learning_paths: {
    keyPath: 'id',
    indexes: ['goalId', 'capabilityId', 'skillId'],
  },
  learning_notes: {
    keyPath: 'id',
    indexes: ['targetType', 'targetId', 'skillId'],
  },
};

export const STORE_SCHEMAS_V4_NEW = {
  time_blocks: {
    keyPath: 'id',
    indexes: ['date', 'blockType', 'taskId', 'isFixed'],
  },
  weekly_plans: {
    keyPath: 'id',
    indexes: ['weekStartDate'],
  },
  execution_history: {
    keyPath: 'id',
    indexes: ['taskId', 'date', 'eventType', 'skillId'],
  },
};

export const STORE_SCHEMAS_V5_NEW = {
  diagnostic_assessments: {
    keyPath: 'id',
    indexes: ['skillId', 'subskillId', 'objectiveId'],
  },
  mastery_history: {
    keyPath: 'id',
    indexes: ['entityType', 'entityId', 'skillId', 'transitionType'],
  },
};

export const STORE_SCHEMAS_V6_NEW = {
  periodic_reviews: {
    keyPath: 'id',
    indexes: ['periodType', 'periodKey', 'startDate', 'endDate'],
  },
};

export const STORE_SCHEMAS_V7_NEW = {
  strategic_decisions: {
    keyPath: 'id',
    indexes: ['recommendationKey', 'status', 'targetId', 'skillId', 'createdAt'],
  },
};

export const STORE_SCHEMAS_V8_NEW = {};

export const STORE_SCHEMAS_V9_NEW = {
  outcome_evaluations: {
    keyPath: 'id',
    indexes: [
      'decisionId',
      'recommendationKey',
      'actionType',
      'skillId',
      'outcomeState',
      'evaluatedAt',
    ],
  },
};

export const ALL_STORES_SCHEMAS = {
  ...STORE_SCHEMAS_V1,
  ...STORE_SCHEMAS_V2_NEW,
  ...STORE_SCHEMAS_V3_NEW,
  ...STORE_SCHEMAS_V4_NEW,
  ...STORE_SCHEMAS_V5_NEW,
  ...STORE_SCHEMAS_V6_NEW,
  ...STORE_SCHEMAS_V7_NEW,
  ...STORE_SCHEMAS_V8_NEW,
  ...STORE_SCHEMAS_V9_NEW,
};

export const MIGRATIONS = [
  {
    version: 1,
    description: 'Initial Phase 1 Master Foundation Schema (16 stores)',
    upgrade(db) {
      for (const [storeName, def] of Object.entries(STORE_SCHEMAS_V1)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: def.keyPath });
          for (const idx of def.indexes) {
            store.createIndex(idx, idx, { unique: false });
          }
        }
      }
    },
  },
  {
    version: 2,
    description: 'Phase 2 Skill Engine Schema Upgrade (adds evidence, tests, test_attempts, remediations)',
    upgrade(db) {
      for (const [storeName, def] of Object.entries(STORE_SCHEMAS_V2_NEW)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: def.keyPath });
          for (const idx of def.indexes) {
            store.createIndex(idx, idx, { unique: false });
          }
        }
      }
    },
  },
  {
    version: 3,
    description:
      'Phase 3 Learning Engine Additive Schema Upgrade (adds learning_objectives, learning_sessions, recall_attempts, flashcards, feynman_entries, learning_paths, learning_notes)',
    upgrade(db) {
      for (const [storeName, def] of Object.entries(STORE_SCHEMAS_V3_NEW)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: def.keyPath });
          for (const idx of def.indexes) {
            store.createIndex(idx, idx, { unique: false });
          }
        }
      }
    },
  },
  {
    version: 4,
    description:
      'Phase 4 Adaptive Scheduling & Execution Additive Schema Upgrade (adds time_blocks, weekly_plans, execution_history)',
    upgrade(db) {
      for (const [storeName, def] of Object.entries(STORE_SCHEMAS_V4_NEW)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: def.keyPath });
          for (const idx of def.indexes) {
            store.createIndex(idx, idx, { unique: false });
          }
        }
      }
    },
  },
  {
    version: 5,
    description:
      'Phase 5 Integrated Diagnostics & Mastery History Additive Schema Upgrade (adds diagnostic_assessments, mastery_history without modifying v1–v4 data)',
    upgrade(db) {
      for (const [storeName, def] of Object.entries(STORE_SCHEMAS_V5_NEW)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: def.keyPath });
          for (const idx of def.indexes) {
            store.createIndex(idx, idx, { unique: false });
          }
        }
      }
    },
  },
  {
    version: 6,
    description:
      'Phase 6 Reporting, Analytics, Performance Trends & Review Engine Additive Schema Upgrade (adds periodic_reviews without modifying v1–v5 data)',
    upgrade(db) {
      for (const [storeName, def] of Object.entries(STORE_SCHEMAS_V6_NEW)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: def.keyPath });
          for (const idx of def.indexes) {
            store.createIndex(idx, idx, { unique: false });
          }
        }
      }
    },
  },
  {
    version: 7,
    description:
      'Phase 7 Adaptive Strategy, Priority Optimization & Next-Best-Action Additive Schema Upgrade (adds strategic_decisions without modifying v1–v6 data)',
    upgrade(db) {
      for (const [storeName, def] of Object.entries(STORE_SCHEMAS_V7_NEW)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: def.keyPath });
          for (const idx of def.indexes) {
            store.createIndex(idx, idx, { unique: false });
          }
        }
      }
    },
  },
  {
    version: 8,
    description:
      'Phase 8 Unified Strategy Authority & Architectural Consolidation Compatibility Upgrade',
    upgrade() {
      // Additive consolidation of unified strategy authority (no destructive store changes)
    },
  },
  {
    version: 9,
    description:
      'Phase 9 Outcome Calibration, Recommendation Effectiveness & Evidence-Based Improvement Additive Schema Upgrade (adds outcome_evaluations without modifying v1–v8 data)',
    upgrade(db) {
      for (const [storeName, def] of Object.entries(STORE_SCHEMAS_V9_NEW)) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: def.keyPath });
          for (const idx of def.indexes) {
            store.createIndex(idx, idx, { unique: false });
          }
        }
      }
    },
  },
];

export class WhiteRoomDatabase {
  constructor(options = {}) {
    this.dbName = options.dbName || DB_NAME;
    this.version = options.version || DB_VERSION;
    this.forceMemory = Boolean(options.forceMemory);
    this.idb = null;
    this.memoryStores = null;
    this.migrationLog = [];
    this.initialized = false;
  }

  hasBrowserIndexedDB() {
    return !this.forceMemory && typeof globalThis !== 'undefined' && typeof globalThis.indexedDB !== 'undefined';
  }

  async listStores() {
    return Object.keys(ALL_STORES_SCHEMAS);
  }

  async open() {
    if (this.initialized) return this;

    if (this.hasBrowserIndexedDB()) {
      await new Promise((resolve, reject) => {
        const req = globalThis.indexedDB.open(this.dbName, this.version);
        req.onupgradeneeded = (event) => {
          const db = event.target.result;
          const oldVersion = event.oldVersion || 0;
          for (const m of MIGRATIONS) {
            if (m.version > oldVersion && m.version <= this.version) {
              m.upgrade(db);
              this.migrationLog.push({
                version: m.version,
                description: m.description,
                appliedAt: new Date().toISOString(),
              });
            }
          }
        };
        req.onsuccess = (event) => {
          this.idb = event.target.result;
          this.initialized = true;
          resolve();
        };
        req.onerror = (event) => {
          reject(new Error(`IndexedDB Open Error: ${event.target.error?.message || 'Unknown'}`));
        };
      });
    } else {
      this.memoryStores = {};
      for (const storeName of Object.keys(ALL_STORES_SCHEMAS)) {
        this.memoryStores[storeName] = new Map();
      }
      for (const m of MIGRATIONS) {
        if (m.version <= this.version) {
          this.migrationLog.push({
            version: m.version,
            description: m.description,
            appliedAt: new Date().toISOString(),
          });
        }
      }
      this.initialized = true;
    }

    await this.put('meta', {
      id: 'schema_info',
      dbName: this.dbName,
      schemaVersion: this.version,
      storageBackend: this.hasBrowserIndexedDB() ? 'IndexedDB' : 'InMemoryAdapter',
      migrationsApplied: this.migrationLog.map((m) => m.version),
      updatedAt: new Date().toISOString(),
    });

    return this;
  }

  _assertStore(storeName) {
    if (!ALL_STORES_SCHEMAS[storeName]) {
      throw new Error(`Unknown object store: ${storeName}`);
    }
  }

  async put(storeName, record) {
    await this.open();
    this._assertStore(storeName);
    const validated = validateEntity(storeName, structuredClone(record));

    if (this.idb) {
      return new Promise((resolve, reject) => {
        const tx = this.idb.transaction([storeName], 'readwrite');
        const store = tx.objectStore(storeName);
        const req = store.put(validated);
        req.onsuccess = () => resolve(validated);
        req.onerror = (e) => reject(e.target.error);
      });
    }

    this.memoryStores[storeName].set(validated.id, validated);
    return structuredClone(validated);
  }

  async bulkPut(storeName, records) {
    await this.open();
    this._assertStore(storeName);
    const validatedRecords = records.map((r) => validateEntity(storeName, structuredClone(r)));

    if (this.idb) {
      return new Promise((resolve, reject) => {
        const tx = this.idb.transaction([storeName], 'readwrite');
        const store = tx.objectStore(storeName);
        for (const item of validatedRecords) {
          store.put(item);
        }
        tx.oncomplete = () => resolve(validatedRecords);
        tx.onerror = (e) => reject(e.target.error);
      });
    }

    for (const item of validatedRecords) {
      this.memoryStores[storeName].set(item.id, item);
    }
    return structuredClone(validatedRecords);
  }

  async get(storeName, id) {
    await this.open();
    this._assertStore(storeName);

    if (this.idb) {
      return new Promise((resolve, reject) => {
        const tx = this.idb.transaction([storeName], 'readonly');
        const store = tx.objectStore(storeName);
        const req = store.get(id);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = (e) => reject(e.target.error);
      });
    }

    const item = this.memoryStores[storeName].get(id);
    return item ? structuredClone(item) : null;
  }

  async getAll(storeName) {
    await this.open();
    this._assertStore(storeName);

    if (this.idb) {
      return new Promise((resolve, reject) => {
        const tx = this.idb.transaction([storeName], 'readonly');
        const store = tx.objectStore(storeName);
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = (e) => reject(e.target.error);
      });
    }

    return Array.from(this.memoryStores[storeName].values()).map((v) => structuredClone(v));
  }

  async queryByField(storeName, field, value) {
    const all = await this.getAll(storeName);
    return all.filter((item) => item[field] === value);
  }

  async delete(storeName, id) {
    await this.open();
    this._assertStore(storeName);

    if (this.idb) {
      return new Promise((resolve, reject) => {
        const tx = this.idb.transaction([storeName], 'readwrite');
        const store = tx.objectStore(storeName);
        const req = store.delete(id);
        req.onsuccess = () => resolve(true);
        req.onerror = (e) => reject(e.target.error);
      });
    }

    this.memoryStores[storeName].delete(id);
    return true;
  }

  async clearStore(storeName) {
    await this.open();
    this._assertStore(storeName);

    if (this.idb) {
      return new Promise((resolve, reject) => {
        const tx = this.idb.transaction([storeName], 'readwrite');
        const store = tx.objectStore(storeName);
        const req = store.clear();
        req.onsuccess = () => resolve(true);
        req.onerror = (e) => reject(e.target.error);
      });
    }

    this.memoryStores[storeName].clear();
    return true;
  }

  async clearAll() {
    await this.open();
    for (const storeName of Object.keys(ALL_STORES_SCHEMAS)) {
      await this.clearStore(storeName);
    }
    return true;
  }
}
