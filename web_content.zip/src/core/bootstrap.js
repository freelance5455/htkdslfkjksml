/**
 * WHITE ROOM OS — System Bootstrapper & Unified Reactive Store (Phases 1 + 2 + 3 + 4 + 5 + 6 + 7 Integrated)
 * Seeds initial Master Capability domains, Skill Engine entities, Learning Engine entities,
 * AdaptiveSchedulerEngine, DiagnosticsAndMasteryEngine, AnalyticsAndReviewEngine, and
 * Phase 7 StrategicDecisionEngine without overwriting user data.
 */

import { WhiteRoomDatabase } from './db.js';
import { createStore } from './store.js';
import {
  MASTER_CAPABILITIES_SEED,
  INITIAL_VISIONS_SEED,
  INITIAL_GOALS_SEED,
  INITIAL_SKILLS_SEED,
  INITIAL_SUBSKILLS_SEED,
  INITIAL_CURRICULUM_SEED,
  INITIAL_EVIDENCE_SEED,
  INITIAL_TESTS_SEED,
  INITIAL_LEARNING_OBJECTIVES_SEED,
  INITIAL_RESOURCES_SEED,
  INITIAL_FLASHCARDS_SEED,
  INITIAL_LEARNING_PATHS_SEED,
  DEFAULT_SCHEDULE_CONFIG,
  MASTER_ENGINES_REGISTRY,
} from '../data/seed.js';
import { TimeManagementEngine } from '../engines/timeEngine.js';
import { DailyOsEngine } from '../engines/dailyOsEngine.js';
import { PersistentTimerEngine } from '../engines/timerEngine.js';
import { PerformanceEngine } from '../engines/performanceEngine.js';
import { BackupRestoreEngine } from '../engines/backupEngine.js';
import { SkillEngine } from '../engines/skillEngine.js';
import { SpacedRepetitionScheduler } from '../engines/spacedRepetition.js';
import { LearningEngine } from '../engines/learningEngine.js';
import { AdaptiveSchedulerEngine } from '../engines/schedulerEngine.js';
import { DiagnosticsAndMasteryEngine } from '../engines/diagnosticsEngine.js';
import { AnalyticsAndReviewEngine } from '../engines/analyticsAndReviewEngine.js';
import { StrategicDecisionEngine } from '../engines/strategyAndRecommendationEngine.js';

export async function createWhiteRoomSystem(options = {}) {
  const db = new WhiteRoomDatabase(options);
  await db.open();

  const timeEngine = new TimeManagementEngine(db);
  const dailyOsEngine = new DailyOsEngine(db, timeEngine);
  const timerEngine = new PersistentTimerEngine(db);
  const skillEngine = new SkillEngine(db);
  const srScheduler = new SpacedRepetitionScheduler();
  const learningEngine = new LearningEngine(db, skillEngine, srScheduler);
  const performanceEngine = new PerformanceEngine(db, skillEngine);
  const backupEngine = new BackupRestoreEngine(db);
  const schedulerEngine = new AdaptiveSchedulerEngine(db, {
    timeEngine,
    skillEngine,
    learningEngine,
    performanceEngine,
    timerEngine,
  });
  const diagnosticsEngine = new DiagnosticsAndMasteryEngine(db, {
    skillEngine,
    learningEngine,
    performanceEngine,
    schedulerEngine,
  });
  const analyticsEngine = new AnalyticsAndReviewEngine(db, {
    skillEngine,
    learningEngine,
    schedulerEngine,
    diagnosticsEngine,
    performanceEngine,
    timeEngine,
  });
  const strategyEngine = new StrategicDecisionEngine(db, {
    skillEngine,
    learningEngine,
    schedulerEngine,
    diagnosticsEngine,
    analyticsEngine,
    performanceEngine,
    timeEngine,
  });

  // Allow creating an intentionally empty system for empty-state unit/integration testing
  if (!options.skipSeed) {
    // Seed Phase 1 foundational stores ONLY if empty
    const existingCaps = await db.getAll('capabilities');
    if (existingCaps.length === 0) {
      await db.bulkPut('capabilities', MASTER_CAPABILITIES_SEED);
      await db.bulkPut('visions', INITIAL_VISIONS_SEED);
      await db.bulkPut('goals', INITIAL_GOALS_SEED);
      await db.bulkPut('skills', INITIAL_SKILLS_SEED);
      await db.put('schedule_config', DEFAULT_SCHEDULE_CONFIG);
    }

    // Seed Phase 2 Skill Engine stores ONLY if subskills store is empty
    const existingSubskills = await db.getAll('subskills');
    if (existingSubskills.length === 0) {
      const dpSkill = await db.get('skills', 'skill-dp-graphs');
      if (!dpSkill) {
        const seedDp = INITIAL_SKILLS_SEED.find((s) => s.id === 'skill-dp-graphs');
        if (seedDp) await db.put('skills', seedDp);
      }
      const pySkill = await db.get('skills', 'skill-python-algo');
      if (pySkill && (!pySkill.subskills || !pySkill.subskills.includes('sub-py-arrays'))) {
        await db.put('skills', {
          ...pySkill,
          subskills: ['sub-py-arrays', 'sub-py-trees'],
        });
      }

      await db.bulkPut('subskills', INITIAL_SUBSKILLS_SEED);
      await db.bulkPut('curriculum', INITIAL_CURRICULUM_SEED);
      await db.bulkPut('evidence', INITIAL_EVIDENCE_SEED);
      await db.bulkPut('tests', INITIAL_TESTS_SEED);
    }

    // Seed Phase 3 Learning Engine stores ONLY if learning_objectives store is empty
    const existingObjectives = await db.getAll('learning_objectives');
    if (existingObjectives.length === 0) {
      await db.bulkPut('learning_objectives', INITIAL_LEARNING_OBJECTIVES_SEED);
      await db.bulkPut('resources', INITIAL_RESOURCES_SEED);
      await db.bulkPut('flashcards', INITIAL_FLASHCARDS_SEED);
      await db.bulkPut('learning_paths', INITIAL_LEARNING_PATHS_SEED);
    }
  }

  const todayStr = options.initialDate || '2026-10-14';
  if (!options.skipSeed) {
    await learningEngine.reconcileObjectiveStates();
    for (const sk of await db.getAll('skills')) {
      await skillEngine.calculateSkillProgress(sk.id, todayStr);
    }

    await dailyOsEngine.generateAdaptiveMissions(todayStr, 7, false);
    await schedulerEngine.generateSmartDailyPlan(todayStr, 7, { forceRegenerate: false });
    await schedulerEngine.generateWeeklyPlan(todayStr);
  }

  const store = createStore((set, get) => ({
    currentDate: todayStr,
    currentEnergy: 7,
    activeTab: 'daily-os',
    selectedSkillId: 'skill-python-algo',
    selectedObjectiveId: 'obj-py-two-pointers',
    analyticsFilters: {
      startDate: '',
      endDate: '',
      goalId: '',
      capabilityId: '',
      skillId: '',
    },
    activeReviewPeriodType: 'daily',
    analyticsReport: null,
    periodicReviews: [],
    strategyBundle: null,
    strategicDecisions: [],
    visions: [],
    goals: [],
    capabilities: [],
    skills: [],
    subskills: [],
    curriculum: [],
    resources: [],
    evidence: [],
    tests: [],
    testAttempts: [],
    remediations: [],
    reviews: [],
    learningObjectives: [],
    learningSessions: [],
    recallAttempts: [],
    flashcards: [],
    feynmanEntries: [],
    learningPaths: [],
    learningNotes: [],
    learningRecommendations: [],
    diagnosticAssessments: [],
    masteryHistory: [],
    weaknessScan: null,
    selectedSkillBundle: null,
    selectedObjectiveBundle: null,
    scheduleConfig: DEFAULT_SCHEDULE_CONFIG,
    dailyPlan: null,
    dailyExecutionView: null,
    weeklyPlan: null,
    timeBlocks: [],
    executionHistory: [],
    timerState: null,
    performanceLogs: [],
    errors: [],
    progressSummary: null,
    enginesRegistry: MASTER_ENGINES_REGISTRY,

    async refreshAll() {
      const {
        currentDate,
        currentEnergy,
        selectedSkillId,
        selectedObjectiveId,
        analyticsFilters,
      } = get();

      const activeFilterPayload = {
        referenceDate: currentDate,
        startDate: analyticsFilters?.startDate || null,
        endDate: analyticsFilters?.endDate || null,
        goalId: analyticsFilters?.goalId || null,
        capabilityId: analyticsFilters?.capabilityId || null,
        skillId: analyticsFilters?.skillId || null,
      };

      const [
        visions,
        goals,
        capabilities,
        skills,
        subskills,
        curriculum,
        resources,
        evidence,
        tests,
        testAttempts,
        remediations,
        reviews,
        learningObjectives,
        learningSessions,
        recallAttempts,
        flashcards,
        feynmanEntries,
        learningPaths,
        learningNotes,
        learningRecommendations,
        diagnosticAssessments,
        masteryHistory,
        weaknessScan,
        scheduleConfig,
        dailyPlan,
        dailyExecutionView,
        weeklyPlan,
        timeBlocks,
        executionHistory,
        timerState,
        performanceLogs,
        errors,
        progressSummary,
        analyticsReport,
        periodicReviews,
        strategyBundle,
      ] = await Promise.all([
        db.getAll('visions'),
        db.getAll('goals'),
        db.getAll('capabilities'),
        db.getAll('skills'),
        db.getAll('subskills'),
        db.getAll('curriculum'),
        db.getAll('resources'),
        db.getAll('evidence'),
        db.getAll('tests'),
        db.getAll('test_attempts'),
        db.getAll('remediations'),
        db.getAll('reviews'),
        db.getAll('learning_objectives'),
        db.getAll('learning_sessions'),
        db.getAll('recall_attempts'),
        db.getAll('flashcards'),
        db.getAll('feynman_entries'),
        db.getAll('learning_paths'),
        db.getAll('learning_notes'),
        learningEngine.getLearningRecommendations(currentDate),
        db.getAll('diagnostic_assessments'),
        db.getAll('mastery_history'),
        diagnosticsEngine.scanWeakSkillsAndSubskills(currentDate),
        timeEngine.getScheduleConfig(),
        dailyOsEngine.getDailyPlan(currentDate, currentEnergy),
        schedulerEngine.getDailyExecutionView(currentDate, currentEnergy),
        db.get('weekly_plans', `week_${currentDate}`),
        db.queryByField('time_blocks', 'date', currentDate),
        db.queryByField('execution_history', 'date', currentDate),
        timerEngine.getState(),
        db.getAll('performance_logs'),
        db.getAll('errors'),
        performanceEngine.computeSystemProgress(currentDate),
        analyticsEngine.getComprehensiveAnalyticsReport(activeFilterPayload),
        analyticsEngine.getPeriodicReviews(),
        strategyEngine.getComprehensiveStrategyBundle(currentDate, currentEnergy),
      ]);

      const activeSkillId =
        selectedSkillId && skills.some((s) => s.id === selectedSkillId)
          ? selectedSkillId
          : skills[0]?.id || null;

      const activeObjectiveId =
        selectedObjectiveId && learningObjectives.some((o) => o.id === selectedObjectiveId)
          ? selectedObjectiveId
          : learningObjectives[0]?.id || null;

      const [selectedSkillBundle, selectedObjectiveBundle] = await Promise.all([
        activeSkillId ? skillEngine.getSkillDetailBundle(activeSkillId) : null,
        activeObjectiveId ? learningEngine.getObjectiveDetailBundle(activeObjectiveId) : null,
      ]);

      set({
        selectedSkillId: activeSkillId,
        selectedObjectiveId: activeObjectiveId,
        visions,
        goals,
        capabilities: capabilities.sort((a, b) => a.order - b.order),
        skills,
        subskills,
        curriculum,
        resources,
        evidence,
        tests,
        testAttempts: testAttempts.sort((a, b) =>
          String(b.timestamp || '').localeCompare(String(a.timestamp || ''))
        ),
        remediations,
        reviews,
        learningObjectives,
        learningSessions: learningSessions.sort((a, b) =>
          String(b.createdAt || '').localeCompare(String(a.createdAt || ''))
        ),
        recallAttempts: recallAttempts.sort((a, b) =>
          String(b.timestamp || '').localeCompare(String(a.timestamp || ''))
        ),
        flashcards,
        feynmanEntries: feynmanEntries.sort((a, b) =>
          String(b.timestamp || '').localeCompare(String(a.timestamp || ''))
        ),
        learningPaths,
        learningNotes,
        learningRecommendations,
        diagnosticAssessments: diagnosticAssessments.sort((a, b) =>
          String(b.createdAt || '').localeCompare(String(a.createdAt || ''))
        ),
        masteryHistory: masteryHistory.sort((a, b) =>
          String(b.timestamp || '').localeCompare(String(a.timestamp || ''))
        ),
        weaknessScan,
        selectedSkillBundle,
        selectedObjectiveBundle,
        scheduleConfig,
        dailyPlan,
        dailyExecutionView,
        weeklyPlan: weeklyPlan || (skills.length > 0 ? await schedulerEngine.generateWeeklyPlan(currentDate) : null),
        timeBlocks,
        executionHistory: executionHistory.sort((a, b) =>
          String(b.timestamp || '').localeCompare(String(a.timestamp || ''))
        ),
        timerState,
        performanceLogs: performanceLogs.sort((a, b) =>
          String(b.finishedAtIso || '').localeCompare(String(a.finishedAtIso || ''))
        ),
        errors,
        progressSummary,
        analyticsReport,
        periodicReviews,
        strategyBundle,
        strategicDecisions: strategyBundle?.strategicDecisionsHistory || [],
        outcomeEvaluations: strategyBundle?.outcomeEvaluationsHistory || [],
      });
    },

    async setAnalyticsFilters(newFilters = {}) {
      set({
        analyticsFilters: {
          ...get().analyticsFilters,
          ...newFilters,
        },
      });
      await get().refreshAll();
    },

    async setActiveReviewPeriodType(periodType) {
      set({ activeReviewPeriodType: periodType });
      await get().refreshAll();
    },

    async selectSkill(skillId) {
      set({ selectedSkillId: skillId });
      await get().refreshAll();
    },

    async selectObjective(objectiveId) {
      set({ selectedObjectiveId: objectiveId });
      await get().refreshAll();
    },

    async setDateAndEnergy(dateStr, energyLevel) {
      set({ currentDate: dateStr, currentEnergy: Number(energyLevel) });
      await schedulerEngine.generateSmartDailyPlan(dateStr, Number(energyLevel), {
        forceRegenerate: false,
      });
      await get().refreshAll();
    },

    async regenerateDayMissions() {
      const { currentDate, currentEnergy } = get();
      await schedulerEngine.generateSmartDailyPlan(currentDate, currentEnergy, {
        forceRegenerate: true,
      });
      await get().refreshAll();
    },
  }));

  await store.getState().refreshAll();

  return {
    db,
    store,
    engines: {
      timeEngine,
      dailyOsEngine,
      timerEngine,
      skillEngine,
      srScheduler,
      learningEngine,
      schedulerEngine,
      diagnosticsEngine,
      analyticsEngine,
      strategyEngine,
      performanceEngine,
      backupEngine,
    },
  };
}
