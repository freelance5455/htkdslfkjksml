/**
 * reminderService.js — your reminders (wake-up, priorities, Anki, evening check-in, Weekly Review,
 * weigh-in, prayers, Mastery skills). Native Android ring with the app closed (Capacitor
 * LocalNotifications); in a browser/APK-converter they show while the app is open.
 */
import { getSetting, setSetting } from '../storage/storageService.js';
import { buzz } from '../profile/prefsService.js';
import { todayISO, addDaysISO } from '../utils/dateUtils.js';
import { showToast } from './toast.js';
import { ensureNotificationPermission, scheduleNative, nativeNotificationsAvailable } from '../native/bridge.js';
import { listSkills } from '../../modules/mastery/masteryService.js';
import { getWeightPlan } from '../../modules/body/weight/weightService.js';
import { getPrayerConfig, computePrayerTimes, PRAYER_LABEL } from '../prayer/prayerService.js';

const KEY = 'reminders.v1';
const ALL = [0, 1, 2, 3, 4, 5, 6];
export const DEFAULT_REMINDERS = [
  { id: 'wake', label: '⏰ Wake up', time: '04:25', days: ALL, enabled: true },
  { id: 'priorities', label: '🎯 Priorities + deep study', time: '05:45', days: ALL, enabled: true },
  { id: 'anki', label: '🃏 Anki + revision', time: '16:30', days: ALL, enabled: false },
  { id: 'checkin', label: '📝 Open Life Guide: tick tasks, plan tomorrow', time: '21:00', days: ALL, enabled: true },
  { id: 'winddown', label: '📵 Phone away, wind down', time: '21:50', days: ALL, enabled: true },
  { id: 'review', label: '🔍 Weekly Review + backup', time: '20:00', days: [6], enabled: true },
];
const DEFAULT_CFG = { items: DEFAULT_REMINDERS, prayer: { enabled: false, minutesBefore: 10 }, mastery: true, weigh: true, backup: true };

export async function getReminderConfig() {
  const saved = await getSetting(KEY, null);
  return { ...DEFAULT_CFG, ...(saved || {}), prayer: { ...DEFAULT_CFG.prayer, ...(saved?.prayer || {}) }, items: saved?.items || DEFAULT_REMINDERS };
}
export async function saveReminderConfig(cfg) { await setSetting(KEY, cfg); await rescheduleAll(); }

const hash = (s) => { let h = 7; for (let i = 0; i < s.length; i += 1) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h) % 2000000000 + 1; };
const hm = (t) => { const [h, m] = (t || '00:00').split(':').map(Number); return { hour: h || 0, minute: m || 0 }; };

/** Every reminder expressed as repeating weekly slots {key, title, body, hour, minute, day(0=Sun)} or one-offs {at}. */
export async function buildSchedule() {
  const cfg = await getReminderConfig();
  const out = [];
  cfg.items.filter((r) => r.enabled).forEach((r) => r.days.forEach((d) => out.push({ key: `${r.id}:${d}`, title: r.label, body: 'Life Guide', ...hm(r.time), day: d })));
  if (cfg.mastery) {
    (await listSkills()).filter((s) => s.time).forEach((s) => s.days.forEach((d) => out.push({ key: `skill:${s.id}:${d}`, title: `${s.emoji} ${s.name}`, body: `${s.minutes} minutes — a small step today`, ...hm(s.time), day: d })));
  }
  if (cfg.weigh) { const p = await getWeightPlan(); out.push({ key: 'weigh', title: '⚖️ Weigh-in day', body: 'Log your weight in Body → Weight', hour: 7, minute: 0, day: p.weighDay }); }
  if (cfg.prayer.enabled) {
    try {
      const pc = await getPrayerConfig();
      for (let i = 0; i < 7; i += 1) {
        const date = addDaysISO(todayISO(), i);
        const t = computePrayerTimes(date, pc);
        ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].forEach((k) => {
          const [y, mo, d] = date.split('-').map(Number);
          const at = new Date(y, mo - 1, d, 0, Math.round(t[k] * 60 - cfg.prayer.minutesBefore), 0); // t[k] = local hours
          if (Number.isNaN(at.getTime())) return;
          if (at.getTime() > Date.now()) out.push({ key: `prayer:${k}:${date}`, title: `🕌 ${PRAYER_LABEL[k]} in ${cfg.prayer.minutesBefore} min`, body: 'Prepare for prayer', at });
        });
      }
    } catch (e) { console.warn('[reminders] prayer schedule failed', e); }
  }
  return out;
}

export async function rescheduleAll() {
  if (!nativeNotificationsAvailable()) return false;
  const sched = await buildSchedule();
  const items = sched.map((s) => ({
    id: hash(s.key), title: s.title, body: s.body, channelId: 'lifeguide',
    schedule: s.at ? { at: s.at, allowWhileIdle: true } : { on: { weekday: s.day + 1, hour: s.hour, minute: s.minute }, allowWhileIdle: true },
  }));
  return scheduleNative(items);
}

/* ---- plain-web fallback: fire while the app is open ---- */
const fired = new Set();
export function startInAppReminders() {
  if (nativeNotificationsAvailable()) return;
  setInterval(async () => {
    const now = new Date();
    const stamp = `${todayISO()} ${now.getHours()}:${now.getMinutes()}`;
    const sched = await buildSchedule();
    sched.filter((s) => !s.at && s.day === now.getDay() && s.hour === now.getHours() && s.minute === now.getMinutes() && !fired.has(`${s.key}@${stamp}`))
      .forEach((s) => {
        fired.add(`${s.key}@${stamp}`);
        showToast(`${s.title}`);
        try { if ('Notification' in window && Notification.permission === 'granted') new Notification(s.title, { body: s.body, icon: './icons/icon-192.png' }); } catch { /* ignore */ }
        buzz([150, 80, 150]);
      });
  }, 20000);
}

export async function enableReminders() { return ensureNotificationPermission(); }
