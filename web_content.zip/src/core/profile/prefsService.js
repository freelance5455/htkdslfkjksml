/**
 * prefsService.js — appearance, accessibility and behaviour preferences.
 *
 * One small object stored in the existing `settings` store (so backup/restore carries it) and mirrored
 * in localStorage so the look is applied instantly at start-up, before the database opens (no flash).
 * Applying = setting data-* attributes on <html>; tokens.css does the rest, so switching is cheap
 * even on low-end phones.
 */
import { getSetting, setSetting } from '../storage/storageService.js';

const KEY = 'prefs.v1';
const LS = 'lg.prefs.v1';

export const DEFAULT_PREFS = {
  accent: 'emerald', font: 'default', density: 'comfortable', cardStyle: 'soft', corners: 'rounded',
  motion: 'full', reduceMotion: 'system', touch: 'normal', contrast: 'normal',
  celebrations: true, vibrate: true, greeting: true, startScreen: '/',
};

export const ACCENTS = [
  { value: 'emerald', label: 'Emerald', color: '#17C77E' }, { value: 'ocean', label: 'Ocean', color: '#5B93F5' },
  { value: 'teal', label: 'Teal', color: '#22C3D1' }, { value: 'violet', label: 'Violet', color: '#A18BF5' },
  { value: 'rose', label: 'Rose', color: '#F0709C' }, { value: 'amber', label: 'Amber', color: '#F5B13D' },
];
export const START_SCREENS = [
  { label: 'Home', value: '/' }, { label: 'Body', value: '/body' }, { label: 'Mind', value: '/mind' },
  { label: 'Discipline', value: '/discipline' }, { label: 'Progress', value: '/progress' },
];

let cache = null;

function readLocal() { try { return JSON.parse(localStorage.getItem(LS) || 'null'); } catch { return null; } }
function writeLocal(p) { try { localStorage.setItem(LS, JSON.stringify(p)); } catch { /* storage unavailable */ } }

const OK = {
  accent: ACCENTS.map((a) => a.value), font: ['small', 'default', 'large', 'xlarge'], density: ['compact', 'comfortable', 'spacious'],
  cardStyle: ['soft', 'flat', 'outlined', 'glass', 'elevated'], corners: ['sharp', 'rounded', 'round'], motion: ['full', 'subtle', 'off'],
  reduceMotion: ['system', 'always'], touch: ['normal', 'large'], contrast: ['normal', 'high'],
};
/** Keeps only valid values (a corrupted backup can never break the UI). */
function sanitize(raw) {
  const p = { ...DEFAULT_PREFS };
  Object.entries(raw || {}).forEach(([k, v]) => {
    if (!(k in DEFAULT_PREFS)) return;
    if (OK[k]) { if (OK[k].includes(v)) p[k] = v; } else if (typeof DEFAULT_PREFS[k] === 'boolean') p[k] = !!v;
    else if (k === 'startScreen' && START_SCREENS.some((s) => s.value === v)) p[k] = v;
  });
  return p;
}

export function getPrefsSync() { if (!cache) cache = sanitize(readLocal()); return cache; }
export async function getPrefs() { cache = sanitize(await getSetting(KEY, readLocal())); writeLocal(cache); return cache; }

export async function savePrefs(patch) {
  cache = sanitize({ ...getPrefsSync(), ...patch });
  writeLocal(cache);
  await setSetting(KEY, cache);
  applyPreferences();
  return cache;
}
export async function resetPrefs() { return savePrefs(DEFAULT_PREFS); }

/** The animation level actually in force: reduce-motion always wins. */
export function effectiveMotion(p = getPrefsSync()) {
  const sys = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  if (p.reduceMotion === 'always' || (p.reduceMotion === 'system' && sys)) return 'off';
  return p.motion;
}

export function applyPreferences(p = getPrefsSync()) {
  const d = document.documentElement.dataset;
  d.accent = p.accent; d.font = p.font; d.density = p.density; d.cards = p.cardStyle; d.corners = p.corners;
  d.touch = p.touch; d.contrast = p.contrast; d.motion = effectiveMotion(p);
}

/** Call at boot (before anything renders) and after a backup is restored. */
export async function initPreferences() {
  applyPreferences(getPrefsSync());          // instant, from the local mirror
  await getPrefs(); applyPreferences();      // then the database copy is the truth
  try { window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', () => applyPreferences()); } catch { /* old WebView */ }
}

/** Vibrate only if the user hasn't switched vibration off (Settings → App behaviour). */
export function buzz(pattern) { try { if (getPrefsSync().vibrate) navigator.vibrate?.(pattern); } catch { /* unsupported */ } }
