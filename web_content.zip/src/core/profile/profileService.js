/**
 * profileService.js — who the user is + app preferences, all in the existing
 * `settings` key/value store (no new schema needed for these small values).
 */
import { getSetting, setSetting } from '../storage/storageService.js';

const KEY = 'profile.v1';

export const DEFAULT_PROFILE = {
  name: 'Abbas',
  photo: null, // data URL, compressed, stored only on this device
  bio: 'Medical student at KASU, builder and mentor. I lead SMEA, run MedForge Academy and build apps under AH Creative Solutions.',
  why: 'I built Life Guide to be my personal guide — to build the body, mind, discipline and faith of the person I am becoming, one honest day at a time.',
  motto: "I don't break routine, I only reschedule it.",
  contacts: { whatsapp: '', email: '', facebook: '', instagram: '' },
  theme: 'dark',
  backupEveryDays: 7,
  lastBackup: null,
  installedOn: null,
};

let cache = null;

export async function getProfile() {
  if (cache) return cache;
  const saved = await getSetting(KEY, null);
  cache = { ...DEFAULT_PROFILE, ...(saved || {}) };
  if (!cache.installedOn) {
    const d = new Date();
    cache.installedOn = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    await setSetting(KEY, cache);
  }
  return cache;
}

export async function updateProfile(patch) {
  const current = await getProfile();
  cache = { ...current, ...patch };
  await setSetting(KEY, cache);
  return cache;
}

export function resetProfileCache() { cache = null; }

export async function firstName() {
  const p = await getProfile();
  return (p.name || 'Champ').trim().split(/\s+/)[0] || 'Champ';
}

/** Light/dark — dark is the default look you know; light is optional. */
export async function applyTheme() {
  const { theme } = await getProfile();
  let t = theme;
  if (t === 'auto') t = window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', t);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'light' ? '#F4F7F5' : '#0B0F0E');
}

/** Compress a chosen image file to a small JPEG data URL. */
export function fileToCompressedDataURL(file, max = 480) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * scale);
        c.height = Math.round(img.height * scale);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL('image/jpeg', 0.85));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

export function pickImage(max = 480) {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async () => {
      if (!input.files[0]) return resolve(null);
      try { resolve(await fileToCompressedDataURL(input.files[0], max)); } catch { resolve(null); }
    };
    input.click();
  });
}
