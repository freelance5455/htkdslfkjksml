/**
 * suggestionEngine.js — rule-based "what to focus on today" system.
 * Deterministic and explainable: every rule reads your real statistics and
 * produces a suggestion only if its condition fires. Top 3 by priority show
 * on Home. v2 adds many more rules (prayer, Anki, water, workout split,
 * weekly review, backup, barber, strongest area).
 */
import { computeLifeScore } from '../scoring/scoreEngine.js';
import { habitsAtRiskToday, getTodaySnapshot, habitMissedYesterday } from '../../modules/discipline/habits/habitsService.js';
import { getAll } from '../storage/storageService.js';
import { lastNDates, todayISO, startOfWeekISO } from '../utils/dateUtils.js';
import { todayCardsReviewed } from '../../modules/mind/anki/ankiService.js';
import { cardStats } from '../../modules/mind/flashcards/flashcardService.js';
import { todaysSplitFocus } from '../../modules/body/fitness/fitnessService.js';
import { getPrayerConfig, nextPrayer, getDayLog, prayersDone, PRAYER_LABEL, countdownText, fastInfo } from '../prayer/prayerService.js';
import { backupDue } from '../storage/backupService.js';
import { daysUntilBarber } from '../../modules/presence/grooming/groomingService.js';
import { weightProgress } from '../../modules/body/weight/weightService.js';
import { todaysMastery } from '../../modules/mastery/masteryService.js';
import { isExamMode, upcomingExams } from '../../modules/mind/subjects/subjectsService.js';
import { getProfile } from '../profile/profileService.js';

const SCORE_LABELS = {
  study: 'study consistency', fitness: 'fitness consistency',
  health: 'skin & health routine', confidence: 'confidence practice',
};

const S = (priority, icon, message) => ({ priority, icon, message });

async function studyDropRule() {
  const sessionDates = new Set((await getAll('studySessions')).map((s) => s.date));
  const hit = lastNDates(7).filter((d) => sessionDates.has(d)).length;
  return hit <= 2 ? S(90, '📚', 'Your study consistency dropped this week → prioritize 2 focused Pomodoro sessions today.') : null;
}

async function lowScoreRule(scores) {
  const lowest = Object.entries(SCORE_LABELS).map(([key, label]) => ({ label, value: scores[key] })).sort((a, b) => a.value - b.value)[0];
  return lowest.value < 50 ? S(80, '⚠️', `Your ${lowest.label} is at ${lowest.value}/100 — the lowest of your four scores. Give it deliberate attention today.`) : null;
}

async function streakRiskRule() {
  const atRisk = await habitsAtRiskToday();
  if (!atRisk.length) return null;
  const top = atRisk.sort((a, b) => b.streak - a.streak)[0];
  return S(95, '🔥', `"${top.habit.name}" has a ${top.streak}-day streak on the line — log it today before you lose it.`);
}

async function neverMissTwiceRule() {
  const snap = await getTodaySnapshot();
  for (const h of snap.habits) {
    if (h.habit.frequency === 'daily' && !h.completedToday && h.streak >= 2 && (await habitMissedYesterday(h.habit))) {
      return S(94, '🛡️', `You missed "${h.habit.name}" yesterday. One miss is fine — never miss twice. Do it today.`);
    }
  }
  return null;
}

async function missedHabitsRule() {
  const snap = await getTodaySnapshot();
  const missed = snap.habits.filter((h) => h.habit.frequency === 'daily' && !h.completedToday);
  return missed.length >= 3 ? S(60, '✅', `${missed.length} daily habits are still open today. Start with the easiest one to build momentum.`) : null;
}

async function ankiRule() {
  const today = await todayCardsReviewed();
  const stats = await cardStats();
  if (stats.due > 0) return S(85, '🧠', `${stats.due} flashcard${stats.due > 1 ? 's are' : ' is'} due — clear them in the Anki tab before they pile up.`);
  const hour = new Date().getHours();
  if (today === 0 && hour >= 12) return S(70, '🧠', 'No Anki reviews logged yet today. Even 20 cards keeps the streak and the memory alive.');
  return null;
}

async function waterRule() {
  const hour = new Date().getHours();
  const n = (await getAll('nutritionLogs')).find((x) => x.date === todayISO());
  const ml = n?.waterMl || 0;
  if (hour >= 14 && ml < 1500) return S(65, '💧', `Only ${(ml / 1000).toFixed(1)}L of water so far — drink a big glass now and aim to catch up before evening.`);
  return null;
}

async function workoutRule() {
  const today = todayISO();
  const done = (await getAll('workoutLogs')).some((w) => w.date === today && w.completed);
  const focus = todaysSplitFocus();
  if (!done && !/rest/i.test(focus.focus) && new Date().getHours() >= 15) return S(68, '💪', `Today's plan: ${focus.focus}. Log it before the day ends.`);
  return null;
}

async function prayerRule() {
  const cfg = await getPrayerConfig();
  const np = nextPrayer(cfg);
  const log = await getDayLog();
  const done = prayersDone(log);
  const fi = fastInfo(new Date(), cfg.hijriAdjust);
  const out = [];
  if (np.inHours <= 0.5 && !np.tomorrow) out.push(S(88, '🕌', `${PRAYER_LABEL[np.name]} is in ${countdownText(np.inHours)} — get ready.`));
  if (fi && !log.fasted && new Date().getHours() < 12) out.push(S(66, '🌙', `${fi.label}. Mark it on Home if you're fasting today.`));
  const hour = new Date().getHours() + new Date().getMinutes() / 60;
  const passed = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].filter((p) => np.times[p] < hour - 0.25).length;
  if (passed - done >= 2) out.push(S(75, '🕌', `You've prayed ${done} of the ${passed} prayers whose time has come — log them or catch up.`));
  return out.sort((a, b) => b.priority - a.priority)[0] || null;
}

async function weeklyReviewRule() {
  const reviewed = (await getAll('weeklyReviews')).some((r) => r.weekStartDate === startOfWeekISO());
  const dow = new Date().getDay();
  if (!reviewed && (dow === 0 || dow === 6)) return S(72, '📝', 'Your weekly review is open — Discipline → Weekly Review. Five minutes now sets up next week.');
  return null;
}

async function backupRule() {
  const p = await getProfile();
  return backupDue(p) ? S(55, '💾', 'It has been a while since your last backup. Settings → Export backup keeps your progress safe.') : null;
}

async function barberRule() {
  const d = await daysUntilBarber();
  return d !== null && d < 0 ? S(50, '💈', `Your barber visit is ${Math.abs(d)} days overdue — a fresh fade is an easy confidence win.`) : null;
}

async function strengthRule(scores) {
  const best = Object.entries(SCORE_LABELS).map(([key, label]) => ({ label, value: scores[key] })).sort((a, b) => b.value - a.value)[0];
  return best.value >= 70 ? S(30, '🌟', `Your ${best.label} is strong at ${best.value}/100 — keep that standard and lift the rest to match.`) : null;
}

async function weighInRule() {
  const p = await weightProgress();
  return p.weighInDue ? S(70, '⚖️', 'It is weigh-in day. Step on the scale this morning and log it in Body → Weight — your trend matters more than one number.') : null;
}

async function masteryRule() {
  const today = await todaysMastery();
  const left = today.filter((t) => !t.done);
  if (!left.length) return null;
  const hour = new Date().getHours();
  const names = left.slice(0, 2).map((t) => `${t.skill.emoji} ${t.skill.name}`).join(' and ');
  return S(hour >= 16 ? 78 : 60, '🌱', `${left.length} Mastery item${left.length > 1 ? 's' : ''} planned today: ${names}. ${left[0].skill.minutes} minutes is enough — start with ${left[0].skill.name}.`);
}

async function examRule() {
  const exams = await upcomingExams();
  const mode = await isExamMode();
  const next = exams[0];
  if (mode) return S(92, '📖', next ? `Exam mode: ${next.name} is in ${next.daysLeft} day${next.daysLeft === 1 ? '' : 's'}. Today — one past-questions round, your due flashcards, and a 50-minute focus block on it.` : 'Exam mode is on: do a past-questions round, clear your flashcards and run a 50-minute focus block today.');
  if (next && next.daysLeft <= 14) return S(75, '📖', `${next.name} exam is in ${next.daysLeft} days. Consider turning on Exam mode (Mind → Study).`);
  return null;
}

export async function getTodaySuggestions(limit = 3) {
  const scores = await computeLifeScore();
  const rules = [
    studyDropRule(), lowScoreRule(scores), streakRiskRule(), neverMissTwiceRule(), missedHabitsRule(),
    ankiRule(), waterRule(), workoutRule(), prayerRule(), weeklyReviewRule(), backupRule(), barberRule(), strengthRule(scores), weighInRule(), masteryRule(), examRule(),
  ].map((p) => p.catch(() => null));
  const results = (await Promise.all(rules)).filter(Boolean);
  if (!results.length) results.push(S(10, '🌱', 'Everything is on track. Stay consistent — this is the boring middle part that produces results.'));
  return results.sort((a, b) => b.priority - a.priority).slice(0, limit);
}
