/**
 * bridge.js — the only place that knows about Capacitor. Everything has a plain-web fallback,
 * so the same code runs as a PWA, as a converted APK, or as a real Capacitor app.
 * Plugins are read from the global `Capacitor.Plugins` (no imports, no build step needed).
 */
const cap = () => (typeof window !== 'undefined' ? window.Capacitor : undefined);
export const isNative = () => { try { return !!cap()?.isNativePlatform?.(); } catch { return false; } };
export const plugin = (name) => { try { return cap()?.Plugins?.[name] || null; } catch { return null; } };

/* ---------------- notifications ---------------- */
export const nativeNotificationsAvailable = () => isNative() && !!plugin('LocalNotifications');

export async function ensureNotificationPermission() {
  const LN = plugin('LocalNotifications');
  if (LN) {
    try { const r = await LN.checkPermissions(); if (r.display === 'granted') return true; return (await LN.requestPermissions()).display === 'granted'; } catch { return false; }
  }
  if ('Notification' in window) {
    if (Notification.permission === 'granted') return true;
    if (Notification.permission !== 'denied') return (await Notification.requestPermission()) === 'granted';
  }
  return false;
}

export async function scheduleNative(items) {
  const LN = plugin('LocalNotifications'); if (!LN) return false;
  try {
    const pending = await LN.getPending();
    if (pending?.notifications?.length) await LN.cancel({ notifications: pending.notifications });
    if (items.length) await LN.schedule({ notifications: items });
    return true;
  } catch (e) { console.warn('[native] schedule failed', e); return false; }
}

/* ---------------- sharing / saving a backup file ---------------- */
function download(text, filename) {
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  const a = Object.assign(document.createElement('a'), { href: url, download: filename });
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000);
  return 'downloaded';
}

/** Opens the phone's share sheet (WhatsApp, Drive, email…). Returns what happened. */
export async function shareBackup(text, filename) {
  const FS = plugin('Filesystem'); const SH = plugin('Share');
  if (FS && SH) {
    try {
      const w = await FS.writeFile({ path: filename, data: text, directory: 'CACHE', encoding: 'utf8' });
      await SH.share({ title: 'Life Guide backup', text: 'My Life Guide backup file', url: w.uri, dialogTitle: 'Save or send your backup' });
      return 'shared';
    } catch (e) { if (String(e).toLowerCase().includes('cancel')) return 'cancelled'; }
  }
  try {
    const file = new File([text], filename, { type: 'application/json' });
    if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: 'Life Guide backup' }); return 'shared'; }
  } catch (e) { if (e?.name === 'AbortError') return 'cancelled'; }
  return download(text, filename);
}

/** Saves into Documents/LifeGuide on the phone (native) — otherwise a normal download. */
export async function saveBackupFile(text, filename) {
  const FS = plugin('Filesystem');
  if (FS) {
    try { await FS.writeFile({ path: `LifeGuide/${filename}`, data: text, directory: 'DOCUMENTS', encoding: 'utf8', recursive: true }); return 'saved:Documents/LifeGuide'; } catch (e) { console.warn(e); }
  }
  return download(text, filename);
}

/* ---------------- biometrics (optional plugin) ---------------- */
export const biometricAvailable = () => isNative() && !!plugin('BiometricAuth');
export async function biometricUnlock(reason = 'Unlock Life Guide') {
  const B = plugin('BiometricAuth'); if (!B) return false;
  try { const r = await B.checkBiometry?.(); if (r && r.isAvailable === false) return false; await B.authenticate({ reason, cancelTitle: 'Use PIN', allowDeviceCredential: false }); return true; } catch { return false; }
}
