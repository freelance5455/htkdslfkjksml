export type Screen = 'home' | 'settings' | 'editor' | 'security' | 'lab';
export type TrackKind = 'video' | 'image' | 'audio' | 'text' | 'shape' | 'sticker';
export type EffectCategory = 'essential'|'motion'|'color'|'glitch'|'cinematic'|'stylize'|'particles'|'distortion'|'ai';
export type Easing = 'linear'|'ease-in'|'ease-out'|'ease-in-out'|'bezier';
export type BlendMode = 'normal'|'screen'|'multiply'|'overlay'|'add'|'soft-light';
export interface ProjectSettings {name:string;fps:number;width:number;height:number;durationMs:number;createdAt:number;updatedAt:number;}
export interface Transform {x:number;y:number;scaleX:number;scaleY:number;rotation:number;opacity:number;anchorX:number;anchorY:number;}
export interface Keyframe {id:string;timeMs:number;property:string;value:number[];easing:Easing;}
export interface EffectInstance {id:string;effectId:string;intensity:number;enabled:boolean;params:Record<string,number|string|boolean>;}
export interface TimelineItem {
 id:string;name:string;kind:TrackKind;startMs:number;durationMs:number;assetId?:string;mime?:string;color?:string;text?:string;
 blendMode:BlendMode;speed:number;transform:Transform;effects:EffectInstance[];keyframes:Keyframe[];
}
export interface TimelineTrack {id:string;name:string;kind:TrackKind;locked:boolean;muted:boolean;visible:boolean;height:number;items:TimelineItem[];}
export interface ProjectState {settings:ProjectSettings;tracks:TimelineTrack[];selectedItemId:string|null;playheadMs:number;zoom:number;snap:boolean;}
export interface DeviceCaps {memoryGB:number|null;hardwareConcurrency:number;maxTextureSize:number;supportsWebGL2:boolean;supportsWebGPU:boolean;supportsWebCodecs:boolean;tier:'low'|'balanced'|'high';}
