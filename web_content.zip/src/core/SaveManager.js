import { audioManager } from '../audio/AudioManager.js';

export class SaveManager {
  static SAVE_KEY = 're2_ai_save_data';

  static saveGame(player, objectiveManager, inventorySystem) {
    const saveData = {
      timestamp: new Date().toISOString(),
      playerPos: { x: player.mesh.position.x, y: player.mesh.position.y, z: player.mesh.position.z },
      playerRotY: player.mesh.rotation.y,
      health: player.health,
      status: player.status,
      ammo: player.ammo,
      inventoryItems: inventorySystem.items,
      itemBox: inventorySystem.itemBox,
      objectiveIndex: objectiveManager.currentObjectiveIndex
    };

    try {
      localStorage.setItem(this.SAVE_KEY, JSON.stringify(saveData));
      audioManager.playItemPickup();
      return true;
    } catch (e) {
      console.error('Save failed', e);
      return false;
    }
  }

  static loadGame(player, objectiveManager, inventorySystem) {
    try {
      const raw = localStorage.getItem(this.SAVE_KEY);
      if (!raw) return false;

      const saveData = JSON.parse(raw);
      player.mesh.position.set(saveData.playerPos.x, saveData.playerPos.y, saveData.playerPos.z);
      player.mesh.rotation.y = saveData.playerRotY;
      player.health = saveData.health;
      player.status = saveData.status;
      player.ammo = saveData.ammo;

      inventorySystem.items = saveData.inventoryItems;
      inventorySystem.itemBox = saveData.itemBox;
      objectiveManager.currentObjectiveIndex = saveData.objectiveIndex;

      audioManager.playItemPickup();
      return true;
    } catch (e) {
      console.error('Load failed', e);
      return false;
    }
  }

  static hasSave() {
    return !!localStorage.getItem(this.SAVE_KEY);
  }
}
