/**
 * prayerService.js — offline prayer times (astronomical calculation, no network),
 * Hijri date, Sunnah-fast detection and daily prayer logging.
 * Defaults to Kaduna, Nigeria (UTC+1); everything is editable in Settings.
 */
import { getSetting, setSetting, getByIndex, put, newId, todayISO } from '../storage/storageService.js';
import { addDaysISO } from '../utils/dateUtils.js';
import { emit } from '../utils/eventBus.js';

export const METHODS = {
  MWL: { name: 'Muslim World League', fajr: 18, isha: 17 },
  EGY: { name: 'Egyptian General Authority', fajr: 19.5, isha: 17.5 },
  KAR: { name: 'Univ. of Islamic Sciences, Karachi', fajr: 18, isha: 18 },
  UMM: { name: 'Umm al-Qura (Makkah)', fajr: 18.5, ishaMin: 90 },
  ISNA: { name: 'ISNA', fajr: 15, isha: 15 },
};
export const PRAYERS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
export const PRAYER_LABEL = { fajr: 'Fajr', sunrise: 'Sunrise', dhuhr: 'Dhuhr', asr: 'Asr', maghrib: 'Maghrib', isha: 'Isha' };

export const DEFAULT_PRAYER_CONFIG = {
  place: 'Kaduna', lat: 10.52, lng: 7.44, tz: 1, method: 'MWL', asr: 1,
  offsets: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
  hijriAdjust: 0,
};

const CFG_KEY = 'prayer.config';
export async function getPrayerConfig() {
  const saved = await getSetting(CFG_KEY, null);
  return { ...DEFAULT_PRAYER_CONFIG, ...(saved || {}), offsets: { ...DEFAULT_PRAYER_CONFIG.offsets, ...((saved || {}).offsets || {}) } };
}
export async function savePrayerConfig(cfg) { await setSetting(CFG_KEY, cfg); }

// ---------- astronomy ----------
const rad = (d) => (d * Math.PI) / 180;
const deg = (r) => (r * 180) / Math.PI;
const fixRange = (a, b) => { const r = a - b * Math.floor(a / b); return r < 0 ? r + b : r; };

function julian(y, m, d) {
  if (m <= 2) { y -= 1; m += 12; }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
}

function sunPosition(jd) {
  const D = jd - 2451545.0;
  const g = fixRange(357.529 + 0.98560028 * D, 360);
  const q = fixRange(280.459 + 0.98564736 * D, 360);
  const L = fixRange(q + 1.915 * Math.sin(rad(g)) + 0.02 * Math.sin(rad(2 * g)), 360);
  const e = 23.439 - 0.00000036 * D;
  const RA = fixRange(deg(Math.atan2(Math.cos(rad(e)) * Math.sin(rad(L)), Math.cos(rad(L)))), 360) / 15;
  return { decl: deg(Math.asin(Math.sin(rad(e)) * Math.sin(rad(L)))), eqt: q / 15 - fixRange(RA, 24) };
}

/** Returns local times in decimal hours for the given ISO date. */
export function computePrayerTimes(dateISO, cfg) {
  const [y, m, d] = dateISO.split('-').map(Number);
  const jd = julian(y, m, d) - cfg.lng / (15 * 24);
  const sp = sunPosition(jd + 0.5);
  const mid = fixRange(12 - sp.eqt, 24);
  const T = (angle) => {
    const x = (-Math.sin(rad(angle)) - Math.sin(rad(sp.decl)) * Math.sin(rad(cfg.lat))) /
      (Math.cos(rad(sp.decl)) * Math.cos(rad(cfg.lat)));
    return deg(Math.acos(Math.max(-1, Math.min(1, x)))) / 15;
  };
  const M = METHODS[cfg.method] || METHODS.MWL;
  const asrAngle = -deg(Math.atan(1 / ((cfg.asr || 1) + Math.tan(rad(Math.abs(cfg.lat - sp.decl))))));
  const base = {
    fajr: mid - T(M.fajr),
    sunrise: mid - T(0.833),
    dhuhr: mid + 0.0167,
    asr: mid + T(asrAngle),
    maghrib: mid + T(0.833),
  };
  base.isha = M.ishaMin ? base.maghrib + M.ishaMin / 60 : mid + T(M.isha);
  const shift = cfg.tz - cfg.lng / 15;
  const out = {};
  Object.keys(base).forEach((k) => { out[k] = base[k] + shift + ((cfg.offsets || {})[k] || 0) / 60; });
  return out;
}

/** Next prayer from `now`: { name, at (decimal hours, may exceed 24), inHours, times, tomorrow } */
export function nextPrayer(cfg, now = new Date()) {
  const today = todayISO();
  const hr = now.getHours() + now.getMinutes() / 60 + now.getSeconds() / 3600;
  const times = computePrayerTimes(today, cfg);
  for (const p of PRAYERS) {
    if (times[p] > hr) return { name: p, at: times[p], inHours: times[p] - hr, times, tomorrow: false };
  }
  const t2 = computePrayerTimes(addDaysISO(today, 1), cfg);
  return { name: 'fajr', at: t2.fajr + 24, inHours: t2.fajr + 24 - hr, times, tomorrow: true };
}

export function countdownText(inHours) {
  const mins = Math.max(0, Math.round(inHours * 60));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

// ---------- Hijri + fasting ----------
const HIJRI_MONTHS = ['Muharram', 'Safar', "Rabi' al-Awwal", "Rabi' al-Thani", 'Jumada al-Awwal', 'Jumada al-Thani', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhul-Qa'dah", 'Dhul-Hijjah'];

export function hijriDate(date, adjust = 0) {
  try {
    const d = new Date(date.getTime() + adjust * 86400000);
    const parts = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', { day: 'numeric', month: 'numeric', year: 'numeric' }).formatToParts(d);
    const get = (t) => Number(parts.find((p) => p.type === t).value);
    const day = get('day'); const month = get('month'); const year = get('year');
    if (!day || !month || !year) return null;
    return { day, month, year, text: `${day} ${HIJRI_MONTHS[month - 1]} ${year} AH` };
  } catch { return null; }
}

/** Suggested fast for a date: Ramadan, Monday/Thursday, White Days (13-15), Arafah, Ashura. */
export function fastInfo(date, adjust = 0) {
  const hj = hijriDate(date, adjust);
  const dow = date.getDay();
  if (hj && hj.month === 9) return { type: 'ramadan', label: 'Ramadan — obligatory fast' };
  const tags = [];
  if (hj && hj.month === 12 && hj.day === 9) tags.push('Day of Arafah');
  if (hj && hj.month === 1 && (hj.day === 10 || hj.day === 9)) tags.push(hj.day === 10 ? 'Ashura' : "Tasu'a");
  if (hj && [13, 14, 15].includes(hj.day) && hj.month !== 9) tags.push(`White Day (${hj.day})`);
  if (dow === 1) tags.push('Monday');
  if (dow === 4) tags.push('Thursday');
  return tags.length ? { type: 'sunnah', label: `Sunnah fast: ${tags.join(' · ')}` } : null;
}

// ---------- logging ----------
export async function getDayLog(dateISO = todayISO()) {
  const found = (await getByIndex('dayLogs', 'date', dateISO))[0];
  return found || { id: null, date: dateISO, prayers: {}, fasted: false };
}

async function saveDayLog(log) {
  return put('dayLogs', { ...log, id: log.id || newId() });
}

export async function togglePrayer(prayer, dateISO = todayISO()) {
  const log = await getDayLog(dateISO);
  const done = !log.prayers[prayer];
  const saved = await saveDayLog({ ...log, prayers: { ...log.prayers, [prayer]: done } });
  if (done) emit('prayer:logged', { prayer });
  return saved;
}

export async function setFasted(fasted, dateISO = todayISO()) {
  const log = await getDayLog(dateISO);
  return saveDayLog({ ...log, fasted });
}

export async function setWokeForFajr(woke, dateISO = todayISO()) {
  const log = await getDayLog(dateISO);
  return saveDayLog({ ...log, wokeForFajr: woke });
}

export function prayersDone(log) {
  return PRAYERS.filter((p) => log.prayers?.[p]).length;
}
