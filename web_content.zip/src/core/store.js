/**
 * WHITE ROOM OS — Reactive State Store (Zustand-Compatible API)
 * Provides deterministic state management, subscriptions, and actions.
 */

export function createStore(initializer) {
  let state;
  const listeners = new Set();

  const setState = (partial, replace = false) => {
    const nextState = typeof partial === 'function' ? partial(state) : partial;
    if (! Object.is(nextState, state)) {
      const previousState = state;
      state = replace ? nextState : Object.assign({}, state, nextState);
      for (const listener of listeners) {
        listener(state, previousState);
      }
    }
  };

  const getState = () => state;

  const subscribe = (listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };

  state = initializer(setState, getState);

  return {
    getState,
    setState,
    subscribe,
  };
}
