/**
 * WHITE ROOM OS — Schema & Data Integrity Engine (Phases 1–5 Integrated Diagnostics, Mastery & Retention)
 * Enforces strict runtime validation and normalizes legacy v1–v4 records for backward compatibility.
 */

export class ValidationError extends Error {
  constructor(entityName, issues) {
    super(`[ValidationError:${entityName}] ${issues.join('; ')}`);
    this.name = 'ValidationError';
    this.entityName = entityName;
    this.issues = issues;
  }
}

const isString = (v) => typeof v === 'string' && v.trim().length > 0;
const isOptionalString = (v) => v === undefined || v === null || typeof v === 'string';
const isNumber = (v) => typeof v === 'number' && !Number.isNaN(v);
const isArray = (v) => Array.isArray(v);
const isEnum = (v, allowed) => allowed.includes(v);

export const TASK_CATEGORIES = [
  'Primary',
  'Secondary',
  'Maintenance',
  'Recovery',
  'Reviews',
  'Practice',
  'Remediation',
  'Tests',
];

export const TASK_STATUSES = [
  'pending',
  'planned',
  'ready',
  'in_progress',
  'completed',
  'partially_completed',
  'skipped',
  'cancelled',
  'deferred',
];

export const TIMER_STATUSES = ['idle', 'running', 'paused', 'finished', 'cancelled'];
export const SKILL_STATES = ['LOCKED', 'AVAILABLE', 'IN_PROGRESS', 'MASTERED', 'MAINTENANCE'];
export const ERROR_SEVERITIES = ['low', 'medium', 'high', 'critical'];
export const ERROR_STATUSES = ['open', 'remediating', 'resolved', 'escalated'];

// Configurable 11-category Error Taxonomy + legacy v1-v4 aliases
export const ERROR_TAXONOMY_CATEGORIES = [
  'conceptual_misunderstanding',
  'missing_prerequisite',
  'procedural_error',
  'calculation_execution_error',
  'recall_failure',
  'misapplication',
  'attention_careless_error',
  'strategy_selection_error',
  'time_management_issue',
  'incomplete_evidence',
  'unknown_unclassified',
];

export const ERROR_CATEGORIES = [
  ...ERROR_TAXONOMY_CATEGORIES,
  'conceptual',
  'procedural',
  'calculation',
  'execution',
  'tactical',
  'general',
  'unknown',
];

export const RETEST_VERIFICATION_MODES = [
  'equivalent_questions',
  'new_examples',
  'varied_context',
  'independent_performance',
  'practical_demonstration',
  'delayed_retention_check',
];

export const RETENTION_STATUSES = [
  'UNMASTERED',
  'ACTIVE_MASTERY',
  'RETAINED',
  'DUE_FOR_REVIEW',
  'RETENTION_DECAY_RELEARNING',
];

export const LEARNING_STATES = [
  'LOCKED',
  'NOT_STARTED',
  'EXPOSED',
  'LEARNING',
  'PRACTICING',
  'RECALLING',
  'UNDER_REVIEW',
  'WEAK',
  'READY_FOR_TEST',
  'TESTED',
  'MASTERED',
  'MAINTENANCE',
  'REMEDIATION',
];

export const RESOURCE_TYPES = [
  'YouTube video',
  'Course',
  'Book',
  'PDF',
  'Article',
  'Lecture',
  'Problem set',
  'Exercise',
  'Documentation',
  'Project',
  'Custom resource',
];

export const RESOURCE_STATUSES = ['queued', 'in_progress', 'processed', 'archived'];

export const SESSION_TYPES = [
  'LEARN',
  'REVIEW',
  'RECALL',
  'PRACTICE',
  'TEST',
  'REMEDIATION',
  'PROJECT',
  'MAINTENANCE',
];

export const EVIDENCE_TYPES = [
  'training',
  'test',
  'retest',
  'retention',
  'practice',
  'learning',
  'study',
  'feynman',
  'worked_example',
  'summary',
  'independent_application',
  'project_artifact',
  'problem_set_solution',
  'tactical_analysis',
  'oral_written_production',
  'maintenance_review',
  'delayed_retention_check',
  'completed_exercise',
  'solved_problem',
  'written_explanation',
  'code_project',
  'quiz_result',
  'test_result',
  'practical_demonstration',
  'uploaded_work',
  'manual_verification',
];

export const TEST_KINDS = [
  'diagnostic',
  'formative',
  'practice',
  'mastery',
  'retention',
];

export const FLASHCARD_RETENTION_STATES = [
  'NEW',
  'LEARNING',
  'REVIEW',
  'RETAINED',
  'LAPSED',
];

export const NOTE_TARGET_TYPES = [
  'resource',
  'session',
  'objective',
  'skill',
  'subskill',
];

export const TIME_BLOCK_TYPES = [
  'fixed_commitment',
  'college',
  'sleep',
  'meals_prayer',
  'study_window',
  'task_block',
  'buffer',
  'recovery_break',
];

export const PERIODIC_REVIEW_TYPES = ['daily', 'weekly', 'monthly'];
export const STRATEGIC_DECISION_STATUSES = ['ACCEPTED', 'REJECTED', 'DEFERRED', 'DISMISSED', 'MODIFIED'];
export const OUTCOME_CLASSIFICATION_STATES = [
  'PENDING',
  'ACCEPTED_NOT_STARTED',
  'IN_PROGRESS',
  'AWAITING_VERIFICATION',
  'VERIFIED_SUCCESSFUL',
  'VERIFIED_UNSUCCESSFUL',
  'INCONCLUSIVE',
  'EXPIRED_INSUFFICIENT_EVIDENCE',
  'CANCELLED_OR_DISMISSED',
];

export const DAYS_OF_WEEK = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

export function getDefaultDomainEvidenceTypes(capabilityId = '') {
  if (capabilityId.includes('math')) return ['solved_problem', 'written_explanation', 'test_result'];
  if (capabilityId.includes('cs') || capabilityId.includes('cyber')) {
    return ['code_project', 'solved_problem', 'practical_demonstration', 'test_result'];
  }
  if (capabilityId.includes('chess')) return ['tactical_analysis', 'solved_problem', 'practical_demonstration'];
  if (capabilityId.includes('lang')) return ['oral_written_production', 'written_explanation', 'practical_demonstration'];
  if (capabilityId.includes('phys')) return ['practical_demonstration', 'manual_verification'];
  return [];
}

export function normalizeSkillRecord(raw) {
  if (!raw || typeof raw !== 'object') return raw;
  const nowIso = new Date().toISOString();
  const capabilityId = raw.capabilityId || raw.domain || 'cap-04-cs';
  const domain = raw.domain || capabilityId;
  const mc = raw.masteryCriteria || {};
  const maint = raw.maintenanceCriteria || {};
  const metrics = raw.metrics || {};
  const isMasteredNow = raw.status === 'MASTERED' || raw.status === 'MAINTENANCE';

  return {
    ...raw,
    capabilityId,
    domain,
    name: raw.name || raw.nameAr || '',
    nameAr: raw.nameAr || raw.name || '',
    description: isString(raw.description)
      ? raw.description
      : `تطوير وإتقان مهارة ${raw.nameAr || raw.name || ''}`,
    status: SKILL_STATES.includes(raw.status) ? raw.status : 'AVAILABLE',
    priority: isNumber(raw.priority) ? raw.priority : 2,
    prerequisites: isArray(raw.prerequisites) ? raw.prerequisites : [],
    subskills: isArray(raw.subskills) ? raw.subskills : [],
    historicalMasteryAchieved: Boolean(raw.historicalMasteryAchieved || isMasteredNow),
    firstMasteredAt: raw.firstMasteredAt || raw.masteredAt || (isMasteredNow ? nowIso : null),
    masteredAt: raw.masteredAt || raw.firstMasteredAt || (isMasteredNow ? nowIso : null),
    currentRetentionStatus: RETENTION_STATUSES.includes(raw.currentRetentionStatus)
      ? raw.currentRetentionStatus
      : raw.status === 'MAINTENANCE'
      ? 'RETAINED'
      : raw.status === 'MASTERED'
      ? 'ACTIVE_MASTERY'
      : 'UNMASTERED',
    masteryCriteria: {
      minTestScore: isNumber(mc.minTestScore) ? mc.minTestScore : isNumber(mc.minTestScorePct) ? mc.minTestScorePct : 85,
      minTestScorePct: isNumber(mc.minTestScorePct) ? mc.minTestScorePct : isNumber(mc.minTestScore) ? mc.minTestScore : 85,
      minAccuracy: isNumber(mc.minAccuracy) ? mc.minAccuracy : 80,
      minSuccessfulAttempts: isNumber(mc.minSuccessfulAttempts) ? mc.minSuccessfulAttempts : 1,
      consistencyDays: isNumber(mc.consistencyDays) ? mc.consistencyDays : isNumber(mc.consistency) ? mc.consistency : 2,
      consistency: isNumber(mc.consistency) ? mc.consistency : isNumber(mc.consistencyDays) ? mc.consistencyDays : 2,
      requiredEvidenceCount: isNumber(mc.requiredEvidenceCount) ? mc.requiredEvidenceCount : 1,
      requiredEvidenceTypes: isArray(mc.requiredEvidenceTypes) ? mc.requiredEvidenceTypes : [],
      requireIndependentApplication:
        mc.requireIndependentApplication !== undefined
          ? Boolean(mc.requireIndependentApplication)
          : false,
      prerequisiteMastery: mc.prerequisiteMastery !== undefined ? Boolean(mc.prerequisiteMastery) : true,
      requireAllSubskillsMastered:
        mc.requireAllSubskillsMastered !== undefined ? Boolean(mc.requireAllSubskillsMastered) : true,
      minPracticeHours: isNumber(mc.minPracticeHours) ? mc.minPracticeHours : 10,
      gatePassed: Boolean(mc.gatePassed),
    },
    maintenanceCriteria: {
      intervalDays: isNumber(maint.intervalDays) ? maint.intervalDays : 14,
      minRetentionScore: isNumber(maint.minRetentionScore) ? maint.minRetentionScore : 80,
      requiredSessions: isNumber(maint.requiredSessions) ? maint.requiredSessions : 1,
      lastReviewDate: maint.lastReviewDate || null,
      nextReviewDate: maint.nextReviewDate || null,
      retentionRate: isNumber(maint.retentionRate) ? maint.retentionRate : 100,
    },
    metrics: {
      totalStudyMinutes: isNumber(metrics.totalStudyMinutes) ? metrics.totalStudyMinutes : 0,
      totalPracticeMinutes: isNumber(metrics.totalPracticeMinutes) ? metrics.totalPracticeMinutes : 0,
      trainingSessionsCount: isNumber(metrics.trainingSessionsCount) ? metrics.trainingSessionsCount : 1,
      testsCompleted: isNumber(metrics.testsCompleted) ? metrics.testsCompleted : 0,
      successfulAttempts: isNumber(metrics.successfulAttempts) ? metrics.successfulAttempts : 0,
      avgTestScore: isNumber(metrics.avgTestScore) ? metrics.avgTestScore : 0,
      avgAccuracy: isNumber(metrics.avgAccuracy) ? metrics.avgAccuracy : 0,
      evidenceCount: isNumber(metrics.evidenceCount) ? metrics.evidenceCount : 0,
      errorCount: isNumber(metrics.errorCount) ? metrics.errorCount : 0,
      openErrorCount: isNumber(metrics.openErrorCount) ? metrics.openErrorCount : 0,
      maintenanceSessionsCount: isNumber(metrics.maintenanceSessionsCount) ? metrics.maintenanceSessionsCount : 0,
      lastPracticedDate: metrics.lastPracticedDate || null,
    },
    progress: raw.progress || {
      activityProgress: 0,
      learningProgress: 0,
      competence: 0,
      mastery: 0,
      retention: 0,
    },
    weaknessIndicators: raw.weaknessIndicators || {
      isWeak: false,
      unresolvedErrorsCount: 0,
      overdueReviewsCount: 0,
      retentionDecayCount: 0,
      weakSubskillsCount: 0,
      primaryWeaknessSummary: null,
    },
    createdAt: raw.createdAt || nowIso,
    updatedAt: raw.updatedAt || nowIso,
  };
}

export function normalizeSubskillRecord(raw) {
  if (!raw || typeof raw !== 'object') return raw;
  const nowIso = new Date().toISOString();
  const mc = raw.masteryCriteria || {};
  const tr = raw.training || {};
  const maint = raw.maintenance || {};
  const isMasteredNow = raw.masteryState === 'MASTERED' || raw.masteryState === 'MAINTENANCE';

  return {
    ...raw,
    name: raw.name || '',
    description: isString(raw.description) ? raw.description : `مهارة فرعية: ${raw.name || ''}`,
    level: isNumber(raw.level) ? raw.level : 1,
    prerequisites: isArray(raw.prerequisites) ? raw.prerequisites : [],
    historicalMasteryAchieved: Boolean(raw.historicalMasteryAchieved || isMasteredNow),
    firstMasteredAt: raw.firstMasteredAt || raw.masteredAt || (isMasteredNow ? nowIso : null),
    masteredAt: raw.masteredAt || raw.firstMasteredAt || (isMasteredNow ? nowIso : null),
    currentRetentionStatus: RETENTION_STATUSES.includes(raw.currentRetentionStatus)
      ? raw.currentRetentionStatus
      : raw.masteryState === 'MAINTENANCE'
      ? 'RETAINED'
      : raw.masteryState === 'MASTERED'
      ? 'ACTIVE_MASTERY'
      : 'UNMASTERED',
    training: {
      requiredSessions: isNumber(tr.requiredSessions) ? tr.requiredSessions : 1,
      completedSessions: isNumber(tr.completedSessions) ? tr.completedSessions : 0,
      totalMinutes: isNumber(tr.totalMinutes) ? tr.totalMinutes : 0,
      instructions: tr.instructions || 'تدرب عملياً مع توثيق الدليل (Evidence) قبل دخول الاختبار',
    },
    evidence: isArray(raw.evidence) ? raw.evidence : [],
    tests: isArray(raw.tests) ? raw.tests : [],
    masteryState: SKILL_STATES.includes(raw.masteryState) ? raw.masteryState : 'AVAILABLE',
    masteryCriteria: {
      minTestScore: isNumber(mc.minTestScore) ? mc.minTestScore : 85,
      minAccuracy: isNumber(mc.minAccuracy) ? mc.minAccuracy : 80,
      minSuccessfulAttempts: isNumber(mc.minSuccessfulAttempts) ? mc.minSuccessfulAttempts : 1,
      consistency: isNumber(mc.consistency) ? mc.consistency : 1,
      requiredEvidenceCount: isNumber(mc.requiredEvidenceCount) ? mc.requiredEvidenceCount : 1,
      requiredEvidenceTypes: isArray(mc.requiredEvidenceTypes) ? mc.requiredEvidenceTypes : [],
      requireIndependentApplication: Boolean(mc.requireIndependentApplication),
      prerequisiteMastery: mc.prerequisiteMastery !== undefined ? Boolean(mc.prerequisiteMastery) : true,
    },
    errors: isArray(raw.errors) ? raw.errors : [],
    remediation: isArray(raw.remediation) ? raw.remediation : [],
    maintenance: {
      intervalDays: isNumber(maint.intervalDays) ? maint.intervalDays : 14,
      lastReviewDate: maint.lastReviewDate || null,
      nextReviewDate: maint.nextReviewDate || null,
      retentionScore: isNumber(maint.retentionScore) ? maint.retentionScore : 100,
      sessionsCount: isNumber(maint.sessionsCount) ? maint.sessionsCount : 0,
    },
    createdAt: raw.createdAt || nowIso,
    updatedAt: raw.updatedAt || nowIso,
  };
}

export function normalizeErrorCategory(cat) {
  if (!cat) return 'unknown_unclassified';
  if (ERROR_CATEGORIES.includes(cat)) return cat;
  return 'unknown_unclassified';
}

export function normalizeErrorRecord(raw) {
  if (!raw || typeof raw !== 'object') return raw;
  const skillId = raw.skillId || raw.linkedSkill || '';
  const subskillId = raw.subskillId !== undefined ? raw.subskillId : (raw.linkedSubskill || null);
  const category = normalizeErrorCategory(raw.category);

  return {
    ...raw,
    goalId: raw.goalId || raw.linkedGoal || null,
    capabilityId: raw.capabilityId || raw.linkedCapability || null,
    skillId,
    linkedSkill: skillId,
    subskillId,
    linkedSubskill: subskillId,
    subskill: raw.subskill || subskillId || 'General Practice',
    objectiveId: raw.objectiveId || raw.linkedObjective || null,
    sessionId: raw.sessionId || raw.linkedSessionId || null,
    testId: raw.testId || raw.linkedTestId || null,
    linkedTestAttemptId: raw.linkedTestAttemptId || raw.linkedTestAttempt || null,
    category,
    taxonomyCategory: ERROR_TAXONOMY_CATEGORIES.includes(category)
      ? category
      : category === 'conceptual'
      ? 'conceptual_misunderstanding'
      : category === 'procedural'
      ? 'procedural_error'
      : category === 'calculation' || category === 'execution'
      ? 'calculation_execution_error'
      : category === 'tactical'
      ? 'strategy_selection_error'
      : 'unknown_unclassified',
    severity: ERROR_SEVERITIES.includes(raw.severity) ? raw.severity : 'medium',
    status: ERROR_STATUSES.includes(raw.status) ? raw.status : 'open',
    observedFacts: isArray(raw.observedFacts)
      ? raw.observedFacts
      : raw.evidence
      ? [String(raw.evidence)]
      : [],
    hypotheses: isArray(raw.hypotheses) ? raw.hypotheses : [],
    failureCount: isNumber(raw.failureCount) ? raw.failureCount : 1,
    remediationId: raw.remediationId || null,
    retestRequired: raw.retestRequired !== undefined ? Boolean(raw.retestRequired) : true,
    date: raw.date || new Date().toISOString().slice(0, 10),
  };
}

export function normalizeLearningObjectiveRecord(raw) {
  if (!raw || typeof raw !== 'object') return raw;
  const nowIso = new Date().toISOString();
  const skillId = raw.skillId || raw.linkedSkill || '';
  const subskillId = raw.subskillId || raw.linkedSubskill || null;
  const goalId = raw.goalId || raw.linkedGoal || null;
  const capabilityId = raw.capabilityId || raw.linkedCapability || 'cap-04-cs';

  return {
    ...raw,
    skillId,
    linkedSkill: skillId,
    subskillId,
    linkedSubskill: subskillId,
    goalId,
    linkedGoal: goalId,
    capabilityId,
    linkedCapability: capabilityId,
    title: raw.title || '',
    description: isString(raw.description) ? raw.description : raw.title || '',
    targetOutcome: isString(raw.targetOutcome)
      ? raw.targetOutcome
      : `القدرة العملية على تطبيق وإثبات: ${raw.title || ''}`,
    whyItMatters: isString(raw.whyItMatters)
      ? raw.whyItMatters
      : `يبني الكفاءة التطبيقية المباشرة في ${raw.title || ''}`,
    difficulty: isNumber(raw.difficulty) ? Math.max(1, Math.min(10, raw.difficulty)) : 5,
    estimatedEffortMin: isNumber(raw.estimatedEffortMin) ? raw.estimatedEffortMin : 60,
    status: LEARNING_STATES.includes(raw.status) ? raw.status : 'NOT_STARTED',
    masteryRelevance: ['core', 'supporting', 'advanced'].includes(raw.masteryRelevance)
      ? raw.masteryRelevance
      : 'core',
    prerequisites: isArray(raw.prerequisites) ? raw.prerequisites : [],
    historicalMasteryAchieved: Boolean(raw.historicalMasteryAchieved),
    masteredAt: raw.masteredAt || null,
    lastRetentionScore: isNumber(raw.lastRetentionScore) ? raw.lastRetentionScore : null,
    nextReviewDate: raw.nextReviewDate || null,
    createdAt: raw.createdAt || nowIso,
    updatedAt: raw.updatedAt || nowIso,
  };
}

export function normalizeResourceRecord(raw) {
  if (!raw || typeof raw !== 'object') return raw;
  const nowIso = new Date().toISOString();
  const skillId = raw.skillId || raw.linkedSkill || '';
  const subskillId = raw.subskillId || raw.linkedSubskill || null;
  const domain = raw.domain || raw.linkedDomain || 'cap-04-cs';

  return {
    ...raw,
    title: raw.title || '',
    type: RESOURCE_TYPES.includes(raw.type) ? raw.type : 'Custom resource',
    reference: isString(raw.reference) ? raw.reference : isString(raw.url) ? raw.url : 'local://reference',
    url: isString(raw.url) ? raw.url : isString(raw.reference) ? raw.reference : 'local://reference',
    author: raw.author || raw.source || 'Unknown Source',
    estimatedTimeMin: isNumber(raw.estimatedTimeMin)
      ? raw.estimatedTimeMin
      : isNumber(raw.duration)
      ? raw.duration
      : 30,
    difficulty: isNumber(raw.difficulty) ? Math.max(1, Math.min(10, raw.difficulty)) : 5,
    domain,
    linkedDomain: domain,
    skillId,
    linkedSkill: skillId,
    subskillId,
    linkedSubskill: subskillId,
    learningObjectives: isArray(raw.learningObjectives) ? raw.learningObjectives : [],
    status: RESOURCE_STATUSES.includes(raw.status) ? raw.status : 'queued',
    notes: raw.notes || '',
    createdAt: raw.createdAt || nowIso,
    updatedAt: raw.updatedAt || nowIso,
  };
}

export function normalizeScheduleConfigRecord(raw) {
  if (!raw || typeof raw !== 'object') return raw;
  return {
    ...raw,
    bufferRatio: isNumber(raw.bufferRatio) ? Math.max(0.05, Math.min(0.5, raw.bufferRatio)) : 0.2,
    maxDailyWorkloadMin: isNumber(raw.maxDailyWorkloadMin) ? raw.maxDailyWorkloadMin : 360,
    maxCollegeDayWorkloadMin: isNumber(raw.maxCollegeDayWorkloadMin)
      ? raw.maxCollegeDayWorkloadMin
      : 110,
    preferredTaskDurationMin: isNumber(raw.preferredTaskDurationMin)
      ? raw.preferredTaskDurationMin
      : 45,
    minRecoveryMinutesPerDay: isNumber(raw.minRecoveryMinutesPerDay)
      ? raw.minRecoveryMinutesPerDay
      : 20,
    studyWindows: isArray(raw.studyWindows)
      ? raw.studyWindows
      : [
          { id: 'win-morning', label: 'فترة التركيز الصباحية', start: '07:30', end: '11:30', collegeDayAllowed: false },
          { id: 'win-afternoon', label: 'فترة التدريب الظهيرة', start: '13:00', end: '16:30', collegeDayAllowed: false },
          { id: 'win-evening', label: 'فترة المساء والمراجعة', start: '19:00', end: '21:45', collegeDayAllowed: true },
        ],
    recurringCommitments: isArray(raw.recurringCommitments) ? raw.recurringCommitments : [],
  };
}

export function normalizeTaskRecord(raw) {
  if (!raw || typeof raw !== 'object') return raw;
  const executionState = raw.executionState || (raw.status === 'pending' ? 'ready' : raw.status);
  return {
    ...raw,
    executionState,
    difficulty: isNumber(raw.difficulty) ? Math.max(1, Math.min(10, raw.difficulty)) : 5,
    energyDemand: isNumber(raw.energyDemand) ? Math.max(1, Math.min(10, raw.energyDemand)) : 6,
    priorityScore: isNumber(raw.priorityScore) ? raw.priorityScore : (6 - (raw.priority || 3)) * 18,
    priorityBreakdown: raw.priorityBreakdown || null,
    selectionExplanation:
      raw.selectionExplanation || raw.notes || 'مهمة مجدولة ضمن خطة التطوير اليومية',
    whySelectedOverAlternatives:
      raw.whySelectedOverAlternatives || 'أولوية أعلى وتوافق مع المتطلبات والميزانية الزمنية المتاحة',
    consequenceIfSkipped:
      raw.consequenceIfSkipped || 'تأخر في تقدم المهارة المرتبطة وإعادة جدولتها لليوم التالي',
    prerequisiteStatus: raw.prerequisiteStatus || 'SATISFIED',
    skipCount: isNumber(raw.skipCount) ? raw.skipCount : 0,
    skipReason: raw.skipReason || null,
    blockers: isArray(raw.blockers) ? raw.blockers : [],
    partialCompletionPct: isNumber(raw.partialCompletionPct)
      ? raw.partialCompletionPct
      : raw.status === 'completed'
      ? 100
      : 0,
    timeBlockId: raw.timeBlockId || null,
    scheduledWindow: raw.scheduledWindow || null,
  };
}

export const Schemas = {
  Vision: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.title)) issues.push('title must be a non-empty string');
      if (!isString(data?.statement)) issues.push('statement must be a non-empty string');
      if (!isNumber(data?.horizonYears) || data.horizonYears < 1) {
        issues.push('horizonYears must be a positive number');
      }
      if (issues.length) throw new ValidationError('Vision', issues);
      return data;
    },
  },

  Goal: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.visionId)) issues.push('visionId is required');
      if (!isString(data?.title)) issues.push('title must be a non-empty string');
      if (!isString(data?.capabilityId)) issues.push('capabilityId is required');
      if (!isEnum(data?.status, ['active', 'achieved', 'paused'])) {
        issues.push('status must be active | achieved | paused');
      }
      if (!isNumber(data?.progressPct) || data.progressPct < 0 || data.progressPct > 100) {
        issues.push('progressPct must be between 0 and 100');
      }
      if (issues.length) throw new ValidationError('Goal', issues);
      return data;
    },
  },

  Capability: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isNumber(data?.order) || data.order < 1) issues.push('order must be >= 1');
      if (!isString(data?.name)) issues.push('name must be a non-empty string');
      if (!isString(data?.nameAr)) issues.push('nameAr must be a non-empty string');
      if (!isArray(data?.subareas) || data.subareas.length === 0) {
        issues.push('subareas must be a non-empty array');
      }
      if (issues.length) throw new ValidationError('Capability', issues);
      return data;
    },
  },

  Skill: {
    validate(raw) {
      const data = normalizeSkillRecord(raw);
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.capabilityId)) issues.push('capabilityId/domain is required');
      if (!isString(data?.name)) issues.push('name must be a non-empty string');
      if (!isString(data?.description)) issues.push('description must be a non-empty string');
      if (!isNumber(data?.currentLevel) || data.currentLevel < 0 || data.currentLevel > 10) {
        issues.push('currentLevel must be between 0 and 10');
      }
      if (!isNumber(data?.targetLevel) || data.targetLevel < 1 || data.targetLevel > 10) {
        issues.push('targetLevel must be between 1 and 10');
      }
      if (!isEnum(data?.status, SKILL_STATES)) {
        issues.push(`status must be one of ${SKILL_STATES.join(', ')}`);
      }
      if (!isNumber(data?.priority) || data.priority < 1 || data.priority > 5) {
        issues.push('priority must be between 1 and 5');
      }
      if (!isArray(data?.prerequisites)) issues.push('prerequisites must be an array');
      if (!isArray(data?.subskills)) issues.push('subskills must be an array');
      if (!data?.masteryCriteria || typeof data.masteryCriteria !== 'object') {
        issues.push('masteryCriteria object is required');
      }
      if (!data?.maintenanceCriteria || typeof data.maintenanceCriteria !== 'object') {
        issues.push('maintenanceCriteria object is required');
      }
      if (!data?.metrics || typeof data.metrics !== 'object') {
        issues.push('metrics object is required');
      }
      if (issues.length) throw new ValidationError('Skill', issues);
      return data;
    },
  },

  Subskill: {
    validate(raw) {
      const data = normalizeSubskillRecord(raw);
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isString(data?.name)) issues.push('name must be a non-empty string');
      if (!isNumber(data?.level) || data.level < 1 || data.level > 10) {
        issues.push('level must be between 1 and 10');
      }
      if (!isArray(data?.prerequisites)) issues.push('prerequisites must be an array');
      if (!isEnum(data?.masteryState, SKILL_STATES)) {
        issues.push(`masteryState must be one of ${SKILL_STATES.join(', ')}`);
      }
      if (!data?.training || typeof data.training !== 'object') {
        issues.push('training object is required');
      }
      if (!isArray(data?.evidence)) issues.push('evidence must be an array');
      if (!isArray(data?.tests)) issues.push('tests must be an array');
      if (!isArray(data?.errors)) issues.push('errors must be an array');
      if (!isArray(data?.remediation)) issues.push('remediation must be an array');
      if (!data?.maintenance || typeof data.maintenance !== 'object') {
        issues.push('maintenance object is required');
      }
      if (issues.length) throw new ValidationError('Subskill', issues);
      return data;
    },
  },

  Curriculum: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isString(data?.title)) issues.push('title must be a non-empty string');
      if (issues.length) throw new ValidationError('Curriculum', issues);
      return data;
    },
  },

  Evidence: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isString(data?.title)) issues.push('title must be a non-empty string');
      if (!isEnum(data?.type, EVIDENCE_TYPES)) {
        issues.push(`type must be one of ${EVIDENCE_TYPES.join(', ')}`);
      }
      if (issues.length) throw new ValidationError('Evidence', issues);
      return data;
    },
  },

  Test: {
    validate(data) {
      const normalized = {
        ...data,
        testType: TEST_KINDS.includes(data?.testType) ? data.testType : 'mastery',
      };
      const issues = [];
      if (!isString(normalized?.id)) issues.push('id must be a non-empty string');
      if (!isString(normalized?.skillId)) issues.push('skillId is required');
      if (!isString(normalized?.title)) issues.push('title must be a non-empty string');
      if (!isNumber(normalized?.passingScore) || normalized.passingScore < 0 || normalized.passingScore > 100) {
        issues.push('passingScore must be between 0 and 100');
      }
      if (!isNumber(normalized?.minAccuracy) || normalized.minAccuracy < 0 || normalized.minAccuracy > 100) {
        issues.push('minAccuracy must be between 0 and 100');
      }
      if (issues.length) throw new ValidationError('Test', issues);
      return normalized;
    },
  },

  TestAttempt: {
    validate(data) {
      const normalized = {
        ...data,
        verificationMode: RETEST_VERIFICATION_MODES.includes(data?.verificationMode)
          ? data.verificationMode
          : 'equivalent_questions',
      };
      const issues = [];
      if (!isString(normalized?.id)) issues.push('id must be a non-empty string');
      if (!isString(normalized?.skillId)) issues.push('skillId is required');
      if (!isNumber(normalized?.score) || normalized.score < 0 || normalized.score > 100) {
        issues.push('score must be between 0 and 100');
      }
      if (!isNumber(normalized?.accuracy) || normalized.accuracy < 0 || normalized.accuracy > 100) {
        issues.push('accuracy must be between 0 and 100');
      }
      if (typeof normalized?.passed !== 'boolean') {
        issues.push('passed must be a boolean');
      }
      if (!isString(normalized?.timestamp)) issues.push('timestamp is required');
      if (issues.length) throw new ValidationError('TestAttempt', issues);
      return normalized;
    },
  },

  Remediation: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.errorId)) issues.push('errorId is required');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isString(data?.title)) issues.push('title is required');
      if (!isArray(data?.correctiveTaskIds)) issues.push('correctiveTaskIds must be an array');
      if (!isEnum(data?.status, ['active', 'ready_for_retest', 'completed', 'escalated'])) {
        issues.push('status must be active | ready_for_retest | completed | escalated');
      }
      if (issues.length) throw new ValidationError('Remediation', issues);
      return data;
    },
  },

  Review: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isString(data?.reviewDate)) issues.push('reviewDate is required');
      if (!isString(data?.nextReviewDate)) issues.push('nextReviewDate is required');
      if (!isNumber(data?.score) || data.score < 0 || data.score > 100) {
        issues.push('score must be between 0 and 100');
      }
      if (issues.length) throw new ValidationError('Review', issues);
      return data;
    },
  },

  DiagnosticAssessment: {
    validate(raw) {
      const nowIso = new Date().toISOString();
      const data = {
        ...raw,
        timestamp: raw?.timestamp || raw?.createdAt || nowIso,
        createdAt: raw?.createdAt || raw?.timestamp || nowIso,
      };
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isArray(data?.observedFacts)) issues.push('observedFacts must be an array');
      if (!isArray(data?.hypotheses)) issues.push('hypotheses must be an array');
      if (!isString(data?.timestamp)) issues.push('timestamp is required');
      if (issues.length) throw new ValidationError('DiagnosticAssessment', issues);
      return data;
    },
  },

  MasteryHistory: {
    validate(raw) {
      const nowIso = new Date().toISOString();
      const tType = raw?.transitionType || raw?.eventType || 'MASTERY_ACHIEVED';
      const data = {
        ...raw,
        transitionType: tType,
        eventType: raw?.eventType || tType,
        timestamp: raw?.timestamp || nowIso,
      };
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.entityType)) issues.push('entityType is required');
      if (!isString(data?.entityId)) issues.push('entityId is required');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isString(data?.transitionType)) issues.push('transitionType is required');
      if (!isString(data?.timestamp)) issues.push('timestamp is required');
      if (issues.length) throw new ValidationError('MasteryHistory', issues);
      return data;
    },
  },

  StrategicDecision: {
    validate(raw) {
      const nowIso = new Date().toISOString();
      const data = {
        ...raw,
        status: STRATEGIC_DECISION_STATUSES.includes(raw?.status) ? raw.status : 'ACCEPTED',
        supportingEvidence: Array.isArray(raw?.supportingEvidence) ? raw.supportingEvidence : [],
        createdAt: raw?.createdAt || nowIso,
        updatedAt: raw?.updatedAt || nowIso,
      };
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.recommendationKey)) issues.push('recommendationKey is required');
      if (!isString(data?.actionType)) issues.push('actionType is required');
      if (!isEnum(data?.status, STRATEGIC_DECISION_STATUSES)) {
        issues.push('status must be ACCEPTED | REJECTED | DEFERRED | DISMISSED | MODIFIED');
      }
      if (issues.length) throw new ValidationError('StrategicDecision', issues);
      return data;
    },
  },

  OutcomeEvaluation: {
    validate(raw) {
      const nowIso = new Date().toISOString();
      const data = {
        ...raw,
        evaluationVersion: typeof raw?.evaluationVersion === 'number' ? raw.evaluationVersion : 1,
        isReevaluation: Boolean(raw?.isReevaluation),
        evidenceUsedRefs: Array.isArray(raw?.evidenceUsedRefs) ? raw.evidenceUsedRefs : [],
        evaluatedAt: raw?.evaluatedAt || nowIso,
      };
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.decisionId)) issues.push('decisionId is required');
      if (!isString(data?.recommendationKey)) issues.push('recommendationKey is required');
      if (!isString(data?.actionType)) issues.push('actionType is required');
      if (!isEnum(data?.outcomeState, OUTCOME_CLASSIFICATION_STATES)) {
        issues.push(`outcomeState must be one of ${OUTCOME_CLASSIFICATION_STATES.join(', ')}`);
      }
      if (issues.length) throw new ValidationError('OutcomeEvaluation', issues);
      return data;
    },
  },

  PeriodicReview: {
    validate(raw) {
      const nowIso = new Date().toISOString();
      const data = {
        ...raw,
        periodType: PERIODIC_REVIEW_TYPES.includes(raw?.periodType) ? raw.periodType : 'daily',
        userNotes: typeof raw?.userNotes === 'string' ? raw.userNotes : '',
        decisions: Array.isArray(raw?.decisions) ? raw.decisions : [],
        nextActions: Array.isArray(raw?.nextActions) ? raw.nextActions : [],
        createdAt: raw?.createdAt || nowIso,
      };
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isEnum(data?.periodType, PERIODIC_REVIEW_TYPES)) {
        issues.push('periodType must be daily | weekly | monthly');
      }
      if (!isString(data?.periodKey)) issues.push('periodKey is required');
      if (!isString(data?.startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(data.startDate)) {
        issues.push('startDate must be YYYY-MM-DD');
      }
      if (!isString(data?.endDate) || !/^\d{4}-\d{2}-\d{2}$/.test(data.endDate)) {
        issues.push('endDate must be YYYY-MM-DD');
      }
      if (!data?.snapshot || typeof data.snapshot !== 'object') {
        issues.push('snapshot object is required');
      }
      if (issues.length) throw new ValidationError('PeriodicReview', issues);
      return data;
    },
  },

  LearningObjective: {
    validate(raw) {
      const data = normalizeLearningObjectiveRecord(raw);
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.title)) issues.push('title must be a non-empty string');
      if (!isString(data?.skillId)) issues.push('skillId/linkedSkill is required');
      if (!isString(data?.targetOutcome)) issues.push('targetOutcome is required');
      if (!isEnum(data?.status, LEARNING_STATES)) {
        issues.push(`status must be one of ${LEARNING_STATES.join(', ')}`);
      }
      if (!isNumber(data?.difficulty) || data.difficulty < 1 || data.difficulty > 10) {
        issues.push('difficulty must be between 1 and 10');
      }
      if (!isNumber(data?.estimatedEffortMin) || data.estimatedEffortMin < 1) {
        issues.push('estimatedEffortMin must be >= 1');
      }
      if (!isArray(data?.prerequisites)) issues.push('prerequisites must be an array');
      if (issues.length) throw new ValidationError('LearningObjective', issues);
      return data;
    },
  },

  Resource: {
    validate(raw) {
      const data = normalizeResourceRecord(raw);
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.title)) issues.push('title must be a non-empty string');
      if (!isEnum(data?.type, RESOURCE_TYPES)) {
        issues.push(`type must be one of ${RESOURCE_TYPES.join(', ')}`);
      }
      if (!isString(data?.skillId) && (!isArray(data?.learningObjectives) || data.learningObjectives.length === 0)) {
        issues.push('Resource must be linked to a skillId or at least one learningObjective');
      }
      if (issues.length) throw new ValidationError('Resource', issues);
      return data;
    },
  },

  LearningSession: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.objectiveId)) issues.push('objectiveId is required');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isEnum(data?.sessionType, SESSION_TYPES)) {
        issues.push(`sessionType must be one of ${SESSION_TYPES.join(', ')}`);
      }
      if (!isEnum(data?.completionState, ['in_progress', 'completed', 'partial', 'aborted'])) {
        issues.push('completionState must be in_progress | completed | partial | aborted');
      }
      if (!isNumber(data?.plannedDurationMin) || data.plannedDurationMin < 0) {
        issues.push('plannedDurationMin must be >= 0');
      }
      if (!isNumber(data?.actualDurationMin) || data.actualDurationMin < 0) {
        issues.push('actualDurationMin must be >= 0');
      }
      if (issues.length) throw new ValidationError('LearningSession', issues);
      return data;
    },
  },

  RecallAttempt: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.objectiveId)) issues.push('objectiveId is required');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isString(data?.question)) issues.push('question is required');
      if (!isString(data?.expectedAnswer)) issues.push('expectedAnswer is required');
      if (!isString(data?.userAnswer)) issues.push('userAnswer is required');
      if (!isNumber(data?.correctness) || data.correctness < 0 || data.correctness > 100) {
        issues.push('correctness must be between 0 and 100');
      }
      if (!isNumber(data?.confidence) || data.confidence < 0 || data.confidence > 100) {
        issues.push('confidence must be between 0 and 100');
      }
      if (!isString(data?.timestamp)) issues.push('timestamp is required');
      if (issues.length) throw new ValidationError('RecallAttempt', issues);
      return data;
    },
  },

  Flashcard: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.front)) issues.push('front is required');
      if (!isString(data?.back)) issues.push('back is required');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isArray(data?.reviewHistory)) issues.push('reviewHistory must be an array');
      if (!isEnum(data?.retentionState, FLASHCARD_RETENTION_STATES)) {
        issues.push(`retentionState must be one of ${FLASHCARD_RETENTION_STATES.join(', ')}`);
      }
      if (issues.length) throw new ValidationError('Flashcard', issues);
      return data;
    },
  },

  FeynmanEntry: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.objectiveId)) issues.push('objectiveId is required');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isString(data?.explanation)) issues.push('explanation is required');
      if (!isArray(data?.identifiedGaps)) issues.push('identifiedGaps must be an array');
      if (!isString(data?.timestamp)) issues.push('timestamp is required');
      if (issues.length) throw new ValidationError('FeynmanEntry', issues);
      return data;
    },
  },

  LearningPath: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.title)) issues.push('title is required');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isArray(data?.objectiveIds)) issues.push('objectiveIds must be an array');
      if (issues.length) throw new ValidationError('LearningPath', issues);
      return data;
    },
  },

  LearningNote: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isEnum(data?.targetType, NOTE_TARGET_TYPES)) {
        issues.push(`targetType must be one of ${NOTE_TARGET_TYPES.join(', ')}`);
      }
      if (!isString(data?.targetId)) issues.push('targetId is required');
      if (!isString(data?.content)) issues.push('content is required');
      if (issues.length) throw new ValidationError('LearningNote', issues);
      return data;
    },
  },

  ScheduleConfig: {
    validate(raw) {
      const data = normalizeScheduleConfigRecord(raw);
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isArray(data?.collegeDays) || !data.collegeDays.every((d) => DAYS_OF_WEEK.includes(d))) {
        issues.push('collegeDays must be an array of valid weekday names');
      }
      if (!isString(data?.collegeStart) || !/^\d{2}:\d{2}$/.test(data.collegeStart)) {
        issues.push('collegeStart must be HH:MM');
      }
      if (!isString(data?.collegeEnd) || !/^\d{2}:\d{2}$/.test(data.collegeEnd)) {
        issues.push('collegeEnd must be HH:MM');
      }
      if (!isNumber(data?.sleepHours) || data.sleepHours < 3 || data.sleepHours > 14) {
        issues.push('sleepHours must be between 3 and 14');
      }
      if (issues.length) throw new ValidationError('ScheduleConfig', issues);
      return data;
    },
  },

  Task: {
    validate(raw) {
      const data = normalizeTaskRecord(raw);
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.title)) issues.push('title must be a non-empty string');
      if (!isString(data?.date) || !/^\d{4}-\d{2}-\d{2}$/.test(data.date)) {
        issues.push('date must be YYYY-MM-DD');
      }
      if (!isEnum(data?.category, TASK_CATEGORIES)) {
        issues.push(`category must be one of ${TASK_CATEGORIES.join(', ')}`);
      }
      if (!isEnum(data?.status, TASK_STATUSES)) {
        issues.push(`status must be one of ${TASK_STATUSES.join(', ')}`);
      }
      if (!isNumber(data?.plannedDurationMin) || data.plannedDurationMin < 1 || data.plannedDurationMin > 600) {
        issues.push('plannedDurationMin must be between 1 and 600');
      }
      if (!isNumber(data?.priority) || data.priority < 1 || data.priority > 5) {
        issues.push('priority must be between 1 and 5');
      }
      if (!isOptionalString(data?.skillId)) issues.push('skillId must be string or null');
      if (issues.length) throw new ValidationError('Task', issues);
      return data;
    },
  },

  TimeBlock: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.date) || !/^\d{4}-\d{2}-\d{2}$/.test(data.date)) {
        issues.push('date must be YYYY-MM-DD');
      }
      if (!isString(data?.title)) issues.push('title must be a non-empty string');
      if (!isString(data?.startTime) || !/^\d{2}:\d{2}$/.test(data.startTime)) {
        issues.push('startTime must be HH:MM');
      }
      if (!isString(data?.endTime) || !/^\d{2}:\d{2}$/.test(data.endTime)) {
        issues.push('endTime must be HH:MM');
      }
      if (!isEnum(data?.blockType, TIME_BLOCK_TYPES)) {
        issues.push(`blockType must be one of ${TIME_BLOCK_TYPES.join(', ')}`);
      }
      if (typeof data?.isFixed !== 'boolean') {
        issues.push('isFixed must be a boolean');
      }
      if (issues.length) throw new ValidationError('TimeBlock', issues);
      return data;
    },
  },

  WeeklyPlan: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.weekStartDate) || !/^\d{4}-\d{2}-\d{2}$/.test(data.weekStartDate)) {
        issues.push('weekStartDate must be YYYY-MM-DD');
      }
      if (!isArray(data?.days) || data.days.length !== 7) {
        issues.push('days must be an array of 7 daily summaries');
      }
      if (issues.length) throw new ValidationError('WeeklyPlan', issues);
      return data;
    },
  },

  ExecutionHistory: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.taskId)) issues.push('taskId is required');
      if (!isString(data?.date)) issues.push('date is required');
      if (!isString(data?.eventType)) issues.push('eventType is required');
      if (!isString(data?.timestamp)) issues.push('timestamp is required');
      if (issues.length) throw new ValidationError('ExecutionHistory', issues);
      return data;
    },
  },

  TimerState: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isEnum(data?.status, TIMER_STATUSES)) {
        issues.push(`status must be one of ${TIMER_STATUSES.join(', ')}`);
      }
      if (!isNumber(data?.plannedDurationSec) || data.plannedDurationSec < 0) {
        issues.push('plannedDurationSec must be >= 0');
      }
      if (!isNumber(data?.accumulatedActiveMs) || data.accumulatedActiveMs < 0) {
        issues.push('accumulatedActiveMs must be >= 0');
      }
      if (!isNumber(data?.accumulatedPauseMs) || data.accumulatedPauseMs < 0) {
        issues.push('accumulatedPauseMs must be >= 0');
      }
      if (issues.length) throw new ValidationError('TimerState', issues);
      return data;
    },
  },

  PerformanceLog: {
    validate(data) {
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.taskId)) issues.push('taskId is required');
      if (!isString(data?.date)) issues.push('date is required');
      if (!isNumber(data?.plannedDurationSec) || data.plannedDurationSec < 0) {
        issues.push('plannedDurationSec must be >= 0');
      }
      if (!isNumber(data?.actualDurationSec) || data.actualDurationSec < 0) {
        issues.push('actualDurationSec must be >= 0');
      }
      if (!isNumber(data?.pauseDurationSec) || data.pauseDurationSec < 0) {
        issues.push('pauseDurationSec must be >= 0');
      }
      if (!isNumber(data?.completionPct) || data.completionPct < 0 || data.completionPct > 100) {
        issues.push('completionPct must be between 0 and 100');
      }
      if (!isNumber(data?.energy) || data.energy < 1 || data.energy > 10) {
        issues.push('energy must be between 1 and 10');
      }
      if (!isNumber(data?.difficulty) || data.difficulty < 1 || data.difficulty > 10) {
        issues.push('difficulty must be between 1 and 10');
      }
      if (!isNumber(data?.confidence) || data.confidence < 1 || data.confidence > 10) {
        issues.push('confidence must be between 1 and 10');
      }
      if (!isOptionalString(data?.whatLearned)) issues.push('whatLearned must be string');
      if (!isOptionalString(data?.mistakes)) issues.push('mistakes must be string');
      if (!isOptionalString(data?.notes)) issues.push('notes must be string');
      if (issues.length) throw new ValidationError('PerformanceLog', issues);
      return data;
    },
  },

  ErrorRecord: {
    validate(raw) {
      const data = normalizeErrorRecord(raw);
      const issues = [];
      if (!isString(data?.id)) issues.push('id must be a non-empty string');
      if (!isString(data?.skillId)) issues.push('skillId is required');
      if (!isString(data?.description)) issues.push('description is required');
      if (!isEnum(data?.severity, ERROR_SEVERITIES)) {
        issues.push('severity must be low | medium | high | critical');
      }
      if (!isEnum(data?.category, ERROR_CATEGORIES)) {
        issues.push(`category must be one of ${ERROR_CATEGORIES.join(', ')}`);
      }
      if (!isEnum(data?.status, ERROR_STATUSES)) {
        issues.push('status must be open | remediating | resolved | escalated');
      }
      if (issues.length) throw new ValidationError('ErrorRecord', issues);
      return data;
    },
  },
};

export function validateEntity(storeName, record) {
  const map = {
    visions: Schemas.Vision,
    goals: Schemas.Goal,
    capabilities: Schemas.Capability,
    skills: Schemas.Skill,
    subskills: Schemas.Subskill,
    curriculum: Schemas.Curriculum,
    resources: Schemas.Resource,
    evidence: Schemas.Evidence,
    tests: Schemas.Test,
    test_attempts: Schemas.TestAttempt,
    remediations: Schemas.Remediation,
    reviews: Schemas.Review,
    learning_objectives: Schemas.LearningObjective,
    learning_sessions: Schemas.LearningSession,
    recall_attempts: Schemas.RecallAttempt,
    flashcards: Schemas.Flashcard,
    feynman_entries: Schemas.FeynmanEntry,
    learning_paths: Schemas.LearningPath,
    learning_notes: Schemas.LearningNote,
    schedule_config: Schemas.ScheduleConfig,
    tasks: Schemas.Task,
    time_blocks: Schemas.TimeBlock,
    weekly_plans: Schemas.WeeklyPlan,
    execution_history: Schemas.ExecutionHistory,
    diagnostic_assessments: Schemas.DiagnosticAssessment,
    mastery_history: Schemas.MasteryHistory,
    periodic_reviews: Schemas.PeriodicReview,
    strategic_decisions: Schemas.StrategicDecision,
    outcome_evaluations: Schemas.OutcomeEvaluation,
    timer_state: Schemas.TimerState,
    performance_logs: Schemas.PerformanceLog,
    errors: Schemas.ErrorRecord,
  };
  const validator = map[storeName];
  if (validator) {
    return validator.validate(record);
  }
  if (!record || !isString(record.id)) {
    throw new ValidationError(storeName, ['Record must have a valid string id']);
  }
  return record;
}
