/**
 * backupService.js — full export/import of all app data.
 * v2: backups can also be copied as text, restore can fully REPLACE, there is a
 * "last backup" date with a reminder, and any table can be exported as CSV.
 */

import { getStoreNames, DB_VERSION } from './db.js';
import { getAll, put, withStoreClear } from './storageService.js';
import { todayISO, daysBetween } from '../utils/dateUtils.js';
import { getProfile, updateProfile, resetProfileCache } from '../profile/profileService.js';

export async function exportAllData() {
  const data = {};
  for (const storeName of getStoreNames()) data[storeName] = await getAll(storeName);
  return { app: 'personalOS', schemaVersion: DB_VERSION, appVersion: '3.0.0', exportedAt: new Date().toISOString(), data };
}

function saveTextAsFile(filename, text, mime = 'application/json') {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export async function downloadBackup() {
  const backup = await exportAllData();
  saveTextAsFile(`life-guide-backup-${todayISO()}.json`, JSON.stringify(backup), 'application/json');
  await updateProfile({ lastBackup: todayISO() });
}

/** Opens the share sheet (WhatsApp, Google Drive, email) with the backup file; falls back to a download. */
export async function shareBackupFile() {
  const { shareBackup } = await import('../native/bridge.js');
  const text = JSON.stringify(await exportAllData());
  const result = await shareBackup(text, `life-guide-backup-${todayISO()}.json`);
  if (result !== 'cancelled') await updateProfile({ lastBackup: todayISO() });
  return result;
}

export async function copyBackupText() {
  const text = JSON.stringify(await exportAllData());
  try { await navigator.clipboard.writeText(text); } catch {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
  }
  await updateProfile({ lastBackup: todayISO() });
}

export async function downloadCSV(storeName) {
  const rows = await getAll(storeName);
  if (!rows.length) return false;
  const cols = [];
  rows.forEach((r) => Object.keys(r).forEach((k) => { if (!cols.includes(k)) cols.push(k); }));
  const q = (v) => { if (v == null) return ''; const s = typeof v === 'object' ? JSON.stringify(v) : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const csv = [cols.join(',')].concat(rows.map((r) => cols.map((c) => q(r[c])).join(','))).join('\n');
  saveTextAsFile(`${storeName}-${todayISO()}.csv`, csv, 'text/csv');
  return true;
}

/** Validate + restore. mode 'merge' keeps current data; 'replace' wipes first. */
export async function importBackupText(text, mode = 'merge') {
  let parsed;
  try { parsed = JSON.parse(text); } catch { throw new Error('That is not valid backup text.'); }
  if (!parsed?.data || parsed.app !== 'personalOS') throw new Error('This file is not a recognized Personal OS backup.');
  if (parsed.schemaVersion > DB_VERSION) throw new Error('This backup was made with a newer app version. Please update the app first.');

  const known = new Set(getStoreNames());
  // Validate everything BEFORE touching the database: every record must be an object with an id (or key for settings).
  for (const [storeName, records] of Object.entries(parsed.data)) {
    if (!known.has(storeName)) continue;
    if (!Array.isArray(records) || records.some((r) => !r || typeof r !== 'object' || (r.id === undefined && r.key === undefined))) {
      throw new Error(`The backup looks damaged (problem in "${storeName}"). Nothing was changed.`);
    }
  }
  // Safety net for "replace": keep the current data so a failure half-way can be rolled back.
  const before = mode === 'replace' ? await exportAllData() : null;
  let restored = 0;
  try {
    if (mode === 'replace') for (const name of known) if (Array.isArray(parsed.data[name])) await withStoreClear(name);
    for (const [storeName, records] of Object.entries(parsed.data)) {
      if (!known.has(storeName)) continue;
      for (const record of records) { await put(storeName, record); restored += 1; }
    }
  } catch (err) {
    if (before) {
      for (const name of known) if (Array.isArray(before.data[name])) { await withStoreClear(name); for (const r of before.data[name]) await put(name, r); }
    }
    throw new Error('Restore failed, so your previous data was put back. Nothing was lost.');
  }
  resetProfileCache();
  // Preferences, theme and Home arrangement come back with the backup — re-apply them now.
  try {
    const { getPrefs, applyPreferences } = await import('../profile/prefsService.js');
    const { getDash } = await import('../../modules/dashboard/dashPrefs.js');
    const { applyTheme } = await import('../profile/profileService.js');
    await getPrefs(); applyPreferences(); await getDash(); await applyTheme();
  } catch { /* cosmetic only */ }
  return restored;
}

export async function importBackupFile(file, mode = 'merge') {
  return importBackupText(await file.text(), mode);
}

/** True when the last backup is older than the user's reminder interval. */
export function backupDue(profile) {
  if (!profile || !profile.backupEveryDays) return false;
  const ref = profile.lastBackup || profile.installedOn || todayISO();
  return daysBetween(ref, todayISO()) >= profile.backupEveryDays;
}

export { getProfile };
