/**
 * pinLock.js — PIN screen lock. A local deterrent for casual snooping:
 * the PIN is salted + SHA-256 hashed, but the data itself is NOT encrypted.
 */
import { getSetting, setSetting } from '../storage/storageService.js';
import { buzz } from '../profile/prefsService.js';
import { el } from '../../components/ui.js';
import { biometricAvailable, biometricUnlock } from '../native/bridge.js';
import { getProfile } from '../profile/profileService.js';

const KEY = 'security.pin';
const CFG_KEY = 'security.config';
const FAIL_KEY = 'security.fails';
export const LOCK_OPTIONS = [
  { label: 'Right away', value: 0 },
  { label: '30 sec', value: 30 },
  { label: '1 min', value: 60 },
  { label: '5 min', value: 300 },
  { label: 'Only when closed', value: -1 },
];
const DEFAULT_CFG = { timeoutSec: 60, recoveryQ: '', recoveryHash: '' };

export async function getLockConfig() { return { ...DEFAULT_CFG, ...(await getSetting(CFG_KEY, null) || {}) }; }
export async function saveLockConfig(patch) { await setSetting(CFG_KEY, { ...(await getLockConfig()), ...patch }); }

const normAnswer = (a) => String(a).trim().toLowerCase().replace(/\s+/g, ' ');
export async function hasRecovery() { return !!(await getLockConfig()).recoveryHash; }
export async function setRecovery(question, answer) {
  await saveLockConfig({ recoveryQ: question.trim(), recoveryHash: await sha256(`rec:${normAnswer(answer)}`) });
}
async function verifyRecovery(answer) {
  const cfg = await getLockConfig();
  return !!cfg.recoveryHash && (await sha256(`rec:${normAnswer(answer)}`)) === cfg.recoveryHash;
}

// wrong-PIN throttle: 5 wrong tries -> wait 30s, then 60s, 120s... (kept in localStorage)
function readFails() { try { return JSON.parse(localStorage.getItem(FAIL_KEY) || '{}'); } catch { return {}; } }
function writeFails(v) { try { localStorage.setItem(FAIL_KEY, JSON.stringify(v)); } catch { /* ignore */ } }
function lockedForMs() { const f = readFails(); return Math.max(0, (f.until || 0) - Date.now()); }
function registerFail() {
  const f = readFails(); f.count = (f.count || 0) + 1;
  if (f.count % 5 === 0) f.until = Date.now() + 30000 * 2 ** (f.count / 5 - 1);
  writeFails(f);
}
const clearFails = () => writeFails({});

async function sha256(text) {
  try {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch {
    // crypto.subtle needs a secure context; fall back to a simple hash on plain http
    let h = 5381;
    for (let i = 0; i < text.length; i += 1) h = ((h << 5) + h + text.charCodeAt(i)) | 0;
    return `f${h}`;
  }
}

export async function hasPin() { return !!(await getSetting(KEY, null)); }

export async function setPin(pin) {
  const salt = Math.random().toString(36).slice(2) + Date.now().toString(36);
  await setSetting(KEY, { salt, len: String(pin).length, hash: await sha256(salt + pin) });
}

export async function removePin() { await setSetting(KEY, null); }

export async function verifyPin(pin) {
  const rec = await getSetting(KEY, null);
  if (!rec) return true;
  return (await sha256(rec.salt + pin)) === rec.hash;
}

let lockEl = null;

/** Shows the lock screen; resolves when unlocked (or immediately if no PIN). */
export async function showLockIfNeeded() {
  if (lockEl || !(await hasPin())) return;
  const profile = await getProfile();
  await new Promise(async (resolve) => {
    let entered = '';
    const rec = await getSetting(KEY, null);
    const pinLen = rec?.len || 4;
    const dots = el('div', 'lock-dots');
    const msg = el('div', 'lock-msg', ' ');
    const redraw = () => {
      dots.innerHTML = '';
      for (let i = 0; i < Math.max(pinLen, entered.length); i += 1) {
        dots.append(el('span', `lock-dot${i < entered.length ? ' lock-dot--on' : ''}`));
      }
    };
    const submit = async () => {
      if (entered.length < 4) return;
      const wait = lockedForMs();
      if (wait > 0) { msg.textContent = `Too many tries. Wait ${Math.ceil(wait / 1000)}s.`; entered = ''; redraw(); return; }
      if (await verifyPin(entered)) {
        clearFails();
        lockEl.classList.add('lock--out');
        setTimeout(() => { lockEl?.remove(); lockEl = null; resolve(); }, 250);
      } else {
        registerFail();
        const w = lockedForMs();
        dots.classList.remove('shake'); void dots.offsetWidth; dots.classList.add('shake');
        msg.textContent = w > 0 ? `Too many tries. Wait ${Math.ceil(w / 1000)}s.` : 'Wrong PIN';
        entered = '';
        redraw();
        buzz(80);
      }
    };
    const forgot = el('button', 'lock-forgot', 'Forgot PIN?');
    forgot.addEventListener('click', async () => {
      const cfg = await getLockConfig();
      if (!cfg.recoveryHash) { msg.textContent = 'No recovery question was set. Reinstall clears the app (restore from your backup).'; return; }
      const ans = window.prompt(cfg.recoveryQ || 'Recovery answer');
      if (ans && await verifyRecovery(ans)) {
        await removePin(); clearFails();
        lockEl.classList.add('lock--out');
        setTimeout(() => { lockEl?.remove(); lockEl = null; resolve(); }, 250);
        window.alert('PIN removed. Set a new one in Settings.');
      } else if (ans !== null) { msg.textContent = 'That answer does not match.'; }
    });
    const unlockNow = () => { lockEl.classList.add('lock--out'); setTimeout(() => { lockEl?.remove(); lockEl = null; resolve(); }, 250); };
    const bio = biometricAvailable() ? el('button', 'lock-forgot', '👆 Use fingerprint') : null;
    if (bio) bio.addEventListener('click', async () => { if (await biometricUnlock()) { clearFails(); unlockNow(); } });
    const pad = el('div', 'lock-pad');
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', '✓'].forEach((k) => {
      const b = el('button', 'lock-key', k);
      b.addEventListener('click', () => {
        msg.textContent = ' ';
        if (k === '⌫') entered = entered.slice(0, -1);
        else if (k === '✓') return submit();
        else if (entered.length < 8) entered += k;
        redraw();
        if (k !== '⌫' && entered.length === pinLen) submit(); // auto-submit at the PIN's own length
      });
      pad.append(b);
    });
    lockEl = el('div', 'lock', [
      el('div', 'lock-icon', '🔒'),
      el('h2', null, `Welcome back, ${(profile.name || '').split(' ')[0] || 'friend'}`),
      el('p', 'text-dim text-xs', 'Enter your PIN'),
      dots, msg, pad, bio, forgot,
    ]);
    redraw();
    document.body.append(lockEl);
    if (bio) setTimeout(() => bio.click(), 350);
  });
}

let hiddenAt = 0;
let coverEl = null;
function showCover() { if (!coverEl) { coverEl = el('div', 'privacy-cover', el('div', 'lock-icon', '🔒')); document.body.append(coverEl); } }
function hideCover() { coverEl?.remove(); coverEl = null; }

/** Covers the app in the recent-apps view; locks again after your chosen time away. The page is never reloaded. */
export function initIdleLock() {
  document.addEventListener('visibilitychange', async () => {
    if (document.hidden) {
      hiddenAt = Date.now();
      if (await hasPin()) showCover();
      return;
    }
    const away = hiddenAt ? Date.now() - hiddenAt : 0;
    const { timeoutSec } = await getLockConfig();
    const mustLock = hiddenAt && timeoutSec >= 0 && away >= timeoutSec * 1000 && await hasPin();
    if (mustLock) { const done = showLockIfNeeded(); hideCover(); await done; } else hideCover();
  });
}
