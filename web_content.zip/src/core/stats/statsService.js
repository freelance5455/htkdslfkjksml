/**
 * statsService.js — read-only statistics shared by Home, Progress and Weekly Review.
 * Pure reads over existing stores. Nothing here writes data.
 */
import { getAll } from '../storage/storageService.js';
import { lastNDates, addDaysISO, startOfWeekISO, todayISO } from '../utils/dateUtils.js';
import { PRAYERS } from '../prayer/prayerService.js';

const sum = (a) => a.reduce((x, y) => x + (Number(y) || 0), 0);
const avg = (a) => (a.length ? sum(a) / a.length : null);
const r1 = (x) => Math.round(x * 10) / 10;

/** Stats for the 7 days starting at `startISO` (Sunday-based weeks). */
export async function statsForWeek(startISO) {
  const days = Array.from({ length: 7 }, (_, i) => addDaysISO(startISO, i));
  const inWeek = (d) => days.includes(d);
  const [habits, habitLogs, sessions, anki, workouts, nutrition, conf, skin, dayLogs, routines, cards] = await Promise.all([
    getAll('habits'), getAll('habitLogs'), getAll('studySessions'), getAll('ankiLogs'), getAll('workoutLogs'),
    getAll('nutritionLogs'), getAll('confidenceLogs'), getAll('skincareLogs'), getAll('dayLogs'), getAll('routines'), getAll('flashcards'),
  ]);
  const dailyHabits = habits.filter((h) => h.frequency === 'daily');
  const habitTicks = habitLogs.filter((l) => inWeek(l.date) && l.completed).length;
  const habitPossible = Math.max(1, dailyHabits.length * 7);
  const studyMin = sum(sessions.filter((s) => inWeek(s.date)).map((s) => s.durationMin));
  const prayerDays = dayLogs.filter((d) => inWeek(d.date));
  const prayers = sum(prayerDays.map((d) => PRAYERS.filter((p) => d.prayers?.[p]).length));
  const water = nutrition.filter((n) => inWeek(n.date)).map((n) => n.waterMl || 0);
  const skinDays = new Set(skin.filter((s) => inWeek(s.date) && s.steps?.some((x) => x.done)).map((s) => s.date));
  const cardsReviewed = sum(anki.filter((a) => inWeek(a.date)).map((a) => a.cardsReviewed));
  const ratings = conf.filter((c) => inWeek(c.date) && c.rating).map((c) => c.rating);
  return {
    start: startISO,
    habitTicks, habitPossible, habitPct: Math.round((habitTicks / habitPossible) * 100),
    studyHours: r1(studyMin / 60), studyMin,
    studyDays: new Set(sessions.filter((s) => inWeek(s.date)).map((s) => s.date)).size,
    ankiCards: cardsReviewed,
    ankiDays: new Set(anki.filter((a) => inWeek(a.date)).map((a) => a.date)).size,
    workouts: new Set(workouts.filter((w) => inWeek(w.date) && w.completed).map((w) => w.date)).size,
    waterAvgL: water.length ? r1(avg(water) / 1000) : null,
    skinDays: skinDays.size,
    confidenceLogs: conf.filter((c) => inWeek(c.date)).length,
    confidenceAvg: ratings.length ? r1(avg(ratings)) : null,
    prayers, prayerPct: Math.round((prayers / 35) * 100),
    fastsKept: prayerDays.filter((d) => d.fasted).length,
    routinesDone: routines.filter((r) => inWeek(r.date) && r.steps?.every((s) => s.done)).length,
    cardsDue: cards.filter((c) => c.dueDate <= todayISO()).length,
  };
}

export async function thisAndLastWeek() {
  const thisStart = startOfWeekISO();
  const [cur, prev] = await Promise.all([statsForWeek(thisStart), statsForWeek(addDaysISO(thisStart, -7))]);
  return { cur, prev };
}

export function delta(cur, prev) {
  if (prev == null || cur == null) return null;
  if (prev === 0) return cur > 0 ? 100 : 0;
  return Math.round(((cur - prev) / prev) * 100);
}

/** Per-day series for any store field, over N days (for the range charts). */
export async function dailySeries(days, kind) {
  const dates = lastNDates(days);
  const by = (rows, f) => { const m = new Map(dates.map((d) => [d, 0])); rows.forEach((r) => { if (m.has(r.date)) m.set(r.date, m.get(r.date) + f(r)); }); return dates.map((d) => ({ date: d, value: m.get(d) })); };
  if (kind === 'anki') return by(await getAll('ankiLogs'), (r) => r.cardsReviewed || 0);
  if (kind === 'workouts') return by((await getAll('workoutLogs')).filter((w) => w.completed), () => 1);
  if (kind === 'water') return by(await getAll('nutritionLogs'), (r) => Math.round(((r.waterMl || 0) / 100)) / 10);
  if (kind === 'prayers') return by(await getAll('dayLogs'), (r) => PRAYERS.filter((p) => r.prayers?.[p]).length);
  if (kind === 'confidence') {
    const logs = (await getAll('confidenceLogs')).filter((c) => c.rating);
    const m = new Map(logs.map((c) => [c.date, c.rating]));
    return dates.map((d) => ({ date: d, value: m.get(d) || 0 }));
  }
  return dates.map((d) => ({ date: d, value: 0 }));
}

/** Study minutes per subject over N days → sorted [subject, minutes]. */
export async function studyBySubject(days) {
  const dates = lastNDates(days);
  const map = new Map();
  (await getAll('studySessions')).filter((s) => dates.includes(s.date)).forEach((s) => map.set(s.subject, (map.get(s.subject) || 0) + (s.durationMin || 0)));
  return [...map.entries()].sort((a, b) => b[1] - a[1]);
}

/** Totals + best day for the Progress page. */
export async function lifetimeStats() {
  const [sessions, anki, workouts, habitLogs, dayLogs] = await Promise.all([
    getAll('studySessions'), getAll('ankiLogs'), getAll('workoutLogs'), getAll('habitLogs'), getAll('dayLogs'),
  ]);
  const perDay = new Map();
  sessions.forEach((s) => perDay.set(s.date, (perDay.get(s.date) || 0) + (s.durationMin || 0)));
  const best = [...perDay.entries()].sort((a, b) => b[1] - a[1])[0];
  return {
    studyHours: r1(sum(sessions.map((s) => s.durationMin)) / 60),
    ankiCards: sum(anki.map((a) => a.cardsReviewed)),
    workouts: workouts.filter((w) => w.completed).length,
    habitTicks: habitLogs.filter((l) => l.completed).length,
    prayers: sum(dayLogs.map((d) => PRAYERS.filter((p) => d.prayers?.[p]).length)),
    bestStudyDay: best ? { date: best[0], hours: r1(best[1] / 60) } : null,
  };
}
