import { useEffect, useState } from "react";
import { ArrowUp, ArrowRight, MonitorPlay, Sparkles } from "lucide-react";
import Nav from "../components/Nav";
import Hero from "../components/Hero";
import Showcase from "../components/Showcase";
import Bento from "../components/Bento";
import Benefits from "../components/Benefits";
import Testimonials from "../components/Testimonials";
import Pricing from "../components/Pricing";
import Faq from "../components/Faq";
import Footer from "../components/Footer";

export default function Landing({ onOpenApp }: { onOpenApp: () => void }) {
  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 520);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen bg-abyss font-sans text-slate-100">
      <Nav onOpenApp={onOpenApp} />
      <main>
        <Hero />
        <Showcase />
        <Bento />
        <Benefits />
        <Testimonials />
        <Pricing />
        <Faq />

        {/* ── launch panel (antes: formulario de descarga) ── */}
        <section id="descargar" className="scroll-mt-28 mx-auto max-w-7xl px-4 pb-20 pt-4 sm:px-6">
          <div className="relative overflow-hidden rounded-3xl border border-electric/30 shadow-[0_40px_120px_-30px_rgba(47,123,255,0.45)]">
            <img src="/img/hero-art.jpg" alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover object-[62%_center]" />
            <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-r from-[#04061a]/95 via-[#04061a]/80 to-[#04061a]/15" />
            <div className="relative max-w-lg p-6 sm:p-12">
              <p className="eyebrow">Ya la tienes</p>
              <h2 className="mt-3 font-display text-4xl font-bold leading-[1.05] text-white sm:text-6xl">La app,<br /><span className="grad-text">no el APK.</span></h2>
              <p className="mt-4 max-w-md text-base leading-relaxed text-slate-200">
                Acabas de leer la teoría. La práctica está a un toque: World TV con streams en vivo, marcadores de ESPN,
                Deezer, radio real, Wikidata, búsqueda global y hasta un juego jugable dentro de la propia app.
              </p>
              <button onClick={onOpenApp} className="grad-btn mt-7 inline-flex h-14 items-center gap-3 rounded-2xl px-7 text-lg font-black text-white">
                <MonitorPlay size={22} /> Abrir TV LO3 ahora <ArrowRight size={19} strokeWidth={2.5} />
              </button>
              <p className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-500">
                <span className="flex items-center gap-1.5"><Sparkles size={11} className="text-cyanx" />Sin registro</span>
                <span className="flex items-center gap-1.5"><Sparkles size={11} className="text-cyanx" />Datos reales en vivo</span>
                <span className="flex items-center gap-1.5"><Sparkles size={11} className="text-cyanx" />Tus datos no salen de aquí</span>
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />

      {/* floating open-app pill */}
      <button onClick={onOpenApp} className="grad-btn fixed bottom-5 left-1/2 z-50 flex h-13 -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-2xl px-6 py-3 text-sm font-black text-white" aria-label="Abrir la aplicación TV LO3">
        <MonitorPlay size={18} /> Abrir TV LO3 <ArrowRight size={16} strokeWidth={2.5} />
      </button>
      <button
        type="button"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        aria-label="Volver arriba"
        className={`fixed bottom-5 right-5 z-40 flex h-12 w-12 items-center justify-center rounded-2xl border border-cyanx/40 bg-[#071231]/90 text-cyanx backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:text-white ${showTop ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"}`}
      >
        <ArrowUp size={20} strokeWidth={2.5} />
      </button>
    </div>
  );
}
