import { create } from "zustand";
import {
  DEFAULT_SLOTS,
  newSlotId,
  resolveProgression,
  slotsFromNumerals,
  type ChordSlot,
  type InstrumentId,
  type ResolvedChord,
  type ScaleId,
} from "@/lib/harmony";
import { PRESETS } from "@/lib/harmony";
import type { PatternId } from "@/lib/patterns";

const STORAGE_KEY = "cadence-player-v1";

export type PlayerState = {
  hydrated: boolean;
  keyPc: number;
  scale: ScaleId;
  slots: ChordSlot[];
  sevenths: boolean;
  instrument: InstrumentId;
  pattern: PatternId;
  bpm: number;
  loop: boolean;
  volume: number;
  metronome: boolean;
  playing: boolean;
  activeIndex: number;
  selectedIndex: number;
  playGen: number;
  hydrate: () => void;
  persistable: () => Record<string, unknown>;
  resolved: () => ResolvedChord[];
  setKey: (pc: number) => void;
  setScale: (scale: ScaleId) => void;
  setPattern: (pattern: PatternId) => void;
  setInstrument: (instrument: InstrumentId) => void;
  setBpm: (bpm: number) => void;
  setVolume: (volume: number) => void;
  setLoop: (loop: boolean) => void;
  setMetronome: (on: boolean) => void;
  setSevenths: (on: boolean) => void;
  setPlaying: (playing: boolean) => void;
  setActiveIndex: (index: number) => void;
  selectIndex: (index: number) => void;
  advanceTo: (index: number) => void;
  bumpPlay: () => void;
  applyPreset: (id: string) => void;
  addChord: (numeral: string) => void;
  setSlotNumeral: (index: number, numeral: string) => void;
  setSlotBeats: (index: number, beats: number) => void;
  removeSlot: (index: number) => void;
  moveSlot: (from: number, to: number) => void;
  duplicateSlot: (index: number) => void;
  setDefaultBeats: (beats: number) => void;
};

type Persisted = {
  keyPc: number;
  scale: ScaleId;
  slots: ChordSlot[];
  sevenths: boolean;
  instrument: InstrumentId;
  pattern: PatternId;
  bpm: number;
  loop: boolean;
  volume: number;
  metronome: boolean;
};

function persist(state: PlayerState) {
  if (typeof window === "undefined" || !state.hydrated) return;
  const data: Persisted = {
    keyPc: state.keyPc,
    scale: state.scale,
    slots: state.slots,
    sevenths: state.sevenths,
    instrument: state.instrument,
    pattern: state.pattern,
    bpm: state.bpm,
    loop: state.loop,
    volume: state.volume,
    metronome: state.metronome,
  };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    /* ignore quota */
  }
}

export const usePlayerStore = create<PlayerState>((set, get) => ({
  hydrated: false,
  keyPc: 0,
  scale: "major",
  slots: DEFAULT_SLOTS,
  sevenths: false,
  instrument: "keys",
  pattern: "strum",
  bpm: 96,
  loop: true,
  volume: 0.72,
  metronome: false,
  playing: false,
  activeIndex: 0,
  selectedIndex: 0,
  playGen: 0,
  hydrate: () => {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw) as Partial<Persisted>;
        set({
          keyPc: typeof data.keyPc === "number" ? data.keyPc : 0,
          scale: data.scale ?? "major",
          slots: Array.isArray(data.slots) && data.slots.length > 0 ? data.slots : DEFAULT_SLOTS,
          sevenths: Boolean(data.sevenths),
          instrument: data.instrument === "nylon" ? "nylon" : "keys",
          pattern: data.pattern ?? "strum",
          bpm: typeof data.bpm === "number" ? Math.min(180, Math.max(60, data.bpm)) : 96,
          loop: data.loop !== false,
          volume: typeof data.volume === "number" ? data.volume : 0.72,
          metronome: Boolean(data.metronome),
          hydrated: true,
        });
        return;
      }
    } catch {
      /* ignore */
    }
    set({ hydrated: true });
  },
  persistable: () => {
    const s = get();
    return {
      keyPc: s.keyPc,
      scale: s.scale,
      slots: s.slots,
      sevenths: s.sevenths,
      instrument: s.instrument,
      pattern: s.pattern,
      bpm: s.bpm,
      loop: s.loop,
      volume: s.volume,
      metronome: s.metronome,
    };
  },
  resolved: () => {
    const s = get();
    return resolveProgression(s.slots, s.keyPc, s.scale, s.sevenths, s.instrument);
  },
  setKey: (pc) => set({ keyPc: pc }),
  setScale: (scale) => set({ scale }),
  setPattern: (pattern) => set({ pattern }),
  setInstrument: (instrument) => set({ instrument }),
  setBpm: (bpm) => set({ bpm: Math.min(180, Math.max(60, Math.round(bpm))) }),
  setVolume: (volume) => set({ volume: Math.min(1, Math.max(0, volume)) }),
  setLoop: (loop) => set({ loop }),
  setMetronome: (metronome) => set({ metronome }),
  setSevenths: (sevenths) => set({ sevenths }),
  setPlaying: (playing) => set({ playing, playGen: playing ? get().playGen + 1 : get().playGen }),
  setActiveIndex: (index) => set({ activeIndex: index }),
  selectIndex: (index) => set({ selectedIndex: index }),
  advanceTo: (index) => set({ activeIndex: index, playGen: get().playGen + 1 }),
  bumpPlay: () => set({ playGen: get().playGen + 1 }),
  applyPreset: (id) => {
    const preset = PRESETS.find((p) => p.id === id);
    if (!preset) return;
    set({
      scale: preset.scale,
      slots: slotsFromNumerals(preset.numerals, 4),
      selectedIndex: 0,
      activeIndex: 0,
    });
  },
  addChord: (numeral) => {
    const s = get();
    const beats = s.slots[s.selectedIndex]?.beats ?? 4;
    const next = [...s.slots, { id: newSlotId(), numeral, beats }];
    set({ slots: next, selectedIndex: next.length - 1 });
  },
  setSlotNumeral: (index, numeral) => {
    const slots = get().slots.map((slot, i) => (i === index ? { ...slot, numeral } : slot));
    set({ slots });
  },
  setSlotBeats: (index, beats) => {
    const slots = get().slots.map((slot, i) => (i === index ? { ...slot, beats } : slot));
    set({ slots });
  },
  removeSlot: (index) => {
    const slots = get().slots.filter((_, i) => i !== index);
    if (slots.length === 0) {
      set({
        slots: [{ id: newSlotId(), numeral: "I", beats: 4 }],
        selectedIndex: 0,
        activeIndex: 0,
      });
      return;
    }
    const selectedIndex = Math.min(get().selectedIndex, slots.length - 1);
    const activeIndex = Math.min(get().activeIndex, slots.length - 1);
    set({ slots, selectedIndex, activeIndex });
  },
  moveSlot: (from, to) => {
    const slots = [...get().slots];
    if (from < 0 || to < 0 || from >= slots.length || to >= slots.length) return;
    const [item] = slots.splice(from, 1);
    slots.splice(to, 0, item);
    set({ slots, selectedIndex: to });
  },
  duplicateSlot: (index) => {
    const slots = [...get().slots];
    const src = slots[index];
    if (!src) return;
    slots.splice(index + 1, 0, { ...src, id: newSlotId() });
    set({ slots, selectedIndex: index + 1 });
  },
  setDefaultBeats: (beats) => {
    set({ slots: get().slots.map((s) => ({ ...s, beats })) });
  },
}));

if (typeof window !== "undefined") {
  let last = "";
  usePlayerStore.subscribe((state) => {
    const next = JSON.stringify(state.persistable());
    if (next === last) return;
    last = next;
    persist(state);
  });
}
