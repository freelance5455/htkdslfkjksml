import { create } from "zustand";
import { CATALOG, CATALOG_BY_SLUG, type CatalogStar } from "@/data/catalog";
import {
  deleteMedia,
  deleteProfile,
  getQuota,
  listMedia,
  listProfiles,
  moveMedia,
  putMedia,
  putProfile,
  requestPersist,
  type MediaKind,
  type MediaRecord,
  type ProfileRecord,
} from "@/lib/idb";
import { catalogMatch } from "@/lib/match";
import { kindFromFile, slugify, uid } from "@/lib/utils";
import { thumbFromImage, thumbFromVideo } from "@/lib/thumbs";

export const INBOX_SLUG = "_inbox";

export type MediaMeta = Omit<MediaRecord, "blob" | "thumb"> & { hasThumb: boolean };

export type VaultStar = CatalogStar & {
  favorite: boolean;
  addedByUser: boolean;
  customPhotoUrl?: string;
  counts: { video: number; photo: number; gif: number; total: number };
};

type VaultState = {
  ready: boolean;
  error: string | null;
  media: MediaMeta[];
  profiles: Record<string, ProfileRecord>;
  photoUrls: Record<string, string>;
  quota: { usage: number; quota: number } | null;
  hydrate: () => Promise<void>;
  refreshQuota: () => Promise<void>;
  importFiles: (files: File[], defaultSlug?: string) => Promise<{ filed: number; inbox: number; failed: number }>;
  setStarPhoto: (slug: string, file: File) => Promise<void>;
  clearStarPhoto: (slug: string) => Promise<void>;
  toggleFavorite: (slug: string) => Promise<void>;
  addStar: (name: string, photo?: File) => Promise<string>;
  removeUserStar: (slug: string) => Promise<void>;
  assignMedia: (id: string, slug: string) => Promise<void>;
  removeMedia: (id: string) => Promise<void>;
  getBlob: (id: string) => Promise<{ blob: Blob; thumb?: Blob; rec: MediaMeta } | null>;
};

const photoUrls: Record<string, string> = {};

function revoke(url?: string) {
  if (url) URL.revokeObjectURL(url);
}

function metaOf(rec: MediaRecord): MediaMeta {
  const { blob: _b, thumb, ...rest } = rec;
  return { ...rest, hasThumb: Boolean(thumb) };
}

export const useVault = create<VaultState>((set, get) => ({
  ready: false,
  error: null,
  media: [],
  profiles: {},
  photoUrls: {},
  quota: null,

  hydrate: async () => {
    try {
      const [media, profiles] = await Promise.all([listMedia(), listProfiles()]);
      for (const p of profiles) {
        if (p.customPhoto) {
          revoke(photoUrls[p.slug]);
          photoUrls[p.slug] = URL.createObjectURL(p.customPhoto);
        }
      }
      const quota = await getQuota();
      set({
        ready: true,
        media: media.map(metaOf),
        profiles: Object.fromEntries(profiles.map((p) => [p.slug, p])),
        photoUrls: { ...photoUrls },
        quota,
        error: null,
      });
      void requestPersist();
    } catch (err) {
      set({
        ready: true,
        error: err instanceof Error ? err.message : "Could not open library storage",
      });
    }
  },

  refreshQuota: async () => {
    set({ quota: await getQuota() });
  },

  importFiles: async (files, defaultSlug) => {
    const extras = Object.values(get().profiles)
      .filter((p) => p.addedByUser && p.name)
      .map((p) => ({ slug: p.slug, name: p.name!, photo: null, wiki: p.name! }));
    let filed = 0;
    let inbox = 0;
    let failed = 0;
    for (const file of files) {
      try {
        const kind = kindFromFile(file);
        let slug = defaultSlug;
        if (!slug) {
          const hits = catalogMatch(file.name, extras);
          slug = hits[0] ?? INBOX_SLUG;
        }
        const thumb =
          kind === "video" ? await thumbFromVideo(file) : await thumbFromImage(file);
        const rec: MediaRecord = {
          id: uid(),
          starSlug: slug,
          kind,
          name: file.name,
          mime: file.type || "application/octet-stream",
          size: file.size,
          createdAt: Date.now(),
          blob: file,
          thumb,
        };
        await putMedia(rec);
        set((s) => ({ media: [metaOf(rec), ...s.media] }));
        if (slug === INBOX_SLUG) inbox += 1;
        else filed += 1;
      } catch {
        failed += 1;
      }
    }
    await get().refreshQuota();
    return { filed, inbox, failed };
  },

  setStarPhoto: async (slug, file) => {
    const blob = file;
    const existing = get().profiles[slug];
    const rec: ProfileRecord = { ...existing, slug, customPhoto: blob };
    await putProfile(rec);
    revoke(photoUrls[slug]);
    photoUrls[slug] = URL.createObjectURL(blob);
    set((s) => ({
      profiles: { ...s.profiles, [slug]: rec },
      photoUrls: { ...photoUrls },
    }));
    await get().refreshQuota();
  },

  clearStarPhoto: async (slug) => {
    const existing = get().profiles[slug];
    if (!existing) return;
    const rec = { ...existing, customPhoto: undefined };
    await putProfile(rec);
    revoke(photoUrls[slug]);
    delete photoUrls[slug];
    set((s) => ({
      profiles: { ...s.profiles, [slug]: rec },
      photoUrls: { ...photoUrls },
    }));
  },

  toggleFavorite: async (slug) => {
    const existing = get().profiles[slug] ?? { slug };
    const rec = { ...existing, favorite: !existing.favorite };
    await putProfile(rec);
    set((s) => ({ profiles: { ...s.profiles, [slug]: rec } }));
  },

  addStar: async (name, photo) => {
    const base = slugify(name);
    let slug = base;
    let n = 2;
    while (CATALOG_BY_SLUG.has(slug) || get().profiles[slug]?.addedByUser) {
      slug = `${base}-${n}`;
      n += 1;
    }
    const rec: ProfileRecord = {
      slug,
      name: name.trim(),
      addedByUser: true,
      customPhoto: photo,
    };
    await putProfile(rec);
    if (photo) {
      revoke(photoUrls[slug]);
      photoUrls[slug] = URL.createObjectURL(photo);
    }
    set((s) => ({
      profiles: { ...s.profiles, [slug]: rec },
      photoUrls: { ...photoUrls },
    }));
    return slug;
  },

  removeUserStar: async (slug) => {
    const media = get().media.filter((m) => m.starSlug === slug);
    for (const m of media) await deleteMedia(m.id);
    await deleteProfile(slug);
    revoke(photoUrls[slug]);
    delete photoUrls[slug];
    set((s) => {
      const profiles = { ...s.profiles };
      delete profiles[slug];
      return {
        profiles,
        photoUrls: { ...photoUrls },
        media: s.media.filter((m) => m.starSlug !== slug),
      };
    });
  },

  assignMedia: async (id, slug) => {
    await moveMedia(id, slug);
    set((s) => ({
      media: s.media.map((m) => (m.id === id ? { ...m, starSlug: slug } : m)),
    }));
  },

  removeMedia: async (id) => {
    await deleteMedia(id);
    set((s) => ({ media: s.media.filter((m) => m.id !== id) }));
    await get().refreshQuota();
  },

  getBlob: async (id) => {
    const { getMedia } = await import("@/lib/idb");
    const rec = await getMedia(id);
    if (!rec) return null;
    return { blob: rec.blob, thumb: rec.thumb, rec: metaOf(rec) };
  },
}));

export function useStars(): VaultStar[] {
  const profiles = useVault((s) => s.profiles);
  const photoUrlsMap = useVault((s) => s.photoUrls);
  const media = useVault((s) => s.media);

  const counts = new Map<string, VaultStar["counts"]>();
  for (const m of media) {
    if (m.starSlug === INBOX_SLUG) continue;
    const cur = counts.get(m.starSlug) ?? { video: 0, photo: 0, gif: 0, total: 0 };
    cur[m.kind] += 1;
    cur.total += 1;
    counts.set(m.starSlug, cur);
  }

  const userStars: VaultStar[] = Object.values(profiles)
    .filter((p) => p.addedByUser && p.name && !CATALOG_BY_SLUG.has(p.slug))
    .map((p) => ({
      slug: p.slug,
      name: p.name!,
      photo: null,
      wiki: p.name!,
      favorite: Boolean(p.favorite),
      addedByUser: true,
      customPhotoUrl: photoUrlsMap[p.slug],
      counts: counts.get(p.slug) ?? { video: 0, photo: 0, gif: 0, total: 0 },
    }));

  const built: VaultStar[] = CATALOG.map((s) => {
    const p = profiles[s.slug];
    return {
      ...s,
      favorite: Boolean(p?.favorite),
      addedByUser: false,
      customPhotoUrl: photoUrlsMap[s.slug],
      counts: counts.get(s.slug) ?? { video: 0, photo: 0, gif: 0, total: 0 },
    };
  });

  return [...userStars, ...built].sort((a, b) =>
    a.name.localeCompare(b.name, "en", { sensitivity: "base" }),
  );
}

export function useStar(slug: string): VaultStar | undefined {
  return useStars().find((s) => s.slug === slug);
}

export function useStarMedia(slug: string) {
  return useVault((s) => s.media.filter((m) => m.starSlug === slug));
}

export function useInboxCount() {
  return useVault((s) => s.media.filter((m) => m.starSlug === INBOX_SLUG).length);
}
