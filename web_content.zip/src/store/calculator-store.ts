import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  canClearEntry,
  initialEngine,
  memoryActive,
  reduce,
  type EngineAction,
  type EngineState,
} from "@/lib/calculator/engine";
import {
  applyBitOp,
  applyIntOp,
  bitNot,
  formatProgEntry,
  isDigitForBase,
  parseBase,
  toggleBit,
  wrapBits,
  type IntOp,
} from "@/lib/calculator/programmer";
import { convertValue, CATEGORIES, type UnitCategoryId } from "@/lib/calculator/units";
import type { BitOp, Mode, NumberBase, Theme, WordSize } from "@/lib/calculator/types";

export type Panel = "none" | "history" | "more";

export type ProgState = {
  value: string;
  entry: string;
  entering: boolean;
  overwrite: boolean;
  pendingOp: BitOp | IntOp | null;
  pendingValue: string | null;
  base: NumberBase;
  wordSize: WordSize;
  signed: boolean;
};

const initialProg = (): ProgState => ({
  value: "0",
  entry: "0",
  entering: false,
  overwrite: true,
  pendingOp: null,
  pendingValue: null,
  base: 10,
  wordSize: 64,
  signed: true,
});

export type ConvertState = {
  category: UnitCategoryId;
  fromId: string;
  toId: string;
  input: string;
};

const initialConvert = (): ConvertState => ({
  category: "length",
  fromId: "m",
  toId: "ft",
  input: "1",
});

type CalcStore = EngineState & {
  mode: Mode;
  theme: Theme;
  panel: Panel;
  prog: ProgState;
  convert: ConvertState;
  dispatch: (action: EngineAction) => void;
  setMode: (mode: Mode) => void;
  setTheme: (theme: Theme) => void;
  setPanel: (panel: Panel) => void;
  progDigit: (d: string) => void;
  progOp: (op: BitOp | IntOp) => void;
  progNot: () => void;
  progEquals: () => void;
  progClear: () => void;
  progBackspace: () => void;
  progSign: () => void;
  setBase: (base: NumberBase) => void;
  setWordSize: (size: WordSize) => void;
  toggleSigned: () => void;
  flipBit: (index: number) => void;
  setCategory: (id: UnitCategoryId) => void;
  setFromUnit: (id: string) => void;
  setToUnit: (id: string) => void;
  swapUnits: () => void;
  convertDigit: (d: string) => void;
  convertDot: () => void;
  convertBackspace: () => void;
  convertClear: () => void;
  convertSign: () => void;
  hasMemory: () => boolean;
  clearLabel: () => "C" | "AC";
};

function asBig(s: string): bigint {
  try {
    return BigInt(s);
  } catch {
    return 0n;
  }
}

function paintProg(p: ProgState, value: bigint): ProgState {
  const wrapped = wrapBits(value, p.wordSize);
  const entry = formatProgEntry(wrapped, p.base, p.wordSize, p.signed);
  return { ...p, value: wrapped.toString(), entry, overwrite: true, entering: false };
}

export const useCalc = create<CalcStore>()(
  persist(
    (set, get) => ({
      ...initialEngine(),
      mode: "basic",
      theme: "amoled",
      panel: "none",
      prog: initialProg(),
      convert: initialConvert(),

      dispatch: (action) => {
        const s = get();
        const next = reduce(s, action, s.mode === "basic");
        set(next);
      },

      setMode: (mode) => {
        const s = get();
        if (mode === "programmer" && s.mode !== "programmer") {
          const n = Number(s.entry);
          const v = Number.isFinite(n) ? BigInt(Math.trunc(n)) : 0n;
          set({ mode, panel: "none", prog: paintProg({ ...s.prog }, v) });
          return;
        }
        set({ mode, panel: "none" });
      },
      setTheme: (theme) => set({ theme }),
      setPanel: (panel) => set({ panel }),

      progDigit: (d) => {
        const p = get().prog;
        if (!isDigitForBase(d, p.base)) return;
        if (p.overwrite || !p.entering) {
          const entry = d;
          set({ prog: { ...p, entry, entering: true, overwrite: false, value: parseBase(entry, p.base).toString() } });
          return;
        }
        const raw = p.entry.replace(/\s+/g, "");
        if (raw.replace("-", "").length >= 64) return;
        const entry = (raw === "0" ? d : raw + d);
        set({ prog: { ...p, entry, value: parseBase(entry, p.base).toString() } });
      },
      progOp: (op) => {
        const p = get().prog;
        const value = wrapBits(asBig(p.value), p.wordSize);
        set({
          prog: {
            ...p,
            pendingOp: op,
            pendingValue: value.toString(),
            overwrite: true,
            entering: false,
          },
        });
      },
      progNot: () => {
        const p = get().prog;
        set({ prog: paintProg(p, bitNot(asBig(p.value), p.wordSize)) });
      },
      progEquals: () => {
        const p = get().prog;
        if (!p.pendingOp || p.pendingValue === null) return;
        const a = asBig(p.pendingValue);
        const b = asBig(p.value);
        const intOps: IntOp[] = ["iadd", "isub", "imul", "idiv"];
        const result = intOps.includes(p.pendingOp as IntOp)
          ? applyIntOp(p.pendingOp as IntOp, a, b, p.wordSize)
          : applyBitOp(p.pendingOp as BitOp, a, b, p.wordSize);
        set({
          prog: {
            ...paintProg(p, result),
            pendingOp: p.pendingOp,
            pendingValue: p.value,
          },
        });
      },
      progClear: () => set({ prog: { ...get().prog, ...initialProg(), base: get().prog.base, wordSize: get().prog.wordSize, signed: get().prog.signed } }),
      progBackspace: () => {
        const p = get().prog;
        if (p.overwrite || !p.entering) return;
        const raw = p.entry.replace(/\s+/g, "");
        const next = raw.slice(0, -1) || "0";
        set({
          prog: {
            ...p,
            entry: next,
            value: parseBase(next, p.base).toString(),
            entering: next !== "0",
            overwrite: next === "0",
          },
        });
      },
      progSign: () => {
        const p = get().prog;
        set({ prog: paintProg(p, -asBig(p.value)) });
      },
      setBase: (base) => {
        const p = get().prog;
        set({ prog: paintProg({ ...p, base }, asBig(p.value)) });
      },
      setWordSize: (wordSize) => {
        const p = get().prog;
        set({ prog: paintProg({ ...p, wordSize }, asBig(p.value)) });
      },
      toggleSigned: () => {
        const p = get().prog;
        set({ prog: paintProg({ ...p, signed: !p.signed }, asBig(p.value)) });
      },
      flipBit: (index) => {
        const p = get().prog;
        set({ prog: paintProg(p, toggleBit(asBig(p.value), index, p.wordSize)) });
      },

      setCategory: (category) => {
        const c = get().convert;
        const cat = CATEGORIES.find((x) => x.id === category);
        const fromId = cat?.units[0]?.id ?? "m";
        const toId = cat?.units[1]?.id ?? cat?.units[0]?.id ?? "ft";
        set({ convert: { ...c, category, fromId, toId } });
      },
      setFromUnit: (fromId) => set({ convert: { ...get().convert, fromId } }),
      setToUnit: (toId) => set({ convert: { ...get().convert, toId } }),
      swapUnits: () => {
        const c = get().convert;
        set({ convert: { ...c, fromId: c.toId, toId: c.fromId, input: String(convertValue(Number(c.input) || 0, c.category, c.fromId, c.toId)) } });
      },
      convertDigit: (d) => {
        const c = get().convert;
        const next = c.input === "0" ? d : c.input + d;
        set({ convert: { ...c, input: next } });
      },
      convertDot: () => {
        const c = get().convert;
        if (c.input.includes(".")) return;
        set({ convert: { ...c, input: c.input + "." } });
      },
      convertBackspace: () => {
        const c = get().convert;
        const next = c.input.slice(0, -1) || "0";
        set({ convert: { ...c, input: next } });
      },
      convertClear: () => set({ convert: { ...get().convert, input: "0" } }),
      convertSign: () => {
        const c = get().convert;
        if (c.input.startsWith("-")) set({ convert: { ...c, input: c.input.slice(1) || "0" } });
        else if (c.input !== "0") set({ convert: { ...c, input: `-${c.input}` } });
      },

      hasMemory: () => memoryActive(get()),
      clearLabel: () => (canClearEntry(get()) ? "C" : "AC"),
    }),
    {
      name: "calculator",
      partialize: (s) => ({
        theme: s.theme,
        mode: s.mode,
        angle: s.angle,
        memory: s.memory,
        history: s.history,
        prog: {
          base: s.prog.base,
          wordSize: s.prog.wordSize,
          signed: s.prog.signed,
        },
        convert: {
          category: s.convert.category,
          fromId: s.convert.fromId,
          toId: s.convert.toId,
        },
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<CalcStore>;
        return {
          ...current,
          theme: p.theme ?? current.theme,
          mode: p.mode ?? current.mode,
          angle: p.angle ?? current.angle,
          memory: p.memory ?? current.memory,
          history: p.history ?? current.history,
          prog: { ...current.prog, ...(p.prog ?? {}) },
          convert: { ...current.convert, ...(p.convert ?? {}) },
        };
      },
    },
  ),
);
