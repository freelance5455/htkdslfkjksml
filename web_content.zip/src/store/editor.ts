import { create } from "zustand";
import {
  adjustmentsEqual,
  applyLook,
  centeredCrop,
  cloneAdjustments,
  defaultAdjustments,
  defaultCrop,
  displaySize,
  rotateQuarter,
  withDefaultGeometry,
  type Adjustments,
  type AspectId,
  type Crop,
  type HslKey,
  type Photo,
} from "@/lib/photo/model";
import {
  createSamplePhotos,
  deleteImport,
  saveImport,
  type UserPreset,
} from "@/lib/photo/library";

const HISTORY_LIMIT = 50;

type HistoryEntry = { photoId: string; adjustments: Adjustments };

type Gesture = { photoId: string; adjustments: Adjustments } | null;

type EditorState = {
  photos: Photo[];
  activeId: string;
  userPresets: UserPreset[];
  clipboard: Adjustments | null;
  undoStack: HistoryEntry[];
  redoStack: HistoryEntry[];
  gesture: Gesture;
  compare: "off" | "before" | "split";
  split: number;
  cropMode: boolean;
  clipWarn: boolean;
  holdBefore: boolean;
  zoom: number;
  pan: { x: number; y: number };
  status: string;
  dirty: boolean;
  hydrated: boolean;
  active: () => Photo | undefined;
  setStatus: (status: string) => void;
  hydrate: (photos: Photo[], presets: UserPreset[]) => void;
  setActive: (id: string) => void;
  beginGesture: () => void;
  commitGesture: () => void;
  patch: (partial: Partial<Adjustments>) => void;
  setHsl: (channel: HslKey, key: "h" | "s" | "l", value: number) => void;
  setCrop: (crop: Crop) => void;
  setAspect: (aspect: AspectId) => void;
  rotate: (direction: 1 | -1) => void;
  toggleFlip: () => void;
  applyPreset: (adjustments: Adjustments, geometry?: boolean) => void;
  reset: () => void;
  auto: (partial: Partial<Adjustments>) => void;
  undo: () => void;
  redo: () => void;
  copyLook: () => void;
  pasteLook: () => void;
  addPhotos: (items: { photo: Photo; blob: Blob }[]) => void;
  removePhoto: (id: string) => void;
  restoreSamples: () => void;
  savePreset: (name: string) => void;
  deletePreset: (id: string) => void;
  setCompare: (compare: "off" | "before" | "split") => void;
  setSplit: (split: number) => void;
  setCropMode: (cropMode: boolean) => void;
  setClipWarn: (clipWarn: boolean) => void;
  setHoldBefore: (holdBefore: boolean) => void;
  setView: (zoom: number, pan: { x: number; y: number }) => void;
};

function replacePhoto(photos: Photo[], id: string, adjustments: Adjustments) {
  return photos.map((photo) => (photo.id === id ? { ...photo, adjustments } : photo));
}

function pushHistory(stack: HistoryEntry[], entry: HistoryEntry) {
  const next = [...stack, entry];
  return next.length > HISTORY_LIMIT ? next.slice(next.length - HISTORY_LIMIT) : next;
}

export const useEditor = create<EditorState>((set, get) => ({
  photos: createSamplePhotos(),
  activeId: "alpine",
  userPresets: [],
  clipboard: null,
  undoStack: [],
  redoStack: [],
  gesture: null,
  compare: "off",
  split: 0.5,
  cropMode: false,
  clipWarn: false,
  holdBefore: false,
  zoom: 1,
  pan: { x: 0, y: 0 },
  status: "",
  dirty: false,
  hydrated: false,
  active: () => get().photos.find((photo) => photo.id === get().activeId),
  setStatus: (status) => set({ status }),
  hydrate: (photos, presets) => {
    if (get().hydrated) return;
    set({
      hydrated: true,
      userPresets: presets,
      photos: get().dirty ? get().photos : photos,
      activeId: get().dirty ? get().activeId : (photos[0]?.id ?? get().activeId),
    });
  },
  setActive: (id) => {
    if (id === get().activeId) return;
    get().commitGesture();
    set({ activeId: id, zoom: 1, pan: { x: 0, y: 0 }, cropMode: false });
  },
  beginGesture: () => {
    const photo = get().active();
    if (!photo || get().gesture) return;
    set({
      gesture: { photoId: photo.id, adjustments: cloneAdjustments(photo.adjustments) },
      redoStack: [],
    });
  },
  commitGesture: () => {
    const gesture = get().gesture;
    if (!gesture) return;
    const photo = get().photos.find((item) => item.id === gesture.photoId);
    if (!photo || adjustmentsEqual(photo.adjustments, gesture.adjustments)) {
      set({ gesture: null });
      return;
    }
    set({
      gesture: null,
      dirty: true,
      undoStack: pushHistory(get().undoStack, {
        photoId: gesture.photoId,
        adjustments: gesture.adjustments,
      }),
    });
  },
  patch: (partial) => {
    const photo = get().active();
    if (!photo) return;
    const next = { ...photo.adjustments, ...partial };
    if (partial.crop) next.crop = { ...partial.crop };
    if (partial.hsl) next.hsl = partial.hsl;
    set({
      dirty: true,
      photos: replacePhoto(get().photos, photo.id, next),
    });
  },
  setHsl: (channel, key, value) => {
    const photo = get().active();
    if (!photo) return;
    const hsl = {
      ...photo.adjustments.hsl,
      [channel]: { ...photo.adjustments.hsl[channel], [key]: value },
    };
    get().patch({ hsl });
  },
  setCrop: (crop) => get().patch({ crop }),
  setAspect: (aspect) => {
    const photo = get().active();
    if (!photo) return;
    const size = displaySize(photo.width, photo.height, photo.adjustments, true);
    const crop = centeredCrop(aspect, size.frameW, size.frameH);
    get().applyPreset(
      { ...photo.adjustments, aspect, crop },
      true,
    );
  },
  rotate: (direction) => {
    const photo = get().active();
    if (!photo) return;
    const rotation = rotateQuarter(photo.adjustments.rotation, direction);
    get().applyPreset(
      {
        ...photo.adjustments,
        rotation,
        aspect: "free",
        crop: defaultCrop(),
      },
      true,
    );
  },
  toggleFlip: () => {
    const photo = get().active();
    if (!photo) return;
    get().applyPreset({ ...photo.adjustments, flip: !photo.adjustments.flip }, true);
  },
  applyPreset: (adjustments, geometry = false) => {
    const photo = get().active();
    if (!photo) return;
    get().commitGesture();
    const next = geometry
      ? cloneAdjustments(adjustments)
      : applyLook(photo.adjustments, adjustments, false);
    if (adjustmentsEqual(photo.adjustments, next)) return;
    set({
      dirty: true,
      redoStack: [],
      undoStack: pushHistory(get().undoStack, {
        photoId: photo.id,
        adjustments: cloneAdjustments(photo.adjustments),
      }),
      photos: replacePhoto(get().photos, photo.id, next),
    });
  },
  reset: () => {
    get().applyPreset(defaultAdjustments(), true);
    set({ zoom: 1, pan: { x: 0, y: 0 }, status: "Reset" });
  },
  auto: (partial) => {
    const photo = get().active();
    if (!photo) return;
    get().applyPreset({ ...photo.adjustments, ...partial }, true);
    set({ status: "Auto tone" });
  },
  undo: () => {
    get().commitGesture();
    const stack = get().undoStack;
    const entry = stack[stack.length - 1];
    if (!entry) return;
    const photo = get().photos.find((item) => item.id === entry.photoId);
    if (!photo) {
      set({ undoStack: stack.slice(0, -1) });
      return;
    }
    set({
      dirty: true,
      undoStack: stack.slice(0, -1),
      redoStack: [...get().redoStack, { photoId: photo.id, adjustments: cloneAdjustments(photo.adjustments) }],
      activeId: photo.id,
      cropMode: false,
      photos: replacePhoto(get().photos, photo.id, cloneAdjustments(entry.adjustments)),
    });
  },
  redo: () => {
    get().commitGesture();
    const stack = get().redoStack;
    const entry = stack[stack.length - 1];
    if (!entry) return;
    const photo = get().photos.find((item) => item.id === entry.photoId);
    if (!photo) {
      set({ redoStack: stack.slice(0, -1) });
      return;
    }
    set({
      dirty: true,
      redoStack: stack.slice(0, -1),
      undoStack: pushHistory(get().undoStack, {
        photoId: photo.id,
        adjustments: cloneAdjustments(photo.adjustments),
      }),
      activeId: photo.id,
      photos: replacePhoto(get().photos, photo.id, cloneAdjustments(entry.adjustments)),
    });
  },
  copyLook: () => {
    const photo = get().active();
    if (!photo) return;
    set({ clipboard: cloneAdjustments(photo.adjustments), status: "Settings copied" });
  },
  pasteLook: () => {
    const clip = get().clipboard;
    if (!clip) {
      set({ status: "Nothing copied" });
      return;
    }
    get().applyPreset(clip, true);
    set({ status: "Settings pasted" });
  },
  addPhotos: (items) => {
    if (!items.length) {
      set({ status: "Couldn’t read that image" });
      return;
    }
    set({
      dirty: true,
      photos: [...get().photos, ...items.map((item) => item.photo)],
      activeId: items[0]?.photo.id ?? get().activeId,
      zoom: 1,
      pan: { x: 0, y: 0 },
      cropMode: false,
      status: items.length === 1 ? "Photo added" : `${items.length} photos added`,
    });
    for (const item of items) {
      void saveImport(item.photo, item.blob).catch(() => undefined);
    }
  },
  removePhoto: (id) => {
    const photo = get().photos.find((item) => item.id === id);
    if (!photo) return;
    if (!photo.builtin) {
      URL.revokeObjectURL(photo.src);
      void deleteImport(id);
    }
    const photos = get().photos.filter((item) => item.id !== id);
    const activeId = get().activeId === id ? (photos[0]?.id ?? "") : get().activeId;
    set({
      dirty: true,
      photos,
      activeId,
      undoStack: get().undoStack.filter((entry) => entry.photoId !== id),
      redoStack: get().redoStack.filter((entry) => entry.photoId !== id),
    });
  },
  restoreSamples: () => {
    const existing = new Set(get().photos.map((photo) => photo.id));
    const samples = createSamplePhotos().filter((photo) => !existing.has(photo.id));
    if (!samples.length) return;
    set({
      photos: [...get().photos, ...samples],
      activeId: get().activeId || samples[0]?.id || "",
    });
  },
  savePreset: (name) => {
    const photo = get().active();
    const trimmed = name.trim().slice(0, 32);
    if (!photo || !trimmed) return;
    const preset: UserPreset = {
      id: `preset-${crypto.randomUUID()}`,
      name: trimmed,
      adjustments: withDefaultGeometry(photo.adjustments),
    };
    set({ userPresets: [...get().userPresets, preset], status: "Preset saved" });
  },
  deletePreset: (id) => {
    set({ userPresets: get().userPresets.filter((preset) => preset.id !== id) });
  },
  setCompare: (compare) => set({ compare }),
  setSplit: (split) => set({ split }),
  setCropMode: (cropMode) => set({ cropMode }),
  setClipWarn: (clipWarn) => set({ clipWarn }),
  setHoldBefore: (holdBefore) => set({ holdBefore }),
  setView: (zoom, pan) => set({ zoom, pan }),
}));
