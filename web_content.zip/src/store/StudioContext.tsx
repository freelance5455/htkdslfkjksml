import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import JSZip from "jszip";
import type { ExportSettings, MediaKind, MediaMeta, Project, ProjectSummary, ToastMessage } from "@/types";
import {
  createBlankProject,
  createStarterProject,
  normalizeProject,
  sanitizeFilename,
  uid,
} from "@/data/defaults";
import {
  allProjects,
  deleteMediaRecord,
  getMedia,
  getMediaMany,
  getProject,
  projectSummaries,
  putMedia,
  putProject,
  removeProject,
} from "@/lib/idb";
import {
  downloadBlob,
  errorMessage,
  inspectAudioFile,
  inspectImageFile,
  isAudioName,
  isImageName,
  safeRevoke,
} from "@/lib/media";
import { requiredMediaIds } from "@/lib/preflight";

const ACTIVE_KEY = "quiz-studio-active-project";

interface StudioContextValue {
  project: Project;
  ready: boolean;
  dirty: boolean;
  saving: boolean;
  lastSavedAt: number | null;
  projects: ProjectSummary[];
  mediaUrls: Record<string, string>;
  availableMedia: Set<string>;
  missingMedia: string[];
  updateProject: (updater: (project: Project) => Project) => void;
  addMediaFile: (file: File, kind?: MediaKind) => Promise<MediaMeta>;
  addMediaFromBlob: (blob: Blob, name: string, options?: { kind?: MediaKind; meta?: Partial<MediaMeta> }) => Promise<MediaMeta>;
  removeMedia: (mediaId: string) => Promise<void>;
  saveNow: () => Promise<void>;
  refreshProjects: () => Promise<void>;
  openProject: (id: string) => Promise<void>;
  createProject: (name: string, aspect: ExportSettings["aspect"]) => Promise<void>;
  removeProjectById: (id: string) => Promise<void>;
  exportProjectZip: () => Promise<void>;
  importProjectZip: (file: File) => Promise<void>;
  hydrateMedia: (project: Project, clear?: boolean) => Promise<void>;
  toast: (text: string, kind?: ToastMessage["kind"]) => void;
  toasts: ToastMessage[];
  dismissToast: (id: string) => void;
}

const StudioContext = createContext<StudioContextValue | null>(null);

function quotaMessage(error: unknown): string {
  if (error instanceof DOMException && (error.name === "QuotaExceededError" || error.name === "NS_ERROR_DOM_QUOTA_REACHED")) {
    return "مساحة التخزين المحلي ممتلئة. احذف مشاريعًا قديمة أو ملفات كبيرة ثم أعد المحاولة.";
  }
  return errorMessage(error, "تعذّر حفظ البيانات محليًا.");
}

export function StudioProvider({ children }: { children: ReactNode }) {
  const [project, setProject] = useState<Project>(() => createStarterProject());
  const [ready, setReady] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [mediaUrls, setMediaUrls] = useState<Record<string, string>>({});
  const [availableMedia, setAvailableMedia] = useState<Set<string>>(new Set());
  const [missingMedia, setMissingMedia] = useState<string[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const urlsRef = useRef<Record<string, string>>({});
  const projectRef = useRef(project);
  projectRef.current = project;
  const saveTimer = useRef<number | null>(null);

  const toast = useCallback((text: string, kind: ToastMessage["kind"] = "info") => {
    const item: ToastMessage = { id: uid("toast"), text, kind };
    setToasts((current) => [...current.slice(-3), item]);
    window.setTimeout(() => setToasts((current) => current.filter((entry) => entry.id !== item.id)), 5000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((current) => current.filter((entry) => entry.id !== id));
  }, []);

  const hydrateMedia = useCallback(async (next: Project, clear = false) => {
    const ids = requiredMediaIds(next);
    if (clear) {
      Object.values(urlsRef.current).forEach(safeRevoke);
      urlsRef.current = {};
      setMediaUrls({});
    }
    let records = new Map<string, { blob: Blob; meta: MediaMeta }>();
    try {
      records = await getMediaMany(ids);
    } catch (error) {
      toast(quotaMessage(error), "error");
    }
    const nextUrls: Record<string, string> = { ...urlsRef.current };
    records.forEach((record, id) => {
      if (!nextUrls[id]) {
        try {
          nextUrls[id] = URL.createObjectURL(record.blob);
        } catch {
          /* ignore */
        }
      }
    });
    urlsRef.current = nextUrls;
    setMediaUrls(nextUrls);
    setAvailableMedia(new Set([...records.keys()]));
    setMissingMedia(ids.filter((id) => !records.has(id)));
  }, [toast]);

  const refreshProjects = useCallback(async () => {
    try {
      setProjects(await projectSummaries());
    } catch {
      /* القائمة اختيارية قبل توفر IndexedDB */
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    const boot = async () => {
      let loaded: Project | undefined;
      try {
        const lastId = localStorage.getItem(ACTIVE_KEY);
        if (lastId) loaded = await getProject(lastId);
        if (!loaded) {
          const all = await allProjects();
          loaded = all[0];
        }
      } catch {
        /* استخدم المشروع الافتراضي */
      }
      if (cancelled) return;
      const next = loaded ?? createStarterProject();
      setProject(next);
      setReady(true);
      setLastSavedAt(next.updatedAt);
      localStorage.setItem(ACTIVE_KEY, next.id);
      await hydrateMedia(next, true);
      if (!loaded) {
        try {
          await putProject(next);
        } catch {
          /* التخزين قد يكون معطلًا */
        }
      }
      await refreshProjects();
    };
    void boot();
    return () => {
      cancelled = true;
    };
  }, [hydrateMedia, refreshProjects]);

  const persist = useCallback(async (next: Project, announce = false) => {
    const stamped: Project = { ...next, updatedAt: Date.now() };
    try {
      await putProject(stamped);
      setLastSavedAt(stamped.updatedAt);
      setDirty(false);
      localStorage.setItem(ACTIVE_KEY, stamped.id);
      if (announce) toast("تم حفظ المشروع بنجاح في هذا المتصفح.", "success");
    } catch (error) {
      toast(quotaMessage(error), "error");
      throw error;
    }
  }, [toast]);

  const saveNow = useCallback(async () => {
    if (saving) return;
    setSaving(true);
    try {
      await persist(projectRef.current, true);
      await refreshProjects();
    } catch {
      /* تُعرض الرسالة من persist */
    } finally {
      setSaving(false);
    }
  }, [persist, refreshProjects, saving]);

  const updateProject = useCallback((updater: (current: Project) => Project) => {
    setDirty(true);
    setProject((current) => updater(current));
  }, []);

  useEffect(() => {
    if (!ready) return;
    if (!dirty) return;
    if (saveTimer.current) window.clearTimeout(saveTimer.current);
    saveTimer.current = window.setTimeout(() => {
      setSaving(true);
      persist(projectRef.current)
        .catch(() => undefined)
        .finally(() => setSaving(false));
    }, 1100);
    return () => {
      if (saveTimer.current) window.clearTimeout(saveTimer.current);
    };
  }, [project, dirty, ready, persist]);

  useEffect(() => {
    const handler = (event: BeforeUnloadEvent) => {
      if (dirty) {
        event.preventDefault();
        event.returnValue = "لديك تغييرات لم تُحفظ بعد.";
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty]);

  useEffect(() => {
    return () => {
      Object.values(urlsRef.current).forEach(safeRevoke);
    };
  }, []);

  const addMediaFromBlob = useCallback(
    async (blob: Blob, name: string, options: { kind?: MediaKind; meta?: Partial<MediaMeta> } = {}): Promise<MediaMeta> => {
      const kind: MediaKind = options.kind ?? (isImageName(name, blob.type) ? "image" : "audio");
      let duration: number | undefined;
      let peaks: number[] | undefined;
      let width: number | undefined;
      let height: number | undefined;
      const file = blob instanceof File ? blob : new File([blob], name, { type: blob.type || (kind === "audio" ? "audio/mpeg" : "image/png") });
      if (kind === "audio") {
        if (!isAudioName(name, file.type)) throw new Error(`الملف «${name}» ليس صوتًا مدعومًا.`);
        const inspected = await inspectAudioFile(file);
        duration = inspected.duration;
        peaks = inspected.peaks;
      } else {
        if (!isImageName(name, file.type)) throw new Error(`الملف «${name}» ليس صورة مدعومة.`);
        const inspected = await inspectImageFile(file);
        width = inspected.width;
        height = inspected.height;
      }
      const id = options.meta?.id ?? uid(kind);
      const meta: MediaMeta = {
        id,
        name,
        type: file.type || (kind === "audio" ? "audio/mpeg" : "image/png"),
        size: file.size,
        kind,
        duration,
        peaks,
        width,
        height,
        createdAt: Date.now(),
        ...options.meta,
      };
      try {
        await putMedia(id, file, meta);
      } catch (error) {
        throw new Error(quotaMessage(error));
      }
      const url = URL.createObjectURL(file);
      urlsRef.current = { ...urlsRef.current, [id]: url };
      setMediaUrls(urlsRef.current);
      setAvailableMedia((current) => new Set([...current, id]));
      setMissingMedia((current) => current.filter((entry) => entry !== id));
      updateProject((current) => ({ ...current, media: { ...current.media, [id]: meta } }));
      return meta;
    },
    [updateProject],
  );

  const addMediaFile = useCallback(
    async (file: File, kind?: MediaKind): Promise<MediaMeta> => {
      try {
        return await addMediaFromBlob(file, file.name, { kind });
      } catch (error) {
        const message = errorMessage(error);
        toast(message, "error");
        throw new Error(message);
      }
    },
    [addMediaFromBlob, toast],
  );

  const removeMedia = useCallback(
    async (mediaId: string) => {
      try {
        await deleteMediaRecord(mediaId);
      } catch (error) {
        toast(quotaMessage(error), "error");
        return;
      }
      if (urlsRef.current[mediaId]) {
        safeRevoke(urlsRef.current[mediaId]);
        const nextUrls = { ...urlsRef.current };
        delete nextUrls[mediaId];
        urlsRef.current = nextUrls;
        setMediaUrls(nextUrls);
      }
      setAvailableMedia((current) => {
        const next = new Set(current);
        next.delete(mediaId);
        return next;
      });
      updateProject((current) => {
        const media = { ...current.media };
        delete media[mediaId];
        return {
          ...current,
          media,
          timing: {
            ...current.timing,
            backgroundMusicId:
              current.timing.backgroundMusicId === mediaId ? null : current.timing.backgroundMusicId,
          },
          design: {
            ...current.design,
            background: {
              ...current.design.background,
              imageId: current.design.background.imageId === mediaId ? null : current.design.background.imageId,
            },
            brand: { ...current.design.brand, logoId: current.design.brand.logoId === mediaId ? null : current.design.brand.logoId },
          },
          questions: current.questions.map((question) => ({
            ...question,
            questionAudioId: question.questionAudioId === mediaId ? null : question.questionAudioId,
            optionsAudioId: question.optionsAudioId === mediaId ? null : question.optionsAudioId,
            combinedAudioId: question.combinedAudioId === mediaId ? null : question.combinedAudioId,
            answerAudioId: question.answerAudioId === mediaId ? null : question.answerAudioId,
            imageId: question.imageId === mediaId ? null : question.imageId,
          })),
        };
      });
      toast(`حُذف الملف «${projectRef.current.media[mediaId]?.name ?? "المحدد"}» من المشروع والتخزين.`, "info");
    },
    [toast, updateProject],
  );

  const openProject = useCallback(
    async (id: string) => {
      try {
        if (dirty) await persist(projectRef.current);
        const next = await getProject(id);
        if (!next) throw new Error("المشروع غير موجود في التخزين المحلي. ربما حُذف.");
        setProject(next);
        setDirty(false);
        setLastSavedAt(next.updatedAt);
        localStorage.setItem(ACTIVE_KEY, next.id);
        await hydrateMedia(next, true);
        toast(`فُتح المشروع «${next.name}».`, "success");
      } catch (error) {
        toast(errorMessage(error, "تعذّر فتح المشروع."), "error");
      }
    },
    [dirty, hydrateMedia, persist, toast],
  );

  const createProject = useCallback(
    async (name: string, aspect: ExportSettings["aspect"]) => {
      try {
        if (dirty) await persist(projectRef.current);
        const next = createBlankProject(name, aspect);
        await putProject(next);
        setProject(next);
        setDirty(false);
        setLastSavedAt(next.updatedAt);
        localStorage.setItem(ACTIVE_KEY, next.id);
        await hydrateMedia(next, true);
        await refreshProjects();
        toast(`أُنشئ المشروع «${next.name}». ابدأ بإضافة أسئلتك.`, "success");
      } catch (error) {
        toast(quotaMessage(error), "error");
      }
    },
    [dirty, hydrateMedia, persist, refreshProjects, toast],
  );

  const removeProjectById = useCallback(
    async (id: string) => {
      try {
        const target = await getProject(id);
        if (!target) throw new Error("المشروع غير موجود.");
        const mediaIds = requiredMediaIds(target);
        await removeProject(id);
        for (const mediaId of mediaIds) {
          if (mediaId.startsWith("test_")) continue;
          await deleteMediaRecord(mediaId).catch(() => undefined);
          safeRevoke(urlsRef.current[mediaId]);
          delete urlsRef.current[mediaId];
        }
        setMediaUrls({ ...urlsRef.current });
        await refreshProjects();
        if (projectRef.current.id === id) {
          const next = createBlankProject("مشروع جديد");
          await putProject(next);
          setProject(next);
          setDirty(false);
          localStorage.setItem(ACTIVE_KEY, next.id);
          await hydrateMedia(next, true);
        }
        toast(`حُذف المشروع «${target.name}».`, "success");
      } catch (error) {
        toast(errorMessage(error, "تعذّر حذف المشروع."), "error");
      }
    },
    [hydrateMedia, refreshProjects, toast],
  );

  const exportProjectZip = useCallback(async () => {
    const current = projectRef.current;
    const zip = new JSZip();
    const mediaIds = requiredMediaIds(current);
    const found: string[] = [];
    const missing: string[] = [];
    for (const mediaId of mediaIds) {
      try {
        const record = await getMedia(mediaId);
        if (!record) {
          missing.push(current.media[mediaId]?.name ?? mediaId);
          continue;
        }
        const ext = record.meta.name.split(".").pop() || (record.meta.kind === "audio" ? "mp3" : "png");
        const path = `media/${mediaId}.${ext}`;
        zip.file(path, record.blob);
        found.push(path);
      } catch {
        missing.push(current.media[mediaId]?.name ?? mediaId);
      }
    }
    const manifest = {
      ...current,
      updatedAt: Date.now(),
    };
    zip.file("project.json", JSON.stringify(manifest, null, 2));
    zip.file(
      "README.txt",
      [
        "Quiz Studio Pro — حزمة مشروع",
        "",
        `اسم المشروع: ${current.name}`,
        `عدد الأسئلة: ${current.questions.length}`,
        `عدد ملفات الوسائط المضمّنة: ${found.length}`,
        missing.length ? `ملفات مفقودة لم تُضمَّن: ${missing.join("، ")}` : "جميع ملفات الوسائط مضمّنة.",
        "",
        "لاستعادة المشروع: افتح Quiz Studio Pro > فتح مشروع > استيراد حزمة ZIP.",
        "الملفات داخل مجلد media مرتبطة بالمعرّفات الموجودة في project.json.",
      ].join("\n"),
    );
    try {
      const blob = await zip.generateAsync({ type: "blob", compression: "STORE" });
      if (blob.size === 0) throw new Error("فشل إنشاء حزمة المشروع: الملف فارغ.");
      downloadBlob(blob, `${sanitizeFilename(current.name, "quiz-project")}.zip`);
      if (missing.length) toast(`صُدّرت الحزمة، لكن ${missing.length} ملفًا مفقودًا لم يُضمَّن. راجع قائمة الملفات المفقودة.`, "warning");
      else toast("صُدّرت حزمة المشروع بصيغة ZIP مع جميع الملفات.", "success");
    } catch (error) {
      toast(errorMessage(error, "تعذّر تصدير حزمة المشروع."), "error");
    }
  }, [toast]);

  const importProjectZip = useCallback(
    async (file: File) => {
      try {
        if (!/\.zip$/i.test(file.name)) throw new Error("اختر ملف مشروع بصيغة ZIP.");
        if (file.size === 0) throw new Error("ملف ZIP فارغ.");
        const zip = await JSZip.loadAsync(file);
        const jsonCandidates = Object.keys(zip.files).filter(
          (path) => /\.json$/i.test(path) && !path.startsWith("__MACOSX") && zip.files[path].dir === false,
        );
        const projectEntry =
          jsonCandidates.find((path) => /(^|\/)project\.json$/i.test(path)) ??
          jsonCandidates.find((path) => /(^|\/)quiz.*\.json$/i.test(path)) ??
          jsonCandidates[0];
        if (!projectEntry) throw new Error("لا يحتوي ZIP على ملف project.json. تأكد أنه مشروع Quiz Studio.");
        const rawText = await zip.files[projectEntry].async("text");
        let raw: unknown;
        try {
          raw = JSON.parse(rawText);
        } catch {
          throw new Error("ملف project.json يحتوي JSON غير صالح. أعد تصدير المشروع من التطبيق.");
        }
        const parsed = normalizeProject(raw);
        const next: Project = { ...parsed, id: uid("project"), name: `${parsed.name} — مستورد` };
        const mediaEntries = Object.keys(zip.files).filter((path) => path.startsWith("media/") && !zip.files[path].dir);
        const mediaBlobs = new Map<string, Blob>();
        for (const path of mediaEntries) {
          const filename = path.split("/").pop() ?? path;
          const idFromName = filename.split(".")[0];
          const blob = await zip.files[path].async("blob");
          const extension = filename.split(".").pop()?.toLowerCase() ?? "";
          const mime = extension === "mp3" ? "audio/mpeg" : extension === "wav" ? "audio/wav" : extension === "m4a" ? "audio/mp4" : extension === "png" ? "image/png" : extension === "jpg" || extension === "jpeg" ? "image/jpeg" : extension === "webp" ? "image/webp" : blob.type;
          mediaBlobs.set(idFromName, new Blob([blob], { type: mime }));
        }
        const recovered: Record<string, MediaMeta> = { ...next.media };
        const recoveredIds = new Set<string>();
        for (const [mediaId, meta] of Object.entries(next.media)) {
          const blob = mediaBlobs.get(mediaId);
          if (!blob) continue;
          try {
            const stored = await addMediaFromBlob(blob, meta.name, {
              kind: meta.kind,
              meta: { ...meta, id: mediaId },
            });
            recovered[mediaId] = stored;
            recoveredIds.add(mediaId);
          } catch {
            /* يظهر الملف كمفقود في الفحص */
          }
        }
        const finalProject: Project = { ...next, media: recovered };
        await putProject(finalProject);
        setProject(finalProject);
        setDirty(false);
        setLastSavedAt(finalProject.updatedAt);
        localStorage.setItem(ACTIVE_KEY, finalProject.id);
        await hydrateMedia(finalProject, true);
        await refreshProjects();
        const missingCount = requiredMediaIds(finalProject).filter((id) => !recoveredIds.has(id)).length;
        toast(
          missingCount > 0
            ? `استُعيد المشروع، لكن بعض الملفات لم تكن داخل الحزمة. راجع فحص التصدير.`
            : "استُعيد المشروع وجميع ملفاته بنجاح.",
          missingCount > 0 ? "warning" : "success",
        );
      } catch (error) {
        toast(errorMessage(error, "تعذّر استيراد المشروع. تأكد من اختيار ZIP صالح."), "error");
        throw error;
      }
    },
    [addMediaFromBlob, hydrateMedia, refreshProjects, toast],
  );

  const value = useMemo<StudioContextValue>(
    () => ({
      project,
      ready,
      dirty,
      saving,
      lastSavedAt,
      projects,
      mediaUrls,
      availableMedia,
      missingMedia,
      updateProject,
      addMediaFile,
      addMediaFromBlob,
      removeMedia,
      saveNow,
      refreshProjects,
      openProject,
      createProject,
      removeProjectById,
      exportProjectZip,
      importProjectZip,
      hydrateMedia,
      toast,
      toasts,
      dismissToast,
    }),
    [
      project,
      ready,
      dirty,
      saving,
      lastSavedAt,
      projects,
      mediaUrls,
      availableMedia,
      missingMedia,
      updateProject,
      addMediaFile,
      addMediaFromBlob,
      removeMedia,
      saveNow,
      refreshProjects,
      openProject,
      createProject,
      removeProjectById,
      exportProjectZip,
      importProjectZip,
      hydrateMedia,
      toast,
      toasts,
      dismissToast,
    ],
  );

  return <StudioContext.Provider value={value}>{children}</StudioContext.Provider>;
}

export function useStudio(): StudioContextValue {
  const context = useContext(StudioContext);
  if (!context) throw new Error("useStudio must be used inside StudioProvider");
  return context;
}
