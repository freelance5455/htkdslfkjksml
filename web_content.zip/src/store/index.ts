/* ============================================
   plix_ai studio — State management (localStorage)
   ============================================ */

import type { Project, BuildJob, AppSettings, KeystoreConfig } from '../types';

const STORAGE_KEYS = {
  projects: 'plix_projects',
  settings: 'plix_settings',
  keystores: 'plix_keystores',
  buildHistory: 'plix_build_history',
} as const;

// --- Default settings ---
const DEFAULT_SETTINGS: AppSettings = {
  darkMode: true,
  showDemoBadge: true,
  autoSave: true,
  buildNotifications: true,
  defaultMinSdk: 24,
  defaultOutputFormat: 'apk',
  defaultKeystoreValidity: 25,
};

// --- Helpers ---
function safeGet<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function safeSet(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error('[plix_store] Write failed:', e);
  }
}

// --- Projects ---
export function getProjects(): Project[] {
  return safeGet<Project[]>(STORAGE_KEYS.projects, []);
}

export function getProject(id: string): Project | undefined {
  return getProjects().find(p => p.id === id);
}

export function saveProject(project: Project): void {
  const projects = getProjects();
  const idx = projects.findIndex(p => p.id === project.id);
  project.updatedAt = Date.now();
  if (idx >= 0) {
    projects[idx] = project;
  } else {
    projects.unshift(project);
  }
  safeSet(STORAGE_KEYS.projects, projects);
}

export function deleteProject(id: string): void {
  const projects = getProjects().filter(p => p.id !== id);
  safeSet(STORAGE_KEYS.projects, projects);
}

export function duplicateProject(id: string): Project | undefined {
  const original = getProject(id);
  if (!original) return undefined;
  const copy: Project = {
    ...JSON.parse(JSON.stringify(original)),
    id: crypto.randomUUID(),
    name: `${original.name} (copy)`,
    status: 'draft',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    builds: [],
    lastBuildId: undefined,
  };
  saveProject(copy);
  return copy;
}

export function archiveProject(id: string): void {
  const project = getProject(id);
  if (project) {
    project.status = 'archived';
    saveProject(project);
  }
}

// --- Settings ---
export function getSettings(): AppSettings {
  return safeGet<AppSettings>(STORAGE_KEYS.settings, DEFAULT_SETTINGS);
}

export function saveSettings(settings: AppSettings): void {
  safeSet(STORAGE_KEYS.settings, settings);
}

// --- Keystores ---
export function getKeystores(): KeystoreConfig[] {
  return safeGet<KeystoreConfig[]>(STORAGE_KEYS.keystores, []);
}

export function saveKeystore(ks: KeystoreConfig): void {
  const keystores = getKeystores();
  const idx = keystores.findIndex(k => k.alias === ks.alias);
  if (idx >= 0) {
    keystores[idx] = ks;
  } else {
    keystores.push(ks);
  }
  safeSet(STORAGE_KEYS.keystores, keystores);
}

export function deleteKeystore(alias: string): void {
  const keystores = getKeystores().filter(k => k.alias !== alias);
  safeSet(STORAGE_KEYS.keystores, keystores);
}

// --- Build jobs (separate for performance) ---
export function getAllBuildJobs(): BuildJob[] {
  return safeGet<BuildJob[]>(STORAGE_KEYS.buildHistory, []);
}

export function saveBuildJob(job: BuildJob): void {
  const jobs = getAllBuildJobs();
  const idx = jobs.findIndex(j => j.id === job.id);
  if (idx >= 0) {
    jobs[idx] = job;
  } else {
    jobs.unshift(job);
  }
  safeSet(STORAGE_KEYS.buildHistory, jobs);
}

export function getBuildJob(id: string): BuildJob | undefined {
  return getAllBuildJobs().find(j => j.id === id);
}

// --- Nuke all data ---
export function deleteAllData(): void {
  Object.values(STORAGE_KEYS).forEach(key => localStorage.removeItem(key));
}

// --- Stats ---
export function getStats() {
  const projects = getProjects();
  const jobs = getAllBuildJobs();
  return {
    totalProjects: projects.length,
    activeProjects: projects.filter(p => p.status !== 'archived').length,
    totalBuilds: jobs.length,
    successfulBuilds: jobs.filter(j => j.status === 'completed').length,
    failedBuilds: jobs.filter(j => j.status === 'failed').length,
  };
}