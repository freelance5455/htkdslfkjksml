import { create } from "zustand";
import { CONFIG } from "@/lib/engine/config";
import { getExampleBundles } from "@/lib/engine/examples";
import { finalizePrediction, predict, scoreAndSort } from "@/lib/engine/predict";
import type { FeedStatus, LiveItem } from "@/lib/engine/types";
import { getLiveFeed } from "@/lib/fotmob/api";

export type TabId = "live" | "history";
export type FilterId = "all" | "goal" | "btts" | "next";

type AppState = {
  tab: TabId;
  filter: FilterId;
  items: LiveItem[];
  status: FeedStatus;
  error: string | null;
  lastUpdate: number | null;
  selectedId: string | null;
  analystMode: boolean;
  fetching: boolean;
  setTab: (tab: TabId) => void;
  setFilter: (filter: FilterId) => void;
  setSelected: (id: string | null) => void;
  setAnalystMode: (on: boolean) => void;
  refresh: () => Promise<void>;
  loadDemo: () => void;
  reclassify: () => void;
};

function buildItems(
  bundles: { match: LiveItem["match"]; stats: Parameters<typeof predict>[1]; graph?: Parameters<typeof predict>[2] }[],
  analystMode: boolean,
): LiveItem[] {
  const items = bundles.map(({ match, stats, graph }) => {
    const pred = finalizePrediction(match, predict(match, stats, graph ?? null), analystMode);
    return { match, pred };
  });
  return scoreAndSort(items, analystMode);
}

function readAnalystPref() {
  if (typeof localStorage === "undefined") return true;
  try {
    const v = localStorage.getItem("bola_mode99");
    if (v === "0") return false;
    if (v === "1") return true;
  } catch { /* ignore */ }
  return true;
}

export const useAppStore = create<AppState>((set, get) => ({
  tab: "live",
  filter: "all",
  items: [],
  status: "idle",
  error: null,
  lastUpdate: null,
  selectedId: null,
  analystMode: true,
  fetching: false,
  setTab: (tab) => set({ tab }),
  setFilter: (filter) => set({ filter }),
  setSelected: (id) => set({ selectedId: id }),
  setAnalystMode: (on) => {
    try { localStorage.setItem("bola_mode99", on ? "1" : "0"); } catch { /* ignore */ }
    set({ analystMode: on });
    get().reclassify();
  },
  reclassify: () => {
    const { items, analystMode } = get();
    const next = scoreAndSort(
      items.map((it) => ({
        match: it.match,
        pred: finalizePrediction(it.match, { ...it.pred }, analystMode),
      })),
      analystMode,
    );
    set({ items: next });
  },
  loadDemo: () => {
    const items = buildItems(getExampleBundles().map((b) => ({ ...b, graph: null })), get().analystMode);
    set({
      items,
      status: "demo",
      error: null,
      lastUpdate: Date.now(),
      selectedId: items[0]?.match.id ?? null,
    });
  },
  refresh: async () => {
    if (get().fetching) return;
    set({ fetching: true, status: get().items.length ? get().status : "loading", error: null });
    try {
      const res = await getLiveFeed();
      if (!res.ok) {
        if (!get().items.length) get().loadDemo();
        set({
          fetching: false,
          status: get().items.length ? get().status : "error",
          error: res.error || "Sem dados ao vivo",
        });
        return;
      }
      if (!res.items.length) {
        set({ fetching: false, items: [], status: "ok", lastUpdate: res.fetchedAt, selectedId: null });
        return;
      }
      const items = buildItems(res.items, get().analystMode);
      const keep = get().selectedId;
      const selectedId = items.some((it) => it.match.id === keep) ? keep : items[0]?.match.id ?? null;
      set({ items, status: "ok", error: null, lastUpdate: res.fetchedAt, selectedId, fetching: false });
    } catch (err) {
      if (!get().items.length) get().loadDemo();
      set({
        fetching: false,
        error: err instanceof Error ? err.message : "Falha na atualização",
        status: get().items.length ? get().status : "error",
      });
    }
  },
}));

export function hydratePrefs() {
  useAppStore.setState({ analystMode: readAnalystPref() });
}

export const FILTERS: { id: FilterId; label: string }[] = [
  { id: "all", label: "Ao vivo" },
  { id: "goal", label: "Golo quente" },
  { id: "btts", label: "BTTS" },
  { id: "next", label: "Próx. golo" },
];

export function itemMatchesFilter(it: LiveItem, filter: FilterId) {
  if (filter === "all") return true;
  if (filter === "goal") return it.pred.verdict?.key === "alta";
  if (filter === "btts") return it.pred.has && !it.pred.bttsDone && it.pred.bttsYes >= 55;
  if (filter === "next") return it.pred.has && it.pred.probability >= 58 && it.pred.pAny >= 50;
  return true;
}

export { CONFIG };
