import { create } from "zustand";
import { analyze, invalidateAnalysis, makeSnapshot, scoreArchive } from "@/lib/lottery/analyze";
import type { Analysis } from "@/lib/lottery/analyze";
import { mergeDraws, weekdayFromDate } from "@/lib/lottery/helpers";
import type { ArchiveSnapshot, Draw, Numbers5, SeedDraw } from "@/lib/lottery/types";
import { APP_UNLOCK_CODE } from "@/lib/lottery/types";
import type { I18nKey, Lang } from "@/lib/i18n";
import { dict } from "@/lib/i18n";

export type ScreenId =
  | "dashboard"
  | "history"
  | "grids"
  | "stats"
  | "prediction"
  | "assistant"
  | "gold"
  | "similar"
  | "dates"
  | "radar"
  | "turbo2"
  | "twosure"
  | "sum-pairs"
  | "gap-pairs"
  | "pair"
  | "number"
  | "archive"
  | "settings"
  | "news"
  | "add";

export type Screen =
  | { id: "dashboard" }
  | { id: "history" }
  | { id: "grids" }
  | { id: "stats" }
  | { id: "prediction" }
  | { id: "assistant" }
  | { id: "gold" }
  | { id: "similar" }
  | { id: "dates" }
  | { id: "radar" }
  | { id: "turbo2" }
  | { id: "twosure" }
  | { id: "sum-pairs"; family?: number }
  | { id: "gap-pairs"; family?: number }
  | { id: "pair"; a: number; b: number }
  | { id: "number"; n: number }
  | { id: "archive" }
  | { id: "settings" }
  | { id: "news" }
  | { id: "add"; editDate?: string };

const STORAGE = "pv8-v1";
const SESSION = "pv8-unlocked";

type Persisted = {
  extras: SeedDraw[];
  removedDates: string[];
  lang: Lang;
  lockOnBlur: boolean;
  archive: ArchiveSnapshot[];
};

function loadPersisted(): Persisted {
  const fallback: Persisted = {
    extras: [],
    removedDates: [],
    lang: "fr",
    lockOnBlur: true,
    archive: [],
  };
  if (typeof localStorage === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(STORAGE);
    if (!raw) return fallback;
    return { ...fallback, ...(JSON.parse(raw) as Persisted) };
  } catch {
    return fallback;
  }
}

function persist(p: Persisted) {
  try {
    localStorage.setItem(STORAGE, JSON.stringify(p));
  } catch {
    /* ignore */
  }
}

type State = Persisted & {
  unlocked: boolean;
  ready: boolean;
  stack: Screen[];
  toast: string | null;
  draws: Draw[];
  analysis: Analysis | null;
  hydrate: () => void;
  t: (k: I18nKey) => string;
  unlock: (code: string) => boolean;
  lock: () => void;
  go: (s: Screen) => void;
  back: () => void;
  tab: (id: Extract<Screen, { id: "dashboard" | "history" | "grids" | "stats" | "prediction" | "assistant" }>["id"]) => void;
  setLang: (lang: Lang) => void;
  setLockOnBlur: (v: boolean) => void;
  addDraw: (d: SeedDraw) => string | null;
  removeDraw: (date: string) => void;
  resetManual: () => void;
  importDraws: (rows: SeedDraw[]) => number;
  archiveNow: () => void;
  scorePending: (date: string, numbers: Numbers5) => void;
  setToast: (s: string | null) => void;
};

function recompute(extras: SeedDraw[], removedDates: string[]) {
  invalidateAnalysis();
  const draws = mergeDraws({ extras, removedDates });
  const analysis = analyze(draws, false);
  return { draws, analysis };
}

export const useApp = create<State>((set, get) => ({
  extras: [],
  removedDates: [],
  lang: "fr",
  lockOnBlur: true,
  archive: [],
  unlocked: false,
  ready: false,
  stack: [{ id: "dashboard" }],
  toast: null,
  draws: [],
  analysis: null,
  hydrate: () => {
    const p = loadPersisted();
    const { draws, analysis } = recompute(p.extras, p.removedDates);
    let archive = p.archive;
    const last = draws[draws.length - 1];
    archive = archive.map((s) => {
      if (!s.pending || !s.actual) return s;
      return s;
    });
    const unlocked =
      typeof sessionStorage !== "undefined" && sessionStorage.getItem(SESSION) === "1";
    set({
      ...p,
      archive,
      draws,
      analysis,
      ready: true,
      unlocked,
    });
    queueMicrotask(() => {
      const full = analyze(draws, true);
      set({ analysis: full });
    });
  },
  t: (k) => dict[get().lang][k],
  unlock: (code) => {
    if (code !== APP_UNLOCK_CODE) return false;
    try {
      sessionStorage.setItem(SESSION, "1");
    } catch {
      /* ignore */
    }
    set({ unlocked: true });
    return true;
  },
  lock: () => {
    try {
      sessionStorage.removeItem(SESSION);
    } catch {
      /* ignore */
    }
    set({ unlocked: false });
  },
  go: (s) => set({ stack: [...get().stack, s] }),
  back: () =>
    set({
      stack: get().stack.length > 1 ? get().stack.slice(0, -1) : [{ id: "dashboard" }],
    }),
  tab: (id) => set({ stack: [{ id }] }),
  setLang: (lang) => {
    const next = { ...slicePersist(get()), lang };
    persist(next);
    set(next);
  },
  setLockOnBlur: (lockOnBlur) => {
    const next = { ...slicePersist(get()), lockOnBlur };
    persist(next);
    set(next);
  },
  addDraw: (d) => {
    const day = weekdayFromDate(d.date);
    if (day === "dimanche") return get().t("sundaySkip");
    const draw: SeedDraw = { ...d, day };
    const { extras, removedDates, draws } = get();
    const exists = draws.some((x) => x.date === draw.date);
    let nextExtras = extras.filter((e) => e.date !== draw.date).concat(draw);
    let nextRemoved = removedDates.filter((x) => x !== draw.date);
    if (exists && !extras.some((e) => e.date === draw.date)) {
      nextExtras = extras.concat(draw);
    }
    const computed = recompute(nextExtras, nextRemoved);
    const persistable = {
      ...slicePersist(get()),
      extras: nextExtras,
      removedDates: nextRemoved,
    };
    persist(persistable);
    set({ ...persistable, ...computed });
    get().scorePending(draw.date, draw.numbers);
    queueMicrotask(() => set({ analysis: analyze(computed.draws, true) }));
    return null;
  },
  removeDraw: (date) => {
    const extras = get().extras.filter((e) => e.date !== date);
    const isSeed = get().draws.some((d) => d.date === date && d.source === "seed");
    const removedDates = isSeed
      ? Array.from(new Set([...get().removedDates, date]))
      : get().removedDates;
    const persistable = { ...slicePersist(get()), extras, removedDates };
    persist(persistable);
    const computed = recompute(extras, removedDates);
    set({ ...persistable, ...computed });
  },
  resetManual: () => {
    const persistable = { ...slicePersist(get()), extras: [], removedDates: [] };
    persist(persistable);
    const computed = recompute([], []);
    set({ ...persistable, ...computed });
  },
  importDraws: (rows) => {
    let extras = [...get().extras];
    let removedDates = [...get().removedDates];
    for (const r of rows) {
      const day = weekdayFromDate(r.date);
      if (day === "dimanche") continue;
      extras = extras.filter((e) => e.date !== r.date).concat({ ...r, day });
      removedDates = removedDates.filter((d) => d !== r.date);
    }
    const persistable = { ...slicePersist(get()), extras, removedDates };
    persist(persistable);
    const computed = recompute(extras, removedDates);
    set({ ...persistable, ...computed });
    return rows.length;
  },
  archiveNow: () => {
    const a = get().analysis;
    if (!a) return;
    const snap = makeSnapshot(a);
    const archive = [snap, ...get().archive.filter((s) => s.forDate !== snap.forDate || !s.pending)];
    const persistable = { ...slicePersist(get()), archive };
    persist(persistable);
    set({ archive });
  },
  scorePending: (date, numbers) => {
    const archive = get().archive.map((s) =>
      s.pending && (s.forDate === date || s.forDate === "")
        ? scoreArchive(s, numbers)
        : s,
    );
    const persistable = { ...slicePersist(get()), archive };
    persist(persistable);
    set({ archive });
  },
  setToast: (toast) => set({ toast }),
}));

function slicePersist(s: State): Persisted {
  return {
    extras: s.extras,
    removedDates: s.removedDates,
    lang: s.lang,
    lockOnBlur: s.lockOnBlur,
    archive: s.archive,
  };
}

export { APP_UNLOCK_CODE };

