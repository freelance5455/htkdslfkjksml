/* AccoNova UI core: helpers, formatting, modal, toast, form widgets. */
(function (root) {
  "use strict";
  var AN = root.AN, J = root.AN_J;
  var UI = root.AN_UI = { lang: "fa", store: null, ctx: null, tab: "home", sub: {}, timers: [], views: {} };

  /* ───── i18n ───── */
  function t(key, vars) {
    var D = root.AN_I18N || {}, s = D[UI.lang] && D[UI.lang][key];
    if (s == null) s = D.en && D.en[key];
    if (s == null) s = key;
    if (vars) s = s.replace(/\{(\w+)\}/g, function (m, k) { return vars[k] != null ? vars[k] : m; });
    return s;
  }
  UI.t = t;
  UI.LANGS = ["fa", "en", "ar", "fr", "de"];
  UI.LANG_NAMES = { fa: "فارسی", en: "English", ar: "العربية", fr: "Français", de: "Deutsch" };
  UI.isFa = function () { return UI.lang === "fa"; };
  UI.isRtl = function () { return UI.lang === "fa" || UI.lang === "ar"; };
  var LOCALES = { fa: "fa-IR", en: "en-US", ar: "ar-u-nu-latn", fr: "fr-FR", de: "de-DE" }, GREG = { fa: "fa-IR-u-ca-gregory", en: "en-US", ar: "ar-u-ca-gregory-nu-latn", fr: "fr-FR-u-ca-gregory", de: "de-DE-u-ca-gregory" };
  UI.locale = function () { return LOCALES[UI.lang] || "en-US"; };
  UI.gregLocale = function () { return GREG[UI.lang] || "en-US"; };

  /* ───── DOM helper ───── */
  function h(tag, attrs) {
    var e = document.createElement(tag);
    if (attrs) for (var k in attrs) {
      var v = attrs[k]; if (v == null || v === false) continue;
      if (k === "class") e.className = v; else if (k === "text") e.textContent = v;
      else if (k === "html") e.innerHTML = v; /* only ever called with static, trusted markup */
      else if (k.slice(0, 2) === "on") e.addEventListener(k.slice(2), v);
      else if (k === "value") e.value = v; else if (k === "checked") e.checked = !!v; else if (k === "disabled") e.disabled = !!v;
      else e.setAttribute(k, v === true ? "" : v);
    }
    for (var i = 2; i < arguments.length; i++) add(e, arguments[i]);
    return e;
  }
  function add(e, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { add(e, x); }); return; }
    e.appendChild(typeof c === "object" ? c : document.createTextNode(String(c)));
  }
  UI.h = h; UI.add = add;
  UI.clear = function (e) { while (e.firstChild) e.removeChild(e.firstChild); return e; };
  UI.$ = function (id) { return document.getElementById(id); };

  var ICONS = {
    globe: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/></svg>',
    check: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    back: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>',
    lock: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></svg>',
    plus: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
    x: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    download: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 11l5 5 5-5M5 20h14"/></svg>',
    print: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 9V4h10v5M7 17H5a1 1 0 0 1-1-1v-5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5a1 1 0 0 1-1 1h-2M7 14h10v6H7z"/></svg>',
    lock: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
    check: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5 9-10"/></svg>'
  };
  UI.icon = function (n) { return h("span", { class: "ic", html: ICONS[n] || "", "aria-hidden": "true" }); };

  /* ───── context ───── */
  UI.co = function () { return UI.store.company(UI.ctx); };
  UI.can = function (p) { return UI.store.can(UI.ctx, p); };

  /* ───── formatting ───── */
  var nfCache = {};
  function nf(opts) { var k = UI.locale() + JSON.stringify(opts); return nfCache[k] || (nfCache[k] = new Intl.NumberFormat(UI.locale(), opts)); }
  var F = UI.fmt = {
    num: function (n, o) { return nf(o || {}).format(n); },
    int: function (n) { return nf({ useGrouping: false }).format(n); },
    pad2: function (n) { return nf({ useGrouping: false, minimumIntegerDigits: 2 }).format(n); },
    cur: function (code) { if (UI.lang === "fa") { if (code === "IRR") return "ریال"; if (code === "IRT") return "تومان"; } return code; },
    money: function (minor, cur, noCode) {
      var co = UI.co(), c = co.currencies[cur || co.baseCurrency] || AN.CURRENCIES[cur] || { decimals: 2 };
      var s = AN.formatMinor(minor, c.decimals, UI.locale());
      return noCode ? s : s + " " + F.cur(cur || co.baseCurrency);
    },
    base: function (minor, noCode) { return F.money(minor, UI.co().baseCurrency, noCode); },
    date: function (iso) {
      if (!iso) return "";
      var p = J.parseIso(iso); if (!p) return iso;
      if (UI.co().calendar === "jalali") { var j = J.toJalali(p.y, p.m, p.d); return F.int(j.y) + "/" + F.pad2(j.m) + "/" + F.pad2(j.d); }
      return F.int(p.y) + "-" + F.pad2(p.m) + "-" + F.pad2(p.d);
    },
    dateAlt: function (iso) { /* the "other" calendar, for hints */
      var p = J.parseIso(iso); if (!p) return "";
      if (UI.co().calendar === "jalali") return F.int(p.y) + "-" + F.pad2(p.m) + "-" + F.pad2(p.d);
      var j = J.toJalali(p.y, p.m, p.d); return F.int(j.y) + "/" + F.pad2(j.m) + "/" + F.pad2(j.d);
    },
    dateTime: function (ms) {
      var d = new Date(ms), iso = J.isoFrom(d.getFullYear(), d.getMonth() + 1, d.getDate());
      return F.date(iso) + " " + F.pad2(d.getHours()) + ":" + F.pad2(d.getMinutes());
    },
    pct: function (bps) { return F.num(bps / 100, { maximumFractionDigits: 2 }) + "%"; },
    qty: function (milli) { return F.num(milli / 1000, { maximumFractionDigits: 3 }); },
    periodName: function (p) { return UI.co().calendar === "jalali" ? (UI.monthName("jalali", p.month) + " " + F.int(p.year)) : (UI.monthName("gregorian", p.month) + " " + F.int(p.year)); }
  };
  var FA_M = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
  var AR_M = ["فروردين", "أرديبهشت", "خرداد", "تير", "مرداد", "شهريور", "مهر", "آبان", "آذر", "دي", "بهمن", "إسفند"];
  var EN_M = ["Farvardin", "Ordibehesht", "Khordad", "Tir", "Mordad", "Shahrivar", "Mehr", "Aban", "Azar", "Dey", "Bahman", "Esfand"];
  UI.monthName = function (cal, m) {
    if (cal === "jalali") return UI.isFa() ? FA_M[m - 1] : UI.lang === "ar" ? AR_M[m - 1] : EN_M[m - 1];
    return new Intl.DateTimeFormat(UI.gregLocale(), { month: "long", timeZone: "UTC" }).format(new Date(Date.UTC(2021, m - 1, 15)));
  };
  /* built-in names (accounts, currencies, tax codes) are translated by key; user-typed names stay as typed */
  function nameByKey(key, en, obj) { var D = root.AN_I18N; if (obj && obj[UI.lang]) return obj[UI.lang]; if (UI.lang !== "fa" && UI.lang !== "en" && D.en[key] && (!obj || obj.en === D.en[key])) return t(key); return null; }
  UI.accName = function (a) { return nameByKey("acc_" + a.code, null, a.name) || a.name[UI.lang] || (UI.lang === "fa" ? a.name.fa || a.name.en : a.name.en || a.name.fa); };
  UI.curName = function (code) { var c = root.AN.CURRENCIES[code]; if (!c) return code; return UI.lang === "fa" || UI.lang === "en" ? c.name[UI.lang] : t("cur_" + code); };
  UI.taxName = function (x) { return nameByKey("tax_" + x.id, null, x.name) || x.name[UI.lang] || (UI.lang === "fa" ? x.name.fa || x.name.en : x.name.en || x.name.fa); };
  UI.codeNum = function (code) { return String(code).replace(/\d/g, function (d) { return F.int(Number(d)); }); };
  UI.accountLabel = function (a) { return UI.codeNum(a.code) + " · " + UI.accName(a); };

  /* ───── errors ───── */
  UI.errMsg = function (e) {
    if (!e) return "";
    var code = e.code, key = "e_" + code, vars = e.details || {};
    var D = root.AN_I18N, has = D && ((D[UI.lang] && D[UI.lang][key]) || (D.en && D.en[key]));
    if (code && has) {
      var v = {}; for (var k in vars) v[k] = vars[k];
      if (v.max === Infinity) v.max = "∞";
      if (typeof v.debit === "number" && UI.store) { var base = UI.co().baseCurrency; v.debit = F.money(v.debit, UI.curOfForm || base, true); v.credit = F.money(v.credit, UI.curOfForm || base, true); }
      return t(key, v);
    }
    return (e.message || String(e));
  };

  /* ───── toast ───── */
  UI.toast = function (msg, kind) {
    var box = UI.$("toasts"); if (!box) return;
    var el = h("div", { class: "toast " + (kind || "ok"), role: "status" }, msg); box.appendChild(el);
    setTimeout(function () { el.classList.add("out"); setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 300); }, kind === "err" ? 6000 : 3200);
  };

  /* ───── modal ───── */
  UI.modal = function (o) {
    var dlg = h("dialog", { class: "modal" + (o.wide ? " wide" : ""), "aria-labelledby": "mtitle" });
    var err = h("div", { class: "form-error", role: "alert", hidden: "" });
    var closeBtn = h("button", { class: "icon-btn", type: "button", "aria-label": t("close"), onclick: function () { api.close(); } }, UI.icon("x"));
    var head = h("div", { class: "modal-head" }, h("h2", { id: "mtitle", text: o.title }), closeBtn);
    var body = h("div", { class: "modal-body" }, o.body), foot = h("div", { class: "modal-foot" }, o.footer || []);
    dlg.appendChild(h("div", { class: "modal-inner" }, head, err, body, foot));
    var api = {
      dialog: dlg, body: body, foot: foot,
      error: function (m) { if (m) { err.textContent = m; err.hidden = false; err.scrollIntoView && err.scrollIntoView({ block: "nearest" }); } else { err.hidden = true; err.textContent = ""; } },
      close: function () { if (dlg.open && dlg.close) dlg.close(); if (dlg.parentNode) dlg.parentNode.removeChild(dlg); if (o.onClose) o.onClose(); }
    };
    dlg.addEventListener("cancel", function (ev) { ev.preventDefault(); api.close(); });
    dlg.addEventListener("click", function (ev) { if (ev.target === dlg) api.close(); });
    document.body.appendChild(dlg);
    if (dlg.showModal) dlg.showModal(); else dlg.setAttribute("open", "");
    var first = dlg.querySelector("input:not([type=hidden]),select,textarea"); if (first && !o.noFocus) first.focus();
    return api;
  };
  UI.confirm = function (title, text, okLabel, danger) {
    return new Promise(function (resolve) {
      var m, done = false;
      var ok = h("button", { class: "btn" + (danger ? " danger" : ""), type: "button", onclick: function () { done = true; m.close(); resolve(true); } }, okLabel || t("ok"));
      var no = h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); } }, t("cancel"));
      m = UI.modal({ title: title, body: h("p", { text: text }), footer: [no, ok], onClose: function () { if (!done) resolve(false); } });
    });
  };
  UI.busy = function (btn, fn) { /* disable a button while an async/sync action runs (prevents double submit) */
    if (btn.disabled) return; btn.disabled = true;
    Promise.resolve().then(fn).catch(function () { }).then(function () { btn.disabled = false; });
  };

  /* ───── form widgets ───── */
  UI.field = function (label, input, hint, cls) {
    var id = "f" + Math.random().toString(36).slice(2, 8); if (input.setAttribute && !input.id) input.id = id;
    return h("div", { class: "field " + (cls || "") }, h("label", { for: input.id || id, text: label }), input, hint ? h("div", { class: "hint", text: hint }) : null);
  };
  UI.select = function (options, value, onchange) {
    var s = h("select", { class: "inp" });
    options.forEach(function (o) { s.appendChild(h("option", { value: o.value, text: o.label })); });
    if (value != null) s.value = value; if (onchange) s.addEventListener("change", onchange); return s;
  };
  UI.moneyInput = function (getDecimals, initialMinor, onchange) {
    var inp = h("input", { class: "inp num", type: "text", inputmode: "decimal", autocomplete: "off", dir: "ltr" });
    function show(minor) { inp.value = minor == null ? "" : AN.formatMinor(minor, getDecimals(), UI.locale()).replace(/[,٬]/g, ""); }
    if (initialMinor != null) show(initialMinor);
    inp.addEventListener("input", function () { inp.classList.remove("bad"); if (onchange) onchange(); });
    inp.addEventListener("blur", function () { var v = api.get(); if (v != null) show(v); else if (inp.value.trim()) inp.classList.add("bad"); });
    var api = { el: inp, get: function () { var s = inp.value.trim(); if (!s) return null; return AN.parseMoney(s, getDecimals()); }, set: show, raw: function () { return inp.value.trim(); } };
    return api;
  };
  UI.dateInput = function (initialIso, onchange) {
    var co = UI.co(), jal = co.calendar === "jalali";
    var inp = h("input", { class: "inp num", type: "text", inputmode: "numeric", autocomplete: "off", dir: "ltr", placeholder: jal ? F.int(1405) + "/" + F.pad2(1) + "/" + F.pad2(1) : "2026-01-31" });
    var hint = h("div", { class: "hint", dir: "ltr" });
    function parse() { return J.parseDateInput(inp.value, jal ? "jalali" : "gregorian"); }
    function refresh() { var iso = parse(); hint.textContent = iso ? "≈ " + F.dateAlt(iso) : (inp.value.trim() ? t("badDate") : ""); hint.classList.toggle("bad", !iso && !!inp.value.trim()); inp.classList.toggle("bad", !iso && !!inp.value.trim()); }
    function set(iso, silent) { inp.value = iso ? F.date(iso) : ""; refresh(); if (onchange && !silent) onchange(); }
    inp.addEventListener("input", function () { refresh(); if (onchange) onchange(); });
    var today = h("button", { class: "mini", type: "button", onclick: function () { set(UI.store.today()); } }, t("today"));
    var wrap = h("div", { class: "date-wrap" }, h("div", { class: "date-row" }, inp, today), hint);
    set(initialIso || null, true);
    return { el: wrap, input: inp, get: parse, set: set };
  };
  /* "this section is part of a paid plan" notice with an upgrade button (owner only) */
  UI.upgradeNote = function (textKey, planKey) {
    return h("div", { class: "locked" }, UI.icon("lock"), h("p", { text: t(textKey, { plan: t("plan_" + (planKey || "pro")) }) }),
      UI.can("plan.manage") ? h("button", { class: "btn", type: "button", onclick: function () { UI.go("settings", "plan"); } }, t("seePlans")) : h("p", { class: "muted small", text: t("askOwnerUpgrade") }));
  };
  UI.price = function (plan) {
    var pr = (root.AN.PLANS[plan] || {}).price || {}; if (!pr.USD) return t("priceFree");
    return t("priceMonthly", UI.isFa() ? { amount: UI.fmt.num(pr.IRT), cur: UI.fmt.cur("IRT") } : { amount: UI.fmt.num(pr.USD), cur: "USD" });
  };
  UI.badge = function (text, kind) { return h("span", { class: "badge " + (kind || ""), text: text }); };
  UI.table = function (heads, rows, o) {
    o = o || {};
    var thead = h("thead", {}, h("tr", {}, heads.map(function (x) { return h("th", { class: x.cls || "", scope: "col", text: x.label }); })));
    var tbody = h("tbody", {}, rows.map(function (r) { return h("tr", r.attrs || {}, (r.cells || r).map(function (c, i) { var hd = heads[i] || {}; return h("td", { class: hd.cls || "", "data-label": hd.label || "" }, c); })); }));
    return h("div", { class: "tw" }, h("table", { class: "tbl " + (o.cls || "") }, thead, tbody, o.foot || null));
  };
  UI.empty = function (msg, cta) { return h("div", { class: "empty" }, h("p", { text: msg }), cta || null); };
  UI.amount = function (minor, cur) { return h("span", { class: "amt", dir: "ltr" }, F.money(minor, cur)); };
  UI.num = function (text) { return h("span", { class: "amt", dir: "ltr", text: text }); };

  /* ───── downloads ───── */
  UI.download = function (name, text, mime) {
    var blob = new Blob([text], { type: mime || "text/plain;charset=utf-8" }), url = URL.createObjectURL(blob);
    var a = h("a", { href: url, download: name }); document.body.appendChild(a); a.click();
    setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 500);
  };
  /* ASCII-only names: some browsers drop non-Latin download names (and the extension with them). */
  UI.fileName = function (base, ext) { var co = UI.co(); return "AccoNova_" + (co.name.replace(/[^A-Za-z0-9\-]+/g, " ").trim().replace(/\s+/g, "_") || "company") + "_" + base + "_" + UI.store.today() + "." + ext; };
  UI.printNode = function () {
    var src = document.querySelector("dialog[open] .print-area") || document.querySelector(".report-out") || document.querySelector(".print-area");
    var root = document.getElementById("printRoot"); if (!root || !src) { window.print(); return; }
    root.textContent = ""; root.appendChild(src.cloneNode(true));
    var done = function () { document.documentElement.classList.remove("printing"); root.textContent = ""; window.removeEventListener("afterprint", done); };
    window.addEventListener("afterprint", done);
    document.documentElement.classList.add("printing");
    setTimeout(function () { try { window.print(); } finally { setTimeout(done, 1500); } }, 50);
  };

  UI.store_id = function (p) { return p + Math.random().toString(36).slice(2); };
  UI.newIdemKey = function () { return AN.newId("idem"); };
  UI.clearTimers = function () { UI.timers.forEach(function (x) { clearTimeout(x); clearInterval(x); }); UI.timers = []; };
})(typeof globalThis !== "undefined" ? globalThis : this);
