/**
 * flashcardService.js — built-in spaced repetition (SM-2) for quick cards,
 * living INSIDE the Anki tab next to your existing Anki statistics.
 */
import { getAll, put, newId, remove, todayISO } from '../../../core/storage/storageService.js';
import { addDaysISO } from '../../../core/utils/dateUtils.js';
import { emit } from '../../../core/utils/eventBus.js';

export const GRADES = { again: 1, hard: 3, good: 4, easy: 5 };

/** Pure SM-2 step. Returns the updated card (does not save). */
export function schedule(card, quality) {
  let ease = card.ease || 2.5;
  let reps = card.reps || 0;
  let interval = card.interval || 0;
  if (quality < 3) {
    reps = 0;
    interval = 0; // due again today
  } else {
    interval = reps === 0 ? 1 : reps === 1 ? 6 : Math.round(Math.max(1, interval) * ease);
    if (quality === 3) interval = Math.max(1, Math.round(interval * 0.8));
    if (quality === 5) interval = Math.round(interval * 1.15) || 1;
    reps += 1;
  }
  ease = Math.max(1.3, ease + 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
  return {
    ...card,
    ease: Math.round(ease * 100) / 100,
    reps,
    interval,
    dueDate: addDaysISO(todayISO(), interval),
    lastReviewed: todayISO(),
    lapses: (card.lapses || 0) + (quality < 3 ? 1 : 0),
  };
}

export function previewInterval(card, quality) {
  return quality < 3 ? 'now' : `${schedule(card, quality).interval}d`;
}

export async function addCard({ front, back, deck = 'General' }) {
  return put('flashcards', {
    id: newId(), front, back, deck: deck || 'General',
    dueDate: todayISO(), ease: 2.5, reps: 0, interval: 0, lapses: 0,
  });
}

export async function reviewCard(card, quality) {
  const updated = await put('flashcards', schedule(card, quality));
  emit('anki:logged', {}); // same XP event as your Anki log
  return updated;
}

export async function deleteCard(id) { return remove('flashcards', id); }
export async function getAllCards() { return getAll('flashcards'); }

export async function dueCards(deck = '') {
  const t = todayISO();
  return (await getAll('flashcards'))
    .filter((c) => c.dueDate <= t && (!deck || c.deck === deck))
    .sort((a, b) => (a.dueDate < b.dueDate ? -1 : 1));
}

export async function deckNames() {
  return [...new Set((await getAll('flashcards')).map((c) => c.deck || 'General'))].sort();
}

/** Parse "question | answer | deck" lines (or tab-separated, e.g. pasted from Excel/Anki). */
export function parseImport(text, defaultDeck = 'General') {
  const rows = [];
  text.split('\n').forEach((line) => {
    const parts = line.includes('\t') ? line.split('\t') : line.split('|');
    if (parts.length < 2) return;
    const front = parts[0].trim();
    const back = parts[1].trim();
    if (!front || !back) return;
    rows.push({ front, back, deck: (parts[2] || '').trim() || defaultDeck });
  });
  return rows;
}

export async function importCards(text, defaultDeck) {
  const rows = parseImport(text, defaultDeck);
  for (const r of rows) await addCard(r);
  return rows.length;
}

export async function exportCardsText() {
  const clean = (s) => String(s).replace(/\s*\n\s*/g, ' ').replace(/\|/g, '/');
  return (await getAll('flashcards')).map((c) => [c.front, c.back, c.deck || 'General'].map(clean).join(' | ')).join('\n');
}

export async function cardStats() {
  const all = await getAll('flashcards');
  const t = todayISO();
  return {
    total: all.length,
    due: all.filter((c) => c.dueDate <= t).length,
    mature: all.filter((c) => c.interval >= 21).length,
    learning: all.filter((c) => c.reps === 0).length,
  };
}
