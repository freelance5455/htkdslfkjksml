/**
 * pomodoroService.js — the Pomodoro engine (state machine, no UI).
 * - Timestamp-based: remaining time is computed from the wall clock, so it stays
 *   correct even if the screen sleeps or the sheet is closed (v1 used a plain
 *   setInterval counter that drifted and was lost when the sheet closed).
 * - Logs the REAL focused minutes into `studySessions` (type 'pomodoro').
 */
import { put, newId, todayISO, getAll } from '../../../core/storage/storageService.js';
import { buzz } from '../../../core/profile/prefsService.js';
import { emit } from '../../../core/utils/eventBus.js';
import { showToast } from '../../../core/notifications/toast.js';

export const PRESETS = {
  classic: { key: 'classic', label: '25 / 5', focus: 25, short: 5, long: 15, every: 4 },
  deep: { key: 'deep', label: '50 / 10', focus: 50, short: 10, long: 20, every: 3 },
  sprint: { key: 'sprint', label: '15 / 3', focus: 15, short: 3, long: 10, every: 4 },
};

export const PHASE_LABEL = { focus: 'Focus', short: 'Short break', long: 'Long break' };

const state = {
  preset: { ...PRESETS.classic },
  phase: 'focus',
  running: false,
  endAt: 0,
  remainingMs: PRESETS.classic.focus * 60000,
  totalMs: PRESETS.classic.focus * 60000,
  subject: '',
  cycle: 0,          // focus sessions finished in the current set
  sessionStartedAt: 0,
};

const subs = new Set();
let timer = null;

export function getPomodoroState() { return { ...state, remainingMs: currentRemaining() }; }
export function subscribePomodoro(fn) { subs.add(fn); return () => subs.delete(fn); }
const SAVE_KEY = 'pomodoro.state.v1';
function persist() {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify({
      preset: state.preset, phase: state.phase, running: state.running, endAt: state.endAt,
      remainingMs: state.remainingMs, totalMs: state.totalMs, subject: state.subject,
      cycle: state.cycle, sessionStartedAt: state.sessionStartedAt,
    }));
  } catch { /* storage unavailable */ }
}

/**
 * Call once at boot (before the lock screen). If Android unloaded the app while a
 * timer was running, the timer carries on from the saved wall-clock end time; a
 * focus block that finished while you were away is logged and moves to its break.
 */
export async function restorePomodoro() {
  let saved = null;
  try { saved = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null'); } catch { saved = null; }
  if (!saved || !saved.preset) return false;
  Object.assign(state, saved);
  if (state.running) {
    if (state.endAt <= Date.now()) await completePhase(true);
    else ensureTimer();
  }
  notify();
  return true;
}

function notify() { persist(); subs.forEach((fn) => { try { fn(getPomodoroState()); } catch (e) { console.error(e); } }); }

function currentRemaining() {
  return state.running ? Math.max(0, state.endAt - Date.now()) : state.remainingMs;
}

function phaseMs(phase) {
  const p = state.preset;
  return (phase === 'focus' ? p.focus : phase === 'short' ? p.short : p.long) * 60000;
}

function setPhase(phase) {
  state.phase = phase;
  state.totalMs = phaseMs(phase);
  state.remainingMs = state.totalMs;
  state.running = false;
  state.endAt = 0;
}

export function setPreset(key, custom) {
  if (state.running) return false;
  state.preset = key === 'custom' ? { key: 'custom', label: `${custom.focus} / ${custom.short}`, ...custom, long: custom.long || custom.short * 3, every: 4 } : { ...PRESETS[key] };
  state.cycle = 0;
  setPhase('focus');
  notify();
  return true;
}

export function setSubject(subject) { state.subject = subject; }

function ensureTimer() {
  if (timer) return;
  timer = setInterval(() => {
    if (state.running && currentRemaining() <= 0) completePhase();
    notify();
  }, 250);
}
function stopTimer() { if (timer) { clearInterval(timer); timer = null; } }

export function startPomodoro() {
  if (state.running) return;
  if (state.phase === 'focus' && state.remainingMs === state.totalMs) state.sessionStartedAt = Date.now();
  state.running = true;
  state.endAt = Date.now() + state.remainingMs;
  ensureTimer();
  notify();
}

export function pausePomodoro() {
  if (!state.running) return;
  state.remainingMs = currentRemaining();
  state.running = false;
  state.endAt = 0;
  notify();
}

export function resetPomodoro() {
  setPhase(state.phase);
  notify();
}

export function skipPhase() {
  if (state.phase === 'focus') {
    setPhase(state.cycle + 1 >= state.preset.every ? 'long' : 'short');
  } else {
    if (state.phase === 'long') state.cycle = 0;
    setPhase('focus');
  }
  notify();
}

/** Minutes of focus already completed in the running/paused focus phase. */
export function elapsedFocusMinutes() {
  if (state.phase !== 'focus') return 0;
  const elapsed = state.totalMs - currentRemaining();
  return Math.floor(elapsed / 60000);
}

/** Stop a focus session early and log the minutes actually focused (if ≥ 1). */
export async function stopAndLog() {
  const mins = elapsedFocusMinutes();
  if (mins >= 1) await logFocus(mins);
  resetPomodoro();
  return mins;
}

async function logFocus(minutes) {
  await put('studySessions', {
    id: newId(),
    date: todayISO(),
    subject: state.subject.trim() || 'Focused study',
    durationMin: minutes,
    type: 'pomodoro',
  });
  emit('study:blockCompleted', { subject: state.subject, durationMin: minutes });
}

async function completePhase(silent = false) {
  const wasFocus = state.phase === 'focus';
  state.running = false;
  if (!silent) { beep(); buzz([200, 100, 200]); }
  if (wasFocus) {
    const mins = Math.round(state.totalMs / 60000);
    await logFocus(mins);
    state.cycle += 1;
    showToast(`Focus complete — ${mins} min logged. Take a break.`);
    setPhase(state.cycle >= state.preset.every ? 'long' : 'short');
  } else {
    showToast('Break over — ready for the next focus block?');
    if (state.phase === 'long') state.cycle = 0;
    setPhase('focus');
  }
  emit('pomodoro:phaseChanged', { phase: state.phase });
  notify();
}

function beep() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    [0, 0.25].forEach((delay) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.frequency.value = 880; gain.gain.value = 0.15;
      osc.start(ctx.currentTime + delay);
      osc.stop(ctx.currentTime + delay + 0.18);
    });
    setTimeout(() => ctx.close(), 900);
  } catch { /* audio not available */ }
}

export function fmtMs(ms) {
  const total = Math.ceil(ms / 1000);
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}

export async function todaysPomodoroStats() {
  const today = todayISO();
  const all = await getAll('studySessions');
  const mine = all.filter((s) => s.date === today && s.type === 'pomodoro');
  return { count: mine.length, minutes: mine.reduce((a, s) => a + (s.durationMin || 0), 0) };
}

export async function recentSubjects(limit = 10) {
  const { subjectChoices } = await import('../subjects/subjectsService.js');
  return (await subjectChoices()).slice(0, limit);
}

export function pomodoroIsActive() {
  return state.running || state.remainingMs !== state.totalMs;
}
