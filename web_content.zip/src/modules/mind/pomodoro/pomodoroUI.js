/**
 * pomodoroUI.js — the Pomodoro clock: a big progress-ring timer in a bottom sheet,
 * presets, subject picker, cycle dots, pause/resume/skip/stop-and-log, and a
 * floating mini-timer that stays visible while a session runs.
 */
import { openSheet, closeSheet } from '../../../components/modal.js';
import { el, button, textInput } from '../../../components/ui.js';
import { showToast } from '../../../core/notifications/toast.js';
import {
  PRESETS, PHASE_LABEL, getPomodoroState, subscribePomodoro, setPreset, setSubject,
  startPomodoro, pausePomodoro, resetPomodoro, skipPhase, stopAndLog, fmtMs,
  elapsedFocusMinutes, todaysPomodoroStats, recentSubjects,
} from './pomodoroService.js';

const R = 96;
const CIRC = 2 * Math.PI * R;

function ringSVG() {
  const wrap = el('div', 'pomo-ring');
  wrap.innerHTML = `
    <svg viewBox="0 0 220 220" width="220" height="220">
      <circle cx="110" cy="110" r="${R}" class="pomo-ring__track"/>
      <circle cx="110" cy="110" r="${R}" class="pomo-ring__bar" stroke-dasharray="${CIRC}" stroke-dashoffset="0" transform="rotate(-90 110 110)"/>
    </svg>`;
  return wrap;
}

export async function openPomodoro() {
  const stats = await todaysPomodoroStats();
  const recents = await recentSubjects();

  openSheet('Focus timer', (body) => {
    const ring = ringSVG();
    const bar = ring.querySelector('.pomo-ring__bar');
    const time = el('div', 'pomo-time', '25:00');
    const phase = el('div', 'pomo-phase', 'Focus');
    ring.append(el('div', 'pomo-center', [phase, time]));

    const dots = el('div', 'pomo-dots');
    const todayLine = el('p', 'text-xs text-dim pomo-today', `Today: ${stats.count} session${stats.count === 1 ? '' : 's'} · ${stats.minutes} min`);

    // presets
    const presetRow = el('div', 'chip-row pomo-presets');
    const presetBtns = {};
    Object.values(PRESETS).forEach((p) => {
      const b = el('button', 'chip', p.label);
      b.addEventListener('click', () => { if (!setPreset(p.key)) showToast('Pause or reset the timer first.'); });
      presetBtns[p.key] = b;
      presetRow.append(b);
    });
    const customBtn = el('button', 'chip', 'Custom');
    customBtn.addEventListener('click', () => {
      const f = parseInt(window.prompt('Focus minutes (1–180):', '30'), 10);
      if (!f || f < 1 || f > 180) return;
      const s = parseInt(window.prompt('Break minutes (1–60):', '5'), 10) || 5;
      if (!setPreset('custom', { focus: f, short: Math.min(60, s), long: Math.min(60, s * 3) })) showToast('Pause or reset the timer first.');
    });
    presetBtns.custom = customBtn;
    presetRow.append(customBtn);

    // subject
    const st = getPomodoroState();
    const subject = textInput({ placeholder: 'What are you studying? (e.g. Physiology)', value: st.subject });
    subject.addEventListener('input', () => setSubject(subject.value));
    const recentRow = el('div', 'chip-row');
    recents.forEach((r) => {
      const c = el('button', 'chip', r);
      c.addEventListener('click', () => { subject.value = r; setSubject(r); });
      recentRow.append(c);
    });

    const primary = button('Start', { block: true });
    const reset = button('Reset', { variant: 'ghost' });
    const skip = button('Skip', { variant: 'ghost' });
    const stop = button('Stop & log', { variant: 'ghost' });
    primary.addEventListener('click', () => {
      const s = getPomodoroState();
      if (s.running) pausePomodoro(); else startPomodoro();
    });
    reset.addEventListener('click', () => resetPomodoro());
    skip.addEventListener('click', () => skipPhase());
    stop.addEventListener('click', async () => {
      const mins = elapsedFocusMinutes();
      if (mins < 1) { showToast('Focus for at least a minute to log it.'); return; }
      const m = await stopAndLog();
      showToast(`Logged ${m} min of focus.`);
    });

    const controls = el('div', 'pomo-controls', [reset, skip, stop]);

    function sync(s) {
      time.textContent = fmtMs(s.remainingMs);
      phase.textContent = PHASE_LABEL[s.phase];
      const frac = s.totalMs ? s.remainingMs / s.totalMs : 1;
      bar.setAttribute('stroke-dashoffset', String(CIRC * (1 - frac)));
      ring.dataset.phase = s.phase;
      ring.classList.toggle('pomo-ring--running', s.running);
      primary.textContent = s.running ? 'Pause' : (s.remainingMs < s.totalMs ? 'Resume' : (s.phase === 'focus' ? 'Start focus' : 'Start break'));
      Object.entries(presetBtns).forEach(([k, b]) => b.classList.toggle('chip--active', s.preset.key === k));
      dots.innerHTML = '';
      for (let i = 0; i < s.preset.every; i += 1) dots.append(el('span', `pomo-dot${i < s.cycle ? ' pomo-dot--done' : ''}`));
      stop.style.display = s.phase === 'focus' && s.remainingMs < s.totalMs ? '' : 'none';
    }

    body.append(ring, dots, todayLine, presetRow, subject, recentRow, el('div', 'mt-4', primary), controls,
      el('p', 'text-xs text-dim mt-3', 'The timer follows the clock, so it stays accurate if your screen sleeps. You can close this panel — a small timer stays on screen.'));

    const unsub = subscribePomodoro(sync);
    sync(getPomodoroState());
    // clean up the subscription when the sheet is removed from the DOM
    const obs = new MutationObserver(() => { if (!document.body.contains(body)) { unsub(); obs.disconnect(); } });
    obs.observe(document.body, { childList: true });
  });
}

/** Floating mini timer: visible on every page while a session is running/paused. */
export function initPomodoroMiniBar() {
  const bar = el('button', 'pomo-mini');
  bar.style.display = 'none';
  document.body.append(bar);
  bar.addEventListener('click', () => openPomodoro());
  subscribePomodoro((s) => {
    const active = s.running || s.remainingMs !== s.totalMs;
    bar.style.display = active ? 'flex' : 'none';
    bar.textContent = `${s.running ? '⏱' : '⏸'} ${PHASE_LABEL[s.phase]} · ${fmtMs(s.remainingMs)}`;
  });
}

export { closeSheet };
