/**
 * studyService.js — study session logging + timetable reference.
 * Timetable blocks mirror the report's execution system.
 */

import { getAll, put, newId, todayISO } from '../../../core/storage/storageService.js';
import { emit } from '../../../core/utils/eventBus.js';
import { lastNDates } from '../../../core/utils/dateUtils.js';

export const TIMETABLE_BLOCKS = [
  { time: '07:00 – 08:30', label: 'Block 1 — High-difficulty conceptual review' },
  { time: '09:00 – 12:00', label: 'Block 2 — Active recall practice questions' },
  { time: '14:00 – 17:00', label: 'Block 3 — Note consolidation & lecture prep' },
];

export const EXAM_TIMETABLE = [
  { time: '06:00 – 07:30', label: 'Dawn deep study — hardest topic first, then memorisation' },
  { time: '08:00 – 12:00', label: 'Past questions in 50/10 blocks — mark what you miss' },
  { time: '16:00 – 18:00', label: 'Anki / flashcards, then review every mistake' },
  { time: '19:45 – 21:00', label: 'Light recap + plan tomorrow — sleep early' },
];

export async function logStudySession({ subject, durationMin, type = 'block', notes = '' }) {
  const record = await put('studySessions', {
    id: newId(),
    date: todayISO(),
    subject,
    durationMin,
    type,
    notes,
  });
  emit('study:blockCompleted', { subject, durationMin });
  return record;
}

export async function getRecentSessions(limit = 10) {
  const all = await getAll('studySessions');
  return all.sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, limit);
}

export async function weeklyStudyHours() {
  const dates = lastNDates(7);
  const all = await getAll('studySessions');
  const totalMin = all.filter((s) => dates.includes(s.date)).reduce((sum, s) => sum + (s.durationMin || 0), 0);
  return Math.round((totalMin / 60) * 10) / 10;
}

export async function subjectBreakdown(days = 14) {
  const dates = lastNDates(days);
  const all = await getAll('studySessions');
  const bySubject = new Map();
  all.filter((s) => dates.includes(s.date)).forEach((s) => {
    bySubject.set(s.subject, (bySubject.get(s.subject) || 0) + s.durationMin);
  });
  return [...bySubject.entries()].sort((a, b) => b[1] - a[1]);
}
