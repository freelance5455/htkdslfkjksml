/** subjectsUI.js — "My subjects" manager, exam countdowns + exam-mode switch, and a chip row to pick a subject. */
import { el, card, sectionHeader, button, textInput, fieldLabel } from '../../../components/ui.js';
import { showToast } from '../../../core/notifications/toast.js';
import { openSheet, closeSheet } from '../../../components/modal.js';
import { subjectChoices, listSubjects, addSubject, updateSubject, deleteSubject, upcomingExams, isExamMode, setExamMode } from './subjectsService.js';

/** Chips that fill `input` when tapped. */
export async function subjectChipRow(input, onPick = () => {}) {
  const names = await subjectChoices();
  const row = el('div', 'chip-row');
  names.forEach((n) => { const c = el('button', 'chip', n); c.addEventListener('click', () => { input.value = n; onPick(n); }); row.append(c); });
  return names.length ? row : null;
}

function openSubjectForm(subject, done) {
  openSheet(subject ? 'Edit subject' : 'Add a subject', (body) => {
    const name = textInput({ value: subject?.name || '', placeholder: 'e.g. Anatomy' });
    const date = textInput({ type: 'date', value: subject?.examDate || '' });
    body.append(
      el('div', 'field', [fieldLabel('Subject name'), name]),
      el('div', 'field', [fieldLabel('Exam date (optional)'), date]),
      el('div', 'bottom-sheet__footer', [button('Save', { block: true, onClick: async () => {
        if (!name.value.trim()) { showToast('Give it a name.'); return; }
        if (subject) await updateSubject(subject.id, { name: name.value.trim(), examDate: date.value });
        else if (!(await addSubject(name.value, date.value))) { showToast('That subject already exists.'); return; }
        closeSheet(); showToast('Saved.'); done();
      } })]),
    );
    if (subject) body.append(el('div', 'mt-3', button('Delete subject', { variant: 'ghost', block: true, onClick: async () => {
      if (!window.confirm(`Remove "${subject.name}" from your list? Past study logs stay.`)) return;
      await deleteSubject(subject.id); closeSheet(); done();
    } })));
  });
}

export async function renderSubjectsSection(page, rerender) {
  const subjects = await listSubjects();
  const exams = await upcomingExams();
  const exam = await isExamMode();
  page.append(sectionHeader(`${subjects.length} subjects`, 'My subjects'));

  const rows = [];
  if (!subjects.length) rows.push(el('p', 'text-xs text-dim', 'Add the subjects you are studying now. Change them any time — new semester, new subjects.'));
  subjects.forEach((s) => {
    const left = exams.find((e) => e.id === s.id);
    const row = el('div', 'checklist-item', [
      el('span', 'checklist-item__label', s.name),
      el('span', 'text-xs text-dim', left ? `exam in ${left.daysLeft}d` : (s.examDate ? 'exam passed' : '')),
    ]);
    row.addEventListener('click', () => openSubjectForm(s, rerender));
    rows.push(row);
  });
  rows.push(el('div', 'mt-3', button('+ Add a subject', { variant: 'ghost', block: true, onClick: () => openSubjectForm(null, rerender) })));
  page.append(card(rows));

  const toggle = el('div', 'checklist-item', [
    el('span', 'checklist-item__label', exam ? '📖 Exam mode is ON' : '📖 Exam mode is off'),
    button(exam ? 'Turn off' : 'Turn on', { size: 'sm', variant: exam ? 'ghost' : 'primary', onClick: async () => { await setExamMode(!exam); showToast(exam ? 'Exam mode off.' : 'Exam mode on — Home now focuses on revision.'); rerender(); } }),
  ]);
  page.append(card([toggle, el('p', 'text-xs text-dim mt-2', 'When on, your coach and suggestions focus on past questions, Anki and your nearest exam.')]));
}
