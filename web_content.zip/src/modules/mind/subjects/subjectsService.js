/**
 * subjectsService.js — YOUR subjects. Nothing is built in: add, rename and delete them as the
 * semesters change (100 level sciences now, anatomy and physiology later).
 * Stored in settings. Study history keeps working because logs store the subject name as text.
 */
import { getSetting, setSetting, getAll, newId, todayISO } from '../../../core/storage/storageService.js';
import { daysBetween } from '../../../core/utils/dateUtils.js';

const KEY = 'subjects.v1';
const EXAM_KEY = 'exam.mode';

export async function listSubjects() { return getSetting(KEY, []); }
export async function subjectNames() { return (await listSubjects()).map((s) => s.name); }

export async function addSubject(name, examDate = '') {
  const n = name.trim(); if (!n) return null;
  const list = await listSubjects();
  if (list.some((s) => s.name.toLowerCase() === n.toLowerCase())) return null;
  const s = { id: newId(), name: n, examDate: examDate || '' };
  await setSetting(KEY, [...list, s]); return s;
}
export async function updateSubject(id, patch) {
  await setSetting(KEY, (await listSubjects()).map((s) => (s.id === id ? { ...s, ...patch } : s)));
}
export async function deleteSubject(id) { await setSetting(KEY, (await listSubjects()).filter((s) => s.id !== id)); }

/** Subjects that have an exam date still to come, soonest first. */
export async function upcomingExams() {
  const t = todayISO();
  return (await listSubjects()).filter((s) => s.examDate && s.examDate >= t)
    .map((s) => ({ ...s, daysLeft: daysBetween(t, s.examDate) })).sort((a, b) => a.daysLeft - b.daysLeft);
}

export async function isExamMode() { return !!(await getSetting(EXAM_KEY, false)); }
export async function setExamMode(on) { await setSetting(EXAM_KEY, !!on); }

/** Subjects + names already used in your logs, so old history stays selectable. */
export async function subjectChoices() {
  const mine = await subjectNames();
  const used = new Set((await getAll('studySessions')).map((s) => s.subject).filter(Boolean));
  return [...mine, ...[...used].filter((u) => !mine.includes(u) && u !== 'Focused study').slice(0, 6)];
}
