/**
 * notesService.js — Cornell notes, Memory Palace entries and journal.
 * All share the `notesEntries` store (differentiated by `type`).
 * v2: #tags are extracted automatically, notes can be edited/deleted, and
 * searchEverything() looks across notes, flashcards and past questions.
 */
import { getAll, put, newId, remove, todayISO } from '../../../core/storage/storageService.js';

export function extractTags(text) {
  return [...new Set((String(text || '').match(/#[\p{L}\d_-]+/gu) || []).map((t) => t.slice(1).toLowerCase()))];
}

export async function createNote({ type, title, content }) {
  return put('notesEntries', { id: newId(), date: todayISO(), type, title, content, tags: extractTags(`${title} ${content}`) });
}

export async function updateNote(note, { title, content }) {
  return put('notesEntries', { ...note, title, content, tags: extractTags(`${title} ${content}`) });
}

export async function deleteNote(id) { return remove('notesEntries', id); }

export async function getNotesByType(type, tag = '') {
  const all = await getAll('notesEntries');
  return all
    .filter((n) => n.type === type && (!tag || (n.tags || extractTags(`${n.title} ${n.content}`)).includes(tag)))
    .sort((a, b) => (a.date < b.date ? 1 : -1));
}

export async function tagCounts(type) {
  const counts = {};
  (await getAll('notesEntries')).filter((n) => n.type === type).forEach((n) => {
    (n.tags || extractTags(`${n.title} ${n.content}`)).forEach((t) => { counts[t] = (counts[t] || 0) + 1; });
  });
  return counts;
}

export async function searchEverything(query) {
  const q = query.trim().toLowerCase();
  if (q.length < 2) return { notes: [], cards: [], questions: [] };
  const has = (...f) => f.some((x) => String(x || '').toLowerCase().includes(q));
  const [notes, cards, questions] = await Promise.all([getAll('notesEntries'), getAll('flashcards'), getAll('pastQuestions')]);
  return {
    notes: notes.filter((n) => has(n.title, n.content, (n.tags || []).map((t) => `#${t}`).join(' '))),
    cards: cards.filter((c) => has(c.front, c.back, c.deck)),
    questions: questions.filter((p) => has(p.question, p.answer, p.subject)),
  };
}
