/** pastQuestionsService.js — your own bank of past questions with practice mode. */
import { getAll, put, newId, remove, todayISO } from '../../../core/storage/storageService.js';

export const STATUSES = ['new', 'weak', 'done'];

export async function addQuestion({ question, answer = '', subject = 'General', source = '' }) {
  return put('pastQuestions', { id: newId(), question, answer, subject: subject || 'General', source, status: 'new', addedOn: todayISO(), attempts: 0 });
}

export async function setStatus(q, status) {
  return put('pastQuestions', { ...q, status, attempts: (q.attempts || 0) + 1, lastPracticed: todayISO() });
}

export async function deleteQuestion(id) { return remove('pastQuestions', id); }

export async function listQuestions({ subject = '', status = '' } = {}) {
  return (await getAll('pastQuestions'))
    .filter((q) => (!subject || q.subject === subject) && (!status || q.status === status))
    .sort((a, b) => (a.addedOn < b.addedOn ? 1 : -1));
}

export async function subjectsInBank() {
  return [...new Set((await getAll('pastQuestions')).map((q) => q.subject || 'General'))].sort();
}

export async function bankStats() {
  const all = await getAll('pastQuestions');
  return { total: all.length, weak: all.filter((q) => q.status === 'weak').length, done: all.filter((q) => q.status === 'done').length };
}
