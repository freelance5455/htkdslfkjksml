import React, { useState } from 'react';
import JSZip from 'jszip';
import { useAscend } from '../context/AscendContext';
import { AscendIcon } from '../components/AscendIcon';
import { CustomTheme, TypographyConfig } from '../types/ascend';

const MODERN_FONTS = [
  'Inter',
  'Manrope',
  'Plus Jakarta Sans',
  'DM Sans',
  'Poppins',
];

const HANDWRITING_FONTS = [
  'Caveat',
  'Kalam',
  'Patrick Hand',
  'Architects Daughter',
  'Indie Flower',
  'Shadows Into Light',
  'Dancing Script',
  'Sacramento',
];

export const SettingsAndStudioModule: React.FC = () => {
  const {
    state,
    setActiveTheme,
    saveCustomTheme,
    deleteCustomTheme,
    updateTypography,
    updateNavigation,
    importFullState,
    resetToDefaults,
  } = useAscend();

  const [activeTab, setActiveTab] = useState<
    'themes' | 'typography' | 'navigation' | 'android-export'
  >('themes');

  const currentTheme =
    state.themes.find((t) => t.id === state.activeThemeId) || state.themes[0];

  const [customThemeDraft, setCustomThemeDraft] = useState<CustomTheme>({
    id: `theme-custom-${Date.now()}`,
    name: 'My Custom Studio',
    mode: 'light',
    bgCanvas: currentTheme.bgCanvas,
    bgSurface: currentTheme.bgSurface,
    bgElevated: currentTheme.bgElevated,
    textPrimary: currentTheme.textPrimary,
    textSecondary: currentTheme.textSecondary,
    textMuted: currentTheme.textMuted,
    borderSubtle: currentTheme.borderSubtle,
    accentPrimary: currentTheme.accentPrimary,
  });

  const [isGeneratingZip, setIsGeneratingZip] = useState(false);
  const [zipStatus, setZipStatus] = useState<string | null>(null);

  const sortedNav = [...state.navigation].sort((a, b) => a.order - b.order);

  const moveNavOrder = (id: string, dir: -1 | 1) => {
    const ordered = [...state.navigation].sort((a, b) => a.order - b.order);
    const idx = ordered.findIndex((n) => n.id === id);
    const swapIdx = idx + dir;
    if (idx < 0 || swapIdx < 0 || swapIdx >= ordered.length) return;
    const temp = ordered[idx].order;
    ordered[idx].order = ordered[swapIdx].order;
    ordered[swapIdx].order = temp;
    updateNavigation([...ordered]);
  };

  const handleExportJson = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ascend-os-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(String(ev.target?.result));
        if (parsed && parsed.character && parsed.habits) {
          importFullState(parsed);
        }
      } catch {
        // Ignore invalid JSON
      }
    };
    reader.readAsText(file);
  };

  const handleGenerateAndroidReadyZip = async () => {
    setIsGeneratingZip(true);
    setZipStatus(null);
    try {
      const zip = new JSZip();

      // Root Gradle files (directly in root of MyAndroidApp-Ready.zip — no extra nested folder)
      zip.file(
        'settings.gradle',
        `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "AscendOS"
include ':app'
`
      );

      zip.file(
        'build.gradle',
        `// Top-level build file for Ascend OS Android Project
plugins {
    id 'com.android.application' version '8.2.2' apply false
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`
      );

      zip.file(
        'gradle.properties',
        `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
`
      );

      zip.file(
        'gradlew',
        `#!/usr/bin/env sh
# Gradle Startup Script for Unix/macOS
exec gradle "$@"
`
      );

      zip.file(
        'gradlew.bat',
        `@rem Gradle startup script for Windows
@echo off
gradle %*
`
      );

      zip.file(
        'gradle/wrapper/gradle-wrapper.properties',
        `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.5-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
      );

      zip.file(
        'app/build.gradle',
        `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.ascendos.app'
    compileSdk 34

    defaultConfig {
        applicationId "com.ascendos.app"
        minSdk 24
        targetSdk 34
        versionCode 3
        versionName "3.0.0"
    }

    buildTypes {
        debug {
            debuggable true
            applicationIdSuffix ".debug"
        }
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'androidx.webkit:webkit:1.10.0'
}
`
      );

      zip.file(
        'app/src/main/AndroidManifest.xml',
        `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.ascendos.app">

    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="true">
        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`
      );

      zip.file(
        'app/src/main/java/com/ascendos/app/MainActivity.java',
        `package com.ascendos.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
`
      );

      zip.file(
        'app/src/main/res/values/strings.xml',
        `<resources>
    <string name="app_name">ASCEND OS</string>
</resources>
`
      );

      zip.file(
        'app/src/main/res/values/styles.xml',
        `<resources>
    <style name="AppTheme" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="android:statusBarColor">#0F1014</item>
    </style>
</resources>
`
      );

      zip.file(
        'app/src/main/assets/www/ascend-os-state-snapshot.json',
        JSON.stringify(state, null, 2)
      );

      zip.file(
        'README.md',
        `# ASCEND OS — Android Studio & Gradle Ready Project (MyAndroidApp-Ready.zip)

## Project Structure
\`\`\`
├── settings.gradle
├── build.gradle
├── gradle.properties
├── gradlew
├── gradlew.bat
├── gradle/wrapper/gradle-wrapper.properties
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/www/ascend-os-state-snapshot.json
│       ├── java/com/ascendos/app/MainActivity.java
│       └── res/values/{strings.xml, styles.xml}
└── README.md
\`\`\`

## How to Build the Android APK
1. Run \`npm run build\` in the Ascend OS web repository and copy \`dist/index.html\` into \`app/src/main/assets/www/index.html\`.
2. Open this root folder directly in **Android Studio** (Hedgehog / Iguana / Jellyfish or newer).
3. Allow Gradle Sync to complete (uses Android Gradle Plugin 8.2.2 and Gradle 8.5, compileSdk 34, minSdk 24).
4. Run **Build > Build Bundle(s) / APK(s) > Build APK(s)** or execute \`./gradlew assembleDebug\` from the terminal.
5. Output APK location: \`app/build/outputs/apk/debug/app-debug.apk\`.
`
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'MyAndroidApp-Ready.zip';
      a.click();
      URL.revokeObjectURL(url);
      setZipStatus(
        'MyAndroidApp-Ready.zip generated and downloaded with root settings.gradle, build.gradle, MainActivity.java, AndroidManifest.xml, and your live Ascend OS state snapshot.'
      );
    } finally {
      setIsGeneratingZip(false);
    }
  };

  const typographySlots: {
    key: keyof TypographyConfig;
    label: string;
    sample: string;
  }[] = [
    {
      key: 'headingFont',
      label: 'Main Headings Font',
      sample: 'ASCEND OS — Life Operating System',
    },
    {
      key: 'subheadingFont',
      label: 'Subheadings & Card Titles Font',
      sample: 'Character Progression & Strategic Goals',
    },
    {
      key: 'bodyFont',
      label: 'Primary Body Text Font',
      sample: 'Clean, legible typography designed for calm daily focus.',
    },
    {
      key: 'taskFont',
      label: 'Task & Habit Names Font',
      sample: 'Complete 30 Analytical Physics Problems',
    },
    {
      key: 'notesFont',
      label: 'Second Brain Notes Font',
      sample: 'Parallel Axis Theorem: I = I_cm + M*d^2',
    },
    {
      key: 'characterFont',
      label: 'Character Sheet Identity Font',
      sample: 'Aiden Vance · Level 5 Strategist',
    },
    {
      key: 'journalFont',
      label: 'Personal Journal Font (Handwriting Supported)',
      sample: 'Morning clarity compounds into lifelong mastery.',
    },
    {
      key: 'handwritingFont',
      label: 'Decorative & Handwritten Compendium Font',
      sample: 'Handwritten derivation & reflection notes.',
    },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            System Studio & Customization Center
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            Customize themes, independent font slots, navigation structure, data backups, and Android APK project packaging.
          </p>
        </div>

        <div className="inline-flex flex-wrap rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1">
          {[
            { id: 'themes', label: 'Theme Studio', icon: 'Palette' },
            { id: 'typography', label: 'Typography Studio', icon: 'Type' },
            { id: 'navigation', label: 'Navigation', icon: 'Layout' },
            { id: 'android-export', label: 'Android APK & Backup', icon: 'Smartphone' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as typeof activeTab)}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                activeTab === t.id
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)]'
              }`}
            >
              <AscendIcon name={t.icon} size={14} />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: THEME STUDIO */}
      {activeTab === 'themes' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Saved Themes */}
          <div className="lg:col-span-7 space-y-4">
            <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Saved Themes ({state.themes.length})
            </h2>
            <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
              {state.themes.map((th) => {
                const isActive = th.id === state.activeThemeId;
                return (
                  <div
                    key={th.id}
                    className={`flex flex-col justify-between rounded-2xl border p-4 transition ${
                      isActive
                        ? 'border-[var(--accent-primary)] ring-2 ring-[var(--accent-primary)]/30'
                        : 'border-[var(--border-subtle)]'
                    }`}
                    style={{
                      backgroundColor: th.bgSurface,
                      color: th.textPrimary,
                    }}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold">{th.name}</span>
                        <span
                          className="rounded-full px-2 py-0.5 text-[10px] font-bold text-white"
                          style={{ backgroundColor: th.accentPrimary }}
                        >
                          {th.mode.toUpperCase()}
                        </span>
                      </div>

                      {/* Swatch Preview */}
                      <div className="mt-3 flex items-center gap-2">
                        {[
                          th.bgCanvas,
                          th.bgSurface,
                          th.bgElevated,
                          th.textPrimary,
                          th.accentPrimary,
                        ].map((c, i) => (
                          <span
                            key={i}
                            className="h-6 w-6 rounded-full border border-black/15"
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="mt-4 flex items-center justify-between pt-3">
                      <button
                        onClick={() => setActiveTheme(th.id)}
                        className="rounded-xl px-3.5 py-1.5 text-xs font-bold text-white"
                        style={{ backgroundColor: th.accentPrimary }}
                      >
                        {isActive ? 'Active Theme' : 'Apply Theme'}
                      </button>

                      {state.themes.length > 2 &&
                        th.id.startsWith('theme-custom') && (
                          <button
                            onClick={() => deleteCustomTheme(th.id)}
                            className="text-xs font-semibold text-rose-500"
                          >
                            Delete
                          </button>
                        )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Custom Theme Builder */}
          <div className="lg:col-span-5 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5 space-y-3.5 h-fit">
            <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Create & Save Custom Theme
            </h2>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Theme Name
              </label>
              <input
                type="text"
                value={customThemeDraft.name}
                onChange={(e) =>
                  setCustomThemeDraft({
                    ...customThemeDraft,
                    name: e.target.value,
                  })
                }
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              {[
                { key: 'bgCanvas', label: 'Background Canvas' },
                { key: 'bgSurface', label: 'Card Surface' },
                { key: 'bgElevated', label: 'Secondary Surface' },
                { key: 'textPrimary', label: 'Primary Text' },
                { key: 'textSecondary', label: 'Secondary Text' },
                { key: 'accentPrimary', label: 'Primary Accent' },
              ].map((field) => (
                <div key={field.key}>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    {field.label}
                  </label>
                  <div className="mt-1 flex items-center gap-2">
                    <input
                      type="color"
                      value={
                        customThemeDraft[
                          field.key as keyof CustomTheme
                        ] as string
                      }
                      onChange={(e) =>
                        setCustomThemeDraft({
                          ...customThemeDraft,
                          [field.key]: e.target.value,
                        })
                      }
                      className="h-8 w-10 cursor-pointer rounded border border-[var(--border-subtle)]"
                    />
                    <span className="font-mono-metric text-xs text-[var(--text-primary)]">
                      {
                        customThemeDraft[
                          field.key as keyof CustomTheme
                        ] as string
                      }
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() =>
                saveCustomTheme({
                  ...customThemeDraft,
                  id: `theme-custom-${Date.now()}`,
                })
              }
              className="w-full rounded-xl bg-[var(--accent-primary)] py-2.5 text-xs font-bold text-white"
            >
              Save & Activate Custom Theme
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: TYPOGRAPHY STUDIO */}
      {activeTab === 'typography' && (
        <div className="space-y-6">
          {/* Global Weight & Scale Controls */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Global Font Weight & Scale Calibration
            </h2>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Heading Font Weight
                </label>
                <select
                  value={state.typography.headingWeight}
                  onChange={(e) =>
                    updateTypography({
                      headingWeight: e.target.value as TypographyConfig['headingWeight'],
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                >
                  <option value="500">Medium (500)</option>
                  <option value="600">Semi-Bold (600)</option>
                  <option value="700">Bold (700)</option>
                  <option value="800">Extra-Bold (800)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Application Text Scale ({Math.round(state.typography.bodyScale * 100)}%)
                </label>
                <input
                  type="range"
                  min={0.9}
                  max={1.1}
                  step={0.05}
                  value={state.typography.bodyScale}
                  onChange={(e) =>
                    updateTypography({ bodyScale: Number(e.target.value) })
                  }
                  className="mt-3 w-full accent-[var(--accent-primary)]"
                />
              </div>

              <div className="flex flex-col justify-center gap-2">
                <label className="flex items-center gap-2 text-xs text-[var(--text-primary)] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={state.typography.useHandwritingInJournal}
                    onChange={(e) =>
                      updateTypography({
                        useHandwritingInJournal: e.target.checked,
                      })
                    }
                  />
                  Default Handwriting Font in Journal
                </label>
                <label className="flex items-center gap-2 text-xs text-[var(--text-primary)] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={state.typography.useHandwritingInNotes}
                    onChange={(e) =>
                      updateTypography({
                        useHandwritingInNotes: e.target.checked,
                      })
                    }
                  />
                  Default Handwriting Font in Notes
                </label>
              </div>
            </div>
          </div>

          {/* 8 Independent Font Slots */}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {typographySlots.map((slot) => {
              const selectedFont = state.typography[slot.key] as string;
              return (
                <div
                  key={slot.key}
                  className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-xs font-bold text-[var(--text-primary)]">
                      {slot.label}
                    </label>
                    <select
                      value={selectedFont}
                      onChange={(e) =>
                        updateTypography({ [slot.key]: e.target.value })
                      }
                      className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-semibold text-[var(--accent-primary)]"
                    >
                      <optgroup label="Modern Sans-Serif">
                        {MODERN_FONTS.map((f) => (
                          <option key={f} value={f}>
                            {f}
                          </option>
                        ))}
                      </optgroup>
                      <optgroup label="Handwriting & Script">
                        {HANDWRITING_FONTS.map((f) => (
                          <option key={f} value={f}>
                            {f}
                          </option>
                        ))}
                      </optgroup>
                    </select>
                  </div>

                  {/* Live Rendered Font Specimen */}
                  <div
                    className="mt-3 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3 text-base text-[var(--text-primary)]"
                    style={{ fontFamily: `'${selectedFont}', sans-serif` }}
                  >
                    {slot.sample}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: NAVIGATION CUSTOMIZER */}
      {activeTab === 'navigation' && (
        <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
          <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
            Customize Application Navigation
          </h2>
          <p className="text-xs text-[var(--text-secondary)]">
            Reorder modules, hide sections you do not currently use, or pin up to 5 modules to your Mobile Bottom Bar.
          </p>

          <div className="mt-4 grid grid-cols-1 gap-2.5 md:grid-cols-2">
            {sortedNav.map((item, idx) => (
              <div
                key={item.id}
                className="flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 px-3.5 py-2.5"
              >
                <div className="flex items-center gap-2.5">
                  <AscendIcon
                    name={item.icon}
                    size={16}
                    className="text-[var(--accent-primary)]"
                  />
                  <div>
                    <div className="text-xs font-bold text-[var(--text-primary)]">
                      {item.label}
                    </div>
                    <div className="text-[10px] text-[var(--text-secondary)]">
                      Group: {item.group}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() =>
                      updateNavigation(
                        state.navigation.map((n) =>
                          n.id === item.id ? { ...n, pinned: !n.pinned } : n
                        )
                      )
                    }
                    className={`rounded-lg px-2 py-1 text-[10px] font-bold transition ${
                      item.pinned
                        ? 'bg-[var(--accent-primary)] text-white'
                        : 'border border-[var(--border-subtle)] bg-[var(--bg-surface)] text-[var(--text-secondary)]'
                    }`}
                  >
                    {item.pinned ? 'Pinned' : 'Pin'}
                  </button>

                  <button
                    disabled={item.id === 'home' || item.id === 'settings'}
                    onClick={() =>
                      updateNavigation(
                        state.navigation.map((n) =>
                          n.id === item.id ? { ...n, visible: !n.visible } : n
                        )
                      )
                    }
                    className={`rounded-lg px-2 py-1 text-[10px] font-bold ${
                      item.visible
                        ? 'bg-emerald-500/15 text-emerald-500'
                        : 'bg-rose-500/15 text-rose-500'
                    }`}
                  >
                    {item.visible ? 'Visible' : 'Hidden'}
                  </button>

                  <button
                    disabled={idx === 0}
                    onClick={() => moveNavOrder(item.id, -1)}
                    className="rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1 disabled:opacity-30"
                  >
                    <AscendIcon name="ChevronUp" size={13} />
                  </button>
                  <button
                    disabled={idx === sortedNav.length - 1}
                    onClick={() => moveNavOrder(item.id, 1)}
                    className="rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1 disabled:opacity-30"
                  >
                    <AscendIcon name="ChevronDown" size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: ANDROID APK GRADLE PACKAGE GENERATOR & DATA BACKUP */}
      {activeTab === 'android-export' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Android APK / Gradle Project Exporter */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent-primary)]">
                <AscendIcon name="Smartphone" size={24} />
              </div>
              <div>
                <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                  Android Studio & Gradle Project Exporter
                </h2>
                <p className="text-xs text-[var(--text-secondary)]">
                  Generate and download a complete, non-nested `MyAndroidApp-Ready.zip` package configured for Android APK compilation.
                </p>
              </div>
            </div>

            <div className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/50 p-3.5 font-mono-metric text-[11px] text-[var(--text-secondary)] space-y-1">
              <div>MyAndroidApp-Ready.zip (Root-level structure):</div>
              <div>├── settings.gradle &amp; build.gradle (AGP 8.2.2)</div>
              <div>├── gradlew, gradlew.bat &amp; gradle.properties</div>
              <div>├── app/build.gradle (applicationId: com.ascendos.app, SDK 24-34)</div>
              <div>├── app/src/main/AndroidManifest.xml</div>
              <div>├── app/src/main/java/com/ascendos/app/MainActivity.java</div>
              <div>└── README.md (Exact APK Build Instructions)</div>
            </div>

            {zipStatus && (
              <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-xs text-emerald-500">
                {zipStatus}
              </div>
            )}

            <button
              onClick={handleGenerateAndroidReadyZip}
              disabled={isGeneratingZip}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[var(--accent-primary)] py-3 text-xs font-bold text-white shadow-sm transition hover:opacity-95"
            >
              <AscendIcon name="Download" size={16} />
              {isGeneratingZip
                ? 'Packaging MyAndroidApp-Ready.zip...'
                : 'Download MyAndroidApp-Ready.zip'}
            </button>
          </div>

          {/* Full JSON Database Backup & Restore */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent-primary)]">
                <AscendIcon name="Database" size={24} />
              </div>
              <div>
                <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                  Ascend OS Database Backup & Restore
                </h2>
                <p className="text-xs text-[var(--text-secondary)]">
                  Export your entire Character Sheet, XP Ledger, Habits, Goals, and Second Brain as a portable JSON file.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 pt-2">
              <button
                onClick={handleExportJson}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] py-3 text-xs font-bold text-[var(--text-primary)] hover:border-[var(--accent-primary)]"
              >
                <AscendIcon name="Download" size={15} />
                Export Full Backup (.json)
              </button>

              <label className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] py-3 text-xs font-bold text-[var(--text-primary)] hover:border-[var(--accent-primary)]">
                <AscendIcon name="Upload" size={15} />
                Import Backup (.json)
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportJson}
                  className="hidden"
                />
              </label>
            </div>

            <div className="border-t border-[var(--border-subtle)] pt-4">
              <button
                onClick={resetToDefaults}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-rose-500 hover:underline"
              >
                <AscendIcon name="RotateCcw" size={14} />
                Reset Ascend OS to Default Starter Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
