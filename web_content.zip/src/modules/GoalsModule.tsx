import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon, PICKABLE_ICONS } from '../components/AscendIcon';
import { calculateGoalProgress } from '../utils/progressionEngine';
import { GoalItem } from '../types/ascend';
import { getFutureDateStr, getTodayStr } from '../data/initialAscendState';

export const GoalsModule: React.FC = () => {
  const {
    state,
    saveGoal,
    deleteGoal,
    toggleGoalMilestone,
    addGoalCategory,
  } = useAscend();

  const [statusFilter, setStatusFilter] = useState<string>('Active');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [editingGoal, setEditingGoal] = useState<GoalItem | null>(null);
  const [newMilestoneInputs, setNewMilestoneInputs] = useState<Record<string, string>>({});
  const [newCatInput, setNewCatInput] = useState('');

  const filteredGoals = state.goals.filter((g) => {
    const matchStatus = statusFilter === 'All' || g.status === statusFilter;
    const matchCat = categoryFilter === 'All' || g.category === categoryFilter;
    return matchStatus && matchCat;
  });

  const handleOpenNewGoal = () => {
    setEditingGoal({
      id: `goal-${Date.now()}`,
      title: '',
      description: '',
      category: state.goalCategories[0] || 'Education',
      icon: 'Target',
      color: '#7C5CFC',
      startDate: getTodayStr(),
      targetDate: getFutureDateStr(30),
      priority: 'High',
      status: 'Active',
      milestones: [
        {
          id: `ms-${Date.now()}-1`,
          title: 'Define Key Success Architecture & First Benchmark',
          completed: false,
          xpReward: state.xpSettings.defaultMilestoneXp,
        },
      ],
      notes: '',
      attributeIds: ['attr-int', 'attr-dis'],
      domainId: state.domains[0]?.id,
      xpReward: state.xpSettings.defaultGoalXp,
    });
  };

  const handleDuplicateGoal = (goal: GoalItem) => {
    const dup: GoalItem = {
      ...goal,
      id: `goal-${Date.now()}`,
      title: `${goal.title} (Copy)`,
      status: 'Active',
      milestones: goal.milestones.map((m, idx) => ({
        ...m,
        id: `ms-${Date.now()}-${idx}`,
        completed: false,
      })),
    };
    saveGoal(dup);
  };

  const handleAddInlineMilestone = (goal: GoalItem) => {
    const title = (newMilestoneInputs[goal.id] || '').trim();
    if (!title) return;
    const updated: GoalItem = {
      ...goal,
      milestones: [
        ...goal.milestones,
        {
          id: `ms-${Date.now()}`,
          title,
          completed: false,
          xpReward: state.xpSettings.defaultMilestoneXp,
        },
      ],
    };
    saveGoal(updated);
    setNewMilestoneInputs({ ...newMilestoneInputs, [goal.id]: '' });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            Strategic Goal Architecture
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            Connect long-horizon goals to milestones, daily habits, tasks, projects, and character attributes.
          </p>
        </div>

        <button
          onClick={handleOpenNewGoal}
          className="inline-flex items-center gap-2 rounded-xl bg-[var(--accent-primary)] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:opacity-95"
        >
          <AscendIcon name="Plus" size={16} />
          Create New Goal
        </button>
      </div>

      {/* Filters & Category Creator */}
      <div className="flex flex-col gap-3 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-1.5">
          {['Active', 'Completed', 'Paused', 'Archived', 'All'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                statusFilter === st
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs text-[var(--text-primary)]"
          >
            <option value="All">All Categories</option>
            {state.goalCategories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newCatInput.trim()) return;
              addGoalCategory(newCatInput);
              setNewCatInput('');
            }}
            className="flex items-center gap-1.5"
          >
            <input
              type="text"
              placeholder="New category..."
              value={newCatInput}
              onChange={(e) => setNewCatInput(e.target.value)}
              className="w-32 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1.5 text-xs text-[var(--text-primary)]"
            />
            <button
              type="submit"
              className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1.5 text-xs font-semibold text-[var(--text-primary)]"
            >
              + Cat
            </button>
          </form>
        </div>
      </div>

      {/* Goals List */}
      <div className="grid grid-cols-1 gap-5">
        {filteredGoals.map((goal) => {
          const linkedTasks = state.tasks.filter((t) => t.linkedGoalId === goal.id);
          const linkedHabits = state.habits.filter((h) => h.linkedGoalId === goal.id);
          const linkedProjects = state.projects.filter(
            (p) => p.linkedGoalId === goal.id
          );
          const linkedAttrs = state.attributes.filter((a) =>
            goal.attributeIds.includes(a.id)
          );
          const pct = calculateGoalProgress(goal, linkedTasks);

          return (
            <div
              key={goal.id}
              className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5 sm:p-6"
            >
              <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                <div className="flex items-start gap-3.5">
                  <div
                    className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-white"
                    style={{ backgroundColor: goal.color || '#7C5CFC' }}
                  >
                    <AscendIcon name={goal.icon} size={22} />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-subheading text-lg font-bold text-[var(--text-primary)]">
                        {goal.title}
                      </h2>
                      <span className="rounded-full bg-[var(--bg-elevated)] px-2.5 py-0.5 text-xs font-medium text-[var(--text-secondary)]">
                        {goal.category}
                      </span>
                      <span className="rounded-full border border-[var(--border-subtle)] px-2.5 py-0.5 text-xs font-semibold text-[var(--text-primary)]">
                        {goal.priority} Priority
                      </span>
                      <span className="font-mono-metric rounded-full bg-[var(--accent-soft)] px-2.5 py-0.5 text-xs font-bold text-[var(--accent-primary)]">
                        +{goal.xpReward} XP Completion
                      </span>
                    </div>
                    <p className="mt-1 text-xs sm:text-sm text-[var(--text-secondary)]">
                      {goal.description}
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-[var(--text-secondary)]">
                      <span className="font-mono-metric">
                        Start: {goal.startDate} → Target: {goal.targetDate}
                      </span>
                      <span>·</span>
                      <span>
                        Linked: {linkedHabits.length} Habits, {linkedTasks.length} Tasks,{' '}
                        {linkedProjects.length} Projects
                      </span>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {linkedAttrs.map((a) => (
                        <span
                          key={a.id}
                          className="font-mono-metric rounded-md border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2 py-0.5 text-[10px] font-bold text-[var(--text-primary)]"
                        >
                          {a.code} ({a.name})
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Goal Action Controls */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setEditingGoal(goal)}
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-medium text-[var(--text-primary)] hover:border-[var(--accent-primary)]"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDuplicateGoal(goal)}
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
                  >
                    Duplicate
                  </button>
                  <select
                    value={goal.status}
                    onChange={(e) =>
                      saveGoal({
                        ...goal,
                        status: e.target.value as GoalItem['status'],
                      })
                    }
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1.5 text-xs font-semibold text-[var(--text-primary)]"
                  >
                    <option value="Active">Active</option>
                    <option value="Completed">Completed</option>
                    <option value="Paused">Paused</option>
                    <option value="Archived">Archived</option>
                  </select>
                </div>
              </div>

              {/* Overall Goal Progress Bar */}
              <div className="mt-5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[var(--text-primary)]">
                    Milestone & Linked Task Completion
                  </span>
                  <span className="font-mono-metric text-sm font-bold text-[var(--accent-primary)]">
                    {pct}%
                  </span>
                </div>
                <div className="mt-1.5 h-2.5 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${pct}%`,
                      backgroundColor: goal.color || 'var(--accent-primary)',
                    }}
                  />
                </div>
              </div>

              {/* Interactive Milestones List */}
              <div className="mt-5 space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)]">
                  Milestones ({goal.milestones.filter((m) => m.completed).length}/
                  {goal.milestones.length})
                </h3>
                {goal.milestones.map((ms) => (
                  <div
                    key={ms.id}
                    className="flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 px-3.5 py-2.5"
                  >
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => toggleGoalMilestone(goal.id, ms.id)}
                        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition ${
                          ms.completed
                            ? 'border-emerald-500 bg-emerald-500 text-white'
                            : 'border-[var(--border-subtle)] bg-[var(--bg-surface)]'
                        }`}
                      >
                        {ms.completed && (
                          <AscendIcon name="CheckCircle2" size={13} />
                        )}
                      </button>
                      <span
                        className={`text-xs font-medium ${
                          ms.completed
                            ? 'line-through text-[var(--text-secondary)]'
                            : 'text-[var(--text-primary)]'
                        }`}
                      >
                        {ms.title}
                      </span>
                    </div>
                    <span className="font-mono-metric rounded bg-[var(--accent-soft)] px-2 py-0.5 text-[10px] font-semibold text-[var(--accent-primary)]">
                      +{ms.xpReward} XP
                    </span>
                  </div>
                ))}

                {/* Add Milestone Inline */}
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    placeholder="Add new milestone to this goal..."
                    value={newMilestoneInputs[goal.id] || ''}
                    onChange={(e) =>
                      setNewMilestoneInputs({
                        ...newMilestoneInputs,
                        [goal.id]: e.target.value,
                      })
                    }
                    className="flex-1 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                  <button
                    onClick={() => handleAddInlineMilestone(goal)}
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-3.5 py-2 text-xs font-semibold text-[var(--accent-primary)] hover:border-[var(--accent-primary)]"
                  >
                    + Add Milestone
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Goal Editor Modal */}
      {editingGoal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
          <div className="my-8 w-full max-w-lg rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                Configure Strategic Goal
              </h3>
              <button
                onClick={() => setEditingGoal(null)}
                className="text-[var(--text-secondary)]"
              >
                <AscendIcon name="X" size={18} />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Goal Title
                </label>
                <input
                  type="text"
                  placeholder="e.g., Master Multivariable Calculus"
                  value={editingGoal.title}
                  onChange={(e) =>
                    setEditingGoal({ ...editingGoal, title: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>

              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Description & Success Criteria
                </label>
                <textarea
                  rows={2}
                  value={editingGoal.description}
                  onChange={(e) =>
                    setEditingGoal({
                      ...editingGoal,
                      description: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Category
                  </label>
                  <select
                    value={editingGoal.category}
                    onChange={(e) =>
                      setEditingGoal({ ...editingGoal, category: e.target.value })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    {state.goalCategories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Priority
                  </label>
                  <select
                    value={editingGoal.priority}
                    onChange={(e) =>
                      setEditingGoal({
                        ...editingGoal,
                        priority: e.target.value as GoalItem['priority'],
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Critical">Critical</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Custom XP Reward
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editingGoal.xpReward}
                    onChange={(e) =>
                      setEditingGoal({
                        ...editingGoal,
                        xpReward: Math.max(0, Number(e.target.value) || 0),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={editingGoal.startDate}
                    onChange={(e) =>
                      setEditingGoal({
                        ...editingGoal,
                        startDate: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Target Date
                  </label>
                  <input
                    type="date"
                    value={editingGoal.targetDate}
                    onChange={(e) =>
                      setEditingGoal({
                        ...editingGoal,
                        targetDate: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Accent Color
                  </label>
                  <input
                    type="color"
                    value={editingGoal.color}
                    onChange={(e) =>
                      setEditingGoal({ ...editingGoal, color: e.target.value })
                    }
                    className="mt-1 h-9 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-1"
                  />
                </div>
              </div>

              {/* Associated Character Attributes */}
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Linked Character Attributes (Receive XP when goal/milestones progress)
                </label>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {state.attributes.map((attr) => {
                    const selected = editingGoal.attributeIds.includes(attr.id);
                    return (
                      <button
                        type="button"
                        key={attr.id}
                        onClick={() => {
                          const nextIds = selected
                            ? editingGoal.attributeIds.filter((i) => i !== attr.id)
                            : [...editingGoal.attributeIds, attr.id];
                          setEditingGoal({ ...editingGoal, attributeIds: nextIds });
                        }}
                        className={`rounded-lg border px-2 py-1 text-[11px] font-semibold transition ${
                          selected
                            ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                            : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                        }`}
                      >
                        {attr.code} · {attr.name}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Icon
                </label>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {PICKABLE_ICONS.slice(0, 14).map((ic) => (
                    <button
                      type="button"
                      key={ic}
                      onClick={() => setEditingGoal({ ...editingGoal, icon: ic })}
                      className={`flex h-8 w-8 items-center justify-center rounded-lg border ${
                        editingGoal.icon === ic
                          ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                          : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                      }`}
                    >
                      <AscendIcon name={ic} size={15} />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteGoal(editingGoal.id);
                  setEditingGoal(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Goal
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingGoal(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingGoal.title.trim()) return;
                    saveGoal(editingGoal);
                    setEditingGoal(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Goal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
