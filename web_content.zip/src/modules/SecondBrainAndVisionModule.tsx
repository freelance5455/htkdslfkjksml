import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon, PICKABLE_ICONS } from '../components/AscendIcon';
import { getTodayStr } from '../data/initialAscendState';
import { SecondBrainNote, VisionBoardItem } from '../types/ascend';

export const SecondBrainAndVisionModule: React.FC = () => {
  const {
    state,
    saveNote,
    deleteNote,
    saveVisionItem,
    deleteVisionItem,
  } = useAscend();

  const [activeTab, setActiveTab] = useState<'second-brain' | 'vision-board'>(
    'second-brain'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [catFilter, setCatFilter] = useState<string>('All');
  const [editingNote, setEditingNote] = useState<SecondBrainNote | null>(null);
  const [editingVision, setEditingVision] = useState<VisionBoardItem | null>(
    null
  );

  const filteredNotes = state.notes
    .filter((n) => {
      const matchCat = catFilter === 'All' || n.category === catFilter;
      const q = searchQuery.toLowerCase();
      const matchSearch =
        !q ||
        n.title.toLowerCase().includes(q) ||
        n.content.toLowerCase().includes(q) ||
        n.folder.toLowerCase().includes(q) ||
        n.tags.some((t) => t.toLowerCase().includes(q));
      return matchCat && matchSearch;
    })
    .sort((a, b) => Number(b.pinned) - Number(a.pinned));

  const handleOpenNewNote = () => {
    setEditingNote({
      id: `note-${Date.now()}`,
      title: '',
      category: 'Learning Note',
      folder: 'General Vault',
      content: '',
      tags: ['Knowledge'],
      pinned: false,
      updatedAt: getTodayStr(),
      linkedGoalId: state.goals[0]?.id,
      useHandwriting: state.typography.useHandwritingInNotes,
    });
  };

  const handleOpenNewVision = () => {
    setEditingVision({
      id: `vb-${Date.now()}`,
      title: '',
      pillar: 'Education & Mastery',
      statement: '',
      targetTimeframe: '2025 - 2026',
      icon: 'Crown',
      accentColor: '#7C5CFC',
      linkedGoalId: state.goals[0]?.id,
      achieved: false,
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            {activeTab === 'second-brain'
              ? 'Second Brain Knowledge Architecture'
              : 'North Star Vision Board'}
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            {activeTab === 'second-brain'
              ? 'Organize lecture notes, book syntheses, ideas, and resources connected to your goals and skill tree.'
              : 'Visualize long-term identity pillars and connect them to concrete execution goals.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1">
            <button
              onClick={() => setActiveTab('second-brain')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                activeTab === 'second-brain'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)]'
              }`}
            >
              <AscendIcon name="Brain" size={14} />
              Second Brain ({state.notes.length})
            </button>
            <button
              onClick={() => setActiveTab('vision-board')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                activeTab === 'vision-board'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)]'
              }`}
            >
              <AscendIcon name="Sparkles" size={14} />
              Vision Board ({state.visionBoard.length})
            </button>
          </div>

          {activeTab === 'second-brain' ? (
            <button
              onClick={handleOpenNewNote}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Plus" size={15} />
              New Note
            </button>
          ) : (
            <button
              onClick={handleOpenNewVision}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Plus" size={15} />
              Add Vision Pillar
            </button>
          )}
        </div>
      </div>

      {/* VIEW 1: SECOND BRAIN */}
      {activeTab === 'second-brain' && (
        <div className="space-y-5">
          <div className="flex flex-col gap-3 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                'All',
                'Learning Note',
                'Book Note',
                'Idea',
                'Resource',
                'Note',
              ].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCatFilter(cat)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                    catFilter === cat
                      ? 'bg-[var(--accent-primary)] text-white'
                      : 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="relative">
              <input
                type="text"
                placeholder="Search notes, folders, tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full sm:w-64 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] pl-8 pr-3 py-1.5 text-xs text-[var(--text-primary)]"
              />
              <AscendIcon
                name="Search"
                size={14}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
            {filteredNotes.map((note) => {
              const linkedGoal = state.goals.find(
                (g) => g.id === note.linkedGoalId
              );
              const linkedSubject = state.subjects.find(
                (s) => s.id === note.linkedSubjectId
              );

              return (
                <div
                  key={note.id}
                  className="flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="rounded-md bg-[var(--accent-soft)] px-2 py-0.5 text-[10px] font-bold text-[var(--accent-primary)]">
                            {note.category}
                          </span>
                          <span className="inline-flex items-center gap-1 rounded-md bg-[var(--bg-elevated)] px-2 py-0.5 text-[10px] font-medium text-[var(--text-secondary)]">
                            <AscendIcon name="Folder" size={11} />
                            {note.folder}
                          </span>
                          {note.pinned && (
                            <span className="rounded-md bg-amber-500/15 px-2 py-0.5 text-[10px] font-bold text-amber-500">
                              Pinned
                            </span>
                          )}
                        </div>
                        <h3 className="mt-2 font-subheading text-base font-bold text-[var(--text-primary)]">
                          {note.title}
                        </h3>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() =>
                            saveNote({
                              ...note,
                              useHandwriting: !note.useHandwriting,
                            })
                          }
                          className="rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1 text-[10px] font-semibold text-[var(--text-primary)]"
                          title="Toggle Handwritten Compendium View"
                        >
                          {note.useHandwriting ? 'Sans View' : 'Handwritten'}
                        </button>
                        <button
                          onClick={() => setEditingNote(note)}
                          className="text-xs font-medium text-[var(--accent-primary)]"
                        >
                          Edit
                        </button>
                      </div>
                    </div>

                    <div
                      className={`mt-3 whitespace-pre-line rounded-xl p-3.5 ${
                        note.useHandwriting
                          ? 'notebook-paper font-handwriting-custom text-lg text-[var(--text-primary)] bg-[var(--bg-elevated)]/40'
                          : 'font-notes-custom text-xs leading-relaxed text-[var(--text-secondary)] bg-[var(--bg-elevated)]/30'
                      }`}
                    >
                      {note.content}
                    </div>
                  </div>

                  <div className="mt-4 border-t border-[var(--border-subtle)] pt-3 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                    <div className="flex flex-wrap gap-1.5">
                      {linkedGoal && (
                        <span className="rounded bg-[var(--bg-elevated)] px-2 py-0.5 text-[var(--accent-primary)] font-medium">
                          Goal: {linkedGoal.title}
                        </span>
                      )}
                      {linkedSubject && (
                        <span className="rounded bg-[var(--bg-elevated)] px-2 py-0.5 text-[var(--text-primary)]">
                          Subject: {linkedSubject.name}
                        </span>
                      )}
                      {note.tags.map((tg) => (
                        <span
                          key={tg}
                          className="text-[var(--text-secondary)]"
                        >
                          #{tg}
                        </span>
                      ))}
                    </div>
                    <span className="font-mono-metric text-[var(--text-muted)]">
                      {note.updatedAt}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: VISION BOARD */}
      {activeTab === 'vision-board' && (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
          {state.visionBoard.map((vb) => {
            const linkedGoal = state.goals.find(
              (g) => g.id === vb.linkedGoalId
            );

            return (
              <div
                key={vb.id}
                className="flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div
                      className="flex h-12 w-12 items-center justify-center rounded-2xl text-white"
                      style={{ backgroundColor: vb.accentColor }}
                    >
                      <AscendIcon name={vb.icon} size={22} />
                    </div>
                    <span className="font-mono-metric rounded-full bg-[var(--bg-elevated)] px-2.5 py-1 text-[11px] font-semibold text-[var(--text-secondary)]">
                      {vb.targetTimeframe}
                    </span>
                  </div>

                  <div className="mt-4">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--accent-primary)]">
                      {vb.pillar}
                    </span>
                    <h3 className="mt-1 font-heading text-lg font-bold text-[var(--text-primary)]">
                      {vb.title}
                    </h3>
                    <p className="mt-2 font-journal-custom text-xl text-[var(--text-secondary)]">
                      "{vb.statement}"
                    </p>
                  </div>
                </div>

                <div className="mt-5 border-t border-[var(--border-subtle)] pt-3 flex items-center justify-between text-xs">
                  <span className="truncate text-[var(--text-secondary)]">
                    {linkedGoal ? `Linked: ${linkedGoal.title}` : 'Identity Pillar'}
                  </span>
                  <button
                    onClick={() => setEditingVision(vb)}
                    className="font-semibold text-[var(--accent-primary)]"
                  >
                    Edit
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Note Editor Modal */}
      {editingNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
          <div className="my-8 w-full max-w-xl rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Second Brain Note & Relational Links
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Note Title
                </label>
                <input
                  type="text"
                  value={editingNote.title}
                  onChange={(e) =>
                    setEditingNote({ ...editingNote, title: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Category
                  </label>
                  <select
                    value={editingNote.category}
                    onChange={(e) =>
                      setEditingNote({
                        ...editingNote,
                        category: e.target.value as SecondBrainNote['category'],
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="Learning Note">Learning Note</option>
                    <option value="Book Note">Book Note</option>
                    <option value="Idea">Idea</option>
                    <option value="Resource">Resource</option>
                    <option value="Note">Note</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Folder / Collection
                  </label>
                  <input
                    type="text"
                    value={editingNote.folder}
                    onChange={(e) =>
                      setEditingNote({ ...editingNote, folder: e.target.value })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Content / Synthesis
                  </label>
                  <label className="flex items-center gap-1.5 text-xs text-[var(--accent-primary)] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={Boolean(editingNote.useHandwriting)}
                      onChange={(e) =>
                        setEditingNote({
                          ...editingNote,
                          useHandwriting: e.target.checked,
                        })
                      }
                    />
                    Handwritten Lecture Note Style
                  </label>
                </div>
                <textarea
                  rows={5}
                  value={editingNote.content}
                  onChange={(e) =>
                    setEditingNote({ ...editingNote, content: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-3 text-xs text-[var(--text-primary)]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Linked Strategic Goal
                  </label>
                  <select
                    value={editingNote.linkedGoalId || ''}
                    onChange={(e) =>
                      setEditingNote({
                        ...editingNote,
                        linkedGoalId: e.target.value || undefined,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="">None</option>
                    {state.goals.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.title}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Linked Education Subject
                  </label>
                  <select
                    value={editingNote.linkedSubjectId || ''}
                    onChange={(e) =>
                      setEditingNote({
                        ...editingNote,
                        linkedSubjectId: e.target.value || undefined,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="">None</option>
                    {state.subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteNote(editingNote.id);
                  setEditingNote(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Note
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingNote(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingNote.title.trim()) return;
                    saveNote({ ...editingNote, updatedAt: getTodayStr() });
                    setEditingNote(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Note
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Vision Editor Modal */}
      {editingVision && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Configure Vision Board Pillar
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Vision Title
                </label>
                <input
                  type="text"
                  value={editingVision.title}
                  onChange={(e) =>
                    setEditingVision({ ...editingVision, title: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  North Star Statement
                </label>
                <textarea
                  rows={3}
                  value={editingVision.statement}
                  onChange={(e) =>
                    setEditingVision({
                      ...editingVision,
                      statement: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-3 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Pillar
                  </label>
                  <input
                    type="text"
                    value={editingVision.pillar}
                    onChange={(e) =>
                      setEditingVision({
                        ...editingVision,
                        pillar: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Timeframe
                  </label>
                  <input
                    type="text"
                    value={editingVision.targetTimeframe}
                    onChange={(e) =>
                      setEditingVision({
                        ...editingVision,
                        targetTimeframe: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Icon
                </label>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {PICKABLE_ICONS.slice(0, 12).map((ic) => (
                    <button
                      type="button"
                      key={ic}
                      onClick={() =>
                        setEditingVision({ ...editingVision, icon: ic })
                      }
                      className={`flex h-8 w-8 items-center justify-center rounded-lg border ${
                        editingVision.icon === ic
                          ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                          : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                      }`}
                    >
                      <AscendIcon name={ic} size={15} />
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteVisionItem(editingVision.id);
                  setEditingVision(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Vision
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingVision(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingVision.title.trim()) return;
                    saveVisionItem(editingVision);
                    setEditingVision(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Vision
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
