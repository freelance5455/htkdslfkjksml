/**
 * weeklyReviewService.js — the Sunday ritual: reflections + auto metrics snapshot.
 * v2: each review also stores that week's full statistics (statsForWeek) so the
 * Weekly Review tab can chart your progress week after week.
 */

import { getAll, put, newId } from '../../../core/storage/storageService.js';
import { startOfWeekISO } from '../../../core/utils/dateUtils.js';
import { computeLifeScore } from '../../../core/scoring/scoreEngine.js';
import { statsForWeek } from '../../../core/stats/statsService.js';
import { emit } from '../../../core/utils/eventBus.js';

export async function submitWeeklyReview({ wins, misses, adjustments, rating = null, lesson = '' }) {
  const metricsSnapshot = await computeLifeScore();
  const weekStats = await statsForWeek(startOfWeekISO());
  const existing = (await getAll('weeklyReviews')).find((r) => r.weekStartDate === startOfWeekISO());
  const record = await put('weeklyReviews', {
    id: existing?.id || newId(),
    weekStartDate: startOfWeekISO(),
    reflections: { wins, misses, adjustments, lesson },
    rating,
    metricsSnapshot,
    weekStats,
  });
  if (!existing) emit('weeklyReview:completed', {});
  return record;
}

export async function getReviewHistory(limit = 8) {
  const all = await getAll('weeklyReviews');
  return all.sort((a, b) => (a.weekStartDate < b.weekStartDate ? 1 : -1)).slice(0, limit);
}

export async function getThisWeekReview() {
  return (await getAll('weeklyReviews')).find((r) => r.weekStartDate === startOfWeekISO()) || null;
}

export async function hasReviewedThisWeek() {
  return !!(await getThisWeekReview());
}
