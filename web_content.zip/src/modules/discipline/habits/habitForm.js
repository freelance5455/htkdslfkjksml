/**
 * habitForm.js — one bottom-sheet form to ADD or EDIT a habit/task of your own
 * (name, how often, which weekdays, which area). Replaces the old browser prompt.
 * Used by both Home and Discipline so the behaviour is identical everywhere.
 */
import { openSheet, closeSheet } from '../../../components/modal.js';
import { el, button, textInput, fieldLabel, chipSelect } from '../../../components/ui.js';
import { showToast } from '../../../core/notifications/toast.js';
import { FREQUENCY, createHabit, updateHabit, deleteHabit } from './habitsService.js';

const DOMAINS = [
  { label: 'Body', value: 'body' }, { label: 'Mind', value: 'mind' },
  { label: 'Discipline', value: 'discipline' }, { label: 'Presence', value: 'presence' },
];
const FREQS = [
  { label: 'Daily', value: FREQUENCY.DAILY }, { label: 'Weekly', value: FREQUENCY.WEEKLY },
  { label: 'Custom days', value: FREQUENCY.CUSTOM },
];
const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function openHabitForm({ habit = null, defaultFrequency = FREQUENCY.DAILY, onDone = () => {} } = {}) {
  let frequency = habit?.frequency || defaultFrequency;
  let domain = habit?.domain || 'discipline';
  let days = new Set(habit?.days?.length ? habit.days : [1, 2, 3, 4, 5]);

  openSheet(habit ? 'Edit task / habit' : 'Add your own task', (body) => {
    const name = textInput({ placeholder: 'e.g. Read 10 pages, Call mum, Gym', value: habit?.name || '' });
    const freqSlot = el('div');
    const domSlot = el('div');
    const daySlot = el('div');

    function draw() {
      freqSlot.replaceChildren(chipSelect(FREQS, frequency, (v) => { frequency = v; draw(); }));
      domSlot.replaceChildren(chipSelect(DOMAINS, domain, (v) => { domain = v; draw(); }));
      daySlot.replaceChildren();
      if (frequency === FREQUENCY.CUSTOM) {
        const row = el('div', 'chip-row');
        DAY_NAMES.forEach((d, i) => {
          const chip = el('button', `chip${days.has(i) ? ' chip--active' : ''}`, d);
          chip.addEventListener('click', () => { if (days.has(i)) days.delete(i); else days.add(i); draw(); });
          row.append(chip);
        });
        daySlot.append(el('div', 'field', [fieldLabel('Which days?'), row]));
      } else if (frequency === FREQUENCY.WEEKLY) {
        daySlot.append(el('p', 'text-xs text-dim', 'Weekly: counts as done once per week, any day.'));
      }
    }
    draw();

    const save = button(habit ? 'Save changes' : 'Add', { block: true, onClick: async () => {
      if (!name.value.trim()) { showToast('Give it a name first.'); return; }
      if (frequency === FREQUENCY.CUSTOM && days.size === 0) { showToast('Pick at least one day.'); return; }
      const payload = { name: name.value.trim(), frequency, domain, days: frequency === FREQUENCY.CUSTOM ? [...days].sort() : null, targetPerWeek: frequency === FREQUENCY.WEEKLY ? 1 : null };
      if (habit) await updateHabit(habit, payload); else await createHabit(payload);
      showToast(habit ? 'Updated.' : 'Added to your list.');
      closeSheet();
      onDone();
    } });

    body.append(
      el('div', 'field', [fieldLabel('Name'), name]),
      el('div', 'field', [fieldLabel('How often?'), freqSlot]),
      daySlot,
      el('div', 'field', [fieldLabel('Area'), domSlot]),
      el('div', 'bottom-sheet__footer', [save])
    );
    if (habit) {
      body.append(el('div', 'mt-3', button('Delete this', { variant: 'ghost', block: true, onClick: async () => {
        if (!window.confirm(`Delete "${habit.name}" and all its history?`)) return;
        await deleteHabit(habit.id);
        showToast('Deleted.');
        closeSheet();
        onDone();
      } })));
    }
  });
}
