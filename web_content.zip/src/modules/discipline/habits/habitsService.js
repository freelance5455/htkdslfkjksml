/**
 * habitsService.js — the single source of truth for habit data + logic.
 * Both Dashboard (Module 2) and the future full Discipline module import
 * from here, so habit rules are never duplicated across modules.
 */

import { getAll, put, newId, getByIndex, remove } from '../../../core/storage/storageService.js';
import { todayISO, isoDaysAgo, startOfWeekISO, lastNDates, gentleStreak, addDaysISO, parseISO } from '../../../core/utils/dateUtils.js';
import { emit } from '../../../core/utils/eventBus.js';

export const FREQUENCY = {
  DAILY: 'daily',
  WEEKLY: 'weekly',
  CUSTOM: 'custom',
};

const DEFAULT_HABITS = [
  { name: 'Morning skincare', domain: 'body', frequency: FREQUENCY.DAILY },
  { name: 'Night skincare', domain: 'body', frequency: FREQUENCY.DAILY },
  { name: 'Water 3.5L+', domain: 'body', frequency: FREQUENCY.DAILY },
  { name: 'Workout / steps', domain: 'body', frequency: FREQUENCY.DAILY },
  { name: 'Anki review', domain: 'mind', frequency: FREQUENCY.DAILY },
  { name: 'Study block', domain: 'mind', frequency: FREQUENCY.DAILY },
  { name: 'Phone grayscale / low distraction', domain: 'discipline', frequency: FREQUENCY.DAILY },
  { name: 'Barber / grooming check', domain: 'body', frequency: FREQUENCY.WEEKLY, targetPerWeek: 1 },
  { name: 'Weekly review', domain: 'discipline', frequency: FREQUENCY.WEEKLY, targetPerWeek: 1 },
];

export async function ensureDefaultHabits() {
  const existing = await getAll('habits');
  if (existing.length > 0) return existing;
  const created = [];
  for (const h of DEFAULT_HABITS) {
    created.push(await put('habits', { id: newId(), ...h }));
  }
  return created;
}

export async function getAllHabits() {
  return getAll('habits');
}

export async function createHabit({ name, domain = 'discipline', frequency = FREQUENCY.DAILY, targetPerWeek = null, days = null }) {
  return put('habits', { id: newId(), name, domain, frequency, targetPerWeek, days });
}

export async function updateHabit(habit, patch) {
  return put('habits', { ...habit, ...patch });
}

/** Deletes a habit AND its logs so no orphan data is left behind. */
export async function deleteHabit(habitId) {
  const logs = await getByIndex('habitLogs', 'habitId', habitId);
  for (const l of logs) await remove('habitLogs', l.id);
  await remove('habits', habitId);
}

/** Custom habits only show on the weekdays the user picked (0 = Sun). */
export function isDueToday(habit, date = new Date()) {
  if (habit.frequency === FREQUENCY.CUSTOM && Array.isArray(habit.days) && habit.days.length > 0) {
    return habit.days.includes(date.getDay());
  }
  return true;
}

export async function getLogsForHabit(habitId) {
  return getByIndex('habitLogs', 'habitId', habitId);
}

export async function getLogsForDate(date) {
  return getByIndex('habitLogs', 'date', date);
}

export async function toggleHabitLog(habit, date, completed) {
  const logsOnDate = await getLogsForDate(date);
  const existingLog = logsOnDate.find((l) => l.habitId === habit.id);
  await put('habitLogs', {
    id: existingLog?.id || newId(),
    habitId: habit.id,
    date,
    completed,
  });
  if (completed) emit('habit:completed', { habitId: habit.id, domain: habit.domain });
  return true;
}

/**
 * Current streak for a single habit. "Never miss twice": one missed day does
 * not break a daily chain. Weekly habits count consecutive WEEKS with a hit.
 */
export async function habitStreak(habit) {
  const logs = await getLogsForHabit(habit.id);
  const completedDates = new Set(logs.filter((l) => l.completed).map((l) => l.date));
  if (habit.frequency === FREQUENCY.WEEKLY) {
    const weeks = new Set([...completedDates].map((d) => startOfWeekISO(d)));
    let cursor = startOfWeekISO();
    if (!weeks.has(cursor)) cursor = addDaysISO(cursor, -7);
    let count = 0;
    while (weeks.has(cursor)) { count += 1; cursor = addDaysISO(cursor, -7); }
    return count;
  }
  return gentleStreak(completedDates).count;
}

/** True when the chain is alive but yesterday was missed (so today must not be). */
export async function habitMissedYesterday(habit) {
  const logs = await getLogsForHabit(habit.id);
  const g = gentleStreak(new Set(logs.filter((l) => l.completed).map((l) => l.date)));
  return g.atRisk;
}

/** Completion percentage for a habit over the last N days (daily) or weeks (weekly). */
export async function habitCompletionPct(habit, windowDays = 28) {
  const logs = await getLogsForHabit(habit.id);
  const completedDates = new Set(logs.filter((l) => l.completed).map((l) => l.date));

  if (habit.frequency === FREQUENCY.WEEKLY) {
    const weeksToCheck = Math.max(1, Math.round(windowDays / 7));
    let hits = 0;
    for (let w = 0; w < weeksToCheck; w += 1) {
      const weekStart = startOfWeekISO(isoDaysAgo(w * 7));
      const weekEnd = addDaysISO(weekStart, 6);
      const hitInWeek = [...completedDates].some((d) => d >= weekStart && d <= weekEnd);
      if (hitInWeek) hits += 1;
    }
    return Math.round((hits / weeksToCheck) * 100);
  }

  const dates = lastNDates(windowDays);
  const hits = dates.filter((d) => completedDates.has(d)).length;
  return Math.round((hits / windowDays) * 100);
}

/** Overall "today" snapshot across all habits: counts + which are done. */
export async function getTodaySnapshot() {
  const habits = await ensureDefaultHabits();
  const today = todayISO();
  const logsToday = await getLogsForDate(today);
  const dueToday = habits.filter((h) => isDueToday(h)); // custom habits only on their chosen weekdays

  const withStatus = await Promise.all(
    dueToday.map(async (h) => {
      const log = logsToday.find((l) => l.habitId === h.id);
      let completedThisWeek = false;
      if (h.frequency === FREQUENCY.WEEKLY) {
        const weekStart = startOfWeekISO();
        const logs = await getLogsForHabit(h.id);
        completedThisWeek = logs.some((l) => l.completed && l.date >= weekStart);
      }
      return {
        habit: h,
        completedToday: !!log?.completed,
        completedThisWeek,
        streak: await habitStreak(h),
      };
    })
  );

  return { habits: withStatus, date: today };
}

/** Daily overall streak: days with at least one habit done ("never miss twice" rule). */
export async function overallDailyStreak() {
  const logs = await getAll('habitLogs');
  return gentleStreak(new Set(logs.filter((l) => l.completed).map((l) => l.date))).count;
}

/** Habits that were missed yesterday but had an active streak — used for streak-protection warnings. */
export async function habitsAtRiskToday() {
  const habits = await ensureDefaultHabits();
  const atRisk = [];
  for (const h of habits) {
    if (h.frequency !== FREQUENCY.DAILY) continue;
    const logs = await getLogsForHabit(h.id);
    const todayLog = logs.find((l) => l.date === todayISO());
    const streak = await habitStreak(h);
    if (streak >= 3 && !todayLog?.completed) {
      atRisk.push({ habit: h, streak });
    }
  }
  return atRisk;
}
