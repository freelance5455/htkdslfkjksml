/**
 * dashPrefs.js — what Home shows and in which order.
 * Stored in the `settings` store (so it is part of backup/restore) and mirrored in localStorage.
 */
import { getSetting, setSetting } from '../../core/storage/storageService.js';
import { todayISO } from '../../core/utils/dateUtils.js';

const KEY = 'dash.v1';
const LS = 'lg.dash.v1';
const PRI_KEY = 'dash.priorityDone';

/** Registry of Home sections. `span` is how many columns it takes in the Compact (2-column) layout. */
export const SECTIONS = [
  { key: 'priorities', label: 'My daily priorities', icon: '⭐', span: 2, hint: 'Your own top-3 for today' },
  { key: 'overview', label: 'Streak & level', icon: '🔥', span: 1, hint: 'Streak, XP and level' },
  { key: 'vitals', label: 'Life Score & vitals', icon: '💯', span: 1, hint: 'Life Score and the four vitals' },
  { key: 'suggestions', label: "Today's suggestions", icon: '💡', span: 2, hint: 'What to do next, from your stats' },
  { key: 'prayer', label: 'Prayer times', icon: '🕌', span: 2, hint: 'Next prayer, tap to mark done' },
  { key: 'mastery', label: "Today's Mastery", icon: '🌱', span: 2, hint: 'Skills planned for today' },
  { key: 'tasks', label: "Today's tasks", icon: '✅', span: 2, hint: 'Your checklist for today' },
  { key: 'habits', label: 'Habit tracker', icon: '📆', span: 2, hint: 'Daily, weekly and custom habits' },
  { key: 'progress', label: 'Progress charts', icon: '📈', span: 2, hint: 'Weekly comparison and 14-day charts' },
  { key: 'motivation', label: 'Motivation', icon: '🤲', span: 2, hint: 'Coach, affirmation, why I started' },
  { key: 'quick', label: 'Quick actions', icon: '⚡', span: 2, hint: 'One-tap logging buttons' },
];
export const VITAL_TILES = [
  { key: 'health', label: 'Health' }, { key: 'study', label: 'Study' }, { key: 'fitness', label: 'Fitness' }, { key: 'confidence', label: 'Confidence' },
];
export const CHARTS = [
  { key: 'week', label: 'This week vs last week' }, { key: 'xp', label: 'XP growth' },
  { key: 'consistency', label: 'Habit consistency' }, { key: 'study', label: 'Study hours' },
];

export const DEFAULT_DASH = {
  layout: 'comfortable', // 'comfortable' = one column · 'compact' = two columns
  order: ['overview', 'priorities', 'vitals', 'suggestions', 'prayer', 'mastery', 'tasks', 'habits', 'progress', 'motivation', 'quick'],
  hidden: [],
  vitals: VITAL_TILES.map((v) => v.key),
  charts: CHARTS.map((c) => c.key),
  priorities: [],
};

let cache = null;
const readLocal = () => { try { return JSON.parse(localStorage.getItem(LS) || 'null'); } catch { return null; } };
const writeLocal = (v) => { try { localStorage.setItem(LS, JSON.stringify(v)); } catch { /* ignore */ } };

/** Defensive: unknown keys dropped, missing sections appended, so an old/corrupt save can never hide Home. */
export function sanitizeDash(raw) {
  const r = raw && typeof raw === 'object' ? raw : {};
  const keys = SECTIONS.map((s) => s.key);
  const order = [...new Set((Array.isArray(r.order) ? r.order : []).filter((k) => keys.includes(k)))];
  keys.forEach((k) => { if (!order.includes(k)) order.push(k); });
  const pick = (val, all, fallback) => (Array.isArray(val) ? val.filter((k) => all.includes(k)) : fallback);
  return {
    layout: r.layout === 'compact' ? 'compact' : 'comfortable',
    order,
    hidden: pick(r.hidden, keys, []),
    vitals: pick(r.vitals, VITAL_TILES.map((v) => v.key), DEFAULT_DASH.vitals),
    charts: pick(r.charts, CHARTS.map((c) => c.key), DEFAULT_DASH.charts),
    priorities: (Array.isArray(r.priorities) ? r.priorities : []).map((x) => String(x).trim().slice(0, 80)).filter(Boolean).slice(0, 5),
  };
}

export function getDashSync() { if (!cache) cache = sanitizeDash(readLocal() || DEFAULT_DASH); return cache; }
export async function getDash() { cache = sanitizeDash(await getSetting(KEY, readLocal() || DEFAULT_DASH)); writeLocal(cache); return cache; }
export async function saveDash(patch) {
  cache = sanitizeDash({ ...(await getDash()), ...patch });
  writeLocal(cache); await setSetting(KEY, cache); return cache;
}
export async function resetDash() { cache = sanitizeDash(DEFAULT_DASH); writeLocal(cache); await setSetting(KEY, cache); await setSetting(PRI_KEY, { date: '', done: [] }); return cache; }

export async function moveSection(key, dir) {
  const d = await getDash(); const i = d.order.indexOf(key); const j = i + dir;
  if (i < 0 || j < 0 || j >= d.order.length) return d;
  const order = [...d.order]; [order[i], order[j]] = [order[j], order[i]];
  return saveDash({ order });
}
export async function toggleSection(key) {
  const d = await getDash();
  return saveDash({ hidden: d.hidden.includes(key) ? d.hidden.filter((k) => k !== key) : [...d.hidden, key] });
}
export async function toggleInList(field, key) {
  const d = await getDash(); const cur = d[field];
  const next = cur.includes(key) ? cur.filter((k) => k !== key) : [...cur, key];
  return saveDash({ [field]: next });
}

/* ---- today's priority ticks (reset each day) ---- */
export async function getPriorityDone() {
  const v = await getSetting(PRI_KEY, { date: '', done: [] });
  return v.date === todayISO() ? v.done : [];
}
export async function setPriorityDone(index, checked) {
  const cur = new Set(await getPriorityDone());
  if (checked) cur.add(index); else cur.delete(index);
  await setSetting(PRI_KEY, { date: todayISO(), done: [...cur] });
}
