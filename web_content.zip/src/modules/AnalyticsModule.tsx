import React from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon } from '../components/AscendIcon';
import { RadarChartSVG } from '../components/RadarChartSVG';
import {
  calculateAttributeMetrics,
  calculateGoalProgress,
  calculateHabitConsistency,
  calculateHabitStreak,
} from '../utils/progressionEngine';

export const AnalyticsModule: React.FC = () => {
  const { state, levelStatus } = useAscend();

  // Compute XP breakdown by activityType from real xpTransactions
  const xpByCategory = state.xpTransactions.reduce<Record<string, number>>(
    (acc, tx) => {
      acc[tx.activityType] = (acc[tx.activityType] || 0) + tx.xpAmount;
      return acc;
    },
    {}
  );

  const totalFocusHours = (
    state.focusSessions.reduce((sum, s) => sum + s.durationMinutes, 0) / 60
  ).toFixed(1);

  const totalStudyHours = state.subjects
    .reduce((sum, s) => sum + s.loggedHours, 0)
    .toFixed(1);

  const totalQuestions = state.subjects.reduce(
    (sum, s) =>
      sum +
      s.chapters.reduce((cSum, ch) => cSum + ch.practiceQuestionsSolved, 0),
    0
  );

  const completedGoals = state.goals.filter(
    (g) => g.status === 'Completed'
  ).length;
  const completedMissions = state.missions.filter(
    (m) => m.status === 'Completed'
  ).length;
  const completedTasks = state.tasks.filter(
    (t) => t.status === 'Completed'
  ).length;
  const unlockedBadges = state.achievements.filter((a) => a.unlocked).length;

  return (
    <div className="space-y-6 pb-12">
      <div>
        <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
          Character Telemetry & Life Analytics
        </h1>
        <p className="text-sm text-[var(--text-secondary)]">
          Every chart and statistic below is dynamically calculated from your real stored Ascend OS records.
        </p>
      </div>

      {/* Top 6 Summary Cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {[
          {
            label: 'Total XP Earned',
            value: levelStatus.totalXp.toLocaleString(),
            sub: `Level ${levelStatus.level}`,
            icon: 'Zap',
          },
          {
            label: 'Study & Focus',
            value: `${(Number(totalStudyHours) + Number(totalFocusHours)).toFixed(1)}h`,
            sub: `${totalStudyHours}h Study · ${totalFocusHours}h Focus`,
            icon: 'Timer',
          },
          {
            label: 'Problems Solved',
            value: totalQuestions.toLocaleString(),
            sub: `${state.subjects.length} Active Subjects`,
            icon: 'GraduationCap',
          },
          {
            label: 'Goals & Quests',
            value: `${completedGoals + completedMissions}`,
            sub: `${completedGoals} Goals · ${completedMissions} Quests`,
            icon: 'Target',
          },
          {
            label: 'Tasks Executed',
            value: `${completedTasks}/${state.tasks.length}`,
            sub: 'Verified Completions',
            icon: 'CheckSquare',
          },
          {
            label: 'Badges Unlocked',
            value: `${unlockedBadges}/${state.achievements.length}`,
            sub: 'Milestone Achievements',
            icon: 'Award',
          },
        ].map((card) => (
          <div
            key={card.label}
            className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4"
          >
            <div className="flex items-center gap-1.5 text-xs text-[var(--text-secondary)]">
              <AscendIcon
                name={card.icon}
                size={14}
                className="text-[var(--accent-primary)]"
              />
              <span className="truncate">{card.label}</span>
            </div>
            <div className="font-mono-metric mt-1.5 text-xl font-extrabold text-[var(--text-primary)]">
              {card.value}
            </div>
            <div className="mt-0.5 text-[10px] text-[var(--text-muted)]">
              {card.sub}
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Attribute Radar & Ranking */}
        <div className="lg:col-span-5 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
          <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
            Attribute Balance Matrix
          </h2>
          <div className="my-3 flex justify-center">
            <RadarChartSVG attributes={state.attributes} size={275} />
          </div>
          <div className="space-y-2 border-t border-[var(--border-subtle)] pt-3">
            {[...state.attributes]
              .sort(
                (a, b) =>
                  calculateAttributeMetrics(b).totalScore -
                  calculateAttributeMetrics(a).totalScore
              )
              .slice(0, 6)
              .map((attr) => {
                const m = calculateAttributeMetrics(attr);
                return (
                  <div
                    key={attr.id}
                    className="flex items-center justify-between text-xs"
                  >
                    <span className="font-medium text-[var(--text-primary)]">
                      {attr.code} · {attr.name}
                    </span>
                    <span className="font-mono-metric font-bold text-[var(--accent-primary)]">
                      Score {m.totalScore} ({attr.xpEarned} XP)
                    </span>
                  </div>
                );
              })}
          </div>
        </div>

        {/* XP Source Distribution & Habit Consistency */}
        <div className="lg:col-span-7 space-y-6">
          {/* XP Source Breakdown */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              XP Ledger Source Breakdown
            </h2>
            <p className="text-xs text-[var(--text-secondary)]">
              Real distribution of XP earned across habits, milestones, education, skills, focus, and tasks.
            </p>
            <div className="mt-4 space-y-3">
              {Object.entries(xpByCategory)
                .sort((a, b) => b[1] - a[1])
                .map(([cat, amount]) => {
                  const pct = Math.min(
                    100,
                    Math.max(
                      4,
                      Math.round((amount / Math.max(1, levelStatus.totalXp)) * 100)
                    )
                  );
                  return (
                    <div key={cat}>
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold uppercase tracking-wider text-[var(--text-primary)]">
                          {cat}
                        </span>
                        <span className="font-mono-metric font-bold text-[var(--text-primary)]">
                          {amount.toLocaleString()} XP ({pct}%)
                        </span>
                      </div>
                      <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                        <div
                          className="h-full rounded-full bg-[var(--accent-primary)]"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* Habit Consistency Leaderboard */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Habit Consistency & Streaks
            </h2>
            <div className="mt-3 space-y-3">
              {state.habits.map((h) => {
                const c7 = calculateHabitConsistency(h, 7);
                const streak = calculateHabitStreak(h);
                return (
                  <div
                    key={h.id}
                    className="flex items-center justify-between gap-4 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 px-3.5 py-2.5"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-xs font-bold text-[var(--text-primary)]">
                        {h.name}
                      </div>
                      <div className="font-mono-metric text-[11px] text-[var(--text-secondary)]">
                        Streak: {streak}d · +{h.xpReward} XP/day
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-24 h-2 overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                        <div
                          className="h-full rounded-full bg-emerald-500"
                          style={{ width: `${c7}%` }}
                        />
                      </div>
                      <span className="font-mono-metric w-10 text-right text-xs font-bold text-[var(--text-primary)]">
                        {c7}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Life Domain & Goal Completion Matrix */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
          <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
            Life Domain Weekly Allocation
          </h2>
          <div className="mt-4 space-y-2.5">
            {state.domains.slice(0, 8).map((dom) => {
              const pct = Math.min(
                100,
                Math.round(
                  (dom.loggedHours / Math.max(1, dom.targetHoursPerWeek)) * 100
                )
              );
              return (
                <div key={dom.id} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-[var(--text-primary)]">
                      {dom.name}
                    </span>
                    <span className="font-mono-metric text-[var(--text-secondary)]">
                      {dom.loggedHours}h / {dom.targetHoursPerWeek}h ({pct}%)
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${pct}%`, backgroundColor: dom.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
          <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
            Strategic Goal Progress Overview
          </h2>
          <div className="mt-4 space-y-3">
            {state.goals.map((g) => {
              const linkedTasks = state.tasks.filter(
                (t) => t.linkedGoalId === g.id
              );
              const pct = calculateGoalProgress(g, linkedTasks);
              return (
                <div
                  key={g.id}
                  className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-[var(--text-primary)]">
                      {g.title}
                    </span>
                    <span className="font-mono-metric font-bold text-[var(--accent-primary)]">
                      {pct}%
                    </span>
                  </div>
                  <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${pct}%`,
                        backgroundColor: g.color || 'var(--accent-primary)',
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
