import React, { useEffect, useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon } from '../components/AscendIcon';
import { playAscendChime } from '../utils/progressionEngine';
import { getTodayStr } from '../data/initialAscendState';

export const FocusStudioModule: React.FC = () => {
  const { state, updateFocusConfig, recordFocusSession } = useAscend();
  const cfg = state.focusConfig;

  const [mode, setMode] = useState<'Pomodoro' | 'Custom' | 'Stopwatch'>('Pomodoro');
  const [phase, setPhase] = useState<'focus' | 'short-break' | 'long-break'>('focus');
  const [secondsLeft, setSecondsLeft] = useState<number>(cfg.pomodoroMinutes * 60);
  const [stopwatchSeconds, setStopwatchSeconds] = useState<number>(0);
  const [running, setRunning] = useState<boolean>(false);

  const [sessionLabel, setSessionLabel] = useState<string>(
    'Deep Scholarship & Problem Synthesis'
  );
  const [linkedGoalId, setLinkedGoalId] = useState<string>(
    state.goals[0]?.id || ''
  );
  const [linkedTaskId, setLinkedTaskId] = useState<string>('');
  const [linkedSubjectId, setLinkedSubjectId] = useState<string>(
    state.subjects[0]?.id || ''
  );

  // Sync timer duration when mode/phase changes and timer is stopped
  useEffect(() => {
    if (running) return;
    if (mode === 'Pomodoro') {
      if (phase === 'focus') setSecondsLeft(cfg.pomodoroMinutes * 60);
      else if (phase === 'short-break') setSecondsLeft(cfg.shortBreakMinutes * 60);
      else setSecondsLeft(cfg.longBreakMinutes * 60);
    } else if (mode === 'Custom') {
      setSecondsLeft(cfg.customTimerMinutes * 60);
    }
  }, [
    mode,
    phase,
    cfg.pomodoroMinutes,
    cfg.shortBreakMinutes,
    cfg.longBreakMinutes,
    cfg.customTimerMinutes,
    running,
  ]);

  useEffect(() => {
    if (!running) return;
    const interval = setInterval(() => {
      if (mode === 'Stopwatch') {
        setStopwatchSeconds((s) => s + 1);
      } else {
        setSecondsLeft((s) => {
          if (s <= 1) {
            setRunning(false);
            if (cfg.soundEnabled) playAscendChime('timer');
            if (phase === 'focus') {
              const mins =
                mode === 'Pomodoro'
                  ? cfg.pomodoroMinutes
                  : cfg.customTimerMinutes;
              recordFocusSession({
                date: getTodayStr(),
                timestamp: new Date().toTimeString().slice(0, 5),
                label: sessionLabel || 'Focus Session',
                mode,
                durationMinutes: mins,
                linkedGoalId: linkedGoalId || undefined,
                linkedTaskId: linkedTaskId || undefined,
                linkedSubjectId: linkedSubjectId || undefined,
              });
            }
            return 0;
          }
          return s - 1;
        });
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [
    running,
    mode,
    phase,
    cfg,
    sessionLabel,
    linkedGoalId,
    linkedTaskId,
    linkedSubjectId,
    recordFocusSession,
  ]);

  const formatClock = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handleCompleteManualSession = () => {
    const durationMinutes =
      mode === 'Stopwatch'
        ? Math.max(1, Math.round(stopwatchSeconds / 60))
        : mode === 'Pomodoro'
        ? cfg.pomodoroMinutes
        : cfg.customTimerMinutes;

    setRunning(false);
    recordFocusSession({
      date: getTodayStr(),
      timestamp: new Date().toTimeString().slice(0, 5),
      label: sessionLabel || 'Deep Focus Sprint',
      mode,
      durationMinutes,
      linkedGoalId: linkedGoalId || undefined,
      linkedTaskId: linkedTaskId || undefined,
      linkedSubjectId: linkedSubjectId || undefined,
    });
    if (mode === 'Stopwatch') setStopwatchSeconds(0);
  };

  const totalFocusMins = state.focusSessions.reduce(
    (sum, s) => sum + s.durationMinutes,
    0
  );
  const totalFocusXp = state.focusSessions.reduce(
    (sum, s) => sum + s.xpEarned,
    0
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            Deep Focus Studio
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            Execute distraction-free Pomodoro, Custom, or Stopwatch sessions tied directly to your goals and character attributes.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => updateFocusConfig({ soundEnabled: !cfg.soundEnabled })}
            className="inline-flex items-center gap-1.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-3.5 py-2 text-xs font-medium text-[var(--text-primary)]"
          >
            <AscendIcon
              name={cfg.soundEnabled ? 'Volume2' : 'VolumeX'}
              size={15}
              className="text-[var(--accent-primary)]"
            />
            Chime {cfg.soundEnabled ? 'On' : 'Muted'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Main Timer Dial Card */}
        <div className="lg:col-span-7 flex flex-col items-center justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 sm:p-8">
          {/* Mode Switcher */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            {(['Pomodoro', 'Custom', 'Stopwatch'] as const).map((m) => (
              <button
                key={m}
                onClick={() => {
                  setRunning(false);
                  setMode(m);
                }}
                className={`rounded-xl px-4 py-1.5 text-xs font-semibold transition ${
                  mode === m
                    ? 'bg-[var(--accent-primary)] text-white'
                    : 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                }`}
              >
                {m}
              </button>
            ))}
          </div>

          {/* Break / Focus Phase Selector for Pomodoro */}
          {mode === 'Pomodoro' && (
            <div className="mt-3 flex items-center gap-2">
              {[
                { id: 'focus', label: `Focus (${cfg.pomodoroMinutes}m)` },
                { id: 'short-break', label: `Short Break (${cfg.shortBreakMinutes}m)` },
                { id: 'long-break', label: `Long Break (${cfg.longBreakMinutes}m)` },
              ].map((ph) => (
                <button
                  key={ph.id}
                  onClick={() => {
                    setRunning(false);
                    setPhase(ph.id as typeof phase);
                  }}
                  className={`rounded-lg px-2.5 py-1 text-[11px] font-medium transition ${
                    phase === ph.id
                      ? 'bg-[var(--accent-soft)] text-[var(--accent-primary)] font-semibold'
                      : 'text-[var(--text-secondary)]'
                  }`}
                >
                  {ph.label}
                </button>
              ))}
            </div>
          )}

          {/* Giant Monospace Clock Display */}
          <div className="my-8 text-center">
            <div className="font-mono-metric text-6xl sm:text-7xl font-extrabold tracking-tight text-[var(--text-primary)]">
              {mode === 'Stopwatch'
                ? formatClock(stopwatchSeconds)
                : formatClock(secondsLeft)}
            </div>
            <p className="mt-2 text-xs font-medium text-[var(--text-secondary)]">
              {sessionLabel}
            </p>
          </div>

          {/* Primary Play / Pause / Reset / Complete Controls */}
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => setRunning(!running)}
              className="inline-flex items-center gap-2 rounded-2xl bg-[var(--accent-primary)] px-7 py-3 text-sm font-bold text-white shadow-sm transition hover:opacity-95"
            >
              <AscendIcon name={running ? 'Pause' : 'Play'} size={17} />
              {running ? 'Pause Timer' : 'Start Session'}
            </button>

            <button
              onClick={() => {
                setRunning(false);
                if (mode === 'Stopwatch') setStopwatchSeconds(0);
                else if (mode === 'Pomodoro')
                  setSecondsLeft(cfg.pomodoroMinutes * 60);
                else setSecondsLeft(cfg.customTimerMinutes * 60);
              }}
              className="inline-flex items-center gap-1.5 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-4 py-3 text-xs font-semibold text-[var(--text-primary)]"
            >
              <AscendIcon name="RotateCcw" size={15} />
              Reset
            </button>

            <button
              onClick={handleCompleteManualSession}
              className="inline-flex items-center gap-1.5 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-xs font-semibold text-emerald-500"
            >
              <AscendIcon name="CheckCircle2" size={15} />
              Log Completed Session (+XP)
            </button>
          </div>

          {/* Session Metadata Inputs */}
          <div className="mt-8 w-full grid grid-cols-1 gap-3 border-t border-[var(--border-subtle)] pt-5 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                Session Intention / Label
              </label>
              <input
                type="text"
                value={sessionLabel}
                onChange={(e) => setSessionLabel(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                Linked Strategic Goal
              </label>
              <select
                value={linkedGoalId}
                onChange={(e) => setLinkedGoalId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              >
                <option value="">None</option>
                {state.goals.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                Linked Education Subject
              </label>
              <select
                value={linkedSubjectId}
                onChange={(e) => setLinkedSubjectId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              >
                <option value="">None</option>
                {state.subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                Linked Execution Task
              </label>
              <select
                value={linkedTaskId}
                onChange={(e) => setLinkedTaskId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              >
                <option value="">None</option>
                {state.tasks.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.title}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Right Column: Timer Configuration & History */}
        <div className="lg:col-span-5 space-y-5">
          {/* Custom Timer & XP Settings */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
              Timer & Session XP Configuration
            </h3>
            <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div>
                <label className="block text-[11px] text-[var(--text-secondary)]">
                  Pomodoro (m)
                </label>
                <input
                  type="number"
                  min={5}
                  value={cfg.pomodoroMinutes}
                  onChange={(e) =>
                    updateFocusConfig({
                      pomodoroMinutes: Math.max(5, Number(e.target.value) || 25),
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1.5 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[var(--text-secondary)]">
                  Short Break (m)
                </label>
                <input
                  type="number"
                  min={1}
                  value={cfg.shortBreakMinutes}
                  onChange={(e) =>
                    updateFocusConfig({
                      shortBreakMinutes: Math.max(1, Number(e.target.value) || 5),
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1.5 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[var(--text-secondary)]">
                  Long Break (m)
                </label>
                <input
                  type="number"
                  min={5}
                  value={cfg.longBreakMinutes}
                  onChange={(e) =>
                    updateFocusConfig({
                      longBreakMinutes: Math.max(5, Number(e.target.value) || 15),
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1.5 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[var(--text-secondary)]">
                  Custom Timer (m)
                </label>
                <input
                  type="number"
                  min={5}
                  value={cfg.customTimerMinutes}
                  onChange={(e) =>
                    updateFocusConfig({
                      customTimerMinutes: Math.max(5, Number(e.target.value) || 45),
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1.5 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-[11px] text-[var(--text-secondary)]">
                  XP Reward per 25m Focus
                </label>
                <input
                  type="number"
                  min={0}
                  value={cfg.xpPer25MinSession}
                  onChange={(e) =>
                    updateFocusConfig({
                      xpPer25MinSession: Math.max(0, Number(e.target.value) || 0),
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1.5 text-xs font-bold text-[var(--accent-primary)]"
                />
              </div>
            </div>
          </div>

          {/* Focus Session History Log */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <div className="flex items-center justify-between">
              <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
                Focus Session History ({state.focusSessions.length})
              </h3>
              <span className="font-mono-metric text-xs font-semibold text-[var(--accent-primary)]">
                {(totalFocusMins / 60).toFixed(1)}h · +{totalFocusXp} XP
              </span>
            </div>

            <div className="mt-3 max-h-72 space-y-2 overflow-y-auto pr-1">
              {state.focusSessions.map((fs) => (
                <div
                  key={fs.id}
                  className="flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 px-3 py-2.5 text-xs"
                >
                  <div className="min-w-0 flex-1 pr-2">
                    <div className="truncate font-semibold text-[var(--text-primary)]">
                      {fs.label}
                    </div>
                    <div className="font-mono-metric text-[10px] text-[var(--text-secondary)]">
                      {fs.date} at {fs.timestamp} · {fs.mode} ({fs.durationMinutes}m)
                    </div>
                  </div>
                  <span className="font-mono-metric shrink-0 rounded bg-[var(--accent-soft)] px-2 py-0.5 text-[11px] font-bold text-[var(--accent-primary)]">
                    +{fs.xpEarned} XP
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
