import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon } from '../components/AscendIcon';
import { getTodayStr } from '../data/initialAscendState';
import { JournalEntry, WeeklyReviewRecord } from '../types/ascend';

export const JournalAndReviewModule: React.FC = () => {
  const {
    state,
    saveJournalEntry,
    deleteJournalEntry,
    saveWeeklyReview,
    updateTypography,
  } = useAscend();

  const [activeTab, setActiveTab] = useState<'journal' | 'weekly-review'>('journal');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);

  // Weekly Review Form
  const [wins, setWins] = useState('');
  const [challenges, setChallenges] = useState('');
  const [keyLesson, setKeyLesson] = useState('');
  const [nextWeekFocus, setNextWeekFocus] = useState('');
  const [disciplineRating, setDisciplineRating] = useState(9);

  const filteredEntries = state.journalEntries
    .filter((entry) => {
      const matchType = typeFilter === 'All' || entry.type === typeFilter;
      const q = searchQuery.toLowerCase();
      const matchSearch =
        !q ||
        entry.title.toLowerCase().includes(q) ||
        entry.content.toLowerCase().includes(q) ||
        entry.tags.some((t) => t.toLowerCase().includes(q));
      return matchType && matchSearch;
    })
    .sort((a, b) => Number(b.pinned) - Number(a.pinned));

  const handleOpenNewEntry = () => {
    setEditingEntry({
      id: `jrn-${Date.now()}`,
      date: getTodayStr(),
      title: '',
      type: 'Daily',
      mood: 'Focused',
      content: '',
      gratitudeList: [''],
      lessonsLearned: '',
      tags: ['Reflection'],
      pinned: false,
      useHandwriting: state.typography.useHandwritingInJournal,
    });
  };

  const handleSubmitWeeklyReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!wins.trim()) return;
    const rec: WeeklyReviewRecord = {
      id: `wr-${Date.now()}`,
      weekStartDate: getTodayStr(),
      wins: wins.trim(),
      challenges: challenges.trim(),
      keyLesson: keyLesson.trim(),
      nextWeekFocus: nextWeekFocus.trim(),
      disciplineRating,
      completedAt: getTodayStr(),
    };
    saveWeeklyReview(rec);
    setWins('');
    setChallenges('');
    setKeyLesson('');
    setNextWeekFocus('');
  };

  const HANDWRITING_FONTS = [
    'Caveat',
    'Kalam',
    'Patrick Hand',
    'Architects Daughter',
    'Indie Flower',
    'Shadows Into Light',
    'Dancing Script',
    'Sacramento',
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            {activeTab === 'journal'
              ? 'Personal Journal & Handwritten Reflection'
              : 'Weekly Architecture Review'}
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            {activeTab === 'journal'
              ? 'Private daily, weekly, and monthly reflections with optional handwritten notebook paper styling.'
              : 'Audit your past 7 days of execution, extract key lessons, and calibrate next week.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1">
            <button
              onClick={() => setActiveTab('journal')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                activeTab === 'journal'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)]'
              }`}
            >
              <AscendIcon name="NotebookPen" size={14} />
              Journal ({state.journalEntries.length})
            </button>
            <button
              onClick={() => setActiveTab('weekly-review')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                activeTab === 'weekly-review'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)]'
              }`}
            >
              <AscendIcon name="Compass" size={14} />
              Weekly Review ({state.weeklyReviews.length})
            </button>
          </div>

          {activeTab === 'journal' && (
            <button
              onClick={handleOpenNewEntry}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Feather" size={15} />
              New Reflection
            </button>
          )}
        </div>
      </div>

      {/* VIEW 1: JOURNAL */}
      {activeTab === 'journal' && (
        <div className="space-y-5">
          {/* Search, Type Filter & Quick Handwriting Font Selector */}
          <div className="flex flex-col gap-3 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                'All',
                'Daily',
                'Weekly',
                'Monthly',
                'Gratitude',
                'Reflection',
                'Free Writing',
              ].map((tp) => (
                <button
                  key={tp}
                  onClick={() => setTypeFilter(tp)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                    typeFilter === tp
                      ? 'bg-[var(--accent-primary)] text-white'
                      : 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                  }`}
                >
                  {tp}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search entries or tags..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] pl-8 pr-3 py-1.5 text-xs text-[var(--text-primary)]"
                />
                <AscendIcon
                  name="Search"
                  size={14}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"
                />
              </div>

              <select
                value={state.typography.journalFont}
                onChange={(e) =>
                  updateTypography({
                    journalFont: e.target.value,
                    handwritingFont: e.target.value,
                  })
                }
                className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-medium text-[var(--text-primary)]"
                title="Select Journal Handwriting Font"
              >
                {HANDWRITING_FONTS.map((f) => (
                  <option key={f} value={f}>
                    Handwriting: {f}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Journal Entries Cards */}
          <div className="grid grid-cols-1 gap-5">
            {filteredEntries.map((entry) => (
              <div
                key={entry.id}
                className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5 sm:p-6"
              >
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[var(--border-subtle)] pb-3">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono-metric text-xs font-semibold text-[var(--accent-primary)]">
                        {entry.date}
                      </span>
                      <span className="rounded-full bg-[var(--bg-elevated)] px-2.5 py-0.5 text-[11px] font-medium text-[var(--text-secondary)]">
                        {entry.type}
                      </span>
                      <span className="rounded-full border border-[var(--border-subtle)] px-2.5 py-0.5 text-[11px] text-[var(--text-primary)]">
                        Mood: {entry.mood}
                      </span>
                      {entry.pinned && (
                        <span className="rounded-full bg-amber-500/15 px-2.5 py-0.5 text-[10px] font-bold text-amber-500">
                          Pinned
                        </span>
                      )}
                    </div>
                    <h2
                      className={`mt-1.5 text-xl font-bold text-[var(--text-primary)] ${
                        entry.useHandwriting ? 'font-journal-custom text-2xl' : 'font-subheading'
                      }`}
                    >
                      {entry.title}
                    </h2>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() =>
                        saveJournalEntry({
                          ...entry,
                          useHandwriting: !entry.useHandwriting,
                        })
                      }
                      className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-medium text-[var(--text-primary)]"
                    >
                      {entry.useHandwriting ? 'Sans-Serif View' : 'Handwritten View'}
                    </button>
                    <button
                      onClick={() =>
                        saveJournalEntry({ ...entry, pinned: !entry.pinned })
                      }
                      className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs text-[var(--text-secondary)]"
                    >
                      {entry.pinned ? 'Unpin' : 'Pin'}
                    </button>
                    <button
                      onClick={() => setEditingEntry(entry)}
                      className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs text-[var(--accent-primary)]"
                    >
                      Edit
                    </button>
                  </div>
                </div>

                {/* Body Content (Handwritten Lined Paper or Clean Sans) */}
                <div
                  className={`mt-4 rounded-xl p-4 ${
                    entry.useHandwriting
                      ? 'notebook-paper font-journal-custom text-xl text-[var(--text-primary)] bg-[var(--bg-elevated)]/35'
                      : 'text-sm leading-relaxed text-[var(--text-primary)]'
                  }`}
                >
                  {entry.content}
                </div>

                {/* Gratitude & Lessons Learned */}
                <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {entry.gratitudeList.length > 0 && (
                    <div className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3.5">
                      <div className="text-xs font-bold text-[var(--text-primary)]">
                        Gratitude Anchors
                      </div>
                      <ul className="mt-1.5 space-y-1 text-xs text-[var(--text-secondary)]">
                        {entry.gratitudeList.map((g, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <AscendIcon
                              name="Heart"
                              size={12}
                              className="text-[var(--accent-primary)] shrink-0"
                            />
                            <span>{g}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {entry.lessonsLearned && (
                    <div className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3.5">
                      <div className="text-xs font-bold text-[var(--text-primary)]">
                        Key Lesson Extracted
                      </div>
                      <p className="mt-1.5 text-xs text-[var(--text-secondary)]">
                        {entry.lessonsLearned}
                      </p>
                    </div>
                  )}
                </div>

                {/* Tags */}
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {entry.tags.map((tg) => (
                    <span
                      key={tg}
                      className="rounded-lg bg-[var(--bg-elevated)] px-2.5 py-0.5 text-[11px] text-[var(--text-secondary)]"
                    >
                      #{tg}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 2: WEEKLY REVIEW WIZARD */}
      {activeTab === 'weekly-review' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <form
            onSubmit={handleSubmitWeeklyReview}
            className="lg:col-span-6 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                Complete Weekly Review (+60 XP)
              </h2>
              <span className="font-mono-metric text-xs text-[var(--accent-primary)] font-semibold">
                {getTodayStr()}
              </span>
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                1. Biggest Wins & Milestones Completed This Week
              </label>
              <textarea
                rows={3}
                required
                placeholder="What went exceptionally well across study, habits, and projects?"
                value={wins}
                onChange={(e) => setWins(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-3 text-xs text-[var(--text-primary)]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                2. Friction Points & Bottlenecks Encountered
              </label>
              <textarea
                rows={2}
                placeholder="Where did energy or focus leak?"
                value={challenges}
                onChange={(e) => setChallenges(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-3 text-xs text-[var(--text-primary)]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                3. Primary System Adjustment / Lesson Learned
              </label>
              <input
                type="text"
                placeholder="One structural improvement for next week..."
                value={keyLesson}
                onChange={(e) => setKeyLesson(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                4. Top 3 Non-Negotiable Priorities for Next Week
              </label>
              <input
                type="text"
                placeholder="Define the exact focus targets..."
                value={nextWeekFocus}
                onChange={(e) => setNextWeekFocus(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                5. Self-Command & Discipline Rating: {disciplineRating} / 10
              </label>
              <input
                type="range"
                min={1}
                max={10}
                value={disciplineRating}
                onChange={(e) => setDisciplineRating(Number(e.target.value))}
                className="mt-2 w-full accent-[var(--accent-primary)]"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-xl bg-[var(--accent-primary)] py-2.5 text-xs font-bold text-white"
            >
              Archive Weekly Review & Claim +60 XP
            </button>
          </form>

          {/* Past Weekly Reviews */}
          <div className="lg:col-span-6 space-y-4">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Past Weekly Architecture Reviews
            </h3>
            {state.weeklyReviews.map((wr) => (
              <div
                key={wr.id}
                className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5 space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono-metric text-xs font-bold text-[var(--accent-primary)]">
                    Week of {wr.weekStartDate}
                  </span>
                  <span className="font-mono-metric rounded-lg bg-[var(--accent-soft)] px-2.5 py-0.5 text-xs font-bold text-[var(--accent-primary)]">
                    Discipline: {wr.disciplineRating}/10
                  </span>
                </div>
                <div className="text-xs text-[var(--text-primary)]">
                  <strong>Wins:</strong> {wr.wins}
                </div>
                <div className="text-xs text-[var(--text-secondary)]">
                  <strong>Challenges:</strong> {wr.challenges}
                </div>
                <div className="text-xs text-[var(--text-secondary)]">
                  <strong>Key Lesson:</strong> {wr.keyLesson}
                </div>
                <div className="text-xs text-[var(--text-primary)]">
                  <strong>Next Week Focus:</strong> {wr.nextWeekFocus}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Journal Editor Modal */}
      {editingEntry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
          <div className="my-8 w-full max-w-xl rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Write Journal Reflection
            </h3>
            <div className="mt-4 space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Date
                  </label>
                  <input
                    type="date"
                    value={editingEntry.date}
                    onChange={(e) =>
                      setEditingEntry({ ...editingEntry, date: e.target.value })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Entry Type
                  </label>
                  <select
                    value={editingEntry.type}
                    onChange={(e) =>
                      setEditingEntry({
                        ...editingEntry,
                        type: e.target.value as JournalEntry['type'],
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="Daily">Daily</option>
                    <option value="Weekly">Weekly</option>
                    <option value="Monthly">Monthly</option>
                    <option value="Gratitude">Gratitude</option>
                    <option value="Reflection">Reflection</option>
                    <option value="Free Writing">Free Writing</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Mood Label
                  </label>
                  <select
                    value={editingEntry.mood}
                    onChange={(e) =>
                      setEditingEntry({
                        ...editingEntry,
                        mood: e.target.value as JournalEntry['mood'],
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="Focused">Focused</option>
                    <option value="Energized">Energized</option>
                    <option value="Calm">Calm</option>
                    <option value="Reflective">Reflective</option>
                    <option value="Determined">Determined</option>
                    <option value="Neutral">Neutral</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Reflection Title
                </label>
                <input
                  type="text"
                  placeholder="Title of your entry..."
                  value={editingEntry.title}
                  onChange={(e) =>
                    setEditingEntry({ ...editingEntry, title: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Journal Content
                  </label>
                  <label className="flex items-center gap-1.5 text-xs text-[var(--accent-primary)] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingEntry.useHandwriting}
                      onChange={(e) =>
                        setEditingEntry({
                          ...editingEntry,
                          useHandwriting: e.target.checked,
                        })
                      }
                    />
                    Render with Handwriting Font ({state.typography.journalFont})
                  </label>
                </div>
                <textarea
                  rows={5}
                  value={editingEntry.content}
                  onChange={(e) =>
                    setEditingEntry({ ...editingEntry, content: e.target.value })
                  }
                  className={`mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-3 text-[var(--text-primary)] ${
                    editingEntry.useHandwriting
                      ? 'font-journal-custom text-xl'
                      : 'text-xs'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Key Lesson Learned
                </label>
                <input
                  type="text"
                  value={editingEntry.lessonsLearned}
                  onChange={(e) =>
                    setEditingEntry({
                      ...editingEntry,
                      lessonsLearned: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteJournalEntry(editingEntry.id);
                  setEditingEntry(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Entry
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingEntry(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingEntry.title.trim()) return;
                    saveJournalEntry(editingEntry);
                    setEditingEntry(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Entry
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
