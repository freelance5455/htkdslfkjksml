import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon } from '../components/AscendIcon';
import { getFutureDateStr } from '../data/initialAscendState';
import { MissionItem, RewardItem } from '../types/ascend';

export const MissionsAndRewardsModule: React.FC = () => {
  const {
    state,
    levelStatus,
    saveMission,
    deleteMission,
    incrementMissionProgress,
    saveReward,
    deleteReward,
    toggleRewardRedeem,
  } = useAscend();

  const [activeTab, setActiveTab] = useState<'missions' | 'rewards'>('missions');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [editingMission, setEditingMission] = useState<MissionItem | null>(null);
  const [editingReward, setEditingReward] = useState<RewardItem | null>(null);

  const filteredMissions = state.missions.filter(
    (m) => typeFilter === 'All' || m.type === typeFilter
  );

  const handleOpenNewMission = () => {
    setEditingMission({
      id: `mis-${Date.now()}`,
      name: '',
      description: '',
      type: 'Daily',
      difficulty: 'Medium',
      deadline: getFutureDateStr(7),
      targetCount: 3,
      currentCount: 0,
      unit: 'completions',
      xpReward: state.xpSettings.defaultMissionXp,
      attributeIds: ['attr-dis', 'attr-foc'],
      status: 'Active',
    });
  };

  const handleOpenNewReward = () => {
    setEditingReward({
      id: `rew-${Date.now()}`,
      name: '',
      description: '',
      category: 'Leisure',
      icon: 'Gift',
      unlockRequirementText: 'Reach 3,000 XP or complete weekly mission',
      requiredXp: 3000,
      unlocked: false,
      redeemed: false,
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            {activeTab === 'missions'
              ? 'Missions & Quest Log'
              : 'Personal Milestone Rewards Vault'}
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            {activeTab === 'missions'
              ? 'Structured Daily, Weekly, Monthly, and Learning quests with customizable XP rewards.'
              : 'Celebrate meaningful milestones with healthy, intentional personal rewards.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1">
            <button
              onClick={() => setActiveTab('missions')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                activeTab === 'missions'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)]'
              }`}
            >
              <AscendIcon name="Compass" size={14} />
              Missions ({state.missions.length})
            </button>
            <button
              onClick={() => setActiveTab('rewards')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                activeTab === 'rewards'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)]'
              }`}
            >
              <AscendIcon name="Gift" size={14} />
              Rewards ({state.rewards.length})
            </button>
          </div>

          {activeTab === 'missions' ? (
            <button
              onClick={handleOpenNewMission}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Plus" size={15} />
              Create Mission
            </button>
          ) : (
            <button
              onClick={handleOpenNewReward}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Plus" size={15} />
              Create Reward
            </button>
          )}
        </div>
      </div>

      {/* MISSIONS VIEW */}
      {activeTab === 'missions' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-1.5 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-3.5">
            {['All', 'Daily', 'Weekly', 'Monthly', 'Goal', 'Learning', 'Habit', 'Custom'].map(
              (tp) => (
                <button
                  key={tp}
                  onClick={() => setTypeFilter(tp)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                    typeFilter === tp
                      ? 'bg-[var(--accent-primary)] text-white'
                      : 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                  }`}
                >
                  {tp}
                </button>
              )
            )}
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {filteredMissions.map((mis) => {
              const pct = Math.min(
                100,
                Math.round((mis.currentCount / Math.max(1, mis.targetCount)) * 100)
              );
              const isDone = mis.status === 'Completed';

              return (
                <div
                  key={mis.id}
                  className="flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="rounded-md bg-[var(--bg-elevated)] px-2 py-0.5 text-[10px] font-bold uppercase text-[var(--text-secondary)]">
                            {mis.type} Quest
                          </span>
                          <span className="rounded-md border border-[var(--border-subtle)] px-2 py-0.5 text-[10px] font-semibold text-[var(--text-primary)]">
                            {mis.difficulty}
                          </span>
                          <span className="font-mono-metric rounded-md bg-[var(--accent-soft)] px-2 py-0.5 text-xs font-bold text-[var(--accent-primary)]">
                            +{mis.xpReward} XP
                          </span>
                        </div>
                        <h3 className="mt-2 font-subheading text-base font-bold text-[var(--text-primary)]">
                          {mis.name}
                        </h3>
                        <p className="mt-1 text-xs text-[var(--text-secondary)]">
                          {mis.description}
                        </p>
                      </div>
                      <button
                        onClick={() => setEditingMission(mis)}
                        className="text-xs font-medium text-[var(--accent-primary)]"
                      >
                        Edit
                      </button>
                    </div>

                    <div className="mt-4">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[var(--text-secondary)]">
                          Progress ({mis.unit})
                        </span>
                        <span className="font-mono-metric font-bold text-[var(--text-primary)]">
                          {mis.currentCount} / {mis.targetCount} ({pct}%)
                        </span>
                      </div>
                      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                        <div
                          className={`h-full rounded-full transition-all ${
                            isDone ? 'bg-emerald-500' : 'bg-[var(--accent-primary)]'
                          }`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between border-t border-[var(--border-subtle)] pt-3">
                    <span className="font-mono-metric text-[11px] text-[var(--text-secondary)]">
                      Deadline: {mis.deadline}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => incrementMissionProgress(mis.id, -1)}
                        disabled={mis.currentCount <= 0}
                        className="rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1 text-xs font-bold disabled:opacity-40"
                      >
                        -1
                      </button>
                      <button
                        onClick={() => incrementMissionProgress(mis.id, 1)}
                        disabled={mis.currentCount >= mis.targetCount}
                        className="rounded-lg bg-[var(--accent-primary)] px-3 py-1 text-xs font-semibold text-white disabled:opacity-40"
                      >
                        +1 Progress
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* REWARDS VIEW */}
      {activeTab === 'rewards' && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {state.rewards.map((rew) => {
            const meetsXp =
              !rew.requiredXp || levelStatus.totalXp >= rew.requiredXp;
            const canClaim = rew.unlocked || meetsXp;

            return (
              <div
                key={rew.id}
                className="flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent-primary)]">
                      <AscendIcon name={rew.icon} size={20} />
                    </div>
                    <button
                      onClick={() => setEditingReward(rew)}
                      className="text-xs text-[var(--accent-primary)]"
                    >
                      Edit
                    </button>
                  </div>
                  <div className="mt-3">
                    <span className="rounded bg-[var(--bg-elevated)] px-2 py-0.5 text-[10px] font-bold uppercase text-[var(--text-secondary)]">
                      {rew.category}
                    </span>
                    <h3 className="mt-1 font-subheading text-base font-bold text-[var(--text-primary)]">
                      {rew.name}
                    </h3>
                    <p className="mt-1 text-xs text-[var(--text-secondary)]">
                      {rew.description}
                    </p>
                    <p className="mt-2 text-[11px] text-[var(--text-muted)]">
                      Requirement: {rew.unlockRequirementText}
                    </p>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-[var(--border-subtle)] pt-3">
                  <span
                    className={`text-xs font-semibold ${
                      rew.redeemed
                        ? 'text-emerald-500'
                        : canClaim
                        ? 'text-[var(--accent-primary)]'
                        : 'text-[var(--text-muted)]'
                    }`}
                  >
                    {rew.redeemed
                      ? 'Redeemed & Celebrated'
                      : canClaim
                      ? 'Ready to Claim'
                      : `Requires ${rew.requiredXp?.toLocaleString()} XP`}
                  </span>
                  <button
                    onClick={() => toggleRewardRedeem(rew.id)}
                    className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition ${
                      rew.redeemed
                        ? 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                        : 'bg-[var(--accent-primary)] text-white'
                    }`}
                  >
                    {rew.redeemed ? 'Mark Unclaimed' : 'Claim Reward'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Mission Editor Modal */}
      {editingMission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Configure Quest / Mission
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Mission Name
                </label>
                <input
                  type="text"
                  value={editingMission.name}
                  onChange={(e) =>
                    setEditingMission({ ...editingMission, name: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Description
                </label>
                <input
                  type="text"
                  value={editingMission.description}
                  onChange={(e) =>
                    setEditingMission({
                      ...editingMission,
                      description: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Mission Type
                  </label>
                  <select
                    value={editingMission.type}
                    onChange={(e) =>
                      setEditingMission({
                        ...editingMission,
                        type: e.target.value as MissionItem['type'],
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="Daily">Daily</option>
                    <option value="Weekly">Weekly</option>
                    <option value="Monthly">Monthly</option>
                    <option value="Goal">Goal-Based</option>
                    <option value="Learning">Learning</option>
                    <option value="Habit">Habit</option>
                    <option value="Custom">Custom</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Difficulty
                  </label>
                  <select
                    value={editingMission.difficulty}
                    onChange={(e) =>
                      setEditingMission({
                        ...editingMission,
                        difficulty: e.target.value as MissionItem['difficulty'],
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="Easy">Easy</option>
                    <option value="Medium">Medium</option>
                    <option value="Hard">Hard</option>
                    <option value="Mythic">Mythic</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Target Count
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={editingMission.targetCount}
                    onChange={(e) =>
                      setEditingMission({
                        ...editingMission,
                        targetCount: Math.max(1, Number(e.target.value) || 1),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Unit
                  </label>
                  <input
                    type="text"
                    value={editingMission.unit}
                    onChange={(e) =>
                      setEditingMission({
                        ...editingMission,
                        unit: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    XP Reward
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editingMission.xpReward}
                    onChange={(e) =>
                      setEditingMission({
                        ...editingMission,
                        xpReward: Math.max(0, Number(e.target.value) || 0),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs font-bold text-[var(--accent-primary)]"
                  />
                </div>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteMission(editingMission.id);
                  setEditingMission(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Mission
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingMission(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingMission.name.trim()) return;
                    saveMission(editingMission);
                    setEditingMission(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Mission
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Reward Editor Modal */}
      {editingReward && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Create Personal Milestone Reward
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Reward Name
                </label>
                <input
                  type="text"
                  value={editingReward.name}
                  onChange={(e) =>
                    setEditingReward({ ...editingReward, name: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Description
                </label>
                <input
                  type="text"
                  value={editingReward.description}
                  onChange={(e) =>
                    setEditingReward({
                      ...editingReward,
                      description: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Unlock Requirement Text
                  </label>
                  <input
                    type="text"
                    value={editingReward.unlockRequirementText}
                    onChange={(e) =>
                      setEditingReward({
                        ...editingReward,
                        unlockRequirementText: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Required XP Threshold
                  </label>
                  <input
                    type="number"
                    value={editingReward.requiredXp || 0}
                    onChange={(e) =>
                      setEditingReward({
                        ...editingReward,
                        requiredXp: Number(e.target.value) || 0,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteReward(editingReward.id);
                  setEditingReward(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Reward
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingReward(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingReward.name.trim()) return;
                    saveReward(editingReward);
                    setEditingReward(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Reward
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
