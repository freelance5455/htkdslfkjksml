import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon } from '../components/AscendIcon';
import { RadarChartSVG } from '../components/RadarChartSVG';
import {
  calculateGoalProgress,
  calculateHabitStreak,
  getActiveTitle,
  isHabitCompletedOnDate,
} from '../utils/progressionEngine';
import { getTodayStr } from '../data/initialAscendState';
import { DashboardWidgetConfig } from '../types/ascend';

export const HomeDashboard: React.FC = () => {
  const {
    state,
    levelStatus,
    setActiveModule,
    logHabitProgress,
    toggleTaskStatus,
    incrementMissionProgress,
    updateWidgets,
  } = useAscend();

  const [customizing, setCustomizing] = useState(false);
  const today = getTodayStr();

  const activeHabits = state.habits.filter((h) => h.status === 'Active');
  const completedHabitsToday = activeHabits.filter((h) =>
    isHabitCompletedOnDate(h, today)
  ).length;
  const habitDailyPercent =
    activeHabits.length > 0
      ? Math.round((completedHabitsToday / activeHabits.length) * 100)
      : 0;

  const activeTasks = state.tasks.filter(
    (t) => t.status !== 'Archived' && t.status !== 'Cancelled'
  );
  const completedTasksCount = activeTasks.filter((t) => t.status === 'Completed').length;

  const activeGoals = state.goals.filter((g) => g.status === 'Active');
  const totalFocusMinutes = state.focusSessions.reduce(
    (sum, s) => sum + s.durationMinutes,
    0
  );
  const totalStudyHours = state.subjects.reduce((sum, s) => sum + s.loggedHours, 0);

  const activeTitle = getActiveTitle(state, levelStatus.level);

  const sortedWidgets = [...state.dashboardWidgets].sort((a, b) => a.order - b.order);
  const visibleWidgets = sortedWidgets.filter((w) => w.visible);

  const toggleWidgetVisibility = (id: DashboardWidgetConfig['id']) => {
    const next = state.dashboardWidgets.map((w) =>
      w.id === id ? { ...w, visible: !w.visible } : w
    );
    updateWidgets(next);
  };

  const changeWidgetSize = (
    id: DashboardWidgetConfig['id'],
    size: DashboardWidgetConfig['size']
  ) => {
    const next = state.dashboardWidgets.map((w) =>
      w.id === id ? { ...w, size } : w
    );
    updateWidgets(next);
  };

  const moveWidgetOrder = (id: DashboardWidgetConfig['id'], dir: -1 | 1) => {
    const ordered = [...state.dashboardWidgets].sort((a, b) => a.order - b.order);
    const idx = ordered.findIndex((w) => w.id === id);
    if (idx < 0) return;
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= ordered.length) return;
    const temp = ordered[idx].order;
    ordered[idx].order = ordered[swapIdx].order;
    ordered[swapIdx].order = temp;
    updateWidgets([...ordered]);
  };

  const formattedDate = new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(new Date());

  return (
    <div className="space-y-6 pb-10">
      {/* Top Executive Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-[var(--text-secondary)]">
            <AscendIcon name="Calendar" size={14} />
            <span>{formattedDate}</span>
            <span>·</span>
            <span className="text-[var(--accent-primary)] font-semibold">
              ASCEND OS LIVE
            </span>
          </div>
          <h1 className="font-heading mt-1 text-2xl sm:text-3xl text-[var(--text-primary)]">
            Welcome back, {state.character.name}
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            {state.character.tagline}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveModule('focus')}
            className="inline-flex items-center gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-3.5 py-2 text-xs font-medium text-[var(--text-primary)] transition hover:border-[var(--accent-primary)]"
          >
            <AscendIcon name="Timer" size={15} className="text-[var(--accent-primary)]" />
            Start Focus
          </button>
          <button
            onClick={() => setActiveModule('planner')}
            className="inline-flex items-center gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-3.5 py-2 text-xs font-medium text-[var(--text-primary)] transition hover:border-[var(--accent-primary)]"
          >
            <AscendIcon name="Calendar" size={15} className="text-[var(--accent-primary)]" />
            Time Blocks
          </button>
          <button
            onClick={() => setCustomizing(!customizing)}
            className={`inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-medium transition ${
              customizing
                ? 'bg-[var(--accent-primary)] text-white'
                : 'border border-[var(--border-subtle)] bg-[var(--bg-surface)] text-[var(--text-primary)] hover:border-[var(--accent-primary)]'
            }`}
          >
            <AscendIcon name="Layout" size={15} />
            {customizing ? 'Done Customizing' : 'Customize Widgets'}
          </button>
        </div>
      </div>

      {/* Widget Layout Studio Drawer */}
      {customizing && (
        <div className="rounded-2xl border border-[var(--accent-primary)]/40 bg-[var(--bg-surface)] p-5 shadow-sm">
          <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-3">
            <div>
              <h3 className="font-subheading text-sm font-semibold text-[var(--text-primary)]">
                Dashboard Widget Architecture
              </h3>
              <p className="text-xs text-[var(--text-secondary)]">
                Show, hide, reorder, or resize any widget. Changes persist immediately.
              </p>
            </div>
            <span className="font-mono-metric rounded-lg bg-[var(--accent-soft)] px-2.5 py-1 text-xs font-semibold text-[var(--accent-primary)]">
              {visibleWidgets.length} / {sortedWidgets.length} Active
            </span>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-2.5 md:grid-cols-2">
            {sortedWidgets.map((w, idx) => (
              <div
                key={w.id}
                className="flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/60 px-3.5 py-2.5"
              >
                <div className="flex items-center gap-2.5">
                  <button
                    onClick={() => toggleWidgetVisibility(w.id)}
                    className={`flex h-6 w-6 items-center justify-center rounded-lg border transition ${
                      w.visible
                        ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                        : 'border-[var(--border-subtle)] bg-[var(--bg-surface)] text-[var(--text-muted)]'
                    }`}
                  >
                    <AscendIcon name={w.visible ? 'Eye' : 'EyeOff'} size={13} />
                  </button>
                  <span className="text-xs font-medium text-[var(--text-primary)]">
                    {w.title}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <select
                    value={w.size}
                    onChange={(e) =>
                      changeWidgetSize(
                        w.id,
                        e.target.value as DashboardWidgetConfig['size']
                      )
                    }
                    className="rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-2 py-1 text-[11px] text-[var(--text-primary)]"
                  >
                    <option value="compact">1 Col</option>
                    <option value="wide">2 Col</option>
                    <option value="full">Full Width</option>
                  </select>
                  <button
                    disabled={idx === 0}
                    onClick={() => moveWidgetOrder(w.id, -1)}
                    className="rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1 text-[var(--text-secondary)] disabled:opacity-30"
                  >
                    <AscendIcon name="ChevronUp" size={13} />
                  </button>
                  <button
                    disabled={idx === sortedWidgets.length - 1}
                    onClick={() => moveWidgetOrder(w.id, 1)}
                    className="rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1 text-[var(--text-secondary)] disabled:opacity-30"
                  >
                    <AscendIcon name="ChevronDown" size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Dynamic Responsive Bento Grid */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
        {visibleWidgets.map((widget) => {
          const colSpanClass =
            widget.size === 'full'
              ? 'lg:col-span-12'
              : widget.size === 'wide'
              ? 'lg:col-span-8'
              : 'lg:col-span-4';

          if (widget.id === 'character-card') {
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5 sm:p-6`}
              >
                <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
                  {/* Character Identity */}
                  <div className="flex items-start gap-4">
                    <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent-primary)] ring-1 ring-[var(--accent-primary)]/30">
                      <AscendIcon name={state.character.avatarIcon} size={30} />
                    </div>
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-character-custom text-lg font-bold text-[var(--text-primary)]">
                          {state.character.name}
                        </span>
                        <span className="rounded-full bg-[var(--accent-soft)] px-2.5 py-0.5 text-xs font-semibold text-[var(--accent-primary)]">
                          {activeTitle}
                        </span>
                        <span className="rounded-full border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-0.5 text-xs text-[var(--text-secondary)]">
                          {state.character.archetype}
                        </span>
                      </div>
                      <p className="text-xs text-[var(--text-secondary)]">
                        {state.character.customArchetypeDescription}
                      </p>

                      {/* Level & XP Bar */}
                      <div className="pt-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-mono-metric font-semibold text-[var(--text-primary)]">
                            LEVEL {levelStatus.level}
                          </span>
                          <span className="font-mono-metric text-[var(--text-secondary)]">
                            {levelStatus.xpIntoLevel.toLocaleString()} /{' '}
                            {levelStatus.xpNeededForLevel.toLocaleString()} XP (
                            {levelStatus.progressPercent}%) · Total{' '}
                            {levelStatus.totalXp.toLocaleString()} XP
                          </span>
                        </div>
                        <div className="mt-1.5 h-2.5 w-full max-w-md overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                          <div
                            className="h-full rounded-full bg-[var(--accent-primary)] transition-all duration-300"
                            style={{ width: `${levelStatus.progressPercent}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 4 Key Live Telemetry Counters */}
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                    <div className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/50 px-3.5 py-2.5">
                      <div className="flex items-center gap-1.5 text-[11px] font-medium text-[var(--text-secondary)]">
                        <AscendIcon name="Flame" size={14} className="text-emerald-500" />
                        Today's Habits
                      </div>
                      <div className="font-mono-metric mt-1 text-lg font-bold text-[var(--text-primary)]">
                        {completedHabitsToday}/{activeHabits.length}{' '}
                        <span className="text-xs font-normal text-[var(--text-secondary)]">
                          ({habitDailyPercent}%)
                        </span>
                      </div>
                    </div>

                    <div className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/50 px-3.5 py-2.5">
                      <div className="flex items-center gap-1.5 text-[11px] font-medium text-[var(--text-secondary)]">
                        <AscendIcon name="CheckSquare" size={14} className="text-sky-500" />
                        Tasks Done
                      </div>
                      <div className="font-mono-metric mt-1 text-lg font-bold text-[var(--text-primary)]">
                        {completedTasksCount}/{activeTasks.length}
                      </div>
                    </div>

                    <div className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/50 px-3.5 py-2.5">
                      <div className="flex items-center gap-1.5 text-[11px] font-medium text-[var(--text-secondary)]">
                        <AscendIcon name="GraduationCap" size={14} className="text-violet-500" />
                        Study Logged
                      </div>
                      <div className="font-mono-metric mt-1 text-lg font-bold text-[var(--text-primary)]">
                        {totalStudyHours.toFixed(1)}h
                      </div>
                    </div>

                    <div className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/50 px-3.5 py-2.5">
                      <div className="flex items-center gap-1.5 text-[11px] font-medium text-[var(--text-secondary)]">
                        <AscendIcon name="Timer" size={14} className="text-amber-500" />
                        Focus Time
                      </div>
                      <div className="font-mono-metric mt-1 text-lg font-bold text-[var(--text-primary)]">
                        {(totalFocusMinutes / 60).toFixed(1)}h
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          }

          if (widget.id === 'habit-tracker') {
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <AscendIcon name="Flame" size={18} className="text-[var(--accent-primary)]" />
                      <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
                        {widget.title}
                      </h2>
                    </div>
                    <button
                      onClick={() => setActiveModule('habits')}
                      className="text-xs font-medium text-[var(--accent-primary)] hover:underline"
                    >
                      Full Matrix →
                    </button>
                  </div>

                  <div className="mt-4 space-y-2.5">
                    {activeHabits.map((habit) => {
                      const currentVal = habit.history[today] ?? 0;
                      const isDone = isHabitCompletedOnDate(habit, today);
                      const streak = calculateHabitStreak(habit);
                      const pct = Math.min(
                        100,
                        Math.round((currentVal / habit.targetValue) * 100)
                      );

                      return (
                        <div
                          key={habit.id}
                          className="flex flex-col gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3 sm:flex-row sm:items-center sm:justify-between"
                        >
                          <div className="flex items-center gap-3">
                            <button
                              onClick={() =>
                                logHabitProgress(
                                  habit.id,
                                  today,
                                  isDone ? 0 : habit.targetValue
                                )
                              }
                              className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border transition ${
                                isDone
                                  ? 'border-emerald-500 bg-emerald-500 text-white'
                                  : 'border-[var(--border-subtle)] bg-[var(--bg-surface)] text-[var(--text-secondary)] hover:border-[var(--accent-primary)]'
                              }`}
                              title="Toggle today's completion"
                            >
                              <AscendIcon
                                name={isDone ? 'CheckCircle2' : habit.icon}
                                size={17}
                              />
                            </button>
                            <div>
                              <div className="flex items-center gap-2">
                                <span
                                  className={`font-task-custom text-sm font-medium ${
                                    isDone
                                      ? 'line-through text-[var(--text-secondary)]'
                                      : 'text-[var(--text-primary)]'
                                  }`}
                                >
                                  {habit.name}
                                </span>
                                <span className="font-mono-metric rounded-md bg-[var(--accent-soft)] px-1.5 py-0.5 text-[10px] font-semibold text-[var(--accent-primary)]">
                                  +{habit.xpReward} XP
                                </span>
                              </div>
                              <div className="mt-0.5 flex items-center gap-2 text-[11px] text-[var(--text-secondary)]">
                                <span>
                                  Target: {habit.targetValue} {habit.unit}
                                </span>
                                <span>·</span>
                                <span className="font-mono-metric text-amber-500 font-medium">
                                  {streak}d streak
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Numeric / Duration stepper controls */}
                          <div className="flex items-center gap-2 self-end sm:self-center">
                            {habit.type !== 'yes_no' && (
                              <div className="flex items-center gap-1 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-1.5 py-1">
                                <button
                                  onClick={() =>
                                    logHabitProgress(
                                      habit.id,
                                      today,
                                      Math.max(
                                        0,
                                        currentVal -
                                          (habit.targetValue >= 10 ? 5 : 1)
                                      )
                                    )
                                  }
                                  className="px-1.5 text-xs font-bold text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
                                >
                                  -
                                </button>
                                <span className="font-mono-metric min-w-[54px] text-center text-xs font-semibold text-[var(--text-primary)]">
                                  {currentVal}/{habit.targetValue}
                                </span>
                                <button
                                  onClick={() =>
                                    logHabitProgress(
                                      habit.id,
                                      today,
                                      currentVal +
                                        (habit.targetValue >= 10 ? 5 : 1)
                                    )
                                  }
                                  className="px-1.5 text-xs font-bold text-[var(--accent-primary)]"
                                >
                                  +
                                </button>
                              </div>
                            )}
                            <div className="w-16 hidden sm:block">
                              <div className="h-1.5 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                                <div
                                  className="h-full rounded-full bg-emerald-500 transition-all"
                                  style={{ width: `${pct}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          }

          if (widget.id === 'task-list') {
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <AscendIcon
                        name="CheckSquare"
                        size={18}
                        className="text-[var(--accent-primary)]"
                      />
                      <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
                        {widget.title}
                      </h2>
                    </div>
                    <button
                      onClick={() => setActiveModule('tasks')}
                      className="text-xs font-medium text-[var(--accent-primary)] hover:underline"
                    >
                      All Tasks →
                    </button>
                  </div>

                  <div className="mt-4 space-y-2.5">
                    {activeTasks.slice(0, 5).map((task) => {
                      const done = task.status === 'Completed';
                      return (
                        <div
                          key={task.id}
                          className="flex items-start justify-between gap-2.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3"
                        >
                          <div className="flex items-start gap-2.5">
                            <button
                              onClick={() => toggleTaskStatus(task.id)}
                              className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition ${
                                done
                                  ? 'border-emerald-500 bg-emerald-500 text-white'
                                  : 'border-[var(--border-subtle)] bg-[var(--bg-surface)]'
                              }`}
                            >
                              {done && <AscendIcon name="CheckCircle2" size={13} />}
                            </button>
                            <div>
                              <p
                                className={`font-task-custom text-xs font-medium ${
                                  done
                                    ? 'line-through text-[var(--text-secondary)]'
                                    : 'text-[var(--text-primary)]'
                                }`}
                              >
                                {task.title}
                              </p>
                              <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[10px] text-[var(--text-secondary)]">
                                <span className="rounded bg-[var(--bg-surface)] px-1.5 py-0.5 font-medium">
                                  {task.priority}
                                </span>
                                {task.scheduledTime && (
                                  <span className="font-mono-metric">
                                    {task.scheduledTime}
                                  </span>
                                )}
                                <span className="font-mono-metric text-[var(--accent-primary)] font-semibold">
                                  +{task.xpReward} XP
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          }

          if (widget.id === 'goal-progress') {
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AscendIcon
                      name="Target"
                      size={18}
                      className="text-[var(--accent-primary)]"
                    />
                    <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
                      {widget.title}
                    </h2>
                  </div>
                  <button
                    onClick={() => setActiveModule('goals')}
                    className="text-xs font-medium text-[var(--accent-primary)] hover:underline"
                  >
                    Manage →
                  </button>
                </div>

                <div className="mt-4 space-y-3.5">
                  {activeGoals.slice(0, 3).map((goal) => {
                    const linkedTasks = state.tasks.filter(
                      (t) => t.linkedGoalId === goal.id
                    );
                    const pct = calculateGoalProgress(goal, linkedTasks);
                    const doneMs = goal.milestones.filter((m) => m.completed).length;

                    return (
                      <div
                        key={goal.id}
                        className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3.5"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <AscendIcon
                              name={goal.icon}
                              size={16}
                              style={{ color: goal.color }}
                            />
                            <span className="text-xs font-semibold text-[var(--text-primary)]">
                              {goal.title}
                            </span>
                          </div>
                          <span className="font-mono-metric text-xs font-bold text-[var(--accent-primary)]">
                            {pct}%
                          </span>
                        </div>
                        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                          <div
                            className="h-full rounded-full transition-all"
                            style={{
                              width: `${pct}%`,
                              backgroundColor: goal.color || 'var(--accent-primary)',
                            }}
                          />
                        </div>
                        <div className="mt-2 flex items-center justify-between text-[11px] text-[var(--text-secondary)]">
                          <span>
                            {doneMs}/{goal.milestones.length} Milestones
                          </span>
                          <span className="font-mono-metric">
                            Due {goal.targetDate}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          }

          if (widget.id === 'daily-missions') {
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AscendIcon
                      name="Compass"
                      size={18}
                      className="text-[var(--accent-primary)]"
                    />
                    <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
                      {widget.title}
                    </h2>
                  </div>
                  <button
                    onClick={() => setActiveModule('missions')}
                    className="text-xs font-medium text-[var(--accent-primary)] hover:underline"
                  >
                    Quest Log →
                  </button>
                </div>

                <div className="mt-4 space-y-3">
                  {state.missions.slice(0, 3).map((mis) => {
                    const pct = Math.min(
                      100,
                      Math.round((mis.currentCount / mis.targetCount) * 100)
                    );
                    return (
                      <div
                        key={mis.id}
                        className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-[var(--text-primary)]">
                            {mis.name}
                          </span>
                          <span className="font-mono-metric rounded bg-[var(--accent-soft)] px-1.5 py-0.5 text-[10px] font-semibold text-[var(--accent-primary)]">
                            +{mis.xpReward} XP
                          </span>
                        </div>
                        <p className="mt-1 text-[11px] text-[var(--text-secondary)] line-clamp-1">
                          {mis.description}
                        </p>
                        <div className="mt-2 flex items-center justify-between gap-2">
                          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                            <div
                              className="h-full rounded-full bg-[var(--accent-primary)] transition-all"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <span className="font-mono-metric text-[11px] font-semibold text-[var(--text-primary)]">
                            {mis.currentCount}/{mis.targetCount}
                          </span>
                          <button
                            onClick={() => incrementMissionProgress(mis.id, 1)}
                            disabled={mis.currentCount >= mis.targetCount}
                            className="rounded-md border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-2 py-0.5 text-[10px] font-semibold text-[var(--accent-primary)] disabled:opacity-40"
                          >
                            +1
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          }

          if (widget.id === 'weekly-stats') {
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AscendIcon
                      name="Shield"
                      size={18}
                      className="text-[var(--accent-primary)]"
                    />
                    <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
                      {widget.title}
                    </h2>
                  </div>
                  <button
                    onClick={() => setActiveModule('character')}
                    className="text-xs font-medium text-[var(--accent-primary)] hover:underline"
                  >
                    Character →
                  </button>
                </div>
                <div className="mt-2 flex justify-center">
                  <RadarChartSVG attributes={state.attributes} size={235} />
                </div>
              </div>
            );
          }

          if (widget.id === 'xp-overview') {
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AscendIcon
                      name="Zap"
                      size={18}
                      className="text-[var(--accent-primary)]"
                    />
                    <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
                      {widget.title}
                    </h2>
                  </div>
                  <button
                    onClick={() => setActiveModule('xp-settings')}
                    className="text-xs font-medium text-[var(--accent-primary)] hover:underline"
                  >
                    XP Rules & Full Ledger →
                  </button>
                </div>
                <div className="mt-3 space-y-2">
                  {state.xpTransactions.slice(0, 5).map((tx) => (
                    <div
                      key={tx.id}
                      className="flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/30 px-3 py-2 text-xs"
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <span
                          className={`font-mono-metric rounded-md px-2 py-0.5 text-[11px] font-bold ${
                            tx.xpAmount >= 0
                              ? 'bg-emerald-500/15 text-emerald-500'
                              : 'bg-rose-500/15 text-rose-500'
                          }`}
                        >
                          {tx.xpAmount >= 0 ? `+${tx.xpAmount}` : tx.xpAmount} XP
                        </span>
                        <span className="truncate font-medium text-[var(--text-primary)]">
                          {tx.reason}
                        </span>
                      </div>
                      <span className="font-mono-metric shrink-0 text-[11px] text-[var(--text-secondary)]">
                        {tx.date}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            );
          }

          if (widget.id === 'focus-timer') {
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <AscendIcon
                        name="Timer"
                        size={18}
                        className="text-[var(--accent-primary)]"
                      />
                      <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
                        {widget.title}
                      </h2>
                    </div>
                    <span className="font-mono-metric rounded bg-[var(--accent-soft)] px-2 py-0.5 text-[11px] font-semibold text-[var(--accent-primary)]">
                      +{state.focusConfig.xpPer25MinSession} XP / 25m
                    </span>
                  </div>
                  <p className="mt-2 text-xs text-[var(--text-secondary)]">
                    Launch a distraction-free Pomodoro, custom deep study block, or stopwatch session linked to your goals.
                  </p>
                </div>

                <div className="mt-4 flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/50 p-3.5">
                  <div>
                    <div className="font-mono-metric text-2xl font-bold text-[var(--text-primary)]">
                      {state.focusConfig.pomodoroMinutes}:00
                    </div>
                    <div className="text-[11px] text-[var(--text-secondary)]">
                      {state.focusSessions.length} sessions completed
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveModule('focus')}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white shadow-sm transition hover:opacity-95"
                  >
                    <AscendIcon name="Play" size={14} />
                    Open Studio
                  </button>
                </div>
              </div>
            );
          }

          if (widget.id === 'recent-achievements') {
            const unlocked = state.achievements.filter((a) => a.unlocked);
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AscendIcon
                      name="Award"
                      size={18}
                      className="text-[var(--accent-primary)]"
                    />
                    <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
                      {widget.title}
                    </h2>
                  </div>
                  <span className="font-mono-metric text-xs font-semibold text-[var(--text-secondary)]">
                    {unlocked.length}/{state.achievements.length}
                  </span>
                </div>
                <div className="mt-3 space-y-2.5">
                  {unlocked.slice(0, 3).map((ach) => (
                    <div
                      key={ach.id}
                      className="flex items-center gap-3 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-2.5"
                    >
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--accent-soft)] text-[var(--accent-primary)]">
                        <AscendIcon name={ach.icon} size={17} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-xs font-semibold text-[var(--text-primary)]">
                          {ach.name}
                        </div>
                        <div className="truncate text-[11px] text-[var(--text-secondary)]">
                          {ach.description}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          }

          if (widget.id === 'journal-shortcut') {
            const latest = state.journalEntries[0];
            return (
              <div
                key={widget.id}
                className={`${colSpanClass} flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <AscendIcon
                        name="NotebookPen"
                        size={18}
                        className="text-[var(--accent-primary)]"
                      />
                      <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
                        {widget.title}
                      </h2>
                    </div>
                    <button
                      onClick={() => setActiveModule('journal')}
                      className="text-xs font-medium text-[var(--accent-primary)] hover:underline"
                    >
                      Open Journal →
                    </button>
                  </div>

                  {latest ? (
                    <div className="mt-3 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3">
                      <div className="text-xs font-semibold text-[var(--text-primary)]">
                        {latest.title}
                      </div>
                      <p
                        className={`mt-1 line-clamp-3 text-xs text-[var(--text-secondary)] ${
                          latest.useHandwriting ? 'font-journal-custom text-base' : ''
                        }`}
                      >
                        {latest.content}
                      </p>
                    </div>
                  ) : null}
                </div>

                <button
                  onClick={() => setActiveModule('journal')}
                  className="mt-3 inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] py-2 text-xs font-medium text-[var(--text-primary)] hover:border-[var(--accent-primary)]"
                >
                  <AscendIcon name="Feather" size={14} />
                  Write Today's Reflection
                </button>
              </div>
            );
          }

          return null;
        })}
      </div>
    </div>
  );
};
