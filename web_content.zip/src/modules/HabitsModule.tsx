import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon, PICKABLE_ICONS } from '../components/AscendIcon';
import {
  calculateHabitConsistency,
  calculateHabitStreak,
  isHabitCompletedOnDate,
} from '../utils/progressionEngine';
import { getPastDateStr, getTodayStr } from '../data/initialAscendState';
import { HabitItem, HabitType } from '../types/ascend';

export const HabitsModule: React.FC = () => {
  const { state, saveHabit, deleteHabit, logHabitProgress } = useAscend();

  const [statusFilter, setStatusFilter] = useState<'Active' | 'Paused' | 'Archived' | 'All'>('Active');
  const [editingHabit, setEditingHabit] = useState<HabitItem | null>(null);
  const [selectedHistoryDate, setSelectedHistoryDate] = useState<string>(getTodayStr());

  const today = getTodayStr();
  // Last 14 days for the interactive historical matrix
  const recentDates = Array.from({ length: 14 }, (_, idx) =>
    getPastDateStr(13 - idx)
  );

  const filteredHabits = state.habits
    .filter((h) => statusFilter === 'All' || h.status === statusFilter)
    .sort((a, b) => a.order - b.order);

  const handleOpenNewHabit = () => {
    setEditingHabit({
      id: `hab-${Date.now()}`,
      name: '',
      description: '',
      icon: 'Flame',
      color: '#7C5CFC',
      category: 'Education',
      type: 'numeric',
      targetValue: 30,
      unit: 'mins',
      scheduleType: 'daily',
      scheduledDays: [0, 1, 2, 3, 4, 5, 6],
      reminderTime: '08:00',
      startDate: today,
      xpReward: state.xpSettings.defaultHabitXp,
      attributeIds: ['attr-dis'],
      status: 'Active',
      order: state.habits.length + 1,
      history: {},
    });
  };

  const handleDuplicateHabit = (hab: HabitItem) => {
    saveHabit({
      ...hab,
      id: `hab-${Date.now()}`,
      name: `${hab.name} (Copy)`,
      order: state.habits.length + 1,
      history: {},
    });
  };

  const moveHabitOrder = (habit: HabitItem, dir: -1 | 1) => {
    const ordered = [...state.habits].sort((a, b) => a.order - b.order);
    const idx = ordered.findIndex((h) => h.id === habit.id);
    const swapIdx = idx + dir;
    if (idx < 0 || swapIdx < 0 || swapIdx >= ordered.length) return;
    const other = ordered[swapIdx];
    saveHabit({ ...habit, order: other.order });
    saveHabit({ ...other, order: habit.order });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            Habit Consistency Matrix
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            Track Yes/No, Numeric, Count, Duration, and Checklist habits with independent custom XP and historical entry correction.
          </p>
        </div>

        <button
          onClick={handleOpenNewHabit}
          className="inline-flex items-center gap-2 rounded-xl bg-[var(--accent-primary)] px-4 py-2.5 text-xs font-semibold text-white shadow-sm"
        >
          <AscendIcon name="Plus" size={16} />
          Create Custom Habit
        </button>
      </div>

      {/* Filter Bar & Date Inspector Selector */}
      <div className="flex flex-col gap-3 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-1.5">
          {(['Active', 'Paused', 'Archived', 'All'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                statusFilter === st
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-[var(--text-secondary)]">
            Active Log Date (Correct Any Past Day):
          </span>
          <input
            type="date"
            max={today}
            value={selectedHistoryDate}
            onChange={(e) => setSelectedHistoryDate(e.target.value || today)}
            className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-semibold text-[var(--text-primary)]"
          />
        </div>
      </div>

      {/* Habit Cards with 14-Day Interactive Calendar Strip */}
      <div className="space-y-4">
        {filteredHabits.map((habit) => {
          const valOnSelectedDate = habit.history[selectedHistoryDate] ?? 0;
          const doneOnSelectedDate = isHabitCompletedOnDate(
            habit,
            selectedHistoryDate
          );
          const streak = calculateHabitStreak(habit);
          const consistency7d = calculateHabitConsistency(habit, 7);
          const consistency30d = calculateHabitConsistency(habit, 30);
          const linkedAttrs = state.attributes.filter((a) =>
            habit.attributeIds.includes(a.id)
          );

          return (
            <div
              key={habit.id}
              className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
            >
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                {/* Habit Info & Toggle */}
                <div className="flex items-start gap-3.5">
                  <button
                    onClick={() =>
                      logHabitProgress(
                        habit.id,
                        selectedHistoryDate,
                        doneOnSelectedDate ? 0 : habit.targetValue
                      )
                    }
                    className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border transition ${
                      doneOnSelectedDate
                        ? 'border-emerald-500 bg-emerald-500 text-white'
                        : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:border-[var(--accent-primary)]'
                    }`}
                  >
                    <AscendIcon
                      name={doneOnSelectedDate ? 'CheckCircle2' : habit.icon}
                      size={22}
                    />
                  </button>

                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-task-custom text-base font-bold text-[var(--text-primary)]">
                        {habit.name}
                      </h2>
                      <span className="rounded-full bg-[var(--bg-elevated)] px-2.5 py-0.5 text-[11px] text-[var(--text-secondary)]">
                        {habit.category}
                      </span>
                      <span className="rounded-full border border-[var(--border-subtle)] px-2 py-0.5 text-[10px] font-semibold uppercase text-[var(--text-secondary)]">
                        {habit.type.replace('_', '/')} · {habit.targetValue}{' '}
                        {habit.unit}
                      </span>
                      <span className="font-mono-metric rounded-full bg-[var(--accent-soft)] px-2.5 py-0.5 text-xs font-bold text-[var(--accent-primary)]">
                        +{habit.xpReward} XP
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-[var(--text-secondary)]">
                      {habit.description}
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-3 text-xs">
                      <span className="font-mono-metric font-semibold text-amber-500">
                        Streak: {streak}d
                      </span>
                      <span className="font-mono-metric text-[var(--text-secondary)]">
                        7d: {consistency7d}% · 30d: {consistency30d}%
                      </span>
                      {habit.reminderTime && (
                        <span className="font-mono-metric text-[var(--text-muted)]">
                          Reminder: {habit.reminderTime}
                        </span>
                      )}
                      {linkedAttrs.map((a) => (
                        <span
                          key={a.id}
                          className="font-mono-metric rounded border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-1.5 py-0.5 text-[10px] font-semibold text-[var(--text-primary)]"
                        >
                          {a.code}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Numeric Entry Input for Selected Date & Actions */}
                <div className="flex flex-wrap items-center gap-2">
                  <div className="flex items-center gap-1.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5">
                    <span className="text-[11px] text-[var(--text-secondary)]">
                      {selectedHistoryDate === today ? 'Today' : selectedHistoryDate}:
                    </span>
                    <input
                      type="number"
                      min={0}
                      step={habit.type === 'duration' ? 0.5 : 1}
                      value={valOnSelectedDate}
                      onChange={(e) =>
                        logHabitProgress(
                          habit.id,
                          selectedHistoryDate,
                          Number(e.target.value) || 0
                        )
                      }
                      className="font-mono-metric w-16 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-2 py-1 text-center text-xs font-bold text-[var(--text-primary)]"
                    />
                    <span className="text-xs text-[var(--text-secondary)]">
                      / {habit.targetValue} {habit.unit}
                    </span>
                  </div>

                  <button
                    onClick={() => moveHabitOrder(habit, -1)}
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-2 text-[var(--text-secondary)]"
                    title="Move Up"
                  >
                    <AscendIcon name="ChevronUp" size={14} />
                  </button>
                  <button
                    onClick={() => moveHabitOrder(habit, 1)}
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-2 text-[var(--text-secondary)]"
                    title="Move Down"
                  >
                    <AscendIcon name="ChevronDown" size={14} />
                  </button>
                  <button
                    onClick={() => setEditingHabit(habit)}
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-medium text-[var(--text-primary)]"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDuplicateHabit(habit)}
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs text-[var(--text-secondary)]"
                  >
                    Duplicate
                  </button>
                </div>
              </div>

              {/* 14-Day Interactive Calendar History Strip */}
              <div className="mt-4 border-t border-[var(--border-subtle)] pt-3">
                <div className="mb-1.5 flex items-center justify-between text-[11px] text-[var(--text-secondary)]">
                  <span>
                    14-Day History (Click any date cell to toggle or correct entry)
                  </span>
                  <span className="font-mono-metric">
                    Target: {habit.targetValue} {habit.unit}
                  </span>
                </div>
                <div className="grid grid-cols-7 gap-1.5 sm:grid-cols-14">
                  {recentDates.map((dStr) => {
                    const dayVal = habit.history[dStr] ?? 0;
                    const dayDone = dayVal >= habit.targetValue;
                    const dayPartial = dayVal > 0 && dayVal < habit.targetValue;
                    const dayLabel = dStr.slice(8, 10);

                    return (
                      <button
                        key={dStr}
                        onClick={() => {
                          setSelectedHistoryDate(dStr);
                          logHabitProgress(
                            habit.id,
                            dStr,
                            dayDone ? 0 : habit.targetValue
                          );
                        }}
                        className={`flex flex-col items-center justify-center rounded-xl border py-1.5 text-center transition ${
                          dayDone
                            ? 'border-emerald-500 bg-emerald-500 text-white'
                            : dayPartial
                            ? 'border-amber-500/60 bg-amber-500/15 text-amber-500'
                            : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)]/50 text-[var(--text-secondary)] hover:border-[var(--accent-primary)]'
                        }`}
                        title={`${dStr}: ${dayVal}/${habit.targetValue} ${habit.unit}`}
                      >
                        <span className="font-mono-metric text-[10px] font-bold">
                          {dayLabel}
                        </span>
                        <span className="font-mono-metric text-[9px] opacity-85">
                          {dayVal}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Habit Editor Modal */}
      {editingHabit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
          <div className="my-8 w-full max-w-lg rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                Configure Custom Habit & XP Rule
              </h3>
              <button
                onClick={() => setEditingHabit(null)}
                className="text-[var(--text-secondary)]"
              >
                <AscendIcon name="X" size={18} />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Habit Name
                </label>
                <input
                  type="text"
                  placeholder="e.g., Study for 4 hours, Solve 30 questions, Read 20 pages"
                  value={editingHabit.name}
                  onChange={(e) =>
                    setEditingHabit({ ...editingHabit, name: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>

              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Description & Completion Condition
                </label>
                <input
                  type="text"
                  value={editingHabit.description}
                  onChange={(e) =>
                    setEditingHabit({
                      ...editingHabit,
                      description: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="col-span-2">
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Habit Type
                  </label>
                  <select
                    value={editingHabit.type}
                    onChange={(e) => {
                      const nextType = e.target.value as HabitType;
                      setEditingHabit({
                        ...editingHabit,
                        type: nextType,
                        targetValue:
                          nextType === 'yes_no' ? 1 : editingHabit.targetValue,
                        unit:
                          nextType === 'yes_no'
                            ? 'completion'
                            : editingHabit.unit,
                      });
                    }}
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="yes_no">Yes / No Habit</option>
                    <option value="numeric">Numeric Habit</option>
                    <option value="count">Count-Based Habit</option>
                    <option value="duration">Duration-Based Habit</option>
                    <option value="checklist">Checklist Habit</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Target Value
                  </label>
                  <input
                    type="number"
                    min={1}
                    step="any"
                    value={editingHabit.targetValue}
                    onChange={(e) =>
                      setEditingHabit({
                        ...editingHabit,
                        targetValue: Math.max(0.5, Number(e.target.value) || 1),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Unit
                  </label>
                  <input
                    type="text"
                    placeholder="hours, pages, mins"
                    value={editingHabit.unit}
                    onChange={(e) =>
                      setEditingHabit({ ...editingHabit, unit: e.target.value })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Independent XP (0+)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editingHabit.xpReward}
                    onChange={(e) =>
                      setEditingHabit({
                        ...editingHabit,
                        xpReward: Math.max(0, Number(e.target.value) || 0),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs font-bold text-[var(--accent-primary)]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Category
                  </label>
                  <input
                    type="text"
                    value={editingHabit.category}
                    onChange={(e) =>
                      setEditingHabit({
                        ...editingHabit,
                        category: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Reminder Time
                  </label>
                  <input
                    type="time"
                    value={editingHabit.reminderTime || '08:00'}
                    onChange={(e) =>
                      setEditingHabit({
                        ...editingHabit,
                        reminderTime: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Status
                  </label>
                  <select
                    value={editingHabit.status}
                    onChange={(e) =>
                      setEditingHabit({
                        ...editingHabit,
                        status: e.target.value as HabitItem['status'],
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="Active">Active</option>
                    <option value="Paused">Paused</option>
                    <option value="Archived">Archived</option>
                  </select>
                </div>
              </div>

              {/* Linked Attributes */}
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Linked Character Attributes
                </label>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {state.attributes.map((attr) => {
                    const selected = editingHabit.attributeIds.includes(attr.id);
                    return (
                      <button
                        type="button"
                        key={attr.id}
                        onClick={() => {
                          const nextIds = selected
                            ? editingHabit.attributeIds.filter(
                                (id) => id !== attr.id
                              )
                            : [...editingHabit.attributeIds, attr.id];
                          setEditingHabit({
                            ...editingHabit,
                            attributeIds: nextIds,
                          });
                        }}
                        className={`rounded-lg border px-2 py-1 text-[11px] font-semibold transition ${
                          selected
                            ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                            : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                        }`}
                      >
                        {attr.code}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Icon
                </label>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {PICKABLE_ICONS.slice(0, 14).map((ic) => (
                    <button
                      type="button"
                      key={ic}
                      onClick={() => setEditingHabit({ ...editingHabit, icon: ic })}
                      className={`flex h-8 w-8 items-center justify-center rounded-lg border ${
                        editingHabit.icon === ic
                          ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                          : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                      }`}
                    >
                      <AscendIcon name={ic} size={15} />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteHabit(editingHabit.id);
                  setEditingHabit(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Habit
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingHabit(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingHabit.name.trim()) return;
                    saveHabit(editingHabit);
                    setEditingHabit(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Habit
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
