import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon } from '../components/AscendIcon';
import { calculateProjectProgress } from '../utils/progressionEngine';
import { getFutureDateStr, getTodayStr } from '../data/initialAscendState';
import { ProjectItem, TaskItem } from '../types/ascend';

interface TasksAndProjectsProps {
  initialView?: 'tasks' | 'projects';
}

export const TasksAndProjectsModule: React.FC<TasksAndProjectsProps> = ({
  initialView = 'tasks',
}) => {
  const {
    state,
    saveTask,
    deleteTask,
    toggleTaskStatus,
    saveProject,
    deleteProject,
    toggleProjectMilestone,
  } = useAscend();

  const [viewMode, setViewMode] = useState<'tasks' | 'projects'>(initialView);
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);
  const [editingProject, setEditingProject] = useState<ProjectItem | null>(null);
  const [newSubtaskInputs, setNewSubtaskInputs] = useState<Record<string, string>>({});
  const [newProjMilestoneInputs, setNewProjMilestoneInputs] = useState<
    Record<string, string>
  >({});

  const filteredTasks = state.tasks.filter(
    (t) => statusFilter === 'All' || t.status === statusFilter
  );

  const handleOpenNewTask = () => {
    setEditingTask({
      id: `task-${Date.now()}`,
      title: '',
      description: '',
      dueDate: getTodayStr(),
      scheduledTime: '10:00',
      durationMinutes: 45,
      priority: 'High',
      category: 'Education',
      status: 'To-do',
      subtasks: [],
      notes: '',
      recurrence: 'None',
      linkedGoalId: state.goals[0]?.id,
      linkedProjectId: state.projects[0]?.id,
      attributeIds: ['attr-int', 'attr-foc'],
      xpReward: state.xpSettings.defaultTaskXp,
    });
  };

  const handleOpenNewProject = () => {
    setEditingProject({
      id: `proj-${Date.now()}`,
      name: '',
      description: '',
      category: 'Engineering',
      icon: 'FolderKanban',
      color: '#7C5CFC',
      startDate: getTodayStr(),
      deadline: getFutureDateStr(21),
      status: 'Active',
      priority: 'High',
      milestones: [
        { id: `pms-${Date.now()}`, title: 'Phase 1 Architecture & Spec', completed: false },
      ],
      notes: '',
      linkedGoalId: state.goals[0]?.id,
      xpReward: 200,
    });
  };

  const handleToggleSubtask = (task: TaskItem, subId: string) => {
    const updated: TaskItem = {
      ...task,
      subtasks: task.subtasks.map((s) =>
        s.id === subId ? { ...s, completed: !s.completed } : s
      ),
    };
    saveTask(updated);
  };

  const handleAddSubtask = (task: TaskItem) => {
    const title = (newSubtaskInputs[task.id] || '').trim();
    if (!title) return;
    saveTask({
      ...task,
      subtasks: [
        ...task.subtasks,
        { id: `sub-${Date.now()}`, title, completed: false },
      ],
    });
    setNewSubtaskInputs({ ...newSubtaskInputs, [task.id]: '' });
  };

  const handleAddProjectMilestone = (proj: ProjectItem) => {
    const title = (newProjMilestoneInputs[proj.id] || '').trim();
    if (!title) return;
    saveProject({
      ...proj,
      milestones: [
        ...proj.milestones,
        { id: `pms-${Date.now()}`, title, completed: false },
      ],
    });
    setNewProjMilestoneInputs({ ...newProjMilestoneInputs, [proj.id]: '' });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            {viewMode === 'tasks'
              ? 'Task Execution Queue'
              : 'Project Dashboards & Milestones'}
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            Every task and project links directly to your strategic goals and character progression.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1">
            <button
              onClick={() => setViewMode('tasks')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                viewMode === 'tasks'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <AscendIcon name="CheckSquare" size={14} />
              Tasks ({state.tasks.length})
            </button>
            <button
              onClick={() => setViewMode('projects')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                viewMode === 'projects'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <AscendIcon name="FolderKanban" size={14} />
              Projects ({state.projects.length})
            </button>
          </div>

          {viewMode === 'tasks' ? (
            <button
              onClick={handleOpenNewTask}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Plus" size={15} />
              New Task
            </button>
          ) : (
            <button
              onClick={handleOpenNewProject}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Plus" size={15} />
              New Project
            </button>
          )}
        </div>
      </div>

      {/* VIEW 1: TASKS */}
      {viewMode === 'tasks' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-1.5 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-3.5">
            {['All', 'To-do', 'In progress', 'Completed', 'Cancelled', 'Archived'].map(
              (st) => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                    statusFilter === st
                      ? 'bg-[var(--accent-primary)] text-white'
                      : 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                  }`}
                >
                  {st}
                </button>
              )
            )}
          </div>

          <div className="space-y-3.5">
            {filteredTasks.map((task) => {
              const done = task.status === 'Completed';
              const linkedGoal = state.goals.find(
                (g) => g.id === task.linkedGoalId
              );
              const linkedProject = state.projects.find(
                (p) => p.id === task.linkedProjectId
              );

              return (
                <div
                  key={task.id}
                  className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => toggleTaskStatus(task.id)}
                        className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border transition ${
                          done
                            ? 'border-emerald-500 bg-emerald-500 text-white'
                            : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)]'
                        }`}
                      >
                        {done && <AscendIcon name="CheckCircle2" size={14} />}
                      </button>

                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3
                            className={`font-task-custom text-sm sm:text-base font-bold ${
                              done
                                ? 'line-through text-[var(--text-secondary)]'
                                : 'text-[var(--text-primary)]'
                            }`}
                          >
                            {task.title}
                          </h3>
                          <span className="rounded-full bg-[var(--bg-elevated)] px-2.5 py-0.5 text-[11px] font-semibold text-[var(--text-primary)]">
                            {task.priority}
                          </span>
                          <span className="font-mono-metric rounded-full bg-[var(--accent-soft)] px-2.5 py-0.5 text-xs font-bold text-[var(--accent-primary)]">
                            +{task.xpReward} XP
                          </span>
                        </div>
                        <p className="mt-1 text-xs text-[var(--text-secondary)]">
                          {task.description}
                        </p>

                        <div className="mt-2 flex flex-wrap items-center gap-2.5 text-[11px] text-[var(--text-secondary)]">
                          <span className="font-mono-metric">
                            Due: {task.dueDate}{' '}
                            {task.scheduledTime ? `at ${task.scheduledTime}` : ''}
                          </span>
                          {task.recurrence !== 'None' && (
                            <span className="rounded bg-[var(--bg-elevated)] px-1.5 py-0.5">
                              Repeats: {task.recurrence}
                            </span>
                          )}
                          {linkedGoal && (
                            <span className="rounded bg-[var(--bg-elevated)] px-2 py-0.5 text-[var(--accent-primary)] font-medium">
                              Goal: {linkedGoal.title}
                            </span>
                          )}
                          {linkedProject && (
                            <span className="rounded bg-[var(--bg-elevated)] px-2 py-0.5 font-medium">
                              Project: {linkedProject.name}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-start">
                      <select
                        value={task.status}
                        onChange={(e) => {
                          const nextSt = e.target.value as TaskItem['status'];
                          if (
                            (nextSt === 'Completed' && task.status !== 'Completed') ||
                            (nextSt !== 'Completed' && task.status === 'Completed')
                          ) {
                            toggleTaskStatus(task.id);
                          } else {
                            saveTask({ ...task, status: nextSt });
                          }
                        }}
                        className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1.5 text-xs font-semibold text-[var(--text-primary)]"
                      >
                        <option value="To-do">To-do</option>
                        <option value="In progress">In progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                        <option value="Archived">Archived</option>
                      </select>
                      <button
                        onClick={() => setEditingTask(task)}
                        className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs text-[var(--text-primary)]"
                      >
                        Edit
                      </button>
                    </div>
                  </div>

                  {/* Subtasks */}
                  <div className="mt-4 border-t border-[var(--border-subtle)] pt-3 space-y-2">
                    {task.subtasks.map((sub) => (
                      <div
                        key={sub.id}
                        className="flex items-center gap-2.5 text-xs"
                      >
                        <button
                          onClick={() => handleToggleSubtask(task, sub.id)}
                          className={`flex h-4 w-4 items-center justify-center rounded border ${
                            sub.completed
                              ? 'border-emerald-500 bg-emerald-500 text-white'
                              : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)]'
                          }`}
                        >
                          {sub.completed && (
                            <AscendIcon name="CheckCircle2" size={11} />
                          )}
                        </button>
                        <span
                          className={
                            sub.completed
                              ? 'line-through text-[var(--text-secondary)]'
                              : 'text-[var(--text-primary)]'
                          }
                        >
                          {sub.title}
                        </span>
                      </div>
                    ))}

                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="text"
                        placeholder="Add subtask step..."
                        value={newSubtaskInputs[task.id] || ''}
                        onChange={(e) =>
                          setNewSubtaskInputs({
                            ...newSubtaskInputs,
                            [task.id]: e.target.value,
                          })
                        }
                        className="flex-1 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs text-[var(--text-primary)]"
                      />
                      <button
                        onClick={() => handleAddSubtask(task)}
                        className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-3 py-1.5 text-xs font-semibold text-[var(--accent-primary)]"
                      >
                        + Subtask
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: PROJECTS */}
      {viewMode === 'projects' && (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
          {state.projects.map((proj) => {
            const linkedTasks = state.tasks.filter(
              (t) => t.linkedProjectId === proj.id
            );
            const pct = calculateProjectProgress(proj, linkedTasks);

            return (
              <div
                key={proj.id}
                className="flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div
                        className="flex h-11 w-11 items-center justify-center rounded-2xl text-white"
                        style={{ backgroundColor: proj.color || '#7C5CFC' }}
                      >
                        <AscendIcon name={proj.icon} size={20} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                            {proj.name}
                          </h2>
                          <span className="rounded-full bg-[var(--bg-elevated)] px-2.5 py-0.5 text-[11px] font-semibold text-[var(--text-secondary)]">
                            {proj.status}
                          </span>
                        </div>
                        <p className="mt-0.5 text-xs text-[var(--text-secondary)]">
                          {proj.description}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setEditingProject(proj)}
                      className="text-xs font-medium text-[var(--accent-primary)]"
                    >
                      Edit
                    </button>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-4">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[var(--text-secondary)]">
                        Project Progress ({linkedTasks.length} linked tasks)
                      </span>
                      <span className="font-mono-metric font-bold text-[var(--accent-primary)]">
                        {pct}%
                      </span>
                    </div>
                    <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: `${pct}%`,
                          backgroundColor: proj.color || 'var(--accent-primary)',
                        }}
                      />
                    </div>
                  </div>

                  {/* Project Milestones */}
                  <div className="mt-4 space-y-2">
                    <div className="text-xs font-semibold text-[var(--text-secondary)]">
                      Milestones
                    </div>
                    {proj.milestones.map((ms) => (
                      <div
                        key={ms.id}
                        className="flex items-center gap-2.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 px-3 py-2 text-xs"
                      >
                        <button
                          onClick={() => toggleProjectMilestone(proj.id, ms.id)}
                          className={`flex h-4 w-4 items-center justify-center rounded border ${
                            ms.completed
                              ? 'border-emerald-500 bg-emerald-500 text-white'
                              : 'border-[var(--border-subtle)] bg-[var(--bg-surface)]'
                          }`}
                        >
                          {ms.completed && (
                            <AscendIcon name="CheckCircle2" size={11} />
                          )}
                        </button>
                        <span
                          className={
                            ms.completed
                              ? 'line-through text-[var(--text-secondary)]'
                              : 'text-[var(--text-primary)]'
                          }
                        >
                          {ms.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2 border-t border-[var(--border-subtle)] pt-3">
                  <input
                    type="text"
                    placeholder="Add project milestone..."
                    value={newProjMilestoneInputs[proj.id] || ''}
                    onChange={(e) =>
                      setNewProjMilestoneInputs({
                        ...newProjMilestoneInputs,
                        [proj.id]: e.target.value,
                      })
                    }
                    className="flex-1 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs text-[var(--text-primary)]"
                  />
                  <button
                    onClick={() => handleAddProjectMilestone(proj)}
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-3 py-1.5 text-xs font-semibold text-[var(--accent-primary)]"
                  >
                    + Add
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Task Editor Modal */}
      {editingTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
          <div className="my-8 w-full max-w-lg rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Configure Task & Relational Connections
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Task Name
                </label>
                <input
                  type="text"
                  value={editingTask.title}
                  onChange={(e) =>
                    setEditingTask({ ...editingTask, title: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Description
                </label>
                <input
                  type="text"
                  value={editingTask.description}
                  onChange={(e) =>
                    setEditingTask({
                      ...editingTask,
                      description: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Due Date
                  </label>
                  <input
                    type="date"
                    value={editingTask.dueDate}
                    onChange={(e) =>
                      setEditingTask({ ...editingTask, dueDate: e.target.value })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Priority
                  </label>
                  <select
                    value={editingTask.priority}
                    onChange={(e) =>
                      setEditingTask({
                        ...editingTask,
                        priority: e.target.value as TaskItem['priority'],
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Custom XP
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editingTask.xpReward}
                    onChange={(e) =>
                      setEditingTask({
                        ...editingTask,
                        xpReward: Math.max(0, Number(e.target.value) || 0),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs font-bold text-[var(--accent-primary)]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Linked Strategic Goal
                  </label>
                  <select
                    value={editingTask.linkedGoalId || ''}
                    onChange={(e) =>
                      setEditingTask({
                        ...editingTask,
                        linkedGoalId: e.target.value || undefined,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="">None</option>
                    {state.goals.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.title}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Linked Project
                  </label>
                  <select
                    value={editingTask.linkedProjectId || ''}
                    onChange={(e) =>
                      setEditingTask({
                        ...editingTask,
                        linkedProjectId: e.target.value || undefined,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="">None</option>
                    {state.projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteTask(editingTask.id);
                  setEditingTask(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Task
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingTask(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingTask.title.trim()) return;
                    saveTask(editingTask);
                    setEditingTask(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Task
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Project Editor Modal */}
      {editingProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Configure Project
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Project Name
                </label>
                <input
                  type="text"
                  value={editingProject.name}
                  onChange={(e) =>
                    setEditingProject({ ...editingProject, name: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Description
                </label>
                <input
                  type="text"
                  value={editingProject.description}
                  onChange={(e) =>
                    setEditingProject({
                      ...editingProject,
                      description: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Deadline
                  </label>
                  <input
                    type="date"
                    value={editingProject.deadline}
                    onChange={(e) =>
                      setEditingProject({
                        ...editingProject,
                        deadline: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Status
                  </label>
                  <select
                    value={editingProject.status}
                    onChange={(e) =>
                      setEditingProject({
                        ...editingProject,
                        status: e.target.value as ProjectItem['status'],
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="Planning">Planning</option>
                    <option value="Active">Active</option>
                    <option value="On Hold">On Hold</option>
                    <option value="Completed">Completed</option>
                    <option value="Archived">Archived</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteProject(editingProject.id);
                  setEditingProject(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Project
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingProject(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingProject.name.trim()) return;
                    saveProject(editingProject);
                    setEditingProject(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Project
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
