/**
 * masteryService.js — "Mastery": skills you grow on a schedule (communication, public speaking,
 * coding, marketing, podcasts, Islamic studies, Arabic …). You add and delete your own.
 * Skills live in settings (small list); every practice session is a row in `masteryLogs`.
 */
import { getSetting, setSetting, getAll, put, remove, newId, todayISO } from '../../core/storage/storageService.js';
import { startOfWeekISO, addDaysISO, lastNDates } from '../../core/utils/dateUtils.js';
import { emit } from '../../core/utils/eventBus.js';

const KEY = 'mastery.skills';

export const CATEGORIES = [
  { value: 'deen', label: '🕌 Deen' }, { value: 'skill', label: '💻 Skill' },
  { value: 'voice', label: '🗣️ Speaking' }, { value: 'mind', label: '🧠 Mind' }, { value: 'work', label: '💼 Work' },
];
export const KINDS = ['Podcast', 'Reading', 'Research', 'Practice', 'Course', 'Writing', 'Lesson', 'Recording'];
// Handy starting points when you tap "+ Add a skill" — nothing is added unless you pick it.
export const SUGGESTED = [
  { name: 'Islamic studies & Arabic', emoji: '🕌', category: 'deen', days: [1, 3, 5], minutes: 25, kind: 'Lesson' },
  { name: 'Coding', emoji: '💻', category: 'skill', days: [2, 4, 6], minutes: 30, kind: 'Practice' },
  { name: 'Public speaking', emoji: '🗣️', category: 'voice', days: [0], minutes: 20, kind: 'Recording' },
  { name: 'Communication', emoji: '💬', category: 'voice', days: [1, 4], minutes: 15, kind: 'Reading' },
  { name: 'Podcast', emoji: '🎧', category: 'mind', days: [0, 1, 2, 3, 4, 5, 6], minutes: 15, kind: 'Podcast' },
  { name: 'Memory training', emoji: '🧠', category: 'mind', days: [0, 1, 2, 3, 4, 5, 6], minutes: 10, kind: 'Practice' },
  { name: 'Marketing', emoji: '📣', category: 'work', days: [3, 6], minutes: 20, kind: 'Course' },
];

export async function listSkills() { return getSetting(KEY, []); }
async function save(list) { await setSetting(KEY, list); }

export async function addSkill(data) {
  const name = (data.name || '').trim(); if (!name) return null;
  const skill = { id: newId(), name, emoji: data.emoji || '🎯', category: data.category || 'skill', days: data.days?.length ? [...data.days].sort() : [0, 1, 2, 3, 4, 5, 6], minutes: Number(data.minutes) || 20, kind: data.kind || 'Practice', time: data.time || '', note: data.note || '', createdAt: todayISO() };
  await save([...(await listSkills()), skill]); return skill;
}
export async function updateSkill(id, patch) { await save((await listSkills()).map((s) => (s.id === id ? { ...s, ...patch } : s))); }
export async function deleteSkill(id) {
  await save((await listSkills()).filter((s) => s.id !== id));
  for (const l of (await getAll('masteryLogs')).filter((x) => x.skillId === id)) await remove('masteryLogs', l.id);
}

export async function logPractice(skill, minutes, note = '', date = todayISO()) {
  await put('masteryLogs', { id: newId(), skillId: skill.id, date, minutes: Number(minutes) || skill.minutes, note: note.trim() });
  emit('mastery:logged', { skillId: skill.id, minutes });
}
export async function undoToday(skill) {
  for (const l of (await getAll('masteryLogs')).filter((x) => x.skillId === skill.id && x.date === todayISO())) await remove('masteryLogs', l.id);
}

export const isScheduled = (skill, d = new Date()) => skill.days.includes(d.getDay());

/** Today's checklist: scheduled skills + their state. */
export async function todaysMastery() {
  const logs = (await getAll('masteryLogs')).filter((l) => l.date === todayISO());
  return (await listSkills()).filter((s) => isScheduled(s)).map((s) => {
    const mine = logs.filter((l) => l.skillId === s.id);
    return { skill: s, done: mine.length > 0, minutes: mine.reduce((a, l) => a + l.minutes, 0) };
  });
}

/** Weeks in a row you hit at least half your target sessions. One quiet week never breaks it (never miss twice). */
export async function skillStreak(skill) {
  const logs = (await getAll('masteryLogs')).filter((l) => l.skillId === skill.id);
  const need = Math.max(1, Math.ceil(skill.days.length / 2));
  const countIn = (ws) => logs.filter((l) => l.date >= ws && l.date <= addDaysISO(ws, 6)).length;
  let ws = startOfWeekISO(); let weeks = 0; let misses = 0;
  if (countIn(ws) < need) { ws = addDaysISO(ws, -7); } // current week still in progress
  for (let i = 0; i < 52; i += 1) {
    if (countIn(ws) >= need) { weeks += 1; misses = 0; } else { misses += 1; if (misses >= 2) break; }
    ws = addDaysISO(ws, -7);
  }
  return weeks;
}

export async function weeklyMastery() {
  const ws = startOfWeekISO();
  const logs = (await getAll('masteryLogs')).filter((l) => l.date >= ws);
  return (await listSkills()).map((s) => {
    const mine = logs.filter((l) => l.skillId === s.id);
    return { skill: s, sessions: mine.length, minutes: mine.reduce((a, l) => a + l.minutes, 0), target: s.days.length };
  });
}

export async function recentLogs(limit = 8) {
  const skills = new Map((await listSkills()).map((s) => [s.id, s]));
  return (await getAll('masteryLogs')).filter((l) => skills.has(l.skillId)).sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, limit).map((l) => ({ ...l, skill: skills.get(l.skillId) }));
}

export async function minutesSeries(days = 14) {
  const logs = await getAll('masteryLogs');
  return lastNDates(days).map((d) => ({ date: d, value: logs.filter((l) => l.date === d).reduce((a, l) => a + l.minutes, 0) }));
}
