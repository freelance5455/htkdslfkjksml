/** masteryUI.js — Mastery tab (Discipline), the "Today's Mastery" card (Home) and the add/edit/log sheets. */
import { el, card, sectionHeader, button, textInput, textareaInput, fieldLabel, chipSelect, checklistItem, barList, statGrid, emptyState } from '../../components/ui.js';
import { chartCanvas, renderBarChart } from '../../components/charts/canvasChart.js';
import { showToast } from '../../core/notifications/toast.js';
import { openSheet, closeSheet } from '../../components/modal.js';
import { icon } from '../../components/icons.js';
import {
  CATEGORIES, KINDS, SUGGESTED, addSkill, updateSkill, deleteSkill, logPractice, undoToday,
  todaysMastery, weeklyMastery, skillStreak, recentLogs, minutesSeries, listSkills,
} from './masteryService.js';

const DAY = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const daysText = (d) => (d.length === 7 ? 'Every day' : d.map((x) => DAY[x]).join(' '));

/** Home card. Returns null when nothing is scheduled today, so Home stays calm. */
export async function buildTodaysMasteryCard(onChange = () => {}) {
  const today = await todaysMastery();
  if (!today.length) return null;
  const doneCount = today.filter((t) => t.done).length;
  const rows = today.map((t) => checklistItem(`${t.skill.emoji} ${t.skill.name} · ${t.skill.minutes} min`, t.done, async (checked) => {
    if (checked) openLogSheet(t.skill, onChange); else { await undoToday(t.skill); onChange(); }
  }));
  return card([
    el('div', 'flex justify-between items-center', [el('strong', null, '🌱 Today\'s Mastery'), el('span', 'text-xs text-dim', `${doneCount}/${today.length} done`)]),
    el('div', 'mt-2', rows),
    doneCount === today.length ? el('p', 'text-xs text-dim mt-2', 'All done — that is how mastery is built. 🤲') : null,
  ]);
}

export function openLogSheet(skill, done = () => {}) {
  openSheet(`${skill.emoji} ${skill.name}`, (body) => {
    const mins = textInput({ type: 'number', value: String(skill.minutes), placeholder: 'Minutes' }); mins.inputMode = 'numeric';
    const note = textareaInput({ rows: 3, placeholder: 'What did you learn or practise? (optional)' });
    body.append(
      skill.note ? el('p', 'text-xs text-dim', `Resource: ${skill.note}`) : null,
      el('div', 'field', [fieldLabel('Minutes spent'), mins]), el('div', 'field', [fieldLabel('Note'), note]),
      el('div', 'bottom-sheet__footer', [button('Log it ✓', { block: true, onClick: async () => {
        await logPractice(skill, parseInt(mins.value, 10) || skill.minutes, note.value); closeSheet(); showToast('Logged. Well done.'); done();
      } })]),
    );
  });
}

function openSkillForm(skill, done) {
  const base = skill || { name: '', emoji: '🎯', category: 'skill', days: [1, 3, 5], minutes: 20, kind: 'Practice', time: '', note: '' };
  openSheet(skill ? 'Edit skill' : 'Add a skill', (body) => {
    let cat = base.category; let kind = base.kind; const days = new Set(base.days);
    const name = textInput({ value: base.name, placeholder: 'e.g. Public speaking' });
    const emoji = textInput({ value: base.emoji, placeholder: '🎯' }); emoji.maxLength = 4;
    const mins = textInput({ type: 'number', value: String(base.minutes), placeholder: 'Minutes per session' });
    const time = textInput({ type: 'time', value: base.time });
    const note = textInput({ value: base.note, placeholder: 'Resource (podcast name, course, book) — optional' });
    const catSlot = el('div'); const kindSlot = el('div'); const daySlot = el('div', 'chip-row');
    const draw = () => {
      catSlot.replaceChildren(chipSelect(CATEGORIES, cat, (v) => { cat = v; draw(); }));
      kindSlot.replaceChildren(chipSelect(KINDS.map((k) => ({ label: k, value: k })), kind, (v) => { kind = v; draw(); }));
      daySlot.replaceChildren(...DAY.map((d, i) => { const c = el('button', `chip${days.has(i) ? ' chip--active' : ''}`, d); c.addEventListener('click', () => { if (days.has(i)) days.delete(i); else days.add(i); draw(); }); return c; }));
    };
    draw();
    if (!skill) {
      const row = el('div', 'chip-row');
      SUGGESTED.forEach((s) => { const c = el('button', 'chip', `${s.emoji} ${s.name}`); c.addEventListener('click', () => { name.value = s.name; emoji.value = s.emoji; mins.value = s.minutes; cat = s.category; kind = s.kind; days.clear(); s.days.forEach((d) => days.add(d)); draw(); }); row.append(c); });
      body.append(el('p', 'text-xs text-dim', 'Quick start — tap one, then change anything:'), row);
    }
    body.append(
      el('div', 'field', [fieldLabel('Skill'), name]), el('div', 'field', [fieldLabel('Emoji'), emoji]),
      el('div', 'field', [fieldLabel('Type'), catSlot]), el('div', 'field', [fieldLabel('Activity'), kindSlot]),
      el('div', 'field', [fieldLabel('Which days?'), daySlot]), el('div', 'field', [fieldLabel('Minutes per session'), mins]),
      el('div', 'field', [fieldLabel('Reminder time (optional)'), time]), el('div', 'field', [fieldLabel('Resource'), note]),
      el('div', 'bottom-sheet__footer', [button(skill ? 'Save changes' : 'Add skill', { block: true, onClick: async () => {
        if (!name.value.trim()) { showToast('Give the skill a name.'); return; }
        if (!days.size) { showToast('Pick at least one day.'); return; }
        const data = { name: name.value.trim(), emoji: emoji.value.trim() || '🎯', category: cat, kind, days: [...days].sort(), minutes: parseInt(mins.value, 10) || 20, time: time.value, note: note.value.trim() };
        if (skill) await updateSkill(skill.id, data); else await addSkill(data);
        closeSheet(); showToast(skill ? 'Updated.' : 'Skill added.'); done();
      } })]),
    );
    if (skill) body.append(el('div', 'mt-3', button('Delete this skill', { variant: 'ghost', block: true, onClick: async () => {
      if (!window.confirm(`Delete "${skill.name}" and its history?`)) return;
      await deleteSkill(skill.id); closeSheet(); showToast('Deleted.'); done();
    } })));
  });
}

export async function renderMasteryTab(page, rerender) {
  const skills = await listSkills();
  page.append(el('p', 'text-dim text-xs', 'Skills you grow on a schedule — each day only what is planned for today shows on Home.'));

  const today = await buildTodaysMasteryCard(rerender);
  if (today) page.append(sectionHeader(null, 'Today'), today);

  page.append(sectionHeader(`${skills.length} skills`, 'My skills'));
  if (!skills.length) page.append(emptyState('No skills yet', 'Add podcasts, public speaking, coding, Arabic… your choice.'));
  const weekly = await weeklyMastery();
  for (const w of weekly) {
    const s = w.skill; const streak = await skillStreak(s);
    page.append(card([
      el('div', 'flex justify-between items-center', [el('strong', null, `${s.emoji} ${s.name}`), streak > 0 ? el('span', 'streak-pill', [icon('flame'), `${streak}w`]) : null]),
      el('p', 'text-xs text-dim mt-1', `${daysText(s.days)} · ${s.minutes} min · ${s.kind}${s.time ? ` · ⏰ ${s.time}` : ''}`),
      el('p', 'text-xs mt-1', `This week: ${w.sessions}/${w.target} sessions · ${w.minutes} min`),
      el('div', 'mt-2 flex gap-3', [button('Log now', { size: 'sm', onClick: () => openLogSheet(s, rerender) }), button('Edit', { size: 'sm', variant: 'ghost', onClick: () => openSkillForm(s, rerender) })]),
    ]));
  }
  page.append(el('div', 'mt-3', button('+ Add a skill', { variant: 'ghost', block: true, onClick: () => openSkillForm(null, rerender) })));

  if (skills.length) {
    page.append(sectionHeader(null, 'Time this week'));
    page.append(card([barList(weekly.map((w) => ({ label: `${w.skill.emoji} ${w.skill.name}`, value: w.minutes, text: `${w.minutes} min` })))]));
    const series = await minutesSeries(14);
    const cc = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Minutes per day (14 days)')])]);
    const cv = chartCanvas(90); cc.append(cv); page.append(cc);
    requestAnimationFrame(() => renderBarChart(cv, series, { color: '#60A5FA' }));
    const logs = await recentLogs(6);
    if (logs.length) { page.append(sectionHeader(null, 'Recent')); page.append(card(logs.map((l) => el('div', 'checklist-item', [el('span', 'checklist-item__label', `${l.skill.emoji} ${l.skill.name}${l.note ? ` — ${l.note.slice(0, 50)}` : ''}`), el('span', 'text-xs text-dim', `${l.date} · ${l.minutes}m`)])))); }
  }
}
