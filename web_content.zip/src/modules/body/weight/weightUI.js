/** weightUI.js — the Weight tab inside Body: goal progress, weekly weigh-in, trend chart, measurements, plan. */
import { el, card, sectionHeader, button, textInput, fieldLabel, chipSelect, statGrid, emptyState } from '../../../components/ui.js';
import { chartCanvas, renderLineChart } from '../../../components/charts/canvasChart.js';
import { showToast } from '../../../core/notifications/toast.js';
import { openSheet, closeSheet } from '../../../components/modal.js';
import { formatFriendlyDate } from '../../../core/utils/dateUtils.js';
import { weightProgress, logWeight, saveWeightPlan, paceMessage, WEEKDAYS } from './weightService.js';

const kgText = (n) => `${Math.round(n * 10) / 10} kg`;

export async function renderWeightTab(page, rerender) {
  const p = await weightProgress();

  page.append(sectionHeader(`${p.plan.startKg} → ${p.plan.goalKg} kg`, 'Weight goal'));
  const bar = el('div', 'weight-bar', [el('div', 'weight-bar__fill')]);
  bar.firstChild.style.width = `${p.pct}%`;
  page.append(card([
    el('div', 'flex justify-between', [el('span', 'weight-now', kgText(p.current)), el('span', 'text-dim text-xs', p.toGo > 0 ? `${kgText(p.toGo)} to go` : 'Goal reached 🎉')]),
    bar,
    el('p', 'text-xs text-dim mt-2', `${p.pct}% of the way · ${p.lost >= 0 ? `${kgText(p.lost)} down` : `${kgText(-p.lost)} up`} since the start`),
  ]));

  if (p.weighInDue) {
    const due = card([el('p', null, `⚖️ Weigh-in day (${WEEKDAYS[p.plan.weighDay]}). Same time, same conditions — ideally in the morning, after the toilet and before eating.`)]);
    due.classList.add('card--accent'); page.append(due);
  }

  page.append(sectionHeader(null, 'Log a weigh-in'));
  const kg = textInput({ placeholder: 'Weight (kg)', type: 'number' }); kg.step = '0.1'; kg.inputMode = 'decimal';
  const waist = textInput({ placeholder: 'Waist (cm) — optional', type: 'number' }); waist.inputMode = 'decimal';
  page.append(card([
    kg, el('div', 'mt-3', waist),
    el('div', 'mt-3', button('Save weigh-in', { block: true, onClick: async () => {
      const v = parseFloat(kg.value);
      if (!(v >= 25 && v <= 300)) { showToast('Enter a weight in kg, like 78.5'); return; }
      await logWeight({ kg: v, waistCm: waist.value ? parseFloat(waist.value) : null });
      showToast('Weigh-in saved.'); await rerender();
    } })),
  ]));

  page.append(sectionHeader(null, 'Your trend'));
  page.append(statGrid([
    { value: kgText(p.trend), label: 'Trend (avg of last 7)' },
    { value: p.perWeek == null ? '—' : `${p.perWeek > 0 ? '+' : ''}${p.perWeek}`, label: 'kg / week (last 4 wks)' },
    { value: p.etaDate ? formatFriendlyDate(p.etaDate) : '—', label: 'Estimated goal date' },
    { value: p.bmi ?? '—', label: 'BMI', hint: p.plan.heightCm ? '' : 'add height in plan' },
  ]));
  page.append(card([el('p', 'text-xs', paceMessage(p))]));

  const points = p.entries.slice(-30).map((e) => ({ date: e.date, value: e.weightKg }));
  const chartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Weight over time')])]);
  if (points.length >= 2) {
    const canvas = chartCanvas(120); chartCard.append(canvas);
    requestAnimationFrame(() => renderLineChart(canvas, points, {}));
  } else chartCard.append(emptyState('Not enough weigh-ins yet', 'Two or more weigh-ins draw your line.'));
  page.append(chartCard);

  const waists = p.entries.filter((e) => e.waistCm).slice(-3).reverse();
  if (waists.length) page.append(card(waists.map((e) => el('div', 'checklist-item', [el('span', 'checklist-item__label', `${e.date} — waist ${e.waistCm} cm`)]))));

  const history = p.entries.slice(-6).reverse();
  if (history.length) {
    page.append(sectionHeader(null, 'Recent weigh-ins'));
    page.append(card(history.map((e) => el('div', 'checklist-item', [el('span', 'checklist-item__label', e.date), el('span', 'text-dim', kgText(e.weightKg))]))));
  }

  page.append(el('div', 'mt-3', button('⚙️ Edit goal & weigh-in day', { variant: 'ghost', block: true, onClick: () => openPlan(p.plan, rerender) })));
  page.append(el('p', 'text-xs text-dim mt-3', 'A healthy pace is roughly 0.25–1 kg a week. Your trend matters, not one day.'));
}

function openPlan(plan, rerender) {
  openSheet('Weight plan', (body) => {
    let day = plan.weighDay;
    const start = textInput({ value: String(plan.startKg), type: 'number', placeholder: 'Starting weight (kg)' });
    const goal = textInput({ value: String(plan.goalKg), type: 'number', placeholder: 'Goal weight (kg)' });
    const height = textInput({ value: plan.heightCm ? String(plan.heightCm) : '', type: 'number', placeholder: 'Height (cm) — optional, for BMI' });
    const date = textInput({ value: plan.targetDate || '', type: 'date' });
    const slot = el('div');
    const draw = () => slot.replaceChildren(chipSelect(WEEKDAYS.map((d, i) => ({ label: d.slice(0, 3), value: i })), day, (v) => { day = v; draw(); }));
    draw();
    body.append(
      el('div', 'field', [fieldLabel('Starting weight (kg)'), start]), el('div', 'field', [fieldLabel('Goal weight (kg)'), goal]),
      el('div', 'field', [fieldLabel('Height (cm)'), height]), el('div', 'field', [fieldLabel('Target date (optional)'), date]),
      el('div', 'field', [fieldLabel('Weekly weigh-in day'), slot]),
      el('div', 'bottom-sheet__footer', [button('Save', { block: true, onClick: async () => {
        const s = parseFloat(start.value), g = parseFloat(goal.value);
        if (!(s > 0 && g > 0)) { showToast('Enter start and goal weight.'); return; }
        await saveWeightPlan({ startKg: s, goalKg: g, weighDay: day, targetDate: date.value, heightCm: height.value ? parseFloat(height.value) : null });
        closeSheet(); showToast('Plan saved.'); await rerender();
      } })]),
    );
  });
}
