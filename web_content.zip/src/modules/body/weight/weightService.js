/**
 * weightService.js — weight + measurements toward a goal.
 * Weigh-ins live in the existing `bodyMetrics` store (one row per day, so older body-fat
 * entries are untouched); the plan (start, goal, date, weigh-in day) lives in settings.
 */
import { getAll, put, newId, getSetting, setSetting } from '../../../core/storage/storageService.js';
import { todayISO, addDaysISO, daysBetween, parseISO, toISO } from '../../../core/utils/dateUtils.js';
import { emit } from '../../../core/utils/eventBus.js';

const PLAN_KEY = 'weight.plan';
export const DEFAULT_PLAN = { startKg: 80, goalKg: 60, targetDate: '', weighDay: 6, heightCm: null }; // weighDay: 0 = Sun … 6 = Sat

export async function getWeightPlan() { return { ...DEFAULT_PLAN, ...(await getSetting(PLAN_KEY, null) || {}) }; }
export async function saveWeightPlan(patch) { const p = { ...(await getWeightPlan()), ...patch }; await setSetting(PLAN_KEY, p); return p; }

export async function logWeight({ kg, waistCm = null, chestCm = null, hipsCm = null, date = todayISO() }) {
  const rows = (await getAll('bodyMetrics')).filter((m) => m.date === date);
  const ex = rows[0];
  await put('bodyMetrics', {
    ...(ex || {}), id: ex?.id || newId(), date,
    weightKg: kg ?? ex?.weightKg ?? null,
    waistCm: waistCm ?? ex?.waistCm ?? null, chestCm: chestCm ?? ex?.chestCm ?? null, hipsCm: hipsCm ?? ex?.hipsCm ?? null,
  });
  emit('weight:logged', { kg, date });
}

export async function weighIns() {
  return (await getAll('bodyMetrics')).filter((m) => m.weightKg != null).sort((a, b) => (a.date < b.date ? -1 : 1));
}

/** Smoothed trend (average of the last up-to-7 weigh-ins) so one salty meal doesn't discourage you. */
export function trendOf(entries) {
  if (!entries.length) return null;
  const last = entries.slice(-7);
  return Math.round((last.reduce((a, e) => a + e.weightKg, 0) / last.length) * 10) / 10;
}

export async function weightProgress() {
  const plan = await getWeightPlan();
  const entries = await weighIns();
  const latest = entries[entries.length - 1] || null;
  const current = latest ? latest.weightKg : plan.startKg;
  const trend = trendOf(entries) ?? current;
  const total = Math.max(0.1, plan.startKg - plan.goalKg);
  const lost = Math.round((plan.startKg - current) * 10) / 10;
  const toGo = Math.round((current - plan.goalKg) * 10) / 10;
  const pct = Math.max(0, Math.min(100, Math.round(((plan.startKg - current) / total) * 100)));

  // average pace over the last 28 days (kg per week); negative = losing
  let perWeek = null, etaDate = null;
  const recent = entries.filter((e) => daysBetween(e.date, todayISO()) <= 28);
  if (recent.length >= 2) {
    const a = recent[0], b = recent[recent.length - 1];
    const days = Math.max(1, daysBetween(a.date, b.date));
    perWeek = Math.round(((b.weightKg - a.weightKg) / days) * 7 * 100) / 100;
    if (perWeek < -0.05 && toGo > 0) etaDate = addDaysISO(todayISO(), Math.round((toGo / -perWeek) * 7));
  }
  const bmi = plan.heightCm ? Math.round((current / ((plan.heightCm / 100) ** 2)) * 10) / 10 : null;

  const lastDate = latest?.date || null;
  const dow = new Date().getDay();
  const daysSince = lastDate ? daysBetween(lastDate, todayISO()) : 999;
  const weighInDue = daysSince >= 7 || (dow === plan.weighDay && lastDate !== todayISO());
  return { plan, entries, current, trend, lost, toGo, pct, perWeek, etaDate, bmi, lastDate, weighInDue, count: entries.length };
}

export const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

/** Honest, gentle one-liner about the pace. 0.25–1 kg/week is a healthy range. */
export function paceMessage(p) {
  if (p.count < 2) return 'Log your weight each week and your trend will appear here.';
  if (p.toGo <= 0) return 'You have reached your goal weight. Now keep it steady. 🤲';
  if (p.perWeek === null) return 'Keep weighing in weekly to see your pace.';
  if (p.perWeek > 0.05) return 'Weight is creeping up. Look at the weekly pattern, not one day — and keep your walk and water habits.';
  if (p.perWeek < -1) return 'You are losing faster than 1 kg a week. Eat enough and sleep well — slow and steady lasts.';
  if (p.perWeek > -0.15) return 'Almost flat this month. Small, steady changes in food and walking will move it.';
  return `Healthy pace: about ${Math.abs(p.perWeek)} kg a week${p.etaDate ? `. At this rate you reach your goal around ${p.etaDate}.` : '.'}`;
}
