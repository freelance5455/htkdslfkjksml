/**
 * skinTrackerService.js — skin tracker that sits UNDER your AM/PM routine:
 *  - actives with a "one new active at a time" guard
 *  - retinoid-night counter + daily irritation
 *  - dark-mark timeline with optional private photos (kept only on this device)
 */
import { getAll, put, newId, remove, todayISO, getByIndex } from '../../../core/storage/storageService.js';
import { daysBetween, lastNDates } from '../../../core/utils/dateUtils.js';

const SETTLE_DAYS = 14;

export async function listActives() {
  return (await getAll('skinTracker')).filter((r) => r.type === 'active').sort((a, b) => (a.startDate < b.startDate ? 1 : -1));
}

/** The active still "settling in" (<14 days old, not stopped), if any. */
export async function settlingActive() {
  const t = todayISO();
  return (await listActives()).find((a) => !a.endDate && daysBetween(a.startDate, t) < SETTLE_DAYS) || null;
}

export async function startActive(name) {
  return put('skinTracker', { id: newId(), type: 'active', name, startDate: todayISO(), endDate: null, date: todayISO() });
}

export async function stopActive(active) {
  return put('skinTracker', { ...active, endDate: todayISO() });
}

export async function getTodayLog() {
  const found = (await getByIndex('skinTracker', 'date', todayISO())).find((r) => r.type === 'log');
  return found || { id: null, type: 'log', date: todayISO(), retinoid: false, irritation: 0 };
}

export async function saveTodayLog(patch) {
  const cur = await getTodayLog();
  return put('skinTracker', { ...cur, ...patch, id: cur.id || newId() });
}

export async function skinSummary() {
  const logs = (await getAll('skinTracker')).filter((r) => r.type === 'log');
  const last7 = lastNDates(7);
  const last4 = lastNDates(4);
  return {
    retinoidWeek: logs.filter((l) => l.retinoid && last7.includes(l.date)).length,
    retinoidTotal: logs.filter((l) => l.retinoid).length,
    recentIrritation: logs.some((l) => (l.irritation || 0) >= 2 && last4.includes(l.date)),
  };
}

export async function listMarks() {
  return (await getAll('skinTracker')).filter((r) => r.type === 'mark').sort((a, b) => (a.startDate < b.startDate ? -1 : 1));
}

export async function addMark(name) {
  return put('skinTracker', { id: newId(), type: 'mark', name, startDate: todayISO(), date: todayISO(), checks: [] });
}

export async function addMarkCheck(mark, severity, photoDataURL = null) {
  let photoId = null;
  if (photoDataURL) {
    photoId = newId();
    await put('photos', { id: photoId, kind: 'skin', date: todayISO(), data: photoDataURL });
  }
  const checks = [...(mark.checks || []), { date: todayISO(), severity, photoId }];
  return put('skinTracker', { ...mark, checks });
}

export async function deleteMark(mark) {
  for (const c of mark.checks || []) if (c.photoId) await remove('photos', c.photoId);
  await remove('skinTracker', mark.id);
}

export async function getPhoto(id) {
  const all = await getAll('photos');
  return all.find((p) => p.id === id)?.data || null;
}
