import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon } from '../components/AscendIcon';

export const XPSettingsAndLedgerModule: React.FC = () => {
  const {
    state,
    levelStatus,
    updateXPSettings,
    saveHabit,
    saveTask,
    saveGoal,
    recordManualXP,
    reverseXPTransaction,
  } = useAscend();

  const xp = state.xpSettings;
  const [activeTab, setActiveTab] = useState<
    'engine' | 'overrides' | 'ledger'
  >('engine');

  // Custom XP Activity Trigger
  const [customReason, setCustomReason] = useState('');
  const [customXpAmount, setCustomXpAmount] = useState(50);
  const [customAttrIds, setCustomAttrIds] = useState<string[]>(['attr-dis']);

  const handleTriggerCustomXp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customReason.trim()) return;
    recordManualXP(Number(customXpAmount) || 0, customReason.trim(), customAttrIds);
    setCustomReason('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            Central XP & Progression Engine
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            Zero hard-coded rules. Customize every XP value, level formula, streak bonus, and inspect or reverse any transaction.
          </p>
        </div>

        <div className="inline-flex rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1">
          {[
            { id: 'engine', label: 'Rules & Level Formula', icon: 'Sliders' },
            { id: 'overrides', label: 'Per-Item XP Matrix', icon: 'ListChecks' },
            { id: 'ledger', label: `XP Ledger (${state.xpTransactions.length})`, icon: 'History' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as typeof activeTab)}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                activeTab === t.id
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)]'
              }`}
            >
              <AscendIcon name={t.icon} size={14} />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Live Level Preview Strip */}
      <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono-metric text-xl font-extrabold text-[var(--text-primary)]">
                LEVEL {levelStatus.level}
              </span>
              <span className="rounded-full bg-[var(--accent-soft)] px-2.5 py-0.5 text-xs font-semibold text-[var(--accent-primary)]">
                {xp.levelFormula === 'linear'
                  ? `Linear Formula (${xp.xpPerLevelBase} XP / Level)`
                  : `Progressive Curve (Base ${xp.xpPerLevelBase} XP × 1.12^Lv)`}
              </span>
            </div>
            <p className="mt-1 text-xs text-[var(--text-secondary)]">
              Current Progress: {levelStatus.xpIntoLevel.toLocaleString()} /{' '}
              {levelStatus.xpNeededForLevel.toLocaleString()} XP (
              {levelStatus.progressPercent}%) · Total Verified Ledger XP:{' '}
              <strong>{levelStatus.totalXp.toLocaleString()} XP</strong>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs font-semibold text-[var(--text-primary)] cursor-pointer">
              <input
                type="checkbox"
                checked={xp.xpEnabled}
                onChange={(e) => updateXPSettings({ xpEnabled: e.target.checked })}
              />
              XP System Enabled
            </label>
            <label className="flex items-center gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs font-semibold text-[var(--text-primary)] cursor-pointer">
              <input
                type="checkbox"
                checked={xp.autoXpEnabled}
                onChange={(e) =>
                  updateXPSettings({ autoXpEnabled: e.target.checked })
                }
              />
              Auto-XP on Completion
            </label>
          </div>
        </div>
      </div>

      {/* TAB 1: PROGRESSION ENGINE RULES & CUSTOM XP TRIGGER */}
      {activeTab === 'engine' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Level System & Default XP Rules */}
          <div className="lg:col-span-8 space-y-6">
            <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
              <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                Custom Level Progression System
              </h2>
              <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Starting Level
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={xp.startingLevel}
                    onChange={(e) =>
                      updateXPSettings({
                        startingLevel: Math.max(1, Number(e.target.value) || 1),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Starting Baseline XP
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={xp.startingXp}
                    onChange={(e) =>
                      updateXPSettings({
                        startingXp: Math.max(0, Number(e.target.value) || 0),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    XP Needed per Level
                  </label>
                  <input
                    type="number"
                    min={50}
                    value={xp.xpPerLevelBase}
                    onChange={(e) =>
                      updateXPSettings({
                        xpPerLevelBase: Math.max(50, Number(e.target.value) || 500),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs font-bold text-[var(--accent-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Maximum Level Cap
                  </label>
                  <input
                    type="number"
                    min={10}
                    value={xp.maxLevel}
                    onChange={(e) =>
                      updateXPSettings({
                        maxLevel: Math.max(10, Number(e.target.value) || 100),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
              </div>

              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Progression Formula
                  </label>
                  <select
                    value={xp.levelFormula}
                    onChange={(e) =>
                      updateXPSettings({
                        levelFormula: e.target.value as 'linear' | 'progressive',
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value="linear">
                      Linear (Constant XP per Level)
                    </option>
                    <option value="progressive">
                      Progressive RPG Curve (+12% per Level)
                    </option>
                  </select>
                </div>

                <div className="flex items-end">
                  <label className="flex items-center gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3.5 py-2 text-xs text-[var(--text-primary)] w-full cursor-pointer">
                    <input
                      type="checkbox"
                      checked={xp.streakBonusEnabled}
                      onChange={(e) =>
                        updateXPSettings({
                          streakBonusEnabled: e.target.checked,
                        })
                      }
                    />
                    Enable Streak Bonus (+{xp.streakBonusXpPerDay} XP/day)
                  </label>
                </div>
              </div>
            </div>

            {/* Default XP Values for New Records */}
            <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
              <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                Default XP Rewards for New Activities (Set Any Value Including 0)
              </h2>
              <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
                {[
                  { key: 'defaultHabitXp', label: 'Default Habit XP' },
                  { key: 'defaultTaskXp', label: 'Default Task XP' },
                  { key: 'defaultGoalXp', label: 'Default Goal XP' },
                  { key: 'defaultMilestoneXp', label: 'Goal Milestone XP' },
                  { key: 'defaultMissionXp', label: 'Default Mission XP' },
                  { key: 'defaultFocusXp', label: 'Focus Session XP' },
                  { key: 'defaultSkillXp', label: 'Skill Level-Up XP' },
                  { key: 'defaultLearningHourXp', label: 'Study Hour XP' },
                ].map((item) => (
                  <div key={item.key}>
                    <label className="block text-xs text-[var(--text-secondary)]">
                      {item.label}
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={xp[item.key as keyof typeof xp] as number}
                      onChange={(e) =>
                        updateXPSettings({
                          [item.key]: Math.max(0, Number(e.target.value) || 0),
                        })
                      }
                      className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs font-semibold text-[var(--text-primary)]"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Custom XP Activity Trigger */}
          <form
            onSubmit={handleTriggerCustomXp}
            className="lg:col-span-4 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5 space-y-4 h-fit"
          >
            <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Log Custom XP Activity
            </h2>
            <p className="text-xs text-[var(--text-secondary)]">
              Award custom or bonus XP for any off-schedule milestone, lecture, or personal breakthrough.
            </p>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Activity Description / Reason
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Completed 3-hour Mock Exam"
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                XP Amount
              </label>
              <input
                type="number"
                value={customXpAmount}
                onChange={(e) => setCustomXpAmount(Number(e.target.value) || 0)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs font-bold text-[var(--accent-primary)]"
              />
            </div>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Target Attributes
              </label>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {state.attributes.map((attr) => {
                  const sel = customAttrIds.includes(attr.id);
                  return (
                    <button
                      type="button"
                      key={attr.id}
                      onClick={() =>
                        setCustomAttrIds(
                          sel
                            ? customAttrIds.filter((i) => i !== attr.id)
                            : [...customAttrIds, attr.id]
                        )
                      }
                      className={`rounded-lg border px-2 py-1 text-[10px] font-bold ${
                        sel
                          ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                          : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                      }`}
                    >
                      {attr.code}
                    </button>
                  );
                })}
              </div>
            </div>
            <button
              type="submit"
              className="w-full rounded-xl bg-[var(--accent-primary)] py-2.5 text-xs font-bold text-white"
            >
              Record Custom XP Transaction
            </button>
          </form>
        </div>
      )}

      {/* TAB 2: PER-ITEM XP OVERRIDE MATRIX */}
      {activeTab === 'overrides' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Habits Individual XP */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
              Individual Habit XP Rewards
            </h3>
            <p className="mt-0.5 text-xs text-[var(--text-secondary)]">
              Every habit has its own independent XP reward (including 0).
            </p>
            <div className="mt-4 space-y-2.5">
              {state.habits.map((h) => (
                <div
                  key={h.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 px-3 py-2"
                >
                  <span className="truncate text-xs font-medium text-[var(--text-primary)]">
                    {h.name}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      min={0}
                      value={h.xpReward}
                      onChange={(e) =>
                        saveHabit({
                          ...h,
                          xpReward: Math.max(0, Number(e.target.value) || 0),
                        })
                      }
                      className="font-mono-metric w-16 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-2 py-1 text-right text-xs font-bold text-[var(--accent-primary)]"
                    />
                    <span className="text-[10px] text-[var(--text-secondary)]">
                      XP
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tasks Individual XP */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
              Individual Task XP Rewards
            </h3>
            <p className="mt-0.5 text-xs text-[var(--text-secondary)]">
              Customize exact XP for every task in your queue.
            </p>
            <div className="mt-4 space-y-2.5">
              {state.tasks.map((t) => (
                <div
                  key={t.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 px-3 py-2"
                >
                  <span className="truncate text-xs font-medium text-[var(--text-primary)]">
                    {t.title}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      min={0}
                      value={t.xpReward}
                      onChange={(e) =>
                        saveTask({
                          ...t,
                          xpReward: Math.max(0, Number(e.target.value) || 0),
                        })
                      }
                      className="font-mono-metric w-16 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-2 py-1 text-right text-xs font-bold text-[var(--accent-primary)]"
                    />
                    <span className="text-[10px] text-[var(--text-secondary)]">
                      XP
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Goals Individual XP */}
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
              Individual Goal XP Rewards
            </h3>
            <p className="mt-0.5 text-xs text-[var(--text-secondary)]">
              Customize completion XP for each strategic goal.
            </p>
            <div className="mt-4 space-y-2.5">
              {state.goals.map((g) => (
                <div
                  key={g.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 px-3 py-2"
                >
                  <span className="truncate text-xs font-medium text-[var(--text-primary)]">
                    {g.title}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      min={0}
                      value={g.xpReward}
                      onChange={(e) =>
                        saveGoal({
                          ...g,
                          xpReward: Math.max(0, Number(e.target.value) || 0),
                        })
                      }
                      className="font-mono-metric w-16 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-2 py-1 text-right text-xs font-bold text-[var(--accent-primary)]"
                    />
                    <span className="text-[10px] text-[var(--text-secondary)]">
                      XP
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: XP TRANSACTION LEDGER */}
      {activeTab === 'ledger' && (
        <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
          <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-3">
            <div>
              <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                Immutable & Reversible XP Transaction History
              </h2>
              <p className="text-xs text-[var(--text-secondary)]">
                Every XP change is logged with Transaction ID, Activity Type, Timestamp, and Linked Attributes.
              </p>
            </div>
            <span className="font-mono-metric text-xs font-bold text-[var(--accent-primary)]">
              {state.xpTransactions.length} Transactions
            </span>
          </div>

          <div className="mt-4 space-y-2.5">
            {state.xpTransactions.map((tx) => (
              <div
                key={tx.id}
                className="flex flex-col gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3.5 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="flex items-start gap-3">
                  <span
                    className={`font-mono-metric rounded-lg px-2.5 py-1 text-xs font-extrabold ${
                      tx.xpAmount >= 0
                        ? 'bg-emerald-500/15 text-emerald-500'
                        : 'bg-rose-500/15 text-rose-500'
                    }`}
                  >
                    {tx.xpAmount >= 0 ? `+${tx.xpAmount}` : tx.xpAmount} XP
                  </span>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-bold text-[var(--text-primary)]">
                        {tx.reason}
                      </span>
                      <span className="rounded bg-[var(--bg-surface)] px-2 py-0.5 text-[10px] font-semibold uppercase text-[var(--text-secondary)]">
                        {tx.activityType}
                      </span>
                    </div>
                    <div className="mt-0.5 font-mono-metric text-[10px] text-[var(--text-muted)]">
                      ID: {tx.id} · {tx.date} {tx.timestamp} · Record: {tx.relatedRecordTitle}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => reverseXPTransaction(tx.id)}
                  className="self-end rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-3 py-1.5 text-xs font-medium text-rose-500 hover:border-rose-500 sm:self-center"
                >
                  Undo / Reverse
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
