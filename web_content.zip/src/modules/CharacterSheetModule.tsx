import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon, PICKABLE_ICONS } from '../components/AscendIcon';
import { RadarChartSVG } from '../components/RadarChartSVG';
import {
  calculateAttributeMetrics,
  calculateHabitStreak,
  getActiveTitle,
} from '../utils/progressionEngine';
import {
  AchievementItem,
  CharacterAttribute,
  CharacterTitle,
  LifeDomain,
} from '../types/ascend';

const ARCHETYPES = [
  'The Strategist',
  'The Scholar',
  'The Creator',
  'The Explorer',
  'The Disciplined One',
  'The Balanced Individual',
  'Custom Archetype',
];

export const CharacterSheetModule: React.FC = () => {
  const {
    state,
    levelStatus,
    updateCharacter,
    saveAttribute,
    deleteAttribute,
    saveDomain,
    deleteDomain,
    saveTitle,
    saveAchievement,
    unlockAchievement,
  } = useAscend();

  const [activeTab, setActiveTab] = useState<
    'attributes' | 'domains' | 'titles' | 'achievements'
  >('attributes');
  const [editingProfile, setEditingProfile] = useState(false);

  // Attribute Modal State
  const [editingAttr, setEditingAttr] = useState<CharacterAttribute | null>(null);
  // Domain Modal State
  const [editingDomain, setEditingDomain] = useState<LifeDomain | null>(null);
  // Title Modal State
  const [newTitleName, setNewTitleName] = useState('');
  const [newTitleDesc, setNewTitleDesc] = useState('');
  const [newTitleLevel, setNewTitleLevel] = useState(5);
  // Achievement Modal State
  const [newAchName, setNewAchName] = useState('');
  const [newAchDesc, setNewAchDesc] = useState('');
  const [newAchCond, setNewAchCond] = useState('');
  const [newAchXp, setNewAchXp] = useState(100);
  const [newAchIcon, setNewAchIcon] = useState('Award');

  // Real statistics computed from application records
  const completedGoalsCount = state.goals.filter((g) => g.status === 'Completed').length;
  const completedTasksCount = state.tasks.filter((t) => t.status === 'Completed').length;
  const totalHabitCompletions = state.habits.reduce(
    (sum, h) =>
      sum +
      Object.values(h.history).filter((val) => val >= h.targetValue).length,
    0
  );
  const bestStreak = Math.max(
    0,
    ...state.habits.map((h) => calculateHabitStreak(h))
  );
  const totalFocusHours = (
    state.focusSessions.reduce((sum, s) => sum + s.durationMinutes, 0) / 60
  ).toFixed(1);
  const totalStudyHours = state.subjects
    .reduce((sum, s) => sum + s.loggedHours, 0)
    .toFixed(1);
  const developedSkillsCount = state.skills.filter((s) => s.currentLevel >= 2).length;
  const unlockedAchievementsCount = state.achievements.filter((a) => a.unlocked).length;

  const activeTitle = getActiveTitle(state, levelStatus.level);

  const handleCreateNewAttribute = () => {
    setEditingAttr({
      id: `attr-custom-${Date.now()}`,
      code: 'CUS',
      name: 'New Attribute',
      description: 'Custom personal development dimension.',
      icon: 'Sparkles',
      color: '#7C5CFC',
      baseScore: 10,
      xpEarned: 0,
      xpPerPoint: 100,
      visible: true,
      isCustom: true,
      order: state.attributes.length + 1,
    });
  };

  const handleCreateNewDomain = () => {
    setEditingDomain({
      id: `dom-custom-${Date.now()}`,
      name: 'New Life Domain',
      description: 'Custom life pillar and focus area.',
      icon: 'Compass',
      color: '#10B981',
      targetHoursPerWeek: 5,
      loggedHours: 0,
      order: state.domains.length + 1,
      isCustom: true,
    });
  };

  const handleAddTitle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleName.trim()) return;
    const t: CharacterTitle = {
      id: `title-${Date.now()}`,
      name: newTitleName.trim(),
      description: newTitleDesc.trim() || 'Custom rank milestone.',
      requiredLevel: Number(newTitleLevel) || 1,
      unlocked: levelStatus.level >= (Number(newTitleLevel) || 1),
      isCustom: true,
    };
    saveTitle(t);
    setNewTitleName('');
    setNewTitleDesc('');
  };

  const handleAddAchievement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAchName.trim()) return;
    const ach: AchievementItem = {
      id: `ach-${Date.now()}`,
      name: newAchName.trim(),
      description: newAchDesc.trim() || 'Personal milestone badge.',
      category: 'Custom',
      icon: newAchIcon,
      unlockConditionText: newAchCond.trim() || 'Manual milestone verification',
      unlocked: false,
      xpReward: Number(newAchXp) || 0,
      isCustom: true,
    };
    saveAchievement(ach);
    setNewAchName('');
    setNewAchDesc('');
    setNewAchCond('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Character Identity Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent-primary)] ring-2 ring-[var(--accent-primary)]/30">
              <AscendIcon name={state.character.avatarIcon} size={38} />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="font-character-custom text-2xl font-bold text-[var(--text-primary)]">
                  {state.character.name}
                </h1>
                <span className="rounded-full bg-[var(--accent-primary)] px-3 py-0.5 text-xs font-semibold text-white">
                  {activeTitle}
                </span>
                <span className="rounded-full border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-0.5 text-xs font-medium text-[var(--text-secondary)]">
                  {state.character.archetype}
                </span>
              </div>
              <p className="mt-1 text-sm text-[var(--text-secondary)]">
                {state.character.tagline}
              </p>
              <p className="mt-0.5 text-xs text-[var(--text-muted)]">
                {state.character.customArchetypeDescription}
              </p>

              {/* Level Progress Bar */}
              <div className="mt-3 max-w-lg">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono-metric font-bold text-[var(--text-primary)]">
                    LEVEL {levelStatus.level}
                  </span>
                  <span className="font-mono-metric text-[var(--text-secondary)]">
                    {levelStatus.xpIntoLevel.toLocaleString()} /{' '}
                    {levelStatus.xpNeededForLevel.toLocaleString()} XP to Lv.
                    {levelStatus.level + 1} · Total {levelStatus.totalXp.toLocaleString()} XP
                  </span>
                </div>
                <div className="mt-1.5 h-2.5 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                  <div
                    className="h-full rounded-full bg-[var(--accent-primary)] transition-all duration-300"
                    style={{ width: `${levelStatus.progressPercent}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setEditingProfile(!editingProfile)}
              className="inline-flex items-center gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-4 py-2 text-xs font-semibold text-[var(--text-primary)] transition hover:border-[var(--accent-primary)]"
            >
              <AscendIcon name="Edit3" size={14} />
              {editingProfile ? 'Close Profile Editor' : 'Customize Identity'}
            </button>
          </div>
        </div>

        {/* Profile Customization Drawer */}
        {editingProfile && (
          <div className="mt-6 border-t border-[var(--border-subtle)] pt-5">
            <h3 className="font-subheading text-sm font-semibold text-[var(--text-primary)]">
              Customize Character Identity & Archetype
            </h3>
            <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              <div>
                <label className="block text-xs font-medium text-[var(--text-secondary)]">
                  Character Name
                </label>
                <input
                  type="text"
                  value={state.character.name}
                  onChange={(e) => updateCharacter({ name: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[var(--text-secondary)]">
                  Character Archetype (Descriptive, Change Anytime)
                </label>
                <select
                  value={state.character.archetype}
                  onChange={(e) => updateCharacter({ archetype: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                >
                  {ARCHETYPES.map((arch) => (
                    <option key={arch} value={arch}>
                      {arch}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[var(--text-secondary)]">
                  Active Character Title
                </label>
                <select
                  value={state.character.activeTitleId}
                  onChange={(e) => updateCharacter({ activeTitleId: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                >
                  {state.titles.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} (Lv.{t.requiredLevel}+)
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-medium text-[var(--text-secondary)]">
                  Personal Mission Tagline
                </label>
                <input
                  type="text"
                  value={state.character.tagline}
                  onChange={(e) => updateCharacter({ tagline: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[var(--text-secondary)]">
                  Archetype Description
                </label>
                <input
                  type="text"
                  value={state.character.customArchetypeDescription}
                  onChange={(e) =>
                    updateCharacter({ customArchetypeDescription: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-xs font-medium text-[var(--text-secondary)]">
                Select Character Emblem Icon
              </label>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {PICKABLE_ICONS.slice(0, 18).map((iconName) => (
                  <button
                    key={iconName}
                    onClick={() => updateCharacter({ avatarIcon: iconName })}
                    className={`flex h-9 w-9 items-center justify-center rounded-xl border transition ${
                      state.character.avatarIcon === iconName
                        ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                        : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                    }`}
                  >
                    <AscendIcon name={iconName} size={16} />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Real Application Record Telemetry Bar */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
        {[
          { label: 'Total XP', val: levelStatus.totalXp.toLocaleString(), icon: 'Zap' },
          { label: 'Current Level', val: `Lv. ${levelStatus.level}`, icon: 'Crown' },
          { label: 'Goals Done', val: `${completedGoalsCount}/${state.goals.length}`, icon: 'Target' },
          { label: 'Habit Logs', val: totalHabitCompletions, icon: 'Flame' },
          { label: 'Tasks Done', val: completedTasksCount, icon: 'CheckSquare' },
          { label: 'Focus + Study', val: `${(Number(totalFocusHours) + Number(totalStudyHours)).toFixed(1)}h`, icon: 'Timer' },
          { label: 'Skills Lv.2+', val: `${developedSkillsCount}/${state.skills.length}`, icon: 'Network' },
          { label: 'Best Streak', val: `${bestStreak}d`, icon: 'Award' },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-3"
          >
            <div className="flex items-center gap-1.5 text-[11px] text-[var(--text-secondary)]">
              <AscendIcon
                name={stat.icon}
                size={13}
                className="text-[var(--accent-primary)]"
              />
              <span className="truncate">{stat.label}</span>
            </div>
            <div className="font-mono-metric mt-1 text-base font-bold text-[var(--text-primary)]">
              {stat.val}
            </div>
          </div>
        ))}
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border-subtle)] pb-3">
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'attributes', label: `Attributes (${state.attributes.length})`, icon: 'Shield' },
            { id: 'domains', label: `Life Domains (${state.domains.length})`, icon: 'Compass' },
            { id: 'titles', label: `Titles & Ranks (${state.titles.length})`, icon: 'Crown' },
            { id: 'achievements', label: `Achievements (${unlockedAchievementsCount}/${state.achievements.length})`, icon: 'Award' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition ${
                activeTab === tab.id
                  ? 'bg-[var(--accent-primary)] text-white shadow-sm'
                  : 'border border-[var(--border-subtle)] bg-[var(--bg-surface)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <AscendIcon name={tab.icon} size={15} />
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'attributes' && (
          <button
            onClick={handleCreateNewAttribute}
            className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-3.5 py-2 text-xs font-semibold text-white"
          >
            <AscendIcon name="Plus" size={14} />
            Add Custom Attribute
          </button>
        )}
        {activeTab === 'domains' && (
          <button
            onClick={handleCreateNewDomain}
            className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-3.5 py-2 text-xs font-semibold text-white"
          >
            <AscendIcon name="Plus" size={14} />
            Add Custom Domain
          </button>
        )}
      </div>

      {/* TAB 1: 12+ CHARACTER ATTRIBUTES & RADAR */}
      {activeTab === 'attributes' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Radar Visualization Card */}
          <div className="lg:col-span-5 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h2 className="font-subheading text-base font-semibold text-[var(--text-primary)]">
              12-Attribute Synergy Polygon
            </h2>
            <p className="mt-1 text-xs text-[var(--text-secondary)]">
              Transparent progression rule: Each attribute increases by +1 point for every{' '}
              <span className="font-mono-metric font-semibold text-[var(--text-primary)]">
                xpPerPoint
              </span>{' '}
              earned from its linked habits, goals, tasks, and skills.
            </p>
            <div className="my-4 flex justify-center">
              <RadarChartSVG attributes={state.attributes} size={300} />
            </div>
            <div className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/50 p-3 text-[11px] text-[var(--text-secondary)]">
              <strong>Transparent Progression Note:</strong> Attribute scores reflect your self-defined activity tracking rules within Ascend OS and are never an objective measurement of personal worth or human potential.
            </div>
          </div>

          {/* 12 Attributes Grid */}
          <div className="lg:col-span-7 grid grid-cols-1 gap-3.5 sm:grid-cols-2">
            {state.attributes.map((attr) => {
              const metrics = calculateAttributeMetrics(attr);
              const linkedHabits = state.habits.filter((h) =>
                h.attributeIds.includes(attr.id)
              );
              const linkedGoals = state.goals.filter((g) =>
                g.attributeIds.includes(attr.id)
              );

              return (
                <div
                  key={attr.id}
                  className="flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4 transition hover:border-[var(--accent-primary)]/50"
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="flex h-9 w-9 items-center justify-center rounded-xl text-white"
                          style={{ backgroundColor: attr.color || '#7C5CFC' }}
                        >
                          <AscendIcon name={attr.icon} size={17} />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono-metric rounded bg-[var(--bg-elevated)] px-1.5 py-0.5 text-[10px] font-bold text-[var(--text-primary)]">
                              {attr.code}
                            </span>
                            <h3 className="font-character-custom text-sm font-bold text-[var(--text-primary)]">
                              {attr.name}
                            </h3>
                          </div>
                          <p className="mt-0.5 text-[11px] text-[var(--text-secondary)] line-clamp-2">
                            {attr.description}
                          </p>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-mono-metric text-xl font-extrabold text-[var(--text-primary)]">
                          {metrics.totalScore}
                        </div>
                        <button
                          onClick={() => setEditingAttr(attr)}
                          className="text-[10px] font-medium text-[var(--accent-primary)] hover:underline"
                        >
                          Edit Rule
                        </button>
                      </div>
                    </div>

                    {/* Transparent XP Rule Progress */}
                    <div className="mt-3">
                      <div className="flex items-center justify-between text-[10px] text-[var(--text-secondary)]">
                        <span className="font-mono-metric">
                          Base {attr.baseScore} + {metrics.bonusPoints} XP Pts
                        </span>
                        <span className="font-mono-metric">
                          {metrics.remainderXp}/{metrics.xpPerPoint} XP to +1
                        </span>
                      </div>
                      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            width: `${metrics.progressPercent}%`,
                            backgroundColor: attr.color || 'var(--accent-primary)',
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between border-t border-[var(--border-subtle)] pt-2 text-[10px] text-[var(--text-secondary)]">
                    <span>
                      Linked: {linkedHabits.length} habits · {linkedGoals.length} goals
                    </span>
                    <button
                      onClick={() =>
                        saveAttribute({ ...attr, visible: !attr.visible })
                      }
                      className="font-medium hover:text-[var(--text-primary)]"
                    >
                      {attr.visible ? 'In Radar' : 'Hidden'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Attribute Editor Modal */}
      {editingAttr && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                Customize Attribute & Progression Rule
              </h3>
              <button
                onClick={() => setEditingAttr(null)}
                className="text-[var(--text-secondary)]"
              >
                <AscendIcon name="X" size={18} />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Code (3 chars)
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    value={editingAttr.code}
                    onChange={(e) =>
                      setEditingAttr({
                        ...editingAttr,
                        code: e.target.value.toUpperCase(),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Attribute Name
                  </label>
                  <input
                    type="text"
                    value={editingAttr.name}
                    onChange={(e) =>
                      setEditingAttr({ ...editingAttr, name: e.target.value })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Description
                </label>
                <input
                  type="text"
                  value={editingAttr.description}
                  onChange={(e) =>
                    setEditingAttr({ ...editingAttr, description: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Baseline Score
                  </label>
                  <input
                    type="number"
                    value={editingAttr.baseScore}
                    onChange={(e) =>
                      setEditingAttr({
                        ...editingAttr,
                        baseScore: Number(e.target.value) || 0,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    XP per +1 Point
                  </label>
                  <input
                    type="number"
                    min={10}
                    value={editingAttr.xpPerPoint}
                    onChange={(e) =>
                      setEditingAttr({
                        ...editingAttr,
                        xpPerPoint: Math.max(10, Number(e.target.value) || 100),
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Accent Color
                  </label>
                  <input
                    type="color"
                    value={editingAttr.color}
                    onChange={(e) =>
                      setEditingAttr({ ...editingAttr, color: e.target.value })
                    }
                    className="mt-1 h-9 w-full cursor-pointer rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-1"
                  />
                </div>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between">
              {editingAttr.isCustom ? (
                <button
                  onClick={() => {
                    deleteAttribute(editingAttr.id);
                    setEditingAttr(null);
                  }}
                  className="text-xs font-semibold text-rose-500 hover:underline"
                >
                  Delete Custom Attribute
                </button>
              ) : (
                <span />
              )}
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingAttr(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs font-medium text-[var(--text-secondary)]"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    saveAttribute(editingAttr);
                    setEditingAttr(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Attribute
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: 12+ LIFE DOMAINS */}
      {activeTab === 'domains' && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {state.domains.map((dom) => {
            const linkedGoals = state.goals.filter((g) => g.domainId === dom.id);
            const linkedHabits = state.habits.filter((h) => h.domainId === dom.id);
            const pct = Math.min(
              100,
              Math.round((dom.loggedHours / Math.max(1, dom.targetHoursPerWeek)) * 100)
            );

            return (
              <div
                key={dom.id}
                className="flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div
                        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white"
                        style={{ backgroundColor: dom.color }}
                      >
                        <AscendIcon name={dom.icon} size={18} />
                      </div>
                      <div>
                        <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
                          {dom.name}
                        </h3>
                        <p className="text-xs text-[var(--text-secondary)]">
                          {dom.description}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setEditingDomain(dom)}
                      className="text-xs text-[var(--accent-primary)] hover:underline"
                    >
                      Edit
                    </button>
                  </div>

                  <div className="mt-4">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[var(--text-secondary)]">
                        Weekly Allocation
                      </span>
                      <span className="font-mono-metric font-semibold text-[var(--text-primary)]">
                        {dom.loggedHours}h / {dom.targetHoursPerWeek}h ({pct}%)
                      </span>
                    </div>
                    <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{ width: `${pct}%`, backgroundColor: dom.color }}
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-[var(--border-subtle)] pt-3 text-xs text-[var(--text-secondary)]">
                  <span>
                    {linkedGoals.length} Goals · {linkedHabits.length} Habits
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() =>
                        saveDomain({
                          ...dom,
                          loggedHours: Math.max(0, Number((dom.loggedHours - 0.5).toFixed(1))),
                        })
                      }
                      className="rounded-lg border border-[var(--border-subtle)] px-2 py-0.5 text-xs font-bold"
                    >
                      -0.5h
                    </button>
                    <button
                      onClick={() =>
                        saveDomain({
                          ...dom,
                          loggedHours: Number((dom.loggedHours + 0.5).toFixed(1)),
                        })
                      }
                      className="rounded-lg bg-[var(--accent-soft)] px-2 py-0.5 text-xs font-bold text-[var(--accent-primary)]"
                    >
                      +0.5h
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Domain Editor Modal */}
      {editingDomain && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Edit Life Domain
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Domain Name
                </label>
                <input
                  type="text"
                  value={editingDomain.name}
                  onChange={(e) =>
                    setEditingDomain({ ...editingDomain, name: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Description
                </label>
                <input
                  type="text"
                  value={editingDomain.description}
                  onChange={(e) =>
                    setEditingDomain({
                      ...editingDomain,
                      description: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Target Hours / Week
                  </label>
                  <input
                    type="number"
                    value={editingDomain.targetHoursPerWeek}
                    onChange={(e) =>
                      setEditingDomain({
                        ...editingDomain,
                        targetHoursPerWeek: Number(e.target.value) || 1,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Color
                  </label>
                  <input
                    type="color"
                    value={editingDomain.color}
                    onChange={(e) =>
                      setEditingDomain({ ...editingDomain, color: e.target.value })
                    }
                    className="mt-1 h-9 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-1"
                  />
                </div>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between">
              {editingDomain.isCustom ? (
                <button
                  onClick={() => {
                    deleteDomain(editingDomain.id);
                    setEditingDomain(null);
                  }}
                  className="text-xs font-semibold text-rose-500"
                >
                  Delete Domain
                </button>
              ) : (
                <span />
              )}
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingDomain(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    saveDomain(editingDomain);
                    setEditingDomain(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Domain
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CHARACTER TITLES & RANKS */}
      {activeTab === 'titles' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="lg:col-span-8 grid grid-cols-1 gap-3.5 sm:grid-cols-2">
            {state.titles.map((t) => {
              const isSelected = state.character.activeTitleId === t.id;
              const isUnlocked = t.unlocked || levelStatus.level >= t.requiredLevel;

              return (
                <div
                  key={t.id}
                  className={`flex flex-col justify-between rounded-2xl border p-4 ${
                    isSelected
                      ? 'border-[var(--accent-primary)] bg-[var(--accent-soft)]/30'
                      : 'border-[var(--border-subtle)] bg-[var(--bg-surface)]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="font-character-custom text-sm font-bold text-[var(--text-primary)]">
                        {t.name}
                      </span>
                      <span className="font-mono-metric rounded-md bg-[var(--bg-elevated)] px-2 py-0.5 text-[11px] font-semibold text-[var(--text-secondary)]">
                        Req Lv. {t.requiredLevel}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-[var(--text-secondary)]">
                      {t.description}
                    </p>
                  </div>

                  <div className="mt-4 flex items-center justify-between">
                    <span
                      className={`text-[11px] font-semibold ${
                        isUnlocked ? 'text-emerald-500' : 'text-[var(--text-muted)]'
                      }`}
                    >
                      {isUnlocked ? 'Unlocked' : 'Locked'}
                    </span>
                    <button
                      onClick={() => updateCharacter({ activeTitleId: t.id })}
                      className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                        isSelected
                          ? 'bg-[var(--accent-primary)] text-white'
                          : 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-primary)] hover:border-[var(--accent-primary)]'
                      }`}
                    >
                      {isSelected ? 'Active Title' : 'Equip Title'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <form
            onSubmit={handleAddTitle}
            className="lg:col-span-4 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5 space-y-3 h-fit"
          >
            <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
              Create Custom Character Title
            </h3>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Title Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Polymath Scholar"
                value={newTitleName}
                onChange={(e) => setNewTitleName(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Description & Unlock Meaning
              </label>
              <input
                type="text"
                placeholder="Sustained mastery across STEM & Fitness"
                value={newTitleDesc}
                onChange={(e) => setNewTitleDesc(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Required Level
              </label>
              <input
                type="number"
                min={1}
                value={newTitleLevel}
                onChange={(e) => setNewTitleLevel(Number(e.target.value) || 1)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>
            <button
              type="submit"
              className="w-full rounded-xl bg-[var(--accent-primary)] py-2.5 text-xs font-semibold text-white"
            >
              Add Custom Title
            </button>
          </form>
        </div>
      )}

      {/* TAB 4: ACHIEVEMENTS & BADGES */}
      {activeTab === 'achievements' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="lg:col-span-8 grid grid-cols-1 gap-3.5 sm:grid-cols-2">
            {state.achievements.map((ach) => (
              <div
                key={ach.id}
                className={`flex flex-col justify-between rounded-2xl border p-4 ${
                  ach.unlocked
                    ? 'border-[var(--border-subtle)] bg-[var(--bg-surface)]'
                    : 'border-dashed border-[var(--border-subtle)] bg-[var(--bg-elevated)]/30 opacity-80'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${
                      ach.unlocked
                        ? 'bg-[var(--accent-soft)] text-[var(--accent-primary)]'
                        : 'bg-[var(--bg-elevated)] text-[var(--text-muted)]'
                    }`}
                  >
                    <AscendIcon name={ach.icon} size={20} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="truncate text-sm font-bold text-[var(--text-primary)]">
                        {ach.name}
                      </h4>
                      <span className="font-mono-metric shrink-0 rounded bg-[var(--accent-soft)] px-1.5 py-0.5 text-[10px] font-semibold text-[var(--accent-primary)]">
                        +{ach.xpReward} XP
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-[var(--text-secondary)]">
                      {ach.description}
                    </p>
                    <p className="mt-1.5 text-[10px] text-[var(--text-muted)]">
                      Condition: {ach.unlockConditionText}
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-[var(--border-subtle)] pt-2.5 text-[11px]">
                  {ach.unlocked ? (
                    <span className="font-mono-metric text-emerald-500 font-semibold">
                      Unlocked {ach.unlockedDate}
                    </span>
                  ) : (
                    <button
                      onClick={() => unlockAchievement(ach.id)}
                      className="rounded-lg bg-[var(--accent-primary)] px-3 py-1 text-xs font-semibold text-white"
                    >
                      Claim & Unlock Badge
                    </button>
                  )}
                  <span className="text-[var(--text-secondary)]">{ach.category}</span>
                </div>
              </div>
            ))}
          </div>

          <form
            onSubmit={handleAddAchievement}
            className="lg:col-span-4 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5 space-y-3 h-fit"
          >
            <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
              Create Custom Achievement Badge
            </h3>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Badge Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g., 100-Hour Calculus Titan"
                value={newAchName}
                onChange={(e) => setNewAchName(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Description
              </label>
              <input
                type="text"
                placeholder="Completed 100 hours of advanced problem sets"
                value={newAchDesc}
                onChange={(e) => setNewAchDesc(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Unlock Condition
                </label>
                <input
                  type="text"
                  placeholder="100h logged"
                  value={newAchCond}
                  onChange={(e) => setNewAchCond(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  XP Reward
                </label>
                <input
                  type="number"
                  min={0}
                  value={newAchXp}
                  onChange={(e) => setNewAchXp(Number(e.target.value) || 0)}
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Badge Icon
              </label>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {['Award', 'Trophy', 'Medal', 'Crown', 'Shield', 'Flame', 'Star', 'Gem'].map(
                  (ic) => (
                    <button
                      type="button"
                      key={ic}
                      onClick={() => setNewAchIcon(ic)}
                      className={`flex h-8 w-8 items-center justify-center rounded-lg border ${
                        newAchIcon === ic
                          ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                          : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                      }`}
                    >
                      <AscendIcon name={ic} size={15} />
                    </button>
                  )
                )}
              </div>
            </div>
            <button
              type="submit"
              className="w-full rounded-xl bg-[var(--accent-primary)] py-2.5 text-xs font-semibold text-white"
            >
              Create Badge
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
