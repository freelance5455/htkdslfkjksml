import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon, PICKABLE_ICONS } from '../components/AscendIcon';
import { EducationSubject, SkillNode } from '../types/ascend';

export const SkillTreeAndEducationModule: React.FC = () => {
  const {
    state,
    upgradeSkillNode,
    saveSkill,
    deleteSkill,
    addSkillBranch,
    saveSubject,
    deleteSubject,
    logSubjectStudyHours,
    toggleSubjectChapter,
  } = useAscend();

  const [viewMode, setViewMode] = useState<'skill-tree' | 'education'>('skill-tree');
  const [selectedBranch, setSelectedBranch] = useState<string>('All');
  const [editingSkill, setEditingSkill] = useState<SkillNode | null>(null);
  const [newBranchName, setNewBranchName] = useState('');

  // Education state
  const [editingSubject, setEditingSubject] = useState<EducationSubject | null>(null);
  const [newChapterTitles, setNewChapterTitles] = useState<Record<string, string>>({});

  const filteredBranches =
    selectedBranch === 'All'
      ? state.skillBranches
      : state.skillBranches.filter((b) => b === selectedBranch);

  const handleOpenNewSkill = () => {
    setEditingSkill({
      id: `sk-custom-${Date.now()}`,
      branch:
        selectedBranch === 'All'
          ? state.skillBranches[0] || 'Intellect'
          : selectedBranch,
      name: '',
      description: '',
      icon: 'Sparkles',
      tier: 1,
      currentLevel: 1,
      maxLevel: 5,
      xpInvested: 100,
      xpPerLevel: 100,
      unlockRequirementText: 'Custom Skill Node',
      unlocked: true,
      attributeIds: ['attr-int'],
      xpRewardOnLevelUp: state.xpSettings.defaultSkillXp,
    });
  };

  const handleOpenNewSubject = () => {
    setEditingSubject({
      id: `subj-${Date.now()}`,
      name: '',
      category: 'Academic Core',
      icon: 'BookOpen',
      color: '#7C5CFC',
      targetHours: 60,
      loggedHours: 0,
      attributeIds: ['attr-int', 'attr-kno'],
      xpPerHour: state.xpSettings.defaultLearningHourXp,
      chapters: [],
    });
  };

  const handleAddChapterToSubject = (subj: EducationSubject) => {
    const title = (newChapterTitles[subj.id] || '').trim();
    if (!title) return;
    const updated: EducationSubject = {
      ...subj,
      chapters: [
        ...subj.chapters,
        {
          id: `ch-${Date.now()}`,
          title,
          completed: false,
          practiceQuestionsSolved: 0,
          revisionCount: 0,
        },
      ],
    };
    saveSubject(updated);
    setNewChapterTitles({ ...newChapterTitles, [subj.id]: '' });
  };

  const totalStudyHours = state.subjects.reduce((sum, s) => sum + s.loggedHours, 0);
  const totalChapters = state.subjects.reduce((sum, s) => sum + s.chapters.length, 0);
  const completedChapters = state.subjects.reduce(
    (sum, s) => sum + s.chapters.filter((c) => c.completed).length,
    0
  );
  const totalQuestionsSolved = state.subjects.reduce(
    (sum, s) =>
      sum +
      s.chapters.reduce((cSum, ch) => cSum + ch.practiceQuestionsSolved, 0),
    0
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Mode Switcher */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            {viewMode === 'skill-tree'
              ? 'Interactive Life Skill Tree'
              : 'Education Character Profile'}
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            {viewMode === 'skill-tree'
              ? 'Develop interconnected capabilities across Intellect, Discipline, Physical, Creativity, Social, and Wisdom branches.'
              : 'Track academic subjects, syllabus chapters, solved problem sets, and study hours tied to character progression.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1">
            <button
              onClick={() => setViewMode('skill-tree')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                viewMode === 'skill-tree'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <AscendIcon name="Network" size={14} />
              Life Skill Tree ({state.skills.length})
            </button>
            <button
              onClick={() => setViewMode('education')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                viewMode === 'education'
                  ? 'bg-[var(--accent-primary)] text-white'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              <AscendIcon name="GraduationCap" size={14} />
              Education Profile ({state.subjects.length})
            </button>
          </div>

          {viewMode === 'skill-tree' ? (
            <button
              onClick={handleOpenNewSkill}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-3.5 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Plus" size={15} />
              Add Custom Skill
            </button>
          ) : (
            <button
              onClick={handleOpenNewSubject}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-3.5 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Plus" size={15} />
              Add Subject / Course
            </button>
          )}
        </div>
      </div>

      {/* VIEW 1: INTERACTIVE LIFE SKILL TREE */}
      {viewMode === 'skill-tree' && (
        <div className="space-y-6">
          {/* Branch Filter Bar + Add Branch */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4">
            <div className="flex flex-wrap items-center gap-1.5">
              {['All', ...state.skillBranches].map((branch) => (
                <button
                  key={branch}
                  onClick={() => setSelectedBranch(branch)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                    selectedBranch === branch
                      ? 'bg-[var(--accent-primary)] text-white'
                      : 'border border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                  }`}
                >
                  {branch}
                </button>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newBranchName.trim()) return;
                addSkillBranch(newBranchName);
                setNewBranchName('');
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                placeholder="New skill branch..."
                value={newBranchName}
                onChange={(e) => setNewBranchName(e.target.value)}
                className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs text-[var(--text-primary)]"
              />
              <button
                type="submit"
                className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-semibold text-[var(--text-primary)] hover:border-[var(--accent-primary)]"
              >
                + Branch
              </button>
            </form>
          </div>

          {/* Skill Tree Branches */}
          <div className="space-y-6">
            {filteredBranches.map((branch) => {
              const branchSkills = state.skills
                .filter((s) => s.branch === branch)
                .sort((a, b) => a.tier - b.tier);

              if (branchSkills.length === 0) return null;

              const totalLevels = branchSkills.reduce(
                (sum, s) => sum + s.currentLevel,
                0
              );
              const maxBranchLevels = branchSkills.reduce(
                (sum, s) => sum + s.maxLevel,
                0
              );

              return (
                <div
                  key={branch}
                  className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--border-subtle)] pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[var(--accent-soft)] text-[var(--accent-primary)]">
                        <AscendIcon name="GitBranch" size={16} />
                      </div>
                      <div>
                        <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                          {branch} Branch
                        </h2>
                        <p className="text-xs text-[var(--text-secondary)]">
                          Tier 1 Foundation → Tier 2 Specialization → Tier 3 Mastery
                        </p>
                      </div>
                    </div>
                    <span className="font-mono-metric rounded-xl bg-[var(--bg-elevated)] px-3 py-1 text-xs font-bold text-[var(--text-primary)]">
                      Branch Mastery: {totalLevels} / {maxBranchLevels}
                    </span>
                  </div>

                  {/* Interactive Connected Nodes Row */}
                  <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-3">
                    {branchSkills.map((skill, idx) => {
                      const pct = Math.round(
                        (skill.currentLevel / skill.maxLevel) * 100
                      );
                      const isMaxed = skill.currentLevel >= skill.maxLevel;
                      const linkedAttrs = state.attributes.filter((a) =>
                        skill.attributeIds.includes(a.id)
                      );

                      return (
                        <div key={skill.id} className="relative flex items-stretch">
                          {/* Connector Line on Desktop */}
                          {idx > 0 && (
                            <div className="hidden md:flex absolute -left-4 top-1/2 -translate-y-1/2 w-4 items-center justify-center">
                              <div className="h-0.5 w-full bg-[var(--accent-primary)]/40" />
                            </div>
                          )}

                          <div
                            className={`flex w-full flex-col justify-between rounded-2xl border p-4 transition ${
                              isMaxed
                                ? 'border-emerald-500/60 bg-emerald-500/5'
                                : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 hover:border-[var(--accent-primary)]'
                            }`}
                          >
                            <div>
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center gap-2.5">
                                  <div
                                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
                                      isMaxed
                                        ? 'bg-emerald-500 text-white'
                                        : 'bg-[var(--accent-soft)] text-[var(--accent-primary)]'
                                    }`}
                                  >
                                    <AscendIcon name={skill.icon} size={18} />
                                  </div>
                                  <div>
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-mono-metric rounded bg-[var(--bg-surface)] px-1.5 py-0.5 text-[10px] font-semibold text-[var(--text-secondary)]">
                                        TIER {skill.tier}
                                      </span>
                                      <span className="font-mono-metric rounded bg-[var(--accent-soft)] px-1.5 py-0.5 text-[10px] font-bold text-[var(--accent-primary)]">
                                        Lv.{skill.currentLevel}/{skill.maxLevel}
                                      </span>
                                    </div>
                                    <h3 className="mt-1 text-sm font-bold text-[var(--text-primary)]">
                                      {skill.name}
                                    </h3>
                                  </div>
                                </div>
                                <button
                                  onClick={() => setEditingSkill(skill)}
                                  className="text-[11px] text-[var(--text-secondary)] hover:text-[var(--accent-primary)]"
                                >
                                  Edit
                                </button>
                              </div>

                              <p className="mt-2 text-xs text-[var(--text-secondary)]">
                                {skill.description}
                              </p>

                              {/* Linked Attribute Pills */}
                              <div className="mt-2.5 flex flex-wrap gap-1">
                                {linkedAttrs.map((a) => (
                                  <span
                                    key={a.id}
                                    className="font-mono-metric rounded-md border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-1.5 py-0.5 text-[10px] font-semibold text-[var(--text-primary)]"
                                  >
                                    {a.code}
                                  </span>
                                ))}
                                <span className="font-mono-metric rounded-md bg-[var(--accent-soft)] px-1.5 py-0.5 text-[10px] font-semibold text-[var(--accent-primary)]">
                                  +{skill.xpRewardOnLevelUp} XP / Lv
                                </span>
                              </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-[var(--border-subtle)]">
                              <div className="mb-2 h-1.5 w-full overflow-hidden rounded-full bg-[var(--bg-surface)]">
                                <div
                                  className={`h-full rounded-full transition-all ${
                                    isMaxed
                                      ? 'bg-emerald-500'
                                      : 'bg-[var(--accent-primary)]'
                                  }`}
                                  style={{ width: `${pct}%` }}
                                />
                              </div>

                              <div className="flex items-center justify-between">
                                <span className="text-[10px] text-[var(--text-muted)]">
                                  {skill.unlockRequirementText}
                                </span>
                                <button
                                  onClick={() => upgradeSkillNode(skill.id)}
                                  disabled={isMaxed}
                                  className={`inline-flex items-center gap-1 rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                                    isMaxed
                                      ? 'bg-emerald-500/20 text-emerald-500 cursor-default'
                                      : 'bg-[var(--accent-primary)] text-white hover:opacity-95'
                                  }`}
                                >
                                  <AscendIcon
                                    name={isMaxed ? 'CheckCircle2' : 'Zap'}
                                    size={13}
                                  />
                                  {isMaxed ? 'Mastered' : 'Train +1 Lv'}
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: EDUCATION CHARACTER PROFILE */}
      {viewMode === 'education' && (
        <div className="space-y-6">
          {/* Education Telemetry Strip */}
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4">
              <div className="text-xs text-[var(--text-secondary)]">
                Total Study Hours
              </div>
              <div className="font-mono-metric mt-1 text-2xl font-bold text-[var(--text-primary)]">
                {totalStudyHours.toFixed(1)}h
              </div>
            </div>
            <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4">
              <div className="text-xs text-[var(--text-secondary)]">
                Chapters Completed
              </div>
              <div className="font-mono-metric mt-1 text-2xl font-bold text-[var(--text-primary)]">
                {completedChapters} / {totalChapters}
              </div>
            </div>
            <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4">
              <div className="text-xs text-[var(--text-secondary)]">
                Practice Questions Solved
              </div>
              <div className="font-mono-metric mt-1 text-2xl font-bold text-[var(--accent-primary)]">
                {totalQuestionsSolved.toLocaleString()}
              </div>
            </div>
            <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-4">
              <div className="text-xs text-[var(--text-secondary)]">
                Active Subjects
              </div>
              <div className="font-mono-metric mt-1 text-2xl font-bold text-[var(--text-primary)]">
                {state.subjects.length}
              </div>
            </div>
          </div>

          {/* Subjects & Syllabus Modules */}
          <div className="grid grid-cols-1 gap-6">
            {state.subjects.map((subj) => {
              const hourPct = Math.min(
                100,
                Math.round((subj.loggedHours / Math.max(1, subj.targetHours)) * 100)
              );
              const doneCh = subj.chapters.filter((c) => c.completed).length;

              return (
                <div
                  key={subj.id}
                  className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
                >
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between border-b border-[var(--border-subtle)] pb-4">
                    <div className="flex items-start gap-3.5">
                      <div
                        className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-white"
                        style={{ backgroundColor: subj.color }}
                      >
                        <AscendIcon name={subj.icon} size={22} />
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h2 className="font-subheading text-lg font-bold text-[var(--text-primary)]">
                            {subj.name}
                          </h2>
                          <span className="rounded-full bg-[var(--bg-elevated)] px-2.5 py-0.5 text-xs text-[var(--text-secondary)]">
                            {subj.category}
                          </span>
                          <span className="font-mono-metric rounded-full bg-[var(--accent-soft)] px-2.5 py-0.5 text-xs font-semibold text-[var(--accent-primary)]">
                            +{subj.xpPerHour} XP / Study Hour
                          </span>
                        </div>
                        <div className="mt-2 flex flex-wrap items-center gap-4 text-xs text-[var(--text-secondary)]">
                          <span className="font-mono-metric">
                            Hours: <strong>{subj.loggedHours}h</strong> / {subj.targetHours}h ({hourPct}%)
                          </span>
                          <span className="font-mono-metric">
                            Chapters: <strong>{doneCh}</strong> / {subj.chapters.length}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => logSubjectStudyHours(subj.id, 1)}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-3.5 py-2 text-xs font-semibold text-white"
                      >
                        <AscendIcon name="Clock" size={14} />
                        Log +1h Study
                      </button>
                      <button
                        onClick={() => logSubjectStudyHours(subj.id, 2)}
                        className="inline-flex items-center gap-1.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs font-semibold text-[var(--text-primary)]"
                      >
                        +2h Sprint
                      </button>
                      <button
                        onClick={() => setEditingSubject(subj)}
                        className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-secondary)]"
                      >
                        Configure
                      </button>
                    </div>
                  </div>

                  {/* Chapters & Problem Counter List */}
                  <div className="mt-4 space-y-2.5">
                    {subj.chapters.map((ch) => (
                      <div
                        key={ch.id}
                        className="flex flex-col gap-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3 sm:flex-row sm:items-center sm:justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => toggleSubjectChapter(subj.id, ch.id)}
                            className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border transition ${
                              ch.completed
                                ? 'border-emerald-500 bg-emerald-500 text-white'
                                : 'border-[var(--border-subtle)] bg-[var(--bg-surface)]'
                            }`}
                          >
                            {ch.completed && (
                              <AscendIcon name="CheckCircle2" size={14} />
                            )}
                          </button>
                          <span
                            className={`text-xs font-medium ${
                              ch.completed
                                ? 'line-through text-[var(--text-secondary)]'
                                : 'text-[var(--text-primary)]'
                            }`}
                          >
                            {ch.title}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-3 self-end sm:self-center">
                          <div className="flex items-center gap-1.5 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-2.5 py-1 text-xs">
                            <span className="text-[var(--text-secondary)]">
                              Questions:
                            </span>
                            <span className="font-mono-metric font-bold text-[var(--text-primary)]">
                              {ch.practiceQuestionsSolved}
                            </span>
                            <button
                              onClick={() => {
                                const updated: EducationSubject = {
                                  ...subj,
                                  chapters: subj.chapters.map((c) =>
                                    c.id === ch.id
                                      ? {
                                          ...c,
                                          practiceQuestionsSolved:
                                            c.practiceQuestionsSolved + 10,
                                        }
                                      : c
                                  ),
                                };
                                saveSubject(updated);
                              }}
                              className="ml-1 rounded bg-[var(--accent-soft)] px-1.5 py-0.5 text-[10px] font-bold text-[var(--accent-primary)]"
                            >
                              +10
                            </button>
                          </div>

                          <div className="flex items-center gap-1.5 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-2.5 py-1 text-xs">
                            <span className="text-[var(--text-secondary)]">
                              Revisions:
                            </span>
                            <span className="font-mono-metric font-bold text-[var(--text-primary)]">
                              {ch.revisionCount}
                            </span>
                            <button
                              onClick={() => {
                                const updated: EducationSubject = {
                                  ...subj,
                                  chapters: subj.chapters.map((c) =>
                                    c.id === ch.id
                                      ? { ...c, revisionCount: c.revisionCount + 1 }
                                      : c
                                  ),
                                };
                                saveSubject(updated);
                              }}
                              className="ml-1 rounded bg-[var(--bg-elevated)] px-1.5 py-0.5 text-[10px] font-bold text-[var(--text-primary)]"
                            >
                              +1
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}

                    {/* Add New Chapter Inline */}
                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="text"
                        placeholder="Add chapter, lecture, or topic..."
                        value={newChapterTitles[subj.id] || ''}
                        onChange={(e) =>
                          setNewChapterTitles({
                            ...newChapterTitles,
                            [subj.id]: e.target.value,
                          })
                        }
                        className="flex-1 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                      />
                      <button
                        onClick={() => handleAddChapterToSubject(subj)}
                        className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-3.5 py-2 text-xs font-semibold text-[var(--accent-primary)] hover:border-[var(--accent-primary)]"
                      >
                        + Add Chapter
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Skill Editor Modal */}
      {editingSkill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Configure Skill Node
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Skill Name
                </label>
                <input
                  type="text"
                  value={editingSkill.name}
                  onChange={(e) =>
                    setEditingSkill({ ...editingSkill, name: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Branch
                  </label>
                  <select
                    value={editingSkill.branch}
                    onChange={(e) =>
                      setEditingSkill({ ...editingSkill, branch: e.target.value })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    {state.skillBranches.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Tier (1 - 3)
                  </label>
                  <select
                    value={editingSkill.tier}
                    onChange={(e) =>
                      setEditingSkill({
                        ...editingSkill,
                        tier: Number(e.target.value) as 1 | 2 | 3,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  >
                    <option value={1}>Tier 1 (Foundation)</option>
                    <option value={2}>Tier 2 (Specialization)</option>
                    <option value={3}>Tier 3 (Mastery)</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Description
                </label>
                <input
                  type="text"
                  value={editingSkill.description}
                  onChange={(e) =>
                    setEditingSkill({
                      ...editingSkill,
                      description: e.target.value,
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Current Lv
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={editingSkill.maxLevel}
                    value={editingSkill.currentLevel}
                    onChange={(e) =>
                      setEditingSkill({
                        ...editingSkill,
                        currentLevel: Number(e.target.value) || 0,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Max Lv
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={editingSkill.maxLevel}
                    onChange={(e) =>
                      setEditingSkill({
                        ...editingSkill,
                        maxLevel: Number(e.target.value) || 5,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    XP Reward / Lv
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editingSkill.xpRewardOnLevelUp}
                    onChange={(e) =>
                      setEditingSkill({
                        ...editingSkill,
                        xpRewardOnLevelUp: Number(e.target.value) || 0,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Icon
                </label>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {PICKABLE_ICONS.slice(0, 12).map((ic) => (
                    <button
                      type="button"
                      key={ic}
                      onClick={() => setEditingSkill({ ...editingSkill, icon: ic })}
                      className={`flex h-8 w-8 items-center justify-center rounded-lg border ${
                        editingSkill.icon === ic
                          ? 'border-[var(--accent-primary)] bg-[var(--accent-primary)] text-white'
                          : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)] text-[var(--text-secondary)]'
                      }`}
                    >
                      <AscendIcon name={ic} size={15} />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteSkill(editingSkill.id);
                  setEditingSkill(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Skill
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingSkill(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingSkill.name.trim()) return;
                    saveSkill(editingSkill);
                    setEditingSkill(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Skill
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Subject Editor Modal */}
      {editingSubject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Configure Education Subject
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Subject / Course Title
                </label>
                <input
                  type="text"
                  value={editingSubject.name}
                  onChange={(e) =>
                    setEditingSubject({ ...editingSubject, name: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Category
                  </label>
                  <input
                    type="text"
                    value={editingSubject.category}
                    onChange={(e) =>
                      setEditingSubject({
                        ...editingSubject,
                        category: e.target.value,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Target Hours
                  </label>
                  <input
                    type="number"
                    value={editingSubject.targetHours}
                    onChange={(e) =>
                      setEditingSubject({
                        ...editingSubject,
                        targetHours: Number(e.target.value) || 20,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    XP per Study Hour
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editingSubject.xpPerHour}
                    onChange={(e) =>
                      setEditingSubject({
                        ...editingSubject,
                        xpPerHour: Number(e.target.value) || 0,
                      })
                    }
                    className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[var(--text-secondary)]">
                    Accent Color
                  </label>
                  <input
                    type="color"
                    value={editingSubject.color}
                    onChange={(e) =>
                      setEditingSubject({ ...editingSubject, color: e.target.value })
                    }
                    className="mt-1 h-9 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-1"
                  />
                </div>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => {
                  deleteSubject(editingSubject.id);
                  setEditingSubject(null);
                }}
                className="text-xs font-semibold text-rose-500"
              >
                Delete Subject
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => setEditingSubject(null)}
                  className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingSubject.name.trim()) return;
                    saveSubject(editingSubject);
                    setEditingSubject(null);
                  }}
                  className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
                >
                  Save Subject
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
