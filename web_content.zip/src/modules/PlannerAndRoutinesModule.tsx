import React, { useState } from 'react';
import { useAscend } from '../context/AscendContext';
import { AscendIcon } from '../components/AscendIcon';
import { detectPlannerConflicts } from '../utils/progressionEngine';
import { getTodayStr } from '../data/initialAscendState';
import { PlannerBlock, RoutineItem } from '../types/ascend';

export const PlannerAndRoutinesModule: React.FC = () => {
  const {
    state,
    savePlannerBlock,
    deletePlannerBlock,
    togglePlannerBlock,
    saveRoutine,
    deleteRoutine,
    toggleRoutineActivity,
  } = useAscend();

  const [selectedDate, setSelectedDate] = useState<string>(getTodayStr());
  const [activeTab, setActiveTab] = useState<'schedule' | 'routines' | 'calendar'>('schedule');

  // New Time Block Form
  const [blockTitle, setBlockTitle] = useState('');
  const [blockStart, setBlockStart] = useState('09:00');
  const [blockEnd, setBlockEnd] = useState('10:30');
  const [blockCategory, setBlockCategory] =
    useState<PlannerBlock['category']>('Deep Work');
  const [blockNotes, setBlockNotes] = useState('');

  // Routine Editing
  const [editingRoutine, setEditingRoutine] = useState<RoutineItem | null>(null);
  const [newActTitles, setNewActTitles] = useState<Record<string, string>>({});
  const [newActTimes, setNewActTimes] = useState<Record<string, string>>({});

  const dayBlocks = state.plannerBlocks
    .filter((b) => b.date === selectedDate)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  const conflictIds = detectPlannerConflicts(dayBlocks);

  const handleAddBlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!blockTitle.trim()) return;
    const block: PlannerBlock = {
      id: `pb-${Date.now()}`,
      date: selectedDate,
      startTime: blockStart,
      endTime: blockEnd,
      title: blockTitle.trim(),
      category: blockCategory,
      completed: false,
      notes: blockNotes.trim(),
    };
    savePlannerBlock(block);
    setBlockTitle('');
    setBlockNotes('');
  };

  const handleCreateNewRoutine = () => {
    setEditingRoutine({
      id: `rout-${Date.now()}`,
      name: 'New Custom Routine',
      period: 'Custom',
      icon: 'Sunrise',
      repeatingDays: [0, 1, 2, 3, 4, 5, 6],
      activities: [
        {
          id: `ra-${Date.now()}`,
          title: 'First Keystone Activity',
          timeSlot: '07:00',
          durationMinutes: 20,
          completedDates: [],
        },
      ],
    });
  };

  const handleAddActivityToRoutine = (rout: RoutineItem) => {
    const title = (newActTitles[rout.id] || '').trim();
    if (!title) return;
    const timeSlot = newActTimes[rout.id] || '08:00';
    const updated: RoutineItem = {
      ...rout,
      activities: [
        ...rout.activities,
        {
          id: `ra-${Date.now()}`,
          title,
          timeSlot,
          durationMinutes: 30,
          completedDates: [],
        },
      ],
    };
    saveRoutine(updated);
    setNewActTitles({ ...newActTitles, [rout.id]: '' });
  };

  const handleDeleteRoutineActivity = (rout: RoutineItem, actId: string) => {
    saveRoutine({
      ...rout,
      activities: rout.activities.filter((a) => a.id !== actId),
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl text-[var(--text-primary)]">
            Daily Planner & Routine Architecture
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            Time-block your day with conflict detection, execute structured routines, and view upcoming deadlines.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value || getTodayStr())}
            className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] px-3 py-2 text-xs font-semibold text-[var(--text-primary)]"
          />

          <div className="inline-flex rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-1">
            {[
              { id: 'schedule', label: 'Time Blocks', icon: 'Clock' },
              { id: 'routines', label: 'Routines', icon: 'Sunrise' },
              { id: 'calendar', label: 'Calendar', icon: 'Calendar' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id as typeof activeTab)}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                  activeTab === t.id
                    ? 'bg-[var(--accent-primary)] text-white'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                <AscendIcon name={t.icon} size={14} />
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* TAB 1: DAILY TIME-BLOCKED SCHEDULE */}
      {activeTab === 'schedule' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Timeline Column */}
          <div className="lg:col-span-8 space-y-4">
            {conflictIds.size > 0 && (
              <div className="flex items-center gap-2.5 rounded-2xl border border-amber-500/50 bg-amber-500/10 p-3.5 text-xs text-amber-600 dark:text-amber-400">
                <AscendIcon name="Zap" size={16} />
                <span>
                  <strong>Schedule Overlap Detected:</strong> {conflictIds.size}{' '}
                  time blocks overlap on {selectedDate}. Adjust timings to maintain clean focus boundaries.
                </span>
              </div>
            )}

            <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
              <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-3">
                <h2 className="font-subheading text-base font-bold text-[var(--text-primary)]">
                  Schedule for {selectedDate}
                </h2>
                <span className="font-mono-metric text-xs text-[var(--text-secondary)]">
                  {dayBlocks.filter((b) => b.completed).length}/{dayBlocks.length}{' '}
                  Blocks Completed
                </span>
              </div>

              <div className="mt-4 space-y-3">
                {dayBlocks.length === 0 ? (
                  <p className="py-8 text-center text-xs text-[var(--text-secondary)]">
                    No time blocks scheduled for {selectedDate}. Add a block on the right to structure your day.
                  </p>
                ) : (
                  dayBlocks.map((block) => {
                    const hasConflict = conflictIds.has(block.id);
                    return (
                      <div
                        key={block.id}
                        className={`flex flex-col gap-2 rounded-xl border p-3.5 sm:flex-row sm:items-center sm:justify-between ${
                          hasConflict
                            ? 'border-amber-500 bg-amber-500/5'
                            : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <button
                            onClick={() => togglePlannerBlock(block.id)}
                            className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border transition ${
                              block.completed
                                ? 'border-emerald-500 bg-emerald-500 text-white'
                                : 'border-[var(--border-subtle)] bg-[var(--bg-surface)]'
                            }`}
                          >
                            {block.completed && (
                              <AscendIcon name="CheckCircle2" size={14} />
                            )}
                          </button>
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-mono-metric rounded-md bg-[var(--accent-soft)] px-2 py-0.5 text-xs font-bold text-[var(--accent-primary)]">
                                {block.startTime} – {block.endTime}
                              </span>
                              <span className="rounded-md bg-[var(--bg-surface)] px-2 py-0.5 text-[11px] font-medium text-[var(--text-secondary)]">
                                {block.category}
                              </span>
                              {hasConflict && (
                                <span className="rounded-md bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold text-amber-500">
                                  Overlap Conflict
                                </span>
                              )}
                            </div>
                            <h3
                              className={`mt-1 text-sm font-semibold ${
                                block.completed
                                  ? 'line-through text-[var(--text-secondary)]'
                                  : 'text-[var(--text-primary)]'
                              }`}
                            >
                              {block.title}
                            </h3>
                            {block.notes && (
                              <p className="mt-0.5 text-xs text-[var(--text-secondary)]">
                                {block.notes}
                              </p>
                            )}
                          </div>
                        </div>

                        <button
                          onClick={() => deletePlannerBlock(block.id)}
                          className="self-end text-xs text-[var(--text-muted)] hover:text-rose-500 sm:self-center"
                        >
                          <AscendIcon name="Trash2" size={15} />
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Add Time Block Form */}
          <form
            onSubmit={handleAddBlock}
            className="lg:col-span-4 rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5 space-y-3.5 h-fit"
          >
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Schedule Time Block
            </h3>
            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Activity Title
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Deep Work: Physics Problem Set"
                value={blockTitle}
                onChange={(e) => setBlockTitle(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Start Time
                </label>
                <input
                  type="time"
                  value={blockStart}
                  onChange={(e) => setBlockStart(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  End Time
                </label>
                <input
                  type="time"
                  value={blockEnd}
                  onChange={(e) => setBlockEnd(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Block Category
              </label>
              <select
                value={blockCategory}
                onChange={(e) =>
                  setBlockCategory(e.target.value as PlannerBlock['category'])
                }
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              >
                <option value="Deep Work">Deep Work</option>
                <option value="Study">Study</option>
                <option value="Habit">Habit</option>
                <option value="Task">Task</option>
                <option value="Routine">Routine</option>
                <option value="Health">Health</option>
                <option value="Break">Break</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-[var(--text-secondary)]">
                Notes
              </label>
              <input
                type="text"
                placeholder="Optional intention or target..."
                value={blockNotes}
                onChange={(e) => setBlockNotes(e.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-xl bg-[var(--accent-primary)] py-2.5 text-xs font-semibold text-white"
            >
              Add Time Block
            </button>
          </form>
        </div>
      )}

      {/* TAB 2: EDITABLE ROUTINES */}
      {activeTab === 'routines' && (
        <div className="space-y-5">
          <div className="flex justify-end">
            <button
              onClick={handleCreateNewRoutine}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
            >
              <AscendIcon name="Plus" size={14} />
              Create New Routine
            </button>
          </div>

          <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
            {state.routines.map((rout) => {
              const doneCount = rout.activities.filter((a) =>
                a.completedDates.includes(selectedDate)
              ).length;
              const pct =
                rout.activities.length > 0
                  ? Math.round((doneCount / rout.activities.length) * 100)
                  : 0;

              return (
                <div
                  key={rout.id}
                  className="flex flex-col justify-between rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5"
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--accent-soft)] text-[var(--accent-primary)]">
                          <AscendIcon name={rout.icon} size={18} />
                        </div>
                        <div>
                          <span className="rounded bg-[var(--bg-elevated)] px-2 py-0.5 text-[10px] font-bold uppercase text-[var(--text-secondary)]">
                            {rout.period} Protocol
                          </span>
                          <h3 className="mt-0.5 font-subheading text-sm font-bold text-[var(--text-primary)]">
                            {rout.name}
                          </h3>
                        </div>
                      </div>
                      <button
                        onClick={() => deleteRoutine(rout.id)}
                        className="text-xs text-[var(--text-muted)] hover:text-rose-500"
                      >
                        <AscendIcon name="Trash2" size={14} />
                      </button>
                    </div>

                    <div className="mt-3">
                      <div className="flex items-center justify-between text-[11px] text-[var(--text-secondary)]">
                        <span>Completion ({selectedDate})</span>
                        <span className="font-mono-metric font-bold text-[var(--text-primary)]">
                          {doneCount}/{rout.activities.length} ({pct}%)
                        </span>
                      </div>
                      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                        <div
                          className="h-full rounded-full bg-[var(--accent-primary)] transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>

                    {/* Activities List */}
                    <div className="mt-4 space-y-2">
                      {rout.activities.map((act) => {
                        const done = act.completedDates.includes(selectedDate);
                        return (
                          <div
                            key={act.id}
                            className="flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 px-3 py-2"
                          >
                            <div className="flex items-center gap-2.5">
                              <button
                                onClick={() =>
                                  toggleRoutineActivity(
                                    rout.id,
                                    act.id,
                                    selectedDate
                                  )
                                }
                                className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${
                                  done
                                    ? 'border-emerald-500 bg-emerald-500 text-white'
                                    : 'border-[var(--border-subtle)] bg-[var(--bg-surface)]'
                                }`}
                              >
                                {done && (
                                  <AscendIcon name="CheckCircle2" size={12} />
                                )}
                              </button>
                              <div>
                                <div
                                  className={`text-xs font-medium ${
                                    done
                                      ? 'line-through text-[var(--text-secondary)]'
                                      : 'text-[var(--text-primary)]'
                                  }`}
                                >
                                  {act.title}
                                </div>
                                <div className="font-mono-metric text-[10px] text-[var(--text-secondary)]">
                                  {act.timeSlot} · {act.durationMinutes}m
                                </div>
                              </div>
                            </div>
                            <button
                              onClick={() =>
                                handleDeleteRoutineActivity(rout, act.id)
                              }
                              className="text-[var(--text-muted)] hover:text-rose-500"
                            >
                              <AscendIcon name="X" size={13} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Add Activity Inline */}
                  <div className="mt-4 border-t border-[var(--border-subtle)] pt-3 space-y-2">
                    <div className="flex gap-1.5">
                      <input
                        type="time"
                        value={newActTimes[rout.id] || '07:00'}
                        onChange={(e) =>
                          setNewActTimes({
                            ...newActTimes,
                            [rout.id]: e.target.value,
                          })
                        }
                        className="w-24 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2 py-1 text-xs text-[var(--text-primary)]"
                      />
                      <input
                        type="text"
                        placeholder="Add activity..."
                        value={newActTitles[rout.id] || ''}
                        onChange={(e) =>
                          setNewActTitles({
                            ...newActTitles,
                            [rout.id]: e.target.value,
                          })
                        }
                        className="flex-1 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-2.5 py-1 text-xs text-[var(--text-primary)]"
                      />
                    </div>
                    <button
                      onClick={() => handleAddActivityToRoutine(rout)}
                      className="w-full rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-elevated)] py-1.5 text-xs font-semibold text-[var(--accent-primary)] hover:border-[var(--accent-primary)]"
                    >
                      + Add Step to Routine
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* New Routine Modal */}
      {editingRoutine && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-6 shadow-xl">
            <h3 className="font-subheading text-base font-bold text-[var(--text-primary)]">
              Create Routine Protocol
            </h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Routine Name
                </label>
                <input
                  type="text"
                  value={editingRoutine.name}
                  onChange={(e) =>
                    setEditingRoutine({ ...editingRoutine, name: e.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--text-secondary)]">
                  Routine Period
                </label>
                <select
                  value={editingRoutine.period}
                  onChange={(e) =>
                    setEditingRoutine({
                      ...editingRoutine,
                      period: e.target.value as RoutineItem['period'],
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-2 text-xs text-[var(--text-primary)]"
                >
                  <option value="Morning">Morning</option>
                  <option value="Afternoon">Afternoon</option>
                  <option value="Evening">Evening</option>
                  <option value="Night">Night</option>
                  <option value="Study">Study</option>
                  <option value="Custom">Custom</option>
                </select>
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => setEditingRoutine(null)}
                className="rounded-xl border border-[var(--border-subtle)] px-4 py-2 text-xs"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  saveRoutine(editingRoutine);
                  setEditingRoutine(null);
                }}
                className="rounded-xl bg-[var(--accent-primary)] px-4 py-2 text-xs font-semibold text-white"
              >
                Create Routine
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CALENDAR & UPCOMING DEADLINES */}
      {activeTab === 'calendar' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
              Scheduled Tasks & Due Dates
            </h3>
            <div className="mt-3 space-y-2.5">
              {state.tasks.map((t) => (
                <div
                  key={t.id}
                  className="flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3 text-xs"
                >
                  <span className="font-medium text-[var(--text-primary)] truncate pr-2">
                    {t.title}
                  </span>
                  <span className="font-mono-metric shrink-0 rounded bg-[var(--bg-surface)] px-2 py-0.5 text-[11px] text-[var(--text-secondary)]">
                    {t.dueDate}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
              Strategic Goal Deadlines
            </h3>
            <div className="mt-3 space-y-2.5">
              {state.goals.map((g) => (
                <div
                  key={g.id}
                  className="flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3 text-xs"
                >
                  <span className="font-medium text-[var(--text-primary)] truncate pr-2">
                    {g.title}
                  </span>
                  <span className="font-mono-metric shrink-0 rounded bg-[var(--accent-soft)] px-2 py-0.5 text-[11px] font-semibold text-[var(--accent-primary)]">
                    {g.targetDate}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <h3 className="font-subheading text-sm font-bold text-[var(--text-primary)]">
              Project Milestones & Deadlines
            </h3>
            <div className="mt-3 space-y-2.5">
              {state.projects.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/40 p-3 text-xs"
                >
                  <span className="font-medium text-[var(--text-primary)] truncate pr-2">
                    {p.name}
                  </span>
                  <span className="font-mono-metric shrink-0 rounded bg-[var(--bg-surface)] px-2 py-0.5 text-[11px] text-[var(--text-secondary)]">
                    {p.deadline}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
