// Moteur de dames 10x10. 1/-1 = pion, 2/-2 = dame.
import { getArenaRules, isArenaSquare } from './arena-rules.js';
export const BOARD_SIZE = 10;
const dirs=[[-1,-1],[-1,1],[1,-1],[1,1]];
const inside=(r,c)=>r>=0&&r<10&&c>=0&&c<10;
const sideOf=p=>Math.sign(p);
const clone=b=>b.map(row=>row.slice());
export function createInitialBoard(){const b=Array.from({length:10},()=>Array(10).fill(0));for(let r=0;r<4;r++)for(let c=0;c<10;c++)if((r+c)%2===1)b[r][c]=-1;for(let r=6;r<10;r++)for(let c=0;c<10;c++)if((r+c)%2===1)b[r][c]=1;return b;}
export function validateBoard(board){if(!Array.isArray(board)||board.length!==10||board.some(row=>!Array.isArray(row)||row.length!==10||row.some(p=>![-2,-1,0,1,2].includes(p))))throw new Error('Damier 10×10 invalide');return true;}
function captureBranches(board,r,c,player,captured,path,rules){
 const p=board[r][c],out=[];
 for(const [dr,dc] of dirs){
  if(Math.abs(p)===1){
   if(rules.menCaptureForwardOnly&&dr!==-player)continue;
   const mr=r+dr,mc=c+dc,lr=r+2*dr,lc=c+2*dc;
   if(inside(lr,lc)&&sideOf(board[mr][mc])===-player&&!captured.has(`${mr},${mc}`)&&board[lr][lc]===0){const nb=clone(board);nb[r][c]=0;nb[lr][lc]=p;const nc=new Set(captured);nc.add(`${mr},${mc}`);out.push(...captureBranches(nb,lr,lc,player,nc,[...path,{from:[r,c],to:[lr,lc],captured:[mr,mc]}],rules));}
  }else{
   let rr=r+dr,cc=c+dc,enemy=null;
   while(inside(rr,cc)){const q=board[rr][cc];if(q!==0){if(sideOf(q)===player||enemy||captured.has(`${rr},${cc}`))break;enemy=[rr,cc];}else if(enemy){const nb=clone(board);nb[r][c]=0;nb[rr][cc]=p;const nc=new Set(captured);nc.add(`${enemy[0]},${enemy[1]}`);out.push(...captureBranches(nb,rr,cc,player,nc,[...path,{from:[r,c],to:[rr,cc],captured:enemy.slice()}],rules));}rr+=dr;cc+=dc;}
  }
 }
 return out.length?out:[...(path.length?[{path,captures:[...captured].map(x=>x.split(',').map(Number))}]:[])];
}
function simpleMoves(board,r,c,rules){const p=board[r][c],out=[];if(!p)return out;if(Math.abs(p)===1){const dr=-sideOf(p);for(const dc of [-1,1]){const rr=r+dr,cc=c+dc;if(inside(rr,cc)&&board[rr][cc]===0)out.push({path:[{from:[r,c],to:[rr,cc],captured:null}],captures:[]});}}else{for(const [dr,dc]of dirs){let rr=r+dr,cc=c+dc,steps=0;while(inside(rr,cc)&&board[rr][cc]===0&&(!rules.kingMoveLimit||steps<rules.kingMoveLimit)){out.push({path:[{from:[r,c],to:[rr,cc],captured:null}],captures:[]});rr+=dr;cc+=dc;steps++;}}}return out;}
export function legalMoves(board,player,{arena='terrestrial'}={}){validateBoard(board);if(player!==1&&player!==-1)throw new Error('Camp de jeu invalide');const rules=getArenaRules(arena),captures=[];for(let r=0;r<10;r++)for(let c=0;c<10;c++)if(sideOf(board[r][c])===player)captures.push(...captureBranches(board,r,c,player,new Set(),[],rules));if(captures.length){const max=Math.max(...captures.map(m=>m.captures.length));return captures.filter(m=>m.captures.length===max);}const normal=[];for(let r=0;r<10;r++)for(let c=0;c<10;c++)if(sideOf(board[r][c])===player)normal.push(...simpleMoves(board,r,c,rules));return normal;}
function sameMove(a,b){return JSON.stringify(a.path)===JSON.stringify(b.path)&&JSON.stringify(a.captures||[])===JSON.stringify(b.captures||[]);}
export function applyMove(board,move,{arena='terrestrial'}={}){validateBoard(board);if(!move?.path?.length)throw new Error('Déplacement invalide');const first=move.path[0],piece=board[first.from[0]]?.[first.from[1]];if(!piece||!legalMoves(board,sideOf(piece),{arena}).some(candidate=>sameMove(candidate,move)))throw new Error('Coup illégal : le déplacement ne respecte pas les règles');const next=clone(board);for(const step of move.path){const[r,c]=step.from,[rr,cc]=step.to;if(next[r][c]!==piece||next[rr][cc]!==0)throw new Error('Séquence de déplacement incohérente');next[r][c]=0;next[rr][cc]=piece;}for(const[r,c]of(move.captures||[]))next[r][c]=0;const[fr,fc]=move.path.at(-1).to,rules=getArenaRules(arena);if(piece===1&&(fr===0||(rules.earlyPromotion&&fr===1)))next[fr][fc]=2;if(piece===-1&&(fr===9||(rules.earlyPromotion&&fr===8)))next[fr][fc]=-2;
 // Effets appliqués à l'arrivée : la lave détruit la pièce, le cristal couronne un pion.
 if(isArenaSquare(rules.lava,fr,fc))next[fr][fc]=0;else if(Math.abs(next[fr][fc])===1&&isArenaSquare(rules.crystals,fr,fc))next[fr][fc]*=2;
 return next;}
export function countPieces(board){return{1:board.flat().filter(p=>p>0).length,'-1':board.flat().filter(p=>p<0).length};}
export function gameStatus(board,playerToMove,{arena='terrestrial'}={}){const counts=countPieces(board),mine=counts[playerToMove],theirs=counts[-playerToMove];if(!mine)return{over:true,winner:-playerToMove,reason:'no-pieces'};if(!theirs)return{over:true,winner:playerToMove,reason:'no-pieces'};if(!legalMoves(board,playerToMove,{arena}).length)return{over:true,winner:-playerToMove,reason:'no-legal-move'};return{over:false,winner:null,reason:null};}
export function chooseAIMove(board,player=-1,{arena='terrestrial'}={}){const moves=legalMoves(board,player,{arena});if(!moves.length)return null;let best=moves[0],bestScore=-Infinity;for(const m of moves){const next=applyMove(board,m,{arena}),[r,c]=m.path.at(-1).to;let score=m.captures.length*120+(Math.abs(next[r][c])===2?45:0)+(player===-1?r:9-r)*2;score-=Math.min(legalMoves(next,-player,{arena}).length,30)*.15;if(score>bestScore){bestScore=score;best=m;}}return best;}
