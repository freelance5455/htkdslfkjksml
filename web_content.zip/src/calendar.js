import { getLunarDate } from './lunar-calendar.js';
import { scheduleCompetitionCalendar } from './competition-calendar.js';
import { recordDameOrResult } from './dame-or.js';
import { recordManagedMatchFinance } from './manager-office.js';
export function roundRobin(clubs, season, divisionId) {
  if (clubs.length < 2 || clubs.length % 2 !== 0) throw new Error('Le calendrier exige un nombre pair de clubs supérieur ou égal à deux');
  const list = clubs.map(c => c.id); const rounds = list.length - 1; const half = list.length / 2;
  let rotation = [...list]; const fixtures = [];
  for (let r = 0; r < rounds; r++) {
    for (let i = 0; i < half; i++) {
      const home = rotation[i], away = rotation[list.length - 1 - i];
      fixtures.push(makeFixture(season, divisionId, r + 1, home, away));
      fixtures.push(makeFixture(season, divisionId, r + 1 + rounds, away, home));
    }
    rotation = [rotation[0], rotation.at(-1), ...rotation.slice(1, -1)];
  }
  return fixtures;
}
function makeFixture(season, divisionId, round, home, away) {
  return { id: `S${season}:${divisionId}:J${round}:${home}:${away}`, season, divisionId, round, home, away, status: 'scheduled', score: null, playedAt: null };
}
export function generateSeasonCalendar(state) {
  const seasonFixtures = state.divisions.filter(d => d.status === 'active').flatMap(d => roundRobin(d.clubs, state.season, d.id));
  const existing = new Set(state.calendar.fixtures.map(f => f.id));
  const fresh = seasonFixtures.filter(f => !existing.has(f.id));
  state.calendar.fixtures.push(...fresh);
  state.calendar.lastGeneratedSeason = state.season;
  scheduleCompetitionCalendar(state);
  return fresh;
}
export function recordResult(state, fixtureId, homeScore, awayScore, matchDetails = {}) {
  if (![homeScore, awayScore].every(n => Number.isInteger(n) && n >= 0)) throw new Error('Score invalide');
  const f = state.calendar.fixtures.find(x => x.id === fixtureId);
  if (!f) throw new Error('Match introuvable');
  if (f.status === 'played' || state.calendar.processedFixtureIds.includes(fixtureId)) return false;
  const home = findClub(state, f.home), away = findClub(state, f.away);
  f.score = [homeScore, awayScore]; f.status = 'played'; f.playedAt = { season: state.season, ...getLunarDate(state.calendar?.currentDay || state.day || 1) };
  if (!f.competitionId) {
    applyClubResult(home, homeScore, awayScore); applyClubResult(away, awayScore, homeScore);
  } else {
    applyCompetitionResult(home, f.competitionId, homeScore, awayScore);
    applyCompetitionResult(away, f.competitionId, awayScore, homeScore);
  }
  f.matchDetails = { ...(f.matchDetails || {}), ...matchDetails };
  recordManagedMatchFinance(state, f, homeScore, awayScore, f.matchDetails);
  recordDameOrResult(state, f, homeScore, awayScore, f.matchDetails);
  state.calendar.processedFixtureIds.push(fixtureId); return true;
}
function findClub(state, id) { const c = state.divisions.flatMap(d => d.clubs).find(x => x.id === id); if (!c) throw new Error(`Club absent du championnat: ${id}`); return c; }
function applyClubResult(club, gf, ga) {
  club.played = (Number(club.played) || 0) + 1;
  club.gf = (Number(club.gf) || 0) + gf;
  club.ga = (Number(club.ga) || 0) + ga;
  if (gf > ga) { club.won = (Number(club.won) || 0) + 1; club.points = (Number(club.points) || 0) + 3; }
  else if (gf === ga) { club.drawn = (Number(club.drawn) || 0) + 1; club.points = (Number(club.points) || 0) + 1; }
  else club.lost = (Number(club.lost) || 0) + 1;
}

function applyCompetitionResult(club, competitionId, gf, ga) {
  club.competitionStats ??= {};
  const stats = club.competitionStats[competitionId] ??= { played: 0, won: 0, lost: 0, gf: 0, ga: 0 };
  stats.played++; stats.gf += gf; stats.ga += ga;
  if (gf > ga) stats.won++; else if (gf < ga) stats.lost++;
}

/**
 * Recalcule les stats de championnat (played/won/drawn/lost/gf/ga/points) à partir
 * des fixtures jouées sans competitionId. Corrige les sauvegardes où le statut
 * était "played" sans mise à jour du classement.
 */
export function rebuildLeagueStandingsFromFixtures(state) {
  if (!state?.divisions || !state?.calendar?.fixtures) return { repaired: 0 };
  for (const division of state.divisions) {
    for (const club of division.clubs || []) {
      Object.assign(club, { played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, points: 0 });
    }
  }
  let repaired = 0;
  const season = Number(state.season) || 1;
  for (const f of state.calendar.fixtures) {
    if (f.status !== 'played' || f.competitionId) continue;
    if (Number(f.season) !== season) continue;
    const score = Array.isArray(f.score) ? f.score : null;
    if (!score || score.length < 2) continue;
    const [hs, as] = score.map(n => Number(n));
    if (![hs, as].every(n => Number.isInteger(n) && n >= 0)) continue;
    try {
      const home = findClub(state, f.home);
      const away = findClub(state, f.away);
      applyClubResult(home, hs, as);
      applyClubResult(away, as, hs);
      repaired++;
      if (!state.calendar.processedFixtureIds.includes(f.id)) {
        state.calendar.processedFixtureIds.push(f.id);
      }
    } catch {
      /* club introuvable : ignorer */
    }
  }
  return { repaired };
}
