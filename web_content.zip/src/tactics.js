// Étape 6.8 — Tactique et composition (écran 08, disposition FM27).
// Les consignes sont enregistrées dans state.options.tactics ; elles n'altèrent pas les règles du jeu.
export const TACTIC_OPTIONS = {
  formation: { label: 'Formation', values: [['centre', 'Centre'], ['ailes', 'Ailes'], ['mixte', 'Mixte']] },
  style: { label: 'Style', values: [['attaque', 'Attaque'], ['equilibre', 'Équilibré'], ['prudent', 'Prudent']] },
  rythme: { label: 'Rythme', values: [['normal', 'Normal'], ['rapide', 'Rapide']] }
};
export const DEFAULT_TACTICS = { formation: 'centre', style: 'equilibre', rythme: 'normal' };
const labelOf = (key, id) => TACTIC_OPTIONS[key].values.find(([value]) => value === id)?.[1] || id;

export function getTactics(state) {
  const saved = state?.options?.tactics || {};
  const result = {};
  for (const key of Object.keys(DEFAULT_TACTICS)) {
    result[key] = TACTIC_OPTIONS[key].values.some(([id]) => id === saved[key]) ? saved[key] : DEFAULT_TACTICS[key];
  }
  return result;
}

export function setTactic(state, key, value) {
  if (!TACTIC_OPTIONS[key] || !TACTIC_OPTIONS[key].values.some(([id]) => id === value)) return getTactics(state);
  state.options ??= {};
  state.options.tactics = { ...getTactics(state), [key]: value };
  return state.options.tactics;
}

export function tacticsSummary(state) {
  const t = getTactics(state);
  return `${labelOf('style', t.style)} · rythme ${labelOf('rythme', t.rythme).toLowerCase()} · formation ${labelOf('formation', t.formation).toLowerCase()}`;
}

// Colonnes (0 à 9) que la formation cherche à occuper : simple aide visuelle.
export function zoneColumns(formation) {
  const zones = { centre: [3, 4, 5, 6], ailes: [0, 1, 8, 9], mixte: [1, 2, 7, 8] };
  return new Set(zones[formation] || zones.centre);
}

/**
 * Effet des consignes sur la simulation du match du club dirigé (borné à ±5 points de force).
 * Style : l'attaque exploite un avantage mais coûte cher en infériorité ; la prudence protège un club plus faible.
 * Rythme rapide : récompense un damiste en forme, pénalise un damiste fatigué. La formation reste visuelle.
 */
export function getTacticBonus(state, ownStrength, opponentStrength, ownForm) {
  const { style, rythme } = getTactics(state);
  const stronger = Number(ownStrength) >= Number(opponentStrength);
  let bonus = 0;
  if (style === 'attaque') bonus += stronger ? 3 : -3;
  if (style === 'prudent') bonus += stronger ? -2 : 3;
  if (rythme === 'rapide') bonus += Number(ownForm) >= 70 ? 2 : Number(ownForm) < 55 ? -2 : 0;
  return Math.max(-5, Math.min(5, bonus));
}
