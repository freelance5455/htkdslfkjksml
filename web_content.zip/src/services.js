// Infrastructure status for the Infrastructure screen. Reports presence only, never secret values.
import { json } from './security.js';

export async function infraStatus(env) {
  const d1 = { state: env.DB ? 'configured' : 'missing' };
  if (env.DB) {
    try {
      await env.DB.prepare('SELECT 1 AS ok').first();
      d1.state = 'connected';
    } catch {
      d1.state = 'error';
    }
  }
  const b2 = {
    bucket: env.B2_BUCKET || null,
    endpoint: env.B2_ENDPOINT || null,
    region: env.B2_REGION || null,
    keyIdSet: Boolean(env.B2_KEY_ID),
    appKeySet: Boolean(env.B2_APPLICATION_KEY),
  };
  b2.configured = Boolean(b2.bucket && b2.endpoint && b2.keyIdSet && b2.appKeySet);
  return { d1, b2, assetsBase: env.ASSETS_BASE || null };
}

export async function handleServices(request, env, { admin, rest }) {
  if (!admin) return json({ error: 'Unauthorized' }, 401);
  if (request.method === 'GET' && rest.length === 1 && rest[0] === 'infra') {
    return json(await infraStatus(env));
  }
  return json({ error: 'Not found' }, 404);
}
