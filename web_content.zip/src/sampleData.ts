import { SlideItem } from './types';

export const INITIAL_SLIDES: SlideItem[] = [
  {
    id: 'slide-1',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
    name: 'Tropical Beach Dawn',
  },
  {
    id: 'slide-2',
    url: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1200&q=80',
    name: 'Snowy Mountain Peaks',
  },
  {
    id: 'slide-3',
    url: 'https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=1200&q=80',
    name: 'Alpine Lake Reflections',
  },
  {
    id: 'slide-4',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
    name: 'Yosemite Valley Mist',
  },
  {
    id: 'slide-5',
    url: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80',
    name: 'Neon Cyberpunk Metropolis',
  },
];
