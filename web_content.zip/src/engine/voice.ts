export interface VoiceSample {
  active: boolean;
  simulated: boolean;
  level: number; // 0..1 overall loudness
  pitch: number; // 0..1 dominant pitch/brightness
  bars: [number, number, number, number, number]; // 5 equalizer bars (0..1)
}

class VoiceChatEngine {
  private stream: MediaStream | null = null;
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private freqData: Uint8Array<ArrayBuffer> | null = null;
  private timeData: Uint8Array<ArrayBuffer> | null = null;
  private active = false;
  private simulated = false;
  private simPhase = 0;

  async start(): Promise<{ active: boolean; simulated: boolean }> {
    if (this.active) {
      return { active: true, simulated: this.simulated };
    }
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error('MediaDevices unavailable');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
        video: false,
      });
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      if (ctx.state === 'suspended') {
        await ctx.resume();
      }
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      analyser.smoothingTimeConstant = 0.62;
      src.connect(analyser);

      this.stream = stream;
      this.ctx = ctx;
      this.analyser = analyser;
      this.freqData = new Uint8Array(analyser.frequencyBinCount);
      this.timeData = new Uint8Array(analyser.fftSize);
      this.active = true;
      this.simulated = false;
      return { active: true, simulated: false };
    } catch {
      // Graceful fallback if mic permission is denied or unavailable in iframe
      this.active = true;
      this.simulated = true;
      this.simPhase = 0;
      return { active: true, simulated: true };
    }
  }

  stop(): void {
    this.active = false;
    this.simulated = false;
    if (this.stream) {
      this.stream.getTracks().forEach((t) => t.stop());
      this.stream = null;
    }
    if (this.ctx) {
      this.ctx.close().catch(() => {});
      this.ctx = null;
    }
    this.analyser = null;
    this.freqData = null;
    this.timeData = null;
  }

  sample(dt = 0.05): VoiceSample {
    if (!this.active) {
      return { active: false, simulated: false, level: 0, pitch: 0, bars: [0, 0, 0, 0, 0] };
    }

    if (this.simulated || !this.analyser || !this.freqData || !this.timeData) {
      this.simPhase += dt * 7.5;
      const burst = Math.max(0, Math.sin(this.simPhase * 0.45) * 0.6 + 0.35);
      const b0 = Math.min(1, Math.max(0.12, Math.abs(Math.sin(this.simPhase * 1.1)) * burst));
      const b1 = Math.min(1, Math.max(0.15, Math.abs(Math.sin(this.simPhase * 1.7 + 0.8)) * burst));
      const b2 = Math.min(1, Math.max(0.18, Math.abs(Math.cos(this.simPhase * 2.1)) * burst));
      const b3 = Math.min(1, Math.max(0.14, Math.abs(Math.sin(this.simPhase * 2.6 + 1.4)) * burst));
      const b4 = Math.min(1, Math.max(0.1, Math.abs(Math.cos(this.simPhase * 3.1 + 0.5)) * burst));
      const level = (b0 + b1 + b2 + b3 + b4) / 5;
      const pitch = (b3 + b4) * 0.5;
      return { active: true, simulated: true, level, pitch, bars: [b0, b1, b2, b3, b4] };
    }

    this.analyser.getByteTimeDomainData(this.timeData);
    this.analyser.getByteFrequencyData(this.freqData);

    // RMS loudness from time-domain waveform
    let sumSq = 0;
    for (let i = 0; i < this.timeData.length; i++) {
      const v = (this.timeData[i] - 128) / 128;
      sumSq += v * v;
    }
    const rms = Math.sqrt(sumSq / this.timeData.length);
    const level = Math.min(1, Math.max(0, (rms - 0.012) * 5.2));

    // 5 speech-range frequency bands (low bass -> mid vocal -> high tone)
    const bandRanges: [number, number][] = [
      [1, 4],
      [4, 9],
      [9, 16],
      [16, 28],
      [28, 48],
    ];
    const rawBars = bandRanges.map(([start, end]) => {
      let sum = 0;
      const count = Math.max(1, end - start);
      for (let i = start; i < end && i < this.freqData!.length; i++) {
        sum += this.freqData![i];
      }
      const norm = sum / (count * 255);
      return Math.min(1, Math.max(0.06, norm * 2.2));
    }) as [number, number, number, number, number];

    // Weighted spectral centroid for pitch estimation
    let weighted = 0;
    let totalMag = 0;
    for (let i = 2; i < 48 && i < this.freqData.length; i++) {
      const m = this.freqData[i];
      weighted += i * m;
      totalMag += m;
    }
    const pitch = totalMag > 10 ? Math.min(1, Math.max(0, (weighted / totalMag - 4) / 28)) : 0.3;

    return {
      active: true,
      simulated: false,
      level,
      pitch,
      bars: rawBars,
    };
  }
}

export const voiceEngine = new VoiceChatEngine();
