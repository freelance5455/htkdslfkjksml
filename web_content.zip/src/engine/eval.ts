import { Board, P, N, B, R, Q, K, WHITE } from './board';

export const VALUE = [0, 100, 320, 330, 500, 900, 0];

// Простые таблицы позиций (Tomasz Michniewski). Строка 0 = 8-я горизонталь.
const PST: number[][] = [
  [],
  [
    0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 10, 10, 20, 30, 30, 20, 10, 10, 5, 5, 10, 25, 25, 10, 5, 5,
    0, 0, 0, 20, 20, 0, 0, 0, 5, -5, -10, 0, 0, -10, -5, 5, 5, 10, 10, -20, -20, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0,
  ],
  [
    -50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 0, 0, 0, -20, -40, -30, 0, 10, 15, 15, 10, 0, -30, -30, 5, 15,
    20, 20, 15, 5, -30, -30, 0, 15, 20, 20, 15, 0, -30, -30, 5, 10, 15, 15, 10, 5, -30, -40, -20, 0, 5, 5, 0, -20, -40,
    -50, -40, -30, -30, -30, -30, -40, -50,
  ],
  [
    -20, -10, -10, -10, -10, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 10, 10, 5, 0, -10, -10, 5, 5, 10, 10,
    5, 5, -10, -10, 0, 10, 10, 10, 10, 0, -10, -10, 10, 10, 10, 10, 10, 10, -10, -10, 5, 0, 0, 0, 0, 5, -10, -20, -10,
    -10, -10, -10, -10, -10, -20,
  ],
  [
    0, 0, 0, 0, 0, 0, 0, 0, 5, 10, 10, 10, 10, 10, 10, 5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0,
    0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, 0, 0, 0, 5, 5, 0, 0, 0,
  ],
  [
    -20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 5, 5, 5, 0, -10, -5, 0, 5, 5, 5, 5, 0,
    -5, 0, 0, 5, 5, 5, 5, 0, -5, -10, 5, 5, 5, 5, 5, 0, -10, -10, 0, 5, 0, 0, 0, 0, -10, -20, -10, -10, -5, -5, -10,
    -10, -20,
  ],
  [
    -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40,
    -30, -30, -40, -40, -50, -50, -40, -40, -30, -20, -30, -30, -40, -40, -30, -30, -20, -10, -20, -20, -20, -20, -20,
    -20, -10, 20, 20, 0, 0, 0, 0, 20, 20, 20, 30, 10, 0, 0, 10, 30, 20,
  ],
];
const KING_END = [
  -50, -40, -30, -20, -20, -30, -40, -50, -30, -20, -10, 0, 0, -10, -20, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30,
  -10, 30, 40, 40, 30, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -30, 0, 0,
  0, 0, -30, -30, -50, -30, -30, -30, -30, -30, -30, -50,
];

export interface EvalFlags {
  usePST: boolean;
  bishopPair: boolean;
  pawnStructure: boolean;
  rookFiles: boolean;
}

const PASSED = [0, 5, 10, 20, 35, 60, 100, 0];

/** Оценка в сантипешках с точки зрения стороны, которая ходит */
export function evaluate(bd: Board, f: EvalFlags): number {
  const b = bd.b;
  const score = [0, 0];
  const bishops = [0, 0];
  let nonPawn = 0;
  const pawnCnt = [new Int8Array(8), new Int8Array(8)];
  const pawnMax = [new Int8Array(8).fill(-1), new Int8Array(8).fill(-1)]; // макс. горизонталь пешек (для белых смотрим чёрных)
  const pawnMin = [new Int8Array(8).fill(8), new Int8Array(8).fill(8)];
  const rooks: number[][] = [[], []];
  const pawnList: number[][] = [[], []];

  for (let sq = 0; sq < 128; sq++) {
    if (sq & 0x88) {
      sq += 7;
      continue;
    }
    const p = b[sq];
    if (!p) continue;
    const t = p & 7;
    const c = p >> 3;
    const file = sq & 7;
    const rank = sq >> 4;
    score[c] += VALUE[t];
    if (t !== P && t !== K) nonPawn += VALUE[t];
    if (f.usePST && t !== K) {
      const idx = c === WHITE ? (7 - rank) * 8 + file : rank * 8 + file;
      score[c] += PST[t][idx];
    }
    if (t === B) bishops[c]++;
    else if (t === P) {
      pawnCnt[c][file]++;
      if (rank > pawnMax[c][file]) pawnMax[c][file] = rank;
      if (rank < pawnMin[c][file]) pawnMin[c][file] = rank;
      pawnList[c].push(sq);
    } else if (t === R) rooks[c].push(sq);
  }

  // король: плавный переход миттельшпиль → эндшпиль
  const phase = Math.min(1, nonPawn / 4800);
  if (f.usePST) {
    for (let c = 0; c < 2; c++) {
      const sq = bd.kingSq[c];
      const file = sq & 7,
        rank = sq >> 4;
      const idx = c === WHITE ? (7 - rank) * 8 + file : rank * 8 + file;
      score[c] += Math.round(PST[K][idx] * phase + KING_END[idx] * (1 - phase));
    }
  }

  if (f.bishopPair) {
    if (bishops[0] >= 2) score[0] += 30;
    if (bishops[1] >= 2) score[1] += 30;
  }

  if (f.pawnStructure) {
    for (let c = 0; c < 2; c++) {
      const o = c ^ 1;
      for (let file = 0; file < 8; file++) {
        const cnt = pawnCnt[c][file];
        if (cnt > 1) score[c] -= 12 * (cnt - 1);
        if (cnt > 0) {
          const left = file > 0 ? pawnCnt[c][file - 1] : 0;
          const right = file < 7 ? pawnCnt[c][file + 1] : 0;
          if (!left && !right) score[c] -= 14 * cnt;
        }
      }
      for (const sq of pawnList[c]) {
        const file = sq & 7,
          rank = sq >> 4;
        let passed = true;
        for (let ff = Math.max(0, file - 1); ff <= Math.min(7, file + 1); ff++) {
          if (c === WHITE ? pawnMax[o][ff] > rank : pawnMin[o][ff] < rank) {
            passed = false;
            break;
          }
        }
        if (passed) score[c] += PASSED[c === WHITE ? rank : 7 - rank];
      }
    }
  }

  if (f.rookFiles) {
    for (let c = 0; c < 2; c++) {
      for (const sq of rooks[c]) {
        const file = sq & 7;
        if (!pawnCnt[c][file]) score[c] += pawnCnt[c ^ 1][file] ? 10 : 20;
      }
    }
  }

  const diff = score[0] - score[1];
  return (bd.side === WHITE ? diff : -diff) + 8;
}

export const NON_PAWN_TYPES = [N, B, R, Q];
