import * as THREE from 'three';

export interface ProceduralTextureSet {
  roadAsphalt: THREE.CanvasTexture;
  sidewalkTile: THREE.CanvasTexture;
  buildingModern: THREE.CanvasTexture;
  buildingModernEmissive: THREE.CanvasTexture;
  buildingHeritage: THREE.CanvasTexture;
  buildingBazaar: THREE.CanvasTexture;
  truckArt: THREE.CanvasTexture;
  sandTexture: THREE.CanvasTexture;
  waterNormal: THREE.DataTexture;
  contactShadow: THREE.CanvasTexture;
  dashboardGauge: THREE.CanvasTexture;
  ajrakFabric: THREE.CanvasTexture;
  sindhiTopi: THREE.CanvasTexture;
  kurtaWeave: THREE.CanvasTexture;
  denimFabric: THREE.CanvasTexture;
  eyeIris: THREE.CanvasTexture;
  dispose: () => void;
}

function finalizeColorTex(
  canvas: HTMLCanvasElement,
  anisotropy: number,
  repeatX = 1,
  repeatY = 1
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = anisotropy;
  tex.needsUpdate = true;
  return tex;
}

export function createProceduralTextures(maxAnisotropy: number): ProceduralTextureSet {
  const aniso = Math.min(8, Math.max(1, maxAnisotropy));

  // 1. Asphalt Road Texture (with dashed lane divider & curb shoulders)
  const roadCanvas = document.createElement('canvas');
  roadCanvas.width = 512;
  roadCanvas.height = 512;
  const rctx = roadCanvas.getContext('2d')!;
  rctx.fillStyle = '#252930';
  rctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 4500; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const v = 30 + Math.floor(Math.random() * 24);
    rctx.fillStyle = `rgb(${v},${v + 2},${v + 5})`;
    rctx.fillRect(x, y, 2, 2);
  }
  // Yellow edge lines
  rctx.fillStyle = '#eab308';
  rctx.fillRect(14, 0, 6, 512);
  rctx.fillRect(492, 0, 6, 512);
  // White dashed center line
  rctx.fillStyle = '#f8fafc';
  for (let y = 16; y < 512; y += 64) {
    rctx.fillRect(252, y, 8, 36);
  }
  const roadAsphalt = finalizeColorTex(roadCanvas, aniso, 1, 8);

  // 2. Sidewalk / Marble Plaza Texture
  const swCanvas = document.createElement('canvas');
  swCanvas.width = 256;
  swCanvas.height = 256;
  const swctx = swCanvas.getContext('2d')!;
  swctx.fillStyle = '#9ca3af';
  swctx.fillRect(0, 0, 256, 256);
  swctx.strokeStyle = '#6b7280';
  swctx.lineWidth = 2;
  for (let x = 0; x <= 256; x += 64) {
    swctx.beginPath();
    swctx.moveTo(x, 0);
    swctx.lineTo(x, 256);
    swctx.stroke();
  }
  for (let y = 0; y <= 256; y += 64) {
    swctx.beginPath();
    swctx.moveTo(0, y);
    swctx.lineTo(256, y);
    swctx.stroke();
  }
  const sidewalkTile = finalizeColorTex(swCanvas, aniso, 12, 12);

  // 3. Modern Glass & Concrete Building Facade + Night Window Emissive
  const bmCanvas = document.createElement('canvas');
  bmCanvas.width = 512;
  bmCanvas.height = 512;
  const bmctx = bmCanvas.getContext('2d')!;
  bmctx.fillStyle = '#334155';
  bmctx.fillRect(0, 0, 512, 512);

  const bmeCanvas = document.createElement('canvas');
  bmeCanvas.width = 512;
  bmeCanvas.height = 512;
  const bmectx = bmeCanvas.getContext('2d')!;
  bmectx.fillStyle = '#000000';
  bmectx.fillRect(0, 0, 512, 512);

  for (let row = 0; row < 16; row++) {
    for (let col = 0; col < 8; col++) {
      const x = col * 64 + 8;
      const y = row * 32 + 6;
      const lit = Math.random() > 0.38;
      bmctx.fillStyle = lit ? '#bae6fd' : '#1e293b';
      bmctx.fillRect(x, y, 48, 20);
      if (lit) {
        bmectx.fillStyle = Math.random() > 0.3 ? '#fde68a' : '#7dd3fc';
        bmectx.fillRect(x + 2, y + 2, 44, 16);
      }
    }
  }
  const buildingModern = finalizeColorTex(bmCanvas, aniso, 1, 2);
  const buildingModernEmissive = finalizeColorTex(bmeCanvas, aniso, 1, 2);

  // 4. Heritage Sandstone (Saddar / Empress Market)
  const bhCanvas = document.createElement('canvas');
  bhCanvas.width = 256;
  bhCanvas.height = 256;
  const bhctx = bhCanvas.getContext('2d')!;
  bhctx.fillStyle = '#d6b48c';
  bhctx.fillRect(0, 0, 256, 256);
  for (let row = 0; row < 8; row++) {
    bhctx.fillStyle = row % 2 === 0 ? '#c49a6c' : '#dfc29d';
    bhctx.fillRect(0, row * 32, 256, 4);
    for (let col = 0; col < 4; col++) {
      bhctx.fillStyle = '#475569';
      bhctx.fillRect(col * 64 + 18, row * 32 + 8, 28, 20);
    }
  }
  const buildingHeritage = finalizeColorTex(bhCanvas, aniso, 1, 1);

  // 5. Bazaar / Burns Road / Lyari Colorful Facade
  const bbCanvas = document.createElement('canvas');
  bbCanvas.width = 256;
  bbCanvas.height = 256;
  const bbctx = bbCanvas.getContext('2d')!;
  bbctx.fillStyle = '#e5dccb';
  bbctx.fillRect(0, 0, 256, 256);
  for (let row = 0; row < 6; row++) {
    for (let col = 0; col < 4; col++) {
      const x = col * 64 + 10;
      const y = row * 42 + 8;
      bbctx.fillStyle = row === 5 ? '#0f766e' : '#334155';
      bbctx.fillRect(x, y, 44, 24);
      bbctx.fillStyle = '#f59e0b';
      bbctx.fillRect(x, y + 24, 44, 5);
    }
  }
  const buildingBazaar = finalizeColorTex(bbCanvas, aniso, 1, 1);

  // 6. Pakistani Truck & Bus Decorative Art Texture
  const taCanvas = document.createElement('canvas');
  taCanvas.width = 512;
  taCanvas.height = 256;
  const tactx = taCanvas.getContext('2d')!;
  tactx.fillStyle = '#0f766e';
  tactx.fillRect(0, 0, 512, 256);
  const stripeColors = ['#ec4899', '#f59e0b', '#22c55e', '#38bdf8', '#ef4444'];
  stripeColors.forEach((col, i) => {
    tactx.fillStyle = col;
    tactx.fillRect(0, i * 14, 512, 10);
    tactx.fillRect(0, 246 - i * 14, 512, 10);
  });
  // Floral medallions
  for (let cx = 64; cx < 512; cx += 96) {
    tactx.fillStyle = '#fef08a';
    tactx.beginPath();
    tactx.arc(cx, 128, 36, 0, Math.PI * 2);
    tactx.fill();
    tactx.fillStyle = '#dc2626';
    tactx.beginPath();
    tactx.arc(cx, 128, 22, 0, Math.PI * 2);
    tactx.fill();
    tactx.fillStyle = '#2563eb';
    tactx.beginPath();
    tactx.arc(cx, 128, 10, 0, Math.PI * 2);
    tactx.fill();
  }
  const truckArt = finalizeColorTex(taCanvas, aniso, 1, 1);

  // 7. Sea View Sand Texture
  const sandCanvas = document.createElement('canvas');
  sandCanvas.width = 256;
  sandCanvas.height = 256;
  const sctx = sandCanvas.getContext('2d')!;
  sctx.fillStyle = '#d9b982';
  sctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 3000; i++) {
    sctx.fillStyle = Math.random() > 0.5 ? '#c8a46b' : '#e7cca0';
    sctx.fillRect(Math.random() * 256, Math.random() * 256, 2, 2);
  }
  const sandTexture = finalizeColorTex(sandCanvas, aniso, 16, 4);

  // 8. Water Normal-ish Ripple Texture (DataTexture in linear space)
  const wSize = 128;
  const wData = new Uint8Array(wSize * wSize * 4);
  for (let y = 0; y < wSize; y++) {
    for (let x = 0; x < wSize; x++) {
      const idx = (y * wSize + x) * 4;
      const nx = Math.sin((x / wSize) * Math.PI * 6) * 0.5 + 0.5;
      const ny = Math.cos((y / wSize) * Math.PI * 6) * 0.5 + 0.5;
      wData[idx] = Math.floor(nx * 255);
      wData[idx + 1] = Math.floor(ny * 255);
      wData[idx + 2] = 235;
      wData[idx + 3] = 255;
    }
  }
  const waterNormal = new THREE.DataTexture(wData, wSize, wSize);
  waterNormal.wrapS = THREE.RepeatWrapping;
  waterNormal.wrapT = THREE.RepeatWrapping;
  waterNormal.repeat.set(18, 12);
  waterNormal.needsUpdate = true;

  // 9. Soft Radial Contact Shadow
  const csCanvas = document.createElement('canvas');
  csCanvas.width = 128;
  csCanvas.height = 128;
  const csctx = csCanvas.getContext('2d')!;
  const grad = csctx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0,0,0,0.72)');
  grad.addColorStop(0.55, 'rgba(0,0,0,0.28)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  csctx.fillStyle = grad;
  csctx.fillRect(0, 0, 128, 128);
  const contactShadow = new THREE.CanvasTexture(csCanvas);
  contactShadow.needsUpdate = true;

  // 10. Realistic Vehicle Interior Dashboard Gauge Texture
  const dbCanvas = document.createElement('canvas');
  dbCanvas.width = 256;
  dbCanvas.height = 128;
  const dbctx = dbCanvas.getContext('2d')!;
  dbctx.fillStyle = '#090d16';
  dbctx.fillRect(0, 0, 256, 128);
  // Speedometer & Tachometer rings
  [70, 186].forEach((cx, i) => {
    dbctx.strokeStyle = i === 0 ? '#38bdf8' : '#f43f5e';
    dbctx.lineWidth = 4;
    dbctx.beginPath();
    dbctx.arc(cx, 64, 42, Math.PI * 0.75, Math.PI * 2.25);
    dbctx.stroke();
    dbctx.fillStyle = '#e2e8f0';
    dbctx.font = 'bold 14px monospace';
    dbctx.textAlign = 'center';
    dbctx.fillText(i === 0 ? 'KM/H' : 'RPM', cx, 96);
  });
  dbctx.fillStyle = '#22c55e';
  dbctx.fillRect(112, 30, 32, 18);
  const dashboardGauge = finalizeColorTex(dbCanvas, aniso, 1, 1);

  // 11. Authentic Sindhi Ajrak Block Print Texture
  const ajCanvas = document.createElement('canvas');
  ajCanvas.width = 256;
  ajCanvas.height = 256;
  const ajctx = ajCanvas.getContext('2d')!;
  ajctx.fillStyle = '#991b1b';
  ajctx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 32) {
    for (let x = 0; x < 256; x += 32) {
      ajctx.fillStyle = '#1e1b4b';
      ajctx.beginPath();
      ajctx.moveTo(x + 16, y + 2);
      ajctx.lineTo(x + 30, y + 16);
      ajctx.lineTo(x + 16, y + 30);
      ajctx.lineTo(x + 2, y + 16);
      ajctx.closePath();
      ajctx.fill();
      ajctx.strokeStyle = '#f8fafc';
      ajctx.lineWidth = 2;
      ajctx.stroke();
      ajctx.fillStyle = '#f8fafc';
      ajctx.beginPath();
      ajctx.arc(x + 16, y + 16, 4, 0, Math.PI * 2);
      ajctx.fill();
    }
  }
  const ajrakFabric = finalizeColorTex(ajCanvas, aniso, 2, 2);

  // 12. Embroidered Sindhi Topi Pattern Texture
  const tpCanvas = document.createElement('canvas');
  tpCanvas.width = 256;
  tpCanvas.height = 128;
  const tpctx = tpCanvas.getContext('2d')!;
  tpctx.fillStyle = '#7f1d1d';
  tpctx.fillRect(0, 0, 256, 128);
  tpctx.fillStyle = '#fbbf24';
  tpctx.fillRect(0, 14, 256, 8);
  tpctx.fillRect(0, 106, 256, 8);
  for (let x = 16; x < 256; x += 32) {
    tpctx.fillStyle = '#0ea5e9';
    tpctx.beginPath();
    tpctx.arc(x, 64, 12, 0, Math.PI * 2);
    tpctx.fill();
    tpctx.fillStyle = '#f8fafc';
    tpctx.beginPath();
    tpctx.arc(x, 64, 5, 0, Math.PI * 2);
    tpctx.fill();
  }
  const sindhiTopi = finalizeColorTex(tpCanvas, aniso, 2, 1);

  // 13. Cotton Kurta & Denim Fabric Weaves
  const kwCanvas = document.createElement('canvas');
  kwCanvas.width = 128;
  kwCanvas.height = 128;
  const kwctx = kwCanvas.getContext('2d')!;
  kwctx.fillStyle = '#f8fafc';
  kwctx.fillRect(0, 0, 128, 128);
  kwctx.fillStyle = 'rgba(15,23,42,0.06)';
  for (let i = 0; i < 128; i += 4) {
    kwctx.fillRect(i, 0, 1, 128);
    kwctx.fillRect(0, i, 128, 1);
  }
  const kurtaWeave = finalizeColorTex(kwCanvas, aniso, 4, 4);

  const dnCanvas = document.createElement('canvas');
  dnCanvas.width = 128;
  dnCanvas.height = 128;
  const dnctx = dnCanvas.getContext('2d')!;
  dnctx.fillStyle = '#e2e8f0';
  dnctx.fillRect(0, 0, 128, 128);
  dnctx.strokeStyle = 'rgba(15,23,42,0.14)';
  dnctx.lineWidth = 1;
  for (let i = -128; i < 256; i += 4) {
    dnctx.beginPath();
    dnctx.moveTo(i, 0);
    dnctx.lineTo(i + 128, 128);
    dnctx.stroke();
  }
  const denimFabric = finalizeColorTex(dnCanvas, aniso, 4, 4);

  // 14. Realistic Human Eye (Sclera + Brown Iris + Pupil + Specular Highlight)
  const eyeCanvas = document.createElement('canvas');
  eyeCanvas.width = 128;
  eyeCanvas.height = 128;
  const ectx = eyeCanvas.getContext('2d')!;
  ectx.fillStyle = '#f8fafc';
  ectx.fillRect(0, 0, 128, 128);
  const irisGrad = ectx.createRadialGradient(64, 64, 8, 64, 64, 34);
  irisGrad.addColorStop(0, '#1e1b18');
  irisGrad.addColorStop(0.55, '#4a2c16');
  irisGrad.addColorStop(0.9, '#2b190d');
  irisGrad.addColorStop(1, '#111827');
  ectx.fillStyle = irisGrad;
  ectx.beginPath();
  ectx.arc(64, 64, 34, 0, Math.PI * 2);
  ectx.fill();
  ectx.fillStyle = '#050505';
  ectx.beginPath();
  ectx.arc(64, 64, 15, 0, Math.PI * 2);
  ectx.fill();
  ectx.fillStyle = '#ffffff';
  ectx.beginPath();
  ectx.arc(52, 52, 6, 0, Math.PI * 2);
  ectx.fill();
  const eyeIris = finalizeColorTex(eyeCanvas, aniso, 1, 1);

  return {
    roadAsphalt,
    sidewalkTile,
    buildingModern,
    buildingModernEmissive,
    buildingHeritage,
    buildingBazaar,
    truckArt,
    sandTexture,
    waterNormal,
    contactShadow,
    dashboardGauge,
    ajrakFabric,
    sindhiTopi,
    kurtaWeave,
    denimFabric,
    eyeIris,
    dispose: () => {
      roadAsphalt.dispose();
      sidewalkTile.dispose();
      buildingModern.dispose();
      buildingModernEmissive.dispose();
      buildingHeritage.dispose();
      buildingBazaar.dispose();
      truckArt.dispose();
      sandTexture.dispose();
      waterNormal.dispose();
      contactShadow.dispose();
      dashboardGauge.dispose();
      ajrakFabric.dispose();
      sindhiTopi.dispose();
      kurtaWeave.dispose();
      denimFabric.dispose();
      eyeIris.dispose();
    },
  };
}
