import * as THREE from 'three';
import { MakeupStyle } from '../types/game';

export type ResolvedFaceMood =
  | 'neutral'
  | 'happy'
  | 'cool'
  | 'angry'
  | 'surprised'
  | 'wink'
  | 'heart_eyes'
  | 'sleepy';

export function createStudTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#f1f5f9';
  ctx.fillRect(0, 0, size, size);

  ctx.strokeStyle = 'rgba(15, 23, 42, 0.14)';
  ctx.lineWidth = 4;
  ctx.strokeRect(2, 2, size - 4, size - 4);

  const offsets = [32, 96];
  for (const cx of offsets) {
    for (const cy of offsets) {
      ctx.beginPath();
      ctx.arc(cx + 1.5, cy + 2, 18, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.22)';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(cx, cy, 18, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(cx, cy, 14, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createCheckerTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const step = 32;
  for (let y = 0; y < size; y += step) {
    for (let x = 0; x < size; x += step) {
      const dark = ((x + y) / step) % 2 === 0;
      ctx.fillStyle = dark ? '#0f172a' : '#f8fafc';
      ctx.fillRect(x, y, step, step);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createLavaTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createLinearGradient(0, 0, size, size);
  grad.addColorStop(0, '#ea580c');
  grad.addColorStop(0.5, '#dc2626');
  grad.addColorStop(1, '#f97316');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 42; i++) {
    const x = (i * 73) % size;
    const y = (i * 137) % size;
    const r = 12 + (i % 4) * 7;
    const cellGrad = ctx.createRadialGradient(x, y, 2, x, y, r);
    cellGrad.addColorStop(0, '#fde047');
    cellGrad.addColorStop(0.5, '#f97316');
    cellGrad.addColorStop(1, 'rgba(185, 28, 28, 0)');
    ctx.fillStyle = cellGrad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(16, 16);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createFaceTexture(
  makeup: MakeupStyle = 'none',
  mood: ResolvedFaceMood = 'neutral',
  blink = false
): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, size, size);

  if (makeup === 'goth') {
    ctx.fillStyle = 'rgba(24, 24, 27, 0.72)';
    ctx.fillRect(58, 64, 52, 66);
    ctx.fillRect(146, 64, 52, 66);
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(68, 74);
    ctx.lineTo(44, 62);
    ctx.moveTo(188, 74);
    ctx.lineTo(212, 62);
    ctx.stroke();
  }

  const drawHeart = (cx: number, cy: number, s: number, color: string) => {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(cx, cy + s * 0.65);
    ctx.bezierCurveTo(cx - s * 1.15, cy - s * 0.1, cx - s * 0.55, cy - s * 1.0, cx, cy - s * 0.3);
    ctx.bezierCurveTo(cx + s * 0.55, cy - s * 1.0, cx + s * 1.15, cy - s * 0.1, cx, cy + s * 0.65);
    ctx.fill();
  };

  // Eyes layer based on mood & blink
  if (mood === 'cool') {
    // Sleek blocky sunglasses
    ctx.fillStyle = '#09090b';
    ctx.fillRect(46, 70, 72, 46);
    ctx.fillRect(138, 70, 72, 46);
    ctx.fillRect(114, 82, 28, 12);
    ctx.fillStyle = 'rgba(255,255,255,0.28)';
    ctx.fillRect(54, 76, 20, 8);
    ctx.fillRect(146, 76, 20, 8);
  } else if (blink) {
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(66, 102);
    ctx.lineTo(104, 102);
    ctx.moveTo(152, 102);
    ctx.lineTo(190, 102);
    ctx.stroke();
  } else if (mood === 'heart_eyes') {
    drawHeart(85, 98, 28, '#e11d48');
    drawHeart(171, 98, 28, '#e11d48');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(73, 86, 7, 7);
    ctx.fillRect(159, 86, 7, 7);
  } else if (mood === 'happy') {
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 9;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(85, 110, 20, Math.PI * 1.12, Math.PI * 1.88);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(171, 110, 20, Math.PI * 1.12, Math.PI * 1.88);
    ctx.stroke();
  } else if (mood === 'sleepy') {
    // Half-closed sleepy eyes
    ctx.fillStyle = '#09090b';
    ctx.fillRect(66, 98, 36, 18);
    ctx.fillRect(154, 98, 36, 18);
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(64, 90);
    ctx.lineTo(104, 94);
    ctx.moveTo(192, 90);
    ctx.lineTo(152, 94);
    ctx.stroke();
  } else if (mood === 'wink') {
    // Left eye open, right eye winking
    ctx.fillStyle = '#09090b';
    ctx.fillRect(68, 72, 34, 54);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(74, 80, 10, 12);
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(150, 88);
    ctx.lineTo(184, 102);
    ctx.lineTo(150, 116);
    ctx.stroke();
  } else if (mood === 'surprised') {
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(85, 98, 22, 0, Math.PI * 2);
    ctx.arc(171, 98, 22, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 5;
    ctx.stroke();
    ctx.fillStyle = '#09090b';
    ctx.beginPath();
    ctx.arc(85, 98, 11, 0, Math.PI * 2);
    ctx.arc(171, 98, 11, 0, Math.PI * 2);
    ctx.fill();
    // Raised eyebrows
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(85, 72, 18, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(171, 72, 18, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();
  } else if (mood === 'angry') {
    ctx.fillStyle = '#09090b';
    ctx.fillRect(68, 78, 34, 46);
    ctx.fillRect(154, 78, 34, 46);
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(78, 92, 12, 12);
    ctx.fillRect(166, 92, 12, 12);
    // Angry slanted brows
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(62, 62);
    ctx.lineTo(106, 78);
    ctx.moveTo(194, 62);
    ctx.lineTo(150, 78);
    ctx.stroke();
  } else {
    // Classic neutral blocky eyes
    ctx.fillStyle = '#09090b';
    ctx.fillRect(68, 72, 34, 54);
    ctx.fillRect(154, 72, 34, 54);
  }

  // Eye sparkles for blush / kawaii / stars when eyes are normal blocky
  if (
    !blink &&
    (mood === 'neutral' || mood === 'angry') &&
    (makeup === 'blush' || makeup === 'kawaii' || makeup === 'stars')
  ) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(74, 80, 11, 13);
    ctx.fillRect(160, 80, 11, 13);
    ctx.fillRect(88, 108, 6, 6);
    ctx.fillRect(174, 108, 6, 6);
  }

  // Eyelashes for lipstick / kawaii
  if (!blink && mood !== 'cool' && (makeup === 'lipstick' || makeup === 'kawaii')) {
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(68, 74);
    ctx.lineTo(52, 66);
    ctx.moveTo(188, 74);
    ctx.lineTo(204, 66);
    ctx.stroke();
  }

  // Cheek Blush
  if (makeup === 'blush' || makeup === 'kawaii' || makeup === 'lipstick') {
    ctx.fillStyle = makeup === 'kawaii' ? 'rgba(244, 114, 182, 0.72)' : 'rgba(251, 113, 133, 0.65)';
    ctx.beginPath();
    ctx.ellipse(54, 150, 22, 12, 0, 0, Math.PI * 2);
    ctx.ellipse(202, 150, 22, 12, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Star cheek stickers
  if (makeup === 'stars') {
    const drawStar = (cx: number, cy: number, r: number, color: string) => {
      ctx.fillStyle = color;
      ctx.beginPath();
      for (let i = 0; i < 10; i++) {
        const rad = i % 2 === 0 ? r : r * 0.45;
        const ang = (Math.PI / 5) * i - Math.PI / 2;
        const x = cx + Math.cos(ang) * rad;
        const y = cy + Math.sin(ang) * rad;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
    };
    drawStar(54, 150, 16, '#facc15');
    drawStar(202, 150, 16, '#facc15');
    drawStar(54, 150, 7, '#ffffff');
    drawStar(202, 150, 7, '#ffffff');
  }

  // Mouth layer combining mood & makeup
  if (mood === 'surprised') {
    ctx.fillStyle = '#09090b';
    ctx.beginPath();
    ctx.ellipse(128, 178, 16, 20, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.ellipse(128, 184, 9, 8, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (mood === 'angry') {
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 7;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(128, 196, 22, Math.PI * 1.18, Math.PI * 1.82);
    ctx.stroke();
  } else if (mood === 'sleepy') {
    ctx.fillStyle = '#09090b';
    ctx.beginPath();
    ctx.ellipse(128, 178, 10, 11, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (mood === 'happy' || mood === 'heart_eyes') {
    ctx.fillStyle = '#09090b';
    ctx.beginPath();
    ctx.arc(128, 164, 28, 0, Math.PI);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(106, 166, 44, 8);
    ctx.fillStyle = '#fb7185';
    ctx.beginPath();
    ctx.ellipse(128, 186, 12, 6, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (mood === 'cool' || mood === 'wink') {
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 7;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(106, 176);
    ctx.quadraticCurveTo(132, 188, 152, 166);
    ctx.stroke();
  } else if (makeup === 'lipstick') {
    ctx.fillStyle = '#e11d48';
    ctx.beginPath();
    ctx.ellipse(128, 178, 28, 11, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.beginPath();
    ctx.ellipse(122, 175, 10, 3, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (makeup === 'goth') {
    ctx.fillStyle = '#3b0764';
    ctx.beginPath();
    ctx.ellipse(128, 178, 26, 9, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (makeup === 'kawaii' || makeup === 'stars') {
    ctx.strokeStyle = '#09090b';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(128, 166, 20, 0.25 * Math.PI, 0.75 * Math.PI);
    ctx.stroke();
    if (makeup === 'kawaii') {
      ctx.fillStyle = '#f43f5e';
      ctx.beginPath();
      ctx.arc(128, 184, 7, 0, Math.PI);
      ctx.fill();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createShirtEmblemTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, size, size);

  // Subtle Pickare pocket emblem
  ctx.save();
  ctx.translate(128, 128);
  ctx.rotate(-0.12);
  ctx.strokeStyle = 'rgba(255,255,255,0.35)';
  ctx.lineWidth = 10;
  ctx.strokeRect(-30, -30, 60, 60);
  ctx.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
