import * as THREE from 'three'
import { GLTFLoader, type GLTF } from 'three/examples/jsm/loaders/GLTFLoader.js'
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js'

/**
 * Cached asset loading with real download progress for the boot screen.
 *
 * Models are Meshopt-compressed GLB files; the decoder is registered once on the loader.
 * Runtime media is addressed by its stable `/manus-storage/...` path (see `src/game/assetTable.ts`).
 */
export class Assets {
  private readonly manager = new THREE.LoadingManager()
  private readonly gltfLoader = new GLTFLoader(this.manager).setMeshoptDecoder(MeshoptDecoder)
  private readonly cache = new Map<string, Promise<unknown>>()

  /** Load a GLB, reporting download progress 0..1. Failed loads are not cached so Retry works. */
  gltf(url: string, onProgress?: (fraction: number) => void): Promise<GLTF> {
    return this.memo(url, async () => {
      const response = await fetch(url)
      if (!response.ok) throw new Error(`HTTP ${response.status} ${url}`)
      const total = Number(response.headers.get('content-length')) || 0
      const reader = response.body?.getReader()
      let buffer: ArrayBuffer
      if (reader) {
        const chunks: Uint8Array[] = []
        let received = 0
        for (;;) {
          const { done, value } = await reader.read()
          if (done) break
          chunks.push(value)
          received += value.length
          if (total > 0) onProgress?.(Math.min(1, received / total))
        }
        const merged = new Uint8Array(received)
        let offset = 0
        for (const c of chunks) {
          merged.set(c, offset)
          offset += c.length
        }
        buffer = merged.buffer
      } else {
        buffer = await response.arrayBuffer()
      }
      onProgress?.(1)
      return this.gltfLoader.parseAsync(buffer, url.slice(0, url.lastIndexOf('/') + 1))
    })
  }

  private memo<T>(key: string, load: () => Promise<T>): Promise<T> {
    let pending = this.cache.get(key) as Promise<T> | undefined
    if (!pending) {
      pending = load()
      this.cache.set(key, pending)
      pending.catch(() => this.cache.delete(key))
    }
    return pending
  }
}
