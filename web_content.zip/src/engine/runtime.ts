import { EngineAudio } from "./audio";
import { EngineScene } from "./scene";
import { curve } from "./spec";
import { ignite, step, tryShift } from "./sim";
import { createLive, type Live, type Spec } from "./types";

export type RuntimeHooks = {
  onDead: (dead: boolean) => void;
  onGear: (gear: number) => void;
};

export class Runtime {
  readonly live: Live = createLive();
  spec: Spec;
  readonly scene: EngineScene;
  readonly audio: EngineAudio;
  private raf = 0;
  private last = 0;
  private acc = 0;
  private hooks: RuntimeHooks;
  private onKeyDown: (e: KeyboardEvent) => void;
  private onKeyUp: (e: KeyboardEvent) => void;
  private onBlur: () => void;

  constructor(canvas: HTMLCanvasElement, spec: Spec, hooks: RuntimeHooks) {
    this.spec = spec;
    this.hooks = hooks;
    this.scene = new EngineScene(canvas);
    this.audio = new EngineAudio(
      () => this.spec,
      () => this.live,
    );
    this.scene.rebuild(spec);
    this.scene.resize();
    this.onKeyDown = (e) => this.keyDown(e);
    this.onKeyUp = (e) => this.keyUp(e);
    this.onBlur = () => this.release();
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
  }

  start() {
    this.last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - this.last) / 1000);
      this.last = now;
      this.acc += dt;
      const h = 1 / 60;
      let n = 0;
      while (this.acc >= h && n < 4) {
        step(this.live, this.spec, h, {
          blow: () => this.onBlow(),
          limit: () => this.onLimit(),
        });
        this.acc -= h;
        n++;
      }
      this.crackle(dt);
      this.audio.update(dt);
      this.scene.advance(dt, this.live, this.spec);
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  stop() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
  }

  resize() {
    this.scene.resize();
  }

  setSpec(spec: Spec) {
    this.spec = spec;
    if (this.live.dead) {
      this.live.dead = false;
      this.live.deadT = 0;
      this.live.stopT = 0;
      this.live.stall = true;
      this.live.rpm = 0;
      this.live.crank = 0;
      this.live.pedal = 0;
      this.live.thr = 0;
      this.live.gear = 0;
      this.hooks.onDead(false);
      this.hooks.onGear(0);
    }
    this.scene.rebuild(spec);
  }

  repair() {
    this.live.dead = false;
    this.live.deadT = 0;
    this.live.stopT = 0;
    this.live.stall = true;
    this.live.rpm = 0;
    this.live.crank = 0;
    this.live.pedal = 0;
    this.live.thr = 0;
    this.live.gear = 0;
    this.live.cut = false;
    this.hooks.onDead(false);
    this.hooks.onGear(0);
    this.scene.rebuild(this.spec);
  }

  shift(g: number) {
    const res = tryShift(this.live, g);
    if (res.grind) this.audio.grind();
    this.hooks.onGear(this.live.gear);
    return this.live.gear;
  }

  ignition() {
    const res = ignite(this.live);
    if (res === "crank") this.audio.starter();
  }

  private onBlow() {
    this.scene.blow();
    this.audio.boom();
    this.hooks.onDead(true);
  }

  private onLimit() {
    const spec = this.spec;
    const live = this.live;
    if (live.dead || !spec.pop || spec.fuel === "dsl" || spec.exh === "stock") return;
    this.scene.flame();
    const n = (spec.exh === "open" ? 3 : spec.exh === "straight" ? 2 : 1) + Math.floor(Math.random() * 2);
    for (let i = 0; i < n; i++) this.audio.pop(i * 0.025 + Math.random() * 0.02);
  }

  private crackle(dt: number) {
    const spec = this.spec;
    const live = this.live;
    if (live.dead || !spec.pop || spec.fuel === "dsl" || spec.exh === "stock") return;
    if (live.thr > 0.15 || live.rpm < 2500 || live.stall) return;
    const rate = ({ sport: 4, straight: 7, open: 10 } as const)[spec.exh] * (live.rpm / curve(spec).red);
    if (Math.random() < dt * rate) {
      this.scene.flame();
      this.audio.pop();
    }
  }

  private typingTarget(e: KeyboardEvent) {
    const tag = (e.target as HTMLElement | null)?.tagName;
    return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";
  }

  private keyDown(e: KeyboardEvent) {
    if (e.repeat || this.typingTarget(e)) return;
    const c = e.code;
    if (c === "KeyC" || c === "ShiftLeft" || c === "ShiftRight") this.live.cin = 1;
    if (c === "KeyB" || c === "ArrowDown") {
      this.live.brk = 1;
      e.preventDefault();
    }
    if (c === "Space" || c === "ArrowUp") {
      this.live.pedal = 1;
      e.preventDefault();
    }
    if (c === "KeyE") this.shift(Math.min(6, this.live.gear + 1));
    if (c === "KeyQ") this.shift(Math.max(0, this.live.gear - 1));
    if (c === "KeyK") this.ignition();
  }

  private keyUp(e: KeyboardEvent) {
    const c = e.code;
    if (c === "KeyC" || c === "ShiftLeft" || c === "ShiftRight") this.live.cin = 0;
    if (c === "KeyB" || c === "ArrowDown") this.live.brk = 0;
    if (c === "Space" || c === "ArrowUp") this.live.pedal = 0;
  }

  private release() {
    this.live.cin = 0;
    this.live.brk = 0;
    this.live.pedal = 0;
  }
}
