import {
  ALL_TRAITS,
  AVG_LIFESPAN_SEC,
  BODY_TYPES,
  COATS,
  DINGO_NAME_POOL,
  PATTERNS,
  PUP_ADULT_AGE_SEC,
  TRAIT_CONFLICTS,
} from '../data/kennelConstants';
import {
  BodyType,
  CoatColor,
  Dog,
  DogGenetics,
  DogGender,
  DogSkills,
  DogStats,
  FurPattern,
  HabitatLocationId,
  UniqueTrait,
} from '../types/kennel';

const COAT_DOMINANCE: Record<CoatColor, number> = {
  black: 4,
  fawn: 3,
  gray: 2,
  white: 1,
};

const PATTERN_DOMINANCE: Record<FurPattern, number> = {
  striped: 4,
  'black piebald': 3,
  'black spots': 2,
  patternless: 1,
};

const BODY_DOMINANCE: Record<BodyType, number> = {
  medium: 3,
  slender: 2,
  chubby: 1,
};

export function clamp(val: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, val));
}

export function randRange(min: number, max: number): number {
  return min + Math.random() * (max - min);
}

export function randInt(min: number, max: number): number {
  return Math.floor(randRange(min, max + 1));
}

export function pickOne<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function makeId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export function pickTraits(count: number, inheritedPool?: UniqueTrait[]): UniqueTrait[] {
  const chosen: UniqueTrait[] = [];
  const pool = [...ALL_TRAITS];

  if (inheritedPool && inheritedPool.length > 0) {
    for (const t of inheritedPool) {
      if (chosen.length >= count) break;
      if (Math.random() < 0.6 && !hasTraitConflict(chosen, t)) {
        chosen.push(t);
      }
    }
  }

  let guard = 0;
  while (chosen.length < count && guard < 40) {
    guard++;
    const candidate = pickOne(pool);
    if (!chosen.includes(candidate) && !hasTraitConflict(chosen, candidate)) {
      chosen.push(candidate);
    }
  }
  return chosen;
}

function hasTraitConflict(existing: UniqueTrait[], candidate: UniqueTrait): boolean {
  const conflicts = TRAIT_CONFLICTS[candidate] ?? [];
  return existing.some((t) => conflicts.includes(t));
}

function expressCoat(a: CoatColor, b: CoatColor): CoatColor {
  return COAT_DOMINANCE[a] >= COAT_DOMINANCE[b] ? a : b;
}

function expressPattern(a: FurPattern, b: FurPattern): FurPattern {
  return PATTERN_DOMINANCE[a] >= PATTERN_DOMINANCE[b] ? a : b;
}

function expressBody(a: BodyType, b: BodyType): BodyType {
  if ((a === 'slender' && b === 'chubby') || (a === 'chubby' && b === 'slender')) {
    return 'medium';
  }
  return BODY_DOMINANCE[a] >= BODY_DOMINANCE[b] ? a : b;
}

export function createRandomGenetics(): DogGenetics {
  const c1 = pickOne(COATS);
  const c2 = Math.random() < 0.45 ? c1 : pickOne(COATS);
  const p1 = pickOne(PATTERNS);
  const p2 = Math.random() < 0.45 ? p1 : pickOne(PATTERNS);
  const b1 = pickOne(BODY_TYPES);
  const b2 = Math.random() < 0.45 ? b1 : pickOne(BODY_TYPES);

  return {
    coat: expressCoat(c1, c2),
    bodyType: expressBody(b1, b2),
    pattern: expressPattern(p1, p2),
    coatAlleles: [c1, c2],
    patternAlleles: [p1, p2],
    bodyAlleles: [b1, b2],
    patternSeed: randInt(1000, 999999),
  };
}

export function inheritGenetics(mother: Dog, father: Dog): DogGenetics {
  const mCoat = pickOne(mother.genetics.coatAlleles);
  const fCoat = pickOne(father.genetics.coatAlleles);
  const coatAlleles: [CoatColor, CoatColor] = [
    Math.random() < 0.04 ? pickOne(COATS) : mCoat,
    Math.random() < 0.04 ? pickOne(COATS) : fCoat,
  ];

  const mPat = pickOne(mother.genetics.patternAlleles);
  const fPat = pickOne(father.genetics.patternAlleles);
  const patternAlleles: [FurPattern, FurPattern] = [
    Math.random() < 0.05 ? pickOne(PATTERNS) : mPat,
    Math.random() < 0.05 ? pickOne(PATTERNS) : fPat,
  ];

  const mBody = pickOne(mother.genetics.bodyAlleles);
  const fBody = pickOne(father.genetics.bodyAlleles);
  const bodyAlleles: [BodyType, BodyType] = [
    Math.random() < 0.04 ? pickOne(BODY_TYPES) : mBody,
    Math.random() < 0.04 ? pickOne(BODY_TYPES) : fBody,
  ];

  return {
    coat: expressCoat(coatAlleles[0], coatAlleles[1]),
    bodyType: expressBody(bodyAlleles[0], bodyAlleles[1]),
    pattern: expressPattern(patternAlleles[0], patternAlleles[1]),
    coatAlleles,
    patternAlleles,
    bodyAlleles,
    patternSeed: randInt(1000, 999999),
  };
}

export function calculateLitterSize(mother: Dog): number {
  // Mother age: adults are 3600s..~21600s. Prime fertility age is 5000s..15000s
  const ageFactor =
    mother.ageSeconds < 5000
      ? 0.72
      : mother.ageSeconds < 14500
      ? 1.0
      : mother.ageSeconds < 18500
      ? 0.7
      : 0.45;
  const fertFactor = clamp(mother.stats.fertility, 20, 100) / 100;
  const expected = 1 + ageFactor * fertFactor * 5.6 + randRange(-0.9, 1.4);
  return Math.max(1, Math.min(8, Math.round(expected)));
}

export function generateRandomDog(options: {
  location: HabitatLocationId;
  origin: 'market' | 'starter';
  forceAdult?: boolean;
  forceGender?: DogGender;
  existingNames?: string[];
}): Dog {
  const gender: DogGender = options.forceGender ?? (Math.random() < 0.5 ? 'female' : 'male');
  const isPup = options.forceAdult ? false : Math.random() < 0.16;
  const ageSeconds = isPup
    ? randInt(600, PUP_ADULT_AGE_SEC - 400)
    : randInt(PUP_ADULT_AGE_SEC + 300, Math.floor(AVG_LIFESPAN_SEC * 0.65));
  const lifespanSeconds = randInt(AVG_LIFESPAN_SEC - 1800, AVG_LIFESPAN_SEC + 2200);

  const traits = pickTraits(randInt(2, 4));
  const genetics = createRandomGenetics();

  const stats: DogStats = {
    health: randInt(76, 98),
    dominance: randInt(20, 88),
    energy: isPup ? randInt(48, 76) : randInt(55, 95),
    intelligence: randInt(28, 92),
    hunger: randInt(12, 42),
    matingDrive: isPup ? 0 : randInt(18, 72),
    thirst: randInt(10, 38),
    playfulness: traits.includes('playful') ? randInt(68, 96) : randInt(24, 78),
    aggression: traits.includes('reactive') ? randInt(48, 86) : randInt(12, 62),
    mood: traits.includes('calm') ? randInt(62, 90) : randInt(44, 82),
    fertility: isPup ? 0 : gender === 'female' ? randInt(45, 96) : randInt(65, 95),
    stress: traits.includes('calm') ? randInt(6, 26) : randInt(14, 48),
  };

  if (traits.includes('lazy')) stats.energy = Math.min(stats.energy, 62);
  if (traits.includes('active')) stats.energy = Math.max(stats.energy, 70);

  const skills: DogSkills = {
    foraging: randInt(18, 88),
    tracking: randInt(18, 88),
    agility: genetics.bodyType === 'slender' ? randInt(52, 95) : randInt(24, 82),
    watchfulness: randInt(22, 90),
    socialGrace: traits.includes('solitary') ? randInt(12, 54) : randInt(32, 90),
  };

  const taken = new Set(options.existingNames ?? []);
  const availableNames = DINGO_NAME_POOL.filter((n) => !taken.has(n));
  const name = availableNames.length > 0 ? pickOne(availableNames) : `Dingo-${randInt(10, 99)}`;

  const likesHumans = traits.includes('likes humans');
  const dislikesHumans = traits.includes('dislikes humans');

  return {
    id: makeId('dog'),
    name,
    gender,
    ageSeconds,
    lifespanSeconds,
    genetics,
    stats,
    skills,
    traits,
    discoveredTraits: options.origin === 'starter' ? [traits[0]] : [],
    location: options.location,
    playerRel: {
      trust: likesHumans ? randInt(42, 65) : dislikesHumans ? randInt(8, 26) : randInt(22, 46),
      curiosity: randInt(28, 72),
      fear: dislikesHumans ? randInt(34, 66) : likesHumans ? randInt(6, 24) : randInt(16, 42),
      anger: dislikesHumans ? randInt(14, 38) : randInt(4, 20),
      stress: randInt(10, 34),
      interactionCount: 0,
    },
    pairRelations: {},
    fertilityCooldownSec: 0,
    pregnantRemainingSec: null,
    litterSireId: null,
    motherId: null,
    fatherId: null,
    generation: 1,
    currentBehavior: isPup ? 'curled quietly in the straw' : 'scanning the kennel mesh',
    lastActivitySimSec: 0,
    lastTensionSimSec: -999,
    notes: '',
    origin: options.origin,
  };
}

export function createBredPup(mother: Dog, father: Dog, existingNames: string[]): Dog {
  const gender: DogGender = Math.random() < 0.5 ? 'female' : 'male';
  const genetics = inheritGenetics(mother, father);
  const parentTraitPool = [...mother.traits, ...father.traits];
  const traits = pickTraits(randInt(2, 4), parentTraitPool);

  const avgStat = (a: number, b: number, jitter = 14) =>
    clamp(Math.round((a + b) / 2 + randRange(-jitter, jitter)), 10, 95);

  const taken = new Set(existingNames);
  const availableNames = DINGO_NAME_POOL.filter((n) => !taken.has(n));
  const name = availableNames.length > 0 ? pickOne(availableNames) : `Pup-${randInt(100, 999)}`;

  return {
    id: makeId('dog'),
    name,
    gender,
    ageSeconds: 0,
    lifespanSeconds: randInt(AVG_LIFESPAN_SEC - 1600, AVG_LIFESPAN_SEC + 2200),
    genetics,
    stats: {
      health: randInt(86, 98),
      dominance: avgStat(mother.stats.dominance, father.stats.dominance),
      energy: randInt(45, 72), // pups have less energy
      intelligence: avgStat(mother.stats.intelligence, father.stats.intelligence),
      hunger: randInt(15, 32),
      matingDrive: 0,
      thirst: randInt(10, 26),
      playfulness: clamp(avgStat(mother.stats.playfulness, father.stats.playfulness) + 16),
      aggression: clamp(avgStat(mother.stats.aggression, father.stats.aggression) - 10),
      mood: randInt(72, 92),
      fertility: 0,
      stress: randInt(6, 20),
    },
    skills: {
      foraging: avgStat(mother.skills.foraging, father.skills.foraging, 12),
      tracking: avgStat(mother.skills.tracking, father.skills.tracking, 12),
      agility: avgStat(mother.skills.agility, father.skills.agility, 12),
      watchfulness: avgStat(mother.skills.watchfulness, father.skills.watchfulness, 12),
      socialGrace: clamp(avgStat(mother.skills.socialGrace, father.skills.socialGrace, 12) + 8),
    },
    traits,
    discoveredTraits: [],
    location: 'nursery_pen',
    playerRel: {
      trust: traits.includes('likes humans') ? 45 : 30,
      curiosity: 65,
      fear: traits.includes('dislikes humans') ? 38 : 18,
      anger: 4,
      stress: 12,
      interactionCount: 0,
    },
    pairRelations: {
      [mother.id]: { affinity: 68, tension: 0, isAlly: true, lastUpdatedSimSec: 0 },
    },
    fertilityCooldownSec: 0,
    pregnantRemainingSec: null,
    litterSireId: null,
    motherId: mother.id,
    fatherId: father.id,
    generation: Math.max(mother.generation, father.generation) + 1,
    currentBehavior: 'blinking softly in the warm nursery straw',
    lastActivitySimSec: 0,
    lastTensionSimSec: -999,
    notes: `Born to ${mother.name} × ${father.name}.`,
    origin: 'bred',
  };
}

export function calculateAttributeCompatibility(a: Dog, b: Dog): number {
  // Returns 0..1 compatibility score (higher = more alike & harmonious)
  let score = 0.55;

  const sharedTraits = a.traits.filter((t) => b.traits.includes(t)).length;
  score += sharedTraits * 0.14;

  // Conflicting temperament penalties
  if (a.traits.includes('dislikes females') && b.gender === 'female') score -= 0.34;
  if (a.traits.includes('dislikes males') && b.gender === 'male') score -= 0.34;
  if (b.traits.includes('dislikes females') && a.gender === 'female') score -= 0.34;
  if (b.traits.includes('dislikes males') && a.gender === 'male') score -= 0.34;

  if (a.traits.includes('solitary')) score -= 0.14;
  if (b.traits.includes('solitary')) score -= 0.14;

  const aggDiff = Math.abs(a.stats.aggression - b.stats.aggression) / 100;
  const playDiff = Math.abs(a.stats.playfulness - b.stats.playfulness) / 100;
  const domClash = (a.stats.dominance > 70 && b.stats.dominance > 70) ? 0.18 : 0;

  score -= aggDiff * 0.18 + playDiff * 0.1 + domClash;

  return Math.max(0.05, Math.min(0.98, score));
}

export function estimateDogMarketValue(dog: Dog): number {
  const isAdult = dog.ageSeconds >= PUP_ADULT_AGE_SEC;
  const skillAvg =
    (dog.skills.foraging +
      dog.skills.tracking +
      dog.skills.agility +
      dog.skills.watchfulness +
      dog.skills.socialGrace) /
    5;
  const patternBonus = dog.genetics.pattern === 'patternless' ? 0 : 35;
  const genBonus = (dog.generation - 1) * 25;
  const base = isAdult ? 140 : 95;
  return Math.round(base + skillAvg * 0.8 + patternBonus + genBonus);
}
