import { Chess } from 'chess.js';
import { runSearch, type SearchInfo, type SearchParams } from './search';

export interface WorkerRequest {
  id: number;
  startFen: string;
  moves: string[]; // UCI
  params: SearchParams;
}

export interface SanLine {
  uci: string;
  score: number; // с точки зрения стороны, которая ходит
  pv: string[]; // UCI
  san: string[]; // SAN
}

export interface WorkerInfo extends Omit<SearchInfo, 'lines'> {
  lines: SanLine[];
}

export type WorkerResponse =
  | { id: number; type: 'info'; info: WorkerInfo }
  | { id: number; type: 'done'; info: WorkerInfo | null };

function toSan(startFen: string, moves: string[], info: SearchInfo): WorkerInfo {
  const base = new Chess(startFen);
  for (const u of moves) base.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
  const fen = base.fen();
  return {
    ...info,
    lines: info.lines.map((l) => {
      const c = new Chess(fen);
      const san: string[] = [];
      for (const u of l.pv) {
        try {
          san.push(c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }).san);
        } catch {
          break;
        }
      }
      return { ...l, san };
    }),
  };
}

self.onmessage = (ev: MessageEvent<WorkerRequest>) => {
  const { id, startFen, moves, params } = ev.data;
  const post = (m: WorkerResponse) => (self as unknown as Worker).postMessage(m);
  const last = runSearch(startFen, moves, params, (info) => {
    post({ id, type: 'info', info: toSan(startFen, moves, info) });
  });
  post({ id, type: 'done', info: last ? toSan(startFen, moves, last) : null });
};
