import es from '../i18n/es.json'

/**
 * The game is single-language: Spanish (Rioplatense). The locale is pinned; there is no selector and
 * no browser-based switching. Every visible string is a key in `src/i18n/es.json`.
 */
export const LOCALE = 'es' as const
export type Dictionary = Record<string, string>

const DICTIONARY: Dictionary = es

export class I18n {
  readonly locale = LOCALE

  constructor() {
    document.documentElement.lang = LOCALE
  }

  /** Look up `key`, replacing `{name}` placeholders. Missing keys render the key so gaps are visible. */
  t(key: string, vars: Record<string, string | number> = {}): string {
    const text = DICTIONARY[key] ?? key
    return text.replace(/\{(\w+)\}/g, (_, name: string) => String(vars[name] ?? `{${name}}`))
  }
}

export const DICTIONARY_KEYS = Object.keys(es)
