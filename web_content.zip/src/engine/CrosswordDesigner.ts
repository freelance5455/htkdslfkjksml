import {
  CrosswordLayout,
  CrosswordLayoutCell,
  CrosswordLayoutWord,
  CrosswordLayoutClue,
  LayoutDirection,
  ValidationResult
} from '../types/crosswordLayout';
import { normalizeArabicString } from './normalization';
import { validateCrosswordLayout } from './CrosswordValidator';

export interface DesignerQuestionInput {
  id: string;
  clue: string;
  answer: string;
  number?: number;
  reversed?: boolean;
}

interface PlacedWordInternal {
  id: string;
  clue: string;
  answer: string;
  normalizedAnswer: string;
  direction: LayoutDirection;
  startRow: number;
  startColumn: number;
  length: number;
  reversed?: boolean;
}

interface WordInput {
  id: string;
  clue: string;
  answer: string;
  norm: string;
  len: number;
  reversed?: boolean;
}

interface Candidate {
  word: WordInput;
  wordIdx: number;
  dir: LayoutDirection;
  r: number;
  c: number;
  intersections: number;
  score: number;
}

export class CrosswordDesigner {
  private gridDim = 15;
  private nodeCounter = 0;

  public generateLayout(
    questionsInput: DesignerQuestionInput[],
    maxAttempts = 1000,
    targetRows = 15,
    targetCols = 15
  ): {
    layout: CrosswordLayout;
    validation: ValidationResult;
  } {
    if (questionsInput.length < 2) {
      throw new Error(`مطلوب كلمتان على الأقل لتوليد الكلمات المتقاطعة.`);
    }

    this.gridDim = Math.max(targetRows, targetCols);

    const wordsToPlace: WordInput[] = questionsInput.map((q) => {
      const norm = normalizeArabicString(q.answer);
      return {
        id: q.id,
        clue: q.clue,
        answer: q.answer,
        norm,
        len: norm.length,
        reversed: q.reversed ?? false
      };
    });

    for (const w of wordsToPlace) {
      if (!w.norm || w.len < 2) {
        throw new Error(`الإجابة "${w.answer}" قصيرة جداً للكلمات المتقاطعة.`);
      }
    }

    let bestLayout: CrosswordLayout | null = null;
    let bestValidation: ValidationResult | null = null;
    let bestScore = -Infinity;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const rootIdx = Math.floor(Math.random() * Math.min(8, wordsToPlace.length));
      const rootWord = wordsToPlace[rootIdx];
      const remaining = wordsToPlace.filter((_, idx) => idx !== rootIdx);

      const grid: (string | null)[][] = Array.from({ length: this.gridDim }, () =>
        Array(this.gridDim).fill(null)
      );
      const cellDirs: Set<LayoutDirection>[][] = Array.from({ length: this.gridDim }, () =>
        Array.from({ length: this.gridDim }, () => new Set<LayoutDirection>())
      );

      const rootDir: LayoutDirection = Math.random() > 0.5 ? 'across' : 'down';
      const startR =
        rootDir === 'down'
          ? Math.floor((this.gridDim - rootWord.len) / 2)
          : Math.floor(this.gridDim / 2);
      const startC =
        rootDir === 'across'
          ? Math.floor((this.gridDim - rootWord.len) / 2)
          : Math.floor(this.gridDim / 2);

      for (let k = 0; k < rootWord.len; k++) {
        const cr = rootDir === 'down' ? startR + k : startR;
        const cc = rootDir === 'across' ? startC + k : startC;
        grid[cr][cc] = rootWord.norm[k];
        cellDirs[cr][cc].add(rootDir);
      }

      const firstPlaced: PlacedWordInternal = {
        id: rootWord.id,
        clue: rootWord.clue,
        answer: rootWord.answer,
        normalizedAnswer: rootWord.norm,
        length: rootWord.len,
        direction: rootDir,
        startRow: startR,
        startColumn: startC,
        reversed: rootWord.reversed
      };

      this.nodeCounter = 0;
      const result = this.backtrackPlaceWords(
        [firstPlaced],
        remaining,
        grid,
        cellDirs,
        5000
      );

      if (result && result.length === wordsToPlace.length) {
        const layout = this.buildFinalLayout(result, targetRows, targetCols);
        const validation = validateCrosswordLayout(layout);

        if (validation.isValid) {
          const intersections = validation.stats.intersectionsCount;
          const score = intersections * 100;

          if (score > bestScore) {
            bestScore = score;
            bestLayout = layout;
            bestValidation = validation;

            if (intersections >= 24) {
              break;
            }
          }
        }
      }
    }

    if (!bestLayout || !bestValidation || !bestValidation.isValid) {
      throw new Error(
        `GENERATION FAILED: تعذر إيجاد شبكة متصلة صالحة تحقق أبعاد 15×15 وقواعد الفصل التام بين الكلمات.`
      );
    }

    return { layout: bestLayout, validation: bestValidation };
  }

  private backtrackPlaceWords(
    placed: PlacedWordInternal[],
    unplaced: WordInput[],
    grid: (string | null)[][],
    cellDirs: Set<LayoutDirection>[][],
    nodeLimit: number
  ): PlacedWordInternal[] | null {
    this.nodeCounter++;
    if (this.nodeCounter > nodeLimit) return null;

    if (unplaced.length === 0) {
      return placed;
    }

    const placeableList: { wordIdx: number; candidates: Candidate[] }[] = [];

    for (let i = 0; i < unplaced.length; i++) {
      const cands = this.findValidCandidates(unplaced[i], i, grid, cellDirs, placed);
      if (cands.length > 0) {
        placeableList.push({ wordIdx: i, candidates: cands });
      }
    }

    if (placeableList.length === 0) return null;

    placeableList.sort((a, b) => {
      if (a.candidates.length !== b.candidates.length) {
        return a.candidates.length - b.candidates.length;
      }
      return Math.random() - 0.5;
    });

    const bestChoice = placeableList[0];
    const nextUnplaced = unplaced.filter((_, idx) => idx !== bestChoice.wordIdx);

    bestChoice.candidates.sort(
      (a, b) => b.score - a.score + (Math.random() * 10 - 5)
    );

    const candsToTry =
      unplaced.length <= 4
        ? bestChoice.candidates
        : bestChoice.candidates.slice(0, 16);

    for (const cand of candsToTry) {
      const newlyOccupied: { r: number; c: number; wasEmpty: boolean }[] = [];
      for (let k = 0; k < cand.word.len; k++) {
        const cr = cand.dir === 'down' ? cand.r + k : cand.r;
        const cc = cand.dir === 'across' ? cand.c + k : cand.c;
        const wasEmpty = grid[cr][cc] === null;
        grid[cr][cc] = cand.word.norm[k];
        cellDirs[cr][cc].add(cand.dir);
        newlyOccupied.push({ r: cr, c: cc, wasEmpty });
      }

      const pw: PlacedWordInternal = {
        id: cand.word.id,
        clue: cand.word.clue,
        answer: cand.word.answer,
        normalizedAnswer: cand.word.norm,
        length: cand.word.len,
        direction: cand.dir,
        startRow: cand.r,
        startColumn: cand.c,
        reversed: cand.word.reversed
      };
      placed.push(pw);

      const result = this.backtrackPlaceWords(
        placed,
        nextUnplaced,
        grid,
        cellDirs,
        nodeLimit
      );
      if (result) return result;

      placed.pop();
      for (const { r, c, wasEmpty } of newlyOccupied) {
        cellDirs[r][c].delete(cand.dir);
        if (wasEmpty) {
          grid[r][c] = null;
        }
      }
    }

    return null;
  }

  private findValidCandidates(
    targetWord: WordInput,
    targetIdx: number,
    grid: (string | null)[][],
    cellDirs: Set<LayoutDirection>[][],
    placed: PlacedWordInternal[]
  ): Candidate[] {
    const candidates: Candidate[] = [];
    const len = targetWord.len;

    for (const pw of placed) {
      const candDir: LayoutDirection = pw.direction === 'across' ? 'down' : 'across';

      for (let i = 0; i < pw.length; i++) {
        const pChar = pw.normalizedAnswer[i];

        for (let j = 0; j < len; j++) {
          const tChar = targetWord.norm[j];

          if (pChar === tChar) {
            let startR = 0;
            let startC = 0;

            if (pw.direction === 'across') {
              startR = pw.startRow - j;
              startC = pw.startColumn + i;
            } else {
              startR = pw.startRow + i;
              startC = pw.startColumn - j;
            }

            if (startR < 0 || startC < 0) continue;
            if (candDir === 'down' && startR + len > this.gridDim) continue;
            if (candDir === 'across' && startC + len > this.gridDim) continue;

            const check = this.isValidPlacement(
              targetWord,
              startR,
              startC,
              candDir,
              grid,
              cellDirs
            );
            if (check.valid) {
              const midR = candDir === 'down' ? startR + len / 2 : startR;
              const midC = candDir === 'across' ? startC + len / 2 : startC;
              const distFromCenter =
                Math.abs(midR - this.gridDim / 2) + Math.abs(midC - this.gridDim / 2);

              const score = check.intersections * 100 - distFromCenter * 3;

              candidates.push({
                word: targetWord,
                wordIdx: targetIdx,
                dir: candDir,
                r: startR,
                c: startC,
                intersections: check.intersections,
                score
              });
            }
          }
        }
      }
    }

    return candidates;
  }

  private isValidPlacement(
    word: WordInput,
    r: number,
    c: number,
    dir: LayoutDirection,
    grid: (string | null)[][],
    cellDirs: Set<LayoutDirection>[][]
  ): { valid: boolean; intersections: number } {
    const len = word.len;

    // 1. Head and Tail check
    if (dir === 'across') {
      if (c > 0 && grid[r][c - 1] !== null) return { valid: false, intersections: 0 };
      if (c + len < this.gridDim && grid[r][c + len] !== null)
        return { valid: false, intersections: 0 };
    } else {
      if (r > 0 && grid[r - 1][c] !== null) return { valid: false, intersections: 0 };
      if (r + len < this.gridDim && grid[r + len][c] !== null)
        return { valid: false, intersections: 0 };
    }

    let intersections = 0;

    for (let k = 0; k < len; k++) {
      const cr = dir === 'down' ? r + k : r;
      const cc = dir === 'across' ? c + k : c;
      const ch = word.norm[k];

      const currentCellChar = grid[cr][cc];

      if (currentCellChar !== null) {
        if (currentCellChar !== ch) return { valid: false, intersections: 0 };
        if (cellDirs[cr][cc].has(dir)) return { valid: false, intersections: 0 };
        if (cellDirs[cr][cc].size >= 2) return { valid: false, intersections: 0 };
        intersections++;
      } else {
        if (dir === 'across') {
          if (cr > 0 && grid[cr - 1][cc] !== null)
            return { valid: false, intersections: 0 };
          if (cr < this.gridDim - 1 && grid[cr + 1][cc] !== null)
            return { valid: false, intersections: 0 };
        } else {
          if (cc > 0 && grid[cr][cc - 1] !== null)
            return { valid: false, intersections: 0 };
          if (cc < this.gridDim - 1 && grid[cr][cc + 1] !== null)
            return { valid: false, intersections: 0 };
        }
      }
    }

    if (intersections === 0) return { valid: false, intersections: 0 };
    return { valid: true, intersections };
  }

  private buildFinalLayout(
    placedList: PlacedWordInternal[],
    targetRows = 15,
    targetCols = 15
  ): CrosswordLayout {
    let minR = Infinity;
    let minC = Infinity;
    let maxR = -Infinity;
    let maxC = -Infinity;

    for (const pw of placedList) {
      minR = Math.min(minR, pw.startRow);
      minC = Math.min(minC, pw.startColumn);
      const endR =
        pw.direction === 'down' ? pw.startRow + pw.length - 1 : pw.startRow;
      const endC =
        pw.direction === 'across' ? pw.startColumn + pw.length - 1 : pw.startColumn;
      maxR = Math.max(maxR, endR);
      maxC = Math.max(maxC, endC);
    }

    const boundingRows = maxR - minR + 1;
    const boundingCols = maxC - minC + 1;

    const gridRows = targetRows > 0 ? Math.max(targetRows, boundingRows) : boundingRows;
    const gridColumns = targetCols > 0 ? Math.max(targetCols, boundingCols) : boundingCols;

    const offsetR = targetRows >= boundingRows ? Math.floor((targetRows - boundingRows) / 2) : 0;
    const offsetC = targetCols >= boundingCols ? Math.floor((targetCols - boundingCols) / 2) : 0;

    const shiftedWords: PlacedWordInternal[] = placedList.map((pw) => ({
      ...pw,
      startRow: pw.startRow - minR + offsetR,
      startColumn: pw.startColumn - minC + offsetC
    }));

    const startCellMap = new Map<
      string,
      { acrossWord?: PlacedWordInternal; downWord?: PlacedWordInternal }
    >();

    for (const w of shiftedWords) {
      const key = `${w.startRow}_${w.startColumn}`;
      const entry = startCellMap.get(key) || {};
      if (w.direction === 'across') entry.acrossWord = w;
      if (w.direction === 'down') entry.downWord = w;
      startCellMap.set(key, entry);
    }

    const wordClueNumbers = new Map<string, number>();
    let currentClueNumber = 1;

    for (let r = 0; r < gridRows; r++) {
      for (let c = 0; c < gridColumns; c++) {
        const key = `${r}_${c}`;
        const entry = startCellMap.get(key);
        if (entry) {
          let numberAssigned = false;
          if (entry.acrossWord) {
            wordClueNumbers.set(entry.acrossWord.id, currentClueNumber);
            numberAssigned = true;
          }
          if (entry.downWord) {
            wordClueNumbers.set(entry.downWord.id, currentClueNumber);
            numberAssigned = true;
          }
          if (numberAssigned) {
            currentClueNumber++;
          }
        }
      }
    }

    const cellMap = new Map<
      string,
      {
        letter: string;
        acrossWordId?: string;
        downWordId?: string;
        clueNumber?: number;
      }
    >();

    for (const w of shiftedWords) {
      const clueNum = wordClueNumbers.get(w.id)!;

      for (let i = 0; i < w.length; i++) {
        const r = w.direction === 'down' ? w.startRow + i : w.startRow;
        const c = w.direction === 'across' ? w.startColumn + i : w.startColumn;
        const key = `${r}_${c}`;

        const existing = cellMap.get(key) || { letter: w.normalizedAnswer[i] };

        if (w.direction === 'across') {
          existing.acrossWordId = w.id;
        } else {
          existing.downWordId = w.id;
        }

        if (i === 0) {
          existing.clueNumber = clueNum;
        }

        cellMap.set(key, existing);
      }
    }

    const cells: CrosswordLayoutCell[] = [];
    const blackCells: { row: number; col: number }[] = [];

    for (let r = 0; r < gridRows; r++) {
      for (let c = 0; c < gridColumns; c++) {
        const key = `${r}_${c}`;
        const data = cellMap.get(key);

        if (data) {
          cells.push({
            row: r,
            column: c,
            isBlocked: false,
            letter: data.letter,
            acrossWordId: data.acrossWordId,
            downWordId: data.downWordId,
            clueNumber: data.clueNumber
          });
        } else {
          cells.push({
            row: r,
            column: c,
            isBlocked: true,
            letter: ''
          });
          blackCells.push({ row: r, col: c });
        }
      }
    }

    const layoutWords: CrosswordLayoutWord[] = shiftedWords.map((w) => {
      const clueNum = wordClueNumbers.get(w.id)!;
      const wordCells: { row: number; col: number }[] = [];

      for (let i = 0; i < w.length; i++) {
        const r = w.direction === 'down' ? w.startRow + i : w.startRow;
        const c = w.direction === 'across' ? w.startColumn + i : w.startColumn;
        wordCells.push({ row: r, col: c });
      }

      return {
        id: w.id,
        clue: w.clue,
        answer: w.answer,
        normalizedAnswer: w.normalizedAnswer,
        direction: w.direction,
        startRow: w.startRow,
        startColumn: w.startColumn,
        length: w.length,
        cells: wordCells,
        number: clueNum,
        reversed: w.reversed
      };
    });

    layoutWords.sort(
      (a, b) => a.number - b.number || a.direction.localeCompare(b.direction)
    );

    const layoutClues: CrosswordLayoutClue[] = layoutWords.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction,
      clue: w.clue,
      answer: w.answer
    }));

    let intersectionsCount = 0;
    for (const cell of cells) {
      if (!cell.isBlocked && cell.acrossWordId && cell.downWordId) {
        intersectionsCount++;
      }
    }

    return {
      gridRows,
      gridColumns,
      cells,
      words: layoutWords,
      blackCells,
      clues: layoutClues,
      metadata: {
        totalWords: layoutWords.length,
        placedWords: layoutWords.length,
        intersectionsCount,
        blackCellsCount: blackCells.length,
        generatedAt: new Date().toISOString()
      }
    };
  }
}
