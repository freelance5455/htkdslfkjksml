import type {
  AppSettings,
  Committee,
  CommitteeTransaction,
  CustomModule,
  CustomRecord,
  CustomReportConfig,
  CustomSubmodule,
  DashboardCardConfig,
  FieldDefinition,
  FieldMapping,
  FormulaDefinition,
  LoanPerson,
  LoanTransaction,
} from '../types/app';
import {
  detectCircularDependencies,
  evaluateFormula,
  extractReferencedFields,
} from './formulaParser';

export interface PersonLoanSummary {
  person: LoanPerson;
  openingBalance: number;
  totalReceived: number;
  totalRepaid: number;
  closingPayable: number;
  isOverpaid: boolean;
  transactionCount: number;
  lastTransactionDate: string | null;
}

export interface OverallLoanTotals {
  totalPeople: number;
  activePeople: number;
  totalOpeningBalance: number;
  totalReceived: number;
  totalRepaid: number;
  remainingPayable: number;
}

export function calculatePersonLoanSummary(
  person: LoanPerson,
  transactions: LoanTransaction[]
): PersonLoanSummary {
  const personTx = transactions.filter((t) => t.personId === person.id);
  let totalReceived = 0;
  let totalRepaid = 0;
  let lastDate: string | null = null;

  for (const tx of personTx) {
    const amt = Number(tx.amount) || 0;
    if (tx.type === 'received') {
      totalReceived += amt;
    } else if (tx.type === 'repayment') {
      totalRepaid += amt;
    }
    if (!lastDate || tx.date > lastDate) {
      lastDate = tx.date;
    }
  }

  const opening = Number(person.openingBalance) || 0;
  const closingPayable = roundMoney(opening + totalReceived - totalRepaid);

  return {
    person,
    openingBalance: roundMoney(opening),
    totalReceived: roundMoney(totalReceived),
    totalRepaid: roundMoney(totalRepaid),
    closingPayable,
    isOverpaid: closingPayable < 0,
    transactionCount: personTx.length,
    lastTransactionDate: lastDate,
  };
}

export function calculateOverallLoanTotals(
  persons: LoanPerson[],
  transactions: LoanTransaction[]
): OverallLoanTotals {
  const activePersons = persons.filter((p) => !p.archived);
  let totalOpeningBalance = 0;
  let totalReceived = 0;
  let totalRepaid = 0;
  let remainingPayable = 0;

  for (const p of activePersons) {
    const summary = calculatePersonLoanSummary(p, transactions);
    totalOpeningBalance += summary.openingBalance;
    totalReceived += summary.totalReceived;
    totalRepaid += summary.totalRepaid;
    remainingPayable += summary.closingPayable;
  }

  return {
    totalPeople: persons.length,
    activePeople: activePersons.length,
    totalOpeningBalance: roundMoney(totalOpeningBalance),
    totalReceived: roundMoney(totalReceived),
    totalRepaid: roundMoney(totalRepaid),
    remainingPayable: roundMoney(remainingPayable),
  };
}

export function validateRepaymentAmount(
  closingPayable: number,
  paymentAmount: number,
  allowOverpayment = false
): { valid: boolean; error?: string } {
  if (!Number.isFinite(paymentAmount) || paymentAmount <= 0) {
    return { valid: false, error: 'Repayment amount must be greater than zero.' };
  }
  if (!allowOverpayment && paymentAmount > closingPayable + 0.001) {
    return {
      valid: false,
      error: `Payment (${paymentAmount.toFixed(2)}) exceeds remaining payable (${closingPayable.toFixed(2)}). Enable "Allow Overpayment" if intentional.`,
    };
  }
  return { valid: true };
}

export interface CommitteeSummary {
  committee: Committee;
  openingBalance: number;
  totalCommitteeAmount: number;
  installmentAmount: number;
  totalInstallmentsPaid: number;
  totalPayouts: number;
  totalReceivable: number;
  totalPayable: number;
  closingBalance: number;
  transactionCount: number;
}

export interface OverallCommitteeTotals {
  totalCommittees: number;
  activeCommittees: number;
  totalOpeningBalance: number;
  totalInstallmentsPaid: number;
  totalPayouts: number;
  totalReceivable: number;
  totalPayable: number;
  netClosingBalance: number;
}

export function calculateCommitteeSummary(
  committee: Committee,
  transactions: CommitteeTransaction[]
): CommitteeSummary {
  const txList = transactions.filter((t) => t.committeeId === committee.id);
  let totalInstallmentsPaid = 0;
  let totalPayouts = 0;

  for (const tx of txList) {
    const amt = Number(tx.amount) || 0;
    if (tx.type === 'installment') {
      totalInstallmentsPaid += amt;
    } else if (tx.type === 'payout') {
      totalPayouts += amt;
    }
  }

  const opening = Number(committee.openingBalance) || 0;
  const totalCommitteeAmount = Number(committee.totalCommitteeAmount) || 0;
  // Positive closingBalance = net receivable (paid in more than received out)
  // Negative closingBalance = net payable (received payout exceeding paid-in contributions)
  const closingBalance = roundMoney(opening + totalInstallmentsPaid - totalPayouts);
  const totalReceivable = closingBalance > 0 ? closingBalance : 0;
  const remainingInstallments = Math.max(0, totalCommitteeAmount - totalInstallmentsPaid);
  const totalPayable =
    closingBalance < 0 ? roundMoney(Math.abs(closingBalance)) : roundMoney(remainingInstallments);

  return {
    committee,
    openingBalance: roundMoney(opening),
    totalCommitteeAmount: roundMoney(totalCommitteeAmount),
    installmentAmount: roundMoney(Number(committee.installmentAmount) || 0),
    totalInstallmentsPaid: roundMoney(totalInstallmentsPaid),
    totalPayouts: roundMoney(totalPayouts),
    totalReceivable: roundMoney(totalReceivable),
    totalPayable: roundMoney(totalPayable),
    closingBalance,
    transactionCount: txList.length,
  };
}

export function calculateOverallCommitteeTotals(
  committees: Committee[],
  transactions: CommitteeTransaction[]
): OverallCommitteeTotals {
  const active = committees.filter((c) => !c.archived);
  let totalOpeningBalance = 0;
  let totalInstallmentsPaid = 0;
  let totalPayouts = 0;
  let totalReceivable = 0;
  let totalPayable = 0;
  let netClosingBalance = 0;

  for (const c of active) {
    const s = calculateCommitteeSummary(c, transactions);
    totalOpeningBalance += s.openingBalance;
    totalInstallmentsPaid += s.totalInstallmentsPaid;
    totalPayouts += s.totalPayouts;
    totalReceivable += s.totalReceivable;
    totalPayable += s.totalPayable;
    netClosingBalance += s.closingBalance;
  }

  return {
    totalCommittees: committees.length,
    activeCommittees: active.length,
    totalOpeningBalance: roundMoney(totalOpeningBalance),
    totalInstallmentsPaid: roundMoney(totalInstallmentsPaid),
    totalPayouts: roundMoney(totalPayouts),
    totalReceivable: roundMoney(totalReceivable),
    totalPayable: roundMoney(totalPayable),
    netClosingBalance: roundMoney(netClosingBalance),
  };
}

export function roundMoney(val: number, decimals = 2): number {
  const factor = Math.pow(10, decimals);
  return Math.round((val + Number.EPSILON) * factor) / factor;
}

// Build cross-module context keys and evaluate formulas + field mappings
export interface EvaluatedFieldState {
  values: Record<string, unknown>;
  errors: Record<string, string>;
}

export function buildSubmoduleDependencyGraph(
  fields: FieldDefinition[],
  formulas: FormulaDefinition[],
  mappings: FieldMapping[],
  submoduleId: string
): Record<string, string[]> {
  const subFields = fields.filter((f) => f.submoduleId === submoduleId);
  const nameById = new Map(subFields.map((f) => [f.id, f.name]));
  const graph: Record<string, string[]> = {};

  for (const f of subFields) {
    graph[f.name] = [];
    const formulaDef = formulas.find((fm) => fm.targetFieldId === f.id);
    const expr = formulaDef?.expression || f.formulaExpression;
    if (f.type === 'formula' && expr) {
      const { fields: refs } = extractReferencedFields(expr);
      graph[f.name].push(...refs);
    }
  }

  for (const m of mappings) {
    if (m.destSubmoduleId === submoduleId && m.sourceSubmoduleId === submoduleId) {
      const destName = nameById.get(m.destFieldId);
      const srcName = nameById.get(m.sourceFieldId);
      if (destName && srcName) {
        graph[destName] = graph[destName] || [];
        graph[destName].push(srcName);
        if (m.formulaExpression) {
          const { fields: refs } = extractReferencedFields(m.formulaExpression);
          graph[destName].push(...refs);
        }
      }
    }
  }

  return graph;
}

export function checkGlobalCircularReferences(
  fields: FieldDefinition[],
  formulas: FormulaDefinition[],
  mappings: FieldMapping[],
  modules: CustomModule[],
  submodules: CustomSubmodule[]
): { hasCycle: boolean; cyclePath: string[] } {
  const modMap = new Map(modules.map((m) => [m.id, m.name]));
  const subMap = new Map(submodules.map((s) => [s.id, s.name]));
  const fieldById = new Map(fields.map((f) => [f.id, f]));

  const keyFor = (f: FieldDefinition) =>
    `${modMap.get(f.moduleId) || f.moduleId}.${subMap.get(f.submoduleId) || f.submoduleId}.${f.name}`;

  const graph: Record<string, string[]> = {};

  for (const f of fields) {
    const k = keyFor(f);
    graph[k] = [];
    const fm = formulas.find((item) => item.targetFieldId === f.id);
    const expr = fm?.expression || f.formulaExpression;
    if (f.type === 'formula' && expr) {
      const { fields: refs } = extractReferencedFields(expr);
      for (const r of refs) {
        if (r.includes('.')) {
          graph[k].push(r);
        } else {
          const localMatch = fields.find(
            (other) =>
              other.submoduleId === f.submoduleId &&
              (other.name.toLowerCase() === r.toLowerCase() || other.label.toLowerCase() === r.toLowerCase())
          );
          graph[k].push(localMatch ? keyFor(localMatch) : r);
        }
      }
    }
  }

  for (const m of mappings) {
    const dest = fieldById.get(m.destFieldId);
    const src = fieldById.get(m.sourceFieldId);
    if (dest && src) {
      const dk = keyFor(dest);
      const sk = keyFor(src);
      graph[dk] = graph[dk] || [];
      graph[dk].push(sk);
      if (m.formulaExpression) {
        const { fields: refs } = extractReferencedFields(m.formulaExpression);
        for (const r of refs) {
          if (r.includes('.')) graph[dk].push(r);
          else {
            const localMatch = fields.find(
              (other) =>
                other.submoduleId === dest.submoduleId &&
                (other.name.toLowerCase() === r.toLowerCase() || other.label.toLowerCase() === r.toLowerCase())
            );
            graph[dk].push(localMatch ? keyFor(localMatch) : r);
          }
        }
      }
    }
  }

  return detectCircularDependencies(graph);
}

export function evaluateRecordValues(args: {
  submoduleId: string;
  rawValues: Record<string, unknown>;
  fields: FieldDefinition[];
  formulas: FormulaDefinition[];
  mappings: FieldMapping[];
  allRecords: CustomRecord[];
  modules: CustomModule[];
  submodules: CustomSubmodule[];
}): EvaluatedFieldState {
  const { submoduleId, rawValues, fields, formulas, mappings, allRecords, modules, submodules } = args;
  const subFields = fields.filter((f) => f.submoduleId === submoduleId);
  const values: Record<string, unknown> = { ...rawValues };
  const errors: Record<string, string> = {};

  // Build cross-module context from latest / aggregate values
  const modMap = new Map(modules.map((m) => [m.id, m.name]));
  const subMap = new Map(submodules.map((s) => [s.id, s.name]));
  const crossContext: Record<string, unknown> = {};

  for (const f of fields) {
    const modName = modMap.get(f.moduleId);
    const subName = subMap.get(f.submoduleId);
    if (!modName || !subName) continue;
    const key = `${modName}.${subName}.${f.name}`;
    const matchingRecs = allRecords.filter((r) => !r.archived && r.submoduleId === f.submoduleId);
    if (matchingRecs.length > 0) {
      const latest = matchingRecs[matchingRecs.length - 1];
      crossContext[key] = latest.values[f.name] ?? 0;
    } else {
      crossContext[key] = 0;
    }
  }

  // Build local field name & label aliases
  const buildEvalContext = (): Record<string, unknown> => {
    const ctx: Record<string, unknown> = { ...crossContext };
    for (const f of subFields) {
      const val = values[f.name] ?? values[f.id] ?? 0;
      ctx[f.name] = val;
      if (f.label && f.label !== f.name) {
        ctx[f.label] = val;
      }
    }
    return ctx;
  };

  // Multi-pass evaluation so chained formulas & mappings converge safely (capped by subFields.length + 2)
  const subMappings = mappings.filter((m) => m.destSubmoduleId === submoduleId && m.validationStatus !== 'invalid');
  const graph = buildSubmoduleDependencyGraph(fields, formulas, mappings, submoduleId);
  const cycleCheck = detectCircularDependencies(graph);
  if (cycleCheck.hasCycle) {
    for (const node of cycleCheck.cyclePath) {
      errors[node] = `Circular dependency detected: ${cycleCheck.cyclePath.join(' → ')}`;
    }
    return { values, errors };
  }

  const maxPasses = Math.max(2, subFields.length + subMappings.length + 1);
  for (let pass = 0; pass < maxPasses; pass++) {
    let changed = false;

    // 1. Apply Field Mappings targeting this submodule
    for (const mapping of subMappings) {
      const destField = subFields.find((f) => f.id === mapping.destFieldId);
      const srcField = fields.find((f) => f.id === mapping.sourceFieldId);
      if (!destField || !srcField) continue;

      let computed: unknown;
      if (mapping.mappingType === 'direct') {
        if (mapping.sourceSubmoduleId === submoduleId) {
          computed = values[srcField.name] ?? 0;
        } else {
          const srcRecs = allRecords.filter((r) => !r.archived && r.submoduleId === mapping.sourceSubmoduleId);
          computed = srcRecs.length > 0 ? srcRecs[srcRecs.length - 1].values[srcField.name] ?? 0 : 0;
        }
      } else if (mapping.mappingType === 'aggregate_sum' || mapping.mappingType === 'aggregate_avg') {
        const srcRecs = allRecords.filter((r) => !r.archived && r.submoduleId === mapping.sourceSubmoduleId);
        const nums = srcRecs.map((r) => Number(r.values[srcField.name]) || 0);
        if (mapping.mappingType === 'aggregate_sum') {
          computed = roundMoney(nums.reduce((a, b) => a + b, 0), destField.decimalPlaces);
        } else {
          computed = nums.length > 0 ? roundMoney(nums.reduce((a, b) => a + b, 0) / nums.length, destField.decimalPlaces) : 0;
        }
      } else if (mapping.mappingType === 'formula' && mapping.formulaExpression) {
        const ctx = buildEvalContext();
        // Also inject A, B, C positional aliases for cell-style mapping
        ctx['A'] = values[srcField.name] ?? crossContext[`${modMap.get(srcField.moduleId)}.${subMap.get(srcField.submoduleId)}.${srcField.name}`] ?? 0;
        const res = evaluateFormula(mapping.formulaExpression, ctx, destField.decimalPlaces);
        if (res.ok) {
          computed = res.value;
          delete errors[destField.name];
        } else {
          errors[destField.name] = res.error || 'Mapping formula error';
          continue;
        }
      }

      if (computed !== undefined && values[destField.name] !== computed) {
        values[destField.name] = computed;
        changed = true;
      }
    }

    // 2. Apply Formula Fields
    for (const f of subFields) {
      if (f.type !== 'formula') continue;
      const formulaDef = formulas.find((fm) => fm.targetFieldId === f.id);
      const expr = formulaDef?.expression || f.formulaExpression;
      if (!expr) continue;

      const res = evaluateFormula(expr, buildEvalContext(), formulaDef?.decimalPlaces ?? f.decimalPlaces);
      if (res.ok) {
        if (values[f.name] !== res.value) {
          values[f.name] = res.value;
          changed = true;
        }
        delete errors[f.name];
      } else {
        errors[f.name] = res.error || 'Calculation error';
      }
    }

    if (!changed) break;
  }

  return { values, errors };
}

export function computeDashboardCardValue(args: {
  card: DashboardCardConfig;
  loanPersons: LoanPerson[];
  loanTransactions: LoanTransaction[];
  committees: Committee[];
  committeeTransactions: CommitteeTransaction[];
  customRecords: CustomRecord[];
  fields: FieldDefinition[];
}): { value: number; formattedHint: string; recordCount: number; error?: string } {
  const { card, loanPersons, loanTransactions, committees, committeeTransactions, customRecords, fields } = args;

  const loanTotals = calculateOverallLoanTotals(loanPersons, loanTransactions);
  const commTotals = calculateOverallCommitteeTotals(committees, committeeTransactions);

  if (card.isSystem && card.systemKey) {
    const repayCount = loanTransactions.filter((t) => t.type === 'repayment').length;
    switch (card.systemKey) {
      case 'loan_received':
        return {
          value: loanTotals.totalReceived,
          formattedHint: `${loanTotals.activePeople} ${loanTotals.activePeople === 1 ? 'person' : 'people'}`,
          recordCount: loanTransactions.filter((t) => t.type === 'received').length,
        };
      case 'loan_repaid':
        return {
          value: loanTotals.totalRepaid,
          formattedHint: `${repayCount} ${repayCount === 1 ? 'payment' : 'payments'}`,
          recordCount: repayCount,
        };
      case 'loan_remaining':
        return {
          value: loanTotals.remainingPayable,
          formattedHint: `Opening + Received − Repaid`,
          recordCount: loanTotals.activePeople,
        };
      case 'committee_receivable':
        return {
          value: commTotals.totalReceivable,
          formattedHint: `${commTotals.activeCommittees} active ${commTotals.activeCommittees === 1 ? 'committee' : 'committees'}`,
          recordCount: commTotals.activeCommittees,
        };
    }
  }

  if (card.calculation === 'custom_formula' && card.customFormula) {
    const ctx: Record<string, number> = {
      LoanReceived: loanTotals.totalReceived,
      LoanRepaid: loanTotals.totalRepaid,
      LoanRemaining: loanTotals.remainingPayable,
      CommitteeReceivable: commTotals.totalReceivable,
      CommitteePayable: commTotals.totalPayable,
      CommitteePaid: commTotals.totalInstallmentsPaid,
      CommitteePayouts: commTotals.totalPayouts,
    };
    const res = evaluateFormula(card.customFormula, ctx, 2);
    if (!res.ok) {
      return { value: 0, formattedHint: res.error || 'Formula error', recordCount: 0, error: res.error };
    }
    return { value: Number(res.value) || 0, formattedHint: 'Custom formula', recordCount: 1 };
  }

  // Gather numeric values from selected source
  let numbers: number[] = [];

  if (card.sourceType === 'loan') {
    if (card.calculation === 'remaining_balance') {
      return { value: loanTotals.remainingPayable, formattedHint: `${loanTotals.activePeople} accounts`, recordCount: loanTotals.activePeople };
    }
    if (card.fieldId === 'received') {
      numbers = loanTransactions.filter((t) => t.type === 'received').map((t) => Number(t.amount) || 0);
    } else if (card.fieldId === 'repayment') {
      numbers = loanTransactions.filter((t) => t.type === 'repayment').map((t) => Number(t.amount) || 0);
    } else if (card.fieldId === 'openingBalance') {
      numbers = loanPersons.filter((p) => !p.archived).map((p) => Number(p.openingBalance) || 0);
    } else {
      numbers = loanTransactions.map((t) => Number(t.amount) || 0);
    }
  } else if (card.sourceType === 'committee') {
    if (card.calculation === 'remaining_balance') {
      return { value: commTotals.totalReceivable, formattedHint: `${commTotals.activeCommittees} committees`, recordCount: commTotals.activeCommittees };
    }
    if (card.fieldId === 'installment') {
      numbers = committeeTransactions.filter((t) => t.type === 'installment').map((t) => Number(t.amount) || 0);
    } else if (card.fieldId === 'payout') {
      numbers = committeeTransactions.filter((t) => t.type === 'payout').map((t) => Number(t.amount) || 0);
    } else if (card.fieldId === 'totalCommitteeAmount') {
      numbers = committees.filter((c) => !c.archived).map((c) => Number(c.totalCommitteeAmount) || 0);
    } else {
      numbers = committeeTransactions.map((t) => Number(t.amount) || 0);
    }
  } else {
    const fieldDef = fields.find((f) => f.id === card.fieldId || f.name === card.fieldId);
    const targetRecords = customRecords.filter(
      (r) =>
        !r.archived &&
        (!card.moduleId || r.moduleId === card.moduleId) &&
        (!card.submoduleId || r.submoduleId === card.submoduleId)
    );
    if (card.calculation === 'count') {
      return { value: targetRecords.length, formattedHint: `${targetRecords.length} records`, recordCount: targetRecords.length };
    }
    const key = fieldDef ? fieldDef.name : card.fieldId || '';
    numbers = targetRecords
      .map((r) => Number(r.values[key]))
      .filter((n) => Number.isFinite(n));
  }

  const count = numbers.length;
  if (count === 0) {
    return { value: 0, formattedHint: '0 records', recordCount: 0 };
  }

  switch (card.calculation) {
    case 'count':
      return { value: count, formattedHint: `${count} entries`, recordCount: count };
    case 'sum':
      return { value: roundMoney(numbers.reduce((a, b) => a + b, 0)), formattedHint: `${count} entries`, recordCount: count };
    case 'average':
      return { value: roundMoney(numbers.reduce((a, b) => a + b, 0) / count), formattedHint: `Avg of ${count}`, recordCount: count };
    case 'min':
      return { value: roundMoney(Math.min(...numbers)), formattedHint: `Min of ${count}`, recordCount: count };
    case 'max':
      return { value: roundMoney(Math.max(...numbers)), formattedHint: `Max of ${count}`, recordCount: count };
    default:
      return { value: roundMoney(numbers.reduce((a, b) => a + b, 0)), formattedHint: `${count} entries`, recordCount: count };
  }
}

export interface ReportRow {
  id: string;
  [key: string]: unknown;
}

export interface DynamicReportOutput {
  columns: { key: string; label: string }[];
  rows: ReportRow[];
  groupedSummary?: { group: string; count: number; aggregate: number }[];
  totalAggregate: number;
}

export function runDynamicReport(args: {
  report: CustomReportConfig;
  loanPersons: LoanPerson[];
  loanTransactions: LoanTransaction[];
  committees: Committee[];
  committeeTransactions: CommitteeTransaction[];
  customRecords: CustomRecord[];
  fields: FieldDefinition[];
}): DynamicReportOutput {
  const { report, loanPersons, loanTransactions, committees, committeeTransactions, customRecords, fields } = args;
  let rows: ReportRow[] = [];
  let columns: { key: string; label: string }[] = [];

  if (report.sourceType === 'loan') {
    const personMap = new Map(loanPersons.map((p) => [p.id, p.name]));
    const allCols = [
      { key: 'date', label: 'Date' },
      { key: 'personName', label: 'Person Name' },
      { key: 'type', label: 'Type' },
      { key: 'amount', label: 'Amount' },
      { key: 'paymentMethod', label: 'Method' },
      { key: 'transactionRef', label: 'Reference' },
      { key: 'description', label: 'Description' },
      { key: 'remarks', label: 'Remarks' },
    ];
    columns = report.fieldIds.length > 0 ? allCols.filter((c) => report.fieldIds.includes(c.key)) : allCols;
    rows = loanTransactions.map((tx) => ({
      id: tx.id,
      date: tx.date,
      personName: personMap.get(tx.personId) || 'Unknown',
      type: tx.type === 'received' ? 'Loan Received' : 'Repayment',
      amount: tx.amount,
      paymentMethod: tx.paymentMethod || '-',
      transactionRef: tx.transactionRef || '-',
      description: tx.description || '-',
      remarks: tx.remarks || '-',
    }));
  } else if (report.sourceType === 'committee') {
    const commMap = new Map(committees.map((c) => [c.id, c.name]));
    const allCols = [
      { key: 'date', label: 'Date' },
      { key: 'committeeName', label: 'Committee' },
      { key: 'personName', label: 'Person Name' },
      { key: 'type', label: 'Transaction Type' },
      { key: 'amount', label: 'Amount' },
      { key: 'paymentMethod', label: 'Method' },
      { key: 'paymentRef', label: 'Reference' },
      { key: 'remarks', label: 'Remarks' },
    ];
    columns = report.fieldIds.length > 0 ? allCols.filter((c) => report.fieldIds.includes(c.key)) : allCols;
    rows = committeeTransactions.map((tx) => ({
      id: tx.id,
      date: tx.date,
      committeeName: commMap.get(tx.committeeId) || 'Unknown',
      personName: tx.personName,
      type: tx.type === 'installment' ? 'Installment Paid' : 'Payout Received',
      amount: tx.amount,
      paymentMethod: tx.paymentMethod || '-',
      paymentRef: tx.paymentRef || '-',
      remarks: tx.remarks || '-',
    }));
  } else {
    const subFields = fields
      .filter((f) => (!report.moduleId || f.moduleId === report.moduleId) && (!report.submoduleId || f.submoduleId === report.submoduleId))
      .sort((a, b) => a.position - b.position);
    const chosenFields = report.fieldIds.length > 0
      ? subFields.filter((f) => report.fieldIds.includes(f.id) || report.fieldIds.includes(f.name))
      : subFields;

    columns = [
      ...chosenFields.map((f) => ({ key: f.name, label: f.label })),
      { key: 'createdAt', label: 'Created Date' },
    ];

    const recs = customRecords.filter(
      (r) =>
        !r.archived &&
        (!report.moduleId || r.moduleId === report.moduleId) &&
        (!report.submoduleId || r.submoduleId === report.submoduleId)
    );

    rows = recs.map((r) => ({
      id: r.id,
      ...r.values,
      createdAt: r.createdAt.slice(0, 10),
    }));
  }

  // Date range filter
  const dateKey = report.dateFieldId || (report.sourceType === 'custom' ? 'createdAt' : 'date');
  if (report.dateFrom || report.dateTo) {
    rows = rows.filter((r) => {
      const val = String(r[dateKey] || '').slice(0, 10);
      if (!val) return true;
      if (report.dateFrom && val < report.dateFrom) return false;
      if (report.dateTo && val > report.dateTo) return false;
      return true;
    });
  }

  // Custom filters
  for (const flt of report.filters) {
    if (!flt.fieldId || flt.value === '') continue;
    rows = rows.filter((r) => {
      const cell = r[flt.fieldId];
      const cellStr = String(cell ?? '').toLowerCase();
      const targetStr = flt.value.toLowerCase();
      if (flt.operator === 'equals') return cellStr === targetStr;
      if (flt.operator === 'contains') return cellStr.includes(targetStr);
      if (flt.operator === 'gt') return Number(cell) > Number(flt.value);
      if (flt.operator === 'lt') return Number(cell) < Number(flt.value);
      return true;
    });
  }

  // Sort
  if (report.sortBy) {
    const sortKey = report.sortBy;
    const dir = report.sortDir === 'desc' ? -1 : 1;
    rows = [...rows].sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      const an = Number(av);
      const bn = Number(bv);
      if (!Number.isNaN(an) && !Number.isNaN(bn) && av !== '' && bv !== '') {
        return (an - bn) * dir;
      }
      return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
    });
  }

  // Determine primary numeric column for aggregate calculation
  const numericKey =
    columns.find((c) => c.key === 'amount')?.key ||
    columns.find((c) => rows.some((r) => typeof r[c.key] === 'number' || (String(r[c.key] || '').trim() !== '' && !Number.isNaN(Number(r[c.key])))))?.key ||
    '';

  const calcAgg = (items: ReportRow[]): number => {
    if (report.calculation === 'count') return items.length;
    if (report.calculation === 'none' || !numericKey) return 0;
    const nums = items.map((r) => Number(r[numericKey])).filter((n) => Number.isFinite(n));
    if (nums.length === 0) return 0;
    if (report.calculation === 'sum') return roundMoney(nums.reduce((a, b) => a + b, 0));
    if (report.calculation === 'avg') return roundMoney(nums.reduce((a, b) => a + b, 0) / nums.length);
    if (report.calculation === 'min') return roundMoney(Math.min(...nums));
    if (report.calculation === 'max') return roundMoney(Math.max(...nums));
    return 0;
  };

  let groupedSummary: { group: string; count: number; aggregate: number }[] | undefined;
  if (report.groupBy) {
    const groups = new Map<string, ReportRow[]>();
    for (const r of rows) {
      const gKey = String(r[report.groupBy] ?? 'Uncategorized');
      const arr = groups.get(gKey) || [];
      arr.push(r);
      groups.set(gKey, arr);
    }
    groupedSummary = Array.from(groups.entries()).map(([group, grpRows]) => ({
      group,
      count: grpRows.length,
      aggregate: calcAgg(grpRows),
    }));
  }

  return {
    columns,
    rows,
    groupedSummary,
    totalAggregate: calcAgg(rows),
  };
}

export function toCsvString(columns: { key: string; label: string }[], rows: Record<string, unknown>[]): string {
  const escape = (val: unknown): string => {
    const str = Array.isArray(val) ? val.join('; ') : String(val ?? '');
    if (/[",\n\r]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const header = columns.map((c) => escape(c.label)).join(',');
  const body = rows.map((r) => columns.map((c) => escape(r[c.key])).join(','));
  return [header, ...body].join('\n');
}

export function formatMoney(amount: number, settings?: Pick<AppSettings, 'currency' | 'numberFormat'>): string {
  const currency = settings?.currency || 'Rs.';
  const locale = settings?.numberFormat || 'en-PK';
  const num = Number(amount) || 0;
  const formatted = new Intl.NumberFormat(locale, {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(Math.abs(num));
  return `${num < 0 ? '-' : ''}${currency} ${formatted}`;
}

export function formatDisplayDate(isoDate: string, format: AppSettings['dateFormat'] = 'YYYY-MM-DD'): string {
  if (!isoDate) return '-';
  const clean = isoDate.slice(0, 10);
  const parts = clean.split('-');
  if (parts.length !== 3) return isoDate;
  const [y, m, d] = parts;
  if (format === 'DD/MM/YYYY') return `${d}/${m}/${y}`;
  if (format === 'MM/DD/YYYY') return `${m}/${d}/${y}`;
  if (format === 'DD MMM YYYY') {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const mIdx = Math.max(0, Math.min(11, Number(m) - 1));
    return `${d} ${months[mIdx]} ${y}`;
  }
  return clean;
}
