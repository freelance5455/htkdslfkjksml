import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  CameraMode,
  CharacterCustomization,
  CharacterId,
  DistrictDef,
  GamePhase,
  HudSnapshot,
  MissionDef,
  PlaceDef,
  RecordedClipDraft,
  VehicleTuning,
  VehicleType,
  WeatherType,
} from '../types/game';
import {
  CHARACTER_PROFILES,
  KARACHI_DISTRICTS,
  KARACHI_PLACES,
  VEHICLE_SPECS,
} from '../data/karachiWorldData';
import { createProceduralTextures, ProceduralTextureSet } from './textures';
import {
  animateCharacterRig,
  ArticulatedCharacter,
  createCharacterRig,
  createVehicleRig,
  VehicleRig,
} from './models';
import {
  BoxCollider,
  buildKarachiWorld,
  groundHeightAt,
  isWaterAt,
  WorldRefs,
} from './worldBuilder';
import { soundEngine } from '../audio/soundEngine';

interface VehicleEntity {
  id: string;
  type: VehicleType;
  rig: VehicleRig;
  driverRig?: ArticulatedCharacter;
  x: number;
  y: number;
  z: number;
  yaw: number;
  speed: number;
  steerAngle: number;
  isTraffic: boolean;
  isPolice: boolean;
  trafficDirX: number;
  trafficDirZ: number;
  trafficTimer: number;
}

interface NpcEntity {
  rig: ArticulatedCharacter;
  x: number;
  z: number;
  yaw: number;
  speed: number;
  role: 'pedestrian' | 'vendor' | 'shopkeeper' | 'police';
  walkPhase: number;
  turnTimer: number;
  fleeTimer: number;
  blinkSeed: number;
}

export interface EngineCallbacks {
  onHudUpdate: (hud: HudSnapshot) => void;
  onOpenPlace: (place: PlaceDef) => void;
  onMissionComplete: (mission: MissionDef) => void;
  onMissionFailed: (reason: string) => void;
  onWasted: () => void;
  onNotification: (text: string) => void;
  onTogglePause: () => void;
  onTogglePhone: () => void;
}

// Module-scope reusable scratch math objects (zero GC in render loop)
const _camDesired = new THREE.Vector3();
const _camLookAt = new THREE.Vector3();
const _skyColor = new THREE.Color();
const _sunColor = new THREE.Color();

export class KarachiGameEngine {
  private container: HTMLElement;
  private callbacks: EngineCallbacks;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private textures: ProceduralTextureSet;
  private world: WorldRefs;
  private isSoftwareGl: boolean;

  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private rainPoints: THREE.Points;
  private rainPositions: Float32Array;

  private phase: GamePhase = 'title';
  private frameId = 0;
  private lastTime = performance.now();
  private hudEmitTimer = 0;
  private hitstopTimer = 0;
  private shakeIntensity = 0;

  // Player State
  private playerRig: ArticulatedCharacter;
  private activeCharId: CharacterId = 'zain';
  private charCustom: CharacterCustomization;
  private playerX = 18;
  private playerY = 0;
  private playerZ = -55;
  private playerVx = 0;
  private playerVy = 0;
  private playerVz = 0;
  private playerYaw = Math.PI;
  private walkPhase = 0;
  private coyoteTimer = 0;
  private isGrounded = true;
  private isSwimming = false;
  private health = 100;
  private maxHealth = 100;
  private stamina = 100;
  private cash = 150000;
  private wantedLevel = 0;
  private wantedCooldown = 0;

  // Vehicle & NPC State
  private vehicles: VehicleEntity[] = [];
  private activeVehicle: VehicleEntity | null = null;
  private npcs: NpcEntity[] = [];

  // Camera State
  private cameraMode: CameraMode = 'third_person';
  private camYaw = 0;
  private camPitch = 0.28;
  private manualCamCooldown = 0;
  private isDraggingCam = false;
  private lastPointerX = 0;
  private lastPointerY = 0;

  // Environment State
  private timeOfDay = 17.2; // 0..24
  private autoTimeCycle = true;
  private weather: WeatherType = 'golden';

  // Mission & Waypoint State
  private activeMission: {
    def: MissionDef;
    waypointIndex: number;
    timeLeft: number | null;
  } | null = null;
  private missionBeacon: THREE.Mesh;
  private customWaypoint: { x: number; z: number; label: string } | null = null;
  private waypointBeacon: THREE.Mesh;

  // Input State (held vs edge-triggered)
  private keys = new Set<string>();
  private justPressed = new Set<string>();
  private touchMove = { x: 0, y: 0 }; // x: left/right (-1..1), y: forward/back (-1..1)
  private touchSteer = 0; // -1 left .. +1 right (for buttons/wheel)
  private touchGas = 0;
  private touchBrake = 0;
  private touchHandbrake = false;
  private touchBoost = false;
  private touchSprint = false;
  private vehicleTuning: Partial<Record<VehicleType, VehicleTuning>> = {};

  // YouTube Real Gameplay Recording State
  private isRecordingVideo = false;
  private recordingStartMs = 0;
  private recordingActionScore = 0;
  private recordingDistricts = new Set<string>();
  private recordingThumbnail = '';
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: BlobPart[] = [];

  // Cleanup refs
  private destroyed = false;
  private boundKeyDown: (e: KeyboardEvent) => void;
  private boundKeyUp: (e: KeyboardEvent) => void;
  private boundBlur: () => void;
  private boundResize: () => void;
  private boundPointerDown: (e: PointerEvent) => void;
  private boundPointerMove: (e: PointerEvent) => void;
  private boundPointerUp: () => void;

  constructor(
    container: HTMLElement,
    initialChar: CharacterId,
    initialCustom: CharacterCustomization,
    initialCash: number,
    initialPos: { x: number; y: number; z: number },
    initialTime: number,
    initialWeather: WeatherType,
    callbacks: EngineCallbacks
  ) {
    this.container = container;
    this.callbacks = callbacks;
    this.activeCharId = initialChar;
    this.charCustom = initialCustom;
    this.cash = initialCash;
    this.playerX = initialPos.x;
    this.playerY = initialPos.y;
    this.playerZ = initialPos.z;
    this.timeOfDay = initialTime;
    this.weather = initialWeather;

    // 1. Software WebGL probe
    this.isSoftwareGl = (() => {
      const probe = document.createElement('canvas');
      const gl = probe.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Renderer setup
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // 3. Scene, Camera & Studio RoomEnvironment
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#1e293b');
    this.scene.fog = new THREE.FogExp2('#1e293b', 0.0022);

    this.camera = new THREE.PerspectiveCamera(
      62,
      (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight),
      0.2,
      900
    );

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // 4. Balanced 3-point outdoor lighting rig
    this.hemiLight = new THREE.HemisphereLight('#93c5fd', '#78350f', 0.65);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight('#fff7ed', 1.75);
    this.sunLight.position.set(80, 120, 60);
    this.sunLight.castShadow = !this.isSoftwareGl;
    this.sunLight.shadow.mapSize.set(2048, 2048);
    this.sunLight.shadow.camera.near = 10;
    this.sunLight.shadow.camera.far = 280;
    const d = 95;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.03;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // 5. Procedural Textures & Connected Karachi City
    this.textures = createProceduralTextures(this.renderer.capabilities.getMaxAnisotropy());
    this.world = buildKarachiWorld(this.scene, this.textures, this.isSoftwareGl);

    // 6. Player Character Rig (Ultra-realistic articulated human)
    this.playerRig = this.buildPlayerRig(this.activeCharId, this.charCustom);
    this.playerRig.group.position.set(this.playerX, this.playerY, this.playerZ);
    this.scene.add(this.playerRig.group);

    // 7. Mission & GPS Waypoint Beacons
    this.missionBeacon = new THREE.Mesh(
      new THREE.CylinderGeometry(3.5, 3.5, 16, 24, 1, true),
      new THREE.MeshBasicMaterial({
        color: '#facc15',
        transparent: true,
        opacity: 0.45,
        side: THREE.DoubleSide,
        depthWrite: false,
      })
    );
    this.missionBeacon.visible = false;
    this.scene.add(this.missionBeacon);

    this.waypointBeacon = new THREE.Mesh(
      new THREE.CylinderGeometry(2.6, 2.6, 18, 20, 1, true),
      new THREE.MeshBasicMaterial({
        color: '#38bdf8',
        transparent: true,
        opacity: 0.4,
        side: THREE.DoubleSide,
        depthWrite: false,
      })
    );
    this.waypointBeacon.visible = false;
    this.scene.add(this.waypointBeacon);

    // 8. Rain Particle System
    const rainCount = 900;
    this.rainPositions = new Float32Array(rainCount * 3);
    for (let i = 0; i < rainCount; i++) {
      this.rainPositions[i * 3] = (Math.random() - 0.5) * 90;
      this.rainPositions[i * 3 + 1] = Math.random() * 40;
      this.rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const rainGeo = new THREE.BufferGeometry();
    rainGeo.setAttribute('position', new THREE.BufferAttribute(this.rainPositions, 3));
    const rainMat = new THREE.PointsMaterial({
      color: '#bae6fd',
      size: 0.25,
      transparent: true,
      opacity: 0.65,
    });
    this.rainPoints = new THREE.Points(rainGeo, rainMat);
    this.rainPoints.visible = false;
    this.scene.add(this.rainPoints);

    // 9. Spawn Fleet of All 10 Drivable Vehicles + Traffic + NPCs
    this.populateInitialVehicles();
    this.populateNpcs();

    // 10. Pre-warm shaders (GPU only)
    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    // 11. Input & Resize Listeners
    this.boundKeyDown = (e) => {
      if (e.code === 'Escape') {
        if (this.phase === 'playing' || this.phase === 'paused') {
          this.callbacks.onTogglePause();
        }
        return;
      }
      if (this.phase !== 'playing') return;
      if (!this.keys.has(e.code)) {
        this.justPressed.add(e.code);
      }
      this.keys.add(e.code);
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
    };

    this.boundKeyUp = (e) => {
      this.keys.delete(e.code);
    };

    this.boundBlur = () => {
      this.keys.clear();
      this.justPressed.clear();
      this.touchMove.x = 0;
      this.touchMove.y = 0;
      this.touchGas = 0;
      this.touchBrake = 0;
      this.touchSprint = false;
    };

    this.boundResize = () => {
      const w = this.container.clientWidth || window.innerWidth;
      const h = this.container.clientHeight || window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    };

    this.boundPointerDown = (e) => {
      if (e.target !== this.renderer.domElement) return;
      soundEngine.unlock();
      this.isDraggingCam = true;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
    };

    this.boundPointerMove = (e) => {
      if (!this.isDraggingCam || this.phase !== 'playing') return;
      const dx = e.clientX - this.lastPointerX;
      const dy = e.clientY - this.lastPointerY;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
      this.camYaw -= dx * 0.0065;
      this.camPitch = THREE.MathUtils.clamp(this.camPitch + dy * 0.005, -0.2, 1.1);
      this.manualCamCooldown = 5.0;
    };

    this.boundPointerUp = () => {
      this.isDraggingCam = false;
    };

    window.addEventListener('keydown', this.boundKeyDown);
    window.addEventListener('keyup', this.boundKeyUp);
    window.addEventListener('blur', this.boundBlur);
    window.addEventListener('resize', this.boundResize);
    this.renderer.domElement.addEventListener('pointerdown', this.boundPointerDown);
    window.addEventListener('pointermove', this.boundPointerMove);
    window.addEventListener('pointerup', this.boundPointerUp);
    window.addEventListener('pointercancel', this.boundPointerUp);

    this.applyAtmosphere();
    this.startLoop();
  }

  private populateInitialVehicles() {
    // Player starter vehicles parked right outside starter plaza & home
    this.spawnVehicle('mehran', 12, -48, Math.PI * 0.5, false, '#f8fafc');
    this.spawnVehicle('motorcycle', 22, -48, Math.PI * 0.2, false, '#dc2626');
    this.spawnVehicle('civic', 38, -32, 0, false, '#dc2626'); // Near Car Shop
    this.spawnVehicle('land_cruiser', 348, 220, -Math.PI * 0.5, false, '#111827'); // DHA
    this.spawnVehicle('corolla', -12, 212, Math.PI * 0.5, false, '#cbd5e1'); // Clifton Teen Talwar
    this.spawnVehicle('alto', 180, -130, 0, false, '#38bdf8'); // Tariq Road
    this.spawnVehicle('rickshaw', -182, 24, Math.PI * 0.5, false, '#16a34a'); // Saddar
    this.spawnVehicle('bus', -30, -6, Math.PI * 0.5, false, '#ec4899'); // Shahrah-e-Faisal W-11
    this.spawnVehicle('truck', 455, 112, -Math.PI * 0.5, false, '#f59e0b'); // Korangi
    this.spawnVehicle('civic', 372, -295, Math.PI, false, '#0284c7'); // Gulshan Chowrangi
    this.spawnVehicle('mehran', -390, -195, 0, false, '#facc15'); // Lyari
    // Boats moored along Sea View & Karachi Port waters
    this.spawnVehicle('boat', -410, 392, Math.PI * 0.45, false, '#f8fafc');
    this.spawnVehicle('boat', 45, 388, 0, false, '#0ea5e9');
    this.spawnVehicle('boat', 280, 392, -Math.PI * 0.25, false, '#f8fafc');

    // Autonomous Karachi Traffic AI vehicles spread across the 1.4km mega-city
    const trafficDefs: { type: VehicleType; x: number; z: number; dx: number; dz: number; color: string }[] = [
      { type: 'rickshaw', x: -240, z: -5, dx: 1, dz: 0, color: '#16a34a' },
      { type: 'mehran', x: 160, z: 6, dx: -1, dz: 0, color: '#e2e8f0' },
      { type: 'bus', x: -450, z: -6, dx: 1, dz: 0, color: '#ec4899' },
      { type: 'civic', x: 420, z: 6, dx: -1, dz: 0, color: '#b91c1c' },
      { type: 'corolla', x: 5, z: 75, dx: 0, dz: 1, color: '#475569' },
      { type: 'alto', x: -5, z: -210, dx: 0, dz: -1, color: '#0284c7' },
      { type: 'truck', x: 310, z: 120, dx: -1, dz: 0, color: '#d97706' },
      { type: 'civic', x: -190, z: 160, dx: 0, dz: -1, color: '#b91c1c' },
      { type: 'motorcycle', x: 190, z: -55, dx: 0, dz: 1, color: '#1e293b' },
      { type: 'land_cruiser', x: 240, z: 225, dx: 1, dz: 0, color: '#0f172a' },
      { type: 'bus', x: -120, z: -280, dx: 1, dz: 0, color: '#db2777' },
      { type: 'rickshaw', x: 380, z: -180, dx: 0, dz: 1, color: '#15803d' },
      { type: 'mehran', x: -380, z: -80, dx: 0, dz: -1, color: '#f8fafc' },
      { type: 'truck', x: -560, z: 140, dx: 0, dz: 1, color: '#ea580c' },
      { type: 'corolla', x: 560, z: -100, dx: 0, dz: -1, color: '#94a3b8' },
      { type: 'alto', x: -290, z: 320, dx: 1, dz: 0, color: '#38bdf8' },
      { type: 'civic', x: 120, z: -420, dx: -1, dz: 0, color: '#111827' },
      { type: 'motorcycle', x: -420, z: -140, dx: 1, dz: 0, color: '#dc2626' },
    ];

    trafficDefs.forEach((t, idx) => {
      const v = this.spawnVehicle(
        t.type,
        t.x,
        t.z,
        Math.atan2(t.dx, t.dz),
        true,
        t.color,
        false,
        `traffic_${idx}`
      );
      v.trafficDirX = t.dx;
      v.trafficDirZ = t.dz;
    });
  }

  public spawnVehicle(
    type: VehicleType,
    x: number,
    z: number,
    yaw: number,
    isTraffic: boolean,
    color?: string,
    isPolice = false,
    idOverride?: string
  ): VehicleEntity {
    const rig = createVehicleRig(type, this.textures, color, isPolice);
    const y = type === 'boat' ? -0.25 : groundHeightAt(x, z);
    rig.group.position.set(x, y, z);
    rig.group.rotation.y = yaw;
    this.scene.add(rig.group);

    // Spawn real seated 3D human driver for Traffic AI & Police cruisers
    let driverRig: ArticulatedCharacter | undefined;
    if (isTraffic || isPolice) {
      const driverSkins = ['#c68b59', '#b57b4e', '#d8a072', '#9e663d'];
      const driverOutfit: CharacterCustomization = isPolice
        ? { style: 'modern_casual', primaryColor: '#1e293b', secondaryColor: '#eab308', accessory: 'none' }
        : {
            style: Math.random() > 0.45 ? 'shalwar_kameez' : 'modern_casual',
            primaryColor: ['#f8fafc', '#0f766e', '#334155', '#e2e8f0'][Math.floor(Math.random() * 4)],
            secondaryColor: '#dc2626',
            accessory: Math.random() > 0.65 ? 'sunglasses' : Math.random() > 0.5 ? 'sindhi_cap' : 'none',
            facialHair: Math.random() > 0.45 ? 'stubble' : 'beard',
          };
      driverRig = createCharacterRig(driverOutfit, {
        skinHex: driverSkins[Math.floor(Math.random() * driverSkins.length)],
        role: isPolice ? 'police' : 'civilian',
        textures: this.textures,
      });
      animateCharacterRig(driverRig, { mode: 'seated', walkPhase: 0, elapsedSec: 0, steerAngle: 0 });
      rig.driverMount.add(driverRig.group);
    }

    const entity: VehicleEntity = {
      id: idOverride || `${type}_${Math.random().toString(36).slice(2, 8)}`,
      type,
      rig,
      driverRig,
      x,
      y,
      z,
      yaw,
      speed: isTraffic ? 9 : 0,
      steerAngle: 0,
      isTraffic,
      isPolice,
      trafficDirX: Math.sin(yaw),
      trafficDirZ: Math.cos(yaw),
      trafficTimer: 0,
    };
    this.vehicles.push(entity);
    return entity;
  }

  private buildPlayerRig(charId: CharacterId, custom: CharacterCustomization): ArticulatedCharacter {
    const profile = CHARACTER_PROFILES[charId] || CHARACTER_PROFILES.zain;
    return createCharacterRig(custom, {
      skinHex: custom.skinTone || profile.defaultSkin,
      isFemale: Boolean(profile.isFemale),
      facialHair: custom.facialHair ?? profile.defaultCustomization.facialHair ?? 'none',
      hairColor: charId === 'tariq' ? '#475569' : '#111827',
      textures: this.textures,
      contactShadowTex: this.textures.contactShadow,
    });
  }

  private createVendorCartMesh(): THREE.Group {
    const cart = new THREE.Group();
    const woodMat = new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.8 });
    const steelMat = new THREE.MeshStandardMaterial({ color: '#cbd5e1', metalness: 0.8, roughness: 0.25 });
    const awningMat = new THREE.MeshStandardMaterial({ color: '#dc2626', roughness: 0.7 });

    const counter = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.85, 0.85), woodMat);
    counter.position.set(0, 0.62, 0);
    counter.castShadow = true;
    cart.add(counter);

    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.2, 0.28, 12), steelMat);
    pot.position.set(-0.38, 1.18, 0);
    cart.add(pot);

    const canopy = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.08, 1.05), awningMat);
    canopy.position.set(0, 2.05, 0);
    cart.add(canopy);

    [
      [-0.8, -0.38],
      [0.8, -0.38],
      [-0.8, 0.38],
      [0.8, 0.38],
    ].forEach(([px, pz]) => {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.05, 8), steelMat);
      pole.position.set(px, 1.52, pz);
      cart.add(pole);
    });

    [-0.65, 0.65].forEach((wx) => {
      const wheel = new THREE.Mesh(
        new THREE.CylinderGeometry(0.22, 0.22, 0.08, 12),
        new THREE.MeshStandardMaterial({ color: '#18181b', roughness: 0.85 })
      );
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(wx, 0.22, 0);
      cart.add(wheel);
    });
    return cart;
  }

  private populateNpcs() {
    const outfits: CharacterCustomization[] = [
      { style: 'shalwar_kameez', primaryColor: '#f8fafc', secondaryColor: '#cbd5e1', accessory: 'none', facialHair: 'beard' },
      { style: 'kurta_waistcoat', primaryColor: '#fef3c7', secondaryColor: '#1e293b', accessory: 'sindhi_cap', facialHair: 'stubble' },
      { style: 'ajrak_street', primaryColor: '#0f172a', secondaryColor: '#b91c1c', accessory: 'sunglasses', facialHair: 'stubble' },
      { style: 'shalwar_kameez', primaryColor: '#0d9488', secondaryColor: '#f8fafc', accessory: 'none', facialHair: 'none' },
      { style: 'modern_casual', primaryColor: '#2563eb', secondaryColor: '#1e293b', accessory: 'cap', facialHair: 'none' },
      { style: 'shalwar_kameez', primaryColor: '#e2e8f0', secondaryColor: '#475569', accessory: 'none', facialHair: 'beard' },
      { style: 'modern_casual', primaryColor: '#ec4899', secondaryColor: '#f8fafc', accessory: 'sunglasses', facialHair: 'none' },
    ];
    const skins = ['#c68b59', '#b57b4e', '#d8a072', '#a66e43', '#cf9564'];

    // 1. Real Karachi Pedestrians across all 12 districts
    const pedestrianSpots: [number, number][] = [
      [12, -55], [22, -62], [-16, 232], [40, 326], [120, 326], [-80, 328], [210, 328],
      [-175, 14], [-198, 28], [182, -132], [202, -120], [352, 238], [368, 215],
      [-430, -195], [-448, -210], [460, 112], [478, 128], [-515, 322], [-530, 336],
      [382, -335], [360, -345], [-375, 18], [548, 220], [12, -415], [-185, -275],
      [555, -275], [-555, -135], [-12, -142], [18, -142], [-255, 116], [-235, 134],
      [62, 250], [-65, 250], [-40, -18], [38, -20],
    ];

    pedestrianSpots.forEach(([nx, nz], idx) => {
      const custom = outfits[idx % outfits.length];
      const isFemale = idx % 4 === 3 || idx % 7 === 6;
      const isElder = idx % 6 === 0;
      const rig = createCharacterRig(custom, {
        skinHex: skins[idx % skins.length],
        isFemale,
        facialHair: isFemale ? 'none' : custom.facialHair,
        hairColor: isElder ? '#64748b' : '#111827',
        heightScale: isFemale ? 0.95 : 0.96 + (idx % 4) * 0.025,
        widthScale: isFemale ? 0.9 : 0.96 + (idx % 3) * 0.03,
        textures: this.textures,
      });
      rig.group.position.set(nx, groundHeightAt(nx, nz), nz);
      this.scene.add(rig.group);
      this.npcs.push({
        rig,
        x: nx,
        z: nz,
        yaw: (idx * 1.4) % (Math.PI * 2),
        speed: 1.55 + (idx % 3) * 0.35,
        role: 'pedestrian',
        walkPhase: idx,
        turnTimer: 3 + (idx % 5),
        fleeTimer: 0,
        blinkSeed: idx * 0.73,
      });
    });

    // 2. Authentic Street Vendors with 3D Chai / Biryani Carts
    const vendorSpots: [number, number, number][] = [
      [-240, 128, 0],
      [-262, 144, Math.PI * 0.5],
      [-182, 24, Math.PI],
      [205, -130, -Math.PI * 0.5],
      [372, -295, 0],
      [45, 336, Math.PI],
      [-435, -198, Math.PI * 0.4],
    ];

    vendorSpots.forEach(([vx, vz, vyaw], idx) => {
      const rig = createCharacterRig(
        { style: 'shalwar_kameez', primaryColor: '#e2e8f0', secondaryColor: '#b91c1c', accessory: idx % 2 === 0 ? 'sindhi_cap' : 'none', facialHair: 'beard' },
        { skinHex: skins[(idx + 1) % skins.length], role: 'vendor', textures: this.textures }
      );
      const y = groundHeightAt(vx, vz);
      rig.group.position.set(vx, y, vz);
      rig.group.rotation.y = vyaw;
      this.scene.add(rig.group);

      const cart = this.createVendorCartMesh();
      cart.position.set(vx + Math.sin(vyaw) * 1.15, y, vz + Math.cos(vyaw) * 1.15);
      cart.rotation.y = vyaw;
      this.scene.add(cart);

      this.npcs.push({
        rig,
        x: vx,
        z: vz,
        yaw: vyaw,
        speed: 0,
        role: 'vendor',
        walkPhase: idx,
        turnTimer: 99,
        fleeTimer: 0,
        blinkSeed: idx * 1.1,
      });
    });

    // 3. Real Shopkeepers & Bank / Home Personnel stationed at KARACHI_PLACES
    KARACHI_PLACES.forEach((p, idx) => {
      const sx = p.x + 2.4;
      const sz = p.z + 1.8;
      const rig = createCharacterRig(
        {
          style: p.type === 'bank' || p.type === 'dealership' ? 'kurta_waistcoat' : 'shalwar_kameez',
          primaryColor: p.type === 'bank' ? '#f8fafc' : '#cbd5e1',
          secondaryColor: p.type === 'bank' ? '#065f46' : '#1e3a8a',
          accessory: p.type === 'phone_shop' ? 'sunglasses' : 'none',
          facialHair: idx % 2 === 0 ? 'stubble' : 'beard',
        },
        { skinHex: skins[idx % skins.length], role: 'shopkeeper', textures: this.textures }
      );
      rig.group.position.set(sx, groundHeightAt(sx, sz), sz);
      rig.group.rotation.y = -Math.PI * 0.35;
      this.scene.add(rig.group);
      this.npcs.push({
        rig,
        x: sx,
        z: sz,
        yaw: -Math.PI * 0.35,
        speed: 0,
        role: 'shopkeeper',
        walkPhase: idx,
        turnTimer: 99,
        fleeTimer: 0,
        blinkSeed: idx * 0.91,
      });
    });

    // 4. Real Karachi Sindh Police Officers stationed at city hubs
    const policePosts: [number, number][] = [
      [-10, -125], // Mazar-e-Quaid
      [-18, -12],  // Shahrah-e-Faisal / K-Bank
      [-172, 8],   // Saddar Empress Market
      [14, 212],   // Clifton Teen Talwar
      [-498, 315], // Karachi Port Gate
      [350, 212],  // DHA Phase 8
    ];
    policePosts.forEach(([px, pz], idx) => {
      const rig = createCharacterRig(
        { style: 'modern_casual', primaryColor: '#1e293b', secondaryColor: '#eab308', accessory: 'none', facialHair: 'stubble' },
        { skinHex: skins[(idx + 2) % skins.length], role: 'police', textures: this.textures }
      );
      rig.group.position.set(px, groundHeightAt(px, pz), pz);
      this.scene.add(rig.group);
      this.npcs.push({
        rig,
        x: px,
        z: pz,
        yaw: (idx * 0.9) % (Math.PI * 2),
        speed: 1.4,
        role: 'police',
        walkPhase: idx,
        turnTimer: 4,
        fleeTimer: 0,
        blinkSeed: idx * 1.37,
      });
    });
  }

  // Public Controls / Bridge Methods
  public setPhase(phase: GamePhase) {
    this.phase = phase;
    if (phase !== 'playing') {
      soundEngine.stopEngine();
      soundEngine.stopSiren();
    } else {
      soundEngine.unlock();
    }
  }

  public setCash(cash: number) {
    this.cash = cash;
  }

  public switchCharacter(charId: CharacterId, custom: CharacterCustomization) {
    this.activeCharId = charId;
    this.charCustom = custom;
    const wasVisible = this.playerRig.group.visible;
    if (this.playerRig.group.parent) {
      this.playerRig.group.parent.remove(this.playerRig.group);
    }
    this.playerRig = this.buildPlayerRig(charId, custom);
    if (this.activeVehicle) {
      this.playerRig.group.position.set(0, 0, 0);
      this.playerRig.group.rotation.set(0, 0, 0);
      this.playerRig.group.visible = this.cameraMode !== 'first_person';
      this.activeVehicle.rig.driverMount.add(this.playerRig.group);
    } else {
      this.playerRig.group.position.set(this.playerX, this.playerY, this.playerZ);
      this.playerRig.group.rotation.y = this.playerYaw;
      this.playerRig.group.visible = wasVisible;
      this.scene.add(this.playerRig.group);
    }
  }

  public setCameraMode(mode: CameraMode) {
    this.cameraMode = mode;
    this.playerRig.group.visible = mode !== 'first_person';
  }

  public cycleCameraMode(): CameraMode {
    const order: CameraMode[] = ['third_person', 'first_person', 'cinematic'];
    const next = order[(order.indexOf(this.cameraMode) + 1) % order.length];
    this.setCameraMode(next);
    return next;
  }

  public setTimeOfDay(hour: number, autoCycle: boolean) {
    this.timeOfDay = ((hour % 24) + 24) % 24;
    this.autoTimeCycle = autoCycle;
    this.applyAtmosphere();
  }

  public setWeather(weather: WeatherType) {
    this.weather = weather;
    this.rainPoints.visible = weather === 'rain';
    this.applyAtmosphere();
  }

  public setWaypoint(x: number, z: number, label: string) {
    this.customWaypoint = { x, z, label };
    this.waypointBeacon.position.set(x, 9, z);
    this.waypointBeacon.visible = true;
    this.callbacks.onNotification(`GPS set to ${label}`);
  }

  public clearWaypoint() {
    this.customWaypoint = null;
    this.waypointBeacon.visible = false;
  }

  public setVehicleTuningMap(tuning: Partial<Record<VehicleType, VehicleTuning>>) {
    this.vehicleTuning = tuning;
  }

  public summonVehicleNearPlayer(type: VehicleType) {
    if (this.activeVehicle) {
      this.exitActiveVehicle();
    }
    let sx = this.playerX + Math.sin(this.playerYaw) * 4.5;
    let sz = this.playerZ + Math.cos(this.playerYaw) * 4.5;
    if (type === 'boat') {
      // Spawn boat right off Sea View / Karachi Port shore and warp player to shoreline
      sx = this.playerX < -160 ? -420 : 45;
      sz = 385;
      this.playerX = sx;
      this.playerZ = 358;
      this.playerY = groundHeightAt(this.playerX, this.playerZ);
    }
    const customColor = this.vehicleTuning[type]?.color;
    const v = this.spawnVehicle(type, sx, sz, this.playerYaw, false, customColor);
    this.callbacks.onNotification(`${VEHICLE_SPECS[type].name} delivered nearby`);
    if (type !== 'boat') {
      this.enterVehicle(v);
    }
  }

  public teleportToHome(x: number, z: number) {
    if (this.activeVehicle) {
      this.exitActiveVehicle();
    }
    this.playerX = x;
    this.playerZ = z;
    this.playerY = groundHeightAt(x, z);
    this.playerVy = 0;
    this.callbacks.onNotification('Arrived at your Karachi Home');
  }

  public captureFrameDataUrl(): string {
    this.renderer.render(this.scene, this.camera);
    try {
      return this.renderer.domElement.toDataURL('image/jpeg', 0.78);
    } catch {
      return '';
    }
  }

  public startVideoRecording(): boolean {
    if (this.isRecordingVideo) return true;
    this.isRecordingVideo = true;
    this.recordingStartMs = performance.now();
    this.recordingActionScore = 25;
    this.recordingDistricts.clear();
    this.recordingDistricts.add(this.getCurrentDistrict().name);
    this.recordingThumbnail = this.captureFrameDataUrl();
    this.recordedChunks = [];
    this.mediaRecorder = null;

    try {
      const canvas = this.renderer.domElement as HTMLCanvasElement & {
        captureStream?: (fps?: number) => MediaStream;
      };
      if (typeof canvas.captureStream === 'function' && typeof MediaRecorder !== 'undefined') {
        const stream = canvas.captureStream(24);
        const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp8')
          ? 'video/webm;codecs=vp8'
          : MediaRecorder.isTypeSupported('video/webm')
            ? 'video/webm'
            : '';
        const recorder = mimeType
          ? new MediaRecorder(stream, { mimeType })
          : new MediaRecorder(stream);
        recorder.ondataavailable = (ev) => {
          if (ev.data && ev.data.size > 0) {
            this.recordedChunks.push(ev.data);
          }
        };
        recorder.start(250);
        this.mediaRecorder = recorder;
      }
    } catch {
      // Fallback: thumbnail + gameplay telemetry capture still succeeds
      this.mediaRecorder = null;
    }

    this.callbacks.onNotification('Recording Karachi gameplay video...');
    return true;
  }

  public async stopVideoRecording(): Promise<RecordedClipDraft | null> {
    if (!this.isRecordingVideo) return null;
    this.isRecordingVideo = false;
    const durationSec = Math.max(1, Math.round((performance.now() - this.recordingStartMs) / 1000));
    const endThumb = this.captureFrameDataUrl();
    const thumbnailDataUrl = endThumb || this.recordingThumbnail;
    const district = this.getCurrentDistrict().name;
    const actionScore = Math.round(
      this.recordingActionScore + this.recordingDistricts.size * 20 + durationSec * 3
    );

    let videoUrl: string | undefined;
    const recorder = this.mediaRecorder;
    this.mediaRecorder = null;

    if (recorder && recorder.state !== 'inactive') {
      videoUrl = await new Promise<string | undefined>((resolve) => {
        recorder.onstop = () => {
          try {
            if (this.recordedChunks.length > 0) {
              const blob = new Blob(this.recordedChunks, { type: recorder.mimeType || 'video/webm' });
              resolve(URL.createObjectURL(blob));
              return;
            }
          } catch {
            // ignore
          }
          resolve(undefined);
        };
        try {
          recorder.stop();
        } catch {
          resolve(undefined);
        }
      });
    }

    return {
      thumbnailDataUrl,
      videoUrl,
      durationSec,
      actionScore,
      district,
    };
  }

  public startMission(mission: MissionDef) {
    if (this.activeMission) {
      this.callbacks.onNotification('Finished previous route; starting new mission.');
    }
    this.activeMission = {
      def: mission,
      waypointIndex: 0,
      timeLeft: mission.timeLimitSec ?? null,
    };
    if (mission.requiredVehicle) {
      this.summonVehicleNearPlayer(mission.requiredVehicle);
    }
    if (mission.wantedOnStart && mission.wantedOnStart > this.wantedLevel) {
      this.setWantedLevel(mission.wantedOnStart);
    }
    const wp = mission.waypoints[0];
    this.missionBeacon.position.set(wp.x, 8, wp.z);
    this.missionBeacon.visible = true;
    this.callbacks.onNotification(`Mission Started: ${mission.title}`);
  }

  public abortMission() {
    this.activeMission = null;
    this.missionBeacon.visible = false;
  }

  public restoreFullHealth() {
    this.health = this.maxHealth;
    this.stamina = 100;
  }

  public respawnAtHospital() {
    if (this.activeVehicle) {
      this.exitActiveVehicle();
    }
    this.playerX = -175; // Near Saddar / Jinnah Hospital corridor
    this.playerZ = 25;
    this.playerY = groundHeightAt(this.playerX, this.playerZ);
    this.playerVy = 0;
    this.health = 100;
    this.stamina = 100;
    this.wantedLevel = 0;
    this.wantedCooldown = 0;
    this.clearPolicePursuit();
    this.phase = 'playing';
  }

  // Mobile Touch Input Bridges
  public setTouchJoystick(x: number, y: number) {
    this.touchMove.x = x;
    this.touchMove.y = y;
  }
  public setTouchSteer(steer: number) {
    this.touchSteer = steer;
  }
  public setTouchPedals(gas: number, brake: number) {
    this.touchGas = gas;
    this.touchBrake = brake;
  }
  public setTouchHandbrake(active: boolean) {
    this.touchHandbrake = active;
  }
  public setTouchBoost(active: boolean) {
    this.touchBoost = active;
  }
  public setTouchSprint(active: boolean) {
    this.touchSprint = active;
  }
  public triggerJump() {
    this.justPressed.add('Space');
  }
  public triggerEnterExit() {
    this.justPressed.add('KeyF');
  }
  public triggerInteract() {
    this.justPressed.add('KeyE');
  }
  public triggerHorn() {
    if (this.activeVehicle) {
      soundEngine.playHorn(this.activeVehicle.type);
    } else {
      soundEngine.playPhonePing();
    }
  }
  public recenterCamera() {
    this.manualCamCooldown = 0;
    this.camPitch = 0.28;
    if (this.activeVehicle) {
      this.camYaw = this.activeVehicle.yaw + Math.PI;
    } else {
      this.camYaw = this.playerYaw + Math.PI;
    }
  }

  public getPlayerPosition() {
    return { x: this.playerX, y: this.playerY, z: this.playerZ };
  }

  private setWantedLevel(stars: number) {
    const next = Math.min(5, Math.max(0, stars));
    if (next > this.wantedLevel) {
      this.wantedLevel = next;
      this.wantedCooldown = 16;
      this.ensurePolicePursuit(next);
    }
  }

  private ensurePolicePursuit(stars: number) {
    const activePolice = this.vehicles.filter((v) => v.isPolice).length;
    const needed = Math.min(3, stars);
    for (let i = activePolice; i < needed; i++) {
      const ang = (i * Math.PI * 2) / 3 + Math.random();
      const px = THREE.MathUtils.clamp(this.playerX + Math.cos(ang) * 65, -660, 660);
      const pz = THREE.MathUtils.clamp(this.playerZ + Math.sin(ang) * 65, -580, 325);
      this.spawnVehicle('corolla', px, pz, 0, false, '#f8fafc', true);
    }
  }

  private clearPolicePursuit() {
    this.vehicles = this.vehicles.filter((v) => {
      if (v.isPolice && v !== this.activeVehicle) {
        this.scene.remove(v.rig.group);
        return false;
      }
      return true;
    });
  }

  private applyAtmosphere() {
    // 24h cycle lighting & horizon fog matching
    const h = this.timeOfDay;
    const isNight = h < 5.5 || h > 19.2;
    const isGolden = (h >= 16.5 && h <= 19.2) || (h >= 5.5 && h <= 7.5);
    const isRain = this.weather === 'rain';
    const isOvercast = this.weather === 'overcast';

    if (isRain) {
      _skyColor.set(isNight ? '#090d16' : '#334155');
      _sunColor.set('#94a3b8');
      this.sunLight.intensity = isNight ? 0.35 : 0.75;
      this.hemiLight.intensity = isNight ? 0.35 : 0.55;
      this.world.roadMaterial.roughness = 0.22; // Wet reflective asphalt!
    } else if (isOvercast) {
      _skyColor.set(isNight ? '#0b1120' : '#64748b');
      _sunColor.set('#cbd5e1');
      this.sunLight.intensity = isNight ? 0.35 : 0.95;
      this.hemiLight.intensity = 0.65;
      this.world.roadMaterial.roughness = 0.65;
    } else if (isNight) {
      _skyColor.set('#070b18');
      _sunColor.set('#93c5fd');
      this.sunLight.intensity = 0.32;
      this.hemiLight.intensity = 0.34;
      this.world.roadMaterial.roughness = 0.68;
    } else if (isGolden || this.weather === 'golden') {
      _skyColor.set('#fb923c').lerp(new THREE.Color('#4c1d95'), 0.28);
      _sunColor.set('#fdba74');
      this.sunLight.intensity = 1.65;
      this.hemiLight.intensity = 0.62;
      this.world.roadMaterial.roughness = 0.62;
    } else {
      _skyColor.set('#38bdf8');
      _sunColor.set('#fffbeb');
      this.sunLight.intensity = 1.85;
      this.hemiLight.intensity = 0.72;
      this.world.roadMaterial.roughness = 0.7;
    }

    this.scene.background = _skyColor.clone();
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.color.copy(_skyColor);
      this.scene.fog.density = isRain ? 0.0042 : isNight ? 0.0026 : 0.0019;
    }
    this.sunLight.color.copy(_sunColor);

    // Night window glow & streetlight brightness
    const nightMix = isNight ? 1.0 : isGolden ? 0.55 : 0.12;
    this.world.modernBuildingMat.emissiveIntensity = nightMix;
    this.world.streetLightBulbs.color.set(isNight || isGolden ? '#fde047' : '#94a3b8');

    const sunAngle = ((h - 6) / 12) * Math.PI;
    const sunElev = Math.max(0.15, Math.sin(sunAngle));
    this.sunLight.position.set(
      this.playerX + Math.cos(sunAngle) * 90,
      Math.max(25, sunElev * 130),
      this.playerZ + 55
    );
    this.sunLight.target.position.set(this.playerX, 0, this.playerZ);

    // Position Celestial Sun/Moon Disc
    this.world.sunDisc.position.set(
      this.playerX + Math.cos(sunAngle) * 320,
      Math.max(18, Math.sin(sunAngle) * 260),
      this.playerZ - 260
    );
    const sunMat = this.world.sunDisc.material as THREE.MeshBasicMaterial;
    sunMat.color.set(isNight ? '#e2e8f0' : isGolden ? '#fb923c' : '#fef08a');
  }

  private resolveCircleColliders(
    x: number,
    z: number,
    radius: number,
    colliders: BoxCollider[]
  ): { x: number; z: number; collided: boolean } {
    let rx = THREE.MathUtils.clamp(x, -715, 715);
    let rz = THREE.MathUtils.clamp(z, -635, 420);
    let collided = false;

    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      const closestX = THREE.MathUtils.clamp(rx, c.minX, c.maxX);
      const closestZ = THREE.MathUtils.clamp(rz, c.minZ, c.maxZ);
      const dx = rx - closestX;
      const dz = rz - closestZ;
      const distSq = dx * dx + dz * dz;
      if (distSq < radius * radius) {
        collided = true;
        const dist = Math.sqrt(distSq);
        if (dist > 0.0001) {
          const push = radius - dist;
          rx += (dx / dist) * push;
          rz += (dz / dist) * push;
        } else {
          rx += radius;
        }
      }
    }
    return { x: rx, z: rz, collided };
  }

  private enterVehicle(v: VehicleEntity) {
    if (v.driverRig) {
      v.rig.driverMount.remove(v.driverRig.group);
      v.driverRig = undefined;
    }
    this.activeVehicle = v;
    v.isTraffic = false;
    if (this.playerRig.group.parent) {
      this.playerRig.group.parent.remove(this.playerRig.group);
    }
    this.playerRig.group.position.set(0, 0, 0);
    this.playerRig.group.rotation.set(0, 0, 0);
    this.playerRig.group.visible = this.cameraMode !== 'first_person';
    v.rig.driverMount.add(this.playerRig.group);
    this.camYaw = v.yaw;
    soundEngine.playPhonePing();
  }

  private exitActiveVehicle() {
    if (!this.activeVehicle) return;
    const v = this.activeVehicle;
    const spec = VEHICLE_SPECS[v.type];
    const sideOffset = spec.width * 0.8 + 0.9;
    this.playerX = v.x - Math.cos(v.yaw) * sideOffset;
    this.playerZ = v.z + Math.sin(v.yaw) * sideOffset;
    this.playerY = groundHeightAt(this.playerX, this.playerZ);
    this.playerYaw = v.yaw;
    if (this.playerRig.group.parent) {
      this.playerRig.group.parent.remove(this.playerRig.group);
    }
    this.scene.add(this.playerRig.group);
    this.playerRig.group.position.set(this.playerX, this.playerY, this.playerZ);
    this.playerRig.group.rotation.set(0, this.playerYaw, 0);
    this.activeVehicle = null;
    this.playerRig.group.visible = this.cameraMode !== 'first_person';
    soundEngine.stopEngine();
  }

  private startLoop() {
    const tick = () => {
      if (this.destroyed) return;
      const now = performance.now();
      const rawDt = (now - this.lastTime) / 1000;
      this.lastTime = now;
      const dt = Math.min(rawDt, 0.05);

      this.update(dt, now * 0.001);
      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.afterDraw(tick);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.destroyed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private update(dt: number, elapsedSec: number) {
    // Animate ocean water 3D waves, ripples & beacon rotation on every state
    this.world.oceanUniforms.uTime.value = elapsedSec;
    this.textures.waterNormal.offset.x = (elapsedSec * 0.03) % 1;
    this.textures.waterNormal.offset.y = (elapsedSec * 0.02) % 1;
    this.world.placeBeacons.forEach((mesh) => {
      mesh.rotation.y += dt * 1.1;
    });
    if (this.missionBeacon.visible) this.missionBeacon.rotation.y += dt * 1.8;
    if (this.waypointBeacon.visible) this.waypointBeacon.rotation.y -= dt * 1.4;

    // Title Screen steady scenic wide shot over Karachi (no automatic spinning)
    if (this.phase === 'title') {
      this.camera.position.set(68, 48, 92);
      this.camera.lookAt(0, 12, -95);
      this.updateTrafficAndNpcs(dt, elapsedSec);
      this.justPressed.clear();
      return;
    }

    if (this.phase !== 'playing') {
      this.justPressed.clear();
      return;
    }

    // Hitstop freeze on heavy collisions
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      this.justPressed.clear();
      return;
    }

    // Time of Day & Rain particles
    if (this.autoTimeCycle) {
      this.timeOfDay = (this.timeOfDay + dt * 0.045) % 24;
      this.applyAtmosphere();
    }
    if (this.rainPoints.visible) {
      this.rainPoints.position.set(this.playerX, 0, this.playerZ);
      for (let i = 0; i < this.rainPositions.length; i += 3) {
        this.rainPositions[i + 1] -= dt * 28;
        if (this.rainPositions[i + 1] < 0) {
          this.rainPositions[i + 1] = 38;
        }
      }
      this.rainPoints.geometry.attributes.position.needsUpdate = true;
    }

    // Quick Keyboard Toggles
    if (this.justPressed.has('KeyC')) {
      this.cycleCameraMode();
    }
    if (this.justPressed.has('KeyV')) {
      this.recenterCamera();
    }
    if (this.justPressed.has('KeyP')) {
      this.callbacks.onTogglePhone();
    }
    if (this.justPressed.has('KeyH')) {
      this.triggerHorn();
    }

    // Find nearby vehicle & nearby place
    let nearestVehicle: VehicleEntity | null = null;
    let nearestVehicleDist = 4.4;
    for (let i = 0; i < this.vehicles.length; i++) {
      const v = this.vehicles[i];
      if (v === this.activeVehicle) continue;
      const d = Math.hypot(v.x - this.playerX, v.z - this.playerZ);
      if (d < nearestVehicleDist) {
        nearestVehicleDist = d;
        nearestVehicle = v;
      }
    }

    let nearestPlace: PlaceDef | null = null;
    let nearestPlaceDist = 5.2;
    for (let i = 0; i < KARACHI_PLACES.length; i++) {
      const p = KARACHI_PLACES[i];
      const d = Math.hypot(p.x - this.playerX, p.z - this.playerZ);
      if (d < nearestPlaceDist) {
        nearestPlaceDist = d;
        nearestPlace = p;
      }
    }

    // Enter / Exit Vehicle (F)
    if (this.justPressed.has('KeyF')) {
      if (this.activeVehicle) {
        this.exitActiveVehicle();
      } else if (nearestVehicle) {
        this.enterVehicle(nearestVehicle);
      }
    }

    // Open Shop / Restaurant / Dealership / Property (E)
    if (this.justPressed.has('KeyE') && nearestPlace && !this.activeVehicle) {
      this.callbacks.onOpenPlace(nearestPlace);
    }

    // Update Player (Driving vs On-Foot / Swimming)
    if (this.activeVehicle) {
      this.updateActiveVehicle(dt, elapsedSec);
    } else {
      this.updatePlayerOnFoot(dt, elapsedSec);
    }

    // Update Traffic AI, Police Pursuit & Pedestrians
    this.updateTrafficAndNpcs(dt, elapsedSec);

    // Update Wanted Level Cooldown & Sirens
    if (this.wantedLevel > 0) {
      let nearestCopDist = 999;
      for (let i = 0; i < this.vehicles.length; i++) {
        const v = this.vehicles[i];
        if (!v.isPolice) continue;
        const d = Math.hypot(v.x - this.playerX, v.z - this.playerZ);
        if (d < nearestCopDist) nearestCopDist = d;
      }
      if (nearestCopDist > 68) {
        this.wantedCooldown -= dt;
        if (this.wantedCooldown <= 0) {
          this.wantedLevel = Math.max(0, this.wantedLevel - 1);
          this.wantedCooldown = 14;
          if (this.wantedLevel === 0) {
            this.clearPolicePursuit();
            this.callbacks.onNotification('Police heat cleared!');
          }
        }
      } else {
        this.wantedCooldown = 12;
      }
      soundEngine.updateSiren(nearestCopDist < 85, dt);
    } else {
      soundEngine.updateSiren(false, dt);
    }

    // Update Active Mission Progress
    if (this.activeMission) {
      if (this.activeMission.timeLeft !== null) {
        this.activeMission.timeLeft -= dt;
        if (this.activeMission.timeLeft <= 0) {
          this.callbacks.onMissionFailed('Time expired!');
          this.abortMission();
        }
      }
      if (this.activeMission) {
        const wp = this.activeMission.def.waypoints[this.activeMission.waypointIndex];
        const dist = Math.hypot(wp.x - this.playerX, wp.z - this.playerZ);
        if (dist < (wp.radius ?? 7.5)) {
          soundEngine.playCash();
          if (this.activeMission.waypointIndex + 1 < this.activeMission.def.waypoints.length) {
            this.activeMission.waypointIndex++;
            const nextWp = this.activeMission.def.waypoints[this.activeMission.waypointIndex];
            this.missionBeacon.position.set(nextWp.x, 8, nextWp.z);
            this.callbacks.onNotification(`Objective updated: ${nextWp.label}`);
          } else {
            const done = this.activeMission.def;
            this.abortMission();
            this.callbacks.onMissionComplete(done);
          }
        }
      }
    }

    // Clear Custom GPS Waypoint on arrival
    if (this.customWaypoint) {
      const dw = Math.hypot(this.customWaypoint.x - this.playerX, this.customWaypoint.z - this.playerZ);
      if (dw < 8) {
        this.clearWaypoint();
        soundEngine.playPhonePing();
        this.callbacks.onNotification('Arrived at GPS destination');
      }
    }

    // Check Wasted
    if (this.health <= 0 && this.phase === 'playing') {
      this.health = 0;
      this.phase = 'wasted';
      soundEngine.stopEngine();
      soundEngine.stopSiren();
      this.callbacks.onWasted();
    }

    // Update Camera (with decaying impact shake)
    this.updateCamera(dt, elapsedSec);

    // Throttled HUD snapshot emission (~15Hz) so React never bottlenecks 60fps loop
    this.hudEmitTimer += dt;
    if (this.hudEmitTimer >= 0.065) {
      this.hudEmitTimer = 0;
      this.emitHud(nearestVehicle, nearestPlace);
    }

    this.justPressed.clear();
  }

  private updatePlayerOnFoot(dt: number, elapsedSec: number) {
    soundEngine.updateEngine(false, 0, null);

    let inX = (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0) -
      (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? 1 : 0) +
      this.touchMove.x;
    let inY = (this.keys.has('KeyW') || this.keys.has('ArrowUp') ? 1 : 0) -
      (this.keys.has('KeyS') || this.keys.has('ArrowDown') ? 1 : 0) +
      this.touchMove.y;

    const rawMag = Math.hypot(inX, inY);
    const mag = Math.min(1, rawMag);
    if (rawMag > 1) {
      inX /= rawMag;
      inY /= rawMag;
    }

    const sprinting =
      (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || this.touchSprint) &&
      mag > 0.15 &&
      this.stamina > 3;

    if (sprinting) {
      this.stamina = Math.max(0, this.stamina - dt * 20);
    } else {
      this.stamina = Math.min(100, this.stamina + dt * 18);
    }

    this.isSwimming = isWaterAt(this.playerX, this.playerZ);
    // Smooth analog walk -> jog -> sprint speed curve
    const baseSpeed = this.isSwimming ? 5.2 : sprinting ? 11.4 : 6.2 * Math.max(0.45, mag);

    let targetVx = 0;
    let targetVz = 0;
    if (mag > 0.08) {
      const forwardX = -Math.sin(this.camYaw);
      const forwardZ = -Math.cos(this.camYaw);
      const rightX = Math.cos(this.camYaw);
      const rightZ = -Math.sin(this.camYaw);

      const dirLen = Math.hypot(inX, inY) || 1;
      const nxIn = inX / dirLen;
      const nyIn = inY / dirLen;

      const moveDirX = forwardX * nyIn + rightX * nxIn;
      const moveDirZ = forwardZ * nyIn + rightZ * nxIn;
      const targetYaw = Math.atan2(moveDirX, moveDirZ);

      let diff = targetYaw - this.playerYaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.playerYaw += diff * Math.min(1, dt * 16);

      targetVx = moveDirX * baseSpeed;
      targetVz = moveDirZ * baseSpeed;
      this.walkPhase += dt * (sprinting ? 14.5 : 6.5 + mag * 4.5);
    } else {
      this.walkPhase = THREE.MathUtils.damp(this.walkPhase, Math.round(this.walkPhase / Math.PI) * Math.PI, 10, dt);
    }

    // Smooth ground acceleration / air steering / snappy stop
    const accelRate = this.isSwimming ? 10 : this.isGrounded ? (mag > 0.08 ? 18 : 15) : 7.5;
    this.playerVx = THREE.MathUtils.damp(this.playerVx, targetVx, accelRate, dt);
    this.playerVz = THREE.MathUtils.damp(this.playerVz, targetVz, accelRate, dt);

    const nextX = this.playerX + this.playerVx * dt;
    const nextZ = this.playerZ + this.playerVz * dt;
    const resolved = this.resolveCircleColliders(nextX, nextZ, 0.45, this.world.colliders);
    this.playerX = resolved.x;
    this.playerZ = resolved.z;

    // Jump & Gravity / Swim Buoyancy
    const floorY = this.isSwimming ? -0.95 : groundHeightAt(this.playerX, this.playerZ);
    if (this.isGrounded) this.coyoteTimer = 0.14;
    else this.coyoteTimer = Math.max(0, this.coyoteTimer - dt);

    if (this.justPressed.has('Space') && !this.isSwimming && this.coyoteTimer > 0) {
      this.playerVy = 8.4;
      this.isGrounded = false;
      this.coyoteTimer = 0;
      soundEngine.playJump(false);
    }

    if (this.isSwimming) {
      this.playerY = THREE.MathUtils.damp(this.playerY, floorY + Math.sin(elapsedSec * 3) * 0.08, 6, dt);
      this.playerVy = 0;
      this.isGrounded = false;
    } else {
      this.playerVy -= 21 * dt;
      this.playerY += this.playerVy * dt;
      if (this.playerY <= floorY) {
        this.playerY = floorY;
        this.playerVy = 0;
        this.isGrounded = true;
      } else {
        this.isGrounded = false;
      }
    }

    // Articulated human limb, knee, elbow & blinking animation
    const horizSpeed = Math.hypot(this.playerVx, this.playerVz);
    const animMode = this.isSwimming
      ? 'swim'
      : horizSpeed > 7.5
        ? 'run'
        : horizSpeed > 0.45
          ? 'walk'
          : 'idle';
    animateCharacterRig(this.playerRig, {
      mode: animMode,
      walkPhase: this.walkPhase,
      elapsedSec,
      blinkSeed: 0.4,
    });

    this.playerRig.group.position.set(this.playerX, this.playerY, this.playerZ);
    this.playerRig.group.rotation.y = this.playerYaw;
  }

  private updateActiveVehicle(dt: number, elapsedSec: number) {
    const v = this.activeVehicle!;
    const spec = VEHICLE_SPECS[v.type];
    const tuning = this.vehicleTuning[v.type];
    const engMult = 1 + ((tuning?.engineLevel ?? 1) - 1) * 0.18;
    const gripMult = 1 + ((tuning?.handlingLevel ?? 1) - 1) * 0.2;
    const isBoat = spec.category === 'boat';

    const boostActive = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || this.touchBoost;
    const boostSpeedMult = boostActive && !isBoat ? 1.28 : 1.0;
    const boostAccelMult = boostActive && !isBoat ? 1.38 : 1.0;

    const gas =
      (this.keys.has('KeyW') || this.keys.has('ArrowUp') ? 1 : 0) +
      Math.max(0, this.touchMove.y) +
      this.touchGas;
    const brake =
      (this.keys.has('KeyS') || this.keys.has('ArrowDown') ? 1 : 0) +
      Math.max(0, -this.touchMove.y) +
      this.touchBrake;
    const steerInput =
      (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? 1 : 0) -
      (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0) -
      this.touchMove.x -
      this.touchSteer;
    const handbrake = this.keys.has('Space') || this.touchHandbrake;

    const maxSpeed = spec.topSpeed * engMult * boostSpeedMult;
    const accel = spec.acceleration * engMult * boostAccelMult;

    if (gas > 0.05) {
      if (v.speed < -0.5) {
        v.speed += spec.braking * 1.1 * Math.min(1, gas) * dt;
      } else {
        v.speed += accel * Math.min(1, gas) * dt;
      }
    } else if (brake > 0.05) {
      if (v.speed > 0.35) {
        v.speed -= spec.braking * 1.15 * Math.min(1, brake) * dt;
      } else {
        v.speed -= accel * 0.8 * Math.min(1, brake) * dt;
      }
    } else {
      v.speed = THREE.MathUtils.damp(v.speed, 0, isBoat ? 0.9 : 1.45, dt);
    }

    if (handbrake) {
      v.speed = THREE.MathUtils.damp(v.speed, 0, Math.abs(v.speed) > 8 ? 1.85 : 4.2, dt);
    }

    v.speed = THREE.MathUtils.clamp(v.speed, -maxSpeed * 0.38, maxSpeed);

    // Speed-sensitive steering: agile in city streets, steady at high speeds
    const clampedSteer = THREE.MathUtils.clamp(steerInput, -1, 1);
    const targetSteer = clampedSteer * (handbrake ? 0.58 : 0.48);
    const steerDamp = Math.abs(clampedSteer) > 0.05 ? 18 : 14;
    v.steerAngle = THREE.MathUtils.damp(v.steerAngle, targetSteer, steerDamp, dt);

    const speedRatio = Math.min(1, Math.abs(v.speed) / maxSpeed);
    const speedFactor = Math.min(1, Math.abs(v.speed) / 3.2);
    const steerCurve = THREE.MathUtils.lerp(1.28, 0.72, speedRatio);
    const turnDir = v.speed >= -0.08 ? 1 : -1;
    const driftBonus = handbrake && Math.abs(v.speed) > 5 ? 1.42 : 1.0;
    v.yaw += v.steerAngle * spec.handling * gripMult * steerCurve * driftBonus * speedFactor * turnDir * dt * 2.45;

    const nextX = v.x + Math.sin(v.yaw) * v.speed * dt;
    const nextZ = v.z + Math.cos(v.yaw) * v.speed * dt;

    if (isBoat) {
      v.x = THREE.MathUtils.clamp(nextX, -715, 715);
      v.z = THREE.MathUtils.clamp(nextZ, 368, 660);
      v.y = -0.25 + Math.sin(performance.now() * 0.004) * 0.08;
    } else {
      const resolved = this.resolveCircleColliders(
        nextX,
        nextZ,
        spec.width * 0.55,
        this.world.colliders
      );
      if (resolved.collided && Math.abs(v.speed) > 8) {
        const impact = Math.min(1, Math.abs(v.speed) / 35);
        soundEngine.playImpact(impact);
        this.shakeIntensity = Math.max(this.shakeIntensity, impact * 0.55);
        this.hitstopTimer = impact > 0.6 ? 0.045 : 0;
        v.speed *= -0.32;
      }
      v.x = resolved.x;
      v.z = Math.min(362, resolved.z);
      v.y = groundHeightAt(v.x, v.z);
    }

    // Visual body tilt, drift slip kick & wheel/cockpit animations
    v.rig.group.position.set(v.x, v.y, v.z);
    v.rig.group.rotation.y = v.yaw;
    v.rig.bodyGroup.rotation.y = THREE.MathUtils.damp(
      v.rig.bodyGroup.rotation.y,
      handbrake && Math.abs(v.speed) > 6 ? v.steerAngle * 0.42 : 0,
      9,
      dt
    );
    v.rig.bodyGroup.rotation.z = THREE.MathUtils.damp(
      v.rig.bodyGroup.rotation.z,
      -v.steerAngle * speedFactor * (spec.category === 'bike' ? 0.58 : 0.16),
      9,
      dt
    );
    v.rig.bodyGroup.rotation.x = THREE.MathUtils.damp(
      v.rig.bodyGroup.rotation.x,
      (brake > 0.1 && v.speed > 2 ? 0.045 : gas > 0.1 ? (boostActive ? -0.045 : -0.025) : 0),
      8,
      dt
    );

    v.rig.wheels.forEach((w) => {
      w.rotation.x += v.speed * dt * 2.4;
    });
    v.rig.frontWheelPivots.forEach((p) => {
      p.rotation.y = v.steerAngle;
    });
    if (v.rig.steeringWheel) {
      v.rig.steeringWheel.rotation.z = v.steerAngle * 2.2;
    }
    v.rig.brakelights.forEach((m) => {
      m.color.set(brake > 0.1 || handbrake ? '#ff1f1f' : '#7f1d1d');
    });

    // Animate player seated inside/on the vehicle gripping steering wheel/handlebar
    animateCharacterRig(this.playerRig, {
      mode: 'seated',
      walkPhase: 0,
      elapsedSec,
      steerAngle: v.steerAngle,
      blinkSeed: 0.4,
    });

    // Keep player coords synced to vehicle
    this.playerX = v.x;
    this.playerY = v.y;
    this.playerZ = v.z;
    this.playerYaw = v.yaw;

    soundEngine.updateEngine(true, Math.abs(v.speed) / spec.topSpeed, v.type);
  }

  private updateTrafficAndNpcs(dt: number, elapsedSec: number) {
    // 1. Traffic & Police Pursuit Vehicles
    for (let i = 0; i < this.vehicles.length; i++) {
      const v = this.vehicles[i];
      if (v === this.activeVehicle) continue;

      if (v.isPolice) {
        const dx = this.playerX - v.x;
        const dz = this.playerZ - v.z;
        const dist = Math.hypot(dx, dz);
        const targetYaw = Math.atan2(dx, dz);
        let diff = targetYaw - v.yaw;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        v.yaw += THREE.MathUtils.clamp(diff, -2.5 * dt, 2.5 * dt);
        v.speed = dist > 9 ? Math.min(27, 15 + this.wantedLevel * 3) : 6;

        const nx = v.x + Math.sin(v.yaw) * v.speed * dt;
        const nz = v.z + Math.cos(v.yaw) * v.speed * dt;
        const res = this.resolveCircleColliders(nx, nz, 1.3, this.world.colliders);
        v.x = res.x;
        v.z = Math.min(355, res.z);
        v.y = groundHeightAt(v.x, v.z);
        if (res.collided) v.yaw += 1.1;

        if (v.rig.sirenBars) {
          const flash = Math.floor(elapsedSec * 8) % 2 === 0;
          v.rig.sirenBars.red.color.set(flash ? '#ff2222' : '#450a0a');
          v.rig.sirenBars.blue.color.set(flash ? '#1e3a8a' : '#38bdf8');
        }

        // Police ramming damage if chasing player
        if (this.phase === 'playing' && dist < 2.8) {
          this.health = Math.max(0, this.health - dt * 16);
          this.shakeIntensity = Math.max(this.shakeIntensity, 0.3);
        }
      } else if (v.isTraffic) {
        // Check distance to player to brake politely unless player rams
        const distPlayer = Math.hypot(this.playerX - v.x, this.playerZ - v.z);
        const targetSpd = distPlayer < 9 ? 0 : 11;
        v.speed = THREE.MathUtils.damp(v.speed, targetSpd, 4, dt);

        const nx = v.x + v.trafficDirX * v.speed * dt;
        const nz = v.z + v.trafficDirZ * v.speed * dt;
        if (Math.abs(nx) > 680 || nz > 325 || nz < -580) {
          v.trafficDirX *= -1;
          v.trafficDirZ *= -1;
          v.yaw = Math.atan2(v.trafficDirX, v.trafficDirZ);
        } else {
          v.x = nx;
          v.z = nz;
        }
        v.y = groundHeightAt(v.x, v.z);
      }

      // Vehicle-to-Player collision check (triggers Wanted Star if player rams traffic hard!)
      if (this.activeVehicle && this.phase === 'playing') {
        const dx = this.activeVehicle.x - v.x;
        const dz = this.activeVehicle.z - v.z;
        const dist = Math.hypot(dx, dz);
        if (dist < 2.9 && dist > 0.01) {
          const push = (2.9 - dist) * 0.5;
          this.activeVehicle.x += (dx / dist) * push;
          this.activeVehicle.z += (dz / dist) * push;
          v.x -= (dx / dist) * push;
          v.z -= (dz / dist) * push;
          if (Math.abs(this.activeVehicle.speed) > 13) {
            soundEngine.playImpact(0.65);
            this.shakeIntensity = Math.max(this.shakeIntensity, 0.35);
            this.activeVehicle.speed *= 0.45;
            this.setWantedLevel(this.wantedLevel + 1);
          }
        }
      }

      v.rig.group.position.set(v.x, v.y, v.z);
      v.rig.group.rotation.y = v.yaw;
      v.rig.wheels.forEach((w) => {
        w.rotation.x += v.speed * dt * 2.2;
      });
      if (v.driverRig) {
        animateCharacterRig(v.driverRig, {
          mode: 'seated',
          walkPhase: 0,
          elapsedSec,
          steerAngle: v.steerAngle,
          blinkSeed: i * 0.7,
        });
      }
    }

    // 2. Real Karachi Pedestrians, Shopkeepers, Vendors & Police Officers AI
    for (let i = 0; i < this.npcs.length; i++) {
      const npc = this.npcs[i];
      const distPlayer = Math.hypot(this.playerX - npc.x, this.playerZ - npc.z);

      // If player speeds past closely, pedestrians panic & flee!
      if (this.activeVehicle && Math.abs(this.activeVehicle.speed) > 14 && distPlayer < 6 && npc.role === 'pedestrian') {
        npc.fleeTimer = 4;
        npc.yaw = Math.atan2(npc.x - this.playerX, npc.z - this.playerZ);
        if (distPlayer < 2.0) {
          this.setWantedLevel(this.wantedLevel + 1);
          soundEngine.playImpact(0.4);
        }
      }

      if (npc.role === 'police' && this.wantedLevel > 0 && distPlayer < 48) {
        // Police officer pursues player on foot!
        npc.yaw = Math.atan2(this.playerX - npc.x, this.playerZ - npc.z);
        const spd = 4.6;
        const nx = npc.x + Math.sin(npc.yaw) * spd * dt;
        const nz = npc.z + Math.cos(npc.yaw) * spd * dt;
        const res = this.resolveCircleColliders(nx, nz, 0.4, this.world.colliders);
        npc.x = res.x;
        npc.z = Math.min(358, res.z);
        npc.walkPhase += dt * spd * 3.1;
        animateCharacterRig(npc.rig, {
          mode: 'run',
          walkPhase: npc.walkPhase,
          elapsedSec,
          blinkSeed: npc.blinkSeed,
        });
        if (this.phase === 'playing' && distPlayer < 1.8) {
          this.health = Math.max(0, this.health - dt * 14);
        }
      } else if (npc.role === 'pedestrian' || npc.role === 'police') {
        const spd = npc.fleeTimer > 0 ? 5.4 : npc.speed;
        if (npc.fleeTimer > 0) npc.fleeTimer -= dt;
        npc.turnTimer -= dt;
        if (npc.turnTimer <= 0) {
          npc.yaw += (Math.random() - 0.5) * 2.1;
          npc.turnTimer = 3 + Math.random() * 5;
        }
        const nx = npc.x + Math.sin(npc.yaw) * spd * dt;
        const nz = npc.z + Math.cos(npc.yaw) * spd * dt;
        const res = this.resolveCircleColliders(nx, nz, 0.4, this.world.colliders);
        npc.x = res.x;
        npc.z = Math.min(358, res.z);
        if (res.collided) npc.yaw += Math.PI * 0.7;

        npc.walkPhase += dt * spd * 3.2;
        animateCharacterRig(npc.rig, {
          mode: npc.fleeTimer > 0 ? 'run' : 'walk',
          walkPhase: npc.walkPhase,
          elapsedSec,
          blinkSeed: npc.blinkSeed,
        });
      } else if (npc.role === 'vendor') {
        animateCharacterRig(npc.rig, {
          mode: 'vendor',
          walkPhase: npc.walkPhase,
          elapsedSec,
          blinkSeed: npc.blinkSeed,
        });
      } else {
        // Shopkeeper turns gently toward nearby player & breathes/blinks naturally
        if (distPlayer < 10) {
          const targetYaw = Math.atan2(this.playerX - npc.x, this.playerZ - npc.z);
          let dYaw = targetYaw - npc.yaw;
          while (dYaw > Math.PI) dYaw -= Math.PI * 2;
          while (dYaw < -Math.PI) dYaw += Math.PI * 2;
          npc.yaw += dYaw * Math.min(1, dt * 4);
        }
        animateCharacterRig(npc.rig, {
          mode: 'idle',
          walkPhase: 0,
          elapsedSec,
          blinkSeed: npc.blinkSeed,
        });
      }

      npc.rig.group.position.set(npc.x, groundHeightAt(npc.x, npc.z), npc.z);
      npc.rig.group.rotation.y = npc.yaw;
    }
  }

  private updateCamera(dt: number, _elapsedSec: number) {
    if (this.manualCamCooldown > 0) {
      this.manualCamCooldown = Math.max(0, this.manualCamCooldown - dt);
    }

    // Decay impact camera shake
    this.shakeIntensity = Math.max(0, this.shakeIntensity - dt * 1.9);
    const shakeX = (Math.random() - 0.5) * this.shakeIntensity;
    const shakeY = (Math.random() - 0.5) * this.shakeIntensity;

    if (this.cameraMode === 'first_person') {
      if (this.activeVehicle) {
        const v = this.activeVehicle;
        const spec = VEHICLE_SPECS[v.type];
        const cosY = Math.cos(v.yaw);
        const sinY = Math.sin(v.yaw);
        const localX = spec.seatOffset.x;
        const localZ = spec.seatOffset.z;
        const eyeX = v.x + localX * cosY + localZ * sinY;
        const eyeY = v.y + spec.seatOffset.y + 0.16;
        const eyeZ = v.z - localX * sinY + localZ * cosY;

        this.camera.position.set(eyeX + shakeX * 0.3, eyeY + shakeY * 0.3, eyeZ);
        const lookDist = 18;
        const lookYaw = this.isDraggingCam || this.manualCamCooldown > 0 ? this.camYaw : v.yaw;
        this.camera.lookAt(
          eyeX + Math.sin(lookYaw) * lookDist,
          eyeY - 0.45,
          eyeZ + Math.cos(lookYaw) * lookDist
        );
      } else {
        const bob = Math.sin(this.walkPhase * 2) * 0.04;
        const eyeY = this.playerY + 1.62 + bob;
        this.camera.position.set(this.playerX, eyeY, this.playerZ);
        this.camera.lookAt(
          this.playerX - Math.sin(this.camYaw) * 12,
          eyeY - Math.sin(this.camPitch) * 6,
          this.playerZ - Math.cos(this.camYaw) * 12
        );
      }
      return;
    }

    if (this.cameraMode === 'cinematic') {
      // Steady Wide Aerial Chase Cam (no automatic orbiting!)
      const target = this.activeVehicle ? this.activeVehicle : { x: this.playerX, y: this.playerY, z: this.playerZ };
      _camDesired.set(
        target.x + Math.sin(this.camYaw) * 16,
        target.y + 8.5 + Math.sin(this.camPitch) * 5,
        target.z + Math.cos(this.camYaw) * 16
      );
      this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, _camDesired.x, 5, dt);
      this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, _camDesired.y, 5, dt);
      this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, _camDesired.z, 5, dt);
      this.camera.lookAt(target.x, target.y + 1.5, target.z);
      return;
    }

    // GTA 5-style Third-Person Smooth Follow Camera (no auto-spin when stopped, reversing, or dragging)
    if (this.activeVehicle) {
      const v = this.activeVehicle;
      const spec = VEHICLE_SPECS[v.type];
      if (!this.isDraggingCam && this.manualCamCooldown <= 0 && v.speed > 4.0) {
        const desiredYaw = v.yaw + Math.PI;
        let diff = desiredYaw - this.camYaw;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        this.camYaw += diff * Math.min(1, dt * 2.2);
      }

      const dist = spec.length * 1.45 + 3.2;
      const height = spec.height * 1.2 + 1.9;
      _camDesired.set(
        v.x + Math.sin(this.camYaw) * dist * Math.cos(this.camPitch * 0.5),
        v.y + height + Math.sin(this.camPitch) * 4.5,
        v.z + Math.cos(this.camYaw) * dist * Math.cos(this.camPitch * 0.5)
      );
      _camLookAt.set(v.x, v.y + spec.height * 0.75, v.z);
    } else {
      const dist = 6.2;
      _camDesired.set(
        this.playerX + Math.sin(this.camYaw) * dist * Math.cos(this.camPitch),
        Math.max(0.8, this.playerY + 2.1 + Math.sin(this.camPitch) * dist),
        this.playerZ + Math.cos(this.camYaw) * dist * Math.cos(this.camPitch)
      );
      _camLookAt.set(this.playerX, this.playerY + 1.35, this.playerZ);
    }

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, _camDesired.x, 9, dt) + shakeX;
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, _camDesired.y, 9, dt) + shakeY;
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, _camDesired.z, 9, dt);
    this.camera.lookAt(_camLookAt);
  }

  private getCurrentDistrict(): DistrictDef {
    let closest = KARACHI_DISTRICTS[0];
    let best = Infinity;
    for (let i = 0; i < KARACHI_DISTRICTS.length; i++) {
      const d = KARACHI_DISTRICTS[i];
      const dist = Math.hypot(d.x - this.playerX, d.z - this.playerZ);
      if (dist < best) {
        best = dist;
        closest = d;
      }
    }
    return closest;
  }

  private emitHud(nearestVehicle: VehicleEntity | null, nearestPlace: PlaceDef | null) {
    let nearbyPrompt: HudSnapshot['nearbyPrompt'] = null;
    if (this.activeVehicle) {
      nearbyPrompt = {
        action: 'F',
        label: `Exit ${VEHICLE_SPECS[this.activeVehicle.type].name}`,
        kind: 'vehicle',
      };
    } else if (nearestVehicle) {
      nearbyPrompt = {
        action: 'F',
        label: `Drive ${VEHICLE_SPECS[nearestVehicle.type].name}`,
        kind: 'vehicle',
      };
    } else if (nearestPlace) {
      nearbyPrompt = {
        action: 'E',
        label: `Enter ${nearestPlace.name}`,
        kind: 'place',
        id: nearestPlace.id,
      };
    }

    const blips: HudSnapshot['radarBlips'] = [];
    for (let i = 0; i < this.vehicles.length; i++) {
      const v = this.vehicles[i];
      if (v === this.activeVehicle) continue;
      if (Math.hypot(v.x - this.playerX, v.z - this.playerZ) < 280) {
        blips.push({ x: v.x, z: v.z, kind: v.isPolice ? 'police' : 'vehicle' });
      }
    }
    for (let i = 0; i < KARACHI_PLACES.length; i++) {
      const p = KARACHI_PLACES[i];
      if (Math.hypot(p.x - this.playerX, p.z - this.playerZ) < 360) {
        blips.push({ x: p.x, z: p.z, kind: 'place' });
      }
    }
    if (this.activeMission) {
      const wp = this.activeMission.def.waypoints[this.activeMission.waypointIndex];
      blips.push({ x: wp.x, z: wp.z, kind: 'mission' });
    }

    const activeMissionHud: HudSnapshot['activeMission'] = this.activeMission
      ? {
          id: this.activeMission.def.id,
          title: this.activeMission.def.title,
          objective: this.activeMission.def.waypoints[this.activeMission.waypointIndex].label,
          waypointIndex: this.activeMission.waypointIndex,
          totalWaypoints: this.activeMission.def.waypoints.length,
          timeLeft: this.activeMission.timeLeft,
          targetX: this.activeMission.def.waypoints[this.activeMission.waypointIndex].x,
          targetZ: this.activeMission.def.waypoints[this.activeMission.waypointIndex].z,
        }
      : null;

    const speedKmh = this.activeVehicle ? Math.round(Math.abs(this.activeVehicle.speed) * 3.6) : 0;

    if (this.isRecordingVideo) {
      this.recordingDistricts.add(this.getCurrentDistrict().name);
      this.recordingActionScore += (speedKmh > 60 ? 2.5 : 0.6) + this.wantedLevel * 3;
    }

    this.callbacks.onHudUpdate({
      health: Math.round(this.health),
      maxHealth: this.maxHealth,
      stamina: Math.round(this.stamina),
      cash: this.cash,
      wantedLevel: this.wantedLevel,
      wantedCooldown: Math.ceil(this.wantedCooldown),
      district: this.getCurrentDistrict(),
      speedKmh,
      inVehicle: this.activeVehicle ? this.activeVehicle.type : null,
      vehicleName: this.activeVehicle ? VEHICLE_SPECS[this.activeVehicle.type].name : null,
      isSwimming: this.isSwimming,
      cameraMode: this.cameraMode,
      timeOfDay: this.timeOfDay,
      weather: this.weather,
      playerX: this.playerX,
      playerZ: this.playerZ,
      playerYaw: this.playerYaw,
      isRecordingVideo: this.isRecordingVideo,
      recordingSeconds: this.isRecordingVideo
        ? Math.floor((performance.now() - this.recordingStartMs) / 1000)
        : 0,
      nearbyPrompt,
      activeMission: activeMissionHud,
      waypoint: this.customWaypoint,
      radarBlips: blips,
    });
  }

  public dispose() {
    this.destroyed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    soundEngine.stopEngine();
    soundEngine.stopSiren();

    window.removeEventListener('keydown', this.boundKeyDown);
    window.removeEventListener('keyup', this.boundKeyUp);
    window.removeEventListener('blur', this.boundBlur);
    window.removeEventListener('resize', this.boundResize);
    this.renderer.domElement.removeEventListener('pointerdown', this.boundPointerDown);
    window.removeEventListener('pointermove', this.boundPointerMove);
    window.removeEventListener('pointerup', this.boundPointerUp);
    window.removeEventListener('pointercancel', this.boundPointerUp);

    this.textures.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
