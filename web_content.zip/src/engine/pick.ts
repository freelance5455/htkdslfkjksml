import type { SanLine } from './worker';
import type { EngineSettings } from './settings';

const pickRandom = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)];

function gauss() {
  let u = 0,
    v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

/** Выбор хода из лучших линий с учётом "человечности" (ошибки, шум, вариативность дебюта) */
export function pickMove(lines: SanLine[], s: EngineSettings, plyCount: number): SanLine {
  if (lines.length === 1) return lines[0];
  const best = lines[0].score;
  // если найден форсированный мат — играем его
  if (best > 90000) return lines[0];

  const safe = (arr: SanLine[]) => {
    const f = arr.filter((l) => l.score > -90000);
    return f.length ? f : arr;
  };

  if (plyCount < s.openingVariety) {
    const pool = lines.filter((l) => l.score >= best - 30);
    return pickRandom(pool);
  }
  if (Math.random() < s.mistakeChance) {
    return pickRandom(safe(lines.slice(0, Math.max(1, s.candidates))));
  }
  if (s.noise > 0) {
    let bestLine = lines[0];
    let bestVal = -Infinity;
    for (const l of safe(lines.slice(0, Math.max(1, s.candidates)))) {
      const v = Math.max(-5000, Math.min(5000, l.score)) + gauss() * s.noise;
      if (v > bestVal) {
        bestVal = v;
        bestLine = l;
      }
    }
    return bestLine;
  }
  return lines[0];
}
