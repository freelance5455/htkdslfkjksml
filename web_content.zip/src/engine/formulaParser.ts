// Safe recursive-descent formula parser & evaluator.
// Never uses eval() or new Function().

export interface FormulaEvalResult {
  ok: boolean;
  value: number | string | boolean | null;
  error?: string;
  referencedFields: string[];
}

type TokenType =
  | 'NUMBER'
  | 'STRING'
  | 'IDENT'
  | 'FIELD_REF'
  | 'OP'
  | 'LPAREN'
  | 'RPAREN'
  | 'COMMA'
  | 'PERCENT'
  | 'EOF';

interface Token {
  type: TokenType;
  value: string;
  pos: number;
}

const FUNCTION_NAMES = new Set([
  'SUM',
  'MIN',
  'MAX',
  'AVERAGE',
  'AVG',
  'IF',
  'ROUND',
  'ABS',
  'PERCENT',
  'AND',
  'OR',
  'NOT',
]);

export function tokenizeFormula(input: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  const len = input.length;

  while (i < len) {
    const ch = input[i];

    if (/\s/.test(ch)) {
      i++;
      continue;
    }

    // Bracketed field reference: [Field Name] or {Field Name}
    if (ch === '[' || ch === '{') {
      const closeCh = ch === '[' ? ']' : '}';
      const start = i;
      i++;
      let ref = '';
      while (i < len && input[i] !== closeCh) {
        ref += input[i];
        i++;
      }
      if (i >= len || input[i] !== closeCh) {
        throw new Error(`Unclosed field reference starting at position ${start + 1}`);
      }
      i++; // consume closeCh
      const trimmed = ref.trim();
      if (!trimmed) {
        throw new Error(`Empty field reference at position ${start + 1}`);
      }
      tokens.push({ type: 'FIELD_REF', value: trimmed, pos: start });
      continue;
    }

    // String literal "..." or '...'
    if (ch === '"' || ch === "'") {
      const quote = ch;
      const start = i;
      i++;
      let str = '';
      while (i < len && input[i] !== quote) {
        if (input[i] === '\\' && i + 1 < len) {
          i++;
        }
        str += input[i];
        i++;
      }
      if (i >= len) {
        throw new Error(`Unterminated string literal at position ${start + 1}`);
      }
      i++;
      tokens.push({ type: 'STRING', value: str, pos: start });
      continue;
    }

    // Number literal
    if (/[0-9]/.test(ch) || (ch === '.' && i + 1 < len && /[0-9]/.test(input[i + 1]))) {
      const start = i;
      let numStr = '';
      let dotCount = 0;
      while (i < len && (/[0-9]/.test(input[i]) || input[i] === '.')) {
        if (input[i] === '.') dotCount++;
        if (dotCount > 1) {
          throw new Error(`Invalid number format at position ${start + 1}`);
        }
        numStr += input[i];
        i++;
      }
      tokens.push({ type: 'NUMBER', value: numStr, pos: start });
      continue;
    }

    // Multi-char comparison operators
    const twoChar = input.slice(i, i + 2);
    if (twoChar === '>=' || twoChar === '<=' || twoChar === '==' || twoChar === '!=' || twoChar === '<>') {
      tokens.push({ type: 'OP', value: twoChar === '<>' ? '!=' : twoChar, pos: i });
      i += 2;
      continue;
    }

    // Single-char operators (normalize unicode × and ÷)
    if (ch === '+' || ch === '-' || ch === '*' || ch === '/' || ch === '×' || ch === '÷' || ch === '>' || ch === '<' || ch === '=') {
      const norm = ch === '×' ? '*' : ch === '÷' ? '/' : ch === '=' ? '==' : ch;
      tokens.push({ type: 'OP', value: norm, pos: i });
      i++;
      continue;
    }

    if (ch === '%') {
      tokens.push({ type: 'PERCENT', value: '%', pos: i });
      i++;
      continue;
    }

    if (ch === '(') {
      tokens.push({ type: 'LPAREN', value: '(', pos: i });
      i++;
      continue;
    }

    if (ch === ')') {
      tokens.push({ type: 'RPAREN', value: ')', pos: i });
      i++;
      continue;
    }

    if (ch === ',') {
      tokens.push({ type: 'COMMA', value: ',', pos: i });
      i++;
      continue;
    }

    // Identifier (function name, boolean, or unbracketed field name)
    if (/[A-Za-z_]/.test(ch)) {
      const start = i;
      let ident = '';
      while (i < len && /[A-Za-z0-9_.]/.test(input[i])) {
        ident += input[i];
        i++;
      }
      tokens.push({ type: 'IDENT', value: ident, pos: start });
      continue;
    }

    throw new Error(`Unexpected character "${ch}" at position ${i + 1}`);
  }

  tokens.push({ type: 'EOF', value: '', pos: len });
  return tokens;
}

export function extractReferencedFields(expression: string): { fields: string[]; error?: string } {
  if (!expression || !expression.trim()) {
    return { fields: [] };
  }
  try {
    const tokens = tokenizeFormula(expression);
    const fields = new Set<string>();
    for (let i = 0; i < tokens.length; i++) {
      const t = tokens[i];
      if (t.type === 'FIELD_REF') {
        fields.add(t.value);
      } else if (t.type === 'IDENT') {
        const upper = t.value.toUpperCase();
        const nextIsParen = tokens[i + 1]?.type === 'LPAREN';
        if (nextIsParen && FUNCTION_NAMES.has(upper)) {
          continue;
        }
        if (upper === 'TRUE' || upper === 'FALSE') {
          continue;
        }
        fields.add(t.value);
      }
    }
    return { fields: Array.from(fields) };
  } catch (err) {
    return { fields: [], error: err instanceof Error ? err.message : 'Invalid syntax' };
  }
}

export function detectCircularDependencies(
  dependencies: Record<string, string[]>
): { hasCycle: boolean; cyclePath: string[] } {
  const state: Record<string, 'unvisited' | 'visiting' | 'visited'> = {};
  const stack: string[] = [];

  const dfs = (node: string): string[] | null => {
    state[node] = 'visiting';
    stack.push(node);

    const neighbors = dependencies[node] || [];
    for (const next of neighbors) {
      const nextState = state[next] || 'unvisited';
      if (nextState === 'visiting') {
        const idx = stack.indexOf(next);
        return [...stack.slice(idx), next];
      }
      if (nextState === 'unvisited') {
        const cycle = dfs(next);
        if (cycle) return cycle;
      }
    }

    stack.pop();
    state[node] = 'visited';
    return null;
  };

  for (const node of Object.keys(dependencies)) {
    if ((state[node] || 'unvisited') === 'unvisited') {
      const cycle = dfs(node);
      if (cycle) {
        return { hasCycle: true, cyclePath: cycle };
      }
    }
  }

  return { hasCycle: false, cyclePath: [] };
}

type EvalVal = number | string | boolean;

class Parser {
  private tokens: Token[];
  private pos = 0;
  private context: Record<string, unknown>;
  private referenced = new Set<string>();

  constructor(tokens: Token[], context: Record<string, unknown>) {
    this.tokens = tokens;
    this.context = context;
  }

  private peek(): Token {
    return this.tokens[this.pos] ?? { type: 'EOF', value: '', pos: -1 };
  }

  private consume(): Token {
    const t = this.peek();
    this.pos++;
    return t;
  }

  public getReferencedFields(): string[] {
    return Array.from(this.referenced);
  }

  public parse(): EvalVal {
    if (this.peek().type === 'EOF') {
      throw new Error('Formula expression is empty');
    }
    const result = this.parseComparison();
    if (this.peek().type !== 'EOF') {
      throw new Error(`Unexpected token "${this.peek().value}" at position ${this.peek().pos + 1}`);
    }
    return result;
  }

  private parseComparison(): EvalVal {
    let left = this.parseAddSub();
    while (
      this.peek().type === 'OP' &&
      ['>', '<', '>=', '<=', '==', '!='].includes(this.peek().value)
    ) {
      const op = this.consume().value;
      const right = this.parseAddSub();
      if (op === '==') left = left === right || Number(left) === Number(right);
      else if (op === '!=') left = left !== right && Number(left) !== Number(right);
      else {
        const lNum = this.toNumber(left, op);
        const rNum = this.toNumber(right, op);
        if (op === '>') left = lNum > rNum;
        else if (op === '<') left = lNum < rNum;
        else if (op === '>=') left = lNum >= rNum;
        else if (op === '<=') left = lNum <= rNum;
      }
    }
    return left;
  }

  private parseAddSub(): EvalVal {
    let left = this.parseMulDiv();
    while (this.peek().type === 'OP' && (this.peek().value === '+' || this.peek().value === '-')) {
      const op = this.consume().value;
      const right = this.parseMulDiv();
      const lNum = this.toNumber(left, op);
      const rNum = this.toNumber(right, op);
      left = op === '+' ? lNum + rNum : lNum - rNum;
    }
    return left;
  }

  private parseMulDiv(): EvalVal {
    let left = this.parseUnary();
    while (this.peek().type === 'OP' && (this.peek().value === '*' || this.peek().value === '/')) {
      const op = this.consume().value;
      const right = this.parseUnary();
      const lNum = this.toNumber(left, op);
      const rNum = this.toNumber(right, op);
      if (op === '/') {
        if (rNum === 0) {
          throw new Error('Division by zero error');
        }
        left = lNum / rNum;
      } else {
        left = lNum * rNum;
      }
    }
    return left;
  }

  private parseUnary(): EvalVal {
    if (this.peek().type === 'OP' && (this.peek().value === '-' || this.peek().value === '+')) {
      const op = this.consume().value;
      const val = this.parseUnary();
      const n = this.toNumber(val, op);
      return op === '-' ? -n : n;
    }
    return this.parsePostfix();
  }

  private parsePostfix(): EvalVal {
    let val = this.parsePrimary();
    while (this.peek().type === 'PERCENT') {
      this.consume();
      const n = this.toNumber(val, '%');
      val = n / 100;
    }
    return val;
  }

  private parsePrimary(): EvalVal {
    const tok = this.peek();

    if (tok.type === 'NUMBER') {
      this.consume();
      return Number(tok.value);
    }

    if (tok.type === 'STRING') {
      this.consume();
      return tok.value;
    }

    if (tok.type === 'FIELD_REF') {
      this.consume();
      return this.resolveField(tok.value);
    }

    if (tok.type === 'LPAREN') {
      this.consume();
      const val = this.parseComparison();
      if (this.peek().type !== 'RPAREN') {
        throw new Error('Missing closing parenthesis ")"');
      }
      this.consume();
      return val;
    }

    if (tok.type === 'IDENT') {
      this.consume();
      const upper = tok.value.toUpperCase();

      if (upper === 'TRUE') return true;
      if (upper === 'FALSE') return false;

      if (this.peek().type === 'LPAREN') {
        if (!FUNCTION_NAMES.has(upper)) {
          throw new Error(`Unknown function "${tok.value}"`);
        }
        this.consume(); // '('
        const args: EvalVal[] = [];
        if (this.peek().type !== 'RPAREN') {
          args.push(this.parseComparison());
          while (this.peek().type === 'COMMA') {
            this.consume();
            args.push(this.parseComparison());
          }
        }
        if (this.peek().type !== 'RPAREN') {
          throw new Error(`Missing closing parenthesis ")" in ${upper}()`);
        }
        this.consume();
        return this.evalFunction(upper, args);
      }

      return this.resolveField(tok.value);
    }

    throw new Error(`Unexpected token "${tok.value || 'end of expression'}"`);
  }

  private resolveField(name: string): EvalVal {
    this.referenced.add(name);
    // Try exact match, then case-insensitive match
    let raw: unknown;
    if (Object.prototype.hasOwnProperty.call(this.context, name)) {
      raw = this.context[name];
    } else {
      const lower = name.toLowerCase();
      const key = Object.keys(this.context).find((k) => k.toLowerCase() === lower);
      if (key === undefined) {
        throw new Error(`Unknown field reference "${name}"`);
      }
      raw = this.context[key];
    }

    if (raw === null || raw === undefined || raw === '') {
      return 0;
    }
    if (typeof raw === 'number') {
      if (Number.isNaN(raw)) return 0;
      return raw;
    }
    if (typeof raw === 'boolean') return raw;
    if (typeof raw === 'string') {
      const trimmed = raw.trim();
      if (trimmed !== '' && !Number.isNaN(Number(trimmed))) {
        return Number(trimmed);
      }
      return raw;
    }
    return 0;
  }

  private toNumber(val: EvalVal, op: string): number {
    if (typeof val === 'number') {
      if (!Number.isFinite(val)) throw new Error(`Numeric overflow near "${op}"`);
      return val;
    }
    if (typeof val === 'boolean') return val ? 1 : 0;
    const n = Number(val);
    if (Number.isNaN(n)) {
      throw new Error(`Cannot perform "${op}" on non-numeric value "${val}"`);
    }
    return n;
  }

  private evalFunction(fn: string, args: EvalVal[]): EvalVal {
    const nums = () => args.map((a) => this.toNumber(a, fn));
    switch (fn) {
      case 'SUM': {
        if (args.length === 0) return 0;
        return nums().reduce((acc, v) => acc + v, 0);
      }
      case 'MIN': {
        if (args.length === 0) throw new Error('MIN() requires at least 1 argument');
        return Math.min(...nums());
      }
      case 'MAX': {
        if (args.length === 0) throw new Error('MAX() requires at least 1 argument');
        return Math.max(...nums());
      }
      case 'AVERAGE':
      case 'AVG': {
        if (args.length === 0) throw new Error(`${fn}() requires at least 1 argument`);
        const arr = nums();
        return arr.reduce((a, b) => a + b, 0) / arr.length;
      }
      case 'ABS': {
        if (args.length !== 1) throw new Error('ABS() requires exactly 1 argument');
        return Math.abs(this.toNumber(args[0], 'ABS'));
      }
      case 'ROUND': {
        if (args.length < 1 || args.length > 2) {
          throw new Error('ROUND(value, decimals) requires 1 or 2 arguments');
        }
        const val = this.toNumber(args[0], 'ROUND');
        const dec = args.length === 2 ? Math.max(0, Math.min(10, Math.trunc(this.toNumber(args[1], 'ROUND')))) : 0;
        const factor = Math.pow(10, dec);
        return Math.round((val + Number.EPSILON) * factor) / factor;
      }
      case 'PERCENT': {
        if (args.length !== 2) throw new Error('PERCENT(part, whole) requires 2 arguments');
        const part = this.toNumber(args[0], 'PERCENT');
        const whole = this.toNumber(args[1], 'PERCENT');
        if (whole === 0) throw new Error('Division by zero in PERCENT()');
        return (part / whole) * 100;
      }
      case 'IF': {
        if (args.length !== 3) throw new Error('IF(condition, trueValue, falseValue) requires 3 arguments');
        const cond = Boolean(args[0]);
        return cond ? args[1] : args[2];
      }
      case 'AND': {
        if (args.length === 0) throw new Error('AND() requires at least 1 argument');
        return args.every((a) => Boolean(a));
      }
      case 'OR': {
        if (args.length === 0) throw new Error('OR() requires at least 1 argument');
        return args.some((a) => Boolean(a));
      }
      case 'NOT': {
        if (args.length !== 1) throw new Error('NOT() requires 1 argument');
        return !Boolean(args[0]);
      }
      default:
        throw new Error(`Unsupported function "${fn}"`);
    }
  }
}

export function evaluateFormula(
  expression: string,
  context: Record<string, unknown>,
  decimalPlaces = 2
): FormulaEvalResult {
  try {
    const trimmed = (expression || '').trim();
    const cleaned = trimmed.startsWith('=') ? trimmed.slice(1).trim() : trimmed;
    if (!cleaned) {
      return { ok: false, value: null, error: 'Formula expression is empty', referencedFields: [] };
    }
    const tokens = tokenizeFormula(cleaned);
    const parser = new Parser(tokens, context);
    const raw = parser.parse();
    const referencedFields = parser.getReferencedFields();
    if (typeof raw === 'number') {
      if (!Number.isFinite(raw)) {
        return { ok: false, value: null, error: 'Calculation resulted in invalid number', referencedFields };
      }
      const factor = Math.pow(10, Math.max(0, Math.min(8, decimalPlaces)));
      const rounded = Math.round((raw + Number.EPSILON) * factor) / factor;
      return { ok: true, value: rounded, referencedFields };
    }
    return { ok: true, value: raw, referencedFields };
  } catch (err) {
    const { fields } = extractReferencedFields(expression);
    return {
      ok: false,
      value: null,
      error: err instanceof Error ? err.message : 'Formula evaluation failed',
      referencedFields: fields,
    };
  }
}

export function validateFormulaSyntaxAndReferences(
  expression: string,
  availableFieldNames: string[]
): { valid: boolean; error?: string; missingFields: string[]; referencedFields: string[] } {
  const trimmed = (expression || '').trim();
  const cleaned = trimmed.startsWith('=') ? trimmed.slice(1).trim() : trimmed;
  if (!cleaned) {
    return { valid: false, error: 'Formula cannot be empty', missingFields: [], referencedFields: [] };
  }

  const { fields, error } = extractReferencedFields(cleaned);
  if (error) {
    return { valid: false, error, missingFields: [], referencedFields: [] };
  }

  const lowerAvail = new Set(availableFieldNames.map((f) => f.toLowerCase()));
  const missingFields = fields.filter((f) => !lowerAvail.has(f.toLowerCase()));
  if (missingFields.length > 0) {
    return {
      valid: false,
      error: `Unknown field reference(s): ${missingFields.join(', ')}`,
      missingFields,
      referencedFields: fields,
    };
  }

  // Run dry-run evaluation with dummy 1s to verify syntax and arity
  const dummyContext: Record<string, number> = {};
  for (const f of availableFieldNames) {
    dummyContext[f] = 1;
  }
  const dry = evaluateFormula(cleaned, dummyContext, 2);
  if (!dry.ok) {
    return { valid: false, error: dry.error, missingFields: [], referencedFields: fields };
  }

  return { valid: true, missingFields: [], referencedFields: fields };
}
