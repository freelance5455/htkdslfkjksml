import * as THREE from 'three';
import { CharacterCustomization, VehicleType } from '../types/game';
import { ProceduralTextureSet } from './textures';
import { VEHICLE_SPECS } from '../data/karachiWorldData';

export interface ArticulatedCharacter {
  group: THREE.Group;
  pelvisGroup: THREE.Group;
  torsoGroup: THREE.Group;
  headGroup: THREE.Group;
  eyelidsGroup: THREE.Group;
  leftArm: THREE.Group;
  leftElbow: THREE.Group;
  rightArm: THREE.Group;
  rightElbow: THREE.Group;
  leftLeg: THREE.Group;
  leftKnee: THREE.Group;
  rightLeg: THREE.Group;
  rightKnee: THREE.Group;
}

export interface CharacterRigOptions {
  skinHex?: string;
  isFemale?: boolean;
  facialHair?: 'none' | 'stubble' | 'beard';
  hairColor?: string;
  role?: 'civilian' | 'police' | 'vendor' | 'shopkeeper';
  heightScale?: number;
  widthScale?: number;
  textures?: ProceduralTextureSet;
  contactShadowTex?: THREE.Texture;
}

export interface CharacterAnimState {
  mode: 'idle' | 'walk' | 'run' | 'swim' | 'seated' | 'vendor';
  walkPhase: number;
  elapsedSec: number;
  steerAngle?: number;
  speedRatio?: number;
  blinkSeed?: number;
}

export interface VehicleRig {
  group: THREE.Group;
  bodyGroup: THREE.Group;
  driverMount: THREE.Group;
  wheels: THREE.Object3D[];
  frontWheelPivots: THREE.Object3D[];
  steeringWheel: THREE.Object3D | null;
  headlights: THREE.MeshBasicMaterial[];
  brakelights: THREE.MeshBasicMaterial[];
  sirenBars?: { red: THREE.MeshBasicMaterial; blue: THREE.MeshBasicMaterial };
}

// Module-level cached anatomical geometries so 60+ characters render at 60 FPS with minimal memory
interface HumanGeoCache {
  pelvis: THREE.LatheGeometry;
  torsoMale: THREE.LatheGeometry;
  torsoFemale: THREE.LatheGeometry;
  headProfile: THREE.LatheGeometry;
  neck: THREE.CylinderGeometry;
  thighPants: THREE.CapsuleGeometry;
  thighShalwar: THREE.CapsuleGeometry;
  calfPants: THREE.CapsuleGeometry;
  calfShalwar: THREE.CapsuleGeometry;
  shoeUpper: THREE.CapsuleGeometry;
  shoeSole: THREE.BoxGeometry;
  upperArm: THREE.CapsuleGeometry;
  forearm: THREE.CapsuleGeometry;
  palm: THREE.BoxGeometry;
  thumb: THREE.CapsuleGeometry;
  shoulderJoint: THREE.SphereGeometry;
  ear: THREE.SphereGeometry;
  noseBridge: THREE.BoxGeometry;
  noseTip: THREE.SphereGeometry;
  eyeBall: THREE.SphereGeometry;
  eyelid: THREE.BoxGeometry;
  brow: THREE.BoxGeometry;
  lips: THREE.BoxGeometry;
  hairCrown: THREE.SphereGeometry;
  hairBack: THREE.CapsuleGeometry;
  beardJaw: THREE.SphereGeometry;
  mustache: THREE.BoxGeometry;
}

let _humanGeoCache: HumanGeoCache | null = null;
function getHumanGeos(): HumanGeoCache {
  if (_humanGeoCache) return _humanGeoCache;

  // Sculpted tapered pelvis / hips
  const pelvis = new THREE.LatheGeometry(
    [
      new THREE.Vector2(0.01, -0.06),
      new THREE.Vector2(0.14, -0.03),
      new THREE.Vector2(0.175, 0.05),
      new THREE.Vector2(0.16, 0.14),
      new THREE.Vector2(0.01, 0.15),
    ],
    16
  );

  // Sculpted ribcage & broad shoulders (male & female contours)
  const torsoMale = new THREE.LatheGeometry(
    [
      new THREE.Vector2(0.01, 0.0),
      new THREE.Vector2(0.155, 0.02),
      new THREE.Vector2(0.175, 0.18),
      new THREE.Vector2(0.215, 0.36),
      new THREE.Vector2(0.205, 0.48),
      new THREE.Vector2(0.11, 0.54),
      new THREE.Vector2(0.01, 0.55),
    ],
    18
  );

  const torsoFemale = new THREE.LatheGeometry(
    [
      new THREE.Vector2(0.01, 0.0),
      new THREE.Vector2(0.135, 0.02),
      new THREE.Vector2(0.15, 0.18),
      new THREE.Vector2(0.185, 0.35),
      new THREE.Vector2(0.175, 0.47),
      new THREE.Vector2(0.095, 0.53),
      new THREE.Vector2(0.01, 0.54),
    ],
    18
  );

  // Anatomical cranium + jaw + chin profile
  const headProfile = new THREE.LatheGeometry(
    [
      new THREE.Vector2(0.0, 0.0),
      new THREE.Vector2(0.055, 0.015),
      new THREE.Vector2(0.095, 0.055),
      new THREE.Vector2(0.118, 0.12),
      new THREE.Vector2(0.128, 0.19),
      new THREE.Vector2(0.122, 0.245),
      new THREE.Vector2(0.085, 0.285),
      new THREE.Vector2(0.0, 0.3),
    ],
    18
  );

  _humanGeoCache = {
    pelvis,
    torsoMale,
    torsoFemale,
    headProfile,
    neck: new THREE.CylinderGeometry(0.058, 0.072, 0.12, 12),
    thighPants: new THREE.CapsuleGeometry(0.078, 0.25, 6, 12),
    thighShalwar: new THREE.CapsuleGeometry(0.102, 0.25, 6, 12),
    calfPants: new THREE.CapsuleGeometry(0.062, 0.26, 6, 12),
    calfShalwar: new THREE.CapsuleGeometry(0.084, 0.26, 6, 12),
    shoeUpper: new THREE.CapsuleGeometry(0.056, 0.12, 6, 10),
    shoeSole: new THREE.BoxGeometry(0.125, 0.032, 0.25),
    upperArm: new THREE.CapsuleGeometry(0.058, 0.17, 6, 10),
    forearm: new THREE.CapsuleGeometry(0.046, 0.17, 6, 10),
    palm: new THREE.BoxGeometry(0.068, 0.09, 0.044),
    thumb: new THREE.CapsuleGeometry(0.014, 0.03, 4, 6),
    shoulderJoint: new THREE.SphereGeometry(0.074, 10, 10),
    ear: new THREE.SphereGeometry(0.024, 8, 8),
    noseBridge: new THREE.BoxGeometry(0.022, 0.046, 0.028),
    noseTip: new THREE.SphereGeometry(0.016, 8, 8),
    eyeBall: new THREE.SphereGeometry(0.0175, 10, 10),
    eyelid: new THREE.BoxGeometry(0.036, 0.018, 0.022),
    brow: new THREE.BoxGeometry(0.038, 0.01, 0.014),
    lips: new THREE.BoxGeometry(0.046, 0.014, 0.016),
    hairCrown: new THREE.SphereGeometry(0.136, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.56),
    hairBack: new THREE.CapsuleGeometry(0.082, 0.18, 6, 10),
    beardJaw: new THREE.SphereGeometry(0.118, 14, 10, 0, Math.PI * 2, Math.PI * 0.45, Math.PI * 0.52),
    mustache: new THREE.BoxGeometry(0.058, 0.014, 0.022),
  };
  return _humanGeoCache;
}

export function createCharacterRig(
  custom: CharacterCustomization,
  skinOrOpts: string | CharacterRigOptions = '#c68b59',
  isFemaleLegacy = false,
  contactShadowTexLegacy?: THREE.Texture
): ArticulatedCharacter {
  const opts: CharacterRigOptions =
    typeof skinOrOpts === 'string'
      ? {
          skinHex: skinOrOpts,
          isFemale: isFemaleLegacy,
          contactShadowTex: contactShadowTexLegacy,
        }
      : skinOrOpts;

  const geos = getHumanGeos();
  const isFemale = opts.isFemale ?? false;
  const role = opts.role ?? 'civilian';
  const skinHex = custom.skinTone || opts.skinHex || '#c68b59';
  const hairHex = opts.hairColor || '#111827';
  const facialHair = isFemale ? 'none' : opts.facialHair ?? custom.facialHair ?? 'none';
  const textures = opts.textures;
  const contactShadowTex = opts.contactShadowTex || textures?.contactShadow;

  const root = new THREE.Group();
  const bodyScaleH = opts.heightScale ?? (isFemale ? 0.96 : 1.0);
  const bodyScaleW = opts.widthScale ?? (isFemale ? 0.92 : 1.0);
  root.scale.set(bodyScaleW, bodyScaleH, bodyScaleW);

  const isPolice = role === 'police';
  const isVendor = role === 'vendor';
  const isKurta = !isPolice && (custom.style === 'shalwar_kameez' || custom.style === 'kurta_waistcoat');

  const topColor = isPolice ? '#1e293b' : custom.primaryColor;
  const pantColor = isPolice
    ? '#0f172a'
    : custom.style === 'modern_casual'
      ? '#1e293b'
      : custom.primaryColor;

  const shirtMat = new THREE.MeshStandardMaterial({
    color: topColor,
    map: isKurta && textures ? textures.kurtaWeave : undefined,
    roughness: 0.76,
    metalness: 0.04,
  });
  const pantMat = new THREE.MeshStandardMaterial({
    color: pantColor,
    map:
      custom.style === 'modern_casual' && !isPolice && textures
        ? textures.denimFabric
        : isKurta && textures
          ? textures.kurtaWeave
          : undefined,
    roughness: 0.82,
    metalness: 0.04,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: isPolice ? '#eab308' : custom.secondaryColor,
    map: custom.style === 'ajrak_street' && !isPolice && textures ? textures.ajrakFabric : undefined,
    roughness: 0.62,
    metalness: isPolice ? 0.65 : 0.08,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    color: skinHex,
    roughness: 0.56,
    metalness: 0.02,
  });
  const lipMat = new THREE.MeshStandardMaterial({
    color: '#8c4f42',
    roughness: 0.55,
  });
  const shoeMat = new THREE.MeshStandardMaterial({
    color: isKurta && !isPolice ? '#451a03' : '#18181b',
    roughness: 0.45,
    metalness: 0.14,
  });
  const soleMat = new THREE.MeshStandardMaterial({
    color: isKurta && !isPolice ? '#292524' : '#f1f5f9',
    roughness: 0.72,
  });
  const hairMat = new THREE.MeshStandardMaterial({
    color: hairHex,
    roughness: 0.84,
    metalness: 0.04,
  });
  const stubbleMat = new THREE.MeshStandardMaterial({
    color: hairHex,
    roughness: 0.9,
    transparent: true,
    opacity: 0.42,
  });

  if (contactShadowTex) {
    const shadowPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(1.1, 1.1),
      new THREE.MeshBasicMaterial({
        map: contactShadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.46,
      })
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.02;
    root.add(shadowPlane);
  }

  // Pelvis / Waist Pivot
  const pelvisGroup = new THREE.Group();
  pelvisGroup.position.y = 0.88;
  root.add(pelvisGroup);

  const pelvisMesh = new THREE.Mesh(geos.pelvis, pantMat);
  pelvisMesh.scale.set(isFemale ? 0.96 : 1.0, 1.0, 0.74);
  pelvisMesh.castShadow = true;
  pelvisGroup.add(pelvisMesh);

  // Leather Belt & Metallic Buckle (for casual / police)
  if (custom.style === 'modern_casual' || isPolice) {
    const belt = new THREE.Mesh(
      new THREE.CylinderGeometry(0.168, 0.168, 0.048, 16),
      new THREE.MeshStandardMaterial({ color: '#18181b', roughness: 0.4 })
    );
    belt.scale.set(1.0, 1.0, 0.75);
    belt.position.y = 0.11;
    pelvisGroup.add(belt);
    const buckle = new THREE.Mesh(
      new THREE.BoxGeometry(0.055, 0.045, 0.03),
      new THREE.MeshStandardMaterial({ color: isPolice ? '#facc15' : '#cbd5e1', metalness: 0.9, roughness: 0.2 })
    );
    buckle.position.set(0, 0.11, 0.125);
    pelvisGroup.add(buckle);
  }

  // Two-Bone Articulated Legs (Hip -> Thigh -> Knee -> Calf -> Sculpted Shoe)
  const makeLeg = (xOffset: number) => {
    const hipPivot = new THREE.Group();
    hipPivot.position.set(xOffset, 0.02, 0);
    const isShalwar = !isPolice && isKurta;

    const thigh = new THREE.Mesh(isShalwar ? geos.thighShalwar : geos.thighPants, pantMat);
    thigh.position.y = -0.21;
    thigh.castShadow = true;
    hipPivot.add(thigh);

    const kneePivot = new THREE.Group();
    kneePivot.position.set(0, -0.43, 0);
    hipPivot.add(kneePivot);

    const calf = new THREE.Mesh(isShalwar ? geos.calfShalwar : geos.calfPants, pantMat);
    calf.position.y = -0.2;
    calf.castShadow = true;
    kneePivot.add(calf);

    const shoeGroup = new THREE.Group();
    shoeGroup.position.set(0, -0.42, 0.035);
    const shoeUpper = new THREE.Mesh(geos.shoeUpper, shoeMat);
    shoeUpper.rotation.x = Math.PI / 2;
    shoeUpper.scale.set(1.05, 1.0, 0.78);
    shoeUpper.castShadow = true;
    shoeGroup.add(shoeUpper);

    const sole = new THREE.Mesh(geos.shoeSole, soleMat);
    sole.position.set(0, -0.034, 0.0);
    shoeGroup.add(sole);
    kneePivot.add(shoeGroup);

    pelvisGroup.add(hipPivot);
    return { hipPivot, kneePivot };
  };

  const leftLegData = makeLeg(-0.105);
  const rightLegData = makeLeg(0.105);

  // Upper Body / Torso Pivot (sits on top of pelvis)
  const torsoGroup = new THREE.Group();
  torsoGroup.position.y = 0.12;
  pelvisGroup.add(torsoGroup);

  const torsoMesh = new THREE.Mesh(isFemale ? geos.torsoFemale : geos.torsoMale, shirtMat);
  torsoMesh.scale.set(1.05, 1.0, 0.68);
  torsoMesh.castShadow = true;
  torsoGroup.add(torsoMesh);

  // Flowing Kurta / Kameez lower skirt hem
  if (isKurta && !isPolice) {
    const hem = new THREE.Mesh(new THREE.CylinderGeometry(0.175, 0.215, 0.34, 16, 1, true), shirtMat);
    hem.scale.set(1.04, 1, 0.68);
    hem.position.y = -0.11;
    hem.material.side = THREE.DoubleSide;
    hem.castShadow = true;
    torsoGroup.add(hem);
  }

  // Shirt Collar / Kurta Placket
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.088, 0.022, 8, 16), accentMat);
  collar.rotation.x = Math.PI / 2;
  collar.position.set(0, 0.525, 0.01);
  torsoGroup.add(collar);

  const placket = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.22, 0.02), accentMat);
  placket.position.set(0, 0.4, 0.132);
  torsoGroup.add(placket);

  // Outfit & Role Layering
  if (isPolice) {
    // Sindh Police Chest Badge, Shoulder Epaulettes & Tie
    const badge = new THREE.Mesh(
      new THREE.CylinderGeometry(0.026, 0.026, 0.012, 8),
      new THREE.MeshStandardMaterial({ color: '#facc15', metalness: 0.9, roughness: 0.2 })
    );
    badge.rotation.x = Math.PI / 2;
    badge.position.set(0.09, 0.36, 0.138);
    torsoGroup.add(badge);

    [-0.17, 0.17].forEach((ex) => {
      const ep = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.02, 0.055), accentMat);
      ep.position.set(ex, 0.51, 0);
      torsoGroup.add(ep);
    });
  } else if (isVendor) {
    // Karachi Chaiwala / Food Street Apron & Shoulder Cloth
    const apron = new THREE.Mesh(
      new THREE.BoxGeometry(0.28, 0.48, 0.03),
      new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.85 })
    );
    apron.position.set(0, 0.18, 0.135);
    torsoGroup.add(apron);
    const towel = new THREE.Mesh(
      new THREE.BoxGeometry(0.09, 0.34, 0.18),
      new THREE.MeshStandardMaterial({ color: '#dc2626', roughness: 0.9 })
    );
    towel.position.set(-0.14, 0.38, 0);
    torsoGroup.add(towel);
  } else if (custom.style === 'kurta_waistcoat' || role === 'shopkeeper') {
    const vest = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.17, 0.42, 16), accentMat);
    vest.scale.set(1.16, 1, 0.74);
    vest.position.set(0, 0.26, 0);
    vest.castShadow = true;
    torsoGroup.add(vest);
  } else if (custom.style === 'ajrak_street') {
    const shawlNeck = new THREE.Mesh(new THREE.TorusGeometry(0.165, 0.042, 8, 16), accentMat);
    shawlNeck.rotation.x = Math.PI / 2;
    shawlNeck.position.set(0, 0.47, 0);
    torsoGroup.add(shawlNeck);
    const shawlDrape = new THREE.Mesh(new THREE.BoxGeometry(0.115, 0.48, 0.22), accentMat);
    shawlDrape.position.set(0.12, 0.26, 0.01);
    shawlDrape.castShadow = true;
    torsoGroup.add(shawlDrape);
  } else if (custom.style === 'modern_casual') {
    const jacket = new THREE.Mesh(new THREE.CylinderGeometry(0.195, 0.175, 0.45, 16), accentMat);
    jacket.scale.set(1.18, 1, 0.75);
    jacket.position.set(0, 0.27, -0.005);
    jacket.castShadow = true;
    torsoGroup.add(jacket);
  }

  // Two-Bone Articulated Arms (Shoulder -> Upper Arm -> Elbow -> Forearm -> Wristwatch -> Sculpted Hand)
  const makeArm = (xOffset: number, hasWatch: boolean) => {
    const shoulderPivot = new THREE.Group();
    shoulderPivot.position.set(xOffset, 0.46, 0);

    const shoulder = new THREE.Mesh(geos.shoulderJoint, shirtMat);
    shoulderPivot.add(shoulder);

    const upperArm = new THREE.Mesh(geos.upperArm, shirtMat);
    upperArm.position.y = -0.14;
    upperArm.castShadow = true;
    shoulderPivot.add(upperArm);

    const elbowPivot = new THREE.Group();
    elbowPivot.position.set(0, -0.28, 0);
    shoulderPivot.add(elbowPivot);

    const sleeveMat = custom.style === 'modern_casual' || isPolice || isVendor ? skinMat : shirtMat;
    const forearm = new THREE.Mesh(geos.forearm, sleeveMat);
    forearm.position.y = -0.13;
    forearm.castShadow = true;
    elbowPivot.add(forearm);

    if (hasWatch && !isVendor) {
      const watch = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05, 0.05, 0.025, 12),
        new THREE.MeshStandardMaterial({ color: '#eab308', metalness: 0.9, roughness: 0.2 })
      );
      watch.position.y = -0.22;
      elbowPivot.add(watch);
    }

    const handGroup = new THREE.Group();
    handGroup.position.set(0, -0.27, 0.01);
    const palm = new THREE.Mesh(geos.palm, skinMat);
    handGroup.add(palm);
    const thumb = new THREE.Mesh(geos.thumb, skinMat);
    thumb.position.set(xOffset > 0 ? -0.036 : 0.036, 0.01, 0.02);
    thumb.rotation.z = xOffset > 0 ? 0.5 : -0.5;
    handGroup.add(thumb);
    elbowPivot.add(handGroup);

    torsoGroup.add(shoulderPivot);
    return { shoulderPivot, elbowPivot };
  };

  const leftArmData = makeArm(isFemale ? -0.23 : -0.255, true);
  const rightArmData = makeArm(isFemale ? 0.23 : 0.255, false);

  // Neck + Anatomical Head + Realistic Eyes/Blinking + Mouth + Facial Hair + Hair/Headwear
  const neck = new THREE.Mesh(geos.neck, skinMat);
  neck.position.set(0, 0.56, 0);
  torsoGroup.add(neck);

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.59, 0);
  torsoGroup.add(headGroup);

  const headMesh = new THREE.Mesh(geos.headProfile, skinMat);
  headMesh.scale.set(0.95, 1.0, 1.06);
  headMesh.castShadow = true;
  headGroup.add(headMesh);

  // Sculpted Ears
  [-0.125, 0.125].forEach((ex) => {
    const ear = new THREE.Mesh(geos.ear, skinMat);
    ear.scale.set(0.65, 1.35, 0.85);
    ear.position.set(ex, 0.155, -0.01);
    headGroup.add(ear);
  });

  // Sculpted Nose Bridge & Tip
  const noseBridge = new THREE.Mesh(geos.noseBridge, skinMat);
  noseBridge.position.set(0, 0.15, 0.13);
  noseBridge.rotation.x = -0.24;
  headGroup.add(noseBridge);
  const noseTip = new THREE.Mesh(geos.noseTip, skinMat);
  noseTip.position.set(0, 0.13, 0.145);
  headGroup.add(noseTip);

  // Expressive Mouth / Lips
  const lips = new THREE.Mesh(geos.lips, lipMat);
  lips.position.set(0, 0.082, 0.122);
  headGroup.add(lips);

  // Detailed Textured Eyes (Iris + Sclera) + Animated Eyelids
  const eyeMat = textures
    ? new THREE.MeshStandardMaterial({ map: textures.eyeIris, roughness: 0.18, metalness: 0.05 })
    : new THREE.MeshBasicMaterial({ color: '#1e1b18' });

  const eyelidsGroup = new THREE.Group();
  headGroup.add(eyelidsGroup);

  [-0.044, 0.044].forEach((ex) => {
    const eyeball = new THREE.Mesh(geos.eyeBall, eyeMat);
    eyeball.position.set(ex, 0.175, 0.118);
    // Rotate sphere UV so front iris faces +Z toward camera/forward
    eyeball.rotation.y = -Math.PI / 2;
    headGroup.add(eyeball);

    const lid = new THREE.Mesh(geos.eyelid, skinMat);
    lid.position.set(ex, 0.186, 0.125);
    lid.scale.y = 0.25;
    eyelidsGroup.add(lid);

    const brow = new THREE.Mesh(geos.brow, hairMat);
    brow.position.set(ex, 0.205, 0.124);
    brow.rotation.z = ex < 0 ? 0.08 : -0.08;
    headGroup.add(brow);
  });

  // Facial Hair (Beard / Mustache / Stubble)
  if (facialHair === 'beard') {
    const beard = new THREE.Mesh(geos.beardJaw, hairMat);
    beard.scale.set(0.98, 1.05, 1.08);
    beard.position.set(0, 0.115, 0.015);
    headGroup.add(beard);
    const stache = new THREE.Mesh(geos.mustache, hairMat);
    stache.position.set(0, 0.102, 0.126);
    headGroup.add(stache);
  } else if (facialHair === 'stubble') {
    const stubble = new THREE.Mesh(geos.beardJaw, stubbleMat);
    stubble.scale.set(0.96, 0.98, 1.05);
    stubble.position.set(0, 0.115, 0.014);
    headGroup.add(stubble);
  }

  // Sculpted Hair
  const hairCrown = new THREE.Mesh(geos.hairCrown, hairMat);
  hairCrown.position.set(0, 0.175, -0.01);
  hairCrown.rotation.x = -0.18;
  headGroup.add(hairCrown);

  if (isFemale) {
    const hairBack = new THREE.Mesh(geos.hairBack, hairMat);
    hairBack.position.set(0, 0.09, -0.11);
    headGroup.add(hairBack);

    if (isKurta) {
      // Draped Pakistani Dupatta Scarf around head/shoulders
      const dupatta = new THREE.Mesh(
        new THREE.TorusGeometry(0.145, 0.036, 8, 16),
        accentMat
      );
      dupatta.rotation.x = Math.PI / 2.2;
      dupatta.position.set(0, 0.18, -0.01);
      headGroup.add(dupatta);
    }
  }

  // Headwear & Sunglasses
  if (isPolice) {
    const capCrown = new THREE.Mesh(
      new THREE.CylinderGeometry(0.142, 0.128, 0.09, 16),
      new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.45 })
    );
    capCrown.position.set(0, 0.285, 0.0);
    headGroup.add(capCrown);
    const capPeak = new THREE.Mesh(
      new THREE.BoxGeometry(0.19, 0.016, 0.12),
      new THREE.MeshStandardMaterial({ color: '#09090b', roughness: 0.25 })
    );
    capPeak.position.set(0, 0.245, 0.13);
    capPeak.rotation.x = 0.2;
    headGroup.add(capPeak);
    const capCrest = new THREE.Mesh(
      new THREE.SphereGeometry(0.02, 8, 8),
      new THREE.MeshStandardMaterial({ color: '#facc15', metalness: 0.9, roughness: 0.2 })
    );
    capCrest.position.set(0, 0.295, 0.135);
    headGroup.add(capCrest);
  } else if (custom.accessory === 'sunglasses') {
    const glassesMat = new THREE.MeshPhysicalMaterial({
      color: '#09090b',
      roughness: 0.06,
      metalness: 0.88,
      clearcoat: 1.0,
    });
    [-0.048, 0.048].forEach((gx) => {
      const lens = new THREE.Mesh(new THREE.BoxGeometry(0.072, 0.042, 0.028), glassesMat);
      lens.position.set(gx, 0.175, 0.136);
      headGroup.add(lens);
    });
    const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.185, 0.014, 0.022), glassesMat);
    bridge.position.set(0, 0.184, 0.136);
    headGroup.add(bridge);
  } else if (custom.accessory === 'cap') {
    const cap = new THREE.Mesh(
      new THREE.SphereGeometry(0.14, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.5),
      accentMat
    );
    cap.position.set(0, 0.195, 0);
    headGroup.add(cap);
    const brim = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.018, 0.13), accentMat);
    brim.position.set(0, 0.228, 0.145);
    headGroup.add(brim);
  } else if (custom.accessory === 'sindhi_cap') {
    const topiMat = textures
      ? new THREE.MeshStandardMaterial({ map: textures.sindhiTopi, roughness: 0.55 })
      : new THREE.MeshStandardMaterial({ color: '#b91c1c', roughness: 0.5 });
    const topi = new THREE.Mesh(new THREE.CylinderGeometry(0.122, 0.132, 0.095, 16), topiMat);
    topi.position.set(0, 0.27, 0);
    headGroup.add(topi);
  }

  return {
    group: root,
    pelvisGroup,
    torsoGroup,
    headGroup,
    eyelidsGroup,
    leftArm: leftArmData.shoulderPivot,
    leftElbow: leftArmData.elbowPivot,
    rightArm: rightArmData.shoulderPivot,
    rightElbow: rightArmData.elbowPivot,
    leftLeg: leftLegData.hipPivot,
    leftKnee: leftLegData.kneePivot,
    rightLeg: rightLegData.hipPivot,
    rightKnee: rightLegData.kneePivot,
  };
}

export function animateCharacterRig(rig: ArticulatedCharacter, state: CharacterAnimState) {
  const t = state.elapsedSec;
  const blinkSeed = state.blinkSeed ?? 0;

  // Natural periodic eye blinking every ~3.8s
  const blinkCycle = (t + blinkSeed) % 3.8;
  const isBlinking = blinkCycle > 3.66;
  rig.eyelidsGroup.children.forEach((lid) => {
    lid.scale.y = isBlinking ? 1.35 : 0.22;
  });

  // Reset pelvis height & orientation defaults
  rig.pelvisGroup.position.y = 0.88;
  rig.pelvisGroup.rotation.set(0, 0, 0);
  rig.torsoGroup.rotation.set(0, 0, 0);
  rig.headGroup.rotation.set(0, 0, 0);

  if (state.mode === 'seated') {
    const steer = state.steerAngle ?? 0;
    rig.pelvisGroup.position.y = 0.82;
    rig.torsoGroup.rotation.x = -0.08;
    rig.torsoGroup.rotation.z = -steer * 0.22;
    rig.leftLeg.rotation.set(-1.32, 0, 0.08);
    rig.rightLeg.rotation.set(-1.32, 0, -0.08);
    rig.leftKnee.rotation.x = 1.42;
    rig.rightKnee.rotation.x = 1.42;
    rig.leftArm.rotation.set(-1.12, 0, -0.15 + steer * 0.18);
    rig.rightArm.rotation.set(-1.12, 0, 0.15 + steer * 0.18);
    rig.leftElbow.rotation.x = -0.38;
    rig.rightElbow.rotation.x = -0.38;
    rig.headGroup.rotation.y = steer * 0.35;
    return;
  }

  if (state.mode === 'swim') {
    rig.torsoGroup.rotation.x = 1.15;
    rig.leftArm.rotation.set(-Math.PI * 0.6 + Math.sin(t * 7) * 0.7, 0, 0);
    rig.rightArm.rotation.set(-Math.PI * 0.6 - Math.sin(t * 7) * 0.7, 0, 0);
    rig.leftElbow.rotation.x = -0.4;
    rig.rightElbow.rotation.x = -0.4;
    rig.leftLeg.rotation.set(Math.sin(t * 8) * 0.4, 0, 0);
    rig.rightLeg.rotation.set(-Math.sin(t * 8) * 0.4, 0, 0);
    rig.leftKnee.rotation.x = 0.35 + Math.cos(t * 8) * 0.25;
    rig.rightKnee.rotation.x = 0.35 - Math.cos(t * 8) * 0.25;
    return;
  }

  if (state.mode === 'walk' || state.mode === 'run') {
    const isRun = state.mode === 'run';
    const ph = state.walkPhase;
    const strideAmp = isRun ? 0.86 : 0.56;
    const armAmp = isRun ? 0.92 : 0.52;
    const s = Math.sin(ph);
    const c = Math.cos(ph);

    // Pelvis bounce & natural hip counter-twist
    rig.pelvisGroup.position.y = 0.88 + Math.abs(s) * (isRun ? 0.055 : 0.025);
    rig.pelvisGroup.rotation.y = s * (isRun ? 0.12 : 0.06);

    // Torso forward lean & counter-rotation
    rig.torsoGroup.rotation.x = isRun ? 0.2 : 0.06;
    rig.torsoGroup.rotation.y = -s * (isRun ? 0.16 : 0.08);

    // Hip flexion & extension
    rig.leftLeg.rotation.set(s * strideAmp, 0, 0);
    rig.rightLeg.rotation.set(-s * strideAmp, 0, 0);

    // Biomechanical knee bend (bends rearward during swing & push-off)
    rig.leftKnee.rotation.x = Math.max(0.06, -c * (isRun ? 1.15 : 0.65) + (isRun ? 0.35 : 0.15));
    rig.rightKnee.rotation.x = Math.max(0.06, c * (isRun ? 1.15 : 0.65) + (isRun ? 0.35 : 0.15));

    // Shoulder swing & natural elbow flexion
    rig.leftArm.rotation.set(-s * armAmp, 0, 0.06);
    rig.rightArm.rotation.set(s * armAmp, 0, -0.06);
    rig.leftElbow.rotation.x = isRun ? -1.15 + s * 0.25 : -0.35 - s * 0.2;
    rig.rightElbow.rotation.x = isRun ? -1.15 - s * 0.25 : -0.35 + s * 0.2;
    return;
  }

  if (state.mode === 'vendor') {
    const breath = Math.sin(t * 2.2 + blinkSeed);
    rig.torsoGroup.rotation.x = 0.04 + breath * 0.015;
    rig.headGroup.rotation.y = Math.sin(t * 1.1 + blinkSeed) * 0.25;
    rig.leftArm.rotation.set(-0.35 + Math.sin(t * 3.2) * 0.15, 0, 0.08);
    rig.rightArm.rotation.set(-0.65 + Math.cos(t * 4.2) * 0.25, 0, -0.12);
    rig.leftElbow.rotation.x = -0.65;
    rig.rightElbow.rotation.x = -0.95 + Math.sin(t * 4.5) * 0.2;
    rig.leftLeg.rotation.set(0, 0, 0.04);
    rig.rightLeg.rotation.set(0, 0, -0.04);
    rig.leftKnee.rotation.x = 0.04;
    rig.rightKnee.rotation.x = 0.04;
    return;
  }

  // Natural Breathing & Weight-Shift Idle
  const breath = Math.sin(t * 2.0 + blinkSeed);
  rig.torsoGroup.rotation.x = breath * 0.02;
  rig.headGroup.rotation.y = Math.sin(t * 0.75 + blinkSeed) * 0.18;
  rig.leftArm.rotation.set(breath * 0.03, 0, 0.06);
  rig.rightArm.rotation.set(-breath * 0.03, 0, -0.06);
  rig.leftElbow.rotation.x = -0.18;
  rig.rightElbow.rotation.x = -0.18;
  rig.leftLeg.rotation.set(0, 0, 0.03);
  rig.rightLeg.rotation.set(0, 0, -0.03);
  rig.leftKnee.rotation.x = 0.03;
  rig.rightKnee.rotation.x = 0.03;
}

export function createVehicleRig(
  type: VehicleType,
  textures: ProceduralTextureSet,
  colorOverride?: string,
  isPolice = false
): VehicleRig {
  const spec = VEHICLE_SPECS[type];
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const driverMount = new THREE.Group();
  driverMount.position.set(
    spec.seatOffset.x,
    type === 'motorcycle' ? 0.12 : spec.seatOffset.y - 0.72,
    type === 'motorcycle' ? -0.22 : spec.seatOffset.z - 0.12
  );
  bodyGroup.add(driverMount);

  const primaryColor = isPolice ? '#f8fafc' : colorOverride || spec.defaultColor;

  const paintMat = new THREE.MeshPhysicalMaterial({
    color: primaryColor,
    metalness: 0.62,
    roughness: 0.22,
    clearcoat: 1.0,
    clearcoatRoughness: 0.08,
  });

  const darkTrimMat = new THREE.MeshStandardMaterial({
    color: '#18181b',
    roughness: 0.68,
    metalness: 0.28,
  });

  const chromeMat = new THREE.MeshStandardMaterial({
    color: '#e2e8f0',
    roughness: 0.14,
    metalness: 0.94,
  });

  const interiorMat = new THREE.MeshStandardMaterial({
    color: '#1e293b',
    roughness: 0.84,
    metalness: 0.1,
  });

  const glassMat = new THREE.MeshPhysicalMaterial({
    color: '#93c5fd',
    metalness: 0.12,
    roughness: 0.05,
    transparent: true,
    opacity: 0.36,
    depthWrite: false,
    clearcoat: 1.0,
  });

  const tireMat = new THREE.MeshStandardMaterial({
    color: '#0f172a',
    roughness: 0.86,
    metalness: 0.06,
  });

  const headlights: THREE.MeshBasicMaterial[] = [];
  const brakelights: THREE.MeshBasicMaterial[] = [];
  const wheels: THREE.Object3D[] = [];
  const frontWheelPivots: THREE.Object3D[] = [];

  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(spec.width * 1.48, spec.length * 1.26),
    new THREE.MeshBasicMaterial({
      map: textures.contactShadow,
      transparent: true,
      depthWrite: false,
      opacity: 0.56,
    })
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.03;
  root.add(contactShadow);

  const addWheel = (x: number, y: number, z: number, radius: number, width: number, isFront: boolean) => {
    const pivot = new THREE.Group();
    pivot.position.set(x, y, z);
    const wheel = new THREE.Group();
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, width, 22), tireMat);
    tire.rotation.z = Math.PI / 2;
    tire.castShadow = true;
    wheel.add(tire);

    const rim = new THREE.Mesh(
      new THREE.CylinderGeometry(radius * 0.6, radius * 0.6, width + 0.025, 14),
      chromeMat
    );
    rim.rotation.z = Math.PI / 2;
    wheel.add(rim);

    // 5-spoke alloy detail
    const hub = new THREE.Mesh(
      new THREE.CylinderGeometry(radius * 0.22, radius * 0.22, width + 0.04, 10),
      darkTrimMat
    );
    hub.rotation.z = Math.PI / 2;
    wheel.add(hub);

    pivot.add(wheel);
    bodyGroup.add(pivot);
    wheels.push(wheel);
    if (isFront) frontWheelPivots.push(pivot);
  };

  let steeringWheel: THREE.Object3D | null = null;
  const addCockpitInterior = (dashX: number, dashY: number, dashZ: number, dashW: number) => {
    const dash = new THREE.Mesh(new THREE.BoxGeometry(dashW, 0.24, 0.36), interiorMat);
    dash.position.set(0, dashY, dashZ);
    bodyGroup.add(dash);

    const gaugePanel = new THREE.Mesh(
      new THREE.PlaneGeometry(0.46, 0.18),
      new THREE.MeshBasicMaterial({ map: textures.dashboardGauge })
    );
    gaugePanel.position.set(dashX, dashY + 0.04, dashZ - 0.19);
    gaugePanel.rotation.y = Math.PI;
    bodyGroup.add(gaugePanel);

    const swPivot = new THREE.Group();
    swPivot.position.set(dashX, dashY + 0.08, dashZ - 0.26);
    swPivot.rotation.x = -0.35;
    const swRing = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.022, 8, 18), darkTrimMat);
    swPivot.add(swRing);
    const swSpoke = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.03, 0.02), chromeMat);
    swPivot.add(swSpoke);
    bodyGroup.add(swPivot);
    steeringWheel = swPivot;

    const seatOffsets = dashW > 1.2 ? [-Math.abs(dashX), Math.abs(dashX)] : [0];
    seatOffsets.forEach((sx) => {
      const seatBase = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.12, 0.44), interiorMat);
      seatBase.position.set(sx, dashY - 0.34, dashZ - 0.55);
      bodyGroup.add(seatBase);
      const seatBack = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.54, 0.11), interiorMat);
      seatBack.position.set(sx, dashY - 0.06, dashZ - 0.75);
      seatBack.rotation.x = -0.15;
      bodyGroup.add(seatBack);
    });
  };

  const addLights = (w: number, yFront: number, zFront: number, yRear: number, zRear: number) => {
    const hlMat = new THREE.MeshBasicMaterial({ color: '#fef9c3' });
    const blMat = new THREE.MeshBasicMaterial({ color: '#b91c1c' });
    headlights.push(hlMat);
    brakelights.push(blMat);

    [-w * 0.36, w * 0.36].forEach((lx) => {
      const hl = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.13, 0.07), hlMat);
      hl.position.set(lx, yFront, zFront);
      bodyGroup.add(hl);

      const bl = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.12, 0.07), blMat);
      bl.position.set(lx, yRear, zRear);
      bodyGroup.add(bl);
    });
  };

  if (type === 'boat') {
    const hull = new THREE.Mesh(new THREE.BoxGeometry(2.15, 0.72, 5.4), paintMat);
    hull.position.set(0, 0.45, -0.2);
    hull.castShadow = true;
    bodyGroup.add(hull);

    const bow = new THREE.Mesh(new THREE.ConeGeometry(1.12, 1.9, 4), paintMat);
    bow.rotation.x = Math.PI / 2;
    bow.rotation.y = Math.PI / 4;
    bow.scale.set(1.25, 1, 0.55);
    bow.position.set(0, 0.55, 3.12);
    bow.castShadow = true;
    bodyGroup.add(bow);

    const stripe = new THREE.Mesh(
      new THREE.BoxGeometry(2.2, 0.14, 5.2),
      new THREE.MeshStandardMaterial({ color: '#0284c7', roughness: 0.25 })
    );
    stripe.position.set(0, 0.62, -0.15);
    bodyGroup.add(stripe);

    const windshield = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.52, 0.08), glassMat);
    windshield.position.set(0, 1.08, 1.0);
    windshield.rotation.x = -0.5;
    bodyGroup.add(windshield);

    const outboard = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.9, 0.55), darkTrimMat);
    outboard.position.set(0, 0.58, -3.1);
    bodyGroup.add(outboard);

    addCockpitInterior(0.35, 0.92, 0.75, 1.45);
    addLights(1.5, 0.72, 2.45, 0.72, -2.9);
  } else if (type === 'motorcycle') {
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.35, 1.25), darkTrimMat);
    frame.position.set(0, 0.58, 0);
    frame.castShadow = true;
    bodyGroup.add(frame);

    const tank = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.36, 6, 10), paintMat);
    tank.rotation.x = Math.PI / 2;
    tank.position.set(0, 0.86, 0.25);
    tank.castShadow = true;
    bodyGroup.add(tank);

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.14, 0.72), interiorMat);
    seat.position.set(0, 0.82, -0.35);
    bodyGroup.add(seat);

    const fork = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.78, 8), chromeMat);
    fork.position.set(0, 0.62, 0.68);
    fork.rotation.x = -0.32;
    bodyGroup.add(fork);

    const handlebar = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.05, 0.06), chromeMat);
    handlebar.position.set(0, 0.98, 0.56);
    bodyGroup.add(handlebar);
    steeringWheel = handlebar;

    const exhaust = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.055, 0.95, 10), chromeMat);
    exhaust.rotation.x = Math.PI / 2;
    exhaust.position.set(0.18, 0.36, -0.35);
    bodyGroup.add(exhaust);

    addWheel(0, 0.32, 0.72, 0.32, 0.11, true);
    addWheel(0, 0.32, -0.72, 0.32, 0.12, false);

    const hlMat = new THREE.MeshBasicMaterial({ color: '#fef9c3' });
    headlights.push(hlMat);
    const hl = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.12, 12), hlMat);
    hl.rotation.x = Math.PI / 2;
    hl.position.set(0, 0.86, 0.72);
    bodyGroup.add(hl);

    const blMat = new THREE.MeshBasicMaterial({ color: '#b91c1c' });
    brakelights.push(blMat);
    const bl = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.09, 0.05), blMat);
    bl.position.set(0, 0.75, -0.82);
    bodyGroup.add(bl);
  } else if (type === 'rickshaw') {
    const lowerBody = new THREE.Mesh(new THREE.BoxGeometry(1.32, 0.58, 2.35), paintMat);
    lowerBody.position.set(0, 0.54, -0.05);
    lowerBody.castShadow = true;
    bodyGroup.add(lowerBody);

    const frontNose = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.72, 0.65), paintMat);
    frontNose.position.set(0, 0.64, 1.05);
    frontNose.castShadow = true;
    bodyGroup.add(frontNose);

    const canopyMat = new THREE.MeshStandardMaterial({ color: '#eab308', roughness: 0.68 });
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(1.34, 0.14, 2.2), canopyMat);
    canopy.position.set(0, 1.66, -0.1);
    canopy.castShadow = true;
    bodyGroup.add(canopy);

    const rearCurtain = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.82, 0.12), canopyMat);
    rearCurtain.position.set(0, 1.22, -1.16);
    bodyGroup.add(rearCurtain);

    const windshield = new THREE.Mesh(new THREE.BoxGeometry(0.86, 0.52, 0.05), glassMat);
    windshield.position.set(0, 1.28, 0.98);
    windshield.rotation.x = -0.18;
    bodyGroup.add(windshield);

    [-0.62, 0.62].forEach((px) => {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.85, 0.06), darkTrimMat);
      pillar.position.set(px, 1.24, 0.88);
      bodyGroup.add(pillar);
    });

    addWheel(0, 0.28, 1.06, 0.28, 0.14, true);
    addWheel(-0.68, 0.28, -0.85, 0.28, 0.15, false);
    addWheel(0.68, 0.28, -0.85, 0.28, 0.15, false);
    addCockpitInterior(0, 0.96, 0.82, 0.9);
    addLights(1.1, 0.68, 1.38, 0.68, -1.24);
  } else if (type === 'bus' || type === 'truck') {
    const isBus = type === 'bus';
    const artMat = new THREE.MeshStandardMaterial({
      map: textures.truckArt,
      roughness: 0.38,
      metalness: 0.2,
    });

    const chassis = new THREE.Mesh(new THREE.BoxGeometry(spec.width, 0.38, spec.length), darkTrimMat);
    chassis.position.set(0, 0.56, 0);
    bodyGroup.add(chassis);

    if (isBus) {
      const coach = new THREE.Mesh(new THREE.BoxGeometry(spec.width, 2.05, spec.length), paintMat);
      coach.position.set(0, 1.72, 0);
      coach.castShadow = true;
      bodyGroup.add(coach);

      const artBand = new THREE.Mesh(new THREE.BoxGeometry(spec.width + 0.04, 0.65, spec.length - 0.1), artMat);
      artBand.position.set(0, 1.22, 0);
      bodyGroup.add(artBand);

      const roofRack = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.85, 0.24, spec.length * 0.72), chromeMat);
      roofRack.position.set(0, 2.86, -0.4);
      bodyGroup.add(roofRack);

      const windshield = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.88, 0.95, 0.08), glassMat);
      windshield.position.set(0, 2.05, spec.length / 2 + 0.02);
      bodyGroup.add(windshield);

      const sideWindows = new THREE.Mesh(new THREE.BoxGeometry(spec.width + 0.03, 0.72, spec.length * 0.76), glassMat);
      sideWindows.position.set(0, 2.05, -0.2);
      bodyGroup.add(sideWindows);
    } else {
      const cab = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.94, 1.72, 2.15), paintMat);
      cab.position.set(0, 1.56, 2.25);
      cab.castShadow = true;
      bodyGroup.add(cab);

      const tajCrown = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.98, 0.68, 1.2), artMat);
      tajCrown.position.set(0, 2.74, 2.5);
      tajCrown.castShadow = true;
      bodyGroup.add(tajCrown);

      const cargo = new THREE.Mesh(new THREE.BoxGeometry(spec.width, 2.15, 4.95), artMat);
      cargo.position.set(0, 1.82, -1.25);
      cargo.castShadow = true;
      bodyGroup.add(cargo);

      const windshield = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.82, 0.68, 0.08), glassMat);
      windshield.position.set(0, 1.88, 3.34);
      bodyGroup.add(windshield);
    }

    const zFront = spec.length * 0.34;
    const zRear = -spec.length * 0.32;
    addWheel(-spec.width * 0.48, 0.48, zFront, 0.48, 0.28, true);
    addWheel(spec.width * 0.48, 0.48, zFront, 0.48, 0.28, true);
    addWheel(-spec.width * 0.48, 0.48, zRear, 0.48, 0.34, false);
    addWheel(spec.width * 0.48, 0.48, zRear, 0.48, 0.34, false);

    addCockpitInterior(spec.seatOffset.x, spec.seatOffset.y - 0.15, spec.seatOffset.z + 0.45, spec.width * 0.8);
    addLights(spec.width * 0.85, 0.95, spec.length / 2 + 0.03, 0.95, -spec.length / 2 - 0.03);
  } else {
    // Realistic Multi-Part Sedans, Hatchbacks & SUVs
    const isSuv = type === 'land_cruiser';
    const isHatch = type === 'mehran' || type === 'alto';
    const isSports = type === 'civic';
    const wheelR = isSuv ? 0.42 : 0.33;
    const bodyH = isSuv ? 0.72 : 0.52;
    const bodyY = wheelR + bodyH * 0.5 - 0.04;

    const lowerHull = new THREE.Mesh(new THREE.BoxGeometry(spec.width, bodyH, spec.length), paintMat);
    lowerHull.position.set(0, bodyY, 0);
    lowerHull.castShadow = true;
    lowerHull.receiveShadow = true;
    bodyGroup.add(lowerHull);

    // Sculpted sloped hood
    const hoodSlope = new THREE.Mesh(
      new THREE.BoxGeometry(spec.width * 0.9, 0.1, spec.length * 0.28),
      paintMat
    );
    hoodSlope.position.set(0, bodyY + bodyH * 0.46, spec.length * 0.31);
    hoodSlope.rotation.x = 0.08;
    bodyGroup.add(hoodSlope);

    // Front & rear bumpers + Pakistani KHI License Plates
    const frontBumper = new THREE.Mesh(
      new THREE.BoxGeometry(spec.width + 0.05, 0.22, 0.2),
      isSuv || isHatch ? darkTrimMat : paintMat
    );
    frontBumper.position.set(0, wheelR + 0.08, spec.length / 2 + 0.04);
    bodyGroup.add(frontBumper);

    const rearBumper = new THREE.Mesh(
      new THREE.BoxGeometry(spec.width + 0.05, 0.22, 0.2),
      isSuv || isHatch ? darkTrimMat : paintMat
    );
    rearBumper.position.set(0, wheelR + 0.08, -spec.length / 2 - 0.04);
    bodyGroup.add(rearBumper);

    const plateMat = new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.35 });
    [spec.length / 2 + 0.15, -spec.length / 2 - 0.15].forEach((pz) => {
      const plate = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.14, 0.02), plateMat);
      plate.position.set(0, wheelR + 0.08, pz);
      bodyGroup.add(plate);
    });

    // Front Chrome Grille
    const grille = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.56, 0.24, 0.06), chromeMat);
    grille.position.set(0, bodyY + 0.04, spec.length / 2 + 0.02);
    bodyGroup.add(grille);

    const cabinLen = isSuv ? spec.length * 0.66 : isHatch ? spec.length * 0.58 : spec.length * 0.5;
    const cabinZ = isSuv ? -0.3 : isHatch ? -0.22 : -0.15;
    const cabinH = isSuv ? 0.68 : 0.54;
    const cabinY = bodyY + bodyH * 0.5 + cabinH * 0.5 - 0.02;

    const roof = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.84, 0.09, cabinLen * 0.82), paintMat);
    roof.position.set(0, cabinY + cabinH * 0.45, cabinZ);
    roof.castShadow = true;
    bodyGroup.add(roof);

    // Side-view Mirrors
    [-spec.width * 0.53, spec.width * 0.53].forEach((mx) => {
      const mirror = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.1, 0.14), paintMat);
      mirror.position.set(mx, bodyY + bodyH * 0.55, cabinZ + cabinLen * 0.36);
      bodyGroup.add(mirror);
    });

    // Civic Sport Spoiler / Land Cruiser Roof Rails & Rear Spare Wheel
    if (isSports) {
      const spoiler = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.88, 0.06, 0.24), darkTrimMat);
      spoiler.position.set(0, bodyY + bodyH * 0.64, -spec.length * 0.44);
      bodyGroup.add(spoiler);
    }
    if (isSuv) {
      [-spec.width * 0.34, spec.width * 0.34].forEach((rx) => {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.08, cabinLen * 0.72), chromeMat);
        rail.position.set(rx, cabinY + cabinH * 0.52, cabinZ);
        bodyGroup.add(rail);
      });
      const spare = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.2, 16), tireMat);
      spare.rotation.x = Math.PI / 2;
      spare.position.set(0, bodyY + 0.18, -spec.length / 2 - 0.1);
      bodyGroup.add(spare);
    }

    // Pillars
    [
      [-spec.width * 0.39, cabinZ + cabinLen * 0.36],
      [spec.width * 0.39, cabinZ + cabinLen * 0.36],
      [-spec.width * 0.39, cabinZ - cabinLen * 0.36],
      [spec.width * 0.39, cabinZ - cabinLen * 0.36],
    ].forEach(([px, pz]) => {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.08, cabinH, 0.08), darkTrimMat);
      pillar.position.set(px, cabinY, pz);
      bodyGroup.add(pillar);
    });

    const frontGlass = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.8, cabinH * 0.9, 0.05), glassMat);
    frontGlass.position.set(0, cabinY, cabinZ + cabinLen * 0.41);
    frontGlass.rotation.x = -0.35;
    bodyGroup.add(frontGlass);

    const rearGlass = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.8, cabinH * 0.88, 0.05), glassMat);
    rearGlass.position.set(0, cabinY, cabinZ - cabinLen * 0.41);
    rearGlass.rotation.x = isHatch || isSuv ? 0.15 : 0.42;
    bodyGroup.add(rearGlass);

    const sideGlass = new THREE.Mesh(new THREE.BoxGeometry(spec.width * 0.86, cabinH * 0.78, cabinLen * 0.72), glassMat);
    sideGlass.position.set(0, cabinY, cabinZ);
    bodyGroup.add(sideGlass);

    let sirenBars: VehicleRig['sirenBars'] | undefined;
    if (isPolice) {
      const policeDoorStripe = new THREE.Mesh(
        new THREE.BoxGeometry(spec.width + 0.02, 0.24, spec.length * 0.48),
        new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.4 })
      );
      policeDoorStripe.position.set(0, bodyY + 0.05, 0);
      bodyGroup.add(policeDoorStripe);

      const redMat = new THREE.MeshBasicMaterial({ color: '#ef4444' });
      const blueMat = new THREE.MeshBasicMaterial({ color: '#3b82f6' });
      const barBase = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.1, 0.22), darkTrimMat);
      barBase.position.set(0, cabinY + cabinH * 0.56, cabinZ + 0.1);
      bodyGroup.add(barBase);
      const redBeacon = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.12, 0.24), redMat);
      redBeacon.position.set(-0.24, cabinY + cabinH * 0.58, cabinZ + 0.1);
      bodyGroup.add(redBeacon);
      const blueBeacon = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.12, 0.24), blueMat);
      blueBeacon.position.set(0.24, cabinY + cabinH * 0.58, cabinZ + 0.1);
      bodyGroup.add(blueBeacon);
      sirenBars = { red: redMat, blue: blueMat };
    }

    const zFront = spec.length * 0.31;
    const zRear = -spec.length * 0.31;
    addWheel(-spec.width * 0.46, wheelR, zFront, wheelR, 0.21, true);
    addWheel(spec.width * 0.46, wheelR, zFront, wheelR, 0.21, true);
    addWheel(-spec.width * 0.46, wheelR, zRear, wheelR, 0.22, false);
    addWheel(spec.width * 0.46, wheelR, zRear, wheelR, 0.22, false);

    addCockpitInterior(spec.seatOffset.x, bodyY + bodyH * 0.45, cabinZ + 0.48, spec.width * 0.78);
    addLights(spec.width * 0.88, bodyY + 0.06, spec.length / 2 + 0.03, bodyY + 0.08, -spec.length / 2 - 0.03);

    return {
      group: root,
      bodyGroup,
      driverMount,
      wheels,
      frontWheelPivots,
      steeringWheel,
      headlights,
      brakelights,
      sirenBars,
    };
  }

  return {
    group: root,
    bodyGroup,
    driverMount,
    wheels,
    frontWheelPivots,
    steeringWheel,
    headlights,
    brakelights,
  };
}
