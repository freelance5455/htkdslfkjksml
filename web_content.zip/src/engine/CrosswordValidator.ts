import {
  CrosswordLayout,
  ValidationResult,
  ValidationItem
} from '../types/crosswordLayout';

export function validateCrosswordLayout(layout: CrosswordLayout): ValidationResult {
  const items: ValidationItem[] = [];
  const { gridRows, gridColumns, cells, words, blackCells } = layout;

  // Build quick cell lookup map: "r_c" => cell
  const cellMap = new Map<string, typeof cells[0]>();
  for (const cell of cells) {
    cellMap.set(`${cell.row}_${cell.column}`, cell);
  }

  // 1. Check exactly 25 words present
  const wordsPresent = words.length === 25;
  items.push({
    key: 'words_present',
    label: 'جميع الكلمات الـ 25 موجودة',
    passed: wordsPresent,
    message: wordsPresent ? 'توجد 25 كلمة بالضبط في القائمة' : `العدد الحالي: ${words.length}`
  });

  // 2. Check 25 words placed with coordinates
  const allPlaced = words.every(
    (w) =>
      w.startRow >= 0 &&
      w.startColumn >= 0 &&
      w.length > 0 &&
      Array.isArray(w.cells) &&
      w.cells.length === w.length
  );
  items.push({
    key: 'words_placed',
    label: 'جميع الكلمات الـ 25 موضوعة على الشبكة',
    passed: allPlaced && wordsPresent,
    message: allPlaced ? 'جميع الكلمات لها مواقع وإحداثيات صحيحة' : 'بعض الكلمات غير موضوعة'
  });

  // 3. Check lengths match normalized answers
  const lengthsMatch = words.every((w) => w.length === w.normalizedAnswer.length);
  items.push({
    key: 'lengths_match',
    label: 'طول كل كلمة مطابق للإجابة',
    passed: lengthsMatch,
    message: lengthsMatch ? 'جميع الأطوال مطابقة لعدد أحرف الإجابات' : 'يوجد اختلاف في أطوال الإجابات'
  });

  // 4. No black cell inside any word
  let blackCellInsideWord = false;
  for (const w of words) {
    for (let i = 0; i < w.length; i++) {
      const r = w.direction === 'down' ? w.startRow + i : w.startRow;
      const c = w.direction === 'across' ? w.startColumn + i : w.startColumn;
      const cell = cellMap.get(`${r}_${c}`);
      if (!cell || cell.isBlocked) {
        blackCellInsideWord = true;
        break;
      }
    }
  }
  items.push({
    key: 'no_black_inside_word',
    label: 'لا يوجد مربع أسود داخل أي كلمة',
    passed: !blackCellInsideWord,
    message: !blackCellInsideWord ? 'كافة خلايا الكلمات بيضاء ونشطة' : 'يوجد مربع أسود يعترض إحدى الكلمات'
  });

  // 5. Letter matching and valid cross intersections
  let lettersMatch = true;
  let letterConflictFound = false;
  let intersectionsCount = 0;

  for (const w of words) {
    for (let i = 0; i < w.length; i++) {
      const r = w.direction === 'down' ? w.startRow + i : w.startRow;
      const c = w.direction === 'across' ? w.startColumn + i : w.startColumn;
      const expectedChar = w.normalizedAnswer[i];
      const cell = cellMap.get(`${r}_${c}`);

      if (!cell || cell.isBlocked) {
        lettersMatch = false;
        break;
      }

      if (cell.letter && cell.letter !== expectedChar) {
        letterConflictFound = true;
        lettersMatch = false;
      }
    }
  }

  // Count actual intersections (cells with both acrossWordId and downWordId)
  for (const cell of cells) {
    if (!cell.isBlocked && cell.acrossWordId && cell.downWordId) {
      intersectionsCount++;
    }
  }

  items.push({
    key: 'letters_and_intersections',
    label: 'جميع التقاطعات متعامدة وصحيحة ومتطابقة الحروف',
    passed: lettersMatch && !letterConflictFound && intersectionsCount > 0,
    message: lettersMatch && !letterConflictFound
      ? `تم التحقق من تطابق جميع الحروف. عدد التقاطعات: ${intersectionsCount}`
      : 'يوجد تعارض في الأحرف عند بعض التقاطعات'
  });

  // 6. No orphan white cells (every white cell must belong to at least one word)
  let orphanCellsFound = false;
  for (const cell of cells) {
    if (!cell.isBlocked) {
      if (!cell.acrossWordId && !cell.downWordId) {
        orphanCellsFound = true;
        break;
      }
    }
  }
  items.push({
    key: 'no_orphan_cells',
    label: 'لا توجد خلايا بيضاء يتيمة أو معزولة',
    passed: !orphanCellsFound,
    message: !orphanCellsFound ? 'كل خلية بيضاء تنتمي لكلمة معتمدة واحدة على الأقل' : 'توجد خلايا بيضاء لا تنتمي لأي كلمة'
  });

  // 7. Parallel Separation Rule:
  // - No two horizontal words in adjacent rows touching unless connected by a valid Down word passing through both
  // - No two vertical words in adjacent columns touching unless connected by a valid Across word passing through both
  let parallelAcrossViolation = false;
  let parallelDownViolation = false;

  for (const w of words) {
    if (w.direction === 'across') {
      for (let i = 0; i < w.length; i++) {
        const r = w.startRow;
        const c = w.startColumn + i;

        // Check cell above (r - 1, c)
        const topCell = cellMap.get(`${r - 1}_${c}`);
        if (topCell && !topCell.isBlocked) {
          // If top cell is white, is there a down word that passes through BOTH (r-1, c) and (r, c)?
          const downWord = words.find(
            (dw) =>
              dw.direction === 'down' &&
              dw.startColumn === c &&
              dw.startRow <= r - 1 &&
              dw.startRow + dw.length - 1 >= r
          );
          if (!downWord) {
            parallelAcrossViolation = true;
          }
        }

        // Check cell below (r + 1, c)
        const bottomCell = cellMap.get(`${r + 1}_${c}`);
        if (bottomCell && !bottomCell.isBlocked) {
          // If bottom cell is white, is there a down word that passes through BOTH (r, c) and (r+1, c)?
          const downWord = words.find(
            (dw) =>
              dw.direction === 'down' &&
              dw.startColumn === c &&
              dw.startRow <= r &&
              dw.startRow + dw.length - 1 >= r + 1
          );
          if (!downWord) {
            parallelAcrossViolation = true;
          }
        }
      }
    } else { // 'down'
      for (let i = 0; i < w.length; i++) {
        const r = w.startRow + i;
        const c = w.startColumn;

        // Check left cell (r, c - 1)
        const leftCell = cellMap.get(`${r}_${c - 1}`);
        if (leftCell && !leftCell.isBlocked) {
          // If left cell is white, is there an across word that passes through BOTH (r, c-1) and (r, c)?
          const acrossWord = words.find(
            (aw) =>
              aw.direction === 'across' &&
              aw.startRow === r &&
              aw.startColumn <= c - 1 &&
              aw.startColumn + aw.length - 1 >= c
          );
          if (!acrossWord) {
            parallelDownViolation = true;
          }
        }

        // Check right cell (r, c + 1)
        const rightCell = cellMap.get(`${r}_${c + 1}`);
        if (rightCell && !rightCell.isBlocked) {
          // If right cell is white, is there an across word that passes through BOTH (r, c) and (r, c+1)?
          const acrossWord = words.find(
            (aw) =>
              aw.direction === 'across' &&
              aw.startRow === r &&
              aw.startColumn <= c &&
              aw.startColumn + aw.length - 1 >= c + 1
          );
          if (!acrossWord) {
            parallelDownViolation = true;
          }
        }
      }
    }
  }

  items.push({
    key: 'parallel_across_separation',
    label: 'فصل الكلمات الأفقية المتوازية بمربعات سوداء',
    passed: !parallelAcrossViolation,
    message: !parallelAcrossViolation
      ? 'لا توجد كلمات أفقية متجاورة بدون فاصل أسود أو تقاطع عمودي صحيح'
      : 'توجد كلمات أفقية متوازية متلاصقة بدون فاصل'
  });

  items.push({
    key: 'parallel_down_separation',
    label: 'فصل الكلمات العمودية المتوازية بمربعات سوداء',
    passed: !parallelDownViolation,
    message: !parallelDownViolation
      ? 'لا توجد كلمات عمودية متجاورة بدون فاصل أسود أو تقاطع أفقي صحيح'
      : 'توجد كلمات عمودية متوازية متلاصقة بدون فاصل'
  });

  // 8. Unintended Words Check:
  // ANY contiguous white cell run >= 2 horizontally or vertically must match a registered word.
  let unintendedWordsCount = 0;

  // Check horizontal runs
  for (let r = 0; r < gridRows; r++) {
    let runStart = -1;
    let runLen = 0;
    for (let c = 0; c <= gridColumns; c++) {
      const cell = cellMap.get(`${r}_${c}`);
      if (cell && !cell.isBlocked) {
        if (runLen === 0) runStart = c;
        runLen++;
      } else {
        if (runLen >= 2) {
          const matchingWord = words.find(
            (w) =>
              w.direction === 'across' &&
              w.startRow === r &&
              w.startColumn === runStart &&
              w.length === runLen
          );
          if (!matchingWord) {
            unintendedWordsCount++;
          }
        }
        runLen = 0;
      }
    }
  }

  // Check vertical runs
  for (let c = 0; c < gridColumns; c++) {
    let runStart = -1;
    let runLen = 0;
    for (let r = 0; r <= gridRows; r++) {
      const cell = cellMap.get(`${r}_${c}`);
      if (cell && !cell.isBlocked) {
        if (runLen === 0) runStart = r;
        runLen++;
      } else {
        if (runLen >= 2) {
          const matchingWord = words.find(
            (w) =>
              w.direction === 'down' &&
              w.startRow === runStart &&
              w.startColumn === c &&
              w.length === runLen
          );
          if (!matchingWord) {
            unintendedWordsCount++;
          }
        }
        runLen = 0;
      }
    }
  }

  items.push({
    key: 'unintended_words',
    label: 'لا توجد كلمات عرضية غير مقصودة (Unintended Words = 0)',
    passed: unintendedWordsCount === 0,
    message:
      unintendedWordsCount === 0
        ? 'جميع السلاسل البيضاء (طول >= 2) هي كلمات معتمدة رسمياً'
        : `توجد ${unintendedWordsCount} كلمات عرضية غير مقصودة`
  });

  // 9. Single Connected Component Check (BFS)
  const whiteCells = cells.filter((c) => !c.isBlocked);
  let isConnected = true;

  if (whiteCells.length === 0) {
    isConnected = false;
  } else {
    const visited = new Set<string>();
    const queue: { r: number; c: number }[] = [{ r: whiteCells[0].row, c: whiteCells[0].column }];
    visited.add(`${whiteCells[0].row}_${whiteCells[0].column}`);

    while (queue.length > 0) {
      const curr = queue.shift()!;
      const neighbors = [
        { r: curr.r - 1, c: curr.c },
        { r: curr.r + 1, c: curr.c },
        { r: curr.r, c: curr.c - 1 },
        { r: curr.r, c: curr.c + 1 }
      ];

      for (const n of neighbors) {
        const key = `${n.r}_${n.c}`;
        const neighborCell = cellMap.get(key);
        if (neighborCell && !neighborCell.isBlocked && !visited.has(key)) {
          visited.add(key);
          queue.push({ r: n.r, c: n.c });
        }
      }
    }

    isConnected = visited.size === whiteCells.length;
  }

  items.push({
    key: 'connectivity',
    label: 'جميع الكلمات متصلة ضمن شبكة واحدة (Connected Component)',
    passed: isConnected,
    message: isConnected
      ? 'الشبكة متصلة بالكامل في مكون واحد بدون أي مجموعات معزولة'
      : 'الشبكة تحتوي على مجموعات كلمات منفصلة'
  });

  // 10. Check all cells valid (bounds & grid cell count)
  const allCellsValid =
    cells.length === gridRows * gridColumns &&
    cells.every((c) => c.row >= 0 && c.row < gridRows && c.column >= 0 && c.column < gridColumns);

  items.push({
    key: 'cells_validity',
    label: 'جميع الخلايا ضمن حدود الشبكة المنظمة',
    passed: allCellsValid,
    message: allCellsValid
      ? `الشبكة منظمة بأبعاد ${gridRows}×${gridColumns}`
      : 'توجد خلايا خارج حدود الشبكة'
  });

  // 11. Check question numbers
  const numberCheck = words.every((w) => {
    const cell = cellMap.get(`${w.startRow}_${w.startColumn}`);
    return cell && cell.clueNumber !== undefined && cell.clueNumber > 0;
  });

  items.push({
    key: 'question_numbers',
    label: 'أرقام الأسئلة موجودة على خلايا البداية',
    passed: numberCheck,
    message: numberCheck
      ? 'تم تعيين أرقام التلميحات بشكل منتظم'
      : 'توجد كلمات بدون أرقام أسئلة عند البداية'
  });

  // 12. Clear start and end check
  let clearStartEnd = true;
  for (const w of words) {
    if (w.direction === 'across') {
      const beforeCell = cellMap.get(`${w.startRow}_${w.startColumn - 1}`);
      const afterCell = cellMap.get(`${w.startRow}_${w.startColumn + w.length}`);
      if (beforeCell && !beforeCell.isBlocked) clearStartEnd = false;
      if (afterCell && !afterCell.isBlocked) clearStartEnd = false;
    } else {
      const beforeCell = cellMap.get(`${w.startRow - 1}_${w.startColumn}`);
      const afterCell = cellMap.get(`${w.startRow + w.length}_${w.startColumn}`);
      if (beforeCell && !beforeCell.isBlocked) clearStartEnd = false;
      if (afterCell && !afterCell.isBlocked) clearStartEnd = false;
    }
  }

  items.push({
    key: 'clear_start_end',
    label: 'بداية ونهاية كل كلمة محددة ومفصولة',
    passed: clearStartEnd,
    message: clearStartEnd
      ? 'بداية ونهاية كل كلمة محاطة بمربعات سوداء أو بحدود الشبكة'
      : 'توجد كلمة غير منتهية بمربع أسود'
  });

  const allPassed = items.every((i) => i.passed);

  return {
    isValid: allPassed,
    statusMessage: allPassed ? 'VALID GOLDEN LAYOUT' : 'INVALID LAYOUT',
    items,
    stats: {
      wordsCount: words.length,
      placedCount: words.filter((w) => w.startRow >= 0).length,
      intersectionsCount,
      gridSize: `${gridRows} × ${gridColumns}`,
      blackCellsCount: blackCells.length,
      isConnected,
      unintendedWordsCount
    }
  };
}
