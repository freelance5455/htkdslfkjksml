import {
  ALL_HABITAT_IDS,
  BOX_IDS,
  DAY_SECONDS,
  FERTILITY_COOLDOWN_SEC,
  GESTATION_DURATION_SEC,
  INITIAL_PEN_OBJECTS,
  INTERACTION_MIN_AUTO_END_SEC,
  MARKET_REFRESH_SEC,
  OUTSIDE_PEN_CAPACITY,
  PUP_ADULT_AGE_SEC,
  formatLocationLabel,
  formatSimClock,
} from '../data/kennelConstants';
import {
  ActivePlayerInteraction,
  ApproachReason,
  Dog,
  DogSocialAction,
  GameState,
  HabitatBowl,
  HabitatLocationId,
  LocationId,
  LogCategory,
  LogEntry,
  MarketListing,
  ObjectVerb,
  PenObject,
  PlayerAction,
  UniqueTrait,
} from '../types/kennel';
import {
  calculateAttributeCompatibility,
  calculateLitterSize,
  clamp,
  createBredPup,
  estimateDogMarketValue,
  generateRandomDog,
  makeId,
  pickOne,
  randInt,
} from './genetics';

export const SAVE_VERSION = 1;

function createEmptyBowls(): Record<HabitatLocationId, HabitatBowl> {
  const bowls = {} as Record<HabitatLocationId, HabitatBowl>;
  for (const id of ALL_HABITAT_IDS) {
    bowls[id] = { food: 0, water: 0 };
  }
  bowls.outside_pen = { food: 70, water: 80 };
  bowls.nursery_pen = { food: 65, water: 75 };
  bowls.box_1 = { food: 60, water: 70 };
  bowls.box_2 = { food: 60, water: 70 };
  return bowls;
}

function generateMarketBatch(existingNames: string[], totalElapsedSec: number): MarketListing[] {
  const count = randInt(3, 6);
  const listings: MarketListing[] = [];
  const usedNames = [...existingNames];
  for (let i = 0; i < count; i++) {
    const dog = generateRandomDog({
      location: 'box_1',
      origin: 'market',
      existingNames: usedNames,
    });
    usedNames.push(dog.name);
    listings.push({
      id: makeId('mkt'),
      dog,
      price: estimateDogMarketValue(dog),
      arrivedAtTotalSec: totalElapsedSec,
    });
  }
  return listings;
}

export function createInitialGameState(): GameState {
  const starter1 = generateRandomDog({
    location: 'outside_pen',
    origin: 'starter',
    forceAdult: true,
    forceGender: 'female',
    existingNames: [],
  });
  starter1.stats.fertility = 88;
  starter1.name = 'Kora';

  const starter2 = generateRandomDog({
    location: 'outside_pen',
    origin: 'starter',
    forceAdult: true,
    forceGender: 'male',
    existingNames: ['Kora'],
  });
  starter2.name = 'Tarka';

  const starter3 = generateRandomDog({
    location: 'box_1',
    origin: 'starter',
    forceAdult: true,
    forceGender: 'female',
    existingNames: ['Kora', 'Tarka'],
  });
  starter3.name = 'Bindi';

  const dogs = [starter1, starter2, starter3];
  const startClock = 8 * 3600 + 15 * 60; // 08:15:00

  return {
    version: SAVE_VERSION,
    simClockSec: startClock,
    totalElapsedSec: 0,
    dayCount: 1,
    isPaused: false,
    playerLocation: 'outside_pen',
    observingLocation: null,
    dogs,
    deceased: [],
    bowls: createEmptyBowls(),
    penObjects: INITIAL_PEN_OBJECTS.map((o) => ({ ...o })),
    marketListings: generateMarketBatch(['Kora', 'Tarka', 'Bindi'], 0),
    nextMarketRefreshSec: MARKET_REFRESH_SEC,
    logs: [
      {
        id: makeId('log'),
        simTimeSec: startClock,
        totalElapsedSec: 0,
        location: 'outside_pen',
        category: 'behavior',
        text: `You step inside the Outside Pen. ${starter1.name} pauses near the Timber Climbing Deck while ${starter2.name} tests the wind along the mesh.`,
        dogIds: [starter1.id, starter2.id],
      },
    ],
    activeInteraction: null,
    kennelCredits: 420,
    soldCount: 0,
    rehomedCount: 0,
    journalSelectedDogId: starter1.id,
    lastSavedAtMs: Date.now(),
  };
}

function addLog(
  logs: LogEntry[],
  simTimeSec: number,
  totalElapsedSec: number,
  location: HabitatLocationId,
  category: LogCategory,
  text: string,
  dogIds: string[] = []
): void {
  logs.push({
    id: makeId('log'),
    simTimeSec,
    totalElapsedSec,
    location,
    category,
    text,
    dogIds,
  });
}

function revealTrait(dog: Dog, trait: UniqueTrait): boolean {
  if (dog.traits.includes(trait) && !dog.discoveredTraits.includes(trait)) {
    dog.discoveredTraits.push(trait);
    return true;
  }
  return false;
}

function getOrCreatePair(a: Dog, bId: string, nowSec: number) {
  if (!a.pairRelations[bId]) {
    a.pairRelations[bId] = {
      affinity: 0,
      tension: 12,
      isAlly: false,
      lastUpdatedSimSec: nowSec,
    };
  }
  return a.pairRelations[bId];
}

function findFirstEmptyBox(dogs: Dog[]): HabitatLocationId | null {
  for (const boxId of BOX_IDS) {
    if (!dogs.some((d) => d.location === boxId)) {
      return boxId;
    }
  }
  return null;
}

export function isPup(dog: Dog): boolean {
  return dog.ageSeconds < PUP_ADULT_AGE_SEC;
}

function chooseApproachReason(dog: Dog, bowl: HabitatBowl): ApproachReason {
  const weights: Record<ApproachReason, number> = {
    curiosity: 22 + dog.playerRel.curiosity * 0.6 + (dog.traits.includes('focused') ? 10 : 0),
    affection: 10 + dog.playerRel.trust * 0.75 + (dog.traits.includes('clingy') ? 25 : 0) + (dog.traits.includes('likes humans') ? 22 : 0),
    territory: 8 + dog.stats.dominance * 0.4 + dog.playerRel.anger * 0.5 + (dog.traits.includes('reactive') ? 14 : 0),
    hunger: dog.stats.hunger > 45 ? 25 + (dog.stats.hunger - 40) * 0.9 + (bowl.food < 10 ? 15 : 0) : 4,
    fear: 8 + dog.playerRel.fear * 0.75 + (dog.traits.includes('dislikes humans') ? 24 : 0),
  };

  if (isPup(dog)) {
    weights.curiosity += 22;
    weights.affection += 16;
    weights.territory = 2;
  }

  const entries = Object.entries(weights) as [ApproachReason, number][];
  const total = entries.reduce((sum, [, w]) => sum + Math.max(1, w), 0);
  let r = Math.random() * total;
  for (const [reason, w] of entries) {
    r -= Math.max(1, w);
    if (r <= 0) return reason;
  }
  return 'curiosity';
}

function buildApproachOpeningText(dog: Dog, reason: ApproachReason): string {
  switch (reason) {
    case 'curiosity':
      return `${dog.name} trots halfway across the enclosure, ears angled forward, nose working carefully toward your boots.`;
    case 'affection':
      return `${dog.name} steps straight into your space with a loose tail sweep and leans a warm shoulder lightly beside your knee.`;
    case 'territory':
      return `${dog.name} plants all four feet squarely in front of you, chest lifted and gaze hard, testing whether you yield ground.`;
    case 'hunger':
      return `${dog.name} glances from the empty edge of the feed pan back up to your pockets, licking their muzzle expectantly.`;
    case 'fear':
      return `${dog.name} circles wide with lowered ears and tight hindquarters, pausing just within arm's reach while watching your hands.`;
  }
}

function runAutonomousPenObjectBehavior(
  dog: Dog,
  penObjects: PenObject[],
  state: GameState
): void {
  const obj = pickOne(penObjects);
  const verbs: ObjectVerb[] = ['investigating', 'sniffing', 'pawing', 'pacing'];

  if (dog.traits.includes('active') || dog.stats.energy > 65) {
    verbs.push('climbing', 'digging');
  }
  if (dog.traits.includes('possessive of toys') || dog.traits.includes('playful')) {
    verbs.push('biting');
  }
  if (dog.traits.includes('erratic') || dog.stats.stress > 65 || dog.stats.aggression > 68) {
    verbs.push('breaking', 'biting');
  }

  let verb = pickOne(verbs);
  if (obj.kind === 'climb' && Math.random() < 0.55) verb = 'climbing';
  if (obj.kind === 'dig' && Math.random() < 0.6) verb = 'digging';
  if (obj.kind === 'chew' && Math.random() < 0.55) verb = 'biting';
  if (obj.kind === 'fence' && Math.random() < 0.5) verb = 'pacing';
  if (obj.kind === 'scent' && Math.random() < 0.65) verb = 'sniffing';
  if (obj.kind === 'shelter' && dog.traits.includes('lazy')) verb = 'pacing';

  // Stat & object condition effects
  if (verb === 'climbing') {
    dog.stats.energy = clamp(dog.stats.energy - 4);
    dog.skills.agility = clamp(dog.skills.agility + 0.4);
    dog.stats.mood = clamp(dog.stats.mood + 3);
    revealTrait(dog, 'active');
  } else if (verb === 'digging') {
    dog.stats.energy = clamp(dog.stats.energy - 5);
    dog.stats.stress = clamp(dog.stats.stress - 4);
    obj.condition = clamp(obj.condition - 1.5);
    revealTrait(dog, 'active');
  } else if (verb === 'biting') {
    dog.stats.stress = clamp(dog.stats.stress - 3);
    obj.condition = clamp(obj.condition - 2.5);
    if (obj.kind === 'chew') revealTrait(dog, 'possessive of toys');
  } else if (verb === 'breaking') {
    dog.stats.stress = clamp(dog.stats.stress + 2);
    obj.condition = clamp(obj.condition - 5);
    revealTrait(dog, 'erratic');
  } else if (verb === 'pacing') {
    dog.stats.energy = clamp(dog.stats.energy - 2);
    if (dog.stats.stress > 50) dog.stats.stress = clamp(dog.stats.stress + 1);
  } else {
    dog.skills.tracking = clamp(dog.skills.tracking + 0.3);
    dog.stats.mood = clamp(dog.stats.mood + 1.5);
    if (dog.traits.includes('focused')) revealTrait(dog, 'focused');
  }

  const proseMap: Record<ObjectVerb, string> = {
    climbing: `${dog.name} springs cleanly onto the ${obj.name}, surveying the run from the high plank.`,
    pacing: `${dog.name} paces a steady track past the ${obj.name}, ears flicking at distant sounds.`,
    digging: `${dog.name} rakes briskly into the earth beside the ${obj.name}, sending dry dust behind their hocks.`,
    pawing: `${dog.name} taps and paws experimentally at the edge of the ${obj.name}.`,
    investigating: `${dog.name} circles the ${obj.name} deliberately, checking every joint and crevice.`,
    biting: `${dog.name} clamps their jaws firmly onto the ${obj.name} and gives a sharp, rhythmic shake.`,
    breaking: `${dog.name} wrenches roughly at the ${obj.name}, splintering loose material in a restless burst.`,
    sniffing: `${dog.name} lingers nose-down along the ${obj.name}, reading stale scent trails.`,
  };

  dog.currentBehavior = `${verb} around the ${obj.name.toLowerCase()}`;
  obj.lastInteractedText = proseMap[verb];

  addLog(state.logs, state.simClockSec, state.totalElapsedSec, dog.location, 'object', proseMap[verb], [dog.id]);
}

function runDogToDogInteraction(
  actor: Dog,
  target: Dog,
  penDogs: Dog[],
  state: GameState
): void {
  const now = state.totalElapsedSec;
  const compatibility = calculateAttributeCompatibility(actor, target);
  const relAB = getOrCreatePair(actor, target.id, now);
  const relBA = getOrCreatePair(target, actor.id, now);

  const actorIsPup = isPup(actor);
  const targetIsPup = isPup(target);

  // Check if target is tense/injured and actor is a compatible ally -> console!
  if ((target.stats.stress > 52 || target.stats.health < 62) && (relAB.isAlly || compatibility > 0.66)) {
    target.stats.stress = clamp(target.stats.stress - 12);
    target.stats.mood = clamp(target.stats.mood + 9);
    relAB.affinity = clamp(relAB.affinity + 5, -100, 100);
    relBA.affinity = clamp(relBA.affinity + 7, -100, 100);
    actor.currentBehavior = `consoling ${target.name}`;
    target.currentBehavior = `leaning into ${actor.name}'s comfort`;
    if (actor.traits.includes('calm')) revealTrait(actor, 'calm');
    addLog(
      state.logs,
      state.simClockSec,
      now,
      actor.location,
      'social',
      `${actor.name} approaches tense ${target.name} and gently licks their muzzle, resting side-to-side until ${target.name}'s breathing eases.`,
      [actor.id, target.id]
    );
    return;
  }

  // Mating check (adults of opposite sex, not pups)
  if (!actorIsPup && !targetIsPup && actor.gender !== target.gender) {
    const male = actor.gender === 'male' ? actor : target;
    const female = actor.gender === 'female' ? actor : target;
    const canTryMate =
      male.stats.matingDrive > 52 &&
      female.pregnantRemainingSec === null &&
      female.fertilityCooldownSec <= 0 &&
      Math.random() < 0.42;

    if (canTryMate) {
      const femaleWilling =
        female.stats.fertility >= 74 &&
        !female.traits.includes('dislikes males') &&
        female.stats.stress < 68 &&
        compatibility >= 0.42 &&
        relAB.affinity >= -10;

      if (femaleWilling) {
        female.stats.fertility = 0;
        female.fertilityCooldownSec = FERTILITY_COOLDOWN_SEC;
        female.pregnantRemainingSec = GESTATION_DURATION_SEC;
        female.litterSireId = male.id;
        male.stats.matingDrive = clamp(male.stats.matingDrive - 45);
        female.stats.matingDrive = clamp(female.stats.matingDrive - 40);
        relAB.affinity = clamp(relAB.affinity + 12, -100, 100);
        relBA.affinity = clamp(relBA.affinity + 12, -100, 100);
        actor.currentBehavior = `mated with ${target.name}`;
        addLog(
          state.logs,
          state.simClockSec,
          now,
          actor.location,
          'breeding',
          `${male.name} courts ${female.name} at peak fertility; ${female.name} accepts and the mating succeeds. Pregnancy has begun.`,
          [male.id, female.id]
        );
        return;
      } else {
        if (female.traits.includes('dislikes males')) revealTrait(female, 'dislikes males');
        female.stats.stress = clamp(female.stats.stress + 6);
        male.stats.matingDrive = clamp(male.stats.matingDrive - 12);
        relAB.tension = clamp(relAB.tension + 10);
        relBA.tension = clamp(relBA.tension + 14);
        actor.currentBehavior = `rejected by ${target.name}`;
        addLog(
          state.logs,
          state.simClockSec,
          now,
          actor.location,
          'social',
          `${male.name} attempts to court ${female.name}, but ${female.name} turns sharply and rejects mating with a warning snap.`,
          [male.id, female.id]
        );
        return;
      }
    }
  }

  // Choose from the 12 non-mating dog-to-dog actions
  const hostiltyBias =
    (1 - compatibility) * 45 +
    (actor.stats.aggression * 0.35) -
    (relAB.affinity > 25 ? 25 : 0) +
    (actor.traits.includes('dislikes females') && target.gender === 'female' ? 28 : 0) +
    (actor.traits.includes('dislikes males') && target.gender === 'male' ? 28 : 0);

  let action: DogSocialAction;
  if (actorIsPup && targetIsPup) {
    action = pickOne(['follow', 'sniff', 'playful bow', 'playful ambush', 'lick muzzle', 'chase', 'submit']);
  } else if (hostiltyBias > 38 && Math.random() < 0.65) {
    action = pickOne(['growl', 'pin down', 'bite', 'chase', 'avoid']);
  } else if (compatibility > 0.62 || relAB.affinity > 20) {
    action = pickOne(['sniff', 'follow', 'lick muzzle', 'playful bow', 'playful ambush', 'chase']);
  } else {
    action = pickOne(['sniff', 'follow', 'avoid', 'submit', 'growl', 'playful bow']);
  }

  // Resolve reaction & pack alliances
  if (action === 'bite' || action === 'pin down' || action === 'growl') {
    actor.lastTensionSimSec = now;
    target.lastTensionSimSec = now;

    if (actor.traits.includes('dislikes females') && target.gender === 'female') revealTrait(actor, 'dislikes females');
    if (actor.traits.includes('dislikes males') && target.gender === 'male') revealTrait(actor, 'dislikes males');
    if (actor.traits.includes('reactive')) revealTrait(actor, 'reactive');

    const damage = action === 'bite' ? randInt(7, 15) : action === 'pin down' ? randInt(3, 8) : 0;
    target.stats.health = clamp(target.stats.health - damage);
    target.stats.stress = clamp(target.stats.stress + (action === 'growl' ? 9 : 16));
    target.stats.mood = clamp(target.stats.mood - 12);
    relAB.affinity = clamp(relAB.affinity - 14, -100, 100);
    relBA.affinity = clamp(relBA.affinity - 18, -100, 100);
    relAB.tension = clamp(relAB.tension + 18);
    relBA.tension = clamp(relBA.tension + 20);

    let extraText = '';

    // Allies being tense transfers some stress to other allies
    for (const penMate of penDogs) {
      if (penMate.id === actor.id || penMate.id === target.id) continue;
      const allyToTarget = penMate.pairRelations[target.id];
      const allyToActor = penMate.pairRelations[actor.id];
      if (allyToTarget?.isAlly) {
        penMate.stats.stress = clamp(penMate.stats.stress + 5);
        if (Math.random() < 0.55) {
          // Ally defends target!
          actor.stats.stress = clamp(actor.stats.stress + 8);
          extraText = ` ${penMate.name} rushes in to defend ${target.name}, forcing ${actor.name} back.`;
          break;
        }
      } else if (allyToActor?.isAlly && relAB.affinity < -15) {
        // Compatible allies attack hostile newcomer together!
        penMate.stats.stress = clamp(penMate.stats.stress + 4);
        if (Math.random() < 0.5) {
          target.stats.health = clamp(target.stats.health - 5);
          target.stats.stress = clamp(target.stats.stress + 8);
          extraText = ` Ally ${penMate.name} flanks alongside ${actor.name} to drive ${target.name} into the corner.`;
          break;
        }
      }
    }

    // Tense moments end faster between compatible dogs
    if (compatibility > 0.65) {
      relAB.tension = clamp(relAB.tension - 10);
      relBA.tension = clamp(relBA.tension - 10);
      extraText += ' Because their temperaments align, the flare-up cools rapidly.';
    }

    actor.currentBehavior = `${action} toward ${target.name}`;
    target.currentBehavior = damage > 0 ? `nursing a scrape after clash with ${actor.name}` : `tense around ${actor.name}`;

    const actionPhrase =
      action === 'bite'
        ? `${actor.name} lunges and delivers a sharp bite to ${target.name}'s shoulder (-${damage} health).`
        : action === 'pin down'
        ? `${actor.name} drives ${target.name} onto their side and pins them briefly (-${damage} health).`
        : `${actor.name} bares teeth in a low, rattling growl at ${target.name}.`;

    addLog(state.logs, state.simClockSec, now, actor.location, 'social', `${actionPhrase}${extraText}`, [actor.id, target.id]);
    return;
  }

  // Positive / neutral social actions
  if (action === 'lick muzzle' || action === 'playful bow' || action === 'playful ambush') {
    relAB.affinity = clamp(relAB.affinity + 9, -100, 100);
    relBA.affinity = clamp(relBA.affinity + 9, -100, 100);
    relAB.tension = clamp(relAB.tension - 10);
    relBA.tension = clamp(relBA.tension - 10);
    if (relAB.affinity >= 32 && compatibility >= 0.52) {
      relAB.isAlly = true;
      relBA.isAlly = true;
    }
    actor.stats.mood = clamp(actor.stats.mood + 6);
    target.stats.mood = clamp(target.stats.mood + 6);
    actor.stats.stress = clamp(actor.stats.stress - 5);
    target.stats.stress = clamp(target.stats.stress - 5);
    actor.skills.socialGrace = clamp(actor.skills.socialGrace + 0.4);
    if (actor.traits.includes('playful') && (action === 'playful bow' || action === 'playful ambush')) {
      revealTrait(actor, 'playful');
    }
  } else if (action === 'submit') {
    relAB.tension = clamp(relAB.tension - 8);
    relBA.tension = clamp(relBA.tension - 8);
    target.stats.dominance = clamp(target.stats.dominance + 1);
  } else if (action === 'avoid') {
    if (actor.traits.includes('solitary')) revealTrait(actor, 'solitary');
    actor.stats.stress = clamp(actor.stats.stress + 1);
  } else {
    relAB.affinity = clamp(relAB.affinity + 3, -100, 100);
    relBA.affinity = clamp(relBA.affinity + 3, -100, 100);
  }

  const socialText: Record<DogSocialAction, string> = {
    follow: `${actor.name} pads quietly a step behind ${target.name}, mirroring their path across the pen.`,
    sniff: `${actor.name} and ${target.name} touch noses and exchange unhurried scent checks.`,
    growl: `${actor.name} growls at ${target.name}.`,
    'pin down': `${actor.name} pins ${target.name}.`,
    chase: `${actor.name} breaks into a sweeping chase behind ${target.name}, kicking up dust along the fence.`,
    'lick muzzle': `${actor.name} reaches up to lick ${target.name}'s muzzle in calm appeasement.`,
    'playful bow': `${actor.name} drops onto their elbows in a wide playful bow toward ${target.name}.`,
    submit: `${actor.name} lowers their head and rolls slightly aside to submit to ${target.name}.`,
    avoid: `${actor.name} alters course early to avoid crossing paths with ${target.name}.`,
    mate: `${actor.name} mates with ${target.name}.`,
    'reject mating': `${actor.name} rejects ${target.name}.`,
    bite: `${actor.name} bites ${target.name}.`,
    'playful ambush': `${actor.name} crouches behind the scrub and springs a playful ambush on ${target.name}.`,
    defend: `${actor.name} steps in to defend ${target.name}.`,
  };

  actor.currentBehavior = `${action} with ${target.name}`;
  addLog(state.logs, state.simClockSec, now, actor.location, 'social', socialText[action], [actor.id, target.id]);
}

function stepOneSecond(state: GameState): void {
  state.totalElapsedSec += 1;
  state.simClockSec += 1;
  if (state.simClockSec >= DAY_SECONDS) {
    state.simClockSec = 0;
    state.dayCount += 1;
  }

  // Market 8-minute refresh
  state.nextMarketRefreshSec -= 1;
  if (state.nextMarketRefreshSec <= 0) {
    const existingNames = state.dogs.map((d) => d.name);
    state.marketListings = generateMarketBatch(existingNames, state.totalElapsedSec);
    state.nextMarketRefreshSec = MARKET_REFRESH_SEC;
  }

  const newPups: Dog[] = [];
  const deadIds = new Set<string>();

  for (const dog of state.dogs) {
    const wasPup = isPup(dog);
    dog.ageSeconds += 1;
    const nowPup = isPup(dog);

    // Pup -> Adult maturation at 1 hour
    if (wasPup && !nowPup) {
      dog.stats.fertility = dog.gender === 'female' ? randInt(55, 85) : randInt(70, 95);
      dog.stats.matingDrive = randInt(25, 65);
      let moveText = '';
      if (dog.location === 'nursery_pen') {
        const freeBox = findFirstEmptyBox(state.dogs);
        if (freeBox) {
          dog.location = freeBox;
          moveText = ` Relocated from Nursery Pen to ${formatLocationLabel(freeBox)}.`;
        } else {
          moveText = ' All 21 boxes are full; waiting in Nursery Pen for an open stall.';
        }
      }
      addLog(
        state.logs,
        state.simClockSec,
        state.totalElapsedSec,
        dog.location,
        'alert',
        `${dog.name} has reached adulthood (1h). Their permanent ${dog.genetics.pattern} coat markings are now visible.${moveText}`,
        [dog.id]
      );
    }

    // Check lifespan / critical health
    if (dog.ageSeconds >= dog.lifespanSeconds || dog.stats.health <= 0) {
      const cause = dog.stats.health <= 0 ? 'Critical injury or starvation' : 'Old age';
      deadIds.add(dog.id);
      state.deceased.unshift({
        id: dog.id,
        name: dog.name,
        gender: dog.gender,
        coat: dog.genetics.coat,
        bodyType: dog.genetics.bodyType,
        pattern: dog.genetics.pattern,
        ageAtDeathSec: dog.ageSeconds,
        cause,
        traits: [...dog.traits],
        generation: dog.generation,
      });
      addLog(
        state.logs,
        state.simClockSec,
        state.totalElapsedSec,
        dog.location,
        'alert',
        `${dog.name} passed away quietly (${cause}).`,
        [dog.id]
      );
      continue;
    }

    // Hunger & Thirst progression (pups need more food)
    const hungerRate = nowPup ? 0.082 : dog.traits.includes('active') ? 0.052 : 0.036;
    const thirstRate = dog.traits.includes('active') ? 0.058 : 0.042;
    dog.stats.hunger = clamp(dog.stats.hunger + hungerRate);
    dog.stats.thirst = clamp(dog.stats.thirst + thirstRate);

    // Energy & Stress & Mood dynamics
    const energyDelta = dog.traits.includes('lazy') ? 0.04 : dog.traits.includes('active') ? -0.02 : 0.015;
    dog.stats.energy = clamp(dog.stats.energy + (nowPup ? energyDelta * 0.6 : energyDelta), 5, nowPup ? 80 : 100);

    // Pups recover mood & stress faster
    const recoveryMult = nowPup ? 2.4 : dog.traits.includes('calm') ? 1.5 : 1.0;
    if (dog.stats.hunger < 65 && dog.stats.thirst < 65) {
      dog.stats.stress = clamp(dog.stats.stress - 0.035 * recoveryMult);
      dog.stats.mood = clamp(dog.stats.mood + 0.03 * recoveryMult);
    } else {
      dog.stats.stress = clamp(dog.stats.stress + 0.05);
      dog.stats.mood = clamp(dog.stats.mood - 0.06);
    }

    // Player presence inside dog's box/pen affects mood & stress subtly
    if (state.playerLocation === dog.location) {
      if (dog.traits.includes('likes humans') || dog.playerRel.trust > 62) {
        dog.stats.mood = clamp(dog.stats.mood + 0.04);
        dog.stats.stress = clamp(dog.stats.stress - 0.03);
      } else if (dog.traits.includes('dislikes humans') || dog.playerRel.fear > 60) {
        dog.stats.stress = clamp(dog.stats.stress + 0.04);
      }
    }

    // Eat & Drink from habitat bowl
    const bowl = state.bowls[dog.location];
    if (dog.stats.hunger >= 42 && bowl.food > 0) {
      const bite = Math.min(bowl.food, nowPup ? 18 : 22);
      bowl.food = clamp(bowl.food - bite);
      dog.stats.hunger = clamp(dog.stats.hunger - bite * 1.45);
      dog.stats.health = clamp(dog.stats.health + 3.5);
      dog.stats.mood = clamp(dog.stats.mood + 4);
      dog.currentBehavior = 'eating from the feed bowl';
      addLog(
        state.logs,
        state.simClockSec,
        state.totalElapsedSec,
        dog.location,
        'care',
        `${dog.name} steps to the bowl and eats a steady ration of kibble.`,
        [dog.id]
      );
    }
    if (dog.stats.thirst >= 40 && bowl.water > 0) {
      const sip = Math.min(bowl.water, 18);
      bowl.water = clamp(bowl.water - sip);
      dog.stats.thirst = clamp(dog.stats.thirst - sip * 1.6);
      dog.currentBehavior = 'lapping cool water from the trough';
      addLog(
        state.logs,
        state.simClockSec,
        state.totalElapsedSec,
        dog.location,
        'care',
        `${dog.name} laps water cleanly from the habitat bowl.`,
        [dog.id]
      );
    }

    // Health natural regeneration or starvation penalty
    if (dog.stats.hunger > 88 || dog.stats.thirst > 88) {
      dog.stats.health = clamp(dog.stats.health - 0.06);
    } else if (dog.stats.hunger < 60 && dog.stats.thirst < 60 && dog.stats.health < 100) {
      dog.stats.health = clamp(dog.stats.health + 0.035);
    }

    // Fertility & Pregnancy
    if (!nowPup) {
      if (dog.gender === 'female') {
        if (dog.pregnantRemainingSec !== null) {
          dog.pregnantRemainingSec -= 1;
          if (dog.pregnantRemainingSec <= 0) {
            const sire = state.dogs.find((d) => d.id === dog.litterSireId) ?? dog;
            const litterCount = calculateLitterSize(dog);
            const names = [...state.dogs.map((d) => d.name), ...newPups.map((p) => p.name)];
            for (let i = 0; i < litterCount; i++) {
              const pup = createBredPup(dog, sire, names);
              names.push(pup.name);
              newPups.push(pup);
            }
            dog.pregnantRemainingSec = null;
            dog.litterSireId = null;
            addLog(
              state.logs,
              state.simClockSec,
              state.totalElapsedSec,
              dog.location,
              'breeding',
              `${dog.name} delivers a litter of ${litterCount} pup${litterCount > 1 ? 's' : ''}! They have been settled safely into the Nursery Pen.`,
              [dog.id]
            );
            addLog(
              state.logs,
              state.simClockSec,
              state.totalElapsedSec,
              'nursery_pen',
              'breeding',
              `${litterCount} newborn pup${litterCount > 1 ? 's' : ''} from ${dog.name} curl into the warm Nursery Pen straw.`,
              newPups.map((p) => p.id)
            );
          }
        } else if (dog.fertilityCooldownSec > 0) {
          dog.fertilityCooldownSec -= 1;
        } else {
          // Rises naturally toward peak fertility
          dog.stats.fertility = clamp(dog.stats.fertility + 0.045);
          dog.stats.matingDrive = clamp(dog.stats.matingDrive + (dog.stats.fertility > 70 ? 0.05 : 0.015));
        }
      } else {
        dog.stats.matingDrive = clamp(dog.stats.matingDrive + 0.025);
      }
    }

    // Autonomous habitat activity every ~9-15 seconds
    if (state.totalElapsedSec - dog.lastActivitySimSec >= randInt(9, 16)) {
      dog.lastActivitySimSec = state.totalElapsedSec;

      // Skip autonomous roaming if currently in active player interaction
      if (state.activeInteraction?.dogId === dog.id) continue;

      if (dog.location === 'outside_pen') {
        const penDogs = state.dogs.filter((d) => d.location === 'outside_pen' && !deadIds.has(d.id));
        if (penDogs.length > 1 && Math.random() < (nowPup ? 0.72 : 0.56)) {
          const others = penDogs.filter((d) => d.id !== dog.id);
          const partner = pickOne(others);
          runDogToDogInteraction(dog, partner, penDogs, state);
        } else {
          runAutonomousPenObjectBehavior(dog, state.penObjects, state);
        }
      } else if (dog.location === 'nursery_pen') {
        const nurseryDogs = state.dogs.filter((d) => d.location === 'nursery_pen' && !deadIds.has(d.id));
        if (nurseryDogs.length > 1 && Math.random() < 0.65) {
          const others = nurseryDogs.filter((d) => d.id !== dog.id);
          runDogToDogInteraction(dog, pickOne(others), nurseryDogs, state);
        } else {
          const pupActions = [
            'nosing into the straw bedding for warmth',
            'tumbling playfully over a folded blanket',
            'practicing soft squeaking barks near the low gate',
            'curling tightly in a sunlit corner of the nursery',
          ];
          const text = `${dog.name} is ${pickOne(pupActions)}.`;
          dog.currentBehavior = text;
          addLog(state.logs, state.simClockSec, state.totalElapsedSec, 'nursery_pen', 'behavior', text, [dog.id]);
        }
      } else {
        // Inside individual Box 01..21
        const boxBehaviors = dog.traits.includes('lazy')
          ? ['dozing stretched out on the mat', 'resting chin on paws while watching the gate', 'blinking sleepily from the cool corner']
          : dog.traits.includes('active')
          ? ['trotting short loops inside the stall', 'scratching lightly at the timber sill', 'perching alertly near the mesh gate']
          : ['grooming a forepaw quietly', 'sniffing along the lower partition', 'settling beside the water pan'];
        const phrase = pickOne(boxBehaviors);
        dog.currentBehavior = phrase;
        if (dog.traits.includes('lazy') && Math.random() < 0.25) revealTrait(dog, 'lazy');
        if (dog.traits.includes('active') && Math.random() < 0.25) revealTrait(dog, 'active');
        addLog(
          state.logs,
          state.simClockSec,
          state.totalElapsedSec,
          dog.location,
          'behavior',
          `${dog.name} is ${phrase}.`,
          [dog.id]
        );
      }
    }
  }

  // Remove deceased & add newborns
  if (deadIds.size > 0) {
    state.dogs = state.dogs.filter((d) => !deadIds.has(d.id));
    if (state.activeInteraction && deadIds.has(state.activeInteraction.dogId)) {
      state.activeInteraction = null;
    }
  }
  if (newPups.length > 0) {
    state.dogs.push(...newPups);
  }

  // Handle Active Player Interaction progression & 60s auto-end rule
  if (state.activeInteraction) {
    const inter = state.activeInteraction;
    const dog = state.dogs.find((d) => d.id === inter.dogId);
    if (!dog || dog.location !== state.playerLocation) {
      state.activeInteraction = null;
    } else {
      const elapsedSinceStart = state.totalElapsedSec - inter.startedAtTotalSec;
      const elapsedSinceLast = state.totalElapsedSec - inter.lastActionAtTotalSec;

      // If player doesn't choose an action, the dog continues on its own
      if (elapsedSinceLast >= 14) {
        inter.lastActionAtTotalSec = state.totalElapsedSec;
        inter.boredom = clamp(inter.boredom + 12);

        const continuationText =
          inter.reason === 'hunger'
            ? `${dog.name} nudges your coat pocket once, ears tipped forward in silent expectation.`
            : inter.reason === 'affection'
            ? `${dog.name} leans slightly closer against your shin, waiting for a hand to drop.`
            : inter.reason === 'territory'
            ? `${dog.name} shifts their weight stiffly and emits a quiet huff, still holding your space.`
            : inter.reason === 'fear'
            ? `${dog.name} takes one small sidestep and glances toward the exit gate while watching your eyes.`
            : `${dog.name} stretches their neck to sniff your sleeve, tail held level and inquiring.`;

        inter.history.push({
          id: makeId('ih'),
          actor: 'dog',
          text: continuationText,
          timeStr: formatSimClock(state.simClockSec),
        });
        addLog(state.logs, state.simClockSec, state.totalElapsedSec, inter.location, 'interaction', continuationText, [dog.id]);
      }

      // Dogs might end interaction on their own if disliking it or bored, ONLY once >= 60s passed
      if (elapsedSinceStart >= INTERACTION_MIN_AUTO_END_SEC) {
        const dislikesIt = dog.playerRel.fear > 62 || dog.playerRel.anger > 55 || dog.stats.stress > 78;
        const isBored = inter.boredom >= 68;
        if ((dislikesIt && Math.random() < 0.25) || (isBored && Math.random() < 0.20)) {
          const endReason = dislikesIt
            ? `${dog.name} has had enough tension—they turn sharply and retreat to the far corner, ending the encounter.`
            : `${dog.name} loses interest after a full minute, yawns, and wanders away on their own.`;
          addLog(state.logs, state.simClockSec, state.totalElapsedSec, inter.location, 'interaction', endReason, [dog.id]);
          state.activeInteraction = null;
        }
      }
    }
  } else if (state.playerLocation !== 'corridor') {
    // Chance for a dog in current habitat to approach player
    const hereDogs = state.dogs.filter((d) => d.location === state.playerLocation);
    if (hereDogs.length > 0 && Math.random() < 0.14) {
      const candidate = pickOne(hereDogs);
      const approachChance =
        0.35 +
        (candidate.traits.includes('likes humans') ? 0.35 : 0) +
        (candidate.traits.includes('clingy') ? 0.25 : 0) +
        (candidate.traits.includes('dislikes humans') ? -0.22 : 0) +
        candidate.playerRel.curiosity * 0.004;

      if (Math.random() < approachChance) {
        const bowl = state.bowls[state.playerLocation];
        const reason = chooseApproachReason(candidate, bowl);
        const opening = buildApproachOpeningText(candidate, reason);
        candidate.playerRel.interactionCount += 1;
        state.activeInteraction = {
          dogId: candidate.id,
          location: state.playerLocation,
          reason,
          startedAtTotalSec: state.totalElapsedSec,
          lastActionAtTotalSec: state.totalElapsedSec,
          turns: 0,
          boredom: 0,
          history: [
            {
              id: makeId('ih'),
              actor: 'dog',
              text: opening,
              timeStr: formatSimClock(state.simClockSec),
            },
          ],
        };
        addLog(
          state.logs,
          state.simClockSec,
          state.totalElapsedSec,
          state.playerLocation,
          'interaction',
          `[Approach · ${reason}] ${opening}`,
          [candidate.id]
        );
      }
    }
  }

  // Auto-delete old logs (keep max 120 and drop logs older than 30 min = 1800s)
  const cutoff = state.totalElapsedSec - 1800;
  if (state.logs.length > 120 || (state.logs.length > 0 && state.logs[0].totalElapsedSec < cutoff)) {
    state.logs = state.logs.filter((l) => l.totalElapsedSec >= cutoff).slice(-120);
  }
}

export function advanceSimulation(prev: GameState, seconds: number): GameState {
  if (prev.isPaused || seconds <= 0) return prev;
  const steps = Math.min(Math.floor(seconds), 600);
  if (steps <= 0) return prev;

  const next: GameState = structuredClone(prev);
  for (let i = 0; i < steps; i++) {
    stepOneSecond(next);
  }
  return next;
}

export function enterLocation(prev: GameState, loc: LocationId): GameState {
  const next: GameState = structuredClone(prev);
  next.playerLocation = loc;
  next.observingLocation = null;
  next.activeInteraction = null;

  if (loc !== 'corridor') {
    const hereDogs = next.dogs.filter((d) => d.location === loc);
    if (hereDogs.length === 0) {
      addLog(
        next.logs,
        next.simClockSec,
        next.totalElapsedSec,
        loc,
        'behavior',
        `You step into ${formatLocationLabel(loc)}. The stall is currently empty.`,
        []
      );
    } else {
      const reactions = hereDogs.map((d) => {
        if (d.traits.includes('likes humans') || d.playerRel.trust > 55) {
          d.stats.mood = clamp(d.stats.mood + 2);
          return `${d.name} perks both ears up warmly at your arrival`;
        }
        if (d.traits.includes('dislikes humans') || d.playerRel.fear > 55) {
          d.stats.stress = clamp(d.stats.stress + 3);
          return `${d.name} tucks back a half-step and tracks you warily`;
        }
        return `${d.name} pauses mid-stride to watch you enter`;
      });
      addLog(
        next.logs,
        next.simClockSec,
        next.totalElapsedSec,
        loc,
        'behavior',
        `You enter ${formatLocationLabel(loc)}. ${reactions.join('; ')}.`,
        hereDogs.map((d) => d.id)
      );
    }
  }
  return next;
}

export function initiateManualInteraction(prev: GameState, dogId: string): GameState {
  const next: GameState = structuredClone(prev);
  const dog = next.dogs.find((d) => d.id === dogId);
  if (next.playerLocation === 'corridor' || !dog || dog.location !== next.playerLocation) {
    return prev;
  }
  const bowl = next.bowls[next.playerLocation];
  const reason = chooseApproachReason(dog, bowl);
  const opening = buildApproachOpeningText(dog, reason);
  dog.playerRel.interactionCount += 1;

  next.activeInteraction = {
    dogId: dog.id,
    location: next.playerLocation,
    reason,
    startedAtTotalSec: next.totalElapsedSec,
    lastActionAtTotalSec: next.totalElapsedSec,
    turns: 0,
    boredom: 0,
    history: [
      {
        id: makeId('ih'),
        actor: 'dog',
        text: opening,
        timeStr: formatSimClock(next.simClockSec),
      },
    ],
  };

  addLog(
    next.logs,
    next.simClockSec,
    next.totalElapsedSec,
    next.playerLocation,
    'interaction',
    `You kneel slightly to invite ${dog.name} closer. ${opening}`,
    [dog.id]
  );

  return next;
}

export function applyPlayerInteractionAction(prev: GameState, action: PlayerAction): GameState {
  if (!prev.activeInteraction) return prev;
  const next: GameState = structuredClone(prev);
  const inter = next.activeInteraction!;
  const dog = next.dogs.find((d) => d.id === inter.dogId);
  if (!dog) {
    next.activeInteraction = null;
    return next;
  }

  const timeStr = formatSimClock(next.simClockSec);
  inter.lastActionAtTotalSec = next.totalElapsedSec;
  inter.turns += 1;

  if (action === 'end_interaction') {
    const byeText = `You step back smoothly and end the interaction with ${dog.name}.`;
    addLog(next.logs, next.simClockSec, next.totalElapsedSec, inter.location, 'interaction', byeText, [dog.id]);
    next.activeInteraction = null;
    return next;
  }

  const moodScore = (dog.stats.mood - dog.stats.stress * 0.5 + dog.playerRel.trust * 0.6 - dog.playerRel.fear * 0.5);
  const highTrust = dog.playerRel.trust >= 52;
  const highFear = dog.playerRel.fear >= 52;

  let playerLine = '';
  let dogReaction = '';

  switch (action) {
    case 'look_away': {
      playerLine = 'You turn your gaze calmly toward the side mesh.';
      if (highFear || dog.traits.includes('reactive')) {
        dog.playerRel.fear = clamp(dog.playerRel.fear - 9);
        dog.playerRel.stress = clamp(dog.playerRel.stress - 8);
        dog.playerRel.trust = clamp(dog.playerRel.trust + 5);
        dog.stats.stress = clamp(dog.stats.stress - 6);
        dogReaction = `${dog.name}'s shoulders drop noticeably at the appeasement signal; they step half a pace closer.`;
      } else if (dog.traits.includes('clingy')) {
        dog.playerRel.curiosity = clamp(dog.playerRel.curiosity + 6);
        inter.boredom = clamp(inter.boredom + 10);
        revealTrait(dog, 'clingy');
        dogReaction = `${dog.name} steps straight back into your line of sight, nosing your hand for attention.`;
      } else {
        dog.playerRel.anger = clamp(dog.playerRel.anger - 6);
        dog.playerRel.trust = clamp(dog.playerRel.trust + 3);
        inter.boredom = clamp(inter.boredom + 8);
        dogReaction = `${dog.name} blinks slowly and relaxes their stance beside you.`;
      }
      break;
    }

    case 'offer_palm': {
      playerLine = 'You extend a quiet, open palm low near chest height.';
      if (dog.traits.includes('dislikes humans') && !highTrust) {
        dog.playerRel.fear = clamp(dog.playerRel.fear + 6);
        dog.playerRel.curiosity = clamp(dog.playerRel.curiosity + 4);
        revealTrait(dog, 'dislikes humans');
        dogReaction = `${dog.name} stretches their neck to sniff your fingertips from max range, then jerks back sharply.`;
      } else if (moodScore > 45 || dog.traits.includes('likes humans')) {
        dog.playerRel.trust = clamp(dog.playerRel.trust + 8);
        dog.playerRel.curiosity = clamp(dog.playerRel.curiosity + 5);
        dog.playerRel.fear = clamp(dog.playerRel.fear - 6);
        revealTrait(dog, 'likes humans');
        dogReaction = `${dog.name} sniffs your palm thoroughly, then presses a cool wet nose right into the crease of your fingers.`;
      } else {
        dog.playerRel.curiosity = clamp(dog.playerRel.curiosity + 8);
        dog.playerRel.trust = clamp(dog.playerRel.trust + 3);
        dogReaction = `${dog.name} inhales across your knuckles in two careful sniffs before stepping back to evaluate you.`;
      }
      break;
    }

    case 'playful_wrestle': {
      playerLine = 'You tap the ground lightly and invite a playful wrestle.';
      if (dog.traits.includes('playful') || (dog.stats.playfulness > 58 && moodScore > 30)) {
        dog.stats.mood = clamp(dog.stats.mood + 10);
        dog.stats.energy = clamp(dog.stats.energy - 8);
        dog.playerRel.trust = clamp(dog.playerRel.trust + 7);
        inter.boredom = clamp(inter.boredom - 25);
        revealTrait(dog, 'playful');
        dogReaction = `${dog.name} explodes into a wide play-bow, mouthing lightly at your sleeve and darting around your knees!`;
      } else if (highFear || dog.traits.includes('reactive') || dog.stats.aggression > 68) {
        dog.playerRel.anger = clamp(dog.playerRel.anger + 12);
        dog.playerRel.fear = clamp(dog.playerRel.fear + 9);
        dog.stats.stress = clamp(dog.stats.stress + 10);
        revealTrait(dog, 'reactive');
        dogReaction = `${dog.name} misreads the sudden lunging motion—ears pin flat and a crisp warning snap cracks the air.`;
      } else {
        dog.stats.energy = clamp(dog.stats.energy - 3);
        inter.boredom = clamp(inter.boredom + 6);
        dogReaction = `${dog.name} hops sideways out of reach, watching your hands with mild uncertainty.`;
      }
      break;
    }

    case 'pet': {
      playerLine = 'You reach smoothly to stroke along their shoulder and ear base.';
      if (dog.traits.includes('dislikes petting')) {
        dog.playerRel.anger = clamp(dog.playerRel.anger + 11);
        dog.playerRel.stress = clamp(dog.playerRel.stress + 10);
        dog.playerRel.trust = clamp(dog.playerRel.trust - 6);
        dog.stats.stress = clamp(dog.stats.stress + 9);
        revealTrait(dog, 'dislikes petting');
        dogReaction = `${dog.name} stiffens immediately under your fingers and ducks out with a sharp grunt of dislike.`;
      } else if (dog.traits.includes('likes petting') || highTrust) {
        dog.playerRel.trust = clamp(dog.playerRel.trust + 9);
        dog.playerRel.stress = clamp(dog.playerRel.stress - 9);
        dog.stats.stress = clamp(dog.stats.stress - 10);
        dog.stats.mood = clamp(dog.stats.mood + 9);
        inter.boredom = clamp(inter.boredom - 12);
        revealTrait(dog, 'likes petting');
        dogReaction = `${dog.name} leans heavily into your hand, eyes half-closing as you scratch behind the jaw.`;
      } else if (highFear) {
        dog.playerRel.fear = clamp(dog.playerRel.fear + 7);
        dog.stats.stress = clamp(dog.stats.stress + 6);
        dogReaction = `${dog.name} freezes beneath your palm, skin twitching rapidly until you lift your fingers.`;
      } else {
        dog.playerRel.trust = clamp(dog.playerRel.trust + 4);
        dog.stats.mood = clamp(dog.stats.mood + 3);
        dogReaction = `${dog.name} tolerates two slow strokes along the neck before shaking their coat once.`;
      }
      break;
    }

    case 'offer_kibble': {
      playerLine = 'You hold out a dry meat kibble from your pouch.';
      if (dog.stats.hunger > 35 || !highFear) {
        dog.stats.hunger = clamp(dog.stats.hunger - 14);
        dog.stats.health = clamp(dog.stats.health + 2);
        dog.stats.mood = clamp(dog.stats.mood + 7);
        dog.playerRel.trust = clamp(dog.playerRel.trust + 9);
        dog.playerRel.fear = clamp(dog.playerRel.fear - 6);
        inter.boredom = clamp(inter.boredom - 18);
        dogReaction = `${dog.name} takes the kibble cleanly from your fingers, crunches it once, and noses your palm for another.`;
      } else {
        dog.playerRel.curiosity = clamp(dog.playerRel.curiosity + 6);
        dog.playerRel.trust = clamp(dog.playerRel.trust + 3);
        dogReaction = `${dog.name} waits until you drop the kibble onto the ground before snatching it cautiously.`;
      }
      break;
    }

    case 'crouch': {
      playerLine = 'You crouch low to minimize your silhouette.';
      if (dog.traits.includes('dislikes humans') && dog.stats.dominance > 65) {
        dog.playerRel.anger = clamp(dog.playerRel.anger + 5);
        dogReaction = `${dog.name} crowds into your lowered posture, testing your shoulder with a stiff chest.`;
      } else {
        dog.playerRel.fear = clamp(dog.playerRel.fear - 10);
        dog.playerRel.curiosity = clamp(dog.playerRel.curiosity + 9);
        dog.playerRel.trust = clamp(dog.playerRel.trust + 6);
        dog.stats.stress = clamp(dog.stats.stress - 5);
        dogReaction = `${dog.name} advances right to knee-level, sniffing your collar and hair with settled curiosity.`;
      }
      break;
    }

    case 'scold': {
      playerLine = 'You deliver a crisp, stern verbal correction.';
      if (dog.stats.dominance > 72 && dog.stats.aggression > 60) {
        dog.playerRel.anger = clamp(dog.playerRel.anger + 15);
        dog.playerRel.trust = clamp(dog.playerRel.trust - 9);
        dog.stats.stress = clamp(dog.stats.stress + 12);
        dogReaction = `${dog.name} refuses to back down—hackles lift along the spine and a low rumble vibrates in their throat.`;
      } else {
        dog.playerRel.fear = clamp(dog.playerRel.fear + 11);
        dog.playerRel.stress = clamp(dog.playerRel.stress + 11);
        dog.playerRel.trust = clamp(dog.playerRel.trust - 7);
        dog.stats.mood = clamp(dog.stats.mood - 10);
        dogReaction = `${dog.name} flattens both ears, breaks gaze abruptly, and retreats two paces with tucked tail.`;
      }
      break;
    }

    case 'eye_contact': {
      playerLine = 'You hold steady, direct eye contact.';
      if (highTrust && dog.traits.includes('focused')) {
        dog.playerRel.trust = clamp(dog.playerRel.trust + 6);
        dog.playerRel.curiosity = clamp(dog.playerRel.curiosity + 6);
        revealTrait(dog, 'focused');
        dogReaction = `${dog.name} locks eyes steadily with attentive calm, tail swaying gently at half-mast.`;
      } else if (dog.stats.dominance > 68 || dog.traits.includes('reactive')) {
        dog.playerRel.anger = clamp(dog.playerRel.anger + 11);
        dog.stats.stress = clamp(dog.stats.stress + 9);
        revealTrait(dog, 'reactive');
        dogReaction = `${dog.name} stiffens under the direct stare, lip curling faintly before they huff a challenge.`;
      } else {
        dog.playerRel.fear = clamp(dog.playerRel.fear + 7);
        dog.playerRel.stress = clamp(dog.playerRel.stress + 6);
        dogReaction = `${dog.name} shifts uncomfortably and darts their gaze away toward the fence corner.`;
      }
      break;
    }
  }

  inter.history.push(
    { id: makeId('ih'), actor: 'player', text: playerLine, timeStr },
    { id: makeId('ih'), actor: 'dog', text: dogReaction, timeStr }
  );
  if (inter.history.length > 24) {
    inter.history = inter.history.slice(-24);
  }

  addLog(
    next.logs,
    next.simClockSec,
    next.totalElapsedSec,
    inter.location,
    'interaction',
    `${playerLine} ${dogReaction}`,
    [dog.id]
  );

  return next;
}

export function placeFoodInBowl(prev: GameState, target: HabitatLocationId): GameState {
  // Strictly requires player to be inside the target habitat
  if (prev.playerLocation !== target) return prev;
  const next: GameState = structuredClone(prev);
  next.bowls[target].food = clamp(next.bowls[target].food + 60);
  addLog(
    next.logs,
    next.simClockSec,
    next.totalElapsedSec,
    target,
    'care',
    `You scoop fresh kibble into the feed bowl in ${formatLocationLabel(target)}.`,
    []
  );
  return next;
}

export function placeWaterInBowl(prev: GameState, target: HabitatLocationId): GameState {
  if (prev.playerLocation !== target) return prev;
  const next: GameState = structuredClone(prev);
  next.bowls[target].water = clamp(next.bowls[target].water + 75);
  addLog(
    next.logs,
    next.simClockSec,
    next.totalElapsedSec,
    target,
    'care',
    `You refill the water pan in ${formatLocationLabel(target)} with fresh cool water.`,
    []
  );
  return next;
}

export function canMoveDogTo(dogs: Dog[], dog: Dog, dest: HabitatLocationId): { ok: boolean; reason?: string } {
  if (dog.location === dest) return { ok: false, reason: 'Already in this enclosure.' };
  if (dest === 'outside_pen') {
    const count = dogs.filter((d) => d.location === 'outside_pen').length;
    if (count >= OUTSIDE_PEN_CAPACITY) {
      return { ok: false, reason: `Outside Pen is at capacity (${OUTSIDE_PEN_CAPACITY}/${OUTSIDE_PEN_CAPACITY}).` };
    }
  } else if (dest !== 'nursery_pen') {
    const occupied = dogs.some((d) => d.location === dest);
    if (occupied) return { ok: false, reason: `${formatLocationLabel(dest)} already houses a dog.` };
  }
  return { ok: true };
}

export function moveDogToLocation(prev: GameState, dogId: string, dest: HabitatLocationId): GameState {
  const next: GameState = structuredClone(prev);
  const dog = next.dogs.find((d) => d.id === dogId);
  if (!dog) return prev;

  const check = canMoveDogTo(next.dogs, dog, dest);
  if (!check.ok) return prev;

  const oldLoc = dog.location;
  dog.location = dest;
  dog.currentBehavior = `settling into ${formatLocationLabel(dest)}`;

  if (next.activeInteraction?.dogId === dog.id) {
    next.activeInteraction = null;
  }

  addLog(
    next.logs,
    next.simClockSec,
    next.totalElapsedSec,
    oldLoc,
    'care',
    `${dog.name} is led out of ${formatLocationLabel(oldLoc)} toward ${formatLocationLabel(dest)}.`,
    [dog.id]
  );
  addLog(
    next.logs,
    next.simClockSec,
    next.totalElapsedSec,
    dest,
    'care',
    `${dog.name} arrives inside ${formatLocationLabel(dest)} and sniffs the perimeter.`,
    [dog.id]
  );

  return next;
}

export function acceptMarketListing(
  prev: GameState,
  listingId: string,
  dest: HabitatLocationId,
  customName?: string
): GameState {
  const listing = prev.marketListings.find((m) => m.id === listingId);
  if (!listing) return prev;
  if (prev.kennelCredits < listing.price) return prev;

  const next: GameState = structuredClone(prev);
  const dogCopy: Dog = structuredClone(listing.dog);
  if (customName && customName.trim()) {
    dogCopy.name = customName.trim().slice(0, 24);
  }

  // Validate capacity
  if (dest === 'outside_pen') {
    if (next.dogs.filter((d) => d.location === 'outside_pen').length >= OUTSIDE_PEN_CAPACITY) return prev;
  } else if (dest !== 'nursery_pen') {
    if (next.dogs.some((d) => d.location === dest)) return prev;
  }

  dogCopy.location = dest;
  dogCopy.lastActivitySimSec = next.totalElapsedSec;
  next.dogs.push(dogCopy);
  next.kennelCredits -= listing.price;
  next.marketListings = next.marketListings.filter((m) => m.id !== listingId);

  addLog(
    next.logs,
    next.simClockSec,
    next.totalElapsedSec,
    dest,
    'care',
    `New arrival ${dogCopy.name} (${dogCopy.gender}) is placed into ${formatLocationLabel(dest)}.`,
    [dogCopy.id]
  );

  return next;
}

export function refuseMarketListing(prev: GameState, listingId: string): GameState {
  const next: GameState = structuredClone(prev);
  const remaining = next.marketListings.filter((m) => m.id !== listingId);
  const existingNames = [...next.dogs.map((d) => d.name), ...remaining.map((m) => m.dog.name)];
  const replacementDog = generateRandomDog({
    location: 'box_1',
    origin: 'market',
    existingNames,
  });
  remaining.push({
    id: makeId('mkt'),
    dog: replacementDog,
    price: estimateDogMarketValue(replacementDog),
    arrivedAtTotalSec: next.totalElapsedSec,
  });
  next.marketListings = remaining;
  return next;
}

export function sellOrRehomeDog(prev: GameState, dogId: string): GameState {
  const dog = prev.dogs.find((d) => d.id === dogId);
  if (!dog) return prev;

  const next: GameState = structuredClone(prev);
  const targetPup = isPup(dog);
  const payout = targetPup ? Math.round(estimateDogMarketValue(dog) * 0.85) : Math.round(estimateDogMarketValue(dog) * 0.45);

  next.dogs = next.dogs.filter((d) => d.id !== dogId);
  if (next.activeInteraction?.dogId === dogId) {
    next.activeInteraction = null;
  }
  if (next.journalSelectedDogId === dogId) {
    next.journalSelectedDogId = next.dogs[0]?.id ?? null;
  }

  if (targetPup) {
    next.soldCount += 1;
    next.kennelCredits += payout;
    addLog(
      next.logs,
      next.simClockSec,
      next.totalElapsedSec,
      dog.location,
      'care',
      `Pup ${dog.name} was sold to a registered handler (+${payout} credits).`,
      []
    );
  } else {
    next.rehomedCount += 1;
    next.kennelCredits += payout;
    addLog(
      next.logs,
      next.simClockSec,
      next.totalElapsedSec,
      dog.location,
      'care',
      `Adult ${dog.name} was rehomed through the kennel network (+${payout} credits).`,
      []
    );
  }

  return next;
}

export function repairPenObject(prev: GameState, objectId: string): GameState {
  if (prev.playerLocation !== 'outside_pen') return prev;
  const next: GameState = structuredClone(prev);
  const obj = next.penObjects.find((o) => o.id === objectId);
  if (!obj) return prev;
  obj.condition = 100;
  obj.lastInteractedText = `Restored and reinforced by handler at ${formatSimClock(next.simClockSec)}.`;
  addLog(
    next.logs,
    next.simClockSec,
    next.totalElapsedSec,
    'outside_pen',
    'care',
    `You repair and tidy the ${obj.name} in the Outside Pen.`,
    []
  );
  return next;
}

export function renameDog(prev: GameState, dogId: string, newName: string): GameState {
  const trimmed = newName.trim().slice(0, 24);
  if (!trimmed) return prev;
  const next: GameState = structuredClone(prev);
  const dog = next.dogs.find((d) => d.id === dogId);
  if (!dog) return prev;
  dog.name = trimmed;
  return next;
}

export function updateDogNotes(prev: GameState, dogId: string, notes: string): GameState {
  const next: GameState = structuredClone(prev);
  const dog = next.dogs.find((d) => d.id === dogId);
  if (!dog) return prev;
  dog.notes = notes;
  return next;
}

export function toggleConfirmTraitInJournal(prev: GameState, dogId: string, trait: UniqueTrait): GameState {
  const next: GameState = structuredClone(prev);
  const dog = next.dogs.find((d) => d.id === dogId);
  if (!dog) return prev;
  if (dog.discoveredTraits.includes(trait)) {
    dog.discoveredTraits = dog.discoveredTraits.filter((t) => t !== trait);
  } else {
    dog.discoveredTraits.push(trait);
  }
  return next;
}
