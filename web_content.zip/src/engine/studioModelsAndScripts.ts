import { StudioPart, StudioScript } from '../types/game';

export interface ModelJadiPreset {
  id: string;
  name: string;
  category: string;
  previewColor: string;
  partsCount: number;
  build: (offsetZ: number) => StudioPart[];
}

export const MODEL_JADI_PRESETS: ModelJadiPreset[] = [
  {
    id: 'model-tree',
    name: 'Pohon Rindang',
    category: 'Alam',
    previewColor: '#22c55e',
    partsCount: 3,
    build: (z) => {
      const t = Date.now();
      return [
        { id: `m-${t}-1`, name: 'BatangPohon', shape: 'cylinder', x: 0, y: 2.1, z, sx: 0.9, sy: 3.0, sz: 0.9, color: '#78350f', kind: 'normal' },
        { id: `m-${t}-2`, name: 'DaunBawah', shape: 'box', x: 0, y: 4.1, z, sx: 3.2, sy: 1.4, sz: 3.2, color: '#16a34a', kind: 'normal' },
        { id: `m-${t}-3`, name: 'DaunAtas', shape: 'box', x: 0, y: 5.3, z, sx: 2.0, sy: 1.1, sz: 2.0, color: '#22c55e', kind: 'normal' },
      ];
    },
  },
  {
    id: 'model-house',
    name: 'Rumah Mini',
    category: 'Bangunan',
    previewColor: '#ef4444',
    partsCount: 5,
    build: (z) => {
      const t = Date.now();
      return [
        { id: `m-${t}-1`, name: 'LantaiRumah', shape: 'box', x: 0, y: 0.9, z, sx: 6, sy: 0.5, sz: 6, color: '#94a3b8', kind: 'normal' },
        { id: `m-${t}-2`, name: 'DindingKiri', shape: 'box', x: -2.6, y: 2.9, z, sx: 0.7, sy: 3.5, sz: 6, color: '#f8fafc', kind: 'normal' },
        { id: `m-${t}-3`, name: 'DindingKanan', shape: 'box', x: 2.6, y: 2.9, z, sx: 0.7, sy: 3.5, sz: 6, color: '#f8fafc', kind: 'normal' },
        { id: `m-${t}-4`, name: 'DindingBelakang', shape: 'box', x: 0, y: 2.9, z: z - 2.6, sx: 4.6, sy: 3.5, sz: 0.7, color: '#e2e8f0', kind: 'normal' },
        { id: `m-${t}-5`, name: 'AtapRumah', shape: 'box', x: 0, y: 5.1, z, sx: 6.8, sy: 0.9, sz: 6.8, color: '#ef4444', kind: 'normal' },
      ];
    },
  },
  {
    id: 'model-arch',
    name: 'Gapura Juara',
    category: 'Dekorasi',
    previewColor: '#facc15',
    partsCount: 4,
    build: (z) => {
      const t = Date.now();
      return [
        { id: `m-${t}-1`, name: 'PilarKiri', shape: 'cylinder', x: -3.2, y: 3.1, z, sx: 1.0, sy: 5.0, sz: 1.0, color: '#f8fafc', kind: 'normal' },
        { id: `m-${t}-2`, name: 'PilarKanan', shape: 'cylinder', x: 3.2, y: 3.1, z, sx: 1.0, sy: 5.0, sz: 1.0, color: '#f8fafc', kind: 'normal' },
        { id: `m-${t}-3`, name: 'PalangAtas', shape: 'box', x: 0, y: 5.8, z, sx: 7.8, sy: 1.1, sz: 1.4, color: '#facc15', kind: 'normal' },
        { id: `m-${t}-4`, name: 'MahkotaGapura', shape: 'box', x: 0, y: 6.7, z, sx: 3.2, sy: 0.8, sz: 1.5, color: '#09090b', kind: 'checkpoint' },
      ];
    },
  },
  {
    id: 'model-lamp',
    name: 'Lampu Jalan',
    category: 'Kota',
    previewColor: '#fde047',
    partsCount: 3,
    build: (z) => {
      const t = Date.now();
      return [
        { id: `m-${t}-1`, name: 'TiangLampu', shape: 'cylinder', x: 0, y: 3.1, z, sx: 0.45, sy: 5.0, sz: 0.45, color: '#18181b', kind: 'normal' },
        { id: `m-${t}-2`, name: 'LenganLampu', shape: 'box', x: 0.8, y: 5.5, z, sx: 1.8, sy: 0.35, sz: 0.35, color: '#18181b', kind: 'normal' },
        { id: `m-${t}-3`, name: 'BolaLampu', shape: 'sphere', x: 1.5, y: 5.1, z, sx: 0.85, sy: 0.85, sz: 0.85, color: '#fde047', kind: 'normal' },
      ];
    },
  },
  {
    id: 'model-stairs',
    name: 'Tangga Pelangi',
    category: 'Obby',
    previewColor: '#38bdf8',
    partsCount: 5,
    build: (z) => {
      const t = Date.now();
      const colors = ['#ef4444', '#f97316', '#facc15', '#22c55e', '#38bdf8'];
      return colors.map((c, i) => ({
        id: `m-${t}-${i + 1}`,
        name: `Tangga_${i + 1}`,
        shape: 'box' as const,
        x: 0,
        y: 1.1 + i * 1.1,
        z: z - i * 2.6,
        sx: 4.5,
        sy: 0.7,
        sz: 2.5,
        color: c,
        kind: 'normal' as const,
      }));
    },
  },
  {
    id: 'model-tower',
    name: 'Menara Pantau',
    category: 'Bangunan',
    previewColor: '#6366f1',
    partsCount: 5,
    build: (z) => {
      const t = Date.now();
      return [
        { id: `m-${t}-1`, name: 'KakiMenara_1', shape: 'box', x: -1.8, y: 3.6, z: z - 1.8, sx: 0.7, sy: 6.0, sz: 0.7, color: '#334155', kind: 'normal' },
        { id: `m-${t}-2`, name: 'KakiMenara_2', shape: 'box', x: 1.8, y: 3.6, z: z - 1.8, sx: 0.7, sy: 6.0, sz: 0.7, color: '#334155', kind: 'normal' },
        { id: `m-${t}-3`, name: 'KakiMenara_3', shape: 'box', x: -1.8, y: 3.6, z: z + 1.8, sx: 0.7, sy: 6.0, sz: 0.7, color: '#334155', kind: 'normal' },
        { id: `m-${t}-4`, name: 'KakiMenara_4', shape: 'box', x: 1.8, y: 3.6, z: z + 1.8, sx: 0.7, sy: 6.0, sz: 0.7, color: '#334155', kind: 'normal' },
        { id: `m-${t}-5`, name: 'DekMenara', shape: 'box', x: 0, y: 6.8, z, sx: 5.2, sy: 0.8, sz: 5.2, color: '#6366f1', kind: 'checkpoint' },
      ];
    },
  },
  {
    id: 'model-bench',
    name: 'Bangku Taman',
    category: 'Dekorasi',
    previewColor: '#fb923c',
    partsCount: 4,
    build: (z) => {
      const t = Date.now();
      return [
        { id: `m-${t}-1`, name: 'DudukanBangku', shape: 'box', x: 0, y: 1.35, z, sx: 3.6, sy: 0.35, sz: 1.3, color: '#d97706', kind: 'normal' },
        { id: `m-${t}-2`, name: 'SandaranBangku', shape: 'box', x: 0, y: 2.05, z: z - 0.55, sx: 3.6, sy: 0.9, sz: 0.25, color: '#b45309', kind: 'normal' },
        { id: `m-${t}-3`, name: 'KakiKiri', shape: 'box', x: -1.4, y: 0.95, z, sx: 0.35, sy: 0.65, sz: 1.1, color: '#18181b', kind: 'normal' },
        { id: `m-${t}-4`, name: 'KakiKanan', shape: 'box', x: 1.4, y: 0.95, z, sx: 0.35, sy: 0.65, sz: 1.1, color: '#18181b', kind: 'normal' },
      ];
    },
  },
  {
    id: 'model-trampoline',
    name: 'Arena Trampolin',
    category: 'Obby',
    previewColor: '#06b6d4',
    partsCount: 2,
    build: (z) => {
      const t = Date.now();
      return [
        { id: `m-${t}-1`, name: 'BingkaiTrampolin', shape: 'cylinder', x: 0, y: 0.95, z, sx: 5.2, sy: 0.55, sz: 5.2, color: '#18181b', kind: 'normal' },
        { id: `m-${t}-2`, name: 'BantalanLompat', shape: 'cylinder', x: 0, y: 1.25, z, sx: 4.3, sy: 0.45, sz: 4.3, color: '#06b6d4', kind: 'bounce' },
      ];
    },
  },
];

export interface ScriptTemplateItem {
  id: string;
  name: string;
  description: string;
  code: string;
}

export const SCRIPT_TEMPLATES: ScriptTemplateItem[] = [
  {
    id: 'tpl-spin',
    name: 'Auto Putar Part',
    description: 'Memutar part target terus-menerus secara otomatis.',
    code: `// Dipanggil setiap frame saat game berjalan
onTick = (dt, time) => {
  part.ry += 90 * dt;
};`,
  },
  {
    id: 'tpl-elevator',
    name: 'Lift Naik-Turun',
    description: 'Menggerakkan part naik dan turun secara halus seperti elevator.',
    code: `// Lift bergerak naik turun 3 unit
onTick = (dt, time) => {
  part.y = base.y + Math.sin(time * 2) * 3;
};`,
  },
  {
    id: 'tpl-speed',
    name: 'Sistem Speed Boost',
    description: 'Saat disentuh pemain, kecepatan lari meningkat drastis!',
    code: `onTouch = () => {
  api.setSpeed(22);
  api.say("TURBO AKTIF!");
};`,
  },
  {
    id: 'tpl-superjump',
    name: 'Sistem Super Jump',
    description: 'Memberi lompatan tinggi dan gravitasi ringan saat disentuh.',
    code: `onTouch = () => {
  api.setJumpPower(24);
  api.setGravity(22);
  api.say("LOMPAT SUPER!");
};`,
  },
  {
    id: 'tpl-coin',
    name: 'Sistem Hadiah Koin',
    description: 'Menambah koin pemain otomatis saat menyentuh part target.',
    code: `let sudahKlaim = false;
onTouch = () => {
  if (!sudahKlaim) {
    sudahKlaim = true;
    api.giveCoins(1);
    api.say("+1 Koin dari Script!");
  }
};`,
  },
  {
    id: 'tpl-teleport',
    name: 'Portal Teleport',
    description: 'Memindahkan pemain langsung ke posisi tinggi saat menyentuh part.',
    code: `onTouch = () => {
  api.teleport(0, 12, -16);
  api.say("Teleport Berhasil!");
};`,
  },
  {
    id: 'tpl-rainbow',
    name: 'Efek Pelangi Dinamis',
    description: 'Mengubah warna part secara pelangi terus-menerus.',
    code: `onTick = (dt, time) => {
  api.setRainbow(time * 0.4);
};`,
  },
  {
    id: 'tpl-custom',
    name: 'Script Bebas (Custom)',
    description: 'Buat sistem apa saja dengan api.setSpeed, api.teleport, part.x/y/z/rx/ry/rz, onTick & onTouch.',
    code: `// Variabel tersedia: part, base, api, player
// Event: onTick = (dt, time) => { ... } | onTouch = () => { ... }
onTick = (dt, time) => {
  part.ry += 45 * dt;
};
onTouch = () => {
  api.heal(100);
  api.say("Sistem Custom Aktif!");
};`,
  },
];

export interface ScriptPartState {
  x: number;
  y: number;
  z: number;
  rx: number;
  ry: number;
  rz: number;
  color: string;
}

export interface ScriptApi {
  setSpeed: (speed: number) => void;
  setJumpPower: (vel: number) => void;
  setGravity: (g: number) => void;
  giveCoins: (count: number) => void;
  teleport: (x: number, y: number, z: number) => void;
  heal: (hp: number) => void;
  respawn: () => void;
  say: (text: string) => void;
  setColor: (hex: string) => void;
  setRainbow: (hueOffset: number) => void;
  log: (msg: string) => void;
}

export interface CompiledScriptRunner {
  scriptId: string;
  targetPartId: string;
  onTick?: (dt: number, time: number) => void;
  onTouch?: () => void;
}

export function compileStudioScript(
  script: StudioScript,
  partProxy: ScriptPartState,
  baseState: ScriptPartState,
  api: ScriptApi,
  playerRef: { x: number; y: number; z: number }
): { runner: CompiledScriptRunner | null; error?: string } {
  try {
    const fn = new Function(
      'part',
      'base',
      'api',
      'player',
      `
      let onTick = undefined;
      let onTouch = undefined;
      ${script.code}
      return { onTick, onTouch };
      `
    );
    const result = fn(partProxy, baseState, api, playerRef) as {
      onTick?: (dt: number, time: number) => void;
      onTouch?: () => void;
    };
    return {
      runner: {
        scriptId: script.id,
        targetPartId: script.targetPartId,
        onTick: typeof result?.onTick === 'function' ? result.onTick : undefined,
        onTouch: typeof result?.onTouch === 'function' ? result.onTouch : undefined,
      },
    };
  } catch (err) {
    return {
      runner: null,
      error: err instanceof Error ? err.message : 'Script syntax error',
    };
  }
}
