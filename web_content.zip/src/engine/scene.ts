// @ts-nocheck
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import * as THREE from "three";
import { curve, layout, type Journal } from "./spec";
import type { Live, Spec } from "./types";

const PG = new THREE.SphereGeometry(0.3, 8, 6);
const VIS = 0.1;

type Cyl = { c: Journal; pg: THREE.Group; rod: THREE.Mesh; prevStroke: number };
type Unit = {
  root: THREE.Group;
  crank: THREE.Object3D;
  cyl: Cyl[];
  spin: THREE.Object3D[];
  hot: THREE.MeshStandardMaterial | null;
  tip: THREE.Vector3;
  fx: THREE.Group;
  r: number;
  L: number;
  top: number;
  pool: THREE.Mesh[];
};
type Puff = { m: THREE.Mesh; f: boolean; t: number; l: number; v: THREE.Vector3 };
type Flow = { m: THREE.Mesh; t: number; l: number; v: THREE.Vector3; kind: "air" | "fuel" | "burn" | "exh" };
type Fly = { cyl: Cyl; v: THREE.Vector3; rv: THREE.Vector3 };

function M(color: string, metal = 0.4, rough = 0.5) {
  return new THREE.MeshStandardMaterial({ color, metalness: metal, roughness: rough });
}

function cyl(rt: number, rb: number, h: number, mat: THREE.Material, seg = 24) {
  return new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), mat);
}

function ax(m: THREE.Mesh) {
  m.rotation.z = Math.PI / 2;
  return m;
}

function bakeMerge(root: THREE.Object3D) {
  root.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(root.matrixWorld).invert();
  const buckets = new Map<THREE.Material, { geos: THREE.BufferGeometry[]; meshes: THREE.Mesh[] }>();
  const found: THREE.Mesh[] = [];
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (!mesh.isMesh || mesh.userData.live) return;
    let p: THREE.Object3D | null = mesh.parent;
    while (p && p !== root) {
      if (p.userData.live) return;
      p = p.parent;
    }
    found.push(mesh);
  });
  for (const mesh of found) {
    const mat = mesh.material;
    if (Array.isArray(mat)) continue;
    const g = mesh.geometry.clone();
    g.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inv, mesh.matrixWorld));
    let b = buckets.get(mat);
    if (!b) {
      b = { geos: [], meshes: [] };
      buckets.set(mat, b);
    }
    b.geos.push(g);
    b.meshes.push(mesh);
  }
  for (const [mat, b] of buckets) {
    if (b.meshes.length < 2) {
      for (const g of b.geos) g.dispose();
      continue;
    }
    const merged = (() => {
      try {
        return mergeGeometries(b.geos);
      } catch {
        return null;
      }
    })();
    for (const g of b.geos) g.dispose();
    if (!merged) continue;
    for (const m of b.meshes) {
      m.geometry.dispose();
      m.removeFromParent();
    }
    root.add(new THREE.Mesh(merged, mat));
  }
}

function buildUnit(spec: Spec): Unit {
  const engine = new THREE.Group();
  const b = spec.bore / 50;
  const r = spec.stroke / 100;
  const L = r * 3;
  const journals = layout(spec.type, b);
  const cm = M(spec.color, 0.35, 0.45);
  const steel = M("#c4cad4", 0.55, 0.32);
  const dark = M("#2a2e35", 0.45, 0.5);
  const xs = journals.map((c) => c.x);
  const x0 = Math.min(...xs) - 0.5 * b - 0.3;
  const x1 = Math.max(...xs) + 0.5 * b + 0.3;
  const crank = new THREE.Group();
  const sh = ax(cyl(0.16, 0.16, x1 - x0 + 0.4, steel));
  sh.position.x = (x0 + x1) / 2;
  crank.add(sh);
  for (const c of journals) {
    const cs = Math.cos(c.p);
    const sn = Math.sin(c.p);
    const pin = ax(cyl(0.13, 0.13, 0.4, steel));
    pin.position.set(c.x, r * cs, r * sn);
    crank.add(pin);
    for (const dx of [-0.2, 0.2]) {
      const w = new THREE.Mesh(new THREE.BoxGeometry(0.08, r + 0.3, 0.4), dark);
      w.position.set(c.x + dx, (r * cs) / 2, (r * sn) / 2);
      w.rotation.x = c.p;
      crank.add(w);
    }
  }
  const fr = Math.max(0.9, r + 0.4);
  const fw = ax(cyl(fr, fr, 0.25, steel, 32));
  fw.position.x = x1 + 0.3;
  crank.add(fw);
  const mk = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.2, 0.12), M("#e8590c"));
  mk.position.set(x1 + 0.3, fr * 0.75, 0);
  crank.add(mk);
  engine.add(crank);

  const glass = new THREE.MeshStandardMaterial({
    color: spec.color,
    transparent: true,
    opacity: 0.16,
    metalness: 0.3,
    roughness: 0.45,
    depthWrite: false,
  });
  const cc = ax(cyl(r + 0.55, r + 0.55, x1 - x0, glass));
  cc.position.x = (x0 + x1) / 2;
  engine.add(cc);
  const sump = new THREE.Mesh(
    new THREE.BoxGeometry(x1 - x0 + 0.2, r + 0.45, (r + 0.55) * 1.7),
    dark,
  );
  sump.position.set((x0 + x1) / 2, -r * 0.35, 0);
  engine.add(sump);

  const top = r + L + 0.3 * b;
  const s0 = L - r - 0.4 * b;
  const len = top - s0;
  const linerMat = new THREE.MeshStandardMaterial({
    color: spec.color,
    transparent: true,
    opacity: 0.22,
    side: THREE.DoubleSide,
    metalness: 0.3,
    roughness: 0.45,
    depthWrite: false,
  });
  const cyls: Cyl[] = [];
  const dz = spec.fuel === "dsl";
  for (const c of journals) {
    const g = new THREE.Group();
    g.position.x = c.x;
    g.rotation.x = c.bk;
    const ln = cyl(b / 2 + 0.1, b / 2 + 0.1, len, linerMat, 24);
    ln.position.y = s0 + len / 2;
    g.add(ln);
    for (let k = 1; k < 5; k++) {
      const f = cyl(b / 2 + 0.2, b / 2 + 0.2, 0.04, cm, 24);
      f.position.y = s0 + (len * k) / 5.5;
      g.add(f);
    }
    const hd = cyl(b / 2 + 0.15, b / 2 + 0.15, 0.4 * b, cm, 24);
    hd.position.y = top + 0.2 * b;
    g.add(hd);
    const pl = cyl(dz ? 0.09 : 0.06, dz ? 0.09 : 0.06, 0.45, dz ? M("#d9480f") : steel, 10);
    pl.position.y = top + 0.4 * b + 0.2;
    g.add(pl);
    engine.add(g);

    const pg = new THREE.Group();
    pg.position.x = c.x;
    pg.rotation.x = c.bk;
    const pm = cyl(b / 2 - 0.03, b / 2 - 0.03, 0.6 * b, steel, 20);
    pm.position.y = -0.05 * b;
    pg.add(pm);
    const rg = cyl(b / 2 - 0.01, b / 2 - 0.01, 0.04, dark, 20);
    rg.position.y = 0.15 * b;
    pg.add(rg);
    pg.add(ax(cyl(0.07, 0.07, 0.3, dark, 10)));
    engine.add(pg);
    const rod = new THREE.Mesh(new THREE.BoxGeometry(0.12, L, 0.09), dark);
    rod.userData.live = true;
    engine.add(rod);
    cyls.push({ c, pg, rod, prevStroke: 0 });
  }

  const spin: THREE.Object3D[] = [];
  const spinner = (parent: THREE.Object3D, x: number, y0: number, rad: number, col: string) => {
    const g = new THREE.Group();
    g.position.set(x, y0, 0);
    g.add(new THREE.Mesh(new THREE.BoxGeometry(0.08, rad * 1.8, 0.14), M(col)));
    g.add(new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.14, rad * 1.8), M(col)));
    parent.add(g);
    spin.push(g);
    return g;
  };

  let yStack = top + 0.7 * b;
  let hot: THREE.MeshStandardMaterial | null = null;
  if (spec.sc) {
    const g = new THREE.Group();
    const bd = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.8, 1.1), M("#3a4049", 0.5, 0.4));
    g.add(bd);
    for (let k = -1; k <= 1; k++) {
      const f = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.86, 1.16), steel);
      f.position.x = k * 0.55;
      g.add(f);
    }
    const pu = ax(cyl(0.38, 0.38, 0.16, steel));
    pu.position.x = 1.05;
    g.add(pu);
    spinner(g, 1.15, 0, 0.3, "#e8590c");
    g.position.set((x0 + x1) / 2, yStack + 0.45, 0);
    engine.add(g);
    yStack += 1.05;
  }
  if (spec.carb) {
    const g = new THREE.Group();
    g.add(cyl(0.5, 0.5, 0.6, M("#c9a227", 0.6, 0.35)));
    const fl = cyl(0.9, 0.9, 0.3, steel, 28);
    fl.position.y = 0.5;
    g.add(fl);
    const th = ax(cyl(0.18, 0.18, 1.1, steel, 12));
    th.position.y = -0.1;
    g.add(th);
    g.position.set((x0 + x1) / 2, yStack + 0.45, 0);
    engine.add(g);
    yStack += 1.1;
  }
  if (spec.turbo) {
    const g = new THREE.Group();
    g.position.set((x0 + x1) / 2, 0.15, r + 1.35);
    hot = new THREE.MeshStandardMaterial({
      color: "#8a3412",
      emissive: 0xff4d00,
      emissiveIntensity: 0,
      metalness: 0.4,
      roughness: 0.5,
    });
    const t = ax(cyl(0.75, 0.5, 0.8, hot));
    t.position.x = 0.6;
    const cp = ax(cyl(0.5, 0.7, 0.7, steel));
    cp.position.x = -0.6;
    const st = ax(cyl(0.1, 0.1, 0.5, dark, 10));
    g.add(t, cp, st);
    spinner(g, 1.02, 0, 0.5, "#ffd8a8");
    spinner(g, -0.97, 0, 0.55, "#9ec5ff");
    const p1 = cyl(0.16, 0.16, 1.1, M("#6b7280", 0.5, 0.5), 12);
    p1.rotation.x = Math.PI / 2;
    p1.position.set(0.6, 0, -0.55);
    const p2 = cyl(0.14, 0.14, 1.1, M("#2f6fd0", 0.4, 0.4), 12);
    p2.rotation.x = Math.PI / 2;
    p2.position.set(-0.6, 0.1, -0.55);
    g.add(p1, p2);
    engine.add(g);
  }

  const ey = -0.15;
  const ez = -(r + 0.95);
  const header = ax(cyl(0.16, 0.16, x1 - x0, M("#8a5a2b", 0.5, 0.5)));
  header.position.set((x0 + x1) / 2, ey, ez);
  engine.add(header);
  const cf = {
    stock: [0.5, 2.2, "#555b66"],
    sport: [0.36, 2, "#aeb6c2"],
    straight: [0.24, 2, "#b9c0cb"],
    open: [0.2, 0.9, "#9aa3b0"],
  }[spec.exh];
  const muff = ax(cyl(Number(cf[0]), Number(cf[0]), Number(cf[1]), M(String(cf[2]), 0.6, 0.35)));
  muff.position.set(x1 + 0.3 + Number(cf[1]) / 2, ey, ez);
  engine.add(muff);
  const tipR = spec.exh === "open" ? 0.34 : Number(cf[0]) * 0.7;
  const tipM = ax(cyl(tipR, Number(cf[0]) * 0.7, 0.35, M("#d5dae2", 0.8, 0.25)));
  tipM.position.set(x1 + 0.3 + Number(cf[1]) + 0.1, ey, ez);
  engine.add(tipM);
  const tip = new THREE.Vector3(x1 + 0.3 + Number(cf[1]) + 0.3, ey, ez);

  const fx = new THREE.Group();
  engine.add(fx);
  const lt = new THREE.PointLight(0xff5500, 0, 8);
  lt.position.set((x0 + x1) / 2, top, 0);
  engine.add(lt);
  fx.userData.light = lt;
  const sparkMat = new THREE.MeshBasicMaterial({
    color: 0xfff6d8,
    transparent: true,
    opacity: 0,
    depthWrite: false,
    toneMapped: false,
  });
  const spark = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), sparkMat);
  spark.userData.live = true;
  spark.visible = false;
  fx.add(spark);
  fx.userData.spark = spark;
  const pool: THREE.Mesh[] = [];
  for (let i = 0; i < 28; i++) {
    const mat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0,
      depthWrite: false,
      toneMapped: false,
    });
    const m = new THREE.Mesh(PG, mat);
    m.userData.live = true;
    m.visible = false;
    fx.add(m);
    pool.push(m);
  }

  for (const c of cyls) {
    bakeMerge(c.pg);
    c.pg.userData.live = true;
  }
  for (const s of spin) {
    bakeMerge(s);
    s.userData.live = true;
  }
  bakeMerge(crank);
  crank.userData.live = true;
  bakeMerge(engine);

  return { root: engine, crank, cyl: cyls, spin, hot, tip, fx, r, L, top, pool };
}

function disposeTree(root: THREE.Object3D) {
  const geos = new Set<THREE.BufferGeometry>();
  const mats = new Set<THREE.Material>();
  root.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.geometry && m.geometry !== PG) geos.add(m.geometry);
    const mat = m.material;
    if (!mat) return;
    if (Array.isArray(mat)) mat.forEach((x) => mats.add(x));
    else mats.add(mat);
  });
  geos.forEach((g) => g.dispose());
  mats.forEach((m) => m.dispose());
}

export class EngineScene {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
  private root = new THREE.Group();
  private shadow: THREE.Mesh;
  private units: Unit[] = [];
  private holder: THREE.Group | null = null;
  private pt: Puff[] = [];
  private flow: Flow[] = [];
  private fly: Fly | null = null;
  private blown = false;
  private yaw = -0.62;
  private pitch = 0.18;
  private dist = 1.18;
  private fitZ = 9.4;
  private fitPitch = 0.22;
  private lookY = -0.4;
  ang = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
    this.renderer.setClearColor(0x000000, 0);
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x556070, 1.05));
    const dl = new THREE.DirectionalLight(0xffffff, 1.25);
    dl.position.set(5, 8, 6);
    this.scene.add(dl);
    const dl2 = new THREE.DirectionalLight(0xaabbff, 0.45);
    dl2.position.set(-6, 2, -4);
    this.scene.add(dl2);
    this.root.rotation.order = "YXZ";
    this.scene.add(this.root);
    const shadow = new THREE.Mesh(
      new THREE.CircleGeometry(1, 40),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28 }),
    );
    shadow.rotation.x = -Math.PI / 2;
    this.shadow = shadow;
    this.scene.add(shadow);
    this.applyPose();
  }

  resize() {
    const canvas = this.renderer.domElement;
    const w = canvas.clientWidth || 1;
    const h = canvas.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    const portrait = w / h < 1;
    this.fitZ = portrait ? (9.4 / (w / h)) * 0.66 : 9.4;
    this.fitPitch = portrait ? 0.2 : 0.22;
    this.lookY = portrait ? -0.25 : -0.4;
    this.applyCamera();
  }

  zoom(delta: number) {
    this.dist = Math.min(2.6, Math.max(0.42, this.dist * Math.exp(delta)));
    this.applyCamera();
  }

  private applyCamera() {
    const z = this.fitZ * this.dist;
    this.camera.position.set(0, z * this.fitPitch, z);
    this.camera.lookAt(0, this.lookY, 0);
    this.camera.updateProjectionMatrix();
  }

  orbit(dx: number, dy: number) {
    this.yaw -= dx * 0.008;
    this.pitch = Math.min(0.9, Math.max(-0.35, this.pitch + dy * 0.006));
    this.applyPose();
  }

  resetView() {
    this.yaw = -0.62;
    this.pitch = 0.18;
    this.dist = 1.18;
    this.applyPose();
    this.applyCamera();
  }

  private applyPose() {
    this.root.rotation.y = this.yaw;
    this.root.rotation.x = this.pitch;
  }

  rebuild(spec: Spec) {
    if (this.holder) {
      this.root.remove(this.holder);
      disposeTree(this.holder);
    }
    this.pt = [];
    this.flow = [];
    this.fly = null;
    this.blown = false;
    this.root.position.x = 0;
    const a = buildUnit(spec);
    const holder = new THREE.Group();
    holder.add(a.root);
    this.units = [a];
    if (spec.twin) {
      const b = buildUnit(spec);
      const box = new THREE.Box3().setFromObject(a.root);
      const dz = box.max.z - box.min.z + 0.85;
      b.root.position.z = -dz;
      holder.add(b.root);
      this.units.push(b);
    }
    const box = new THREE.Box3().setFromObject(holder);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    holder.position.copy(center).negate();
    this.root.scale.setScalar(9.15 / Math.max(0.001, size.length()));
    this.root.add(holder);
    this.holder = holder;
    this.root.updateMatrixWorld(true);
    const wb = new THREE.Box3().setFromObject(this.root);
    const span = Math.max(wb.max.x - wb.min.x, wb.max.z - wb.min.z);
    this.shadow.position.y = wb.min.y + 0.02;
    this.shadow.scale.setScalar(Math.max(1.2, span * 0.42));
  }

  blow() {
    if (!this.holder || this.blown) return;
    this.blown = true;
    const seen = new Set<THREE.Material>();
    this.holder.traverse((o) => {
      const m = (o as THREE.Mesh).material as THREE.Material | THREE.Material[] | undefined;
      if (!m) return;
      const list = Array.isArray(m) ? m : [m];
      for (const mat of list) {
        if (seen.has(mat)) continue;
        seen.add(mat);
        const sm = mat as THREE.MeshStandardMaterial;
        if (sm.color) sm.color.multiplyScalar(0.4);
      }
    });
    const unit = this.units[0];
    if (!unit || unit.cyl.length === 0) return;
    const cyl = unit.cyl[Math.floor(Math.random() * unit.cyl.length)]!;
    const a = cyl.c.bk;
    const rnd = Math.random;
    this.fly = {
      cyl,
      v: new THREE.Vector3((rnd() - 0.5) * 3, Math.cos(a) * 16, Math.sin(a) * 16),
      rv: new THREE.Vector3((rnd() - 0.5) * 4, Math.cos(a) * 10, Math.sin(a) * 10),
    };
  }

  flame() {
    for (const u of this.units) {
      const n = 3;
      for (let i = 0; i < n; i++) this.puffAt(u, true, true);
    }
  }

  private puffAt(unit: Unit, fire: boolean, exhaust: boolean) {
    if (this.pt.length > 120) return;
    const mat = new THREE.MeshBasicMaterial({
      color: fire ? 0xff6a00 : 0x333333,
      transparent: true,
      opacity: fire ? 0.9 : 0.55,
      toneMapped: false,
    });
    const m = new THREE.Mesh(PG, mat);
    if (exhaust) {
      m.position.copy(unit.tip);
      m.position.y += (Math.random() - 0.5) * 0.1;
      m.scale.setScalar(0.35 + Math.random() * 0.25);
      unit.fx.add(m);
      this.pt.push({
        m,
        f: true,
        t: 0,
        l: 0.15 + Math.random() * 0.15,
        v: new THREE.Vector3(3 + Math.random() * 5, Math.random() - 0.5, Math.random() - 0.5),
      });
      return;
    }
    const q = unit.fx;
    const src = (q.userData.light as THREE.PointLight | undefined)?.position ?? new THREE.Vector3();
    m.position.set(src.x + (Math.random() - 0.5) * 2.2, src.y + Math.random() * 0.4, src.z + (Math.random() - 0.5) * 1.4);
    m.scale.setScalar(fire ? 0.5 + Math.random() * 0.5 : 0.5 + Math.random() * 0.7);
    unit.fx.add(m);
    this.pt.push({
      m,
      f: fire,
      t: 0,
      l: fire ? 0.5 + Math.random() * 0.4 : 2 + Math.random() * 2.5,
      v: new THREE.Vector3(
        (Math.random() - 0.5) * (fire ? 5 : 1.2),
        (fire ? 3 : 1.6) + Math.random() * (fire ? 4 : 1.2),
        (Math.random() - 0.5) * (fire ? 5 : 1.2),
      ),
    });
  }

  advance(dt: number, live: Live, spec: Spec) {
    const rpm = live.dead ? Math.min(live.rpm, 2500) : live.rpm;
    this.ang += dt * (rpm / 60) * Math.PI * 2 * VIS;
    for (const u of this.units) this.pose(u);
    const red = Math.max(1, curve(spec).red);
    for (const u of this.units) {
      if (u.hot) u.hot.emissiveIntensity = live.stall ? 0 : Math.min(1.4, (live.rpm / red) * 0.9);
      const light = u.fx.userData.light as THREE.PointLight | undefined;
      if (light) light.intensity = live.dead ? Math.max(0, 6 * (1 - live.deadT / 1.3)) : 0;
    }
    this.cycle(dt, live, spec);
    this.fx(dt, live);
    this.renderer.render(this.scene, this.camera);
  }

  private pose(u: Unit) {
    u.crank.rotation.x = this.ang;
    const { r, L } = u;
    for (const item of u.cyl) {
      if (this.fly && this.fly.cyl === item) continue;
      const { c, pg, rod } = item;
      const th = this.ang + c.p;
      const a = c.bk;
      const v = r * Math.sin(th - a);
      const s = r * Math.cos(th - a) + Math.sqrt(Math.max(0, L * L - v * v));
      const py = r * Math.cos(th);
      const pz = r * Math.sin(th);
      const Py = s * Math.cos(a);
      const Pz = s * Math.sin(a);
      pg.position.y = Py;
      pg.position.z = Pz;
      rod.position.set(c.x, (py + Py) / 2, (pz + Pz) / 2);
      rod.rotation.x = Math.atan2(Pz - pz, Py - py);
    }
    for (const g of u.spin) g.rotation.x = this.ang * 4;
  }

  private mod4(n: number) {
    const t = Math.PI * 4;
    return ((n % t) + t) % t;
  }

  private grab(u: Unit) {
    for (const m of u.pool) if (!m.visible) return m;
    return null;
  }

  private cycle(dt: number, live: Live, spec: Spec) {
    const running = !live.stall && !live.dead && live.rpm > 45;
    const gas = spec.fuel !== "dsl";
    let spawned = 0;
    for (const u of this.units) {
      const spark = u.fx.userData.spark as THREE.Mesh | undefined;
      for (const item of u.cyl) {
        const stroke = this.mod4(this.ang + item.c.p - item.c.bk);
        const prev = item.prevStroke;
        item.prevStroke = stroke;
        if (!running) continue;
        const intake = stroke > 0.35 && stroke < 2.55;
        if (intake && spawned < 3 && this.flow.length < 36 && Math.random() < dt * (1.1 + live.rpm / 4500)) {
          if (this.spit(u, item, "air")) spawned++;
          if (gas && spawned < 3 && Math.random() < 0.42 && this.spit(u, item, "fuel")) spawned++;
        }
        if (prev < Math.PI * 2 && stroke >= Math.PI * 2) {
          this.spit(u, item, "burn");
          if (spark && gas) {
            const a = item.c.bk;
            const y = u.top * Math.cos(a);
            const z = u.top * Math.sin(a);
            spark.position.set(item.c.x, y * 0.92, z * 0.92);
            spark.visible = true;
            (spark.material as THREE.MeshBasicMaterial).opacity = gas ? 0.95 : 0.35;
            spark.scale.setScalar(1);
            u.fx.userData.sparkT = 0.07;
          }
        }
        if (stroke > Math.PI * 3.05 && stroke < Math.PI * 3.8 && spawned < 3 && this.flow.length < 36 && Math.random() < dt * (0.7 + live.rpm / 5500)) {
          if (this.spit(u, item, "exh")) spawned++;
        }
      }
      if (spark) {
        let left = Number(u.fx.userData.sparkT) || 0;
        if (!running) left = 0;
        left -= dt;
        u.fx.userData.sparkT = left;
        const mat = spark.material as THREE.MeshBasicMaterial;
        if (left <= 0 || !gas) {
          spark.visible = false;
          mat.opacity = 0;
        } else {
          mat.opacity = 0.9 * (left / 0.07);
        }
      }
    }
    for (let i = this.flow.length - 1; i >= 0; i--) {
      const p = this.flow[i]!;
      p.t += dt;
      const mat = p.m.material as THREE.MeshBasicMaterial;
      if (p.t > p.l) {
        p.m.visible = false;
        mat.opacity = 0;
        this.flow.splice(i, 1);
        continue;
      }
      p.m.position.addScaledVector(p.v, dt);
      const u = p.t / p.l;
      mat.opacity = (p.kind === "burn" ? 0.72 : p.kind === "exh" ? 0.4 : 0.55) * (1 - u);
      if (p.kind === "exh") p.m.scale.multiplyScalar(1 + dt * 0.8);
    }
  }

  private spit(u: Unit, item: Cyl, kind: Flow["kind"]) {
    const m = this.grab(u);
    if (!m) return false;
    const a = item.c.bk;
    const crownY = item.pg.position.y + Math.cos(a) * 0.28;
    const crownZ = item.pg.position.z + Math.sin(a) * 0.28;
    const hy = u.top * Math.cos(a);
    const hz = u.top * Math.sin(a);
    const mat = m.material as THREE.MeshBasicMaterial;
    let life = 0.28;
    let scale = 0.09;
    const v = new THREE.Vector3();
    if (kind === "air" || kind === "fuel") {
      m.position.set(item.c.x + (kind === "fuel" ? 0.12 : 0.22), hy + Math.cos(a) * 0.35, hz + Math.sin(a) * 0.35);
      v.set(item.c.x - m.position.x, crownY - m.position.y, crownZ - m.position.z);
      const len = Math.max(0.001, v.length());
      v.multiplyScalar((kind === "fuel" ? 1.6 : 1.35) / len);
      mat.color.setHex(kind === "fuel" ? 0xe8590c : 0x74c0fc);
      life = 0.22 + Math.random() * 0.08;
      scale = kind === "fuel" ? 0.08 : 0.13;
    } else if (kind === "burn") {
      m.position.set(item.c.x, hy * 0.78 + crownY * 0.22, hz * 0.78 + crownZ * 0.22);
      v.set((Math.random() - 0.5) * 0.25, (Math.random() - 0.5) * 0.25, (Math.random() - 0.5) * 0.25);
      mat.color.setHex(0xffc14d);
      life = 0.1;
      scale = 0.2;
    } else {
      m.position.set(item.c.x, crownY, crownZ);
      v.set((Math.random() - 0.5) * 0.3, -Math.cos(a) * 0.6, -Math.sin(a) * 0.6 - 1.1);
      mat.color.setHex(Math.random() < 0.45 ? 0xc2410c : 0x8d959e);
      life = 0.28;
      scale = 0.12;
    }
    m.visible = true;
    m.scale.setScalar(scale);
    mat.opacity = 0.6;
    this.flow.push({ m, t: 0, l: life, v, kind });
    return true;
  }

  private fx(dt: number, live: Live) {
    if (!live.dead) this.root.position.x = 0;
    else {
      const t = live.deadT;
      const sp = live.spd;
      this.root.position.x =
        t < 0.7 ? (Math.random() - 0.5) * 0.35 * (1 - t / 0.7) : sp > 0.5 ? (Math.random() - 0.5) * Math.min(0.12, sp * 0.006) : 0;
      if (t < 0.8 && this.units[0]) {
        for (let i = 0; i < 4; i++) this.puffAt(this.units[0], true, false);
        this.puffAt(this.units[0], false, false);
      } else if (this.units[0]) {
        const q = Math.max(0, 1 - live.stopT / 8);
        if (Math.random() < (0.15 + live.spd / 30) * q) this.puffAt(this.units[0], false, false);
        if (live.spd > 1 && Math.random() < Math.min(0.5, live.spd / 40)) this.puffAt(this.units[0], true, false);
      }
      const f = this.fly;
      if (f) {
        f.cyl.pg.position.addScaledVector(f.v, dt);
        f.v.y -= 25 * dt;
        f.cyl.pg.rotation.z += dt * 7;
        f.cyl.rod.position.addScaledVector(f.rv, dt);
        f.rv.y -= 25 * dt;
        f.cyl.rod.rotation.z += dt * 4;
      }
    }
    for (let i = this.pt.length - 1; i >= 0; i--) {
      const p = this.pt[i]!;
      p.t += dt;
      if (p.t > p.l) {
        p.m.removeFromParent();
        (p.m.material as THREE.Material).dispose();
        this.pt.splice(i, 1);
        continue;
      }
      p.m.position.addScaledVector(p.v, dt);
      const u = p.t / p.l;
      const mat = p.m.material as THREE.MeshBasicMaterial;
      if (p.f) {
        mat.color.setHSL(0.08 * (1 - u), 1, 0.5 - 0.3 * u);
        mat.opacity = 0.9 * (1 - u);
      } else {
        p.v.y *= 1 - dt * 0.3;
        p.m.scale.multiplyScalar(1 + dt * 0.5);
        mat.opacity = 0.55 * (1 - u);
      }
    }
  }
}

