import type {EffectInstance,TimelineItem} from '../core/types';
const css:Record<string,(p:Record<string,number|string|boolean>)=>string>={
 glow:p=>`drop-shadow(0 0 ${Number(p.radius)/2}px rgba(80,220,255,${Number(p.intensity)/120}))`,
 'motion-blur':p=>`blur(${Math.max(0,Number(p.amount)/48)}px)`,
 'rgb-split':p=>`drop-shadow(${Number(p.amount)/7}px 0 rgba(255,40,90,.45)) drop-shadow(${-Number(p.amount)/7}px 0 rgba(50,200,255,.45))`,
 glitch:p=>`contrast(${1+Number(p.amount)/260}) saturate(${1+Number(p.blocks)/120})`,
 vhs:p=>`saturate(${1+Number(p.chroma)/160}) contrast(${1+Number(p.lines)/250})`,
 'cinema-lens':p=>`contrast(${1+Number(p.contrast)/120}) drop-shadow(0 0 ${Number(p.bloom)/3}px rgba(255,255,255,.18))`,
 'smart-sharpen':p=>`contrast(${1+Number(p.amount)/250}) saturate(${1+Number(p.amount)/300})`,
 'film-grain':p=>`contrast(${1+Number(p.amount)/500})`,
 'lens-distortion':p=>`perspective(900px) rotateZ(${Number(p.amount)/100}deg)`,
 'radial-zoom':p=>`scale(${1+Number(p.amount)/1000})`,
 'tilt-shift':p=>`blur(${Number(p.blur)/25}px)`,
 duotone:p=>`saturate(${Math.max(.2,1-Number(p.mix)/150)}) hue-rotate(${Number(p.angle)}deg)`,
 'prism-bloom':p=>`drop-shadow(0 0 ${Number(p.spread)/2}px rgba(178,117,255,.28))`,
 'echo-trail':p=>`blur(${Number(p.offset)/80}px)`,
 'pixel-surge':p=>`contrast(${1+Number(p.amount)/200}) saturate(${1+Number(p.blocks)/200})`,
 'night-bloom':p=>`contrast(${1+Number(p.bloom)/220}) brightness(${1+Number(p.blackLift)/260})`,
 'toon-pulse':p=>`contrast(${1+Number(p.ink)/200})`,
 'edge-pulse':p=>`contrast(${1+Number(p.amount)/240})`,
 'focus-pop':p=>`contrast(${1+Number(p.sharpness)/180})`,
};
export function computeFilter(effects:EffectInstance[]){return effects.filter(e=>e.enabled).map(e=>css[e.effectId]?.(e.params)??'').filter(Boolean).join(' ');}
export function itemLabel(item:TimelineItem){return item.name||item.kind.toUpperCase();}
export function activeEffectIds(effects:EffectInstance[]){return effects.filter(e=>e.enabled).map(e=>e.effectId);}
