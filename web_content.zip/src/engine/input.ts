/**
 * Unified input for flying.
 *
 *  - `stick` is the combined control stick, each axis in [-1, 1]; y > 0 means "up" (push forward).
 *  - `throttle` is a persistent 0..1 setting (slider, keys, mouse wheel or gamepad triggers).
 *
 * The on-screen joystick and throttle slider (src/ui/touch.ts) write into this object through
 * `setTouchStick` / `setThrottle`; keyboard and gamepad are read here. All sources are blended,
 * so a phone with a paired controller or a laptop with a mouse works with no mode switch.
 */
export type Action = 'pause' | 'confirm'
export type InputMethod = 'touch' | 'keyboard' | 'gamepad'

const BINDINGS: Record<string, Action> = {
  Escape: 'pause',
  KeyP: 'pause',
  Enter: 'confirm',
  Space: 'confirm',
}

const PREVENT = new Set(['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'PageUp', 'PageDown'])

export class Input {
  readonly stick = { x: 0, y: 0 }
  throttle = 0.5
  method: InputMethod = 'touch'

  private readonly touchStick = { x: 0, y: 0 }
  private readonly held = new Set<string>()
  private readonly pressed = new Set<Action>()
  private gamepadPause = false
  private gamepadConfirm = false
  private readonly cleanup: Array<() => void> = []

  constructor(private readonly target: HTMLElement) {
    const on = <K extends keyof WindowEventMap>(type: K, fn: (e: WindowEventMap[K]) => void, opts?: AddEventListenerOptions) => {
      window.addEventListener(type, fn, opts)
      this.cleanup.push(() => window.removeEventListener(type, fn))
    }
    on('keydown', e => {
      if (e.repeat) return
      if (PREVENT.has(e.code)) e.preventDefault()
      this.held.add(e.code)
      this.method = 'keyboard'
      const action = BINDINGS[e.code]
      if (action) this.pressed.add(action)
    })
    on('keyup', e => this.held.delete(e.code))
    on('blur', () => this.releaseAll())
    on('wheel', e => {
      if (!(e.target instanceof HTMLCanvasElement)) return
      this.throttle = Math.min(1, Math.max(0, this.throttle - Math.sign(e.deltaY) * 0.05))
      this.method = 'keyboard'
    }, { passive: true })
  }

  /** Called by the on-screen joystick. Values in [-1, 1], y positive = up. */
  setTouchStick(x: number, y: number): void {
    this.touchStick.x = x
    this.touchStick.y = y
    this.method = 'touch'
  }

  releaseTouchStick(): void {
    this.touchStick.x = 0
    this.touchStick.y = 0
  }

  /** Called by the on-screen throttle slider. */
  setThrottle(value: number): void {
    this.throttle = Math.min(1, Math.max(0, value))
    this.method = 'touch'
  }

  private releaseAll(): void {
    this.held.clear()
    this.releaseTouchStick()
  }

  /** Sample keyboard and gamepad. Call once per rendered frame with the elapsed seconds. */
  update(frameSeconds: number): void {
    let x = this.touchStick.x
    let y = this.touchStick.y

    const h = this.held
    const kx = (h.has('ArrowRight') || h.has('KeyD') ? 1 : 0) - (h.has('ArrowLeft') || h.has('KeyA') ? 1 : 0)
    const ky = (h.has('ArrowUp') || h.has('KeyW') ? 1 : 0) - (h.has('ArrowDown') || h.has('KeyS') ? 1 : 0)
    x += kx
    y += ky
    const kt = (h.has('ShiftLeft') || h.has('ShiftRight') || h.has('KeyR') || h.has('PageUp') ? 1 : 0)
      - (h.has('ControlLeft') || h.has('ControlRight') || h.has('KeyF') || h.has('PageDown') ? 1 : 0)
    if (kt !== 0) this.throttle = Math.min(1, Math.max(0, this.throttle + kt * 0.6 * frameSeconds))

    const pad = this.readGamepad()
    if (pad) {
      const dz = (v: number) => (Math.abs(v) < 0.14 ? 0 : (v - Math.sign(v) * 0.14) / 0.86)
      const px = dz(pad.axes[0] ?? 0)
      const py = -dz(pad.axes[1] ?? 0)
      x += px
      y += py
      const rt = pad.buttons[7]?.value ?? 0
      const lt = pad.buttons[6]?.value ?? 0
      const dpad = (pad.buttons[12]?.pressed ? 1 : 0) - (pad.buttons[13]?.pressed ? 1 : 0)
      const delta = rt - lt + dpad
      if (Math.abs(delta) > 0.05) this.throttle = Math.min(1, Math.max(0, this.throttle + delta * 0.6 * frameSeconds))
      if (px !== 0 || py !== 0 || delta !== 0) this.method = 'gamepad'
      const start = pad.buttons[9]?.pressed ?? false
      if (start && !this.gamepadPause) this.pressed.add('pause')
      this.gamepadPause = start
      const a = pad.buttons[0]?.pressed ?? false
      if (a && !this.gamepadConfirm) this.pressed.add('confirm')
      this.gamepadConfirm = a
    }

    this.stick.x = Math.min(1, Math.max(-1, x))
    this.stick.y = Math.min(1, Math.max(-1, y))
  }

  private readGamepad(): Gamepad | null {
    const pads = typeof navigator.getGamepads === 'function' ? navigator.getGamepads() : []
    for (const pad of pads) if (pad && pad.connected) return pad
    return null
  }

  /** True once per press of `action`. */
  consume(action: Action): boolean {
    return this.pressed.delete(action)
  }

  clearActions(): void {
    this.pressed.clear()
  }

  dispose(): void {
    for (const fn of this.cleanup) fn()
    this.cleanup.length = 0
    void this.target
  }
}
