import {
  CrosswordQuestion,
  CrosswordWord,
  Direction,
  GridCell,
  GridPosition,
  Stage
} from '../types/crossword';
import { getWordInputSequence, normalizeArabicChar } from './normalization';

export class CrosswordEngine {
  private stage: Stage | null = null;
  private grid: GridCell[][] = [];
  private selectedPos: GridPosition | null = null;
  private activeDirection: Direction = 'horizontal';
  private selectedWordId: string | null = null;

  /**
   * Load a stage into the engine, restoring any saved answers.
   * Ensures the grid follows the strict rule:
   * 1. Every cell that is part of a horizontal or vertical word is a playable white cell.
   * 2. Every cell that does not belong to any word is a black square (isBlocked: true).
   * 3. No black squares ever cut inside any word.
   * 4. Clue start numbers are recalculated consistently based on grid scanning order.
   */
  public loadStage(stage: Stage, savedAnswers: { [cellKey: string]: string } = {}): void {
    this.stage = stage;
    const { rows, cols } = stage.gridSize;

    // 1. Initialize entire grid with black cells (isBlocked = true) by default
    this.grid = Array.from({ length: rows }, (_, r) =>
      Array.from({ length: cols }, (_, c) => ({
        row: r,
        col: c,
        isBlocked: true,
        userChar: savedAnswers[`${r}_${c}`] || '',
        status: 'unchecked',
      }))
    );

    // 2. Map all words onto the grid: any cell in a word becomes a white cell (isBlocked = false)
    for (const q of stage.questions) {
      const { startPos, direction, length, id } = q;

      for (let i = 0; i < length; i++) {
        const r = direction === 'vertical' ? startPos.row + i : startPos.row;
        const c = direction === 'horizontal' ? startPos.col + i : startPos.col;

        if (this.isValidCell(r, c)) {
          const cell = this.grid[r][c];
          cell.isBlocked = false; // Mark cell as white playable cell

          if (direction === 'horizontal') {
            cell.horizontalWordId = id;
          } else {
            cell.verticalWordId = id;
          }
        }
      }
    }

    // 3. Clue start numbers:
    // If the stage already provides specific numbers (such as golden layouts or custom numbered stages),
    // preserve those exact numbers and apply them to grid cells. Otherwise, calculate based on reading order.
    const hasPredefinedNumbers = stage.questions.every((q) => typeof q.number === 'number' && q.number > 0);

    if (hasPredefinedNumbers) {
      for (const q of stage.questions) {
        const cell = this.grid[q.startPos.row][q.startPos.col];
        if (cell) {
          cell.number = q.number;
        }
      }
    } else {
      let currentClueNumber = 1;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const cell = this.grid[r][c];
          if (cell.isBlocked) continue;

          let hasStart = false;

          // Check if a horizontal question starts at this cell
          const hQuestion = stage.questions.find(
            (q) => q.direction === 'horizontal' && q.startPos.row === r && q.startPos.col === c
          );
          if (hQuestion) {
            hQuestion.number = currentClueNumber;
            hasStart = true;
          }

          // Check if a vertical question starts at this cell
          const vQuestion = stage.questions.find(
            (q) => q.direction === 'vertical' && q.startPos.row === r && q.startPos.col === c
          );
          if (vQuestion) {
            vQuestion.number = currentClueNumber;
            hasStart = true;
          }

          if (hasStart) {
            cell.number = currentClueNumber;
            currentClueNumber++;
          }
        }
      }
    }

    // 4. Update stage.blockedCells to reflect all unused cells accurately
    const finalBlockedCells: GridPosition[] = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (this.grid[r][c].isBlocked) {
          finalBlockedCells.push({ row: r, col: c });
        }
      }
    }
    this.stage.blockedCells = finalBlockedCells;

    // 5. Select initial cell (first playable cell of word 1 or top-left playable)
    this.autoSelectInitialCell();
  }

  private autoSelectInitialCell(): void {
    if (!this.stage) return;
    
    // Find word with number 1 or first question
    const firstWord = this.stage.questions.find((q) => q.number === 1) || this.stage.questions[0];
    if (firstWord) {
      this.selectedPos = { ...firstWord.startPos };
      this.activeDirection = firstWord.direction;
      this.selectedWordId = firstWord.id;
    } else {
      // Fallback: first non-blocked cell
      for (let r = 0; r < this.grid.length; r++) {
        for (let c = 0; c < this.grid[r].length; c++) {
          if (!this.grid[r][c].isBlocked) {
            this.selectedPos = { row: r, col: c };
            this.updateActiveWord();
            return;
          }
        }
      }
    }
  }

  public getGrid(): GridCell[][] {
    return this.grid;
  }

  public getStage(): Stage | null {
    return this.stage;
  }

  public getSelectedPos(): GridPosition | null {
    return this.selectedPos;
  }

  public getSelectedPosition(): GridPosition | null {
    return this.selectedPos;
  }

  public getActiveDirection(): Direction {
    return this.activeDirection;
  }

  public getSelectedWordId(): string | null {
    return this.selectedWordId;
  }

  public getSelectedQuestion(): CrosswordQuestion | null {
    if (!this.stage || !this.selectedWordId) return null;
    return this.stage.questions.find((q) => q.id === this.selectedWordId) || null;
  }

  /**
   * Select a cell in the grid. Toggles direction if clicking the same cell that has both directions.
   */
  public selectCell(row: number, col: number, preferredDirection?: Direction): void {
    if (!this.isValidCell(row, col) || this.grid[row][col].isBlocked) return;

    const cell = this.grid[row][col];
    const isSameCell = this.selectedPos?.row === row && this.selectedPos?.col === col;

    if (preferredDirection) {
      this.activeDirection = preferredDirection;
    } else if (isSameCell) {
      // Toggle direction if cell supports both
      if (cell.horizontalWordId && cell.verticalWordId) {
        this.activeDirection = this.activeDirection === 'horizontal' ? 'vertical' : 'horizontal';
      }
    } else {
      // If cell only belongs to vertical word, switch direction to vertical
      if (cell.verticalWordId && !cell.horizontalWordId) {
        this.activeDirection = 'vertical';
      } else if (cell.horizontalWordId && !cell.verticalWordId) {
        this.activeDirection = 'horizontal';
      }
    }

    this.selectedPos = { row, col };
    this.updateActiveWord();
  }

  public setDirection(direction: Direction): void {
    this.activeDirection = direction;
    if (this.selectedPos) {
      const cell = this.grid[this.selectedPos.row]?.[this.selectedPos.col];
      if (cell) {
        const targetWordId = direction === 'horizontal' ? cell.horizontalWordId : cell.verticalWordId;
        if (targetWordId) {
          this.selectedWordId = targetWordId;
        } else {
          const firstQuestion = this.stage?.questions.find((q) => q.direction === direction);
          if (firstQuestion) {
            this.selectedPos = { ...firstQuestion.startPos };
            this.selectedWordId = firstQuestion.id;
          }
        }
      }
    } else {
      const firstQuestion = this.stage?.questions.find((q) => q.direction === direction);
      if (firstQuestion) {
        this.selectedPos = { ...firstQuestion.startPos };
        this.selectedWordId = firstQuestion.id;
      }
    }
  }

  public toggleDirection(): void {
    const newDir: Direction = this.activeDirection === 'horizontal' ? 'vertical' : 'horizontal';
    this.setDirection(newDir);
  }

  public skipToNextCell(): void {
    this.advanceCursor();
  }

  public selectQuestion(questionId: string): void {
    if (!this.stage) return;
    const question = this.stage.questions.find((q) => q.id === questionId);
    if (question) {
      this.selectedPos = { ...question.startPos };
      this.activeDirection = question.direction;
      this.selectedWordId = question.id;
    }
  }

  private updateActiveWord(): void {
    if (!this.selectedPos) return;
    const cell = this.grid[this.selectedPos.row]?.[this.selectedPos.col];
    if (!cell) return;

    if (this.activeDirection === 'horizontal') {
      this.selectedWordId = cell.horizontalWordId || cell.verticalWordId || null;
      if (!cell.horizontalWordId && cell.verticalWordId) {
        this.activeDirection = 'vertical';
      }
    } else {
      this.selectedWordId = cell.verticalWordId || cell.horizontalWordId || null;
      if (!cell.verticalWordId && cell.horizontalWordId) {
        this.activeDirection = 'horizontal';
      }
    }
  }

  /**
   * Input a single character at the current selected position and advance cursor.
   */
  public typeChar(char: string): void {
    if (!this.selectedPos) return;
    const norm = normalizeArabicChar(char);
    if (!norm) return;

    const { row, col } = this.selectedPos;
    const cell = this.grid[row][col];
    if (cell.isBlocked) return;

    cell.userChar = norm;
    cell.status = 'unchecked'; // Reset check indicator on modification

    this.advanceCursor();
  }

  /**
   * Delete character at current position or move back and delete.
   */
  public deleteChar(): void {
    if (!this.selectedPos) return;
    const { row, col } = this.selectedPos;
    const cell = this.grid[row][col];

    if (cell.userChar !== '') {
      cell.userChar = '';
      cell.status = 'unchecked';
    } else {
      // Move back to previous cell in current word and clear it
      this.retreatCursor();
      if (this.selectedPos) {
        const prevCell = this.grid[this.selectedPos.row][this.selectedPos.col];
        prevCell.userChar = '';
        prevCell.status = 'unchecked';
      }
    }
  }

  private advanceCursor(): void {
    if (!this.selectedPos || !this.selectedWordId || !this.stage) return;

    const question = this.stage.questions.find((q) => q.id === this.selectedWordId);
    if (!question) return;

    const { startPos, direction, length } = question;
    const stepRow = direction === 'vertical' ? 1 : 0;
    const stepCol = direction === 'horizontal' ? 1 : 0;

    // Calculate current index in word
    const currentIndex = direction === 'horizontal'
      ? this.selectedPos.col - startPos.col
      : this.selectedPos.row - startPos.row;

    if (currentIndex < length - 1) {
      const nextRow = startPos.row + (currentIndex + 1) * stepRow;
      const nextCol = startPos.col + (currentIndex + 1) * stepCol;
      if (this.isValidCell(nextRow, nextCol) && !this.grid[nextRow][nextCol].isBlocked) {
        this.selectedPos = { row: nextRow, col: nextCol };
      }
    }
  }

  private retreatCursor(): void {
    if (!this.selectedPos || !this.selectedWordId || !this.stage) return;

    const question = this.stage.questions.find((q) => q.id === this.selectedWordId);
    if (!question) return;

    const { startPos, direction } = question;
    const stepRow = direction === 'vertical' ? 1 : 0;
    const stepCol = direction === 'horizontal' ? 1 : 0;

    const currentIndex = direction === 'horizontal'
      ? this.selectedPos.col - startPos.col
      : this.selectedPos.row - startPos.row;

    if (currentIndex > 0) {
      const prevRow = startPos.row + (currentIndex - 1) * stepRow;
      const prevCol = startPos.col + (currentIndex - 1) * stepCol;
      if (this.isValidCell(prevRow, prevCol) && !this.grid[prevRow][prevCol].isBlocked) {
        this.selectedPos = { row: prevRow, col: prevCol };
      }
    }
  }

  /**
   * Helper to derive expected normalized target character for a cell position.
   */
  public getTargetCharForCell(row: number, col: number): string | null {
    if (!this.stage || this.grid[row][col].isBlocked) return null;

    const cell = this.grid[row][col];
    const wordId = cell.horizontalWordId || cell.verticalWordId;
    if (!wordId) return null;

    const question = this.stage.questions.find((q) => q.id === wordId);
    if (!question) return null;

    const inputSequence = getWordInputSequence(question.answer, question.reversed);
    const index = question.direction === 'horizontal'
      ? col - question.startPos.col
      : row - question.startPos.row;

    return inputSequence[index] || null;
  }

  /**
   * Check all user answers against authoritative target answers.
   */
  public checkAnswers(): { correctCount: number; totalCount: number } {
    let correctCount = 0;
    let totalCount = 0;

    for (let r = 0; r < this.grid.length; r++) {
      for (let c = 0; c < this.grid[r].length; c++) {
        const cell = this.grid[r][c];
        if (cell.isBlocked) continue;

        const target = this.getTargetCharForCell(r, c);
        if (target) {
          totalCount++;
          if (cell.userChar === '') {
            cell.status = 'unchecked';
          } else if (normalizeArabicChar(cell.userChar) === target) {
            cell.status = 'correct';
          } else {
            cell.status = 'incorrect';
          }
        }
      }
    }

    return { correctCount, totalCount };
  }

  /**
   * Check only the currently selected word/question against authoritative target answers.
   */
  public checkCurrentWord(): {
    wordNumber?: number;
    wordDirection?: Direction;
    isWordCorrect: boolean;
    correctCount: number;
    incorrectCount: number;
    emptyCount: number;
    totalLetters: number;
  } | null {
    const question = this.getSelectedQuestion();
    if (!question) return null;

    const inputSeq = getWordInputSequence(question.answer, question.reversed);
    let correctCount = 0;
    let incorrectCount = 0;
    let emptyCount = 0;

    for (let i = 0; i < question.length; i++) {
      const r = question.direction === 'vertical' ? question.startPos.row + i : question.startPos.row;
      const c = question.direction === 'horizontal' ? question.startPos.col + i : question.startPos.col;
      const cell = this.grid[r][c];

      const expectedChar = inputSeq[i];
      if (cell.userChar === '') {
        emptyCount++;
        cell.status = 'unchecked';
      } else if (normalizeArabicChar(cell.userChar) === expectedChar) {
        correctCount++;
        cell.status = 'correct';
      } else {
        incorrectCount++;
        cell.status = 'incorrect';
      }
    }

    const isWordCorrect = correctCount === question.length;

    return {
      wordNumber: question.number,
      wordDirection: question.direction,
      isWordCorrect,
      correctCount,
      incorrectCount,
      emptyCount,
      totalLetters: question.length,
    };
  }

  /**
   * Check if stage is 100% completed correctly.
   */
  public isStageComplete(): boolean {
    if (!this.stage) return false;

    for (let r = 0; r < this.grid.length; r++) {
      for (let c = 0; c < this.grid[r].length; c++) {
        const cell = this.grid[r][c];
        if (cell.isBlocked) continue;

        const target = this.getTargetCharForCell(r, c);
        if (target) {
          if (!cell.userChar || normalizeArabicChar(cell.userChar) !== target) {
            return false;
          }
        }
      }
    }

    return true;
  }

  public isStageCompleted(): boolean {
    return this.isStageComplete();
  }

  /**
   * Get list of completed question IDs for progress tracking.
   */
  public getCompletedQuestionIds(): string[] {
    if (!this.stage) return [];
    const completedIds: string[] = [];

    for (const q of this.stage.questions) {
      const inputSeq = getWordInputSequence(q.answer, q.reversed);
      let isComplete = true;

      for (let i = 0; i < q.length; i++) {
        const r = q.direction === 'vertical' ? q.startPos.row + i : q.startPos.row;
        const c = q.direction === 'horizontal' ? q.startPos.col + i : q.startPos.col;
        const userChar = normalizeArabicChar(this.grid[r]?.[c]?.userChar || '');

        if (!userChar || userChar !== inputSeq[i]) {
          isComplete = false;
          break;
        }
      }

      if (isComplete) {
        completedIds.push(q.id);
      }
    }

    return completedIds;
  }

  /**
   * Check if a specific question/word is already 100% correctly completed.
   */
  public isQuestionCompleted(questionId: string): boolean {
    if (!this.stage) return false;
    const q = this.stage.questions.find((item) => item.id === questionId);
    if (!q) return false;

    const inputSeq = getWordInputSequence(q.answer, q.reversed);
    for (let i = 0; i < q.length; i++) {
      const r = q.direction === 'vertical' ? q.startPos.row + i : q.startPos.row;
      const c = q.direction === 'horizontal' ? q.startPos.col + i : q.startPos.col;
      const userChar = normalizeArabicChar(this.grid[r]?.[c]?.userChar || '');
      if (!userChar || userChar !== inputSeq[i]) {
        return false;
      }
    }
    return true;
  }

  /**
   * Reveal an entire specific word chosen by the player (Hint Action).
   * Fully populates the word's cells with target characters and marks them correct.
   */
  public revealWord(questionId: string): boolean {
    if (!this.stage) return false;
    const q = this.stage.questions.find((item) => item.id === questionId);
    if (!q) return false;

    const inputSeq = getWordInputSequence(q.answer, q.reversed);
    for (let i = 0; i < q.length; i++) {
      const r = q.direction === 'vertical' ? q.startPos.row + i : q.startPos.row;
      const c = q.direction === 'horizontal' ? q.startPos.col + i : q.startPos.col;
      const cell = this.grid[r]?.[c];
      if (cell && !cell.isBlocked) {
        cell.userChar = inputSeq[i];
        cell.status = 'correct';
      }
    }
    return true;
  }

  /**
   * Reveal full solution for this stage.
   */
  public fillSolution(): void {
    if (!this.stage) return;
    for (let r = 0; r < this.grid.length; r++) {
      for (let c = 0; c < this.grid[r].length; c++) {
        const cell = this.grid[r][c];
        if (cell.isBlocked) continue;

        const target = this.getTargetCharForCell(r, c);
        if (target) {
          cell.userChar = target;
          cell.status = 'correct';
        }
      }
    }
  }

  /**
   * Reset current stage progress.
   */
  public resetStage(): void {
    for (let r = 0; r < this.grid.length; r++) {
      for (let c = 0; c < this.grid[r].length; c++) {
        this.grid[r][c].userChar = '';
        this.grid[r][c].status = 'unchecked';
      }
    }
  }

  /**
   * Export key-value answers for persistence.
   */
  public exportUserAnswers(): { [cellKey: string]: string } {
    const answers: { [cellKey: string]: string } = {};
    for (let r = 0; r < this.grid.length; r++) {
      for (let c = 0; c < this.grid[r].length; c++) {
        if (this.grid[r][c].userChar) {
          answers[`${r}_${c}`] = this.grid[r][c].userChar;
        }
      }
    }
    return answers;
  }

  public getUserAnswers(): { [cellKey: string]: string } {
    return this.exportUserAnswers();
  }

  private isValidCell(row: number, col: number): boolean {
    return row >= 0 && row < this.grid.length && col >= 0 && col < this.grid[0].length;
  }
}
