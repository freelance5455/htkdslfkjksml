import test from 'node:test';
import assert from 'node:assert/strict';
import {
  evaluateFormula,
  detectCircularDependencies,
  validateFormulaSyntaxAndReferences,
} from './formulaParser';
import {
  calculatePersonLoanSummary,
  calculateOverallLoanTotals,
  validateRepaymentAmount,
  calculateCommitteeSummary,
  calculateOverallCommitteeTotals,
  evaluateRecordValues,
  computeDashboardCardValue,
  runDynamicReport,
  toCsvString,
} from './calculations';
import { createZipArchive } from './zipBuilder';
import type {
  Committee,
  CommitteeTransaction,
  CustomModule,
  CustomRecord,
  CustomReportConfig,
  CustomSubmodule,
  DashboardCardConfig,
  FieldDefinition,
  FieldMapping,
  FormulaDefinition,
  LoanPerson,
  LoanTransaction,
} from '../types/app';

test('Formula Parser: arithmetic, Quantity * Rate, functions, IF, percentage', () => {
  const res1 = evaluateFormula('Quantity * Rate', { Quantity: 10, Rate: 500 });
  assert.equal(res1.ok, true);
  assert.equal(res1.value, 5000);

  const res2 = evaluateFormula('SUM(10, 20, 30) + AVERAGE(10, 20)', {});
  assert.equal(res2.ok, true);
  assert.equal(res2.value, 75);

  const res3 = evaluateFormula('IF(Amount >= 1000, Amount * 10%, 0)', { Amount: 2000 });
  assert.equal(res3.ok, true);
  assert.equal(res3.value, 200);

  const res4 = evaluateFormula('MIN(5, 2, 9) + MAX(1, 8)', {});
  assert.equal(res4.ok, true);
  assert.equal(res4.value, 10);
});

test('Formula Parser: prevents division by zero and unknown references', () => {
  const divZero = evaluateFormula('Total / Count', { Total: 100, Count: 0 });
  assert.equal(divZero.ok, false);
  assert.match(divZero.error || '', /Division by zero/i);

  const badRef = validateFormulaSyntaxAndReferences('[Quantity] * [MissingField]', ['Quantity', 'Rate']);
  assert.equal(badRef.valid, false);
  assert.deepEqual(badRef.missingFields, ['MissingField']);
});

test('Circular dependency detection catches direct and indirect loops', () => {
  const cycle = detectCircularDependencies({
    A: ['B'],
    B: ['C'],
    C: ['A'],
  });
  assert.equal(cycle.hasCycle, true);
  assert.equal(cycle.cyclePath[0], 'A');

  const acyclic = detectCircularDependencies({
    Total: ['Quantity', 'Rate'],
    Quantity: [],
    Rate: [],
  });
  assert.equal(acyclic.hasCycle, false);
});

test('Loan calculations: opening balance, received, partial repayment, overpayment guard', () => {
  const person: LoanPerson = {
    id: 'p1',
    name: 'Ahmed',
    contactNumber: '03001234567',
    openingBalance: 5000,
    remarks: '',
    archived: false,
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  };
  const txs: LoanTransaction[] = [
    {
      id: 't1',
      personId: 'p1',
      type: 'received',
      amount: 10000,
      date: '2026-01-05',
      description: 'Second loan',
      remarks: '',
      createdAt: '2026-01-05',
      updatedAt: '2026-01-05',
    },
    {
      id: 't2',
      personId: 'p1',
      type: 'repayment',
      amount: 3500,
      date: '2026-01-10',
      description: 'Partial payment',
      paymentMethod: 'Cash',
      transactionRef: 'REF-1',
      remarks: '',
      createdAt: '2026-01-10',
      updatedAt: '2026-01-10',
    },
  ];

  const summary = calculatePersonLoanSummary(person, txs);
  assert.equal(summary.openingBalance, 5000);
  assert.equal(summary.totalReceived, 10000);
  assert.equal(summary.totalRepaid, 3500);
  assert.equal(summary.closingPayable, 11500);

  const overpayBlocked = validateRepaymentAmount(summary.closingPayable, 12000, false);
  assert.equal(overpayBlocked.valid, false);
  const overpayAllowed = validateRepaymentAmount(summary.closingPayable, 12000, true);
  assert.equal(overpayAllowed.valid, true);
});

test('Committee calculations remain strictly separate from Loan Payable', () => {
  const persons: LoanPerson[] = [
    { id: 'p1', name: 'Bilal', contactNumber: '', openingBalance: 1000, remarks: '', archived: false, createdAt: '', updatedAt: '' },
  ];
  const loanTxs: LoanTransaction[] = [];
  const committee: Committee = {
    id: 'c1',
    name: 'Monthly Gold Committee',
    personName: 'Bilal',
    openingBalance: 0,
    totalCommitteeAmount: 100000,
    installmentAmount: 10000,
    startDate: '2026-01-01',
    endDate: '2026-10-01',
    paymentFrequency: 'Monthly',
    remarks: '',
    archived: false,
    createdAt: '',
    updatedAt: '',
  };
  const commTxs: CommitteeTransaction[] = [
    { id: 'ct1', committeeId: 'c1', personName: 'Bilal', type: 'installment', amount: 10000, date: '2026-01-01', remarks: '', createdAt: '', updatedAt: '' },
    { id: 'ct2', committeeId: 'c1', personName: 'Bilal', type: 'installment', amount: 10000, date: '2026-02-01', remarks: '', createdAt: '', updatedAt: '' },
    { id: 'ct3', committeeId: 'c1', personName: 'Bilal', type: 'payout', amount: 5000, date: '2026-02-15', remarks: '', createdAt: '', updatedAt: '' },
  ];

  const commSummary = calculateCommitteeSummary(committee, commTxs);
  assert.equal(commSummary.totalInstallmentsPaid, 20000);
  assert.equal(commSummary.totalPayouts, 5000);
  assert.equal(commSummary.totalReceivable, 15000);
  assert.equal(commSummary.closingBalance, 15000);

  const loanTotals = calculateOverallLoanTotals(persons, loanTxs);
  assert.equal(loanTotals.remainingPayable, 1000); // Unaffected by committee transactions

  const commTotals = calculateOverallCommitteeTotals([committee], commTxs);
  assert.equal(commTotals.totalReceivable, 15000);
});

test('Dynamic record formula + field mapping + dashboard SUM card + CSV', () => {
  const modules: CustomModule[] = [
    { id: 'm1', name: 'Inventory', description: '', icon: 'Package', color: '#059669', position: 0, visible: true, archived: false, status: 'published', createdAt: '', updatedAt: '' },
  ];
  const submodules: CustomSubmodule[] = [
    { id: 's1', moduleId: 'm1', name: 'Purchases', icon: 'FileText', color: '#059669', position: 0, visible: true, archived: false, status: 'published', createdAt: '', updatedAt: '' },
  ];
  const fields: FieldDefinition[] = [
    { id: 'f1', moduleId: 'm1', submoduleId: 's1', name: 'Quantity', label: 'Quantity', type: 'number', placeholder: '', defaultValue: '0', required: true, editable: true, visible: true, position: 0, decimalPlaces: 0, dropdownOptions: [], color: '#0B1F3A', status: 'published', createdAt: '', updatedAt: '' },
    { id: 'f2', moduleId: 'm1', submoduleId: 's1', name: 'Rate', label: 'Rate', type: 'currency', placeholder: '', defaultValue: '0', required: true, editable: true, visible: true, position: 1, decimalPlaces: 2, dropdownOptions: [], color: '#0B1F3A', status: 'published', createdAt: '', updatedAt: '' },
    { id: 'f3', moduleId: 'm1', submoduleId: 's1', name: 'TotalAmount', label: 'Total Amount', type: 'formula', placeholder: '', defaultValue: '0', required: false, editable: false, visible: true, position: 2, decimalPlaces: 2, dropdownOptions: [], color: '#059669', formulaExpression: 'Quantity * Rate', status: 'published', createdAt: '', updatedAt: '' },
  ];
  const formulas: FormulaDefinition[] = [
    { id: 'fm1', name: 'Total Amount', moduleId: 'm1', submoduleId: 's1', targetFieldId: 'f3', expression: 'Quantity * Rate', decimalPlaces: 2, status: 'published', createdAt: '', updatedAt: '' },
  ];
  const mappings: FieldMapping[] = [];

  const evaluated = evaluateRecordValues({
    submoduleId: 's1',
    rawValues: { Quantity: 10, Rate: 500 },
    fields,
    formulas,
    mappings,
    allRecords: [],
    modules,
    submodules,
  });

  assert.equal(evaluated.values.TotalAmount, 5000);
  assert.deepEqual(evaluated.errors, {});

  const records: CustomRecord[] = [
    { id: 'r1', moduleId: 'm1', submoduleId: 's1', values: evaluated.values, archived: false, createdAt: '2026-03-01T00:00:00Z', updatedAt: '2026-03-01T00:00:00Z' },
    { id: 'r2', moduleId: 'm1', submoduleId: 's1', values: { Quantity: 5, Rate: 200, TotalAmount: 1000 }, archived: false, createdAt: '2026-03-02T00:00:00Z', updatedAt: '2026-03-02T00:00:00Z' },
  ];

  const card: DashboardCardConfig = {
    id: 'dc1',
    title: 'Inventory Spend',
    sourceType: 'custom',
    moduleId: 'm1',
    submoduleId: 's1',
    fieldId: 'f3',
    calculation: 'sum',
    color: '#059669',
    icon: 'Wallet',
    position: 4,
    visible: true,
    status: 'published',
    createdAt: '',
    updatedAt: '',
  };

  const cardRes = computeDashboardCardValue({
    card,
    loanPersons: [],
    loanTransactions: [],
    committees: [],
    committeeTransactions: [],
    customRecords: records,
    fields,
  });
  assert.equal(cardRes.value, 6000);

  const reportCfg: CustomReportConfig = {
    id: 'rep1',
    name: 'Inventory Report',
    sourceType: 'custom',
    moduleId: 'm1',
    submoduleId: 's1',
    fieldIds: ['f1', 'f2', 'f3'],
    filters: [],
    sortDir: 'asc',
    calculation: 'sum',
    status: 'published',
    createdAt: '',
    updatedAt: '',
  };
  const reportOut = runDynamicReport({
    report: reportCfg,
    loanPersons: [],
    loanTransactions: [],
    committees: [],
    committeeTransactions: [],
    customRecords: records,
    fields,
  });
  assert.equal(reportOut.rows.length, 2);
  const csv = toCsvString(reportOut.columns, reportOut.rows);
  assert.match(csv, /Quantity,Rate,Total Amount/);
  assert.match(csv, /10,500,5000/);

  const zipBytes = createZipArchive([{ name: 'report.csv', content: csv }]);
  assert.equal(zipBytes[0], 0x50); // 'P'
  assert.equal(zipBytes[1], 0x4b); // 'K'
});
