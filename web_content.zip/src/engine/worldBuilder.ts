import * as THREE from 'three';
import { ProceduralTextureSet } from './textures';
import { KARACHI_PLACES } from '../data/karachiWorldData';

export interface BoxCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
}

export interface WorldRefs {
  colliders: BoxCollider[];
  oceanMesh: THREE.Mesh;
  oceanMaterial: THREE.MeshPhysicalMaterial;
  oceanUniforms: { uTime: { value: number } };
  sunDisc: THREE.Mesh;
  roadMaterial: THREE.MeshStandardMaterial;
  modernBuildingMat: THREE.MeshStandardMaterial;
  streetLightBulbs: THREE.MeshBasicMaterial;
  placeBeacons: Map<string, THREE.Mesh>;
  roadGraphNodes: { x: number; z: number }[];
}

export const WATER_LINE_Z = 365;
export const BEACH_START_Z = 330;
export const PORT_PIER_BOUNDS = { minX: -620, maxX: -430, minZ: 318, maxZ: 405 };

export function isWaterAt(x: number, z: number): boolean {
  if (
    x >= PORT_PIER_BOUNDS.minX &&
    x <= PORT_PIER_BOUNDS.maxX &&
    z >= PORT_PIER_BOUNDS.minZ &&
    z <= PORT_PIER_BOUNDS.maxZ
  ) {
    return false;
  }
  return z > WATER_LINE_Z;
}

export function groundHeightAt(x: number, z: number): number {
  if (
    x >= PORT_PIER_BOUNDS.minX &&
    x <= PORT_PIER_BOUNDS.maxX &&
    z >= PORT_PIER_BOUNDS.minZ &&
    z <= PORT_PIER_BOUNDS.maxZ
  ) {
    return 0.65;
  }
  if (z > BEACH_START_Z && z <= WATER_LINE_Z) {
    const t = (z - BEACH_START_Z) / (WATER_LINE_Z - BEACH_START_Z);
    return -t * 0.45;
  }
  if (z > WATER_LINE_Z) {
    return -0.6;
  }
  return 0;
}

export function buildKarachiWorld(
  scene: THREE.Scene,
  textures: ProceduralTextureSet,
  isSoftwareGl: boolean
): WorldRefs {
  const colliders: BoxCollider[] = [];

  // 1. Massive Ground Plane (2600 x 1800) so horizon blends into atmospheric fog
  const groundMat = new THREE.MeshStandardMaterial({
    map: textures.sidewalkTile,
    color: '#94a3b8',
    roughness: 0.9,
    metalness: 0.05,
  });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(2600, 1800), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.set(0, -0.02, -550);
  ground.receiveShadow = true;
  scene.add(ground);

  // Sea View Golden Sand Beach Strip
  const beachMat = new THREE.MeshStandardMaterial({
    map: textures.sandTexture,
    roughness: 0.95,
    metalness: 0.0,
  });
  const beach = new THREE.Mesh(new THREE.PlaneGeometry(2600, 68), beachMat);
  beach.rotation.x = -Math.PI / 2 + 0.015;
  beach.position.set(0, -0.18, 355);
  beach.receiveShadow = true;
  scene.add(beach);

  // Arabian Sea Ocean Plane with 3D Animated Waves & Shoreline Foam
  const oceanUniforms = { uTime: { value: 0 } };
  const oceanMaterial = new THREE.MeshPhysicalMaterial({
    color: '#0284c7',
    roughness: 0.1,
    metalness: 0.18,
    clearcoat: isSoftwareGl ? 0.25 : 0.95,
    clearcoatRoughness: 0.08,
    normalMap: textures.waterNormal,
    normalScale: new THREE.Vector2(0.75, 0.75),
  });
  oceanMaterial.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = oceanUniforms.uTime;
    shader.vertexShader =
      `uniform float uTime;\nvarying vec3 vWorldPos;\n` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         vec4 wPos = modelMatrix * vec4(transformed, 1.0);
         float wave1 = sin(wPos.x * 0.08 + uTime * 1.6) * 0.18;
         float wave2 = cos(wPos.z * 0.11 - uTime * 1.25) * 0.14;
         transformed.z += wave1 + wave2;
         vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`
      );
    shader.fragmentShader =
      `uniform float uTime;\nvarying vec3 vWorldPos;\n` +
      shader.fragmentShader.replace(
        '#include <color_fragment>',
        `#include <color_fragment>
         float shoreDist = max(0.0, vWorldPos.z - 362.0);
         float shallowMix = exp(-shoreDist * 0.055);
         vec3 deepColor = vec3(0.01, 0.26, 0.45);
         vec3 shallowColor = vec3(0.06, 0.62, 0.72);
         diffuseColor.rgb = mix(deepColor, shallowColor, shallowMix);
         float foamBand = sin(shoreDist * 1.15 - uTime * 2.2) * 0.5 + 0.5;
         float foam = smoothstep(0.65, 0.96, foamBand) * exp(-shoreDist * 0.14);
         diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.92, 0.97, 1.0), foam * 0.72);`
      );
  };
  const oceanMesh = new THREE.Mesh(new THREE.PlaneGeometry(2800, 1400, 72, 48), oceanMaterial);
  oceanMesh.rotation.x = -Math.PI / 2;
  oceanMesh.position.set(0, -0.32, 1062);
  oceanMesh.receiveShadow = true;
  scene.add(oceanMesh);

  // Celestial Sun/Moon Disc
  const sunDisc = new THREE.Mesh(
    new THREE.SphereGeometry(20, 20, 20),
    new THREE.MeshBasicMaterial({ color: '#fde047', fog: false })
  );
  scene.add(sunDisc);

  // 2. Massive Connected Karachi Road Grid (1,400m x 920m network!)
  const roadMaterial = new THREE.MeshStandardMaterial({
    map: textures.roadAsphalt,
    roughness: 0.72,
    metalness: 0.08,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });

  const addRoadSegment = (x1: number, z1: number, x2: number, z2: number, width: number) => {
    const dx = x2 - x1;
    const dz = z2 - z1;
    const len = Math.hypot(dx, dz);
    const angle = Math.atan2(dx, dz);
    const tex = textures.roadAsphalt.clone();
    tex.needsUpdate = true;
    tex.repeat.set(1, Math.max(1, Math.round(len / 24)));
    const mat = roadMaterial.clone();
    mat.map = tex;

    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, len), mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.rotation.z = -angle;
    mesh.position.set((x1 + x2) / 2, 0.03, (z1 + z2) / 2);
    mesh.receiveShadow = true;
    scene.add(mesh);
  };

  // East-West Highways & Expressways (1,400m span: -700 to +700)
  addRoadSegment(-700, -560, 700, -560, 20); // North Nazimabad / Super Highway Link
  addRoadSegment(-700, -420, 700, -420, 20); // Gulshan / Johar Expressway
  addRoadSegment(-700, -280, 700, -280, 22); // University Road Corridor
  addRoadSegment(-700, -140, 700, -140, 20); // Mazar-e-Quaid / Tariq Rd / Lyari Avenue
  addRoadSegment(-700, 0, 700, 0, 28); // SHAHRAH-E-FAISAL (6-Lane Grand Boulevard)
  addRoadSegment(-700, 120, 700, 120, 20); // Burns Road / Saddar / Korangi Link
  addRoadSegment(-700, 225, 700, 225, 22); // Clifton / DHA Boulevard
  addRoadSegment(-640, 320, 680, 320, 20); // Sea View Promenade / Port Highway

  // North-South Highways & Expressways (925m span: -600 to +325)
  addRoadSegment(-560, -600, -560, 325, 20); // Karachi Port / Hawksbay Spine
  addRoadSegment(-380, -600, -380, 325, 20); // Lyari / Mauripur Expressway
  addRoadSegment(-190, -600, -190, 325, 22); // Saddar / II Chundrigar Financial Axis
  addRoadSegment(0, -600, 0, 328, 24); // Central Spine: Mazar-e-Quaid – Teen Talwar – Sea View
  addRoadSegment(190, -600, 190, 325, 20); // Tariq Road – Clifton East – DHA Axis
  addRoadSegment(380, -600, 380, 325, 20); // Gulshan – Korangi Expressway
  addRoadSegment(560, -600, 560, 325, 20); // Malir / DHA Phase 8 East Highway

  // Roundabouts across the mega city
  const addRoundabout = (cx: number, cz: number, radius: number) => {
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(radius * 0.45, radius, 32),
      roadMaterial
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(cx, 0.04, cz);
    ring.receiveShadow = true;
    scene.add(ring);

    const island = new THREE.Mesh(
      new THREE.CylinderGeometry(radius * 0.44, radius * 0.46, 0.35, 28),
      new THREE.MeshStandardMaterial({ color: '#15803d', roughness: 0.9 })
    );
    island.position.set(cx, 0.175, cz);
    island.receiveShadow = true;
    scene.add(island);
  };
  addRoundabout(0, 225, 24); // Teen Talwar Clifton
  addRoundabout(-190, 120, 20); // Saddar / Burns Road Circle
  addRoundabout(190, -140, 20); // Tariq Road / Nursery Circle
  addRoundabout(380, -280, 22); // Gulshan Chowrangi

  // 3. Shared Building Materials
  const modernBuildingMat = new THREE.MeshStandardMaterial({
    map: textures.buildingModern,
    emissiveMap: textures.buildingModernEmissive,
    emissive: new THREE.Color('#fde68a'),
    emissiveIntensity: 0.25,
    roughness: 0.32,
    metalness: 0.48,
  });

  const heritageMat = new THREE.MeshStandardMaterial({
    map: textures.buildingHeritage,
    roughness: 0.8,
    metalness: 0.05,
  });

  const bazaarMat = new THREE.MeshStandardMaterial({
    map: textures.buildingBazaar,
    roughness: 0.78,
    metalness: 0.08,
  });

  const addHeroBuilding = (
    x: number,
    z: number,
    w: number,
    h: number,
    d: number,
    mat: THREE.Material,
    tintHex?: string,
    roofAccent = true
  ) => {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    const m = tintHex ? (mat as THREE.MeshStandardMaterial).clone() : mat;
    if (tintHex && m instanceof THREE.MeshStandardMaterial) {
      m.color.set(tintHex);
    }
    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    body.position.y = h / 2;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    if (roofAccent) {
      const parapet = new THREE.Mesh(
        new THREE.BoxGeometry(w + 0.6, 0.7, d + 0.6),
        new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.7 })
      );
      parapet.position.y = h + 0.35;
      group.add(parapet);
    }
    scene.add(group);
    colliders.push({
      minX: x - w / 2,
      maxX: x + w / 2,
      minZ: z - d / 2,
      maxZ: z + d / 2,
      height: h,
    });
  };

  // 4. ICONIC KARACHI LANDMARKS

  // A) MAZAR-E-QUAID (0, -140)
  {
    const mazar = new THREE.Group();
    mazar.position.set(0, 0, -140);
    const marbleMat = new THREE.MeshPhysicalMaterial({
      color: '#f8fafc',
      roughness: 0.25,
      metalness: 0.08,
      clearcoat: 0.4,
    });
    const trimMat = new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.5 });

    const base1 = new THREE.Mesh(new THREE.BoxGeometry(44, 1.4, 44), marbleMat);
    base1.position.y = 0.7;
    base1.receiveShadow = true;
    mazar.add(base1);

    const base2 = new THREE.Mesh(new THREE.BoxGeometry(34, 1.8, 34), marbleMat);
    base2.position.y = 2.3;
    base2.receiveShadow = true;
    mazar.add(base2);

    const chamber = new THREE.Mesh(new THREE.BoxGeometry(19, 13.5, 19), marbleMat);
    chamber.position.y = 9.9;
    chamber.castShadow = true;
    chamber.receiveShadow = true;
    mazar.add(chamber);

    [
      [0, 9.5, 9.6, 0],
      [0, 9.5, -9.6, Math.PI],
      [9.6, 9.5, 0, Math.PI / 2],
      [-9.6, 9.5, 0, -Math.PI / 2],
    ].forEach(([ax, ay, az, ry]) => {
      const arch = new THREE.Mesh(new THREE.BoxGeometry(6.4, 9, 0.4), trimMat);
      arch.position.set(ax, ay, az);
      arch.rotation.y = ry;
      mazar.add(arch);
    });

    const drum = new THREE.Mesh(new THREE.CylinderGeometry(7.5, 8.0, 3.0, 24), marbleMat);
    drum.position.y = 18.0;
    mazar.add(drum);

    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(7.8, 28, 20, 0, Math.PI * 2, 0, Math.PI * 0.56),
      marbleMat
    );
    dome.position.y = 19.2;
    dome.castShadow = true;
    mazar.add(dome);

    const spire = new THREE.Mesh(
      new THREE.CylinderGeometry(0.15, 0.35, 3.5, 10),
      new THREE.MeshStandardMaterial({ color: '#eab308', metalness: 0.9, roughness: 0.2 })
    );
    spire.position.y = 28.2;
    mazar.add(spire);

    scene.add(mazar);
    colliders.push({ minX: -12, maxX: 12, minZ: -152, maxZ: -128, height: 29 });
  }

  // B) TEEN TALWAR - Clifton Roundabout (0, 225)
  {
    const teenTalwar = new THREE.Group();
    teenTalwar.position.set(0, 0.35, 225);
    const swordMat = new THREE.MeshPhysicalMaterial({
      color: '#f1f5f9',
      roughness: 0.2,
      metalness: 0.15,
      clearcoat: 0.6,
    });
    const goldMat = new THREE.MeshStandardMaterial({ color: '#eab308', metalness: 0.85, roughness: 0.2 });

    for (let i = 0; i < 3; i++) {
      const ang = (i * Math.PI * 2) / 3;
      const bladePivot = new THREE.Group();
      bladePivot.rotation.y = ang;
      const blade = new THREE.Mesh(new THREE.BoxGeometry(1.2, 16, 0.4), swordMat);
      blade.position.set(0, 8.0, 2.4);
      blade.rotation.x = -0.16;
      blade.castShadow = true;
      bladePivot.add(blade);

      const hilt = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.5, 0.6), goldMat);
      hilt.position.set(0, 2.6, 3.1);
      bladePivot.add(hilt);
      teenTalwar.add(bladePivot);
    }
    scene.add(teenTalwar);
    colliders.push({ minX: -5, maxX: 5, minZ: 220, maxZ: 230, height: 16 });
  }

  // C) EMPRESS MARKET - Saddar (-218, 28)
  {
    const empress = new THREE.Group();
    empress.position.set(-218, 0, 28);
    const hall = new THREE.Mesh(new THREE.BoxGeometry(28, 10.5, 19), heritageMat);
    hall.position.y = 5.25;
    hall.castShadow = true;
    hall.receiveShadow = true;
    empress.add(hall);

    const tower = new THREE.Mesh(new THREE.BoxGeometry(6.8, 26, 6.8), heritageMat);
    tower.position.set(0, 13, 0);
    tower.castShadow = true;
    empress.add(tower);

    const clockFace = new THREE.Mesh(
      new THREE.CircleGeometry(1.9, 20),
      new THREE.MeshBasicMaterial({ color: '#fef3c7' })
    );
    clockFace.position.set(3.5, 21, 0);
    clockFace.rotation.y = Math.PI / 2;
    empress.add(clockFace);

    const spire = new THREE.Mesh(
      new THREE.ConeGeometry(4.6, 6.5, 4),
      new THREE.MeshStandardMaterial({ color: '#991b1b', roughness: 0.6 })
    );
    spire.position.set(0, 29, 0);
    spire.rotation.y = Math.PI / 4;
    empress.add(spire);
    scene.add(empress);
    colliders.push({ minX: -232, maxX: -204, minZ: 18.5, maxZ: 37.5, height: 30 });
  }

  // D) SHAHRAH-E-FAISAL HIGHWAY GANTRIES (Multiple gantries along the 1.4km corridor)
  [-120, 32, 260].forEach((gx) => {
    const gantry = new THREE.Group();
    gantry.position.set(gx, 0, 0);
    const steelMat = new THREE.MeshStandardMaterial({ color: '#475569', metalness: 0.7, roughness: 0.3 });
    [-14.5, 14.5].forEach((gz) => {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.95, 9, 0.95), steelMat);
      leg.position.set(0, 4.5, gz);
      gantry.add(leg);
    });
    const beam = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.3, 30), steelMat);
    beam.position.set(0, 8.6, 0);
    gantry.add(beam);
    const signBoard = new THREE.Mesh(
      new THREE.BoxGeometry(0.4, 2.6, 18),
      new THREE.MeshStandardMaterial({ color: '#15803d', emissive: '#065f46', emissiveIntensity: 0.35 })
    );
    signBoard.position.set(-0.4, 8.6, 0);
    gantry.add(signBoard);
    scene.add(gantry);
  });

  // E) BURNS ROAD FOOD STREET ARCH & STALLS (-250, 120..165)
  {
    const archMat = new THREE.MeshStandardMaterial({
      color: '#dc2626',
      emissive: '#991b1b',
      emissiveIntensity: 0.4,
      roughness: 0.4,
    });
    const pillarL = new THREE.Mesh(new THREE.BoxGeometry(1.2, 6.5, 1.2), archMat);
    pillarL.position.set(-259, 3.25, 132);
    scene.add(pillarL);
    const pillarR = new THREE.Mesh(new THREE.BoxGeometry(1.2, 6.5, 1.2), archMat);
    pillarR.position.set(-241, 3.25, 132);
    scene.add(pillarR);
    const archTop = new THREE.Mesh(new THREE.BoxGeometry(19.5, 1.6, 1.4), archMat);
    archTop.position.set(-250, 6.8, 132);
    scene.add(archTop);

    [-267, -233].forEach((sx) => {
      for (let sz = 144; sz <= 180; sz += 12) {
        const stall = new THREE.Mesh(
          new THREE.BoxGeometry(4.2, 2.8, 5.2),
          new THREE.MeshStandardMaterial({ color: '#f59e0b', roughness: 0.7 })
        );
        stall.position.set(sx, 1.4, sz);
        stall.castShadow = true;
        scene.add(stall);
        const awning = new THREE.Mesh(
          new THREE.BoxGeometry(5.2, 0.25, 5.6),
          new THREE.MeshStandardMaterial({ color: '#ef4444', roughness: 0.8 })
        );
        awning.position.set(sx, 2.9, sz);
        scene.add(awning);
      }
    });
  }

  // F) LYARI FLOODLIT FOOTBALL STADIUM (-465, -210)
  {
    const pitch = new THREE.Mesh(
      new THREE.PlaneGeometry(46, 68),
      new THREE.MeshStandardMaterial({ color: '#15803d', roughness: 0.9 })
    );
    pitch.rotation.x = -Math.PI / 2;
    pitch.position.set(-465, 0.04, -210);
    scene.add(pitch);
    const lineMat = new THREE.MeshBasicMaterial({ color: '#f8fafc' });
    [-242, -178].forEach((gz) => {
      const goal = new THREE.Mesh(new THREE.BoxGeometry(9, 2.8, 0.3), lineMat);
      goal.position.set(-465, 1.4, gz);
      scene.add(goal);
    });
    // Stadium stands
    addHeroBuilding(-496, -210, 8, 9, 64, heritageMat, '#475569', false);
    addHeroBuilding(-434, -210, 8, 9, 64, heritageMat, '#475569', false);
  }

  // G) KARACHI PORT CONCRETE PIER, CONTAINERS, GANTRY CRANES & CARGO SHIPS
  {
    const pier = new THREE.Mesh(
      new THREE.BoxGeometry(190, 1.3, 87),
      new THREE.MeshStandardMaterial({ color: '#64748b', roughness: 0.88 })
    );
    pier.position.set(-525, 0, 361.5);
    pier.receiveShadow = true;
    scene.add(pier);

    const containerColors = ['#dc2626', '#2563eb', '#f59e0b', '#16a34a', '#0284c7'];
    for (let i = 0; i < 16; i++) {
      const cx = -600 + (i % 8) * 16;
      const cz = i < 8 ? 338 : 352;
      const col = containerColors[i % containerColors.length];
      addHeroBuilding(
        cx,
        cz,
        11,
        3.2 + (i % 2) * 3.0,
        3.8,
        new THREE.MeshStandardMaterial({ color: col, roughness: 0.55, metalness: 0.3 }),
        undefined,
        false
      );
    }

    [-585, -520, -455].forEach((kx) => {
      const crane = new THREE.Group();
      crane.position.set(kx, 0.65, 392);
      const craneMat = new THREE.MeshStandardMaterial({ color: '#ea580c', roughness: 0.45, metalness: 0.4 });
      [-4, 4].forEach((lx) => {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(1.1, 24, 1.1), craneMat);
        leg.position.set(lx, 12, 0);
        leg.castShadow = true;
        crane.add(leg);
      });
      const boom = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.6, 34), craneMat);
      boom.position.set(0, 23.5, 9);
      boom.castShadow = true;
      crane.add(boom);
      scene.add(crane);
    });

    // Docked Giant Cargo Ship offshore near Port
    const ship = new THREE.Group();
    ship.position.set(-510, 0.5, 435);
    const hull = new THREE.Mesh(
      new THREE.BoxGeometry(72, 9, 18),
      new THREE.MeshStandardMaterial({ color: '#7f1d1d', roughness: 0.6 })
    );
    hull.position.y = 3.5;
    ship.add(hull);
    const bridge = new THREE.Mesh(
      new THREE.BoxGeometry(12, 12, 14),
      new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.5 })
    );
    bridge.position.set(-24, 12, 0);
    ship.add(bridge);
    scene.add(ship);
  }

  // H) STARTER KARACHI HOME (Gulshan House beside Mazar-e-Quaid Link x:38, z:-70)
  {
    const home = new THREE.Group();
    home.position.set(38, 0, -70);
    const wallMat = new THREE.MeshStandardMaterial({ color: '#fef3c7', roughness: 0.72 });
    const trimMat = new THREE.MeshStandardMaterial({ color: '#0f766e', roughness: 0.48 });
    const houseBody = new THREE.Mesh(new THREE.BoxGeometry(12, 4.8, 10), wallMat);
    houseBody.position.set(0, 2.4, 0);
    houseBody.castShadow = true;
    houseBody.receiveShadow = true;
    home.add(houseBody);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(13, 0.5, 11), trimMat);
    roof.position.set(0, 5.05, 0);
    roof.castShadow = true;
    home.add(roof);

    const porch = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.35, 3.6), trimMat);
    porch.position.set(-7.5, 3.2, 0);
    home.add(porch);

    const door = new THREE.Mesh(
      new THREE.BoxGeometry(0.25, 2.8, 2.2),
      new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.5 })
    );
    door.position.set(-6.05, 1.4, 0);
    home.add(door);

    const garagePad = new THREE.Mesh(
      new THREE.PlaneGeometry(6.5, 7),
      new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.85 })
    );
    garagePad.rotation.x = -Math.PI / 2;
    garagePad.position.set(-8.5, 0.03, 5.5);
    home.add(garagePad);

    scene.add(home);
    colliders.push({ minX: 32, maxX: 44, minZ: -75, maxZ: -65, height: 5.5 });
  }

  // I) K-TECH MOBILE & PHONE SHOP STOREFRONT (-50, 24)
  {
    const phoneShop = new THREE.Group();
    phoneShop.position.set(-50, 0, 24);
    const shopBody = new THREE.Mesh(
      new THREE.BoxGeometry(11, 5.5, 9),
      new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.45, metalness: 0.3 })
    );
    shopBody.position.set(0, 2.75, 0);
    shopBody.castShadow = true;
    phoneShop.add(shopBody);

    const neonSign = new THREE.Mesh(
      new THREE.BoxGeometry(9.5, 1.4, 0.4),
      new THREE.MeshBasicMaterial({ color: '#a855f7' })
    );
    neonSign.position.set(0, 4.6, 4.65);
    phoneShop.add(neonSign);

    const screenDisplay = new THREE.Mesh(
      new THREE.BoxGeometry(2.2, 3.6, 0.25),
      new THREE.MeshBasicMaterial({ color: '#38bdf8' })
    );
    screenDisplay.position.set(-3.2, 2.2, 4.6);
    phoneShop.add(screenDisplay);

    scene.add(phoneShop);
    colliders.push({ minX: -55.5, maxX: -44.5, minZ: 19.5, maxZ: 28.5, height: 5.5 });
  }

  // I2) K-BANK & ATM HQ TOWER (-56, -44)
  {
    const bank = new THREE.Group();
    bank.position.set(-56, 0, -44);
    const bankBody = new THREE.Mesh(
      new THREE.BoxGeometry(14, 9.5, 11),
      new THREE.MeshStandardMaterial({ color: '#064e3b', roughness: 0.35, metalness: 0.25 })
    );
    bankBody.position.set(0, 4.75, 0);
    bankBody.castShadow = true;
    bankBody.receiveShadow = true;
    bank.add(bankBody);

    const goldCrown = new THREE.Mesh(
      new THREE.BoxGeometry(14.6, 1.0, 11.6),
      new THREE.MeshStandardMaterial({ color: '#eab308', metalness: 0.85, roughness: 0.2 })
    );
    goldCrown.position.set(0, 9.8, 0);
    bank.add(goldCrown);

    const bankSign = new THREE.Mesh(
      new THREE.BoxGeometry(10, 1.5, 0.4),
      new THREE.MeshBasicMaterial({ color: '#10b981' })
    );
    bankSign.position.set(0, 8.2, 5.65);
    bank.add(bankSign);

    const atmScreen = new THREE.Mesh(
      new THREE.BoxGeometry(2.6, 2.8, 0.35),
      new THREE.MeshBasicMaterial({ color: '#fef08a' })
    );
    atmScreen.position.set(4.2, 1.8, 5.6);
    bank.add(atmScreen);

    scene.add(bank);
    colliders.push({ minX: -63, maxX: -49, minZ: -49.5, maxZ: -38.5, height: 10.5 });
  }

  // J) KARACHI CAR SHOP SHOWROOM (x:64, z:-42)
  addHeroBuilding(68, -42, 22, 11, 18, modernBuildingMat, '#38bdf8');

  // K) REAL LUXURY DHA PHASE 8 VILLA + BACKYARD POOL (x:345, z:282)
  {
    const villa = new THREE.Group();
    villa.position.set(345, 0, 282);
    const stuccoMat = new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.65 });
    const woodTrimMat = new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.55 });
    const villaGlass = new THREE.MeshPhysicalMaterial({
      color: '#bae6fd',
      roughness: 0.08,
      metalness: 0.2,
      transparent: true,
      opacity: 0.5,
    });

    const groundFloor = new THREE.Mesh(new THREE.BoxGeometry(18, 4.4, 14), stuccoMat);
    groundFloor.position.set(0, 2.2, 0);
    groundFloor.castShadow = true;
    groundFloor.receiveShadow = true;
    villa.add(groundFloor);

    const upperFloor = new THREE.Mesh(new THREE.BoxGeometry(14, 4.0, 12), stuccoMat);
    upperFloor.position.set(-1.5, 6.4, -0.5);
    upperFloor.castShadow = true;
    villa.add(upperFloor);

    const roofPergola = new THREE.Mesh(new THREE.BoxGeometry(16.5, 0.35, 14.5), woodTrimMat);
    roofPergola.position.set(-1, 8.55, -0.2);
    roofPergola.castShadow = true;
    villa.add(roofPergola);

    const balconyGlass = new THREE.Mesh(new THREE.BoxGeometry(15.2, 1.1, 0.14), villaGlass);
    balconyGlass.position.set(0, 4.95, 6.9);
    villa.add(balconyGlass);

    const frontDoor = new THREE.Mesh(new THREE.BoxGeometry(2.4, 3.2, 0.2), woodTrimMat);
    frontDoor.position.set(2, 1.6, 7.05);
    villa.add(frontDoor);

    [-4.5, 5.5].forEach((px) => {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.35, 4.4, 12), stuccoMat);
      col.position.set(px, 2.2, 7.2);
      villa.add(col);
    });

    const poolFrame = new THREE.Mesh(
      new THREE.BoxGeometry(11, 0.2, 6.5),
      new THREE.MeshStandardMaterial({ color: '#e2e8f0', roughness: 0.4 })
    );
    poolFrame.position.set(14.5, 0.1, 1);
    villa.add(poolFrame);
    const poolWater = new THREE.Mesh(
      new THREE.PlaneGeometry(9.6, 5.2),
      new THREE.MeshPhysicalMaterial({ color: '#06b6d4', roughness: 0.08, clearcoat: 1.0 })
    );
    poolWater.rotation.x = -Math.PI / 2;
    poolWater.position.set(14.5, 0.22, 1);
    villa.add(poolWater);

    scene.add(villa);
    colliders.push({ minX: 336, maxX: 354, minZ: 275, maxZ: 289, height: 9 });
  }

  // L) DOLMEN SEAFRONT MALL & KORANGI SMOKESTACK
  addHeroBuilding(86, 276, 36, 20, 26, modernBuildingMat, '#bae6fd');
  const chimney = new THREE.Mesh(
    new THREE.CylinderGeometry(1.6, 2.5, 34, 12),
    new THREE.MeshStandardMaterial({ color: '#991b1b', roughness: 0.7 })
  );
  chimney.position.set(500, 17, 72);
  chimney.castShadow = true;
  scene.add(chimney);

  // 5. MASSIVE PROCEDURAL KARACHI SKYLINE & NEIGHBORHOOD BLOCKS (~210+ Buildings in 3 InstancedMesh batches!)
  interface BuildingSpec {
    x: number;
    z: number;
    w: number;
    h: number;
    d: number;
    tint: string;
  }
  const modernSpecs: BuildingSpec[] = [];
  const heritageSpecs: BuildingSpec[] = [];
  const bazaarSpecs: BuildingSpec[] = [];

  const roadXs = [-560, -380, -190, 0, 190, 380, 560];
  const roadZs = [-560, -420, -280, -140, 0, 120, 225, 320];

  const isClearOfRoadsAndLandmarks = (bx: number, bz: number, bw: number, bd: number): boolean => {
    const hw = bw / 2 + 4;
    const hd = bd / 2 + 4;
    for (let i = 0; i < roadXs.length; i++) {
      if (Math.abs(bx - roadXs[i]) < hw + 15) return false;
    }
    for (let i = 0; i < roadZs.length; i++) {
      if (Math.abs(bz - roadZs[i]) < hd + 15) return false;
    }
    // Keep landmarks, starter plaza, stadium, and places clear
    if (Math.abs(bx - 0) < 36 && Math.abs(bz + 140) < 36) return false; // Mazar
    if (Math.abs(bx - 38) < 30 && Math.abs(bz + 70) < 25) return false; // Home
    if (Math.abs(bx - 55) < 34 && Math.abs(bz + 42) < 25) return false; // Car Shop
    if (Math.abs(bx + 50) < 24 && Math.abs(bz - 30) < 22) return false; // Phone Shop
    if (Math.abs(bx + 52) < 28 && Math.abs(bz + 42) < 24) return false; // K-Bank HQ
    if (Math.abs(bx + 218) < 30 && Math.abs(bz - 28) < 25) return false; // Empress Market
    if (Math.abs(bx + 250) < 35 && Math.abs(bz - 145) < 42) return false; // Burns Road
    if (Math.abs(bx + 465) < 46 && Math.abs(bz + 210) < 46) return false; // Lyari Stadium
    if (Math.abs(bx - 350) < 32 && Math.abs(bz - 275) < 28) return false; // DHA Villa
    if (Math.abs(bx - 86) < 34 && Math.abs(bz - 272) < 28) return false; // Dolmen Mall
    for (let i = 0; i < KARACHI_PLACES.length; i++) {
      const p = KARACHI_PLACES[i];
      if (Math.hypot(bx - p.x, bz - p.z) < Math.max(hw, hd) + 10) return false;
    }
    return true;
  };

  const blockXs = [-645, -470, -285, -95, 95, 285, 470, 645];
  const blockZs = [-490, -350, -210, -70, 60, 172, 272];
  const modernTints = ['#93c5fd', '#cbd5e1', '#bae6fd', '#e2e8f0', '#d8b4fe', '#fbcfe8'];
  const bazaarTints = ['#fde68a', '#fed7aa', '#fca5a5', '#fcd34d', '#e2e8f0'];
  const heritageTints = ['#e7e5e4', '#d6d3d1', '#cbd5e1', '#f5f5f4'];

  let seed = 1337;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  blockXs.forEach((cx) => {
    blockZs.forEach((cz) => {
      // 4 sub-lots per city block
      const offsets: [number, number][] = [
        [-38, -26],
        [38, -26],
        [-38, 26],
        [38, 26],
      ];
      offsets.forEach(([ox, oz]) => {
        const bx = cx + ox + (rand() - 0.5) * 10;
        const bz = cz + oz + (rand() - 0.5) * 8;
        const w = 18 + Math.round(rand() * 14);
        const d = 16 + Math.round(rand() * 12);
        if (!isClearOfRoadsAndLandmarks(bx, bz, w, d)) return;

        // Tallest skyscrapers along Shahrah-e-Faisal (|z|<140) & Clifton waterfront (z>160)
        const nearCore = Math.abs(bz) < 150 && Math.abs(bx) < 350;
        const nearClifton = bz > 150 && Math.abs(bx) < 250;
        const isIndustrial = bx > 350 && bz > -50 && bz < 200;
        const isSaddarLyari = bx < -120 && bz < 200;

        if (nearCore || nearClifton) {
          const h = Math.round(24 + rand() * 52);
          modernSpecs.push({
            x: bx,
            z: bz,
            w,
            h,
            d,
            tint: modernTints[Math.floor(rand() * modernTints.length)],
          });
        } else if (isIndustrial) {
          const h = Math.round(11 + rand() * 11);
          heritageSpecs.push({
            x: bx,
            z: bz,
            w: w + 6,
            h,
            d: d + 4,
            tint: heritageTints[Math.floor(rand() * heritageTints.length)],
          });
        } else if (isSaddarLyari) {
          const h = Math.round(12 + rand() * 16);
          if (rand() > 0.45) {
            heritageSpecs.push({
              x: bx,
              z: bz,
              w,
              h,
              d,
              tint: heritageTints[Math.floor(rand() * heritageTints.length)],
            });
          } else {
            bazaarSpecs.push({
              x: bx,
              z: bz,
              w,
              h,
              d,
              tint: bazaarTints[Math.floor(rand() * bazaarTints.length)],
            });
          }
        } else {
          // Gulshan, North Nazimabad, DHA, Tariq Road residential & commercial towers
          const h = Math.round(14 + rand() * 26);
          if (rand() > 0.55) {
            modernSpecs.push({
              x: bx,
              z: bz,
              w,
              h,
              d,
              tint: modernTints[Math.floor(rand() * modernTints.length)],
            });
          } else {
            bazaarSpecs.push({
              x: bx,
              z: bz,
              w,
              h,
              d,
              tint: bazaarTints[Math.floor(rand() * bazaarTints.length)],
            });
          }
        }
      });
    });
  });

  const buildInstancedCityBatch = (specs: BuildingSpec[], mat: THREE.MeshStandardMaterial) => {
    if (specs.length === 0) return;
    const unitBox = new THREE.BoxGeometry(1, 1, 1);
    unitBox.translate(0, 0.5, 0);
    const mesh = new THREE.InstancedMesh(unitBox, mat, specs.length);
    mesh.castShadow = !isSoftwareGl;
    mesh.receiveShadow = true;

    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    specs.forEach((b, i) => {
      dummy.position.set(b.x, 0, b.z);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(b.w, b.h, b.d);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      color.set(b.tint);
      mesh.setColorAt(i, color);
      colliders.push({
        minX: b.x - b.w / 2,
        maxX: b.x + b.w / 2,
        minZ: b.z - b.d / 2,
        maxZ: b.z + b.d / 2,
        height: b.h,
      });
    });
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    mesh.computeBoundingSphere();
    scene.add(mesh);
  };

  buildInstancedCityBatch(modernSpecs, modernBuildingMat);
  buildInstancedCityBatch(heritageSpecs, heritageMat);
  buildInstancedCityBatch(bazaarSpecs, bazaarMat);

  // 6. INSTANCED PALM TREES & STREETLIGHTS ACROSS THE MEGA CITY
  const palmPositions: [number, number][] = [];
  for (let x = -400; x <= 640; x += 32) {
    palmPositions.push([x, 330]); // Sea View Beachfront Palms
  }
  for (let z = -540; z <= 300; z += 44) {
    if (Math.abs(z - 225) > 25 && Math.abs(z) > 20 && Math.abs(z + 140) > 30) {
      palmPositions.push([15, z]);
      palmPositions.push([-15, z]);
    }
  }
  for (let x = 210; x <= 620; x += 38) {
    palmPositions.push([x, 240]); // DHA Palms
  }

  const trunkGeo = new THREE.CylinderGeometry(0.22, 0.36, 6.2, 7);
  trunkGeo.translate(0, 3.1, 0);
  const trunkMat = new THREE.MeshStandardMaterial({ color: '#78350f', roughness: 0.92 });
  const palmTrunks = new THREE.InstancedMesh(trunkGeo, trunkMat, palmPositions.length);
  palmTrunks.castShadow = !isSoftwareGl;

  const crownGeo = new THREE.ConeGeometry(2.6, 2.2, 7);
  crownGeo.translate(0, 6.5, 0);
  const crownMat = new THREE.MeshStandardMaterial({ color: '#15803d', roughness: 0.78 });
  const palmCrowns = new THREE.InstancedMesh(crownGeo, crownMat, palmPositions.length);
  palmCrowns.castShadow = !isSoftwareGl;

  const dummy = new THREE.Object3D();
  const tint = new THREE.Color();
  palmPositions.forEach(([px, pz], idx) => {
    const s = 0.85 + ((idx * 37) % 30) / 100;
    dummy.position.set(px, 0, pz);
    dummy.rotation.set(0, idx * 1.1, 0);
    dummy.scale.set(s, s, s);
    dummy.updateMatrix();
    palmTrunks.setMatrixAt(idx, dummy.matrix);
    palmCrowns.setMatrixAt(idx, dummy.matrix);
    tint.setHSL(0.32 + ((idx % 5) - 2) * 0.015, 0.55, 0.32);
    palmCrowns.setColorAt(idx, tint);
  });
  palmTrunks.instanceMatrix.needsUpdate = true;
  palmCrowns.instanceMatrix.needsUpdate = true;
  if (palmCrowns.instanceColor) palmCrowns.instanceColor.needsUpdate = true;
  palmTrunks.computeBoundingSphere();
  palmCrowns.computeBoundingSphere();
  scene.add(palmTrunks, palmCrowns);

  // Instanced Streetlights along main avenues
  const lightPositions: [number, number][] = [];
  for (let x = -640; x <= 640; x += 50) {
    lightPositions.push([x, -16]);
    lightPositions.push([x, 16]);
    lightPositions.push([x, 238]);
    lightPositions.push([x, -293]);
  }
  const poleGeo = new THREE.CylinderGeometry(0.1, 0.14, 6.5, 6);
  poleGeo.translate(0, 3.25, 0);
  const poleMat = new THREE.MeshStandardMaterial({ color: '#334155', metalness: 0.7, roughness: 0.4 });
  const poles = new THREE.InstancedMesh(poleGeo, poleMat, lightPositions.length);

  const bulbGeo = new THREE.BoxGeometry(0.8, 0.25, 0.4);
  bulbGeo.translate(0, 6.5, 0);
  const streetLightBulbs = new THREE.MeshBasicMaterial({ color: '#fef08a' });
  const bulbs = new THREE.InstancedMesh(bulbGeo, streetLightBulbs, lightPositions.length);

  lightPositions.forEach(([lx, lz], i) => {
    dummy.position.set(lx, 0, lz);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    poles.setMatrixAt(i, dummy.matrix);
    bulbs.setMatrixAt(i, dummy.matrix);
  });
  poles.instanceMatrix.needsUpdate = true;
  bulbs.instanceMatrix.needsUpdate = true;
  poles.computeBoundingSphere();
  bulbs.computeBoundingSphere();
  scene.add(poles, bulbs);

  // 7. Interactive Shop / Property / Dealership 3D Beacon Markers
  const placeBeacons = new Map<string, THREE.Mesh>();
  KARACHI_PLACES.forEach((place) => {
    const color =
      place.type === 'home'
        ? '#facc15'
        : place.type === 'bank'
          ? '#22c55e'
          : place.type === 'phone_shop'
            ? '#a855f7'
            : place.type === 'property'
              ? '#10b981'
              : place.type === 'dealership' || place.type === 'bike_shop'
                ? '#38bdf8'
                : place.type === 'restaurant'
                  ? '#ef4444'
                  : '#f59e0b';

    const ring = new THREE.Mesh(
      new THREE.CylinderGeometry(2.4, 2.4, 2.8, 24, 1, true),
      new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0.42,
        side: THREE.DoubleSide,
        depthWrite: false,
      })
    );
    ring.position.set(place.x, 1.4, place.z);
    scene.add(ring);
    placeBeacons.set(place.id, ring);
  });

  // Road intersection nodes for Traffic AI across the 7 x 8 mega grid
  const roadGraphNodes: { x: number; z: number }[] = [];
  roadXs.forEach((rx) => roadZs.forEach((rz) => roadGraphNodes.push({ x: rx, z: rz })));

  return {
    colliders,
    oceanMesh,
    oceanMaterial,
    oceanUniforms,
    sunDisc,
    roadMaterial,
    modernBuildingMat,
    streetLightBulbs,
    placeBeacons,
    roadGraphNodes,
  };
}
