import * as THREE from 'three'
import type { Quality } from './save'

type Preset = { pixelRatio: number; antialias: boolean; terrainRadius: number; clouds: number; fogFar: number }

export const QUALITY_PRESETS: Record<Quality, Preset> = {
  low: { pixelRatio: 1, antialias: false, terrainRadius: 2, clouds: 14, fogFar: 1500 },
  medium: { pixelRatio: 1.5, antialias: true, terrainRadius: 3, clouds: 26, fogFar: 2100 },
  high: { pixelRatio: 2, antialias: true, terrainRadius: 4, clouds: 36, fogFar: 2800 },
}

/** Pick a starting quality from device hints; the player can override it in Ajustes. */
export function suggestQuality(): Quality {
  const coarse = matchMedia('(pointer: coarse)').matches
  const cores = navigator.hardwareConcurrency ?? 4
  if (coarse) return cores >= 8 ? 'medium' : 'low'
  return cores <= 4 ? 'medium' : 'high'
}

/**
 * Owns the WebGL renderer and resize handling. The flight scene is drawn directly (no
 * post-processing) to keep frame times low on phones.
 */
export class Renderer {
  readonly gl: THREE.WebGLRenderer
  private preset: Preset
  private resizeListeners: Array<() => void> = []

  constructor(readonly canvas: HTMLCanvasElement, quality: Quality) {
    this.preset = QUALITY_PRESETS[quality]
    this.gl = new THREE.WebGLRenderer({ canvas, antialias: this.preset.antialias, powerPreference: 'high-performance' })
    this.gl.outputColorSpace = THREE.SRGBColorSpace
    this.gl.toneMapping = THREE.ACESFilmicToneMapping
    this.gl.toneMappingExposure = 1.0
    this.applyQuality(quality)
    window.addEventListener('resize', () => this.resize())
    window.addEventListener('orientationchange', () => window.setTimeout(() => this.resize(), 120))
  }

  get settings(): Preset {
    return this.preset
  }

  get pixelHeight(): number {
    return this.gl.domElement.height
  }

  onResize(fn: () => void): void {
    this.resizeListeners.push(fn)
  }

  applyQuality(quality: Quality): void {
    this.preset = QUALITY_PRESETS[quality]
    this.gl.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.preset.pixelRatio))
    this.resize()
  }

  resize(): void {
    const w = this.canvas.clientWidth || window.innerWidth
    const h = this.canvas.clientHeight || window.innerHeight
    this.gl.setSize(w, h, false)
    for (const fn of this.resizeListeners) fn()
  }

  render(scene: THREE.Scene, camera: THREE.PerspectiveCamera): void {
    const w = this.canvas.clientWidth || window.innerWidth
    const h = this.canvas.clientHeight || window.innerHeight
    if (Math.abs(camera.aspect - w / h) > 1e-3) {
      camera.aspect = w / h
      camera.updateProjectionMatrix()
    }
    this.gl.render(scene, camera)
  }
}
