import { curve, perf } from "./spec";
import type { Live, Spec } from "./types";

const RAT = [0, 13, 9, 6.6, 5.1, 4.1, 3.4];
const IDLE = 900;

export type SimHooks = {
  blow: () => void;
  limit: () => void;
};

export function step(live: Live, spec: Spec, dt: number, hooks: SimHooks) {
  const e = curve(spec);
  const g = live.gear;
  const R = RAT[g] ?? 0;
  const M = 500 * (spec.twin ? 1.4 : 1);
  live.brake += (live.brk - live.brake) * Math.min(1, dt * 10);
  live.grind = Math.max(0, live.grind - dt);
  live.msg = Math.max(0, live.msg - dt);
  live.clu += (live.cin - live.clu) * Math.min(1, dt * (live.cin ? 10 : 2.2));

  if (live.dead) {
    live.deadT += dt;
    live.thr *= Math.exp(-dt * 8);
    live.spd = Math.max(0, live.spd - dt * (1 + 0.0006 * live.spd * live.spd + live.brake * 9));
    if (live.spd < 0.3) live.stopT += dt;
    const tg = g ? Math.min(2500, live.spd * R * 31.8 * 0.3) : 0;
    live.rpm += (tg - live.rpm) * Math.min(1, dt * 3);
    return;
  }

  live.thr += (live.pedal - live.thr) * Math.min(1, dt * (8 + (spec.ecu ? spec.map * 0.4 : 0)));
  const drag = 0.3 + 0.0006 * live.spd * live.spd;
  const cr = live.spd * R * 31.8;
  const en = g ? Math.min(1, Math.max(0, (0.75 - live.clu) / 0.5)) : 0;

  if (live.stall) {
    if (live.crank > 0) {
      live.crank -= dt;
      live.rpm += (260 - live.rpm) * Math.min(1, dt * 10);
      if (live.crank <= 0) {
        live.stall = false;
        live.rpm = 1300;
        live.cut = false;
      }
    } else live.rpm *= Math.exp(-dt * 8);
    if (live.stall) {
      live.spd = Math.max(0, live.spd - dt * (drag + live.brake * 9 + en * R * 0.4));
      return;
    }
  }

  const top = en > 0.5 ? Math.max(live.rpm, cr) : live.rpm;
  if (live.cut) {
    live.cutT -= dt;
    if (live.cutT <= 0) {
      live.cut = false;
      live.rel = true;
      live.limCd = 0.025 + Math.random() * 0.035;
    }
  } else {
    live.limCd -= dt;
    if (top >= e.red && live.thr > 0.3 && live.limCd <= 0) {
      live.cut = true;
      live.cutT = 0.05 + Math.random() * 0.04;
      hooks.limit();
    }
  }
  const thr = live.cut ? 0 : top >= e.red * 1.01 ? 0 : live.thr;
  const tg = IDLE + thr * (e.red * 1.1 - IDLE);
  const follow =
    tg > live.rpm ? (live.rpm > e.red * 0.8 ? 9 : 4) : live.cut ? 0.45 : 1.6;
  const rF = live.rpm + (tg - live.rpm) * Math.min(1, dt * follow);

  if (en <= 0) {
    live.rpm = rF;
    live.spd = Math.max(
      0,
      live.spd - dt * ((g ? 0.3 : 0.6) + 0.0006 * live.spd * live.spd + live.brake * 9),
    );
    return;
  }

  const p = perf(spec, Math.max(live.rpm, IDLE));
  const tqE = p.tq * (0.08 + 0.92 * thr);
  const df = live.rpm - cr;
  if (en > 0.9 && Math.abs(df) < 250) {
    if (cr > e.red * 1.3) {
      blow(live, hooks);
      return;
    }
    const a =
      (thr * p.tq * R) / (0.3 * M) -
      drag -
      (thr < 0.05 ? (0.6 * (live.rpm / e.red) * R) / 8 : 0) -
      live.brake * 9 -
      (live.cut ? 2.5 : 0);
    live.spd = Math.max(0, live.spd + Math.min(a, 14) * dt);
    const c2 = live.spd * R * 31.8;
    live.rpm += (c2 - live.rpm) * Math.min(1, dt * 10);
    if (c2 < 300 && live.rpm < 350 && thr < 0.2) live.stall = true;
  } else {
    const pull =
      df > 0
        ? Math.max(-1, Math.min(1, df / 1500)) * Math.min(14, (tqE * R) / (0.3 * M))
        : Math.max(-1, df / 1500) * 6;
    const a = en * pull - drag - live.brake * 9;
    live.spd = Math.max(0, live.spd + a * dt);
    const launch = live.spd < 3 && thr > 0.15 ? 0.28 : 1;
    live.rpm = rF + (Math.max(cr, 0) - rF) * Math.min(1, dt * 8 * en * launch);
    if (live.rpm > e.red * 1.3) {
      blow(live, hooks);
      return;
    }
    if (en > 0.9 && live.rpm < 300 && thr < 0.2) live.stall = true;
  }
}

function blow(live: Live, hooks: SimHooks) {
  if (live.dead) return;
  live.dead = true;
  live.deadT = 0;
  live.stopT = 0;
  live.pedal = 0;
  hooks.blow();
}

export function tryShift(live: Live, g: number): { gear: number; grind: boolean } {
  if (g === live.gear || g === 0 || live.clu > 0.6 || live.stall || live.spd < 0.5) {
    live.gear = g;
    return { gear: g, grind: false };
  }
  live.grind = 1.5;
  return { gear: live.gear, grind: true };
}

export function ignite(live: Live): "stop" | "busy" | "need-clutch" | "crank" {
  if (live.dead) return "busy";
  if (!live.stall) {
    live.stall = true;
    live.crank = 0;
    return "stop";
  }
  if (live.crank > 0) return "busy";
  if (live.gear && live.clu < 0.7) {
    live.msg = 1.8;
    return "need-clutch";
  }
  live.crank = 0.9;
  return "crank";
}
