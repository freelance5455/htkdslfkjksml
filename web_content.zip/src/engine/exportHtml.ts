import { AvatarConfig, WorldConfig } from '../types/game';

export function buildStandaloneHtml(world: WorldConfig, avatar: AvatarConfig): string {
  const worldJson = JSON.stringify(world);
  const avatarJson = JSON.stringify(avatar);

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Slapbox — ${world.name}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body { width: 100%; height: 100%; overflow: hidden; background: #0f172a; font-family: system-ui, -apple-system, sans-serif; color: #f8fafc; }
    #hud {
      position: fixed; top: 16px; left: 16px; z-index: 10;
      background: rgba(15, 23, 42, 0.85); border: 1px solid rgba(255,255,255,0.12);
      border-radius: 12px; padding: 12px 16px; display: flex; gap: 18px; align-items: center;
      font-size: 14px; font-weight: 600;
    }
    #controls {
      position: fixed; bottom: 16px; left: 50%; transform: translateX(-50%); z-index: 10;
      background: rgba(15, 23, 42, 0.85); border: 1px solid rgba(255,255,255,0.12);
      border-radius: 10px; padding: 8px 16px; font-size: 13px; color: #cbd5e1; white-space: nowrap;
    }
    #win {
      display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 20;
      background: rgba(15, 23, 42, 0.94); border: 1px solid rgba(250, 204, 21, 0.5);
      border-radius: 16px; padding: 24px 32px; text-align: center;
    }
    button {
      margin-top: 12px; background: #2563eb; color: #fff; border: none; padding: 8px 18px;
      border-radius: 8px; font-weight: 600; cursor: pointer;
    }
  </style>
</head>
<body>
  <div id="hud">
    <span>${world.name}</span>
    <span id="stage">Tahap 1</span>
    <span id="coins">Koin 0/${world.coins.length}</span>
    <span id="timer">00:00</span>
  </div>
  <div id="controls">WASD / Panah: Gerak · Spasi: Lompat · Shift: Lari · Seret Mouse: Putar Kamera</div>
  <div id="win">
    <h2>Selamat! Kamu Menang!</h2>
    <p id="win-sub" style="margin-top:6px;color:#cbd5e1;"></p>
    <button onclick="location.reload()">Main Lagi</button>
  </div>
  <script type="importmap">
    {
      "imports": {
        "three": "https://cdn.jsdelivr.net/npm/three@0.174.0/build/three.module.js"
      }
    }
  </script>
  <script type="module">
    import * as THREE from 'three';

    const WORLD = ${worldJson};
    const AVATAR = ${avatarJson};

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(WORLD.isLavaSea ? '#451a03' : '#7dd3fc');
    scene.fog = new THREE.Fog(scene.background, 45, 190);

    const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 400);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(innerWidth, innerHeight);
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    document.body.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0xe0f2fe, 0x334155, 0.8));
    const sun = new THREE.DirectionalLight(0xfff7ed, 1.5);
    sun.position.set(35, 55, 25);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    scene.add(sun);

    const sea = new THREE.Mesh(
      new THREE.PlaneGeometry(500, 500),
      new THREE.MeshStandardMaterial({ color: WORLD.seaColor, emissive: WORLD.seaEmissive, emissiveIntensity: WORLD.isLavaSea ? 0.55 : 0.1, roughness: 0.4 })
    );
    sea.rotation.x = -Math.PI / 2;
    sea.position.y = WORLD.seaY;
    scene.add(sea);

    const plats = WORLD.platforms.map((p) => {
      const mesh = new THREE.Mesh(
        new THREE.BoxGeometry(p.w, p.h, p.d),
        new THREE.MeshStandardMaterial({ color: p.color, roughness: 0.42 })
      );
      mesh.position.set(p.x, p.y, p.z);
      mesh.receiveShadow = true;
      mesh.castShadow = true;
      scene.add(mesh);
      return { def: p, mesh, prevX: p.x, prevY: p.y, prevZ: p.z };
    });

    const coins = WORLD.coins.map((c) => {
      const m = new THREE.Mesh(
        new THREE.CylinderGeometry(0.55, 0.55, 0.18, 16),
        new THREE.MeshStandardMaterial({ color: '#facc15', metalness: 0.8, roughness: 0.2 })
      );
      m.rotation.z = Math.PI / 2;
      m.position.set(c.x, c.y, c.z);
      scene.add(m);
      return { mesh: m, collected: false };
    });

    const player = new THREE.Group();
    const legMat = new THREE.MeshStandardMaterial({ color: AVATAR.pantsColor });
    const shirtMat = new THREE.MeshStandardMaterial({ color: AVATAR.shirtColor });
    const skinMat = new THREE.MeshStandardMaterial({ color: AVATAR.skinColor });
    const lLeg = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.95, 0.45), legMat); lLeg.position.set(-0.25, 0.48, 0);
    const rLeg = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.95, 0.45), legMat); rLeg.position.set(0.25, 0.48, 0);
    const torso = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.05, 0.52), shirtMat); torso.position.set(0, 1.48, 0);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.78, 0.8), skinMat); head.position.set(0, 2.42, 0);
    player.add(lLeg, rLeg, torso, head);
    player.position.set(...WORLD.spawn);
    scene.add(player);

    const keys = {};
    addEventListener('keydown', (e) => { keys[e.code] = true; });
    addEventListener('keyup', (e) => { keys[e.code] = false; });

    let yaw = 0, pitch = 0.42, dist = 12, dragging = false, lx = 0, ly = 0;
    renderer.domElement.addEventListener('pointerdown', (e) => { dragging = true; lx = e.clientX; ly = e.clientY; });
    addEventListener('pointerup', () => { dragging = false; });
    addEventListener('pointermove', (e) => {
      if (!dragging) return;
      yaw -= (e.clientX - lx) * 0.007;
      pitch = Math.max(0.12, Math.min(1.25, pitch + (e.clientY - ly) * 0.006));
      lx = e.clientX; ly = e.clientY;
    });

    let vy = 0, grounded = false, stage = 1, coinCount = 0, won = false;
    let spawn = new THREE.Vector3(...WORLD.spawn);
    const clock = new THREE.Clock();
    let elapsed = 0;

    function tick() {
      const dt = Math.min(clock.getDelta(), 0.05);
      const t = clock.elapsedTime;
      if (!won) elapsed += dt;

      for (const p of plats) {
        p.prevX = p.mesh.position.x; p.prevY = p.mesh.position.y; p.prevZ = p.mesh.position.z;
        if (p.def.kind === 'moving' && p.def.moveRange) {
          const offset = Math.sin(t * (p.def.moveSpeed || 1.5) + (p.def.movePhase || 0)) * p.def.moveRange;
          if (p.def.moveAxis === 'x') p.mesh.position.x = p.def.x + offset;
          if (p.def.moveAxis === 'y') p.mesh.position.y = p.def.y + offset;
          if (p.def.moveAxis === 'z') p.mesh.position.z = p.def.z + offset;
        }
      }

      let mx = (keys['KeyD'] || keys['ArrowRight'] ? 1 : 0) - (keys['KeyA'] || keys['ArrowLeft'] ? 1 : 0);
      let mz = (keys['KeyS'] || keys['ArrowDown'] ? 1 : 0) - (keys['KeyW'] || keys['ArrowUp'] ? 1 : 0);
      const speed = (keys['ShiftLeft'] || keys['ShiftRight']) ? 13.5 : 9.8;
      if (mx !== 0 || mz !== 0) {
        const angle = Math.atan2(mx, mz) + yaw;
        player.position.x += Math.sin(angle) * speed * dt;
        player.position.z += Math.cos(angle) * speed * dt;
        player.rotation.y = angle;
      }

      if (keys['Space'] && grounded) { vy = 14.5; grounded = false; }
      vy -= 32 * dt;
      player.position.y += vy * dt;

      grounded = false;
      for (const p of plats) {
        const hw = p.def.w / 2 + 0.45, hd = p.def.d / 2 + 0.45;
        const top = p.mesh.position.y + p.def.h / 2;
        if (Math.abs(player.position.x - p.mesh.position.x) < hw && Math.abs(player.position.z - p.mesh.position.z) < hd) {
          if (vy <= 0 && player.position.y <= top + 0.2 && player.position.y >= top - 1.2) {
            if (p.def.kind === 'hazard') { player.position.copy(spawn); vy = 0; break; }
            player.position.y = top;
            player.position.x += p.mesh.position.x - p.prevX;
            player.position.z += p.mesh.position.z - p.prevZ;
            vy = 0;
            grounded = true;
            if (p.def.kind === 'bounce') { vy = p.def.bounceVelocity || 22; grounded = false; }
            if (p.def.kind === 'checkpoint' && p.def.stageIndex && p.def.stageIndex > stage) {
              stage = p.def.stageIndex;
              spawn.set(p.mesh.position.x, top + 0.5, p.mesh.position.z);
              document.getElementById('stage').textContent = 'Tahap ' + stage;
            }
            if (p.def.kind === 'finish' && !won) {
              won = true;
              document.getElementById('win-sub').textContent = 'Koin: ' + coinCount + '/' + coins.length;
              document.getElementById('win').style.display = 'block';
            }
          }
        }
      }

      if (player.position.y < WORLD.fallY) {
        player.position.copy(spawn);
        vy = 0;
      }

      for (const c of coins) {
        if (c.collected) continue;
        c.mesh.rotation.y += dt * 3;
        if (player.position.distanceTo(c.mesh.position) < 2.2) {
          c.collected = true;
          c.mesh.visible = false;
          coinCount++;
          document.getElementById('coins').textContent = 'Koin ' + coinCount + '/' + coins.length;
        }
      }

      const cx = player.position.x + Math.sin(yaw) * Math.cos(pitch) * dist;
      const cy = player.position.y + 1.8 + Math.sin(pitch) * dist;
      const cz = player.position.z + Math.cos(yaw) * Math.cos(pitch) * dist;
      camera.position.lerp(new THREE.Vector3(cx, cy, cz), 1 - Math.exp(-10 * dt));
      camera.lookAt(player.position.x, player.position.y + 1.6, player.position.z);

      const mins = String(Math.floor(elapsed / 60)).padStart(2, '0');
      const secs = String(Math.floor(elapsed % 60)).padStart(2, '0');
      document.getElementById('timer').textContent = mins + ':' + secs;

      renderer.render(scene, camera);
      requestAnimationFrame(tick);
    }
    tick();

    addEventListener('resize', () => {
      camera.aspect = innerWidth / innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(innerWidth, innerHeight);
    });
  </script>
</body>
</html>`;
}
