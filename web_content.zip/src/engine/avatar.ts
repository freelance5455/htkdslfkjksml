import * as THREE from 'three';
import {
  AccessoryEffect,
  AvatarConfig,
  EmoteId,
  FaceExpression,
  FootTrailStyle,
  HairStyle,
  IdleAnimStyle,
  JumpAnimStyle,
  MakeupStyle,
  UgcItemAttachment,
  WalkAnimStyle,
} from '../types/game';
import { ResolvedFaceMood, createFaceTexture } from './textures';

export interface AvatarRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  headGroup: THREE.Group;
  leftArmPivot: THREE.Group;
  rightArmPivot: THREE.Group;
  leftLegPivot: THREE.Group;
  rightLegPivot: THREE.Group;
  setNameTag: (name: string | null, isPlus?: boolean) => void;
  setChatBubble: (text: string | null) => void;
  setVoiceState: (active: boolean, bars: [number, number, number, number, number]) => void;
  updateAppearance: (cfg: AvatarConfig) => void;
  updateAnimation: (
    dt: number,
    speedRatio: number,
    isGrounded: boolean,
    verticalVel: number,
    walkAnim?: WalkAnimStyle,
    jumpAnim?: JumpAnimStyle,
    activeEmote?: EmoteId | null,
    emoteElapsed?: number,
    idleAnim?: IdleAnimStyle
  ) => void;
  dispose: () => void;
}

function drawNameTagTexture(name: string, isPlus = false): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const label = isPlus ? `+ ${name}` : name;
  ctx.font = '700 42px "Plus Jakarta Sans", system-ui, sans-serif';
  const metrics = ctx.measureText(label);
  const pillW = Math.min(488, Math.max(168, metrics.width + 72));
  const pillH = 74;
  const x = (canvas.width - pillW) / 2;
  const y = (canvas.height - pillH) / 2;

  ctx.fillStyle = isPlus ? 'rgba(18, 14, 6, 0.92)' : 'rgba(10, 10, 12, 0.88)';
  ctx.beginPath();
  ctx.roundRect(x, y, pillW, pillH, 22);
  ctx.fill();

  ctx.strokeStyle = isPlus ? '#facc15' : 'rgba(255, 255, 255, 0.45)';
  ctx.lineWidth = isPlus ? 4 : 3;
  ctx.stroke();

  if (isPlus) {
    // Crisp [+] badge on left
    const bx = x + 14;
    const by = canvas.height / 2 - 20;
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.roundRect(bx, by, 40, 40, 12);
    ctx.fill();
    ctx.fillStyle = '#09090b';
    ctx.font = '900 32px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('+', bx + 20, canvas.height / 2 + 1);

    ctx.fillStyle = '#fef08a';
    ctx.font = '700 40px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(name, bx + 52, canvas.height / 2 + 2, pillW - 80);
  } else {
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(name, canvas.width / 2, canvas.height / 2 + 2, pillW - 24);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function drawChatBubbleTexture(text: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 192;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const trimmed = text.trim().slice(0, 72);
  ctx.font = '700 34px "Plus Jakarta Sans", system-ui, sans-serif';

  // Wrap into up to 2 lines
  const words = trimmed.split(/\s+/);
  const lines: string[] = [];
  let current = '';
  for (const w of words) {
    const test = current ? `${current} ${w}` : w;
    if (ctx.measureText(test).width > 520 && current) {
      lines.push(current);
      current = w;
      if (lines.length === 1 && words.indexOf(w) < words.length - 1) {
        // continue collecting second line
      }
    } else {
      current = test;
    }
  }
  if (current) lines.push(current);
  const displayLines = lines.slice(0, 2);
  if (lines.length > 2) {
    displayLines[1] = displayLines[1].slice(0, Math.max(3, displayLines[1].length - 3)) + '...';
  }

  const maxLineW = Math.max(...displayLines.map((l) => ctx.measureText(l).width), 80);
  const bubbleW = Math.min(590, Math.max(150, maxLineW + 70));
  const bubbleH = displayLines.length === 1 ? 84 : 124;
  const bx = (canvas.width - bubbleW) / 2;
  const by = 18;

  // Drop shadow
  ctx.fillStyle = 'rgba(0,0,0,0.22)';
  ctx.beginPath();
  ctx.roundRect(bx, by + 6, bubbleW, bubbleH, 26);
  ctx.fill();

  // White speech bubble + pointer
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = '#09090b';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.roundRect(bx, by, bubbleW, bubbleH, 26);
  ctx.fill();
  ctx.stroke();

  // Pointer triangle
  ctx.beginPath();
  ctx.moveTo(canvas.width / 2 - 14, by + bubbleH - 2);
  ctx.lineTo(canvas.width / 2, by + bubbleH + 20);
  ctx.lineTo(canvas.width / 2 + 14, by + bubbleH - 2);
  ctx.closePath();
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  ctx.stroke();
  // Cover inner stroke line where pointer meets bubble
  ctx.fillRect(canvas.width / 2 - 12, by + bubbleH - 6, 24, 8);

  ctx.fillStyle = '#09090b';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  if (displayLines.length === 1) {
    ctx.fillText(displayLines[0], canvas.width / 2, by + bubbleH / 2 + 2, bubbleW - 32);
  } else {
    ctx.fillText(displayLines[0], canvas.width / 2, by + bubbleH * 0.34, bubbleW - 32);
    ctx.fillText(displayLines[1], canvas.width / 2, by + bubbleH * 0.68, bubbleW - 32);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

const EFFECT_PALETTES: Record<Exclude<AccessoryEffect, 'none'>, string[]> = {
  fire: ['#f97316', '#ef4444', '#facc15'],
  lightning: ['#fde047', '#38bdf8', '#ffffff'],
  galaxy: ['#a855f7', '#6366f1', '#38bdf8'],
  rainbow: ['#ef4444', '#facc15', '#22c55e', '#38bdf8', '#a855f7'],
  sparkle: ['#ffffff', '#fde047', '#cbd5e1'],
};

const FOOT_TRAIL_PALETTES: Record<Exclude<FootTrailStyle, 'none'>, string[]> = {
  fire: ['#f97316', '#ef4444', '#fde047'],
  lightning: ['#38bdf8', '#fde047', '#ffffff'],
  hearts: ['#f43f5e', '#fb7185', '#fbcfe8'],
  pixel: ['#22c55e', '#4ade80', '#38bdf8'],
  rainbow: ['#ef4444', '#facc15', '#22c55e', '#38bdf8', '#a855f7'],
  galaxy: ['#8b5cf6', '#6366f1', '#38bdf8', '#f0abfc'],
};

export function createAvatarRig(initial: AvatarConfig, nameTagText?: string): AvatarRig {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const skinMat = new THREE.MeshStandardMaterial({
    color: initial.skinColor,
    roughness: 0.48,
    metalness: 0.04,
  });
  const shirtMat = new THREE.MeshStandardMaterial({
    color: initial.shirtColor,
    roughness: 0.58,
    metalness: 0.05,
  });
  const pantsMat = new THREE.MeshStandardMaterial({
    color: initial.pantsColor,
    roughness: 0.72,
    metalness: 0.04,
  });
  const hatMat = new THREE.MeshStandardMaterial({
    color: initial.hatColor,
    roughness: 0.34,
    metalness: 0.18,
  });
  const hairMat = new THREE.MeshStandardMaterial({
    color: initial.hairColor || '#18181b',
    roughness: 0.56,
    metalness: 0.08,
  });
  const whiteMat = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    roughness: 0.3,
    metalness: 0.1,
  });
  const shoeMat = new THREE.MeshStandardMaterial({
    color: initial.shoeColor || '#f8fafc',
    roughness: 0.35,
    metalness: 0.2,
  });
  const shoeSoleMat = new THREE.MeshStandardMaterial({
    color: '#09090b',
    emissive: '#000000',
    emissiveIntensity: 0,
    roughness: 0.4,
    metalness: 0.3,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.3,
    metalness: 0.55,
  });
  const goldMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    roughness: 0.22,
    metalness: 0.85,
  });
  const wingMat = new THREE.MeshStandardMaterial({
    color: 0xe0f2fe,
    emissive: 0x38bdf8,
    emissiveIntensity: 0.25,
    roughness: 0.28,
    metalness: 0.2,
  });
  const swordMat = new THREE.MeshStandardMaterial({
    color: 0xf472b6,
    emissive: 0xec4899,
    emissiveIntensity: 0.3,
    roughness: 0.2,
    metalness: 0.7,
  });
  const headphoneGlowMat = new THREE.MeshStandardMaterial({
    color: '#38bdf8',
    emissive: '#38bdf8',
    emissiveIntensity: 0.85,
    roughness: 0.2,
  });

  // Legs + 3D Shoes
  const legGeo = new THREE.BoxGeometry(0.47, 1.0, 0.48);
  const leftLegPivot = new THREE.Group();
  leftLegPivot.position.set(-0.25, 1.0, 0);
  const leftLeg = new THREE.Mesh(legGeo, pantsMat);
  leftLeg.position.set(0, -0.5, 0);
  leftLeg.castShadow = true;
  leftLegPivot.add(leftLeg);

  const rightLegPivot = new THREE.Group();
  rightLegPivot.position.set(0.25, 1.0, 0);
  const rightLeg = new THREE.Mesh(legGeo, pantsMat);
  rightLeg.position.set(0, -0.5, 0);
  rightLeg.castShadow = true;
  rightLegPivot.add(rightLeg);

  const buildShoeMesh = () => {
    const g = new THREE.Group();
    const upper = new THREE.Mesh(new THREE.BoxGeometry(0.51, 0.26, 0.62), shoeMat);
    upper.position.set(0, -0.86, 0.06);
    upper.castShadow = true;
    const sole = new THREE.Mesh(new THREE.BoxGeometry(0.53, 0.1, 0.66), shoeSoleMat);
    sole.position.set(0, -0.96, 0.06);
    const cuff = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.16, 0.52), shoeMat);
    cuff.position.set(0, -0.71, 0);
    g.add(upper, sole, cuff);
    return { g, cuff };
  };
  const leftShoe = buildShoeMesh();
  const rightShoe = buildShoeMesh();
  leftLegPivot.add(leftShoe.g);
  rightLegPivot.add(rightShoe.g);

  bodyGroup.add(leftLegPivot, rightLegPivot);

  // Torso
  const torso = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.04, 0.52), shirtMat);
  torso.position.set(0, 1.52, 0);
  torso.castShadow = true;
  torso.receiveShadow = true;
  bodyGroup.add(torso);

  // Wings
  const wingsGroup = new THREE.Group();
  wingsGroup.position.set(0, 1.65, -0.32);
  const leftWing = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.65, 0.1), wingMat);
  leftWing.position.set(-0.68, 0.12, -0.06);
  leftWing.rotation.y = 0.35;
  leftWing.rotation.z = 0.22;
  const rightWing = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.65, 0.1), wingMat);
  rightWing.position.set(0.68, 0.12, -0.06);
  rightWing.rotation.y = -0.35;
  rightWing.rotation.z = -0.22;
  wingsGroup.add(leftWing, rightWing);
  bodyGroup.add(wingsGroup);

  // Arms
  const armGeo = new THREE.BoxGeometry(0.44, 1.0, 0.46);

  const leftArmPivot = new THREE.Group();
  leftArmPivot.position.set(-0.74, 1.98, 0);
  const leftArm = new THREE.Mesh(armGeo, skinMat);
  leftArm.position.set(0, -0.46, 0);
  leftArm.castShadow = true;
  leftArmPivot.add(leftArm);

  const rightArmPivot = new THREE.Group();
  rightArmPivot.position.set(0.74, 1.98, 0);
  const rightArm = new THREE.Mesh(armGeo, skinMat);
  rightArm.position.set(0, -0.46, 0);
  rightArm.castShadow = true;
  rightArmPivot.add(rightArm);

  // Sword in right hand
  const swordGroup = new THREE.Group();
  swordGroup.position.set(0, -0.92, 0.25);
  const hilt = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.45), accentMat);
  const guard = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.1, 0.1), goldMat);
  guard.position.set(0, 0, 0.24);
  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.08, 1.15), swordMat);
  blade.position.set(0, 0, 0.85);
  swordGroup.add(hilt, guard, blade);
  rightArmPivot.add(swordGroup);

  bodyGroup.add(leftArmPivot, rightArmPivot);

  // Head + Face (with Make Up support)
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 2.46, 0);
  const headMesh = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.82, 0.84), skinMat);
  headMesh.castShadow = true;
  headGroup.add(headMesh);

  let currentMakeup: MakeupStyle = initial.makeup || 'none';
  let currentFaceExpr: FaceExpression = initial.faceExpression || 'auto';
  let currentMood: ResolvedFaceMood =
    currentFaceExpr === 'auto' ? 'neutral' : currentFaceExpr;
  let currentBlink = false;
  let blinkTimer = 1.6;
  let faceTex = createFaceTexture(currentMakeup, currentMood, false);
  const faceMat = new THREE.MeshStandardMaterial({
    map: faceTex,
    transparent: true,
    roughness: 0.4,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const facePlane = new THREE.Mesh(new THREE.PlaneGeometry(0.76, 0.76), faceMat);
  facePlane.position.set(0, 0, 0.425);
  headGroup.add(facePlane);

  const syncFaceTexture = (nextMakeup: MakeupStyle, nextMood: ResolvedFaceMood, nextBlink: boolean) => {
    if (nextMakeup === currentMakeup && nextMood === currentMood && nextBlink === currentBlink) {
      return;
    }
    currentMakeup = nextMakeup;
    currentMood = nextMood;
    currentBlink = nextBlink;
    const nextTex = createFaceTexture(currentMakeup, currentMood, currentBlink);
    faceMat.map = nextTex;
    faceMat.needsUpdate = true;
    faceTex.dispose();
    faceTex = nextTex;
  };

  // Hairstyles (attached inside headGroup so hair rotates/bobs naturally with head)
  const hairGroups: Record<Exclude<HairStyle, 'none'>, THREE.Group> = {
    spiky: new THREE.Group(),
    messy: new THREE.Group(),
    long: new THREE.Group(),
    ponytail: new THREE.Group(),
    mohawk: new THREE.Group(),
    bob: new THREE.Group(),
    curly: new THREE.Group(),
  };

  // Spiky anime hair
  {
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.24, 0.92), hairMat);
    base.position.set(0, 0.38, -0.02);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.55, 0.2), hairMat);
    back.position.set(0, 0.1, -0.44);
    hairGroups.spiky.add(base, back);
    const spikeOffsets: [number, number, number, number, number][] = [
      [-0.25, 0.58, 0.2, 0.2, -0.25],
      [0, 0.62, 0.22, 0.15, 0],
      [0.25, 0.58, 0.2, 0.2, 0.25],
      [-0.22, 0.6, -0.1, -0.2, -0.2],
      [0.22, 0.6, -0.1, -0.2, 0.2],
      [0, 0.65, -0.18, -0.25, 0],
    ];
    spikeOffsets.forEach(([sx, sy, sz, rx, rz]) => {
      const sp = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.42, 6), hairMat);
      sp.position.set(sx, sy, sz);
      sp.rotation.set(rx, 0, rz);
      sp.castShadow = true;
      hairGroups.spiky.add(sp);
    });
  }

  // Messy / Mullet hair
  {
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.28, 0.95), hairMat);
    top.position.set(0, 0.38, -0.01);
    const bangsL = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.24, 0.16), hairMat);
    bangsL.position.set(-0.24, 0.28, 0.44);
    bangsL.rotation.z = 0.16;
    const bangsR = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.22, 0.16), hairMat);
    bangsR.position.set(0.24, 0.3, 0.44);
    bangsR.rotation.z = -0.18;
    const backMullet = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.85, 0.22), hairMat);
    backMullet.position.set(0, -0.08, -0.44);
    hairGroups.messy.add(top, bangsL, bangsR, backMullet);
  }

  // Long hair
  {
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.94, 0.26, 0.94), hairMat);
    top.position.set(0, 0.38, -0.02);
    const backLong = new THREE.Mesh(new THREE.BoxGeometry(0.94, 1.38, 0.22), hairMat);
    backLong.position.set(0, -0.35, -0.44);
    const sideL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 1.15, 0.72), hairMat);
    sideL.position.set(-0.46, -0.18, -0.08);
    const sideR = new THREE.Mesh(new THREE.BoxGeometry(0.16, 1.15, 0.72), hairMat);
    sideR.position.set(0.46, -0.18, -0.08);
    hairGroups.long.add(top, backLong, sideL, sideR);
  }

  // Ponytail hair
  {
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.26, 0.92), hairMat);
    top.position.set(0, 0.38, -0.02);
    const tie = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.16, 10), whiteMat);
    tie.rotation.x = Math.PI / 2;
    tie.position.set(0, 0.22, -0.5);
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.88, 0.26), hairMat);
    tail.position.set(0, -0.18, -0.62);
    tail.rotation.x = 0.24;
    hairGroups.ponytail.add(top, tie, tail);
  }

  // Mohawk hair
  {
    const ridge = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.42, 0.92), hairMat);
    ridge.position.set(0, 0.56, -0.02);
    const backTail = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.45, 0.22), hairMat);
    backTail.position.set(0, 0.14, -0.46);
    hairGroups.mohawk.add(ridge, backTail);
  }

  // Bob cut
  {
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.96, 0.26, 0.96), hairMat);
    top.position.set(0, 0.38, 0);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.96, 0.72, 0.22), hairMat);
    back.position.set(0, 0.02, -0.44);
    const sideL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.68, 0.84), hairMat);
    sideL.position.set(-0.46, 0.04, 0);
    const sideR = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.68, 0.84), hairMat);
    sideR.position.set(0.46, 0.04, 0);
    hairGroups.bob.add(top, back, sideL, sideR);
  }

  // Curly / Afro style
  {
    const puffs: [number, number, number, number][] = [
      [0, 0.52, 0, 0.34],
      [-0.3, 0.42, 0.18, 0.28],
      [0.3, 0.42, 0.18, 0.28],
      [-0.32, 0.4, -0.2, 0.28],
      [0.32, 0.4, -0.2, 0.28],
      [0, 0.38, -0.36, 0.3],
      [-0.42, 0.18, -0.1, 0.24],
      [0.42, 0.18, -0.1, 0.24],
    ];
    puffs.forEach(([px, py, pz, r]) => {
      const puff = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 10), hairMat);
      puff.position.set(px, py, pz);
      puff.castShadow = true;
      hairGroups.curly.add(puff);
    });
  }

  Object.values(hairGroups).forEach((hg) => {
    hg.visible = false;
    headGroup.add(hg);
  });

  // Dynamic UGC Custom 3D Item Groups
  const ugcHeadGroup = new THREE.Group();
  ugcHeadGroup.position.set(0, 0.45, 0);
  headGroup.add(ugcHeadGroup);

  const ugcBackGroup = new THREE.Group();
  ugcBackGroup.position.set(0, 1.55, -0.35);
  bodyGroup.add(ugcBackGroup);

  const ugcHandGroup = new THREE.Group();
  ugcHandGroup.position.set(0, -0.92, 0.18);
  rightArmPivot.add(ugcHandGroup);

  bodyGroup.add(headGroup);

  // Hats (9 cool hat styles)
  const capGroup = new THREE.Group();
  capGroup.position.set(0, 2.9, 0);
  const capCrown = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.28, 0.88), hatMat);
  capCrown.position.set(0, 0.07, 0);
  const capBadge = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.14, 0.04), whiteMat);
  capBadge.position.set(0, 0.08, 0.45);
  const capBrim = new THREE.Mesh(new THREE.BoxGeometry(0.86, 0.09, 0.5), hatMat);
  capBrim.position.set(0, -0.04, 0.57);
  capGroup.add(capCrown, capBadge, capBrim);

  const helmetGroup = new THREE.Group();
  helmetGroup.position.set(0, 2.5, 0);
  const helmetShell = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.9, 0.95), hatMat);
  helmetShell.position.set(0, 0.04, -0.02);
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.32, 0.14), accentMat);
  visor.position.set(0, 0.05, 0.46);
  helmetGroup.add(helmetShell, visor);

  const crownGroup = new THREE.Group();
  crownGroup.position.set(0, 2.9, 0);
  const crownBand = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.2, 0.82), goldMat);
  crownGroup.add(crownBand);
  const spikeGeo = new THREE.ConeGeometry(0.12, 0.3, 4);
  [
    [-0.28, 0.28],
    [0.28, 0.28],
    [-0.28, -0.28],
    [0.28, -0.28],
    [0, 0.32],
  ].forEach(([sx, sz]) => {
    const spike = new THREE.Mesh(spikeGeo, goldMat);
    spike.position.set(sx, 0.22, sz);
    spike.rotation.y = Math.PI / 4;
    crownGroup.add(spike);
  });

  const partyGroup = new THREE.Group();
  partyGroup.position.set(0, 2.9, 0);
  const cone = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.85, 16), hatMat);
  cone.position.y = 0.4;
  const pom = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 12), goldMat);
  pom.position.y = 0.86;
  partyGroup.add(cone, pom);

  const dominoGroup = new THREE.Group();
  dominoGroup.position.set(0, 2.92, 0);
  const domBase = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.2, 0.9), accentMat);
  dominoGroup.add(domBase);
  for (let i = -1; i <= 1; i++) {
    const tile = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.42, 0.14), i === 0 ? goldMat : accentMat);
    tile.position.set(i * 0.28, 0.26, 0.34);
    dominoGroup.add(tile);
  }

  // Beanie Hat (Kupluk Cozy)
  const beanieGroup = new THREE.Group();
  beanieGroup.position.set(0, 2.86, 0);
  const beanieCuff = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.2, 0.92), whiteMat);
  beanieCuff.position.y = 0.02;
  const beanieDome = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.34, 0.84), hatMat);
  beanieDome.position.y = 0.24;
  const beaniePom = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 12), whiteMat);
  beaniePom.position.y = 0.48;
  beanieGroup.add(beanieCuff, beanieDome, beaniePom);

  // Gaming Headphones
  const headphonesGroup = new THREE.Group();
  headphonesGroup.position.set(0, 2.48, 0);
  const hpBandTop = new THREE.Mesh(new THREE.BoxGeometry(0.98, 0.12, 0.24), accentMat);
  hpBandTop.position.y = 0.48;
  const hpBandL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.48, 0.22), accentMat);
  hpBandL.position.set(-0.48, 0.22, 0);
  const hpBandR = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.48, 0.22), accentMat);
  hpBandR.position.set(0.48, 0.22, 0);
  const hpCupL = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.16, 16), hatMat);
  hpCupL.rotation.z = Math.PI / 2;
  hpCupL.position.set(-0.52, 0.02, 0);
  const hpCupR = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.16, 16), hatMat);
  hpCupR.rotation.z = Math.PI / 2;
  hpCupR.position.set(0.52, 0.02, 0);
  const hpRingL = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.035, 8, 20), headphoneGlowMat);
  hpRingL.rotation.y = Math.PI / 2;
  hpRingL.position.set(-0.6, 0.02, 0);
  const hpRingR = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.035, 8, 20), headphoneGlowMat);
  hpRingR.rotation.y = Math.PI / 2;
  hpRingR.position.set(0.6, 0.02, 0);
  headphonesGroup.add(hpBandTop, hpBandL, hpBandR, hpCupL, hpCupR, hpRingL, hpRingR);

  // Wizard Hat
  const wizardGroup = new THREE.Group();
  wizardGroup.position.set(0, 2.88, 0);
  const wizBrim = new THREE.Mesh(new THREE.CylinderGeometry(0.84, 0.88, 0.08, 18), hatMat);
  wizBrim.position.y = 0.02;
  const wizBand = new THREE.Mesh(new THREE.CylinderGeometry(0.44, 0.48, 0.14, 16), goldMat);
  wizBand.position.y = 0.12;
  const wizCone = new THREE.Mesh(new THREE.ConeGeometry(0.46, 1.05, 16), hatMat);
  wizCone.position.set(0, 0.62, -0.05);
  wizCone.rotation.x = -0.14;
  wizardGroup.add(wizBrim, wizBand, wizCone);

  // Cyber Horns
  const hornsGroup = new THREE.Group();
  hornsGroup.position.set(0, 2.86, 0);
  const hornGeo = new THREE.ConeGeometry(0.13, 0.56, 10);
  const leftHorn = new THREE.Mesh(hornGeo, hatMat);
  leftHorn.position.set(-0.34, 0.22, 0.08);
  leftHorn.rotation.z = 0.42;
  leftHorn.rotation.x = 0.18;
  const rightHorn = new THREE.Mesh(hornGeo, hatMat);
  rightHorn.position.set(0.34, 0.22, 0.08);
  rightHorn.rotation.z = -0.42;
  rightHorn.rotation.x = 0.18;
  const hornTipL = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.22, 8), headphoneGlowMat);
  hornTipL.position.set(-0.44, 0.45, 0.12);
  hornTipL.rotation.z = 0.42;
  hornTipL.rotation.x = 0.18;
  const hornTipR = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.22, 8), headphoneGlowMat);
  hornTipR.position.set(0.44, 0.45, 0.12);
  hornTipR.rotation.z = -0.42;
  hornTipR.rotation.x = 0.18;
  hornsGroup.add(leftHorn, rightHorn, hornTipL, hornTipR);

  bodyGroup.add(
    capGroup,
    helmetGroup,
    crownGroup,
    partyGroup,
    dominoGroup,
    beanieGroup,
    headphonesGroup,
    wizardGroup,
    hornsGroup
  );

  // 3D Accessory Aura / Particle Effects Group
  const effectGroup = new THREE.Group();
  const effectRingMat = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    emissive: '#ffffff',
    emissiveIntensity: 0.8,
    roughness: 0.2,
    transparent: true,
    opacity: 0.72,
  });
  const effectRing = new THREE.Mesh(new THREE.TorusGeometry(0.92, 0.045, 8, 28), effectRingMat);
  effectRing.rotation.x = Math.PI / 2;
  effectRing.position.y = 0.15;
  effectGroup.add(effectRing);

  const effectOrbGeo = new THREE.OctahedronGeometry(0.14, 0);
  const effectOrbs: THREE.Mesh[] = [];
  const effectOrbMats: THREE.MeshStandardMaterial[] = [];
  for (let i = 0; i < 8; i++) {
    const mat = new THREE.MeshStandardMaterial({
      color: '#ffffff',
      emissive: '#ffffff',
      emissiveIntensity: 0.9,
      roughness: 0.2,
    });
    const m = new THREE.Mesh(effectOrbGeo, mat);
    effectGroup.add(m);
    effectOrbs.push(m);
    effectOrbMats.push(mat);
  }
  root.add(effectGroup);

  // 3D Foot Aura Rings & Foot Trail Particle Pool (Aura & Trail Kaki)
  const footTrailGroup = new THREE.Group();
  const footRingMat = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    emissive: '#ffffff',
    emissiveIntensity: 0.9,
    transparent: true,
    opacity: 0.75,
    roughness: 0.2,
  });
  const footRingGeo = new THREE.TorusGeometry(0.32, 0.04, 8, 22);
  const leftFootRing = new THREE.Mesh(footRingGeo, footRingMat);
  leftFootRing.rotation.x = Math.PI / 2;
  leftFootRing.position.set(-0.25, 0.06, 0);
  const rightFootRing = new THREE.Mesh(footRingGeo, footRingMat);
  rightFootRing.rotation.x = Math.PI / 2;
  rightFootRing.position.set(0.25, 0.06, 0);
  footTrailGroup.add(leftFootRing, rightFootRing);

  const trailBoxGeo = new THREE.BoxGeometry(0.2, 0.2, 0.2);
  const trailOctGeo = new THREE.OctahedronGeometry(0.14, 0);
  interface TrailParticle {
    mesh: THREE.Mesh;
    mat: THREE.MeshStandardMaterial;
    age: number;
    life: number;
    vx: number;
    vy: number;
    vz: number;
    active: boolean;
  }
  const trailParticles: TrailParticle[] = [];
  for (let i = 0; i < 24; i++) {
    const mat = new THREE.MeshStandardMaterial({
      color: '#ffffff',
      emissive: '#ffffff',
      emissiveIntensity: 0.95,
      transparent: true,
      opacity: 0,
      roughness: 0.25,
    });
    const mesh = new THREE.Mesh(i % 2 === 0 ? trailBoxGeo : trailOctGeo, mat);
    mesh.visible = false;
    footTrailGroup.add(mesh);
    trailParticles.push({
      mesh,
      mat,
      age: 0,
      life: 0.55,
      vx: 0,
      vy: 0,
      vz: 0,
      active: false,
    });
  }
  root.add(footTrailGroup);

  // Overhead Floating Name Tag Sprite
  let nameTex: THREE.CanvasTexture | null = null;
  const nameMat = new THREE.SpriteMaterial({ transparent: true, depthTest: false });
  const nameSprite = new THREE.Sprite(nameMat);
  nameSprite.position.set(0, 3.65, 0);
  nameSprite.scale.set(2.9, 0.72, 1);
  nameSprite.renderOrder = 20;
  nameSprite.visible = false;
  root.add(nameSprite);

  // Overhead Speech Bubble Sprite (when player types chat)
  let chatTex: THREE.CanvasTexture | null = null;
  const chatMat = new THREE.SpriteMaterial({ transparent: true, depthTest: false });
  const chatSprite = new THREE.Sprite(chatMat);
  chatSprite.position.set(0, 4.55, 0);
  chatSprite.scale.set(3.8, 1.14, 1);
  chatSprite.renderOrder = 25;
  chatSprite.visible = false;
  root.add(chatSprite);

  // Overhead Voice Chat Logo + Dynamic Sound Bars Sprite
  const voiceCanvas = document.createElement('canvas');
  voiceCanvas.width = 256;
  voiceCanvas.height = 96;
  const voiceCtx = voiceCanvas.getContext('2d')!;
  const voiceTex = new THREE.CanvasTexture(voiceCanvas);
  voiceTex.colorSpace = THREE.SRGBColorSpace;
  const voiceMat = new THREE.SpriteMaterial({ map: voiceTex, transparent: true, depthTest: false });
  const voiceSprite = new THREE.Sprite(voiceMat);
  voiceSprite.position.set(0, 4.25, 0);
  voiceSprite.scale.set(1.9, 0.72, 1);
  voiceSprite.renderOrder = 24;
  voiceSprite.visible = false;
  root.add(voiceSprite);

  let chatRemaining = 0;
  let bodyScale = THREE.MathUtils.clamp(initial.bodyScale || 1, 0.5, 1.3);

  const updateOverheadPositions = () => {
    const scaleFactor = Math.max(0.65, bodyScale);
    nameSprite.position.set(0, 3.65 * bodyScale + 0.15, 0);
    nameSprite.scale.set(2.9 * scaleFactor, 0.72 * scaleFactor, 1);
    voiceSprite.position.set(0, 3.65 * bodyScale + 0.72, 0);
    voiceSprite.scale.set(1.9 * scaleFactor, 0.72 * scaleFactor, 1);
    chatSprite.position.set(0, 3.65 * bodyScale + (voiceSprite.visible ? 1.45 : 0.95), 0);
    chatSprite.scale.set(3.8 * scaleFactor, 1.14 * scaleFactor, 1);
  };

  const setNameTag = (name: string | null, isPlus = false) => {
    if (!name) {
      nameSprite.visible = false;
      return;
    }
    if (nameTex) nameTex.dispose();
    nameTex = drawNameTagTexture(name, isPlus);
    nameMat.map = nameTex;
    nameMat.needsUpdate = true;
    nameSprite.visible = true;
  };
  if (nameTagText) setNameTag(nameTagText, false);

  const setChatBubble = (text: string | null) => {
    if (!text || !text.trim()) {
      chatSprite.visible = false;
      chatRemaining = 0;
      return;
    }
    if (chatTex) chatTex.dispose();
    chatTex = drawChatBubbleTexture(text);
    chatMat.map = chatTex;
    chatMat.needsUpdate = true;
    chatSprite.visible = true;
    chatRemaining = 5.0;
    updateOverheadPositions();
  };

  const setVoiceState = (active: boolean, bars: [number, number, number, number, number]) => {
    const prevVis = voiceSprite.visible;
    voiceSprite.visible = active;
    if (prevVis !== active) {
      updateOverheadPositions();
    }
    if (!active) return;

    const avg = (bars[0] + bars[1] + bars[2] + bars[3] + bars[4]) / 5;
    const isTalking = avg > 0.14;

    voiceCtx.clearRect(0, 0, voiceCanvas.width, voiceCanvas.height);
    // Pill container
    voiceCtx.fillStyle = isTalking ? 'rgba(9, 9, 11, 0.94)' : 'rgba(24, 24, 27, 0.86)';
    voiceCtx.beginPath();
    voiceCtx.roundRect(14, 12, 228, 72, 36);
    voiceCtx.fill();

    voiceCtx.strokeStyle = isTalking ? '#22c55e' : 'rgba(255,255,255,0.5)';
    voiceCtx.lineWidth = 4;
    voiceCtx.stroke();

    // Mic Icon on left
    const micCx = 54;
    const micCy = 46;
    voiceCtx.fillStyle = isTalking ? '#22c55e' : '#ffffff';
    voiceCtx.beginPath();
    voiceCtx.roundRect(micCx - 8, micCy - 16, 16, 22, 8);
    voiceCtx.fill();

    voiceCtx.strokeStyle = isTalking ? '#22c55e' : '#ffffff';
    voiceCtx.lineWidth = 3.5;
    voiceCtx.beginPath();
    voiceCtx.arc(micCx, micCy + 2, 13, 0, Math.PI);
    voiceCtx.stroke();
    voiceCtx.beginPath();
    voiceCtx.moveTo(micCx, micCy + 15);
    voiceCtx.lineTo(micCx, micCy + 22);
    voiceCtx.moveTo(micCx - 8, micCy + 22);
    voiceCtx.lineTo(micCx + 8, micCy + 22);
    voiceCtx.stroke();

    // 5 Dynamic Equalizer Bars responding to speech pitch & volume
    bars.forEach((val, idx) => {
      const barW = 12;
      const gap = 8;
      const bx = 94 + idx * (barW + gap);
      const bh = Math.max(10, Math.min(44, 10 + val * 36));
      const by = 48 - bh / 2;
      voiceCtx.fillStyle = isTalking ? '#4ade80' : '#d4d4d8';
      voiceCtx.beginPath();
      voiceCtx.roundRect(bx, by, barW, bh, 6);
      voiceCtx.fill();
    });

    voiceTex.needsUpdate = true;
  };

  let currentEffect: AccessoryEffect = initial.effect || 'none';
  let currentFootTrail: FootTrailStyle = initial.footTrail || 'none';
  let currentUgcKey = '';

  const rebuildUgcMeshes = (attachment?: UgcItemAttachment | null) => {
    const key = attachment
      ? `${attachment.id}:${attachment.slot}:${JSON.stringify(attachment.parts)}`
      : '';
    if (key === currentUgcKey) return;
    currentUgcKey = key;

    [ugcHeadGroup, ugcBackGroup, ugcHandGroup].forEach((grp) => {
      while (grp.children.length > 0) {
        const child = grp.children[0] as THREE.Mesh;
        grp.remove(child);
        if (child.isMesh) {
          child.geometry.dispose();
          if (Array.isArray(child.material)) child.material.forEach((m) => m.dispose());
          else child.material.dispose();
        }
      }
    });

    if (!attachment || attachment.parts.length === 0) return;

    const targetGroup =
      attachment.slot === 'back'
        ? ugcBackGroup
        : attachment.slot === 'hand'
        ? ugcHandGroup
        : ugcHeadGroup;

    for (const pt of attachment.parts) {
      const geo =
        pt.shape === 'cylinder'
          ? new THREE.CylinderGeometry(pt.sx * 0.5, pt.sx * 0.5, pt.sy, 14)
          : pt.shape === 'sphere'
          ? new THREE.SphereGeometry(0.5, 14, 14)
          : new THREE.BoxGeometry(pt.sx, pt.sy, pt.sz);
      const mat = new THREE.MeshStandardMaterial({
        color: pt.color,
        roughness: 0.35,
        metalness: 0.18,
      });
      const mesh = new THREE.Mesh(geo, mat);
      if (pt.shape === 'sphere') {
        mesh.scale.set(pt.sx, pt.sy, pt.sz);
      }
      mesh.position.set(pt.x, pt.y, pt.z);
      mesh.rotation.set(
        THREE.MathUtils.degToRad(pt.rx ?? 0),
        THREE.MathUtils.degToRad(pt.ry ?? 0),
        THREE.MathUtils.degToRad(pt.rz ?? 0)
      );
      mesh.castShadow = true;
      targetGroup.add(mesh);
    }
  };

  const applyConfig = (cfg: AvatarConfig) => {
    skinMat.color.set(cfg.skinColor);
    shirtMat.color.set(cfg.shirtColor);
    pantsMat.color.set(cfg.pantsColor);
    hatMat.color.set(cfg.hatColor);
    hairMat.color.set(cfg.hairColor || '#18181b');
    headGroup.visible = !cfg.headless;
    wingsGroup.visible = cfg.hasWings;
    swordGroup.visible = cfg.hasSword;
    capGroup.visible = cfg.hatStyle === 'cap';
    helmetGroup.visible = cfg.hatStyle === 'helmet';
    crownGroup.visible = cfg.hatStyle === 'crown';
    partyGroup.visible = cfg.hatStyle === 'party';
    dominoGroup.visible = cfg.hatStyle === 'domino';
    beanieGroup.visible = cfg.hatStyle === 'beanie';
    headphonesGroup.visible = cfg.hatStyle === 'headphones';
    wizardGroup.visible = cfg.hatStyle === 'wizard';
    hornsGroup.visible = cfg.hatStyle === 'horns';

    const activeHair = cfg.hairStyle || 'none';
    (Object.keys(hairGroups) as Exclude<HairStyle, 'none'>[]).forEach((style) => {
      hairGroups[style].visible = activeHair === style;
    });

    rebuildUgcMeshes(cfg.ugcAttachment);

    // Body Scale
    bodyScale = THREE.MathUtils.clamp(cfg.bodyScale ?? 1, 0.5, 1.3);
    effectGroup.scale.setScalar(bodyScale);
    footTrailGroup.scale.setScalar(bodyScale);
    updateOverheadPositions();

    // Make Up & Face Expression
    const nextMakeup: MakeupStyle = cfg.makeup || 'none';
    currentFaceExpr = cfg.faceExpression || 'auto';
    const nextMood: ResolvedFaceMood =
      currentFaceExpr === 'auto' ? 'neutral' : currentFaceExpr;
    syncFaceTexture(nextMakeup, nextMood, false);

    // Shoes appearance
    const shoeStyle = cfg.shoeStyle || 'none';
    const hasShoes = shoeStyle !== 'none';
    leftShoe.g.visible = hasShoes;
    rightShoe.g.visible = hasShoes;
    const isBoots = shoeStyle === 'boots' || shoeStyle === 'flame' || shoeStyle === 'cyber';
    leftShoe.cuff.visible = isBoots;
    rightShoe.cuff.visible = isBoots;
    shoeMat.color.set(shoeStyle === 'gold' ? '#facc15' : cfg.shoeColor || '#f8fafc');
    shoeMat.metalness = shoeStyle === 'gold' ? 0.85 : 0.2;
    if (shoeStyle === 'cyber') {
      shoeSoleMat.color.set('#38bdf8');
      shoeSoleMat.emissive.set('#0ea5e9');
      shoeSoleMat.emissiveIntensity = 0.85;
    } else if (shoeStyle === 'flame') {
      shoeSoleMat.color.set('#f97316');
      shoeSoleMat.emissive.set('#ea580c');
      shoeSoleMat.emissiveIntensity = 0.9;
    } else {
      shoeSoleMat.color.set('#09090b');
      shoeSoleMat.emissive.set('#000000');
      shoeSoleMat.emissiveIntensity = 0;
    }

    // Accessory aura effects
    currentEffect = cfg.effect || 'none';
    effectGroup.visible = currentEffect !== 'none';
    if (currentEffect !== 'none') {
      const palette = EFFECT_PALETTES[currentEffect];
      effectRingMat.color.set(palette[0]);
      effectRingMat.emissive.set(palette[0]);
      effectOrbMats.forEach((m, i) => {
        const c = palette[i % palette.length];
        m.color.set(c);
        m.emissive.set(c);
      });
    }

    // Foot Trail & Foot Aura
    currentFootTrail = cfg.footTrail || 'none';
    footTrailGroup.visible = currentFootTrail !== 'none';
    if (currentFootTrail !== 'none') {
      const tPalette = FOOT_TRAIL_PALETTES[currentFootTrail];
      footRingMat.color.set(tPalette[0]);
      footRingMat.emissive.set(tPalette[0]);
    } else {
      trailParticles.forEach((p) => {
        p.active = false;
        p.mesh.visible = false;
      });
    }
  };
  applyConfig(initial);

  let walkPhase = 0;
  let idlePhase = 0;
  let effectTime = 0;
  let trailSpawnAccum = 0;
  let trailStepIndex = 0;
  let wasGrounded = true;
  let squash = 0;
  let flipAngle = 0;

  return {
    root,
    bodyGroup,
    headGroup,
    leftArmPivot,
    rightArmPivot,
    leftLegPivot,
    rightLegPivot,
    setNameTag,
    setChatBubble,
    setVoiceState,
    updateAppearance: applyConfig,
    updateAnimation(
      dt: number,
      speedRatio: number,
      isGrounded: boolean,
      verticalVel: number,
      walkAnim: WalkAnimStyle = 'default',
      jumpAnim: JumpAnimStyle = 'default',
      activeEmote: EmoteId | null = null,
      emoteElapsed = 0,
      idleAnim: IdleAnimStyle = 'default'
    ) {
      if (chatRemaining > 0) {
        chatRemaining -= dt;
        if (chatRemaining <= 0) {
          chatRemaining = 0;
          chatSprite.visible = false;
        }
      }

      if (!wasGrounded && isGrounded) {
        squash = 0.2;
        flipAngle = 0;
      }
      wasGrounded = isGrounded;
      squash = THREE.MathUtils.damp(squash, 0, 14, dt);

      if (currentEffect !== 'none') {
        effectTime += dt;
        const speedMul = currentEffect === 'lightning' ? 5.2 : currentEffect === 'fire' ? 3.8 : 2.6;
        effectRing.rotation.z = effectTime * speedMul;
        effectRing.scale.setScalar(1 + Math.sin(effectTime * 4) * 0.06);
        effectOrbs.forEach((orb, i) => {
          const ang = effectTime * speedMul + (i / effectOrbs.length) * Math.PI * 2;
          const rad = 0.95 + Math.sin(effectTime * 3 + i) * 0.14;
          const yBase =
            currentEffect === 'fire'
              ? ((effectTime * 1.4 + i * 0.4) % 2.6) + 0.2
              : 1.45 + Math.sin(effectTime * 3.2 + i * 0.9) * 0.75;
          orb.position.set(Math.cos(ang) * rad, yBase, Math.sin(ang) * rad);
          orb.rotation.x += dt * 4;
          orb.rotation.y += dt * 5;
        });
      }

      // Dynamic Face Expressions & Auto Blinking
      blinkTimer -= dt;
      if (blinkTimer <= -0.13) {
        blinkTimer = 2.8 + ((trailStepIndex * 37) % 15) * 0.12;
      }
      const nextBlink = blinkTimer < 0;
      let targetMood: ResolvedFaceMood;
      if (currentFaceExpr === 'auto') {
        if (!isGrounded && verticalVel < -5) {
          targetMood = 'surprised';
        } else if (activeEmote === 'wave' || activeEmote === 'dance' || activeEmote === 'clap') {
          targetMood = 'happy';
        } else if (activeEmote === 'salute') {
          targetMood = 'cool';
        } else if (activeEmote === 'sit') {
          targetMood = 'wink';
        } else if (idleAnim === 'sleepy' && speedRatio <= 0.05) {
          targetMood = 'sleepy';
        } else if (speedRatio > 1.08) {
          targetMood = 'cool';
        } else if (chatRemaining > 3.2) {
          targetMood = 'happy';
        } else {
          targetMood = 'neutral';
        }
      } else {
        targetMood = currentFaceExpr;
      }
      const canBlink = targetMood !== 'cool' && targetMood !== 'sleepy';
      syncFaceTexture(currentMakeup, targetMood, canBlink && nextBlink);

      // Aura & Trail Kaki (Foot Trail Particles + Ankle Rings)
      if (currentFootTrail !== 'none') {
        const tPalette = FOOT_TRAIL_PALETTES[currentFootTrail];
        const ringPulse = 1 + Math.sin(performance.now() * 0.008) * 0.12;
        leftFootRing.scale.setScalar(ringPulse);
        rightFootRing.scale.setScalar(ringPulse);
        leftFootRing.rotation.z += dt * 4;
        rightFootRing.rotation.z -= dt * 4;

        const isMovingOrAir = speedRatio > 0.06 || !isGrounded;
        const spawnInterval = isMovingOrAir ? (speedRatio > 1.05 ? 0.032 : 0.05) : 0.18;
        trailSpawnAccum += dt;
        if (trailSpawnAccum >= spawnInterval) {
          trailSpawnAccum = 0;
          const slot = trailParticles.find((p) => !p.active) || trailParticles[0];
          const footSide = trailStepIndex % 2 === 0 ? -0.25 : 0.25;
          const colorHex = tPalette[trailStepIndex % tPalette.length];
          trailStepIndex += 1;

          slot.active = true;
          slot.age = 0;
          slot.life = isMovingOrAir ? 0.58 : 0.45;
          slot.mesh.visible = true;
          slot.mesh.position.set(
            footSide + (Math.random() - 0.5) * 0.16,
            0.12 + Math.random() * 0.08,
            isMovingOrAir ? -0.18 : (Math.random() - 0.5) * 0.22
          );
          slot.vx = (Math.random() - 0.5) * (currentFootTrail === 'lightning' ? 1.8 : 0.65);
          slot.vy = currentFootTrail === 'fire' || currentFootTrail === 'hearts' ? 1.15 : 0.55;
          slot.vz = isMovingOrAir ? -(1.8 + speedRatio * 1.4) : -0.35;
          slot.mat.color.set(colorHex);
          slot.mat.emissive.set(colorHex);
          slot.mat.opacity = 0.95;
          slot.mesh.scale.setScalar(isMovingOrAir ? 1.0 : 0.72);
        }

        for (const p of trailParticles) {
          if (!p.active) continue;
          p.age += dt;
          if (p.age >= p.life) {
            p.active = false;
            p.mesh.visible = false;
            continue;
          }
          const ratio = p.age / p.life;
          p.mesh.position.x += p.vx * dt;
          p.mesh.position.y += p.vy * dt;
          p.mesh.position.z += p.vz * dt;
          p.mesh.rotation.x += dt * 5;
          p.mesh.rotation.y += dt * 6;
          const s = Math.max(0.05, 1 - ratio * 0.85);
          p.mesh.scale.setScalar(s);
          p.mat.opacity = 1 - ratio;
        }
      }

      let targetBodyRotX = 0;
      let targetBodyRotY = 0;
      let targetBodyRotZ = 0;
      let targetBodyPosY = 0;
      let targetLeftArmZ = 0;
      let targetRightArmZ = 0;
      let targetHeadRotX = 0;
      let targetHeadRotY = 0;

      if (activeEmote && isGrounded && speedRatio <= 0.08) {
        if (activeEmote === 'wave') {
          targetRightArmZ = -2.55 + Math.sin(emoteElapsed * 10) * 0.45;
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, -0.2, 14, dt);
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, 0.1, 14, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0, 14, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, 0, 14, dt);
        } else if (activeEmote === 'dance') {
          const groove = emoteElapsed * 9;
          targetBodyPosY = Math.abs(Math.sin(groove)) * 0.28;
          targetBodyRotZ = Math.sin(groove * 0.5) * 0.18;
          leftArmPivot.rotation.x = Math.sin(groove) * 1.1 - 0.6;
          rightArmPivot.rotation.x = -Math.sin(groove) * 1.1 - 0.6;
          targetLeftArmZ = 0.45;
          targetRightArmZ = -0.45;
          leftLegPivot.rotation.x = Math.sin(groove) * 0.55;
          rightLegPivot.rotation.x = -Math.sin(groove) * 0.55;
        } else if (activeEmote === 'clap') {
          const c = Math.abs(Math.sin(emoteElapsed * 12));
          leftArmPivot.rotation.x = -1.35;
          rightArmPivot.rotation.x = -1.35;
          targetLeftArmZ = -0.45 + c * 0.35;
          targetRightArmZ = 0.45 - c * 0.35;
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0, 12, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, 0, 12, dt);
        } else if (activeEmote === 'spin') {
          targetBodyRotY = emoteElapsed * 9;
          targetBodyPosY = Math.abs(Math.sin(emoteElapsed * 6)) * 0.35;
          targetLeftArmZ = 1.25;
          targetRightArmZ = -1.25;
          leftArmPivot.rotation.x = 0;
          rightArmPivot.rotation.x = 0;
        } else if (activeEmote === 'salute') {
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, -2.15, 16, dt);
          targetRightArmZ = 0.25;
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, 0.05, 14, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0, 14, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, 0, 14, dt);
        } else if (activeEmote === 'sit') {
          targetBodyPosY = -0.58;
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, -1.42, 14, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, -1.42, 14, dt);
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, -0.35, 14, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, -0.35, 14, dt);
        }
      } else if (!isGrounded) {
        if (jumpAnim === 'flip') {
          flipAngle += dt * 10.5;
          targetBodyRotX = flipAngle;
          leftArmPivot.rotation.x = -1.4;
          rightArmPivot.rotation.x = -1.4;
          leftLegPivot.rotation.x = -0.8;
          rightLegPivot.rotation.x = -0.8;
        } else if (jumpAnim === 'superhero') {
          targetBodyRotX = 0.22;
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, -2.75, 14, dt);
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, 0.75, 14, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, -0.95, 14, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0.25, 14, dt);
        } else if (jumpAnim === 'float') {
          targetLeftArmZ = 1.15;
          targetRightArmZ = -1.15;
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, 0, 12, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, 0, 12, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0.15, 12, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, -0.15, 12, dt);
        } else {
          const armRaise = THREE.MathUtils.clamp(verticalVel * 0.08 + 0.9, -0.4, 1.8);
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, -armRaise, 12, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, -armRaise, 12, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0.35, 12, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, -0.35, 12, dt);
        }
      } else if (speedRatio > 0.05) {
        const amp = Math.min(speedRatio, 1.2);
        if (walkAnim === 'ninja') {
          walkPhase += dt * (11 + speedRatio * 7);
          const swing = Math.sin(walkPhase) * 0.95 * amp;
          targetBodyRotX = 0.28;
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, 1.15, 16, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, 1.15, 16, dt);
          leftLegPivot.rotation.x = swing;
          rightLegPivot.rotation.x = -swing;
          targetBodyPosY = Math.abs(Math.sin(walkPhase)) * 0.1;
        } else if (walkAnim === 'robot') {
          walkPhase += dt * 8;
          const step = Math.sign(Math.sin(walkPhase)) * 0.72;
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, step, 18, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, -step, 18, dt);
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, -step * 0.8, 18, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, step * 0.8, 18, dt);
        } else if (walkAnim === 'hero') {
          walkPhase += dt * (7.5 + speedRatio * 4.5);
          const swing = Math.sin(walkPhase) * 0.82 * amp;
          targetBodyRotX = -0.08;
          targetBodyRotY = Math.sin(walkPhase) * 0.12;
          leftLegPivot.rotation.x = swing;
          rightLegPivot.rotation.x = -swing;
          leftArmPivot.rotation.x = -swing * 0.7;
          rightArmPivot.rotation.x = swing * 0.7;
          targetLeftArmZ = 0.16;
          targetRightArmZ = -0.16;
          targetBodyPosY = Math.abs(Math.sin(walkPhase)) * 0.06;
        } else if (walkAnim === 'bouncy') {
          walkPhase += dt * (10 + speedRatio * 5);
          const swing = Math.sin(walkPhase) * 0.95 * amp;
          leftLegPivot.rotation.x = swing;
          rightLegPivot.rotation.x = -swing;
          leftArmPivot.rotation.x = -swing;
          rightArmPivot.rotation.x = swing;
          targetLeftArmZ = 0.3;
          targetRightArmZ = -0.3;
          targetBodyPosY = Math.abs(Math.sin(walkPhase)) * 0.24;
        } else {
          walkPhase += dt * (8 + speedRatio * 6);
          const swing = Math.sin(walkPhase) * 0.85 * Math.min(speedRatio, 1);
          leftLegPivot.rotation.x = swing;
          rightLegPivot.rotation.x = -swing;
          leftArmPivot.rotation.x = -swing * 0.85;
          rightArmPivot.rotation.x = swing * 0.85;
          targetBodyPosY = Math.abs(Math.sin(walkPhase)) * 0.08 * Math.min(speedRatio, 1);
        }
      } else {
        // Idle Animations when standing still
        idlePhase += dt * 2.6;
        if (idleAnim === 'cool') {
          // Santai Keren: pose miring dengan tangan agak keluar dan kepala menoleh pelan
          targetBodyRotY = 0.22 + Math.sin(idlePhase * 0.6) * 0.08;
          targetBodyPosY = Math.sin(idlePhase * 1.2) * 0.03;
          targetHeadRotY = -0.18 + Math.sin(idlePhase * 0.7) * 0.12;
          targetLeftArmZ = -0.32;
          targetRightArmZ = 0.22;
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, -0.35, 10, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, 0.12, 10, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0.08, 10, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, -0.1, 10, dt);
        } else if (idleAnim === 'bounce') {
          // Joget Kecil: memantul ceria saat diam
          const b = Math.abs(Math.sin(idlePhase * 1.7));
          targetBodyPosY = b * 0.14;
          targetBodyRotZ = Math.sin(idlePhase * 1.7) * 0.08;
          targetLeftArmZ = 0.26 + Math.sin(idlePhase * 1.7) * 0.12;
          targetRightArmZ = -0.26 + Math.sin(idlePhase * 1.7) * 0.12;
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, -0.45 + Math.sin(idlePhase * 3.4) * 0.18, 12, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, -0.45 - Math.sin(idlePhase * 3.4) * 0.18, 12, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0, 12, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, 0, 12, dt);
        } else if (idleAnim === 'ninja') {
          // Siaga Ninja: posisi rendah siap tempur
          targetBodyPosY = -0.12 + Math.sin(idlePhase * 1.4) * 0.03;
          targetBodyRotX = 0.18;
          targetBodyRotY = -0.32;
          targetHeadRotY = 0.28;
          targetLeftArmZ = 0.35;
          targetRightArmZ = -0.25;
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, -0.95 + Math.sin(idlePhase) * 0.08, 12, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, -0.45 - Math.sin(idlePhase) * 0.08, 12, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, -0.35, 12, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, 0.35, 12, dt);
        } else if (idleAnim === 'hero') {
          // Gagah Pahlawan: dada membusung & ayunan tangan heroik
          targetBodyPosY = Math.sin(idlePhase * 1.1) * 0.04;
          targetBodyRotX = -0.06;
          targetLeftArmZ = 0.28 + Math.sin(idlePhase * 1.1) * 0.04;
          targetRightArmZ = -0.28 - Math.sin(idlePhase * 1.1) * 0.04;
          targetHeadRotX = -0.05;
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, -0.15, 10, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, -0.15, 10, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0, 10, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, 0, 10, dt);
        } else if (idleAnim === 'sleepy') {
          // Mengantuk Santai: anggukan pelan & badan goyang ringan
          targetBodyPosY = Math.sin(idlePhase * 0.7) * 0.025;
          targetBodyRotZ = Math.sin(idlePhase * 0.55) * 0.07;
          targetHeadRotX = 0.16 + Math.max(0, Math.sin(idlePhase * 0.9)) * 0.18;
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, 0.08, 8, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, 0.08, 8, dt);
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0, 10, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, 0, 10, dt);
        } else {
          // Default breathing
          const idle = Math.sin(idlePhase * 0.85) * 0.06;
          targetBodyPosY = Math.sin(idlePhase * 0.85) * 0.02;
          targetHeadRotY = Math.sin(idlePhase * 0.4) * 0.08;
          leftLegPivot.rotation.x = THREE.MathUtils.damp(leftLegPivot.rotation.x, 0, 10, dt);
          rightLegPivot.rotation.x = THREE.MathUtils.damp(rightLegPivot.rotation.x, 0, 10, dt);
          leftArmPivot.rotation.x = THREE.MathUtils.damp(leftArmPivot.rotation.x, idle, 10, dt);
          rightArmPivot.rotation.x = THREE.MathUtils.damp(rightArmPivot.rotation.x, -idle, 10, dt);
        }
      }

      bodyGroup.scale.set(
        bodyScale * (1 + squash * 0.3),
        bodyScale * (1 - squash * 0.4),
        bodyScale * (1 + squash * 0.3)
      );
      bodyGroup.position.y = THREE.MathUtils.damp(bodyGroup.position.y, targetBodyPosY * bodyScale, 14, dt);
      bodyGroup.rotation.x =
        jumpAnim === 'flip' && !isGrounded
          ? targetBodyRotX
          : THREE.MathUtils.damp(bodyGroup.rotation.x, targetBodyRotX, 14, dt);
      bodyGroup.rotation.y =
        activeEmote === 'spin'
          ? targetBodyRotY
          : THREE.MathUtils.damp(bodyGroup.rotation.y, targetBodyRotY, 14, dt);
      bodyGroup.rotation.z = THREE.MathUtils.damp(bodyGroup.rotation.z, targetBodyRotZ, 14, dt);
      headGroup.rotation.x = THREE.MathUtils.damp(headGroup.rotation.x, targetHeadRotX, 10, dt);
      headGroup.rotation.y = THREE.MathUtils.damp(headGroup.rotation.y, targetHeadRotY, 10, dt);
      leftArmPivot.rotation.z = THREE.MathUtils.damp(leftArmPivot.rotation.z, targetLeftArmZ, 14, dt);
      rightArmPivot.rotation.z = THREE.MathUtils.damp(rightArmPivot.rotation.z, targetRightArmZ, 14, dt);
    },
    dispose() {
      faceTex.dispose();
      if (nameTex) nameTex.dispose();
      if (chatTex) chatTex.dispose();
      voiceTex.dispose();
      nameMat.dispose();
      chatMat.dispose();
      voiceMat.dispose();
      [
        skinMat,
        shirtMat,
        pantsMat,
        hatMat,
        hairMat,
        whiteMat,
        shoeMat,
        shoeSoleMat,
        accentMat,
        goldMat,
        wingMat,
        swordMat,
        headphoneGlowMat,
        faceMat,
        effectRingMat,
        footRingMat,
        ...effectOrbMats,
        ...trailParticles.map((p) => p.mat),
      ].forEach((m) => m.dispose());
      root.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) (obj as THREE.Mesh).geometry.dispose();
      });
    },
  };
}
