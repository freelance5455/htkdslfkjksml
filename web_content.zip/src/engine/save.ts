/**
 * Versioned local save. Everything the player keeps between sessions lives in one JSON record so
 * it is easy to migrate. Corrupt or foreign data falls back to defaults instead of crashing.
 */
export type Quality = 'low' | 'medium' | 'high'

export type BestRun = { score: number; rings: number; distance: number; seconds: number }

export type SaveData = {
  version: 2
  musicVolume: number
  sfxVolume: number
  muted: boolean
  /** Stick sensitivity multiplier. */
  sensitivity: number
  /** false = pull back (stick down) raises the nose; true = inverted. */
  invertY: boolean
  /** Automatic wing levelling when the stick is released. */
  assist: boolean
  quality: Quality
  reducedMotion: boolean
  tutorialDone: boolean
  best: BestRun
  flights: number
}

export const SAVE_KEY = 'pampa.vuelo.save'

export function defaultSave(): SaveData {
  return {
    version: 2,
    musicVolume: 0.6,
    sfxVolume: 0.8,
    muted: false,
    sensitivity: 1,
    invertY: false,
    assist: true,
    quality: 'medium',
    reducedMotion: false,
    tutorialDone: false,
    best: { score: 0, rings: 0, distance: 0, seconds: 0 },
    flights: 0,
  }
}

const clamp01 = (v: unknown, fallback: number) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : fallback)
const nonNeg = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : 0)

/** Parse untrusted stored JSON into a valid SaveData (pure; unit tested). */
export function parseSave(raw: string | null): SaveData {
  const base = defaultSave()
  if (!raw) return base
  let data: Record<string, unknown>
  try {
    const parsed = JSON.parse(raw)
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return base
    data = parsed as Record<string, unknown>
  } catch {
    return base
  }
  if (data.version !== 2) return base
  const best = (data.best && typeof data.best === 'object' ? data.best : {}) as Record<string, unknown>
  return {
    version: 2,
    musicVolume: clamp01(data.musicVolume, base.musicVolume),
    sfxVolume: clamp01(data.sfxVolume, base.sfxVolume),
    muted: data.muted === true,
    sensitivity: typeof data.sensitivity === 'number' && data.sensitivity >= 0.5 && data.sensitivity <= 2 ? data.sensitivity : base.sensitivity,
    invertY: data.invertY === true,
    assist: data.assist !== false,
    quality: data.quality === 'low' || data.quality === 'medium' || data.quality === 'high' ? data.quality : base.quality,
    reducedMotion: data.reducedMotion === true,
    tutorialDone: data.tutorialDone === true,
    best: { score: Math.floor(nonNeg(best.score)), rings: Math.floor(nonNeg(best.rings)), distance: nonNeg(best.distance), seconds: nonNeg(best.seconds) },
    flights: Math.floor(nonNeg(data.flights)),
  }
}

export class SaveStore {
  data: SaveData

  constructor(private readonly storage: Pick<Storage, 'getItem' | 'setItem'> | undefined = globalThis.localStorage) {
    let raw: string | null = null
    try {
      raw = this.storage?.getItem(SAVE_KEY) ?? null
    } catch {
      raw = null
    }
    this.data = parseSave(raw)
  }

  update(patch: Partial<SaveData>): void {
    this.data = { ...this.data, ...patch }
    try {
      this.storage?.setItem(SAVE_KEY, JSON.stringify(this.data))
    } catch {
      // Private browsing or quota: the game keeps working with in-memory settings.
    }
  }
}
