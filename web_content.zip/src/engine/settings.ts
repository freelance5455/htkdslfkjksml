export const MAX_ELO = 2400;
export const MIN_ELO = 100;

/** Параметры, которые напрямую влияют на силу игры движка */
export interface EngineSettings {
  depth: number; // максимальная глубина (полуходы)
  timeMs: number; // лимит времени на ход
  quiescence: boolean; // поиск взятий в конце ветки
  qDepth: number; // глубина quiescence
  useTT: boolean; // таблица транспозиций
  checkExt: boolean; // расширение при шахе
  nullMove: boolean; // нулевой ход (отсечения)
  lmr: boolean; // сокращение поздних ходов
  noise: number; // шум оценки, сантипешки
  mistakeChance: number; // 0..1 вероятность "ошибки"
  candidates: number; // сколько лучших ходов рассматривать
  openingVariety: number; // сколько первых полуходов играть разнообразно
  usePST: boolean; // таблицы позиций фигур
  bishopPair: boolean;
  pawnStructure: boolean;
  rookFiles: boolean;
}

export interface UISettings {
  analysisDepth: number;
  analysisTimeMs: number;
  arrows: number; // 0..5
  showEval: boolean;
  showLastMove: boolean;
  showLegal: boolean;
  showCoords: boolean;
  autoFlip: boolean;
  theme: 'classic' | 'green' | 'blue' | 'gray';
}

export type Settings = EngineSettings & UISettings;

export const DEFAULT_UI: UISettings = {
  analysisDepth: 5,
  analysisTimeMs: 1500,
  arrows: 3,
  showEval: true,
  showLastMove: true,
  showLegal: true,
  showCoords: true,
  autoFlip: true,
  theme: 'green',
};

export function clampElo(n: number): number {
  if (!Number.isFinite(n)) return 1200;
  return Math.max(MIN_ELO, Math.min(MAX_ELO, Math.round(n)));
}

/** Подбирает настройки движка под заданное Эло (макс. 2400) */
export function settingsForElo(rawElo: number): EngineSettings {
  const elo = clampElo(rawElo);
  const t = (elo - MIN_ELO) / (MAX_ELO - MIN_ELO); // 0..1
  const weak = 1 - t;
  return {
    depth: Math.max(1, Math.round(1 + t * 9)),
    timeMs: Math.round(200 + t * 3800),
    quiescence: elo >= 700,
    qDepth: Math.round(2 + t * 8),
    useTT: elo >= 900,
    checkExt: elo >= 1300,
    nullMove: elo >= 1400,
    lmr: elo >= 1600,
    noise: Math.round(260 * weak * weak),
    mistakeChance: Math.round(45 * Math.pow(weak, 1.6)) / 100,
    candidates: 1 + Math.round(5 * weak),
    openingVariety: elo >= 1800 ? 6 : 8,
    usePST: elo >= 500,
    bishopPair: elo >= 1200,
    pawnStructure: elo >= 1000,
    rookFiles: elo >= 1500,
  };
}

export const ENGINE_KEYS: (keyof EngineSettings)[] = [
  'depth',
  'timeMs',
  'quiescence',
  'qDepth',
  'useTT',
  'checkExt',
  'nullMove',
  'lmr',
  'noise',
  'mistakeChance',
  'candidates',
  'openingVariety',
  'usePST',
  'bishopPair',
  'pawnStructure',
  'rookFiles',
];

export function matchesElo(s: Settings, elo: number): boolean {
  const e = settingsForElo(elo);
  return ENGINE_KEYS.every((k) => e[k] === s[k]);
}

export const DEFAULT_SETTINGS: Settings = {
  ...settingsForElo(1500),
  ...DEFAULT_UI,
};
