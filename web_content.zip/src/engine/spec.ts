import type { Copy } from "./i18n";
import { CYL, type LayoutId, type Spec } from "./types";

const D = Math.PI / 180;

export type Journal = { x: number; bk: number; p: number };

export function layout(t: LayoutId, b: number): Journal[] {
  const n = CYL[t];
  const sp = b * 1.15;
  const o: Journal[] = [];
  for (let i = 0; i < n; i++) {
    let x = (i - (n - 1) / 2) * sp;
    let bk = 0;
    let p = (i * 2 * Math.PI) / n;
    if (t[0] === "v") {
      bk = (i % 2 ? 1 : -1) * 45 * D;
      if (t === "v2") {
        x = (i - 0.5) * 0.4;
        p = 0;
      } else x = (i - (n - 1) / 2) * b * (n > 3 ? 0.85 : 1);
      if (t === "v4") p = i === 1 || i === 2 ? Math.PI : 0;
      if (n > 4) {
        const q = Math.floor(i / 2);
        x = (q - (n / 4 - 0.5)) * (b + 0.45) + (i % 2 ? 0.2 : -0.2);
        p = n === 8 ? [0, 90, 270, 180][q]! * D : (q * 4 * Math.PI) / n;
      }
    }
    if (t[0] === "f") {
      bk = (i % 2 ? 1 : -1) * 90 * D;
      if (t === "f2") {
        x = (i - 0.5) * 0.5;
        p = i ? Math.PI : 0;
      } else if (t === "f4") {
        p = [0, Math.PI, Math.PI, 0][i]!;
        x = (Math.floor(i / 2) - 0.5) * sp + (i % 2 ? 0.2 : -0.2);
      } else p += i % 2 ? Math.PI : 0;
    }
    if (t === "i2") p = i * Math.PI;
    if (t === "i4") p = [0, Math.PI, Math.PI, 0][i]!;
    if (t === "w12") {
      const row = Math.floor(i / 3);
      const bn = i % 3;
      bk = (bn - 1) * 60 * D;
      x = (row - 1.5) * (b + 0.45) + (bn - 1) * b * 0.4;
      p = [0, Math.PI, Math.PI, 0][row]!;
    }
    o.push({ x, bk, p });
  }
  return o;
}

export function curve(spec: Spec) {
  const n = CYL[spec.type];
  const cc = (spec.twin ? 2 : 1) * n * (Math.PI / 4) * (spec.bore / 10) ** 2 * (spec.stroke / 10);
  const base =
    spec.fuel === "dsl" ? 5200 - (spec.stroke - 50) * 30 : 9500 - (spec.stroke - 50) * 60;
  const red = base * (spec.ecu ? 1 + spec.lim / 100 : 1);
  return { cc, n, red: Math.max(1800, red) };
}

const EXH_PWR = { stock: 1, sport: 1.03, straight: 1.05, open: 1.07 } as const;

export function perf(spec: Spec, rpm: number) {
  const e = curve(spec);
  const x = rpm / e.red;
  let pk = e.cc * 0.07 * (1 + 0.15 * (spec.bore / spec.stroke - 1));
  if (spec.carb) pk *= 0.94;
  if (spec.ecu) pk *= 1 + spec.map / 100;
  if (spec.fuel === "dsl") pk *= 0.75;
  pk *= EXH_PWR[spec.exh];
  let m = 1;
  const bf = spec.ecu ? 1 + spec.bst / 100 : 1;
  if (spec.turbo) m *= 1 + 0.35 * bf * Math.min(1, Math.max(0, (x - 0.25) / 0.4));
  if (spec.sc) m *= 1 + 0.22 * bf;
  const hp = Math.max(0, x * (1.4 - 0.4 * x)) * pk * m;
  return { hp, tq: (hp * 7121) / Math.max(rpm, 1), cc: e.cc, red: e.red };
}

export function layoutName(id: LayoutId, tr: Copy) {
  if (id === "single") return tr.single;
  if (id === "w12") return "W12";
  const n = id.slice(1);
  if (id.startsWith("v")) return `V${n}`;
  if (id.startsWith("f")) return `${tr.flat} ${n}`;
  return `${tr.inl} ${n}`;
}

export function engineTitle(spec: Spec, tr: Copy) {
  const bits = [layoutName(spec.type, tr)];
  if (spec.fuel === "dsl") bits.push(tr.diesel);
  if (spec.ecu) bits.push("ECU");
  if (spec.twin) bits.push("×2");
  if (spec.turbo) bits.push("T");
  if (spec.sc) bits.push("SC");
  if (spec.carb) bits.push("CARB");
  return bits.join("  ");
}
