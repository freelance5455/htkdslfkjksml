import type { ProjectState, TimelineItem } from '../core/types';
import { loadAsset } from '../services/projectStore';
import { computeFilter } from './renderEngine';

export async function exportSelectedFrame(project: ProjectState, item: TimelineItem): Promise<Blob> {
  const asset = item.assetId ? await loadAsset(item.assetId) : null;
  if (!asset) throw new Error('Mídia não encontrada no armazenamento local.');
  const url = URL.createObjectURL(asset);
  try {
    const canvas = document.createElement('canvas');
    canvas.width = project.settings.width; canvas.height = project.settings.height;
    const ctx = canvas.getContext('2d'); if (!ctx) throw new Error('Canvas 2D indisponível.');
    ctx.filter = computeFilter(item.effects) || 'none';
    if (item.mime?.startsWith('image/')) {
      const img = new Image(); img.src = url; await img.decode();
      drawContain(ctx, img, canvas.width, canvas.height);
    } else if (item.mime?.startsWith('video/')) {
      const video = document.createElement('video'); video.src = url; video.muted = true; video.playsInline = true;
      await new Promise<void>((resolve, reject) => { video.onloadeddata=()=>resolve(); video.onerror=()=>reject(new Error('Não foi possível decodificar o vídeo.')); });
      drawContain(ctx, video, canvas.width, canvas.height);
    } else throw new Error('Selecione uma imagem ou vídeo para exportar um frame.');
    return await new Promise<Blob>((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('Falha ao gerar PNG.')), 'image/png', .95));
  } finally { URL.revokeObjectURL(url); }
}

function drawContain(ctx:CanvasRenderingContext2D, source:CanvasImageSource, cw:number,ch:number){
  const w=source instanceof HTMLVideoElement?source.videoWidth:(source as HTMLImageElement).naturalWidth;
  const h=source instanceof HTMLVideoElement?source.videoHeight:(source as HTMLImageElement).naturalHeight;
  const scale=Math.min(cw/w,ch/h); const dw=w*scale,dh=h*scale;
  ctx.fillStyle='#000';ctx.fillRect(0,0,cw,ch);ctx.drawImage(source,(cw-dw)/2,(ch-dh)/2,dw,dh);
}
