import { curve } from "./spec";
import type { LayoutId, Live, Spec } from "./types";

const evn = (n: number, j: number) =>
  Array.from({ length: n }, (_, i) => (i ? (i + (i % 2 ? j : -j)) / n : 0));

const SCH: Record<LayoutId, number[]> = {
  single: [0],
  v2: [0, 0.375],
  f2: [0, 0.5],
  i2: [0, 0.25],
  v3: [0, 0.3, 0.67],
  i3: [0, 1 / 3, 2 / 3],
  f3: [0, 1 / 3, 2 / 3],
  v4: [0, 0.2, 0.5, 0.7],
  i4: [0, 0.25, 0.5, 0.75],
  f4: [0, 0.23, 0.5, 0.73],
  i5: [0, 0.2, 0.4, 0.6, 0.8],
  v6: [0, 0.14, 0.33, 0.47, 0.67, 0.81],
  v8: [0, 0.12, 0.27, 0.37, 0.5, 0.62, 0.77, 0.87],
  v10: evn(10, 0.12),
  v12: evn(12, 0),
  w12: evn(12, 0.05),
};

const TIM: Record<LayoutId, [number, number, number]> = {
  single: [0.8, 0.5, 1.2],
  v2: [0.9, 0.9, 1],
  f2: [1, 0.6, 0.9],
  i2: [1.3, 0.6, 1.1],
  v3: [1, 0.7, 1],
  i3: [1.15, 0.5, 1.2],
  f3: [0.95, 0.8, 0.9],
  v4: [1.05, 0.6, 0.8],
  i4: [1.3, 0.5, 1],
  f4: [0.9, 0.9, 0.85],
  i5: [1.15, 0.6, 1],
  v6: [1, 0.7, 0.9],
  v8: [0.75, 1, 1.2],
  v10: [1.05, 0.8, 0.8],
  v12: [1.2, 0.5, 0.7],
  w12: [1.1, 0.7, 0.8],
};

const EXH: Record<Spec["exh"], [number, number, number, number, number]> = {
  stock: [0.7, 0.8, 0, 0.35, 1.1],
  sport: [1.1, 1, 0.2, 0.5, 1],
  straight: [1.5, 1.15, 0.4, 0.7, 0.9],
  open: [2.2, 1.3, 0.7, 0.95, 0.7],
};

export class EngineAudio {
  private ac: AudioContext | null = null;
  private mg: GainNode | null = null;
  private cmp: DynamicsCompressorNode | null = null;
  private tOsc: OscillatorNode | null = null;
  private tG: GainNode | null = null;
  private sOsc: OscillatorNode | null = null;
  private sG: GainNode | null = null;
  private gB: BiquadFilterNode | null = null;
  private gG: GainNode | null = null;
  private bq: OscillatorNode | null = null;
  private bqG: GainNode | null = null;
  private nbuf: AudioBuffer | null = null;
  private on = false;
  private vol = 0.7;
  private spool = 0;
  private prevThr = 0;
  private nextBov = 0;
  private PH = [0, 0];
  private BP = [0, 0];
  private EN = [0, 0];
  private AM = [1, 1];
  private CK = [0, 0];
  private lp = 0;
  private n1 = 0;

  constructor(
    private getSpec: () => Spec,
    private getLive: () => Live,
  ) {}

  get enabled() {
    return this.on;
  }

  setVolume(v: number) {
    this.vol = v;
    if (this.mg) this.mg.gain.value = v * 0.85;
  }

  toggle() {
    this.ensure();
    if (!this.ac) return this.on;
    this.on = !this.on;
    if (this.on) void this.ac.resume();
    else void this.ac.suspend();
    return this.on;
  }

  ensure() {
    if (this.ac) {
      if (this.ac.state === "suspended" && this.on) void this.ac.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ac = new AC();
    this.ac = ac;
    const cmp = ac.createDynamicsCompressor();
    cmp.threshold.value = -14;
    cmp.knee.value = 16;
    cmp.ratio.value = 4;
    cmp.attack.value = 0.004;
    cmp.release.value = 0.18;
    const mg = ac.createGain();
    mg.gain.value = this.vol * 0.85;
    cmp.connect(mg);
    mg.connect(ac.destination);
    this.cmp = cmp;
    this.mg = mg;

    const sp = ac.createScriptProcessor(2048, 0, 1);
    sp.onaudioprocess = (e) => this.process(e);
    sp.connect(cmp);

    const tOsc = ac.createOscillator();
    const tG = ac.createGain();
    tG.gain.value = 0;
    tOsc.connect(tG);
    tG.connect(cmp);
    tOsc.start();
    this.tOsc = tOsc;
    this.tG = tG;

    const sOsc = ac.createOscillator();
    sOsc.type = "sawtooth";
    const sf = ac.createBiquadFilter();
    sf.type = "lowpass";
    sf.frequency.value = 3500;
    const sG = ac.createGain();
    sG.gain.value = 0;
    sOsc.connect(sf);
    sf.connect(sG);
    sG.connect(cmp);
    sOsc.start();
    this.sOsc = sOsc;
    this.sG = sG;

    const nbuf = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
    const d = nbuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    this.nbuf = nbuf;

    const gs = ac.createBufferSource();
    gs.buffer = nbuf;
    gs.loop = true;
    const gB = ac.createBiquadFilter();
    gB.type = "bandpass";
    gB.frequency.value = 700;
    gB.Q.value = 1.5;
    const gG = ac.createGain();
    gG.gain.value = 0;
    gs.connect(gB);
    gB.connect(gG);
    gG.connect(cmp);
    gs.start();
    this.gB = gB;
    this.gG = gG;

    const bq = ac.createOscillator();
    bq.type = "sawtooth";
    const bpf = ac.createBiquadFilter();
    bpf.type = "bandpass";
    bpf.frequency.value = 2000;
    bpf.Q.value = 10;
    const bqG = ac.createGain();
    bqG.gain.value = 0;
    bq.connect(bpf);
    bpf.connect(bqG);
    bqG.connect(cmp);
    bq.start();
    this.bq = bq;
    this.bqG = bqG;
  }

  private process(e: AudioProcessingEvent) {
    const ac = this.ac;
    if (!ac) return;
    const o = e.outputBuffer.getChannelData(0);
    const spec = this.getSpec();
    const live = this.getLive();
    const sr = ac.sampleRate;
    const c = curve(spec);
    const rpm = live.dead || live.stall ? 0 : live.rpm;
    const x = Math.min(1.3, rpm / c.red);
    const sch = SCH[spec.type];
    const tm = TIM[spec.type];
    const dz = spec.fuel === "dsl";
    const th = 0.4 + 0.6 * live.thr;
    const ex = EXH[spec.exh];
    const bf = (90 + rpm * 0.025) * (70 / spec.bore) * tm[0] * (dz ? 0.65 : 1);
    const dec = Math.exp(
      -1 / (sr * (0.012 + 0.02 / (1 + rpm / 2000)) * tm[2] * (dz ? 0.9 : 1) * ex[4]),
    );
    const k =
      1 -
      Math.exp(
        (-6.283 * (dz ? 180 + rpm * 0.45 : 250 + rpm * 0.7) * (0.6 + 0.4 * live.thr) * ex[0]) / sr,
      );
    const kd = Math.exp(-1 / (sr * 0.0015));
    const ir = spec.carb ? 0.6 * x : 0;
    const step = rpm > 0 ? rpm / 120 / sr : 0;
    const nv = spec.twin ? 2 : 1;
    for (let i = 0; i < o.length; i++) {
      let v = 0;
      let tk = 0;
      const nz = Math.random() * 2 - 1;
      for (let w = 0; w < nv; w++) {
        const pv = this.PH[w]!;
        const dt2 = w ? 1.015 : 1;
        this.PH[w] = pv + step * dt2;
        if (this.PH[w]! >= 1) this.PH[w] = this.PH[w]! - 1;
        const ph = this.PH[w]!;
        if (rpm > 0 && !live.cut) {
          for (let j = 0; j < sch.length; j++) {
            const q = sch[j]!;
            if (ph < pv ? q > pv || q <= ph : q > pv && q <= ph) {
              this.EN[w] = 1;
              this.BP[w] = 0;
              this.AM[w] =
                ((dz ? 0.6 : 0.75) + (dz ? 0.4 : 0.25) * Math.random()) * (live.rel ? 1.7 : 1);
              live.rel = false;
              this.CK[w] = 1;
              break;
            }
          }
        }
        this.EN[w] = this.EN[w]! * dec;
        this.CK[w] = this.CK[w]! * kd;
        this.BP[w] = this.BP[w]! + (6.283 * bf * dt2) / sr;
        const bp = this.BP[w]!;
        const env = this.EN[w]!;
        const amp = this.AM[w]!;
        v += dz
          ? (Math.sin(bp) + 0.35 * Math.sin(bp * 3.1) + nz * 0.9) * env * amp
          : (Math.sin(bp) +
              (tm[1] + ex[2]) * Math.sin(bp * 2.01) +
              ex[2] * 0.6 * Math.sin(bp * 3.02) +
              nz * ex[3]) *
            env *
            amp;
        tk += this.CK[w]!;
      }
      this.lp += (v - this.lp) * k;
      this.n1 += (Math.random() * 2 - 1 - this.n1) * 0.04;
      o[i] =
        rpm > 0
          ? (this.lp * 0.9 + this.n1 * ir + (dz ? nz * tk * 0.3 : 0)) * th * ex[1] * (nv > 1 ? 0.85 : 1)
          : 0;
    }
  }

  update(dt: number) {
    const ac = this.ac;
    if (!ac || !this.on || !this.tOsc || !this.tG || !this.sOsc || !this.sG || !this.bq || !this.bqG || !this.gG || !this.gB)
      return;
    const spec = this.getSpec();
    const live = this.getLive();
    const c = curve(spec);
    const x = Math.min(1.2, live.rpm / c.red);
    const t = ac.currentTime;
    this.bqG.gain.setTargetAtTime(
      live.brake > 0.5 && live.spd > 2 ? Math.min(0.05, (live.spd / 30) * 0.05) * (0.7 + 0.3 * Math.random()) : 0,
      t,
      0.05,
    );
    this.bq.frequency.setTargetAtTime(1400 + live.spd * 15, t, 0.1);
    if (live.dead) {
      this.tG.gain.setTargetAtTime(0, t, 0.05);
      this.sG.gain.setTargetAtTime(0, t, 0.05);
      const sp = live.spd;
      this.gG.gain.setTargetAtTime(Math.min(0.3, (sp / 25) * 0.3) * (0.6 + 0.4 * Math.random()), t, 0.05);
      this.gB.frequency.setTargetAtTime(300 + sp * 30, t, 0.1);
      if (Math.random() < dt * sp * 0.25) this.clank(t);
      return;
    }
    this.gG.gain.setTargetAtTime(0, t, 0.05);
    const tgt = spec.turbo && live.rpm > 50 ? Math.min(1, Math.max(0, (x - 0.15) / 0.6)) * (0.25 + 0.75 * live.thr) : 0;
    this.spool += (tgt - this.spool) * Math.min(1, dt * (tgt > this.spool ? 1.2 : 2.5));
    this.tOsc.frequency.setTargetAtTime(900 + 4200 * this.spool, t, 0.05);
    this.tG.gain.setTargetAtTime(
      spec.turbo ? 0.05 * this.spool * this.spool * (spec.ecu ? 1 + spec.bst / 150 : 1) + 0.004 * this.spool : 0,
      t,
      0.05,
    );
    if (spec.turbo && this.spool > 0.45 && this.prevThr > 0.6 && live.thr < 0.3 && t > this.nextBov) {
      this.bov(t);
      this.nextBov = t + 1;
    }
    this.prevThr = live.thr;
    this.sOsc.frequency.setTargetAtTime(150 + live.rpm * 0.45, t, 0.05);
    this.sG.gain.setTargetAtTime(spec.sc && live.rpm > 50 ? 0.035 * (0.35 + x * 0.65) * (0.5 + 0.5 * live.thr) : 0, t, 0.05);
  }

  private bov(t: number) {
    if (!this.ac || !this.nbuf || !this.cmp) return;
    const s = this.ac.createBufferSource();
    s.buffer = this.nbuf;
    const h = this.ac.createBiquadFilter();
    h.type = "bandpass";
    h.frequency.value = 3200;
    h.Q.value = 0.8;
    const g = this.ac.createGain();
    g.gain.setValueAtTime(0.4, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.6);
    s.connect(h);
    h.connect(g);
    g.connect(this.cmp);
    s.start(t);
    s.stop(t + 0.7);
  }

  private clank(t: number) {
    if (!this.ac || !this.cmp) return;
    const oc = this.ac.createOscillator();
    const gc = this.ac.createGain();
    oc.type = "square";
    oc.frequency.value = 250 + Math.random() * 1400;
    gc.gain.setValueAtTime(0.1, t);
    gc.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    oc.connect(gc);
    gc.connect(this.cmp);
    oc.start(t);
    oc.stop(t + 0.12);
  }

  grind() {
    if (!this.ac || !this.on) return;
    const t = this.ac.currentTime;
    for (let i = 0; i < 9; i++) this.clank(t + i * 0.025);
  }

  starter() {
    if (!this.ac || !this.on || !this.cmp) return;
    const t = this.ac.currentTime;
    const o = this.ac.createOscillator();
    const f = this.ac.createBiquadFilter();
    const g = this.ac.createGain();
    o.type = "sawtooth";
    o.frequency.value = 58;
    f.type = "lowpass";
    f.frequency.value = 420;
    g.gain.value = 0;
    o.connect(f);
    f.connect(g);
    g.connect(this.cmp);
    o.start(t);
    for (let i = 0; i < 14; i++) {
      const tt = t + i * 0.065;
      g.gain.setValueAtTime(0.2, tt);
      g.gain.linearRampToValueAtTime(0.03, tt + 0.05);
    }
    g.gain.setValueAtTime(0, t + 0.91);
    o.stop(t + 0.95);
  }

  boom() {
    if (!this.ac || !this.on || !this.cmp || !this.nbuf) return;
    const t = this.ac.currentTime;
    const nz = (f0: number, f1: number, ty: BiquadFilterType, gn: number, d: number) => {
      const s = this.ac!.createBufferSource();
      s.buffer = this.nbuf;
      s.loop = true;
      const fl = this.ac!.createBiquadFilter();
      fl.type = ty;
      fl.frequency.setValueAtTime(f0, t);
      if (f1) fl.frequency.exponentialRampToValueAtTime(f1, t + d);
      const g = this.ac!.createGain();
      g.gain.setValueAtTime(gn, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + d);
      s.connect(fl);
      fl.connect(g);
      g.connect(this.cmp!);
      s.start(t);
      s.stop(t + d + 0.1);
    };
    nz(1800, 120, "lowpass", 1, 1.4);
    nz(3500, 400, "highpass", 0.12, 1.2);
    const o = this.ac.createOscillator();
    const og = this.ac.createGain();
    o.frequency.setValueAtTime(110, t);
    o.frequency.exponentialRampToValueAtTime(30, t + 0.5);
    og.gain.setValueAtTime(1.2, t);
    og.gain.exponentialRampToValueAtTime(0.001, t + 0.6);
    o.connect(og);
    og.connect(this.cmp);
    o.start(t);
    o.stop(t + 0.7);
    for (let i = 0; i < 6; i++) {
      const tt = t + 0.05 + i * 0.11 + Math.random() * 0.05;
      this.clank(tt);
    }
  }

  pop(delay = 0) {
    if (!this.ac || !this.on || !this.cmp || !this.nbuf) return;
    const t = this.ac.currentTime + delay;
    const sn = this.ac.createBufferSource();
    sn.buffer = this.nbuf;
    const f = this.ac.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 500 + Math.random() * 900;
    f.Q.value = 0.7;
    const g = this.ac.createGain();
    g.gain.setValueAtTime(0.5 + Math.random() * 0.4, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
    sn.connect(f);
    f.connect(g);
    g.connect(this.cmp);
    sn.start(t, Math.random() * 0.5);
    sn.stop(t + 0.12);
  }
}
