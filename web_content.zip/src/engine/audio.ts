/**
 * All sound is synthesised with the Web Audio API, so the game ships without audio files.
 * The AudioContext is created lazily on the first user gesture (browser autoplay rules).
 */
export type Sfx = 'click' | 'ring' | 'perfect' | 'warn' | 'stall' | 'crash' | 'start'

const PAD_CHORDS = [
  [220.0, 261.63, 329.63, 440.0], // La menor
  [174.61, 220.0, 261.63, 349.23], // Fa
  [196.0, 261.63, 329.63, 392.0], // Do
  [196.0, 246.94, 293.66, 392.0], // Sol
]

export class AudioManager {
  private ctx?: AudioContext
  private master?: GainNode
  private musicBus?: GainNode
  private sfxBus?: GainNode
  private noise?: AudioBuffer
  private engineGain?: GainNode
  private engineFilter?: BiquadFilterNode
  private engineOsc?: OscillatorNode
  private windGain?: GainNode
  private windFilter?: BiquadFilterNode
  private padOsc: OscillatorNode[] = []
  private padTimer = 0
  private chord = 0
  private musicVolume = 0.6
  private sfxVolume = 0.8
  private muted = false
  private paused = false
  private engineOn = false

  /** Create / resume the context. Call from a user gesture handler. */
  unlock(): void {
    if (!this.ctx) {
      const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
      if (!Ctor) return
      this.ctx = new Ctor()
      this.master = this.ctx.createGain()
      this.musicBus = this.ctx.createGain()
      this.sfxBus = this.ctx.createGain()
      this.musicBus.connect(this.master)
      this.sfxBus.connect(this.master)
      this.master.connect(this.ctx.destination)
      this.noise = this.makeNoise(this.ctx)
      this.applyVolumes()
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume()
  }

  setVolumes(music: number, sfx: number, muted: boolean): void {
    this.musicVolume = music
    this.sfxVolume = sfx
    this.muted = muted
    this.applyVolumes()
  }

  private applyVolumes(): void {
    if (!this.ctx || !this.master || !this.musicBus || !this.sfxBus) return
    const t = this.ctx.currentTime
    this.master.gain.setTargetAtTime(this.muted ? 0 : 1, t, 0.05)
    this.musicBus.gain.setTargetAtTime(this.musicVolume * 0.22, t, 0.1)
    this.sfxBus.gain.setTargetAtTime(this.sfxVolume, t, 0.05)
  }

  private makeNoise(ctx: AudioContext): AudioBuffer {
    const length = ctx.sampleRate * 2
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate)
    const data = buffer.getChannelData(0)
    for (let i = 0; i < length; i += 1) data[i] = Math.random() * 2 - 1
    return buffer
  }

  // ─── engine + wind ──────────────────────────────────────────────────────
  startEngine(): void {
    if (!this.ctx || !this.sfxBus || !this.noise || this.engineOn) return
    const ctx = this.ctx
    const roar = ctx.createBufferSource()
    roar.buffer = this.noise
    roar.loop = true
    this.engineFilter = ctx.createBiquadFilter()
    this.engineFilter.type = 'bandpass'
    this.engineFilter.Q.value = 0.8
    this.engineGain = ctx.createGain()
    this.engineGain.gain.value = 0
    roar.connect(this.engineFilter).connect(this.engineGain).connect(this.sfxBus)
    roar.start()

    this.engineOsc = ctx.createOscillator()
    this.engineOsc.type = 'sawtooth'
    const low = ctx.createBiquadFilter()
    low.type = 'lowpass'
    low.frequency.value = 380
    const oscGain = ctx.createGain()
    oscGain.gain.value = 0.05
    this.engineOsc.connect(low).connect(oscGain).connect(this.engineGain)
    this.engineOsc.start()

    const wind = ctx.createBufferSource()
    wind.buffer = this.noise
    wind.loop = true
    this.windFilter = ctx.createBiquadFilter()
    this.windFilter.type = 'highpass'
    this.windFilter.frequency.value = 1200
    this.windGain = ctx.createGain()
    this.windGain.gain.value = 0
    wind.connect(this.windFilter).connect(this.windGain).connect(this.sfxBus)
    wind.start()
    this.engineOn = true
  }

  /** `engine` and `speed01` in 0..1. */
  setEngine(engine: number, speed01: number): void {
    if (!this.ctx || !this.engineOn) return
    const t = this.ctx.currentTime
    const gain = this.paused ? 0 : 0.16 + engine * 0.2
    this.engineGain!.gain.setTargetAtTime(gain, t, 0.12)
    this.engineFilter!.frequency.setTargetAtTime(380 + engine * 1100, t, 0.15)
    this.engineOsc!.frequency.setTargetAtTime(52 + engine * 70, t, 0.2)
    this.windGain!.gain.setTargetAtTime(this.paused ? 0 : 0.015 + speed01 * 0.13, t, 0.2)
    this.windFilter!.frequency.setTargetAtTime(900 + speed01 * 1600, t, 0.2)
  }

  silenceEngine(): void {
    if (!this.ctx || !this.engineOn) return
    const t = this.ctx.currentTime
    this.engineGain!.gain.setTargetAtTime(0, t, 0.08)
    this.windGain!.gain.setTargetAtTime(0, t, 0.08)
  }

  setPaused(paused: boolean): void {
    this.paused = paused
    if (paused) this.silenceEngine()
  }

  // ─── music ──────────────────────────────────────────────────────────────
  startMusic(): void {
    if (!this.ctx || !this.musicBus || this.padOsc.length) return
    const ctx = this.ctx
    const filter = ctx.createBiquadFilter()
    filter.type = 'lowpass'
    filter.frequency.value = 900
    filter.connect(this.musicBus)
    for (let i = 0; i < 4; i += 1) {
      const osc = ctx.createOscillator()
      osc.type = i % 2 === 0 ? 'triangle' : 'sine'
      osc.frequency.value = PAD_CHORDS[0][i]
      const g = ctx.createGain()
      g.gain.value = 0.35
      osc.connect(g).connect(filter)
      osc.start()
      this.padOsc.push(osc)
    }
    this.padTimer = window.setInterval(() => {
      this.chord = (this.chord + 1) % PAD_CHORDS.length
      const t = ctx.currentTime
      this.padOsc.forEach((o, i) => o.frequency.setTargetAtTime(PAD_CHORDS[this.chord][i], t, 1.4))
    }, 7000)
  }

  stopMusic(): void {
    window.clearInterval(this.padTimer)
    for (const o of this.padOsc) {
      try { o.stop() } catch { /* already stopped */ }
    }
    this.padOsc = []
  }

  // ─── effects ────────────────────────────────────────────────────────────
  play(name: Sfx): void {
    if (!this.ctx || !this.sfxBus) return
    switch (name) {
      case 'click': this.tone(880, 0.05, 'triangle', 0.18); break
      case 'start': this.tone(392, 0.12, 'triangle', 0.2); this.tone(587, 0.2, 'triangle', 0.2, 0.1); break
      case 'ring': this.tone(660, 0.14, 'sine', 0.3); this.tone(990, 0.24, 'sine', 0.3, 0.07); break
      case 'perfect': this.tone(660, 0.12, 'sine', 0.3); this.tone(880, 0.12, 'sine', 0.3, 0.07); this.tone(1320, 0.3, 'sine', 0.3, 0.14); break
      case 'warn': this.tone(1180, 0.09, 'square', 0.12); break
      case 'stall': this.tone(520, 0.12, 'sawtooth', 0.12); break
      case 'crash':
        this.burst(1.6, 2400, 60, 0.95)
        this.tone(70, 0.7, 'sawtooth', 0.5, 0, 28)
        break
    }
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, delay = 0, slideTo?: number): void {
    const ctx = this.ctx!
    const t = ctx.currentTime + delay
    const osc = ctx.createOscillator()
    osc.type = type
    osc.frequency.setValueAtTime(freq, t)
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t + dur)
    const g = ctx.createGain()
    g.gain.setValueAtTime(0, t)
    g.gain.linearRampToValueAtTime(vol, t + 0.01)
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
    osc.connect(g).connect(this.sfxBus!)
    osc.start(t)
    osc.stop(t + dur + 0.05)
  }

  private burst(dur: number, from: number, to: number, vol: number): void {
    const ctx = this.ctx!
    const t = ctx.currentTime
    const src = ctx.createBufferSource()
    src.buffer = this.noise!
    const f = ctx.createBiquadFilter()
    f.type = 'lowpass'
    f.frequency.setValueAtTime(from, t)
    f.frequency.exponentialRampToValueAtTime(to, t + dur)
    const g = ctx.createGain()
    g.gain.setValueAtTime(vol, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
    src.connect(f).connect(g).connect(this.sfxBus!)
    src.start(t)
    src.stop(t + dur + 0.05)
  }
}
