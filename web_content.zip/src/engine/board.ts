// Быстрое представление доски 0x88 с make/unmake и Zobrist-хешем.
// chess.js используется только для интерфейса (правила, SAN), а поиск идёт здесь.

export const P = 1,
  N = 2,
  B = 3,
  R = 4,
  Q = 5,
  K = 6;
export const WHITE = 0,
  BLACK = 1;

export const FLAG_CAP = 1,
  FLAG_EP = 2,
  FLAG_CASTLE = 4,
  FLAG_DOUBLE = 8;

export const mk = (from: number, to: number, promo: number, flags: number) =>
  from | (to << 7) | (promo << 14) | (flags << 17);
export const mFrom = (m: number) => m & 127;
export const mTo = (m: number) => (m >> 7) & 127;
export const mPromo = (m: number) => (m >> 14) & 7;
export const mFlags = (m: number) => (m >> 17) & 15;

export const sqName = (s: number) => 'abcdefgh'[s & 7] + ((s >> 4) + 1);
export const parseSq = (str: string) => (str.charCodeAt(1) - 49) * 16 + (str.charCodeAt(0) - 97);

const PROMO_CHAR = ['', '', 'n', 'b', 'r', 'q'];
export function moveToUci(m: number): string {
  return sqName(mFrom(m)) + sqName(mTo(m)) + PROMO_CHAR[mPromo(m)];
}

const KN = [33, 31, 18, 14, -33, -31, -18, -14];
const KG = [1, -1, 16, -16, 17, 15, -17, -15];
const BD = [17, 15, -17, -15];
const RD = [16, -16, 1, -1];

// --- Zobrist ---
function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) | 0;
  };
}
const rnd = mulberry32(0x5eed1234);
const Z1: Int32Array[] = [];
const Z2: Int32Array[] = [];
for (let p = 0; p < 16; p++) {
  Z1.push(new Int32Array(128).map(() => rnd()));
  Z2.push(new Int32Array(128).map(() => rnd()));
}
const ZC1 = new Int32Array(16).map(() => rnd());
const ZC2 = new Int32Array(16).map(() => rnd());
const ZE1 = new Int32Array(8).map(() => rnd());
const ZE2 = new Int32Array(8).map(() => rnd());
const ZS1 = rnd();
const ZS2 = rnd();

const CASTLE_MASK = new Uint8Array(128).fill(15);
CASTLE_MASK[0] = 15 & ~2;
CASTLE_MASK[4] = 15 & ~3;
CASTLE_MASK[7] = 15 & ~1;
CASTLE_MASK[112] = 15 & ~8;
CASTLE_MASK[116] = 15 & ~12;
CASTLE_MASK[119] = 15 & ~4;

export class Board {
  b = new Int8Array(128);
  side = WHITE;
  castling = 0;
  ep = -1;
  half = 0;
  kingSq = [4, 116];
  h1 = 0;
  h2 = 0;

  n = 0;
  uMove = new Int32Array(4096);
  uCap = new Int8Array(4096);
  uCastle = new Uint8Array(4096);
  uEp = new Int16Array(4096);
  uHalf = new Int16Array(4096);
  uH1 = new Int32Array(4096);
  uH2 = new Int32Array(4096);

  static fromFen(fen: string): Board {
    const bd = new Board();
    const [pos, stm, cas, ep, hm] = fen.trim().split(/\s+/);
    const map: Record<string, number> = { p: P, n: N, b: B, r: R, q: Q, k: K };
    let rank = 7,
      file = 0;
    for (const ch of pos) {
      if (ch === '/') {
        rank--;
        file = 0;
      } else if (ch >= '1' && ch <= '8') file += +ch;
      else {
        const lower = ch.toLowerCase();
        const color = ch === lower ? BLACK : WHITE;
        const piece = map[lower] | (color << 3);
        const sq = rank * 16 + file;
        bd.b[sq] = piece;
        if (map[lower] === K) bd.kingSq[color] = sq;
        file++;
      }
    }
    bd.side = stm === 'b' ? BLACK : WHITE;
    bd.castling = 0;
    if (cas && cas !== '-') {
      if (cas.includes('K')) bd.castling |= 1;
      if (cas.includes('Q')) bd.castling |= 2;
      if (cas.includes('k')) bd.castling |= 4;
      if (cas.includes('q')) bd.castling |= 8;
    }
    bd.ep = ep && ep !== '-' ? parseSq(ep) : -1;
    bd.half = hm ? parseInt(hm, 10) || 0 : 0;
    bd.computeHash();
    return bd;
  }

  computeHash() {
    let a = 0,
      c = 0;
    for (let sq = 0; sq < 128; sq++) {
      if (sq & 0x88) {
        sq += 7;
        continue;
      }
      const p = this.b[sq];
      if (p) {
        a ^= Z1[p][sq];
        c ^= Z2[p][sq];
      }
    }
    a ^= ZC1[this.castling];
    c ^= ZC2[this.castling];
    if (this.ep >= 0) {
      a ^= ZE1[this.ep & 7];
      c ^= ZE2[this.ep & 7];
    }
    if (this.side === BLACK) {
      a ^= ZS1;
      c ^= ZS2;
    }
    this.h1 = a;
    this.h2 = c;
  }

  get key(): number {
    return (this.h1 >>> 0) * 2097152 + (this.h2 & 0x1fffff);
  }

  isAttacked(sq: number, by: number): boolean {
    const b = this.b;
    const hi = by << 3;
    // пешки
    if (by === WHITE) {
      let s = sq - 15;
      if (!(s & 0x88) && b[s] === P) return true;
      s = sq - 17;
      if (!(s & 0x88) && b[s] === P) return true;
    } else {
      let s = sq + 15;
      if (!(s & 0x88) && b[s] === (P | 8)) return true;
      s = sq + 17;
      if (!(s & 0x88) && b[s] === (P | 8)) return true;
    }
    for (let i = 0; i < 8; i++) {
      let s = sq + KN[i];
      if (!(s & 0x88) && b[s] === (N | hi)) return true;
      s = sq + KG[i];
      if (!(s & 0x88) && b[s] === (K | hi)) return true;
    }
    for (let i = 0; i < 4; i++) {
      let s = sq + BD[i];
      while (!(s & 0x88)) {
        const p = b[s];
        if (p) {
          if (p === (B | hi) || p === (Q | hi)) return true;
          break;
        }
        s += BD[i];
      }
      s = sq + RD[i];
      while (!(s & 0x88)) {
        const p = b[s];
        if (p) {
          if (p === (R | hi) || p === (Q | hi)) return true;
          break;
        }
        s += RD[i];
      }
    }
    return false;
  }

  inCheck(): boolean {
    return this.isAttacked(this.kingSq[this.side], this.side ^ 1);
  }

  /** Псевдолегальные ходы. capsOnly — только взятия и превращения в ферзя */
  genMoves(capsOnly = false): number[] {
    const out: number[] = [];
    const b = this.b;
    const us = this.side;
    for (let sq = 0; sq < 128; sq++) {
      if (sq & 0x88) {
        sq += 7;
        continue;
      }
      const p = b[sq];
      if (!p || p >> 3 !== us) continue;
      const t = p & 7;
      if (t === P) {
        const dir = us === WHITE ? 16 : -16;
        const startRank = us === WHITE ? 1 : 6;
        const promoRank = us === WHITE ? 6 : 1;
        const rank = sq >> 4;
        const one = sq + dir;
        if (!b[one]) {
          if (rank === promoRank) {
            out.push(mk(sq, one, Q, 0));
            if (!capsOnly) out.push(mk(sq, one, R, 0), mk(sq, one, B, 0), mk(sq, one, N, 0));
          } else if (!capsOnly) {
            out.push(mk(sq, one, 0, 0));
            if (rank === startRank && !b[one + dir]) out.push(mk(sq, one + dir, 0, FLAG_DOUBLE));
          }
        }
        for (let k = -1; k <= 1; k += 2) {
          const to = sq + dir + k;
          if (to & 0x88) continue;
          const q = b[to];
          if (q && q >> 3 !== us) {
            if (rank === promoRank) {
              out.push(mk(sq, to, Q, FLAG_CAP));
              if (!capsOnly) out.push(mk(sq, to, R, FLAG_CAP), mk(sq, to, B, FLAG_CAP), mk(sq, to, N, FLAG_CAP));
            } else out.push(mk(sq, to, 0, FLAG_CAP));
          } else if (!q && to === this.ep) {
            out.push(mk(sq, to, 0, FLAG_CAP | FLAG_EP));
          }
        }
      } else if (t === N || t === K) {
        const offs = t === N ? KN : KG;
        for (let i = 0; i < 8; i++) {
          const to = sq + offs[i];
          if (to & 0x88) continue;
          const q = b[to];
          if (!q) {
            if (!capsOnly) out.push(mk(sq, to, 0, 0));
          } else if (q >> 3 !== us) out.push(mk(sq, to, 0, FLAG_CAP));
        }
      } else {
        const dirs = t === B ? BD : t === R ? RD : KG;
        for (let i = 0; i < dirs.length; i++) {
          const d = dirs[i];
          let to = sq + d;
          while (!(to & 0x88)) {
            const q = b[to];
            if (!q) {
              if (!capsOnly) out.push(mk(sq, to, 0, 0));
            } else {
              if (q >> 3 !== us) out.push(mk(sq, to, 0, FLAG_CAP));
              break;
            }
            to += d;
          }
        }
      }
    }
    if (!capsOnly) {
      if (us === WHITE) {
        if (this.castling & 1 && b[4] === K && b[7] === R && !b[5] && !b[6]) {
          if (!this.isAttacked(4, 1) && !this.isAttacked(5, 1) && !this.isAttacked(6, 1))
            out.push(mk(4, 6, 0, FLAG_CASTLE));
        }
        if (this.castling & 2 && b[4] === K && b[0] === R && !b[1] && !b[2] && !b[3]) {
          if (!this.isAttacked(4, 1) && !this.isAttacked(3, 1) && !this.isAttacked(2, 1))
            out.push(mk(4, 2, 0, FLAG_CASTLE));
        }
      } else {
        const bk = K | 8,
          br = R | 8;
        if (this.castling & 4 && b[116] === bk && b[119] === br && !b[117] && !b[118]) {
          if (!this.isAttacked(116, 0) && !this.isAttacked(117, 0) && !this.isAttacked(118, 0))
            out.push(mk(116, 118, 0, FLAG_CASTLE));
        }
        if (this.castling & 8 && b[116] === bk && b[112] === br && !b[113] && !b[114] && !b[115]) {
          if (!this.isAttacked(116, 0) && !this.isAttacked(115, 0) && !this.isAttacked(114, 0))
            out.push(mk(116, 114, 0, FLAG_CASTLE));
        }
      }
    }
    return out;
  }

  /** Делает ход. Возвращает false (и откатывает), если ход оставляет короля под шахом */
  make(m: number): boolean {
    const b = this.b;
    const from = mFrom(m),
      to = mTo(m),
      promo = mPromo(m),
      flags = mFlags(m);
    const us = this.side;
    const piece = b[from];
    let captured = b[to];

    const i = this.n++;
    this.uMove[i] = m;
    this.uCastle[i] = this.castling;
    this.uEp[i] = this.ep;
    this.uHalf[i] = this.half;
    this.uH1[i] = this.h1;
    this.uH2[i] = this.h2;

    let a = this.h1,
      c = this.h2;
    a ^= ZC1[this.castling];
    c ^= ZC2[this.castling];
    if (this.ep >= 0) {
      a ^= ZE1[this.ep & 7];
      c ^= ZE2[this.ep & 7];
    }

    if (flags & FLAG_EP) {
      const capSq = us === WHITE ? to - 16 : to + 16;
      captured = b[capSq];
      b[capSq] = 0;
      a ^= Z1[captured][capSq];
      c ^= Z2[captured][capSq];
    } else if (captured) {
      a ^= Z1[captured][to];
      c ^= Z2[captured][to];
    }
    this.uCap[i] = captured;

    const placed = promo ? promo | (us << 3) : piece;
    a ^= Z1[piece][from] ^ Z1[placed][to];
    c ^= Z2[piece][from] ^ Z2[placed][to];
    b[from] = 0;
    b[to] = placed;

    if (flags & FLAG_CASTLE) {
      let rf: number, rt: number;
      if (to > from) {
        rf = from + 3;
        rt = from + 1;
      } else {
        rf = from - 4;
        rt = from - 1;
      }
      const rook = b[rf];
      b[rf] = 0;
      b[rt] = rook;
      a ^= Z1[rook][rf] ^ Z1[rook][rt];
      c ^= Z2[rook][rf] ^ Z2[rook][rt];
    }

    if ((piece & 7) === K) this.kingSq[us] = to;

    this.ep = flags & FLAG_DOUBLE ? (from + to) >> 1 : -1;
    this.castling &= CASTLE_MASK[from] & CASTLE_MASK[to];
    this.half = (piece & 7) === P || captured ? 0 : this.half + 1;

    a ^= ZC1[this.castling];
    c ^= ZC2[this.castling];
    if (this.ep >= 0) {
      a ^= ZE1[this.ep & 7];
      c ^= ZE2[this.ep & 7];
    }
    a ^= ZS1;
    c ^= ZS2;
    this.h1 = a;
    this.h2 = c;
    this.side = us ^ 1;

    if (this.isAttacked(this.kingSq[us], us ^ 1)) {
      this.unmake();
      return false;
    }
    return true;
  }

  unmake() {
    const i = --this.n;
    const m = this.uMove[i];
    const b = this.b;
    const from = mFrom(m),
      to = mTo(m),
      promo = mPromo(m),
      flags = mFlags(m);
    this.side ^= 1;
    const us = this.side;
    const placed = b[to];
    const piece = promo ? P | (us << 3) : placed;
    b[from] = piece;
    if (flags & FLAG_EP) {
      b[to] = 0;
      b[us === WHITE ? to - 16 : to + 16] = this.uCap[i];
    } else b[to] = this.uCap[i];

    if (flags & FLAG_CASTLE) {
      let rf: number, rt: number;
      if (to > from) {
        rf = from + 3;
        rt = from + 1;
      } else {
        rf = from - 4;
        rt = from - 1;
      }
      b[rf] = b[rt];
      b[rt] = 0;
    }
    if ((piece & 7) === K) this.kingSq[us] = from;
    this.castling = this.uCastle[i];
    this.ep = this.uEp[i];
    this.half = this.uHalf[i];
    this.h1 = this.uH1[i];
    this.h2 = this.uH2[i];
  }

  makeNull() {
    const i = this.n++;
    this.uMove[i] = 0;
    this.uEp[i] = this.ep;
    this.uHalf[i] = this.half;
    this.uH1[i] = this.h1;
    this.uH2[i] = this.h2;
    this.uCastle[i] = this.castling;
    if (this.ep >= 0) {
      this.h1 ^= ZE1[this.ep & 7];
      this.h2 ^= ZE2[this.ep & 7];
    }
    this.ep = -1;
    this.h1 ^= ZS1;
    this.h2 ^= ZS2;
    this.side ^= 1;
  }

  unmakeNull() {
    const i = --this.n;
    this.side ^= 1;
    this.ep = this.uEp[i];
    this.half = this.uHalf[i];
    this.h1 = this.uH1[i];
    this.h2 = this.uH2[i];
  }

  /** Повторение позиции (достаточно одного предыдущего вхождения) */
  isRepetition(): boolean {
    const lim = Math.max(0, this.n - this.half);
    for (let i = this.n - 2; i >= lim; i -= 2) {
      if (this.uH1[i] === this.h1 && this.uH2[i] === this.h2) return true;
    }
    return false;
  }

  /** Находит легальный ход по строке UCI */
  findUci(uci: string): number | null {
    const moves = this.genMoves();
    for (const m of moves) {
      if (moveToUci(m) === uci) {
        if (this.make(m)) {
          this.unmake();
          return m;
        }
      }
    }
    return null;
  }

  playUci(uci: string): boolean {
    const m = this.findUci(uci);
    if (m === null) return false;
    this.make(m);
    return true;
  }

  legalMoves(): number[] {
    const res: number[] = [];
    for (const m of this.genMoves()) {
      if (this.make(m)) {
        this.unmake();
        res.push(m);
      }
    }
    return res;
  }

  perft(depth: number): number {
    if (depth === 0) return 1;
    let total = 0;
    for (const m of this.genMoves()) {
      if (!this.make(m)) continue;
      total += this.perft(depth - 1);
      this.unmake();
    }
    return total;
  }
}
