import { Board, FLAG_CAP, FLAG_EP, mFlags, mFrom, mPromo, mTo, moveToUci } from './board';
import { evaluate, VALUE, type EvalFlags } from './eval';

export const MATE = 100000;
const INF = 1000000;
const MAX_PLY = 90;

export interface SearchParams extends EvalFlags {
  depth: number;
  timeMs: number;
  quiescence: boolean;
  qDepth: number;
  useTT: boolean;
  checkExt: boolean;
  nullMove: boolean;
  lmr: boolean;
  multiPV: number;
}

export interface SearchLine {
  uci: string;
  score: number; // сантипешки, с точки зрения стороны, которая ходит
  pv: string[]; // UCI
}

export interface SearchInfo {
  depth: number;
  nodes: number;
  timeMs: number;
  lines: SearchLine[];
}

class Abort {}

interface TTEntry {
  depth: number;
  score: number;
  flag: number; // 0 точно, 1 нижняя граница, 2 верхняя
  move: number;
}

export function runSearch(
  startFen: string,
  moveList: string[],
  p: SearchParams,
  onInfo: (i: SearchInfo) => void,
): SearchInfo | null {
  const bd = Board.fromFen(startFen);
  for (const u of moveList) bd.playUci(u);

  const t0 = Date.now();
  const deadline = t0 + p.timeMs;
  let nodes = 0;
  let canAbort = false;

  const tt = new Map<number, TTEntry>();
  const killers: number[][] = Array.from({ length: MAX_PLY + 2 }, () => [0, 0]);
  const history = new Int32Array(128 * 128);
  const pvTable: number[][] = Array.from({ length: MAX_PLY + 2 }, () => new Array(MAX_PLY + 2).fill(0));
  const pvLen = new Int32Array(MAX_PLY + 2);

  const hasPieces = (side: number) => {
    const b = bd.b;
    for (let sq = 0; sq < 128; sq++) {
      if (sq & 0x88) {
        sq += 7;
        continue;
      }
      const x = b[sq];
      if (x && x >> 3 === side) {
        const t = x & 7;
        if (t !== 1 && t !== 6) return true;
      }
    }
    return false;
  };

  const moveScore = (m: number, ttMove: number, ply: number) => {
    if (m === ttMove) return 1e7;
    const fl = mFlags(m);
    if (fl & FLAG_CAP) {
      const victim = fl & FLAG_EP ? 1 : bd.b[mTo(m)] & 7;
      return 1e6 + victim * 10 - (bd.b[mFrom(m)] & 7) + (mPromo(m) ? 500 : 0);
    }
    if (mPromo(m)) return 9e5 + mPromo(m);
    if (m === killers[ply][0]) return 8e5;
    if (m === killers[ply][1]) return 7e5;
    return history[(mFrom(m) << 7) | mTo(m)];
  };

  const checkTime = () => {
    if (canAbort && (nodes & 2047) === 0 && Date.now() > deadline) throw new Abort();
  };

  function qsearch(alpha: number, beta: number, ply: number, qd: number): number {
    nodes++;
    checkTime();
    const stand = evaluate(bd, p);
    if (stand >= beta) return stand;
    if (stand > alpha) alpha = stand;
    if (qd >= p.qDepth || ply >= MAX_PLY) return alpha;

    const moves = bd.genMoves(true);
    const sc = moves.map((m) => moveScore(m, 0, ply));
    for (let i = 0; i < moves.length; i++) {
      let bi = i;
      for (let j = i + 1; j < moves.length; j++) if (sc[j] > sc[bi]) bi = j;
      if (bi !== i) {
        [moves[i], moves[bi]] = [moves[bi], moves[i]];
        [sc[i], sc[bi]] = [sc[bi], sc[i]];
      }
      const m = moves[i];
      if (!mPromo(m)) {
        const victim = mFlags(m) & FLAG_EP ? 1 : bd.b[mTo(m)] & 7;
        if (stand + VALUE[victim] + 200 < alpha) continue;
      }
      if (!bd.make(m)) continue;
      const s = -qsearch(-beta, -alpha, ply + 1, qd + 1);
      bd.unmake();
      if (s >= beta) return s;
      if (s > alpha) alpha = s;
    }
    return alpha;
  }

  function negamax(depth: number, alpha: number, beta: number, ply: number, allowNull: boolean): number {
    nodes++;
    checkTime();
    pvLen[ply] = ply;
    if (ply > 0 && (bd.half >= 100 || bd.isRepetition())) return 0;
    if (ply >= MAX_PLY) return evaluate(bd, p);

    const inCheck = bd.inCheck();
    if (inCheck && p.checkExt) depth++;
    if (depth <= 0) return p.quiescence ? qsearch(alpha, beta, ply, 0) : evaluate(bd, p);

    const key = bd.key;
    let ttMove = 0;
    if (p.useTT) {
      const e = tt.get(key);
      if (e) {
        ttMove = e.move;
        if (ply > 0 && e.depth >= depth) {
          let s = e.score;
          if (s > MATE - 1000) s -= ply;
          else if (s < -MATE + 1000) s += ply;
          if (e.flag === 0) return s;
          if (e.flag === 1 && s >= beta) return s;
          if (e.flag === 2 && s <= alpha) return s;
        }
      }
    }

    if (p.nullMove && allowNull && !inCheck && depth >= 3 && beta < MATE - 1000 && hasPieces(bd.side)) {
      bd.makeNull();
      const s = -negamax(depth - 3, -beta, -beta + 1, ply + 1, false);
      bd.unmakeNull();
      if (s >= beta) return s < MATE - 1000 ? s : beta;
    }

    const moves = bd.genMoves();
    const sc = moves.map((m) => moveScore(m, ttMove, ply));
    const alpha0 = alpha;
    let best = -INF;
    let bestMove = 0;
    let legal = 0;

    for (let i = 0; i < moves.length; i++) {
      let bi = i;
      for (let j = i + 1; j < moves.length; j++) if (sc[j] > sc[bi]) bi = j;
      if (bi !== i) {
        [moves[i], moves[bi]] = [moves[bi], moves[i]];
        [sc[i], sc[bi]] = [sc[bi], sc[i]];
      }
      const m = moves[i];
      const quiet = !(mFlags(m) & FLAG_CAP) && !mPromo(m);
      if (!bd.make(m)) continue;
      legal++;
      let score: number;
      if (legal === 1) {
        score = -negamax(depth - 1, -beta, -alpha, ply + 1, true);
      } else {
        let r = 0;
        if (p.lmr && legal > 4 && depth >= 3 && !inCheck && quiet) r = legal > 10 ? 2 : 1;
        score = -negamax(depth - 1 - r, -alpha - 1, -alpha, ply + 1, true);
        if (score > alpha && r > 0) score = -negamax(depth - 1, -alpha - 1, -alpha, ply + 1, true);
        if (score > alpha && score < beta) score = -negamax(depth - 1, -beta, -alpha, ply + 1, true);
      }
      bd.unmake();

      if (score > best) {
        best = score;
        bestMove = m;
        if (score > alpha) {
          alpha = score;
          pvTable[ply][ply] = m;
          for (let k = ply + 1; k < pvLen[ply + 1]; k++) pvTable[ply][k] = pvTable[ply + 1][k];
          pvLen[ply] = Math.max(ply + 1, pvLen[ply + 1]);
          if (alpha >= beta) {
            if (quiet) {
              if (killers[ply][0] !== m) {
                killers[ply][1] = killers[ply][0];
                killers[ply][0] = m;
              }
              history[(mFrom(m) << 7) | mTo(m)] += depth * depth;
            }
            break;
          }
        }
      }
    }

    if (legal === 0) return inCheck ? -MATE + ply : 0;

    if (p.useTT) {
      if (tt.size > 1_500_000) tt.clear();
      let s = best;
      if (s > MATE - 1000) s += ply;
      else if (s < -MATE + 1000) s -= ply;
      tt.set(key, {
        depth,
        score: s,
        flag: best <= alpha0 ? 2 : best >= beta ? 1 : 0,
        move: bestMove,
      });
    }
    return best;
  }

  // ---- корень с итеративным углублением и MultiPV ----
  const rootMoves = bd.legalMoves();
  if (!rootMoves.length) return null;
  const k = Math.max(1, Math.min(p.multiPV, rootMoves.length));
  const rootScore = new Map<number, number>();
  rootMoves.forEach((m) => rootScore.set(m, 0));
  let last: SearchInfo | null = null;

  for (let depth = 1; depth <= p.depth; depth++) {
    canAbort = depth > 1;
    rootMoves.sort((a, b) => (rootScore.get(b) ?? 0) - (rootScore.get(a) ?? 0));
    try {
      const lines: { m: number; score: number; pv: number[] }[] = [];
      for (const m of rootMoves) {
        bd.make(m);
        const alpha = lines.length >= k ? lines[k - 1].score : -INF;
        const score = -negamax(depth - 1, -INF, alpha === -INF ? INF : -alpha, 1, true);
        const pv = [m];
        for (let i = 1; i < pvLen[1]; i++) pv.push(pvTable[1][i]);
        bd.unmake();
        rootScore.set(m, score);
        if (lines.length < k || score > alpha) {
          lines.push({ m, score, pv });
          lines.sort((a, b) => b.score - a.score);
          if (lines.length > k) lines.pop();
        }
      }
      const info: SearchInfo = {
        depth,
        nodes,
        timeMs: Date.now() - t0,
        lines: lines.map((l) => ({ uci: moveToUci(l.m), score: l.score, pv: l.pv.map(moveToUci) })),
      };
      last = info;
      onInfo(info);
      // победа/мат найден или единственный ход — дальше искать не нужно
      if (Math.abs(lines[0].score) > MATE - 100) break;
      if (rootMoves.length === 1 && depth >= 2) break;
      if (Date.now() - t0 > p.timeMs * 0.5) break;
    } catch (e) {
      if (e instanceof Abort) break;
      throw e;
    }
  }
  return last;
}
