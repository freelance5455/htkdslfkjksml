export const LAYOUTS = [
  "single",
  "v2",
  "f2",
  "i2",
  "v3",
  "i3",
  "f3",
  "v4",
  "i4",
  "f4",
  "i5",
  "v6",
  "v8",
  "v10",
  "v12",
  "w12",
] as const;

export type LayoutId = (typeof LAYOUTS)[number];
export type Fuel = "gas" | "dsl";
export type Exhaust = "stock" | "sport" | "straight" | "open";

export type Spec = {
  twin: boolean;
  ecu: boolean;
  map: number;
  lim: number;
  bst: number;
  exh: Exhaust;
  pop: boolean;
  fuel: Fuel;
  type: LayoutId;
  bore: number;
  stroke: number;
  carb: boolean;
  turbo: boolean;
  sc: boolean;
  color: string;
};

export type Live = {
  rpm: number;
  thr: number;
  pedal: number;
  brake: number;
  brk: number;
  gear: number;
  spd: number;
  dead: boolean;
  deadT: number;
  stopT: number;
  stall: boolean;
  crank: number;
  cut: boolean;
  cutT: number;
  rel: boolean;
  limCd: number;
  clu: number;
  cin: number;
  grind: number;
  msg: number;
};

export const COLORS = ["#7b8494", "#c0392b", "#2f6fd0", "#c9a227"] as const;

export const CYL: Record<LayoutId, number> = {
  single: 1,
  v2: 2,
  f2: 2,
  i2: 2,
  v3: 3,
  i3: 3,
  f3: 3,
  v4: 4,
  i4: 4,
  f4: 4,
  i5: 5,
  v6: 6,
  v8: 8,
  v10: 10,
  v12: 12,
  w12: 12,
};

export function defaultSpec(): Spec {
  return {
    twin: false,
    ecu: false,
    map: 10,
    lim: 0,
    bst: 10,
    exh: "stock",
    pop: false,
    fuel: "gas",
    type: "i4",
    bore: 82,
    stroke: 86,
    carb: false,
    turbo: false,
    sc: false,
    color: COLORS[0],
  };
}

const EXH: Exhaust[] = ["stock", "sport", "straight", "open"];

export function sanitize(input: unknown): Spec {
  const d = defaultSpec();
  if (!input || typeof input !== "object") return d;
  const o = input as Partial<Spec>;
  const type = LAYOUTS.includes(o.type as LayoutId) ? (o.type as LayoutId) : d.type;
  const fuel: Fuel = o.fuel === "dsl" ? "dsl" : "gas";
  const exh = EXH.includes(o.exh as Exhaust) ? (o.exh as Exhaust) : d.exh;
  const color = COLORS.includes(o.color as (typeof COLORS)[number]) ? (o.color as string) : d.color;
  const num = (v: unknown, min: number, max: number, fallback: number) => {
    const n = typeof v === "number" ? v : Number(v);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, n));
  };
  return {
    twin: !!o.twin,
    ecu: !!o.ecu,
    map: num(o.map, 0, 30, d.map),
    lim: num(o.lim, -10, 20, d.lim),
    bst: num(o.bst, 0, 50, d.bst),
    exh,
    pop: !!o.pop,
    fuel,
    type,
    bore: num(o.bore, 50, 110, d.bore),
    stroke: num(o.stroke, 50, 110, d.stroke),
    carb: fuel === "dsl" ? false : !!o.carb,
    turbo: !!o.turbo,
    sc: !!o.sc,
    color,
  };
}

export function createLive(): Live {
  return {
    rpm: 0,
    thr: 0,
    pedal: 0,
    brake: 0,
    brk: 0,
    gear: 0,
    spd: 0,
    dead: false,
    deadT: 0,
    stopT: 0,
    stall: true,
    crank: 0,
    cut: false,
    cutT: 0,
    rel: false,
    limCd: 0,
    clu: 0,
    cin: 0,
    grind: 0,
    msg: 0,
  };
}
