/**
 * Arabic character normalization rules specifically tailored for traditional Arabic crosswords.
 * 
 * Rules:
 * - All forms of Alef with Hamza or Madd (أ, إ, آ, ٱ) normalize to plain "ا".
 * - "ي" and "ى" are DIFFERENT letters (Do NOT normalize between them).
 * - "ه" and "ة" are DIFFERENT letters (Do NOT normalize between them).
 * - Strips Arabic diacritics (Tashkeel).
 */

export function normalizeArabicChar(char: string): string {
  if (!char) return '';
  
  // Strip Tashkeel (diacritics)
  const cleanChar = char.replace(/[\u064B-\u0652\u0670]/g, '');
  if (!cleanChar) return '';

  // Normalize Alef variants ONLY
  if (['أ', 'إ', 'آ', 'ٱ'].includes(cleanChar)) {
    return 'ا';
  }

  return cleanChar;
}

export function normalizeArabicString(str: string): string {
  if (!str) return '';
  // In crossword puzzles, all whitespace (spaces/tabs/newlines) between compound words
  // are stripped so characters flow sequentially into grid cells without empty spaces.
  return str
    .replace(/\s+/g, '')
    .split('')
    .map(normalizeArabicChar)
    .filter((c) => Boolean(c))
    .join('');
}

/**
 * Returns the target character sequence for a word in cell input order.
 * If word.reversed is true, the sequence is inverted.
 * Example: answer "كهف أفلاطون" => ["ك", "ه", "ف", "ا", "ف", "ل", "ا", "ط", "و", "ن"]
 * Example: answer "عراق", reversed = true => input sequence ["ق", "ا", "ر", "ع"]
 */
export function getWordInputSequence(answer: string, reversed?: boolean): string[] {
  const normalized = normalizeArabicString(answer);
  const chars = Array.from(normalized);
  if (reversed) {
    return chars.reverse();
  }
  return chars;
}
