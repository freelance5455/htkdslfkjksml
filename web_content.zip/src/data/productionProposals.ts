import { ProgramGenre, TimeSlotId, ProductionProposal } from '../types/game';

interface ProposalTemplate {
  title: string;
  genre: ProgramGenre;
  synopsis: string;
  recommendedSlot: TimeSlotId;
  baseQuality: number;
  baseCost: number;
  seasonTotal: number;
  setupCost: number;
}

export const PROPOSAL_TEMPLATES: ProposalTemplate[] = [
  // Novelas
  {
    title: 'Terra da Paixão',
    genre: 'novela',
    synopsis: 'Superprodução rural com disputa de terras, herança de família e um amor proibido entre duas dinastias rivais.',
    recommendedSlot: 'primetime',
    baseQuality: 86,
    baseCost: 2800,
    seasonTotal: 90,
    setupCost: 7500,
  },
  {
    title: 'Sombras do Passado',
    genre: 'novela',
    synopsis: 'Trama de suspense e vingança no Rio de Janeiro. Uma jovem retorna com nova identidade para expor a vilã que destruiu sua vida.',
    recommendedSlot: 'primetime',
    baseQuality: 82,
    baseCost: 2400,
    seasonTotal: 85,
    setupCost: 6500,
  },
  {
    title: 'Flor de Lótus: Amor de Época',
    genre: 'novela',
    synopsis: 'Romance histórico ambientado nos anos 1920 entre imigrantes recém-chegados e a aristocracia cafeeira paulista.',
    recommendedSlot: 'afternoon',
    baseQuality: 78,
    baseCost: 2100,
    seasonTotal: 75,
    setupCost: 5500,
  },
  {
    title: 'Coração Sertanejo',
    genre: 'novela',
    synopsis: 'A trajetória de dois irmãos cantores no interior do Brasil rumo ao estrelato nacional, recheada de paixões e traições.',
    recommendedSlot: 'primetime',
    baseQuality: 84,
    baseCost: 2500,
    seasonTotal: 80,
    setupCost: 6800,
  },

  // Séries / Policial / Suspense
  {
    title: 'Operação Fronteira',
    genre: 'filme',
    synopsis: 'Série policial de ação rápida com perseguições, investigação tática e helicópteros desarticulando esquemas de contrabando.',
    recommendedSlot: 'latenight',
    baseQuality: 85,
    baseCost: 2600,
    seasonTotal: 30,
    setupCost: 6000,
  },
  {
    title: 'Plantão Noturno',
    genre: 'filme',
    synopsis: 'Drama médico intenso que acompanha a rotina de médicos e enfermeiros em um hospital de emergência durante as madrugadas.',
    recommendedSlot: 'latenight',
    baseQuality: 79,
    baseCost: 2200,
    seasonTotal: 26,
    setupCost: 5000,
  },
  {
    title: 'O Código dos Bastidores',
    genre: 'filme',
    synopsis: 'Thriller político sobre jornalistas investigativos que descobrem escutas ilegais e transações misteriosas no Congresso.',
    recommendedSlot: 'latenight',
    baseQuality: 81,
    baseCost: 2300,
    seasonTotal: 24,
    setupCost: 5200,
  },

  // Reality Shows
  {
    title: 'A Fazenda dos Confinados',
    genre: 'reality',
    synopsis: 'Famosos e subcelebridades isolados em um sítio cuidando de animais, com votação popular ao vivo e barracos diários.',
    recommendedSlot: 'primetime',
    baseQuality: 88,
    baseCost: 3200,
    seasonTotal: 45,
    setupCost: 8000,
  },
  {
    title: 'Batalha dos Mestres da Cozinha',
    genre: 'reality',
    synopsis: 'Competição gastronômica com chefs exigentes avaliando pratos típicos sob pressão do cronômetro.',
    recommendedSlot: 'afternoon',
    baseQuality: 77,
    baseCost: 2000,
    seasonTotal: 35,
    setupCost: 4800,
  },
  {
    title: 'Mansão dos Segredos',
    genre: 'reality',
    synopsis: 'Vinte solteiros confinados em uma mansão cinematográfica competindo por R$ 1 milhão com provas de resistência.',
    recommendedSlot: 'latenight',
    baseQuality: 83,
    baseCost: 2700,
    seasonTotal: 40,
    setupCost: 6200,
  },

  // Auditório
  {
    title: 'Domingo Show de Prêmios',
    genre: 'auditorio',
    synopsis: 'Programa vibrante com auditório lotado, caravanas de todo o país, gincanas divertidas e entrega de casas e carros.',
    recommendedSlot: 'afternoon',
    baseQuality: 82,
    baseCost: 2400,
    seasonTotal: 52,
    setupCost: 5800,
  },
  {
    title: 'Noite das Estrelas',
    genre: 'auditorio',
    synopsis: 'Música ao vivo com os maiores cantores do momento, entrevistas bem-humoradas e homenagens emocionantes.',
    recommendedSlot: 'primetime',
    baseQuality: 85,
    baseCost: 2900,
    seasonTotal: 40,
    setupCost: 7000,
  },

  // Jornalismo Especial
  {
    title: 'Brasilis Repórter Especial',
    genre: 'jornalismo',
    synopsis: 'Grande reportagem semanal com documentários exclusivos, viagens a lugares remotos e denúncias de grande impacto.',
    recommendedSlot: 'latenight',
    baseQuality: 84,
    baseCost: 2200,
    seasonTotal: 36,
    setupCost: 4500,
  },
  {
    title: 'Alerta da Manhã',
    genre: 'jornalismo',
    synopsis: 'Jornalismo comunitário ágil com helicóptero ao vivo, prestação de serviços, trânsito nas pontes e o clima do dia.',
    recommendedSlot: 'morning',
    baseQuality: 80,
    baseCost: 1900,
    seasonTotal: 60,
    setupCost: 4000,
  },
];

let lastProposalIndex = 0;

export function generateRandomProposal(directorName: string): ProductionProposal {
  const index = (lastProposalIndex + Math.floor(Math.random() * 3) + 1) % PROPOSAL_TEMPLATES.length;
  lastProposalIndex = index;
  const tmpl = PROPOSAL_TEMPLATES[index];

  // Slight random variation in quality and cost
  const qualityVariance = Math.floor(Math.random() * 7) - 3;
  const estimatedQuality = Math.min(95, Math.max(65, tmpl.baseQuality + qualityVariance));
  const costVariance = Math.floor(Math.random() * 300) - 150;
  const productionCost = Math.max(1200, tmpl.baseCost + costVariance);

  return {
    id: `proposal-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    title: tmpl.title,
    genre: tmpl.genre,
    synopsis: tmpl.synopsis,
    directorName,
    estimatedQuality,
    productionCost,
    seasonTotal: tmpl.seasonTotal,
    recommendedSlot: tmpl.recommendedSlot,
    suggestedTalentId: null,
    hype: 70 + Math.floor(Math.random() * 15),
    setupCost: tmpl.setupCost,
  };
}
