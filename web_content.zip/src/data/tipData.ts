import { TipCategoryMeta, HealthTipItem, TipLanguage } from '../types/tip';

export const TIP_CATEGORIES: TipCategoryMeta[] = [
  {
    id: 'general-health',
    emoji: '❤️',
    iconBg: 'bg-rose-500',
    badgeBg: 'bg-rose-50 text-rose-700 border-rose-200',
    nameEn: 'General Health',
    nameHi: 'सामान्य स्वास्थ्य',
    nameMr: 'सामान्य आरोग्य',
    descriptionEn: 'Essential daily habits for overall vitality and wellness.',
    descriptionHi: 'समग्र जीवन शक्ति के लिए दैनिक आवश्यक आदतें।',
    descriptionMr: 'सर्वांगीण आरोग्यासाठी आवश्यक दैनंदिन सवयी.'
  },
  {
    id: 'nutrition-tips',
    emoji: '🥗',
    iconBg: 'bg-emerald-500',
    badgeBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    nameEn: 'Nutrition Tips',
    nameHi: 'पोषण और आहार',
    nameMr: 'पोषण आणि आहार',
    descriptionEn: 'Balanced diet strategies, superfoods, and meal timing.',
    descriptionHi: 'संतुलित आहार रणनीतियाँ और सुपरफूड मार्गदर्शन।',
    descriptionMr: 'संतुलित आहार आणि पोषणविषयक मार्गदर्शन.'
  },
  {
    id: 'hydration-tips',
    emoji: '💧',
    iconBg: 'bg-sky-500',
    badgeBg: 'bg-sky-50 text-sky-700 border-sky-200',
    nameEn: 'Hydration Tips',
    nameHi: 'जलपान और हाइड्रेशन',
    nameMr: 'हायड्रेशन आणि पाणी',
    descriptionEn: 'Optimal fluid intake, electrolytes, and water habits.',
    descriptionHi: 'शरीर में पानी का सही संतुलन और हाइड्रेशन मार्गदर्शन।',
    descriptionMr: 'शरीरातील पाण्याचे योग्य प्रमाण आणि सवयी.'
  },
  {
    id: 'fitness-tips',
    emoji: '🏃',
    iconBg: 'bg-orange-500',
    badgeBg: 'bg-orange-50 text-orange-700 border-orange-200',
    nameEn: 'Fitness Tips',
    nameHi: 'फिटनेस और व्यायाम',
    nameMr: 'फिटनेस आणि व्यायाम',
    descriptionEn: 'Daily movement, aerobic health, and posture support.',
    descriptionHi: 'शारीरिक व्यायाम, स्ट्रेंथ और पोस्टचर गाइड।',
    descriptionMr: 'दैनंदिन हालचाली आणि शारीरिक तंदुरुस्ती.'
  },
  {
    id: 'sleep-tips',
    emoji: '😴',
    iconBg: 'bg-indigo-500',
    badgeBg: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    nameEn: 'Sleep Tips',
    nameHi: 'नींद और विश्राम',
    nameMr: 'झोप आणि विश्रांती',
    descriptionEn: 'Circadian rhythm, restorative sleep, and night routines.',
    descriptionHi: 'गहरी नींद और बॉडी रिकवरी के वैज्ञानिक उपाय।',
    descriptionMr: 'शांत झोप आणि मानसिक विश्रांतीसाठी टिप्स.'
  },
  {
    id: 'mental-wellness',
    emoji: '🧠',
    iconBg: 'bg-purple-500',
    badgeBg: 'bg-purple-50 text-purple-700 border-purple-200',
    nameEn: 'Mental Wellness',
    nameHi: 'मानसिक स्वास्थ्य',
    nameMr: 'मानसिक आरोग्य',
    descriptionEn: 'Stress management, mindfulness, and cognitive health.',
    descriptionHi: 'तनाव मुक्ति, ध्यान और मानसिक शांति।',
    descriptionMr: 'ताणतणाव व्यवस्थापन आणि मानसिक शांतता.'
  },
  {
    id: 'medicine-safety',
    emoji: '💊',
    iconBg: 'bg-blue-500',
    badgeBg: 'bg-blue-50 text-blue-700 border-blue-200',
    nameEn: 'Medicine Safety',
    nameHi: 'दवा सुरक्षा',
    nameMr: 'औधध सुरक्षा',
    descriptionEn: 'Proper dosage, interactions, and safe storage.',
    descriptionHi: 'दवाइयों का सही सेवन और दुष्प्रभाव से बचाव।',
    descriptionMr: 'औषधांचा योग्य वापर आणि खबरदारी.'
  },
  {
    id: 'disease-prevention',
    emoji: '🦠',
    iconBg: 'bg-teal-500',
    badgeBg: 'bg-teal-50 text-teal-700 border-teal-200',
    nameEn: 'Disease Prevention',
    nameHi: 'रोग रोकथाम',
    nameMr: 'आजार प्रतिबंध',
    descriptionEn: 'Hygiene, vaccination, and screening guidelines.',
    descriptionHi: 'संक्रमण और पुरानी बीमारियों से सुरक्षा नियम।',
    descriptionMr: 'संसर्गजन्य आणि जुनाट आजारांपासून बचाव.'
  },
  {
    id: 'child-health',
    emoji: '👶',
    iconBg: 'bg-pink-500',
    badgeBg: 'bg-pink-50 text-pink-700 border-pink-200',
    nameEn: 'Child Health',
    nameHi: 'बाल स्वास्थ्य',
    nameMr: 'बाल आरोग्य',
    descriptionEn: 'Pediatric care, growth milestones, and infant immunity.',
    descriptionHi: 'बच्चों का पोषण, टीकाकरण और वृद्धि मार्गदर्शन।',
    descriptionMr: 'लहान मुलांचे पोषण, लसीकरण आणि विकास.'
  },
  {
    id: 'womens-health',
    emoji: '👩',
    iconBg: 'bg-fuchsia-500',
    badgeBg: 'bg-fuchsia-50 text-fuchsia-700 border-fuchsia-200',
    nameEn: "Women's Health",
    nameHi: 'महिला स्वास्थ्य',
    nameMr: 'महिला आरोग्य',
    descriptionEn: 'Hormonal balance, reproductive health, and bone density.',
    descriptionHi: 'हार्मोनल संतुलन, मातृत्व और पोषण।',
    descriptionMr: 'स्त्री आरोग्य, हार्मोन्स आणि पोषण.'
  },
  {
    id: 'senior-health',
    emoji: '👴',
    iconBg: 'bg-amber-500',
    badgeBg: 'bg-amber-50 text-amber-700 border-amber-200',
    nameEn: 'Senior Health',
    nameHi: 'वरिष्ठ नागरिक स्वास्थ्य',
    nameMr: 'जेष्ठ नागरिक आरोग्य',
    descriptionEn: 'Healthy aging, mobility, memory, and joint care.',
    descriptionHi: 'बुजुर्गों की गतिशीलता, स्मृति और जोड़ों की देखभाल।',
    descriptionMr: 'वयोवृद्धांची काळजी, हाडे आणि स्मरणशक्ती.'
  },
  {
    id: 'heart-health',
    emoji: '🫀',
    iconBg: 'bg-red-500',
    badgeBg: 'bg-red-50 text-red-700 border-red-200',
    nameEn: 'Heart Health',
    nameHi: 'हृदय स्वास्थ्य',
    nameMr: 'हृदय आरोग्य',
    descriptionEn: 'Cardiovascular wellness, BP control, and cholesterol.',
    descriptionHi: 'रक्तचाप नियंत्रण और कोलेस्ट्रॉल प्रबंधन।',
    descriptionMr: 'रक्तदाब आणि कोलेस्ट्रॉल नियंत्रण.'
  },
  {
    id: 'diabetes-care',
    emoji: '🩸',
    iconBg: 'bg-cyan-500',
    badgeBg: 'bg-cyan-50 text-cyan-700 border-cyan-200',
    nameEn: 'Diabetes Care',
    nameHi: 'डायबिटीज देखभाल',
    nameMr: 'मधुमेह काळजी',
    descriptionEn: 'Blood glucose monitoring, HbA1c, and carbohydrate tips.',
    descriptionHi: 'ब्लड शुगर लेवल और इंसुलिन संवेदनशीलता।',
    descriptionMr: 'रक्तातील साखरेचे प्रमाण आणि नियंत्रण.'
  },
  {
    id: 'bone-joint',
    emoji: '🦴',
    iconBg: 'bg-yellow-600',
    badgeBg: 'bg-yellow-50 text-yellow-800 border-yellow-200',
    nameEn: 'Bone & Joint Health',
    nameHi: 'हड्डी और जोड़ स्वास्थ्य',
    nameMr: 'हाडे आणि सांधे आरोग्य',
    descriptionEn: 'Calcium, Vitamin D, arthritis prevention, and strength.',
    descriptionHi: 'कैल्शियम, विटामिन डी और गठिया से बचाव।',
    descriptionMr: 'कॅल्शियम, व्हिटॅमिन डी आणि सांधेदुखी.'
  },
  {
    id: 'immunity-tips',
    emoji: '🛡',
    iconBg: 'bg-emerald-600',
    badgeBg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    nameEn: 'Immunity Tips',
    nameHi: 'रोग प्रतिरोधक क्षमता',
    nameMr: 'रोगप्रतिकारशक्ती टिप्स',
    descriptionEn: 'Natural immune boosters, antioxidants, and gut balance.',
    descriptionHi: 'इम्युनिटी बढ़ाने के प्राकृतिक उपाय।',
    descriptionMr: 'रोगप्रतिकारक शक्ती वाढवण्यासाठी नैसर्गिक उपाय.'
  }
];

export const ALL_HEALTH_TIPS: HealthTipItem[] = [
  // 1. GENERAL HEALTH
  {
    id: 'tip-gh-01',
    categoryId: 'general-health',
    tags: ['walking', 'exercise', 'longevity', 'general'],
    content: {
      English: {
        title: '30-Minute Daily Brisk Walk',
        tip: 'Walk briskly for 30 minutes every day to cut cardiovascular disease risk by up to 30%.',
        explanation: 'Regular moderate aerobic walking boosts high-density lipoprotein (HDL) cholesterol while lowering low-density lipoprotein (LDL). It improves systemic circulation, regulates blood pressure, and promotes insulin sensitivity.',
        benefits: ['Improves blood circulation', 'Lowers resting heart rate', 'Enhances mood via endorphin release', 'Helps maintain weight'],
        recommendedFrequency: 'Daily (5 to 7 times a week)',
        source: 'World Health Organization (WHO)'
      },
      Hindi: {
        title: 'रोजाना 30 मिनट की तेज चाल (Brisk Walk)',
        tip: 'रोजाना 30 मिनट तेज गति से टहलने से दिल की बीमारियों का खतरा 30% तक कम हो सकता है।',
        explanation: 'नियमित रूप से मध्यम गति से टहलने से अच्छा कोलेस्ट्रॉल (HDL) बढ़ता है और बुरा कोलेस्ट्रॉल (LDL) घटता है। यह ब्लड प्रेशर को नियंत्रित करता है और इंसुलिन संवेदनशीलता में सुधार करता है।',
        benefits: ['रक्त संचार में सुधार', 'हृदय गति को सामान्य रखना', 'मानसिक तनाव कम करना', 'वजन नियंत्रण में मददगार'],
        recommendedFrequency: 'प्रतिदिन (सप्ताह में 5-7 दिन)',
        source: 'विश्व स्वास्थ्य संगठन (WHO)'
      },
      Marathi: {
        title: 'रोज ५-३० मिनिटे जलद चालणे',
        tip: 'दररोज ३० मिनिटे जलद चालण्याने हृदयाच्या आजारांचा धोका ३०% कमी होतो.',
        explanation: 'नियमित चालण्यामुळे चांगले कोलेस्ट्रॉल (HDL) वाढते आणि वाईट कोलेस्ट्रॉल (LDL) कमी होते. यामुळे रक्ताभिसरण सुधारते आणि रक्तदाब नियंत्रणात राहतो.',
        benefits: ['रक्ताभिसरण सुधारते', 'हृदयाची कार्यक्षमता वाढते', 'ताणतणाव कमी होतो', 'वजन नियंत्रणात राहते'],
        recommendedFrequency: 'दररोज (आवडत्या वेळेत)',
        source: 'जागतिक आरोग्य संघटना (WHO)'
      }
    }
  },
  {
    id: 'tip-gh-02',
    categoryId: 'general-health',
    tags: ['posture', 'ergonomics', 'back pain'],
    content: {
      English: {
        title: 'The 20-20-20 Rule for Digital Eye Strain',
        tip: 'Every 20 minutes of screen usage, look at an object 20 feet away for 20 seconds.',
        explanation: 'Continuous visual focal adjustment on near screens causes ciliary muscle spasm and eye fatigue. Looking into the distance relaxes the focusing mechanism and promotes natural blinking, reducing dry eye symptoms.',
        benefits: ['Reduces digital eye fatigue', 'Prevents tension headaches', 'Relaxes ciliary eye muscles', 'Encourages natural blink rate'],
        recommendedFrequency: 'Every 20 minutes during work',
        source: 'American Academy of Ophthalmology'
      },
      Hindi: {
        title: 'आंखों के तनाव के लिए 20-20-20 नियम',
        tip: 'हर 20 मिनट के स्क्रीन समय के बाद, 20 फीट दूर किसी वस्तु को 20 सेकंड के लिए देखें।',
        explanation: 'लगातार स्क्रीन देखने से आंखों की मांसपेशियां थक जाती हैं। दूर देखने से आंखों के लेंस को विश्राम मिलता है और प्राकृतिक रूप से पलकें झपकती हैं।',
        benefits: ['आंखों का तनाव कम होता है', 'सिरदर्द से राहत मिलती है', 'ड्राई आई की समस्या कम होती है'],
        recommendedFrequency: 'काम के दौरान हर 20 मिनट में',
        source: 'अमेरिकन एकेडमी ऑफ ऑप्थैल्मोलॉजी'
      },
      Marathi: {
        title: 'डोळ्यांच्या आरोग्यासाठी २०-२०-२० नियम',
        tip: 'स्क्रीन वापरताना दर २० मिनिटांनी, २० फूट दूर असलेल्या वस्तूवर २० सेकंद पाहा.',
        explanation: 'लगातार स्क्रीन पाहिल्यामुळे डोळ्यांच्या स्नायूंवर ताण येतो. लांब पाहिल्यामुळे डोळ्यांना विश्रांती मिळते आणि डोळे कोरडे पडत नाहीत.',
        benefits: ['डोळ्यांचा थकवा कमी होतो', 'डोकेदुखीपासून आराम', 'दृष्टी तीक्ष्ण राहण्यास मदत'],
        recommendedFrequency: 'कामाच्या वेळी दर २० मिनिटांनी',
        source: 'अमेरिकन अकॅडमी ऑफ ऑप्थॅल्मोलॉजी'
      }
    }
  },

  // 2. NUTRITION TIPS
  {
    id: 'tip-nu-01',
    categoryId: 'nutrition-tips',
    tags: ['diet', 'fiber', 'gut health', 'vegetables'],
    content: {
      English: {
        title: 'Eat a Rainbow of Whole Plant Foods',
        tip: 'Incorporate 5 distinct colored fruits and vegetables daily to max out phytonutrients.',
        explanation: 'Different natural plant pigments (carotenoids, anthocyanins, flavonoids) indicate unique antioxidant profiles. Eating colorful plant foods supports diverse gut microbiota and reduces chronic inflammatory markers.',
        benefits: ['Diversifies microbiome', 'Reduces cellular oxidative stress', 'Supports vascular flexibility', 'Provides essential vitamins'],
        recommendedFrequency: 'With every main meal',
        source: 'National Health Service (NHS UK)'
      },
      Hindi: {
        title: 'रंगीन फलों और सब्जियों का सेवन करें',
        tip: 'विटामिन और एंटी-ऑक्सीडेंट के लिए रोज 5 अलग-अलग रंगों के फल और सब्जियां खाएं।',
        explanation: 'पौधों के प्राकृतिक रंग (जैसे लाल, हरा, बैंगनी) विभिन्न फाइटोन्यूट्रिएंट्स के प्रतीक हैं। ये शरीर की सूजन कम करते हैं और आंतों के बैक्टीरिया को स्वस्थ रखते हैं।',
        benefits: ['पाचन शक्ति मजबूत होना', 'एंटी-ऑक्सीडेंट सुरक्षा', 'प्रतिरोधक क्षमता बढ़ना'],
        recommendedFrequency: 'मुख्य भोजन में रोज शामिल करें',
        source: 'राष्ट्रीय स्वास्थ्य सेवा (NHS UK)'
      },
      Marathi: {
        title: 'रंगीबेरंगी फळे व भाज्यांचा आहारात समावेश करा',
        tip: 'दैनंदिन आहारात ५ वेगवेगळ्या रंगांची फळे आणि भाज्यांचा समावेश करा.',
        explanation: 'नैसर्गिक रंगांमध्ये विविध अँटी-ऑक्सिडंट्स असतात जे शरीरातील दाह कमी करतात आणि पचनसंस्था निरोगी ठेवतात.',
        benefits: ['पचनक्रिया सुधारते', 'रोगप्रतिकारक शक्ती वाढते', 'शरीराला आवश्यक जीवनसत्त्वे मिळतात'],
        recommendedFrequency: 'दररोजच्या जेवणात',
        source: 'नॅशनल हेल्थ सर्व्हिस (NHS UK)'
      }
    }
  },

  // 3. HYDRATION TIPS
  {
    id: 'tip-hy-01',
    categoryId: 'hydration-tips',
    tags: ['water', 'hydration', 'kidneys', 'detox'],
    content: {
      English: {
        title: 'Morning Warm Water Protocol',
        tip: 'Drink 1-2 glasses of warm water immediately upon waking to stimulate GI peristalsis.',
        explanation: 'Hydration right after sleep counteracts mild nocturnal dehydration, stimulates gastrointestinal motility, aids renal filtration of nitrogenous waste, and readies digestive enzymes for breakfast.',
        benefits: ['Activates bowel movement', 'Clears metabolic waste via kidneys', 'Rehydrates tissues quickly', 'Enhances alertness'],
        recommendedFrequency: 'Every morning on an empty stomach',
        source: 'Indian Council of Medical Research (ICMR)'
      },
      Hindi: {
        title: 'सुबह खाली पेट गुनगुना पानी पीएं',
        tip: 'सुबह उठते ही 1-2 गिलास गुनगुना पानी पीकर अपनी पाचन प्रक्रिया को सक्रिय करें।',
        explanation: 'रात भर की निर्जलीकरण को दूर करने और आंतों की सफाई के लिए सुबह गुनगुना पानी बहुत फायदेमंद है। यह गुर्दों को अपशिष्ट पदार्थों को छानने में मदद करता है।',
        benefits: ['पाचन तंत्र सक्रिय होता है', 'कब्ज से राहत', 'त्वचा में चमक आती है'],
        recommendedFrequency: 'रोज सुबह खाली पेट',
        source: 'भारतीय चिकित्सा अनुसंधान परिषद (ICMR)'
      },
      Marathi: {
        title: 'सकाळी उठल्यावर कोमट पाणी पिणे',
        tip: 'सकाळी उठल्यावर १-२ ग्लास कोमट पाणी प्यायल्याने पचनक्रिया गतिमान होते.',
        explanation: 'रात्रभरात शरीरात झालेली पाण्याची कमतरता भरून निघते आणि आतील अवयव कार्यक्षम होतात.',
        benefits: ['पचनक्रिया सुधारते', 'बद्धकोष्ठता दूर होते', 'शरीरातील विषारी द्रव्ये बाहेर पडतात'],
        recommendedFrequency: 'दररोज सकाळी उपाशीपोटी',
        source: 'भारतीय वैद्यकीय संशोधन परिषद (ICMR)'
      }
    }
  },

  // 4. FITNESS TIPS
  {
    id: 'tip-fi-01',
    categoryId: 'fitness-tips',
    tags: ['stretching', 'joints', 'flexibility', 'morning'],
    content: {
      English: {
        title: 'Dynamic Joint Mobility Stretch Routine',
        tip: 'Perform 5-10 minutes of gentle dynamic joint mobility stretches every morning.',
        explanation: 'Dynamic stretching circulates synovial fluid within shoulder, hip, and knee capsule joints, reducing morning joint stiffness and preparing skeletal muscle fibers for physical exertion without overstraining tendons.',
        benefits: ['Increases synovial fluid flow', 'Reduces muscle stiffness', 'Improves posture and spinal alignment', 'Prevents ligament sprains'],
        recommendedFrequency: 'Daily after waking up',
        source: 'American College of Sports Medicine (ACSM)'
      },
      Hindi: {
        title: 'सुबह 5-10 मिनट जोड़ों का व्यायाम',
        tip: 'सुबह उठने के बाद जोड़ों के लचीलेपन के लिए 5-10 मिनट हल्का व्यायाम करें।',
        explanation: 'हल्का खिंचाव जोड़ों में सिनोवियल द्रव के बहाव को बढ़ाता है, जिससे सुबह की अकड़न दूर होती है और जोड़ों का स्वास्थ्य बना रहता है।',
        benefits: ['जोड़ों का लचीलापन बढ़ना', 'चोट लगने की संभावना कम', 'शरीर में फुर्ती आना'],
        recommendedFrequency: 'रोजाना सुबह',
        source: 'अमेरिकन कॉलेज ऑफ स्पोर्ट्स मेडिसिन'
      },
      Marathi: {
        title: 'सकाळी सांध्यांचे सोपे व्यायाम',
        tip: 'रोज सकाळी ५-१० मिनिटे सांधे व स्नायूंचा हलका व्यायाम करा.',
        explanation: 'यामुळे सांध्यांमधील द्रवाची हालचाल वाढते, सकाळी जाणवणारी कडकपणा कमी होते आणि दुखापतींचा धोका टळतो.',
        benefits: ['सांधेदुखी कमी होते', 'शरीराचा लवचीकपणा वाढतो', 'उत्साह टिकून राहतो'],
        recommendedFrequency: 'दररोज सकाळी',
        source: 'अमेरिकन कॉलेज ऑफ स्पोर्ट्स मेडिसिन'
      }
    }
  },

  // 5. SLEEP TIPS
  {
    id: 'tip-sl-01',
    categoryId: 'sleep-tips',
    tags: ['sleep', 'melatonin', 'circadian rhythm', 'blue light'],
    content: {
      English: {
        title: 'Digital Screen Detox 60 Mins Before Bed',
        tip: 'Power off phones, tablets, and TV screens 60 minutes before sleeping to protect melatonin release.',
        explanation: 'Blue light wavelength (450–480nm) emitted by screens suppresses pineal gland production of melatonin, delaying sleep onset latency and diminishing deep non-REM restorative sleep phases.',
        benefits: ['Promotes rapid natural sleep onset', 'Increases deep restorative slow-wave sleep', 'Stabilizes circadian body clock', 'Improves morning mental alertness'],
        recommendedFrequency: 'Nightly before sleeping',
        source: 'CDC - Centers for Disease Control and Prevention'
      },
      Hindi: {
        title: 'सोने से 1 घंटे पहले मोबाइल-स्क्रीन बंद करें',
        tip: 'सोने से 60 मिनट पहले फोन और टीवी बंद कर दें ताकि मेलाटोनिन हार्मोन सही मात्रा में बने।',
        explanation: 'स्क्रीन से निकलने वाली नीली रोशनी (Blue Light) मस्तिष्क को दिन होने का भ्रम देती है और नींद लाने वाले हार्मोन (मेलाटोनिन) को रोकती है।',
        benefits: ['जल्दी और गहरी नींद आना', 'सुबह ताजगी महसूस होना', 'मानसिक शांति'],
        recommendedFrequency: 'हर रात सोने से पहले',
        source: 'सीडीसी (CDC - USA)'
      },
      Marathi: {
        title: 'झोपण्यापूर्वी १ तास स्क्रीन बंद ठेवा',
        tip: 'गाढ झोपेसाठी झोपण्याच्या ६० मिनिटे आधी फोन व टीव्हीचा वापर बंद करा.',
        explanation: 'स्क्रीनच्या निळ्या प्रकाशामुळे मेंदूतील मेलाटोनिन या झोपेच्या संप्रेरकाचे प्रमाण घटते, ज्यामुळे निद्रानाशाचा त्रास होतो.',
        benefits: ['शांत व गाढ झोप येते', 'सकाळी ताजेतवाने वाटते', 'डोळ्यांवरील ताण कमी होतो'],
        recommendedFrequency: 'दररोज रात्री',
        source: 'सेंटर्स फॉर डिसीज कंट्रोल (CDC)'
      }
    }
  },

  // 6. MENTAL WELLNESS
  {
    id: 'tip-mw-01',
    categoryId: 'mental-wellness',
    tags: ['stress', 'breathing', 'anxiety', 'mindfulness'],
    content: {
      English: {
        title: 'Box Breathing Protocol (4-4-4-4) for Acute Stress',
        tip: 'Inhale for 4 seconds, hold for 4, exhale for 4, and hold empty for 4 seconds during high stress.',
        explanation: 'Controlled rhythmic box breathing stimulates the vagus nerve, initiating parasympathetic nervous system dominant outflow. This lowers serum cortisol, slows down tachycardia, and reduces acute cognitive distress.',
        benefits: ['Rapid autonomic nervous system calming', 'Lowers elevated heart rate', 'Decreases blood cortisol spikes', 'Restores executive focus'],
        recommendedFrequency: 'Whenever feeling anxious or stressed',
        source: 'National Institutes of Health (NIH)'
      },
      Hindi: {
        title: 'तनाव कम करने के लिए बॉक्स ब्रीदिंग (Box Breathing)',
        tip: '4 सेकंड सांस लें, 4 सेकंड रोकें, 4 सेकंड छोड़ें और 4 सेकंड रुकें।',
        explanation: 'यह गहरी सांस लेने की तकनीक वेगस तंत्रिका को उत्तेजित करती है, जिससे पैरासिम्पेथेटिक तंत्रिका तंत्र सक्रिय होता है और तनाव हार्मोन कार्टिसोल कम होता है।',
        benefits: ['तुरंत मानसिक शांति', 'हृदय गति सामान्य होना', 'चिंता और घबराहट में राहत'],
        recommendedFrequency: 'तनाव महसूस होने पर तुरंत',
        source: 'नेशनल इंस्टीट्यूट ऑफ हेल्थ (NIH)'
      },
      Marathi: {
        title: 'तणावमुक्तीसाठी बॉक्स ब्रीदिंग तंत्र',
        tip: '४ सेकंद श्वास घ्या, ४ सेकंद रोखा, ४ सेकंद सोडा आणि ४ सेकंद थांबा.',
        explanation: 'या प्राणायाम पद्धतीमुळे मज्जासंस्था शांत होते आणि रक्तातील ताण निर्माण करणारे कॉर्टिसॉल संप्रेरक कमी होते.',
        benefits: ['मानसिक ताण त्वरित कमी होतो', 'हृदयाचे ठोके नियंत्रित होतात', 'एकाग्रता वाढते'],
        recommendedFrequency: 'तणावाच्या वेळी',
        source: 'नॅशनल इन्स्टिट्यूट ऑफ हेल्थ (NIH)'
      }
    }
  },

  // 7. MEDICINE SAFETY
  {
    id: 'tip-ms-01',
    categoryId: 'medicine-safety',
    tags: ['medicines', 'antibiotics', 'prescriptions', 'safety'],
    content: {
      English: {
        title: 'Never Discontinue Antibiotics Prematurely',
        tip: 'Always complete the full prescribed duration of antibiotics even if your symptoms disappear early.',
        explanation: 'Stopping antibiotic treatment prematurely leaves surviving bacterial strains with elevated resistance. These persistent microorganisms proliferate and spread antimicrobial resistance (AMR), making future infections harder to treat.',
        benefits: ['Prevents antibiotic resistance', 'Ensures complete pathogen eradication', 'Prevents disease relapse', 'Protects community health'],
        recommendedFrequency: 'Whenever taking antibiotic courses',
        source: 'World Health Organization (WHO)'
      },
      Hindi: {
        title: 'एंटीबायोटिक का कोर्स कभी अधूरा न छोड़ें',
        tip: 'लक्षण ठीक होने पर भी डॉक्टर द्वारा बताई गई एंटीबायोटिक की पूरी खुराक लें।',
        explanation: 'बीच में दवा बंद करने से बचे हुए जीवाणु (Bacteria) दवा के प्रति प्रतिरोधी हो जाते हैं। इससे भविष्य में संक्रमण का इलाज बहुत कठिन हो जाता है।',
        benefits: ['एंटीबायोटिक रेजिस्टेंस से बचाव', 'संक्रमण का जड़ से इलाज', 'पुनः बीमारी होने से सुरक्षा'],
        recommendedFrequency: 'एंटीबायोटिक सेवन के दौरान',
        source: 'विश्व स्वास्थ्य संगठन (WHO)'
      },
      Marathi: {
        title: 'अँटीबायोटिक्सचा डोस कधीही अर्धवट सोडू नका',
        tip: 'लक्षणे कमी झाली तरी डॉक्टरांनी दिलेला अँटीबायोटिक्सचा डोस पूर्ण करा.',
        explanation: 'औषध मधेच थांबवल्यास जीवाणू औषधांना दाद न देणारे (Resistant) बनतात, ज्यामुळे भविष्यात संसर्ग बरा करणे कठीण होते.',
        benefits: ['जीवाणू औषध-प्रतिबंधक होत नाहीत', 'संसर्ग पूर्ण बरा होतो', 'पुनरुद्भव टळतो'],
        recommendedFrequency: 'अँटीबायोटिक्स घेताना',
        source: 'जागतिक आरोग्य संघटना (WHO)'
      }
    }
  },

  // 8. DISEASE PREVENTION
  {
    id: 'tip-dp-01',
    categoryId: 'disease-prevention',
    tags: ['hygiene', 'handwashing', 'infection control', 'flu'],
    content: {
      English: {
        title: '20-Second Proper Handwashing Technique',
        tip: 'Wash hands thoroughly with soap and water for 20 seconds, especially before eating and after public contact.',
        explanation: 'Surfactants in soap break down the lipid membrane surrounding respiratory viruses (like Influenza & Coronaviruses) and wash bacteria away from skin folds, dramatically breaking disease transmission chains.',
        benefits: ['Reduces gastrointestinal infections by 30%', 'Reduces respiratory infections by 20%', 'Eliminates virulent skin pathogens', 'Protects vulnerable family members'],
        recommendedFrequency: 'Multiple times daily before meals and post-exposure',
        source: 'CDC - Centers for Disease Control and Prevention'
      },
      Hindi: {
        title: '20 सेकंड तक साबुन से हाथ धोएं',
        tip: 'खाना खाने से पहले और बाहर से आने के बाद 20 सेकंड तक साबुन और पानी से हाथ धोएं।',
        explanation: 'साबुन विषाणुओं (Viruses) के बाहरी वसा आवरण को नष्ट कर देता है, जिससे वे त्वचा से छूटकर बह जाते हैं और संक्रमण का खतरा टल जाता है।',
        benefits: ['पेट के संक्रमण से बचाव', 'सर्दी-जुकाम से सुरक्षा', 'संक्रमण फैलने से रोकना'],
        recommendedFrequency: 'दिन में कई बार आवश्यकतानुसार',
        source: 'सीडीसी (CDC)'
      },
      Marathi: {
        title: '२० सेकंद स्वच्छ साबणाने हात धुणे',
        tip: 'जेवणापूर्वी आणि बाहेरून आल्यावर साबणाने २० सेकंद हात स्वच्छ धुवा.',
        explanation: 'साबणामुळे विषाणूंचे बाहेरील आवरण नष्ट होते आणि हातावरील जंतू पूर्णपणे निघून जातात.',
        benefits: ['पोटाचे आजार टळतात', 'सर्दी-खोकला संसर्गापासून बचाव', 'कुटुंबाचे रक्षण'],
        recommendedFrequency: 'दररोज वारंवार',
        source: 'सेंटर्स फॉर डिसीज कंट्रोल (CDC)'
      }
    }
  },

  // 9. CHILD HEALTH
  {
    id: 'tip-ch-01',
    categoryId: 'child-health',
    tags: ['pediatrics', 'vaccination', 'child immunity'],
    content: {
      English: {
        title: 'Strict Adherence to Pediatric Immunization Schedule',
        tip: 'Follow your pediatrician recommended vaccination chart on time without skipping booster doses.',
        explanation: 'Vaccines train the developing pediatric immune system by creating memory B-lymphocytes against dangerous infectious agents (Measles, Polio, Rotavirus, DPT) before encountering natural exposure.',
        benefits: ['Provides life-saving immunity', 'Prevents childhood disease complications', 'Contributes to community herd protection', 'Safe and evidence-based'],
        recommendedFrequency: 'As scheduled by national health authorities',
        source: 'Indian Academy of Pediatrics (IAP)'
      },
      Hindi: {
        title: 'बच्चों का समय पर टीकाकरण कराएं',
        tip: 'बाल रोग विशेषज्ञ द्वारा दिए गए टीकाकरण चार्ट के अनुसार बच्चों को सभी टीके समय पर लगवाएं।',
        explanation: 'टीके बच्चों के प्रतिरक्षा तंत्र को खसरा, पोलियों और काली खांसी जैसी गंभीर बीमारियों से लड़ने के लिए तैयार करते हैं।',
        benefits: ['जानलेवा बीमारियों से सुरक्षा', 'मजबूत रोग प्रतिरोधक क्षमता', 'स्वस्थ शारीरिक विकास'],
        recommendedFrequency: 'टीकाकरण सारणी के अनुसार',
        source: 'इंडियन एकेडमी ऑफ पीडियाट्रिक्स (IAP)'
      },
      Marathi: {
        title: 'बालकांचे वेळेवर लसीकरण करणे',
        tip: 'डॉक्टरांच्या सल्ल्यानुसार बालकांचे सर्व लसीकरण वेळेत पूर्ण करा.',
        explanation: 'लसींमुळे बालकांची प्रतिकारशक्ती वाढते आणि पोलिओ, गोवर यांसारख्या गंभीर आजारांपासून कायमचे संरक्षण मिळते.',
        benefits: ['गंभीर आजारांपासून रक्षण', 'सुदृढ शारीरिक वाढ', 'आयुष्यभरासाठी सुरक्षितता'],
        recommendedFrequency: 'लसीकरण पत्रकानुसार',
        source: 'इंडियन अकॅडमी ऑफ पेडियाट्रिक्स (IAP)'
      }
    }
  },

  // 10. WOMEN'S HEALTH
  {
    id: 'tip-wh-01',
    categoryId: 'womens-health',
    tags: ['iron', 'anemia', 'calcium', 'women'],
    content: {
      English: {
        title: 'Iron & Vitamin C Synergy for Anemia Prevention',
        tip: 'Combine iron-rich foods (spinach, lentils) with Vitamin C (lemon, amla) to boost iron absorption.',
        explanation: 'Non-heme iron present in plant sources requires an acidic environment to convert ferric (Fe3+) into the absorbable ferrous (Fe2+) state. Vitamin C significantly increases intestinal iron uptake.',
        benefits: ['Prevents iron-deficiency anemia', 'Reduces chronic exhaustion', 'Supports healthy hemoglobin levels', 'Boosts natural energy'],
        recommendedFrequency: 'Daily meal design',
        source: 'Ministry of Health and Family Welfare (MoHFW India)'
      },
      Hindi: {
        title: 'एनीमिया से बचाव के लिए आयरन और विटामिन सी',
        tip: 'पालक और दालों जैसे आयरन युक्त भोजन के साथ नींबू या आंवला (विटामिन सी) जरूर लें।',
        explanation: 'विटामिन सी पौधों से मिलने वाले आयरन के अवशोषण को कई गुना बढ़ा देता है, जिससे हीमोग्लोबिन तेजी से बढ़ता है और कमजोरी दूर होती है।',
        benefits: ['हीमोग्लोबिन स्तर में सुधार', 'थकान और कमजोरी से राहत', 'एनीमिया का रोकथाम'],
        recommendedFrequency: 'रोजाना भोजन में',
        source: 'स्वास्थ्य एवं परिवार कल्याण मंत्रालय'
      },
      Marathi: {
        title: 'ॲनिमिया टाळण्यासाठी आयर्न आणि व्हिटॅमिन सी',
        tip: 'पालक, कडधान्ये यांसारख्या लोहयुक्त आहारासोबत लिंबू किंवा आवळा (व्हिटॅमिन सी) घ्या.',
        explanation: 'व्हिटॅमिन सी मुळे शरीरात लोह शोषून घेण्याची क्षमता वाढते, ज्यामुळे रक्तातील हिमोग्लोबिनचे प्रमाण वेगाने वाढते.',
        benefits: ['ॲनिमियापासून बचाव', 'थकवा कमी होतो', 'हिमोग्लोबिन वाढते'],
        recommendedFrequency: 'दररोजच्या आहारात',
        source: 'आरोग्य व कुटुंब कल्याण मंत्रालय'
      }
    }
  },

  // 11. SENIOR HEALTH
  {
    id: 'tip-sh-01',
    categoryId: 'senior-health',
    tags: ['seniors', 'falls', 'balance', 'joint mobility'],
    content: {
      English: {
        title: 'Fall Prevention & Home Hazard Check for Seniors',
        tip: 'Ensure bright home lighting, non-slip bathroom mats, and clear loose carpets to prevent falls.',
        explanation: 'Falls are the leading cause of osteoporotic hip fractures and head injury among older adults. Environmental safety adjustments combined with light balance training maintain independence.',
        benefits: ['Drastically reduces hip fracture risk', 'Preserves physical mobility', 'Reduces hospitalization emergency risk', 'Enhances daily confidence'],
        recommendedFrequency: 'Ongoing home environmental audit',
        source: 'National Institute on Aging (NIA USA)'
      },
      Hindi: {
        title: 'वरिष्ठ नागरिकों के लिए फिसलने और गिरने से बचाव',
        tip: 'बाथरूम में फिसलन विरोधी मैट लगाएं और घर में पर्याप्त रोशनी की व्यवस्था रखें।',
        explanation: 'उम्र बढ़ने के साथ हड्डियां कमजोर हो जाती हैं। गिरने से कूल्हे की हड्डी टूटने का खतरा रहता है, इसलिए घर में फिसलन वाली जगहें ठीक रखें।',
        benefits: ['हड्डी टूटने से बचाव', 'सुरक्षित चहलकदमी', 'आत्मविश्वास बना रहना'],
        recommendedFrequency: 'हमेशा ध्यान रखें',
        source: 'नेशनल इंस्टीट्यूट ऑन एजिंग'
      },
      Marathi: {
        title: 'ज्येष्ठ नागरिकांसाठी घरातील सुरक्षितता',
        tip: 'बाथरूममध्ये घसरगुंडीविरोधी मॅट वापरा आणि घरात पुरेसा प्रकाश ठेवा.',
        explanation: 'वयोवृद्धांमध्ये हाडे ठिसूळ असल्यामुळे घसरून पडल्यास फ्रॅक्चरचा धोका जास्त असतो.',
        benefits: ['हाडे मोडण्याचा धोका टळतो', 'घरात सुरक्षित हालचाल', 'स्वातंत्र्य टिकून राहते'],
        recommendedFrequency: 'कायमस्वरूपी काळजी घ्या',
        source: 'नॅशनल इन्स्टिट्यूट ऑन एजिंग'
      }
    }
  },

  // 12. HEART HEALTH
  {
    id: 'tip-hh-01',
    categoryId: 'heart-health',
    tags: ['heart', 'salt', 'blood pressure', 'sodium'],
    content: {
      English: {
        title: 'Cap Daily Salt Intake to Less Than 5 Grams (1 Teaspoon)',
        tip: 'Limit total daily sodium consumption to under 2,000 mg (approx 5g table salt) for vascular health.',
        explanation: 'Excessive sodium causes intravascular water retention, elevating arterial blood pressure (hypertension) and straining arterial walls, accelerating coronary risk.',
        benefits: ['Lowers blood pressure', 'Reduces cardiac strain', 'Protects kidney blood vessels', 'Lowers stroke risk'],
        recommendedFrequency: 'Daily diet tracking',
        source: 'World Health Organization (WHO)'
      },
      Hindi: {
        title: 'नमक का सेवन प्रतिदिन 5 ग्राम (1 छोटा चम्मच) से कम रखें',
        tip: 'हाई ब्लड प्रेशर से बचने के लिए दिन भर में 1 चम्मच से अधिक नमक का सेवन न करें।',
        explanation: 'अधिक नमक खाने से रक्त वाहिकाओं में पानी की मात्रा बढ़ती है, जिससे ब्लड प्रेशर बढ़ता है और दिल पर अतिरिक्त दबाव पड़ता है।',
        benefits: ['ब्लड प्रेशर नियंत्रित रहता है', 'हार्ट अटैक का खतरा कम होना', 'गुर्दों की सुरक्षा'],
        recommendedFrequency: 'रोजाना भोजन में',
        source: 'विश्व स्वास्थ्य संगठन (WHO)'
      },
      Marathi: {
        title: 'मीठाचे प्रमाण दररोज ५ ग्रॅमपेक्षा कमी ठेवा',
        tip: 'रक्तदाब नियंत्रणात ठेवण्यासाठी दिवसाला १ चमच्यापेक्षा जास्त मीठ खाऊ नका.',
        explanation: 'जास्त मीठ खाल्ल्यामुळे रक्तातील पाण्याचे प्रमाण वाढते आणि रक्तवाहिन्यांवर ताण येऊन बीपी वाढतो.',
        benefits: ['रक्तदाब नियंत्रणात राहतो', 'हृदयविकाराचा धोका टळतो', 'मूत्रपिंड निरोगी राहतात'],
        recommendedFrequency: 'दररोजच्या आहारात',
        source: 'जागतिक आरोग्य संघटना (WHO)'
      }
    }
  },

  // 13. DIABETES CARE
  {
    id: 'tip-dc-01',
    categoryId: 'diabetes-care',
    tags: ['diabetes', 'sugar', 'glycemic index', 'walk'],
    content: {
      English: {
        title: '15-Minute Post-Meal Walk for Glycemic Control',
        tip: 'Walk gently for 10-15 minutes within 30 minutes after major meals to blunt blood sugar spikes.',
        explanation: 'Skeletal muscle contraction during light walking stimulates GLUT4 glucose transporters via insulin-independent pathways, pulling circulating glucose directly into muscle cells.',
        benefits: ['Prevents postprandial blood sugar spikes', 'Improves muscle insulin sensitivity', 'Aids digestion', 'Helps lower long-term HbA1c'],
        recommendedFrequency: 'After lunch and dinner',
        source: 'American Diabetes Association (ADA)'
      },
      Hindi: {
        title: 'खाना खाने के बाद 15 मिनट टहलें',
        tip: 'भोजन के 30 मिनट के भीतर 10-15 मिनट हल्का टहलने से शुगर लेवल अचानक नहीं बढ़ता।',
        explanation: 'चलने से मांसपेशियां खून से ग्लूकोज को बिना इंसुलिन के अवशोषित करती हैं, जिससे खाने के बाद शुगर की स्पाइक रुकती है।',
        benefits: ['शुगर स्पाइक से बचाव', 'पाचन बेहतर होना', 'HbA1c नियंत्रित रहना'],
        recommendedFrequency: 'दोपहर और रात के खाने के बाद',
        source: 'अमेरिकन डायबिटीज एसोसिएशन (ADA)'
      },
      Marathi: {
        title: 'जेवणानंतर १५ मिनिटे शतपावली करा',
        tip: 'जेवण झाल्यानंतर ३० मिनिटांच्या आत १०-१५ मिनिटे हळूहळू चाला.',
        explanation: 'चालल्यामुळे स्नायू रक्तातील साखर थेट वापरतात, ज्यामुळे जेवणानंतर साखरेचे प्रमाण अचानक वाढत नाही.',
        benefits: ['साखर नियंत्रित राहते', 'पचन सुलभ होते', 'HbA1c कमी होण्यास मदत'],
        recommendedFrequency: 'दुपारच्या व रात्रीच्या जेवणानंतर',
        source: 'अमेरिकन डायबिटीस असोसिएशन (ADA)'
      }
    }
  },

  // 14. BONE & JOINT HEALTH
  {
    id: 'tip-bj-01',
    categoryId: 'bone-joint',
    tags: ['calcium', 'sunlight', 'vitamin d', 'bones'],
    content: {
      English: {
        title: '15 Minutes Morning Sun Exposure for Vitamin D',
        tip: 'Expose arms and face to early morning sunlight for 15-20 minutes to synthesize natural Vitamin D3.',
        explanation: 'Ultraviolet-B (UVB) photons convert 7-dehydrocholesterol in skin to pre-vitamin D3. Active Vitamin D is mandatory for intestinal calcium absorption and bone mineral density maintenance.',
        benefits: ['Maximizes calcium uptake', 'Strengthens bone density', 'Prevents osteopenia and osteoporosis', 'Supports muscular balance'],
        recommendedFrequency: '3-5 times a week before 9:00 AM',
        source: 'National Osteoporosis Foundation'
      },
      Hindi: {
        title: 'विटामिन डी के लिए सुबह 15 मिनट धूप लें',
        tip: 'प्राकृतिक विटामिन डी3 के लिए सुबह की हल्की धूप में 15-20 मिनट बैठें।',
        explanation: 'धूप से मिलने वाली यूवी-बी किरणें त्वचा में विटामिन डी बनाती हैं, जो हड्डियों द्वारा कैल्शियम को सोखने के लिए अत्यंत आवश्यक है।',
        benefits: ['हड्डियां मजबूत होना', 'कैल्शियम का सही अवशोषण', 'जोड़ों के दर्द में राहत'],
        recommendedFrequency: 'सप्ताह में 3-5 बार सुबह 9 बजे से पहले',
        source: 'नेशनल ऑस्टियोपोरोसिस फाउंडेशन'
      },
      Marathi: {
        title: 'व्हिटॅमिन डी साठी सकाळी १५ मिनिटे उन्हात बसा',
        tip: 'सकाळच्या कोवळ्या उन्हात १५-२० मिनिटे बसल्याने शरीरात व्हिटॅमिन डी३ तयार होते.',
        explanation: 'उन्हातील किरणांमुळे त्वचेमध्ये व्हिटॅमिन डी तयार होते, जे हाडांना कॅल्शियम शोषून घेण्यासाठी आवश्यक असते.',
        benefits: ['हाडे मजबूत होतात', 'कॅल्शियम व्यवस्थित शोषले जाते', 'सांधेदुखीपासून आराम'],
        recommendedFrequency: 'आठवड्यातून ३-५ वेळा सकाळी ९ पूर्वी',
        source: 'नॅशनल ऑस्टियोपोरोसिस फाउंडेशन'
      }
    }
  },

  // 15. IMMUNITY TIPS
  {
    id: 'tip-im-01',
    categoryId: 'immunity-tips',
    tags: ['immunity', 'amla', 'vitamin c', 'antioxidants'],
    content: {
      English: {
        title: 'Fresh Amla (Indian Gooseberry) for High Vitamin C Immunity',
        tip: 'Consume one fresh Amla or its juice daily to provide over 600mg of natural Vitamin C.',
        explanation: 'Amla is one of the richest botanical sources of Vitamin C and polyphenols. It enhances leukocyte function, stimulates interferon production, and protects immune cells from oxidative degradation.',
        benefits: ['Enhances white blood cell count', 'Potent systemic antioxidant protection', 'Supports respiratory mucosa integrity', 'Protects against seasonal colds'],
        recommendedFrequency: 'Daily in morning',
        source: 'AYUSH Ministry & ICMR'
      },
      Hindi: {
        title: 'इम्युनिटी बढ़ाने के लिए रोज एक ताजा आंवला लें',
        tip: 'प्रतिरोधक क्षमता बढ़ाने के लिए रोजाना एक ताजा आंवला या उसका जूस सेवन करें।',
        explanation: 'आंवला प्राकृतिक विटामिन सी का सर्वोत्तम स्रोत है। यह श्वेत रक्त कोशिकाओं (WBC) की कार्यक्षमता बढ़ाता है और मौसमी बीमारियों से बचाता है।',
        benefits: ['सफेद रक्त कोशिकाओं में वृद्धि', 'एंटी-ऑक्सीडेंट सुरक्षा', 'सर्दी-खांसी से बचाव'],
        recommendedFrequency: 'रोज सुबह',
        source: 'आयुष मंत्रालय और ICMR'
      },
      Marathi: {
        title: 'रोगप्रतिकारशक्तीसाठी दररोज एका आवळ्याचे सेवन',
        tip: 'प्रतिकारशक्ती वाढवण्यासाठी रोज एक ताजा आवळा किंवा त्याचा रस प्या.',
        explanation: 'आवळा हा व्हिटॅमिन सी चा उत्तम स्रोत आहे. यामुळे शरीरातील पांढऱ्या पेशींची ताकद वाढते आणि संसर्गापासून बचाव होतो.',
        benefits: ['रोगप्रतिकारक शक्ती दुप्पट होते', 'त्वचा व केसांसाठी उत्तम', 'सर्दी-पडशापासून संरक्षण'],
        recommendedFrequency: 'दररोज सकाळी',
        source: 'आयुष मंत्रालय व ICMR'
      }
    }
  }
];

export function getTipsByCategory(categoryId: string): HealthTipItem[] {
  return ALL_HEALTH_TIPS.filter((t) => t.categoryId === categoryId);
}

export function searchHealthTips(query: string, lang: TipLanguage = 'English'): HealthTipItem[] {
  const q = query.trim().toLowerCase();
  if (!q) return ALL_HEALTH_TIPS;

  return ALL_HEALTH_TIPS.filter((item) => {
    const c = item.content[lang] || item.content.English;
    const searchableText = `${c.title} ${c.tip} ${c.explanation} ${c.benefits.join(' ')} ${c.source} ${item.tags.join(' ')}`.toLowerCase();
    return searchableText.includes(q);
  });
}

// Helper to reliably return today's tip based on calendar date
export function getTipOfTheDay(): HealthTipItem {
  const today = new Date();
  const dayOfYear = Math.floor(
    (today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)
  );
  const index = dayOfYear % ALL_HEALTH_TIPS.length;
  return ALL_HEALTH_TIPS[index];
}
