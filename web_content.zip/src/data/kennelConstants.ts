import {
  BoxId,
  CoatColor,
  BodyType,
  FurPattern,
  HabitatLocationId,
  PenObject,
  PlayerAction,
  UniqueTrait,
} from '../types/kennel';

export const PUP_ADULT_AGE_SEC = 3600;     // 1 real hour to adulthood
export const AVG_LIFESPAN_SEC = 21600;     // 6 real hours average lifespan
export const FERTILITY_COOLDOWN_SEC = 1800;// 30 real minutes after mating
export const GESTATION_DURATION_SEC = 360; // 6 real minutes gestation so births are observable
export const MARKET_REFRESH_SEC = 480;     // 8 real minutes per trade batch
export const INTERACTION_MIN_AUTO_END_SEC = 60; // 60 seconds before dog leaves on its own
export const OUTSIDE_PEN_CAPACITY = 6;
export const DAY_SECONDS = 86400;          // 24 real hours

export const BOX_IDS: BoxId[] = Array.from({ length: 21 }, (_, i) => `box_${i + 1}` as BoxId);

export const ALL_HABITAT_IDS: HabitatLocationId[] = [
  ...BOX_IDS,
  'outside_pen',
  'nursery_pen',
];

export const COATS: CoatColor[] = ['fawn', 'black', 'gray', 'white'];
export const BODY_TYPES: BodyType[] = ['slender', 'chubby', 'medium'];
export const PATTERNS: FurPattern[] = ['black spots', 'striped', 'black piebald', 'patternless'];

export const ALL_TRAITS: UniqueTrait[] = [
  'lazy',
  'active',
  'clingy',
  'solitary',
  'likes humans',
  'dislikes humans',
  'dislikes females',
  'dislikes males',
  'possessive of toys',
  'playful',
  'likes petting',
  'dislikes petting',
  'focused',
  'erratic',
  'calm',
  'reactive',
];

export const TRAIT_CONFLICTS: Partial<Record<UniqueTrait, UniqueTrait[]>> = {
  lazy: ['active'],
  active: ['lazy'],
  clingy: ['solitary'],
  solitary: ['clingy'],
  'likes humans': ['dislikes humans'],
  'dislikes humans': ['likes humans'],
  'likes petting': ['dislikes petting'],
  'dislikes petting': ['likes petting'],
  calm: ['reactive', 'erratic'],
  reactive: ['calm'],
  erratic: ['calm', 'focused'],
  focused: ['erratic'],
};

export const TRAIT_NOTES: Record<UniqueTrait, string> = {
  lazy: 'Conserves energy, favors shaded resting spots, and avoids strenuous chases.',
  active: 'Paces runs frequently, burns calories faster, and seeks climbing or digging outlets.',
  clingy: 'Shadows trusted handlers and allies closely; distress rises when isolated.',
  solitary: 'Prefers personal space in corners and withdraws quickly from crowded interactions.',
  'likes humans': 'Approaches handlers readily and gains trust quickly from gentle gestures.',
  'dislikes humans': 'Keeps guarded distance from people; startles or bristles under close contact.',
  'dislikes females': 'Shows persistent territorial tension or avoidance toward female dogs.',
  'dislikes males': 'Bristles easily around male dogs and resists male social advances.',
  'possessive of toys': 'Guards ropes, sticks, and pen objects fiercely against penmates.',
  playful: 'Initiates playful bows, ambushes, and wrestling bouts even under moderate fatigue.',
  'likes petting': 'Relaxes noticeably when stroked along the shoulders and ears.',
  'dislikes petting': 'Pulls back or snaps defensively if touched directly by hand.',
  focused: 'Stays absorbed in scent trails, object investigation, and prolonged interactions.',
  erratic: 'Swings rapidly between curiosity and sudden avoidance or startled bursts.',
  calm: 'Recovers quickly from tension and buffers nearby allies during disputes.',
  reactive: 'Triggers faster into growls or defensive snaps when startled or challenged.',
};

export const PLAYER_ACTION_META: Record<PlayerAction, { label: string; hint: string }> = {
  look_away: { label: 'Look away', hint: 'Soften posture & ease pressure' },
  offer_palm: { label: 'Offer palm', hint: 'Present back of hand to sniff' },
  playful_wrestle: { label: 'Playful wrestle', hint: 'Invite rough-and-tumble play' },
  pet: { label: 'Pet', hint: 'Stroke shoulder or behind ears' },
  offer_kibble: { label: 'Offer kibble', hint: 'Hand-feed dried meat morsel' },
  crouch: { label: 'Crouch', hint: 'Lower height to appear non-threatening' },
  scold: { label: 'Scold', hint: 'Sharp verbal correction' },
  eye_contact: { label: 'Eye contact', hint: 'Hold steady direct gaze' },
  end_interaction: { label: 'End interaction', hint: 'Step back cleanly' },
};

export const INITIAL_PEN_OBJECTS: PenObject[] = [
  {
    id: 'obj_climb_deck',
    name: 'Timber Climbing Deck',
    kind: 'climb',
    condition: 94,
    lastInteractedText: 'Weathered eucalyptus planks dusted with paw prints.',
  },
  {
    id: 'obj_dig_pit',
    name: 'Red-Clay Digging Pit',
    kind: 'dig',
    condition: 88,
    lastInteractedText: 'Loose ochre earth banked beneath the shade tree.',
  },
  {
    id: 'obj_rope_tug',
    name: 'Knotted Hemp Toy',
    kind: 'chew',
    condition: 82,
    lastInteractedText: 'Frayed braided rope scented from previous play.',
  },
  {
    id: 'obj_fence_line',
    name: 'Perimeter Mesh Fence',
    kind: 'fence',
    condition: 96,
    lastInteractedText: 'Heavy-gauge galvanized run along the scrub margin.',
  },
  {
    id: 'obj_scent_bush',
    name: 'Saltbush Scent Post',
    kind: 'scent',
    condition: 91,
    lastInteractedText: 'Dry scrub tuft carrying territory markings.',
  },
  {
    id: 'obj_shade_shelter',
    name: 'Corrugated Shade Lean-to',
    kind: 'shelter',
    condition: 98,
    lastInteractedText: 'Cool sand bed tucked out of midday glare.',
  },
];

export const DINGO_NAME_POOL: string[] = [
  'Kora', 'Bindi', 'Tarka', 'Milo', 'Yara', 'Daku', 'Sable', 'Wren',
  'Ochre', 'Kestrel', 'Brindle', 'Tully', 'Nala', 'Cinder', 'Ringo', 'Sorrel',
  'Birch', 'Vesper', 'Kip', 'Marley', 'Dune', 'Tawny', 'Gale', 'Pippa',
  'Sirocco', 'Arlo', 'Jindi', 'Rowan', 'Bramble', 'Lark', 'Koda', 'Fennel',
  'Bindi-Lou', 'Kangaroo', 'Thistle', 'Shale', 'Rye', 'Sol', 'Flint', 'Kiri',
];

export function formatLocationLabel(loc: string): string {
  if (loc === 'corridor') return 'Outside Corridor';
  if (loc === 'outside_pen') return 'Outside Pen';
  if (loc === 'nursery_pen') return 'Nursery Pen';
  if (loc.startsWith('box_')) {
    const num = loc.replace('box_', '').padStart(2, '0');
    return `Box ${num}`;
  }
  return loc;
}

export function formatSimClock(sec: number): string {
  const s = ((Math.floor(sec) % DAY_SECONDS) + DAY_SECONDS) % DAY_SECONDS;
  const hh = Math.floor(s / 3600).toString().padStart(2, '0');
  const mm = Math.floor((s % 3600) / 60).toString().padStart(2, '0');
  const ss = Math.floor(s % 60).toString().padStart(2, '0');
  return `${hh}:${mm}:${ss}`;
}

export function formatDurationShort(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const remS = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${remS}s`;
  return `${remS}s`;
}
