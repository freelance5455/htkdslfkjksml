export interface CompanionPhrase {
  id: string;
  category: 'greeting' | 'correct' | 'wrong' | 'levelUp' | 'rankUp' | 'streak' | 'advice';
  ar: string;
  fr: string;
  en: string;
  emotion: 'idle' | 'proud' | 'encouraging' | 'thinking' | 'radiant';
}

export const COMPANION_PHRASES: CompanionPhrase[] = [
  // Greetings
  {
    id: 'g-1',
    category: 'greeting',
    ar: 'مرحباً بك في عالم ظلال الأشعة! قوتك كصياد باراميديكال تبدأ بإتقان كل بكسل شعاعي.',
    fr: 'Bienvenue dans le royaume des ombres radiologiques ! Ta maîtrise commence par chaque pixel.',
    en: 'Welcome to the shadow radiology realm! Your hunter mastery starts with every pixel.',
    emotion: 'idle'
  },
  {
    id: 'g-2',
    category: 'greeting',
    ar: 'أهلاً يا بطل! أجهزة الرنين والسكانير تنتظر أوامرك اليوم، هل نبدأ التدريب؟',
    fr: 'Salutations ! Les scanners et les IRM attendent tes ordres pour la session du jour.',
    en: 'Greetings! The CT and MRI systems await your command for today’s session.',
    emotion: 'radiant'
  },
  {
    id: 'g-3',
    category: 'greeting',
    ar: 'المرضى في مستشفيات الجزائر يستحقون أفضل تقني أشعة، استعد لاكتساب المهارات العليا!',
    fr: 'Les patients de nos hôpitaux méritent l’élite des manipulateurs radio. En avant !',
    en: 'Hospital patients deserve elite radiology technologists. Prepare for greatness!',
    emotion: 'idle'
  },

  // Correct
  {
    id: 'c-1',
    category: 'correct',
    ar: 'إجابة خارقة! طاقتك الشعاعية تزداد قوة، هذا هو تركيز صياد النخبة!',
    fr: 'Excellente réponse ! Ton aura d’énergie s’amplifie, digne d’un chasseur d’élite !',
    en: 'Outstanding answer! Your radiant energy surges like an elite hunter!',
    emotion: 'proud'
  },
  {
    id: 'c-2',
    category: 'correct',
    ar: 'تحليل دقيق! معرفتك بالفيزياء الشعاعية والتشريح تتفوق على الصعاب.',
    fr: 'Analyse chirurgicale ! Ta compréhension des rayonnements triomphe avec brio.',
    en: 'Surgical accuracy! Your grasp of radiology physics triumphs effortlessly.',
    emotion: 'proud'
  },
  {
    id: 'c-3',
    category: 'correct',
    ar: 'رائع جداً! بهذا الإتقان ستكون قدوة لزملائك في قاعات التصوير الطبي.',
    fr: 'Magnifique ! Avec une telle précision, tu seras le pilier de ton service d’imagerie.',
    en: 'Brilliant! With this precision, you will be a pillar in the radiology department.',
    emotion: 'proud'
  },
  {
    id: 'c-4',
    category: 'correct',
    ar: 'ضربة قاضية للسؤال! كسبت نقاط خبرة وعززت رصيد معرفتك الطبية.',
    fr: 'Coup critique ! Tu engranges de précieux points d’XP et renforces ton savoir.',
    en: 'Critical hit! You gain valuable XP and reinforce your clinical knowledge.',
    emotion: 'radiant'
  },

  // Wrong / Encouraging
  {
    id: 'w-1',
    category: 'wrong',
    ar: 'لا تحزن أبداً! السقوط هو الخطوة الأولى لتعلّم تفادي الأخطاء في قاعة الفحص الحقيقية.',
    fr: 'Ne sois pas déçu ! L’erreur en entraînement est la garantie de la perfection en clinique.',
    en: 'Never despair! Stumbling during practice guarantees perfection on real patients.',
    emotion: 'encouraging'
  },
  {
    id: 'w-2',
    category: 'wrong',
    ar: 'كل صياد عظيم واجه كبوات في البداية. راجع التفسير العلمي وانهض أقوى مما كنت!',
    fr: 'Chaque grand maître a trébuché à ses débuts. Lis l’explication et relève-toi !',
    en: 'Every great master has stumbled. Read the clinical rationale and rise stronger!',
    emotion: 'encouraging'
  },
  {
    id: 'w-3',
    category: 'wrong',
    ar: 'خذ نفساً عميقاً، الشجاعة ليست في عدم الخطأ، بل في إصرارك على فهم السبب.',
    fr: 'Respire profondément. Le courage réside dans ta volonté de comprendre la cause.',
    en: 'Take a deep breath. True courage is your determination to understand the root cause.',
    emotion: 'thinking'
  },

  // Level Up / Rank Up
  {
    id: 'l-1',
    category: 'levelUp',
    ar: 'ارتقاء في المستوى! طاقتك تتفجر وجسدك يمتص أسرار التصوير الطبي الحديث!',
    fr: 'Montée de niveau ! Ton potentiel se libère au cœur des arcanes de la radiologie !',
    en: 'Level up! Your aura surges as you unlock deeper radiological mastery!',
    emotion: 'radiant'
  },
  {
    id: 'r-1',
    category: 'rankUp',
    ar: 'ترقية رتبة الصياد! العالم يشهد ولادة خبير أشعة لا يُستهان به، مبروك الرتبة الجديدة!',
    fr: 'Élévation de rang ! Le monde accueille un chasseur radiologue redoutable, félicitations !',
    en: 'Rank ascension! The world witnesses a formidable radiology hunter, congratulations!',
    emotion: 'radiant'
  },

  // Streaks
  {
    id: 's-1',
    category: 'streak',
    ar: 'شعلة التزامك تشتعل يوماً بعد يوم! الاستمرار اليومي هو السر الحقيقي للعباقرة.',
    fr: 'Ta flamme de persévérance brûle ardemment ! La régularité forge les génies.',
    en: 'Your dedication flame blazes brighter! Daily consistency shapes true genius.',
    emotion: 'radiant'
  },

  // Practical Clinical Advice
  {
    id: 'a-1',
    category: 'advice',
    ar: 'نصيحة الميدان: في الأشعة المتنقلة بالمستشفى، لا تطلق الشعاع قبل التأكد من ابتعاد الجميع مترين على الأقل.',
    fr: 'Conseil de stage : En radio mobile, assure-toi que chacun soit à 2 mètres au minimum avant le tir.',
    en: 'Clinical tip: In portable radiography, ensure everyone is at least 2 meters away before firing.',
    emotion: 'thinking'
  },
  {
    id: 'a-2',
    category: 'advice',
    ar: 'نصيحة الميدان: ابتسامتك وكلماتك المطمئنة للمريض بالدارجة الجزائرية تزيل نصف خوفه من نفق السكانير.',
    fr: 'Conseil humain : Un mot doux et rassurant désamorce l’angoisse du patient avant le tunnel.',
    en: 'Human tip: A calming smile and reassuring words dispel half the patient’s scan anxiety.',
    emotion: 'idle'
  }
];

export function getRandomPhrase(
  category: 'greeting' | 'correct' | 'wrong' | 'levelUp' | 'rankUp' | 'streak' | 'advice'
): CompanionPhrase {
  const filtered = COMPANION_PHRASES.filter((p) => p.category === category);
  if (filtered.length === 0) return COMPANION_PHRASES[0];
  const randomIndex = Math.floor(Math.random() * filtered.length);
  return filtered[randomIndex];
}
