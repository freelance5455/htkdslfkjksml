import type { Board, ClassLevel, Subject, SyllabusStatus } from "./types";

// ---------------------------------------------------------------------------
// Syllabus Master Library
// ---------------------------------------------------------------------------
// This is a BROWSABLE CHAPTER REFERENCE separate from (but linked to) the
// deep interactive Formula library in class8.ts/class9.ts/class10.ts.
//
// Every entry is honestly labeled:
//   - "Official"    — cross-checked this session against published current
//                      syllabus sources (see `source`). Still verify against
//                      your own school's prescribed textbook/year, since
//                      boards revise syllabi periodically.
//   - "Unverified"   — based on long-standing, well-known textbook chapter
//                      structures, but NOT independently confirmed against
//                      an official document in this session. Treat as a
//                      study-organisation starting point, not an official
//                      citation.
//   - "Additional"   — commonly taught/practiced but not always a distinct
//                      graded chapter in every edition of the syllabus.
//   - "Enrichment"   — background/conceptual material that supports the
//                      syllabus but goes beyond what is typically examined.
//
// CBSE Physics & Chemistry note: CBSE/NCERT teaches Physics, Chemistry and
// Biology together as ONE integrated subject called "Science" for Classes
// 8–10 — they are NOT separate subjects/papers as they are in ICSE. We still
// organise CBSE content under "Physics" and "Chemistry" headings here purely
// for study navigation inside FormulaVerse; this is flagged on every CBSE
// Physics/Chemistry entry so it is never mistaken for an official separate
// CBSE subject.
// ---------------------------------------------------------------------------

export interface ChapterEntry {
  board: Board;
  classLevel: ClassLevel;
  subject: Subject;
  chapter: string;
  topics: string[];
  status: SyllabusStatus;
  note?: string;
  source?: { name: string; url: string };
}

const CBSE_SCIENCE_NOTE =
  "CBSE/NCERT teaches this as part of the single integrated 'Science' subject (with Biology), not as a separate subject called Physics or Chemistry. Organised here under its own heading for study navigation only.";

export const SYLLABUS: ChapterEntry[] = [
  // ============================= CBSE — MATHEMATICS =============================
  {
    board: "CBSE",
    classLevel: 8,
    subject: "Mathematics",
    chapter: "Rational Numbers",
    topics: ["Properties of rational numbers", "Representation on a number line", "Operations on rational numbers"],
    status: "Unverified",
    note: "Based on the long-standing NCERT Class 8 Maths chapter structure; confirm against your current edition.",
  },
  {
    board: "CBSE",
    classLevel: 8,
    subject: "Mathematics",
    chapter: "Linear Equations in One Variable",
    topics: ["Solving linear equations", "Applications to word problems", "Reducing equations to simpler form"],
    status: "Unverified",
  },
  {
    board: "CBSE",
    classLevel: 8,
    subject: "Mathematics",
    chapter: "Understanding Quadrilaterals",
    topics: ["Classification of polygons", "Angle sum property", "Properties of parallelograms, rhombus, kite"],
    status: "Unverified",
  },
  { board: "CBSE", classLevel: 8, subject: "Mathematics", chapter: "Practical Geometry", topics: ["Construction of quadrilaterals"], status: "Unverified" },
  {
    board: "CBSE",
    classLevel: 8,
    subject: "Mathematics",
    chapter: "Data Handling",
    topics: ["Organising data", "Bar graphs, histograms, pie charts", "Probability — simple experiments"],
    status: "Unverified",
  },
  { board: "CBSE", classLevel: 8, subject: "Mathematics", chapter: "Squares and Square Roots", topics: ["Properties of squares", "Finding square roots", "Square roots of decimals"], status: "Unverified" },
  { board: "CBSE", classLevel: 8, subject: "Mathematics", chapter: "Cubes and Cube Roots", topics: ["Properties of cubes", "Finding cube roots"], status: "Unverified" },
  {
    board: "CBSE",
    classLevel: 8,
    subject: "Mathematics",
    chapter: "Comparing Quantities",
    topics: ["Percentages", "Profit, loss and discount", "Simple and compound interest"],
    status: "Unverified",
  },
  {
    board: "CBSE",
    classLevel: 8,
    subject: "Mathematics",
    chapter: "Algebraic Expressions and Identities",
    topics: ["Addition/subtraction of expressions", "Multiplication of algebraic expressions", "Standard identities", "Factorisation"],
    status: "Unverified",
  },
  { board: "CBSE", classLevel: 8, subject: "Mathematics", chapter: "Visualising Solid Shapes", topics: ["Nets of solids", "Views of 3D shapes", "Euler's formula"], status: "Unverified" },
  {
    board: "CBSE",
    classLevel: 8,
    subject: "Mathematics",
    chapter: "Mensuration",
    topics: ["Area of trapezium, rhombus, polygon", "Surface area of cube/cuboid/cylinder", "Volume of cube/cuboid/cylinder"],
    status: "Unverified",
  },
  { board: "CBSE", classLevel: 8, subject: "Mathematics", chapter: "Exponents and Powers", topics: ["Laws of exponents", "Negative exponents", "Standard/scientific form"], status: "Unverified" },
  { board: "CBSE", classLevel: 8, subject: "Mathematics", chapter: "Direct and Inverse Proportions", topics: ["Direct proportion", "Inverse proportion", "Word problems"], status: "Unverified" },
  { board: "CBSE", classLevel: 8, subject: "Mathematics", chapter: "Factorisation", topics: ["Factorisation using common factors", "Factorisation using identities", "Division of algebraic expressions"], status: "Unverified" },
  { board: "CBSE", classLevel: 8, subject: "Mathematics", chapter: "Introduction to Graphs", topics: ["Linear graphs", "Reading and plotting graphs"], status: "Unverified" },
  { board: "CBSE", classLevel: 8, subject: "Mathematics", chapter: "Playing with Numbers", topics: ["Numbers in general form", "Divisibility tests", "Puzzles"], status: "Unverified" },

  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Number Systems",
    topics: ["Rational and irrational numbers", "Real numbers and decimal expansions", "Laws of exponents for real numbers"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Polynomials",
    topics: ["Polynomials in one variable", "Zeros of a polynomial", "Factorisation of polynomials", "Algebraic identities"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Coordinate Geometry",
    topics: ["Cartesian system", "Plotting points in a plane"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Linear Equations in Two Variables",
    topics: ["Linear equations and their solutions", "Graph of a linear equation"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Introduction to Euclid's Geometry",
    topics: ["Euclid's definitions", "Axioms and postulates"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Lines and Angles",
    topics: ["Basic terms and definitions", "Pairs of angles", "Lines parallel to the same line"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Triangles",
    topics: ["Congruence of triangles", "Criteria for congruence", "Properties of a triangle"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Quadrilaterals",
    topics: ["Properties of a parallelogram", "The midpoint theorem"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Circles",
    topics: ["Angle subtended by a chord", "Perpendicular from the centre to a chord", "Cyclic quadrilaterals"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Heron's Formula",
    topics: ["Area of a triangle using Heron's formula"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Surface Areas and Volumes",
    topics: ["Surface area and volume of a cone", "Surface area and volume of a sphere"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Statistics",
    topics: ["Graphical representation of data", "Measures of central tendency"],
    status: "Official",
    source: { name: "NCERT/CBSE Class 9 Maths syllabus (published summaries)", url: "https://school.careers360.com/ncert/ncert-syllabus-for-class-9" },
  },
  {
    board: "CBSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Probability",
    topics: ["Empirical/experimental probability"],
    status: "Unverified",
    note: "Included in recent syllabi but confirm its exact placement for your academic year.",
  },

  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Real Numbers",
    topics: ["Euclid's division lemma", "Fundamental Theorem of Arithmetic", "Irrationality proofs"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Polynomials",
    topics: ["Zeros of a polynomial", "Relationship between zeros and coefficients"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Pair of Linear Equations in Two Variables",
    topics: ["Graphical method", "Substitution and elimination methods", "Consistency/inconsistency"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Quadratic Equations",
    topics: ["Standard form", "Solving by factorisation", "Quadratic formula", "Nature of roots (discriminant)"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Arithmetic Progressions",
    topics: ["nth term of an AP", "Sum of first n terms"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Triangles",
    topics: ["Similar triangles", "Basic Proportionality Theorem", "Pythagoras theorem and converse"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Coordinate Geometry",
    topics: ["Distance formula", "Section formula", "Area of a triangle"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Introduction to Trigonometry",
    topics: ["Trigonometric ratios", "Values at standard angles", "Trigonometric identities"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Some Applications of Trigonometry",
    topics: ["Heights and distances", "Angle of elevation/depression"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Circles",
    topics: ["Tangent to a circle", "Tangent perpendicular to radius", "Lengths of tangents from an external point"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  { board: "CBSE", classLevel: 10, subject: "Mathematics", chapter: "Constructions", topics: ["Division of a line segment", "Construction of similar triangles", "Tangents to a circle"], status: "Official", source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" } },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Areas Related to Circles",
    topics: ["Area of sector and segment", "Areas of combinations of plane figures"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Surface Areas and Volumes",
    topics: ["Combinations of solids", "Surface area and volume of combined solids"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Statistics",
    topics: ["Mean, median, mode of grouped data", "Cumulative frequency"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },
  {
    board: "CBSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Probability",
    topics: ["Classical/theoretical probability"],
    status: "Official",
    source: { name: "CBSE Class 10 Maths syllabus 2024-25", url: "https://edustud.nic.in/edu/SYLLABUS_2024_25/10/10_math_eng_2024_25.pdf" },
  },

  // ============================= CBSE — PHYSICS (part of integrated Science) =============================
  { board: "CBSE", classLevel: 8, subject: "Physics", chapter: "Force and Pressure", topics: ["Types of force", "Pressure in fluids"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 8, subject: "Physics", chapter: "Friction", topics: ["Causes of friction", "Advantages and disadvantages"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 8, subject: "Physics", chapter: "Sound", topics: ["Production and propagation of sound", "Frequency, amplitude, pitch"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 8, subject: "Physics", chapter: "Chemical Effects of Electric Current", topics: ["Conductors and insulators", "Electroplating — introductory"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 8, subject: "Physics", chapter: "Some Natural Phenomena", topics: ["Lightning", "Earthquakes — basic safety"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 8, subject: "Physics", chapter: "Light", topics: ["Reflection of light", "Human eye — introductory"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 8, subject: "Physics", chapter: "Stars and the Solar System", topics: ["The Moon", "Stars and constellations", "The solar system"], status: "Unverified", note: CBSE_SCIENCE_NOTE },

  { board: "CBSE", classLevel: 9, subject: "Physics", chapter: "Motion", topics: ["Distance and displacement", "Speed and velocity", "Equations of motion", "Graphs of motion"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 9, subject: "Physics", chapter: "Force and Laws of Motion", topics: ["Newton's three laws", "Inertia and momentum", "Conservation of momentum"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 9, subject: "Physics", chapter: "Gravitation", topics: ["Universal law of gravitation", "Free fall", "Mass and weight", "Thrust, pressure, buoyancy", "Archimedes' principle"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 9, subject: "Physics", chapter: "Work and Energy", topics: ["Work done by a force", "Kinetic and potential energy", "Conservation of energy", "Power"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 9, subject: "Physics", chapter: "Sound", topics: ["Wave nature of sound", "Speed of sound", "Reflection — echo and reverberation"], status: "Unverified", note: CBSE_SCIENCE_NOTE },

  { board: "CBSE", classLevel: 10, subject: "Physics", chapter: "Light — Reflection and Refraction", topics: ["Spherical mirrors", "Mirror formula and magnification", "Refraction", "Lenses"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 10, subject: "Physics", chapter: "The Human Eye and the Colourful World", topics: ["Defects of vision", "Dispersion of light", "Scattering"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 10, subject: "Physics", chapter: "Electricity", topics: ["Electric current and potential difference", "Ohm's law", "Resistance and resistivity", "Series and parallel circuits", "Electrical power"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 10, subject: "Physics", chapter: "Magnetic Effects of Electric Current", topics: ["Magnetic field and field lines", "Force on a current-carrying conductor", "Electromagnetic induction", "Electric motor and generator"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 10, subject: "Physics", chapter: "Sources of Energy", topics: ["Conventional and non-conventional energy sources", "Environmental consequences"], status: "Unverified", note: CBSE_SCIENCE_NOTE },

  // ============================= CBSE — CHEMISTRY (part of integrated Science) =============================
  { board: "CBSE", classLevel: 8, subject: "Chemistry", chapter: "Materials: Metals and Non-Metals", topics: ["Physical properties", "Chemical properties", "Uses"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 8, subject: "Chemistry", chapter: "Synthetic Fibres and Plastics", topics: ["Types of synthetic fibres", "Plastics as materials of choice"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 8, subject: "Chemistry", chapter: "Coal and Petroleum", topics: ["Formation", "Fractional distillation", "Fuel efficiency"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 8, subject: "Chemistry", chapter: "Combustion and Flame", topics: ["Conditions for combustion", "Types of flames", "Fuel efficiency"], status: "Unverified", note: CBSE_SCIENCE_NOTE },

  { board: "CBSE", classLevel: 9, subject: "Chemistry", chapter: "Matter in Our Surroundings", topics: ["States of matter", "Change of state", "Evaporation"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 9, subject: "Chemistry", chapter: "Is Matter Around Us Pure", topics: ["Mixtures and solutions", "Separation techniques", "Physical vs chemical change"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 9, subject: "Chemistry", chapter: "Atoms and Molecules", topics: ["Laws of chemical combination", "Atomic and molecular mass", "Mole concept"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 9, subject: "Chemistry", chapter: "Structure of the Atom", topics: ["Sub-atomic particles", "Atomic models", "Valency", "Isotopes and isobars"], status: "Unverified", note: CBSE_SCIENCE_NOTE },

  { board: "CBSE", classLevel: 10, subject: "Chemistry", chapter: "Chemical Reactions and Equations", topics: ["Balancing equations", "Types of reactions", "Oxidation and reduction"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 10, subject: "Chemistry", chapter: "Acids, Bases and Salts", topics: ["Properties of acids and bases", "pH scale", "Important salts"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 10, subject: "Chemistry", chapter: "Metals and Non-Metals", topics: ["Physical/chemical properties", "Reactivity series", "Extraction of metals", "Corrosion"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 10, subject: "Chemistry", chapter: "Carbon and Its Compounds", topics: ["Covalent bonding", "Homologous series", "Nomenclature", "Ethanol and ethanoic acid", "Soaps and detergents"], status: "Unverified", note: CBSE_SCIENCE_NOTE },
  { board: "CBSE", classLevel: 10, subject: "Chemistry", chapter: "Periodic Classification of Elements", topics: ["Mendeleev's periodic table", "Modern periodic table", "Periodic trends"], status: "Unverified", note: CBSE_SCIENCE_NOTE },

  // ============================= ICSE — MATHEMATICS =============================
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Rational Numbers", topics: ["Properties and operations"], status: "Unverified", note: "Based on common Selina/ICSE Class 8 textbook structure; confirm with current edition." },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Exponents and Powers", topics: ["Laws of exponents"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Squares and Square Roots", topics: ["Perfect squares", "Square root methods"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Cubes and Cube Roots", topics: ["Perfect cubes", "Cube root methods"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Simple and Compound Interest", topics: ["Simple interest", "Compound interest"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Algebraic Expressions and Identities", topics: ["Expansion", "Standard identities"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Factorisation", topics: ["Common factors", "Using identities"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Linear Equations in One Variable", topics: ["Solving and applications"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Understanding Shapes (Polygons & Quadrilaterals)", topics: ["Polygon angle properties", "Quadrilateral properties"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Constructions", topics: ["Construction of quadrilaterals"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Mensuration", topics: ["Area and perimeter", "Surface area and volume of solids"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Mathematics", chapter: "Data Handling and Probability", topics: ["Graphs", "Simple probability"], status: "Unverified" },

  {
    board: "ICSE",
    classLevel: 9,
    subject: "Mathematics",
    chapter: "Rational and Irrational Numbers",
    topics: ["Properties of rational/irrational numbers"],
    status: "Official",
    source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" },
  },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Compound Interest", topics: ["Using the formula", "Without using the formula"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Expansions and Factorisation", topics: ["Standard identities", "Factorisation methods"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Simultaneous Linear Equations", topics: ["Framing and solving equations"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Indices", topics: ["Laws of indices"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Triangles", topics: ["Congruence", "Inequalities in a triangle"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Midpoint Theorem", topics: ["Midpoint theorem and its converse", "Equal intercept theorem"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Pythagoras Theorem", topics: ["Statement and proof", "Applications"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Polygons and Quadrilaterals", topics: ["Angle properties of polygons", "Properties of special quadrilaterals"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Area Theorems", topics: ["Area of parallelograms and triangles"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Circle", topics: ["Chord and arc properties"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Statistics", topics: ["Mean and median of ungrouped data", "Graphical representation"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Mensuration", topics: ["Area and perimeter of plane figures", "Volume and surface area of solids"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Trigonometrical Ratios", topics: ["Ratios of standard angles", "Solution of right triangles", "Complementary angles"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Mathematics", chapter: "Coordinate Geometry", topics: ["Graphical solution", "Distance formula"], status: "Official", source: { name: "ICSE Class 9 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-9/" } },

  {
    board: "ICSE",
    classLevel: 10,
    subject: "Mathematics",
    chapter: "Compound Interest",
    topics: ["Compound interest formula and applications"],
    status: "Official",
    source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" },
  },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Sales Tax and Value Added Tax", topics: ["GST/VAT style computations"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Banking", topics: ["Recurring deposit accounts"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Linear Inequations", topics: ["Solving and graphing inequations"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Quadratic Equations", topics: ["Solving quadratic equations", "Problems on quadratic equations"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Ratio and Proportion", topics: ["Ratio", "Proportion"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Factor Theorem", topics: ["Remainder and factor theorem"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Matrices", topics: ["Matrix operations"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Reflection", topics: ["Reflection in a line/point"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Distance and Section Formulae", topics: ["Distance formula", "Section formula"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Equation of a Straight Line", topics: ["Slope and intercept form"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Symmetry", topics: ["Lines of symmetry"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Similarity", topics: ["Similarity as a size transformation", "Similarity of triangles"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Loci", topics: ["Loci and constructions"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Circles", topics: ["Chord properties", "Angle properties", "Tangent properties", "Constructions involving circles"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Mensuration — Cylinder, Cone and Sphere", topics: ["Surface area and volume"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Trigonometrical Identities", topics: ["Standard identities", "Heights and distances"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Statistics", topics: ["Graphical representation", "Measures of central tendency", "Median, quartiles and mode"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },
  { board: "ICSE", classLevel: 10, subject: "Mathematics", chapter: "Probability", topics: ["Theoretical probability"], status: "Official", source: { name: "ICSE Class 10 Mathematics chapter list (icseboard.org)", url: "https://www.icseboard.org/icse/class-10/" } },

  // ============================= ICSE — PHYSICS =============================
  { board: "ICSE", classLevel: 8, subject: "Physics", chapter: "Matter and Measurement", topics: ["Physical quantities and SI units", "Measuring instruments"], status: "Unverified", note: "Based on common Selina/ICSE Class 8 Physics structure; confirm with current edition." },
  { board: "ICSE", classLevel: 8, subject: "Physics", chapter: "Force and Motion", topics: ["Types of force", "Effects of force"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Physics", chapter: "Energy", topics: ["Forms of energy", "Conservation of energy — introductory"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Physics", chapter: "Light Energy", topics: ["Reflection of light", "Image formation in mirrors"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Physics", chapter: "Heat Transfer", topics: ["Conduction, convection, radiation"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Physics", chapter: "Sound", topics: ["Production and propagation"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Physics", chapter: "Electricity and Magnetism", topics: ["Simple circuits", "Magnetic properties"], status: "Unverified" },

  {
    board: "ICSE",
    classLevel: 9,
    subject: "Physics",
    chapter: "Measurements and Experimentation",
    topics: ["SI units", "Vernier calipers and screw gauge"],
    status: "Official",
    source: { name: "ICSE Class 9 Physics syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" },
  },
  { board: "ICSE", classLevel: 9, subject: "Physics", chapter: "Motion in One Dimension", topics: ["Distance, displacement, speed, velocity, acceleration"], status: "Official", source: { name: "ICSE Class 9 Physics syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Physics", chapter: "Laws of Motion", topics: ["Newton's laws", "Momentum"], status: "Official", source: { name: "ICSE Class 9 Physics syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Physics", chapter: "Fluids", topics: ["Pressure in fluids", "Atmospheric pressure"], status: "Official", source: { name: "ICSE Class 9 Physics syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Physics", chapter: "Buoyancy", topics: ["Archimedes' principle", "Floatation"], status: "Official", source: { name: "ICSE Class 9 Physics syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Physics", chapter: "Light", topics: ["Reflection of light", "Spherical mirrors"], status: "Official", source: { name: "ICSE Class 9 Physics syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Physics", chapter: "Sound", topics: ["Wave motion", "Characteristics of sound"], status: "Official", source: { name: "ICSE Class 9 Physics syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Physics", chapter: "Electricity and Magnetism", topics: ["Current electricity basics", "Magnetic effects"], status: "Official", source: { name: "ICSE Class 9 Physics syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },

  {
    board: "ICSE",
    classLevel: 10,
    subject: "Physics",
    chapter: "Force, Work, Power and Energy",
    topics: ["Turning forces (moments)", "Work, energy, power relations", "Machines as force multipliers", "Conservation of energy"],
    status: "Official",
    source: { name: "ICSE Class 10 Physics syllabus (collegedunia)", url: "https://collegedunia.com/exams/icse-class-x-board/physics-syllabus" },
  },
  {
    board: "ICSE",
    classLevel: 10,
    subject: "Physics",
    chapter: "Light",
    topics: ["Refraction at plane surfaces", "Refraction through a lens", "Total internal reflection", "Spectrum"],
    status: "Official",
    source: { name: "ICSE Class 10 Physics syllabus (collegedunia)", url: "https://collegedunia.com/exams/icse-class-x-board/physics-syllabus" },
  },
  {
    board: "ICSE",
    classLevel: 10,
    subject: "Physics",
    chapter: "Sound",
    topics: ["Reflection of sound (echo)", "Vibrations and resonance", "Loudness, pitch, quality"],
    status: "Official",
    source: { name: "ICSE Class 10 Physics syllabus (collegedunia)", url: "https://collegedunia.com/exams/icse-class-x-board/physics-syllabus" },
  },
  {
    board: "ICSE",
    classLevel: 10,
    subject: "Physics",
    chapter: "Electricity and Magnetism",
    topics: ["Ohm's law", "Electrical power and energy", "Household circuits", "Magnetic effect of current"],
    status: "Official",
    source: { name: "ICSE Class 10 Physics syllabus (collegedunia)", url: "https://collegedunia.com/exams/icse-class-x-board/physics-syllabus" },
  },
  {
    board: "ICSE",
    classLevel: 10,
    subject: "Physics",
    chapter: "Heat",
    topics: ["Calorimetry", "Latent heat", "Loss and gain of heat"],
    status: "Official",
    source: { name: "ICSE Class 10 Physics syllabus (collegedunia)", url: "https://collegedunia.com/exams/icse-class-x-board/physics-syllabus" },
  },
  {
    board: "ICSE",
    classLevel: 10,
    subject: "Physics",
    chapter: "Modern Physics",
    topics: ["Radioactivity", "Changes in the nucleus", "Nuclear energy"],
    status: "Official",
    source: { name: "ICSE Class 10 Physics syllabus (collegedunia)", url: "https://collegedunia.com/exams/icse-class-x-board/physics-syllabus" },
  },

  // ============================= ICSE — CHEMISTRY =============================
  { board: "ICSE", classLevel: 8, subject: "Chemistry", chapter: "Matter and Its Composition", topics: ["States of matter", "Elements, compounds, mixtures"], status: "Unverified", note: "Based on common Selina/ICSE Class 8 Chemistry structure; confirm with current edition." },
  { board: "ICSE", classLevel: 8, subject: "Chemistry", chapter: "Physical and Chemical Changes", topics: ["Distinguishing physical vs chemical change"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Chemistry", chapter: "Atomic Structure — Introduction", topics: ["Protons, neutrons, electrons — introductory"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Chemistry", chapter: "Language of Chemistry", topics: ["Symbols and formulae"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Chemistry", chapter: "Acids, Bases and Salts — Introduction", topics: ["Indicators", "Neutralisation"], status: "Unverified" },
  { board: "ICSE", classLevel: 8, subject: "Chemistry", chapter: "Water", topics: ["Properties of water", "Water purification"], status: "Unverified" },

  {
    board: "ICSE",
    classLevel: 9,
    subject: "Chemistry",
    chapter: "Matter and Its Composition",
    topics: ["Law of conservation of mass"],
    status: "Official",
    source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" },
  },
  { board: "ICSE", classLevel: 9, subject: "Chemistry", chapter: "Study of Gas Laws", topics: ["Boyle's law", "Charles's law"], status: "Official", source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Chemistry", chapter: "Elements, Compounds and Mixtures", topics: ["Classification of matter", "Separation techniques"], status: "Official", source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Chemistry", chapter: "The Language of Chemistry", topics: ["Chemical symbols, formulae, equations"], status: "Official", source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Chemistry", chapter: "Physical and Chemical Changes", topics: ["Types of chemical reactions"], status: "Official", source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Chemistry", chapter: "Water", topics: ["Properties", "Water pollution"], status: "Official", source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Chemistry", chapter: "Atomic Structure", topics: ["Sub-atomic particles", "Electronic configuration"], status: "Official", source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Chemistry", chapter: "The Periodic Table", topics: ["Periodic trends — introductory"], status: "Official", source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Chemistry", chapter: "Study of the First Element — Hydrogen", topics: ["Preparation and properties of hydrogen"], status: "Official", source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },
  { board: "ICSE", classLevel: 9, subject: "Chemistry", chapter: "Atmospheric Pollution", topics: ["Air pollution and its effects"], status: "Official", source: { name: "ICSE Class 9 Chemistry syllabus overview (embibe)", url: "https://www.embibe.com/exams/icse-syllabus-for-class-9/" } },

  {
    board: "ICSE",
    classLevel: 10,
    subject: "Chemistry",
    chapter: "Periodic Properties and Variations of Properties",
    topics: ["Periodic trends", "Modern periodic table up to period 4"],
    status: "Official",
    source: { name: "ICSE Class 10 Chemistry syllabus (educart.co)", url: "https://www.educart.co/icse-and-isc/icse-syllabus-class-10-chemistry" },
  },
  { board: "ICSE", classLevel: 10, subject: "Chemistry", chapter: "Chemical Bonding", topics: ["Ionic bonding", "Covalent bonding"], status: "Official", source: { name: "ICSE Class 10 Chemistry syllabus (educart.co)", url: "https://www.educart.co/icse-and-isc/icse-syllabus-class-10-chemistry" } },
  { board: "ICSE", classLevel: 10, subject: "Chemistry", chapter: "Study of Acids, Bases and Salts", topics: ["Properties and reactions", "Preparation of salts"], status: "Official", source: { name: "ICSE Class 10 Chemistry syllabus (educart.co)", url: "https://www.educart.co/icse-and-isc/icse-syllabus-class-10-chemistry" } },
  { board: "ICSE", classLevel: 10, subject: "Chemistry", chapter: "Analytical Chemistry", topics: ["Action of NaOH and NH4OH on salt solutions", "Amphoteric nature of Al, Zn, Pb"], status: "Official", source: { name: "ICSE Class 10 Chemistry syllabus (educart.co)", url: "https://www.educart.co/icse-and-isc/icse-syllabus-class-10-chemistry" } },
  { board: "ICSE", classLevel: 10, subject: "Chemistry", chapter: "Mole Concept and Stoichiometry", topics: ["Gay-Lussac's and Avogadro's laws", "Mole-mass-volume calculations", "Stoichiometric calculations"], status: "Official", source: { name: "ICSE Class 10 Chemistry syllabus (educart.co)", url: "https://www.educart.co/icse-and-isc/icse-syllabus-class-10-chemistry" } },
  { board: "ICSE", classLevel: 10, subject: "Chemistry", chapter: "Electrolysis", topics: ["Electrolytic processes", "Applications"], status: "Official", source: { name: "ICSE Class 10 Chemistry syllabus (educart.co)", url: "https://www.educart.co/icse-and-isc/icse-syllabus-class-10-chemistry" } },
  { board: "ICSE", classLevel: 10, subject: "Chemistry", chapter: "Metallurgy", topics: ["Extraction of metals"], status: "Official", source: { name: "ICSE Class 10 Chemistry syllabus (educart.co)", url: "https://www.educart.co/icse-and-isc/icse-syllabus-class-10-chemistry" } },
  { board: "ICSE", classLevel: 10, subject: "Chemistry", chapter: "Study of Compounds (HCl, Ammonia, Nitric Acid, Sulphuric Acid)", topics: ["Laboratory preparation", "Properties and uses"], status: "Official", source: { name: "ICSE Class 10 Chemistry syllabus (educart.co)", url: "https://www.educart.co/icse-and-isc/icse-syllabus-class-10-chemistry" } },
  { board: "ICSE", classLevel: 10, subject: "Chemistry", chapter: "Organic Chemistry", topics: ["Hydrocarbons", "Homologous series", "Functional groups"], status: "Official", source: { name: "ICSE Class 10 Chemistry syllabus (educart.co)", url: "https://www.educart.co/icse-and-isc/icse-syllabus-class-10-chemistry" } },
];

// ------------------------------- helpers -------------------------------

export function getBoardChapters(board: Board, classLevel: ClassLevel, subject: Subject): ChapterEntry[] {
  return SYLLABUS.filter((c) => c.board === board && c.classLevel === classLevel && c.subject === subject);
}

export function getChapterEntry(board: Board, classLevel: ClassLevel, subject: Subject, chapter: string): ChapterEntry | undefined {
  return SYLLABUS.find((c) => c.board === board && c.classLevel === classLevel && c.subject === subject && c.chapter === chapter);
}

function norm(s: string): string {
  return s.toLowerCase().trim();
}

export function searchSyllabus(query: string, board?: Board, classLevel?: ClassLevel, subject?: Subject): ChapterEntry[] {
  const q = norm(query);
  if (!q) return [];
  return SYLLABUS.filter((c) => {
    if (board && c.board !== board) return false;
    if (classLevel && c.classLevel !== classLevel) return false;
    if (subject && c.subject !== subject) return false;
    const haystack = `${c.chapter} ${c.topics.join(" ")}`.toLowerCase();
    return haystack.includes(q);
  });
}

export const STATUS_LABEL: Record<SyllabusStatus, string> = {
  Official: "Official Syllabus",
  Additional: "Additional Practice",
  Enrichment: "Enrichment",
  Unverified: "Unverified — please confirm",
};

export const STATUS_COLOR: Record<SyllabusStatus, string> = {
  Official: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300",
  Additional: "bg-sky-100 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300",
  Enrichment: "bg-violet-100 text-violet-700 dark:bg-violet-500/10 dark:text-violet-300",
  Unverified: "bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300",
};
