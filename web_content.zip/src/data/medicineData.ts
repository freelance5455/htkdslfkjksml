import { MedicineItem } from '../types/medicine';

export const MEDICINES_DATA: MedicineItem[] = [
  // 1. Paracetamol (Fever / Pain)
  {
    id: 'paracetamol',
    category: 'Fever Medicines',
    categoryIcon: 'Thermometer',
    bgGradient: 'from-amber-500 to-rose-600',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-800 border-amber-200',
    content: {
      English: {
        name: 'Paracetamol (Acetaminophen)',
        genericName: 'Paracetamol / Acetaminophen',
        brandNames: ['Dolo 650', 'Crocin 650', 'Calpol 500', 'Tylenol', 'Pacimol'],
        categoryName: 'Antipyretic & Analgesic (Fever & Pain Reliever)',
        description: 'Paracetamol is a widely used over-the-counter medication designed to reduce fever and relieve mild-to-moderate pain such as headaches, muscle aches, and toothaches.',
        uses: [
          'Reduction of high body temperature (fever)',
          'Relief from mild to moderate body aches and headaches',
          'Symptomatic relief during viral fever, cold, and flu',
          'Post-vaccination fever and soreness'
        ],
        howItWorks: 'It inhibits the production of prostaglandins in the central nervous system, which are chemical messengers that signal pain and regulate body temperature in the brain.',
        recommendedDosage: 'Adults: 500 mg to 650 mg every 4 to 6 hours as needed. Maximum daily limit is 4,000 mg (4 grams) in 24 hours. Children: Dosage strictly based on body weight (10-15 mg/kg per dose).',
        howToTake: 'Swallow the tablet whole with a glass of water. Do not crush or chew extended-release formulations.',
        foodRelation: 'Can be taken after food to prevent stomach discomfort, though it can also be taken on an empty stomach.',
        missedDoseAdvice: 'If taken on a regular schedule and a dose is missed, take it as soon as remembered. Skip if it is almost time for the next dose. Do not double doses.',
        overdoseInformation: 'Overdose can cause severe liver damage (hepatotoxicity). Seek emergency medical care immediately if more than 4,000 mg is consumed in a day.',
        commonSideEffects: ['Mild nausea', 'Stomach upset', 'Rare skin allergic reactions'],
        seriousSideEffects: ['Jaundice (yellowing of skin/eyes)', 'Severe allergic rash or anaphylaxis', 'Unexplained dark urine or pale stools'],
        warningsPrecautions: [
          'Avoid taking other medications containing paracetamol simultaneously to prevent accidental overdose.',
          'Use with extreme caution if you have underlying liver disease or chronic alcoholism.',
          'Do not exceed recommended daily dosage.'
        ],
        pregnancyInfo: 'Generally considered safe during pregnancy when taken at the lowest effective dose for the shortest possible duration under doctor advice.',
        breastfeedingInfo: 'Safe during breastfeeding in standard therapeutic doses as minimal amounts pass into breast milk.',
        drivingWarning: 'Does not affect driving ability or mental alertness.',
        alcoholInteraction: 'Avoid alcohol consumption while taking paracetamol as it significantly increases the risk of acute liver toxicity.',
        drugInteractions: ['Warfarin (blood thinner)', 'Carbamazepine & Phenytoin (epilepsy meds)', 'Isoniazid & Rifampicin'],
        storageInstructions: 'Store in a cool, dry place below 30°C away from direct sunlight and out of reach of children.',
        faqs: [
          {
            question: 'What is the difference between Dolo 650 and Crocin?',
            answer: 'Both contain the exact same active medicine (Paracetamol). Dolo 650 contains 650 mg per tablet, while standard Crocin usually contains 500 mg or 650 mg.'
          },
          {
            question: 'Can I take Paracetamol on an empty stomach?',
            answer: 'Yes, Paracetamol can be taken with or without food, but taking it after meals reduces the chance of mild stomach irritation.'
          }
        ]
      },
      Hindi: {
        name: 'पैरासिटामोल (Dolo 650 / Crocin)',
        genericName: 'पैरासिटामोल (Paracetamol)',
        brandNames: ['डोलो 650 (Dolo 650)', 'क्रोसीन (Crocin)', 'कालपोल (Calpol)', 'पैसीमोल (Pacimol)'],
        categoryName: 'बुखार और दर्द निवारक दवा',
        description: 'पैरासिटामोल एक बहुत ही सुरक्षित और प्रभावी दवा है जिसका उपयोग बुखार कम करने और सिरदर्द, शरीर दर्द व दांत दर्द से राहत पाने के लिए किया जाता है।',
        uses: [
          'शरीर का तापमान (बुखार) कम करना',
          'सिरदर्द, बदन दर्द और जोड़ों के दर्द से राहत',
          'सर्दी-जुकाम और वायरल बुखार में आराम',
          'टीकाकरण (Vaccination) के बाद होने वाले बुखार में राहत'
        ],
        howItWorks: 'यह मस्तिष्क में दर्द और तापमान को नियंत्रित करने वाले प्रोस्टाग्लैंडीन रसायन के उत्पादन को रोककर काम करता है।',
        recommendedDosage: 'वयस्क: 500 mg से 650 mg आवश्यकतानुसार हर 4 से 6 घंटे में। 24 घंटे में अधिकतम 4,000 mg (4 ग्राम) से अधिक न लें। बच्चों के लिए खुराक वजन के अनुसार तय की जाती है।',
        howToTake: 'गोली को पानी के साथ पूरा निगल लें। इसे चबाएं या कुचलें नहीं।',
        foodRelation: 'भोजन के बाद लेना बेहतर है ताकि पेट में जलन या अस्वस्थता न हो।',
        missedDoseAdvice: 'याद आने पर छूटी हुई खुराक लें। यदि अगली खुराक का समय हो गया हो तो छूटी हुई खुराक छोड़ दें। दोगुनी खुराक न लें।',
        overdoseInformation: 'अत्यधिक मात्रा में लेने पर लिवर को गंभीर नुकसान पहुंच सकता है। 24 घंटे में 4 ग्राम से अधिक लेने पर तुरंत आपातकालीन चिकित्सा सहायता लें।',
        commonSideEffects: ['हल्की मिचली', 'पेट में अस्वस्थता', 'हल्की त्वचा एलर्जी'],
        seriousSideEffects: ['पीलिया (त्वचा या आंखों का पीला पड़ना)', 'गंभीर त्वचा चकत्ते', 'गहरे रंग का पेशाब'],
        warningsPrecautions: [
          'अन्य पैरासिटामोल युक्त दवाओं के साथ न लें ताकि ओवरडोज न हो।',
          'लिवर या गुर्दे की बीमारी वाले मरीज डॉक्टर की सलाह से ही लें।'
        ],
        pregnancyInfo: 'गर्भावस्था के दौरान न्यूनतम आवश्यक खुराक और कम समय के लिए डॉक्टर की सलाह पर लेना सुरक्षित माना जाता है।',
        breastfeedingInfo: 'स्तनपान के दौरान मानक खुराक में लेना सुरक्षित है।',
        drivingWarning: 'ड्राइविंग या मानसिक सतर्कता पर कोई नकारात्मक प्रभाव नहीं पड़ता।',
        alcoholInteraction: 'पैरासिटामोल के साथ शराब का सेवन न करें क्योंकि इससे लिवर खराब होने का खतरा काफी बढ़ जाता है।',
        drugInteractions: ['वारफारिन (रक्त पतला करने वाली दवा)', 'मिर्गी की दवाएं (कार्बामाज़ेपाइन)'],
        storageInstructions: '30°C से कम तापमान पर, सूखी जगह और धूप से बचाकर रखें। बच्चों की पहुंच से दूर रखें।',
        faqs: [
          {
            question: 'क्या डोलो 650 और क्रोसीन एक ही दवा हैं?',
            answer: 'हां, दोनों में एक ही मुख्य साल्ट (पैरासिटामोल) होता है। डोलो 650 में 650 mg की मात्रा होती है।'
          }
        ]
      },
      Marathi: {
        name: 'पॅरासिटामॉल (Dolo 650 / Crocin)',
        genericName: 'पॅरासिटामॉल (Paracetamol)',
        brandNames: ['डोलो ६५० (Dolo 650)', 'क्रॉसिन (Crocin)', 'काल्पोल (Calpol)', 'पॅसिमॉल'],
        categoryName: 'ताप आणि वेदनाशामक औषध',
        description: 'पॅरासिटामॉल हे ताप कमी करण्यासाठी आणि डोकेदुखी, अंगदुखी व सौम्य वेदनांपासून आराम मिळवण्यासाठी वापरले जाणारे अत्यंत लोकप्रिय औषध आहे.',
        uses: [
          'शरीराचे तापमान (ताप) कमी करणे',
          'अंगदुखी, डोकेदुखी आणि स्नायूंच्या वेदना कमी करणे',
          'व्हायरल ताप व सर्दी-पडशात आराम',
          'लसीकरणानंतर येणारा ताप कमी करणे'
        ],
        howItWorks: 'हे मेंदूतील वेदना आणि ताप नियंत्रित करणाऱ्या रसायनांना रोखून कार्य करते.',
        recommendedDosage: 'प्रौढ: ५०० mg ते ६५० mg गरजेनुसार दर ४ ते ६ तासांनी. २४ तासांत जास्तीत जास्त ४,००० mg पेक्षा जास्त घेऊ नये. मुलांसाठी डोस वजनावर आधारित असावा.',
        howToTake: 'गोळी पाण्यासोबत अख्खी गिळावी. गोळी चावू किंवा चुरडू नये.',
        foodRelation: 'जेवणानंतर घेणे अधिक श्रेयस्कर ठरते, ज्यामुळे पोटाला त्रास होत नाही.',
        missedDoseAdvice: 'आठवताच चुकलेला डोस घ्यावा. पुढील डोसची वेळ झाली असल्यास चुकलेला डोस सोडून द्यावा. दुप्पट डोस घेऊ नये.',
        overdoseInformation: 'अतिप्रमाणात घेतल्यास यकृताला (लिव्हर) गंभीर इजा होऊ शकते. दिवसभरात ४ ग्रॅमपेक्षा जास्त डोस घेतल्यास त्वरित डॉक्टरांशी संपर्क साधावा.',
        commonSideEffects: ['सौम्य मळमळ', 'पोटाची अस्वस्थता', 'त्वचेवर सौम्य पुरळ'],
        seriousSideEffects: ['काविळ (डोळे किंवा त्वचा पिवळी होणे)', 'तीव्र ॲलर्जी'],
        warningsPrecautions: [
          'इतर पॅरासिटामॉलयुक्त गोळ्यांसोबत घेऊ नये.',
          'यकृताचा किंवा मूत्रपिंडाचा आजार असल्यास डॉक्टरांच्या सल्ल्यानेच घ्यावे.'
        ],
        pregnancyInfo: 'गरोदरपणात डॉक्टरांच्या सल्ल्याने कमीत कमी डोस घेणे सुरक्षित मानले जाते.',
        breastfeedingInfo: 'स्तनपान करणाऱ्या मातांसाठी योग्य प्रमाणात घेणे सुरक्षित आहे.',
        drivingWarning: 'वाह चालवण्याच्या क्षमतेवर कोणताही परिणाम होत नाही.',
        alcoholInteraction: 'पॅरासिटामॉल चालू असताना मद्यपान पूर्णपणे टाळावे, अन्यथा लिव्हरचे गंभीर नुकसान होऊ शकते.',
        drugInteractions: ['रक्त पातळ करणारी औषधे (Warfarin)'],
        storageInstructions: '३०°C पेक्षा कमी तापमानात, कोरड्या जागी आणि बालकांच्या हस्तक्षेपापासून दूर ठेवावे.',
        faqs: [
          {
            question: 'डोलो ६५० उपाशी पोटी घेता येते का?',
            answer: 'होय, परंतु पोटाची जळजळ टाळण्यासाठी जेवणानंतर किंवा काहीतरी खाऊन घेणे उत्तम.'
          }
        ]
      }
    }
  },

  // 2. Azithromycin (Antibiotics)
  {
    id: 'azithromycin',
    category: 'Antibiotics',
    categoryIcon: 'Pill',
    bgGradient: 'from-blue-600 to-indigo-700',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-800 border-blue-200',
    content: {
      English: {
        name: 'Azithromycin',
        genericName: 'Azithromycin Dihydrate',
        brandNames: ['Azithral 500', 'Zithromax', 'Azee 500', 'Azimax'],
        categoryName: 'Macrolide Antibiotic',
        description: 'Azithromycin is a prescription antibiotic used to treat a wide variety of bacterial infections, particularly of the respiratory tract, ear, throat, and skin.',
        uses: [
          'Bacterial chest and throat infections (Tonsillitis, Pharyngitis, Bronchitis)',
          'Community-acquired pneumonia and sinusitis',
          'Skin and soft tissue bacterial infections',
          'Certain sexually transmitted bacterial infections (Chlamydia)'
        ],
        howItWorks: 'It halts bacterial growth by binding to the 50S ribosomal subunit of susceptible microorganisms, thereby inhibiting bacterial protein synthesis.',
        recommendedDosage: 'Standard adult dose: 500 mg once daily for 3 to 5 days. Must be completed strictly as prescribed by a medical doctor.',
        howToTake: 'Take once daily at the same time with a full glass of water. Complete the entire course even if symptoms improve early.',
        foodRelation: 'Can be taken with or without food. Taking with food helps reduce potential stomach distress.',
        missedDoseAdvice: 'Take the missed dose as soon as remembered. If it is almost time for your next scheduled dose, skip the missed one. Do not take double doses.',
        overdoseInformation: 'Overdose may cause severe diarrhea, vomiting, or temporary hearing loss. Seek medical emergency attention immediately.',
        commonSideEffects: ['Diarrhea / loose stools', 'Nausea and abdominal pain', 'Vomiting', 'Headache'],
        seriousSideEffects: ['Severe watery diarrhea (Clostridium difficile colitis)', 'QT prolongation (irregular heart rhythm)', 'Severe allergic reactions (Stevens-Johnson syndrome)'],
        warningsPrecautions: [
          'Do not take antacids containing aluminum or magnesium within 2 hours of taking Azithromycin.',
          'Complete the full course; stopping early promotes antibiotic resistance.',
          'Inform doctor if you have a history of cardiac arrhythmia or heart failure.'
        ],
        pregnancyInfo: 'Use during pregnancy only if clearly needed and prescribed by a doctor (FDA Category B).',
        breastfeedingInfo: 'Passes into breast milk in small amounts; monitor infant for diarrhea or candidiasis.',
        drivingWarning: 'May cause dizziness in rare cases; exercise caution when driving.',
        alcoholInteraction: 'Alcohol does not directly stop Azithromycin working, but can worsen dizziness and gastrointestinal side effects.',
        drugInteractions: ['Antacids (aluminum/magnesium)', 'Digoxin', 'Warfarin', 'Ergotamine'],
        storageInstructions: 'Store below 25°C in a dry place protected from light.',
        faqs: [
          {
            question: 'Why is Azithromycin prescribed for only 3 to 5 days?',
            answer: 'Azithromycin stays active in body tissues for a long time after the last pill, so a short 3-day or 5-day course is effective for treating infections.'
          }
        ]
      },
      Hindi: {
        name: 'एज़िथ्रोमाइसिन (Azithral 500 / Azee 500)',
        genericName: 'एज़िथ्रोमाइसिन (Azithromycin)',
        brandNames: ['एज़िथ्रल 500 (Azithral 500)', 'अज़ी 500 (Azee 500)', 'ज़िथ्रोमैक्स (Zithromax)'],
        categoryName: 'मैक्रोलाइड एंटीबायोटिक (एंटीबायोटिक दवा)',
        description: 'एज़िथ्रोमाइसिन एक डॉक्टर के पर्चे पर मिलने वाली एंटीबायोटिक दवा है जिसका उपयोग गले, फेफड़ों, कान और त्वचा के जीवाणु (बैक्टीरियल) संक्रमण के इलाज में किया जाता है।',
        uses: [
          'गले और फेफड़ों का बैक्टीरियल इंफेक्शन (टॉन्सिल, ब्रोंकाइटिस, निमोनिया)',
          'कान और साइनस का संक्रमण',
          'त्वचा और नरम ऊतकों का संक्रमण'
        ],
        howItWorks: 'यह बैक्टीरिया के विकास और प्रोटीन निर्माण को रोककर संक्रमण को समाप्त करता है।',
        recommendedDosage: 'वयस्क: 500 mg प्रतिदिन एक बार, 3 से 5 दिनों के लिए (केवल डॉक्टर के परामर्श अनुसार)।',
        howToTake: 'दिन में एक बार निश्चित समय पर पानी के साथ लें। लक्षण ठीक होने पर भी डॉक्टर द्वारा बताया गया पूरा कोर्स खत्म करें।',
        foodRelation: 'इसे भोजन के साथ या बिना भोजन के लिया जा सकता है। भोजन के बाद लेने पर पेट में मिचली कम होती है।',
        missedDoseAdvice: 'याद आते ही छूटी हुई खुराक लें। अगर अगली खुराक का समय हो गया हो तो इसे छोड़ दें।',
        overdoseInformation: 'अत्यधिक मात्रा से उल्टी, दस्त या चक्कर आ सकते हैं। तुरंत डॉक्टर से संपर्क करें।',
        commonSideEffects: ['दस्त या पेट खराब होना', 'मिचली और पेट में दर्द', 'सिरदर्द'],
        seriousSideEffects: ['गंभीर दस्त', 'दिल की धड़कन अनियंत्रित होना (QT Prolongation)', 'त्वचा पर लाल दाने'],
        warningsPrecautions: [
          'एंटासिड (गैस की दवा) लेने से 2 घंटे पहले या बाद में ही लें।',
          'एंटीबायोटिक का कोर्स अधूरा न छोड़ें, इससे बैक्टीरिया में प्रतिरोध क्षमता बढ़ जाती है।'
        ],
        pregnancyInfo: 'गर्भावस्था में डॉक्टर के परामर्श पर ही उपयोग करें।',
        breastfeedingInfo: 'डॉक्टर की सलाह पर स्तनपान के दौरान दिया जा सकता है।',
        drivingWarning: 'यदि चक्कर आए तो ड्राइविंग से बचें।',
        alcoholInteraction: 'शराब के साथ लेने पर पेट में दर्द और मिचली बढ़ सकती है।',
        drugInteractions: ['एंटासिड (एल्यूमीनियम/मैग्नीशियम)', 'वारफारिन', 'डिगोक्सिन'],
        storageInstructions: '25°C से कम तापमान पर सूखी जगह रखें।',
        faqs: [
          {
            question: 'क्या एज़िथ्रोमाइसिन केवल 3 दिन ही ली जाती है?',
            answer: 'हां, यह दवा शरीर के ऊतकों में कई दिनों तक असरदार रहती है, इसलिए 3 से 5 दिन का कोर्स पर्याप्त होता है।'
          }
        ]
      },
      Marathi: {
        name: 'ॲझिथ्रोमायसिन (Azithral / Azee 500)',
        genericName: 'ॲझिथ्रोमायसिन (Azithromycin)',
        brandNames: ['ॲझिथ्रल ५०० (Azithral 500)', 'अझी ५०० (Azee 500)'],
        categoryName: 'एंटीबायोटिक औषध',
        description: 'ॲझिथ्रोमायसिन हे एक प्रभावी प्रतिजैविक (एंटीबायोटिक) औषध आहे जे छाती, घसा, कान आणि त्वचेच्या जिवाणू संसर्गावर (Bacterial infection) वापरले जाते.',
        uses: [
          'घसा आणि फुफ्फुसाचा संसर्ग (टॉन्सिल्स, निमोनिया)',
          'कान आणि सायनायटिसचा संसर्ग',
          'त्वचेचे संसर्ग'
        ],
        howItWorks: 'हे बॅक्टेरियाच्या वाढीस आवश्यक असणाऱ्या प्रथिनांची निर्मिती रोखून बॅक्टेरिया नष्ट करते.',
        recommendedDosage: 'प्रौढ: ५०० mg दिवसातून एकदा सलग ३ ते ५ दिवस (केवळ डॉक्टरांच्या सल्ल्याने).',
        howToTake: 'दररोज एकाच वेळी पाण्यासोबत घ्यावे. त्रास कमी झाला तरी डॉक्टरांनी दिलेला संपूर्ण कोर्स पूर्ण करावा.',
        foodRelation: 'जेवणासोबत किंवा जेवणाशिवाय घेता येते.',
        missedDoseAdvice: 'आठवताच डोस घ्यावा. पुढील डोसची वेळ झाली असल्यास मागील डोस सोडून द्यावा.',
        overdoseInformation: 'अतिप्रमाणात घेतल्यास जुलाब किंवा मळमळ होऊ शकते. त्वरित डॉक्टरांकडे जावे.',
        commonSideEffects: ['जुलाब', 'पोटदुखी व मळमळ', 'डोकेदुखी'],
        seriousSideEffects: ['तीव्र ॲलर्जी', 'हृदयाचे ठोके अनियमित होणे'],
        warningsPrecautions: [
          'ॲसिडिटीची औषधे (Antacids) घेण्याच्या २ तास आधी किंवा नंतरच हे औषध घ्यावे.',
          'औषधांचा कोर्स अर्ध्यावर सोडू नये.'
        ],
        pregnancyInfo: 'गरोदरपणात डॉक्टरांच्या सल्ल्यानेच वापरावे.',
        breastfeedingInfo: 'डॉक्टरांच्या सल्ल्याने घेणे सुरक्षित.',
        drivingWarning: 'चक्कर आल्यास वाहन चालवणे टाळावे.',
        alcoholInteraction: 'दारूशी थेट संवाद नसला तरी पोटाचा त्रास वाढू शकतो.',
        drugInteractions: ['अँटासिड्स', 'वारफारिन'],
        storageInstructions: '२५°C पेक्षा कमी तापमानात कोरड्या जागी ठेवावे.',
        faqs: [
          {
            question: 'ॲझिथ्रोमायसिनचा कोर्स पूर्ण करणे का गरजेचे आहे?',
            answer: 'कोर्स अर्ध्यावर सोडल्यास बॅक्टेरिया औषधाला प्रतिकार करू लागतात (Antibiotic resistance) आणि संसर्ग पुन्हा उद्भवू शकतो.'
          }
        ]
      }
    }
  },

  // 3. Cetirizine (Anti-Allergy)
  {
    id: 'cetirizine',
    category: 'Anti-Allergy Medicines',
    categoryIcon: 'ShieldAlert',
    bgGradient: 'from-emerald-500 to-teal-700',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-800 border-emerald-200',
    content: {
      English: {
        name: 'Cetirizine Hydrochloride',
        genericName: 'Cetirizine HCl',
        brandNames: ['Okacet 10', 'Cetzine', 'Zyrtec', 'Alerid', 'Cetcip'],
        categoryName: 'Antihistamine (Anti-Allergy)',
        description: 'Cetirizine is a non-drowsy second-generation antihistamine used to relieve symptoms associated with seasonal allergies, allergic rhinitis, hives, and insect bites.',
        uses: [
          'Relief of runny nose, sneezing, and watery eyes (Hay fever)',
          'Treatment of allergic skin rashes, itching, and hives (Urticaria)',
          'Allergic reactions to dust, pollen, pet dander, or food items'
        ],
        howItWorks: 'It selectively blocks histamine H1 receptors, preventing histamine (a natural inflammatory chemical in the body) from triggering allergic reactions.',
        recommendedDosage: 'Adults and children over 12 years: 5 mg to 10 mg once daily (preferably at bedtime). Maximum 10 mg daily.',
        howToTake: 'Swallow tablet with water. Best taken in the evening or at night due to mild sedative effects in sensitive individuals.',
        foodRelation: 'Can be taken with or without food.',
        missedDoseAdvice: 'Take missed dose as soon as remembered. Skip if it is close to your next scheduled dose.',
        overdoseInformation: 'Overdose may cause extreme drowsiness, confusion, or agitation. Seek immediate emergency care.',
        commonSideEffects: ['Mild drowsiness / sleepiness', 'Dry mouth', 'Fatigue', 'Mild headache'],
        seriousSideEffects: ['Difficulty breathing or swallowing (Anaphylaxis)', 'Severe dizziness', 'Urinary retention'],
        warningsPrecautions: [
          'May cause drowsiness in sensitive individuals; avoid operating heavy machinery until you know how it affects you.',
          'Dose adjustment required for patients with severe renal impairment (kidney disease).'
        ],
        pregnancyInfo: 'Consult doctor before use. Generally Category B (used when benefits outweigh risks).',
        breastfeedingInfo: 'Excreted in small amounts in breast milk; may cause sedation in nursing infants. Use under medical supervision.',
        drivingWarning: 'Caution advised. Can cause mild drowsiness.',
        alcoholInteraction: 'Avoid alcohol as it intensifies drowsiness and central nervous system depression.',
        drugInteractions: ['Sedatives & sleeping pills', 'Tranquilizers', 'Alcohol'],
        storageInstructions: 'Store in a dry room below 30°C.',
        faqs: [
          {
            question: 'Does Cetirizine make you sleepy?',
            answer: 'While Cetirizine is a second-generation antihistamine designed to be less sedating, it can still cause mild sleepiness in some people. Taking it at night is recommended.'
          }
        ]
      },
      Hindi: {
        name: 'सेटिरिज़िन (Okacet / Cetzine)',
        genericName: 'सेटिरिज़िन (Cetirizine HCl)',
        brandNames: ['ओकासेट (Okacet)', 'सेटज़ीन (Cetzine)', 'एलरिड (Alerid)', 'सेटसिप (Cetcip)'],
        categoryName: 'एंटी-अलर्जिक (Antihistamine)',
        description: 'सेटिरिज़िन एक लोकप्रिय एंटी-एलर्जी दवा है जिसका उपयोग बहती नाक, छींक, आंखों में पानी और त्वचा की एलर्जी (खुजली और चकत्ते) के इलाज के लिए किया जाता है।',
        uses: [
          'छींक आना, बहती नाक और आंखों में पानी (एलर्जी)',
          'त्वचा पर खुजली, पित्ती (Urticaria) और लाल दाने',
          'धूल, धुएं और परागकणों से होने वाली एलर्जी'
        ],
        howItWorks: 'यह शरीर में एलर्जी पैदा करने वाले प्राकृतिक हिस्टामाइन रसायन को रोककर काम करता है।',
        recommendedDosage: 'वयस्क: 10 mg की एक गोली रोजाना रात को सोने से पहले।',
        howToTake: 'गोली को पानी के साथ निगलें।',
        foodRelation: 'भोजन के साथ या बिना भोजन के ले सकते हैं।',
        missedDoseAdvice: 'याद आने पर लें, अगली खुराक का समय हो तो छोड़ दें।',
        overdoseInformation: 'अत्यधिक मात्रा से बहुत अधिक नींद या घबराहट हो सकती है। डॉक्टर से संपर्क करें।',
        commonSideEffects: ['हल्की नींद आना', 'मुंह सूखना', 'थकान'],
        seriousSideEffects: ['सांस लेने में तकलीफ', 'अत्यधिक चक्कर आना'],
        warningsPrecautions: [
          'इसे लेने के बाद वाहन न चलाएं यदि आपको सुस्ती महसूस हो रही हो।',
          'किडनी के मरीज डॉक्टर की सलाह से ही लें।'
        ],
        pregnancyInfo: 'गर्भावस्था में डॉक्टर से परामर्श के बाद ही लें।',
        breastfeedingInfo: 'स्तनपान के दौरान डॉक्टर की सलाह आवश्यक है।',
        drivingWarning: 'सावधानी बरतें, हल्की नींद आ सकती है।',
        alcoholInteraction: 'शराब के साथ लेने पर नींद और सुस्ती बहुत बढ़ सकती है।',
        drugInteractions: ['नींद की गोलियां', 'शराब'],
        storageInstructions: 'सूखी जगह पर कमरे के तापमान पर रखें।',
        faqs: [
          {
            question: 'क्या सेटिरिज़िन से नींद आती है?',
            answer: 'हां, कुछ लोगों में इससे हल्की नींद या सुस्ती आ सकती है, इसीलिए इसे रात को सोने से पहले लेने की सलाह दी जाती है।'
          }
        ]
      },
      Marathi: {
        name: 'सेटिरिझिन (Okacet / Cetzine)',
        genericName: 'सेटिरिझिन (Cetirizine HCl)',
        brandNames: ['ओकासेट (Okacet)', 'सेटझीन (Cetzine)', 'ॲलरीड (Alerid)'],
        categoryName: 'एंटी-ॲलर्जिक गोळी',
        description: 'सेटिरिझिन हे ॲलर्जीवर वापरले जाणारे औषध आहे, जे नाक गळणे, शिंका येणे, डोळ्यांतून पाणी येणे आणि त्वचेवरील खाज कमी करते.',
        uses: [
          'शिंका येणे, नाक वाहणे व ॲलर्जी',
          'त्वचेवर खाज येणे आणि लाल चट्टे उठणे (पित्त/Urticaria)'
        ],
        howItWorks: 'हे शरीरातील हिस्टामाइन नावाचे रसायन रोखून ॲलर्जीची लक्षणे थांबवते.',
        recommendedDosage: 'प्रौढ: १० mg ची १ गोळी रोज रात्री.',
        howToTake: 'पाण्यासोबत गोळी घ्यावी.',
        foodRelation: 'जेवणाआधी किंवा जेवणानंतर घेता येते.',
        missedDoseAdvice: 'आठवताच गोळी घ्यावी.',
        overdoseInformation: 'अतिप्रमाणात घेतल्यास तीव्र झोप येऊ शकते.',
        commonSideEffects: ['सौम्य झोप/सुस्ती', 'तोंड सुकणे', 'थकवा'],
        seriousSideEffects: ['शॉक किंवा श्वास घेण्यास त्रास'],
        warningsPrecautions: [
          'गोळी घेतल्यानंतर सुस्ती आल्यास वाहन चालवणे टाळावे.'
        ],
        pregnancyInfo: 'डॉक्टरांच्या सल्ल्यानुसारच घ्यावे.',
        breastfeedingInfo: 'डॉक्टरांचा सल्ला आवश्यक.',
        drivingWarning: 'सुस्ती येऊ शकते, काळजी घ्यावी.',
        alcoholInteraction: 'मद्यपानासोबत घेतल्यास अतिसुस्ती येते.',
        drugInteractions: ['झोपेच्या गोळ्या'],
        storageInstructions: 'कोरड्या जागी ३०°C च्या खाली ठेवावे.',
        faqs: [
          {
            question: 'सेटिरिझिन रात्री घेणे का योग्य ठरेल?',
            answer: 'या औषधामुळे सौम्य झोप येऊ शकते, म्हणून रात्री झोपताना घेणे सोयीचे ठरते.'
          }
        ]
      }
    }
  },

  // 4. Metformin (Diabetes)
  {
    id: 'metformin',
    category: 'Diabetes Medicines',
    categoryIcon: 'Activity',
    bgGradient: 'from-blue-600 to-indigo-800',
    badgeBg: 'bg-indigo-50',
    badgeText: 'text-indigo-800 border-indigo-200',
    content: {
      English: {
        name: 'Metformin Hydrochloride',
        genericName: 'Metformin HCl',
        brandNames: ['Glycomet 500', 'Obimet', 'Glyciphage', 'Glucophage', 'Riomet'],
        categoryName: 'Biguanide Antidiabetic Medicine',
        description: 'Metformin is the first-line prescription medication for the management of Type 2 Diabetes Mellitus. It helps control blood sugar levels alongside diet and exercise.',
        uses: [
          'Management and blood sugar control in Type 2 Diabetes',
          'Polycystic Ovary Syndrome (PCOS) insulin resistance treatment',
          'Prevention of Type 2 diabetes in high-risk prediabetic patients'
        ],
        howItWorks: 'It reduces hepatic glucose production (sugar made by the liver), decreases intestinal absorption of glucose, and improves insulin sensitivity in skeletal muscle.',
        recommendedDosage: 'Initial dose: 500 mg once or twice daily with meals. Dosage is escalated gradually under strict endocrinologist supervision up to 2,000 mg daily.',
        howToTake: 'Always take with meals to reduce gastrointestinal side effects. Extended-release (SR/XR) tablets must be swallowed whole.',
        foodRelation: 'Must be taken WITH meals (during or immediately after food).',
        missedDoseAdvice: 'Take with your next meal. Do not take extra medicine to make up the missed dose.',
        overdoseInformation: 'Risk of Lactic Acidosis (a life-threatening medical emergency). Seek immediate hospital care if severe weakness or muscle pain occurs.',
        commonSideEffects: ['Diarrhea & gas', 'Nausea / stomach pain', 'Metallic taste in mouth', 'Decreased Vitamin B12 absorption over long-term use'],
        seriousSideEffects: ['Lactic Acidosis (extreme fatigue, trouble breathing, severe muscle cramps)', 'Severe hypoglycemia when combined with sulfonylureas/insulin'],
        warningsPrecautions: [
          'Contraindicated in patients with severe kidney impairment (eGFR < 30 mL/min).',
          'Temporarily stop Metformin before undergoing radiological imaging involving iodine contrast dyes.',
          'Monitor Vitamin B12 levels annually.'
        ],
        pregnancyInfo: 'Widely used in gestational diabetes under strict specialist advice.',
        breastfeedingInfo: 'Enters breast milk in low concentrations; monitor infant blood sugar.',
        drivingWarning: 'Does not cause hypoglycemia when used alone; driving is generally safe.',
        alcoholInteraction: 'AVOID heavy alcohol as it significantly elevates the risk of fatal Lactic Acidosis.',
        drugInteractions: ['Iodinated Contrast Dyes', 'Cimetidine', 'Diuretics', 'Steroids'],
        storageInstructions: 'Store below 25°C in a tightly closed container.',
        faqs: [
          {
            question: 'Why must Metformin be taken with food?',
            answer: 'Taking Metformin during or right after a meal minimizes common digestive side effects like nausea, stomach cramps, and diarrhea.'
          }
        ]
      },
      Hindi: {
        name: 'मेटफॉर्मिन (Glycomet 500 / Glyciphage)',
        genericName: 'मेटफॉर्मिन (Metformin HCl)',
        brandNames: ['ग्लाइकोमेट (Glycomet 500)', 'ग्लाइसीफेज (Glyciphage)', 'ओबीमेट (Obimet)'],
        categoryName: 'एंटी-डायबिटिक दवा (टाइप 2 मधुमेह)',
        description: 'मेटफॉर्मिन टाइप 2 डायबिटीज (मधुमेह) के इलाज के लिए सबसे प्रमुख और भरोसेमंद दवा है। यह खान-पान और व्यायाम के साथ मिलकर ब्लड शुगर को नियंत्रित करती है।',
        uses: [
          'टाइप 2 मधुमेह (Type 2 Diabetes) में ब्लड शुगर नियंत्रित करना',
          'PCOS (पीसीओएस) में इंसुलिन प्रतिरोध सुधारना'
        ],
        howItWorks: 'यह लिवर द्वारा बनने वाले ग्लूकोज (शर्करा) की मात्रा को कम करती है और शरीर में इंसुलिन के प्रभाव को बढ़ाती है।',
        recommendedDosage: '500 mg से 850 mg दिन में 1 या 2 बार (केवल डॉक्टर के परामर्श पर)।',
        howToTake: 'हमेशा भोजन के साथ या भोजन के ठीक बाद लें।',
        foodRelation: 'भोजन के साथ (With meals) ही लेना अनिवार्य है।',
        missedDoseAdvice: 'अगले भोजन के साथ लें। दोहरी खुराक न लें।',
        overdoseInformation: 'ओवरडोज से लैक्टिक एसिडोसिस (गंभीर स्थिति) हो सकता है। तुरंत अस्पताल जाएं।',
        commonSideEffects: ['दस्त या गैस बनना', 'जी मिचलाना और पेट दर्द', 'मुंह में धातु जैसा स्वाद आना', 'विटामिन बी12 की कमी'],
        seriousSideEffects: ['लैक्टिक एसिडोसिस (अत्यधिक कमजोरी, सांस लेने में तकलीफ, मांसपेशियों में दर्द)'],
        warningsPrecautions: [
          'गुर्दे (किडनी) की गंभीर बीमारी वाले मरीज न लें।',
          'सीटी स्कैन या एक्स-रे में डाई दिए जाने से पहले डॉक्टर को सूचित करें।'
        ],
        pregnancyInfo: 'डॉक्टर की देखरेख में गर्भावस्था में प्रयोग किया जा सकता है।',
        breastfeedingInfo: 'डॉक्टर की सलाह आवश्यक है।',
        drivingWarning: 'ड्राइविंग पर कोई विपरीत प्रभाव नहीं पड़ता।',
        alcoholInteraction: 'शराब के सेवन से बचें; इससे लैक्टिक एसिडोसिस का खतरा बढ़ जाता है।',
        drugInteractions: ['कंट्रास्ट डाई', 'स्टेरॉयड'],
        storageInstructions: 'सूखी जगह पर 25°C से कम तापमान पर रखें।',
        faqs: [
          {
            question: 'मेटफॉर्मिन खाने के साथ लेना क्यों जरूरी है?',
            answer: 'भोजन के साथ लेने से पेट खराब होने, दस्त और मिचली की समस्या से बचाव होता है।'
          }
        ]
      },
      Marathi: {
        name: 'मेटफॉर्मिन (Glycomet 500 / Glyciphage)',
        genericName: 'मेटफॉर्मिन (Metformin HCl)',
        brandNames: ['ग्लायकोमेट (Glycomet 500)', 'ग्लायसीफेज (Glyciphage)'],
        categoryName: 'मधुमेहावरील औषध (Type 2 Diabetes)',
        description: 'मेटफॉर्मिन हे टाइप २ मधुमेहातील रक्तातील साखर नियंत्रणात ठेवण्यासाठी सर्वाधिक वापरले जाणारे मूळ औषध आहे.',
        uses: [
          'टाइप २ मधुमेहात साखरेचे प्रमाण नियंत्रित करणे',
          'PCOS मधील इन्सुलिन रोध सुधारणे'
        ],
        howItWorks: 'हे यकृतातून साखरेची निर्मिती कमी करते आणि इन्सुलिनची कार्यक्षमता वाढवते.',
        recommendedDosage: '५०० mg ते ८५० mg दिवसातून १-२ वेळा (डॉक्टरांच्या सल्ल्याने).',
        howToTake: 'नेहमी जेवणासोबत किंवा जेवणानंतर लगेचच घ्यावे.',
        foodRelation: 'जेवणासोबतच घेणे आवश्यक.',
        missedDoseAdvice: 'पुढील जेवणासोबत डोस घ्यावा. डबल डोस घेऊ नये.',
        overdoseInformation: 'लॅक्टिक ॲसिडोसिसचा धोका. त्वरित रुग्णालयात जावे.',
        commonSideEffects: ['जुलाब किंवा गॅस', 'मळमळ व पेटके', 'तोंडात धातूसारखी चव', 'व्हिटॅमिन B12 ची कमतरता'],
        seriousSideEffects: ['तीव्र थकवा आणि श्वास घेण्यास त्रास (Lactic Acidosis)'],
        warningsPrecautions: ['मूत्रपिंडाचे (Kidney) आजार असल्यास डॉक्टरांना सांगावे.'],
        pregnancyInfo: 'डॉक्टरांच्या सल्ल्याने गरोदरपणात वापरले जाते.',
        breastfeedingInfo: 'डॉक्टरांचा सल्ला आवश्यक.',
        drivingWarning: 'सुरक्षित.',
        alcoholInteraction: 'मद्यपान टाळावे.',
        drugInteractions: ['कंट्रास्ट डाय'],
        storageInstructions: 'कोरड्या जागी ठेवावे.',
        faqs: [
          {
            question: 'मेटफॉर्मिन जेवणासोबतच का घ्यावे?',
            answer: 'जेवणासोबत घेतल्याने पोटाचा त्रास आणि जुलाब होत नाहीत.'
          }
        ]
      }
    }
  },

  // 5. Amlodipine (Blood Pressure)
  {
    id: 'amlodipine',
    category: 'Blood Pressure Medicines',
    categoryIcon: 'HeartPulse',
    bgGradient: 'from-rose-600 to-red-700',
    badgeBg: 'bg-rose-50',
    badgeText: 'text-rose-800 border-rose-200',
    content: {
      English: {
        name: 'Amlodipine Besylate',
        genericName: 'Amlodipine',
        brandNames: ['Stamlo 5', 'Amlopress 5', 'Amlodac', 'Norvasc', 'Amlovas'],
        categoryName: 'Calcium Channel Blocker (Antihypertensive)',
        description: 'Amlodipine is a prescription blood pressure medication used to treat hypertension (high blood pressure) and coronary artery disease (angina/chest pain).',
        uses: [
          'Lowering high blood pressure (Hypertension)',
          'Prevention of chest pain (Chronic Stable Angina)',
          'Reducing long-term cardiovascular risk of stroke and heart attack'
        ],
        howItWorks: 'It relaxes and dilates blood vessels, allowing blood to flow more smoothly and reducing the workload on the heart.',
        recommendedDosage: 'Initial dose: 5 mg once daily. May be increased to a maximum of 10 mg once daily based on blood pressure response.',
        howToTake: 'Take once daily at the same time with water.',
        foodRelation: 'Can be taken with or without food. Avoid grapefruit juice.',
        missedDoseAdvice: 'If missed by more than 12 hours, skip the missed dose and take your next dose at the regular time.',
        overdoseInformation: 'Overdose can cause severe low blood pressure (hypotension) and rapid heart rate. Seek emergency hospital care.',
        commonSideEffects: ['Swelling in ankles/feet (Peripheral edema)', 'Flushing / feeling warm', 'Dizziness or lightheadedness', 'Palpitations'],
        seriousSideEffects: ['Severe chest pain or heart attack signs', 'Extreme dizziness/fainting', 'Allergic swelling of face/lips'],
        warningsPrecautions: [
          'Do not stop taking abruptly as it can cause rebound hypertension.',
          'Avoid Grapefruit and Grapefruit juice as it increases Amlodipine concentration in blood.'
        ],
        pregnancyInfo: 'Use during pregnancy only if potential benefit justifies potential risk to fetus.',
        breastfeedingInfo: 'Passes into human breast milk. Consult your doctor.',
        drivingWarning: 'May cause dizziness initially; avoid driving until you know how Amlodipine affects you.',
        alcoholInteraction: 'Alcohol can further lower blood pressure, causing dizziness or fainting.',
        drugInteractions: ['Simvastatin', 'Ketoconazole & Itraconazole', 'Diltiazem', 'Grapefruit Juice'],
        storageInstructions: 'Store at 15°C - 30°C away from moisture and heat.',
        faqs: [
          {
            question: 'Why does Amlodipine cause ankle swelling?',
            answer: 'Amlodipine dilates small blood vessels (capillaries) in the lower legs, which can cause fluid to accumulate around ankles. Raising your legs or lowering dose helps.'
          }
        ]
      },
      Hindi: {
        name: 'एमलोडीपाइन (Stamlo 5 / Amlopress)',
        genericName: 'एमलोडीपाइन (Amlodipine)',
        brandNames: ['स्टैमलो 5 (Stamlo 5)', 'एमलोप्रेस (Amlopress)', 'एमलोडैक (Amlodac)', 'एमलोवास (Amlovas)'],
        categoryName: 'उच्च रक्तचाप (बीपी) की दवा',
        description: 'एमलोडीपाइन एक एंटी-हाइपरटेंसिव दवा है जो उच्च रक्तचाप (High BP) को नियंत्रित करने और सीने में दर्द (एंजाइना) से बचाव के लिए दी जाती है।',
        uses: [
          'उच्च रक्तचाप (High Blood Pressure) को कम करना',
          'सीने में दर्द (एंजाइना) से बचाव',
          'हार्ट अटैक और स्ट्रोक के जोखिम को घटाना'
        ],
        howItWorks: 'यह रक्त वाहिकाओं को शिथिल (रिलैक्स) और चौड़ा करती है, जिससे रक्त का प्रवाह आसान हो जाता है।',
        recommendedDosage: '5 mg प्रतिदिन एक बार (डॉक्टर की सलाह अनुसार)। जरूरत पड़ने पर 10 mg तक बढ़ाया जा सकता है।',
        howToTake: 'प्रतिदिन निश्चित समय पर पानी के साथ लें।',
        foodRelation: 'भोजन के साथ या बिना भोजन के ले सकते हैं। अंगूर/ग्रेपफ्रूट के जूस से बचें।',
        missedDoseAdvice: 'याद आने पर लें। 12 घंटे से अधिक देरी होने पर अगली सामान्य खुराक लें।',
        overdoseInformation: 'ओवरडोज से बीपी बहुत कम हो सकता है। तुरंत अस्पताल जाएं।',
        commonSideEffects: ['पैर या टखनों में सूजन (Swelling)', 'चेहरे पर गर्माहट या लाली महसूस होना', 'चक्कर आना', 'घबराहट'],
        seriousSideEffects: ['अत्यधिक बीपी गिरना या चक्कर आकर गिरना', 'छाती में तेज दर्द'],
        warningsPrecautions: [
          'अचानक दवा बंद न करें, इससे बीपी एकदम बढ़ सकता है।',
          'अंगूर के रस के साथ न लें।'
        ],
        pregnancyInfo: 'गर्भावस्था में डॉक्टर की सलाह पर ही लें।',
        breastfeedingInfo: 'डॉक्टर से परामर्श करें।',
        drivingWarning: 'शुरुआत में चक्कर आ सकते हैं, सतर्क रहें।',
        alcoholInteraction: 'शराब से बीपी और कम हो सकता है, जिससे चक्कर आ सकते हैं।',
        drugInteractions: ['सिमवास्टेटिन', 'अंगूर का रस'],
        storageInstructions: 'सूखी जगह पर रोशनी से बचाकर रखें।',
        faqs: [
          {
            question: 'क्या एमलोडीपाइन से पैरों में सूजन आती है?',
            answer: 'हां, यह दवा पैरों की नसों को फैलाती है जिससे टखनों में पानी जमा हो सकता है। ऐसा होने पर डॉक्टर को बताएं।'
          }
        ]
      },
      Marathi: {
        name: 'एमलोडिपिन (Stamlo 5 / Amlopress)',
        genericName: 'एमलोडिपिन (Amlodipine)',
        brandNames: ['स्टॅमलो ५ (Stamlo 5)', 'एमलोप्रेस (Amlopress)', 'एमलोडॅक'],
        categoryName: 'उच्च रक्तदाबावरील औषध',
        description: 'एमलोडिपिन हे उच्च रक्तदाब (High BP) आणि छातीत होणाऱ्या वेदना (Angina) कमी करण्यासाठी वापरले जाणारे औषध आहे.',
        uses: [
          'रक्तदाब नियंत्रित ठेवणे',
          'हार्ट अटॅक व स्ट्रोकचा धोका कमी करणे'
        ],
        howItWorks: 'हे रक्तवाहिन्या शिथिल करून रक्ताभिसरण सुलभ करते.',
        recommendedDosage: '५ mg दिवसातून एकदा (डॉक्टरांच्या सल्ल्यानुसार).',
        howToTake: 'रोज एकाच वेळी पाण्यासोबत घ्यावे.',
        foodRelation: 'जेवणाआधी किंवा नंतर घेता येते. ग्रेपफ्रूट ज्यूस टाळावा.',
        missedDoseAdvice: 'आठवताच डोस घ्यावा.',
        overdoseInformation: 'रक्तदाब अत्यंत कमी होऊ शकतो. त्वरित डॉक्टरांकडे जावे.',
        commonSideEffects: ['पायांच्या घोट्यांवर सूज', 'चेहऱ्यावर लालसरपणा', 'चक्कर येणे'],
        seriousSideEffects: ['छातीत तीव्र वेदना'],
        warningsPrecautions: ['औषध अचानक बंद करू नये.'],
        pregnancyInfo: 'डॉक्टरांचा सल्ला आवश्यक.',
        breastfeedingInfo: 'डॉक्टरांचा सल्ला आवश्यक.',
        drivingWarning: 'चक्कर येत असल्यास वाहन चालवणे टाळावे.',
        alcoholInteraction: 'मद्यपान टाळावे.',
        drugInteractions: ['सिमव्हास्टॅटिन'],
        storageInstructions: 'कोरड्या ठिकाणी ठेवावे.',
        faqs: [
          {
            question: 'एमलोडिपिनमुळे पायावर सूज का येते?',
            answer: 'हे औषध रक्तवाहिन्या रुंद करते ज्यामुळे पायांच्या घोट्याभोवती द्रव साचू शकतो.'
          }
        ]
      }
    }
  },

  // 6. Pantoprazole (Digestive)
  {
    id: 'pantoprazole',
    category: 'Digestive Medicines',
    categoryIcon: 'Flame',
    bgGradient: 'from-teal-500 to-emerald-700',
    badgeBg: 'bg-teal-50',
    badgeText: 'text-teal-800 border-teal-200',
    content: {
      English: {
        name: 'Pantoprazole Sodium',
        genericName: 'Pantoprazole',
        brandNames: ['Pan 40', 'Pantocid 40', 'Pantodac', 'Protonix', 'Pan-D'],
        categoryName: 'Proton Pump Inhibitor (PPI / Antacid)',
        description: 'Pantoprazole is a widely prescribed Proton Pump Inhibitor (PPI) that significantly reduces stomach acid production, treating heartburn, acid reflux, and stomach ulcers.',
        uses: [
          'Gastroesophageal Reflux Disease (GERD) & Acid Reflux',
          'Healing and prevention of Stomach (Gastric) & Duodenal Ulcers',
          'Zollinger-Ellison Syndrome (hypersecretion of acid)',
          'Prevention of NSAID-induced stomach ulcers'
        ],
        howItWorks: 'It binds irreversibly to the H+/K+ ATPase pump (proton pump) in parietal cells of the stomach lining, suppressing gastric acid secretion.',
        recommendedDosage: '40 mg once daily in the morning, 30 to 60 minutes BEFORE breakfast.',
        howToTake: 'Swallow the delayed-release tablet whole with water 30 minutes before your first meal. Do not crush, split, or chew.',
        foodRelation: 'Must be taken BEFORE FOOD (30 minutes before breakfast on an empty stomach).',
        missedDoseAdvice: 'Take as soon as remembered before your next meal. Do not double up doses.',
        overdoseInformation: 'Overdose symptoms are rare but may include drowsiness or confusion. Consult a doctor.',
        commonSideEffects: ['Headache', 'Diarrhea or constipation', 'Flatulence (gas)', 'Abdominal pain'],
        seriousSideEffects: ['Bone fractures (hip, wrist, spine) with long-term high-dose use', 'Low magnesium levels (Hypomagnesemia)', 'Clostridium difficile severe diarrhea'],
        warningsPrecautions: [
          'Long-term use (> 1 year) may reduce Vitamin B12 and Magnesium absorption.',
          'Always take before food for optimal stomach acid inhibition.'
        ],
        pregnancyInfo: 'Category B. Used during pregnancy under medical prescription when clearly indicated.',
        breastfeedingInfo: 'Excreted in human milk in small amounts; discuss with doctor.',
        drivingWarning: 'Does not impair driving capability.',
        alcoholInteraction: 'Alcohol increases stomach acid production, aggravating reflux symptoms.',
        drugInteractions: ['Atazanavir', 'Ketoconazole', 'Methotrexate', 'Warfarin'],
        storageInstructions: 'Store below 30°C in a dry place.',
        faqs: [
          {
            question: 'Why must Pantoprazole be taken before eating?',
            answer: 'Pantoprazole needs time to block the proton pumps in your stomach before food triggers acid release.'
          }
        ]
      },
      Hindi: {
        name: 'पैंटोप्राजोल (Pan 40 / Pantocid)',
        genericName: 'पैंटोप्राजोल (Pantoprazole)',
        brandNames: ['पैन 40 (Pan 40)', 'पैनटोसिड (Pantocid)', 'पैनटोडैक (Pantodac)', 'पैन-डी (Pan-D)'],
        categoryName: 'गैस और एसिडिटी की दवा (PPI)',
        description: 'पैंटोप्राजोल पेट में बनने वाले अत्यधिक एसिड (तेजाब) को कम करने वाली एक बहुत प्रभावी दवा है। यह एसिडिटी, सीने की जलन और पेट के छालों (अल्सर) में राहत देती है।',
        uses: [
          'एसिडिटी, सीने में जलन और खट्टी डकारें (GERD)',
          'पेट और आंतों के छाले (Ulcers)',
          'दर्द निवारक गोलियों से पेट के बचाव के लिए'
        ],
        howItWorks: 'यह पेट की दीवारों में एसिड बनाने वाले प्रोटीन पंप (Proton Pump) को रोकती है।',
        recommendedDosage: '40 mg दिन में एक बार, सुबह खाली पेट नाश्ते से 30 मिनट पहले।',
        howToTake: 'गोली को बिना तोड़े या चबाए पानी के साथ निगलें।',
        foodRelation: 'खाली पेट (Before Food) - नाश्ते से 30 मिनट पहले लेना अनिवार्य है।',
        missedDoseAdvice: 'याद आते ही भोजन से पहले लें। दोहरी खुराक न लें।',
        overdoseInformation: 'अत्यधिक मात्रा से सिरदर्द या पेट खराब हो सकता है।',
        commonSideEffects: ['सिरदर्द', 'पेट में गैस बनना या दस्त', 'पेट दर्द'],
        seriousSideEffects: ['लंबे समय तक (1 साल+) लेने पर हड्डियों की कमजोरी या मैग्नीशियम की कमी'],
        warningsPrecautions: [
          'दवा को चबाकर या तोड़कर न खाएं।',
          'बिना डॉक्टर की सलाह के लगातार कई महीनों तक न लें।'
        ],
        pregnancyInfo: 'डॉक्टर की सलाह पर ली जा सकती है।',
        breastfeedingInfo: 'डॉक्टर की सलाह आवश्यक है।',
        drivingWarning: 'ड्राइविंग पर कोई असर नहीं।',
        alcoholInteraction: 'शराब से पेट में एसिड बढ़ता है, अतः शराब से बचें।',
        drugInteractions: ['कीटोकोनाज़ोल', 'मिथोट्रेक्सेट'],
        storageInstructions: '30°C से कम तापमान पर सूखी जगह रखें।',
        faqs: [
          {
            question: 'पैंटोप्राजोल सुबह खाली पेट क्यों ली जाती है?',
            answer: 'क्योंकि खाना खाने से पेट में एसिड बनना शुरू होता है, इसलिए खाली पेट लेने पर यह एसिड बनने की प्रक्रिया को पहले ही रोक देती है।'
          }
        ]
      },
      Marathi: {
        name: 'पँटोप्राझोल (Pan 40 / Pantocid)',
        genericName: 'पँटोप्राझोल (Pantoprazole)',
        brandNames: ['पॅन ४० (Pan 40)', 'पँटोसिड (Pantocid)', 'पॅन-डी (Pan-D)'],
        categoryName: 'ॲसिडिटी व अल्सरवरील औषध',
        description: 'पँटोप्राझोल हे पोटातील ॲसिडचे (पित्त) प्रमाण कमी करणारे प्रभावी औषध आहे, जे छातीत जळजळ आणि अल्सरवर वापरले जाते.',
        uses: [
          'ॲसिडिटी, छातीतील जळजळ व पित्त',
          'पोटातील अल्सर (छाले)'
        ],
        howItWorks: 'हे पोटातील ॲसिड तयार करणाऱ्या पंपांना रोखून ॲसिड निर्मिती कमी करते.',
        recommendedDosage: '४० mg रोज सकाळी उपाशी पोटी (नाश्त्याच्या ३० मिनिटे आधी).',
        howToTake: 'नाश्त्याआधी अख्खी गोळी पाण्यासोबत गिळावी.',
        foodRelation: 'उपाशी पोटी (Before Food) घेणे बंधनकारक.',
        missedDoseAdvice: 'आठवताच जेवणाआधी घ्यावी.',
        overdoseInformation: 'डॉक्टरांशी संपर्क साधावा.',
        commonSideEffects: ['डोकेदुखी', 'गॅस होणे', 'जुलाब'],
        seriousSideEffects: ['दीर्घकाळ वापराने हाडे कमकुवत होणे'],
        warningsPrecautions: ['गोळी चुरुडून खाऊ नये.'],
        pregnancyInfo: 'डॉक्टरांचा सल्ला आवश्यक.',
        breastfeedingInfo: 'डॉक्टरांचा सल्ला आवश्यक.',
        drivingWarning: 'सुरक्षित.',
        alcoholInteraction: 'मद्यपानाने ॲसिडिटी वाढते, टाळावे.',
        drugInteractions: ['कीटोकोनॅझोल'],
        storageInstructions: 'सूक्या जागी ठेवावे.',
        faqs: [
          {
            question: 'पॅन ४० उपाशी पोटीच का घ्यावे?',
            answer: 'नाश्त्यानंतर ॲसिड तयार होण्याची प्रक्रिया सुरू होते, ती आधीच रोखण्यासाठी उपाशी पोटी घेणे गरजेचे असते.'
          }
        ]
      }
    }
  },

  // 7. ORS (Oral Rehydration Salts)
  {
    id: 'ors',
    category: 'Digestive Medicines',
    categoryIcon: 'Droplet',
    bgGradient: 'from-cyan-500 to-blue-600',
    badgeBg: 'bg-cyan-50',
    badgeText: 'text-cyan-800 border-cyan-200',
    content: {
      English: {
        name: 'ORS (Oral Rehydration Salts)',
        genericName: 'Oral Rehydration Salts (WHO Formula)',
        brandNames: ['Electral', 'Walyte', 'ORSL', 'Electrokind'],
        categoryName: 'Electrolyte Replenisher & Hydration Solution',
        description: 'ORS is a WHO-recommended balanced formulation of glucose and essential electrolytes (Sodium, Potassium, Chloride, Citrate) used to treat and prevent dehydration caused by diarrhea, vomiting, or excessive sweating.',
        uses: [
          'Treatment and prevention of dehydration due to acute diarrhea or dysentery',
          'Replenishment of fluids lost through vomiting',
          'Recovery from heat exhaustion and heavy exercise dehydration'
        ],
        howItWorks: 'Glucose in the solution promotes active co-transport of sodium and water molecules across the intestinal mucosa into the bloodstream, rapidly restoring fluid balance.',
        recommendedDosage: 'Dissolve 1 full sachet of WHO-formula ORS powder in exactly 1 Liter of clean drinking water. Drink small sips frequently after every loose stool.',
        howToTake: 'Stir well until powder completely dissolves. Never boil the prepared ORS solution.',
        foodRelation: 'Can be taken with or without food.',
        missedDoseAdvice: 'Sip continuously whenever thirsty or following fluid loss.',
        overdoseInformation: 'Extremely safe; however, excessive fluid intake in patients with severe kidney disease or heart failure requires medical monitoring.',
        commonSideEffects: ['Puffiness around eyes if consumed in extreme excess', 'Vomiting if gulping too quickly'],
        seriousSideEffects: ['Hypernatremia (extremely high sodium levels) if prepared with insufficient water'],
        warningsPrecautions: [
          'CRITICAL: Mix exactly in the correct volume of water stated on the package (usually 1 Liter). Adding too little water can worsen dehydration.',
          'Discard any unused prepared ORS solution after 24 hours.'
        ],
        pregnancyInfo: 'Completely safe during pregnancy and essential for managing dehydration.',
        breastfeedingInfo: 'Completely safe during breastfeeding.',
        drivingWarning: 'No restrictions.',
        alcoholInteraction: 'Safe, helpful for alcohol-induced dehydration recovery.',
        drugInteractions: ['Diuretics (water pills)', 'Potassium supplements'],
        storageInstructions: 'Store powder sachets in a dry place. Prepared liquid solution must be used within 24 hours.',
        faqs: [
          {
            question: 'Can I add sugar or juice to ORS?',
            answer: 'No. Adding sugar or juice disrupts the precise osmolarity ratio of glucose to sodium, making the ORS solution less effective and potentially worsening diarrhea.'
          }
        ]
      },
      Hindi: {
        name: 'ओआरएस (ORS / Electral)',
        genericName: 'ओआरएस (Oral Rehydration Salts)',
        brandNames: ['इलेक्ट्राल (Electral)', 'वेलाइट (Walyte)', 'ओआरएसएल (ORSL)'],
        categoryName: 'निर्जलीकरण (डीहाइड्रेशन) रोधक सॉल्यूशन',
        description: 'ओआरएस विश्व स्वास्थ्य संगठन (WHO) द्वारा प्रमाणित जीवनरक्षक घोल है जो दस्त, उल्टी और अत्यधिक पसीने के कारण शरीर में हुई पानी और खनिजों की कमी (डीहाइड्रेशन) को पूरा करता है।',
        uses: [
          'दस्त और उल्टी से होने वाले डीहाइड्रेशन का इलाज',
          'गर्मी और धूप से होने वाली पानी की कमी (Heat Stroke)',
          'शारीरिक श्रम के बाद शरीर में इलेक्ट्रोलाइट्स का संतुलन बनाना'
        ],
        howItWorks: 'घोल में मौजूद ग्लूकोज और सोडियम आंतों में पानी को जल्दी अवशोषित करने में मदद करते हैं।',
        recommendedDosage: 'WHO फॉर्मूला पाउच को 1 लीटर साफ पीने के पानी में अच्छी तरह घोलें। हर बार पतले दस्त के बाद थोड़ा-थोड़ा पीएं।',
        howToTake: 'घोल को 1 लीटर पानी में मिलाकर थोड़ा-थोड़ा करके घूंट-घूंट पीएं। बनाए गए घोल को उबलें नहीं।',
        foodRelation: 'कभी भी पी सकते हैं।',
        missedDoseAdvice: 'जब भी प्यास लगे या दस्त आए, पीएं।',
        overdoseInformation: 'अत्यंत सुरक्षित है।',
        commonSideEffects: ['बहुत जल्दी-जल्दी गटकने पर उल्टी आना'],
        seriousSideEffects: ['पानी कम मिलाने पर खून में नमक का बढ़ना (गलत घोलना)'],
        warningsPrecautions: [
          'ध्यान दें: 1 लीटर पानी में पूरा पैकेट ही मिलाएं। कम पानी मिलाने से स्थिति बिगड़ सकती है।',
          'बनाए गए ओआरएस घोल को 24 घंटे के बाद फेंक दें और नया घोल बनाएं।'
        ],
        pregnancyInfo: 'गर्भावस्था में पूर्णतः सुरक्षित और आवश्यक है।',
        breastfeedingInfo: 'स्तनपान के दौरान पूर्णतः सुरक्षित है।',
        drivingWarning: 'सुरक्षित।',
        alcoholInteraction: 'सुरक्षित।',
        drugInteractions: ['पोटेशियम सप्लीमेंट्स'],
        storageInstructions: 'पाउच को सूखी जगह रखें। घुला हुआ ओआरएस 24 घंटे के अंदर ही इस्तेमाल करें।',
        faqs: [
          {
            question: 'क्या ओआरएस में चीनी या स्वाद के लिए रस मिला सकते हैं?',
            answer: 'नहीं! अतिरिक्त चीनी या रस मिलाने से घोल का अनुपात बिगड़ जाता है, जिससे दस्त बढ़ सकते हैं।'
          }
        ]
      },
      Marathi: {
        name: 'ओआरएस (ORS / Electral)',
        genericName: 'ओआरएस (Oral Rehydration Salts)',
        brandNames: ['इलेक्ट्रॉल (Electral)', 'वेलाईट (Walyte)'],
        categoryName: 'जलसंजीवनी (इलेक्ट्रोलाइट्स)',
        description: 'ओआरएस हे जुलाब, उलट्या किंवा उन्हामुळे शरीरातील कमी झालेली साखरेची व क्षारांची पातळी भरून काढणारी जीवनरक्षक जलसंजीवनी आहे.',
        uses: [
          'जुलाब व उलट्यांमुळे होणारे डिहायड्रेशन',
          'उन्हाचा त्रास व अतिथकवा'
        ],
        howItWorks: 'हे आतड्यांमध्ये पाणी आणि क्षार वेगाने शोषून घेण्यास मदत करते.',
        recommendedDosage: '१ लिटर स्वच्छ पाण्यात १ पाकीट मिसळून थोडे थोडे प्यावे.',
        howToTake: 'पाण्यात पूर्ण विरघळवून थोडे थोडे घोट घ्यावेत.',
        foodRelation: 'केव्हाही घेता येते.',
        missedDoseAdvice: 'तहान लागल्यास प्यावे.',
        overdoseInformation: 'अत्यंत सुरक्षित.',
        commonSideEffects: ['काही नाही'],
        seriousSideEffects: ['चुकीच्या प्रमाणात पाणी मिसळल्यास त्रास'],
        warningsPrecautions: [
          '१ लिटर पाण्यातच पूर्ण पाकीट विरघळवावे.',
          'तयार केलेले द्रावण २४ तासांनंतर फेकून द्यावे.'
        ],
        pregnancyInfo: 'पूर्णपणे सुरक्षित.',
        breastfeedingInfo: 'पूर्णपणे सुरक्षित.',
        drivingWarning: 'सुरक्षित.',
        alcoholInteraction: 'सुरक्षित.',
        drugInteractions: ['नाही'],
        storageInstructions: 'कोरड्या जागी ठेवावे. तयार केलेले द्रावण २४ तास वापरावे.',
        faqs: [
          {
            question: 'ओआरएस मध्ये वेगळी साखर टाकता येते का?',
            answer: 'नाही, वेगळी साखर टाकल्याने जुलाब वाढू शकतात.'
          }
        ]
      }
    }
  },

  // 8. Salbutamol / Asthalin (Asthma)
  {
    id: 'salbutamol',
    category: 'Asthma Medicines',
    categoryIcon: 'Wind',
    bgGradient: 'from-sky-500 to-cyan-700',
    badgeBg: 'bg-sky-50',
    badgeText: 'text-sky-800 border-sky-200',
    content: {
      English: {
        name: 'Salbutamol / Albuterol',
        genericName: 'Salbutamol Sulfate',
        brandNames: ['Asthalin Inhaler', 'Ventolin', 'Aerolin', 'Asthalin Syrup / Tablet'],
        categoryName: 'Short-Acting Beta-2 Agonist (Bronchodilator)',
        description: 'Salbutamol is a quick-relief rescue medicine used to rapidly relax the muscles around airways during acute asthma attacks, wheezing, and COPD shortness of breath.',
        uses: [
          'Quick relief of acute asthma attack symptoms (wheezing, tightness)',
          'Prevention of exercise-induced bronchospasm',
          'Management of Chronic Obstructive Pulmonary Disease (COPD)'
        ],
        howItWorks: 'It stimulates beta-2 adrenergic receptors in bronchial smooth muscle, causing rapid relaxation and widening of the airways within 5 minutes.',
        recommendedDosage: 'Inhaler: 1 to 2 puffs (100-200 mcg) every 4 to 6 hours as needed for breathlessness.',
        howToTake: 'Exhale fully, seal lips around inhaler mouthpiece, press canister while taking a slow deep breath in, hold breath for 10 seconds.',
        foodRelation: 'Inhalers can be used regardless of meals. Tablets can be taken with food.',
        missedDoseAdvice: 'Used as needed for symptoms. Do not overuse.',
        overdoseInformation: 'Overdose causes rapid heart rate (tachycardia), severe muscle tremors, and agitation. Seek immediate emergency care.',
        commonSideEffects: ['Tremors in fingers/hands', 'Rapid heart rate (Palpitations)', 'Headache', 'Throat irritation'],
        seriousSideEffects: ['Paradoxical bronchospasm (sudden worsening of breathing after puff)', 'Low blood potassium levels (Hypokalemia)'],
        warningsPrecautions: [
          'Always carry your rescue inhaler with you at all times.',
          'If you need to use your inhaler more than 2 times a week, your asthma is not well controlled; consult your doctor.'
        ],
        pregnancyInfo: 'Category C. Used when benefits of maintaining oxygenation outweigh potential risks.',
        breastfeedingInfo: 'Safety established; minimal amounts excreted in milk.',
        drivingWarning: 'Use caution if hands are shaky or experiencing palpitations.',
        alcoholInteraction: 'No major direct interaction, but alcohol can aggravate respiratory distress.',
        drugInteractions: ['Non-selective Beta-blockers (Propranolol)', 'Diuretics'],
        storageInstructions: 'Store inhaler below 30°C. Protect from freezing and direct sunlight.',
        faqs: [
          {
            question: 'How quickly does Asthalin inhaler start working?',
            answer: 'Salbutamol inhaler usually starts opening the airways within 3 to 5 minutes after inhalation.'
          }
        ]
      },
      Hindi: {
        name: 'साल्बुटामोल (Asthalin Inhaler)',
        genericName: 'साल्बुटामोल (Salbutamol / Albuterol)',
        brandNames: ['एस्टालिन इनहेलर (Asthalin Inhaler)', 'वेन्टोलिन (Ventolin)'],
        categoryName: 'दमा (अस्थमा) और सांस फूलने की राहत दवा',
        description: 'साल्बुटामोल एक तुरंत राहत देने वाली (Rescue) इनहेलर दवा है, जो दमे का दौरा (Asthma Attack) पड़ने पर सांस की नलियों को 5 मिनट में खोलकर सांस लेना आसान बनाती है।',
        uses: [
          'अस्थमा अटैक के समय अचानक सांस फूलने और सीटी जैसी आवाज में राहत',
          'व्यायाम के दौरान सांस फूलने से बचाव',
          'सीओपीडी (COPD) बीमारी में सांस की नली खोलना'
        ],
        howItWorks: 'यह फेफड़ों की सिकुड़ी हुई सांस नलियों की मांसपेशियों को तुरंत ढीला और चौड़ा करती है।',
        recommendedDosage: 'इनहेलर: 1 से 2 पफ जरूरत पड़ने पर हर 4 से 6 घंटे में।',
        howToTake: 'पूरी सांस बाहर निकालें, इनहेलर को मुंह में पकड़कर सांस खींचते हुए बटन दबाएं और 10 सेकेंड सांस रोकें।',
        foodRelation: 'कभी भी ले सकते हैं।',
        missedDoseAdvice: 'जरूरत पड़ने पर ही लें।',
        overdoseInformation: 'ज्यादा लेने पर धड़कन बहुत तेज हो सकती है और हाथ कांप सकते हैं।',
        commonSideEffects: ['हाथों में कंपन (कांपना)', 'दिल की धड़कन तेज होना', 'गले में सूखापन'],
        seriousSideEffects: ['अचानक सांस अत्यधिक रुकना (Paradoxical Bronchospasm)'],
        warningsPrecautions: [
          'हमेशा अपना इनहेलर अपने पास रखें।',
          'अगर हफ्ते में 2 बार से ज्यादा इनहेलर की जरूरत पड़ रही है तो डॉक्टर से मिलें।'
        ],
        pregnancyInfo: 'डॉक्टर की सलाह पर ली जा सकती है।',
        breastfeedingInfo: 'डॉक्टर की सलाह पर प्रयोग करें।',
        drivingWarning: 'हाथ कांपने पर सावधानी बरतें।',
        alcoholInteraction: 'कोई बड़ा दुष्प्रभाव नहीं।',
        drugInteractions: ['बीटा-ब्लॉकर्स (प्रोप्रानोलोल)'],
        storageInstructions: '30°C से कम तापमान पर सीधे धूप से बचाकर रखें।',
        faqs: [
          {
            question: 'एस्टालिन इनहेलर कितनी देर में असर दिखाता है?',
            answer: 'यह इनहेलर लेने के 3 से 5 मिनट के अंदर ही सांस नलियों को खोलकर राहत देना शुरू कर देता है।'
          }
        ]
      },
      Marathi: {
        name: 'साल्बुटामॉल (Asthalin Inhaler)',
        genericName: 'साल्बुटामॉल (Salbutamol)',
        brandNames: ['ॲस्टॅलिन इनहेलर (Asthalin)', 'व्हेंटोलिन (Ventolin)'],
        categoryName: 'दमा व श्वासोच्छवासाचे औषध',
        description: 'साल्बुटामॉल हे अस्थमाचा अचानक त्रास झाल्यावर श्वासनलिका ५ मिनिटांत मोकळ्या करणारे आपत्कालीन (Rescue Inhaler) औषध आहे.',
        uses: [
          'अस्थमाच्या झटक्यात श्वास गुदमरणे कमी करणे',
          'छातीतील घरघर थांबवणे'
        ],
        howItWorks: 'हे फुफ्फुसांच्या श्वासनलिका रुंद करते.',
        recommendedDosage: 'इनहेलर: १-२ पफ गरजेनुसार.',
        howToTake: 'तोंडात धरून श्वास आत ओढताना पफ दाबावा व १० सेकंद श्वास रोखावा.',
        foodRelation: 'केव्हाही वापरता येते.',
        missedDoseAdvice: 'त्रास झाल्यावरच घ्यावे.',
        overdoseInformation: 'हात थरथरणे व हृदयाचे ठोके जलद होणे.',
        commonSideEffects: ['हात कापणे/थरथरणे', 'हृदयाची धडधड वाढणे'],
        seriousSideEffects: ['अतिशय त्रास होणे'],
        warningsPrecautions: ['इनहेलर नेहमी सोबत ठेवावा.'],
        pregnancyInfo: 'डॉक्टरांचा सल्ला आवश्यक.',
        breastfeedingInfo: 'डॉक्टरांचा सल्ला आवश्यक.',
        drivingWarning: 'हात थरथरत असल्यास काळजी घ्यावी.',
        alcoholInteraction: 'नाही.',
        drugInteractions: ['बीटा ब्लॉकर्स'],
        storageInstructions: 'सूर्यप्रकाशापासून दूर ठेवावे.',
        faqs: [
          {
            question: 'ॲस्टॅलिन इनहेलरचा असर किती वेळात होतो?',
            answer: 'पफ घेतल्यावर ३ ते ५ मिनिटांत श्वास घेणे सोपे होते.'
          }
        ]
      }
    }
  },

  // 9. Clotrimazole (Antifungal)
  {
    id: 'clotrimazole',
    category: 'Antifungal Medicines',
    categoryIcon: 'Bug',
    bgGradient: 'from-purple-600 to-violet-700',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-purple-800 border-purple-200',
    content: {
      English: {
        name: 'Clotrimazole',
        genericName: 'Clotrimazole Topical / Dusting Powder',
        brandNames: ['Candid Powder', 'Candid Cream', 'Canesten', 'Cloben-G'],
        categoryName: 'Broad-Spectrum Antifungal Medication',
        description: 'Clotrimazole is a topical antifungal medication used to treat ringworm, athlete’s foot, fungal diaper rash, sweat rash, and vaginal yeast infections.',
        uses: [
          'Treatment of fungal skin infections (Ringworm / Tinea corporis)',
          'Athlete’s foot (Tinea pedis) and groin fungal rash (Jock itch / Tinea cruris)',
          'Fungal sweat rash and prickly heat redness',
          'Vaginal yeast infections (Candidiasis)'
        ],
        howItWorks: 'It alters fungal cell membrane permeability by inhibiting ergosterol synthesis, causing cell breakdown and fungal death.',
        recommendedDosage: 'Topical cream/powder: Apply thin layer to affected dry area 2 to 3 times daily for 2 to 4 weeks.',
        howToTake: 'Wash and thoroughly dry the affected skin before applying. Gently rub in.',
        foodRelation: 'Topical product (Not for swallowing). Unaffected by food.',
        missedDoseAdvice: 'Apply as soon as remembered.',
        overdoseInformation: 'Accidental swallowing requires medical advice.',
        commonSideEffects: ['Mild local burning sensation', 'Skin redness or itching at application site', 'Skin peeling'],
        seriousSideEffects: ['Severe allergic contact dermatitis (blistering, severe swelling)'],
        warningsPrecautions: [
          'For external topical use only. Do not apply near eyes, mouth, or open wounds.',
          'Continue applying for 1 week after skin clears to prevent fungal recurrence.'
        ],
        pregnancyInfo: 'Topical clotrimazole is generally safe during pregnancy under medical advice.',
        breastfeedingInfo: 'Safe for topical use; do not apply on nipples prior to nursing.',
        drivingWarning: 'No impact.',
        alcoholInteraction: 'No interaction.',
        drugInteractions: ['None reported for topical form'],
        storageInstructions: 'Store below 25°C. Keep tube tightly closed.',
        faqs: [
          {
            question: 'How long should Candid powder be applied for ringworm?',
            answer: 'Even if itching stops in a few days, continue applying for 2 to 3 weeks to completely eliminate fungal spores.'
          }
        ]
      },
      Hindi: {
        name: 'क्लोट्रिमाजोल (Candid Powder / Cream)',
        genericName: 'क्लोट्रिमाजोल (Clotrimazole)',
        brandNames: ['कैंडिड पाउडर (Candid Powder)', 'कैंडिड क्रीम (Candid Cream)', 'केनेस्टन (Canesten)'],
        categoryName: 'दाद, खाज और फंगल इन्फेक्शन की दवा',
        description: 'क्लोट्रिमाजोल त्वचा के फंगल संक्रमण जैसे दाद, खाज, जांघों की खुजली, एथलीट फुट और पसीने के दाने दूर करने की सबसे लोकप्रिय एंटीफंगल दवा है।',
        uses: [
          'दाद, खाज और खुजली (Ringworm)',
          'पसीने से होने वाले लाल दाने और जांघों का फंगल इंफेक्शन',
          'पैरों की उंगलियों का फंगल इंफेक्शन (Athlete Foot)'
        ],
        howItWorks: 'यह फंगस (कवक) की बाहरी परत को नष्ट करके उसे खत्म करता है।',
        recommendedDosage: 'प्रभावित जगह को धोकर सुखाएं और दिन में 2 से 3 बार क्रीम या पाउडर लगाएं।',
        howToTake: 'केवल त्वचा के ऊपर लगाने के लिए (बाहरी उपयोग)।',
        foodRelation: 'लागू नहीं (त्वचा पर लगाने की दवा)।',
        missedDoseAdvice: 'याद आते ही लगाएं।',
        overdoseInformation: 'गलती से निगलने पर डॉक्टर से संपर्क करें।',
        commonSideEffects: ['लगाने की जगह पर हल्की जलन', 'खुजली या त्वचा छिलना'],
        seriousSideEffects: ['गंभीर त्वचा एलर्जी या छाले पड़ना'],
        warningsPrecautions: [
          'केवल बाहरी त्वचा के लिए है। आंख, मुंह या खुले घाव पर न लगाएं।',
          'दाद ठीक होने के 1 हफ्ते बाद तक लगाते रहें ताकि फंगस दोबारा न आए।'
        ],
        pregnancyInfo: 'त्वचा पर लगाना गर्भावस्था में सुरक्षित माना जाता है।',
        breastfeedingInfo: 'सुरक्षित है (स्तन के अग्रभाग पर न लगाएं)।',
        drivingWarning: 'कोई प्रभाव नहीं।',
        alcoholInteraction: 'कोई प्रभाव नहीं।',
        drugInteractions: ['कोई नहीं'],
        storageInstructions: '25°C से कम तापमान पर ठंडी जगह रखें।',
        faqs: [
          {
            question: 'क्या कैंडिड पाउडर दाद में तुरंत आराम देता है?',
            answer: 'पाउडर खुजली और नमी को तुरंत कम करता है, लेकिन पूरी तरह ठीक होने में 2 से 3 हफ्ते का समय लगता है।'
          }
        ]
      },
      Marathi: {
        name: 'क्लोट्रिमाझोल (Candid Powder / Cream)',
        genericName: 'क्लोट्रिमाझोल (Clotrimazole)',
        brandNames: ['कँडिड पावडर (Candid)', 'कँडिड क्रीम', 'केनेस्टन'],
        categoryName: 'गजकर्ण व बुरशीजन्य संसर्गावरील औषध',
        description: 'क्लोट्रिमाझोल हे त्वचेवरील फंगल इन्फेक्शन (गजकर्ण, नायटा, खाज आणि घामाच्या पुरळ) वर वापरले जाणारे अँटीफंगल औषध आहे.',
        uses: [
          'गजकर्ण, नायटा व खाज',
          'घामामुळे येणारी पुरळ'
        ],
        howItWorks: 'हे बुरशीच्या पेशी नष्ट करून इन्फेक्शन रोखते.',
        recommendedDosage: 'दिवसातून २ ते ३ वेळा लावणे.',
        howToTake: 'त्वचा स्वच्छ व कोरडी करून त्यावर लावावे.',
        foodRelation: 'फक्त त्वचेवर लावण्यासाठी.',
        missedDoseAdvice: 'आठवताच लावावे.',
        overdoseInformation: 'पोटात गेल्यास डॉक्टरांकडे जावे.',
        commonSideEffects: ['सौम्य जळजळ किंवा लालसरपणा'],
        seriousSideEffects: ['ॲलर्जी'],
        warningsPrecautions: ['फक्त बाह्य वापरासाठी. डोळ्यात जावू देऊ नये.'],
        pregnancyInfo: 'सुरक्षित.',
        breastfeedingInfo: 'सुरक्षित.',
        drivingWarning: 'सुरक्षित.',
        alcoholInteraction: 'नाही.',
        drugInteractions: ['नाही'],
        storageInstructions: 'थंड जागी ठेवावे.',
        faqs: [
          {
            question: 'कँडिड पावडर किती दिवस वापरावी?',
            answer: 'खाज थांबली तरी २-३ आठवडे सतत वापरावी जेणेकरून संसर्ग पुन्हा होणार नाही.'
          }
        ]
      }
    }
  },

  // 10. Amoxicillin (Antibiotics)
  {
    id: 'amoxicillin',
    category: 'Antibiotics',
    categoryIcon: 'Pill',
    bgGradient: 'from-blue-500 to-indigo-600',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-800 border-blue-200',
    content: {
      English: {
        name: 'Amoxicillin + Potassium Clavulanate',
        genericName: 'Amoxicillin and Clavulanate Potassium',
        brandNames: ['Moxikind-CV 625', 'Augmentin 625', 'Clavam 625', 'Mox 500'],
        categoryName: 'Penicillin Antibiotic & Beta-lactamase Inhibitor',
        description: 'Amoxicillin with Clavulanate is a potent broad-spectrum prescription antibiotic combination effective against complex bacterial infections resistant to simple penicillins.',
        uses: [
          'Middle ear and sinus bacterial infections (Otitis media, Sinusitis)',
          'Lower respiratory tract infections (Pneumonia, Bronchitis)',
          'Dental abscesses and post-tooth extraction infections',
          'Urinary tract infections (UTI) and skin wound infections'
        ],
        howItWorks: 'Amoxicillin destroys bacterial cell walls while Clavulanic acid blocks beta-lactamase enzymes produced by bacteria to resist penicillin.',
        recommendedDosage: '625 mg (500mg Amoxicillin + 125mg Clavulanate) twice daily for 5 to 7 days as prescribed by a physician.',
        howToTake: 'Take immediately before or at the start of a meal to enhance absorption and reduce stomach upset.',
        foodRelation: 'Best taken AT THE START OF A MEAL.',
        missedDoseAdvice: 'Take as soon as remembered with food.',
        overdoseInformation: 'Can cause severe diarrhea, electrolyte imbalance, or kidney problems. Seek immediate care.',
        commonSideEffects: ['Diarrhea / loose motions', 'Nausea and vomiting', 'Skin rash or itching', 'Thrush (fungal infection)'],
        seriousSideEffects: ['Severe Penicillin allergic reaction (Anaphylaxis, lip/throat swelling)', 'Cholestatic jaundice (liver enzyme spike)'],
        warningsPrecautions: [
          'NEVER take if you have a known history of Penicillin or Cephalosporin allergy.',
          'Complete the full prescribed course.'
        ],
        pregnancyInfo: 'Category B. Generally safe during pregnancy if prescribed by your physician.',
        breastfeedingInfo: 'Passes into breast milk in small amounts; may cause diarrhea in infant.',
        drivingWarning: 'Does not affect driving.',
        alcoholInteraction: 'Avoid alcohol as it worsens gastrointestinal irritation.',
        drugInteractions: ['Allopurinol', 'Oral Contraceptive Pills (may reduce efficiency)', 'Warfarin'],
        storageInstructions: 'Store below 25°C away from humidity.',
        faqs: [
          {
            question: 'Why does Augmentin / Moxikind CV cause diarrhea?',
            answer: 'Amoxicillin-clavulanate kills beneficial gut bacteria along with bad bacteria. Taking probiotics or curd can help restore gut balance.'
          }
        ]
      },
      Hindi: {
        name: 'एमोक्सिसिलिन (Moxikind-CV 625 / Clavam)',
        genericName: 'एमोक्सिसिलिन + क्लेवुलेनिक एसिड (Amoxicillin + Clavulanate)',
        brandNames: ['मोक्सीकाइंड-सीवी 625 (Moxikind-CV)', 'क्लेवम 625 (Clavam)', 'ऑगमेंटिन 625 (Augmentin)'],
        categoryName: 'पेनिसिलिन एंटीबायोटिक दवा',
        description: 'यह एक बहुत ही शक्तिशाली एंटीबायोटिक दवा है जिसका उपयोग दांतों के इन्फेक्शन, कान, गले, फेफड़ों और घावों में हुए बैक्टीरियल इंफेक्शन को ठीक करने के लिए किया जाता है।',
        uses: [
          'दांतों के दर्द और मसूड़ों का इंफेक्शन (Dental Infection)',
          'कान, गले और फेफड़ों का संक्रमण (निमोनिया, ब्रोंकाइटिस)',
          'त्वचा के घाव और यूटीआई (UTI) इंफेक्शन'
        ],
        howItWorks: 'एमोक्सिसिलिन बैक्टीरिया की दीवार को तोड़ती है और क्लेवुलेनिक एसिड बैक्टीरिया के बचाव तंत्र को खत्म करता है।',
        recommendedDosage: '625 mg दिन में 2 बार (सुबह-शाम) 5 से 7 दिनों के लिए (डॉक्टर के पर्चे पर)।',
        howToTake: 'खाना खाने के शुरुआत में या तुरंत बाद लें।',
        foodRelation: 'भोजन के साथ लें (पेट दर्द से बचने के लिए)।',
        missedDoseAdvice: 'याद आने पर भोजन के साथ लें।',
        overdoseInformation: 'गंभीर दस्त हो सकते हैं, तुरंत डॉक्टर के पास जाएं।',
        commonSideEffects: ['दस्त होना', 'उल्टी या मिचली', 'त्वचा पर लाल दाने'],
        seriousSideEffects: ['पेनिसिलिन एलर्जी (सांस फूलना, चेहरे पर सूजन)'],
        warningsPrecautions: [
          'यदि आपको पेनिसिलिन (Penicillin) से एलर्जी है तो यह दवा कभी न लें।',
          'कोर्स पूरा करें।'
        ],
        pregnancyInfo: 'डॉक्टर की सलाह पर गर्भावस्था में सुरक्षित है।',
        breastfeedingInfo: 'डॉक्टर की सलाह आवश्यक है।',
        drivingWarning: 'सुरक्षित।',
        alcoholInteraction: 'शराब से बचें।',
        drugInteractions: ['गर्भनिरोधक गोलियां', 'वारफारिन'],
        storageInstructions: '25°C से कम तापमान पर रखें।',
        faqs: [
          {
            question: 'क्या पेनिसिलिन एलर्जी वाले मरीज यह दवा ले सकते हैं?',
            answer: 'बिल्कुल नहीं! पेनिसिलिन एलर्जी वाले मरीजों के लिए यह दवा खतरनाक हो सकती है।'
          }
        ]
      },
      Marathi: {
        name: 'एमॉक्सिसिलिन (Moxikind-CV 625 / Clavam)',
        genericName: 'एमॉक्सिसिलिन (Amoxicillin + Clavulanate)',
        brandNames: ['मोक्सिकाइंड-सीव्ही ६२५', 'क्लॅव्हम ६२५', 'ऑगमेंटिन ६२५'],
        categoryName: 'एंटीबायोटिक औषध',
        description: 'एमॉक्सिसिलिन हे दात, कान, घसा आणि फुफ्फुसांच्या गंभीर बॅक्टेरियल इन्फेक्शनवर वापरले जाणारे शक्तिशाली अँटीबायोटिक आहे.',
        uses: [
          'दातांचे इन्फेक्शन व सुजलेले हिरडे',
          'कान, घसा आणि छातीचे इन्फेक्शन'
        ],
        howItWorks: 'हे बॅक्टेरिया नष्ट करते.',
        recommendedDosage: '६२५ mg दिवसातून २ वेळा जेवणासोबत (५-७ दिवस).',
        howToTake: 'जेवणाच्या सुरुवातीला पाण्यासोबत घ्यावे.',
        foodRelation: 'जेवणासोबतच घ्यावे.',
        missedDoseAdvice: 'आठवताच जेवणासोबत घ्यावे.',
        overdoseInformation: 'डॉक्टरांकडे जावे.',
        commonSideEffects: ['जुलाब', 'मळमळ', 'अंगावर पुरळ'],
        seriousSideEffects: ['पेनिसिलिन ॲलर्जी'],
        warningsPrecautions: ['पेनिसिलिन ॲलर्जी असल्यास अजिबात घेऊ नये.'],
        pregnancyInfo: 'डॉक्टरांच्या सल्ल्याने घ्यावे.',
        breastfeedingInfo: 'डॉक्टरांचा सल्ला आवश्यक.',
        drivingWarning: 'सुरक्षित.',
        alcoholInteraction: 'दारू टाळावी.',
        drugInteractions: ['गर्भनिरोधक गोळ्या'],
        storageInstructions: 'कोरड्या जागी ठेवावे.',
        faqs: [
          {
            question: 'ऑगमेंटिनमुळे जुलाब का होतात?',
            answer: 'अँटीबायोटिकमुळे पोटातील चांगले बॅक्टेरिया देखील कमी होतात, त्यामुळे दही किंवा प्रोबायोटिक्स घ्यावेत.'
          }
        ]
      }
    }
  },

  // 11. Neosporin (Antibiotic Ointment)
  {
    id: 'neosporin',
    category: 'Antibiotic Ointments',
    categoryIcon: 'ShieldPlus',
    bgGradient: 'from-emerald-600 to-teal-800',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-800 border-emerald-200',
    content: {
      English: {
        name: 'Neomycin + Polymyxin B + Bacitracin',
        genericName: 'Neomycin, Polymyxin B Sulfate & Bacitracin Zinc Ointment',
        brandNames: ['Neosporin Ointment', 'Neosporin Powder', 'Nebasulf', 'Bactroban (Mupirocin)'],
        categoryName: 'Triple Antibiotic Ointment (First Aid)',
        description: 'Neosporin is a first-aid triple antibiotic ointment used to prevent bacterial infection in minor cuts, scrapes, scratches, and light burn wounds.',
        uses: [
          'Prevention of bacterial infection in minor cuts, grazes, and abrasions',
          'First-aid care for minor thermal burn injuries',
          'Post-minor skin procedure infection prevention'
        ],
        howItWorks: 'Combines 3 distinct antibiotics: Neomycin and Bacitracin inhibit bacterial wall and protein synthesis, while Polymyxin B disrupts bacterial cell membranes.',
        recommendedDosage: 'Apply a small amount (equal to fingertip size) to cleaned affected area 1 to 3 times daily.',
        howToTake: 'Clean and dry wound area gently before applying. May cover with sterile bandage.',
        foodRelation: 'Topical application only.',
        missedDoseAdvice: 'Apply when remembered.',
        overdoseInformation: 'Topical overdose is non-toxic.',
        commonSideEffects: ['Mild skin itching or redness at application site'],
        seriousSideEffects: ['Neomycin contact allergic reaction (redness, itching, rash worsening)'],
        warningsPrecautions: [
          'FOR EXTERNAL TOPICAL USE ONLY. Do not apply over large body areas or deep puncture wounds.',
          'Do not use in eyes or ears.'
        ],
        pregnancyInfo: 'Safe for small minor cuts during pregnancy.',
        breastfeedingInfo: 'Safe for topical use.',
        drivingWarning: 'No impact.',
        alcoholInteraction: 'No interaction.',
        drugInteractions: ['None reported'],
        storageInstructions: 'Store below 25°C. Do not freeze.',
        faqs: [
          {
            question: 'Can Neosporin be applied on open wounds?',
            answer: 'Neosporin is designed for minor cuts and scrapes. Deep, gaping, or heavily bleeding wounds require doctor evaluation.'
          }
        ]
      },
      Hindi: {
        name: 'नियोस्पोरिन (Neosporin Ointment / Powder)',
        genericName: 'नियोमाइसिन + पॉ Polymyxin B + बैसिट्रासिन',
        brandNames: ['नियोस्पोरिन ऑइंटमेंट (Neosporin)', 'नेबासल्फ पाउडर (Nebasulf)', 'मुपिरोसिन (Mupirocin)'],
        categoryName: 'एंटीबायोटिक मरहम (फर्स्ट एड मलहम)',
        description: 'नियोस्पोरिन छोटी खरोंच, कट, घाव और मामूली जलने की चोट में बैक्टीरिया का इन्फेक्शन होने से रोकने वाली सबसे लोकप्रिय फर्स्ट-एड क्रीम/मलहम है।',
        uses: [
          'छोटी खरोंच, कट और घाव में इंफेक्शन रोकना',
          'मामूली जलने की चोट का प्राथमिक उपचार (First Aid)'
        ],
        howItWorks: 'यह 3 एंटीबायोटिक्स का मिश्रण है जो घाव पर बैक्टीरिया को पनपने नहीं देता।',
        recommendedDosage: 'घाव को साफ करके दिन में 1 से 3 बार पतली परत लगाएं।',
        howToTake: 'केवल घाव की जगह पर लगाएं और पट्टी बांधें।',
        foodRelation: 'लागू नहीं।',
        missedDoseAdvice: 'याद आते ही लगाएं।',
        overdoseInformation: 'कोई खतरा नहीं।',
        commonSideEffects: ['हल्की खुजली या लाली'],
        seriousSideEffects: ['नियोमाइसिन से त्वचा एलर्जी होना'],
        warningsPrecautions: ['केवल बाहरी त्वचा के लिए। आंख या गहरे घाव में न लगाएं।'],
        pregnancyInfo: 'छोटे घाव पर लगाना सुरक्षित है।',
        breastfeedingInfo: 'सुरक्षित है।',
        drivingWarning: 'सुरक्षित।',
        alcoholInteraction: 'कोई प्रभाव नहीं।',
        drugInteractions: ['कोई नहीं'],
        storageInstructions: '25°C से कम तापमान पर रखें।',
        faqs: [
          {
            question: 'क्या नियोस्पोरिन जलने पर लगा सकते हैं?',
            answer: 'हां, मामूली जलने की चोट पर इन्फेक्शन रोकने के लिए नियोस्पोरिन लगाई जा सकती है।'
          }
        ]
      },
      Marathi: {
        name: 'नियोस्पोरिन (Neosporin Ointment)',
        genericName: 'नियोमायसिन व पॉलिमिक्सिन',
        brandNames: ['नियोस्पोरिन मलहम (Neosporin)', 'नेबासल्फ पावडर'],
        categoryName: 'अँटीबायोटिक मलम (First Aid)',
        description: 'नियोस्पोरिन हे लहान-सहान जखमा, खरचटणे आणि भाजण्यावर बॅक्टेरियल इन्फेक्शन रोखणारे मलम आहे.',
        uses: [
          'जखमा व खरचटण्यावर इन्फेक्शन रोखणे',
          'भाजल्यावर प्रथमोपचार'
        ],
        howItWorks: 'हे बॅक्टेरिया नष्ट करते.',
        recommendedDosage: 'जखम स्वच्छ करून दिवसातून १-३ वेळा लावावे.',
        howToTake: 'त्वचेवर बाह्य वापरासाठी.',
        foodRelation: 'लागू नाही.',
        missedDoseAdvice: 'आठवताच लावावे.',
        overdoseInformation: 'काही नाही.',
        commonSideEffects: ['हळूवार खाज'],
        seriousSideEffects: ['ॲलर्जी'],
        warningsPrecautions: ['फक्त बाह्य वापरासाठी.'],
        pregnancyInfo: 'सुरक्षित.',
        breastfeedingInfo: 'सुरक्षित.',
        drivingWarning: 'सुरक्षित.',
        alcoholInteraction: 'नाही.',
        drugInteractions: ['नाही'],
        storageInstructions: 'थंड जागी ठेवावे.',
        faqs: [
          {
            question: 'नियोस्पोरिन जखमेवर कशी लावावी?',
            answer: 'जखम स्वच्छ पाण्याने धुवून वाळवावी व मलम लावून पट्टी बांधावी.'
          }
        ]
      }
    }
  },

  // 12. Vitamin D3 (Vitamins)
  {
    id: 'vitamind3',
    category: 'Vitamins & Supplements',
    categoryIcon: 'Sparkles',
    bgGradient: 'from-amber-400 to-yellow-600',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-800 border-amber-200',
    content: {
      English: {
        name: 'Vitamin D3 (Cholecalciferol)',
        genericName: 'Cholecalciferol (Vitamin D3)',
        brandNames: ['Uprise-D3 60K', 'Tayo 60K', 'D-Rise 60K', 'Calcirol Sachet'],
        categoryName: 'Fat-Soluble Vitamin & Bone Mineralizer',
        description: 'Vitamin D3 (Cholecalciferol) is essential for calcium absorption in the gut, maintaining strong bones and teeth, supporting muscle function, and boosting immune system health.',
        uses: [
          'Treatment and prevention of Vitamin D deficiency',
          'Management of Osteoporosis and weak, brittle bones',
          'Support for muscle weakness and fatigue related to low Vitamin D',
          'Immune system support'
        ],
        howItWorks: 'Cholecalciferol is converted in the liver and kidneys into calcitriol (active Vitamin D), which stimulates intestinal absorption of calcium and phosphorus.',
        recommendedDosage: 'For severe deficiency: 60,000 IU (60K) ONCE A WEEK for 8 weeks, followed by monthly maintenance dose as directed by doctor.',
        howToTake: 'Take capsule or sachet dissolved in milk/water once weekly after a main fatty meal.',
        foodRelation: 'Must be taken WITH A MEAL CONTAINING FATS (milk, butter, ghee, meal) for optimal fat-soluble absorption.',
        missedDoseAdvice: 'Take the missed weekly dose as soon as remembered. Do not take two 60K doses on the same day.',
        overdoseInformation: 'Toxicity (Hypercalcemia) can cause kidney stones, confusion, nausea, and calcium deposits in arteries. Do not take daily 60K doses!',
        commonSideEffects: ['Rare at standard doses'],
        seriousSideEffects: ['Hypercalcemia (vomiting, extreme thirst, confusion, frequent urination due to excessive blood calcium)'],
        warningsPrecautions: [
          'WARNING: 60,000 IU doses are WEEKLY, NOT DAILY. Taking 60K daily causes severe calcium poisoning.',
          'Check blood 25-hydroxy Vitamin D levels periodically.'
        ],
        pregnancyInfo: 'Safe and routinely prescribed during pregnancy under doctor guidance.',
        breastfeedingInfo: 'Safe and recommended during lactation.',
        drivingWarning: 'No impact.',
        alcoholInteraction: 'Excessive alcohol impairs Vitamin D metabolism in liver.',
        drugInteractions: ['Thiazide diuretics', 'Orlistat (weight loss drug)', 'Steroids'],
        storageInstructions: 'Store below 25°C away from moisture.',
        faqs: [
          {
            question: 'Why is Vitamin D3 60K taken only once a week?',
            answer: '60,000 IU is a high therapeutic dose that gets stored in body fat and released gradually over 7 days.'
          }
        ]
      },
      Hindi: {
        name: 'विटामिन डी3 (Uprise-D3 60K / Calcirol)',
        genericName: 'कोलेकैल्सीफेरॉल (Vitamin D3)',
        brandNames: ['अपराइज़-डी3 60K (Uprise-D3)', 'तैयो 60K (Tayo)', 'कैल्सीरॉल (Calcirol Sachet)'],
        categoryName: 'विटामिन डी3 और हड्डियों की ताकत की दवा',
        description: 'विटामिन डी3 शरीर में कैल्शियम को अवशोषित करने, हड्डियों को मजबूत बनाने, जोड़ों के दर्द को दूर करने और रोग प्रतिरोधक क्षमता (Immunity) बढ़ाने के लिए आवश्यक है।',
        uses: [
          'विटामिन डी की कमी का इलाज',
          'हड्डियों और जोड़ों का दर्द दूर करना (ऑस्टियोपोरोसिस)',
          'थकान और मांसपेशियों की कमजोरी दूर करना'
        ],
        howItWorks: 'यह आंतों में भोजन से कैल्शियम और फास्फोरस सोखने में मदद करता है।',
        recommendedDosage: '60,000 IU (60K) का कैप्सूल या पाउच **हफ्ते में केवल 1 बार** (8 हफ्तों के लिए, डॉक्टर के निर्देशानुसार)।',
        howToTake: 'दूध या भारी भोजन के बाद हफ्ते में एक निश्चित दिन लें।',
        foodRelation: 'दूध या भोजन के साथ लें (फैट के साथ बेहतर अवशोषण होता है)।',
        missedDoseAdvice: 'याद आने पर लें। एक ही दिन 2 कैप्सूल न खाएं।',
        overdoseInformation: '60K कैप्सूल रोज खाने पर शरीर में कैल्शियम बहुत बढ़ सकता है जो खतरनाक है।',
        commonSideEffects: ['सामान्य खुराक में कोई नहीं'],
        seriousSideEffects: ['हाइपरकैल्सीमिया (खून में अत्यधिक कैल्शियम से उल्टी, गुर्दे में पथरी)'],
        warningsPrecautions: [
          'सावधान: 60,000 IU की गोली हफ्ते में केवल 1 बार ही ली जाती है, रोज नहीं!',
          'नियमित जांच कराएं।'
        ],
        pregnancyInfo: 'गर्भावस्था में डॉक्टर की सलाह पर जरूरी है।',
        breastfeedingInfo: 'स्तनपान में सुरक्षित है।',
        drivingWarning: 'सुरक्षित।',
        alcoholInteraction: 'शराब से बचें।',
        drugInteractions: ['स्टेरॉयड'],
        storageInstructions: 'सूखी जगह पर रोशनी से बचाकर रखें।',
        faqs: [
          {
            question: 'विटामिन डी3 60K हफ्ते में एक बार ही क्यों खाते हैं?',
            answer: 'यह एक हाई-डोज कैप्सूल है जो शरीर की चर्बी में जमा होकर पूरे हफ्ते धीरे-धीरे असर देता है।'
          }
        ]
      },
      Marathi: {
        name: 'व्हिटॅमिन डी३ (Uprise-D3 60K)',
        genericName: 'कोलेकॅल्सिफेरॉल (Vitamin D3)',
        brandNames: ['अपराईज-डी३ ६०K (Uprise-D3)', 'कॅल्सिरॉल साशे (Calcirol)'],
        categoryName: 'हाडांच्या मजबुतीसाठी व्हिटॅमिन',
        description: 'व्हिटॅमिन D3 हे शरीरात कॅल्शियम शोषून घेण्यासाठी, हाडे बळकट करण्यासाठी आणि थकवा दूर करण्यासाठी अत्यंत आवश्यक व्हिटॅमिन आहे.',
        uses: [
          'व्हिटॅमिन D3 ची कमतरता भरून काढणे',
          'हाडे व सांधेदुखीवर आराम'
        ],
        howItWorks: 'हे कॅल्शियम शोषून घेण्यास मदत करते.',
        recommendedDosage: '६०,००० IU (60K) चे पाकीट किंवा कॅप्सूल **आठवड्यातून फक्त १ वेळा** (दुधासोबत).',
        howToTake: 'जेवणानंतर दुधासोबत आठवड्यातून एकदा घ्यावे.',
        foodRelation: 'दुधासोबत/जेवणानंतर घेणे आवश्यक.',
        missedDoseAdvice: 'आठवताच घ्यावे.',
        overdoseInformation: 'रोज ६०K घेतल्यास कॅल्शियम विषबाधा होऊ शकते.',
        commonSideEffects: ['काही नाही'],
        seriousSideEffects: ['रक्तातील कॅल्शियम अतिप्रमाणात वाढणे'],
        warningsPrecautions: ['६०K डोस आठवड्यातून फक्त एकदाच घ्यावा, रोज घेऊ नये!'],
        pregnancyInfo: 'सुरक्षित.',
        breastfeedingInfo: 'सुरक्षित.',
        drivingWarning: 'सुरक्षित.',
        alcoholInteraction: 'नाही.',
        drugInteractions: ['नाही'],
        storageInstructions: 'कोरड्या जागी ठेवावे.',
        faqs: [
          {
            question: 'व्हिटॅमिन D3 दुधासोबतच का घ्यावे?',
            answer: 'व्हिटॅमिन D3 हे स्निग्ध पदार्थांत (Fat) विरघळणारे असल्याने दुधासोबत घेतल्यास ते शरीरात पूर्णपणे शोषले जाते.'
          }
        ]
      }
    }
  }
];
