// Core data model for the FormulaVerse formula library.
// Keeping data (this file + class8.ts/class9.ts/class10.ts) separate from UI
// components keeps the app fast and easy to extend.

export type ClassLevel = 8 | 9 | 10;
export type Subject = "Mathematics" | "Physics" | "Chemistry";

/** The two school boards FormulaVerse supports. "Both" is used for the
 *  interactive formula library, since fundamental Math/Physics/Chemistry
 *  relationships (e.g. speed = distance/time, area of a circle) are common
 *  to both boards' curricula even though chapter organisation differs. */
export type Board = "CBSE" | "ICSE";
export type BoardFilter = Board | "Both";

/** Honesty labels for every chapter in the syllabus master list — see
 *  src/data/syllabus.ts. Never claim "Official" without a genuinely
 *  verified, cited source. */
export type SyllabusStatus = "Official" | "Additional" | "Enrichment" | "Unverified";

export interface FormulaVariable {
  symbol: string;
  meaning: string;
  unit?: string;
}

export interface VariableInput {
  symbol: string;
  label: string;
  min: number;
  max: number;
  step: number;
  default: number;
  unit?: string;
}

export interface ComputedResult {
  label: string;
  value: number;
  unit?: string;
  precision?: number;
}

export interface InteractiveConfig {
  inputs: VariableInput[];
  compute: (values: Record<string, number>) => ComputedResult[];
  steps?: (values: Record<string, number>, results: ComputedResult[]) => string[];
}

export type VisualizationKind =
  | "circle"
  | "rect-square"
  | "triangle"
  | "parallelogram"
  | "trapezium"
  | "rhombus"
  | "polygon"
  | "identity-square"
  | "solid3d"
  | "linear-graph"
  | "quadratic-graph"
  | "inverse-graph"
  | "coordinate-geometry"
  | "number-line"
  | "ap-sequence"
  | "trig-circle"
  | "heights-distances"
  | "motion"
  | "ohms-law"
  | "resistance-combo"
  | "mirror-lens"
  | "refraction"
  | "sound-wave"
  | "density"
  | "stats"
  | "probability"
  | "mole"
  | "interest-growth"
  | "percentage-bar"
  | "sdt-triangle"
  | "valency"
  | "reaction-explorer"
  | "calculator";

export interface VisualMeta {
  kind: VisualizationKind;
  shape?: string; // discriminator for solid3d (cube/cuboid/cylinder/cone/sphere/hemisphere/frustum)
  mode?: string; // extra discriminator used by several flexible renderers
}

export interface PracticeQuestion {
  question: string;
  answer: string;
}

export interface Formula {
  id: string;
  classLevel: ClassLevel;
  subject: Subject;
  chapter: string;
  topic: string;
  name: string;
  expression: string;
  variables: FormulaVariable[];
  units?: string;
  explanation: string;
  example: string;
  commonMistake: string;
  practice: PracticeQuestion[];
  tags?: string[];
  /** Freeform note about board-specific placement/coverage (existing field, unchanged). */
  board?: string;
  /** Which board(s) this interactive formula applies to. Defaults to "Both"
   *  when omitted, since most core Math/Physics/Chemistry relationships are
   *  shared across CBSE and ICSE even though chapter names differ. */
  boards?: BoardFilter;
  visual: VisualMeta;
  interactive: InteractiveConfig;
}
