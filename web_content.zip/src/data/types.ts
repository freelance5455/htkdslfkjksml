export type Evidence = "quran" | "sunnah" | "wording" | "list";

export type Citation = {
  surah: string;
  ayah: string;
  quote: string;
  url: string;
  note?: string;
};

export type DivineName = {
  n: number;
  slug: string;
  ar: string;
  pron: string;
  evidence: Evidence;
  ling: string;
  mean: string;
  simple: string;
  deep: string;
  cite?: Citation;
  heart: string;
  practice: string[];
  reflect: string;
  themes: string[];
  related: number[];
  sources: string[];
  dua?: { text: string; note: string };
};

export const EVIDENCE_LABEL: Record<Evidence, string> = {
  quran: "ورد الاسم في القرآن",
  sunnah: "ورد في دعاء ثابت عن النبي ﷺ",
  wording: "المعنى ثابت في الوحي، وصيغة الاسم في السرد المشهور",
  list: "في السرد التعليمي المختلف في ثبوته",
};

export const REVIEW_NOTE =
  "الشروح التعليمية هنا مبنية على المعاني المشهورة في كتب الأسماء الحسنى، وهي صياغة هذه المنصة لا نقلًا حرفيًا عن عالم بعينه. تحتاج مراجعة متخصص قبل أي اعتماد رسمي.";
