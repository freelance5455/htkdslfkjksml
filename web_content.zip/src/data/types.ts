export type Skill =
  | "reading"
  | "speaking"
  | "language"
  | "writing"
  | "study"
  | "fun";

export type Vocab = {
  word: string;
  pos?: string;
  meaning: string;
  urdu: string;
  synonyms: string[];
  antonyms: string[];
  sentences: string[];
};

export type Mcq = {
  kind: "mcq";
  q: string;
  options: string[];
  answer: number;
};

export type Tf = { kind: "tf"; q: string; answer: boolean };

export type Fill = {
  kind: "fill";
  q: string;
  answers: string[];
  hint?: string;
};

export type Match = {
  kind: "match";
  q?: string;
  pairs: { left: string; right: string }[];
};

export type Classify = {
  kind: "classify";
  q: string;
  buckets: string[];
  cards: { text: string; bucket: number }[];
};

export type OpenQ = { kind: "open"; q: string; model?: string };

export type Question = Mcq | Tf | Fill | Match | Classify | OpenQ;

export type Block =
  | { type: "h"; text: string }
  | { type: "p"; text: string }
  | { type: "poem"; lines: string[] }
  | { type: "list"; ordered?: boolean; items: string[] }
  | { type: "note"; text: string }
  | { type: "dialogue"; lines: { who: string; text: string }[] }
  | { type: "callout"; title?: string; text: string }
  | { type: "table"; caption?: string; headers: string[]; rows: string[][] }
  | { type: "exercise"; title: string; instruction?: string; items: Question[] }
  | { type: "words"; intro?: string; words: string[] };

export type Lesson = {
  id: string;
  code: string;
  title: string;
  subtitle?: string;
  kind: Skill;
  blocks: Block[];
};

export type Learn = { skill: string; points: string[] };

export type Unit = {
  id: string;
  number: number;
  title: string;
  learn: Learn[];
  lessons: Lesson[];
  vocab: Vocab[];
};
