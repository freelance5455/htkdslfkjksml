export type LangMode = 'both' | 'en' | 'hi';

export interface BiText {
  en: string;
  hi: string;
}

export type SectionId =
  | 'home'
  | 'atoz'
  | 'pipes'
  | 'fittings'
  | 'supply_dwv'
  | 'bathroom_kitchen'
  | 'jointing'
  | 'diagrams'
  | 'calculators'
  | 'pumps_tanks'
  | 'testing_repair'
  | 'dubai_site'
  | 'building_phases'
  | 'tools'
  | 'safety'
  | 'media_lessons'
  | 'vocabulary'
  | 'interview_quiz'
  | 'boq'
  | 'ai_assistant';

export interface CategoryTile {
  id: SectionId;
  title: BiText;
  subtitle: BiText;
  topicNumber: string;
  group: 'core' | 'field' | 'tools' | 'career';
}
