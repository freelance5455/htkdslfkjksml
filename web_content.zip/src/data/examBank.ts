import type { Question } from '../types';

export interface PracticeExam {
  id: string;
  subjectId: string;
  title: string;
  questions: Question[];
}

type TopicRange = { end: number; label: string };
const topicRanges: Record<string, TopicRange[]> = {
  math: [
    { end: 2, label: 'النهايات' }, { end: 5, label: 'الاشتقاق وتطبيقاته' }, { end: 7, label: 'التكامل' },
    { end: 8, label: 'دراسة الدوال' }, { end: 10, label: 'النهايات والاستمرار' },
  ],
  physics: [
    { end: 1, label: 'الحركة المستقيمة' }, { end: 3, label: 'قوانين نيوتن والسقوط الحر' }, { end: 4, label: 'الطاقة الحركية' },
    { end: 5, label: 'قانون كولون' }, { end: 6, label: 'الدارة الكهربائية وقانون أوم' }, { end: 8, label: 'المكثفات والسعة' },
    { end: 9, label: 'الفعل ورد الفعل' }, { end: 10, label: 'منحنى السرعة والزمن' },
  ],
  chemistry: [
    { end: 1, label: 'الأعداد الكمّية' }, { end: 2, label: 'التوزيع الإلكتروني' }, { end: 3, label: 'الروابط الكيميائية' },
    { end: 5, label: 'المول والكتلة المولية' }, { end: 6, label: 'موازنة المعادلات' }, { end: 7, label: 'الأس الهيدروجيني' },
    { end: 8, label: 'تركيز المحاليل والتخفيف' }, { end: 9, label: 'مبدأ باولي والأوربيتالات' }, { end: 10, label: 'المحاليل المنظمة' },
  ],
  biology: [
    { end: 1, label: 'التنفس الخلوي' }, { end: 2, label: 'مكونات الخلية' }, { end: 3, label: 'النقل عبر الأغشية' },
    { end: 5, label: 'الانقسام والوراثة' }, { end: 7, label: 'التعبير الجيني وتركيب البروتين' }, { end: 8, label: 'المناعة الخلطية' },
    { end: 9, label: 'العبور والتنوع الوراثي' }, { end: 10, label: 'الهندسة الوراثية' },
  ],
  arabic: [
    { end: 2, label: 'الصور البيانية والاستعارة' }, { end: 4, label: 'الممنوع من الصرف' }, { end: 6, label: 'الأساليب البلاغية' },
    { end: 7, label: 'القافية والروي' }, { end: 8, label: 'بناء المقالة' }, { end: 9, label: 'التشبيه' }, { end: 10, label: 'الكتابة العروضية' },
  ],
  english: [
    { end: 1, label: 'Present simple' }, { end: 2, label: 'Past continuous' }, { end: 3, label: 'Present perfect: for/since' },
    { end: 4, label: 'Third conditional' }, { end: 5, label: 'Passive voice' }, { end: 6, label: 'Collocations' },
    { end: 7, label: 'Reading comprehension' }, { end: 8, label: 'Linking words' }, { end: 9, label: 'Present perfect' }, { end: 10, label: 'Passive voice' },
  ],
  french: [
    { end: 1, label: 'Expression du but' }, { end: 2, label: 'Subjonctif' }, { end: 4, label: 'Les temps du passé' },
    { end: 5, label: 'Voix passive' }, { end: 6, label: 'Pronoms personnels' }, { end: 7, label: 'Compréhension écrite' },
    { end: 8, label: 'Connecteurs logiques' }, { end: 9, label: 'Subjonctif' }, { end: 10, label: 'Accord du participe passé' },
  ],
  religion: [
    { end: 1, label: 'العقيدة الإسلامية' }, { end: 3, label: 'الإيمان بالغيب' }, { end: 5, label: 'أحكام المعاملات' },
    { end: 6, label: 'الشورى' }, { end: 7, label: 'العدل' }, { end: 8, label: 'الرحمة والقيادة' }, { end: 10, label: 'العقيدة وأثرها السلوكي' },
  ],
};

function topicForQuestion(id: string): string | undefined {
  const [, subjectId, number] = id.split('-');
  const index = Number(number);
  if (!subjectId || !Number.isInteger(index)) return undefined;
  return topicRanges[subjectId]?.find((range: TopicRange) => index <= range.end)?.label;
}

const mcq = (
  id: string,
  text: string,
  options: string[],
  answerIndex: number,
  explanation: string,
): Question => ({ id, type: 'mcq', text, options, answerIndex, explanation, topic: topicForQuestion(id) });

const tf = (id: string, text: string, answerBool: boolean, explanation: string): Question => ({
  id,
  type: 'tf',
  text,
  answerBool,
  explanation,
  topic: topicForQuestion(id),
});

export const practiceExams: PracticeExam[] = [
  {
    id: 'exam-math',
    subjectId: 'math',
    title: 'امتحان تدريبي شامل — الرياضيات',
    questions: [
      mcq('exam-math-01', 'قيمة النهاية lim(x→3) (x²−9)/(x−3) هي:', ['3', '6', '9', 'غير موجودة'], 1, 'نحلّل x²−9 إلى (x−3)(x+3)، فتكون النهاية 3+3=6.'),
      mcq('exam-math-02', 'نهاية (2x²+1)/(x²−4) عندما x→∞ تساوي:', ['0', '1', '2', '∞'], 2, 'في كسر كثيرتي حدود من الدرجة نفسها، تساوي النهاية نسبة معاملي الحدين الأعلى درجة: 2/1.'),
      mcq('exam-math-03', 'إذا كان f(x)=x³−2x، فما قيمة f′(1)؟', ['−1', '1', '3', '5'], 1, 'f′(x)=3x²−2، ومنه f′(1)=3−2=1.'),
      mcq('exam-math-04', 'إذا كانت f′(x)=2x−4، ففي أي مجال يكون f متناقصاً؟', ['x<2', 'x>2', 'x≠2', 'على ℝ كلها'], 0, 'تكون المشتقة سالبة عندما 2x−4<0، أي عندما x<2.'),
      mcq('exam-math-05', 'معادلة المماس للمنحنى y=x² عند النقطة التي فاصلتها 1 هي:', ['y=x+1', 'y=2x−1', 'y=2x+1', 'y=x²−1'], 1, 'قيمة الدالة 1 وميل المماس f′(1)=2؛ لذا y−1=2(x−1)، أي y=2x−1.'),
      mcq('exam-math-06', 'قيمة التكامل غير المحدد ∫3x² dx هي:', ['3x³+C', 'x³+C', '6x+C', 'x²+C'], 1, 'لأن مشتقة x³ تساوي 3x²، فالتكامل هو x³+C.'),
      mcq('exam-math-07', 'قيمة التكامل المحدد ∫ من 0 إلى 2 لـ x dx هي:', ['1', '2', '3', '4'], 1, 'المكاملة x²/2، وبالتعويض بين 0 و2 نحصل على 2.'),
      mcq('exam-math-08', 'للدالة f(x)=x²−4x، تقع نقطة القيمة الصغرى عند:', ['x=−2', 'x=0', 'x=2', 'x=4'], 2, 'نحل f′(x)=2x−4=0 فنجد x=2، ومعامل x² موجب فتكون قيمة صغرى.'),
      tf('exam-math-09', 'يمكن أن توجد نهاية تابع عند عدد مع أن التابع غير معرّف عند ذلك العدد.', true, 'النهاية تصف سلوك التابع قرب العدد، ولا تشترط أن تكون له قيمة عنده.'),
      tf('exam-math-10', 'إذا اختلفت النهاية اليمنى عن النهاية اليسرى عند نقطة، فالنهاية عندها موجودة.', false, 'وجود النهاية يتطلب تساوي النهايتين الجانبيتين.'),
    ],
  },
  {
    id: 'exam-physics',
    subjectId: 'physics',
    title: 'امتحان تدريبي شامل — الفيزياء',
    questions: [
      mcq('exam-physics-01', 'تحرك جسم بسرعة ثابتة 5 m/s مدة 4 s في خط مستقيم. ما إزاحته؟', ['1.25 m', '9 m', '20 m', '25 m'], 2, 'في الحركة المستقيمة المنتظمة Δx=vt=5×4=20 m.'),
      mcq('exam-physics-02', 'كتلة جسم 3 kg والقوة المحصلة المؤثرة فيه 12 N. ما تعجيله؟', ['0.25 m/s²', '4 m/s²', '9 m/s²', '36 m/s²'], 1, 'من قانون نيوتن الثاني a=F/m=12/3=4 m/s².'),
      mcq('exam-physics-03', 'سقط جسم من السكون مدة 2 s. إذا اعتُمد g=10 m/s²، فما مقدار سرعته النهائية؟', ['5 m/s', '10 m/s', '20 m/s', '40 m/s'], 2, 'من v=v₀+gt، السرعة 0+10×2=20 m/s.'),
      mcq('exam-physics-04', 'ما الطاقة الحركية لجسم كتلته 2 kg وسرعته 3 m/s؟', ['3 J', '6 J', '9 J', '18 J'], 2, 'Eₖ=½mv²=½×2×3²=9 J.'),
      mcq('exam-physics-05', 'إذا تضاعفت المسافة بين شحنتين نقطيتين، تصبح قوة كولون بينهما:', ['ضعف قيمتها', 'نصف قيمتها', 'ربع قيمتها', 'أربعة أمثالها'], 2, 'قوة كولون تتناسب عكسياً مع مربع المسافة، لذلك تصبح ربع قيمتها.'),
      mcq('exam-physics-06', 'يمر تيار في مقاومة 4 Ω موصولة بفرق كمون 12 V. شدة التيار هي:', ['0.33 A', '3 A', '8 A', '48 A'], 1, 'من قانون أوم I=V/R=12/4=3 A.'),
      mcq('exam-physics-07', 'مكثفان سعتهما 2 μF و3 μF وصلا على التوازي. السعة المكافئة هي:', ['1 μF', '1.2 μF', '5 μF', '6 μF'], 2, 'في التوازي تُجمع السعات: C المكافئة=2+3=5 μF.'),
      mcq('exam-physics-08', 'شحنة مقدارها 10 μC خُزّنت في مكثف فرق كمونه 5 V. سعة المكثف:', ['0.5 μF', '2 μF', '15 μF', '50 μF'], 1, 'C=Q/V=10 μC/5 V=2 μF.'),
      tf('exam-physics-09', 'قوتا الفعل ورد الفعل تؤثران في جسمين مختلفين.', true, 'كل قوة في الزوج تؤثر في أحد الجسمين المتفاعلين، وتساوي الأخرى مقداراً وتعاكسها اتجاهاً.'),
      tf('exam-physics-10', 'مساحة المنطقة تحت منحنى السرعة-الزمن تمثل الإزاحة.', true, 'الإزاحة تساوي تكامل السرعة بالنسبة إلى الزمن، وتمثلها المساحة الجبرية تحت المنحنى.'),
    ],
  },
  {
    id: 'exam-chemistry',
    subjectId: 'chemistry',
    title: 'امتحان تدريبي شامل — الكيمياء',
    questions: [
      mcq('exam-chemistry-01', 'أي عدد كمّي يحدد شكل الأوربيتال؟', ['n', 'l', 'mₗ', 'mₛ'], 1, 'العدد الكمّي الثانوي l يحدد شكل الأوربيتال ونوعه الفرعي.'),
      mcq('exam-chemistry-02', 'التوزيع الإلكتروني المبسط لذرة الصوديوم (Z=11) هو:', ['2، 8، 1', '2، 7، 2', '2، 8، 2', '2، 6، 3'], 0, 'توزع الإلكترونات الأحد عشر على الأغلفة 2 ثم 8 ثم 1.'),
      mcq('exam-chemistry-03', 'ما نوع الرابطة بين ذرتي الهيدروجين والكلور في جزيء HCl؟', ['أيونية', 'تكافؤية قطبية', 'تكافؤية غير قطبية', 'فلزية'], 1, 'تتشارك الذرتان بالإلكترونات، لكن تفاوت الكهروسلبية يجعل المشاركة غير متكافئة.'),
      mcq('exam-chemistry-04', 'الكتلة المولية للماء H₂O، مع H=1 وO=16 g/mol، تساوي:', ['16 g/mol', '17 g/mol', '18 g/mol', '20 g/mol'], 2, 'M(H₂O)=2×1+16=18 g/mol.'),
      mcq('exam-chemistry-05', 'كم مولاً في 18 g من الماء؟', ['0.5 mol', '1 mol', '2 mol', '18 mol'], 1, 'n=m/M=18 g ÷ 18 g/mol=1 mol.'),
      mcq('exam-chemistry-06', 'ما المعادلة الموزونة لتفاعل الهيدروجين مع الأكسجين لتكوين الماء؟', ['H₂+O₂→H₂O', '2H₂+O₂→2H₂O', 'H₂+2O₂→H₂O', '2H₂+2O₂→H₂O'], 1, 'على الطرفين أربع ذرات H وذرتا O في المعادلة 2H₂+O₂→2H₂O.'),
      mcq('exam-chemistry-07', 'إذا كان [H⁺]=10⁻⁴ M، فإن pH يساوي:', ['−4', '4', '10', '14'], 1, 'pH=−log₁₀[H⁺]=−log₁₀(10⁻⁴)=4.'),
      mcq('exam-chemistry-08', 'خُفف 50 mL من محلول تركيزه 1.0 M إلى حجم نهائي 250 mL. ما تركيزه النهائي؟', ['0.10 M', '0.20 M', '1.25 M', '5.0 M'], 1, 'باستخدام C₁V₁=C₂V₂، C₂=(1.0×50)/250=0.20 M.'),
      tf('exam-chemistry-09', 'يستوعب الأوربيتال الواحد إلكترونين كحد أقصى، ويكون لهما لفّان مغزليان متعاكسان.', true, 'هذا متوافق مع مبدأ استبعاد باولي للحالات الكمومية.'),
      tf('exam-chemistry-10', 'يقاوم المحلول المنظّم التغير الكبير في pH عند إضافة كمية صغيرة من حمض أو أساس.', true, 'يحتوي المنظّم على زوج حمض/أساس مترافق يخفف أثر الإضافة الصغيرة.'),
    ],
  },
  {
    id: 'exam-biology',
    subjectId: 'biology',
    title: 'امتحان تدريبي شامل — علوم الحياة',
    questions: [
      mcq('exam-biology-01', 'أي عضية ترتبط أساساً بإنتاج ATP خلال التنفس الخلوي؟', ['الريبوزوم', 'الميتوكوندريا', 'جهاز غولجي', 'الليسوسوم'], 1, 'تجري المراحل الرئيسة من التنفس الخلوي في الميتوكوندريا، وينتج عنها ATP.'),
      mcq('exam-biology-02', 'ما الذي يميز الخلية النباتية عادةً عن الخلية الحيوانية؟', ['وجود جدار خلوي وبلاستيدات خضراء', 'غياب الغشاء البلازمي', 'غياب المادة الوراثية', 'وجود نواة في النبات فقط'], 0, 'للخلية النباتية جدار خلوي وبلاستيدات خضراء، إضافة إلى مكونات خلوية مشتركة.'),
      mcq('exam-biology-03', 'انتقال جزيئات الماء عبر غشاء شبه منفذ نحو منطقة أعلى تركيزاً بالمذاب يسمى:', ['الانتشار الميسر', 'التناضح', 'النقل الفعال', 'البلعمة'], 1, 'التناضح هو انتقال الماء عبر غشاء شبه منفذ استجابةً لاختلاف تركيز المذاب.'),
      mcq('exam-biology-04', 'ما الغاية الأساسية من الانقسام المنصف؟', ['إنتاج خلايا جسدية مطابقة', 'إنتاج أمشاج بنصف عدد الصبغيات', 'زيادة حجم الخلية', 'نسخ البروتينات'], 1, 'يخفض الانقسام المنصف عدد الصبغيات إلى النصف لتكوين الأمشاج.'),
      mcq('exam-biology-05', 'في تزاوج Aa × Aa مع سيادة تامة، ما النسبة الظاهرية المتوقعة؟', ['1:1', '3:1', '1:2:1', '9:3:3:1'], 1, 'تنتج الأنماط الجينية 1AA:2Aa:1aa، وتكون النسبة الظاهرية 3 سائد إلى 1 متنحٍ.'),
      mcq('exam-biology-06', 'أي نوع من RNA ينقل الشيفرة الوراثية من DNA إلى الريبوزوم؟', ['mRNA', 'tRNA', 'rRNA', 'miRNA فقط'], 0, 'يحمل RNA الرسول mRNA نسخة الشيفرة اللازمة لتركيب البروتين إلى الريبوزوم.'),
      mcq('exam-biology-07', 'ما الدور المباشر للريبوزوم في التعبير الجيني؟', ['تضاعف DNA', 'ترجمة mRNA إلى سلسلة ببتيدية', 'إنتاج الأجسام المضادة', 'تكوين الغشاء الخلوي'], 1, 'يقرأ الريبوزوم شفرات mRNA ويربط الأحماض الأمينية لتكوين البروتين.'),
      mcq('exam-biology-08', 'أي مكوّن يرتبط بالمناعة الخلطية المكتسبة؟', ['الأجسام المضادة التي تنتجها الخلايا البائية', 'الجدار الخلوي النباتي', 'الهيموغلوبين', 'إنزيمات الهضم فقط'], 0, 'تنتج الخلايا البائية أجساماً مضادة نوعية تسهم في الاستجابة المناعية الخلطية.'),
      tf('exam-biology-09', 'تزيد عملية العبور الوراثي في الانقسام المنصف من التنوع الوراثي للأمشاج.', true, 'يسمح العبور بتبادل مقاطع بين صبغيات متماثلة فتتكون تراكيب أليلية جديدة.'),
      tf('exam-biology-10', 'تتعرف أنزيمات القطع على مواقع محددة في DNA وتقطعه عندها أو قربها.', true, 'تتميز أنزيمات القطع التعرفية بتتابعات هدف محددة، لذلك تستخدم في الهندسة الوراثية.'),
    ],
  },
  {
    id: 'exam-arabic',
    subjectId: 'arabic',
    title: 'امتحان تدريبي شامل — اللغة العربية',
    questions: [
      mcq('exam-arabic-01', 'في العبارة «العلمُ نورٌ»، الصورة البيانية هي:', ['تشبيه مرسل مفصل', 'تشبيه مؤكد مجمل', 'تشبيه بليغ', 'استعارة مكنية'], 2, 'حُذفت أداة التشبيه ووجه الشبه، وبقي المشبه والمشبه به؛ فهو تشبيه بليغ.'),
      mcq('exam-arabic-02', 'في قولنا «ابتسم الصباحُ»، الصورة البيانية هي:', ['استعارة مكنية', 'استعارة تصريحية', 'كناية عن صفة', 'تشبيه مرسل'], 0, 'شُبّه الصباح بإنسان، وحُذف المشبه به وأُبقيت صفة من صفاته، وهي الابتسام.'),
      mcq('exam-arabic-03', 'سبب منع كلمة «مصابيح» من الصرف هو أنها:', ['علم أعجمي', 'صفة على وزن أفعل', 'صيغة منتهى الجموع', 'مضافة إلى ضمير'], 2, '«مصابيح» على صيغة منتهى الجموع، وهي من أسباب منع الاسم من الصرف.'),
      mcq('exam-arabic-04', 'ما علامة جر الاسم الممنوع من الصرف إذا لم يُضف ولم يُعرّف بـ«أل»؟', ['الضمة', 'الفتحة نيابةً عن الكسرة', 'الكسرة دائماً', 'السكون'], 1, 'يُجر الممنوع من الصرف بالفتحة نيابةً عن الكسرة ما لم يُضف أو يُعرّف بـ«أل».'),
      mcq('exam-arabic-05', 'في الجملة «لا تهملْ واجبك»، نوع الأسلوب هو:', ['أمر', 'نهي', 'استفهام', 'نداء'], 1, '«لا» الناهية دخلت على الفعل المضارع «تهملْ»، فأنشأت أسلوب نهي.'),
      mcq('exam-arabic-06', 'في قولنا «ألا تحافظ على وقتك؟»، الغرض الأقرب للاستفهام في سياق النصح هو:', ['التقرير أو الحث', 'التمني', 'التعجب', 'الندبة'], 0, 'قد يخرج الاستفهام عن طلب المعلومة إلى التقرير أو الحث بحسب السياق.'),
      mcq('exam-arabic-07', 'حرف الروي في القصيدة هو:', ['أول حرف في البيت', 'الحرف الذي تُبنى عليه القافية وتُنسب إليه القصيدة', 'كل حروف المد', 'آخر كلمة في الصدر'], 1, 'الروي حرف أصلي تلتزمه القصيدة في أبياتها وتُنسب القافية إليه.'),
      mcq('exam-arabic-08', 'أي ترتيب أنسب لبناء مقالة مترابطة؟', ['خاتمة، أمثلة، عنوان', 'مقدمة، عرض منظم، خاتمة', 'أمثلة فقط ثم مقدمة', 'عرض بلا فكرة رئيسة'], 1, 'تقدم المقالة فكرتها في مقدمة، وتناقشها في عرض منظم، ثم تلخصها في خاتمة.'),
      tf('exam-arabic-09', 'وجه الشبه هو الصفة المشتركة بين طرفي التشبيه.', true, 'وجه الشبه يوضح الصفة أو المعنى الجامع بين المشبه والمشبه به.'),
      tf('exam-arabic-10', 'تُكتب الكلمات في الكتابة العروضية دائماً كما تُرسم إملائياً، من دون اعتبار للنطق.', false, 'تعتمد الكتابة العروضية على ما يُنطق، لذلك قد تختلف عن الرسم الإملائي المعتاد.'),
    ],
  },
  {
    id: 'exam-english',
    subjectId: 'english',
    title: 'Practice Exam — English Language',
    questions: [
      mcq('exam-english-01', 'Choose the correct form: “She ___ to school every day.”', ['go', 'goes', 'is go', 'gone'], 1, 'The present simple takes -s with the third-person singular subject “she”.'),
      mcq('exam-english-02', 'Complete the sentence: “They ___ TV when I arrived.”', ['watch', 'watched', 'were watching', 'have watched'], 2, 'The past continuous describes an action in progress when another past event occurred.'),
      mcq('exam-english-03', 'Choose the correct sentence.', ['I have lived here since five years.', 'I have lived here for five years.', 'I live here for five years ago.', 'I am living here since five years.'], 1, 'Use “for” with a duration; “since” is used with a starting point.'),
      mcq('exam-english-04', 'Complete the third conditional: “If he had left earlier, he ___ the train.”', ['would catch', 'will catch', 'would have caught', 'caught'], 2, 'The third conditional uses if + past perfect and would have + past participle.'),
      mcq('exam-english-05', 'Choose the correct passive form: “The letters ___ yesterday.”', ['are sent', 'were sent', 'sent', 'have sending'], 1, 'The time marker “yesterday” calls for the past simple passive: was/were + past participle.'),
      mcq('exam-english-06', 'Choose the correct collocation.', ['do a decision', 'make a decision', 'make homework', 'do a promise'], 1, 'The natural collocation is “make a decision”; we say “do homework”.'),
      mcq('exam-english-07', 'Read: “Maya rides her bicycle to work to avoid traffic.” Why does Maya cycle to work?', ['To avoid traffic', 'To buy a bicycle', 'To visit a friend', 'To exercise at work'], 0, 'The sentence directly states that she cycles to avoid traffic.'),
      mcq('exam-english-08', 'Which linking word best completes the sentence? “It was raining; ___, we continued the match.”', ['because', 'however', 'therefore', 'unless'], 1, '“However” introduces a contrast between the rain and continuing the match.'),
      tf('exam-english-09', 'In the present perfect, “has” is used with he, she, and it.', true, 'The present perfect is formed with have/has and a past participle; third-person singular takes “has”.'),
      tf('exam-english-10', 'In a passive sentence, the receiver of the action typically becomes the grammatical subject.', true, 'The passive voice foregrounds the receiver, as in “The report was written by Lina”.'),
    ],
  },
  {
    id: 'exam-french',
    subjectId: 'french',
    title: 'Examen d’entraînement — Français',
    questions: [
      mcq('exam-french-01', 'Complétez : « Je travaille ___ réussir. »', ['pour', 'pour que', 'afin que', 'que'], 0, '« Pour » est suivi de l’infinitif pour exprimer le but lorsque le sujet est le même.'),
      mcq('exam-french-02', 'Complétez : « Il faut que tu ___ tes devoirs. »', ['fais', 'fasses', 'faire', 'feras'], 1, 'Après « il faut que », on emploie le subjonctif : « que tu fasses ».'),
      mcq('exam-french-03', 'Choisissez la phrase correcte au passé composé.', ['Elle est allé au marché.', 'Elle est allée au marché.', 'Elle a allée au marché.', 'Elle aller au marché.'], 1, '« Aller » se conjugue avec être au passé composé, et le participe s’accorde avec « elle ».'),
      mcq('exam-french-04', 'Complétez : « Quand j’étais petit, je ___ souvent au parc. »', ['suis allé', 'irai', 'allais', 'vais'], 2, 'L’imparfait exprime ici une habitude dans le passé.'),
      mcq('exam-french-05', 'Mettez à la voix passive : « Le professeur explique la leçon. »', ['La leçon explique le professeur.', 'La leçon est expliquée par le professeur.', 'La leçon a expliqué le professeur.', 'Le professeur est expliqué par la leçon.'], 1, 'Au présent passif, on emploie être au présent + participe passé accordé avec le sujet.'),
      mcq('exam-french-06', 'Choisissez le bon pronom : « Marie et Léa sont amies. ___ habitent à Damas. »', ['Elle', 'Ils', 'Elles', 'On'], 2, '« Marie et Léa » est un groupe féminin pluriel, remplacé par « elles ».') ,
      mcq('exam-french-07', 'Lisez : « Paul prend le bus parce que sa voiture est en panne. » Pourquoi prend-il le bus ?', ['Parce qu’il est en retard.', 'Parce que sa voiture est en panne.', 'Pour visiter Paul.', 'Parce qu’il pleut.'], 1, 'La phrase indique explicitement que sa voiture est en panne.'),
      mcq('exam-french-08', 'Complétez avec le connecteur logique : « Elle est fatiguée, ___ elle continue à étudier. »', ['donc', 'mais', 'parce que', 'afin de'], 1, '« Mais » marque l’opposition entre la fatigue et la poursuite des études.'),
      tf('exam-french-09', 'Après « pour que », on emploie généralement le subjonctif.', true, 'La locution « pour que » est suivie d’une proposition au subjonctif.'),
      tf('exam-french-10', 'Dans une phrase passive, le participe passé s’accorde toujours avec l’agent introduit par « par ».', false, 'Dans la voix passive, le participe passé s’accorde avec le sujet qui reçoit l’action, non avec le complément d’agent.'),
    ],
  },
  {
    id: 'exam-religion',
    subjectId: 'religion',
    title: 'امتحان تدريبي شامل — التربية الدينية',
    questions: [
      mcq('exam-religion-01', 'المقصود بالعقيدة الإسلامية هو:', ['مجموعة عادات اجتماعية متغيرة فقط', 'ما يؤمن به القلب ويقوم على الدليل', 'الأحكام المالية وحدها', 'الأقوال من دون اعتقاد'], 1, 'العقيدة ما ينعقد عليه القلب من إيمان، وتستند إلى الدليل النقلي والعقلي.'),
      mcq('exam-religion-02', 'أي مثال يعبّر عن الغيب المطلق؟', ['معرفة نتيجة تجربة بعد إجرائها', 'معرفة موعد الساعة', 'رؤية كوكب بالمِرقاب', 'توقع الطقس بأدوات الرصد'], 1, 'الغيب المطلق مما استأثر الله بعلمه، ومن أمثلته وقت قيام الساعة.'),
      mcq('exam-religion-03', 'من آثار الإيمان بالغيب في سلوك الإنسان:', ['المسؤولية ومراقبة الله في السر والعلن', 'ترك العمل والأخذ بالأسباب', 'إيذاء الآخرين', 'إهمال الحقوق'], 0, 'الإيمان بالغيب يعزز استشعار المسؤولية ومراقبة الله، ولا يلغي العمل والأخذ بالأسباب.'),
      mcq('exam-religion-04', 'من الضوابط العامة لصحة البيع:', ['التراضي ووضوح المبيع والثمن', 'إخفاء العيب عن المشتري', 'بيع ما لا يملكه البائع بلا إذن', 'اشتراط الزيادة الربوية'], 0, 'يشترط في المعاملة المشروعة التراضي والعلم بالمبيع والثمن وانتفاء الغش.'),
      mcq('exam-religion-05', 'الربا في المعاملات هو:', ['كل ربح ناتج عن تجارة', 'زيادة محرمة في معاملة ربوية وفق أحكامها', 'أجرة معلومة مقابل خدمة', 'هبة بلا شرط'], 1, 'الربا زيادة محرمة في صور المعاملات التي حددها الشرع، وليس كل ربح تجاري.'),
      mcq('exam-religion-06', 'تعني الشورى في إدارة الشأن العام:', ['الانفراد بالقرار ورفض النصيحة', 'التشاور ومشاركة أهل الرأي في القرار', 'تأجيل كل قرار بلا سبب', 'اتباع رأي الأكثر مالاً دائماً'], 1, 'الشورى تقوم على التشاور والاستفادة من الرأي والخبرة للوصول إلى قرار مسؤول.'),
      mcq('exam-religion-07', 'أي سلوك يجسد العدل في التعامل؟', ['إعطاء كل ذي حق حقه دون محاباة', 'تفضيل القريب ولو ظلمه', 'حرمان الخصم من حقه', 'إخفاء الشهادة'], 0, 'العدل هو إنصاف الناس وإعطاء الحقوق لأصحابها دون محاباة.'),
      mcq('exam-religion-08', 'الرفق والرحمة في القيادة النبوية يدعوان إلى:', ['القسوة في كل موقف', 'حسن معاملة الناس ومراعاة أحوالهم', 'إلغاء المسؤولية', 'ترك النصح مطلقاً'], 1, 'الرحمة تجمع حسن المعاملة والنصح، مع أداء المسؤولية.'),
      tf('exam-religion-09', 'العقيدة الإسلامية تستند إلى الدليل النقلي والعقلي.', true, 'يجتمع في تقرير العقيدة الوحي الصحيح والنظر العقلي السليم.'),
      tf('exam-religion-10', 'الإيمان بالغيب يعني ترك العمل والأخذ بالأسباب.', false, 'الإيمان بالغيب لا يناقض السعي والعمل؛ بل يدعو إلى التوكل مع الأخذ بالأسباب.'),
    ],
  },
];
