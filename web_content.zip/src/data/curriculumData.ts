import { LetterData, WordData, SentenceExercise, ScienceLesson, Story, VideoItem, QuizItem, PlaceValueProblem } from '../types/education';

// 28 Arabic Letters with tashkeel and examples
export const ARABIC_LETTERS: LetterData[] = [
  { letter: 'أ', name: 'أَلِف', transliteration: 'Alif', withFatha: 'أَ', withDamma: 'أُ', withKasra: 'إِ', withSukun: 'أْ', exampleWord: 'أَرْنَبٌ', exampleTashkeel: 'أَ - أَرْنَب', exampleEmoji: '🐇', exampleMeaning: 'حيوان أليف سريع يحب الجزر', color: 'from-rose-500 to-red-600' },
  { letter: 'ب', name: 'بَاء', transliteration: 'Baa', withFatha: 'بَ', withDamma: 'بُ', withKasra: 'بِ', withSukun: 'بْ', exampleWord: 'بَطَّةٌ', exampleTashkeel: 'بَ - بَطَّة', exampleEmoji: '🦆', exampleMeaning: 'طائر يسبح بمهارة في الماء', color: 'from-amber-500 to-orange-600' },
  { letter: 'ت', name: 'تَاء', transliteration: 'Taa', withFatha: 'تَ', withDamma: 'تُ', withKasra: 'تِ', withSukun: 'تْ', exampleWord: 'تُفَّاحَةٌ', exampleTashkeel: 'تُ - تُفَّاحَة', exampleEmoji: '🍎', exampleMeaning: 'فاكهة لذيذة ومفيدة للصحة', color: 'from-red-500 to-rose-600' },
  { letter: 'ث', name: 'ثَاء', transliteration: 'Thaa', withFatha: 'ثَ', withDamma: 'ثُ', withKasra: 'ثِ', withSukun: 'ثْ', exampleWord: 'ثَعْلَبٌ', exampleTashkeel: 'ثَ - ثَعْلَب', exampleEmoji: '🦊', exampleMeaning: 'حيوان بري ذكي وسريع الحركة', color: 'from-orange-500 to-amber-600' },
  { letter: 'ج', name: 'جِيم', transliteration: 'Jeem', withFatha: 'جَ', withDamma: 'جُ', withKasra: 'جِ', withSukun: 'جْ', exampleWord: 'جَمَلٌ', exampleTashkeel: 'جَ - جَمَل', exampleEmoji: '🐪', exampleMeaning: 'سفينة الصحراء يتحمل العطش', color: 'from-emerald-500 to-teal-600' },
  { letter: 'ح', name: 'حَاء', transliteration: 'Haa', withFatha: 'حَ', withDamma: 'حُ', withKasra: 'حِ', withSukun: 'حْ', exampleWord: 'حِصَانٌ', exampleTashkeel: 'حِ - حِصَان', exampleEmoji: '🐎', exampleMeaning: 'حيوان قوي وجميل يحب الركض', color: 'from-teal-500 to-cyan-600' },
  { letter: 'خ', name: 'خَاء', transliteration: 'Khaa', withFatha: 'خَ', withDamma: 'خُ', withKasra: 'خِ', withSukun: 'خْ', exampleWord: 'خَرُوفٌ', exampleTashkeel: 'خَ - خَرُوف', exampleEmoji: '🐑', exampleMeaning: 'حيوان يغطي جسمه الصوف الأبيض', color: 'from-cyan-500 to-sky-600' },
  { letter: 'د', name: 'دَال', transliteration: 'Dal', withFatha: 'دَ', withDamma: 'دُ', withKasra: 'دِ', withSukun: 'دْ', exampleWord: 'دُلْفِينٌ', exampleTashkeel: 'دُ - دُلْفِين', exampleEmoji: '🐬', exampleMeaning: 'صديق الإنسان الذكي في البحر', color: 'from-blue-500 to-indigo-600' },
  { letter: 'ذ', name: 'ذَال', transliteration: 'Thal', withFatha: 'ذَ', withDamma: 'ذُ', withKasra: 'ذِ', withSukun: 'ذْ', exampleWord: 'ذُرَةٌ', exampleTashkeel: 'ذُ - ذُرَة', exampleEmoji: '🌽', exampleMeaning: 'نبات ذهبي ولذيذ يُصنع منه الفشار', color: 'from-yellow-500 to-amber-600' },
  { letter: 'ر', name: 'رَاء', transliteration: 'Raa', withFatha: 'رَ', withDamma: 'رُ', withKasra: 'رِ', withSukun: 'رْ', exampleWord: 'رُمَّانٌ', exampleTashkeel: 'رُ - رُمَّان', exampleEmoji: '🫐', exampleMeaning: 'فاكهة حمراء مليئة بالحبات الياقوتية', color: 'from-pink-500 to-rose-600' },
  { letter: 'ز', name: 'زَاي', transliteration: 'Zay', withFatha: 'زَ', withDamma: 'زُ', withKasra: 'زِ', withSukun: 'زْ', exampleWord: 'زَرَافَةٌ', exampleTashkeel: 'زَ - زَرَافَة', exampleEmoji: '🦒', exampleMeaning: 'أطول كائن حي في البرية برقبة طويلة', color: 'from-lime-500 to-green-600' },
  { letter: 'س', name: 'سِين', transliteration: 'Seen', withFatha: 'سَ', withDamma: 'سُ', withKasra: 'سِ', withSukun: 'سْ', exampleWord: 'سَمَكَةٌ', exampleTashkeel: 'سَ - سَمَكَة', exampleEmoji: '🐟', exampleMeaning: 'تعيش وتسبح في الماء بواسطة الزعانف', color: 'from-sky-500 to-blue-600' },
  { letter: 'ش', name: 'شِين', transliteration: 'Sheen', withFatha: 'شَ', withDamma: 'شُ', withKasra: 'شِ', withSukun: 'شْ', exampleWord: 'شَمْسٌ', exampleTashkeel: 'شَ - شَمْس', exampleEmoji: '☀️', exampleMeaning: 'تضيء كوكبنا وتمنحنا الدفء والنور', color: 'from-amber-400 to-yellow-500' },
  { letter: 'ص', name: 'صَاد', transliteration: 'Saad', withFatha: 'صَ', withDamma: 'صُ', withKasra: 'صِ', withSukun: 'صْ', exampleWord: 'صَقْرٌ', exampleTashkeel: 'صَ - صَقْر', exampleEmoji: '🦅', exampleMeaning: 'طائر جارح ذو بصر ثاقب وطيران قوي', color: 'from-amber-600 to-stone-700' },
  { letter: 'ض', name: 'ضَاد', transliteration: 'Daad', withFatha: 'ضَ', withDamma: 'ضُ', withKasra: 'ضِ', withSukun: 'ضْ', exampleWord: 'ضِفْدَعٌ', exampleTashkeel: 'ضِ - ضِفْدَع', exampleEmoji: '🐸', exampleMeaning: 'برمائي يقفز ببراعة ويسبح في الماء', color: 'from-green-500 to-emerald-700' },
  { letter: 'ط', name: 'طَاء', transliteration: 'Taa', withFatha: 'طَ', withDamma: 'طُ', withKasra: 'طِ', withSukun: 'طْ', exampleWord: 'طَائِرَةٌ', exampleTashkeel: 'طَ - طَائِرَة', exampleEmoji: '✈️', exampleMeaning: 'مركبة تحلق في السماء وتنقل المسافرين', color: 'from-indigo-500 to-violet-600' },
  { letter: 'ظ', name: 'ظَاء', transliteration: 'Dhaa', withFatha: 'ظَ', withDamma: 'ظُ', withKasra: 'ظِ', withSukun: 'ظْ', exampleWord: 'ظَبْيٌ', exampleTashkeel: 'ظَ - ظَبْي', exampleEmoji: '🦌', exampleMeaning: 'غزال رشيق وسريع في الطبيعة', color: 'from-emerald-600 to-teal-700' },
  { letter: 'ع', name: 'عَيْن', transliteration: 'Ayn', withFatha: 'عَ', withDamma: 'عُ', withKasra: 'عِ', withSukun: 'عْ', exampleWord: 'عُصْفُورٌ', exampleTashkeel: 'عُ - عُصْفُور', exampleEmoji: '🐦', exampleMeaning: 'طائر صغير يغرد أجمل الألحان صباحاً', color: 'from-cyan-600 to-blue-700' },
  { letter: 'غ', name: 'غَيْن', transliteration: 'Ghayn', withFatha: 'غَ', withDamma: 'غُ', withKasra: 'غِ', withSukun: 'غْ', exampleWord: 'غَزَالٌ', exampleTashkeel: 'غَ - غَزَال', exampleEmoji: '🦌', exampleMeaning: 'حيوان وديع وجميل يحب العشب', color: 'from-orange-500 to-red-600' },
  { letter: 'ف', name: 'فَاء', transliteration: 'Faa', withFatha: 'فَ', withDamma: 'فُ', withKasra: 'فِ', withSukun: 'فْ', exampleWord: 'فَرَاشَةٌ', exampleTashkeel: 'فَ - فَرَاشَة', exampleEmoji: '🦋', exampleMeaning: 'حشرة رقيقة ذات أجنحة ملونة بديعة', color: 'from-pink-500 to-purple-600' },
  { letter: 'ق', name: 'قَاف', transliteration: 'Qaaf', withFatha: 'قَ', withDamma: 'قُ', withKasra: 'قِ', withSukun: 'قْ', exampleWord: 'قَمَرٌ', exampleTashkeel: 'قَ - قَمَر', exampleEmoji: '🌙', exampleMeaning: 'ينير السماء ليلاً ويغير أشكاله', color: 'from-violet-500 to-purple-700' },
  { letter: 'ك', name: 'كَاف', transliteration: 'Kaaf', withFatha: 'كَ', withDamma: 'كُ', withKasra: 'كِ', withSukun: 'كْ', exampleWord: 'كِتَابٌ', exampleTashkeel: 'كِ - كِتَاب', exampleEmoji: '📖', exampleMeaning: 'خير جليس مليء بالمعارف والقصص', color: 'from-blue-600 to-cyan-700' },
  { letter: 'ل', name: 'لَام', transliteration: 'Laam', withFatha: 'لَ', withDamma: 'لُ', withKasra: 'لِ', withSukun: 'لْ', exampleWord: 'لَيْمُونٌ', exampleTashkeel: 'لَ - لَيْمُون', exampleEmoji: '🍋', exampleMeaning: 'فاكهة حمضية غنية بفيتامين ج', color: 'from-yellow-400 to-lime-500' },
  { letter: 'م', name: 'مِيم', transliteration: 'Meem', withFatha: 'مَ', withDamma: 'مُ', withKasra: 'مِ', withSukun: 'مْ', exampleWord: 'مَوْزٌ', exampleTashkeel: 'مَ - مَوْز', exampleEmoji: '🍌', exampleMeaning: 'فاكهة صفراء لذيذة تمدنا بالطاقة', color: 'from-amber-400 to-orange-500' },
  { letter: 'ن', name: 'نُون', transliteration: 'Noon', withFatha: 'نَ', withDamma: 'نُ', withKasra: 'نِ', withSukun: 'نْ', exampleWord: 'نَحْلَةٌ', exampleTashkeel: 'نَ - نَحْلَة', exampleEmoji: '🐝', exampleMeaning: 'حشرة نشيطة تصنع العسل من رحيق الأزهار', color: 'from-yellow-500 to-amber-600' },
  { letter: 'هـ', name: 'هَاء', transliteration: 'Haa', withFatha: 'هَ', withDamma: 'هُ', withKasra: 'هِ', withSukun: 'هْ', exampleWord: 'هِلَالٌ', exampleTashkeel: 'هـِ - هِلَال', exampleEmoji: '🌛', exampleMeaning: 'بداية ظهور القمر في أول الشهر العربي', color: 'from-teal-400 to-emerald-600' },
  { letter: 'و', name: 'وَاو', transliteration: 'Waw', withFatha: 'وَ', withDamma: 'وُ', withKasra: 'وِ', withSukun: 'وْ', exampleWord: 'وَرْدَةٌ', exampleTashkeel: 'وَ - وَرْدَة', exampleEmoji: '🌹', exampleMeaning: 'زهرة عطرة ذات ألوان زاهية وجميلة', color: 'from-rose-500 to-red-700' },
  { letter: 'ي', name: 'يَاء', transliteration: 'Yaa', withFatha: 'يَ', withDamma: 'يُ', withKasra: 'يِ', withSukun: 'يْ', exampleWord: 'يَدٌ', exampleTashkeel: 'يَ - يَد', exampleEmoji: '✋', exampleMeaning: 'نعمة نكتب بها ونرسم ونساعد أصدقاءنا', color: 'from-purple-500 to-indigo-600' }
];

// Rich Vocabulary Bank
export const VOCABULARY_LIST: WordData[] = [
  // Animals
  { id: 'w1', word: 'أَسَد', tashkeel: 'أَسَدٌ', category: 'animals', categoryAr: 'الحيوانات', emoji: '🦁', meaning: 'ملك الغابة القوي', letters: ['أ', 'س', 'د'], ageGroup: '5-7' },
  { id: 'w2', word: 'فِيل', tashkeel: 'فِيلٌ', category: 'animals', categoryAr: 'الحيوانات', emoji: '🐘', meaning: 'أضخم حيوان يعيش على اليابسة بخرطوم طويل', letters: ['ف', 'ي', 'ل'], ageGroup: '5-7' },
  { id: 'w3', word: 'زَرَافَة', tashkeel: 'زَرَافَةٌ', category: 'animals', categoryAr: 'الحيوانات', emoji: '🦒', meaning: 'أطول الحيوانات وتأكل أوراق الأشجار العالية', letters: ['ز', 'ر', 'ا', 'ف', 'ة'], ageGroup: '5-7' },
  { id: 'w4', word: 'قِطَّة', tashkeel: 'قِطَّةٌ', category: 'animals', categoryAr: 'الحيوانات', emoji: '🐱', meaning: 'حيوان أليف يحب اللعب والنظافة', letters: ['ق', 'ط', 'ة'], ageGroup: '5-7' },
  { id: 'w5', word: 'طَاوُوس', tashkeel: 'طَاوُوسٌ', category: 'animals', categoryAr: 'الحيوانات', emoji: '🦚', meaning: 'طائر جميل يتباهى بريشه الملون الخلاب', letters: ['ط', 'ا', 'و', 'و', 'س'], ageGroup: '8-10' },
  // Fruits
  { id: 'w6', word: 'تُفَّاح', tashkeel: 'تُفَّاحٌ', category: 'fruits', categoryAr: 'الفواكه', emoji: '🍎', meaning: 'فاكهة مقرمشة وغنية بالألياف', letters: ['ت', 'ف', 'ا', 'ح'], ageGroup: '5-7' },
  { id: 'w7', word: 'بُرْتُقَال', tashkeel: 'بُرْتُقَالٌ', category: 'fruits', categoryAr: 'الفواكه', emoji: '🍊', meaning: 'فاكهة شتوية تمدنا بفيتامين C', letters: ['ب', 'ر', 'ت', 'ق', 'ا', 'ل'], ageGroup: '5-7' },
  { id: 'w8', word: 'عِنَب', tashkeel: 'عِنَبٌ', category: 'fruits', categoryAr: 'الفواكه', emoji: '🍇', meaning: 'حبات حلوة تنمو في عناقيد جميلة', letters: ['ع', 'ن', 'ب'], ageGroup: '5-7' },
  { id: 'w9', word: 'فَرَاوْلَة', tashkeel: 'فَرَاوْلَةٌ', category: 'fruits', categoryAr: 'الفواكه', emoji: '🍓', meaning: 'فاكهة حمراء برائحة زكية وبذور على القشرة', letters: ['ف', 'ر', 'ا', 'و', 'ل', 'ة'], ageGroup: '5-7' },
  { id: 'w10', word: 'بِطِّيخ', tashkeel: 'بِطِّيخٌ', category: 'fruits', categoryAr: 'الفواكه', emoji: '🍉', meaning: 'فاكهة صيفية منعشة مليئة بالماء', letters: ['ب', 'ط', 'ي', 'خ'], ageGroup: '8-10' },
  // Nature & Space
  { id: 'w11', word: 'شَمْس', tashkeel: 'شَمْسٌ', category: 'nature', categoryAr: 'الطبيعة والكون', emoji: '☀️', meaning: 'نجم مشتعل يمنح الأرض الضوء والحرارة', letters: ['ش', 'م', 'س'], ageGroup: '5-7' },
  { id: 'w12', word: 'قَمَر', tashkeel: 'قَمَرٌ', category: 'nature', categoryAr: 'الطبيعة والكون', emoji: '🌕', meaning: 'تابع للأرض يعكس نور الشمس في الليل', letters: ['ق', 'م', 'ر'], ageGroup: '5-7' },
  { id: 'w13', word: 'نَجْمَة', tashkeel: 'نَجْمَةٌ', category: 'nature', categoryAr: 'الطبيعة والكون', emoji: '⭐', meaning: 'جرم سماوي يلمع في الفضاء البعيد', letters: ['ن', 'ج', 'م', 'ة'], ageGroup: '5-7' },
  { id: 'w14', word: 'مَطَر', tashkeel: 'مَطَرٌ', category: 'nature', categoryAr: 'الطبيعة والكون', emoji: '🌧️', meaning: 'قطرات ماء تسقط من الغيوم لري الأرض', letters: ['م', 'ط', 'ر'], ageGroup: '5-7' },
  { id: 'w15', word: 'كَوْكَب', tashkeel: 'كَوْكَبٌ', category: 'nature', categoryAr: 'الطبيعة والكون', emoji: '🪐', meaning: 'جرم فضائي يدور حول نجم مثل كوكب الأرض', letters: ['ك', 'و', 'ك', 'ب'], ageGroup: '8-10' },
  // Professions & Knowledge
  { id: 'w16', word: 'مُعَلِّم', tashkeel: 'مُعَلِّمٌ', category: 'professions', categoryAr: 'المهن والعلوم', emoji: '👨‍🏫', meaning: 'ينير عقول الطلاب بالعلم والمعرفة', letters: ['م', 'ع', 'ل', 'م'], ageGroup: '5-7' },
  { id: 'w17', word: 'طَبِيب', tashkeel: 'طَبِيبٌ', category: 'professions', categoryAr: 'المهن والعلوم', emoji: '🩺', meaning: 'يعالج المرضى ويساعدهم على الشفاء', letters: ['ط', 'ب', 'ي', 'ب'], ageGroup: '5-7' },
  { id: 'w18', word: 'مُهَنْدِس', tashkeel: 'مُهَنْدِسٌ', category: 'professions', categoryAr: 'المهن والعلوم', emoji: '👷‍♂️', meaning: 'يصمم ويبني المباني والجسور الجميلة', letters: ['م', 'ه', 'ن', 'د', 'س'], ageGroup: '8-10' },
  { id: 'w19', word: 'رَائِدُ فَضَاء', tashkeel: 'رَائِدُ فَضَاءٍ', category: 'professions', categoryAr: 'المهن والعلوم', emoji: '🧑‍🚀', meaning: 'يسافر في سفينة الفضاء لاكتشاف أسرار الكون', letters: ['ر', 'ا', 'ئ', 'د', 'ف', 'ض', 'ا', 'ء'], ageGroup: '8-10' },
  { id: 'w20', word: 'عَالِم', tashkeel: 'عَالِمٌ', category: 'professions', categoryAr: 'المهن والعلوم', emoji: '🔬', meaning: 'يجري التجارب ويكتشف أدوية واختراعات جديدة', letters: ['ع', 'ا', 'ل', 'م'], ageGroup: '8-10' }
];

// Interactive Sentence Building Exercises
export const SENTENCE_EXERCISES: SentenceExercise[] = [
  {
    id: 's1',
    sentence: 'الشَّمْسُ تُشْرِقُ فِي الصَّبَاحِ',
    words: ['الشَّمْسُ', 'تُشْرِقُ', 'فِي', 'الصَّبَاحِ'],
    scrambledWords: ['فِي', 'الشَّمْسُ', 'الصَّبَاحِ', 'تُشْرِقُ'],
    meaning: 'The sun rises in the morning',
    emoji: '🌅',
    ageGroup: '5-7'
  },
  {
    id: 's2',
    sentence: 'الْوَلَدُ الْمُؤَدَّبُ يُحِبُّ مُسَاعَدَةَ أُمِّهِ',
    words: ['الْوَلَدُ', 'الْمُؤَدَّبُ', 'يُحِبُّ', 'مُسَاعَدَةَ', 'أُمِّهِ'],
    scrambledWords: ['مُسَاعَدَةَ', 'الْوَلَدُ', 'أُمِّهِ', 'يُحِبُّ', 'الْمُؤَدَّبُ'],
    meaning: 'The polite boy loves helping his mother',
    emoji: '👦❤️',
    ageGroup: '5-7'
  },
  {
    id: 's3',
    sentence: 'النَّحْلَةُ تَصْنَعُ الْعَسَلَ اللَّذِيذَ مِنَ الْأَزْهَارِ',
    words: ['النَّحْلَةُ', 'تَصْنَعُ', 'الْعَسَلَ', 'اللَّذِيذَ', 'مِنَ', 'الْأَزْهَارِ'],
    scrambledWords: ['الْعَسَلَ', 'النَّحْلَةُ', 'الْأَزْهَارِ', 'تَصْنَعُ', 'مِنَ', 'اللَّذِيذَ'],
    meaning: 'The bee makes delicious honey from flowers',
    emoji: '🐝🍯',
    ageGroup: '8-10'
  },
  {
    id: 's4',
    sentence: 'الْقِرَاءَةُ تُغَذِّي الْعَقْلَ بِالْمَعْرِفَةِ وَالْحِكْمَةِ',
    words: ['الْقِرَاءَةُ', 'تُغَذِّي', 'الْعَقْلَ', 'بِالْمَعْرِفَةِ', 'وَالْحِكْمَةِ'],
    scrambledWords: ['بِالْمَعْرِفَةِ', 'الْقِرَاءَةُ', 'وَالْحِكْمَةِ', 'الْعَقْلَ', 'تُغَذِّي'],
    meaning: 'Reading nourishes the mind with knowledge',
    emoji: '📚💡',
    ageGroup: '8-10'
  },
  {
    id: 's5',
    sentence: 'تَدُورُ الْأَرْضُ حَوْلَ الشَّمْسِ فِي مَدَارٍ ثَابِتٍ',
    words: ['تَدُورُ', 'الْأَرْضُ', 'حَوْلَ', 'الشَّمْسِ', 'فِي', 'مَدَارٍ'],
    scrambledWords: ['الشَّمْسِ', 'تَدُورُ', 'مَدَارٍ', 'الْأَرْضُ', 'فِي', 'حَوْلَ'],
    meaning: 'Earth rotates around the sun in a fixed orbit',
    emoji: '🌍☀️',
    ageGroup: '8-10'
  }
];

// Place Value interactive exercises (آحاد، عشرات، مئات، آلاف)
export const PLACE_VALUE_PROBLEMS: PlaceValueProblem[] = [
  {
    id: 'pv1',
    number: 345,
    thousands: 0,
    hundreds: 3,
    tens: 4,
    units: 5,
    question: 'في الرقم 345، ما هي القيمة المكانية للرقم 4؟',
    highlightedPlace: 'tens',
    options: [4, 40, 400, 4000],
    correctAnswer: 40,
    explanation: 'الرقم 4 يقع في خانة العشرات، وقيمته هي 4 × 10 = 40'
  },
  {
    id: 'pv2',
    number: 782,
    thousands: 0,
    hundreds: 7,
    tens: 8,
    units: 2,
    question: 'في الرقم 782، ما هي القيمة المكانية للرقم 7؟',
    highlightedPlace: 'hundreds',
    options: [7, 70, 700, 7000],
    correctAnswer: 700,
    explanation: 'الرقم 7 يقع في خانة المئات، وقيمته هي 7 × 100 = 700'
  },
  {
    id: 'pv3',
    number: 4529,
    thousands: 4,
    hundreds: 5,
    tens: 2,
    units: 9,
    question: 'في الرقم 4,529، ما هي القيمة المكانية للرقم 4؟',
    highlightedPlace: 'thousands',
    options: [40, 400, 4000, 4],
    correctAnswer: 4000,
    explanation: 'الرقم 4 يقع في خانة الآلاف، وقيمته هي 4 × 1000 = 4000'
  },
  {
    id: 'pv4',
    number: 168,
    thousands: 0,
    hundreds: 1,
    tens: 6,
    units: 8,
    question: 'في الرقم 168، ما هي القيمة المكانية للرقم 8؟',
    highlightedPlace: 'units',
    options: [8, 80, 800, 88],
    correctAnswer: 8,
    explanation: 'الرقم 8 يقع في خانة الآحاد، وقيمته هي 8'
  },
  {
    id: 'pv5',
    number: 6350,
    thousands: 6,
    hundreds: 3,
    tens: 5,
    units: 0,
    question: 'في الرقم 6,350، ما هي القيمة المكانية للرقم 3؟',
    highlightedPlace: 'hundreds',
    options: [3, 30, 300, 3000],
    correctAnswer: 300,
    explanation: 'الرقم 3 يقع في خانة المئات، وقيمته هي 3 × 100 = 300'
  }
];

// Science Modules
export const SCIENCE_LESSONS: ScienceLesson[] = [
  {
    id: 'sci-space',
    title: 'رحلة إلى الفضاء والنظام الشمسي',
    category: 'space',
    categoryAr: 'الفضاء والكون',
    icon: '🪐',
    coverColor: 'from-indigo-900 to-purple-800 text-white',
    ageGroup: '8-10',
    summary: 'استكشف الشمس والكواكب الثمانية التي تدور حولها في نظامنا الشمسي الرائع!',
    sections: [
      {
        heading: 'الشمس: نجمنا المضيء العظيم',
        text: 'الشمس ليست كوكباً، بل هي نجم ناري هائل الحجم يقع في مركز النظام الشمسي. كل الكواكب تدور حولها وتستمد منها الضوء والدفء الضروريين للحياة.'
      },
      {
        heading: 'كواكب المجموعة الشمسية الثمانية',
        text: 'الكواكب تدور حول الشمس بانتظام عجيب، وهي بالترتيب حسب قربها من الشمس:',
        visualType: 'cards',
        visualItems: [
          { name: 'عُطَارِد', icon: '🪨', desc: 'أقرب كوكب للشمس، سطحه صخري وساخن جداً نهاراً وشديد البرودة ليلاً' },
          { name: 'الزُّهْرَة', icon: '✨', desc: 'ألمع كوكب في سمائنا، ويُلقب بتوأم الأرض لتقارب حجميهما' },
          { name: 'الْأَرْض', icon: '🌍', desc: 'كوكبنا الأزرق الجميل، الكوكب الوحيد المعروف الذي يحتوي على ماء وحياة' },
          { name: 'الْمِرِّيخ', icon: '🔴', desc: 'الكوكب الأحمر، يتميز بلونه الصدئ وجباله الشاهقة' },
          { name: 'الْمُشْتَرِي', icon: '🪐', desc: 'عملاق المجموعة الشمسية وأضخم الكواكب، وله بقعة حمراء شهيرة' },
          { name: 'زُحَل', icon: '💫', desc: 'أجمل الكواكب بحلقاته اللامعة المصنوعة من الجليد والغبار' },
          { name: 'أُورَانُوس', icon: '🧊', desc: 'العملاق الجليدي ذو اللون الأزرق المخضر ويدور على جانبه' },
          { name: 'نِبْتُون', icon: '🌊', desc: 'أبعد الكواكب عن الشمس، لونه أزرق داكن وتعصف به رياح عاتية' }
        ]
      },
      {
        heading: 'القمر رفيق الأرض',
        text: 'القمر يدور حول الأرض مرة كل شهر عربي، ولذلك نراه يتغير من هلال إلى بدر ثم يختفي في المحاق!'
      }
    ],
    interactiveFact: 'هل تعلم؟ يمكن أن تتسع الشمس لأكثر من مليون كوكب بحجم كوكب الأرض!',
    quizQuestion: {
      question: 'ما هو أكبر كواكب المجموعة الشمسية حجماً؟',
      options: ['الأرض', 'المشتري', 'زحل', 'المريخ'],
      correctIndex: 1,
      explanation: 'المشتري هو أضخم كوكب في النظام الشمسي، وكتلته تفوق كتلة باقي الكواكب مجتمعة!'
    }
  },
  {
    id: 'sci-body',
    title: 'عجائب جسم الإنسان والحواس الخمس',
    category: 'body',
    categoryAr: 'جسم الإنسان',
    icon: '🫀',
    coverColor: 'from-rose-600 to-amber-600 text-white',
    ageGroup: '5-7',
    summary: 'تعرّف على كيفية عمل قلبك، عقلك، ورئتيك وكيف تساعدك حواسك الخمس على استكشاف العالم!',
    sections: [
      {
        heading: 'الأعضاء الحيوية الأساسية',
        text: 'يعمل جسمنا كفريق واحد متعاون بلا توقف:',
        visualType: 'cards',
        visualItems: [
          { name: 'الدماغ (المخ)', icon: '🧠', desc: 'القائد والكمبيوتر العبقري الذي يفكر ويتحكم في كل حركات الجسم' },
          { name: 'القلب', icon: '🫀', desc: 'مضخة عضلية قوية تضخ الدم والأكسجين إلى كل خلية في جسدك' },
          { name: 'الرئتان', icon: '🫁', desc: 'تسحبان الهواء النقي وتأخذان الأكسجين وتطردان ثاني أكسيد الكربون' },
          { name: 'المعدة', icon: '🥣', desc: 'تهضم الطعام اللذيذ وتحوله إلى طاقة وقوة لكي تركض وتلعب وتفكر' }
        ]
      },
      {
        heading: 'الحواس الخمس نعم عظيمة',
        text: 'نكتشف العالم من حولنا بخمس حواس مدهشة:',
        visualType: 'cards',
        visualItems: [
          { name: 'البصر (العين)', icon: '👁️', desc: 'نرى بها الألوان والجمال والكتب' },
          { name: 'السمع (الأذن)', icon: '👂', desc: 'نسمع بها أصوات العصافير والقرآن وكلام الأحباب' },
          { name: 'الشم (الأنف)', icon: '👃', desc: 'نشم به رائحة الورود والطعام الشهي' },
          { name: 'التذوق (اللسان)', icon: '👅', desc: 'نميز به الحلو والحامض والمالح' },
          { name: 'اللمس (الجلد واليد)', icon: '✋', desc: 'نشعر به بالحرارة والبرودة ونعومة الأشياء' }
        ]
      }
    ],
    interactiveFact: 'ينبض قلب الإنسان الطبيعي حوالي 100,000 نبضة كل يوم بدون توقف!',
    quizQuestion: {
      question: 'أي عضو في جسمك مسؤول عن ضخ الدم إلى جميع الأعضاء؟',
      options: ['الرئة', 'القلب', 'المعدة', 'العين'],
      correctIndex: 1,
      explanation: 'القلب هو العضلة التي تضخ الدم الغني بالأكسجين لجميع خلايا الجسم!'
    }
  },
  {
    id: 'sci-plants',
    title: 'عالم النباتات وسحر البناء الضوئي',
    category: 'plants',
    categoryAr: 'النباتات والبيئة',
    icon: '🌱',
    coverColor: 'from-emerald-700 to-teal-800 text-white',
    ageGroup: '5-7',
    summary: 'كيف تبدأ الشجرة من بذرة صغيرة؟ وكيف يصنع النبات غذاءه من ضوء الشمس؟',
    sections: [
      {
        heading: 'أجزاء النبات ووظائفها',
        text: 'لكل جزء في النبات وظيفة أساسية:',
        visualType: 'cards',
        visualItems: [
          { name: 'الجذور', icon: '🪴', desc: 'تثبت النبتة في التربة وتمتص الماء والأملاح المعدنية' },
          { name: 'الساق', icon: '🪵', desc: 'يحمل الأوراق والأزهار وينقل الماء من الجذور إلى أعلى' },
          { name: 'الأوراق', icon: '🍃', desc: 'المصنع الأخضر الصغير الذي يصنع الغذاء بضوء الشمس (البناء الضوئي)' },
          { name: 'الأزهار والثمار', icon: '🌸', desc: 'تنتج البذور اللذيذة لتنمو منها نباتات جديدة' }
        ]
      },
      {
        heading: 'ماذا يحتاج النبات ليعيش؟',
        text: 'يحتاج النبات إلى أربعة أشياء أساسية: ضوء الشمس، الماء النقي، الهواء (ثاني أكسيد الكربون)، والتربة الخصبة.'
      }
    ],
    interactiveFact: 'النباتات تأخذ ثاني أكسيد الكربون من الهواء وتعطينا الأكسجين النقي لنتنفسه!',
    quizQuestion: {
      question: 'أي جزء من النبات يمتص الماء من التربة؟',
      options: ['الأوراق', 'الجذور', 'الساق', 'الزهرة'],
      correctIndex: 1,
      explanation: 'الجذور تمتد تحت الأرض لتمتص الماء والغذاء من التربة!'
    }
  },
  {
    id: 'sci-matter',
    title: 'حالات المادة الثلاث: صلب، سائل، غاز',
    category: 'matter',
    categoryAr: 'الفيزياء والمادة',
    icon: '🧊',
    coverColor: 'from-cyan-600 to-blue-800 text-white',
    ageGroup: '8-10',
    summary: 'كل شيء حولنا هو مادة! تعرّف كيف يتحول الثلج إلى ماء ثم إلى بخار!',
    sections: [
      {
        heading: 'الحالات الثلاث الرائعة',
        text: 'المادة توجد في الطبيعة بثلاث حالات رئيسية:',
        visualType: 'cards',
        visualItems: [
          { name: 'الحالة الصلبة', icon: '🧱', desc: 'لها شكل ثابت وحجم ثابت، مثل الحجر والمكتب ومكعب الثلج' },
          { name: 'الحالة السائلة', icon: '💧', desc: 'لها حجم محدد لكن تأخذ شكل الإناء الذي توضع فيه، مثل الماء والحليب والعصير' },
          { name: 'الحالة الغازية', icon: '💨', desc: 'ليس لها شكل محدد وتنتشر لملء أي مكان، مثل الهواء وبخار الماء' }
        ]
      },
      {
        heading: 'التحولات الممتعة',
        text: 'إذا سخّنا مكعب الثلج الصلب (انصهار) يتحول إلى ماء سائل، وإذا غلينا الماء يتحول إلى بخار غازي (تبخر)!'
      }
    ],
    interactiveFact: 'الماء هو المادة الوحيدة على الأرض التي توجد طبيعياً في الحالات الثلاث: ثلج وماء وبخار!',
    quizQuestion: {
      question: 'عندما يتجمد الماء السائل، يتحول إلى أي حالة؟',
      options: ['غازية', 'صلبة', 'سائلة', 'بلازما'],
      correctIndex: 1,
      explanation: 'التجمد يحول الماء السائل إلى جليد صلب ذي شكل محدد!'
    }
  },
  {
    id: 'sci-experiments',
    title: 'تجربة الطفو والغرق وكثافة المواد',
    category: 'experiments',
    categoryAr: 'تجارب علمية ممتعة',
    icon: '🧪',
    coverColor: 'from-amber-600 to-emerald-600 text-white',
    ageGroup: '5-7',
    summary: 'لماذا تطفو السفينة العملاقة بينما تغرق العملة المعدنية الصغيرة في الماء؟',
    sections: [
      {
        heading: 'سر الطفو والغرق: الكثافة',
        text: 'الأجسام التي تكون كثافتها أقل من الماء تطفو على السطح، بينما الأجسام التي تكون كثافتها أعلى تغوص وتغرق في القاع.'
      },
      {
        heading: 'أمثلة عملية يمكنك تجربتها في المنزل',
        text: 'جرّب وضع حوض ماء واختبر:',
        visualType: 'cards',
        visualItems: [
          { name: 'قطعة خشب أو تفاحة', icon: '🪵', desc: 'تطفو على سطح الماء لأن كثافتها خفيفة وفيها جيوب هواء' },
          { name: 'حجر أو عملة معدنية', icon: '🪙', desc: 'تغوص سريعاً إلى القاع لأن المادة ثقيلة وكثيفة جداً' },
          { name: 'قارب ورقي', icon: '⛵', desc: 'يطفو لأن شكله يحبس الهواء في الداخل ويزيح كمية كافية من الماء' }
        ]
      }
    ],
    interactiveFact: 'السفن الفولاذية الضخمة تطفو لأنها مجوفة من الداخل ومليئة بالهواء الخفيف!',
    quizQuestion: {
      question: 'إذا وضعت قطعة خشب جافة في حوض ماء، فماذا يحدث لها؟',
      options: ['تغوص وتغرق في القاع', 'تطفو على السطح', 'تذوب فوراً', 'تتبخر'],
      correctIndex: 1,
      explanation: 'الخشب يطفو لأن كثافته أقل من كثافة الماء ويحتوي على مسامات هوائية!'
    }
  }
];

// Interactive Children Stories
export const STORIES_LIST: Story[] = [
  {
    id: 'story-turtle',
    title: 'الْأَرْنَبُ السَّرِيعُ وَالسُّلَحْفَاةُ الصَّبُورَةُ',
    category: 'الأخلاق والإصرار',
    ageGroup: '5-7',
    moral: 'الْعَزِيمَةُ وَالصَّبْرُ وَالْعَمَلُ الْمُسْتَمِرُّ يُحَقِّقُونَ النَّجَاحَ دَائِماً، وَالْغُرُورُ يَجْلِبُ الْخَسَارَةَ.',
    coverEmoji: '🐢🐇',
    pages: [
      {
        text: 'فِي غَابَةٍ خَضْرَاءَ جَمِيلَةٍ، كَانَ هُنَاكَ أَرْنَبٌ مَغْرُورٌ اسْمُهُ "سَرِيعٌ". كَانَ يَفْتَخِرُ دَائِماً بِسُرْعَتِهِ أَمَامَ جَمِيعِ الْحَيَوَانَاتِ وَيَقُولُ: "أَنَا أَسْرَعُ كَائِنٍ فِي الْغَابَةِ، لَا أَحَدَ يَسْتَطِيعُ التَّغَلُّبَ عَلَيَّ!".',
        audioNarration: 'في غابة خضراء جميلة، كان هناك أرنب مغرور اسمه سريع. كان يفتخر دائماً بسرعته أمام جميع الحيوانات.',
        illustration: 'غابة جميلة والأرنب المغرور يقفز',
        sceneEmoji: '🌲🐇🌲'
      },
      {
        text: 'تَقَدَّمَتِ السُّلَحْفَاةُ الطَّيِّبَةُ "حَكِيمَةُ" بِهُدُوءٍ وَقَالَتْ لَهُ: "أَنَا أَتَحَدَّاكَ فِي سِبَاقٍ إِلَى قِمَّةِ التَّلَّةِ يَا سَرِيعُ!". ضَحِكَ الْأَرْنَبُ بِصَوْتٍ عَالٍ وَقَالَ: "أَنْتِ يَا بَطِيئَةُ؟! حَسَناً، سَنَرَى مَنْ سَيَفُوزُ!".',
        audioNarration: 'تقدمت السلحفاة الطيبة حكيمة بهدوء وقالت له: أنا أتحداك في سباق إلى قمة التلة يا سريع.',
        illustration: 'السلحفاة تتحدى الأرنب بحكمة وهدوء',
        sceneEmoji: '🐢💬🐇'
      },
      {
        text: 'بَدَأَ السِّبَاقُ! انْطَلَقَ الْأَرْنَبُ كَالْبَرْقِ، بَيْنَمَا مَشَتِ السُّلَحْفَاةُ خُطْوَةً بِخُطْوَةٍ بِدُونِ تَوَقُّفٍ. عِنْدَمَا وَصَلَ الْأَرْنَبُ إِلَى نِصْفِ الطَّرِيقِ، نَظَرَ خَلْفَهُ فَلَمْ يَجِدِ السُّلَحْفَاةَ، فَقَالَ: "سَأَنَامُ قَلِيلاً تَحْتَ هَذِهِ الشَّجَرَةِ الظَّلِيلَةِ، فَهِيَ بَعِيدَةٌ جِدّاً!".',
        audioNarration: 'بدأ السباق! انطلق الأرنب كالبرق، بينما مشت السلحفاة خطوة بخطوة. ونام الأرنب تحت الشجرة الظليلة.',
        illustration: 'الأرنب نائم والسلحفاة تواصل المشي بعزم',
        sceneEmoji: '🌳💤🐢➡️'
      },
      {
        text: 'غَطَّ الْأَرْنَبُ فِي نَوْمٍ عَمِيقٍ. وَفِي هَذِهِ الْأَثْنَاءِ، وَاصَلَتِ السُّلَحْفَاةُ السَّيْرَ بِصَبْرٍ وَثَبَاتٍ دُونَ كَلَلٍ أَوْ مَلَلٍ، حَتَّى تَجَاوَزَتِ الْأَرْنَبَ النَّائِمَ وَاقْتَرَبَتْ مِنْ خَطِّ النِّهَايَةِ!',
        audioNarration: 'غط الأرنب في نوم عميق، وواصلت السلحفاة السير بصبر وثبات حتى اقتربت من خط النهاية.',
        illustration: 'السلحفاة تتجاوز الأرنب النائم',
        sceneEmoji: '🐢🏁🐇💤'
      },
      {
        text: 'اسْتَيْقَظَ الْأَرْنَبُ مَذْعُوراً وَرَكَضَ بِأَقْصَى سُرْعَتِهِ، لَكِنْ كَانَ الْأَوَانُ قَدْ فَاتَ! وَصَلَتِ السُّلَحْفَاةُ أَوَّلاً وَصَفَّقَتْ لَهَا كُلُّ حَيَوَانَاتِ الْغَابَةِ. تَعَلَّمَ الْأَرْنَبُ أَنَّ الصَّبْرَ وَالْعَمَلَ الْجَادَّ أَفْضَلُ مِنَ الْغُرُورِ.',
        audioNarration: 'استيقظ الأرنب مذعوراً، لكن السلحفاة فازت بالسباق! تعلم الأرنب درساً ثميناً أن العمل الجاد ينتصر دائماً.',
        illustration: 'السلحفاة تحمل كأس الفوز والحيوانات تحتفل',
        sceneEmoji: '🏆🐢🎉👏'
      }
    ],
    questions: [
      {
        question: 'لِمَاذَا خَسِرَ الْأَرْنَبُ السِّبَاقَ فِي النِّهَايَةِ؟',
        options: ['لأنه كان أعرج', 'لأنه نام مغروراً تحت الشجرة وتكاسل', 'لأنه ضل الطريق في الغابة'],
        correctIndex: 1,
        rewardStars: 3
      },
      {
        question: 'مَا الْعِبْرَةُ الَّتِي تَعَلَّمْنَاهَا مِنْ هَذِهِ الْقِصَّةِ؟',
        options: ['النوم مفيد قبل السباق', 'الغرور يؤدي للخسارة، والصبر والمثابرة يجلبان النجاح', 'السرعة هي أهم شيء في الحياة'],
        correctIndex: 1,
        rewardStars: 3
      }
    ]
  },
  {
    id: 'story-water-drop',
    title: 'مُغَامَرَةُ قَطْرَةِ الْمَاءِ "نَدَى"',
    category: 'العلوم والبيئة',
    ageGroup: '8-10',
    moral: 'الْمَاءُ سِرُّ الْحَيَاةِ، وَدَوْرَةُ الْمَاءِ مُعْجِزَةٌ طَبِيعِيَّةٌ تُعِيدُ إِحْيَاءَ الْأَرْضِ.',
    coverEmoji: '💧☁️🌈',
    pages: [
      {
        text: 'فِي يَوْمٍ مُشْمِسٍ، كَانَتْ قَطْرَةُ الْمَاءِ اللَّامِعَةُ "نَدَى" تَلْعَبُ فَوْقَ أَمْوَاجِ الْبَحْرِ الْأَزْرَقِ الْكَبِيرِ. دَاعَبَتْهَا أَشِعَّةُ الشَّمْسِ الدَّافِئَةِ، فَشَعَرَتْ بِخِفَّةٍ شَدِيدَةٍ وَبَدَأَتْ تَتَبَخَّرُ صَاعِدَةً نَحْوَ السَّمَاءِ الْعَالِيَةِ!',
        audioNarration: 'في يوم مشمس، كانت قطرة الماء ندى تلعب فوق أمواج البحر، ثم بدأت تتبخر صاعدة نحو السماء.',
        illustration: 'قطرة ماء تتبخر مبتسمة نحو السماء',
        sceneEmoji: '🌊☀️💧⬆️'
      },
      {
        text: 'عِنْدَمَا ارْتَفَعَتْ "نَدَى" فِي السَّمَاءِ الْبَارِدَةِ، الْتَقَتْ بِصَدِيقَاتِهَا الْقَطَرَاتِ الْأُخْرَيَاتِ، وَتَجَمَّعْنَ مَعاً لِيُكَوِّنَّ غَيْمَةً بَيْضَاءَ قُطْنِيَّةً جَمِيلَةً تُسَافِرُ مَعَ نَسَمَاتِ الرِّيَاحِ فَوْقَ الْجِبَالِ وَالْحُقُولِ.',
        audioNarration: 'التقت ندى بصديقاتها وتجمعن ليكوّنّ غيمة بيضاء جميلة تسافر مع الرياح فوق الحقول.',
        illustration: 'غيوم بيضاء لطيفة مع قطرات متجمعة',
        sceneEmoji: '☁️💧💧💨'
      },
      {
        text: 'فَجْأَةً، مَرَّتِ الْغَيْمَةُ بِهَوَاءِ بَارِدٍ جِدّاً فَوْقَ حَدِيقَةٍ ذَابِلَةٍ، فَقَالَتْ "نَدَى": "انْظُرْنَ إِلَى تِلْكَ الْأَزْهَارِ الْعَطْشَى، هَيَّا بِنَا نَنْزِلُ لِنَسْقِيَهَا!". تَكَثَّفَتِ الْقَطَرَاتُ وَهَطَلَ الْمَطَرُ الْمُنْعِشُ فَرِحاً.',
        audioNarration: 'مرت الغيمة بهواء بارد، فقررت القطرات الهطول مطراً لطيفاً ليسقي الأزهار العطشى.',
        illustration: 'أمطار منعشة تسقط على حديقة ورود',
        sceneEmoji: '🌧️🌸🌱'
      },
      {
        text: 'هَبَطَتْ "نَدَى" بِرِقَّةٍ عَلَى وَرْدَةٍ حَمْرَاءَ جَمِيلَةٍ، فَارْتَوَتِ الْوَرْدَةُ وَفَتَحَتْ أَوْرَاقَهَا وَقَالَتْ: "شُكْراً لَكِ يَا نَدَى، لَقَدْ أَعَدْتِ لِيَ الْحَيَاةَ!". ثُمَّ انْسَابَتْ "نَدَى" عَبْرَ جَدْوَلٍ مَائِيٍّ رَقْرَاقٍ عَائِدَةً إِلَى الْبَحْرِ، لِتَبْدَأَ رِحْلَتَهَا السَّاحِرَةَ مِنْ جَدِيدٍ!',
        audioNarration: 'هبطت ندى على وردة حمراء أنعشتها، ثم جرت في الجدول عائدة للبحر لتبدأ الرحلة من جديد.',
        illustration: 'الوردة تنتعش والجدول يجري للبحر وقوس قزح',
        sceneEmoji: '🌹🌈💧🌊'
      }
    ],
    questions: [
      {
        question: 'مَاذَا حَدَثَ لِقَطْرَةِ الْمَاءِ عِنْدَمَا سَخَّنَتْهَا أَشِعَّةُ الشَّمْسِ؟',
        options: ['تَجَمَّدَتْ وَأَصْبَحَتْ ثَلْجاً', 'تَبَخَّرَتْ وَصَعِدَتْ إِلَى السَّمَاءِ', 'غَاصَتْ فِي قَاعِ الْمُحِيطِ'],
        correctIndex: 1,
        rewardStars: 3
      },
      {
        question: 'كَيْفَ تَكَوَّنَتِ الْغَيْمَةُ فِي السَّمَاءِ؟',
        options: ['مِنْ تَجَمُّعِ بُخَارِ الْمَاءِ وَتَكَاثُفِهِ عِنْدَ الْبُرُودَةِ', 'مِنْ قِطَعِ الْقُطْنِ', 'مِنْ رِمَالِ الشَّاطِئِ'],
        correctIndex: 0,
        rewardStars: 3
      }
    ]
  },
  {
    id: 'story-numbers-garden',
    title: 'مُغَامَرَةٌ فِي حَدِيقَةِ الْأَرْقَامِ الْعَجِيبَةِ',
    category: 'الرياضيات والتفكير',
    ageGroup: '5-7',
    moral: 'الرِّيَاضِيَّاتُ لُعْبَةٌ مُمْتِعَةٌ تُسَاعِدُنَا عَلَى حَلِّ الْمُشْكِلَاتِ وَالتَّعَاوُنِ مَعَ الْآخَرِينَ.',
    coverEmoji: '🔢🏰✨',
    pages: [
      {
        text: 'كَانَ هُنَاكَ صَبِيٌّ ذَكِيٌّ اسْمُهُ "زِيَادٌ" يُحِبُّ الِاسْتِكْشَافَ. فِي يَوْمٍ مِنَ الْأَيَّامِ، فَتَحَ كِتَابَ الْحِسَابِ فَوَجَدَ نَفْسَهُ دَاخِلَ بَوَّابَةٍ سِحْرِيَّةٍ تُؤَدِّي إِلَى "حَدِيقَةِ الْأَرْقَامِ"!',
        audioNarration: 'كان هناك صبي ذكي اسمه زياد يحب الاستكشاف، وفتح بوابة سحرية لحديقة الأرقام.',
        illustration: 'زياد أمام بوابة سحرية تضيء بأرقام ملونة',
        sceneEmoji: '🚪✨👦🔢'
      },
      {
        text: 'اسْتَقْبَلَهُ الرَّقَمُ "خَمْسَةٌ 5" بِابْتِسَامَةٍ وَقَالَ: "أَهْلاً بِكَ يَا زِيَادُ! لِكَيْ تَعْبُرَ الْجِسْرَ، عَلَيْكَ أَنْ تَجْمَعَنِي مَعَ صَدِيقِي الرَّقَمِ ثَلَاثَة 3!". فَكَّرَ زِيَادٌ وَعَدَّ عَلَى أَصَابِعِهِ: 5 + 3 = 8! فَانْفَتَحَ الْجِسْرُ أَمَامَهُ مُضِيئاً بِالنُّجُومِ.',
        audioNarration: 'طلب الرقم خمسة من زياد أن يجمعه مع الرقم ثلاثة لفتح الجسر. حسب زياد وقال ثمانية، فانفتح الجسر.',
        illustration: 'الجسر يضيء بالألوان وزياد يقفز سعيداً',
        sceneEmoji: '5️⃣➕3️⃣🟰8️⃣🌉'
      },
      {
        text: 'ثُمَّ وَصَلَ زِيَادٌ إِلَى شَجَرَةِ التُّفَّاحِ الذَّهَبِيِّ. وَكَانَ هُنَاكَ 10 تُفَّاحَاتٍ، أَخَذَ مِنْهَا الْعُصْفُورُ 4 تُفَّاحَاتٍ. سَأَلَتْهُ الشَّجَرَةُ: "كَمْ تُفَّاحَةً بَقِيَتْ عَلَيَّ؟". أَجَابَ زِيَادٌ: 10 - 4 = 6 تُفَّاحَاتٍ! فَقَدَّمَتْ لَهُ الشَّجَرَةُ تُفَّاحَةً لَذِيذَةً كَمُكَافَأَةٍ!',
        audioNarration: 'وصل زياد لشجرة التفاح، وسألته عن حاصل طرح 10 ناقص 4، فأجاب ستة تفاحات وحصل على جائزة.',
        illustration: 'شجرة تفاح والعصفور وزياد يحسب بذكاء',
        sceneEmoji: '🍎🔟➖4️⃣🟰6️⃣'
      }
    ],
    questions: [
      {
        question: 'مَا هُوَ حَاصِلُ جَمْعِ: 5 + 3؟',
        options: ['7', '8', '9'],
        correctIndex: 1,
        rewardStars: 3
      }
    ]
  }
];

// Curated safe educational video items
export const EDUCATIONAL_VIDEOS: VideoItem[] = [
  {
    id: 'vid-alphabet',
    title: 'أُنْشُودَةُ الْحُرُوفِ الْعَرَبِيَّةِ الْجَمِيلَةِ',
    category: 'letters',
    categoryAr: 'الحروف واللغة',
    duration: '04:15',
    youtubeId: 'WwXk9t_w0kU',
    embedUrl: 'https://www.youtube-nocookie.com/embed/WwXk9t_w0kU',
    thumbnailEmoji: '🔤🎵',
    description: 'أنشودة ممتعة ومبهجة للأطفال لتعلم نطق وكتابة الحروف العربية الهجائية من الألف إلى الياء مع أمثلة ورسومات لطيفة.',
    keyPoints: ['نطق سليم لمخارج الحروف', 'أمثلة لكلمات تبدأ بكل حرف', 'إيقاع لحني سهل الترديد والحفظ'],
    ageGroup: '5-7'
  },
  {
    id: 'vid-numbers',
    title: 'تَعَلُّمُ الْأَرْقَامِ وَالْعَدِّ مِنْ 1 إِلَى 20',
    category: 'math',
    categoryAr: 'الحساب والرياضيات',
    duration: '05:30',
    youtubeId: 'H2jKkK7sI4s',
    embedUrl: 'https://www.youtube-nocookie.com/embed/H2jKkK7sI4s',
    thumbnailEmoji: '🔢🍎',
    description: 'فيديو تفاعلي يعلم الطفل عد الأشياء والفواكه من واحد إلى عشرين مع الرسوم المتحركة البصرية التفاعلية.',
    keyPoints: ['الربط بين شكل الرقم ومقداره البصري', 'تدريب عملي على عد العناصر', 'ألعاب سريعة لاختبار الذاكرة'],
    ageGroup: '5-7'
  },
  {
    id: 'vid-multiplication',
    title: 'سِحْرُ جَدْوَلِ الضَّرْبِ بِطَرِيقَةٍ سَهْلَةٍ وَمُمْتِعَةٍ',
    category: 'math',
    categoryAr: 'الحساب والرياضيات',
    duration: '08:20',
    youtubeId: 'b_fL4nE4Fmg',
    embedUrl: 'https://www.youtube-nocookie.com/embed/b_fL4nE4Fmg',
    thumbnailEmoji: '✖️✨',
    description: 'طريقة ذكية تعتمد على الجمع المتكرر والأنماط البصرية لحفظ جداول الضرب من 2 إلى 9 بسهولة متناهية بدون تعقيد.',
    keyPoints: ['الضرب هو جمع متكرر', 'أسرار جدول 5 وجدول 9 الساحر', 'مسائل سريعة لتثبيت المعلومة'],
    ageGroup: '8-10'
  },
  {
    id: 'vid-solarsystem',
    title: 'رِحْلَةٌ مُدْهِشَةٌ دَاخِلَ الْمَجْمُوعَةِ الشَّمْسِيَّةِ',
    category: 'science',
    categoryAr: 'العلوم والفضاء',
    duration: '09:45',
    youtubeId: 'libKVRa01L8',
    embedUrl: 'https://www.youtube-nocookie.com/embed/libKVRa01L8',
    thumbnailEmoji: '🪐🚀',
    description: 'انطلق مع رائد الفضاء الصغير في سفينة الفضاء لاكتشاف الشمس والكواكب الثمانية بالرسوم ثلاثية الأبعاد المذهلة.',
    keyPoints: ['التعرف على كل كوكب ولونه ومميزاته', 'معرفة موقع كوكب الأرض في الكون', 'أهمية الشمس لكوكبنا'],
    ageGroup: '8-10'
  },
  {
    id: 'vid-humanbody',
    title: 'كَيْفَ يَعْمَلُ جِسْمُ الْإِنْسَانِ؟ (الْقَلْبُ وَالرِّئَتَانِ)',
    category: 'science',
    categoryAr: 'العلوم وجسم الإنسان',
    duration: '06:10',
    youtubeId: 'w_q9c8uMh5E',
    embedUrl: 'https://www.youtube-nocookie.com/embed/w_q9c8uMh5E',
    thumbnailEmoji: '🫀🔬',
    description: 'فيديو كرتوني تعليمي يبسط للأطفال عمل الدورة الدموية وكيف يضخ القلب الدم النقي إلى كامل الجسم.',
    keyPoints: ['وظيفة القلب كرئيس للمضخات', 'كيف نتنفس الأكسجين النقي', 'نصائح للمحافظة على صحتنا ونشاطنا'],
    ageGroup: '5-7'
  }
];

// Comprehensive Quizzes Bank
export const QUIZ_BANK: QuizItem[] = [
  // Letters & Words
  {
    id: 'q1',
    category: 'letters',
    categoryAr: 'الحروف الهجائية',
    question: 'مَا هُوَ الْحَرْفُ الْأَوَّلُ فِي كَلِمَةِ "أَرْنَبٌ"؟',
    visualEmoji: '🐇',
    options: ['ب', 'أ', 'ت', 'ث'],
    correctIndex: 1,
    explanation: 'كلمة أَرْنَب تبدأ بحرف الألف المفتوح (أَ)!',
    ageGroup: '5-7'
  },
  {
    id: 'q2',
    category: 'words',
    categoryAr: 'الكلمات والتهجئة',
    question: 'أَيٌّ مِنَ الْكَلِمَاتِ التَّالِيَةِ تُعَبِّرُ عَنْ فَاكِهَةٍ لَذِيذَةٍ؟',
    visualEmoji: '🍎',
    options: ['سَيَّارَةٌ', 'تُفَّاحٌ', 'قَلَمٌ', 'بَابٌ'],
    correctIndex: 1,
    explanation: 'التفاح فاكهة مغذية وصحية ومقرمشة!',
    ageGroup: '5-7'
  },
  {
    id: 'q3',
    category: 'letters',
    categoryAr: 'الحروف والتشكيل',
    question: 'كَيْفَ نَنْطِقُ حَرْفَ الْمِيمِ مَعَ حَرَكَةِ الضَّمَّةِ؟',
    visualEmoji: 'مُ',
    options: ['مَ', 'مُ', 'مِ', 'مْ'],
    correctIndex: 1,
    explanation: 'الضمة تجعلنا نضم الشفتين فنقول: مُ!',
    ageGroup: '5-7'
  },
  {
    id: 'q4',
    category: 'words',
    categoryAr: 'تكوين الجمل',
    question: 'أَكْمِلِ الْجُمْلَةَ: "الشَّمْسُ تُشْرِقُ فِي ......."',
    visualEmoji: '🌅',
    options: ['اللَّيْلِ', 'الصَّبَاحِ', 'الْبَحْرِ', 'الْغُرْفَةِ'],
    correctIndex: 1,
    explanation: 'الشمس تشرق دائماً في الصباح الباكر لتنير يومنا!',
    ageGroup: '5-7'
  },
  // Math: Addition, Subtraction, Multiplication, Place Value
  {
    id: 'q5',
    category: 'math',
    categoryAr: 'الجمع البسيط',
    question: 'مَا هُوَ نَاتِجُ: 4 + 3؟',
    visualEmoji: '🍎🍎🍎🍎 + 🍎🍎🍎',
    options: ['6', '7', '8', '9'],
    correctIndex: 1,
    explanation: '4 زائد 3 يساوي 7!',
    ageGroup: '5-7'
  },
  {
    id: 'q6',
    category: 'math',
    categoryAr: 'الطرح البسيط',
    question: 'كَانَ مَعَكَ 8 بَالُونَاتٍ، طَارَتْ مِنْهَا 3 بَالُونَاتٍ. كَمْ بَالُوناً بَقِيَ مَعَكَ؟',
    visualEmoji: '🎈🎈🎈🎈🎈 (8 - 3)',
    options: ['4', '5', '6', '7'],
    correctIndex: 1,
    explanation: '8 ناقص 3 يساوي 5 بالونات متبقية!',
    ageGroup: '5-7'
  },
  {
    id: 'q7',
    category: 'math',
    categoryAr: 'جدول الضرب',
    question: 'مَا هُوَ نَاتِجُ: 6 × 7؟',
    visualEmoji: '✖️🧮',
    options: ['36', '42', '48', '49'],
    correctIndex: 1,
    explanation: '6 في 7 يساوي 42!',
    ageGroup: '8-10'
  },
  {
    id: 'q8',
    category: 'math',
    categoryAr: 'جدول الضرب',
    question: 'مَا هُوَ نَاتِجُ: 9 × 8؟',
    visualEmoji: '✖️🧠',
    options: ['64', '72', '81', '70'],
    correctIndex: 1,
    explanation: '9 في 8 يساوي 72!',
    ageGroup: '8-10'
  },
  {
    id: 'q9',
    category: 'math',
    categoryAr: 'القيمة المكانية',
    question: 'فِي الرَّقَمِ 542، مَا هِيَ الْقِيمَةُ الْمَكَانِيَّةُ لِلرَّقَمِ 5؟',
    visualEmoji: '💯🧮',
    options: ['5', '50', '500', '5000'],
    correctIndex: 2,
    explanation: 'الرقم 5 يقع في خانة المئات، فقيمة الرقم 5 هي 500!',
    ageGroup: '8-10'
  },
  {
    id: 'q10',
    category: 'math',
    categoryAr: 'القيمة المكانية',
    question: 'فِي الرَّقَمِ 3,741، أَيُّ رَقَمٍ يَقَعُ فِي خَانَةِ الْآلَافِ؟',
    visualEmoji: '🏛️🧮',
    options: ['1', '4', '7', '3'],
    correctIndex: 3,
    explanation: 'الرقم 3 يقع في خانة الآلاف وتساوي قيمته 3,000!',
    ageGroup: '8-10'
  },
  // Science
  {
    id: 'q11',
    category: 'science',
    categoryAr: 'الفضاء والمجموعة الشمسية',
    question: 'مَا هُوَ الْكَوْكَبُ الَّذِي نَعِيشُ عَلَيْهِ وَيُسَمَّى بِالْكَوْكَبِ الْأَزْرَقِ؟',
    visualEmoji: '🌍',
    options: ['الْمِرِّيخُ', 'الْأَرْضُ', 'الْمُشْتَرِي', 'زُحَلُ'],
    correctIndex: 1,
    explanation: 'كوكب الأرض يسمى الكوكب الأزرق لأن الماء يغطي أكثر من 70% من سطحه!',
    ageGroup: '5-7'
  },
  {
    id: 'q12',
    category: 'science',
    categoryAr: 'جسم الإنسان',
    question: 'كَمْ عَدَدُ الْحَوَاسِّ الْخَمْسِ عِنْدَ الْإِنْسَانِ؟',
    visualEmoji: '👁️👂👃👅✋',
    options: ['3', '4', '5', '6'],
    correctIndex: 2,
    explanation: 'الحواس الخمس هي: البصر، السمع، الشم، التذوق، واللمس!',
    ageGroup: '5-7'
  },
  {
    id: 'q13',
    category: 'science',
    categoryAr: 'الفيزياء وحالات المادة',
    question: 'إِلَى أَيِّ حَالَةٍ يَتَحَوَّلُ الْمَاءُ السَّائِلُ عِنْدَ غَلَيَانِهِ عَلَى النَّارِ؟',
    visualEmoji: '💨🫖',
    options: ['حَالَةٍ صَلْبَةٍ (ثَلْج)', 'حَالَةٍ غَازِيَّةٍ (بُخَار)', 'حَالَةٍ تُرَابِيَّةٍ', 'لَا يَتَغَيَّرُ'],
    correctIndex: 1,
    explanation: 'الغليان يحول الماء السائل إلى بخار ماء في الحالة الغازية!',
    ageGroup: '8-10'
  },
  {
    id: 'q14',
    category: 'science',
    categoryAr: 'النباتات والبيئة',
    question: 'مَاذَا يُنْتِجُ النَّبَاتُ فِي عَمَلِيَّةِ الْبِنَاءِ الضَّوْئِيِّ وَنَحْتَاجُهُ لِلتَّنَفُّسِ؟',
    visualEmoji: '🌱💨',
    options: ['الْأُكْسِيجِين', 'التُّرَاب', 'الْمِلْح', 'الْحَدِيد'],
    correctIndex: 0,
    explanation: 'النباتات تأخذ ثاني أكسيد الكربون وتطلق غاز الأكسجين الضروري لتنفس الكائنات الحية!',
    ageGroup: '8-10'
  }
];

export const DEFAULT_BADGES = [
  { id: 'b1', title: 'عبقري الحروف', description: 'أتقن جميع الحروف الهجائية ونطقها', icon: '🔤', unlocked: true },
  { id: 'b2', title: 'بطل الرياضيات', description: 'حل مسائل الجمع والطرح والضرب ببراعة', icon: '🧮', unlocked: true },
  { id: 'b3', title: 'عالم المستقبل', description: 'استكشف الفضاء وأعضاء جسم الإنسان', icon: '🚀', unlocked: false },
  { id: 'b4', title: 'قارئ القصص الماهر', description: 'أكمل قراءة القصص وأجاب على الأسئلة', icon: '📖', unlocked: false },
  { id: 'b5', title: 'فنان السبورة', description: 'رسم وكتب على السبورة التفاعلية', icon: '🎨', unlocked: false },
  { id: 'b6', title: 'نجم التحديات', description: 'حقق درجات كاملة في الاختبارات', icon: '⭐', unlocked: false }
];
