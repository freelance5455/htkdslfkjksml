import {
  hydrateFlowerTuple,
  type CompactFlowerTuple,
  type FlowerCategory,
  type FlowerColor,
  type FlowerEntry,
} from "../types/flower";
import { FLOWERS_PART_1 } from "./flowersPart1";
import { FLOWERS_PART_2 } from "./flowersPart2";
import { FLOWERS_PART_3 } from "./flowersPart3";
import { FLOWERS_PART_4 } from "./flowersPart4";
import { FLOWERS_PART_5 } from "./flowersPart5";
import { FLOWERS_PART_6 } from "./flowersPart6";

const RAW_TUPLES: CompactFlowerTuple[] = [
  ...FLOWERS_PART_1,
  ...FLOWERS_PART_2,
  ...FLOWERS_PART_3,
  ...FLOWERS_PART_4,
  ...FLOWERS_PART_5,
  ...FLOWERS_PART_6,
];

// Deduplicate by latinName + uzName while preserving natural botanical ordering
const seenKeys = new Set<string>();
const UNIQUE_FLOWERS: FlowerEntry[] = [];

for (let i = 0; i < RAW_TUPLES.length; i++) {
  const tuple = RAW_TUPLES[i];
  const key = `${tuple[2].toLowerCase()}|${tuple[0].toLowerCase()}`;
  if (!seenKeys.has(key)) {
    seenKeys.add(key);
    UNIQUE_FLOWERS.push(hydrateFlowerTuple(tuple, UNIQUE_FLOWERS.length + 1));
  }
}

export const FLOWERS_CATALOG: FlowerEntry[] = UNIQUE_FLOWERS;

export function normalizeUzbekQuery(value: string): string {
  return value
    .toLowerCase()
    .replace(/[‘’`ʼ']/g, "'")
    .replace(/o'/g, "o")
    .replace(/g'/g, "g")
    .replace(/\s+/g, " ")
    .trim();
}

export function filterAndSearchFlowers(
  query: string,
  category: "Barchasi" | FlowerCategory,
  color: "Barcha ranglar" | FlowerColor
): FlowerEntry[] {
  const normQuery = normalizeUzbekQuery(query);

  const filtered = FLOWERS_CATALOG.filter((flower) => {
    if (category !== "Barchasi" && flower.category !== category) {
      return false;
    }
    if (color !== "Barcha ranglar" && flower.color !== color) {
      return false;
    }
    if (!normQuery) {
      return true;
    }

    const haystack = normalizeUzbekQuery(
      `${flower.uzName} ${flower.enName} ${flower.latinName} ${flower.family} ${flower.origin} ${flower.meaning} ${flower.color}`
    );
    return haystack.includes(normQuery);
  });

  if (!normQuery) {
    return filtered;
  }

  // Prioritize exact/prefix matches in Uzbek, English, or Latin names
  return filtered.sort((a, b) => {
    const aUz = normalizeUzbekQuery(a.uzName);
    const bUz = normalizeUzbekQuery(b.uzName);
    const aEn = normalizeUzbekQuery(a.enName);
    const bEn = normalizeUzbekQuery(b.enName);
    const aLat = normalizeUzbekQuery(a.latinName);
    const bLat = normalizeUzbekQuery(b.latinName);

    const score = (uz: string, en: string, lat: string): number => {
      if (uz === normQuery || en === normQuery || lat === normQuery) return 100;
      if (uz.startsWith(normQuery) || en.startsWith(normQuery) || lat.startsWith(normQuery)) return 60;
      if (uz.includes(normQuery) || en.includes(normQuery) || lat.includes(normQuery)) return 30;
      return 10;
    };

    return score(bUz, bEn, bLat) - score(aUz, aEn, aLat);
  });
}

export const POPULAR_SEARCH_SUGGESTIONS = [
  "Atirgul",
  "Lola",
  "Pion",
  "Orxideya",
  "Nilufar",
  "Lavanda",
  "Sakura",
  "Moychechak",
  "Siren",
  "Gortenzia",
];
