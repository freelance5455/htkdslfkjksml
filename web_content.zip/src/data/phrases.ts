export type PhraseCategory =
  | "pet"
  | "feed"
  | "play"
  | "sleep"
  | "wake"
  | "idle"
  | "accessory";

export const PHRASES: Record<PhraseCategory, string[]> = {
  pet: [
    "¡Miau! ¡Qué rico, sigue así!",
    "Prrr... prrr... ¡me encanta!",
    "¡Tus manos son mágicas!",
    "¡Ronroneo de felicidad activado!",
    "¡Eres mi humano favorito!",
    "Miau miau... ¡no pares, por favor!",
    "¡Cosquillitas de amor!",
    "Mi corazoncito hace prrr prrr",
    "¡Qué suavecito! ¡Gracias!",
    "Me derrito de ternura...",
    "¡Acaríciame detrás de la orejita!",
    "Prrr... ¡eres lo máximo!",
    "¡Mi colita baila de alegría!",
  ],
  feed: [
    "¡Ñam ñam! ¡Delicioso!",
    "¡Mi pancita está muy feliz!",
    "¡Miau! ¡Sabía riquísimo!",
    "¡Gracias por la comidita!",
    "Ñam... ¡quiero otro poquito!",
    "¡Esto es un manjar mágico!",
    "Mi pancita dice: ¡gracias, gracias!",
    "¡Comí como una verdadera reina!",
    "¡Mmm! ¡Mi favorito de favoritos!",
  ],
  play: [
    "¡A jugar! ¡Corre, corre, corre!",
    "¡Atrapé la bolita! ¿Lo viste?",
    "¡Soy una cazadora experta!",
    "¡Wiiiii! ¡Qué divertido!",
    "¡Es mi juguete favorito!",
    "¡Salto mágico de gatita!",
    "¡Otra vez, otra vez, otra vez!",
    "¡Miau! ¡Nadie me gana jugando!",
    "¡Mis patitas son rapidísimas!",
  ],
  sleep: [
    "Zzz... sueñito de pescaditos...",
    "Hora de mimir... buenas noches",
    "Zzz... solo un sueñito más...",
    "A mimir entre estrellitas...",
    "Zzz... soñando con lunitas de queso...",
  ],
  wake: [
    "¡Miau! ¡Ya desperté renovada!",
    "¡Qué sueñito tan rico tuve!",
    "Estiradita lista... ¡a jugar!",
    "¡Buenos días, mundo mágico!",
    "¡Desperté con mucha energía!",
  ],
  idle: [
    "¿Jugamos a algo bonito?",
    "Hoy es un día mágico, ¿no crees?",
    "Me encanta mi cuartito acogedor",
    "¿Me das una caricia, por favor?",
    "Estoy contando las estrellitas...",
    "Mi colita se mueve de felicidad",
    "¿Lo hueles? ¡Huele a aventuras!",
    "Soy la gatita más suertuda del mundo",
    "Prrr... qué paz se siente aquí",
    "¿Me cuentas un cuento de hadas?",
    "Mis ojitos brillan como esmeraldas",
    "¿Y si practicamos mi salto mágico?",
    "Aaah... qué bostecito tan grande tuve",
    "Creo que vi una mariposa mágica por la ventana",
    "¿Me peinas el pelaje? Hoy quiero verme fabulosa",
    "Mi lunita del pecho brilla cuando estoy feliz",
  ],
  accessory: [
    "¡Me veo absolutamente fabulosa!",
    "¡Qué estilo tan mágico tengo!",
    "¡Miau! ¡Estoy estrenando look!",
    "¡Todas las gatitas me van a envidiar!",
    "¡Combina perfecto con mis ojitos!",
    "¡Soy una gatita muy fashion!",
    "¡Mírame, mírame! ¡Qué bonita!",
  ],
};

export const NO_COINS_PHRASE =
  "¡Nos faltan moneditas! Acaríciame o juega conmigo para ganar más.";

export const HUNGRY_PHRASE = "Miau... mi pancita está haciendo ruiditos. ¿Me das comidita?";
export const TIRED_PHRASE = "Estoy muy cansadita... ¿mimimos un ratito?";

/**
 * Picks a random phrase from a category while avoiding the most
 * recently spoken phrases (kept in `recentRef`).
 */
export function pickPhrase(
  category: PhraseCategory,
  recent: string[],
  keepLast = 7
): string {
  const pool = PHRASES[category];
  const fresh = pool.filter((p) => !recent.includes(p));
  const source = fresh.length > 0 ? fresh : pool;
  const phrase = source[Math.floor(Math.random() * source.length)];
  recent.push(phrase);
  while (recent.length > keepLast) recent.shift();
  return phrase;
}
