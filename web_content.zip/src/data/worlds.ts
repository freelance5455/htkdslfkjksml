export type WorldId = 'summit' | 'lake' | 'forest' | 'meadow';
export type DisplayMode = 'stereo' | 'single';
export type SoundLayer = 'birds' | 'water' | 'wind';

export interface Settings {
  displayMode: DisplayMode;
  volume: number;
  birds: number;
  water: number;
  wind: number;
  footsteps: boolean;
  motionEnabled: boolean;
  sensitivity: number;
  speed: number;
  headTracking: boolean;
  quality: 'balanced' | 'high';
  timeOfDay: 'morning' | 'day' | 'sunset';
}

export const defaultSettings: Settings = {
  displayMode: 'stereo',
  volume: 65,
  birds: 75,
  water: 60,
  wind: 45,
  footsteps: true,
  motionEnabled: true,
  sensitivity: 6,
  speed: 1.6,
  headTracking: true,
  quality: 'balanced',
  timeOfDay: 'morning',
};

export const worlds = [
  {
    id: 'summit' as const,
    name: 'Mountain Summit 🗻',
    category: 'ALPINE PEAK & PANORAMA',
    description: 'High-altitude pinnacle with panoramic views overlooking deep pine valleys, a glistening river, and soaring eagles.',
    shortDescription: 'Clouds, winding river & endless valleys.',
    image: '/images/mountain-summit.jpg',
    sounds: 'Mountain breeze, river murmur & soaring eagles',
    credit: 'Krivec Ales / Pexels',
  },
  {
    id: 'lake' as const,
    name: 'Mirror Lake',
    category: 'LAKE & ALPINE PEAKS',
    description: 'Gentle water ripples, golden dawn rays, and serene mountain reflections.',
    shortDescription: 'Tranquil calm as far as the eye can see.',
    image: '/images/lake.jpg',
    sounds: 'Water ripples & morning birds',
    credit: 'eberhard grossgasteiger / Pexels',
  },
  {
    id: 'forest' as const,
    name: 'Pine Woodland',
    category: 'FOREST & MORNING MIST',
    description: 'Warm sunlight filtering through towering pine groves and rolling hills.',
    shortDescription: 'Lost in the whispering pines.',
    image: '/images/forest.jpg',
    sounds: 'Rustling leaves & forest birds',
    credit: 'Dongdilac / Pexels',
  },
  {
    id: 'meadow' as const,
    name: 'Verdant Meadow',
    category: 'VALLEY & WILDFLOWERS',
    description: 'Endless blossoms, sweeping breezes, and wide open alpine horizons.',
    shortDescription: 'Space to breathe freely.',
    image: '/images/meadow.jpg',
    sounds: 'Valley breeze & dawn birdsong',
    credit: 'Edit Krizsan / Pexels',
  },
];

export function loadSettings(): Settings {
  try {
    const saved = JSON.parse(localStorage.getItem('rimba-settings') || '{}') as Partial<Settings>;
    const merged = { ...defaultSettings, ...saved };
    const clamp = (value: unknown, min: number, max: number, fallback: number) =>
      typeof value === 'number' && Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
    return {
      ...merged,
      displayMode: saved.displayMode === 'single' ? 'single' : 'stereo',
      quality: saved.quality === 'high' ? 'high' : 'balanced',
      timeOfDay: ['morning', 'day', 'sunset'].includes(merged.timeOfDay) ? merged.timeOfDay : 'morning',
      volume: clamp(saved.volume, 0, 100, 65),
      birds: clamp(saved.birds, 0, 100, 75),
      water: clamp(saved.water, 0, 100, 60),
      wind: clamp(saved.wind, 0, 100, 45),
      sensitivity: clamp(saved.sensitivity, 1, 10, 6),
      speed: clamp(saved.speed, 0.6, 3, 1.6),
    };
  } catch {
    return { ...defaultSettings };
  }
}
