import { ConditionEducationSection } from '../types';

export const AUTHORITATIVE_CONDITIONS_LIBRARY: Record<string, ConditionEducationSection> = {
  diabetes: {
    conditionIdentified: true,
    conditionName: 'Diabetes Mellitus / Glycemic Dysregulation',
    conditionNameHi: 'मधुमेह (डायबिटीज) / रक्त शर्करा असंतुलन',
    conditionNameMr: 'मधुमेह (डायबेटिस) / रक्त शर्करा असंतुलन',
    relevanceExplanation:
      'Identified based on laboratory glycemic markers (such as Fasting Blood Glucose, Post-prandial Glucose, or HbA1c). These biomarkers evaluate the body’s ability to regulate blood glucose over time.',
    relevanceExplanationHi:
      'प्रयोगशाला के रक्त शर्करा मार्करों (जैसे फास्टिंग ब्लड ग्लूकोज, भोजन के बाद का ग्लूकोज, या HbA1c) के आधार पर पहचाना गया। ये बायोमार्कर रक्त शर्करा को नियंत्रित करने की शरीर की क्षमता का मूल्यांकन करते हैं।',
    relevanceExplanationMr:
      'प्रयोगशाळेतील ग्लुकोज निर्देशकांच्या (उदा. फास्टिंग ब्लड ग्लुकोज, जेवणानंतरचे ग्लुकोज किंवा HbA1c) आधारे ओळखले गेले. हे बायोमार्कर्स शरीराच्या रक्त शर्करा नियंत्रित करण्याच्या क्षमतेचे मूल्यांकन करतात.',
    retrievalSuccess: true,
    trustedSources: [
      {
        name: 'World Health Organization (WHO)',
        organizationType: 'United Nations Specialized Agency for International Public Health',
        url: 'https://www.who.int/news-room/fact-sheets/detail/diabetes',
        topicTitle: 'WHO Diabetes Fact Sheet: Definition, Epidemiology, and Global Clinical Guidelines',
        retrievedAt: new Date().toISOString(),
      },
      {
        name: 'Centers for Disease Control and Prevention (CDC)',
        organizationType: 'U.S. Department of Health and Human Services',
        url: 'https://www.cdc.gov/diabetes/basics/index.html',
        topicTitle: 'CDC Diabetes Basics: Diagnosis, Screening Criteria, and Risk Factors',
        retrievedAt: new Date().toISOString(),
      },
      {
        name: 'National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK / NIH)',
        organizationType: 'National Institutes of Health (NIH)',
        url: 'https://www.niddk.nih.gov/health-information/diabetes',
        topicTitle: 'NIDDK Diabetes Clinical Overview, Biomarker Testing, and Long-Term Health',
        retrievedAt: new Date().toISOString(),
      },
      {
        name: 'National Library of Medicine (MedlinePlus / NIH)',
        organizationType: 'Federal Medical Information Repository (NIH)',
        url: 'https://medlineplus.gov/diabetes.html',
        topicTitle: 'MedlinePlus Health Topic: Diabetes Diagnostic Tests and Patient Education',
        retrievedAt: new Date().toISOString(),
      },
    ],
    educationalContent: {
      overview:
        'Diabetes mellitus is a chronic metabolic condition characterized by elevated blood glucose (hyperglycemia). It occurs when the pancreas cannot produce enough insulin, or when the body cannot effectively utilize the insulin it produces. Insulin is the hormone essential for allowing glucose to enter cells to provide cellular energy.',
      overviewHi:
        'मधुमेह (डायबिटीज) एक दीर्घकालिक चयापचय (मेटाबॉलिक) स्थिति है जिसमें रक्त में शर्करा (ग्लूकोज) का स्तर बढ़ जाता है। यह तब होता है जब अग्न्याशय (पैंक्रियाज) पर्याप्त इंसुलिन नहीं बनाता है, या जब शरीर अपने द्वारा बनाए गए इंसुलिन का प्रभावी ढंग से उपयोग नहीं कर पाता है। इंसुलिन वह हार्मोन है जो कोशिकाओं को ऊर्जा के लिए ग्लूकोज का उपयोग करने की अनुमति देता है।',
      overviewMr:
        'मधुमेह (डायबेटिस) ही एक जुनाट चयापचय स्थिती आहे ज्यामध्ये रक्तातील साखरेचे (ग्लुकोज) प्रमाण वाढते. हे तेव्हा घडते जेव्हा स्वादुपिंड पुरेसे इन्सुलिन तयार करू शकत नाही किंवा शरीर तयार झालेल्या इन्सुलिनचा प्रभावीपणे वापर करू शकत नाही. पेशींना ऊर्जेसाठी ग्लुकोज वापरू देणारा इन्सुलिन हा अत्यंत महत्त्वाचा संप्रेरक (हार्मोन) आहे.',
      types: [
        'Type 1 Diabetes: An autoimmune condition where the immune system destroys insulin-producing beta cells in the pancreas, requiring daily insulin replacement.',
        'Type 2 Diabetes: The most prevalent form (over 90% of cases), characterized by insulin resistance and progressive loss of beta-cell insulin secretion, closely associated with lifestyle and genetics.',
        'Gestational Diabetes: Hyperglycemia first recognized during pregnancy, increasing risk of maternal and fetal complications and future type 2 diabetes.',
        'Prediabetes: Blood glucose levels higher than normal but below clinical diabetes thresholds; a critical reversible window through lifestyle interventions.',
      ],
      typesHi: [
        'टाइप 1 डायबिटीज: एक ऑटोइम्यून स्थिति जिसमें प्रतिरक्षा प्रणाली अग्न्याशय की इंसुलिन उत्पादक कोशिकाओं को नष्ट कर देती है, जिसके लिए दैनिक इंसुलिन की आवश्यकता होती है।',
        'टाइप 2 डायबिटीज: सबसे सामान्य प्रकार (90% से अधिक मामले), जिसमें इंसुलिन प्रतिरोध और इंसुलिन स्राव में कमी होती है; यह जीवनशैली और आनुवंशिकी से जुड़ा है।',
        'गर्भावधि मधुमेह (जेस्टेशनल डायबिटीज): गर्भावस्था के दौरान पहली बार पहचानी जाने वाली उच्च रक्त शर्करा, जो भविष्य में टाइप 2 डायबिटीज के जोखिम को बढ़ाती है।',
        'प्री-डायबिटीज: रक्त शर्करा सामान्य से अधिक लेकिन मधुमेह की सीमा से कम होती है; यह स्वस्थ जीवनशैली के माध्यम से सुधारने का एक महत्वपूर्ण अवसर है।',
      ],
      typesMr: [
        'टाइप १ मधुमेह: एक ऑटोइम्यून स्थिती ज्यामध्ये शरीराची प्रतिकारसंस्था स्वादुपिंडातील इन्सुलिन तयार करणाऱ्या पेशी नष्ट करते, ज्यासाठी दैनंदिन इन्सुलिन आवश्यक असते.',
        'टाइप २ मधुमेह: सर्वात सामान्य प्रकार (९०% हून अधिक प्रकरणे), ज्यामध्ये इन्सुलिन प्रतिरोध आणि इन्सुलिन स्रावात कमतरता दिसून येते; हा जीवनशैली आणि अनुवंशिकतेशी संबंधित आहे.',
        'गर्भधारणेतील मधुमेह (जेस्टेशनल डायबेटिस): गर्भधारणेदरम्यान प्रथमच आढळलेली वाढलेली रक्त शर्करा, ज्यामुळे भविष्यात टाइप २ मधुमेहाचा धोका वाढतो.',
        'प्री-डायबेटिस: रक्तातील ग्लुकोज सामान्यपेक्षा जास्त परंतु मधुमेहाच्या मर्यादेपेक्षा कमी असते; जीवनशैलीतील बदलांद्वारे हे पूर्ववत करण्याचे महत्त्वाचे टप्पा आहे.',
      ],
      causesAndRisks: [
        'Overweight and Obesity: Especially central/abdominal visceral adiposity.',
        'Physical Inactivity: Sedentary habits reduce cellular glucose uptake and insulin sensitivity.',
        'Family History & Genetics: First-degree relatives with type 2 diabetes significantly raise hereditary risk.',
        'Age & Ethnicity: Risk increases progressively after age 45, though younger onset is rising globally.',
        'Metabolic Syndrome: Co-existing hypertension, elevated triglycerides, and low HDL cholesterol.',
        'History of Gestational Diabetes or Polycystic Ovary Syndrome (PCOS).',
      ],
      causesAndRisksHi: [
        'अधिक वजन और मोटापा: विशेष रूप से पेट के आसपास चर्बी का जमा होना।',
        'शारीरिक निष्क्रियता: व्यायाम की कमी कोशिकाओं की इंसुलिन संवेदनशीलता को कम करती है।',
        'पारिवारिक इतिहास और आनुवंशिकी: परिवार में माता-पिता या भाई-बहन को मधुमेह होना।',
        'आयु: 45 वर्ष से अधिक आयु में जोखिम बढ़ता है, हालांकि युवा आबादी में भी मामले बढ़ रहे हैं।',
        'मेटाबॉलिक सिंड्रोम: उच्च रक्तचाप, उच्च ट्राइग्लिसराइड्स और कम एचडीएल कोलेस्ट्रॉल।',
        'गर्भावधि मधुमेह का इतिहास या पीसीओएस (PCOS)।',
      ],
      causesAndRisksMr: [
        'जास्त वजन आणि लठ्ठपणा: विशेषतः पोटाभोवती अतिरिक्त चरबी जमा होणे.',
        'शारीरिक हालचालींचा अभाव: व्यायामाच्या अभावामुळे इन्सुलिनची संवेदनशीलता कमी होते.',
        'कौटुंबिक इतिहास आणि अनुवंशिकता: आई-वडील किंवा भावंडांना मधुमेह असणे.',
        'वय: वयाच्या ४५ वर्षानंतर धोका वाढतो, जरी आता तरुणांमध्येही प्रमाण वाढत आहे.',
        'मेटाबॉलिक सिंड्रोम: उच्च रक्तदाब, वाढलेले ट्रायग्लिसराइड्स आणि कमी एचडीएल कोलेस्ट्रॉल.',
        'गर्भधारणेतील मधुमेहाचा इतिहास किंवा पीसीओएस (PCOS).',
      ],
      signsAndSymptoms: [
        'Polyuria: Frequent urination, especially waking multiple times at night.',
        'Polydipsia: Unquenchable thirst and persistent dry mouth.',
        'Unexplained Fatigue: Persistent lack of energy because cells cannot access circulating glucose.',
        'Polyphagia: Constant excessive hunger even after regular meals.',
        'Blurred Vision: Fluid shifts swelling the eye lenses.',
        'Slow-Healing Sores: Cuts, bruises, or skin infections that take weeks to resolve.',
        'Tingling or Numbness: Paresthesia in the feet, toes, or fingers (early peripheral nerve irritation).',
      ],
      signsAndSymptomsHi: [
        'बार-बार पेशाब आना (पॉलीयूरिया): विशेष रूप से रात में कई बार उठना।',
        'अत्यधिक प्यास लगना (पॉलीडिप्सिया): बार-बार पानी पीने के बाद भी गला सूखना।',
        'अकारण अत्यधिक थकान: कोशिकाओं को ऊर्जा न मिलने के कारण कमजोरी महसूस होना।',
        'अधिक भूख लगना: भोजन के तुरंत बाद भी भूख का अहसास होना।',
        'धुंधली दृष्टि: आंखों के लेंस में तरल पदार्थ के बदलाव के कारण नजर कमजोर होना।',
        'घाव या चोट का धीरे-धीरे भरना: कटने या छिलने पर घाव सूखने में लंबा समय लगना।',
        'हाथों और पैरों में झनझनाहट या सुन्नता महसूस होना।',
      ],
      signsAndSymptomsMr: [
        'वारंवार लघवी होणे: विशेषतः रात्रीच्या वेळी वारंवार उठावे लागणे.',
        'अतिशय तहान लागणे: वारंवार पाणी पिऊनही तोंड कोरडे पडणे.',
        'अकारण थकवा आणि अशक्तपणा: शरीरातील पेशींना योग्य ऊर्जा न मिळाल्यामुळे थकवा जाणवणे.',
        'सतत भूक लागणे: जेवणानंतरही भूक लागल्यासारखे वाटणे.',
        'दृष्टी धूसर होणे: डोळ्यांच्या लेन्समध्ये द्रवाचे बदल झाल्यामुळे दिसायला त्रास होणे.',
        'जखमा उशिरा भरणे: जखम किंवा खरचटल्यास बरे होण्यास जास्त वेळ लागणे.',
        'हात किंवा पायांमध्ये मुंग्या येणे किंवा बधीरपणा जाणवणे.',
      ],
      diagnosisOverview:
        'Standard clinical diagnostic criteria established by WHO, CDC, and the American Diabetes Association (ADA) require laboratory confirmation via venous plasma testing: 1) Fasting Plasma Glucose (FPG) ≥ 126 mg/dL (7.0 mmol/L) after an 8-hour fast; 2) HbA1c ≥ 6.5% (48 mmol/mol); 3) Oral Glucose Tolerance Test (2-hr PG) ≥ 200 mg/dL; or 4) Random plasma glucose ≥ 200 mg/dL accompanied by classic hyperglycemic symptoms. Asymptomatic findings require confirmation by repeat testing on a separate day.',
      diagnosisOverviewHi:
        'WHO, CDC और ADA द्वारा निर्धारित मानक नैदानिक मानदंडों के अनुसार शिरापरक रक्त (venous plasma) की पुष्टि आवश्यक है: 1) 8 घंटे के उपवास के बाद फास्टिंग प्लाज्मा ग्लूकोज ≥ 126 mg/dL; 2) HbA1c ≥ 6.5%; 3) ओरल ग्लूकोज टॉलरेंस टेस्ट (2 घंटे बाद) ≥ 200 mg/dL; या 4) क्लासिक लक्षणों के साथ रैंडम ग्लूकोज ≥ 200 mg/dL। लक्षण न होने पर दूसरे दिन पुनः परीक्षण द्वारा पुष्टि की जाती है।',
      diagnosisOverviewMr:
        'WHO, CDC आणि ADA द्वारे स्थापित मानक क्लिनिकल निकषांनुसार रक्त तपासणीद्वारे पुष्टी आवश्यक आहे: १) ८ तासांच्या उपवासानंतर फास्टिंग ग्लुकोज ≥ १२६ mg/dL; २) HbA1c ≥ ६.५%; ३) ओरल ग्लुकोज टॉलरन्स टेस्ट (२ तासांनंतर) ≥ २०० mg/dL; किंवा ४) लक्षणांसह रँडम ग्लुकोज ≥ २०० mg/dL. कोणतीही लक्षणे नसल्यास दुसऱ्या दिवशी पुन्हा चाचणी करून खात्री केली जाते.',
      relevantTestsAndMeaning: [
        {
          testName: 'Fasting Blood Glucose (FBG)',
          clinicalMeaning:
            'Measures baseline circulating glucose after 8–12 hours of fasting. Normal: 70–99 mg/dL; Prediabetes: 100–125 mg/dL; Diabetes indicator: ≥ 126 mg/dL.',
          clinicalMeaningHi:
            '8-12 घंटे के उपवास के बाद आधारभूत रक्त शर्करा मापता है। सामान्य: 70–99 mg/dL; प्री-डायबिटीज: 100–125 mg/dL; डायबिटीज: ≥ 126 mg/dL।',
          clinicalMeaningMr:
            '८-१२ तासांच्या उपवासानंतर रक्तातील साखरेची पातळी मोजते. सामान्य: ७०–९९ mg/dL; प्री-डायबेटिस: १००–१२५ mg/dL; मधुमेह: ≥ १२६ mg/dL.',
        },
        {
          testName: 'HbA1c (Glycated Hemoglobin)',
          clinicalMeaning:
            'Reflects the average percentage of hemoglobin bound to glucose over the preceding 2–3 months (lifespan of red blood cells). Normal: < 5.7%; Prediabetes: 5.7%–6.4%; Diabetes indicator: ≥ 6.5%.',
          clinicalMeaningHi:
            'पिछले 2-3 महीनों में रक्त शर्करा के औसत नियंत्रण को दर्शाता है। सामान्य: < 5.7%; प्री-डायबिटीज: 5.7%–6.4%; डायबिटीज: ≥ 6.5%।',
          clinicalMeaningMr:
            'मागील २-३ महिन्यांतील रक्तातील साखरेची सरासरी पातळी दर्शवते. सामान्य: < ५.७%; प्री-डायबेटिस: ५.७%–६.४%; मधुमेह: ≥ ६.५%.',
        },
        {
          testName: 'Post-Prandial Blood Sugar (PPBS / 2-Hr Glucose)',
          clinicalMeaning:
            'Evaluates glycemic clearance and insulin response 2 hours following a meal. Normal: < 140 mg/dL; Impaired tolerance: 140–199 mg/dL; Diabetes indicator: ≥ 200 mg/dL.',
          clinicalMeaningHi:
            'भोजन के 2 घंटे बाद रक्त शर्करा की निकासी और इंसुलिन प्रतिक्रिया का मूल्यांकन करता है। सामान्य: < 140 mg/dL; असामान्य: ≥ 200 mg/dL।',
          clinicalMeaningMr:
            'जेवणानंतर २ तासांनी रक्तातील साखरेची विल्हेवाट आणि इन्सुलिनची प्रतिक्रिया तपासते. सामान्य: < १४० mg/dL; मधुमेह निर्देशक: ≥ २०० mg/dL.',
        },
        {
          testName: 'Urine Microalbumin & Protein',
          clinicalMeaning:
            'Screens for early microscopic kidney filtering damage (diabetic nephropathy) before gross proteinuria appears.',
          clinicalMeaningHi:
            'गुर्दे (किडनी) के शुरुआती नुकसान (डायबिटिक नेफ्रोपैथी) की पहचान के लिए यूरिन माइक्रोएल्ब्यूमिन की जांच की जाती है।',
          clinicalMeaningMr:
            'किडनीच्या सुरुवातीच्या नुकसानाची (डायबेटिक नेफ्रोपॅथी) लवकर तपासणी करण्यासाठी मूत्रातील मायक्रोअल्ब्युमिन तपासले जाते.',
        },
        {
          testName: 'Lipid Panel (Total Cholesterol, Triglycerides, LDL, HDL)',
          clinicalMeaning:
            'Assesses cardiovascular risk co-morbidities frequently accelerated by insulin resistance and hyperglycemia.',
          clinicalMeaningHi:
            'इंसुलिन प्रतिरोध और उच्च शर्करा के साथ जुड़े हृदय रोगों के जोखिम का मूल्यांकन करने के लिए लिपिड प्रोफाइल की जांच की जाती है।',
          clinicalMeaningMr:
            'इन्सुलिन प्रतिरोधामुळे वाढणाऱ्या हृदयविकाराच्या जोखमीचे मूल्यांकन करण्यासाठी लिपिड प्रोफाइल तपासले जाते.',
        },
      ],
      complications: [
        'Cardiovascular Disease: Dramatically accelerated atherosclerosis, 2x to 4x increased risk of coronary artery disease, heart attacks, and ischemic strokes.',
        'Diabetic Nephropathy: Chronic microvascular damage to renal glomeruli, which can progress to chronic kidney disease and end-stage renal failure.',
        'Diabetic Neuropathy: Peripheral nerve damage leading to burning pain, numbness, foot ulcers, and autonomic neuropathy affecting digestion and heart rate.',
        'Diabetic Retinopathy: Retinal capillary damage and macular edema, leading cause of preventable adult blindness.',
        'Diabetic Foot Complications: Impaired microcirculation and peripheral sensory loss leading to non-healing ulcers and severe infections.',
      ],
      complicationsHi: [
        'हृदय रोग: धमनियों का संकुचित होना, दिल का दौरा (हार्ट अटैक) और स्ट्रोक का 2 से 4 गुना बढ़ा हुआ जोखिम।',
        'डायबिटिक नेफ्रोपैथी (किडनी रोग): गुर्दों की सूक्ष्म रक्त वाहिकाओं का नुकसान, जो किडनी फेलियर तक पहुंच सकता है।',
        'डायबिटिक न्यूरोपैथी (नसों का नुकसान): पैरों में जलन, सुन्नता, घाव और नसों में दर्द।',
        'डायबिटिक रेटिनोपैथी (आंखों का नुकसान): रेटिना की रक्त वाहिकाओं का नुकसान, जिससे दृष्टि कमजोर या समाप्त हो सकती है।',
        'डायबिटिक फुट सिंड्रोम: पैरों में रक्त प्रवाह की कमी और सुन्नता के कारण घाव न भरना और संक्रमण का खतरा।',
      ],
      complicationsMr: [
        'हृदयविकार: रक्तवाहिन्या अरुंद होणे, ज्यामुळे हृदयविकाराचा झटका (हार्ट अटॅक) आणि स्ट्रोकचा धोका २ ते ४ पटीने वाढतो.',
        'डायबेटिक नेफ्रोपॅथी (किडनीचे आजार): मूत्रपिंडांच्या सूक्ष्म रक्तवाहिन्यांचे नुकसान, ज्यामुळे किडनी निकामी होण्याचा धोका संभवतो.',
        'डायबेटिक न्यूरोपॅथी (मज्जातंतूंचे नुकसान): पायांमध्ये जळजळ, बधीरपणा, सतत मुंग्या येणे आणि जखमा न भरणे.',
        'डायबेटिक रेटिनोपॅथी (डोळ्यांचे विकार): डोळ्यांच्या पडद्याचे नुकसान, ज्यामुळे दृष्टी कमी होण्याचा किंवा अंधत्वाचा धोका असतो.',
        'डायबेटिक फूट: पायातील रक्तप्रवाह कमी झाल्यामुळे न भरणारे अल्सर आणि गंभीर संसर्ग होणे.',
      ],
      preventionAndLifestyle: [
        'Balanced Medical Nutrition Therapy: Prioritize dietary fiber (vegetables, whole pulses, legumes, seeds), lean proteins, and unsaturated healthy fats while eliminating sugar-sweetened beverages and refined carbohydrates.',
        'Regular Physical Activity: At least 150 minutes per week of moderate-intensity aerobic exercise (e.g. brisk walking, cycling, swimming) combined with 2–3 resistance training sessions.',
        'Weight Management: Modest, sustainable weight reduction (5%–10% of total body weight) significantly restores insulin sensitivity.',
        'Stress Regulation & Restorative Sleep: Chronic cortisol elevation elevates blood glucose; aim for 7–8 hours of consistent nightly sleep.',
        'Structured Glycemic Monitoring: Tracking blood glucose patterns helps identify dietary triggers and informs personalized clinical management.',
      ],
      preventionAndLifestyleHi: [
        'संतुलित पोषण आहार: फाइबर युक्त खाद्य पदार्थ (हरी सब्जियां, साबुत दालें, मेवे), प्रोटीन को प्राथमिकता दें और मीठे पेय तथा रिफाइंड कार्बोहाइड्रेट से बचें।',
        'नियमित शारीरिक व्यायाम: प्रति सप्ताह कम से कम 150 मिनट मध्यम एरोबिक व्यायाम (जैसे तेज चलना, साइकिल चलाना) और हल्का वजन प्रशिक्षण।',
        'वजन नियंत्रण: शरीर के कुल वजन में 5% से 10% की कमी भी इंसुलिन संवेदनशीलता में उल्लेखनीय सुधार करती है।',
        'तनाव प्रबंधन और पर्याप्त नींद: तनाव कम करें और रात में 7 से 8 घंटे की गहरी नींद लें।',
        'नियमित ग्लूकोज की निगरानी: डॉक्टर के निर्देशानुसार समय-समय पर रक्त शर्करा की जांच करना।',
      ],
      preventionAndLifestyleMr: [
        'संतुलित आहार: आहारात फायबरयुक्त अन्न (हिरव्या भाज्या, कडधान्ये, बिया), प्रथिने यांचा समावेश करा आणि गोड पेये व मैद्याचे पदार्थ टाळा.',
        'नियमित व्यायाम: दर आठवड्याला किमान १५० मिनिटे मध्यम स्वरूपाचा एरोबिक व्यायाम (उदा. जलद चालणे, पोहणे) आणि हलके वजन उचलणे.',
        'वजन नियंत्रण: शरीराचे वजन ५% ते १०% कमी केल्यास इन्सुलिनच्या संवेदनशीलतेत लक्षणीय सुधारणा होते.',
        'तणावमुक्ती आणि पुरेशी झोप: मानसिक तणाव कमी ठेवा आणि दररोज रात्री ७ ते ८ तास शांत झोप घ्या.',
        'नियमित साखरेची तपासणी: डॉक्टरांच्या मार्गदर्शनानुसार रक्तातील साखरेची नियमित नोंद ठेवा.',
      ],
      treatmentApproaches: [
        'Comprehensive Lifestyle Intervention: First-line cornerstone for all individuals with glycemic dysregulation.',
        'Oral Antihyperglycemic Medications: Prescribed by a licensed physician when lifestyle modifications alone are insufficient (e.g. insulin sensitizers, SGLT2 inhibitors, GLP-1 receptor agonists, DPP-4 inhibitors).',
        'Insulin Therapy: Essential for type 1 diabetes and utilized in type 2 diabetes when progressive pancreatic beta-cell depletion requires exogenous glycemic control.',
        'Cardiovascular Risk Co-Management: Aggressive blood pressure control (target < 130/80 mmHg) and lipid-lowering therapy as clinically indicated.',
        'Continuous Health Literacy & Diabetes Self-Management Education (DSMES).',
      ],
      treatmentApproachesHi: [
        'जीवनशैली में व्यापक बदलाव: रक्त शर्करा प्रबंधन की पहली और सबसे महत्वपूर्ण नींव।',
        'मौखिक दवाएं (Oral Medications): जब केवल जीवनशैली पर्याप्त न हो, तब केवल योग्य चिकित्सक के परामर्श पर दवाएं दी जाती हैं।',
        'इंसुलिन थेरेपी: टाइप 1 के लिए अनिवार्य और टाइप 2 में आवश्यकता पड़ने पर डॉक्टर द्वारा निर्धारित।',
        'हृदय सुरक्षा और रक्तचाप नियंत्रण: रक्तचाप और कोलेस्ट्रॉल का उचित प्रबंधन।',
        'स्वयं-प्रबंधन और सतत स्वास्थ्य शिक्षा।',
      ],
      treatmentApproachesMr: [
        'जीवनशैलीतील सर्वसमावेशक बदल: रक्त शर्करा नियंत्रणाचा पहिला आणि मूलभूत पाया.',
        'तोंडी औषधे: केवळ जीवनशैलीतील बदल पुरेसे नसताना परवानाधारक डॉक्टरांच्या सल्ल्याने औषधे सुरू करणे.',
        'इन्सुलिन थेरपी: टाइप १ साठी अत्यावश्यक आणि टाइप २ मध्ये आवश्यकतेनुसार तज्ज्ञांकडून दिली जाणारी थेरपी.',
        'रक्तदाब आणि कोलेस्ट्रॉलचे नियंत्रण: हृदयाचे रक्षण करण्यासाठी इतर घटकांचे व्यवस्थापन करणे.',
        'मधुमेह स्व-व्यवस्थापन शिक्षण आणि जागरूकता.',
      ],
      whenToSeeDoctor: [
        'Fasting blood glucose repeatedly exceeding 100 mg/dL, or random readings exceeding 180 mg/dL.',
        'Presence of classic osmotic symptoms (unquenchable thirst, frequent nocturnal urination, rapid unexplained weight loss).',
        'Any slow-healing cut, foot sore, blister, or skin infection.',
        'Frequent dizzy spells, shakiness, confusion, or cold sweats (concerning for hypoglycemia).',
        'Sudden changes in visual acuity, persistent blurred vision, or eye pain.',
        'Before starting any new exercise program, drastic diet change, or supplement regimen.',
      ],
      whenToSeeDoctorHi: [
        'फास्टिंग ब्लड ग्लूकोज लगातार 100 mg/dL से अधिक या रैंडम 180 mg/dL से अधिक आना।',
        'अत्यधिक प्यास, बार-बार पेशाब और तेजी से वजन घटने जैसे लक्षण दिखना।',
        'पैरों में कोई भी कट, छाला, घाव या संक्रमण जो आसानी से ठीक न हो रहा हो।',
        'चक्कर आना, कंपकंपी, पसीना या घबराहट महसूस होना (अल्प शर्करा/हाइपोग्लाइसीमिया का संकेत)।',
        'दृष्टि में अचानक धुंधलापन या आंखों में दर्द महसूस होना।',
        'कोई भी नया आहार, व्यायाम या दवा शुरू करने से पहले हमेशा डॉक्टर से मिलें।',
      ],
      whenToSeeDoctorMr: [
        'फास्टिंग रक्त शर्करा वारंवार १०० mg/dL पेक्षा जास्त किंवा इतर वेळी १८० mg/dL पेक्षा जास्त आढळल्यास.',
        'सतत तहान लागणे, वारंवार लघवी आणि जलद गतीने वजन कमी होणे अशी लक्षणे दिसल्यास.',
        'पायावर कोणतीही जखम, फोड किंवा संसर्ग जो लवकर भरून येत नाही.',
        'चक्कर येणे, थरथरणे, अचानक घाम येणे (कमी साखरेचे लक्षण) जाणवल्यास.',
        'दृष्टीमध्ये अचानक बदल किंवा धूसरपणा आल्यास.',
        'कोणताही नवीन आहार, व्यायाम किंवा पूरक औषध सुरू करण्यापूर्वी डॉक्टरांचा सल्ला घ्या.',
      ],
      additionalEducationalNotes:
        'Understanding your blood reports empowers you to have meaningful, informed discussions with your physician. Remember that biomarkers fluctuate based on stress, hydration, recent meals, illness, and laboratory calibration. A single elevated lab value is an invitation for clinical dialogue, not a final clinical verdict.',
      additionalEducationalNotesHi:
        'अपनी रक्त रिपोर्ट को समझना आपको अपने डॉक्टर के साथ सार्थक और सूचित चर्चा करने में सक्षम बनाता है। ध्यान रखें कि बायोमार्कर तनाव, पानी की मात्रा, हाल के भोजन और बीमारी के अनुसार बदल सकते हैं। एक बार का बढ़ा हुआ मान चिकित्सीय चर्चा के लिए एक संकेत है, अंतिम निर्णय नहीं।',
      additionalEducationalNotesMr:
        'तुमचा रक्त तपासणी अहवाल समजून घेतल्याने तुम्हाला डॉक्टरांशी सविस्तर आणि माहितीपूर्ण चर्चा करता येते. लक्षात ठेवा की तणाव, पाण्याची पातळी, अलीकडील आहार आणि आजारपण यानुसार बायोमार्कर्स बदलू शकतात. एक असामान्य मूल्य ही डॉक्टरांशी सल्लामसलत करण्याची संधी आहे, अंतिम निर्णय नाही.',
    },
  },
  anemia: {
    conditionIdentified: true,
    conditionName: 'Anemia / Decreased Hemoglobin & RBC Capacity',
    conditionNameHi: 'एनीमिया (रक्ताल्पता) / हीमोग्लोबिन की कमी',
    conditionNameMr: 'अ‍ॅनिमिया (रक्तक्षय) / हिमोग्लोबिनची कमतरता',
    relevanceExplanation:
      'Identified based on complete blood count (CBC) biomarkers such as Hemoglobin (Hb), Hematocrit (PCV), Red Blood Cell (RBC) count, MCV, MCH, or Ferritin levels.',
    relevanceExplanationHi:
      'पूर्ण रक्त गणना (CBC) बायोमार्कर जैसे हीमोग्लोबिन (Hb), हेमटोक्रिट (PCV), लाल रक्त कोशिका (RBC) संख्या, MCV, MCH या फेरिटिन स्तरों के आधार पर पहचाना गया।',
    relevanceExplanationMr:
      'संपूर्ण रक्त गणना (CBC) बायोमार्कर्स जसे की हिमोग्लोबिन (Hb), हेमेटोक्रिट (PCV), तांबड्या रक्तपेशींची संख्या (RBC), MCV किंवा फेरिटिनच्या पातळीच्या आधारे ओळखले गेले.',
    retrievalSuccess: true,
    trustedSources: [
      {
        name: 'World Health Organization (WHO)',
        organizationType: 'United Nations Specialized Agency for Global Health',
        url: 'https://www.who.int/news-room/fact-sheets/detail/anaemia',
        topicTitle: 'WHO Global Anaemia Fact Sheet: Diagnostic Cut-Offs, Causes, and Prevention',
        retrievedAt: new Date().toISOString(),
      },
      {
        name: 'National Heart, Lung, and Blood Institute (NHLBI / NIH)',
        organizationType: 'National Institutes of Health (NIH)',
        url: 'https://www.nhlbi.nih.gov/health/anemia',
        topicTitle: 'NHLBI Anemia Health Information: Symptoms, Causes, and Blood Testing',
        retrievedAt: new Date().toISOString(),
      },
      {
        name: 'Centers for Disease Control and Prevention (CDC)',
        organizationType: 'U.S. Public Health Agency',
        url: 'https://www.cdc.gov/nchs/fastats/anemia.htm',
        topicTitle: 'CDC Anemia Clinical Indicators and Nutritional Surveillance',
        retrievedAt: new Date().toISOString(),
      },
    ],
    educationalContent: {
      overview:
        'Anemia is a clinical condition characterized by a deficiency in the number or quality of red blood cells (erythrocytes) or their oxygen-carrying protein, hemoglobin. When hemoglobin is low, the body’s tissues receive insufficient oxygenation (hypoxia), resulting in chronic fatigue, pallor, and reduced functional stamina.',
      overviewHi:
        'एनीमिया (रक्ताल्पता) एक चिकित्सीय स्थिति है जिसमें लाल रक्त कोशिकाओं या उनके ऑक्सीजन ले जाने वाले प्रोटीन, हीमोग्लोबिन की संख्या या गुणवत्ता में कमी हो जाती है। जब हीमोग्लोबिन कम होता है, तो शरीर के अंगों को पर्याप्त ऑक्सीजन नहीं मिल पाती है, जिससे थकान और कमजोरी होती है।',
      overviewMr:
        'अ‍ॅनिमिया (रक्तक्षय) ही अशी स्थिती आहे ज्यामध्ये तांबड्या रक्तपेशींची संख्या किंवा ऑक्सिजन वाहून नेणाऱ्या हिमोग्लोबिन प्रथिनांचे प्रमाण कमी होते. हिमोग्लोबिन कमी असल्यामुळे शरीरातील अवयवांना पुरेसा ऑक्सिजन मिळत नाही, ज्यामुळे तीव्र थकवा आणि अशक्तपणा जाणवतो.',
      types: [
        'Iron Deficiency Anemia: The most common type globally, caused by insufficient dietary iron, poor iron absorption, or chronic blood loss.',
        'Vitamin Deficiency Anemia (Megaloblastic): Caused by a deficiency in Vitamin B12 or Folate (Vitamin B9), leading to abnormally large, fragile red blood cells.',
        'Anemia of Chronic Disease: Associated with chronic inflammation, autoimmune disorders, or chronic kidney disease that impairs erythropoiesis.',
        'Hemolytic Anemia: Premature destruction of red blood cells before their normal 120-day lifespan.',
        'Aplastic Anemia: Rare condition where bone marrow stem cells fail to generate sufficient new blood cells.',
      ],
      typesHi: [
        'आयरन की कमी से एनीमिया: दुनिया भर में सबसे आम, अपर्याप्त आहार, खराब अवशोषण या रक्त की हानि के कारण होता है।',
        'विटामिन की कमी से एनीमिया (मेगालोब्लास्टिक): विटामिन B12 या फोलेट (विटामिन B9) की कमी के कारण लाल रक्त कोशिकाएं असामान्य रूप से बड़ी हो जाती हैं।',
        'दीर्घकालिक बीमारी का एनीमिया: लंबे समय तक चलने वाली सूजन, किडनी रोग या संक्रमण से संबंधित।',
        'हेमोलिटिक एनीमिया: जब लाल रक्त कोशिकाएं अपने सामान्य जीवनकाल से पहले नष्ट हो जाती हैं।',
        'एप्लास्टिक एनीमिया: अस्थिमज्जा (बोन मैरो) द्वारा पर्याप्त रक्त कोशिकाओं का उत्पादन न कर पाना।',
      ],
      typesMr: [
        'लोहाच्या कमतरतेमुळे होणारा अ‍ॅनिमिया: जगभरात सर्वात सामान्य, आहारातील लोहाची कमतरता किंवा अंतर्गत रक्तस्रावामुळे होतो.',
        'जीवनसत्वाच्या कमतरतेमुळे होणारा अ‍ॅनिमिया: व्हिटॅमिन बी१२ किंवा फॉलिक अ‍ॅसिडच्या कमतरतेमुळे मोठ्या आणि कमकुवत रक्तपेशी तयार होतात.',
        'दीर्घकालीन आजारांचा अ‍ॅनिमिया: दीर्घकालीन दाह, मूत्रपिंडाचे आजार यामुळे रक्तनिर्मिती कमी होते.',
        'हेमोलाइटिक अ‍ॅनिमिया: तांबड्या रक्तपेशी त्यांच्या नैसर्गिक कालावधीपूर्वीच नष्ट होणे.',
        'अप्लास्टिक अ‍ॅनिमिया: हाडांमधील मज्जा (बोन मॅरो) पुरेशा रक्तपेशी तयार करू शकत नाही.',
      ],
      causesAndRisks: [
        'Nutritional Deficiencies: Inadequate dietary intake of iron, Vitamin B12, or Folate.',
        'Blood Loss: Heavy menstrual bleeding, gastrointestinal bleeding (ulcers, hemorrhoids, polyp), or frequent blood donation.',
        'Impaired Absorption: Conditions like celiac disease, inflammatory bowel disease (Crohn’s), or history of gastric bypass surgery.',
        'Pregnancy: Increased maternal blood volume and fetal iron demands.',
        'Chronic Illnesses: Chronic kidney disease (low erythropoietin production), rheumatoid arthritis, or thyroid disease.',
      ],
      causesAndRisksHi: [
        'पोषण संबंधी कमियां: आहार में आयरन, विटामिन B12 या फोलिक एसिड की कमी।',
        'रक्त की हानि: महिलाओं में अत्यधिक मासिक धर्म, पेट में अल्सर या बवासीर से रक्तस्राव।',
        'खराब आंतों का अवशोषण: सीलिएक रोग या आंतों की सूजन संबंधी बीमारियां।',
        'गर्भावस्था: भ्रूण के विकास और रक्त की बढ़ी हुई आवश्यकता।',
        'दीर्घकालिक रोग: गुर्दे की बीमारी (एरिथ्रोपोइटिन हार्मोन की कमी) या थायरॉइड विकार।',
      ],
      causesAndRisksMr: [
        'आहारातील कमतरता: आहारात लोह, व्हिटॅमिन बी१२ किंवा फॉलेटची अपुरी उपलब्धता.',
        'रक्तस्त्राव: महिलांमध्ये अतिमासिक पाळी, पोटातील अल्सर किंवा मूळव्याध यामुळे होणारा रक्तस्त्राव.',
        'पचनसंस्थेतील शोषण कमी असणे: आतड्यांचे आजार ज्यामुळे पोषक तत्वे नीट शोषली जात नाहीत.',
        'गर्भधारणा: गर्भाच्या वाढीसाठी आणि आईच्या शरीरासाठी लोहाची जास्त गरज असणे.',
        'दीर्घकालीन आजार: किडनीचे आजार किंवा थायरॉईडच्या तक्रारी.',
      ],
      signsAndSymptoms: [
        'Persistent Fatigue and Weakness: Disproportionate exhaustion during routine tasks.',
        'Pale Skin and Conjunctiva: Noticeable paleness of the inner eyelids, gums, nails, and skin.',
        'Dyspnea: Shortness of breath on mild exertion.',
        'Tachycardia: Fast or pounding heart palpitations as the heart works harder to circulate oxygen.',
        'Cold Extremities: Chronic cold hands and feet due to reduced peripheral circulation.',
        'Dizziness or Lightheadedness, especially upon standing up quickly.',
        'Brittle Nails (Koilonychia) or Pica (unusual cravings for ice, dirt, or clay).',
      ],
      signsAndSymptomsHi: [
        'लगातार थकान और कमजोरी: सामान्य काम करने पर भी अत्यधिक थकावट महसूस होना।',
        'त्वचा और आंखों में पीलापन: निचली पलकों के अंदर, मसूड़ों और नाखूनों का पीला दिखना।',
        'सांस फूलना: थोड़ा सा चलने या सीढ़ियां चढ़ने पर सांस लेने में कठिनाई होना।',
        'दिल की धड़कन तेज होना: ऑक्सीजन पहुंचाने के लिए दिल को अधिक मेहनत करनी पड़ती है।',
        'हाथ और पैर ठंडे रहना।',
        'सिर चकराना या उठते समय चक्कर आना।',
        'नाखूनों का कमजोर और चम्मच के आकार का होना, या बर्फ/मिट्टी खाने की असामान्य इच्छा।',
      ],
      signsAndSymptomsMr: [
        'सतत थकवा आणि अशक्तपणा: दैनंदिन कामे करतानाही तीव्र थकवा जाणवणे.',
        'त्वचा आणि डोळ्यांचा फिकटपणा: डोळ्यांच्या पापण्यांचा आतील भाग, नखे आणि जीभ फिकट दिसणे.',
        'श्वास लागणे: थोडे चालल्यावर किंवा पायऱ्या चढताना दम लागणे.',
        'हृदयाचे ठोके जलद होणे किंवा धडधड जाणवणे.',
        'हात आणि पाय सतत थंड पडणे.',
        'चक्कर येणे किंवा अचानक उठून उभे राहिल्यावर डोळ्यांसमोर अंधारी येणे.',
        'नखे ठिसूळ होणे आणि बर्फ किंवा माती खाण्याची अस्वाभाविक इच्छा होणे.',
      ],
      diagnosisOverview:
        'Diagnosed via Complete Blood Count (CBC) with standard WHO diagnostic thresholds for venous hemoglobin: Men < 13.0 g/dL; Non-pregnant women < 12.0 g/dL; Pregnant women < 11.0 g/dL. Red cell indices (MCV, MCH, RDW), serum ferritin, transferrin saturation, and peripheral blood smear examinations clarify the underlying etiology.',
      diagnosisOverviewHi:
        'पूर्ण रक्त गणना (CBC) द्वारा निदान किया जाता है। WHO के अनुसार हीमोग्लोबिन की सामान्य सीमा: पुरुषों में < 13.0 g/dL; महिलाओं में < 12.0 g/dL; गर्भवती महिलाओं में < 11.0 g/dL होने पर एनीमिया माना जाता है। MCV, MCH, सीरम फेरिटिन और पेरिफेरल स्मीयर से एनीमिया के प्रकार की पुष्टि होती है।',
      diagnosisOverviewMr:
        'संपूर्ण रक्त तपासणी (CBC) द्वारे निदान केले जाते. WHO मानकांनुसार हिमोग्लोबिनची पातळी: पुरुषांमध्ये < १३.० g/dL; महिलांमध्ये < १२.० g/dL; गर्भवती महिलांमध्ये < ११.० g/dL पेक्षा कमी असल्यास अ‍ॅनिमिया मानला जातो. MCV, MCH आणि फेरिटिन चाचणीद्वारे त्याचे नेमके कारण शोधले जाते.',
      relevantTestsAndMeaning: [
        {
          testName: 'Hemoglobin (Hb)',
          clinicalMeaning:
            'Measures the concentration of the primary oxygen-carrying metalloprotein inside red blood cells.',
          clinicalMeaningHi: 'लाल रक्त कोशिकाओं के अंदर ऑक्सीजन ले जाने वाले मुख्य प्रोटीन की सांद्रता को मापता है।',
          clinicalMeaningMr: 'तांबड्या रक्तपेशींमधील ऑक्सिजन वाहून नेणाऱ्या मुख्य प्रथिनाचे प्रमाण मोजते.',
        },
        {
          testName: 'Mean Corpuscular Volume (MCV)',
          clinicalMeaning:
            'Measures average red blood cell size. Low MCV (< 80 fL) indicates microcytic anemia (iron deficiency, thalassemia); High MCV (> 100 fL) indicates macrocytic anemia (B12/folate deficiency).',
          clinicalMeaningHi:
            'लाल रक्त कोशिकाओं के औसत आकार को मापता है। कम मान आयरन की कमी को दर्शाता है, जबकि अधिक मान विटामिन B12 की कमी को दर्शाता है।',
          clinicalMeaningMr:
            'तांबड्या रक्तपेशींचा सरासरी आकार मोजते. कमी मूल्य लोहाच्या कमतरतेकडे निर्देश करते, तर जास्त मूल्य व्हिटॅमिन बी१२ च्या अभावाकडे निर्देश करते.',
        },
        {
          testName: 'Serum Ferritin',
          clinicalMeaning:
            'Measures total cellular iron storage pools in the body; the single most sensitive biomarker for early iron deficiency.',
          clinicalMeaningHi: 'शरीर में संचित कुल आयरन की मात्रा को मापता है; आयरन की कमी की पहचान का सबसे संवेदनशील परीक्षण।',
          clinicalMeaningMr: 'शरीरात साठवून ठेवलेल्या लोहाचे प्रमाण मोजते; लोहाची कमतरता ओळखण्यासाठी सर्वात अचूक चाचणी.',
        },
        {
          testName: 'Vitamin B12 and Folate Levels',
          clinicalMeaning:
            'Essential co-factors for nuclear DNA synthesis and proper red blood cell maturation in the bone marrow.',
          clinicalMeaningHi: 'अस्थिमज्जा में स्वस्थ लाल रक्त कोशिकाओं के निर्माण के लिए आवश्यक विटामिन का स्तर।',
          clinicalMeaningMr: 'रक्तपेशींच्या योग्य वाढीसाठी आणि डीएनए निर्मितीसाठी आवश्यक जीवनसत्त्वे मोजते.',
        },
      ],
      complications: [
        'Cardiovascular Strain: Chronic compensatory tachycardia can lead to left ventricular hypertrophy and high-output heart failure.',
        'Pregnancy Complications: Substantially elevated risk of preterm delivery, low birth weight, and postpartum hemorrhage.',
        'Impaired Cognitive Function: Reduced concentration, memory impairment, and diminished productivity.',
        'Susceptibility to Infections: Iron and B12 deficits compromise cellular immune defense.',
      ],
      complicationsHi: [
        'हृदय पर अत्यधिक दबाव: ऑक्सीजन की कमी पूरी करने के लिए दिल को तेज धड़कना पड़ता है, जिससे हृदय दुर्बल हो सकता है।',
        'गर्भावस्था की जटिलताएं: समय से पहले प्रसव, शिशु का कम वजन और प्रसव के दौरान जोखिम।',
        'मानसिक सतर्कता और ध्यान में कमी: याददाश्त और सीखने की क्षमता पर प्रतिकूल प्रभाव।',
        'संक्रमण के प्रति संवेदनशीलता: रोग प्रतिरोधक क्षमता में कमी आना।',
      ],
      complicationsMr: [
        'हृदयावर अतिरिक्त ताण: सतत जास्त काम करावे लागल्याने हृदयाचे स्नायू कमकुवत होण्याचा धोका.',
        'गर्भधारणेतील धोके: मुदतीपूर्वी प्रसूती, नवजात बाळाचे वजन कमी असणे आणि इतर गुंतागुंत.',
        'एकाग्रता आणि स्मरणात घट: कामातील उत्पादकता आणि मानसिक कार्यक्षमतेवर परिणाम.',
        'संसर्गाची शक्यता वाढणे: रोगप्रतिकारशक्ती क्षीण होणे.',
      ],
      preventionAndLifestyle: [
        'Iron-Rich Foods: Incorporate dark green leafy vegetables (spinach, methi), lentils, beans, chickpeas, beetroot, pomegranate, sesame seeds, and lean meats.',
        'Vitamin C Enhancement: Consume citrus fruits, amla, lemon, and tomatoes alongside iron-rich meals to enhance non-heme iron absorption.',
        'Avoid Iron Inhibitors at Meals: Refrain from drinking tea or coffee within 1 hour of meals, as tannins and polyphenols bind iron.',
        'Vitamin B12 Sources: Dairy products, eggs, fortified cereals, or clinical supplements for strict vegetarians.',
      ],
      preventionAndLifestyleHi: [
        'आयरन युक्त आहार: हरी पत्तेदार सब्जियां (पालक, मेथी), दालें, छोले, चुकंदर, अनार, तिल और सूखे मेवे।',
        'विटामिन C का साथ: आयरन के बेहतर अवशोषण के लिए भोजन के साथ नींबू, आंवला या संतरे का सेवन करें।',
        'चाय-कॉफी से परहेज: भोजन के तुरंत पहले या बाद में चाय या कॉफी न पिएं, क्योंकि ये आयरन के अवशोषण को रोकते हैं।',
        'विटामिन B12 के स्रोत: दूध, दही, पनीर, अंडे और पोषण युक्त अनाज।',
      ],
      preventionAndLifestyleMr: [
        'लोहयुक्त अन्न: पालेभाज्या (पालक, मेथी), डाळी, कडधान्ये, बीट, डाळिंब, तीळ आणि खजूर यांचा आहारात समावेश करा.',
        'व्हिटॅमिन सी चे सेवन: लोहाचे शोषण वाढवण्यासाठी जेवणासोबत लिंबू, आवळा किंवा संत्री खा.',
        'जेवणादरम्यान चहा-कॉफी टाळा: चहामधील टॅनिनमुळे लोहाचे शोषण थांबते, त्यामुळे जेवणानंतर किमान १ तास चहा पिऊ नये.',
        'व्हिटॅमिन बी१२ चे स्रोत: दूध, दही, ताक, अंडी आणि फोर्टिफाइड धान्ये.',
      ],
      treatmentApproaches: [
        'Targeted Nutritional Repletion: Address dietary gaps under registered dietitian guidance.',
        'Oral Iron Therapy: Ferrous sulfate, ascorbate, or bisglycinate prescribed by a doctor when clinical stores are depleted.',
        'Vitamin B12 Injections or High-Dose Oral Therapy for pernicious or megaloblastic anemia.',
        'Treatment of Root Causes: Addressing underlying menstrual dysregulation, peptic ulcers, or parasitic infections.',
      ],
      treatmentApproachesHi: [
        'लक्षित पोषण सुधार: आहार विशेषज्ञ के मार्गदर्शन में आहार में बदलाव।',
        'आयरन की दवाएं: केवल डॉक्टर के पर्चे पर फेरस सल्फेट या उपयुक्त सप्लीमेंट्स का सेवन।',
        'विटामिन B12 इंजेक्शन या गोलियां जब कमी अत्यधिक हो।',
        'मूल कारणों का उपचार: पेट में रक्तस्राव, बवासीर या अत्यधिक मासिक धर्म का चिकित्सकीय इलाज।',
      ],
      treatmentApproachesMr: [
        'आहारातील योग्य बदल: तज्ज्ञांच्या सल्ल्याने आवश्यक पोषक घटकांची पूर्तता.',
        'लोहाच्या गोळ्या: डॉक्टरांच्या सल्ल्यानुसार योग्य स्वरूपातील आयर्न सप्लिमेंट्स घेणे.',
        'व्हिटॅमिन बी१२ च्या गोळ्या किंवा इंजेक्शन्स.',
        'मूळ कारणांचा उपचार: अंतर्गत रक्तस्राव किंवा मासिक पाळीच्या समस्यांचे वैद्यकीय निराकरण करणे.',
      ],
      whenToSeeDoctor: [
        'Hemoglobin below 10 g/dL or rapid unexplained drop in blood counts.',
        'Chest discomfort, severe shortness of breath at rest, or fainting spells.',
        'Noticeable blood in stool (black/tarry stools) or vomit.',
        'Severe fatigue that interferes with basic daily activities.',
      ],
      whenToSeeDoctorHi: [
        'हीमोग्लोबिन 10 g/dL से नीचे आना या रक्त गणना में तेजी से गिरावट।',
        'छाती में दर्द, आराम करने पर भी सांस फूलना या बेहोशी आना।',
        'मल में खून आना या काला मल होना।',
        'अत्यधिक थकान जो दैनिक जीवन को प्रभावित कर रही हो।',
      ],
      whenToSeeDoctorMr: [
        'हिमोग्लोबिन १० g/dL पेक्षा कमी झाल्यास किंवा वेगाने घसरत असल्यास.',
        'छातीत दुखणे, विश्रांती घेतानाही श्वास घेण्यास त्रास होणे किंवा भोवळ येणे.',
        'शौचावाटे रक्त येणे किंवा काळसर शौच होणे.',
        'तीव्र थकव्यामुळे रोजची कामे करणे अशक्य वाटणे.',
      ],
      additionalEducationalNotes:
        'Over-the-counter iron supplements should never be taken without confirmation of iron status via serum ferritin, as conditions like Thalassemia or Hemochromatosis present with low hemoglobin or high iron stores where iron supplementation can cause toxicity.',
      additionalEducationalNotesHi:
        'सीरम फेरिटिन की पुष्टि के बिना कभी भी अपने आप आयरन की गोलियां न लें, क्योंकि थैलेसीमिया जैसी स्थितियों में हीमोग्लोबिन कम होने पर भी आयरन अधिक हो सकता है, जहां अतिरिक्त आयरन हानिकारक होता है।',
      additionalEducationalNotesMr:
        'फेरिटिन तपासल्याशिवाय परस्पर लोहाच्या गोळ्या घेऊ नयेत, कारण थॅलेसेमियासारख्या विकारात हिमोग्लोबिन कमी असले तरी शरीरात लोह जास्त असू शकते, जे शरीरासाठी घातक ठरू शकते.',
    },
  },
  routine: {
    conditionIdentified: true,
    conditionName: 'Routine Preventive Biomarker & Organ Screening',
    conditionNameHi: 'नियमित निवारक बायोमार्कर और स्वास्थ्य जांच',
    conditionNameMr: 'नियमित प्रतिबंधात्मक बायोमार्कर आणि आरोग्य तपासणी',
    relevanceExplanation:
      'Evaluates general metabolic balance, complete blood count, and organ system profiles (kidney, liver, lipids, glucose) for proactive preventive health maintenance.',
    relevanceExplanationHi:
      'सक्रिय निवारक स्वास्थ्य रखरखाव के लिए सामान्य चयापचय संतुलन, पूर्ण रक्त गणना और अंग प्रणाली प्रोफाइल (किडनी, लीवर, लिपिड, ग्लूकोज) का मूल्यांकन करता है।',
    relevanceExplanationMr:
      'सक्रिय आरोग्य सुरक्षेसाठी शरीराचे चयापचय संतुलन, रक्त गणना आणि प्रमुख अवयव प्रोफाइल (किडनी, यकृत, लिपिड, ग्लुकोज) चे मूल्यांकन करते.',
    retrievalSuccess: true,
    trustedSources: [
      {
        name: 'World Health Organization (WHO)',
        organizationType: 'United Nations Specialized Agency for Global Public Health',
        url: 'https://www.who.int/health-topics/noncommunicable-diseases',
        topicTitle: 'WHO Noncommunicable Disease Prevention and Routine Health Screening Guidelines',
        retrievedAt: new Date().toISOString(),
      },
      {
        name: 'Centers for Disease Control and Prevention (CDC)',
        organizationType: 'U.S. National Public Health Institute',
        url: 'https://www.cdc.gov/prevention/index.html',
        topicTitle: 'CDC Regular Health Checkups, Clinical Screening Schedules, and Biomarkers',
        retrievedAt: new Date().toISOString(),
      },
      {
        name: 'National Institutes of Health (MedlinePlus / NIH)',
        organizationType: 'National Library of Medicine',
        url: 'https://medlineplus.gov/lab-tests/',
        topicTitle: 'NIH Guide to Understanding Clinical Laboratory Tests and Biological Reference Intervals',
        retrievedAt: new Date().toISOString(),
      },
    ],
    educationalContent: {
      overview:
        'Routine preventive medical checkups evaluate early biochemical and cellular shifts before clinical symptoms develop. Monitoring baseline organ functions—such as blood counts, glycemic control, renal filtration, liver enzymes, and lipid profiles—empowers proactive lifestyle adjustments and disease prevention.',
      overviewHi:
        'नियमित निवारक स्वास्थ्य जांच नैदानिक लक्षण विकसित होने से पहले प्रारंभिक जैव रासायनिक परिवर्तनों का मूल्यांकन करती है। रक्त गणना, शर्करा, गुर्दे, लीवर और कोलेस्ट्रॉल जैसे बुनियादी मापदंडों की निगरानी सक्रिय स्वास्थ्य सुरक्षा सुनिश्चित करती है।',
      overviewMr:
        'नियमित प्रतिबंधात्मक आरोग्य तपासणी कोणतीही लक्षणे दिसण्यापूर्वीच शरीरातील सूक्ष्म बदल ओळखण्यास मदत करते. रक्तपेशी, साखर, मूत्रपिंड, यकृत आणि कोलेस्ट्रॉल यांसारख्या मूलभूत घटकांचे नियमित मूल्यांकन केल्यास संभाव्य आजारांना प्रतिबंध करणे शक्य होते.',
      types: [
        'Primary Prevention: Promoting optimal health behaviors (nutrition, physical activity, sleep) to prevent the onset of noncommunicable diseases.',
        'Secondary Prevention: Early detection of asymptomatic abnormalities (such as prediabetes or borderline lipid elevations) to arrest disease progression.',
        'Annual Wellness Panels: Comprehensive baseline tests including CBC, lipid panel, metabolic panel, and urine analysis.',
      ],
      typesHi: [
        'प्राथमिक रोकथाम: बीमारियों की शुरुआत को रोकने के लिए स्वस्थ जीवनशैली (आहार, व्यायाम, नींद) को बढ़ावा देना।',
        'द्वितीयक रोकथाम: लक्षणों के प्रकट होने से पहले असामान्यताओं (जैसे प्री-डायबिटीज या कोलेस्ट्रॉल वृद्धि) की शुरुआती पहचान।',
        'वार्षिक स्वास्थ्य प्रोफाइल: सीबीसी, लिपिड, मेटाबॉलिक प्रोफाइल और यूरिन टेस्ट जैसे बुनियादी परीक्षण।',
      ],
      typesMr: [
        'प्राथमिक प्रतिबंध: आजार उद्भवू नये म्हणून योग्य आहार, नियमित व्यायाम आणि पुरेशी झोप यांसारख्या सवयी जोपासणे.',
        'द्वितीयक प्रतिबंध: लक्षणे नसतानाही सुरुवातीच्या टप्प्यातच विसंगती शोधणे (उदा. प्री-डायबेटिस किंवा वाढलेले कोलेस्ट्रॉल).',
        'वार्षिक आरोग्य तपासणी: सीबीसी, लिपिड पॅनेल, मूत्रपिंड व यकृत चाचण्या यांसारख्या मूलभूत चाचण्या.',
      ],
      causesAndRisks: [
        'Sedentary Lifestyle and Prolonged Sitting.',
        'Diets High in Ultra-Processed Foods, Added Sugars, and Saturated Fats.',
        'Chronic Psychological Stress elevating inflammatory cytokines and cortisol.',
        'Inadequate or Fragmented Sleep disrupting neuroendocrine metabolic equilibrium.',
        'Environmental exposures, tobacco use, and excessive alcohol consumption.',
      ],
      causesAndRisksHi: [
        'शारीरिक रूप से निष्क्रिय जीवनशैली और लंबे समय तक बैठे रहना।',
        'अल्ट्रा-प्रोसेस्ड भोजन, अतिरिक्त चीनी और अस्वास्थ्यकर वसा का अधिक सेवन।',
        'दीर्घकालिक मानसिक तनाव जो शरीर में सूजन और कोर्टिसोल को बढ़ाता है।',
        'नींद की कमी या अनियमित नींद जो चयापचय संतुलन को बिगाड़ती है।',
        'तंबाकू का सेवन और अत्यधिक शराब पीना।',
      ],
      causesAndRisksMr: [
        'बैठी जीवनशैली आणि शारीरिक हालचालींचा अभाव.',
        'प्रक्रिया केलेले अन्नपदार्थ, अतिसाखर आणि अस्वास्थ्यकर चरबीचे सेवन.',
        'सततचा मानसिक ताण ज्यामुळे शरीरातील दाहक घटक वाढतात.',
        'अपूरी किंवा विस्कळीत झोप ज्यामुळे चयापचय क्रियेवर विपरीत परिणाम होतो.',
        'तंबाखूचे व्यसन आणि मद्यपान.',
      ],
      signsAndSymptoms: [
        'Subtle or Subclinical Indicators: Mild morning fatigue, occasional energy crashes, or slow recovery after physical exertion.',
        'Asymptomatic Nature: Most early biochemical deviations (elevated cholesterol, borderline blood pressure, mild fasting hyperglycemia) cause zero symptoms in early stages.',
      ],
      signsAndSymptomsHi: [
        'शुरुआती सूक्ष्म संकेत: सुबह हल्का आलस्य, ऊर्जा में कमी या शारीरिक श्रम के बाद देर से रिकवरी।',
        'लक्षणहीन स्वभाव: शुरुआती कोलेस्ट्रॉल वृद्धि, हल्का बढ़ा हुआ रक्तचाप और बॉर्डरलाइन शर्करा आमतौर पर कोई लक्षण नहीं दिखाते।',
      ],
      signsAndSymptomsMr: [
        'सुरुवातीची सौम्य लक्षणे: सकाळी आळस जाणवणे, कामात उत्साह नसणे किंवा थोड्या श्रमाने थकवा येणे.',
        'लक्षणे नसलेली स्थिती: उच्च कोलेस्ट्रॉल, वाढलेला रक्तदाब आणि वाढलेली साखर सुरुवातीला कोणतीही ठळक लक्षणे दाखवत नाहीत.',
      ],
      diagnosisOverview:
        'Standard screening evaluates values against age- and sex-matched biological reference intervals established by standardized laboratory methodologies (CAP, NABL, CDC). Values outside these ranges indicate the need for clinical review, lifestyle adjustment, or repeat testing.',
      diagnosisOverviewHi:
        'मानक प्रयोगशाला पद्धतियों द्वारा स्थापित आयु और लिंग के अनुसार संदर्भ सीमाओं के साथ परिणामों का मिलान किया जाता है। सीमा से बाहर के मान जीवनशैली सुधार या चिकित्सीय समीक्षा की आवश्यकता दर्शाते हैं।',
      diagnosisOverviewMr:
        'मानक प्रयोगशाळा पद्धतींनुसार वय आणि लिंगानुसार ठरवलेल्या संदर्भ श्रेणींशी निकालांची तुलना केली जाते. श्रेणीबाहेर निकाल आढळल्यास डॉक्टरांचा सल्ला आणि जीवनशैलीत सुधारणा आवश्यक असते.',
      relevantTestsAndMeaning: [
        {
          testName: 'Complete Blood Count (CBC)',
          clinicalMeaning: 'Surveys immune cells (WBCs), oxygen carriers (RBCs & Hb), and clotting elements (Platelets).',
          clinicalMeaningHi: 'प्रतिरक्षा कोशिकाओं (WBC), ऑक्सीजन वाहक (RBC व हीमोग्लोबिन) और रक्त के थक्के बनाने वाले तत्वों (प्लेटलेट्स) का सर्वेक्षण करता है।',
          clinicalMeaningMr: 'रोगप्रतिकारक पेशी (WBC), ऑक्सिजन वाहक (RBC व हिमोग्लोबिन) आणि रक्त गोठवणारे घटक (प्लेटलेट्स) तपासते.',
        },
        {
          testName: 'Comprehensive Metabolic Panel (CMP / Liver & Kidney)',
          clinicalMeaning: 'Assesses electrolytes, kidney filtration (Creatinine, BUN), and hepatic integrity (ALT, AST, Bilirubin).',
          clinicalMeaningHi: 'इलेक्ट्रोलाइट्स, गुर्दे की कार्यप्रणाली (क्रिएटिनिन, बीयूएन) और लीवर एंजाइम (ALT, AST) का मूल्यांकन करता है।',
          clinicalMeaningMr: 'इलेक्ट्रोलाइट्स, मूत्रपिंडाचे कार्य (क्रिएटिनिन) आणि यकृताचे एंझाइम्स (ALT, AST) तपासते.',
        },
        {
          testName: 'Lipid Profile',
          clinicalMeaning: 'Measures Total Cholesterol, Triglycerides, LDL ("bad") and HDL ("good") to assess cardiovascular health.',
          clinicalMeaningHi: 'हृदय स्वास्थ्य का मूल्यांकन करने के लिए कुल कोलेस्ट्रॉल, ट्राइग्लिसराइड्स, एलडीएल और एचडीएल को मापता है।',
          clinicalMeaningMr: 'हृदयाच्या आरोग्यासाठी एकूण कोलेस्ट्रॉल, ट्रायग्लिसराइड्स, एलडीएल आणि एचडीएल मोजते.',
        },
      ],
      complications: [
        'Silent Progression of Preventable Conditions: Undetected hypertension or dyslipidemia causing progressive arterial hardening.',
        'Delayed Diagnosis of Metabolic Syndrome: Increasing future lifetime cardiovascular and diabetic vulnerability.',
      ],
      complicationsHi: [
        'बीमारियों का बिना लक्षण बढ़ना: अनियंत्रित रक्तचाप या कोलेस्ट्रॉल से धमनियों का धीरे-धीरे संकुचित होना।',
        'मेटाबॉलिक सिंड्रोम की पहचान में देरी: भविष्य में हृदय रोग और मधुमेह के खतरे को बढ़ाना।',
      ],
      complicationsMr: [
        'लक्षणे नसताना आजार वाढणे: अनपेक्षित उच्च रक्तदाब किंवा कोलेस्ट्रॉलमुळे रक्तवाहिन्या कडक होणे.',
        'मेटाबॉलिक सिंड्रोमचे उशिरा निदान: ज्यामुळे भविष्यात हृदयविकार आणि मधुमेहाचा धोका वाढू शकतो.',
      ],
      preventionAndLifestyle: [
        'Whole-Food Nutrition: Emphasize wholesome colorful vegetables, fruits, whole grains, seeds, and adequate daily hydration (2–3 liters).',
        'Consistent Daily Movement: Aim for 8,000–10,000 steps daily coupled with purposeful aerobic activity.',
        'Circadian Hygiene: Consistent bedtime and wake times promoting restorative cellular repair.',
        'Periodic Wellness Checkups: Schedule an annual review with your healthcare provider.',
      ],
      preventionAndLifestyleHi: [
        'संपूर्ण प्राकृतिक आहार: हरी सब्जियां, फल, साबुत अनाज, मेवे और पर्याप्त पानी (प्रतिदिन 2-3 लीटर)।',
        'दैनिक सक्रियता: प्रतिदिन 8,000 से 10,000 कदम चलने का लक्ष्य और नियमित व्यायाम।',
        'नियमित नींद का चक्र: समय पर सोना और जागना जिससे शरीर की कोशिकाएं स्वस्थ रहें।',
        'नियमित स्वास्थ्य समीक्षा: वर्ष में कम से कम एक बार स्वास्थ्य पेशेवर से परामर्श।',
      ],
      preventionAndLifestyleMr: [
        'सकस आहार: पालेभाज्या, फळे, तृणधान्ये, सुकामेवा आणि पुरेसे पाणी (दररोज २-३ लिटर).',
        'नियमित शारीरिक हालचाल: दररोज ८,००० ते १०,००० पावले चालणे आणि व्यायाम.',
        'झोपेचे योग्य वेळापत्रक: नियमित वेळी झोपणे आणि उठणे ज्यामुळे शरीराची नैसर्गिक झीज भरून निघते.',
        'वार्षिक आरोग्य तपासणी: वर्षातून किमान एकदा डॉक्टरांकडून तपासणी करून घेणे.',
      ],
      treatmentApproaches: [
        'Evidence-Based Lifestyle Optimization: The foundation of modern preventive medicine.',
        'Follow-up Diagnostic Testing: Targeted re-testing of any borderline biomarker in 3–6 months.',
        'Professional Medical Consultation: Personalized assessment of cardiovascular and metabolic risk.',
      ],
      treatmentApproachesHi: [
        'साक्ष्य-आधारित जीवनशैली अनुकूलन: आधुनिक निवारक चिकित्सा की आधारशिला।',
        'फॉलो-अप परीक्षण: बॉर्डरलाइन पाए गए बायोमार्कर की 3 से 6 महीने में पुनः जांच।',
        'योग्य डॉक्टर से व्यक्तिगत परामर्श।',
      ],
      treatmentApproachesMr: [
        'जीवनशैलीतील सकारात्मक बदल: आधुनिक प्रतिबंधात्मक औषधोपचारांचा पाया.',
        'पुनर्तपासणी: सीमावर्ती निकालांची ३ ते ६ महिन्यांत पुन्हा तपासणी करणे.',
        'वैद्यकीय तज्ज्ञांचे वैयक्तिक मार्गदर्शन.',
      ],
      whenToSeeDoctor: [
        'Any laboratory biomarker reported with an abnormal, high, or low flag.',
        'Persistent unexplained changes in weight, bowel habits, or energy levels.',
        'Family history of premature cardiovascular events or chronic organ disease.',
      ],
      whenToSeeDoctorHi: [
        'प्रयोगशाला रिपोर्ट में किसी भी बायोमार्कर के असामान्य, उच्च या निम्न आने पर।',
        'वजन, ऊर्जा स्तर या पाचन में लगातार असामान्य परिवर्तन होने पर।',
        'परिवार में कम उम्र में हृदय रोग या गंभीर बीमारियों का इतिहास होने पर।',
      ],
      whenToSeeDoctorMr: [
        'लॅब अहवालात कोणताही बायोमार्कर असामान्य, जास्त किंवा कमी आढळल्यास.',
        'वजन, ऊर्जा पातळी किंवा पचनात सतत अस्वाभाविक बदल जाणवल्यास.',
        'कुटुंबामध्ये कमी वयात हृदयविकाराचा किंवा इतर जुनाट आजारांचा इतिहास असल्यास.',
      ],
      additionalEducationalNotes:
        'Biomarker reference ranges represent the 95% statistical distribution of a healthy population. Individual baseline values can vary naturally. Always review trends over time in consultation with your clinical doctor.',
      additionalEducationalNotesHi:
        'बायोमार्कर संदर्भ सीमाएं स्वस्थ आबादी के 95% सांख्यिकीय वितरण का प्रतिनिधित्व करती हैं। व्यक्तिगत आधारभूत मान स्वाभाविक रूप से भिन्न हो सकते हैं। अपने डॉक्टर के साथ समय के साथ आए रुझानों की समीक्षा करें।',
      additionalEducationalNotesMr:
        'बायोमार्कर्सची संदर्भ श्रेणी निरोगी लोकसंख्येच्या ९५% आकडेवारीवर आधारित असते. प्रत्येकाचे नैसर्गिक स्तर थोडे वेगळे असू शकतात. त्यामुळे नेहमी डॉक्टरांच्या सल्ल्याने बदलांचा आढावा घ्या.',
    },
  },
};
