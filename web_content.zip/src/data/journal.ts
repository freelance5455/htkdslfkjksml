import type { JournalEntryDef, ResonanceDef } from "@/game/types";

export const JOURNAL: JournalEntryDef[] = [
  {
    id: "j_quete",
    section: "quete",
    title: "Objectif",
    requireFlag: "game_started",
    stages: [
      "Retrouver la prochaine trace d'Esteban.",
      "Esteban a laissé un chemin. Le suivre, cercle après cercle.",
      "Les traces ne mènent plus à un corps. Elles mènent à un lieu.",
      "Comprendre pourquoi ces traces semblent destinées à Lohen.",
      "Atteindre le dernier lieu. Écouter.",
    ],
  },
  {
    id: "j_lohen",
    section: "personnages",
    title: "Lohen",
    requireFlag: "game_started",
    stages: [
      "Curieux. Déterminé. Il veut une explication rationnelle.",
      "Il commence à chercher trop vite. Chaque objet lui semble un signe.",
      "Plus calme. Il n'essaie plus de rattraper. Il lit.",
    ],
  },
  {
    id: "j_esteban",
    section: "personnages",
    title: "Esteban",
    requireFlag: "game_started",
    stages: [
      "Absent. Présent partout. Une voix, une lumière, rien d'autre.",
      "Esteban est passé par ________.",
      "Esteban est passé par Brumeveil, puis l'observatoire, puis Astraea.",
      "Il attendait. Puis il n'attendait plus.",
      "Il a construit un chemin. Pas une fuite.",
    ],
  },
  {
    id: "j_seuil",
    section: "lieux",
    title: "Seuil de l'Inconnu",
    requireFlag: "visited_seuil",
    stages: [
      "Une plaine noire. Une étoile. Des pierres.",
      "Le glyphe du triangle était déjà là avant Lohen.",
    ],
  },
  {
    id: "j_brumeveil",
    section: "lieux",
    title: "Brumeveil",
    requireFlag: "visited_village",
    stages: [
      "Village bas, toits bas, ciel trop grand.",
      "Esteban a campé près du puits, puis est parti vers le nord-ouest.",
    ],
  },
  {
    id: "j_obs",
    section: "lieux",
    title: "Observatoire des Cendres",
    requireFlag: "visited_observatory",
    stages: [
      "Une lunette tournée vers un ciel qui n'a plus rien à montrer.",
      "Les souvenirs s'y accrochent comme de la poussière lumineuse.",
    ],
  },
  {
    id: "j_astraea",
    section: "lieux",
    title: "Astraea",
    requireFlag: "visited_city",
    stages: [
      "Ville sans étoiles. Les gens parlent bas.",
      "La bibliothèque inverse les phrases. La tour allume d'anciennes fenêtres.",
    ],
  },
  {
    id: "j_sanctuaire",
    section: "lieux",
    title: "Sanctuaire du Miroir",
    requireFlag: "visited_sanctuary",
    stages: [
      "Une pièce simple. Une horloge arrêtée.",
      "Dans le passé, quelqu'un était assis. L'heure : 21:07.",
    ],
  },
  {
    id: "j_portes",
    section: "lieux",
    title: "Les Sept Portes",
    requireFlag: "visited_gates",
    stages: [
      "Sept concepts. Sept serrures.",
      "Distance, Souvenir, Absence, Présence, Temps, Destin, Lien.",
    ],
  },
  {
    id: "j_mystere_voix",
    section: "mysteres",
    title: "La transmission",
    requireFlag: "game_started",
    stages: [
      "« Si tu peux m'entendre… suis la lumière. »",
      "La voix connaît le nom de Lohen.",
      "Ce n'était pas un appel au secours. C'était un commencement.",
    ],
  },
  {
    id: "j_mystere_heures",
    section: "mysteres",
    title: "21:07",
    requireFlag: "seen_clock",
    stages: [
      "Une heure figée.",
      "Pas une coordonnée géographique. Un rendez-vous manqué.",
    ],
  },
  {
    id: "j_constellation",
    section: "constellation",
    title: "Ciel intérieur",
    requireFlag: "solved_seuil",
    stages: [
      "Une étoile.",
      "Le ciel se peuple à mesure des traces.",
      "Quand toutes seront là, un seuil s'ouvrira.",
    ],
  },
  {
    id: "j_archive_locked",
    section: "archives",
    title: "Archive verrouillée",
    requireFlag: "game_started",
    stages: ["Archive verrouillée.", "Archive verrouillée.", "Archive verrouillée."],
  },
  {
    id: "j_resonance_note",
    section: "resonances",
    title: "Résonances",
    requireFlag: "resonance_any",
    stages: [
      "Une résonance inconnue a été détectée.",
      "Les réponses ne changent pas le chemin. Elles changent la voix du silence.",
    ],
  },
  {
    id: "j_camp_note",
    section: "mysteres",
    title: "Cendres du camp",
    requireFlag: "examined_camp_ash",
    stages: [
      "« lune, étoile, puits, puis la lune encore — il revenait toujours. »",
    ],
  },
  {
    id: "j_livre",
    section: "mysteres",
    title: "Page inversée",
    requireFlag: "solved_miroir",
    stages: ["Les étoiles ne sont pas mortes. Elles attendent."],
  },
  {
    id: "j_echo_chair",
    section: "mysteres",
    title: "La chaise",
    requireFlag: "examined_chair",
    stages: [
      "Esteban est passé ici.",
      "Esteban attendait ici.",
      "Quelqu'un attendait ici.",
    ],
  },
];

export const RESONANCES: ResonanceDef[] = [
  {
    id: "r_souvenir",
    prompt: "Quel souvenir refuses-tu d'oublier ?",
    placeholder: "Un lieu, une voix, une heure…",
  },
  {
    id: "r_personne",
    prompt: "Quelle personne aimerais-tu retrouver ?",
    placeholder: "Un nom, ou seulement une présence",
  },
  {
    id: "r_distance",
    prompt: "Quelle distance aimerais-tu pouvoir effacer ?",
    placeholder: "Kilomètres, années, silences…",
  },
  {
    id: "r_dire",
    prompt: "Qu'est-ce que tu voudrais pouvoir dire avant qu'il ne soit trop tard ?",
    placeholder: "Une phrase, même incomplète",
  },
];

export const JOURNAL_SECTIONS: { id: JournalEntryDef["section"]; label: string }[] = [
  { id: "quete", label: "Quête" },
  { id: "lieux", label: "Lieux" },
  { id: "personnages", label: "Personnages" },
  { id: "fragments", label: "Fragments" },
  { id: "artefacts", label: "Artefacts" },
  { id: "mysteres", label: "Mystères" },
  { id: "resonances", label: "Résonances" },
  { id: "constellation", label: "Constellation" },
  { id: "archives", label: "Archives" },
];
