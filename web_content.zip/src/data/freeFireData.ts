import { DeviceSensPreset, Weapon, CharacterCombo, HudPreset, TeamScore, Player, MatchRoom } from '../types';

export const FFWS_POINTS_SYSTEM: Record<number, number> = {
  1: 12, // Booyah
  2: 9,
  3: 8,
  4: 7,
  5: 6,
  6: 5,
  7: 4,
  8: 3,
  9: 2,
  10: 1,
  11: 0,
  12: 0,
};

export const INITIAL_ROOM_CONFIG: MatchRoom = {
  roomId: '8492015',
  roomPass: 'ffpro2026',
  map: 'Bermuda',
  mode: 'Battle Royale',
  matchNumber: 1,
  roomType: 'Tournament Final',
  limitedAmmo: false,
  fallDamage: true,
  airDrop: true,
  defaultHp: 200,
  ep: 200,
  movementSpeed: 100,
  notes: 'No hacking / No emulator in mobile bracket. Gloo wall limit: 3 active per player. Official FFWS point rules apply.'
};

export const INITIAL_TEAMS: TeamScore[] = [
  {
    id: 't1',
    teamName: 'EVOS PHOENIX',
    tag: 'EVOS',
    kills: 14,
    placementRank: 1,
    booyah: true,
    placementPoints: 12,
    killPoints: 14,
    totalPoints: 26,
    players: ['Moshi', 'TheCruz', 'D-Long', 'Godoi']
  },
  {
    id: 't2',
    teamName: 'MAGIC SQUAD',
    tag: 'MGS',
    kills: 11,
    placementRank: 2,
    booyah: false,
    placementPoints: 9,
    killPoints: 11,
    totalPoints: 20,
    players: ['Bops', 'Giuh', 'Yago', 'Pedro']
  },
  {
    id: 't3',
    teamName: 'TOTAL GAMING ESPORTS',
    tag: 'TG',
    kills: 8,
    placementRank: 3,
    booyah: false,
    placementPoints: 8,
    killPoints: 8,
    totalPoints: 16,
    players: ['FozyAjay', 'Mafia', 'Delete', 'Vasi']
  },
  {
    id: 't4',
    teamName: 'LOUD ESPORTS',
    tag: 'LOUD',
    kills: 9,
    placementRank: 4,
    booyah: false,
    placementPoints: 7,
    killPoints: 9,
    totalPoints: 16,
    players: ['Cauan7', 'Lost21', 'Mexico', 'Draxx']
  },
  {
    id: 't5',
    teamName: 'GODLIKE ESPORTS',
    tag: 'GODL',
    kills: 6,
    placementRank: 5,
    booyah: false,
    placementPoints: 6,
    killPoints: 6,
    totalPoints: 12,
    players: ['Pahadi', 'Niku', 'Viper', 'Abhay']
  },
  {
    id: 't6',
    teamName: 'ATTACK ALL AROUND',
    tag: 'AAA',
    kills: 7,
    placementRank: 6,
    booyah: false,
    placementPoints: 5,
    killPoints: 7,
    totalPoints: 12,
    players: ['KerMen', 'Poong', 'JLX', 'Hoysang']
  },
  {
    id: 't7',
    teamName: 'FLUXO',
    tag: 'FX',
    kills: 5,
    placementRank: 7,
    booyah: false,
    placementPoints: 4,
    killPoints: 5,
    totalPoints: 9,
    players: ['Nobru', 'Syaz', 'JapaBKR', 'Ousado']
  },
  {
    id: 't8',
    teamName: 'ALPHA 7 ESPORTS',
    tag: 'A7',
    kills: 4,
    placementRank: 8,
    booyah: false,
    placementPoints: 3,
    killPoints: 4,
    totalPoints: 7,
    players: ['Carrilho', 'Swat', 'Revo', 'Myth']
  },
  {
    id: 't9',
    teamName: 'NIGMA GALAXY',
    tag: 'NGX',
    kills: 3,
    placementRank: 9,
    booyah: false,
    placementPoints: 2,
    killPoints: 3,
    totalPoints: 5,
    players: ['Shadow', 'Demon', 'Frost', 'SniperX']
  },
  {
    id: 't10',
    teamName: 'RRQ KAZU',
    tag: 'RRQ',
    kills: 2,
    placementRank: 10,
    booyah: false,
    placementPoints: 1,
    killPoints: 2,
    totalPoints: 3,
    players: ['Lega', 'Maybe', 'Wings', 'Razor']
  },
  {
    id: 't11',
    teamName: 'TEAM ELITE',
    tag: 'TE',
    kills: 2,
    placementRank: 11,
    booyah: false,
    placementPoints: 0,
    killPoints: 2,
    totalPoints: 2,
    players: ['Killer', 'Iconic', 'Ronaq', 'Jash']
  },
  {
    id: 't12',
    teamName: 'BLACK DRAGONS',
    tag: 'BD',
    kills: 1,
    placementRank: 12,
    booyah: false,
    placementPoints: 0,
    killPoints: 1,
    totalPoints: 1,
    players: ['Kroonos', 'Levelup', 'Phoenix', 'Ghost']
  }
];

export const INITIAL_ROSTER: Player[] = [
  {
    id: 'p1',
    ign: '⚡ VASI_99 ⚡',
    uid: '1092847291',
    role: 'IGL',
    rank: 'Grandmaster',
    headshotRate: 72.4,
    kd: 5.8,
    favoriteGun: 'Groza & Woodpecker',
    device: 'iPhone 15 Pro Max',
    status: 'Active'
  },
  {
    id: 'p2',
    ign: '亗 PAHADI_OP 亗',
    uid: '4920194821',
    role: 'Sniper',
    rank: 'Grandmaster',
    headshotRate: 88.2,
    kd: 6.4,
    favoriteGun: 'AWM & M1887',
    device: 'ROG Phone 8 Pro',
    status: 'Active'
  },
  {
    id: 'p3',
    ign: '꧁KILLER_ff꧂',
    uid: '8102938472',
    role: 'Rusher',
    rank: 'Master',
    headshotRate: 81.5,
    kd: 5.2,
    favoriteGun: 'M1887 & MP40',
    device: 'Samsung S24 Ultra',
    status: 'Active'
  },
  {
    id: 'p4',
    ign: '☠️ FOZY_AJAY ☠️',
    uid: '3819203941',
    role: 'Flanker',
    rank: 'Elite Master',
    headshotRate: 69.8,
    kd: 4.9,
    favoriteGun: 'Bizon & AC80',
    device: 'POCO X6 Pro',
    status: 'Active'
  },
  {
    id: 'p5',
    ign: '✦ SHADOW_7 ✦',
    uid: '6729103948',
    role: 'Support',
    rank: 'Master',
    headshotRate: 64.0,
    kd: 4.1,
    favoriteGun: 'SCAR & M1014',
    device: 'OnePlus 12',
    status: 'Sub'
  }
];

export const DEVICE_PRESETS: DeviceSensPreset[] = [
  {
    id: 'ios-pro',
    category: 'iPhone / iOS',
    deviceName: 'iPhone 13 / 14 / 15 / 16 Pro Max (120Hz Promotion)',
    general: 98,
    redDot: 95,
    scope2x: 92,
    scope4x: 88,
    sniperScope: 65,
    freeLook: 80,
    recommendedDpi: 120, // iOS sliding tracker
    fireButtonSize: 45,
    pointerSpeed: 'Fastest (Max)',
    dragTechnique: 'J-Shape Drag',
    description: 'Ultra smooth 120Hz display with near-zero input lag. Best for instant red-number one-tap headshots with M1887 and Woodpecker.'
  },
  {
    id: 'rog-phone',
    category: 'Flagship Android',
    deviceName: 'ASUS ROG Phone 7 / 8 & RedMagic (165Hz)',
    general: 94,
    redDot: 92,
    scope2x: 86,
    scope4x: 82,
    sniperScope: 55,
    freeLook: 75,
    recommendedDpi: 520,
    fireButtonSize: 48,
    pointerSpeed: 'Full Right (100%)',
    dragTechnique: 'Straight Vertical Drag',
    description: 'Extreme touch sampling rate (720Hz+). Low sensitivity is stabilized; slight upward flick immediately locks onto enemy helmet.'
  },
  {
    id: 'samsung-ultra',
    category: 'Flagship Android',
    deviceName: 'Samsung Galaxy S22 / S23 / S24 Ultra',
    general: 100,
    redDot: 98,
    scope2x: 94,
    scope4x: 90,
    sniperScope: 60,
    freeLook: 85,
    recommendedDpi: 460,
    fireButtonSize: 52,
    pointerSpeed: 'Level 9 / 10',
    dragTechnique: 'Rotation Drag',
    description: 'Large Dynamic AMOLED screen requires slightly larger button size to prevent dead-touch during rapid gloo-wall deployment.'
  },
  {
    id: 'poco-redmi',
    category: 'Mid-Range Android',
    deviceName: 'POCO X5 / X6 Pro / Redmi Note 12 / 13 Pro (120Hz)',
    general: 100,
    redDot: 100,
    scope2x: 95,
    scope4x: 92,
    sniperScope: 68,
    freeLook: 90,
    recommendedDpi: 440,
    fireButtonSize: 46,
    pointerSpeed: 'Max + Large Display Scaling',
    dragTechnique: 'J-Shape Drag',
    description: 'Most popular tournament choice. Max general sensitivity counteracts MIUI touch latency for lightning-fast quick-turn.'
  },
  {
    id: 'budget-realme',
    category: 'Budget 90Hz',
    deviceName: 'Realme / Infinix / Tecno / Vivo (4GB - 6GB RAM, 90Hz)',
    general: 100,
    redDot: 100,
    scope2x: 100,
    scope4x: 96,
    sniperScope: 72,
    freeLook: 95,
    recommendedDpi: 392,
    fireButtonSize: 42,
    pointerSpeed: 'Max Speed',
    dragTechnique: 'Straight Vertical Drag',
    description: 'Smaller fire button (42%) creates higher travel distance on the screen, maximizing drag acceleration on moderate frame rates.'
  },
  {
    id: 'emulator-pc',
    category: 'PC / Emulator',
    deviceName: 'BlueStacks 5 / MSI App Player / LDPlayer (Custom Mouse)',
    general: 45,
    redDot: 42,
    scope2x: 38,
    scope4x: 35,
    sniperScope: 25,
    freeLook: 40,
    recommendedDpi: 800,
    fireButtonSize: 35,
    pointerSpeed: '6/11 Windows Default, Enhanced Pointer Off',
    dragTechnique: 'Straight Vertical Drag',
    description: 'X-axis 1.85, Y-axis 2.65 in emulator keymap editor. Tweaked for pinpoint mouse drag and zero recoil shake.'
  }
];

export const WEAPONS_DATA: Weapon[] = [
  {
    id: 'm1887',
    name: 'M1887 (Double Barrel)',
    category: 'Shotgun',
    tier: 'S+',
    damage: 100,
    rateOfFire: 42,
    range: 21,
    reloadSpeed: 55,
    magazine: 2,
    accuracy: 10,
    armorPenetration: 54,
    headshotMultiplier: 3.5,
    proTips: 'King of close-range one-taps. Fire 1st shot with J-Drag, instantly deploy gloo wall or switch to melee to cancel recoil pause.'
  },
  {
    id: 'woodpecker',
    name: 'Woodpecker',
    category: 'Marksman Rifle',
    tier: 'S+',
    damage: 85,
    rateOfFire: 38,
    range: 63,
    reloadSpeed: 48,
    magazine: 12,
    accuracy: 69,
    armorPenetration: 75,
    headshotMultiplier: 3.8,
    proTips: 'Highest armor penetration in the marksman class. 1 headshot easily breaks Level 3 helmet and knocks in 1 shot.'
  },
  {
    id: 'groza',
    name: 'Groza-X',
    category: 'Assault Rifle',
    tier: 'S+',
    damage: 61,
    rateOfFire: 58,
    range: 77,
    reloadSpeed: 48,
    magazine: 30,
    accuracy: 54,
    armorPenetration: 34,
    headshotMultiplier: 2.5,
    proTips: 'Airdrop powerhouse. Outstanding stability at mid-to-long distance. Pair with Laura for surgical accuracy.'
  },
  {
    id: 'mp40',
    name: 'MP40 (Flashing Spade)',
    category: 'SMG',
    tier: 'S',
    damage: 48,
    rateOfFire: 83,
    range: 22,
    reloadSpeed: 48,
    magazine: 20,
    accuracy: 17,
    armorPenetration: 0,
    headshotMultiplier: 2.2,
    proTips: 'Fastest burst rate in Free Fire. Requires quick vertical drag from chest to head before magazine spread blooms.'
  },
  {
    id: 'awm',
    name: 'AWM-Y',
    category: 'Sniper',
    tier: 'S',
    damage: 90,
    rateOfFire: 27,
    range: 91,
    reloadSpeed: 34,
    magazine: 5,
    accuracy: 90,
    armorPenetration: 54,
    headshotMultiplier: 4.0,
    proTips: 'AWM-Y can shoot through Gloo Walls and pierce armor! Quick-switch double AWM cancels cocking animation.'
  },
  {
    id: 'bizon',
    name: 'Bizon',
    category: 'SMG',
    tier: 'S',
    damage: 54,
    rateOfFire: 75,
    range: 20,
    reloadSpeed: 41,
    magazine: 30,
    accuracy: 17,
    armorPenetration: 0,
    headshotMultiplier: 2.2,
    proTips: 'Combines SMG fire rate with high base damage. Exceptional for aggressive clash squad pushes.'
  },
  {
    id: 'ac80',
    name: 'AC80',
    category: 'Marksman Rifle',
    tier: 'A',
    damage: 71,
    rateOfFire: 36,
    range: 68,
    reloadSpeed: 50,
    magazine: 10,
    accuracy: 51,
    armorPenetration: 70,
    headshotMultiplier: 3.6,
    proTips: 'Consecutive hit perk gives bonus damage on the second bullet hit. Lethal for 2-tap headshot bursts.'
  },
  {
    id: 'm1014',
    name: 'M1014-III',
    category: 'Shotgun',
    tier: 'S',
    damage: 94,
    rateOfFire: 38,
    range: 10,
    reloadSpeed: 20,
    magazine: 6,
    accuracy: 10,
    armorPenetration: 28,
    headshotMultiplier: 3.2,
    proTips: 'Upgraded to level 3 chips, it has tight bullet spread and deletes entire squads within point-blank range.'
  },
  {
    id: 'scar',
    name: 'SCAR-III',
    category: 'Assault Rifle',
    tier: 'A',
    damage: 53,
    rateOfFire: 61,
    range: 60,
    reloadSpeed: 41,
    magazine: 30,
    accuracy: 42,
    armorPenetration: 28,
    headshotMultiplier: 2.4,
    proTips: 'The most balanced recoil profile in the game. Ideal training rifle for beginners mastering crosshair placement.'
  },
  {
    id: 'desert-eagle',
    name: 'Desert Eagle',
    category: 'Pistol',
    tier: 'S',
    damage: 90,
    rateOfFire: 33,
    range: 38,
    reloadSpeed: 69,
    magazine: 7,
    accuracy: 45,
    armorPenetration: 0,
    headshotMultiplier: 4.5,
    proTips: 'The Clash Squad round-1 holy grail. 495 damage headshot knock! Keep crosshair at neck level and flick up.'
  }
];

export const CHARACTER_COMBOS: CharacterCombo[] = [
  {
    id: 'combo-rusher',
    name: '⚡ Hyper-Aggressive Rusher & Flanker',
    role: 'Rusher / Entry Fragger',
    activeSkill: {
      character: 'Tatsuya',
      skillName: 'Rebel Rush',
      description: 'Dashes forward at rapid speed (up to 2-3 charges). Perfect for blitzing enemy gloo wall covers.'
    },
    passiveSkills: [
      { character: 'Kelly (Awakened)', skillName: 'Deadly Velocity', description: '+6% sprint speed and first shot after sprint deals 106% damage.' },
      { character: 'Hayato (Awakened)', skillName: 'Art of Blades', description: 'When max HP decreases by 10%, armor penetration increases by 10% + frontal damage reduction.' },
      { character: 'Jota', skillName: 'Sustained Raids', description: 'Hitting enemies recovers HP; knocking down an opponent restores 20% max HP immediately.' }
    ],
    comboSynergy: 'Unstoppable momentum in close quarters. Tatsuya dash closes gaps instantly, Kelly triggers extra opening damage, and Hayato + Jota shred high-tier vests while sustaining health.'
  },
  {
    id: 'combo-zone-tank',
    name: '🛡️ Immortal Zone & EP Regeneration',
    role: 'Support / IGL Anchor',
    activeSkill: {
      character: 'K (Captain Booyah)',
      skillName: 'Master of All',
      description: 'Max EP increases to 250. Jiujitsu mode converts 3 EP into HP every second to all teammates within 6m; Psychology mode restores 3 EP every 2s.'
    },
    passiveSkills: [
      { character: 'Miguel', skillName: 'Crazy Slayer', description: 'Gain 200 EP for every enemy knocked down.' },
      { character: 'Luqueta', skillName: 'Hat Trick', description: 'Every kill permanently boosts max HP by up to 50 HP (reaching 250 Total HP).' },
      { character: 'Nairi', skillName: 'Ice Iron', description: 'Gloo walls recover 50 durability/s when receiving damage, and AR shots against enemy gloo deal +35% damage.' }
    ],
    comboSynergy: 'Infinite sustain engine. Survives outside the safe zone with continuous 3HP/sec healing, extra 250 base health, and indestructible Gloo walls.'
  },
  {
    id: 'combo-one-tap',
    name: '🎯 Red-Number One-Tap Headshot God',
    role: 'Marksman / Long-Range Sniper',
    activeSkill: {
      character: 'Chrono',
      skillName: 'Time Turner',
      description: 'Creates a force field blocking 800 damage. Enables protected peek shooting against snipers.'
    },
    passiveSkills: [
      { character: 'Rafael', skillName: 'Dead Silent', description: 'Silences all snipers & marksman rifles. Knocked down enemies bleed out 85% faster.' },
      { character: 'Maro', skillName: 'Falcon Fervor', description: 'Damage increases with distance, up to +25%. Marked enemies take additional +3.5% damage.' },
      { character: 'Laura', skillName: 'Sharp Shooter', description: 'Accuracy increases by 50% while scoped in.' }
    ],
    comboSynergy: 'Deadly marksman combo with Woodpecker/AC80/AWM. Silent knocks prevent squad mates from knowing the shooter angle, and bleeding enemies die before reviving.'
  },
  {
    id: 'combo-scrim-intel',
    name: '📡 Esports Scrim IGL & Team Tracker',
    role: 'In-Game Leader (IGL)',
    activeSkill: {
      character: 'Homer',
      skillName: 'Senses Shockwave',
      description: 'Releases a drone towards nearest enemy within 100m, dealing 25 damage, reducing 60% movement and 35% firing speed for 5 seconds.'
    },
    passiveSkills: [
      { character: 'Moco (Awakened)', skillName: 'Hacker\'s Eye', description: 'Tags enemies hit for up to 6.5s, visible to the whole squad through walls.' },
      { character: 'Thiva', skillName: 'Vital Vibes', description: 'Rescue speed increases by 70%. Rescued teammates recover 60 HP in 3s.' },
      { character: 'Shirou', skillName: 'Damage Delivered', description: 'When hit from within 100m, attacker is marked for 6s. First shot against marked enemy has +100% armor pen.' }
    ],
    comboSynergy: 'Provides total team reconnaissance. When enemies push, Homer slows them down and Moco reveals their exact rotation for team crossfire.'
  }
];

export const HUD_PRESETS: HudPreset[] = [
  {
    id: 'hud-2finger',
    name: '2-Finger Classic Pro',
    fingers: 2,
    description: 'Optimized standard two-thumb setup. Streamlined layout for high mobility, quick-drag headshots, and fast 360-degree camera spin.',
    bestFor: 'Casual to mid-tier competitive players, phones under 6.5 inches.',
    buttons: [
      { id: 'fire', name: 'Right Fire (Drag)', x: 80, y: 72, size: 52, opacity: 0.9, color: '#ef4444', iconType: 'crosshair', finger: 'Right Thumb' },
      { id: 'left-fire', name: 'Left Fire (Gloo)', x: 18, y: 35, size: 48, opacity: 0.7, color: '#f97316', iconType: 'flame', finger: 'Left Thumb' },
      { id: 'gloo', name: 'Gloo Wall', x: 22, y: 70, size: 56, opacity: 0.9, color: '#3b82f6', iconType: 'shield', finger: 'Left Thumb' },
      { id: 'jump', name: 'Jump', x: 90, y: 52, size: 50, opacity: 0.8, color: '#10b981', iconType: 'arrow-up', finger: 'Right Thumb' },
      { id: 'crouch', name: 'Crouch', x: 74, y: 88, size: 48, opacity: 0.8, color: '#eab308', iconType: 'chevron-down', finger: 'Right Thumb' },
      { id: 'scope', name: 'Scope', x: 88, y: 32, size: 50, opacity: 0.85, color: '#8b5cf6', iconType: 'target', finger: 'Right Thumb' },
      { id: 'active-skill', name: 'Active Skill', x: 68, y: 62, size: 44, opacity: 0.85, color: '#ec4899', iconType: 'zap', finger: 'Right Thumb' },
      { id: 'joystick', name: 'Sprint / Move', x: 14, y: 78, size: 60, opacity: 0.6, color: '#64748b', iconType: 'navigation', finger: 'Left Thumb' }
    ]
  },
  {
    id: 'hud-3finger',
    name: '3-Finger Claw Hybrid (Tournament Standard)',
    fingers: 3,
    description: 'Left Index Finger dedicated to Gloo Wall and Jump/Fire. Allows firing and moving simultaneously without taking right thumb off camera drag.',
    bestFor: 'Esports scrims, 1v1 Custom Room specialists, ultra-fast 0.1s sit-up Gloo Wall.',
    buttons: [
      { id: 'fire', name: 'Right Fire (Drag)', x: 82, y: 70, size: 48, opacity: 0.9, color: '#ef4444', iconType: 'crosshair', finger: 'Right Thumb' },
      { id: 'left-fire', name: 'Top Left Fire', x: 16, y: 15, size: 62, opacity: 0.95, color: '#f97316', iconType: 'flame', finger: 'Left Index' },
      { id: 'gloo', name: 'Gloo Wall', x: 28, y: 18, size: 58, opacity: 0.9, color: '#3b82f6', iconType: 'shield', finger: 'Left Index' },
      { id: 'jump', name: 'Jump', x: 90, y: 50, size: 52, opacity: 0.85, color: '#10b981', iconType: 'arrow-up', finger: 'Right Thumb' },
      { id: 'crouch', name: 'Crouch (Sit-up)', x: 75, y: 86, size: 50, opacity: 0.85, color: '#eab308', iconType: 'chevron-down', finger: 'Right Thumb' },
      { id: 'scope', name: 'Scope', x: 88, y: 30, size: 50, opacity: 0.8, color: '#8b5cf6', iconType: 'target', finger: 'Right Thumb' },
      { id: 'weapon-switch', name: 'Quick Switch', x: 62, y: 78, size: 50, opacity: 0.85, color: '#06b6d4', iconType: 'repeat', finger: 'Right Thumb' },
      { id: 'active-skill', name: 'Active Skill', x: 70, y: 58, size: 46, opacity: 0.85, color: '#ec4899', iconType: 'zap', finger: 'Right Thumb' },
      { id: 'joystick', name: 'Joystick', x: 12, y: 75, size: 55, opacity: 0.5, color: '#64748b', iconType: 'navigation', finger: 'Left Thumb' }
    ]
  },
  {
    id: 'hud-4finger',
    name: '4-Finger Claw Master',
    fingers: 4,
    description: 'Both index fingers on top of the phone screen. Complete split between movement, camera aiming, trigger pull, and secondary abilities.',
    bestFor: 'Pro tournament players, Grandmaster tier rushers, iPads & tablets.',
    buttons: [
      { id: 'fire', name: 'Drag Fire', x: 84, y: 72, size: 45, opacity: 0.85, color: '#ef4444', iconType: 'crosshair', finger: 'Right Thumb' },
      { id: 'left-fire', name: 'Index Trigger Fire', x: 15, y: 14, size: 65, opacity: 0.95, color: '#f97316', iconType: 'flame', finger: 'Left Index' },
      { id: 'gloo', name: 'Quick Gloo', x: 28, y: 16, size: 56, opacity: 0.9, color: '#3b82f6', iconType: 'shield', finger: 'Left Index' },
      { id: 'jump', name: 'Jump', x: 86, y: 15, size: 58, opacity: 0.9, color: '#10b981', iconType: 'arrow-up', finger: 'Right Index' },
      { id: 'scope', name: 'Quick Scope', x: 74, y: 15, size: 54, opacity: 0.9, color: '#8b5cf6', iconType: 'target', finger: 'Right Index' },
      { id: 'crouch', name: 'Crouch', x: 76, y: 86, size: 48, opacity: 0.8, color: '#eab308', iconType: 'chevron-down', finger: 'Right Thumb' },
      { id: 'weapon-switch', name: 'Fast Switch', x: 58, y: 76, size: 52, opacity: 0.85, color: '#06b6d4', iconType: 'repeat', finger: 'Right Thumb' },
      { id: 'active-skill', name: 'Tatsuya/Alok Skill', x: 68, y: 58, size: 46, opacity: 0.85, color: '#ec4899', iconType: 'zap', finger: 'Right Thumb' },
      { id: 'joystick', name: 'Analog Joystick', x: 12, y: 74, size: 55, opacity: 0.5, color: '#64748b', iconType: 'navigation', finger: 'Left Thumb' }
    ]
  }
];
