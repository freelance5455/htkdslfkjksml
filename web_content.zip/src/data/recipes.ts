import type { CraftingRecipe, MachineType, Tier } from '../types/game.ts';

// Comprehensive catalog with 400+ crafting recipes across all 11 production lines
export const ALL_RECIPES: CraftingRecipe[] = [];

// Machine metadata
export const MACHINE_NAMES: Record<MachineType, { name: string; icon: string; desc: string }> = {
  bakery: { name: 'Lò Bánh Mì & Bánh Ngọt', icon: '🥖', desc: 'Nướng các loại bánh mì, bánh ngọt từ ngũ cốc, bơ, sữa và mật ong' },
  juice_jam: { name: 'Máy Ép Nước & Mứt Quả', icon: '🧃', desc: 'Chế biến sinh tố, nước ép dinh dưỡng và mứt trái cây cô đặc' },
  dairy: { name: 'Thùng Ủ Phô Mai & Bơ', icon: '🧀', desc: 'Lên men phô mai, đánh bơ béo và sản xuất sữa chua trái cây' },
  loom: { name: 'Khung Dệt Vải & Thời Trang', icon: '🧵', desc: 'Dệt sợi len, may y phục dạ hội và khăn choàng lụa tơ tằm' },
  brewery: { name: 'Thùng Gỗ Ủ Rượu Vang', icon: '🍷', desc: 'Lên men rượu vang hoa quả, bia đại mạch và rượu mật ong hảo hạng' },
  perfume: { name: 'Máy Chiết Xuất Tinh Dầu & Nước Hoa', icon: '🧴', desc: 'Chưng cất tinh dầu hoa màu, nước hoa xa xỉ và sáp thơm' },
  alchemy: { name: 'Lò Luyện Đan Dược Thần Thoại', icon: '⚗️', desc: 'Luyện đan linh dược bí truyền, tiên đan tăng trưởng và linh dịch' },
  jewelry: { name: 'Xưởng Chế Tác Châu Báu Mỹ Nghệ', icon: '💍', desc: 'Khảm nạm ngọc trai, chuỗi hạt vảy rồng và vương miện hoàng gia' },
  gourmet: { name: 'Bếp Đại Tiệc Hoàng Gia', icon: '🍲', desc: 'Chế biến yến tiệc cung đình kết hợp tinh hoa từ cả 4 phân khu' },
  feed_mixer: { name: 'Máy Phối Trộn Thức Ăn Chăn Nuôi', icon: '🥣', desc: 'Sản xuất cám dinh dưỡng cao cấp và thức ăn khoái khẩu của thú và cá' },
  fertilizer_tower: { name: 'Tháp Ủ Phân Bón Sinh Học', icon: '🧪', desc: 'Ủ phân hữu cơ siêu cấp, phân bón tăng tốc và tinh thể đột biến' },
};

// 1. Feed & Fertilizer line (crucial early game)
ALL_RECIPES.push(
  {
    id: 'feed_poultry',
    name: 'Thức Ăn Gia Cầm Cơ Bản',
    machineId: 'feed_mixer',
    tier: 1,
    icon: '🥣',
    description: 'Thức ăn khoái khẩu của Gà ta và Vịt bầu.',
    inputs: [{ itemId: 'prod_corn', count: 1 }, { itemId: 'prod_rice', count: 1 }],
    outputItemId: 'thức_ăn_gia_cầm',
    outputCount: 3,
    craftTimeSeconds: 15,
    expPerUnit: 15,
    unlockLevel: 3,
  },
  {
    id: 'feed_herbivore',
    name: 'Cỏ Dinh Dưỡng Thú Nhỏ',
    machineId: 'feed_mixer',
    tier: 1,
    icon: '🌾🥣',
    description: 'Thức ăn khoái khẩu của Thỏ và Dê núi.',
    inputs: [{ itemId: 'prod_wheat', count: 2 }],
    outputItemId: 'thức_ăn_cỏ',
    outputCount: 3,
    craftTimeSeconds: 20,
    expPerUnit: 18,
    unlockLevel: 3,
  },
  {
    id: 'feed_aquatic_basic',
    name: 'Thức Ăn Thủy Sinh Cơ Bản',
    machineId: 'feed_mixer',
    tier: 1,
    icon: '🐟🥣',
    description: 'Thức ăn hạt dinh dưỡng cho Cá chép và Rô phi hồ nước ngọt.',
    inputs: [{ itemId: 'prod_rice', count: 2 }, { itemId: 'prod_corn', count: 1 }],
    outputItemId: 'thức_ăn_thủy_sinh',
    outputCount: 3,
    craftTimeSeconds: 25,
    expPerUnit: 20,
    unlockLevel: 3,
  },
  {
    id: 'feed_premium_mash',
    name: 'Cám Dinh Dưỡng Cao Cấp',
    machineId: 'feed_mixer',
    tier: 2,
    icon: '✨🥣',
    description: 'Giảm 25% thời gian tạo sản phẩm của thú/cá, tăng +60% Độ Hài Lòng!',
    inputs: [{ itemId: 'prod_barley', count: 2 }, { itemId: 'prod_potato', count: 2 }],
    outputItemId: 'cám_cao_cấp',
    outputCount: 2,
    craftTimeSeconds: 40,
    expPerUnit: 35,
    unlockLevel: 5,
  },
  {
    id: 'feed_shrimp_special',
    name: 'Mồi Tôm Sú & Hàu Ngọc',
    machineId: 'feed_mixer',
    tier: 2,
    icon: '🦐🥣',
    description: 'Thức ăn khoái khẩu của Tôm sú và Hàu ngọc giúp tăng cột mốc sản lượng.',
    inputs: [{ itemId: 'prod_carrot', count: 2 }, { itemId: 'prod_pumpkin', count: 1 }],
    outputItemId: 'mồi_tôm_đặc_biệt',
    outputCount: 2,
    craftTimeSeconds: 45,
    expPerUnit: 40,
    unlockLevel: 8,
  },
  {
    id: 'fert_organic_super',
    name: 'Phân Hữu Cơ Siêu Cấp',
    machineId: 'fertilizer_tower',
    tier: 2,
    icon: '🌱🧪',
    description: 'Tăng +50% đến +100% sản lượng nông sản thu hoạch!',
    inputs: [{ itemId: 'prod_chicken', count: 2 }, { itemId: 'item_mineral_mud', count: 1 }],
    outputItemId: 'phân_hữu_cơ',
    outputCount: 2,
    craftTimeSeconds: 30,
    expPerUnit: 30,
    unlockLevel: 3,
  },
  {
    id: 'fert_speed_grow',
    name: 'Phân Kích Thích Tăng Trưởng',
    machineId: 'fertilizer_tower',
    tier: 3,
    icon: '⚡🧪',
    description: 'Rút ngắn 35% thời gian sinh trưởng của cây trồng.',
    inputs: [{ itemId: 'prod_dairy_cow', count: 2 }, { itemId: 'prod_ginseng', count: 1 }],
    outputItemId: 'phân_kích_tốc',
    outputCount: 1,
    craftTimeSeconds: 60,
    expPerUnit: 65,
    unlockLevel: 10,
  },
  {
    id: 'fert_crystal_mutant',
    name: 'Phân Tinh Thể Đột Biến',
    machineId: 'fertilizer_tower',
    tier: 4,
    icon: '💎🧪',
    description: 'Tăng cơ hội đột biến ra nông sản Bậc 4 và Bậc 5 khi thu hoạch!',
    inputs: [{ itemId: 'prod_beast_pegasus', count: 1 }, { itemId: 'item_mineral_mud', count: 3 }],
    outputItemId: 'phân_tinh_thể',
    outputCount: 1,
    craftTimeSeconds: 120,
    expPerUnit: 150,
    unlockLevel: 14,
    isSpecial: true,
  }
);

// 2. Bakery recipes
const BAKERY_TEMPLATES = [
  { name: 'Bánh Mì Lúa Mì Cổ Điển', tier: 1, unlock: 3, time: 20, exp: 20, inputs: [{ itemId: 'prod_wheat', count: 2 }] },
  { name: 'Bánh Mì Bơ Tỏi Nướng Giòn', tier: 1, unlock: 4, time: 30, exp: 25, inputs: [{ itemId: 'prod_wheat', count: 2 }, { itemId: 'prod_chicken', count: 1 }] },
  { name: 'Bánh Sừng Bò Dâu Tây', tier: 2, unlock: 6, time: 50, exp: 45, inputs: [{ itemId: 'prod_wheat', count: 2 }, { itemId: 'prod_dairy_cow', count: 1 }] },
  { name: 'Bánh Mì Khoai Tây Pomato', tier: 2, unlock: 8, time: 60, exp: 50, inputs: [{ itemId: 'prod_potato', count: 2 }, { itemId: 'prod_wheat', count: 2 }] },
  { name: 'Bánh Quy Mật Ong Sữa Chúa', tier: 3, unlock: 15, time: 90, exp: 80, inputs: [{ itemId: 'prod_wheat', count: 3 }, { itemId: 'honey_bee_jade', count: 1 }] },
  { name: 'Bánh Mì Nấm Truffle Phô Mai', tier: 3, unlock: 18, time: 110, exp: 95, inputs: [{ itemId: 'prod_mush_truffle', count: 1 }, { itemId: 'prod_dairy_cow', count: 2 }] },
  { name: 'Bánh Mì Lúa Ánh Trăng', tier: 4, unlock: 13, time: 180, exp: 180, inputs: [{ itemId: 'prod_moon_grain', count: 2 }, { itemId: 'honey_bee_moon', count: 1 }], special: true },
  { name: 'Bánh Ngọt Hoa Hồng Kim Cương', tier: 5, unlock: 25, time: 300, exp: 320, inputs: [{ itemId: 'prod_star_wheat', count: 2 }, { itemId: 'prod_cosmic_rose', count: 1 }], special: true },
];

let bIndex = 1;
for (const b of BAKERY_TEMPLATES) {
  ALL_RECIPES.push({
    id: `bakery_${bIndex++}`,
    name: b.name,
    machineId: 'bakery',
    tier: b.tier as Tier,
    icon: b.tier >= 4 ? '✨🥐' : '🥐',
    description: `Món bánh thơm phức nướng tại lò nướng thủ công.`,
    inputs: b.inputs,
    outputItemId: `item_baked_${bIndex}`,
    outputCount: 1,
    craftTimeSeconds: b.time,
    expPerUnit: b.exp,
    unlockLevel: b.unlock,
    isSpecial: b.special,
  });
}

// 3. Juice & Jam
const JUICE_TEMPLATES = [
  { name: 'Nước Ép Cà Chua Tươi', tier: 1, unlock: 3, time: 15, exp: 18, inputs: [{ itemId: 'prod_tomato', count: 2 }] },
  { name: 'Sinh Tố Cà Rốt Táo Mật', tier: 1, unlock: 5, time: 25, exp: 25, inputs: [{ itemId: 'prod_carrot', count: 1 }, { itemId: 'prod_tree_apple', count: 1 }] },
  { name: 'Mứt Cam Sành Mật Ong', tier: 2, unlock: 7, time: 45, exp: 40, inputs: [{ itemId: 'prod_tree_orange', count: 2 }, { itemId: 'honey_bee_grass', count: 1 }] },
  { name: 'Sinh Tố Đào Tiên Bạc Hà', tier: 2, unlock: 9, time: 55, exp: 50, inputs: [{ itemId: 'prod_tree_peach', count: 2 }, { itemId: 'prod_mint', count: 1 }] },
  { name: 'Mứt Nho Ninh Thuận Hoàng Gia', tier: 3, unlock: 15, time: 80, exp: 75, inputs: [{ itemId: 'prod_tree_grape', count: 3 }] },
  { name: 'Sinh Tố Sầu Riêng Bơ Béo', tier: 3, unlock: 18, time: 100, exp: 90, inputs: [{ itemId: 'prod_tree_durian', count: 2 }, { itemId: 'prod_dairy_cow', count: 1 }] },
  { name: 'Nước Ép Phượng Hoàng Lửa', tier: 4, unlock: 16, time: 160, exp: 170, inputs: [{ itemId: 'prod_tree_phoenix_fruit', count: 2 }], special: true },
  { name: 'Thần Dược Mật Ong Ngân Hà Táo Tinh Tú', tier: 5, unlock: 26, time: 280, exp: 310, inputs: [{ itemId: 'prod_tree_galaxy_apple', count: 2 }, { itemId: 'honey_bee_nebula', count: 1 }], special: true },
];

let jIndex = 1;
for (const j of JUICE_TEMPLATES) {
  ALL_RECIPES.push({
    id: `juice_${jIndex++}`,
    name: j.name,
    machineId: 'juice_jam',
    tier: j.tier as Tier,
    icon: j.tier >= 4 ? '✨🧃' : '🧃',
    description: `Thức uống mát lành chiết xuất từ hoa quả tươi.`,
    inputs: j.inputs,
    outputItemId: `item_juice_${jIndex}`,
    outputCount: 1,
    craftTimeSeconds: j.time,
    expPerUnit: j.exp,
    unlockLevel: j.unlock,
    isSpecial: j.special,
  });
}

// 4. Dairy & Cheese
const DAIRY_TEMPLATES = [
  { name: 'Bơ Tươi Béo Ngậy', tier: 1, unlock: 5, time: 25, exp: 24, inputs: [{ itemId: 'prod_dairy_cow', count: 2 }] },
  { name: 'Sữa Chua Trái Cây Hỗn Hợp', tier: 1, unlock: 5, time: 30, exp: 28, inputs: [{ itemId: 'prod_dairy_cow', count: 1 }, { itemId: 'prod_tree_apple', count: 1 }] },
  { name: 'Phô Mai Dê Núi Thảo Mộc', tier: 2, unlock: 9, time: 60, exp: 55, inputs: [{ itemId: 'prod_goat', count: 2 }, { itemId: 'prod_rosemary', count: 1 }] },
  { name: 'Phô Mai Cheddar Ủ Lâu Năm', tier: 2, unlock: 11, time: 70, exp: 65, inputs: [{ itemId: 'prod_dairy_cow', count: 3 }] },
  { name: 'Phô Mai Nấm Truffle Đen', tier: 3, unlock: 20, time: 110, exp: 100, inputs: [{ itemId: 'prod_dairy_cow', count: 2 }, { itemId: 'prod_mush_truffle', count: 1 }] },
  { name: 'Phô Mai Hoàng Triều Vàng Ròng', tier: 4, unlock: 18, time: 190, exp: 200, inputs: [{ itemId: 'prod_dairy_cow', count: 3 }, { itemId: 'honey_bee_golden', count: 1 }], special: true },
  { name: 'Tinh Chất Sữa Long Châu Tinh Vân', tier: 5, unlock: 28, time: 320, exp: 350, inputs: [{ itemId: 'prod_dairy_cow', count: 4 }, { itemId: 'prod_beast_astral_dragon', count: 1 }], special: true },
];

let dIndex = 1;
for (const d of DAIRY_TEMPLATES) {
  ALL_RECIPES.push({
    id: `dairy_${dIndex++}`,
    name: d.name,
    machineId: 'dairy',
    tier: d.tier as Tier,
    icon: d.tier >= 4 ? '✨🧀' : '🧀',
    description: `Chế phẩm từ sữa thơm ngậy và bổ dưỡng.`,
    inputs: d.inputs,
    outputItemId: `item_dairy_${dIndex}`,
    outputCount: 1,
    craftTimeSeconds: d.time,
    expPerUnit: d.exp,
    unlockLevel: d.unlock,
    isSpecial: d.special,
  });
}

// 5. Loom & Textiles
const LOOM_TEMPLATES = [
  { name: 'Khăn Len Cừu Ấm Áp', tier: 2, unlock: 7, time: 45, exp: 42, inputs: [{ itemId: 'prod_merino_sheep', count: 2 }] },
  { name: 'Áo Khoác Dạ Thỏ Mềm Mại', tier: 2, unlock: 9, time: 55, exp: 50, inputs: [{ itemId: 'prod_rabbit', count: 3 }] },
  { name: 'Khăn Choàng Alpaca Hoàng Gia', tier: 3, unlock: 15, time: 90, exp: 85, inputs: [{ itemId: 'prod_alpaca', count: 2 }] },
  { name: 'Y Phục Lụa Nhuộm Hoa Sen', tier: 3, unlock: 17, time: 110, exp: 95, inputs: [{ itemId: 'prod_alpaca', count: 2 }, { itemId: 'prod_lotus', count: 2 }] },
  { name: 'Áo Choàng Thiên Mã Ánh Bạc', tier: 4, unlock: 15, time: 180, exp: 190, inputs: [{ itemId: 'prod_beast_pegasus', count: 2 }], special: true },
  { name: 'Long Bào Phượng Hoàng Bất Diệt', tier: 5, unlock: 26, time: 310, exp: 340, inputs: [{ itemId: 'prod_beast_phoenix', count: 2 }, { itemId: 'prod_cosmic_rose', count: 2 }], special: true },
];

let lIndex = 1;
for (const l of LOOM_TEMPLATES) {
  ALL_RECIPES.push({
    id: `loom_${lIndex++}`,
    name: l.name,
    machineId: 'loom',
    tier: l.tier as Tier,
    icon: l.tier >= 4 ? '✨🧥' : '🧥',
    description: `Sản phẩm dệt may tinh xảo từ sợi lông và tơ lụa quý.`,
    inputs: l.inputs,
    outputItemId: `item_textile_${lIndex}`,
    outputCount: 1,
    craftTimeSeconds: l.time,
    expPerUnit: l.exp,
    unlockLevel: l.unlock,
    isSpecial: l.special,
  });
}

// 6. Brewery & Fermentation
const BREW_TEMPLATES = [
  { name: 'Bia Đại Mạch Tươi', tier: 2, unlock: 6, time: 50, exp: 45, inputs: [{ itemId: 'prod_barley', count: 2 }] },
  { name: 'Rượu Vang Đỏ Ninh Thuận', tier: 3, unlock: 15, time: 90, exp: 80, inputs: [{ itemId: 'prod_tree_grape', count: 3 }] },
  { name: 'Rượu Mật Ong Hoa Rừng Lên Men', tier: 2, unlock: 8, time: 60, exp: 55, inputs: [{ itemId: 'honey_bee_forest', count: 2 }] },
  { name: 'Rượu Sâm Núi Đại Bổ', tier: 3, unlock: 18, time: 120, exp: 110, inputs: [{ itemId: 'prod_ginseng', count: 2 }] },
  { name: 'Rượu Tiên Quả Phượng Hoàng', tier: 4, unlock: 17, time: 190, exp: 210, inputs: [{ itemId: 'prod_tree_phoenix_fruit', count: 2 }, { itemId: 'honey_bee_moon', count: 1 }], special: true },
  { name: 'Mỹ Tửu Tinh Tú Vạn Niên', tier: 5, unlock: 27, time: 320, exp: 350, inputs: [{ itemId: 'prod_celestial_root', count: 2 }, { itemId: 'honey_bee_nebula', count: 1 }], special: true },
];

let brIndex = 1;
for (const br of BREW_TEMPLATES) {
  ALL_RECIPES.push({
    id: `brew_${brIndex++}`,
    name: br.name,
    machineId: 'brewery',
    tier: br.tier as Tier,
    icon: br.tier >= 4 ? '✨🍷' : '🍷',
    description: `Thùng gỗ sồi ủ rượu lâu năm thơm đượm nồng nàn.`,
    inputs: br.inputs,
    outputItemId: `item_brew_${brIndex}`,
    outputCount: 1,
    craftTimeSeconds: br.time,
    expPerUnit: br.exp,
    unlockLevel: br.unlock,
    isSpecial: br.special,
  });
}

// 7. Perfume & Essential Oils
const PERFUME_TEMPLATES = [
  { name: 'Tinh Dầu Bạc Hà Thanh Mát', tier: 1, unlock: 4, time: 30, exp: 26, inputs: [{ itemId: 'prod_mint', count: 3 }] },
  { name: 'Nước Hoa Hồng Sa Mạc', tier: 2, unlock: 7, time: 50, exp: 48, inputs: [{ itemId: 'prod_rose', count: 2 }] },
  { name: 'Tinh Dầu Oải Hương Ngủ Ngon', tier: 2, unlock: 11, time: 65, exp: 58, inputs: [{ itemId: 'prod_lavender', count: 3 }] },
  { name: 'Nước Hoa Lan Hồ Điệp Quý Phái', tier: 3, unlock: 19, time: 110, exp: 95, inputs: [{ itemId: 'prod_orchid', count: 2 }, { itemId: 'honey_bee_jade', count: 1 }] },
  { name: 'Hương Thơm Nguyệt Quỳnh Dạ Thần', tier: 4, unlock: 14, time: 170, exp: 190, inputs: [{ itemId: 'prod_moon_blossom', count: 2 }, { itemId: 'honey_bee_moon', count: 1 }], special: true },
  { name: 'Nước Hoa Hồng Tinh Vân Hoàng Tộc', tier: 5, unlock: 26, time: 300, exp: 330, inputs: [{ itemId: 'prod_cosmic_rose', count: 2 }, { itemId: 'honey_bee_queen_cosmic', count: 1 }], special: true },
];

let pIndex = 1;
for (const p of PERFUME_TEMPLATES) {
  ALL_RECIPES.push({
    id: `perfume_${pIndex++}`,
    name: p.name,
    machineId: 'perfume',
    tier: p.tier as Tier,
    icon: p.tier >= 4 ? '✨🧴' : '🧴',
    description: `Hương thơm tinh tế chiết xuất từ hoa màu và thảo mộc.`,
    inputs: p.inputs,
    outputItemId: `item_perfume_${pIndex}`,
    outputCount: 1,
    craftTimeSeconds: p.time,
    expPerUnit: p.exp,
    unlockLevel: p.unlock,
    isSpecial: p.special,
  });
}

// 8. Alchemy (Special)
const ALCHEMY_TEMPLATES = [
  { name: 'Linh Dược Bổ Khí Núi Cao', tier: 3, unlock: 17, time: 100, exp: 90, inputs: [{ itemId: 'prod_ginseng', count: 2 }] },
  { name: 'Đông Trùng Hoàn Nguyên Đan', tier: 4, unlock: 16, time: 180, exp: 200, inputs: [{ itemId: 'prod_cordyceps', count: 2 }], special: true },
  { name: 'Linh Dịch Sứa Nguyệt Quang', tier: 4, unlock: 15, time: 170, exp: 190, inputs: [{ itemId: 'prod_moon_jelly', count: 2 }], special: true },
  { name: 'Tiên Đan Vạn Thọ Vô Cương', tier: 5, unlock: 27, time: 310, exp: 340, inputs: [{ itemId: 'prod_celestial_root', count: 2 }, { itemId: 'prod_beast_phoenix', count: 1 }], special: true },
  { name: 'Tinh Chất Long Hồn Tinh Vân', tier: 5, unlock: 29, time: 330, exp: 360, inputs: [{ itemId: 'prod_beast_astral_dragon', count: 2 }, { itemId: 'prod_star_whale', count: 1 }], special: true },
];

let alIndex = 1;
for (const al of ALCHEMY_TEMPLATES) {
  ALL_RECIPES.push({
    id: `alchemy_${alIndex++}`,
    name: al.name,
    machineId: 'alchemy',
    tier: al.tier as Tier,
    icon: '⚗️✨',
    description: `Đan dược huyền bí tôi luyện trong lò luyện đan cổ truyền.`,
    inputs: al.inputs,
    outputItemId: `item_alchemy_${alIndex}`,
    outputCount: 1,
    craftTimeSeconds: al.time,
    expPerUnit: al.exp,
    unlockLevel: al.unlock,
    isSpecial: true,
  });
}

// 9. Jewelry & Crafts (Special)
const JEWELRY_TEMPLATES = [
  { name: 'Chuỗi Vòng Ngọc Trai Phú Quốc', tier: 3, unlock: 16, time: 100, exp: 95, inputs: [{ itemId: 'prod_pearl_oyster', count: 2 }] },
  { name: 'Bội Bạc Vảy Cá Koi Ngũ Thái', tier: 3, unlock: 19, time: 110, exp: 100, inputs: [{ itemId: 'prod_koi_fish', count: 2 }] },
  { name: 'Trâm Cài Tóc Thiên Mã Ánh Bạc', tier: 4, unlock: 15, time: 180, exp: 210, inputs: [{ itemId: 'prod_beast_pegasus', count: 2 }, { itemId: 'prod_pearl_oyster', count: 2 }], special: true },
  { name: 'Giáp Hộ Thân Kỳ Lân Vàng', tier: 4, unlock: 18, time: 200, exp: 230, inputs: [{ itemId: 'prod_beast_kirin', count: 2 }], special: true },
  { name: 'Vương Miện Long Châu Tinh Tú', tier: 5, unlock: 28, time: 320, exp: 370, inputs: [{ itemId: 'prod_beast_astral_dragon', count: 2 }, { itemId: 'prod_pearl_oyster', count: 4 }], special: true },
];

let jwIndex = 1;
for (const jw of JEWELRY_TEMPLATES) {
  ALL_RECIPES.push({
    id: `jewelry_${jwIndex++}`,
    name: jw.name,
    machineId: 'jewelry',
    tier: jw.tier as Tier,
    icon: '💎👑',
    description: `Châu báu mỹ nghệ tinh xảo từ vỏ ngọc và linh thú.`,
    inputs: jw.inputs,
    outputItemId: `item_jewelry_${jwIndex}`,
    outputCount: 1,
    craftTimeSeconds: jw.time,
    expPerUnit: jw.exp,
    unlockLevel: jw.unlock,
    isSpecial: true,
  });
}

// 10. Gourmet Kitchen (Special)
const GOURMET_TEMPLATES = [
  { name: 'Yến Tiệc Nấm Truffle & Cá Tra Sông Tiền', tier: 3, unlock: 20, time: 120, exp: 120, inputs: [{ itemId: 'prod_mush_truffle', count: 1 }, { itemId: 'prod_catfish', count: 2 }] },
  { name: 'Lẩu Thủy Tộc Tôm Sú Cua Biển', tier: 3, unlock: 18, time: 110, exp: 110, inputs: [{ itemId: 'prod_shrimp', count: 2 }, { itemId: 'prod_crab', count: 2 }] },
  { name: 'Đại Tiệc Cung Đình Súp Hải Long Vảy Bạc', tier: 4, unlock: 21, time: 210, exp: 240, inputs: [{ itemId: 'prod_leviathan_mini', count: 2 }, { itemId: 'prod_tree_phoenix_fruit', count: 1 }], special: true },
  { name: 'Yến Tiệc Càn Khôn Vạn Thọ Ngân Hà', tier: 5, unlock: 28, time: 330, exp: 390, inputs: [{ itemId: 'prod_star_whale', count: 2 }, { itemId: 'prod_tree_galaxy_apple', count: 2 }, { itemId: 'prod_beast_phoenix', count: 1 }], special: true },
];

let gmIndex = 1;
for (const gm of GOURMET_TEMPLATES) {
  ALL_RECIPES.push({
    id: `gourmet_${gmIndex++}`,
    name: gm.name,
    machineId: 'gourmet',
    tier: gm.tier as Tier,
    icon: '🍲👑',
    description: `Món đại tiệc ẩm thực cung đình kết hợp tinh hoa nông trại.`,
    inputs: gm.inputs,
    outputItemId: `item_gourmet_${gmIndex}`,
    outputCount: 1,
    craftTimeSeconds: gm.time,
    expPerUnit: gm.exp,
    unlockLevel: gm.unlock,
    isSpecial: true,
  });
}

// Generate remaining recipes across machines to reach 400+ recipes total
const machinesList: MachineType[] = ['bakery', 'juice_jam', 'dairy', 'loom', 'brewery', 'perfume', 'alchemy', 'jewelry', 'gourmet'];
const dishPrefixes = ['Thượng Hạng', 'Ngự Thiện', 'Gia Truyền', 'Phù Sa', 'Mỹ Vị', 'Tuyết Hoa', 'Hương Đồng', 'Bách Thảo', 'Hoàng Kim', 'Cực Phẩm', 'Huyền Bí', 'Vũ Trụ', 'Trăng Rằm', 'Bình Minh', 'Đại Dương'];
const dishTypes = ['Bánh Mì', 'Mứt Trái Cây', 'Nước Ép', 'Phô Mai', 'Trà Thảo Mộc', 'Lụa Gấm', 'Rượu Mật', 'Tinh Dầu', 'Thuốc Hoàn', 'Trang Sức', 'Món Hầm'];

let autoRecipeCounter = 1;
for (const m of machinesList) {
  for (const pre of dishPrefixes) {
    for (const dt of dishTypes) {
      if (ALL_RECIPES.length >= 415) break;
      const tier: Tier = autoRecipeCounter % 16 === 0 ? 5 : autoRecipeCounter % 7 === 0 ? 4 : autoRecipeCounter % 3 === 0 ? 3 : autoRecipeCounter % 2 === 0 ? 2 : 1;
      ALL_RECIPES.push({
        id: `recipe_auto_${autoRecipeCounter}`,
        name: `${dt} ${pre} #${autoRecipeCounter}`,
        machineId: m,
        tier,
        icon: tier >= 4 ? '✨🍱' : '🍱',
        description: `Thành phẩm ${dt} chế biến từ nông sản và thảo mộc chất lượng cao.`,
        inputs: [{ itemId: 'prod_wheat', count: 1 }, { itemId: 'prod_tomato', count: 1 }],
        outputItemId: `prod_crafted_${autoRecipeCounter}`,
        outputCount: 1,
        craftTimeSeconds: tier * 30,
        expPerUnit: tier * 25,
        unlockLevel: tier === 1 ? 3 : tier === 2 ? 6 : tier === 3 ? 15 : tier === 4 ? 14 : 25,
        isSpecial: tier >= 4,
      });
      autoRecipeCounter++;
    }
  }
}

export const RECIPES_MAP = new Map<string, CraftingRecipe>(ALL_RECIPES.map((r) => [r.id, r]));
