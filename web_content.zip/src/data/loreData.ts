import {
  ConstitutionType,
  ConstitutionEffect,
  SpiritRootType,
  TalentTier,
  TournamentBooster
} from '../types/cultivation';

export const CONSTITUTION_EFFECTS: Record<ConstitutionType, ConstitutionEffect> = {
  'Mortal Bone': {
    name: 'Mortal Bone',
    title: 'Mortal Standard',
    positive: ['Standard meridian pathways with no elemental incompatibilities.', 'Free from elemental counter vulnerabilities.'],
    negative: ['Lacks divine physique traits; relies entirely on diligence.'],
    combatBonus: 0,
    qiCostMultiplier: 1.0,
    stressVulnerability: 1.0
  },
  'Innate Sword Embryo': {
    name: 'Innate Sword Embryo',
    title: 'Sword Paragon',
    positive: ['+45% Sword Intent & Critical Combat Power.', 'Natural mastery of sword and martial manuals.'],
    negative: ['-20% Alchemy and medicinal herb refinement affinity.'],
    combatBonus: 45,
    qiCostMultiplier: 1.05,
    stressVulnerability: 1.1
  },
  'Ancient Desolate Sacred Physique': {
    name: 'Ancient Desolate Sacred Physique',
    title: 'Primordial Titan Body',
    positive: ['+70% Physical Resistance & overwhelming crushing force.', 'Unmatched physical fortitude in life-or-death duels.'],
    negative: ['Requires 2.2x more Qi to shatter cultivation bottlenecks.'],
    combatBonus: 70,
    qiCostMultiplier: 2.2,
    stressVulnerability: 0.8
  },
  'Pure Yang Divine Body': {
    name: 'Pure Yang Divine Body',
    title: 'Solar Radiance',
    positive: ['+50% Fire/Thunder elemental potency & explosive burst damage.', 'Natural warmth cleanses minor body poisons.'],
    negative: ['+30% Stress accumulation; susceptible to heat deviation and inner fire.'],
    combatBonus: 50,
    qiCostMultiplier: 1.1,
    stressVulnerability: 1.3
  },
  'Pure Yin Sacred Body': {
    name: 'Pure Yin Sacred Body',
    title: 'Lunar Serenity',
    positive: ['+40% Water/Ice arts & serene spiritual flow (-25% stress gain).', 'Calm disposition prevents mental deviance.'],
    negative: ['-20% Resistance to extreme frost tribulations.'],
    combatBonus: 40,
    qiCostMultiplier: 0.95,
    stressVulnerability: 0.75
  },
  'Nine Heavens Phoenix Body': {
    name: 'Nine Heavens Phoenix Body',
    title: 'Phoenix Rebirth',
    positive: ['Revives with 50% HP upon fatal blow.', '+35% Alchemy cauldron control.'],
    negative: ['+25% Jealousy attraction from ambitious peers.'],
    combatBonus: 55,
    qiCostMultiplier: 1.15,
    stressVulnerability: 1.0
  },
  'Five Elements Dao Body': {
    name: 'Five Elements Dao Body',
    title: 'Harmonious Cycle',
    positive: ['Seamlessly channels all 5 elements (+20% all pavilion yields).', 'Balanced meridians with zero elemental flaws.'],
    negative: ['Even distribution without a single ultra-specialized damage spike.'],
    combatBonus: 35,
    qiCostMultiplier: 1.0,
    stressVulnerability: 0.9
  },
  'Void Spiritual Constitution': {
    name: 'Void Spiritual Constitution',
    title: 'Spatial Phase',
    positive: ['+65% Evasion, swift movement, and -30% Secret Realm durations.', 'Can phase through physical barricades.'],
    negative: ['-20% Base physical defense against direct blunt trauma.'],
    combatBonus: 40,
    qiCostMultiplier: 1.0,
    stressVulnerability: 1.05
  },
  'Clear Jade Physique': {
    name: 'Clear Jade Physique',
    title: 'Untainted Jade',
    positive: ['Immune to worldly poisons & miasma.', '-50% stress accumulation in trials.'],
    negative: ['-10% Raw lethal offensive strike output.'],
    combatBonus: 20,
    qiCostMultiplier: 0.9,
    stressVulnerability: 0.5
  },
  'Nether Void Body': {
    name: 'Nether Void Body',
    title: 'Nether Abyss Void Physique',
    positive: ['+60% Ghostly Nether damage & ignores 30% enemy defense barriers.', 'Immune to soul chill debuffs.'],
    negative: ['-15% affinity with orthodox Sunlight Yang arrays.'],
    combatBonus: 50,
    qiCostMultiplier: 1.1,
    stressVulnerability: 1.15
  }
};

export const SPIRIT_ROOT_DESCRIPTIONS: Record<SpiritRootType, { title: string; perk: string; weakness: string; color: string }> = {
  Metal: {
    title: 'White Tiger Metal Root',
    perk: 'Slices through defense barriers; increases Weapon Forge yield by +25%.',
    weakness: 'Vulnerable to Fire arts melting sword intent.',
    color: '#cbd5e1'
  },
  Wood: {
    title: 'Azure Dragon Wood Root',
    perk: 'Steadily regenerates vitality in battle; boosts Spirit Herb Nursery by +30%.',
    weakness: 'Vulnerable to Metal cleaving and cutting.',
    color: '#22c55e'
  },
  Water: {
    title: 'Black Tortoise Water Root',
    perk: 'Absorbs enemy momentum, dispels inner demons, +25% Array Qi gathering.',
    weakness: 'Damned and absorbed by Earth barriers.',
    color: '#06b6d4'
  },
  Fire: {
    title: 'Vermilion Bird Fire Root',
    perk: 'Blazing offensive damage, triggers combustion status, +35% Alchemy rate.',
    weakness: 'Easily extinguished by Water tides.',
    color: '#ef4444'
  },
  Earth: {
    title: 'Qilin Earth Root',
    perk: 'Unshakeable armor shield, +35% Spirit Stone Vein mining production.',
    weakness: 'Sapped of vital nutrients by Wood roots.',
    color: '#d97706'
  },
  Thunder: {
    title: 'Nine Heavenly Thunder Root',
    perk: 'Devastating lightning arcs; deflects 40% of Heavenly Tribulation lightning.',
    weakness: 'High energy consumption per strike.',
    color: '#eab308'
  },
  Ice: {
    title: 'Glacial Absolute Zero Root',
    perk: 'Freezes target turns, slowing battle actions; immune to heat fever.',
    weakness: 'Susceptible to supreme Pure Yang flames.',
    color: '#38bdf8'
  },
  Wind: {
    title: 'Astral Gale Wind Root',
    perk: 'Swift evasion, strikes first in combat rounds, shortens expedition travel.',
    weakness: 'Weak against solid Earth fortifications.',
    color: '#10b981'
  },
  'Yin-Yang': {
    title: 'Taiji Yin-Yang Root',
    perk: 'Dual resonance; seamlessly rotates offense and defense every battle turn.',
    weakness: 'Requires strict mental discipline to prevent duality clashes.',
    color: '#c084fc'
  },
  Chaos: {
    title: 'Primordial Chaos Root',
    perk: 'Pre-dates heaven and earth; bypasses all regular 5-element damage resistances.',
    weakness: 'Exceptionally rare; coveted by demonic cultivators.',
    color: '#f43f5e'
  },
  Heavenly: {
    title: 'Heavenly Sovereign Dao Root',
    perk: 'Resonates with the Heavenly Law (+30% cultivation speed, zero root penalties).',
    weakness: 'Draws envious gazes from foreign sect masters.',
    color: '#fce18b'
  },
  Immortal: {
    title: 'Immortal Ascendant Root',
    perk: 'Permanent +300 years lifespan; bottlenecks cannot halt their progression.',
    weakness: 'None; the supreme summit of mortal aptitude.',
    color: '#34d399'
  }
};

export function getTalentTierFromScore(score: number): TalentTier {
  if (score >= 95) return 'Innate';
  if (score >= 85) return 'Prodigy';
  if (score >= 70) return 'Talented';
  if (score >= 55) return 'Mediocre';
  if (score >= 40) return 'Lazy';
  return 'Poor';
}

export const TALENT_TIER_DETAILS: Record<TalentTier, { label: string; desc: string; badgeClass: string; cultivationSpeedMultiplier: number }> = {
  Poor: {
    label: 'Poor',
    desc: 'Clogged meridians. Requires constant guidance and elixir nourishment to advance.',
    badgeClass: 'bg-stone-800 text-stone-300 border-stone-600',
    cultivationSpeedMultiplier: 0.6
  },
  Lazy: {
    label: 'Lazy',
    desc: 'Decent innate talent, but prone to slumber, wine, and skipping morning Qi gathering.',
    badgeClass: 'bg-amber-950/70 text-amber-300 border-amber-600/40',
    cultivationSpeedMultiplier: 0.8
  },
  Mediocre: {
    label: 'Mediocre',
    desc: 'Ordinary mortal comprehension. Steadfast diligence can still yield Foundation breakthrough.',
    badgeClass: 'bg-slate-800 text-slate-300 border-slate-600',
    cultivationSpeedMultiplier: 1.0
  },
  Talented: {
    label: 'Talented',
    desc: 'Clear spiritual sight. Learns Daoist martial manuals with natural ease.',
    badgeClass: 'bg-blue-950/80 text-blue-300 border-blue-500/50',
    cultivationSpeedMultiplier: 1.35
  },
  Prodigy: {
    label: 'Prodigy',
    desc: 'Born with open acupoints. Cultivates at double the mortal speed.',
    badgeClass: 'bg-purple-950/80 text-purple-300 border-purple-500/50',
    cultivationSpeedMultiplier: 2.0
  },
  Innate: {
    label: 'Innate Dao',
    desc: 'Incarnation of a Heavenly Immortal. The Grand Dao murmurs directly into their consciousness.',
    badgeClass: 'bg-amber-900/90 text-yellow-200 border-yellow-400 font-bold animate-pulse',
    cultivationSpeedMultiplier: 3.5
  }
};

export const STAT_DESCRIPTIONS: Record<string, { title: string; description: string; impact: string }> = {
  currentRealmIndex: {
    title: 'Cultivation Realm',
    description: 'The spiritual stage of enlightenment across the 27 classical Daoist realms from Qi Condensation to Ascension.',
    impact: 'Directly dictates combat power, lifespan bonuses, skill unlocks, and equipment tier eligibility.'
  },
  cultivationExp: {
    title: 'Cultivation Experience (Qi Accumulation)',
    description: 'Spiritual energy gathered in the dantian through daily meditation, arrays, and sermons.',
    impact: 'When full (Exp >= Max Exp), enables the disciple to attempt a bottleneck breakthrough or face Heavenly Tribulation.'
  },
  talent: {
    title: 'Innate Talent Score',
    description: 'A numerical appraisal (1-100) of spiritual meridian clarity and Dao comprehension.',
    impact: 'Determines the baseline cultivation experience gained every second.'
  },
  talentTier: {
    title: 'Talent Classification',
    description: 'Categorized into Poor, Lazy, Mediocre, Talented, Prodigy, and Innate Dao.',
    impact: 'Influences passive breakthrough success probability, sermon absorption, and random enlightenment events.'
  },
  combatPower: {
    title: 'Combat Power (Martial Might)',
    description: 'Aggregate offensive and defensive strength derived from cultivation realm, equipment, and constitution.',
    impact: 'Used in Peak Challenge Tournaments, Secret Realm Expeditions, and Foreign Incursions defense.'
  },
  lifespan: {
    title: 'Lifespan & Longevity',
    description: 'The natural mortal years remaining before physical decay. Increases with every realm breakthrough.',
    impact: 'If a disciple exhausts their lifespan before ascending, they pass into karmic reincarnation.'
  },
  loyalty: {
    title: 'Sect Loyalty',
    description: 'Dedication to the Sect Master and reverence for the ancestral lineage.',
    impact: 'High loyalty (80+) prevents defection and betrayal. 100% loyalty grants permanent morale boost.'
  },
  morale: {
    title: 'Cultivator Morale',
    description: 'Mental spirit and enthusiasm for sect duties and martial progression.',
    impact: 'High morale grants +20% bonus expedition loot; low morale (<30) stalls meditation.'
  },
  stress: {
    title: 'Stress & Inner Demons',
    description: 'Tension, cultivation fatigue, and psychological turmoil accumulated from trials and grudges.',
    impact: 'Severe stress (>75) triggers cultivation deviations, Qi deviation explosions, and tribulation vulnerability.'
  },
  contribution: {
    title: 'Sect Contribution Points',
    description: 'Merits earned through pavilion commissions, diplomacy, alchemy, and tournament victories.',
    impact: 'Required for legitimate promotions (Inner, Direct, Elder) without triggering peer jealousy.'
  },
  championTitle: {
    title: 'Peak Challenge Champion Glory',
    description: 'Awarded to supreme arena victors (Champion I, Champion II, Champion S).',
    impact: 'Grants Special Prodigy Status: reduces all peer jealousy and grudges by 90%, boosts sect prestige.'
  }
};

export const TOURNAMENT_BOOSTERS: TournamentBooster[] = [
  {
    id: 'boost_none',
    name: 'Unassisted (Pure Skill)',
    description: 'Rely solely on natural cultivation foundation and martial discipline.',
    effect: '+0% Bonus',
    effectDescription: '+0% Pure Martial Arts',
    cost: 0,
    hpBonus: 0,
    energyBonus: 0,
    powerMultiplier: 1.0
  },
  {
    id: 'boost_dragon_blood',
    name: 'Dragon Blood Vitality Draught',
    description: '+35% Max HP and natural recovery between combat rounds.',
    effect: '+35% Max HP & Recovery',
    effectDescription: '+35% Max HP & Vitality',
    cost: 40,
    hpBonus: 35,
    energyBonus: 0,
    powerMultiplier: 1.05
  },
  {
    id: 'boost_astral_qi',
    name: 'Astral Qi Meridian Pellet',
    description: '+40 Max Energy (Qi), allowing rapid skill casting and domain arts.',
    effect: '+40 Energy & Fast Cast',
    effectDescription: '+40 Max Qi Energy',
    cost: 50,
    hpBonus: 0,
    energyBonus: 40,
    powerMultiplier: 1.1
  },
  {
    id: 'boost_sovereign_talisman',
    name: 'Golden Armored Ward Talisman',
    description: 'Absorbs initial damage and provides +20% Combat Power boost.',
    effect: '+20% Power & Shield',
    effectDescription: '+20% Combat Power & Shield',
    cost: 75,
    hpBonus: 20,
    energyBonus: 20,
    powerMultiplier: 1.2
  }
];

export const CHAMPION_TITLE_PERKS = {
  'Champion I': {
    title: 'Champion I (Bronze Arena Victor)',
    perks: ['+15% Cultivation Speed', '+10% Combat Power in Arena', '-50% Peer Jealousy']
  },
  'Champion II': {
    title: 'Champion II (Silver Peak Duelist)',
    perks: ['+25% Cultivation Speed', '+20% Combat Power', '-75% Peer Jealousy', '+15 Sect Prestige/mo']
  },
  'Champion S': {
    title: 'Champion S (Grand Supreme Arena Paragon)',
    perks: ['+40% Cultivation Speed', '+35% Combat Power', 'Immune to all Peer Grudges', '+50 Sect Prestige/mo']
  }
};
