import { Product, Review, RoomChecklistItem } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'bue-bed-01',
    name: 'Artisanal Oatmeal French Linen Duvet Set',
    arabicSubtitle: 'طقم غطاء لحاف من الكتان الفرنسي الطبيعي',
    category: 'Bedding & Linens',
    room: 'Bedroom',
    priceUsd: 145,
    originalPriceUsd: 175,
    rating: 4.9,
    reviewsCount: 38,
    image: '/src/assets/images/product_linen_bedding_1792296361540.jpg',
    description: 'Woven from 100% natural Normandy flax, stone-washed for immediate relaxed softness. Breathable, thermo-regulating in all seasons, and pre-shrunk for effortless care.',
    materials: '100% Normandy Flax Linen, Coconut Shell Buttons, Oeko-Tex Standard 100 Certified',
    dimensions: 'Duvet: 230 × 220 cm | 2× Pillowcases: 50 × 75 cm',
    inStock: true,
    stockCount: 14,
    careInstructions: 'Machine wash cool on gentle cycle. Tumble dry low or line dry in shade. Natural crinkle texture requires no ironing.',
    features: [
      'Pre-washed with volcanic stones for immediate softness',
      'Naturally hypoallergenic & antimicrobial',
      'Hidden natural shell button closures',
      'Deep internal corner ties to secure duvet insert'
    ],
    badge: 'Bestseller'
  },
  {
    id: 'bue-kit-02',
    name: 'Speckled Stoneware 16-Piece Dinnerware Set',
    arabicSubtitle: 'طقم أواني طعام فخارية مصنوع يدوياً',
    category: 'Kitchen & Dining',
    room: 'Dining Room',
    priceUsd: 120,
    originalPriceUsd: 145,
    rating: 4.8,
    reviewsCount: 52,
    image: '/src/assets/images/product_ceramic_dinnerware_1792296362815.jpg',
    description: 'Hand-thrown durable stoneware crafted by master potters with an organic matte finish and subtle mineral speckling. Designed for both elevated dinner parties and everyday warmth.',
    materials: 'High-fire ceramic stoneware, food-safe lead-free matte glaze',
    dimensions: '4× Dinner Plates (27cm), 4× Salad Plates (21cm), 4× Cereal/Pasta Bowls (16cm), 4× Morning Mugs (350ml)',
    inStock: true,
    stockCount: 8,
    careInstructions: 'Microwave, oven (up to 200°C), and dishwasher safe. Avoid extreme sudden thermal shock.',
    features: [
      'Each piece exhibits unique organic rim geometry',
      'Chip-resistant high-fire ceramic body',
      'Stackable nesting design for space efficiency',
      'Stain-resistant matte satin exterior'
    ],
    badge: 'Artisanal'
  },
  {
    id: 'bue-frg-03',
    name: 'Royal Amber & Oud Wood Reed Diffuser & Candle Set',
    arabicSubtitle: 'مجموعة ناشر العطر والشموع بالعنبر والعود الفاخر',
    category: 'Fragrance & Oud',
    room: 'Living Room',
    priceUsd: 68,
    originalPriceUsd: 80,
    rating: 5.0,
    reviewsCount: 74,
    image: '/src/assets/images/product_oud_diffuser_1792296361488.jpg',
    description: 'An evocative olfactory journey with rich Cambodian oud wood, warm amber resin, crushed cardamom, and smoky cedarwood. Hand-poured in heavy amber glass with pure brass hardware.',
    materials: 'Natural essential oil blend, VOC-free diffuser base, unbleached black rattan reeds, 100% natural soy wax candle',
    dimensions: 'Diffuser: 250ml (up to 4 months scent throw) | Candle: 220g (50+ hours burn)',
    inStock: true,
    stockCount: 22,
    careInstructions: 'Flip reeds every 7-10 days to refresh the aroma. Keep away from direct draft and direct intense sunlight.',
    features: [
      'Infused with rare Cambodian oud wood extracts',
      'No synthetic phthalates, parabens, or petroleum paraffin',
      'Heavy weighted apothecary glass with brushed brass collar',
      'Includes 8 microporous dense rattan reeds'
    ],
    badge: 'Signature Scent'
  },
  {
    id: 'bue-liv-04',
    name: 'Bait Travertine & Walnut Sanctuary Coffee Table',
    arabicSubtitle: 'طاولة قهوة ترافرتين رخامية مع خشب الجوز',
    category: 'Living & Storage',
    room: 'Living Room',
    priceUsd: 380,
    originalPriceUsd: 450,
    rating: 4.9,
    reviewsCount: 19,
    image: '/src/assets/images/hero_home_essentials_1792296360356.jpg',
    description: 'Carved from monolithic honed beige travertine with rich natural cavities and paired with solid American walnut sub-supports. An architectural statement piece for grounding any living room.',
    materials: 'Natural unfilled honed beige travertine, sustainably sourced solid American walnut',
    dimensions: '110 × 70 × 36 cm | Weight: 42 kg',
    inStock: true,
    stockCount: 4,
    careInstructions: 'Wipe with damp cloth and mild neutral soap. Avoid acidic liquids. Seal annually with natural stone sealant.',
    features: [
      'Authentic honed natural limestone with unique vein patterns',
      'Chamfered safety edge finishing',
      'Precision concealed structural joinery',
      'Felt-padded base to protect hardwood and marble floors'
    ]
  },
  {
    id: 'bue-bat-05',
    name: 'Plush Turkish Ribbed Waffle Bath Sheet Bundle',
    arabicSubtitle: 'طقم مناشف الحمام التركية الفاخرة بنسيج الوافل',
    category: 'Bath & Wellness',
    room: 'Bathroom',
    priceUsd: 85,
    originalPriceUsd: 105,
    rating: 4.9,
    reviewsCount: 46,
    image: '/src/assets/images/product_linen_bedding_1792296361540.jpg',
    description: 'Crafted in Denizli, Turkey from extra-long staple Aegean combed cotton (700 GSM). Ultra-absorbent waffle honeycomb texture dries quickly and softens with every wash.',
    materials: '100% Aegean Combed Cotton (700 GSM), Oeko-Tex Certified',
    dimensions: '2× Bath Sheets (90 × 160 cm), 2× Hand Towels (50 × 90 cm), 2× Washcloths (30 × 30 cm)',
    inStock: true,
    stockCount: 16,
    careInstructions: 'Wash before first use at 40°C. Avoid silicone fabric softeners which coat fibers and decrease absorbency.',
    features: [
      'High-density 700 GSM weight for sumptuous luxury',
      'Dual texture: waffle weave on front, plush zero-twist terry on reverse',
      'Integrated woven hanging loop on all pieces',
      'Quick-drying cellular weave inhibits odor'
    ]
  },
  {
    id: 'bue-kit-06',
    name: 'End-Grain Solid Walnut Butcher Block & Knife Rest',
    arabicSubtitle: 'لوح تقطيع خشبي فاخر من خشب الجوز الصلب',
    category: 'Kitchen & Dining',
    room: 'Kitchen',
    priceUsd: 95,
    originalPriceUsd: 115,
    rating: 4.9,
    reviewsCount: 31,
    image: '/src/assets/images/product_ceramic_dinnerware_1792296362815.jpg',
    description: 'Handcrafted from kiln-dried North American black walnut in an end-grain configuration that protects knife blade sharpness. Features deep perimeter juice grooves and recessed ergonomic handles.',
    materials: 'Solid North American Walnut, Food-grade Mineral Oil & Organic Beeswax Finish',
    dimensions: '45 × 32 × 4.5 cm | Weight: 4.2 kg',
    inStock: true,
    stockCount: 11,
    careInstructions: 'Hand wash only with warm soapy water and dry immediately. Treat with board butter every 4 weeks.',
    features: [
      'Self-healing end-grain construction prevents deep knife grooves',
      'Continuous perimeter juice well prevents countertop messes',
      'Concealed underside finger grips for easy lifting',
      'Non-slip silicone food-grade feet'
    ]
  },
  {
    id: 'bue-frg-07',
    name: 'Hand-Hammered Antique Brass Bukhoor & Frankincense Censer',
    arabicSubtitle: 'مبخرة نحاسية مطروقة يدوياً للبخور واللبان',
    category: 'Fragrance & Oud',
    room: 'Living Room',
    priceUsd: 55,
    originalPriceUsd: 65,
    rating: 4.8,
    reviewsCount: 63,
    image: '/src/assets/images/product_oud_diffuser_1792296361488.jpg',
    description: 'Hand-beaten solid brass burner with floral geometric perforations that diffuse fragrant smoke gracefully. Features an insulated wood foot base and removable charcoal screen.',
    materials: 'Heavy gauge solid brass, heat-resistant wooden base',
    dimensions: 'Diameter: 13 cm | Height: 19 cm',
    inStock: true,
    stockCount: 19,
    careInstructions: 'Let cool completely before emptying ashes. Polish with brass cleaner or natural lemon and salt to maintain patina.',
    features: [
      'Traditional hand-hammered finish with pierced arabesque motifs',
      'Safe heat-insulated base prevents surface burns',
      'Includes brass tong for charcoal and bukhoor placement',
      'Works with both charcoal tablets and tealight candle diffusers'
    ],
    badge: 'Traditional Craft'
  },
  {
    id: 'bue-liv-08',
    name: 'Handwoven Natural Jute & Seagrass Floor Storage Hamper',
    arabicSubtitle: 'سلة تخزين منسوجة يدوياً من الخيش والأعشاب البحرية',
    category: 'Living & Storage',
    room: 'Living Room',
    priceUsd: 48,
    originalPriceUsd: 58,
    rating: 4.7,
    reviewsCount: 29,
    image: '/src/assets/images/hero_home_essentials_1792296360356.jpg',
    description: 'Thick coiled natural jute and sun-dried river seagrass with reinforced handles and removable unbleached cotton lining. Ideal for throw blankets, cushions, or nursery storage.',
    materials: '100% Wild Jute, River Seagrass, Unbleached Cotton Canvas Lining',
    dimensions: 'Diameter: 42 cm | Height: 48 cm',
    inStock: true,
    stockCount: 15,
    careInstructions: 'Spot clean with a damp sponge. Removable canvas liner is machine washable at 30°C.',
    features: [
      'Sturdy coiled construction holds shape when empty',
      'Thick braided dual handles support up to 18kg',
      'Protective natural canvas liner prevents snagging knitwear',
      '100% biodegradable and chemical-free'
    ]
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-01',
    productId: 'bue-bed-01',
    author: 'Zainab M.',
    rating: 5,
    date: 'October 12, 2026',
    title: 'The best linen bedding I have ever slept in',
    comment: 'The French linen is astonishingly soft right out of the package. It regulates temperature completely through the night—no sweating, just pure breathable comfort. Bait ul Ukasha exceeded all expectations.',
    verifiedPurchase: true
  },
  {
    id: 'rev-02',
    productId: 'bue-kit-02',
    author: 'Tariq K.',
    rating: 5,
    date: 'October 8, 2026',
    title: 'Stunning craftsmanship and heavy weight',
    comment: 'The mineral speckling and subtle handmade touch make our dining table look like an editorial photoshoot. They wash easily in the dishwasher and have zero scratches after 3 weeks of daily use.',
    verifiedPurchase: true
  },
  {
    id: 'rev-03',
    productId: 'bue-frg-03',
    author: 'Maryam S.',
    rating: 5,
    date: 'September 29, 2026',
    title: 'Warm, majestic oud scent without being overpowering',
    comment: 'Most diffusers give me a headache, but this Cambodian oud and amber blend is refined and welcoming. Visitors compliment our home entrance immediately!',
    verifiedPurchase: true
  }
];

export const INITIAL_ROOM_CHECKLIST: RoomChecklistItem[] = [
  // Bedroom
  { id: 'chk-b1', room: 'Bedroom', name: 'French Linen Duvet Set & Fitted Sheet', checked: true, estimatedCostUsd: 145, productId: 'bue-bed-01' },
  { id: 'chk-b2', room: 'Bedroom', name: 'Mulberry Silk Pillowcases & Eye Mask', checked: true, estimatedCostUsd: 55 },
  { id: 'chk-b3', room: 'Bedroom', name: 'Weighted Linen Throw & Decorative Cushions', checked: false, estimatedCostUsd: 75 },
  { id: 'chk-b4', room: 'Bedroom', name: 'Amber Bedside Scent Candle & Brass Snuffer', checked: true, estimatedCostUsd: 40 },
  
  // Kitchen
  { id: 'chk-k1', room: 'Kitchen', name: 'End-Grain Walnut Cutting Board', checked: true, estimatedCostUsd: 95, productId: 'bue-kit-06' },
  { id: 'chk-k2', room: 'Kitchen', name: 'Stoneware Oil & Vinegar Cruet Pair', checked: true, estimatedCostUsd: 38 },
  { id: 'chk-k3', room: 'Kitchen', name: 'Waffle Linen Dish Towels (Set of 4)', checked: false, estimatedCostUsd: 32 },
  { id: 'chk-k4', room: 'Kitchen', name: 'Hand-forged Kitchen Shears & Herb Stripper', checked: false, estimatedCostUsd: 28 },

  // Dining Room
  { id: 'chk-d1', room: 'Dining Room', name: '16-Piece Handcrafted Stoneware Set', checked: true, estimatedCostUsd: 120, productId: 'bue-kit-02' },
  { id: 'chk-d2', room: 'Dining Room', name: 'Matte Brushed Gold Cutlery Set (24-Piece)', checked: true, estimatedCostUsd: 85 },
  { id: 'chk-d3', room: 'Dining Room', name: 'Organic Linen Table Runner & 6 Napkins', checked: false, estimatedCostUsd: 48 },
  { id: 'chk-d4', room: 'Dining Room', name: 'Hand-blown Ribbed Glass Water Carafe', checked: false, estimatedCostUsd: 35 },

  // Living Room
  { id: 'chk-l1', room: 'Living Room', name: 'Royal Amber & Oud Diffuser + Candle', checked: true, estimatedCostUsd: 68, productId: 'bue-frg-03' },
  { id: 'chk-l2', room: 'Living Room', name: 'Monolithic Travertine Low Accent Table', checked: false, estimatedCostUsd: 380, productId: 'bue-liv-04' },
  { id: 'chk-l3', room: 'Living Room', name: 'Hand-hammered Brass Bukhoor Censer', checked: true, estimatedCostUsd: 55, productId: 'bue-frg-07' },
  { id: 'chk-l4', room: 'Living Room', name: 'Handwoven Seagrass Floor Basket', checked: true, estimatedCostUsd: 48, productId: 'bue-liv-08' },

  // Bathroom
  { id: 'chk-w1', room: 'Bathroom', name: 'Turkish Ribbed Waffle Bath Sheet Bundle', checked: true, estimatedCostUsd: 85, productId: 'bue-bat-05' },
  { id: 'chk-w2', room: 'Bathroom', name: 'Monolithic Travertine Soap Dispenser & Tray', checked: true, estimatedCostUsd: 42 },
  { id: 'chk-w3', room: 'Bathroom', name: 'Natural Sisal Exfoliating Dry Brush', checked: false, estimatedCostUsd: 18 },
  { id: 'chk-w4', room: 'Bathroom', name: 'Eucalyptus & Sea Salt Bath Soak Jar', checked: false, estimatedCostUsd: 24 }
];
