import { Category } from '../types';

export const CATEGORIES: Category[] = [
  {
    id: 'mathematics',
    name: 'Mathematics',
    slug: 'mathematics',
    description: 'Foundations of algebra, geometry, trigonometry, statistics, and coordinate calculations.',
    icon: 'Sigma',
    subcategories: ['Algebra', 'Geometry', 'Trigonometry', 'Coordinate Geometry', 'Financial Math', 'Statistics']
  },
  {
    id: 'physics',
    name: 'Physics',
    slug: 'physics',
    description: 'Universal laws of mechanics, motion, forces, energy, electricity, waves, and thermodynamics.',
    icon: 'Atom',
    subcategories: ['Force', 'Motion', 'Energy & Work', 'Mechanics', 'Electricity', 'Waves', 'Heat', 'Gravity']
  },
  {
    id: 'chemistry',
    name: 'Chemistry',
    slug: 'chemistry',
    description: 'Stoichiometry, ideal gas laws, solution molarity, acid-base pH, and thermochemistry.',
    icon: 'FlaskConical',
    subcategories: ['Gas Laws', 'Solutions', 'Stoichiometry', 'Thermochemistry', 'Atomic']
  },
  {
    id: 'engineering',
    name: 'Engineering',
    subcategory: 'Mechanical, electrical, materials, fluid mechanics, stress, and powertrain analysis.',
    slug: 'engineering',
    icon: 'Cpu',
    subcategories: ['Materials & Stress', 'Mechanical Engineering', 'Fluid Mechanics', 'Thermodynamics']
  } as any,
  {
    id: 'robotics',
    name: 'Robotics',
    slug: 'robotics',
    description: 'Kinematics, mobile robot differential drive, actuator torque sizing, and feedback PID control.',
    icon: 'Bot',
    subcategories: ['Kinematics', 'Motor Sizing & Torque', 'Manipulators', 'Control Systems', 'Actuators']
  },
  {
    id: 'aerospace',
    name: 'Aerospace',
    slug: 'aerospace',
    description: 'Orbital mechanics, Tsiolkovsky rocket equation, propulsion thrust, and aerodynamic lift/drag.',
    icon: 'Rocket',
    subcategories: ['Rocket Propulsion', 'Orbital Mechanics', 'Aerodynamics']
  }
];
