import { CustomRoutine } from '../types';

export const PRESET_ROUTINES: CustomRoutine[] = [
  {
    id: 'foundation-full-body',
    name: "Today's Focus: Full Body Calisthenics Foundation",
    description: 'The golden balance of vertical pull, horizontal push, core compression, and unilateral leg strength.',
    estimatedDurationMin: 42,
    exercises: [
      { exerciseId: 'pull-up', setsCount: 4, defaultReps: 8, restTimeSec: 90 },
      { exerciseId: 'push-up', setsCount: 4, defaultReps: 15, restTimeSec: 60 },
      { exerciseId: 'parallel-bar-dip', setsCount: 3, defaultReps: 10, restTimeSec: 90 },
      { exerciseId: 'australian-pull-up', setsCount: 3, defaultReps: 12, restTimeSec: 60 },
      { exerciseId: 'hanging-knee-raise', setsCount: 3, defaultReps: 12, restTimeSec: 60 },
      { exerciseId: 'bodyweight-squat', setsCount: 3, defaultReps: 20, restTimeSec: 60 },
    ]
  },
  {
    id: 'upper-body-power',
    name: 'Upper Body Power: Pull & Dip',
    description: 'Intense hypertrophy and pulling torque for massive lats, triceps, and upper chest.',
    estimatedDurationMin: 45,
    exercises: [
      { exerciseId: 'pull-up', setsCount: 4, defaultReps: 8, restTimeSec: 90 },
      { exerciseId: 'parallel-bar-dip', setsCount: 4, defaultReps: 10, restTimeSec: 90 },
      { exerciseId: 'chin-up', setsCount: 3, defaultReps: 8, restTimeSec: 75 },
      { exerciseId: 'diamond-push-up', setsCount: 3, defaultReps: 12, restTimeSec: 60 },
      { exerciseId: 'australian-pull-up', setsCount: 3, defaultReps: 12, restTimeSec: 60 },
      { exerciseId: 'pseudo-planche-push-up', setsCount: 3, defaultReps: 8, restTimeSec: 75 }
    ]
  },
  {
    id: 'backpack-hypertrophy',
    name: 'Home Backpack Strength & Hypertrophy',
    description: 'Loaded progressive home workout using a weighted backpack for curls, rows, squats, and presses.',
    estimatedDurationMin: 38,
    exercises: [
      { exerciseId: 'backpack-row', setsCount: 4, defaultReps: 10, targetWeightKg: 12, restTimeSec: 60 },
      { exerciseId: 'backpack-squat', setsCount: 4, defaultReps: 12, targetWeightKg: 15, restTimeSec: 75 },
      { exerciseId: 'backpack-shoulder-press', setsCount: 3, defaultReps: 10, targetWeightKg: 8, restTimeSec: 60 },
      { exerciseId: 'backpack-weighted-pushup', setsCount: 3, defaultReps: 8, targetWeightKg: 10, restTimeSec: 75 },
      { exerciseId: 'backpack-curl', setsCount: 3, defaultReps: 12, targetWeightKg: 8, restTimeSec: 60 },
      { exerciseId: 'backpack-romanian-deadlift', setsCount: 3, defaultReps: 12, targetWeightKg: 14, restTimeSec: 60 }
    ]
  },
  {
    id: 'core-and-skills',
    name: 'Isometric Core & Lever Master',
    description: 'Gymnastic straight-arm conditioning, hollow compression, and lever endurance holds.',
    estimatedDurationMin: 35,
    exercises: [
      { exerciseId: 'hollow-body-hold', setsCount: 4, defaultHoldSec: 35, restTimeSec: 60 },
      { exerciseId: 'l-sit-hold', setsCount: 4, defaultHoldSec: 15, restTimeSec: 75 },
      { exerciseId: 'plank', setsCount: 3, defaultHoldSec: 60, restTimeSec: 60 },
      { exerciseId: 'hanging-leg-raise', setsCount: 3, defaultReps: 8, restTimeSec: 60 },
      { exerciseId: 'arch-hold', setsCount: 3, defaultHoldSec: 30, restTimeSec: 45 },
      { exerciseId: 'dragon-flag', setsCount: 3, defaultReps: 5, restTimeSec: 90 }
    ]
  },
  {
    id: 'push-and-handstand',
    name: 'Handstand & Push Progression',
    description: 'Vertical pressing overhead power and horizontal chest mastery for calisthenics push skills.',
    estimatedDurationMin: 40,
    exercises: [
      { exerciseId: 'pike-push-up', setsCount: 4, defaultReps: 8, restTimeSec: 75 },
      { exerciseId: 'wall-handstand-push-up', setsCount: 3, defaultReps: 5, restTimeSec: 90 },
      { exerciseId: 'pseudo-planche-push-up', setsCount: 3, defaultReps: 8, restTimeSec: 75 },
      { exerciseId: 'decline-push-up', setsCount: 3, defaultReps: 12, restTimeSec: 60 },
      { exerciseId: 'tuck-hold', setsCount: 3, defaultHoldSec: 20, restTimeSec: 60 },
      { exerciseId: 'explosive-push-up', setsCount: 3, defaultReps: 8, restTimeSec: 75 }
    ]
  },
  {
    id: 'legs-explosive',
    name: 'Pistol Squat & Plyo Leg Blast',
    description: 'High-power lower body training targeting single-leg pistols, jump squats, and lunges.',
    estimatedDurationMin: 32,
    exercises: [
      { exerciseId: 'assisted-pistol-squat', setsCount: 4, defaultReps: 6, restTimeSec: 75 },
      { exerciseId: 'bulgarian-split-squat', setsCount: 3, defaultReps: 10, restTimeSec: 60 },
      { exerciseId: 'jump-squat', setsCount: 3, defaultReps: 10, restTimeSec: 60 },
      { exerciseId: 'walking-lunge', setsCount: 3, defaultReps: 16, restTimeSec: 60 },
      { exerciseId: 'calf-raise', setsCount: 4, defaultReps: 25, restTimeSec: 45 }
    ]
  },
  {
    id: 'resistance-band-hypertrophy',
    name: 'Resistance Band Lat Pulldown, Rows & Joint Armor',
    description: 'Complete elastic upper-body pull & push routine featuring Lat Pulldowns, Bent-Over Rows, Upright Rows, Shrugs, and Resisted Push-Ups.',
    estimatedDurationMin: 40,
    exercises: [
      { exerciseId: 'band-lat-pulldown', setsCount: 4, defaultReps: 12, restTimeSec: 60 },
      { exerciseId: 'band-bent-over-row', setsCount: 4, defaultReps: 12, restTimeSec: 60 },
      { exerciseId: 'band-upright-row', setsCount: 3, defaultReps: 12, restTimeSec: 45 },
      { exerciseId: 'band-shrugs', setsCount: 3, defaultReps: 15, restTimeSec: 45 },
      { exerciseId: 'band-resisted-pushup', setsCount: 4, defaultReps: 10, restTimeSec: 60 },
      { exerciseId: 'band-lateral-raise', setsCount: 3, defaultReps: 15, restTimeSec: 45 },
      { exerciseId: 'band-tricep-pushdown', setsCount: 3, defaultReps: 15, restTimeSec: 45 },
      { exerciseId: 'band-standing-bicep-curl', setsCount: 3, defaultReps: 12, restTimeSec: 45 }
    ]
  },
  {
    id: 'resistance-band-delts-arms',
    name: 'Resistance Band Delts, Traps & Arm Blaster',
    description: 'High-volume shoulder caps, upper traps, triceps horseshoe, and bicep peaks using ascending resistance band tension.',
    estimatedDurationMin: 35,
    exercises: [
      { exerciseId: 'band-overhead-shoulder-press', setsCount: 4, defaultReps: 10, restTimeSec: 60 },
      { exerciseId: 'band-lateral-raise', setsCount: 4, defaultReps: 15, restTimeSec: 45 },
      { exerciseId: 'band-upright-row', setsCount: 3, defaultReps: 12, restTimeSec: 45 },
      { exerciseId: 'band-shrugs', setsCount: 3, defaultReps: 15, restTimeSec: 45 },
      { exerciseId: 'band-face-pull', setsCount: 3, defaultReps: 15, restTimeSec: 45 },
      { exerciseId: 'band-tricep-pushdown', setsCount: 4, defaultReps: 15, restTimeSec: 45 },
      { exerciseId: 'band-overhead-tricep-extension', setsCount: 3, defaultReps: 12, restTimeSec: 45 },
      { exerciseId: 'band-hammer-curl', setsCount: 3, defaultReps: 12, restTimeSec: 45 }
    ]
  },
  {
    id: 'towel-home-strength',
    name: 'Towel & Slider Zero-Equipment Home Routine',
    description: 'Full-body minimalist home training using a towel for back rows, brutal hammer curls, sliding chest flyes, and hamstring curls.',
    estimatedDurationMin: 34,
    exercises: [
      { exerciseId: 'towel-door-row', setsCount: 4, defaultReps: 12, restTimeSec: 60 },
      { exerciseId: 'towel-hammer-curl', setsCount: 3, defaultReps: 12, restTimeSec: 45 },
      { exerciseId: 'towel-floor-hamstring-curl', setsCount: 3, defaultReps: 10, restTimeSec: 60 },
      { exerciseId: 'towel-sliding-chest-flye', setsCount: 3, defaultReps: 8, restTimeSec: 60 },
      { exerciseId: 'towel-sliding-ab-pike', setsCount: 3, defaultReps: 10, restTimeSec: 45 },
      { exerciseId: 'towel-sliding-reverse-lunge', setsCount: 3, defaultReps: 12, restTimeSec: 45 }
    ]
  },
  {
    id: 'advanced-bag-halo-supersets',
    name: 'Advanced Bag Halo, Supersets & Drop-Set Armor',
    description: 'High-intensity gym-replacement workout featuring Weighted Bag Halos (Plate Halo replacement), Meadows Rows, Zercher Good Mornings, and Push-Pull Supersets & Drop Sets.',
    estimatedDurationMin: 44,
    exercises: [
      {
        exerciseId: 'backpack-bag-halo',
        setsCount: 4,
        defaultReps: 12,
        targetWeightKg: 10,
        restTimeSec: 30,
        defaultSetType: 'superset',
        supersetWithNext: true
      },
      {
        exerciseId: 'backpack-around-the-world',
        setsCount: 4,
        defaultReps: 10,
        targetWeightKg: 10,
        restTimeSec: 75,
        defaultSetType: 'superset'
      },
      {
        exerciseId: 'backpack-meadows-row',
        setsCount: 4,
        defaultReps: 10,
        targetWeightKg: 16,
        restTimeSec: 60,
        defaultSetType: 'dropset'
      },
      {
        exerciseId: 'backpack-zercher-good-morning',
        setsCount: 3,
        defaultReps: 8,
        targetWeightKg: 18,
        restTimeSec: 75,
        defaultSetType: 'tempo'
      },
      {
        exerciseId: 'backpack-pullover-hollow-press',
        setsCount: 3,
        defaultReps: 10,
        targetWeightKg: 12,
        restTimeSec: 45,
        defaultSetType: 'superset',
        supersetWithNext: true
      },
      {
        exerciseId: 'backpack-kneeling-jm-press',
        setsCount: 3,
        defaultReps: 10,
        targetWeightKg: 12,
        restTimeSec: 60,
        defaultSetType: 'dropset'
      },
      {
        exerciseId: 'backpack-overhead-walking-lunge',
        setsCount: 3,
        defaultReps: 12,
        targetWeightKg: 12,
        restTimeSec: 60,
        defaultSetType: 'amrap'
      }
    ]
  }
];
