import { AnalyzedSentence } from '../types';

export const sampleAnalyzedSentences: AnalyzedSentence[] = [
  {
    id: 'sent_1',
    arabicText: 'إِنَّ اللّٰهَ غَفُورٌ رَحِيمٌ',
    source: 'القرآن الكريم',
    translation: {
      pashto: 'بېشکه الله خورا بخښونکی، بې کچه مهربان دی.',
      urdu: 'بے شک اللہ بڑا بخشنے والا نہایت رحم کرنے والا ہے۔',
      english: 'Indeed Allah is Ever-Forgiving, Especially Merciful.'
    },
    sentenceType: {
      pashto: 'جمله اسمیه (د حروف مشبهه بالفعل سره)',
      urdu: 'جملہ اسمیہ (حرفِ مشبہ بالفعل کے ساتھ)',
      english: 'Nominal Sentence with particle of inception and corroboration (Inna)'
    },
    tokens: [
      {
        word: 'إِنَّ',
        roleArabic: 'حَرْفُ تَوْكِيدٍ وَنَصْبٍ (مِنَ الأَحْرُفِ الْمُشَبَّهَةِ بِالْفِعْلِ)',
        caseState: 'mabni',
        caseSign: {
          pashto: 'مبني پر فتح باندې',
          urdu: 'مبنی بر فتح',
          english: 'Indeclinable on Fathah'
        },
        explanation: {
          pashto: 'د إنّ له حروفو څخه دی، خپل اسم منصوب او خپل خبر مرفوع کوي.',
          urdu: 'حروفِ مشبہ بالفعل میں سے ہے، اپنے اسم کو نصب اور خبر کو رفع دیتا ہے۔',
          english: 'Corroborative particle governing its noun in accusative and predicate in nominative.'
        }
      },
      {
        word: 'اللّٰهَ',
        roleArabic: 'اسْمُ إِنَّ',
        caseState: 'mansoob',
        caseSign: {
          pashto: 'ښکاره فتحه (زبر)',
          urdu: 'فتحه ظاہرہ برائے نصب',
          english: 'Explicit Fathah denoting accusative case'
        },
        explanation: {
          pashto: 'د إنّ اسم دی او د إنّ له امله منصوب دی.',
          urdu: 'لفظِ جلالت اسمِ إنّ ہونے کی وجہ سے منصوب ہے۔',
          english: 'Governed noun of Inna, in the accusative case.'
        }
      },
      {
        word: 'غَفُورٌ',
        roleArabic: 'خَبَرُ إِنَّ (الأَوَّلُ)',
        caseState: 'marfoo',
        caseSign: {
          pashto: 'ښکاره ضمه (پیش او تنوین)',
          urdu: 'ضمہ ظاہرہ برائے رفع',
          english: 'Explicit Dammah denoting nominative case'
        },
        explanation: {
          pashto: 'د إنّ لومړی خبر دی او مرفوع دی.',
          urdu: 'إنّ کی پہلی خبر ہونے کے سبب مرفوع ہے۔',
          english: 'First predicate of Inna in the nominative case.'
        }
      },
      {
        word: 'رَحِيمٌ',
        roleArabic: 'خَبَرُ إِنَّ (الثَّانِي)',
        caseState: 'marfoo',
        caseSign: {
          pashto: 'ښکاره ضمه (پیش)',
          urdu: 'ضمہ ظاہرہ برائے رفع',
          english: 'Explicit Dammah denoting nominative case'
        },
        explanation: {
          pashto: 'د إنّ دویم خبر دی او مرفوع دی.',
          urdu: 'إنّ کی دوسری خبر ہونے کے سبب مرفوع ہے۔',
          english: 'Second predicate of Inna in the nominative case.'
        }
      }
    ],
    tarkibSummary: {
      pashto: 'ترکیب: إِنَّ حرف مشبه بالفعل + اللّٰهَ اسم إن منصوب + غَفُورٌ خبر اول مرفوع + رَحِيمٌ خبر ثاني مرفوع = جمله اسمیه خبریه.',
      urdu: 'ترکیبِ نحوی: إِنَّ حرفِ مشبہ بالفعل + اللّٰهَ اس کا اسم منصوب + غَفُورٌ خبرِ اول مرفوع + رَحِيمٌ خبرِ ثانی مرفوع۔ مل کر جملہ اسمیہ خبریہ ہوا۔',
      english: 'Syntactic parsing: Inna (particle) + Allaha (accusative noun) + Ghafoorun (first nominative predicate) + Raheemun (second nominative predicate) = Complete nominal sentence.'
    }
  },
  {
    id: 'sent_2',
    arabicText: 'خَلَقَ اللّٰهُ السَّمَاوَاتِ وَالأَرْضَ بِالْحَقِّ',
    source: 'القرآن الكريم',
    translation: {
      pashto: 'الله تعالی اسمانونه او ځمکه په حق سره پیدا کړي دي.',
      urdu: 'اللہ نے آسمانوں اور زمین کو حق کے ساتھ پیدا فرمایا۔',
      english: 'Allah created the heavens and the earth in truth.'
    },
    sentenceType: {
      pashto: 'جمله فعلیه (متعدي فعل سره)',
      urdu: 'جملہ فعلیہ (فعلِ متعدی کے ساتھ)',
      english: 'Verbal sentence with transitive verb and compound direct object'
    },
    tokens: [
      {
        word: 'خَلَقَ',
        roleArabic: 'فِعْلٌ مَاضٍ مَبْنِيٌّ عَلَى الْفَتْحِ',
        caseState: 'mabni',
        caseSign: {
          pashto: 'مبني پر فتح (زبر)',
          urdu: 'مبنی بر فتح',
          english: 'Indeclinable past verb with Fathah'
        },
        explanation: {
          pashto: 'فعل ماضي معروف دی، د نَصَرَ له باب څخه.',
          urdu: 'فعلِ ماضی معروف ہے بابِ نصر ینصر سے۔',
          english: 'Form I active past verb from root Kh-L-Q.'
        }
      },
      {
        word: 'اللّٰهُ',
        roleArabic: 'فَاعِلٌ مَرْفُوعٌ',
        caseState: 'marfoo',
        caseSign: {
          pashto: 'ښکاره ضمه (پیش)',
          urdu: 'ضمہ ظاہرہ',
          english: 'Explicit Dammah (nominative)'
        },
        explanation: {
          pashto: 'د خَلَقَ د فعل فاعل دی او فاعل تل مرفوع وي.',
          urdu: 'فعلِ خلق کا فاعل ہونے کی وجہ سے مرفوع ہے۔',
          english: 'The grammatical agent (Faa\'il) of the verb, in the nominative case.'
        }
      },
      {
        word: 'السَّمَاوَاتِ',
        roleArabic: 'مَفْعُولٌ بِهِ مَنْصُوبٌ',
        caseState: 'mansoob',
        caseSign: {
          pashto: 'کسره د فتحې پر ځای (ځکه جمع مؤنث سالم دی)',
          urdu: 'کسرہ نیابتاً عن الفتحہ (جمع مؤنث سالم ہونے کی وجہ سے)',
          english: 'Kasrah substituting for Fathah (sound feminine plural)'
        },
        explanation: {
          pashto: 'مفعول به دی، او د جمع مؤنث سالم حالت د نصب په کسره سره وي.',
          urdu: 'مفعول بہ ہے، جمع مؤنث سالم کا اعراب حالتِ نصب میں کسرہ سے ہوتا ہے۔',
          english: 'Direct object; sound feminine plural takes Kasrah in the accusative.'
        }
      },
      {
        word: 'وَالأَرْضَ',
        roleArabic: 'حَرْفُ عَطْفٍ + اسْمٌ مَعْطُوفٌ مَنْصُوبٌ',
        caseState: 'mansoob',
        caseSign: {
          pashto: 'ښکاره فتحه (زبر)',
          urdu: 'فتحه ظاہرہ',
          english: 'Explicit Fathah (accusative)'
        },
        explanation: {
          pashto: 'واو د عطف دی او الأرض معطوف دی پر السماوات باندې، نو ځکه منصوب دی.',
          urdu: 'واؤ حرفِ عطف ہے، اور الأرض کا عطف السماوات پر ہونے سے یہ بھی منصوب ہے۔',
          english: 'Conjoined noun mirroring the accusative state of al-Samawaat.'
        }
      },
      {
        word: 'بِالْحَقِّ',
        roleArabic: 'جَارٌّ وَمَجْرُورٌ (مُتَعَلِّقٌ بِالْفِعْلِ)',
        caseState: 'majroor',
        caseSign: {
          pashto: 'ښکاره کسره (زیر)',
          urdu: 'کسرہ ظاہرہ',
          english: 'Explicit Kasrah (genitive)'
        },
        explanation: {
          pashto: 'بـ توری حرف جر دی او الحق مجرور دی، دواړه له خَلَقَ فعل سره متعلق دي.',
          urdu: 'باء حرفِ جر اور الحق مجرور، دونوں مل کر خلق فعل کے متعلق ہیں۔',
          english: 'Preposition and genitive noun functioning as circumstantial adjunct.'
        }
      }
    ],
    tarkibSummary: {
      pashto: 'ترکیب: خَلَقَ فعل + اللّٰهُ فاعل مرفوع + السَّمَاوَاتِ معطوف علیه منصوب + وَالأَرْضَ معطوف منصوب + بِالْحَقِّ جار او مجرور متعلق = جمله فعلیه خبریه.',
      urdu: 'ترکیب: خَلَقَ فعل + اللّٰهُ فاعل مرفوع + السَّمَاوَاتِ مفعول بہ معطوف علیہ + وَالأَرْضَ معطوف منصوب + بِالْحَقِّ متعلقِ فعل۔ مل کر جملہ فعلیہ خبریہ ہوا۔',
      english: 'Syntactic parsing: Khalaqa (verb) + Allaho (nominative agent) + al-Samawati (accusative object) + wal-Arda (conjoined accusative) + bil-Haqqi (prepositional phrase) = Complete verbal sentence.'
    }
  },
  {
    id: 'sent_3',
    arabicText: 'كَانَ النَّاسُ أُمَّةً وَاحِدَةً',
    source: 'القرآن الكريم',
    translation: {
      pashto: 'ټول خلک یو واحد امت (ډله) وو.',
      urdu: 'تمام لوگ ایک ہی امت (طریقے پر) تھے۔',
      english: 'Mankind was once but one single community.'
    },
    sentenceType: {
      pashto: 'جمله اسمیه (له فعل ناقص كان سره)',
      urdu: 'جملہ اسمیہ (فعلِ ناقص کانَ کے ساتھ)',
      english: 'Sentence initiated with defective copular verb Kaana'
    },
    tokens: [
      {
        word: 'كَانَ',
        roleArabic: 'فِعْلٌ مَاضٍ نَاقِصٌ',
        caseState: 'mabni',
        caseSign: {
          pashto: 'مبني پر فتحه',
          urdu: 'مبنی بر فتح',
          english: 'Indeclinable defective past verb'
        },
        explanation: {
          pashto: 'فعل ناقص دی، خپل اسم مرفوع او خپل خبر منصوب کوي.',
          urdu: 'افعالِ ناقصہ میں سے ہے، اپنے اسم کو رفع اور خبر کو نصب دیتا ہے۔',
          english: 'Defective auxiliary verb asserting past continuous state.'
        }
      },
      {
        word: 'النَّاسُ',
        roleArabic: 'اسْمُ كَانَ مَرْفُوعٌ',
        caseState: 'marfoo',
        caseSign: {
          pashto: 'ښکاره ضمه',
          urdu: 'ضمہ ظاہرہ',
          english: 'Explicit Dammah (nominative)'
        },
        explanation: {
          pashto: 'د كانَ اسم دی او مرفوع دی.',
          urdu: 'اسمِ کان ہونے کی وجہ سے مرفوع ہے۔',
          english: 'Subject of Kaana in the nominative case.'
        }
      },
      {
        word: 'أُمَّةً',
        roleArabic: 'خَبَرُ كَانَ مَنْصُوبٌ (مَوْصُوفٌ)',
        caseState: 'mansoob',
        caseSign: {
          pashto: 'ښکاره فتحه (تنوین نصب)',
          urdu: 'فتحه ظاہرہ برائے نصب',
          english: 'Explicit Tanween of Fathah (accusative)'
        },
        explanation: {
          pashto: 'د كانَ خبر دی، نو ځکه منصوب دی.',
          urdu: 'خبرِ کان ہونے کے باعث منصوب ہے۔',
          english: 'Predicate of Kaana in the accusative case, also serving as qualified noun (Mawsoof).'
        }
      },
      {
        word: 'وَاحِدَةً',
        roleArabic: 'نَعْتٌ / صِفَةٌ لِـ (أُمَّةً)',
        caseState: 'mansoob',
        caseSign: {
          pashto: 'ښکاره فتحه',
          urdu: 'فتحه ظاہرہ',
          english: 'Explicit Fathah (accusative)'
        },
        explanation: {
          pashto: 'د أُمَّةً لپاره صفت دی او صفت د موصوف د اعراب پیروي کوي.',
          urdu: 'أُمَّةً کی صفت ہے اور موصوف کے منصوب ہونے کی وجہ سے یہ بھی منصوب ہے۔',
          english: 'Attributive adjective agreeing with the accusative noun Ummatan.'
        }
      }
    ],
    tarkibSummary: {
      pashto: 'ترکیب: كَانَ فعل ناقص + النَّاسُ اسم كان مرفوع + أُمَّةً موصوف + وَاحِدَةً صفت (او دواړه خبر كان منصوب) = جمله اسمیه ناقصه.',
      urdu: 'ترکیب: كَانَ فعلِ ناقص + النَّاسُ اسمِ کان مرفوع + أُمَّةً موصوف + وَاحِدَةً صفت، دونوں مل کر خبرِ کان منصوب۔ جملہ مکمل ہوا۔',
      english: 'Parsing: Kaana (copula) + an-Naasu (nominative noun) + Ummatan Wahidatan (accusative noun-adjective predicate).'
    }
  }
];
