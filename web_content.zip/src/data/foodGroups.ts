import { FoodGroupInfo } from '../types/game';

export const FOOD_GROUPS: Record<string, FoodGroupInfo> = {
  vegetables: {
    id: 'vegetables',
    name: 'Vegetables & Legumes/Beans',
    shortName: 'Vegetables',
    color: '#10b981', // emerald
    accentColor: '#059669',
    gradient: 'from-emerald-500 to-teal-700',
    bgLight: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    icon: 'Salad',
    emoji: '🥦',
    tagline: 'The Micronutrient & Gut Defense Shield',
    teenFocus: 'Clear skin, steady digestion, and immune defense against school bugs',
    teenWhy:
      'Teen bodies are growing fast and undergoing hormonal changes. Dark green, orange, and cruciferous veggies provide zinc, vitamin A, beta-carotene, and prebiotic fiber that stabilize energy and promote clear, radiant skin.',
    recommendedServings: {
      girls: '5 servings / day',
      boys: '5.5 servings / day',
      servingExamples: [
        '1 cup raw leafy greens (spinach, kale)',
        '1/2 cup cooked broccoli or carrots',
        '1/2 cup cooked chickpeas or lentils',
        '1 medium sweet potato',
      ],
    },
    keyNutrients: ['Fiber', 'Vitamin A', 'Vitamin C', 'Potassium', 'Folate', 'Magnesium'],
    topFoods: [
      { name: 'Broccoli', emoji: '🥦', highlight: 'Packed with Vitamin C and sulforaphane' },
      { name: 'Carrots', emoji: '🥕', highlight: 'Rich in beta-carotene for sharp vision and skin' },
      { name: 'Spinach', emoji: '🥬', highlight: 'High in plant iron and folate for cellular growth' },
      { name: 'Sweet Potato', emoji: '🍠', highlight: 'Complex beta-carotene powerhouse' },
      { name: 'Chickpeas & Lentils', emoji: '🫘', highlight: 'Dual bonus: plant protein + prebiotic fiber' },
      { name: 'Bell Peppers', emoji: '🫑', highlight: 'Contains 2.5x more Vitamin C than oranges' },
    ],
    teenProTip:
      'Pair leafy greens (like spinach) with Vitamin C foods (like bell pepper or lemon juice) to increase iron absorption by up to 300%!',
  },

  fruits: {
    id: 'fruits',
    name: 'Fruits',
    shortName: 'Fruits',
    color: '#f43f5e', // rose / red
    accentColor: '#e11d48',
    gradient: 'from-rose-500 to-red-600',
    bgLight: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    icon: 'Apple',
    emoji: '🍎',
    tagline: 'Natural Energy & Antioxidant Boosters',
    teenFocus: 'Quick natural fuel before sports and antioxidant brain protection',
    teenWhy:
      'Whole fruits give teens quick natural energy bound up in soluble fiber, preventing the harsh sugar spikes and crashes caused by soda and candy. They keep you hydrated and boost concentration during tests.',
    recommendedServings: {
      girls: '2 servings / day',
      boys: '2 servings / day',
      servingExamples: [
        '1 medium apple, banana, or orange',
        '1 cup fresh berries (strawberries, blueberries)',
        '2 small kiwi fruits or plums',
        '1 cup diced watermelon or melon',
      ],
    },
    keyNutrients: ['Vitamin C', 'Dietary Fiber', 'Antioxidants', 'Potassium', 'Natural Water'],
    topFoods: [
      { name: 'Apples', emoji: '🍎', highlight: 'Pectin fiber that keeps you full until lunch' },
      { name: 'Bananas', emoji: '🍌', highlight: 'Potassium prevents muscle cramps during sports' },
      { name: 'Blueberries', emoji: '🫐', highlight: 'Anthocyanins boost memory and brain recall' },
      { name: 'Strawberries', emoji: '🍓', highlight: 'High Vitamin C for collagen formation' },
      { name: 'Oranges', emoji: '🍊', highlight: 'Hydrating citrus with hesperidin bioflavonoids' },
      { name: 'Watermelon', emoji: '🍉', highlight: '92% water with lycopene for sun defense' },
    ],
    teenProTip:
      'Always prefer whole fruits over fruit juices! Whole fruit contains cellular fiber that regulates digestion and keeps energy stable, whereas juice acts like liquid sugar.',
  },

  grains: {
    id: 'grains',
    name: 'Grains & Cereals (Mostly Whole Grains)',
    shortName: 'Whole Grains',
    color: '#f59e0b', // amber / gold
    accentColor: '#d97706',
    gradient: 'from-amber-500 to-yellow-600',
    bgLight: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    icon: 'Wheat',
    emoji: '🌾',
    tagline: 'Sustained Brain & Athletic Fuel',
    teenFocus: 'Long-lasting focus for 6-hour school days and marathon sports stamina',
    teenWhy:
      'Your brain runs almost entirely on glucose. Whole grains release complex carbohydrates slowly into the bloodstream over 3 to 4 hours, unlike refined white bread or sugary pastries that leave you sleepy by 2nd period.',
    recommendedServings: {
      girls: '6 servings / day',
      boys: '7 servings / day',
      servingExamples: [
        '1 slice whole grain bread',
        '1/2 cup cooked brown rice or quinoa',
        '1/2 cup cooked rolled oats',
        '2/3 cup whole grain cereal flakes',
      ],
    },
    keyNutrients: ['Complex Carbohydrates', 'B-Vitamins (Thiamine, Niacin)', 'Iron', 'Zinc', 'Fiber'],
    topFoods: [
      { name: 'Rolled Oats', emoji: '🥣', highlight: 'Beta-glucan fiber keeps morning hunger away' },
      { name: 'Brown Rice', emoji: '🍚', highlight: 'Mineral-dense sustained energy for training' },
      { name: 'Whole Wheat Bread', emoji: '🍞', highlight: 'Retains the bran & germ with all B-vitamins' },
      { name: 'Quinoa', emoji: '🌾', highlight: 'Ancient pseudo-grain featuring all 9 essential amino acids' },
      { name: 'Air-popped Popcorn', emoji: '🍿', highlight: 'Surprise! Popcorn is a 100% whole grain snack' },
      { name: 'Whole Grain Pasta', emoji: '🍝', highlight: 'Slow glycemic endurance fuel for sports' },
    ],
    teenProTip:
      'Look for "100% Whole Grain" or "Whole Wheat" as the very first word in the ingredients label. "Multigrain" or "Wheat Flour" often means refined white flour with caramel coloring!',
  },

  protein: {
    id: 'protein',
    name: 'Lean Meats, Poultry, Fish, Eggs, Tofu, Nuts & Seeds',
    shortName: 'Lean Proteins',
    color: '#8b5cf6', // purple / violet
    accentColor: '#7c3aed',
    gradient: 'from-purple-500 to-indigo-600',
    bgLight: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    icon: 'Drumstick',
    emoji: '🍗',
    tagline: 'Growth Spurt Builders & Muscle Repair',
    teenFocus: 'Building lean muscle, repairing tissues post-workout, and making hormones',
    teenWhy:
      'Teens go through their second largest growth surge since infancy. Protein supplies amino acid building blocks for skeletal muscle, antibodies, hair, and neurotransmitters like dopamine.',
    recommendedServings: {
      girls: '2.5 servings / day',
      boys: '3 servings / day',
      servingExamples: [
        '65g cooked lean meat (beef, lamb, pork)',
        '80g cooked poultry (chicken breast, turkey)',
        '100g cooked fish fillet or small can of tuna',
        '2 large eggs',
        '1 cup cooked legumes/beans or 170g firm tofu',
        '30g nuts or seeds',
      ],
    },
    keyNutrients: ['High Quality Protein', 'Heme & Non-Heme Iron', 'Zinc', 'Vitamin B12', 'Omega-3s'],
    topFoods: [
      { name: 'Eggs', emoji: '🍳', highlight: 'Perfect biological value protein + choline for memory' },
      { name: 'Chicken Breast', emoji: '🍗', highlight: 'Lean, ultra-dense protein without excess saturated fat' },
      { name: 'Salmon & Tuna', emoji: '🐟', highlight: 'Omega-3 fatty acids for mood and brain synapses' },
      { name: 'Tofu & Edamame', emoji: '🌱', highlight: 'Complete plant protein loaded with calcium & iron' },
      { name: 'Almonds & Walnuts', emoji: '🥜', highlight: 'Healthy fats, magnesium, and vitamin E' },
      { name: 'Pumpkin & Chia Seeds', emoji: '🌰', highlight: 'Packed with zinc for acne recovery and growth' },
    ],
    teenProTip:
      'Spread your protein evenly across breakfast, lunch, and dinner rather than overloading at dinner! Muscles synthesize protein best in 20-30g intervals.',
  },

  dairy: {
    id: 'dairy',
    name: 'Milk, Yogurt, Cheese & Fortified Alternatives',
    shortName: 'Dairy & Alternatives',
    color: '#0284c7', // cyan / blue
    accentColor: '#0369a1',
    gradient: 'from-sky-400 to-blue-600',
    bgLight: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
    icon: 'Milk',
    emoji: '🥛',
    tagline: 'Peak Bone Density & Calcium Armor',
    teenFocus: 'Building irreversible bone density for the rest of your life',
    teenWhy:
      'CRUCIAL TEEN FACT: You build almost 90% of your lifetime bone mass before age 20! If you don’t bank calcium now during your teen growth window, bones remain brittle permanently in adulthood. Fortified plant milks (with 120mg+ calcium/100ml) count too!',
    recommendedServings: {
      girls: '3.5 servings / day',
      boys: '3.5 servings / day',
      servingExamples: [
        '1 cup (250ml) milk or calcium-fortified plant milk',
        '2 slices (40g) hard cheese (cheddar, swiss)',
        '3/4 cup (200g) plain Greek yogurt',
        '1/2 cup ricotta cheese',
      ],
    },
    keyNutrients: ['Calcium', 'Vitamin D', 'Phosphorus', 'Potassium', 'Vitamin B12', 'Protein'],
    topFoods: [
      { name: 'Milk / Fortified Soy Milk', emoji: '🥛', highlight: '300mg bioavailable calcium per cold glass' },
      { name: 'Greek Yogurt', emoji: '🥣', highlight: '15-20g protein + probiotics for teen digestion' },
      { name: 'Cheddar & Mozzarella', emoji: '🧀', highlight: 'Concentrated calcium and zinc for teeth' },
      { name: 'Kefir', emoji: '🍶', highlight: 'Cultured superfood with 12+ probiotic strains' },
      { name: 'Fortified Almond/Oat Milk', emoji: '🧃', highlight: 'Check the label: look for added calcium & Vit D' },
      { name: 'Cottage Cheese', emoji: '🍨', highlight: 'Casein slow-release protein ideal before sleep' },
    ],
    teenProTip:
      'Lactose sensitive or plant-based? Fortified soy milk is the nutritional equivalent of cow milk in protein and calcium. Always shake the carton, as calcium tends to settle at the bottom!',
  },
};

export const FOOD_GROUP_LIST = Object.values(FOOD_GROUPS);
