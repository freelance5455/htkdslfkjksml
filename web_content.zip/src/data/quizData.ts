import { QuizQuestion } from '../types';

export const quizQuestions: QuizQuestion[] = [
  {
    id: 'q1',
    category: 'sarf',
    arabicPhrase: 'نَصَرَ - يَنْصُرُ',
    question: {
      pashto: 'د "نَصَرَ - يَنْصُرُ" د باب ځانګړتیا په ماضی او مضارع کې څه ده؟',
      urdu: 'بابِ "نَصَرَ - يَنْصُرُ" کی ماضی اور مضارع میں کیا حرکات ہوتی ہیں؟',
      english: 'What are the characteristic vowels of Bab "Nasara - Yansuru" in past and present tenses?'
    },
    options: [
      {
        id: 'opt1',
        text: {
          pashto: 'په ماضی کې فتحه او په مضارع کې ضمه (فَعَلَ - يَفْعُلُ)',
          urdu: 'ماضی میں فتحہ اور مضارع میں ضمہ (فَعَلَ - يَفْعُلُ)',
          english: 'Fathah in past and Dammah in present (Fa\'ala - Yaf\'ulu)'
        }
      },
      {
        id: 'opt2',
        text: {
          pashto: 'په ماضی کې فتحه او په مضارع کې کسره (فَعَلَ - يَفْعِلُ)',
          urdu: 'ماضی میں فتحہ اور مضارع میں کسرہ (فَعَلَ - يَفْعِلُ)',
          english: 'Fathah in past and Kasrah in present (Fa\'ala - Yaf\'ilu)'
        }
      },
      {
        id: 'opt3',
        text: {
          pashto: 'په ماضی کې کسره او په مضارع کې فتحه (فَعِلَ - يَفْعَلُ)',
          urdu: 'ماضی میں کسرہ اور مضارع میں فتحہ (فَعِلَ - يَفْعَلُ)',
          english: 'Kasrah in past and Fathah in present (Fa\'ila - Yaf\'alu)'
        }
      },
      {
        id: 'opt4',
        text: {
          pashto: 'په دواړو کې ضمه (فَعُلَ - يَفْعُلُ)',
          urdu: 'دونوں میں ضمہ (فَعُلَ - يَفْعُلُ)',
          english: 'Dammah in both (Fa\'ula - Yaf\'ulu)'
        }
      }
    ],
    correctOptionId: 'opt1',
    explanation: {
      pashto: 'د نَصَرَ باب د "فَتْحُ ضَمٍّ" په قاعده دی: په ماضی کې نَصَرَ (عین کلمه فتحه لري) او په مضارع کې يَنْصُرُ (عین کلمه ضمه لري).',
      urdu: 'بابِ نصر کی علامت "فتحُ ضمٍّ" ہے، یعنی ماضی مفتوح العین اور مضارع مضموم العین ہوتا ہے۔',
      english: 'Bab Nasara is characterized by Fa\'ala in past and Yaf\'ulu in present.'
    }
  },
  {
    id: 'q2',
    category: 'sarf',
    arabicPhrase: 'صَحِيحٌ اسْتْ وَمِثَالٌ اسْتْ وَمُضَاعَفْ...',
    question: {
      pashto: 'هغه فعل چې فاء کلمه یې د علت توری (واو یا یاء) وي، څه بلل کېږي؟',
      urdu: 'جس فعل کا فاء کلمہ حرفِ علت (واؤ یا یاء) ہو، اسے ہفت اقسام میں کیا کہتے ہیں؟',
      english: 'In the Haft Aqsaam classification, what is a verb whose 1st radical (Fa) is a weak letter called?'
    },
    options: [
      {
        id: 'opt1',
        text: {
          pashto: 'اجوف (چې منځنی توری یې علت وي)',
          urdu: 'اجوف',
          english: 'Ajwaf (Hollow)'
        }
      },
      {
        id: 'opt2',
        text: {
          pashto: 'مثال (لکه: وَعَدَ، يَسَرَ)',
          urdu: 'مثال (جیسے: وَعَدَ، يَسَرَ)',
          english: 'Mithal (Assimilated, e.g. Wa\'ada)'
        }
      },
      {
        id: 'opt3',
        text: {
          pashto: 'ناقص (لکه: دَعَا)',
          urdu: 'ناقص (جیسے: دَعَا)',
          english: 'Naqis (Defective, e.g. Da\'aa)'
        }
      },
      {
        id: 'opt4',
        text: {
          pashto: 'مهموز',
          urdu: 'مہموز',
          english: 'Mahmuz (Hamzated)'
        }
      }
    ],
    correctOptionId: 'opt2',
    explanation: {
      pashto: 'که د فاء په ځای د علت توری وي، ورته "مثال" وایي، لکه وَعَدَ او يَسَرَ.',
      urdu: 'فاء کلمہ میں حرفِ علت ہو تو اسے معتل الفاء یا "مثال" کہا جاتا ہے۔',
      english: 'A verb whose initial root radical is weak is called Mithal (Assimilated).'
    }
  },
  {
    id: 'q3',
    category: 'nahw',
    arabicPhrase: 'إِنَّ اللّٰهَ عَلِيمٌ خَبِيرٌ',
    question: {
      pashto: 'د "إِنَّ" او د هغې د خویندو د اسم او خبر اعراب څه ډول وي؟',
      urdu: 'حروفِ مشبہ بالفعل (إنّ وغیرہ) کا اسم اور خبر کس اعراب میں ہوتے ہیں؟',
      english: 'What are the respective cases of the noun (Ism) and predicate (Khabar) of Inna?'
    },
    options: [
      {
        id: 'opt1',
        text: {
          pashto: 'اسم یې منصوب (زبر) او خبر یې مرفوع (پیش) وي',
          urdu: 'اسم منصوب اور خبر مرفوع ہوتی ہے',
          english: 'Noun is Accusative (Mansoob) and Predicate is Nominative (Marfoo\')'
        }
      },
      {
        id: 'opt2',
        text: {
          pashto: 'اسم یې مرفوع او خبر یې منصوب وي',
          urdu: 'اسم مرفوع اور خبر منصوب ہوتی ہے',
          english: 'Noun is Nominative and Predicate is Accusative'
        }
      },
      {
        id: 'opt3',
        text: {
          pashto: 'دواړه مرفوع وي',
          urdu: 'دونوں مرفوع ہوتے ہیں',
          english: 'Both are Nominative'
        }
      },
      {
        id: 'opt4',
        text: {
          pashto: 'دواړه مجرور وي',
          urdu: 'دونوں مجرور ہوتے ہیں',
          english: 'Both are Genitive'
        }
      }
    ],
    correctOptionId: 'opt1',
    explanation: {
      pashto: 'إنّ خپل اسم ته نصب (زبر) او خپل خبر ته رفع (پیش) ورکوي (لکه: إِنَّ اللّٰهَ عَلِيمٌ).',
      urdu: 'إنّ اور اس کے اخوات اپنے اسم کو نصب اور خبر کو رفع دیتے ہیں۔',
      english: 'Inna renders its Ism accusative (Mansoob) and its Khabar nominative (Marfoo\').'
    }
  },
  {
    id: 'q4',
    category: 'nahw',
    arabicPhrase: 'ضَرَبَ زَيْدٌ عَمْرًا',
    question: {
      pashto: 'په پورتنۍ جمله کې "عَمْرًا" څه شی دی او ولې دوه زبره لري؟',
      urdu: 'اس جملے میں "عَمْرًا" کا نحوی مقام کیا ہے اور اس پر نصب کیوں ہے؟',
      english: 'In the sentence "Daraba Zaydun \'Amran", what is the grammatical role of "\'Amran"?'
    },
    options: [
      {
        id: 'opt1',
        text: {
          pashto: 'فاعل دی',
          urdu: 'فاعل ہے',
          english: 'It is the Agent (Faa\'il)'
        }
      },
      {
        id: 'opt2',
        text: {
          pashto: 'مفعول به دی او منصوب دی',
          urdu: 'مفعول بہ ہے اور منصوب ہے',
          english: 'Direct Object (Maf\'ool Bihi) and therefore Accusative'
        }
      },
      {
        id: 'opt3',
        text: {
          pashto: 'مبتدأ ده',
          urdu: 'مبتدأ ہے',
          english: 'Subject (Mubtada)'
        }
      },
      {
        id: 'opt4',
        text: {
          pashto: 'صفت دی',
          urdu: 'صفت ہے',
          english: 'Adjective (Sifah)'
        }
      }
    ],
    correctOptionId: 'opt2',
    explanation: {
      pashto: 'ځکه چې کار په عمرو شوی دی، نو دا مفعول به دی او مفعول به تل منصوب وي.',
      urdu: 'کیونکہ مارنے کا فعل عمرو پر واقع ہوا ہے، لہٰذا یہ مفعول بہ ہے اور مفعول بہ کا اعراب نصب ہے۔',
      english: '\'Amr is the direct object receiving the action and is in the accusative case.'
    }
  },
  {
    id: 'q5',
    category: 'sarf',
    arabicPhrase: 'عَالِمٌ - مَعْلُومٌ',
    question: {
      pashto: 'په ثلاثي مجرد کې د اسم فاعل او اسم مفعول اوزان کوم دي؟',
      urdu: 'ثلاثی مجرد میں اسمِ فاعل اور اسمِ مفعول کے اوزان کیا ہیں؟',
      english: 'What are the morphological patterns for the Active Participle and Passive Participle in Form I?'
    },
    options: [
      {
        id: 'opt1',
        text: {
          pashto: 'فَاعِلٌ او مَفْعُولٌ',
          urdu: 'فَاعِلٌ اور مَفْعُولٌ',
          english: 'Faa\'ilun and Maf\'oolun'
        }
      },
      {
        id: 'opt2',
        text: {
          pashto: 'مُفْعِلٌ او مُفْعَلٌ',
          urdu: 'مُفْعِلٌ اور مُفْعَلٌ',
          english: 'Muf\'ilun and Muf\'alun'
        }
      },
      {
        id: 'opt3',
        text: {
          pashto: 'فَعِيلٌ او فَعُولٌ',
          urdu: 'فَعِيلٌ اور فَعُولٌ',
          english: 'Fa\'eelun and Fa\'oolun'
        }
      },
      {
        id: 'opt4',
        text: {
          pashto: 'فَعَّالٌ او مِفْعَالٌ',
          urdu: 'فَعَّالٌ اور مِفْعَالٌ',
          english: 'Fa\'\'aalun and Mif\'aalun'
        }
      }
    ],
    correctOptionId: 'opt1',
    explanation: {
      pashto: 'په ثلاثي مجرد کې اسم فاعل تل په وزن د "فَاعِلٌ" (لکه عَالِمٌ) او اسم مفعول په وزن د "مَفْعُولٌ" (لکه مَعْلُومٌ) راځي.',
      urdu: 'ثلاثی مجرد میں اسم فاعل کا اوزان فَاعِلٌ اور اسم مفعول کا وزن مَفْعُولٌ ہوتا ہے۔',
      english: 'Standard Form I active and passive participles follow Faa\'ilun and Maf\'oolun.'
    }
  }
];
