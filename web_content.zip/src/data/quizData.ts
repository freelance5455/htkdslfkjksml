import { QuizCategoryMeta, QuizLevelMeta, QuizQuestion, QuizLanguage } from '../types/quiz';

export const QUIZ_CATEGORIES: QuizCategoryMeta[] = [
  {
    id: 'disease-quiz',
    emoji: '🦠',
    iconBg: 'bg-gradient-to-br from-emerald-500 to-teal-600',
    badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    nameEn: 'Disease Quiz',
    nameHi: 'रोग प्रश्नोत्तरी',
    nameMr: 'रोग प्रश्नमंजुषा',
    descriptionEn: 'Test your understanding of common infectious & chronic medical conditions.',
    descriptionHi: 'सामान्य संक्रामक और पुरानी बीमारियों की समझ का परीक्षण करें।',
    descriptionMr: 'सामान्य संसर्गजन्य आणि जुनाट आजारांच्या ज्ञानाची पडताळणी करा.'
  },
  {
    id: 'medicine-quiz',
    emoji: '💊',
    iconBg: 'bg-gradient-to-br from-blue-500 to-indigo-600',
    badgeBg: 'bg-blue-100 text-blue-800 border-blue-200',
    nameEn: 'Medicine Quiz',
    nameHi: 'दवा प्रश्नोत्तरी',
    nameMr: 'औषध प्रश्नमंजुषा',
    descriptionEn: 'Learn safe drug usage, active salts, dosages, and side-effect awareness.',
    descriptionHi: 'दवाओं का सुरक्षित उपयोग, खुराक और दुष्प्रभावों की जानकारी परखें।',
    descriptionMr: 'औषधांचा सुरक्षित वापर, प्रमाण आणि दुष्परिणामांबद्दलचे ज्ञान तपासा.'
  },
  {
    id: 'nutrition-quiz',
    emoji: '🥗',
    iconBg: 'bg-gradient-to-br from-green-500 to-emerald-700',
    badgeBg: 'bg-green-100 text-green-800 border-green-200',
    nameEn: 'Nutrition Quiz',
    nameHi: 'पोषण प्रश्नोत्तरी',
    nameMr: 'पोषण प्रश्नमंजुषा',
    descriptionEn: 'Discover balanced diets, essential vitamins, and disease meal planning.',
    descriptionHi: 'संतुलित आहार, आवश्यक विटामिन और रोगों में आहार संबंधी जानकारी।',
    descriptionMr: 'संतुलित आहार, जीवनसत्त्वे आणि विविध आजारांमधील आहाराविषयी माहिती.'
  },
  {
    id: 'first-aid-quiz',
    emoji: '🚑',
    iconBg: 'bg-gradient-to-br from-red-500 to-rose-700',
    badgeBg: 'bg-red-100 text-red-800 border-red-200',
    nameEn: 'First Aid Quiz',
    nameHi: 'प्राथमिक चिकित्सा प्रश्नोत्तरी',
    nameMr: 'प्रथमोपचार प्रश्नमंजुषा',
    descriptionEn: 'Life-saving emergency steps, CPR basics, burn care, and choking responses.',
    descriptionHi: 'आपातकालीन जीवनरक्षक उपाय, सीपीआर, जलने का इलाज और घुटन से बचाव।',
    descriptionMr: 'आणीबाणीच्या वेळी जीवन वाचवणारे प्रथमोपचार, सीपीआर आणि भाजल्यावरील उपाय.'
  },
  {
    id: 'heart-health-quiz',
    emoji: '🫀',
    iconBg: 'bg-gradient-to-br from-rose-600 to-pink-700',
    badgeBg: 'bg-rose-100 text-rose-800 border-rose-200',
    nameEn: 'Heart Health Quiz',
    nameHi: 'हृदय स्वास्थ्य प्रश्नोत्तरी',
    nameMr: 'हृदय आरोग्य प्रश्नमंजुषा',
    descriptionEn: 'Blood pressure control, heart attack warning signs, and cardiovascular fitness.',
    descriptionHi: 'रक्तचाप नियंत्रण, हार्ट अटैक के चेतावनी संकेत और दिल की देखभाल।',
    descriptionMr: 'रक्तदाब नियंत्रण, हृदयविकाराच्या झटक्याची लक्षणे आणि हृदयाची निगा.'
  },
  {
    id: 'diabetes-quiz',
    emoji: '🩸',
    iconBg: 'bg-gradient-to-br from-amber-500 to-orange-600',
    badgeBg: 'bg-amber-100 text-amber-800 border-amber-200',
    nameEn: 'Diabetes Quiz',
    nameHi: 'मधुमेह प्रश्नोत्तरी',
    nameMr: 'मधुमेह प्रश्नमंजुषा',
    descriptionEn: 'Blood glucose management, HbA1c testing, insulin care, and diabetic diet.',
    descriptionHi: 'ब्लड शुगर नियंत्रण, HbA1c टेस्ट, इंसुलिन और डायबिटीज आहार की समझ।',
    descriptionMr: 'रक्तातील साखर नियंत्रण, HbA1c चाचणी आणि मधुमेहींचा आहार.'
  },
  {
    id: 'mental-health-quiz',
    emoji: '🧠',
    iconBg: 'bg-gradient-to-br from-purple-500 to-indigo-700',
    badgeBg: 'bg-purple-100 text-purple-800 border-purple-200',
    nameEn: 'Mental Health Quiz',
    nameHi: 'मानसिक स्वास्थ्य प्रश्नोत्तरी',
    nameMr: 'मानसिक आरोग्य प्रश्नमंजुषा',
    descriptionEn: 'Stress management, sleep hygiene, anxiety relief, and emotional well-being.',
    descriptionHi: 'तनाव प्रबंधन, बेहतर नींद, चिंता से मुक्ति और मानसिक शांति।',
    descriptionMr: 'ताणतणाव व्यवस्थापन, शांत झोप, चिंतेवर मात आणि मानसिक स्वास्थ्य.'
  },
  {
    id: 'child-health-quiz',
    emoji: '👶',
    iconBg: 'bg-gradient-to-br from-sky-500 to-blue-600',
    badgeBg: 'bg-sky-100 text-sky-800 border-sky-200',
    nameEn: 'Child Health Quiz',
    nameHi: 'बाल स्वास्थ्य प्रश्नोत्तरी',
    nameMr: 'बाल आरोग्य प्रश्नमंजुषा',
    descriptionEn: 'Immunization schedules, pediatric nutrition, fever care, and growth milestones.',
    descriptionHi: 'बच्चों का टीकाकरण, पोषण, बुखार में देखभाल और शारीरिक विकास।',
    descriptionMr: 'लहान मुलांचे लसीकरण, बालपोषण, तापाची काळजी आणि वाढीचे टप्पे.'
  },
  {
    id: 'womens-health-quiz',
    emoji: '👩',
    iconBg: 'bg-gradient-to-br from-fuchsia-500 to-pink-600',
    badgeBg: 'bg-fuchsia-100 text-fuchsia-800 border-fuchsia-200',
    nameEn: "Women's Health Quiz",
    nameHi: 'महिला स्वास्थ्य प्रश्नोत्तरी',
    nameMr: 'महिला आरोग्य प्रश्नमंजुषा',
    descriptionEn: 'Maternal care, anemia prevention, hormonal health, and wellness routines.',
    descriptionHi: 'गर्भावस्था की देखभाल, एनीमिया से बचाव, हार्मोनल स्वास्थ्य और स्व-देखभाल।',
    descriptionMr: 'गरोदरपणाची काळजी, ॲनिमिया प्रतिबंध, हार्मोन्सचे आरोग्य आणि स्व-आरोग्य.'
  },
  {
    id: 'senior-health-quiz',
    emoji: '🧓',
    iconBg: 'bg-gradient-to-br from-stone-500 to-slate-700',
    badgeBg: 'bg-stone-100 text-stone-800 border-stone-200',
    nameEn: 'Senior Health Quiz',
    nameHi: 'वरिष्ठ नागरिक स्वास्थ्य प्रश्नोत्तरी',
    nameMr: 'ज्येष्ठ नागरिक आरोग्य प्रश्नमंजुषा',
    descriptionEn: 'Fall prevention, joint care, bone density, memory preservation, and longevity.',
    descriptionHi: 'फिसलने से बचाव, जोड़ों की देखभाल, हड्डियों की मजबूती और याददाश्त सुरक्षा।',
    descriptionMr: 'पडण्यापासून बचाव, सांधेदुखी, हाडांची मजबूती आणि स्मरणशक्ती जपणे.'
  }
];

export const QUIZ_LEVELS: QuizLevelMeta[] = [
  {
    level: 'Beginner',
    emoji: '🟢',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    totalQuestions: 10,
    estimatedMinutes: 5,
    nameEn: 'Beginner Level',
    nameHi: 'प्रारंभिक स्तर (Beginner)',
    nameMr: 'प्राथमिक पातळी (Beginner)'
  },
  {
    level: 'Intermediate',
    emoji: '🟡',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
    totalQuestions: 15,
    estimatedMinutes: 8,
    nameEn: 'Intermediate Level',
    nameHi: 'मध्यम स्तर (Intermediate)',
    nameMr: 'मध्यम पातळी (Intermediate)'
  },
  {
    level: 'Advanced',
    emoji: '🔴',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    totalQuestions: 20,
    estimatedMinutes: 12,
    nameEn: 'Advanced Level',
    nameHi: 'उच्च स्तर (Advanced)',
    nameMr: 'प्रगत पातळी (Advanced)'
  }
];

// Helper to generate question sets for any category and difficulty
export function getQuizQuestions(categoryId: string, difficulty: 'Beginner' | 'Intermediate' | 'Advanced'): QuizQuestion[] {
  const targetCount = difficulty === 'Beginner' ? 10 : difficulty === 'Intermediate' ? 15 : 20;

  // Primary database of curated questions
  const pool = QUESTION_BANK[categoryId] || QUESTION_BANK['disease-quiz'];
  const questions: QuizQuestion[] = [];

  for (let i = 0; i < targetCount; i++) {
    const raw = pool[i % pool.length];
    questions.push({
      ...raw,
      id: `${categoryId}-${difficulty.toLowerCase()}-q${i + 1}`
    });
  }

  return questions;
}

export function getDailyQuizQuestions(): QuizQuestion[] {
  const today = new Date().toISOString().split('T')[0];
  const allCategories = Object.keys(QUESTION_BANK);
  const questions: QuizQuestion[] = [];

  for (let i = 0; i < 10; i++) {
    const catId = allCategories[i % allCategories.length];
    const pool = QUESTION_BANK[catId];
    const q = pool[i % pool.length];
    questions.push({
      ...q,
      id: `daily-quiz-${today}-q${i + 1}`
    });
  }

  return questions;
}

// Full multi-category, trilingual question repository
const QUESTION_BANK: Record<string, QuizQuestion[]> = {
  'disease-quiz': [
    {
      id: 'd1',
      content: {
        English: {
          question: 'Which mosquito is primarily responsible for transmitting Dengue virus?',
          options: ['Anopheles mosquito', 'Aedes aegypti mosquito', 'Culex mosquito', 'Mansonia mosquito'],
          correctAnswer: 1,
          explanation: 'Aedes aegypti mosquitoes bite during daytime and transmit the Dengue virus.'
        },
        Hindi: {
          question: 'डेंग्यू वायरस फैलाने के लिए कौन सा मच्छर मुख्य रूप से जिम्मेदार है?',
          options: ['एनोफिलीज मच्छर', 'एडीज एजिप्टी मच्छर', 'क्यूलेक्स मच्छर', 'मेंसोनिया मच्छर'],
          correctAnswer: 1,
          explanation: 'एडीज एजिप्टी मच्छर दिन के समय काटते हैं और डेंग्यू का वायरस फैलाते हैं।'
        },
        Marathi: {
          question: 'डेरेंग्यूचा विषाणू पसरवण्यासाठी मुख्यत्वे कोणता डास कारणीभूत असतो?',
          options: ['ॲनोफिलीस डास', 'एडीस इजिप्ती डास', 'क्युलेक्स डास', 'मान्सोनिया डास'],
          correctAnswer: 1,
          explanation: 'एडीस इजिप्ती डास दिवसा चावतात आणि डेंग्यूचा प्रसार करतात.'
        }
      }
    },
    {
      id: 'd2',
      content: {
        English: {
          question: 'What is a key warning sign of severe dehydration during fever or diarrhea?',
          options: ['High appetite', 'Dry mouth and dark yellow urine', 'Excessive sweating', 'Normal energy levels'],
          correctAnswer: 1,
          explanation: 'Dry mouth, sunken eyes, and dark urine signal immediate fluid replacement needs.'
        },
        Hindi: {
          question: 'बुखार या दस्त के दौरान गंभीर निर्जलीकरण (डिहाइड्रेशन) का मुख्य संकेत क्या है?',
          options: ['अधिक भूख लगना', 'सूखा मुंह और गहरा पीला पेशाब', 'अत्यधिक पसीना', 'सामान्य ऊर्जा स्तर'],
          correctAnswer: 1,
          explanation: 'सूखा मुंह और गहरा पीला पेशाब शरीर में पानी की गंभीर कमी का संकेत देते हैं।'
        },
        Marathi: {
          question: 'ताप किंवा जुलाबादरम्यान तीव्र डिहायड्रेशनचे (पाण्याची कमतरता) मुख्य लक्षण कोणते?',
          options: ['जास्त भूक लागणे', 'कोरडे तोंड आणि गडद पिवळी लघवी', 'खूप घाम येणे', 'सामान्य उत्साह'],
          correctAnswer: 1,
          explanation: 'कोरडे तोंड आणि गडद पिवळी लघवी ही शरीरातील पाणी कमी झाल्याची धोक्याची घंटा आहे.'
        }
      }
    },
    {
      id: 'd3',
      content: {
        English: {
          question: 'Which test is considered the gold standard for measuring long-term blood sugar in Diabetes?',
          options: ['Fasting Blood Glucose', 'HbA1c Test', 'Urine Dipstick Test', 'Oral Glucose Tolerance Test'],
          correctAnswer: 1,
          explanation: 'HbA1c reflects average blood sugar levels over the past 2 to 3 months.'
        },
        Hindi: {
          question: 'डायबिटीज में पिछले 2-3 महीनों के औसत ब्लड शुगर को मापने के लिए कौन सा टेस्ट सर्वोत्तम माना जाता है?',
          options: ['फास्टिंग ब्लड ग्लूकोज', 'HbA1c टेस्ट', 'यूरिन डिपस्टिक टेस्ट', 'ग्लूकोज टॉलरेंस टेस्ट'],
          correctAnswer: 1,
          explanation: 'HbA1c टेस्ट पिछले 2-3 महीनों का औसत ब्लड शुगर लेवल सही दिखाता है।'
        },
        Marathi: {
          question: 'मधुमेहामध्ये मागील २-३ महिन्यांची सरासरी साखर मोजण्यासाठी कोणती चाचणी सर्वोत्तम मानली जाते?',
          options: ['फास्टिंग ब्लड ग्लुकोज', 'HbA1c टेस्ट', 'युरिन डिपस्टिक टेस्ट', 'ग्लुकोज टॉलरन्स टेस्ट'],
          correctAnswer: 1,
          explanation: 'HbA1c चाचणी मागील २ ते ३ महिन्यांच्या सरासरी रक्तातील साखरेची अचूक माहिती देते.'
        }
      }
    },
    {
      id: 'd4',
      content: {
        English: {
          question: 'How is Tuberculosis (TB) primarily transmitted from person to person?',
          options: ['Contaminated water', 'Airborne respiratory droplets when coughing or sneezing', 'Mosquito bites', 'Touching skin'],
          correctAnswer: 1,
          explanation: 'TB bacteria spread through air when an infected person coughs, sneezes, or talks.'
        },
        Hindi: {
          question: 'टीबी (क्षयरोग) एक व्यक्ति से दूसरे व्यक्ति में मुख्य रूप से कैसे फैलता है?',
          options: ['दूषित पानी से', 'खांसने या छींकने की बूंदों से (हवा द्वारा)', 'मच्छर के काटने से', 'त्वचा छूने से'],
          correctAnswer: 1,
          explanation: 'टीबी के जीवाणु हवा के जरिए मरीज के खांसने या छींकने से फैलते हैं।'
        },
        Marathi: {
          question: 'टीबी (क्षयरोग) एका व्यक्तीकडून दुसऱ्या व्यक्तीकडे मुख्यत्वे कसा पसरतो?',
          options: ['दूषित पाण्याद्वारे', 'खोकल्यातून किंवा शिंकण्यातून हवेद्वारे पसरणाऱ्या थेंबांमुळे', 'डास चावल्याने', 'त्वचेचा स्पर्श झाल्याने'],
          correctAnswer: 1,
          explanation: 'टीबीचे जिवाणू खोकताना किंवा शिंकताना हवेत पसरणाऱ्या सूक्ष्म थेंबांद्वारे पसरतात.'
        }
      }
    },
    {
      id: 'd5',
      content: {
        English: {
          question: 'What is the primary characteristic symptom of Malaria?',
          options: ['High fever with shivering cold and sweating cycles', 'Persistent dry cough only', 'Skin redness without fever', 'Swollen joints'],
          correctAnswer: 0,
          explanation: 'Malaria features periodic high fever accompanied by intense chills and sweating.'
        },
        Hindi: {
          question: 'मलेरिया का प्राथमिक और विशिष्ट लक्षण क्या है?',
          options: ['कंपकंपी और पसीने के साथ तेज बुखार आना', 'केवल सूखी खांसी', 'बिना बुखार के त्वचा लाल होना', 'जोड़ों में सूजन'],
          correctAnswer: 0,
          explanation: 'मलेरिया में ठंड लगकर तेज बुखार आता है और फिर पसीना आकर बुखार उतरता है।'
        },
        Marathi: {
          question: 'मलेरियाचे मुख्य आणि वैशिष्ट्यपूर्ण लक्षण कोणते?',
          options: ['थंडी वाजून जोरात ताप येणे आणि घाम येऊन ताप उतरणे', 'फक्त कोरडा खोकला', 'तापाशिवाय अंगावर पुरळ', 'सांध्यांना सूज'],
          correctAnswer: 0,
          explanation: 'मलेरियामध्ये खूप थंडी वाजून ताप येतो आणि नंतर घाम येऊन ताप कमी होतो.'
        }
      }
    }
  ],
  'medicine-quiz': [
    {
      id: 'm1',
      content: {
        English: {
          question: 'What is the active ingredient in most over-the-counter paracetamol pain relievers?',
          options: ['Ibuprofen', 'Acetaminophen', 'Aspirin', 'Diclofenac'],
          correctAnswer: 1,
          explanation: 'Acetaminophen is the international generic chemical name for Paracetamol.'
        },
        Hindi: {
          question: 'पैरासिटामोल दवा का दूसरा अंतरराष्ट्रीय जेनेरिक नाम क्या है?',
          options: ['आइबूप्रोफेन', 'एसेटामिनोफेन (Acetaminophen)', 'एस्पिरिन', 'डाइक्लोफेनैक'],
          correctAnswer: 1,
          explanation: 'एसेटामिनोफेन और पैरासिटामोल दोनों एक ही सक्रिय दवा रसायन के नाम हैं।'
        },
        Marathi: {
          question: 'पॅरासिटामॉल या औषधाचे आंतरराष्ट्रीय जेनेरिक नाव काय आहे?',
          options: ['आयब्युप्रोफेन', 'ॲसिटामिनोफेन (Acetaminophen)', 'ॲस्पिरिन', 'डायक्लोफेनॅक'],
          correctAnswer: 1,
          explanation: 'ॲसिटामिनोफेन आणि पॅरासिटामॉल हे एकाच मूळ औषधाचे नाव आहे.'
        }
      }
    },
    {
      id: 'm2',
      content: {
        English: {
          question: 'Why should Antibiotics never be taken for a common cold or flu?',
          options: ['Cold and flu are caused by viruses, not bacteria', 'Antibiotics cause sleepiness', 'Cold medicines stop antibiotics from working', 'Antibiotics are too expensive'],
          correctAnswer: 0,
          explanation: 'Antibiotics kill bacteria only and have zero effect against viral infections like cold and flu.'
        },
        Hindi: {
          question: 'सामान्य सर्दी या फ्लू में एंटीबायोटिक (Antibiotic) क्यों नहीं लेनी चाहिए?',
          options: ['सर्दी-फ्लू वायरस (विषाणु) से होते हैं, बैक्टीरिया से नहीं', 'एंटीबायोटिक से नींद आती है', 'सर्दी की दवाएं एंटीबायोटिक को रोकती हैं', 'एंटीबायोटिक बहुत महंगी होती हैं'],
          correctAnswer: 0,
          explanation: 'एंटीबायोटिक केवल बैक्टीरिया को मारती हैं, वायरस पर उनका कोई असर नहीं होता।'
        },
        Marathi: {
          question: 'सर्दी किंवा फ्लूमध्ये ॲंटिबायोटिक्स (Antibiotics) का घेऊ नयेत?',
          options: ['सर्दी-फ्लू हे विषाणूंमुळे (Virus) होतात, जिवाणूंमुळे (Bacteria) नाही', 'ॲंटिबायोटिक्सने झोप येते', 'सर्दीची औषधे ॲंटिबायोटिक बंद करतात', 'ॲंटिबायोटिक्स खूप महाग असतात'],
          correctAnswer: 0,
          explanation: 'ॲंटिबायोटिक्स फक्त जिवाणूंवर (Bacteria) काम करतात, विषाणूंवर (Virus) त्यांचा कोणताही परिणाम होत नाही.'
        }
      }
    },
    {
      id: 'm3',
      content: {
        English: {
          question: 'What is the most dangerous consequence of exceeding the recommended maximum dose of Paracetamol?',
          options: ['Severe Liver Damage', 'Kidney Stone Formation', 'Hair Loss', 'High Blood Pressure'],
          correctAnswer: 0,
          explanation: 'Overdosing on paracetamol (exceeding 4,000 mg daily) can cause fatal liver toxicity.'
        },
        Hindi: {
          question: 'पैरासिटामोल की निर्धारित मात्रा से अधिक खुराक लेने का सबसे खतरनाक दुष्प्रभाव क्या है?',
          options: ['गंभीर लिवर की क्षति (Liver Failure)', 'किडनी में पथरी', 'बाल झड़ना', 'उच्च रक्तचाप'],
          correctAnswer: 0,
          explanation: 'पैरासिटामोल की ओवरडोज से लिवर को गंभीर और स्थायी नुकसान पहुंच सकता है।'
        },
        Marathi: {
          question: 'पॅरासिटामॉलचे प्रमाणापेक्षा जास्त सेवन केल्यास कोणता सर्वात धोकादायक दुष्परिणाम होऊ शकतो?',
          options: ['यकृताचे (लिव्हर) गंभीर नुकसान', 'मुतखडा होणे', 'केस गळणे', 'उच्च रक्तदाब'],
          correctAnswer: 0,
          explanation: 'पॅरासिटामॉलच्या ओव्हरडोजमुळे लिव्हर फेल्युअरचा मोठा धोका संभवतो.'
        }
      }
    }
  ],
  'nutrition-quiz': [
    {
      id: 'n1',
      content: {
        English: {
          question: 'Which vitamin essential for bone strength is synthesized when skin is exposed to sunlight?',
          options: ['Vitamin A', 'Vitamin C', 'Vitamin D', 'Vitamin K'],
          correctAnswer: 2,
          explanation: 'Sunlight prompts the skin to produce Vitamin D, which regulates calcium absorption.'
        },
        Hindi: {
          question: 'हड्डियों को मजबूत बनाने वाला कौन सा विटामिन त्वचा पर धूप पड़ने से बनता है?',
          options: ['विटामिन A', 'विटामिन C', 'विटामिन D', 'विटामिन K'],
          correctAnswer: 2,
          explanation: 'सूर्य के प्रकाश से त्वचा में विटामिन D का निर्माण होता है, जो कैल्शियम सोखने में मदद करता है।'
        },
        Marathi: {
          question: 'हाडे मजबूत ठेवण्यासाठी आवश्यक असलेले कोणते जीवनसत्त्व सूर्यप्रकाशातून त्वचेमध्ये तयार होते?',
          options: ['व्हिटॅमिन A', 'व्हिटॅमिन C', 'व्हिटॅमिन D', 'व्हिटॅमिन K'],
          correctAnswer: 2,
          explanation: 'सूर्यप्रकाशामुळे त्वचेमध्ये व्हिटॅमिन D ची निर्मिती होते, ज्यामुळे हाडांना कॅल्शियम मिळते.'
        }
      }
    },
    {
      id: 'n2',
      content: {
        English: {
          question: 'Deficiency of which mineral is the leading cause of Nutritional Anemia?',
          options: ['Sodium', 'Iron', 'Potassium', 'Magnesium'],
          correctAnswer: 1,
          explanation: 'Iron deficiency reduces hemoglobin production, causing fatigue and anemia.'
        },
        Hindi: {
          question: 'शरीर में किस खनिज (Mineral) की कमी से एनीमिया (खून की कमी) होती है?',
          options: ['सोडियम', 'आयरन (लोह)', 'पोटैशियम', 'मैग्नीशियम'],
          correctAnswer: 1,
          explanation: 'आयरन की कमी से हीमोग्लोबिन नहीं बन पाता और खून की कमी (एनीमिया) होती है।'
        },
        Marathi: {
          question: 'कोणत्या खनिजाच्या (Mineral) कमतरतेमुळे ॲनिमिया (रक्तक्षय) होतो?',
          options: ['सोडियम', 'आयर्न (लोह)', 'पोटॅशियम', 'मॅग्नेशियम'],
          correctAnswer: 1,
          explanation: 'लोहाच्या कमतरतेमुळे रक्तातील हिमोग्लोबिन कमी होऊन ॲनिमिया होतो.'
        }
      }
    }
  ],
  'first-aid-quiz': [
    {
      id: 'f1',
      content: {
        English: {
          question: 'What is the correct ratio of chest compressions to rescue breaths during adult CPR?',
          options: ['15 compressions to 2 breaths', '30 compressions to 2 breaths', '50 compressions to 5 breaths', 'Continuous compressions only'],
          correctAnswer: 1,
          explanation: 'The standard adult CPR cycle is 30 chest compressions followed by 2 rescue breaths.'
        },
        Hindi: {
          question: 'वयस्क में सीपीआर (CPR) देते समय छाती दबाने और सांस देने का सही अनुपात क्या है?',
          options: ['15 बार छाती दबाएं : 2 सांसें', '30 बार छाती दबाएं : 2 सांसें', '50 बार छाती दबाएं : 5 सांसें', 'केवल छाती दबाते रहें'],
          correctAnswer: 1,
          explanation: 'मानक सीपीआर चक्र 30 बार तेज छाती दबाने और 2 कृत्रिम सांसों का होता है।'
        },
        Marathi: {
          question: 'मोठ्या व्यक्तीला सीपीआर (CPR) देताना छाती दाबणे आणि कृत्रिम श्वास देण्याचे योग्य प्रमाण काय?',
          options: ['१५ वेळा छाती दाबा : २ श्वास', '३० वेळा छाती दाबा : २ श्वास', '५० वेळा छाती दाबा : ५ श्वास', 'फक्त छाती दाबत राहा'],
          correctAnswer: 1,
          explanation: 'प्रमाणित सीपीआरमध्ये ३० वेळा छाती दाबल्यानंतर २ वेळा तोंडाने श्वास दिला जातो.'
        }
      }
    },
    {
      id: 'f2',
      content: {
        English: {
          question: 'What should be done FIRST for a mild first-degree burn from boiling water or grease?',
          options: ['Apply ice cubes directly', 'Cool with running clean cool water for 10-15 minutes', 'Apply butter or oil', 'Pop any blisters immediately'],
          correctAnswer: 1,
          explanation: 'Cool running water safely stops heat penetration without damaging fragile tissue.'
        },
        Hindi: {
          question: 'उबलते पानी या तेल से हल्का जलने पर सबसे पहले क्या करना चाहिए?',
          options: ['सीधे बर्फ लगाएं', '10-15 मिनट तक बहते ठंडे पानी से धोएं', 'मक्खन या तेल लगाएं', 'छाले फोड़ दें'],
          correctAnswer: 1,
          explanation: 'बहते ठंडे पानी से 10-15 मिनट तक धोने से जलन शांत होती है और त्वचा सुरक्षित रहती है।'
        },
        Marathi: {
          question: 'उकळत्या पाण्याने किंवा तेलाने किरकोळ भाजल्यास सर्वात आधी काय केले पाहिजे?',
          options: ['थेट बर्फ लावावा', '१०-१५ मिनिटे वाहत्या थंड पाण्याखाली ठेवावे', 'लोणी किंवा तेल लावावे', 'फोड लगेच फोडावेत'],
          correctAnswer: 1,
          explanation: 'वाहत्या थंड पाण्याने १० ते १५ मिनिटे धुतल्याने त्वचा आतून शेकणे थांबते.'
        }
      }
    }
  ],
  'heart-health-quiz': [
    {
      id: 'h1',
      content: {
        English: {
          question: 'What range is considered a Normal Resting Blood Pressure for an adult?',
          options: ['Below 120/80 mmHg', '140/90 mmHg', '160/100 mmHg', '90/50 mmHg'],
          correctAnswer: 0,
          explanation: 'A normal reading is systolic under 120 mmHg and diastolic under 80 mmHg.'
        },
        Hindi: {
          question: 'वयस्क व्यक्ति का सामान्य विश्राम रक्तचाप (Blood Pressure) कितना होना चाहिए?',
          options: ['120/80 mmHg से कम', '140/90 mmHg', '160/100 mmHg', '90/50 mmHg'],
          correctAnswer: 0,
          explanation: 'सामान्य ब्लड प्रेशर 120/80 mmHg से कम होना आदर्श माना जाता है।'
        },
        Marathi: {
          question: 'प्राौढ व्यक्तीचा सामान्य रक्तदाब (Blood Pressure) किती असावा?',
          options: ['१२०/८० mmHg पेक्षा कमी', '१४०/९० mmHg', '१६०/१०० mmHg', '९०/५० mmHg'],
          correctAnswer: 0,
          explanation: 'प्राौढ व्यक्तीचा निरोगी रक्तदाब १२०/८० mmHg पेक्षा कमी असतो.'
        }
      }
    }
  ],
  'diabetes-quiz': [
    {
      id: 'db1',
      content: {
        English: {
          question: 'What is a sudden feeling of shakiness, sweating, and confusion usually caused by in diabetic patients?',
          options: ['Hypoglycemia (Low blood sugar)', 'Hyperglycemia (High blood sugar)', 'High blood pressure', 'Dehydration'],
          correctAnswer: 0,
          explanation: 'Hypoglycemia occurs when blood sugar drops below 70 mg/dL, requiring fast-acting sugar.'
        },
        Hindi: {
          question: 'डायबिटीज के मरीज को अचानक घबराहट, पसीना और चक्कर आना किसका लक्षण है?',
          options: ['हाइपोग्लाइसीमिया (लो ब्लड शुगर)', 'हाइपरग्लाइसीमिया (हाई ब्लड शुगर)', 'उच्च रक्तचाप', 'डिहाइड्रेशन'],
          correctAnswer: 0,
          explanation: 'ब्लड शुगर 70 mg/dL से नीचे जाने पर शरीर में घबराहट और पसीना आता है।'
        },
        Marathi: {
          question: 'मधुमेहाच्या रुग्णाला अचानक थरथर कापणे, घाम येणे आणि चक्कर येणे कशामुळे होते?',
          options: ['हायपोग्लायसेमिया (कमी साखर)', 'हायपरग्लायसेमिया (जास्त साखर)', 'उच्च रक्तदाब', 'डीहायड्रेशन'],
          correctAnswer: 0,
          explanation: 'रक्तातील साखर ७० mg/dL पेक्षा कमी झाल्यास हायपोग्लायसेमिया होतो.'
        }
      }
    }
  ],
  'mental-health-quiz': [
    {
      id: 'mh1',
      content: {
        English: {
          question: 'Which slow breathing technique helps reduce acute stress and panic attacks?',
          options: ['Box Breathing (4-4-4-4 technique)', 'Rapid shallow breathing', 'Holding breath for 2 minutes', 'Fast coughing'],
          correctAnswer: 0,
          explanation: 'Box breathing regulates the vagus nerve and lowers heart rate quickly.'
        },
        Hindi: {
          question: 'मानसिक तनाव और एंग्जायटी को तुरंत कम करने के लिए कौन सी श्वसन तकनीक उपयोगी है?',
          options: ['बॉक्स ब्रीदिंग (4-4-4-4 तकनीक)', 'तेज सांस लेना', '2 मिनट सांस रोकना', 'तेज खांसी'],
          correctAnswer: 0,
          explanation: 'गहरी और धीमी सांस लेने की बॉक्स ब्रीदिंग तकनीक से दिल की धड़कन और तनाव शांत होता है।'
        },
        Marathi: {
          question: 'तणाव आणि भीतीची लाट (Panic Attack) कमी करण्यासाठी कोणती श्वसन पद्धती उपयुक्त ठरते?',
          options: ['बॉक्स ब्रीदिंग (४-४-४-४ पद्धत)', 'घाईघाईने श्वास घेणे', '२ मिनिटे श्वास रोखणे', 'मोठ्याने खोकणे'],
          correctAnswer: 0,
          explanation: 'बॉक्स ब्रीदिंग तंत्रामुळे नाडीचे ठोके शांत होतात आणि मानसिक तणाव कमी होतो.'
        }
      }
    }
  ],
  'child-health-quiz': [
    {
      id: 'ch1',
      content: {
        English: {
          question: 'How long does WHO recommend exclusive breastfeeding for newborns before introducing solid foods?',
          options: ['First 6 months', 'First 2 months', 'First 12 months', 'First 1 month'],
          correctAnswer: 0,
          explanation: 'Exclusive breastfeeding for the first 6 months provides ideal antibodies and nutrition.'
        },
        Hindi: {
          question: 'डब्ल्यूएचओ (WHO) के अनुसार नवजात शिशु को केवल मां का दूध (Exclusive Breastfeeding) कितने महीने देना चाहिए?',
          options: ['शुरुआती 6 महीने', 'शुरुआती 2 महीने', 'शुरुआती 12 महीने', 'शुरुआती 1 महीना'],
          correctAnswer: 0,
          explanation: 'शुरुआती 6 महीनों तक केवल मां का दूध शिशु को सभी बीमारियों से बचाता है।'
        },
        Marathi: {
          question: 'जागतिक आरोग्य संघटनेनुसार (WHO) नवजात बालकाला पहिले किती महिने फक्त आईचेच दूध दिले पाहिजे?',
          options: ['पहिले ६ महिने', 'पहिले २ महिने', 'पहिले १२ महिने', 'पहिला १ महिना'],
          correctAnswer: 0,
          explanation: 'पहिल्या ६ महिन्यांत फक्त आईचे दूध दिल्यामुळे बाळाची प्रतिकारशक्ती उत्तम राहते.'
        }
      }
    }
  ],
  'womens-health-quiz': [
    {
      id: 'wh1',
      content: {
        English: {
          question: 'Which supplement is recommended before and during early pregnancy to prevent neural tube defects?',
          options: ['Folic Acid (Vitamin B9)', 'Vitamin K', 'Calcium only', 'Vitamin E'],
          correctAnswer: 0,
          explanation: 'Folic acid supports early fetal spine and brain development.'
        },
        Hindi: {
          question: 'गर्भावस्था के शुरुआती दिनों में शिशु के रीढ़ और मस्तिष्क के विकास के लिए कौन सा सप्लीमेंट अनिवार्य है?',
          options: ['फॉलिक एसिड (विटामिन B9)', 'विटामिन K', 'केवल कैल्शियम', 'विटामिन E'],
          correctAnswer: 0,
          explanation: 'फॉलिक एसिड शिशु को न्यूरल ट्यूब दोषों से सुरक्षित रखता है।'
        },
        Marathi: {
          question: 'गरोदरपणाच्या सुरुवातीला बाळाच्या पाठीचा कणा व मेंदूच्या विकासासाठी कोणते औषध अत्यंत महत्त्वाचे असते?',
          options: ['फॉलिक ॲसिड (व्हिटॅमिन B9)', 'व्हिटॅमिन K', 'फक्त कॅल्शियम', 'व्हिटॅमिन E'],
          correctAnswer: 0,
          explanation: 'फॉलिक ॲसिडमुळे गर्भातील बाळाचा मज्जारज्जू आणि मेंदू सुदृढ राहतो.'
        }
      }
    }
  ],
  'senior-health-quiz': [
    {
      id: 'sh1',
      content: {
        English: {
          question: 'What is a major environmental risk factor for falls among elderly individuals at home?',
          options: ['Loose rugs and wet bathroom floors', 'Bright room lighting', 'Sturdy handrails on stairs', 'Non-slip footwear'],
          correctAnswer: 0,
          explanation: 'Slippery bathroom tiles and loose floor mats cause the majority of senior falls.'
        },
        Hindi: {
          question: 'घर में बुजुर्गों के गिरने और चोट लगने का मुख्य कारण क्या होता है?',
          options: ['फिसलन भरे फर्श और खुले पायदान (रग्स)', 'अच्छी रोशनी', 'सीढ़ियों पर मजबूत ग्रिल', 'एंटी-स्लिप जूते'],
          correctAnswer: 0,
          explanation: 'गीले बाथरूम और ढीले पायदान बुजुर्गों के फिसलने का सबसे बड़ा कारण बनते हैं।'
        },
        Marathi: {
          question: 'घरामध्ये वयोवृद्ध व्यक्ती घसरून पडण्याचे सर्वात मुख्य कारण कोणते?',
          options: ['घसरडे पायपुसणे आणि बाथरूममधील ओला मजला', 'प्रकाशमान दिवा', 'जिन्यावर मजबूत रेलिंग', 'अॅन्टी-स्लिप चप्पल'],
          correctAnswer: 0,
          explanation: 'बाथरूममधील ओले लादी व सैल पायपुसण्यांमुळे वयोवृद्धांचे घसरून पडण्याचे प्रमाण जास्त असते.'
        }
      }
    }
  ]
};
