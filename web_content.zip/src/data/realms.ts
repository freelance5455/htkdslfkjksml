import { RealmDefinition } from '../types/cultivation';

export const CULTIVATION_REALMS: RealmDefinition[] = [
  // 1. Qi Condensation (9 Layers)
  { id: 'qc_1', majorRealm: 'Qi Condensation', subStage: 'Layer 1', name: 'Qi Condensation (Layer 1)', order: 0, qiRequired: 100, lifespanBonus: 10, combatPower: 15, prestigeYield: 10, requiresTribulation: false },
  { id: 'qc_2', majorRealm: 'Qi Condensation', subStage: 'Layer 2', name: 'Qi Condensation (Layer 2)', order: 1, qiRequired: 250, lifespanBonus: 15, combatPower: 35, prestigeYield: 25, requiresTribulation: false },
  { id: 'qc_3', majorRealm: 'Qi Condensation', subStage: 'Layer 3', name: 'Qi Condensation (Layer 3)', order: 2, qiRequired: 500, lifespanBonus: 20, combatPower: 70, prestigeYield: 50, requiresTribulation: false },
  { id: 'qc_4', majorRealm: 'Qi Condensation', subStage: 'Layer 4', name: 'Qi Condensation (Layer 4)', order: 3, qiRequired: 1000, lifespanBonus: 25, combatPower: 120, prestigeYield: 90, requiresTribulation: false },
  { id: 'qc_5', majorRealm: 'Qi Condensation', subStage: 'Layer 5', name: 'Qi Condensation (Layer 5)', order: 4, qiRequired: 2000, lifespanBonus: 30, combatPower: 200, prestigeYield: 150, requiresTribulation: false },
  { id: 'qc_6', majorRealm: 'Qi Condensation', subStage: 'Layer 6', name: 'Qi Condensation (Layer 6)', order: 5, qiRequired: 4000, lifespanBonus: 35, combatPower: 320, prestigeYield: 240, requiresTribulation: false },
  { id: 'qc_7', majorRealm: 'Qi Condensation', subStage: 'Layer 7', name: 'Qi Condensation (Layer 7)', order: 6, qiRequired: 8000, lifespanBonus: 40, combatPower: 500, prestigeYield: 380, requiresTribulation: false },
  { id: 'qc_8', majorRealm: 'Qi Condensation', subStage: 'Layer 8', name: 'Qi Condensation (Layer 8)', order: 7, qiRequired: 15000, lifespanBonus: 45, combatPower: 750, prestigeYield: 550, requiresTribulation: false },
  { id: 'qc_9', majorRealm: 'Qi Condensation', subStage: 'Layer 9 (Great Circle)', name: 'Qi Condensation (Layer 9)', order: 8, qiRequired: 30000, lifespanBonus: 50, combatPower: 1100, prestigeYield: 800, requiresTribulation: false },

  // 2. Foundation Establishment (Pill assistance needed)
  { id: 'fe_early', majorRealm: 'Foundation Establishment', subStage: 'Early Stage', name: 'Foundation Establishment (Early)', order: 9, qiRequired: 65000, lifespanBonus: 100, combatPower: 2400, prestigeYield: 1800, requiresTribulation: false },
  { id: 'fe_mid', majorRealm: 'Foundation Establishment', subStage: 'Mid Stage', name: 'Foundation Establishment (Mid)', order: 10, qiRequired: 140000, lifespanBonus: 130, combatPower: 4200, prestigeYield: 3200, requiresTribulation: false },
  { id: 'fe_late', majorRealm: 'Foundation Establishment', subStage: 'Late Stage', name: 'Foundation Establishment (Late)', order: 11, qiRequired: 300000, lifespanBonus: 160, combatPower: 7500, prestigeYield: 5800, requiresTribulation: false },
  { id: 'fe_peak', majorRealm: 'Foundation Establishment', subStage: 'Peak Stage', name: 'Foundation Establishment (Peak)', order: 12, qiRequired: 600000, lifespanBonus: 200, combatPower: 12500, prestigeYield: 9500, requiresTribulation: false },

  // 3. Golden Core (Divine Core condenser - minor lightning test)
  { id: 'gc_early', majorRealm: 'Golden Core', subStage: 'Early (Grade 3-9)', name: 'Golden Core (Early Stage)', order: 13, qiRequired: 1500000, lifespanBonus: 350, combatPower: 26000, prestigeYield: 20000, requiresTribulation: true, tribulationLightningPower: 800 },
  { id: 'gc_mid', majorRealm: 'Golden Core', subStage: 'Mid (Grade 2 Core)', name: 'Golden Core (Mid Stage)', order: 14, qiRequired: 3500000, lifespanBonus: 420, combatPower: 48000, prestigeYield: 38000, requiresTribulation: false },
  { id: 'gc_late', majorRealm: 'Golden Core', subStage: 'Late (Grade 1 Divine)', name: 'Golden Core (Late Stage)', order: 15, qiRequired: 8000000, lifespanBonus: 500, combatPower: 85000, prestigeYield: 65000, requiresTribulation: false },
  { id: 'gc_peak', majorRealm: 'Golden Core', subStage: 'Great Perfection', name: 'Golden Core (Peak Stage)', order: 16, qiRequired: 18000000, lifespanBonus: 600, combatPower: 145000, prestigeYield: 110000, requiresTribulation: false },

  // 4. Nascent Soul (Soul Avatar Manifestation)
  { id: 'ns_early', majorRealm: 'Nascent Soul', subStage: 'Early Stage', name: 'Nascent Soul (Early Stage)', order: 17, qiRequired: 40000000, lifespanBonus: 1200, combatPower: 280000, prestigeYield: 220000, requiresTribulation: true, tribulationLightningPower: 2500 },
  { id: 'ns_mid', majorRealm: 'Nascent Soul', subStage: 'Mid Stage', name: 'Nascent Soul (Mid Stage)', order: 18, qiRequired: 90000000, lifespanBonus: 1500, combatPower: 520000, prestigeYield: 400000, requiresTribulation: false },
  { id: 'ns_late', majorRealm: 'Nascent Soul', subStage: 'Late Stage', name: 'Nascent Soul (Late Stage)', order: 19, qiRequired: 200000000, lifespanBonus: 1800, combatPower: 950000, prestigeYield: 750000, requiresTribulation: false },
  { id: 'ns_peak', majorRealm: 'Nascent Soul', subStage: 'Great Circle', name: 'Nascent Soul (Peak Great Circle)', order: 20, qiRequired: 450000000, lifespanBonus: 2200, combatPower: 1700000, prestigeYield: 1300000, requiresTribulation: false },

  // 5. Soul Formation (Deity Transformation / Heavenly Domain)
  { id: 'sf_early', majorRealm: 'Soul Formation', subStage: 'Early Stage', name: 'Soul Formation (Early)', order: 21, qiRequired: 1000000000, lifespanBonus: 3500, combatPower: 3200000, prestigeYield: 2500000, requiresTribulation: true, tribulationLightningPower: 8000 },
  { id: 'sf_late', majorRealm: 'Soul Formation', subStage: 'Late Stage', name: 'Soul Formation (Late)', order: 22, qiRequired: 2500000000, lifespanBonus: 5000, combatPower: 6800000, prestigeYield: 5200000, requiresTribulation: false },

  // 6. Void Refining (Transcending Mortal Elements)
  { id: 'vr_stage', majorRealm: 'Void Refining', subStage: 'Domain Master', name: 'Void Refining (Ascendant)', order: 23, qiRequired: 6000000000, lifespanBonus: 8000, combatPower: 14000000, prestigeYield: 11000000, requiresTribulation: true, tribulationLightningPower: 22000 },

  // 7. Body Integration (Sacred Unity)
  { id: 'bi_stage', majorRealm: 'Body Integration', subStage: 'Supreme Law', name: 'Body Integration (Supreme)', order: 24, qiRequired: 15000000000, lifespanBonus: 15000, combatPower: 30000000, prestigeYield: 24000000, requiresTribulation: true, tribulationLightningPower: 60000 },

  // 8. Tribulation Transcendence (9 Heavenly Lightning Strikes)
  { id: 'tt_stage', majorRealm: 'Tribulation Transcendence', subStage: 'Heavenly Dao Test', name: 'Tribulation Transcendence (9 Bolts)', order: 25, qiRequired: 40000000000, lifespanBonus: 30000, combatPower: 70000000, prestigeYield: 60000000, requiresTribulation: true, tribulationLightningPower: 180000 },

  // 9. Mahayana (The Absolute Pinnacle - Sovereign Immortal)
  { id: 'mh_peak', majorRealm: 'Mahayana', subStage: 'True Immortal Pinnacle', name: 'Mahayana (Immortal Sovereign)', order: 26, qiRequired: 100000000000, lifespanBonus: 99999, combatPower: 200000000, prestigeYield: 200000000, requiresTribulation: true, tribulationLightningPower: 500000 }
];

export const MAX_REALM_INDEX = CULTIVATION_REALMS.length - 1;

export function formatLargeNumber(num: number): string {
  if (num >= 1e9) {
    return (num / 1e9).toFixed(1) + 'B';
  }
  if (num >= 1e6) {
    return (num / 1e6).toFixed(1) + 'M';
  }
  if (num >= 1e3) {
    return (num / 1e3).toFixed(1) + 'K';
  }
  return num.toLocaleString();
}
