import type {
  DesignConfig,
  ExportSettings,
  FontKey,
  Project,
  Question,
  TimingConfig,
} from "@/types";

export const FONT_OPTIONS: { key: FontKey; label: string }[] = [
  { key: "Tajawal", label: "طجوال — حديث" },
  { key: "Cairo", label: "القاهرة — واضح" },
  { key: "Almarai", label: "المراعي — أنيق" },
  { key: "Amiri", label: "أميري — كلاسيكي" },
  { key: "IBM Plex Sans Arabic", label: "IBM Plex العربي" },
];

export const uid = (prefix = "id") =>
  `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;

export const ASPECT_PRESETS = {
  vertical: { width: 1080, height: 1920, label: "عمودي", hint: "TikTok · Shorts · Reels" },
  landscape: { width: 1920, height: 1080, label: "أفقي", hint: "YouTube · العروض" },
  square: { width: 1080, height: 1080, label: "مربع", hint: "Instagram · Feed" },
  custom: { width: 1080, height: 1350, label: "مخصص", hint: "أبعاد حسب اختيارك" },
} as const;

export const QUALITY_BITRATES = {
  economy: 3_000_000,
  standard: 6_000_000,
  high: 10_000_000,
} as const;

export const QUALITY_LABELS = {
  economy: "اقتصادية · 3 Mbps",
  standard: "قياسية · 6 Mbps",
  high: "عالية · 10 Mbps",
} as const;

export function defaultDesign(): DesignConfig {
  return {
    presetName: "الذهبي الليلي",
    background: {
      kind: "gradient",
      colorA: "#0b0d12",
      colorB: "#1b1710",
      angle: 155,
      imageId: null,
      overlay: 62,
      glow: true,
      grid: true,
    },
    typography: {
      font: "Tajawal",
      questionSize: 64,
      optionSize: 36,
      questionWeight: 700,
      optionWeight: 500,
      lineHeight: 1.35,
      align: "center",
      questionColor: "#FFFFFF",
      optionColor: "#EDEDF2",
    },
    options: {
      gap: 18,
      radius: 22,
      padding: 22,
      fill: "#FFFFFF",
      fillOpacity: 6,
      borderColor: "#FFFFFF",
      borderWidth: 1,
      shadow: true,
      letters: "arabic",
      correctColor: "#35D68B",
      dimOpacity: 45,
      showCheck: true,
    },
    timer: {
      visible: true,
      style: "ring",
      position: "bottom",
      x: 50,
      y: 89,
      size: 100,
      color: "#E4C87B",
      trackColor: "#2A2A30",
    },
    content: {
      x: 50,
      y: 47,
      width: 86,
      showCard: true,
      showQuestionNumber: true,
    },
    brand: {
      show: true,
      text: "QUIZ STUDIO",
      logoId: null,
      opacity: 85,
      showProgress: true,
    },
    motion: {
      entrance: "rise",
      reveal: "glow",
      transition: "fade",
      speed: 1,
    },
  };
}

export function defaultTiming(): TimingConfig {
  return {
    audioMode: "separate",
    combinedSplit: 55,
    questionHoldMs: 350,
    optionsHoldMs: 400,
    questionSilentMs: 3000,
    optionsSilentMs: 3200,
    nextHoldMs: 500,
    defaultThinkSec: 8,
    requireAudio: false,
    voiceVolume: 100,
    musicVolume: 12,
    sfxVolume: 70,
    backgroundMusicId: null,
    sfxEnabled: true,
    showOptionLetters: true,
  };
}

export function defaultExport(aspect: ExportSettings["aspect"] = "vertical"): ExportSettings {
  const preset = ASPECT_PRESETS[aspect];
  return {
    aspect,
    width: preset.width,
    height: preset.height,
    fps: 30,
    quality: "standard",
    videoBitrate: QUALITY_BITRATES.standard,
    audioBitrate: 128_000,
    filename: "quiz-studio-video",
  };
}

export function newEmptyQuestion(thinkSec = 8): Question {
  return {
    id: uid("q"),
    question: "",
    options: ["", "", "", ""],
    correct: -1,
    questionAudioId: null,
    optionsAudioId: null,
    combinedAudioId: null,
    answerAudioId: null,
    imageId: null,
    thinkSec,
    revealHoldMs: 1800,
  };
}

function sampleQuestions(): Question[] {
  const base = [
    {
      q: "ما هي عاصمة المملكة العربية السعودية؟",
      options: ["الرياض", "جدة", "مكة المكرمة", "الدمام"],
    },
    {
      q: "أي كوكب يُعرف باسم «الكوكب الأحمر»؟",
      options: ["المريخ", "الزهرة", "المشتري", "عطارد"],
    },
    {
      q: "كم عدد أيام السنة الهجرية تقريبًا؟",
      options: ["354 يومًا", "365 يومًا", "360 يومًا", "370 يومًا"],
    },
  ];
  return base.map((item, index) => ({
    ...newEmptyQuestion(8),
    question: item.q,
    options: item.options,
    correct: index === 0 ? 0 : index === 1 ? 0 : 0,
    revealHoldMs: 1800,
  }));
}

export function createStarterProject(): Project {
  const design = defaultDesign();
  const timing = defaultTiming();
  return {
    version: 1,
    id: uid("project"),
    name: "مسابقة المعرفة العامة",
    description:
      "نموذج جاهز للتعديل — استبدل هذه الأسئلة بمحتواك، وارفع ملفات صوتك من صفحة الصوت والتوقيت.",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isSample: true,
    questions: sampleQuestions(),
    design,
    timing,
    exportSettings: { ...defaultExport("vertical"), filename: "masabaqa-almarifa" },
    media: {},
    designPresets: [
      { id: uid("preset"), name: "الذهبي الليلي", design },
      {
        id: uid("preset"),
        name: "أخضر زمردي",
        design: {
          ...defaultDesign(),
          presetName: "أخضر زمردي",
          background: { ...design.background, colorA: "#07120f", colorB: "#10201a", glow: true },
          options: { ...design.options, correctColor: "#4BE39D", borderColor: "#CFF7E1" },
          timer: { ...design.timer, color: "#7DF0B8" },
        },
      },
      {
        id: uid("preset"),
        name: "بنفسجي ملكي",
        design: {
          ...defaultDesign(),
          presetName: "بنفسجي ملكي",
          background: { ...design.background, colorA: "#0d0918", colorB: "#1d1030", glow: true },
          options: { ...design.options, correctColor: "#5EE8A4" },
          timer: { ...design.timer, color: "#C9A4FF" },
          typography: { ...design.typography, font: "Almarai" },
        },
      },
    ],
  };
}

export function createBlankProject(name: string, aspect: ExportSettings["aspect"] = "vertical"): Project {
  return {
    version: 1,
    id: uid("project"),
    name: name.trim() || "مشروع بدون عنوان",
    description: "",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isSample: false,
    questions: [newEmptyQuestion()],
    design: defaultDesign(),
    timing: defaultTiming(),
    exportSettings: defaultExport(aspect),
    media: {},
    designPresets: [
      { id: uid("preset"), name: "الذهبي الليلي", design: defaultDesign() },
    ],
  };
}

export function normalizeProject(raw: unknown): Project {
  if (!raw || typeof raw !== "object") throw new Error("ملف المشروع غير صالح");
  const p = raw as Partial<Project>;
  if (!Array.isArray(p.questions)) throw new Error("ملف المشروع لا يحتوي على قائمة أسئلة صالحة");
  if (p.questions.length === 0) throw new Error("ملف المشروع لا يحتوي على أسئلة");
  const base = createBlankProject(typeof p.name === "string" ? p.name : "مشروع مستورد");
  const project: Project = {
    ...base,
    ...p,
    version: 1,
    id: typeof p.id === "string" ? p.id : base.id,
    name: typeof p.name === "string" && p.name.trim() ? p.name : "مشروع مستورد",
    createdAt: typeof p.createdAt === "number" ? p.createdAt : Date.now(),
    updatedAt: Date.now(),
    isSample: false,
    design: deepMerge(base.design, p.design ?? {}),
    timing: deepMerge(base.timing, p.timing ?? {}),
    exportSettings: deepMerge(base.exportSettings, p.exportSettings ?? {}),
    media: p.media && typeof p.media === "object" ? p.media : {},
    designPresets: Array.isArray(p.designPresets) ? p.designPresets : base.designPresets,
    questions: p.questions
      .filter((q) => q && typeof q === "object")
      .map((q, index) => {
        const candidate = q as Partial<Question>;
        return {
          ...newEmptyQuestion(),
          ...candidate,
          id: typeof candidate.id === "string" ? candidate.id : uid(`q${index + 1}`),
          question: typeof candidate.question === "string" ? candidate.question : "",
          options:
            Array.isArray(candidate.options) && candidate.options.length === 4
              ? candidate.options.map((o) => (typeof o === "string" ? o : String(o ?? "")))
              : ["", "", "", ""],
          correct: typeof candidate.correct === "number" ? candidate.correct : -1,
          thinkSec: Number.isFinite(candidate.thinkSec) ? Number(candidate.thinkSec) : 8,
          revealHoldMs: Number.isFinite(candidate.revealHoldMs) ? Number(candidate.revealHoldMs) : 1800,
        };
      }),
  };
  return project;
}

function deepMerge<T>(base: T, extra: unknown): T {
  if (typeof base !== "object" || base === null || Array.isArray(base)) {
    return (extra === undefined ? base : extra) as T;
  }
  if (typeof extra !== "object" || extra === null || Array.isArray(extra)) return base;
  const output: Record<string, unknown> = { ...(base as Record<string, unknown>) };
  for (const [key, value] of Object.entries(extra as Record<string, unknown>)) {
    if (key in output) output[key] = deepMerge(output[key], value);
  }
  return output as T;
}

export function aspectLabel(width: number, height: number): string {
  const ratio = width / height;
  if (Math.abs(ratio - 9 / 16) < 0.03) return "عمودي 9:16";
  if (Math.abs(ratio - 16 / 9) < 0.03) return "أفقي 16:9";
  if (Math.abs(ratio - 1) < 0.03) return "مربع 1:1";
  if (Math.abs(ratio - 4 / 5) < 0.03) return "عمودي 4:5";
  return `${width}×${height}`;
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) seconds = 0;
  const total = Math.round(seconds);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 ب";
  if (bytes < 1024) return `${bytes} ب`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} كب`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} مب`;
}

export function sanitizeFilename(name: string, fallback = "quiz-video"): string {
  const clean = name
    .trim()
    .replace(/[\\/:*?"<>|]+/g, "-")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^[.-]+|[.-]+$/g, "");
  return clean || fallback;
}

export function moveItem<T>(items: T[], from: number, to: number): T[] {
  if (to < 0 || to >= items.length || from < 0 || from >= items.length) return items;
  const copy = [...items];
  const [item] = copy.splice(from, 1);
  copy.splice(to, 0, item);
  return copy;
}
