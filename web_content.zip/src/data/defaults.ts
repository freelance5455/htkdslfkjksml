import type { AppData, ProjectSubmission, ContactMessage, UserAccount, ServiceProductItem, SupportTicket, VouchItem } from '../types/index.ts';

export interface StoredAccount extends UserAccount {
  passwordHash: string;
  salt: string;
}

export interface AdminStore extends AppData {
  contactMessages?: ContactMessage[];
  accounts?: StoredAccount[];
  serviceProducts?: ServiceProductItem[];
  supportTickets?: SupportTicket[];
  vouches?: VouchItem[];
  adminAuth: {
    email: string;
    id?: string;
    pass: string;
  };
}

export const defaultStore: AdminStore = {
  founders: [
    {
      id: 'f_1794072342788',
      name: 'Shantanu',
      role: 'FOUNDER · MANAGEMENT',
      bio: 'Leads the studio vision, client direction, management systems and overall Cubix Studio experience.',
      skills: 'Systems Architecture, Full-Stack, Cloud',
      avatar: '/cubix-logo.jpg',
      socialLinks: {
        github: '',
        discord: '',
        email: '',
        twitter: '',
        linkedin: ''
      },
      displayOrder: 1,
      published: true
    },
    {
      id: 'f-2',
      name: 'RealCubix',
      role: 'FOUNDER · CREATIVE',
      bio: 'Leads creative direction, portfolio work, digital experiences and project execution across the studio.',
      skills: 'Creative, Portfolio, Digital, Systems Design',
      avatar: '/cubix-logo.jpg',
      socialLinks: {
        email: 'real1cubix@gmail.com'
      },
      displayOrder: 2,
      published: true
    }
  ],
  projects: [
    {
      id: 101,
      name: 'Cubix Cloud Portal',
      category: 'web',
      description: 'Modern, responsive web platform engineered for real-time portfolio management, fast page loads, and mobile accessibility.',
      thumbnail: '',
      tags: ['React', 'TypeScript', 'Tailwind CSS', 'Node.js'],
      fileName: 'cubix-portal-source.zip',
      fileUrl: '/uploads/cubix-portal-source.zip',
      externalUrl: '',
      date: '2026-10-01',
      published: true,
      order: 1
    },
    {
      id: 102,
      name: 'Cyber Identity Brand System',
      category: 'design',
      description: 'Complete visual identity system including vector iconography, social media asset packs, responsive typography guidelines, and digital brand collateral.',
      thumbnail: '',
      tags: ['Brand Identity', 'Vector Design', 'Social Media', 'Typography'],
      fileName: 'brand-identity-guidelines.pdf',
      fileUrl: '/uploads/brand-identity-guidelines.pdf',
      externalUrl: '',
      date: '2026-09-24',
      published: true,
      order: 2
    },
    {
      id: 103,
      name: 'HyperCore Minecraft Server Suite',
      category: 'minecraft',
      description: 'Custom PaperMC/Purpur server plugin bundle featuring custom economy systems, low-latency packet routing, and multi-world data persistence.',
      thumbnail: '',
      tags: ['PaperMC', 'Java', 'Economy Systems', 'Server Optimization'],
      fileName: 'hypercore-plugin-v2.jar',
      fileUrl: '/uploads/hypercore-plugin-v2.jar',
      externalUrl: '',
      date: '2026-09-15',
      published: true,
      order: 3
    },
    {
      id: 104,
      name: 'Guardian Community Discord System',
      category: 'discord',
      description: 'High-availability Discord automation bot with automated client ticket desks, role synchronization, audit logging, and community verification.',
      thumbnail: '',
      tags: ['Discord.js', 'Node.js', 'Automation', 'Ticket Desk'],
      fileName: 'guardian-discord-bot.zip',
      fileUrl: '/uploads/guardian-discord-bot.zip',
      externalUrl: '',
      date: '2026-09-02',
      published: true,
      order: 4
    }
  ],
  financialRecords: [
    {
      id: 'fin-1',
      date: '2026-07-15',
      description: 'Client Web Platform Deployment',
      category: 'Web Development',
      amount: 95000,
      type: 'gain'
    },
    {
      id: 'fin-2',
      date: '2026-07-28',
      description: 'Cloud Server Infrastructure & Licenses',
      category: 'Hosting & Tools',
      amount: 15000,
      type: 'loss'
    },
    {
      id: 'fin-3',
      date: '2026-08-10',
      description: 'Minecraft Network Plugin Suite Commission',
      category: 'Minecraft Development',
      amount: 110000,
      type: 'gain'
    },
    {
      id: 'fin-4',
      date: '2026-08-25',
      description: 'Development Tools & Security Auditing',
      category: 'Operations',
      amount: 19000,
      type: 'loss'
    },
    {
      id: 'fin-5',
      date: '2026-09-12',
      description: 'Brand Identity Design Package',
      category: 'Graphic Design',
      amount: 142000,
      type: 'gain'
    },
    {
      id: 'fin-6',
      date: '2026-09-28',
      description: 'Asset Subscriptions & Cloud Storage',
      category: 'Infrastructure',
      amount: 28000,
      type: 'loss'
    },
    {
      id: 'fin-7',
      date: '2026-10-04',
      description: 'Enterprise Discord Bot Integration',
      category: 'Discord Solutions',
      amount: 185000,
      type: 'gain'
    },
    {
      id: 'fin-8',
      date: '2026-10-07',
      description: 'Hardware Upgrades & Testing Rigs',
      category: 'Equipment',
      amount: 32000,
      type: 'loss'
    }
  ],
  submissions: [
    {
      id: 'sub-1',
      submissionId: 'REQ-10492',
      name: 'Alex Rivera',
      email: 'alex.rivera@example.com',
      discord: 'alex_rivera#0001',
      projectType: 'Custom Discord Bot & Minecraft Mini-Game Sync',
      budget: '₹45,000 - ₹60,000',
      timeline: '3-4 Weeks',
      description: 'Looking to connect our custom Minecraft server player rankings with our Discord server roles, plus an automated ticket system for member support.',
      referenceLinks: 'https://example.com/brief',
      createdAt: '2026-10-08T12:30:00.000Z',
      status: 'In Progress',
      internalNotes: 'Brief reviewed. Architecture scope proposal shared with client.'
    }
  ],
  faqs: [
    {
      id: 'faq-1',
      question: 'What services does Cubix Studio offer?',
      answer: 'Cubix Studio specializes in four core areas: modern website development, graphic design and brand systems, custom Minecraft server plugins and systems, and Discord bot development and community automation.'
    },
    {
      id: 'faq-2',
      question: 'How do I start a project?',
      answer: 'Click the "Start a Project" button to access our project brief page. You can specify your project requirements, budget, timeline, and references using our straightforward submission form.'
    },
    {
      id: 'faq-3',
      question: 'Can I request a custom solution?',
      answer: 'Yes. Every project we undertake is custom-built to match your exact technical specifications, whether that is a specialized server plugin, a proprietary Discord bot, or a custom web application.'
    },
    {
      id: 'faq-4',
      question: 'How can I view previous projects?',
      answer: 'You can explore our Projects page organized into Website Development, Graphic Design, Minecraft Development, and Discord Solutions. Selected projects include descriptions, technology tags, and downloadable files.'
    },
    {
      id: 'faq-5',
      question: 'How do project updates and communication work?',
      answer: 'We provide structured milestones and direct developer communication through Discord and email. You receive regular status updates and preview demonstrations before final delivery.'
    }
  ],
  services: [
    {
      id: 'web',
      name: 'Website Development',
      category: 'web',
      iconName: 'Code2',
      description: 'Modern, responsive websites and custom web applications.',
      points: [
        'Modern, responsive websites.',
        'Custom web experiences and business websites.'
      ],
      displayOrder: 1,
      published: true
    },
    {
      id: 'design',
      name: 'Graphic Design',
      category: 'design',
      iconName: 'PenTool',
      description: 'Branding, graphics, vector icons, and social media assets.',
      points: [
        'Branding, graphics, social media assets.',
        'Creative design systems and visual collateral.'
      ],
      displayOrder: 2,
      published: true
    },
    {
      id: 'minecraft',
      name: 'Minecraft Development',
      category: 'minecraft',
      iconName: 'Box',
      description: 'Minecraft plugins, custom gameplay systems, and server networks.',
      points: [
        'Minecraft plugins and server systems.',
        'Custom architectures and player experiences.'
      ],
      displayOrder: 3,
      published: true
    },
    {
      id: 'discord',
      name: 'Discord Solutions',
      category: 'discord',
      iconName: 'MessageSquare',
      description: 'Discord bots, automations, and community infrastructure.',
      points: [
        'Discord bots and server automations.',
        'Setup services and community management tools.'
      ],
      displayOrder: 4,
      published: true
    }
  ],
  serviceProducts: [
    {
      id: 'sp-1',
      name: 'Custom Discord Bot Development',
      category: 'Discord Bot',
      type: 'service',
      description: 'Bespoke Discord bots engineered with slash commands, automated ticket workflows, real-time logging, security verification, and role synchronization.',
      badge: 'Core Service',
      points: [
        'Custom slash commands & interactive buttons',
        'Automated ticket dispatch and audit logging',
        'Role synchronization & security verification',
        'Fast 24/7 hosting deployment support'
      ],
      price: 'From ₹2,499',
      available: true,
      showInSelectionMenu: true,
      displayOrder: 1,
      iconName: 'Bot',
      createdAt: '2026-10-01'
    },
    {
      id: 'sp-2',
      name: 'Sentinel Bot Source Files & License',
      category: 'Bot Files',
      type: 'product',
      description: 'Production-ready modular Discord bot source files in TypeScript/Node.js with complete setup documentation, pre-configured moderation, and ticket modules.',
      badge: 'Digital Product',
      points: [
        'Complete TypeScript source code & clean architecture',
        'Pre-configured ticket & moderation commands',
        'Detailed step-by-step installation guide',
        'Commercial single-server license'
      ],
      price: '₹1,499',
      available: true,
      showInSelectionMenu: true,
      displayOrder: 2,
      iconName: 'FileCode',
      createdAt: '2026-10-01'
    },
    {
      id: 'sp-3',
      name: 'Full-Stack Web Development',
      category: 'Web Development',
      type: 'service',
      description: 'Modern, high-performance responsive web applications, studio portals, and client dashboards built with modern React, Tailwind, and Node.js APIs.',
      badge: 'Popular',
      points: [
        'Modern responsive UI with dark aesthetics',
        'Full-stack Express/API backend integration',
        'Admin control center & database synchronization',
        'SEO optimization & custom domain deployment'
      ],
      price: 'From ₹9,999',
      available: true,
      showInSelectionMenu: true,
      displayOrder: 3,
      iconName: 'Globe',
      createdAt: '2026-10-01'
    },
    {
      id: 'sp-4',
      name: 'Discord Community Server Architecture',
      category: 'Discord Services',
      type: 'service',
      description: 'Professional Discord server design, channel structures, security bot integrations, custom role hierarchies, and automated welcome flows.',
      badge: 'Discord',
      points: [
        'Optimized channel hierarchy & permission audits',
        'Auto-moderation & anti-raid security setup',
        'Custom server icons, banners & embed styling',
        'Ticket desk & member onboarding flow'
      ],
      price: 'From ₹1,999',
      available: true,
      showInSelectionMenu: true,
      displayOrder: 4,
      iconName: 'MessageSquare',
      createdAt: '2026-10-01'
    },
    {
      id: 'sp-5',
      name: 'Custom Coding & Automation Scripts',
      category: 'Coding',
      type: 'service',
      description: 'Tailored backend scripts, automation bots, REST API webhooks, packet listeners, and custom software utilities built to exact technical specifications.',
      badge: 'Custom Code',
      points: [
        'Automated data pipelines & webhook listeners',
        'Node.js, TypeScript, & Python script development',
        'Bug fixing, refactoring, & performance tuning',
        'Full source code ownership upon delivery'
      ],
      price: 'Custom Quote',
      available: true,
      showInSelectionMenu: true,
      displayOrder: 5,
      iconName: 'Terminal',
      createdAt: '2026-10-01'
    },
    {
      id: 'sp-6',
      name: 'Graphic Design & Vector Brand Identity',
      category: 'Graphic Design',
      type: 'service',
      description: 'Cyberpunk and modern vector brand identity, typography systems, vector emblems, custom banners, social media kits, and UI collateral.',
      badge: 'Creative',
      points: [
        'Vector emblem & primary logo creation',
        'Discord banners, headers & role icons',
        'Social media templates & typography guidelines',
        'High-resolution vector SVG/PNG deliverables'
      ],
      price: 'From ₹2,999',
      available: true,
      showInSelectionMenu: true,
      displayOrder: 6,
      iconName: 'Palette',
      createdAt: '2026-10-01'
    },
    {
      id: 'sp-7',
      name: 'Cyber Vector UI & Asset Pack',
      category: 'Digital Products',
      type: 'product',
      description: 'Downloadable digital UI components, glowing badges, vector shields, and dark-mode graphic assets designed specifically for gaming and community hubs.',
      badge: 'Instant Download',
      points: [
        '50+ vector gaming & community assets',
        'High-resolution PNGs and master SVG files',
        'Commercial use license included',
        'Instant delivery upon order confirmation'
      ],
      price: '₹999',
      available: true,
      showInSelectionMenu: true,
      displayOrder: 7,
      iconName: 'Box',
      createdAt: '2026-10-01'
    },
    {
      id: 'sp-8',
      name: 'Custom Minecraft Server Systems',
      category: 'Custom Solutions',
      type: 'service',
      description: 'Custom PaperMC/Purpur server plugins, packet routing, advanced in-game economies, mini-game systems, and anti-cheat configurations.',
      badge: 'Enterprise',
      points: [
        'High-performance PaperMC/Velocity plugin development',
        'Custom economy, leveling, & game mechanics',
        'Low-latency networking & database sync',
        'Anti-exploit audits & server optimization'
      ],
      price: 'Custom Quote',
      available: true,
      showInSelectionMenu: true,
      displayOrder: 8,
      iconName: 'Layers',
      createdAt: '2026-10-01'
    }
  ],
  supportTickets: [
    {
      id: 'tkt_init_0001',
      ticketNumber: 'CUBIX-0001',
      clientToken: 'ct_demo_client_token_0001_cubix',
      verificationPin: '492815',
      email: 'client@example.com',
      username: 'AlexK',
      discordId: '829102938472910291',
      serviceProductId: 'sp-1',
      serviceProductName: 'Custom Discord Bot Development',
      requestDetails: 'Need a custom Discord community bot with automated ticket dispatch, role syncing, and transaction webhooks supporting our 5,000+ member community.',
      attachments: [],
      status: 'In Progress',
      internalNotes: 'Client verified on Discord. Architecture draft shared with lead developer.',
      conversation: [
        {
          id: 'msg-init-1',
          sender: 'client',
          senderName: 'AlexK',
          message: 'Hello Cubix Studio team! We are looking to build a custom Discord community bot with automated tickets and role sync.',
          createdAt: '2026-10-10T11:20:00.000Z'
        },
        {
          id: 'msg-init-2',
          sender: 'admin',
          senderName: 'Cubix Support',
          message: 'Welcome to Cubix Studio, Alex! We have reviewed your request. Our developers are preparing the module specs and milestone breakdown. We will update you here shortly.',
          createdAt: '2026-10-10T12:05:00.000Z'
        }
      ],
      createdAt: '2026-10-10T11:20:00.000Z',
      updatedAt: '2026-10-10T12:05:00.000Z',
      statusHistory: [
        {
          status: 'Open',
          changedBy: 'System',
          changedAt: '2026-10-10T11:20:00.000Z',
          note: 'Ticket created by client'
        },
        {
          status: 'In Progress',
          changedBy: 'Oscar Cruz (Admin)',
          changedAt: '2026-10-10T12:05:00.000Z',
          note: 'Assigned to development queue'
        }
      ],
      emailNotificationStatus: {
        creationEmailSent: true,
        lastSentAt: '2026-10-10T11:20:05.000Z'
      }
    }
  ],
  settings: {
    siteTitle: 'Cubix Studio — Digital Development & Creative Studio',
    heroHeadline: 'Turning Ideas Into Digital Experiences.',
    heroDescription: 'Cubix Studio builds modern websites, custom digital solutions, and creative experiences that help brands and communities grow.',
    heroSubtitle: 'Cubix Studio builds modern websites, custom digital solutions, and creative experiences that help brands and communities grow.',
    heroBadge: 'CUBIX STUDIO • DIGITAL DEVELOPMENT & CREATIVE SOLUTIONS',
    heroPrimaryBtnText: 'Start a Project',
    heroSecondaryBtnText: 'Meet the Founders',
    aboutHeading: 'About Cubix Studio',
    aboutStatement: 'Building Digital Experiences With Purpose.',
    aboutDescription: 'Cubix Studio brings development, design, and creative problem-solving together to build meaningful digital experiences. From websites and custom software to Discord systems and Minecraft development, we turn ideas into practical, well-crafted solutions.',
    aboutCards: {
      mission: 'To turn ideas into reliable, useful, and thoughtfully designed digital experiences.',
      approach: 'Combining technical precision, creative thinking, and clear communication to deliver work that fits each project\'s needs.',
      whatWeBuild: 'Websites, graphic design, Discord solutions, Minecraft development, and custom digital projects.'
    },
    servicesEyebrow: 'OUR PROJECTS',
    servicesHeading: 'Four Ways to Build. One Cubix Studio.',
    servicesDescription: 'Choose a category to explore the work behind Cubix Studio. Each card opens a dedicated projects page where the portfolio can grow over time.',
    contactEmail: 'real1cubix@gmail.com',
    contactDescription: 'Have a project in mind or need technical consultation? Reach out directly or start a project brief with our team.',
    discordUrl: 'https://discord.gg/cubixstudio',
    ticketDiscordUrl: 'https://discord.gg/cubixstudio',
    logoUrl: '/cubix-logo.jpg',
    location: 'Gurgaon, Haryana, India',
    sectionVisibility: {
      hero: true,
      reputation: true,
      about: true,
      services: true,
      faq: true,
      contact: true,
      gallery: true
    },
    heroBackground: {
      imageUrl: '/b90c9408e77c5a808a0f1adfab828f1b.jpg',
      position: 'top center',
      size: 'cover',
      repeat: 'no-repeat',
      blur: 0,
      overlayOpacity: 80,
      solidColor: '#06101e'
    }
  },
  gallery: [
    {
      id: 'gal-1',
      title: 'Cubix Cloud Studio Dashboard',
      category: 'web',
      imageUrl: '/cubix-logo.jpg',
      caption: 'High-speed administrative control system with real-time synchronization and database telemetry.',
      displayOrder: 1,
      published: true,
      createdAt: '2026-03-15'
    },
    {
      id: 'gal-2',
      title: 'Neon Brand Identity & Typography',
      category: 'design',
      imageUrl: '/cubix-logo.jpg',
      caption: 'Complete brand guide, vector icon sets, and social assets crafted for dark mode interfaces.',
      displayOrder: 2,
      published: true,
      createdAt: '2026-03-20'
    },
    {
      id: 'gal-3',
      title: 'Hyperscale Minecraft Network Core',
      category: 'minecraft',
      imageUrl: '/cubix-logo.jpg',
      caption: 'Distributed multiplayer lobby architecture with custom Paper/Velocity integration.',
      displayOrder: 3,
      published: true,
      createdAt: '2026-03-28'
    },
    {
      id: 'gal-4',
      title: 'Sentinel Discord Bot Infrastructure',
      category: 'discord',
      imageUrl: '/cubix-logo.jpg',
      caption: 'Automated ticket dispatch, role syncing, and transaction webhooks supporting 10k+ members.',
      displayOrder: 4,
      published: true,
      createdAt: '2026-04-02'
    }
  ],
  reputationData: {
    stats: {
      tabKey: 'stats',
      title: 'Cubix Reputation — Stats',
      badge: 'DELIVERY RECORD',
      highlight: 'Continuous Project Delivery & Active Client Maintenance',
      description: 'Dedicated digital solutions deployed with verifiable code quality, active milestones, and long-term technical reliability.'
    },
    works: {
      tabKey: 'works',
      title: 'Cubix Reputation — Works',
      badge: 'PORTFOLIO',
      highlight: 'Full-Stack Web, Discord Automation & Minecraft Systems',
      description: 'From modern responsive web applications to high-performance game servers, our work is engineered for production stability.'
    },
    trust: {
      tabKey: 'trust',
      title: 'Cubix Reputation — Trust',
      badge: 'VERIFIED',
      highlight: 'Direct Developer Communication & Scope Transparency',
      description: 'Transparent timelines, clear architectural documentation, and structured delivery without hidden complexities.'
    },
    rating: {
      tabKey: 'rating',
      title: 'Cubix Reputation — Rating',
      badge: 'CLIENT VOICE',
      highlight: 'Consistent Quality & End-to-End Client Satisfaction',
      description: 'Client-focused partnerships with post-delivery technical support and dependable project execution.'
    }
  },
  aiAssistant: {
    enabled: true,
    assistantName: 'Cubix AI Assistant',
    sectionTitle: 'Cubix AI Assistant',
    sectionDescription: 'Get instant answers about Cubix Studio services, project timelines, and custom development—or open a direct priority channel with our Founders.',
    buttonText: 'Open AI Assistant',
    sectionHeading: 'Cubix Studio AI Assistant',
    sectionSubtitle: 'Ask questions about our services, portfolio, project scoping, or connect directly with the founders through your dedicated client workspace.',
    welcomeMessage: 'Hello! Welcome to Cubix Studio. I can help you explore our web development, Minecraft systems, Discord bots, and design services, or connect you directly with our founders.',
    systemPrompt: 'You are the official AI Assistant for Cubix Studio. Help visitors learn about Cubix Studio services (Web Development, Graphic Design & Branding, Minecraft Server Plugins & Systems, and Discord Bots & Community Automation), explain how to start a project, answer general questions clearly and concisely, and let them know they can click "Talk With Founders" anytime to submit a direct support ticket to the founders.',
    systemInstructions: 'You are the official AI Assistant for Cubix Studio. Help visitors learn about Cubix Studio services (Web Development, Graphic Design & Branding, Minecraft Server Plugins & Systems, and Discord Bots & Community Automation), explain how to start a project, answer general questions clearly and concisely, and let them know they can click "Talk With Founders" anytime to submit a direct support ticket to the founders.',
    quickPrompts: [
      'What services does Cubix Studio offer?',
      'How do I start a custom project?',
      'Tell me about your Minecraft & Discord development',
      'How can I speak directly with the founders?'
    ]
  },
  vouches: [],
  adminAuth: {
    email: 'admin@cubix.std',
    id: 'admin@cubix.std',
    pass: ''
  },
  lastUpdated: '1970-01-01T00:00:00.000Z'
};
