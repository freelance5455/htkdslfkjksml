import { Project, Track, Clip, Note, DrumStep } from '../types/daw';

export const DEMO_PROJECTS: Project[] = [
  // 1. FL Trap Anthem (140 BPM)
  {
    id: 'demo_trap',
    name: 'FL Metro Trap',
    bpm: 140,
    timeSignature: [4, 4],
    swing: 10,
    masterVolume: 0.85,
    loopStart: 0,
    loopEnd: 16,
    isLooping: true,
    tracks: [
      {
        id: 'track_trap_drums',
        name: 'Trap Drum Rack',
        type: 'drums',
        color: '#ff7700', // FL orange
        volume: 0.9,
        pan: 0,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'sine',
          osc2Type: 'sine',
          detune: 0,
          osc2Mix: 0,
          filterCutoff: 10000,
          filterRes: 1,
          filterType: 'lowpass',
          attack: 0.01,
          decay: 0.2,
          sustain: 0.2,
          release: 0.1,
          glide: 0,
        },
        fx: {
          eqLow: 3.5,
          eqMid: 0,
          eqHigh: 2.0,
          delayTime: 0.21,
          delayFeedback: 0.2,
          delayMix: 0.05,
          reverbDecay: 1.5,
          reverbMix: 0.12,
          distortionDrive: 2.5,
          distortionMix: 0.2,
        },
        clips: [
          {
            id: 'clip_trap_d1',
            trackId: 'track_trap_drums',
            name: '808 Trap Beat A',
            startBeat: 0,
            durationBeats: 4,
            color: '#ff7700',
            drumSteps: [
              // Kick
              { step: 0, drum: 'kick', velocity: 1.0 },
              { step: 6, drum: 'kick', velocity: 0.9 },
              { step: 10, drum: 'kick', velocity: 0.95 },
              // Snare & Clap
              { step: 4, drum: 'snare', velocity: 0.9 },
              { step: 12, drum: 'snare', velocity: 1.0 },
              { step: 12, drum: 'clap', velocity: 0.8 },
              // Rolling Hats
              { step: 0, drum: 'hihat_closed', velocity: 0.8 },
              { step: 1, drum: 'hihat_closed', velocity: 0.6 },
              { step: 2, drum: 'hihat_closed', velocity: 0.8 },
              { step: 3, drum: 'hihat_closed', velocity: 0.5 },
              { step: 4, drum: 'hihat_closed', velocity: 0.75 },
              { step: 5, drum: 'hihat_closed', velocity: 0.6 },
              { step: 6, drum: 'hihat_closed', velocity: 0.8 },
              { step: 7, drum: 'hihat_closed', velocity: 0.55 },
              { step: 8, drum: 'hihat_closed', velocity: 0.8 },
              { step: 9, drum: 'hihat_closed', velocity: 0.6 },
              { step: 10, drum: 'hihat_closed', velocity: 0.8 },
              { step: 11, drum: 'hihat_closed', velocity: 0.65 },
              { step: 12, drum: 'hihat_closed', velocity: 0.8 },
              { step: 13, drum: 'hihat_closed', velocity: 0.5 },
              { step: 14, drum: 'hihat_closed', velocity: 0.85 },
              { step: 15, drum: 'hihat_closed', velocity: 0.6 },
              // Open hat
              { step: 2, drum: 'hihat_open', velocity: 0.7 },
              { step: 10, drum: 'hihat_open', velocity: 0.7 },
              // Perc
              { step: 15, drum: 'perc', velocity: 0.6 },
            ],
          },
          {
            id: 'clip_trap_d2',
            trackId: 'track_trap_drums',
            name: '808 Trap Beat B',
            startBeat: 4,
            durationBeats: 4,
            color: '#ff7700',
            drumSteps: [
              { step: 0, drum: 'kick', velocity: 1.0 },
              { step: 4, drum: 'snare', velocity: 0.9 },
              { step: 7, drum: 'kick', velocity: 0.9 },
              { step: 10, drum: 'kick', velocity: 0.95 },
              { step: 12, drum: 'snare', velocity: 1.0 },
              { step: 12, drum: 'clap', velocity: 0.85 },
              { step: 14, drum: 'kick', velocity: 0.85 },
              // Hats
              { step: 0, drum: 'hihat_closed', velocity: 0.8 },
              { step: 1, drum: 'hihat_closed', velocity: 0.6 },
              { step: 2, drum: 'hihat_closed', velocity: 0.85 },
              { step: 3, drum: 'hihat_closed', velocity: 0.5 },
              { step: 4, drum: 'hihat_closed', velocity: 0.75 },
              { step: 5, drum: 'hihat_closed', velocity: 0.6 },
              { step: 6, drum: 'hihat_closed', velocity: 0.8 },
              { step: 7, drum: 'hihat_closed', velocity: 0.55 },
              { step: 8, drum: 'hihat_closed', velocity: 0.8 },
              { step: 9, drum: 'hihat_closed', velocity: 0.6 },
              { step: 10, drum: 'hihat_closed', velocity: 0.8 },
              { step: 11, drum: 'hihat_closed', velocity: 0.65 },
              { step: 12, drum: 'hihat_closed', velocity: 0.8 },
              { step: 13, drum: 'hihat_closed', velocity: 0.5 },
              { step: 14, drum: 'hihat_closed', velocity: 0.9 },
              { step: 15, drum: 'hihat_closed', velocity: 0.7 },
              { step: 6, drum: 'cowbell', velocity: 0.65 },
            ],
          },
          {
            id: 'clip_trap_d3',
            trackId: 'track_trap_drums',
            name: '808 Trap Beat A',
            startBeat: 8,
            durationBeats: 4,
            color: '#ff7700',
            drumSteps: [
              { step: 0, drum: 'kick', velocity: 1.0 },
              { step: 6, drum: 'kick', velocity: 0.9 },
              { step: 10, drum: 'kick', velocity: 0.95 },
              { step: 4, drum: 'snare', velocity: 0.9 },
              { step: 12, drum: 'snare', velocity: 1.0 },
              { step: 12, drum: 'clap', velocity: 0.8 },
              { step: 0, drum: 'hihat_closed', velocity: 0.8 },
              { step: 2, drum: 'hihat_closed', velocity: 0.8 },
              { step: 4, drum: 'hihat_closed', velocity: 0.8 },
              { step: 6, drum: 'hihat_closed', velocity: 0.8 },
              { step: 8, drum: 'hihat_closed', velocity: 0.8 },
              { step: 10, drum: 'hihat_closed', velocity: 0.8 },
              { step: 12, drum: 'hihat_closed', velocity: 0.8 },
              { step: 14, drum: 'hihat_closed', velocity: 0.8 },
            ],
          },
          {
            id: 'clip_trap_d4',
            trackId: 'track_trap_drums',
            name: '808 Trap Beat Fill',
            startBeat: 12,
            durationBeats: 4,
            color: '#ff7700',
            drumSteps: [
              { step: 0, drum: 'kick', velocity: 1.0 },
              { step: 4, drum: 'snare', velocity: 0.9 },
              { step: 8, drum: 'kick', velocity: 0.9 },
              { step: 10, drum: 'snare', velocity: 0.7 },
              { step: 11, drum: 'snare', velocity: 0.8 },
              { step: 12, drum: 'snare', velocity: 0.95 },
              { step: 14, drum: 'snare', velocity: 0.85 },
              { step: 15, drum: 'perc', velocity: 0.9 },
            ],
          },
        ],
      },
      {
        id: 'track_trap_bell',
        name: 'Dark Bell Lead',
        type: 'keys',
        color: '#00e5ff', // Cyan
        volume: 0.8,
        pan: -0.15,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'sine',
          osc2Type: 'triangle',
          detune: 7,
          osc2Mix: 0.45,
          filterCutoff: 3800,
          filterRes: 4.5,
          filterType: 'lowpass',
          attack: 0.008,
          decay: 0.65,
          sustain: 0.1,
          release: 0.45,
          glide: 0.02,
        },
        fx: {
          eqLow: -4.0,
          eqMid: 1.5,
          eqHigh: 4.0,
          delayTime: 0.32,
          delayFeedback: 0.45,
          delayMix: 0.35,
          reverbDecay: 2.8,
          reverbMix: 0.4,
          distortionDrive: 1.2,
          distortionMix: 0.15,
        },
        clips: [
          {
            id: 'clip_bell_1',
            trackId: 'track_trap_bell',
            name: 'Sinister Bell Melody',
            startBeat: 0,
            durationBeats: 8,
            color: '#00e5ff',
            notes: [
              { id: 'b1', pitch: 72, startBeat: 0.0, durationBeats: 0.75, velocity: 0.9 }, // C5
              { id: 'b2', pitch: 75, startBeat: 1.0, durationBeats: 0.5, velocity: 0.85 }, // Eb5
              { id: 'b3', pitch: 74, startBeat: 2.0, durationBeats: 0.75, velocity: 0.88 }, // D5
              { id: 'b4', pitch: 67, startBeat: 3.0, durationBeats: 0.75, velocity: 0.75 }, // G4
              { id: 'b5', pitch: 70, startBeat: 4.0, durationBeats: 0.75, velocity: 0.85 }, // Bb4
              { id: 'b6', pitch: 68, startBeat: 5.0, durationBeats: 0.5, velocity: 0.8 }, // Ab4
              { id: 'b7', pitch: 67, startBeat: 6.0, durationBeats: 1.5, velocity: 0.85 }, // G4
            ],
          },
          {
            id: 'clip_bell_2',
            trackId: 'track_trap_bell',
            name: 'Sinister Bell Melody 2',
            startBeat: 8,
            durationBeats: 8,
            color: '#00e5ff',
            notes: [
              { id: 'b8', pitch: 72, startBeat: 0.0, durationBeats: 0.75, velocity: 0.9 }, // C5
              { id: 'b9', pitch: 75, startBeat: 1.0, durationBeats: 0.5, velocity: 0.85 }, // Eb5
              { id: 'b10', pitch: 77, startBeat: 2.0, durationBeats: 0.75, velocity: 0.9 }, // F5
              { id: 'b11', pitch: 75, startBeat: 3.0, durationBeats: 0.5, velocity: 0.8 }, // Eb5
              { id: 'b12', pitch: 74, startBeat: 4.0, durationBeats: 0.75, velocity: 0.85 }, // D5
              { id: 'b13', pitch: 70, startBeat: 5.0, durationBeats: 0.5, velocity: 0.8 }, // Bb4
              { id: 'b14', pitch: 72, startBeat: 6.0, durationBeats: 1.75, velocity: 0.95 }, // C5
            ],
          },
        ],
      },
      {
        id: 'track_trap_808',
        name: 'Tuned 808 Bass',
        type: 'bass',
        color: '#e040fb', // Magenta
        volume: 0.95,
        pan: 0,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'sine',
          osc2Type: 'sine',
          detune: 0,
          osc2Mix: 0.1,
          filterCutoff: 1800,
          filterRes: 2.0,
          filterType: 'lowpass',
          attack: 0.015,
          decay: 0.8,
          sustain: 0.65,
          release: 0.25,
          glide: 0.08,
        },
        fx: {
          eqLow: 5.0,
          eqMid: -2.0,
          eqHigh: -6.0,
          delayTime: 0.2,
          delayFeedback: 0,
          delayMix: 0,
          reverbDecay: 1.0,
          reverbMix: 0,
          distortionDrive: 3.2,
          distortionMix: 0.35,
        },
        clips: [
          {
            id: 'clip_808_1',
            trackId: 'track_trap_808',
            name: '808 Sub Line A',
            startBeat: 0,
            durationBeats: 8,
            color: '#e040fb',
            notes: [
              { id: 's1', pitch: 36, startBeat: 0.0, durationBeats: 2.5, velocity: 1.0 }, // C2
              { id: 's2', pitch: 36, startBeat: 3.0, durationBeats: 0.75, velocity: 0.9 }, // C2
              { id: 's3', pitch: 39, startBeat: 4.0, durationBeats: 1.75, velocity: 0.95 }, // Eb2
              { id: 's4', pitch: 41, startBeat: 6.0, durationBeats: 1.75, velocity: 0.95 }, // F2
            ],
          },
          {
            id: 'clip_808_2',
            trackId: 'track_trap_808',
            name: '808 Sub Line B',
            startBeat: 8,
            durationBeats: 8,
            color: '#e040fb',
            notes: [
              { id: 's5', pitch: 36, startBeat: 0.0, durationBeats: 2.5, velocity: 1.0 }, // C2
              { id: 's6', pitch: 43, startBeat: 3.0, durationBeats: 0.75, velocity: 0.9 }, // G2
              { id: 's7', pitch: 41, startBeat: 4.0, durationBeats: 1.75, velocity: 0.95 }, // F2
              { id: 's8', pitch: 39, startBeat: 6.0, durationBeats: 1.75, velocity: 0.95 }, // Eb2
            ],
          },
        ],
      },
      {
        id: 'track_trap_pad',
        name: 'Dark Atmosphere',
        type: 'synth',
        color: '#651fff', // Deep Purple
        volume: 0.65,
        pan: 0.2,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'sawtooth',
          osc2Type: 'sawtooth',
          detune: 14,
          osc2Mix: 0.5,
          filterCutoff: 1200,
          filterRes: 2.2,
          filterType: 'lowpass',
          attack: 0.35,
          decay: 0.8,
          sustain: 0.7,
          release: 0.9,
          glide: 0,
        },
        fx: {
          eqLow: -3.0,
          eqMid: 1.0,
          eqHigh: 2.0,
          delayTime: 0.42,
          delayFeedback: 0.4,
          delayMix: 0.3,
          reverbDecay: 3.5,
          reverbMix: 0.45,
          distortionDrive: 0.5,
          distortionMix: 0.05,
        },
        clips: [
          {
            id: 'clip_pad_1',
            trackId: 'track_trap_pad',
            name: 'Trap Pad Chords',
            startBeat: 0,
            durationBeats: 16,
            color: '#651fff',
            notes: [
              // C minor (C4, Eb4, G4)
              { id: 'p1', pitch: 60, startBeat: 0, durationBeats: 3.8, velocity: 0.7 },
              { id: 'p2', pitch: 63, startBeat: 0, durationBeats: 3.8, velocity: 0.7 },
              { id: 'p3', pitch: 67, startBeat: 0, durationBeats: 3.8, velocity: 0.7 },

              // Ab major (Ab3, C4, Eb4)
              { id: 'p4', pitch: 56, startBeat: 4, durationBeats: 3.8, velocity: 0.7 },
              { id: 'p5', pitch: 60, startBeat: 4, durationBeats: 3.8, velocity: 0.7 },
              { id: 'p6', pitch: 63, startBeat: 4, durationBeats: 3.8, velocity: 0.7 },

              // F minor (F3, Ab3, C4)
              { id: 'p7', pitch: 53, startBeat: 8, durationBeats: 3.8, velocity: 0.7 },
              { id: 'p8', pitch: 56, startBeat: 8, durationBeats: 3.8, velocity: 0.7 },
              { id: 'p9', pitch: 60, startBeat: 8, durationBeats: 3.8, velocity: 0.7 },

              // G minor (G3, Bb3, D4)
              { id: 'p10', pitch: 55, startBeat: 12, durationBeats: 3.8, velocity: 0.7 },
              { id: 'p11', pitch: 58, startBeat: 12, durationBeats: 3.8, velocity: 0.7 },
              { id: 'p12', pitch: 62, startBeat: 12, durationBeats: 3.8, velocity: 0.7 },
            ],
          },
        ],
      },
    ],
  },

  // 2. Retro Cyberwave (124 BPM)
  {
    id: 'demo_synthwave',
    name: 'Cyber Synthwave',
    bpm: 124,
    timeSignature: [4, 4],
    swing: 0,
    masterVolume: 0.88,
    loopStart: 0,
    loopEnd: 16,
    isLooping: true,
    tracks: [
      {
        id: 'track_sw_drums',
        name: '80s Drum Machine',
        type: 'drums',
        color: '#ff007f', // Cyber Pink
        volume: 0.9,
        pan: 0,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'triangle',
          osc2Type: 'sine',
          detune: 0,
          osc2Mix: 0,
          filterCutoff: 9000,
          filterRes: 1,
          filterType: 'lowpass',
          attack: 0.01,
          decay: 0.2,
          sustain: 0.1,
          release: 0.1,
          glide: 0,
        },
        fx: {
          eqLow: 3.0,
          eqMid: 1.0,
          eqHigh: 3.0,
          delayTime: 0.24,
          delayFeedback: 0.2,
          delayMix: 0.1,
          reverbDecay: 2.2,
          reverbMix: 0.25,
          distortionDrive: 2.0,
          distortionMix: 0.18,
        },
        clips: [
          {
            id: 'clip_sw_d1',
            trackId: 'track_sw_drums',
            name: 'Retro 80s Beat',
            startBeat: 0,
            durationBeats: 16,
            color: '#ff007f',
            drumSteps: [
              // 4-on-the-floor kick
              { step: 0, drum: 'kick', velocity: 1.0 },
              { step: 4, drum: 'kick', velocity: 0.95 },
              { step: 8, drum: 'kick', velocity: 1.0 },
              { step: 12, drum: 'kick', velocity: 0.95 },
              // Gated snare on 2 and 4
              { step: 4, drum: 'snare', velocity: 1.0 },
              { step: 12, drum: 'snare', velocity: 1.0 },
              // 8th-note hats
              { step: 0, drum: 'hihat_closed', velocity: 0.7 },
              { step: 2, drum: 'hihat_closed', velocity: 0.8 },
              { step: 4, drum: 'hihat_closed', velocity: 0.7 },
              { step: 6, drum: 'hihat_closed', velocity: 0.8 },
              { step: 8, drum: 'hihat_closed', velocity: 0.7 },
              { step: 10, drum: 'hihat_closed', velocity: 0.85 },
              { step: 12, drum: 'hihat_closed', velocity: 0.7 },
              { step: 14, drum: 'hihat_closed', velocity: 0.8 },
              // Open Hat on offbeats
              { step: 2, drum: 'hihat_open', velocity: 0.65 },
              { step: 10, drum: 'hihat_open', velocity: 0.65 },
              { step: 15, drum: 'perc', velocity: 0.75 },
            ],
          },
        ],
      },
      {
        id: 'track_sw_bass',
        name: 'Rolling Saw Bass',
        type: 'bass',
        color: '#00e5ff',
        volume: 0.85,
        pan: 0,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'sawtooth',
          osc2Type: 'square',
          detune: 8,
          osc2Mix: 0.35,
          filterCutoff: 1600,
          filterRes: 3.5,
          filterType: 'lowpass',
          attack: 0.005,
          decay: 0.2,
          sustain: 0.4,
          release: 0.15,
          glide: 0.02,
        },
        fx: {
          eqLow: 4.0,
          eqMid: -1.0,
          eqHigh: 1.0,
          delayTime: 0.24,
          delayFeedback: 0.1,
          delayMix: 0.05,
          reverbDecay: 1.2,
          reverbMix: 0.1,
          distortionDrive: 3.5,
          distortionMix: 0.3,
        },
        clips: [
          {
            id: 'clip_sw_b1',
            trackId: 'track_sw_bass',
            name: '16th Saw Bassline',
            startBeat: 0,
            durationBeats: 8,
            color: '#00e5ff',
            notes: [
              // D2 rolling
              { id: 'nb1', pitch: 38, startBeat: 0.0, durationBeats: 0.45, velocity: 0.9 },
              { id: 'nb2', pitch: 38, startBeat: 0.5, durationBeats: 0.45, velocity: 0.7 },
              { id: 'nb3', pitch: 38, startBeat: 1.0, durationBeats: 0.45, velocity: 0.9 },
              { id: 'nb4', pitch: 38, startBeat: 1.5, durationBeats: 0.45, velocity: 0.75 },
              { id: 'nb5', pitch: 38, startBeat: 2.0, durationBeats: 0.45, velocity: 0.9 },
              { id: 'nb6', pitch: 38, startBeat: 2.5, durationBeats: 0.45, velocity: 0.7 },
              { id: 'nb7', pitch: 41, startBeat: 3.0, durationBeats: 0.45, velocity: 0.85 }, // F2
              { id: 'nb8', pitch: 43, startBeat: 3.5, durationBeats: 0.45, velocity: 0.9 }, // G2

              // Bb1 rolling
              { id: 'nb9', pitch: 34, startBeat: 4.0, durationBeats: 0.45, velocity: 0.9 },
              { id: 'nb10', pitch: 34, startBeat: 4.5, durationBeats: 0.45, velocity: 0.7 },
              { id: 'nb11', pitch: 34, startBeat: 5.0, durationBeats: 0.45, velocity: 0.9 },
              { id: 'nb12', pitch: 34, startBeat: 5.5, durationBeats: 0.45, velocity: 0.75 },
              // C2 rolling
              { id: 'nb13', pitch: 36, startBeat: 6.0, durationBeats: 0.45, velocity: 0.9 },
              { id: 'nb14', pitch: 36, startBeat: 6.5, durationBeats: 0.45, velocity: 0.7 },
              { id: 'nb15', pitch: 36, startBeat: 7.0, durationBeats: 0.45, velocity: 0.9 },
              { id: 'nb16', pitch: 36, startBeat: 7.5, durationBeats: 0.45, velocity: 0.8 },
            ],
          },
        ],
      },
      {
        id: 'track_sw_lead',
        name: 'Cyberpunk Lead',
        type: 'synth',
        color: '#ffea00',
        volume: 0.78,
        pan: 0.1,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'sawtooth',
          osc2Type: 'sawtooth',
          detune: 12,
          osc2Mix: 0.5,
          filterCutoff: 4200,
          filterRes: 3.0,
          filterType: 'lowpass',
          attack: 0.02,
          decay: 0.4,
          sustain: 0.5,
          release: 0.3,
          glide: 0.04,
        },
        fx: {
          eqLow: -2.0,
          eqMid: 2.0,
          eqHigh: 4.0,
          delayTime: 0.24,
          delayFeedback: 0.4,
          delayMix: 0.35,
          reverbDecay: 2.5,
          reverbMix: 0.3,
          distortionDrive: 2.2,
          distortionMix: 0.25,
        },
        clips: [
          {
            id: 'clip_sw_l1',
            trackId: 'track_sw_lead',
            name: 'Neon Arp Lead',
            startBeat: 0,
            durationBeats: 8,
            color: '#ffea00',
            notes: [
              { id: 'sl1', pitch: 62, startBeat: 0.0, durationBeats: 0.4, velocity: 0.85 }, // D4
              { id: 'sl2', pitch: 65, startBeat: 0.5, durationBeats: 0.4, velocity: 0.8 }, // F4
              { id: 'sl3', pitch: 69, startBeat: 1.0, durationBeats: 0.4, velocity: 0.9 }, // A4
              { id: 'sl4', pitch: 74, startBeat: 1.5, durationBeats: 0.8, velocity: 0.95 }, // D5
              { id: 'sl5', pitch: 72, startBeat: 2.5, durationBeats: 0.4, velocity: 0.85 }, // C5
              { id: 'sl6', pitch: 69, startBeat: 3.0, durationBeats: 0.8, velocity: 0.85 }, // A4

              { id: 'sl7', pitch: 70, startBeat: 4.0, durationBeats: 0.4, velocity: 0.85 }, // Bb4
              { id: 'sl8', pitch: 69, startBeat: 4.5, durationBeats: 0.4, velocity: 0.8 }, // A4
              { id: 'sl9', pitch: 65, startBeat: 5.0, durationBeats: 0.8, velocity: 0.85 }, // F4
              { id: 'sl10', pitch: 67, startBeat: 6.0, durationBeats: 0.4, velocity: 0.85 }, // G4
              { id: 'sl11', pitch: 65, startBeat: 6.5, durationBeats: 0.4, velocity: 0.8 }, // F4
              { id: 'sl12', pitch: 62, startBeat: 7.0, durationBeats: 0.9, velocity: 0.9 }, // D4
            ],
          },
        ],
      },
    ],
  },

  // 3. Chill Lo-Fi Sunset (86 BPM)
  {
    id: 'demo_lofi',
    name: 'Sunset Lo-Fi Chill',
    bpm: 86,
    timeSignature: [4, 4],
    swing: 25,
    masterVolume: 0.82,
    loopStart: 0,
    loopEnd: 16,
    isLooping: true,
    tracks: [
      {
        id: 'track_lf_drums',
        name: 'Dusty Boom-Bap',
        type: 'drums',
        color: '#ffb300',
        volume: 0.85,
        pan: 0,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'sine',
          osc2Type: 'sine',
          detune: 0,
          osc2Mix: 0,
          filterCutoff: 6500,
          filterRes: 1,
          filterType: 'lowpass',
          attack: 0.01,
          decay: 0.2,
          sustain: 0.1,
          release: 0.1,
          glide: 0,
        },
        fx: {
          eqLow: 2.0,
          eqMid: -1.0,
          eqHigh: -3.0,
          delayTime: 0.35,
          delayFeedback: 0.15,
          delayMix: 0.08,
          reverbDecay: 1.8,
          reverbMix: 0.2,
          distortionDrive: 1.8,
          distortionMix: 0.22,
        },
        clips: [
          {
            id: 'clip_lf_d1',
            trackId: 'track_lf_drums',
            name: 'Lo-Fi Groove',
            startBeat: 0,
            durationBeats: 8,
            color: '#ffb300',
            drumSteps: [
              { step: 0, drum: 'kick', velocity: 0.9 },
              { step: 6, drum: 'kick', velocity: 0.8 },
              { step: 4, drum: 'snare', velocity: 0.85 },
              { step: 12, drum: 'snare', velocity: 0.9 },
              { step: 0, drum: 'hihat_closed', velocity: 0.6 },
              { step: 2, drum: 'hihat_closed', velocity: 0.5 },
              { step: 4, drum: 'hihat_closed', velocity: 0.65 },
              { step: 6, drum: 'hihat_closed', velocity: 0.55 },
              { step: 8, drum: 'hihat_closed', velocity: 0.6 },
              { step: 10, drum: 'hihat_closed', velocity: 0.5 },
              { step: 12, drum: 'hihat_closed', velocity: 0.7 },
              { step: 14, drum: 'hihat_closed', velocity: 0.5 },
              { step: 7, drum: 'perc', velocity: 0.6 },
            ],
          },
        ],
      },
      {
        id: 'track_lf_keys',
        name: 'Warm Rhodes Keys',
        type: 'keys',
        color: '#ff7043',
        volume: 0.85,
        pan: -0.1,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'triangle',
          osc2Type: 'sine',
          detune: 5,
          osc2Mix: 0.6,
          filterCutoff: 2200,
          filterRes: 1.5,
          filterType: 'lowpass',
          attack: 0.02,
          decay: 0.8,
          sustain: 0.6,
          release: 0.6,
          glide: 0,
        },
        fx: {
          eqLow: 2.0,
          eqMid: 1.0,
          eqHigh: -2.0,
          delayTime: 0.35,
          delayFeedback: 0.3,
          delayMix: 0.25,
          reverbDecay: 2.8,
          reverbMix: 0.35,
          distortionDrive: 1.5,
          distortionMix: 0.15,
        },
        clips: [
          {
            id: 'clip_lf_k1',
            trackId: 'track_lf_keys',
            name: 'Jazzy 7th Chords',
            startBeat: 0,
            durationBeats: 8,
            color: '#ff7043',
            notes: [
              // Dm9 (D3, F3, A3, C4, E4)
              { id: 'k1', pitch: 50, startBeat: 0, durationBeats: 3.5, velocity: 0.75 },
              { id: 'k2', pitch: 53, startBeat: 0, durationBeats: 3.5, velocity: 0.7 },
              { id: 'k3', pitch: 57, startBeat: 0, durationBeats: 3.5, velocity: 0.75 },
              { id: 'k4', pitch: 60, startBeat: 0, durationBeats: 3.5, velocity: 0.7 },
              { id: 'k5', pitch: 64, startBeat: 0, durationBeats: 3.5, velocity: 0.7 },

              // G13 / Gm7 (G2, B2, F3, A3)
              { id: 'k6', pitch: 43, startBeat: 4, durationBeats: 3.5, velocity: 0.75 },
              { id: 'k7', pitch: 53, startBeat: 4, durationBeats: 3.5, velocity: 0.7 },
              { id: 'k8', pitch: 57, startBeat: 4, durationBeats: 3.5, velocity: 0.75 },
              { id: 'k9', pitch: 59, startBeat: 4, durationBeats: 3.5, velocity: 0.7 },
            ],
          },
        ],
      },
      {
        id: 'track_lf_sub',
        name: 'Warm Lo-Fi Sub',
        type: 'bass',
        color: '#26a69a',
        volume: 0.85,
        pan: 0,
        muted: false,
        soloed: false,
        synthConfig: {
          osc1Type: 'sine',
          osc2Type: 'triangle',
          detune: 0,
          osc2Mix: 0.2,
          filterCutoff: 600,
          filterRes: 1.2,
          filterType: 'lowpass',
          attack: 0.04,
          decay: 0.6,
          sustain: 0.7,
          release: 0.4,
          glide: 0.05,
        },
        fx: {
          eqLow: 4.0,
          eqMid: -2.0,
          eqHigh: -6.0,
          delayTime: 0.2,
          delayFeedback: 0,
          delayMix: 0,
          reverbDecay: 1.0,
          reverbMix: 0,
          distortionDrive: 1.5,
          distortionMix: 0.2,
        },
        clips: [
          {
            id: 'clip_lf_s1',
            trackId: 'track_lf_sub',
            name: 'Walking Lo-Fi Bass',
            startBeat: 0,
            durationBeats: 8,
            color: '#26a69a',
            notes: [
              { id: 'ls1', pitch: 38, startBeat: 0, durationBeats: 2.2, velocity: 0.9 }, // D2
              { id: 'ls2', pitch: 41, startBeat: 2.5, durationBeats: 1.2, velocity: 0.8 }, // F2
              { id: 'ls3', pitch: 43, startBeat: 4, durationBeats: 2.2, velocity: 0.9 }, // G2
              { id: 'ls4', pitch: 40, startBeat: 6.5, durationBeats: 1.2, velocity: 0.85 }, // E2
            ],
          },
        ],
      },
    ],
  },
];
