import type { CurriculumQuestion } from '../../types';

// Vite emits one lazy chunk per unit JSON file; the full bank is never loaded at app startup.
const questionModules = import.meta.glob<CurriculumQuestion[]>('./*/*.json', {
  import: 'default',
});

export async function loadUnitQuestions(subjectId: string, unitId: string, lessonId?: string): Promise<CurriculumQuestion[]> {
  const load = questionModules[`./${subjectId}/${unitId}.json`];
  if (!load) return [];
  const result = await load();
  if (!Array.isArray(result)) return [];
  return result.filter((question) => question.subjectId === subjectId && question.unitId === unitId && (!lessonId || question.lessonId === lessonId));
}
