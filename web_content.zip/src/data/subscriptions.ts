export type Subscription = {
  id: string;
  name: string;
  /** emoji glyph shown inside the gradient tile */
  icon: string;
  /** render a Russian tricolor flag instead of the emoji */
  isFlag?: boolean;
  from: string;
  to: string;
  accent: string;
  badges: string[];
  beta?: boolean;
  ping: number;
  url: string;
};

export const SUBSCRIPTIONS: Subscription[] = [
  {
    id: "ru-mobile",
    name: "White Lists RU Mobile",
    icon: "",
    isFlag: true,
    from: "#00E9FF",
    to: "#2E63E8",
    accent: "#00D4FF",
    badges: ["VLESS Reality"],
    ping: 24,
    url: "https://gitlab.com/igareck/vpn-configs-for-russia/raw/main/Vless-Reality-White-Lists-Rus-Mobile.txt",
  },
  {
    id: "bobrik",
    name: "Bobrik",
    icon: "⚡",
    from: "#C084FC",
    to: "#6D28D9",
    accent: "#A855F7",
    badges: ["Xray"],
    ping: 38,
    url: "https://mifa.world/bobrik",
  },
  {
    id: "rkp",
    name: "RKP Bypass",
    icon: "🛡️",
    from: "#FF8A50",
    to: "#E11D48",
    accent: "#FF6B35",
    badges: ["V2Ray"],
    ping: 47,
    url: "https://raw.githubusercontent.com/RKPchannel/RKP_bypass_configs/main/whitelist.txt",
  },
  {
    id: "kizyak7",
    name: "Kizyak VPN 4.0 Beta 7",
    icon: "🐐",
    from: "#4D7CFF",
    to: "#16295E",
    accent: "#4C7DFF",
    badges: ["VLESS Reality"],
    beta: true,
    ping: 52,
    url: "https://raw.githubusercontent.com/Maskkost93/kizyak-vpn-4.0/main/kizyakbeta7.txt",
  },
  {
    id: "kizyak6",
    name: "Kizyak VPN 4.0 Beta 6",
    icon: "🐐",
    from: "#8B93F8",
    to: "#4338CA",
    accent: "#818CF8",
    badges: ["VLESS Reality"],
    ping: 61,
    url: "https://raw.githubusercontent.com/Maskkost93/kizyak-vpn-4.0/main/kizyakbeta6.txt",
  },
  {
    id: "cp035",
    name: "CyberPortal CP-035",
    icon: "🌐",
    from: "#2DD4BF",
    to: "#0D9488",
    accent: "#2DD4BF",
    badges: ["Xray"],
    ping: 33,
    url: "https://raw.githubusercontent.com/NullCoreDeveloper/cyberportal-mirror/master/cp-035.txt",
  },
  {
    id: "cp006",
    name: "CyberPortal CP-006",
    icon: "🌐",
    from: "#2DD4BF",
    to: "#0D9488",
    accent: "#2DD4BF",
    badges: ["Xray"],
    ping: 29,
    url: "https://raw.githubusercontent.com/NullCoreDeveloper/cyberportal-mirror/master/cp-006.txt",
  },
  {
    id: "cp008",
    name: "CyberPortal CP-008",
    icon: "🌐",
    from: "#2DD4BF",
    to: "#0D9488",
    accent: "#2DD4BF",
    badges: ["Xray"],
    ping: 74,
    url: "https://raw.githubusercontent.com/NullCoreDeveloper/cyberportal-mirror/master/cp-008.txt",
  },
  {
    id: "cp042",
    name: "CyberPortal CP-042",
    icon: "🌐",
    from: "#2DD4BF",
    to: "#0D9488",
    accent: "#2DD4BF",
    badges: ["Xray"],
    ping: 41,
    url: "https://raw.githubusercontent.com/NullCoreDeveloper/cyberportal-mirror/master/cp-042.txt",
  },
  {
    id: "etoneya",
    name: "Etoneya Whitelist",
    icon: "🍃",
    from: "#6EE7A0",
    to: "#15803D",
    accent: "#4ADE80",
    badges: ["V2Ray"],
    ping: 36,
    url: "https://etoneya.su/whitelist",
  },
  {
    id: "whoahaow",
    name: "Whoahaow Bypass All",
    icon: "🔓",
    from: "#FDBA74",
    to: "#EA580C",
    accent: "#FB923C",
    badges: ["VLESS Reality"],
    ping: 88,
    url: "https://raw.githubusercontent.com/whoahaow/rjsxrd/main/githubmirror/bypass/bypass-all.txt",
  },
  {
    id: "airlink",
    name: "AirLink VPN RKN Whitelist",
    icon: "✈️",
    from: "#7DD3FC",
    to: "#0284C7",
    accent: "#38BDF8",
    badges: ["Xray"],
    ping: 44,
    url: "https://raw.githubusercontent.com/AirLinkVPN1/AirLinkVPN/main/rkn_white_list",
  },
];

export const INITIAL_ENABLED = new Set<string>(["ru-mobile", "bobrik", "cp035"]);

export function pingColor(ms: number): string {
  if (ms < 45) return "#34D399";
  if (ms < 75) return "#FBBF24";
  return "#FB7185";
}
