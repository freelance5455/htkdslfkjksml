import type { AccessoryItem } from "./catalog";

/* Artículos de la tienda normal: se compran con monedas del juego.
   Los artículos exclusivos del catálogo de 700 NO están aquí:
   solo se obtienen con códigos de regalo. */
export const SHOP_ITEMS: AccessoryItem[] = [
  { id: "sombrero-brujita", slot: "hat", name: "Sombrero de Brujita", desc: "El clásico sombrero morado de la casa.", style: "bruja", primary: "#7c3aed", secondary: "#f5c451", price: 30 },
  { id: "corona-dorada", slot: "hat", name: "Corona Dorada", desc: "Para una verdadera reina gatuna.", style: "corona", primary: "#f5c451", secondary: "#f472b6", price: 45 },
  { id: "gorro-estrella", slot: "hat", name: "Gorro Estrella", desc: "Calientito y con estrellita mágica.", style: "gorro", primary: "#6ee7b7", secondary: "#f9a8d4", price: 25 },
  { id: "diadema-luna", slot: "hat", name: "Diadema de Luna", desc: "Una lunita dorada para soñar despierta.", style: "diadema", primary: "#c4b5fd", secondary: "#f5c451", price: 20 },
  { id: "mono-rosa", slot: "bow", name: "Moño Rosa", desc: "El moñito rosa favorito de Michi.", style: "clasico", primary: "#f472b6", secondary: "#fbcfe8", price: 10 },
  { id: "mono-menta", slot: "bow", name: "Moño Menta", desc: "Fresco como una hojita de menta.", style: "clasico", primary: "#34d399", secondary: "#a7f3d0", price: 15 },
  { id: "mono-lavanda", slot: "bow", name: "Moño Lavanda", desc: "Suave y elegante.", style: "clasico", primary: "#a78bfa", secondary: "#ddd6fe", price: 15 },
  { id: "mono-dorado", slot: "bow", name: "Moño Dorado", desc: "Brilla como el solecito.", style: "clasico", primary: "#f5c451", secondary: "#fde68a", price: 25 },
  { id: "collar-rosa", slot: "collar", name: "Cascabel Rosa", desc: "Tintinea dulcemente al caminar.", style: "clasico", primary: "#f472b6", secondary: "#f5c451", charm: "bell", price: 12 },
  { id: "collar-menta", slot: "collar", name: "Cascabel Menta", desc: "Un cascabelito plateado fresquito.", style: "clasico", primary: "#34d399", secondary: "#e5e7eb", charm: "bellSilver", price: 12 },
  { id: "collar-luna", slot: "collar", name: "Collar Luna Dorada", desc: "Con una lunita que guarda los sueños.", style: "clasico", primary: "#caa25a", secondary: "#f5c451", charm: "moon", price: 28 },
  { id: "collar-estrella", slot: "collar", name: "Collar Estrellita", desc: "Una estrellita de la suerte.", style: "clasico", primary: "#a78bfa", secondary: "#fde68a", charm: "star", price: 22 },
  { id: "collar-corazon", slot: "collar", name: "Collar Corazoncito", desc: "Lleno de amor gatuno.", style: "clasico", primary: "#fb7185", secondary: "#fda4af", charm: "heart", price: 18 },
];

export const SHOP_MAP = new Map(SHOP_ITEMS.map((i) => [i.id, i]));

export interface Food {
  id: string;
  name: string;
  desc: string;
  price: number;
  hunger: number;
  happy: number;
  color: string;
  bg: string;
}

export const FOODS: Food[] = [
  { id: "leche", name: "Leche Tibia", desc: "+18 pancita", price: 3, hunger: 18, happy: 3, color: "#7dd3fc", bg: "#0c2a3d" },
  { id: "pescadito", name: "Pescadito Fresco", desc: "+32 pancita", price: 5, hunger: 32, happy: 5, color: "#38bdf8", bg: "#0b2e3f" },
  { id: "galletita", name: "Galletita Estrella", desc: "+22 pancita · +10 felicidad", price: 8, hunger: 22, happy: 10, color: "#f5c451", bg: "#3a2c07" },
];
