import { NAMES_A } from "@/data/names-a";
import { NAMES_B } from "@/data/names-b";
import { NAMES_C } from "@/data/names-c";
import type { DivineName } from "@/data/types";

export const NAMES: DivineName[] = [...NAMES_A, ...NAMES_B, ...NAMES_C];

export function getName(slug: string) {
  return NAMES.find((item) => item.slug === slug) ?? null;
}

export function getNameByNumber(n: number) {
  return NAMES.find((item) => item.n === n) ?? null;
}

export function relatedNames(name: DivineName) {
  return name.related.map((n) => getNameByNumber(n)).filter((item): item is DivineName => Boolean(item));
}

export function bareName(ar: string) {
  return ar.replace(/^ال/, "").replace(/^ذو /, "");
}

export const NAME_THEMES = Array.from(new Set(NAMES.flatMap((item) => item.themes)));
