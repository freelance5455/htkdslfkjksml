import { MedicineItem, DoseRecord, ReminderLanguage } from '../types/reminder';

const MEDICINES_STORAGE_KEY = 'swasthyaseva_medicines_v2';
const DOSES_STORAGE_KEY = 'swasthyaseva_doses_v2';

// Initial empty medicines list - no demo or fake medicines
export const INITIAL_MEDICINES: MedicineItem[] = [];

// Generate initial doses (empty by default)
export function generateInitialDoses(medicines: MedicineItem[]): DoseRecord[] {
  return [];
}

// Storage helpers
export function loadMedicines(): MedicineItem[] {
  try {
    const raw = localStorage.getItem(MEDICINES_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to load medicines from localStorage', e);
  }
  localStorage.setItem(MEDICINES_STORAGE_KEY, JSON.stringify([]));
  return [];
}

export function saveMedicines(medicines: MedicineItem[]): void {
  try {
    localStorage.setItem(MEDICINES_STORAGE_KEY, JSON.stringify(medicines));
  } catch (e) {
    console.error('Failed to save medicines to localStorage', e);
  }
}

export function loadDoses(medicines: MedicineItem[]): DoseRecord[] {
  try {
    const raw = localStorage.getItem(DOSES_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to load doses from localStorage', e);
  }
  localStorage.setItem(DOSES_STORAGE_KEY, JSON.stringify([]));
  return [];
}

export function saveDoses(doses: DoseRecord[]): void {
  try {
    localStorage.setItem(DOSES_STORAGE_KEY, JSON.stringify(doses));
  } catch (e) {
    console.error('Failed to save doses to localStorage', e);
  }
}

// Trilingual Translations Dictionary
export const TRANSLATIONS: Record<ReminderLanguage, Record<string, string>> = {
  English: {
    title: 'Medicine Reminder',
    subtitle: 'Smart Pill Alarm, Tracking & Inventory',
    activeMeds: 'Active Medicines',
    todaySchedule: 'Today\'s Schedule',
    upcomingDoses: 'Upcoming Doses',
    missedDoses: 'Missed Doses',
    completedDoses: 'Completed Doses',
    addMedicine: 'Add Medicine',
    lowStockAlerts: 'Low Stock Alerts',
    calendarView: 'Monthly Calendar',
    historyLog: 'Medicine History',
    searchPlaceholder: 'Search by medicine, doctor, or condition...',
    taken: 'Taken',
    snooze: 'Snooze (10m)',
    skip: 'Skip',
    refillNow: 'Refill Stock',
    remaining: 'Remaining',
    dosePerTime: 'Dose',
    reason: 'Reason / Condition',
    doctor: 'Doctor Name',
    medicineType: 'Medicine Type',
    frequency: 'Frequency',
    courseDuration: 'Course Duration',
    startDate: 'Start Date',
    endDate: 'End Date',
    totalTablets: 'Total Quantity / Tablets',
    saveMedicine: 'Save Medicine',
    cancel: 'Cancel',
    progressToday: 'Today\'s Adherence Progress',
    noDosesFound: 'No schedule found for selected date.',
    filterAll: 'All Statuses',
    filterTaken: 'Completed',
    filterMissed: 'Missed',
    filterSkipped: 'Skipped',
    filterSnoozed: 'Snoozed',
    refillSuccess: 'Stock successfully refilled!',
    doseMarkedTaken: 'Dose logged as TAKEN! Inventory updated.',
    doseSnoozed: 'Dose snoozed for 10 minutes.',
    doseSkipped: 'Dose marked as SKIPPED.',
    // New Advanced Features
    adherenceScore: 'Medicine Adherence Score',
    todayAdherence: 'Today\'s Adherence',
    weeklyAdherence: 'Weekly Adherence',
    monthlyAdherence: 'Monthly Adherence',
    tierExcellent: 'Excellent',
    tierGood: 'Good',
    tierAverage: 'Average',
    tierPoor: 'Poor',
    refillPrediction: 'Smart Refill Prediction',
    finishInDays: 'Medicine will finish in {days} days.',
    estimatedFinish: 'Estimated Finish Date',
    refillReminder7: 'Refill Warning: 7 days left',
    refillReminder3: 'Refill Warning: 3 days left',
    refillReminder1: 'Critical Warning: 1 day left!',
    refillFinished: 'Medicine Finished',
    tabletsRemaining10: '10 tablets remaining',
    tabletsRemaining5: '5 tablets remaining',
    tabletsRemaining1: '1 tablet remaining',
    effectTracker: 'Medicine Effect Tracker',
    howFeeling: 'How are you feeling after taking this dose?',
    better: 'Better',
    noChange: 'No Change',
    worse: 'Worse',
    weeklyReport: 'Weekly Medicine Report',
    exportPdf: 'Export as PDF',
    aiInsights: 'AI Insights',
    nextReminder: 'Next Reminder',
    dashboard: 'Health Dashboard',
  },
  Hindi: {
    title: 'दवाई रिमाइंडर',
    subtitle: 'स्मार्ट अलार्म, ट्रैकिंग और स्टॉक प्रबंधन',
    activeMeds: 'सक्रिय दवाइयां',
    todaySchedule: 'आज का समय-सारणी',
    upcomingDoses: 'आगामी खुराक',
    missedDoses: 'छूटी हुई खुराक',
    completedDoses: 'पूर्ण खुराक',
    addMedicine: 'नई दवाई जोड़ें',
    lowStockAlerts: 'कम स्टॉक अलर्ट',
    calendarView: 'मासिक कैलेंडर',
    historyLog: 'दवाई का इतिहास',
    searchPlaceholder: 'दवाई, डॉक्टर या बीमारी से खोजें...',
    taken: 'ली गई',
    snooze: 'स्नूज़ (10 मिनट)',
    skip: 'छोड़ें',
    refillNow: 'स्टॉक रिफिल करें',
    remaining: 'शेष गोलियां',
    dosePerTime: 'मात्रा',
    reason: 'कारण / बीमारी',
    doctor: 'डॉक्टर का नाम',
    medicineType: 'दवाई का प्रकार',
    frequency: 'आवृत्ति (Frequency)',
    courseDuration: 'कोर्स अवधि',
    startDate: 'प्रारंभ तिथि',
    endDate: 'समाप्ति तिथि',
    totalTablets: 'कुल मात्रा / गोलियां',
    saveMedicine: 'दवाई सुरक्षित करें',
    cancel: 'रद्द करें',
    progressToday: 'आज का स्वास्थ्य स्कोर',
    noDosesFound: 'चयनित तिथि के लिए कोई शेड्यूल्ड दवाई नहीं मिली।',
    filterAll: 'सभी स्थितियां',
    filterTaken: 'पूर्ण ली गई',
    filterMissed: 'छूटी हुई',
    filterSkipped: 'छोड़ी गई',
    filterSnoozed: 'स्नूज़ की गई',
    refillSuccess: 'स्टॉक सफलतापूर्वक रिफिल किया गया!',
    doseMarkedTaken: 'खुराक ली गई के रूप में दर्ज हुई! स्टॉक अपडेट किया गया।',
    doseSnoozed: '10 मिनट के लिए स्नूज़ किया गया।',
    doseSkipped: 'खुराक छोड़ दी गई।',
    // New Advanced Features
    adherenceScore: 'दवा पालन स्कोर (Adherence Score)',
    todayAdherence: 'आज का पालन',
    weeklyAdherence: 'साप्ताहिक पालन',
    monthlyAdherence: 'मासिक पालन',
    tierExcellent: 'उत्कृष्ट (Excellent)',
    tierGood: 'अच्छा (Good)',
    tierAverage: 'औसत (Average)',
    tierPoor: 'कमज़ोर (Poor)',
    refillPrediction: 'स्मार्ट रिफिल अनुमान',
    finishInDays: 'दवाई {days} दिनों में समाप्त हो जाएगी।',
    estimatedFinish: 'अनुमानित समाप्ति तिथि',
    refillReminder7: 'रिफिल चेतावनी: 7 दिन शेष',
    refillReminder3: 'रिफिल चेतावनी: 3 दिन शेष',
    refillReminder1: 'गंभीर चेतावनी: 1 दिन शेष!',
    refillFinished: 'दवाई समाप्त हो गई',
    tabletsRemaining10: '10 गोलियां शेष',
    tabletsRemaining5: '5 गोलियां शेष',
    tabletsRemaining1: '1 गोली शेष',
    effectTracker: 'दवाई प्रभाव ट्रैकर',
    howFeeling: 'यह खुराक लेने के बाद आप कैसा महसूस कर रहे हैं?',
    better: 'बेहतर (Better)',
    noChange: 'कोई बदलाव नहीं (No Change)',
    worse: 'खराब (Worse)',
    weeklyReport: 'साप्ताहिक दवाई रिपोर्ट',
    exportPdf: 'PDF में एक्सपोर्ट करें',
    aiInsights: 'एआई अंतर्दृष्टि (AI Insights)',
    nextReminder: 'अगला रिमाइंडर',
    dashboard: 'स्वास्थ्य डैशबोर्ड',
  },
  Marathi: {
    title: 'औषध रिमाइंडर',
    subtitle: 'स्मार्ट अलार्म, ट्रॅकिंग आणि साठा व्यवस्थापन',
    activeMeds: 'सध्याची औषधे',
    todaySchedule: 'आजचे शेड्युल',
    upcomingDoses: 'येणारे डोस',
    missedDoses: 'राहिलेले (Missed) डोस',
    completedDoses: 'पूर्ण झालेले डोस',
    addMedicine: 'नवीन औषध जोडा',
    lowStockAlerts: 'कमी साठा अलर्ट',
    calendarView: 'महिन्याचा कॅलेंडर',
    historyLog: 'औषध इतिहास',
    searchPlaceholder: 'औषध, डॉक्टर किंवा आजाराने शोधा...',
    taken: 'घेतले',
    snooze: 'स्नूझ (१० मिनिटे)',
    skip: 'सोडा',
    refillNow: 'स्टॉक रिफिल करा',
    remaining: 'शिल्लक गोळ्या',
    dosePerTime: 'प्रमाण (Dose)',
    reason: 'कारण / आजार',
    doctor: 'डॉक्टरांचे नाव',
    medicineType: 'औषधाचा प्रकार',
    frequency: 'वारंवारता',
    courseDuration: 'कोर्स कालावधी',
    startDate: 'सुरुवातीची तारीख',
    endDate: 'शेवटची तारीख',
    totalTablets: 'एकूण प्रमाण / गोळ्या',
    saveMedicine: 'औषध सेव्ह करा',
    cancel: 'रद्द करा',
    progressToday: 'आजची प्रगती',
    noDosesFound: 'निवडलेल्या तारखेसाठी कोणतेही शेड्युल सापडले नाही.',
    filterAll: 'सर्व स्थिती',
    filterTaken: 'पूर्ण झालेले',
    filterMissed: 'राहिलेले',
    filterSkipped: 'सोडलेले',
    filterSnoozed: 'स्नूझ केलेले',
    refillSuccess: 'स्टॉक यशस्वीपणे रिफिल केला!',
    doseMarkedTaken: 'डोस घेतला म्हणून नोंदवला! साठा अपडेट झाला.',
    doseSnoozed: '१० मिनिटांसाठी स्नूझ केले.',
    doseSkipped: 'डोस सोडला म्हणून नोंदवला.',
    // New Advanced Features
    adherenceScore: 'औषध पालन स्कोअर',
    todayAdherence: 'आजचे पालन',
    weeklyAdherence: 'साप्ताहिक पालन',
    monthlyAdherence: 'मासिक पालन',
    tierExcellent: 'उत्कृष्ट',
    tierGood: 'छान',
    tierAverage: 'सरासरी',
    tierPoor: 'कमी',
    refillPrediction: 'स्मार्ट रिफिल अंदाज',
    finishInDays: 'औषध {days} दिवसांत संपेल.',
    estimatedFinish: 'अंदाजित समाप्ती तारीख',
    refillReminder7: 'रिफिल इशारा: ७ दिवस शिल्लक',
    refillReminder3: 'रिफिल इशारा: ३ दिवस शिल्लक',
    refillReminder1: 'महत्त्वाचा इशारा: १ दिवस शिल्लक!',
    refillFinished: 'औषध संपले',
    tabletsRemaining10: '१० गोळ्या शिल्लक',
    tabletsRemaining5: '५ गोळ्या शिल्लक',
    tabletsRemaining1: '१ गोळी शिल्लक',
    effectTracker: 'औषध प्रभाव ट्रॅकर',
    howFeeling: 'हा डोस घेतल्यानंतर तुम्हाला कसे वाटत आहे?',
    better: 'बरे वाटत आहे',
    noChange: 'काही फरक नाही',
    worse: 'त्रास वाढला',
    weeklyReport: 'साप्ताहिक औषध अहवाल',
    exportPdf: 'PDF डाऊनलोड / प्रिंट करा',
    aiInsights: 'एआय माहिती (AI Insights)',
    nextReminder: 'पुढील रिमाइंडर',
    dashboard: 'आरोग्य डॅशबोर्ड',
  }
};
