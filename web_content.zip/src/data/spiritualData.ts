import { Track, Devotional, Sermon, SoundscapePreset, GlobalPrayerRequest } from '../types';

export const ASSETS = {
  heroBanner: '/src/assets/images/hero_divine_worship_1785560510823.jpg',
  albumSoaking: '/src/assets/images/album_anointed_soaking_1785560523379.jpg',
  prophetPortrait: '/src/assets/images/prophet_juhnkrix_1785560534924.jpg',
};

export const FEATURED_TRACKS: Track[] = [
  {
    id: 'track-1',
    title: 'The Glory Anointing (528Hz Holy Soaking)',
    artist: 'Prophet JUHNKRIX SYNVAGORD',
    category: 'Soaking Meditation',
    duration: 380,
    albumArt: ASSETS.albumSoaking,
    description: 'Anointed deep soaking pads tuned to 528Hz divine frequency designed to wash over the spirit and bring tranquil celestial peace.',
    scriptureRef: 'Psalm 23:2 - He leads me beside still waters.',
    plays: 142800,
    isAnointedFeatured: true,
    synthPreset: '528hz',
    lyrics: `[Soft Celestial Chime]
Let the Glory fall upon this sanctuary.
Every chain is broken, every burden lifted.
In Your Presence, there is fullness of joy.
Breathe in the Holy Atmosphere...
Grace overflows.`
  },
  {
    id: 'track-2',
    title: 'Breakthrough Chants of Fire & Victory',
    artist: 'Prophet JUHNKRIX SYNVAGORD ft. Anointed Voices',
    category: 'Prophetic Chants',
    duration: 295,
    albumArt: ASSETS.heroBanner,
    description: 'Powerful prophetic chanting and spiritual warfare decree that dismantles every stronghold and invites divine breakthrough.',
    scriptureRef: 'Isaiah 54:17 - No weapon formed against you shall prosper.',
    plays: 98400,
    isAnointedFeatured: true,
    synthPreset: 'warfare',
    lyrics: `[Prophetic Decree]
I speak light into your dark places!
Rise up, warrior of Zion!
The Lion of Judah has prevailed!
Hallelujah! Victory is yours today!`
  },
  {
    id: 'track-3',
    title: 'Deep Atmosphere of Grace & Holiness',
    artist: 'Prophet JUHNKRIX SYNVAGORD',
    category: 'Anointed Worship',
    duration: 420,
    albumArt: ASSETS.albumSoaking,
    description: 'Slow, majestic worship movement carrying profound sacred reverence and intimate heart communion.',
    scriptureRef: 'Exodus 33:14 - My Presence will go with you, and I will give you rest.',
    plays: 215000,
    isAnointedFeatured: true,
    synthPreset: 'soaking',
    lyrics: `Holy, Holy, Holy is the Lord Almighty.
The earth is filled with His glorious majesty.
We bow down before the Throne of Grace.
Soaking in Your pure light.`
  },
  {
    id: 'track-4',
    title: 'Celestial Angels Chime (432Hz Calm)',
    artist: 'Prophet JUHNKRIX SYNVAGORD',
    category: 'Soaking Meditation',
    duration: 330,
    albumArt: ASSETS.heroBanner,
    description: 'Tranquil harmonic pad with crystal bell reverberations for midnight meditation and deep spiritual restoration.',
    scriptureRef: 'Philippians 4:7 - The peace of God which surpasses all understanding.',
    plays: 87200,
    synthPreset: '432hz',
    lyrics: `Peace, be still.
Let every fear dissolve in His presence.
Angels encircling your heart tonight.
Divine protection over your household.`
  },
  {
    id: 'track-5',
    title: 'High Praise of Zion & Jubilation',
    artist: 'JUHNKRIX Gospel Orchestra & Choir',
    category: 'High Praise',
    duration: 240,
    albumArt: ASSETS.heroBanner,
    description: 'Upbeat, triumphant gospel praise with brass harmonies, energetic drums, and joyful shouting.',
    scriptureRef: 'Psalm 150:6 - Let everything that has breath praise the Lord!',
    plays: 176300,
    synthPreset: 'angelic',
    lyrics: `Shout for joy all the earth!
Great is the Lord and greatly to be praised!
We dance in His victory, we walk in His light!
Hallelujah, Amen!`
  },
  {
    id: 'track-6',
    title: 'Deliverance & Yoke-Breaking Mantle',
    artist: 'Prophet JUHNKRIX SYNVAGORD',
    category: 'Deliverance & Power',
    duration: 510,
    albumArt: ASSETS.prophetPortrait,
    description: 'Deep resonant prophetic mantle prayer accompanied by heavy organ chords and atmosphere cleansing frequencies.',
    scriptureRef: 'Isaiah 10:27 - The yoke shall be destroyed because of the anointing.',
    plays: 129000,
    isAnointedFeatured: true,
    synthPreset: 'warfare',
    lyrics: `By the power in the Blood of Jesus,
Every demonic assignment is canceled!
Walk out of sickness into total healing!
Be released, be delivered in Jesus name!`
  }
];

export const DAILY_DEVOTIONALS: Devotional[] = [
  {
    id: 'dev-1',
    date: 'TODAY\'S PROPHETIC WORD',
    title: 'The Shift from Stagnation to Divine Acceleration',
    scripture: 'Amos 9:13',
    scriptureText: '"The days are coming," declares the LORD, "when the reaper will be overtaken by the plowman and the planter by the one treading grapes."',
    propheticDecree: 'I decree and declare that every delayed blessing in my life receives divine speed now! My harvest is catching up with my sowing.',
    message: 'Beloved child of God, stagnation is a trick of the adversary to weary your faith. Prophet JUHNKRIX SYNVAGORD brings you this heavenly insight: God is changing your timeline. What used to take years will now manifest in months. Rest your mind in His sovereign grace as you listen to today\'s anointed soaking frequencies.',
    audioDuration: '5 min 20 sec',
    author: 'Prophet JUHNKRIX SYNVAGORD',
    tags: ['Breakthrough', 'Acceleration', 'Prophetic Word']
  },
  {
    id: 'dev-2',
    date: 'YESTERDAY\'S REVELATION',
    title: 'Anointed Peace That Overcomes Every Storm',
    scripture: 'Mark 4:39',
    scriptureText: 'He got up, rebuked the wind and said to the waves, "Quiet! Be still!" Then the wind died down and it was completely calm.',
    propheticDecree: 'I speak quiet and stillness over my thoughts, my home, and my future. No turmoil shall dislodge my divine peace.',
    message: 'When Christ is in your vessel, the storm has no legal right to capsize you. The voice of Prophet JUHNKRIX SYNVAGORD releases quietness over every stormy diagnosis, financial anxiety, and family distress.',
    audioDuration: '6 min 10 sec',
    author: 'Prophet JUHNKRIX SYNVAGORD',
    tags: ['Peace', 'Faith', 'Authority']
  }
];

export const SERMONS_ARCHIVE: Sermon[] = [
  {
    id: 'sermon-live',
    title: 'PROPHETIC NIGHT OF GLORY: Unlocking Your Supernatural Destiny',
    prophet: 'Prophet JUHNKRIX SYNVAGORD',
    date: 'LIVE BROADCAST NOW',
    duration: '1h 45m',
    thumbnail: ASSETS.heroBanner,
    summary: 'Exclusive live spiritual service broadcasting anointed prayers, prophecy for nations, and direct laying on of hands through the airwaves.',
    keyScriptures: ['Joel 2:28', 'Ephesians 1:18', '2 Chronicles 20:20'],
    isLiveNow: true,
    viewersCount: 14290,
    category: 'Prophetic Revelation',
    tags: ['Live', 'Prophecy', 'Glory']
  },
  {
    id: 'sermon-1',
    title: 'The Mystery of the Anointing That Destroys Yokes',
    prophet: 'Prophet JUHNKRIX SYNVAGORD',
    date: 'July 28, 2026',
    duration: '58 min',
    thumbnail: ASSETS.prophetPortrait,
    summary: 'A deep biblical exposition on how the Holy Spirit anointing breaks invisible spiritual resistance and empowers believers for supernatural dominion.',
    keyScriptures: ['Isaiah 10:27', '1 John 2:20', 'Acts 10:38'],
    category: 'Anointing & Grace',
    tags: ['Anointing', 'Deliverance', 'Power']
  },
  {
    id: 'sermon-2',
    title: 'Dismantling Altars of Limitation & Inherited Patterns',
    prophet: 'Prophet JUHNKRIX SYNVAGORD',
    date: 'July 21, 2026',
    duration: '1h 12m',
    thumbnail: ASSETS.albumSoaking,
    summary: 'Spiritual warfare masterclass detailing how to apply the covenant blood of Jesus to eliminate persistent generational stumbling blocks.',
    keyScriptures: ['Gideon Judges 6:25', 'Galatians 3:13'],
    category: 'Spiritual Warfare',
    tags: ['Freedom', 'Deliverance', 'Warfare']
  },
  {
    id: 'sermon-3',
    title: 'Attracting Angels: The Secret of Holy Soaking Worship',
    prophet: 'Prophet JUHNKRIX SYNVAGORD',
    date: 'July 14, 2026',
    duration: '45 min',
    thumbnail: ASSETS.heroBanner,
    summary: 'Discover how quiet, contemplative worship creates a holy sanctuary in your bedroom where angelic assistance manifests.',
    keyScriptures: ['Hebrews 1:14', 'Psalm 91:11'],
    category: 'Prophetic Revelation',
    tags: ['Soaking', 'Angels', 'Worship']
  }
];

export const SOUNDSCAPE_PRESETS: SoundscapePreset[] = [
  {
    id: 'preset-528',
    name: '528Hz Holy Miracle Frequency',
    description: 'Resonates with cellular peace and spiritual rejuvenation.',
    frequencyHz: 528,
    padType: 'soaking',
    chimesEnabled: true,
    riverEnabled: true,
    colorTheme: 'from-amber-500/20 to-yellow-600/10'
  },
  {
    id: 'preset-432',
    name: '432Hz Divine Serenity Pad',
    description: 'Harmonizes your brainwaves with natural creation frequencies.',
    frequencyHz: 432,
    padType: '432hz',
    chimesEnabled: true,
    riverEnabled: false,
    colorTheme: 'from-indigo-500/20 to-purple-600/10'
  },
  {
    id: 'preset-celestial',
    name: 'Angelic Choir & Golden Ray',
    description: 'Ethereal vocal textures and shimmering synth chimes.',
    frequencyHz: 639,
    padType: 'angelic',
    chimesEnabled: true,
    riverEnabled: true,
    colorTheme: 'from-blue-500/20 to-cyan-500/10'
  },
  {
    id: 'preset-warfare',
    name: 'Glory Shaking Deep Resonant Tone',
    description: 'Deep grounding bass drone for intense prophetic prayer.',
    frequencyHz: 396,
    padType: 'warfare',
    chimesEnabled: false,
    riverEnabled: false,
    colorTheme: 'from-rose-500/20 to-purple-800/10'
  }
];

export const INITIAL_GLOBAL_PRAYERS: GlobalPrayerRequest[] = [
  {
    id: 'g-1',
    userName: 'Sister Grace M.',
    location: 'London, UK',
    requestText: 'Standing in agreement for my son\'s complete miraculous healing from spinal inflammation. Lord, stretch forth Your hand!',
    prayerCount: 1240,
    timestamp: '12 min ago'
  },
  {
    id: 'g-2',
    userName: 'Brother Emmanuel K.',
    location: 'Accra, Ghana',
    requestText: 'Believing Prophet JUHNKRIX SYNVAGORD for financial breakthrough and opening of international business doors this month.',
    prayerCount: 890,
    timestamp: '25 min ago'
  },
  {
    id: 'g-3',
    userName: 'Evangelist Sarah T.',
    location: 'Dallas, Texas',
    requestText: 'Praying for divine wisdom and peace in my family restoration. No weapon formed against us shall stand.',
    prayerCount: 2150,
    timestamp: '1 hour ago'
  }
];
