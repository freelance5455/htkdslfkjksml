import { SkinDef, SkinId, CharacterGender } from '../types';

export const SKINS_DATA: SkinDef[] = [
  {
    id: 'classic',
    nameAr: 'البالطو الأبيض الكلاسيكي',
    nameEn: 'Classic Lab Coat',
    cost: 0,
    description: 'الرداء المعملي الأيقوني لطلاب وعلماء الصيدلة، أنيق وبسيط ومعقم.',
    badge: 'مجاني للجميع',
    coatColor: '#f0f6ff',
    coatTrim: '#d7e6fc',
    accentColor: '#4cf5ff',
    pantsColor: '#0f1a3a',
    gogglesColor: '#4cf5ff',
    gogglesLens: 'rgba(76, 245, 255, 0.35)',
    glowColor: '#4cf5ff',
  },
  {
    id: 'biohazard',
    nameAr: 'بدلة العزل النيونية',
    nameEn: 'Neon Biohazard Suit',
    cost: 350,
    description: 'بدلة مقاومة للمواد المشعة والمحاليل الخطرة بلون ليموني فاقع وخوذة فلتر.',
    badge: '350 نقطة',
    coatColor: '#e0f836',
    coatTrim: '#202905',
    accentColor: '#ff9800',
    pantsColor: '#1a1d08',
    gogglesColor: '#ffea00',
    gogglesLens: 'rgba(255, 234, 0, 0.45)',
    auraColor: 'rgba(224, 248, 54, 0.25)',
    glowColor: '#e0f836',
  },
  {
    id: 'cryo',
    nameAr: 'بدلة النانو الجليدية',
    nameEn: 'Cryo-Freeze Nano Suit',
    cost: 750,
    description: 'مصنوعة لغرف التبريد والنيتروجين السائل مع بلورات ثلجية عاكسة وألياف سيان.',
    badge: '750 نقطة',
    coatColor: '#4ff3ff',
    coatTrim: '#0f4870',
    accentColor: '#ffffff',
    pantsColor: '#08253d',
    gogglesColor: '#9bf7ff',
    gogglesLens: 'rgba(155, 247, 255, 0.5)',
    auraColor: 'rgba(79, 243, 255, 0.3)',
    glowColor: '#4ff3ff',
  },
  {
    id: 'toxic',
    nameAr: 'عالم السموم الكوني',
    nameEn: 'Cosmic Toxicologist',
    cost: 1300,
    description: 'معطف بنفسجي ملكي مطعم بألياف ليزرية للمركبات الكيميائية النادرة.',
    badge: '1300 نقطة',
    coatColor: '#9b51e0',
    coatTrim: '#2a0e4a',
    accentColor: '#ff61d2',
    pantsColor: '#120724',
    gogglesColor: '#ff61d2',
    gogglesLens: 'rgba(255, 97, 210, 0.45)',
    auraColor: 'rgba(155, 81, 224, 0.35)',
    glowColor: '#ff61d2',
  },
  {
    id: 'golden',
    nameAr: 'الصيدلي الذهبي الأسطوري',
    nameEn: 'Golden Pharmacist Legend',
    cost: 2000,
    description: 'الرداء الذهبي الخالص المخصص لعلماء الصيدلة المتميزين أصحاب العلامات الكاملة.',
    badge: '2000 نقطة',
    coatColor: '#ffd700',
    coatTrim: '#7a5a00',
    accentColor: '#ffffff',
    pantsColor: '#2b1f00',
    gogglesColor: '#ffe866',
    gogglesLens: 'rgba(255, 232, 102, 0.55)',
    auraColor: 'rgba(255, 215, 0, 0.4)',
    glowColor: '#ffd700',
  },
];

const GENDER_KEY = 'pharma_parkour_gender';
const EQUIPPED_SKIN_KEY = 'pharma_parkour_skin';
const UNLOCKED_SKINS_KEY = 'pharma_parkour_unlocked_skins';
const WALLET_KEY = 'pharma_parkour_points_wallet';

export const getSavedGender = (): CharacterGender => {
  const g = localStorage.getItem(GENDER_KEY);
  return g === 'girl' ? 'girl' : 'boy';
};

export const saveGender = (gender: CharacterGender) => {
  localStorage.setItem(GENDER_KEY, gender);
};

export const getSavedEquippedSkin = (): SkinId => {
  const s = localStorage.getItem(EQUIPPED_SKIN_KEY) as SkinId;
  const exists = SKINS_DATA.some((sk) => sk.id === s);
  return exists ? s : 'classic';
};

export const saveEquippedSkin = (skinId: SkinId) => {
  localStorage.setItem(EQUIPPED_SKIN_KEY, skinId);
};

export const getUnlockedSkins = (): SkinId[] => {
  try {
    const raw = localStorage.getItem(UNLOCKED_SKINS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.includes('classic')) {
        return parsed;
      }
    }
  } catch {}
  return ['classic'];
};

export const saveUnlockedSkin = (skinId: SkinId) => {
  const current = getUnlockedSkins();
  if (!current.includes(skinId)) {
    const updated = [...current, skinId];
    localStorage.setItem(UNLOCKED_SKINS_KEY, JSON.stringify(updated));
  }
};

export const getPointsWallet = (): number => {
  const pts = localStorage.getItem(WALLET_KEY);
  return pts ? Math.max(0, parseInt(pts, 10) || 0) : 500; // start with 500 gift points so they can buy their first skin immediately!
};

export const addPointsToWallet = (amount: number): number => {
  const current = getPointsWallet();
  const next = current + Math.max(0, amount);
  localStorage.setItem(WALLET_KEY, String(next));
  return next;
};

export const deductPointsFromWallet = (amount: number): boolean => {
  const current = getPointsWallet();
  if (current >= amount) {
    const next = current - amount;
    localStorage.setItem(WALLET_KEY, String(next));
    return true;
  }
  return false;
};
