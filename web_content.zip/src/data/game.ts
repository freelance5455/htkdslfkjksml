export type Car = {
  id: string;
  name: string;
  trim: string;
  klass: string;
  blurb: string;
  body: string;
  bodyLight: string;
  bodyDark: string;
  accent: string;
  handling: number;
  nitro: number;
  accel: number;
  tag: string;
};

export const CARS: Car[] = [
  {
    id: "night-spec",
    name: "Night Spec",
    trim: "GT-R",
    klass: "Grand tourer",
    blurb: "The original. Balanced, forgiving and quietly brutal when the road opens up.",
    body: "#232823",
    bodyLight: "#3a4236",
    bodyDark: "#0d110d",
    accent: "#c9fa3c",
    handling: 80,
    nitro: 82,
    accel: 86,
    tag: "Factory setup",
  },
  {
    id: "phantom-rs",
    name: "Phantom RS",
    trim: "RS",
    klass: "Hypercar",
    blurb: "More boost, less mercy. Built to live at the top of the rev range.",
    body: "#1e2a2c",
    bodyLight: "#3a5053",
    bodyDark: "#0b1213",
    accent: "#a9e8ff",
    handling: 72,
    nitro: 96,
    accel: 94,
    tag: "Boost focused",
  },
  {
    id: "ember-gt",
    name: "Ember GT",
    trim: "GT3",
    klass: "Track special",
    blurb: "Short ratios and a hungry front end. It turns before you ask it to.",
    body: "#2b201b",
    bodyLight: "#4d352a",
    bodyDark: "#130d0a",
    accent: "#ff7a45",
    handling: 92,
    nitro: 74,
    accel: 88,
    tag: "Corner hungry",
  },
];

export const DEFAULT_CAR_ID = "night-spec";

export type DriverRecord = {
  id: string;
  driver: string;
  carId: string;
  carName: string;
  distance: number;
  score: number;
  topSpeed: number;
  date: string;
  local?: boolean;
};

export type RunResult = {
  distance: number;
  score: number;
  topSpeed: number;
  level: number;
  nearMisses: number;
  sparks: number;
  carId: string;
  carName: string;
};

const isoDaysAgo = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString();
};

export const GHOST_RECORDS: DriverRecord[] = [
  {
    id: "g-1",
    driver: "K. Silva",
    carId: "night-spec",
    carName: "Night Spec",
    distance: 12480,
    score: 25160,
    topSpeed: 200,
    date: isoDaysAgo(2),
  },
  {
    id: "g-2",
    driver: "R. Perera",
    carId: "phantom-rs",
    carName: "Phantom RS",
    distance: 11205,
    score: 22870,
    topSpeed: 200,
    date: isoDaysAgo(4),
  },
  {
    id: "g-3",
    driver: "A. Fernando",
    carId: "ember-gt",
    carName: "Ember GT",
    distance: 9860,
    score: 19740,
    topSpeed: 200,
    date: isoDaysAgo(7),
  },
  {
    id: "g-4",
    driver: "M. Jay",
    carId: "night-spec",
    carName: "Night Spec",
    distance: 7420,
    score: 15390,
    topSpeed: 196,
    date: isoDaysAgo(9),
  },
  {
    id: "g-5",
    driver: "T. Okafor",
    carId: "phantom-rs",
    carName: "Phantom RS",
    distance: 6180,
    score: 12960,
    topSpeed: 193,
    date: isoDaysAgo(12),
  },
  {
    id: "g-6",
    driver: "L. Moreau",
    carId: "ember-gt",
    carName: "Ember GT",
    distance: 4940,
    score: 10420,
    topSpeed: 188,
    date: isoDaysAgo(16),
  },
];

export const STORAGE = {
  car: "vanta.car.v1",
  sound: "vanta.sound.v1",
  records: "vanta.records.v1",
  best: "vanta.best.v1",
  driver: "vanta.driver.v1",
} as const;

export function loadStored<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function saveStored(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable — the run still counts in-session */
  }
}

export function formatNumber(value: number): string {
  return Math.floor(value).toLocaleString("en-US");
}

export function formatDistance(value: number): string {
  return `${formatNumber(value)} m`;
}

export function formatDateLabel(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
}

export function sortRecords(records: DriverRecord[]): DriverRecord[] {
  return [...records].sort((a, b) => b.distance - a.distance || b.score - a.score);
}

export function allRecords(local: DriverRecord[]): DriverRecord[] {
  return sortRecords([...local, ...GHOST_RECORDS]);
}

export function carById(id: string): Car {
  return CARS.find((car) => car.id === id) ?? CARS[0];
}
