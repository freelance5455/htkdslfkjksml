import { NutritionItem } from '../types/nutrition';

export const NUTRITION_DATA: NutritionItem[] = [
  // 1. DIABETES
  {
    id: 'diet-diabetes',
    category: 'Disease-wise Diet',
    categoryEmoji: '🩸',
    bgGradient: 'from-rose-500 to-red-600',
    badgeBg: 'bg-rose-50 border-rose-200',
    badgeText: 'text-rose-700',
    content: {
      English: {
        title: 'Diabetes Management Diet',
        categoryName: 'Disease-wise Diet',
        summary: 'A low glycemic index (GI), high-fiber diet to maintain blood glucose stability.',
        diseaseDiet: {
          diseaseName: 'Diabetes (Type 2 & Pre-diabetes)',
          summary: 'Focus on complex carbohydrates, high fiber, lean proteins, and low-GI foods that prevent sharp blood sugar spikes.',
          foodsToEat: ['Whole grains (oats, quinoa, brown rice)', 'Legumes & lentils (dal)', 'Leafy greens & fiber-rich vegetables', 'Nuts & seeds (walnuts, chia seeds)', 'Fatty fish & eggs'],
          foodsToAvoid: ['Refined sugar & sweets', 'Refined flour (maida, white bread)', 'Carbonated sodas & packaged fruit juices', 'Fried snacks & trans fats', 'Excessive white rice'],
          recommendedFruits: ['Jamun (Indian Blackberry)', 'Guava', 'Apples (with skin)', 'Pears', 'Papaya (moderate portion)'],
          recommendedVegetables: ['Bitter Gourd (Karela)', 'Fenugreek leaves (Methi)', 'Spinach (Palak)', 'Broccoli', 'Cucumber & Bottle Gourd (Lauki)'],
          recommendedDrinks: ['Warm Cinnamon water', 'Fenugreek seed (Methi) water', 'Unsweetened Buttermilk (Chaas)', 'Green Tea', 'Plain Water'],
          proteinSources: ['Paneer (Cottage cheese)', 'Tofu & Soybeans', 'Sprouted Moong & Chana', 'Chicken breast', 'Egg whites'],
          healthySnacks: ['Roasted Chana (Chickpeas)', 'Handful of almonds & walnuts', 'Cucumber & Carrot sticks', 'Sprouted salad with lemon'],
          mealTimingTips: ['Eat small, frequent meals every 3-4 hours', 'Never skip breakfast', 'Keep dinner light and eat 2-3 hours before sleep', 'Pair carbs with protein or healthy fats'],
          lifestyleAdvice: ['Engage in 30 minutes of brisk walking daily', 'Monitor blood glucose levels regularly', 'Maintain healthy sleep schedule (7-8 hrs)', 'Manage stress with meditation or yoga'],
          faqs: [
            { question: 'Can diabetic patients eat mangoes or bananas?', answer: 'Yes, but in strict portion control (e.g., 1 small piece), ideally paired with nuts to lower GI impact.' },
            { question: 'Is Karela (Bitter Gourd) juice really effective?', answer: 'Karela contains polypeptide-p which acts similarly to insulin, helping lower blood glucose when consumed regularly.' }
          ]
        }
      },
      Hindi: {
        title: 'डायबिटीज आहार निर्देश (Diabetes Diet)',
        categoryName: 'बीमारी अनुसार आहार',
        summary: 'कम ग्लाइसेमिक इंडेक्स और फाइबर युक्त आहार जो ब्लड शुगर को नियंत्रित रखता है।',
        diseaseDiet: {
          diseaseName: 'डायबिटीज (मधुमेह)',
          summary: 'जटिल कार्बोहाइड्रेट, उच्च फाइबर, दुबला प्रोटीन और कम-GI वाले खाद्य पदार्थों पर ध्यान दें जो शुगर स्पाइक को रोकते हैं।',
          foodsToEat: ['साबुत अनाज (ओट्स, दलिया, भूरा चावल)', 'दालें और अंकुरित अनाज', 'हरी पत्तेदार सब्जियां', 'मेवे और बीज (अखरोट, अलसी)', 'अंडे और मछली'],
          foodsToAvoid: ['सफेद चीनी और मिठाइयां', 'मैदा और सफेद ब्रेड', 'कोल्ड ड्रिंक्स और पैक्ड जूस', 'तले हुए भोजन और फास्ट फूड', 'अत्यधिक सफेद चावल'],
          recommendedFruits: ['जामुन', 'अमरूद', 'सेब', 'नाशपाती', 'पपीता (सीमित मात्रा)'],
          recommendedVegetables: ['करेला', 'मेथी', 'पालक', 'लौकी', 'खीरा और ब्रोकली'],
          recommendedDrinks: ['दालचीनी का पानी', 'मेथी दाने का पानी', 'बिना चीनी की छाछ', 'ग्रीन टी', 'सादा पानी'],
          proteinSources: ['पनीर', 'सोयाबीन और टोफू', 'अंकुरित मूंग और चना', 'चिकन', 'अंडे की सफेदी'],
          healthySnacks: ['भुना हुआ चना', 'मुट्ठी भर बादाम-अखरोट', 'खीरा-गाजर स्टिक्स', 'अंकुरित चाट (नींबू के साथ)'],
          mealTimingTips: ['हर 3-4 घंटे में छोटा और संतुलित भोजन लें', 'नाश्ता कभी न छोड़ें', 'रात का खाना हल्का रखें और सोने से 2-3 घंटे पहले खाएं', 'कार्ब्स को प्रोटीन के साथ मिलाकर खाएं'],
          lifestyleAdvice: ['रोजाना कम से कम 30 मिनट पैदल चलें', 'नियमित रूप से ब्लड शुगर की जांच करें', '7-8 घंटे की गहरी नींद लें', 'तनाव दूर करने के लिए योग करें'],
          faqs: [
            { question: 'क्या डायबिटीज मरीज आम या केला खा सकते हैं?', answer: 'हां, लेकिन बहुत कम मात्रा में (जैसे 1 छोटा टुकड़ा) और मेवों के साथ खाएं ताकि शुगर तेजी से न बढ़े।' },
            { question: 'क्या करेले का जूस शुगर कम करने में मददगार है?', answer: 'हां, करेले में इंसुलिन जैसा यौगिक होता है जो ब्लड शुगर को नियंत्रित करने में सहायता करता है।' }
          ]
        }
      },
      Marathi: {
        title: 'मधुमेह आहार मार्गदर्शक (Diabetes Diet)',
        categoryName: 'आजारानुसार आहार',
        summary: 'कमी ग्लायसेमिक इंडेक्स आणि फायबरयुक्त आहार जो रक्तातील साखर नियंत्रित ठेवतो.',
        diseaseDiet: {
          diseaseName: 'मधुमेह (Diabetes)',
          summary: 'रक्तातील साखर वाढू नये म्हणून फायबरयुक्त धान्य, डाळी आणि कमी साखरेचे पदार्थ आहारात समाविष्ट करा.',
          foodsToEat: ['सलग धान्य (ओट्स, दलिया, ब्राऊन राईस)', 'मटकी, मूग, हरभरा', 'हिरव्या पालेभाज्या', 'बदाम, अक्रोड, अळशी', 'अंडी व मासे'],
          foodsToAvoid: ['पांढरी साखर व मिठाई', 'मैदा व व्हाईट ब्रेड', 'कोल्ड ड्रिंक्स व पाकीटबंद ज्यूस', 'तळलेले पदार्थ', 'जास्त प्रमाणात पांढरा भात'],
          recommendedFruits: ['जांभूळ', 'पेरू', 'सफरचंद', 'नारंगी', 'पपई (मर्यादित)'],
          recommendedVegetables: ['कारले', 'मेथी', 'पालक', 'दुधी भोपळा', 'काकडी व ब्रोकोली'],
          recommendedDrinks: ['दालचिनीचे पाणी', 'मेथी दाण्याचे पाणी', 'साजूक ताक (विना साखर)', 'ग्रीन टी', 'स्वच्छ पाणी'],
          proteinSources: ['पनीर', 'सोयाबीन व टोफू', 'मोड आलेले मूग', 'चिकन', 'अंड्याचा पांढरा भाग'],
          healthySnacks: ['भाजलेले चणे', 'बदाम व अक्रोड', 'काकडी-गाजर फोडी', 'मोड आलेले कडधान्य सॅलड'],
          mealTimingTips: ['दर ३-४ तासांनी थोडे थोडे जेवा', 'सकाळचा नाश्ता चुकवू नका', 'रात्रीचे जेवण हलके व झोपण्यापूर्वी २ तास आधी घ्या', 'कार्बोहायड्रेट्स सोबत प्रोटीन घ्या'],
          lifestyleAdvice: ['दररोज ३० मिनिटे वेगाने चाला', 'साखरेची नियमित तपासणी करा', '७-८ तास पुरेशी झोप घ्या', 'योगासने व प्राणायाम करा'],
          faqs: [
            { question: 'मधुमेही रुग्ण आंबा किंवा केळी खाऊ शकतात का?', answer: 'होय, परंतु अगदी कमी प्रमाणात व बदामांसोबत खाणे योग्य ठरेल.' },
            { question: 'कारल्याचा रस साखर कमी करतो का?', answer: 'होय, कारल्यातील घटकांमुळे इन्सुलिनची कार्यक्षमता वाढते व साखर नियंत्रित राहते.' }
          ]
        }
      }
    }
  },

  // 2. HIGH BLOOD PRESSURE
  {
    id: 'diet-hbp',
    category: 'High Blood Pressure Diet',
    categoryEmoji: '🧂',
    bgGradient: 'from-amber-500 to-orange-600',
    badgeBg: 'bg-amber-50 border-amber-200',
    badgeText: 'text-amber-800',
    content: {
      English: {
        title: 'High Blood Pressure (DASH Diet)',
        categoryName: 'High Blood Pressure Diet',
        summary: 'A low-sodium, potassium-rich dietary pattern designed to naturally lower hypertension.',
        diseaseDiet: {
          diseaseName: 'High Blood Pressure (Hypertension)',
          summary: 'Follow the DASH (Dietary Approaches to Stop Hypertension) principles: reduce salt/sodium and increase potassium, magnesium, and calcium.',
          foodsToEat: ['Potassium-rich fruits & veggies', 'Low-fat dairy products', 'Whole grains & oats', 'Garlic & herbs for flavor', 'Flaxseeds & chia seeds'],
          foodsToAvoid: ['Table salt & salted snacks', 'Pickles, papads & processed sauces', 'Canned foods & instant noodles', 'Red meat & processed meats', 'Alcohol & excessive caffeine'],
          recommendedFruits: ['Bananas', 'Oranges & Mosambi', 'Watermelon', 'Pomegranates', 'Berries'],
          recommendedVegetables: ['Spinach & Greens', 'Beetroot', 'Tomatoes', 'Sweet Potatoes', 'Garlic & Onions'],
          recommendedDrinks: ['Beetroot juice', 'Coconut water (if kidney function is normal)', 'Hibiscus tea', 'Lemon water (without salt)', 'Plain Water'],
          proteinSources: ['Lentils & Dal', 'Low-fat curd / yogurt', 'Egg whites', 'Fish rich in Omega-3', 'Tofu'],
          healthySnacks: ['Unsalted roasted makhana (Fox nuts)', 'Fresh fruit bowl', 'Unsalted seeds mixture', 'Carrot & Cucumber with hummus'],
          mealTimingTips: ['Limit total sodium to less than 1,500 - 2,000 mg per day (approx 1 tsp salt)', 'Use herbs, lemon juice, and spices instead of extra salt', 'Avoid late-night heavy suppers'],
          lifestyleAdvice: ['Perform 30 minutes of aerobic exercise daily', 'Practice deep breathing or pranayama', 'Maintain healthy body weight', 'Avoid smoking and limit alcohol intake'],
          faqs: [
            { question: 'Does beetroot juice really help lower BP?', answer: 'Yes! Beetroot is rich in dietary nitrates, which convert to nitric oxide and dilate blood vessels, lowering blood pressure.' },
            { question: 'Can I replace normal salt with pink rock salt (Sendha Namak)?', answer: 'Sendha Namak contains slightly less sodium and trace minerals, but sodium is still present. Quantity control is key for both.' }
          ]
        }
      },
      Hindi: {
        title: 'उच्च रक्तचाप (हाई बीपी) आहार',
        categoryName: 'बीमारी अनुसार आहार',
        summary: 'कम नमक और पोटेशियम से भरपूर आहार जो प्राकृतिक रूप से ब्लड प्रेशर को नियंत्रित करता है।',
        diseaseDiet: {
          diseaseName: 'हाई ब्लड प्रेशर (उच्च रक्तचाप)',
          summary: 'DASH आहार का पालन करें: नमक (सोडियम) कम करें और पोटेशियम, मैग्नीशियम और कैल्शियम का सेवन बढ़ाएं।',
          foodsToEat: ['पोटेशियम से भरपूर फल और सब्जियां', 'कम वसा वाले डेयरी उत्पाद', 'ओट्स और साबुत अनाज', 'लहसुन और प्राकृतिक जड़ी-बूटियां', 'अलसी के बीज'],
          foodsToAvoid: ['ऊपर से लिया जाने वाला नमक व नमकीन', 'अचार, पापड़ और सोया सॉस', 'पैक्ड सूप व इंस्टेंट नूडल्स', 'रेड मीट व प्रोसेस्ड फूड', 'शराब व अत्यधिक कॉफी'],
          recommendedFruits: ['केला', 'संतरा व मौसम्बी', 'तरबूज', 'अनार', 'जामुन व बेरीज'],
          recommendedVegetables: ['पालक व हरी सब्जियां', 'चुकंदर (बीटरूट)', 'टमाटर', 'शकरकंद', 'लहसुन व प्याज'],
          recommendedDrinks: ['चुकंदर का रस', 'नारियल पानी', 'गुड़हल की चाय (Hibiscus tea)', 'नींबू पानी (बिना नमक)', 'सादा जल'],
          proteinSources: ['दालें और अंकुरित अनाज', 'ताजा दही / छाछ', 'अंडे की सफेदी', 'मछली', 'सोयाबीन'],
          healthySnacks: ['बिना नमक भुना मखाना', 'ताजा फलों की चाट', 'अलसी व कद्दू के बीज', 'खीरा व गाजर'],
          mealTimingTips: ['दिन भर में 1 छोटी चम्मच से अधिक नमक न लें', 'नमक की जगह नींबू या जीरा पाउडर का प्रयोग करें', 'रात का भोजन हल्का रखें'],
          lifestyleAdvice: ['रोजाना 30 मिनट एरोबिक व्यायाम या वॉक करें', 'अनुलोम-विलोम और ध्यान का अभ्यास करें', 'वजन नियंत्रित रखें', 'धूम्रपान व शराब से दूर रहें'],
          faqs: [
            { question: 'क्या चुकंदर का रस बीपी कम करने में असरदार है?', answer: 'हां, चुकंदर में प्राकृतिक नाइट्रेट्स होते हैं जो रक्त वाहिकाओं को चौड़ा करके बीपी तुरंत कम करते हैं।' },
            { question: 'क्या सेंधा नमक खाने से बीपी नहीं बढ़ता?', answer: 'सेंधा नमक में भी सोडियम होता है, इसलिए मात्रा नियंत्रित रखना बहुत जरूरी है।' }
          ]
        }
      },
      Marathi: {
        title: 'रक्तदाब नियंत्रण आहार (High BP Diet)',
        categoryName: 'आजारानुसार आहार',
        summary: 'कमी मीठ आणि पोटॅशियमयुक्त आहार जो नैसर्गिकरीत्या उच्च रक्तदाब नियंत्रित करतो.',
        diseaseDiet: {
          diseaseName: 'उच्च रक्तदाब (High Blood Pressure)',
          summary: 'DASH डाएटचे पालन करा: आहारात मिठाचे प्रमाण कमी करा आणि पोटॅशियम व मॅग्नेशियम वाढवा.',
          foodsToEat: ['पोटॅशियमयुक्त फळे व भाज्या', 'कमी चरबीचे दूध व दही', 'ओट्स व सलग धान्य', 'लसूण व सुगंधी मसाले', 'अळशी व जिरा'],
          foodsToAvoid: ['वरचे मीठ व खारट शेव-चिवडा', 'लोणचे, पापड व सॉस', 'रेडी-टू-ईट नूडल्स व सूप', 'मद्यपान व अति कॉफी', 'प्रोसेस्ड फूड'],
          recommendedFruits: ['केळी', 'संतरी व मोसंबी', 'कलिंगड', 'डाळिंब', 'सफरचंद'],
          recommendedVegetables: ['पालक व लाल माठ', 'बीट (चुकंदर)', 'टोमॅटो', 'रताळे', 'लसूण'],
          recommendedDrinks: ['बीटाचा रस', 'शहाळ्याचे पाणी', 'सदाफुली किंवा जास्वंद चहा', 'लिंबू पाणी (मिठाशिवाय)', 'स्वच्छ पाणी'],
          proteinSources: ['वरण व मूग डाळ', 'ताजे ताक व दही', 'अंड्याचा पांढरा भाग', 'मासे', 'टोफू'],
          healthySnacks: ['विना मीठ भाजलेले मखाने', 'ताजी फळे', 'अळशी व भोपळ्याच्या बिया', 'काकडीच्या फोडी'],
          mealTimingTips: ['दिवसभरात एका लहान चमच्यापेक्षा जास्त मीठ वापरू नका', 'मीठाऐवजी लिंबू किंवा कोकम वापरा', 'रात्री हलका आहार घ्या'],
          lifestyleAdvice: ['दररोज ३० मिनिटे व्यायाम करा', 'प्राणायाम व प्राणायाम करा', 'वजन आटोक्यात ठेवा', 'धूम्रपान पूर्णपणे बंद करा'],
          faqs: [
            { question: 'बीटाचा रस बीपी कमी करतो का?', answer: 'होय, बीटातील नायट्रेट्समुळे रक्तवाहिन्या शिथिल होतात आणि रक्तदाब नियंत्रणात राहतो.' },
            { question: 'सेंधव मीठ बीपीसाठी सुरक्षित आहे का?', answer: 'सेंधव मीठामध्येही सोडियम असते, त्यामुळे तेही मर्यादेतच वापरावे.' }
          ]
        }
      }
    }
  },

  // 3. DENGUE
  {
    id: 'diet-dengue',
    category: 'Disease-wise Diet',
    categoryEmoji: '🦟',
    bgGradient: 'from-emerald-500 to-teal-600',
    badgeBg: 'bg-emerald-50 border-emerald-200',
    badgeText: 'text-emerald-800',
    content: {
      English: {
        title: 'Dengue Recovery Diet Plan',
        categoryName: 'Disease-wise Diet',
        summary: 'A hydration-centric, immunity-boosting diet to support platelet regeneration and overcome fatigue.',
        diseaseDiet: {
          diseaseName: 'Dengue Fever Recovery',
          summary: 'Focus on maximum fluid intake, easy-to-digest carbohydrates, vitamin C, iron, and rich antioxidants.',
          foodsToEat: ['Papaya leaf extract', 'Fresh Coconut water', 'Pomegranate & Kiwi', 'Khichdi & Vegetable Soup', 'Boiled eggs & Curd'],
          foodsToAvoid: ['Oily, fried & spicy foods', 'Processed junk food', 'Caffeinated beverages & carbonated drinks', 'Heavy non-veg meals', 'Dark-colored foods (to avoid mistaking stool color)'],
          recommendedFruits: ['Kiwi (high Vitamin C & antioxidants)', 'Pomegranate (Iron rich)', 'Papaya', 'Oranges', 'Bananas'],
          recommendedVegetables: ['Pumpkin & Bottle Gourd', 'Carrots', 'Spinach (well cooked)', 'Beetroot', 'Boiled potatoes'],
          recommendedDrinks: ['Papaya leaf juice (freshly prepared)', 'Tender Coconut Water', 'ORS solution / Lemonade', 'Warm Clear Soup / Broth', 'Herbal Tulsi-Giloy Kadha'],
          proteinSources: ['Steamed Moong Dal Khichdi', 'Boiled Egg Whites', 'Paneer (Soft/fresh)', 'Curd / Yogurt', 'Soya chunks (well boiled)'],
          healthySnacks: ['Fresh fruit bowl', 'Pomegranate seeds', 'Steamed idli', 'Warm vegetable soup'],
          mealTimingTips: ['Sip fluids every 30-45 minutes', 'Eat small soft meals 5-6 times a day', 'Avoid forcing heavy solid food during acute fever phase'],
          lifestyleAdvice: ['Complete bed rest is mandatory', 'Monitor platelet count as advised by physician', 'Stay hydrated continuously to prevent plasma leakage', 'Consult doctor immediately if warning signs appear'],
          faqs: [
            { question: 'How does Papaya leaf extract help in Dengue?', answer: 'Studies indicate papaya leaf extract contains acetogenins which increase platelet count and boost immunity during dengue.' },
            { question: 'Why is Coconut Water so strongly recommended?', answer: 'Coconut water provides key electrolytes (potassium, sodium, magnesium) preventing dehydration and weakness.' }
          ]
        }
      },
      Hindi: {
        title: 'डेंगू रिकवरी डाइट (Dengue Diet)',
        categoryName: 'बीमारी अनुसार आहार',
        summary: 'प्लेटलेट्स बढ़ाने, डिहाइड्रेशन रोकने और शरीर को ताकत देने वाला सुपाच्य आहार।',
        diseaseDiet: {
          diseaseName: 'डेंगू बुखार रिकवरी',
          summary: 'अधिकतम तरल पदार्थ, आसानी से पचने वाले कार्बोहाइड्रेट, विटामिन सी, आयरन और एंटी-ऑक्सीडेंट्स पर ध्यान दें।',
          foodsToEat: ['पपीते के पत्तों का रस', 'ताजा नारियल पानी', 'अनार और कीवी', 'मूंग दाल खिचड़ी व सूप', 'उबला अंडा और ताजा दही'],
          foodsToAvoid: ['तले-भुने और अत्यधिक मसालेदार भोजन', 'जंक फूड और डिब्बा बंद खाना', 'चाय, कॉफी व कोल्ड ड्रिंक्स', 'भारी नॉन-वेज खाना', 'गहरे रंग की चीजें'],
          recommendedFruits: ['कीवी (विटामिन सी से भरपूर)', 'अनार (आयरन युक्त)', 'पपीता', 'संतरा व मौसम्बी', 'केला'],
          recommendedVegetables: ['लौकी और कद्दू', 'गाजर', 'उबली हुई पालक', 'चुकंदर', 'उबले आलू'],
          recommendedDrinks: ['पपीते के पत्तों का अर्क', 'ताजा नारियल पानी', 'ORS घोल / नींबू पानी', 'सब्जियों का गर्म सूप', 'गिलोय व तुलसी का काढ़ा'],
          proteinSources: ['मूंग दाल की पतली खिचड़ी', 'उबले अंडे की सफेदी', 'नरम पनीर', 'ताजा दही', 'सोयाबीन बड़ी (उबली हुई)'],
          healthySnacks: ['ताजा अनार के दाने', 'उबली इडली', 'गर्म सूप का कप', 'कीवी के स्लाइस'],
          mealTimingTips: ['हर 30-45 मिनट में तरल पदार्थ पिएं', 'दिन में 5-6 बार थोड़ा-थोड़ा नरम भोजन लें', 'तेज बुखार में जबरदस्ती भारी खाना न खाएं'],
          lifestyleAdvice: ['पूर्ण बेड रेस्ट लें', 'डॉक्टर की सलाह अनुसार प्लेटलेट काउंट की जांच कराएं', 'शरीर में पानी की कमी न होने दें', 'कोई भी लक्षण बिगड़ने पर डॉक्टर से तुरंत मिलें'],
          faqs: [
            { question: 'क्या पपीते के पत्तों का रस प्लेटलेट बढ़ाता है?', answer: 'हां, शोध के अनुसार पपीते के पत्तों का अर्क प्लेटलेट्स के निर्माण में तेजी लाता है।' },
            { question: 'डेंगू में नारियल पानी क्यों जरूरी है?', answer: 'नारियल पानी में इलेक्ट्रोलाइट्स होते हैं जो डिहाइड्रेशन और कमजोरी दूर करने में बहुत प्रभावी हैं।' }
          ]
        }
      },
      Marathi: {
        title: 'डेंग्यू रिकव्हरी आहार (Dengue Diet)',
        categoryName: 'आजारानुसार आहार',
        summary: 'प्लेटलेट्स वाढवणारा आणि ताकद देणारा द्रवपदार्थयुक्त सुपाच्य आहार.',
        diseaseDiet: {
          diseaseName: 'डेंग्यू ताप रिकव्हरी',
          summary: 'जास्तीत जास्त द्रवपदार्थ, सहजासहजी पचणारे अन्न, जीवनसत्व सी आणि आर्यनयुक्त फळे आहारात घ्या.',
          foodsToEat: ['पपईच्या पानांचा रस', 'शहाळ्याचे पाणी', 'डाळिंब व किवी', 'मुगाची खिचडी व सूप', 'उकडलेले अंडे व ताक'],
          foodsToAvoid: ['तेलकट, तिखट व मसालेदार पदार्थ', 'जंक फूड व पाकीटबंद अन्न', 'कॉफी, चहा व कोल्ड ड्रिंक्स', 'रात्रीचे जड मांसाहार', 'दारू व धूम्रपान'],
          recommendedFruits: ['किवी (प्लेटलेट वाढीसाठी उत्तम)', 'डाळिंब (रक्त वाढीसाठी)', 'पपई', 'संतरी', 'केळी'],
          recommendedVegetables: ['दुधी भोपळा व तांबडा भोपळा', 'गाजर', 'पालक सूप', 'बीट', 'उकडलेले बटाटे'],
          recommendedDrinks: ['पपईच्या पानांचा अर्क', 'ताजे शहाळ्याचे पाणी', 'ओआरएस (ORS) पाणी', 'व्हेज क्लिअर सूप', 'गिलोय-तुलसी काढा'],
          proteinSources: ['पतली मूग डाळ खिचडी', 'उकडलेल्या अंड्याचा पांढरा भाग', 'नरम पनीर', 'ताजे दही', 'उकडलेला सोयाबीन'],
          healthySnacks: ['डाळिंबाचे दाणे', 'वाफवलेली इडली', 'सूप', 'किवीच्या फोडी'],
          mealTimingTips: ['दर अर्ध्या तासाने थोडे थोडे पाणी किंवा द्रवपदार्थ प्या', 'दिवसातून ५-६ वेळा मऊ अन्न खा', 'ताप असताना जबरदस्तीने जड जेवण करू नका'],
          lifestyleAdvice: ['पूर्ण विश्रांती (Bed Rest) घ्या', 'डॉक्टरांच्या सल्ल्यानुसार प्लेटलेट काउंट तपासा', 'शरीरात पाण्याचे प्रमाण कमी होऊ देऊ नका', 'त्रास वाढल्यास तात्काळ रुग्णालयात जा'],
          faqs: [
            { question: 'पपईच्या पानांचा रस प्लेटलेट्स वाढवतो का?', answer: 'होय, अभ्यासानुसार पपईच्या पानांतील घटकांमुळे प्लेटलेट्स जलद गतीने वाढतात.' },
            { question: 'डेंग्यूमध्ये शहाळ्याचे पाणी का प्यावे?', answer: 'शहाळ्याच्या पाण्यात पोटॅशियम व सोडियम भरपूर असल्याने चक्कर व थकवा दूर होतो.' }
          ]
        }
      }
    }
  },

  // 4. VITAMIN C
  {
    id: 'vit-c',
    category: 'Vitamins & Minerals',
    categoryEmoji: '🍊',
    bgGradient: 'from-orange-500 to-amber-600',
    badgeBg: 'bg-orange-50 border-orange-200',
    badgeText: 'text-orange-800',
    content: {
      English: {
        title: 'Vitamin C (Ascorbic Acid)',
        categoryName: 'Vitamins & Minerals',
        summary: 'A potent water-soluble antioxidant essential for immune defense, collagen synthesis, and iron absorption.',
        vitaminMineral: {
          name: 'Vitamin C (Ascorbic Acid)',
          benefits: ['Boosts white blood cell immunity', 'Promotes collagen for glowing skin & wound healing', 'Enhances non-heme iron absorption from plant foods', 'Neutralizes harmful free radicals'],
          foodSources: ['Indian Gooseberry (Amla)', 'Guava', 'Citrus fruits (Orange, Lemon, Grapefruit)', 'Bell peppers (Capsicum)', 'Kiwi & Strawberries', 'Tomatoes'],
          deficiencySymptoms: ['Bleeding gums & loose teeth (Scurvy)', 'Frequent colds & infections', 'Slow wound healing', 'Dry skin & easy bruising', 'Fatigue and joint pain'],
          dailyRequirement: 'Adult Males: 90 mg/day | Adult Females: 75 mg/day (Smokers need +35 mg extra)'
        }
      },
      Hindi: {
        title: 'विटामिन सी (एस्कॉर्बिक एसिड)',
        categoryName: 'विटामिन और मिनरल्स',
        summary: 'इम्यूनिटी बढ़ाने, त्वचा की रंगत सुधारने और घाव भरने के लिए अनिवार्य शक्तिशाली एंटी-ऑक्सीडेंट।',
        vitaminMineral: {
          name: 'विटामिन सी (Vitamin C)',
          benefits: ['रोग प्रतिरोधक क्षमता (Immunity) को मजबूत करता है', 'कोलेजन बनाकर त्वचा को जवां व घाव जल्दी भरता है', 'पौधों से मिलने वाले आयरन के अवशोषण में मदद करता है', 'कोशिकाओं को नुकसान से बचाता है'],
          foodSources: ['आंवला (सबसे समृद्ध स्रोत)', 'अमरूद', 'खट्टे फल (संतरा, नींबू, मौसम्बी)', 'शिमला मिर्च', 'कीवी और स्ट्रॉबेरी', 'टमाटर'],
          deficiencySymptoms: ['मसूड़ों से खून आना और दांत कमजोर होना (स्कर्वी)', 'बार-बार सर्दी-जुकाम होना', 'घाव का देरी से भरना', 'त्वचा का रूखापन व सुस्ती'],
          dailyRequirement: 'वयस्क पुरुष: 90 मिलीग्राम/दिन | वयस्क महिला: 75 मिलीग्राम/दिन'
        }
      },
      Marathi: {
        title: 'व्हिटॅमिन सी (Vitamin C)',
        categoryName: 'व्हिटॅमिन्स व मिनरल्स',
        summary: 'प्रतिकारशक्ती वाढवण्यासाठी, त्वचेच्या आरोग्यासाठी आणि जखमा भरण्यासाठी अत्यंत महत्त्वाचे जीवनसत्व.',
        vitaminMineral: {
          name: 'व्हिटॅमिन सी (Vitamin C)',
          benefits: ['रोगप्रतिकारक शक्ती मजबूत करते', 'त्वचेचा तजेला वाढवते व जखमा लवकर भरते', 'अन्नातील लोह शोषून घेण्यास मदत करते', 'अँटी-ऑक्सिडंट म्हणून पेशींचे रक्षण करते'],
          foodSources: ['आवळा (सर्वात उत्तम स्त्रोत)', 'पेरू', 'संत्रा, लिंबू व मोसंबी', 'ढोबळी मिरची (Capsicum)', 'किवी व स्ट्रॉबेरी', 'टोमॅटो'],
          deficiencySymptoms: ['हिरड्यांमधून रक्त येणे (स्कर्वी)', 'वारंवार सर्दी व संसर्ग होणे', 'जखमा उशिरा भरणे', 'त्वचा कोरडी पडणे व थकवा'],
          dailyRequirement: 'प्रौढ पुरुष: ९० मिग्रॅ/दिवस | प्रौढ महिला: ७५ मिग्रॅ/दिवस'
        }
      }
    }
  },

  // 5. WEIGHT LOSS DIET
  {
    id: 'weight-loss',
    category: 'Weight Management',
    categoryEmoji: '⚖️',
    bgGradient: 'from-blue-600 to-indigo-700',
    badgeBg: 'bg-blue-50 border-blue-200',
    badgeText: 'text-blue-800',
    content: {
      English: {
        title: 'Healthy Weight Loss Diet',
        categoryName: 'Weight Management',
        summary: 'A sustainable calorie-deficit strategy focused on protein, fiber, and portion control without starvation.',
        weightManagement: {
          title: 'Sustainable Weight Loss Plan',
          bmiInfo: 'Healthy BMI range is 18.5 - 22.9 kg/m² (Asian standards). Aim for a gradual weight loss of 0.5 to 1 kg per week.',
          dietTips: [
            'Maintain a modest calorie deficit (300-500 kcal below daily maintenance)',
            'Prioritize 1.2-1.6g protein per kg body weight to preserve muscle',
            'Fill half your plate with non-starchy vegetables at every meal',
            'Drink 500ml water 30 minutes before major meals to curb overeating',
            'Avoid liquid calories (sodas, sweetened coffees, packed juices)'
          ],
          recommendedFoods: ['Oats, Millets (Ragi, Jowar, Bajra)', 'Lentils, Rajma, Chana', 'Chicken breast, Fish, Eggs', 'Paneer, Curd, Tofu', 'Cruciferous vegetables & Salads'],
          foodsToLimit: ['Deep-fried snacks (Samosa, Pakora)', 'Sugary desserts & chocolates', 'Refined flour products (Maida, White Bread)', 'Alcohol & carbonated sodas', 'Excessive butter and clarified butter (Ghee)']
        }
      },
      Hindi: {
        title: 'वजन घटाने का स्वस्थ आहार (Weight Loss Diet)',
        categoryName: 'वजन प्रबंधन',
        summary: 'कैलोरी डेफिसिट, उच्च प्रोटीन और फाइबर पर आधारित स्थायी वजन घटाने की योजना।',
        weightManagement: {
          title: 'सुरक्षित वजन घटाने का डाइट प्लान',
          bmiInfo: 'एशियाई मानकों के अनुसार स्वस्थ BMI 18.5 - 22.9 kg/m² है। प्रति सप्ताह 0.5 से 1 किलो वजन कम करना सुरक्षित है।',
          dietTips: [
            'दैनिक आवश्यकता से 300-500 कैलोरी कम खाएं (Calorie Deficit)',
            'मांसपेशियों को बचाने के लिए आहार में पर्याप्त प्रोटीन लें',
            'हर भोजन की आधी प्लेट हरी सब्जियों व सलाद से भरें',
            'खाना खाने से 30 मिनट पहले 1-2 गिलास पानी पिएं',
            'मीठे पेय पदार्थों और पैकेज्ड जूस से पूरी तरह बचें'
          ],
          recommendedFoods: ['ओट्स, बाजरा, ज्वार, रागी', 'दालें, राजमा, चना', 'चिकन, मछली, अंडे', 'पनीर, दही, टोफू', 'हरी पत्तेदार सब्जियां व सलाद'],
          foodsToLimit: ['समौसे, पकोड़े और तली हुई चीजें', 'मिठाइयां व चॉकलेट', 'मैदा, पिज्जा, बर्गर', 'कोल्ड ड्रिंक्स व शराब', 'अत्यधिक मक्खन व तेल']
        }
      },
      Marathi: {
        title: 'वजन कमी करण्यासाठी आहार (Weight Loss)',
        categoryName: 'वजन व्यवस्थापन',
        summary: 'कॅलरी डेफिसिट, मुबलक प्रोटीन आणि फायबरवर आधारित निरोगी वजन कमी करण्याचा मार्ग.',
        weightManagement: {
          title: 'सुरक्षित वजन घटवण्याची योजना',
          bmiInfo: 'सामान्य BMI १८.५ ते २२.९ kg/m² मानला जातो. आठवड्याला ०.५ ते १ किलो वजन कमी करणे योग्य ठरते.',
          dietTips: [
            'गरजेपेक्षा ३००-५०० कॅलरीज कमी खा (Calorie Deficit)',
            'स्नायू मजबूत ठेवण्यासाठी आहारात प्रोटीनचे प्रमाण वाढवा',
            'जेवणात अर्धी प्लेट सॅलड आणि भाज्या घ्या',
            'जेवणापूर्वी अर्धा तास आधी २ पेल पाणी प्या',
            'गोड पेय व सॉफ्ट ड्रिंक्स अजिबात पिऊ नका'
          ],
          recommendedFoods: ['ज्वारी, बाजरी, नाचणी, ओट्स', 'मुग, मटकी, चवळी, राजमा', 'अंडी, चिकन, मासे', 'पनीर, ताक, टोफू', 'हिरव्या भाज्या व कोशिंबीर'],
          foodsToLimit: ['तळलेले वडा-पाव, भजी व समोसे', 'मिठाई व साखरेचे पदार्थ', 'मैदा, बिस्किटे, बेकरी प्रॉडक्ट्स', 'दारू व सॉफ्ट ड्रिंक्स', 'अति तेल व तूप']
        }
      }
    }
  },

  // 6. HYDRATION GUIDE
  {
    id: 'hydration-guide',
    category: 'Hydration Guide',
    categoryEmoji: '💧',
    bgGradient: 'from-cyan-500 to-blue-600',
    badgeBg: 'bg-cyan-50 border-cyan-200',
    badgeText: 'text-cyan-800',
    content: {
      English: {
        title: 'Complete Hydration & ORS Guide',
        categoryName: 'Hydration Guide',
        summary: 'Essential rules for daily fluid requirements, electrolyte balance, and managing heat exhaustion.',
        hydration: {
          dailyWaterIntake: 'Adults: 2.5 to 3.5 Liters (8-12 glasses) per day. Requirements increase during physical activity or hot weather.',
          hydrationTips: [
            'Start your morning with 1-2 glasses of warm water',
            'Sip water continuously throughout the day rather than chugging large volumes at once',
            'Monitor urine color: Light straw yellow indicates optimal hydration; dark amber indicates dehydration',
            'Eat water-rich foods like cucumber, watermelon, oranges, and tomatoes',
            'Replenish electrolytes during intense sweating with coconut water or ORS'
          ],
          electrolytesAndOrs: 'Oral Rehydration Salts (ORS) contain precise ratios of glucose, sodium, and potassium to quickly restore electrolyte balance during diarrhea, vomiting, or severe sweating.',
          signsOfDehydration: ['Excessive thirst & dry mouth', 'Dark yellow or concentrated urine', 'Dizziness, confusion, or headache', 'Fatigue and muscle cramps', 'Sunken eyes and dry skin']
        }
      },
      Hindi: {
        title: 'हाइड्रेशन और ओआरएस गाइड (Hydration Guide)',
        categoryName: 'हाइड्रेशन गाइड',
        summary: 'दैनिक जल आवश्यकता, इलेक्ट्रोलाइट संतुलन और डिहाइड्रेशन से बचाव की संपूर्ण जानकारी।',
        hydration: {
          dailyWaterIntake: 'वयस्क: 2.5 से 3.5 लीटर (8-12 गिलास) प्रतिदिन। गर्मी या व्यायाम के दौरान पानी की खपत बढ़ाएं।',
          hydrationTips: [
            'सुबह की शुरुआत 1-2 गिलास गुनगुने पानी से करें',
            'एक बार में बहुत सारा पानी पीने के बजाय दिन भर धीरे-धीरे चुस्की लेकर पानी पिएं',
            'पेशाब के रंग पर ध्यान दें: हल्का पीला रंग सही डिहाइड्रेशन को दर्शाता है, गहरा रंग पानी की कमी बताता है',
            'पानी से भरपूर फल खाएं जैसे खीरा, तरबूज, संतरा व टमाटर',
            'पसीना ज्यादा आने पर नारियल पानी या ORS पिएं'
          ],
          electrolytesAndOrs: 'ORS (ओआरएस) में ग्लूकोज, सोडियम और पोटेशियम का सटीक संतुलन होता है जो दस्त, उल्टी या तेज पसीने में शरीर को तुरंत ऊर्जा व इलेक्ट्रोलाइट्स प्रदान करता है।',
          signsOfDehydration: ['अत्यधिक प्यास और मुंह सूखना', 'गहरे पीले रंग का पेशाब', 'चक्कर आना, सिरदर्द व सुस्ती', 'मांसपेशियों में ऐंठन', 'त्वचा का रूखापन व आंखें धंसना']
        }
      },
      Marathi: {
        title: 'पाणी व ओआरएस मार्गदर्शक (Hydration Guide)',
        categoryName: 'हायड्रेशन मार्गदर्शक',
        summary: 'दररोज लागणारे पाणी, शरीरातील इलेक्ट्रोलाइट्स आणि डिहायड्रेशनवरील उपाय.',
        hydration: {
          dailyWaterIntake: 'प्रौढ व्यक्ती: २.५ ते ३.५ लिटर (८ ते १२ पेले) दररोज. उन्हाळ्यात व व्यायामानंतर जास्त पाणी प्यावे.',
          hydrationTips: [
            'सकाळी उठल्यावर १-२ पेले कोमट पाणी प्यावे',
            'दिवसभरात एकाच वेळी जास्त पाणी न पिता थोडे थोडे पाणी घोट घोट प्यावे',
            'लघवीच्या रंगावरून ओळखा: फिकट पिवळा रंग म्हणजे उत्तम पाणी; गडद पिवळा म्हणजे पाण्याची कमतरता',
            'काकडी, कलिंगड, संत्री व टोमॅटो या पाण्याचे प्रमाण जास्त असलेल्या फळांचे सेवन करा',
            'उन्हात काम करताना किंवा घामाच्या वेळी शहाळ्याचे पाणी अथवा ओआरएस प्यावे'
          ],
          electrolytesAndOrs: 'ओआरएस (ORS) मध्ये ग्लुकोज, सोडियम व पोटॅशियमचे योग्य प्रमाण असते जे अतिसार, उलटी किंवा उष्माघातामध्ये तातडीने ऊर्जा देते.',
          signsOfDehydration: ['खूप तहान लागणे व तोंड सुकणे', 'गडद पिवळी लघवी', 'चक्कर येणे व डोकेदुखी', 'स्नायूंमध्ये गोळा येणे व थकवा', 'त्वचा कोरडी पडणे']
        }
      }
    }
  },

  // 7. IRON & ANEMIA
  {
    id: 'diet-anemia',
    category: 'Disease-wise Diet',
    categoryEmoji: '🩸',
    bgGradient: 'from-purple-600 to-indigo-800',
    badgeBg: 'bg-purple-50 border-purple-200',
    badgeText: 'text-purple-800',
    content: {
      English: {
        title: 'Iron-Rich Anemia Management Diet',
        categoryName: 'Disease-wise Diet',
        summary: 'Dietary guidelines to boost hemoglobin, maximize iron absorption, and fight chronic fatigue.',
        diseaseDiet: {
          diseaseName: 'Anemia (Iron Deficiency)',
          summary: 'Combine iron-rich food sources with Vitamin C to increase absorption, while avoiding tea/coffee near meal times.',
          foodsToEat: ['Jaggery (Gud) & Sesame seeds (Til)', 'Spinach, Fenugreek & Amaranth leaves', 'Beetroot & Carrots', 'Dates, Raisins & Figs', 'Organ meats, Eggs & Fish'],
          foodsToAvoid: ['Tea and Coffee with or immediately after meals (tannins block iron)', 'Calcium supplements taken together with iron meals', 'Excessive bran or high-phytate unfermented grains'],
          recommendedFruits: ['Pomegranate', 'Apples', 'Guava', 'Figs (Anjeer)', 'Black Raisins'],
          recommendedVegetables: ['Spinach (Palak)', 'Beetroot', 'Drumstick leaves', 'Sweet potato', 'Broccoli'],
          recommendedDrinks: ['Beetroot-Carrot juice with Lemon', 'Amla juice', 'Pomegranate smoothie', 'Lemon water (taken with meals)', 'Plain Water'],
          proteinSources: ['Rajma & Black Chana', 'Soybeans & Sprouts', 'Chicken liver & eggs', 'Paneer', 'Garden cress seeds (Halim)'],
          healthySnacks: ['Jaggery & Chana (Gud Chana)', 'Soaked Figs & Raisins', 'Roasted sesame chikki', 'Beetroot cutlet'],
          mealTimingTips: ['Pair every iron-rich meal with a squeeze of lemon juice (Vitamin C improves iron absorption by 3x)', 'Maintain a 1-hour gap between tea/coffee and meals', 'Soak legumes overnight to reduce phytates'],
          lifestyleAdvice: ['Get hemoglobin checked every 3-6 months', 'Take prescribed iron supplements on an empty stomach with Vitamin C', 'Maintain regular physical activity to boost circulation'],
          faqs: [
            { question: 'Why should I avoid drinking tea right after lunch?', answer: 'Tea contains tannins and polyphenols that bind to plant iron (non-heme iron) in the stomach, reducing iron absorption by up to 60%.' },
            { question: 'How do Halim seeds (Garden Cress) help in anemia?', answer: 'Halim seeds are exceptionally rich in iron and folic acid; soaking 1 tsp daily in water or lemon juice boosts hemoglobin fast.' }
          ]
        }
      },
      Hindi: {
        title: 'आयरन से भरपूर एनीमिया आहार (Anemia Diet)',
        categoryName: 'बीमारी अनुसार आहार',
        summary: 'हीमोग्लोबिन बढ़ाने, आयरन का अवशोषण सुधारने और थकान दूर करने की आहार योजना।',
        diseaseDiet: {
          diseaseName: 'एनीमिया (खून की कमी)',
          summary: 'आयरन युक्त खाद्य पदार्थों को विटामिन सी के साथ मिलाकर खाएं और खाने के तुरंत बाद चाय-कॉफी पीने से बचें।',
          foodsToEat: ['गुड़ और तिल', 'पालक, मेथी व चौलाई', 'चुकंदर और गाजर', 'खजूर, मुनक्का व अंजीर', 'अंडे, मछली व कलेजी'],
          foodsToAvoid: ['खाने के साथ या तुरंत बाद चाय/कॉफी (टैनिन आयरन को रोकते हैं)', 'आयरन युक्त भोजन के साथ कैल्शियम की गोलियां लेना', 'अत्यधिक चोकर वाले अनाज'],
          recommendedFruits: ['अनार', 'सेब', 'अमरूद', 'अंजीर', 'काली द्राक्ष (मुनक्का)'],
          recommendedVegetables: ['पालक व हरी पत्तेदार सब्जियां', 'चुकंदर', 'सहजन के पत्ते (मोरिंगा)', 'शकरकंद', 'ब्रोकली'],
          recommendedDrinks: ['चुकंदर-गाजर-नींबू का रस', 'आंवला जूस', 'अनार का जूस', 'नींबू पानी', 'सादा जल'],
          proteinSources: ['राजमा व काला चना', 'सोयाबीन व अंकुरित अनाज', 'अंडे व चिकन', 'पनीर', 'हालिम के बीज'],
          healthySnacks: ['गुड़-चना', 'भीगे हुए खजूर व मुनक्का', 'तिल की चिक्की', 'अंकुरित चाट'],
          mealTimingTips: ['आयरन युक्त भोजन पर नींबू निचोड़ें (विटामिन सी आयरन का अवशोषण 3 गुना बढ़ाता है)', 'चाय/कॉफी और खाने में 1 घंटे का अंतर रखें', 'दालों को रात भर भिगोकर पकाएं'],
          lifestyleAdvice: ['हर 3-6 महीने में हीमोग्लोबिन टेस्ट कराएं', 'डॉक्टर की सलाह से आयरन की गोलियां नींबू पानी के साथ लें', 'हल्का व्यायाम करें'],
          faqs: [
            { question: 'खाने के तुरंत बाद चाय क्यों नहीं पीनी चाहिए?', answer: 'चाय में टैनिन होता है जो भोजन के आयरन से चिपक जाता है और शरीर को आयरन सोखने नहीं देता।' },
            { question: 'हालिम के बीज खून बढ़ाने में कैसे मदद करते हैं?', answer: 'हालिम (Garden Cress) में आयरन और फोलिक एसिड प्रचुर मात्रा में होता है जो हीमोग्लोबिन तेजी से बढ़ाता है।' }
          ]
        }
      },
      Marathi: {
        title: 'अ‍ॅनिमिया व रक्तवाढीसाठी आहार (Anemia Diet)',
        categoryName: 'आजारानुसार आहार',
        summary: 'हिमोग्लोबिन वाढवणारा, अशक्तपणा दूर करणारा आणि लोहाने समृद्ध आहार.',
        diseaseDiet: {
          diseaseName: 'अ‍ॅनिमिया (रक्ताची कमतरता)',
          summary: 'लोहयुक्त पदार्थांसोबत जीवनसत्व सी चे सेवन करा आणि जेवणानंतर लगेच चहा-कॉफी पिणे टाळा.',
          foodsToEat: ['गुळ व तीळ', 'पालक, मेथी व माठ', 'बीट व गाजर', 'खजूर, मनुका व अंजीर', 'अंडी, मासे व मटण'],
          foodsToAvoid: ['जेवणासोबत किंवा जेवणानंतर लगेच चहा/कॉफी पिणे', 'कॅल्शियम आणि आयर्नच्या गोळ्या एकत्र घेणे', 'प्रोसेस्ड बेकरीचे पदार्थ'],
          recommendedFruits: ['डाळिंब', 'सफरचंद', 'पेरू', 'अंजीर', 'काळ्या मनुका'],
          recommendedVegetables: ['पालक व पालेभाज्या', 'बीट (Chukandar)', 'शेवग्याचा पाला', 'रताळे', 'ब्रोकोली'],
          recommendedDrinks: ['बीट-गाजर-लिंबू ज्यूस', 'आवळा रस', 'डाळिंब ज्यूस', 'साजूक ताक', 'स्वच्छ पाणी'],
          proteinSources: ['राजमा व काळे चणे', 'मोड आलेली कडधान्ये', 'अंडी', 'पनीर', 'आहाळीव (Halim seeds)'],
          healthySnacks: ['गुळ-दाणे / गुळ-चणे', 'भिजवलेले खजूर व मनुका', 'तिळाची वडी', 'अळूची वडी'],
          mealTimingTips: ['लोहयुक्त भाजीवर लिंबू पिळा (व्हिटॅमिन सी मुळे लोह लवकर शोषले जाते)', 'चहा आणि जेवणामध्ये १ तासाचे अंतर ठेवा', 'कडधान्ये रात्रभर भिजवून शिजवा'],
          lifestyleAdvice: ['दर ३-६ महिन्यांनी हिमोग्लोबिन तपासा', 'आयर्नच्या गोळ्या डॉक्टरांच्या सल्ल्याने घ्या', 'दररोज हलका व्यायाम करा'],
          faqs: [
            { question: 'जेवणानंतर लगेच चहा का पिऊ नये?', answer: 'चहातील टॅनिन्समुळे अन्नातील लोह शरीरात शोषले जात नाही व रक्ताची कमतरता निर्माण होते.' },
            { question: 'आहाळीव (Halim) खीर का खावी?', answer: 'आहाळीवामध्ये लोह आणि फॉलिक अ‍ॅसिड भरपूर प्रमाणात असल्याने हिमोग्लोबिन जलद गतीने वाढते.' }
          ]
        }
      }
    }
  },

  // 8. PREGNANCY NUTRITION
  {
    id: 'diet-pregnancy',
    category: 'Pregnancy Nutrition',
    categoryEmoji: '🤰',
    bgGradient: 'from-pink-500 to-rose-600',
    badgeBg: 'bg-pink-50 border-pink-200',
    badgeText: 'text-pink-800',
    content: {
      English: {
        title: 'Maternal & Pregnancy Nutrition Guide',
        categoryName: 'Pregnancy Nutrition',
        summary: 'Essential nutrients (Folic acid, Iron, Calcium, DHA) for healthy fetal development and maternal well-being.',
        diseaseDiet: {
          diseaseName: 'Pregnancy & Maternal Health',
          summary: 'Emphasize nutrient quality over simply "eating for two". Ensure adequate folate, iron, calcium, protein, and hydration.',
          foodsToEat: ['Folate-rich greens & lentils', 'Pasteurized dairy (milk, curd, paneer)', 'Well-cooked eggs & lean meats', 'Nuts, seeds & dried fruits', 'Whole grains & sweet potatoes'],
          foodsToAvoid: ['Raw / unpasteurized milk & cheese', 'Undercooked or raw eggs/meat/seafood', 'High-mercury fish (King Mackerel, Shark)', 'Papaya (raw/unripe) & Pineapple in early stages', 'Alcohol, tobacco & excess caffeine'],
          recommendedFruits: ['Apples', 'Pomegranates', 'Bananas (Rich in B6 for morning sickness)', 'Oranges', 'Avocados'],
          recommendedVegetables: ['Spinach & Methi', 'Carrots', 'Sweet potatoes', 'Beetroot', 'Beans & Peas'],
          recommendedDrinks: ['Pasteurized warm Milk with saffron or cardamom', 'Fresh Coconut Water', 'Homemade Buttermilk (Chaas)', 'Fresh fruit smoothies (without added sugar)', 'Plenty of water'],
          proteinSources: ['Well-cooked Dal & Legumes', 'Paneer & Curd', 'Boiled Eggs', 'Chicken breast', 'Tofu'],
          healthySnacks: ['Soaked almonds & walnuts', 'Homemade til-gur or dry fruit laddoos', 'Boiled chana chat', 'Roasted makhana'],
          mealTimingTips: ['Eat 5-6 small, frequent meals to combat nausea and heartburn', 'Keep whole-grain crackers near bed for morning sickness', 'Never go long hours without eating'],
          lifestyleAdvice: ['Take prenatal folic acid and iron/calcium supplements as prescribed', 'Stay active with prenatal yoga or gentle walks', 'Get 8-9 hours of restful sleep daily'],
          faqs: [
            { question: 'Why is Folic Acid so crucial during early pregnancy?', answer: 'Folic acid prevents neural tube defects (NTDs) like spina bifida in the developing baby\'s brain and spinal cord.' },
            { question: 'Is raw papaya dangerous during pregnancy?', answer: 'Unripe or semi-ripe papaya contains latex which can trigger uterine contractions; fully ripe papaya in small amounts is generally fine but consult your doctor.' }
          ]
        }
      },
      Hindi: {
        title: 'गर्भावस्था पोषण निर्देश (Pregnancy Nutrition)',
        categoryName: 'गर्भावस्था पोषण',
        summary: 'गर्भस्थ शिशु के विकास और मां के स्वास्थ्य के लिए आवश्यक पोषक तत्व (फोलिक एसिड, आयरन, कैल्शियम)।',
        diseaseDiet: {
          diseaseName: 'गर्भावस्था और मातृ स्वास्थ्य',
          summary: 'केवल "दो लोगों का खाना" खाने के बजाय भोजन की गुणवत्ता, फोलिक एसिड, आयरन, कैल्शियम और प्रोटीन पर ध्यान दें।',
          foodsToEat: ['फोलिक एसिड युक्त हरी सब्जियां व दालें', 'उबला दूध, दही व पनीर', 'पूरी तरह पके हुए अंडे व चिकन', 'मेवे और सूखे मेवे', 'शकरकंद व साबुत अनाज'],
          foodsToAvoid: ['कच्चा दूध व बिना पाश्चुरीकृत पनीर', 'कच्चा या आधा पका अंडा/मांस', 'उच्च पारा (Mercury) वाली मछली', 'कच्चा पपीता व अनानास', 'शराब, सिगरेट व अत्यधिक चाय-कॉफी'],
          recommendedFruits: ['सेब', 'अनार', 'केला (उल्टी रोकने में मददगार)', 'संतरा', 'नाशपाती'],
          recommendedVegetables: ['पालक व मेथी', 'गाजर', 'शकरकंद', 'चुकंदर', 'बीन्स व मटर'],
          recommendedDrinks: ['केसर/इलायची वाला गुनगुना दूध', 'ताजा नारियल पानी', 'घर की ताजा छाछ', 'फलों की स्मूदी', 'पर्याप्त पानी'],
          proteinSources: ['दालें व राजमा', 'पनीर व ताजा दही', 'उबला अंडा', 'चिकन', 'सोयाबीन'],
          healthySnacks: ['भीगे बादाम-अखरोट', 'ड्राई फ्रूट लड्डू', 'उबला चना', 'मखाना'],
          mealTimingTips: ['जी मिचलाने से बचने के लिए दिन में 5-6 बार थोड़ा-थोड़ा खाएं', 'सुबह उठते ही सूखी टोस्ट या बिस्किट लें', 'ज्यादा देर भूखे न रहें'],
          lifestyleAdvice: ['डॉक्टर द्वारा दी गई फोलिक एसिड व आयरन/कैल्शियम की गोलियां लें', 'हल्की वॉक व प्रेगनेंसी योग करें', '8-9 घंटे की पूरी नींद लें'],
          faqs: [
            { question: 'गर्भावस्था में फोलिक एसिड क्यों जरूरी है?', answer: 'फोलिक एसिड बच्चे के दिमाग और रीढ़ की हड्डी को जन्मजात विकारों (Neural Tube Defects) से बचाता है।' },
            { question: 'क्या गर्भावस्था में कच्चा पपीता हानिकारक है?', answer: 'हां, कच्चे पपीते में लेटेक्स होता है जो गर्भाशय में संकुचन पैदा कर सकता है।' }
          ]
        }
      },
      Marathi: {
        title: 'गर्भावस्थेतील आहार मार्गदर्शक (Pregnancy Nutrition)',
        categoryName: 'गर्भावस्था पोषण',
        summary: 'बाळाच्या सुदृढ विकासासाठी फॉलिक अ‍ॅसिड, लोह, कॅल्शियम आणि प्रोटीनने परिपूर्ण आहार.',
        diseaseDiet: {
          diseaseName: 'गर्भावस्था व माता आरोग्य',
          summary: 'दुपटीने खाण्याऐवजी पौष्टिक घटकांवर भर द्या. फॉलिक अ‍ॅसिड, आयर्न, कॅल्शियम व प्रोटीन नियमित घ्या.',
          foodsToEat: ['पालेभाज्या व मुगाची डाळ', 'दूध, ताजे दही व पनीर', 'पूर्ण शिजवलेली अंडी व चिकन', 'बदाम, अक्रोड व खजूर', 'रताळे व सलग धान्य'],
          foodsToAvoid: ['कच्चे दूध व चीज', 'अधवट शिजवलेले मांस किंवा अंडी', 'कच्ची पपई व अननस', 'दारू, सिगारेट व अति चहा-कॉफी', 'जंक फूड व शिळे अन्न'],
          recommendedFruits: ['सफरचंद', 'डाळिंब', 'केळी (मळमळ कमी करण्यासाठी)', 'संत्री', 'पेरू'],
          recommendedVegetables: ['पालक व मेथी', 'गाजर', 'रताळे', 'बीट', 'फ्लॉवर व मटार'],
          recommendedDrinks: ['वेलची/केशरयुक्त कोमट दूध', 'ताजे शहाळ्याचे पाणी', 'घरातील ताक', 'फळांचा ज्यूस', 'भरपूर पाणी'],
          proteinSources: ['वरण व कडधान्ये', 'पनीर व दही', 'उकडलेले अंडे', 'चिकन', 'सोयाबीन'],
          healthySnacks: ['भिजवलेले बदाम', 'सुक्या मेव्याचे लाडू', 'उकडलेले चणे', 'मखाने'],
          mealTimingTips: ['मळमळ व पित्त टाळण्यासाठी दर २-३ तासांनी थोडे थोडे खा', 'सकाळी उठल्यावर सुका खाऊ (टोस्ट/खाकरा) घ्या', 'दीर्घकाळ उपाशी राहू नका'],
          lifestyleAdvice: ['डॉक्टरांच्या सल्ल्याने फॉलिक अ‍ॅसिड व कॅल्शियमच्या गोळ्या घ्या', 'हलके चालणे व गरोदरपणातील योगासने करा', '८-९ तास शांत झोप घ्या'],
          faqs: [
            { question: 'फॉलिक अ‍ॅसिड का आवश्यक आहे?', answer: 'फॉलिक अ‍ॅसिडमुळे बाळाच्या मेंदूचा व पाठीच्या कण्याचा विकास व्यवस्थित होतो.' },
            { question: 'गर्भावस्थेत पपई का खाऊ नये?', answer: 'अपरिपक्व पपईमधील घटकांमुळे गर्भाशयाचे आकुंचन होऊन धोके निर्माण होऊ शकतात.' }
          ]
        }
      }
    }
  }
];
