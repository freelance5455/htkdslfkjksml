import type { GrammarExercise } from '../types';

export interface CompactDrillPack {
  /** [prompt, options (4), correctIndex, explanationAr] */
  mcq: Array<[string, [string, string, string, string], number, string]>;
  /** [prompt, acceptedAnswers, hint, explanationAr] */
  fill: Array<[string, string[], string, string]>;
  /** [wrongSentence, options (4), wrongIdx, correctedSentence, explanationAr] */
  spot: Array<[string, [string, string, string, string], number, string, string]>;
  /** [targetSentence, explanationAr] */
  reorder: Array<[string, string]>;
}

export const GRAMMAR_EXTRA_DRILLS_PART_1: Record<string, CompactDrillPack> = {
  'verb-to-be': {
    mcq: [
      ['I ___ from Alexandria, not Cairo.', ['is', 'am', 'are', 'be'], 1, 'الضمير I يأخذ am دائماً في المضارع.'],
      ['The keys ___ on the kitchen table.', ['is', 'am', 'are', 'was'], 2, 'الفاعل جمع (The keys) فيأخذ are.'],
      ['___ your brother a software engineer?', ['Are', 'Am', 'Is', 'Be'], 2, 'الفاعل مفرد (your brother = he) فيبدأ السؤال بـ Is.'],
      ['My parents ___ not at home this evening.', ['is', 'am', 'are', 'be'], 2, 'الفاعل جمع (My parents = they) لذا نستخدم are not.'],
      ['That restaurant ___ famous for its seafood.', ['are', 'is', 'am', 'were'], 1, 'الفاعل مفرد (That restaurant = it) فيأخذ is.'],
    ],
    fill: [
      ['Hello! I ___ Omar and this is my friend.', ['am', "'m"], 'am / is / are', 'الضمير I يأخذ am أو الاختصار \'m.'],
      ['The weather ___ very pleasant today.', ['is', "'s"], 'am / is / are', 'كلمة weather غير معدودة وتُعامل معاملة المفرد فتأخذ is.'],
      ['___ they ready for the final presentation?', ['Are'], 'Am / Is / Are', 'مع الضمير they نبدأ السؤال بـ Are.'],
      ['This exercise ___ not difficult at all.', ['is', "isn't"], 'is / are', 'الفاعل مفرد (This exercise) فيأخذ is.'],
    ],
    spot: [
      ['My friends is waiting outside the cinema.', ['My', 'friends', 'is', 'waiting'], 2, 'My friends are waiting outside the cinema.', 'الفاعل جمع (friends) فيحتاج are بدلاً من is.'],
      ['Am you sure about the meeting time?', ['Am', 'you', 'sure', 'time'], 0, 'Are you sure about the meeting time?', 'الضمير you يأخذ Are وليس Am.'],
      ['He are my favorite English teacher.', ['He', 'are', 'favorite', 'teacher'], 1, 'He is my favorite English teacher.', 'الضمير He مفرد ويأخذ is.'],
    ],
    reorder: [
      ['My brother is not at work today.', 'نضع not مباشرة بعد فعل الكون is لتكوين النفي.'],
      ['Is your new apartment near the park?', 'في سؤال نعم/لا نبدأ بـ Is ثم الفاعل ثم التكملة.'],
      ['We are proud of your great progress.', 'الترتيب: الفاعل We ثم are ثم الصفة والتكملة.'],
    ],
  },

  'articles-a-an-the': {
    mcq: [
      ['It took us ___ hour to reach the airport.', ['a', 'an', 'the', '—'], 1, 'حرف h صامت في hour فتبدأ بصوت علة وتأخذ an.'],
      ['She plays ___ piano beautifully.', ['a', 'an', 'the', '—'], 2, 'نستخدم the قبل أسماء الآلات الموسيقية مع الفعل play.'],
      ['He wants to buy ___ useful dictionary.', ['an', 'a', 'the', '—'], 1, 'كلمة useful تبدأ بصوت ساكن /juː/ فتأخذ a وليس an.'],
      ['___ honesty is the foundation of trust.', ['A', 'An', 'The', '—'], 3, 'الأسماء المعنوية العامة لا تأخذ أداة تعريف (zero article).'],
      ['Could you pass me ___ salt next to your plate?', ['a', 'an', 'the', '—'], 2, 'الملح محدد ومعروف بموقعه بجانب طبقك لذا نستخدم the.'],
    ],
    fill: [
      ['My uncle is ___ architect in Dubai.', ['an'], 'a / an / the', 'كلمة architect تبدأ بصوت علة ونذكر المهنة فتأخذ an.'],
      ['We saw ___ elephant at the wildlife sanctuary.', ['an'], 'a / an / the', 'كلمة elephant تبدأ بصوت علة وتُذكر لأول مرة فتأخذ an.'],
      ['___ Nile is the longest river in Africa.', ['The'], 'A / An / The', 'أسماء الأنهار والمحيطات تأخذ أداة التعريف The.'],
      ['She adopted ___ cute puppy last weekend.', ['a'], 'a / an / the', 'نذكر الجرو للمرة الأولى ويبدأ بصوت ساكن (cute) فنستخدم a.'],
    ],
    spot: [
      ['She gave me an useful piece of advice.', ['She', 'an', 'useful', 'advice'], 1, 'She gave me a useful piece of advice.', 'كلمة useful تبدأ بصوت /juː/ الساكن فتأخذ a وليس an.'],
      ['I need a umbrella because it is raining.', ['I', 'a', 'umbrella', 'raining'], 1, 'I need an umbrella because it is raining.', 'كلمة umbrella تبدأ بصوت علة /ʌ/ فتأخذ an.'],
      ['The patience is a very important quality.', ['The', 'patience', 'important', 'quality'], 0, 'Patience is a very important quality.', 'الاسم المعنوي العام patience لا يسبقه The.'],
    ],
    reorder: [
      ['He is an honest and reliable friend.', 'تُوضع an قبل الصفة honest التي تبدأ بصوت علة.'],
      ['The book on the desk belongs to me.', 'نستخدم The لتحديد الكتاب الموجود على المكتب.'],
      ['She drinks coffee every single morning.', 'الاسم غير المعدود بالمعنى العام لا يحتاج أداة.'],
    ],
  },

  'nouns-plural-countable': {
    mcq: [
      ['The dentist checked all of the boy’s ___.', ['tooths', 'teeth', 'tooth', 'teethes'], 1, 'جمع tooth شاذ وهو teeth.'],
      ['Could you give me some ___ about the exam?', ['informations', 'information', 'an information', 'inform'], 1, 'كلمة information غير معدودة ولا تُجمع أبداً.'],
      ['Three ___ were running across the field.', ['mouses', 'mouse', 'mice', 'mices'], 2, 'جمع mouse الشاذ هو mice.'],
      ['We bought new ___ for the living room.', ['furnitures', 'a furniture', 'furniture', 'furnituring'], 2, 'كلمة furniture غير معدودة وتُستخدم بصيغة المفرد دائماً.'],
      ['There are two ___ waiting at the reception.', ['womans', 'woman', 'women', 'womens'], 2, 'جمع woman الشاذ هو women.'],
    ],
    fill: [
      ['The ___ are playing happily in the garden.', ['children'], 'plural of child', 'جمع child الشاذ هو children.'],
      ['Please put those sharp ___ back in the drawer.', ['knives'], 'plural of knife', 'الأسماء المنتهية بـ fe تُقلب إلى ves: knife → knives.'],
      ['My ___ hurt after walking ten kilometers.', ['feet'], 'plural of foot', 'جمع foot الشاذ هو feet.'],
      ['The news ___ very encouraging today.', ['is', 'was'], 'is / are', 'كلمة news غير معدودة وتُعامل دائماً كمفرد فتأخذ is.'],
    ],
    spot: [
      ['She gave me two very helpful advices.', ['She', 'two', 'helpful', 'advices'], 3, 'She gave me two very helpful pieces of advice.', 'كلمة advice غير معدودة ولا يُضاف لها s؛ نقول pieces of advice.'],
      ['All the luggages are already in the car.', ['All', 'luggages', 'already', 'car'], 1, 'All the luggage is already in the car.', 'كلمة luggage غير معدودة ولا تُجمع وتأخذ فعل مفرد is.'],
      ['Many sheeps were grazing on the hillside.', ['Many', 'sheeps', 'grazing', 'hillside'], 1, 'Many sheep were grazing on the hillside.', 'جمع sheep يبقى sheep بدون s.'],
    ],
    reorder: [
      ['This luggage is too heavy to carry.', 'الاسم غير المعدود luggage يأخذ فعل المفرد is.'],
      ['The children have three colorful boxes.', 'نستخدم جمع child (children) وجمع box (boxes).'],
      ['Good advice is worth more than gold.', 'advice اسم غير معدود يأخذ الفعل المفرد is.'],
    ],
  },

  'pronouns-system': {
    mcq: [
      ['Please send the report to Sarah and ___.', ['I', 'me', 'my', 'mine'], 1, 'بعد حرف الجر to نستخدم ضمير المفعول me.'],
      ['That laptop on the desk is ___, not yours.', ['my', 'me', 'mine', 'myself'], 2, 'ضمير الملكية المستقل بدون اسم بعده هو mine.'],
      ['He taught ___ how to code in Python.', ['him', 'his', 'himself', 'he'], 2, 'عندما يكون الفاعل والمفعول نفس الشخص نستخدم الضمير الانعكاسي himself.'],
      ['We enjoyed ___ immensely at the festival.', ['us', 'our', 'ourselves', 'ours'], 2, 'الفعل enjoy يأخذ ضمير انعكاسي للفاعل الجمع we → ourselves.'],
      ['The cat licked ___ paws after eating.', ['it’s', 'its', 'itself', 'it'], 1, 'صفة الملكية لغير العاقل هي its بدون فاصلة عليا.'],
    ],
    fill: [
      ['Did you build this website all by ___?', ['yourself'], 'reflexive pronoun', 'بمعنى بمفردك مع الفاعل you نستخدم yourself.'],
      ['This umbrella belongs to Fatima. It is ___.', ['hers'], 'possessive pronoun', 'ضمير الملكية للمفرد المؤنث بدون اسم بعده هو hers.'],
      ['Our neighbors invited ___ over for dinner.', ['us'], 'object pronoun', 'ضمير المفعول من we هو us.'],
      ['She blamed ___ for forgetting the tickets.', ['herself'], 'reflexive pronoun', 'الضمير الانعكاسي للفاعل she هو herself.'],
    ],
    spot: [
      ['Between you and I, this plan needs work.', ['Between', 'you', 'I', 'plan'], 2, 'Between you and me, this plan needs work.', 'بعد حرف الجر between يجب استخدام ضمير المفعول me وليس I.'],
      ['The company changed it’s logo last year.', ['company', 'changed', "it’s", 'logo'], 2, 'The company changed its logo last year.', 'صفة الملكية هي its بدون فاصلة؛ it’s اختصار it is.'],
      ['They prepared the presentation by theirselves.', ['They', 'prepared', 'presentation', 'theirselves'], 3, 'They prepared the presentation by themselves.', 'الصيغة الصحيحة للضمير الانعكاسي هي themselves وليس theirselves.'],
    ],
    reorder: [
      ['She made this cake by herself.', 'نضع الضمير الانعكاسي herself بعد by للتأكيد على الاعتماد على النفس.'],
      ['That blue backpack over there is mine.', 'ضمير الملكية mine يأتي في نهاية الجملة بدون اسم بعده.'],
      ['Please give him the message right away.', 'ضمير المفعول him يأتي مباشرة بعد الفعل give.'],
    ],
  },

  'demonstratives-there-is': {
    mcq: [
      ['Look at ___ mountains far away on the horizon!', ['this', 'these', 'that', 'those'], 3, 'للجمع البعيد (mountains far away) نستخدم those.'],
      ['___ a pharmacy just around the corner.', ['There are', 'There is', 'They are', 'It has'], 1, 'مع الاسم المفرد (a pharmacy) نستخدم There is.'],
      ['___ any milk left in the fridge?', ['Are there', 'Is there', 'There is', 'Have there'], 1, 'كلمة milk غير معدودة فتُعامل مفرد ونستخدم Is there في السؤال.'],
      ['___ shoes I am wearing right now are super comfy.', ['That', 'Those', 'This', 'These'], 3, 'للجمع القريب (shoes I am wearing) نستخدم These.'],
      ['___ many parks in my hometown.', ['There is', 'There are', 'It is', 'There has'], 1, 'مع الجمع (many parks) نستخدم There are.'],
    ],
    fill: [
      ['___ are twenty students in our English class.', ['There'], 'There / It', 'للتعبير عن الوجود مع الجمع نستخدم There are.'],
      ['Excuse me, is ___ seat next to you taken?', ['that', 'this'], 'this / that', 'للمفرد القريب نستخدم this أو للمفرد البعيد that.'],
      ['There ___ not enough chairs for everyone.', ['are', "aren't"], 'is / are', 'الاسم chairs جمع فيأخذ are.'],
      ['___ books right here on my desk are yours.', ['These'], 'This / These / Those', 'الكتب جمع وقريبة (right here) فتأخذ These.'],
    ],
    spot: [
      ['There is three museums in the old city.', ['There', 'is', 'three', 'museums'], 1, 'There are three museums in the old city.', 'الاسم جمع (three museums) فيجب استخدام There are.'],
      ['These book on the table is fascinating.', ['These', 'book', 'table', 'fascinating'], 0, 'This book on the table is fascinating.', 'book مفرد قريب فيأخذ This بدلاً من These.'],
      ['Have there a train to London at nine?', ['Have', 'there', 'train', 'nine'], 0, 'Is there a train to London at nine?', 'للسؤال عن الوجود نستخدم Is there وليس Have there.'],
    ],
    reorder: [
      ['There are two cafés near the station.', 'نبدأ بـ There are ثم الاسم الجمع والمكان.'],
      ['Is there an elevator in this building?', 'في سؤال الوجود للمفرد نبدأ بـ Is there.'],
      ['Those clouds look dark and heavy today.', 'اسم الإشارة للجمع البعيد Those يسبق الاسم clouds.'],
    ],
  },

  'present-simple': {
    mcq: [
      ['My father ___ the newspaper every morning.', ['read', 'reads', 'reading', 'is read'], 1, 'مع الفاعل المفرد الغائب (He) نضيف s للفعل في المضارع البسيط.'],
      ['___ your sister live in Madrid or Barcelona?', ['Do', 'Does', 'Is', 'Has'], 1, 'في السؤال مع المفرد الغائب نستخدم Does.'],
      ['Water ___ at 100 degrees Celsius.', ['boil', 'boils', 'boiling', 'is boil'], 1, 'الحقائق العلمية تُصاغ بالمضارع البسيط ومع المفرد نضيف s.'],
      ['They ___ drink coffee late at night.', ['doesn’t', 'don’t', 'aren’t', 'not'], 1, 'للنفي مع They نستخدم don’t + الفعل المجرد.'],
      ['She always ___ her homework before dinner.', ['finish', 'finishes', 'finishing', 'finished'], 1, 'الأفعال المنتهية بـ sh تأخذ es مع المفرد الغائب: finishes.'],
    ],
    fill: [
      ['The train to Amman ___ at 7:30 a.m. every day.', ['leaves', 'departs'], 'leave / depart', 'جداول المواعيد الثابتة تستخدم المضارع البسيط مع s للمفرد.'],
      ['He ___ not like spicy food at all.', ['does'], 'do / does', 'مع الفاعل المفرد He نستخدم does not للنفي.'],
      ['How often ___ you practice speaking English?', ['do'], 'do / does', 'مع الضمير you نستخدم do في السؤال.'],
      ['She ___ hard to achieve her medical degree.', ['studies', 'works'], 'study / work', 'الفعل المنتهي بـ y مسبوق بساكن يتحول إلى ies: studies.'],
    ],
    spot: [
      ['Does she works in the marketing department?', ['Does', 'she', 'works', 'department'], 2, 'Does she work in the marketing department?', 'بعد Does يعود الفعل إلى المصدر المجرد بدون s.'],
      ['He don’t know the answer to that question.', ['He', "don’t", 'know', 'question'], 1, "He doesn't know the answer to that question.", 'مع الفاعل المفرد He نستخدم doesn’t وليس don’t.'],
      ['My cousin speak three languages fluently.', ['cousin', 'speak', 'three', 'fluently'], 1, 'My cousin speaks three languages fluently.', 'الفاعل مفرد (My cousin) فيجب إضافة s للفعل speaks.'],
    ],
    reorder: [
      ['She usually wakes up at six thirty.', 'ظرف التكرار usually يأتي قبل الفعل الأساسي wakes.'],
      ['Do you play football on the weekends?', 'نبدأ السؤال بـ Do ثم الفاعل ثم الفعل المجرد.'],
      ['He does not eat fast food anymore.', 'النفي بالمفرد الغائب: does not + الفعل المجرد eat.'],
    ],
  },

  'present-continuous': {
    mcq: [
      ['Listen! Someone ___ the violin upstairs.', ['plays', 'is playing', 'play', 'played'], 1, 'وجود Listen! يدل على حدث يجري لحظة الكلام فنستخدم is playing.'],
      ['We ___ for our flights at the gate right now.', ['wait', 'waits', 'are waiting', 'waited'], 2, 'right now تدل على المضارع المستمر: are waiting.'],
      ['I ___ what you mean, so please continue.', ['am understanding', 'understand', 'understanding', 'is understand'], 1, 'الفعل understand من أفعال الحالة (stative verbs) ولا يأتي مستمراً.'],
      ['What ___ you ___ on this weekend?', ['do / working', 'are / working', 'is / working', 'were / work'], 1, 'للسؤال عن ترتيب حالي أو قريب بالمستمر نستخدم are + V-ing.'],
      ['Look outside — it ___ heavily!', ['snows', 'is snowing', 'snowed', 'snow'], 1, 'Look outside تشير لحدث يقع الآن فنستخدم is snowing.'],
    ],
    fill: [
      ['Be quiet, please. The baby ___ right now.', ['is sleeping', "'s sleeping"], 'sleep', 'الحدث يحدث الآن ومع الفاعل المفرد نستخدم is sleeping.'],
      ['They ___ a new hospital in our neighborhood this year.', ['are building', "'re building"], 'build', 'الأعمال المؤقتة المستمرة حالياً تستخدم are + V-ing.'],
      ['Why ___ she crying? Did something happen?', ['is'], 'am / is / are', 'في سؤال المضارع المستمر مع she نستخدم is.'],
      ['I ___ not watching TV; I am reading a novel.', ['am', "'m"], 'am / is / are', 'مع الضمير I نستخدم am not + V-ing.'],
    ],
    spot: [
      ['I am knowing the manager of that hotel.', ['I', 'am knowing', 'manager', 'hotel'], 1, 'I know the manager of that hotel.', 'الفعل know فعل حالة لا يُستخدم في الزمن المستمر.'],
      ['They is studying for the biology test now.', ['They', 'is', 'studying', 'now'], 1, 'They are studying for the biology test now.', 'الفاعل They جمع فيأخذ are وليس is.'],
      ['She working from home this entire week.', ['She', 'working', 'home', 'week'], 1, 'She is working from home this entire week.', 'لا بد من وجود الفعل المساعد is قبل V-ing.'],
    ],
    reorder: [
      ['Are you listening to the new podcast?', 'في سؤال المستمر نبدأ بـ Are ثم الفاعل ثم V-ing.'],
      ['She is preparing dinner in the kitchen.', 'التركيب: الفاعل + is + V-ing + التكملة.'],
      ['We are not going out in this rain.', 'النفي بالمضارع المستمر: are not + V-ing.'],
    ],
  },

  'past-simple': {
    mcq: [
      ['We ___ a wonderful documentary last night.', ['watch', 'watched', 'watching', 'have watch'], 1, 'last night تدل على الماضي البسيط فنستخدم watched.'],
      ['Where ___ you ___ your keys yesterday?', ['did / leave', 'did / left', 'were / leave', 'do / left'], 0, 'في السؤال بالماضي البسيط نستخدم did + الفعل المجرد leave.'],
      ['She ___ to Paris three years ago.', ['moves', 'moved', 'moving', 'has move'], 1, 'three years ago تحدد وقتاً ماضياً منتهياً فتأخذ الماضي البسيط moved.'],
      ['He ___ not attend the meeting because he was ill.', ['was', 'did', 'does', 'had'], 1, 'نفي الأفعال العادية في الماضي البسيط يكون بـ did not + المصدر.'],
      ['I ___ an old classmate at the mall this morning.', ['meet', 'met', 'meeted', 'meeting'], 1, 'الماضي الشاذ للفعل meet هو met.'],
    ],
    fill: [
      ['They ___ to Turkey for their summer holiday in 2023.', ['went', 'traveled', 'travelled', 'flew'], 'go / travel', 'الفعل الشاذ go يتحول إلى went في الماضي البسيط.'],
      ['Did you ___ the email I sent earlier?', ['receive', 'get', 'read', 'see'], 'receive / get', 'بعد Did يجب أن يكون الفعل في صيغة المصدر المجرد.'],
      ['She ___ a delicious pasta dish for us yesterday.', ['cooked', 'made'], 'cook / make', 'في الماضي البسيط نستخدم cooked أو made.'],
      ['We ___ very tired after the long hike.', ['were'], 'was / were', 'ماضي فعل الكون مع We هو were.'],
    ],
    spot: [
      ['Did he went to the dentist yesterday?', ['Did', 'he', 'went', 'yesterday'], 2, 'Did he go to the dentist yesterday?', 'بعد Did يعود الفعل للمصدر المجرد go وليس went.'],
      ['She buyed a brand new laptop last week.', ['She', 'buyed', 'laptop', 'week'], 1, 'She bought a brand new laptop last week.', 'الفعل buy شاذ وماضيه bought وليس buyed.'],
      ['They didn’t saw the warning sign on the road.', ['They', "didn’t", 'saw', 'sign'], 2, "They didn't see the warning sign on the road.", 'بعد didn’t نستخدم المصدر see وليس saw.'],
    ],
    reorder: [
      ['We visited the ancient museum last Friday.', 'الترتيب: الفاعل + الفعل الماضي + المفعول + ظرف الزمان.'],
      ['Did you enjoy the concert last night?', 'سؤال الماضي البسيط: Did + الفاعل + الفعل المجرد.'],
      ['He did not finish his coffee before leaving.', 'النفي بالماضي: did not + المصدر finish.'],
    ],
  },

  'past-continuous': {
    mcq: [
      ['At 9 p.m. yesterday, I ___ dinner with my family.', ['had', 'was having', 'am having', 'have'], 1, 'وقت محدد في الماضي (At 9 p.m. yesterday) يأخذ الماضي المستمر was having.'],
      ['While they ___ through the park, it started to rain.', ['walked', 'were walking', 'are walking', 'walk'], 1, 'بعد While يأتي الحدث الطويل المستمر: were walking.'],
      ['She dropped her phone while she ___ the bus.', ['boarded', 'was boarding', 'boards', 'is boarding'], 1, 'الحدث المستمر في الخلفية يأخذ الماضي المستمر was boarding.'],
      ['What ___ you doing when the power went out?', ['was', 'were', 'did', 'are'], 1, 'مع الضمير you في الماضي المستمر نستخدم were.'],
      ['He ___ not paying attention during the lecture.', ['were', 'was', 'did', 'is'], 1, 'مع الفاعل المفرد He نستخدم was not + V-ing.'],
    ],
    fill: [
      ['I ___ reading a book when you knocked on the door.', ['was'], 'was / were', 'الضمير I يأخذ was في الماضي المستمر.'],
      ['The kids ___ playing chess while their parents talked.', ['were'], 'was / were', 'الفاعل جمع (The kids) فيأخذ were.'],
      ['While Ali was ___ to work, he heard the news on the radio.', ['driving'], 'drive', 'بعد was نضع الفعل مضافاً إليه ing مع حذف e: driving.'],
      ['It was ___ heavily when we left the theater.', ['raining', 'snowing'], 'rain / snow', 'لوصف خلفية مشهد ماضٍ نستخدم was + V-ing.'],
    ],
    spot: [
      ['They was watching a movie when I arrived.', ['They', 'was', 'watching', 'arrived'], 1, 'They were watching a movie when I arrived.', 'الضمير They يأخذ were وليس was.'],
      ['While I cooked dinner, the phone rang loudly.', ['While', 'cooked', 'dinner', 'rang'], 1, 'While I was cooking dinner, the phone rang loudly.', 'الحدث الطويل بعد While يُصاغ بالماضي المستمر was cooking.'],
      ['What did you doing at midnight yesterday?', ['What', 'did', 'doing', 'yesterday'], 1, 'What were you doing at midnight yesterday?', 'قبل V-ing في السؤال الماضي نستخدم were وليس did.'],
    ],
    reorder: [
      ['I was studying when the phone rang.', 'الحدث الطويل المستمر (was studying) قاطعه حدث قصير (rang).'],
      ['Were they waiting outside in the cold?', 'السؤال بالماضي المستمر يبدأ بـ Were ثم الفاعل ثم V-ing.'],
      ['She was listening to music while painting.', 'حدثان متزامنان في الماضي مع while.'],
    ],
  },

  'future-forms': {
    mcq: [
      ['Look at those dark clouds! It ___ rain soon.', ['will', 'is going to', 'rains', 'rained'], 1, 'التنبؤ المبني على دليل مرئي حاضر يستخدم be going to.'],
      ['Oh, you dropped your books! I ___ help you pick them up.', ['am going to', 'will', 'am helping', 'helped'], 1, 'القرار الفوري وعرض المساعدة اللحظي يستخدمان will.'],
      ['We ___ our dentist at 4 p.m. tomorrow; the appointment is booked.', ['will see', 'are seeing', 'see', 'saw'], 1, 'المواعيد المرتّبة مسبقاً تستخدم المضارع المستمر are seeing.'],
      ['I promise I ___ tell anyone your secret.', ['won’t', 'am not going', 'don’t', 'didn’t'], 0, 'الوعود تستخدم will / won’t + المصدر.'],
      ['She has already decided — she ___ study medicine next year.', ['will', 'is going to', 'studied', 'studies'], 1, 'النية والقرار المسبق يستخدمان be going to.'],
    ],
    fill: [
      ['Don’t worry, I ___ call you as soon as I land.', ['will', "'ll"], 'will / going to', 'للوعد والقرار السريع نستخدم will.'],
      ['We are ___ to launch our new app next month.', ['going'], 'going / will', 'التركيب المخطط له مسبقاً: are going to + المصدر.'],
      ['___ you please open the window? It’s warm here.', ['Will', 'Could', 'Would'], 'Will / Would', 'للطلب المهذب نستخدم Will أو Would.'],
      ['I’m tired. I think I ___ go to bed early tonight.', ['will', "'ll"], 'will / going to', 'مع I think للتنبؤ الشخصي أو القرار الفوري نستخدم will.'],
    ],
    spot: [
      ['She will to travel to Japan next spring.', ['She', 'will', 'to', 'travel'], 2, 'She will travel to Japan next spring.', 'بعد will يأتي الفعل المجرد مباشرة بدون to.'],
      ['They are going buy a new house soon.', ['They', 'going', 'buy', 'house'], 1, 'They are going to buy a new house soon.', 'الصيغة الكاملة هي going to + المصدر.'],
      ['I promise I am calling you tonight.', ['promise', 'am calling', 'you', 'tonight'], 1, 'I promise I will call you tonight.', 'مع الوعود (I promise) نستخدم will + المصدر.'],
    ],
    reorder: [
      ['I will send you the files tonight.', 'المستقبل البسيط: الفاعل + will + المصدر + التكملة.'],
      ['She is going to start a new job.', 'النية المسبقة: is going to + الفعل المجرد.'],
      ['We are meeting the client tomorrow morning.', 'الترتيب المؤكد في المستقبل بالمضارع المستمر.'],
    ],
  },

  'present-perfect': {
    mcq: [
      ['I ___ never ___ sushi before in my life.', ['have / eaten', 'did / eat', 'am / eating', 'has / eaten'], 0, 'تجربة حياتية مع never تأخذ المضارع التام have + V3 (eaten).'],
      ['She has lived in London ___ 2019.', ['for', 'since', 'ago', 'from'], 1, 'مع نقطة بداية زمنية محددة (2019) نستخدم since.'],
      ['Have you finished reading that article ___?', ['already', 'just', 'yet', 'ever'], 2, 'في نهاية السؤال والنفي مع المضارع التام نستخدم yet.'],
      ['They have known each other ___ ten years.', ['since', 'for', 'during', 'ago'], 1, 'مع مدة زمنية كاملة (ten years) نستخدم for.'],
      ['Look! Someone ___ the window.', ['broke', 'has broken', 'breaks', 'is breaking'], 1, 'حدث ماضٍ له أثر واضح في الحاضر يستخدم المضارع التام has broken.'],
    ],
    fill: [
      ['He has ___ finished his homework, so he can rest now.', ['already', 'just'], 'just / already / yet', 'في الجملة المثبتة نضع already أو just بين has و V3.'],
      ['We haven’t seen our cousins ___ last summer.', ['since'], 'for / since', 'last summer نقطة بداية محددة فتأخذ since.'],
      ['Have you ___ visited the Pyramids of Giza?', ['ever'], 'ever / never', 'في السؤال عن التجارب الحياتية نستخدم ever.'],
      ['She ___ written three bestselling novels so far.', ['has'], 'have / has', 'الفاعل المفرد She يأخذ has + V3.'],
    ],
    spot: [
      ['I have saw that movie twice already.', ['I', 'have', 'saw', 'twice'], 2, 'I have seen that movie twice already.', 'بعد have نستخدم التصريف الثالث seen وليس الماضي البسيط saw.'],
      ['He has worked here since five years.', ['He', 'worked', 'since', 'years'], 2, 'He has worked here for five years.', 'خمس سنوات مدة زمنية فتأخذ for وليس since.'],
      ['Have she ever tried rock climbing?', ['Have', 'she', 'tried', 'climbing'], 0, 'Has she ever tried rock climbing?', 'مع الضمير المفرد she نستخدم Has وليس Have.'],
    ],
    reorder: [
      ['Have you ever been to Istanbul?', 'السؤال عن التجربة: Have + الفاعل + ever + V3.'],
      ['She has just arrived at the airport.', 'نضع just بين الفعل المساعد has والتصريف الثالث arrived.'],
      ['We have not decided on a date yet.', 'في النفي نضع yet في نهاية الجملة.'],
    ],
  },

  'present-perfect-continuous': {
    mcq: [
      ['She ___ English for three hours without a break.', ['studies', 'has been studying', 'is studying', 'studied'], 1, 'للتأكيد على استمرار الفعل لمدة زمنية حتى الآن نستخدم has been + V-ing.'],
      ['Your hands are covered in paint! What ___?', ['have you done', 'have you been doing', 'did you do', 'are you doing'], 1, 'أثر واضح لنشاط كان مستمراً للتو يستخدم المضارع التام المستمر.'],
      ['How long ___ you ___ for the bus?', ['have / been waiting', 'are / waiting', 'did / wait', 'has / been waiting'], 0, 'السؤال بـ How long عن نشاط ما زال مستمراً يأخذ have + been + V-ing.'],
      ['It ___ since early this morning, so the streets are wet.', ['rains', 'rained', 'has been raining', 'is raining'], 2, 'مع since وفعل مستمر له أثر الآن نستخدم has been raining.'],
      ['I ___ this car since 2020.', ['have been owning', 'have owned', 'am owning', 'owned'], 1, 'الفعل own فعل حالة لا يأتي مستمراً فنستخدم المضارع التام البسيط have owned.'],
    ],
    fill: [
      ['They have ___ working on this design all week.', ['been'], 'be / been / being', 'التركيب الثابت للمضارع التام المستمر: have/has + been + V-ing.'],
      ['He ___ been learning Arabic since January.', ['has'], 'have / has', 'الفاعل المفرد He يأخذ has been + V-ing.'],
      ['We have been ___ for a new apartment for two months.', ['looking', 'searching'], 'look / search', 'بعد have been نضع الفعل مضافاً له ing.'],
      ['How long has she been ___ at that hospital?', ['working'], 'work', 'بعد has + الفاعل + been نضع V-ing.'],
    ],
    spot: [
      ['She has been work here for six months.', ['She', 'been', 'work', 'months'], 2, 'She has been working here for six months.', 'بعد has been يجب إضافة ing للفعل: working.'],
      ['We have been knowing him since childhood.', ['We', 'been knowing', 'him', 'childhood'], 1, 'We have known him since childhood.', 'الفعل know فعل حالة لا يُستخدم بصيغة مستمرة.'],
      ['How long have he been playing guitar?', ['How', 'have', 'he', 'playing'], 1, 'How long has he been playing guitar?', 'مع الضمير المفرد he نستخدم has وليس have.'],
    ],
    reorder: [
      ['I have been waiting here for an hour.', 'التركيب: الفاعل + have been + V-ing + المدة.'],
      ['She has been training for the marathon.', 'النشاط المستمر حتى الحاضر: has been + V-ing.'],
      ['How long have you been living here?', 'السؤال عن المدة المستمرة: How long + have + الفاعل + been + V-ing.'],
    ],
  },

  'past-perfect': {
    mcq: [
      ['When we reached the station, the train ___ already ___.', ['has / left', 'had / left', 'was / leaving', 'did / leave'], 1, 'الحدث الأقدم قبل حدث ماضٍ آخر يُصاغ بالماضي التام had + V3.'],
      ['She realized she ___ her wallet at home.', ['forgets', 'forgot', 'had forgotten', 'has forgotten'], 2, 'نسيان المحفظة وقع قبل لحظة الإدراك في الماضي فنستخدم had forgotten.'],
      ['By the time he arrived, the guests ___ dinner.', ['had finished', 'have finished', 'finish', 'were finish'], 0, 'عبارة By the time + ماضي بسيط تتبعها جملة بالماضي التام had finished.'],
      ['They were exhausted because they ___ for five hours.', ['had been hiking', 'have been hiking', 'hike', 'are hiking'], 0, 'سبب التعب في الماضي كان نشاطاً مستمراً قبله: الماضي التام المستمر had been hiking.'],
      ['After I ___ the contract, I emailed it back.', ['sign', 'had signed', 'have signed', 'signing'], 1, 'بعد After نضع الحدث الأول بالماضي التام had signed.'],
    ],
    fill: [
      ['Before she moved to Berlin, she ___ never lived abroad.', ['had'], 'has / had', 'قبل حدث ماضٍ نستخدم الماضي التام had.'],
      ['He couldn’t enter because he had ___ his key.', ['lost', 'forgotten'], 'lose / forget', 'بعد had نستخدم التصريف الثالث V3.'],
      ['By 2020, they had ___ three successful companies.', ['built', 'founded', 'launched', 'started'], 'build / start', 'مع By + سنة ماضية نستخدم had + V3.'],
      ['She had been ___ for an hour before the bus finally came.', ['waiting'], 'wait', 'في الماضي التام المستمر نضع V-ing بعد had been.'],
    ],
    spot: [
      ['When I arrived, the film has already started.', ['When', 'arrived', 'has', 'started'], 2, 'When I arrived, the film had already started.', 'في سياق الماضي نستخدم الماضي التام had وليس المضارع التام has.'],
      ['She had went home before the storm began.', ['She', 'had', 'went', 'began'], 2, 'She had gone home before the storm began.', 'بعد had نستخدم التصريف الثالث gone وليس went.'],
      ['He was tired because he has been running.', ['tired', 'because', 'has', 'running'], 2, 'He was tired because he had been running.', 'لأن الجملة في الماضي (was tired) نستخدم had been running.'],
    ],
    reorder: [
      ['The train had left before we arrived.', 'الحدث الأقدم (had left) يسبق الحدث الثاني (arrived).'],
      ['She had never seen snow before that trip.', 'نضع never بين had والتصريف الثالث seen.'],
      ['After he had eaten, he went to sleep.', 'بعد After نضع الماضي التام ثم الماضي البسيط.'],
    ],
  },

  'future-continuous-perfect': {
    mcq: [
      ['This time tomorrow, we ___ over the Mediterranean Sea.', ['fly', 'will be flying', 'will have flown', 'flew'], 1, 'عبارة This time tomorrow تشير لحدث سيكون مستمراً في وقت محدد مستقبلاً: will be + V-ing.'],
      ['By next June, she ___ her master’s degree.', ['will finish', 'will be finishing', 'will have finished', 'finishes'], 2, 'By + وقت مستقبلي تشير لاكتمال الحدث قبل ذلك الوقت: will have + V3.'],
      ['Don’t call at 8 p.m. — I ___ dinner with clients.', ['will have', 'will be having', 'will have had', 'had'], 1, 'حدث سيكون جارياً في تمام الساعة الثامنة مساءً: will be having.'],
      ['By the end of the year, they ___ here for a decade.', ['will live', 'will have lived', 'are living', 'lived'], 1, 'مع By the end of the year نستخدم المستقبل التام will have lived.'],
      ['At noon tomorrow, the team ___ the new bridge.', ['will be testing', 'will tested', 'is tested', 'tested'], 0, 'في نقطة زمنية محددة مستقبلاً نستخدم المستقبل المستمر will be testing.'],
    ],
    fill: [
      ['By 5 o’clock, I will ___ completed the entire report.', ['have'], 'be / have', 'المستقبل التام يتكون من will + have + V3.'],
      ['This time next week, she will ___ relaxing on the beach.', ['be'], 'be / have', 'المستقبل المستمر يتكون من will + be + V-ing.'],
      ['By the time you wake up, we will have ___ the house.', ['left', 'cleaned'], 'leave / clean', 'بعد will have نستخدم التصريف الثالث V3.'],
      ['Will you be ___ the car tonight, or can I borrow it?', ['using'], 'use', 'في سؤال المستقبل المستمر نستخدم V-ing بعد be.'],
    ],
    spot: [
      ['By Friday, we will have finish the project.', ['By', 'will', 'finish', 'project'], 2, 'By Friday, we will have finished the project.', 'بعد will have نستخدم التصريف الثالث finished.'],
      ['This time tomorrow I will be study for finals.', ['tomorrow', 'will', 'study', 'finals'], 2, 'This time tomorrow I will be studying for finals.', 'بعد will be نضع V-ing في المستقبل المستمر.'],
      ['She will has graduated by next autumn.', ['She', 'will', 'has', 'graduated'], 2, 'She will have graduated by next autumn.', 'بعد will نستخدم المصدر have دائماً وليس has.'],
    ],
    reorder: [
      ['By tomorrow, I will have finished the book.', 'المستقبل التام مع By tomorrow: will have + V3.'],
      ['This time next month, we will be traveling.', 'المستقبل المستمر: will be + V-ing.'],
      ['Will you be attending the conference tomorrow?', 'سؤال المستقبل المستمر: Will + الفاعل + be + V-ing.'],
    ],
  },

  'modals-ability-permission': {
    mcq: [
      ['When he was six, he ___ swim across the pool.', ['can', 'could', 'may', 'must'], 1, 'للقدرة العامة في الماضي نستخدم could.'],
      ['Despite the heavy traffic, we ___ reach the airport on time.', ['could', 'were able to', 'can', 'might'], 1, 'للنجاح في موقف محدد صعب بالماضي نستخدم was/were able to وليس could.'],
      ['___ I borrow your charger for a few minutes?', ['May', 'Must', 'Should', 'Need'], 0, 'لطلب الإذن بأسلوب مهذب نستخدم May / Could / Can.'],
      ['After this course, you will ___ speak with confidence.', ['can', 'could', 'be able to', 'able to'], 2, 'بعد will لا نستخدم can بل نستخدم be able to.'],
      ['She ___ speak four languages fluently.', ['cans', 'can', 'is can', 'able'], 1, 'الأفعال الناقصة مثل can لا تأخذ s مع المفرد الغائب.'],
    ],
    fill: [
      ['I’m sorry, I ___ come to the party tonight.', ['cannot', "can't"], 'can / cannot', 'للتعبير عن عدم القدرة في الحاضر نستخدم can’t أو cannot.'],
      ['She was ___ to solve the puzzle in two minutes.', ['able'], 'able / can', 'التركيب الماضي للتمكن من فعل محدد: was able to.'],
      ['___ you help me carry these groceries, please?', ['Could', 'Can', 'Would'], 'Can / Could', 'للطلب المهذب نستخدم Could أو Can.'],
      ['Will they be ___ to join the video call tomorrow?', ['able'], 'able / can', 'بعد will be نستخدم able to للتعبير عن القدرة المستقبلية.'],
    ],
    spot: [
      ['He can plays the guitar very well.', ['He', 'can', 'plays', 'guitar'], 2, 'He can play the guitar very well.', 'بعد can يأتي الفعل في المصدر المجرد بدون s.'],
      ['She will can drive next year.', ['She', 'will', 'can', 'drive'], 2, 'She will be able to drive next year.', 'لا يجتمع will مع can؛ نستخدم will be able to.'],
      ['We couldn’t to find a parking space nearby.', ['We', "couldn’t", 'to', 'find'], 2, "We couldn't find a parking space nearby.", 'لا نضع to بعد couldn’t.'],
    ],
    reorder: [
      ['Could I ask you a quick question?', 'طلب الإذن المهذب: Could + الفاعل + الفعل المجرد.'],
      ['She will be able to join us soon.', 'القدرة في المستقبل: will be able to + المصدر.'],
      ['We were able to catch the last train.', 'النجاح في موقف محدد بالماضي: were able to.'],
    ],
  },

  'modals-obligation-advice': {
    mcq: [
      ['You ___ smoke inside the hospital; it is strictly forbidden.', ['don’t have to', 'mustn’t', 'needn’t', 'should'], 1, 'للمنع والتحريم القاطع نستخدم mustn’t.'],
      ['It’s Saturday tomorrow, so I ___ wake up early.', ['mustn’t', 'don’t have to', 'shouldn’t', 'can’t'], 1, 'لغياب الضرورة (ليس عليك أن) نستخدم don’t have to وليس mustn’t.'],
      ['You look exhausted. You ___ get some rest.', ['should', 'mustn’t', 'don’t have to', 'might not'], 0, 'لتقديم النصيحة نستخدم should + المصدر.'],
      ['Yesterday, I ___ stay late to finish the report.', ['must', 'had to', 'have to', 'should'], 1, 'للإلزام في الماضي نستخدم had to لأن must ليس لها صيغة ماضٍ.'],
      ['You ___ to apologize to him as soon as possible.', ['should', 'must', 'ought', 'can'], 2, 'الفعل الناقص الذي يتبعه to هنا هو ought to.'],
    ],
    fill: [
      ['All passengers ___ fasten their seatbelts during takeoff.', ['must', 'have to'], 'must / have to', 'للقوانين والإلزام القوي نستخدم must أو have to.'],
      ['You ___ eat so much sugar; it’s bad for your teeth.', ["shouldn't", 'should not'], 'should / shouldn’t', 'للنصيحة السلبية نستخدم shouldn’t.'],
      ['Does she ___ to wear a uniform at her new job?', ['have'], 'have / must', 'مع Does في السؤال نستخدم المصدر have to.'],
      ['You ___ not bring anything; we already have plenty of food.', ['need', 'do'], 'need / must', 'لغياب الضرورة نستخدم need not أو do not have to.'],
    ],
    spot: [
      ['You must to submit the form before Friday.', ['You', 'must', 'to', 'submit'], 2, 'You must submit the form before Friday.', 'بعد must يأتي المصدر مباشرة بدون to.'],
      ['We musted leave early yesterday morning.', ['We', 'musted', 'leave', 'yesterday'], 1, 'We had to leave early yesterday morning.', 'لا توجد صيغة musted؛ ماضي الإلزام هو had to.'],
      ['He shoulds drink more water every day.', ['He', 'shoulds', 'drink', 'water'], 1, 'He should drink more water every day.', 'الفعل الناقص should لا يأخذ s مع المفرد.'],
    ],
    reorder: [
      ['You should check your work before submitting.', 'تقديم النصيحة: الفاعل + should + الفعل المجرد.'],
      ['We do not have to work on Sunday.', 'غياب الإلزام: do not have to + المصدر.'],
      ['Students must not use phones during exams.', 'المنع الصارم: must not + الفعل المجرد.'],
    ],
  },

  'modals-deduction-probability': {
    mcq: [
      ['All the lights are off and his car is gone. He ___ be at home.', ['must', 'can’t', 'might', 'should'], 1, 'للاستنتاج المنطقي المستحيل في الحاضر نستخدم can’t be (وليس mustn’t).'],
      ['She just won the championship! She ___ be thrilled.', ['can’t', 'must', 'might not', 'couldn’t'], 1, 'للاستنتاج المؤكد الإيجابي في الحاضر نستخدم must be.'],
      ['The ground is completely wet. It ___ have rained overnight.', ['must', 'can’t', 'shouldn’t', 'would'], 0, 'للاستنتاج القوي حول حدث ماضٍ نستخدم must have + V3.'],
      ['Where is Nadia? She ___ be stuck in traffic, I’m not sure.', ['must', 'can’t', 'might', 'had to'], 2, 'للاحتمال غير المؤكد نستخدم might / may / could.'],
      ['He ___ have stolen the money — he was in another country!', ['must', 'can’t', 'might', 'should'], 1, 'لاستحالة وقوع حدث في الماضي نستخدم can’t / couldn’t have + V3.'],
    ],
    fill: [
      ['She has been working for 12 hours. She ___ be exhausted.', ['must'], 'must / can’t / might', 'الدليل القوي يقود لاستنتاج مؤكد بـ must.'],
      ['He ___ have forgotten about the meeting, or maybe he is late.', ['might', 'may', 'could'], 'might / may / could', 'للاحتمال الماضي نستخدم might / may / could + have + V3.'],
      ['That ___ be Karim — he is currently flying to Tokyo!', ["can't", 'cannot'], 'must / can’t', 'نفي الاستنتاج القوي يكون بـ can’t وليس mustn’t.'],
      ['You must have ___ very proud when your daughter graduated.', ['felt', 'been'], 'feel / be', 'بعد must have نستخدم التصريف الثالث V3.'],
    ],
    spot: [
      ['He mustn’t be the thief; he has a solid alibi.', ['He', "mustn’t", 'thief', 'alibi'], 1, "He can't be the thief; he has a solid alibi.", 'لنفي الاستنتاج نستخدم can’t وليس mustn’t.'],
      ['She must has left her coat in the café.', ['She', 'must', 'has', 'left'], 2, 'She must have left her coat in the café.', 'بعد must نستخدم المصدر have دائماً وليس has.'],
      ['They might went to the wrong address earlier.', ['They', 'might', 'went', 'address'], 2, 'They might have gone to the wrong address earlier.', 'لاستنتاج الماضي نستخدم might have + V3 وليس الماضي البسيط.'],
    ],
    reorder: [
      ['She must be very tired after that flight.', 'الاستنتاج الحاضر المؤكد: must + be + الصفة.'],
      ['He cannot have written this letter alone.', 'استحالة حدث ماضٍ: cannot have + V3.'],
      ['They might have missed the early train.', 'احتمال حدث ماضٍ: might have + V3.'],
    ],
  },

  'used-to-would-rather': {
    mcq: [
      ['I ___ live in a small village, but now I live in the city.', ['am used to', 'used to', 'use to', 'would rather'], 1, 'لعادة أو حالة ماضية انتهت نستخدم used to + المصدر.'],
      ['She is a nurse, so she is ___ working night shifts.', ['used to', 'use to', 'would rather', 'had better'], 0, 'بعد be used to يأتي V-ing بمعنى معتاد على.'],
      ['It’s getting dark. We ___ head back before it rains.', ['would rather', 'had better', 'used to', 'are used to'], 1, 'للتحذير والنصيحة العاجلة نستخدم had better + المصدر.'],
      ['I ___ stay home tonight than go to a noisy club.', ['had better', 'would rather', 'used to', 'get used to'], 1, 'للتفضيل بين خيارين نستخدم would rather ... than.'],
      ['Did you ___ play video games when you were a kid?', ['used to', 'use to', 'using to', 'are used to'], 1, 'بعد Did يعود الفعل للمصدر use to بدون d.'],
    ],
    fill: [
      ['I didn’t ___ to like olives, but now I love them.', ['use'], 'use / used', 'بعد didn’t نستخدم المصدر use to بدون d.'],
      ['He is slowly getting used to ___ on the left side of the road.', ['driving'], 'drive', 'بعد get used to نضع V-ing (اسم الفعل).'],
      ['You had ___ not forget your passport at home.', ['better'], 'better / rather', 'صيغة التحذير المنفي هي had better not + المصدر.'],
      ['I’d ___ have tea than coffee this afternoon.', ['rather'], 'rather / better', 'للتعبير عن التفضيل مع than نستخدم would rather.'],
    ],
    spot: [
      ['She is used to wake up early every day.', ['She', 'used', 'wake', 'early'], 2, 'She is used to waking up early every day.', 'بعد be used to نستخدم V-ing (waking) وليس المصدر.'],
      ['Did they used to live near the coast?', ['Did', 'they', 'used', 'coast'], 2, 'Did they use to live near the coast?', 'بعد Did نكتب use to بدون d.'],
      ['You had better to see a doctor right away.', ['had', 'better', 'to', 'doctor'], 2, 'You had better see a doctor right away.', 'بعد had better يأتي المصدر المجرد مباشرة بدون to.'],
    ],
    reorder: [
      ['I would rather walk than take a taxi.', 'التفضيل: would rather + المصدر + than + المصدر.'],
      ['You had better leave now to avoid traffic.', 'النصيحة العاجلة: had better + المصدر المجرد.'],
      ['She got used to speaking English every day.', 'التأقلم التدريجي: got used to + V-ing.'],
    ],
  },
};
