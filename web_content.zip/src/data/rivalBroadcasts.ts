import { TimeSlotId } from '../types/game';

export interface RivalShowInfo {
  title: string;
  genre: string;
  ratingBase: number;
  hostName: string;
  subtitle: string;
  sceneType: 'novela_luxo' | 'jornal_globo' | 'policial_sensacional' | 'auditorio_povo' | 'futebol_mesa' | 'desenho_retro' | 'filme_hollywood';
}

export const RIVAL_PROGRAMMING: Record<string, Record<TimeSlotId, RivalShowInfo>> = {
  soberana: {
    morning: {
      title: 'Bom Dia Soberana',
      genre: 'Jornalismo Matinal',
      ratingBase: 16.5,
      hostName: 'Renato Furtado',
      subtitle: 'Trânsito congestionado na serra e os destaques da economia.',
      sceneType: 'jornal_globo',
    },
    afternoon: {
      title: 'Vale a Pena Chorar de Novo: Senhora do Destino',
      genre: 'Novela Clássica',
      ratingBase: 18.2,
      hostName: 'Nazaré Tedesco & Protagonistas',
      subtitle: 'Nazaré empurra mais um da escada no casarão de Petrópolis!',
      sceneType: 'novela_luxo',
    },
    primetime: {
      title: 'Novela das 9: Avenida do Ouro',
      genre: 'Supernovela',
      ratingBase: 24.8,
      hostName: 'Carminha de Andrade & Tufão',
      subtitle: 'Você acha que eu tenho medo de você, sua ratazana do lixão?!',
      sceneType: 'novela_luxo',
    },
    latenight: {
      title: 'Tela Quente: Resgate em Los Angeles',
      genre: 'Filme Blockbuster',
      ratingBase: 12.0,
      hostName: 'Ação Hollywoodiana',
      subtitle: 'Explosões no centro financeiro e helicópteros em queda!',
      sceneType: 'filme_hollywood',
    },
  },
  popular: {
    morning: {
      title: 'Bom Dia & Cia com Palhaços',
      genre: 'Infantil & Prêmios',
      ratingBase: 11.5,
      hostName: 'Palhaço Pipoca & Patati',
      subtitle: 'Roda a roleta! Qual é o brinquedo, garotinho de Taboão?!',
      sceneType: 'desenho_retro',
    },
    afternoon: {
      title: 'Brasil em Alerta: Corta pra Mim!',
      genre: 'Policial Sensacionalista',
      ratingBase: 15.0,
      hostName: 'Wagner Datena',
      subtitle: 'Põe na tela! É uma pouca vergonha esse trânsito infernal!',
      sceneType: 'policial_sensacional',
    },
    primetime: {
      title: 'Programa Show do Patrão',
      genre: 'Auditório Popular',
      ratingBase: 16.5,
      hostName: 'Patrão Senor',
      subtitle: 'Quem quer dinheiro?! Um aviãozinho de cem reais pra você!',
      sceneType: 'auditorio_povo',
    },
    latenight: {
      title: 'Pegadinhas Picantes & Câmera Oculta',
      genre: 'Humor & Pegadinhas',
      ratingBase: 8.5,
      hostName: 'Ivo Maluco',
      subtitle: 'A noiva fantasma no cemitério assusta taxista!',
      sceneType: 'auditorio_povo',
    },
  },
  'canal-viva': {
    morning: {
      title: 'Anime Retro: Robôs do Futuro',
      genre: 'Desenho Animado',
      ratingBase: 5.5,
      hostName: 'Animação 90s',
      subtitle: 'Guerreiros do espaço ativam canhões de fótons!',
      sceneType: 'desenho_retro',
    },
    afternoon: {
      title: 'Jogo Aberto: O Debate do Apito',
      genre: 'Debate Esportivo',
      ratingBase: 7.2,
      hostName: 'Craque Neto & Convidados',
      subtitle: 'Esse técnico é uma piada! Não ganha nem par ou ímpar!',
      sceneType: 'futebol_mesa',
    },
    primetime: {
      title: 'Mesa Redonda: O Show da Rodada',
      genre: 'Futebol Ao Vivo',
      ratingBase: 9.0,
      hostName: 'Narrador Galvão Jr.',
      subtitle: 'Olho no lance... que golaço de placa na grande final!',
      sceneType: 'futebol_mesa',
    },
    latenight: {
      title: 'Noite Total: Talk Show Sem Filtro',
      genre: 'Talk Show Humor',
      ratingBase: 4.8,
      hostName: 'Danilo Comédia',
      subtitle: 'Entrevista picante com o cantor de arrocha do momento.',
      sceneType: 'policial_sensacional',
    },
  },
};
