export interface UnitDef {
  id: string;
  name: string;
  symbol: string;
  toBase: number | ((val: number) => number);
  fromBase: number | ((val: number) => number);
}

export interface UnitDomain {
  id: string;
  name: string;
  icon: string;
  baseUnit: string;
  units: UnitDef[];
}

export const UNIT_DOMAINS: UnitDomain[] = [
  {
    id: 'length',
    name: 'Length',
    icon: 'Ruler',
    baseUnit: 'm',
    units: [
      { id: 'm', name: 'Meter', symbol: 'm', toBase: 1, fromBase: 1 },
      { id: 'km', name: 'Kilometer', symbol: 'km', toBase: 1000, fromBase: 0.001 },
      { id: 'cm', name: 'Centimeter', symbol: 'cm', toBase: 0.01, fromBase: 100 },
      { id: 'mm', name: 'Millimeter', symbol: 'mm', toBase: 0.001, fromBase: 1000 },
      { id: 'inch', name: 'Inch', symbol: 'in', toBase: 0.0254, fromBase: 39.3700787 },
      { id: 'ft', name: 'Foot', symbol: 'ft', toBase: 0.3048, fromBase: 3.2808399 },
      { id: 'mile', name: 'Mile', symbol: 'mi', toBase: 1609.344, fromBase: 0.000621371 }
    ]
  },
  {
    id: 'mass',
    name: 'Mass',
    icon: 'Scale',
    baseUnit: 'kg',
    units: [
      { id: 'kg', name: 'Kilogram', symbol: 'kg', toBase: 1, fromBase: 1 },
      { id: 'g', name: 'Gram', symbol: 'g', toBase: 0.001, fromBase: 1000 },
      { id: 'mg', name: 'Milligram', symbol: 'mg', toBase: 1e-6, fromBase: 1e6 },
      { id: 't', name: 'Metric Tonne', symbol: 't', toBase: 1000, fromBase: 0.001 },
      { id: 'lb', name: 'Pound', symbol: 'lb', toBase: 0.45359237, fromBase: 2.20462262 },
      { id: 'oz', name: 'Ounce', symbol: 'oz', toBase: 0.028349523, fromBase: 35.27396 }
    ]
  },
  {
    id: 'time',
    name: 'Time',
    icon: 'Clock',
    baseUnit: 's',
    units: [
      { id: 's', name: 'Second', symbol: 's', toBase: 1, fromBase: 1 },
      { id: 'ms', name: 'Millisecond', symbol: 'ms', toBase: 0.001, fromBase: 1000 },
      { id: 'min', name: 'Minute', symbol: 'min', toBase: 60, fromBase: 1 / 60 },
      { id: 'h', name: 'Hour', symbol: 'h', toBase: 3600, fromBase: 1 / 3600 },
      { id: 'day', name: 'Day', symbol: 'd', toBase: 86400, fromBase: 1 / 86400 }
    ]
  },
  {
    id: 'speed',
    name: 'Speed',
    icon: 'Gauge',
    baseUnit: 'm/s',
    units: [
      { id: 'mps', name: 'Meters per second', symbol: 'm/s', toBase: 1, fromBase: 1 },
      { id: 'kph', name: 'Kilometers per hour', symbol: 'km/h', toBase: 1 / 3.6, fromBase: 3.6 },
      { id: 'mph', name: 'Miles per hour', symbol: 'mph', toBase: 0.44704, fromBase: 2.236936 },
      { id: 'knot', name: 'Knot', symbol: 'kn', toBase: 0.514444, fromBase: 1.94384 }
    ]
  },
  {
    id: 'force',
    name: 'Force',
    icon: 'Compass',
    baseUnit: 'N',
    units: [
      { id: 'n', name: 'Newton', symbol: 'N', toBase: 1, fromBase: 1 },
      { id: 'kn', name: 'Kilonewton', symbol: 'kN', toBase: 1000, fromBase: 0.001 },
      { id: 'lbf', name: 'Pound-force', symbol: 'lbf', toBase: 4.448222, fromBase: 0.224809 },
      { id: 'dyn', name: 'Dyne', symbol: 'dyn', toBase: 1e-5, fromBase: 1e5 }
    ]
  },
  {
    id: 'energy',
    name: 'Energy',
    icon: 'Zap',
    baseUnit: 'J',
    units: [
      { id: 'j', name: 'Joule', symbol: 'J', toBase: 1, fromBase: 1 },
      { id: 'kj', name: 'Kilojoule', symbol: 'kJ', toBase: 1000, fromBase: 0.001 },
      { id: 'wh', name: 'Watt-hour', symbol: 'Wh', toBase: 3600, fromBase: 1 / 3600 },
      { id: 'kwh', name: 'Kilowatt-hour', symbol: 'kWh', toBase: 3.6e6, fromBase: 1 / 3.6e6 },
      { id: 'cal', name: 'Calorie', symbol: 'cal', toBase: 4.184, fromBase: 1 / 4.184 },
      { id: 'btu', name: 'BTU', symbol: 'BTU', toBase: 1055.056, fromBase: 1 / 1055.056 }
    ]
  },
  {
    id: 'power',
    name: 'Power',
    icon: 'Activity',
    baseUnit: 'W',
    units: [
      { id: 'w', name: 'Watt', symbol: 'W', toBase: 1, fromBase: 1 },
      { id: 'kw', name: 'Kilowatt', symbol: 'kW', toBase: 1000, fromBase: 0.001 },
      { id: 'hp', name: 'Horsepower (Mechanical)', symbol: 'hp', toBase: 745.69987, fromBase: 1 / 745.69987 },
      { id: 'mw', name: 'Megawatt', symbol: 'MW', toBase: 1e6, fromBase: 1e-6 }
    ]
  },
  {
    id: 'pressure',
    name: 'Pressure',
    icon: 'CircleDot',
    baseUnit: 'Pa',
    units: [
      { id: 'pa', name: 'Pascal', symbol: 'Pa', toBase: 1, fromBase: 1 },
      { id: 'kpa', name: 'Kilopascal', symbol: 'kPa', toBase: 1000, fromBase: 0.001 },
      { id: 'bar', name: 'Bar', symbol: 'bar', toBase: 100000, fromBase: 1e-5 },
      { id: 'atm', name: 'Atmosphere (Standard)', symbol: 'atm', toBase: 101325, fromBase: 1 / 101325 },
      { id: 'psi', name: 'Pounds per Sq Inch', symbol: 'psi', toBase: 6894.757, fromBase: 1 / 6894.757 }
    ]
  },
  {
    id: 'temperature',
    name: 'Temperature',
    icon: 'Thermometer',
    baseUnit: 'K',
    units: [
      {
        id: 'c',
        name: 'Celsius',
        symbol: '°C',
        toBase: (c: number) => c + 273.15,
        fromBase: (k: number) => k - 273.15
      },
      {
        id: 'f',
        name: 'Fahrenheit',
        symbol: '°F',
        toBase: (f: number) => ((f - 32) * 5) / 9 + 273.15,
        fromBase: (k: number) => ((k - 273.15) * 9) / 5 + 32
      },
      {
        id: 'k',
        name: 'Kelvin',
        symbol: 'K',
        toBase: (k: number) => k,
        fromBase: (k: number) => k
      }
    ]
  },
  {
    id: 'area',
    name: 'Area',
    icon: 'Square',
    baseUnit: 'm²',
    units: [
      { id: 'm2', name: 'Square Meter', symbol: 'm²', toBase: 1, fromBase: 1 },
      { id: 'cm2', name: 'Square Centimeter', symbol: 'cm²', toBase: 0.0001, fromBase: 10000 },
      { id: 'km2', name: 'Square Kilometer', symbol: 'km²', toBase: 1e6, fromBase: 1e-6 },
      { id: 'ft2', name: 'Square Foot', symbol: 'ft²', toBase: 0.092903, fromBase: 10.7639 },
      { id: 'acre', name: 'Acre', symbol: 'ac', toBase: 4046.8564224, fromBase: 1 / 4046.8564224 }
    ]
  },
  {
    id: 'volume',
    name: 'Volume',
    icon: 'Box',
    baseUnit: 'm³',
    units: [
      { id: 'm3', name: 'Cubic Meter', symbol: 'm³', toBase: 1, fromBase: 1 },
      { id: 'l', name: 'Liter', symbol: 'L', toBase: 0.001, fromBase: 1000 },
      { id: 'ml', name: 'Milliliter', symbol: 'mL', toBase: 1e-6, fromBase: 1e6 },
      { id: 'gal', name: 'US Gallon', symbol: 'gal', toBase: 0.00378541, fromBase: 264.172 }
    ]
  }
];

export function convertUnitsLocal(
  val: number,
  category: UnitDomain,
  fromId: string,
  toId: string
): number {
  if (isNaN(val)) return NaN;
  if (fromId === toId) return val;

  const from = category.units.find((u) => u.id === fromId);
  const to = category.units.find((u) => u.id === toId);
  if (!from || !to) return NaN;

  let baseVal = typeof from.toBase === 'function' ? from.toBase(val) : val * from.toBase;
  let finalVal = typeof to.fromBase === 'function' ? to.fromBase(baseVal) : baseVal * to.fromBase;

  return finalVal;
}
