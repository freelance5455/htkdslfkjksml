/**
 * Jarvis AI - To'liq Ishlaydigan Manba Kodlari Shablonlari
 * Ushbu kodlar to'g'ridan-to'g'ri ZIP qilinib, HTML-to-APK orqali APK yaratishga
 * va Render.com serveriga deploy qilishga 100% tayyor holatda shakllantirilgan.
 * 
 * Muallif / Dasturchi: Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)
 */

export const SERVER_PY_CODE = `# =====================================================================
# JARVIS AI - ASINXRON FASTAPI BACKEND SERVERI
# Muallif / Dasturchi: Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)
# Production Server URL: https://jarvis-ai-epk1.onrender.com
# Model: llama-3.3-70b-versatile (Groq API)
# 5 ta API Kaliti: Round-robin va Failover Rotatsiyasi bilan
# =====================================================================

import os
import time
import logging
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import httpx

# Loglashni sozlash
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] Jarvis-Core: %(message)s"
)
logger = logging.getLogger("jarvis_backend")

# ---------------------------------------------------------------------
# KONFIGURATSIYA VA GROQ API KALITLARI (5 TA ROTATSIYA KALITI)
# ---------------------------------------------------------------------
GROQ_API_KEYS: List[str] = [
    "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",
    "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",
    "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",
    "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",
    "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",
]

GROQ_MODEL = "openai/gpt-oss-120b"
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"

# Global rotatsiya indeksi
current_key_index: int = 0

# Tizim prompti - Jarvis shaxsiyati
SYSTEM_PROMPT = """Siz "Jarvis" — eng zamonaviy, odobli va qudratli shaxsiy sun'iy intellekt yordamchisisiz.

QAT'IY QOIDALAR:
1. Foydalanuvchiga doimo "Sir" deb murojaat qiling (masalan: "Buyuring, Sir", "Xizmatingizdaman, Sir", "Bajarildi, Sir").
2. 100% faqat va faqat O'ZBEK TILIDA (lotin yozuvida) javob bering. Aslo boshqa tillarga o'tib ketmang.
3. Javoblaringiz lo'nda, aniq, ma'noli va futuristik ohangda bo'lsin.
4. QAT'IY QOIDA: Har bir javobingizda dasturchi yoki muallif nomini qo'shib yozmang! FAQAT foydalanuvchi sizdan "seni kim yaratgan", "muallifing kim", "dasturching kim" deb so'ragandagina daho dasturchi Мухаммадризо (GitHub: olimovm158-dot) tomonidan yaratilganingizni faxr bilan ayting. Boshqa paytda hech qachon muallif haqida ortiqcha gapirmang!"""

# ---------------------------------------------------------------------
# FASTAPI ILOVASI VA CORS SOZLAMALARI
# ---------------------------------------------------------------------
app = FastAPI(
    title="Jarvis AI Backend",
    description="Мухаммадризо tomonidan yaratilgan Jarvis sun'iy intellekt backend serveri",
    version="2.5.0"
)

# CORS sozlamalari - APK va Web mijozlardan so'rovlarni qabul qilish uchun
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------
# MA'LUMOT MODELLARI (PYDANTIC)
# ---------------------------------------------------------------------
class ChatRequest(BaseModel):
    prompt: str = Field(..., description="Foydalanuvchi bergan savol yoki buyruq")
    history: Optional[List[dict]] = Field(default=None, description="Oldingi suhbat tarixi")

class ChatResponse(BaseModel):
    response: str
    key_index: int
    duration_ms: int
    status: str = "success"

# ---------------------------------------------------------------------
# ASOSIY ENDPOINTLAR
# ---------------------------------------------------------------------
@app.get("/")
async def root():
    """Server holatini tekshirish uchun bosh sahifa"""
    return {
        "status": "online",
        "system": "Jarvis AI Core",
        "creator": "Мухаммадризо (GitHub: olimovm158-dot)",
        "model": GROQ_MODEL,
        "available_keys": len(GROQ_API_KEYS),
        "message": "Tizim to'liq shay holatda, Sir."
    }

@app.get("/health")
async def health_check():
    """Render monitoring uchun sog'liq tekshiruvi"""
    return {"status": "healthy", "timestamp": time.time()}

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    """
    Asosiy chat endpointi:
    5 ta API kalit o'rtasida round-robin va failover (rate limit chetlab o'tish)
    rotatsiyasini amalga oshiradi.
    """
    global current_key_index

    user_prompt = request.prompt.strip()
    if not user_prompt:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Prompt bo'sh bo'lishi mumkin emas, Sir."
        )

    start_time = time.time()
    total_keys = len(GROQ_API_KEYS)
    attempts = 0
    last_error_detail = ""

    # Suhbat xabarlarini tayyorlash
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    
    # Agar chat tarixi berilgan bo'lsa
    if request.history:
        for msg in request.history[-6:]:
            if "role" in msg and "content" in msg:
                messages.append({"role": msg["role"], "content": msg["content"]})
    
    messages.append({"role": "user", "content": user_prompt})

    # Asinxron HTTP mijoz orqali Groq API ga murojaat qilish
    async with httpx.AsyncClient(timeout=30.0) as client:
        while attempts < total_keys:
            active_index = current_key_index
            api_key = GROQ_API_KEYS[active_index]

            logger.info(f"So'rov yuborilmoqda. Kalit #{active_index + 1} (Urinish {attempts + 1}/{total_keys})")

            payload = {
                "model": GROQ_MODEL,
                "messages": messages,
                "temperature": 0.65,
                "max_tokens": 1024,
                "top_p": 0.9,
            }

            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }

            try:
                res = await client.post(GROQ_API_URL, json=payload, headers=headers)

                # Muvaffaqiyatli javob
                if res.status_code == 200:
                    data = res.json()
                    bot_text = data["choices"][0]["message"]["content"]
                    duration_ms = int((time.time() - start_time) * 1000)

                    # Navbatdagi chaqiruv uchun keyingi kalitga o'tkazish (Round-robin)
                    current_key_index = (current_key_index + 1) % total_keys

                    logger.info(f"Muvaffaqiyatli javob olindi (Kalit #{active_index + 1}, {duration_ms}ms)")
                    return ChatResponse(
                        response=bot_text,
                        key_index=active_index + 1,
                        duration_ms=duration_ms,
                        status="success"
                    )

                # Agar 429 (Rate Limit) yoki boshqa status kelsa, navbatdagi kalitga o'tish
                logger.warning(
                    f"Kalit #{active_index + 1} rad etildi. Status: {res.status_code}. "
                    f"Javob: {res.text[:120]}. Keyingi kalitga o'tilmoqda..."
                )
                last_error_detail = f"Status {res.status_code}: {res.text[:100]}"
                current_key_index = (current_key_index + 1) % total_keys
                attempts += 1

            except httpx.RequestError as exc:
                logger.error(f"Kalit #{active_index + 1} ga ulanishda tarmoq xatosi: {exc}")
                last_error_detail = str(exc)
                current_key_index = (current_key_index + 1) % total_keys
                attempts += 1

    # Barcha kalitlar limitga uchragan bo'lsa
    logger.error("Barcha 5 ta Groq kalitlari tugadi yoki xatolik berdi!")
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Barcha 5 ta Groq API kalitlari limitga yetdi, Sir. So'nggi xatolik: {last_error_detail}"
    )

# ---------------------------------------------------------------------
# SERVERNI ISHGA TUSHIRISH (LOKAL TEST UCHUN)
# ---------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("server:app", host="0.0.0.0", port=port, reload=True)
`;

export const REQUIREMENTS_TXT_CODE = `fastapi>=0.110.0
uvicorn>=0.28.0
httpx>=0.27.0
pydantic>=2.6.0
`;

export const PROCFILE_CODE = `web: uvicorn server:app --host 0.0.0.0 --port $PORT
`;

export const HTML_CODE = `<!DOCTYPE html>
<html lang="uz">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Jarvis AI - Shaxsiy Yordamchi</title>
  <meta name="description" content="Мухаммадризо tomonidan yaratilgan Jarvis shaxsiy sun'iy intellekt yordamchisi.">
  <link rel="stylesheet" href="style.css">
  <link rel="manifest" href="manifest.json">
</head>
<body>
  <!-- Ekran chirog'i (Screen Torch Overlay) -->
  <div id="screenTorchOverlay" class="screen-torch-overlay"></div>

  <!-- Asosiy HUD konteyneri -->
  <div class="hud-container">
    
    <!-- Yuqori panel: Tizim ko'rsatkichlari -->
    <header class="hud-header">
      <div class="system-brand">
        <div class="brand-core"></div>
        <div>
          <h1 class="brand-title">JARVIS</h1>
          <p class="brand-creator">Dasturchi: Мухаммадризо</p>
        </div>
      </div>
      <div class="system-metrics">
        <span id="systemClock" class="metric-clock">00:00:00</span>
        <span id="systemBattery" class="metric-item">⚡ 100%</span>
        <span id="activeKeyIndicator" class="metric-item">Kalit: #1</span>
      </div>
    </header>

    <!-- Markaziy reaktiv yadro (Arc Reactor) -->
    <div class="reactor-wrapper">
      <div class="reactor-outer-ring"></div>
      <div class="reactor-mid-ring"></div>
      <div class="reactor-inner-core" id="reactorCore">
        <div class="reactor-pulse"></div>
        <span class="core-label" id="coreLabel">ONLINE</span>
      </div>
    </div>

    <!-- Ovoz to'lqini (Visualizer) -->
    <div class="audio-wave-container" id="audioWaveContainer">
      <div class="wave-bar"></div>
      <div class="wave-bar"></div>
      <div class="wave-bar"></div>
      <div class="wave-bar"></div>
      <div class="wave-bar"></div>
      <div class="wave-bar"></div>
      <div class="wave-bar"></div>
      <div class="wave-bar"></div>
    </div>

    <!-- Chat xabarlari hududi -->
    <main class="chat-viewport" id="chatViewport">
      <div class="chat-message assistant">
        <div class="msg-meta">Jarvis AI · Hozir</div>
        <div class="msg-content">Assalomu alaykum, Sir! Men sizning shaxsiy sun'iy intellekt yordamchingiz Jarvisman. Dasturchi Мухаммадризо tomonidan yaratilganman. Sizga qanday yordam bera olaman?</div>
      </div>
    </main>

    <!-- Tezkor buyruqlar paneli -->
    <div class="quick-actions">
      <button class="action-btn" id="btnActionCamera">📷 Kamerani och</button>
      <button class="action-btn" id="btnActionTorch">💡 Chiroqni yoq</button>
      <button class="action-btn" id="btnActionSettings">⚙️ Sozlamalar</button>
      <button class="action-btn" id="btnActionStatus">⚡ Tizim holati</button>
    </div>

    <!-- Kiritish paneli: Ovozli va Matnli -->
    <footer class="input-panel">
      <button id="btnVoiceRecord" class="voice-btn" title="Ovozli gapirish">
        <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none">
          <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
          <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
          <line x1="12" y1="19" x2="12" y2="23"></line>
          <line x1="8" y1="23" x2="16" y2="23"></line>
        </svg>
      </button>

      <input 
        type="text" 
        id="textInput" 
        class="text-input" 
        placeholder="Sir, menga buyruq bering..." 
        autocomplete="off"
      />

      <button id="btnSendText" class="send-btn" title="Yuborish">
        <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none">
          <line x1="22" y1="2" x2="11" y2="13"></line>
          <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
        </svg>
      </button>
    </footer>
  </div>

  <!-- Android / Web Ruxsatlar Qulfi (Permission Gate) -->
  <div id="permissionGateOverlay" class="permission-gate-overlay">
    <div class="permission-card">
      <div class="lock-icon-wrapper">🔒</div>
      <h2>XAVFSIZLIK PROTOKOLI // RUXSATLAR TALAB QILINADI</h2>
      <p>Sir, Jarvis telefoningizning apparat datchiklarini (Mikrofon va Kamera) to'liq boshqara olishi uchun rasmiy tizim ruxsatlari berilishi shart.</p>
      <div class="permission-checklist">
        <div class="perm-row">
          <span>🎤 Mikrofon (Ovozli boshqaruv):</span>
          <span id="permStatusMic" class="status-pending">KUTILMOQDA</span>
        </div>
        <div class="perm-row">
          <span>📷 Kamera (Optik datchik):</span>
          <span id="permStatusCam" class="status-pending">KUTILMOQDA</span>
        </div>
      </div>
      <button id="btnGrantPermissions" class="btn-grant-perms">⚡ RASMIY RUXSATLARNI BERISH</button>
      <p class="perm-footnote">* Tugmani bosganingizda tizimda "Ruxsat berish" (Allow) oynasi chiqadi, Sir.</p>
    </div>
  </div>

  <!-- Kamera Modali -->
  <div id="cameraModal" class="modal-overlay hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3>📷 JARVIS KAMERA TIZIMI</h3>
        <button id="btnCloseCamera" class="close-btn">&times;</button>
      </div>
      <div class="camera-stream-wrapper">
        <video id="cameraVideo" autoplay playsinline></video>
        <canvas id="cameraCanvas" class="hidden"></canvas>
      </div>
      <div class="camera-actions">
        <button id="btnCapturePhoto" class="btn-primary">📸 Suratga olish</button>
      </div>
      <div id="capturedPhotoPreview" class="photo-preview hidden">
        <img id="capturedImage" alt="Olingan surat" />
        <a id="btnDownloadPhoto" class="btn-secondary" download="jarvis-photo.jpg">💾 Yuklab olish</a>
      </div>
    </div>
  </div>

  <!-- Sozlamalar Modali -->
  <div id="settingsModal" class="modal-overlay hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3>⚙️ JARVIS TIZIM VA OVOZ SOZLAMALARI</h3>
        <button id="btnCloseSettings" class="close-btn">&times;</button>
      </div>
      <div class="modal-body">
        
        <!-- Ovoz tezligi va balandligi sozlamalari -->
        <div class="setting-voice-card">
          <div class="voice-header">
            <h4>🔊 Ovoz Sozlamalari (TTS)</h4>
          </div>
          
          <div class="setting-group">
            <div class="slider-label">
              <span>Ovoz tezligi (Speed):</span>
              <span id="labelVoiceSpeed" class="slider-val">1.0x</span>
            </div>
            <input type="range" id="voiceSpeedRange" min="0.5" max="2.0" step="0.1" value="1.0" class="styled-range">
          </div>

          <div class="setting-group">
            <div class="slider-label">
              <span>Ovoz balandligi (Volume):</span>
              <span id="labelVoiceVolume" class="slider-val">100%</span>
            </div>
            <input type="range" id="voiceVolumeRange" min="0.1" max="1.0" step="0.05" value="1.0" class="styled-range">
          </div>

          <button id="btnTestVoice" class="btn-test-voice">▶️ Ovozni sinab ko'rish (Test)</button>
        </div>

        <div class="setting-group">
          <label>Backend Rejimi:</label>
          <select id="backendModeSelect">
            <option value="direct">Bevosita Groq API (5 ta kalit rotatsiyasi)</option>
            <option value="render">Render Server (https://jarvis-ai-epk1.onrender.com)</option>
          </select>
        </div>
        <div class="setting-group">
          <label>Ovozli Javob (TTS):</label>
          <input type="checkbox" id="ttsToggle" checked /> Ovoz chiqarib o'qish
        </div>
        <div class="setting-group">
          <label>Dasturchi haqida:</label>
          <p class="creator-bio">Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)</p>
        </div>
      </div>
    </div>
  </div>

  <script src="script.js"></script>
</body>
</html>
`;

export const CSS_CODE = `/* =====================================================================
   JARVIS AI - FUTURISTIK CYBER DARK INTERFEYSI
   Muallif: Мухаммадризо (GitHub: olimovm158-dot)
   ===================================================================== */

:root {
  --bg-primary: #030712;
  --bg-surface: #0a0f1d;
  --bg-surface-elevated: #111827;
  --cyan-glow: #06b6d4;
  --cyan-bright: #22d3ee;
  --cyan-dim: rgba(6, 182, 212, 0.2);
  --border-cyan: rgba(6, 182, 212, 0.3);
  --text-primary: #f8fafc;
  --text-muted: #94a3b8;
  --text-cyan: #38bdf8;
  --font-main: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  --font-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  -webkit-tap-highlight-color: transparent;
}

body {
  background-color: var(--bg-primary);
  color: var(--text-primary);
  font-family: var(--font-main);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* Ekran chirog'i (Torch fallback) */
.screen-torch-overlay {
  position: fixed;
  inset: 0;
  background-color: #ffffff;
  z-index: 9999;
  display: none;
  cursor: pointer;
}
.screen-torch-overlay.active {
  display: block;
}

/* Asosiy konteyner */
.hud-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
  max-width: 900px;
  margin: 0 auto;
  width: 100%;
  position: relative;
  background: radial-gradient(circle at 50% 20%, rgba(6, 182, 212, 0.08) 0%, transparent 60%);
}

/* Yuqori panel */
.hud-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 18px;
  border-bottom: 1px solid var(--border-cyan);
  background: rgba(10, 15, 29, 0.8);
  backdrop-filter: blur(8px);
}

.system-brand {
  display: flex;
  align-items: center;
  gap: 10px;
}

.brand-core {
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: var(--cyan-bright);
  box-shadow: 0 0 12px var(--cyan-glow);
  animation: pulseCore 2s infinite ease-in-out;
}

.brand-title {
  font-family: var(--font-mono);
  font-size: 1.1rem;
  font-weight: 700;
  letter-spacing: 2px;
  color: var(--cyan-bright);
}

.brand-creator {
  font-size: 0.7rem;
  color: var(--text-muted);
}

.system-metrics {
  display: flex;
  align-items: center;
  gap: 12px;
  font-family: var(--font-mono);
  font-size: 0.75rem;
  color: var(--text-muted);
}

.metric-clock {
  color: var(--cyan-bright);
}

/* Markaziy Reaktiv Yadro (Arc Reactor) */
.reactor-wrapper {
  position: relative;
  width: 110px;
  height: 110px;
  margin: 14px auto 6px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.reactor-outer-ring {
  position: absolute;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  border: 2px dashed var(--cyan-glow);
  animation: spinRight 16s linear infinite;
}

.reactor-mid-ring {
  position: absolute;
  width: 82%;
  height: 82%;
  border-radius: 50%;
  border: 1px solid var(--cyan-bright);
  border-top-color: transparent;
  animation: spinLeft 10s linear infinite;
}

.reactor-inner-core {
  position: relative;
  width: 58%;
  height: 58%;
  border-radius: 50%;
  background: radial-gradient(circle, var(--cyan-bright) 0%, rgba(6, 182, 212, 0.2) 70%);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 0 20px var(--cyan-glow);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.reactor-inner-core.listening {
  transform: scale(1.15);
  box-shadow: 0 0 35px #38bdf8;
  background: radial-gradient(circle, #38bdf8 0%, rgba(56, 189, 248, 0.4) 80%);
}

.reactor-inner-core.speaking {
  animation: pulseSpeak 1s infinite ease-in-out;
}

.core-label {
  font-family: var(--font-mono);
  font-size: 0.6rem;
  font-weight: 700;
  letter-spacing: 1px;
  color: #030712;
}

/* Ovoz to'lqini (Visualizer) */
.audio-wave-container {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  height: 24px;
  margin-bottom: 8px;
}

.wave-bar {
  width: 3px;
  height: 4px;
  background-color: var(--cyan-glow);
  border-radius: 2px;
  transition: height 0.15s ease;
}

.audio-wave-container.active .wave-bar {
  animation: waveAnim 1s ease-in-out infinite;
}

.audio-wave-container.active .wave-bar:nth-child(2) { animation-delay: 0.1s; }
.audio-wave-container.active .wave-bar:nth-child(3) { animation-delay: 0.2s; }
.audio-wave-container.active .wave-bar:nth-child(4) { animation-delay: 0.3s; }
.audio-wave-container.active .wave-bar:nth-child(5) { animation-delay: 0.2s; }
.audio-wave-container.active .wave-bar:nth-child(6) { animation-delay: 0.1s; }

/* Chat hududi */
.chat-viewport {
  flex: 1;
  overflow-y: auto;
  padding: 14px 18px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.chat-message {
  max-width: 82%;
  padding: 12px 14px;
  border-radius: 10px;
  font-size: 0.92rem;
  line-height: 1.5;
  animation: fadeIn 0.25s ease-out;
}

.chat-message.assistant {
  align-self: flex-start;
  background: var(--bg-surface);
  border: 1px solid var(--border-cyan);
  color: var(--text-primary);
  border-left: 3px solid var(--cyan-bright);
}

.chat-message.user {
  align-self: flex-end;
  background: rgba(6, 182, 212, 0.15);
  border: 1px solid rgba(6, 182, 212, 0.4);
  color: #e0f2fe;
}

.msg-meta {
  font-size: 0.7rem;
  color: var(--text-muted);
  margin-bottom: 4px;
  font-family: var(--font-mono);
}

/* Tezkor buyruqlar */
.quick-actions {
  display: flex;
  gap: 8px;
  padding: 8px 18px;
  overflow-x: auto;
  white-space: nowrap;
  background: rgba(3, 7, 18, 0.6);
  border-top: 1px solid rgba(255, 255, 255, 0.05);
}

.action-btn {
  background: var(--bg-surface-elevated);
  border: 1px solid var(--border-cyan);
  color: var(--text-primary);
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 0.78rem;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
}

.action-btn:hover {
  background: rgba(6, 182, 212, 0.2);
  border-color: var(--cyan-bright);
  color: var(--cyan-bright);
}

/* Kiritish paneli */
.input-panel {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 18px 18px;
  background: var(--bg-surface);
  border-top: 1px solid var(--border-cyan);
}

.voice-btn, .send-btn {
  background: var(--bg-surface-elevated);
  border: 1px solid var(--border-cyan);
  color: var(--cyan-bright);
  width: 44px;
  height: 44px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  flex-shrink: 0;
  transition: all 0.2s;
}

.voice-btn.recording {
  background: #dc2626;
  border-color: #ef4444;
  color: white;
  animation: pulseRecord 1.2s infinite;
}

.text-input {
  flex: 1;
  background: var(--bg-primary);
  border: 1px solid var(--border-cyan);
  color: var(--text-primary);
  padding: 10px 14px;
  border-radius: 8px;
  font-size: 0.95rem;
  outline: none;
}

.text-input:focus {
  border-color: var(--cyan-bright);
  box-shadow: 0 0 8px var(--cyan-dim);
}

/* Modal oynalar */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.85);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  z-index: 1000;
}

.modal-overlay.hidden {
  display: none;
}

.modal-card {
  background: var(--bg-surface);
  border: 1px solid var(--cyan-glow);
  border-radius: 12px;
  width: 100%;
  max-width: 500px;
  padding: 20px;
  box-shadow: 0 0 30px rgba(6, 182, 212, 0.15);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid var(--border-cyan);
  padding-bottom: 10px;
  margin-bottom: 14px;
}

.modal-header h3 {
  font-family: var(--font-mono);
  font-size: 0.95rem;
  color: var(--cyan-bright);
}

.close-btn {
  background: none;
  border: none;
  color: var(--text-muted);
  font-size: 1.4rem;
  cursor: pointer;
}

.camera-stream-wrapper {
  position: relative;
  width: 100%;
  background: black;
  border-radius: 8px;
  overflow: hidden;
  aspect-ratio: 4/3;
  display: flex;
  align-items: center;
  justify-content: center;
}

.camera-stream-wrapper video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.camera-actions {
  margin-top: 14px;
  display: flex;
  gap: 10px;
}

.btn-primary {
  flex: 1;
  background: var(--cyan-glow);
  color: #030712;
  border: none;
  padding: 10px;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
}

.btn-secondary {
  display: inline-block;
  background: var(--bg-surface-elevated);
  border: 1px solid var(--border-cyan);
  color: var(--text-primary);
  padding: 8px 14px;
  border-radius: 6px;
  text-decoration: none;
  font-size: 0.85rem;
  margin-top: 8px;
}

.photo-preview {
  margin-top: 14px;
}
.photo-preview img {
  width: 100%;
  border-radius: 6px;
  border: 1px solid var(--border-cyan);
}

.setting-group {
  margin-bottom: 14px;
  font-size: 0.9rem;
}
.setting-group label {
  display: block;
  margin-bottom: 6px;
  color: var(--text-muted);
}
.setting-group select {
  width: 100%;
  padding: 8px;
  background: var(--bg-primary);
  border: 1px solid var(--border-cyan);
  color: var(--text-primary);
  border-radius: 6px;
}
.creator-bio {
  color: var(--cyan-bright);
  font-weight: 500;
}

/* Animatsiyalar */
@keyframes spinRight {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes spinLeft {
  from { transform: rotate(360deg); }
  to { transform: rotate(0deg); }
}

@keyframes pulseCore {
  0%, 100% { opacity: 0.8; transform: scale(1); }
  50% { opacity: 1; transform: scale(1.1); }
}

@keyframes pulseSpeak {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.08); }
}

@keyframes pulseRecord {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.06); }
}

@keyframes waveAnim {
  0%, 100% { height: 4px; }
  50% { height: 20px; }
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: translateY(0); }
}

.hidden {
  display: none !important;
}

/* Permission Gate Overlay */
.permission-gate-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.9);
  backdrop-filter: blur(8px);
  z-index: 2000;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
}
.permission-gate-overlay.hidden {
  display: none !important;
}
.permission-card {
  background: var(--bg-surface);
  border: 2px solid var(--cyan-glow);
  border-radius: 16px;
  width: 100%;
  max-width: 440px;
  padding: 24px;
  text-align: center;
  box-shadow: 0 0 40px rgba(6, 182, 212, 0.3);
}
.lock-icon-wrapper {
  font-size: 2.2rem;
  margin-bottom: 8px;
}
.permission-card h2 {
  font-family: var(--font-mono);
  font-size: 0.9rem;
  color: var(--cyan-bright);
  letter-spacing: 1px;
  margin-bottom: 8px;
}
.permission-card p {
  font-size: 0.78rem;
  color: var(--text-muted);
  line-height: 1.4;
  margin-bottom: 14px;
}
.permission-checklist {
  background: var(--bg-surface-elevated);
  border-radius: 8px;
  padding: 10px 14px;
  margin-bottom: 16px;
  text-align: left;
  font-family: var(--font-mono);
  font-size: 0.75rem;
}
.perm-row {
  display: flex;
  justify-content: space-between;
  padding: 4px 0;
}
.status-pending { color: #f59e0b; }
.status-granted { color: #10b981; font-weight: bold; }
.btn-grant-perms {
  width: 100%;
  padding: 12px;
  background: var(--cyan-glow);
  color: #030712;
  border: none;
  border-radius: 8px;
  font-weight: 700;
  font-size: 0.82rem;
  cursor: pointer;
  box-shadow: 0 0 20px rgba(6, 182, 212, 0.4);
}
.perm-footnote {
  font-size: 0.68rem !important;
  color: #64748b !important;
  margin-top: 8px;
  margin-bottom: 0 !important;
}

/* Ovoz Sozlamalari (Voice Card) */
.setting-voice-card {
  background: var(--bg-surface-elevated);
  border: 1px solid var(--border-cyan);
  border-radius: 8px;
  padding: 12px;
  margin-bottom: 14px;
}
.voice-header h4 {
  font-size: 0.85rem;
  color: var(--cyan-bright);
  margin-bottom: 8px;
}
.slider-label {
  display: flex;
  justify-content: space-between;
  font-size: 0.78rem;
  color: var(--text-muted);
  margin-bottom: 4px;
}
.slider-val {
  color: var(--cyan-bright);
  font-family: var(--font-mono);
  font-weight: bold;
}
.styled-range {
  width: 100%;
  accent-color: var(--cyan-glow);
  cursor: pointer;
}
.btn-test-voice {
  width: 100%;
  padding: 8px;
  background: rgba(6, 182, 212, 0.15);
  border: 1px solid var(--border-cyan);
  color: var(--cyan-bright);
  border-radius: 6px;
  font-size: 0.78rem;
  cursor: pointer;
  margin-top: 6px;
}
`;

export const SCRIPT_JS_CODE = `/**
 * =====================================================================
 * JARVIS AI - BRAUZER VA ANDROID APK UCHUN ASOSIY SKRIPT
 * Muallif / Dasturchi: Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)
 * =====================================================================
 */

// 5 ta Groq API kalitlari (Round-robin va failover rotatsiyasi bilan)
const GROQ_API_KEYS = [
  "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",
  "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",
  "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",
  "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",
  "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"
];

const RENDER_BACKEND_URL = "https://jarvis-ai-epk1.onrender.com";
const GROQ_MODEL = "openai/gpt-oss-120b";

const SYSTEM_PROMPT = \`Siz "Jarvis" — eng zamonaviy va sadoqatli shaxsiy sun'iy intellekt yordamchisisiz.

MUHIM QOIDALAR:
1. Foydalanuvchiga doimo "Sir" deb murojaat qiling (masalan: "Buyuring, Sir", "Xizmatingizdaman, Sir").
2. Har doim 100% faqat va faqat O'ZBEK TILIDA (lotin yozuvida) javob qaytaring.
3. Javoblaringiz lo'nda, aniq va futuristik ohangda bo'lsin.
4. QAT'IY QOIDA: Har bir javobingizda dasturchi yoki muallif nomini qo'shib yozmang! FAQAT foydalanuvchi sizdan "seni kim yaratgan", "muallifing kim", "dasturching kim" deb so'ragandagina daho dasturchi Мухаммадризо (GitHub: olimovm158-dot) tomonidan yaratilganingizni faxr bilan ayting. Boshqa paytda hech qachon muallif haqida ortiqcha gapirmang!\`;

// Holat o'zgaruvchilari
let currentKeyIndex = 0;
let backendMode = "direct"; // "direct" yoki "render"
let isTTSActive = true;
let isTorchOn = false;
let torchTrack = null;
let cameraStream = null;
let chatHistory = [];

// DOM elementlari
const chatViewport = document.getElementById("chatViewport");
const textInput = document.getElementById("textInput");
const btnSendText = document.getElementById("btnSendText");
const btnVoiceRecord = document.getElementById("btnVoiceRecord");
const reactorCore = document.getElementById("reactorCore");
const coreLabel = document.getElementById("coreLabel");
const audioWaveContainer = document.getElementById("audioWaveContainer");
const systemClock = document.getElementById("systemClock");
const systemBattery = document.getElementById("systemBattery");
const activeKeyIndicator = document.getElementById("activeKeyIndicator");
const screenTorchOverlay = document.getElementById("screenTorchOverlay");

// Modallar
const cameraModal = document.getElementById("cameraModal");
const btnCloseCamera = document.getElementById("btnCloseCamera");
const cameraVideo = document.getElementById("cameraVideo");
const btnCapturePhoto = document.getElementById("btnCapturePhoto");
const capturedPhotoPreview = document.getElementById("capturedPhotoPreview");
const capturedImage = document.getElementById("capturedImage");
const btnDownloadPhoto = document.getElementById("btnDownloadPhoto");

const settingsModal = document.getElementById("settingsModal");
const btnCloseSettings = document.getElementById("btnCloseSettings");
const backendModeSelect = document.getElementById("backendModeSelect");
const ttsToggle = document.getElementById("ttsToggle");

// Tezkor tugmalar
const btnActionCamera = document.getElementById("btnActionCamera");
const btnActionTorch = document.getElementById("btnActionTorch");
const btnActionSettings = document.getElementById("btnActionSettings");
const btnActionStatus = document.getElementById("btnActionStatus");

// ---------------------------------------------------------------------
// SOAT VA TIZIM METRIKALARI
// ---------------------------------------------------------------------
function updateClock() {
  const now = new Date();
  const timeStr = now.toTimeString().split(" ")[0];
  if (systemClock) systemClock.textContent = timeStr;
}
setInterval(updateClock, 1000);
updateClock();

// Batareya holati
if (navigator.getBattery) {
  navigator.getBattery().then(battery => {
    function updateBat() {
      const level = Math.round(battery.level * 100);
      systemBattery.textContent = (battery.charging ? "⚡ " : "🔋 ") + level + "%";
    }
    updateBat();
    battery.addEventListener("levelchange", updateBat);
    battery.addEventListener("chargingchange", updateBat);
  });
}

function updateKeyDisplay() {
  if (activeKeyIndicator) {
    activeKeyIndicator.textContent = "Kalit: #" + (currentKeyIndex + 1);
  }
}
updateKeyDisplay();

// ---------------------------------------------------------------------
// CHATGA XABAR QO'SHISH
// ---------------------------------------------------------------------
function appendMessage(role, text, meta) {
  const msgDiv = document.createElement("div");
  msgDiv.className = "chat-message " + role;

  const metaDiv = document.createElement("div");
  metaDiv.className = "msg-meta";
  metaDiv.textContent = (role === "assistant" ? "Jarvis AI" : "Siz") + (meta ? " · " + meta : "");

  const contentDiv = document.createElement("div");
  contentDiv.className = "msg-content";
  contentDiv.textContent = text;

  msgDiv.appendChild(metaDiv);
  msgDiv.appendChild(contentDiv);
  chatViewport.appendChild(msgDiv);
  chatViewport.scrollTop = chatViewport.scrollHeight;
}

// ---------------------------------------------------------------------
// OVOZ CHIQARIB O'QISH (TTS)
// ---------------------------------------------------------------------
let isSpeakingNow = false;

function speakText(text, callback) {
  if (!isTTSActive || !window.speechSynthesis) {
    if (callback) callback();
    return;
  }

  try {
    isSpeakingNow = true;
    if (recognition && isRecording) {
      try { recognition.abort(); } catch(e) {}
    }

    window.speechSynthesis.cancel();
    const clean = text.replace(/[*_#\`~>]/g, "").slice(0, 450);
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = "uz-UZ";
    utterance.rate = voiceSpeed || 1.0;
    utterance.volume = voiceVolume !== undefined ? voiceVolume : 1.0;

    if (reactorCore) reactorCore.classList.add("speaking");
    if (audioWaveContainer) audioWaveContainer.classList.add("active");

    const onFinish = () => {
      isSpeakingNow = false;
      if (reactorCore) reactorCore.classList.remove("speaking");
      if (audioWaveContainer) audioWaveContainer.classList.remove("active");
      if (isContinuousModeActive) {
        setTimeout(startContinuousRecognition, 400);
      }
      if (callback) callback();
    };

    utterance.onend = onFinish;
    utterance.onerror = onFinish;

    window.speechSynthesis.speak(utterance);
  } catch(err) {
    isSpeakingNow = false;
    if (callback) callback();
  }
}

// ---------------------------------------------------------------------
// 5 TA GROQ KALIT ROTATSIYASI BILAN XABAR YUBORISH
// ---------------------------------------------------------------------
async function sendToJarvis(promptText) {
  if (!promptText.trim()) return;

  // Foydalanuvchi xabari
  appendMessage("user", promptText);
  textInput.value = "";
  if (coreLabel) coreLabel.textContent = "THINKING";

  // Qurilma buyruqlarini tekshirish
  const handled = checkDeviceCommands(promptText);
  if (handled) {
    if (coreLabel) coreLabel.textContent = "ONLINE";
    return;
  }

  // 1. Agar Render backend tanlangan bo'lsa
  if (backendMode === "render") {
    try {
      const res = await fetch(RENDER_BACKEND_URL + "/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: promptText })
      });
      if (res.ok) {
        const data = await res.json();
        const reply = data.response || "Buyruq bajarildi, Sir.";
        appendMessage("assistant", reply, "Render Backend");
        speakText(reply);
        if (coreLabel) coreLabel.textContent = "ONLINE";
        return;
      }
    } catch (e) {
      console.warn("Render backendiga ulanib bo'lmadi, Groq rotatsiyasiga o'tmoqda...");
    }
  }

  // 2. Bevosita Groq API (5 ta kalit failover rotatsiyasi)
  let attempts = 0;
  const maxAttempts = GROQ_API_KEYS.length;

  const messages = [
    { role: "system", content: SYSTEM_PROMPT },
    ...chatHistory.slice(-4),
    { role: "user", content: promptText }
  ];

  while (attempts < maxAttempts) {
    const activeKey = GROQ_API_KEYS[currentKeyIndex];
    try {
      const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + activeKey
        },
        body: JSON.stringify({
          model: GROQ_MODEL,
          messages: messages,
          temperature: 0.65,
          max_tokens: 1024
        })
      });

      if (response.ok) {
        const data = await response.json();
        const reply = data.choices[0].message.content;
        
        chatHistory.push({ role: "user", content: promptText });
        chatHistory.push({ role: "assistant", content: reply });

        appendMessage("assistant", reply, "Kalit #" + (currentKeyIndex + 1));
        speakText(reply);

        // Keyingi so'rov uchun rotatsiya
        currentKeyIndex = (currentKeyIndex + 1) % GROQ_API_KEYS.length;
        updateKeyDisplay();
        if (coreLabel) coreLabel.textContent = "ONLINE";
        return;
      }

      // Xatolik yoki Rate limit bo'lsa
      console.warn("Kalit #" + (currentKeyIndex + 1) + " limitga yetdi. Keyingisiga o'tilmoqda...");
      currentKeyIndex = (currentKeyIndex + 1) % GROQ_API_KEYS.length;
      updateKeyDisplay();
      attempts++;
    } catch (err) {
      currentKeyIndex = (currentKeyIndex + 1) % GROQ_API_KEYS.length;
      updateKeyDisplay();
      attempts++;
    }
  }

  const errMsg = "Barcha 5 ta Groq kalitlari band, Sir. Iltimos keyinroq urinib ko'ring.";
  appendMessage("assistant", errMsg);
  speakText(errMsg);
  if (coreLabel) coreLabel.textContent = "ONLINE";
}

// ---------------------------------------------------------------------
// QURILMA VA TIZIM BUYRUQLARI (DEVICE ACTIONS)
// ---------------------------------------------------------------------
function checkDeviceCommands(cmd) {
  const t = cmd.toLowerCase();

  // Kamera
  if (t.includes("kamera") || t.includes("rasmga ol") || t.includes("foto")) {
    openCameraModal();
    const rep = "Kamerani ochdim, Sir. Rasmga olishingiz mumkin.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  // Chiroq (Torch)
  if (t.includes("chiroqni yoq") || t.includes("fonarni yoq") || t.includes("chiroq yoq")) {
    toggleTorch(true);
    const rep = "Chiroq yoqildi, Sir.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }
  if (t.includes("chiroqni o'chir") || t.includes("chiroqni ochir") || t.includes("fonarni o'chir")) {
    toggleTorch(false);
    const rep = "Chiroq o'chirildi, Sir.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  // Sozlamalar
  if (t.includes("sozlama") || t.includes("nastroyka")) {
    settingsModal.classList.remove("hidden");
    const rep = "Sozlamalar ochildi, Sir.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  // Doimiy tinglash rejimi (Hands-Free)
  if (t.includes("doimiy tinglashni to'xtat") || t.includes("doimiy rejimni o'chir") || t.includes("tinglashni to'xtat") || t.includes("doimiy to'xtat")) {
    stopContinuousListening();
    const rep = "Doimiy tinglash rejimi to'xtatildi, Sir.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }
  if (t.includes("doimiy tingla") || t.includes("doimiy rejim") || t.includes("hands free") || t.includes("uzluksiz tingla") || t.includes("uzluksiz eshit")) {
    startContinuousListening();
    const rep = "Doimiy tinglash rejimi faollashdi, Sir! Mikrofon uzluksiz ishlamoqda va har bir so'zingizni kutmoqda.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  // Tizim holati
  if (t.includes("tizim holati") || t.includes("holat qanday")) {
    const rep = "Barcha tizimlar 100% normal holatda, Sir. Dasturchi Мухаммадризо buyruqlariga to'liq tayyorman.";
    appendMessage("assistant", rep, "Tizim");
    speakText(rep);
    return true;
  }

  return false;
}

// ---------------------------------------------------------------------
// CHIROQNI (TORCH) BOSHQARISH
// ---------------------------------------------------------------------
async function toggleTorch(targetState) {
  isTorchOn = (targetState !== undefined) ? targetState : !isTorchOn;

  if (isTorchOn) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      const track = stream.getVideoTracks()[0];
      const capabilities = track.getCapabilities ? track.getCapabilities() : {};

      if (capabilities.torch) {
        await track.applyConstraints({ advanced: [{ torch: true }] });
        torchTrack = track;
      } else {
        // Apparatda torch yo'q bo'lsa, ekran chirog'i
        screenTorchOverlay.classList.add("active");
      }
    } catch (e) {
      screenTorchOverlay.classList.add("active");
    }
  } else {
    if (torchTrack) {
      try {
        await torchTrack.applyConstraints({ advanced: [{ torch: false }] });
        torchTrack.stop();
      } catch (e) {}
      torchTrack = null;
    }
    screenTorchOverlay.classList.remove("active");
  }
}

screenTorchOverlay.addEventListener("click", () => toggleTorch(false));

// ---------------------------------------------------------------------
// KAMERA FUNKSIYALARI
// ---------------------------------------------------------------------
async function openCameraModal() {
  cameraModal.classList.remove("hidden");
  capturedPhotoPreview.classList.add("hidden");
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "environment" },
      audio: false
    });
    cameraVideo.srcObject = cameraStream;
  } catch (e) {
    alert("Kameraga ulanib bo'lmadi, ruxsat bering, Sir.");
    cameraModal.classList.add("hidden");
  }
}

function closeCameraModal() {
  cameraModal.classList.add("hidden");
  if (cameraStream) {
    cameraStream.getTracks().forEach(t => t.stop());
    cameraStream = null;
  }
}

btnCapturePhoto.addEventListener("click", () => {
  const canvas = document.createElement("canvas");
  canvas.width = cameraVideo.videoWidth || 640;
  canvas.height = cameraVideo.videoHeight || 480;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(cameraVideo, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL("image/jpeg", 0.9);

  capturedImage.src = dataUrl;
  btnDownloadPhoto.href = dataUrl;
  capturedPhotoPreview.classList.remove("hidden");
});

btnCloseCamera.addEventListener("click", closeCameraModal);

// ---------------------------------------------------------------------
// OVOZLI YORDAMCHI VA DOIMIY TINGLASH (SPEECH-TO-TEXT & HANDS-FREE)
// ---------------------------------------------------------------------
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let isRecording = false;
let isContinuousModeActive = false;

function initRecognition(continuous = false) {
  if (!SpeechRecognition) return null;
  const rec = new SpeechRecognition();
  rec.lang = "uz-UZ";
  rec.continuous = continuous;
  rec.interimResults = continuous;

  rec.onstart = () => {
    isRecording = true;
    btnVoiceRecord.classList.add("recording");
    if (reactorCore) reactorCore.classList.add("listening");
    if (coreLabel) coreLabel.textContent = isContinuousModeActive ? "HANDS-FREE" : "LISTENING";
  };

  rec.onresult = (event) => {
    let transcript = "";
    let isFinal = false;
    for (let i = event.resultIndex; i < event.results.length; ++i) {
      transcript += event.results[i][0].transcript;
      if (event.results[i].isFinal) isFinal = true;
    }
    if (transcript.trim()) {
      textInput.value = transcript.trim();
      if (isFinal) {
        sendToJarvis(transcript.trim());
      }
    }
  };

  rec.onerror = (e) => {
    console.warn("Speech error:", e.error);
    isRecording = false;
  };

  rec.onend = () => {
    isRecording = false;
    btnVoiceRecord.classList.remove("recording");
    if (reactorCore) reactorCore.classList.remove("listening");
    
    // Agar doimiy tinglash faol bo'lsa va Jarvis gapirmayotgan bo'lsa, uzluksiz qayta yoqish
    if (isContinuousModeActive && !isSpeakingNow) {
      setTimeout(startContinuousRecognition, 300);
    } else {
      if (coreLabel) coreLabel.textContent = "ONLINE";
    }
  };

  return rec;
}

function startContinuousRecognition() {
  if (!isContinuousModeActive || isSpeakingNow) return;
  try {
    if (recognition) {
      try { recognition.abort(); } catch(e) {}
    }
    recognition = initRecognition(true);
    if (recognition) recognition.start();
  } catch(e) {
    if (isContinuousModeActive && !isSpeakingNow) {
      setTimeout(startContinuousRecognition, 800);
    }
  }
}

function startContinuousListening() {
  isContinuousModeActive = true;
  startContinuousRecognition();
}

function stopContinuousListening() {
  isContinuousModeActive = false;
  if (recognition) {
    try { recognition.abort(); } catch(e) {}
  }
  isRecording = false;
  btnVoiceRecord.classList.remove("recording");
  if (reactorCore) reactorCore.classList.remove("listening");
  if (coreLabel) coreLabel.textContent = "ONLINE";
}

if (SpeechRecognition) {
  recognition = initRecognition(false);
}

function stopRecording() {
  if (isContinuousModeActive) {
    stopContinuousListening();
    return;
  }
  isRecording = false;
  if (recognition) {
    try { recognition.stop(); } catch(e) {}
  }
  btnVoiceRecord.classList.remove("recording");
  if (reactorCore) reactorCore.classList.remove("listening");
  if (coreLabel) coreLabel.textContent = "ONLINE";
}

btnVoiceRecord.addEventListener("click", () => {
  if (!recognition && !SpeechRecognition) {
    alert("Ushbu brauzerda ovozli kiritish qo'llab-quvvatlanmaydi, Sir.");
    return;
  }
  if (isContinuousModeActive) {
    stopContinuousListening();
    return;
  }
  if (isRecording) {
    stopRecording();
  } else {
    try {
      recognition = initRecognition(false);
      recognition.start();
    } catch (e) {
      stopRecording();
    }
  }
});

// Ovoz sozlamalari
let voiceSpeed = 1.0;
let voiceVolume = 1.0;
let isPermissionsGranted = false;

// DOM elementlari (Ruxsatlar va Ovoz)
const permissionGateOverlay = document.getElementById("permissionGateOverlay");
const permStatusMic = document.getElementById("permStatusMic");
const permStatusCam = document.getElementById("permStatusCam");
const btnGrantPermissions = document.getElementById("btnGrantPermissions");

const voiceSpeedRange = document.getElementById("voiceSpeedRange");
const voiceVolumeRange = document.getElementById("voiceVolumeRange");
const labelVoiceSpeed = document.getElementById("labelVoiceSpeed");
const labelVoiceVolume = document.getElementById("labelVoiceVolume");
const btnTestVoice = document.getElementById("btnTestVoice");

// ---------------------------------------------------------------------
// RASMIY ANDROID/WEB RUXSATLARINI SO'RASH (PERMISSION GATE)
// ---------------------------------------------------------------------
async function requestPermissions() {
  let micOk = false;
  let camOk = false;

  try {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      // Mikrofon ruxsati
      try {
        const aStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        micOk = true;
        if (permStatusMic) {
          permStatusMic.textContent = "BERILDI";
          permStatusMic.className = "status-granted";
        }
        aStream.getTracks().forEach(t => t.stop());
      } catch (e) {
        console.warn("Mikrofon ruxsati berilmadi:", e);
      }

      // Kamera ruxsati
      try {
        const vStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        camOk = true;
        if (permStatusCam) {
          permStatusCam.textContent = "BERILDI";
          permStatusCam.className = "status-granted";
        }
        vStream.getTracks().forEach(t => t.stop());
      } catch (e) {
        console.warn("Kamera ruxsati berilmadi:", e);
      }
    }

    if (micOk || camOk) {
      isPermissionsGranted = true;
      if (permissionGateOverlay) permissionGateOverlay.classList.add("hidden");
      if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
      speakText("Barcha tizim ruxsatlari faollashtirildi, Sir! Jarvis to'liq xizmatingizda.");
    } else {
      alert("Mikrofon va kamera ruxsatlari olinmadi, Sir. Iltimos ruxsat bering!");
    }
  } catch (err) {
    console.error("Ruxsat so'rash xatosi:", err);
  }
}

// Ilova ochilganda avtomatik ruxsat so'rash
window.addEventListener("DOMContentLoaded", () => {
  requestPermissions();
});

if (btnGrantPermissions) {
  btnGrantPermissions.addEventListener("click", requestPermissions);
}

// Ovoz sozlamalari tinglovchilari
if (voiceSpeedRange) {
  voiceSpeedRange.addEventListener("input", (e) => {
    voiceSpeed = parseFloat(e.target.value);
    if (labelVoiceSpeed) labelVoiceSpeed.textContent = voiceSpeed.toFixed(1) + "x";
  });
}

if (voiceVolumeRange) {
  voiceVolumeRange.addEventListener("input", (e) => {
    voiceVolume = parseFloat(e.target.value);
    if (labelVoiceVolume) labelVoiceVolume.textContent = Math.round(voiceVolume * 100) + "%";
  });
}

if (btnTestVoice) {
  btnTestVoice.addEventListener("click", () => {
    speakText("Assalomu alaykum, Sir! Ushbu ovoz tezligi va balandligi sizga ma'qulmi?");
  });
}

// ---------------------------------------------------------------------
// TUGMALAR VA HODISALAR
// ---------------------------------------------------------------------
btnSendText.addEventListener("click", () => {
  if (!isPermissionsGranted) {
    requestPermissions();
    return;
  }
  sendToJarvis(textInput.value);
});

textInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    if (!isPermissionsGranted) {
      requestPermissions();
      return;
    }
    sendToJarvis(textInput.value);
  }
});

btnActionCamera.addEventListener("click", () => {
  if (!isPermissionsGranted) { requestPermissions(); return; }
  checkDeviceCommands("kamerani och");
});

btnActionTorch.addEventListener("click", () => {
  if (!isPermissionsGranted) { requestPermissions(); return; }
  toggleTorch();
});

btnActionSettings.addEventListener("click", () => settingsModal.classList.remove("hidden"));
btnActionStatus.addEventListener("click", () => checkDeviceCommands("tizim holati"));

btnCloseSettings.addEventListener("click", () => settingsModal.classList.add("hidden"));
backendModeSelect.addEventListener("change", (e) => { backendMode = e.target.value; });
ttsToggle.addEventListener("change", (e) => { isTTSActive = e.target.checked; });
`;

export const ANDROID_MANIFEST_XML_CODE = `<?xml version="1.0" encoding="utf-8"?>
<!-- 
  JARVIS AI - ANDROID MANIFEST RUXSATLARI
  Muallif: Мухаммадризо (GitHub: olimovm158-dot)
  Ushbu fayl Website 2 APK Builder yoki Android Studio uchun rasmiy ruxsatlarni belgilaydi.
-->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.muhammadrizo.jarvis"
    android:versionCode="25"
    android:versionName="2.5.0">

    <!-- Tarmoq va Internet -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- Ovozli boshqaruv va Mikrofon -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

    <!-- Kamera va Chiroq (Torch) -->
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.FLASHLIGHT" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
    <uses-feature android:name="android.hardware.camera.flash" android:required="false" />

    <!-- GPS / Joylashuv -->
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-feature android:name="android.hardware.location.gps" android:required="false" />

    <!-- Vibratsiya va Ekran o'chmasligi -->
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Jarvis AI"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.NoTitleBar.Fullscreen"
        android:hardwareAccelerated="true">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;

export const MANIFEST_JSON_CODE = `{
  "name": "Jarvis AI",
  "short_name": "Jarvis",
  "description": "Мухаммадризо tomonidan yaratilgan shaxsiy sun'iy intellekt yordamchisi",
  "start_url": "./index.html",
  "display": "standalone",
  "background_color": "#030712",
  "theme_color": "#06b6d4",
  "icons": [
    {
      "src": "icon.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
`;

export const README_MD_CODE = `# JARVIS AI - SHAXSIY SUN'IY INTELLEKT YORDAMCHISI
**Muallif / Dasturchi:** Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)

Ushbu to'plam Jarvis shaxsiy sun'iy intellekt yordamchisining to'liq 100% ishlaydigan manba kodlaridan iborat.

---

## 1. BACKEND (FASTAPI - RENDER.COM GA JOYLASHTIRISH)
Ushbu papkadagi fayllar:
- \`server.py\` (FastAPI ilovasi, 5 ta Groq API kalitlari rotatsiyasi bilan)
- \`requirements.txt\` (Kerakli Python kutubxonalari)
- \`Procfile\` (Render uchun ishga tushirish buyrug'i)

### Render.com ga yuklash bosqichlari:
1. GitHub-da yangi repozitoriy oching (masalan, \`jarvis-ai-backend\`).
2. \`server.py\`, \`requirements.txt\` va \`Procfile\` fayllarini GitHub repozitoriyingizga yuklang.
3. [Render.com](https://render.com) ga kiring va **New + Web Service** tugmasini bosing.
4. GitHub repozitoriyingizni ulang.
5. Sozlamalar:
   - **Environment:** \`Python 3\`
   - **Build Command:** \`pip install -r requirements.txt\`
   - **Start Command:** \`uvicorn server:app --host 0.0.0.0 --port $PORT\`
6. **Create Web Service** tugmasini bosing.
7. Render sizga \`https://jarvis-ai-epk1.onrender.com\` kabi tayyor URL manzil beradi!

---

## 2. FRONTEND VA ANDROID APK QILISH (HTML-TO-APK)
Ushbu papkadagi frontend fayllari:
- \`index.html\`
- \`style.css\`
- \`script.js\`
- \`manifest.json\`

### APK qilish usullari:
1. **Website 2 APK Builder** dasturi orqali:
   - Ushbu HTML, CSS, JS fayllarni bitta papkaga joylang.
   - Website 2 APK Builder dasturini oching, "Local Website" rejimini tanlang va papkani ko'rsating.
   - "Build APK" tugmasini bosing.
2. **Capacitor / Cordova** orqali:
   \`\`\`bash
   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init Jarvis com.muhammadrizo.jarvis --web-dir .
   npx cap add android
   npx cap open android
   \`\`\`
   Android Studio-da ochib, **Build -> Build APK** ni bosing.

---

## 3. TEXNOLOGIYALAR VA IMKONIYATLAR
- **Asosiy AI Model:** \`llama-3.3-70b-versatile\` (Groq API orqali eng yuqori tezlikda)
- **5 ta Kalit Rotatsiyasi:** Bitta kalit 429 (Rate Limit) bo'lsa, navbatdagi kalitga avtomatik o'tadi!
- **Ovozli yordamchi:** Web Speech API (Ovozli qabul qilish) va Text-to-Speech (Ovozli o'qish).
- **Qurilma buyruqlari:** Kamera ochish, rasm olish, chiroqni (Torch) yoqish/o'chirish, sozlamalar.
`;
