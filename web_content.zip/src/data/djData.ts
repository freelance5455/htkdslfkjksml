export interface ServiceItem {
  id: string;
  name: string;
  tagline: string;
  priceUgx: number;
  displayPrice: string;
  popular?: boolean;
  duration: string;
  features: string[];
  bestFor: string;
}

export const DJ_SERVICES: ServiceItem[] = [
  {
    id: 'party',
    name: '🎂 Birthday Party',
    tagline: 'High-energy party hype, Kidandali & Amapiano bangerz',
    priceUgx: 120000,
    displayPrice: '120K',
    popular: true,
    duration: '3hrs + Setup',
    features: [
      '3 Hours non-stop mixing + full early setup',
      'Cross DJ Pro live beatmatching & live hot cues',
      'Kidandali, Amapiano, Dancehall & Afrobeats playlist',
      'Wireless MC Hype Microphone included',
      'Kyebando base, fast arrival anywhere in Kampala',
    ],
    bestFor: 'Birthday bashes, house parties, chillouts & graduations',
  },
  {
    id: 'club',
    name: '🎧 Night Club',
    tagline: 'Crowd-pulling club transitions, live TikTok streaming & hype mic',
    priceUgx: 150000,
    displayPrice: '150K',
    duration: 'Per Night',
    features: [
      'All-night club party mixing till dawn',
      'Aggressive scratch cues & fast tempo switches',
      'Live TikTok streaming from the DJ booth (@djevanproug)',
      'Free social media promo flyer posting to my followers',
      'Bax Ragga, Amapiano, Gengetone & Hip-Hop mastery',
    ],
    bestFor: 'Bars, lounges, night club residencies in Kampala & Wakiso',
  },
  {
    id: 'kwanjula',
    name: '💍 Kwanjula & Kuhingira',
    tagline: 'Traditional Ugandan introduction protocol, cultural hymns & modern after-vibe',
    priceUgx: 200000,
    displayPrice: '200K',
    popular: true,
    duration: 'Traditional Mix',
    features: [
      'Traditional Kiganda, Ankole & Kinyankore cultural music library',
      'In-law welcoming fanfares & precise cue drops',
      'Crystal-clear audio for Emcee and elders speeches',
      'Seamless transition into high-energy youth celebration',
      'Reliable Punctuality: Onsite 2 hours before guests arrive',
    ],
    bestFor: 'Traditional Introduction, Kwanjula, Kuhingira & Kukyala',
  },
  {
    id: 'wedding',
    name: '💒 Wedding Reception',
    tagline: 'Classy entrance cues, emotional moments, and midnight party explosion',
    priceUgx: 300000,
    displayPrice: '300K',
    popular: true,
    duration: 'Full Day',
    features: [
      'Full Day ceremony & reception coverage',
      'Bridal entrance & cake cutting timing precision',
      'Clean radio edits for elders & dinner session',
      'Madness evening after-party Amapiano & Naija sets',
      'Coordination with Wedding MC & sound team',
    ],
    bestFor: 'Kampala, Entebbe, Wakiso & Mukono Wedding Receptions',
  },
];

export interface ShopItem {
  id: string;
  title: string;
  category: string;
  priceUgx: number;
  displayPrice: string;
  desc: string;
  whatsappText: string;
  badge?: string;
  isPopular?: boolean;
}

export const DJ_SHOP_ITEMS: ShopItem[] = [
  {
    id: 'drops',
    title: '🎤 DJ Drops (2 Drops)',
    category: 'Vocal Drops',
    priceUgx: 7000,
    displayPrice: '7K UGX',
    desc: 'Custom professional DJ voice drops with your name and laser effects',
    whatsappText: 'I want DJ Drops 2 for 7K',
    badge: 'Best Value',
    isPopular: true,
  },
  {
    id: 'crossdj',
    title: '📱 CrossDJ Pro Apps',
    category: 'Android / iOS',
    priceUgx: 15000,
    displayPrice: '15K Each',
    desc: 'Fully unlocked CrossDJ Pro for Android & Phone with all FX & sample packs',
    whatsappText: 'I want CrossDJ Pro 15K',
    badge: 'Cue King Choice',
    isPopular: true,
  },
  {
    id: 'djay',
    title: '🎧 Djay Apps Unlocked',
    category: 'Pro Software',
    priceUgx: 10000,
    displayPrice: '10K UGX',
    desc: 'Algoriddim Djay Pro unlocked version with Neural Mix & AI stem separation',
    whatsappText: 'I want Djay Unlocked 10K',
  },
  {
    id: 'virtualdj',
    title: '💻 Virtual Softwares',
    category: 'PC / Laptop',
    priceUgx: 20000,
    displayPrice: '20K UGX',
    desc: 'Virtual DJ Pro Infinity for laptop/PC with full video mixing & sound skins',
    whatsappText: 'I want Virtual DJ 20K',
  },
];

export interface MixtapeCover {
  id: string;
  title: string;
  genre: string;
  duration: string;
  releaseYear: string;
  bpm: string;
  gradient: string;
  accentColor: string;
  highlightTag: string;
  tracklistSnippet: string[];
  playsCount: string;
  downloadSize: string;
}

export const MIXTAPE_GALLERY: MixtapeCover[] = [
  {
    id: 'mix-1',
    title: 'KAMPALA STREET BANGERZ VOL. 5',
    genre: 'Kidandali • Bax Ragga • Afro-Dancehall',
    duration: '58:40',
    releaseYear: '2026 Edition',
    bpm: '118 - 128 BPM',
    gradient: 'from-purple-900 via-indigo-950 to-black',
    accentColor: '#a855f7',
    highlightTag: '🔥 85K+ Streams',
    tracklistSnippet: ['Alien Skin - Sitya Danger Refix', 'Sheebah & Kenzo Anthems', 'Bax Ragga Drum Special', 'TikTok Street Dance Mix'],
    playsCount: '85.4K',
    downloadSize: '82 MB',
  },
  {
    id: 'mix-2',
    title: 'KWANJULA ROYAL LOVE EDITION',
    genre: 'Traditional Luganda • Love Ballads • Acoustic',
    duration: '1:12:15',
    releaseYear: '2026 Edition',
    bpm: '95 - 110 BPM',
    gradient: 'from-amber-950 via-purple-950 to-black',
    accentColor: '#f59e0b',
    highlightTag: '💍 #1 Wedding Choice',
    tracklistSnippet: ['Rema Namakula - Deep Romance', 'Juliana Kanyomozi Classics', 'Buganda Royal Intro Fanfares', 'Modern Afro Love Melodies'],
    playsCount: '64.1K',
    downloadSize: '104 MB',
  },
  {
    id: 'mix-3',
    title: 'AMAPIANO & AFROBEATS TAKEOVER',
    genre: 'S.A Amapiano • Naija • Kampala Club Vibes',
    duration: '1:05:00',
    releaseYear: '2026 Edition',
    bpm: '113 BPM',
    gradient: 'from-cyan-950 via-blue-950 to-black',
    accentColor: '#06b6d4',
    highlightTag: '⚡ TikTok LIVE Favorite',
    tracklistSnippet: ['Heavy 3-Step Log Drums', 'Tyler ICU & Kabza De Small', 'Burna Boy & Asake Mashup', 'Cue King Live Transitions'],
    playsCount: '112K',
    downloadSize: '94 MB',
  },
  {
    id: 'mix-4',
    title: 'CROSS DJ PRO LIVE SPEED SCRATCH',
    genre: 'Live Turntablism • Speed Mixing • Dancehall',
    duration: '45:30',
    releaseYear: '2026 Edition',
    bpm: '100 - 135 BPM',
    gradient: 'from-fuchsia-950 via-purple-950 to-black',
    accentColor: '#ec4899',
    highlightTag: '👑 The Cue King Signature',
    tracklistSnippet: ['Rapid 8-Bar Transitions', 'Airhorn & Laser Gun Cues', 'Vybz Kartel & Popcaan Jugglin', 'Cross DJ Android Live Proof'],
    playsCount: '49.8K',
    downloadSize: '65 MB',
  },
];

export interface ClientReview {
  id: string;
  name: string;
  role: string;
  location: string;
  rating: number;
  date: string;
  comment: string;
  service: string;
}

export const CLIENT_REVIEWS: ClientReview[] = [
  {
    id: 'rev-1',
    name: 'Babirye & Ronald Kyeyune',
    role: 'Newlyweds',
    location: 'Munyonyo, Kampala',
    rating: 5,
    date: 'February 2026',
    comment:
      'DJ Evan was the star of our wedding reception! He arrived 2 hours early from Kyebando to test the sound with the MC. When it came to the evening party, nobody sat down—even our aunties danced to Amapiano! The 300k fee was worth triple.',
    service: 'Wedding Reception',
  },
  {
    id: 'rev-2',
    name: 'Kigozi Brian (Bravo Events)',
    role: 'Club Promoter & Manager',
    location: 'Ntinda / Naalya',
    rating: 5,
    date: 'January 2026',
    comment:
      'I booked Evan for our Friday Night vibe. His speed on Cross DJ Pro is insane, zero awkward silences, and his live TikTok stream brought extra young walk-in customers straight to our bar counter.',
    service: 'Night Club',
  },
  {
    id: 'rev-3',
    name: 'Hajjati Sarah Namatovu',
    role: 'Family Elder / Host',
    location: 'Kyebando / Kawempe',
    rating: 5,
    date: 'March 2026',
    comment:
      'Our Kwanjula had over 300 guests. Evan played respectful cultural Buganda hymns during the in-law greetings, then switched to cheerful bangerz after the formal ceremony. Disciplined young man!',
    service: 'Kwanjula & Kuhingira',
  },
  {
    id: 'rev-4',
    name: 'Precious Namutebi',
    role: '24th Birthday Celebrant',
    location: 'Kira, Wakiso',
    rating: 5,
    date: 'Two weeks ago',
    comment:
      'I contacted him on WhatsApp at 10 AM, and by 3 PM he was already at my gate in Kira with his DJ console. 120k for 3 hours of pure madness! The airhorn drops were crazy 🔥!',
    service: 'Birthday Party',
  },
];

export const KAMPALA_LOCATIONS = [
  'Kyebando, Kawempe, Kampala',
  'Kyebando Central / Kisalosalo',
  'Bwaise / Kawempe Division',
  'Kalerwe / Mulago / Kamwokya',
  'Kampala Central / Nakasero',
  'Ntinda / Naguru / Bukoto',
  'Kira / Najjera / Namugongo',
  'Makindye / Munyonyo / Kansanga',
  'Rubaga / Mengo / Nateete',
  'Nansana / Wakiso Town',
  'Entebbe / Kajjansi',
  'Mukono Town / Seeta',
  'Other / Outside Kampala',
];
