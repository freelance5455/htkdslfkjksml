import { GenerationMode, Tone, LanguageStyle, GhazalFormat, SongGenre } from "../types";

export const URDU_LETTERS = [
  "ا", "ب", "پ", "ت", "ٹ", "ث", "ج", "چ", "ح", "خ",
  "د", "ڈ", "ذ", "ر", "ڑ", "ز", "ژ", "س", "ش", "ص",
  "ض", "ط", "ظ", "ع", "غ", "ف", "ق", "ک", "گ", "ل",
  "م", "ن", "و", "ہ", "ء", "ی", "ے"
];

export const TONE_OPTIONS: { id: Tone; labelUrdu: string; labelEn: string; icon: string }[] = [
  { id: "romantic", labelUrdu: "رومانوی", labelEn: "Romantic", icon: "❤️" },
  { id: "emotional", labelUrdu: "حزنیہ و پردرد", labelEn: "Emotional / Sad", icon: "💔" },
  { id: "philosophical", labelUrdu: "فلسفیانہ و فکری", labelEn: "Philosophical", icon: "🌌" },
  { id: "motivational", labelUrdu: "حوصلہ افزا و انقلابی", labelEn: "Motivational", icon: "⚡" },
  { id: "sufi", labelUrdu: "صوفیانہ و روحانی", labelEn: "Sufi / Spiritual", icon: "🕊️" }
];

export const STYLE_OPTIONS: { id: LanguageStyle; labelUrdu: string; labelEn: string; desc: string }[] = [
  { id: "simple", labelUrdu: "سادہ اردو", labelEn: "Simple Urdu", desc: "روانی اور جدید عام فہم انداز" },
  { id: "classic", labelUrdu: "کلاسیکی ادبی اردو", labelEn: "Classic Literary Urdu", desc: "میر، غالب اور اقبال کا شاندار ادبی اسلوب" }
];

export const GHAZAL_FORMATS: { id: GhazalFormat; labelUrdu: string; labelEn: string; desc: string }[] = [
  { id: "sher_2_line", labelUrdu: "دو سطری شعر", labelEn: "2-Line Sher", desc: "موزوں اور ضرب المثل شعر" },
  { id: "qata_4_line", labelUrdu: "چار سطری قطعہ", labelEn: "4-Line Qat'a", desc: "مکمل ایک موضوع پر بند" },
  { id: "full_ghazal", labelUrdu: "مکمل غزل", labelEn: "Full Ghazal", desc: "مطلع، مقطع اور ۵ تا ۷ اشعار" }
];

export const SONG_GENRES: { id: SongGenre; labelUrdu: string; labelEn: string; icon: string }[] = [
  { id: "sufi", labelUrdu: "صوفیانہ کلام / قوالی", labelEn: "Sufi & Qawwali", icon: "✨" },
  { id: "pop", labelUrdu: "پاپ میوزک", labelEn: "Modern Pop", icon: "🎸" },
  { id: "classical", labelUrdu: "کلاسیکی غزل / ٹھمری", labelEn: "Classical Melodic", icon: "🎻" },
  { id: "rap", labelUrdu: "اردو ریپ / ہپ ہاپ", labelEn: "Urdu Rap / Hip-Hop", icon: "🎤" }
];

export const QUICK_TOPIC_SUGGESTIONS = [
  "بارش اور تیری یاد",
  "عشقِ حقیقی و خودی",
  "جدائی کا کرب",
  "دوستی اور وفا",
  "وطن کی محبت",
  "خاموشی اور تنہائی",
  "امید اور مسلسل جدوجہد",
  "رات کا حسن اور چاندنی"
];

export const MODE_METADATA: Record<GenerationMode, { titleUrdu: string; titleEn: string; badge: string; desc: string }> = {
  ghazal_shayari: {
    titleUrdu: "غزل و شاعری",
    titleEn: "Ghazal & Shayari",
    badge: "شاعری",
    desc: "دو سطری شعر، قطعہ یا روایتی غزل"
  },
  song_lyrics: {
    titleUrdu: "نغمہ نگاری و ریپ",
    titleEn: "Song & Rap Lyrics",
    badge: "گیت و ریپ",
    desc: "مکھڑا، انترہ، کورس اور ہک کے ساتھ مکمل نغمہ"
  },
  bait_bazi: {
    titleUrdu: "بیت بازی و مقابلہ",
    titleEn: "Bait Bazi Competition",
    badge: "مقابلہ",
    desc: "حرفِ مخصوص سے شروع ہونے والے فتح مند اشعار"
  },
  rhyme_meter: {
    titleUrdu: "ردیف و قافیہ مددگار",
    titleEn: "Rhyme & Meter Helper",
    badge: "اصلاح و رہنمائی",
    desc: "نامکمل شعر مکمل کریں اور ہم قافیہ الفاظ تلاش کریں"
  }
};
