export const CREDITS_DEFAULT = {
  line1: "Créé par Mohamed dite Esteban",
  line2: "Merci d'avoir joué.",
};
