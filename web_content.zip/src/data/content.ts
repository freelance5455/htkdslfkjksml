export interface Puzzle {
  id: string;
  name: string;
  theme: string;
  rating: number;
  fen: string;
  /** Alternating moves in SAN: player, opponent, player, … */
  solution: string[];
  hint: string;
  lesson: string;
}

export const PUZZLES: Puzzle[] = [
  {
    id: "back-rank",
    name: "The Back Rank",
    theme: "Mate in 1",
    rating: 700,
    fen: "6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1",
    solution: ["Ra8#"],
    hint: "The black king never made luft — its own pawns are the jail bars.",
    lesson:
      "A castled king with three unmoved pawns in front can be mated along the eighth rank. Always ask: does my opponent (or do I!) have an escape square?",
  },
  {
    id: "smothered",
    name: "Smothered Mate",
    theme: "Mate in 1",
    rating: 900,
    fen: "6rk/6pp/8/6N1/8/8/8/6K1 w - - 0 1",
    solution: ["Nf7#"],
    hint: "Only one piece can deliver mate when the king is boxed in by friends.",
    lesson:
      "The knight is the only piece that can give check through a wall of defenders. When a king is surrounded by its own army, hunt for a knight check.",
  },
  {
    id: "fork",
    name: "Family Fork",
    theme: "Knight fork",
    rating: 1050,
    fen: "r3k3/8/8/3N4/8/8/8/2R1K3 w - - 0 1",
    solution: ["Nc7+", "Kd7", "Nxa8"],
    hint: "Find the square that touches both the king and the rook — and is defended.",
    lesson:
      "A knight attacking two pieces at once wins material, because the opponent can only save one. Check first: a fork with check is always the strongest version.",
  },
  {
    id: "double-attack",
    name: "Queen's Double Attack",
    theme: "Double attack",
    rating: 1150,
    fen: "r5k1/6pp/8/8/8/8/5PPP/3Q2K1 w - - 0 1",
    solution: ["Qd5+", "Kh8", "Qxa8+"],
    hint: "One central square puts the queen on two long diagonals at once.",
    lesson:
      "Centralised queens radiate power. Look for the square where a check also hits an undefended piece — the opponent must deal with the check first.",
  },
  {
    id: "pin",
    name: "Pressure the Pin",
    theme: "Pin",
    rating: 1250,
    fen: "4k3/8/5p2/4n3/8/2B5/8/4R1K1 w - - 0 1",
    solution: ["Bxe5", "fxe5", "Rxe5+"],
    hint: "The knight cannot move — so add another attacker and cash in.",
    lesson:
      "A pinned piece is a frozen target. The classic plan is 'pile up on the pin': attack it again and again until the defenders run out.",
  },
  {
    id: "philidor",
    name: "Philidor's Legacy",
    theme: "Mate in 5",
    rating: 1600,
    fen: "5rk1/6pp/8/6N1/8/8/8/3Q2K1 w - - 0 1",
    solution: ["Qb3+", "Kh8", "Nf7+", "Kg8", "Nh6+", "Kh8", "Qg8+", "Rxg8", "Nf7#"],
    hint: "Chase the king into the corner with checks, then give away your queen.",
    lesson:
      "The most famous combination in chess: queen to the long diagonal, knight checks to force the king into the corner, then a queen sacrifice sets up the smothered mate.",
  },
];

export interface Opening {
  id: string;
  name: string;
  eco: string;
  style: string;
  moves: string[];
  idea: string;
  notes: Record<number, string>;
}

export const OPENINGS: Opening[] = [
  {
    id: "italian",
    name: "Italian Game",
    eco: "C50",
    style: "Classical · great first opening",
    moves: ["e4", "e5", "Nf3", "Nc6", "Bc4", "Bc5", "c3", "Nf6", "d4", "exd4", "cxd4", "Bb4+"],
    idea: "Develop quickly, point the bishop at f7, and build the big pawn centre with c3 and d4.",
    notes: {
      0: "1.e4 — grab the centre and open lines for the bishop and queen.",
      2: "2.Nf3 — develop with a threat against e5.",
      4: "3.Bc4 — the 'Italian' bishop eyes the weakest square in Black's camp: f7.",
      6: "4.c3 — preparing d2-d4 to take the whole centre.",
      8: "5.d4 — the thematic central break.",
      11: "Black checks to trade off the attacker; the Giuoco Piano is in full flow.",
    },
  },
  {
    id: "ruy",
    name: "Ruy López",
    eco: "C60",
    style: "Strategic · the Spanish torture",
    moves: ["e4", "e5", "Nf3", "Nc6", "Bb5", "a6", "Ba4", "Nf6", "O-O", "Be7", "Re1", "b5"],
    idea: "Pressure the knight that defends e5, keep the tension, and squeeze on the queenside.",
    notes: {
      4: "3.Bb5 — attacking the defender of e5 instead of the pawn itself.",
      5: "3...a6 — the Morphy Defence, asking the bishop to declare itself.",
      8: "5.O-O — king safety first; the e4 pawn is poisoned-ish, a real gambit line.",
      11: "7...b5 kicks the bishop back and gains queenside space.",
    },
  },
  {
    id: "sicilian",
    name: "Sicilian Defence, Najdorf",
    eco: "B90",
    style: "Sharp · fighting for the win with Black",
    moves: ["e4", "c5", "Nf3", "d6", "d4", "cxd4", "Nxd4", "Nf6", "Nc3", "a6"],
    idea: "Black trades a wing pawn for a centre pawn and plays for an unbalanced, double-edged middlegame.",
    notes: {
      1: "1...c5 — the most ambitious reply to 1.e4.",
      5: "3...cxd4 — the trade that gives Black a half-open c-file forever.",
      9: "5...a6 — Najdorf's move: control b5 before deciding on a setup.",
    },
  },
  {
    id: "french",
    name: "French Defence",
    eco: "C02",
    style: "Solid · pawn-chain warfare",
    moves: ["e4", "e6", "d4", "d5", "e5", "c5", "c3", "Nc6", "Nf3", "Qb6"],
    idea: "Black accepts a cramped but rock-solid position and attacks the base of White's pawn chain with ...c5 and ...f6.",
    notes: {
      1: "1...e6 — preparing ...d5 with a pawn rather than a piece.",
      4: "3.e5 — the Advance Variation locks the centre.",
      5: "3...c5 — hitting d4, the base of the chain.",
      9: "5...Qb6 — adding a third attacker to d4.",
    },
  },
  {
    id: "qgd",
    name: "Queen's Gambit Declined",
    eco: "D30",
    style: "Classical · the backbone of 1.d4",
    moves: ["d4", "d5", "c4", "e6", "Nc3", "Nf6", "Bg5", "Be7", "e3", "O-O", "Nf3", "h6"],
    idea: "White gains central space and a lead in development; Black builds a fortress and aims for the ...c5 or ...e5 break.",
    notes: {
      2: "2.c4 — the Queen's Gambit: not a real sacrifice, White wants to deflect the d5 pawn.",
      3: "2...e6 — declining, keeping a strong pawn on d5.",
      6: "4.Bg5 — pinning the knight that guards d5.",
      11: "6...h6 — asking the bishop the question before completing development.",
    },
  },
  {
    id: "london",
    name: "London System",
    eco: "D02",
    style: "System · easy to learn, hard to beat",
    moves: ["d4", "d5", "Bf4", "Nf6", "e3", "e6", "Nf3", "Bd6", "Bg3", "O-O", "Bd3", "c5"],
    idea: "A setup you can play against almost anything: pawns on d4/e3, bishop outside the chain, then Nbd2, c3 and castle.",
    notes: {
      2: "2.Bf4 — develop the problem bishop before closing it in with e3.",
      4: "3.e3 — a small, solid pawn chain.",
      8: "5.Bg3 — keeping the good bishop by stepping away from the trade.",
      11: "6...c5 — Black's main counter-strike against the London centre.",
    },
  },
];

export interface Lesson {
  id: string;
  title: string;
  level: string;
  minutes: number;
  summary: string;
  points: string[];
}

export const LESSONS: Lesson[] = [
  {
    id: "values",
    title: "What the pieces are worth",
    level: "Beginner",
    minutes: 5,
    summary: "Before you calculate, you need a currency. Here is the exchange rate of chess.",
    points: [
      "Pawn = 1, Knight = 3, Bishop = 3, Rook = 5, Queen = 9. The king is priceless.",
      "Two bishops working together are often worth a bit more than 6 — keep the pair in open positions.",
      "A rook for a bishop or knight is 'winning the exchange' (+2).",
      "Material is only one factor: king safety, activity and structure can outweigh a pawn or two.",
    ],
  },
  {
    id: "opening",
    title: "The four opening principles",
    level: "Beginner",
    minutes: 7,
    summary: "You don't need theory to get a good position — you need good habits.",
    points: [
      "1. Fight for the centre with a pawn (e4/d4 or e5/d5).",
      "2. Develop knights before bishops, and don't move the same piece twice.",
      "3. Castle early — usually before move 10.",
      "4. Connect the rooks, then make a plan. Don't bring the queen out too early.",
    ],
  },
  {
    id: "tactics",
    title: "The tactical motifs",
    level: "Intermediate",
    minutes: 10,
    summary: "99% of games below master level are decided by a tactic. Learn the shapes.",
    points: [
      "Fork — one piece attacks two targets at once (knights are the champions).",
      "Pin — a piece can't move because something more valuable sits behind it.",
      "Skewer — the reverse pin: the valuable piece is in front and must step aside.",
      "Discovered attack — move one piece to unleash the power of another. Discovered check is brutal.",
      "Deflection & decoy — drag a defender away from the square it is guarding.",
    ],
  },
  {
    id: "endgame",
    title: "Endgames that win games",
    level: "Intermediate",
    minutes: 12,
    summary: "The player who knows the ending plays the middlegame with confidence.",
    points: [
      "King and queen vs king: push the lone king to the edge, keep a knight's distance, avoid stalemate.",
      "Opposition: in king and pawn endings, the player NOT having to move usually wins the key squares.",
      "Rook endings: put your rook behind the passed pawn — yours or theirs.",
      "Activate your king! In the endgame it is a strong attacking piece, worth about 4 points.",
    ],
  },
  {
    id: "thinking",
    title: "A thinking routine for every move",
    level: "All levels",
    minutes: 6,
    summary: "Blunders come from missing the opponent's idea, not from weak calculation.",
    points: [
      "Ask what changed: what does the opponent's last move attack or allow?",
      "List all checks, captures and threats — for both sides.",
      "Pick candidate moves (two or three), calculate each to a quiet position.",
      "Before you touch the piece: blunder-check. Is anything of mine hanging?",
    ],
  },
];

export interface PieceDemo {
  id: string;
  name: string;
  fen: string;
  from: string;
  text: string;
}

export const PIECE_DEMOS: PieceDemo[] = [
  {
    id: "pawn",
    name: "Pawn",
    fen: "4k3/8/8/8/8/8/3P4/4K3 w - - 0 1",
    from: "d2",
    text: "Pawns step forward one square (two from their starting row) but capture diagonally. Reach the last rank and the pawn promotes — usually to a queen.",
  },
  {
    id: "knight",
    name: "Knight",
    fen: "4k3/8/8/8/3N4/8/8/4K3 w - - 0 1",
    from: "d4",
    text: "The knight jumps in an L: two squares one way, one square across. It is the only piece that leaps over others, and it always changes square colour.",
  },
  {
    id: "bishop",
    name: "Bishop",
    fen: "4k3/8/8/8/3B4/8/8/4K3 w - - 0 1",
    from: "d4",
    text: "Bishops slide along diagonals and stay on one colour forever. A pair of bishops covering both colours is a serious long-range weapon.",
  },
  {
    id: "rook",
    name: "Rook",
    fen: "4k3/8/8/8/3R4/8/8/4K3 w - - 0 1",
    from: "d4",
    text: "Rooks move in straight lines along files and ranks. They love open files and the seventh rank, and they also castle with the king.",
  },
  {
    id: "queen",
    name: "Queen",
    fen: "4k3/8/8/8/3Q4/8/8/4K3 w - - 0 1",
    from: "d4",
    text: "The queen combines rook and bishop: the most powerful piece on the board. Powerful, but don't develop her too early — she is easy to chase.",
  },
  {
    id: "king",
    name: "King",
    fen: "7k/8/8/8/3K4/8/8/8 w - - 0 1",
    from: "d4",
    text: "The king moves one square in any direction and can never step into check. Keep it safe in the opening, then march it forward in the endgame.",
  },
];
