export const brand = {
  name: "Cascade",
  tagline: "Workflows that think ahead",
  description:
    "Cascade is the AI-native operations platform that automates complex workflows, unifies your tools, and gives every team superpowers—without the chaos.",
};

export const navLinks = [
  { label: "Features", href: "features" },
  { label: "Product", href: "showcase" },
  { label: "Benefits", href: "benefits" },
  { label: "Pricing", href: "pricing" },
  { label: "FAQ", href: "faq" },
];

export const logos = [
  "NovaTech",
  "Brightly",
  "Orbit Labs",
  "Meridian",
  "Pulse AI",
  "Vertex",
  "Lumen Co",
  "Stackwright",
];

export const stats = [
  { value: "40%", label: "faster cycle times", suffix: "" },
  { value: "12k+", label: "teams shipping daily", suffix: "" },
  { value: "99.99%", label: "platform uptime", suffix: "" },
  { value: "3.2×", label: "ROI in 90 days", suffix: "" },
];

export const features = [
  {
    title: "AI Workflow Copilot",
    description:
      "Describe outcomes in plain English. Cascade designs, builds, and optimizes multi-step automations—then keeps improving them as your data evolves.",
    icon: "sparkles" as const,
    accent: "from-violet-500/20 to-fuchsia-500/10",
  },
  {
    title: "Unified Tool Graph",
    description:
      "Connect Slack, Salesforce, Notion, Jira, Stripe, and 300+ apps. Cascade maps dependencies so nothing falls through the cracks.",
    icon: "link" as const,
    accent: "from-indigo-500/20 to-blue-500/10",
  },
  {
    title: "Real-time Ops Radar",
    description:
      "Live dashboards surface bottlenecks before they become fires. Predictive alerts keep leaders three steps ahead of the queue.",
    icon: "chart" as const,
    accent: "from-cyan-500/20 to-teal-500/10",
  },
  {
    title: "Enterprise-grade Guardrails",
    description:
      "SOC 2, SSO, audit trails, and granular permissions baked in. Ship fast without compromising security or compliance.",
    icon: "shield" as const,
    accent: "from-emerald-500/20 to-green-500/10",
  },
  {
    title: "Composable Playbooks",
    description:
      "Turn tribal knowledge into reusable blueprints. Version, share, and fork workflows across teams like modern software.",
    icon: "layers" as const,
    accent: "from-amber-500/20 to-orange-500/10",
  },
  {
    title: "Human-in-the-loop Control",
    description:
      "Set approval gates, escalation paths, and smart handoffs. Automate the routine—keep humans on the decisions that matter.",
    icon: "users" as const,
    accent: "from-rose-500/20 to-pink-500/10",
  },
];

export const showcaseTabs = [
  {
    id: "automate",
    label: "Automate",
    title: "From idea to live workflow in minutes",
    description:
      "Type what you need—“When a deal closes, provision accounts, notify CS, and schedule onboarding”—and Cascade orchestrates every step across your stack.",
    points: [
      "Natural language to production workflows",
      "Auto-generated error handling & retries",
      "Visual canvas for fine-grained control",
    ],
  },
  {
    id: "orchestrate",
    label: "Orchestrate",
    title: "One brain for every tool you already use",
    description:
      "Cascade sits above your existing stack as an intelligent control plane—syncing data, resolving conflicts, and keeping every system of record aligned.",
    points: [
      "300+ native integrations",
      "Bidirectional sync with conflict resolution",
      "Event-driven triggers with sub-second latency",
    ],
  },
  {
    id: "scale",
    label: "Scale",
    title: "Built for teams that move at startup speed",
    description:
      "From 10 to 10,000 employees, Cascade scales with role-based access, multi-workspace architecture, and observability that ops teams actually love.",
    points: [
      "Unlimited parallel workflow runs",
      "Audit-ready logging & version history",
      "Global edge execution network",
    ],
  },
];

export const benefits = [
  {
    title: "Reclaim 15+ hours a week",
    description:
      "Eliminate swivel-chair work between tools. Your team focuses on strategy while Cascade handles the handoffs, nudges, and busywork.",
    metric: "15 hrs",
    metricLabel: "saved weekly per ops lead",
  },
  {
    title: "Ship changes without fear",
    description:
      "Preview impact, roll back instantly, and test in sandboxes. Every change is versioned—so experimentation becomes a competitive advantage.",
    metric: "0",
    metricLabel: "production surprises",
  },
  {
    title: "Align every team on one source of truth",
    description:
      "Sales, CS, product, and finance finally operate from the same live data. No more stale spreadsheets or “who owns this?” chaos.",
    metric: "1",
    metricLabel: "unified operations layer",
  },
];

export const testimonials = [
  {
    quote:
      "Cascade replaced four brittle Zapier stacks and a custom scripts nightmare. We cut onboarding time from 9 days to 36 hours—and the AI keeps getting smarter.",
    name: "Maya Chen",
    role: "VP of Operations",
    company: "Brightly",
    avatar: "MC",
    rating: 5,
  },
  {
    quote:
      "I was skeptical of another automation platform. Cascade felt different on day one—the copilot actually understands our domain. ROI paid for itself in the first sprint.",
    name: "Jordan Ellis",
    role: "Head of Revenue Ops",
    company: "Orbit Labs",
    avatar: "JE",
    rating: 5,
  },
  {
    quote:
      "Security reviewed it in a week. Our compliance team loves the audit trails. Our ICs love that they can ship workflows without waiting on engineering.",
    name: "Priya Nair",
    role: "CTO",
    company: "Meridian Health",
    avatar: "PN",
    rating: 5,
  },
];

export const pricingPlans = [
  {
    name: "Starter",
    price: 29,
    period: "per seat / mo",
    description: "For small teams ready to automate their first critical workflows.",
    cta: "Start free trial",
    highlighted: false,
    features: [
      "Up to 5 active workflows",
      "10k runs / month",
      "Core integrations",
      "AI copilot (standard)",
      "Email support",
    ],
  },
  {
    name: "Growth",
    price: 79,
    period: "per seat / mo",
    description: "For scaling teams that need power, visibility, and collaboration.",
    cta: "Start free trial",
    highlighted: true,
    badge: "Most popular",
    features: [
      "Unlimited workflows",
      "100k runs / month",
      "All integrations + API",
      "AI copilot (advanced)",
      "Ops radar & alerts",
      "SSO & audit logs",
      "Priority support",
    ],
  },
  {
    name: "Enterprise",
    price: null,
    period: "custom",
    description: "For organizations that need scale, governance, and dedicated partnership.",
    cta: "Talk to sales",
    highlighted: false,
    features: [
      "Unlimited everything",
      "Dedicated success team",
      "Custom SLAs & VPC",
      "Advanced SCIM & RBAC",
      "On-prem agent option",
      "Custom AI model routing",
      "24/7 premium support",
    ],
  },
];

export const faqs = [
  {
    question: "How is Cascade different from Zapier or Make?",
    answer:
      "Traditional automation tools connect apps with linear triggers. Cascade is AI-native—it understands your business context, designs multi-step workflows from natural language, predicts failures, and continuously optimizes. Think of it as an ops teammate, not just a pipe between tools.",
  },
  {
    question: "Do I need engineers to set this up?",
    answer:
      "No. Most teams go live in under a day. The AI copilot builds workflows from plain English, and the visual canvas lets non-technical operators refine every step. Engineers love the API and version control when they want deeper customization.",
  },
  {
    question: "Is my data secure?",
    answer:
      "Yes. We're SOC 2 Type II certified, encrypt data in transit and at rest, support SSO/SAML and SCIM, and offer regional data residency. Enterprise plans include VPC deployment and private AI model routing so sensitive data never leaves your boundary.",
  },
  {
    question: "Can I try Cascade before committing?",
    answer:
      "Absolutely. Every plan starts with a 14-day free trial—no credit card required. You'll get full Growth features so you can prove value on a real workflow before you buy.",
  },
  {
    question: "What happens if a workflow fails?",
    answer:
      "Cascade includes automatic retries with backoff, dead-letter queues, and smart escalation to the right human. The Ops Radar surfaces failures in real time with root-cause hints, and you can roll back to any previous version in one click.",
  },
  {
    question: "How does pricing scale with usage?",
    answer:
      "Plans are seat-based with generous run allowances. Overages are billed transparently at published rates—no surprise invoices. Enterprise customers get custom volume commitments and predictable annual pricing.",
  },
];

export const footerLinks = {
  product: [
    { label: "Features", href: "#features" },
    { label: "Integrations", href: "#showcase" },
    { label: "Pricing", href: "#pricing" },
    { label: "Changelog", href: "#" },
    { label: "Roadmap", href: "#" },
  ],
  company: [
    { label: "About", href: "#" },
    { label: "Customers", href: "#testimonials" },
    { label: "Careers", href: "#" },
    { label: "Blog", href: "#" },
    { label: "Press", href: "#" },
  ],
  resources: [
    { label: "Documentation", href: "#" },
    { label: "API Reference", href: "#" },
    { label: "Community", href: "#" },
    { label: "Status", href: "#" },
    { label: "Templates", href: "#" },
  ],
  legal: [
    { label: "Privacy", href: "#" },
    { label: "Terms", href: "#" },
    { label: "Security", href: "#" },
    { label: "DPA", href: "#" },
  ],
};
