export type Zone = 'abc' | '123' | 'urdu';

export interface Option { id: string; primary: string; secondary?: string; emoji?: string; isCorrect: boolean; color: string; }
export interface Question {
  id: string;
  zone: Zone;
  kind: string;
  title: string;
  subtitle: string;
  speak: string;
  speakLang: string;
  // visual prompt
  bigLetter?: string;        // ABC / Urdu letter
  bigEmoji?: string;         // picture prompt
  bigWord?: string;          // word under picture
  countItems?: { emoji: string; count: number; label: string };
  options: Option[];
  praise: string;
}

const COLORS = ['bg-rose-400', 'bg-amber-400', 'bg-sky-400', 'bg-emerald-400', 'bg-violet-400', 'bg-orange-400', 'bg-pink-400', 'bg-teal-400'];
const SHADOWS: Record<string, string> = {
  'bg-rose-400': 'shadow-[0_7px_0_#be123c]', 'bg-amber-400': 'shadow-[0_7px_0_#b45309]',
  'bg-sky-400': 'shadow-[0_7px_0_#0369a1]', 'bg-emerald-400': 'shadow-[0_7px_0_#047857]',
  'bg-violet-400': 'shadow-[0_7px_0_#6d28d9]', 'bg-orange-400': 'shadow-[0_7px_0_#c2410c]',
  'bg-pink-400': 'shadow-[0_7px_0_#be185d]', 'bg-teal-400': 'shadow-[0_7px_0_#0f766e]',
};

export const ABC_DATA = [
  { l: 'A', w: 'Apple', e: '🍎' }, { l: 'B', w: 'Ball', e: '⚽' }, { l: 'C', w: 'Cat', e: '🐱' },
  { l: 'D', w: 'Dog', e: '🐶' }, { l: 'E', w: 'Egg', e: '🥚' }, { l: 'F', w: 'Fish', e: '🐟' },
  { l: 'G', w: 'Grapes', e: '🍇' }, { l: 'H', w: 'Hat', e: '🎩' }, { l: 'I', w: 'Ice Cream', e: '🍦' },
  { l: 'J', w: 'Juice', e: '🧃' }, { l: 'K', w: 'Kite', e: '🪁' }, { l: 'L', w: 'Lion', e: '🦁' },
  { l: 'M', w: 'Monkey', e: '🐵' }, { l: 'N', w: 'Nose', e: '👃' }, { l: 'O', w: 'Orange', e: '🍊' },
  { l: 'P', w: 'Penguin', e: '🐧' }, { l: 'Q', w: 'Queen', e: '👑' }, { l: 'R', w: 'Rabbit', e: '🐰' },
  { l: 'S', w: 'Sun', e: '☀️' }, { l: 'T', w: 'Tiger', e: '🐯' }, { l: 'U', w: 'Umbrella', e: '☂️' },
  { l: 'V', w: 'Van', e: '🚐' }, { l: 'W', w: 'Whale', e: '🐋' }, { l: 'X', w: 'Xylophone', e: '🎶' },
  { l: 'Y', w: 'Yo-Yo', e: '🪀' }, { l: 'Z', w: 'Zebra', e: '🦓' },
];

export const URDU_DATA = [
  { l: 'ا', w: 'انار', r: 'Anaar', e: '🍎', ln: 'Alif' }, { l: 'ب', w: 'بلی', r: 'Billi', e: '🐱', ln: 'Be' },
  { l: 'ت', w: 'تتلی', r: 'Titli', e: '🦋', ln: 'Te' }, { l: 'ث', w: 'ثعلب', r: 'Sa\'lab', e: '🦊', ln: 'Se' },
  { l: 'ج', w: 'جہاز', r: 'Jahaz', e: '🚢', ln: 'Jeem' }, { l: 'چ', w: 'چائے', r: 'Chai', e: '☕', ln: 'Che' },
  { l: 'ح', w: 'حوت', r: 'Hoot', e: '🐳', ln: 'He' }, { l: 'خ', w: 'خربوزہ', r: 'Kharbooza', e: '🍈', ln: 'Khe' },
  { l: 'د', w: 'درخت', r: 'Darakht', e: '🌳', ln: 'Dal' }, { l: 'ڈ', w: 'ڈبہ', r: 'Dabba', e: '📦', ln: 'Dal' },
  { l: 'ذ', w: 'ذرت', r: 'Zurat', e: '🌽', ln: 'Zal' }, { l: 'ر', w: 'ریل گاڑی', r: 'Rail Gari', e: '🚂', ln: 'Re' },
  { l: 'ز', w: 'زرافہ', r: 'Zarafa', e: '🦒', ln: 'Ze' }, { l: 'س', w: 'سیب', r: 'Saib', e: '🍏', ln: 'Seen' },
  { l: 'ش', w: 'شہد', r: 'Shehad', e: '🍯', ln: 'Sheen' }, { l: 'ص', w: 'صابن', r: 'Saban', e: '🧼', ln: 'Sad' },
  { l: 'ط', w: 'طوطا', r: 'Tota', e: '🦜', ln: 'To' }, { l: 'ع', w: 'عینک', r: 'Ainak', e: '👓', ln: 'Ain' },
  { l: 'غ', w: 'غبارہ', r: 'Ghubara', e: '🎈', ln: 'Ghain' }, { l: 'ف', w: 'فٹبال', r: 'Football', e: '⚽', ln: 'Fe' },
  { l: 'ق', w: 'قلم', r: 'Qalam', e: '✏️', ln: 'Qaf' }, { l: 'ک', w: 'کتاب', r: 'Kitab', e: '📚', ln: 'Kaf' },
  { l: 'گ', w: 'گائے', r: 'Gaye', e: '🐄', ln: 'Gaf' }, { l: 'ل', w: 'لیموں', r: 'Lemon', e: '🍋', ln: 'Lam' },
  { l: 'م', w: 'مچھلی', r: 'Machli', e: '🐠', ln: 'Meem' }, { l: 'ن', w: 'ناریل', r: 'Nariyal', e: '🥥', ln: 'Noon' },
  { l: 'و', w: 'ویل', r: 'Whale', e: '🐋', ln: 'Wao' }, { l: 'ہ', w: 'ہاتھی', r: 'Hathi', e: '🐘', ln: 'He' },
  { l: 'ی', w: 'یخ', r: 'Yakh', e: '🍦', ln: 'Ye' },
];

export const COUNT_ITEMS = [
  { emoji: '🎈', label: 'balloons' }, { emoji: '⭐', label: 'stars' }, { emoji: '🍎', label: 'apples' },
  { emoji: '❤️', label: 'hearts' }, { emoji: '🌸', label: 'flowers' }, { emoji: '🦆', label: 'ducks' },
  { emoji: '🐠', label: 'fish' }, { emoji: '🦋', label: 'butterflies' }, { emoji: '🍬', label: 'candies' },
  { emoji: '🚗', label: 'cars' }, { emoji: '🍓', label: 'strawberries' }, { emoji: '🐢', label: 'turtles' },
];

const PRAISE = ['Wah! Bohat khub! 🎉', 'Shabash! Super star! ⭐', 'Yay! Tum ne kar dikhaya! 🎈', 'Kya baat hai! 🌟', 'Hooray! Bohat hoshiyar! 🎊', 'Zabardast! 💖', 'Wah wah! Kya baat hai! 🎁'];
const TRY_AGAIN = ['Phir se koshish karo! Tum kar sakte ho! 💪', 'Qareeb ho! Phir se dekho! 👀', 'Bohat achi koshish! Ek dafa aur! 🌈', 'Tum qareeb ho! Phir try karo! ✨'];

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
function pickOthers<T>(pool: T[], correct: T, n = 2): T[] {
  return shuffle(pool.filter(x => x !== correct)).slice(0, n);
}
function makeOptions(correct: { primary: string; secondary?: string; emoji?: string }, others: typeof correct[]): Option[] {
  const all = shuffle([{ ...correct, isCorrect: true }, ...others.map(o => ({ ...o, isCorrect: false }))]);
  return all.map((o, i) => ({ id: `${o.primary}-${i}`, primary: o.primary, secondary: o.secondary, emoji: o.emoji, isCorrect: o.isCorrect, color: COLORS[i % COLORS.length] }));
}
export function shadowFor(color: string) { return SHADOWS[color] || 'shadow-[0_7px_0_rgba(0,0,0,.2)]'; }
export { PRAISE, TRY_AGAIN };

let qid = 0;
function abcQuestion(): Question {
  const item = ABC_DATA[Math.floor(Math.random() * ABC_DATA.length)];
  const kind = Math.random() < 0.55 ? 'word' : 'letter';
  const praise = PRAISE[Math.floor(Math.random() * PRAISE.length)];
  if (kind === 'word') {
    const others = pickOthers(ABC_DATA, item).map(o => ({ primary: o.w, emoji: o.e }));
    return {
      id: `q${++qid}`, zone: 'abc', kind, title: `${item.l} for ...?`, subtitle: `${item.l} se kya hota hai? ${item.w} ko chhuo!`,
      speak: `${item.l}... ${item.l} se ${item.w}! ${item.w} ko chhuo!`, speakLang: 'ur-PK',
      bigLetter: item.l, options: makeOptions({ primary: item.w, emoji: item.e }, others), praise,
    };
  }
  const others = pickOthers(ABC_DATA, item).map(o => ({ primary: o.l }));
  return {
    id: `q${++qid}`, zone: 'abc', kind, title: `${item.w} starts with...?`, subtitle: `${item.w} kis harf se shuru hota hai?`,
    speak: `${item.w} kis harf se shuru hota hai? Sahi harf ko chhuo!`, speakLang: 'ur-PK',
    bigEmoji: item.e, bigWord: item.w, options: makeOptions({ primary: item.l }, others), praise,
  };
}

function numQuestion(): Question {
  const praise = PRAISE[Math.floor(Math.random() * PRAISE.length)];
  if (Math.random() < 0.7) {
    const count = 1 + Math.floor(Math.random() * 10);
    const item = COUNT_ITEMS[Math.floor(Math.random() * COUNT_ITEMS.length)];
    const distract = new Set<number>();
    while (distract.size < 2) { const d = Math.max(1, Math.min(10, count + (Math.random() < 0.5 ? -1 : 1) * (1 + Math.floor(Math.random() * 3)))); if (d !== count) distract.add(d); }
    const others = [...distract].map(d => ({ primary: String(d) }));
    const urLabel: Record<string, string> = { balloons: 'gubbaray', stars: 'sitaray', apples: 'saib', hearts: 'dil', flowers: 'phool', ducks: 'battakhain', fish: 'machliyan', butterflies: 'titliyan', candies: 'mithaiyan', cars: 'gaariyan', strawberries: 'strawberry', turtles: 'kachway' };
    const ul = urLabel[item.label] || item.label;
    return {
      id: `q${++qid}`, zone: '123', kind: 'count', title: 'Count them! 🧮', subtitle: `Kitnay ${ul} hain? Gin kar batao!`,
      speak: `${ul} ginnao! Kitnay ${ul} hain? Ginn kar sahi number ko chhuo!`, speakLang: 'ur-PK',
      countItems: { emoji: item.emoji, count, label: item.label },
      options: makeOptions({ primary: String(count) }, others), praise,
    };
  }
  const n = 1 + Math.floor(Math.random() * 10);
  const distract = new Set<number>();
  while (distract.size < 2) { const d = 1 + Math.floor(Math.random() * 10); if (d !== n) distract.add(d); }
  return {
    id: `q${++qid}`, zone: '123', kind: 'find', title: `Find number ${n}! 🔢`, subtitle: `Number ${n} ko dhundho!`,
    speak: `Number ${n} dhundho! Sahi number ko chhuo!`, speakLang: 'ur-PK',
    options: makeOptions({ primary: String(n) }, [...distract].map(d => ({ primary: String(d) }))), praise,
  };
}

function urduQuestion(): Question {
  const item = URDU_DATA[Math.floor(Math.random() * URDU_DATA.length)];
  const kind = Math.random() < 0.55 ? 'word' : 'letter';
  const praise = PRAISE[Math.floor(Math.random() * PRAISE.length)];
  if (kind === 'word') {
    const others = pickOthers(URDU_DATA, item).map(o => ({ primary: o.w, secondary: o.r, emoji: o.e }));
    return {
      id: `q${++qid}`, zone: 'urdu', kind, title: `${item.l} سے کیا ہوتا ہے؟`, subtitle: `${item.ln} — ${item.r} ko chhuo!`,
      speak: `${item.ln}... ${item.ln} se ${item.r}! ${item.r} ko chhuo!`, speakLang: 'ur-PK',
      bigLetter: item.l, options: makeOptions({ primary: item.w, secondary: item.r, emoji: item.e }, others), praise,
    };
  }
  const others = pickOthers(URDU_DATA, item).map(o => ({ primary: o.l }));
  return {
    id: `q${++qid}`, zone: 'urdu', kind, title: `${item.w} کس حرف سے شروع ہوتا ہے؟`, subtitle: `${item.w} (${item.r})`,
    speak: `${item.r} kis harf se shuru hota hai? Sahi harf ko chhuo!`, speakLang: 'ur-PK',
    bigEmoji: item.e, bigWord: item.w, options: makeOptions({ primary: item.l }, others), praise,
  };
}

export function buildSession(zone: Zone, rounds = 10): Question[] {
  const gen = zone === 'abc' ? abcQuestion : zone === '123' ? numQuestion : urduQuestion;
  const seen = new Set<string>();
  const out: Question[] = [];
  let guard = 0;
  while (out.length < rounds && guard++ < 200) {
    const q = gen();
    const key = q.bigLetter || q.bigEmoji || q.title;
    // allow repeats but avoid immediate duplicates
    if (out.length && out[out.length - 1].title === q.title) continue;
    seen.add(key);
    out.push(q);
  }
  return out;
}

export const ZONE_META: Record<Zone, { name: string; urdu: string; emoji: string; gradient: string; shadow: string; desc: string }> = {
  abc: { name: 'ABC Zone', urdu: 'English Alphabets', emoji: '🔤', gradient: 'from-rose-400 to-orange-400', shadow: 'shadow-[0_8px_0_#be123c]', desc: 'Letters & Phonics' },
  '123': { name: '123 Zone', urdu: 'Maths & Counting', emoji: '🔢', gradient: 'from-sky-400 to-violet-500', shadow: 'shadow-[0_8px_0_#0369a1]', desc: 'Numbers & Counting' },
  urdu: { name: 'Urdu Zone', urdu: 'اردو حروفِ تہجی', emoji: '🌙', gradient: 'from-emerald-400 to-teal-500', shadow: 'shadow-[0_8px_0_#047857]', desc: 'Urdu Alphabets' },
};
