import { Club, HairStyle, KitConfig, Player, PlayerPosition, StadiumOption } from '../types/game';

export const HAIRSTYLE_OPTIONS: HairStyle[] = ['short', 'fade', 'afro', 'mohawk', 'long', 'bald'];

export const HAIR_COLOR_PRESETS = [
  '#1E1B18',
  '#3F2A1D',
  '#7C542B',
  '#D4A74A',
  '#0F172A',
  '#9A3412',
  '#CBD5E1',
];

export const KIT_COLOR_PRESETS: Array<{
  id: string;
  name: string;
  primaryColor: string;
  secondaryColor: string;
  shortsColor: string;
}> = [
  { id: 'crimson_gold', name: 'Crimson & Gold', primaryColor: '#B91C1C', secondaryColor: '#F5C451', shortsColor: '#111827' },
  { id: 'royal_white', name: 'Royal & White', primaryColor: '#1D4ED8', secondaryColor: '#F8FAFC', shortsColor: '#F8FAFC' },
  { id: 'emerald_dark', name: 'Emerald & Onyx', primaryColor: '#047857', secondaryColor: '#F8FAFC', shortsColor: '#0F172A' },
  { id: 'obsidian_gold', name: 'Obsidian & Gold', primaryColor: '#0F172A', secondaryColor: '#F5C451', shortsColor: '#0F172A' },
  { id: 'ivory_navy', name: 'Ivory & Navy', primaryColor: '#F8FAFC', secondaryColor: '#1E3A8A', shortsColor: '#1E3A8A' },
  { id: 'sky_slate', name: 'Sky & Slate', primaryColor: '#0284C7', secondaryColor: '#0F172A', shortsColor: '#F8FAFC' },
  { id: 'violet_silver', name: 'Violet & Silver', primaryColor: '#5B21B6', secondaryColor: '#E2E8F0', shortsColor: '#1E1B4B' },
  { id: 'amber_black', name: 'Amber & Black', primaryColor: '#D97706', secondaryColor: '#111827', shortsColor: '#111827' },
];

export function resolveClubKit(club: Club, variant: 'home' | 'away'): KitConfig {
  if (variant === 'home') {
    return (
      club.homeKit ?? {
        primaryColor: club.primaryColor,
        secondaryColor: club.secondaryColor,
        shortsColor: club.secondaryColor,
        pattern: club.pattern,
      }
    );
  }
  if (club.awayKit) return club.awayKit;
  const isLightPrimary = ['#F8FAFC', '#FFFFFF', '#FAFAFA', '#F1F5F9'].includes(club.primaryColor.toUpperCase());
  return {
    primaryColor: isLightPrimary ? '#1E293B' : '#F8FAFC',
    secondaryColor: club.primaryColor,
    shortsColor: isLightPrimary ? '#0F172A' : club.primaryColor,
    pattern: 'sash',
  };
}

function mkPlayer(
  id: string,
  name: string,
  position: PlayerPosition,
  number: number,
  ovr: number,
  nationality: string,
  cardTier: Player['cardTier'] = 'gold',
  idx = 0
): Player {
  const isAtk = position === 'ATA';
  const isMid = position === 'MEI' || position === 'VOL';
  const isDef = position === 'ZAG';

  const pac = Math.min(99, Math.max(55, ovr + (isAtk ? 4 : isMid ? 1 : isDef ? -3 : -22)));
  const sho = Math.min(99, Math.max(40, ovr + (isAtk ? 4 : isMid ? -3 : isDef ? -24 : -35)));
  const pas = Math.min(99, Math.max(55, ovr + (isMid ? 4 : isAtk ? -2 : isDef ? -8 : -10)));
  const dri = Math.min(99, Math.max(50, ovr + (isAtk ? 3 : isMid ? 3 : isDef ? -12 : -28)));
  const def = Math.min(99, Math.max(35, ovr + (isDef ? 4 : position === 'VOL' ? 2 : isMid ? -14 : isAtk ? -38 : 3)));
  const phy = Math.min(99, Math.max(58, ovr + (isDef ? 3 : position === 'VOL' ? 2 : -3)));

  const hairStyles: HairStyle[] = ['short', 'fade', 'afro', 'mohawk', 'long', 'bald'];
  const hairColors = ['#1E1B18', '#3F2A1D', '#7C542B', '#D4A74A', '#0F172A'];

  return {
    id,
    name,
    position,
    number,
    ovr,
    pac,
    sho,
    pas,
    dri,
    def,
    phy,
    nationality,
    hairStyle: hairStyles[(idx + number) % hairStyles.length],
    hairColor: hairColors[(idx * 2 + number) % hairColors.length],
    cardTier,
  };
}

function buildClub(
  id: string,
  name: string,
  abbr: string,
  league: Club['league'],
  primaryColor: string,
  secondaryColor: string,
  pattern: Club['pattern'],
  icon: Club['icon'],
  stadium: string,
  roster: Array<[string, PlayerPosition, number, number, string, Player['cardTier']?]>
): Club {
  const players = roster.map(([pName, pos, num, ovr, nat, tier], idx) =>
    mkPlayer(`${id}_p${idx + 1}`, pName, pos, num, ovr, nat, tier ?? (ovr >= 89 ? 'totw' : 'gold'), idx)
  );

  const avg = (list: Player[]) =>
    list.length ? Math.round(list.reduce((s, p) => s + p.ovr, 0) / list.length) : 80;

  const att = avg(players.filter((p) => p.position === 'ATA'));
  const mid = avg(players.filter((p) => p.position === 'MEI' || p.position === 'VOL'));
  const def = avg(players.filter((p) => p.position === 'ZAG' || p.position === 'GOL'));
  const ovr = avg(players);

  const isLightPrimary = ['#F8FAFC', '#FFFFFF', '#FAFAFA', '#F1F5F9'].includes(primaryColor.toUpperCase());
  const homeKit: KitConfig = {
    primaryColor,
    secondaryColor,
    shortsColor: secondaryColor,
    pattern,
  };
  const awayKit: KitConfig = {
    primaryColor: isLightPrimary ? '#1E293B' : '#F8FAFC',
    secondaryColor: primaryColor,
    shortsColor: isLightPrimary ? '#0F172A' : primaryColor,
    pattern: 'sash',
  };

  return {
    id,
    name,
    abbr,
    league,
    primaryColor,
    secondaryColor,
    pattern,
    icon,
    homeKit,
    awayKit,
    stadium,
    ovr,
    att,
    mid,
    def,
    players,
  };
}

export const STADIUMS: StadiumOption[] = [
  { id: 'atlantico', name: 'Arena Atlântico', city: 'Costa Sul', capacity: '78.500', turfTone: '#1b6b34' },
  { id: 'real_sul', name: 'Estádio Real Sul', city: 'Capital Central', capacity: '85.000', turfTone: '#187038' },
  { id: 'horizonte', name: 'Arena Horizonte', city: 'Porto Norte', capacity: '55.200', turfTone: '#1c773b' },
  { id: 'olimpico', name: 'Estádio Olímpico Norte', city: 'Vale Alpino', capacity: '74.800', turfTone: '#176733' },
  { id: 'luz', name: 'Parque da Luz', city: 'Cidade Nova', capacity: '49.400', turfTone: '#1d7539' },
];

export const INITIAL_CLUBS: Club[] = [
  // === CLUBES NACIONAIS (12) ===
  buildClub('atletico_carioca', 'Atlético Carioca', 'ACA', 'brasileirao', '#C8102E', '#111827', 'stripes', 'flame', 'Arena Atlântico', [
    ['M. Tavares', 'GOL', 1, 82, 'ARG'],
    ['D. Azevedo', 'ZAG', 43, 80, 'BRA'],
    ['L. Queiroz', 'ZAG', 3, 83, 'BRA'],
    ['R. Sampaio', 'ZAG', 4, 82, 'BRA'],
    ['F. Gusmão', 'ZAG', 6, 81, 'BRA'],
    ['E. Villalba', 'VOL', 5, 81, 'CHI'],
    ['G. Rezende', 'MEI', 8, 85, 'BRA'],
    ['N. Salgado', 'MEI', 14, 87, 'URU', 'totw'],
    ['B. Lacerda', 'ATA', 7, 81, 'BRA'],
    ['P. Henriquez', 'ATA', 9, 86, 'BRA'],
    ['C. Monteiro', 'ATA', 27, 83, 'BRA'],
  ]),
  buildClub('ec_palestra', 'EC Palestra', 'ECP', 'brasileirao', '#006437', '#F8FAFC', 'solid', 'star', 'Estádio Olímpico Norte', [
    ['W. Barreto', 'GOL', 21, 84, 'BRA'],
    ['M. Linhares', 'ZAG', 2, 79, 'BRA'],
    ['G. Benítez', 'ZAG', 15, 85, 'PAR'],
    ['T. Fonseca', 'ZAG', 26, 82, 'BRA'],
    ['J. Morales', 'ZAG', 22, 82, 'URU'],
    ['A. Cárdenas', 'VOL', 5, 82, 'ARG'],
    ['R. Quintero', 'MEI', 8, 82, 'COL'],
    ['R. Vasconcelos', 'MEI', 23, 85, 'BRA'],
    ['E. Medeiros', 'ATA', 41, 84, 'BRA', 'totw'],
    ['F. Mendoza', 'ATA', 42, 81, 'ARG'],
    ['L. Magalhães', 'ATA', 9, 82, 'BRA'],
  ]),
  buildClub('paulista_fc', 'Paulista FC', 'PFC', 'brasileirao', '#D90429', '#F8FAFC', 'cross', 'shield', 'Arena Atlântico', [
    ['R. Toledo', 'GOL', 23, 81, 'BRA'],
    ['S. Amaral', 'ZAG', 13, 78, 'BRA'],
    ['H. Cevallos', 'ZAG', 5, 82, 'ECU'],
    ['A. Pereyra', 'ZAG', 28, 80, 'ARG'],
    ['W. Fagundes', 'ZAG', 6, 78, 'BRA'],
    ['L. Dornelles', 'VOL', 16, 80, 'BRA'],
    ['A. Cavalcanti', 'VOL', 25, 80, 'BRA'],
    ['L. Peixoto', 'MEI', 10, 82, 'BRA'],
    ['L. Nogueira', 'ATA', 7, 85, 'BRA'],
    ['J. Giménez', 'ATA', 9, 83, 'ARG'],
    ['F. Bastos', 'ATA', 47, 79, 'BRA'],
  ]),
  buildClub('sc_alvinegro', 'SC Alvinegro', 'ALV', 'brasileirao', '#111827', '#F8FAFC', 'halves', 'eagle', 'Arena Atlântico', [
    ['H. Ferraz', 'GOL', 1, 81, 'BRA'],
    ['M. Galvão', 'ZAG', 2, 78, 'BRA'],
    ['A. Seabra', 'ZAG', 5, 79, 'BRA'],
    ['F. Bolaños', 'ZAG', 3, 79, 'ECU'],
    ['M. Muniz', 'ZAG', 21, 78, 'BRA'],
    ['J. Rangel', 'VOL', 70, 79, 'VEN'],
    ['A. Paredes', 'MEI', 19, 80, 'PER'],
    ['R. Santoro', 'MEI', 10, 84, 'ARG'],
    ['T. Mascarenhas', 'ATA', 43, 79, 'BRA'],
    ['Y. Valente', 'ATA', 9, 82, 'BRA'],
    ['M. Vermeer', 'ATA', 94, 85, 'NED', 'totw'],
  ]),
  buildClub('tricolor_serra', 'Tricolor da Serra', 'TRI', 'brasileirao', '#7F1D1D', '#065F46', 'stripes', 'crown', 'Arena Atlântico', [
    ['F. Pinheiro', 'GOL', 1, 82, 'BRA'],
    ['S. Frota', 'ZAG', 2, 78, 'BRA'],
    ['T. Brandão', 'ZAG', 3, 85, 'BRA', 'icon'],
    ['T. Couto', 'ZAG', 29, 78, 'BRA'],
    ['M. Borges', 'ZAG', 12, 81, 'BRA'],
    ['A. Siqueira', 'VOL', 7, 82, 'BRA'],
    ['M. Corrêa', 'VOL', 8, 79, 'BRA'],
    ['P. Loureiro', 'MEI', 10, 82, 'BRA'],
    ['J. Montoya', 'ATA', 21, 84, 'COL'],
    ['G. Alarcón', 'ATA', 14, 82, 'ARG'],
    ['K. Arantes', 'ATA', 11, 79, 'BRA'],
  ]),
  buildClub('atletico_minas', 'Atlético das Minas', 'ATM', 'brasileirao', '#0F172A', '#F1F5F9', 'stripes', 'shield', 'Arena Atlântico', [
    ['E. Passos', 'GOL', 22, 81, 'BRA'],
    ['R. Mansilla', 'ZAG', 26, 78, 'ARG'],
    ['B. Ferreyra', 'ZAG', 21, 80, 'ARG'],
    ['J. Galeano', 'ZAG', 6, 81, 'PAR'],
    ['G. Miranda', 'ZAG', 13, 83, 'BRA'],
    ['A. Delgado', 'VOL', 23, 79, 'ECU'],
    ['F. Quiroga', 'VOL', 18, 78, 'ARG'],
    ['G. Silveira', 'MEI', 6, 82, 'BRA'],
    ['P. Cordeiro', 'ATA', 10, 83, 'BRA'],
    ['G. Macedo', 'ATA', 7, 85, 'BRA', 'hero'],
    ['D. Fontes', 'ATA', 9, 79, 'BRA'],
  ]),
  buildClub('sc_colorado', 'SC Colorado', 'COL', 'brasileirao', '#DC2626', '#FFFFFF', 'solid', 'star', 'Arena Atlântico', [
    ['S. Cabrera', 'GOL', 1, 83, 'URU'],
    ['B. Lameira', 'ZAG', 15, 78, 'BRA'],
    ['V. Morais', 'ZAG', 4, 81, 'BRA'],
    ['A. Olivera', 'ZAG', 25, 78, 'URU'],
    ['A. Zárate', 'ZAG', 26, 80, 'ARG'],
    ['F. Machado', 'VOL', 5, 80, 'BRA'],
    ['T. Guedes', 'VOL', 29, 79, 'BRA'],
    ['A. Portela', 'MEI', 10, 84, 'BRA'],
    ['W. Prates', 'ATA', 21, 80, 'BRA'],
    ['R. Valencia', 'ATA', 19, 82, 'COL'],
    ['E. Quintero', 'ATA', 13, 81, 'ECU'],
  ]),
  buildClub('gremio_azul', 'Grêmio Azul', 'GRA', 'brasileirao', '#0284C7', '#0F172A', 'stripes', 'crown', 'Arena Atlântico', [
    ['A. Roldán', 'GOL', 1, 81, 'ARG'],
    ['J. Viana', 'ZAG', 18, 78, 'BRA'],
    ['R. Chaves', 'ZAG', 5, 78, 'BRA'],
    ['J. Mesquita', 'ZAG', 28, 78, 'BRA'],
    ['R. Bueno', 'ZAG', 6, 78, 'BRA'],
    ['M. Franco', 'VOL', 20, 82, 'PAR'],
    ['D. Pimentel', 'VOL', 17, 77, 'BRA'],
    ['F. Pellegrini', 'MEI', 10, 82, 'ARG'],
    ['Y. Briceño', 'ATA', 7, 81, 'VEN'],
    ['M. Sorensen', 'ATA', 22, 82, 'DEN'],
    ['A. Fuenzalida', 'ATA', 16, 78, 'CHI'],
  ]),
  buildClub('estrela_solitaria', 'Estrela Solitária', 'EST', 'brasileirao', '#18181B', '#FAFAFA', 'stripes', 'star', 'Arena Atlântico', [
    ['J. Albuquerque', 'GOL', 12, 82, 'BRA'],
    ['V. Guimarães', 'ZAG', 2, 79, 'BRA'],
    ['B. Nkosi', 'ZAG', 15, 81, 'ANG'],
    ['A. Bustos', 'ZAG', 20, 82, 'ARG'],
    ['A. Figueiredo', 'ZAG', 13, 81, 'BRA'],
    ['G. Saraiva', 'VOL', 26, 81, 'BRA'],
    ['M. Resende', 'VOL', 17, 82, 'BRA'],
    ['T. Carranza', 'MEI', 23, 84, 'ARG', 'totw'],
    ['L. Dantas', 'ATA', 7, 84, 'BRA'],
    ['I. Vasconcelos', 'ATA', 99, 83, 'BRA'],
    ['J. Rondón', 'ATA', 10, 82, 'VEN'],
  ]),
  buildClub('cruz_malta', 'Cruz de Malta FC', 'CMF', 'brasileirao', '#09090B', '#F8FAFC', 'sash', 'anchor', 'Arena Atlântico', [
    ['L. Camargo', 'GOL', 1, 82, 'BRA'],
    ['P. Saldanha', 'ZAG', 96, 78, 'BRA'],
    ['J. Alencar', 'ZAG', 38, 79, 'BRA'],
    ['L. Castelo', 'ZAG', 3, 78, 'BRA'],
    ['L. Bezerra', 'ZAG', 6, 80, 'BRA'],
    ['H. Noronha', 'VOL', 25, 78, 'BRA'],
    ['M. Neves', 'VOL', 85, 78, 'BRA'],
    ['P. Fontoura', 'MEI', 11, 82, 'BRA'],
    ['D. Laurent', 'MEI', 10, 81, 'FRA'],
    ['P. Aguirre', 'ATA', 99, 83, 'ARG'],
    ['D. Valadares', 'ATA', 7, 78, 'BRA'],
  ]),
  buildClub('estrela_celeste', 'Estrela Celeste', 'ECE', 'brasileirao', '#1D4ED8', '#FFFFFF', 'solid', 'star', 'Arena Atlântico', [
    ['C. Moura', 'GOL', 1, 82, 'BRA'],
    ['W. Pessoa', 'ZAG', 12, 80, 'BRA'],
    ['Z. Meireles', 'ZAG', 5, 78, 'BRA'],
    ['J. Lobato', 'ZAG', 43, 79, 'BRA'],
    ['M. Aguiar', 'ZAG', 3, 79, 'BRA'],
    ['L. Maidana', 'VOL', 29, 80, 'ARG'],
    ['M. Paiva', 'MEI', 97, 81, 'BRA'],
    ['M. Bittencourt', 'MEI', 10, 85, 'BRA'],
    ['G. Antunes', 'ATA', 30, 78, 'BRA'],
    ['K. Seixas', 'ATA', 9, 80, 'BRA'],
    ['A. Leiva', 'ATA', 21, 79, 'ARG'],
  ]),
  buildClub('ec_baiano', 'EC Baiano', 'BAI', 'brasileirao', '#2563EB', '#DC2626', 'halves', 'shield', 'Arena Atlântico', [
    ['M. Furtado', 'GOL', 22, 79, 'BRA'],
    ['S. Mosquera', 'ZAG', 13, 80, 'COL'],
    ['G. Caldas', 'ZAG', 3, 79, 'BRA'],
    ['K. Sodré', 'ZAG', 4, 79, 'BRA'],
    ['L. Barcellos', 'ZAG', 46, 79, 'BRA'],
    ['C. Bandeira', 'VOL', 19, 81, 'BRA'],
    ['J. Pedrosa', 'MEI', 6, 80, 'BRA'],
    ['E. Coutinho', 'MEI', 10, 82, 'BRA'],
    ['C. Oliveira', 'MEI', 8, 81, 'BRA'],
    ['T. Teles', 'ATA', 16, 79, 'BRA'],
    ['E. Maia', 'ATA', 9, 79, 'BRA'],
  ]),

  // === CLUBES EUROPEUS (9) ===
  buildClub('real_capital', 'Real Capital', 'RCA', 'europe', '#F8FAFC', '#D97706', 'solid', 'crown', 'Estádio Real Sul', [
    ['T. Vandenberg', 'GOL', 1, 90, 'BEL'],
    ['D. Navarro', 'ZAG', 2, 87, 'ESP'],
    ['A. Richter', 'ZAG', 22, 88, 'GER'],
    ['E. Ferraz', 'ZAG', 3, 86, 'BRA'],
    ['F. Moreau', 'ZAG', 23, 84, 'FRA'],
    ['A. Delacroix', 'VOL', 14, 86, 'FRA'],
    ['F. Ibarra', 'MEI', 8, 89, 'URU'],
    ['J. Whitaker', 'MEI', 5, 91, 'ENG', 'totw'],
    ['R. Viana', 'ATA', 11, 87, 'BRA'],
    ['K. Beaumont', 'ATA', 9, 92, 'FRA', 'totw'],
    ['V. Prado', 'ATA', 7, 91, 'BRA', 'totw'],
  ]),
  buildClub('fc_catalunha', 'FC Catalunha', 'CAT', 'europe', '#1E3A8A', '#B91C1C', 'stripes', 'crown', 'Estádio Real Sul', [
    ['M. Hoffman', 'GOL', 1, 88, 'GER'],
    ['J. Thibault', 'ZAG', 23, 86, 'FRA'],
    ['P. Soler', 'ZAG', 2, 84, 'ESP'],
    ['I. Zabaleta', 'ZAG', 5, 84, 'ESP'],
    ['A. Serrano', 'ZAG', 3, 83, 'ESP'],
    ['P. Morales', 'MEI', 8, 88, 'ESP'],
    ['M. Puig', 'VOL', 17, 82, 'ESP'],
    ['D. Castellar', 'MEI', 20, 86, 'ESP'],
    ['L. Alarcón', 'ATA', 19, 88, 'ESP', 'totw'],
    ['R. Kowalski', 'ATA', 9, 89, 'POL'],
    ['R. Teixeira', 'ATA', 11, 88, 'BRA', 'totw'],
  ]),
  buildClub('manchester_sky', 'Manchester Sky', 'MSY', 'europe', '#38BDF8', '#0F172A', 'solid', 'eagle', 'Arena Horizonte', [
    ['E. Moraes', 'GOL', 31, 88, 'BRA'],
    ['K. Holloway', 'ZAG', 2, 84, 'ENG'],
    ['R. Guerreiro', 'ZAG', 3, 88, 'POR'],
    ['M. Keller', 'ZAG', 25, 85, 'SUI'],
    ['J. Kovacic', 'ZAG', 24, 86, 'CRO'],
    ['R. Espinosa', 'VOL', 16, 91, 'ESP', 'totw'],
    ['K. Vermeulen', 'MEI', 17, 90, 'BEL'],
    ['B. Tavares', 'MEI', 20, 88, 'POR'],
    ['P. Bennett', 'ATA', 47, 88, 'ENG'],
    ['E. Solberg', 'ATA', 9, 92, 'NOR', 'totw'],
    ['J. Peeters', 'ATA', 11, 83, 'BEL'],
  ]),
  buildClub('fc_bavaria', 'FC Bavária', 'BAV', 'europe', '#DC2626', '#FFFFFF', 'chevron', 'star', 'Estádio Olímpico Norte', [
    ['M. Weber', 'GOL', 1, 86, 'GER'],
    ['K. Gruber', 'ZAG', 27, 83, 'AUT'],
    ['D. Mercier', 'ZAG', 2, 85, 'FRA'],
    ['M. Park', 'ZAG', 3, 84, 'KOR'],
    ['A. Tremblay', 'ZAG', 19, 85, 'CAN'],
    ['J. Becker', 'VOL', 6, 88, 'GER'],
    ['A. Hartmann', 'VOL', 45, 82, 'GER'],
    ['J. Lindner', 'MEI', 42, 89, 'GER', 'totw'],
    ['M. Chevalier', 'ATA', 17, 85, 'FRA'],
    ['H. Fletcher', 'ATA', 9, 91, 'ENG', 'totw'],
    ['K. Lefèvre', 'ATA', 11, 84, 'FRA'],
  ]),
  buildClub('paris_etoile', 'Paris Étoile', 'PET', 'europe', '#0F2557', '#DC2626', 'stripes', 'crown', 'Parque da Luz', [
    ['G. Lombardi', 'GOL', 1, 89, 'ITA'],
    ['A. Benali', 'ZAG', 2, 86, 'MAR'],
    ['M. Monteiro', 'ZAG', 5, 87, 'BRA'],
    ['W. Caicedo', 'ZAG', 51, 83, 'ECU'],
    ['N. Azevedo', 'ZAG', 25, 85, 'POR'],
    ['V. Ferreira', 'MEI', 17, 87, 'POR'],
    ['J. Magalhães', 'VOL', 87, 84, 'POR'],
    ['W. Carpentier', 'MEI', 33, 84, 'FRA'],
    ['O. Garnier', 'ATA', 10, 87, 'FRA'],
    ['G. Fonseca', 'ATA', 9, 83, 'POR'],
    ['B. Lemaire', 'ATA', 29, 85, 'FRA'],
  ]),
  buildClub('north_london', 'North London FC', 'NLF', 'europe', '#EF4444', '#FFFFFF', 'halves', 'shield', 'Arena Horizonte', [
    ['D. Cárdenas', 'GOL', 22, 85, 'ESP'],
    ['B. Thornton', 'ZAG', 4, 84, 'ENG'],
    ['W. Marchand', 'ZAG', 2, 88, 'FRA'],
    ['G. Rezende', 'ZAG', 6, 87, 'BRA'],
    ['J. Van Dijk', 'ZAG', 12, 83, 'NED'],
    ['D. Palmer', 'VOL', 41, 88, 'ENG'],
    ['M. Halvorsen', 'MEI', 8, 89, 'NOR'],
    ['M. Velasco', 'MEI', 23, 83, 'ESP'],
    ['B. Adeyemi', 'ATA', 7, 89, 'ENG', 'totw'],
    ['K. Schneider', 'ATA', 29, 84, 'GER'],
    ['G. Soares', 'ATA', 11, 84, 'BRA'],
  ]),
  buildClub('milano_nero', 'Milano Neroazzurri', 'MNA', 'europe', '#1D4ED8', '#09090B', 'stripes', 'star', 'Estádio Olímpico Norte', [
    ['Y. Meier', 'GOL', 1, 87, 'SUI'],
    ['B. Gauthier', 'ZAG', 28, 84, 'FRA'],
    ['F. Bellini', 'ZAG', 15, 84, 'ITA'],
    ['A. Conti', 'ZAG', 95, 88, 'ITA'],
    ['D. Bakker', 'ZAG', 2, 83, 'NED'],
    ['H. Demir', 'VOL', 20, 87, 'TUR'],
    ['N. Moretti', 'MEI', 23, 88, 'ITA'],
    ['H. Vardanyan', 'MEI', 22, 83, 'ARM'],
    ['F. De Santis', 'ZAG', 32, 86, 'ITA'],
    ['L. Giménez', 'ATA', 10, 90, 'ARG', 'totw'],
    ['M. Deschamps', 'ATA', 9, 86, 'FRA'],
  ]),
  buildClub('mersey_reds', 'Mersey Reds', 'MRD', 'europe', '#B91C1C', '#FBBF24', 'solid', 'eagle', 'Arena Horizonte', [
    ['A. Guimarães', 'GOL', 1, 89, 'BRA'],
    ['T. Hawthorne', 'ZAG', 66, 87, 'ENG'],
    ['I. Diallo', 'ZAG', 5, 85, 'FRA'],
    ['V. Kuipers', 'ZAG', 4, 90, 'NED'],
    ['A. MacLeod', 'ZAG', 26, 85, 'SCO'],
    ['R. Hendriks', 'VOL', 38, 84, 'NED'],
    ['A. Gallardo', 'MEI', 10, 87, 'ARG'],
    ['D. Molnár', 'MEI', 8, 84, 'HUN'],
    ['M. Mansour', 'ATA', 11, 90, 'EGY', 'totw'],
    ['D. Correia', 'ATA', 20, 85, 'POR'],
    ['L. Castaño', 'ATA', 7, 86, 'COL'],
  ]),
  buildClub('torino_bianco', 'Torino Bianconeri', 'TBC', 'europe', '#111827', '#F8FAFC', 'stripes', 'shield', 'Estádio Olímpico Norte', [
    ['M. Ferretti', 'GOL', 29, 83, 'ITA'],
    ['A. Rinaldi', 'ZAG', 27, 83, 'ITA'],
    ['G. Alencar', 'ZAG', 3, 87, 'BRA'],
    ['F. Galli', 'ZAG', 4, 81, 'ITA'],
    ['J. Mosquera', 'ZAG', 32, 79, 'COL'],
    ['M. Cattaneo', 'VOL', 5, 83, 'ITA'],
    ['K. Girard', 'VOL', 19, 82, 'FRA'],
    ['T. Brouwer', 'MEI', 8, 85, 'NED'],
    ['F. Azevedo', 'ATA', 7, 82, 'POR'],
    ['D. Petrovic', 'ATA', 9, 85, 'SRB'],
    ['K. Kaya', 'ATA', 10, 82, 'TUR'],
  ]),
];

export const FUT_PACKS = [
  {
    id: 'gold_pack',
    name: 'Gold Premium Pack',
    cost: 1500,
    minOvr: 78,
    maxOvr: 86,
    accent: '#F5C451',
    cardsCount: 3,
  },
  {
    id: 'totw_pack',
    name: 'Champions Elite Pack',
    cost: 4000,
    minOvr: 83,
    maxOvr: 92,
    accent: '#38BDF8',
    cardsCount: 3,
  },
  {
    id: 'ultimate_pack',
    name: 'Arena Football Ultimate Icon Pack',
    cost: 7500,
    minOvr: 86,
    maxOvr: 94,
    accent: '#A855F7',
    cardsCount: 3,
  },
];
