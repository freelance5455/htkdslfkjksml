export const INITIAL_UNITS: Record<string, [string, number][]> = {
  "1": [
    ["PRADIP KUMAR BISWAS", 1820],
    ["PARTHA SARATHI SAHA", 1770],
    ["BIMAL TANTI", 1490],
    ["JAY PRAKASH GOALA", 1500],
    ["BIPRADAS MONDAL", 1110],
    ["SWAPNA PATRA", 1080],
    ["TAPAN KARMAKAR", 1090],
    ["ABHAY KUMAR", 1060],
    ["HASAN RAHAMAN MULLICK", 1090],
    ["SUVANKAR GHOSH", 1060],
    ["SUNNY GHOSH", 970],
    ["SUMONTA ADHIKARY", 970],
    ["RAJENDRA PRASAD ROUT", 1690],
    ["JAMAL", 1850],
    ["ABHIJIT PAL", 1140]
  ],
  "2": [
    ["RAMNARAYAN PRASAD", 1990],
    ["GOBINDA YADAV", 1880],
    ["HARINDRA KUMAR SINGH", 1720],
    ["ASHOK KUMAR SHOW", 1500],
    ["RANJIT KUMAR RAM", 1380],
    ["MANTU ROUTH", 1500],
    ["DADAN YADAV", 1500],
    ["KRISHNA GOALA", 1500],
    ["JITENDRA AHIR", 1500],
    ["PALTAN GHOSH", 1340],
    ["AKHILESH KUMAR MANDAL", 1150],
    ["PARTHA SAMANTA", 1250],
    ["NEWTON BISWAS", 1080],
    ["BROJO DULAL BERA", 1210],
    ["SHYAM KUMAR", 1110],
    ["AKASH KUMAR", 1060],
    ["SUSHANTA BAG", 970],
    ["AVIJIT SARKAR", 970],
    ["SURESH SADHUKHAN", 970],
    ["SURESH RAJAK", 1630],
    ["RABI ROUTH", 1060],
    ["KARTIK KANRAR", 1230],
    ["SUBRATA BHOWMICK", 1060],
    ["GOBINDO MONDOL", 1060],
    ["SUJIT MADHU", 860],
    ["TAPAS KUMAR SARKAR", 1230],
    ["SANJOY KUMAR KOLE", 890],
    ["SANJAY KUMAR", 1260],
    ["SUKANTA BASAK", 1110],
    ["PHALGUNI PRADHAN", 860],
    ["AKASH DUTTA", 860],
    ["VIKRAM KUMAR LALAN SAW", 860],
    ["ANIL CHOUDHARY", 1330],
    ["RAMA KANT SHARMA", 1190]
  ],
  "3": [
    ["KISHORE PASWAN", 1990],
    ["SK NASIR", 1720],
    ["KOUSHIK ROY", 1330],
    ["BISAMBHAR YADAV", 1450],
    ["BISUNDEO SINGH", 1450],
    ["ANJAN CHATTERJEE", 1280],
    ["CHANDAN KUMAR", 1240],
    ["AJIT KUMAR AMAR", 1240],
    ["SANDIP MANDAL", 970],
    ["ABDUL RAHID", 1340],
    ["AMIT BHATTACHARJEE", 1640],
    ["KAZI ALI AKRAM", 880],
    ["MITHUN GHOSH", 990],
    ["AMIMA KHATUN BEGUM", 1140],
    ["JHUMPA MEDDA ( MONDAL)", 1110],
    ["RUNA LAILA HALDAR", 1110],
    ["HALIMA KHATUN", 1010],
    ["MITHUN CHAKRABORTY", 1590],
    ["CHANDRADIP KARMAKAR", 1320],
    ["SUKUMAR SARKAR", 1150]
  ],
  "4": [
    ["RANJIT KORA", 2050],
    ["UMESH MONDAL", 1580],
    ["GANESH DAS", 1490],
    ["SUDIP KUMAR NASKAR", 1820],
    ["DHARMOBIR MONDAL", 1690],
    ["RAJENDRA GOALA", 1500],
    ["SUBRATA ADHIKARY", 1340],
    ["PAPPU MONDAL", 1550],
    ["BHOLA DAS", 1260],
    ["BHISON SAROJ", 1150],
    ["SRIKANTA SOREN", 1150],
    ["KAMALENDU MONDAL", 1530],
    ["ABU SADIK MANDAL", 1300],
    ["SANAT KUMAR GHOSH", 1250],
    ["SAHIED ALI", 1110],
    ["SAKIR HOSSAIN MALLICK", 1140],
    ["ARJUN SINGH", 1000],
    ["HIRANMOY MONDAL", 1250],
    ["SURAJIT DAS", 970],
    ["SUKANTA PRAMANIK", 970],
    ["ARNAB PATRA", 950],
    ["CHIRANJIT GHOSH", 970],
    ["BISWAJIT SAMANTA", 970],
    ["INDRANIL MAITY", 970],
    ["MUFTI MD.MAINUNAL HAQUE", 1140],
    ["SANJAY MANDAL", 1060],
    ["CHANCHAL NASKAR", 1090],
    ["SHANTANU NASKAR", 860],
    ["DEBASHIS ROY", 860],
    ["SUBIR PODDAR", 1760]
  ],
  "5": [
    ["RAMDHANI", 1990],
    ["CHANDAN MONDAL", 1770],
    ["AJAY SAHA", 1440],
    ["BISWANATH BANIK", 1690],
    ["SATYADEO GOND", 1500],
    ["SRIKANT KURMI", 1460],
    ["KEDAR KUMAR", 1250],
    ["RABI KUMAR OJHA", 1280],
    ["PRAVAT LAHA", 1250],
    ["NARAYAN YADAV", 1440],
    ["MINHAJ SARKAR", 1210],
    ["ANIRUDHA DUTTA", 1040],
    ["BUDDHAN BAGBAI", 1280],
    ["MITHUN DAS", 1340],
    ["SUMAN NASKAR", 860]
  ],
  "6": [
    ["ANINDA BISWAS", 1770],
    ["PREM CHAND PASI", 1770],
    ["MUKUL MUDI", 1490],
    ["RAM SAGAR YADAV", 1500],
    ["BIKASH RAM", 1500],
    ["MANOJ KUMAR", 1500],
    ["BHARAT GOALA", 1500],
    ["PURNWASI GOALA", 1500],
    ["GOURI SANKAR GOALA", 1500],
    ["BISWAJIT PAL", 1250],
    ["SATYENDRA KUMAR", 1250],
    ["PRASENJIT DEY", 1250],
    ["SANJOY MANNA", 1210],
    ["TINKU CHOUDHARY", 1280],
    ["ANADI SAHOO", 1140],
    ["KISHORE KUNAL KAUSHAL", 1250],
    ["PARTHA DAS", 970],
    ["TARAK NATH PAL", 970],
    ["SAMIRAN KHAMARU", 970],
    ["TAIMUR AL AMAN MALLICK", 970],
    ["ASHIM GHOSH", 1210],
    ["SOHAM PAL", 970],
    ["PARTHA GHOSH", 970],
    ["RAJA PAUL", 970],
    ["MANOJ DE", 1250],
    ["SAMBHU BISWAS", 1060],
    ["RAJU BISWAS", 970],
    ["DEVENDRA SOY", 1990],
    ["BABLU MURARI", 1850],
    ["ARUN SOREN", 1690]
  ],
  "7": [
    ["ASHUTOSH RAI", 1770],
    ["NIKHIL BERA", 1930],
    ["SABIR ALI MALLICK", 1670],
    ["AJIT DAS", 1500],
    ["SRIRAM KURMI", 1500],
    ["RAMA SANKAR YADAV", 1500],
    ["SUPRABHAT JANA", 1140],
    ["SHYAMAL BHANDARI", 1140],
    ["SOUMEN AMANI", 1060],
    ["MUKTA DAS", 1060],
    ["AMIT KUMAR", 860],
    ["KALYAN MANDI", 860],
    ["SAROJ KUMAR", 860]
  ],
  "MISC": [
    ["AMAN SUBHAM TIRU", 810],
    ["ASHIS MOYRA", 1110],
    ["PRABIR KUMAR MAHATO", 920]
  ]
};

// Formats numbers according to Indian locale (e.g., 1,50,000)
export const formatINR = (num: number): string => {
  return num.toLocaleString('en-IN');
};

// Converts number to words for receipts
export function numberToWordsIndian(n: number): string {
  if (n === 0) return 'Zero';
  
  const ones = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen'
  ];
  const tens = [
    '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
  ];

  function helper(num: number): string {
    let str = '';
    if (num > 99) {
      str += ones[Math.floor(num / 100)] + ' Hundred ';
      num %= 100;
    }
    if (num > 19) {
      str += tens[Math.floor(num / 10)] + ' ' + ones[num % 10];
    } else if (num > 0) {
      str += ones[num];
    }
    return str.trim();
  }

  let crore = Math.floor(n / 10000000);
  n %= 10000000;
  let lakh = Math.floor(n / 100000);
  n %= 100000;
  let thousand = Math.floor(n / 1000);
  n %= 1000;
  let remainder = n;

  let result = '';
  if (crore > 0) result += helper(crore) + ' Crore ';
  if (lakh > 0) result += helper(lakh) + ' Lakh ';
  if (thousand > 0) result += helper(thousand) + ' Thousand ';
  if (remainder > 0) result += helper(remainder);

  return result.trim() + ' Rupees Only';
}

export const COMMITTEE_INFO = {
  name: "SARBOJANIN DURGA PUJA SAMITY",
  bengaliName: "সর্বজনীন শ্রী শ্রী দুর্গাপূজা সমিতি",
  regNo: "REG/DP/2026-WB/884",
  address: "Puja Pandal Ground, Ward 12, West Bengal",
  year: "2026 / ১৪৩৩ বঙ্গাব্দ",
  treasurer: "Sanat Kumar Ghosh",
  secretary: "Pradip Kr. Biswas",
};
