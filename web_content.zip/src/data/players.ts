export type Position = 'GK'|'LB'|'CB'|'RB'|'CDM'|'CM'|'CAM'|'LW'|'RW'|'ST'|'LM'|'RM';
export type Rarity = 'Common'|'Rare'|'Elite'|'Icon';
export type Player = { id: number; name: string; country: string; position: Position; overall: number; rarity: Rarity; value: number; pace: number; shooting: number; passing: number; dribbling: number; defending: number; physical: number; stamina: number; keeper: number; };
const countries = ['England','Brazil','France','Spain','Argentina','Germany','Portugal','Netherlands','Italy','Japan','Nigeria','Morocco','USA','Mexico','South Korea','Croatia','Senegal','Colombia','Uruguay','Belgium','Ghana','Norway'];
const first = ['Adrian','Mateo','Leo','Thiago','Luis','Nico','Daniel','Rafael','Yusuf','Marcus','Ibrahim','Antonio','Enzo','Luca','Victor','Omar','Julian','Andreas','Stefan','Noah','Gabriel','Diego','Hugo','Amir','Oscar','Kai','Alex','Ruben','Pablo','Tomas','Santiago','Elias','Pedro','Emil','Finn','Hassan','Martin','Tariq','Samuel','Ivan','Dario','Benjamin','Theo','Max','Sergio','Roman','Carlos','Jules','Kenji','Keita','Christian','Bruno','Amadou','David','Felix','Nabil','Jonas','Hector','Johan','Yuki'];
const last = ['Silva','Costa','Moreira','Ramos','Santos','Torres','Alvarez','Martinez','Mendes','Walker','Bennett','Fischer','Hernandez','Sato','Kim','Diallo','Traore','Berg','Moreno','Navarro','Kovac','Rossi','Dubois','Pereira','Adebayo','Meunier','Haddad','Gomez','Diaz','Ibrahim','Lopez','Romero','Williams','Nguyen','Varela','Okafor','Duarte','Reyes','Ortega','Watanabe','Jensen','Müller','Petrov','Marin','Zhang'];
const specials: [string,string,Position,number][] = [
 ['Kylian Mbappé','France','ST',94],['Erling Haaland','Norway','ST',94],['Jude Bellingham','England','CAM',93],['Vinícius Júnior','Brazil','LW',93],['Mohamed Salah','Egypt','RW',92],['Harry Kane','England','ST',91],['Rodri','Spain','CDM',92],['Kevin De Bruyne','Belgium','CM',91],['Lamine Yamal','Spain','RW',91],['Pedri','Spain','CM',90],['Federico Valverde','Uruguay','CM',90],['Bukayo Saka','England','RW',90],['Virgil van Dijk','Netherlands','CB',90],['William Saliba','France','CB',89],['Achraf Hakimi','Morocco','RB',89],['Raphinha','Brazil','RW',89],['Lautaro Martínez','Argentina','ST',89],['Jamal Musiala','Germany','CAM',90],['Declan Rice','England','CDM',89],['Alisson Becker','Brazil','GK',90],['Thibaut Courtois','Belgium','GK',90],['Nuno Mendes','Portugal','LB',88],['Cole Palmer','England','CAM',89],['Ousmane Dembélé','France','RW',90]
];
const positions: Position[] = ['GK','LB','CB','CB','RB','CDM','CM','CAM','LW','RW','ST','ST','CM','CB','LB','RB','LW','RW','GK','LM','RM','CDM'];
function random(seed:number){ const x=Math.sin(seed*127.1+78.233)*43758.5453; return x-Math.floor(x); }
function clamp(n:number,a=29,b=99){return Math.max(a,Math.min(b,Math.round(n)));}
function createPlayer(id:number,name:string,country:string,position:Position,ovr:number):Player{
 const r=(salt:number)=>random(id*23+salt)*2-1;
 const g=position==='GK'; const attack=['ST','RW','LW','CAM','LM','RM'].includes(position); const defend=['CB','LB','RB','CDM'].includes(position);
 const pace=clamp(ovr+(g?-22:position==='CB'?-9:4)+r(1)*15);
 const shooting=clamp(ovr+(g?-39:defend?-20:position==='ST'?8:0)+r(2)*12);
 const passing=clamp(ovr+(g?-21:position==='CB'?-11:0)+r(3)*11);
 const dribbling=clamp(ovr+(g?-29:position==='CB'?-15:attack?5:0)+r(4)*12);
 const defending=clamp(ovr+(g?-35:defend?7:-25)+r(5)*12);
 const physical=clamp(ovr+(g?1:position==='CB'?7:0)+r(6)*12);
 const stamina=clamp(ovr+4+r(7)*12);
 const keeper=clamp(g?ovr+3+r(8)*7:26+r(8)*15);
 const rarity:Rarity=ovr>=91?'Icon':ovr>=82?'Elite':ovr>=70?'Rare':'Common';
 const value=Math.round((Math.pow((ovr-43)/8,3)*150+100)/50)*50;
 return {id,name,country,position,overall:ovr,rarity,value:Math.max(150,value),pace,shooting,passing,dribbling,defending,physical,stamina,keeper};
}
// 24 recognizable names (names only, no licensed images) and 276 original fictional players.
export const PLAYERS:Player[] = [
 ...specials.map(([n,c,p,o],i)=>createPlayer(i,n,c,p,o)),
 ...Array.from({length:276},(_,i)=>{const id=i+24; const name=`${first[(i*19+5)%first.length]} ${last[(i*13+Math.floor(i/44)*7)%last.length]}`;
 const pos=positions[(i*7+Math.floor(i/22))%positions.length]; const o=clamp(48+Math.floor(i/8)+Math.round(random(i+13)*9),45,87);
 return createPlayer(id,name,countries[(i*7+Math.floor(i/19))%countries.length],pos,o);})
];
export const PLAYERS_BY_ID = new Map(PLAYERS.map(p=>[p.id,p]));
export const FORMATIONS: Record<string,Position[]> = {
 '4-3-3':['GK','LB','CB','CB','RB','CM','CDM','CM','LW','ST','RW'],
 '4-2-3-1':['GK','LB','CB','CB','RB','CDM','CDM','CAM','LW','ST','RW'],
 '4-4-2':['GK','LB','CB','CB','RB','LM','CM','CM','RM','ST','ST'],
 '3-5-2':['GK','CB','CB','CB','LM','CDM','CM','CAM','RM','ST','ST']
};
export const RANKS=['Bronze','Silver','Gold','Platinum','Diamond','Sapphire','World Champion'] as const;
export function rankName(n:number){return n>=18?'World Champion':`${RANKS[Math.floor(Math.max(0,n)/3)]} ${Math.max(0,n)%3+1}`;}
export function rankTier(n:number){return Math.min(6,Math.floor(n/3));}
export function effectivePlayer(p:Player,training:number):Player {const boost=Math.min(10,training*2);return {...p,overall:Math.min(99,p.overall+boost),pace:Math.min(99,p.pace+boost),shooting:Math.min(99,p.shooting+boost),passing:Math.min(99,p.passing+boost),dribbling:Math.min(99,p.dribbling+boost),defending:Math.min(99,p.defending+boost),physical:Math.min(99,p.physical+boost),keeper:Math.min(99,p.keeper+boost),stamina:Math.min(99,p.stamina+boost)};}
export function starterSquad(){ const needed=FORMATIONS['4-3-3']; const used=new Set<number>(); return needed.map(pos=>{
 const match=PLAYERS.filter(p=>p.id>=24 && !used.has(p.id) && p.position===pos && p.overall<=65).sort((a,b)=>b.overall-a.overall)[0]
 ||PLAYERS.filter(p=>p.id>=24&&!used.has(p.id)).sort((a,b)=>a.overall-b.overall)[0]; used.add(match.id);return match.id; }); }
export const starterIds=starterSquad();
export function displayInitials(name:string){return name.split(' ').map(n=>n[0]).slice(0,2).join('');}
export const COUNTRY_FLAGS:Record<string,string>={'England':'🏴','Brazil':'🇧🇷','France':'🇫🇷','Spain':'🇪🇸','Argentina':'🇦🇷','Germany':'🇩🇪','Portugal':'🇵🇹','Netherlands':'🇳🇱','Italy':'🇮🇹','Japan':'🇯🇵','Nigeria':'🇳🇬','Morocco':'🇲🇦','USA':'🇺🇸','Mexico':'🇲🇽','South Korea':'🇰🇷','Croatia':'🇭🇷','Senegal':'🇸🇳','Colombia':'🇨🇴','Uruguay':'🇺🇾','Belgium':'🇧🇪','Ghana':'🇬🇭','Norway':'🇳🇴','Egypt':'🇪🇬'};
