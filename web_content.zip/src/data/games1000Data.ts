export interface CloudGame {
  id: string;
  title: string;
  titleBn: string;
  category: string;
  categoryBn: string;
  icon: string;
  rating: number;
  plays: string;
  badge: string;
  rewardPerMin: number; // in Coins
  description: string;
  descriptionBn: string;
  arcadeType: 'space_shooter' | 'car_racing' | 'brick_breaker' | 'flappy_bird' | 'meteor_dodge' | 'bubble_pop';
}

// Base game definitions across all 8 major genres
const BASE_GAMES_BY_CATEGORY: Record<string, {
  categoryBn: string;
  iconPool: string[];
  arcadeTypes: CloudGame['arcadeType'][];
  items: Array<{ title: string; titleBn: string; desc: string; descBn: string }>;
}> = {
  'Action & Shooting': {
    categoryBn: 'অ্যাকশন ও শুটিং',
    iconPool: ['🎯', '🔫', '🚀', '💥', '🛡️', '⚔️', '👾', '🔥', '🥷', '🦾'],
    arcadeTypes: ['space_shooter', 'meteor_dodge'],
    items: [
      { title: 'Subway Cyber Runner', titleBn: 'সাবওয়ে সাইবার রানার', desc: 'Dodge trains, lasers, and collect golden energy cells at lightning speed.', descBn: 'ট্রেন ও লেজার এড়িয়ে দ্রুত গতিতে এনার্জি কয়েন সংগ্রহ করুন।' },
      { title: 'Sniper 3D Assassin', titleBn: 'স্নাইপার থ্রিডি অ্যাসাসিন', desc: 'Take out high-value targets across dynamic city rooftop environments.', descBn: 'শহরের ছাদ থেকে গোপন লক্ষ্যবস্তুতে নিখুঁত স্নাইপার নিশানা করুন।' },
      { title: 'Stickman Shadow Fighter', titleBn: 'স্টিকম্যান শ্যাডো ফাইটার', desc: 'Unleash martial arts combos and mystical katana slices against hordes.', descBn: 'অন্ধকার শত্রুদের বিরুদ্ধে কাতানা ও মার্শাল আর্ট কম্বো ব্যবহার করুন।' },
      { title: 'Alien Galaxy Assault', titleBn: 'এলিয়েন গ্যালাক্সি অ্যাসল্ট', desc: 'Pilot advanced starfighters against swarms of cosmic alien invaders.', descBn: 'মহাকাশযানের কামান দিয়ে ভিনগ্রহের আক্রমণ প্রতিহত করুন।' },
      { title: 'Zombie Apocalypse Strike', titleBn: 'জম্বি স্ট্রাইক অ্যারেনা', desc: 'Hold down the barricade against undead waves with upgradeable weapons.', descBn: 'শক্তিশালী অস্ত্র দিয়ে জম্বিদের পরাস্ত করে বেঁচে থাকুন।' },
      { title: 'Cyber Commando Ops', titleBn: 'সাইবার কমান্ডো অপস', desc: 'Infiltrate enemy robotic fortresses with high-tech assault rifles.', descBn: 'হাই-টেক অস্ত্র নিয়ে শত্রুর রোবট ঘাঁটিতে অতর্কিত আক্রমণ চালান।' },
      { title: 'Tank Destroyer 2026', titleBn: 'ট্যাঙ্ক ডেস্ট্রয়ার ২০২৬', desc: 'Heavy armor warfare! Blast enemy cannons and capture military bases.', descBn: 'ভারী সাঁজোয়া ট্যাঙ্ক চালিয়ে শত্রুঘাঁটি ধ্বংস করে জয়ী হোন।' },
      { title: 'Ninja Blade Shadow Run', titleBn: 'নিনজা ব্লেড শ্যাডো রান', desc: 'Sprint across rooftops, throw shurikens, and defeat samurai bosses.', descBn: 'ছাদে দৌড়ে শুরিকেন ছুড়ে সামুরাইদের পরাজিত করুন।' },
      { title: 'Robo Mech Warfare', titleBn: 'রোবো মেক ওয়ারফেয়ার', desc: 'Command giant steel robots armed with plasma cannons and missile pods.', descBn: 'প্লাজমা কামান চালিত রোবটদের নিয়ে মেক ওয়ারফেয়ারে যোগ দিন।' },
      { title: 'Bounty Hunter Galaxy', titleBn: 'বাউন্টি হান্টার গ্যালাক্সি', desc: 'Track cosmic outlaws through treacherous nebulae and asteroid belts.', descBn: 'মহাজাগতিক অপরাধীদের খুঁজে বের করে প্রচুর বাউন্টি পুরস্কার জিতুন।' },
      { title: 'Special Forces SWAT Rescue', titleBn: 'স্পেশাল ফোর্সেস সোয়াত', desc: 'Breach secure rooms, defuse bombs, and rescue civilians under fire.', descBn: 'কৌশলগত অপারেশনে অংশ নিয়ে সন্ত্রাসীদের দমন করুন।' },
      { title: 'Air Combat Top Gun', titleBn: 'এয়ার কমব্যাট টপ গান', desc: 'Supersonic dogfights with heat-seeking missiles in high altitude skies.', descBn: 'আকাশে ফাইটার জেট দিয়ে শত্রুপক্ষের যুদ্ধবিমান ধ্বংস করুন।' },
      { title: 'Dungeon Knight Slayer', titleBn: 'ডানজিয়ন নাইট স্লেয়ার', desc: 'Venture into cursed catacombs to slay demons and uncover treasure chests.', descBn: 'অভিশপ্ত অন্ধকার গুহায় নেমে দানবদের পরাজিত করে গুপ্তধন পান।' },
      { title: 'Laser Drone Infiltration', titleBn: 'লেজার ড্রোন অপারেশন', desc: 'Pilot stealth micro-drones through laser tripwires and surveillance grids.', descBn: 'লেজার ট্রিপওয়্যার এড়িয়ে ড্রোন চালিয়ে মিশন সফল করুন।' },
      { title: 'Dragon Rider Arena', titleBn: 'ড্রাগন রাইডার অ্যারেনা', desc: 'Mount fire-breathing dragons and burn opposing aerial armadas.', descBn: 'আগুন ছড়ানো ড্রাগনে চড়ে আকাশের যুদ্ধক্ষেত্রে রাজত্ব করুন।' },
    ],
  },
  'Puzzle & Brain': {
    categoryBn: 'ধাঁধা ও মেধা',
    iconPool: ['🧩', '🧠', '🍬', '💎', '🔢', '🔍', '💡', '🧪', '📦', '🔮'],
    arcadeTypes: ['bubble_pop', 'brick_breaker'],
    items: [
      { title: 'Candy Match Deluxe 3', titleBn: 'ক্যান্ডি ম্যাচ ডিলাক্স ৩', desc: 'Match 3 sweet jellies, create striped wrapped bombs, and blast boards.', descBn: 'মিষ্টি ক্যান্ডি ও জেলি মিলিয়ে দুর্দান্ত বিস্ফোরণ ঘটান।' },
      { title: '2048 Hexa Mania', titleBn: '২০৪৮ হেক্সা ম্যানিয়া', desc: 'Slide and merge identical numbered hexagonal tiles to reach infinite 2048.', descBn: 'একই নম্বরের হেক্সাগন টাইলস মিলিয়ে ২০৪৮ লক্ষ্য অর্জন করুন।' },
      { title: 'Bubble Shooter Galaxy', titleBn: 'বাবল শুটার গ্যালাক্সি', desc: 'Aim your marble cannon to match 3 or more colored cosmic orbs.', descBn: 'রঙিন বুদ্বুদ লক্ষ্য করে মার্বেল ছুড়ে ক্লাস্টার ধ্বংস করুন।' },
      { title: 'Block Jewel Puzzle Master', titleBn: 'ব্লক জুয়েল পাজল মাস্টার', desc: 'Drop sparkling jewel blocks into the 10x10 grid to clear complete rows.', descBn: '১০x১০ গ্রিডে মূল্যবান রত্ন সাজিয়ে পুরো সারি মুছে কয়েন আয় করুন।' },
      { title: 'Water Sort Liquid Alchemy', titleBn: 'ওয়াটার সর্ট কালার পাজল', desc: 'Pour colorful fluids between test tubes until all colors are segregated.', descBn: 'টিউবগুলোতে একই রঙের তরল আলাদা করে বুদ্ধিদীপ্ত সমাধান করুন।' },
      { title: 'Word Search Explorer Pro', titleBn: 'ওয়ার্ড সার্চ এক্সপ্লোরার', desc: 'Unravel hidden vocabulary words in themed crossword letter grids.', descBn: 'বর্ণমালার জটলা থেকে লুকিয়ে থাকা সঠিক শব্দগুলো খুঁজে বের করুন।' },
      { title: 'Mahjong Ancient Solitaire', titleBn: 'মাহজং সলিটায়ার মাস্টার', desc: 'Match pairs of traditional bamboo, character, and seasonal tiles.', descBn: 'প্রাচীন মাহজং টাইলস মিলিয়ে বোর্ড ফাঁকা করে পয়েন্ট পান।' },
      { title: 'Sudoku Champion 9x9', titleBn: 'সুডোকু চ্যাম্পিয়ন ৯x৯', desc: 'Fill the classic Japanese grid with digits 1 through 9 with zero repeats.', descBn: '১ থেকে ৯ সংখ্যা সঠিকভাবে বসিয়ে সুডোকু গ্রিড পূর্ণ করুন।' },
      { title: 'Pipe Connect Water Flow', titleBn: 'পাইপ কানেক্ট প্লাম্বার', desc: 'Rotate plumbing valves to channel fresh reservoir water to plants.', descBn: 'পাইপ ঘুরিয়ে সঠিক সংযোগ স্থাপন করে পানির প্রবাহ চালু করুন।' },
      { title: 'Tangram Wooden Poly', titleBn: 'ট্যানগ্রাম পলিগন পাজল', desc: 'Fit geometric wooden shapes into animal and architecture silhouettes.', descBn: 'জ্যামিতিক কাঠের টুকরো সাজিয়ে সুন্দর আকৃতি তৈরি করুন।' },
      { title: 'Laser Mirror Reflection', titleBn: 'লেজার রিফ্লেকশন পাজল', desc: 'Angle quartz prisms to guide radiant laser beams to gemstone nodes.', descBn: 'কাঁচের প্রিজম ঘুরিয়ে লেজার রশ্মি ঠিক লক্ষ্যের দিকে ঘুরিয়ে দিন।' },
      { title: 'Chess Puzzle Tactics', titleBn: 'দাবা ট্যাকটিকস চ্যালেঞ্জ', desc: 'Solve mate-in-2 and tactical chess master puzzles against engine.', descBn: 'সেরা গ্র্যান্ডমাস্টার চাল দিয়ে মাত্র ২ চালে কিস্তিমাত করুন।' },
      { title: 'Brain Logic IQ Test 150', titleBn: 'আইকিউ ব্রেন টিজার ১৫০', desc: 'Mind-bending riddles and visual pattern recognition challenges.', descBn: 'চোখের ধাঁধা ও বুদ্ধিদীপ্ত লজিক্যাল প্যাটার্ন সমাধান করুন।' },
      { title: 'Block Slider Unblock Red', titleBn: 'আনব্লক রেড স্লাইডার', desc: 'Slide blocking wooden logs aside to free the special red ruby block.', descBn: 'কাঠের ব্লক সরিয়ে লাল রত্নকে বাইরে বের করার পথ তৈরি করুন।' },
      { title: 'Draw One Line Connect', titleBn: 'ওয়ান লাইন কানেক্ট পাজল', desc: 'Connect all dots on the chalkboard with a single continuous stroke.', descBn: 'এক টানে হাত না তুলে সমস্ত বিন্দু যুক্ত করে পাজল মেটান।' },
    ],
  },
  'Racing & Speed': {
    categoryBn: 'রেসিং ও স্পিড',
    iconPool: ['🏎️', '🏍️', '🚗', '🚀', '🏁', '💨', '🚓', '🚜', '🛣️', '🚤'],
    arcadeTypes: ['car_racing'],
    items: [
      { title: 'Highway Traffic Nitro Racer', titleBn: 'হাইওয়ে ট্র্যাফিক নাইট্রো', desc: 'Overtake speeding trucks on endless highways with nitrous boosters.', descBn: 'হাইওয়েতে দ্রুতগামী গাড়ি কাটিয়ে নাইট্রো পুশ দিয়ে এগিয়ে চলুন।' },
      { title: 'Moto X3M Extreme Stunt', titleBn: 'মটো এক্স৩এম এক্সট্রিম স্টান্ট', desc: 'Perform backflips over explosive barrels, spikes, and giant loops.', descBn: 'বিস্ফোরক ও লুপের ওপর দিয়ে মোটরবাইক ব্যাকফ্লিপ স্টান্ট দেখান।' },
      { title: 'Drift Boss Mountain Pass', titleBn: 'ড্রিফ্ট বস মাউন্টেন রোড', desc: 'Time your sharp corner drifts perfectly along steep cliff edges.', descBn: 'পাহাড়ের বাঁকে নির্ভুল টাইমিংয়ে ড্রিফ্ট করে টিকে থাকুন।' },
      { title: 'Super Formula GP 2026', titleBn: 'সুপার ফর্মুলা জিপি ২০২৬', desc: 'Race against 19 AI champions in slick open-wheel aerodynamic cars.', descBn: 'বিশ্বসেরা ফর্মুলা ট্র্যাকগুলোতে গতিবেগের সাথে প্রতিদ্বন্দ্বিতা করুন।' },
      { title: '4x4 Offroad Mud Monster', titleBn: '৪x৪ অফরোড মাড মনস্টার', desc: 'Conquer rocky gorges, river beds, and steep muddy inclines.', descBn: 'পাহাড় ও কাদার প্রতিকূল রাস্তায় ৪x৪ মনস্টার ট্রাক চালান।' },
      { title: 'City Police Chase Escape', titleBn: 'সিটি পুলিশ চেস এস্কেপ', desc: 'Outrun high-speed police cruisers, spike strips, and road blocks.', descBn: 'পুলিশের স্পিডবোট ও গাড়ি এড়িয়ে শহরে নিরাপদে পালান।' },
      { title: 'Cyber Hoverbike 3000', titleBn: 'সাইবার হোভারবাইক ৩০০০', desc: 'Fly magnetic levitation motorcycles through futuristic neon skyways.', descBn: 'নিয়ন আলোর আধুনিক আকাশে অ্যান্টি-গ্র্যাভিটি হোভারবাইক চালান।' },
      { title: 'Desert Buggy Rally', titleBn: 'ডেজার্ট বাগি র্যালি', desc: 'Powerslide across towering sand dunes under scorching desert heat.', descBn: 'মরুভূমির বালিয়াড়িতে স্যান্ড বাগি চালিয়ে চেকপয়েন্ট পার করুন।' },
      { title: 'Speed Boat Ocean Sprint', titleBn: 'স্পিড বোট ওশান স্প্রিন্ট', desc: 'Jump rolling ocean waves, dodge buoys, and cross the finish line.', descBn: 'সাগরের উত্তাল ঢেউয়ের ওপর স্পিডবোট ছুটিয়ে শিরোপা জিতুন।' },
      { title: 'Kart Crash Tournament', titleBn: 'কার্ট ক্র্যাশ টুর্নামেন্ট', desc: 'Throw turtle shells, banana peels, and drift through rainbow bridges.', descBn: 'মজার কার্ট রেসিংয়ে বানানা ও পাওয়ার-আপ ব্যবহার করে জিতুন।' },
      { title: 'Ambulance Emergency Rush', titleBn: 'অ্যাম্বুলেন্স ইমার্জেন্সি রাশ', desc: 'Rush through gridlock traffic to deliver emergency patients to hospital.', descBn: 'ট্র্যাফিক জ্যাম কাটিয়ে দ্রুত হাসপাতালে রোগী পৌঁছে দিন।' },
      { title: 'Neon Highway Horizon', titleBn: 'নিয়ন হাইওয়ে হরাইজন', desc: 'Synthwave aesthetic 80s supercar cruising at breakneck velocities.', descBn: 'রেট্রো মিউজিকের সাথে নিয়ন হাইওয়েতে সুপারকার ড্রাইভ করুন।' },
      { title: 'Drag Strip Burnout Pro', titleBn: 'ড্র্যাগ স্ট্রিপ বার্নআউট', desc: 'Shift gears at optimal RPM to set quarter-mile acceleration records.', descBn: 'সঠিক আরপিএমে গিয়ার বদলে ১/৪ মাইল রেকর্ড সময় অর্জন করুন।' },
      { title: 'Heavy Semi Truck Simulator', titleBn: 'হেভি ট্রাক সিমুলেটর', desc: 'Maneuver 18-wheelers carrying oversized cargo across continents.', descBn: '১৮ চাকার বিশাল ট্রেলার নিয়ে দীর্ঘ রাস্তায় নিরাপদে গাড়ি চালান।' },
      { title: 'Rocket Jetpack Highway', titleBn: 'রকেট জেটপ্যাক হাইওয়ে', desc: 'Soar inches above speeding sports cars with twin ion jetpacks.', descBn: 'জেটপ্যাক পিঠে লাগিয়ে গাড়ির ওপর দিয়ে উড়ে কয়েন সংগ্রহ করুন।' },
    ],
  },
  'Sports & Cricket': {
    categoryBn: 'স্পোর্টস ও ক্রিকেট',
    iconPool: ['🏏', '⚽', '🏀', '🎾', '🎱', '🥊', '🎯', '🏸', '🏓', '⛳'],
    arcadeTypes: ['brick_breaker', 'meteor_dodge'],
    items: [
      { title: 'Cricket Premier League 2026', titleBn: 'ক্রিকেট প্রিমিয়ার লিগ', desc: 'Smash yorkers, bouncers, and spinners into the stands for massive sixes.', descBn: 'ইয়র্কার ও বাউন্সার বলে বিশাল ছক্কা মেরে চ্যাম্পিয়ন হোন।' },
      { title: 'Gully Cricket Sixer Hit', titleBn: 'গলি ক্রিকেট ছক্কার রাজা', desc: 'Play in Indian street alleys, smash balls over terraces to win coins.', descBn: 'গলির ছাদে ও বারান্দায় বল উড়িয়ে টাকা ও কয়েন জিতুন।' },
      { title: 'Penalty Shootout World Cup', titleBn: 'পেনাল্টি শুটআউট বিশ্বকাপ', desc: 'Curve footballs into top corners past athletic world-class goalkeepers.', descBn: 'গোলকিপারকে ফাঁকি দিয়ে জালে বল জড়িয়ে গোল উৎসব করুন।' },
      { title: '8 Ball Pool Classic Club', titleBn: '৮ বল পুল বিলিয়ার্ডস', desc: 'Angle cue stick spin to sink solids, stripes, and final 8 ball cleanly.', descBn: 'নিখুঁত স্পিন ও নিশানা দিয়ে পকেটে ৮ নম্বর বল প্রবেশ করান।' },
      { title: 'Basketball Slam Dunk Pro', titleBn: 'বাস্কেটবল স্ল্যাম ডাঙ্ক', desc: 'Swipe with precision arcs to sink nothing-but-net 3-pointers and dunks.', descBn: 'সঠিক কোণে আঙুল টেনে বাস্কেটে নিখুঁত থ্রি-পয়েন্টার ফেলুন।' },
      { title: 'Table Tennis Ping Pong Star', titleBn: 'পিং পং টেবিল টেনিস', desc: 'Smash fast topspin returns and slice drop shots on indoor tables.', descBn: 'দ্রুত টপস্পিন ও স্লাইস মেরে প্রতিপক্ষকে পরাস্ত করুন।' },
      { title: 'Archery Bullseye Master 3D', titleBn: 'তীরন্দাজ বুলসআই মাস্টার', desc: 'Account for wind speed and distance to strike golden bullseyes.', descBn: 'বাতাসের গতি হিসাব করে ধনু থেকে তীরের নিখুঁত নিশানা লাগান।' },
      { title: 'Boxing Ring Knockout Hero', titleBn: 'বক্সিং রিং নকআউট হিরো', desc: 'Jab, duck, weave, and throw devastating uppercuts for 10-count knockouts.', descBn: 'জ্যাব ও আপারকাট পাঞ্চ মেরে বিপক্ষকে রিংয়ে কুপোকাত করুন।' },
      { title: 'Tennis Grand Slam Ace', titleBn: 'টেনিস গ্র্যান্ড স্ল্যাম এইস', desc: 'Serve 130mph aces on grass, clay, and hard courts to win trophies.', descBn: 'ঘাসের কোর্টে দ্রুতগতির সার্ভ ও ভলি মেরে গ্র্যান্ড স্ল্যাম জিতুন।' },
      { title: 'Golf Mini Putt Odyssey', titleBn: 'মিনি গলফ ওডিসি', desc: 'Navigate windmills, loops, and sand traps in under-par strokes.', descBn: 'উইন্ডমিল ও বাধা এড়িয়ে কম শটে গলফ বল গর্তে ফেলুন।' },
      { title: 'Super Over 1-Over Clash', titleBn: 'সুপার ওভার ১-ওভার ম্যাচ', desc: 'Defend 20 runs or chase down huge targets with only 6 balls left.', descBn: 'মাত্র ৬ বলে ২০ রানের কঠিন টার্গেট তাড়া করে জয় ছিনিয়ে নিন।' },
      { title: 'Street Basketball 3v3', titleBn: 'স্ট্রিট বাস্কেটবল ৩v৩', desc: 'Cross-over dribble, alley-oops, and street court supremacy.', descBn: 'রাস্তার কোর্টে অসাধারণ ড্রিবলিং ও ডাঙ্ক করে পয়েন্ট বাড়ান।' },
      { title: 'Badminton Smash Arena', titleBn: 'ব্যাডমিন্টন স্ম্যাশ অ্যারেনা', desc: 'Drop shuttlecock delicately on net tape and unleash leaping smashes.', descBn: 'তীক্ষ্ণ স্ম্যাশ ও ড্রপ শট দিয়ে ব্যাডমিন্টন খেলায় আধিপত্য বজায় রাখুন।' },
      { title: 'Bowling Strike King 3D', titleBn: 'বোলিং স্ট্রাইক কিং', desc: 'Hook heavy bowling balls down oiled lanes to smash all 10 pins down.', descBn: 'সবগুলো পিন এক আঘাতে ফেলে পারফেক্ট স্ট্রাইক স্কোর করুন।' },
      { title: 'Dart Board 180 Champion', titleBn: 'ডার্ট বোর্ড ১৮০ চ্যাম্পিয়ন', desc: 'Land triple 20s consistently on professional Bristle dartboards.', descBn: 'ট্রিপল ২০ পয়েন্টে ডার্ট মেরে সর্বোচ্চ ১৮০ স্কোর তুলে নিন।' },
    ],
  },
  'Board & Dice': {
    categoryBn: 'বোর্ড ও ডাইস',
    iconPool: ['🎲', '♟️', '🎯', '🎰', '🃏', '👑', '🎪', '🪵', '🪙', '⭐'],
    arcadeTypes: ['brick_breaker', 'meteor_dodge'],
    items: [
      { title: 'Ludo Supreme Star 2026', titleBn: 'লুডো সুপ্রিম স্টার ২০২৬', desc: 'Roll 6s, capture opponent pawns, secure safe stars, and reach home.', descBn: 'ডাইসে ৬ ফেলে ঘুঁটি বের করুন ও প্রতিপক্ষের ঘুঁটি কেটে বাড়ি পৌঁছান।' },
      { title: 'Snakes & Ladders Classic', titleBn: 'সাপ-লুডো ক্লাসিক', desc: 'Climb golden ladders to 100 while avoiding venomous giant king cobras.', descBn: 'মই বেয়ে ১০০ নম্বরে উঠুন এবং বিষাক্ত সাপের মুখ এড়িয়ে চলুন।' },
      { title: 'Carrom Board Pro Striker', titleBn: 'ক্যারম বোর্ড প্রো স্ট্রাইকার', desc: 'Pocket carrom men and the precious red Queen with cover bonus.', descBn: 'রেড কুইন ও সাদা-কালো গুটি পকেটে ফেলে ক্যারম চ্যাম্পিয়ন হোন।' },
      { title: 'Chess Grandmaster Engine', titleBn: 'দাবা গ্র্যান্ডমাস্টার', desc: 'Challenge rated 2500+ AI engines with deep opening books.', descBn: 'শক্তিশালী এআই-র বিরুদ্ধে দাবা খেলে আপনার বুদ্ধিমত্তা যাচাই করুন।' },
      { title: 'Checkers Draughts Crown', titleBn: 'চেকার্স ড্রাফটস ক্রাউন', desc: 'Diagonal jumping over enemy pieces to king your checkers.', descBn: 'কোনাকুনি লাফিয়ে বিপক্ষের গুটি তুলে নিয়ে ক্রাউন রাজা বানান।' },
      { title: 'Dominoes Double Six Rush', titleBn: 'ডমিনোজ ডাবল সিক্স', desc: 'Match numbered bone tiles at ends of open chain lines to block opponent.', descBn: 'একই সংখ্যার ডমিনো টাইলস জুড়ে বিপক্ষকে ব্লক করে জিতুন।' },
      { title: 'Backgammon Lord of Dice', titleBn: 'ব্যাকগ্যামন বোর্ড কিং', desc: 'Move 15 checkers according to roll of two dice and bear them off.', descBn: 'দুইটি ডাইস ঘুরিয়ে নিজের ১৫টি গুটি সবচেয়ে আগে তুলে নিন।' },
      { title: 'Dice 7 Up 7 Down Royale', titleBn: 'ডাইস সেভেন আপ-ডাউন রয়্যাল', desc: 'Bet on whether two dice will total above 7, under 7, or exact 7.', descBn: 'ডাইসের যোগফল ৭ এর বেশি, কম নাকি সমান তা প্রেডিক্ট করুন।' },
      { title: 'Chinese Checkers Star', titleBn: 'চাইনিজ চেকার্স স্টার', desc: 'Hop marbles across hexagonal star boards into destination corners.', descBn: 'মার্বেল লাফিয়ে সবার আগে তারার অপর প্রান্তে সব মার্বেল সাজান।' },
      { title: 'Monopoly Property Tycoon', titleBn: 'প্রপার্টি টাইকুন বিজনেস', desc: 'Buy streets, build luxury hotels, and collect bankrupting rents.', descBn: 'শহরের সেরা জমি কিনে হোটেল বানান ও ভাড়া আদায় করুন।' },
      { title: 'Yahtzee Five Dice Frenzy', titleBn: 'ইয়াৎজি ফাইভ ডাইস', desc: 'Roll 5 dice to score Full Houses, Straights, and 50-point Yahtzees.', descBn: '৫টি ডাইস ঘুরিয়ে ফুল হাউস ও স্ট্রেট বানিয়ে উচ্চ স্কোর তুলুন।' },
      { title: 'Tic-Tac-Toe AI Unbeatable', titleBn: 'টিক-ট্যাক-টো এআই মাস্টার', desc: 'Classic X and O tactical battle with zero-mistake algorithms.', descBn: '৩x৩ গ্রিডে এআই-র সাথে এক্স এবং ও দিয়ে বুদ্ধিদীপ্ত লড়াই করুন।' },
      { title: 'Connect 4 Four in a Row', titleBn: 'কানেক্ট ফোর ইন আ রো', desc: 'Drop yellow and red discs into vertical 7-column grids to form 4-lines.', descBn: 'উল্লম্ব গ্রিডে পরপর ৪টি রঙিন ডিস্ক সাজিয়ে লাইন পূর্ণ করুন।' },
      { title: 'Reversi Othello Black White', titleBn: 'রিভার্সি ওথেলো গেম', desc: 'Flank enemy tokens horizontally and diagonally to flip them to your color.', descBn: 'বিপক্ষের গুটি ঘিরে ফেলে নিজের রঙে উল্টে দিয়ে বোর্ড দখল করুন।' },
      { title: 'Battleship Naval Radar', titleBn: 'ব্যাটলশিপ নেভাল রাডার', desc: 'Guess coordinates to torpedo aircraft carriers, destroyers, and subs.', descBn: 'কো-অর্ডিনেট অনুমান করে শত্রুর লুকানো রণতরী ও সাবমেরিন ধ্বংস করুন।' },
    ],
  },
  'Hyper-Casual & Reflex': {
    categoryBn: 'হাইপার-ক্যাজুয়াল ও রিফ্লেক্স',
    iconPool: ['⚡', '🗡️', '🎈', '🎯', '🦘', '🌀', '🍎', '🪙', '✨', '🪓'],
    arcadeTypes: ['flappy_bird', 'meteor_dodge', 'bubble_pop'],
    items: [
      { title: 'Knife Hit Master Blade', titleBn: 'নাইফ হিট মাস্টার ব্লেড', desc: 'Throw throwing knives into spinning timber logs without hitting existing knives.', descBn: 'ঘূর্ণায়মান কাঠের গুঁড়িতে ছুরি ছুড়ে আপেল কাটুন ও লেভেল পার করুন।' },
      { title: 'Helix Jump Spiral Drop', titleBn: 'হেলিক্স জাম্প স্পাইরাল', desc: 'Rotate the helix tower to let the bouncing ball drop through safe gaps.', descBn: 'হেলিক্স টাওয়ার ঘুরিয়ে বলটিকে রঙিন ফাঁক দিয়ে নিচে নামান।' },
      { title: 'Flappy Coin Sky Glider', titleBn: 'ফ্ল্যাপী কয়েন স্কাই গ্লাইডার', desc: 'Tap rhythmically to flap wings between golden coin pipes without crashing.', descBn: 'সোনালী পাইপ এড়িয়ে ফ্ল্যাপ করে উড়ে কয়েন সংগ্রহ করুন।' },
      { title: 'Stack Tower 3D Builder', titleBn: 'স্ট্যাক টাওয়ার থ্রিডি', desc: 'Time the drop of sliding rectangular slabs to build the highest skyscraper.', descBn: 'সঠিক সময়ে ট্যাপ করে ব্লকের ওপর ব্লক বসিয়ে উঁচু টাওয়ার বানান।' },
      { title: 'Fruit Ninja Samurai Slice', titleBn: 'ফ্রুট নিনজা সামুরাই স্লাইস', desc: 'Swipe screens to slice flying watermelons, kiwis, and avoid ticking bombs.', descBn: 'আকাশে ওড়া তরমুজ ও আপেল কেটে ফেলুন, তবে বোমা এড়িয়ে চলুন।' },
      { title: 'Color Switch Obstacle Jump', titleBn: 'কালার সুইচ জাম্প', desc: 'Tap ball through spinning obstacles matching only the current ball hue.', descBn: 'বলের রঙের সাথে মিলে যাওয়া রঙিন রিং দিয়ে বল পার করান।' },
      { title: 'Pop It Antistress 3D Relax', titleBn: 'পপ ইট অ্যান্টিস্ট্রেস থ্রিডি', desc: 'Pop satisfying sensory silicone bubble grids with realistic audio.', descBn: 'শান্তিদায়ক বাবল পপ করে মানসিক চাপ দূর করুন ও রিওয়ার্ড পান।' },
      { title: 'Bottle Flip 3D Challenge', titleBn: 'বোটল ফ্লিপ থ্রিডি', desc: 'Flip water bottles with accurate torque to land standing on couches.', descBn: 'পানির বোতল বাতাসে ফ্লিপ করে সোজা দাঁড় করিয়ে কয়েন জিতুন।' },
      { title: 'Bounce Ball Brick Crusher', titleBn: 'বাউন্স বল ব্রিক ক্রাশার', desc: 'Fire 100 pinball spheres simultaneously to pulverize descending blocks.', descBn: 'একসাথে ১০০টি বল ছুড়ে নেমে আসা ব্লকের সংখ্যা শূন্য করুন।' },
      { title: 'Tap the Color Reflex Rush', titleBn: 'ট্যাপ কালার রিফ্লেক্স', desc: 'React within 0.8 seconds to match rapid color-word stroop tests.', descBn: '১ সেকেন্ডেরও কম সময়ে সঠিক রঙের বাটন ট্যাপ করে রেকর্ড করুন।' },
      { title: 'Coin Rain Basket Catch', titleBn: 'কয়েন রেইন ক্যাচার', desc: 'Slide the treasure chest left and right to catch raining coins and gems.', descBn: 'উপর থেকে পড়া সোনার কয়েন ও হীরা বাক্সে ধরে পয়েন্ট বাড়ান।' },
      { title: 'Whack A Mole Garden Hammer', titleBn: 'মোল হ্যামার গার্ডেন', desc: 'Smash subterranean moles popping out of grass burrow holes.', descBn: 'গর্ত থেকে মাথা বের করা মোলদের হাতুড়ি দিয়ে আঘাত করুন।' },
      { title: 'Balloon Popper Dart Blitz', titleBn: 'বেলুন পপার ডার্ট ব্লিটজ', desc: 'Throw darts to burst clusters of rising helium balloons before escape.', descBn: 'উপরে উড়ে যাওয়া রঙিন বেলুনগুলোতে ডার্ট ছুড়ে ফাটিয়ে দিন।' },
      { title: 'Rolling Sky Ball 3D', titleBn: 'রোলিং স্কাই বল থ্রিডি', desc: 'Guide the fast rolling speedball along narrow airborne platforms.', descBn: 'আকাশের সরু প্ল্যাটফর্মে স্পিডবল ব্যালান্স করে এগিয়ে চলুন।' },
      { title: 'Doodle Jump Galaxy Bounce', titleBn: 'ডুডল জাম্প গ্যালাক্সি', desc: 'Jump continuously on moving platforms to ascend toward deep cosmos.', descBn: 'উচ্চতায় অবস্থিত প্ল্যাটফর্মে একটানা লাফিয়ে মহাকাশের দিকে উঠুন।' },
    ],
  },
  'Retro & Arcade': {
    categoryBn: 'রেট্রো ও আর্কেড',
    iconPool: ['🕹️', '👾', '🐍', '🧱', '🚀', '🟡', '🛸', '🦖', '📺', '📼'],
    arcadeTypes: ['space_shooter', 'brick_breaker', 'meteor_dodge'],
    items: [
      { title: 'Retro Snake 97 Nokia Nostalgia', titleBn: 'রেট্রো স্নেক ৯৭ নোকিয়া', desc: 'Guide the classic monochrome 8-bit snake to eat pixel dots and grow.', descBn: 'ক্লাসিক নোকিয়া স্নেকের মতো খাবার খেয়ে লম্বা হোন ও দেওয়ালে ধাক্কা এড়ান।' },
      { title: 'Space Invaders 1978 Arcade', titleBn: 'স্পেস ইনভেডার্স ১৯৭৮', desc: 'Blast rows of descending pixelated alien bugs from behind shields.', descBn: 'নিচে নেমে আসা এলিয়েনদের গুলি করে প্রতিরক্ষা ব্যারিকেড রক্ষা করুন।' },
      { title: 'Brick Breaker Arkanoid Retro', titleBn: 'ব্রিক ব্রেকার আর্কানয়েড', desc: 'Bounce steel spheres off bottom paddles to shatter colored brick layers.', descBn: 'প্যাডেল দিয়ে বল বাউন্স করিয়ে সব ইট ভেঙে বোনাস সংগ্রহ করুন।' },
      { title: 'Pac-Maze Dot Gobbler', titleBn: 'প্যাক-মেজ ডট গোবলার', desc: 'Chomp glowing yellow dots while evading Blinky, Pinky, and Clyde ghosts.', descBn: 'ভুতদের ফাঁকি দিয়ে গোলকধাঁধার সমস্ত ডট খেয়ে লেভেল শেষ করুন।' },
      { title: 'Asteroids Vector Space 80s', titleBn: 'অ্যাস্টেরয়েডস ভেক্টর স্পেস', desc: 'Rotate vector triangle spaceships and blow gigantic meteors into dust.', descBn: 'মহাকাশে ভাসমান পাথরগুলোতে লেজার মেরে টুকরো টুকরো করুন।' },
      { title: 'Pong 1972 Vintage Duel', titleBn: 'পং ১৯৭২ ভিন্টেজ ডুয়েল', desc: 'The very first video game! Slide vertical paddles to return the square ball.', descBn: 'ভিডিও গেমের আদি রূপ! প্যাডেল দিয়ে স্কয়ার বল ফিরিয়ে পয়েন্ট নিন।' },
      { title: 'Donkey Kong Barrel Jumper', titleBn: 'ব্যারেল জাম্পার আর্কেড', desc: 'Climb construction girders and jump rolling timber barrels to save princess.', descBn: 'গড়িয়ে আসা কাঠের ব্যারেল লাফিয়ে মই বেয়ে চূড়ায় উঠুন।' },
      { title: 'Galaga Starfighter 88', titleBn: 'গালাগা স্টারফাইটার ৮৮', desc: 'Double ship tractor beam rescues and dogfights against alien swarms.', descBn: 'ভিনগ্রহের আক্রমণকারী পতঙ্গদের বিমানবহর ধ্বংস করে স্টারফাইটার বাঁচান।' },
      { title: 'Frogger Highway & River Hop', titleBn: 'ফ্রগার হাইওয়ে অ্যান্ড রিভার', desc: 'Guide brave frogs across 5 lanes of traffic and alligator-infested logs.', descBn: 'গাড়ি ও কুমির ভরা নদী পার করে ব্যাঙটিকে তার ঘরে পৌঁছান।' },
      { title: 'Dig Dug Underground Rock', titleBn: 'ডিগ ডাগ আন্ডারগ্রাউন্ড', desc: 'Tunnel through earth layers, inflate underground monsters with air pumps.', descBn: 'মাটির নিচে সুড়ঙ্গ খুঁড়ে দানবদের পাম্প করে পরাস্ত করুন।' },
      { title: 'Centipede Garden Blast', titleBn: 'সেন্টিপিড গার্ডেন ব্লাস্ট', desc: 'Shoot segmented centipedes winding down mushroom forests.', descBn: 'মাশরুম বনের মধ্যে নেমে আসা শতপদী পোকাদের গুলি করুন।' },
      { title: 'Q*bert Isometric Pyramid', titleBn: 'কিউ-বার্ট পিরামিড জাম্প', desc: 'Hop on isometric cubes to transform their colors while dodging snakes.', descBn: 'পিরামিডের ঘনকগুলোর ওপর লাফিয়ে তাদের রং বদলে দিন।' },
      { title: 'Bomberman Arena 1990', titleBn: 'বোম্বারম্যান অ্যারেনা ১৯৯০', desc: 'Place timed dynamite bombs to blast brick mazes and trap rivals.', descBn: 'টাইম বোমা পেতে দেয়াল ধ্বংস করুন এবং প্রতিপক্ষকে কোণঠাসা করুন।' },
      { title: 'Tetris Block Drop Classic', titleBn: 'টেট্রিস ব্লক ড্রপ ক্লাসিক', desc: 'Rotate falling geometric tetrominoes to clear continuous solid lines.', descBn: 'পড়ন্ত টেট্রিস ব্লকগুলো সঠিকভাবে সাজিয়ে লাইন মুছে ফেলুন।' },
      { title: 'OutRun Red Convertible Rush', titleBn: 'আউটরান কনভার্টিবল স্পিড', desc: 'Cruise in the red sports convertible with your radio tuned to classic beats.', descBn: 'রেট্রো মিউজিকের সাথে ক্লাসিক কনভার্টিবল স্পোর্টস কার চালান।' },
    ],
  },
  'Cards & Casino': {
    categoryBn: 'কার্ডস ও ক্যাসিনো',
    iconPool: ['🃏', '♠️', '♥️', '♦️', '♣️', '🎰', '🪙', '💰', '👑', '💎'],
    arcadeTypes: ['brick_breaker', 'meteor_dodge'],
    items: [
      { title: 'Teen Patti Indian Royale', titleBn: 'তিন পাত্তি ইন্ডিয়ান রয়্যাল', desc: 'Play Trail, Pure Sequence, and Pair hands with friendly coin tables.', descBn: 'ট্রায়াল ও পিওর সিকোয়েন্স বানিয়ে তিন পাত্তি টেবিলে বড় জয় নিন।' },
      { title: 'Rummy 13-Card Star Club', titleBn: 'রামি ১৩-কার্ড স্টার', desc: 'Meld cards into valid sequences and sets before declaring your win.', descBn: 'কার্ডগুলো সঠিক সিকোয়েন্স ও সেটে সাজিয়ে রামি ডিক্লেয়ার করুন।' },
      { title: 'Solitaire Klondike Classic', titleBn: 'সলিটায়ার ক্লোনডাইক ক্লাসিক', desc: 'Build 4 foundation suit piles from Ace to King in alternating colors.', descBn: 'এক্কা থেকে রাজা পর্যন্ত ক্রমানুসারে সাজিয়ে সলিটায়ার বোর্ড শেষ করুন।' },
      { title: 'Spider Solitaire 2-Suit', titleBn: 'স্পাইডার সলিটায়ার ২-স্যুট', desc: 'Arrange 8 columns of cards descending from King to Ace to clear web.', descBn: '৮টি কলামে রাজা থেকে এক্কা পর্যন্ত ক্রমানুসারে সাজিয়ে কার্ড সরান।' },
      { title: 'Blackjack 21 Vegas Dealer', titleBn: 'ব্ল্যাকজ্যাক ২১ ভেগাস', desc: 'Hit, stand, double down, and beat the dealer with hands closer to 21.', descBn: '২১ এর কাছাকাছি কার্ড যোগফল তৈরি করে ডিলারকে পরাস্ত করুন।' },
      { title: 'FreeCell Patience Master', titleBn: 'ফ্রি-সেল পেশেন্স মাস্টার', desc: 'Use 4 open reserve cells strategically to arrange entire 52-card decks.', descBn: '৪টি উন্মুক্ত সেল কাজে লাগিয়ে ৫২টি তাসের সবগুলো সাজান।' },
      { title: 'Texas Holdem Poker Showdown', titleBn: 'টেক্সাস হোল্ডেম পোকার', desc: 'Bluff, raise, and evaluate flop, turn, and river cards to win pots.', descBn: 'ফ্লপ, টার্ন ও রিভার কার্ডের সমন্বয়ে সেরা পোকার হাত তৈরি করুন।' },
      { title: 'Andar Bahar Lucky Card', titleBn: 'আন্দার বাহার লাকি কার্ড', desc: 'Predict whether matching face cards will deal on the Andar or Bahar side.', descBn: 'একই মানের কার্ড আন্দার না বাহার পাশে পড়বে তা প্রেডিক্ট করুন।' },
      { title: 'Roulette Spin European 36', titleBn: 'রুলেট স্পিন ইউরোপিয়ান', desc: 'Place chips on Red, Black, Odd, Even, or single golden lucky numbers.', descBn: 'লাল, কালো বা লাকি নম্বরে কয়েন বাজি রেখে চাকা ঘোরান।' },
      { title: 'Slot Machine Triple 777', titleBn: 'স্লট মেশিন ট্রিপল ৭৭৭', desc: 'Spin reels and hit triple 7s, gold bars, and cherries for jackpot bells.', descBn: 'স্লটের রিল ঘুরিয়ে ট্রিপল ৭ মিলিয়ে মেগা জ্যাকপট জিতে নিন।' },
      { title: 'Baccarat Punto Banco Royale', titleBn: 'বাকারা পুন্তো বাঙ্কো', desc: 'Bet on Player, Banker, or Tie as cards are dealt closest to total 9.', descBn: 'প্লেয়ার নাকি ব্যাঙ্কারের তাস ৯ এর কাছাকাছি হবে তা বেছে নিন।' },
      { title: 'TriPeaks Solitaire Island', titleBn: 'ট্রাইপিকস সলিটায়ার', desc: 'Clear 3 pyramids of cards by picking values one rank higher or lower.', descBn: 'এক ধাপ বেশি বা কম মানের কার্ড তুলে ৩টি পিরামিড ফাঁকা করুন।' },
      { title: 'Hearts Queen of Spades', titleBn: 'হার্টস কুইন অফ স্পেডস', desc: 'Avoid collecting heart penalty points and dangerous 13-point Spades Queen.', descBn: 'পেনাল্টি পয়েন্ট এবং ক্ষতিকর ইস্কাপনের রানি এড়িয়ে খেলুন।' },
      { title: 'Spades Trump Trick Taker', titleBn: 'স্পেডস ট্রাম্প ট্রিক টেকার', desc: 'Bid your tricks accurately with Spades always functioning as trump suit.', descBn: 'ইস্কাপন ট্রাম্প ব্যবহার করে বিড অনুযায়ী সঠিক সংখ্যক ট্রিক জিতুন।' },
      { title: 'Gin Rummy 2-Player Duel', titleBn: 'জিন রামি টু-প্লেয়ার', desc: 'Knock or go Gin when deadwood points drop below 10 against bot.', descBn: 'ডেডউড পয়েন্ট কমিয়ে জিন রামি ডুয়েলে জয়লাভ করুন।' },
    ],
  },
};

// Generates 1,020+ games with rich attributes, realistic play counts, ratings, and coin earnings
export function generate1000Games(): CloudGame[] {
  const games: CloudGame[] = [];
  const categories = Object.keys(BASE_GAMES_BY_CATEGORY);
  let globalIndex = 1;

  // We loop to generate ~130 games per category, giving 1,040+ total curated games
  const VARIANTS_PER_CATEGORY = 130;

  for (const cat of categories) {
    const catData = BASE_GAMES_BY_CATEGORY[cat];
    const items = catData.items;

    for (let i = 0; i < VARIANTS_PER_CATEGORY; i++) {
      const baseItem = items[i % items.length];
      const cycle = Math.floor(i / items.length);

      const icon = catData.iconPool[i % catData.iconPool.length];
      const arcadeType = catData.arcadeTypes[i % catData.arcadeTypes.length];

      let title = baseItem.title;
      let titleBn = baseItem.titleBn;

      if (cycle === 1) {
        title = `${baseItem.title} II: Turbo`;
        titleBn = `${baseItem.titleBn} ২: টার্বো`;
      } else if (cycle === 2) {
        title = `${baseItem.title}: World Edition`;
        titleBn = `${baseItem.titleBn}: ওয়ার্ল্ড এডিশন`;
      } else if (cycle === 3) {
        title = `Super ${baseItem.title} 3D`;
        titleBn = `সুপার ${baseItem.titleBn} থ্রিডি`;
      } else if (cycle === 4) {
        title = `${baseItem.title}: Championship`;
        titleBn = `${baseItem.titleBn}: চ্যাম্পিয়নশিপ`;
      } else if (cycle === 5) {
        title = `Mega ${baseItem.title} Deluxe`;
        titleBn = `মেগা ${baseItem.titleBn} ডিলাক্স`;
      } else if (cycle === 6) {
        title = `${baseItem.title}: Unlimited`;
        titleBn = `${baseItem.titleBn}: আনলিমিটেড`;
      } else if (cycle === 7) {
        title = `Ultimate ${baseItem.title} 2026`;
        titleBn = `আল্টিমেট ${baseItem.titleBn} ২০২৬`;
      } else if (cycle >= 8) {
        title = `${baseItem.title} Pro [Season ${cycle}]`;
        titleBn = `${baseItem.titleBn} প্রো [সিজন ${cycle}]`;
      }

      // Ratings between 4.6 and 5.0
      const rating = +(4.6 + ((i * 7) % 5) * 0.1).toFixed(1);
      
      // Plays count
      const playsK = 12 + ((i * 19 + cycle * 37) % 240);
      const plays = `${playsK}k plays`;

      // Badges
      const badges = ['🔥 Trending', '⚡ Instant', '🏆 Tournament', '⭐ Top Rated', '🪙 +25 Coins', '💎 Pro'];
      const badge = badges[i % badges.length];

      // Reward: 15 to 35 Coins per min
      const rewardPerMin = 20 + ((i * 3) % 15);

      games.push({
        id: `cg_${globalIndex}`,
        title,
        titleBn,
        category: cat,
        categoryBn: catData.categoryBn,
        icon,
        rating,
        plays,
        badge,
        rewardPerMin,
        description: baseItem.desc,
        descriptionBn: baseItem.descBn,
        arcadeType,
      });

      globalIndex++;
    }
  }

  return games;
}

// Singleton cache so generate1000Games runs once
let cachedGames: CloudGame[] | null = null;
export function get1000GamesCatalog(): CloudGame[] {
  if (!cachedGames) {
    cachedGames = generate1000Games();
  }
  return cachedGames;
}
