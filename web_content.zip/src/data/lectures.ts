export type LectureChapter = {
  title: string;
  /** Start position in seconds. */
  start: number;
  /** Synced companion text shown while this chapter plays (optional). */
  text?: string;
};

export type Lecture = {
  id: string;
  title: string;
  /** Scholar who delivered the lecture. */
  speaker: string;
  /** Short description of the scholar. */
  speakerNote: string;
  /** Series name, if this lecture belongs to a series. */
  series?: string;
  category: string;
  /** Cover image shown in the lecture list. */
  image: string;
  /** YouTube video ID. When set, the video plays embedded directly on this page. */
  youtubeId?: string;
  /** Channel / source that hosts the recording (shown as credit). */
  source: { label: string; url: string };
  /** Optional local/remote audio file (used when there is no video). */
  audioSrc?: string;
  /** Duration in seconds (only when known from an audio file). */
  duration?: number;
  chapters?: LectureChapter[];
};

const TANTAWI = "الشيخ علي الطنطاوي";
const TANTAWI_NOTE = "أديب وعالم سوري من دمشق، رحمه الله، عُرف ببرنامجه الإذاعي «على مائدة الإفطار».";
const BUTI = "الشيخ محمد سعيد رمضان البوطي";
const BUTI_NOTE = "عالم سوري من دمشق، وأستاذ في جامعة دمشق، رحمه الله، له دروس واسعة في التفسير والفقه.";
const BAZM = "الشيخ عبد الفتاح البزم";
const BAZM_NOTE = "مفتي دمشق السابق، ومدير معهد الفتح الإسلامي بدمشق.";
const SHAAL = "الدكتور محمد خير الشعال";
const SHAAL_NOTE = "طبيب وداعية سوري، يلقي محاضرات في التربية والإصلاح الاجتماعي وسنن الله في الخلق.";
const ARQSOUSI = "الشيخ محمد نعيم عرقسوسي";
const ARQSOUSI_NOTE = "داعية وعالم سوري من دمشق، له دروس «جلسة الصفا» في جامع الإيمان بدمشق.";
const RIFAI = "الشيخ أسامة الرفاعي";
const RIFAI_NOTE = "مفتي الجمهورية العربية السورية، وإمام جامع الشيخ عبد الكريم الرفاعي بدمشق.";

export const LECTURES: Lecture[] = [
  // ——— الشيخ علي الطنطاوي ———
  {
    id: "tantawi-ftur-1",
    title: "على مائدة الإفطار — الحلقة الأولى",
    speaker: TANTAWI,
    speakerNote: TANTAWI_NOTE,
    series: "على مائدة الإفطار",
    category: "أدب ومعارف",
    image: "/images/lecture-1.jpg",
    youtubeId: "3wbB4XbAeYY",
    source: { label: "قناة التلفزيون الشامي على يوتيوب", url: "https://www.youtube.com/watch?v=3wbB4XbAeYY" },
  },
  {
    id: "tantawi-rizq",
    title: "قضية تقسيم الأرزاق من عند الله تعالى",
    speaker: TANTAWI,
    speakerNote: TANTAWI_NOTE,
    category: "عقيدة",
    image: "/images/card-hadith.jpg",
    youtubeId: "WjjNC8AM3RE",
    source: { label: "موقع مداد على يوتيوب", url: "https://www.youtube.com/watch?v=WjjNC8AM3RE" },
  },

  // ——— الدكتور محمد خير الشعال ———
  {
    id: "shaal-tamkeen",
    title: "سُنّة الله في التمكين لعباده",
    speaker: SHAAL,
    speakerNote: SHAAL_NOTE,
    series: "محاضرات الدكتور محمد خير الشعال",
    category: "سنن إلهية",
    image: "/images/card-lectures.jpg",
    youtubeId: "LiFSTBkyF54",
    source: { label: "قناة نادر كبريت على يوتيوب", url: "https://www.youtube.com/watch?v=LiFSTBkyF54" },
  },
  {
    id: "shaal-yusari-un",
    title: "يسارعون في الخيرات",
    speaker: SHAAL,
    speakerNote: SHAAL_NOTE,
    series: "محاضرات الدكتور محمد خير الشعال",
    category: "تربية",
    image: "/images/card-adhkar.jpg",
    youtubeId: "aQduw_qaHn0",
    source: { label: "قناة نوّرني على يوتيوب", url: "https://www.youtube.com/watch?v=aQduw_qaHn0" },
  },
  {
    id: "shaal-family-disputes",
    title: "لماذا كثرت الخلافات الأسرية؟ (أسباب وحلول)",
    speaker: SHAAL,
    speakerNote: SHAAL_NOTE,
    series: "محاضرات الدكتور محمد خير الشعال",
    category: "أسرة",
    image: "/images/card-paths.jpg",
    youtubeId: "pY9wLxbCY54",
    source: { label: "قناة درر الدكتور محمد خير الشعال على يوتيوب", url: "https://www.youtube.com/watch?v=pY9wLxbCY54" },
  },

  // ——— الشيخ محمد نعيم عرقسوسي ———
  {
    id: "arqsousi-nimam",
    title: "النِّعَم المَنْسِيَّة",
    speaker: ARQSOUSI,
    speakerNote: ARQSOUSI_NOTE,
    series: "دروس جلسة الصفا",
    category: "تزكية",
    image: "/images/lecture-2.jpg",
    youtubeId: "jk5ZWPLXrhw",
    source: { label: "قناة مسجد عليمان على يوتيوب", url: "https://www.youtube.com/watch?v=jk5ZWPLXrhw" },
  },
  {
    id: "arqsousi-hijrah",
    title: "ما هو حظُّك من الهجرة؟ (الهجرة الباقية التي لا تنقطع)",
    speaker: ARQSOUSI,
    speakerNote: ARQSOUSI_NOTE,
    series: "دروس جلسة الصفا",
    category: "سيرة",
    image: "/images/card-seerah.jpg",
    youtubeId: "g4GLUIhoGTg",
    source: { label: "قناة مسجد عليمان على يوتيوب", url: "https://www.youtube.com/watch?v=g4GLUIhoGTg" },
  },
  {
    id: "arqsousi-kibr",
    title: "كيف نعالج الكبر وكيف نتخلص منه؟",
    speaker: ARQSOUSI,
    speakerNote: ARQSOUSI_NOTE,
    series: "دروس جلسة الصفا",
    category: "أخلاق",
    image: "/images/card-hadith.jpg",
    youtubeId: "LmgAEaNS3EY",
    source: { label: "قناة مسجد عليمان على يوتيوب", url: "https://www.youtube.com/watch?v=LmgAEaNS3EY" },
  },
  {
    id: "arqsousi-mulk-dunya",
    title: "مُلكُ الدنيا بحذافيرها",
    speaker: ARQSOUSI,
    speakerNote: ARQSOUSI_NOTE,
    series: "دروس جلسة الصفا",
    category: "زهد",
    image: "/images/card-sahaba.jpg",
    youtubeId: "Z11PSS8pQQM",
    source: { label: "قناة مسجد عليمان على يوتيوب", url: "https://www.youtube.com/watch?v=Z11PSS8pQQM" },
  },

  // ——— الشيخ أسامة الرفاعي ———
  {
    id: "rifai-aqidah-18",
    title: "درس العقيدة الثامن عشر — كتاب المسامرة شرح المسايرة",
    speaker: RIFAI,
    speakerNote: RIFAI_NOTE,
    series: "دروس العقيدة — المسامرة",
    category: "عقيدة",
    image: "/images/card-quran.jpg",
    youtubeId: "rrNVqAhW0ac",
    source: { label: "مؤسسة الحضارة الإسلامية على يوتيوب", url: "https://www.youtube.com/watch?v=rrNVqAhW0ac" },
  },
  {
    id: "rifai-aqidah-72",
    title: "درس العقيدة الثاني والسبعون — كتاب المسامرة شرح المسايرة",
    speaker: RIFAI,
    speakerNote: RIFAI_NOTE,
    series: "دروس العقيدة — المسامرة",
    category: "عقيدة",
    image: "/images/lecture-3.jpg",
    youtubeId: "3SKe1G12OhY",
    source: { label: "مؤسسة الحضارة الإسلامية على يوتيوب", url: "https://www.youtube.com/watch?v=3SKe1G12OhY" },
  },

  // ——— الشيخ عبد الفتاح البزم ———
  {
    id: "bazm-haya",
    title: "الحياء والعفاف زينة الفتاة",
    speaker: BAZM,
    speakerNote: BAZM_NOTE,
    series: "محاضرات التزكية — جامعة بلاد الشام",
    category: "أخلاق",
    image: "/images/card-paths.jpg",
    youtubeId: "0tNP7v79ll8",
    source: { label: "قناة مجمع الشيخ أحمد كفتارو على يوتيوب", url: "https://www.youtube.com/watch?v=0tNP7v79ll8" },
  },
  {
    id: "bazm-khutbah",
    title: "خير الأمم — خطبة في جامع السيدة رقية",
    speaker: BAZM,
    speakerNote: BAZM_NOTE,
    category: "خطب",
    image: "/images/lecture-3.jpg",
    youtubeId: "R93c7KJX2KU",
    source: { label: "قناة الجمان غزوان على يوتيوب", url: "https://www.youtube.com/watch?v=R93c7KJX2KU" },
  },

  // ——— الشيخ محمد سعيد رمضان البوطي ———
  {
    id: "buti-ibadah",
    title: "العبادة والعبودية في القرآن",
    speaker: BUTI,
    speakerNote: BUTI_NOTE,
    series: "دراسات قرآنية",
    category: "تفسير",
    image: "/images/card-quran.jpg",
    youtubeId: "sCrdFRO86_A",
    source: { label: "قناة نور الشام (منقولة على يوتيوب)", url: "https://www.youtube.com/watch?v=sCrdFRO86_A" },
  },
  {
    id: "buti-quran-studies-1",
    title: "دراسات قرآنية — الحلقة الأولى",
    speaker: BUTI,
    speakerNote: BUTI_NOTE,
    series: "دراسات قرآنية",
    category: "تفسير",
    image: "/images/card-seerah.jpg",
    youtubeId: "8ci5z87wJZg",
    source: { label: "قناة نور الشام (منقولة على يوتيوب)", url: "https://www.youtube.com/watch?v=8ci5z87wJZg" },
  },
];

export function getLecture(id: string): Lecture | undefined {
  return LECTURES.find((l) => l.id === id);
}
