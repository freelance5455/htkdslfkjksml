import { PracticeQuestion } from '../types';

export const PRACTICE_QUESTIONS: PracticeQuestion[] = [
  {
    id: 'pq-1',
    formulaId: 'newtons-second-law',
    formulaTitle: "Newton's Second Law",
    question: 'A 10 kg satellite thruster pod accelerates at 5 m/s² during stationkeeping. What is the net propulsive force exerted?',
    given: { m: 10, a: 5 },
    targetSymbol: 'F',
    targetUnit: 'N',
    options: [
      { label: 'A', value: '15 N', isCorrect: false },
      { label: 'B', value: '25 N', isCorrect: false },
      { label: 'C', value: '50 N', isCorrect: true },
      { label: 'D', value: '100 N', isCorrect: false }
    ],
    explanation: 'According to Newton’s second law, Force equals mass multiplied by acceleration: F = m × a.',
    steps: [
      'Given: m = 10 kg, a = 5 m/s²',
      'Formula: F = m × a',
      'Substitute: F = 10 × 5',
      'Calculate: F = 50',
      'Answer: 50 N'
    ]
  },
  {
    id: 'pq-2',
    formulaId: 'kinetic-energy',
    formulaTitle: 'Kinetic Energy',
    question: 'A 1000 kg electric vehicle travels at a steady highway speed of 20 m/s (72 km/h). What is its stored kinetic energy?',
    given: { m: 1000, v: 20 },
    targetSymbol: 'KE',
    targetUnit: 'kJ',
    options: [
      { label: 'A', value: '100 kJ', isCorrect: false },
      { label: 'B', value: '200 kJ', isCorrect: true },
      { label: 'C', value: '400 kJ', isCorrect: false },
      { label: 'D', value: '20,000 kJ', isCorrect: false }
    ],
    explanation: 'Kinetic energy is calculated as KE = ½ × m × v². Speed is squared.',
    steps: [
      'Given: m = 1000 kg, v = 20 m/s',
      'Formula: KE = ½ × m × v²',
      'Substitute: KE = 0.5 × 1000 × (20²)',
      'Calculate: KE = 0.5 × 1000 × 400 = 200,000 J',
      'Answer: 200 kJ'
    ]
  },
  {
    id: 'pq-3',
    formulaId: 'ohms-law-physics',
    formulaTitle: "Ohm's Law",
    question: 'A micro-controller sensing circuit has an operating voltage of 12 V across a known resistor of 6 Ω. What current flows through it?',
    given: { V: 12, R: 6 },
    targetSymbol: 'I',
    targetUnit: 'A',
    options: [
      { label: 'A', value: '0.5 A', isCorrect: false },
      { label: 'B', value: '2.0 A', isCorrect: true },
      { label: 'C', value: '6.0 A', isCorrect: false },
      { label: 'D', value: '72 A', isCorrect: false }
    ],
    explanation: "From Ohm's law V = I × R, solving for current gives I = V / R.",
    steps: [
      'Given: V = 12 V, R = 6 Ω',
      'Formula: I = V / R',
      'Substitute: I = 12 / 6',
      'Calculate: I = 2',
      'Answer: 2.0 A'
    ]
  },
  {
    id: 'pq-4',
    formulaId: 'fluid-pressure',
    formulaTitle: 'Pressure Equation',
    question: 'An industrial hydraulic press piston applies a vertical clamping force of 1000 N across a contact plate of area 0.1 m². What is the resulting surface pressure?',
    given: { F: 1000, A: 0.1 },
    targetSymbol: 'P',
    targetUnit: 'kPa',
    options: [
      { label: 'A', value: '1 kPa', isCorrect: false },
      { label: 'B', value: '10 kPa', isCorrect: true },
      { label: 'C', value: '100 kPa', isCorrect: false },
      { label: 'D', value: '10,000 kPa', isCorrect: false }
    ],
    explanation: 'Pressure is force divided by surface area: P = F / A.',
    steps: [
      'Given: F = 1000 N, A = 0.1 m²',
      'Formula: P = F / A',
      'Substitute: P = 1000 / 0.1',
      'Calculate: P = 10,000 Pa',
      'Answer: 10 kPa'
    ]
  },
  {
    id: 'pq-5',
    formulaId: 'mechanical-work',
    formulaTitle: 'Mechanical Work',
    question: 'A warehouse linear actuator pulls a sliding component with a steady force of 150 N across a displacement of 4 m. How much mechanical work is performed?',
    given: { F: 150, d: 4 },
    targetSymbol: 'W',
    targetUnit: 'J',
    options: [
      { label: 'A', value: '37.5 J', isCorrect: false },
      { label: 'B', value: '300 J', isCorrect: false },
      { label: 'C', value: '600 J', isCorrect: true },
      { label: 'D', value: '1200 J', isCorrect: false }
    ],
    explanation: 'Work equals force multiplied by distance in direction of motion: W = F × d.',
    steps: [
      'Given: F = 150 N, d = 4 m',
      'Formula: W = F × d',
      'Substitute: W = 150 × 4',
      'Calculate: W = 600',
      'Answer: 600 J'
    ]
  },
  {
    id: 'pq-6',
    formulaId: 'molarity-formula',
    formulaTitle: 'Chemical Molarity',
    question: 'A laboratory technician dissolves 0.5 moles of sodium hydroxide into a volumetric flask filled with water to 2.0 L total. What is the solution molarity?',
    given: { n: 0.5, V: 2.0 },
    targetSymbol: 'M',
    targetUnit: 'mol/L',
    options: [
      { label: 'A', value: '0.25 M', isCorrect: true },
      { label: 'B', value: '1.0 M', isCorrect: false },
      { label: 'C', value: '2.5 M', isCorrect: false },
      { label: 'D', value: '4.0 M', isCorrect: false }
    ],
    explanation: 'Molarity M = moles of solute (n) / volume in liters (V).',
    steps: [
      'Given: n = 0.5 mol, V = 2.0 L',
      'Formula: M = n / V',
      'Substitute: M = 0.5 / 2.0',
      'Calculate: M = 0.25',
      'Answer: 0.25 mol/L (M)'
    ]
  },
  {
    id: 'pq-7',
    formulaId: 'gear-ratio-speeds',
    formulaTitle: 'Gear Ratio',
    question: 'A motor drives a small 15-tooth pinion gear meshed into a large 60-tooth gear. What is the gear reduction ratio?',
    given: { Ndriven: 60, Ndriver: 15 },
    targetSymbol: 'GR',
    targetUnit: ':1',
    options: [
      { label: 'A', value: '0.25:1', isCorrect: false },
      { label: 'B', value: '2.0:1', isCorrect: false },
      { label: 'C', value: '4.0:1', isCorrect: true },
      { label: 'D', value: '8.0:1', isCorrect: false }
    ],
    explanation: 'Gear Ratio = Driven gear teeth / Driver gear teeth = 60 / 15 = 4.0:1.',
    steps: [
      'Given: Ndriven = 60 teeth, Ndriver = 15 teeth',
      'Formula: GR = Ndriven / Ndriver',
      'Substitute: GR = 60 / 15',
      'Calculate: GR = 4.0',
      'Answer: 4.0:1'
    ]
  },
  {
    id: 'pq-8',
    formulaId: 'pythagorean-theorem',
    formulaTitle: 'Pythagorean Theorem',
    question: 'A mobile robot navigates 3 meters East, then turns 90 degrees and moves 4 meters North. What is the direct straight-line distance from its origin?',
    given: { a: 3, b: 4 },
    targetSymbol: 'c',
    targetUnit: 'm',
    options: [
      { label: 'A', value: '5 m', isCorrect: true },
      { label: 'B', value: '7 m', isCorrect: false },
      { label: 'C', value: '12 m', isCorrect: false },
      { label: 'D', value: '25 m', isCorrect: false }
    ],
    explanation: 'Using the Pythagorean theorem c = √(a² + b²) = √(3² + 4²) = √25 = 5 m.',
    steps: [
      'Given: a = 3 m, b = 4 m',
      'Formula: c = √(a² + b²)',
      'Substitute: c = √(3² + 4²) = √(9 + 16)',
      'Calculate: c = √25 = 5',
      'Answer: 5 m'
    ]
  }
];
