import { Category } from '../types';

export const SEED_CATEGORIES: Category[] = [
  {
    id: 'mathematics',
    name: 'Mathematics',
    slug: 'mathematics',
    description: 'Fundamental equations from algebra, geometry, trigonometry, and calculus.',
    icon: 'Sigma',
    subcategories: [
      'Algebra',
      'Geometry',
      'Trigonometry',
      'Calculus',
      'Statistics',
      'Probability',
      'Coordinate Geometry',
      'Financial Math'
    ],
    order: 1,
    enabled: true
  },
  {
    id: 'physics',
    name: 'Physics',
    slug: 'physics',
    description: 'Laws governing the physical universe: mechanics, thermodynamics, electromagnetism, and waves.',
    icon: 'Atom',
    subcategories: [
      'Mechanics',
      'Motion',
      'Forces',
      'Energy & Work',
      'Electricity',
      'Magnetism',
      'Waves & Optics',
      'Thermodynamics'
    ],
    order: 2,
    enabled: true
  },
  {
    id: 'chemistry',
    name: 'Chemistry',
    slug: 'chemistry',
    description: 'Quantitative relations in chemical systems, stoichiometry, thermodynamics, and kinetics.',
    icon: 'FlaskConical',
    subcategories: [
      'Stoichiometry & Moles',
      'Gas Laws',
      'Solutions & Concentration',
      'Thermochemistry',
      'Electrochemistry',
      'Kinetics'
    ],
    order: 3,
    enabled: true
  },
  {
    id: 'engineering',
    name: 'Engineering',
    slug: 'engineering',
    description: 'Mechanical, civil, electrical, and control system engineering calculations.',
    icon: 'Cpu',
    subcategories: [
      'Mechanical Engineering',
      'Electrical Engineering',
      'Fluid Mechanics',
      'Materials & Stress',
      'Control Systems',
      'Thermodynamics'
    ],
    order: 4,
    enabled: true
  },
  {
    id: 'aerospace',
    name: 'Aerospace',
    slug: 'aerospace',
    description: 'Orbital mechanics, propulsion, atmospheric aerodynamics, and rocket dynamics.',
    icon: 'Rocket',
    subcategories: [
      'Orbital Mechanics',
      'Rocket Propulsion',
      'Aerodynamics',
      'Atmospheric Flight',
      'Reentry & Trajectory'
    ],
    order: 5,
    enabled: true
  },
  {
    id: 'electronics',
    name: 'Electronics',
    slug: 'electronics',
    description: 'Circuit analysis, signal processing, filter design, and semiconductor physics.',
    icon: 'Zap',
    subcategories: [
      'DC Circuits',
      'AC Circuits',
      'Semiconductors',
      'Filter Design',
      'Digital Logic'
    ],
    order: 6,
    enabled: true
  },
  {
    id: 'robotics',
    name: 'Robotics',
    slug: 'robotics',
    description: 'Kinematics, dynamics, actuator sizing, and sensor telemetry algorithms.',
    icon: 'Bot',
    subcategories: [
      'Kinematics',
      'Motor Sizing & Torque',
      'Sensors & Odometry',
      'PID Control'
    ],
    order: 7,
    enabled: true
  },
  {
    id: 'statistics',
    name: 'Statistics',
    slug: 'statistics',
    description: 'Descriptive stats, dispersion, probability distributions, and hypothesis tests.',
    icon: 'BarChart2',
    subcategories: [
      'Descriptive Statistics',
      'Probability',
      'Sampling Distributions',
      'Regression'
    ],
    order: 8,
    enabled: true
  }
];
