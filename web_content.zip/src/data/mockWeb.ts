import { Bookmark, DownloadFile, PageContent, BlockedItem } from '../types/browser';

export const DEFAULT_BOOKMARKS: Bookmark[] = [
  {
    id: 'b1',
    title: 'DuckDuckGo',
    url: 'https://duckduckgo.com',
    icon: 'Search',
    category: 'Search',
  },
  {
    id: 'b2',
    title: 'EFF Cover Your Tracks',
    url: 'https://coveryourtracks.eff.org',
    icon: 'ShieldCheck',
    category: 'Privacy Test',
  },
  {
    id: 'b3',
    title: 'Privacy Guides',
    url: 'https://privacyguides.org',
    icon: 'Lock',
    category: 'Security',
  },
  {
    id: 'b4',
    title: 'The Tor Project',
    url: 'https://torproject.org',
    icon: 'Globe',
    category: 'Anonymity',
  },
  {
    id: 'b5',
    title: 'Wikipedia: Privacy',
    url: 'https://en.wikipedia.org/wiki/Internet_privacy',
    icon: 'BookOpen',
    category: 'Knowledge',
  },
  {
    id: 'b6',
    title: 'Hacker News',
    url: 'https://news.ycombinator.com',
    icon: 'Terminal',
    category: 'Tech News',
  },
];

export const MOCK_DOWNLOADS: DownloadFile[] = [
  {
    id: 'd1',
    name: 'aegis-privacy-whitepaper-v4.pdf',
    size: '2.4 MB',
    date: 'Today, 09:41 AM',
    status: 'safe',
    hash: 'sha256: 8f4a2b91c0e3...617a',
  },
  {
    id: 'd2',
    name: 'tor-circuit-diagnostic-log.txt',
    size: '412 KB',
    date: 'Yesterday',
    status: 'scanned',
    hash: 'sha256: d18e77a452fc...3b01',
  },
];

export const TRACKER_DATABASE: Record<string, BlockedItem[]> = {
  'duckduckgo.com': [],
  'torproject.org': [],
  'privacyguides.org': [],
  'coveryourtracks.eff.org': [],
  'en.wikipedia.org': [],
  'news.ycombinator.com': [],
  'default': [
    {
      id: 'tr-1',
      name: 'Google Analytics 4 & Tag Manager',
      domain: 'google-analytics.com',
      category: 'Analytics',
      risk: 'High',
    },
    {
      id: 'tr-2',
      name: 'Meta / Facebook Pixel Beacon',
      domain: 'connect.facebook.net',
      category: 'Social Tracker',
      risk: 'High',
    },
    {
      id: 'tr-3',
      name: 'Criteo Retargeting Graph',
      domain: 'criteo.net',
      category: 'Advertising',
      risk: 'Medium',
    },
    {
      id: 'tr-4',
      name: 'FingerprintJS Canvas Probe',
      domain: 'api.fpjs.io',
      category: 'Fingerprinting',
      risk: 'High',
    },
    {
      id: 'tr-5',
      name: 'Hotjar DOM Session Replay',
      domain: 'static.hotjar.com',
      category: 'Session Replay',
      risk: 'High',
    },
    {
      id: 'tr-6',
      name: 'Branch.io Cross-App Fingerprinter',
      domain: 'app.link',
      category: 'Fingerprinting',
      risk: 'Medium',
    },
  ],
};

export const BUILTIN_PAGES: Record<string, PageContent> = {
  'duckduckgo.com': {
    title: 'DuckDuckGo — Privacy, simplified.',
    url: 'https://duckduckgo.com',
    interactiveType: 'duckduckgo',
    summary: 'The search engine that doesn\'t track you. No profiling, no targeted ads, zero search history retained.',
  },
  'coveryourtracks.eff.org': {
    title: 'Cover Your Tracks | Electronic Frontier Foundation',
    url: 'https://coveryourtracks.eff.org',
    interactiveType: 'eff_test',
    summary: 'Comprehensive browser fingerprint audit tool created by the Electronic Frontier Foundation (EFF).',
  },
  'privacyguides.org': {
    title: 'Privacy Guides — Digital Privacy & Hardening',
    url: 'https://privacyguides.org',
    interactiveType: 'privacy_guides',
    summary: 'Open-source security recommendations for hardware, operating systems, encrypted messaging, and defensive browsing.',
  },
  'torproject.org': {
    title: 'The Tor Project | Anonymity Online',
    url: 'https://torproject.org',
    interactiveType: 'article',
    readTime: '4 min read',
    summary: 'Defend yourself against network surveillance and traffic analysis through multi-hop onion routing.',
    sections: [
      {
        heading: 'What is Onion Routing?',
        paragraphs: [
          'Tor directs Internet traffic through a free, worldwide, volunteer overlay network consisting of more than seven thousand relays. This conceals a user\'s location and usage from anyone conducting network surveillance or traffic analysis.',
          'Using Tor makes it much more difficult to trace Internet activity to the user. This includes visits to Web sites, online posts, instant messages, and other communication forms.',
        ],
        quote: 'Privacy is not about having something to hide. It is about personal autonomy and freedom from mass commercial profiling.',
        list: [
          'Three-hop encrypted circuit (Guard Relay → Middle Relay → Exit Relay)',
          'Cryptographic layer peeled off at each hop like onion skins',
          'Defense against browser fingerprinting through unified user-agent parity',
          'Elimination of persistent device cookies and canvas leakages',
        ],
      },
      {
        heading: 'Aegis Browser Tor Circuit Integration',
        paragraphs: [
          'Aegis for Android natively simulates an ephemeral Tor routing circuit for sensitive sessions. All outgoing socket connections are routed through verified SOCKS5 tunnels with strict DNS over Tor protection.',
          'Your IP address is hidden from destination web servers, preventing geolocation tracking and ISP packet sniffing.',
        ],
      },
    ],
  },
  'en.wikipedia.org/wiki/Internet_privacy': {
    title: 'Internet Privacy — Wikipedia',
    url: 'https://en.wikipedia.org/wiki/Internet_privacy',
    interactiveType: 'article',
    readTime: '6 min read',
    summary: 'Internet privacy involves the right or mandate of personal privacy concerning the storing, repurposing, providing to third parties, and displaying of information pertaining to oneself via the Internet.',
    sections: [
      {
        heading: 'Risks to Internet Privacy',
        paragraphs: [
          'The risks to privacy on the Internet encompass commercial tracking networks, cross-app advertising identifiers (AAID), browser fingerprinting, government mass data collection, and malicious credential harvesting.',
          'Browser fingerprinting is a method of tracking web browsers by collecting information about the browser configuration, such as screen dimensions, installed fonts, WebGL canvas render traits, and audio stack response latency.',
        ],
        list: [
          'HTTP Cookies & Supercookies (HSTS-based persistent tokens)',
          'HTML5 Canvas & WebGL hardware fingerprinting',
          'IP address logging and ISP-level unencrypted SNI harvesting',
          'Social media embedded widgets and tracking telemetry beacons',
        ],
      },
      {
        heading: 'Countermeasures & Defensive Architecture',
        paragraphs: [
          'Modern privacy-focused mobile browsers employ strict partitioning of state, ephemeral sandbox sessions, randomized canvas noise, and DNS-over-HTTPS (DoH) with automated tracker domain blacklisting.',
        ],
      },
    ],
  },
  'news.ycombinator.com': {
    title: 'Hacker News — Privacy & Systems',
    url: 'https://news.ycombinator.com',
    interactiveType: 'hackernews',
    summary: 'Curated technical news and community discussions focusing on encryption, security, and decentralized technology.',
  },
};

export const SAMPLE_SEARCH_RESULTS: Record<string, { title: string; url: string; snippet: string }[]> = {
  'privacy': [
    {
      title: 'Electronic Frontier Foundation — Defending Digital Rights',
      url: 'https://eff.org',
      snippet: 'The EFF is the leading nonprofit defending digital privacy, free speech, and civil liberties in the networked world.',
    },
    {
      title: 'Privacy Guides: Recommended Tools & Software (2026)',
      url: 'https://privacyguides.org',
      snippet: 'Security-focused recommendations for secure operating systems, Android browsers, encrypted messaging, and private search.',
    },
    {
      title: 'How to Prevent Browser Fingerprinting in Android',
      url: 'https://coveryourtracks.eff.org/learn',
      snippet: 'Fingerprinting uses unique characteristics of your browser and device to track you across the web without cookies.',
    },
    {
      title: 'Signal Messenger: Private, End-to-End Encrypted Conversations',
      url: 'https://signal.org',
      snippet: 'State-of-the-art end-to-end encryption (powered by open-source Signal Protocol) keeps your chats safe.',
    },
  ],
  'android': [
    {
      title: 'Hardening Android for Maximum Privacy & Sandboxing',
      url: 'https://privacyguides.org/android',
      snippet: 'Guidelines for running private Android environments: GrapheneOS, app sandboxing, permission auditing, and encrypted DNS.',
    },
    {
      title: 'Aegis Privacy Engine Architecture for Android',
      url: 'https://aegis-browser.org/specs',
      snippet: 'Deep dive into Aegis ephemeral memory architecture, zero-persistence tabs, and hardware canvas jitter defenses.',
    },
  ],
};
