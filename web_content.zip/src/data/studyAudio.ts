import type { StudyRecitation } from '../components/study/StudySoundPanel';

// لا تُنزَّل التلاوات محلياً؛ يعمل كل خيار داخل مشغّل YouTube بعد اختيار الطالب وضغط التشغيل.
export const STUDY_RECITATIONS: StudyRecitation[] = [
  {
    id: 'baqarah-alafasy',
    videoId: 'X2YnP50cwNU',
    title: 'سورة البقرة كاملة',
    reciter: 'مشاري راشد العفاسي',
    sourceChannel: 'Alafasy (@alafasy)',
    duration: '٢:٠٤:١٥',
  },
  {
    id: 'baqarah-luhaidan',
    videoId: 'Mnd-_D8jEF0',
    title: 'آيات من سورة البقرة',
    reciter: 'الشيخ محمد اللحيدان',
    sourceChannel: 'قناة محمد اللحيدان @Alluhaydan',
    duration: '٠٣:١٥',
    note: 'المقطع منشور ضمن محتوى القناة؛ التشغيل يدوي داخل التطبيق.',
  },
  {
    id: 'mulk-alafasy',
    videoId: 'JFhEEI7-SH4',
    title: 'سورة الملك وفضلها',
    reciter: 'مشاري راشد العفاسي',
    sourceChannel: 'Alafasy (@alafasy)',
    duration: '٠٩:٣٠',
    note: 'تتضمن مقدمة قصيرة قبل التلاوة.',
  },
  {
    id: 'insan-alafasy',
    videoId: 'gklkcgjyaxQ',
    title: 'سورة الإنسان كاملة',
    reciter: 'مشاري راشد العفاسي',
    sourceChannel: 'مدرجة في قائمة تلاوات قناة Alafasy',
    duration: '٠٥:١٨',
  },
  {
    id: 'jinn-alafasy',
    videoId: 'Ks3VpDIfEnw',
    title: 'سورة الجن كاملة',
    reciter: 'مشاري راشد العفاسي',
    sourceChannel: 'مدرجة في قائمة تلاوات قناة Alafasy',
    duration: '٠٧:٠٥',
  },
];
