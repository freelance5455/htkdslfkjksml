export interface MemoryRadiographCard {
  id: string;
  titleAr: string;
  titleFr: string;
  titleEn: string;
  category: 'xray' | 'ct' | 'ultrasound';
  difficulty: 'E' | 'D' | 'C' | 'B' | 'A';
  // SVG procedural radiograph rendering key & parameters
  radiographType: 'pneumothorax' | 'epidural' | 'shoulder_luxation' | 'colles_fracture' | 'femur_neck' | 'waters_sinus' | 'cardiomegaly' | 'gallstone_echo' | 'pneumoperitoneum';
  descriptionAr: string;
  descriptionFr: string;
  keySigns: string[];
  optionsAr: string[];
  optionsFr: string[];
  optionsEn: string[];
  correctIndex: number;
  explanationAr: string;
  explanationFr: string;
  clinicalTipAr: string;
}

export const MEMORY_CHALLENGE_CARDS: MemoryRadiographCard[] = [
  {
    id: 'mem-01',
    titleAr: 'صورة الصدر الإشعاعية',
    titleFr: 'Radiographie Thoracique',
    titleEn: 'Chest Radiograph',
    category: 'xray',
    difficulty: 'D',
    radiographType: 'pneumothorax',
    descriptionAr: 'صورة صدر مكبرة للجانب الأيمن تظهر خطاً رفيعاً فاصلاً بين الرئة المتقبضة وجدار الصدر مع غياب الأوعية الرئوية.',
    descriptionFr: 'Cliché montrant un hyperclarté avasculaire au sommet pulmonaire droit avec décollement de la plèvre viscérale.',
    keySigns: ['خط الجنب الحشوي المفصول (Ligne pleurale)', 'غياب التفرعات الوعائية في القمة الرئوية', 'فرط الشفافية الهوائي الحاد'],
    optionsAr: [
      'استرواح الصدر الأيمن (Pneumothorax droit)',
      'انصباب جنبي سائل قاعدي (Épanchement pleural)',
      'تضخم شديد في عضلة القلب (Cardiomégalie)',
      'ذات الرئة الفصية اليمنى (Pneumonie lobaire)'
    ],
    optionsFr: [
      'Pneumothorax droit avec atélectasie rétractile',
      'Épanchement pleural liquidien de la base',
      'Cardiomégalie globale',
      'Pneumonie franche lobaire aiguë'
    ],
    optionsEn: [
      'Right pneumothorax with collapsed visceral pleura',
      'Pleural effusion',
      'Cardiomegaly',
      'Lobar pneumonia'
    ],
    correctIndex: 0,
    explanationAr: 'يتميز استرواح الصدر بظهور منطقة سوداء مفرطة الشفافية خالية تماماً من علامات الأوعية الدموية مع رؤية حافة الرئة المنكمشة بوضوح.',
    explanationFr: 'Le pneumothorax se traduit par un espace aérique transparent avasculaire bordé par la ligne fine de la plèvre viscérale rétractée.',
    clinicalTipAr: 'في حالات الاسترواح الخفي، إجراء صورة صدر في وضعية الزفير (Expiration) يبرز الانكماش ويؤكد التشخيص.'
  },
  {
    id: 'mem-02',
    titleAr: 'مفراس الدماغ بدون حقن',
    titleFr: 'TDM Cérébrale sans injection',
    titleEn: 'Non-Contrast Brain CT',
    category: 'ct',
    difficulty: 'C',
    radiographType: 'epidural',
    descriptionAr: 'مقطع عرضي لسكانير المخ يظهر تجمعاً دموياً ناصع البياض محدب الوجهين (عدسي) ملتصقاً بعظم الجمجمة.',
    descriptionFr: 'Coupe axiale montrant une masse hyperdense spontanée biconvexe en lentille temporo-pariétale.',
    keySigns: ['شكل عدسي محدب الوجهين (Lentille biconvexe)', 'كثافة دموية مرتفعة (+65 إلى +75 UH)', 'لا يعبر الدروز القحفية العظمية'],
    optionsAr: [
      'ورم دموي فوق الجافية الشرياني (Hématome extra-dural)',
      'ورم دموي تحت الجافية هلالي الشكل (Hématome sous-dural)',
      'سكتة دماغية إقفارية بنقص الكثافة (AVC ischémique)',
      'استسقاء دماغي بطيني حاد (Hydrocéphalie)'
    ],
    optionsFr: [
      'Hématome extra-dural biconvexe post-traumatique',
      'Hématome sous-dural en croissant de lune',
      'Accident vasculaire cérébral ischémique',
      'Hydrocéphalie obstructive'
    ],
    optionsEn: [
      'Epidural hematoma (biconvex lens)',
      'Subdural hematoma (crescent shape)',
      'Acute ischemic stroke',
      'Obstructive hydrocephalus'
    ],
    correctIndex: 0,
    explanationAr: 'الورم الدموي فوق الجافية ينجم غالباً عن تمزق الشريان السحائي الأوسط ويأخذ شكلاً محدب الوجهين لالتصاق الأم الجافية الشديد بالدروز العظمية.',
    explanationFr: 'L’hématome extra-dural est une urgence neurochirurgicale absolue liée à la rupture de l’artère méningée moyenne, bloquée aux sutures crâniennes.',
    clinicalTipAr: 'حالة طوارئ جراحية قصوى تستوجب إبلاغ جراح الأعصاب فور رؤية الصورة على شاشة السكانير.'
  },
  {
    id: 'mem-03',
    titleAr: 'صورة الكتف الشعاعية',
    titleFr: 'Radiographie de l’Épaule',
    titleEn: 'Shoulder Radiograph',
    category: 'xray',
    difficulty: 'D',
    radiographType: 'shoulder_luxation',
    descriptionAr: 'صورة لوجه مفصل الكتف تظهر رأس عظم العضد منحرفاً نحو الأسفل والداخل تحت النتوء الغرابي، خارج الحفرة الحقانية.',
    descriptionFr: 'Cliché montrant la tête humérale projetée en dedans et sous le processus coracoïde, hors de la cavité glénoïdale.',
    keySigns: ['فقدان التمفصل الحقاني العضدي الطبيعي', 'رأس العضد تحت النتوء الغرابي (Sous-coracoïdien)', 'تسطح الكتف (علامة الكتافية)'],
    optionsAr: [
      'خلع الكتف الأمامي الإنسي (Luxation antéro-interne)',
      'كسر معزول في عنق عظم العضد الجراحي (Fracture du col)',
      'فصال عظمي تنكسي شديد (Omarthrose)',
      'تكلس وتر العضلة فوق الشوكة (Tendinite calcifiante)'
    ],
    optionsFr: [
      'Luxation antéro-interne de l’épaule (sous-coracoïdienne)',
      'Fracture isolée du col chirurgical de l’humérus',
      'Omarthrose gléno-humérale évoluée',
      'Calcification de la coiffe des rotateurs'
    ],
    optionsEn: [
      'Anterior glenohumeral shoulder dislocation',
      'Humeral surgical neck fracture',
      'Glenohumeral osteoarthritis',
      'Rotator cuff calcification'
    ],
    correctIndex: 0,
    explanationAr: 'يشكل الخلع الأمامي الإنسي أكثر من 95% من خلوغ الكتف، ويظهر فيه رأس العضد مزاحاً للداخل وأسفل الغرابي.',
    explanationFr: 'La luxation antéro-interne est la plus fréquente (95%), avec tête humérale projetée sous le processus coracoïde.',
    clinicalTipAr: 'إنجاز إسقاط نير (Profil de Neer en Y) ضروري للتأكد التام من اتجاه الخلع واستبعاد كسر الحافة الحقانية.'
  },
  {
    id: 'mem-04',
    titleAr: 'صورة الرسغ من الجانب والوجه',
    titleFr: 'Radiographie du Poignet Face & Profil',
    titleEn: 'Wrist Radiograph',
    category: 'xray',
    difficulty: 'E',
    radiographType: 'colles_fracture',
    descriptionAr: 'صورة لأسفل الساعد والرسغ تظهر انكسار الطرف السفلي للكعبرة مع ميلان ظهري مميز كشكل شوكة الطعام.',
    descriptionFr: 'Fracture de la métaphyse distale du radius avec bascule postérieure caractéristique en dos de fourchette.',
    keySigns: ['انكسار قشرة الكعبرة السفلية', 'انزياح ظهري للقطعة العظمية المكسورة', 'تشوه شوكة الطعام (Dos de fourchette)'],
    optionsAr: [
      'كسر بوتو-كولز أسفل الكعبرة (Fracture de Pouteau-Colles)',
      'كسر العظم الزورقي في رسغ اليد (Fracture du scaphoïde)',
      'خلع العظم الهلالي للرسغ (Luxation rétrolunaire)',
      'كسر معزول في عظم الزند السفلي'
    ],
    optionsFr: [
      'Fracture de Pouteau-Colles du radius distal',
      'Fracture du scaphoïde carpien',
      'Luxation périlunaire du carpe',
      'Fracture isolée de l’ulna'
    ],
    optionsEn: [
      'Colles’ fracture of distal radius',
      'Scaphoid bone fracture',
      'Perilunate carpal dislocation',
      'Isolated ulna fracture'
    ],
    correctIndex: 0,
    explanationAr: 'كسر بوتو-كولز هو أشيع كسر لدى كبار السن ناتج عن السقوط على راحة اليد الممدودة مسبباً انزياح الكعبرة نحو الخلف.',
    explanationFr: 'La fracture de Pouteau-Colles survient par chute sur la paume en hyper-extension avec déplacement dorsal typique.',
    clinicalTipAr: 'يجب دائماً مراقبة تروية الأصابع وحركة الأعصاب (العصب المتوسط) قبل وبعد وضع الجبس.'
  },
  {
    id: 'mem-05',
    titleAr: 'صورة الحوض من الأمام',
    titleFr: 'Radiographie du Bassin de Face',
    titleEn: 'Pelvis AP Radiograph',
    category: 'xray',
    difficulty: 'D',
    radiographType: 'femur_neck',
    descriptionAr: 'صورة حوض أمامية تظهر انقطاع خط شنتون القوسي (Cintre de Shenton) في عنق الفخذ الأيمن مع تراكب عظمي.',
    descriptionFr: 'Rupture du cintre cervico-obturateur de Shenton avec tassement de la travée osseuse du col fémoral droit.',
    keySigns: ['انقطاع خط شنتون القوسي (Ligne de Shenton)', 'تقارب المدورين مع قصر نسبي', 'دوران خارجي لطرف الفخذ'],
    optionsAr: [
      'كسر عنق عظم الفخذ (Fracture du col fémoral)',
      'خلع ولادي للورك غير معالج (Luxation congénitale)',
      'كسر في الجناح الحرقفي للحوض (Fracture de l’aile iliaque)',
      'التهاب مفصل الورك التفاعلي (Coxite)'
    ],
    optionsFr: [
      'Fracture du col fémoral avec rupture du cintre de Shenton',
      'Luxation congénitale de la hanche',
      'Fracture de l’aile iliaque',
      'Coxite infectieuse aiguë'
    ],
    optionsEn: [
      'Femoral neck fracture with disrupted Shenton line',
      'Congenital hip dislocation',
      'Iliac wing fracture',
      'Acute septic coxitis'
    ],
    correctIndex: 0,
    explanationAr: 'انقطاع قوس شنتون الهندسي بين الحافة السفلية لعنق الفخذ والحافة العلوية للثقبة السدادية هو العلامة الحاسمة لكسر عنق الفخذ.',
    explanationFr: 'La rupture de continuité de l’arche de Shenton est le critère cardinal d’une fracture déplacée ou engrenée du col fémoral.',
    clinicalTipAr: 'لا تجبر المريض على تدوير قدمه داخلياً إذا كان يعاني من ألم حاد بعد السقوط لمنع تفكك الكسر.'
  },
  {
    id: 'mem-06',
    titleAr: 'إسقاط بلوندو (Blondeau) للجيوب الأنفية',
    titleFr: 'Incidence de Blondeau (Sinus)',
    titleEn: 'Waters View (Maxillary Sinus)',
    category: 'xray',
    difficulty: 'C',
    radiographType: 'waters_sinus',
    descriptionAr: 'صورة وجه للجيوب الأنفية بوضعية الوقوف تظهر عتامة مع مستوى أفقي سائل-هواء داخل الجيب الفكي الأيمن.',
    descriptionFr: 'Cliché nez-menton-plaque montrant un niveau hydro-aérique horizontal net dans le sinus maxillaire droit.',
    keySigns: ['مستوى أفقي فاصل بين الهواء والصديد (Niveau hydro-aérique)', 'عتامة كاملة أو جزئية للجيب', 'الجيب المقابل سليم وشفاف'],
    optionsAr: [
      'التهاب الجيب الفكي الحاد مع مستوى سائلي هوائي (Sinusite maxillaire aiguë)',
      'كسر قاع الحجاج الانفجاري (Blow-out fracture)',
      'بوليب الجيب الأنفي المزمن',
      'تكلس خلقي في العظم الوتدي'
    ],
    optionsFr: [
      'Sinusite maxillaire aiguë droite avec niveau liquide',
      'Fracture du plancher de l’orbite (Blow-out)',
      'Polype muqueux bénin',
      'Calcification sphénoïdale'
    ],
    optionsEn: [
      'Acute maxillary sinusitis with air-fluid level',
      'Orbital blow-out fracture',
      'Benign sinus polyp',
      'Sphenoid calcification'
    ],
    correctIndex: 0,
    explanationAr: 'ظهور المستوى السائلي الهوائي المستقيم داخل الجيب الفكي بالصورة الوقوفية دليل قاطع على التهاب قيحي حاد.',
    explanationFr: 'Le niveau hydro-aérique horizontal visualisé en position debout est pathognomonique d’une suppuration sinusienne aiguë.',
    clinicalTipAr: 'إذا أُجريت الصورة والمريض مستلقٍ، ينتشر السائل على كامل الجيب ويختفي الخط الأفقي مما يضيع التشخيص.'
  },
  {
    id: 'mem-07',
    titleAr: 'صورة الصدر وجهاً PA',
    titleFr: 'Thorax Face PA',
    titleEn: 'Chest PA View',
    category: 'xray',
    difficulty: 'E',
    radiographType: 'cardiomegaly',
    descriptionAr: 'صورة صدر وقوفية تظهر اتساعاً هائلاً في ظل القلب مع تجاوز المشعر القلبي الصدري لنسبة 0.65.',
    descriptionFr: 'Augmentation majeure de la silhouette cardiaque avec indice cardio-thoracique supérieur à 0,65.',
    keySigns: ['المشعر القلبي الصدري ICT > 0.50', 'قوس بطيني أيسر ممتد نحو الجدار الصدري', 'احتقان نسبي في الأوعية الرئوية'],
    optionsAr: [
      'تضخم شديد في ظل القلب (Cardiomégalie majeure ICT > 0.60)',
      'استرواح صدري تلقائي ثنائي الجانب',
      'انكماش الفص الرئوي الأيمن',
      'فتق حجابي معوي في التجويف الصدري'
    ],
    optionsFr: [
      'Cardiomégalie majeure avec ICT > 0,60',
      'Pneumothorax bilatéral compressif',
      'Atélectasie lobaire supérieure',
      'Hernie hiatale géante'
    ],
    optionsEn: [
      'Major cardiomegaly with ICT > 0.60',
      'Tension pneumothorax',
      'Lobar atelectasis',
      'Giant diaphragmatic hernia'
    ],
    correctIndex: 0,
    explanationAr: 'يُحسب المشعر القلبي الصدري بقسمة أقصى عرض للقلب على أقصى عرض داخلي للقفص، والقيمة الطبيعية أقل من 0.50.',
    explanationFr: 'L’indice cardio-thoracique ICT normal chez l’adulte est inférieur à 0,50 en inspiration profonde debout.',
    clinicalTipAr: 'لا تحسب المشعر القلبي الصدري على صورة مستلقية (AP) لأن قرب القلب من أنبوب الأشعة يضخم ظله كاذباً.'
  },
  {
    id: 'mem-08',
    titleAr: 'إيكوغرافيا البطن والمرارة',
    titleFr: 'Échographie de la Vésicule Biliaire',
    titleEn: 'Gallbladder Ultrasound',
    category: 'ultrasound',
    difficulty: 'C',
    radiographType: 'gallstone_echo',
    descriptionAr: 'صورة موجات فوق صوتية للمرارة تظهر كتلة بيضاء ناصعة داخل تجويف المرارة يتبعها ظل صوتي أسود مميز.',
    descriptionFr: 'Formation hyperéchogène intra-vésiculaire mobile déclive accompagnée d’un cône d’ombre acoustique postérieur net.',
    keySigns: ['قوس أبيض ناصع (Hyperéchogène)', 'ظل صوتي خلفي أسود تام (Cône d’ombre postérieur)', 'متحركة مع تغير وضعية المريض'],
    optionsAr: [
      'حصاة مرارية صلبة مع ظل صوتي خلفي (Lithiase vésiculaire)',
      'بوليب لحمي في جدار المرارة دون ظل',
      'كيس كبدي مائي رائق (Kyste hydatique)',
      'ورم وعائي كبدي حميد (Hémangiome)'
    ],
    optionsFr: [
      'Lithiase vésiculaire calcique avec cône d’ombre acoustique',
      'Polype vésiculaire sans ombre',
      'Kyste hydatique hépatique',
      'Hémangiome hépatique'
    ],
    optionsEn: [
      'Gallbladder stone with posterior acoustic shadow',
      'Gallbladder polyp without shadow',
      'Hepatic hydatid cyst',
      'Hepatic hemangioma'
    ],
    correctIndex: 0,
    explanationAr: 'الحصاة المرارية تعكس كامل الموجات الصوتية فيظهر سطحها أبيض ساطعاً، وتمنع مرور الأمواج خلفها مما يشكل ظلاً صوتياً أسود نقياً.',
    explanationFr: 'Le calcul bloque la propagation des ultrasons par forte atténuation, projetant un cône d’ombre acoustique postérieur caractéristique.',
    clinicalTipAr: 'قلب المريض على جنبه الأيسر (Décubitus latéral gauche) يؤكد دحرجة الحصاة وانفصالها عن الجدار تفريقاً لها عن الأورام.'
  },
  {
    id: 'mem-09',
    titleAr: 'صورة البطن بدون تحضير وقوفاً (ASP)',
    titleFr: 'Abdomen Sans Préparation (ASP Debout)',
    titleEn: 'Erect Abdominal Radiograph',
    category: 'xray',
    difficulty: 'D',
    radiographType: 'pneumoperitoneum',
    descriptionAr: 'صورة بطن وقوفية تظهر هلالاً هوائياً شفافاً (أسود) فاصلاً بين قبة الحجاب الحاجز اليمنى وسطح الكبد العلوي.',
    descriptionFr: 'Croissant gazeux radiotransparent sous-diaphragmatique bilatéral signant un épanchement aérique péritonéal.',
    keySigns: ['هلال غازي أسود تحت القبة الحجابية (Croissant gazeux)', 'غياب الهواء تحت الحجاب في الحالة الطبيعية', 'انثقاب عضو مجوف هضمي'],
    optionsAr: [
      'هواء حر تحت الحجاب الحاجز - انثقاب حشوي (Pneumopéritoine)',
      'انسداد الأمعاء الدقيقة بمستويات مائية هوائية',
      'حصوة في الحالب الأيمن',
      'تضخم في الطحال'
    ],
    optionsFr: [
      'Pneumopéritoine par perforation d’organe creux digestif',
      'Occlusion du grêle avec niveaux hydro-aériques',
      'Lithiase urétérale droite',
      'Splénomégalie volumineuse'
    ],
    optionsEn: [
      'Pneumoperitoneum from hollow viscus perforation',
      'Small bowel obstruction',
      'Ureteral calculus',
      'Splenomegaly'
    ],
    correctIndex: 0,
    explanationAr: 'الهواء الحر المتسرب من انثقاب المعدة أو الأمعاء يصعد لأعلى نقطة بالبطن متجمعاً كهلال أسود رقيق تحت الحجاب الحاجز.',
    explanationFr: 'L’air libre intra-péritonéal migre vers le point le plus haut en position debout, formant un croissant clair sous la coupole.',
    clinicalTipAr: 'حالة طوارئ جراحية مطلقة (بطن حادة Chirurgicale) تتطلب إخطار الجراح فوراً وتحضير المريض للعمليات.'
  }
];
