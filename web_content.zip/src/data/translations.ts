export const translations = {
  ar: {
    brandName: 'المواساة',
    brandSub: 'AL-MOWASAT MEDICAL & TOURISM',
    slogan: '«المواساة... رعايتك تبدأ من هنا، أينما كنت في العالم»',
    demoNoticeBadge: 'نموذج أولي تفاعلي للعرض أمام المستثمرين والشركاء',
    disclaimerBar: 'منصة المواساة هي جهة رقمية رائدة لتنسيق الرعاية الصحية والسياحة العلاجية والخدمات اللوجستية، وليست جهة تشخيص طبي أو وصفات علاجية. جميع البيانات في هذا النموذج هي بيانات تجريبية لأغراض العرض فقط.',
    
    // Nav
    navHome: 'الرئيسية',
    navMedical: 'القطاع الطبي الشامل',
    navRehab: 'علاج الإدمان والتأهيل',
    navTourism: 'السياحة العلاجية والاستشفائية',
    navReception: 'استقبال المرضى الأجانب',
    navTracking: 'متابعة المرضى',
    navInternational: 'الخدمات الدولية',
    navAbout: 'عن المنصة',
    navAdmin: 'لوحة الإدارة',
    navRequestBtn: 'اطلب خدمة الآن',
    navTrackingSearch: 'تتبع طلبك',
    login: 'تسجيل الدخول',
    createAccount: 'إنشاء حساب',

    // Hero
    heroTitle: 'بوابتك الموثوقة لأفضل رعاية صحية وسياحة علاجية في مصر',
    heroSubtitle: 'نربط المرضى من جميع أنحاء العالم بنخبة المستشفيات والكوادر الطبية المعتمدة ومراكز التأهيل والاستشفاء البيئي في جمهورية مصر العربية، مع تنظيم لوجستي شامل من المطار وحتى اكتمال الشفاء.',
    heroCtaRequest: 'اطلب خدمة تنسيق طبي',
    heroCtaExplore: 'استكشف خدماتنا الستة',
    heroCtaAdmin: 'لوحة تحكم الإدارة (عرض للمستثمر)',
    heroTrackInputPlaceholder: 'أدخل رقم الطلب التجريبي (مثال: ALM-REQ-7924)',
    heroTrackBtn: 'متابعة الحالة',

    // Stats
    statHospitals: '25+ مركز ومستشفى معتمد',
    statDoctors: '150+ استشاري وأستاذ جراحة',
    statCountries: '18+ دولة شريكة',
    statSuccessRate: '99.2% رضا المستفيدين',

    // Services Overview Section
    servicesTitle: 'منظومة خدمات المواساة المتكاملة',
    servicesSubtitle: 'ستة ركائز رئيسية صُممت لتمنح المريض والمرافق تجربة علاجية وسياحية آمنة، مريحة، وفائقة الجودة.',
    
    // Service 1
    s1Title: 'القطاع الطبي الشامل',
    s1Desc: 'تنسيق مباشر مع أرقى المستشفيات والمراكز التخصصية المعتمدة محلياً ودولياً، وأفضل الاستشاريين في الجراحات الدقيقة وزراعة الأعضاء والقلب والأورام.',
    
    // Service 2
    s2Title: 'علاج الإدمان والتأهيل',
    s2Desc: 'مراكز تأهيل معتمدة وبرامج استشفائية قائمة على الأدلة الطبية في بيئات طبيعية هادئة مع ضمان السرية المطلقة والخصوصية التامة للمريض والأسرة.',
    
    // Service 3
    s3Title: 'السياحة العلاجية والاستشفائية',
    s3Desc: 'برامج استشفاء بيئي بمصر (سيوة، أسوان، سفاجا) للعلاج المناخي، بحيرات الملح، والعيون الكبريتية، تحت إشراف طبي متخصص كبرامج مكملة ومعززة للصحة.',
    
    // Service 4
    s4Title: 'استقبال المرضى الأجانب',
    s4Desc: 'استقبال VIP من باب الطائرة، أسطول سيارات مجهزة، حجز أجنحة فندقية، مترجمون محترفون، ومرافق شخصي يرافق المريض طوال فترة إقامته بمصر.',
    
    // Service 5
    s5Title: 'متابعة المرضى والملف الرقمي',
    s5Desc: 'ملف صحي رقمي يتيح للمريض متابعة خطته العلاجية، جدول المواعيد، تقارير الأطباء المنسقة، وتحديثات المتابعة بعد العودة إلى الوطن.',
    
    // Service 6
    s6Title: 'الخدمات الدولية',
    s6Desc: 'تيسير إصدار التأشيرات العلاجية، استشارات مرئية دولية Telehealth، استقبال التقارير وترجمتها، وحاسبة تقدير التكاليف ومسار الرحلة للمرضى الوافدين.',

    // How it works
    howItWorksTitle: 'رحلة الرعاية في خمس خطوات ميسرة',
    howItWorksSubtitle: 'مسار واضح وسلس من أول استفسار حتى تمام الشفاء والعودة إلى وطنك بأمان',
    step1Title: '1. تقديم الطلب والاستشارة',
    step1Desc: 'تسجيل الاحتياج الطبي أو الاستشفائي عبر النموذج الآمن واختيار التخصص والخدمات المصاحبة.',
    step2Title: '2. دراسة الحالة والتنسيق الطبي',
    step2Desc: 'مراجعة الاحتياج عبر فريق التنسيق وترشيح المستشفى والاستشاري الأنسب وإعداد خطة زمنية وتكلفة تقديرية.',
    step3Title: '3. الترتيبات واللوجستيات',
    step3Desc: 'تنسيق تأشيرة العلاج، حجز الطيران والإقامة، وتجهيز خطة الاستقبال والمترجم المصاحب.',
    step4Title: '4. الاستقبال والرعاية السريرية',
    step4Desc: 'الترحيب في المطار، الانتقال للفندق والمستشفى، والمرافقة في جميع الفحوصات والتدخلات الطبية.',
    step5Title: '5. الاستشفاء والمتابعة اللاحقة',
    step5Desc: 'تنظيم فترات النقاهة والاستجمام، مع متابعة دورية عن بُعد بعد عودة المريض لبلده بسلام.',

    // Common buttons
    learnMore: 'استكشف التفاصيل',
    requestThisService: 'طلب هذه الخدمة',
    viewDetails: 'عرض التفاصيل',
    close: 'إغلاق',
    backToHome: 'العودة للرئيسية',
    demoWalkthrough: 'جولة المستثمر التجريبية',

    // Form
    formTitle: 'نموذج طلب الخدمة والتنسيق الطبي',
    formSubtitle: 'املأ البيانات التجريبية وسيقوم فريق التنسيق بدراسة الاحتياج فورًا وربطك بالجهة الملائمة.',
    formName: 'الاسم الكامل للمريض أو طالب الخدمة',
    formCountry: 'الدولة والجنسية',
    formPhone: 'رقم الهاتف (مع كود الدولة)',
    formEmail: 'البريد الإلكتروني',
    formPrefLang: 'اللغة المفضلة للتواصل',
    formServiceType: 'نوع الخدمة المطلوبة',
    formSpecialty: 'التخصص الطبي أو الاحتياج المحدد',
    formDesc: 'وصف مختصر للاحتياج الصحي أو الاستشفائي',
    formContactMethod: 'وسيلة التواصل المفضلة',
    formPrivacyConsent: 'أوافق على سياسة الخصوصية وأدرك أن هذا نموذج تجريبي لتنسيق الخدمات الطبية وليس استشارة علاجية فورية.',
    formSubmitBtn: 'إرسال الطلب وحفظه في النظام التجريبي',
    formSuccessTitle: 'تم استلام طلبك بنجاح!',
    formSuccessDesc: 'تم إدراج طلبك التجريبي في قاعدة بيانات منصة المواساة. يمكنك الآن متابعته أو الاطلاع عليه في لوحة تحكم الإدارة.',
    formYourCode: 'رقم المتابعة الخاص بك:',

    // Admin
    adminDashboardTitle: 'AL-MOWASAT ADMIN DASHBOARD',
    adminDashboardSubtitle: 'لوحة التحكم الإدارية الموحدة لتنسيق الرعاية الصحية والسياحة العلاجية والخدمات اللوجستية',
    adminTabOverview: 'لوحة الإحصائيات العامة',
    adminTabRequests: 'إدارة الطلبات والمرضى',
    adminTabHospitals: 'المستشفيات والمراكز المعتمدة',
    adminTabDoctors: 'الأطباء والاستشاريون',
    adminTabCompliance: 'مراجعة التراخيص والاعتمادات',
    adminTabLogistics: 'اللوجستيات وحجوزات السفر',
    adminTabTranslators: 'المترجمون والمرافقون',
    adminTabInvoices: 'المالية والفواتير التجريبية',
    adminTabReports: 'تقارير الأداء ومؤشرات النمو',
  },
  en: {
    brandName: 'AL-MOWASAT',
    brandSub: 'MEDICAL & TOURISM PLATFORM',
    slogan: '«Al-Mowasat... Your care begins here, wherever you are in the world»',
    demoNoticeBadge: 'Interactive Prototype for Investors & Healthcare Partners',
    disclaimerBar: 'Al-Mowasat is a healthcare coordination, medical tourism, and logistics management platform, not a medical diagnostic or prescribing entity. All data in this prototype is for demonstration purposes.',
    
    // Nav
    navHome: 'Home',
    navMedical: 'Medical Sector',
    navRehab: 'Rehab & Recovery',
    navTourism: 'Wellness & Healing',
    navReception: 'Foreign Reception',
    navTracking: 'Patient Tracking',
    navInternational: 'Global Services',
    navAbout: 'About Platform',
    navAdmin: 'Admin Dashboard',
    navRequestBtn: 'Request Service',
    navTrackingSearch: 'Track Request',
    login: 'Sign In',
    createAccount: 'Register',

    // Hero
    heroTitle: 'Your Trusted Gateway to Premier Healthcare & Medical Tourism in Egypt',
    heroSubtitle: 'Connecting international patients with top-tier accredited Egyptian hospitals, senior surgical professors, certified rehabilitation retreats, and world-renowned natural healing oases with seamless door-to-door concierge care.',
    heroCtaRequest: 'Request Medical Coordination',
    heroCtaExplore: 'Explore Our 6 Core Pillars',
    heroCtaAdmin: 'Admin Dashboard (Investor View)',
    heroTrackInputPlaceholder: 'Enter Demo Tracking ID (e.g., ALM-REQ-7924)',
    heroTrackBtn: 'Track Status',

    // Stats
    statHospitals: '25+ Accredited Hospitals',
    statDoctors: '150+ Leading Consultants',
    statCountries: '18+ Partner Nations',
    statSuccessRate: '99.2% Patient Satisfaction',

    // Services Overview Section
    servicesTitle: 'Al-Mowasat Integrated Service Ecosystem',
    servicesSubtitle: 'Six specialized pillars designed to grant patients and companions a safe, world-class medical journey.',
    
    // Service 1
    s1Title: 'Comprehensive Medical Sector',
    s1Desc: 'Direct coordination with leading JCI & GAHAR accredited hospitals, top surgical professors, organ transplants, interventional cardiology, and oncology.',
    
    // Service 2
    s2Title: 'Addiction Treatment & Rehab',
    s2Desc: 'Evidence-based psychiatric and behavioral rehabilitation campuses in peaceful secluded retreats ensuring total patient and family confidentiality.',
    
    // Service 3
    s3Title: 'Medical & Wellness Tourism',
    s3Desc: 'Climatotherapy and natural healing in Siwa Oasis, Aswan, and Safaga Black Sand bays, strictly supervised as complementary wellness programs.',
    
    // Service 4
    s4Title: 'Foreign Patient Reception',
    s4Desc: 'VIP tarmac greeting, medical transport fleet, luxury hotel accommodation, certified multi-lingual interpreters, and a dedicated patient concierge.',
    
    // Service 5
    s5Title: 'Patient Follow-up & Portal',
    s5Desc: 'Comprehensive digital timeline keeping patients informed on appointments, coordinator notes, physician rounds, and post-treatment checkups.',
    
    // Service 6
    s6Title: 'Global Coordination Services',
    s6Desc: 'Facilitating medical entry visas, cross-border telehealth consultations, medical record translations, and transparent cost estimators for incoming patients.',

    // How it works
    howItWorksTitle: 'Your Care Journey in 5 Simple Steps',
    howItWorksSubtitle: 'A transparent, stress-free pathway from initial inquiry to full recovery and safe return home',
    step1Title: '1. Inquiry & Request Submission',
    step1Desc: 'Submit your health needs securely via our portal and select needed logistics.',
    step2Title: '2. Clinical Review & Matching',
    step2Desc: 'Our coordination board matches your case with top certified specialists and crafts a transparent estimate.',
    step3Title: '3. Travel Logistics & Visa',
    step3Desc: 'We coordinate medical entry visas, flight bookings, hotel reservations, and language concierges.',
    step4Title: '4. Arrival & Clinical Care',
    step4Desc: 'VIP airport greeting, direct hospital transit, and dedicated escort throughout diagnostic and surgical care.',
    step5Title: '5. Convalescence & Follow-up',
    step5Desc: 'Curated wellness recuperation followed by continuous remote follow-up once you return home safely.',

    // Common buttons
    learnMore: 'Explore Details',
    requestThisService: 'Request This Service',
    viewDetails: 'View Details',
    close: 'Close',
    backToHome: 'Back to Home',
    demoWalkthrough: 'Investor Guided Tour',

    // Form
    formTitle: 'Service Request & Coordination Form',
    formSubtitle: 'Complete the demo details below. Our coordination desk will evaluate your needs and match you with the optimal facility.',
    formName: 'Full Name of Patient or Representative',
    formCountry: 'Country & Citizenship',
    formPhone: 'Phone Number (with Country Code)',
    formEmail: 'Email Address',
    formPrefLang: 'Preferred Language for Contact',
    formServiceType: 'Primary Service Required',
    formSpecialty: 'Medical Specialty or Specific Need',
    formDesc: 'Brief Description of Condition or Request',
    formContactMethod: 'Preferred Contact Channel',
    formPrivacyConsent: 'I agree to the privacy policy and understand that this is a demo coordination prototype, not a direct emergency or diagnostic service.',
    formSubmitBtn: 'Submit Request to Demo System',
    formSuccessTitle: 'Request Registered Successfully!',
    formSuccessDesc: 'Your demo request is now saved in the Al-Mowasat database. You can track its status or view it live in the Admin Dashboard.',
    formYourCode: 'Your Demo Tracking Code:',

    // Admin
    adminDashboardTitle: 'AL-MOWASAT ADMIN DASHBOARD',
    adminDashboardSubtitle: 'Unified Control Center for Healthcare Coordination, Medical Tourism, and Logistics',
    adminTabOverview: 'General KPIs & Overview',
    adminTabRequests: 'Patient Requests Management',
    adminTabHospitals: 'Accredited Hospitals & Centers',
    adminTabDoctors: 'Consultants & Specialists',
    adminTabCompliance: 'Accreditation & Compliance Audit',
    adminTabLogistics: 'Logistics, Travel & Transfers',
    adminTabTranslators: 'Interpreters & Concierges',
    adminTabInvoices: 'Demo Financials & Invoices',
    adminTabReports: 'Performance & Growth Metrics',
  }
};
