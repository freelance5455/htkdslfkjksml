export const translations = {
  en: {
    shopName: 'A K Golu Computer',
    tagline: 'Computer & Laptop Sales & Repair | CCTV Cameras | Printer Service & Networking',
    callNow: 'Call Now',
    chatWhatsApp: 'Chat on WhatsApp',
    openHours: 'Open Today',
    home: 'Home',
    products: 'Products',
    services: 'Services',
    offers: 'Special Offers',
    contact: 'Contact & Location',
    adminNav: 'Admin Login',
    searchPlaceholder: 'Search laptops, computers, CCTV, printers, SSD...',
    categories: {
      all: 'All Products',
      laptops_refurbished: 'Refurbished Laptops',
      laptops_new: 'New Laptops',
      computers_desktops: 'Desktops & PCs',
      cctv_surveillance: 'CCTV & DVR/NVR',
      printers_toner: 'Printers & Cartridges',
      accessories_networking: 'Accessories & Wi-Fi'
    },
    hero: {
      badge: 'Trusted Computer & CCTV Hub',
      titleHighlight: 'Tech Sales & Chip-Level Repair',
      subtitle: 'Premium refurbished laptops, custom gaming/office PCs, genuine CCTV camera installations, and guaranteed same-day repair services with doorstep support.',
      primaryBtn: 'Explore Products',
      secondaryBtn: 'Book Doorstep Repair',
      whatsappBtn1: 'WhatsApp (7054304313)',
      whatsappBtn2: 'WhatsApp (8726356413)',
      stats: {
        experience: 'Years of Experience',
        cameras: 'CCTV Cameras Installed',
        laptops: 'Laptops & PCs Repaired',
        satisfaction: 'Customer Trust'
      }
    },
    productCard: {
      newBadge: 'Brand New',
      refurbishedBadge: 'Tested Grade-A',
      inStock: 'In Stock',
      outOfStock: 'Out of Stock',
      viewSpecs: 'Quick View',
      addToCart: 'Add to Cart',
      buyNow: 'Buy Now via WhatsApp',
      original: 'MRP',
      save: 'Save',
      warranty: 'Warranty'
    },
    cart: {
      title: 'Your Order Bag',
      empty: 'Your cart is empty',
      emptySub: 'Browse our catalog and add computers, laptops, CCTV cameras, or accessories.',
      browseBtn: 'Browse Products Now',
      itemsCount: 'items',
      subtotal: 'Estimated Total',
      notice: 'Payment & Order Notice',
      noticeText: 'Orders are processed via WhatsApp directly with the shop owner. Product availability and payment mode (Cash on Delivery / UPI) will be confirmed before dispatch. No automated charge is deducted.',
      customerDetailsTitle: 'Customer Delivery & Contact Info',
      nameLabel: 'Your Full Name',
      namePlaceholder: 'e.g. Ramesh Kumar',
      phoneLabel: '10-Digit Mobile Number (WhatsApp)',
      phonePlaceholder: 'e.g. 9876543210',
      addressLabel: 'Full Delivery Address / Landmark',
      addressPlaceholder: 'e.g. House No. 12, Near Temple, Main Market',
      pincodeLabel: 'Pincode / Area',
      pincodePlaceholder: 'e.g. 226001',
      sendToLabel: 'Send WhatsApp Order To:',
      placeOrderWhatsApp: 'Send Order on WhatsApp',
      fillRequired: 'Please enter your name, valid 10-digit mobile number, and address.'
    },
    servicesSection: {
      badge: 'Expert Repair & Installation',
      title: 'Professional Technical Services',
      subtitle: 'From chip-level laptop motherboard fixing to complete CCTV surveillance wiring and printer cartridge refilling. We provide both shop repair and doorstep home visits.',
      bookNow: 'Book Service',
      homeServiceTag: 'Doorstep Home Service Available',
      estTime: 'Turnaround Time',
      startingFrom: 'Starting from'
    },
    serviceModal: {
      title: 'Book a Service / Repair Request',
      subtitle: 'Fill in your device problem. We will connect with you immediately on WhatsApp to confirm timing.',
      name: 'Full Name',
      phone: 'Mobile Number',
      serviceMode: 'Service Location',
      homeVisit: 'Doorstep / Home Visit (We come to your place)',
      shopVisit: 'Shop Visit (I will bring device to A K Golu Computer)',
      deviceType: 'Device Type',
      problem: 'Describe the Problem / Required Work',
      problemPlaceholder: 'e.g. Laptop not turning on, screen flickering, CCTV 2 cameras not showing on TV, toner refilling required...',
      preferredDate: 'Preferred Date',
      preferredSlot: 'Preferred Time Slot',
      selectNumber: 'Submit Request to WhatsApp Number',
      submitBtn: 'Submit Request via WhatsApp',
      disclaimer: 'Note: Booking request will open in WhatsApp. The technician will confirm the visit schedule and exact estimate before starting work.'
    },
    specialOffers: {
      badge: 'Limited Period Super Deals',
      title: 'Special Combos & Packages',
      subtitle: 'Hand-picked packages combining high performance hardware and professional installation at wholesale rates.'
    },
    pwaBanner: {
      installTitle: 'Install A K Golu Computer App',
      installDesc: 'Add to your Android home screen for instant 1-tap access, fast loading & offline viewing without typing URL.',
      installBtn: 'Install App',
      installedBtn: 'App Installed',
      howToInstall: 'How to Install on Phone',
      offlineAlert: 'You are currently browsing offline. Cached products and contact info are available.'
    },
    contactSection: {
      badge: 'Get In Touch',
      title: 'Visit Our Shop or Contact Us',
      subtitle: 'Have a question about a product, want a custom PC quote, or need emergency CCTV repair? We are always happy to help.',
      callPrimary: 'Call 7054304313',
      callSecondary: 'Call 8726356413',
      whatsappPrimary: 'WhatsApp 7054304313',
      whatsappSecondary: 'WhatsApp 8726356413',
      addressTitle: 'Shop Address',
      hoursTitle: 'Working Hours',
      directionsBtn: 'Open in Google Maps',
      contactCardNote: 'Free consultation on custom PC builds and CCTV security quotes.'
    },
    admin: {
      title: 'Shop Owner Admin Panel',
      lockSubtitle: 'Enter your 6-digit or custom admin PIN to access product inventory, order logs, and store settings.',
      pinPlaceholder: 'Enter Admin PIN',
      loginBtn: 'Unlock Admin',
      defaultPinNotice: 'Default initial PIN is golu123. You can change this PIN anytime in Store Settings.',
      incorrectPin: 'Incorrect PIN. Please try again.',
      tabs: {
        products: 'Products Inventory',
        orders: 'Orders Log',
        services: 'Service Bookings',
        settings: 'Shop Settings & Address'
      },
      addNewProduct: '+ Add New Product',
      resetSample: 'Restore Sample Data',
      logout: 'Lock & Exit Admin'
    },
    footer: {
      about: 'A K Golu Computer is your one-stop solution for new & refurbished laptops, desktops, CCTV surveillance, printer servicing, and networking in India.',
      quickLinks: 'Quick Links',
      servicesTitle: 'Our Services',
      callUs: 'Call for Immediate Assistance',
      rights: 'All Rights Reserved. Built for A K Golu Computer.'
    }
  },

  hi: {
    shopName: 'ए के गोलू कंप्यूटर',
    tagline: 'कंप्यूटर और लैपटॉप बिक्री व रिपेयर | सीसीटीवी कैमरा | प्रिंटर सर्विस और नेटवर्किंग',
    callNow: 'कॉल करें',
    chatWhatsApp: 'व्हाट्सएप चैट',
    openHours: 'आज खुला है',
    home: 'होम',
    products: 'सामान / प्रोडक्ट्स',
    services: 'सर्विस व रिपेयर',
    offers: 'खास ऑफर',
    contact: 'संपर्क व पता',
    adminNav: 'एडमिन लॉगिन',
    searchPlaceholder: 'लैपटॉप, कंप्यूटर, सीसीटीवी, प्रिंटर, एसएसडी खोजें...',
    categories: {
      all: 'सभी प्रोडक्ट्स',
      laptops_refurbished: 'रिफर्बिश्ड लैपटॉप (सस्ते व बेस्ट)',
      laptops_new: 'नए लैपटॉप (सील पैक)',
      computers_desktops: 'कंप्यूटर व डेस्कटॉप पीसी',
      cctv_surveillance: 'सीसीटीवी कैमरा व DVR/NVR',
      printers_toner: 'प्रिंटर व टोनर कार्ट्रिज',
      accessories_networking: 'एक्सेसरीज़ व वाई-फाई'
    },
    hero: {
      badge: 'विश्वसनीय कंप्यूटर व सीसीटीवी केंद्र',
      titleHighlight: 'हार्डवेयर बिक्री व चिप-लेवल रिपेयर',
      subtitle: 'कम बजट में बेस्ट रिफर्बिश्ड लैपटॉप, ऑफिस व साइबर कैफे पीसी, हिकविज़न/सीपी प्लस सीसीटीवी इंस्टॉलेशन, और घर बैठे रिपेयरिंग की गारंटीड सुविधा।',
      primaryBtn: 'प्रोडक्ट्स देखें',
      secondaryBtn: 'घर बैठे रिपेयर बुक करें',
      whatsappBtn1: 'व्हाट्सएप (7054304313)',
      whatsappBtn2: 'व्हाट्सएप (8726356413)',
      stats: {
        experience: 'वर्षों का अनुभव',
        cameras: 'सीसीटीवी कैमरे फिट किए गए',
        laptops: 'लैपटॉप व कंप्यूटर रिपेयर',
        satisfaction: 'संतुष्ट ग्राहक'
      }
    },
    productCard: {
      newBadge: 'ब्रांड न्यू',
      refurbishedBadge: 'टेस्टेड ग्रेड-ए',
      inStock: 'उपलब्ध (In Stock)',
      outOfStock: 'स्टॉक समाप्त',
      viewSpecs: 'पूरी जानकारी',
      addToCart: 'कार्ट में डालें',
      buyNow: 'व्हाट्सएप पर ऑर्डर करें',
      original: 'असली कीमत',
      save: 'बचत',
      warranty: 'वारंटी'
    },
    cart: {
      title: 'आपकी ऑर्डर लिस्ट (कार्ट)',
      empty: 'आपकी कार्ट खाली है',
      emptySub: 'हमारे प्रोडक्ट्स में से अपनी पसंद का लैपटॉप, सीसीटीवी या सामान चुनें।',
      browseBtn: 'अभी प्रोडक्ट्स देखें',
      itemsCount: 'सामान',
      subtotal: 'कुल अनुमानित राशि',
      notice: 'ऑर्डर व पेमेंट सूचना',
      noticeText: 'ऑर्डर का विवरण सीधे दुकानदार के व्हाट्सएप पर जाएगा। सामान की उपलब्धता, डिलीवरी का समय और पेमेंट (कैश ऑन डिलीवरी / यूपीआई) दुकानदार द्वारा आपसे फोन पर बातचीत के बाद ही कन्फर्म होगा। वेबसाइट से कोई ऑटोमैटिक पैसे नहीं कटते।',
      customerDetailsTitle: 'ग्राहक का नाम और डिलीवरी पता',
      nameLabel: 'आपका पूरा नाम',
      namePlaceholder: 'उदा. रमेश कुमार',
      phoneLabel: '10 अंकों का मोबाइल नंबर (व्हाट्सएप)',
      phonePlaceholder: 'उदा. 9876543210',
      addressLabel: 'पूरा पता व नजदीकी पहचान (लैंडमार्क)',
      addressPlaceholder: 'उदा. मकान नंबर 12, मंदिर के पास, मेन रोड',
      pincodeLabel: 'पिनकोड / कस्बा',
      pincodePlaceholder: 'उदा. 226001',
      sendToLabel: 'ऑर्डर किस व्हाट्सएप नंबर पर भेजें:',
      placeOrderWhatsApp: 'व्हाट्सएप पर ऑर्डर भेजें',
      fillRequired: 'कृपया अपना नाम, सही 10 अंकों का मोबाइल नंबर और पूरा पता दर्ज करें।'
    },
    servicesSection: {
      badge: 'माहिर कारीगर व तुरंत सर्विस',
      title: 'हमारी टेक्निकल सर्विसेज',
      subtitle: 'लैपटॉप मदरबोर्ड की चिप-लेवल रिपेयरिंग से लेकर नई सीसीटीवी फिटिंग और प्रिंटर टोनर रिफिलिंग तक—दुकान पर या घर बैठे दोनों सुविधा उपलब्ध।',
      bookNow: 'सर्विस बुक करें',
      homeServiceTag: 'होम सर्विस (घर बैठे सुविधा) उपलब्ध',
      estTime: 'समय',
      startingFrom: 'शुरुआती चार्ज'
    },
    serviceModal: {
      title: 'रिपेयर / सर्विस बुक करें',
      subtitle: 'अपने कंप्यूटर, सीसीटीवी या प्रिंटर की समस्या लिखें। हम तुरंत व्हाट्सएप पर आपसे समय तय करेंगे।',
      name: 'आपका नाम',
      phone: 'मोबाइल नंबर',
      serviceMode: 'सर्विस कहां चाहिए?',
      homeVisit: 'होम सर्विस (कारीगर आपके घर/दुकान आएगा)',
      shopVisit: 'शॉप विजिट (मैं डिवाइस ए के गोलू कंप्यूटर पर लाऊंगा)',
      deviceType: 'डिवाइस का प्रकार',
      problem: 'क्या समस्या है? विस्तार से बताएं',
      problemPlaceholder: 'उदा. लैपटॉप ऑन नहीं हो रहा, सीसीटीवी में 2 कैमरे टीवी पर नहीं दिख रहे, 12A कार्ट्रिज रिफिल करानी है...',
      preferredDate: 'पसंदीदा तारीख',
      preferredSlot: 'पसंदीदा समय',
      selectNumber: 'किस नंबर पर व्हाट्सएप भेजें:',
      submitBtn: 'व्हाट्सएप पर सर्विस रिक्वेस्ट भेजें',
      disclaimer: 'नोट: फॉर्म सबमिट करने पर व्हाट्सएप खुलेगा। कारीगर काम शुरू करने से पहले आने का समय और खर्च आपसे कन्फर्म करेगा।'
    },
    specialOffers: {
      badge: 'सीमित समय के लिए महा-ऑफर',
      title: 'स्पेशल कॉम्बो और पैकेज',
      subtitle: 'होलसेल रेट पर चुने हुए हाई-क्वालिटी हार्डवेयर और फ्री इंस्टॉलेशन पैकेज।'
    },
    pwaBanner: {
      installTitle: 'ए के गोलू कंप्यूटर ऐप इनस्टॉल करें',
      installDesc: 'बिना कोई लिंक टाइप किए अपने एंड्रॉइड मोबाइल पर एक क्लिक में दुकान खोलने के लिए ऐप को होम स्क्रीन पर लगाएं।',
      installBtn: 'ऐप इनस्टॉल करें',
      installedBtn: 'ऐप इनस्टॉल है',
      howToInstall: 'फोन में इनस्टॉल करने का तरीका',
      offlineAlert: 'आप अभी ऑफलाइन हैं। पहले से लोड जानकारी और फोन नंबर उपलब्ध हैं।'
    },
    contactSection: {
      badge: 'हमसे संपर्क करें',
      title: 'हमारी दुकान पर आएं या सीधे फोन करें',
      subtitle: 'लैपटॉप खरीदना हो, नया कंप्यूटर असेंबल कराना हो या सीसीटीवी कैमरे लगवाने हों—किसी भी जानकारी के लिए बेझिझक कॉल या व्हाट्सएप करें।',
      callPrimary: 'कॉल 7054304313',
      callSecondary: 'कॉल 8726356413',
      whatsappPrimary: 'व्हाट्सएप 7054304313',
      whatsappSecondary: 'व्हाट्सएप 8726356413',
      addressTitle: 'दुकान का पता',
      hoursTitle: 'खुलने का समय',
      directionsBtn: 'गूगल मैप्स पर रास्ता देखें',
      contactCardNote: 'नया कंप्यूटर बनवाने व सीसीटीवी कोटेशन के लिए फ्री सलाह।'
    },
    admin: {
      title: 'शॉप ओनर एडमिन पैनल (दुकानदार के लिए)',
      lockSubtitle: 'प्रोडक्ट्स बदलने, नया सामान जोड़ने, ऑर्डर देखने और दुकान की जानकारी बदलने के लिए अपना एडमिन पिन दर्ज करें।',
      pinPlaceholder: 'एडमिन पिन दर्ज करें',
      loginBtn: 'एडमिन अनलॉक करें',
      defaultPinNotice: 'शुरुआती डिफ़ॉल्ट पिन golu123 है। आप इसे सेटिंग्स में जाकर बदल सकते हैं।',
      incorrectPin: 'गलत पिन! कृपया सही पिन डालें।',
      tabs: {
        products: 'प्रोडक्ट्स लिस्ट',
        orders: 'आए हुए ऑर्डर्स',
        services: 'सर्विस बुकिंग्स',
        settings: 'दुकान का पता व सेटिंग्स'
      },
      addNewProduct: '+ नया प्रोडक्ट जोड़ें',
      resetSample: 'सैंपल प्रोडक्ट्स रीस्टोर करें',
      logout: 'एडमिन से बाहर आएं'
    },
    footer: {
      about: 'ए के गोलू कंप्यूटर: लैपटॉप, कंप्यूटर, सीसीटीवी सर्विलांस, प्रिंटर सर्विसिंग और नेटवर्किंग के लिए आपका विश्वसनीय स्थानीय केंद्र।',
      quickLinks: 'महत्वपूर्ण लिंक',
      servicesTitle: 'हमारी सेवाएं',
      callUs: 'तुरंत बातचीत के लिए कॉल करें',
      rights: 'सर्वाधिकार सुरक्षित। ए के गोलू कंप्यूटर।'
    }
  }
};
