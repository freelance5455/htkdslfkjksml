import { LanguageCode } from '../types/language';

export interface TranslationDictionary {
  home: string;
  categories: string;
  shop: string;
  cart: string;
  orders: string;
  account: string;
  wishlist: string;
  notifications: string;
  support: string;
  policies: string;
  searchProducts: string;
  searchPlaceholder: string;
  recentSearches: string;
  clearAll: string;
  searchSuggestions: string;
  matchingProducts: string;
  viewAllResults: string;
  deliveryTo: string;
  change: string;
  all: string;
  forYou: string;
  men: string;
  women: string;
  kids: string;
  bags: string;
  footwear: string;
  sandals: string;
  chappals: string;
  sneakers: string;
  offers: string;
  trending: string;
  newArrivals: string;
  bestSellers: string;
  topRated: string;
  filter: string;
  filters: string;
  sortBy: string;
  popular: string;
  priceLowToHigh: string;
  priceHighToLow: string;
  discount: string;
  minDiscount: string;
  resetFilters: string;
  applyFilters: string;
  addToCart: string;
  added: string;
  buyNow: string;
  off: string;
  freeDelivery: string;
  codAvailable: string;
  cashOnDelivery: string;
  reviews: string;
  rating: string;
  inStock: string;
  outOfStock: string;
  selectSize: string;
  selectColor: string;
  description: string;
  features: string;
  returnPolicy: string;
  daysReturn: string;
  authenticProducts: string;
  shoppingCart: string;
  orderSummary: string;
  subtotal: string;
  total: string;
  deliveryFee: string;
  free: string;
  proceedToCheckout: string;
  emptyCart: string;
  emptyCartDesc: string;
  startShopping: string;
  enterAddress: string;
  fullName: string;
  phone: string;
  addressLine: string;
  city: string;
  state: string;
  pincode: string;
  selectPayment: string;
  cashOnDeliveryTitle: string;
  placeOrder: string;
  processingOrder: string;
  orderSuccess: string;
  orderNumber: string;
  continueShopping: string;
  myOrders: string;
  orderId: string;
  orderPlaced: string;
  status: string;
  trackOrder: string;
  expectedDelivery: string;
  items: string;
  cancelOrder: string;
  viewDetails: string;
  noOrdersYet: string;
  orderedOn: string;
  deliveredOn: string;
  inTransit: string;
  outForDelivery: string;
  delivered: string;
  myWishlist: string;
  emptyWishlist: string;
  emptyWishlistDesc: string;
  moveToCart: string;
  removeFromWishlist: string;
  exploreProducts: string;
  profile: string;
  profileDetails: string;
  savedAddresses: string;
  security: string;
  signOut: string;
  login: string;
  register: string;
  welcomeBack: string;
  enterPhoneOrEmail: string;
  sendOtp: string;
  verifyOtp: string;
  continueBtn: string;
  cancel: string;
  save: string;
  edit: string;
  delete: string;
  back: string;
  next: string;
  language: string;
  selectLanguage: string;
  loading: string;
  error: string;
  success: string;
  retry: string;
  close: string;
  confirm: string;
  itemAddedToCart: string;
  itemRemovedFromCart: string;
}

export const TRANSLATIONS: Record<LanguageCode, TranslationDictionary> = {
  en: {
    home: 'Home',
    categories: 'Categories',
    shop: 'Shop',
    cart: 'Cart',
    orders: 'Orders',
    account: 'Account',
    wishlist: 'Wishlist',
    notifications: 'Notifications',
    support: 'Support',
    policies: 'Policies',
    searchProducts: 'Search for products, brands and more',
    searchPlaceholder: 'Search for products',
    recentSearches: 'Recent Searches',
    clearAll: 'Clear All',
    searchSuggestions: 'Search Suggestions',
    matchingProducts: 'Matching Products',
    viewAllResults: 'View all results for',
    deliveryTo: 'Delivery to',
    change: 'Change',
    all: 'All',
    forYou: 'For You',
    men: 'Men',
    women: 'Women',
    kids: 'Kids',
    bags: 'Bags',
    footwear: 'Footwear',
    sandals: 'Sandals',
    chappals: 'Chappals',
    sneakers: 'Sneakers',
    offers: 'Offers',
    trending: 'Trending',
    newArrivals: 'New Arrivals',
    bestSellers: 'Best Sellers',
    topRated: 'Top Rated',
    filter: 'Filter',
    filters: 'Filters',
    sortBy: 'Sort By',
    popular: 'Popularity',
    priceLowToHigh: 'Price: Low to High',
    priceHighToLow: 'Price: High to Low',
    discount: 'Discount',
    minDiscount: 'Minimum Discount',
    resetFilters: 'Reset Filters',
    applyFilters: 'Apply Filters',
    addToCart: 'Add to Cart',
    added: 'Added',
    buyNow: 'Buy Now',
    off: 'OFF',
    freeDelivery: 'Free Delivery',
    codAvailable: 'Cash on Delivery Available',
    cashOnDelivery: 'Cash on Delivery',
    reviews: 'Reviews',
    rating: 'Rating',
    inStock: 'In Stock',
    outOfStock: 'Out of Stock',
    selectSize: 'Select Size',
    selectColor: 'Select Color',
    description: 'Description',
    features: 'Key Highlights',
    returnPolicy: 'Return Policy',
    daysReturn: '7-Day Easy Returns',
    authenticProducts: '100% Genuine Products',
    shoppingCart: 'Shopping Cart',
    orderSummary: 'Order Summary',
    subtotal: 'Subtotal',
    total: 'Total Amount',
    deliveryFee: 'Delivery Fee',
    free: 'FREE',
    proceedToCheckout: 'Proceed to Checkout',
    emptyCart: 'Your Cart is Empty',
    emptyCartDesc: 'Explore our latest collection and add your favorite items',
    startShopping: 'Start Shopping',
    enterAddress: 'Delivery Address',
    fullName: 'Full Name',
    phone: 'Phone Number',
    addressLine: 'House / Street / Area',
    city: 'City',
    state: 'State',
    pincode: 'PIN Code',
    selectPayment: 'Payment Method',
    cashOnDeliveryTitle: 'Cash on Delivery (Pay upon delivery)',
    placeOrder: 'Place Order (COD)',
    processingOrder: 'Processing your order...',
    orderSuccess: 'Order Placed Successfully!',
    orderNumber: 'Order Number',
    continueShopping: 'Continue Shopping',
    myOrders: 'My Orders',
    orderId: 'Order ID',
    orderPlaced: 'Order Placed',
    status: 'Status',
    trackOrder: 'Track Order',
    expectedDelivery: 'Expected Delivery',
    items: 'items',
    cancelOrder: 'Cancel Order',
    viewDetails: 'View Details',
    noOrdersYet: 'No Orders Yet',
    orderedOn: 'Ordered on',
    deliveredOn: 'Delivered on',
    inTransit: 'In Transit',
    outForDelivery: 'Out for Delivery',
    delivered: 'Delivered',
    myWishlist: 'My Wishlist',
    emptyWishlist: 'Your Wishlist is Empty',
    emptyWishlistDesc: 'Save items you love to shop later',
    moveToCart: 'Move to Cart',
    removeFromWishlist: 'Remove',
    exploreProducts: 'Explore Products',
    profile: 'Profile',
    profileDetails: 'Profile Details',
    savedAddresses: 'Saved Addresses',
    security: 'Security & Privacy',
    signOut: 'Sign Out',
    login: 'Login',
    register: 'Create Account',
    welcomeBack: 'Welcome Back',
    enterPhoneOrEmail: 'Enter Mobile Number or Email',
    sendOtp: 'Send OTP',
    verifyOtp: 'Verify OTP',
    continueBtn: 'Continue',
    cancel: 'Cancel',
    save: 'Save',
    edit: 'Edit',
    delete: 'Delete',
    back: 'Back',
    next: 'Next',
    language: 'Language',
    selectLanguage: 'Select Your Language',
    loading: 'Loading...',
    error: 'Something went wrong',
    success: 'Success',
    retry: 'Retry',
    close: 'Close',
    confirm: 'Confirm',
    itemAddedToCart: 'Added to your cart!',
    itemRemovedFromCart: 'Item removed from cart',
  },
  hi: {
    home: 'होम',
    categories: 'श्रेणियां',
    shop: 'शॉप',
    cart: 'कार्ट',
    orders: 'ऑर्डर्स',
    account: 'अकाउंट',
    wishlist: 'विशलिस्ट',
    notifications: 'सूचनाएं',
    support: 'सहायता',
    policies: 'नीतियां',
    searchProducts: 'उत्पाद और ब्रांड खोजें',
    searchPlaceholder: 'उत्पाद खोजें...',
    recentSearches: 'हालिया खोजें',
    clearAll: 'साफ़ करें',
    searchSuggestions: 'सुझाव',
    matchingProducts: 'मिलते-जुलते उत्पाद',
    viewAllResults: 'सभी परिणाम देखें',
    deliveryTo: 'डिलीवरी स्थान',
    change: 'बदलें',
    all: 'सभी',
    forYou: 'आपके लिए',
    men: 'पुरुष',
    women: 'महिला',
    kids: 'बच्चे',
    bags: 'बैग्स',
    footwear: 'फुटवियर',
    sandals: 'सैंडल',
    chappals: 'चप्पल',
    sneakers: 'स्नीकर्स',
    offers: 'ऑफ़र्स',
    trending: 'ट्रेंडिंग',
    newArrivals: 'नए उत्पाद',
    bestSellers: 'टॉप सेलिंग',
    topRated: 'टॉप रेटेड',
    filter: 'फ़िल्टर',
    filters: 'फ़िल्टर्स',
    sortBy: 'क्रमबद्ध करें',
    popular: 'लोकप्रियता',
    priceLowToHigh: 'कीमत: कम से ज्यादा',
    priceHighToLow: 'कीमत: ज्यादा से कम',
    discount: 'छूट',
    minDiscount: 'न्यूनतम छूट',
    resetFilters: 'रीसेट करें',
    applyFilters: 'लागू करें',
    addToCart: 'कार्ट में जोड़ें',
    added: 'जोड़ दिया गया',
    buyNow: 'अभी खरीदें',
    off: 'छूट',
    freeDelivery: 'मुफ़्त डिलीवरी',
    codAvailable: 'कैश ऑन डिलीवरी उपलब्ध',
    cashOnDelivery: 'कैश ऑन डिलीवरी',
    reviews: 'समीक्षाएं',
    rating: 'रेटिंग',
    inStock: 'उपलब्ध',
    outOfStock: 'स्टॉक समाप्त',
    selectSize: 'साइज़ चुनें',
    selectColor: 'रंग चुनें',
    description: 'विवरण',
    features: 'विशेषताएं',
    returnPolicy: 'वापसी नीति',
    daysReturn: '7-दिन आसान वापसी',
    authenticProducts: '100% असली उत्पाद',
    shoppingCart: 'शॉपिंग कार्ट',
    orderSummary: 'ऑर्डर सारांश',
    subtotal: 'उप-योग',
    total: 'कुल राशि',
    deliveryFee: 'डिलीवरी शुल्क',
    free: 'मुफ़्त',
    proceedToCheckout: 'चेकआउट करें',
    emptyCart: 'आपकी कार्ट खाली है',
    emptyCartDesc: 'पसंदीदा उत्पाद कार्ट में जोड़ें',
    startShopping: 'खरीदारी शुरू करें',
    enterAddress: 'डिलीवरी पता',
    fullName: 'पूरा नाम',
    phone: 'मोबाइल नंबर',
    addressLine: 'घर / सड़क / इलाका',
    city: 'शहर',
    state: 'राज्य',
    pincode: 'पिन कोड',
    selectPayment: 'भुगतान विकल्प',
    cashOnDeliveryTitle: 'कैश ऑन डिलीवरी (सामान मिलने पर भुगतान)',
    placeOrder: 'ऑर्डर करें (COD)',
    processingOrder: 'ऑर्डर प्रोसेस हो रहा है...',
    orderSuccess: 'ऑर्डर सफलतापूर्वक दर्ज!',
    orderNumber: 'ऑर्डर नंबर',
    continueShopping: 'खरीदारी जारी रखें',
    myOrders: 'मेरे ऑर्डर्स',
    orderId: 'ऑर्डर आईडी',
    orderPlaced: 'ऑर्डर हुआ',
    status: 'स्थिति',
    trackOrder: 'ट्रैक करें',
    expectedDelivery: 'संभावित डिलीवरी',
    items: 'आइटम',
    cancelOrder: 'ऑर्डर रद्द करें',
    viewDetails: 'विवरण देखें',
    noOrdersYet: 'कोई ऑर्डर नहीं',
    orderedOn: 'तारीख',
    deliveredOn: 'डिलीवरी तारीख',
    inTransit: 'रास्ते में',
    outForDelivery: 'डिलीवरी के लिए निकला',
    delivered: 'डिलीवर हुआ',
    myWishlist: 'मेरी विशलिस्ट',
    emptyWishlist: 'विशलिस्ट खाली है',
    emptyWishlistDesc: 'पसंदीदा सामान सहेजें',
    moveToCart: 'कार्ट में भेजें',
    removeFromWishlist: 'हटाएं',
    exploreProducts: 'उत्पाद देखें',
    profile: 'प्रोफ़ाइल',
    profileDetails: 'प्रोफ़ाइल विवरण',
    savedAddresses: 'सहेजे गए पते',
    security: 'सुरक्षा',
    signOut: 'लॉग आउट',
    login: 'लॉग इन',
    register: 'नया खाता',
    welcomeBack: 'स्वागत है',
    enterPhoneOrEmail: 'मोबाइल या ईमेल दर्ज करें',
    sendOtp: 'ओटीपी भेजें',
    verifyOtp: 'ओटीपी सत्यापित करें',
    continueBtn: 'जारी रखें',
    cancel: 'रद्द करें',
    save: 'सहेजें',
    edit: 'संपादित करें',
    delete: 'हटाएं',
    back: 'वापस',
    next: 'आगे',
    language: 'भाषा',
    selectLanguage: 'भाषा चुनें',
    loading: 'लोड हो रहा है...',
    error: 'त्रुटि हुई',
    success: 'सफल',
    retry: 'पुनः प्रयास करें',
    close: 'बंद करें',
    confirm: 'पुष्टि करें',
    itemAddedToCart: 'कार्ट में जोड़ा गया!',
    itemRemovedFromCart: 'कार्ट से हटाया गया',
  },
  bn: {
    home: 'হোম',
    categories: 'বিভাগ',
    shop: 'শপ',
    cart: 'কার্ট',
    orders: 'অর্ডার',
    account: 'অ্যাকাউন্ট',
    wishlist: 'উইশলিস্ট',
    notifications: 'বিজ্ঞপ্তি',
    support: 'সহায়তা',
    policies: 'নীতিমালা',
    searchProducts: 'পণ্য খুঁজুন',
    searchPlaceholder: 'পণ্য খুঁজুন...',
    recentSearches: 'সাম্প্রতিক অনুসন্ধান',
    clearAll: 'মুছুন',
    searchSuggestions: 'পরামর্শ',
    matchingProducts: 'মিল পণ্য',
    viewAllResults: 'সব দেখুন',
    deliveryTo: 'ডেলিভারি',
    change: 'পরিবর্তন',
    all: 'সব',
    forYou: 'আপনার জন্য',
    men: 'পুরুষ',
    women: 'মহিলা',
    kids: 'বাচ্চা',
    bags: 'ব্যাগ',
    footwear: 'জুতো',
    sandals: 'স্যান্ডেল',
    chappals: 'চটি',
    sneakers: 'স্নিকার্স',
    offers: 'অফার',
    trending: 'ট্রেন্ডিং',
    newArrivals: 'নতুন',
    bestSellers: 'সেরা বিক্রয়',
    topRated: 'শীর্ষ রেটিং',
    filter: 'ফিল্টার',
    filters: 'ফিল্টার',
    sortBy: 'সাজান',
    popular: 'জনপ্রিয়তা',
    priceLowToHigh: 'দাম: কম থেকে বেশি',
    priceHighToLow: 'দাম: বেশি থেকে কম',
    discount: 'ছাড়',
    minDiscount: 'নূন্যতম ছাড়',
    resetFilters: 'রিসেট',
    applyFilters: 'প্রয়োগ করুন',
    addToCart: 'কার্টে যোগ করুন',
    added: 'যোগ হয়েছে',
    buyNow: 'এখনই কিনুন',
    off: 'ছাড়',
    freeDelivery: 'ফ্রি ডেলিভারি',
    codAvailable: 'ক্যাশ অন ডেলিভারি উপলব্ধ',
    cashOnDelivery: 'ক্যাশ অন ডেলিভারি',
    reviews: 'পর্যালোচনা',
    rating: 'রেটিং',
    inStock: 'স্টকে আছে',
    outOfStock: 'স্টক শেষ',
    selectSize: 'সাইজ বাছুন',
    selectColor: 'রং বাছুন',
    description: 'বর্ণনা',
    features: 'বৈশিষ্ট্য',
    returnPolicy: 'রিটার্ন নীতি',
    daysReturn: '৭ দিন রিটার্ন',
    authenticProducts: '১০০% আসল পণ্য',
    shoppingCart: 'শপিং কার্ট',
    orderSummary: 'অর্ডারের বিবরণ',
    subtotal: 'উপমোট',
    total: 'মোট',
    deliveryFee: 'ডেলিভারি ফি',
    free: 'ফ্রি',
    proceedToCheckout: 'চেকআউট করুন',
    emptyCart: 'কার্ট খালি',
    emptyCartDesc: 'পণ্য যোগ করুন',
    startShopping: 'শপিং শুরু করুন',
    enterAddress: 'ঠিকানা',
    fullName: 'নাম',
    phone: 'ফোন',
    addressLine: 'ঠিকানা',
    city: 'শহর',
    state: 'রাজ্য',
    pincode: 'পিন কোড',
    selectPayment: 'পেমেন্ট',
    cashOnDeliveryTitle: 'ক্যাশ অন ডেলিভারি',
    placeOrder: 'অর্ডার দিন',
    processingOrder: 'প্রক্রিয়াকরণ...',
    orderSuccess: 'অর্ডার সফল!',
    orderNumber: 'অর্ডার নম্বর',
    continueShopping: 'শপিং চালিয়ে যান',
    myOrders: 'আমার অর্ডার',
    orderId: 'অর্ডার আইডি',
    orderPlaced: 'অর্ডার হয়েছে',
    status: 'অবস্থা',
    trackOrder: 'ট্র্যাক করুন',
    expectedDelivery: 'প্রত্যাশিত ডেলিভারি',
    items: 'টি পণ্য',
    cancelOrder: 'বাতিল করুন',
    viewDetails: 'বিবরণ দেখুন',
    noOrdersYet: 'কোন অর্ডার নেই',
    orderedOn: 'তারিখ',
    deliveredOn: 'ডেলিভারির তারিখ',
    inTransit: 'পথে আছে',
    outForDelivery: 'ডেলিভারি হচ্ছে',
    delivered: 'ডেলিভার্ড',
    myWishlist: 'উইশলিস্ট',
    emptyWishlist: 'উইশলিস্ট খালি',
    emptyWishlistDesc: 'পছন্দের পণ্য সংরক্ষণ করুন',
    moveToCart: 'কার্টে নিন',
    removeFromWishlist: 'মুছুন',
    exploreProducts: 'পণ্য দেখুন',
    profile: 'প্রোফাইল',
    profileDetails: 'প্রোফাইল বিবরণ',
    savedAddresses: 'সংরক্ষিত ঠিকানা',
    security: 'নিরাপত্তা',
    signOut: 'সাইন আউট',
    login: 'লগইন',
    register: 'রেজিস্টার',
    welcomeBack: 'স্বাগতম',
    enterPhoneOrEmail: 'ফোন বা ইমেল লিখুন',
    sendOtp: 'ওটিপি পাঠান',
    verifyOtp: 'যাচাই করুন',
    continueBtn: 'চালিয়ে যান',
    cancel: 'বাতিল',
    save: 'সংরক্ষণ',
    edit: 'সম্পাদনা',
    delete: 'মুছুন',
    back: 'পেছনে',
    next: 'পরবর্তী',
    language: 'ভাষা',
    selectLanguage: 'ভাষা বাছুন',
    loading: 'লোড হচ্ছে...',
    error: 'ত্রুটি',
    success: 'সফল',
    retry: 'পুনরায় চেষ্টা করুন',
    close: 'বন্ধ করুন',
    confirm: 'নিশ্চিত করুন',
    itemAddedToCart: 'কার্টে যোগ হয়েছে',
    itemRemovedFromCart: 'কার্ট থেকে সরানো হয়েছে',
  },
  te: {
    home: 'హోమ్',
    categories: 'వర్గాలు',
    shop: 'షాప్',
    cart: 'కార్ట్',
    orders: 'ఆర్డర్లు',
    account: 'ఖాతా',
    wishlist: 'విష్‌లిస్ట్',
    notifications: 'నోటిఫికేషన్లు',
    support: 'సహాయం',
    policies: 'విధానాలు',
    searchProducts: 'ఉత్పత్తులను వెతకండి',
    searchPlaceholder: 'వెతకండి...',
    recentSearches: 'ఇటీవలి శోధనలు',
    clearAll: 'క్లియర్ చేయండి',
    searchSuggestions: 'సూచనలు',
    matchingProducts: 'సరిపోలిన ఉత్పత్తులు',
    viewAllResults: 'అన్ని చూడండి',
    deliveryTo: 'డెలివరీ',
    change: 'మార్చండి',
    all: 'అన్నీ',
    forYou: 'మీ కోసం',
    men: 'పురుషులు',
    women: 'మహిళలు',
    kids: 'పిల్లలు',
    bags: 'బ్యాగులు',
    footwear: 'పాదరక్షలు',
    sandals: 'చెప్పులు',
    chappals: 'చప్పల్స్',
    sneakers: 'స్నీకర్స్',
    offers: 'ఆఫర్లు',
    trending: 'ట్రెండింగ్',
    newArrivals: 'కొత్తవి',
    bestSellers: 'బెస్ట్ సెల్లర్స్',
    topRated: 'టాప్ రేటెడ్',
    filter: 'ఫిల్టర్',
    filters: 'ఫిల్టర్లు',
    sortBy: 'క్రమబద్ధీకరించు',
    popular: 'జనాదరణ',
    priceLowToHigh: 'ధర: తక్కువ నుండి ఎక్కువ',
    priceHighToLow: 'ధర: ఎక్కువ నుండి తక్కువ',
    discount: 'రాయితీ',
    minDiscount: 'కనిష్ట రాయితీ',
    resetFilters: 'రీసెట్',
    applyFilters: 'వర్తించు',
    addToCart: 'కార్ట్‌కు జోడించు',
    added: 'జోడించబడింది',
    buyNow: 'ఇప్పుడే కొనండి',
    off: 'రాయితీ',
    freeDelivery: 'ఉచిత డెలివరీ',
    codAvailable: 'క్యాష్ ఆన్ డెలివరీ ఉంది',
    cashOnDelivery: 'క్యాష్ ఆన్ డెలివరీ',
    reviews: 'సమీక్షలు',
    rating: 'రేటింగ్',
    inStock: 'స్టాక్ ఉంది',
    outOfStock: 'స్టాక్ లేదు',
    selectSize: 'సైజు ఎంచుకోండి',
    selectColor: 'రంగు ఎంచుకోండి',
    description: 'వివరణ',
    features: 'ముఖ్యాంశాలు',
    returnPolicy: 'రిటర్న్ పాలసీ',
    daysReturn: '7 రోజుల రిటర్న్',
    authenticProducts: '100% అసలైన ఉత్పత్తులు',
    shoppingCart: 'షాపింగ్ కార్ట్',
    orderSummary: 'ఆర్డర్ సారాంశం',
    subtotal: 'మొత్తం',
    total: 'పూర్తి మొత్తం',
    deliveryFee: 'డెలివరీ రుసుము',
    free: 'ఉచితం',
    proceedToCheckout: 'చెక్‌అవుట్ చేయండి',
    emptyCart: 'కార్ట్ ఖాళీగా ఉంది',
    emptyCartDesc: 'ఉత్పత్తులను జోడించండి',
    startShopping: 'షాపింగ్ ప్రారంభించండి',
    enterAddress: 'చిరునామా',
    fullName: 'పూర్తి పేరు',
    phone: 'ఫోన్ నంబర్',
    addressLine: 'చిరునామా',
    city: 'నగరం',
    state: 'రాష్ట్రం',
    pincode: 'పిన్ కోడ్',
    selectPayment: 'చెల్లింపు విధానం',
    cashOnDeliveryTitle: 'క్యాష్ ఆన్ డెలివరీ',
    placeOrder: 'ఆర్డర్ చేయండి (COD)',
    processingOrder: 'ప్రాసెస్ అవుతోంది...',
    orderSuccess: 'ఆర్డర్ విజయవంతమైంది!',
    orderNumber: 'ఆర్డర్ సంఖ్య',
    continueShopping: 'షాపింగ్ కొనసాగించండి',
    myOrders: 'నా ఆర్డర్లు',
    orderId: 'ఆర్డర్ ఐడి',
    orderPlaced: 'ఆర్డర్ చేయబడింది',
    status: 'స్థితి',
    trackOrder: 'ట్రాక్ చేయండి',
    expectedDelivery: 'అంచనా డెలివరీ',
    items: 'వస్తువులు',
    cancelOrder: 'రద్దు చేయండి',
    viewDetails: 'వివరాలు చూడండి',
    noOrdersYet: 'ఇంకా ఆర్డర్లు లేవు',
    orderedOn: 'తేదీ',
    deliveredOn: 'డెలివరీ తేదీ',
    inTransit: 'దారిలో ఉంది',
    outForDelivery: 'డెలివరీకి వచ్చింది',
    delivered: 'డెలివరీ అయింది',
    myWishlist: 'నా విష్‌లిస్ట్',
    emptyWishlist: 'విష్‌లిస్ట్ ఖాళీగా ఉంది',
    emptyWishlistDesc: 'ఇష్టమైనవి భద్రపరచండి',
    moveToCart: 'కార్ట్‌కు తరలించు',
    removeFromWishlist: 'తొలగించు',
    exploreProducts: 'ఉత్పత్తులను చూడండి',
    profile: 'ప్రొఫైల్',
    profileDetails: 'ప్రొఫైల్ వివరాలు',
    savedAddresses: 'చిరునామాలు',
    security: 'భద్రత',
    signOut: 'లాగ్ అవుట్',
    login: 'లాగిన్',
    register: 'ఖాతా సృష్టించండి',
    welcomeBack: 'స్వాగతం',
    enterPhoneOrEmail: 'ఫోన్ లేదా ఈమెయిల్',
    sendOtp: 'OTP పంపండి',
    verifyOtp: 'OTP నిర్ధారించండి',
    continueBtn: 'కొనసాగించు',
    cancel: 'రద్దు',
    save: 'సేవ్',
    edit: 'సవరించు',
    delete: 'తొలగించు',
    back: 'వెనుకకు',
    next: 'తరువాత',
    language: 'భాష',
    selectLanguage: 'భాషను ఎంచుకోండి',
    loading: 'లోడ్ అవుతోంది...',
    error: 'లోపం జరిగింది',
    success: 'విజయం',
    retry: 'మళ్లీ ప్రయత్నించండి',
    close: 'మూసివేయి',
    confirm: 'నిర్ధారించు',
    itemAddedToCart: 'కార్ట్‌కు జోడించబడింది!',
    itemRemovedFromCart: 'కార్ట్ నుండి తీసివేయబడింది',
  },
  mr: { ...({} as any) },
  ta: { ...({} as any) },
  gu: { ...({} as any) },
  kn: { ...({} as any) },
  ml: { ...({} as any) },
  pa: { ...({} as any) },
  or: { ...({} as any) },
  as: { ...({} as any) },
  ur: { ...({} as any) },
};

// Fill any other languages with English fallback
const fallbackLanguages: LanguageCode[] = ['mr', 'ta', 'gu', 'kn', 'ml', 'pa', 'or', 'as', 'ur'];
for (const lang of fallbackLanguages) {
  TRANSLATIONS[lang] = { ...TRANSLATIONS.en };
}

export function getTranslation(lang: LanguageCode, key: keyof TranslationDictionary, fallback?: string): string {
  const dict = TRANSLATIONS[lang] || TRANSLATIONS.en;
  return dict[key] || TRANSLATIONS.en[key] || fallback || (key as string);
}
