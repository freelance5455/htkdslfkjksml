export type Ride = {
  id: string;
  driverName: string;
  from: string;
  to: string;
  date: string;
  departure: string;
  arrival: string;
  vehicle: 'Car' | 'Bike';
  vehicleModel: string;
  price: number;
  seats: number;
  rating: number;
  verified: boolean;
  vehicleVerified: boolean;
  onTime: number;
  cancellation: number;
};

export const demoRides: Ride[] = [
  {
    id: 'demo-1', driverName: 'Rahul Sharma', from: 'Jaipur', to: 'Delhi',
    date: 'Tomorrow', departure: '07:00 AM', arrival: '12:00 PM', vehicle: 'Car',
    vehicleModel: 'Sedan · AC', price: 650, seats: 2, rating: 4.8,
    verified: true, vehicleVerified: true, onTime: 94, cancellation: 2
  },
  {
    id: 'demo-2', driverName: 'Aman Verma', from: 'Jaipur', to: 'Delhi',
    date: 'Tomorrow', departure: '08:30 AM', arrival: '01:30 PM', vehicle: 'Bike',
    vehicleModel: 'Motorcycle', price: 280, seats: 1, rating: 4.7,
    verified: false, vehicleVerified: false, onTime: 90, cancellation: 5
  },
  {
    id: 'demo-3', driverName: 'Neha Singh', from: 'Delhi', to: 'Agra',
    date: 'Today', departure: '10:00 AM', arrival: '01:30 PM', vehicle: 'Car',
    vehicleModel: 'Hatchback · AC', price: 400, seats: 3, rating: 4.9,
    verified: false, vehicleVerified: false, onTime: 96, cancellation: 1
  },
  {
    id: 'demo-4', driverName: 'Karan Mehta', from: 'Mumbai', to: 'Pune',
    date: 'Tomorrow', departure: '09:00 AM', arrival: '12:00 PM', vehicle: 'Car',
    vehicleModel: 'SUV · AC', price: 350, seats: 3, rating: 4.6,
    verified: false, vehicleVerified: false, onTime: 88, cancellation: 7
  }
];