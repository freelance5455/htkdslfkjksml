import type { Species, Tier, SpeciesCategory } from '../types/game.ts';

// Comprehensive dataset generator ensuring 365+ species covering all categories and 5 tiers

const GRAINS_DATA = [
  { id: 'rice', name: 'Lúa Nước', icon: '🌾', tier: 1, unlock: 1, time: 15, price: 15, sell: 25, exp: 5 },
  { id: 'corn', name: 'Ngô Vàng', icon: '🌽', tier: 1, unlock: 2, time: 25, price: 25, sell: 40, exp: 6 },
  { id: 'wheat', name: 'Lúa Mì', icon: '🌾', tier: 1, unlock: 3, time: 35, price: 30, sell: 50, exp: 6 },
  { id: 'barley', name: 'Đại Mạch', icon: '🌾', tier: 2, unlock: 5, time: 60, price: 70, sell: 120, exp: 14 },
  { id: 'millet', name: 'Kê Vàng', icon: '🌾', tier: 2, unlock: 7, time: 75, price: 85, sell: 150, exp: 16 },
  { id: 'rye', name: 'Hắc Mạch', icon: '🌾', tier: 2, unlock: 9, time: 90, price: 100, sell: 180, exp: 18 },
  { id: 'quinoa', name: 'Diêm Mạch', icon: '🌾', tier: 3, unlock: 15, time: 150, price: 220, sell: 420, exp: 35 },
  { id: 'sorghum', name: 'Lúa Miến Đỏ', icon: '🌾', tier: 3, unlock: 18, time: 180, price: 260, sell: 500, exp: 40 },
  { id: 'moon_grain', name: 'Lúa Ánh Trăng', icon: '✨', tier: 4, unlock: 12, time: 300, price: 0, sell: 1200, exp: 85, parents: ['wheat', 'quinoa'] },
  { id: 'star_wheat', name: 'Lúa Mì Tinh Tú', icon: '🌟', tier: 5, unlock: 25, time: 480, price: 0, sell: 3200, exp: 180, parents: ['moon_grain', 'sorghum'] },
];

const VEGETABLES_DATA = [
  { id: 'tomato', name: 'Cà Chua', icon: '🍅', tier: 1, unlock: 1, time: 20, price: 18, sell: 30, exp: 5 },
  { id: 'carrot', name: 'Cà Rốt', icon: '🥕', tier: 1, unlock: 2, time: 30, price: 25, sell: 42, exp: 6 },
  { id: 'potato', name: 'Khoai Tây', icon: '🥔', tier: 1, unlock: 3, time: 40, price: 30, sell: 55, exp: 6 },
  { id: 'cabbage', name: 'Bắp Cải', icon: '🥬', tier: 1, unlock: 4, time: 50, price: 40, sell: 70, exp: 6 },
  { id: 'eggplant', name: 'Cà Tím', icon: '🍆', tier: 2, unlock: 6, time: 70, price: 80, sell: 145, exp: 15 },
  { id: 'cucumber', name: 'Dưa Leo', icon: '🥒', tier: 2, unlock: 8, time: 80, price: 90, sell: 165, exp: 16 },
  { id: 'pumpkin', name: 'Bí Ngô Khổng Lồ', icon: '🎃', tier: 2, unlock: 10, time: 100, price: 120, sell: 220, exp: 18 },
  { id: 'bell_pepper', name: 'Ớt Chuông Ngũ Sắc', icon: '🫑', tier: 2, unlock: 12, time: 110, price: 140, sell: 250, exp: 18 },
  { id: 'asparagus', name: 'Măng Tây Ngọc', icon: '🌱', tier: 3, unlock: 16, time: 160, price: 240, sell: 450, exp: 35 },
  { id: 'artichoke', name: 'A-ti-sô Đà Lạt', icon: '🌿', tier: 3, unlock: 20, time: 200, price: 300, sell: 580, exp: 42 },
  { id: 'pomato_mutant', name: 'Cây Củ Lai Pomato', icon: '🥔🍅', tier: 4, unlock: 14, time: 320, price: 0, sell: 1400, exp: 90, parents: ['potato', 'tomato'] },
  { id: 'crystal_melon', name: 'Dưa Pha Lê Vũ Trụ', icon: '🍈💎', tier: 5, unlock: 26, time: 500, price: 0, sell: 3600, exp: 190, parents: ['pomato_mutant', 'pumpkin'] },
];

// Flowers across 5 tiers: Crucial for Bee Gacha and Perfumes
const FLOWERS_DATA = [
  { id: 'daisy', name: 'Cúc Họa Mi', icon: '🌼', tier: 1, unlock: 2, time: 25, price: 20, sell: 35, exp: 5 },
  { id: 'tulip', name: 'Hoa Uất Kim Hương', icon: '🌷', tier: 1, unlock: 4, time: 35, price: 35, sell: 60, exp: 6 },
  { id: 'rose', name: 'Hoa Hồng Đỏ', icon: '🌹', tier: 2, unlock: 6, time: 65, price: 75, sell: 135, exp: 14 },
  { id: 'sunflower', name: 'Hoa Hướng Dương', icon: '🌻', tier: 2, unlock: 8, time: 85, price: 95, sell: 170, exp: 16 },
  { id: 'lavender', name: 'Oải Hương Tím', icon: '🪻', tier: 2, unlock: 11, time: 95, price: 110, sell: 200, exp: 18 },
  { id: 'lotus', name: 'Hoa Sen Bách Diệp', icon: '🪷', tier: 3, unlock: 15, time: 140, price: 210, sell: 400, exp: 32 },
  { id: 'orchid', name: 'Lan Hồ Điệp Hoàng Gia', icon: '🌸', tier: 3, unlock: 19, time: 180, price: 270, sell: 520, exp: 38 },
  { id: 'moon_blossom', name: 'Nguyệt Quỳnh Thần Thoại', icon: '🌙🌺', tier: 4, unlock: 13, time: 300, price: 0, sell: 1300, exp: 88, parents: ['lotus', 'lavender'] },
  { id: 'cosmic_rose', name: 'Hoa Hồng Tinh Vân', icon: '🌌🌹', tier: 5, unlock: 25, time: 520, price: 0, sell: 3800, exp: 195, parents: ['moon_blossom', 'orchid'] },
];

const HERBS_DATA = [
  { id: 'mint', name: 'Bạc Hà Cay', icon: '🌿', tier: 1, unlock: 3, time: 25, price: 22, sell: 38, exp: 5 },
  { id: 'basil', name: 'Húng Quế Tây', icon: '🍃', tier: 1, unlock: 4, time: 30, price: 28, sell: 48, exp: 6 },
  { id: 'rosemary', name: 'Hương Thảo', icon: '🌿', tier: 2, unlock: 7, time: 70, price: 80, sell: 150, exp: 15 },
  { id: 'ginger', name: 'Gừng Gió', icon: '🫚', tier: 2, unlock: 10, time: 90, price: 105, sell: 190, exp: 17 },
  { id: 'ginseng', name: 'Nhân Sâm Núi', icon: '🪴', tier: 3, unlock: 17, time: 190, price: 280, sell: 550, exp: 40 },
  { id: 'cordyceps', name: 'Đông Trùng Hạ Thảo', icon: '🐛🌱', tier: 4, unlock: 16, time: 340, price: 0, sell: 1600, exp: 95, parents: ['ginseng', 'ginger'] },
  { id: 'celestial_root', name: 'Căn Thảo Vạn Niên', icon: '✨🪴', tier: 5, unlock: 27, time: 540, price: 0, sell: 4200, exp: 200, parents: ['cordyceps', 'ginseng'] },
];

// Additional crops to scale up to rich biodiversity
const EXTRA_CROPS: { name: string; cat: SpeciesCategory; tier: Tier; icon: string; unlock: number; time: number; price: number; sell: number; exp: number }[] = [];
const cropPrefixes = ['Thảo Mộc', 'Dưa', 'Đậu', 'Hành', 'Cải', 'Củ', 'Khoai', 'Nho Đất', 'Bí', 'Ớt'];
const cropSuffixes = ['Miền Tây', 'Đồng Xanh', 'Hương Rừng', 'Ngọt Lịm', 'Phù Sa', 'Tuyết Sơn', 'Hồng Ngọc', 'Kim Sa', 'Bắc Cực', 'Hỏa Diệm', 'Viễn Đông', 'Hoàng Triều', 'Bách Thảo', 'Thần Kỳ', 'Cực Quang', 'Thái Cực', 'Huyền Bí'];

let cropCounter = 1;
for (const prefix of cropPrefixes) {
  for (const suffix of cropSuffixes) {
    if (cropCounter > 175) break;
    const tier: Tier = cropCounter % 15 === 0 ? 5 : cropCounter % 7 === 0 ? 4 : cropCounter % 4 === 0 ? 3 : cropCounter % 2 === 0 ? 2 : 1;
    const cat: SpeciesCategory = cropCounter % 3 === 0 ? 'crop_vegetable' : cropCounter % 3 === 1 ? 'crop_flower' : 'crop_herb';
    const icon = cat === 'crop_flower' ? '🌺' : cat === 'crop_herb' ? '🌿' : '🥬';
    EXTRA_CROPS.push({
      name: `${prefix} ${suffix}`,
      cat,
      tier,
      icon,
      unlock: tier === 1 ? 2 : tier === 2 ? 6 : tier === 3 ? 15 : tier === 4 ? 14 : 25,
      time: tier * 40,
      price: tier <= 3 ? tier * 55 : 0,
      sell: tier * 110,
      exp: tier * 16,
    });
    cropCounter++;
  }
}

// Fruit trees (Khu 4)
const FRUIT_TREES_DATA = [
  { id: 'tree_apple', name: 'Cây Táo Mật', icon: '🍎', tier: 1, unlock: 5, time: 40, price: 150, sell: 80, exp: 12 },
  { id: 'tree_banana', name: 'Cây Chuối Ngự', icon: '🍌', tier: 1, unlock: 5, time: 45, price: 160, sell: 85, exp: 12 },
  { id: 'tree_orange', name: 'Cây Cam Sành', icon: '🍊', tier: 2, unlock: 7, time: 80, price: 300, sell: 180, exp: 25 },
  { id: 'tree_peach', name: 'Cây Đào Tiên', icon: '🍑', tier: 2, unlock: 9, time: 90, price: 350, sell: 210, exp: 28 },
  { id: 'tree_mango', name: 'Cây Xoài Cát Hòa Lộc', icon: '🥭', tier: 2, unlock: 11, time: 100, price: 400, sell: 240, exp: 30 },
  { id: 'tree_grape', name: 'Giàn Nho Ninh Thuận', icon: '🍇', tier: 3, unlock: 15, time: 160, price: 650, sell: 420, exp: 55 },
  { id: 'tree_durian', name: 'Cây Sầu Riêng Ri6', icon: '🍈', tier: 3, unlock: 18, time: 200, price: 800, sell: 550, exp: 65 },
  { id: 'tree_phoenix_fruit', name: 'Cây Phượng Hoàng Quả', icon: '🔥🍎', tier: 4, unlock: 16, time: 320, price: 0, sell: 1500, exp: 130, parents: ['tree_peach', 'tree_durian'] },
  { id: 'tree_galaxy_apple', name: 'Cây Táo Tinh Vân', icon: '🌌🍏', tier: 5, unlock: 25, time: 500, price: 0, sell: 3500, exp: 240, parents: ['tree_phoenix_fruit', 'tree_grape'] },
];

// Mushrooms (Khu 4)
const MUSHROOMS_DATA = [
  { id: 'mush_straw', name: 'Nấm Rơm', icon: '🍄', tier: 1, unlock: 5, time: 35, price: 120, sell: 70, exp: 12 },
  { id: 'mush_button', name: 'Nấm Mỡ Trắng', icon: '🍄', tier: 1, unlock: 6, time: 45, price: 140, sell: 80, exp: 14 },
  { id: 'mush_shiitake', name: 'Nấm Hương Rừng', icon: '🍄', tier: 2, unlock: 8, time: 75, price: 260, sell: 160, exp: 26 },
  { id: 'mush_enoki', name: 'Nấm Kim Châm', icon: '🍄', tier: 2, unlock: 10, time: 90, price: 310, sell: 190, exp: 28 },
  { id: 'mush_morel', name: 'Nấm Bụng Dê Hoàng Gia', icon: '🍄', tier: 3, unlock: 16, time: 170, price: 600, sell: 450, exp: 58 },
  { id: 'mush_truffle', name: 'Nấm Truffle Đen Quý Hiếm', icon: '🖤🍄', tier: 3, unlock: 20, time: 220, price: 850, sell: 650, exp: 70 },
  { id: 'mush_spirit', name: 'Nấm Linh Chi Ngàn Năm', icon: '✨🍄', tier: 4, unlock: 17, time: 340, price: 0, sell: 1650, exp: 140, parents: ['mush_truffle', 'mush_shiitake'] },
  { id: 'mush_cosmic_spore', name: 'Nấm Tinh Tú Dạ Quang', icon: '🌌🍄', tier: 5, unlock: 26, time: 520, price: 0, sell: 3900, exp: 260, parents: ['mush_spirit', 'mush_morel'] },
];

// 10 Bee Species (5 Tiers, exactly 2 per tier with balanced perks)
export const BEE_SPECIES_DATA = [
  { id: 'bee_grass', name: 'Ong Mật Cỏ', icon: '🐝', tier: 1, unlock: 5, time: 40, honey: 'Mật Ong Thường', honeyIcon: '🍯', honeySell: 90, perk: '+2% tốc độ chín cây ăn quả' },
  { id: 'bee_yellow', name: 'Ong Vàng Nhỏ', icon: '🐝', tier: 1, unlock: 5, time: 45, honey: 'Mật Ong Hoa Cỏ', honeyIcon: '🍯', honeySell: 95, perk: '+2% tốc độ lớn nấm' },
  { id: 'bee_forest', name: 'Ong Rừng Xanh', icon: '🐝🌿', tier: 2, unlock: 8, time: 70, honey: 'Mật Ong Hoa Rừng', honeyIcon: '🍯', honeySell: 260, perk: '-5% thời gian tạo mật, +5% sản lượng' },
  { id: 'bee_rose', name: 'Ong Hoa Hồng', icon: '🐝🌹', tier: 2, unlock: 10, time: 75, honey: 'Mật Ong Hồng Hương', honeyIcon: '🍯', honeySell: 280, perk: '-5% thời gian tạo mật, +5% sản lượng' },
  { id: 'bee_jade', name: 'Ong Ngọc Bích', icon: '🐝💚', tier: 3, unlock: 16, time: 130, honey: 'Mật Ong Sữa Chúa', honeyIcon: '🍯✨', honeySell: 680, perk: '-10% thời gian tạo mật, +10% sản lượng' },
  { id: 'bee_golden', name: 'Ong Hoàng Kim', icon: '🐝⭐', tier: 3, unlock: 19, time: 140, honey: 'Mật Ong Hoàng Triều', honeyIcon: '🍯👑', honeySell: 750, perk: '-10% thời gian tạo mật, +10% sản lượng' },
  { id: 'bee_moon', name: 'Ong Ánh Trăng', icon: '🐝🌙', tier: 4, unlock: 20, time: 240, honey: 'Mật Ong Nguyệt Quang', honeyIcon: '🍯🌙', honeySell: 1850, perk: '-15% thời gian tạo mật, +15% sản lượng, 5% rơi Sáp Ong Hiếm' },
  { id: 'bee_crystal', name: 'Ong Pha Lê', icon: '🐝💎', tier: 4, unlock: 22, time: 260, honey: 'Mật Ong Pha Lê', honeyIcon: '🍯💎', honeySell: 2000, perk: '-15% thời gian tạo mật, +15% sản lượng, 5% rơi Sáp Ong Hiếm' },
  { id: 'bee_nebula', name: 'Ong Tinh Vân', icon: '🐝🌌', tier: 5, unlock: 27, time: 420, honey: 'Mật Ong Ngân Hà', honeyIcon: '🍯🌌', honeySell: 4800, perk: '-20% thời gian tạo mật, +20% sản lượng, 10% rơi Phấn Hoa Đột Biến' },
  { id: 'bee_queen_cosmic', name: 'Ong Nữ Hoàng Vũ Trụ', icon: '🐝👑🌌', tier: 5, unlock: 29, time: 450, honey: 'Mật Ong Vũ Trụ Chí Tôn', honeyIcon: '🍯✨👑', honeySell: 5500, perk: '-20% thời gian tạo mật, +20% sản lượng, 10% rơi Phấn Hoa Đột Biến' },
];

// Animals (Khu 2) - 1 coop per species, max 10 animals per coop
const ANIMALS_DATA = [
  { id: 'chicken', name: 'Gà Ta', icon: '🐔', tier: 1, unlock: 1, time: 30, price: 100, sellVal: 75, exp: 14, prod: 'Trứng Gà Tươi', prodIcon: '🥚', prodYield: 1, prodSell: 35, favFood: 'thức_ăn_gia_cầm' },
  { id: 'duck', name: 'Vịt Bầu Cánh Trắng', icon: '🦆', tier: 1, unlock: 2, time: 35, price: 140, sellVal: 105, exp: 16, prod: 'Trứng Vịt', prodIcon: '🥚', prodYield: 1, prodSell: 45, favFood: 'thức_ăn_gia_cầm' },
  { id: 'rabbit', name: 'Thỏ Trắng Tai Dài', icon: '🐇', tier: 1, unlock: 4, time: 40, price: 180, sellVal: 135, exp: 16, prod: 'Lông Thỏ Mềm', prodIcon: '🧶', prodYield: 1, prodSell: 60, favFood: 'thức_ăn_cỏ' },
  { id: 'dairy_cow', name: 'Bò Sữa Hà Lan', icon: '🐄', tier: 2, unlock: 5, time: 70, price: 450, sellVal: 337, exp: 32, prod: 'Sữa Bò Tươi', prodIcon: '🥛', prodYield: 2, prodSell: 110, favFood: 'cám_cao_cấp' },
  { id: 'merino_sheep', name: 'Cừu Merino', icon: '🐑', tier: 2, unlock: 7, time: 80, price: 550, sellVal: 412, exp: 36, prod: 'Len Cừu Thượng Hạng', prodIcon: '🧶', prodYield: 2, prodSell: 135, favFood: 'cám_cao_cấp' },
  { id: 'goat', name: 'Dê Núi Saanen', icon: '🐐', tier: 2, unlock: 9, time: 90, price: 600, sellVal: 450, exp: 40, prod: 'Sữa Dê Thanh Khiết', prodIcon: '🥛', prodYield: 2, prodSell: 150, favFood: 'thức_ăn_cỏ' },
  { id: 'pig', name: 'Lợn Ba Xuyên', icon: '🐖', tier: 2, unlock: 11, time: 100, price: 700, sellVal: 525, exp: 40, prod: 'Mỡ Lợn Hảo Hạng', prodIcon: '🥓', prodYield: 2, prodSell: 170, favFood: 'cám_cao_cấp' },
  { id: 'alpaca', name: 'Lạc Đà Lùn Alpaca', icon: '🦙', tier: 3, unlock: 15, time: 150, price: 1200, sellVal: 900, exp: 75, prod: 'Lông Vũ Alpaca Hoàng Gia', prodIcon: '🧶✨', prodYield: 3, prodSell: 380, favFood: 'cám_cao_cấp' },
  { id: 'spotted_deer', name: 'Hươu Sao Hoa Mai', icon: '🦌', tier: 3, unlock: 18, time: 180, price: 1600, sellVal: 1200, exp: 85, prod: 'Nhung Hươu Bổ Dưỡng', prodIcon: '🫎', prodYield: 2, prodSell: 520, favFood: 'cám_cao_cấp' },
  { id: 'peacock', name: 'Khổng Tước Ánh Kim', icon: '🦚', tier: 3, unlock: 22, time: 210, price: 2000, sellVal: 1500, exp: 90, prod: 'Lông Vũ Khổng Tước', prodIcon: '🪶', prodYield: 2, prodSell: 640, favFood: 'thức_ăn_gia_cầm' },
  // Tier 4 Mythical Beasts (Bred in Zone 5)
  { id: 'beast_pegasus', name: 'Thiên Mã Ánh Bạc', icon: '🦄', tier: 4, unlock: 14, time: 320, price: 0, sellVal: 3500, exp: 170, prod: 'Bờm Ngựa Ánh Bạc', prodIcon: '✨🦄', prodYield: 3, prodSell: 1450, parents: ['merino_sheep', 'alpaca'] },
  { id: 'beast_kirin', name: 'Kỳ Lân Hoàng Thổ', icon: '🦁✨', tier: 4, unlock: 18, time: 360, price: 0, sellVal: 4200, exp: 190, prod: 'Vảy Kỳ Lân May Mắn', prodIcon: '🛡️✨', prodYield: 3, prodSell: 1750, parents: ['spotted_deer', 'peacock'] },
  // Tier 5 Cosmic Beasts
  { id: 'beast_phoenix', name: 'Phượng Hoàng Lửa Bất Diệt', icon: '🔥🦅', tier: 5, unlock: 25, time: 540, price: 0, sellVal: 8500, exp: 320, prod: 'Lông Phượng Hoàng Hoàng Triều', prodIcon: '🔥🪶', prodYield: 4, prodSell: 4200, parents: ['beast_pegasus', 'peacock'] },
  { id: 'beast_astral_dragon', name: 'Thanh Long Tinh Tú', icon: '🐉🌌', tier: 5, unlock: 28, time: 600, price: 0, sellVal: 10500, exp: 340, prod: 'Long Châu Tinh Vân', prodIcon: '🔮🌌', prodYield: 4, prodSell: 5200, parents: ['beast_kirin', 'beast_phoenix'] },
];

// Scaled extra pets/beasts
const EXTRA_ANIMALS: typeof ANIMALS_DATA = [];
const animalTypes = ['Gà', 'Vịt', 'Ngỗng', 'Thỏ', 'Dê', 'Cừu', 'Bò', 'Lợn', 'Ngựa', 'Linh Cẩu'];
const animalSubtypes = ['Hoa Cúc', 'Tuyết Sơn', 'Mặt Trời', 'Thảo Nguyên', 'Đồi Chè', 'Đầm Phù Sa', 'Nguyệt Quang', 'Lam Điền', 'Kim Cương', 'Thiên Hà'];
let animIndex = 1;
for (const aType of animalTypes) {
  for (const sub of animalSubtypes) {
    if (animIndex > 90) break;
    const tier: Tier = animIndex % 18 === 0 ? 5 : animIndex % 8 === 0 ? 4 : animIndex % 4 === 0 ? 3 : animIndex % 2 === 0 ? 2 : 1;
    EXTRA_ANIMALS.push({
      id: `anim_${animIndex}`,
      name: `${aType} ${sub}`,
      icon: tier >= 4 ? '✨🐾' : '🐾',
      tier,
      unlock: tier === 1 ? 2 : tier === 2 ? 6 : tier === 3 ? 15 : tier === 4 ? 14 : 25,
      time: tier * 45,
      price: tier <= 3 ? tier * 250 : 0,
      sellVal: tier * 350,
      exp: tier * 30,
      prod: `Sản Phẩm ${aType} ${sub}`,
      prodIcon: '📦',
      prodYield: tier,
      prodSell: tier * 120,
      favFood: 'cám_cao_cấp',
    });
    animIndex++;
  }
}

// Aquatic (Khu 3) - 1 tank per species, max 10 fish per tank
const AQUATIC_DATA = [
  { id: 'carp', name: 'Cá Chép Vàng', icon: '🐟', tier: 1, unlock: 8, time: 35, price: 160, sellVal: 120, exp: 14, prod: 'Thịt Cá Chép Tươi', prodIcon: '🐟', prodYield: 1, prodSell: 65, water: 'freshwater', favFood: 'thức_ăn_thủy_sinh' },
  { id: 'tilapia', name: 'Cá Rô Phi Đầm Sen', icon: '🐟', tier: 1, unlock: 8, time: 40, price: 180, sellVal: 135, exp: 15, prod: 'Vảy Cá Rô', prodIcon: '🐟', prodYield: 1, prodSell: 75, water: 'freshwater', favFood: 'thức_ăn_thủy_sinh' },
  { id: 'catfish', name: 'Cá Tra Sông Tiền', icon: '🐡', tier: 2, unlock: 10, time: 75, price: 420, sellVal: 315, exp: 32, prod: 'Phi-lê Cá Tra', prodIcon: '🐟', prodYield: 2, prodSell: 180, water: 'freshwater', favFood: 'thức_ăn_thủy_sinh' },
  { id: 'shrimp', name: 'Tôm Sú Cà Mau', icon: '🦐', tier: 2, unlock: 12, time: 85, price: 500, sellVal: 375, exp: 36, prod: 'Tôm Sú Tươi Sống', prodIcon: '🦐', prodYield: 2, prodSell: 220, water: 'shallow_sea', favFood: 'mồi_tôm_đặc_biệt' },
  { id: 'crab', name: 'Cua Biển Năm Căn', icon: '🦀', tier: 2, unlock: 14, time: 95, price: 620, sellVal: 465, exp: 38, prod: 'Gạch Cua Biển', prodIcon: '🦀', prodYield: 2, prodSell: 270, water: 'shallow_sea', favFood: 'mồi_tôm_đặc_biệt' },
  { id: 'pearl_oyster', name: 'Hàu Ngọc Phú Quốc', icon: '🦪', tier: 3, unlock: 16, time: 160, price: 1100, sellVal: 825, exp: 70, prod: 'Ngọc Trai Sáng', prodIcon: '🦪✨', prodYield: 2, prodSell: 550, water: 'shallow_sea', favFood: 'mồi_tôm_đặc_biệt' },
  { id: 'koi_fish', name: 'Cá Koi Ngũ Thái Hoàng Triều', icon: '🎏', tier: 3, unlock: 19, time: 190, price: 1500, sellVal: 1125, exp: 85, prod: 'Vảy Cá Koi May Mắn', prodIcon: '🎏✨', prodYield: 2, prodSell: 720, water: 'moonlight_lake', favFood: 'thức_ăn_thủy_sinh' },
  // Tier 4 Bred Aquatic
  { id: 'moon_jelly', name: 'Sứa Nguyệt Quang Biển Sâu', icon: '🪼✨', tier: 4, unlock: 15, time: 320, price: 0, sellVal: 3200, exp: 160, prod: 'Tinh Chất Dạ Quang', prodIcon: '🧪✨', prodYield: 3, prodSell: 1550, water: 'moonlight_lake', parents: ['pearl_oyster', 'koi_fish'] },
  { id: 'leviathan_mini', name: 'Hải Long Thần Thoại', icon: '🐉🌊', tier: 4, unlock: 20, time: 360, price: 0, sellVal: 4500, exp: 185, prod: 'Vảy Hải Long', prodIcon: '🛡️🌊', prodYield: 3, prodSell: 1950, water: 'moonlight_lake', parents: ['moon_jelly', 'crab'] },
  // Tier 5 Cosmic Aquatic
  { id: 'star_whale', name: 'Kình Ngư Ngân Hà', icon: '🐋🌌', tier: 5, unlock: 25, time: 540, price: 0, sellVal: 9500, exp: 310, prod: 'Dầu Tinh Tú Ngân Hà', prodIcon: '🌌🪔', prodYield: 4, prodSell: 4800, water: 'moonlight_lake', parents: ['leviathan_mini', 'moon_jelly'] },
];

// Scaled extra aquatic species (total 55+)
const EXTRA_AQUATIC: typeof AQUATIC_DATA = [];
const fishNames = ['Cá Bống', 'Cá Lóc', 'Cá Trắm', 'Cá Chẽm', 'Tôm Hùm', 'Bạch Tuộc', 'Mực Ống', 'Cá Ngừ', 'Cá Hồi', 'Cá Voi Cổ'];
const waterModifiers = ['Đồng Sen', 'Rạn San Hô', 'Rừng Sác', 'Nước Trong', 'Hoàng Hôn', 'Tảo Lam', 'Băng Bắc Hải', 'Huyền Vũ', 'Thủy Ngân', 'Vũ Trụ'];
let aquaIndex = 1;
for (const f of fishNames) {
  for (const m of waterModifiers) {
    if (aquaIndex > 45) break;
    const tier: Tier = aquaIndex % 15 === 0 ? 5 : aquaIndex % 6 === 0 ? 4 : aquaIndex % 3 === 0 ? 3 : aquaIndex % 2 === 0 ? 2 : 1;
    EXTRA_AQUATIC.push({
      id: `aqua_${aquaIndex}`,
      name: `${f} ${m}`,
      icon: tier >= 4 ? '✨🐟' : '🐟',
      tier,
      unlock: tier === 1 ? 8 : tier === 2 ? 11 : tier === 3 ? 16 : tier === 4 ? 18 : 25,
      time: tier * 40,
      price: tier <= 3 ? tier * 280 : 0,
      sellVal: tier * 390,
      exp: tier * 28,
      prod: `Sản Phẩm ${f} ${m}`,
      prodIcon: '📦',
      prodYield: tier,
      prodSell: tier * 130,
      water: aquaIndex % 3 === 0 ? 'moonlight_lake' : aquaIndex % 2 === 0 ? 'shallow_sea' : 'freshwater',
      favFood: 'thức_ăn_thủy_sinh',
    });
    aquaIndex++;
  }
}

// Combine all species into master dictionary
export const ALL_SPECIES: Species[] = [];

// Convert Grains
for (const g of GRAINS_DATA) {
  ALL_SPECIES.push({
    id: g.id,
    name: g.name,
    category: 'crop_grain',
    tier: g.tier as Tier,
    icon: g.icon,
    description: `Hạt giống ${g.name} phẩm chất Bậc ${g.tier}.`,
    growthTime: g.time,
    unlockLevel: g.unlock,
    seedBuyPrice: g.price,
    harvestProductId: `prod_${g.id}`,
    harvestProductName: g.name,
    harvestProductIcon: g.icon,
    harvestBaseYield: 2,
    baseSellPrice: g.sell,
    baseExp: g.exp,
    breedingParents: (g as any).parents,
  });
}

// Convert Vegetables
for (const v of VEGETABLES_DATA) {
  ALL_SPECIES.push({
    id: v.id,
    name: v.name,
    category: 'crop_vegetable',
    tier: v.tier as Tier,
    icon: v.icon,
    description: `Giống rau củ ${v.name} tươi ngon, giàu dưỡng chất.`,
    growthTime: v.time,
    unlockLevel: v.unlock,
    seedBuyPrice: v.price,
    harvestProductId: `prod_${v.id}`,
    harvestProductName: v.name,
    harvestProductIcon: v.icon,
    harvestBaseYield: 2,
    baseSellPrice: v.sell,
    baseExp: v.exp,
    breedingParents: (v as any).parents,
  });
}

// Convert Flowers
for (const f of FLOWERS_DATA) {
  ALL_SPECIES.push({
    id: f.id,
    name: f.name,
    category: 'crop_flower',
    tier: f.tier as Tier,
    icon: f.icon,
    description: `Hoa ${f.name} ngát hương, nguyên liệu cho đài Gacha Ong & Tinh dầu.`,
    growthTime: f.time,
    unlockLevel: f.unlock,
    seedBuyPrice: f.price,
    harvestProductId: `prod_${f.id}`,
    harvestProductName: f.name,
    harvestProductIcon: f.icon,
    harvestBaseYield: 2,
    baseSellPrice: f.sell,
    baseExp: f.exp,
    breedingParents: (f as any).parents,
  });
}

// Convert Herbs
for (const h of HERBS_DATA) {
  ALL_SPECIES.push({
    id: h.id,
    name: h.name,
    category: 'crop_herb',
    tier: h.tier as Tier,
    icon: h.icon,
    description: `Thảo dược ${h.name} bồi bổ, chiết xuất đan dược và thuốc kích thích.`,
    growthTime: h.time,
    unlockLevel: h.unlock,
    seedBuyPrice: h.price,
    harvestProductId: `prod_${h.id}`,
    harvestProductName: h.name,
    harvestProductIcon: h.icon,
    harvestBaseYield: 2,
    baseSellPrice: h.sell,
    baseExp: h.exp,
    breedingParents: (h as any).parents,
  });
}

// Convert Extra Crops
for (let i = 0; i < EXTRA_CROPS.length; i++) {
  const ec = EXTRA_CROPS[i];
  ALL_SPECIES.push({
    id: `extra_crop_${i + 1}`,
    name: ec.name,
    category: ec.cat,
    tier: ec.tier,
    icon: ec.icon,
    description: `Giống nông sản ${ec.name} thu hoạch bội thu.`,
    growthTime: ec.time,
    unlockLevel: ec.unlock,
    seedBuyPrice: ec.price,
    harvestProductId: `prod_extra_crop_${i + 1}`,
    harvestProductName: ec.name,
    harvestProductIcon: ec.icon,
    harvestBaseYield: 2,
    baseSellPrice: ec.sell,
    baseExp: ec.exp,
  });
}

// Convert Fruit Trees
for (const ft of FRUIT_TREES_DATA) {
  ALL_SPECIES.push({
    id: ft.id,
    name: ft.name,
    category: 'fruit_tree',
    tier: ft.tier as Tier,
    icon: ft.icon,
    description: `${ft.name} sum suê trĩu quả tại Vườn Quả Khu 4.`,
    growthTime: ft.time,
    unlockLevel: ft.unlock,
    seedBuyPrice: ft.price,
    harvestProductId: `prod_${ft.id}`,
    harvestProductName: `Quả ${ft.name.replace('Cây ', '').replace('Giàn ', '')}`,
    harvestProductIcon: ft.icon,
    harvestBaseYield: 3,
    baseSellPrice: ft.sell,
    baseExp: ft.exp,
    breedingParents: (ft as any).parents,
  });
}

// Convert Mushrooms
for (const m of MUSHROOMS_DATA) {
  ALL_SPECIES.push({
    id: m.id,
    name: m.name,
    category: 'mushroom',
    tier: m.tier as Tier,
    icon: m.icon,
    description: `Gỗ mục cấy ${m.name} phát triển mạnh mẽ khi trời mù sương.`,
    growthTime: m.time,
    unlockLevel: m.unlock,
    seedBuyPrice: m.price,
    harvestProductId: `prod_${m.id}`,
    harvestProductName: m.name,
    harvestProductIcon: m.icon,
    harvestBaseYield: 3,
    baseSellPrice: m.sell,
    baseExp: m.exp,
    breedingParents: (m as any).parents,
  });
}

// Convert Bees
for (const b of BEE_SPECIES_DATA) {
  ALL_SPECIES.push({
    id: b.id,
    name: b.name,
    category: 'bee',
    tier: b.tier as Tier,
    icon: b.icon,
    description: `${b.name} chăm chỉ thụ phấn. Lợi ích: ${b.perk}`,
    growthTime: b.time,
    unlockLevel: b.unlock,
    seedBuyPrice: 0, // obtained via gacha
    harvestProductId: `honey_${b.id}`,
    harvestProductName: b.honey,
    harvestProductIcon: b.honeyIcon,
    harvestBaseYield: 1,
    baseSellPrice: b.honeySell,
    baseExp: b.tier * 25,
    specialBuff: b.perk,
  });
}

// Convert Animals
for (const a of ANIMALS_DATA) {
  ALL_SPECIES.push({
    id: a.id,
    name: a.name,
    category: 'animal',
    tier: a.tier as Tier,
    icon: a.icon,
    description: `Động vật nuôi ${a.name} chung một chuồng duy nhất tối đa 10 con.`,
    growthTime: a.time,
    unlockLevel: a.unlock,
    seedBuyPrice: a.price,
    harvestProductId: `prod_${a.id}`,
    harvestProductName: a.prod,
    harvestProductIcon: a.prodIcon,
    harvestBaseYield: a.prodYield,
    baseSellPrice: a.prodSell,
    baseExp: a.exp,
    favoriteFoodId: a.favFood,
    breedingParents: (a as any).parents,
  });
}

// Convert Extra Animals
for (const ea of EXTRA_ANIMALS) {
  ALL_SPECIES.push({
    id: ea.id,
    name: ea.name,
    category: 'animal',
    tier: ea.tier as Tier,
    icon: ea.icon,
    description: `Giống ${ea.name} khỏe mạnh, ngoan ngoãn.`,
    growthTime: ea.time,
    unlockLevel: ea.unlock,
    seedBuyPrice: ea.price,
    harvestProductId: `prod_${ea.id}`,
    harvestProductName: ea.prod,
    harvestProductIcon: ea.prodIcon,
    harvestBaseYield: ea.prodYield,
    baseSellPrice: ea.prodSell,
    baseExp: ea.exp,
    favoriteFoodId: ea.favFood,
  });
}

// Convert Aquatic
for (const aq of AQUATIC_DATA) {
  ALL_SPECIES.push({
    id: aq.id,
    name: aq.name,
    category: 'aquatic',
    tier: aq.tier as Tier,
    icon: aq.icon,
    description: `Thủy sản ${aq.name} nuôi trong hồ ${aq.water === 'freshwater' ? 'nước ngọt' : aq.water === 'shallow_sea' ? 'biển cạn' : 'hồ nguyệt quang'}.`,
    growthTime: aq.time,
    unlockLevel: aq.unlock,
    seedBuyPrice: aq.price,
    harvestProductId: `prod_${aq.id}`,
    harvestProductName: aq.prod,
    harvestProductIcon: aq.prodIcon,
    harvestBaseYield: aq.prodYield,
    baseSellPrice: aq.prodSell,
    baseExp: aq.exp,
    favoriteFoodId: aq.favFood,
    breedingParents: (aq as any).parents,
  });
}

// Convert Extra Aquatic
for (const exq of EXTRA_AQUATIC) {
  ALL_SPECIES.push({
    id: exq.id,
    name: exq.name,
    category: 'aquatic',
    tier: exq.tier as Tier,
    icon: exq.icon,
    description: `Thủy sản ${exq.name} sinh trưởng dồi dào.`,
    growthTime: exq.time,
    unlockLevel: exq.unlock,
    seedBuyPrice: exq.price,
    harvestProductId: `prod_${exq.id}`,
    harvestProductName: exq.prod,
    harvestProductIcon: exq.prodIcon,
    harvestBaseYield: exq.prodYield,
    baseSellPrice: exq.prodSell,
    baseExp: exq.exp,
    favoriteFoodId: exq.favFood,
  });
}

// Helper lookup map
export const SPECIES_MAP = new Map<string, Species>(ALL_SPECIES.map((s) => [s.id, s]));

export function getSpeciesById(id: string): Species | undefined {
  return SPECIES_MAP.get(id);
}
