import readme from "../native/README.md?raw";
import pubspec from "../native/pubspec.yaml?raw";
import manifest from "../native/AndroidManifest.xml?raw";
import mainDart from "../native/lib/main.dart?raw";
import meshService from "../native/lib/core/mesh_service.dart?raw";
import permissionService from "../native/lib/core/permission_service.dart?raw";
import meshPacket from "../native/lib/models/mesh_packet.dart?raw";
import chatMessage from "../native/lib/models/chat_message.dart?raw";
import permissionsGate from "../native/lib/screens/permissions_gate.dart?raw";
import discoveryScreen from "../native/lib/screens/discovery_screen.dart?raw";
import chatScreen from "../native/lib/screens/chat_screen.dart?raw";

export interface NativeFile {
  zipPath: string;
  label: string;
  note: string;
  code: string;
}

export const nativeFiles: NativeFile[] = [
  { zipPath: "meshlink/README.md", label: "README.md", note: "Build steps and mesh rules", code: readme },
  { zipPath: "meshlink/pubspec.yaml", label: "pubspec.yaml", note: "Dependencies — nearby_connections (Google Nearby API)", code: pubspec },
  { zipPath: "meshlink/android/app/src/main/AndroidManifest.xml", label: "AndroidManifest.xml", note: "Bluetooth, Wi-Fi Direct, hotspot, location permissions", code: manifest },
  { zipPath: "meshlink/lib/main.dart", label: "main.dart", note: "App root, theme, permission gate wiring", code: mainDart },
  { zipPath: "meshlink/lib/core/mesh_service.dart", label: "core/mesh_service.dart", note: "The relay engine on Google Nearby Connections (P2P_CLUSTER)", code: meshService },
  { zipPath: "meshlink/lib/core/permission_service.dart", label: "core/permission_service.dart", note: "One-tap request of all Android permissions", code: permissionService },
  { zipPath: "meshlink/lib/models/mesh_packet.dart", label: "models/mesh_packet.dart", note: "Packet: senderId, targetId, messageId, TTL = 10, payload", code: meshPacket },
  { zipPath: "meshlink/lib/models/chat_message.dart", label: "models/chat_message.dart", note: "Chat row with sent / delivered / hop status", code: chatMessage },
  { zipPath: "meshlink/lib/screens/permissions_gate.dart", label: "screens/permissions_gate.dart", note: "First-run permissions screen", code: permissionsGate },
  { zipPath: "meshlink/lib/screens/discovery_screen.dart", label: "screens/discovery_screen.dart", note: "BLE / Wi-Fi radar, peer list, connected-peers indicator", code: discoveryScreen },
  { zipPath: "meshlink/lib/screens/chat_screen.dart", label: "screens/chat_screen.dart", note: "Chat UI: checks, double checks, hop counts, relay ticker", code: chatScreen },
];

export const totalLines = nativeFiles.reduce(
  (n, f) => n + f.code.split("\n").length,
  0
);
