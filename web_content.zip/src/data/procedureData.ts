import { WorkProcedureReport } from '../types/procedure';

import imgSandblasting from '../assets/images/op_sandblasting_sa25_1792393509954.jpg';
import imgPaintingAirless from '../assets/images/op_liquid_coating_airless_1792393510989.jpg';
import imgSafety from '../assets/images/op_safety_inspection_1792391864369.jpg';
import imgMaintenance from '../assets/images/op_maintenance_check_1792391863808.jpg';

export const INITIAL_PROCEDURES: WorkProcedureReport[] = [
  {
    id: 'proc-001',
    code: 'SOP-SFL-014',
    title: 'Istruzione Operativa: Ciclo di Sabbiatura SA 2.5 e Applicazione Airless Epossidica',
    revision: 'Rev. 02',
    date: '2026-10-18',
    author: 'M. Preato (Responsabile Tecnico)',
    department: 'Sabbiatura',
    scope: 'Definire la sequenza standard di esecuzione per la preparazione superficiale con graniglia/garnet e successiva primerizzazione anticorrosiva secondo ISO 12944.',
    equipmentAndPpe: 'Scafandro ventilato con filtro a carboni attivi, tuta antistatica Tyvek, cuffie 3M, spessimetro PosiTector 6000, termo-igrometro DPM.',
    preferredLayout: 'detailed',
    status: 'approvata',
    steps: [
      {
        id: 's-1',
        stepNumber: 1,
        title: 'Verifica DPI e Controllo Preliminare Inquinanti Superficiali',
        instruction: 'Prima di iniziare la sabbiatura, verificare l\'assenza di residui d\'olio e grasso sui manufatti metallici. Eseguire sgrassaggio a solvente secondo SSPC-SP 1 se necessario. Indossare tuta, guanti protettivi e casco ventilato.',
        photoUrl: imgSafety,
        photoCaption: 'Ispezione preliminare carpenteria pesante e verifica idoneità DPI operatore',
        photoTag: 'Sicurezza & DPI',
        safetyNotice: 'Vietato iniziare senza ventilazione forzata della cabina attiva.'
      },
      {
        id: 's-2',
        stepNumber: 2,
        title: 'Sabbiatura Abrasiva a Getto Libero Grado SA 2.5',
        instruction: 'Impostare la pressione al manometro della tramoggia a 6.8 - 7.2 bar con abrasivo Garnet 30/60 Mesh. Mantenere l\'ugello Venturi n. 8 a una distanza di 30-40 cm con angolo di 75-80° rispetto alla superficie per ottenere un profilo Medium G (50-60 µm).',
        photoUrl: imgSandblasting,
        photoCaption: 'Superficie metallica Near-White dopo sabbiatura SA 2.5 con incisione uniforme',
        photoTag: 'Sabbiatura SA 2.5',
        safetyNotice: 'Controllare periodicamente l\'usura del foro calibrato dell\'ugello.'
      },
      {
        id: 's-3',
        stepNumber: 3,
        title: 'Depolveratura e Controllo Parametri Ambientali (ISO 8502-4)',
        instruction: 'Soffiare con aria compressa deumidificata ed eseguire test del nastro per contaminazione polvere (ISO 8502-3, Classe max 1). Rilevare temperatura aria, umidità relativa e verificare che la temperatura della superficie sia di almeno 3°C superiore al punto di rugiada.',
        photoUrl: imgMaintenance,
        photoCaption: 'Rilievo condizioni climatiche con termoigrometro a contatto e verifica delta rugiada',
        photoTag: 'Controllo Qualità',
        safetyNotice: 'Non applicare mai se il delta termico è inferiore a 3°C.'
      },
      {
        id: 's-4',
        stepNumber: 4,
        title: 'Applicazione a Spruzzo Airless Strato Primer ad Alto Solido',
        instruction: 'Miscelare il componente A e il catalizzatore B con agitatore pneumatico per 3 minuti rispettando il tempo di induzione. Regolare la pompa airless a 180-200 bar, impiegare ugello 517/519 con passate incrociate al 50% di sormonto per ottenere 75 µm di film secco DFT.',
        photoUrl: imgPaintingAirless,
        photoCaption: 'Stesura uniforme a passate incrociate in cabina di verniciatura pressurizzata',
        photoTag: 'Verniciatura Airless',
        safetyNotice: 'Messa a terra obbligatoria per la pompa e la pistola airless.'
      }
    ],
    createdAt: '2026-10-18T10:00:00.000Z',
    updatedAt: '2026-10-18T16:00:00.000Z'
  }
];
