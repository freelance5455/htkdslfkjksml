import { AccessoryOption, DisciplineConfig, DisciplineId } from '../types/game';

export const DISCIPLINES: Record<DisciplineId, DisciplineConfig> = {
  chonk: {
    id: 'chonk',
    code: 'GWR-2025-ORB',
    title: 'Спринт Округлости',
    shortTitle: 'Спринт Округлости',
    guinnessCategory: 'Максимальный индекс сферической котости и объёма за 15 секунд',
    targetScore: 150,
    unit: 'КГ-Шар',
    previousHolder: 'Сэр Батончик IV (149.8 КГ-Шар)',
    previousLocation: 'Цюрих, Институт Круглых Котов',
    description:
      'За 15 секунд накормите Котость отборным лососем, сметанкой и царскими пельменями до состояния идеальной гравитационной сферы! Ловите пролетающую Золотую Царь-Рыбу для мега-бонуса.',
    controlsHint: 'Быстро кликайте по Котости / нажимайте ПРОБЕЛ + ловите Золотых Рыб!',
    accentColor: '#F59E0B',
    iconName: 'scale',
  },
  jump: {
    id: 'jump',
    code: 'GWR-2025-FLY',
    title: 'Мега-Прыжок Тыгыдык',
    shortTitle: 'Мега-Прыжок',
    guinnessCategory: 'Самый высокий вертикальный прыжок сферического кота с места',
    targetScore: 45,
    unit: 'Метров',
    previousHolder: 'Пан Пушистый Мяч (44.2 Метра)',
    previousLocation: 'Токио, Арена Летающих Хвостов',
    description:
      'Сожмите Котость как мощную пружину и отпустите на пике шкалы импульса! В полёте подруливайте влево и вправо, отталкиваясь от батутных облаков и золотых клубков до самой стратосферы!',
    controlsHint: 'Зажмите и отпустите ПРОБЕЛ/Клик в зелёной зоне → В полёте A/D или Курсор!',
    accentColor: '#10B981',
    iconName: 'rocket',
  },
  stack: {
    id: 'stack',
    code: 'GWR-2025-ZEN',
    title: 'Башня На Голове',
    shortTitle: 'Башня На Голове',
    guinnessCategory: 'Самая высокая башня предметов на абсолютно плоской макушке кота',
    targetScore: 12,
    unit: 'Предметов',
    previousHolder: 'Мастер Мурзик-Дзен (11 Предметов)',
    previousLocation: 'Лондон, Королевский Зал Баланса',
    description:
      'Складывайте башню из паштетов, сыра, самоваров и кубков прямо на невозмутимую макушку Котости! Сбрасывайте предметы точно по центру и удерживайте равновесие башни.',
    controlsHint: 'Клик / ПРОБЕЛ для сброса предмета • A/D или Стрелки для балансировки!',
    accentColor: '#E11D48',
    iconName: 'layers',
  },
};

export const DISCIPLINE_LIST: DisciplineConfig[] = [
  DISCIPLINES.chonk,
  DISCIPLINES.jump,
  DISCIPLINES.stack,
];

export const ACCESSORIES: AccessoryOption[] = [
  {
    id: 'none',
    name: 'Натуральная Котость',
    description: 'Эталонная природная круглость без лишних деталей',
    emoji: '🐱',
  },
  {
    id: 'crown',
    name: 'Корона Гиннесса',
    description: 'Чистое золото 999 пробы для монарха сферичности',
    emoji: '👑',
  },
  {
    id: 'headband',
    name: 'Повязка «ТЫГЫДЫК»',
    description: 'Аэродинамическая лента чемпиона по ночным забегам',
    emoji: '🎽',
  },
  {
    id: 'shades',
    name: 'Турбо-Очки',
    description: 'Скрывают шок в глазах при выходе на околоземную орбиту',
    emoji: '🕶️',
  },
  {
    id: 'bowtie',
    name: 'Золотая Бабочка',
    description: 'Официальный дресс-код гала-церемонии Книги Рекордов',
    emoji: '🎀',
  },
];

export const STACK_ITEMS_CATALOG = [
  { name: 'Банка элитного паштета «Мур-Делюкс»', color: '#F59E0B', shape: 'cylinder', height: 0.34, radius: 0.46 },
  { name: 'Головка альпийского сыра', color: '#FACC15', shape: 'cylinder', height: 0.36, radius: 0.48 },
  { name: 'Том «Книга Рекордов Гиннесса»', color: '#0284C7', shape: 'box', height: 0.28, radius: 0.50 },
  { name: 'Бабушкина банка сметаны 30%', color: '#FFFBF5', shape: 'cylinder', height: 0.38, radius: 0.42 },
  { name: 'Коробка царских креветок', color: '#FB7185', shape: 'box', height: 0.32, radius: 0.46 },
  { name: 'Золотая миска с лососем', color: '#E87A24', shape: 'cylinder', height: 0.30, radius: 0.45 },
  { name: 'Будильник «Тыгыдык в 4:30 утра»', color: '#EF4444', shape: 'cylinder', height: 0.36, radius: 0.40 },
  { name: 'Королевский полосатый арбуз', color: '#10B981', shape: 'sphere', height: 0.44, radius: 0.42 },
  { name: 'Тульский золотой самовар', color: '#D97706', shape: 'cylinder', height: 0.46, radius: 0.38 },
  { name: 'Хрустальный аквариум с карасём', color: '#38BDF8', shape: 'sphere', height: 0.42, radius: 0.41 },
  { name: 'Мини-статуэтка Котости из золота', color: '#FDE047', shape: 'sphere', height: 0.40, radius: 0.38 },
  { name: 'Гран-При Кубок Рекордов Гиннесса', color: '#F59E0B', shape: 'trophy', height: 0.52, radius: 0.40 },
  { name: 'Секретный Спутник Кото-НАСА', color: '#A855F7', shape: 'cylinder', height: 0.40, radius: 0.38 },
  { name: 'Платиновая Корона Императора Мяу', color: '#E2E8F0', shape: 'cylinder', height: 0.38, radius: 0.38 },
];

export const JUMP_ALTITUDE_LANDMARKS = [
  { height: 2, label: 'Комод в гостиной (2 м)' },
  { height: 5, label: 'Хрустальная люстра (5 м)' },
  { height: 10, label: 'Крыша пятиэтажки (10 м)' },
  { height: 18, label: 'Уровень удивлённых голубей (18 м)' },
  { height: 28, label: 'Кучевые облака (28 м)' },
  { height: 38, label: 'Вертолёт телеканала Гиннесса (38 м)' },
  { height: 45, label: '🏆 МИРОВОЙ РЕКОРД: Дирижабль Гиннесса (45 м)' },
  { height: 60, label: 'Стратосферный зонд (60 м)' },
  { height: 80, label: 'Орбита Кото-Спутника (80 м)' },
];

export const JUDGE_QUOTES = {
  recordBroken: [
    '«Я проверял штангенциркуль трижды — эта Котость нарушает законы евклидовой геометрии и физики!»',
    '«Комиссия в шоке: такая плотность пушистости и величие взгляда фиксируются впервые с 1955 года!»',
    '«Официально подтверждаю: более идеального шара с глазами человечество ещё не наблюдало!»',
  ],
  almostThere: [
    '«Невероятная округлость, но до мирового рекорда не хватило буквально пары пельменей!»',
    '«Судейская коллегия аплодирует стоя! Ещё одна попытка — и сертификат ваш!»',
  ],
};
