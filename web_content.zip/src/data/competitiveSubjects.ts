export interface CompetitiveSubject {
  id: string;
  nameBn: string;
  nameHi: string;
  nameEn: string;
  icon: string;
  color: string;
  category: 'general_studies' | 'science' | 'aptitude' | 'gk_current';
  totalQsHint: number;
  chapterHintBn: string;
  chapterHintEn: string;
  chapterHintHi: string;
}

export const COMPETITIVE_EXAM_SUBJECTS: CompetitiveSubject[] = [
  {
    id: 'General Knowledge',
    nameBn: 'সাধারণ জ্ঞান',
    nameHi: 'सामान्य ज्ञान',
    nameEn: 'General Knowledge',
    icon: '🌐',
    color: 'from-blue-600 to-indigo-600',
    category: 'general_studies',
    totalQsHint: 650,
    chapterHintBn: 'অধ্যায় ১: ভারতীয় সংবিধান ও গুরুত্বপূর্ণ তথ্য',
    chapterHintEn: 'Chapter 1: Indian Polity & Important Facts',
    chapterHintHi: 'अध्याय 1: भारतीय राजव्यवस्था व तथ्य'
  },
  {
    id: 'History',
    nameBn: 'ইতিহাস',
    nameHi: 'इतिहास',
    nameEn: 'History',
    icon: '📜',
    color: 'from-amber-600 to-orange-600',
    category: 'general_studies',
    totalQsHint: 540,
    chapterHintBn: 'অধ্যায় ১: সিন্ধু সভ্যতা ও স্বাধীনতা আন্দোলন',
    chapterHintEn: 'Chapter 1: Indus Valley & National Movement',
    chapterHintHi: 'अध्याय 1: सिंधु सभ्यता व स्वतंत्रता संग्राम'
  },
  {
    id: 'Geography',
    nameBn: 'ভূগোল',
    nameHi: 'भूगोल',
    nameEn: 'Geography',
    icon: '🗺️',
    color: 'from-emerald-600 to-teal-600',
    category: 'general_studies',
    totalQsHint: 510,
    chapterHintBn: 'অধ্যায় ১: ভারতের নদ-নদী, পর্বত ও জলবায়ু',
    chapterHintEn: 'Chapter 1: Indian Drainage, Mountains & Climate',
    chapterHintHi: 'अध्याय 1: भारत की नदियां व जलवायु'
  },
  {
    id: 'Indian Polity',
    nameBn: 'ভারতীয় রাজনীতি',
    nameHi: 'भारतीय राजनीति',
    nameEn: 'Indian Polity',
    icon: '🏛️',
    color: 'from-purple-600 to-indigo-600',
    category: 'general_studies',
    totalQsHint: 480,
    chapterHintBn: 'অধ্যায় ১: সংসদ, রাষ্ট্রপতি ও বিচারব্যবস্থা',
    chapterHintEn: 'Chapter 1: Parliament, President & Judiciary',
    chapterHintHi: 'अध्याय 1: संसद, राष्ट्रपति और न्यायपालिका'
  },
  {
    id: 'Indian Constitution',
    nameBn: 'ভারতীয় সংবিধান',
    nameHi: 'भारतीय संविधान',
    nameEn: 'Indian Constitution',
    icon: '⚖️',
    color: 'from-blue-700 to-sky-600',
    category: 'general_studies',
    totalQsHint: 490,
    chapterHintBn: 'অধ্যায় ১: মৌলিক অধিকার ও সংবিধানের ধারা',
    chapterHintEn: 'Chapter 1: Fundamental Rights, Preamble & Articles',
    chapterHintHi: 'अध्याय 1: मौलिक अधिकार व अनुच्छेद'
  },
  {
    id: 'Indian Economy',
    nameBn: 'ভারতীয় অর্থনীতি',
    nameHi: 'भारतीय अर्थव्यवस्था',
    nameEn: 'Indian Economy',
    icon: '📈',
    color: 'from-emerald-600 to-green-600',
    category: 'general_studies',
    totalQsHint: 420,
    chapterHintBn: 'অধ্যায় ১: জিডিপি, মুদ্রাস্ফীতি ও পঞ্চবার্ষিকী পরিকল্পনা',
    chapterHintEn: 'Chapter 1: GDP, RBI Banking & Five Year Plans',
    chapterHintHi: 'अध्याय 1: जीडीपी, आरबीआई व योजनाएं'
  },
  {
    id: 'General Science',
    nameBn: 'সাধারণ বিজ্ঞান',
    nameHi: 'सामान्य विज्ञान',
    nameEn: 'General Science',
    icon: '🔬',
    color: 'from-cyan-600 to-blue-600',
    category: 'science',
    totalQsHint: 580,
    chapterHintBn: 'অধ্যায় ১: গতি, শক্তি, আলো ও মানব শারীরবিদ্যা',
    chapterHintEn: 'Chapter 1: Mechanics, Light & Human Physiology',
    chapterHintHi: 'अध्याय 1: यांत्रिकी, प्रकाश व मानव शरीर'
  },
  {
    id: 'Physics',
    nameBn: 'পদার্থবিজ্ঞান',
    nameHi: 'भौतिक विज्ञान',
    nameEn: 'Physics',
    icon: '⚡',
    color: 'from-violet-600 to-purple-600',
    category: 'science',
    totalQsHint: 460,
    chapterHintBn: 'অধ্যায় ১: বল, গতি, কার্য, শক্তি ও আলোকবিজ্ঞান',
    chapterHintEn: 'Chapter 1: Motion, Force, Energy & Optics',
    chapterHintHi: 'अध्याय 1: गति, बल, ऊर्जा व प्रकाशिकी'
  },
  {
    id: 'Chemistry',
    nameBn: 'রসায়নবিজ্ঞান',
    nameHi: 'रसायन विज्ञान',
    nameEn: 'Chemistry',
    icon: '🧪',
    color: 'from-pink-600 to-rose-600',
    category: 'science',
    totalQsHint: 430,
    chapterHintBn: 'অধ্যায় ১: পরমাণুর গঠন, অ্যাসিড, ক্ষার ও পর্যায় সারণি',
    chapterHintEn: 'Chapter 1: Periodic Table, Acids, Bases & Metals',
    chapterHintHi: 'अध्याय 1: आवर्त सारणी, अम्ल व क्षार'
  },
  {
    id: 'Biology',
    nameBn: 'জীববিজ্ঞান',
    nameHi: 'जीव विज्ञान',
    nameEn: 'Biology',
    icon: '🧬',
    color: 'from-green-600 to-emerald-600',
    category: 'science',
    totalQsHint: 520,
    chapterHintBn: 'অধ্যায় ১: কোষবিদ্যা, বংশগতি, রক্ত সংবহন ও ভিটামিন',
    chapterHintEn: 'Chapter 1: Cytology, Genetics, Blood & Nutrition',
    chapterHintHi: 'अध्याय 1: कोशिका, रक्त परिसंचरण व पोषण'
  },
  {
    id: 'Mathematics',
    nameBn: 'গণিত',
    nameHi: 'गणित',
    nameEn: 'Mathematics',
    icon: '📐',
    color: 'from-indigo-600 to-blue-600',
    category: 'aptitude',
    totalQsHint: 680,
    chapterHintBn: 'অধ্যায় ১: শতকরা, অনুপাত, লাভ-ক্ষতি ও পরিমিতি',
    chapterHintEn: 'Chapter 1: Percentage, Ratio, Profit & Loss, Mensuration',
    chapterHintHi: 'अध्याय 1: प्रतिशत, अनुपात व लाभ-हानि'
  },
  {
    id: 'Reasoning',
    nameBn: 'জিআই / রিজনিং',
    nameHi: 'तर्कशक्ति',
    nameEn: 'Reasoning',
    icon: '🧠',
    color: 'from-fuchsia-600 to-pink-600',
    category: 'aptitude',
    totalQsHint: 620,
    chapterHintBn: 'অধ্যায় ১: কোডিং-ডিকোডিং, রক্ত সম্পর্ক ও দিকনির্ণয়',
    chapterHintEn: 'Chapter 1: Coding-Decoding, Blood Relations & Series',
    chapterHintHi: 'अध्याय 1: कोडिंग-डिकोडिंग व रक्त संबंध'
  },
  {
    id: 'General Awareness',
    nameBn: 'সাধারণ সচেতনতা',
    nameHi: 'सामान्य जागरूकता',
    nameEn: 'General Awareness',
    icon: '🔔',
    color: 'from-sky-600 to-blue-600',
    category: 'gk_current',
    totalQsHint: 470,
    chapterHintBn: 'অধ্যায় ১: আন্তর্জাতিক সংস্থা, সদর দপ্তর ও মুদ্রা',
    chapterHintEn: 'Chapter 1: International Organizations & Capitals',
    chapterHintHi: 'अध्याय 1: अंतर्राष्ट्रीय संगठन व राजधानियां'
  },
  {
    id: 'Current Affairs',
    nameBn: 'সাম্প্রতিক ঘটনাবলী',
    nameHi: 'समसामयिकी',
    nameEn: 'Current Affairs',
    icon: '📰',
    color: 'from-rose-600 to-red-600',
    category: 'gk_current',
    totalQsHint: 530,
    chapterHintBn: 'অধ্যায় ১: জাতীয় ও আন্তর্জাতিক সাম্প্রতিক ঘটনাবলী',
    chapterHintEn: 'Chapter 1: National & International Summits, Awards',
    chapterHintHi: 'अध्याय 1: राष्ट्रीय व अंतर्राष्ट्रीय घटनाएं'
  },
  {
    id: 'Computer',
    nameBn: 'কম্পিউটার জ্ঞান',
    nameHi: 'कंप्यूटर ज्ञान',
    nameEn: 'Computer Knowledge',
    icon: '💻',
    color: 'from-slate-600 to-gray-700',
    category: 'science',
    totalQsHint: 390,
    chapterHintBn: 'অধ্যায় ১: হার্ডওয়্যার, শর্টকাট কি, ইন্টারনেট ও এমএস অফিস',
    chapterHintEn: 'Chapter 1: Hardware, Shortcuts, Networking & Office',
    chapterHintHi: 'अध्याय 1: हार्डवेयर, शॉर्टकट व इंटरनेट'
  },
  {
    id: 'Environment',
    nameBn: 'পরিবেশবিদ্যা',
    nameHi: 'पर्यावरण अध्ययन',
    nameEn: 'Environment & Ecology',
    icon: '🌿',
    color: 'from-teal-600 to-emerald-600',
    category: 'general_studies',
    totalQsHint: 410,
    chapterHintBn: 'অধ্যায় ১: বাস্তুতন্ত্র, জীববৈচিত্র্য, দূষণ ও পরিবেশ আইন',
    chapterHintEn: 'Chapter 1: Ecosystem, Biodiversity, Pollution & Acts',
    chapterHintHi: 'अध्याय 1: पारिस्थितिकी तंत्र, प्रदूषण व जैव विविधता'
  },
  {
    id: 'Indian Culture',
    nameBn: 'ভারতীয় সংস্কৃতি',
    nameHi: 'भारतीय संस्कृति',
    nameEn: 'Indian Culture & Heritage',
    icon: '🛕',
    color: 'from-amber-600 to-yellow-600',
    category: 'general_studies',
    totalQsHint: 380,
    chapterHintBn: 'অধ্যায় ১: ধ্রুপদী নৃত্য, বাদ্যযন্ত্র, মেলা ও স্থাপত্যশিল্প',
    chapterHintEn: 'Chapter 1: Classical Dance, Music Instruments & Fairs',
    chapterHintHi: 'अध्याय 1: शास्त्रीय नृत्य, संगीत व वाद्ययंत्र'
  },
  {
    id: 'Sports',
    nameBn: 'ক্রীড়া সংবাদ ও জ্ঞান',
    nameHi: 'खेल कूद',
    nameEn: 'Sports & Games',
    icon: '⚽',
    color: 'from-orange-600 to-amber-600',
    category: 'gk_current',
    totalQsHint: 360,
    chapterHintBn: 'অধ্যায় ১: অলিম্পিক, ক্রিকেট বিশ্বকাপ ও ট্রফি পরিভাষা',
    chapterHintEn: 'Chapter 1: Olympics, Cups, Trophies & Stadiums',
    chapterHintHi: 'अध्याय 1: ओलंपिक, कप, ट्रॉफी व शब्दावली'
  },
  {
    id: 'Government Schemes',
    nameBn: 'সরকারি প্রকল্প',
    nameHi: 'सरकारी योजनाएं',
    nameEn: 'Government Schemes',
    icon: '📋',
    color: 'from-blue-600 to-cyan-600',
    category: 'gk_current',
    totalQsHint: 410,
    chapterHintBn: 'অধ্যায় ১: কেন্দ্রীয় ও রাজ্য সরকারের গুরুত্বপূর্ণ প্রকল্প',
    chapterHintEn: 'Chapter 1: Major Central & State Welfare Schemes',
    chapterHintHi: 'अध्याय 1: केंद्र व राज्य सरकार की योजनाएं'
  },
  {
    id: 'Railway GK',
    nameBn: 'রেলওয়ে জিকে',
    nameHi: 'रेलवे जीके',
    nameEn: 'Railway GK',
    icon: '🚂',
    color: 'from-red-600 to-orange-600',
    category: 'gk_current',
    totalQsHint: 450,
    chapterHintBn: 'অধ্যায় ১: ভারতীয় রেলের ইতিহাস, জোন ও প্রযুক্তি',
    chapterHintEn: 'Chapter 1: History of Indian Railways, Zones & Tech',
    chapterHintHi: 'अध्याय 1: भारतीय रेल इतिहास, ज़ोन व ट्रैक'
  },
  {
    id: 'Static GK',
    nameBn: 'স্ট্যাটিক জিকে',
    nameHi: 'स्टेटिक जीके',
    nameEn: 'Static GK',
    icon: '📍',
    color: 'from-violet-600 to-indigo-600',
    category: 'gk_current',
    totalQsHint: 590,
    chapterHintBn: 'অধ্যায় ১: ভারতের দীর্ঘতম, উচ্চতম, প্রথম পুরুষ ও মহিলা',
    chapterHintEn: 'Chapter 1: First in India, Highest, Longest & Monuments',
    chapterHintHi: 'अध्याय 1: भारत में प्रथम, सबसे लंबा व ऊँचा'
  }
];
