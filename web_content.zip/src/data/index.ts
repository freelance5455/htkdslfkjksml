import type { ClassLevel, Formula, Subject } from "./types";
import { class8Formulas, class8Math, class8Physics, class8Chemistry } from "./class8";
import { class9Formulas, class9Math, class9Physics, class9Chemistry } from "./class9";
import { class10Formulas, class10Math, class10Physics, class10Chemistry } from "./class10";

export * from "./types";

export const allFormulas: Formula[] = [...class8Formulas, ...class9Formulas, ...class10Formulas];

export const formulasByClass: Record<ClassLevel, Formula[]> = {
  8: class8Formulas,
  9: class9Formulas,
  10: class10Formulas,
};

export const formulasByClassSubject: Record<ClassLevel, Record<Subject, Formula[]>> = {
  8: { Mathematics: class8Math, Physics: class8Physics, Chemistry: class8Chemistry },
  9: { Mathematics: class9Math, Physics: class9Physics, Chemistry: class9Chemistry },
  10: { Mathematics: class10Math, Physics: class10Physics, Chemistry: class10Chemistry },
};

export function getFormulaById(id: string): Formula | undefined {
  return allFormulas.find((f) => f.id === id);
}

export function getChaptersFor(classLevel: ClassLevel, subject: Subject): string[] {
  const list = formulasByClassSubject[classLevel][subject];
  const chapters: string[] = [];
  list.forEach((f) => {
    if (!chapters.includes(f.chapter)) chapters.push(f.chapter);
  });
  return chapters;
}

export function getTopicsFor(classLevel: ClassLevel, subject: Subject, chapter: string): string[] {
  const list = formulasByClassSubject[classLevel][subject].filter((f) => f.chapter === chapter);
  const topics: string[] = [];
  list.forEach((f) => {
    if (!topics.includes(f.topic)) topics.push(f.topic);
  });
  return topics;
}

function simplify(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\b(introduction|to|the|of|and|a|some|applications|chapter)\b/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/** Fuzzy-matches a syllabus master-list chapter name (e.g. "Introduction to
 *  Trigonometry") against the interactive Formula library's own chapter
 *  names for the same class/subject (e.g. "Introduction to Trigonometry" or
 *  "Triangles"), so a syllabus chapter can surface the matching interactive
 *  formulas without requiring every formula to be re-tagged by hand. Falls
 *  back to no matches (never guesses wildly) when names are unrelated. */
export function getFormulasForSyllabusChapter(classLevel: ClassLevel, subject: Subject, chapterName: string): Formula[] {
  const list = formulasByClassSubject[classLevel][subject];
  const target = simplify(chapterName);
  if (!target) return [];
  return list.filter((f) => {
    const a = simplify(f.chapter);
    const b = simplify(f.topic);
    return a === target || a.includes(target) || target.includes(a) || b.includes(target) || target.includes(b);
  });
}

function normalize(s: string): string {
  return s.toLowerCase().trim();
}

export function searchFormulas(query: string): Formula[] {
  const q = normalize(query);
  if (!q) return [];
  const terms = q.split(/\s+/).filter(Boolean);

  const scored = allFormulas
    .map((f) => {
      const haystacks = [
        f.name,
        f.chapter,
        f.topic,
        f.expression,
        f.explanation,
        f.subject,
        `class ${f.classLevel}`,
        ...(f.tags ?? []),
        ...f.variables.map((v) => `${v.symbol} ${v.meaning}`),
      ]
        .join(" ")
        .toLowerCase();

      let score = 0;
      for (const term of terms) {
        if (!haystacks.includes(term)) {
          score = -1;
          break;
        }
        if (normalize(f.name).includes(term)) score += 5;
        if (f.tags?.some((t) => normalize(t) === term)) score += 4;
        if (normalize(f.topic).includes(term)) score += 3;
        if (normalize(f.chapter).includes(term)) score += 1;
        score += 1;
      }
      return { f, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored.map((x) => x.f);
}
