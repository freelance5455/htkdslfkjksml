import { SurahDetail } from '../types';

export const BUILT_IN_SURAHS: Record<number, SurahDetail> = {
  1: {
    number: 1,
    name: "الفَاتِحَة",
    englishName: "Al-Faatiha",
    revelationType: "Meccan",
    numberOfAyahs: 7,
    startJuz: 1,
    page: 1,
    bismillahPre: false,
    ayahs: [
      {
        number: 1,
        numberInSurah: 1,
        text: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
        juz: 1,
        page: 1,
        tafseer: "أبتدئ قراءتي باسم الله مستعينا به، (الله) علم على الرب تبارك وتعالى، (الرحمن) ذو الرحمة الواسعة، (الرحيم) الموصل رحمته لمن يشاء من عباده."
      },
      {
        number: 2,
        numberInSurah: 2,
        text: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
        juz: 1,
        page: 1,
        tafseer: "الثناء الكامل والشكر لله تعالى خالق الخلق ومالكهم ومدبر أمورهم ومربيهم بنعمه."
      },
      {
        number: 3,
        numberInSurah: 3,
        text: "الرَّحْمَٰنِ الرَّحِيمِ",
        juz: 1,
        page: 1,
        tafseer: "الرحمن الذي وسعت رحمته كل شيء، والرحيم بالمؤمنين خاصة."
      },
      {
        number: 4,
        numberInSurah: 4,
        text: "مَالِكِ يَوْمِ الدِّينِ",
        juz: 1,
        page: 1,
        tafseer: "المالك المتصرف وحده في يوم الجزاء والحساب وهو يوم القيامة."
      },
      {
        number: 5,
        numberInSurah: 5,
        text: "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
        juz: 1,
        page: 1,
        tafseer: "نخصك وحدك بالعبادة والطاعة، ونستعين بك وحدك في جميع شؤوننا وأمورنا."
      },
      {
        number: 6,
        numberInSurah: 6,
        text: "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
        juz: 1,
        page: 1,
        tafseer: "دلنا وأرشدنا ووفقنا وثبتنا على الطريق الواضح الموصل إليك وإلى جناتك وهو الإسلام."
      },
      {
        number: 7,
        numberInSurah: 7,
        text: "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",
        juz: 1,
        page: 1,
        tafseer: "طريق النبيين والصديقين والشهداء والصالحين، غير طريق المغضوب عليهم (كاليهود) ولا التائهين الضالين (كالنصارى)."
      }
    ]
  },
  112: {
    number: 112,
    name: "الإِخْلَاص",
    englishName: "Al-Ikhlaas",
    revelationType: "Meccan",
    numberOfAyahs: 4,
    startJuz: 30,
    page: 604,
    bismillahPre: true,
    ayahs: [
      {
        number: 6222,
        numberInSurah: 1,
        text: "قُلْ هُوَ اللَّهُ أَحَدٌ",
        juz: 30,
        page: 604,
        tafseer: "قل أيها الرسول: هو الله المنفرد بالألوهية والربوبية والأسماء والصفات، لا شريك له."
      },
      {
        number: 6223,
        numberInSurah: 2,
        text: "اللَّهُ الصَّمَدُ",
        juz: 30,
        page: 604,
        tafseer: "السيد الكامل الذي تصمد وتلجأ إليه جميع الخلائق في حوائجها ورغائبها."
      },
      {
        number: 6224,
        numberInSurah: 3,
        text: "لَمْ يَلِدْ وَلَمْ يُولَدْ",
        juz: 30,
        page: 604,
        tafseer: "تنزه سبحانه عن الولد والوالد، فليس له ولد ولا والد ولا مثيل."
      },
      {
        number: 6225,
        numberInSurah: 4,
        text: "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ",
        juz: 30,
        page: 604,
        tafseer: "ولم يكن له مكافئ ولا مماثل ولا نظير في ذاته أو صفاته أو أفعاله."
      }
    ]
  },
  113: {
    number: 113,
    name: "الفَلَق",
    englishName: "Al-Falaq",
    revelationType: "Meccan",
    numberOfAyahs: 5,
    startJuz: 30,
    page: 604,
    bismillahPre: true,
    ayahs: [
      {
        number: 6226,
        numberInSurah: 1,
        text: "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ",
        juz: 30,
        page: 604,
        tafseer: "قل: أعتصم وألتجئ برب الصبح وفالقه."
      },
      {
        number: 6227,
        numberInSurah: 2,
        text: "مِن شَرِّ مَا خَلَقَ",
        juz: 30,
        page: 604,
        tafseer: "من شر جميع المخلوقات وأذاها."
      },
      {
        number: 6228,
        numberInSurah: 3,
        text: "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ",
        juz: 30,
        page: 604,
        tafseer: "ومن شر ليل مظلم شديد الظلمة إذا دخل وانتشر وما يخرج فيه من شرور."
      },
      {
        number: 6229,
        numberInSurah: 4,
        text: "وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ",
        juz: 30,
        page: 604,
        tafseer: "ومن شر السواحر اللاتي ينفثن في عقد الخيوط لإيقاع السحر."
      },
      {
        number: 6230,
        numberInSurah: 5,
        text: "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ",
        juz: 30,
        page: 604,
        tafseer: "ومن شر باغض للنعمة يتمنى زوالها عن صاحبها إذا أظهر حسده وسعى في ذلك."
      }
    ]
  },
  114: {
    number: 114,
    name: "النَّاس",
    englishName: "An-Naas",
    revelationType: "Meccan",
    numberOfAyahs: 6,
    startJuz: 30,
    page: 604,
    bismillahPre: true,
    ayahs: [
      {
        number: 6231,
        numberInSurah: 1,
        text: "قُلْ أَعُوذُ بِرَبِّ النَّاسِ",
        juz: 30,
        page: 604,
        tafseer: "قل أعتصم وأتحصن برب البشر وخالقهم ومدبر أحوالهم."
      },
      {
        number: 6232,
        numberInSurah: 2,
        text: "مَلِكِ النَّاسِ",
        juz: 30,
        page: 604,
        tafseer: "مالك الناس المتصرف في شؤونهم وسلطانهم الحق."
      },
      {
        number: 6233,
        numberInSurah: 3,
        text: "إِلَٰهِ النَّاسِ",
        juz: 30,
        page: 604,
        tafseer: "معبودهم الحق الذي لا معبود سواه."
      },
      {
        number: 6234,
        numberInSurah: 4,
        text: "مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ",
        juz: 30,
        page: 604,
        tafseer: "من شر الشيطان الموسوس الذي يختفي ويخنس إذا ذُكر الله تعالى."
      },
      {
        number: 6235,
        numberInSurah: 5,
        text: "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ",
        juz: 30,
        page: 604,
        tafseer: "الذي يبث الشر والشكوك والأوهام في قلوب بني آدم."
      },
      {
        number: 6236,
        numberInSurah: 6,
        text: "مِنَ الْجِنَّةِ وَالنَّاسِ",
        juz: 30,
        page: 604,
        tafseer: "من شياطين الإنس والجن على حد سواء."
      }
    ]
  },
  108: {
    number: 108,
    name: "الكَوْثَر",
    englishName: "Al-Kawthar",
    revelationType: "Meccan",
    numberOfAyahs: 3,
    startJuz: 30,
    page: 602,
    bismillahPre: true,
    ayahs: [
      {
        number: 6197,
        numberInSurah: 1,
        text: "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ",
        juz: 30,
        page: 602,
        tafseer: "إنا أعطيناك أيها النبي الخير الكثير في الدنيا والآخرة، ومنه نهر الكوثر العظيم في الجنة."
      },
      {
        number: 6198,
        numberInSurah: 2,
        text: "فَصَلِّ لِرَبِّكَ وَانْحَرْ",
        juz: 30,
        page: 602,
        tafseer: "فأخلص لربك صلاتك كلها واذبح ذبيحتك له وحده شكراً له على ما أولاك."
      },
      {
        number: 6199,
        numberInSurah: 3,
        text: "إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ",
        juz: 30,
        page: 602,
        tafseer: "إن مبغضك وعدوك هو المنقطع أثره، المقطوع من كل خير."
      }
    ]
  },
  103: {
    number: 103,
    name: "العَصْر",
    englishName: "Al-Asr",
    revelationType: "Meccan",
    numberOfAyahs: 3,
    startJuz: 30,
    page: 601,
    bismillahPre: true,
    ayahs: [
      {
        number: 6177,
        numberInSurah: 1,
        text: "وَالْعَصْرِ",
        juz: 30,
        page: 601,
        tafseer: "أقسم الله تعالى بالدهر والزمان لما فيه من العبر والدلائل على قدرته."
      },
      {
        number: 6178,
        numberInSurah: 2,
        text: "إِنَّ الْإِنسَانَ لَفِي خُسْرٍ",
        juz: 30,
        page: 601,
        tafseer: "إن كل إنسان في خسارة وهلاك ونقصان في تجارته وسعيه."
      },
      {
        number: 6179,
        numberInSurah: 3,
        text: "إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ",
        juz: 30,
        page: 601,
        tafseer: "إلا الذين جمعوا بين الإيمان بالله والعمل الصالح، وتواصوا بالتمسك بالحق والصبر على طاعة الله ومصائبه."
      }
    ]
  },
  110: {
    number: 110,
    name: "النَّصْر",
    englishName: "An-Nasr",
    revelationType: "Medinan",
    numberOfAyahs: 3,
    startJuz: 30,
    page: 603,
    bismillahPre: true,
    ayahs: [
      {
        number: 6214,
        numberInSurah: 1,
        text: "إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ",
        juz: 30,
        page: 603,
        tafseer: "إذا تم لك نصر الله لدينك وأعزك وفتح عليك مكة."
      },
      {
        number: 6215,
        numberInSurah: 2,
        text: "وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْوَاجًا",
        juz: 30,
        page: 603,
        tafseer: "ورأيت الناس يقبلون على الإسلام ويدخلون فيه جماعات جماعات."
      },
      {
        number: 6216,
        numberInSurah: 3,
        text: "فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ ۚ إِنَّهُ كَانَ تَوَّابًا",
        juz: 30,
        page: 603,
        tafseer: "فاستقبل نعمة الله بالتسبيح بحمده والثناء عليه وسؤاله المغفرة، إنه كان تواباً على من تاب."
      }
    ]
  }
};
