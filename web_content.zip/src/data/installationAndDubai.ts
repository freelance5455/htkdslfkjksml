import { BiText } from './types';

export interface FixtureRoughIn {
  id: string;
  fixture: BiText;
  waterSupplyHeight: string;
  drainHeight: string;
  centerDistance: string;
  pipeSizes: string;
  steps: BiText[];
}

export interface DubaiStandard {
  id: string;
  authority: string;
  title: BiText;
  spec: BiText;
  siteRule: BiText;
}

export interface DailySiteBriefing {
  phase: string;
  title: BiText;
  morningInstruction: BiText;
  checkBeforeLeaving: BiText;
}

export interface BuildingPhase {
  step: number;
  title: BiText;
  scope: BiText;
  materials: string;
  inspectionGate: BiText;
}

export interface ToolItem {
  id: string;
  name: string;
  hindiName: string;
  photo: string;
  purpose: BiText;
  careTip: BiText;
}

export interface SafetyRule {
  id: string;
  title: BiText;
  hazardLevel: 'High' | 'Mandatory PPE';
  rule: BiText;
  emergencyAction: BiText;
}

export interface TroubleshootingItem {
  id: string;
  issue: BiText;
  cause: BiText;
  detectionMethod: BiText;
  fixSteps: BiText[];
}

export interface PumpTankGuide {
  id: string;
  title: BiText;
  specs: string;
  explanation: BiText;
  checklist: BiText[];
}

export interface VideoLesson {
  id: string;
  title: BiText;
  duration: string;
  thumbnail: string;
  category: string;
  frames: {
    stepNumber: number;
    caption: BiText;
    technicalNote: string;
    calloutX: number;
    calloutY: number;
  }[];
}

export interface SectorComparison {
  sector: BiText;
  pipeSpecs: string;
  pressure: string;
  keySystems: BiText;
}

export const FIXTURE_ROUGH_INS: FixtureRoughIn[] = [
  {
    id: 'wc-floor',
    fixture: { en: 'Western WC (Floor-Mounted & Concealed Cistern)', hi: 'वेस्टर्न टॉयलेट (फ्लोर व कंसील्ड सिस्टर्न)' },
    waterSupplyHeight: '250–300 mm FFL (Left) / 1120 mm Frame',
    drainHeight: 'Center 300 mm from wall (Floor) or 180 mm (Wall-hung)',
    centerDistance: 'Shattaf (Bidet Spray): 550 mm FFL on Right',
    pipeSizes: '110 mm Soil · 20 mm Cold PPR',
    steps: [
      {
        en: 'Confirm Finished Floor Level (FFL) datum mark from the mason before fixing concealed cistern steel legs.',
        hi: 'फ्रेम फिट करने से पहले राजमिस्त्री से फाइनल फ्लोर लेवल (FFL) का निशान जरूर कन्फर्म करें।',
      },
      {
        en: 'Align 110mm WC outlet center dead-square to the wall and anchor the frame with M10 heavy anchor bolts.',
        hi: '110mm टॉयलेट आउटलेट को दीवार से सीधा 90° रखें और M10 एंकर बोल्ट से फ्रेम पक्का कसें।',
      },
      {
        en: 'Install 1/2" Shattaf (Muslim shower) angle valve point on the right-hand side at 550mm from FFL.',
        hi: 'दाहिनी तरफ (Right) जमीन से 550mm ऊंचाई पर 1/2" शत्ताफ (जेट स्प्रे) का पॉइंट दें।',
      },
    ],
  },
  {
    id: 'wash-basin',
    fixture: { en: 'Wash Basin (Countertop / Wall-Hung)', hi: 'वॉश बेसिन (काउंटर / वॉल-हंग)' },
    waterSupplyHeight: '550 mm FFL (Hot Left · Cold Right)',
    drainHeight: '500 mm FFL (Center between H & C)',
    centerDistance: '100–150 mm between Hot & Cold · Rim at 800–850 mm',
    pipeSizes: '40 mm Waste · 15–20 mm Supply',
    steps: [
      {
        en: 'Center the 40mm waste outlet between the hot (left) and cold (right) angle valve points.',
        hi: '40mm ड्रेन पॉइंट को गर्म (बाएं) और ठंडे (दाएं) एंगल वॉल्व के ठीक बीच में रखें।',
      },
      {
        en: 'Keep angle valves at 550mm height and basin rim at 800–850mm above finished tiles.',
        hi: 'एंगल वॉल्व की ऊंचाई 550mm और बेसिन के ऊपरी किनारे की ऊंचाई 800–850mm रखें।',
      },
      {
        en: 'Connect flexible braided hoses and a 40mm Bottle Trap or P-Trap; seal basin perimeter with anti-fungal silicone.',
        hi: 'फ्लेक्सिबल पाइप और बॉटल ट्रैप जोड़कर दीवार के किनारे पर एंटी-फंगल सिलिकॉन लगाएं।',
      },
    ],
  },
  {
    id: 'shower-mixer',
    fixture: { en: 'Shower Mixer & Overhead Rain Shower', hi: 'शावर मिक्सर और ओवरहेड शावर' },
    waterSupplyHeight: 'Mixer: 1050–1100 mm FFL · Shower Head: 2100 mm FFL',
    drainHeight: 'Floor Trap / Linear Shower Channel (50 mm)',
    centerDistance: '150 mm Exact Center-to-Center (Hot Left, Cold Right)',
    pipeSizes: '20 mm PPR Supply · 50 mm Waste',
    steps: [
      {
        en: 'Use a spirit level and a 150mm jig/bracket so hot and cold brass wall elbows sit completely level.',
        hi: 'स्पिरिट लेवल से गर्म और ठंडे ब्रास एल्बो को ठीक 150mm की दूरी पर और बिल्कुल सीधा फिक्स करें।',
      },
      {
        en: 'Verify concealed brass elbow faces sit flush with the finished tile thickness (account for 15–20mm plaster + tile).',
        hi: 'ब्रास एल्बो का मुंह प्लास्टर और टाइल की मोटाई (15–20mm) के बराबर बाहर होना चाहिए।',
      },
      {
        en: 'Run the overhead shower riser at 2100mm height and install a dedicated floor trap/channel inside the shower zone.',
        hi: 'ऊपर वाले शावर का पॉइंट 2100mm पर दें और नहाने के एरिया में 50mm फ्लोर ट्रैप लगाएं।',
      },
    ],
  },
  {
    id: 'kitchen-sink',
    fixture: { en: 'Kitchen Sink, Dishwasher & Water Filter', hi: 'किचन सिंक, डिशवॉशर और वाटर फिल्टर' },
    waterSupplyHeight: '450–500 mm FFL (Under Counter) · Wall Bib: 1100 mm',
    drainHeight: '400–450 mm FFL (50 mm uPVC)',
    centerDistance: 'Provide extra Cold Tee for RO / Drinking Filter & Dishwasher',
    pipeSizes: '50 mm Waste · 20 mm Supply',
    steps: [
      {
        en: 'Always use a 50mm uPVC drain line (not 40mm) for kitchen sinks to reduce cooking-grease blockages.',
        hi: 'किचन सिंक में चिकनाई व कचरे से जाम बचने के लिए हमेशा 50mm ड्रेन पाइप लगाएं।',
      },
      {
        en: 'Provide an extra 1/2" cold angle valve with a washing-machine/dishwasher Y-branch at 450mm height.',
        hi: 'RO फिल्टर और डिशवॉशर के लिए सिंक के नीचे एक अतिरिक्त 1/2" ठंडे पानी का एंगल वॉल्व जरूर दें।',
      },
      {
        en: 'Install a P-trap with a cleanout cap and slope the drain cleanly to the kitchen gully or grease trap.',
        hi: 'सफाई वाले कैप के साथ P-Trap लगाएं और पाइप को सही ढलान के साथ ग्रीस ट्रैप या गली ट्रैप से जोड़ें।',
      },
    ],
  },
];

export const DUBAI_STANDARDS: DubaiStandard[] = [
  {
    id: 'dewa-water',
    authority: 'DEWA / Dubai Municipality',
    title: {
      en: 'PPR Color Coding, Insulation & 10 Bar Hydrostatic Test',
      hi: 'PPR कलर कोड, इंसुलेशन और 10 Bar प्रेशर टेस्ट',
    },
    spec: {
      en: 'Test all water supply lines at 1.5× working pressure (minimum 10 Bar / 150 PSI) for 2–4 hours with consultant witness.',
      hi: 'टाइल लगने से पहले सभी पानी की लाइनों का 10 Bar (150 PSI) पर 2 से 4 घंटे तक कंसल्टेंट के सामने प्रेशर टेस्ट पास करना अनिवार्य है।',
    },
    siteRule: {
      en: 'Insulate all hot water lines and exposed roof cold lines with 13–19mm closed-cell elastomeric foam (Armaflex) + UV cladding.',
      hi: 'छत के सभी ठंडे और दीवार के अंदर गर्म पाइपों पर 13–19mm फोम इंसुलेशन और छत पर एल्यूमिनियम क्लैडिंग लगाना जरूरी है।',
    },
  },
  {
    id: 'dm-drainage',
    authority: 'Dubai Municipality (DM Code)',
    title: {
      en: 'Two-Pipe Drainage, Multi-Inlet Floor Trap & Y-Branches',
      hi: 'टू-पाइप ड्रेनेज, फ्लोर ट्रैप और 45° वाई-ब्रांच',
    },
    spec: {
      en: 'Separate Soil (110mm WC) and Waste (50/75mm) stacks. Every branch connection uses 45° Wye fittings; cleanouts required at every stack base and bend.',
      hi: 'टॉयलेट (110mm Soil) और बाथरूम वेस्ट (50/75mm) अलग रखे जाते हैं। हर जोड़ पर 45° Wye टी और नीचे क्लीनआउट प्लग देना अनिवार्य है।',
    },
    siteRule: {
      en: 'Water-fill test gravity drainage for 30 minutes (minimum 1.5m water head) and run a steel ball test through 110mm underground drains.',
      hi: 'ड्रेनेज पाइप में पानी भरकर 30 मिनट लीक टेस्ट और 110mm जमीन के नीचे की लाइन में बॉल टेस्ट किया जाता है।',
    },
  },
  {
    id: 'mep-coordination',
    authority: 'Dubai MEP Site Practice',
    title: {
      en: 'Slab Sleeves, MEP Coordination & Concealed Cisterns',
      hi: 'स्लैब स्लीव, MEP ड्रॉइंग और कंसील्ड टॉयलेट फ्रेम',
    },
    spec: {
      en: 'Place uPVC puddle flange sleeves before concrete slab pouring; seal gaps around penetrations with fire-stop sealant.',
      hi: 'छत की ढलाई से पहले ही पाइप के लिए स्लीव (Sleeve) लगाना और बाद में फायर-स्टॉप सीलेंट से सील करना जरूरी है।',
    },
    siteRule: {
      en: 'Always submit an IR (Inspection Request) with pressure gauge photo and signed checklist before wall closing.',
      hi: 'दीवार बंद करने या प्लास्टर से पहले प्रेशर गेज की फोटो के साथ IR (Inspection Request) पास करवाना जरूरी होता है।',
    },
  },
];

export const DAILY_SITE_INSTRUCTIONS: DailySiteBriefing[] = [
  {
    phase: '07:00 AM · Toolbox Talk',
    title: {
      en: 'Morning Safety & Drawing Check',
      hi: 'सुबह की सेफ्टी और ड्रॉइंग चेकिंग',
    },
    morningInstruction: {
      en: 'Wear helmet, safety shoes, goggles, and gloves. Check today’s approved IFC drawing revision and verify FFL (Finished Floor Level) marks on site.',
      hi: 'हेलमेट, सेफ्टी शूज, चश्मा और दस्ताने पहनें। आज की अप्रूव्ड ड्रॉइंग देखें और साइट पर राजमिस्त्री के FFL लेवल निशान चेक करें।',
    },
    checkBeforeLeaving: {
      en: 'Confirm PPR welder reaches 260°C and cutter blades are sharp before starting.',
      hi: 'काम शुरू करने से पहले वेल्डिंग मशीन का 260°C तापमान और कटर का ब्लेड जांच लें।',
    },
  },
  {
    phase: '09:00 AM · First Fix / Rough-In',
    title: {
      en: 'Chasing, Pipe Fixing & Clamping',
      hi: 'दीवार झिरी (Chasing), पाइप फिटिंग और क्लैंपिंग',
    },
    morningInstruction: {
      en: 'Keep Hot on Left, Cold on Right. Clamp vertical pipes every 1.0m and horizontal pipes every 0.8–1.0m. Maintain 1:50 slope on waste pipes.',
      hi: 'गर्म बाईं तरफ और ठंडा दाईं तरफ रखें। हर 1 मीटर पर क्लैंप लगाएं। ड्रेनेज पाइप में 1:50 का सही ढलान चेक करें।',
    },
    checkBeforeLeaving: {
      en: 'Cap every open pipe end with test plugs so cement mortar and dust never enter the line.',
      hi: 'शाम को काम खत्म करने से पहले हर खुले पाइप पर एंड-कैप (डमी प्लग) जरूर लगाएं ताकि मसाला अंदर न जाए।',
    },
  },
  {
    phase: '02:00 PM · Pressure & Water Test',
    title: {
      en: 'Hydrostatic Testing & IR Preparation',
      hi: 'प्रेशर टेस्ट और इंजीनियर इंस्पेक्शन (IR)',
    },
    morningInstruction: {
      en: 'Fill pipes completely, bleed all air pockets, pump to 10 Bar, and inspect every welded joint and brass nipple thread with dry tissue paper.',
      hi: 'पाइप में पानी भरकर पूरी हवा निकालें, 10 Bar तक प्रेशर चढ़ाएं और सूखे टिशू पेपर से हर जोड़ की नमी चेक करें।',
    },
    checkBeforeLeaving: {
      en: 'Leave pressure gauge connected under pressure if overnight drop check is required by the site engineer.',
      hi: 'अगर इंजीनियर 24 घंटे का टेस्ट मांगते हैं तो गेज को प्रेशर में ही लॉक छोड़कर जाएं।',
    },
  },
  {
    phase: '04:30 PM · Second Fix & Housekeeping',
    title: {
      en: 'Sanitaryware Mounting & Site Cleanup',
      hi: 'टॉयलेट-नल फिटिंग और साइट की सफाई',
    },
    morningInstruction: {
      en: 'Use cloth or tape on chrome wrench jaws so mixers never scratch. Run water through all lines before installing aerators and ceramic cartridges.',
      hi: 'क्रोम के महंगे नल कसते समय रिंच पर कपड़ा या टेप लगाएं ताकि स्क्रैच न आए। जाली लगाने से पहले पानी बहाकर कचरा साफ करें।',
    },
    checkBeforeLeaving: {
      en: 'Disconnect electrical tools, store solvent glue caps tightly, and clear pipe off-cuts from walkways.',
      hi: 'बिजली की मशीन बंद करें, ग्लू के डिब्बे का ढक्कन कसें और रास्ते से कचरा साफ करें।',
    },
  },
];

export const BUILDING_PHASES: BuildingPhase[] = [
  {
    step: 1,
    title: { en: 'Sub-Soil & Slab Sleeves (Foundation Stage)', hi: '1. जमीन के नीचे और स्लैब स्लीव (नींव स्टेज)' },
    scope: {
      en: 'Lay underground 110mm/160mm uPVC sewer lines to manholes, install earthing/water entry sleeves, and place slab sleeves before RCC concrete pouring.',
      hi: 'ग्राउंड फ्लोर के नीचे 110/160mm सीवर पाइप बिछाना, मैनहोल बनाना और छत ढलाई से पहले पाइप गुजरने के लिए स्लीव डालना।',
    },
    materials: '110/160mm uPVC Class 4, Puddle Flanges, Manhole Covers',
    inspectionGate: { en: 'Water fill + 100mm Steel Ball Test + Manhole Invert Level Check', hi: 'पाइप में पानी भरकर टेस्ट + बॉल टेस्ट + लेवल चेकिंग' },
  },
  {
    step: 2,
    title: { en: 'Main Vertical Shafts & Risers', hi: '2. मुख्य खड़ी लाइनें (Risers & Shafts)' },
    scope: {
      en: 'Install 110mm Soil, 75mm Waste, 50mm Vent stacks, and 32–63mm cold/hot supply risers inside service shafts with heavy-duty rubber-lined clamps.',
      hi: 'डक्ट या शाफ्ट के अंदर 110mm टॉयलेट, 75mm वेस्ट, 50mm वेंट और सप्लाई राइजर को मजबूत क्लैंप के साथ खड़ा करना।',
    },
    materials: 'PPR PN20 Risers, uPVC SWR Stacks, Clevis/Split Clamps, Expansion Joints',
    inspectionGate: { en: 'Vertical plumb check + Shaft pressure test at 10 Bar', hi: 'साहुल (Plumb) चेकिंग और राइजर का 10 Bar प्रेशर टेस्ट' },
  },
  {
    step: 3,
    title: { en: 'First Fix (Bathroom & Kitchen Rough-In)', hi: '3. फर्स्ट फिक्स (बाथरूम व किचन कंसील्ड काम)' },
    scope: {
      en: 'Wall chasing, 20/25mm PPR hot & cold concealed piping, concealed cistern frames, shower mixer bodies, floor traps, and 50mm waste piping.',
      hi: 'दीवार काटकर झिरी बनाना, 20/25mm PPR लाइन, कंसील्ड टैंक फ्रेम, मिक्सर बॉडी और फ्लोर ट्रैप लगाना।',
    },
    materials: '20/25mm PPR, Brass Elbows, Concealed Cistern, Multi-Inlet Floor Trap',
    inspectionGate: { en: '10 Bar Hydrostatic Test + 30-min Floor Trap Water Test before tiling', hi: 'टाइल से पहले 10 Bar प्रेशर टेस्ट और ड्रेन वाटर टेस्ट' },
  },
  {
    step: 4,
    title: { en: 'Waterproofing & Masonry Protection', hi: '4. वाटरप्रूफिंग और प्रोटेक्शन' },
    scope: {
      en: 'Coordinate puddle collars around floor traps, keep pipes pressurized during wall plastering/tiling to detect any accidental nail puncture immediately.',
      hi: 'फ्लोर ट्रैप के चारों तरफ वाटरप्रूफिंग करवाना और प्लास्टर-टाइल के समय पाइप में प्रेशर रखना ताकि कील लगने पर तुरंत पता चले।',
    },
    materials: 'Epoxy grout, Silicone, Pipe end test plugs',
    inspectionGate: { en: '48-hour Ponding Water Test on bathroom sunken slab', hi: 'बाथरूम फर्श में 48 घंटे पानी भरकर सीलन चेक करना' },
  },
  {
    step: 5,
    title: { en: 'Second Fix (Sanitaryware & Trim Fixtures)', hi: '5. सेकंड फिक्स (टॉयलेट, बेसिन व नल फिटिंग)' },
    scope: {
      en: 'Install WC bowls, push plates, wash basins, bottle traps, angle valves, shower heads, kitchen mixers, water heaters, and drain gratings.',
      hi: 'टॉयलेट सीट, फ्लश प्लेट, वॉश बेसिन, बॉटल ट्रैप, एंगल वॉल्व, मिक्सर, शावर और गीजर लगाना।',
    },
    materials: 'Sanitaryware, Angle Valves, Braided Hoses, Silicone Sealant',
    inspectionGate: { en: 'Flow, hot/cold orientation, trap seal & zero-drip fixture test', hi: 'नल प्रेशर, गर्म-ठंडा दिशा और बिना लीकेज चेकिंग' },
  },
  {
    step: 6,
    title: { en: 'Pump Room, Roof Tanks & Final Commissioning', hi: '6. पंप रूम, छत की टंकी और फाइनल हैंडओवर' },
    scope: {
      en: 'Connect underground & roof water tanks, float valves, transfer/booster pumps, PRVs, disinfect tanks with chlorine, and balance floor pressures.',
      hi: 'टंकी कनेक्शन, फ्लोट वॉल्व, बूस्टर पंप, PRV सेट करना, टंकी की सफाई (क्लोरीनेशन) और फाइनल हैंडओवर।',
    },
    materials: 'Booster Pump Set, Pressure Vessel, NRV, PRV, Y-Strainer, Float Valve',
    inspectionGate: { en: 'Auto start/stop pressure switch calibration & handover dossier', hi: 'ऑटो पंप कट-ऑफ सेटिंग और फाइनल टेस्टिंग पास' },
  },
];

export const PLUMBING_TOOLS: ToolItem[] = [
  {
    id: 'ppr-welder',
    name: 'PPR Socket Fusion Machine (260°C)',
    hindiName: 'PPR हीट वेल्डिंग मशीन',
    photo: '/src/assets/images/tools_ppr_welder_kit.jpg',
    purpose: {
      en: 'Heats PPR pipes and fittings simultaneously on Teflon-coated 20mm–110mm dies at 260°C for leak-proof permanent molecular joints.',
      hi: '260°C तापमान पर PPR पाइप और फिटिंग को एक साथ पिघलाकर पक्का जोड़ बनाने के लिए इस्तेमाल होती है।',
    },
    careTip: {
      en: 'Never scrape Teflon dies with metal knives; wipe gently with a clean dry cotton rag while warm.',
      hi: 'गर्म डाई को चाकू या लोहे से न खुरचें; हल्के गर्म में सूखे सूती कपड़े से साफ करें।',
    },
  },
  {
    id: 'ratchet-cutter',
    name: 'Ratchet Pipe Cutter (PPR / PVC)',
    hindiName: 'रैचेट पाइप कटर',
    photo: '/src/assets/images/tools_ppr_welder_kit.jpg',
    purpose: {
      en: 'Cuts PPR, PEX, CPVC, and uPVC pipes up to 42mm/63mm cleanly at 90° without plastic sawdust inside the line.',
      hi: 'बिना बुरादा निकाले PPR, CPVC और PVC पाइप को एक दम सीधा 90° काटने का सबसे बेहतरीन कटर।',
    },
    careTip: {
      en: 'Rotate pipe slightly while biting cold pipes in winter to avoid cracking the pipe wall.',
      hi: 'ठंड के मौसम में काटते समय पाइप को हल्का सा घुमाते रहें ताकि पाइप चिटके नहीं।',
    },
  },
  {
    id: 'pipe-wrench',
    name: 'Heavy-Duty Pipe Wrench & Adjustable Spanner',
    hindiName: 'पाइप रिंच और एडजस्टेबल पाना',
    photo: '/src/assets/images/tools_ppr_welder_kit.jpg',
    purpose: {
      en: 'Pipe wrench grips round GI pipes and nipples tightly; adjustable spanner turns flat hex brass valves, unions, and angle valves without biting marks.',
      hi: 'पाइप रिंच गोल GI पाइप पकड़ने के लिए, और एडजस्टेबल पाना चौकोर पीतल के वॉल्व व यूनियन कसने के लिए।',
    },
    careTip: {
      en: 'Always wrap masking tape or cloth on chrome angle valves before using any spanner.',
      hi: 'चमकदार क्रोम नल कसते समय पाने के मुंह पर कपड़ा या टेप जरूर लपेटें।',
    },
  },
  {
    id: 'spirit-level',
    name: 'Spirit Level & Measuring Tape',
    hindiName: 'स्पिरिट लेवल और इंच टेप',
    photo: '/src/assets/images/dubai_bathroom_roughin.jpg',
    purpose: {
      en: 'Verifies vertical plumb, level mixer centers (150mm), and exact drainage slope (1–2 cm fall per meter).',
      hi: 'मिक्सर पॉइंट्स को सीधा रखने और ड्रेनेज पाइप में सही ढलान (1–2 सेमी प्रति मीटर) नापने के लिए।',
    },
    careTip: {
      en: 'Keep cement mortar off the spirit bubble window and check accuracy by flipping it 180°.',
      hi: 'स्पिरिट लेवल पर सीमेंट न जमने दें और समय-समय पर उल्टा रखकर सही रीडिंग जांचें।',
    },
  },
  {
    id: 'hydro-pump',
    name: 'Hydrostatic Pressure Test Pump (0–50 Bar)',
    hindiName: 'हाइड्रोस्टैटिक प्रेशर टेस्ट पंप',
    photo: '/src/assets/images/pressure_test_pump.jpg',
    purpose: {
      en: 'Manually pressurizes sealed plumbing loops with water up to 10–15 Bar to detect pinhole leaks before wall tiling.',
      hi: 'दीवार में टाइल लगने से पहले पानी भरकर 10–15 Bar प्रेशर पर हर जोड़ की लीकेज चेक करने का पंप।',
    },
    careTip: {
      en: 'Always flush dirty water out of the pump reservoir after site testing and verify the gauge needle returns to zero.',
      hi: 'टेस्ट पूरा होने के बाद टैंक का गंदा पानी खाली करें और चेक करें कि गेज सुई जीरो पर लौटती है।',
    },
  },
];

export const SAFETY_RULES: SafetyRule[] = [
  {
    id: 'ppe',
    title: { en: 'Mandatory Site PPE (Personal Protective Equipment)', hi: 'अनिवार्य सेफ्टी उपकरण (PPE)' },
    hazardLevel: 'Mandatory PPE',
    rule: {
      en: 'Always wear Hard Hat, Safety Goggles (especially during wall chasing and overhead cutting), Cut-Resistant Gloves, and Steel-Toe Boots.',
      hi: 'साइट पर हमेशा सेफ्टी हेलमेट, चश्मा (दीवार कटर चलाते समय खास), कट-प्रूफ दस्ताने और स्टील-टो जूते पहनें।',
    },
    emergencyAction: {
      en: 'If concrete dust or solvent enters eyes, flush immediately at an eyewash station for 15 minutes.',
      hi: 'अगर आंखों में धूल या सॉल्वेंट ग्लू चला जाए तो तुरंत 15 मिनट तक साफ पानी से आंख धोएं।',
    },
  },
  {
    id: 'thermal-burn',
    title: { en: '260°C PPR Welder & Brazing Burn Safety', hi: '260°C वेल्डिंग मशीन और आग से बचाव' },
    hazardLevel: 'High',
    rule: {
      en: 'Always place the hot PPR welding machine on its metal floor stand—never on plastic pipes, cardboard, or wet floors. Keep electrical cord clear of the hot plate.',
      hi: 'गर्म PPR वेल्डिंग मशीन हमेशा उसके लोहे के स्टैंड पर रखें, कभी प्लास्टिक या गीले फर्श पर नहीं। तार को गर्म प्लेट से दूर रखें।',
    },
    emergencyAction: {
      en: 'Cool minor skin burns under running cool water for 10+ minutes; never apply toothpaste or grease.',
      hi: 'जलने पर कम से कम 10 मिनट तक बहते ठंडे पानी के नीचे रखें—कभी टूथपेस्ट या तेल न लगाएं।',
    },
  },
  {
    id: 'solvent-fumes',
    title: { en: 'Solvent Cement & Chemical Drain Safety', hi: 'सॉल्वेंट ग्लू और केमिकल सेफ्टी' },
    hazardLevel: 'High',
    rule: {
      en: 'uPVC/CPVC primer and solvent cement are highly flammable and release strong fumes. Never smoke or grind metal nearby, and ensure ventilation in closed bathrooms.',
      hi: 'सॉल्वेंट ग्लू बहुत ज्वलनशील होता है। बंद बाथरूम में काम करते समय हवा का इंतजाम रखें और पास में चिंगारी या सिगरेट न लाएं।',
    },
    emergencyAction: {
      en: 'Move immediately to fresh air if dizzy; never mix acid drain cleaners with bleach.',
      hi: 'चक्कर आने पर तुरंत खुली हवा में जाएं; एसिड और ब्लीच को कभी आपस में न मिलाएं।',
    },
  },
  {
    id: 'trench-ladder',
    title: { en: 'Trenching, Confined Spaces & Ladder Work', hi: 'गड्ढे (Trench), मैनहोल और सीढ़ी सुरक्षा' },
    hazardLevel: 'High',
    rule: {
      en: 'Never enter a deep sewer manhole alone—toxic H2S gas can be fatal without gas detector testing and ventilation. Secure ladders at 4:1 angle with 3-point contact.',
      hi: 'पुराने सीवर मैनहोल में गैस चेक किए बिना अकेले कभी न उतरें (H2S गैस जानलेवा हो सकती है)। सीढ़ी हमेशा 4:1 कोण पर फिक्स करें।',
    },
    emergencyAction: {
      en: 'Call site safety rescue immediately; do not enter an unventilated manhole without breathing apparatus.',
      hi: 'किसी साथी के बेहोश होने पर बिना मास्क अंदर न कूदें—तुरंत सेफ्टी टीम को बुलाएं।',
    },
  },
];

export const TROUBLESHOOTING_ITEMS: TroubleshootingItem[] = [
  {
    id: 'hidden-leak',
    issue: { en: 'Concealed Wall Dampness / Hidden Pipe Leak', hi: 'दीवार में सीलन / छुपी हुई लीकेज' },
    cause: { en: 'Pinholes from incomplete PPR fusion, unsealed brass nipple threads, or mason drill puncture.', hi: 'अधूरी PPR वेल्डिंग, निप्पल पर कम टेफ्लॉन टेप या टाइल लगाते समय ड्रिल लगने से छेद।' },
    detectionMethod: { en: 'Close all taps, check water meter spinning, isolate Hot vs Cold via angle valves, or attach 10 Bar test pump.', hi: 'सभी नल बंद करके वाटर मीटर देखें, गर्म और ठंडी लाइन अलग बंद करके प्रेशर गेज से चेक करें।' },
    fixSteps: [
      { en: 'Isolate zone valve and drain line; verify whether pressure drops on Cold or Hot circuit.', hi: 'जोन वॉल्व बंद करें और गेज से पक्का करें कि लीक ठंडी लाइन में है या गर्म में।' },
      { en: 'Use thermal camera or acoustic leak listener to pinpoint the exact tile before breaking.', hi: 'पूरी दीवार तोड़ने से पहले थर्मल या साउंड डिटेक्टर से सही जगह पहचानें।' },
      { en: 'Repair using PPR repair saddle/socket and re-test at 10 Bar for 2 hours before re-tiling.', hi: 'सही सॉकेट से रिपेयर करके टाइल लगाने से पहले दोबारा 10 Bar प्रेशर टेस्ट जरूर करें।' },
    ],
  },
  {
    id: 'slow-drain',
    issue: { en: 'Slow Drain & Foul Sewer Odor in Bathroom', hi: 'बाथरूम में पानी धीरे जाना और बदबू आना' },
    cause: { en: 'Hair/soap buildup in floor trap, dry trap water seal, or missing vent stack causing trap siphoning.', hi: 'फ्लोर ट्रैप में बाल व साबुन जमना, ट्रैप का पानी सूख जाना या वेंट पाइप न होने से पानी खिंच जाना।' },
    detectionMethod: { en: 'Inspect floor trap water depth (must be ≥50mm) and flush adjacent WC to watch if trap water bubbles/drops.', hi: 'फ्लोर ट्रैप की जाली खोलकर देखें कि अंदर कम से कम 50mm पानी खड़ा है या नहीं।' },
    fixSteps: [
      { en: 'Remove floor trap cover and clear hair/sludge manually or with a flexible drain auger (snake).', hi: 'जाली खोलकर हाथ से या ड्रेन स्प्रिंग वायर (Auger) से जमा बाल व कचरा निकालें।' },
      { en: 'Flush hot water + mild enzyme cleaner; avoid harsh acid that damages uPVC rubber seals.', hi: 'गर्म पानी चलाकर फ्लश करें; तेज तेजाब न डालें वरना रबर सील गल सकती है।' },
      { en: 'Refill trap water seal and check roof vent cowl for bird nests or blockage.', hi: 'ट्रैप में पानी भरें और छत पर वेंट पाइप की जाली साफ करें।' },
    ],
  },
  {
    id: 'low-pressure',
    issue: { en: 'Low Water Pressure or Hammering Noise', hi: 'कम पानी का प्रेशर या पाइप में खटखट की आवाज' },
    cause: { en: 'Blocked tap aerator, clogged Y-strainer before pump, partially closed gate valve, or air-locked PPR overheat restriction.', hi: 'नल की जाली में रेत फंसना, पंप का स्ट्रेनर जाम होना या PPR वेल्डिंग में ज्यादा गर्म करने से छेद सिकुड़ना।' },
    detectionMethod: { en: 'Remove tap aerator first; check pressure gauge before and after Y-strainer / PRV.', hi: 'सबसे पहले नल की जाली खोलकर पानी देखें, फिर पंप से पहले Y-स्ट्रेनर चेक करें।' },
    fixSteps: [
      { en: 'Clean tap aerators and Y-strainer stainless mesh screen.', hi: 'नल की जाली और Y-स्ट्रेनर की जाली साफ करें।' },
      { en: 'Verify booster pump bladder tank air pre-charge (set 0.2 Bar below pump cut-in pressure).', hi: 'बूस्टर पंप के प्रेशर टैंक में हवा का प्रेशर चेक करें।' },
      { en: 'Clamp loose pipes with rubber-lined brackets and install water hammer arresters near washing machines.', hi: 'ढीले पाइपों पर रबर क्लैंप कसें और वाशिंग मशीन पॉइंट पर वाटर हैमर अरेस्टर लगाएं।' },
    ],
  },
];

export const PUMP_TANK_GUIDES: PumpTankGuide[] = [
  {
    id: 'booster-pump',
    title: { en: 'Booster Pump & Pressure Vessel Setup', hi: 'बूस्टर पंप और प्रेशर टैंक कनेक्शन' },
    specs: 'Cut-in: 2.0 Bar · Cut-out: 3.5 Bar · Bladder Air: 1.8 Bar',
    explanation: {
      en: 'Maintains steady water pressure in top-floor apartments and villas. A diaphragm pressure vessel prevents frequent pump short-cycling when a small tap opens.',
      hi: 'ऊपरी मंजिलों में तेज प्रेशर बनाए रखने के लिए लगता है। प्रेशर टैंक (ब्लैडर टैंक) लगाने से छोटा नल खोलने पर पंप बार-बार चालू-बंद नहीं होता।',
    },
    checklist: [
      { en: 'Install 3-piece Unions + Isolation Ball Valves on both suction and delivery sides.', hi: 'पंप के इनलेट और आउटलेट दोनों तरफ यूनियन और बॉल वॉल्व जरूर लगाएं।' },
      { en: 'Place Y-Strainer on suction line and NRV (Check Valve) on pump discharge.', hi: 'इनलेट पर Y-स्ट्रेनर और आउटलेट पर NRV (चेक वॉल्व) लगाएं।' },
      { en: 'Add flexible anti-vibration connectors and dry-run float switch protection inside the tank.', hi: 'कंपन रोकने के लिए फ्लेक्सिबल जॉइंट और टंकी खाली होने पर पंप बचाने के लिए फ्लोट स्विच लगाएं।' },
    ],
  },
  {
    id: 'water-tank',
    title: { en: 'Roof & Underground Water Tanks (GRP / PE)', hi: 'छत व अंडरग्राउंड पानी की टंकी की फिटिंग' },
    specs: 'Inlet · Outlet (+100mm above floor) · Drain · Overflow · Vent',
    explanation: {
      en: 'Proper tank connections keep sediment out of home taps and protect against roof flooding if the float valve fails.',
      hi: 'टंकी के सही कनेक्शन घर के नलों में कीचड़ आने से रोकते हैं और फ्लोट वॉल्व खराब होने पर छत पर पानी भरने से बचाते हैं।',
    },
    checklist: [
      { en: 'Place supply Outlet 100mm above tank bottom so settled silt stays away from house pipes.', hi: 'सप्लाई आउटलेट टंकी की तली से 100mm ऊपर रखें ताकि नीचे बैठी रेत नलों में न जाए।' },
      { en: 'Keep Overflow pipe 1 size larger than Inlet pipe and fit insect mesh.', hi: 'ओवरफ्लो पाइप हमेशा इनलेट से एक साइज बड़ा रखें और जाली लगाएं।' },
      { en: 'Use brass mechanical float valve or solenoid level control valve on the inlet.', hi: 'इनलेट पर मजबूत पीतल का फ्लोट वॉल्व लगाएं ताकि टंकी भरते ही बंद हो जाए।' },
    ],
  },
  {
    id: 'water-heater',
    title: { en: 'Electric & Solar Water Heater Safety Piping', hi: 'इलेक्ट्रिक और सोलर वाटर हीटर कनेक्शन' },
    specs: 'Cold Right (Blue) · Hot Left (Red) · 6–8 Bar Safety Valve',
    explanation: {
      en: 'Water expands when heated. Without a working NRV + Pressure/Temperature Relief Valve (T&P), tanks can over-pressurize or back-feed hot water into cold lines.',
      hi: 'पानी गर्म होने पर फैलता है। बिना NRV और सेफ्टी रिलीफ वॉल्व के गीजर का प्रेशर बढ़ सकता है या गर्म पानी ठंडी लाइन में वापस आ सकता है।',
    },
    checklist: [
      { en: 'Always install the factory Non-Return & Safety Relief Valve on the COLD inlet (Blue).', hi: 'सेफ्टी रिलीफ + NRV वॉल्व हमेशा ठंडे इनलेट (नीला निशान) पर ही लगाएं।' },
      { en: 'Connect a small drain tube from the safety valve weep port to the nearest floor drain.', hi: 'सेफ्टी वॉल्व के साइड छेद से एक पतली ड्रेन पाइप पास के फ्लोर ट्रैप तक ले जाएं।' },
      { en: 'Fill heater completely with water (open hot tap until steady water flows) BEFORE switching ON electricity.', hi: 'बिजली चालू करने से पहले गर्म नल खोलकर गीजर को पूरा पानी से भरें और हवा निकालें।' },
    ],
  },
];

export const SECTOR_COMPARISONS: SectorComparison[] = [
  {
    sector: { en: 'Residential (Houses & Villas)', hi: 'घरेलू प्लंबिंग (घर और विला)' },
    pipeSpecs: '15–32mm PPR/CPVC · 40–110mm uPVC',
    pressure: '2.5 – 4.0 Bar',
    keySystems: {
      en: 'Individual roof tank, single booster pump, wall-hung/floor WCs, electric/solar water heaters, and septic/manhole connection.',
      hi: 'छत की टंकी, सिंगल बूस्टर पंप, बाथरूम-किचन फिटिंग, गीजर और घर के मैनहोल कनेक्शन।',
    },
  },
  {
    sector: { en: 'Commercial (Towers, Malls & Hotels)', hi: 'कमर्शियल (बिल्डिंग, मॉल और होटल)' },
    pipeSpecs: '20–160mm PPR/Copper/HDPE · Cast Iron/uPVC',
    pressure: '4–10 Bar Zoned with PRVs',
    keySystems: {
      en: 'Multi-pump VFD booster skids, zoned pressure reducing stations, hot-water recirculation, grease traps, and DEWA/DM IR inspections.',
      hi: 'VFD बूस्टर पंप, अलग-अलग मंजिल पर PRV जोन, सेंट्रल गर्म पानी लूप, ग्रीस ट्रैप और कंसल्टेंट इंस्पेक्शन।',
    },
  },
  {
    sector: { en: 'Industrial (Factories & Plants)', hi: 'इंडस्ट्रियल (फैक्ट्री और प्लांट)' },
    pipeSpecs: 'DN50–DN300 GI/Steel/HDPE/SS',
    pressure: '10–25+ Bar Process & Fire',
    keySystems: {
      en: 'Flanged/grooved steel headers, fire-fighting sprinkler mains, chemical-resistant drainage, steam/condensate, and compressed air loops.',
      hi: 'फ्लैंज व ग्रूव्ड स्टील पाइप, फायर-फाइटिंग स्प्रिंकलर लाइन, केमिकल ड्रेनेज और भारी प्रेशर सिस्टम।',
    },
  },
];

export const VIDEO_LESSONS: VideoLesson[] = [
  {
    id: 'lesson-ppr',
    title: { en: 'PPR 260°C Fusion Joint Mastery', hi: 'PPR 260°C हीट वेल्डिंग का सही तरीका' },
    duration: '4 Steps · Visual Guide',
    thumbnail: '/src/assets/images/tools_ppr_welder_kit.jpg',
    category: 'Jointing',
    frames: [
      {
        stepNumber: 1,
        caption: {
          en: 'Cut pipe square with ratchet cutter and mark 16mm insertion depth for 25mm PPR.',
          hi: 'रैचेट कटर से सीधा 90° काटें और 25mm पाइप पर 16mm गहराई का निशान लगाएं।',
        },
        technicalNote: 'Angle: 90° Square · Depth: 16 mm',
        calloutX: 25,
        calloutY: 32,
      },
      {
        stepNumber: 2,
        caption: {
          en: 'Verify machine display reads 260°C green light before inserting pipe and fitting.',
          hi: 'मशीन के डिजिटल डिस्प्ले पर 260°C और हरी बत्ती जलने की जांच करें।',
        },
        technicalNote: 'Welder Temp: 260°C',
        calloutX: 60,
        calloutY: 44,
      },
      {
        stepNumber: 3,
        caption: {
          en: 'Heat 25mm pipe and fitting simultaneously for exactly 7 seconds without twisting.',
          hi: 'बिना घुमाए 25mm पाइप और फिटिंग को एक साथ ठीक 7 सेकंड गर्म करें।',
        },
        technicalNote: 'Heating Time: 7 sec (25mm)',
        calloutX: 46,
        calloutY: 48,
      },
      {
        stepNumber: 4,
        caption: {
          en: 'Push straight together up to the mark; hold steady 4 seconds until uniform double bead ring forms.',
          hi: 'निशान तक सीधा दबाएं और 4 सेकंड रोकें जब तक चारों तरफ बराबर रिंग न बन जाए।',
        },
        technicalNote: 'Hold: 4 sec · Cool: 2 min',
        calloutX: 52,
        calloutY: 56,
      },
    ],
  },
  {
    id: 'lesson-dubai-bath',
    title: { en: 'Dubai Bathroom Rough-In & Concealed Cistern', hi: 'दुबई बाथरूम राफ-इन और कंसील्ड टैंक फ्रेम' },
    duration: '4 Steps · Visual Guide',
    thumbnail: '/src/assets/images/dubai_bathroom_roughin.jpg',
    category: 'Dubai Site',
    frames: [
      {
        stepNumber: 1,
        caption: {
          en: 'Level the concealed cistern steel frame accurately against the FFL mark using a spirit level.',
          hi: 'FFL फर्श लेवल के हिसाब से स्पिरिट लेवल रखकर कंसील्ड टैंक फ्रेम को बिल्कुल सीधा कसें।',
        },
        technicalNote: 'Top Frame Alignment · 0° Level',
        calloutX: 50,
        calloutY: 24,
      },
      {
        stepNumber: 2,
        caption: {
          en: 'Route insulated Blue Cold (Right) & Red Hot (Left) PPR lines with steel wall clamps.',
          hi: 'नीली ठंडी (दाएं) और लाल गर्म (बाएं) इंसुलेटेड PPR लाइनों को क्लैंप के साथ सीधी चलाएं।',
        },
        technicalNote: 'Hot = Left · Cold = Right',
        calloutX: 55,
        calloutY: 58,
      },
      {
        stepNumber: 3,
        caption: {
          en: 'Connect 110mm WC waste via swept Y-tee into the vertical uPVC soil stack.',
          hi: '110mm टॉयलेट ड्रेन को 45° वाई-टी (Wye) के जरिए खड़ी सॉइल लाइन में जोड़ें।',
        },
        technicalNote: '110 mm Soil Stack · 45° Wye',
        calloutX: 25,
        calloutY: 66,
      },
      {
        stepNumber: 4,
        caption: {
          en: 'Plug all brass elbows and pressurize lines to 10 Bar before wall plastering.',
          hi: 'प्लास्टर से पहले सभी ब्रास एल्बो में डमी प्लग लगाकर 10 Bar प्रेशर टेस्ट करें।',
        },
        technicalNote: 'Pre-Tile Test: 10 Bar',
        calloutX: 72,
        calloutY: 55,
      },
    ],
  },
  {
    id: 'lesson-pressure',
    title: { en: '10 Bar Hydrostatic Pressure Testing', hi: '10 Bar हाइड्रोस्टैटिक प्रेशर टेस्ट प्रक्रिया' },
    duration: '4 Steps · Visual Guide',
    thumbnail: '/src/assets/images/pressure_test_pump.jpg',
    category: 'Testing',
    frames: [
      {
        stepNumber: 1,
        caption: {
          en: 'Cap all wall outlets with brass/plastic test plugs and connect the braided test pump hose.',
          hi: 'सभी नल पॉइंट्स पर टेस्ट प्लग कसें और प्रेशर पंप की होज पाइप मैनिफोल्ड से जोड़ें।',
        },
        technicalNote: 'All Outlets Sealed',
        calloutX: 60,
        calloutY: 38,
      },
      {
        stepNumber: 2,
        caption: {
          en: 'Fill pipes with clean water and bleed out all trapped air from the highest outlet.',
          hi: 'लाइन में पानी भरकर सबसे ऊंचे पॉइंट से सारी हवा बाहर निकालें।',
        },
        technicalNote: 'Zero Trapped Air',
        calloutX: 35,
        calloutY: 64,
      },
      {
        stepNumber: 3,
        caption: {
          en: 'Pump handle steadily until the analog gauge needle reaches 10 Bar (150 PSI) and close pump valve.',
          hi: 'हैंडल चलाकर गेज पर ठीक 10 Bar (150 PSI) प्रेशर बनाएं और पंप का वॉल्व बंद करें।',
        },
        technicalNote: 'Target: 10 Bar (150 PSI)',
        calloutX: 67,
        calloutY: 27,
      },
      {
        stepNumber: 4,
        caption: {
          en: 'Inspect every weld and thread for 2 hours; zero gauge drop means ready for tiling.',
          hi: '2 घंटे तक गेज देखें और हर जोड़ चेक करें—सुई नहीं गिरने का मतलब लाइन पूरी तरह पास है।',
        },
        technicalNote: 'Hold 2–4 Hrs · 0 Bar Drop',
        calloutX: 78,
        calloutY: 55,
      },
    ],
  },
];
