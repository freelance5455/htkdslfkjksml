export interface RestaurantContactInfo {
  name: string;
  tagline: string;
  phone: string; // Dialable format
  phoneDisplay: string;
  whatsappPhone: string;
  whatsappDisplay: string;
  alternatePhone?: string;
  alternatePhoneDisplay?: string;
  email: string;
  address: {
    line1: string;
    line2: string;
    city: string;
    state: string;
    pincode: string;
    fullText: string;
  };
  coordinates: {
    lat: number;
    lng: number;
  };
  hours: {
    kitchen: string;
    breakfast: string;
    dineIn: string;
  };
  links: {
    googleMapsEmbed: string;
    googleMapsDirect: string;
    zomato: string;
    swiggy: string;
    instagram: string;
    whatsapp: string;
  };
}

export const RESTAURANT_INFO: RestaurantContactInfo = {
  name: "KAL O R E E Z",
  tagline: "The Wholesome Eatery",
  phone: "+918912345678", // Direct dialable phone link for calls
  phoneDisplay: "+91 891 234 5678",
  whatsappPhone: "+919966994787", // WhatsApp order & inquiry line
  whatsappDisplay: "+91 99669 94787",
  alternatePhone: "+919966994787",
  alternatePhoneDisplay: "+91 99669 94787",
  email: "kaloreez.vizag@gmail.com",
  address: {
    line1: "Plot 95, Oota Gadda Road",
    line2: "Daspalla Hills, Pandurangapuram",
    city: "Visakhapatnam",
    state: "Andhra Pradesh",
    pincode: "530003",
    fullText: "Plot 95, Oota Gadda Road, Daspalla Hills, Pandurangapuram, Visakhapatnam, Andhra Pradesh 530003",
  },
  coordinates: {
    lat: 17.7126,
    lng: 83.3228,
  },
  hours: {
    kitchen: "12:00 PM – 3:00 PM & 6:00 PM – 9:00 PM",
    breakfast: "7:30 AM – 3:00 PM & 5:30 PM – 10:00 PM",
    dineIn: "7:30 AM – 10:00 PM Daily",
  },
  links: {
    // High-resolution real-time Google Maps embed for Daspalla Hills, Visakhapatnam
    googleMapsEmbed:
      "https://maps.google.com/maps?q=Plot%2095%2C%20Oota%20Gadda%20Road%2C%20Daspalla%20Hills%2C%20Pandurangapuram%2C%20Visakhapatnam%2C%20Andhra%20Pradesh%20530003&t=&z=16&ie=UTF8&iwloc=&output=embed",
    googleMapsDirect:
      "https://www.google.com/maps/search/?api=1&query=Plot+95,+Oota+Gadda+Road,+Daspalla+Hills,+Pandurangapuram,+Visakhapatnam,+Andhra+Pradesh+530003",
    zomato: "https://www.zomato.com/visakhapatnam",
    swiggy: "https://www.swiggy.com/city/vizag",
    instagram: "https://www.instagram.com/kaloreez_vizag",
    whatsapp: "https://wa.me/919966994787?text=Hello%20Kaloreez%2C%20I%20would%20like%20to%20inquire%20about%20a%20table%20reservation.",
  },
};
