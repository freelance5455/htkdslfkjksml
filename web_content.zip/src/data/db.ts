import b64 from './hadith.b64.txt?raw';

export interface Topic {
  id: string;
  name: string;
  icon: string;
}

export interface Meta {
  books: string[];
  masoomsNames: string[];
  topics: Topic[];
  grades: string[];
  graders: string[];
}

export interface Hadith {
  key: string;
  text: string;
  split: number;
  book: number;
  num: number;
  /** 3 = صحيح, 2 = حسن/موثق كالصحيح, 1 = معتبر (حسن/موثق) */
  tier: 1 | 2 | 3;
  speaker: number;
  quoted: number[];
  topics: number[];
  grade: number;
  grader: number;
  norm?: string;
}

export interface DB {
  meta: Meta;
  hadiths: Hadith[];
}

/** Decode the gzip+base64 database that is embedded inside the app (works fully offline). */
export async function loadDB(): Promise<DB> {
  const bin = atob(b64.trim());
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  const text = await new Response(stream).text();
  const raw = JSON.parse(text) as { meta: Meta; h: any[][] };
  const hadiths: Hadith[] = raw.h.map((r) => ({
    key: `${r[2]}:${r[3]}`,
    text: r[0],
    split: r[1],
    book: r[2],
    num: r[3],
    tier: r[4],
    speaker: r[5],
    quoted: r[6],
    topics: r[7],
    grade: r[8],
    grader: r[9],
  }));
  return { meta: raw.meta, hadiths };
}

const DIAC = /[\u064B-\u065F\u0670\u0640\u06D6-\u06ED]/g;
export function normalizeAr(s: string): string {
  return s
    .replace(DIAC, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/\s+/g, ' ')
    .toLowerCase();
}

export function getNorm(h: Hadith): string {
  if (h.norm === undefined) h.norm = normalizeAr(h.text);
  return h.norm;
}

export function matnOf(h: Hadith): string {
  return h.split > 0 ? h.text.slice(h.split) : h.text;
}
export function sanadOf(h: Hadith): string {
  return h.split > 0 ? h.text.slice(0, h.split) : '';
}

export type TierMode = 'sahih' | 'plus' | 'all';
export function passTier(h: Hadith, mode: TierMode): boolean {
  if (mode === 'sahih') return h.tier === 3;
  if (mode === 'plus') return h.tier >= 2;
  return true;
}

export function passMasoom(h: Hadith, m: number | null): boolean {
  if (m === null) return true;
  return h.speaker === m || h.quoted.includes(m);
}
