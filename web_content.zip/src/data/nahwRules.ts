import { GrammarRule, GrammarTopic } from '../types';

export const nahwTopics: GrammarTopic[] = [
  {
    id: 'intro_nahw',
    category: 'nahw',
    arabicTitle: 'مُقَدِّمَةُ عِلْمِ النَّحْوِ وَأَقْسَامُ الْكَلاَمِ',
    title: {
      pashto: 'د نحو علم پېژندنه او د کلام وېش',
      urdu: 'علم النحو کا تعارف اور کلام کی تقسیم',
      english: 'Introduction to Ilm-e-Nahw & Discourse Anatomy'
    },
    description: {
      pashto: 'د نحو تعریف، موضوع، غرض او د جملې بنسټیز جوړښتونه',
      urdu: 'علم النحو کی تعریف، موضوع، غرض اور جملہ و کلام کے بنیادی ارکان',
      english: 'Syntax definitions, scope, objectives, and the architecture of speech'
    },
    iconName: 'BookMarked',
    rulesCount: 3
  },
  {
    id: 'murakkabaat',
    category: 'nahw',
    arabicTitle: 'الْمُرَكَّبُ التَّامُّ وَالْمُرَكَّبُ النَّاقِصُ',
    title: {
      pashto: 'مرکب تام (جمله) او مرکب ناقص',
      urdu: 'مرکب تام (جملہ) اور مرکب ناقص کی اقسام',
      english: 'Complete Sentences vs Nominal Phrasal Compounds'
    },
    description: {
      pashto: 'جمله اسمیه او فعلیه، مرکب توصيفي او مرکب اضافي',
      urdu: 'جملہ اسمیہ، جملہ فعلیہ، مرکب توصیفی اور مرکب اضافی کے قواعد',
      english: 'Nominal and verbal sentences, adjectival phrases, and possessive constructs'
    },
    iconName: 'Network',
    rulesCount: 4
  },
  {
    id: 'irab_marfooat',
    category: 'nahw',
    arabicTitle: 'الْمَرْفُوعَاتُ مِنَ الأَسْمَاءِ',
    title: {
      pashto: 'مرفوعات (هغه اسمونه چې پیش یا رفع اخلي)',
      urdu: 'مرفوعات (وہ اسماء جن پر پیش یا رفع آتا ہے)',
      english: 'The Nominative Case (Al-Marfoo\'aat)'
    },
    description: {
      pashto: 'فاعل، نائب الفاعل، مبتدأ، خبر، د إنّ خبر او د كانَ اسم',
      urdu: 'فاعل، نائب الفاعل، مبتدأ، خبر، خبرِ إنّ اور اسمِ کان کے تفصیلی احکام',
      english: 'Exhaustive rules of agents, subjects, predicates, and copular nouns'
    },
    iconName: 'ArrowUpCircle',
    rulesCount: 5
  },
  {
    id: 'irab_mansoobaat',
    category: 'nahw',
    arabicTitle: 'الْمَنْصُوبَاتُ مِنَ الأَسْمَاءِ',
    title: {
      pashto: 'منصوبات (هغه اسمونه چې زبر یا نصب اخلي)',
      urdu: 'منصوبات (وہ اسماء جن پر زبر یا نصب آتا ہے)',
      english: 'The Accusative Case (Al-Mansoobaat)'
    },
    description: {
      pashto: 'مفاعیل خمسه، حال، تمییز، مستثنیٰ، د إنّ اسم او د كانَ خبر',
      urdu: 'مفاعیل خمسہ (۵ مفعول)، حال، تمییز، مستثنیٰ، اسمِ إنّ اور خبرِ کان',
      english: 'The five cognate objects, circumstance (Haal), specification, and exceptions'
    },
    iconName: 'AlignJustify',
    rulesCount: 6
  },
  {
    id: 'irab_majrooraat',
    category: 'nahw',
    arabicTitle: 'الْمَجْرُورَاتُ مِنَ الأَسْمَاءِ',
    title: {
      pashto: 'مجرورات (هغه اسمونه چې زیر یا جر اخلي)',
      urdu: 'مجرورات (وہ اسماء جن پر زیر یا جر آتا ہے)',
      english: 'The Genitive Case (Al-Majrooraat)'
    },
    description: {
      pashto: 'مجرور په حرف جر او مجرور په اضافت (مضاف الیه)',
      urdu: 'حروفِ جارہ کے ذریعے مجرور اور مضاف الیہ بن کر مجرور ہونے والے اسماء',
      english: 'Prepositional genitives and construct annexation (Idaafah)'
    },
    iconName: 'ArrowDownCircle',
    rulesCount: 2
  },
  {
    id: 'tawabi_nawasib',
    category: 'nahw',
    arabicTitle: 'التَّوَابِعُ وَنَوَاصِبُ وَجَوَازِمُ الْمُضَارِعِ',
    title: {
      pashto: 'توابع او د مضارع ناصبه او جازمه توري',
      urdu: 'توابع اور نواصب و جوازمِ مضارع',
      english: 'Grammatical Followers (Tawabi\') & Mood Regulators'
    },
    description: {
      pashto: 'صفت، عطف، تاکید، بدل او د مضارع فعل د جزم او نصب عوامل',
      urdu: 'صفت، عطف، تاکید اور بدل کے احکام، نیز مضارع کو نصب و جزم دینے والے حروف',
      english: 'Appositives, conjunctions, emphasis, and subjunctive/jussive particles'
    },
    iconName: 'Compass',
    rulesCount: 4
  }
];

export const nahwRules: GrammarRule[] = [
  {
    id: 'nahw_definition',
    category: 'nahw',
    topicId: 'intro_nahw',
    arabicTitle: 'تَعْرِيفُ عِلْمِ النَّحْوِ وَمَوْضُوعُهُ وَغَايَتُهُ',
    title: {
      pashto: 'د نحو علم تعریف، موضوع او غرض',
      urdu: 'علم النحو کی تعریف، موضوع اور غرض و غایت',
      english: 'Definition, Scope, and Purpose of Ilm-e-Nahw'
    },
    summary: {
      pashto: 'نحو هغه علم دی چې په وسیله یې د جملې دننه د کلمو د وروستیو تورو اعراب او د هغوی خپلمنځي ترکیب پېژندل کېږي.',
      urdu: 'علم النحو وہ علم ہے جس کے ذریعے جملے میں کلمات کے آخری حروف کے اعراب اور کلمات کو باہم جوڑنے کے قواعد معلوم ہوں۔',
      english: 'Ilm-e-Nahw is the science of Arabic syntax which governs the inflections of word endings and sentence composition.'
    },
    definition: {
      pashto: 'نحو په لغت کې قصد، لوري او مثل ته وایي. په اصطلاح کې: هغه علم دی چې په هغې کې د کلمو د یوځای کولو طریقه او د هغوی د پای تورو احکام (معرب او مبنی والی) بیانېږي تر څو انسان په کلام کې له اعرابي غلطۍ څخه وساتل شي.',
      urdu: 'نحو لغت میں ارادہ، راستہ اور مثل کو کہتے ہیں۔ اصطلاح میں: وہ علم جس میں کلمات کو باہم جوڑ کر جملہ بنانے اور ان کے آخری حروف کی حالت (اعراب و بناء) معلوم کی جائے تاکہ کلام میں اعرابی غلطی سے بچا جا سکے۔',
      english: 'Etymologically, Nahw signifies intention, direction, or likeness. Technically, it is the discipline that analyzes syntactical linkage between words and determines the grammatical state of final syllables (I\'rab and Binaa).'
    },
    detailedRules: [
      {
        pashto: 'موضوع: د نحو علم موضوع "کَلِمَه" او "کَلَام" دي، له دې پلوه چې ترکیب پکې راځي او معرب یا مبنی وي.',
        urdu: 'موضوع: علم النحو کا موضوع "کلمہ" اور "کلام" ہیں، اس حیثیت سے کہ وہ آپس میں کیسے جڑتے ہیں اور ان کے آخر پر کیا اعراب آتا ہے۔',
        english: 'Subject Matter: Arabic words and connected speech regarding their declension and syntactic composition.'
      },
      {
        pashto: 'غرض او ګټه: په عربي ژبه کې د اعراب په پوهېدو سره د الهي وحي (قرآن) او نبوي سنت سم درک او د ژبې له خطا ژغورنه ده.',
        urdu: 'غرض و غایت: عربی بولنے اور سمجھنے میں اعرابی غلطی سے ذہن و زبان کو بچانا اور کلامِ الٰہی کے مفہوم کو درست سمجھنا ہے۔',
        english: 'Objective: Eliminating vocalic and grammatical errors to interpret Quranic and classical Arabic text with fidelity.'
      }
    ],
    examples: [
      {
        arabic: 'إِنَّمَا يَخْشَى اللّٰهَ مِنْ عِبَادِهِ الْعُلَمَاءُ',
        pashtoTranslation: 'بېشکه د الله له بندګانو څخه یوازې پوهان (علماء) له هغه څخه ډارېږي.',
        urduTranslation: 'اللہ کے بندوں میں سے صرف اہل علم ہی اس سے ڈرتے ہیں۔',
        englishTranslation: 'Only those among His servants who possess true knowledge fear Allah.',
        analysis: {
          pashto: 'د نحو د اعراب له امله دلته "اللّٰهَ" په زبر (نصب) سره مفعول دی او "الْعُلَمَاءُ" په پیش (رفع) سره فاعل دی. که اعراب بدل شي، معنی کفر ته رسېږي!',
          urdu: 'نحو کی برکت سے معلوم ہوتا ہے کہ لفظ جلالت "اللّٰهَ" منصوب ہونے کی وجہ سے مفعول ہے اور "الْعُلَمَاءُ" مرفوع ہونے کی وجہ سے فاعل ہے۔ اعراب بدلنے سے معنی بالکل الٹ سکتا تھا!',
          english: 'Demonstrates the critical power of I\'rab: Allah is in the accusative (object) and al-\'Ulamaa is in the nominative (agent/subject).'
        }
      }
    ],
    mnemonicOrNote: {
      pashto: 'حضرت علي رضی الله عنه ابو الاسود الدؤلي ته امر وکړ: "انْحُ هَذَا النَّحْوَ" (دا لاره تعقیب کړه)، نو ځکه ورته نحو وویل شول.',
      urdu: 'سیدنا علی مرتضیٰ رضی اللہ عنہ نے ابو الاسود الدؤلی کو قواعد مرتب کرتے وقت فرمایا تھا: "انح هذا النحو" (اس طریقے کی پیروی کرو)، جس سے اس علم کا نام نحو پڑا۔',
      english: 'Historical origin: Ali ibn Abi Talib (RA) instructed Abu al-Aswad al-Du\'ali: "Inhu hadha al-nahw" (Follow this method), coining the term Nahw.'
    },
    tags: ['تعریف نحو', 'موضوع', 'غرض', 'ابو الاسود الدؤلی']
  },
  {
    id: 'nahw_jumla_ismiyya',
    category: 'nahw',
    topicId: 'murakkabaat',
    arabicTitle: 'الْجُمْلَةُ الاسْمِيَّةُ: الْمُبْتَدَأُ وَالْخَبَرُ',
    title: {
      pashto: 'جمله اسمیه: مبتدأ او خبر',
      urdu: 'جملہ اسمیہ: مبتدأ اور خبر کے اصول',
      english: 'The Nominal Sentence: Subject (Mubtada) and Predicate (Khabar)'
    },
    summary: {
      pashto: 'جمله اسمیه هغه جمله ده چې لومړۍ برخه یې اسم وي، او له دوو اصلي ارکانو (مبتدأ او خبر) څخه جوړه شوې وي.',
      urdu: 'جملہ اسمیہ وہ جملہ ہے جو اسم سے شروع ہو، اور اس کے دو بنیادی اجزاء مبتدأ اور خبر ہوتے ہیں۔',
      english: 'A nominal sentence starts with a noun and fundamentally comprises an inchoative subject (Mubtada) and a predicate (Khabar).'
    },
    definition: {
      pashto: 'مبتدأ: هغه معرفه (پېژندل شوی) اسم دی چې جمله پرې پیلېږي او تل مرفوع (پیش لرونکی) وي. خبر: هغه برخه ده چې د مبتدأ په اړه خبر او ګټه بشپړوي او هغه هم تل مرفوع وي.',
      urdu: 'مبتدأ: وہ اسمِ معرفہ ہے جس سے جملہ شروع ہو اور وہ عموماً مرفوع ہوتا ہے۔ خبر: وہ کلمہ یا جملہ ہے جو مبتدأ کے بارے میں بات مکمل کرے اور وہ بھی مرفوع ہوتی ہے۔',
      english: 'The Mubtada is the definite initial subject in the nominative case. The Khabar is the predicate completing the thought, likewise inherently in the nominative case.'
    },
    detailedRules: [
      {
        pashto: 'قاعده: مبتدأ زیاتره معرفه (لکه د ال سره) وي او خبر زیاتره نکره (بې ال او له تنوین سره) وي.',
        urdu: 'قاعدہ: مبتدأ بالعموم معرفہ (ال کے ساتھ یا علم) ہوتا ہے اور خبر عموماً نکرہ (تنوین والی) ہوتی ہے۔',
        english: 'Canonical structure: Mubtada is typically definite (Ma\'rifah), whereas Khabar is typically indefinite (Nakirah).'
      },
      {
        pashto: 'موافقت: خبر باید له مبتدأ سره په جنس (مذکر/مؤنث) او په عدد (واحد، تثنیه، جمع) کې برابر وي.',
        urdu: 'مطابقت: خبر کو مبتدأ کے مطابق جنس (تذکیر و تانیث) اور عدد (واحد، تثنیہ، جمع) میں متفق ہونا لازم ہے۔',
        english: 'Concord: The predicate must agree with the subject in gender and number (except non-human plurals, which take feminine singular).'
      }
    ],
    examples: [
      {
        arabic: 'الْعِلْمُ نُورٌ | الصَّادِقُونَ مَفَائِزُ',
        pashtoTranslation: 'علم رڼا ده | رښتیني خلک بریالي دي.',
        urduTranslation: 'علم نور ہے | سچے لوگ کامیاب ہیں۔',
        englishTranslation: 'Knowledge is light | The truthful are triumphant.',
        analysis: {
          pashto: 'الْعِلْمُ مبتدأ ده (مرفوع په ضمه)، نُورٌ خبر ده (مرفوع په ضمه).',
          urdu: 'الْعِلْمُ مبتدأ ہے (مرفوع بالضمہ) اور نُورٌ اس کی خبر ہے (مرفوع بالضمہ)۔',
          english: 'Al-\'Ilmu is Mubtada (nominative with Dammah), Noorun is Khabar (nominative with Dammah).'
        }
      }
    ],
    tags: ['جملہ اسمیہ', 'مبتدأ', 'خبر', 'مرکب تام']
  },
  {
    id: 'nahw_jumla_filiyya',
    category: 'nahw',
    topicId: 'murakkabaat',
    arabicTitle: 'الْجُمْلَةُ الْفِعْلِيَّةُ: الْفِعْلُ وَالْفَاعِلُ وَالْمَفْعُولُ',
    title: {
      pashto: 'جمله فعلیه: فعل، فاعل او مفعول',
      urdu: 'جملہ فعلیہ: فعل، فاعل اور مفعول به',
      english: 'The Verbal Sentence: Verb, Agent (Faa\'il), and Object (Maf\'ool)'
    },
    summary: {
      pashto: 'جمله فعلیه هغه جمله ده چې په فعل سره پیل شي او له فعل، فاعل (کوونکي) او که متعدي وي له مفعول څخه جوړه وي.',
      urdu: 'جملہ فعلیہ وہ جملہ ہے جو فعل سے شروع ہو اور اس کے بنیادی ارکان فعل اور فاعل (اور متعدی ہونے کی صورت میں مفعول به) ہیں۔',
      english: 'A verbal sentence begins with a verb and fundamentally consists of the action, the agent (Faa\'il), and direct object.'
    },
    definition: {
      pashto: 'فعل: کار او زمانه ښیي. فاعل: هغه څوک دی چې کار یې کړی او تل "مرفوع" وي. مفعول به: هغه ذات دی چې کار پرې واقع شوی او تل "منصوب" (زبر لرونکی) وي.',
      urdu: 'فعل: کام اور زمانہ بتاتا ہے۔ فاعل: کام کرنے والا، جو ہمیشہ "مرفوع" ہوتا ہے۔ مفعول به: جس پر کام واقع ہو، اور یہ ہمیشہ "منصوب" ہوتا ہے۔',
      english: 'The verb indicates the action. The Faa\'il (agent) is perpetually in the nominative case (Marfoo\'). The Maf\'ool Bihi is perpetually in the accusative case (Mansoob).'
    },
    detailedRules: [
      {
        pashto: 'قاعده: که فاعل ښکاره اسم وي، فعل به تل د واحد په بڼه راځي، که څه هم فاعل تثنیه یا جمع وي (لکه: قَامَ الرَّجُلُ، قَامَ الرَّجُلَانِ، قَامَ الرِّجَالُ).',
        urdu: 'اہم قاعدہ: اگر فاعل اسمِ ظاہر ہو تو فعل ہمیشہ واحد ہی آئے گا، چاہے فاعل واحد ہو، تثنیہ ہو یا جمع ہو (جیسے: جَاءَ الْمُسْلِمُ، جَاءَ الْمُسْلِمَانِ، جَاءَ الْمُسْلِمُونَ)۔',
        english: 'Cardinal Rule: When the agent is an overt noun, the verb remains in the singular form even if the agent is dual or plural.'
      }
    ],
    examples: [
      {
        arabic: 'نَصَرَ زَيْدٌ عَمْرًا فِي الْمَسْجِدِ',
        pashtoTranslation: 'زید په جومات کې له عمرو سره مرسته وکړه.',
        urduTranslation: 'زید نے مسجد میں عمرو کی مدد کی۔',
        englishTranslation: 'Zayd helped \'Amr in the mosque.',
        analysis: {
          pashto: 'نَصَرَ فعل دی، زَيْدٌ فاعل دی (مرفوع په ضمه)، عَمْرًا مفعول به دی (منصوب په فتحه)، او فِي الْمَسْجِدِ جار او مجرور دي.',
          urdu: 'نَصَرَ فعلِ ماضی ہے، زَيْدٌ فاعل مرفوع ہے، عَمْرًا مفعول بہ منصوب ہے، اور فِي الْمَسْجِدِ جار و مجرور متعلقِ فعل ہیں۔',
          english: 'Nasara is verb, Zayd is nominative agent, \'Amran is accusative object, fil-masjidi is prepositional phrase.'
        }
      }
    ],
    tags: ['جملہ فعلیہ', 'فاعل', 'مفعول به', 'فعل']
  },
  {
    id: 'nahw_marfooat_rules',
    category: 'nahw',
    topicId: 'irab_marfooat',
    arabicTitle: 'أَقْسَامُ الْمَرْفُوعَاتِ الثَّمَانِيَةِ',
    title: {
      pashto: 'د مرفوعاتو اته واړه قسمونه په بشپړه توګه',
      urdu: 'مرفوعات کی آٹھوں اقسام اور ان کے احکام',
      english: 'The Eight Categories of Nominative Nouns (Marfoo\'aat)'
    },
    summary: {
      pashto: 'په عربي کې ۸ اسمونه دي چې تل به په هغوی پیش (رفع) راځي او بل هیڅ حرکت نشي اخیستی.',
      urdu: 'عربی گرامر میں ۸ قسم کے اسماء ایسے ہیں جن کا حق ہمیشہ "رفع" (پیش) ہے اور وہ کسی صورت منصوب یا مجرور نہیں ہو سکتے۔',
      english: 'Classical syntax identifies exactly eight distinct structural functions where a noun must receive the nominative case.'
    },
    definition: {
      pashto: 'اته مرفوعات دا دي: ۱. الفاعل (کار کوونکی) ۲. نائب الفاعل (چې فعل یې مجهول وي) ۳. المبتدأ ۴. الخبر ۵. د إنّ او د هغې د خویندو خبر ۶. د كانَ او د هغې د خویندو اسم ۷. د ما او لا المشبهتین بلیس اسم ۸. د لا لنفي الجنس خبر.',
      urdu: 'آٹھ مرفوعات یہ ہیں: ۱. فاعل ۲. نائب الفاعل (مفعول ما لم یسم فاعلہ) ۳. مبتدأ ۴. خبر ۵. خبرِ اِنَّ اور اس کی اخوات ۶. اسمِ کانَ اور اس کی اخوات ۷. اسمِ ما و لا مشبہتان بلیس ۸. خبرِ لا نفی جنس۔',
      english: 'The 8 Nominatives: 1. Faa\'il (agent), 2. Na\'ib al-Faa\'il (deputy agent of passive verb), 3. Mubtada (subject), 4. Khabar (predicate), 5. Predicate of Inna, 6. Subject of Kaana, 7. Subject of Maa/Laa resembling Laysa, 8. Predicate of generic negation Laa.'
    },
    detailedRules: [
      {
        pashto: 'د كانَ قاعده: كانَ او د هغې خویندې (أَصْبَحَ، أَمْسَى، صَارَ، لَيْسَ...) اسم مرفوع او خبر منصوب کوي (لکه: كَانَ اللّٰهُ غَفُورًا).',
        urdu: 'افعالِ ناقصہ (کان، اصبح، امسی، صار، لیس وغیرہ) اپنے اسم کو رفع اور خبر کو نصب دیتے ہیں (جیسے: كَانَ اللّٰهُ عَلِيمًا)۔',
        english: 'Kaana and its sisters render their subject nominative (Marfoo\') and their predicate accusative (Mansoob).'
      },
      {
        pashto: 'د إنّ قاعده: إنّ او د هغې خویندې (أَنَّ، كَأَنَّ، لَكِنَّ، لَيْتَ، لَعَلَّ) اسم منصوب او خبر مرفوع کوي (لکه: إِنَّ اللّٰهَ غَفُورٌ).',
        urdu: 'حروفِ مشبہ بالفعل (إنّ، أنّ، كأنّ، لكنّ، ليت، لعلّ) اپنے اسم کو نصب اور خبر کو رفع دیتے ہیں (جیسے: إِنَّ اللّٰهَ مَعَ الصَّابِرِينَ)۔',
        english: 'Inna and its sisters govern their noun in the accusative (Mansoob) and their predicate in the nominative (Marfoo\').'
      }
    ],
    examples: [
      {
        arabic: 'كَانَ اللّٰهُ غَفُورًا رَحِيمًا | إِنَّ اللّٰهَ عَلِيمٌ حَكِيمٌ',
        pashtoTranslation: 'الله تل بښونکی او مهربان دی | بېشکه الله خورا پوه او باحکمته دی.',
        urduTranslation: 'اللہ ہمیشہ سے بخشنے والا مہربان ہے | بے شک اللہ خوب جاننے والا حکمت والا ہے۔',
        englishTranslation: 'Allah is Ever Forgiving, Merciful | Indeed Allah is All-Knowing, All-Wise.',
        analysis: {
          pashto: 'په لومړي مثال کې "اللّٰهُ" د كانَ اسم (مرفوع) دی؛ په دویم کې "عَلِيمٌ" د إنّ خبر (مرفوع) دی.',
          urdu: 'پہلی مثال میں لفظ جلالت اسمِ کان ہونے کی وجہ سے مرفوع ہے؛ دوسری مثال میں "عَلِيمٌ" خبرِ إنّ ہونے سے مرفوع ہے۔',
          english: 'Contrasts the nominative noun of Kaana versus the nominative predicate of Inna.'
        }
      }
    ],
    tags: ['مرفوعات', 'کان', 'ان', 'نائب الفاعل', 'فاعل']
  },
  {
    id: 'nahw_mansoobaat_rules',
    category: 'nahw',
    topicId: 'irab_mansoobaat',
    arabicTitle: 'أَقْسَامُ الْمَنْصُوبَاتِ الاِثْنَيْ عَشَرَ وَالْمَفَاعِيلُ الْخَمْسَةُ',
    title: {
      pashto: 'د منصوباتو دوولس واړه قسمونه او پنځه ګوني مفعولان',
      urdu: 'منصوبات کی ۱۲ اقسام اور مفاعیل خمسہ کا بیان',
      english: 'The Twelve Categories of Accusatives & The Five Objects'
    },
    summary: {
      pashto: 'منصوبات هغه اسمونه دي چې په هغوی زبر (نصب) راځي، او تر ټولو مشهور پکې ۵ مفعولان، حال او تمییز دي.',
      urdu: 'منصوبات وہ اسماء ہیں جن کا اعراب نصب (زبر) ہوتا ہے۔ ان میں بنیادی طور پر ۵ مفعول، حال، تمییز اور مستثنیٰ شامل ہیں۔',
      english: 'The accusative case encompasses 12 classes, most notably the Five Cognate Objects, Haal, and Tamyeez.'
    },
    definition: {
      pashto: 'پنځه مفعولان دا دي: ۱. مفعول به (هغه ذات چې کار پرې شوی لکه: کَتَبَ الرِّسَالَةَ). ۲. مفعول مطلق (د همغه فعل مصدر د تاکید یا عدد لپاره لکه: نَصَرْتُ نَصْرًا). ۳. مفعول فیه یا ظرف (وخت یا ځای لکه: صُمْتُ يَوْمًا، جَلَسْتُ أَمَامَكَ). ۴. مفعول له (د کار د کولو لامل او سبب لکه: قُمْتُ إِجْلاَلًا لَكَ). ۵. مفعول معه (د ملګرتیا ښودلو لپاره د واو معیت وروسته لکه: سِرْتُ وَالنَّهْرَ).',
      urdu: 'مفاعیل خمسہ (پانچ مفعول) یہ ہیں: ۱. مفعول بہ (جس پر فعل واقع ہو، جیسے: قَرَأْتُ الْكِتَابَ)۔ ۲. مفعول مطلق (اسی فعل کا مصدر برائے تاکید، نوعیت یا عدد، جیسے: كَلَّمَ اللّٰهُ مُوسَى تَكْلِيمًا)۔ ۳. مفعول فیہ یعنی ظرفِ زمان و مکان (جیسے: صُمْتُ شَهْرًا، جَلَسْتُ فَوْقَ السَّطْحِ)۔ ۴. مفعول لہ (کام کی وجہ اور سبب، جیسے: قُمْتُ إِكْرَامًا لِلْعَالِمِ)۔ ۵. مفعول معہ (واؤ معیت کے بعد آنے والا اسم، جیسے: جَاءَ الْبَرْدُ وَالطَّيَالِسَةَ)۔',
      english: 'The Five Objects: 1. Maf\'ool Bihi (direct object), 2. Maf\'ool Mutlaq (absolute/cognate accusative), 3. Maf\'ool Feehi (locative/temporal adverb), 4. Maf\'ool Lahu (accusative of purpose/cause), 5. Maf\'ool Ma\'ahu (accusative of accompaniment).'
    },
    detailedRules: [
      {
        pashto: 'حال: هغه مشتق او نکره اسم دی چې د کار په وخت کې د فاعل یا مفعول بڼه او کیفیت بیان کړي (لکه: جَاءَ زَيْدٌ رَاكِبًا - زید سپور راغی).',
        urdu: 'حال: وہ اسمِ نکرہ و مشتق ہے جو فعل کے صدور کے وقت فاعل یا مفعول کی کیفیت ظاہر کرے (جیسے: جَاءَ زَيْدٌ ضَاحِكًا یعنی زید ہنستے ہوئے آیا)۔',
        english: 'Haal (Circumstantial Accusative): Indefinite participle describing the physical or mental state of the agent or object at the moment of action.'
      },
      {
        pashto: 'تمییز: هغه جامد او نکره اسم دی چې د مخکیني مبهم عدد یا کلمې ابهام لرې کړي (لکه: اشْتَرَيْتُ عِشْرِينَ كِتَابًا - شل کتابونه).',
        urdu: 'تمییز: وہ اسمِ نکرہ و جامد ہے جو اپنے ماقبل لفظ یا جملے کے ابہام کو دور کرے (جیسے: مَلَكْتُ عِشْرِينَ دِرْهَمًا)۔',
        english: 'Tamyeez (Specification/Clarification): Resolves ambiguity in previous numerals, measures, weights, or clauses.'
      }
    ],
    examples: [
      {
        arabic: 'وَكَلَّمَ اللّٰهُ مُوسَى تَكْلِيمًا | رَأَيْتُ أَحَدَ عَشَرَ كَوْكَبًا',
        pashtoTranslation: 'او الله له موسیٰ سره خبرې وکړې په ځانګړي ډول | ما یوولس ستوري ولیدل.',
        urduTranslation: 'اور اللہ نے موسیٰ علیہ السلام سے خاص گفتگو فرمائی | میں نے گیارہ ستارے دیکھے۔',
        englishTranslation: 'And Allah spoke to Moses with direct speech | I saw eleven stars.',
        analysis: {
          pashto: 'تَكْلِيمًا مفعول مطلق دی (د تاکید لپاره منصوب)، او كَوْكَبًا تمییز دی (د عدد د ابهام لرې کولو لپاره منصوب).',
          urdu: 'تَكْلِيمًا مفعول مطلق برائے تاکید ہے، اور كَوْكَبًا گیارہ کے عدد کی تمییز ہونے کے سبب منصوب ہے۔',
          english: 'Takleeman is absolute cognate object; Kawkaban is accusative of specification following numeral eleven.'
        }
      }
    ],
    tags: ['منصوبات', 'مفاعیل خمسہ', 'حال', 'تمییز', 'مستثنیٰ']
  },
  {
    id: 'nahw_majrooraat_rules',
    category: 'nahw',
    topicId: 'irab_majrooraat',
    arabicTitle: 'الْمَجْرُورَاتُ: بِحَرْفِ الْجَرِّ وَبِالإِضَافَةِ',
    title: {
      pashto: 'د مجروراتو دوه ډوله: په حرف جر او په اضافت سره',
      urdu: 'مجرورات کی دو قسمیں: بحرفِ جر اور باضافت (مضاف الیہ)',
      english: 'The Two Modes of the Genitive Case: Prepositional & Construct State'
    },
    summary: {
      pashto: 'په عربي کې اسم یوازې په دوو لارو مجرور (زیر لرونکی) کېږي: یا مخکې ترې حرف جر راشي، او یا مضاف الیه شي.',
      urdu: 'عربی زبان میں اسم پر جر (زیر) صرف دو اسباب سے آتا ہے: یا اس پر حرفِ جر داخل ہو، یا وہ مضاف الیہ بنے۔',
      english: 'An Arabic noun enters the genitive case through strictly two mechanisms: preceded by a preposition or serving as the second term of an Idaafah.'
    },
    definition: {
      pashto: '۱. مجرور په حرف جر: حروف جاره ۱۷ دي (باء، تاء، كاف، لام، واو، منذ، مذ، خلا، رب، حاشا، من، عدا، في، عن، على، حتى، إلى). ۲. مجرور په اضافت: لکه د "کِتَابُ زَيْدٍ" په مثال کې چې "زَيْدٍ" مضاف الیه او مجرور دی.',
      urdu: '۱. مجرور بحرفِ جر: سترہ حروفِ جارہ کے بعد آنے والا اسم مجرور ہوتا ہے (با، تا، کاف، لام، واؤ، منذ، مذ، خلا، رب، حاشا، من، عدا، فی، عن، علی، حتیٰ، الیٰ)۔ ۲. مجرور بالإضافة: مرکب اضافی میں مضاف الیہ ہمیشہ مجرور ہوتا ہے، جیسے: بَيْتُ اللّٰهِ میں لفظ جلالت مجرور ہے۔',
      english: '1. Prepositional Genitive: Governed by the 17 Huruf al-Jarr. 2. Annexed Genitive (Mudhaf Ilayh): The possessor in a construct state is invariably in the genitive.'
    },
    detailedRules: [
      {
        pashto: 'د مضاف اصول: مضاف هېڅکله "ال" او "تنوین" نه قبلوي، او که تثنیه یا جمع مذکر سالم وي، د هغوی نون هم لوېږي (لکه: غُلاَمَا زَيْدٍ).',
        urdu: 'مضاف کے قواعد: مضاف پر الف لام اور تنوین کبھی داخل نہیں ہو سکتے، اور اضافت کی وجہ سے تثنیہ و جمع مذکر سالم کا نون گر جاتا ہے (جیسے: مُعَلِّمُو الْمَدْرَسَةِ)۔',
        english: 'Rules for the Mudhaf: It can never take the definite article \'al-\' nor Tanween; furthermore, dual and sound masculine plural Noons are elided.'
      }
    ],
    examples: [
      {
        arabic: 'بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ',
        pashtoTranslation: 'د الله په نوم سره چې خورا بخښونکی او بې حده مهربان دی.',
        urduTranslation: 'اللہ کے نام کے ساتھ جو بڑا مہربان نہایت رحم فرمانے والا ہے۔',
        englishTranslation: 'In the name of Allah, the Entirely Merciful, the Especially Merciful.',
        analysis: {
          pashto: 'په "اسْمِ" کې د باء د حرف جر له امله جر دی، او "اللّٰهِ" د مضاف الیه توب له امله مجرور دی.',
          urdu: 'لفظ "اسْمِ" باء حرفِ جر کی وجہ سے مجرور ہے، اور لفظ جلالت "اللّٰهِ" مضاف الیہ ہونے کی وجہ سے مجرور ہے۔',
          english: 'Ismi is genitive via preposition Bi; Allahi is genitive as Mudhaf Ilayh.'
        }
      }
    ],
    tags: ['مجرورات', 'حروف جر', 'مضاف الیہ', 'اضافت']
  },
  {
    id: 'nahw_tawabi_rules',
    category: 'nahw',
    topicId: 'tawabi_nawasib',
    arabicTitle: 'التَّوَابِعُ الْخَمْسَةُ: النَّعْتُ وَالْعَطْفُ وَالتَّأْكِيدُ وَالْبَدَلُ',
    title: {
      pashto: 'توابع (هغه کلمې چې د مخکینۍ کلمې اعراب پوره تعقیبوي)',
      urdu: 'توابع کی اقسام: نعت (صفت)، عطف، تاکید اور بدل',
      english: 'The Grammatical Followers (Tawabi\'): Sifah, Atf, Ta\'keed, Badal'
    },
    summary: {
      pashto: 'تابع هغه کلمه ده چې خپل مستقل اعراب نه لري، بلکې د خپل مخکيني لفظ (متبوع) اعراب کټ مټ اخلي.',
      urdu: 'تابع وہ لفظ ہے جس کا اپنا ذاتی اعراب نہیں ہوتا بلکہ وہ اپنے ماقبل لفظ (متبوع) کے اعراب کی مکمل پیروی کرتا ہے۔',
      english: 'A Taabi\' (follower) possesses no independent case ending; it mirrors the syntactic inflection of its antecedent (Matboo\').'
    },
    definition: {
      pashto: 'توابع پنځه دي: ۱. نعت یا صفت (لکه: جَاءَ رَجُلٌ عَالِمٌ). ۲. عطف په حروفو سره (د واو، فاء، ثم وغيره په واسطه لکه: جَاءَ زَيْدٌ وَعَمْرٌو). ۳. تاکید (لفظي یا معنوي لکه: جَاءَ الْقَوْمُ كُلُّهُمْ). ۴. بدل (چې اصل مقصود وي لکه: قَالَ الشَّيْخُ زَيْدٌ). ۵. عطف بیان (چې ابهام په مشهور نوم سره لرې کړي).',
      urdu: 'توابع پانچ ہیں: ۱. صفت / نعت (جو موصوف کی اچھائی یا برائی بیان کرے، جیسے: رَأَيْتُ رَجُلًا صَالِحًا)۔ ۲. عطف بحرف (حروفِ عطف کے بعد آنے والا معطوف، جیسے: قَرَأْتُ الْفِقْهَ وَالنَّحْوَ)۔ ۳. تاکید (لفظی یا معنوی برائے پختگی، جیسے: جَاءَ الْمَلِكُ نَفْسُهُ)۔ ۴. بدل (جو اصل مقصود بالحکم ہو، جیسے: جَاءَ الْخَلِيفَةُ عُمَرُ)۔ ۵. عطفِ بیان۔',
      english: 'The 5 Followers: 1. Na\'at/Sifah (attributive adjective), 2. Atf (conjoined noun through particle), 3. Ta\'keed (corroboration/emphasis), 4. Badal (appositive substitute), 5. \'Atf Bayaan (explicative apposition).'
    },
    detailedRules: [
      {
        pashto: 'د صفت او موصوف موافقت: صفت باید په څلورو شیانو کې له موصوف سره یو شان وي: په اعراب کې (رفع، نصب، جر)، په تعریف او تنکیر کې، په جنس کې (مذکر/مؤنث)، او په عدد کې (واحد، تثنیه، جمع).',
        urdu: 'صفت و موصوف میں مطابقت: صفت اپنے موصوف کے ۴ امور میں تابع ہوتی ہے: اعراب (رفع، نصب، جر)، معرفہ و نکرہ، جنس (مذکر و مؤنث) اور عدد (واحد، تثنیہ، جمع)۔',
        english: 'Fourfold Concord: The adjective strictly matches its noun in case (I\'rab), definiteness, gender, and grammatical number.'
      }
    ],
    examples: [
      {
        arabic: 'فَسَجَدَ الْمَلَائِكَةُ كُلُّهُمْ أَجْمَعُونَ | اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
        pashtoTranslation: 'نو ټولو ملائکو په ګډه سجده وکړه | موږ ته سمه سیده لاره وښایه.',
        urduTranslation: 'پس تمام فرشتوں نے مل کر سب کے سب نے سجدہ کیا | ہمیں سیدھے راستے کی ہدایت فرما۔',
        englishTranslation: 'So the angels prostrated—all of them entirely | Guide us to the straight path.',
        analysis: {
          pashto: 'كُلُّهُمْ د ملائکه لپاره تاکید دی (مرفوع)، او الْمُسْتَقِيمَ د الصِّرَاطَ لپاره صفت دی (منصوب).',
          urdu: 'كُلُّهُمْ فاعلِ مرفوع کی معنوی تاکید ہے، اور الْمُسْتَقِيمَ مفعول بہ منصوب کی صفت ہونے کی وجہ سے منصوب ہے۔',
          english: 'Kulluhum is Ta\'keed mirroring the nominative Malaa\'ikah; al-Mustaqeema is an adjective matching the accusative al-Siraat.'
        }
      }
    ],
    tags: ['توابع', 'صفت', 'موصوف', 'تاکید', 'بدل', 'عطف']
  }
];
