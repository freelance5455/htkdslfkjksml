import raw from "./stars.json";
import { letterOf } from "@/lib/utils";

export type CatalogStar = {
  slug: string;
  name: string;
  photo: string | null;
  wiki: string;
  aliases?: string[];
};

export const CATALOG = raw as CatalogStar[];

export const CATALOG_BY_SLUG = new Map(CATALOG.map((s) => [s.slug, s]));

export const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

export function groupByLetter<T extends { name: string }>(stars: T[]) {
  const groups = new Map<string, T[]>();
  for (const star of stars) {
    const letter = letterOf(star.name);
    const list = groups.get(letter);
    if (list) list.push(star);
    else groups.set(letter, [star]);
  }
  for (const list of groups.values()) {
    list.sort((a, b) => a.name.localeCompare(b.name, "en", { sensitivity: "base" }));
  }
  return groups;
}
