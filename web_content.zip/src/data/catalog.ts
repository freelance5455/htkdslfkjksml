/* ============================================================
   MICHILICIAS — Catálogo exclusivo de 700 regalos
   Generación modular y determinista: cada artículo combina una
   forma/estilo + una paleta de colores (+ dije en collares), por
   lo que las 700 piezas tienen apariencia visual real y distinta.
   Estos artículos NO se venden con monedas: solo se obtienen
   canjeando códigos de regalo registrados en el sistema.
   ============================================================ */

export type Slot = "hat" | "bow" | "collar";
export type CharmType =
  | "bell" | "bellSilver" | "moon" | "star" | "heart"
  | "fish" | "gemPink" | "gemBlue" | "flower" | "paw";

export interface AccessoryItem {
  id: string;
  slot: Slot;
  name: string;
  desc: string;
  style: string;
  primary: string;
  secondary: string;
  charm?: CharmType;
  price?: number; // solo tienda normal
  exclusive?: boolean; // solo códigos de regalo
}

/* ---------------- Paletas ---------------- */
export interface Palette { name: string; p: string; s: string }
export const PALETTES: Palette[] = [
  { name: "Rosa Pastel", p: "#f9a8d4", s: "#fbcfe8" },
  { name: "Dorado Real", p: "#f5c451", s: "#fde68a" },
  { name: "Menta Fresca", p: "#6ee7b7", s: "#a7f3d0" },
  { name: "Lavanda Suave", p: "#c4b5fd", s: "#ddd6fe" },
  { name: "Cielo Dulce", p: "#7dd3fc", s: "#bae6fd" },
  { name: "Coral Vivo", p: "#fb923c", s: "#fda4af" },
  { name: "Medianoche", p: "#818cf8", s: "#f5c451" },
  { name: "Caramelo", p: "#d99a55", s: "#f5c451" },
  { name: "Blanco Nube", p: "#f1f5f9", s: "#f9a8d4" },
  { name: "Uva Mágica", p: "#a78bfa", s: "#f0abfc" },
];

/* ---------------- 100 Sombreros (10 formas × 10 paletas) ---------------- */
export const HAT_STYLES = [
  { id: "bruja", label: "Sombrero de Brujita" },
  { id: "corona", label: "Corona" },
  { id: "gorro", label: "Gorrito de Lana" },
  { id: "diadema", label: "Diadema Lunar" },
  { id: "copa", label: "Sombrero de Copa" },
  { id: "boina", label: "Boina Parisina" },
  { id: "gorra", label: "Gorrita Deportiva" },
  { id: "flores", label: "Corona de Flores" },
  { id: "halo", label: "Aureola Brillante" },
  { id: "conejo", label: "Orejitas de Conejo" },
] as const;

export const HATS: AccessoryItem[] = [];
HAT_STYLES.forEach((st, si) => {
  PALETTES.forEach((pal, pi) => {
    const n = si * 10 + pi + 1;
    HATS.push({
      id: `sombrero-${String(n).padStart(3, "0")}`,
      slot: "hat",
      name: `${st.label} ${pal.name}`,
      desc: `${st.label} en tonos ${pal.name.toLowerCase()}, tejido con hilos de luz de luna. Pieza exclusiva de MICHILICIAS.`,
      style: st.id,
      primary: pal.p,
      secondary: pal.s,
      exclusive: true,
    });
  });
});

/* ---------------- 100 Moños (10 estilos × 10 paletas) ---------------- */
export const BOW_STYLES = [
  { id: "clasico", label: "Clásico" },
  { id: "grande", label: "Gigante" },
  { id: "mini", label: "Mini" },
  { id: "lazo", label: "Lazo Largo" },
  { id: "doble", label: "Doble" },
  { id: "estrella", label: "Estrella" },
  { id: "corazon", label: "Corazón" },
  { id: "flor", label: "Flor" },
  { id: "pompon", label: "Pompón" },
  { id: "mariposa", label: "Mariposa" },
] as const;

export const BOWS: AccessoryItem[] = [];
BOW_STYLES.forEach((st, si) => {
  PALETTES.forEach((pal, pi) => {
    const n = si * 10 + pi + 1;
    BOWS.push({
      id: `mono-${String(n).padStart(3, "0")}`,
      slot: "bow",
      name: `Moño ${st.label} ${pal.name}`,
      desc: `Moño ${st.label.toLowerCase()} en tonos ${pal.name.toLowerCase()}, suave como una nubecita. Pieza exclusiva de MICHILICIAS.`,
      style: st.id,
      primary: pal.p,
      secondary: pal.s,
      exclusive: true,
    });
  });
});

/* ---------------- 100 Collares (10 paletas × 10 dijes) ---------------- */
export const CHARMS: { id: CharmType; label: string }[] = [
  { id: "bell", label: "Cascabel Dorado" },
  { id: "bellSilver", label: "Cascabel Plateado" },
  { id: "moon", label: "Lunita" },
  { id: "star", label: "Estrellita" },
  { id: "heart", label: "Corazoncito" },
  { id: "fish", label: "Pescadito" },
  { id: "gemPink", label: "Gema Rosa" },
  { id: "gemBlue", label: "Gema Azul" },
  { id: "flower", label: "Florcita" },
  { id: "paw", label: "Patita" },
];

export const COLLARS: AccessoryItem[] = [];
PALETTES.forEach((pal, pi) => {
  CHARMS.forEach((ch, ci) => {
    const n = pi * 10 + ci + 1;
    COLLARS.push({
      id: `collar-${String(n).padStart(3, "0")}`,
      slot: "collar",
      name: `Collar ${pal.name} con ${ch.label}`,
      desc: `Collar en tonos ${pal.name.toLowerCase()} con dije de ${ch.label.toLowerCase()} que tintinea al caminar. Pieza exclusiva de MICHILICIAS.`,
      style: "clasico",
      primary: pal.p,
      secondary: pal.p,
      charm: ch.id,
      exclusive: true,
    });
  });
});

/* ---------------- 100 Pelajes (10 colores × 10 patrones) ---------------- */
export type PatternId =
  | "liso" | "rayas" | "manchas" | "bicolor" | "carey"
  | "puntas" | "estrellas" | "corazones" | "degradado" | "marmol";

export interface FurStyle {
  id: string;
  name: string;
  desc: string;
  hex: string;
  hex2: string;
  pattern: PatternId;
  exclusive?: boolean;
}

export const FUR_COLORS = [
  { name: "Negro Ónix", hex: "#262632", hex2: "#434355" },
  { name: "Blanco Nieve", hex: "#f4f0e8", hex2: "#ddd5c6" },
  { name: "Gris Niebla", hex: "#9aa3b2", hex2: "#6e7686" },
  { name: "Chocolate", hex: "#6e452a", hex2: "#472a16" },
  { name: "Caramelo", hex: "#d99a55", hex2: "#a96f33" },
  { name: "Rosa Pétalo", hex: "#f6b8d0", hex2: "#e58bb2" },
  { name: "Lavanda", hex: "#c3b2ea", hex2: "#9d84d6" },
  { name: "Menta", hex: "#a9e5c8", hex2: "#6fbf97" },
  { name: "Azul Cielo", hex: "#a8cdf0", hex2: "#6f9fd2" },
  { name: "Dorado Miel", hex: "#f2cd7e", hex2: "#d9a53f" },
];

export const FUR_PATTERNS: { id: PatternId; label: string }[] = [
  { id: "liso", label: "Liso" },
  { id: "rayas", label: "Rayado" },
  { id: "manchas", label: "Manchado" },
  { id: "bicolor", label: "Bicolor" },
  { id: "carey", label: "Carey" },
  { id: "puntas", label: "Puntas Oscuras" },
  { id: "estrellas", label: "Estrellitas" },
  { id: "corazones", label: "Corazoncitos" },
  { id: "degradado", label: "Degradado" },
  { id: "marmol", label: "Mármol" },
];

export const FURS: FurStyle[] = [];
FUR_COLORS.forEach((c, ci) => {
  FUR_PATTERNS.forEach((p, pi) => {
    FURS.push({
      id: `pelaje-${ci}-${pi}`,
      name: `${c.name} ${p.label}`,
      desc: `Pelaje ${c.name.toLowerCase()} con patrón ${p.label.toLowerCase()}. Suave, brillante y único en el mundo.`,
      hex: c.hex,
      hex2: c.hex2,
      pattern: p.id,
      exclusive: true,
    });
  });
});

/* ---------------- 100 Gatos ---------------- */
export interface CatalogCat {
  id: string;
  name: string;
  furId: string;
  eye: string;
  eyeName: string;
  personality: string;
  hobby: string;
  rarity: "Común" | "Especial" | "Mágico" | "Legendario";
  desc: string;
}

const EYE_COLORS = [
  { hex: "#10b981", name: "Esmeralda" },
  { hex: "#f59e0b", name: "Ámbar" },
  { hex: "#38bdf8", name: "Cielo" },
  { hex: "#a78bfa", name: "Violeta" },
  { hex: "#f472b6", name: "Rosa" },
  { hex: "#34d399", name: "Jade" },
  { hex: "#818cf8", name: "Índigo" },
  { hex: "#fb923c", name: "Atardecer" },
  { hex: "#22d3ee", name: "Aguamarina" },
  { hex: "#e879f9", name: "Orquídea" },
];

const CAT_NAMES = [
  "Luna", "Estrella", "Nube", "Canela", "Miel", "Mora", "Perla", "Coco", "Kiwi", "Cacao",
  "Azúcar", "Copito", "Violeta", "Trébol", "Burbuja", "Pompón", "Chispa", "Turrón", "Galaxia", "Cometa",
  "Brisa", "Ónix", "Topacio", "Zafiro", "Solcito",
];
const EPITHETS = ["la Mágica", "la Dulce", "la Traviesa", "la Soñadora"];
const PERSONALITIES = ["Dulce", "Traviesa", "Soñadora", "Valiente", "Mimosa", "Curiosa", "Elegante", "Juguetona", "Sabia", "Aventurera"];
const HOBBIES = [
  "perseguir lunitas de papel", "dormir sobre libros de cuentos", "cazar mariposas de luz",
  "esconderse en cajas de cartón", "tomar lechita tibia al atardecer", "contar estrellas desde la ventana",
  "jugar con bolitas de estambre", "escuchar cuentos de hadas", "oler las flores del jardín", "bailar bajo la luna llena",
];

export const CATS: CatalogCat[] = Array.from({ length: 100 }, (_, i) => {
  const fur = FURS[i];
  const eye = EYE_COLORS[(i * 3) % 10];
  const personality = PERSONALITIES[i % 10];
  const hobby = HOBBIES[(i * 7) % 10];
  const rarity = i % 10 === 9 ? "Legendario" : i % 5 === 4 ? "Mágico" : i % 3 === 2 ? "Especial" : "Común";
  return {
    id: `gato-${String(i + 1).padStart(3, "0")}`,
    name: `${CAT_NAMES[i % 25]} ${EPITHETS[Math.floor(i / 25)]}`,
    furId: fur.id,
    eye: eye.hex,
    eyeName: eye.name,
    personality,
    hobby,
    rarity,
    desc: `Gatito de personalidad ${personality.toLowerCase()} al que le encanta ${hobby}. Pelaje ${fur.name.toLowerCase()} y ojitos color ${eye.name.toLowerCase()}.`,
  };
});

/* ---------------- 200 Conjuntos (combinaciones equipables) ---------------- */
export interface Outfit {
  id: string;
  name: string;
  desc: string;
  theme: string;
  hatId: string | null;
  bowId: string | null;
  collarId: string | null;
  exclusive: true;
}

const OUTFIT_A = [
  "Atardecer", "Luna Nueva", "Jardín Secreto", "Fiesta", "Invierno", "Playa", "Bosque Encantado", "Cumpleaños",
  "Navidad", "Primavera", "Otoño", "Verano", "Medianoche", "Amanecer", "Arcoíris", "Cristal",
  "Caramelo", "Estrellas", "Nubes", "Realeza",
];
const OUTFIT_B = [
  "Mágico", "Encantado", "Pastel", "Dorado", "Brillante", "Soñador", "Real", "Dulce", "Celestial", "Festivo",
];

export const OUTFITS: Outfit[] = Array.from({ length: 200 }, (_, i) => {
  const a = OUTFIT_A[i % 20];
  const b = OUTFIT_B[Math.floor(i / 20) % 10];
  const hat = HATS[(i * 13 + 7) % 100];
  const bow = BOWS[(i * 29 + 3) % 100];
  const collar = COLLARS[(i * 41 + 11) % 100];
  return {
    id: `conjunto-${String(i + 1).padStart(3, "0")}`,
    name: `Conjunto ${a} ${b}`,
    desc: `Conjunto completo de tema ${a.toLowerCase()}: ${hat.name}, ${bow.name} y ${collar.name}. Se equipa todo de una vez.`,
    theme: a,
    hatId: hat.id,
    bowId: bow.id,
    collarId: collar.id,
    exclusive: true,
  };
});

/* ---------------- Índices y totales ---------------- */
export const ACCESSORY_MAP = new Map<string, AccessoryItem>(
  [...HATS, ...BOWS, ...COLLARS].map((i) => [i.id, i])
);
export const FUR_MAP = new Map<string, FurStyle>(FURS.map((f) => [f.id, f]));
export const CAT_MAP = new Map<string, CatalogCat>(CATS.map((c) => [c.id, c]));
export const OUTFIT_MAP = new Map<string, Outfit>(OUTFITS.map((o) => [o.id, o]));

export const CATALOG_TOTALS = {
  sombreros: HATS.length,
  monos: BOWS.length,
  collares: COLLARS.length,
  gatos: CATS.length,
  pelajes: FURS.length,
  conjuntos: OUTFITS.length,
  total: HATS.length + BOWS.length + COLLARS.length + CATS.length + FURS.length + OUTFITS.length,
};

/** Resuelve el nombre visible de cualquier recompensa del catálogo. */
export function rewardName(id: string): string {
  if (ACCESSORY_MAP.has(id)) return ACCESSORY_MAP.get(id)!.name;
  if (FUR_MAP.has(id)) return `Pelaje ${FUR_MAP.get(id)!.name}`;
  if (CAT_MAP.has(id)) return `Gatito ${CAT_MAP.get(id)!.name}`;
  if (OUTFIT_MAP.has(id)) return OUTFIT_MAP.get(id)!.name;
  return id;
}

/** Categoría legible de una recompensa. */
export function rewardKind(id: string): string {
  if (id.startsWith("sombrero-")) return "Sombrero exclusivo";
  if (id.startsWith("mono-")) return "Moño exclusivo";
  if (id.startsWith("collar-")) return "Collar exclusivo";
  if (id.startsWith("pelaje-")) return "Pelaje exclusivo";
  if (id.startsWith("gato-")) return "Gatito exclusivo";
  if (id.startsWith("conjunto-")) return "Conjunto exclusivo";
  return "Artículo";
}
