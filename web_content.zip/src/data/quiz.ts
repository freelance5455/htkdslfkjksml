import type { ClassLevel, Subject } from "./types";

export type Difficulty = "Easy" | "Medium" | "Hard";

export interface QuizQuestion {
  id: string;
  classLevel: ClassLevel;
  subject: Subject;
  difficulty: Difficulty;
  topic: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  /** "bank" = from this hand-verified stored question bank (the default
   *  when omitted). "ai" = generated live by the AI Tutor for this session
   *  and validated before being shown — always labeled honestly in the UI,
   *  never presented as if it came from the stored bank. */
  source?: "bank" | "ai";
}

// A verified, hand-written built-in question bank used as the reliable
// fallback (and default) quiz source — every question/answer here has been
// checked for mathematical/scientific accuracy. This bank is always
// available even when no AI backend is configured.
export const QUIZ_BANK: QuizQuestion[] = [
  // ---------------- Class 8 ----------------
  { id: "q8m1", classLevel: 8, subject: "Mathematics", difficulty: "Easy", topic: "Exponents", question: "What is 2³ × 2²?", options: ["2⁵", "2⁶", "4⁵", "2¹"], correctIndex: 0, explanation: "When multiplying powers with the same base, add the exponents: 2³×2² = 2³⁺² = 2⁵ = 32." },
  { id: "q8m2", classLevel: 8, subject: "Mathematics", difficulty: "Easy", topic: "Mensuration", question: "What is the area of a square with side 9 cm?", options: ["18 cm²", "36 cm²", "81 cm²", "90 cm²"], correctIndex: 2, explanation: "Area of a square = side² = 9² = 81 cm²." },
  { id: "q8m3", classLevel: 8, subject: "Mathematics", difficulty: "Medium", topic: "Algebraic Identities", question: "Expand (x + 5)²", options: ["x² + 25", "x² + 10x + 25", "x² + 5x + 25", "x² − 10x + 25"], correctIndex: 1, explanation: "(a+b)² = a² + 2ab + b², so (x+5)² = x² + 2(5)x + 25 = x² + 10x + 25." },
  { id: "q8m4", classLevel: 8, subject: "Mathematics", difficulty: "Medium", topic: "Comparing Quantities", question: "Find the simple interest on ₹2000 at 5% per annum for 3 years.", options: ["₹100", "₹200", "₹300", "₹400"], correctIndex: 2, explanation: "SI = (P×R×T)/100 = (2000×5×3)/100 = ₹300." },
  { id: "q8m5", classLevel: 8, subject: "Mathematics", difficulty: "Hard", topic: "Direct and Inverse Proportion", question: "If 6 workers finish a job in 8 days, how many days will 4 workers take (inverse proportion)?", options: ["10 days", "12 days", "6 days", "16 days"], correctIndex: 1, explanation: "Workers × Days is constant: 6×8=48. With 4 workers: 48/4 = 12 days." },
  { id: "q8m6", classLevel: 8, subject: "Mathematics", difficulty: "Easy", topic: "Mensuration", question: "What is the circumference of a circle with radius 7 cm? (use π ≈ 22/7)", options: ["22 cm", "44 cm", "14 cm", "154 cm"], correctIndex: 1, explanation: "Circumference = 2πr = 2×(22/7)×7 = 44 cm." },
  { id: "q8m7", classLevel: 8, subject: "Mathematics", difficulty: "Medium", topic: "Linear Equations", question: "Solve for x: 3x − 6 = 9", options: ["x = 1", "x = 3", "x = 5", "x = 9"], correctIndex: 2, explanation: "3x = 9+6 = 15, so x = 15/3 = 5." },
  { id: "q8p1", classLevel: 8, subject: "Physics", difficulty: "Easy", topic: "Force and Pressure", question: "Pressure is defined as:", options: ["Force × Area", "Force / Area", "Mass / Volume", "Force × Distance"], correctIndex: 1, explanation: "Pressure = Force / Area, measured in pascals (Pa)." },
  { id: "q8p2", classLevel: 8, subject: "Physics", difficulty: "Easy", topic: "Motion", question: "A car covers 100 m in 10 s. What is its speed?", options: ["5 m/s", "10 m/s", "100 m/s", "1000 m/s"], correctIndex: 1, explanation: "Speed = Distance/Time = 100/10 = 10 m/s." },
  { id: "q8p3", classLevel: 8, subject: "Physics", difficulty: "Medium", topic: "Sound", question: "If the frequency of a wave is 50 Hz, what is its time period?", options: ["0.02 s", "0.2 s", "2 s", "50 s"], correctIndex: 0, explanation: "T = 1/f = 1/50 = 0.02 s." },
  { id: "q8p4", classLevel: 8, subject: "Physics", difficulty: "Medium", topic: "Current Electricity", question: "A charge of 10 C flows in 5 s. What is the current?", options: ["0.5 A", "2 A", "15 A", "50 A"], correctIndex: 1, explanation: "I = Q/t = 10/5 = 2 A." },
  { id: "q8c1", classLevel: 8, subject: "Chemistry", difficulty: "Easy", topic: "Matter", question: "Density is defined as:", options: ["Mass × Volume", "Mass / Volume", "Volume / Mass", "Weight / Area"], correctIndex: 1, explanation: "Density = Mass / Volume, commonly in g/cm³ or kg/m³." },
  { id: "q8c2", classLevel: 8, subject: "Chemistry", difficulty: "Medium", topic: "Elements, Compounds and Symbols", question: "Using the criss-cross method, what is the formula for Aluminium (valency 3) and Oxygen (valency 2)?", options: ["AlO", "Al₂O₃", "Al₃O₂", "AlO₃"], correctIndex: 1, explanation: "Criss-cross the valencies: Al gets subscript 2 (from O's valency), O gets subscript 3 (from Al's valency) → Al₂O₃." },
  { id: "q8c3", classLevel: 8, subject: "Chemistry", difficulty: "Easy", topic: "Matter", question: "A metal block has mass 270 g and volume 100 cm³. What is its density?", options: ["0.37 g/cm³", "2.7 g/cm³", "27 g/cm³", "270 g/cm³"], correctIndex: 1, explanation: "Density = mass/volume = 270/100 = 2.7 g/cm³ (this is aluminium)." },

  // ---------------- Class 9 ----------------
  { id: "q9m1", classLevel: 9, subject: "Mathematics", difficulty: "Easy", topic: "Number Systems", question: "Which of these is an irrational number?", options: ["4/5", "√9", "√2", "0.75"], correctIndex: 2, explanation: "√2 cannot be written as a simple fraction and its decimal expansion is non-terminating, non-repeating — it is irrational. √9 = 3, which is rational." },
  { id: "q9m2", classLevel: 9, subject: "Mathematics", difficulty: "Medium", topic: "Polynomials", question: "What is the degree of the polynomial 3x⁴ − 2x² + 7?", options: ["2", "3", "4", "7"], correctIndex: 2, explanation: "The degree of a polynomial is the highest power of the variable — here it's 4." },
  { id: "q9m3", classLevel: 9, subject: "Mathematics", difficulty: "Medium", topic: "Triangles", question: "In a triangle, if two angles are 55° and 65°, what is the third angle?", options: ["50°", "60°", "70°", "80°"], correctIndex: 1, explanation: "By the Angle Sum Property, the third angle = 180° − 55° − 65° = 60°." },
  { id: "q9m4", classLevel: 9, subject: "Mathematics", difficulty: "Easy", topic: "Coordinate Geometry", question: "In which quadrant does the point (−3, 4) lie?", options: ["I", "II", "III", "IV"], correctIndex: 1, explanation: "x is negative and y is positive, so the point lies in Quadrant II." },
  { id: "q9m5", classLevel: 9, subject: "Mathematics", difficulty: "Hard", topic: "Heron's Formula", question: "Find the area of a triangle with sides 3 cm, 4 cm, 5 cm using Heron's formula.", options: ["6 cm²", "7.5 cm²", "10 cm²", "12 cm²"], correctIndex: 0, explanation: "s = (3+4+5)/2 = 6. Area = √(6×3×2×1) = √36 = 6 cm²." },
  { id: "q9m6", classLevel: 9, subject: "Mathematics", difficulty: "Medium", topic: "Statistics", question: "Find the mean of 4, 8, 6, 5, 3.", options: ["5", "5.2", "6", "26"], correctIndex: 1, explanation: "Mean = (4+8+6+5+3)/5 = 26/5 = 5.2." },
  { id: "q9p1", classLevel: 9, subject: "Physics", difficulty: "Easy", topic: "Motion", question: "A body starts from rest and accelerates at 2 m/s² for 5 s. What is its final velocity?", options: ["5 m/s", "7 m/s", "10 m/s", "25 m/s"], correctIndex: 2, explanation: "v = u + at = 0 + 2×5 = 10 m/s." },
  { id: "q9p2", classLevel: 9, subject: "Physics", difficulty: "Medium", topic: "Force and Laws of Motion", question: "Newton's Second Law states that force equals:", options: ["mass × velocity", "mass × acceleration", "mass / acceleration", "mass × distance"], correctIndex: 1, explanation: "F = ma — force equals mass times acceleration." },
  { id: "q9p3", classLevel: 9, subject: "Physics", difficulty: "Medium", topic: "Gravitation", question: "The weight of a 10 kg object on Earth (g = 9.8 m/s²) is:", options: ["0.98 N", "9.8 N", "98 N", "980 N"], correctIndex: 2, explanation: "W = mg = 10 × 9.8 = 98 N." },
  { id: "q9p4", classLevel: 9, subject: "Physics", difficulty: "Hard", topic: "Work and Energy", question: "Find the kinetic energy of a 2 kg object moving at 3 m/s.", options: ["3 J", "6 J", "9 J", "18 J"], correctIndex: 2, explanation: "KE = ½mv² = 0.5×2×3² = 0.5×2×9 = 9 J." },
  { id: "q9c1", classLevel: 9, subject: "Chemistry", difficulty: "Easy", topic: "Atoms and Molecules", question: "The atomic number of an element represents the number of:", options: ["neutrons", "protons", "electrons only in ions", "protons + neutrons"], correctIndex: 1, explanation: "Atomic number (Z) = number of protons in the nucleus." },
  { id: "q9c2", classLevel: 9, subject: "Chemistry", difficulty: "Medium", topic: "Atoms and Molecules", question: "What is the molecular mass of water, H₂O? (H=1, O=16)", options: ["17 u", "18 u", "16 u", "19 u"], correctIndex: 1, explanation: "Molecular mass = 2(1) + 16 = 18 u." },
  { id: "q9c3", classLevel: 9, subject: "Chemistry", difficulty: "Hard", topic: "Mole Concept", question: "How many moles are in 36 g of water? (molar mass of water = 18 g/mol)", options: ["0.5 mol", "1 mol", "2 mol", "18 mol"], correctIndex: 2, explanation: "n = mass/molar mass = 36/18 = 2 mol." },

  // ---------------- Class 10 ----------------
  { id: "q10m1", classLevel: 10, subject: "Mathematics", difficulty: "Easy", topic: "Quadratic Equations", question: "What is the discriminant of x² − 4x + 4 = 0?", options: ["0", "4", "16", "-4"], correctIndex: 0, explanation: "D = b²−4ac = (−4)² − 4(1)(4) = 16−16 = 0, meaning equal real roots." },
  { id: "q10m2", classLevel: 10, subject: "Mathematics", difficulty: "Medium", topic: "Arithmetic Progressions", question: "Find the 10th term of the AP: 3, 7, 11, 15, ...", options: ["35", "37", "39", "41"], correctIndex: 2, explanation: "a=3, d=4. a₁₀ = a+(10−1)d = 3+9×4 = 39." },
  { id: "q10m3", classLevel: 10, subject: "Mathematics", difficulty: "Easy", topic: "Trigonometry", question: "What is the value of sin 30°?", options: ["0", "0.5", "1/√2", "1"], correctIndex: 1, explanation: "sin 30° = 1/2 = 0.5, a standard angle value." },
  { id: "q10m4", classLevel: 10, subject: "Mathematics", difficulty: "Hard", topic: "Coordinate Geometry", question: "Find the distance between (0,0) and (3,4).", options: ["3", "4", "5", "7"], correctIndex: 2, explanation: "d = √(3²+4²) = √25 = 5 (distance formula)." },
  { id: "q10m5", classLevel: 10, subject: "Mathematics", difficulty: "Medium", topic: "Circles", question: "A tangent to a circle is always ___ to the radius at the point of contact.", options: ["parallel", "perpendicular", "equal", "double"], correctIndex: 1, explanation: "A tangent is always perpendicular (90°) to the radius drawn at the point of contact." },
  { id: "q10m6", classLevel: 10, subject: "Mathematics", difficulty: "Hard", topic: "Surface Areas and Volumes", question: "Find the volume of a cone with radius 3 cm and height 4 cm. (use π ≈ 3.14)", options: ["12.56 cm³", "37.68 cm³", "113.04 cm³", "18.84 cm³"], correctIndex: 1, explanation: "Volume = (1/3)πr²h = (1/3)×3.14×9×4 = 37.68 cm³." },
  { id: "q10p1", classLevel: 10, subject: "Physics", difficulty: "Easy", topic: "Electricity", question: "According to Ohm's Law, V = ?", options: ["I/R", "I × R", "R/I", "I + R"], correctIndex: 1, explanation: "Ohm's Law: V = I × R." },
  { id: "q10p2", classLevel: 10, subject: "Physics", difficulty: "Medium", topic: "Electricity", question: "Find the current when V = 12 V and R = 4 Ω.", options: ["0.33 A", "3 A", "16 A", "48 A"], correctIndex: 1, explanation: "I = V/R = 12/4 = 3 A." },
  { id: "q10p3", classLevel: 10, subject: "Physics", difficulty: "Medium", topic: "Light", question: "A concave mirror has a focal length of:", options: ["always positive", "always negative (by convention)", "always zero", "undefined"], correctIndex: 1, explanation: "By the Cartesian sign convention, a concave mirror's focal length is taken as negative." },
  { id: "q10p4", classLevel: 10, subject: "Physics", difficulty: "Hard", topic: "Electricity", question: "Two resistors of 4 Ω and 6 Ω are connected in parallel. Find the equivalent resistance.", options: ["2.4 Ω", "5 Ω", "10 Ω", "24 Ω"], correctIndex: 0, explanation: "1/R = 1/4 + 1/6 = 5/12, so R = 12/5 = 2.4 Ω." },
  { id: "q10c1", classLevel: 10, subject: "Chemistry", difficulty: "Easy", topic: "Acids, Bases and Salts", question: "A solution with pH = 3 is:", options: ["strongly basic", "neutral", "acidic", "strongly alkaline"], correctIndex: 2, explanation: "pH < 7 indicates an acidic solution." },
  { id: "q10c2", classLevel: 10, subject: "Chemistry", difficulty: "Medium", topic: "Chemical Reactions and Equations", question: "In the reaction Zn + CuSO₄ → ZnSO₄ + Cu, this is an example of a:", options: ["combination reaction", "decomposition reaction", "displacement reaction", "neutralisation reaction"], correctIndex: 2, explanation: "Zinc displaces copper from copper sulphate because zinc is more reactive — a displacement reaction." },
  { id: "q10c3", classLevel: 10, subject: "Chemistry", difficulty: "Hard", topic: "Metals and Non-metals", question: "Which of these metals is most reactive, based on the typical reactivity series?", options: ["Copper", "Iron", "Sodium", "Gold"], correctIndex: 2, explanation: "Sodium is a highly reactive alkali metal, far more reactive than iron, copper, or gold in the standard reactivity series." },
];

export function getQuizQuestions(classLevel: ClassLevel, subject: Subject, difficulty: Difficulty | "All"): QuizQuestion[] {
  return QUIZ_BANK.filter((q) => q.classLevel === classLevel && q.subject === subject && (difficulty === "All" || q.difficulty === difficulty));
}
