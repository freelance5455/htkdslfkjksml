export type QuizQuestion = {
  prompt: string;
  options: string[];
  answer: number;
  why: string;
  lesson: string;
};

export const QUIZ: QuizQuestion[] = [
  {
    prompt: "Which star is brighter?",
    options: ["Magnitude 3.0", "Magnitude 0.5", "They are equal — magnitude is distance"],
    answer: 1,
    why: "Brighter stars have smaller magnitudes. 0.5 beats 3.0 by a wide margin, about ten times the light.",
    lesson: "light",
  },
  {
    prompt: "A light-year measures…",
    options: ["How long a star lives", "How far light travels in one year", "The time between solstices"],
    answer: 1,
    why: "It is a distance: about 9.5 trillion kilometers. Stars “being light-years away” means their light is that old when it arrives.",
    lesson: "light",
  },
  {
    prompt: "You measure Polaris at 51° above the horizon. Your latitude is about…",
    options: ["51°N", "39°N", "51°S"],
    answer: 0,
    why: "North of the equator, the pole star's altitude is your latitude. London sits near 51°N, which is why the Dipper never sets there.",
    lesson: "dome",
  },
  {
    prompt: "Stars rise in the east because…",
    options: [
      "The sky is a sphere that rotates west to east",
      "Earth rotates toward the east, so the sky seems to drift west",
      "The Sun pushes the star field every evening",
    ],
    answer: 1,
    why: "The ground moves east under you. The stars are effectively still, on human timescales. The drift you see is your horizon turning.",
    lesson: "dome",
  },
  {
    prompt: "A crescent moon happens because…",
    options: [
      "Earth's shadow is covering the rest",
      "You see only part of the Moon's sunlit face",
      "The Moon's own light is weaker that week",
    ],
    answer: 1,
    why: "Earth's shadow is a lunar eclipse, and only at full moon. Phases are the viewing angle on a ball that is always half lit.",
    lesson: "moon",
  },
  {
    prompt: "A solar eclipse can only happen at…",
    options: ["Full moon", "First quarter", "New moon"],
    answer: 2,
    why: "The Moon has to stand between you and the Sun, which is the new-moon geometry — and it also has to cross the plane of Earth's orbit, which is why most new moons are not eclipses.",
    lesson: "moon",
  },
  {
    prompt: "Which planet can stand highest at midnight?",
    options: ["Mercury", "Venus", "Jupiter"],
    answer: 2,
    why: "Mercury and Venus stay near the Sun in our sky. Jupiter, orbiting outside Earth, can rise at sunset and ride all night when it is at opposition.",
    lesson: "worlds",
  },
  {
    prompt: "The stars of a constellation are usually…",
    options: [
      "Born together and bound by gravity into that shape",
      "At very different distances, aligned only from here",
      "Planets that settled into a picture",
    ],
    answer: 1,
    why: "Orion's shoulder and Orion's belt are not neighbors. A few groups, like much of the Big Dipper, really are related — that is the exception.",
    lesson: "patterns",
  },
  {
    prompt: "Northern summer happens when…",
    options: [
      "Earth is nearest the Sun",
      "The northern hemisphere tilts toward the Sun",
      "The Sun's output peaks in June",
    ],
    answer: 1,
    why: "Earth is nearest the Sun in early January. June heat is longer days and a higher noon sun, both from the 23.4° tilt.",
    lesson: "seasons",
  },
  {
    prompt: "A full moon rises around…",
    options: ["Sunrise", "Noon", "Sunset"],
    answer: 2,
    why: "Full moon means the Moon is opposite the Sun. When the Sun sets, the full moon is rising. It is up all night and sets around sunrise.",
    lesson: "moon",
  },
];
