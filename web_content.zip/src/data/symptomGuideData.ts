import { SymptomItem, SymptomCategory, AuthoritativeSource, PreferredLanguage, UrgencyLevel } from '../types';

export const COMMON_SYMPTOMS: SymptomItem[] = [
  // General & Constitutional
  {
    id: 'fever',
    name: 'Fever',
    category: 'General & Constitutional',
    description: 'Elevated body temperature above 100.4°F (38°C), often indicating the immune system is fighting an infection.',
    nameTranslations: {
      English: 'Fever',
      Hindi: 'बुखार (Fever)',
      Marathi: 'ताप (Fever)',
    },
    descriptionTranslations: {
      English: 'Elevated body temperature above 100.4°F (38°C), often indicating the immune system is fighting an infection.',
      Hindi: '100.4°F (38°C) से अधिक बढ़ा हुआ शारीरिक तापमान, जो अक्सर संक्रमण से लड़ने का संकेत देता है।',
      Marathi: '१००.४°F (३८°C) पेक्षा जास्त वाढलेले शरीराचे तापमान, जे सहसा संसर्गाशी लढण्याचे लक्षण असते.',
    },
  },
  {
    id: 'fatigue',
    name: 'Fatigue',
    category: 'General & Constitutional',
    description: 'Persistent feeling of tiredness, low energy, or exhaustion not relieved by ordinary rest.',
    nameTranslations: {
      English: 'Fatigue',
      Hindi: 'अत्यधिक थकान (Fatigue)',
      Marathi: 'तीव्र थकवा (Fatigue)',
    },
    descriptionTranslations: {
      English: 'Persistent feeling of tiredness, low energy, or exhaustion not relieved by ordinary rest.',
      Hindi: 'लगातार थकान या ऊर्जा की कमी महसूस होना, जो सामान्य आराम से ठीक न हो।',
      Marathi: 'सतत थकवा किंवा ऊर्जेची कमतरता जाणवणे, जी साध्या विश्रांतीने दूर होत नाही.',
    },
  },
  {
    id: 'weakness',
    name: 'Weakness',
    category: 'General & Constitutional',
    description: 'Decreased physical muscle strength or feeling generalized bodily lack of power.',
    isRedFlagTrigger: true,
    nameTranslations: {
      English: 'Weakness',
      Hindi: 'शारीरिक कमजोरी (Weakness)',
      Marathi: 'शारीरिक अशक्तपणा (Weakness)',
    },
    descriptionTranslations: {
      English: 'Decreased physical muscle strength or feeling generalized bodily lack of power.',
      Hindi: 'मांसपेशियों की ताकत में कमी या शरीर में शक्ति का अभाव महसूस होना।',
      Marathi: 'स्नायूंच्या ताकदीमध्ये कमतरता किंवा संपूर्ण शरीरात शक्तीचा अभाव जाणवणे.',
    },
  },
  {
    id: 'chills',
    name: 'Chills & Shivering',
    category: 'General & Constitutional',
    description: 'Involuntary muscle shivering and feeling excessively cold, commonly associated with fever onset.',
    nameTranslations: {
      English: 'Chills & Shivering',
      Hindi: 'कंपकंपी और ठंड लगना (Chills & Shivering)',
      Marathi: 'थंडी वाजून हुडहुडी भरणे (Chills & Shivering)',
    },
    descriptionTranslations: {
      English: 'Involuntary muscle shivering and feeling excessively cold, commonly associated with fever onset.',
      Hindi: 'मांसपेशियों में अनैच्छिक कंपकंपी और अत्यधिक ठंड महसूस होना, जो अक्सर बुखार के साथ होती है।',
      Marathi: 'शरीरात थरथर आणि अतिशय थंडी वाजणे, जे सहसा ताप येताना आढळते.',
    },
  },
  {
    id: 'loss_of_appetite',
    name: 'Loss of Appetite',
    category: 'General & Constitutional',
    description: 'Reduced desire or interest in eating food.',
    nameTranslations: {
      English: 'Loss of Appetite',
      Hindi: 'भूख न लगना (Loss of Appetite)',
      Marathi: 'भूक मंदावणे (Loss of Appetite)',
    },
    descriptionTranslations: {
      English: 'Reduced desire or interest in eating food.',
      Hindi: 'खाना खाने की इच्छा या भूख में कमी आना।',
      Marathi: 'अन्न खाण्याची इच्छा किंवा भूक कमी होणे.',
    },
  },

  // Respiratory & Throat
  {
    id: 'cough',
    name: 'Cough',
    category: 'Respiratory & Throat',
    description: 'Sudden reflex to clear airways of mucus, irritants, fluids, or infectious microbes.',
    nameTranslations: {
      English: 'Cough',
      Hindi: 'खांसी (Cough)',
      Marathi: 'खोकला (Cough)',
    },
    descriptionTranslations: {
      English: 'Sudden reflex to clear airways of mucus, irritants, fluids, or infectious microbes.',
      Hindi: 'वायुमार्ग से कफ, धूल, या रोगाणुओं को बाहर निकालने की शारीरिक प्रतिक्रिया।',
      Marathi: 'श्वासनलिकेतून कफ, धूळ किंवा जंतू बाहेर काढण्यासाठी शरीराची नैसर्गिक प्रतिक्रिया.',
    },
  },
  {
    id: 'cold',
    name: 'Cold & Nasal Congestion',
    category: 'Respiratory & Throat',
    description: 'Stuffy, blocked, or runny nose accompanied by sinus congestion or sneezing.',
    nameTranslations: {
      English: 'Cold & Nasal Congestion',
      Hindi: 'सर्दी और नाक बंद होना (Cold & Congestion)',
      Marathi: 'सर्दी आणि नाक बंद होणे (Cold & Congestion)',
    },
    descriptionTranslations: {
      English: 'Stuffy, blocked, or runny nose accompanied by sinus congestion or sneezing.',
      Hindi: 'नाक बंद होना, पानी बहना, छींकें आना या साइनस में भारीपन होना।',
      Marathi: 'नाक वाहणे, बंद होणे, शिंका येणे किंवा सायनसमध्ये जडपणा जाणवणे.',
    },
  },
  {
    id: 'sore_throat',
    name: 'Sore Throat',
    category: 'Respiratory & Throat',
    description: 'Pain, scratchiness, or irritation of the throat that frequently worsens when swallowing.',
    nameTranslations: {
      English: 'Sore Throat',
      Hindi: 'गले में खराश या दर्द (Sore Throat)',
      Marathi: 'घसा खवखवणे किंवा दुखणे (Sore Throat)',
    },
    descriptionTranslations: {
      English: 'Pain, scratchiness, or irritation of the throat that frequently worsens when swallowing.',
      Hindi: 'गले में दर्द, चुभन या जलन जो निगलते समय और बढ़ जाती है।',
      Marathi: 'घशात टोचणे, आग होणे किंवा गिळताना तीव्र त्रास होणे.',
    },
  },
  {
    id: 'shortness_of_breath',
    name: 'Shortness of Breath',
    category: 'Respiratory & Throat',
    description: 'Difficulty breathing, breathlessness, or feeling unable to catch a full breath.',
    isRedFlagTrigger: true,
    nameTranslations: {
      English: 'Shortness of Breath',
      Hindi: 'सांस लेने में कठिनाई (Shortness of Breath)',
      Marathi: 'श्वास घेण्यास त्रास / धाप लागणे (Shortness of Breath)',
    },
    descriptionTranslations: {
      English: 'Difficulty breathing, breathlessness, or feeling unable to catch a full breath.',
      Hindi: 'सांस फूलना, गहरी सांस न ले पाना या दम घुटने जैसा अहसास होना।',
      Marathi: 'धाप लागणे, श्वास घेण्यास अडचण येणे किंवा पूर्ण श्वास न घेता येणे.',
    },
  },
  {
    id: 'wheezing',
    name: 'Wheezing',
    category: 'Respiratory & Throat',
    description: 'High-pitched whistling sound during breathing caused by narrowed bronchial airways.',
    nameTranslations: {
      English: 'Wheezing',
      Hindi: 'सांस में सीटी जैसी आवाज (Wheezing)',
      Marathi: 'श्वास घेताना शिटीसारखा आवाज (Wheezing)',
    },
    descriptionTranslations: {
      English: 'High-pitched whistling sound during breathing caused by narrowed bronchial airways.',
      Hindi: 'श्वास नलियों के संकुचित होने से सांस लेते समय सीटी जैसी बारीक आवाज आना।',
      Marathi: 'श्वासनलिका अरुंद झाल्यामुळे श्वास घेताना किंवा सोडताना घरघर/शिट्टीचा आवाज येणे.',
    },
  },

  // Head & Neurological
  {
    id: 'headache',
    name: 'Headache',
    category: 'Head & Neurological',
    description: 'Pain or discomfort in the head, scalp, or neck region.',
    nameTranslations: {
      English: 'Headache',
      Hindi: 'सिरदर्द (Headache)',
      Marathi: 'डोकेदुखी (Headache)',
    },
    descriptionTranslations: {
      English: 'Pain or discomfort in the head, scalp, or neck region.',
      Hindi: 'सिर, खोपड़ी या गर्दन के ऊपरी हिस्से में लगातार या तेज दर्द होना।',
      Marathi: 'डोक्यात, टाळूवर किंवा मानेच्या वरच्या भागात तीव्र किंवा मंद वेदना.',
    },
  },
  {
    id: 'dizziness',
    name: 'Dizziness & Lightheadedness',
    category: 'Head & Neurological',
    description: 'Feeling unsteady, woozy, faint, or having a spinning sensation.',
    nameTranslations: {
      English: 'Dizziness & Lightheadedness',
      Hindi: 'चक्कर आना और असंतुलन (Dizziness)',
      Marathi: 'चक्कर येणे आणि गरगरणे (Dizziness)',
    },
    descriptionTranslations: {
      English: 'Feeling unsteady, woozy, faint, or having a spinning sensation.',
      Hindi: 'सिर घूमना, असंतुलन महसूस होना या बेहोशी जैसा लगना।',
      Marathi: 'तोल जाणे, भोवळ येणे किंवा डोळ्यांसमोर अंधारी येणे.',
    },
  },
  {
    id: 'confusion',
    name: 'Confusion or Disorientation',
    category: 'Head & Neurological',
    description: 'Sudden inability to think clearly, memory fog, or disorientation.',
    isRedFlagTrigger: true,
    nameTranslations: {
      English: 'Confusion or Disorientation',
      Hindi: 'अचानक भ्रम या मानसिक अस्पष्टता (Confusion)',
      Marathi: 'गोंधळलेली मानसिक स्थिती (Confusion)',
    },
    descriptionTranslations: {
      English: 'Sudden inability to think clearly, memory fog, or disorientation.',
      Hindi: 'स्पष्ट सोचने में असमर्थता, याददाश्त का धुंधला होना या समय-स्थान की समझ न रहना।',
      Marathi: 'स्पष्ट विचार न करता येणे, स्मरणशक्ती कमजोर वाटणे किंवा दिशाभूल होणे.',
    },
  },
  {
    id: 'stiff_neck',
    name: 'Stiff Neck',
    category: 'Head & Neurological',
    description: 'Pain and difficulty moving or bending the neck forward toward the chest.',
    isRedFlagTrigger: true,
    nameTranslations: {
      English: 'Stiff Neck',
      Hindi: 'गर्दन में तेज अकड़न (Stiff Neck)',
      Marathi: 'मान आखडणे (Stiff Neck)',
    },
    descriptionTranslations: {
      English: 'Pain and difficulty moving or bending the neck forward toward the chest.',
      Hindi: 'गर्दन को हिलाने या ठुड्डी को छाती की ओर झुकाने में अत्यधिक दर्द और रुकावट।',
      Marathi: 'मान हालवताना तीव्र वेदना होणे किंवा हनुवटी छातीकडे झुकवता न येणे.',
    },
  },
  {
    id: 'fainting',
    name: 'Fainting or Blackout',
    category: 'Head & Neurological',
    description: 'Temporary sudden loss of consciousness and muscle posture.',
    isRedFlagTrigger: true,
    nameTranslations: {
      English: 'Fainting or Blackout',
      Hindi: 'बेहोशी या अचानक गिरना (Fainting)',
      Marathi: 'अचानक भोवळ येऊन बेशुद्ध पडणे (Fainting)',
    },
    descriptionTranslations: {
      English: 'Temporary sudden loss of consciousness and muscle posture.',
      Hindi: 'अचानक कुछ समय के लिए चेतना (होश) खो देना और गिर जाना।',
      Marathi: 'काही क्षणांसाठी शुद्ध हरपणे किंवा अचानक चक्कर येऊन खाली पडणे.',
    },
  },

  // Digestive & Abdominal
  {
    id: 'nausea',
    name: 'Nausea',
    category: 'Digestive & Abdominal',
    description: 'An unsettling sensation in the stomach accompanied by an urge to vomit.',
    nameTranslations: {
      English: 'Nausea',
      Hindi: 'जी मिचलाना (Nausea)',
      Marathi: 'मळमळणे (Nausea)',
    },
    descriptionTranslations: {
      English: 'An unsettling sensation in the stomach accompanied by an urge to vomit.',
      Hindi: 'पेट में बेचैनी होना और उल्टी आने जैसा महसूस होना।',
      Marathi: 'पोटात अस्वस्थता जाणवणे आणि उलट्या होण्याची तीव्र भावना होणे.',
    },
  },
  {
    id: 'vomiting',
    name: 'Vomiting',
    category: 'Digestive & Abdominal',
    description: 'Involuntary forceful expulsion of stomach contents through the mouth.',
    nameTranslations: {
      English: 'Vomiting',
      Hindi: 'उल्टी होना (Vomiting)',
      Marathi: 'उलट्या होणे (Vomiting)',
    },
    descriptionTranslations: {
      English: 'Involuntary forceful expulsion of stomach contents through the mouth.',
      Hindi: 'पेट की सामग्री का मुंह के रास्ते अनैच्छिक रूप से बाहर निकलना।',
      Marathi: 'पोटातील अन्न किंवा पाणी तोंडावाटे जोराने बाहेर पडणे.',
    },
  },
  {
    id: 'diarrhea',
    name: 'Diarrhea',
    category: 'Digestive & Abdominal',
    description: 'Loose, watery, or frequent bowel movements (3 or more times per day).',
    nameTranslations: {
      English: 'Diarrhea',
      Hindi: 'दस्त या पतले शौच (Diarrhea)',
      Marathi: 'जुलाब / पातळ संडास (Diarrhea)',
    },
    descriptionTranslations: {
      English: 'Loose, watery, or frequent bowel movements (3 or more times per day).',
      Hindi: 'दिन में 3 या अधिक बार पतला, पानी जैसा मल आना।',
      Marathi: 'दिवसातून ३ किंवा त्याहून अधिक वेळा पातळ, पाण्यासारखे जुलाब होणे.',
    },
  },
  {
    id: 'abdominal_pain',
    name: 'Abdominal Pain',
    category: 'Digestive & Abdominal',
    description: 'Cramping, aching, dull, or sharp pain anywhere between the chest and groin.',
    nameTranslations: {
      English: 'Abdominal Pain',
      Hindi: 'पेट में दर्द या मरोड़ (Abdominal Pain)',
      Marathi: 'पोटदुखी किंवा पोटात मुरडा (Abdominal Pain)',
    },
    descriptionTranslations: {
      English: 'Cramping, aching, dull, or sharp pain anywhere between the chest and groin.',
      Hindi: 'छाती के नीचे और पेट के किसी भी हिस्से में मरोड़, जलन या तेज दर्द।',
      Marathi: 'पोटात गोळा येणे, कळा येणे किंवा तीव्र वेदना जाणवणे.',
    },
  },

  // Chest & Cardiovascular
  {
    id: 'chest_pain',
    name: 'Chest Pain',
    category: 'Chest & Cardiovascular',
    description: 'Pain, pressure, tightness, squeezing, or burning discomfort in the chest area.',
    isRedFlagTrigger: true,
    nameTranslations: {
      English: 'Chest Pain',
      Hindi: 'छाती में दर्द या दबाव (Chest Pain)',
      Marathi: 'छातीत दुखणे किंवा दाब जाणवणे (Chest Pain)',
    },
    descriptionTranslations: {
      English: 'Pain, pressure, tightness, squeezing, or burning discomfort in the chest area.',
      Hindi: 'छाती में भारीपन, दबाव, खिंचाव या जलन महसूस होना।',
      Marathi: 'छातीवर जडपणा, दाब, कळ येणे किंवा जळजळ जाणवणे.',
    },
  },
  {
    id: 'palpitations',
    name: 'Palpitations',
    category: 'Chest & Cardiovascular',
    description: 'Noticeable sensation of a racing, pounding, or fluttering heartbeat.',
    nameTranslations: {
      English: 'Palpitations',
      Hindi: 'दिल की धड़कन तेज होना (Palpitations)',
      Marathi: 'हृदयाचे ठोके जलद पडणे (Palpitations)',
    },
    descriptionTranslations: {
      English: 'Noticeable sensation of a racing, pounding, or fluttering heartbeat.',
      Hindi: 'दिल की धड़कन का असामान्य रूप से तेज, भारी या धक-धक करता हुआ महसूस होना।',
      Marathi: 'हृदयाची धडधड अचानक खूप वाढल्यासारखी किंवा छातीत धडधडल्यासारखे वाटणे.',
    },
  },

  // Musculoskeletal
  {
    id: 'back_pain',
    name: 'Back Pain',
    category: 'Musculoskeletal',
    description: 'Aching, stiffness, or sharp discomfort in the upper, middle, or lower spine.',
    nameTranslations: {
      English: 'Back Pain',
      Hindi: 'पीठ या कमर दर्द (Back Pain)',
      Marathi: 'पाठदुखी किंवा कंबरदुखी (Back Pain)',
    },
    descriptionTranslations: {
      English: 'Aching, stiffness, or sharp discomfort in the upper, middle, or lower spine.',
      Hindi: 'रीढ़ की हड्डी के ऊपरी, मध्य या निचले हिस्से में दर्द और अकड़न।',
      Marathi: 'पाठीत, मणक्यात किंवा कमरेमध्ये तीव्र किंवा सतत दुखणे.',
    },
  },
  {
    id: 'joint_pain',
    name: 'Joint Pain',
    category: 'Musculoskeletal',
    description: 'Discomfort, stiffness, or tenderness in knees, shoulders, hips, hands, or other joints.',
    nameTranslations: {
      English: 'Joint Pain',
      Hindi: 'जोड़ों में दर्द (Joint Pain)',
      Marathi: 'सांधेदुखी (Joint Pain)',
    },
    descriptionTranslations: {
      English: 'Discomfort, stiffness, or tenderness in knees, shoulders, hips, hands, or other joints.',
      Hindi: 'घुटनों, कंधों, कोहनी, हाथों या अन्य जोड़ों में दर्द व सूजन।',
      Marathi: 'गुडघे, खांदे, हात किंवा इतर सांध्यांमध्ये कळा येणे व सूज असणे.',
    },
  },
  {
    id: 'muscle_aches',
    name: 'Muscle Aches (Myalgia)',
    category: 'Musculoskeletal',
    description: 'Generalized soreness, tenderness, or stiffness in muscles throughout the body.',
    nameTranslations: {
      English: 'Muscle Aches (Myalgia)',
      Hindi: 'मांसपेशियों में दर्द (Muscle Aches)',
      Marathi: 'स्नायूंमध्ये दुखणे (Muscle Aches)',
    },
    descriptionTranslations: {
      English: 'Generalized soreness, tenderness, or stiffness in muscles throughout the body.',
      Hindi: 'पूरे शरीर की मांसपेशियों में दर्द, जकड़न या खिंचाव महसूस होना।',
      Marathi: 'संपूर्ण अंगातील स्नायू दुखणे, ताण येणे किंवा जड पडणे.',
    },
  },

  // Skin & Allergies
  {
    id: 'skin_rash',
    name: 'Skin Rash',
    category: 'Skin & Allergies',
    description: 'Changes in skin color, texture, bumps, redness, or itching patches.',
    nameTranslations: {
      English: 'Skin Rash',
      Hindi: 'त्वचा पर दाने या चकत्ते (Skin Rash)',
      Marathi: 'त्वचेवर पुरळ किंवा खाज (Skin Rash)',
    },
    descriptionTranslations: {
      English: 'Changes in skin color, texture, bumps, redness, or itching patches.',
      Hindi: 'त्वचा पर लाल चकत्ते, खुजली, फुंसियां या जलन होना।',
      Marathi: 'त्वचेवर लाल डाग, बारीक फोड, खाज किंवा आग होणे.',
    },
  },
  {
    id: 'burning_urination',
    name: 'Burning with Urination',
    category: 'General & Constitutional',
    description: 'Pain, burning, or stinging sensation when passing urine.',
    nameTranslations: {
      English: 'Burning with Urination',
      Hindi: 'पेशाब में जलन या दर्द (Burning Urination)',
      Marathi: 'लघवी करताना जळजळ (Burning Urination)',
    },
    descriptionTranslations: {
      English: 'Pain, burning, or stinging sensation when passing urine.',
      Hindi: 'पेशाब करते समय दर्द, जलन या चुभन महसूस होना।',
      Marathi: 'लघवी करताना तीव्र आग, जळजळ किंवा वेदना जाणवणे.',
    },
  },
];

export const SYMPTOM_CATEGORIES_TRANSLATIONS: Record<
  'All' | SymptomCategory,
  Record<PreferredLanguage, string>
> = {
  All: {
    English: 'All',
    Hindi: 'सभी',
    Marathi: 'सर्व',
  },
  'General & Constitutional': {
    English: 'General & Constitutional',
    Hindi: 'सामान्य व शारीरिक',
    Marathi: 'सामान्य आणि शारीरिक',
  },
  'Respiratory & Throat': {
    English: 'Respiratory & Throat',
    Hindi: 'श्वसन और गला',
    Marathi: 'श्वसन आणि घसा',
  },
  'Head & Neurological': {
    English: 'Head & Neurological',
    Hindi: 'सिर और तंत्रिका',
    Marathi: 'डोके आणि मज्जासंस्था',
  },
  'Digestive & Abdominal': {
    English: 'Digestive & Abdominal',
    Hindi: 'पाचन और पेट',
    Marathi: 'पचन आणि पोट',
  },
  'Chest & Cardiovascular': {
    English: 'Chest & Cardiovascular',
    Hindi: 'छाती और हृदय',
    Marathi: 'छाती आणि हृदय',
  },
  Musculoskeletal: {
    English: 'Musculoskeletal',
    Hindi: 'मांसपेशियां व जोड़',
    Marathi: 'स्नायू आणि सांधे',
  },
  'Skin & Allergies': {
    English: 'Skin & Allergies',
    Hindi: 'त्वचा और एलर्जी',
    Marathi: 'त्वचा आणि अ‍ॅलर्जी',
  },
};

export interface ConditionRule {
  id: string;
  name: string;
  category: string;
  description: string;
  primarySymptoms: string[]; // Strong associations
  secondarySymptoms: string[]; // Frequent secondary associations
  sources: AuthoritativeSource[];
  nameTranslations: Record<PreferredLanguage, string>;
  descriptionTranslations: Record<PreferredLanguage, string>;
}

export const AUTHORITATIVE_CONDITIONS: ConditionRule[] = [
  {
    id: 'cond_common_cold',
    name: 'Viral Upper Respiratory Infection (Common Cold)',
    category: 'Respiratory',
    description: 'A self-limited viral infection primarily affecting the mucosal lining of the nasal passages and throat.',
    primarySymptoms: ['cold', 'sore_throat', 'cough'],
    secondarySymptoms: ['headache', 'fatigue', 'fever'],
    nameTranslations: {
      English: 'Viral Upper Respiratory Infection (Common Cold)',
      Hindi: 'वायरल ऊपरी श्वसन संक्रमण - सामान्य सर्दी-जुकाम (Common Cold)',
      Marathi: 'व्हायरल वरच्या श्वसनमार्गाचा संसर्ग - सामान्य सर्दी (Common Cold)',
    },
    descriptionTranslations: {
      English: 'A self-limited viral infection primarily affecting the mucosal lining of the nasal passages and throat.',
      Hindi: 'एक सामान्य वायरल संक्रमण जो मुख्य रूप से नाक और गले की श्लेष्मा झिल्ली को प्रभावित करता है।',
      Marathi: 'एक सामान्य विषाणू संसर्ग जो प्रामुख्याने नाक आणि घशाच्या आतील आवरणावर परिणाम करतो.',
    },
    sources: [
      {
        organization: 'CDC',
        title: 'Common Colds: Protect Yourself and Others',
        guidelineTopic: 'Viral Respiratory Pathogens Clinical Information',
      },
      {
        organization: 'NHS UK',
        title: 'Common Cold Health Guidance',
        guidelineTopic: 'NHS Health A-Z: Respiratory Tract Infections',
      },
    ],
  },
  {
    id: 'cond_influenza',
    name: 'Seasonal Influenza (Flu Syndrome)',
    category: 'Respiratory / Systemic',
    description: 'An acute viral infection caused by influenza viruses characterized by rapid onset of systemic and respiratory symptoms.',
    primarySymptoms: ['fever', 'chills', 'muscle_aches', 'fatigue'],
    secondarySymptoms: ['cough', 'sore_throat', 'headache', 'loss_of_appetite'],
    nameTranslations: {
      English: 'Seasonal Influenza (Flu Syndrome)',
      Hindi: 'मौसमी इन्फ्लूएंजा - फ्लू (Seasonal Influenza / Flu)',
      Marathi: 'हंगामी इन्फ्लूएंझा - फ्लू (Seasonal Influenza / Flu)',
    },
    descriptionTranslations: {
      English: 'An acute viral infection caused by influenza viruses characterized by rapid onset of systemic and respiratory symptoms.',
      Hindi: 'इन्फ्लूएंजा वायरस से होने वाला तीव्र संक्रमण, जिसमें अचानक तेज बुखार, बदन दर्द और श्वसन संबंधी लक्षण आते हैं।',
      Marathi: 'इन्फ्लूएंझा विषाणूंमुळे होणारा तीव्र संसर्ग, ज्यामध्ये अचानक ताप, अंगदुखी आणि श्वसनाचा त्रास सुरू होतो.',
    },
    sources: [
      {
        organization: 'WHO',
        title: 'Seasonal Influenza Clinical Overview',
        guidelineTopic: 'WHO Fact Sheets: Influenza Prevention and Management',
      },
      {
        organization: 'CDC',
        title: 'Flu Symptoms & Complications',
        guidelineTopic: 'CDC Influenza Division Guidelines',
      },
    ],
  },
  {
    id: 'cond_acute_bronchitis',
    name: 'Acute Bronchitis (Chest Cold)',
    category: 'Respiratory',
    description: 'Inflammation of the bronchial tubes leading to the lungs, typically occurring after an upper respiratory infection.',
    primarySymptoms: ['cough', 'shortness_of_breath'],
    secondarySymptoms: ['fatigue', 'sore_throat', 'chest_pain', 'fever', 'wheezing'],
    nameTranslations: {
      English: 'Acute Bronchitis (Chest Cold)',
      Hindi: 'तीव्र ब्रोंकाइटिस - सीने की जकड़न व खांसी (Acute Bronchitis)',
      Marathi: 'तीव्र ब्राँकायटिस - छातीतील कफ व खोकला (Acute Bronchitis)',
    },
    descriptionTranslations: {
      English: 'Inflammation of the bronchial tubes leading to the lungs, typically occurring after an upper respiratory infection.',
      Hindi: 'फेफड़ों में जाने वाली श्वास नलियों में सूजन, जो अक्सर सर्दी या जुकाम के बाद विकसित होती है।',
      Marathi: 'फुफ्फुसांकडे जाणाऱ्या श्वासनलिकांमध्ये सूज येणे, जी सहसा सर्दी किंवा खोकल्यानंतर निर्माण होते.',
    },
    sources: [
      {
        organization: 'CDC',
        title: 'Chest Cold (Acute Bronchitis) Diagnosis & Management',
        guidelineTopic: 'CDC Antibiotic Stewardship & Respiratory Guidelines',
      },
      {
        organization: 'NHS UK',
        title: 'Bronchitis Overview and Symptoms',
        guidelineTopic: 'NHS Lung & Respiratory Health Guidelines',
      },
    ],
  },
  {
    id: 'cond_gastroenteritis',
    name: 'Acute Gastroenteritis (Stomach Infection)',
    category: 'Gastrointestinal',
    description: 'Inflammation of the gastrointestinal tract commonly caused by viral or foodborne pathogens, affecting stomach and intestinal function.',
    primarySymptoms: ['nausea', 'vomiting', 'diarrhea', 'abdominal_pain'],
    secondarySymptoms: ['fever', 'loss_of_appetite', 'fatigue', 'dizziness'],
    nameTranslations: {
      English: 'Acute Gastroenteritis (Stomach Infection)',
      Hindi: 'तीव्र गैस्ट्रोएंटेराइटिस - पेट का संक्रमण (Acute Gastroenteritis)',
      Marathi: 'तीव्र गॅस्ट्रोएन्टेरिटिस - पोटाचा संसर्ग (Acute Gastroenteritis)',
    },
    descriptionTranslations: {
      English: 'Inflammation of the gastrointestinal tract commonly caused by viral or foodborne pathogens, affecting stomach and intestinal function.',
      Hindi: 'वायरल या दूषित भोजन-पानी से होने वाला पेट और आंतों का संक्रमण, जिससे उल्टी और दस्त होते हैं।',
      Marathi: 'विषाणू किंवा दूषित अन्नामुळे पोटाचा आणि आतड्यांचा होणारा संसर्ग, ज्यामुळे उलट्या आणि जुलाब होतात.',
    },
    sources: [
      {
        organization: 'NIH / NIDDK',
        title: 'Viral Gastroenteritis ("Stomach Flu") Education',
        guidelineTopic: 'National Institute of Diabetes and Digestive and Kidney Diseases',
      },
      {
        organization: 'WHO',
        title: 'Diarrhoeal Disease Fact Sheet',
        guidelineTopic: 'WHO Global Health Observatories: Gastrointestinal Health',
      },
      {
        organization: 'CDC',
        title: 'Norovirus and Foodborne Infection Guidelines',
        guidelineTopic: 'CDC Division of Foodborne, Waterborne, and Environmental Diseases',
      },
    ],
  },
  {
    id: 'cond_headache_syndrome',
    name: 'Tension-Type Headache or Primary Migraine',
    category: 'Neurological',
    description: 'Common benign primary headache disorders related to muscular contraction, vascular regulation, or neurological sensory processing.',
    primarySymptoms: ['headache'],
    secondarySymptoms: ['nausea', 'dizziness', 'fatigue'],
    nameTranslations: {
      English: 'Tension-Type Headache or Primary Migraine',
      Hindi: 'तनाव सिरदर्द या माइग्रेन (Tension Headache / Migraine)',
      Marathi: 'तणावजन्य डोकेदुखी किंवा मायग्रेन (Tension Headache / Migraine)',
    },
    descriptionTranslations: {
      English: 'Common benign primary headache disorders related to muscular contraction, vascular regulation, or neurological sensory processing.',
      Hindi: 'मांसपेशियों के तनाव, नसों में खिंचाव या संवेदी संवेदनशीलता से जुड़ा सामान्य सिरदर्द या आधासीसी।',
      Marathi: 'स्नायूंचा ताण किंवा मज्जासंस्थेच्या संवेदनशीलतेमुळे उद्भवणारी नेहमीची डोकेदुखी किंवा मायग्रेन.',
    },
    sources: [
      {
        organization: 'NIH / NINDS',
        title: 'Headache Information Page',
        guidelineTopic: 'National Institute of Neurological Disorders and Stroke',
      },
      {
        organization: 'NHS UK',
        title: 'Tension Headaches and Migraine Overview',
        guidelineTopic: 'NHS Neurological Health A-Z',
      },
    ],
  },
  {
    id: 'cond_gerd_gastritis',
    name: 'Acute Gastritis / Gastroesophageal Reflux (GERD)',
    category: 'Gastrointestinal',
    description: 'Irritation of the stomach lining or retrograde flow of gastric acid into the esophagus, producing discomfort.',
    primarySymptoms: ['abdominal_pain', 'nausea'],
    secondarySymptoms: ['chest_pain', 'vomiting', 'loss_of_appetite'],
    nameTranslations: {
      English: 'Acute Gastritis / Gastroesophageal Reflux (GERD)',
      Hindi: 'गैस्ट्राइटिस / एसिड रिफ्लक्स (GERD / Gastritis)',
      Marathi: 'गॅस्ट्रायटिस / आम्लपित्त व ॲसिडिटी (GERD / Gastritis)',
    },
    descriptionTranslations: {
      English: 'Irritation of the stomach lining or retrograde flow of gastric acid into the esophagus, producing discomfort.',
      Hindi: 'पेट की अंदरूनी परत में जलन या पेट के एसिड का भोजन नली में वापस आना, जिससे खट्टी डकारें व जलन होती है।',
      Marathi: 'पोटाच्या आतील आवरणाची जळजळ किंवा जठरातील आम्ल अन्ननलिकेत वर येणे, ज्यामुळे छातीत व पोटात जळजळ होते.',
    },
    sources: [
      {
        organization: 'NIH / NIDDK',
        title: 'Gastritis and Acid Reflux (GERD) in Adults',
        guidelineTopic: 'NIDDK Digestive Diseases Information Program',
      },
      {
        organization: 'NHS UK',
        title: 'Heartburn and Acid Reflux Guidance',
        guidelineTopic: 'NHS Health A-Z: Stomach and Esophageal Conditions',
      },
    ],
  },
  {
    id: 'cond_musculoskeletal_strain',
    name: 'Acute Musculoskeletal Strain or Joint Sprain',
    category: 'Musculoskeletal',
    description: 'Mechanical stress, micro-tearing, or inflammation of skeletal muscles, tendons, or ligamentous tissue around joints.',
    primarySymptoms: ['back_pain', 'joint_pain', 'muscle_aches'],
    secondarySymptoms: ['weakness', 'fatigue'],
    nameTranslations: {
      English: 'Acute Musculoskeletal Strain or Joint Sprain',
      Hindi: 'मांसपेशियों में खिंचाव या मोच (Musculoskeletal Strain / Sprain)',
      Marathi: 'स्नायूंवर ताण किंवा सांध्याची मुरगळ (Strain / Sprain)',
    },
    descriptionTranslations: {
      English: 'Mechanical stress, micro-tearing, or inflammation of skeletal muscles, tendons, or ligamentous tissue around joints.',
      Hindi: 'अत्यधिक शारीरिक भार या गलत खिंचाव से मांसपेशियों, लिगामेंट्स या जोड़ों में सूजन और दर्द।',
      Marathi: 'जास्त ताण किंवा चुकीच्या हालचालींमुळे स्नायू किंवा सांध्यांच्या उतींना होणारी इजा व वेदना.',
    },
    sources: [
      {
        organization: 'NIH / NIAMS',
        title: 'Back Pain and Muscle Strains Information',
        guidelineTopic: 'National Institute of Arthritis and Musculoskeletal and Skin Diseases',
      },
      {
        organization: 'NHS UK',
        title: 'Back Pain and Joint Sprains Care Guide',
        guidelineTopic: 'NHS Musculoskeletal Conditions',
      },
    ],
  },
  {
    id: 'cond_dermatitis_exanthem',
    name: 'Dermatitis or Viral Exanthem',
    category: 'Dermatological',
    description: 'Inflammatory skin reaction or generalized rash associated with viral immune activation, contact allergens, or environmental triggers.',
    primarySymptoms: ['skin_rash'],
    secondarySymptoms: ['fever', 'joint_pain', 'fatigue'],
    nameTranslations: {
      English: 'Dermatitis or Viral Exanthem',
      Hindi: 'डर्मेटाइटिस या वायरल चकत्ते (Dermatitis / Skin Rash)',
      Marathi: 'डर्मेटायटिस किंवा संसर्गजन्य पुरळ (Dermatitis / Skin Rash)',
    },
    descriptionTranslations: {
      English: 'Inflammatory skin reaction or generalized rash associated with viral immune activation, contact allergens, or environmental triggers.',
      Hindi: 'त्वचा की एलर्जी या वायरल संक्रमण के कारण पूरे शरीर पर निकलने वाले लाल दाने या खुजलीदार चकत्ते।',
      Marathi: 'अ‍ॅलर्जी किंवा संसर्गामुळे त्वचेवर उमटणारे लाल पुरळ, खाज किंवा दाहक प्रतिक्रिया.',
    },
    sources: [
      {
        organization: 'CDC',
        title: 'Evaluation of Acute Rashes and Viral Exanthems',
        guidelineTopic: 'CDC Skin Infections & Pediatric Infectious Disease',
      },
      {
        organization: 'NHS UK',
        title: 'Rashes in Adults and Children Guide',
        guidelineTopic: 'NHS Skin Conditions A-Z',
      },
    ],
  },
  {
    id: 'cond_cardiopulmonary_warning',
    name: 'Potential Cardiopulmonary Event (Emergency Warning)',
    category: 'Cardiovascular / Critical Care',
    description: 'A clinical presentation involving chest discomfort and respiratory difficulty that requires urgent evaluation to rule out acute coronary or pulmonary conditions.',
    primarySymptoms: ['chest_pain', 'shortness_of_breath'],
    secondarySymptoms: ['dizziness', 'palpitations', 'weakness', 'fainting'],
    nameTranslations: {
      English: 'Potential Cardiopulmonary Event (Emergency Warning)',
      Hindi: 'संभावित हृदय व फेफड़े संबंधी आपातकाल (Cardiopulmonary Warning)',
      Marathi: 'संभाव्य हृदय किंवा फुफ्फुसाशी संबंधित आणीबाणी (Cardiopulmonary Warning)',
    },
    descriptionTranslations: {
      English: 'A clinical presentation involving chest discomfort and respiratory difficulty that requires urgent evaluation to rule out acute coronary or pulmonary conditions.',
      Hindi: 'छाती में दर्द और सांस लेने में तकलीफ का एक गंभीर संकेत, जिसके लिए तत्काल आपातकालीन जांच की आवश्यकता होती है।',
      Marathi: 'छातीत अस्वस्थता आणि श्वास घेण्यास अडचण दर्शवणारे गंभीर लक्षण, ज्यासाठी त्वरित वैद्यकीय तपासणी आवश्यक आहे.',
    },
    sources: [
      {
        organization: 'CDC',
        title: 'Heart Disease and Stroke Emergency Warning Signs',
        guidelineTopic: 'CDC Division for Heart Disease and Stroke Prevention',
      },
      {
        organization: 'NHS UK',
        title: 'Chest Pain and When to Call 999',
        guidelineTopic: 'NHS Urgent and Emergency Medical Services',
      },
      {
        organization: 'WHO',
        title: 'Cardiovascular Diseases (CVDs) Clinical Fact Sheet',
        guidelineTopic: 'WHO Noncommunicable Diseases Emergency Response',
      },
    ],
  },
  {
    id: 'cond_sinusitis',
    name: 'Acute Sinusitis (Rhinosinusitis)',
    category: 'ENT / Respiratory',
    description: 'Inflammation of the paranasal sinus cavities, frequently triggered by viral upper respiratory infections or allergens.',
    primarySymptoms: ['cold', 'headache'],
    secondarySymptoms: ['sore_throat', 'cough', 'fever', 'fatigue'],
    nameTranslations: {
      English: 'Acute Sinusitis (Rhinosinusitis)',
      Hindi: 'एक्यूट साइनसाइटिस - साइनस संक्रमण (Sinusitis)',
      Marathi: 'तीव्र सायनुसायटिस - सायनस संसर्ग (Sinusitis)',
    },
    descriptionTranslations: {
      English: 'Inflammation of the paranasal sinus cavities, frequently triggered by viral upper respiratory infections or allergens.',
      Hindi: 'चेहरे की साइनस गुहाओं में सूजन और बलगम का जमाव, जो अक्सर जुकाम या एलर्जी के बाद होता है।',
      Marathi: 'सायनसच्या पोकळ्यांमध्ये सूज आणि कफ साठणे, जे सर्दी किंवा अ‍ॅलर्जीनंतर उद्भवते.',
    },
    sources: [
      {
        organization: 'CDC',
        title: 'Sinus Infection (Sinusitis) Features and Care',
        guidelineTopic: 'CDC Antibiotic Prescribing and Use',
      },
      {
        organization: 'NHS UK',
        title: 'Sinusitis (Sinus Infection) Overview',
        guidelineTopic: 'NHS Ear, Nose, and Throat Guidance',
      },
    ],
  },
  {
    id: 'cond_uti',
    name: 'Urinary Tract Infection (UTI Presentation)',
    category: 'Urological',
    description: 'Infection of the bladder or urethra characterized by localized dysuria and frequent urinary discomfort.',
    primarySymptoms: ['burning_urination'],
    secondarySymptoms: ['fever', 'abdominal_pain', 'fatigue', 'back_pain'],
    nameTranslations: {
      English: 'Urinary Tract Infection (UTI Presentation)',
      Hindi: 'मूत्रमार्ग संक्रमण (Urinary Tract Infection - UTI)',
      Marathi: 'मूत्रमार्ग संसर्ग (Urinary Tract Infection - UTI)',
    },
    descriptionTranslations: {
      English: 'Infection of the bladder or urethra characterized by localized dysuria and frequent urinary discomfort.',
      Hindi: 'मूत्राशय या मूत्रमार्ग का संक्रमण, जिसमें पेशाब करते समय दर्द, जलन और बार-बार पेशाब आने की समस्या होती है।',
      Marathi: 'मूत्राशय किंवा मूत्रनलिकेचा संसर्ग, ज्यामध्ये लघवी करताना आग होणे आणि वारंवार लघवी लागणे असे त्रास होतात.',
    },
    sources: [
      {
        organization: 'CDC',
        title: 'Urinary Tract Infection Information for Patients',
        guidelineTopic: 'CDC Antibiotic Guidance & Outpatient Infections',
      },
      {
        organization: 'NIH / NIDDK',
        title: 'Urinary Tract Infections in Adults',
        guidelineTopic: 'NIDDK Kidney and Urologic Diseases Information',
      },
    ],
  },
];

export const GENERAL_SELF_CARE_MEASURES: Record<string, string[]> = {
  default: [
    'Rest and recovery: Allow your body adequate physical rest and 7-9 hours of sleep to support immune function.',
    'Hydration: Drink plenty of clean water, electrolyte broths, or warm herbal teas throughout the day.',
    'Comfort measures: Maintain a well-ventilated, comfortable room temperature.',
    'Avoid self-medication: Do not take unprescribed antibiotics or alter medication dosages without professional clinical consultation.',
  ],
  respiratory: [
    'Humidified air: Use a cool mist humidifier or sit in a warm, steamy bathroom to help loosen airway mucus.',
    'Warm saline gargles: Dissolve 1/2 teaspoon of salt in warm water and gargle to soothe throat irritation (spit out after gargling).',
    'Elevation: Elevate your head slightly with an extra pillow during sleep to reduce nasal congestion.',
    'Avoid irritants: Avoid exposure to tobacco smoke, strong chemical fumes, and airborne allergens.',
  ],
  digestive: [
    'Oral rehydration: Sip small amounts of oral rehydration solution (ORS), clear broths, or water frequently to prevent dehydration.',
    'Bland diet: When ready to eat, follow a gentle bland diet such as bananas, rice, applesauce, toast, or plain porridge.',
    'Avoid triggers: Temporarily refrain from spicy, greasy, highly acidic foods, dairy, caffeine, and alcohol.',
    'Small frequent portions: Eat small portions rather than large meals to reduce gastric stress.',
  ],
  musculoskeletal: [
    'Gentle mobility & rest: Avoid heavy lifting or strenuous exertion while avoiding prolonged complete bed rest.',
    'Temperature application: Apply a cool pack wrapped in a cloth for acute inflammation, or warm compress for muscle stiffness.',
    'Ergonomics: Maintain supportive posture when sitting or standing.',
  ],
};

export const GENERAL_SELF_CARE_MEASURES_I18N: Record<
  string,
  Record<PreferredLanguage, string[]>
> = {
  default: {
    English: [
      'Rest and recovery: Allow your body adequate physical rest and 7-9 hours of sleep to support immune function.',
      'Hydration: Drink plenty of clean water, electrolyte broths, or warm herbal teas throughout the day.',
      'Comfort measures: Maintain a well-ventilated, comfortable room temperature.',
      'Avoid self-medication: Do not take unprescribed antibiotics or alter medication dosages without professional clinical consultation.',
    ],
    Hindi: [
      'पर्याप्त आराम: शरीर की रोग प्रतिरोधक क्षमता को बढ़ाने के लिए पर्याप्त शारीरिक विश्राम और 7-9 घंटे की नींद लें।',
      'शरीर में पानी की मात्रा (Hydration): दिनभर पर्याप्त स्वच्छ पानी, ओआरएस, सूप या गुनगुना पानी पिएं।',
      'हवादार वातावरण: कमरे का तापमान आरामदायक रखें और ताजी हवा का आवागमन सुनिश्चित करें।',
      'स्वयं-दवा लेने से बचें: डॉक्टर के परामर्श के बिना एंटीबायोटिक्स या अन्य दवाएं न लें और न ही खुराक बदलें।',
    ],
    Marathi: [
      'विश्रांती आणि रिकव्हरी: शरीराची प्रतिकारशक्ती वाढवण्यासाठी पुरेशी शारीरिक विश्रांती आणि ७-९ तासांची झोप घ्या.',
      'शरीरात पाण्याचे प्रमाण ठेवा (Hydration): दिवसभरात भरपूर स्वच्छ पाणी, ओआरएस किंवा कोमट पेय प्या.',
      'हवेशीर वातावरण: खोलीचे तापमान आरामदायक ठेवा आणि मोकळी हवा राहू द्या.',
      'स्वतःहून औषधे घेणे टाळा: डॉक्टरांच्या सल्ल्याशिवाय कोणतीही अँटीबायोटिक्स किंवा नवीन औषधे घेऊ नका.',
    ],
  },
  respiratory: {
    English: [
      'Humidified air: Use a cool mist humidifier or sit in a warm, steamy bathroom to help loosen airway mucus.',
      'Warm saline gargles: Dissolve 1/2 teaspoon of salt in warm water and gargle to soothe throat irritation (spit out after gargling).',
      'Elevation: Elevate your head slightly with an extra pillow during sleep to reduce nasal congestion.',
      'Avoid irritants: Avoid exposure to tobacco smoke, strong chemical fumes, and airborne allergens.',
    ],
    Hindi: [
      'भाप या नम हवा: श्वासनली का कफ ढीला करने के लिए भाप लें या ह्यूमिडिफायर का उपयोग करें।',
      'गुनगुने नमक के पानी से गरारे: गले की खराश कम करने के लिए गुनगुने पानी में आधा चम्मच नमक डालकर गरारे करें (पानी थूक दें)।',
      'सिर ऊंचा रखें: सोते समय सिर के नीचे अतिरिक्त तकिया लगाएं ताकि नाक बंद होने में राहत मिले।',
      'उत्तेजक तत्वों से बचाव: सिगरेट के धुएं, तेज रसायनों, धूल और वायु प्रदूषण से दूर रहें।',
    ],
    Marathi: [
      'वाफ घेणे: श्वसनमार्गातील कफ मोकळा करण्यासाठी गरम पाण्याची वाफ घ्या.',
      'मिठाच्या कोमट पाण्याच्या गुळण्या: घशातील खवखव कमी करण्यासाठी कोमट पाण्यात अर्धा चमचा मीठ घालून गुळण्या करा (पाणी थुंकून टाका).',
      'डोके थोडे उंच ठेवा: झोपताना डोक्याखाली उशी थोडी उंच ठेवा जेणेकरून नाक मोकळे राहण्यास मदत होईल.',
      'धूर व धूळ टाळा: तंबाखूचा धूर, रासायनिक वास आणि धूळ यांपासून लांब राहा.',
    ],
  },
  digestive: {
    English: [
      'Oral rehydration: Sip small amounts of oral rehydration solution (ORS), clear broths, or water frequently to prevent dehydration.',
      'Bland diet: When ready to eat, follow a gentle bland diet such as bananas, rice, applesauce, toast, or plain porridge.',
      'Avoid triggers: Temporarily refrain from spicy, greasy, highly acidic foods, dairy, caffeine, and alcohol.',
      'Small frequent portions: Eat small portions rather than large meals to reduce gastric stress.',
    ],
    Hindi: [
      'ओआरएस और तरल पदार्थ: निर्जलीकरण (डिहाइड्रेशन) से बचने के लिए थोड़े-थोड़े अंतराल पर ओआरएस घोल, छाछ या पानी पिएं।',
      'हल्का व सुपाच्य भोजन: भूख लगने पर केला, चावल, मूंग दाल की खिचड़ी, दलिया या टोस्ट जैसा हल्का आहार लें।',
      'परहेज: कुछ समय के लिए तला-भुना, अत्यधिक मसालेदार, खट्टा, कैफीन और शराब पूरी तरह टालें।',
      'थोड़ा-थोड़ा भोजन: पेट पर अतिरिक्त दबाव न डालने के लिए एक साथ भारी भोजन करने के बजाय थोड़ा-थोड़ा खाएं।',
    ],
    Marathi: [
      'ओआरएस (ORS) आणि द्रवपदार्थ: डिहायड्रेशन टाळण्यासाठी थोड्या थोड्या वेळाने ओआरएसचे पाणी, ताक किंवा स्वच्छ पाणी प्या.',
      'हलका आणि पचणारा आहार: भूक लागल्यावर केळी, भात, मऊ खिचडी किंवा टोस्ट यासारखा हलका आहार घ्या.',
      'पथ्य पाळा: तेलकट, अति तिखट, आंबट, चहा-कॉफी आणि मद्यपान काही काळ पूर्णपणे टाळा.',
      'कमी प्रमाणात वारंवार खाणे: पोटावर ताण पडू नये म्हणून एकाच वेळी जास्त न खाता थोडे थोडे खा.',
    ],
  },
  musculoskeletal: {
    English: [
      'Gentle mobility & rest: Avoid heavy lifting or strenuous exertion while avoiding prolonged complete bed rest.',
      'Temperature application: Apply a cool pack wrapped in a cloth for acute inflammation, or warm compress for muscle stiffness.',
      'Ergonomics: Maintain supportive posture when sitting or standing.',
    ],
    Hindi: [
      'हल्की गतिशीलता और आराम: भारी वजन उठाने या कठिन व्यायाम से बचें, लेकिन पूरी तरह से बिस्तर पर पड़े रहने से भी बचें।',
      'सिकाई: ताजी सूजन या चोट पर कपड़े में लपेटकर बर्फ लगाएं, और पुरानी मांसपेशियों की जकड़न पर गर्म सिकाई करें।',
      'सही मुद्रा (Posture): बैठते और खड़े होते समय रीढ़ की हड्डी को सीधा और सहारा देने वाली स्थिति में रखें।',
    ],
    Marathi: [
      'हलकी हालचाल आणि विश्रांती: जड वजन उचलणे टाळा, पण सतत एकाच जागी पडून राहणेही टाळा.',
      'शेक देणे: सूज असल्यास कपड्यात गुंडाळून बर्फ लावा आणि स्नायूंमधील आखडणे कमी करण्यासाठी गरम पाण्याची पिशवी लावा.',
      'योग्य पोश्चर (Posture): बसताना आणि उभे राहताना पाठीचा कणा ताठ व व्यवस्थित ठेवा.',
    ],
  },
};

export const URGENCY_LEVEL_TRANSLATIONS: Record<
  UrgencyLevel,
  Record<PreferredLanguage, string>
> = {
  'Low urgency': {
    English: 'Low urgency',
    Hindi: 'कम तात्कालिकता (Low urgency)',
    Marathi: 'कमी तातडी (Low urgency)',
  },
  'Medical consultation recommended': {
    English: 'Medical consultation recommended',
    Hindi: 'डॉक्टर से परामर्श की सलाह (Consultation recommended)',
    Marathi: 'वैद्यकीय सल्ल्याची शिफारस (Consultation recommended)',
  },
  'Urgent medical attention': {
    English: 'Urgent medical attention',
    Hindi: 'तत्काल आपातकालीन चिकित्सा ध्यान (Urgent medical attention)',
    Marathi: 'तातडीने वैद्यकीय मदत आवश्यक (Urgent medical attention)',
  },
};

export const MANDATORY_DISCLAIMER =
  'This information is provided for educational purposes only and is not intended to diagnose, treat, cure, or prevent any disease. It should not replace advice, diagnosis, or treatment from a qualified healthcare professional.';

export const MANDATORY_DISCLAIMER_I18N: Record<PreferredLanguage, string> = {
  English:
    'This information is provided for educational purposes only and is not intended to diagnose, treat, cure, or prevent any disease. It should not replace advice, diagnosis, or treatment from a qualified healthcare professional.',
  Hindi:
    'यह जानकारी केवल शैक्षणिक उद्देश्यों के लिए प्रदान की गई है और इसका उद्देश्य किसी भी बीमारी का निदान, उपचार, इलाज या रोकथाम करना नहीं है। इसे किसी योग्य स्वास्थ्य देखभाल पेशेवर की सलाह, निदान या उपचार का विकल्प नहीं माना जाना चाहिए।',
  Marathi:
    'ही माहिती केवळ शैक्षणिक हेतूने दिली आहे आणि कोणत्याही आजाराचे निदान, उपचार, निवारण किंवा प्रतिबंध करण्याचा उद्देश नाही. याला कोणत्याही पात्र आरोग्यसेवा व्यावसायिकाचा सल्ला, निदान किंवा उपचारांचा पर्याय मानू नये.',
};

export const SYMPTOM_GUIDE_UI_TRANSLATIONS: Record<
  PreferredLanguage,
  {
    screenTitle: string;
    screenSubtitle: string;
    languageLabel: string;
    headerTitle: string;
    headerSubtitle: string;
    searchPlaceholder: string;
    selectedSymptomsTitle: string;
    selectedCount: string;
    clearAll: string;
    emptyTitle: string;
    emptySubtitle: string;
    availableSymptomsTitle: string;
    tapToSelect: string;
    keySignBadge: string;
    continueToAnalysis: string;
    editSymptoms: string;
    newCheck: string;
    evaluatedSymptomsTitle: string;
    triageLevelLabel: string;
    redFlagsTitle: string;
    redFlagsSubtitle: string;
    possibleCausesTitle: string;
    possibleCausesSubtitle: string;
    matchedTag: string;
    matchingCountTag: string;
    verifiedSourcesTag: string;
    noConditionsFound: string;
    consultDoctorNote: string;
    selfCareTitle: string;
    selfCareSubtitle: string;
    selfCareWarning: string;
    whenToSeeDoctorTitle: string;
    authoritativeRefsTitle: string;
    authoritativeRefsSubtitle: string;
    disclaimerTitle: string;
    noMatchingSearch: string;
    resetSearch: string;
  }
> = {
  English: {
    screenTitle: 'Symptom Guide',
    screenSubtitle: 'Educational Symptom Navigator & Medical Reference',
    languageLabel: 'Language',
    headerTitle: 'Educational Symptom Navigator',
    headerSubtitle:
      'Select what you are experiencing to view associated health conditions, urgency levels, red flags, and safe self-care guidelines sourced from WHO, CDC, and NHS.',
    searchPlaceholder: 'Search symptoms (e.g. fever, cough, headache)...',
    selectedSymptomsTitle: 'Selected Symptoms',
    selectedCount: 'selected',
    clearAll: 'Clear all',
    emptyTitle: 'Select symptoms to get an educational guide.',
    emptySubtitle: 'Choose one or more symptoms below or search to review clinical insights.',
    availableSymptomsTitle: 'Available Symptoms',
    tapToSelect: 'Tap to select',
    keySignBadge: 'Key sign',
    continueToAnalysis: 'Continue to Analysis',
    editSymptoms: 'Edit Symptoms',
    newCheck: 'New Check',
    evaluatedSymptomsTitle: 'Evaluated Symptoms',
    triageLevelLabel: 'Triage Assessment Level',
    redFlagsTitle: 'Important Red Flags to Watch For',
    redFlagsSubtitle:
      'If you or the individual experience any of the following warning signs, seek immediate emergency medical evaluation:',
    possibleCausesTitle: 'Possible Causes & Associated Conditions',
    possibleCausesSubtitle:
      'Your symptoms may be associated with several conditions, including the educational references below. A qualified healthcare professional can perform tests to determine the accurate cause.',
    matchedTag: 'Matched:',
    matchingCountTag: 'matching',
    verifiedSourcesTag: 'Verified Sources:',
    noConditionsFound: 'Verified medical guidelines could not match this exact symptom combination.',
    consultDoctorNote: 'Please consult a physician for a personalized physical assessment.',
    selfCareTitle: 'General Self-Care Information',
    selfCareSubtitle:
      'Safe, general educational measures that may help your body recover. These do not replace medical treatment plans or prescriptions.',
    selfCareWarning:
      'Important: Do not take unprescribed medicines or change existing medication schedules without guidance from a doctor or licensed pharmacist.',
    whenToSeeDoctorTitle: 'When to See a Doctor',
    authoritativeRefsTitle: 'Authoritative Medical References',
    authoritativeRefsSubtitle:
      'This educational guide is built directly upon clinical guidelines published by recognized global health organizations:',
    disclaimerTitle: 'Medical Disclaimer',
    noMatchingSearch: 'No symptoms matching',
    resetSearch: 'Reset search & filters',
  },
  Hindi: {
    screenTitle: 'लक्षण मार्गदर्शिका',
    screenSubtitle: 'शैक्षणिक लक्षण मार्गदर्शक और चिकित्सा संदर्भ',
    languageLabel: 'भाषा',
    headerTitle: 'शैक्षणिक लक्षण मार्गदर्शिका',
    headerSubtitle:
      'आप जो लक्षण महसूस कर रहे हैं उन्हें चुनें ताकि WHO, CDC और NHS के दिशानिर्देशों पर आधारित संबंधित स्वास्थ्य स्थितियां, तात्कालिकता स्तर, चेतावनी संकेत और सुरक्षित देखभाल उपाय देख सकें।',
    searchPlaceholder: 'लक्षण खोजें (उदा. बुखार, खांसी, सिरदर्द)...',
    selectedSymptomsTitle: 'चुने गए लक्षण',
    selectedCount: 'चुने गए',
    clearAll: 'सभी हटाएं',
    emptyTitle: 'शैक्षणिक मार्गदर्शिका प्राप्त करने के लिए लक्षण चुनें।',
    emptySubtitle: 'नीचे दिए गए एक या अधिक लक्षणों को चुनें या खोजें ताकि चिकित्सकीय जानकारी देख सकें।',
    availableSymptomsTitle: 'उपलब्ध लक्षण',
    tapToSelect: 'चुनने के लिए टैप करें',
    keySignBadge: 'मुख्य संकेत',
    continueToAnalysis: 'विश्लेषण देखें',
    editSymptoms: 'लक्षण बदलें',
    newCheck: 'नया परीक्षण',
    evaluatedSymptomsTitle: 'परीक्षण किए गए लक्षण',
    triageLevelLabel: 'चिकित्सकीय मूल्यांकन स्तर',
    redFlagsTitle: 'महत्वपूर्ण चेतावनी संकेत (Red Flags)',
    redFlagsSubtitle:
      'यदि आप या संबंधित व्यक्ति इनमें से कोई भी चेतावनी संकेत महसूस करते हैं, तो तुरंत आपातकालीन चिकित्सा सहायता लें:',
    possibleCausesTitle: 'संभावित कारण और संबंधित स्वास्थ्य स्थितियां',
    possibleCausesSubtitle:
      'आपके लक्षण नीचे दिए गए शैक्षणिक संदर्भों सहित कई स्वास्थ्य स्थितियों से जुड़े हो सकते हैं। एक योग्य स्वास्थ्य पेशेवर सटीक कारण जानने के लिए आवश्यक परीक्षण कर सकते हैं।',
    matchedTag: 'मेल खाने वाले लक्षण:',
    matchingCountTag: 'मेल',
    verifiedSourcesTag: 'सत्यापित स्रोत:',
    noConditionsFound: 'सत्यापित चिकित्सा दिशानिर्देश इस सटीक लक्षण संयोजन से मेल नहीं खा सके।',
    consultDoctorNote: 'कृपया व्यक्तिगत शारीरिक मूल्यांकन के लिए डॉक्टर से परामर्श लें।',
    selfCareTitle: 'सामान्य स्व-देखभाल जानकारी',
    selfCareSubtitle:
      'सुरक्षित, सामान्य शैक्षणिक उपाय जो आपके शरीर को स्वस्थ होने में मदद कर सकते हैं। ये चिकित्सकीय उपचार या नुस्खों का विकल्प नहीं हैं।',
    selfCareWarning:
      'महत्वपूर्ण: डॉक्टर या फार्मासिस्ट के मार्गदर्शन के बिना बिना पर्ची वाली दवाएं न लें और न ही मौजूदा दवाओं का समय बदलें।',
    whenToSeeDoctorTitle: 'डॉक्टर से कब संपर्क करें',
    authoritativeRefsTitle: 'प्रामाणिक चिकित्सा संदर्भ',
    authoritativeRefsSubtitle:
      'यह शैक्षणिक मार्गदर्शिका मान्यता प्राप्त वैश्विक स्वास्थ्य संगठनों द्वारा प्रकाशित नैदानिक दिशानिर्देशों पर आधारित है:',
    disclaimerTitle: 'चिकित्सा अस्वीकरण (Medical Disclaimer)',
    noMatchingSearch: 'कोई मेल खाता लक्षण नहीं मिला',
    resetSearch: 'खोज और फ़िल्टर रीसेट करें',
  },
  Marathi: {
    screenTitle: 'लक्षण मार्गदर्शिका',
    screenSubtitle: 'शैक्षणिक लक्षण मार्गदर्शक आणि वैद्यकीय संदर्भ',
    languageLabel: 'भाषा',
    headerTitle: 'शैक्षणिक लक्षण मार्गदर्शिका',
    headerSubtitle:
      'तुम्हाला जाणवणारी लक्षणे निवडा जेणेकरून WHO, CDC आणि NHS च्या मार्गदर्शक तत्त्वांवर आधारित संभाव्य आजार, तातडीची पातळी, धोक्याचे इशारे आणि सुरक्षित काळजीचे उपाय पाहता येतील.',
    searchPlaceholder: 'लक्षणे शोधा (उदा. ताप, खोकला, डोकेदुखी)...',
    selectedSymptomsTitle: 'निवडलेली लक्षणे',
    selectedCount: 'निवडलेले',
    clearAll: 'सर्व काढा',
    emptyTitle: 'शैक्षणिक मार्गदर्शिका मिळवण्यासाठी लक्षणे निवडा.',
    emptySubtitle: 'वैद्यकीय माहिती पाहण्यासाठी खालीलपैकी एक किंवा अधिक लक्षणे निवडा अथवा शोधा.',
    availableSymptomsTitle: 'उपलब्ध लक्षणे',
    tapToSelect: 'निवडण्यासाठी टॅप करा',
    keySignBadge: 'महत्त्वाचे लक्षण',
    continueToAnalysis: 'विश्लेषण सुरू करा',
    editSymptoms: 'लक्षणे बदला',
    newCheck: 'नवीन तपासणी',
    evaluatedSymptomsTitle: 'तपासलेली लक्षणे',
    triageLevelLabel: 'वैद्यकीय मूल्यांकन पातळी',
    redFlagsTitle: 'महत्त्वाचे धोक्याचे इशारे (Red Flags)',
    redFlagsSubtitle:
      'जर तुम्हाला किंवा संबंधित व्यक्तीला खालीलपैकी कोणताही धोक्याचा इशारा जाणवला, तर त्वरित आपत्कालीन वैद्यकीय मदत घ्या:',
    possibleCausesTitle: 'संभाव्य कारणे आणि संबंधित आजार',
    possibleCausesSubtitle:
      'तुमची लक्षणे खालील शैक्षणिक संदर्भांसह अनेक आजारांशी संबंधित असू शकतात. अचूक कारण शोधण्यासाठी पात्र आरोग्यतज्ज्ञ तपासणी करू शकतात.',
    matchedTag: 'जुळलेली लक्षणे:',
    matchingCountTag: 'जुळणारे',
    verifiedSourcesTag: 'खात्रीशीर संदर्भ:',
    noConditionsFound: 'खात्रीशीर वैद्यकीय मार्गदर्शक तत्त्वांमध्ये हे अचूक लक्षण संयोजन आढळले नाही.',
    consultDoctorNote: 'कृपया वैयक्तिक शारीरिक तपासणीसाठी डॉक्टरांचा सल्ला घ्या.',
    selfCareTitle: 'सामान्य स्व-काळजी माहिती',
    selfCareSubtitle:
      'सुरक्षित, सामान्य शैक्षणिक उपाय जे तुमच्या शरीराला बरे होण्यास मदत करू शकतात. हे वैद्यकीय उपचार किंवा डॉक्टरांच्या औषधांचा पर्याय नाहीत.',
    selfCareWarning:
      'महत्त्वाचे: डॉक्टर किंवा फार्मासिस्टच्या सल्ल्याशिवाय कोणतीही न सुचवलेली औषधे घेऊ नका किंवा चालू औषधांचे वेळापत्रक बदलू नका.',
    whenToSeeDoctorTitle: 'डॉक्टरांना कधी भेटावे',
    authoritativeRefsTitle: 'प्रामाणिक वैद्यकीय संदर्भ',
    authoritativeRefsSubtitle:
      'हे शैक्षणिक मार्गदर्शन मान्यताप्राप्त जागतिक आरोग्य संघटनांनी प्रसिद्ध केलेल्या वैद्यकीय मार्गदर्शक तत्त्वांवर आधारित आहे:',
    disclaimerTitle: 'वैद्यकीय अस्वीकरण (Medical Disclaimer)',
    noMatchingSearch: 'जुळणारे कोणतेही लक्षण आढळले नाही',
    resetSearch: 'शोध आणि फिल्टर्स रीसेट करा',
  },
};
