import { MythCategoryMeta, MythItem } from '../types/myth';

export const MYTH_CATEGORIES: MythCategoryMeta[] = [
  {
    id: 'disease-myths',
    emoji: '🦠',
    iconBg: 'bg-gradient-to-br from-red-500 to-rose-600',
    badgeBg: 'bg-red-100 text-red-800 border-red-200',
    nameEn: 'Disease Myths',
    nameHi: 'बीमारी से जुड़े भ्रम',
    nameMr: 'आजारविषयक समज-गैरसमज',
    descriptionEn: 'Debunking common misconceptions about viral, bacterial, and chronic illnesses.',
    descriptionHi: 'वायरल, बैक्टीरिया और पुरानी बीमारियों के बारे में मिथकों का निवारण।',
    descriptionMr: 'संसर्गजन्य आणि जुनाट आजारांविषयीचे गैरसमज दूर करा.'
  },
  {
    id: 'medicine-myths',
    emoji: '💊',
    iconBg: 'bg-gradient-to-br from-blue-500 to-indigo-600',
    badgeBg: 'bg-blue-100 text-blue-800 border-blue-200',
    nameEn: 'Medicine Myths',
    nameHi: 'दवाइयों से जुड़े भ्रम',
    nameMr: 'औषधांविषयीचे भ्रम',
    descriptionEn: 'Clarifying drug safety, antibiotic usage, dosage, and side effects.',
    descriptionHi: 'दवाओं की सुरक्षा, एंटीबायोटिक्स, खुराक और दुष्प्रभावों की स्पष्टता।',
    descriptionMr: 'औषधांचे प्रमाण, सुरक्षितता आणि प्रतिजैविकांच्या योग्य वापराबद्दल माहिती.'
  },
  {
    id: 'nutrition-myths',
    emoji: '🥗',
    iconBg: 'bg-gradient-to-br from-emerald-500 to-teal-600',
    badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    nameEn: 'Nutrition Myths',
    nameHi: 'पोषण और आहार भ्रम',
    nameMr: 'पोषण व आहारातील भ्रम',
    descriptionEn: 'Busting diet fads, superfood claims, and healthy eating misunderstandings.',
    descriptionHi: 'डाइट ट्रेंड, सुपरफूड के दावों और खान-पान के भ्रम दूर करें।',
    descriptionMr: 'आहार, सुपरफूड्स आणि कॅलरीशी संबंधित गैरसमज.'
  },
  {
    id: 'child-health-myths',
    emoji: '👶',
    iconBg: 'bg-gradient-to-br from-amber-500 to-orange-600',
    badgeBg: 'bg-amber-100 text-amber-800 border-amber-200',
    nameEn: 'Child Health Myths',
    nameHi: 'बाल स्वास्थ्य भ्रम',
    nameMr: 'बालसंगोपन व आरोग्य भ्रम',
    descriptionEn: 'Evidence-based guidance on infant care, childhood vaccination, and growth.',
    descriptionHi: 'शिशु देखभाल, बाल टीकाकरण और विकास पर वैज्ञानिक तथ्य।',
    descriptionMr: 'लहान मुलांचे लसीकरण, पोषण आणि काळजी याबद्दलचे सत्य.'
  },
  {
    id: 'women-health-myths',
    emoji: '🤰',
    iconBg: 'bg-gradient-to-br from-purple-500 to-pink-600',
    badgeBg: 'bg-purple-100 text-purple-800 border-purple-200',
    nameEn: "Women's Health Myths",
    nameHi: 'महिला स्वास्थ्य भ्रम',
    nameMr: 'महिलांचे आरोग्य भ्रम',
    descriptionEn: 'Addressing myths surrounding menstruation, pregnancy, menopause, and hormonal health.',
    descriptionHi: 'मासिक धर्म, गर्भावस्था, रजोनिवृत्ति और हार्मोनल स्वास्थ्य के तथ्य।',
    descriptionMr: 'मासिक पाळी, गर्भधारणा आणि महिलांच्या आरोग्याशी संबंधित तथ्ये.'
  },
  {
    id: 'heart-health-myths',
    emoji: '❤️',
    iconBg: 'bg-gradient-to-br from-rose-600 to-red-700',
    badgeBg: 'bg-rose-100 text-rose-800 border-rose-200',
    nameEn: 'Heart Health Myths',
    nameHi: 'हृदय स्वास्थ्य भ्रम',
    nameMr: 'हृदय आरोग्य भ्रम',
    descriptionEn: 'Understanding blood pressure, cholesterol, heart attack symptoms, and exercise.',
    descriptionHi: 'रक्तचाप, कोलेस्ट्रॉल, दिल का दौरा के लक्षण और व्यायाम के सच।',
    descriptionMr: 'रक्तदाब, कोलेस्टेरॉल आणि हृदयविकाराच्या झटक्याविषयी योग्य माहिती.'
  },
  {
    id: 'diabetes-myths',
    emoji: '🩸',
    iconBg: 'bg-gradient-to-br from-cyan-600 to-blue-700',
    badgeBg: 'bg-cyan-100 text-cyan-800 border-cyan-200',
    nameEn: 'Diabetes Myths',
    nameHi: 'डायबिटीज (मधुमेह) भ्रम',
    nameMr: 'मधुमेह आरोग्य भ्रम',
    descriptionEn: 'Fact-checking sugar intake, insulin therapy, diet control, and cures.',
    descriptionHi: 'चीनी सेवन, इंसुलिन, डाइट नियंत्रण और उपचार के वैज्ञानिक तथ्य।',
    descriptionMr: 'साखरेचे प्रमाण, इन्सुलिन आणि आहारावरील नियंत्रणाचे वास्तव.'
  },
  {
    id: 'mental-health-myths',
    emoji: '🧠',
    iconBg: 'bg-gradient-to-br from-violet-600 to-purple-700',
    badgeBg: 'bg-violet-100 text-violet-800 border-violet-200',
    nameEn: 'Mental Health Myths',
    nameHi: 'मानसिक स्वास्थ्य भ्रम',
    nameMr: 'मानसिक आरोग्य भ्रम',
    descriptionEn: 'Demystifying anxiety, depression, therapy, and mental wellness stigma.',
    descriptionHi: 'चिंता, अवसाद, थेरेपी और मानसिक स्वास्थ्य से जुड़ी गलत धारणाएं।',
    descriptionMr: 'ताणतणाव, नैराश्य आणि मानसिक उपचारांबद्दलचे स्पष्टीकरण.'
  },
  {
    id: 'first-aid-myths',
    emoji: '🚑',
    iconBg: 'bg-gradient-to-br from-emerald-600 to-green-700',
    badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    nameEn: 'First Aid Myths',
    nameHi: 'प्राथमिक चिकित्सा भ्रम',
    nameMr: 'प्रथमोपचार भ्रम',
    descriptionEn: 'Correcting dangerous emergency response practices for burns, bites, and fainting.',
    descriptionHi: 'जलने, काटने और बेहोशी में की जाने वाली खतरनाक गलतियों का सुधार।',
    descriptionMr: 'भाजणे, कीटकदंश आणि आपत्कालीन प्रथमोपचारातील योग्य पद्धती.'
  },
  {
    id: 'general-health-myths',
    emoji: '🛡',
    iconBg: 'bg-gradient-to-br from-slate-600 to-zinc-700',
    badgeBg: 'bg-slate-100 text-slate-800 border-slate-200',
    nameEn: 'General Health Myths',
    nameHi: 'सामान्य स्वास्थ्य भ्रम',
    nameMr: 'सामान्य आरोग्य भ्रम',
    descriptionEn: 'Everyday hygiene, sleep, immune system boosters, and water intake facts.',
    descriptionHi: 'दैनिक स्वच्छता, नींद, रोग प्रतिरोधक क्षमता और पानी पीने से जुड़े सच।',
    descriptionMr: 'दैनंदिन स्वच्छता, झोप, प्रतिकारशक्ती आणि पाणी पिण्याच्या योग्य सवयी.'
  }
];

export const ALL_MYTHS: MythItem[] = [
  // 1. DISEASE MYTHS
  {
    id: 'dm-01',
    categoryId: 'disease-myths',
    tags: ['antibiotics', 'virus', 'infection', 'cold', 'flu'],
    content: {
      English: {
        myth: 'Antibiotics cure viral infections like the common cold or flu.',
        fact: 'Antibiotics only kill bacteria. They have zero effect against viruses.',
        explanation: 'Taking antibiotics for colds or viral sore throats does not speed up recovery. Unnecessary antibiotic use leads to antimicrobial resistance (AMR), making future bacterial infections harder to treat.',
        healthTip: 'Rest, hydration, and symptomatic treatment are best for viral colds. Only take antibiotics when prescribed by a doctor for confirmed bacterial infections.',
        reference: 'World Health Organization (WHO)'
      },
      Hindi: {
        myth: 'एंटीबायोटिक्स सर्दी और फ्लू जैसे वायरल संक्रमण को ठीक करते हैं।',
        fact: 'एंटीबायोटिक्स केवल बैक्टीरिया को मारते हैं। वे वायरस पर काम नहीं करते।',
        explanation: 'वायरल सर्दी या गले में खराश के लिए एंटीबायोटिक लेने से कोई फायदा नहीं होता। बिना जरूरत एंटीबायोटिक लेने से शरीर में एंटीबायोटिक रेजिस्टेंस पैदा होता है।',
        healthTip: 'वायरल सर्दी में आराम, पर्याप्त पानी और डॉक्टर की सलाह से लक्षण आधारित दवा लें।',
        reference: 'विश्व स्वास्थ्य संगठन (WHO)'
      },
      Marathi: {
        myth: 'अँटीबायोटिक्स सर्दी आणि फ्ल्यूसारखे व्हायरल संसर्ग पूर्णपणे बरे करतात.',
        fact: 'अँटीबायोटिक्स फक्त बॅक्टेरियावर (जीवाणू) काम करतात. व्हायरसवर त्यांचा कोणताही परिणाम होत नाही.',
        explanation: 'सर्दी किंवा व्हायरसमुळे होणाऱ्या घशाच्या त्रासासाठी अँटीबायोटिक्स घेतल्याने फरक पडत नाही. उलट अतिवापरामुळे शरीरात अँटीबायोटिक प्रतिकारशक्ती तयार होते.',
        healthTip: 'व्हायरल संसर्गात पुरेसा आराम करा, द्रवपदार्थ घ्या आणि डॉक्टरांच्या सल्ल्यानुसारच औषधे घ्या.',
        reference: 'जागतिक आरोग्य संघटना (WHO)'
      }
    }
  },
  {
    id: 'dm-02',
    categoryId: 'disease-myths',
    tags: ['cold weather', 'fever', 'pneumonia', 'chill'],
    content: {
      English: {
        myth: 'Going out in cold weather causes you to catch a cold or fever.',
        fact: 'Colds are caused by viruses (such as rhinoviruses), not cold temperatures alone.',
        explanation: 'Cold air itself does not contain viruses. However, cold weather causes people to stay indoors close together, making viral transmission via respiratory droplets much higher.',
        healthTip: 'Dress warmly to stay comfortable, but focus on handwashing and mask hygiene to prevent cold viruses.',
        reference: 'Centers for Disease Control and Prevention (CDC)'
      },
      Hindi: {
        myth: 'ठंड के मौसम में बाहर जाने से ही इंसान को सर्दी या बुखार होता है।',
        fact: 'सर्दी वायरस (जैसे राइनोवायरस) से होती है, सिर्फ ठंडी हवा से नहीं।',
        explanation: 'ठंडी हवा में वायरस नहीं होते। हालांकि, सर्दियों में लोग बंद कमरों में पास-पास रहते हैं, जिससे सांस की बूंदों द्वारा वायरस आसानी से फैलता है।',
        healthTip: 'ठंड में गर्म कपड़े पहनें और हाथों को धोकर संक्रमण से बचाव करें।',
        reference: 'सीडीसी (CDC)'
      },
      Marathi: {
        myth: 'थंडीत बाहेर गेल्यामुळेच सर्दी किंवा ताप येतो.',
        fact: 'सर्दी ही व्हायरसमुळे होते, केवळ थंड हवेमुळे नाही.',
        explanation: 'थंड हवेत व्हायरस नसतात. मात्र थंडीच्या दिवसांत लोक घरात एकत्र राहतात, ज्यामुळे संसर्ग वेगाने पसरतो.',
        healthTip: 'उबदार कपडे वापरा आणि वारंवार हात धुण्याची सवय ठेवा.',
        reference: 'सीडीसी (CDC)'
      }
    }
  },
  {
    id: 'dm-03',
    categoryId: 'disease-myths',
    tags: ['dengue', 'papaya leaf', 'platelets', 'mosquito'],
    content: {
      English: {
        myth: 'Papaya leaf juice is a guaranteed complete cure for Dengue fever.',
        fact: 'Dengue has no specific antiviral cure; supportive clinical care and hydration are life-saving.',
        explanation: 'While some studies indicate papaya leaf extract may moderately support platelet production, it does not kill the dengue virus or replace clinical monitoring and fluid management.',
        healthTip: 'Maintain adequate fluid intake (ORS, fluids) and get daily blood tests for platelet and hematocrit monitoring under medical supervision.',
        reference: 'National Health Authority (NHA) / AIIMS'
      },
      Hindi: {
        myth: 'पपीते के पत्तों का रस डेंगू का 100% पक्का इलाज है।',
        fact: 'डेंगू का कोई एक जादूई इलाज नहीं है; पर्याप्त तरल पदार्थ और चिकित्सकीय देखभाल ही असली उपचार है।',
        explanation: 'पपीते के पत्ते का रस प्लेटलेट्स बढ़ाने में कुछ हद तक मदद कर सकता है, लेकिन यह डेंगू वायरस को खत्म नहीं करता। अस्पताल की देखरेख सबसे जरूरी है।',
        healthTip: 'डेंगू में ORS, नारियल पानी और पानी की कमी न होने दें तथा डॉक्टर से नियमित प्लेटलेट जांच कराएं।',
        reference: 'एम्स (AIIMS) और स्वास्थ्य मंत्रालय'
      },
      Marathi: {
        myth: 'पपईच्या पानांचा रस हा डेंग्यूवर शंभर टक्के खात्रीशीर उपाय आहे.',
        fact: 'डेंग्यूवर असा कोणताही एकच चमत्कारिक उपाय नाही; योग्य वैद्यकीय उपचार आणि शरीरातील पाण्याचे प्रमाण टिकवणे महत्त्वाचे आहे.',
        explanation: 'पपईच्या पानांचा रस प्लेटलेट्स वाढवण्यास काही प्रमाणात मदत करू शकतो, पण तो डेंग्यूच्या व्हायरसचा नाश करत नाही.',
        healthTip: 'डेंग्यू झाल्यास ओआरएस आणि भरपूर द्रवपदार्थ प्या, तसेच डॉक्टरांच्या सल्ल्याने प्लेटलेट्स तपासा.',
        reference: 'एम्स (AIIMS) व एनएचए'
      }
    }
  },
  {
    id: 'dm-04',
    categoryId: 'disease-myths',
    tags: ['cancer', 'sugar', 'tumor', 'sweet'],
    content: {
      English: {
        myth: 'Eating sugar causes cancer to grow and spread faster.',
        fact: 'Sugar does not directly cause cancer cells to grow faster than normal cells.',
        explanation: 'All cells in the body use glucose for energy. While excess sugar intake can lead to obesity—which is a risk factor for certain cancers—sugar itself does not directly fuel cancer growth.',
        healthTip: 'Limit added sugars for overall metabolic and cardiovascular health, but do not completely eliminate healthy natural carbohydrates.',
        reference: 'National Cancer Institute (NCI) / Mayo Clinic'
      },
      Hindi: {
        myth: 'चीनी खाने से कैंसर तेजी से बढ़ता और फैलता है।',
        fact: 'चीनी सीधे तौर पर कैंसर कोशिकाओं को सामान्य से तेज नहीं बढ़ाती।',
        explanation: 'शरीर की सभी कोशिकाएं ऊर्जा के लिए ग्लूकोज का उपयोग करती हैं। हालांकि, ज्यादा चीनी से मोटापा बढ़ता है, जो कैंसर का एक जोखिम कारक है, पर चीनी खुद कैंसर नहीं बढ़ाती।',
        healthTip: 'संसाधित चीनी का सेवन सीमित करें, लेकिन प्राकृतिक फल और स्वस्थ कार्बोहाइड्रेट बंद न करें।',
        reference: 'नेशनल कैंसर इंस्टीट्यूट (NCI)'
      },
      Marathi: {
        myth: 'साखर खाल्ल्याने कर्करोग (कॅन्सर) वेगाने वाढतो.',
        fact: 'साखर थेटपणे कॅन्सरच्या पेशींना वाढवत नाही.',
        explanation: 'शरीरातील सर्व पेशी ऊर्जेसाठी ग्लुकोज वापरतात. अति साखरेमुळे लठ्ठपणा येऊ शकतो, जो कॅन्सरसाठी धोकादायक आहे, परंतु साखर स्वतः कॅन्सर वाढवत नाही.',
        healthTip: 'प्रक्रियेतून तयार झालेली साखर कमी करा, परंतु नैसर्गिक कर्बोदके पूर्णपणे बंद करू नका.',
        reference: 'नॅशनल कॅन्सर इन्स्टिट्यूट (NCI)'
      }
    }
  },
  {
    id: 'dm-05',
    categoryId: 'disease-myths',
    tags: ['rabies', 'dog bite', 'chilli powder', 'injection'],
    content: {
      English: {
        myth: 'Applying chilli powder or turmeric on a dog bite prevents rabies.',
        fact: 'Chilli or turmeric does not kill the rabies virus and causes painful tissue damage.',
        explanation: 'Rabies is a 100% fatal viral encephalitis once symptoms appear. Applying home remedies traps virus particles in damaged skin. Immediate washing with soap and running water for 15 minutes is vital.',
        healthTip: 'Wash bite wounds under running water with soap for 15 minutes immediately and take Anti-Rabies Vaccine (ARV) as scheduled.',
        reference: 'World Health Organization (WHO)'
      },
      Hindi: {
        myth: 'कुत्ते के काटने पर मिर्च या हल्दी लगाने से रेबीज से बचाव होता है।',
        fact: 'मिर्च या हल्दी रेबीज के वायरस को नहीं मारती, बल्कि घाव को और गंभीर बनाती है।',
        explanation: 'रेबीज एक जानलेवा बीमारी है। कुत्ता काटने पर घाव को 15 मिनट तक साबुन और बहते पानी से धोना और तुरंत रेबीज का टीका लगवाना ही एकमात्र सुरक्षा है।',
        healthTip: 'कुत्ते के काटने पर तुरंत घाव को 15 मिनट तक साबुन से धोएं और सरकारी अस्पताल में रेबीज का टीका लगवाएं।',
        reference: 'विश्व स्वास्थ्य संगठन (WHO)'
      },
      Marathi: {
        myth: 'कुत्रा चावल्यावर मिरपूड किंवा हळद लावल्यास रेबीज होत नाही.',
        fact: 'मिरपूड किंवा हळद रेबीजच्या व्हायरसला मारू शकत नाही, उलट यामुळे जखम अधिक गंभीर होते.',
        explanation: 'रेबीज हा अत्यंत घातक आजार आहे. कुत्रा चावल्यास जखम ताबडतोब १५ मिनिटे साबण व वाहत्या पाण्याने धुणे आणि रेबीजची लस घेणे आवश्यक आहे.',
        healthTip: 'कुत्रा चावल्यास जखम लगेच १५ मिनिटे साबणाने धुवा आणि तातडीने रेबीज प्रतिबंधक लस घ्या.',
        reference: 'जागतिक आरोग्य संघटना (WHO)'
      }
    }
  },

  // 2. MEDICINE MYTHS
  {
    id: 'mm-01',
    categoryId: 'medicine-myths',
    tags: ['medicine', 'side effects', 'antibiotics', 'stop dose'],
    content: {
      English: {
        myth: 'You can stop taking prescribed medicines as soon as you feel better.',
        fact: 'Stopping medication prematurely can lead to disease relapse and drug resistance.',
        explanation: 'Even if symptoms disappear, bacteria or disease processes may still be active in small numbers. Completing the full course ensures eradication and prevents recurrence.',
        healthTip: 'Always finish your complete prescribed medication course unless advised otherwise by your physician.',
        reference: 'NHS / FDA'
      },
      Hindi: {
        myth: 'जैसे ही आप बेहतर महसूस करें, डॉक्टर की दी गई दवाएं बंद कर देनी चाहिए।',
        fact: 'दवा बीच में छोड़ने से बीमारी दोबारा लौट सकती है और दवा बेअसर हो सकती है।',
        explanation: 'लक्षण ठीक होने के बाद भी शरीर में कुछ कीटाणु बचे हो सकते हैं। पूरा कोर्स करने से बीमारी पूरी तरह समाप्त होती है।',
        healthTip: 'डॉक्टर द्वारा बताए गए कोर्स को पूरा करें, भले ही आप पूरी तरह ठीक महसूस कर रहे हों।',
        reference: 'एनएचएस (NHS)'
      },
      Marathi: {
        myth: 'तब्बेत बरी वाटू लागताच डॉक्टरांनी दिलेली औषधे बंद करावीत.',
        fact: 'औषधांचा कोर्स अधांतरी सोडल्यास आजार पुन्हा उद्भवू शकतो.',
        explanation: 'लक्षणे कमी झाली तरी शरीरात जंतू शिल्लक असू शकतात. पूर्ण कोर्स केल्यानेच आजार पूर्णपणे बरा होतो.',
        healthTip: 'डॉक्टरांनी सांगितलेला औषधांचा पूर्ण कालावधी नक्की पूर्ण करा.',
        reference: 'एनएचएस (NHS)'
      }
    }
  },
  {
    id: 'mm-02',
    categoryId: 'medicine-myths',
    tags: ['herbal', 'natural', 'side effects', 'ayurveda'],
    content: {
      English: {
        myth: 'Herbal and natural medicines are 100% safe and have zero side effects.',
        fact: 'Natural compounds contain active chemicals that can cause toxicities or drug interactions.',
        explanation: 'Plant-based supplements can cause liver strain, kidney issues, or interact dangerously with conventional heart, blood pressure, or blood-thinning medications.',
        healthTip: 'Always inform your doctor about all herbal supplements or traditional remedies you are consuming.',
        reference: 'US Food and Drug Administration (FDA)'
      },
      Hindi: {
        myth: 'आयुर्वेदिक और हर्बल दवाएं 100% सुरक्षित होती हैं और उनका कोई दुष्प्रभाव नहीं होता।',
        fact: 'प्राकृतिक तत्वों में भी सक्रिय रसायन होते हैं जो लीवर या किडनी पर असर डाल सकते हैं।',
        explanation: 'हर्बल दवाएं एलोपैथिक दवाओं (जैसे बीपी या खून पतला करने वाली दवा) के साथ मिलकर नुकसान पहुंचा सकती हैं।',
        healthTip: 'किसी भी हर्बल या आयुर्वेदिक सप्लीमेंट का सेवन करने से पहले डॉक्टर को जरूर बताएं।',
        reference: 'एफडीए (FDA)'
      },
      Marathi: {
        myth: 'वनस्पतीजन्य आणि आयुर्वेदिक औषधे शंभर टक्के सुरक्षित असतात व त्यांचे कोणतेही दुष्परिणाम होत नाहीत.',
        fact: 'नैसर्गिक घटकांमध्येही तीव्र रसायने असतात, जी यकृत व मूत्रपिंडावर ताण आणू शकतात.',
        explanation: 'हर्बल औषधे बीपी किंवा रक्त पातळ करणाऱ्या इतर औषधांसोबत प्रतिक्रिया करू शकतात.',
        healthTip: 'कोणतेही हर्बल किंवा आयुर्वेदिक औषध घेण्यापूर्वी डॉक्टरांचा सल्ला नक्की घ्या.',
        reference: 'एफडीए (FDA)'
      }
    }
  },
  {
    id: 'mm-03',
    categoryId: 'medicine-myths',
    tags: ['painkillers', 'addiction', 'paracetamol', 'ibuprofen'],
    content: {
      English: {
        myth: 'Taking pain relievers like Paracetamol frequently causes instant organ addiction.',
        fact: 'When taken at recommended medical dosages, Paracetamol is safe and non-addictive.',
        explanation: 'Paracetamol does not act on opioid receptors and is not habit-forming. However, exceeding the daily limit (4,000 mg/day) can lead to severe liver damage.',
        healthTip: 'Follow dosing instructions carefully and never exceed 4 grams of Paracetamol in 24 hours.',
        reference: 'Mayo Clinic / British Pharmacopoeia'
      },
      Hindi: {
        myth: 'पैरासिटामॉल जैसी दर्द निवारक दवाएं लेने से तुरंत नशा या आदत पड़ जाती है।',
        fact: 'डॉक्टर द्वारा बताई गई सही मात्रा में लेने पर पैरासिटामॉल सुरक्षित है और इसकी आदत नहीं पड़ती।',
        explanation: 'पैरासिटामॉल शरीर में लत नहीं बनाती। लेकिन 24 घंटे में 4000 मिग्रा से अधिक लेने पर लीवर को नुकसान पहुंच सकता है।',
        healthTip: 'दवा के पैकेट पर दी गई खुराक का पालन करें और ओवरडोज से बचें।',
        reference: 'मेयो क्लीनिक (Mayo Clinic)'
      },
      Marathi: {
        myth: 'पॅरासिटामॉलसारखी वेदनाशामक औषधे वारंवार घेतल्यास त्याचे व्यसन लागते.',
        fact: 'योग्य प्रमाणात आणि आवश्यकतेनुसार घेतल्यास पॅरासिटामॉलचे कोणतेही व्यसन लागत नाही.',
        explanation: 'पॅरासिटामॉलची सवय लागत नाही, मात्र एका दिवसात ४ ग्रॅमपेक्षा जास्त घेतल्यास यकृताला हानी पोहोचू शकते.',
        healthTip: 'औषधाचे योग्य प्रमाण पाळा आणि स्वतःच्या मनाने प्रमाणाबाहेर औषध घेऊ नका.',
        reference: 'मेयो क्लिनिक (Mayo Clinic)'
      }
    }
  },
  {
    id: 'mm-04',
    categoryId: 'medicine-myths',
    tags: ['generic', 'brand name', 'pharmacy', 'cost'],
    content: {
      English: {
        myth: 'Generic medicines are inferior in quality compared to costly branded medicines.',
        fact: 'Generic medicines contain the exact same active pharmaceutical ingredient (API), strength, and safety as branded drugs.',
        explanation: 'Regulatory bodies (such as CDSCO and FDA) enforce identical bioequivalence standards for generic medicines. Generic versions cost significantly less because manufacturers do not re-conduct original clinical trials.',
        healthTip: 'Ask your physician or pharmacist for quality-assured Jan Aushadhi or bioequivalent generic medicines to reduce healthcare costs.',
        reference: 'Indian Council of Medical Research (ICMR) / FDA'
      },
      Hindi: {
        myth: 'जेनेरिक दवाएं ब्रांडेड दवाओं की तुलना में घटिया और कम असरदार होती हैं।',
        fact: 'जेनेरिक दवाओं में वही मुख्य सॉल्ट, गुणवत्ता और प्रभावशीलता होती है जो ब्रांडेड दवाओं में होती है।',
        explanation: 'जेनेरिक दवाएं इसलिए सस्ती होती हैं क्योंकि उनके निर्माण में विज्ञापन और दोबारा क्लीनिकल ट्रायल का खर्च नहीं होता। सरकारी जांच में दोनों समान पाई जाती हैं।',
        healthTip: 'जन औषधि केंद्र से सस्ती और असरदार जेनेरिक दवाएं खरीदकर इलाज का खर्च घटाएं।',
        reference: 'आईसीएमआर (ICMR)'
      },
      Marathi: {
        myth: 'जेनेरिक औषधे ही महागड्या ब्रँडेड औषधांपेक्षा कमी दर्जाची असतात.',
        fact: 'जेनेरिक औषधांमध्ये तेच मुख्य घटक, ताकद आणि गुणवत्ता असते जी ब्रँडेड औषधांमध्ये असते.',
        explanation: 'जेनेरिक औषधांवर जाहिरात आणि संशोधनाचा मोठा खर्च होत नसल्यामुळे ती स्वस्त मिळतात.',
        healthTip: 'जन औषधी केंद्रातून गुणवत्तापूर्ण जेनेरिक औषधे घेऊन वैद्यकीय खर्च कमी करा.',
        reference: 'आयसीएमआर (ICMR)'
      }
    }
  },

  // 3. NUTRITION MYTHS
  {
    id: 'nm-01',
    categoryId: 'nutrition-myths',
    tags: ['carbs', 'weight loss', 'rice', 'roti', 'fat'],
    content: {
      English: {
        myth: 'Carbohydrates make you fat, so you must completely cut out rice and wheat to lose weight.',
        fact: 'Carbohydrates are your body’s primary energy source; weight gain is caused by total calorie excess, not carbs alone.',
        explanation: 'Complex carbohydrates (whole grains, millets, oats) supply fiber, vitamins, and sustained energy. Eliminating them entirely can cause fatigue, muscle loss, and digestive issues.',
        healthTip: 'Choose whole grains and control portion sizes rather than eliminating carbohydrates completely.',
        reference: 'Harvard T.H. Chan School of Public Health'
      },
      Hindi: {
        myth: 'कार्बोहाइड्रेट खाने से मोटापा बढ़ता है, इसलिए वजन घटाने के लिए चावल-रोटी बंद कर देनी चाहिए।',
        fact: 'कार्बोहाइड्रेट शरीर की मुख्य ऊर्जा हैं; मोटापा ज्यादा कैलोरी खाने से बढ़ता है, सिर्फ कार्बोहाइड्रेट से नहीं।',
        explanation: 'ब्राउन राइस, ज्वार, बाजरा, गेहूं से शरीर को फाइबर और विटामिन मिलते हैं। इन्हें पूरी तरह छोड़ना सेहत के लिए हानिकारक है।',
        healthTip: 'अपनी थाली में साबुत अनाज शामिल करें और संतुलित मात्रा में खाएं।',
        reference: 'हार्वर्ड पब्लिक हेल्थ'
      },
      Marathi: {
        myth: 'कार्बोहायड्रेट्समुळे वजन वाढते, त्यामुळे भात आणि पोळी पूर्णपणे बंद केली पाहिजे.',
        fact: 'कार्बोहायड्रेट्स हे शरीराच्या ऊर्जेचे मुख्य स्त्रोत आहेत; वजन हे एकूण जास्त कॅलरींमुळे वाढते.',
        explanation: 'ज्वारी, बाजरी आणि गव्हातून शरीराला फायबर मिळते. कार्बोहायड्रेट्स पूर्णपणे बंद केल्याने थकवा येतो.',
        healthTip: 'धान्याचे प्रमाण योग्य ठेवा आणि रोजच्या आहारात फायबरचा समावेश करा.',
        reference: 'हार्वर्ड पब्लिक हेल्थ'
      }
    }
  },
  {
    id: 'nm-02',
    categoryId: 'nutrition-myths',
    tags: ['detox', 'juicing', 'cleansing', 'lemon water'],
    content: {
      English: {
        myth: 'Detox teas and juice cleanses are necessary to flush toxins out of your body.',
        fact: 'Your liver and kidneys naturally detoxify your body 24 hours a day.',
        explanation: 'Commercial detox products lack scientific evidence and often act as laxatives or diuretics. Extreme juice fasts can cause electrolyte imbalances and muscle loss.',
        healthTip: 'Drink plenty of water, eat fiber-rich fruits and vegetables, and avoid smoking and alcohol to support your natural organ detoxification.',
        reference: 'British Dietetic Association (BDA)'
      },
      Hindi: {
        myth: 'शरीर से टॉक्सिन्स बाहर निकालने के लिए डिटॉक्स जूस और चाय पीना जरूरी है।',
        fact: 'आपका लीवर और किडनी शरीर को प्राकृतिक रूप से 24 घंटे डिटॉक्स करते हैं।',
        explanation: 'डिटॉक्स ड्रिंक्स का कोई वैज्ञानिक आधार नहीं है। अत्यधिक डिटॉक्स जूस पीने से कमजोरी और इलेक्ट्रोलाइट का संतुलन बिगड़ सकता है।',
        healthTip: 'पर्याप्त पानी पिएं, ताजे फल-सब्जियां खाएं और लीवर-किडनी को प्राकृतिक रूप से स्वस्थ रखें।',
        reference: 'ब्रिटिश डाइटेटिक एसोसिएशन (BDA)'
      },
      Marathi: {
        myth: 'शरीरातील विषारी घटक बाहेर काढण्यासाठी डिटॉक्स ज्यूस किंवा डिटॉक्स टी पिणे आवश्यक आहे.',
        fact: 'तुमचे यकृत (लिव्हर) आणि मूत्रपिंड (किडनी) २४ तास शरीराची नैसर्गिक स्वच्छता करतात.',
        explanation: 'डिटॉक्स ड्रिंक्सचा कोणताही वैज्ञानिक पुरावा नाही. फक्त ज्यूसवर राहिल्याने अशक्तपणा येतो.',
        healthTip: 'भरपूर पाणी प्या, हिरव्या भाज्या खा आणि यकृत निरोगी ठेवा.',
        reference: 'ब्रिटिश डाएटेटिक असोसिएशन (BDA)'
      }
    }
  },
  {
    id: 'nm-03',
    categoryId: 'nutrition-myths',
    tags: ['fat free', 'oil', 'ghee', 'cholesterol'],
    content: {
      English: {
        myth: 'All dietary fats are bad for health and should be avoided completely.',
        fact: 'Healthy fats are essential for brain function, hormone production, and nutrient absorption.',
        explanation: 'Monounsaturated and polyunsaturated fats (found in nuts, seeds, olive oil, mustard oil) protect the heart. Saturated fats and trans fats should be consumed in moderation.',
        healthTip: 'Include moderate amounts of healthy cold-pressed oils, nuts, and seeds in your daily meals.',
        reference: 'American Heart Association (AHA)'
      },
      Hindi: {
        myth: 'सभी प्रकार का फैट (वसा) सेहत के लिए बुरा होता है और इसे बिल्कुल नहीं खाना चाहिए।',
        fact: 'स्वस्थ फैट दिमाग, हार्मोन और पोषक तत्वों के अवशोषण के लिए बेहद जरूरी हैं।',
        explanation: 'अखरोट, बादाम, सरसों के तेल और बीज में मिलने वाला गुड फैट दिल की रक्षा करता है। केवल ट्रांस फैट और जंक फूड से बचना चाहिए।',
        healthTip: 'भोजन में सीमित मात्रा में शुद्ध तेल, घी और मेवे शामिल करें।',
        reference: 'अमेरिकन हार्ट एसोसिएशन (AHA)'
      },
      Marathi: {
        myth: 'आहारातील सर्व प्रकारचे स्निग्ध पदार्थ (फॅट्स) शरीरासाठी घातक असतात.',
        fact: 'मेंदूचे कार्य आणि संप्रेरकांसाठी (हार्मोन) निरोगी फॅट्स अत्यंत आवश्यक आहेत.',
        explanation: 'बदाम, अक्रोड, बिया आणि मोहरीच्या तेलातील फॅट्स हृदयासाठी चांगले असतात. फक्त जंक फूडमधील ट्रान्स फॅट्स टाळावेत.',
        healthTip: 'रोजच्या आहारात योग्य प्रमाणात सुकामेवा आणि निरोगी तेलाचा वापर करा.',
        reference: 'अमेरिकन हार्ट असोसिएशन (AHA)'
      }
    }
  },

  // 4. CHILD HEALTH MYTHS
  {
    id: 'cm-01',
    categoryId: 'child-health-myths',
    tags: ['vaccine', 'autism', 'children', 'immunization'],
    content: {
      English: {
        myth: 'Vaccines cause autism and overload a child’s immune system.',
        fact: 'Decades of extensive global studies prove vaccines do not cause autism and are safe.',
        explanation: 'The single 1998 study claiming a vaccine-autism link was completely debunked, retracted, and found to be fraudulent. Vaccines strengthen a child’s immune system against lethal diseases.',
        healthTip: 'Follow the national immunization schedule strictly to protect your child from preventable severe diseases.',
        reference: 'WHO / American Academy of Pediatrics (AAP)'
      },
      Hindi: {
        myth: 'टीके लगाने से बच्चों में ऑटिज्म होता है और इम्यून सिस्टम कमजोर होता है।',
        fact: 'कई वर्षों के वैश्विक शोध से साबित हुआ है कि टीकों का ऑटिज्म से कोई संबंध नहीं है।',
        explanation: 'टीके बच्चों के रोग प्रतिरोधक तंत्र को खसरा, पोलियो और काली खांसी जैसी जानलेवा बीमारियों से लड़ने के लिए मजबूत बनाते हैं।',
        healthTip: 'अपने बच्चे का समय पर और पूरा टीकाकरण करवाएं।',
        reference: 'डब्ल्यूएचओ (WHO) और एएपी'
      },
      Marathi: {
        myth: 'लसीकरणामुळे मुलांमध्ये ऑटिझम (मतिमंदत्व) होतो आणि प्रतिकारशक्ती बिघडते.',
        fact: 'जागतिक संशोधनातून सिद्ध झाले आहे की लसींचा आणि ऑटिझमचा कोणताही संबंध नाही.',
        explanation: 'लसी मुलांची प्रतिकारशक्ती वाढवतात आणि पोलिओ, गोवर यांसारख्या गंभीर आजारांपासून संरक्षण करतात.',
        healthTip: 'मुलांचे राष्ट्रीय लस वेळापत्रकानुसार वेळेवर लसीकरण पूर्ण करा.',
        reference: 'डब्ल्यूएचओ (WHO)'
      }
    }
  },
  {
    id: 'cm-02',
    categoryId: 'child-health-myths',
    tags: ['baby walker', 'walking', 'infant', 'development'],
    content: {
      English: {
        myth: 'Baby walkers help infants learn to walk faster and strengthen leg muscles.',
        fact: 'Baby walkers actually delay independent walking and pose high physical injury risks.',
        explanation: 'Walkers allow babies to move without developing proper hip alignment or abdominal core muscles. They also account for thousands of stair falls and head injuries globally.',
        healthTip: 'Provide supervised floor "tummy time" and let your baby learn to crawl and pull themselves up naturally.',
        reference: 'American Academy of Pediatrics (AAP)'
      },
      Hindi: {
        myth: 'बेबी वॉकर से बच्चा जल्दी चलना सीखता है और पैर मजबूत होते हैं।',
        fact: 'बेबी वॉकर से बच्चा वास्तव में खुद से चलना सीखने में देर करता है और चोट का खतरा बढ़ता है।',
        explanation: 'वॉकर में बच्चा बिना पैरों पर जोर दिए घिसटता है, जिससे मांसपेशियों का सही विकास रुकता है और गिरने का जोखिम रहता है।',
        healthTip: 'बच्चे को फर्श पर टमी टाइम दें और उसे प्राकृतिक रूप से रेंगने और खड़े होने दें।',
        reference: 'अमेरिकन अकेडमी ऑफ पेडियाट्रिक्स (AAP)'
      },
      Marathi: {
        myth: 'बेबी वॉकर वापरल्यामुळे मूल लवकर चालायला शिकते.',
        fact: 'बेबी वॉकरमुळे मूल स्वतःहून चालायला शिकण्यास उशीर होतो आणि अपघाताचा धोका वाढतो.',
        explanation: 'वॉकरमुळे पायाच्या स्नायूंचा योग्य विकास होत नाही आणि पायरीवरून पडण्याची भीती असते.',
        healthTip: 'बाळाला जमिनीवर खेळू द्या आणि नैसर्गिकरीत्या उभे राहू द्या.',
        reference: 'अमेरिकन अकॅडमी ऑफ पेडियाट्रिक्स (AAP)'
      }
    }
  },

  // 5. WOMEN'S HEALTH MYTHS
  {
    id: 'wm-01',
    categoryId: 'women-health-myths',
    tags: ['period', 'menstruation', 'exercise', 'hair wash', 'pickle'],
    content: {
      English: {
        myth: 'Women should avoid exercising, washing hair, or eating sour foods during menstruation.',
        fact: 'Menstruation is a normal biological process; gentle exercise and hygiene are beneficial.',
        explanation: 'Washing hair or eating sour food like pickles has zero biological impact on menstrual flow. Light exercise releases endorphins, which help relieve painful cramps.',
        healthTip: 'Maintain warm baths, stay hydrated, and practice light stretching or walking during periods.',
        reference: 'UNICEF / Federation of Obstetric and Gynecological Societies of India (FOGSI)'
      },
      Hindi: {
        myth: 'पीरियड्स के दौरान महिलाओं को बाल धोने, व्यायाम करने या खट्टा खाने से बचना चाहिए।',
        fact: 'पीरियड्स एक सामान्य जैविक प्रक्रिया है; स्वच्छता और हल्का व्यायाम दर्द में राहत देता है।',
        explanation: 'बाल धोने या खट्टा खाने से पीरियड के बहाव पर कोई असर नहीं पड़ता। हल्का टहलना और योग पेट के दर्द और ऐंठन को कम करता है।',
        healthTip: 'पीरियड्स में व्यक्तिगत स्वच्छता बनाए रखें और गुनगुने पानी से स्नान करें।',
        reference: 'यूनिसेफ (UNICEF) और FOGSI'
      },
      Marathi: {
        myth: 'मासिक पाळीदरम्यान महिलांनी केस धुणे, व्यायाम करणे किंवा आंबट पदार्थ खाणे टाळावे.',
        fact: 'मासिक पाळी ही नैसर्गिक प्रक्रिया आहे; स्वच्छता राखणे आणि सौम्य व्यायाम करणे फायदेशीर ठरते.',
        explanation: 'केस धुण्याचा किंवा आंबट खाण्याचा रक्ताभिसरणावर कोणताही वाईट परिणाम होत नाही. उलट व्यायामाने पोटदुखी कमी होते.',
        healthTip: 'मासिक पाळीच्या काळात उबदार पाण्याने आंघोळ करा आणि योगासने करा.',
        reference: 'युनिसेफ (UNICEF)'
      }
    }
  },
  {
    id: 'wm-02',
    categoryId: 'women-health-myths',
    tags: ['pcos', 'infertility', 'pregnancy', 'weight'],
    content: {
      English: {
        myth: 'PCOS (Polycystic Ovary Syndrome) means you are permanently infertile and cannot get pregnant.',
        fact: 'Most women with PCOS can get pregnant naturally or with simple lifestyle interventions.',
        explanation: 'PCOS affects ovulation consistency, but with weight management, healthy nutrition, and medical ovulation support when needed, pregnancy rates are very high.',
        healthTip: 'Focus on low-glycemic nutrition, regular physical activity, and consult a gynecologist early for PCOS management.',
        reference: 'American College of Obstetricians and Gynecologists (ACOG)'
      },
      Hindi: {
        myth: 'PCOS होने का मतलब है कि महिला कभी मां नहीं बन सकती और वह हमेशा बांझ रहेगी।',
        fact: 'PCOS से पीड़ित अधिकांश महिलाएं सही जीवनशैली और इलाज से आसानी से गर्भधारण कर सकती हैं।',
        explanation: 'PCOS में ओव्यूलेशन अनियमित होता है। वजन नियंत्रण, संतुलित आहार और डॉक्टर की सलाह से गर्भधारण संभव है।',
        healthTip: 'व्यायाम करें, मीठा और जंक फूड कम करें और गाइनेकोलॉजिस्ट की सलाह लें।',
        reference: 'एसीओजी (ACOG)'
      },
      Marathi: {
        myth: 'PCOS मुळे स्त्री कधीही गरोदर राहू शकत नाही.',
        fact: 'PCOS असूनही योग्य जीवनशैली आणि उपचारांच्या मदतीने महिला आई होऊ शकतात.',
        explanation: 'PCOS मुळे बीजांड तयार होण्यात अडथळा येतो, परंतु वजन नियंत्रण आणि उपचारांनी ही समस्या सुटू शकते.',
        healthTip: 'नियमित व्यायाम करा, आहार नियंत्रित ठेवा आणि स्त्रीरोग तज्ज्ञांचा सल्ला घ्या.',
        reference: 'एसीओजी (ACOG)'
      }
    }
  },

  // 6. HEART HEALTH MYTHS
  {
    id: 'hm-01',
    categoryId: 'heart-health-myths',
    tags: ['heart attack', 'chest pain', 'women', 'young people'],
    content: {
      English: {
        myth: 'Heart attacks always present with crushing left chest pain; young people never get them.',
        fact: 'Heart attacks can present as jaw pain, breathlessness, nausea, or back pain, especially in women.',
        explanation: 'A significant portion of heart attacks (especially in women and diabetics) lack severe chest pain. Furthermore, sedentary lifestyles and stress have increased heart attacks in young adults under 40.',
        healthTip: 'Never ignore unusual upper body discomfort, severe sweating, or sudden breathlessness—seek emergency medical help immediately.',
        reference: 'American Heart Association (AHA)'
      },
      Hindi: {
        myth: 'हार्ट अटैक में हमेशा छाती के बाएं तरफ तेज दर्द होता है और युवाओं को हार्ट अटैक नहीं होता।',
        fact: 'हार्ट अटैक में जबड़े का दर्द, सांस फूलना, उल्टी या पीठ दर्द भी हो सकता है; युवा भी इसके शिकार हो रहे हैं।',
        explanation: 'महिलाओं और डायबिटीज के मरीजों में छाती में दर्द के बिना भी साइलेंट अटैक हो सकता है। तनाव और खराब लाइफस्टाइल से युवाओं में भी केस बढ़ रहे हैं।',
        healthTip: 'अचानक पसीना आने, सांस फूलने या जबड़े/पीठ में दर्द को अनदेखा न करें और तुरंत अस्पताल जाएं।',
        reference: 'अमेरिकन हार्ट एसोसिएशन (AHA)'
      },
      Marathi: {
        myth: 'हृदयविकाराच्या झटक्यात फक्त छातीच्या डाव्या बाजूलाच तीव्र वेदना होतात.',
        fact: 'हृदयविकाराच्या झटक्यात जबडा, पाठ किंवा पोटात दुखणे आणि धाप लागणे अशीही लक्षणे दिसू शकतात.',
        explanation: 'स्त्रिया आणि मधुमेही रुग्णांमध्ये छातीत दुखण्याव्यतिरिक्त इतर लक्षणे अधिक दिसतात. सध्या तरुणांमध्येही याचे प्रमाण वाढले आहे.',
        healthTip: 'अचानक येणारा घाम, धाप लागणे किंवा जबड्यात दुखणे याकडे दुर्लक्ष करू नका.',
        reference: 'अमेरिकन हार्ट असोसिएशन (AHA)'
      }
    }
  },

  // 7. DIABETES MYTHS
  {
    id: 'dm-10',
    categoryId: 'diabetes-myths',
    tags: ['diabetes', 'sugar', 'sweets', 'insulin'],
    content: {
      English: {
        myth: 'Eating too much sugar is the direct sole cause of diabetes.',
        fact: 'Type 1 diabetes is autoimmune; Type 2 is driven by genetics, obesity, physical inactivity, and insulin resistance.',
        explanation: 'While consuming sugary drinks contributes to weight gain—which increases Type 2 risk—sugar intake alone does not directly cause diabetes without underlying metabolic factors.',
        healthTip: 'Focus on regular exercise, maintaining a healthy weight, and eating balanced whole foods to reduce diabetes risk.',
        reference: 'American Diabetes Association (ADA)'
      },
      Hindi: {
        myth: 'केवल ज्यादा मीठा या चीनी खाने से ही डायबिटीज (मधुमेह) होती है।',
        fact: 'टाइप 1 जेनेटिक/इम्यून बीमारी है; टाइप 2 डायबिटीज मोटापा, शारीरिक निष्क्रियता और तनाव से होती है।',
        explanation: 'ज्यादा मीठा खाने से वजन बढ़ता है जिससे इंसुलिन रेजिस्टेंस का खतरा बढ़ता है, पर मीठा खुद सीधे डायबिटीज का एकमात्र कारण नहीं है।',
        healthTip: 'वजन नियंत्रित रखें, रोज 30 मिनट टहलें और संतुलित भोजन करें।',
        reference: 'अमेरिकन डायबिटीज एसोसिएशन (ADA)'
      },
      Marathi: {
        myth: 'फक्त खूप गोड किंवा साखर खाल्ल्यामुळेच मधुमेह (डायबिटीज) होतो.',
        fact: 'टाइप १ हा प्रतिकारशक्तीच्या दोषाने होतो; टाइप २ हा लठ्ठपणा, आळशी जीवनशैली व जनुकांमुळे होतो.',
        explanation: 'अति गोड खाल्ल्याने वजन वाढते ज्यामुळे मधुमेहाचा धोका वाढतो, पण केवळ साखर खाणे हे एकमेव कारण नाही.',
        healthTip: 'रोज ३० मिनिटे चाला, वजन नियंत्रणात ठेवा आणि संतुलित आहार घ्या.',
        reference: 'अमेरिकन डायबिटीज असोसिएशन (ADA)'
      }
    }
  },

  // 8. MENTAL HEALTH MYTHS
  {
    id: 'mhm-01',
    categoryId: 'mental-health-myths',
    tags: ['depression', 'sadness', 'mental health', 'willpower'],
    content: {
      English: {
        myth: 'Depression is just sadness or weakness that you can snap out of with positive thinking.',
        fact: 'Depression is a medical condition involving brain chemistry, genetics, and environment.',
        explanation: 'Telling someone with clinical depression to "just be positive" is like telling a diabetic to produce insulin through willpower. Professional counseling and therapy are effective medical treatments.',
        healthTip: 'Seek support from a psychiatrist or licensed clinical psychologist if persistent low mood affects your daily life.',
        reference: 'National Institute of Mental Health (NIMH)'
      },
      Hindi: {
        myth: 'डिप्रेशन (अवसाद) सिर्फ एक दिमागी कमजोरी है जिसे सोच बदलकर तुरंत ठीक किया जा सकता है।',
        fact: 'डिप्रेशन एक गंभीर चिकित्सीय बीमारी है जिसमें न्यूरोट्रांसमीटर और मस्तिष्क रसायन शामिल होते हैं।',
        explanation: 'डिप्रेशन से पीड़ित व्यक्ति को "पॉजिटिव सोचो" कहना काफी नहीं है। इसे सही थेरेपी, काउंसलिंग और डॉक्टर की सलाह से ही ठीक किया जाता है।',
        healthTip: 'मानसिक तनाव या अवसाद महसूस होने पर बिना झिझक काउंसलर या मनोचिकित्सक से परामर्श लें।',
        reference: 'नेशनल इंस्टीट्यूट ऑफ मेंटल हेल्थ (NIMH)'
      },
      Marathi: {
        myth: 'नैराश्य (डिप्रेशन) म्हणजे केवळ मनाचा कमकुवतपणा, जो सकारात्मक विचाराने लगेच घालवता येतो.',
        fact: 'नैराश्य हा मेंदूतील रसायनांच्या असंतुलनामुळे होणारा एक वैद्यकीय आजार आहे.',
        explanation: 'डिप्रेशन असलेल्या व्यक्तीला केवळ "सकारात्मक राहा" सांगणे पुरेसे नसते; त्याला योग्य समुपदेशन व उपचारांची गरज असते.',
        healthTip: 'सतत उदास वाटत असल्यास मानसोपचार तज्ज्ञांचा सल्ला घ्यावा.',
        reference: 'नॅशनल इन्स्टिट्यूट ऑफ मेंटल हेल्थ (NIMH)'
      }
    }
  },

  // 9. FIRST AID MYTHS
  {
    id: 'fam-01',
    categoryId: 'first-aid-myths',
    tags: ['burn', 'ice', 'paste', 'butter', 'first aid'],
    content: {
      English: {
        myth: 'Put ice, butter, or toothpaste on a skin burn to soothe it immediately.',
        fact: 'Ice damages fragile burned tissue, while butter or toothpaste traps heat and causes infection.',
        explanation: 'Ice causes severe vasoconstriction and cold injury to damaged skin. Toothpaste or butter contains oils and chemicals that harbor bacteria, worsening burn depth.',
        healthTip: 'Hold minor burns under cool running tap water for 10 to 20 minutes, then cover loosely with a sterile bandage.',
        reference: 'Red Cross / WHO First Aid Guidelines'
      },
      Hindi: {
        myth: 'जलने पर त्वचा पर बर्फ, मक्खन या टूथपेस्ट तुरंत लगाना चाहिए।',
        fact: 'बर्फ जलने के घाव को और गहरा करती है, जबकि मक्खन या टूथपेस्ट से इन्फेक्शन का खतरा बढ़ता है।',
        explanation: 'बर्फ से त्वचा की कोशिकाएं जम जाती हैं। टूथपेस्ट और पेस्ट गर्मी को अंदर ही रोक लेते हैं जिससे त्वचा अंदर तक जलती है।',
        healthTip: 'जले हुए हिस्से पर तुरंत 10-20 मिनट तक नल का बहता ठंडा पानी डालें और फिर साफ कपड़े से ढकें।',
        reference: 'रेड क्रॉस (Red Cross)'
      },
      Marathi: {
        myth: 'भाजल्यावर लगेच बर्फ, लोणी किंवा टूथपेस्ट लावावी.',
        fact: 'बर्फामुळे त्वचेची हानी होते, तर लोणी किंवा टूथपेस्टमुळे संसर्गाचा (इन्फेक्शन) धोका वाढतो.',
        explanation: 'टूथपेस्ट किंवा पेस्ट उष्णता आतच अडकवून ठेवते, ज्यामुळे जखम अधिक खोलवर होते.',
        healthTip: 'भाजलेल्या भागावर लगेच १० ते २० मिनिटे नळाचे थंड पाणी टाका आणि स्वच्छ कपड्याने झाका.',
        reference: 'रेड क्रॉस (Red Cross)'
      }
    }
  },

  // 10. GENERAL HEALTH MYTHS
  {
    id: 'ghm-01',
    categoryId: 'general-health-myths',
    tags: ['water', '8 glasses', 'hydration', 'thirst'],
    content: {
      English: {
        myth: 'Everyone must strictly drink 8 glasses (2 liters) of plain water every single day.',
        fact: 'Fluid requirements vary based on climate, physical activity, weight, and diet.',
        explanation: 'Hydration comes not only from plain water, but also from soups, fruits, vegetables, and tea/coffee. Thirst and light-colored urine are your best indicators of adequate hydration.',
        healthTip: 'Drink when you feel thirsty and monitor your urine color—pale clear yellow indicates healthy hydration.',
        reference: 'National Academy of Medicine / Mayo Clinic'
      },
      Hindi: {
        myth: 'हर इंसान को हर दिन बिना चूके ठीक 8 गिलास (2 लीटर) सादा पानी पीना ही चाहिए।',
        fact: 'शरीर में पानी की जरूरत मौसम, वजन, मेहनत और खान-पान पर निर्भर करती है।',
        explanation: 'पानी की पूर्ति दाल, सूप, फल (जैसे तरबूज) और सब्जियों से भी होती है। जब प्यास लगे तब पानी पीना सबसे सही नियम है।',
        healthTip: 'प्यास लगने पर पानी पिएं और पेशाब के रंग पर ध्यान दें—हल्का पीला रंग सही हाइड्रेशन दर्शाता है।',
        reference: 'मेयो क्लीनिक (Mayo Clinic)'
      },
      Marathi: {
        myth: 'प्रत्येक व्यक्तीने रोजच्या रोज नेमके ८ ग्लास पाणी पिणे बंधनकारक आहे.',
        fact: 'पाण्याची गरज ही हवामान, शारीरिक श्रम आणि आहारावर अवलंबून असते.',
        explanation: 'फळे, भाज्या, वरण आणि सुपमधूनही शरीराला पाणी मिळते. तहान लागल्यावर पाणी पिणे हा उत्तम नियम आहे.',
        healthTip: 'तहान लागल्यावर पाणी प्या आणि लघवीचा रंग फिकट पिवळा राहील याकडे लक्ष द्या.',
        reference: 'मेयो क्लिनिक (Mayo Clinic)'
      }
    }
  }
];

export function getMythsByCategory(categoryId: string): MythItem[] {
  return ALL_MYTHS.filter((m) => m.categoryId === categoryId);
}

export function searchMyths(query: string, language: string = 'English'): MythItem[] {
  if (!query || query.trim() === '') return ALL_MYTHS;

  const q = query.toLowerCase().trim();
  return ALL_MYTHS.filter((item) => {
    const langData = item.content[language as keyof typeof item.content] || item.content.English;
    const matchMyth = langData.myth.toLowerCase().includes(q);
    const matchFact = langData.fact.toLowerCase().includes(q);
    const matchExp = langData.explanation.toLowerCase().includes(q);
    const matchTip = langData.healthTip.toLowerCase().includes(q);
    const matchTag = item.tags.some((t) => t.toLowerCase().includes(q));

    return matchMyth || matchFact || matchExp || matchTip || matchTag;
  });
}

export function getMythOfTheDay(): MythItem {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 1000 / 60 / 60 / 24
  );
  const index = dayOfYear % ALL_MYTHS.length;
  return ALL_MYTHS[index] || ALL_MYTHS[0];
}
