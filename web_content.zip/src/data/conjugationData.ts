import { VerbBab, ConjugationForm } from '../types';

export const personMetadata = [
  { person: '3rd', gender: 'masculine', number: 'singular', seghaArabic: 'مُفْرَدٌ مُذَكَّرٌ غَائِبٌ', seghaUrdu: 'واحد مذکر غائب', seghaPashto: 'يو مذکر غایب' },
  { person: '3rd', gender: 'masculine', number: 'dual', seghaArabic: 'تَثْنِيَةٌ مُذَكَّرٌ غَائِبٌ', seghaUrdu: 'تثنیہ مذکر غائب', seghaPashto: 'دوه مذکره غایب' },
  { person: '3rd', gender: 'masculine', number: 'plural', seghaArabic: 'جَمْعٌ مُذَكَّرٌ غَائِبٌ', seghaUrdu: 'جمع مذکر غائب', seghaPashto: 'ډېر مذکره غایب' },
  
  { person: '3rd', gender: 'feminine', number: 'singular', seghaArabic: 'مُفْرَدَةٌ مُؤَنَّثَةٌ غَائِبَةٌ', seghaUrdu: 'واحد مؤنث غائب', seghaPashto: 'یوه مؤنثه غایبه' },
  { person: '3rd', gender: 'feminine', number: 'dual', seghaArabic: 'تَثْنِيَةٌ مُؤَنَّثَةٌ غَائِبَةٌ', seghaUrdu: 'تثنیہ مؤنث غائب', seghaPashto: 'دوې مؤنثې غایبې' },
  { person: '3rd', gender: 'feminine', number: 'plural', seghaArabic: 'جَمْعٌ مُؤَنَّثٌ غَائِبٌ', seghaUrdu: 'جمع مؤنث غائب', seghaPashto: 'ډېرې مؤنثې غایبې' },

  { person: '2nd', gender: 'masculine', number: 'singular', seghaArabic: 'مُفْرَدٌ مُذَكَّرٌ مُخَاطَبٌ', seghaUrdu: 'واحد مذکر حاضر', seghaPashto: 'يو مذکر حاضر' },
  { person: '2nd', gender: 'masculine', number: 'dual', seghaArabic: 'تَثْنِيَةٌ مُذَكَّرٌ مُخَاطَبٌ', seghaUrdu: 'تثنیہ مذکر حاضر', seghaPashto: 'دوه مذکره حاضر' },
  { person: '2nd', gender: 'masculine', number: 'plural', seghaArabic: 'جَمْعٌ مُذَكَّرٌ مُخَاطَبٌ', seghaUrdu: 'جمع مذکر حاضر', seghaPashto: 'ډېر مذکره حاضر' },

  { person: '2nd', gender: 'feminine', number: 'singular', seghaArabic: 'مُفْرَدَةٌ مُؤَنَّثَةٌ مُخَاطَبَةٌ', seghaUrdu: 'واحد مؤنث حاضر', seghaPashto: 'یوه مؤنثه حاضره' },
  { person: '2nd', gender: 'feminine', number: 'dual', seghaArabic: 'تَثْنِيَةٌ مُؤَنَّثَةٌ مُخَاطَبَةٌ', seghaUrdu: 'تثنیہ مؤنث حاضر', seghaPashto: 'دوې مؤنثې حاضرې' },
  { person: '2nd', gender: 'feminine', number: 'plural', seghaArabic: 'جَمْعٌ مُؤَنَّثٌ مُخَاطَبٌ', seghaUrdu: 'جمع مؤنث حاضر', seghaPashto: 'ډېرې مؤنثې حاضرې' },

  { person: '1st', gender: 'common', number: 'singular', seghaArabic: 'وَاحِدٌ مُتَكَلِّمٌ', seghaUrdu: 'واحد متکلم', seghaPashto: 'یو متکلم (زه)' },
  { person: '1st', gender: 'common', number: 'plural', seghaArabic: 'جَمْعٌ مُتَكَلِّمٌ (مَعَ الْغَيْرِ)', seghaUrdu: 'جمع متکلم (ہم)', seghaPashto: 'جمع متکلم (موږ)' },
];

function buildPastConjugation(root: string, meaningKey: { pastP: string; pastU: string; pastE: string }): ConjugationForm[] {
  // standard helper for sound past: [fa'ala, fa'alaa, fa'aloo, ...]
  const forms = [
    { ar: `${root}َ`, en: `He (one male) ${meaningKey.pastE}`, ur: `اس ایک مرد نے ${meaningKey.pastU}`, ps: `هغه یو سړي ${meaningKey.pastP}` },
    { ar: `${root}َا`, en: `They both (two males) ${meaningKey.pastE}`, ur: `ان دو مردوں نے ${meaningKey.pastU}`, ps: `هغو دوو سړو ${meaningKey.pastP}` },
    { ar: `${root}ُوا`, en: `They (all males) ${meaningKey.pastE}`, ur: `ان سب مردوں نے ${meaningKey.pastU}`, ps: `هغو ټولو سړو ${meaningKey.pastP}` },
    { ar: `${root}َتْ`, en: `She (one female) ${meaningKey.pastE}`, ur: `اس ایک عورت نے ${meaningKey.pastU}`, ps: `هغې یوې ښځې ${meaningKey.pastP}` },
    { ar: `${root}َتَا`, en: `They both (two females) ${meaningKey.pastE}`, ur: `ان دو عورتوں نے ${meaningKey.pastU}`, ps: `هغو دوو ښځو ${meaningKey.pastP}` },
    { ar: `${root}ْنَ`, en: `They (all females) ${meaningKey.pastE}`, ur: `ان سب عورتوں نے ${meaningKey.pastU}`, ps: `هغو ټولو ښځو ${meaningKey.pastP}` },
    { ar: `${root}ْتَ`, en: `You (one male) ${meaningKey.pastE}`, ur: `تو ایک مرد نے ${meaningKey.pastU}`, ps: `تا یو سړي ${meaningKey.pastP}` },
    { ar: `${root}ْتُمَا`, en: `You both (two males) ${meaningKey.pastE}`, ur: `تم دو مردوں نے ${meaningKey.pastU}`, ps: `تاسو دوو سړو ${meaningKey.pastP}` },
    { ar: `${root}ْتُمْ`, en: `You (all males) ${meaningKey.pastE}`, ur: `تم سب مردوں نے ${meaningKey.pastU}`, ps: `تاسو ټولو سړو ${meaningKey.pastP}` },
    { ar: `${root}ْتِ`, en: `You (one female) ${meaningKey.pastE}`, ur: `تو ایک عورت نے ${meaningKey.pastU}`, ps: `تا یوې ښځې ${meaningKey.pastP}` },
    { ar: `${root}ْتُمَا`, en: `You both (two females) ${meaningKey.pastE}`, ur: `تم دو عورتوں نے ${meaningKey.pastU}`, ps: `تاسو دوو ښځو ${meaningKey.pastP}` },
    { ar: `${root}ْتُنَّ`, en: `You (all females) ${meaningKey.pastE}`, ur: `تم سب عورتوں نے ${meaningKey.pastU}`, ps: `تاسو ټولو ښځو ${meaningKey.pastP}` },
    { ar: `${root}ْتُ`, en: `I ${meaningKey.pastE}`, ur: `میں نے ${meaningKey.pastU}`, ps: `ما ${meaningKey.pastP}` },
    { ar: `${root}ْنَا`, en: `We ${meaningKey.pastE}`, ur: `ہم سب نے ${meaningKey.pastU}`, ps: `موږ ${meaningKey.pastP}` },
  ];

  return forms.map((f, i) => ({
    arabic: f.ar,
    person: personMetadata[i].person,
    gender: personMetadata[i].gender,
    number: personMetadata[i].number,
    seghaArabic: personMetadata[i].seghaArabic,
    seghaUrdu: personMetadata[i].seghaUrdu,
    seghaPashto: personMetadata[i].seghaPashto,
    meaningPashto: f.ps,
    meaningUrdu: f.ur,
    meaningEnglish: f.en,
  }));
}

function buildPresentConjugation(pfx: string, stem: string, meaningKey: { presP: string; presU: string; presE: string }): ConjugationForm[] {
  const forms = [
    { ar: `يَ${stem}ُ`, en: `He (one male) ${meaningKey.presE}`, ur: `وہ ایک مرد ${meaningKey.presU} ہے`, ps: `هغه یو سړی ${meaningKey.presP}` },
    { ar: `يَ${stem}َانِ`, en: `They both (two males) ${meaningKey.presE}`, ur: `وہ دو مرد ${meaningKey.presU} ہیں`, ps: `هغه دوه سړي ${meaningKey.presP}` },
    { ar: `يَ${stem}ُونَ`, en: `They (all males) ${meaningKey.presE}`, ur: `وہ سب مرد ${meaningKey.presU} ہیں`, ps: `هغه ټول سړي ${meaningKey.presP}` },
    { ar: `تَ${stem}ُ`, en: `She (one female) ${meaningKey.presE}`, ur: `وہ ایک عورت ${meaningKey.presU} ہے`, ps: `هغه یوه ښځه ${meaningKey.presP}` },
    { ar: `تَ${stem}َانِ`, en: `They both (two females) ${meaningKey.presE}`, ur: `وہ دو عورتیں ${meaningKey.presU} ہیں`, ps: `هغه دوې ښځې ${meaningKey.presP}` },
    { ar: `يَ${stem}ْنَ`, en: `They (all females) ${meaningKey.presE}`, ur: `وہ سب عورتیں ${meaningKey.presU} ہیں`, ps: `هغه ټولې ښځې ${meaningKey.presP}` },
    { ar: `تَ${stem}ُ`, en: `You (one male) ${meaningKey.presE}`, ur: `تو ایک مرد ${meaningKey.presU} ہے`, ps: `ته یو سړی ${meaningKey.presP}` },
    { ar: `تَ${stem}َانِ`, en: `You both (two males) ${meaningKey.presE}`, ur: `تم دو مرد ${meaningKey.presU} ہو`, ps: `تاسو دوه سړي ${meaningKey.presP}` },
    { ar: `تَ${stem}ُونَ`, en: `You (all males) ${meaningKey.presE}`, ur: `تم سب مرد ${meaningKey.presU} ہو`, ps: `تاسو ټول سړي ${meaningKey.presP}` },
    { ar: `تَ${stem}ِينَ`, en: `You (one female) ${meaningKey.presE}`, ur: `تو ایک عورت ${meaningKey.presU} ہے`, ps: `ته یوه ښځه ${meaningKey.presP}` },
    { ar: `تَ${stem}َانِ`, en: `You both (two females) ${meaningKey.presE}`, ur: `تم دو عورتیں ${meaningKey.presU} ہو`, ps: `تاسو دوې ښځې ${meaningKey.presP}` },
    { ar: `تَ${stem}ْنَ`, en: `You (all females) ${meaningKey.presE}`, ur: `تم سب عورتیں ${meaningKey.presU} ہو`, ps: `تاسو ټولې ښځې ${meaningKey.presP}` },
    { ar: `أَ${stem}ُ`, en: `I ${meaningKey.presE}`, ur: `میں ${meaningKey.presU} ہوں`, ps: `زه ${meaningKey.presP}` },
    { ar: `نَ${stem}ُ`, en: `We ${meaningKey.presE}`, ur: `ہم سب ${meaningKey.presU} ہیں`, ps: `موږ ${meaningKey.presP}` },
  ];

  return forms.map((f, i) => ({
    arabic: f.ar,
    person: personMetadata[i].person,
    gender: personMetadata[i].gender,
    number: personMetadata[i].number,
    seghaArabic: personMetadata[i].seghaArabic,
    seghaUrdu: personMetadata[i].seghaUrdu,
    seghaPashto: personMetadata[i].seghaPashto,
    meaningPashto: f.ps,
    meaningUrdu: f.ur,
    meaningEnglish: f.en,
  }));
}

function buildAmrConjugation(amrStem: string, meaningVerb: { ps: string; ur: string; en: string }): ConjugationForm[] {
  // 6 forms of amr haadir (2nd person)
  const forms = [
    { ar: `${amrStem}ْ`, person: '2nd', gender: 'masculine', number: 'singular', segAr: 'مُفْرَدٌ مُذَكَّرٌ حَاضِرٌ', segUr: 'واحد مذکر حاضر', segPs: 'يو مذکر حاضر', en: `(You one male) ${meaningVerb.en}!`, ur: `تو ایک مرد ${meaningVerb.ur}!`, ps: `ته یو سړی ${meaningVerb.ps} کړه!` },
    { ar: `${amrStem}َا`, person: '2nd', gender: 'masculine', number: 'dual', segAr: 'تَثْنِيَةٌ مُذَكَّرٌ حَاضِرٌ', segUr: 'تثنیہ مذکر حاضر', segPs: 'دوه مذکره حاضر', en: `(You two males) ${meaningVerb.en}!`, ur: `تم دو مرد ${meaningVerb.ur}!`, ps: `تاسو دوه سړي ${meaningVerb.ps} کړئ!` },
    { ar: `${amrStem}ُوا`, person: '2nd', gender: 'masculine', number: 'plural', segAr: 'جَمْعٌ مُذَكَّرٌ حَاضِرٌ', segUr: 'جمع مذکر حاضر', segPs: 'ډېر مذکره حاضر', en: `(You all males) ${meaningVerb.en}!`, ur: `تم سب مرد ${meaningVerb.ur}!`, ps: `تاسو ټول سړي ${meaningVerb.ps} کړئ!` },
    { ar: `${amrStem}ِي`, person: '2nd', gender: 'feminine', number: 'singular', segAr: 'مُفْرَدَةٌ مُؤَنَّثَةٌ حَاضِرَةٌ', segUr: 'واحد مؤنث حاضر', segPs: 'یوه مؤنثه حاضره', en: `(You one female) ${meaningVerb.en}!`, ur: `تو ایک عورت ${meaningVerb.ur}!`, ps: `ته یوه ښځه ${meaningVerb.ps} کړه!` },
    { ar: `${amrStem}َا`, person: '2nd', gender: 'feminine', number: 'dual', segAr: 'تَثْنِيَةٌ مُؤَنَّثَةٌ حَاضِرَةٌ', segUr: 'تثنیہ مؤنث حاضر', segPs: 'دوې مؤنثې حاضرې', en: `(You two females) ${meaningVerb.en}!`, ur: `تم دو عورتیں ${meaningVerb.ur}!`, ps: `تاسو دوې ښځې ${meaningVerb.ps} کړئ!` },
    { ar: `${amrStem}ْنَ`, person: '2nd', gender: 'feminine', number: 'plural', segAr: 'جَمْعٌ مُؤَنَّثٌ حَاضِرٌ', segUr: 'جمع مؤنث حاضر', segPs: 'ډېرې مؤنثې حاضرې', en: `(You all females) ${meaningVerb.en}!`, ur: `تم سب عورتیں ${meaningVerb.ur}!`, ps: `تاسو ټولې ښځې ${meaningVerb.ps} کړئ!` },
  ];

  return forms.map(f => ({
    arabic: f.ar,
    person: f.person,
    gender: f.gender,
    number: f.number,
    seghaArabic: f.segAr,
    seghaUrdu: f.segUr,
    seghaPashto: f.segPs,
    meaningPashto: f.ps,
    meaningUrdu: f.ur,
    meaningEnglish: f.en,
  }));
}

function buildNahyConjugation(nahyStem: string, meaningVerb: { ps: string; ur: string; en: string }): ConjugationForm[] {
  const forms = [
    { ar: `لَا تَ${nahyStem}ْ`, person: '2nd', gender: 'masculine', number: 'singular', segAr: 'مُفْرَدٌ مُذَكَّرٌ حَاضِرٌ', segUr: 'واحد مذکر حاضر', segPs: 'يو مذکر حاضر', en: `Do not ${meaningVerb.en}!`, ur: `تو مت ${meaningVerb.ur}!`, ps: `ته ${meaningVerb.ps} مه کوه!` },
    { ar: `لَا تَ${nahyStem}َا`, person: '2nd', gender: 'masculine', number: 'dual', segAr: 'تَثْنِيَةٌ مُذَكَّرٌ حَاضِرٌ', segUr: 'تثنیہ مذکر حاضر', segPs: 'دوه مذکره حاضر', en: `Do not both of you ${meaningVerb.en}!`, ur: `تم دونوں مت ${meaningVerb.ur}!`, ps: `تاسو دواړه ${meaningVerb.ps} مه کوئ!` },
    { ar: `لَا تَ${nahyStem}ُوا`, person: '2nd', gender: 'masculine', number: 'plural', segAr: 'جَمْعٌ مُذَكَّرٌ حَاضِرٌ', segUr: 'جمع مذکر حاضر', segPs: 'ډېر مذکره حاضر', en: `Do not all of you ${meaningVerb.en}!`, ur: `تم سب مت ${meaningVerb.ur}!`, ps: `تاسو ټول ${meaningVerb.ps} مه کوئ!` },
    { ar: `لَا تَ${nahyStem}ِي`, person: '2nd', gender: 'feminine', number: 'singular', segAr: 'مُفْرَدَةٌ مُؤَنَّثَةٌ حَاضِرَةٌ', segUr: 'واحد مؤنث حاضر', segPs: 'یوه مؤنثه حاضره', en: `Do not (female) ${meaningVerb.en}!`, ur: `تو ایک عورت مت ${meaningVerb.ur}!`, ps: `ته ښځه ${meaningVerb.ps} مه کوه!` },
    { ar: `لَا تَ${nahyStem}َا`, person: '2nd', gender: 'feminine', number: 'dual', segAr: 'تَثْنِيَةٌ مُؤَنَّثَةٌ حَاضِرَةٌ', segUr: 'تثنیہ مؤنث حاضر', segPs: 'دوې مؤنثې حاضرې', en: `Do not both of you (females) ${meaningVerb.en}!`, ur: `تم دو عورتیں مت ${meaningVerb.ur}!`, ps: `تاسو دوې ښځې ${meaningVerb.ps} مه کوئ!` },
    { ar: `لَا تَ${nahyStem}ْنَ`, person: '2nd', gender: 'feminine', number: 'plural', segAr: 'جَمْعٌ مُؤَنَّثٌ حَاضِرٌ', segUr: 'جمع مؤنث حاضر', segPs: 'ډېرې مؤنثې حاضرې', en: `Do not all of you (females) ${meaningVerb.en}!`, ur: `تم سب عورتیں مت ${meaningVerb.ur}!`, ps: `تاسو ټولې ښځې ${meaningVerb.ps} مه کوئ!` },
  ];

  return forms.map(f => ({
    arabic: f.ar,
    person: f.person,
    gender: f.gender,
    number: f.number,
    seghaArabic: f.segAr,
    seghaUrdu: f.segUr,
    seghaPashto: f.segPs,
    meaningPashto: f.ps,
    meaningUrdu: f.ur,
    meaningEnglish: f.en,
  }));
}

export const verbBabs: VerbBab[] = [
  {
    id: 'bab_nasara',
    nameArabic: 'بَابُ نَصَرَ - يَنْصُرُ',
    pattern: 'فَعَلَ - يَفْعُلُ',
    category: 'thulathi_mujarrad',
    symbolArabic: 'ن',
    title: {
      pashto: 'باب نَصَرَ (مرسته کول)',
      urdu: 'بابِ نَصَرَ (مدد کرنا)',
      english: 'Bab Nasara (To Help)'
    },
    description: {
      pashto: 'ماضي مفتوح العین (نَصَرَ) او مضارع مضموم العین (يَنْصُرُ).',
      urdu: 'ماضی مفتوح العین (نَصَرَ) اور مضارع مضموم العین (يَنْصُرُ)۔',
      english: 'Past Fa\'ala, Present Yaf\'ulu. Extremely common transitive pattern.'
    },
    characteristic: {
      pashto: 'ډېر کله متعدي راځي او امر یې په پیش دی: اُنْصُرْ.',
      urdu: 'اکثر متعدی آتا ہے اور امر بالضم آتا ہے: اُنْصُرْ۔',
      english: 'Predominantly transitive; imperative takes Dammah prefix: Unsur.'
    },
    rootLetters: 'ن - ص - ر',
    past3rdMasc: 'نَصَرَ',
    present3rdMasc: 'يَنْصُرُ',
    masdar: 'نَصْرًا',
    amr: 'اُنْصُرْ',
    nahy: 'لَا تَنْصُرْ',
    conjugations: {
      past: buildPastConjugation('نَصَر', { pastP: 'مرسته وکړه', pastU: 'مدد کی', pastE: 'helped' }),
      present: buildPresentConjugation('يَ', 'نْصُر', { presP: 'مرسته کوي', presU: 'مدد کرتا', presE: 'helps' }),
      amr: buildAmrConjugation('اُنْصُر', { ps: 'مرسته', ur: 'مدد کر', en: 'help' }),
      nahy: buildNahyConjugation('نْصُر', { ps: 'مرسته', ur: 'مدد کر', en: 'help' })
    }
  },
  {
    id: 'bab_daraba',
    nameArabic: 'بَابُ ضَرَبَ - يَضْرِبُ',
    pattern: 'فَعَلَ - يَفْعِلُ',
    category: 'thulathi_mujarrad',
    symbolArabic: 'ض',
    title: {
      pashto: 'باب ضَرَبَ (وهل / بیانول)',
      urdu: 'بابِ ضَرَبَ (مارنا / بیان کرنا)',
      english: 'Bab Daraba (To Strike / Mention)'
    },
    description: {
      pashto: 'ماضي مفتوح العین (ضَرَبَ) او مضارع مکسور العین (يَضْرِبُ).',
      urdu: 'ماضی مفتوح العین (ضَرَبَ) اور مضارع مکسور العین (يَضْرِبُ)۔',
      english: 'Past Fa\'ala, Present Yaf\'ilu. Imperative takes Kasrah prefix: Idrib.'
    },
    characteristic: {
      pashto: 'هم لازم او هم متعدي راځي، لکه: جَلَسَ (لازم) او ضَرَبَ (متعدي).',
      urdu: 'لازم اور متعدی دونوں بکثرت آتے ہیں۔',
      english: 'Both transitive and intransitive verbs.'
    },
    rootLetters: 'ض - ر - ب',
    past3rdMasc: 'ضَرَبَ',
    present3rdMasc: 'يَضْرِبُ',
    masdar: 'ضَرْبًا',
    amr: 'اِضْرِبْ',
    nahy: 'لَا تَضْرِبْ',
    conjugations: {
      past: buildPastConjugation('ضَرَب', { pastP: 'ووهل', pastU: 'مارا', pastE: 'struck' }),
      present: buildPresentConjugation('يَ', 'ضْرِب', { presP: 'وهي', presU: 'مارتا', presE: 'strikes' }),
      amr: buildAmrConjugation('اِضْرِب', { ps: 'وهل', ur: 'مار', en: 'strike' }),
      nahy: buildNahyConjugation('ضْرِب', { ps: 'وهل', ur: 'مار', en: 'strike' })
    }
  },
  {
    id: 'bab_samia',
    nameArabic: 'بَابُ سَمِعَ - يَسْمَعُ',
    pattern: 'فَعِلَ - يَفْعَلُ',
    category: 'thulathi_mujarrad',
    symbolArabic: 'س',
    title: {
      pashto: 'باب سَمِعَ (اورېدل / پوهېدل)',
      urdu: 'بابِ سَمِعَ (سننا / جاننا)',
      english: 'Bab Sami\'a (To Hear / Know)'
    },
    description: {
      pashto: 'ماضي مکسور العین (سَمِعَ) او مضارع مفتوح العین (يَسْمَعُ).',
      urdu: 'ماضی مکسور العین (سَمِعَ) اور مضارع مفتوح العین (يَسْمَعُ)۔',
      english: 'Past Fa\'ila, Present Yaf\'alu. Imperative: Isma\'.'
    },
    characteristic: {
      pashto: 'زیاتره د انسان د باطني او ادراکي حالاتو لپاره راځي (عَلِمَ، سَمِعَ، فَهِمَ).',
      urdu: 'حواس اور باطنی فہم کے لیے کثیر الاستعمال ہے۔',
      english: 'Frequently represents sensory perception, knowledge, and inner emotions.'
    },
    rootLetters: 'س - م - ع',
    past3rdMasc: 'سَمِعَ',
    present3rdMasc: 'يَسْمَعُ',
    masdar: 'سَمْعًا',
    amr: 'اِسْمَعْ',
    nahy: 'لَا تَسْمَعْ',
    conjugations: {
      past: buildPastConjugation('سَمِع', { pastP: 'واورېدل', pastU: 'سنا', pastE: 'heard' }),
      present: buildPresentConjugation('يَ', 'سْمَع', { presP: 'اوري', presU: 'سنتا', presE: 'hears' }),
      amr: buildAmrConjugation('اِسْمَع', { ps: 'اورېدل', ur: 'سن', en: 'hear' }),
      nahy: buildNahyConjugation('سْمَع', { ps: 'اورېدل', ur: 'سن', en: 'hear' })
    }
  },
  {
    id: 'bab_fataha',
    nameArabic: 'بَابُ فَتَحَ - يَفْتَحُ',
    pattern: 'فَعَلَ - يَفْعَلُ',
    category: 'thulathi_mujarrad',
    symbolArabic: 'ف',
    title: {
      pashto: 'باب فَتَحَ (خلاصول / بریا)',
      urdu: 'بابِ فَتَحَ (کھولنا / فتح دینا)',
      english: 'Bab Fataha (To Open / Grant Victory)'
    },
    description: {
      pashto: 'په ماضی او مضارع دواړو کې د عین کلمې زبر (فتحتان) وي او عین یا لام د حلق توری وي.',
      urdu: 'ماضی اور مضارع دونوں میں فتحہ (زبر) اور عین یا لام کلمہ میں حروفِ حلقی کا ہونا لازم ہے۔',
      english: 'Past and Present both with Fathah; requires a throat letter in root.'
    },
    characteristic: {
      pashto: 'د حلق له شپږو تورو (ء، هـ، ع، ح، غ، خ) څخه یو پکې حتمي وي.',
      urdu: 'حروفِ حلقی کی موجودگی شرطِ لازم ہے۔',
      english: 'Contains a guttural radical.'
    },
    rootLetters: 'ف - ت - ح',
    past3rdMasc: 'فَتَحَ',
    present3rdMasc: 'يَفْتَحُ',
    masdar: 'فَتْحًا',
    amr: 'اِفْتَحْ',
    nahy: 'لَا تَفْتَحْ',
    conjugations: {
      past: buildPastConjugation('فَتَح', { pastP: 'خلاص کړ', pastU: 'کھولا', pastE: 'opened' }),
      present: buildPresentConjugation('يَ', 'فْتَح', { presP: 'خلاصوي', presU: 'کھولتا', presE: 'opens' }),
      amr: buildAmrConjugation('اِفْتَح', { ps: 'خلاص', ur: 'کھول', en: 'open' }),
      nahy: buildNahyConjugation('فْتَح', { ps: 'خلاص', ur: 'کھول', en: 'open' })
    }
  },
  {
    id: 'bab_karuma',
    nameArabic: 'بَابُ كَرُمَ - يَكْرُمُ',
    pattern: 'فَعُلَ - يَفْعُلُ',
    category: 'thulathi_mujarrad',
    symbolArabic: 'ك',
    title: {
      pashto: 'باب كَرُمَ (شریف او سخي کېدل)',
      urdu: 'بابِ كَرُمَ (سخی اور شریف ہونا)',
      english: 'Bab Karuma (To Be Noble)'
    },
    description: {
      pashto: 'ماضي او مضارع دواړه ضمه لري (ضمُّ ضمٍّ). تل لازمي وي.',
      urdu: 'ماضی اور مضارع دونوں مضموم (ضمُّ ضمٍّ)۔ تمام افعال ہمیشہ لازم ہوتے ہیں۔',
      english: 'Both tenses with Dammah; exclusively intransitive stative verbs.'
    },
    characteristic: {
      pashto: 'د اخلاقو، شرافت او ذاتي صفتونو د ښودلو لپاره ځانګړی دی.',
      urdu: 'فطری خصلتوں اور اخلاقی اوصاف کے لیے مخصوص ہے۔',
      english: 'Expresses permanent inherent attributes and personal noble virtues.'
    },
    rootLetters: 'ك - ر - م',
    past3rdMasc: 'كَرُمَ',
    present3rdMasc: 'يَكْرُمُ',
    masdar: 'كَرَمًا',
    amr: 'اُكْرُمْ',
    nahy: 'لَا تَكْرُمْ',
    conjugations: {
      past: buildPastConjugation('كَرُم', { pastP: 'سخي او شریف شو', pastU: 'سخی ہوا', pastE: 'became noble' }),
      present: buildPresentConjugation('يَ', 'كْرُم', { presP: 'شریف او سخي کېږي', presU: 'سخی ہوتا', presE: 'becomes noble' }),
      amr: buildAmrConjugation('اُكْرُم', { ps: 'سخاوت او شرافت', ur: 'سخاوت', en: 'be noble' }),
      nahy: buildNahyConjugation('كْرُم', { ps: 'بد اخلاقي', ur: 'بخل', en: 'be ignoble' })
    }
  },
  {
    id: 'bab_if\'aal',
    nameArabic: 'بَابُ الإِفْعَالِ (أَكْرَمَ - يُكْرِمُ)',
    pattern: 'أَفْعَلَ - يُفْعِلُ',
    category: 'thulathi_mazeed',
    title: {
      pashto: 'باب إفعال (عزت ورکول، پوره کول)',
      urdu: 'بابِ افعال (عزت دینا، اکرام کرنا)',
      english: 'Bab If\'aal (Form IV - Causative)'
    },
    description: {
      pashto: 'د ثلاثي مزید فیه مشهور باب دی، مصدر یې د إِفْعَال په وزن راځي.',
      urdu: 'ثلاثی مزید فیہ کا معروف ترین باب، مصدر إِفْعَال کے وزن پر۔',
      english: 'The primary causative Form IV paradigm: Akrama - Yukrimu - Ikraam.'
    },
    characteristic: {
      pashto: 'بنسټیزه خاصیت یې "تعدیه" (لازم فعل متعدي کول) دی.',
      urdu: 'سب سے اہم خاصیت تعدیہ ہے (جیسے جلس سے اجلاس، نزل سے انزال)۔',
      english: 'Transforms intransitive verbs into transitive causatives.'
    },
    rootLetters: 'ك - ر - م',
    past3rdMasc: 'أَكْرَمَ',
    present3rdMasc: 'يُكْرِمُ',
    masdar: 'إِكْرَامًا',
    amr: 'أَكْرِمْ',
    nahy: 'لَا تُكْرِمْ',
    conjugations: {
      past: buildPastConjugation('أَكْرَم', { pastP: 'عزت یې وکړه', pastU: 'عزت دی', pastE: 'honored' }),
      present: buildPresentConjugation('يُ', 'كْرِم', { presP: 'عزت کوي', presU: 'عزت دیتا', presE: 'honors' }),
      amr: buildAmrConjugation('أَكْرِم', { ps: 'عزت', ur: 'عزت کر', en: 'honor' }),
      nahy: buildNahyConjugation('كْرِم', { ps: 'بې عزتي', ur: 'بے عزتی', en: 'dishonor' })
    }
  }
];
