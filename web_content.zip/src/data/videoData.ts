import { HealthVideoItem, VideoCategory } from '../types/video';

export const VIDEO_CATEGORIES: {
  id: VideoCategory;
  emoji: string;
  nameEn: string;
  nameHi: string;
  nameMr: string;
}[] = [
  { id: 'Disease Education', emoji: '🦠', nameEn: 'Disease Education', nameHi: 'बीमारी शिक्षा', nameMr: 'आजार शिक्षण' },
  { id: 'Medicine Education', emoji: '💊', nameEn: 'Medicine Education', nameHi: 'दवा शिक्षा', nameMr: 'औषध मार्गदर्शन' },
  { id: 'Nutrition & Diet', emoji: '🥗', nameEn: 'Nutrition & Diet', nameHi: 'पोषण और आहार', nameMr: 'पोषण व आहार' },
  { id: 'Fitness & Exercise', emoji: '🏋', nameEn: 'Fitness & Exercise', nameHi: 'फिटनेस और व्यायाम', nameMr: 'फिटनेस व व्यायाम' },
  { id: 'Heart Health', emoji: '❤️', nameEn: 'Heart Health', nameHi: 'हृदय स्वास्थ्य', nameMr: 'हृदय आरोग्य' },
  { id: 'Diabetes Care', emoji: '🩸', nameEn: 'Diabetes Care', nameHi: 'डायबिटीज देखभाल', nameMr: 'मधुमेह काळजी' },
  { id: 'Respiratory Health', emoji: '🫁', nameEn: 'Respiratory Health', nameHi: 'श्वसन स्वास्थ्य', nameMr: 'श्वसन आरोग्य' },
  { id: 'Mental Health', emoji: '🧠', nameEn: 'Mental Health', nameHi: 'मानसिक स्वास्थ्य', nameMr: 'मानसिक आरोग्य' },
  { id: 'Women\'s Health', emoji: '🤰', nameEn: 'Women\'s Health', nameHi: 'महिला स्वास्थ्य', nameMr: 'महिला आरोग्य' },
  { id: 'Child Health', emoji: '👶', nameEn: 'Child Health', nameHi: 'बाल स्वास्थ्य', nameMr: 'बाल आरोग्य' },
  { id: 'Senior Citizen Health', emoji: '👴', nameEn: 'Senior Citizen Health', nameHi: 'वरिष्ठ नागरिक स्वास्थ्य', nameMr: 'ज्येष्ठ नागरिक आरोग्य' },
  { id: 'First Aid & Emergency', emoji: '🚑', nameEn: 'First Aid & Emergency', nameHi: 'प्राथमिक चिकित्सा', nameMr: 'प्रथमोपचार' },
  { id: 'Bone & Joint Health', emoji: '🦴', nameEn: 'Bone & Joint Health', nameHi: 'हड्डी और जोड़', nameMr: 'हाडे व सांधे आरोग्य' },
  { id: 'Preventive Healthcare', emoji: '🛡', nameEn: 'Preventive Healthcare', nameHi: 'निवारक स्वास्थ्य देखभाल', nameMr: 'प्रतिबंधात्मक आरोग्य' }
];

export interface VideoTopicBlueprint {
  id: string;
  searchQuery: string;
  category: VideoCategory;
  categoryEmoji: string;
  lastUpdated: string;
  bgGradient: string;
  content: {
    English: {
      title: string;
      description: string;
      categoryName: string;
      source: string;
      keyTakeaways: string[];
    };
    Hindi: {
      title: string;
      description: string;
      categoryName: string;
      source: string;
      keyTakeaways: string[];
    };
    Marathi: {
      title: string;
      description: string;
      categoryName: string;
      source: string;
      keyTakeaways: string[];
    };
  };
}

// Educational Topic Definitions - NEVER contain hardcoded or static YouTube IDs.
// All YouTube IDs are dynamically fetched using the official YouTube Data API v3 on demand.
export const HEALTH_VIDEO_TOPICS: VideoTopicBlueprint[] = [
  {
    id: 'topic-dengue-prevention',
    searchQuery: 'Dengue fever symptoms prevention patient education WHO CDC',
    category: 'Disease Education',
    categoryEmoji: '🦠',
    lastUpdated: 'August 2026',
    bgGradient: 'from-rose-500 to-amber-600',
    content: {
      English: {
        title: 'Dengue Fever Symptoms & Platelet Care Guide',
        description: 'Understand primary symptoms of dengue fever, warning signs of severe dengue, platelet count management, and home hydration protocols.',
        categoryName: 'Disease Education',
        source: 'World Health Organization & CDC',
        keyTakeaways: [
          'Recognize high fever, severe eye pain, and joint aches early',
          'Importance of daily platelet count monitoring',
          'ORS, coconut water, and hydration protocols'
        ]
      },
      Hindi: {
        title: 'डेंगू बुखार के लक्षण एवं प्लेटलेट प्रबंधन मार्गदर्शन',
        description: 'डेंगू के शुरुआती लक्षणों, गंभीर चेतावनी संकेतों, प्लेटलेट की गिरावट और घर पर तरल पदार्थ प्रबंधन की जानकारी।',
        categoryName: 'बीमारी शिक्षा',
        source: 'विश्व स्वास्थ्य संगठन एवं स्वास्थ्य मंत्रालय',
        keyTakeaways: [
          'तेज बुखार, आंखों में दर्द और जोड़ों के दर्द को पहचानें',
          'प्रतिदिन प्लेटलेट काउंट की निगरानी की आवश्यकता',
          'ओआरएस और नारियल पानी से सही तरल पूर्ति'
        ]
      },
      Marathi: {
        title: 'डेंग्यू ताप लक्षणे व प्लेटलेट्स काळजी मार्गदर्शन',
        description: 'डेंग्यू तापाची मुख्य लक्षणे, गंभीर धोक्याच्या सूचना, प्लेटलेट्स घट व घरगुती हायड्रेशन टिप्स.',
        categoryName: 'आजार शिक्षण',
        source: 'जागतिक आरोग्य संघटना व आरोग्य मंत्रालय',
        keyTakeaways: [
          'तीव्र ताप, डोळ्यांच्या मागील वेदना व सांधेदुखी ओळखा',
          'रोज प्लेटलेट्स तपासणीचे महत्त्व',
          'ओआरएस व नारळ पाणी हायड्रेशन पद्धती'
        ]
      }
    }
  },
  {
    id: 'topic-paracetamol-safe-use',
    searchQuery: 'Paracetamol safe dosage liver safety medicine education NHS',
    category: 'Medicine Education',
    categoryEmoji: '💊',
    lastUpdated: 'August 2026',
    bgGradient: 'from-blue-500 to-indigo-600',
    content: {
      English: {
        title: 'Paracetamol Safe Dosage & Liver Safety Rules',
        description: 'Comprehensive medical advice on correct Paracetamol dosage for adults and children, daily maximum limits, and liver toxicity prevention.',
        categoryName: 'Medicine Education',
        source: 'NHS & National Health Authority',
        keyTakeaways: [
          'Adult maximum limit is 4,000 mg (4 grams) per 24 hours',
          'Minimum 4 to 6 hours gap between doses',
          'Avoid taking multiple medicines containing acetaminophen simultaneously'
        ]
      },
      Hindi: {
        title: 'पैरासिटामोल की सही खुराक और लिवर सुरक्षा नियम',
        description: 'वयस्कों और बच्चों के लिए पैरासिटामोल की सही मात्रा, 24 घंटे की अधिकतम सीमा और ओवरडोज से बचाव की जानकारी।',
        categoryName: 'दवा शिक्षा',
        source: 'राष्ट्रीय स्वास्थ्य प्राधिकरण',
        keyTakeaways: [
          'वयस्कों के लिए 24 घंटे में अधिकतम 4,000 मिलीग्राम (4 ग्राम)',
          'दो खुराकों के बीच कम से कम 4 से 6 घंटे का अंतर रखें',
          'एक साथ कई पैरासिटामोल युक्त दवाएं न लें'
        ]
      },
      Marathi: {
        title: 'पॅरासिटामॉल योग्य डोस व लिव्हर सुरक्षितता नियम',
        description: 'पॅरासिटामॉलचे अचूक प्रमाण, २४ तासांतील कमाल मर्यादा आणि लिव्हर सुरक्षिततेचे महत्त्वाचे नियम.',
        categoryName: 'औषध मार्गदर्शन',
        source: 'राष्ट्रीय आरोग्य प्राधिकरण',
        keyTakeaways: [
          'प्रौढांसाठी २४ तासांत कमाल ४,००० मिग्रॅ मर्यादा',
          'दोन डोसमधे किमान ४ ते ६ तासांचे अंतर ठेवा',
          'अतिवापर टाळा व डॉक्टरांचा सल्ला घ्या'
        ]
      }
    }
  },
  {
    id: 'topic-diabetes-diet-plan',
    searchQuery: 'Diabetes diet food plate diabetes care Mayo Clinic NHS',
    category: 'Diabetes Care',
    categoryEmoji: '🩸',
    lastUpdated: 'August 2026',
    bgGradient: 'from-amber-500 to-emerald-600',
    content: {
      English: {
        title: 'Diabetes Healthy Diet Plate & Glycemic Control',
        description: 'Learn how to construct a balanced diabetic meal plate using complex carbs, fiber-rich vegetables, and lean protein to prevent blood sugar spikes.',
        categoryName: 'Diabetes Care',
        source: 'Mayo Clinic & Diabetes Association',
        keyTakeaways: [
          'Fill half your plate with non-starchy vegetables',
          'Choose low glycemic index whole grains (oats, brown rice, millets)',
          'Maintain consistent meal timings to avoid glucose fluctuations'
        ]
      },
      Hindi: {
        title: 'डायबिटीज में सही आहार थाली एवं ब्लड शुगर नियंत्रण',
        description: 'मधुमेह रोगियों के लिए फाइबर युक्त सब्जियां, कम ग्लाइसेमिक इंडेक्स अनाज और प्रोटीन से भरपूर संतुलित आहार थाली।',
        categoryName: 'डायबिटीज देखभाल',
        source: 'मेयो क्लीनिक एवं स्वास्थ्य शिक्षा',
        keyTakeaways: [
          'अपनी थाली का आधा हिस्सा हरी सब्जियों से भरें',
          'कम ग्लाइसेमिक इंडेक्स अनाज जैसे बाजरा, ओट्स चुनें',
          'नियमित समय पर भोजन करें ताकि शुगर लेवल न बढ़े'
        ]
      },
      Marathi: {
        title: 'मधुमेह आहार थाळी व रक्तातील साखरेचे नियंत्रण',
        description: 'मधुमेहाच्या रुग्णांसाठी फायबरयुक्त भाज्या, कमी ग्लायसेमिक इंडेक्स धान्ये आणि प्रथिनांनी समृद्ध योग्य आहार.',
        categoryName: 'मधुमेह काळजी',
        source: 'मेयो क्लिनिक आरोग्य मार्गदर्शन',
        keyTakeaways: [
          'थाळीचा अर्धा भाग पालेभाज्यांनी भरा',
          'कमी ग्लायसेमिक इंडेक्स असलेले धान्य निवडा',
          'जेवणाची वेळ पाळा व साखर नियंत्रणात ठेवा'
        ]
      }
    }
  },
  {
    id: 'topic-heart-attack-warning',
    searchQuery: 'Heart attack warning signs symptoms patient education CDC Mayo Clinic',
    category: 'Heart Health',
    categoryEmoji: '❤️',
    lastUpdated: 'August 2026',
    bgGradient: 'from-red-600 to-rose-700',
    content: {
      English: {
        title: 'Heart Attack Early Warning Signs & Emergency Action',
        description: 'Identify chest pain, shortness of breath, radiating pain in arms/jaw, cold sweats, and critical immediate first steps before ambulance arrives.',
        categoryName: 'Heart Health',
        source: 'American Heart Association & CDC',
        keyTakeaways: [
          'Chest pressure or tight squeezing sensation lasting over 5 minutes',
          'Pain radiating to jaw, neck, left arm, or back',
          'Call emergency services immediately and chew aspirin if prescribed'
        ]
      },
      Hindi: {
        title: 'हार्ट अटैक के शुरुआती लक्षण और आपातकालीन प्राथमिक चिकित्सा',
        description: 'छाती में दर्द, सांस फूलना, बांह या जबड़े में खिंचाव और पसीने के लक्षणों को पहचानें एवं तत्काल एम्बुलेंस बुलाएं।',
        categoryName: 'हृदय स्वास्थ्य',
        source: 'अमेरिकन हार्ट एसोसिएशन एवं स्वास्थ्य मंत्रालय',
        keyTakeaways: [
          'छाती में भारीपन या 5 मिनट से अधिक का दबाव महसूस होना',
          'बाएं हाथ, गर्दन या जबड़े में दर्द का फैलना',
          'तुरंत इमरजेंसी नंबर डायल करें और मरीज को शांत बैठाएं'
        ]
      },
      Marathi: {
        title: 'हार्ट अटॅकची पूर्वलक्षणे व तातडीची प्राथमिक मदत',
        description: 'छातीत दुखणे, धाप लागणे, डाव्या हातातील वेदना आणि घाम येणे यांसारखी धोक्याची लक्षणे ओळखा.',
        categoryName: 'हृदय आरोग्य',
        source: 'अमेरिकन हार्ट असोसिएशन',
        keyTakeaways: [
          'छातीत ५ मिनिटांपेक्षा जास्त वेळ होणारा त्रास',
          'मान, जबडा किंवा डाव्या हातात पसरणाऱ्या वेदना',
          'त्वरित रुग्णवाहिका बोलवा व रुग्णाला शांत ठेवा'
        ]
      }
    }
  },
  {
    id: 'topic-cpr-first-aid',
    searchQuery: 'CPR first aid step by step tutorial Red Cross AHA',
    category: 'First Aid & Emergency',
    categoryEmoji: '🚑',
    lastUpdated: 'August 2026',
    bgGradient: 'from-emerald-600 to-cyan-700',
    content: {
      English: {
        title: 'Hands-Only CPR Step-by-Step Emergency Guide',
        description: 'Learn life-saving hands-only CPR compressions for unresponsive adults and children in emergency cardiac situations.',
        categoryName: 'First Aid & Emergency',
        source: 'Red Cross & Emergency Health Guide',
        keyTakeaways: [
          'Check responsiveness and call local emergency services immediately',
          'Place hands in center of chest and compress 100-120 times per minute',
          'Push hard and fast until professional help arrives'
        ]
      },
      Hindi: {
        title: 'हैंड्स-ओनली सीपीआर (CPR) चरण-दर-चरण आपातकालीन गाइड',
        description: 'बेहोश या सांस न ले पा रहे व्यक्ति के लिए जीवन रक्षक सीपीआर तकनीक और सही चेस्ट कम्प्रेशन की जानकारी।',
        categoryName: 'प्राथमिक चिकित्सा',
        source: 'रेड क्रॉस एवं आपातकालीन स्वास्थ्य सेवा',
        keyTakeaways: [
          'मरीज की सांस और प्रतिक्रिया जांचें, तुरंत एम्बुलेंस को कॉल करें',
          'छाती के बीचों-बीच दोनों हाथों से 100-120 प्रति मिनट की गति से दबाएं',
          'मदद आने तक लगातार बिना रुके सीपीआर जारी रखें'
        ]
      },
      Marathi: {
        title: 'सीपीआर (CPR) प्रथमोपचार जीवनरक्षक सोपी पद्धत',
        description: 'अचानक बेशुद्ध पडलेल्या किंवा श्वास थांबलेल्या रुग्णासाठी जीवनरक्षक सीपीआर प्रात्यक्षिक.',
        categoryName: 'प्रथमोपचार',
        source: 'रेड क्रॉस व आपत्कालीन वैद्यकीय विभाग',
        keyTakeaways: [
          'रुग्णाची प्रतिसाद क्षमता तपासा व त्वरित मदत मागा',
          'छातीच्या मध्यभागी दर मिनिटाला १००-१२० दाबाव द्या',
          'वैद्यकीय मदत मिळेपर्यंत सीपीआर सुरू ठेवा'
        ]
      }
    }
  },
  {
    id: 'topic-anxiety-mental-health',
    searchQuery: 'Anxiety panic attack breathing exercises mental health NHS Johns Hopkins',
    category: 'Mental Health',
    categoryEmoji: '🧠',
    lastUpdated: 'August 2026',
    bgGradient: 'from-purple-600 to-indigo-700',
    content: {
      English: {
        title: 'Anxiety Relief & Box Breathing Relaxation Techniques',
        description: 'Master evidence-based 4-7-8 breathing and grounding exercises to manage sudden panic attacks, anxiety, and elevated heart rate.',
        categoryName: 'Mental Health',
        source: 'NHS & Johns Hopkins Mental Health',
        keyTakeaways: [
          'Practice 4-7-8 deep diaphragmatic breathing technique',
          'Use 5-4-3-2-1 sensory grounding method during panic',
          'Reduce caffeine intake and prioritize quality sleep'
        ]
      },
      Hindi: {
        title: 'मानसिक तनाव और घबराहट दूर करने के श्वसन अभ्यास',
        description: 'अचानक होने वाली घबराहट और चिंता को शांत करने के लिए 4-7-8 डीप ब्रीदिंग और ग्राउंडिंग तकनीकें।',
        categoryName: 'मानसिक स्वास्थ्य',
        source: 'एनएचएस एवं मानसिक स्वास्थ्य संस्थान',
        keyTakeaways: [
          '4 सेकंड सांस लें, 7 सेकंड रोकें और 8 सेकंड में छोड़ें',
          'घबराहट के समय अपनी 5 इंद्रियों पर ध्यान केंद्रित करें',
          'कैफीन का सेवन कम करें और पर्याप्त नींद लें'
        ]
      },
      Marathi: {
        title: 'चिंता व भीती कमी करण्याचे श्वासोच्छवास व्यायाम',
        description: 'मानसिक ताण आणि पॅनिक अटॅकच्या वेळी मन शांत करण्यासाठी ४-७-८ श्वसन पद्धत.',
        categoryName: 'मानसिक आरोग्य',
        source: 'एनएचएस व मानसिक आरोग्य तज्ज्ञ',
        keyTakeaways: [
          '४-७-८ डीप ब्रीदिंग पद्धतीचा सराव करा',
          'भीती वाटल्यास सभोवतालच्या वस्तूंवर लक्ष केंद्रित करा',
          'पुरेशी झोप घ्या व चहा/कॉफीचे प्रमाण कमी करा'
        ]
      }
    }
  },
  {
    id: 'topic-asthma-inhaler-use',
    searchQuery: 'Asthma inhaler technique step by step NHS Asthma UK',
    category: 'Respiratory Health',
    categoryEmoji: '🫁',
    lastUpdated: 'August 2026',
    bgGradient: 'from-sky-500 to-blue-700',
    content: {
      English: {
        title: 'Correct Asthma Inhaler & Spacer Technique Guide',
        description: 'Step-by-step clinical demonstration on using metered-dose inhalers (MDI) with spacers to ensure maximum medication reaches the lungs.',
        categoryName: 'Respiratory Health',
        source: 'NHS & Asthma Lung Association',
        keyTakeaways: [
          'Always use a spacer device for better pulmonary absorption',
          'Exhale fully before pressing the canister and inhale slowly for 3-5 seconds',
          'Rinse mouth thoroughly after corticosteroid inhaler use'
        ]
      },
      Hindi: {
        title: 'अस्थमा इनहेलर और स्पेंसर के सही उपयोग की विधि',
        description: 'फेफड़ों तक दवा की सही मात्रा पहुंचाने के लिए इनहेलर और स्पेसर के सही इस्तेमाल का चरणबद्ध तरीका।',
        categoryName: 'श्वसन स्वास्थ्य',
        source: 'राष्ट्रीय श्वसन संस्थान',
        keyTakeaways: [
          'दवा के बेहतर अवशोषण के लिए हमेशा स्पेसर का उपयोग करें',
          'इनहेलर दबाने से पहले पूरी तरह सांस बाहर छोड़ें',
          'स्टेरॉयड इनहेलर के बाद हमेशा कुल्ला करें'
        ]
      },
      Marathi: {
        title: 'दमा (Asthma) इनहेलर वापरण्याची योग्य आणि अचूक पद्धत',
        description: 'फुफ्फुसांपर्यंत औषध नीट पोहोचण्यासाठी इनहेलर आणि स्पेसर वापरण्याची प्रात्यक्षिक मार्गदर्शिका.',
        categoryName: 'श्वसन आरोग्य',
        source: 'श्वसन आजार विभाग',
        keyTakeaways: [
          'उत्तम परिणामासाठी स्पेसरचा वापर करा',
          'इनहेलर वापरण्यापूर्वी पूर्ण श्वास बाहेर सोडा',
          'वापरानंतर तोंड स्वच्छ धुवून गुळण्या करा'
        ]
      }
    }
  },
  {
    id: 'topic-knee-osteoarthritis',
    searchQuery: 'Knee osteoarthritis exercises joint health NHS Mayo Clinic',
    category: 'Bone & Joint Health',
    categoryEmoji: '🦴',
    lastUpdated: 'August 2026',
    bgGradient: 'from-teal-600 to-slate-800',
    content: {
      English: {
        title: 'Knee Pain & Osteoarthritis Physiotherapy Exercises',
        description: 'Gentle quadriceps strengthening and hamstring stretching exercises to reduce knee joint pressure and improve mobility.',
        categoryName: 'Bone & Joint Health',
        source: 'NHS Physiotherapy & Mayo Clinic',
        keyTakeaways: [
          'Strengthen quadriceps muscles to support knee joint stability',
          'Perform low-impact exercises like straight leg raises',
          'Avoid deep squatting and high-impact jumping activities'
        ]
      },
      Hindi: {
        title: 'घुटनों के दर्द और ऑस्टियोआर्थराइटिस के लिए फिजियोथेरेपी व्यायाम',
        description: 'घुटनों के जोड़ों के दबाव को कम करने और मांसपेशियों को मजबूत बनाने के आसान घरेलू व्यायाम।',
        categoryName: 'हड्डी और जोड़',
        source: 'फिजियोथेरेपी विभाग',
        keyTakeaways: [
          'घुटने के जोड़ की मजबूती के लिए थाई मसल्स का व्यायाम करें',
          'सीधे पैर उठाने (Straight Leg Raise) का अभ्यास करें',
          'ज्यादा झुकने या उकड़ू बैठने से बचें'
        ]
      },
      Marathi: {
        title: 'गुडघेदुखी व सांधेदुखीसाठी सोपे फिजियोथेरपी व्यायाम',
        description: 'गुडघ्यांवरचा ताण कमी करण्यासाठी आणि पायाच्या स्नायूंना बळकट करण्यासाठी सोपे प्रात्यक्षिक.',
        categoryName: 'हाडे व सांधे आरोग्य',
        source: 'फिजियोथेरपी आरोग्य विभाग',
        keyTakeaways: [
          'मांडीचे स्नायू मजबूत करणारे व्यायाम करा',
          'दररोज हलके लेग रेझ व्यायाम करा',
          'उकिडवे बसणे किंवा जास्त वजन उचलणे टाळा'
        ]
      }
    }
  },
  {
    id: 'topic-child-immunization',
    searchQuery: 'Child vaccination schedule immunization guide WHO CDC',
    category: 'Child Health',
    categoryEmoji: '👶',
    lastUpdated: 'August 2026',
    bgGradient: 'from-rose-400 to-purple-600',
    content: {
      English: {
        title: 'Essential Child Vaccination & Immunization Schedule',
        description: 'Learn about critical infant vaccines (BCG, Polio, Pentavalent, MMR) preventing life-threatening childhood infections.',
        categoryName: 'Child Health',
        source: 'WHO & UNICEF Child Health',
        keyTakeaways: [
          'Complete birth doses (BCG, OPV-0, Hepatitis B-0) promptly',
          'Follow the 6, 10, and 14-week primary vaccination rounds',
          'Manage post-vaccination mild fever with doctor-recommended paracetamol'
        ]
      },
      Hindi: {
        title: 'शिशु टीकाकरण सारणी एवं आवश्यक सुरक्षा गाइड',
        description: 'बच्चों को गंभीर बीमारियों से बचाने के लिए जन्म से लेकर 5 वर्ष तक की संपूर्ण टीकाकरण सारणी।',
        categoryName: 'बाल स्वास्थ्य',
        source: 'विश्व स्वास्थ्य संगठन एवं बाल कल्याण',
        keyTakeaways: [
          'जन्म के तुरंत बाद बीसीजी, पोलियों और हेपेटाइटिस बी लगवाएं',
          '6, 10 और 14वें सप्ताह के टीके समय पर लगवाएं',
          'टीके के बाद हल्का बुखार आने पर डॉक्टर की सलाह लें'
        ]
      },
      Marathi: {
        title: 'बाळांचे लसीकरण वेळापत्रक व महत्त्वाच्या लसींची माहिती',
        description: 'बालकांना घातक आजारांपासून वाचवण्यासाठी जन्मापासून ते ५ वर्षांपर्यंतचे लसीकरण वेळापत्रक.',
        categoryName: 'बाल आरोग्य',
        source: 'युनिसेफ व आरोग्य विभाग',
        keyTakeaways: [
          'जन्मावेळी बीसीजी आणि पोलिओ लस आवर्जून द्या',
          '६, १० आणि १४ व्या आठवड्याचे डोस वेळेत घ्या',
          'लसीकरणानंतर हलका ताप आल्यास डॉक्टरांचा सल्ला घ्या'
        ]
      }
    }
  },
  {
    id: 'topic-balanced-nutrition-plate',
    searchQuery: 'Healthy balanced diet plate nutrition Harvard Health WHO',
    category: 'Nutrition & Diet',
    categoryEmoji: '🥗',
    lastUpdated: 'August 2026',
    bgGradient: 'from-green-500 to-emerald-700',
    content: {
      English: {
        title: 'Building a Healthy Balanced Nutrition Meal Plate',
        description: 'Practical guide on balancing macronutrients, portion sizes, micronutrients, and daily water consumption for long-term health.',
        categoryName: 'Nutrition & Diet',
        source: 'Harvard School of Public Health & WHO',
        keyTakeaways: [
          'Make 50% of your meal vegetables and whole fruits',
          'Choose whole grains like millets, brown rice, or whole wheat',
          'Include 1.5 to 2 liters of water daily and limit refined sugar'
        ]
      },
      Hindi: {
        title: 'संतुलित पोषण आहार थाली एवं स्वास्थ्यवर्धक भोजन',
        description: 'दैनिक भोजन में प्रोटीन, कार्ब्स, फाइबर और सूक्ष्म पोषक तत्वों का सही संतुलन बनाने का तरीका।',
        categoryName: 'पोषण और आहार',
        source: 'हार्वर्ड पब्लिक हेल्थ एवं पोषण संस्थान',
        keyTakeaways: [
          'भोजन में आधा हिस्सा फल और हरी सब्जियों का रखें',
          'साबुत अनाज जैसे बाजरा, ज्वार या ओट्स शामिल करें',
          'दिन भर में पर्याप्त पानी पिएं और रिफाइंड चीनी कम करें'
        ]
      },
      Marathi: {
        title: 'आरोग्यदायी संतुलित आहार थाळी आणि पोषण नियम',
        description: 'रोजच्या जेवणात प्रथिने, फायबर आणि जीवनसत्त्वांचा योग्य समतोल कसा साधावा.',
        categoryName: 'पोषण व आहार',
        source: 'हार्वर्ड हेल्थ व पोषण विभाग',
        keyTakeaways: [
          'जेवणात ५०% भाग भाज्या व फळांचा असावा',
          'ज्वारी, बाजरी यांसारखी तृणधान्ये समाविष्ट करा',
          'दररोज पुरेशी पाणी प्या व साखरेचा वापर टाळा'
        ]
      }
    }
  },
  {
    id: 'topic-daily-home-exercise',
    searchQuery: 'Gentle home workout daily exercise fitness health education NHS',
    category: 'Fitness & Exercise',
    categoryEmoji: '🏋',
    lastUpdated: 'August 2026',
    bgGradient: 'from-cyan-500 to-teal-700',
    content: {
      English: {
        title: '15-Minute Daily Gentle Home Exercise Routine',
        description: 'Low-impact full-body routine designed to improve cardiovascular fitness, joint mobility, and posture without equipment.',
        categoryName: 'Fitness & Exercise',
        source: 'NHS Fitness Guide',
        keyTakeaways: [
          'Warm up with 3 minutes of gentle joint rotations',
          'Perform brisk walking or low-impact squats',
          'Cool down with static stretching to prevent muscle soreness'
        ]
      },
      Hindi: {
        title: '15 मिनट का दैनिक हल्का घरेलू व्यायाम और फिटनेस रूटीन',
        description: 'बिना किसी उपकरण के शरीर को चुस्त-दुरुस्त रखने और जोड़ों की गतिशीलता बढ़ाने का आसान अभ्यास।',
        categoryName: 'फिटनेस और व्यायाम',
        source: 'एनएचएस फिटनेस गाइड',
        keyTakeaways: [
          'व्यायाम से पहले 3 मिनट हल्की वार्म-अप स्ट्रेचिंग करें',
          'तेज चलना या हल्के स्क्वाट्स का अभ्यास करें',
          'व्यायाम के बाद कूल-डाउन स्ट्रेचिंग जरूर करें'
        ]
      },
      Marathi: {
        title: '१५ मिनिटांचा रोजचा सोपा घरगुती व्यायाम व फिटनेस टिप्स',
        description: 'कोणत्याही साहित्याशिवाय रोजच्या रोज करता येणारा सोपा आणि प्रभावी व्यायाम प्रकार.',
        categoryName: 'फिटनेस व व्यायाम',
        source: 'एनएचएस फिटनेस मार्गदर्शक',
        keyTakeaways: [
          'व्यायामापूर्वी ३ मिनिटे वॉर्म-अप करा',
          'रोज जलद चाला किंवा हलके व्यायाम करा',
          'शेवटी स्नायूंना ताण देऊन कूल-डाऊन करा'
        ]
      }
    }
  },
  {
    id: 'topic-hypertension-care',
    searchQuery: 'High blood pressure hypertension salt reduction CDC NHS',
    category: 'Preventive Healthcare',
    categoryEmoji: '🛡',
    lastUpdated: 'August 2026',
    bgGradient: 'from-indigo-600 to-slate-900',
    content: {
      English: {
        title: 'High Blood Pressure Control & Salt Reduction Guide',
        description: 'Understand systolic/diastolic blood pressure readings, sodium reduction strategies, and lifestyle changes to prevent hypertension.',
        categoryName: 'Preventive Healthcare',
        source: 'CDC & Preventive Health Association',
        keyTakeaways: [
          'Target blood pressure reading below 120/80 mmHg',
          'Limit daily sodium intake to under 2,000 mg (under 1 teaspoon salt)',
          'Monitor blood pressure regularly and avoid tobacco/alcohol'
        ]
      },
      Hindi: {
        title: 'उच्च रक्तचाप (बीपी) नियंत्रण और नमक कम करने के नियम',
        description: 'रक्तचाप के मापदंडों को समझें, नमक की खपत कम करने और बीपी नियंत्रित रखने के उपाय।',
        categoryName: 'निवारक स्वास्थ्य देखभाल',
        source: 'सीडीसी एवं निवारक स्वास्थ्य संस्थान',
        keyTakeaways: [
          'सामान्य रक्तचाप 120/80 mmHg से कम होना चाहिए',
          'दिन भर में 1 चम्मच (2,000 मिग्रा) से कम नमक खाएं',
          'नियमित रूप से बीपी की जांच करवाएं'
        ]
      },
      Marathi: {
        title: 'उच्च रक्तदाब (बीपी) नियंत्रण व मिठाचे प्रमाण कमी करणे',
        description: 'रक्तदाबाची पातळी नियंत्रणात ठेवण्यासाठी आहारातील बदल आणि मिठाचा वापर कमी करण्याचे तंत्र.',
        categoryName: 'प्रतिबंधात्मक आरोग्य',
        source: 'सीडीसी आरोग्य विभाग',
        keyTakeaways: [
          'रक्तदाब १२०/८० mmHg पेक्षा कमी ठेवण्याचे ध्येय ठेवा',
          'रोज १ चमच्यापेक्षा कमी मीठ वापरा',
          'नियमित बीपी तपासा व तणाव टाळा'
        ]
      }
    }
  },
  {
    id: 'topic-senior-citizen-health',
    searchQuery: 'Senior citizen fall prevention balance exercises NHS Mayo Clinic',
    category: 'Senior Citizen Health',
    categoryEmoji: '👴',
    lastUpdated: 'August 2026',
    bgGradient: 'from-slate-700 to-slate-900',
    content: {
      English: {
        title: 'Senior Citizen Fall Prevention & Balance Exercises',
        description: 'Essential home hazard safety checks and chair-assisted balance exercises for elderly adults to prevent accidental falls.',
        categoryName: 'Senior Citizen Health',
        source: 'NHS Senior Health & Mayo Clinic',
        keyTakeaways: [
          'Remove loose rugs, clutter, and improve lighting at home',
          'Practice heel-to-toe walking and chair sit-to-stand exercises',
          'Ensure regular bone density and vision checkups'
        ]
      },
      Hindi: {
        title: 'वरिष्ठ नागरिकों के लिए संतुलन व्यायाम एवं गिरने से बचाव',
        description: 'बुजुर्गों में गिरने से बचाव के लिए घरेलू सुरक्षा जांच और कुर्सी के सहारे किए जाने वाले संतुलन व्यायाम।',
        categoryName: 'वरिष्ठ नागरिक स्वास्थ्य',
        source: 'एनएचएस सीनियर हेल्थ',
        keyTakeaways: [
          'घर में फिसलने वाली चटाइयां हटाएं और पर्याप्त रोशनी रखें',
          'कुर्सी के सहारे खड़े होने और बैठने का संतुलन अभ्यास करें',
          'हड्डियों का घनत्व और आंखों की नियमित जांच करवाएं'
        ]
      },
      Marathi: {
        title: 'ज्येष्ठ नागरिकांसाठी तोल सांभाळणारे सोपे व्यायाम',
        description: 'वयोवृद्धांना घरात पडण्यापासून वाचवण्यासाठी सुरक्षा टिप्स व खुर्चीवर बसून करण्याचे व्यायाम.',
        categoryName: 'ज्येष्ठ नागरिक आरोग्य',
        source: 'एनएचएस सीनियर आरोग्य विभाग',
        keyTakeaways: [
          'घरातील पायघड्या व अंधार दूर करा',
          'खुर्चीच्या आधाराने संतुलन राखण्याचे व्यायाम करा',
          'डोळे व हाडांची नियमित तपासणी करा'
        ]
      }
    }
  },
  {
    id: 'topic-pregnancy-care',
    searchQuery: 'Pregnancy care iron folic acid nutrition WHO UNICEF',
    category: 'Women\'s Health',
    categoryEmoji: '🤰',
    lastUpdated: 'August 2026',
    bgGradient: 'from-fuchsia-600 to-rose-700',
    content: {
      English: {
        title: 'Pregnancy Antenatal Care, Iron & Folic Acid Guide',
        description: 'Essential trimester guidelines on prenatal checkups, folic acid supplementation to prevent birth defects, and maternal nutrition.',
        categoryName: 'Women\'s Health',
        source: 'WHO & UNICEF Maternal Health',
        keyTakeaways: [
          'Start Folic Acid supplements before conception or early 1st trimester',
          'Take Iron & Calcium supplements as prescribed from 2nd trimester',
          'Attend at least 4 antenatal doctor visits during pregnancy'
        ]
      },
      Hindi: {
        title: 'गर्भावस्था की देखभाल, फोलिक एसिड एवं आयरन की खुराक',
        description: 'गर्भवती महिलाओं के लिए नियमित जांच, फोलिक एसिड और आयरन सप्लीमेंट्स का महत्व और सही आहार।',
        categoryName: 'महिला स्वास्थ्य',
        source: 'विश्व स्वास्थ्य संगठन एवं मातृ कल्याण',
        keyTakeaways: [
          'शुरुआती महीनों में फोलिक एसिड की गोली जरूर लें',
          'दूसरे महीने से डॉक्टर की सलाह पर आयरन और कैल्शियम लें',
          'गर्भावस्था के दौरान कम से कम 4 बार डॉक्टर से जांच कराएं'
        ]
      },
      Marathi: {
        title: 'गरोदरपणातील काळजी, फॉलिक ॲसिड व आयर्नच्या गोळ्या',
        description: 'माता व बालकाच्या आरोग्यासाठी गरोदरपणातील आवश्यक तपासण्या, आहार व गोळ्यांचे महत्त्व.',
        categoryName: 'महिला आरोग्य',
        source: 'युनिसेफ व मातृ आरोग्य विभाग',
        keyTakeaways: [
          'पहिल्या महिन्यात फॉलिक ॲसिडच्या गोळ्या सुरू करा',
          'दुसऱ्या तिमाहीपासून आयर्न व कॅल्शियम गोळ्या घ्या',
          'किमान ४ वेळा गरोदरपणाची वैद्यकीय तपासणी करा'
        ]
      }
    }
  }
];

// Fallback empty initializer function - dynamic data will be populated dynamically by YouTube Data API v3
export const HEALTH_VIDEOS_DATA: HealthVideoItem[] = [];
