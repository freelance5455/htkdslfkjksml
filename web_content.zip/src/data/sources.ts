import type { ProxySource } from "../types";

export const PROXY_SOURCES: ProxySource[] = [
  {
    id: "radikal",
    name: "Free Telegram Proxy",
    shortName: "Radikal",
    url: "https://raw.githubusercontent.com/0xRadikal/Free-Telegram-Proxy/main/stable/proxies.json",
    homepage: "https://github.com/0xRadikal/Free-Telegram-Proxy",
    description: "Три раунда реального MTProto-запроса до дата-центра Telegram. В выборке stable — uptime не ниже 90%.",
    method: "telegram",
    location: "Сервер проверки: US",
    refresh: "Обновление каждые 15 минут",
    defaultEnabled: true,
  },
  {
    id: "tgmt",
    name: "TG MTProxy Catalog",
    shortName: "TG MTProxy",
    url: "https://raw.githubusercontent.com/tgmtproxy/mtproxy/main/proxies.json",
    homepage: "https://github.com/tgmtproxy/mtproxy",
    description: "Агрегатор публичных списков с Fake-TLS handshake или проверкой TCP-порта. Только отвечающие записи.",
    method: "tcp",
    location: "Расположение проверки не раскрыто",
    refresh: "Обновление каждый час",
    defaultEnabled: true,
  },
  {
    id: "russia",
    name: "Проверено из России",
    shortName: "RU Check",
    url: "https://raw.githubusercontent.com/Chumbayoumba/free-telegram-proxy-russia-2026/main/mtproto.json",
    homepage: "https://github.com/Chumbayoumba/free-telegram-proxy-russia-2026",
    description: "Небольшой региональный список с замером RTT из РФ. Полезен как дополнительный сигнал доступности.",
    method: "handshake",
    location: "Сервер проверки: RU",
    refresh: "Обновление каждые 2 часа",
    defaultEnabled: true,
  },
  {
    id: "nexus",
    name: "MTProto Proxy Pro",
    shortName: "Nexus",
    url: "https://zakky8.github.io/mtproto-proxy-pro/proxies.json",
    homepage: "https://github.com/KevinNexus/mtproto-proxy-pro",
    description: "Геолокация, latency, uptime и отдельные результаты доступности из RU, IR и VN.",
    method: "handshake",
    location: "Несколько регионов проверки",
    refresh: "Обновление каждые 6 часов",
    defaultEnabled: false,
  },
];

export const DEFAULT_SETTINGS = {
  enabledSources: PROXY_SOURCES.filter((source) => source.defaultEnabled).map((source) => source.id),
  autoRefresh: true,
  refreshMinutes: 30,
  checkerUrl: "",
};

export const COUNTRY_NAMES: Record<string, string> = {
  AE: "ОАЭ", AL: "Албания", AT: "Австрия", AZ: "Азербайджан", BG: "Болгария",
  BR: "Бразилия", BY: "Беларусь", CA: "Канада", CH: "Швейцария", CZ: "Чехия",
  DE: "Германия", DK: "Дания", EE: "Эстония", ES: "Испания", FI: "Финляндия",
  FR: "Франция", GB: "Великобритания", GE: "Грузия", GR: "Греция", HK: "Гонконг",
  IL: "Израиль", IN: "Индия", IR: "Иран", IT: "Италия", JP: "Япония", KZ: "Казахстан",
  KR: "Южная Корея", LT: "Литва", LU: "Люксембург", LV: "Латвия", MD: "Молдова",
  NL: "Нидерланды", NO: "Норвегия", PL: "Польша", PT: "Португалия", RO: "Румыния",
  RS: "Сербия", RU: "Россия", SE: "Швеция", SG: "Сингапур", TR: "Турция",
  UA: "Украина", US: "США", VN: "Вьетнам",
};
