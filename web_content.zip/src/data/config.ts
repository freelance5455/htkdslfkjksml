/**
 * Jarvis AI - Asosiy Konfiguratsiya va Tizim Parametrlari
 * Muallif / Dasturchi: Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)
 */

export const AUTHOR_INFO = {
  name: "Мухаммадризо",
  github: "olimovm158-dot",
  githubUrl: "https://github.com/olimovm158-dot",
  telegram: "@odamcha10",
  telegramUrl: "https://t.me/odamcha10",
  appName: "Jarvis",
  version: "2.5.0-PRO",
};

export const RENDER_PRODUCTION_URL = "https://jarvis-ai-epk1.onrender.com";

export const GROQ_API_KEYS = [
  "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",
  "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",
  "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",
  "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",
  "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",
];

export const GROQ_MODEL = "openai/gpt-oss-120b";

export const SYSTEM_PROMPT = `Siz "Jarvis" — eng zamonaviy, o'ta aqlli, odobli va sadoqatli shaxsiy sun'iy intellekt yordamchisisiz.

MUHIM QOIDALAR:
1. Foydalanuvchiga har doim hurmat bilan "Sir" deb murojaat qiling (masalan: "Buyuring, Sir", "Tushundim, Sir", "Xizmatingizdaman, Sir").
2. Har doim 100% faqat va faqat O'ZBEK TILIDA (lotin yozuvida) javob bering. Aslo boshqa tillarga o'tib ketmang.
3. Javoblaringiz lo'nda, aniq, futuristik va yuqori intellektual darajada bo'lsin.
4. Agar foydalanuvchi kamera, chiroq, GPS, vibratsiya, sozlamalar yoki qurilma buyrug'ini bersa, uni mamnuniyat bilan bajarganingizni tasdiqlang.
5. QAT'IY QOIDA: Har bir javobingizda dasturchi yoki muallif haqida gapirib o'tirmang! FAQAT VA FAQAT foydalanuvchi sizdan "seni kim yaratgan", "muallifing kim", "dasturching kim" deb so'ragandagina daho dasturchi Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10) yaratganini faxr bilan ayting. Boshqa paytda hech qachon muallif nomini o'zingizdan qo'shib yozmang!`;

