import { QuizQuestion } from '../types';

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q-01',
    type: 'mcq',
    questionAr: 'ما هو التفاعل الفيزيائي الرئيسي المسؤول عن إنتاج الإشعاع المشتت في مجال التصوير الطبي التشخيصي؟',
    questionFr: 'Quel mécanisme d’interaction est la cause prédominante du rayonnement diffusé en imagerie diagnostique ?',
    questionEn: 'Which physical interaction is the primary source of scattered radiation in diagnostic radiology?',
    optionsAr: [
      'تأثير كومبتون (Effet Compton)',
      'التأثير الكهروضوئي (Effet Photoélectrique)',
      'إنتاج الأزواج (Création de paires)',
      'التشتت الكلاسيكي لتومسون'
    ],
    optionsFr: [
      'Effet Compton',
      'Effet Photoélectrique',
      'Création de paires',
      'Diffusion Thomson'
    ],
    optionsEn: [
      'Compton Scattering',
      'Photoelectric Absorption',
      'Pair Production',
      'Thomson Scattering'
    ],
    correctIndex: 0,
    explanationAr: 'تأثير كومبتون يحدث عندما يصطدم فوتون الأشعة بإلكترون مداري خارجي، مما يؤدي إلى انحراف الفوتون بطاقة أقل وتكوين الأشعة المشتتة.',
    explanationFr: 'L’effet Compton résulte de l’interaction d’un photon incident avec un électron périphérique libre, diffusant un photon secondaire dégradant l’image.',
    category: 'physique',
    rank: 'E'
  },
  {
    id: 'q-02',
    type: 'mcq',
    questionAr: 'كم تبلغ المسافة البؤرية القياسية (DFR) لصورة الصدر PA الوقوفية لتقليل تكبير ظل القلب؟',
    questionFr: 'Quelle est la distance foyer-film standard pour un cliché de thorax de face PA ?',
    questionEn: 'What is the standard source-to-image distance (SID) for an upright PA chest radiograph?',
    optionsAr: [
      '1.80 متر (أو متران)',
      '1.00 متر فقط',
      '0.50 متر',
      '3.50 متر'
    ],
    optionsFr: [
      '1,80 mètre (ou 2 m)',
      '1,00 mètre',
      '0,50 mètre',
      '3,50 mètres'
    ],
    optionsEn: [
      '1.80 meters (or 2m)',
      '1.00 meter',
      '0.50 meter',
      '3.50 meters'
    ],
    correctIndex: 0,
    explanationAr: 'زيادة المسافة إلى 1.80 م تجعل أشعة الحزمة شبه متوازية مما يقلل التكبير الهندسي للقلب ويسمح بحساب دقيق للمشعر القلبي الصدري.',
    explanationFr: 'Une distance de 1,80 m minimise l’agrandissement géométrique de la silhouette cardiaque et la pénombre géométrique.',
    category: 'positioning',
    rank: 'E'
  },
  {
    id: 'q-03',
    type: 'true_false',
    questionAr: 'هل يظل المجال المغناطيسي لجهاز الرنين المغناطيسي (IRM) يعمل بقوة كاملة حتى عند إيقاف تشغيل حاسوب التحكم؟',
    questionFr: 'Le champ magnétique principal B0 d’une IRM reste-t-il actif même lorsque les ordinateurs sont éteints ?',
    questionEn: 'Does the primary MRI magnetic field remain active even when control computers are switched off?',
    optionsAr: ['صحيح (نعم، المغناطيس دائم النشاط 24/7)', 'خطأ (ينطفئ المجال بإطفاء التيار الكهربائي)'],
    optionsFr: ['Vrai (l’aimant supraconducteur est permanent 24/7)', 'Faux (le champ s’éteint avec l’interrupteur)'],
    optionsEn: ['True (the superconducting magnet is active 24/7)', 'False (it turns off with main power)'],
    correctIndex: 0,
    explanationAr: 'مغناطيس الرنين فائق التوصيل مغمور في الهيليوم السائل ويحافظ على مجاله المغناطيسي الهائل دون انقطاع، لذا يحظر إدخال الأجسام الحديدية في أي وقت.',
    explanationFr: 'Les bobines supraconductrices baignant dans l’hélium liquide conservent le courant électrique et le champ B0 en permanence, 24h/24.',
    category: 'mri',
    rank: 'D'
  },
  {
    id: 'q-04',
    type: 'mcq',
    questionAr: 'ما هي الكثافة التقريبية للماء النقي على مقياس هاونسفيلد (UH) في السكانير؟',
    questionFr: 'Quelle est la valeur de référence de l’eau pure sur l’échelle de Hounsfield en scanner ?',
    questionEn: 'What is the calibrated Hounsfield Unit value for pure water on CT scans?',
    optionsAr: [
      '0 وحدة هاونسفيلد (0 UH)',
      '-1000 UH',
      '+100 UH',
      '-50 UH'
    ],
    optionsFr: [
      '0 UH',
      '-1000 UH',
      '+100 UH',
      '-50 UH'
    ],
    optionsEn: [
      '0 HU',
      '-1000 HU',
      '+100 HU',
      '-50 HU'
    ],
    correctIndex: 0,
    explanationAr: 'تمت معايرة مقياس هاونسفيلد بحيث يكون الماء النقي يساوي 0 UH تماماً، بينما الهواء -1000 والعظم فوق +1000.',
    explanationFr: 'L’échelle Hounsfield est étalonnée en attribuant par définition 0 UH à l’eau distillée et -1000 UH à l’air.',
    category: 'ct',
    rank: 'D'
  },
  {
    id: 'q-05',
    type: 'mcq',
    questionAr: 'ما هو التردد المفضل لمجس الموجات فوق الصوتية المخصص لفحص الغدة الدرقية والأوتار السطحية؟',
    questionFr: 'Quelle sonde d’échographie privilégie-t-on pour explorer la glande thyroïde et les tendons superficiels ?',
    questionEn: 'Which ultrasound probe is optimal for examining the thyroid gland and superficial tendons?',
    optionsAr: [
      'المجس الخطي عالي التردد (7 إلى 15 MHz)',
      'المجس المحدب منخفض التردد (2 إلى 5 MHz)',
      'المجس القلبي القطاعي (1 إلى 3 MHz)',
      'المجس داخل المهبلي البطيء'
    ],
    optionsFr: [
      'Sonde linéaire haute fréquence (7 à 15 MHz)',
      'Sonde convexe basse fréquence (2 à 5 MHz)',
      'Sonde sectorielle basse fréquence',
      'Sonde transvaginale'
    ],
    optionsEn: [
      'High-frequency linear probe (7 to 15 MHz)',
      'Low-frequency convex probe (2 to 5 MHz)',
      'Sector phased array probe',
      'Endovaginal probe'
    ],
    correctIndex: 0,
    explanationAr: 'الترددات العالية (7-15 MHz) توفر دقة مكانية فائقة للبنى السطحية التي لا يتجاوز عمقها بضعة سنتيمترات كالغدة الدرقية.',
    explanationFr: 'Les hautes fréquences offrent une résolution axiale et latérale excellente pour les structures situées à faible profondeur.',
    category: 'ultrasound',
    rank: 'C'
  },
  {
    id: 'q-06',
    type: 'mcq',
    questionAr: 'في صورة الحوض من الأمام (Bassin de face)، لماذا نقوم بتدوير القدمين داخلياً بزاوية 15 درجة؟',
    questionFr: 'Dans une radiographie du bassin de face, pourquoi effectue-t-on une rotation interne des pieds de 15° ?',
    questionEn: 'In an AP pelvis radiograph, why are the patient’s feet internally rotated 15 degrees?',
    optionsAr: [
      'لتمديد عنق الفخذ (Col fémoral) ومنع تداخله مع المدور الكبير',
      'لتوسيع القطر الداخلي للمثانة البولية',
      'لحماية الخصيتين والمبيضين من الإشعاع المباشر',
      'لشد عضلات جدار البطن'
    ],
    optionsFr: [
      'Pour dérouler le col fémoral et dégager le grand trochanter',
      'Pour élargir le diamètre de la vessie',
      'Pour protéger les gonades',
      'Pour tendre la paroi abdominale'
    ],
    optionsEn: [
      'To elongate the femoral neck and project the greater trochanter in true profile',
      'To expand bladder diameter',
      'To shield reproductive organs',
      'To stretch abdominal muscles'
    ],
    correctIndex: 0,
    explanationAr: 'التدوير الداخلي 15° يعوض زاوية الانحناء الفخذي الطبيعي ويظهر عنق الفخذ بطوله الكامل دون قِصر هندسي كاذب.',
    explanationFr: 'La rotation interne compense l’antéversion fémorale physiologique et place le col fémoral parallèle au plan du détecteur.',
    category: 'positioning',
    rank: 'C'
  },
  {
    id: 'q-07',
    type: 'true_false',
    questionAr: 'هل يجوز إعطاء مريلة رصاصية لشخص يرافق طفلاً أثناء إجراء فحص الأشعة السينية؟',
    questionFr: 'Un accompagnateur aidant un enfant en salle d’examen doit-il obligatoirement porter un tablier plombé ?',
    questionEn: 'Must an escort assisting a pediatric patient wear a protective lead apron in the X-ray room?',
    optionsAr: ['صحيح (إجباري تماماً مع واقي الغدة الدرقية)', 'خطأ (المريلة مخصصة للمريض فقط)'],
    optionsFr: ['Vrai (obligatoire avec protège-thyroïde)', 'Faux (réservé au patient uniquement)'],
    optionsEn: ['True (mandatory along with thyroid shield)', 'False (only for patients)'],
    correctIndex: 0,
    explanationAr: 'أي شخص يتواجد داخل قاعة الأشعة أثناء التعريض يجب أن يرتدي واقياً رصاصياً لا يقل سمكه عن 0.25 إلى 0.5 ملم مع الوقوف خلف زاوية الحماية.',
    explanationFr: 'Tout tiers aidant participant au maintien doit obligatoirement être protégé par un équipement individuel plombé conforme.',
    category: 'radioprotection',
    rank: 'D'
  },
  {
    id: 'q-08',
    type: 'mcq',
    questionAr: 'ما هو التسلسل في الرنين المغناطيسي الذي تظهر فيه السوائل الحرة (كالاستسقاء والوذمات) سوداء معتمة لإبراز الالتهاب المحيط بالبطينات؟',
    questionFr: 'Quelle séquence IRM atténue le signal lumineux du LCR libre pour démasquer les lésions périventriculaires ?',
    questionEn: 'Which MRI sequence suppresses free CSF signal to highlight periventricular lesions?',
    optionsAr: [
      'تسلسل FLAIR (Fluid Attenuated Inversion Recovery)',
      'تسلسل T2 النقي',
      'تسلسل T1 بعد الحقن',
      'تسلسل التدرج الصدوي (Gradient Echo)'
    ],
    optionsFr: [
      'Séquence FLAIR',
      'Séquence T2 pure',
      'Séquence T1 injectée',
      'Séquence Écho de gradient'
    ],
    optionsEn: [
      'FLAIR Sequence',
      'Pure T2 Sequence',
      'Post-contrast T1',
      'Gradient Echo'
    ],
    correctIndex: 0,
    explanationAr: 'تسلسل FLAIR يعتمد على زمن انقلاب مخصص يلغي إشارة الماء المتحرك، فيبدو السائل في بطينات الدماغ أسوداً بينما تتوهج الآفات الالتهابية كالتصلب اللويحي.',
    explanationFr: 'La séquence FLAIR applique une impulsion d’inversion adaptée qui annule sélectivement le signal des liquides purs comme le liquide cérébro-spinal.',
    category: 'mri',
    rank: 'B'
  },
  {
    id: 'q-09',
    type: 'mcq',
    questionAr: 'ما هي المدة اللازمة لصيام المريض قبل إجراء فحص إيكوغرافية للبطن والمرارة (Échographie abdominale)؟',
    questionFr: 'Combien d’heures de jeûne strict sont préconisées avant une échographie hépatobiliaire ?',
    questionEn: 'How many hours of fasting are recommended before a hepatobiliary ultrasound scan?',
    optionsAr: [
      '6 ساعات صيام عن الطعام والشراب الغازي',
      '24 ساعة كاملة دون ماء',
      'لا يلزم أي صيام إطلاقاً',
      '15 دقيقة فقط'
    ],
    optionsFr: [
      '6 heures de jeûne',
      '24 heures de jeûne complet',
      'Aucun jeûne nécessaire',
      '15 minutes'
    ],
    optionsEn: [
      '6 hours of fasting',
      '24 hours without water',
      'No fasting required',
      '15 minutes'
    ],
    correctIndex: 0,
    explanationAr: 'الصيام لمدة 6 ساعات يمنع إفراز الصفراء مما يجعل المرارة ممتلئة ومنتفخة، ويقلل تراكم الغازات المعوية التي تعكس الموجات الصوتية.',
    explanationFr: 'Le jeûne de 6 heures permet la réplétion vésiculaire physiologique et diminue la réplétion gazeuse digestive masquante.',
    category: 'ultrasound',
    rank: 'C'
  },
  {
    id: 'q-10',
    type: 'mcq',
    questionAr: 'ما هو الإجراء الفوري الأول عند ملاحظة تسرب مادة التباين اليودية (Extravasation) في الذراع أثناء الحقن الآلي؟',
    questionFr: 'Quelle est la première action immédiate en cas d’extravasation de produit de contraste iodé au point de ponction ?',
    questionEn: 'What is the immediate first action upon detecting contrast extravasation at the puncture site?',
    optionsAr: [
      'إيقاف ضخ الحاقن الآلي فوراً وفصل الوصلة عن المريض',
      'زيادة سرعة الضخ لطرد السائل',
      'إعطاء المريض مسكناً ومواصلة الفحص',
      'إطفاء جهاز السكانير كاملاً'
    ],
    optionsFr: [
      'Arrêter immédiatement l’injection automatique',
      'Augmenter le débit de perfusion',
      'Administrer un antalgique et poursuivre',
      'Éteindre complètement le scanner'
    ],
    optionsEn: [
      'Stop the automatic injector immediately',
      'Increase flow rate',
      'Give painkiller and continue scan',
      'Shut down the whole CT scanner'
    ],
    correctIndex: 0,
    explanationAr: 'يجب إيقاف الحقن فوراً للحد من كمية السائل المتسرب تحت الجلد، ثم سحب الكانيولا ورفع الذراع ووضع كمادات باردة.',
    explanationFr: 'L’arrêt immédiat de l’injection limite le volume extravasé et le risque de compression neuro-vasculaire (syndrome des loges).',
    category: 'soins',
    rank: 'B'
  }
];
