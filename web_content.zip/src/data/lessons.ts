export type Lesson = {
  id: string;
  kicker: string;
  title: string;
  minutes: number;
  lede: string;
  lab?: "magnitude" | "polaris" | "moon" | "seasons" | "scale";
  skyCon?: string;
  sections: { heading: string; paragraphs: string[] }[];
  check: { prompt: string; options: string[]; answer: number; why: string };
};

export const LESSONS: Lesson[] = [
  {
    id: "light",
    kicker: "01  ·  Distance",
    title: "Light takes time",
    minutes: 6,
    lede: "Every star you see is the Sun's cousin, and every one of them is late.",
    lab: "magnitude",
    sections: [
      {
        heading: "Suns, not sparks",
        paragraphs: [
          "A star is a sun: a ball of gas hot enough that its core fuses hydrogen. The ones overhead look like pinpricks only because they are absurdly far. The Sun is a star too. If you stood next to Proxima Centauri, our Sun would be the pinprick.",
          "The nearest star system after the Sun, Alpha Centauri, is 4.4 light-years away. Sirius, the brightest night star, is 8.6. Vega is 25. Deneb, which looks almost as bright as Vega, is thousands. Same sparkle, completely different machine.",
        ],
      },
      {
        heading: "A light-year is a distance",
        paragraphs: [
          "Light covers 299,792 kilometers every second. A light-year is how far it travels in a year: about 9.5 trillion kilometers. It is not a unit of time. Saying a star is “8 light-years away” means you are seeing it as it was 8 years ago.",
          "Sunlight is 8.3 minutes old when it warms your face. Moonlight is about 1.3 seconds old. Nothing in the night sky is live except, practically, the Moon.",
        ],
      },
      {
        heading: "Magnitude, the backwards brightness scale",
        paragraphs: [
          "Astronomers inherited a scale from Hipparchus in which brighter stars got smaller numbers. Sirius is magnitude −1.5. Vega is about 0. The faintest stars a dark sky will show are about 6. A city sky gives up around 3 or 4.",
          "Each step of 1 magnitude is about 2.51 times in brightness. Five steps is a factor of 100. So a magnitude 1 star is not a little brighter than a magnitude 6 star. It is 100 times brighter.",
        ],
      },
    ],
    check: {
      prompt: "Sirius is magnitude −1.5 and Polaris is about 2. Which statement is true?",
      options: [
        "Polaris is brighter — a bigger number means more light.",
        "Sirius is much brighter. Smaller magnitude means more light.",
        "They match. Magnitude measures distance, not brightness.",
      ],
      answer: 1,
      why: "The scale runs backwards on purpose, a 2,000-year-old habit. Sirius outshines Polaris by several magnitudes, which is tens of times in actual light — and Polaris is not “the brightest star,” a myth worth retiring tonight.",
    },
  },
  {
    id: "dome",
    kicker: "02  ·  The turning Earth",
    title: "The dome overhead",
    minutes: 7,
    lede: "The sky is not a bowl that spins. You are, and the bowl is the view from a moving ground.",
    lab: "polaris",
    sections: [
      {
        heading: "Horizon, zenith, pole",
        paragraphs: [
          "The horizon is where the ground cuts the sky. The zenith is the point straight overhead. Halfway between, neither “high” nor “low” in casual speech, is 45° altitude. Astronomers measure altitude up from the horizon and azimuth around from north toward east.",
          "Earth's axis points at a spot on the sky called the north celestial pole. Polaris sits less than a degree from it. So Polaris barely moves, and everything else wheels around it once per sidereal day — 23 hours 56 minutes, not 24, because we are also orbiting the Sun.",
        ],
      },
      {
        heading: "Your latitude is an angle in the sky",
        paragraphs: [
          "In the northern hemisphere, the altitude of Polaris equals your latitude. At 40°N it stands 40° above the northern horizon. On the equator it sits on the horizon. At the north pole it is overhead. That is not a coincidence. You are tilting with the ground.",
          "South of the equator Polaris is gone. The south celestial pole stands at an altitude equal to your southern latitude, but the star there — Sigma Octantis — is far too faint to use. Southern navigators use the Southern Cross instead.",
        ],
      },
      {
        heading: "Why everything rises in the east",
        paragraphs: [
          "Earth rotates toward the east. The ground under you moves east, so the sky appears to drift west. Stars rise on the eastern horizon, culminate on the meridian (the north-south line through your zenith), and set in the west.",
          "Stars close enough to the pole never meet the horizon. Those are circumpolar. How wide that cap is depends on your latitude: farther from the equator, more stars never set. The Big Dipper is circumpolar from London and scrapes the horizon from the southern United States.",
        ],
      },
    ],
    check: {
      prompt: "Polaris is 28° above the northern horizon. Where are you?",
      options: [
        "About 28°N, because the pole star's altitude matches northern latitude.",
        "About 62°N, because you subtract from 90°.",
        "About 28°S. Polaris is a southern star.",
      ],
      answer: 0,
      why: "Face north and measure Polaris. That angle is your latitude. At 28°N you might be in the Canaries, Florida, or the Himalayan foothills — the sky doesn't care about the country, only the parallel.",
    },
  },
  {
    id: "moon",
    kicker: "03  ·  Geometry",
    title: "The Moon is half lit",
    minutes: 6,
    lede: "Phases are not Earth's shadow. The Moon is always half in sunlight. What changes is how much of that half faces you.",
    lab: "moon",
    sections: [
      {
        heading: "The mistake everyone makes",
        paragraphs: [
          "Earth's shadow does hit the Moon. That is a lunar eclipse, and it only happens at full moon, a couple of times a year, when the Moon also crosses the plane of our orbit. The monthly fade and return is something else.",
          "The Sun lights one hemisphere of the Moon at all times, just as it lights one hemisphere of Earth. New moon is when that bright hemisphere faces away from us — the Moon is roughly between us and the Sun, in the daytime sky, lost in glare. Full moon is when we sit between them and look straight at the lit face.",
        ],
      },
      {
        heading: "Waxing and waning",
        paragraphs: [
          "After new, a thin crescent appears in the west after sunset. The Moon is “waxing” — growing. First quarter (half, confusingly) is high at sunset and sets around midnight. Waxing gibbous fills in until full, which rises at sunset and is up all night.",
          "Then it wanes. Last quarter rises around midnight. The old crescent sits in the east before dawn. From the northern hemisphere a waxing moon is bright on the right; south of the equator, on the left. The lab flips if you set a southern latitude.",
        ],
      },
      {
        heading: "Eclipses are the special case",
        paragraphs: [
          "The Moon's orbit is tilted about 5° to Earth's. Most new moons pass above or below the Sun, and most full moons pass above or below Earth's shadow. Only when the crossing lines up do you get a solar eclipse (new moon, Moon's shadow on us) or a lunar eclipse (full moon, our shadow on it).",
          "A solar eclipse is local and short. A lunar eclipse is visible from the entire night side of Earth, and the Moon goes copper rather than vanishing, because Earth's atmosphere bends red light into the shadow.",
        ],
      },
    ],
    check: {
      prompt: "Why is the Moon a crescent?",
      options: [
        "Earth's shadow is covering most of it.",
        "We are seeing only a slice of the Moon's sunlit half.",
        "The Moon produces less of its own light that week.",
      ],
      answer: 1,
      why: "The Moon makes no light of its own. A crescent is a side view of a ball that is still half lit by the Sun. If you see a crescent and a dark “rest of the Moon” faintly glowing, that ghostly part is earthshine — our daylight, bounced back.",
    },
  },
  {
    id: "worlds",
    kicker: "04  ·  Planets",
    title: "Five wanderers",
    minutes: 6,
    lede: "Planets don't twinkle the way stars do, and they refuse to stay in a constellation.",
    sections: [
      {
        heading: "Wanderers on a road",
        paragraphs: [
          "“Planet” comes from the Greek for wanderer. Stars keep their figures for a lifetime. Planets drift through those figures, night to night, because they are nearby worlds orbiting the same Sun, not distant suns.",
          "Five are naked-eye: Mercury, Venus, Mars, Jupiter, Saturn. They stay near the ecliptic — the Sun's yearly path — so you will not find a bright planet in the Big Dipper or the Southern Cross. If it is far from that line, it is a star.",
        ],
      },
      {
        heading: "Why Venus is never up at midnight",
        paragraphs: [
          "Mercury and Venus orbit inside Earth's path. From here they can never appear opposite the Sun. Venus reaches at most about 47° from the Sun, Mercury even less. So Venus is a morning star or an evening star, brilliant and low, and then it disappears into the glare for weeks.",
          "Mars, Jupiter, and Saturn orbit outside us. When Earth passes between them and the Sun they are at opposition: they rise at sunset, stand highest at midnight, and shine all night. Jupiter at opposition is the brightest thing in the sky after Venus and the Moon.",
        ],
      },
      {
        heading: "Twinkle is the atmosphere, mostly",
        paragraphs: [
          "Stars are so far they are points. Earth's turbulent air bends that point in and out of your eye, which you read as twinkling. Planets are tiny disks. The twinkles across the disk average out, so planets shine steadier. It is a hint, not a proof — a star high overhead on a calm night can look steady too.",
          "Mars is the red one. Saturn is calmer and more yellow. Jupiter is simply bright and white. Color plus the ecliptic plus a chart is how you stop guessing.",
        ],
      },
    ],
    check: {
      prompt: "Which of these can be high in the south at midnight?",
      options: [
        "Venus, if the night is clear enough.",
        "Jupiter, when it is opposite the Sun.",
        "Mercury, because it is the fastest.",
      ],
      answer: 1,
      why: "Inner planets are tied to the Sun's schedule. Outer planets are not. Midnight culmination means the body is roughly opposite the Sun — a geometry Venus is not allowed.",
    },
  },
  {
    id: "patterns",
    kicker: "05  ·  Constellations",
    title: "Pictures, not families",
    minutes: 7,
    lede: "A constellation is a region of sky and a story we draw on it. The stars in the story are usually unrelated.",
    skyCon: "ori",
    sections: [
      {
        heading: "88 regions, and a lot of nicknames",
        paragraphs: [
          "The International Astronomical Union divides the sky into 88 constellations. Every star and every galaxy belongs to exactly one. What most people mean by the word is the connect-the-dots figure inside that region.",
          "An asterism is a nickname that isn't an official constellation. The Big Dipper sits inside Ursa Major. The Summer Triangle is Vega, Altair, and Deneb — three constellations, one landmark. The Great Square of Pegasus is an asterism too, and one of its corners is officially in Andromeda.",
        ],
      },
      {
        heading: "Orion is a trick of the line of sight",
        paragraphs: [
          "Betelgeuse is a few hundred light-years away. Rigel is farther. The belt stars are farther still, around a thousand to two thousand light-years, and not even at the same distance as each other. Stand anywhere else in the galaxy and Orion dissolves.",
          "The Dipper is the interesting exception. Five of its seven stars are a real moving group, born together about 80 light-years away. Dubhe and Alkaid are not members. They just happen to complete the picture. Most patterns are Orion. A few are the Dipper.",
        ],
      },
      {
        heading: "Learn pointers, not myths",
        paragraphs: [
          "Myths are worth knowing as culture. They will not help you find anything. Pointers will. The two outer stars of the Dipper's bowl lead to Polaris. The arc of the handle leads to Arcturus, and if you keep going, to Spica. Orion's belt points one way to Sirius and the other way to Aldebaran.",
          "Learn one figure per season well, rather than twelve badly. From mid-northern latitudes: Orion in winter, Leo in spring, the Summer Triangle in summer, the Great Square in autumn. The southern sky has its own set — the Cross, Centaurus, Canopus — and they are not a mirror of the north.",
        ],
      },
    ],
    check: {
      prompt: "Why do the stars of Orion make a hunter?",
      options: [
        "They formed together and gravity holds the shape.",
        "They lie in nearly the same direction from here, at very different distances.",
        "The bright ones are planets that paused in that pattern.",
      ],
      answer: 1,
      why: "A constellation is a direction, not an object. The distances in Orion differ by factors of several. The hunter exists in our line of sight and in the stories we hung on it.",
    },
  },
  {
    id: "seasons",
    kicker: "06  ·  The year",
    title: "Tilt, not distance",
    minutes: 7,
    lede: "Summer is not when Earth is close to the Sun. Northern summer is when Earth is farthest.",
    lab: "seasons",
    sections: [
      {
        heading: "23.4 degrees",
        paragraphs: [
          "Earth's axis leans 23.4° relative to its orbit and points at Polaris year-round. The lean doesn't flip from summer to winter. What changes is where we are in the orbit, so the lean is toward the Sun, away from it, or sideways.",
          "When your hemisphere leans toward the Sun, days are longer and the noon sun climbs higher. The same light is spread over less ground and lands for more hours. That is summer. The other hemisphere is leaning away and having winter at the same time. Seasons are opposite, not universal.",
        ],
      },
      {
        heading: "Distance loses",
        paragraphs: [
          "Earth's orbit is slightly oval. We are closest to the Sun — perihelion — in early January, and farthest in early July. The difference is about 3 percent in distance, enough to notice in careful measurements and nowhere near enough to cause seasons. If distance ran the year, January would be the global summer. It isn't.",
          "At an equinox the axis points sideways to the Sun, day and night are nearly equal worldwide, and the noon sun is overhead at the equator. At a solstice the lean is at its maximum. The Tropic of Cancer and the Tropic of Capricorn are the lines where the noon sun is exactly overhead on those two days.",
        ],
      },
      {
        heading: "What to watch",
        paragraphs: [
          "You don't need a calendar. Watch where the Sun sets. Through northern spring it sets farther north each evening, stalls at the June solstice, and walks back south. The stall is the solstice — “sun stands still.” Sunset position is the whole lesson, available from any west-facing window.",
          "The night sky has seasons for the same reason. You can only see the stars opposite the Sun. Orion is a winter figure in the north because that is when it is opposite the Sun and up at a convenient hour. In June it is behind the Sun, in the daytime sky.",
        ],
      },
    ],
    check: {
      prompt: "Why is June hot in Madrid and cold in Sydney?",
      options: [
        "Earth is closer to the Sun in June, but only the north feels it.",
        "The northern hemisphere is tilted toward the Sun; the southern is tilted away.",
        "The Sun burns hotter in June and the south is cloudier.",
      ],
      answer: 1,
      why: "One tilt, two hemispheres, opposite seasons. Earth is actually a little farther from the Sun in June. Madrid's long days and high noon sun outweigh that. Sydney, leaning away, gets short days and a low sun.",
    },
  },
];

export function lessonById(id: string): Lesson | undefined {
  return LESSONS.find((l) => l.id === id);
}
