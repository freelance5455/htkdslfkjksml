export type Reciter = {
  id: string;
  name: string;
  folder: string;
  note: string;
};

/** Verse-by-verse MP3s hosted by EveryAyah. Playback and personal offline cache only. */
export const RECITERS: Reciter[] = [
  { id: "alafasy", name: "مشاري راشد العفاسي", folder: "Alafasy_128kbps", note: "مرتل · 128" },
  { id: "basit", name: "عبد الباسط عبد الصمد", folder: "Abdul_Basit_Murattal_192kbps", note: "مرتل · 192" },
  { id: "maher", name: "ماهر المعيقلي", folder: "MaherAlMuaiqly128kbps", note: "مرتل · 128" },
  { id: "sudais", name: "عبد الرحمن السديس", folder: "Abdurrahmaan_As-Sudais_192kbps", note: "مرتل · 192" },
  { id: "shuraim", name: "سعود الشريم", folder: "Saood_ash-Shuraym_128kbps", note: "مرتل · 128" },
  { id: "dosari", name: "ياسر الدوسري", folder: "Yasser_Ad-Dussary_128kbps", note: "مرتل · 128" },
  { id: "qatami", name: "ناصر القطامي", folder: "Nasser_Alqatami_128kbps", note: "مرتل · 128" },
  { id: "shaatri", name: "أبو بكر الشاطري", folder: "Abu_Bakr_Ash-Shaatree_128kbps", note: "مرتل · 128" },
  { id: "husary", name: "محمود خليل الحصري", folder: "Husary_128kbps", note: "مرتل · 128" },
  { id: "minshawi", name: "محمد صديق المنشاوي", folder: "Minshawy_Murattal_128kbps", note: "مرتل · 128" },
  { id: "mustafa", name: "مصطفى إسماعيل", folder: "Mustafa_Ismail_48kbps", note: "مجوّد · 48 جودة أقل" },
  { id: "rifai", name: "هاني الرفاعي", folder: "Hani_Rifai_192kbps", note: "مرتل · 192" },
];

export function reciterById(id: string): Reciter {
  return RECITERS.find((r) => r.id === id) || RECITERS[0];
}

export function ayahAudioUrl(folder: string, surah: number, ayah: number): string {
  const s = String(surah).padStart(3, "0");
  const a = String(ayah).padStart(3, "0");
  return `https://everyayah.com/data/${folder}/${s}${a}.mp3`;
}

export const AUDIO_SOURCE =
  "ملفات التلاوة تُبث من EveryAyah.com وتُحفظ في جهازك عند التنزيل للاستماع دون اتصال. التطبيق لا يملك التسجيلات.";
