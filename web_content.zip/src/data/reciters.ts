import { Reciter } from '../types';

export const RECITERS: Reciter[] = [
  {
    id: 'alafasy',
    name: 'مشاري بن راشد العفاسي',
    subname: 'رواية حفص عن عاصم - مرتل',
    folder: 'Alafasy_128kbps',
  },
  {
    id: 'abdulbasit_murattal',
    name: 'عبد الباسط عبد الصمد',
    subname: 'المصحف المرتل - جودة عالية',
    folder: 'Abdul_Basit_Murattal_192kbps',
  },
  {
    id: 'abdulbasit_mujawwad',
    name: 'عبد الباسط عبد الصمد',
    subname: 'المصحف المجوّد الشهير (مدرسة مصر)',
    folder: 'Abdul_Basit_Mujawwad_128kbps',
  },
  {
    id: 'minshawi',
    name: 'محمد صديق المنشاوي',
    subname: 'المصحف المرتل الخاشع الباكي',
    folder: 'Minshawy_Murattal_128kbps',
  },
  {
    id: 'minshawi_mujawwad',
    name: 'محمد صديق المنشاوي',
    subname: 'المصحف المجوّد الخالد',
    folder: 'Minshawy_Mujawwad_192kbps',
  },
  {
    id: 'husary',
    name: 'محمود خليل الحصري',
    subname: 'المصحف المرتل - شيخ عموم المقارئ',
    folder: 'Husary_128kbps',
  },
  {
    id: 'husary_mujawwad',
    name: 'محمود خليل الحصري',
    subname: 'المصحف المجوّد المتقن',
    folder: 'Husary_128kbps_Mujawwad',
  },
  {
    id: 'mustafa_ismail',
    name: 'مصطفى إسماعيل',
    subname: 'عملاق التلاوة والمقامات القرآنية',
    folder: 'Mustafa_Ismail_48kbps',
  },
  {
    id: 'banna',
    name: 'محمود علي البنا',
    subname: 'المصحف المرتل برواية حفص عن عاصم',
    folder: 'mahmoud_ali_al_banna_32kbps',
  },
  {
    id: 'muaiqly',
    name: 'ماهر المعيقلي',
    subname: 'إمام الحرم المكي الشريف',
    folder: 'Maher_AlMuaiqly_64kbps',
  },
  {
    id: 'qatami',
    name: 'ناصر القطامي',
    subname: 'تلاوة خاشعة رقراقة تأسر القلوب',
    folder: 'Nasser_Alqatami_128kbps',
  },
  {
    id: 'dussary',
    name: 'ياسر الدوسري',
    subname: 'إمام الحرم المكي - نبرة شجية خاشعة',
    folder: 'Yasser_Ad-Dussary_128kbps',
  },
  {
    id: 'ali_jaber',
    name: 'علي جابر',
    subname: 'إمام الحرم المكي الراحل - التلاوة الخالدة',
    folder: 'Ali_Jaber_64kbps',
  },
  {
    id: 'ghamadi',
    name: 'سعد الغامدي',
    subname: 'تلاوة ندية هادئة',
    folder: 'Ghamadi_40kbps',
  },
  {
    id: 'shatri',
    name: 'أبو بكر الشاطري',
    subname: 'ترتيل عذب متقن',
    folder: 'Abu_Bakr_Ash-Shaatree_128kbps',
  },
  {
    id: 'sudais',
    name: 'عبد الرحمن السديس',
    subname: 'إمام وخطيب المسجد الحرام',
    folder: 'Abdurrahmaan_As-Sudais_192kbps',
  },
  {
    id: 'shuraym',
    name: 'سعود الشريم',
    subname: 'إمام المسجد الحرام السابق',
    folder: 'Saood_ash-Shuraym_128kbps',
  },
  {
    id: 'ajamy',
    name: 'أحمد بن علي العجمي',
    subname: 'تلاوة حزينة ومؤثرة',
    folder: 'ahmed_ibn_ali_al_ajamy_128kbps',
  },
  {
    id: 'ayyoub',
    name: 'محمد أيوب',
    subname: 'إمام المسجد النبوي الشريف - ترتيل حجازي عذب',
    folder: 'Muhammad_Ayyoub_128kbps',
  },
  {
    id: 'rifai',
    name: 'هاني الرفاعي',
    subname: 'تلاوة باكية مبكية',
    folder: 'Hani_Rifai_192kbps',
  },
];

/**
 * Returns the direct audio URL for a specific Ayah from EveryAyah CDN.
 * EveryAyah uses format: 3-digit surah + 3-digit ayah e.g. 001001.mp3
 */
export function getAyahAudioUrl(folder: string, surahNumber: number, ayahNumber: number): string {
  const surahStr = String(surahNumber).padStart(3, '0');
  const ayahStr = String(ayahNumber).padStart(3, '0');
  return `https://everyayah.com/data/${folder}/${surahStr}${ayahStr}.mp3`;
}
