import { Category, Ebook, ExamUpdate, CurrentAffairItem, MockTest, Coupon } from '../types';

export const categoriesData: Category[] = [
  {
    id: 'railway',
    name: 'Railway Exams',
    nameKey: 'railway',
    iconName: 'Train',
    gradient: 'from-blue-600 to-indigo-800',
    textColor: 'text-blue-100',
    borderAccent: 'border-blue-400',
    count: 24,
    subCategories: ['RRB ALP', 'RRB NTPC', 'Railway Group D', 'RPF Constable and SI', 'Railway Technician'],
    description: 'Comprehensive guides, CBT 1 & 2 question banks, technical trades, and mock practice sets for Indian Railways recruitment.'
  },
  {
    id: 'assam-police',
    name: 'Assam Police',
    nameKey: 'assam-police',
    iconName: 'ShieldAlert',
    gradient: 'from-emerald-700 to-teal-900',
    textColor: 'text-emerald-100',
    borderAccent: 'border-emerald-400',
    count: 18,
    subCategories: ['Assam Police Constable', 'Assam Police SI', 'Previous-Year Question Papers', 'Assam Police GK', 'Physical Test Preparation'],
    description: 'Dedicated study materials for SLPRB Assam Police UB/AB Constable, Sub-Inspector, Commando Battalion, and Physical Standard guides.'
  },
  {
    id: 'assam-govt-jobs',
    name: 'Assam Govt Jobs',
    nameKey: 'assam-govt-jobs',
    iconName: 'Landmark',
    gradient: 'from-amber-600 to-orange-800',
    textColor: 'text-amber-100',
    borderAccent: 'border-amber-400',
    count: 32,
    subCategories: ['Assam Direct Recruitment Grade III', 'Assam Direct Recruitment Grade IV', 'APSC Preparation', 'Forest Department', 'Excise Department', 'Assam GK and History'],
    description: 'ADRE 2.0 Class III & IV, APSC CCE Prelims, Assam History & Geography, Excise, and Forest Department syllabus coverage.'
  },
  {
    id: 'ssc-central',
    name: 'SSC & Central Govt',
    nameKey: 'ssc-central',
    iconName: 'Award',
    gradient: 'from-purple-700 to-indigo-950',
    textColor: 'text-purple-100',
    borderAccent: 'border-purple-400',
    count: 28,
    subCategories: ['SSC GD', 'SSC CHSL', 'SSC CGL', 'SSC MTS', 'Selection Post'],
    description: 'Bilingual chapter-wise TCS pattern question banks, English grammar, Quantitative aptitude, and General Awareness for Staff Selection Commission.'
  },
  {
    id: 'banking-finance',
    name: 'Banking & Finance',
    nameKey: 'banking-finance',
    iconName: 'Briefcase',
    gradient: 'from-sky-700 to-cyan-950',
    textColor: 'text-sky-100',
    borderAccent: 'border-sky-400',
    count: 16,
    subCategories: ['IBPS Clerk', 'IBPS PO', 'SBI Clerk', 'SBI PO', 'Assam Gramin/RRB Banking Exams'],
    description: 'Speed maths, high-level puzzles, banking awareness, financial aptitude, and Assam Gramin Vikash Bank specific sets.'
  },
  {
    id: 'defence-tech',
    name: 'Defence & Technical Trade',
    nameKey: 'defence-tech',
    iconName: 'Crosshair',
    gradient: 'from-rose-700 to-red-950',
    textColor: 'text-rose-100',
    borderAccent: 'border-rose-400',
    count: 22,
    subCategories: ['Army and Agniveer', 'India Post', 'Teaching and TET', 'General Knowledge', 'Reasoning', 'Mathematics', 'English', 'Computer Knowledge', 'Current Affairs', 'Interview Preparation', 'Electrician ITI and Technical Trade Study Material'],
    description: 'Agniveer GD/Tradesman, India Post GDS, Assam TET, ITI Electrician & Fitter theory, plus core subject mastery modules.'
  }
];

export const ebooksData: Ebook[] = [
  {
    id: 'nx-adre-gr3-mastery',
    title: 'Assam Direct Recruitment (ADRE) Grade III Complete Guide 2026',
    subtitle: 'Comprehensive Syllabus Coverage with 5000+ Chapter-wise MCQs & 5 Mock Tests',
    author: 'Nexa Assam Exam Editorial Board',
    publisher: 'Nexa Exam Publications, Guwahati',
    categoryId: 'assam-govt-jobs',
    subCategory: 'Assam Direct Recruitment Grade III',
    targetExam: 'ADRE Grade III',
    language: 'Assamese',
    price: 199,
    originalPrice: 499,
    discountPercent: 60,
    isFree: false,
    isBestseller: true,
    isFeatured: true,
    rating: 4.9,
    ratingCount: 1420,
    pageCount: 468,
    fileSize: '18.4 MB',
    format: 'PDF',
    coverGradient: 'from-[#0F172A] via-[#1E3E62] to-[#0B192C]',
    coverAccent: '#F59E0B',
    coverBadge: 'ADRE 2026 SPECIAL',
    description: 'The definitive handbook for Assam Direct Recruitment Grade III aspirants. Written in clear Assamese medium strictly following the official State Level Recruitment Commission (SLRC) syllabus. Includes full Assam General Knowledge, History of Assam, Geography, Indian Polity, General Mathematics, Logical Reasoning, Computer Application, and General English.',
    features: [
      'Written strictly as per latest SLRC syllabus & exam pattern',
      'Assam History from Ancient Pragjyotisha to Post-Independence Era',
      '2022, 2024 & 2025 Solved Question Papers with Explanations',
      '5 Full-length Mock Tests with OMR Sheet format',
      'Quick Revision Formula Sheet for Quantitative Aptitude'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'Introduction to ADRE Grade III Exam Pattern & Marks Distribution', pages: '1-14', isSample: true },
      { chapterNumber: 2, title: 'Ancient, Medieval and Modern Assam History', pages: '15-84', isSample: true },
      { chapterNumber: 3, title: 'Geography of Assam, National Parks & Wildlife Sanctuaries', pages: '85-142', isSample: true },
      { chapterNumber: 4, title: 'Assamese Literature, Culture, Festivals & Tribes', pages: '143-198' },
      { chapterNumber: 5, title: 'Indian Polity & Assam Governance Structure', pages: '199-245' },
      { chapterNumber: 6, title: 'General Mathematics & Numerical Ability (Tricks & Formulas)', pages: '246-320' },
      { chapterNumber: 7, title: 'Logical Reasoning & Analytical Mental Ability', pages: '321-382' },
      { chapterNumber: 8, title: 'General English & Vocabulary with Past Paper Rules', pages: '383-430' },
      { chapterNumber: 9, title: '5 Full-Length Model Practice Papers with Solutions', pages: '431-468' }
    ],
    sampleContent: {
      title: 'Chapter 2: Ancient, Medieval and Modern Assam History',
      chapterName: 'Sample Chapter: The Ahom Dynasty & Battle of Saraighat',
      text: 'The Ahom dynasty was established in 1228 CE by Chaolung Sukaphaa, a Tai prince from Mong Mao who crossed the Patkai mountains with around 9,000 followers. The kingdom established its first permanent capital at Charaideo in 1253 CE. One of the most decisive battles in Assam\'s military history was the Battle of Saraighat (1671 CE), fought on the Brahmaputra River near Guwahati. The Ahom army was led by legendary General Lachit Borphukan against the massive Mughal expeditionary forces commanded by Raja Ram Singh I of Amber. Using unmatched guerrilla warfare (Daga-Yuddha), psychological tactics, and riverine combat mastery, Lachit Borphukan completely routed the Mughal forces, permanently securing the eastern frontiers of Assam against Mughal conquest.',
      sampleQuestions: [
        {
          q: 'Who was the first king to establish the Ahom rule in Assam in 1228 CE?',
          a: 'Chaolung Sukaphaa',
          explanation: 'Chaolung Sukaphaa crossed the Patkai Hills and founded the Ahom Kingdom in 1228 CE, naming Charaideo as his first capital.'
        },
        {
          q: 'In which year was the famous naval Battle of Saraighat fought?',
          a: '1671 CE',
          explanation: 'The Battle of Saraighat was fought in 1671 between the Ahom Kingdom led by Lachit Borphukan and the Mughal forces led by Ram Singh.'
        },
        {
          q: 'Which Mughal general commanded the imperial army in the Battle of Saraighat?',
          a: 'Raja Ram Singh I of Amber',
          explanation: 'Emperor Aurangzeb dispatched Raja Ram Singh I of Amber to lead the Mughal forces against Assam.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'Nexa_ADRE_Grade3_Complete_Guide_2026.pdf',
    lastUpdated: '15 March 2026',
    edition: '4th Revised Edition 2026',
    isbn: '978-93-89124-77-1',
    officialSourceUrl: 'https://assam.gov.in'
  },
  {
    id: 'nx-rrb-ntpc-cbt1-cbt2',
    title: 'RRB NTPC 2026 Master Question Bank (CBT-1 & CBT-2)',
    subtitle: '7500+ TCS Pattern MCQs with 100% Detailed Step-by-Step Solutions',
    author: 'Er. R. K. Sharma & Nexa Railway Wing',
    publisher: 'Nexa Tech Exam Press',
    categoryId: 'railway',
    subCategory: 'RRB NTPC',
    targetExam: 'RRB NTPC (Non-Technical Popular Categories)',
    language: 'English',
    price: 179,
    originalPrice: 449,
    discountPercent: 60,
    isFree: false,
    isBestseller: true,
    isFeatured: true,
    rating: 4.8,
    ratingCount: 2310,
    pageCount: 520,
    fileSize: '22.1 MB',
    format: 'PDF',
    coverGradient: 'from-[#1E3A8A] via-[#1D4ED8] to-[#0F172A]',
    coverAccent: '#FBBF24',
    coverBadge: 'TCS PATTERN 2026',
    description: 'Designed for Railway Recruitment Board (RRB) NTPC Graduate and Under Graduate posts. Contains comprehensive topic-wise coverage of General Awareness, Mathematics, and General Intelligence & Reasoning. Fully updated with latest TCS questions asked across all Railway shifts in 2024-2025.',
    features: [
      '7,500+ Chapter-wise TCS Pattern Questions',
      'Detailed visual explanations for Data Interpretation and Puzzles',
      'Special section on Indian Railways History, Facts & Budget 2026',
      'Short-trick methods for Arithmetic & Advanced Algebra',
      'Includes 10 CBT Practice Sets strictly timed'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'RRB NTPC CBT 1 & 2 Blueprint & Normalization Insights', pages: '1-12', isSample: true },
      { chapterNumber: 2, title: 'Number Systems, LCM-HCF, Simplification & Surds', pages: '13-58', isSample: true },
      { chapterNumber: 3, title: 'Percentages, Profit & Loss, SI & CI Quick Formulas', pages: '59-112', isSample: true },
      { chapterNumber: 4, title: 'Time & Work, Pipes & Cisterns, Speed Time & Distance', pages: '113-176' },
      { chapterNumber: 5, title: 'Geometry, Mensuration 2D/3D & Trigonometry', pages: '177-240' },
      { chapterNumber: 6, title: 'Coding-Decoding, Syllogism, Blood Relations, Seating Arrangement', pages: '241-325' },
      { chapterNumber: 7, title: 'Indian Railways Heritage, Zones, Mascot & Vande Bharat Tech', pages: '326-370' },
      { chapterNumber: 8, title: 'General Science (Physics, Chemistry, Biology) High-Yield Points', pages: '371-460' },
      { chapterNumber: 9, title: '10 Full-Length CBT Practice Question Sets', pages: '461-520' }
    ],
    sampleContent: {
      title: 'Chapter 7: Indian Railways Heritage, Zones & Technology',
      chapterName: 'Sample: Railway Zones, Headquarters & Indian Rail Milestones',
      text: 'Indian Railways is divided into 19 zones (including Kolkata Metro and South Coast Railway headquartered in Visakhapatnam). The Northeast Frontier Railway (NFR) is headquartered at Maligaon, Guwahati, serving all eight northeastern states, northern West Bengal, and parts of Bihar. The first passenger train in India ran on 16 April 1853 between Bori Bunder (Bombay) and Thane over a distance of 34 kilometres, hauled by three steam locomotives named Sultan, Sindh, and Sahib. India\'s first semi-high speed train, Vande Bharat Express (Train 18), was designed and manufactured by the Integral Coach Factory (ICF) at Perambur, Chennai, under the Make in India initiative.',
      sampleQuestions: [
        {
          q: 'Where is the headquarters of the Northeast Frontier Railway (NFR) located?',
          a: 'Maligaon, Guwahati',
          explanation: 'Northeast Frontier Railway (NFR) is headquartered at Maligaon in Guwahati, Assam.'
        },
        {
          q: 'What were the names of the three locomotives used in the maiden passenger train run from Bombay to Thane in 1853?',
          a: 'Sultan, Sindh, and Sahib',
          explanation: 'The three historic steam locomotives that hauled the first train were named Sultan, Sindh, and Sahib.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'RRB_NTPC_2026_Master_Question_Bank.pdf',
    lastUpdated: '02 April 2026',
    edition: '2026 Golden Edition',
    isbn: '978-93-5510-182-3',
    officialSourceUrl: 'https://rrbcdg.gov.in'
  },
  {
    id: 'nx-assam-police-si-ub-ab',
    title: 'Assam Police Sub-Inspector (UB/AB) Complete Exam Cracker',
    subtitle: 'Previous Years Solved Papers, Assam GK, Criminal Law Basics & Mental Ability',
    author: 'Police Exam Mentors Team & Pranjal Bora',
    publisher: 'Nexa Assam Career Press',
    categoryId: 'assam-police',
    subCategory: 'Assam Police SI',
    targetExam: 'Assam Police Sub-Inspector',
    language: 'Assamese',
    price: 149,
    originalPrice: 399,
    discountPercent: 63,
    isFree: false,
    isBestseller: true,
    isFeatured: true,
    rating: 4.9,
    ratingCount: 1890,
    pageCount: 390,
    fileSize: '16.8 MB',
    format: 'PDF',
    coverGradient: 'from-[#064E3B] via-[#047857] to-[#022C22]',
    coverAccent: '#FACC15',
    coverBadge: 'SLPRB POLICE SPECIAL',
    description: 'Designed exclusively for SLPRB Assam Police Sub-Inspector Unarmed Branch (UB) and Armed Branch (AB) recruitment tests. Features exhaustive coverage of General Awareness, Assam History, Indian Penal System & Constitutional Rights, Reasoning, and Basic Mathematics with Assamese & English medium support.',
    features: [
      'Comprehensive coverage of SLPRB SI written exam syllabus',
      'Assam History, Geography, Assam Art & Culture focus',
      'Basic knowledge of Bharatiya Nyaya Sanhita (BNS) & Indian Constitution',
      'Previous 5 recruitment cycle actual papers solved with answer keys',
      'Physical Efficiency Test (PET) & Physical Standard Test (PST) guidelines'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'Assam Police SI Exam Scheme, Marks Distribution & Cutoff Analysis', pages: '1-10', isSample: true },
      { chapterNumber: 2, title: 'General Knowledge: Assam State, Geography, Economy & Demographics', pages: '11-75', isSample: true },
      { chapterNumber: 3, title: 'Constitutional Rights, Fundamental Duties & Police Administration', pages: '76-130' },
      { chapterNumber: 4, title: 'Logical Reasoning, Direction Sense, Coding & Puzzles', pages: '131-210' },
      { chapterNumber: 5, title: 'Elementary Mathematics: Arithmetic, Data Interpretation & Mensuration', pages: '211-285' },
      { chapterNumber: 6, title: 'Current Affairs (National, Regional, Sports & Awards)', pages: '286-340' },
      { chapterNumber: 7, title: 'Solved Papers (2020, 2022, 2024, 2025 SLPRB Exams)', pages: '341-390' }
    ],
    sampleContent: {
      title: 'Chapter 1: SLPRB Assam Police SI Scheme & Physical Standards',
      chapterName: 'Sample: Selection Process & Written Exam Pattern',
      text: 'The written test for Assam Police Sub Inspector conducted by the State Level Police Recruitment Board (SLPRB) consists of 100 marks with 100 multiple-choice questions. Each correct answer carries 1 mark, with 0.50 negative marking for every incorrect answer. The paper is bilingual (Assamese, Bodo, Bengali, and English). Candidates who qualify the written exam in the ratio of 1:5 are called for the Physical Standard Test (PST) and Physical Efficiency Test (PET) carrying 40 marks.',
      sampleQuestions: [
        {
          q: 'What is the negative marking per wrong answer in the Assam Police SI written test?',
          a: '0.50 marks (Half Mark)',
          explanation: 'As per SLPRB guidelines, there is a penalty of 0.50 marks for each incorrect response in the 100-mark paper.'
        },
        {
          q: 'Which body is responsible for conducting recruitment for Assam Police?',
          a: 'State Level Police Recruitment Board (SLPRB), Assam',
          explanation: 'The SLPRB Assam is the statutory body entrusted with conducting competitive recruitment for all police cadres.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'Assam_Police_SI_UB_AB_Exam_Cracker_2026.pdf',
    lastUpdated: '10 March 2026',
    edition: '2026 Edition',
    officialSourceUrl: 'https://slprb.assam.gov.in'
  },
  {
    id: 'nx-rrb-alp-tech-cbt1',
    title: 'RRB Assistant Loco Pilot (ALP) & Technician CBT-1 Complete Kit',
    subtitle: 'Chapter-wise Basic Science, Engineering Concepts, Math & Reasoning',
    author: 'Er. Sandeep Verma, M.Tech (Mech)',
    publisher: 'Nexa Railway Tech Wing',
    categoryId: 'railway',
    subCategory: 'RRB ALP',
    targetExam: 'RRB ALP & Technician',
    language: 'Hindi',
    price: 159,
    originalPrice: 399,
    discountPercent: 60,
    isFree: false,
    isBestseller: false,
    isNewArrival: true,
    rating: 4.7,
    ratingCount: 950,
    pageCount: 412,
    fileSize: '19.5 MB',
    format: 'PDF',
    coverGradient: 'from-[#1E1B4B] via-[#312E81] to-[#0F172A]',
    coverAccent: '#F59E0B',
    coverBadge: 'NEW ALP 2026',
    description: 'RRB ALP एवं तकनीशियन CBT-1 परीक्षा के लिए सर्वश्रेष्ठ हिंदी माध्यम पुस्तक। इसमें बेसिक साइंस एवं इंजीनियरिंग, गणित, सामान्य बुद्धिमत्ता एवं तर्कशक्ति और समसामयिक विषयों के अध्यायवार प्रश्नोत्तरी विस्तृत हल के साथ शामिल हैं।',
    features: [
      'CBT-1 के संपूर्ण 75 प्रश्नों के पैटर्न पर आधारित',
      'बेसिक साइंस और इंजीनियरिंग के 1500+ सचित्र प्रश्न',
      'गणित और रीजनिंग के शॉर्टकट ट्रिक्स और फॉर्मूला चार्ट',
      'पिछले वर्षों (2018-2024) के सभी शिफ्टों के हल प्रश्न'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'आरआरबी एएलपी सीबीटी-1 परीक्षा पैटर्न एवं टाइम मैनेजमेंट', pages: '1-8', isSample: true },
      { chapterNumber: 2, title: 'इकाइयाँ और माप (Units & Measurement), द्रव्यमान और घनत्व', pages: '9-52', isSample: true },
      { chapterNumber: 3, title: 'कार्य, शक्ति एवं ऊर्जा (Work, Power & Energy)', pages: '53-95' },
      { chapterNumber: 4, title: 'चाल और वेग, ऊष्मा और तापमान (Heat & Temperature)', pages: '96-150' },
      { chapterNumber: 5, title: 'मूलभूत विद्युत (Basic Electricity) एवं इलेक्ट्रॉनिक सिद्धांत', pages: '151-215' },
      { chapterNumber: 6, title: 'गणित: संख्या पद्धति, त्रिकोणमिति, क्षेत्रमिति और समय कार्य', pages: '216-310' },
      { chapterNumber: 7, title: 'सामान्य बुद्धिमत्ता एवं रीजनिंग (दिशा, रक्त संबंध, पहेलियां)', pages: '311-370' },
      { chapterNumber: 8, title: '5 फुल-लेंथ सीबीटी-1 मॉडल अभ्यास सेट्स', pages: '371-412' }
    ],
    sampleContent: {
      title: 'अध्याय 2: इकाइयाँ, माप और मूलभूत भौतिक राशियाँ',
      chapterName: 'सैंपल: SI मात्रक एवं विमीय सूत्र',
      text: 'अंतरराष्ट्रीय मात्रक प्रणाली (SI) में 7 मूल मात्रक होते हैं: लम्बाई (मीटर - m), द्रव्यमान (किलोग्राम - kg), समय (सेकंड - s), विद्युत धारा (एम्पीयर - A), ताप (केल्विन - K), ज्योति तीव्रता (कैंडेला - cd), और पदार्थ की मात्रा (मोल - mol)। शक्ति की SI इकाई वॉट (Watt) होती है, जहाँ 1 अश्वशक्ति (Horse Power) = 746 वॉट होता है। विद्युत ऊर्जा का व्यावसायिक मात्रक किलोवाट-घंटा (kWh) होता है, जहाँ 1 kWh = 3.6 × 10^6 जूल होता है।',
      sampleQuestions: [
        {
          q: '1 हॉर्स पावर (HP) में कितने वॉट होते हैं?',
          a: '746 वॉट (Watt)',
          explanation: '1 मेट्रिक हॉर्सपावर में 746 वॉट की विद्युत शक्ति के बराबर माना जाता है।'
        },
        {
          q: 'विद्युत ऊर्जा की व्यावसायिक इकाई (Commercial Unit) क्या है?',
          a: 'किलोवाट घंटा (kWh / 1 Unit)',
          explanation: 'घरेलू बिजली बिलिंग के लिए 1 यूनिट = 1 kWh = 3.6 × 10^6 जूल होता है।'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'RRB_ALP_Tech_CBT1_Complete_Guide_Hindi.pdf',
    lastUpdated: '18 March 2026',
    edition: '2026 Edition',
    officialSourceUrl: 'https://rrbcdg.gov.in'
  },
  {
    id: 'nx-assam-direct-recruitment-gr4',
    title: 'Assam Direct Recruitment (ADRE) Grade IV Practice Workbook',
    subtitle: 'Strictly as per Class 8 & Class 10 Level Syllabus with 3000+ Questions',
    author: 'Nexa Assam Exam Team',
    publisher: 'Nexa Exam Publications, Guwahati',
    categoryId: 'assam-govt-jobs',
    subCategory: 'Assam Direct Recruitment Grade IV',
    targetExam: 'ADRE Grade IV',
    language: 'Assamese',
    price: 99,
    originalPrice: 299,
    discountPercent: 67,
    isFree: false,
    isBestseller: true,
    isFeatured: false,
    rating: 4.8,
    ratingCount: 1650,
    pageCount: 310,
    fileSize: '12.4 MB',
    format: 'PDF',
    coverGradient: 'from-[#78350F] via-[#92400E] to-[#451A03]',
    coverAccent: '#FBBF24',
    coverBadge: 'CLASS 8/10 LEVEL',
    description: 'Specialized simplified workbook for ADRE Grade IV examination (Peon, Chowkidar, Khalasi, Field Worker, etc.). High yield questions on basic Assam GK, simple mathematics, mental ability, and everyday science in lucid Assamese.',
    features: [
      'Designed strictly for Class VIII & Class X pass candidates',
      'Simple language with clear illustrations',
      '30 Practice question sets with detailed answers',
      'Covers all previous ADRE Grade IV papers'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'Grade IV Exam Structure & Marking Rules', pages: '1-6', isSample: true },
      { chapterNumber: 2, title: 'Basic Assam Knowledge & Famous Personalities', pages: '7-65', isSample: true },
      { chapterNumber: 3, title: 'Simple Arithmetic & Daily Life Maths', pages: '66-135' },
      { chapterNumber: 4, title: 'Mental Aptitude & Visual Puzzles', pages: '136-190' },
      { chapterNumber: 5, title: 'General Science in Everyday Life', pages: '191-240' },
      { chapterNumber: 6, title: '15 Full-length Mock Tests for Grade IV', pages: '241-310' }
    ],
    sampleContent: {
      title: 'Chapter 2: Basic Assam Knowledge & Historical Sites',
      chapterName: 'Sample: State Symbols & National Parks of Assam',
      text: 'Assam is blessed with rich bio-diversity. The state animal of Assam is the Great Indian One-Horned Rhinoceros (Rhino unicornis), and the state bird is the White-Winged Wood Duck (Deo Hah). The state tree is Hollong, and the state flower is Kopou Phool (Foxtail Orchid). Assam has 7 National Parks: Kaziranga, Manas, Nameri, Orang, Dibru-Saikhowa, Raimona, and Dihing Patkai. Kaziranga and Manas are also designated UNESCO World Heritage Sites.',
      sampleQuestions: [
        {
          q: 'What is the state bird of Assam?',
          a: 'White-Winged Wood Duck (Deo Hah)',
          explanation: 'The White-Winged Wood Duck (Deo Hah) is the official state bird of Assam.'
        },
        {
          q: 'How many National Parks are there in Assam at present?',
          a: '7 National Parks',
          explanation: 'Assam has 7 National Parks, with Raimona and Dihing Patkai being the latest additions in 2021.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'ADRE_Grade4_Practice_Workbook_Assamese.pdf',
    lastUpdated: '12 February 2026',
    edition: '2026 Edition',
    officialSourceUrl: 'https://assam.gov.in'
  },
  {
    id: 'nx-ssc-cgl-tier1-tier2-english',
    title: 'SSC CGL 2026 Tier 1 & Tier 2 Comprehensive English Guide',
    subtitle: 'Grammar Rules, Vocabulary Builder (Root Words), Cloze Test & Comprehension',
    author: 'Prof. Ananya Sen & Nexa Editorial Board',
    publisher: 'Nexa SSC Wing, New Delhi',
    categoryId: 'ssc-central',
    subCategory: 'SSC CGL',
    targetExam: 'SSC CGL Tier 1 & Tier 2',
    language: 'English',
    price: 189,
    originalPrice: 499,
    discountPercent: 62,
    isFree: false,
    isBestseller: true,
    isFeatured: true,
    rating: 4.9,
    ratingCount: 3120,
    pageCount: 440,
    fileSize: '17.2 MB',
    format: 'PDF',
    coverGradient: 'from-[#3B0764] via-[#581C87] to-[#1E1B4B]',
    coverAccent: '#F59E0B',
    coverBadge: 'SSC CGL TOP RATED',
    description: 'The definitive guide for mastering English Comprehension in SSC CGL Tier 1 & 2. Features 100 Golden Grammar Rules with exam-oriented exceptions, 3000+ One Word Substitutions, Idioms & Phrases with memory mnemonics, and extensive practice passages.',
    features: [
      '100 Golden Rules of English Grammar with Error Spotting Exercises',
      '3000+ High-Frequency Words with Etymology and Synonyms/Antonyms',
      'Advanced Cloze Test & Para Jumbles (Sentence Rearrangement) Strategies',
      'Tier 2 High-Scoring Reading Comprehension Passages',
      'Solved Papers from SSC CGL 2020 through 2025'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'Subject-Verb Agreement & Golden Grammar Rules', pages: '1-45', isSample: true },
      { chapterNumber: 2, title: 'Nouns, Pronouns, Adjectives & Adverbs Mastery', pages: '46-95', isSample: true },
      { chapterNumber: 3, title: 'Tenses, Conditionals & Subjunctive Mood', pages: '96-140' },
      { chapterNumber: 4, title: 'Active-Passive Voice & Direct-Indirect Speech Transformations', pages: '141-190' },
      { chapterNumber: 5, title: 'Root Words, Prefixes & Suffixes Vocabulary System', pages: '191-260' },
      { chapterNumber: 6, title: 'Idioms, Phrasal Verbs & Confusing Words', pages: '261-320' },
      { chapterNumber: 7, title: 'Cloze Tests & Sentence Rearrangement (PQRS)', pages: '321-380' },
      { chapterNumber: 8, title: 'Tier 2 Model Practice Papers with Explanations', pages: '381-440' }
    ],
    sampleContent: {
      title: 'Chapter 1: Subject-Verb Agreement Golden Rules',
      chapterName: 'Sample: Rule 3 & 4 (Neither-Nor, As Well As, Collective Nouns)',
      text: 'Rule: When two subjects are connected by "as well as", "along with", "together with", "in addition to", "accompanied by", or "like", the verb agrees with the FIRST subject. Example: The captain, along with his crew members, WAS rewarded (not were). Conversely, when subjects are joined by "either... or", "neither... nor", or "not only... but also", the verb agrees with the NEAREST subject.',
      sampleQuestions: [
        {
          q: 'Find the error: "The Minister, together with his secretaries, are arriving tomorrow."',
          a: 'Error in "are arriving" -> Should be "is arriving"',
          explanation: 'When two subjects are connected by "together with", the verb agrees with the first subject ("The Minister", singular).'
        },
        {
          q: 'Neither the manager nor the employees _____ present at the conference yesterday.',
          a: 'were',
          explanation: 'With "neither... nor", the verb agrees with the closest subject ("the employees", plural).'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'SSC_CGL_English_Mastery_Tier1_Tier2.pdf',
    lastUpdated: '22 March 2026',
    edition: '2026 Edition',
    isbn: '978-93-88210-90-5',
    officialSourceUrl: 'https://ssc.gov.in'
  },
  {
    id: 'nx-assam-gk-history-encyclopedia',
    title: 'Assam Year Book & General Knowledge Encyclopedia 2026',
    subtitle: 'Complete Assam History, Geography, Economy, Tribes, Schemes & Culture',
    author: 'Dr. Hiranya Dutta & Nexa Assam Research Cell',
    publisher: 'Nexa Assam Publications',
    categoryId: 'assam-govt-jobs',
    subCategory: 'Assam GK and History',
    targetExam: 'All Assam Govt Exams (APSC, ADRE, Police, Forest)',
    language: 'English',
    price: 169,
    originalPrice: 420,
    discountPercent: 60,
    isFree: false,
    isBestseller: true,
    isFeatured: true,
    rating: 4.95,
    ratingCount: 2840,
    pageCount: 512,
    fileSize: '24.2 MB',
    format: 'PDF',
    coverGradient: 'from-[#064E3B] via-[#0F766E] to-[#134E4A]',
    coverAccent: '#F59E0B',
    coverBadge: 'ESSENTIAL FOR ASSAM EXAMS',
    description: 'The most comprehensive single-volume encyclopedia on Assam for competitive exams. Recommended by past APSC toppers. Covers all 35 districts, Brahmaputra and Barak river systems, Oil and Coal reserves, Tea industry, Major tribes, Bihu, Srimanta Sankardev and Neo-Vaishnavite culture, Bodoland Accord, and State Budget 2026-27.',
    features: [
      'District-wise detailed profile of all 35 districts of Assam',
      'Comprehensive chronicle of Ahom, Koch, Kachari, and Chutiya dynasties',
      'Assam in the Indian Freedom Movement with all key martyrs',
      'Biodiversity, Ramsar Sites, and Environmental conservation laws',
      'Current State Schemes: Orunodoi 3.0, Atmanirbhar Asom, Nijut Moina'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'Geographical Features, Rivers, Minerals & Climate of Assam', pages: '1-60', isSample: true },
      { chapterNumber: 2, title: 'Political History: Varman, Salastambha, Pala Dynasties', pages: '61-120', isSample: true },
      { chapterNumber: 3, title: 'Ahom Era (1228-1826) & Treaty of Yandabo', pages: '121-190' },
      { chapterNumber: 4, title: 'Assam Freedom Struggle: 1857 to 1947', pages: '191-255' },
      { chapterNumber: 5, title: 'Art, Neo-Vaishnavism, Sattriya Dance, Masks & Literature', pages: '256-320' },
      { chapterNumber: 6, title: 'Economy: Tea, Oil & Gas, Agriculture, Tourism & Transport', pages: '321-395' },
      { chapterNumber: 7, title: 'District Profiles (All 35 Districts Key Facts)', pages: '396-470' },
      { chapterNumber: 8, title: '1000 Practice MCQs with Answers', pages: '471-512' }
    ],
    sampleContent: {
      title: 'Chapter 3: The Ahom Kingdom & Treaty of Yandabo (1826)',
      chapterName: 'Sample: End of Ahom Rule & British Annexation',
      text: 'The Ahom kingdom, which ruled Assam for nearly six centuries, came to an end following Burmese invasions (Maanor Akromon) between 1817 and 1826. The First Anglo-Burmese War broke out in 1824. With the British victory over Burma, the historic Treaty of Yandabo was signed on 24 February 1826 between General Sir Archibald Campbell and Maha Min Hla Kyaw Htin. Under Article 2 of this treaty, the King of Ava (Burma) renounced all claims upon, and agreed to abstain from all interference with, the territory of Assam, Jaintia, and Cachar. This marked the commencement of British colonial administration in Assam.',
      sampleQuestions: [
        {
          q: 'On which date was the Treaty of Yandabo signed?',
          a: '24 February 1826',
          explanation: 'The Treaty of Yandabo was signed on 24 February 1826, concluding the First Anglo-Burmese War and paving the way for British rule in Assam.'
        },
        {
          q: 'Who was the British general who signed the Treaty of Yandabo on behalf of the British East India Company?',
          a: 'General Sir Archibald Campbell',
          explanation: 'Sir Archibald Campbell served as the British commander and signatory.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'Assam_GK_Encyclopedia_2026.pdf',
    lastUpdated: '05 April 2026',
    edition: '12th Edition 2026',
    isbn: '978-93-8745-120-4',
    officialSourceUrl: 'https://assam.gov.in'
  },
  {
    id: 'nx-free-assam-budget-economic-survey',
    title: 'Assam State Budget 2026-27 & Economic Survey Highlights',
    subtitle: 'Free Essential Digest for APSC, ADRE & Assam Police Aspirants',
    author: 'Nexa Research Cell',
    publisher: 'Nexa Free Learning Series',
    categoryId: 'assam-govt-jobs',
    subCategory: 'Assam GK and History',
    targetExam: 'APSC, ADRE, Assam Police, Forest Dept',
    language: 'English',
    price: 0,
    originalPrice: 150,
    discountPercent: 100,
    isFree: true,
    isFeatured: true,
    rating: 4.9,
    ratingCount: 4210,
    pageCount: 84,
    fileSize: '4.8 MB',
    format: 'PDF',
    coverGradient: 'from-[#047857] via-[#059669] to-[#065F46]',
    coverAccent: '#FBBF24',
    coverBadge: '100% FREE EBOOK',
    description: 'Free public study material provided by NEXA EXAM BOOKS. Contains summary of the Assam State Budget 2026-27, key welfare schemes, capital expenditures, state GDP projections, and 200 high-probability exam questions.',
    features: [
      'Completely FREE - No payment required to download or read',
      'Detailed sector-wise allocation summary',
      'Orunodoi, Nijut Moina, and Atmanirbhar Asom updates',
      '200 Model Multiple Choice Questions with Explanations'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'Macroeconomic Overview of Assam (GSDP & Growth Rate)', pages: '1-16', isSample: true },
      { chapterNumber: 2, title: 'Budget at a Glance: Revenue, Fiscal Deficit & Capital Outlay', pages: '17-38', isSample: true },
      { chapterNumber: 3, title: 'Flagship Schemes & Direct Beneficiary Programs', pages: '39-60', isSample: true },
      { chapterNumber: 4, title: '200 Practice MCQs for APSC & ADRE', pages: '61-84', isSample: true }
    ],
    sampleContent: {
      title: 'Chapter 2: Budget at a Glance',
      chapterName: 'Sample: Key Allocations & Infrastructure Investments',
      text: 'The Assam State Budget 2026-27 reinforces strong capital expenditure with priority funding for road infrastructure, healthcare institutes, flood and erosion mitigation, and education modernization. The flagship Nijut Moina scheme provides financial assistance to girl students in higher education to curb child marriage and enhance female gross enrolment ratio.',
      sampleQuestions: [
        {
          q: 'What is the primary objective of the "Nijut Moina" scheme in Assam?',
          a: 'Financial support to girl students for higher education and prevention of child marriage',
          explanation: 'Nijut Moina provides monthly stipends to girl students pursuing Higher Secondary, Degree, and Post-Graduate studies.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'Assam_Budget_Economic_Survey_2026_Nexa_Free.pdf',
    lastUpdated: '28 February 2026',
    edition: 'Free Release 2026',
    officialSourceUrl: 'https://finance.assam.gov.in'
  },
  {
    id: 'nx-sbi-clerk-prelims-mains-kit',
    title: 'SBI Clerk (Junior Associate) Prelims & Mains 50 Practice Papers',
    subtitle: 'High Level DI, Reasoning Puzzles, English, Financial & Banking Awareness',
    author: 'Sunil Nair & Nexa Banking Faculty',
    publisher: 'Nexa Banking Press, Mumbai',
    categoryId: 'banking-finance',
    subCategory: 'SBI Clerk',
    targetExam: 'SBI Clerk (Junior Associate)',
    language: 'English',
    price: 199,
    originalPrice: 499,
    discountPercent: 60,
    isFree: false,
    isBestseller: false,
    isNewArrival: true,
    rating: 4.8,
    ratingCount: 1120,
    pageCount: 480,
    fileSize: '21.0 MB',
    format: 'PDF',
    coverGradient: 'from-[#0C4A6E] via-[#0284C7] to-[#082F49]',
    coverAccent: '#F59E0B',
    coverBadge: 'SBI CLERK 2026',
    description: 'Targeted preparation tool for State Bank of India Clerk Prelims and Mains. Includes recent pattern sectional tests with time management tips, seating arrangement masterclass, and RBI circular summaries.',
    features: [
      '50 Full-Length Mock Papers (30 Prelims + 20 Mains)',
      'Detailed video-style step-by-step solutions',
      'Advanced Circular & Linear Seating Arrangements',
      'Monthly Banking Awareness Question Bank'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'SBI Clerk Syllabus, Trend Analysis & Speed Strategies', pages: '1-15', isSample: true },
      { chapterNumber: 2, title: 'Speed Mathematics: Simplification, Approximation, Number Series', pages: '16-70', isSample: true },
      { chapterNumber: 3, title: 'Data Interpretation (Tabular, Pie, Bar, Radar & Caselet)', pages: '71-150' },
      { chapterNumber: 4, title: 'Logical Reasoning & Multi-Variable Puzzles', pages: '151-240' },
      { chapterNumber: 5, title: 'General & Financial Awareness (RBI, Monitory Policy, Fintech)', pages: '241-330' },
      { chapterNumber: 6, title: 'English Language: Error Detection, Sentence Fillers, RC', pages: '331-410' },
      { chapterNumber: 7, title: 'Full Length Mains Practice Sets', pages: '411-480' }
    ],
    sampleContent: {
      title: 'Chapter 5: General & Financial Awareness',
      chapterName: 'Sample: RBI Monetary Policy Instruments & Key Rates',
      text: 'The Reserve Bank of India (RBI) utilizes qualitative and quantitative instruments to manage liquidity. Key quantitative tools include Repo Rate (the rate at which RBI lends short-term money to commercial banks against government securities), Reverse Repo Rate, Marginal Standing Facility (MSF), Cash Reserve Ratio (CRR), and Statutory Liquidity Ratio (SLR). The Monetary Policy Committee (MPC) consists of 6 members (3 from RBI, 3 appointed by Central Government) chaired by the RBI Governor.',
      sampleQuestions: [
        {
          q: 'Who chairs the Monetary Policy Committee (MPC) of India?',
          a: 'Governor of the Reserve Bank of India (RBI)',
          explanation: 'The Governor of RBI is the ex-officio Chairperson of the 6-member Monetary Policy Committee.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'SBI_Clerk_Prelims_Mains_Kit_2026.pdf',
    lastUpdated: '14 March 2026',
    edition: '2026 Edition',
    officialSourceUrl: 'https://sbi.co.in/careers'
  },
  {
    id: 'nx-assam-police-constable-pyq',
    title: 'Assam Police AB/UB Constable 10-Years Solved Papers (2015-2025)',
    subtitle: 'With Detailed Explanations in Assamese & English + Physical Test Tips',
    author: 'SLPRB Mentors Wing',
    publisher: 'Nexa Assam Career Press',
    categoryId: 'assam-police',
    subCategory: 'Previous-Year Question Papers',
    targetExam: 'Assam Police Constable AB/UB & Commando',
    language: 'Bilingual (Eng/Assamese)',
    price: 119,
    originalPrice: 299,
    discountPercent: 60,
    isFree: false,
    isBestseller: true,
    isFeatured: false,
    rating: 4.85,
    ratingCount: 2150,
    pageCount: 320,
    fileSize: '14.1 MB',
    format: 'PDF',
    coverGradient: 'from-[#065F46] via-[#047857] to-[#022C22]',
    coverAccent: '#F59E0B',
    coverBadge: '10-YEAR PYQ',
    description: 'Authentic previous year question papers of SLPRB Assam Police Constable Unarmed Branch, Armed Branch, Commando Battalion, and APRO. Fully solved with bilingual explanations and answer key authentications.',
    features: [
      '10 Years of original SLPRB question papers',
      'Both Assamese and English question texts',
      'Cutoff trends and category-wise analysis for all districts',
      'Includes 1600m / 3200m running and long jump preparation guide'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'SLPRB Constable Recruitment Guidelines & Physical Test Criteria', pages: '1-14', isSample: true },
      { chapterNumber: 2, title: '2025 SLPRB Constable Solved Paper with Explanations', pages: '15-45', isSample: true },
      { chapterNumber: 3, title: '2024 SLPRB Constable Solved Paper', pages: '46-76' },
      { chapterNumber: 4, title: '2022 SLPRB AB/UB Constable Solved Paper', pages: '77-110' },
      { chapterNumber: 5, title: '2020 & 2018 SLPRB Previous Papers', pages: '111-180' },
      { chapterNumber: 6, title: 'Topic-wise High Frequency Assam GK & Reasoning Questions', pages: '181-260' },
      { chapterNumber: 7, title: '5 Model Mock Papers for Upcoming 2026 Exam', pages: '261-320' }
    ],
    sampleContent: {
      title: 'Chapter 1: SLPRB Constable Physical Test Criteria',
      chapterName: 'Sample: Physical Standards and Running Requirements',
      text: 'For male candidates, the Physical Efficiency Test (PET) requires completing a 3200-meter race within 14 minutes (840 seconds). Maximum marks are awarded for completing the run in less than 600 seconds (10 minutes). For female candidates, the race is 1600 meters to be completed within 8 minutes. Long jump requires minimum 335 cm for males and 244 cm for females.',
      sampleQuestions: [
        {
          q: 'What is the standard running distance for male candidates in Assam Police Constable PET?',
          a: '3200 meters (3.2 km)',
          explanation: 'Male candidates must run 3200 meters, while female candidates run 1600 meters.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'Assam_Police_Constable_10Yr_PYQ.pdf',
    lastUpdated: '01 March 2026',
    edition: '2026 Edition',
    officialSourceUrl: 'https://slprb.assam.gov.in'
  },
  {
    id: 'nx-electrician-iti-technical-trade',
    title: 'ITI Electrician & Wireman Trade Theory Master Handbook',
    subtitle: 'Bilingual Hindi/English Guide for Railway ALP, Technician, Metro & State Power Utilities',
    author: 'Er. D. K. Sahoo, B.E. (Electrical)',
    publisher: 'Nexa Technical Publications',
    categoryId: 'defence-tech',
    subCategory: 'Electrician ITI and Technical Trade Study Material',
    targetExam: 'RRB Technician Grade III, Metro Rail, APDCL, State Electricity Boards',
    language: 'Hindi',
    price: 169,
    originalPrice: 420,
    discountPercent: 60,
    isFree: false,
    isBestseller: false,
    isFeatured: true,
    rating: 4.8,
    ratingCount: 780,
    pageCount: 384,
    fileSize: '17.6 MB',
    format: 'PDF',
    coverGradient: 'from-[#881337] via-[#9F1239] to-[#4C0519]',
    coverAccent: '#FBBF24',
    coverBadge: 'ITI ELECTRICIAN SPECIAL',
    description: 'Electrician & Wireman trade theory guide following the NSQF Level 5 DGT syllabus. Perfect for candidates targeting RRB Technician Grade III, DMRC, APDCL Junior Manager / Assistant Accounts Officer, and PSU technical tests.',
    features: [
      'Strictly based on latest DGT NSQF Level 5 syllabus',
      'Over 2500 objective questions with circuit diagrams',
      'AC & DC machines, Transformer, Safety & Earthing practices',
      'Formulas and numerical problems solved step-by-step'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'व्यावसायिक सुरक्षा एवं स्वास्थ्य (Safety Signs, Fire Extinguishers)', pages: '1-30', isSample: true },
      { chapterNumber: 2, title: 'विद्युत की मूलभूत अवधारणाएँ (Current, Voltage, Resistance, Ohm\'s Law)', pages: '31-75', isSample: true },
      { chapterNumber: 3, title: 'चुम्बकत्व एवं वैद्युतचुम्बकत्व (Magnetism & Electromagnetism)', pages: '76-120' },
      { chapterNumber: 4, title: 'प्रत्यावर्ती धारा (AC Theory, Single Phase & 3-Phase Systems)', pages: '121-175' },
      { chapterNumber: 5, title: 'DC जनरेटर एवं DC मोटर सिद्धांत एवं कार्यप्रणाली', pages: '176-240' },
      { chapterNumber: 6, title: 'ट्रांसफॉर्मर, अल्टरनेटर एवं 3-फेज इंडक्शन मोटर', pages: '241-315' },
      { chapterNumber: 7, title: 'अर्थिंग नियम एवं वायरिंग सिस्टम्स (IE Rules)', pages: '316-350' },
      { chapterNumber: 8, title: 'तकनीकी परीक्षा मॉडल प्रश्न पत्र (Solutions)', pages: '351-384' }
    ],
    sampleContent: {
      title: 'अध्याय 2: ओम का नियम एवं विद्युत सर्किट',
      chapterName: 'सैंपल: ओम का नियम एवं प्रतिरोधों का संयोजन',
      text: 'ओम के नियमानुसार, यदि किसी चालक की भौतिक अवस्थाएं (जैसे तापमान, दाब) स्थिर रहें, तो चालक के सिरों पर उत्पन्न विभवान्तर (V) उसमें प्रवाहित धारा (I) के समानुपाती होता है (V = I × R)। प्रतिरोधों के श्रेणी संयोजन में कुल प्रतिरोध R = R1 + R2 + R3 होता है और धारा समान रहती है। समानांतर संयोजन में कुल प्रतिरोध 1/R = 1/R1 + 1/R2 + 1/R3 होता है और वोल्टेज समान रहता है।',
      sampleQuestions: [
        {
          q: 'ओम का नियम किन परिस्थितियों में लागू होता है?',
          a: 'जब चालक का तापमान और भौतिक अवस्था स्थिर हो (At constant temperature)',
          explanation: 'तापमान बदलने पर चालक का प्रतिरोध बदल जाता है, इसलिए तापमान स्थिर होना अनिवार्य है।'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'ITI_Electrician_Trade_Theory_Nexa.pdf',
    lastUpdated: '16 March 2026',
    edition: '2026 Technical Edition',
    officialSourceUrl: 'https://dgt.gov.in'
  },
  {
    id: 'nx-mega-assam-police-combo',
    title: 'Assam Police Mega Success Combo (Constable + SI + Previous 10-Yr Papers)',
    subtitle: 'All-In-One 3 Books Bundle with Free Mock Test Series & Physical Guide',
    author: 'Nexa Assam Editorial Board',
    publisher: 'Nexa Assam Career Press',
    categoryId: 'assam-police',
    subCategory: 'Assam Police Constable',
    targetExam: 'Assam Police Constable & Sub-Inspector',
    language: 'Assamese',
    price: 249,
    originalPrice: 799,
    discountPercent: 69,
    isFree: false,
    isBestseller: true,
    isFeatured: true,
    isComboOffer: true,
    rating: 4.96,
    ratingCount: 3890,
    pageCount: 920,
    fileSize: '38.5 MB',
    format: 'PDF',
    coverGradient: 'from-[#064E3B] via-[#065F46] to-[#047857]',
    coverAccent: '#FBBF24',
    coverBadge: 'SUPER SAVER COMBO',
    description: 'Save 69% with this ultimate triple-pack for Assam Police aspirants. Combines the complete Sub-Inspector Cracker, the Constable UB/AB Guide, and the 10-Year Solved Question Papers in one unified digital library. Includes free offline reading and updates for the entire 2026 recruitment season.',
    features: [
      'Contains 3 Complete Bestselling Ebooks in 1 Bundle',
      'Over 900+ pages of high-yield exam preparation content',
      'Includes 10 Full-Length Mock Tests with Detailed Explanations',
      'Exclusive Physical Training, Running & Diet manual included'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'Book 1: Assam Police Sub-Inspector Full Guide (UB/AB)', pages: '1-390', isSample: true },
      { chapterNumber: 2, title: 'Book 2: Assam Police Constable 10-Year Solved Papers', pages: '391-710', isSample: true },
      { chapterNumber: 3, title: 'Book 3: Assam GK Special & Mental Ability Booster', pages: '711-860' },
      { chapterNumber: 4, title: 'Bonus: Physical Standard & Fitness Training Manual', pages: '861-920' }
    ],
    sampleContent: {
      title: 'Mega Combo Overview: Selection Strategy',
      chapterName: 'Sample: Roadmap to Clear Assam Police Written & Physical Test',
      text: 'To secure a top rank in Assam Police recruitment, candidates must balance daily physical conditioning (morning 5 AM running routine) with focused daily 4-hour study sessions. Assam GK accounts for nearly 35% of the total questions, followed by Logical Reasoning (25%) and General Mathematics (20%).',
      sampleQuestions: [
        {
          q: 'What is the minimum qualifying mark requirement in PET?',
          a: 'Candidates must achieve minimum qualifying threshold in running and long jump',
          explanation: 'Failing the minimum threshold results in immediate disqualification regardless of written test marks.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'Assam_Police_Mega_Combo_3in1.pdf',
    lastUpdated: '20 March 2026',
    edition: '2026 Mega Edition',
    officialSourceUrl: 'https://slprb.assam.gov.in'
  },
  {
    id: 'nx-free-monthly-current-affairs-mar-2026',
    title: 'Monthly Current Affairs Digest - March 2026 (National & Assam Special)',
    subtitle: 'Free Ebook: 500+ MCQs, Government Schemes, Appointments, Sports & Summits',
    author: 'Nexa Current Affairs Cell',
    publisher: 'Nexa Free Learning Series',
    categoryId: 'defence-tech',
    subCategory: 'Current Affairs',
    targetExam: 'All Competitive Exams 2026',
    language: 'English',
    price: 0,
    originalPrice: 99,
    discountPercent: 100,
    isFree: true,
    isFeatured: true,
    rating: 4.9,
    ratingCount: 3820,
    pageCount: 96,
    fileSize: '5.2 MB',
    format: 'PDF',
    coverGradient: 'from-[#1E3A8A] via-[#2563EB] to-[#1D4ED8]',
    coverAccent: '#FBBF24',
    coverBadge: '100% FREE EBOOK',
    description: 'Monthly Current Affairs compilation covering March 2026 events. Includes national and international news, Assam state cabinet decisions, environmental milestones in Northeast India, sports achievements, and 500 multiple-choice questions with answers.',
    features: [
      'Completely FREE - Instant download & offline reading',
      'Assam Cabinet Decisions & Northeast Special Roundup',
      'National News, Science & Tech, Defence Exercises',
      '500 Practice Questions with Detailed Notes'
    ],
    tableOfContents: [
      { chapterNumber: 1, title: 'National & Constitutional News March 2026', pages: '1-24', isSample: true },
      { chapterNumber: 2, title: 'Assam & Northeast India Current Events', pages: '25-45', isSample: true },
      { chapterNumber: 3, title: 'Economy, Banking, Indices & Reports', pages: '46-65', isSample: true },
      { chapterNumber: 4, title: 'Science, Space, Defence & Environment', pages: '66-80', isSample: true },
      { chapterNumber: 5, title: '500 Monthly Practice MCQs with Answers', pages: '81-96', isSample: true }
    ],
    sampleContent: {
      title: 'Chapter 2: Assam & Northeast Affairs',
      chapterName: 'Sample: Infrastructure & Heritage Milestone in Assam',
      text: 'During March 2026, the state government inaugurated multiple key connectivity links connecting North and South Guwahati across the Brahmaputra. The UNESCO World Heritage Committee formally commended Kaziranga National Park for continuing zero-poaching successes and expanding community-driven eco-tourism corridors.',
      sampleQuestions: [
        {
          q: 'Which wildlife sanctuary or national park in Assam recently celebrated sustained zero rhino poaching achievements?',
          a: 'Kaziranga National Park',
          explanation: 'Kaziranga National Park continues to record exceptional conservation milestones.'
        }
      ]
    },
    hasPdfUploaded: true,
    pdfFileName: 'Monthly_Current_Affairs_March_2026_Nexa.pdf',
    lastUpdated: '31 March 2026',
    edition: 'March 2026 Monthly Edition',
    officialSourceUrl: 'https://assam.gov.in'
  }
];

export const examUpdatesData: ExamUpdate[] = [
  {
    id: 'up-adre-2026-phase2',
    title: 'Assam Direct Recruitment (ADRE) Class III & IV - Exam Schedule & Syllabus Guidelines',
    examName: 'ADRE Grade III & IV (State Level Recruitment Commission)',
    organization: 'SLRC / Government of Assam',
    category: 'Assam Govt Jobs',
    notificationDate: '15 March 2026',
    lastDate: '30 April 2026',
    examDate: 'June - July 2026 (Tentative)',
    officialUrl: 'https://assam.gov.in',
    sourceNote: 'Directly sourced from State Level Recruitment Commission Official Gazette Notifications.',
    status: 'Notification Released',
    summary: 'The State Level Recruitment Commission for Class-III and Class-IV posts has announced key updates regarding examination centers across all district headquarters in Assam. Candidates are advised to review the official syllabus structure for general knowledge and regional heritage.',
    syllabusHighlights: [
      'Grade III: General Knowledge (focus on Assam History & Geography), General Mathematics, Mental Ability, English',
      'Grade IV: Elementary Level General Knowledge, Basic Mathematics, Logical Aptitude',
      'OMR-based offline multiple choice test with 0.50 negative marking'
    ],
    lastUpdated: '20 March 2026'
  },
  {
    id: 'up-slprb-assam-police-constable-si',
    title: 'SLPRB Assam Police - Sub-Inspector & Constable Physical Test (PET/PST) Guidelines',
    examName: 'SLPRB Assam Police Recruitment',
    organization: 'State Level Police Recruitment Board, Assam',
    category: 'Assam Police',
    notificationDate: '02 March 2026',
    lastDate: '25 April 2026',
    examDate: 'May - June 2026',
    officialUrl: 'https://slprb.assam.gov.in',
    sourceNote: 'Sourced from SLPRB official recruitment portal (slprb.assam.gov.in).',
    status: 'Admit Card Available',
    summary: 'SLPRB Assam has released the detailed standard operating procedures for Physical Efficiency Test (PET) and Physical Standard Test (PST) for Sub-Inspector and Constable recruitment. Digital RFID biometric tagging will be employed during the running test.',
    syllabusHighlights: [
      'Male Running: 3200m in max 14 minutes; Female Running: 1600m in max 8 minutes',
      'Long Jump: Minimum 335 cm for Male, 244 cm for Female',
      'Written test follows PET for qualified candidates with bilingual question papers'
    ],
    lastUpdated: '18 March 2026'
  },
  {
    id: 'up-rrb-ntpc-alp-2026',
    title: 'Railway Recruitment Boards (RRB) - Annual Exam Calendar & NTPC / ALP Stage 1 Updates',
    examName: 'RRB NTPC & Assistant Loco Pilot (CEN 2026)',
    organization: 'Railway Recruitment Control Board, Ministry of Railways',
    category: 'Railway',
    notificationDate: '10 February 2026',
    lastDate: 'Open as per CEN schedules',
    examDate: 'August - October 2026',
    officialUrl: 'https://rrbcdg.gov.in',
    sourceNote: 'Verified from RRB Chandigarh and Railway Recruitment Control Board official portals.',
    status: 'Exam Date Announced',
    summary: 'The Railway Recruitment Board confirms the schedule for Computer Based Test (CBT-1) across regional centers nationwide. Candidates must carry original photo ID and Aadhaar biometric verification will be mandatory at examination centers.',
    syllabusHighlights: [
      'Mathematics: 30 Questions (Arithmetic, Algebra, Geometry, Trigonometry)',
      'General Intelligence & Reasoning: 30 Questions',
      'General Awareness: 40 Questions (including Indian Railways History & Science)',
      'Total 100 Questions in 90 Minutes with 1/3rd Negative Marking'
    ],
    lastUpdated: '12 March 2026'
  },
  {
    id: 'up-ssc-cgl-2026',
    title: 'Staff Selection Commission (SSC) - Combined Graduate Level Exam (CGL) 2026 Notice',
    examName: 'SSC CGL Examination 2026',
    organization: 'Staff Selection Commission, Govt of India',
    category: 'SSC & Central Govt',
    notificationDate: '24 January 2026',
    lastDate: '31 March 2026',
    examDate: 'September 2026',
    officialUrl: 'https://ssc.gov.in',
    sourceNote: 'Published on the newly launched official SSC portal (ssc.gov.in).',
    status: 'Notification Released',
    summary: 'Staff Selection Commission has invited applications for Group B and Group C posts in central government ministries and departments. One-Time Registration (OTR) on ssc.gov.in is required before filling application forms.',
    syllabusHighlights: [
      'Tier-1: General Intelligence, General Awareness, Quantitative Aptitude, English Comprehension (25 questions each, 200 marks total)',
      'Tier-2: Mathematical Abilities, Reasoning, English, General Awareness, Computer Knowledge Module, and Data Entry Speed Test',
      'Negative marking: 0.50 per wrong question in Tier 1; 1 mark per wrong question in Tier 2'
    ],
    lastUpdated: '16 March 2026'
  }
];

export const currentAffairsData: CurrentAffairItem[] = [
  {
    id: 'ca-daily-1',
    title: 'Assam Cabinet clears comprehensive sports infrastructure package for all sub-divisions',
    date: '20 October 2026',
    monthYear: 'October 2026',
    category: 'Assam & NE',
    highlights: [
      'Establishment of mini-stadiums in 40 rural blocks across Assam',
      'Special scholarship program for athletes preparing for National Games',
      'Renovation of historical sporting complexes in Dibrugarh, Jorhat, and Silchar'
    ],
    isMonthlyPdf: false,
    pages: 4,
    fileSize: '650 KB',
    freeDownloadable: true
  },
  {
    id: 'ca-daily-2',
    title: 'Indian Railways tests indigenous Kavach 4.0 automatic train protection system on NFR route',
    date: '19 October 2026',
    monthYear: 'October 2026',
    category: 'National',
    highlights: [
      'First deployment of Kavach 4.0 over 500 km of Guwahati-New Jalpaiguri section',
      'Zero head-on collision safety guarantee via ultra-high frequency radio telemetry',
      'Developed by Research Designs and Standards Organisation (RDSO)'
    ],
    isMonthlyPdf: false,
    pages: 3,
    fileSize: '510 KB',
    freeDownloadable: true
  },
  {
    id: 'ca-daily-3',
    title: 'Reserve Bank of India maintains Repo Rate at 6.25% in bi-monthly monetary policy review',
    date: '17 October 2026',
    monthYear: 'October 2026',
    category: 'Economy',
    highlights: [
      'Retail inflation projected within comfortable tolerance band of 4 (+/-2)%',
      'GDP growth rate forecast for FY27 projected at 7.1%',
      'Expansion of UPI offline wallet limits for rural and low-connectivity zones'
    ],
    isMonthlyPdf: false,
    pages: 5,
    fileSize: '780 KB',
    freeDownloadable: true
  },
  {
    id: 'ca-monthly-mar-2026',
    title: 'Complete Monthly Current Affairs Compilation - March 2026 (Assam & All India)',
    date: '31 March 2026',
    monthYear: 'March 2026',
    category: 'National',
    highlights: [
      'Over 500 multiple-choice questions with detailed rationales',
      'Comprehensive table of all new appointments, honours, awards, and sports titles',
      'Exclusive Assam state schemes and regional environmental developments'
    ],
    isMonthlyPdf: true,
    pages: 96,
    fileSize: '5.2 MB',
    freeDownloadable: true
  },
  {
    id: 'ca-monthly-feb-2026',
    title: 'Monthly Current Affairs Digest - February 2026 (Union & State Budgets Special)',
    date: '28 February 2026',
    monthYear: 'February 2026',
    category: 'Economy',
    highlights: [
      'Union Budget 2026 highlights & Assam State Budget analysis',
      'Major science, defence, and space missions of ISRO and DRDO',
      '400 Practice MCQs for competitive examinations'
    ],
    isMonthlyPdf: true,
    pages: 88,
    fileSize: '4.9 MB',
    freeDownloadable: true
  }
];

export const mockTestData: MockTest = {
  id: 'mt-adre-police-quick-10',
  title: 'All-Assam & Central Exam Live Mini Mock Test 2026',
  exam: 'Target: ADRE 2.0 / Assam Police / Railway / SSC',
  durationMinutes: 10,
  totalQuestions: 10,
  marksPerQuestion: 2,
  negativeMark: 0.5,
  difficulty: 'Moderate',
  questions: [
    {
      id: 1,
      topic: 'Assam History',
      question: 'Who was the founder of the Ahom Kingdom in Assam who established his capital at Charaideo in 1253 CE?',
      options: ['Lachit Borphukan', 'Chaolung Sukaphaa', 'Rudra Singha', 'Gadadhar Singha'],
      correctAnswer: 1,
      explanation: 'Chaolung Sukaphaa crossed the Patkai hills in 1228 CE and established the Ahom Kingdom, choosing Charaideo as his first permanent capital in 1253 CE.'
    },
    {
      id: 2,
      topic: 'Assam Geography',
      question: 'Which of the following National Parks in Assam is world-renowned for housing the highest density of Royal Bengal Tigers?',
      options: ['Kaziranga National Park', 'Orang National Park', 'Manas National Park', 'Dibru-Saikhowa National Park'],
      correctAnswer: 1,
      explanation: 'Orang National Park, often called the mini Kaziranga, has the highest density of Royal Bengal Tigers in Assam and one of the highest in the world.'
    },
    {
      id: 3,
      topic: 'Indian Polity',
      question: 'Under which Article of the Constitution of India is the President of India empowered to grant pardons and reprieves?',
      options: ['Article 61', 'Article 72', 'Article 123', 'Article 143'],
      correctAnswer: 1,
      explanation: 'Article 72 of the Indian Constitution grants the President the power to pardon, commute, remit, or suspend sentences in certain cases.'
    },
    {
      id: 4,
      topic: 'Indian Railways',
      question: 'Where is the headquarters of Northeast Frontier Railway (NFR) situated?',
      options: ['Maligaon, Guwahati', 'Silchar', 'Tinsukia', 'Rangiya'],
      correctAnswer: 0,
      explanation: 'The Northeast Frontier Railway (NFR) is headquartered at Maligaon in Guwahati, Assam.'
    },
    {
      id: 5,
      topic: 'General Science',
      question: 'What is the SI unit of electric resistance?',
      options: ['Volt', 'Ampere', 'Ohm', 'Joule'],
      correctAnswer: 2,
      explanation: 'The SI unit of electrical resistance is the Ohm, symbolized by the Greek letter omega (Ω).'
    },
    {
      id: 6,
      topic: 'Assam Culture',
      question: 'Which great saint-scholar of Assam founded the Neo-Vaishnavite movement and introduced the Sattriya dance form?',
      options: ['Madhavdev', 'Srimanta Sankardev', 'Ananta Kandali', 'Bhattadeva'],
      correctAnswer: 1,
      explanation: 'Mahapurush Srimanta Sankardev was a 15th-16th century polymath, saint, playwright, and social reformer who propagated Ekasarana Dharma and founded the Sattriya dance tradition.'
    },
    {
      id: 7,
      topic: 'Quantitative Aptitude',
      question: 'If the selling price of an article is ₹240 with a profit of 20%, what was its cost price?',
      options: ['₹180', '₹200', '₹210', '₹220'],
      correctAnswer: 1,
      explanation: 'Cost Price = Selling Price / (1 + Profit%) = 240 / 1.20 = ₹200.'
    },
    {
      id: 8,
      topic: 'Logical Reasoning',
      question: 'Find the next number in the sequence: 4, 9, 16, 25, 36, ?',
      options: ['47', '49', '50', '64'],
      correctAnswer: 1,
      explanation: 'The series consists of consecutive perfect squares: 2^2=4, 3^2=9, 4^2=16, 5^2=25, 6^2=36, next is 7^2 = 49.'
    },
    {
      id: 9,
      topic: 'Indian Economy',
      question: 'Which statutory body is responsible for regulating securities markets in India?',
      options: ['RBI', 'SEBI', 'NABARD', 'IRDAI'],
      correctAnswer: 1,
      explanation: 'The Securities and Exchange Board of India (SEBI) regulates the securities and commodity market in India.'
    },
    {
      id: 10,
      topic: 'Current Affairs & Schemes',
      question: 'Which welfare scheme in Assam provides monthly financial support to girl students pursuing Higher Secondary and University degrees?',
      options: ['Orunodoi', 'Nijut Moina', 'Pragyan Bharati', 'Arogya Nidhi'],
      correctAnswer: 1,
      explanation: 'The "Nijut Moina" scheme was introduced to promote higher education among young women and eliminate child marriage through phased financial grants.'
    }
  ]
};

export const validCoupons: Coupon[] = [
  {
    code: 'NEXA20',
    discountType: 'percentage',
    discountValue: 20,
    minOrderValue: 100,
    description: 'Get flat 20% OFF on all exam preparation ebooks!',
    expiryDate: '31 Dec 2026'
  },
  {
    code: 'ASSAM100',
    discountType: 'fixed',
    discountValue: 100,
    minOrderValue: 249,
    description: 'Save ₹100 on orders above ₹249 (Great for combos & guides)',
    expiryDate: '31 Dec 2026'
  },
  {
    code: 'FIRSTEXAM',
    discountType: 'percentage',
    discountValue: 25,
    minOrderValue: 99,
    description: 'New Student Welcome Offer: 25% OFF on your first book',
    expiryDate: '31 Dec 2026'
  },
  {
    code: 'SUPERSTUDENT',
    discountType: 'fixed',
    discountValue: 50,
    minOrderValue: 149,
    description: 'Instant ₹50 discount for dedicated exam preparation',
    expiryDate: '31 Dec 2026'
  }
];
