import { Product, Order, WholesalerInventoryItem, DriverTrip, PlatformCommissionConfig, SettlementRecord, ComplaintRecord, AppNotification, UserProfile } from '../types';

export const initialCurrentUser: UserProfile = {
  id: 'usr_cust_001',
  name: 'Subhash Sen (Sen Builders & Developers)',
  mobile: '+91 98301 44521',
  email: 'psen63334@gmail.com',
  address: 'Plot 42, Anandapur Main Road, Near Ruby Hospital, Kolkata',
  pinCode: '700107',
  role: 'customer',
  verified: true,
  kycStatus: 'verified',
  gpsPermissionGranted: true,
  businessName: 'Sen Real Estates Pvt Ltd',
  gstNumber: '19AAACS8921P1Z9',
  panNumber: 'AAACS8921P'
};

export const initialProducts: Product[] = [
  {
    id: 'prod_101',
    name: 'Maa Tara Super 1st Class Red Clay Wirecut Brick',
    brickType: '1st Class Brick',
    size: '9" x 4.25" x 2.75" (Standard KFB)',
    quality: 'Class 1 Heavy Load',
    pricePerThousand: 9400,
    availableStockThousand: 145, // 145,000 bricks
    minOrderThousand: 3,
    photos: [
      'https://images.unsplash.com/photo-1590069261209-f8e9b8642343?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=800&q=80'
    ],
    manufacturerId: 'mfg_01',
    manufacturerName: 'Maa Tara Brick Kiln (BFB Bhatta)',
    dealerId: 'wh_01',
    dealerName: 'Ghosh Imarati Bhandar',
    rating: 4.8,
    reviewCount: 94,
    deliveryChargePerKm: 32,
    deliveryAreaRadiusKm: 65,
    gstPercent: 5,
    description: 'High compressive strength (>10.5 N/mm²), uniform cherry red color, sharp edges, metallic ringing sound upon impact, zero efflorescence. Ideal for load-bearing multi-storey masonry.',
    isApproved: true,
    isActive: true
  },
  {
    id: 'prod_102',
    name: 'Burdwan Kiln 2nd Class Standard Red Brick',
    brickType: '2nd Class Brick',
    size: '9" x 4.25" x 2.75"',
    quality: 'Class 2 Standard',
    pricePerThousand: 7600,
    availableStockThousand: 90,
    minOrderThousand: 3,
    photos: [
      'https://images.unsplash.com/photo-1541888946425-d0fbb186c5f7?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1584463699028-eb6e5ea77cfd?auto=format&fit=crop&w=800&q=80'
    ],
    manufacturerId: 'mfg_02',
    manufacturerName: 'Bengal Red Clay Industries',
    dealerId: 'wh_01',
    dealerName: 'Ghosh Imarati Bhandar',
    rating: 4.4,
    reviewCount: 52,
    deliveryChargePerKm: 28,
    deliveryAreaRadiusKm: 50,
    gstPercent: 5,
    description: 'Slightly irregular shape, well-burnt, suitable for boundary walls, partition walls, and secondary plaster-covered structures.',
    isApproved: true,
    isActive: true
  },
  {
    id: 'prod_103',
    name: 'EcoGreen Steam Cured High Strength Fly Ash Brick',
    brickType: 'Fly Ash Brick',
    size: '230 x 110 x 75 mm (IS 12894 Certified)',
    quality: 'Eco Green Grade A',
    pricePerThousand: 6100,
    availableStockThousand: 280,
    minOrderThousand: 4,
    photos: [
      'https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800&q=80'
    ],
    manufacturerId: 'mfg_03',
    manufacturerName: 'Royal Fly-Ash & Green Bricks Ltd',
    dealerId: 'wh_02',
    dealerName: 'Shree Ram Construction Supplies',
    rating: 4.9,
    reviewCount: 146,
    deliveryChargePerKm: 30,
    deliveryAreaRadiusKm: 80,
    gstPercent: 5,
    description: 'Precision molded with fly ash, cement, and lime. Exceptional compressive strength (>9 N/mm²), 20% lower mortar consumption, thermal insulation, and eco-friendly.',
    isApproved: true,
    isActive: true
  },
  {
    id: 'prod_104',
    name: 'UltraLite Autoclaved Aerated Concrete (AAC) Blocks',
    brickType: 'Concrete Block',
    size: '600 x 200 x 150 mm (Per 100 Blocks bundle)',
    quality: 'High Strength AAC',
    pricePerThousand: 48000, // For 1000 blocks equivalent
    availableStockThousand: 40,
    minOrderThousand: 1,
    photos: [
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=800&q=80'
    ],
    manufacturerId: 'mfg_04',
    manufacturerName: 'Ganga Valley Concrete Blocks',
    dealerId: 'wh_02',
    dealerName: 'Shree Ram Construction Supplies',
    rating: 4.7,
    reviewCount: 88,
    deliveryChargePerKm: 35,
    deliveryAreaRadiusKm: 90,
    gstPercent: 12,
    description: '3x lighter than clay bricks. Earthquake resistant, fire-rated 4 hours, supreme sound insulation. Drastically reduces structural steel load.',
    isApproved: true,
    isActive: true
  },
  {
    id: 'prod_105',
    name: 'Riverbed Coarse Sand (Baloo) & Stone Aggregates',
    brickType: 'Building Materials',
    size: '100 Cu. Ft (1 Brass) Bulk Delivery',
    quality: 'Class 1 Heavy Load',
    pricePerThousand: 6500, // Unit price
    availableStockThousand: 500,
    minOrderThousand: 2,
    photos: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80'
    ],
    manufacturerId: 'mfg_01',
    manufacturerName: 'Maa Tara Mining & Materials',
    dealerId: 'wh_01',
    dealerName: 'Ghosh Imarati Bhandar',
    rating: 4.6,
    reviewCount: 40,
    deliveryChargePerKm: 30,
    deliveryAreaRadiusKm: 45,
    gstPercent: 5,
    description: 'Washed Damodar riverbed sand, graded silt-free sand and 20mm blue metal stone chips for concrete casting.',
    isApproved: true,
    isActive: true
  },
  {
    id: 'prod_106',
    name: 'Heavy Duty 10-Wheeler Brick Haulage Service',
    brickType: 'Transport',
    size: 'Capacity: Up to 6,000 Bricks / 22 Metric Tons',
    quality: 'Class 1 Heavy Load',
    pricePerThousand: 1800, // Base freight per 1000 bricks for 20km
    availableStockThousand: 100,
    minOrderThousand: 3,
    photos: [
      'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=800&q=80'
    ],
    manufacturerId: 'mfg_02',
    manufacturerName: 'M/S Durgapur Transport Logistics',
    rating: 4.9,
    reviewCount: 110,
    deliveryChargePerKm: 40,
    deliveryAreaRadiusKm: 150,
    gstPercent: 5,
    description: 'Hydraulic tipper dumper & flatbed carriers equipped with GPS real-time telemetry and trained unloading helpers.',
    isApproved: true,
    isActive: true
  }
];

export const initialOrders: Order[] = [
  {
    id: 'BRK-ORD-88219',
    customerId: 'usr_cust_001',
    customerName: 'Subhash Sen',
    customerMobile: '+91 98301 44521',
    deliveryAddress: 'Project Site B, Anandapur Main Road, Sector 3, Kolkata',
    deliveryPinCode: '700107',
    deliveryDate: '2026-09-22',
    items: [
      {
        productId: 'prod_101',
        productName: 'Maa Tara Super 1st Class Red Clay Wirecut Brick',
        brickType: '1st Class Brick',
        quantityThousand: 5, // 5,000 bricks
        unitPrice: 9400,
        totalProductPrice: 47000
      }
    ],
    productTotal: 47000,
    transportCharge: 3800,
    discount: 1000,
    gstAmount: 2350,
    totalAmount: 52150,
    paymentMethod: 'UPI',
    paymentStatus: 'Paid',
    orderStatus: 'Out for Delivery',
    manufacturerId: 'mfg_01',
    manufacturerName: 'Maa Tara Brick Kiln (BFB Bhatta)',
    vehicleType: '10-Wheeler Heavy Truck',
    vehicleNumber: 'WB 39 B 4812',
    driverId: 'drv_01',
    driverName: 'Ramen Das (Bholanath Roadways)',
    driverMobile: '+91 98312 90123',
    deliveryOtp: '741852',
    liveTracking: {
      driverLat: 22.5204,
      driverLng: 88.3986,
      currentSpeedKmH: 38,
      etaMinutes: 24,
      distanceRemainingKm: 11.4,
      currentStage: 'Crossing Basanti Highway towards Ruby Junction'
    },
    loadingPhoto: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=400&q=80',
    createdAt: '2026-09-20 09:15 AM',
    notes: 'Please ensure side-unloading near tower 2 foundation.'
  },
  {
    id: 'BRK-ORD-88194',
    customerId: 'usr_cust_001',
    customerName: 'Subhash Sen',
    customerMobile: '+91 98301 44521',
    deliveryAddress: 'Villa 14, Rajarhat Action Area 2, Newtown, Kolkata',
    deliveryPinCode: '700135',
    deliveryDate: '2026-09-18',
    items: [
      {
        productId: 'prod_103',
        productName: 'EcoGreen Steam Cured High Strength Fly Ash Brick',
        brickType: 'Fly Ash Brick',
        quantityThousand: 8,
        unitPrice: 6100,
        totalProductPrice: 48800
      }
    ],
    productTotal: 48800,
    transportCharge: 4200,
    discount: 1500,
    gstAmount: 2440,
    totalAmount: 53940,
    paymentMethod: 'Net Banking',
    paymentStatus: 'Paid',
    orderStatus: 'Delivered',
    manufacturerId: 'mfg_03',
    manufacturerName: 'Royal Fly-Ash & Green Bricks Ltd',
    vehicleType: '6-Wheeler Dumper',
    vehicleNumber: 'WB 25 D 7719',
    driverId: 'drv_02',
    driverName: 'Anwar Hossain',
    driverMobile: '+91 97488 12390',
    deliveryOtp: '519284',
    customerSignature: 'Subhash Sen (Verified on site)',
    loadingPhoto: 'https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?auto=format&fit=crop&w=400&q=80',
    deliveryPhoto: 'https://images.unsplash.com/photo-1590069261209-f8e9b8642343?auto=format&fit=crop&w=400&q=80',
    createdAt: '2026-09-18 08:30 AM'
  },
  {
    id: 'BRK-ORD-88230',
    customerId: 'usr_cust_002',
    customerName: 'Prabir Chatterjee',
    customerMobile: '+91 94330 88219',
    deliveryAddress: 'Howrah Amta Road, Domjur Yard',
    deliveryPinCode: '711405',
    deliveryDate: '2026-09-23',
    items: [
      {
        productId: 'prod_102',
        productName: 'Burdwan Kiln 2nd Class Standard Red Brick',
        brickType: '2nd Class Brick',
        quantityThousand: 6,
        unitPrice: 7600,
        totalProductPrice: 45600
      }
    ],
    productTotal: 45600,
    transportCharge: 3600,
    discount: 500,
    gstAmount: 2280,
    totalAmount: 50980,
    paymentMethod: 'UPI',
    paymentStatus: 'Paid',
    orderStatus: 'Manufacturer Preparing',
    manufacturerId: 'mfg_01',
    manufacturerName: 'Maa Tara Brick Kiln (BFB Bhatta)',
    vehicleType: '10-Wheeler Heavy Truck',
    deliveryOtp: '892014',
    createdAt: '2026-09-20 11:40 AM'
  }
];

export const initialWholesaleInventory: WholesalerInventoryItem[] = [
  {
    id: 'wh_inv_01',
    productId: 'prod_101',
    name: '1st Class Red Clay Wirecut Brick',
    category: '1st Class Brick',
    openingStockThousand: 120,
    purchasedThousand: 60,
    soldThousand: 75,
    currentStockThousand: 105,
    purchasePricePerThousand: 8800,
    sellingPricePerThousand: 9400,
    lowStockThresholdThousand: 30
  },
  {
    id: 'wh_inv_02',
    productId: 'prod_102',
    name: '2nd Class Kiln Red Brick',
    category: '2nd Class Brick',
    openingStockThousand: 80,
    purchasedThousand: 40,
    soldThousand: 50,
    currentStockThousand: 70,
    purchasePricePerThousand: 7100,
    sellingPricePerThousand: 7600,
    lowStockThresholdThousand: 25
  },
  {
    id: 'wh_inv_03',
    productId: 'prod_103',
    name: 'EcoGreen Fly Ash Brick (Class A)',
    category: 'Fly Ash Brick',
    openingStockThousand: 150,
    purchasedThousand: 100,
    soldThousand: 110,
    currentStockThousand: 140,
    purchasePricePerThousand: 5400,
    sellingPricePerThousand: 6100,
    lowStockThresholdThousand: 40
  },
  {
    id: 'wh_inv_04',
    productId: 'prod_104',
    name: 'AAC Lightweight Concrete Blocks',
    category: 'Concrete Block',
    openingStockThousand: 30,
    purchasedThousand: 20,
    soldThousand: 22,
    currentStockThousand: 28,
    purchasePricePerThousand: 44000,
    sellingPricePerThousand: 48000,
    lowStockThresholdThousand: 10
  }
];

export const initialDriverTrips: DriverTrip[] = [
  {
    id: 'TRIP-7021',
    orderId: 'BRK-ORD-88219',
    pickupAddress: 'Maa Tara Bhatta, Ghatakpukur Kiln Belt, South 24 Parganas',
    destinationAddress: 'Project Site B, Anandapur Main Road, Sector 3, Kolkata',
    brickQuantityThousand: 5,
    vehicleType: '10-Wheeler Heavy Truck',
    estimatedDistanceKm: 28.5,
    transportCharge: 3800,
    driverEarnings: 3420,
    status: 'in_transit',
    vehicleNumber: 'WB 39 B 4812',
    customerName: 'Subhash Sen',
    customerMobile: '+91 98301 44521',
    manufacturerName: 'Maa Tara Brick Kiln (BFB Bhatta)',
    date: '2026-09-20'
  },
  {
    id: 'TRIP-7022',
    orderId: 'BRK-ORD-88230',
    pickupAddress: 'Maa Tara Bhatta, Ghatakpukur Kiln Belt, South 24 Parganas',
    destinationAddress: 'Howrah Amta Road, Domjur Yard',
    brickQuantityThousand: 6,
    vehicleType: '10-Wheeler Heavy Truck',
    estimatedDistanceKm: 34.0,
    transportCharge: 4400,
    driverEarnings: 3960,
    status: 'requested',
    vehicleNumber: 'WB 39 B 4812',
    customerName: 'Prabir Chatterjee',
    customerMobile: '+91 94330 88219',
    manufacturerName: 'Maa Tara Brick Kiln (BFB Bhatta)',
    date: '2026-09-20'
  },
  {
    id: 'TRIP-6998',
    orderId: 'BRK-ORD-88194',
    pickupAddress: 'Royal Fly Ash Works, Uluberia Industrial Corridor',
    destinationAddress: 'Villa 14, Rajarhat Action Area 2, Newtown, Kolkata',
    brickQuantityThousand: 8,
    vehicleType: '6-Wheeler Dumper',
    estimatedDistanceKm: 42.0,
    transportCharge: 4200,
    driverEarnings: 3780,
    status: 'delivered',
    vehicleNumber: 'WB 25 D 7719',
    customerName: 'Subhash Sen',
    customerMobile: '+91 98301 44521',
    manufacturerName: 'Royal Fly-Ash & Green Bricks Ltd',
    date: '2026-09-18'
  }
];

export const initialCommissionConfig: PlatformCommissionConfig = {
  manufacturerCommissionPercent: 3.5, // 3.5% on brick sale
  dealerCommissionPercent: 2.0,       // 2.0% on wholesale
  transportCommissionPercent: 5.0,    // 5.0% on transport
  paymentGatewayFeePercent: 1.8,     // 1.8% PG fee
  gstPercent: 5.0                     // 5.0% GST
};

export const initialSettlements: SettlementRecord[] = [
  {
    id: 'SETTL-901',
    orderId: 'BRK-ORD-88194',
    beneficiaryType: 'Manufacturer',
    beneficiaryName: 'Royal Fly-Ash & Green Bricks Ltd',
    grossAmount: 48800,
    platformCommission: 1708,
    transportFee: 4200,
    netPayable: 47092,
    status: 'Paid',
    paymentRef: 'NEFT/HDFC/202609188921',
    date: '2026-09-19'
  },
  {
    id: 'SETTL-902',
    orderId: 'BRK-ORD-88194',
    beneficiaryType: 'Transporter',
    beneficiaryName: 'Anwar Hossain (WB 25 D 7719)',
    grossAmount: 4200,
    platformCommission: 210,
    transportFee: 0,
    netPayable: 3990,
    status: 'Paid',
    paymentRef: 'UPI/ICICI/992140',
    date: '2026-09-19'
  },
  {
    id: 'SETTL-903',
    orderId: 'BRK-ORD-88219',
    beneficiaryType: 'Manufacturer',
    beneficiaryName: 'Maa Tara Brick Kiln (BFB Bhatta)',
    grossAmount: 47000,
    platformCommission: 1645,
    transportFee: 3800,
    netPayable: 45355,
    status: 'Processing',
    date: '2026-09-20'
  },
  {
    id: 'SETTL-904',
    orderId: 'BRK-ORD-88219',
    beneficiaryType: 'Transporter',
    beneficiaryName: 'Ramen Das (WB 39 B 4812)',
    grossAmount: 3800,
    platformCommission: 190,
    transportFee: 0,
    netPayable: 3610,
    status: 'Pending',
    date: '2026-09-20'
  }
];

export const initialComplaints: ComplaintRecord[] = [
  {
    id: 'CMP-401',
    orderId: 'BRK-ORD-88194',
    raisedByName: 'Subhash Sen',
    raisedByRole: 'customer',
    category: 'Damaged bricks',
    description: 'During hydraulic unloading, approximately 180 fly-ash bricks fractured at corner edges due to rapid tilt. Requesting refund/credit.',
    status: 'Resolved',
    createdAt: '2026-09-18 04:30 PM',
    assignedStaff: 'Manager Animesh Roy',
    resolutionNotes: 'Credited ₹1,098 to Customer Wallet as compensation for 180 fractured bricks. Transporter cautioned.'
  },
  {
    id: 'CMP-402',
    orderId: 'BRK-ORD-88219',
    raisedByName: 'Subhash Sen',
    raisedByRole: 'customer',
    category: 'Late delivery',
    description: 'Vehicle delayed due to toll congestion on highway. Requested ETA update.',
    status: 'Investigation',
    createdAt: '2026-09-20 01:10 PM',
    assignedStaff: 'Staff Bikram Mitra',
    resolutionNotes: 'Driver contacted; GPS verified 24 min ETA.'
  }
];

export const initialNotifications: AppNotification[] = [
  {
    id: 'notif_1',
    recipientRole: 'customer',
    title: 'Truck is Out for Delivery! 🚚',
    message: 'Your order BRK-ORD-88219 (5,000 Bricks) is now en route with Driver Ramen Das (WB 39 B 4812). ETA: 24 mins.',
    type: 'transport',
    timestamp: '20 mins ago',
    read: false,
    orderId: 'BRK-ORD-88219'
  },
  {
    id: 'notif_2',
    recipientRole: 'manufacturer',
    title: 'New Order Received: ₹50,980',
    message: 'Customer Prabir Chatterjee placed order BRK-ORD-88230 for 6,000 standard kiln bricks.',
    type: 'order',
    timestamp: '1 hour ago',
    read: false,
    orderId: 'BRK-ORD-88230'
  },
  {
    id: 'notif_3',
    recipientRole: 'driver',
    title: 'New Trip Available Near Ghatakpukur',
    message: 'Trip TRIP-7022 to Howrah Domjur (6,000 Bricks). Payout: ₹3,960. Tap to review & accept.',
    type: 'transport',
    timestamp: '45 mins ago',
    read: false
  },
  {
    id: 'notif_4',
    recipientRole: 'all',
    title: 'Market Update: Monsoon Kiln Production',
    message: 'Brick prices revised +2.5% across Bengal & Bihar corridors due to post-monsoon firing. Check today’s spot rates.',
    type: 'system',
    timestamp: 'Yesterday',
    read: true
  }
];
