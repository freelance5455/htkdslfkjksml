import { Client, Project, Task, ProgressUpdate, ConversationMessage, ProjectDocument, AppNotification, ActivityLog, User, Employee, PluginSettings } from '../types';
import { createSynthesizedVoiceNote } from '../utils/audioHelper';

export const INITIAL_SETTINGS: PluginSettings = {
  zohoUrl: 'https://www.zoho.com/crm/'
};

export const INITIAL_EMPLOYEES: Employee[] = [
  {
    id: 'emp-1',
    employeeCode: 'PFS-0001',
    employeeName: 'Senthil Nathan',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    aadhaarNumber: '7829-4102-9912',
    panNumber: 'ABCPS4102K',
    phone: '+91 94443 81920',
    alternatePhone: '+91 94440 12399',
    email: 'senthil.n@phoenixfiresafety.in',
    designation: 'Senior Project Engineer (Fire Protection)',
    department: 'Fire Protection Engineering',
    joiningDate: '2022-03-15',
    bloodGroup: 'O+',
    dateOfBirth: '1988-06-22',
    address: 'No. 14, 2nd Main Road, Anna Nagar West, Chennai, Tamil Nadu 600040',
    emergencyContactName: 'Meenakshi Nathan (Spouse)',
    emergencyContactPhone: '+91 94442 88102',
    status: 'Active',
    createdAt: '2022-03-15'
  },
  {
    id: 'emp-2',
    employeeCode: 'PFS-0002',
    employeeName: 'Priya Balan',
    photo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80',
    aadhaarNumber: '6610-8819-2391',
    panNumber: 'BKPBL2391M',
    phone: '+91 98842 19283',
    alternatePhone: '+91 98840 99110',
    email: 'priya.b@phoenixfiresafety.in',
    designation: 'Lead MEP & Fire CAD Designer',
    department: 'Design & Drafting',
    joiningDate: '2023-01-10',
    bloodGroup: 'B+',
    dateOfBirth: '1992-11-14',
    address: 'Flat 3B, Shanthi Apartments, T. Nagar, Chennai, Tamil Nadu 600017',
    emergencyContactName: 'R. Balan (Father)',
    emergencyContactPhone: '+91 98841 00291',
    status: 'Active',
    createdAt: '2023-01-10'
  },
  {
    id: 'emp-3',
    employeeCode: 'PFS-0003',
    employeeName: 'Murugan K.',
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    aadhaarNumber: '9102-3341-8820',
    panNumber: 'CPMKR8820F',
    phone: '+91 97909 33211',
    alternatePhone: '+91 97900 44100',
    email: 'murugan.k@phoenixfiresafety.in',
    designation: 'Site Commissioning Supervisor',
    department: 'Field Installation & Testing',
    joiningDate: '2021-08-01',
    bloodGroup: 'A+',
    dateOfBirth: '1985-04-18',
    address: 'Plot 42, SIDCO Nagar, Villivakkam, Chennai, Tamil Nadu 600049',
    emergencyContactName: 'Lakshmi Murugan (Spouse)',
    emergencyContactPhone: '+91 97908 11922',
    status: 'Active',
    createdAt: '2021-08-01'
  },
  {
    id: 'emp-4',
    employeeCode: 'PFS-0004',
    employeeName: 'Kavitha Sundaram',
    photo: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&q=80',
    aadhaarNumber: '4491-0283-7719',
    panNumber: 'DFPKS7719Q',
    phone: '+91 98409 66120',
    alternatePhone: '+91 98400 33819',
    email: 'kavitha.s@phoenixfiresafety.in',
    designation: 'Compliance & Audit Manager',
    department: 'Statutory TNFRS Approvals',
    joiningDate: '2023-06-01',
    bloodGroup: 'AB+',
    dateOfBirth: '1990-09-05',
    address: 'No. 8, Gandhi Road, Alwarpet, Chennai, Tamil Nadu 600018',
    emergencyContactName: 'K. Sundaram (Spouse)',
    emergencyContactPhone: '+91 98408 22109',
    status: 'Active',
    createdAt: '2023-06-01'
  }
];

export const INITIAL_USERS: User[] = [
  {
    id: 'user-admin-1',
    name: 'Rajesh Kumar',
    email: 'rajesh.kumar@phoenixfiresafety.in',
    role: 'Admin',
    designation: 'Managing Director & Chief Safety Auditor',
    phone: '+91 98401 22841'
  },
  {
    id: 'user-emp-1',
    name: 'Senthil Nathan',
    email: 'senthil.n@phoenixfiresafety.in',
    role: 'Employee',
    designation: 'Senior Project Engineer (Fire Protection)',
    employeeId: 'emp-1',
    phone: '+91 94443 81920'
  },
  {
    id: 'user-emp-2',
    name: 'Priya Balan',
    email: 'priya.b@phoenixfiresafety.in',
    role: 'Employee',
    designation: 'Lead MEP & Fire CAD Designer',
    employeeId: 'emp-2',
    phone: '+91 98842 19283'
  },
  {
    id: 'user-emp-3',
    name: 'Murugan K.',
    email: 'murugan.k@phoenixfiresafety.in',
    role: 'Employee',
    designation: 'Site Commissioning Supervisor',
    employeeId: 'emp-3',
    phone: '+91 97909 33211'
  },
  {
    id: 'user-client-1',
    name: 'R. Sundararajan',
    email: 'sundararajan.r@apollohospitals.com',
    role: 'Client',
    designation: 'Chief Facilities & Biomedical Officer',
    clientId: 'client-apollo',
    phone: '+91 98410 77123'
  },
  {
    id: 'user-client-2',
    name: 'Ananya Roy',
    email: 'ananya.roy@hyundai-india.com',
    role: 'Client',
    designation: 'EHS & Plant Safety Head',
    clientId: 'client-hyundai',
    phone: '+91 99620 54321'
  },
  {
    id: 'user-client-3',
    name: 'Karthik V.',
    email: 'karthik.v@olympiagroup.in',
    role: 'Client',
    designation: 'Infrastructure Director',
    clientId: 'client-olympia',
    phone: '+91 98408 90112'
  }
];

export const INITIAL_CLIENTS: Client[] = [
  {
    id: 'client-apollo',
    companyName: 'Apollo Hospitals Enterprise Ltd.',
    contactPerson: 'R. Sundararajan',
    email: 'sundararajan.r@apollohospitals.com',
    phone: '+91 98410 77123',
    username: 'sundararajan.r',
    password: 'password123',
    status: 'Active',
    address: 'No. 21, Greams Lane, Off Greams Road, Thousand Lights',
    city: 'Chennai, Tamil Nadu 600006',
    gstin: '33AABCA1294F1Z8',
    industry: 'Healthcare & Multispeciality Hospitals',
    zohoContactId: 'ZC-8819234',
    zohoData: {
      'Company Name': 'Apollo Hospitals Enterprise Ltd.',
      'Contact Name': 'R. Sundararajan',
      'Currency': 'INR',
      'Payment Terms': 'Due on Receipt'
    },
    createdAt: '2025-04-12',
    notes: 'Key hospital campus requiring zero downtime during alarm panel switchover.'
  },
  {
    id: 'client-hyundai',
    companyName: 'Hyundai Motor India Ltd.',
    contactPerson: 'Ananya Roy',
    email: 'ananya.roy@hyundai-india.com',
    phone: '+91 99620 54321',
    username: 'ananya.roy',
    password: 'password123',
    status: 'Active',
    address: 'Plot No. H-1, SIPCOT Industrial Park, Irungattukottai',
    city: 'Sriperumbudur, Tamil Nadu 602117',
    gstin: '33AAACH2391Q1ZP',
    industry: 'Automobile Manufacturing & Assembly',
    zohoContactId: 'ZC-9120441',
    zohoData: {
      'Company Name': 'Hyundai Motor India Ltd.',
      'Contact Name': 'Ananya Roy',
      'Currency': 'INR'
    },
    createdAt: '2025-06-18',
    notes: 'Industrial paint shop and battery storage protection standards required.'
  },
  {
    id: 'client-olympia',
    companyName: 'Olympia Tech Park (Guindy)',
    contactPerson: 'Karthik V.',
    email: 'karthik.v@olympiagroup.in',
    phone: '+91 98408 90112',
    username: 'karthik.v',
    password: 'password123',
    status: 'Active',
    address: 'SIDCO Industrial Estate, Guindy',
    city: 'Chennai, Tamil Nadu 600032',
    gstin: '33AAAFO9182L1ZX',
    industry: 'Commercial IT Park & Data Centers',
    zohoContactId: 'ZC-7731802',
    createdAt: '2025-08-04',
    notes: 'Novec 1230 gas suppression for Tier-3 data center floors.'
  },
  {
    id: 'client-express',
    companyName: 'Express Avenue Commercial Complex',
    contactPerson: 'Deepak Mehrotra',
    email: 'deepak.m@expressavenue.in',
    phone: '+91 98402 11990',
    username: 'deepak.m',
    password: 'password123',
    status: 'Active',
    address: 'Club House Road, Royapettah',
    city: 'Chennai, Tamil Nadu 600002',
    gstin: '33AACCE4482B1ZM',
    industry: 'Retail Mall & Multiplex',
    zohoContactId: 'ZC-6019488',
    createdAt: '2025-09-15',
    notes: 'Annual AMC and Form B NOC renewal with Chennai Regional Fire Office.'
  },
  {
    id: 'client-mmm',
    companyName: 'Madras Medical Mission (MMM Hospital)',
    contactPerson: 'Dr. Joseph Thomas',
    email: 'facilities@mmmhospital.org',
    phone: '+91 94441 55678',
    username: 'facilities.mmm',
    password: 'password123',
    status: 'Active',
    address: '4-A, Dr J.J. Nagar, Mogappair',
    city: 'Chennai, Tamil Nadu 600037',
    gstin: '33AAATM5591C1ZT',
    industry: 'Cardiac & Speciality Hospital',
    zohoContactId: 'ZC-5519201',
    createdAt: '2025-11-20',
    notes: 'ICU and Cath Lab pre-action sprinkler systems.'
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'proj-1',
    reference: 'PHX-2026-081',
    name: 'Emergency Fire Alarm & Voice Evacuation System Upgrade',
    clientId: 'client-apollo',
    clientCompanyName: 'Apollo Hospitals Enterprise Ltd.',
    description: 'Complete replacement of legacy smoke detectors with addressable optical sensors, dual optical/heat multisensors in critical care units, and multi-zone voice evacuation panels connected to Tamil Nadu Fire Services repeater.',
    category: 'Fire Alarm System',
    startDate: '2026-01-10',
    expectedCompletionDate: '2026-11-25',
    assignedEmployeeIds: ['emp-1', 'emp-2'],
    priority: 'Critical',
    status: 'In Progress',
    progressPercentage: 75,
    isManualProgress: false,
    contractValueINR: 2450000,
    siteLocation: 'Main Hospital Block, Greams Road, Chennai',
    createdAt: '2026-01-05',
    milestones: [
      { id: 'm1-1', title: 'Site Inspection & CAD Rerouting Drawing', description: 'Survey of 8 floors and cable duct pathways', completed: true, dueDate: '2026-01-28', completedDate: '2026-01-25' },
      { id: 'm1-2', title: 'Material Dispatch & Sensor Delivery', description: '340 addressable smoke detectors & sounders', completed: true, dueDate: '2026-02-20', completedDate: '2026-02-18' },
      { id: 'm1-3', title: 'Zone 1-4 Cable Conduit & Erection', description: 'OPD, ICU, and surgical wards cabling', completed: true, dueDate: '2026-05-15', completedDate: '2026-05-12' },
      { id: 'm1-4', title: 'Main Control Panel Integration & Testing', description: 'Central command console in Security BMS room', completed: false, dueDate: '2026-10-30' },
      { id: 'm1-5', title: 'TNFRS Final Inspection & Handover', description: 'Statutory compliance demonstration with Fire Officer', completed: false, dueDate: '2026-11-25' }
    ]
  },
  {
    id: 'proj-2',
    reference: 'PHX-2026-089',
    name: 'High-Pressure Sprinkler & Hydrant Network Expansion',
    clientId: 'client-hyundai',
    clientCompanyName: 'Hyundai Motor India Ltd.',
    description: 'Turnkey hydraulic calculation, ring main piping (150mm MS class C), deluge sprinkler installation in assembly bay 4, and high-velocity water spray system for transformer yard.',
    category: 'Hydrant & Sprinkler',
    startDate: '2026-02-01',
    expectedCompletionDate: '2026-12-15',
    assignedEmployeeIds: ['emp-1', 'emp-3'],
    priority: 'High',
    status: 'In Progress',
    progressPercentage: 45,
    isManualProgress: false,
    contractValueINR: 5800000,
    siteLocation: 'Assembly Plant Unit 2, Irungattukottai, Sriperumbudur',
    createdAt: '2026-01-20',
    milestones: [
      { id: 'm2-1', title: 'Hydraulic Calculations & NFPA 13 Review', description: 'Design signoff with Hyundai Korean Engineering Team', completed: true, dueDate: '2026-02-28', completedDate: '2026-02-27' },
      { id: 'm2-2', title: 'Main Yard Ring Pipeline Laying', description: 'Trenching, pipe wrapping, and underground laying', completed: true, dueDate: '2026-06-15', completedDate: '2026-06-10' },
      { id: 'm2-3', title: 'Deluge Valve & Overhead Sprinkler Droppers', description: 'Fitting 850 quick-response pendant sprinklers', completed: false, dueDate: '2026-11-10' },
      { id: 'm2-4', title: 'Hydrostatic Pressure Test (14 Bar)', description: '4-hour hold test with independent auditor', completed: false, dueDate: '2026-11-30' },
      { id: 'm2-5', title: 'Commissioning & Safety Cert handover', description: 'Final commissioning and pump house automation', completed: false, dueDate: '2026-12-15' }
    ]
  },
  {
    id: 'proj-3',
    reference: 'PHX-2026-077',
    name: 'Clean Agent Novec 1230 Server Room Suppression',
    clientId: 'client-olympia',
    clientCompanyName: 'Olympia Tech Park (Guindy)',
    description: 'Design and installation of total flooding Novec 1230 gas cylinder bank, cross-zoned VESDA (Very Early Smoke Detection Apparatus) aspirating sensors, and abort switches for main data hall.',
    category: 'CO2 & Clean Agent Gas',
    startDate: '2026-09-01',
    expectedCompletionDate: '2026-12-30',
    assignedEmployeeIds: ['emp-2', 'emp-3'],
    priority: 'Medium',
    status: 'Pending',
    progressPercentage: 15,
    isManualProgress: false,
    contractValueINR: 1950000,
    siteLocation: 'C-Wing 4th Floor Data Hall, Guindy, Chennai',
    createdAt: '2026-08-25',
    milestones: [
      { id: 'm3-1', title: 'Room Integrity Test & Volumetric Measure', description: 'Fan pressurization testing for room air tightness', completed: true, dueDate: '2026-09-20', completedDate: '2026-09-18' },
      { id: 'm3-2', title: 'Gas Cylinder Manifold Fabrication', description: 'High-strength steel manifold rack and discharge piping', completed: false, dueDate: '2026-11-05' },
      { id: 'm3-3', title: 'VESDA Laser Pipe Network Installation', description: 'Aspirating capillary tubes above server racks', completed: false, dueDate: '2026-11-28' },
      { id: 'm3-4', title: 'Electrical Actuator & Abort Switch Wiring', description: 'Failsafe interlock with HVAC dampers', completed: false, dueDate: '2026-12-20' }
    ]
  },
  {
    id: 'proj-4',
    reference: 'PHX-2026-064',
    name: 'Mall Fire Extinguisher AMC & Form B Compliance Renewal',
    clientId: 'client-express',
    clientCompanyName: 'Express Avenue Commercial Complex',
    description: 'Annual inspection and hydrostatic pressure testing of 420 portable fire extinguishers (ABC Dry Powder, CO2 4.5kg, Mechanical Foam), replacement of discharge hoses, and TNFRS compliance renewal.',
    category: 'Extinguisher & AMC',
    startDate: '2026-01-02',
    expectedCompletionDate: '2026-03-30',
    assignedEmployeeIds: ['emp-1'],
    priority: 'High',
    status: 'Overdue',
    progressPercentage: 80,
    isManualProgress: false,
    contractValueINR: 480000,
    siteLocation: 'Royapettah, Chennai',
    createdAt: '2025-12-28',
    milestones: [
      { id: 'm4-1', title: 'Floor-by-Floor Extinguisher Audit', description: 'Tagging and QR barcode logging of 420 units', completed: true, dueDate: '2026-01-20', completedDate: '2026-01-19' },
      { id: 'm4-2', title: 'Refilling & Cartridge Hydro Testing', description: 'Batch refilling at Phoenix Ambattur factory', completed: true, dueDate: '2026-02-15', completedDate: '2026-02-14' },
      { id: 'm4-3', title: 'Multiplex Zone Form B Application', description: 'Joint submission to Central Chennai Fire Division', completed: false, dueDate: '2026-03-15' },
      { id: 'm4-4', title: 'Final Inspection & Certificate Dispatch', description: 'Pending receipt of signed Form B clearance certificate', completed: false, dueDate: '2026-03-30' }
    ]
  },
  {
    id: 'proj-5',
    reference: 'PHX-2026-052',
    name: 'Cardiac Care Block Wet Riser & Yard Hydrant Commissioning',
    clientId: 'client-mmm',
    clientCompanyName: 'Madras Medical Mission (MMM Hospital)',
    description: 'Comprehensive installation of double-headed landing valves, 1000 LPM diesel standby fire pump integration, hose reel drums, and water flow test according to IS 3844.',
    category: 'Hydrant & Sprinkler',
    startDate: '2025-11-01',
    expectedCompletionDate: '2026-02-28',
    assignedEmployeeIds: ['emp-1', 'emp-2', 'emp-3'],
    priority: 'Medium',
    status: 'Completed',
    progressPercentage: 100,
    isManualProgress: false,
    contractValueINR: 3200000,
    siteLocation: 'Mogappair Campus, Chennai',
    createdAt: '2025-10-25',
    milestones: [
      { id: 'm5-1', title: 'Underground Pump House Installation', description: 'Main electric, jockey, and diesel backup pump set', completed: true, dueDate: '2025-12-10', completedDate: '2025-12-08' },
      { id: 'm5-2', title: 'Wet Riser Pipe Erection (Floors 1-6)', description: 'Heavy duty C-class galvanized risers and valves', completed: true, dueDate: '2026-01-15', completedDate: '2026-01-14' },
      { id: 'm5-3', title: 'Full Flow Pressure Test at Roof Hydrant', description: 'Achieved 4.5 kg/cm2 at top terrace outlet', completed: true, dueDate: '2026-02-10', completedDate: '2026-02-09' },
      { id: 'm5-4', title: 'Staff Fire Drill & Handover Training', description: 'Hospital engineering & security staff mock drill', completed: true, dueDate: '2026-02-25', completedDate: '2026-02-24' }
    ]
  }
];

export const INITIAL_TASKS: Task[] = [
  {
    id: 'task-101',
    projectId: 'proj-1',
    projectReference: 'PHX-2026-081',
    title: 'Install Addressable Optical Detectors in ICU Wing 3',
    description: 'Mount 48 dual optical-heat detectors and verify address DIP switch mapping against Phoenix drawing PHX-DWG-APL-03.',
    assignedToEmployeeId: 'emp-1',
    assignedToName: 'Senthil Nathan',
    assignedToCode: 'PFS-0001',
    deadline: '2026-10-20',
    priority: 'Critical',
    status: 'In Progress',
    remarks: 'ICU coordinator granted night window 10 PM - 5 AM for quiet installation.',
    visibleToClient: true,
    createdAt: '2026-10-01'
  },
  {
    id: 'task-102',
    projectId: 'proj-1',
    projectReference: 'PHX-2026-081',
    title: 'Update Master As-Built CAD Layout with Sounder Locations',
    description: 'Mark all 32 strobe-cum-sounder wall positions and cable loops on the architectural layout for client signoff.',
    assignedToEmployeeId: 'emp-2',
    assignedToName: 'Priya Balan',
    assignedToCode: 'PFS-0002',
    deadline: '2026-10-18',
    priority: 'High',
    status: 'Completed',
    remarks: 'CAD revision 4 completed and shared with Apollo facilities desk.',
    visibleToClient: true,
    completedAt: '2026-10-12',
    createdAt: '2026-10-02'
  },
  {
    id: 'task-103',
    projectId: 'proj-1',
    projectReference: 'PHX-2026-081',
    title: 'BMS Interlock Relay Testing in Main Security Console',
    description: 'Ensure alarm panel trigger opens stairwell magnetic fire doors and shuts down HVAC AHUs.',
    assignedToEmployeeId: 'emp-1',
    assignedToName: 'Senthil Nathan',
    assignedToCode: 'PFS-0001',
    deadline: '2026-10-28',
    priority: 'High',
    status: 'Pending',
    remarks: 'Awaiting BMS engineer presence from Johnson Controls.',
    visibleToClient: false,
    createdAt: '2026-10-05'
  },
  {
    id: 'task-104',
    projectId: 'proj-2',
    projectReference: 'PHX-2026-089',
    title: 'Fabricate 150mm Header Flange for Deluge Valve Station 2',
    description: 'Weld class C carbon steel flange, perform ultrasonic weld flaw test before shipping to Hyundai site.',
    assignedToEmployeeId: 'emp-3',
    assignedToName: 'Murugan K.',
    assignedToCode: 'PFS-0003',
    deadline: '2026-10-22',
    priority: 'High',
    status: 'In Progress',
    remarks: 'Hydro-weld testing at Ambattur fabrication workshop underway.',
    visibleToClient: true,
    createdAt: '2026-10-03'
  },
  {
    id: 'task-105',
    projectId: 'proj-2',
    projectReference: 'PHX-2026-089',
    title: 'Delivery of 850 UL-Listed Pendant Sprinkler Heads',
    description: 'Verify 68°C red bulb rating, CE and UL markings with shipping manifest.',
    assignedToEmployeeId: 'emp-1',
    assignedToName: 'Senthil Nathan',
    assignedToCode: 'PFS-0001',
    deadline: '2026-10-25',
    priority: 'Medium',
    status: 'Pending',
    remarks: 'Consignment arrived at Chennai port warehouse.',
    visibleToClient: true,
    createdAt: '2026-10-04'
  },
  {
    id: 'task-106',
    projectId: 'proj-4',
    projectReference: 'PHX-2026-064',
    title: 'Resubmit Form B Clarification Letter to Chennai Fire Officer',
    description: 'Submit revised fire exit corridor width calculation requested by District Fire Officer, Central Chennai.',
    assignedToEmployeeId: 'emp-1',
    assignedToName: 'Senthil Nathan',
    assignedToCode: 'PFS-0001',
    deadline: '2026-03-25',
    priority: 'Critical',
    status: 'Overdue',
    remarks: 'Awaiting updated architect plan from Express Avenue mall management.',
    visibleToClient: true,
    createdAt: '2026-03-10'
  },
  {
    id: 'task-107',
    projectId: 'proj-3',
    projectReference: 'PHX-2026-077',
    title: 'Server Room Air Tightness Room Integrity Test',
    description: 'Run door fan pressurization test to verify 10-minute gas retention concentration per NFPA 2001.',
    assignedToEmployeeId: 'emp-3',
    assignedToName: 'Murugan K.',
    assignedToCode: 'PFS-0003',
    deadline: '2026-09-18',
    priority: 'Medium',
    status: 'Completed',
    remarks: 'Retention time measured at 11.4 minutes, meeting NFPA requirements.',
    visibleToClient: true,
    completedAt: '2026-09-18',
    createdAt: '2026-09-02'
  }
];

export const INITIAL_PROGRESS_UPDATES: ProgressUpdate[] = [
  {
    id: 'upd-1',
    projectId: 'proj-1',
    submittedByUserId: 'emp-1',
    submittedByName: 'Senthil Nathan',
    userRole: 'Employee',
    timestamp: '2026-10-12 16:30',
    percentageReported: 75,
    notes: 'Completed loop wiring for 4th and 5th floors. Loop resistance measured at 14.2 ohms, well within 25 ohm ceiling. Commencing smoke sensor clipping tonight in ICU corridor.',
    attachmentName: 'Apollo_Loop_Resistance_Log_Oct12.pdf',
    clientVisible: true
  },
  {
    id: 'upd-2',
    projectId: 'proj-1',
    submittedByUserId: 'emp-2',
    submittedByName: 'Priya Balan',
    userRole: 'Employee',
    timestamp: '2026-10-08 11:15',
    percentageReported: 70,
    notes: 'Uploaded revision 4 of the architectural CAD overlay highlighting the relocation of the secondary repeater panel to the nursing station as requested by Dr. Sundararajan.',
    attachmentName: 'PHX_APL_Nursing_Station_Repeater_Rev4.dwg',
    clientVisible: true
  },
  {
    id: 'upd-3',
    projectId: 'proj-2',
    submittedByUserId: 'emp-3',
    submittedByName: 'Murugan K.',
    userRole: 'Employee',
    timestamp: '2026-10-10 14:00',
    percentageReported: 45,
    notes: 'Underground yard hydrant pipeline trenching finished. Concrete thrust blocks cast at all 90-degree elbows. Ready for pre-pressure leak check.',
    attachmentName: 'Hyundai_Trench_ThrustBlock_Photos.zip',
    clientVisible: true
  }
];

const sampleVoiceAdminToClient = createSynthesizedVoiceNote(340, 6, 'engineer');
const sampleVoiceClientToAdmin = createSynthesizedVoiceNote(220, 8, 'client');
const sampleVoiceTechReport = createSynthesizedVoiceNote(400, 5, 'urgent');

export const INITIAL_MESSAGES: ConversationMessage[] = [
  {
    id: 'msg-1',
    projectId: 'proj-1',
    senderId: 'client-apollo',
    senderName: 'R. Sundararajan',
    senderType: 'client',
    senderRole: 'Client',
    timestamp: '2026-10-11 09:40',
    type: 'text',
    content: 'Good morning Senthil. Please confirm that the night shift team will not generate any loud drilling noise near the Cardiac ICU between 1 AM and 4 AM.',
    messageType: 'public',
    isRead: true,
    status: 'Read'
  },
  {
    id: 'msg-2',
    projectId: 'proj-1',
    senderId: 'emp-1',
    senderName: 'Senthil Nathan (Phoenix Fire Safety)',
    senderType: 'office',
    senderRole: 'Employee',
    timestamp: '2026-10-11 10:05',
    type: 'voice',
    audioUrl: sampleVoiceAdminToClient,
    audioDurationSeconds: 6,
    content: '[Voice Message - 0:06] "Good morning Sir. Yes, all heavy anchor drilling for cable trays will be finished strictly by 11:30 PM. From midnight onwards we will only be doing quiet optical sensor snapping and wire loop crimping."',
    messageType: 'public',
    isRead: true,
    status: 'Read'
  },
  {
    id: 'msg-3',
    projectId: 'proj-1',
    senderId: 'client-apollo',
    senderName: 'R. Sundararajan',
    senderType: 'client',
    senderRole: 'Client',
    timestamp: '2026-10-11 10:20',
    type: 'voice',
    audioUrl: sampleVoiceClientToAdmin,
    audioDurationSeconds: 8,
    content: '[Voice Message - 0:08] "Understood and appreciated Senthil. Also, our medical director requested an extra manual call point right near the dialysis suite exit. Can you verify if that loop has spare capacity?"',
    messageType: 'public',
    isRead: true,
    status: 'Read'
  },
  {
    id: 'msg-4',
    projectId: 'proj-1',
    senderId: 'user-admin-1',
    senderName: 'Rajesh Kumar (Phoenix Fire Safety)',
    senderType: 'office',
    senderRole: 'Admin',
    timestamp: '2026-10-11 11:30',
    type: 'text',
    content: 'Dear Mr. Sundararajan, we reviewed Loop 3 loading. We have 41 address points available on that loop, so adding the manual call point and an additional strobe at the dialysis exit is completely safe. We have included it in the work order with no extra routing charge.',
    messageType: 'public',
    isRead: true,
    status: 'Read'
  },
  {
    id: 'msg-5',
    projectId: 'proj-2',
    senderId: 'client-hyundai',
    senderName: 'Ananya Roy',
    senderType: 'client',
    senderRole: 'Client',
    timestamp: '2026-10-12 15:10',
    type: 'text',
    content: 'Hi Senthil, what is the status of the deluge valve calibration test for Assembly Bay 4?',
    messageType: 'public',
    isRead: false,
    status: 'Delivered'
  },
  {
    id: 'msg-6',
    projectId: 'proj-2',
    senderId: 'emp-3',
    senderName: 'Murugan K. (Phoenix Fire Safety)',
    senderType: 'office',
    senderRole: 'Employee',
    timestamp: '2026-10-12 15:45',
    type: 'voice',
    audioUrl: sampleVoiceTechReport,
    audioDurationSeconds: 5,
    content: '[Voice Message - 0:05] "Madam, flange welding is finished at our workshop. We are scheduling the hydrostatic hold test for Thursday afternoon on site with your safety team."',
    messageType: 'public',
    isRead: false,
    status: 'Delivered'
  }
];

export const INITIAL_DOCUMENTS: ProjectDocument[] = [
  {
    id: 'doc-1',
    projectId: 'proj-1',
    projectReference: 'PHX-2026-081',
    title: 'Approved Fire Alarm Loop Schematic (ICU & OPD)',
    filename: 'PHX_DWG_APL_03_Rev4.dwg',
    fileType: 'dwg',
    fileSize: '4.8 MB',
    category: 'Drawing',
    uploadDate: '2026-10-08',
    uploadedBy: 'Priya Balan',
    uploadedByRole: 'Employee',
    accessLevel: 'Client Shared',
    previewText: 'CAD Drawing Schematic: Phoenix Addressable Loop 1 to 4 Layout for Apollo Greams Road Main Block. 340 Smoke Detectors, 48 Strobe Sounders, 14 Manual Call Points.'
  },
  {
    id: 'doc-2',
    projectId: 'proj-1',
    projectReference: 'PHX-2026-081',
    title: 'Apollo Work Order & Technical Scope of Work',
    filename: 'APOLLO_WO_PHX_2026_9918.pdf',
    fileType: 'pdf',
    fileSize: '1.2 MB',
    category: 'Work Order',
    uploadDate: '2026-01-10',
    uploadedBy: 'Rajesh Kumar',
    uploadedByRole: 'Admin',
    accessLevel: 'Client Shared',
    previewText: 'Formal Work Order issued by Apollo Hospitals Enterprise Ltd. Scope: Supply, installation, testing and commissioning of UL-listed addressable fire alarm system.'
  },
  {
    id: 'doc-3',
    projectId: 'proj-1',
    projectReference: 'PHX-2026-081',
    title: 'Cable Insulation & Loop Resistance Verification Log',
    filename: 'Apollo_Loop_Resistance_Log_Oct12.pdf',
    fileType: 'pdf',
    fileSize: '620 KB',
    category: 'Inspection Report',
    uploadDate: '2026-10-12',
    uploadedBy: 'Senthil Nathan',
    uploadedByRole: 'Employee',
    accessLevel: 'Client Shared',
    previewText: 'Site Measurement Report: Loop 1 (13.8Ω), Loop 2 (14.2Ω), Loop 3 (12.9Ω), Loop 4 (15.1Ω). Megger Insulation Test > 100 MΩ at 500V DC.'
  },
  {
    id: 'doc-4',
    projectId: 'proj-2',
    projectReference: 'PHX-2026-089',
    title: 'NFPA 13 Hydraulic Calculation Sheet (Bay 4)',
    filename: 'Hyundai_Hydraulic_Calc_NFPA13.pdf',
    fileType: 'pdf',
    fileSize: '2.4 MB',
    category: 'Quotation',
    uploadDate: '2026-02-15',
    uploadedBy: 'Rajesh Kumar',
    uploadedByRole: 'Admin',
    accessLevel: 'Client Shared',
    previewText: 'Hydraulic calculation model per NFPA 13 Ordinary Hazard Group 2. Density 0.20 GPM/sq ft over 2500 sq ft design area. Residual pressure at remote sprinkler: 1.8 bar.'
  },
  {
    id: 'doc-5',
    projectId: 'proj-4',
    projectReference: 'PHX-2026-064',
    title: 'Tamil Nadu Fire Service Form B Inspection Checklist',
    filename: 'TNFRS_FormB_Audit_Checklist_ExpressAve.pdf',
    fileType: 'pdf',
    fileSize: '1.8 MB',
    category: 'Form B NOC',
    uploadDate: '2026-01-22',
    uploadedBy: 'Rajesh Kumar',
    uploadedByRole: 'Admin',
    accessLevel: 'Client Shared',
    previewText: 'Statutory Form B Inspection Checklist under Tamil Nadu Fire Service Rules 1990 for Commercial Complex NOC renewal.'
  },
  {
    id: 'doc-6',
    projectId: 'proj-5',
    projectReference: 'PHX-2026-052',
    title: 'Final Handover & Commissioning Certificate',
    filename: 'MMM_Hospital_Fire_Safety_Handover_Cert.pdf',
    fileType: 'pdf',
    fileSize: '890 KB',
    category: 'Certificate',
    uploadDate: '2026-02-28',
    uploadedBy: 'Rajesh Kumar',
    uploadedByRole: 'Admin',
    accessLevel: 'Client Shared',
    previewText: 'Handover Certificate signed by Phoenix Fire Safety Equipments Pvt. Ltd. and Madras Medical Mission Hospital Management. System operational and warrantied.'
  }
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-1',
    title: 'Urgent Task Overdue',
    message: 'Express Avenue Mall Form B Clarification Letter has exceeded target deadline.',
    type: 'deadline',
    targetRole: 'Admin',
    projectId: 'proj-4',
    taskId: 'task-106',
    read: false,
    timestamp: '2026-10-14 08:30'
  },
  {
    id: 'notif-2',
    title: 'New Client Message Received',
    message: 'Ananya Roy (Hyundai Motor) sent a new inquiry regarding Assembly Bay 4 deluge testing.',
    type: 'message',
    targetRole: 'Admin',
    projectId: 'proj-2',
    read: false,
    timestamp: '2026-10-12 15:10'
  },
  {
    id: 'notif-3',
    title: 'Progress Report Submitted',
    message: 'Senthil Nathan updated project PHX-2026-081 progress to 75%.',
    type: 'project',
    targetRole: 'Admin',
    projectId: 'proj-1',
    read: true,
    timestamp: '2026-10-12 16:30'
  },
  {
    id: 'notif-4',
    title: 'Document Uploaded',
    message: 'Priya Balan uploaded CAD Drawing Revision 4 for Apollo Hospitals.',
    type: 'document',
    targetRole: 'Client',
    projectId: 'proj-1',
    read: true,
    timestamp: '2026-10-08 11:20'
  }
];

export const INITIAL_ACTIVITIES: ActivityLog[] = [
  {
    id: 'act-1',
    projectId: 'proj-1',
    projectReference: 'PHX-2026-081',
    action: 'Progress Updated',
    details: 'Project progress increased from 70% to 75% following loop wiring completion.',
    performedBy: 'Senthil Nathan',
    role: 'Employee',
    timestamp: '2026-10-12 16:30'
  },
  {
    id: 'act-2',
    projectId: 'proj-1',
    projectReference: 'PHX-2026-081',
    action: 'Voice Message Sent',
    details: 'R. Sundararajan sent 8-second voice clarification on dialysis exit.',
    performedBy: 'R. Sundararajan',
    role: 'Client',
    timestamp: '2026-10-11 10:20'
  },
  {
    id: 'act-3',
    projectId: 'proj-1',
    projectReference: 'PHX-2026-081',
    action: 'CAD Drawing Shared',
    details: 'Priya Balan uploaded approved schematic revision 4 with client access.',
    performedBy: 'Priya Balan',
    role: 'Employee',
    timestamp: '2026-10-08 11:15'
  },
  {
    id: 'act-4',
    projectId: 'proj-2',
    projectReference: 'PHX-2026-089',
    action: 'Milestone Completed',
    details: 'Milestone "Main Yard Ring Pipeline Laying" marked completed.',
    performedBy: 'Rajesh Kumar',
    role: 'Admin',
    timestamp: '2026-06-10 17:00'
  }
];

export const ZOHO_SAMPLE_RECORDS = [
  {
    companyName: 'Apollo Hospitals Enterprise Ltd.',
    contactPerson: 'R. Sundararajan',
    email: 'sundararajan.r@apollohospitals.com',
    phone: '+91 98410 77123',
    address: '21 Greams Lane',
    city: 'Chennai',
    gstin: '33AABCA1294F1Z8',
    industry: 'Healthcare',
    zohoContactId: 'ZC-8819234'
  },
  {
    companyName: 'TVS Motor Company Ltd.',
    contactPerson: 'M. S. Venkatesan',
    email: 'venkatesan.ms@tvsmotor.com',
    phone: '+91 98403 66102',
    address: 'Post Box No. 4, Harita',
    city: 'Hosur, Tamil Nadu 635109',
    gstin: '33AAACT1029B1Z4',
    industry: 'Automotive & 2-Wheeler Plant',
    zohoContactId: 'ZC-3019842'
  },
  {
    companyName: 'Zoho Corporation Private Ltd.',
    contactPerson: 'Shyamala Sundaram',
    email: 'facilities@zohocorp.com',
    phone: '+91 98409 11844',
    address: 'Estancia IT Park, Vallancheri, GST Road',
    city: 'Chengalpattu, Tamil Nadu 603202',
    gstin: '33AABCZ9941K1ZM',
    industry: 'Cloud Software & Tech Campus',
    zohoContactId: 'ZC-4491022'
  },
  {
    companyName: 'Hyundai Motor India Ltd.',
    contactPerson: 'Ananya Roy',
    email: 'ananya.roy@hyundai-india.com',
    phone: '+91 99620 54321',
    address: 'Plot H-1, SIPCOT',
    city: 'Sriperumbudur',
    gstin: '33AAACH2391Q1ZP',
    industry: 'Automobile',
    zohoContactId: 'ZC-9120441'
  },
  {
    companyName: 'L&T Infotech (LTIMindtree) Chennai',
    contactPerson: 'Gautam Ramakrishnan',
    email: 'gautam.r@ltimindtree.com',
    phone: '+91 94440 88219',
    address: 'DLF Cybercity, Block 7, Mount Poonamallee Rd, Manapakkam',
    city: 'Chennai, Tamil Nadu 600089',
    gstin: '33AABCL3391P1ZO',
    industry: 'Information Technology',
    zohoContactId: 'ZC-5510294'
  }
];
