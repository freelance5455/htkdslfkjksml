import { User, Paper, Post, Notification, Achievement, SystemStats } from '../types';

export const SRI_LANKAN_SCHOOLS = [
  'Royal College, Colombo 07',
  'Visakha Vidyalaya, Colombo 05',
  'Ananda College, Colombo 10',
  'Nalanda College, Colombo 10',
  'Ladies\' College, Colombo 07',
  'Dharmaraja College, Kandy',
  'Mahinda College, Galle',
  'Trinity College, Kandy',
  'Jaffna Hindu College, Jaffna',
  'Maliyadeva College, Kurunegala',
  'Central College, Jaffna',
  'Central College, Piliyandala',
  'St. Joseph\'s College, Colombo 10',
  'St. Peter\'s College, Colombo 04',
  'Central College, Bandarawela',
  'St. Thomas\' College, Mount Lavinia',
  'Devi Balika Vidyalaya, Colombo 08',
  'Musaeus College, Colombo 07',
  'Sirimavo Bandaranaike Vidyalaya, Colombo 07',
  'Richmond College, Galle',
  'St. Aloysius\' College, Galle',
  'St. Anthony\'s College, Kandy',
  'Kingswood College, Kandy',
  'Gampaha Bandaranayake College',
  'Taxila Central College, Horana',
  'Rahula College, Matara'
];

export const SUBJECTS_BY_GRADE: Record<string, string[]> = {
  'Grade 6': ['Mathematics', 'Science', 'Sinhala Language', 'English Language', 'History', 'Geography', 'Buddhism', 'Health & Physical Education', 'Practical & Technical Skills'],
  'Grade 7': ['Mathematics', 'Science', 'Sinhala Language', 'English Language', 'History', 'Geography', 'Buddhism', 'Civic Education', 'Practical & Technical Skills'],
  'Grade 8': ['Mathematics', 'Science', 'Sinhala Language', 'English Language', 'History', 'Geography', 'Buddhism', 'Civic Education', 'Information Technology'],
  'Grade 9': ['Mathematics', 'Science', 'Sinhala Language', 'English Language', 'History', 'Geography', 'Buddhism', 'Civic Education', 'Information Technology'],
  'G.C.E. O/L': [
    'Mathematics', 'Science', 'Sinhala Language & Lit', 'English Language', 'History', 'Buddhism',
    'Information & Communication Technology (ICT)', 'Business & Accounting Studies', 'Entrepreneurship Studies', 'Geography', 'Civic Education', 'English Literature', 'Health & Physical Education', 'Agriculture & Food Technology', 'Music', 'Art', 'Dancing'
  ],
  'G.C.E. A/L': [
    'Combined Mathematics', 'Physics', 'Chemistry', 'Biology', 'Agricultural Science',
    'Information & Communication Technology (ICT)', 'Accounting', 'Business Studies', 'Economics', 'Business Statistics',
    'Sinhala', 'English Literature', 'History', 'Logic & Scientific Method', 'Political Science', 'Media Studies', 'Geography',
    'Engineering Technology', 'Science for Technology', 'Bio Systems Technology'
  ]
};

export const INITIAL_USERS: User[] = [
  {
    id: 'usr_1',
    name: 'Kasun Perera',
    email: 'kasun.p@lankapaperhub.lk',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    coverImage: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=1200&auto=format&fit=crop&q=80',
    role: 'TEACHER',
    bio: 'Senior Physics Teacher & Exam Paper Author with 12+ years experience preparing A/L students across Sri Lanka.',
    school: 'Royal College, Colombo 07',
    province: 'Western',
    points: 3450,
    level: 8,
    joinedDate: '2024-01-15',
    followersCount: 1240,
    followingCount: 89,
    isVerified: true,
    isTwoFactorEnabled: true,
    badges: ['Top Uploader', 'Master Educator', 'Physics Guru'],
    savedPaperIds: ['p_1', 'p_3'],
    likedPaperIds: ['p_1', 'p_2', 'p_4'],
    followedUserIds: ['usr_2', 'usr_3']
  },
  {
    id: 'usr_2',
    name: 'Dilani Bandara',
    email: 'dilani.b@student.lk',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    coverImage: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=1200&auto=format&fit=crop&q=80',
    role: 'STUDENT',
    bio: '2025 A/L Physical Science Stream student. Passionate about Combined Maths and ICT.',
    school: 'Visakha Vidyalaya, Colombo 05',
    province: 'Western',
    points: 1280,
    level: 4,
    joinedDate: '2024-03-10',
    followersCount: 310,
    followingCount: 145,
    isVerified: true,
    isTwoFactorEnabled: false,
    badges: ['Scholar', 'Active Contributor'],
    savedPaperIds: ['p_2', 'p_5'],
    likedPaperIds: ['p_1', 'p_3'],
    followedUserIds: ['usr_1']
  },
  {
    id: 'usr_3',
    name: 'Dr. Tharindu Wickramasinghe',
    email: 'admin@lankapaperhub.lk',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    coverImage: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1200&auto=format&fit=crop&q=80',
    role: 'SUPER_ADMIN',
    bio: 'Lead Platform Moderator & Educational Technology Strategist.',
    school: 'Dharmaraja College, Kandy',
    province: 'Central',
    points: 9800,
    level: 15,
    joinedDate: '2023-11-01',
    followersCount: 4500,
    followingCount: 200,
    isVerified: true,
    isTwoFactorEnabled: true,
    badges: ['Super Admin', 'Platform Founder', 'Verified Educator'],
    savedPaperIds: ['p_1', 'p_2', 'p_3', 'p_4', 'p_5', 'p_6'],
    likedPaperIds: ['p_1', 'p_2', 'p_3', 'p_4', 'p_5', 'p_6'],
    followedUserIds: ['usr_1', 'usr_2']
  }
];

export const INITIAL_PAPERS: Paper[] = [
  {
    id: 'p_1',
    title: 'G.C.E. A/L Combined Mathematics 2024 - Paper I & II Full Model Paper with Marking Scheme',
    subject: 'Combined Mathematics',
    grade: 'G.C.E. A/L',
    medium: 'Sinhala',
    year: 2024,
    province: 'Western',
    school: 'Royal College, Colombo 07',
    paperType: 'Model Paper',
    termTest: '3rd Term',
    hasAnswers: true,
    hasMarkingScheme: true,
    fileFormat: 'PDF',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    fileSize: '4.8 MB',
    pagesCount: 16,
    downloadCount: 3420,
    viewsCount: 12850,
    uploadedDate: '2024-10-12',
    uploaderId: 'usr_1',
    uploaderName: 'Kasun Perera',
    uploaderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    uploaderRole: 'TEACHER',
    status: 'APPROVED',
    tags: ['A/L Maths', 'Royal College', 'Combined Mathematics', 'Marking Scheme', '2024 Model'],
    description: 'Comprehensive 2024 Model Examination Paper for Combined Mathematics (Pure Maths & Applied Maths) designed according to Department of Examinations specifications. Complete step-by-step marking scheme included.',
    previewPagesText: [
      'G.C.E. (A/L) EXAMINATION - MODEL PAPER 2024\nCOMBINED MATHEMATICS I (PURE MATHEMATICS)\nTime: 03 Hours\n\n[PART A] Answer all ten questions.\n1. Solve the inequality |2x - 3| < x + 1 for real values of x.\n2. If α and β are the roots of equation x² - p x + q = 0, show that α/β + β/α = (p² - 2q)/q.\n3. Find the derivative of f(x) = tan⁻¹( (1 + sin x) / cos x ).\n4. Evaluate the integral ∫ (0 to π/2) sin³ x cos x dx.\n\n[PART B] Answer five questions selecting at least two from each section.\n5.(a) Prove by mathematical induction that 1² + 2² + ... + n² = n(n+1)(2n+1)/6.',
      'G.C.E. (A/L) EXAMINATION - MODEL PAPER 2024\nCOMBINED MATHEMATICS II (APPLIED MATHEMATICS)\nTime: 03 Hours\n\n[SECTION A - MECHANICS]\n1. A particle P of mass m is projected vertically upwards with speed u. Show that maximum height reached is u²/2g.\n2. Two light elastic strings attached to a particle of mass m maintain equilibrium on an inclined plane.\n\n[SECTION B - PROBABILITY & STATISTICS]\n3. Calculate the standard deviation and variance for the given frequency distribution of A/L marks.'
    ],
    likesCount: 542
  },
  {
    id: 'p_2',
    title: 'G.C.E. A/L Physics 2023 - Western Province 3rd Term Evaluation Exam (Paper I, II + Answers)',
    subject: 'Physics',
    grade: 'G.C.E. A/L',
    medium: 'English',
    year: 2023,
    province: 'Western',
    school: 'Visakha Vidyalaya, Colombo 05',
    paperType: 'Term Test',
    termTest: '3rd Term',
    hasAnswers: true,
    hasMarkingScheme: true,
    fileFormat: 'PDF',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    fileSize: '3.2 MB',
    pagesCount: 12,
    downloadCount: 2890,
    viewsCount: 9400,
    uploadedDate: '2023-11-20',
    uploaderId: 'usr_2',
    uploaderName: 'Dilani Bandara',
    uploaderAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    uploaderRole: 'STUDENT',
    status: 'APPROVED',
    tags: ['Physics', 'Western Province', 'Term Test', 'Visakha Vidyalaya', 'A/L Physics'],
    description: 'Western Province 2023 Grade 13 3rd Term Physics paper with full MCQ key and structured essay explanations.',
    previewPagesText: [
      'WESTERN PROVINCE EDUCATION DEPARTMENT\nGRADE 13 THIRD TERM EVALUATION - 2023\nPHYSICS I - MULTIPLE CHOICE QUESTIONS (50 MCQs)\n\n1. Which of the following physical quantities has dimensions [M L T⁻²]?\n(A) Energy  (B) Power  (C) Force  (D) Momentum  (E) Pressure\n\n2. A ray of light passes from air into glass of refractive index 1.5. If the angle of incidence is 30°, the angle of refraction is roughly:\n(A) 19.5°  (B) 30°  (C) 45°  (D) 60°\n\n3. An ideal gas undergoes an isothermal expansion at temperature 300 K...',
      'PHYSICS II - STRUCTURED ESSAY & ESSAY\n\n1. (a) State Newton\'s Law of Universal Gravitation.\n   (b) Derive an expression for the orbital velocity of a satellite revolving around Earth at height h above the surface.\n   (c) A communication satellite orbits Earth at an altitude where g = 8.5 m s⁻²...'
    ],
    likesCount: 388
  },
  {
    id: 'p_3',
    title: 'G.C.E. O/L Mathematics 2024 - Past Paper & Full Official Marking Scheme (Sinhala Medium)',
    subject: 'Mathematics',
    grade: 'G.C.E. O/L',
    medium: 'Sinhala',
    year: 2024,
    province: 'National',
    school: 'Department of Examinations, Sri Lanka',
    paperType: 'Past Paper',
    termTest: 'Final Exam',
    hasAnswers: true,
    hasMarkingScheme: true,
    fileFormat: 'PDF',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    fileSize: '5.1 MB',
    pagesCount: 18,
    downloadCount: 5670,
    viewsCount: 18900,
    uploadedDate: '2024-06-15',
    uploaderId: 'usr_3',
    uploaderName: 'Dr. Tharindu Wickramasinghe',
    uploaderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    uploaderRole: 'SUPER_ADMIN',
    status: 'APPROVED',
    tags: ['O/L Maths', 'National Past Paper', '2024 OL', 'Official Marking Scheme'],
    description: 'Official 2024 G.C.E. O/L Mathematics Past Paper I and Part II with marking scheme approved by Department of Examinations.',
    previewPagesText: [
      'ශ්‍රී ලංකා විභාග දෙපාර්තමේන්තුව\nඅධ්‍යයන පොදු සහතික පත්‍ර (සාමාන්‍ය පෙළ) විභාගය - 2024\nගණිතය I - කොටස A (ප්‍රශ්න 25)\n\n1. ශුද්ධ රු. 40,000 ක වටිනාකමකින් යුත් භාණ්ඩයක් සඳහා 8% ක වැට් (VAT) බද්දක් අය කෙරේ. අය කරන බදු මුදල සොයන්න.\n2. පහත දැක්වෙන සාධක සොයන්න: x² - 9y².\n3. අරය 7 cm වන අර්ධ ගෝලයක වක්‍ර පෘෂ්ඨ වර්ගඵලය ගණනය කරන්න.',
      'ගණිතය II - කොටස A (ප්‍රශ්න 6 කට පිළිතුරු සපයන්න)\n1. (a) මිනිසුන් 6 දෙනෙකුට දින 8 කින් නිම කළ හැකි වැඩක් මිනිසුන් 4 දෙනෙකුට නිම කිරීමට දින කීයක් ගතවේද?\n2. දී ඇති ලඝුගණක වගු භාවිතයෙන් 45.2 × √(0.816) හි අගය සොයන්න.'
    ],
    likesCount: 890
  },
  {
    id: 'p_4',
    title: 'G.C.E. A/L Information & Communication Technology (ICT) 2023 - Term Test Paper',
    subject: 'Information & Communication Technology (ICT)',
    grade: 'G.C.E. A/L',
    medium: 'English',
    year: 2023,
    province: 'Central',
    school: 'Dharmaraja College, Kandy',
    paperType: 'Term Test',
    termTest: '2nd Term',
    hasAnswers: true,
    hasMarkingScheme: true,
    fileFormat: 'PDF',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    fileSize: '2.9 MB',
    pagesCount: 10,
    downloadCount: 1420,
    viewsCount: 4200,
    uploadedDate: '2023-08-10',
    uploaderId: 'usr_1',
    uploaderName: 'Kasun Perera',
    uploaderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    uploaderRole: 'TEACHER',
    status: 'APPROVED',
    tags: ['A/L ICT', 'Dharmaraja College', 'Python', 'SQL', 'Networking'],
    description: 'Dharmaraja College 2023 Grade 12 2nd Term ICT Paper covering Logic Gates, Python Programming, Database SQL queries, and Networking fundamentals.',
    previewPagesText: [
      'DHARMARAJA COLLEGE - KANDY\nGRADE 12 MID-YEAR EXAMINATION 2023\nINFORMATION & COMMUNICATION TECHNOLOGY (ICT)\n\nPart A - 50 MCQs\n1. What is the equivalent hexadecimal representation of the binary number 11010110₂?\n(A) D6₁₆  (B) E6₁₆  (C) C6₁₆  (D) B6₁₆\n\n2. Which OSI layer is responsible for IP routing and logical addressing?\n(A) Data Link  (B) Network  (C) Transport  (D) Session\n\n3. Consider the following Python code snippet:\n   x = [i*2 for i in range(5) if i % 2 == 0]\n   print(x)\n   Output will be:\n   (A) [0, 4, 8]  (B) [0, 2, 4]  (C) [2, 4]  (D) [0, 1, 2, 3, 4]',
      'Part B - Structured Essay\n\n1. (a) Draw the truth table and circuit diagram for a 2-to-1 Multiplexer using NAND gates.\n   (b) Write a SQL statement to retrieve student names and average marks from the `Students` table where average > 75.\n   (c) Explain the difference between TCP and UDP protocols.'
    ],
    likesCount: 210
  },
  {
    id: 'p_5',
    title: 'G.C.E. O/L Science 2023 - Southern Province Provincial Evaluation Examination',
    subject: 'Science',
    grade: 'G.C.E. O/L',
    medium: 'Sinhala',
    year: 2023,
    province: 'Southern',
    school: 'Mahinda College, Galle',
    paperType: 'Term Test',
    termTest: '3rd Term',
    hasAnswers: true,
    hasMarkingScheme: false,
    fileFormat: 'PDF',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    fileSize: '3.9 MB',
    pagesCount: 14,
    downloadCount: 2150,
    viewsCount: 6800,
    uploadedDate: '2023-10-05',
    uploaderId: 'usr_2',
    uploaderName: 'Dilani Bandara',
    uploaderAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    uploaderRole: 'STUDENT',
    status: 'APPROVED',
    tags: ['O/L Science', 'Southern Province', 'Mahinda College', 'Biology', 'Chemistry'],
    description: 'Southern Province 2023 Grade 11 3rd Term Science evaluation test covering Physics, Chemistry, and Biology sections.',
    previewPagesText: [
      'දකුණු පළාත් අධ්‍යාපන දෙපාර්තමේන්තුව\n3 වන වාර ඇගයීම - 2023\nවිද්‍යාව I (බහුගවරණ ප්‍රශ්න 40)\n\n1. ශාක සෛලයක ප්ලාස්ම පටලය හරහා ජලය ඇතුළුවීමේ ප්‍රධාන ක්‍රියාවලිය කුමක්ද?\n(A) විසරණය  (B) පරාසෘතිය  (C) සක්‍රිය ප්‍රවාහනය  (D) අන්තඃශෝෂණය\n\n2. ආවර්තිතා වගුවේ 3 වන ආවර්තයේ II කාණ්ඩයේ ඇති මූලද්‍රව්‍යයේ පරමාණුක ක්‍රමාංකය කොපමණද?\n(A) 11  (B) 12  (C) 13  (D) 14'
    ],
    likesCount: 290
  }
];

export const INITIAL_POSTS: Post[] = [
  {
    id: 'post_1',
    authorId: 'usr_1',
    authorName: 'Kasun Perera',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    authorRole: 'TEACHER',
    content: '📢 Important Update for 2025 A/L Physics Students: Make sure to thoroughly revise rotational motion, electromagnetic induction, and heat radiation. I have uploaded the latest model paper with complete marking scheme in LankaPaperHub! Good luck to all students! 🇱🇰📚 #ALPhysics #SriLankaEducation #ExamPrep',
    createdAt: '2024-07-22T10:30:00Z',
    likesCount: 142,
    likedUserIds: ['usr_2', 'usr_3'],
    commentsCount: 28,
    hashtags: ['ALPhysics', 'SriLankaEducation', 'ExamPrep'],
    poll: {
      question: 'Which area in A/L Physics do you find most challenging?',
      options: [
        { id: 'opt_1', text: 'Mechanics & Rotational Motion', votes: 45, votedUserIds: ['usr_2'] },
        { id: 'opt_2', text: 'Waves & Oscillations', votes: 18, votedUserIds: [] },
        { id: 'opt_3', text: 'Electricity & Electronics', votes: 32, votedUserIds: [] },
        { id: 'opt_4', text: 'Thermal Physics & Radiation', votes: 12, votedUserIds: [] }
      ]
    },
    isPinned: true,
    isAnnouncement: true
  },
  {
    id: 'post_2',
    authorId: 'usr_2',
    authorName: 'Dilani Bandara',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    authorRole: 'STUDENT',
    content: 'Does anyone have the official marking scheme for 2023 A/L Combined Maths Western Province 2nd Term Paper II? Please upload or share the link if available! Thanks in advance! 🙏 #CombinedMaths #AL2025 #HelpEachOther',
    createdAt: '2024-07-23T14:15:00Z',
    likesCount: 38,
    likedUserIds: ['usr_1'],
    commentsCount: 9,
    hashtags: ['CombinedMaths', 'AL2025', 'HelpEachOther']
  }
];

export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'notif_1',
    userId: 'usr_2',
    type: 'PAPER_APPROVED',
    title: 'Paper Approved!',
    message: 'Your uploaded paper "G.C.E. O/L Science 2023 - Southern Province" has been approved by moderators. +50 Gamification Points awarded!',
    createdAt: '2024-07-23T16:00:00Z',
    isRead: false,
    linkUrl: '/paper/p_5'
  },
  {
    id: 'notif_2',
    userId: 'usr_2',
    type: 'LIKE',
    title: 'New Like on your Post',
    message: 'Kasun Perera liked your community post regarding Combined Mathematics marking scheme.',
    createdAt: '2024-07-23T15:10:00Z',
    isRead: true
  }
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach_1',
    title: 'First Contribution',
    description: 'Upload your first verified past paper or model test.',
    category: 'UPLOADS',
    icon: 'Upload',
    progress: 100,
    unlockedAt: '2024-03-12'
  },
  {
    id: 'ach_2',
    title: 'Top Scholar',
    description: 'Download 25 study papers and marking schemes.',
    category: 'DOWNLOADS',
    icon: 'BookOpen',
    progress: 80
  },
  {
    id: 'ach_3',
    title: 'Community Beacon',
    description: 'Receive 50 likes on your shared community posts.',
    category: 'COMMUNITY',
    icon: 'MessageSquare',
    progress: 60
  },
  {
    id: 'ach_4',
    title: 'Exam Guardian',
    description: 'Upload 10 paper marking schemes that help 1,000+ Sri Lankan students.',
    category: 'UPLOADS',
    icon: 'Award',
    progress: 30
  }
];

export const SYSTEM_STATS: SystemStats = {
  totalPapers: 12480,
  totalDownloads: 489200,
  totalUsers: 34150,
  pendingApprovals: 8,
  storageUsedGB: 142.5,
  activeToday: 2480
};
