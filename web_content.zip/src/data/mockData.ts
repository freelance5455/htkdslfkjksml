import { ChildDevice, AlertNotification } from '../types';

export const INITIAL_DEVICES: ChildDevice[] = [
  {
    id: 'dev_ahmed_01',
    childName: 'Ahmed',
    childNameAr: 'أحمد',
    childAge: 12,
    avatarUrl: 'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?w=150&auto=format&fit=crop&q=80',
    deviceName: 'Galaxy S24 Ultra',
    platform: 'android',
    model: 'Samsung SM-S928B',
    osVersion: 'Android 14 (One UI 6.1)',
    batteryLevel: 68,
    isCharging: false,
    isOnline: true,
    lastSyncTime: 'الآن (متصل)',
    screenTimeTodayMinutes: 185,
    screenTimeLimitMinutes: 240,
    currentLocation: {
      lat: 24.7136,
      lng: 46.6753,
      address: 'مدرسة الأفق العالمية - طريق الملك فهد، الرياض',
      speedKmh: 0,
      accuracyMeters: 4,
      lastUpdated: 'منذ دقيقة',
    },
    simCarrier: 'STC 5G',
    pairingCode: 'PG-8492',
    currentActiveApp: 'com.google.android.youtube',
    geofenceZones: [
      {
        id: 'geo_home',
        name: 'Home Zone',
        nameAr: 'المنزل',
        lat: 24.7180,
        lng: 46.6680,
        radiusMeters: 180,
        type: 'safe',
        address: 'حي النخيل، فيلا 14',
        notifyOnEnter: true,
        notifyOnExit: true,
      },
      {
        id: 'geo_school',
        name: 'Horizon School',
        nameAr: 'مدرسة الأفق',
        lat: 24.7136,
        lng: 46.6753,
        radiusMeters: 250,
        type: 'safe',
        address: 'طريق الملك فهد، مجمع المدارس',
        notifyOnEnter: true,
        notifyOnExit: true,
      },
      {
        id: 'geo_club',
        name: 'Sports Club',
        nameAr: 'النادي الرياضي',
        lat: 24.7290,
        lng: 46.6850,
        radiusMeters: 300,
        type: 'safe',
        address: 'شارع التخصصي',
        notifyOnEnter: true,
        notifyOnExit: true,
      },
    ],
    settings: {
      wifiEnabled: true,
      bluetoothEnabled: true,
      cellularDataEnabled: true,
      airplaneMode: false,
      gpsEnabled: true,
      hotspotEnabled: false,
      flashlightEnabled: false,
      doNotDisturb: false,
      volumeMedia: 60,
      volumeRing: 80,
      volumeAlarm: 90,
      brightness: 75,
      autoBrightness: true,
      safeSearchEnabled: true,
      installAppsBlocked: true,
      uninstallAppsBlocked: true,
      cameraBlocked: false,
      micBlocked: false,
      screenLocked: false,
      lockMessage: 'تم قفل هذا الهاتف بواسطة ولي الأمر. يرجى التركيز في الدراسة!',
      bedtimeStart: '21:30',
      bedtimeEnd: '06:30',
      bedtimeActive: false,
    },
    installedApps: [
      {
        id: 'app_youtube',
        name: 'YouTube',
        nameAr: 'يوتيوب',
        packageName: 'com.google.android.youtube',
        icon: 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png',
        category: 'entertainment',
        isBlocked: false,
        dailyLimitMinutes: 60,
        usedMinutesToday: 55,
        installDate: '2024-01-10',
        sizeMb: 142,
        version: '19.12.35',
        isSystemApp: false,
      },
      {
        id: 'app_tiktok',
        name: 'TikTok',
        nameAr: 'تيك توك',
        packageName: 'com.zhiliaoapp.musically',
        icon: 'https://cdn-icons-png.flaticon.com/512/3046/3046121.png',
        category: 'social',
        isBlocked: true,
        dailyLimitMinutes: 30,
        usedMinutesToday: 30,
        installDate: '2024-02-15',
        sizeMb: 210,
        version: '33.4.1',
        isSystemApp: false,
      },
      {
        id: 'app_roblox',
        name: 'Roblox',
        nameAr: 'روبلوكس',
        packageName: 'com.roblox.client',
        icon: 'https://cdn-icons-png.flaticon.com/512/5969/5969074.png',
        category: 'games',
        isBlocked: false,
        dailyLimitMinutes: 45,
        usedMinutesToday: 40,
        installDate: '2024-01-20',
        sizeMb: 185,
        version: '2.618',
        isSystemApp: false,
      },
      {
        id: 'app_whatsapp',
        name: 'WhatsApp',
        nameAr: 'واتساب',
        packageName: 'com.whatsapp',
        icon: 'https://cdn-icons-png.flaticon.com/512/733/733585.png',
        category: 'social',
        isBlocked: false,
        dailyLimitMinutes: 0,
        usedMinutesToday: 25,
        installDate: '2024-01-01',
        sizeMb: 98,
        version: '2.24.8',
        isSystemApp: false,
      },
      {
        id: 'app_minecraft',
        name: 'Minecraft',
        nameAr: 'ماين كرافت',
        packageName: 'com.mojang.minecraftpe',
        icon: 'https://cdn-icons-png.flaticon.com/512/6073/6073873.png',
        category: 'games',
        isBlocked: false,
        dailyLimitMinutes: 45,
        usedMinutesToday: 20,
        installDate: '2024-03-01',
        sizeMb: 650,
        version: '1.20.70',
        isSystemApp: false,
      },
      {
        id: 'app_duolingo',
        name: 'Duolingo',
        nameAr: 'دويولينجو',
        packageName: 'com.duolingo',
        icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968841.png',
        category: 'education',
        isBlocked: false,
        dailyLimitMinutes: 0,
        usedMinutesToday: 15,
        installDate: '2024-01-05',
        sizeMb: 85,
        version: '5.140.2',
        isSystemApp: false,
      },
      {
        id: 'app_camera',
        name: 'Camera',
        nameAr: 'الكاميرا',
        packageName: 'com.sec.android.app.camera',
        icon: 'https://cdn-icons-png.flaticon.com/512/685/685655.png',
        category: 'system',
        isBlocked: false,
        dailyLimitMinutes: 0,
        usedMinutesToday: 5,
        installDate: '2023-12-01',
        sizeMb: 45,
        version: '14.0.01',
        isSystemApp: true,
      },
      {
        id: 'app_chrome',
        name: 'Google Chrome',
        nameAr: 'جوجل كروم',
        packageName: 'com.android.chrome',
        icon: 'https://cdn-icons-png.flaticon.com/512/888/888846.png',
        category: 'utility',
        isBlocked: false,
        dailyLimitMinutes: 40,
        usedMinutesToday: 15,
        installDate: '2023-12-01',
        sizeMb: 110,
        version: '123.0.6312',
        isSystemApp: true,
      }
    ],
  },
  {
    id: 'dev_sarah_02',
    childName: 'Sarah',
    childNameAr: 'سارة',
    childAge: 9,
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    deviceName: 'iPad 10th Gen',
    platform: 'ios',
    model: 'iPad 10,9 (A2696)',
    osVersion: 'iPadOS 17.4',
    batteryLevel: 84,
    isCharging: true,
    isOnline: true,
    lastSyncTime: 'الآن (متصل)',
    screenTimeTodayMinutes: 110,
    screenTimeLimitMinutes: 180,
    currentLocation: {
      lat: 24.7180,
      lng: 46.6680,
      address: 'المنزل - حي النخيل، الرياض',
      speedKmh: 0,
      accuracyMeters: 3,
      lastUpdated: 'منذ دقيقتين',
    },
    simCarrier: 'WiFi المنزل (5GHz)',
    pairingCode: 'PG-4917',
    currentActiveApp: 'com.duolingo',
    geofenceZones: [
      {
        id: 'geo_home_sarah',
        name: 'Home Zone',
        nameAr: 'المنزل',
        lat: 24.7180,
        lng: 46.6680,
        radiusMeters: 180,
        type: 'safe',
        address: 'حي النخيل، فيلا 14',
        notifyOnEnter: true,
        notifyOnExit: true,
      }
    ],
    settings: {
      wifiEnabled: true,
      bluetoothEnabled: false,
      cellularDataEnabled: false,
      airplaneMode: false,
      gpsEnabled: true,
      hotspotEnabled: false,
      flashlightEnabled: false,
      doNotDisturb: false,
      volumeMedia: 45,
      volumeRing: 70,
      volumeAlarm: 80,
      brightness: 60,
      autoBrightness: true,
      safeSearchEnabled: true,
      installAppsBlocked: true,
      uninstallAppsBlocked: true,
      cameraBlocked: false,
      micBlocked: false,
      screenLocked: false,
      lockMessage: 'وقت القراءة والراحة، تم قفل الجهاز!',
      bedtimeStart: '20:30',
      bedtimeEnd: '07:00',
      bedtimeActive: false,
    },
    installedApps: [
      {
        id: 'app_duolingo_s',
        name: 'Duolingo ABC',
        nameAr: 'دويولينجو لتعليم القراءة',
        packageName: 'com.duolingo.abc',
        icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968841.png',
        category: 'education',
        isBlocked: false,
        dailyLimitMinutes: 0,
        usedMinutesToday: 35,
        installDate: '2024-02-01',
        sizeMb: 95,
        version: '3.1.2',
        isSystemApp: false,
      },
      {
        id: 'app_youtube_kids',
        name: 'YouTube Kids',
        nameAr: 'يوتيوب أطفال',
        packageName: 'com.google.ios.youtubekids',
        icon: 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png',
        category: 'entertainment',
        isBlocked: false,
        dailyLimitMinutes: 60,
        usedMinutesToday: 50,
        installDate: '2024-01-12',
        sizeMb: 120,
        version: '8.45.1',
        isSystemApp: false,
      },
      {
        id: 'app_drawing',
        name: 'Tayasui Sketches',
        nameAr: 'تطبيق الرسم والتلوين',
        packageName: 'com.tayasui.sketches',
        icon: 'https://cdn-icons-png.flaticon.com/512/2970/2970785.png',
        category: 'education',
        isBlocked: false,
        dailyLimitMinutes: 0,
        usedMinutesToday: 25,
        installDate: '2024-02-10',
        sizeMb: 140,
        version: '6.2.0',
        isSystemApp: false,
      }
    ]
  },
  {
    id: 'dev_omar_03',
    childName: 'Omar',
    childNameAr: 'عمر',
    childAge: 15,
    avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
    deviceName: 'iPhone 15 Pro',
    platform: 'ios',
    model: 'iPhone 16,1 (A3102)',
    osVersion: 'iOS 17.5',
    batteryLevel: 42,
    isCharging: false,
    isOnline: true,
    lastSyncTime: 'الآن (متصل)',
    screenTimeTodayMinutes: 210,
    screenTimeLimitMinutes: 300,
    currentLocation: {
      lat: 24.7290,
      lng: 46.6850,
      address: 'النادي الرياضي - شارع التخصصي، الرياض',
      speedKmh: 12,
      accuracyMeters: 5,
      lastUpdated: 'الآن',
    },
    simCarrier: 'Mobily 5G',
    pairingCode: 'PG-9124',
    currentActiveApp: 'com.apple.Maps',
    geofenceZones: [],
    settings: {
      wifiEnabled: true,
      bluetoothEnabled: true,
      cellularDataEnabled: true,
      airplaneMode: false,
      gpsEnabled: true,
      hotspotEnabled: false,
      flashlightEnabled: false,
      doNotDisturb: false,
      volumeMedia: 80,
      volumeRing: 90,
      volumeAlarm: 100,
      brightness: 85,
      autoBrightness: true,
      safeSearchEnabled: true,
      installAppsBlocked: false,
      uninstallAppsBlocked: true,
      cameraBlocked: false,
      micBlocked: false,
      screenLocked: false,
      lockMessage: 'تم تفعيل وضع الحظر الأبوي',
      bedtimeStart: '23:00',
      bedtimeEnd: '06:00',
      bedtimeActive: false,
    },
    installedApps: [
      {
        id: 'app_insta',
        name: 'Instagram',
        nameAr: 'إنستغرام',
        packageName: 'com.burbn.instagram',
        icon: 'https://cdn-icons-png.flaticon.com/512/174/174855.png',
        category: 'social',
        isBlocked: false,
        dailyLimitMinutes: 45,
        usedMinutesToday: 42,
        installDate: '2024-01-02',
        sizeMb: 195,
        version: '315.0',
        isSystemApp: false,
      }
    ]
  }
];

export const INITIAL_ALERTS: AlertNotification[] = [
  {
    id: 'alt_1',
    deviceId: 'dev_ahmed_01',
    childName: 'أحمد',
    title: 'App limit reached',
    titleAr: 'تجاوز حد استخدام التطبيق',
    message: 'Ahmed has reached the daily 30m limit for TikTok.',
    messageAr: 'استنفد أحمد الحد اليومي (30 دقيقة) المخصص لتطبيق تيك توك، تم حظر التطبيق تلقائياً.',
    timestamp: 'منذ 15 دقيقة',
    severity: 'warning',
    type: 'app_limit',
    isRead: false,
  },
  {
    id: 'alt_2',
    deviceId: 'dev_ahmed_01',
    childName: 'أحمد',
    title: 'Arrived at School',
    titleAr: 'وصل إلى المنطقة الآمنة (المدرسة)',
    message: 'Ahmed entered Horizon School geofence at 07:45 AM.',
    messageAr: 'وصل أحمد إلى مدرسة الأفق النموذجية بسلام عند الساعة 07:45 صباحاً.',
    timestamp: 'منذ ساعتين',
    severity: 'info',
    type: 'geofence',
    isRead: false,
  },
  {
    id: 'alt_3',
    deviceId: 'dev_sarah_02',
    childName: 'سارة',
    title: 'Safe Charging Connected',
    titleAr: 'تم توصيل الشاحن بأمان',
    message: 'Sarah connected iPad to charger. Battery: 84%.',
    messageAr: 'تم توصيل جهاز آيباد سارة بالشاحن. نسبة البطارية 84%.',
    timestamp: 'منذ 40 دقيقة',
    severity: 'info',
    type: 'battery',
    isRead: true,
  },
  {
    id: 'alt_4',
    deviceId: 'dev_omar_03',
    childName: 'عمر',
    title: 'High Speed Detected',
    titleAr: 'تنبيه حركة سريعة في السيارة',
    message: 'Omar is traveling at 65 km/h towards King Fahd Rd.',
    messageAr: 'تم رصد حركة بسرعة 65 كم/ساعة بالقرب من طريق الملك فهد.',
    timestamp: 'منذ 25 دقيقة',
    severity: 'warning',
    type: 'geofence',
    isRead: true,
  },
];

export const CURATED_APPS_STORE = [
  {
    id: 'store_khan',
    name: 'Khan Academy Kids',
    nameAr: 'خان أكاديمي للأطفال',
    category: 'education',
    icon: 'https://cdn-icons-png.flaticon.com/512/3976/3976625.png',
    descriptionAr: 'منهج تعليمي تفاعلي شامل في الرياضيات والقراءة والعلوم للأطفال.',
    sizeMb: 165,
    packageName: 'org.khankids.android',
  },
  {
    id: 'store_chess',
    name: 'Chess for Kids',
    nameAr: 'شطرنج للأطفال',
    category: 'games',
    icon: 'https://cdn-icons-png.flaticon.com/512/3565/3565418.png',
    descriptionAr: 'تعلم استراتيجيات وتكتيكات الشطرنج الذكية بأسلوب ممتع ومحمي.',
    sizeMb: 85,
    packageName: 'com.chess.kids',
  },
  {
    id: 'store_scratch',
    name: 'ScratchJr Coding',
    nameAr: 'سكراتش جونيور لتعليم البرمجة',
    category: 'education',
    icon: 'https://cdn-icons-png.flaticon.com/512/1006/1006771.png',
    descriptionAr: 'تطوير التفكير المنطقي وإنشاء القصص التفاعلية والألعاب البرمجية.',
    sizeMb: 95,
    packageName: 'org.scratchjr.android',
  },
  {
    id: 'store_quran',
    name: 'Quran Kids Reciter',
    nameAr: 'المصحف المعلم للأطفال',
    category: 'education',
    icon: 'https://cdn-icons-png.flaticon.com/512/2855/2855260.png',
    descriptionAr: 'تحفيظ جزء عم وترديد الآيات بصوت الشيخ المنشاوي والأطفال.',
    sizeMb: 110,
    packageName: 'com.islamic.qurankids',
  },
  {
    id: 'store_spotify_kids',
    name: 'Spotify Kids',
    nameAr: 'سبوتيفاي كيدز للقصص والأناشيد',
    category: 'entertainment',
    icon: 'https://cdn-icons-png.flaticon.com/512/2111/2111624.png',
    descriptionAr: 'موسيقى هادئة وقصص أطفال مع خلو تام من الإعلانات والمحتوى غير اللائق.',
    sizeMb: 70,
    packageName: 'com.spotify.kids',
  }
];

export const FLUTTER_CODE_SNIPPETS = {
  architecture: `
// ==========================================
// 📱 ParentGuard Flutter Cross-Platform Architecture
// Android: DevicePolicyManager + AccessibilityService
// iOS: DeviceActivityReport + FamilyControls + ManagedSettings
// Backend / Telemetry: WebSockets / Firebase Firestore Realtime
// ==========================================

lib/
├── main.dart                       # App entry point (Role selector: Parent vs Child)
├── models/
│   ├── child_device.dart           # Device schema, battery, state, geolocation
│   ├── installed_app.dart          # App package, usage time, blocked status
│   └── remote_command.dart         # Command payload (lock, toggle_wifi, mic_stream)
├── services/
│   ├── device_control_service.dart # Platform Channel router (MethodChannel)
│   ├── realtime_sync_service.dart  # WebSocket / Cloud sync for immediate commands
│   ├── camera_streaming_service.dart# WebRTC / Camera preview stream
│   └── ambient_audio_service.dart  # Audio recording & live ambient socket
├── android/
│   └── src/main/kotlin/com/parentguard/
│       ├── DeviceAdminReceiver.kt  # Lock device, wipe, password policies
│       ├── AppLockAccessibilityService.kt # Real-time app interception & block
│       └── HardwareSettingsManager.kt # WiFi, BT, Volume, Brightness native hooks
└── ios/
    └── Runner/
        ├── ScreenTimeShieldManager.swift # FamilyControls & ManagedSettings Shield
        └── LocationTrackerService.swift  # Background CoreLocation updates
`,

  mainDart: `
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'services/realtime_sync_service.dart';
import 'services/device_control_service.dart';
import 'views/parent_dashboard_screen.dart';
import 'views/child_companion_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Set preferred orientations & system UI
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);
  
  // Initialize Realtime Sync engine
  final syncService = RealtimeSyncService();
  await syncService.initialize();

  runApp(const ParentGuardApp());
}

class ParentGuardApp extends StatelessWidget {
  const ParentGuardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ParentGuard - تحكم أبوي',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Cairo',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6366F1),
          brightness: Brightness.dark,
        ),
      ),
      home: const RoleGatewayScreen(),
    );
  }
}

class RoleGatewayScreen extends StatelessWidget {
  const RoleGatewayScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.shield_rounded, size: 80, color: Color(0xFF6366F1)),
              const SizedBox(height: 16),
              const Text(
                'ParentGuard 🛡️',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const Text('اختر دور هذا الجهاز'),
              const SizedBox(height: 32),
              ElevatedButton.icon(
                icon: const Icon(Icons.supervisor_account),
                label: const Text('جهاز ولي الأمر (Parent Dashboard)'),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ParentDashboardScreen()),
                ),
              ),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                icon: const Icon(Icons.phone_android),
                label: const Text('جهاز الطفل (Child Companion)'),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ChildCompanionScreen()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
`,

  androidAdminKt: `
package com.parentguard.app

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast

class ParentGuardDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(context, "تم تفعيل صلاحيات حماية الوالدين بنجاح", Toast.LENGTH_SHORT).show()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        // Alert server if child tries to revoke admin permission
        RealtimeSyncHelper.reportAdminDisabled(context)
    }

    companion object {
        fun lockNow(context: Context) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            dpm.lockNow()
        }

        fun setCameraDisabled(context: Context, admin: ComponentName, disabled: Boolean) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            dpm.setCameraDisabled(admin, disabled)
        }
    }
}
`,

  accessibilityKt: `
package com.parentguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent

class AppBlockerAccessibilityService : AccessibilityService() {

    private val blockedPackages = mutableSetOf<String>()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGE) return
        
        val packageName = event.packageName?.toString() ?: return
        
        // Intercept blocked app opening
        if (blockedPackages.contains(packageName)) {
            // Immediately bring up Parental Lock Overlay
            val lockIntent = Intent(this, ScreenLockOverlayActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("BLOCKED_APP", packageName)
            }
            startActivity(lockIntent)
        }
    }

    override fun onInterrupt() {}
}
`,

  iosScreenTimeSwift: `
import Foundation
import DeviceActivity
import ManagedSettings
import FamilyControls

// iOS Screen Time & ManagedSettings Shield configuration
class IOSChildShieldManager {
    static let shared = IOSChildShieldManager()
    private let store = ManagedSettingsStore()

    // Request Authorization for Family Controls (Parental Consent)
    func requestAuthorization() async throws {
        try await AuthorizationCenter.shared.requestAuthorization(for: .child)
    }

    // Shield (Block) specific application tokens
    func blockApplications(tokens: Set<ApplicationToken>) {
        store.shield.applications = tokens
        store.application.denyAppRemoval = true // Prevent child from deleting apps
        store.application.denyAppInstallation = true // Prevent installing new apps
    }

    // Toggle Safari Web Filter & Safe Search
    func enforceWebFilter() {
        store.webContent.blockedByFilter = .all(except: [])
        store.media.denyExplicitContent = true
    }

    // Instant Lock device by restricting all activities
    func lockDevice() {
        store.shield.applicationCategories = .all()
    }

    func unlockDevice() {
        store.shield.applicationCategories = nil
        store.shield.applications = nil
    }
}
`
};
