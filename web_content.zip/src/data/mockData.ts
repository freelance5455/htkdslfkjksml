import { Product, Plan } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Empreendedorismo da Elite',
    slug: 'empreendedorismo-da-elite',
    description: 'Guia prático definitivo para construir negócios digitais rentáveis e escaláveis a partir de Moçambique e mercados lusófonos.',
    price: 497,
    originalPrice: 850,
    category: 'ebooks',
    type: 'digital',
    stock: 14,
    minStockAlert: 5,
    sku: 'EB-EMP-01',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 142,
    salesCount: 388,
    badge: 'Mais Vendido',
    weightOrFormat: 'PDF + Audiobook MP3 + Mockup 3D',
    features: [
      '12 Capítulos estruturados com planos de ação práticos',
      'Modelos de propostas comerciais e templates de vendas',
      'Acesso a grupo VIP exclusivo de mentoria no WhatsApp',
      'Download instantâneo após confirmação do M-Pesa / Cartão'
    ],
    digitalContentUrl: 'https://escalepay.com/downloads/ebook-empreendedorismo-elite.pdf'
  },
  {
    id: 'prod-2',
    name: 'Receitas de Culinária Moçambicana',
    slug: 'receitas-culinaria-mocambicana',
    description: 'Mais de 80 receitas tradicionais e contemporâneas com fotos em alta definição, medidas exatas e dicas de chef moçambicano.',
    price: 350,
    originalPrice: 500,
    category: 'ebooks',
    type: 'digital',
    stock: 22,
    minStockAlert: 5,
    sku: 'EB-CUL-MZ',
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 96,
    salesCount: 240,
    weightOrFormat: 'eBook Interativo PDF (184 págs)',
    features: [
      'Matapa, Caril de Amendoim, Frango à Zambeziana e Marisco',
      'Tabelas de equivalência de ingredientes locais',
      'Vídeo tutoriais passo a passo em QR Code',
      'Livro digital com índice interativo e busca facilitada'
    ],
    digitalContentUrl: 'https://escalepay.com/downloads/culinaria-mocambique-livro.pdf'
  },
  {
    id: 'prod-3',
    name: 'Curso Editor Master Jacques',
    slug: 'curso-editor-master-jacques',
    description: 'Curso completo de edição audiovisual com Premiere Pro, CapCut e After Effects para criar vídeos que retêm e convertem.',
    price: 997,
    originalPrice: 1600,
    category: 'courses_vsl',
    type: 'digital',
    stock: 7,
    minStockAlert: 4,
    sku: 'CRS-JAC-09',
    image: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=800&q=80',
    rating: 5.0,
    ratingCount: 89,
    salesCount: 164,
    badge: 'Edição Limitada',
    weightOrFormat: 'Portal de Membros + 45 Aulas HD',
    features: [
      'Pack de transições sonoras (SFX) e motion graphics de cinema',
      'Como criar anúncios e VSLs dinâmicas em menos de 30 minutos',
      'Certificado de conclusão reconhecido pelo mercado criativo',
      'Atualizações mensais de novas técnicas e tendências'
    ],
    digitalContentUrl: 'https://escalepay.com/courses/editor-master-jacques'
  },
  {
    id: 'prod-4',
    name: 'Curso de Emagrecimento, Saúde & Equilíbrio',
    slug: 'curso-emagrecimento-saude',
    description: 'Protocolo de reeducação nutricional adaptado a alimentos locais moçambicanos para perder peso de forma sustentável sem passar fome.',
    price: 497,
    originalPrice: 750,
    category: 'courses_vsl',
    type: 'digital',
    stock: 18,
    minStockAlert: 5,
    sku: 'CRS-EMAG-02',
    image: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    ratingCount: 114,
    salesCount: 312,
    weightOrFormat: 'Plano 60 Dias + Vídeo Aulas',
    features: [
      'Cardápio semanal econômico com produtos frescos do mercado',
      'Treinos funcionais de 20 minutos para fazer em casa',
      'Planilha de acompanhamento biométrico automatizada',
      'Suporte direto via comunidade no WhatsApp'
    ],
    digitalContentUrl: 'https://escalepay.com/courses/emagrecimento-saudavel'
  },
  {
    id: 'prod-5',
    name: 'Planilha Excel de Gestão Financeira Empresarial',
    slug: 'planilha-excel-financeira',
    description: 'Planilha inteligente pronta com fórmulas automáticas de fluxo de caixa, DRE gerencial, conciliação bancária e dashboard dinâmico.',
    price: 297,
    originalPrice: 450,
    category: 'spreadsheets',
    type: 'digital',
    stock: 35,
    minStockAlert: 5,
    sku: 'PL-FIN-01',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 78,
    salesCount: 420,
    weightOrFormat: 'Ficheiro .XLSX compatível com Excel & Sheets',
    features: [
      'Dashboard automático com gráficos gerenciais em tempo real',
      'Cálculo de margem de lucro, ponto de equilíbrio e tributação',
      'Suporte a múltiplas contas bancárias (BIM, BCI, M-Pesa, e-Mola)',
      'Vídeo manual explicando cada aba e funcionalidade'
    ],
    digitalContentUrl: 'https://escalepay.com/downloads/planilha-financeira-v3.xlsx'
  },
  {
    id: 'prod-6',
    name: 'Pack 100+ Capas 3D & Mockups Profissionais',
    slug: 'pack-capas-3d-mockups',
    description: 'Coleção completa de mockups editáveis no Photoshop e Canva para valorizar e empacotar infoprodutos e cursos.',
    price: 397,
    originalPrice: 650,
    category: 'covers3d',
    type: 'digital',
    stock: 4,
    minStockAlert: 5,
    sku: 'CP-3D-100',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 52,
    salesCount: 195,
    badge: 'Últimas Unidades',
    weightOrFormat: 'PSD + Templates Canva + PNG',
    features: [
      'Mockups de livros físicos, caixas de software, tablets e smartphones',
      'Resolução 4K ultra nítida para anúncios e landing pages',
      'Direitos de uso comercial irrestritos',
      'Tutoriais em vídeo de 5 minutos ensinando a personalizar'
    ],
    digitalContentUrl: 'https://escalepay.com/downloads/pack-mockups-3d.zip'
  },
  {
    id: 'prod-7',
    name: 'Kit Físico do Empreendedor Moçambicano 2026',
    slug: 'kit-fisico-empreendedor-2026',
    description: 'Caderno executivo em capa dura gravada a laser, caneta metálica personalizada, planner anual e adesivos de produtividade.',
    price: 850,
    originalPrice: 1200,
    category: 'physical',
    type: 'physical',
    stock: 12,
    minStockAlert: 5,
    sku: 'KT-FIS-01',
    image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 64,
    salesCount: 118,
    weightOrFormat: 'Embalagem rígida 650g • Envio para todo Moçambique',
    features: [
      'Encadernação artesanal de luxo em couro sintético ecológico',
      'Páginas numeradas de 100g/m² sem sangramento de tinta',
      'Entrega rápida em Maputo, Matola, Beira, Nampula e Tete',
      'Acompanha código de rastreamento de encomenda'
    ]
  },
  {
    id: 'prod-8',
    name: 'Mega Pack Criativos & Banners de Alta Conversão',
    slug: 'mega-pack-criativos-banners',
    description: 'Mais de 250 modelos prontos de anúncios para Facebook, Instagram, TikTok e banners de checkout otimizados para vendas.',
    price: 320,
    originalPrice: 550,
    category: 'ads_banners',
    type: 'digital',
    stock: 2,
    minStockAlert: 5,
    sku: 'ADS-BNR-250',
    image: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80',
    rating: 4.6,
    ratingCount: 39,
    salesCount: 180,
    badge: 'Estoque Baixo',
    weightOrFormat: 'Acesso vitalício ao Canva Pro Templates',
    features: [
      'Gatilhos visuais comprovados de retenção e cliques',
      'Formatos Story (9:16), Feed (1:1 e 4:5) e Banners Web',
      'Copywriting pré-escrito para testar títulos vencedores',
      'Economize mais de 20 horas de design gráfico'
    ],
    digitalContentUrl: 'https://escalepay.com/downloads/criativos-alta-conversao.zip'
  }
];

export const INITIAL_PLANS: Plan[] = [
  {
    id: 'plan-mini',
    name: 'Mini',
    price: 97,
    credits: 100,
    bonusCredits: 3,
    accentColor: 'slate',
    features: [
      '100 créditos (inclui +3 de bónus) — usas como quiseres, sem prazo',
      'eBooks completos com capítulos, prontos para vender',
      'Planilhas Excel com fórmulas automáticas',
      'Capas profissionais com mockup 3D',
      'Anúncios, imagens e banners de checkout',
      'Narração com voz de IA em vários idiomas e sotaques',
      'Antes de gerar, vês quantos créditos vai gastar'
    ]
  },
  {
    id: 'plan-start',
    name: 'Start',
    price: 297,
    credits: 310,
    bonusCredits: 13,
    accentColor: 'sky',
    features: [
      '310 créditos (inclui +13 de bónus) — usas como quiseres, sem prazo',
      'eBooks completos com capítulos, prontos para vender',
      'Planilhas Excel com fórmulas automáticas',
      'Capas profissionais com mockup 3D',
      'Anúncios, imagens e banners de checkout',
      'Narração com voz de IA em vários idiomas e sotaques',
      'Clona a tua própria voz nos teus anúncios e VSL',
      'Antes de gerar, vês quantos créditos vai gastar'
    ]
  },
  {
    id: 'plan-basico',
    name: 'Básico',
    price: 497,
    credits: 525,
    bonusCredits: 28,
    accentColor: 'emerald',
    features: [
      '525 créditos (inclui +28 de bónus) — usas como quiseres, sem prazo',
      'eBooks completos com capítulos, prontos para vender',
      'Planilhas Excel com fórmulas automáticas',
      'Capas profissionais com mockup 3D',
      'Anúncios, imagens e banners de checkout',
      'Narração com voz de IA em vários idiomas e sotaques',
      'Clona a tua própria voz nos teus anúncios e VSL',
      'Antes de gerar, vês quantos créditos vai gastar'
    ]
  },
  {
    id: 'plan-pro',
    name: 'Pro',
    price: 797,
    credits: 860,
    bonusCredits: 63,
    isPopular: true,
    accentColor: 'purple',
    features: [
      '860 créditos (inclui +63 de bónus) — usas como quiseres, sem prazo',
      'eBooks completos com capítulos, prontos para vender',
      'Planilhas Excel com fórmulas automáticas',
      'Capas profissionais com mockup 3D',
      'Anúncios, imagens e banners de checkout',
      'Narração com voz de IA em vários idiomas e sotaques',
      'Anúncios em vídeo e VSL com avatar falante e sincronização labial',
      'Clona a tua própria voz nos teus anúncios e VSL',
      'Antes de gerar, vês quantos créditos vai gastar'
    ]
  }
];
