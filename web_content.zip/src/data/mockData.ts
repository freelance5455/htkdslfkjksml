import { Tournament, User, Transaction, MatchResult, NotificationItem, AuditLogEntry, SupportTicket } from '../types';

export const INITIAL_USER: User = {
  id: "usr_tour_9812",
  name: "Tanvir Ahmed",
  phone: "01789234567",
  email: "tanvir.esports@gmail.com",
  ffIgn: "VIPER๛SHADOW",
  ffUid: "248910283",
  walletBalance: 350,
  winningsBalance: 240,
  depositBalance: 90,
  bonusCoins: 20,
  rankTier: "Grandmaster",
  totalKills: 142,
  matchesWon: 18,
  matchesPlayed: 46,
  avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=viper_shadow",
  role: "super_admin", // Default active session as Super Admin (App Owner X SABBIR)
  createdAt: "2026-08-14T10:00:00.000Z"
};

export const INITIAL_TOURNAMENTS: Tournament[] = [
  {
    id: "tour_ff_001",
    title: "Bermuda Grand Royale - Season 14",
    subtitle: "High Stakes Squad Showdown with 10 BDT Per Kill Bonus",
    category: "squad",
    map: "Bermuda",
    matchType: "Battle Royale",
    version: "TPP",
    scheduleTime: new Date(Date.now() + 45 * 60 * 1000).toISOString(),
    registrationDeadline: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
    entryFee: 50,
    perKill: 10,
    totalPrize: 2400,
    prizePoolStatus: "guaranteed",
    firstPrize: 1200,
    secondPrize: 600,
    thirdPrize: 300,
    prizeDistributionRules: "1st Place: ৳1200, 2nd Place: ৳600, 3rd Place: ৳300. Kill Bounty: ৳10 per kill for all participants.",
    refundRules: "100% immediate automatic refund if match is cancelled or underfilled by scheduled start time.",
    totalSlots: 48,
    bookedSlots: 41,
    status: "upcoming",
    bannerImage: "/src/assets/images/hero_tournament_banner_1793067091837.jpg",
    roomStatus: "available",
    roomId: "84729103",
    roomPassword: "889",
    roomReleaseTime: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    registeredSlots: [
      {
        slotNumber: 1,
        userId: "usr_tour_9812",
        userName: "Tanvir Ahmed",
        ffIgn: "VIPER๛SHADOW",
        ffUid: "248910283",
        teamName: "DELTA FORCE",
        teammates: [
          { ign: "VIPER๛REX", uid: "248910284" },
          { ign: "VIPER๛GHOST", uid: "248910285" },
          { ign: "VIPER๛NOVA", uid: "248910286" }
        ],
        registeredAt: new Date(Date.now() - 3600000).toISOString()
      },
      {
        slotNumber: 2,
        userId: "usr_mock_1",
        userName: "Shakil Khan",
        ffIgn: "DARK亗RAIDER",
        ffUid: "192847291",
        teamName: "SHADOW ELITE",
        teammates: [
          { ign: "DARK亗HUNTER", uid: "192847292" },
          { ign: "DARK亗ASSASSIN", uid: "192847293" },
          { ign: "DARK亗VIPER", uid: "192847294" }
        ],
        registeredAt: new Date(Date.now() - 7200000).toISOString()
      }
    ],
    rules: [
      "Room ID & Pass provided for registered players.",
      "Teaming is strictly bannable. Gun skins attributes: OFF.",
      "No hacking or third-party config files allowed.",
      "Proof screenshot must be submitted within 20 mins of match end."
    ]
  },
  {
    id: "tour_ff_002",
    title: "Clash Squad 4v4 Night Fire Cup",
    subtitle: "Fast-Paced Knockout Tournament on Bermuda CS",
    category: "clash_squad",
    map: "Bermuda",
    matchType: "Clash Squad 4v4",
    version: "TPP",
    scheduleTime: new Date(Date.now() + 110 * 60 * 1000).toISOString(),
    registrationDeadline: new Date(Date.now() + 90 * 60 * 1000).toISOString(),
    entryFee: 40,
    perKill: 5,
    totalPrize: 1600,
    prizePoolStatus: "funded",
    firstPrize: 1000,
    secondPrize: 400,
    thirdPrize: 200,
    prizeDistributionRules: "Winner takes ৳1000, Runner-up ৳400, 3rd Place ৳200. Frag bounty: ৳5 per kill.",
    refundRules: "Automatic wallet refund processed if opponent forfeits.",
    totalSlots: 16,
    bookedSlots: 12,
    status: "upcoming",
    bannerImage: "/src/assets/images/clash_squad_banner_1793067092664.jpg",
    roomStatus: "scheduled",
    roomId: "99281726",
    roomPassword: "123",
    roomReleaseTime: new Date(Date.now() + 95 * 60 * 1000).toISOString(),
    registeredSlots: [
      {
        slotNumber: 3,
        userId: "usr_mock_3",
        userName: "Arif Hossain",
        ffIgn: "TITAN亗NEXUS",
        ffUid: "558291038",
        teamName: "TEAM NEXUS",
        registeredAt: new Date(Date.now() - 5000000).toISOString()
      }
    ],
    rules: [
      "7 Rounds match format. Grenades: Standard limit (Max 2 per round).",
      "Character skills allowed. Emulator not allowed.",
      "Referee decisions are final."
    ]
  },
  {
    id: "tour_ff_003",
    title: "Kalahari Solo Survival Master",
    subtitle: "Lone Wolf Battle - Prove Your Individual Firepower",
    category: "solo",
    map: "Kalahari",
    matchType: "Battle Royale",
    version: "TPP",
    scheduleTime: new Date(Date.now() + 190 * 60 * 1000).toISOString(),
    registrationDeadline: new Date(Date.now() + 160 * 60 * 1000).toISOString(),
    entryFee: 30,
    perKill: 8,
    totalPrize: 1200,
    prizePoolStatus: "planned",
    firstPrize: 600,
    secondPrize: 300,
    thirdPrize: 150,
    prizeDistributionRules: "Top 3 survivors split ৳1050 + ৳8 per kill bounty up to ৳1200 max pool.",
    refundRules: "Full refund if fewer than 20 players register.",
    totalSlots: 48,
    bookedSlots: 29,
    status: "upcoming",
    bannerImage: "/src/assets/images/bermuda_battle_banner_1793067093629.jpg",
    roomStatus: "not_added",
    registeredSlots: [],
    rules: [
      "Solo Battle Royale on Kalahari desert map.",
      "Teaming up will result in disqualification without refund.",
      "Per kill prize credited automatically based on leaderboard."
    ]
  },
  {
    id: "tour_ff_004",
    title: "Purgatory Duo Lethal Combat",
    subtitle: "Partner Up for Tactical Domination",
    category: "duo",
    map: "Purgatory",
    matchType: "Battle Royale",
    version: "TPP",
    scheduleTime: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
    registrationDeadline: new Date(Date.now() - 50 * 60 * 1000).toISOString(),
    entryFee: 35,
    perKill: 7,
    totalPrize: 1500,
    prizePoolStatus: "guaranteed",
    firstPrize: 800,
    secondPrize: 400,
    thirdPrize: 200,
    prizeDistributionRules: "1st: ৳800, 2nd: ৳400, 3rd: ৳200, ৳7 per kill.",
    refundRules: "Standard tournament refund policy.",
    totalSlots: 24,
    bookedSlots: 24,
    status: "ongoing",
    bannerImage: "/src/assets/images/hero_tournament_banner_1793067091837.jpg",
    roomStatus: "available",
    roomId: "77182901",
    roomPassword: "441",
    roomReleaseTime: new Date(Date.now() - 50 * 60 * 1000).toISOString(),
    registeredSlots: [
      {
        slotNumber: 7,
        userId: "usr_tour_9812",
        userName: "Tanvir Ahmed",
        ffIgn: "VIPER๛SHADOW",
        ffUid: "248910283",
        teamName: "DUO LETHAL",
        teammates: [{ ign: "VIPER๛REX", uid: "248910284" }],
        registeredAt: new Date(Date.now() - 86400000).toISOString()
      }
    ],
    rules: [
      "2-player team. Revival points active.",
      "Map: Purgatory. All standard esports settings enabled."
    ]
  },
  {
    id: "tour_ff_005",
    title: "Alpine Elite Squad Championship",
    subtitle: "Completed Match - Prize Distributed to All Winners",
    category: "squad",
    map: "Alpine",
    matchType: "Battle Royale",
    version: "TPP",
    scheduleTime: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
    registrationDeadline: new Date(Date.now() - 5 * 3600 * 1000).toISOString(),
    entryFee: 50,
    perKill: 10,
    totalPrize: 2500,
    prizePoolStatus: "guaranteed",
    firstPrize: 1200,
    secondPrize: 600,
    thirdPrize: 300,
    prizeDistributionRules: "Audited payouts: ৳1200 to 1st, ৳600 to 2nd, ৳300 to 3rd.",
    refundRules: "N/A - Match completed successfully.",
    totalSlots: 48,
    bookedSlots: 48,
    status: "completed",
    bannerImage: "/src/assets/images/bermuda_battle_banner_1793067093629.jpg",
    roomStatus: "completed",
    roomId: "55192837",
    roomPassword: "782",
    registeredSlots: [],
    rules: ["Official verified results archived."]
  }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: "audit_log_100",
    timestamp: "2026-10-26T17:30:00.000Z",
    adminId: "admin_root_sabbir",
    adminName: "X SABBIR (Super Admin)",
    category: "login",
    action: "Super Admin MFA Authenticated Login",
    status: "success",
    ipAddress: "103.205.180.12"
  },
  {
    id: "audit_log_101",
    timestamp: "2026-10-26T18:00:00.000Z",
    adminId: "admin_root_sabbir",
    adminName: "X SABBIR (Super Admin)",
    category: "tournament",
    tournamentId: "tour_ff_001",
    tournamentTitle: "Bermuda Grand Royale - Season 14",
    action: "Updated Prize Pool & Guaranteed Status",
    status: "success",
    changes: [
      { field: "totalPrize", oldVal: 2000, newVal: 2400 },
      { field: "prizePoolStatus", oldVal: "planned", newVal: "guaranteed" }
    ]
  },
  {
    id: "audit_log_102",
    timestamp: "2026-10-26T18:40:00.000Z",
    adminId: "admin_root_sabbir",
    adminName: "X SABBIR (Super Admin)",
    category: "room",
    tournamentId: "tour_ff_001",
    tournamentTitle: "Bermuda Grand Royale - Season 14",
    action: "Manually Set Actual Room ID & Password",
    status: "success",
    changes: [
      { field: "roomId", oldVal: "Pending", newVal: "84729103" },
      { field: "roomPassword", oldVal: "Pending", newVal: "889" },
      { field: "roomStatus", oldVal: "scheduled", newVal: "available" }
    ]
  },
  {
    id: "audit_log_103",
    timestamp: "2026-10-26T18:55:00.000Z",
    adminId: "admin_root_sabbir",
    adminName: "X SABBIR (Super Admin)",
    category: "payment",
    action: "Verified & Approved bKash Deposit TXN_DEP_881920 (৳300)",
    status: "success"
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: "TXN_DEP_881920",
    userId: "usr_tour_9812",
    type: "deposit",
    amount: 300,
    paymentMethod: "bKash",
    trxId: "BLM982K19A",
    senderNumber: "01789234567",
    receiverNumber: "01336161980",
    status: "completed",
    timestamp: "2026-10-25T14:20:00.000Z",
    description: "bKash Send Money Deposit (TrxID: BLM982K19A)",
    balanceAfter: 450
  },
  {
    id: "TXN_ENTRY_551829",
    userId: "usr_tour_9812",
    type: "match_entry",
    amount: 50,
    paymentMethod: "Wallet",
    status: "completed",
    timestamp: "2026-10-25T18:10:00.000Z",
    description: "Entry Fee: Bermuda Grand Royale - Season 14 (Slot #1)",
    balanceAfter: 400
  },
  {
    id: "TXN_ENTRY_551830",
    userId: "usr_tour_9812",
    type: "match_entry",
    amount: 35,
    paymentMethod: "Wallet",
    status: "completed",
    timestamp: "2026-10-26T12:00:00.000Z",
    description: "Entry Fee: Purgatory Duo Lethal Combat (Slot #7)",
    balanceAfter: 365
  },
  {
    id: "TXN_PRIZE_991823",
    userId: "usr_tour_9812",
    type: "prize_winnings",
    amount: 125,
    paymentMethod: "Wallet",
    status: "completed",
    timestamp: "2026-10-26T16:30:00.000Z",
    description: "Prize Won: Alpine Elite Squad (Rank #2 + 6 Kills)",
    balanceAfter: 490
  },
  {
    id: "TXN_WTH_110293",
    userId: "usr_tour_9812",
    type: "withdrawal",
    amount: 140,
    paymentMethod: "Nagad",
    receiverNumber: "01789234567",
    status: "completed",
    timestamp: "2026-10-26T17:45:00.000Z",
    description: "Withdrawal to Nagad 01789234567 (Processed)",
    balanceAfter: 350
  }
];

export const INITIAL_RESULTS: MatchResult[] = [
  {
    id: "res_001",
    tournamentId: "tour_ff_005",
    matchTitle: "Alpine Elite Squad Championship",
    category: "Squad",
    map: "Alpine",
    completedAt: "2026-10-26T16:00:00.000Z",
    winner: {
      ign: "GHOST_REAPERS",
      teamName: "GHOST REAPERS",
      kills: 14,
      prize: 1200
    },
    mvp: {
      ign: "GHOST๛VALOR",
      kills: 8,
      headshots: 5
    },
    standings: [
      { rank: 1, ign: "GHOST๛VALOR", teamName: "GHOST REAPERS", kills: 14, prize: 1340, ffUid: "119284729" },
      { rank: 2, ign: "VIPER๛SHADOW", teamName: "DELTA FORCE", kills: 6, prize: 660, ffUid: "248910283" },
      { rank: 3, ign: "TITAN亗NEXUS", teamName: "TEAM NEXUS", kills: 4, prize: 340, ffUid: "558291038" },
      { rank: 4, ign: "DARK亗RAIDER", teamName: "SHADOW ELITE", kills: 5, prize: 50, ffUid: "192847291" },
      { rank: 5, ign: "APEX亗BLAZE", teamName: "BLAZE SQUAD", kills: 3, prize: 30, ffUid: "772819203" }
    ]
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: "notif_1",
    title: "Room ID & Password Released!",
    message: "Room credentials for Bermuda Grand Royale - Season 14 are now visible in 'My Matches'.",
    timestamp: "10 mins ago",
    type: "match",
    isRead: false,
    actionUrl: "my-matches"
  },
  {
    id: "notif_2",
    title: "Prize Credited to Wallet",
    message: "Congratulations! 125 BDT credited for Rank #2 in Alpine Elite Squad.",
    timestamp: "2 hours ago",
    type: "wallet",
    isRead: false,
    actionUrl: "wallet"
  },
  {
    id: "notif_3",
    title: "Official WhatsApp Support Available",
    message: "Need help? Official developer X SABBIR WhatsApp support is active 24/7 at 01336161980.",
    timestamp: "1 day ago",
    type: "announcement",
    isRead: true,
    actionUrl: "support"
  }
];

export const INITIAL_SUPPORT_TICKETS: SupportTicket[] = [
  {
    id: "TCK_9912",
    userId: "usr_mock_1",
    userName: "Shakil Khan",
    userPhone: "01711223344",
    category: "Deposit / Payment",
    subject: "Nagad deposit ৳200 pending for 25 minutes",
    message: "I sent ৳200 via Nagad Send Money to 01336161980 with TrxID NGD882910. Please verify and credit my wallet.",
    status: "in_progress",
    createdAt: "2026-10-26T18:15:00.000Z",
    assignedAdmin: "X SABBIR (Super Admin)",
    replies: [
      {
        sender: "user",
        text: "Please speed up, the match starts in 40 minutes!",
        time: "18:20"
      },
      {
        sender: "support",
        text: "Hello Shakil, Super Admin X SABBIR is reviewing your TrxID right now. Will be credited shortly.",
        time: "18:24"
      }
    ]
  },
  {
    id: "TCK_9913",
    userId: "usr_mock_3",
    userName: "Arif Hossain",
    userPhone: "01988776655",
    category: "Rule Violation / Anti-Cheat",
    subject: "Report: Enemy team teaming up in Duo match",
    message: "In Purgatory match, team on Slot 4 and Slot 5 did not engage each other and killed our squad together. Screenshot attached.",
    status: "open",
    createdAt: "2026-10-26T18:45:00.000Z",
    replies: []
  }
];

export const TOP_LEADERBOARD = [
  { rank: 1, name: "Tanvir Ahmed", ign: "VIPER๛SHADOW", winnings: 8450, kills: 142, matches: 46, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=viper_shadow" },
  { rank: 2, name: "Rakibul Hasan", ign: "GHOST๛VALOR", winnings: 7800, kills: 138, matches: 42, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=ghost_valor" },
  { rank: 3, name: "Mahmudul Joy", ign: "DARK亗RAIDER", winnings: 6920, kills: 121, matches: 39, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=dark_raider" },
  { rank: 4, name: "Sabbir Hossain", ign: "TITAN亗NEXUS", winnings: 5890, kills: 108, matches: 35, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=titan_nexus" },
  { rank: 5, name: "Fahim Faysal", ign: "CYBER亗STORM", winnings: 5200, kills: 99, matches: 30, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=cyber_storm" },
  { rank: 6, name: "Ahsan Habib", ign: "APEX亗BLAZE", winnings: 4750, kills: 87, matches: 28, avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=apex_blaze" }
];
