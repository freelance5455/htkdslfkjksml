import { Product, Vendor, DeliveryAddress } from '../types/ecommerce';

export const HERO_BANNER_IMG = '/src/assets/images/sewora_hero_banner_1793512630085.jpg';
export const SNEAKERS_IMG = '/src/assets/images/sewora_product_sneakers_1793512629798.jpg';

export const VENDORS: Record<string, Vendor> = {
  'v1': {
    id: 'v1',
    name: 'Aura Lifestyle Mall',
    badge: 'Mall',
    rating: 4.9,
    positiveFeedbackPercent: 98,
    shipOnTimePercent: 99,
    responseTime: '< 15 mins',
    followersCount: '48.2k',
    joinedYear: 2021,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    banner: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=800&q=80',
    vouchers: [
      { id: 'vch1', discount: 'Rs. 450 OFF', minSpend: 3500, code: 'AURA450' },
      { id: 'vch2', discount: 'Rs. 1,000 OFF', minSpend: 8000, code: 'AURA1000' }
    ]
  },
  'v2': {
    id: 'v2',
    name: 'TechZone Direct',
    badge: 'Verified',
    rating: 4.8,
    positiveFeedbackPercent: 96,
    shipOnTimePercent: 97,
    responseTime: '< 1 hour',
    followersCount: '29.4k',
    joinedYear: 2022,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    banner: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=800&q=80',
    vouchers: [
      { id: 'vch3', discount: 'Rs. 300 OFF', minSpend: 2500, code: 'TECH300' }
    ]
  },
  'v3': {
    id: 'v3',
    name: 'Elegance & Co. Global',
    badge: 'Top Seller',
    rating: 4.7,
    positiveFeedbackPercent: 94,
    shipOnTimePercent: 95,
    responseTime: '< 3 hours',
    followersCount: '15.1k',
    joinedYear: 2023,
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    banner: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=800&q=80',
    vouchers: [
      { id: 'vch4', discount: '10% OFF', minSpend: 2000, code: 'ELEGANCE10' }
    ]
  }
};

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    title: 'Sewora SpeedPro Hyper-Cushion Running Sneakers',
    category: 'Fashion',
    price: 4950,
    originalPrice: 8900,
    discountPercent: 44,
    rating: 4.9,
    reviewCount: 384,
    soldCount: '2.4k',
    images: [
      SNEAKERS_IMG,
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=600&q=80'
    ],
    colors: [
      { id: 'c1', name: 'Electric Blaze', hex: '#FF6600' },
      { id: 'c2', name: 'Obsidian Black', hex: '#0F172A' },
      { id: 'c3', name: 'Pure White', hex: '#FFFFFF' }
    ],
    sizes: ['39', '40', '41', '42', '43', '44'],
    vendorId: 'v1',
    isFlashSale: true,
    flashSoldPercent: 84,
    freeShipping: true,
    specifications: [
      { label: 'Upper Material', value: 'Breathable Engineered Knit Mesh' },
      { label: 'Midsole', value: 'Sewora Bounce-Air Nitrogen Foam' },
      { label: 'Outsole', value: 'High-traction Continental Rubber' },
      { label: 'Warranty', value: '6 Months Local Seller Warranty' }
    ],
    description: 'Engineered for maximum responsiveness and high-energy rebound. Features ultra-breathable micro-mesh upper with ergonomic arch containment, making every step effortless whether running or casual commuting.',
    reviews: [
      {
        id: 'rev-1',
        author: 'Kasun P.',
        rating: 5,
        date: '2 days ago',
        comment: 'Top tier quality! Super comfortable cushioning, the electric orange color looks even better in person than photos. Delivered in 48 hours to Colombo.',
        verifiedPurchase: true,
        variant: 'Electric Blaze / 42',
        photos: [SNEAKERS_IMG],
        likes: 24
      },
      {
        id: 'rev-2',
        author: 'Nimalee F.',
        rating: 5,
        date: '1 week ago',
        comment: 'Bought this for my gym sessions and evening jogs. True to size and zero foot pain even after 10km runs.',
        verifiedPurchase: true,
        variant: 'Pure White / 39',
        likes: 12
      }
    ]
  },
  {
    id: 'prod-2',
    title: 'Aura Sync Pro Smartwatch with AMOLED Display & Bluetooth Calling',
    category: 'Electronics',
    price: 6850,
    originalPrice: 12500,
    discountPercent: 45,
    rating: 4.8,
    reviewCount: 512,
    soldCount: '3.8k',
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80'
    ],
    colors: [
      { id: 'c1', name: 'Space Gray', hex: '#4B5563' },
      { id: 'c2', name: 'Midnight Blue', hex: '#1E3A8A' },
      { id: 'c3', name: 'Rose Gold', hex: '#F43F5E' }
    ],
    sizes: ['41mm', '45mm'],
    vendorId: 'v2',
    isFlashSale: true,
    flashSoldPercent: 92,
    freeShipping: true,
    specifications: [
      { label: 'Display', value: '1.96-inch HD AMOLED 410x502' },
      { label: 'Battery Life', value: 'Up to 10 days on single charge' },
      { label: 'Water Resistance', value: 'IP68 Certified Swim-proof' },
      { label: 'Sensors', value: 'SpO2, Heart Rate, Sleep Monitor' }
    ],
    description: 'Crisp AMOLED display with always-on technology. Dual-speaker high-fidelity Bluetooth calling, 100+ sports modes, and real-time stress and health analytics synced to the Sewora Health companion app.',
    reviews: [
      {
        id: 'rev-3',
        author: 'Dulantha M.',
        rating: 5,
        date: '3 days ago',
        comment: 'Crystal clear calls even when driving! Battery lasted 8 full days on first charge. Amazing value for this price point.',
        verifiedPurchase: true,
        variant: 'Space Gray / 45mm',
        likes: 31
      }
    ]
  },
  {
    id: 'prod-3',
    title: 'Aura SoundWave ANC Wireless Over-Ear Studio Headphones',
    category: 'Electronics',
    price: 7990,
    originalPrice: 14900,
    discountPercent: 46,
    rating: 4.9,
    reviewCount: 220,
    soldCount: '1.1k',
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=600&q=80'
    ],
    colors: [
      { id: 'c1', name: 'Matte Black', hex: '#18181B' },
      { id: 'c2', name: 'Cream Sand', hex: '#E2E8F0' }
    ],
    sizes: ['Standard'],
    vendorId: 'v2',
    isFlashSale: true,
    flashSoldPercent: 67,
    freeShipping: true,
    specifications: [
      { label: 'Noise Cancellation', value: 'Hybrid 40dB Active Noise Cancellation' },
      { label: 'Driver Size', value: '40mm Beryllium Custom Drivers' },
      { label: 'Playtime', value: '55 Hours with ANC Off, 40h ANC On' }
    ],
    description: 'Studio-grade acoustic tuning with Hi-Res Audio certification. Plush memory foam ear cups for zero fatigue during extended listening sessions.',
    reviews: []
  },
  {
    id: 'prod-4',
    title: 'Minimalist Ceramic Pour-Over Drip Coffee Maker Set',
    category: 'Home & Living',
    price: 3450,
    originalPrice: 5200,
    discountPercent: 33,
    rating: 4.7,
    reviewCount: 145,
    soldCount: '890',
    images: [
      'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=600&q=80'
    ],
    colors: [
      { id: 'c1', name: 'Terracotta Matte', hex: '#C2410C' },
      { id: 'c2', name: 'Nordic White', hex: '#F8FAFC' }
    ],
    sizes: ['600ml (2-4 Cups)'],
    vendorId: 'v3',
    isFlashSale: false,
    freeShipping: false,
    specifications: [
      { label: 'Material', value: 'Borosilicate Glass & High-fire Ceramic' },
      { label: 'Capacity', value: '600ml' }
    ],
    description: 'Handcrafted pour-over set featuring spiral ribbing for optimal extraction and clarity. Heat-resistant borosilicate glass server with wooden collar.',
    reviews: []
  },
  {
    id: 'prod-5',
    title: 'Organic Vitamin C Radiant Glow Facial Serum 30ml',
    category: 'Beauty',
    price: 2650,
    originalPrice: 4200,
    discountPercent: 37,
    rating: 4.8,
    reviewCount: 410,
    soldCount: '4.2k',
    images: [
      'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80'
    ],
    colors: [
      { id: 'c1', name: 'Original Formula', hex: '#F59E0B' }
    ],
    sizes: ['30ml', '50ml'],
    vendorId: 'v1',
    isFlashSale: false,
    freeShipping: true,
    specifications: [
      { label: 'Active Ingredients', value: '15% Ethyl Ascorbic Acid + Hyaluronic Acid' },
      { label: 'Skin Type', value: 'All skin types, sensitive friendly' }
    ],
    description: 'Stabilized Vitamin C formula that brightens hyperpigmentation and provides 24-hour hydration barrier protection without greasy residue.',
    reviews: []
  },
  {
    id: 'prod-6',
    title: 'Sewora Urban Waterproof Commuter Backpack 22L',
    category: 'Fashion',
    price: 4200,
    originalPrice: 6500,
    discountPercent: 35,
    rating: 4.6,
    reviewCount: 188,
    soldCount: '1.5k',
    images: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&q=80'
    ],
    colors: [
      { id: 'c1', name: 'Stealth Gray', hex: '#374151' },
      { id: 'c2', name: 'Navy Blue', hex: '#1E3A8A' }
    ],
    sizes: ['22L Standard'],
    vendorId: 'v3',
    isFlashSale: true,
    flashSoldPercent: 78,
    freeShipping: true,
    specifications: [
      { label: 'Laptop Sleeve', value: 'Padded fits up to 16-inch MacBook Pro' },
      { label: 'Fabric', value: 'Waterproof 900D Oxford Fabric' }
    ],
    description: 'Designed for daily city commuters with anti-theft hidden pockets, USB charging port passthrough, and ergonomic ventilated back padding.',
    reviews: []
  },
  {
    id: 'prod-7',
    title: 'SEWORA Mart Single Origin Ceylon Silver Tips BOPF Black Tea 500g',
    category: 'Groceries',
    price: 1450,
    originalPrice: 2100,
    discountPercent: 31,
    rating: 4.9,
    reviewCount: 620,
    soldCount: '5.8k',
    images: [
      'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=600&q=80'
    ],
    colors: [
      { id: 'c1', name: 'Loose Leaf 500g Tin', hex: '#78350F' }
    ],
    sizes: ['500g Foil Pack', '1kg Value Tin'],
    vendorId: 'v1',
    isFlashSale: true,
    flashSoldPercent: 88,
    freeShipping: true,
    specifications: [
      { label: 'Origin', value: 'Nuwara Eliya High Elevation (6,000 ft)' },
      { label: 'Grade', value: 'BOPF Premium Broken Orange Pekoe Fannings' },
      { label: 'Expiry', value: '24 Months Sealed' }
    ],
    description: 'Freshly harvested single-origin Ceylon highland tea with signature amber liquor and fragrant brisk character. Vacuum foil sealed for utmost garden freshness.',
    reviews: []
  },
  {
    id: 'prod-8',
    title: 'SEWORA Mart Premium Fragrant Long Grain Basmati Rice 5kg Pack',
    category: 'Groceries',
    price: 2950,
    originalPrice: 3800,
    discountPercent: 22,
    rating: 4.8,
    reviewCount: 390,
    soldCount: '4.1k',
    images: [
      'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80'
    ],
    colors: [
      { id: 'c1', name: 'Royal White Grain', hex: '#FEF3C7' }
    ],
    sizes: ['5kg Sealed Bag', '10kg Family Sack'],
    vendorId: 'v1',
    isFlashSale: false,
    freeShipping: true,
    specifications: [
      { label: 'Grain Length', value: '8.4mm Extra Long Aged Grain' },
      { label: 'Aroma', value: 'Naturally Aged Fragrant Aroma' },
      { label: 'Net Weight', value: '5 kg' }
    ],
    description: 'Naturally aged for two full years to guarantee delicate fluffy texture and zero sticking when steamed. Perfect for authentic biryanis and everyday family meals.',
    reviews: []
  },
  {
    id: 'prod-9',
    title: 'SEWORA Mart Cold-Pressed Organic Extra Virgin Olive Oil 750ml',
    category: 'Groceries',
    price: 3650,
    originalPrice: 4800,
    discountPercent: 24,
    rating: 4.9,
    reviewCount: 195,
    soldCount: '1.2k',
    images: [
      'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80'
    ],
    colors: [
      { id: 'c1', name: 'Dark Glass Bottle', hex: '#166534' }
    ],
    sizes: ['750ml Dark UV Glass'],
    vendorId: 'v3',
    isFlashSale: false,
    freeShipping: false,
    specifications: [
      { label: 'Acidity', value: '< 0.3% First Cold Extraction' },
      { label: 'Certifications', value: '100% USDA & EU Organic' }
    ],
    description: 'First cold-pressed single estate extra virgin olive oil. Robust polyphenols, peppery finish, and rich healthy monounsaturated fats.',
    reviews: []
  }
];

export const CATEGORIES = [
  { id: 'all', name: 'All Mart Deals', icon: 'Sparkles', color: '#FF6600' },
  { id: 'Groceries', name: 'Sewora Mart Fresh', icon: 'ShoppingBag', color: '#16A34A' },
  { id: 'Electronics', name: 'Electronics & Tech', icon: 'Smartphone', color: '#2563EB' },
  { id: 'Fashion', name: 'Fashion & Wear', icon: 'Shirt', color: '#DB2777' },
  { id: 'Beauty', name: 'Health & Beauty', icon: 'HeartHandshake', color: '#059669' },
  { id: 'Home & Living', name: 'Home & Living', icon: 'Home', color: '#7C3AED' },
  { id: 'Sports', name: 'Sports & Outdoors', icon: 'Trophy', color: '#EA580C' },
  { id: 'Global', name: 'Global Direct', icon: 'Globe', color: '#0891B2' }
];

export const WHATSAPP_SUPPORT_NUMBER = '+94771234567';
export const WHATSAPP_DISPLAY_NUMBER = '+94 77 123 4567';

export const DEFAULT_ADDRESSES: DeliveryAddress[] = [
  {
    id: 'addr-1',
    name: 'Kasun Perera',
    phone: '+94 77 123 4567',
    addressLine: 'No. 42, Galle Road, Bambalapitiya',
    city: 'Colombo 04',
    postalCode: '00400',
    isDefault: true,
    label: 'Home'
  },
  {
    id: 'addr-2',
    name: 'Kasun Perera (Tech Dept)',
    phone: '+94 71 987 6543',
    addressLine: 'Floor 8, World Trade Center, Echelon Square',
    city: 'Colombo 01',
    postalCode: '00100',
    isDefault: false,
    label: 'Office'
  }
];

export const INITIAL_ORDERS = [
  {
    id: 'ord-101',
    orderNumber: 'SEW-918231',
    date: 'Oct 28, 2026',
    status: 'Delivered' as const,
    trackingNumber: 'LK-EXP-4820194',
    totalAmount: 5300,
    paymentMethod: 'Cash on Delivery',
    address: DEFAULT_ADDRESSES[0],
    items: [
      {
        id: 'ord-item-1',
        product: SAMPLE_PRODUCTS[0],
        selectedColor: 'Electric Blaze',
        selectedSize: '42',
        quantity: 1,
        selected: true
      }
    ]
  },
  {
    id: 'ord-102',
    orderNumber: 'SEW-849202',
    date: 'Oct 30, 2026',
    status: 'Out for Delivery' as const,
    trackingNumber: 'LK-EXP-7729104',
    totalAmount: 7200,
    paymentMethod: 'Visa Card (Ending 4242)',
    address: DEFAULT_ADDRESSES[0],
    items: [
      {
        id: 'ord-item-2',
        product: SAMPLE_PRODUCTS[1],
        selectedColor: 'Space Gray',
        selectedSize: '45mm',
        quantity: 1,
        selected: true
      }
    ]
  },
  {
    id: 'ord-103',
    orderNumber: 'SEW-739110',
    date: 'Oct 31, 2026',
    status: 'Processing' as const,
    trackingNumber: 'LK-EXP-9920194',
    totalAmount: 5100,
    paymentMethod: 'Mobile Wallet (FriMi)',
    address: DEFAULT_ADDRESSES[1],
    items: [
      {
        id: 'ord-item-3',
        product: SAMPLE_PRODUCTS[6], // Tea
        selectedColor: 'Loose Leaf 500g Tin',
        selectedSize: '500g Foil Pack',
        quantity: 2,
        selected: true
      }
    ]
  }
];
