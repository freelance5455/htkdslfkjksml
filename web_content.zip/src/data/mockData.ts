import {
  User,
  Provider,
  DeliveryPartner,
  CategoryMeta,
  ServiceItem,
  RideVehicleOption,
  Order,
  ChatSession,
  ChatMessage,
  AdminConfig,
  WithdrawalRequest,
  SafetyIncidentReport,
  AppNotification
} from '../types';

export const INITIAL_ADMIN_CONFIG: AdminConfig = {
  platformCommissionDefaults: {
    food: 18,
    grocery: 10,
    ride: 12,
    home_service: 15,
    salon: 20,
    massage: 20,
    electrician: 15,
    plumber: 15,
    repair: 15,
    cleaning: 18,
    courier: 10,
    artists: 12,
    custom: 15
  },
  chatRules: {
    freeMessageLimit: 5,
    unlockFee: 29, // ₹29 for unlimited chat on this job
    allowPaidChat: true,
    providerChatSharePercent: 50 // 50% goes to provider
  },
  deliveryRules: {
    baseFare: 30,
    perKmRate: 8,
    freeDeliveryOver: 499,
    platformFeePerOrder: 5
  },
  safetyHelpline: '1800-ALLJI-SAFE (1800-255-5472)',
  policeHelpline: '112',
  womenHelpline: '1091'
};

export const CATEGORIES: CategoryMeta[] = [
  { id: 'food', title: 'Food Delivery', subtitle: 'Restaurants & treats', icon: 'Utensils', color: 'from-amber-500 to-orange-600', badge: '30 Min', commissionPercent: 18 },
  { id: 'grocery', title: 'Grocery Delivery', subtitle: 'Fresh daily essentials', icon: 'ShoppingBag', color: 'from-emerald-500 to-green-600', badge: '12 Min', commissionPercent: 10 },
  { id: 'ride', title: 'Cab & Bike Ride', subtitle: 'Auto, Cabs & Bikes', icon: 'Car', color: 'from-yellow-400 to-amber-600', badge: 'Instant', commissionPercent: 12 },
  { id: 'electrician', title: 'Electrician', subtitle: 'Wiring, MCB & fittings', icon: 'Zap', color: 'from-blue-500 to-indigo-600', badge: 'Verified', commissionPercent: 15 },
  { id: 'plumber', title: 'Plumber', subtitle: 'Leaks, pipes & tanks', icon: 'Wrench', color: 'from-cyan-500 to-blue-600', badge: 'Expert', commissionPercent: 15 },
  { id: 'repair', title: 'Appliance Repair', subtitle: 'AC, Fridge, RO & TV', icon: 'Cpu', color: 'from-teal-500 to-emerald-700', badge: 'Warranty', commissionPercent: 15 },
  { id: 'cleaning', title: 'Cleaning Services', subtitle: 'Home, Sofa & Kitchen', icon: 'Sparkles', color: 'from-sky-400 to-blue-600', badge: 'Popular', commissionPercent: 18 },
  { id: 'salon', title: 'Salon & Beauty', subtitle: 'Haircut, facial & grooming', icon: 'Scissors', color: 'from-pink-500 to-rose-600', badge: 'At Home', commissionPercent: 20 },
  { id: 'massage', title: 'Massage & Spa', subtitle: 'Ayurvedic & relaxation', icon: 'HeartHandshake', color: 'from-purple-500 to-indigo-600', badge: 'Certified', commissionPercent: 20 },
  { id: 'courier', title: 'Parcel & Courier', subtitle: 'Send packages anywhere', icon: 'Package', color: 'from-violet-500 to-purple-700', badge: 'Live Track', commissionPercent: 10 },
  { id: 'home_service', title: 'Home Services', subtitle: 'Carpentry, Paint & Pest', icon: 'Home', color: 'from-lime-500 to-emerald-600', badge: 'Trusted', commissionPercent: 15 },
  { id: 'artists', title: 'Artists & Experts', subtitle: 'Photographers, Mehndi, Tutors', icon: 'Palette', color: 'from-fuchsia-500 to-rose-500', badge: 'Creative', commissionPercent: 12 }
];

export const MOCK_USERS: User[] = [
  {
    id: 'u_customer_1',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@example.com',
    phone: '+91 98765 43210',
    role: 'customer',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    walletBalance: 850,
    savedAddresses: [
      {
        id: 'addr_1',
        label: 'Home',
        street: 'Flat 402, Lotus Towers, Golf Course Road',
        locality: 'DLF Phase 5',
        city: 'Gurugram',
        pincode: '122002',
        coordinates: { lat: 28.4595, lng: 77.0266 },
        isDefault: true
      },
      {
        id: 'addr_2',
        label: 'Work',
        street: 'Cyber City, Tower B, 8th Floor',
        locality: 'DLF Cyber City',
        city: 'Gurugram',
        pincode: '122008',
        coordinates: { lat: 28.4908, lng: 77.0906 }
      }
    ],
    emergencyContacts: [
      { id: 'ec_1', name: 'Sunita Sharma (Mother)', phone: '+91 98111 22334', relation: 'Parent' },
      { id: 'ec_2', name: 'Rohit Sharma (Brother)', phone: '+91 98222 33445', relation: 'Sibling' }
    ],
    createdAt: '2026-01-10T10:00:00Z'
  },
  {
    id: 'u_provider_1',
    name: 'Rajesh Verma',
    email: 'rajesh.verma@allji.in',
    phone: '+91 98100 11223',
    role: 'provider',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    walletBalance: 4250,
    savedAddresses: [],
    emergencyContacts: [],
    createdAt: '2026-02-01T08:30:00Z'
  },
  {
    id: 'u_delivery_1',
    name: 'Vikram Singh',
    email: 'vikram.delivery@allji.in',
    phone: '+91 97188 55443',
    role: 'delivery',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    walletBalance: 1200,
    savedAddresses: [],
    emergencyContacts: [],
    createdAt: '2026-02-15T09:00:00Z'
  },
  {
    id: 'u_admin_1',
    name: 'Super Admin',
    email: 'admin@allji.com',
    phone: '+91 99999 00000',
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    walletBalance: 250000,
    savedAddresses: [],
    emergencyContacts: [],
    createdAt: '2025-12-01T00:00:00Z'
  }
];

export const MOCK_PROVIDERS: Provider[] = [
  {
    id: 'prov_1',
    userId: 'u_provider_1',
    businessName: 'Verma Electrical & Tech Solutions',
    category: 'electrician',
    description: 'Licensed Master Electrician with 12+ years experience in domestic & commercial rewiring, inverter, switches & appliance setup.',
    experienceYears: 12,
    rating: 4.8,
    reviewCount: 312,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&auto=format&fit=crop&q=80',
    serviceRadiusKm: 15,
    serviceCity: 'Gurugram',
    isOnline: true,
    isVerified: true,
    kycStatus: 'verified',
    documents: [
      { idProofType: 'Aadhaar', documentNumber: 'XXXX-XXXX-8912', documentUrl: 'aadhaar_verified.pdf', submittedAt: '2026-02-02' },
      { idProofType: 'TradeLicense', documentNumber: 'ELEC-DL-2024-991', documentUrl: 'cert_elec.pdf', submittedAt: '2026-02-03' }
    ],
    pricingStartsAt: 199,
    commissionPercentage: 15,
    customServices: [
      {
        id: 'cserv_1',
        categoryId: 'electrician',
        title: 'Emergency Short Circuit Troubleshooting',
        description: 'Instant root-cause detection and urgent breaker isolation with safety testing.',
        price: 399,
        durationMinutes: 45,
        imageUrl: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=300&auto=format&fit=crop&q=80',
        rating: 4.9,
        unit: 'visit'
      }
    ],
    earnings: {
      total: 38400,
      withdrawn: 34150,
      pendingPayout: 4250
    },
    phone: '+91 98100 11223'
  },
  {
    id: 'prov_2',
    userId: 'u_prov_2',
    businessName: 'Royal Dawat Biryani & Kebabs',
    category: 'food',
    description: 'Authentic Dum Biryani, Mughlai Gravies, and charcoal-grilled Kebabs prepared with pure Desi Ghee.',
    experienceYears: 8,
    rating: 4.6,
    reviewCount: 1420,
    avatar: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=150&auto=format&fit=crop&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop&q=80',
    serviceRadiusKm: 10,
    serviceCity: 'Gurugram',
    isOnline: true,
    isVerified: true,
    kycStatus: 'verified',
    documents: [
      { idProofType: 'TradeLicense', documentNumber: 'FSSAI-11223344556677', documentUrl: 'fssai_cert.pdf', submittedAt: '2026-01-15' }
    ],
    pricingStartsAt: 249,
    commissionPercentage: 18,
    customServices: [],
    earnings: {
      total: 185000,
      withdrawn: 162000,
      pendingPayout: 23000
    },
    phone: '+91 98100 99881'
  },
  {
    id: 'prov_3',
    userId: 'u_prov_3',
    businessName: 'QuickKart Daily Grocery Superstore',
    category: 'grocery',
    description: 'Farm-fresh organic fruits, vegetables, dairy, farm eggs, baking essentials, and snacks with 15-minute dispatch.',
    experienceYears: 4,
    rating: 4.7,
    reviewCount: 890,
    avatar: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=150&auto=format&fit=crop&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=800&auto=format&fit=crop&q=80',
    serviceRadiusKm: 8,
    serviceCity: 'Gurugram',
    isOnline: true,
    isVerified: true,
    kycStatus: 'verified',
    documents: [],
    pricingStartsAt: 49,
    commissionPercentage: 10,
    customServices: [],
    earnings: {
      total: 94000,
      withdrawn: 82000,
      pendingPayout: 12000
    },
    phone: '+91 98111 88776'
  },
  {
    id: 'prov_4',
    userId: 'u_prov_4',
    businessName: 'Glow & Grace Mobile Salon',
    category: 'salon',
    description: 'Hygienic single-use kits, branded products (L’Oreal, O3+), expert salon therapists at your doorstep.',
    experienceYears: 6,
    rating: 4.9,
    reviewCount: 540,
    avatar: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=150&auto=format&fit=crop&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop&q=80',
    serviceRadiusKm: 12,
    serviceCity: 'Gurugram',
    isOnline: true,
    isVerified: true,
    kycStatus: 'verified',
    documents: [],
    pricingStartsAt: 399,
    commissionPercentage: 20,
    customServices: [],
    earnings: {
      total: 45000,
      withdrawn: 38000,
      pendingPayout: 7000
    },
    phone: '+91 98711 44552'
  },
  {
    id: 'prov_5',
    userId: 'u_prov_5',
    businessName: 'FixMaster Cooling & Appliance Experts',
    category: 'repair',
    description: 'AC deep jet servicing, PCB repair, gas charging, washing machine & microwave repairs with 60-day warranty.',
    experienceYears: 9,
    rating: 4.8,
    reviewCount: 420,
    avatar: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=150&auto=format&fit=crop&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&auto=format&fit=crop&q=80',
    serviceRadiusKm: 20,
    serviceCity: 'Gurugram',
    isOnline: true,
    isVerified: true,
    kycStatus: 'verified',
    documents: [],
    pricingStartsAt: 299,
    commissionPercentage: 15,
    customServices: [],
    earnings: {
      total: 62000,
      withdrawn: 51000,
      pendingPayout: 11000
    },
    phone: '+91 98199 66774'
  },
  {
    id: 'prov_6',
    userId: 'u_prov_6',
    businessName: 'Pratibha Mehendi & Wedding Art',
    category: 'artists',
    description: 'Award-winning bridal henna, organic Rajasthani cone, portrait mehndi and festive party styling.',
    experienceYears: 7,
    rating: 4.9,
    reviewCount: 280,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    bannerImage: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=800&auto=format&fit=crop&q=80',
    serviceRadiusKm: 25,
    serviceCity: 'Gurugram',
    isOnline: true,
    isVerified: true,
    kycStatus: 'verified',
    documents: [],
    pricingStartsAt: 999,
    commissionPercentage: 12,
    customServices: [],
    earnings: {
      total: 31000,
      withdrawn: 26000,
      pendingPayout: 5000
    },
    phone: '+91 98123 77889'
  }
];

export const MOCK_DELIVERY_PARTNERS: DeliveryPartner[] = [
  {
    id: 'deliv_1',
    userId: 'u_delivery_1',
    name: 'Vikram Singh',
    phone: '+91 97188 55443',
    vehicleType: 'EV_Bike',
    vehicleNumber: 'HR-26-EQ-8819',
    isOnline: true,
    currentLocation: {
      lat: 28.4620,
      lng: 77.0310,
      locality: 'Sector 42, Gurugram'
    },
    rating: 4.9,
    totalDeliveries: 1240,
    walletBalance: 1200,
    activeOrderId: 'ord_101',
    kycStatus: 'verified'
  },
  {
    id: 'deliv_2',
    userId: 'u_deliv_2',
    name: 'Manoj Yadav',
    phone: '+91 98112 33441',
    vehicleType: 'Bike',
    vehicleNumber: 'DL-04-AB-4321',
    isOnline: true,
    currentLocation: {
      lat: 28.4750,
      lng: 77.0520,
      locality: 'Sushant Lok 1, Gurugram'
    },
    rating: 4.7,
    totalDeliveries: 820,
    walletBalance: 840,
    kycStatus: 'verified'
  }
];

export const RIDE_VEHICLE_OPTIONS: RideVehicleOption[] = [
  {
    id: 'auto',
    title: 'AllJi Auto',
    capacity: 3,
    baseFare: 35,
    perKmRate: 11,
    etaMinutes: 3,
    icon: 'Zap',
    description: 'Pocket-friendly rides with door-to-door auto drivers'
  },
  {
    id: 'bike',
    title: 'AllJi Moto / Bike',
    capacity: 1,
    baseFare: 20,
    perKmRate: 8,
    etaMinutes: 2,
    icon: 'Bike',
    description: 'Beat city traffic fast with sanitized helmet provided'
  },
  {
    id: 'mini',
    title: 'AllJi Mini (Hatchback)',
    capacity: 4,
    baseFare: 60,
    perKmRate: 14,
    etaMinutes: 4,
    icon: 'Car',
    description: 'Comfortable AC hatchbacks for everyday city commutes'
  },
  {
    id: 'sedan',
    title: 'AllJi Prime Sedan',
    capacity: 4,
    baseFare: 90,
    perKmRate: 17,
    etaMinutes: 6,
    icon: 'ShieldCheck',
    description: 'Spacious sedans with top rated drivers & extra legroom'
  },
  {
    id: 'suv',
    title: 'AllJi Prime SUV XL',
    capacity: 6,
    baseFare: 140,
    perKmRate: 22,
    etaMinutes: 8,
    icon: 'Users',
    description: '6-seater premium SUVs for family trips and luggage'
  }
];

export const ALL_SERVICES: ServiceItem[] = [
  // Food
  {
    id: 'food_1',
    categoryId: 'food',
    providerId: 'prov_2',
    title: 'Hyderabadi Dum Chicken Biryani',
    description: 'Slow cooked aromatic basmati rice layered with succulent spiced chicken, saffron, mint and fried onions. Served with Mirchi ka Salan and creamy Raita.',
    price: 349,
    discountPrice: 299,
    imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400&auto=format&fit=crop&q=80',
    isVeg: false,
    rating: 4.8,
    tags: ['Bestseller', 'Mughlai', 'Spicy'],
    options: [
      { name: 'Portion', choices: [{ label: 'Regular (Serves 1)', price: 0 }, { label: 'Large (Serves 2)', price: 180 }] },
      { name: 'Spice Level', choices: [{ label: 'Medium Desi', price: 0 }, { label: 'Extra Spicy', price: 0 }] }
    ]
  },
  {
    id: 'food_2',
    categoryId: 'food',
    providerId: 'prov_2',
    title: 'Paneer Butter Masala & Garlic Naan',
    description: 'Cottage cheese cubes bathed in rich cashew-tomato velvet gravy, paired with 2 hot butter garlic naans.',
    price: 310,
    discountPrice: 269,
    imageUrl: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400&auto=format&fit=crop&q=80',
    isVeg: true,
    rating: 4.7,
    tags: ['Pure Veg', 'North Indian']
  },
  {
    id: 'food_3',
    categoryId: 'food',
    providerId: 'prov_2',
    title: 'Crispy Butter Masala Dosa',
    description: 'Golden fermented crepe stuffed with spiced potato masala, served with piping hot sambar and fresh coconut chutney.',
    price: 189,
    discountPrice: 159,
    imageUrl: 'https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=400&auto=format&fit=crop&q=80',
    isVeg: true,
    rating: 4.6,
    tags: ['South Indian', 'Breakfast']
  },
  {
    id: 'food_4',
    categoryId: 'food',
    providerId: 'prov_2',
    title: 'Gulab Jamun with Rabri (2 Pcs)',
    description: 'Warm melt-in-mouth milk dumplings soaked in cardamom sugar syrup, topped with slow-reduced creamy rabri.',
    price: 140,
    imageUrl: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=400&auto=format&fit=crop&q=80',
    isVeg: true,
    rating: 4.9,
    tags: ['Dessert']
  },

  // Grocery
  {
    id: 'groc_1',
    categoryId: 'grocery',
    providerId: 'prov_3',
    title: 'Aashirvaad Shudh Chakki Atta',
    description: '100% whole wheat grain atta with 0% maida for soft rotis.',
    price: 245,
    discountPrice: 220,
    unit: '5 kg pack',
    imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&auto=format&fit=crop&q=80',
    rating: 4.8,
    tags: ['Staples', 'Super Saver']
  },
  {
    id: 'groc_2',
    categoryId: 'grocery',
    providerId: 'prov_3',
    title: 'Amul Taaza Homogenised Toned Milk',
    description: 'Nutritious pasteurized toned milk, rich in calcium and protein.',
    price: 68,
    unit: '1 L Tetra',
    imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    tags: ['Dairy', 'Daily Need']
  },
  {
    id: 'groc_3',
    categoryId: 'grocery',
    providerId: 'prov_3',
    title: 'Fresh Farm Tomatoes (Desi)',
    description: 'Naturally ripened, tangy and fresh farm harvested tomatoes.',
    price: 45,
    discountPrice: 38,
    unit: '1 kg',
    imageUrl: 'https://images.unsplash.com/photo-1546470427-e26264be0b11?w=400&auto=format&fit=crop&q=80',
    rating: 4.7,
    tags: ['Vegetables']
  },
  {
    id: 'groc_4',
    categoryId: 'grocery',
    providerId: 'prov_3',
    title: 'Shimla Royal Apple Box',
    description: 'Crisp, sweet and juicy premium handpicked mountain apples.',
    price: 180,
    discountPrice: 159,
    unit: '1 kg (4-5 pcs)',
    imageUrl: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400&auto=format&fit=crop&q=80',
    rating: 4.8,
    tags: ['Fruits', 'Fresh']
  },

  // Electrician
  {
    id: 'elec_1',
    categoryId: 'electrician',
    providerId: 'prov_1',
    title: 'Ceiling Fan Installation & Uninstallation',
    description: 'Complete ceiling fan assembly, balancing, downrod setup, and wiring with safety regulator connection.',
    price: 199,
    durationMinutes: 30,
    imageUrl: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400&auto=format&fit=crop&q=80',
    rating: 4.8,
    unit: 'fan'
  },
  {
    id: 'elec_2',
    categoryId: 'electrician',
    providerId: 'prov_1',
    title: 'MCB Tripping & Switchboard Repair',
    description: 'Repair burned switches, replace MCB, fix fuse tripping or burnt wiring safely.',
    price: 249,
    durationMinutes: 45,
    imageUrl: 'https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    unit: 'inspection'
  },

  // Plumber
  {
    id: 'plumb_1',
    categoryId: 'plumber',
    title: 'Tap Leakage & Mixer Faucet Repair',
    description: 'Fix dripping taps, replace faulty washer, cartridge, or install brand-new brass mixer taps.',
    price: 179,
    durationMinutes: 35,
    imageUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=400&auto=format&fit=crop&q=80',
    rating: 4.7,
    unit: 'tap'
  },
  {
    id: 'plumb_2',
    categoryId: 'plumber',
    title: 'Overhead Water Tank Deep Cleaning',
    description: 'Multi-stage mechanized cleaning with sludge pump, antibacterial spray, and UV sanitization.',
    price: 699,
    durationMinutes: 90,
    imageUrl: 'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    unit: 'tank (up to 1000L)'
  },

  // Repair
  {
    id: 'rep_1',
    categoryId: 'repair',
    providerId: 'prov_5',
    title: 'Split AC Foam Jet Deep Servicing',
    description: '2x deeper cooling power foam wash of indoor cooling coils, blower wheel, drain tray & outdoor condenser jet clean.',
    price: 499,
    discountPrice: 449,
    durationMinutes: 60,
    imageUrl: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    unit: 'per AC unit'
  },
  {
    id: 'rep_2',
    categoryId: 'repair',
    providerId: 'prov_5',
    title: 'Refrigerator Cooling & Gas Refill Check',
    description: 'Comprehensive diagnosis for defrosting issues, compressor humming, temperature thermostat, or refrigerant gas leak.',
    price: 349,
    durationMinutes: 45,
    imageUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=400&auto=format&fit=crop&q=80',
    rating: 4.8,
    unit: 'inspection'
  },

  // Cleaning
  {
    id: 'clean_1',
    categoryId: 'cleaning',
    title: 'Full Home Deep Cleaning (2 BHK / 3 BHK)',
    description: 'Intense 6-hour deep cleaning: Floor buffing, balcony wash, window glass grime removal, kitchen degreasing, bathroom descaling.',
    price: 2499,
    discountPrice: 2199,
    durationMinutes: 300,
    imageUrl: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400&auto=format&fit=crop&q=80',
    rating: 4.8,
    unit: 'apartment'
  },
  {
    id: 'clean_2',
    categoryId: 'cleaning',
    title: 'Sofa Fabric Shampooing & Extraction',
    description: 'Mechanized foam extraction to remove stubborn food stains, allergens, dust mites, and pet odors.',
    price: 799,
    durationMinutes: 75,
    imageUrl: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    unit: '3-seater'
  },

  // Salon & Beauty
  {
    id: 'sal_1',
    categoryId: 'salon',
    providerId: 'prov_4',
    title: 'Men’s Grooming: Haircut + Beard Styling + Head Massage',
    description: 'Premium cut tailored to face shape, precision beard fade, and 15-min cooling almond oil head massage.',
    price: 449,
    discountPrice: 399,
    durationMinutes: 50,
    imageUrl: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    unit: 'package'
  },
  {
    id: 'sal_2',
    categoryId: 'salon',
    providerId: 'prov_4',
    title: 'O3+ Bridal Glow Facial & De-Tan Therapy',
    description: 'Instantly brightens dull skin, deep pore cleanup, diamond peel mask, and gentle skin rejuvenation.',
    price: 1299,
    discountPrice: 1099,
    durationMinutes: 75,
    imageUrl: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    unit: 'session'
  },

  // Massage
  {
    id: 'mass_1',
    categoryId: 'massage',
    title: 'Ayurvedic Herbal Potli & Warm Oil Therapy',
    description: 'Traditional healing with heated herbal pouches soaked in medicated sesame oil for joint stiffness and muscle recovery.',
    price: 1499,
    durationMinutes: 60,
    imageUrl: 'https://images.unsplash.com/photo-1600334089648-b0d9d3028eb2?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    unit: 'session'
  },

  // Courier
  {
    id: 'cour_1',
    categoryId: 'courier',
    title: 'Instant City Express Parcel Drop',
    description: 'Send keys, documents, lunchbox, gifts, or gadgets anywhere in the city within 45 minutes by bike courier.',
    price: 49,
    imageUrl: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=400&auto=format&fit=crop&q=80',
    rating: 4.8,
    unit: 'per trip'
  },

  // Home Services
  {
    id: 'home_1',
    categoryId: 'home_service',
    title: 'Wall Painting & Waterproofing Patch Work',
    description: 'Smooth putty prep, damp proofing primer, and two coats of washable luxury interior emulsion.',
    price: 1499,
    durationMinutes: 180,
    imageUrl: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=400&auto=format&fit=crop&q=80',
    rating: 4.8,
    unit: 'room'
  },

  // Artists & Professionals
  {
    id: 'art_1',
    categoryId: 'artists',
    providerId: 'prov_6',
    title: 'Bridal Henna / Designer Mehndi',
    description: 'Intricate Rajasthani, Arabic, and personalized bridal story henna with 100% natural dark stain organic cones.',
    price: 2499,
    durationMinutes: 120,
    imageUrl: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    unit: 'both hands'
  },
  {
    id: 'art_2',
    categoryId: 'artists',
    title: 'Birthday & Portrait Candid Photographer',
    description: 'Professional Sony Alpha full-frame setup, 2 hours shooting, 50 edited high-res digital photos.',
    price: 3499,
    durationMinutes: 120,
    imageUrl: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&auto=format&fit=crop&q=80',
    rating: 4.9,
    unit: '2 hrs session'
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord_101',
    orderNumber: 'ALLJI-98421',
    customerId: 'u_customer_1',
    customerName: 'Aarav Sharma',
    customerPhone: '+91 98765 43210',
    category: 'food',
    providerId: 'prov_2',
    providerName: 'Royal Dawat Biryani & Kebabs',
    deliveryPartnerId: 'deliv_1',
    deliveryPartnerName: 'Vikram Singh',
    deliveryPartnerPhone: '+91 97188 55443',
    items: [
      {
        serviceId: 'food_1',
        title: 'Hyderabadi Dum Chicken Biryani',
        quantity: 1,
        price: 299,
        selectedOptions: ['Regular (Serves 1)', 'Medium Desi']
      },
      {
        serviceId: 'food_4',
        title: 'Gulab Jamun with Rabri (2 Pcs)',
        quantity: 1,
        price: 140
      }
    ],
    deliveryAddress: {
      id: 'addr_1',
      label: 'Home',
      street: 'Flat 402, Lotus Towers, Golf Course Road',
      locality: 'DLF Phase 5',
      city: 'Gurugram',
      pincode: '122002'
    },
    itemTotal: 439,
    deliveryFee: 30,
    platformFee: 5,
    taxes: 22,
    discount: 50,
    grandTotal: 446,
    paymentMethod: 'upi',
    paymentStatus: 'paid',
    status: 'out_for_delivery',
    eta: '14 mins',
    deliveryOtp: '7482',
    createdAt: new Date(Date.now() - 25 * 60000).toISOString()
  },
  {
    id: 'ord_102',
    orderNumber: 'ALLJI-94112',
    customerId: 'u_customer_1',
    customerName: 'Aarav Sharma',
    customerPhone: '+91 98765 43210',
    category: 'electrician',
    providerId: 'prov_1',
    providerName: 'Verma Electrical & Tech Solutions',
    items: [
      {
        serviceId: 'elec_1',
        title: 'Ceiling Fan Installation & Uninstallation',
        quantity: 1,
        price: 199
      }
    ],
    scheduledSlot: 'Today, 04:00 PM - 05:00 PM',
    deliveryAddress: {
      id: 'addr_1',
      label: 'Home',
      street: 'Flat 402, Lotus Towers, Golf Course Road',
      locality: 'DLF Phase 5',
      city: 'Gurugram',
      pincode: '122002'
    },
    itemTotal: 199,
    deliveryFee: 0,
    platformFee: 5,
    taxes: 10,
    discount: 0,
    grandTotal: 214,
    paymentMethod: 'cash',
    paymentStatus: 'pending',
    status: 'accepted',
    eta: 'Arriving at 4:00 PM',
    deliveryOtp: '3910',
    createdAt: new Date(Date.now() - 2 * 3600000).toISOString()
  }
];

export const INITIAL_CHAT_SESSIONS: ChatSession[] = [
  {
    id: 'chat_1',
    orderId: 'ord_101',
    customerId: 'u_customer_1',
    customerName: 'Aarav Sharma',
    participantId: 'deliv_1',
    participantName: 'Vikram Singh (Delivery Partner)',
    participantRole: 'delivery',
    freeMessagesAllowed: 5,
    freeMessagesUsed: 3,
    isPaidUnlocked: false,
    paidUnlockPrice: 29,
    lastMessage: 'Ji bhaiya, main society gate number 2 par aa gaya hoon.',
    updatedAt: new Date(Date.now() - 5 * 60000).toISOString()
  },
  {
    id: 'chat_2',
    orderId: 'ord_102',
    customerId: 'u_customer_1',
    customerName: 'Aarav Sharma',
    participantId: 'prov_1',
    participantName: 'Rajesh Verma (Electrician)',
    participantRole: 'provider',
    freeMessagesAllowed: 5,
    freeMessagesUsed: 1,
    isPaidUnlocked: false,
    paidUnlockPrice: 29,
    lastMessage: 'Namaste sir, main naya fan regulator bhi sath la raha hoon.',
    updatedAt: new Date(Date.now() - 60 * 60000).toISOString()
  }
];

export const INITIAL_CHAT_MESSAGES: Record<string, ChatMessage[]> = {
  chat_1: [
    {
      id: 'msg_1',
      sessionId: 'chat_1',
      senderId: 'system',
      senderRole: 'admin',
      senderName: 'AllJi Assistant',
      text: 'Order #ALLJI-98421 placed. Delivery partner Vikram Singh assigned. (You have 5 free chat messages with the rider).',
      timestamp: new Date(Date.now() - 20 * 60000).toISOString(),
      isSystem: true
    },
    {
      id: 'msg_2',
      sessionId: 'chat_1',
      senderId: 'u_customer_1',
      senderRole: 'customer',
      senderName: 'Aarav Sharma',
      text: 'Bhaiya, extra green chutney and napkins packet me add karwa dena please!',
      timestamp: new Date(Date.now() - 15 * 60000).toISOString()
    },
    {
      id: 'msg_3',
      sessionId: 'chat_1',
      senderId: 'deliv_1',
      senderRole: 'delivery',
      senderName: 'Vikram Singh',
      text: 'Haanji sir, chef se bolkar pack karwa diya hai, bas 10 min me pahuch raha hoon.',
      timestamp: new Date(Date.now() - 10 * 60000).toISOString()
    },
    {
      id: 'msg_4',
      sessionId: 'chat_1',
      senderId: 'deliv_1',
      senderRole: 'delivery',
      senderName: 'Vikram Singh',
      text: 'Ji bhaiya, main society gate number 2 par aa gaya hoon.',
      timestamp: new Date(Date.now() - 5 * 60000).toISOString()
    }
  ],
  chat_2: [
    {
      id: 'msg_201',
      sessionId: 'chat_2',
      senderId: 'u_customer_1',
      senderRole: 'customer',
      senderName: 'Aarav Sharma',
      text: 'Bhaiya, ek naya 5-step anchor fan regulator bhi le aana please.',
      timestamp: new Date(Date.now() - 70 * 60000).toISOString()
    },
    {
      id: 'msg_202',
      sessionId: 'chat_2',
      senderId: 'prov_1',
      senderRole: 'provider',
      senderName: 'Rajesh Verma',
      text: 'Namaste sir, main naya fan regulator bhi sath la raha hoon.',
      timestamp: new Date(Date.now() - 60 * 60000).toISOString()
    }
  ]
};

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif_1',
    userId: 'u_customer_1',
    title: 'Order is on the way! 🛵',
    message: 'Vikram is 1.2 km away with your Hyderabadi Biryani. Share delivery OTP: 7482.',
    type: 'order',
    read: false,
    timestamp: '5 mins ago',
    linkId: 'ord_101'
  },
  {
    id: 'notif_2',
    userId: 'u_customer_1',
    title: 'Flat ₹50 Cashback on UPI 💰',
    message: 'Use code ALLJIUPI on any grocery or home service booking today!',
    type: 'promo',
    read: true,
    timestamp: '2 hours ago'
  }
];

export const INITIAL_WITHDRAWALS: WithdrawalRequest[] = [
  {
    id: 'w_1',
    providerId: 'prov_1',
    providerName: 'Verma Electrical & Tech Solutions',
    amount: 3500,
    bankAccount: 'HDFC Bank - A/C **9182',
    ifscOrUpi: 'HDFC0001234',
    status: 'approved',
    requestedAt: '2026-03-10T14:20:00Z',
    processedAt: '2026-03-10T16:00:00Z'
  },
  {
    id: 'w_2',
    providerId: 'prov_2',
    providerName: 'Royal Dawat Biryani & Kebabs',
    amount: 15000,
    bankAccount: 'ICICI Bank - A/C **4411',
    ifscOrUpi: 'ICIC0000987',
    status: 'pending',
    requestedAt: '2026-03-16T18:40:00Z'
  }
];

export const INITIAL_SAFETY_INCIDENTS: SafetyIncidentReport[] = [
  {
    id: 'safe_1',
    userId: 'u_customer_1',
    userName: 'Aarav Sharma',
    userPhone: '+91 98765 43210',
    orderId: 'ord_101',
    location: 'Near Sector 42 Rapid Metro, Gurugram',
    coordinates: { lat: 28.4620, lng: 77.0310 },
    emergencyType: 'safety',
    status: 'resolved',
    timestamp: '2026-03-14T21:10:00Z',
    notes: 'Precautionary location check-in during late evening delivery. Rider and customer confirmed safe.'
  }
];
