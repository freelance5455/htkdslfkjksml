import { Exercise } from '../types';

export const INITIAL_EXERCISES: Exercise[] = [
  // ==================== PULL ====================
  {
    id: 'pull-up',
    name: 'Pull-Up',
    category: 'pull',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'The definitive upper body vertical pulling movement for lat and bicep power.',
    instructions: [
      'Grip the bar overhand slightly wider than shoulder-width.',
      'Engage scapular retractors and depress your shoulders.',
      'Drive elbows down towards hips until chin clearly clears the bar.',
      'Lower under complete control back to a dead hang.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Latissimus Dorsi', 'Biceps', 'Rhomboids', 'Forearms']
  },
  {
    id: 'chin-up',
    name: 'Chin-Up',
    category: 'pull',
    difficulty: 'beginner',
    equipment: 'pull-up bar',
    description: 'Underhand vertical pull emphasizing heavy bicep recruitment and lower lat engagement.',
    instructions: [
      'Grip the bar supinated (palms facing you) shoulder-width apart.',
      'Pull your chest up toward the bar, keeping core braced.',
      'Touch your upper chest to the bar or pull chin well above.',
      'Control the eccentric lowering phase for 2 full seconds.'
    ],
    progressionLevel: 2,
    defaultReps: 10,
    targetMuscles: ['Biceps', 'Lats', 'Brachialis', 'Upper Back']
  },
  {
    id: 'wide-grip-pull-up',
    name: 'Wide-Grip Pull-Up',
    category: 'pull',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'Wide grip hand placement that maximizes lat sweep and decreases bicep leverage.',
    instructions: [
      'Take a grip 1.5x shoulder width on the bar.',
      'Focus strictly on pulling through your elbows, driving them downward and back.',
      'Maintain hollow body posture without swinging your legs.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Latissimus Dorsi (Outer)', 'Teres Major', 'Posterior Deltoid']
  },
  {
    id: 'close-grip-pull-up',
    name: 'Close-Grip Pull-Up',
    category: 'pull',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'Narrow overhand grip requiring high forearm stabilization and center back squeeze.',
    instructions: [
      'Place hands 4-6 inches apart on the bar with overhand grip.',
      'Pull up with elbows tucked inward, bringing sternum close to hands.',
      'Squeeze mid-back at apex, then descend smoothly.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Lats', 'Lower Traps', 'Brachioradialis', 'Biceps']
  },
  {
    id: 'neutral-grip-pull-up',
    name: 'Neutral-Grip Pull-Up',
    category: 'pull',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'Palms-facing-each-other pull that is joint-friendly on shoulders and builds brachialis thickness.',
    instructions: [
      'Grip parallel handles on pull-up bar or rings.',
      'Pull up driving chest between hands.',
      'Pause for 1 second at top contraction before full extension.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Brachialis', 'Lats', 'Rhomboids', 'Forearms']
  },
  {
    id: 'archer-pull-up',
    name: 'Archer Pull-Up',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Asymmetric unilateral pull where one arm does the primary load while the other assists outstretched.',
    instructions: [
      'Grip very wide. Pull your body up toward one hand.',
      'Straighten the opposite arm completely along the bar like an archer.',
      'Lock out at the working hand, then shift or lower smoothly and alternate.'
    ],
    progressionLevel: 5,
    defaultReps: 4,
    targetMuscles: ['Unilateral Lats', 'One-Arm Bicep', 'Rotator Cuff', 'Forearms']
  },
  {
    id: 'commando-pull-up',
    name: 'Commando Pull-Up',
    category: 'pull',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'Standing sideways beneath the bar with mixed staggered grip, pulling head alternatively to each side.',
    instructions: [
      'Stand parallel directly beneath the bar.',
      'Grip with one hand overhand and other underhand along the bar.',
      'Pull up, tilting head to one side of the bar at top, alternate side next rep.'
    ],
    progressionLevel: 4,
    defaultReps: 8,
    targetMuscles: ['Obliques', 'Lats', 'Biceps', 'Core Stability']
  },
  {
    id: 'typewriter-pull-up',
    name: 'Typewriter Pull-Up',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Pull to top height, then slide horizontally from hand to hand while remaining locked at chin level.',
    instructions: [
      'Pull up to top chest height.',
      'Keeping chin high above bar, slide horizontally across to the right hand.',
      'Slide horizontally back across to the left hand, then lower down.'
    ],
    progressionLevel: 5,
    defaultReps: 4,
    targetMuscles: ['Upper Back Endurance', 'Forearms', 'Core Lockout', 'Biceps']
  },
  {
    id: 'explosive-pull-up',
    name: 'Explosive Pull-Up',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'High-velocity pull driving the chest or belly button to bar height for muscle-up power.',
    instructions: [
      'Start in active dead hang.',
      'Pull explosively with maximum acceleration, driving elbows forcefully down and back.',
      'Aim to touch lower rib cage or naval to the bar level.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Fast-Twitch Lats', 'Biceps', 'Rear Delts', 'Core']
  },
  {
    id: 'australian-pull-up',
    name: 'Australian Pull-Up (Inverted Row)',
    category: 'pull',
    difficulty: 'beginner',
    equipment: 'pull-up bar',
    description: 'Horizontal bodyweight row that builds essential scapular retraction and posture base.',
    instructions: [
      'Hang underneath waist-height bar or rings with heels on floor.',
      'Keep body in a rigid straight plank line.',
      'Retract shoulder blades and pull chest up to touch the bar.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Rhomboids', 'Mid Traps', 'Rear Deltoids', 'Biceps']
  },
  {
    id: 'straight-bar-dip',
    name: 'Straight Bar Dip (Muscle-Up Progression)',
    category: 'pull',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'Key top-half movement of the muscle-up performed over a single horizontal bar.',
    instructions: [
      'Support yourself at the top of a pull-up bar with straight arms.',
      'Lean chest slightly forward over the bar to balance center of gravity.',
      'Descend until lower chest touches the bar, then press back up.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Triceps', 'Lower Chest', 'Anterior Delts', 'Core']
  },
  {
    id: 'muscle-up-strict',
    name: 'Strict Bar Muscle-Up',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'The crown calisthenics movement combining explosive high pull, rapid transition, and straight bar dip.',
    instructions: [
      'Establish a solid false grip or high overhand grip on bar.',
      'Pull high and fast, driving sternum over the bar.',
      'Rotate wrists and lean chest forward to transition into dip position.',
      'Press out smoothly into full lockout above the bar.'
    ],
    progressionLevel: 5,
    defaultReps: 3,
    targetMuscles: ['Lats', 'Triceps', 'Chest', 'Shoulders', 'Forearms']
  },

  // ==================== PUSH ====================
  {
    id: 'wall-push-up',
    name: 'Wall Push-Up',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Joint-friendly standing incline press against a wall to build initial pushing patterns, scapular control, and elbow tendon readiness.',
    instructions: [
      'Stand facing a wall about arm-length away with feet hip-width apart.',
      'Place palms flat against the wall at shoulder height and shoulder-width apart.',
      'Brace your core and glutes, bending elbows at a 45-degree angle to bring your chest and nose toward the wall.',
      'Push firmly through your palms back to full arm extension with scapular protraction.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Anterior Deltoid', 'Serratus Anterior']
  },
  {
    id: 'incline-push-up',
    name: 'Incline Push-Up (Hands Elevated)',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Hands elevated on a bench, box, chair, or low bar to reduce bodyweight leverage and emphasize the lower-to-mid sternal chest and triceps.',
    instructions: [
      'Place hands slightly wider than shoulder-width on a sturdy elevated surface (bench, box, or step).',
      'Step feet back into a straight hollow-body plank from head to heels.',
      'Lower your lower sternum to the edge of the elevated surface with elbows tucked at 45 degrees.',
      'Press forcefully back to full lockout while keeping your core rigid.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Pectoralis Major (Lower & Sternal)', 'Triceps Brachii', 'Anterior Deltoid', 'Core']
  },
  {
    id: 'knee-push-up',
    name: 'Knee Push-Up',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Modified floor push-up pivoting from the knees to master full chest-to-floor range of motion with reduced load.',
    instructions: [
      'Kneel on a mat and place hands shoulder-width apart on the floor.',
      'Maintain a straight line from the crown of your head through your hips to your knees—do not hinge at the waist.',
      'Lower your chest until it lightly touches the floor with elbows tracking back at 45 degrees.',
      'Drive through your palms to full lockout.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Anterior Deltoid', 'Core']
  },
  {
    id: 'negative-push-up',
    name: 'Eccentric (Negative) Push-Up',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Slow 5-second lowering phase from a full plank to build rapid pushing strength and tendon resilience for strict push-ups.',
    instructions: [
      'Start in a strong high plank position with arms locked and shoulder blades protracted.',
      'Brace abs and glutes, then lower your body toward the floor over a strict 4-to-5 second count.',
      'Keep elbows tucked at 45 degrees and prevent hips from sagging.',
      'Once chest touches the floor, reset to the top via your knees and repeat.'
    ],
    progressionLevel: 1,
    defaultReps: 8,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Anterior Deltoid', 'Core']
  },
  {
    id: 'scapular-push-up',
    name: 'Scapular Push-Up (Serratus Protraction)',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Straight-arm scapular isolation movement training shoulder blade protraction and retraction for bulletproof shoulders and planche prep.',
    instructions: [
      'Assume a high push-up plank with elbows locked completely straight.',
      'Without bending your elbows, allow your chest to sink slightly as your shoulder blades pinch together (retraction).',
      'Push the floor away forcefully to dome your upper back and spread your shoulder blades wide apart (protraction).',
      'Hold peak protraction for 1-2 seconds on every rep.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Serratus Anterior', 'Pectoralis Minor', 'Anterior Deltoid', 'Core']
  },
  {
    id: 'hand-release-push-up',
    name: 'Hand-Release Dead-Stop Push-Up',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Full-range push-up pausing on the floor to lift both palms at the bottom, eliminating stretch reflex and building raw concentric pressing power.',
    instructions: [
      'Lower from a rigid plank until your chest, torso, and thighs rest briefly on the floor.',
      'Lift both hands 1-2 inches off the floor while squeezing your upper back.',
      'Plant palms back down, brace your core hard, and press your entire body up as one solid unit.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Anterior Deltoid', 'Rhomboids', 'Core']
  },
  {
    id: 'push-up',
    name: 'Standard Push-Up',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'The foundation of upper-body pushing mechanics, chest development, and core stability.',
    instructions: [
      'Place hands shoulder-width apart, fingers slightly flared.',
      'Lock core, glutes, and quadriceps in a rigid hollow plank.',
      'Lower chest until 1 inch off floor with elbows at 45-degree angle.',
      'Push through palms and protract shoulder blades at the top.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Anterior Deltoid', 'Core']
  },
  {
    id: 'push-up-plus',
    name: 'Push-Up Plus (Protracted Top Lockout)',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Standard full-range push-up finished with an extra upward scapular protraction push at the top to maximize serratus anterior activation.',
    instructions: [
      'Perform a clean chest-to-floor push-up with elbows at 45 degrees.',
      'Upon reaching elbow lockout, push the floor away an extra 2 inches to round your upper back into hollow protraction.',
      'Hold the top protracted position for 1 full second before descending into the next rep.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Serratus Anterior', 'Pectoralis Major', 'Triceps', 'Anterior Deltoid']
  },
  {
    id: 'wide-push-up',
    name: 'Wide-Grip Push-Up',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Wide hand placement putting elevated stretch and mechanical tension on the outer pectoral fibers and front delts.',
    instructions: [
      'Position hands approximately 1.5x to 1.75x shoulder width apart with fingers angled slightly outward.',
      'Lower chest slowly to feel a deep outer pectoral stretch.',
      'Press back up smoothly, squeezing your chest toward the midline at lockout.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Outer Pectorals', 'Anterior Deltoid', 'Serratus Anterior']
  },
  {
    id: 'close-push-up',
    name: 'Close-Grip Push-Up (Military Push-Up)',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Hands placed narrow beneath the shoulders with elbows skimming tightly along the ribs to heavily load the triceps and inner chest.',
    instructions: [
      'Set hands directly beneath or slightly narrower than your shoulder joints.',
      'Descend under strict control while keeping your elbows glued tightly against your ribcage.',
      'Touch lower chest to thumb level, then drive straight up focusing on pure tricep extension.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Triceps Brachii', 'Anterior Deltoid', 'Inner Chest', 'Core']
  },
  {
    id: 'diamond-push-up',
    name: 'Diamond Push-Up',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Index fingers and thumbs touching or closely spaced in a diamond shape under the sternum for intense tricep and inner pectoral overload.',
    instructions: [
      'Form a triangle or diamond with thumbs and index fingers directly under your sternum.',
      'Keep elbows tucked close to your ribcage throughout the descent.',
      'Lower until chest touches the backs of your hands, then lock triceps completely at the top.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Triceps Lateral & Medial Heads', 'Inner Chest', 'Anterior Deltoid', 'Core']
  },
  {
    id: 'decline-push-up',
    name: 'Decline Push-Up (Feet Elevated)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Feet elevated on a chair, box, or bench, shifting a higher percentage of bodyweight onto the clavicular upper chest and anterior deltoids.',
    instructions: [
      'Place toes on an elevated surface (12 to 24 inches high).',
      'Maintain a rigid hollow-body line without letting your lower back arch or hips sag.',
      'Lower upper chest and chin toward the floor, then press powerfully back to lockout.'
    ],
    progressionLevel: 3,
    defaultReps: 12,
    targetMuscles: ['Clavicular Upper Chest', 'Anterior Deltoid', 'Triceps', 'Core']
  },
  {
    id: 'deep-deficit-push-up',
    name: 'Deep Deficit Push-Up (Parallettes / Books)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Hands elevated on parallettes, push-up handles, or stacks of books to allow the chest to descend below palm level for an extreme pectoral stretch.',
    instructions: [
      'Grip parallettes or place palms on two equal stacks of books shoulder-width apart.',
      'Lower your torso slowly until your chest drops 2-4 inches deeper than the level of your hands.',
      'Pause for 1 second in the deep bottom stretch while keeping shoulders packed.',
      'Drive forcefully back up to full protracted lockout.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Pectoralis Major (Deep Stretch)', 'Anterior Deltoid', 'Triceps', 'Serratus Anterior']
  },
  {
    id: 'staggered-push-up',
    name: 'Staggered-Stance Push-Up (Uneven Hands)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Asymmetric hand placement with one hand positioned forward at shoulder level and the other back near the ribs to train unilateral chest and tricep drive.',
    instructions: [
      'Start in a push-up plank and slide one hand 6 inches forward and the other hand 6 inches backward toward your lower ribs.',
      'Keep your elbows tucked and lower your chest evenly to the floor.',
      'Push back up, feeling increased tricep and front-delt load on the lower hand.',
      'Switch hand positions halfway through the set or alternate each set.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Pectoralis Major', 'Triceps Brachii', 'Anterior Deltoid', 'Core Anti-Rotation']
  },
  {
    id: 'reverse-grip-push-up',
    name: 'Reverse-Grip (Supinated) Push-Up',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Fingers rotated backward toward the toes (supinated wrists) to heavily recruit the anterior deltoids, upper clavicular chest, and biceps tendons.',
    instructions: [
      'Place hands on the floor shoulder-width apart with fingers pointing backward toward your feet (or angled 135-180 degrees outward).',
      'Lean your shoulders slightly forward and keep elbows tucked tightly against your sides.',
      'Lower your chest under strict control, feeling tension in your biceps tendons and upper chest.',
      'Press smoothly back to full elbow extension.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Anterior Deltoid', 'Clavicular Upper Chest', 'Biceps Brachii', 'Triceps', 'Forearms']
  },
  {
    id: 'knuckle-push-up',
    name: 'Knuckle (Fist) Push-Up',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Performed on clenched fists with neutral straight wrists to forge iron wrist stability, forearm co-contraction, and slightly deeper range of motion.',
    instructions: [
      'Make tight fists and support your weight on your index and middle knuckles with wrists locked completely straight.',
      'Set hands shoulder-width apart and elbows tucked at 30-45 degrees.',
      'Lower chest until it nearly touches the floor between your fists, then press cleanly to lockout.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Forearms & Wrist Stabilizers', 'Anterior Deltoid']
  },
  {
    id: 'fingertip-push-up',
    name: 'Fingertip Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Old-school calisthenics feat supporting your entire body weight on arched fingertips to build steel finger tendons and crushing grip strength.',
    instructions: [
      'Spread your fingers wide and arch your knuckles in a dome/claw shape so only your finger pads touch the floor.',
      'Do not let your finger joints hyperextend or collapse flat.',
      'Lower your chest smoothly toward the floor while maintaining active finger tension, then press to the top.'
    ],
    progressionLevel: 4,
    defaultReps: 8,
    targetMuscles: ['Finger Flexors & Forearms', 'Pectoralis Major', 'Triceps', 'Anterior Deltoid'],
    safetyNote: 'Progress gradually from knees or an incline if your finger tendons are new to fingertip loading.'
  },
  {
    id: 'wrist-dorsal-push-up',
    name: 'Back-of-Wrist (Dorsal) Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Push-up performed on the backs of the hands with wrists flexed inward, conditioning wrist extensors and false-grip tendon resilience.',
    instructions: [
      'Fold your wrists inward so the dorsal (back) surfaces of your hands rest on a padded mat with fingers pointing toward each other.',
      'Keep your fists tightly balled to stabilize the wrist joint.',
      'Lower chest under control and press back up while maintaining tight fist tension.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Forearm Extensors & Wrists', 'Triceps', 'Pectoralis Major', 'Anterior Deltoid'],
    safetyNote: 'Perform on a yoga mat or carpet and master kneeling dorsal push-ups first before full plank reps.'
  },
  {
    id: 'cobra-push-up',
    name: 'Cobra Tricep Push-Up',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Prone press keeping hips grounded while extending the torso upward with tucked elbows to isolate the triceps and mobilize the lumbar/thoracic spine.',
    instructions: [
      'Lie face down with palms planted beneath your shoulders and elbows tucked tight to your ribs.',
      'Keeping your pelvis and legs relaxed on the floor, press through your palms to lift your chest and torso upward.',
      'Squeeze your triceps hard at the top without shrugging your shoulders, then lower slowly.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Triceps Brachii', 'Pectoralis Major', 'Rectus Abdominis (Stretch)', 'Lower Back']
  },
  {
    id: 'hindu-push-up',
    name: 'Hindu Push-Up (Dand)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Traditional dynamic wrestling push-up swooping from a high downward-dog pike into an arched upward-dog press before pushing hips back to pike.',
    instructions: [
      'Start in a wide-stance downward dog (inverted V pike) with hips high and heels reaching toward the floor.',
      'Bend your elbows and swoop your nose, chest, and torso low along the floor in a smooth circular arc.',
      'Press your chest up into an arched upward-dog position with arms locked and hips hovering above the floor.',
      'Push through your shoulders to drive your hips straight back up into the starting pike.'
    ],
    progressionLevel: 3,
    defaultReps: 12,
    targetMuscles: ['Anterior Deltoids', 'Pectoralis Major', 'Triceps', 'Serratus Anterior', 'Erector Spinae']
  },
  {
    id: 'dive-bomber-push-up',
    name: 'Dive-Bomber Push-Up (Two-Way Scoop)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Stricter two-way variation of the Hindu push-up where you reverse the exact low-skimming arc back under an imaginary fence to return to the pike.',
    instructions: [
      'Start in a high pike position with feet shoulder-width apart.',
      'Dive your head and chest downward and forward as if ducking underneath a low bar until you press into an upward-dog arch.',
      'Instead of hiking your hips straight up, bend your elbows and reverse the exact low path backward along the floor into the high pike.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Anterior Deltoids', 'Triceps Brachii', 'Clavicular & Sternal Chest', 'Core']
  },
  {
    id: 'mike-tyson-push-up',
    name: 'Mike Tyson Push-Up (Loaded Pike-Squat Press)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Explosive boxing conditioning push-up sitting hips back onto heels in a loadedhorizontal squat before rocketing forward into a deep push-up.',
    instructions: [
      'Brace your feet against a wall (optional for traction) in a push-up plank.',
      'Push through your palms to sit your glutes all the way back toward your heels with knees hovering off the floor and arms extended overhead.',
      'Drive explosively forward with your legs into a low plank and drop immediately into a chest-to-floor push-up.',
      'Press up and push straight back into the loaded crouch.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Pectoralis Major', 'Anterior Deltoids', 'Triceps', 'Quadriceps', 'Core']
  },
  {
    id: 'spiderman-push-up',
    name: 'Spiderman (Oblique Crunch) Push-Up',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Dynamic push-up driving one knee laterally up to touch the same-side elbow at the bottom of each rep for intense chest and oblique integration.',
    instructions: [
      'Begin in a standard push-up plank.',
      'As you lower your chest toward the floor, lift one foot and drive your knee out to the side to touch your elbow.',
      'Press back up to the top while returning your foot to plank, then alternate legs on the next rep.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'External & Internal Obliques', 'Hip Flexors']
  },
  {
    id: 't-rotation-push-up',
    name: 'Push-Up to Side Plank (T-Push-Up)',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Full push-up followed by a 90-degree thoracic rotation into a single-arm side plank to build shoulder stability and rotational core strength.',
    instructions: [
      'Perform a full chest-to-floor push-up.',
      'At the top, pivot onto the edges of your feet and rotate your torso to one side, reaching your top arm straight toward the ceiling in a T-shape.',
      'Pause for 1 second with stacked shoulders, return to plank, and rotate to the opposite side on the next rep.'
    ],
    progressionLevel: 2,
    defaultReps: 10,
    targetMuscles: ['Pectoralis Major', 'Anterior & Posterior Deltoids', 'Obliques', 'Triceps']
  },
  {
    id: 'iso-bottom-hold-push-up',
    name: 'Bottom-Hold Isometric Push-Up (90° Hover)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Static time-under-tension hold hovering 1 inch off the floor with elbows at 90 degrees to forge extreme bottom-position pressing strength.',
    instructions: [
      'Lower from a high plank until your chest hovers 1 inch above the floor and your elbows are bent at 90 degrees.',
      'Keep your elbows tucked at 45 degrees, glutes squeezed, and body completely parallel to the floor.',
      'Breathe steadily while holding the hover without resting your chest on the ground.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 25,
    targetMuscles: ['Pectoralis Major', 'Anterior Deltoid', 'Triceps Brachii', 'Core']
  },
  {
    id: 'sphinx-push-up',
    name: 'Sphinx Push-Up (Tiger-Bend Tricep Extension)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Plank tricep extension dropping both forearms flat to the floor and pressing strictly through the palms to isolate all three heads of the triceps.',
    instructions: [
      'Start in a forearm plank with elbows directly under shoulders and palms flat on the floor.',
      'Or start in a high plank with hands positioned slightly forward of your shoulders.',
      'Keeping elbows tucked narrow in line with your wrists, press through your palms to lift both elbows off the floor into full lockout.',
      'Lower both elbows smoothly back to touch the floor simultaneously.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Triceps Brachii (Long, Lateral & Medial Heads)', 'Core', 'Serratus Anterior']
  },
  {
    id: 'bodyweight-tricep-extension',
    name: 'Bodyweight Tricep Extension (Bar / Bench Skullcrusher)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Hands on a low bar, bench, or table edge, bending at the elbows to tuck the head beneath the hands for surgical long-head tricep hypertrophy.',
    instructions: [
      'Grip a waist-to-knee-height bar, bench edge, or sturdy table with a shoulder-width overhand grip.',
      'Step feet back into an angled plank with arms extended.',
      'Keeping your upper arms fixed and elbows tucked inward, bend only at the elbows until your forehead passes beneath your hands.',
      'Extend your forearms forcefully to return to full lockout.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Triceps Long & Medial Heads', 'Core', 'Latissimus Dorsi (Stabilizer)']
  },
  {
    id: 'cross-arm-tricep-push-up',
    name: 'Cross-Arm (X-Grip) Tricep Push-Up',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Forearms crossed in an X beneath the chest, pressing from the outer edges of the palms outward to isolate the lateral horseshoe head of the triceps.',
    instructions: [
      'Assume a plank and cross your forearms in front of you so your right hand rests on the left side and left hand on the right side.',
      'Lower your chest toward the intersection of your forearms.',
      'Push outward and downward through your palms to extend your elbows.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Triceps Lateral Head', 'Inner Pectorals', 'Anterior Deltoid']
  },
  {
    id: 'incline-pike-push-up',
    name: 'Incline Pike Push-Up (Hands Elevated)',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Entry-level overhead vertical push with hands elevated on a bench or step and hips hinged high into a pike.',
    instructions: [
      'Place hands shoulder-width apart on a sturdy box, bench, or step.',
      'Walk feet in and hinge at the hips to form an inverted V-shape with your torso and legs.',
      'Lower the crown of your head diagonally forward toward the front edge of the bench.',
      'Press up and back until your ears align between your biceps.'
    ],
    progressionLevel: 2,
    defaultReps: 10,
    targetMuscles: ['Anterior Deltoids', 'Triceps', 'Upper Trapezius', 'Clavicular Chest']
  },
  {
    id: 'pike-push-up',
    name: 'Pike Push-Up',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Hips folded high in an inverted V-shape, serving as the foundational bodyweight overhead press for handstand push-ups.',
    instructions: [
      'Hike hips high in the air, creating a sharp upside-down V with your body.',
      'Shift weight onto hands, gazing slightly in front of fingertips.',
      'Lower head diagonally forward into a tripod shape, then press overhead back into pike.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Anterior Deltoids', 'Triceps', 'Upper Traps', 'Serratus Anterior']
  },
  {
    id: 'elevated-pike-push-up',
    name: 'Elevated Pike Push-Up (Feet on Box / Chair)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Feet elevated on a box or chair with torso stacked vertically at 90 degrees over the hands to closely replicate full handstand push-up mechanics.',
    instructions: [
      'Place your toes or shins on a chair or box and walk your hands backward until your torso is nearly vertical.',
      'Tuck your elbows at a 45-degree angle and lean your head forward in front of your fingertips to form an equilateral tripod.',
      'Touch the top of your head lightly to the floor, then press vertically into full overhead scapular elevation.'
    ],
    progressionLevel: 4,
    defaultReps: 8,
    targetMuscles: ['Anterior & Lateral Deltoids', 'Triceps Brachii', 'Upper Trapezius', 'Serratus Anterior']
  },
  {
    id: 'deficit-pike-push-up',
    name: 'Deep Deficit Pike Push-Up (Parallettes / Books)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Pike push-up with hands on parallettes or elevated blocks so the head descends past palm level for full-range shoulder pressing power.',
    instructions: [
      'Grip parallettes shoulder-width apart and hike your hips into a steep pike (or elevate feet on a box).',
      'Lower your head forward and deep between the parallettes until your shoulders approach hand level.',
      'Drive powerfully straight up into overhead lockout.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Anterior & Lateral Deltoids', 'Triceps', 'Upper Traps', 'Clavicular Chest']
  },
  {
    id: 'wall-handstand-hold',
    name: 'Chest-to-Wall Handstand Hold',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Inverted vertical isometric hold facing the wall to build stacked overhead shoulder strength, hollow-body alignment, and wrist endurance.',
    instructions: [
      'Walk your feet up a wall facing toward it until your hands are 4-8 inches from the baseboard.',
      'Push the floor away maximally by elevating your shoulders toward your ears.',
      'Tuck your pelvis (posterior pelvic tilt), squeeze glutes, and point toes in a perfectly straight vertical line.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 30,
    targetMuscles: ['Anterior & Lateral Deltoids', 'Upper Trapezius', 'Triceps', 'Core', 'Forearms']
  },
  {
    id: 'wall-shoulder-taps',
    name: 'Wall Handstand Shoulder Taps',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Unilateral overhead weight shifts in a wall handstand, tapping the opposite shoulder to build insane single-arm overhead stability.',
    instructions: [
      'Kick up or walk up into a stable handstand against a wall with feet slightly wider than hip-width.',
      'Shift your center of mass over your left hand, push the floor away hard, and briefly tap your left shoulder with your right hand.',
      'Plant your right hand back down and shift smoothly to tap with the opposite side.'
    ],
    progressionLevel: 4,
    defaultReps: 10,
    targetMuscles: ['Anterior & Lateral Deltoids', 'Upper Trapezius', 'Triceps', 'Obliques', 'Forearms']
  },
  {
    id: 'wall-handstand-push-up',
    name: 'Wall Handstand Push-Up (HSPU Progression)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Vertical bodyweight overhead press using a wall for balance.',
    instructions: [
      'Kick up into handstand with heels against wall, fingers 6-10 inches away.',
      'Descend head diagonally forward to form a stable tripod with hands.',
      'Drive aggressively straight up to complete elbow lockout.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Shoulders (Full Deltoid)', 'Triceps', 'Trapezius', 'Core']
  },
  {
    id: 'deficit-wall-hspu',
    name: 'Deep Deficit Wall Handstand Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Full collarbone-to-bar depth handstand push-up performed on parallettes or stacked blocks against the wall.',
    instructions: [
      'Place parallettes or sturdy blocks 8-10 inches from the wall and kick up into a handstand.',
      'Lower slowly past head level until your ears and shoulders descend between your hands.',
      'Press with maximal shoulder and tricep drive back to full overhead lockout.'
    ],
    progressionLevel: 5,
    defaultReps: 4,
    targetMuscles: ['Anterior & Lateral Deltoids', 'Triceps Brachii', 'Upper Trapezius', 'Upper Chest', 'Core']
  },
  {
    id: 'tiger-bend-push-up',
    name: 'Tiger-Bend Pike / Handstand Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Advanced overhead tricep press lowering from a pike or handstand onto the forearms and pressing back up to straight arms.',
    instructions: [
      'From a steep pike or wall handstand, bend your elbows straight back to lower your forearms flat onto the floor.',
      'Shift your shoulders slightly forward over your wrists and press explosively through your palms to lift both elbows simultaneously.',
      'Lock out overhead and repeat.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Triceps Brachii', 'Anterior Deltoids', 'Serratus Anterior', 'Forearms']
  },
  {
    id: 'ninety-degree-push-up',
    name: '90-Degree Handstand Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Elite calisthenics skill combining a freestanding handstand lowering into a horizontal elbow-lever/bent-arm planche and pressing back to handstand.',
    instructions: [
      'Begin in a controlled handstand or high pike.',
      'Lower down while leaning your shoulders forward and floating your legs down until your body hovers parallel to the floor at 90-degree elbow flexion.',
      'Pause briefly in the horizontal float, then press and pike hips back up to vertical.'
    ],
    progressionLevel: 5,
    defaultReps: 3,
    targetMuscles: ['Anterior Deltoids', 'Triceps', 'Pectoralis Major', 'Erector Spinae', 'Core']
  },
  {
    id: 'side-to-side-push-up',
    name: 'Side-to-Side Shifting Push-Up',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Wide-grip push-up shifting your chest over the left hand and then the right hand at the bottom to bridge the gap toward Archer Push-Ups.',
    instructions: [
      'Place hands 1.5x shoulder-width apart.',
      'Lower your chest directly over your right palm while your left elbow stays partially bent.',
      'Glide horizontally across the bottom to bring your chest over your left palm, then press back to center.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Anterior Deltoid', 'Serratus Anterior']
  },
  {
    id: 'archer-push-up',
    name: 'Archer Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Lateral shifting push-up isolating one side of the chest with single-arm pressing power while the opposite arm remains locked straight.',
    instructions: [
      'Assume wide stance with hands turned slightly outward.',
      'Lower body toward one arm, keeping the other arm straight and tracking across floor.',
      'Press out forcefully through the bent arm, then reset and alternate.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Chest Unilateral', 'Triceps', 'Rotator Cuff', 'Core']
  },
  {
    id: 'typewriter-push-up',
    name: 'Typewriter Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Staying hovered 2 inches off the floor in an archer push-up and sliding horizontally side-to-side like a typewriter carriage.',
    instructions: [
      'Lower into an Archer Push-Up on your right arm with your left arm locked straight.',
      'Without rising up, slide your chest horizontally across the floor to your left hand while straightening your right arm.',
      'Slide back to the right hand, then press up to the top.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Pectoralis Major', 'Anterior Deltoid', 'Triceps', 'Core', 'Serratus Anterior']
  },
  {
    id: 'assisted-one-arm-push-up',
    name: 'Assisted One-Arm Push-Up (Hand on Block / Ball)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Primary working hand planted under the shoulder while the assist arm rests out wide on a block, book stack, or ball for calibrated one-arm training.',
    instructions: [
      'Plant your working hand on the floor directly beneath your sternum and place your assist hand wide on an elevated block or ball.',
      'Spread feet wide into a straddle stance and brace your obliques to prevent hip twist.',
      'Lower chest to the floor using 85% of the force from your floor arm, then drive back up.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Pectoralis Major (Unilateral)', 'Triceps', 'Anterior Deltoid', 'Obliques']
  },
  {
    id: 'straddle-one-arm-push-up',
    name: 'One-Arm Push-Up (Straddle Stance)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'True single-arm push-up with a wide foot straddle and the non-working hand pinned behind the lower back.',
    instructions: [
      'Spread your feet 2x shoulder-width apart for a stable base and place your working hand beneath your center of gravity.',
      'Pin your non-working hand behind your lower back and lock your core and obliques so your shoulders stay square to the floor.',
      'Keep your working elbow tucked close to your body as you descend until your chest nears the floor, then drive up to lockout.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Pectoralis Major (Unilateral)', 'Triceps Brachii', 'Anterior Deltoid', 'Obliques & Core']
  },
  {
    id: 'strict-one-arm-push-up',
    name: 'Strict Feet-Together One-Arm Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'The pinnacle of unilateral pushing control: performing a one-arm push-up with feet narrow and zero hip rotation.',
    instructions: [
      'Place feet close together and center your working hand under your sternum.',
      'Create maximal full-body tension through your abs, obliques, glutes, and quads.',
      'Lower chest smoothly with elbow tucked and press back up without twisting your torso.'
    ],
    progressionLevel: 5,
    defaultReps: 3,
    targetMuscles: ['Pectoralis Major', 'Triceps Brachii', 'Obliques', 'Anterior Deltoid', 'Core']
  },
  {
    id: 'planche-lean',
    name: 'Planche Lean Hold (Protracted Straight-Arm)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Essential straight-arm conditioning hold leaning the shoulders far forward past the wrists with maximal scapular protraction and posterior pelvic tilt.',
    instructions: [
      'Assume a push-up plank with hands turned 45 degrees outward.',
      'Lock your elbows completely straight, dome your upper back (protraction), and tuck your tailbone under.',
      'Shift your feet forward or lean your torso ahead until your shoulders are well in front of your fingertips.',
      'Hold peak forward lean for time without bending your arms.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 20,
    targetMuscles: ['Anterior Deltoids', 'Serratus Anterior', 'Biceps Tendons', 'Core', 'Forearms']
  },
  {
    id: 'frog-stand-crow-pose',
    name: 'Frog Stand / Crow Pose Balance',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Foundational hand-balancing hold resting the knees on the backs of the triceps to learn forward wrist pressure and anterior delt engagement.',
    instructions: [
      'Squat down and plant palms shoulder-width apart on the floor with fingers spread wide.',
      'Place your knees high against the backs of your triceps (or outside your elbows).',
      'Lean your shoulders forward and grip the floor with your fingertips until your toes float effortlessly off the ground.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 25,
    targetMuscles: ['Anterior Deltoids', 'Triceps', 'Forearms & Wrists', 'Core', 'Serratus Anterior']
  },
  {
    id: 'pseudo-planche-push-up',
    name: 'Pseudo Planche Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Hands turned outward at waist level, leaning shoulders significantly forward past fingertips throughout the entire push-up.',
    instructions: [
      'Place hands at hip/waist level with fingers angled 45-90 degrees outward.',
      'Lean body forward until shoulders are far in front of wrists.',
      'Keep full protraction and forward lean throughout both the descent and ascent—do not rock backward as you push up.'
    ],
    progressionLevel: 4,
    defaultReps: 8,
    targetMuscles: ['Anterior Deltoids', 'Chest Lower/Mid', 'Biceps Tendons', 'Serratus Anterior']
  },
  {
    id: 'tuck-planche-push-up',
    name: 'Tuck Planche Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Floating push-up with knees tucked tightly to the chest and feet completely off the floor, building elite bent-arm planche strength.',
    instructions: [
      'Grip parallettes or floor, lean shoulders forward, and lift your feet off the ground into a Tuck Planche.',
      'Keeping your knees tucked tightly to your chest and hips at shoulder height, bend your elbows to lower your torso.',
      'Press powerfully back up to a straight-arm protracted Tuck Planche lockout.'
    ],
    progressionLevel: 5,
    defaultReps: 4,
    targetMuscles: ['Anterior Deltoids', 'Pectoralis Major', 'Triceps', 'Serratus Anterior', 'Core']
  },
  {
    id: 'maltese-wide-lean-push-up',
    name: 'Maltese Wide-Arm Lean Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Extra-wide hand placement at hip level with extreme forward shoulder lean to condition the chest, anterior delts, and biceps tendons for wide pressing.',
    instructions: [
      'Place hands 2x shoulder-width apart near hip line with fingers pointed outward.',
      'Lean shoulders forward and lower your torso while keeping elbows tracking back.',
      'Drive through your palms to return to a protracted wide-arm lockout.'
    ],
    progressionLevel: 5,
    defaultReps: 6,
    targetMuscles: ['Pectoralis Major', 'Anterior Deltoids', 'Biceps Tendons', 'Serratus Anterior']
  },
  {
    id: 'plyo-pop-push-up',
    name: 'Plyometric Pop Push-Up',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Explosive push-up launching the palms 3-5 inches off the floor at the top of every rep to develop fast-twitch pressing speed.',
    instructions: [
      'Lower into a full push-up with controlled speed.',
      'Drive through the floor with maximum acceleration so your hands clear the ground at the top.',
      'Absorb the landing softly through slightly bent elbows and flow directly into the next rep.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Pectoralis Major', 'Triceps Brachii', 'Anterior Deltoids', 'Core']
  },
  {
    id: 'explosive-push-up',
    name: 'Explosive Clap Push-Up',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Maximal velocity push launching upper body completely off the floor for a mid-air clap.',
    instructions: [
      'Descend rapidly to build stretch-shortening cycle.',
      'Press through the floor with maximal explosion, clapping hands in mid-air.',
      'Land softly with bent elbows to absorb shock smoothly.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Fast-Twitch Chest', 'Triceps Power', 'Shoulders']
  },
  {
    id: 'chest-tap-push-up',
    name: 'Chest-Tap Explosive Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Higher-altitude plyometric push-up launching high enough to tap both palms against your chest in mid-air before landing.',
    instructions: [
      'Explode upward from the bottom of a push-up with maximum upper-body velocity.',
      'At peak airtime, quickly tap both hands against your pectoral muscles.',
      'Extend hands back to the floor prior to landing and cushion the impact smoothly.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Pectoralis Major', 'Triceps Brachii', 'Anterior Deltoids', 'Core']
  },
  {
    id: 'behind-back-clap-push-up',
    name: 'Behind-the-Back Clap Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Explosive full-body launch clapping hands behind the hips in mid-air.',
    instructions: [
      'Descend into the bottom of a push-up and coil hip and shoulder power.',
      'Drive explosively through palms while snapping hips slightly upward for maximum hang time.',
      'Clap hands behind your lower back and Whip arms forward to land safely with soft elbows.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Anterior & Posterior Deltoids', 'Core']
  },
  {
    id: 'superman-push-up',
    name: 'Superman Flying Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Full-body airborne push-up launching both hands and feet off the floor simultaneously while extending arms overhead like Superman.',
    instructions: [
      'Generate maximum explosive drive through your palms and toes simultaneously.',
      'In mid-air, shoot both arms straight overhead in front of you while your entire body floats parallel to the floor.',
      'Bring hands rapidly back under your shoulders to absorb the landing safely.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Pectoralis Major', 'Anterior Deltoids', 'Triceps', 'Core', 'Erector Spinae']
  },
  {
    id: 'aztec-push-up',
    name: 'Aztec Push-Up (Mid-Air Toe Touch)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Acrobatic plyometric push-up exploding completely into the air and folding into a mid-air pike to touch your toes before landing back in plank.',
    instructions: [
      'Explode off both hands and feet with maximum vertical height.',
      'At the apex of the jump, snap your hips up and fold forward to touch your fingers to your toes in mid-air.',
      'Extend your body back out into a plank to land softly on hands and balls of your feet.'
    ],
    progressionLevel: 5,
    defaultReps: 4,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Rectus Abdominis', 'Hip Flexors', 'Anterior Deltoids']
  },
  {
    id: 'bench-tricep-dip',
    name: 'Bench / Chair Dip',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Accessible vertical pushing progression with hands behind your hips on a bench or chair to build tricep mass and prepare for parallel bar dips.',
    instructions: [
      'Sit on the edge of a sturdy bench or chair and grip the front edge beside your hips.',
      'Extend your legs out in front (or bend knees for less load) and slide your glutes just in front of the seat.',
      'Lower your hips straight down until elbows reach 90 degrees while keeping your back close to the bench.',
      'Press through the heels of your palms to lock out your triceps.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Triceps Brachii', 'Anterior Deltoid', 'Lower Pectorals']
  },
  {
    id: 'parallel-bar-support-hold',
    name: 'Parallel Bar Top Support Hold (Scapular Depression)',
    category: 'push',
    difficulty: 'beginner',
    equipment: 'dip bars',
    description: 'Straight-arm isometric support hold atop parallel bars to build shoulder depression, elbow lockout stability, and dip readiness.',
    instructions: [
      'Jump up onto parallel bars with elbows locked completely straight.',
      'Push down through the bars to depress your shoulders far away from your ears.',
      'Tuck your pelvis into a tight hollow body and hold without sinking into your shoulder joints.'
    ],
    progressionLevel: 1,
    isHold: true,
    defaultHoldSec: 30,
    targetMuscles: ['Lower Trapezius', 'Triceps', 'Pectoralis Minor', 'Serratus Anterior', 'Core']
  },
  {
    id: 'parallel-bar-dip',
    name: 'Parallel Bar Dip',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'dip bars',
    description: 'The upper body squat: builds colossal tricep, chest, and front delt mass and pushing strength.',
    instructions: [
      'Mount dip bars and lock elbows, shoulders depressed down away from ears.',
      'Lean chest slightly forward (15-20 degrees).',
      'Lower smoothly until shoulders are below elbows (90 degrees or deeper).',
      'Drive up through palms back to full lockout.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Pectoralis Major (Lower)', 'Triceps', 'Anterior Deltoid']
  },
  {
    id: 'chest-lean-dip',
    name: 'Forward-Lean Chest Dip',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'dip bars',
    description: 'Parallel bar dip performed with a pronounced 35-45 degree forward torso lean and tucked legs to maximize lower and outer pectoral recruitment.',
    instructions: [
      'Support yourself on dip bars and tuck your knees slightly forward while leaning your chest 35-45 degrees ahead.',
      'Allow elbows to flare slightly (30 degrees) as you descend into a deep pectoral stretch.',
      'Drive up while maintaining the forward torso angle to keep tension squarely on the chest.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Pectoralis Major (Costal & Outer)', 'Anterior Deltoid', 'Triceps Brachii']
  },
  {
    id: 'korean-dip',
    name: 'Korean Dip (Behind-the-Back Straight Bar Dip)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Advanced straight-bar dip performed with the bar positioned behind your lower back and hips.',
    instructions: [
      'Sit on a waist-to-chest height horizontal bar and grip it behind your hips with an underhand or overhand grip.',
      'Slide off the bar into a support hold with the bar behind your back.',
      'Lower your body by bending your elbows and arching slightly around the bar, then press powerfully back to top support.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Triceps Brachii', 'Anterior Deltoids', 'Lower Pectorals', 'Core']
  },
  {
    id: 'russian-dip',
    name: 'Russian Dip (Forearm Drop Dip)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'dip bars',
    description: 'Muscle-up transition strengthener: lowering into a parallel bar dip, shifting backward to rest forearms on the bars, then shifting forward and pressing up.',
    instructions: [
      'Start in top support on parallel bars and descend to the bottom of a standard dip.',
      'At the bottom, shift your shoulders backward until your forearms and elbows rest flat along the tops of the parallel bars.',
      'Explode forward off your forearms back into the bottom dip position and press straight up to lockout.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Triceps Brachii', 'Pectoralis Major', 'Anterior Deltoids', 'Latissimus Dorsi', 'Core']
  },
  {
    id: 'ring-dip',
    name: 'Gymnastic Ring Dip (RTO Lockout)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'dip bars',
    description: 'Unstable suspension dip requiring immense shoulder stabilization and finishing with Rings Turned Out (RTO) at 45 degrees at the top.',
    instructions: [
      'Establish a rock-solid support hold on gymnastic rings with elbows locked and rings hugged close to your hips.',
      'Lower under strict control until shoulders reach ring level.',
      'Press back up and externally rotate your thumbs outward 45 degrees (RTO) at the top lockout.'
    ],
    progressionLevel: 4,
    defaultReps: 8,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Anterior Deltoid', 'Biceps Brachii (Stabilizer)', 'Rotator Cuff']
  },
  {
    id: 'impossible-dip',
    name: 'Impossible Dip (Pure Tricep Vertical Dip)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'dip bars',
    description: 'Extreme mechanical-disadvantage dip keeping the torso 100% vertical and leaning slightly backward so the triceps lift the entire bodyweight with zero forward lean.',
    instructions: [
      'Mount parallel bars and hold your body in a rigid vertical hollow line with zero forward shoulder lean.',
      'Bend only at the elbows, allowing your shoulders to stay behind your hands as your forearms lower toward the bars.',
      'Drive through your palms using pure tricep extension to return upright.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Triceps Brachii', 'Anterior Deltoid', 'Core', 'Forearms']
  },
  {
    id: 'explosive-plyo-dip',
    name: 'Explosive Plyometric Bar Dip',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'dip bars',
    description: 'High-velocity parallel bar dip launching the hands briefly off the bars at the top of the press.',
    instructions: [
      'Lower into a controlled 90-degree parallel bar dip.',
      'Drive downward through the bars with maximum explosive power so your palms hop slightly off the bars at lockout.',
      'Catch the bars smoothly with active shoulders and absorb into the next rep.'
    ],
    progressionLevel: 4,
    defaultReps: 8,
    targetMuscles: ['Triceps Brachii', 'Pectoralis Major', 'Anterior Deltoids', 'Core']
  },

  // ==================== CORE ====================
  {
    id: 'plank',
    name: 'Forearm Plank',
    category: 'core',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Foundational isometric core hold training anti-extension and full body tension.',
    instructions: [
      'Rest on forearms with elbows directly under shoulders.',
      'Squeeze glutes, quads, and draw navel toward spine.',
      'Maintain an unbroken straight line from crown of head to heels.'
    ],
    progressionLevel: 1,
    isHold: true,
    defaultHoldSec: 45,
    targetMuscles: ['Rectus Abdominis', 'Transverse Abdominis', 'Glutes', 'Lower Back']
  },
  {
    id: 'side-plank',
    name: 'Side Plank',
    category: 'core',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Lateral anti-lateral flexion hold strengthening obliques and hip abductors.',
    instructions: [
      'Lie on your side propped on one forearm.',
      'Elevate hips until body forms a straight diagonal line.',
      'Hold position without letting bottom hip drop or rotate.'
    ],
    progressionLevel: 1,
    isHold: true,
    defaultHoldSec: 30,
    targetMuscles: ['Obliques', 'Quadratus Lumborum', 'Gluteus Medius']
  },
  {
    id: 'hollow-body-hold',
    name: 'Hollow Body Hold',
    category: 'core',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Gymnastics cornerstone hold creating anterior pelvic tilt and unbreakable abdominal brace.',
    instructions: [
      'Lie supine on floor, press lower back completely flush against the ground.',
      'Raise shoulder blades and extend arms overhead by ears.',
      'Elevate legs 6 inches off ground with pointed toes, maintaining lower back seal.'
    ],
    progressionLevel: 2,
    isHold: true,
    defaultHoldSec: 30,
    targetMuscles: ['Rectus Abdominis', 'Transverse Abdominis', 'Hip Flexors', 'Serratus']
  },
  {
    id: 'arch-hold',
    name: 'Arch Hold (Superman)',
    category: 'core',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Posterior chain isometric hold developing spinal erectors and gluteal endurance.',
    instructions: [
      'Lie prone on stomach with arms outstretched overhead.',
      'Engage glutes and upper back to lift chest and thighs simultaneously off floor.',
      'Breathe smoothly while sustaining maximum extension.'
    ],
    progressionLevel: 1,
    isHold: true,
    defaultHoldSec: 30,
    targetMuscles: ['Erector Spinae', 'Gluteus Maximus', 'Hamstrings', 'Mid Traps']
  },
  {
    id: 'leg-raise',
    name: 'Lying Leg Raise',
    category: 'core',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Floor leg raises targeting lower abdominal control and hip flexor strength.',
    instructions: [
      'Lie flat with hands placed beside hips or under tailbone for support.',
      'Keep legs straight and lift them vertically to 90 degrees.',
      'Lower legs back down slowly, stopping 2 inches off floor without arching back.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Lower Abdominals', 'Iliopsoas', 'Rectus Femoris']
  },
  {
    id: 'hanging-knee-raise',
    name: 'Hanging Knee Raise',
    category: 'core',
    difficulty: 'beginner',
    equipment: 'pull-up bar',
    description: 'Decompresses the spine while rolling the pelvis upward toward chest.',
    instructions: [
      'Hang from bar with active shoulders.',
      'Tuck knees upward into chest, tilting pelvis backward to contract abs.',
      'Lower slowly without swinging body.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Rectus Abdominis', 'Hip Flexors', 'Grip Strength']
  },
  {
    id: 'hanging-leg-raise',
    name: 'Hanging Straight Leg Raise',
    category: 'core',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'Gold standard calisthenics abdominal movement with straight toes touching the bar.',
    instructions: [
      'Hang from bar with overhand grip.',
      'Without swinging, compress hip flexors and lift straight legs until toes touch the bar.',
      'Lower under 3-second negative control.'
    ],
    progressionLevel: 4,
    defaultReps: 8,
    targetMuscles: ['Abdominals', 'Hip Flexors', 'Lats', 'Forearms']
  },
  {
    id: 'l-sit-hold',
    name: 'L-Sit Hold',
    category: 'core',
    difficulty: 'intermediate',
    equipment: 'parallettes',
    description: 'Classic calisthenics test supporting bodyweight with legs locked perpendicular to torso.',
    instructions: [
      'Support yourself on parallettes or floor with straight locked arms.',
      'Depress scapulae actively to lift hips.',
      'Extend legs straight forward at 90 degrees with quad tension and pointed toes.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 15,
    targetMuscles: ['Rectus Abdominis', 'Quadriceps', 'Hip Flexors', 'Triceps']
  },
  {
    id: 'tuck-hold',
    name: 'Tuck Hold on Parallettes',
    category: 'core',
    difficulty: 'beginner',
    equipment: 'parallettes',
    description: 'Intermediate step toward full L-Sit lifting hips and knees tightly to chest.',
    instructions: [
      'Place hands on parallettes or floor.',
      'Push down firmly through palms to depress shoulders.',
      'Tuck knees tightly toward chest and suspend feet off floor.'
    ],
    progressionLevel: 2,
    isHold: true,
    defaultHoldSec: 20,
    targetMuscles: ['Abdominals', 'Serratus', 'Triceps', 'Shoulders']
  },
  {
    id: 'v-up',
    name: 'V-Up',
    category: 'core',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Dynamic pike compression snapping upper body and legs together simultaneously.',
    instructions: [
      'Start in hollow body position.',
      'Simultaneously fold torso and straight legs upward, reaching fingers to toes.',
      'Balance momentarily on sit-bones at top, then lower back to hollow body.'
    ],
    progressionLevel: 3,
    defaultReps: 12,
    targetMuscles: ['Upper & Lower Abs', 'Hip Flexors', 'Pectorals']
  },
  {
    id: 'dragon-flag',
    name: 'Dragon Flag Progression',
    category: 'core',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'The legendary Bruce Lee movement supporting entire bodyweight purely on upper back and shoulders.',
    instructions: [
      'Lie on floor or bench gripping a sturdy support behind head.',
      'Roll up into vertical candlestick position on upper traps.',
      'Lower entire body in a straight plank line until just above bench, then pull back up.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Entire Core Wall', 'Lats', 'Glutes', 'Lower Back']
  },

  // ==================== LEGS ====================
  {
    id: 'bodyweight-squat',
    name: 'Bodyweight Squat',
    category: 'legs',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Essential lower body compound building knee health, quad power, and hip mobility.',
    instructions: [
      'Stand feet shoulder-width, toes angled slightly outward.',
      'Push hips back and bend knees, driving knees outward over second toe.',
      'Descend below parallel with neutral spine, then drive through mid-foot.'
    ],
    progressionLevel: 1,
    defaultReps: 20,
    targetMuscles: ['Quadriceps', 'Glutes', 'Hamstrings', 'Adductors']
  },
  {
    id: 'split-squat',
    name: 'Split Squat',
    category: 'legs',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Stationary unilateral lunge improving hip stability and quad isolation.',
    instructions: [
      'Step one foot forward and one foot back in a staggered stance.',
      'Lower back knee toward floor while keeping torso upright.',
      'Push through front heel to return to top without moving feet.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Quadriceps', 'Glutes', 'Hip Stabilizers']
  },
  {
    id: 'reverse-lunge',
    name: 'Reverse Lunge',
    category: 'legs',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Joint-friendly stepping lunge emphasizing glute and hamstring deceleration.',
    instructions: [
      'Take a controlled step backward, bending both knees to 90 degrees.',
      'Keep front knee directly stacked above ankle.',
      'Drive powerfully off front foot back to starting standing position.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Glutes', 'Hamstrings', 'Quadriceps', 'Calves']
  },
  {
    id: 'walking-lunge',
    name: 'Walking Lunge',
    category: 'legs',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Continuous forward lunging building functional athletic endurance and balance.',
    instructions: [
      'Step forward into a lunge, trailing knee skimming 1 inch off floor.',
      'Rise continuously directly into the next forward step on the opposite leg.',
      'Maintain steady rhythmic pace and upright posture.'
    ],
    progressionLevel: 2,
    defaultReps: 16,
    targetMuscles: ['Quads', 'Glutes', 'Core Balance', 'Calves']
  },
  {
    id: 'bulgarian-split-squat',
    name: 'Bulgarian Split Squat',
    category: 'legs',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Rear foot elevated split squat providing immense unilateral quad and glute hypertrophy.',
    instructions: [
      'Rest top of rear foot on a chair, couch, or bench behind you.',
      'Lower into deep lunge until front thigh is parallel or deeper.',
      'Drive through front heel while keeping chest proudly lifted.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Quadriceps', 'Gluteus Maximus', 'Adductors']
  },
  {
    id: 'calf-raise',
    name: 'Standing Calf Raise',
    category: 'legs',
    difficulty: 'beginner',
    equipment: 'none',
    description: 'Full ankle plantarflexion for gastrocnemius and soleus strength and tendon resilience.',
    instructions: [
      'Stand on balls of feet on an elevated step or floor.',
      'Elevate as high as possible onto big toes, squeezing calves at top for 2 seconds.',
      'Lower below step level for a full stretch.'
    ],
    progressionLevel: 1,
    defaultReps: 20,
    targetMuscles: ['Gastrocnemius', 'Soleus', 'Achilles Tendon']
  },
  {
    id: 'jump-squat',
    name: 'Explosive Jump Squat',
    category: 'legs',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Plyometric power movement converting leg strength into vertical leap propulsion.',
    instructions: [
      'Descend into a quarter/half squat.',
      'Explode upwards with maximum power, extending ankles, knees, and hips.',
      'Absorb impact softly through balls of feet back down into next squat.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Fast-Twitch Quads', 'Glutes', 'Calves']
  },
  {
    id: 'assisted-pistol-squat',
    name: 'Assisted Pistol Squat',
    category: 'legs',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Single-leg squat using light pole or doorframe touch for balance progression.',
    instructions: [
      'Stand on one leg, extending free leg forward.',
      'Lightly hold a doorframe or pole for balance support.',
      'Squat deep onto the single working leg, then drive up through heel.'
    ],
    progressionLevel: 3,
    defaultReps: 6,
    targetMuscles: ['Unilateral Quads', 'Hip Flexors', 'Ankle Mobility']
  },
  {
    id: 'full-pistol-squat',
    name: 'Full Pistol Squat',
    category: 'legs',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'The pinnacle bodyweight leg strength exercise requiring total balance, mobility, and single-leg force.',
    instructions: [
      'Stand balanced on one leg with opposite leg extended completely straight forward.',
      'Descend under complete control until hamstring meets calf.',
      'Pause at bottom without losing balance, then drive smoothly straight back up.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Quadriceps', 'Glutes', 'Ankles', 'Core Balance']
  },

  // ==================== BACKPACK TRAINING (SAFE HOME LOADED) ====================
  {
    id: 'backpack-curl',
    name: 'Backpack Bicep Curl',
    category: 'backpack',
    difficulty: 'beginner',
    equipment: 'backpack',
    description: 'Safe loaded home bicep curl using top carry handle or side straps.',
    instructions: [
      'Hold the backpack top handle with an underhand grip, elbows pinned to sides.',
      'Curl the backpack upward toward collarbones with strict tempo.',
      'Lower with 2-second eccentric control without swinging torso.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Biceps', 'Brachialis', 'Forearms'],
    safetyNote: 'Distribute books or water bottles evenly. Fasten internal zips so weight cannot shift suddenly.'
  },
  {
    id: 'backpack-hammer-curl',
    name: 'Backpack Hammer Curl',
    category: 'backpack',
    difficulty: 'beginner',
    equipment: 'backpack',
    description: 'Neutral-grip curl holding side straps or side carry loop for brachioradialis and forearm power.',
    instructions: [
      'Grip the backpack side straps or grab both ends of the bag.',
      'Curl upward keeping thumbs facing up in neutral grip.',
      'Squeeze top contraction for 1 second.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Brachioradialis', 'Long Head Biceps', 'Grip'],
    safetyNote: 'Ensure straps are sturdy and double-checked before lifting.'
  },
  {
    id: 'backpack-row',
    name: 'Backpack Bent-Over Row',
    category: 'backpack',
    difficulty: 'intermediate',
    equipment: 'backpack',
    description: 'Hinged horizontal pull targeting lats, rhomboids, and rear delts with loaded home resistance.',
    instructions: [
      'Hinge at hips to a 45-degree angle with flat neutral spine.',
      'Hold backpack handles with both hands hanging beneath shoulders.',
      'Pull backpack toward navel, driving elbows back and squeezing shoulder blades.'
    ],
    progressionLevel: 2,
    defaultReps: 10,
    targetMuscles: ['Latissimus Dorsi', 'Rhomboids', 'Rear Delts', 'Lower Back'],
    safetyNote: 'Never round your lumbar spine. Keep knees soft and brace core throughout.'
  },
  {
    id: 'backpack-squat',
    name: 'Backpack Goblet Squat',
    category: 'backpack',
    difficulty: 'intermediate',
    equipment: 'backpack',
    description: 'Loaded front-hold squat forcing upright posture and greater quad stimulation.',
    instructions: [
      'Hug the weighted backpack tightly against chest with both arms (or wear it on front).',
      'Squat down deep with elbows inside knees.',
      'Push floor away through heels, exhaling on the ascent.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Quadriceps', 'Core Bracing', 'Glutes', 'Upper Back'],
    safetyNote: 'Keep bag held tightly against chest so leverage does not stress neck or lower back.'
  },
  {
    id: 'backpack-romanian-deadlift',
    name: 'Backpack Romanian Deadlift',
    category: 'backpack',
    difficulty: 'intermediate',
    equipment: 'backpack',
    description: 'Hip hinge movement loading the posterior chain (hamstrings and glutes) at home.',
    instructions: [
      'Hold backpack handles with arms extended in front of thighs.',
      'With slight knee bend, push hips backward as if touching a wall behind you.',
      'Lower bag along shins until hamstring tension peaks, then snap hips forward.'
    ],
    progressionLevel: 2,
    defaultReps: 10,
    targetMuscles: ['Hamstrings', 'Gluteus Maximus', 'Erector Spinae'],
    safetyNote: 'Focus on horizontal hip translation rather than bending down. Stop if back begins to round.'
  },
  {
    id: 'backpack-shoulder-press',
    name: 'Backpack Overhead Shoulder Press',
    category: 'backpack',
    difficulty: 'intermediate',
    equipment: 'backpack',
    description: 'Vertical loaded overhead push developing boulder shoulders and locked core stability.',
    instructions: [
      'Hold backpack at collarbone level with palms bracing sides or bottom.',
      'Squeeze glutes and tuck pelvis to prevent hyperextending lower back.',
      'Press bag straight overhead to full arm lockout.'
    ],
    progressionLevel: 2,
    defaultReps: 10,
    targetMuscles: ['Anterior & Lateral Deltoids', 'Triceps', 'Upper Pectorals'],
    safetyNote: 'Start with moderate load (4-8 kg). Do not arch back backwards to force the press.'
  },
  {
    id: 'backpack-calf-raise',
    name: 'Backpack Single-Leg Calf Raise',
    category: 'backpack',
    difficulty: 'intermediate',
    equipment: 'backpack',
    description: 'Wearing a weighted backpack to amplify single-leg calf overload on an elevated ledge.',
    instructions: [
      'Wear backpack securely with chest/waist straps clipped tight.',
      'Stand on ball of one foot on a step edge.',
      'Lower heel for a deep stretch, then elevate onto big toe for a 2-second peak hold.'
    ],
    progressionLevel: 2,
    defaultReps: 15,
    targetMuscles: ['Gastrocnemius', 'Soleus', 'Achilles Tendon'],
    safetyNote: 'Keep one hand touching a wall for stable balance while wearing the pack.'
  },
  {
    id: 'backpack-weighted-pushup',
    name: 'Weighted Backpack Push-Up',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Wearing a securely cinched backpack during push-ups for heavy progressive chest overload.',
    instructions: [
      'Wear loaded backpack high on upper back, cinching straps tightly so it sits between shoulder blades.',
      'Adopt push-up plank, bracing core strongly against added gravitational load.',
      'Perform full range reps touching chest to floor.'
    ],
    progressionLevel: 4,
    defaultReps: 8,
    targetMuscles: ['Pectoralis Major', 'Triceps', 'Shoulders', 'Core Bracing'],
    safetyNote: 'Bag must sit high on upper back, not on lower back. Start with no more than 5-10% of bodyweight.'
  },

  // ==================== RESISTANCE BAND (PULL, PUSH, SHOULDERS, ARMS, CORE, LEGS & ASSISTED SKILLS) ====================
  {
    id: 'band-lat-pulldown',
    name: 'Resistance Band Lat Pulldown',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Band anchored high overhead on a pull-up bar or door top, kneeling or seated and pulling elbows down and back to build wide V-taper lats.',
    instructions: [
      'Loop a medium or heavy resistance band over a pull-up bar or high door anchor.',
      'Kneel on the floor (or sit tall) facing the anchor and grip both sides of the band with an overhand grip.',
      'Depress your shoulder blades first, then drive your elbows straight down toward your ribs until hands reach upper chest height.',
      'Squeeze your lats hard for 1 second at peak tension before extending arms slowly overhead for a full lat stretch.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Latissimus Dorsi', 'Teres Major', 'Lower Trapezius', 'Biceps'],
    safetyNote: 'Ensure your high anchor or door wedge is completely secure before pulling down with full force.'
  },
  {
    id: 'band-single-arm-lat-pulldown',
    name: 'Resistance Band Single-Arm Lat Pulldown',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Half-kneeling unilateral lat pulldown isolating one lat at a time through a deep overhead stretch into an iliac lat crunch.',
    instructions: [
      'Anchor the band high overhead and drop into a half-kneeling stance with the opposite foot forward.',
      'Grasp the band with your working hand, starting with a full overhead scapular stretch.',
      'Drive your working elbow down and slightly inward toward your hip while rotating palm to a neutral or supinated finish.',
      'Pause at the bottom to contract the lower lat fibers, then return smoothly.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Latissimus Dorsi (Unilateral)', 'Teres Major', 'Rhomboids', 'Obliques']
  },
  {
    id: 'band-straight-arm-pulldown',
    name: 'Resistance Band Straight-Arm Lat Pulldown (Pullover)',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Pure straight-arm lat isolation and front lever conditioning drill sweeping the band from overhead down to the thighs with locked elbows.',
    instructions: [
      'Anchor band high above head height, step back, and hinge forward slightly at the hips (20–30 degrees).',
      'Grip the band shoulder-width apart with arms extended overhead and elbows locked (or 5-degree soft lock).',
      'Without bending your elbows, sweep your arms downward in a wide arc until your hands touch your thighs.',
      'Squeeze lats and triceps long head at the bottom, directly mimicking Front Lever lat depression.'
    ],
    progressionLevel: 2,
    defaultReps: 15,
    targetMuscles: ['Latissimus Dorsi', 'Teres Major', 'Triceps Long Head', 'Serratus Anterior']
  },
  {
    id: 'band-bent-over-row',
    name: 'Resistance Band Bent-Over Row',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Stepping on a doubled loop band, hinging at the hips, and rowing elbows high to build thick mid-back and lat density.',
    instructions: [
      'Stand on the center of the band with feet hip-width apart.',
      'Hinge at the hips to a 45-degree angle with a flat neutral spine and braced core.',
      'Choke down lower on the band sides to increase starting elastic tension.',
      'Drive elbows back toward your hips, squeezing shoulder blades together at the top.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Latissimus Dorsi', 'Rhomboids', 'Middle Trapezius', 'Erector Spinae']
  },
  {
    id: 'band-seated-row',
    name: 'Resistance Band Seated Row',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Seated on the floor with legs extended, looping the band around your feet and rowing to your lower abdomen.',
    instructions: [
      'Sit tall on the floor with legs straight or slightly bent, looping the center of the band securely around the soles of your feet.',
      'Hold each side of the band with arms extended and an upright, proud chest.',
      'Pull elbows smoothly backward skimming your ribs, retracting scapulae tightly together.',
      'Slowly release forward under 2-second eccentric control without rounding your lower back.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Latissimus Dorsi', 'Rhomboids', 'Middle Trapezius', 'Biceps']
  },
  {
    id: 'band-single-arm-row',
    name: 'Resistance Band Single-Arm Row (Lawnmower Row)',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Staggered-stance unilateral row anchoring the band under your lead foot and driving the working elbow past your ribs.',
    instructions: [
      'Step into a split lunge stance with the band looped securely under the arch of your front foot.',
      'Rest your non-working forearm on your front thigh to support a flat, rigid spine.',
      'Grab the band low with your working hand and row your elbow back toward your hip pocket.',
      'Hold the peak contraction for 1 second before lowering fully.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Latissimus Dorsi', 'Rhomboids', 'Posterior Deltoid', 'Brachialis']
  },
  {
    id: 'band-wide-elbow-row',
    name: 'Resistance Band Wide-Elbow Upper Back Row',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Horizontal row anchored at chest height with elbows flared at 60–75 degrees to target rear delts, rhomboids, and mid-traps.',
    instructions: [
      'Anchor the band at chest height around a post, pole, or door anchor.',
      'Step back with an overhand pronated grip and arms extended forward.',
      'Row the band toward your upper sternum while keeping elbows flared wide out to the sides.',
      'Pinch your upper back and rear deltoids hard for 2 seconds.'
    ],
    progressionLevel: 2,
    defaultReps: 15,
    targetMuscles: ['Rhomboids', 'Middle Trapezius', 'Rear Deltoids', 'Infraspinatus']
  },
  {
    id: 'band-upright-row',
    name: 'Resistance Band Upright Row',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Standing on the band and pulling hands vertically up to upper chest height with elbows leading high to build side delts and upper traps.',
    instructions: [
      'Stand with both feet hip-width apart on the center of the resistance band.',
      'Grip the band with an overhand grip slightly narrower than shoulder width in front of your thighs.',
      'Pull the band straight up along your torso, leading with your elbows until hands reach collarbone height.',
      'Keep elbows higher than wrists at the top without impinging shoulders, then lower slowly.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Lateral Deltoids', 'Upper Trapezius', 'Anterior Deltoids', 'Brachioradialis'],
    safetyNote: 'Use a shoulder-width grip and stop elbows at shoulder height to keep the shoulder joint comfortable.'
  },
  {
    id: 'band-shrugs',
    name: 'Resistance Band Trap Shrugs',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Heavy elastic tension shrugs elevating the shoulder girdle straight toward the ears to forge thick upper trapezius muscles.',
    instructions: [
      'Stand on a heavy loop band with feet shoulder-width apart, gripping both sides low near your knees for high tension.',
      'Stand tall with arms completely straight at your sides and core braced.',
      'Elevate your shoulders straight up toward your ears as high as possible without bending your elbows.',
      'Hold the top contraction for 2 full seconds against peak band resistance, then lower into a deep trap stretch.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Upper Trapezius', 'Levator Scapulae', 'Rhomboids', 'Forearm Grip']
  },
  {
    id: 'band-behind-back-shrug',
    name: 'Resistance Band Behind-the-Back Shrugs',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Standing on the band with loop routed behind glutes, shrugging up and slightly back to emphasize middle and upper trap thickness.',
    instructions: [
      'Step onto the band so the loop passes behind your heels and calves.',
      'Hold the band behind your hips with straight arms and chest proud.',
      'Shrug your shoulder blades upward and slightly together in a retracted position.',
      'Pause for 2 seconds at the top of each rep.'
    ],
    progressionLevel: 2,
    defaultReps: 15,
    targetMuscles: ['Upper & Middle Trapezius', 'Rhomboids', 'Rear Deltoids']
  },
  {
    id: 'band-lateral-raise',
    name: 'Resistance Band Lateral Raises',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Stepping on a light-to-medium band and sweeping arms outward to 90 degrees to build wide 3D lateral deltoid caps.',
    instructions: [
      'Step one or both feet onto a light loop band, holding the band ends beside your hips.',
      'Maintain a 10-degree soft bend in your elbows and brace your core.',
      'Raise your arms outward in the scapular plane (30 degrees forward of torso) until parallel to the floor.',
      'Pause briefly at shoulder height, then lower over 2–3 seconds under strict control.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Lateral Deltoids', 'Supraspinatus', 'Upper Trapezius']
  },
  {
    id: 'band-single-arm-lateral-raise',
    name: 'Resistance Band Single-Arm Lateral Raise (Behind-Back)',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Cable-style unilateral lateral raise routing the band behind your body from the opposite foot for constant deltoid tension.',
    instructions: [
      'Anchor the band under your left foot and route the loop behind your legs to your right hand.',
      'Stand tall and sweep your right arm laterally outward up to shoulder level.',
      'Focus on pushing your knuckles away toward the wall rather than shrugging your trap.',
      'Complete all reps on one side before switching.'
    ],
    progressionLevel: 2,
    defaultReps: 15,
    targetMuscles: ['Lateral Deltoid', 'Supraspinatus', 'Middle Deltoid']
  },
  {
    id: 'band-front-raise',
    name: 'Resistance Band Front Deltoid Raise',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Standing on the band and raising straight arms forward to eye level to strengthen the anterior deltoids for planche and handstands.',
    instructions: [
      'Stand on the center of the band with feet hip-width apart and hold the band in front of your thighs.',
      'Keeping elbows locked straight, raise both arms directly in front of you up to eye level.',
      'Hold for 1 second at the top while keeping your torso vertical with zero backward lean.',
      'Lower slowly back to your thighs.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Anterior Deltoids', 'Clavicular Pectorals', 'Serratus Anterior']
  },
  {
    id: 'band-lu-raise',
    name: 'Resistance Band Lu Raise (Full-Range Overhead Lateral Raise)',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Weightlifting-inspired full-arc lateral raise sweeping the band from hips all the way overhead to build bulletproof shoulder mobility and strength.',
    instructions: [
      'Stand on a light resistance band with a neutral or thumbs-up grip.',
      'Raise your arms laterally outward to 90 degrees, then externally rotate thumbs upward and continue sweeping all the way overhead.',
      'Finish in a locked-out Y-position overhead with active upward scapular rotation.',
      'Control the entire 180-degree arc back down to your sides.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Lateral Deltoids', 'Lower Trapezius', 'Serratus Anterior', 'Rotator Cuff']
  },
  {
    id: 'band-reverse-flye',
    name: 'Resistance Band Rear Delt Reverse Flye (Bent-Over)',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Hinged at the hips while standing on a light band, sweeping arms out to the sides to isolate the posterior deltoids.',
    instructions: [
      'Stand on the center of a light band and hinge forward at the hips to a 60-degree torso angle.',
      'Cross the band sides in an X if needed, holding with palms facing each other.',
      'With slightly bent elbows, sweep your arms wide out toward the ceiling, leading with the backs of your wrists.',
      'Squeeze rear delts at the top and lower smoothly.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Posterior Deltoids', 'Rhomboids', 'Infraspinatus', 'Middle Trapezius']
  },
  {
    id: 'band-pull-apart',
    name: 'Resistance Band Pull-Apart',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'The golden calisthenics posture and rear-delt primer for healthy shoulders, scapular retraction, and thoracic extension.',
    instructions: [
      'Hold a light resistance band in front of your chest at shoulder height with straight arms.',
      'Retract your shoulder blades and pull your hands horizontally outward until the band touches your sternum.',
      'Squeeze upper back and rear delts for 1 second, then control the band back to starting tension.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Rear Deltoids', 'Rhomboids', 'Middle Trapezius', 'Infraspinatus']
  },
  {
    id: 'band-face-pull',
    name: 'Resistance Band Face Pull with External Rotation',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Anchored at eye level, pulling hands back past ears with knuckles pointed backward into a double-bicep pose for bulletproof rotator cuffs.',
    instructions: [
      'Anchor loop band around a sturdy post, door anchor, or pull-up bar at eye level.',
      'Grip band with thumbs pointing toward you and step back to create baseline tension.',
      'Pull hands toward the bridge of your nose while flaring elbows high and externally rotating hands backward.',
      'Hold peak external rotation for 2 seconds.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Rear Deltoids', 'Rotator Cuff (Infraspinatus/Teres Minor)', 'Lower Traps']
  },
  {
    id: 'band-overhead-shoulder-press',
    name: 'Resistance Band Overhead Shoulder Press',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Standing on the band and pressing from the collarbones into full vertical overhead lockout.',
    instructions: [
      'Stand on the center of the band, holding the top loop at collarbone level with palms facing forward.',
      'Brace your abs and squeeze glutes to keep your pelvis tucked and ribs down.',
      'Press hands vertically overhead to full elbow lockout.',
      'Lower slowly over 2 seconds back to your clavicles.'
    ],
    progressionLevel: 2,
    defaultReps: 10,
    targetMuscles: ['Anterior & Lateral Deltoids', 'Triceps Brachii', 'Upper Pectorals', 'Core']
  },
  {
    id: 'band-arnold-press',
    name: 'Resistance Band Arnold Shoulder Press',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Rotational overhead press starting with palms facing you at chin height and rotating 180 degrees as you press overhead.',
    instructions: [
      'Stand on the center of a loop band, holding the band ends at chin height with palms facing toward your face (supinated).',
      'Open your elbows outward while pressing the band overhead and rotating palms to face forward at lockout.',
      'Reverse the rotational path smoothly on the way down to chin level.'
    ],
    progressionLevel: 2,
    defaultReps: 10,
    targetMuscles: ['Anterior, Lateral & Posterior Deltoids', 'Triceps', 'Upper Traps']
  },
  {
    id: 'band-tricep-pushdown',
    name: 'Resistance Band Tricep Pushdown',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Band anchored high overhead on a pull-up bar or door, pinning elbows to ribs and extending forearms into a hard tricep lockout.',
    instructions: [
      'Anchor a loop band securely over a pull-up bar or high door anchor.',
      'Grip both sides of the band with a neutral or pronated grip, pinning elbows tightly against your ribs.',
      'Extend your forearms straight downward until your elbows are completely locked out.',
      'Spread your hands slightly outward at the bottom to peak-contract the lateral horseshoe head of the triceps.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Triceps Brachii (Lateral & Medial Heads)', 'Anconeus']
  },
  {
    id: 'band-single-arm-tricep-pushdown',
    name: 'Resistance Band Single-Arm Tricep Pushdown (Overhand / Underhand)',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Unilateral high-anchor tricep pushdown allowing strict isolation of each arm with either pronated or reverse supinated grip.',
    instructions: [
      'Anchor the band overhead and grasp it with one hand using an overhand or reverse underhand grip.',
      'Lock your upper arm vertically against your ribcage so only your elbow hinge moves.',
      'Drive your hand down to full extension beside your outer thigh and squeeze the tricep for 1 second.',
      'Return slowly to 90 degrees of elbow flexion.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Triceps Medial & Lateral Heads', 'Forearm Stabilizers']
  },
  {
    id: 'band-overhead-tricep-extension',
    name: 'Resistance Band Overhead Tricep Extension',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Standing on one end of the band behind your back and extending forearms overhead to place maximum stretch on the long head of the triceps.',
    instructions: [
      'Step on one end of the band with your heel and bring the other end up behind your back and head.',
      'Point your elbows toward the ceiling next to your ears with forearms flexed behind your neck.',
      'Extend your hands straight upward toward the ceiling to full arm lockout.',
      'Control the descent to feel a deep stretch along the long head of the triceps.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Triceps Long Head', 'Triceps Lateral Head', 'Core Bracing']
  },
  {
    id: 'band-tricep-kickback',
    name: 'Resistance Band Bent-Over Tricep Kickback',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Hinged forward while standing on the band, locking upper arms parallel to the torso and extending forearms straight back.',
    instructions: [
      'Stand on the center of a light band and hinge at the hips to a 45–60 degree angle.',
      'Row your elbows up once and keep your upper arms glued parallel to your torso throughout the set.',
      'Extend your forearms backward until your arms are completely straight behind your hips.',
      'Pause for 1 second at peak elastic tension before bending elbows back to 90 degrees.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Triceps Brachii (All 3 Heads)', 'Rear Deltoid Stabilizers']
  },
  {
    id: 'band-skullcrusher',
    name: 'Resistance Band Lying Tricep Extension (Skullcrusher)',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Lying on the floor with the band anchored beneath your upper back or a low post, extending forearms from forehead to lockout.',
    instructions: [
      'Lie on your back on the floor with the band looped beneath your upper back (or anchored low behind your head).',
      'Hold the band ends with arms angled slightly back toward your forehead and elbows tucked.',
      'Bend only at the elbows to lower hands toward your temples, then press powerfully to full lockout.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Triceps Medial & Long Heads', 'Anconeus']
  },
  {
    id: 'band-standing-bicep-curl',
    name: 'Resistance Band Standing Bicep Curl',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Standing on the center of a loop band and curling upward with an underhand grip against ascending elastic resistance.',
    instructions: [
      'Stand feet shoulder-width on the center of the band, gripping both sides with an underhand supinated grip.',
      'Pin your elbows tight to your sides and curl your hands upward toward your collarbones.',
      'Squeeze your biceps hard for 1 second at peak stretch.',
      'Lower with a slow 2-second eccentric tempo.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Biceps Brachii (Short & Long Heads)', 'Brachialis', 'Forearms']
  },
  {
    id: 'band-hammer-curl',
    name: 'Resistance Band Hammer Curl',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Neutral palms-facing grip bicep curl targeting the brachioradialis and brachialis for thick forearms and elbow tendon armor.',
    instructions: [
      'Stand on the band with a neutral palms-facing grip on the loop sides.',
      'Curl upward keeping your thumbs pointing toward your shoulders.',
      'Pause at the apex while keeping wrists firm and neutral, then lower under control.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Brachioradialis', 'Brachialis', 'Biceps Brachii']
  },
  {
    id: 'band-concentration-curl',
    name: 'Resistance Band Seated Concentration Curl',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Seated single-arm curl with the band anchored under your foot and working elbow braced against your inner thigh for peak bicep isolation.',
    instructions: [
      'Sit on a bench, chair, or low box with the band looped under your working-side foot.',
      'Brace the back of your working upper arm firmly against your inner thigh near the knee.',
      'Curl your hand toward your face, supinating your pinky finger slightly higher than your thumb at the top.',
      'Squeeze the bicep peak hard before lowering fully.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Biceps Brachii (Short Head Peak)', 'Brachialis']
  },
  {
    id: 'band-preacher-curl',
    name: 'Resistance Band High-Anchor Preacher / Hercules Curl',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Facing a low-to-mid anchor with arms extended forward, curling hands toward your forehead to isolate the biceps with zero shoulder momentum.',
    instructions: [
      'Anchor the band at knee or hip height and step back facing the anchor.',
      'Extend your arms forward at a 45-degree angle with palms facing up.',
      'Keeping your elbows fixed in space in front of your torso, curl your hands back toward your forehead.',
      'Hold the intense peak contraction for 1 second before extending.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Biceps Brachii', 'Brachialis']
  },
  {
    id: 'band-behind-back-bayesian-curl',
    name: 'Resistance Band Behind-the-Back Bayesian Curl',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Band anchored low behind you so your arm starts extended behind the torso, placing maximal loaded stretch on the long head of the bicep.',
    instructions: [
      'Anchor the band low behind your feet (or step your front foot forward in a staggered stance over the band).',
      'Allow your working arm to hang slightly behind your torso line to stretch the bicep long head.',
      'Curl forward and upward without letting your elbow drift prematurely forward.',
      'Lower slowly back into the deep rear stretch.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Biceps Long Head', 'Distal Biceps Tendon']
  },
  {
    id: 'band-reverse-curl',
    name: 'Resistance Band Reverse-Grip Forearm Curl',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Overhand pronated grip curl building forearm extensor balance, brachioradialis mass, and elbow prehab.',
    instructions: [
      'Stand on the center of the band and grip the sides with an overhand (palms-down) grip.',
      'Keep elbows pinned to your ribs and wrists locked straight.',
      'Curl knuckles upward toward your shoulders against the band tension.',
      'Lower slowly over 3 seconds.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Brachioradialis', 'Wrist Extensors', 'Brachialis']
  },
  {
    id: 'band-wrist-curl',
    name: 'Resistance Band Forearm Wrist Curl & Extension',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Forearms braced on thighs while seated, curling and extending the wrists against band tension for false-grip and handstand wrist armor.',
    instructions: [
      'Sit and anchor the band under your feet, resting your forearms flat across your thighs with wrists hanging over your knees.',
      'With palms up, curl your wrists upward as high as possible for 15 reps.',
      'Flip palms down to perform 15 wrist extensions for balanced carpal and tendon health.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Forearm Flexors', 'Forearm Extensors', 'Wrist Stabilizers']
  },
  {
    id: 'band-resisted-pushup',
    name: 'Resistance Band Push-Up (Overload)',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Band draped across your upper back and anchored under both palms, multiplying pressing resistance as you approach lockout.',
    instructions: [
      'Drape a loop band across your upper back and shoulder blades, looping the ends securely under both palms.',
      'Assume a rigid hollow-body push-up plank.',
      'Descend until your chest touches the floor, then press explosively upward against increasing band tension.',
      'Protract your shoulder blades firmly at the top lockout.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Pectoralis Major', 'Triceps Brachii', 'Anterior Deltoids', 'Serratus Anterior']
  },
  {
    id: 'band-standing-chest-press',
    name: 'Resistance Band Standing Chest Press',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Band wrapped behind upper back or anchored at chest height, pressing horizontally forward in a staggered athletic stance.',
    instructions: [
      'Wrap the resistance band around your upper back under your armpits (or anchor behind you at chest height).',
      'Adopt a staggered split stance for stability and hold the band ends at chest level.',
      'Press both hands straight forward until arms are locked out, then bring hands slightly together to squeeze the inner chest.',
      'Return slowly until elbows pass slightly behind your torso.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Pectoralis Major', 'Anterior Deltoids', 'Triceps Brachii', 'Serratus Anterior']
  },
  {
    id: 'band-incline-chest-press',
    name: 'Resistance Band Low-to-High Incline Chest Press',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Stepping on the band with your back foot and pressing upward at a 45-degree angle to target the upper clavicular chest.',
    instructions: [
      'Step your rear foot onto the band in a split stance and bring the band ends up beside your shoulders.',
      'Press the band upward and forward at a 45-degree incline angle.',
      'Bring hands together at the top of the press and squeeze the upper chest.',
      'Lower under control back to shoulder level.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Upper Pectorals (Clavicular Head)', 'Anterior Deltoids', 'Triceps']
  },
  {
    id: 'band-decline-chest-press',
    name: 'Resistance Band High-to-Low Decline Chest Press',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Band anchored high behind you, pressing downward and forward at a 30-degree decline angle to sculpt the lower pectoral line and dip power.',
    instructions: [
      'Anchor the band high on a pull-up bar or door behind you and step forward into a split stance.',
      'Start with elbows bent and hands near your armpits.',
      'Press downward and forward at a 35-degree angle until hands meet in front of your lower chest/hips.',
      'Squeeze lower pecs hard for 1 second.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Lower Pectorals (Costal Fibers)', 'Triceps', 'Serratus Anterior']
  },
  {
    id: 'band-chest-flye',
    name: 'Resistance Band Standing Chest Flye',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Band anchored behind torso at chest height, sweeping wide arms together in a tree-hugging arc for deep pectoral isolation.',
    instructions: [
      'Anchor the band behind your back at mid-chest height and step forward.',
      'Hold ends with arms outstretched in a wide arc and a slight fixed bend in your elbows.',
      'Sweep your hands together in front of your sternum as if hugging a wide barrel.',
      'Squeeze your inner chest forcefully for 2 seconds before opening slowly.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Pectoralis Major (Sternal)', 'Anterior Deltoids']
  },
  {
    id: 'band-low-to-high-chest-flye',
    name: 'Resistance Band Upper Chest Low-to-High Flye',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Standing on the band with feet wide, scooping straight arms upward and inward to chin height to carve the upper chest shelf.',
    instructions: [
      'Stand with feet wide on the band, holding ends beside your outer thighs with palms facing forward/up.',
      'Keeping elbows softly locked, scoop your hands upward and inward in a converging arc until palms meet at chin level.',
      'Hold the upper chest contraction for 1 second, then lower slowly.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Clavicular Pectoralis Major', 'Anterior Deltoids', 'Biceps Short Head']
  },
  {
    id: 'band-crossover-press',
    name: 'Resistance Band Single-Arm Crossover Chest Flye',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Unilateral chest flye pulling the band across the midline of your sternum for maximal peak pectoral adduction.',
    instructions: [
      'Stand sideways to a chest-height band anchor and grab the band with your inside hand.',
      'Step away to create tension and sweep your arm across your chest past the center of your sternum.',
      'Hold the fully shortened pectoral position across your body for 2 seconds.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Inner & Sternal Pectorals', 'Anterior Deltoid', 'Core Anti-Rotation']
  },
  {
    id: 'band-serratus-punch',
    name: 'Resistance Band Serratus Anterior Punch (Planche Protraction)',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Band wrapped around upper back with arms locked straight, protracting shoulder blades forward to build the serratus strength needed for Planche.',
    instructions: [
      'Wrap a resistance band around your upper shoulder blades and hold the ends with straight locked arms in front of you.',
      'Without bending your elbows at all, push your knuckles 3–4 inches further forward by rounding and protracting your shoulder blades.',
      'Hold max scapular protraction for 2 seconds, then retract and repeat.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Serratus Anterior', 'Pectoralis Minor', 'Anterior Deltoids']
  },
  {
    id: 'band-pallof-press',
    name: 'Resistance Band Pallof Press (Anti-Rotation Core)',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Standing sideways to the anchor and pressing hands straight out from the sternum to resist rotational torque.',
    instructions: [
      'Anchor band at chest height and stand sideways with feet shoulder-width apart.',
      'Hold the band with both hands interlaced against the center of your sternum under strong tension.',
      'Press your arms straight out in front of your chest without allowing your hips or shoulders to twist.',
      'Hold the extended position for 2 seconds, then return to your sternum.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Transverse Abdominis', 'Internal & External Obliques', 'Gluteal Stabilizers']
  },
  {
    id: 'band-woodchopper',
    name: 'Resistance Band Diagonal Woodchopper',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'High-to-low or low-to-high rotational core chop transferring explosive rotational power through the hips and obliques.',
    instructions: [
      'Anchor the band high on a bar (for high-to-low) or low on a post (for low-to-high).',
      'Grip the band with both hands and keep your arms extended.',
      'Rotate your torso diagonally across your body while pivoting on your back foot.',
      'Control the eccentric return without letting the band snap you back.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['External & Internal Obliques', 'Rectus Abdominis', 'Hips', 'Shoulders']
  },
  {
    id: 'band-kneeling-crunch',
    name: 'Resistance Band Kneeling Ab Crunch (High Anchor)',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Kneeling below a high-anchored band, holding the band ends beside your ears and flexing your spine to load the six-pack abs.',
    instructions: [
      'Anchor a medium/heavy band high overhead and kneel on a mat facing away or toward the anchor.',
      'Hold both sides of the band next to your temples or collarbone.',
      'Keep your hips stationary and curl your ribcage downward toward your pelvis, rounding the upper and mid spine.',
      'Exhale completely and crunch your abs hard for 2 seconds before rising slowly.'
    ],
    progressionLevel: 2,
    defaultReps: 15,
    targetMuscles: ['Rectus Abdominis', 'External Obliques']
  },
  {
    id: 'band-standing-oblique-side-bend',
    name: 'Resistance Band Standing Oblique Side Bend',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Stepping one foot on a heavy band and laterally flexing the torso away from the band to target the lateral obliques and quadratus lumborum.',
    instructions: [
      'Step your right foot onto a heavy loop band and grip the band low in your right hand.',
      'Stand tall with your left hand behind your head.',
      'Allow the band to pull your right shoulder slightly down, then contract your left obliques to bend laterally and return upright.',
      'Avoid twisting forward or backward; move strictly in the side plane.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['External & Internal Obliques', 'Quadratus Lumborum', 'Erector Spinae']
  },
  {
    id: 'band-bicycle-crunch',
    name: 'Resistance Band Resisted Bicycle Crunch (Feet Looped)',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Mini band or tied loop around the arches of both feet while performing slow bicycle crunches to overload the hip flexors and lower abs.',
    instructions: [
      'Lie on your back and loop a light band around the soles/insteps of both feet.',
      'Lift shoulder blades off the floor in a hollow crunch with hands by your temples.',
      'Extend one leg straight out against the band while driving the opposite knee in and touching it with the opposite elbow.',
      'Hold each cross-body crunch for 1 full second.'
    ],
    progressionLevel: 2,
    defaultReps: 16,
    targetMuscles: ['Rectus Abdominis', 'Obliques', 'Iliopsoas (Hip Flexors)']
  },
  {
    id: 'band-dead-bug',
    name: 'Resistance Band Hollow Body Dead Bug',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Holding an anchored band overhead with straight arms to engage the lats while extending alternating legs in a strict lower-back-glued dead bug.',
    instructions: [
      'Lie on your back with a band anchored behind your head; pull the band down to chest level with straight arms.',
      'Press your lower back flat into the floor and lift knees to a 90-degree tabletop position.',
      'Slowly extend one leg until your heel hovers 2 inches off the floor while maintaining constant straight-arm lat tension.',
      'Return leg to center and alternate sides.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Transverse Abdominis', 'Rectus Abdominis', 'Latissimus Dorsi', 'Hip Flexors']
  },
  {
    id: 'band-squat',
    name: 'Resistance Band Front Squat',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Stepping on the band and racking the top loop across your collarbones/front delts for ascending-resistance squats.',
    instructions: [
      'Stand feet shoulder-width apart on the loop band and rack the top loop across your front shoulders.',
      'Keep elbows pointed forward and chest upright as you squat deep below parallel.',
      'Drive powerfully through your mid-foot against maximum band tension at the top.'
    ],
    progressionLevel: 2,
    defaultReps: 15,
    targetMuscles: ['Quadriceps', 'Gluteus Maximus', 'Core Bracing']
  },
  {
    id: 'band-romanian-deadlift',
    name: 'Resistance Band Romanian Deadlift (RDL)',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Standing on a doubled heavy band and hinging at the hips to overload the hamstrings, glutes, and lower back.',
    instructions: [
      'Stand with both feet on a doubled-up heavy loop band so the two end loops sit beside your ankles.',
      'Hinge down with a flat spine, grab both loops, and stand tall to establish tension.',
      'Push your hips straight backward with a soft 15-degree knee bend until you feel a deep hamstring stretch.',
      'Drive hips forward and squeeze glutes hard at lockout.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Hamstrings', 'Gluteus Maximus', 'Erector Spinae', 'Forearm Grip']
  },
  {
    id: 'band-sumo-deadlift',
    name: 'Resistance Band Wide-Stance Sumo Deadlift',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Wide sumo stance stepping on the outer edges of the band, pulling from the center to target glutes, inner thighs, and quads.',
    instructions: [
      'Take a wide sumo stance on the band with toes pointed out at 45 degrees.',
      'Squat down with an upright torso and grasp the center of the band between your legs.',
      'Push the floor apart with your feet and stand tall to full hip extension.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Gluteus Maximus', 'Adductors', 'Quadriceps', 'Hamstrings']
  },
  {
    id: 'band-good-morning',
    name: 'Resistance Band Good Morning',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Standing on the band with the top loop draped across your upper traps, hinging at the hips to build posterior chain and spinal erector armor.',
    instructions: [
      'Stand feet hip-width on the center of the band and drape the other end across your upper traps behind your neck.',
      'Hold the band sides lightly near your chest for comfort.',
      'With soft knees, hinge your hips deeply backward until your torso is nearly parallel to the floor.',
      'Drive hips forward and squeeze glutes at upright lockout.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Hamstrings', 'Gluteus Maximus', 'Erector Spinae']
  },
  {
    id: 'band-bulgarian-split-squat',
    name: 'Resistance Band Split Squat / Lunge',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Looping the band under your front foot and across your shoulders or in your hands to overload single-leg split squats.',
    instructions: [
      'Step into a split lunge stance with the band anchored under the center of your front foot.',
      'Loop the top of the band over your shoulders or hold both sides tightly at hip level.',
      'Lower straight down until your back knee hovers an inch above the floor.',
      'Drive through your front heel against the band resistance to return to the top.'
    ],
    progressionLevel: 2,
    defaultReps: 10,
    targetMuscles: ['Quadriceps', 'Gluteus Maximus', 'Gluteus Medius', 'Hamstrings']
  },
  {
    id: 'band-lying-leg-curl',
    name: 'Resistance Band Prone Hamstring Leg Curl',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Lying face down with the band anchored low and looped around your heels, curling heels toward glutes for direct hamstring isolation.',
    instructions: [
      'Anchor the band low to a post or heavy furniture leg and loop the free end around one or both heels.',
      'Lie face down on the floor and scoot forward until the band is taut with legs straight.',
      'Keep your hips pressed flat into the mat and curl your heels up toward your glutes.',
      'Squeeze your hamstrings hard for 1 second at 90 degrees before lowering slowly.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Biceps Femoris', 'Semitendinosus', 'Semimembranosus']
  },
  {
    id: 'band-seated-leg-extension',
    name: 'Resistance Band Quad Leg Extension & TKE',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Terminal knee extension (TKE) or seated leg extension against band tension to isolate the vastus medialis (VMO) and bulletproof the knees.',
    instructions: [
      'Anchor a band at knee height around a post and loop the other end behind your knee (for standing TKE) or around your ankle (while seated on a chair).',
      'Start with the knee bent at 30–90 degrees.',
      'Extend and lock the knee completely straight, squeezing the inner quad teardrop (VMO) for 2 seconds.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Quadriceps (Vastus Medialis / VMO)', 'Rectus Femoris', 'Patellar Tendon']
  },
  {
    id: 'band-glute-bridge',
    name: 'Resistance Band Glute Bridge & Hip Thrust',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Band placed above knees or anchored across hips while bridging upward to fire the gluteus maximus and medius.',
    instructions: [
      'Lie on your back with knees bent and feet flat on the floor, placing a band just above your knees.',
      'Push your knees outward against the band tension.',
      'Drive through your heels and elevate your hips until thighs and torso form a straight line.',
      'Squeeze glutes hard at the apex for 2 seconds before lowering.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Gluteus Maximus', 'Gluteus Medius', 'Hamstrings']
  },
  {
    id: 'band-standing-kickback',
    name: 'Resistance Band Standing Glute Kickback',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Band looped around both ankles while standing, extending one leg straight backward to isolate the upper and lower glutes.',
    instructions: [
      'Place a loop band around both ankles and hold onto a wall or bar for balance.',
      'Brace your core so your lower back does not arch.',
      'Kick one leg straight backward and slightly outward, squeezing the glute at full hip extension for 1 second.',
      'Return slowly without touching the working foot to the floor between reps.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Gluteus Maximus', 'Gluteus Medius', 'Hamstrings']
  },
  {
    id: 'band-lateral-monster-walk',
    name: 'Resistance Band Lateral Monster Walk',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Band looped around ankles or above knees, stepping laterally in an athletic quarter-squat to ignite the hip abductors.',
    instructions: [
      'Place a band around your ankles or just above your knees.',
      'Drop into an athletic quarter-squat stance, keeping constant wide tension on the band.',
      'Take controlled lateral steps to the right, then reverse to the left.',
      'Keep toes pointed straight ahead without letting knees cave inward.'
    ],
    progressionLevel: 1,
    defaultReps: 16,
    targetMuscles: ['Gluteus Medius', 'Hip Abductors', 'Tensor Fasciae Latae']
  },
  {
    id: 'band-hip-flexor-march',
    name: 'Resistance Band Standing Hip Flexor March (L-Sit & V-Sit Compression)',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Looping a band around both feet and marching one knee high above hip level to build the raw psoas compression needed for L-Sits and V-Sits.',
    instructions: [
      'Stand tall and loop a light-to-medium band around the insteps of both feet.',
      'Brace your abs and drive one knee straight up as high above hip level as possible against the band.',
      'Hold the top knee-high position for 2 full seconds without leaning backward.',
      'Lower with control and repeat on the other leg.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Iliopsoas (Hip Flexors)', 'Rectus Femoris', 'Lower Rectus Abdominis']
  },
  {
    id: 'band-calf-raise',
    name: 'Resistance Band Calf Raise & Ankle Prehab',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Seated or standing calf plantarflexion against heavy band tension to build calf endurance and Achilles tendon resilience.',
    instructions: [
      'Sit with legs extended and loop a heavy band around the ball of your foot, holding the ends taut.',
      'Point your toes as far forward as possible against the band and pause for 2 seconds.',
      'Slowly allow your toes to flex back toward your shin for a deep calf stretch.'
    ],
    progressionLevel: 1,
    defaultReps: 20,
    targetMuscles: ['Gastrocnemius', 'Soleus', 'Tibialis Posterior', 'Achilles Tendon']
  },
  {
    id: 'band-dislocate',
    name: 'Resistance Band Shoulder Dislocate (Pass-Through)',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Dynamic shoulder mobility exercise sweeping a taut band with straight arms in a 360-degree arc from thighs to lower back.',
    instructions: [
      'Hold the band with a wide overhand grip in front of your hips.',
      'Keeping elbows completely locked straight, sweep your arms overhead in a smooth circular arc.',
      'Continue until the band contacts your lower back, then reverse the arc back to the front.',
      'Never bend your elbows; widen your grip if tightness occurs.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Shoulder Mobility', 'Pectoral Stretch', 'Subscapularis', 'Thoracic Spine']
  },
  {
    id: 'band-external-rotation',
    name: 'Resistance Band Rotator Cuff External Rotation',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Elbow pinned at 90 degrees against the ribs, rotating the forearm outward against light elastic tension to armor the rotator cuff.',
    instructions: [
      'Anchor a light band at elbow height and stand sideways to the anchor.',
      'Pin your working elbow at a strict 90-degree angle against your ribcage.',
      'Rotate your forearm outward away from your abdomen without letting your elbow drift.',
      'Control the return slowly.'
    ],
    progressionLevel: 1,
    defaultReps: 15,
    targetMuscles: ['Infraspinatus', 'Teres Minor', 'Posterior Shoulder Capsule']
  },
  {
    id: 'band-overhead-y-raise',
    name: 'Resistance Band Overhead Y-Raise & Scapular Wall Slide',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Loop band around wrists while sliding forearms upward into an overhead Y-shape to fire the lower traps and serratus anterior.',
    instructions: [
      'Place a light band around your wrists and press your hands outward to create constant tension.',
      'Keep forearms parallel at eye level and slide your arms upward into an overhead Y position.',
      'Pause at the top while depressing and upwardly rotating the scapulae.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Lower Trapezius', 'Serratus Anterior', 'Lateral & Posterior Deltoids']
  },
  {
    id: 'band-assisted-pullup',
    name: 'Resistance Band-Assisted Pull-Up',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Loop band anchored on the pull-up bar under one knee or foot to build strict full-range vertical pulling mechanics.',
    instructions: [
      'Loop a medium or heavy resistance band securely around the center of the pull-up bar.',
      'Place one knee or foot into the bottom loop.',
      'Hang with full arm extension and active depressed shoulder blades.',
      'Drive elbows down and back smoothly until your chin clears the bar, then control the 3-second descent.'
    ],
    progressionLevel: 1,
    defaultReps: 10,
    targetMuscles: ['Latissimus Dorsi', 'Biceps Brachii', 'Rhomboids', 'Middle Trapezius']
  },
  {
    id: 'band-assisted-muscleup',
    name: 'Resistance Band-Assisted Bar Muscle-Up',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Band looped on the bar providing bottom acceleration so you can master the explosive chest-over-bar transition and wrist turnover.',
    instructions: [
      'Anchor a loop band over the bar and step one or both feet inside the bottom loop.',
      'Grip the bar with a firm false or high overhand grip.',
      'Pull explosively toward your lower sternum; as the band recoils, lean your chest aggressively over the bar.',
      'Press out from the straight bar dip into full arm lockout.'
    ],
    progressionLevel: 3,
    defaultReps: 5,
    targetMuscles: ['Latissimus Dorsi', 'Pectorals', 'Triceps', 'Anterior Deltoids', 'Forearms']
  },
  {
    id: 'band-assisted-dip',
    name: 'Resistance Band-Assisted Parallel Bar Dip',
    category: 'resistance band',
    difficulty: 'beginner',
    equipment: 'resistance band',
    description: 'Resistance band stretched across parallel bars under your knees to deload the deep bottom stretch of the dip.',
    instructions: [
      'Stretch a loop band horizontally across both parallel bars.',
      'Mount the bars and rest your knees on top of the stretched band.',
      'Descend into a clean 90-degree dip with slight forward torso lean.',
      'Drive upward through your palms to full elbow lockout.'
    ],
    progressionLevel: 1,
    defaultReps: 10,
    targetMuscles: ['Triceps Brachii', 'Lower Pectorals', 'Anterior Deltoids']
  },
  {
    id: 'band-assisted-frontlever',
    name: 'Resistance Band-Assisted Front Lever Hold',
    category: 'resistance band',
    difficulty: 'advanced',
    equipment: 'resistance band',
    description: 'Band girth-hitched from the bar to your hips, reducing lever torque so you can hold a straight-arm horizontal Front Lever.',
    instructions: [
      'Girth-hitch a resistance band around the pull-up bar and place the loop around your waist/hips.',
      'Hang with completely locked straight arms and pull your body into a laser-straight horizontal line.',
      'Depress and retract your scapulae while locking knees and pointing toes.',
      'Hold statically without piking at the hips.'
    ],
    progressionLevel: 4,
    isHold: true,
    defaultHoldSec: 12,
    targetMuscles: ['Latissimus Dorsi', 'Teres Major', 'Posterior Deltoids', 'Rectus Abdominis']
  },
  {
    id: 'band-assisted-planche',
    name: 'Resistance Band-Assisted Planche Hold',
    category: 'resistance band',
    difficulty: 'advanced',
    equipment: 'resistance band',
    description: 'Overhead band anchored to your hips on parallettes or floor, assisting straight-arm forward shoulder lean and full Planche alignment.',
    instructions: [
      'Loop a resistance band from an overhead bar down around your waist/hips.',
      'Place hands on parallettes or floor, leaning your shoulders far forward past your wrists.',
      'Float your legs into a straddle or full horizontal Planche hold.',
      'Push the floor away with maximal scapular protraction and locked elbows.'
    ],
    progressionLevel: 4,
    isHold: true,
    defaultHoldSec: 10,
    targetMuscles: ['Anterior Deltoids', 'Serratus Anterior', 'Biceps Tendons', 'Core']
  },
  {
    id: 'band-assisted-backlever',
    name: 'Resistance Band-Assisted Back Lever Hold',
    category: 'resistance band',
    difficulty: 'intermediate',
    equipment: 'resistance band',
    description: 'Band supporting the hips from overhead while suspended face-down in a horizontal Back Lever to condition bicep tendons and anterior delts.',
    instructions: [
      'Loop a resistance band from the center of the bar around your hips.',
      'Skin-the-cat backward through your arms into a face-down horizontal body position.',
      'Protract your shoulder blades, squeeze glutes, and lock your elbows completely straight.',
      'Hold the horizontal line for time before returning safely.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 12,
    targetMuscles: ['Anterior Deltoids', 'Biceps Brachii Tendons', 'Pectoralis Major', 'Erector Spinae']
  },
  {
    id: 'band-assisted-onearm-chinup',
    name: 'Resistance Band-Assisted One-Arm Chin-Up',
    category: 'resistance band',
    difficulty: 'advanced',
    equipment: 'resistance band',
    description: 'Gripping the bar with one working arm while the opposite hand pulls a hanging band for calibrated unilateral assistance.',
    instructions: [
      'Grip the pull-up bar with a supinated or neutral grip using your working arm.',
      'With your assist hand, grasp a band looped over the bar at chest height.',
      'Depress your working scapula and pull until your chin clears the bar.',
      'Lower under strict 3-second eccentric control.'
    ],
    progressionLevel: 5,
    defaultReps: 4,
    targetMuscles: ['Unilateral Latissimus Dorsi', 'Biceps Brachii', 'Brachialis', 'Rotator Cuff']
  },

  // ==================== TOWEL EXERCISES (SLIDING, ANCHOR & GRIP TRAINING) ====================
  {
    id: 'towel-hammer-curl',
    name: 'Towel Hammer Curl',
    category: 'towel',
    difficulty: 'beginner',
    equipment: 'towel',
    description: 'Looping a durable towel through a weighted backpack or under foot, using a vertical neutral hammer grip to forge forearm thickness and brachialis strength.',
    instructions: [
      'Loop a folded bath towel through the top handle of a weighted backpack or under your lead foot.',
      'Grasp each side of the towel tightly with a neutral hammer grip (thumbs pointing upward).',
      'Pin elbows tight against your ribs and curl your hands upward toward chest height.',
      'Squeeze forearms and brachialis hard at peak contraction for 1 second, then lower slowly under control.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Brachioradialis', 'Brachialis', 'Biceps Brachii', 'Finger Flexors'],
    safetyNote: 'Ensure the towel fabric is sturdy and grip firmly without letting hands slip.'
  },
  {
    id: 'towel-door-row',
    name: 'Towel Doorframe / Anchor Row',
    category: 'towel',
    difficulty: 'beginner',
    equipment: 'towel',
    description: 'Towel wrapped around a closed doorframe, doorknob, or sturdy pillar, leaning back to perform bodyweight horizontal rows.',
    instructions: [
      'Tie a knot in the center of a towel and wedge it firmly over the top of a closed door, or loop it securely around a sturdy post/pillar.',
      'Grip the two loose towel ends firmly, walk your feet forward, and lean back into an angled plank.',
      'Retract your shoulder blades and drive your elbows backward past your torso until your chest nears the anchor.',
      'Pause at the peak of the row, then lower slowly with straight arm lockout.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Latissimus Dorsi', 'Rhomboids', 'Middle Trapezius', 'Biceps', 'Forearms'],
    safetyNote: 'Always pull toward the door frame in the direction the door closes so the door cannot swing open.'
  },
  {
    id: 'towel-pullup',
    name: 'Towel Pull-Up (Grip Crusher)',
    category: 'towel',
    difficulty: 'advanced',
    equipment: 'towel',
    description: 'Draping one or two towels over a pull-up bar and pulling your entire bodyweight up using only vertical cloth fabric grips.',
    instructions: [
      'Drape two small towels (or one long bath towel) over the pull-up bar about shoulder-width apart.',
      'Grab both towel ends tightly with a crush grip, suspending in a dead hang with engaged scapulae.',
      'Pull forcefully, driving elbows down and back until your chin clears your knuckles.',
      'Lower under strict 3-second eccentric control without swinging.'
    ],
    progressionLevel: 4,
    defaultReps: 6,
    targetMuscles: ['Forearm Flexors', 'Lats', 'Biceps', 'Brachioradialis', 'Core'],
    safetyNote: 'Extremely demanding on hand and tendon grip strength. Warm up wrists and fingers thoroughly.'
  },
  {
    id: 'towel-archer-row',
    name: 'Towel Archer Row (Single-Arm Focus)',
    category: 'towel',
    difficulty: 'intermediate',
    equipment: 'towel',
    description: 'Anchored towel row where one arm pulls close to the ribs while the opposite arm extends straight out as an archer guide.',
    instructions: [
      'Hold both towel ends while leaning back at a 45-degree angle.',
      'Pull primarily with the working arm, driving that elbow back while the assist arm glides straight outward.',
      'Keep your core braced and hips square to prevent twisting.',
      'Return smoothly to full arm extension and alternate sides.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Latissimus Dorsi', 'Posterior Deltoid', 'Biceps', 'Obliques']
  },
  {
    id: 'towel-floor-hamstring-curl',
    name: 'Towel Sliding Hamstring Curl',
    category: 'towel',
    difficulty: 'intermediate',
    equipment: 'towel',
    description: 'Lying on your back with heels on a folded towel atop a smooth wood or tile floor, bridging hips high and sliding heels in and out.',
    instructions: [
      'Lie on your back on a smooth floor with a folded towel directly under both heels.',
      'Press through your heels and elevate your hips into a glute bridge.',
      'Keep your hips raised high while slowly extending both legs out until nearly straight.',
      'Contract your hamstrings powerfully to drag your heels back in toward your glutes.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Biceps Femoris', 'Semitendinosus', 'Gluteus Maximus', 'Erector Spinae'],
    safetyNote: 'Do not allow your lower back or hips to sag to the floor during the extension phase.'
  },
  {
    id: 'towel-sliding-chest-flye',
    name: 'Towel Sliding Floor Chest Flye',
    category: 'towel',
    difficulty: 'intermediate',
    equipment: 'towel',
    description: 'Kneeling on a smooth floor with towels under hands, sliding arms horizontally outward and squeezing back inward with pure pectoral power.',
    instructions: [
      'Start in a kneeling push-up plank on a smooth floor with a small towel under each palm.',
      'With elbows slightly bent, slide both hands slowly outward to the sides in a wide chest flye arc.',
      'Lower your chest to just 2-3 inches above the floor under strict control.',
      'Adduct arms inward, driving palms toward each other to pull your torso back up.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Pectoralis Major (Sternal & Clavicular)', 'Anterior Deltoids', 'Core Stabilizers']
  },
  {
    id: 'towel-sliding-archer-pushup',
    name: 'Towel Sliding Archer Push-Up',
    category: 'towel',
    difficulty: 'intermediate',
    equipment: 'towel',
    description: 'Push-up with one hand on floor and one hand on a towel; slide the towel hand laterally outward as the base arm bends into a deep single push-up.',
    instructions: [
      'Assume a wide push-up plank with one hand on a towel and the other planted firmly on the floor.',
      'Descend toward the planted hand while smoothly sliding the towel hand straight out to the side.',
      'At bottom depth, press powerfully through the base hand while dragging the slider hand back in.',
      'Complete full reps on one side before switching hands.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Pectoralis Major', 'Triceps Brachii', 'Anterior Deltoid', 'Serratus Anterior']
  },
  {
    id: 'towel-sliding-ab-pike',
    name: 'Towel Sliding Ab Pike',
    category: 'towel',
    difficulty: 'intermediate',
    equipment: 'towel',
    description: 'Plank position with toes on a towel on a slick floor, hinging at hips to drag toes toward hands into a high vertical V-pike.',
    instructions: [
      'Start in a straight-arm high plank with both feet together on a towel.',
      'Keeping legs completely straight and elbows locked, pull your toes toward your wrists by flexing the hips.',
      'Elevate hips as high as possible into an inverted V position.',
      'Slide slowly back out into a hollow body plank under full control.'
    ],
    progressionLevel: 3,
    defaultReps: 10,
    targetMuscles: ['Rectus Abdominis', 'Hip Flexors', 'Serratus Anterior', 'Anterior Deltoids']
  },
  {
    id: 'towel-sliding-ab-rollout',
    name: 'Towel Sliding Ab Rollout / Body Saw',
    category: 'towel',
    difficulty: 'intermediate',
    equipment: 'towel',
    description: 'Kneeling on floor with hands on a towel, sliding arms forward into a deep long-lever hollow plank.',
    instructions: [
      'Kneel on a yoga mat or pad with hands resting on a folded towel on the smooth floor in front of you.',
      'Brace your abdominal wall in a posterior pelvic tilt (hollow body).',
      'Slide hands forward away from knees, lowering your torso toward the floor without arching your lower back.',
      'Use lats and core to pull the towel back to the starting position.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Rectus Abdominis', 'Transverse Abdominis', 'Latissimus Dorsi', 'Hip Flexors'],
    safetyNote: 'Only roll out as far as you can maintain a rigid, hollow spine with zero lower back sagging.'
  },
  {
    id: 'towel-sliding-mountain-climbers',
    name: 'Towel Sliding Mountain Climbers',
    category: 'towel',
    difficulty: 'beginner',
    equipment: 'towel',
    description: 'Smooth low-impact friction mountain climbers with each foot on a towel, driving knees rapidly toward the chest.',
    instructions: [
      'Hold a locked-out push-up position with each foot placed on a small towel on smooth flooring.',
      'Slide one knee rapidly forward toward your chest while keeping hips low and core braced.',
      'Slide that leg back while simultaneously sliding the opposite knee forward in a running motion.',
      'Maintain an unbroken rhythmic tempo with quiet feet.'
    ],
    progressionLevel: 1,
    defaultReps: 24,
    targetMuscles: ['Hip Flexors', 'Rectus Abdominis', 'Shoulder Girdle', 'Cardiovascular System']
  },
  {
    id: 'towel-sliding-reverse-lunge',
    name: 'Towel Sliding Reverse Lunge',
    category: 'towel',
    difficulty: 'beginner',
    equipment: 'towel',
    description: 'Standing tall with rear toes on a towel, sliding the back leg into a deep knee-hover lunge and pulling up with the front heel.',
    instructions: [
      'Stand with feet hip-width apart, one foot planted and the rear foot rested on a towel.',
      'Slide the towel foot backward into a deep reverse lunge until the back knee hovers an inch off the floor.',
      'Keep 80% of your weight driven through the front foot and heel.',
      'Contract your front quad and glute to slide the towel foot back to standing.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Quadriceps', 'Gluteus Maximus', 'Hamstrings', 'Core Balance']
  },
  {
    id: 'towel-sliding-cossack-squat',
    name: 'Towel Sliding Cossack Squat (Lateral Slide)',
    category: 'towel',
    difficulty: 'intermediate',
    equipment: 'towel',
    description: 'Slide one leg out to the side on a towel while sitting deep into a single-leg squat on the supporting heel.',
    instructions: [
      'Stand upright with one foot on a towel on a slick floor.',
      'Slide the towel foot directly sideways while sitting your hips back and down over the standing leg.',
      'Keep the sliding leg straight with toes turned up, reaching full adductor mobility.',
      'Drive through the working heel and pull inward with adductors to return to top.'
    ],
    progressionLevel: 3,
    defaultReps: 8,
    targetMuscles: ['Adductors', 'Quadriceps', 'Gluteus Medius', 'Ankle Mobility']
  },
  {
    id: 'towel-tricep-extension',
    name: 'Towel Overhead Tricep Extension',
    category: 'towel',
    difficulty: 'intermediate',
    equipment: 'towel',
    description: 'Towel anchored above head height on a door or post, leaning forward and extending forearms to isolate the triceps.',
    instructions: [
      'Grip both ends of an anchored towel with arms overhead, facing away from the anchor.',
      'Lean forward into a suspended 45-degree angle with elbows pointed forward.',
      'Bend elbows allowing hands to drift back past your head to get a deep tricep stretch.',
      'Extend forearms powerfully, pushing hands away from head until elbows are fully locked.'
    ],
    progressionLevel: 2,
    defaultReps: 12,
    targetMuscles: ['Triceps Brachii (Long Head & Lateral Head)', 'Core Stabilizers']
  },
  {
    id: 'towel-leg-resisted-bicep-curl',
    name: 'Towel Leg-Resisted Bicep Curl',
    category: 'towel',
    difficulty: 'beginner',
    equipment: 'towel',
    description: 'Seated or standing, looping towel under thigh or foot, using your own leg pressure as dynamic adjustable resistance for biceps.',
    instructions: [
      'Sit on a chair or bench, looping a towel under the back of your thigh or bottom of your foot.',
      'Grasp towel ends firmly with an underhand supinated grip.',
      'Curl upward with your arms while pushing downward with your leg to provide calibrated resistance.',
      'Fight the tension both on the way up and on the slow descent.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Biceps Brachii', 'Brachialis', 'Forearms']
  },
  {
    id: 'towel-assisted-onearm-pullup',
    name: 'Towel-Assisted One-Arm Pull-Up (Offset)',
    category: 'towel',
    difficulty: 'advanced',
    equipment: 'towel',
    description: 'Working hand grips the pull-up bar directly while non-working hand grips a hanging towel lower down for fractional assistance.',
    instructions: [
      'Grip the pull-up bar supinated or pronated with your primary working arm.',
      'Drape a towel over the bar and hold it with your non-working hand at chin or chest height.',
      'Pull aggressively with the bar arm while using minimal assistance from the towel hand.',
      'Lower under 3-second control. Progressively lower your grip on the towel to reduce assistance.'
    ],
    progressionLevel: 4,
    defaultReps: 4,
    targetMuscles: ['Latissimus Dorsi', 'Unilateral Biceps', 'Brachialis', 'Rotator Cuff']
  },
  {
    id: 'towel-isometric-deadhang',
    name: 'Towel Grip Isometric Dead Hang',
    category: 'towel',
    difficulty: 'intermediate',
    equipment: 'towel',
    description: 'Hanging from a towel draped over a bar to develop crushing hand, wrist, and forearm isometric endurance.',
    instructions: [
      'Drape two towels over a sturdy bar and squeeze the cloth firmly in each hand.',
      'Step off the box and hang freely with active shoulders depressed away from ears.',
      'Maintain an unyielding crushing grip without letting fabric slip through fingers.',
      'Hold for maximum time under tension.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 25,
    targetMuscles: ['Finger Flexors', 'Brachioradialis', 'Lats', 'Rotator Cuff']
  },
  {
    id: 'towel-shoulder-dislocate',
    name: 'Towel Shoulder Pass-Through / Dislocate',
    category: 'towel',
    difficulty: 'beginner',
    equipment: 'towel',
    description: 'Holding a taut towel with wide straight arms, rotating in a smooth arc overhead and behind the back for shoulder health.',
    instructions: [
      'Hold a towel taut with a wide overhand grip in front of your thighs.',
      'Keeping elbows completely locked straight, sweep arms overhead and back in a continuous circular arc.',
      'Touch the towel to your lower back, then reverse the arc back to the front.',
      'Widen your grip if your elbows bend or shoulders feel pinched.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Anterior Deltoids', 'Pectorals', 'Thoracic Spine', 'Subscapularis']
  },
  {
    id: 'towel-seated-row',
    name: 'Towel Seated Foot Row',
    category: 'towel',
    difficulty: 'beginner',
    equipment: 'towel',
    description: 'Sitting tall on the floor with legs extended, looping a towel around the soles of your feet and rowing against isometric leg extension.',
    instructions: [
      'Sit tall on the floor with legs out in front, looping the middle of a towel around your foot soles.',
      'Hold towel ends with an upright spine and shoulders pinned down.',
      'Row elbows backward along your ribs, driving your chest forward and squeezing your back.',
      'Press forward slightly with feet to generate heavy isometric resistance for lats and biceps.'
    ],
    progressionLevel: 1,
    defaultReps: 12,
    targetMuscles: ['Latissimus Dorsi', 'Rhomboids', 'Middle Trapezius', 'Biceps']
  },
  // ============================================================================
  // ADVANCED GYM-TO-HOME REPLACEMENT EXERCISES (BAG HALO, PLATE & BARBELL SWAPS)
  // ============================================================================
  {
    id: 'backpack-bag-halo',
    name: 'Weighted Bag Halo (Plate Halo Replacement)',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Direct home replacement for the gym Weight Plate Halo or Kettlebell Halo. Orbiting a tightly packed weighted backpack 360° around the head builds bulletproof rotator cuffs, 3D deltoids, upper traps, and anti-rotation core stability.',
    instructions: [
      'Pack a backpack tightly so the load does not shift and grip both side panels or top/bottom edges firmly at chest height.',
      'Brace your abs and glutes hard to lock your ribcage down—do not let your lower back arch.',
      'Circle the weighted bag closely around your right ear, behind the base of your skull, and around your left ear back to the front.',
      'Keep your elbows tucked close at the front and open smoothly as the bag passes behind your neck, alternating clockwise and counter-clockwise orbits.'
    ],
    progressionLevel: 4,
    defaultReps: 12,
    targetMuscles: ['Anterior, Lateral & Posterior Deltoids', 'Rotator Cuff', 'Upper Trapezius', 'Obliques', 'Forearms'],
    safetyNote: 'Zip all compartments shut and keep the bag tight so objects cannot shift while orbiting behind your head.'
  },
  {
    id: 'backpack-around-the-world',
    name: 'Weighted Bag 360° Around-the-World (Plate Orbit Replacement)',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Full-radius standing rotational orbit sweeping a heavy backpack from the hips up overhead and down the opposite side, replacing the gym Plate Around-the-World.',
    instructions: [
      'Stand with feet shoulder-width apart holding a loaded backpack with both hands in front of your pelvis.',
      'With slightly bent elbows and an iron core brace, sweep the bag laterally up your right side to full overhead extension.',
      'Continue the circular arc down your left side back to the starting position, then reverse direction.'
    ],
    progressionLevel: 4,
    defaultReps: 10,
    targetMuscles: ['Obliques', 'Shoulders (Full Deltoid)', 'Serratus Anterior', 'Upper Chest', 'Grip']
  },
  {
    id: 'backpack-zercher-good-morning',
    name: 'Backpack Zercher Squat-to-Good-Morning (Barbell Zercher Replacement)',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Heavy posterior-chain and anterior-core compound movement cradling a loaded backpack in the crooks of your elbows like a Barbell Zercher lift.',
    instructions: [
      'Hook a heavily loaded backpack securely in the crooks of both elbows with fists clenched together in front of your sternum.',
      'Perform a deep Zercher squat, driving knees out and keeping your torso upright.',
      'At the top of the squat, hinge at the hips with soft knees into a strict Zercher Good Morning until your torso is near parallel, then snap hips forward.'
    ],
    progressionLevel: 5,
    defaultReps: 8,
    targetMuscles: ['Erector Spinae', 'Glutes', 'Hamstrings', 'Quadriceps', 'Biceps Isometrics', 'Upper Back']
  },
  {
    id: 'backpack-meadows-row',
    name: 'Backpack Staggered Meadows Row (Landmine Row Replacement)',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Replicates the famous gym Landmine Meadows Row using a heavy backpack—pulling with a high, flared elbow angle to target the upper lats, teres major, and rear delts.',
    instructions: [
      'Take a staggered athletic lunge stance and rest your non-working forearm firmly across your front knee.',
      'Grip the top haul handle of a heavy backpack with a pronated overhand grip.',
      'Row the bag explosively upward with your elbow flared out at a 60-degree angle to hammer the upper back and rear deltoids.',
      'Lower under a 3-second eccentric stretch.'
    ],
    progressionLevel: 4,
    defaultReps: 10,
    targetMuscles: ['Upper Latissimus Dorsi', 'Rear Deltoids', 'Rhomboids', 'Middle Trapezius', 'Brachioradialis']
  },
  {
    id: 'backpack-overhead-walking-lunge',
    name: 'Backpack Locked-Arm Overhead Lunge (Plate Overhead Lunge Replacement)',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Direct replacement for the gym Plate Overhead Walking Lunge. Holding a loaded backpack locked out overhead forces extreme scapular upward rotation, core bracing, and unilateral leg power.',
    instructions: [
      'Press a weighted backpack straight overhead and lock out your elbows completely, pushing your shoulders up toward your ears.',
      'Keeping your biceps aligned with your ears and ribs pulled down, step forward into a deep knee-to-floor lunge.',
      'Drive through your front heel to stand tall without letting the overhead bag sway forward.'
    ],
    progressionLevel: 4,
    defaultReps: 12,
    targetMuscles: ['Quadriceps', 'Glutes', 'Shoulders (Deltoids)', 'Upper Trapezius', 'Core Stabilizers']
  },
  {
    id: 'backpack-pullover-hollow-press',
    name: 'Weighted Bag Hollow-Body Pullover (Dumbbell Pullover Replacement)',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Combines a gym Dumbbell Pullover with a gymnastic Hollow Body Hold to stretch and overload the lats, serratus anterior, and upper chest simultaneously.',
    instructions: [
      'Lie on your back, press your lower spine flat into the floor, and float your straight legs 6 inches off the ground in a hollow hold.',
      'Hold a weighted backpack by its sides directly above your chest with a slight, fixed bend in the elbows.',
      'Lower the bag in a slow arc behind your head until it hovers just above the floor, feeling a deep stretch across your lats.',
      'Pull the bag back over your chest using your lats and chest while keeping your lower back glued to the floor.'
    ],
    progressionLevel: 4,
    defaultReps: 10,
    targetMuscles: ['Latissimus Dorsi', 'Serratus Anterior', 'Pectoralis Major', 'Rectus Abdominis']
  },
  {
    id: 'backpack-rotational-clean-press',
    name: 'Weighted Bag Rotational Clean & Press (Sandbag Replacement)',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Explosive full-body rotational power movement ripping a heavy backpack from outside the ankle into a front rack and pressing overhead.',
    instructions: [
      'Place a heavy backpack outside your left foot and hinge down with a flat spine to grip the straps.',
      'Explosively extend your hips and pivot your feet to clean the bag across your body to your right shoulder rack position.',
      'Immediately drive the bag overhead to lockout, then lower under control and alternate sides.'
    ],
    progressionLevel: 5,
    defaultReps: 8,
    targetMuscles: ['Full Body Power', 'Shoulders', 'Obliques', 'Glutes', 'Hamstrings', 'Upper Traps']
  },
  {
    id: 'backpack-cossack-squat',
    name: 'Weighted Bag Deep Cossack Squat (Goblet Lateral Squat Replacement)',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Loaded single-leg lateral squat holding a heavy backpack tightly against the chest like a goblet weight to build hip mobility and unilateral quad/adductor strength.',
    instructions: [
      'Take a wide sumo stance and hug a loaded backpack against your upper chest in a goblet hold.',
      'Shift your weight entirely over your right leg, descending into a full-depth squat while your left leg stays straight with toes pointed up.',
      'Drive through your right heel back to center and repeat on the left side.'
    ],
    progressionLevel: 4,
    defaultReps: 10,
    targetMuscles: ['Quadriceps', 'Adductors', 'Glutes', 'Hamstrings', 'Upper Back']
  },
  {
    id: 'backpack-kneeling-jm-press',
    name: 'Weighted Bag Floor JM Press / Skullcrusher (EZ-Bar Replacement)',
    category: 'backpack',
    difficulty: 'advanced',
    equipment: 'backpack',
    description: 'Home replacement for the EZ-Bar JM Press and Skullcrusher—a hybrid close-grip press and tricep extension using a dense weighted backpack.',
    instructions: [
      'Lie flat on your back holding the sides of a compact, heavy backpack locked out over your upper chest.',
      'Lower the bag in a straight line toward your chin and neck by bending your elbows forward and down while keeping upper arms at a 45-degree angle.',
      'Pause 1 inch above your chin, then fire your triceps to press and extend back to full lockout.'
    ],
    progressionLevel: 4,
    defaultReps: 10,
    targetMuscles: ['Triceps Brachii (All 3 Heads)', 'Anterior Deltoids', 'Inner Pectorals']
  },
  {
    id: 'impossible-dip',
    name: 'Impossible Dip (Vertical Forearm Tricep Lever)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'dip bars',
    description: 'Extreme-leverage calisthenics dip where the torso leans backward rather than forward, forcing the triceps to lift the entire bodyweight through pure elbow extension.',
    instructions: [
      'Support yourself at the top of parallel dip bars with a hollow body and slight backward lean.',
      'Lower slowly by hinges at the elbows only, allowing your elbows to travel forward until your forearms rest nearly horizontal along the bars.',
      'Without leaning your chest forward, press through your palms using pure tricep torque to return to lockout.'
    ],
    progressionLevel: 5,
    defaultReps: 4,
    targetMuscles: ['Triceps Brachii', 'Anterior Deltoids', 'Core', 'Forearms']
  },
  {
    id: 'pelican-push-up',
    name: 'Pelican Push-Up / Hefesto Eccentric Curl',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'Advanced straight-arm-to-deep-shoulder-extension bodyweight curl that builds tendon resilience and peak bicep strength.',
    instructions: [
      'Set up in a forward-leaning plank on parallettes or rings with hands turned out.',
      'Lower into a deep push-up, then allow your shoulders to drift forward as your elbows stay behind your back.',
      'Curl your bodyweight forward and up by flexing your biceps strongly to pull your shoulders back over your hands.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Biceps Brachii', 'Brachialis', 'Anterior Deltoids', 'Pectoralis Major']
  },

  // ==================== ELITE CALISTHENICS SKILLS & ISOMETRIC LEVERS ====================
  {
    id: 'tuck-planche-hold',
    name: 'Tuck Planche Hold',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'parallettes',
    description: 'Foundational floating planche skill with knees tucked tightly to chest and hips elevated level with protracted shoulders.',
    instructions: [
      'Grip parallettes or floor shoulder-width apart and lock your elbows 100% straight.',
      'Lean your shoulders far forward past your wrists while protracting (doming) your upper back.',
      'Float your feet off the ground, tucking knees to chest with hips level with your shoulders.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 15,
    targetMuscles: ['Anterior Deltoids', 'Serratus Anterior', 'Pectoralis Major', 'Biceps Tendons', 'Core']
  },
  {
    id: 'adv-tuck-planche-hold',
    name: 'Advanced Tuck Planche Hold',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'Intermediate-advanced planche skill extending hips to 90 degrees with a completely flat horizontal lower back.',
    instructions: [
      'Establish a strong Tuck Planche with locked elbows and full scapular protraction.',
      'Slowly push your knees backward until your thighs are perpendicular to the floor and your spine is flat.',
      'Lean shoulders further forward to counterbalance the extended center of mass.'
    ],
    progressionLevel: 4,
    isHold: true,
    defaultHoldSec: 12,
    targetMuscles: ['Anterior Deltoids', 'Serratus Anterior', 'Pectoralis Major', 'Biceps Tendons', 'Core']
  },
  {
    id: 'straddle-planche-hold',
    name: 'Straddle Planche Hold',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'High-level straight-arm horizontal hold with legs extended wide in a straddle parallel to the ground.',
    instructions: [
      'Lean deeply forward with locked elbows, protracted scapulae, and posterior pelvic tilt.',
      'Extend both legs out wide into a straddle with locked knees and pointed toes.',
      'Maintain a horizontal bodyline from shoulders to ankles without bending elbows.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 8,
    targetMuscles: ['Anterior Deltoids', 'Serratus Anterior', 'Pectoralis Major', 'Glutes', 'Lower Back', 'Core']
  },
  {
    id: 'full-planche-hold',
    name: 'Full Planche Hold',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'The supreme straight-arm calisthenics pushing skill: floating completely horizontal with legs locked together and elbows straight.',
    instructions: [
      'Plant hands on floor or parallettes, lock elbows completely, and protract your shoulder blades.',
      'Shift your shoulders far ahead of your hands until your legs float up into a straight horizontal line.',
      'Squeeze ankles, knees, glutes, and abs together to hold a laser-straight horizontal bodyline.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 6,
    targetMuscles: ['Anterior Deltoids', 'Pectoralis Major', 'Serratus Anterior', 'Biceps Tendons', 'Glutes', 'Core']
  },
  {
    id: 'full-planche-push-up',
    name: 'Full Planche Push-Up',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'World-class dynamic pushing skill performing full range-of-motion push-ups while floating horizontally in a Full Planche.',
    instructions: [
      'Stabilize a clean horizontal Full Planche with feet together and glutes locked.',
      'Lower your entire horizontal body toward the floor by bending elbows while keeping legs parallel to the earth.',
      'Press powerfully back up to a straight-arm Full Planche lockout without dropping your hips.'
    ],
    progressionLevel: 5,
    defaultReps: 3,
    targetMuscles: ['Anterior Deltoids', 'Pectoralis Major', 'Triceps Brachii', 'Serratus Anterior', 'Core']
  },
  {
    id: 'two-finger-planche-hold',
    name: '2-Finger Planche Hold (Fingertip Planche)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Extreme tendon and straight-arm mastery supporting a horizontal Planche (Straddle or Full) exclusively on index and middle fingers.',
    instructions: [
      'Thoroughly warm up finger flexors, wrists, and elbows before attempting.',
      'Place index and middle fingers on the floor (or thumb + index finger) with joints locked firmly.',
      'Lean forward with maximal scapular protraction and float into a Straddle or Full Planche on 2 fingers per hand.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 5,
    targetMuscles: ['Forearms & Finger Tendons', 'Anterior Deltoids', 'Serratus Anterior', 'Pectoralis Major', 'Core'],
    safetyNote: 'Requires months of progressive fingertip plank and tuck planche conditioning. Stop immediately if you feel sharp finger pulley tension.'
  },
  {
    id: 'one-arm-planche-hold',
    name: 'One-Arm Planche Hold',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Elite unilateral straight-arm balance supporting the entire horizontal body on a single locked arm.',
    instructions: [
      'Enter a wide straddle planche and shift your center of mass directly over your working shoulder and wrist.',
      'Lock the working elbow and depress/protract the working scapula while releasing the non-working hand.',
      'Hold horizontal equilibrium with intense oblique, glute, and anterior deltoid tension.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 5,
    targetMuscles: ['Anterior Deltoids', 'Pectoralis Major', 'Obliques', 'Triceps', 'Forearms']
  },
  {
    id: 'maltese-planche-hold',
    name: 'Maltese Planche Hold (Wide-Arm Horizontal Lever)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'Ultra-wide straight-arm horizontal planche with hands placed far outside the hips, placing maximal torque on the chest, front delts, and biceps tendons.',
    instructions: [
      'Place hands 2x shoulder-width apart on floor or low parallettes with fingers turned out.',
      'Lock elbows and lean shoulders forward until your body floats horizontally just inches off the floor.',
      'Squeeze chest and anterior delts to hold the wide-arm horizontal suspension.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 5,
    targetMuscles: ['Pectoralis Major', 'Anterior Deltoids', 'Biceps Tendons', 'Serratus Anterior', 'Core']
  },
  {
    id: 'ninety-degree-hold',
    name: '90-Degree Hold (90 Degree Bent-Arm Planche)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'Iconic bent-arm calisthenics skill holding the entire body horizontal in mid-air with elbows locked at a strict 90-degree angle and zero hip support.',
    instructions: [
      'Place hands on floor or parallettes, lean shoulders forward, and bend elbows to 90 degrees.',
      'Keep elbows tucked near your ribs WITHOUT resting your hips or abdomen on your elbows.',
      'Float your legs (straddle or feet together) horizontally parallel to the floor and hold.'
    ],
    progressionLevel: 4,
    isHold: true,
    defaultHoldSec: 10,
    targetMuscles: ['Anterior Deltoids', 'Triceps Brachii', 'Pectoralis Major', 'Serratus Anterior', 'Erector Spinae', 'Core']
  },
  {
    id: 'ninety-degree-handstand-push-up',
    name: '90-Degree Handstand Push-Up (90° HSPU)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'Lowering from a freestanding handstand into a horizontal 90-Degree Hold and pressing all the way back up to vertical handstand.',
    instructions: [
      'Kick up into a controlled freestanding handstand on floor or parallettes.',
      'Lower slowly while planching your shoulders forward until your body hovers horizontally in a 90-Degree Hold.',
      'Press through your palms while elevating your hips back up to a locked-out vertical handstand.'
    ],
    progressionLevel: 5,
    defaultReps: 3,
    targetMuscles: ['Anterior Deltoids', 'Triceps Brachii', 'Upper Chest', 'Trapezius', 'Core']
  },
  {
    id: 'elbow-lever-hold',
    name: 'Full Elbow Lever Hold',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Classic horizontal balancing skill supporting the entire straight body parallel to the ground balanced on bent elbows tucked into the midsection.',
    instructions: [
      'Place palms on the floor or bar with fingers pointing outward or backward.',
      'Bend elbows and wedge them firmly into your lower abs / hip crease near your center of gravity.',
      'Lean forward until your feet lift off the floor and extend your legs straight back into a horizontal line.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 15,
    targetMuscles: ['Anterior Deltoids', 'Wrists & Forearms', 'Core', 'Glutes', 'Erector Spinae']
  },
  {
    id: 'one-arm-elbow-lever-hold',
    name: 'One-Arm Elbow Lever Hold',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Unilateral horizontal balance resting your center of gravity on a single bent elbow while the free arm extends out for poise.',
    instructions: [
      'Wedge your working elbow directly into the centerline of your abdomen near the navel.',
      'Lean forward and spread legs slightly or lock them together to balance horizontally.',
      'Release the non-working hand and hold a steady horizontal line on one arm.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 8,
    targetMuscles: ['Forearms & Wrists', 'Obliques & Core', 'Anterior Deltoids', 'Glutes', 'Lower Back']
  },
  {
    id: 'crane-pose-straight-arm',
    name: 'Straight-Arm Crane Pose (Bakasana)',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Advanced progression of the Frog Stand performed with completely locked elbows and knees wedged high into the armpits.',
    instructions: [
      'Plant palms shoulder-width apart and place knees high into your armpits.',
      'Lean forward and push the floor away until your elbows lock 100% straight and heels pull tight to glutes.',
      'Hold with full scapular protraction as a direct bridge to the Tuck Planche.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 15,
    targetMuscles: ['Anterior Deltoids', 'Serratus Anterior', 'Triceps', 'Hip Flexors', 'Wrists']
  },
  {
    id: 'v-sit-hold',
    name: 'Full V-Sit Hold',
    category: 'core',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'Elite active pike compression skill elevating straight legs to a 45–75 degree V-angle above the hands with locked arms.',
    instructions: [
      'Press down through floor or parallettes into a clean L-Sit with locked elbows.',
      'Push your hips forward slightly while compressing your abs and hip flexors to drive your straight legs upward into a sharp V.',
      'Keep knees locked, toes pointed, and shoulders depressed away from your ears.'
    ],
    progressionLevel: 4,
    isHold: true,
    defaultHoldSec: 10,
    targetMuscles: ['Rectus Abdominis', 'Hip Flexors', 'Quadriceps', 'Triceps Brachii', 'Posterior Deltoids']
  },
  {
    id: 'straddle-l-sit-hold',
    name: 'Straddle L-Sit Hold',
    category: 'core',
    difficulty: 'intermediate',
    equipment: 'parallettes',
    description: 'Wide-legged L-Sit variation demanding intense active hip abduction, hip flexor compression, and tricep depression.',
    instructions: [
      'Support yourself on floor or parallettes with straight arms and depressed shoulders.',
      'Lift both legs into a wide straddle parallel to the ground with knees locked and toes pointed.',
      'Drive hips slightly forward and keep chest proud.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 15,
    targetMuscles: ['Rectus Abdominis', 'Hip Flexors', 'Adductors & Abductors', 'Quadriceps', 'Triceps']
  },
  {
    id: 'manna-hold',
    name: 'Full Manna Hold',
    category: 'core',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'One of the rarest gymnastics compression skills on earth: pushing hips forward and upward in extreme shoulder extension until legs float horizontally above the head.',
    instructions: [
      'Begin in a high V-Sit on parallettes or floor with fingers pointed backward.',
      'Drive your pelvis powerfully forward and upward by extending your shoulders and firing triceps and rear delts.',
      'Fold your straight legs back over your torso until your hips and legs align horizontally.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 5,
    targetMuscles: ['Posterior Deltoids', 'Triceps Brachii', 'Rectus Abdominis', 'Hip Flexors', 'Hamstrings']
  },
  {
    id: 'l-sit-to-handstand-press',
    name: 'L-Sit to Handstand Press',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'Seamless transition from a static L-Sit hold through a tucked or piked fold directly up into a freestanding handstand.',
    instructions: [
      'Hold a clean 3-second L-Sit on parallettes with locked arms.',
      'Sweep your legs backward between your arms while leaning your shoulders forward to float your hips over your wrists.',
      'Extend your legs straight overhead into a locked-out vertical handstand.'
    ],
    progressionLevel: 5,
    defaultReps: 3,
    targetMuscles: ['Anterior Deltoids', 'Triceps Brachii', 'Core & Hip Flexors', 'Serratus Anterior', 'Trapezius']
  },
  {
    id: 'freestanding-handstand-hold',
    name: 'Freestanding Handstand Hold',
    category: 'push',
    difficulty: 'intermediate',
    equipment: 'none',
    description: 'Pure inverted vertical balance in open space using fingertip pressure and a hollow-body line.',
    instructions: [
      'Plant hands shoulder-width apart with fingers spread wide gripping the floor.',
      'Kick up smoothly into a vertical line with shoulders elevated to ears, ribs tucked in, and glutes squeezed.',
      'Balance using subtle fingertip presses (fighting falling over) and palm heel presses.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 20,
    targetMuscles: ['Anterior & Lateral Deltoids', 'Trapezius', 'Triceps', 'Forearms & Wrists', 'Core']
  },
  {
    id: 'straddle-press-to-handstand',
    name: 'Strict Straddle Press to Handstand',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Zero-momentum straight-arm press from a standing wide straddle fold up into a freestanding handstand.',
    instructions: [
      'Place palms flat on the floor with feet in a wide straddle.',
      'Shift your shoulders forward over your fingertips until your toes become weightless and float off the ground.',
      'Keep your arms 100% locked as you smoothly rotate your pelvis overhead and bring your legs together into a handstand.'
    ],
    progressionLevel: 5,
    defaultReps: 3,
    targetMuscles: ['Anterior Deltoids', 'Trapezius', 'Hip Flexors', 'Rectus Abdominis', 'Wrists']
  },
  {
    id: 'one-arm-handstand-hold',
    name: 'One-Arm Handstand Hold (OAHS)',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'The pinnacle of hand-balancing equilibrium: balancing vertically on a single locked arm in straddle or straight-body alignment.',
    instructions: [
      'Establish a rock-solid freestanding straddle handstand.',
      'Shift your hips and center of gravity laterally over your working hand while pushing tall through the working shoulder.',
      'Lighten the non-working hand to one fingertip, then release it completely to hold the One-Arm Handstand.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 8,
    targetMuscles: ['Deltoids', 'Trapezius', 'Obliques', 'Triceps', 'Forearms & Wrists']
  },
  {
    id: 'two-finger-handstand-hold',
    name: '2-Finger Handstand Hold',
    category: 'push',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Balancing an inverted vertical handstand supported purely on two fingers of each hand.',
    instructions: [
      'Warm up wrists and finger tendons thoroughly.',
      'Support weight on index and middle fingers (or thumb and index) against wall or freestanding.',
      'Elevate shoulders strongly and maintain a rigid vertical line.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 8,
    targetMuscles: ['Forearms & Finger Tendons', 'Deltoids', 'Trapezius', 'Triceps', 'Core']
  },
  {
    id: 'tuck-front-lever-hold',
    name: 'Tuck Front Lever Hold',
    category: 'pull',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'Foundational straight-arm horizontal pulling hold with knees tucked to the chest and torso suspended parallel to the ground.',
    instructions: [
      'Hang from a pull-up bar with an overhand shoulder-width grip and lock your elbows.',
      'Depress your shoulder blades and pull down on the bar with straight arms until your torso is horizontal.',
      'Tuck knees tightly to your chest and hold your hips level with your shoulders.'
    ],
    progressionLevel: 2,
    isHold: true,
    defaultHoldSec: 20,
    targetMuscles: ['Latissimus Dorsi', 'Lower Trapezius', 'Posterior Deltoids', 'Rectus Abdominis', 'Triceps Long Head']
  },
  {
    id: 'adv-tuck-front-lever-hold',
    name: 'Advanced Tuck Front Lever Hold',
    category: 'pull',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'Intermediate Front Lever progression extending the knees away from the chest to 90 degrees with a flat horizontal spine.',
    instructions: [
      'Pull into a Tuck Front Lever with straight locked arms.',
      'Extend your knees backward until your thighs are vertical (90 degrees to your torso) and flatten your lower back.',
      'Engage lats and abs intensely to prevent hips from sinking.'
    ],
    progressionLevel: 3,
    isHold: true,
    defaultHoldSec: 15,
    targetMuscles: ['Latissimus Dorsi', 'Posterior Deltoids', 'Rhomboids', 'Rectus Abdominis', 'Forearms']
  },
  {
    id: 'one-leg-front-lever-hold',
    name: 'One-Leg Front Lever Hold',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Asymmetrical Front Lever progression with one leg fully extended straight and the opposite knee tucked in.',
    instructions: [
      'Enter an Advanced Tuck Front Lever with locked elbows.',
      'Extend one leg completely straight inline with your torso while keeping the other knee tucked.',
      'Keep hips square to the ceiling and switch legs halfway through or between sets.'
    ],
    progressionLevel: 4,
    isHold: true,
    defaultHoldSec: 12,
    targetMuscles: ['Latissimus Dorsi', 'Rectus Abdominis', 'Posterior Deltoids', 'Glutes', 'Forearms']
  },
  {
    id: 'straddle-front-lever-hold',
    name: 'Straddle Front Lever Hold',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'High-level horizontal straight-arm hang with both legs extended wide in a straddle parallel to the floor.',
    instructions: [
      'Grip the bar, lock elbows, and drive the bar toward your hips using straight-arm lat power.',
      'Extend both legs out into a wide straddle with locked knees, squeezed glutes, and pointed toes.',
      'Hold a rigid horizontal plane from shoulders to heels.'
    ],
    progressionLevel: 4,
    isHold: true,
    defaultHoldSec: 10,
    targetMuscles: ['Latissimus Dorsi', 'Posterior Deltoids', 'Rectus Abdominis', 'Glutes', 'Triceps Long Head']
  },
  {
    id: 'full-front-lever-hold',
    name: 'Full Front Lever Hold',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'The iconic straight-arm pulling skill: suspending the entire straight body horizontally underneath the bar with feet together.',
    instructions: [
      'Grip the bar shoulder-width apart and lock your elbows completely.',
      'Engage lats, teres major, rear delts, abs, and glutes to hold your body in a horizontal line.',
      'Keep legs squeezed together and toes pointed with zero hip sag.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 8,
    targetMuscles: ['Latissimus Dorsi', 'Posterior Deltoids', 'Rectus Abdominis', 'Rhomboids', 'Glutes', 'Forearms']
  },
  {
    id: 'front-lever-touch',
    name: 'Front Lever Touch (Horizontal Bar-to-Hip Pull)',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Elite dynamic Front Lever skill pulling the horizontal body all the way up until the waist/abs physically contact the bar.',
    instructions: [
      'Lock into a strict Full or Straddle Front Lever.',
      'Explosively row your elbows down and back while keeping your body 100% horizontal.',
      'Touch your lower abs/hips to the bar at the top, then lower back to a straight-arm Front Lever.'
    ],
    progressionLevel: 5,
    defaultReps: 3,
    targetMuscles: ['Latissimus Dorsi', 'Biceps Brachii', 'Posterior Deltoids', 'Rhomboids', 'Rectus Abdominis']
  },
  {
    id: 'one-arm-front-lever-hold',
    name: 'One-Arm Front Lever Hold',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Legendary unilateral straight-arm pulling skill holding a horizontal Front Lever suspended from a single arm.',
    instructions: [
      'Grip the bar with one hand, depress and pack the working shoulder blade, and lock the elbow.',
      'Drive the bar down toward your hips while engaging obliques and lats at maximal intensity.',
      'Hold your body horizontal in a straddle or full line on one arm.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 5,
    targetMuscles: ['Latissimus Dorsi', 'Obliques', 'Posterior Deltoids', 'Forearms', 'Rectus Abdominis']
  },
  {
    id: 'victorian-cross-hold',
    name: 'Victorian Lever Hold (Parallettes / Rings)',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'parallettes',
    description: 'An inverted Maltese for the pulling chain: holding the body horizontally between parallel bars or rings with straight arms extended out at hip level.',
    instructions: [
      'Position your body horizontally between two parallel surfaces or rings with arms straight.',
      'Depress your shoulders and press your straight arms downward into the supports like a horizontal Front Lever on top of bars.',
      'Maintain a rigid straight bodyline parallel to the floor.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 5,
    targetMuscles: ['Latissimus Dorsi', 'Posterior Deltoids', 'Triceps Long Head', 'Rectus Abdominis', 'Pectoralis Major']
  },
  {
    id: 'tuck-back-lever-hold',
    name: 'Tuck Back Lever Hold',
    category: 'pull',
    difficulty: 'intermediate',
    equipment: 'pull-up bar',
    description: 'Straight-arm shoulder-extension skill holding a tucked body horizontally facing the floor underneath a bar or rings.',
    instructions: [
      'Grip the bar and pass your legs through your arms (Skin the Cat) into an inverted hang.',
      'Keep your knees tucked to your chest and slowly lower your torso behind you until your back is horizontal to the ground.',
      'Protract your shoulder blades, lock your elbows, and hold steady.'
    ],
    progressionLevel: 2,
    isHold: true,
    defaultHoldSec: 20,
    targetMuscles: ['Anterior Deltoids', 'Biceps Tendons', 'Pectoralis Major', 'Latissimus Dorsi', 'Erector Spinae']
  },
  {
    id: 'straddle-back-lever-hold',
    name: 'Straddle Back Lever Hold',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Intermediate-advanced Back Lever progression holding the body horizontal facing the floor with legs spread in a wide straddle.',
    instructions: [
      'Lower from an inverted hang with straight locked arms and a wide leg straddle.',
      'Stop when your shoulders, hips, and ankles form a flat horizontal plane parallel to the floor.',
      'Squeeze glutes, lower back, and chest while maintaining locked elbows.'
    ],
    progressionLevel: 4,
    isHold: true,
    defaultHoldSec: 12,
    targetMuscles: ['Anterior Deltoids', 'Pectoralis Major', 'Biceps Tendons', 'Erector Spinae', 'Glutes']
  },
  {
    id: 'full-back-lever-hold',
    name: 'Full Back Lever Hold',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Complete straight-arm horizontal suspension facing the floor with legs locked together, building immense bicep tendon and anterior deltoid strength.',
    instructions: [
      'Use a pronated or supinated grip and invert your body cleanly through your arms.',
      'Lower your straight body under control until you are completely horizontal facing the floor.',
      'Lock elbows, protract scapulae slightly, squeeze glutes and legs together, and hold.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 10,
    targetMuscles: ['Anterior Deltoids', 'Biceps Tendons', 'Pectoralis Major', 'Erector Spinae', 'Glutes', 'Core']
  },
  {
    id: 'strict-hefesto',
    name: 'Strict Bar Hefesto (Reverse Muscle-Up Curl)',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'One of the most demanding bent-arm pulling skills in calisthenics: pulling from a German Hang behind the back up to a Korean Dip support using pure bicep curl torque.',
    instructions: [
      'Enter a supinated German Hang with the bar behind your back and hands gripping with a false grip.',
      'Pull your bodyweight upward by forcefully curling your biceps and driving your elbows down behind your back.',
      'Rise until your lower back rests against the bar in a Korean Dip top support.'
    ],
    progressionLevel: 5,
    defaultReps: 2,
    targetMuscles: ['Biceps Brachii', 'Brachialis', 'Anterior Deltoids', 'Pectoralis Major', 'Forearms'],
    safetyNote: 'Extreme load on the distal biceps tendon and shoulder capsule. Master Full Back Lever and Deep Pelican Curls first.'
  },
  {
    id: 'tuck-human-flag-hold',
    name: 'Tuck Human Flag Hold (Side Lever)',
    category: 'core',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Lateral horizontal suspension on a vertical pole or stall bars with knees tucked in to shorten the lever arm.',
    instructions: [
      'Grip a vertical pole or stall bars with your top hand overhand (pulling) and bottom hand underhand (pushing).',
      'Lock both elbows straight, push hard through the bottom arm, and pull through the top arm.',
      'Lift your hips laterally until your torso is horizontal with knees tucked.'
    ],
    progressionLevel: 4,
    isHold: true,
    defaultHoldSec: 12,
    targetMuscles: ['Obliques', 'Latissimus Dorsi', 'Deltoids', 'Triceps Brachii', 'Quadratus Lumborum']
  },
  {
    id: 'straddle-human-flag-hold',
    name: 'Straddle Human Flag Hold',
    category: 'core',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Horizontal sideways suspension on a vertical post with legs extended in a wide V-straddle.',
    instructions: [
      'Set a wide vertical grip and lock both arms like steel struts.',
      'Press your bottom shoulder into depression/protraction while pulling with your top lat.',
      'Extend both legs into a wide straddle with your torso and hips suspended horizontally.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 8,
    targetMuscles: ['Obliques', 'Latissimus Dorsi', 'Deltoids', 'Gluteus Medius', 'Triceps']
  },
  {
    id: 'full-human-flag-hold',
    name: 'Full Human Flag Hold (Side Lever)',
    category: 'core',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'The iconic street-workout showstopper: holding the entire straight body horizontally out to the side of a vertical pole with legs together.',
    instructions: [
      'Grip the vertical pole wide, lock both elbows, and stack your top shoulder and hip directly above the bottom ones.',
      'Push ruthlessly through the bottom arm while pulling with the top arm and firing your top obliques.',
      'Squeeze both legs together in a horizontal line parallel to the ground.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 6,
    targetMuscles: ['Obliques', 'Latissimus Dorsi', 'Lateral & Anterior Deltoids', 'Triceps', 'Glutes']
  },
  {
    id: 'full-dragon-flag-hold',
    name: 'Full Horizontal Dragon Flag Static Hold',
    category: 'core',
    difficulty: 'advanced',
    equipment: 'none',
    description: 'Static horizontal Bruce Lee Dragon Flag lever supporting the entire straight body off the ground purely on the upper traps and shoulders.',
    instructions: [
      'Lie on a bench or floor and grip a sturdy anchor behind your head.',
      'Press up onto your upper traps and lower your straight, unbent body until it hovers horizontally just inches off the surface.',
      'Hold this horizontal anti-extension lever with maximal abdominal, glute, and lat tension.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 10,
    targetMuscles: ['Rectus Abdominis', 'Transverse Abdominis', 'Latissimus Dorsi', 'Glutes', 'Lower Back']
  },
  {
    id: 'slow-false-grip-muscle-up',
    name: 'Slow False-Grip Strict Muscle-Up',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Zero-momentum, slow-motion bar or ring muscle-up using a deep false grip to transition smoothly from hang to lockout.',
    instructions: [
      'Wrap your wrists high over the bar or rings in a secure false grip.',
      'Pull slowly to your sternum without kipping or swinging your legs.',
      'Transition your shoulders smoothly over your hands and press to a straight-arm top support.'
    ],
    progressionLevel: 5,
    defaultReps: 3,
    targetMuscles: ['Latissimus Dorsi', 'Forearms (False Grip)', 'Triceps Brachii', 'Pectoralis Major', 'Biceps']
  },
  {
    id: 'two-finger-pull-up',
    name: '2-Finger Pull-Up (Fingertip Pull-Up)',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'pull-up bar',
    description: 'Elite grip and pulling skill performing dead-hang pull-ups hanging solely from the index and middle fingers of each hand.',
    instructions: [
      'Hook your index and middle fingers over the bar with an active half-crimp or open-hand grip.',
      'Depress your shoulder blades and pull smoothly without jerking or bouncing at the bottom.',
      'Clear the bar with your chin and lower under strict control.'
    ],
    progressionLevel: 5,
    defaultReps: 5,
    targetMuscles: ['Forearms & Finger Flexors', 'Latissimus Dorsi', 'Biceps Brachii', 'Upper Back']
  },
  {
    id: 'iron-cross-hold',
    name: 'Iron Cross Hold (Rings / Strap-Assisted)',
    category: 'pull',
    difficulty: 'advanced',
    equipment: 'dip bars',
    description: 'Legendary gymnastics strength hold suspending the body vertically with both arms extended straight out horizontally at 90 degrees.',
    instructions: [
      'Begin from a straight-arm ring support hold.',
      'Slowly slide your hands outward with elbows locked until your arms form a horizontal T-cross with your torso.',
      'Engage pectorals, lats, and teres major intensely to hold the cross position.'
    ],
    progressionLevel: 5,
    isHold: true,
    defaultHoldSec: 6,
    targetMuscles: ['Pectoralis Major', 'Latissimus Dorsi', 'Biceps Tendons', 'Anterior & Posterior Deltoids', 'Core']
  }
];
