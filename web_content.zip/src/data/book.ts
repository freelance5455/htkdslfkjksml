import type { Unit, Vocab } from "./types";

const modules = import.meta.glob("./units/*.json", {
  eager: true,
}) as Record<string, { default: Unit }>;

function clean(raw: Unit): Unit {
  return {
    id: raw.id,
    number: raw.number,
    title: raw.title,
    learn: raw.learn ?? [],
    lessons: (raw.lessons ?? []).map((lesson) => ({
      ...lesson,
      blocks: lesson.blocks ?? [],
    })),
    vocab: (raw.vocab ?? [])
      .filter((v) => v && v.word)
      .map((v) => ({
        word: v.word,
        pos: v.pos,
        meaning: v.meaning ?? "",
        urdu: v.urdu ?? "",
        synonyms: v.synonyms ?? [],
        antonyms: v.antonyms ?? [],
        sentences: v.sentences ?? [],
      })),
  };
}

export const units: Unit[] = Object.values(modules)
  .map((m) => clean(m.default))
  .filter((u) => u && u.number && u.title)
  .sort((a, b) => a.number - b.number);

export function vocabForUnit(unit: Unit): Vocab[] {
  return [...unit.vocab].sort(
    (a, b) => b.word.length - a.word.length,
  );
}

export function allVocab(): { unit: Unit; vocab: Vocab }[] {
  const rows: { unit: Unit; vocab: Vocab }[] = [];
  for (const unit of units) {
    for (const vocab of unit.vocab) rows.push({ unit, vocab });
  }
  return rows;
}
