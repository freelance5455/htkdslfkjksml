import type { ConstellationStar } from "@/game/types";

export const STARS: ConstellationStar[] = [
  { id: "s1", name: "Aube", x: 50, y: 22, unlockFlag: "solved_seuil" },
  { id: "s2", name: "Distance", x: 32, y: 38, unlockFlag: "traces_found" },
  { id: "s3", name: "Mémoire", x: 68, y: 36, unlockFlag: "solved_rebuild" },
  { id: "s4", name: "Ville", x: 24, y: 58, unlockFlag: "solved_miroir" },
  { id: "s5", name: "Miroir", x: 76, y: 56, unlockFlag: "act5_door" },
  { id: "s6", name: "Portes", x: 50, y: 48, unlockFlag: "door_lien" },
  { id: "s7", name: "Chute", x: 38, y: 72, unlockFlag: "false_reveal_done" },
  { id: "s8", name: "Reste", x: 62, y: 74, unlockFlag: "act8_understood" },
  { id: "s9", name: "Dernière", x: 50, y: 88, unlockFlag: "solved_final" },
];

export const STAR_EDGES: [string, string][] = [
  ["s1", "s2"],
  ["s1", "s3"],
  ["s2", "s4"],
  ["s3", "s5"],
  ["s2", "s6"],
  ["s3", "s6"],
  ["s4", "s7"],
  ["s5", "s8"],
  ["s6", "s7"],
  ["s6", "s8"],
  ["s7", "s9"],
  ["s8", "s9"],
];
