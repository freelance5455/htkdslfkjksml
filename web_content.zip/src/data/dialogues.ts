import type { DialogueDef } from "@/game/types";

export const DIALOGUES: DialogueDef[] = [
  {
    id: "d_intro",
    npc: "Transmission",
    lines: [
      { speaker: "", text: "Lohen." },
      { speaker: "", text: "Si tu peux m'entendre… suis la lumière." },
    ],
    setFlag: "heard_intro",
  },
  {
    id: "d_mira",
    npc: "Mira",
    lines: [
      { speaker: "Mira", text: "Tu n'es pas d'ici. Tes yeux cherchent encore le ciel." },
      { speaker: "Mira", text: "Un homme est passé. Silencieux. Il a demandé le puits, puis la forêt." },
      { speaker: "Mira", text: "Il a dit qu'il laissait des traces pour quelqu'un qui saurait les lire." },
    ],
    setFlag: "talked_mira",
  },
  {
    id: "d_archiviste",
    npc: "L'archiviste",
    lines: [
      { speaker: "Archiviste", text: "Les étoiles sont parties. Les phrases, elles, se sont retournées." },
      { speaker: "Archiviste", text: "Si tu trouves un verre noir, ne le regarde pas comme un miroir. Regarde-le comme une porte." },
    ],
    setFlag: "talked_archiviste",
    giveItem: "fragment_miroir",
  },
  {
    id: "d_enfant",
    npc: "L'enfant au ciel",
    lines: [
      { speaker: "Enfant", text: "Maman dit que le ciel est fatigué." },
      { speaker: "Enfant", text: "Moi je crois qu'il attend quelqu'un." },
    ],
    setFlag: "talked_enfant",
  },
  {
    id: "d_astronome",
    npc: "Olden",
    lines: [
      { speaker: "Olden", text: "Ma boussole ne veut plus du nord. Elle veut une étoile morte." },
      { speaker: "Olden", text: "Si tu la trouves au marché, rapporte-la. Je te dirai où le jardin s'ouvre la nuit." },
    ],
    choices: [
      {
        id: "help",
        label: "Je vais la chercher.",
        flag: "accepted_boussole",
        reply: "Elle est près des étals muets. L'aiguille brille encore un peu.",
      },
      {
        id: "later",
        label: "Plus tard.",
        flag: "deferred_boussole",
        reply: "Plus tard, le ciel sera encore plus vide.",
      },
    ],
  },
  {
    id: "d_astronome_done",
    npc: "Olden",
    lines: [
      { speaker: "Olden", text: "Elle tremble. Merci." },
      { speaker: "Olden", text: "Le jardin, après vingt-et-une heures. Une lueur qui n'appartient pas aux fleurs." },
    ],
    setFlag: "side_boussole",
  },
  {
    id: "d_marchand",
    npc: "Le marchand silencieux",
    lines: [
      { speaker: "Marchand", text: "Je ne vends plus rien qui fasse de bruit." },
      { speaker: "Marchand", text: "Prends la cloche si tu veux. Elle s'est tue toute seule." },
    ],
    giveItem: "cloche_muette",
    setFlag: "got_cloche",
  },
  {
    id: "d_continue",
    npc: "Transmission",
    lines: [{ speaker: "", text: "Continue." }],
    setFlag: "heard_continue",
  },
];

export function getDialogue(id: string): DialogueDef | undefined {
  return DIALOGUES.find((d) => d.id === id);
}
