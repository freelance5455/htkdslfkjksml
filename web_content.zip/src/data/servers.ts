import type { AIServerNode, WingoInterval, WingoSize, WingoColor, WingoPrediction } from '../types';

export const AI_SERVERS: AIServerNode[] = [
  {
    id: 1,
    name: 'Tiger Pro',
    emoji: '🐯',
    winRate: 98.9,
    tag: '96% STRIKE',
    primaryColor: '#f97316',
    secondaryColor: '#ea580c',
    glowColor: 'rgba(249, 115, 22, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(40, 18, 5, 0.95) 0%, rgba(85, 35, 10, 0.6) 50%, rgba(20, 8, 2, 0.98) 100%)',
    textColor: '#fb923c',
  },
  {
    id: 2,
    name: 'Dragon King',
    emoji: '🐉',
    winRate: 99.2,
    tag: '98% VIP',
    primaryColor: '#ef4444',
    secondaryColor: '#b91c1c',
    glowColor: 'rgba(239, 68, 68, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(45, 10, 10, 0.95) 0%, rgba(90, 20, 20, 0.6) 50%, rgba(25, 5, 5, 0.98) 100%)',
    textColor: '#f87171',
  },
  {
    id: 3,
    name: 'Phoenix VIP',
    emoji: '🔥',
    winRate: 98.7,
    tag: '97% ACCURACY',
    primaryColor: '#f59e0b',
    secondaryColor: '#d97706',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(45, 30, 5, 0.95) 0%, rgba(80, 50, 10, 0.6) 50%, rgba(20, 15, 2, 0.98) 100%)',
    textColor: '#fbbf24',
  },
  {
    id: 4,
    name: 'Eagle Eye',
    emoji: '🦅',
    winRate: 98.5,
    tag: '95% STRIKE',
    primaryColor: '#06b6d4',
    secondaryColor: '#0891b2',
    glowColor: 'rgba(6, 182, 212, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(5, 30, 40, 0.95) 0%, rgba(10, 60, 80, 0.6) 50%, rgba(2, 15, 20, 0.98) 100%)',
    textColor: '#38bdf8',
  },
  {
    id: 5,
    name: 'Lion Heart',
    emoji: '🦁',
    winRate: 99.4,
    tag: '99% MASTER',
    primaryColor: '#eab308',
    secondaryColor: '#ca8a04',
    glowColor: 'rgba(234, 179, 8, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(40, 35, 5, 0.95) 0%, rgba(80, 70, 10, 0.6) 50%, rgba(20, 18, 2, 0.98) 100%)',
    textColor: '#fde047',
  },
  {
    id: 6,
    name: 'Thunder Bolt',
    emoji: '⚡',
    winRate: 98.3,
    tag: 'RAPID PULSE',
    primaryColor: '#3b82f6',
    secondaryColor: '#2563eb',
    glowColor: 'rgba(59, 130, 246, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(10, 20, 45, 0.95) 0%, rgba(20, 40, 90, 0.6) 50%, rgba(5, 10, 25, 0.98) 100%)',
    textColor: '#60a5fa',
  },
  {
    id: 7,
    name: 'Shadow X',
    emoji: '🌀',
    winRate: 98.8,
    tag: 'STEALTH V2',
    primaryColor: '#8b5cf6',
    secondaryColor: '#7c3aed',
    glowColor: 'rgba(139, 92, 246, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(25, 10, 45, 0.95) 0%, rgba(50, 20, 90, 0.6) 50%, rgba(12, 5, 25, 0.98) 100%)',
    textColor: '#a78bfa',
  },
  {
    id: 8,
    name: 'Cobra Strike',
    emoji: '🐍',
    winRate: 98.6,
    tag: 'SNIPER HIT',
    primaryColor: '#10b981',
    secondaryColor: '#059669',
    glowColor: 'rgba(16, 185, 129, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(5, 35, 20, 0.95) 0%, rgba(10, 70, 40, 0.6) 50%, rgba(2, 20, 10, 0.98) 100%)',
    textColor: '#34d399',
  },
  {
    id: 9,
    name: 'Wolf Pack',
    emoji: '🐺',
    winRate: 98.4,
    tag: 'SWARM AI',
    primaryColor: '#64748b',
    secondaryColor: '#475569',
    glowColor: 'rgba(100, 116, 139, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(20, 25, 35, 0.95) 0%, rgba(40, 50, 70, 0.6) 50%, rgba(10, 15, 20, 0.98) 100%)',
    textColor: '#94a3b8',
  },
  {
    id: 10,
    name: 'Blaze Pro',
    emoji: '💥',
    winRate: 99.1,
    tag: 'EXTREME FIRE',
    primaryColor: '#f43f5e',
    secondaryColor: '#e11d48',
    glowColor: 'rgba(244, 63, 94, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(45, 10, 25, 0.95) 0%, rgba(90, 20, 50, 0.6) 50%, rgba(25, 5, 15, 0.98) 100%)',
    textColor: '#fb7185',
  },
  {
    id: 11,
    name: 'Viper Gold',
    emoji: '🐍',
    winRate: 98.9,
    tag: 'GOLD EDGE',
    primaryColor: '#d97706',
    secondaryColor: '#b45309',
    glowColor: 'rgba(217, 119, 6, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(40, 25, 5, 0.95) 0%, rgba(80, 50, 10, 0.6) 50%, rgba(20, 12, 2, 0.98) 100%)',
    textColor: '#f59e0b',
  },
  {
    id: 12,
    name: 'Rocket Star',
    emoji: '🚀',
    winRate: 99.3,
    tag: 'MAX TRAJECTORY',
    primaryColor: '#0284c7',
    secondaryColor: '#0369a1',
    glowColor: 'rgba(2, 132, 199, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(5, 25, 45, 0.95) 0%, rgba(10, 50, 90, 0.6) 50%, rgba(2, 12, 25, 0.98) 100%)',
    textColor: '#38bdf8',
  },
  {
    id: 13,
    name: 'Storm Chaser',
    emoji: '🌪️',
    winRate: 98.5,
    tag: 'CYCLONE WAVE',
    primaryColor: '#0ea5e9',
    secondaryColor: '#0284c7',
    glowColor: 'rgba(14, 165, 233, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(5, 30, 50, 0.95) 0%, rgba(10, 60, 100, 0.6) 50%, rgba(2, 15, 30, 0.98) 100%)',
    textColor: '#7dd3fc',
  },
  {
    id: 14,
    name: 'Ninja Master',
    emoji: '🥷',
    winRate: 99.0,
    tag: 'ULTRA SILENT',
    primaryColor: '#475569',
    secondaryColor: '#334155',
    glowColor: 'rgba(71, 85, 105, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(15, 20, 28, 0.95) 0%, rgba(30, 40, 55, 0.6) 50%, rgba(8, 10, 15, 0.98) 100%)',
    textColor: '#cbd5e1',
  },
  {
    id: 15,
    name: 'VIP Prediction',
    emoji: '👑',
    winRate: 99.7,
    tag: 'EMPEROR VIP',
    primaryColor: '#a855f7',
    secondaryColor: '#9333ea',
    glowColor: 'rgba(168, 85, 247, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(35, 10, 50, 0.95) 0%, rgba(70, 20, 100, 0.6) 50%, rgba(18, 5, 30, 0.98) 100%)',
    textColor: '#c084fc',
  },
  {
    id: 16,
    name: 'Apex Titan',
    emoji: '⛰️',
    winRate: 98.9,
    tag: 'TITAN BULK',
    primaryColor: '#78716c',
    secondaryColor: '#57534e',
    glowColor: 'rgba(120, 113, 108, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(25, 22, 20, 0.95) 0%, rgba(50, 45, 40, 0.6) 50%, rgba(12, 10, 10, 0.98) 100%)',
    textColor: '#d6d3d1',
  },
  {
    id: 17,
    name: 'Quantum Pulse',
    emoji: '🧠',
    winRate: 99.5,
    tag: 'NEURAL QUANTUM',
    primaryColor: '#06b6d4',
    secondaryColor: '#0284c7',
    glowColor: 'rgba(6, 182, 212, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(5, 30, 35, 0.95) 0%, rgba(10, 60, 70, 0.6) 50%, rgba(2, 15, 20, 0.98) 100%)',
    textColor: '#67e8f9',
  },
  {
    id: 18,
    name: 'Tiger Tapas',
    emoji: '🐅',
    winRate: 98.7,
    tag: 'BENGAL FURY',
    primaryColor: '#ea580c',
    secondaryColor: '#c2410c',
    glowColor: 'rgba(234, 88, 12, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(40, 15, 5, 0.95) 0%, rgba(80, 30, 10, 0.6) 50%, rgba(20, 8, 2, 0.98) 100%)',
    textColor: '#fdba74',
  },
  {
    id: 19,
    name: 'Dragon King Zone',
    emoji: '🐲',
    winRate: 99.4,
    tag: 'DRAGON ZONE',
    primaryColor: '#dc2626',
    secondaryColor: '#b91c1c',
    glowColor: 'rgba(220, 38, 38, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(40, 8, 8, 0.95) 0%, rgba(80, 15, 15, 0.6) 50%, rgba(20, 4, 4, 0.98) 100%)',
    textColor: '#fca5a5',
  },
  {
    id: 20,
    name: 'Phoenix Fire',
    emoji: '🕊️',
    winRate: 99.6,
    tag: 'REBIRTH GOLD',
    primaryColor: '#ec4899',
    secondaryColor: '#db2777',
    glowColor: 'rgba(236, 72, 153, 0.4)',
    bgGradient: 'linear-gradient(135deg, rgba(45, 10, 30, 0.95) 0%, rgba(90, 20, 60, 0.6) 50%, rgba(25, 5, 18, 0.98) 100%)',
    textColor: '#f472b6',
  },
];

// Calculate color for a given number
export function getWingoColor(num: number): WingoColor {
  if (num === 0) return 'RED_VIOLET';
  if (num === 5) return 'GREEN_VIOLET';
  if ([1, 3, 7, 9].includes(num)) return 'GREEN';
  return 'RED';
}

// Format period ID based on UTC timestamp
export function computePeriodId(timestamp: number, interval: WingoInterval): string {
  const now = new Date(timestamp);
  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, '0');
  const day = String(now.getUTCDate()).padStart(2, '0');
  
  let secPerPeriod = 30;
  if (interval === '1m') secPerPeriod = 60;
  else if (interval === '3m') secPerPeriod = 180;
  else if (interval === '5m') secPerPeriod = 300;

  const midnightUTC = Date.UTC(year, now.getUTCMonth(), now.getUTCDate());
  const elapsedSec = Math.floor((now.getTime() - midnightUTC) / 1000);
  const periodIndex = Math.floor(elapsedSec / secPerPeriod) + 1;
  const periodStr = String(periodIndex).padStart(4, '0');

  return `${year}${month}${day}1000${periodStr}`;
}

// Generate signal prediction for a server
export function generateServerPrediction(
  server: AIServerNode,
  period: string,
  interval: WingoInterval,
  recentResults: number[] = []
): WingoPrediction {
  let hash = 0;
  const seed = `${server.id}-${server.name}-${period}-${interval}-quantum-seed`;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  const absHash = Math.abs(hash);

  // Anti-loss streak logic & analysis
  let predictedSize: WingoSize = 'BIG';
  let note = 'Neural Delta Confluence Locked';

  if (recentResults.length >= 2) {
    const last = recentResults[0];
    const prev = recentResults[1];
    const lastSize: WingoSize = last >= 5 ? 'BIG' : 'SMALL';
    const prevSize: WingoSize = prev >= 5 ? 'BIG' : 'SMALL';

    if (lastSize === prevSize) {
      // 2 in a row -> streak momentum or reversal based on server strategy
      if (server.id % 2 === 0) {
        predictedSize = lastSize;
        note = `🛡️ Anti-Loss: Streak Momentum Locked [${lastSize}]`;
      } else {
        predictedSize = lastSize === 'BIG' ? 'SMALL' : 'BIG';
        note = `⚡ Anti-Loss: 2-2 Pair Reversal Wave (${lastSize} -> ${predictedSize})`;
      }
    } else {
      // 1-1 alternation
      predictedSize = lastSize === 'BIG' ? 'SMALL' : 'BIG';
      note = `🎯 Anti-Loss: 1-1 Alternation Wave Synced (${lastSize} -> ${predictedSize})`;
    }
  } else {
    // Default deterministic hash
    predictedSize = absHash % 100 < 52 ? 'BIG' : 'SMALL';
  }

  // Choose numbers
  const bigNumbers = [5, 6, 7, 8, 9];
  const smallNumbers = [0, 1, 2, 3, 4];
  const candidatePool = predictedSize === 'BIG' ? bigNumbers : smallNumbers;

  const targetNumber = candidatePool[(absHash + server.id * 3) % candidatePool.length];
  const luckyNumbers = [
    targetNumber,
    candidatePool[(absHash + server.id * 7 + 1) % candidatePool.length]
  ];

  const color = getWingoColor(targetNumber);
  const confidence = 96 + (absHash % 4); // 96% to 99%

  return {
    period,
    size: predictedSize,
    number: targetNumber,
    luckyNumbers,
    color,
    confidence,
    logicTag: `${server.name} Standalone`,
    notes: note,
    serverName: server.name,
    serverEmoji: server.emoji,
    status: 'PENDING'
  };
}
