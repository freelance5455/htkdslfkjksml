import { MCQQuestion } from '../types';

export interface SyllabusTopic {
  id: string;
  topicName: string;
  topicNameBn: string;
  topicNameHi?: string;
  chapterNumber: number;
  estimatedMinutes: number;
  importance: 'High' | 'Very High' | 'Medium';
  conceptsSummary: {
    en: string;
    bn: string;
    hi: string;
  };
  keyFormulasAndTricks: {
    en: string[];
    bn: string[];
    hi: string[];
  };
  examTips: {
    en: string;
    bn: string;
    hi: string;
  };
  sampleQuestions: MCQQuestion[];
}

export interface SubjectSyllabus {
  subjectKey: string;
  displayName: {
    en: string;
    bn: string;
    hi: string;
  };
  emoji: string;
  gradient: string;
  accentColor: string;
  topics: SyllabusTopic[];
}

// -----------------------------------------------------------------------------
// COMPREHENSIVE SYLLABUS DEFINITIONS FOR MAJOR SUBJECTS
// -----------------------------------------------------------------------------
export const SUBJECT_SYLLABUS_MAP: Record<string, SubjectSyllabus> = {
  'Reasoning': {
    subjectKey: 'Reasoning',
    displayName: {
      en: 'Reasoning',
      bn: 'লজিক্যাল রিজনিং (Reasoning)',
      hi: 'तार्किक क्षमता (Reasoning)'
    },
    emoji: '🧠',
    gradient: 'from-purple-600 via-indigo-600 to-blue-600',
    accentColor: 'indigo',
    topics: [
      {
        id: 'rs-analogies',
        topicName: 'Analogy & Classification',
        topicNameBn: 'সাদৃশ্য ও শ্রেণীকরণ (Analogy & Classification)',
        topicNameHi: 'सादृश्यता और वर्गीकरण',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Finding logical relationships between words, numbers, or letters and identifying the odd one out among options.',
          bn: 'শব্দ, সংখ্যা বা অক্ষরের মধ্যকার পারস্পরিক যৌক্তিক সম্পর্ক নির্ণয় এবং বিকল্পগুলির মধ্য থেকে আলাদা বা অমিলটি চিহ্নিত করা।',
          hi: 'शब्दों, संख्याओं या अक्षरों के बीच तार्किक संबंध खोजना और विकल्पों में से विषम को पहचानना।'
        },
        keyFormulasAndTricks: {
          en: [
            'Look for Capital/Country, Instrument/Measurement, Word/Antonym relationships.',
            'Number analogies often follow n²±1, n³±1 or prime number sequences.',
            'Check vowel/consonant count for letter-based odd-one-out questions.'
          ],
          bn: [
            'দেশ/রাজধানী, পরিমাপক যন্ত্র/একক, সমার্থক ও বিপরীতার্থক সম্পর্ক লক্ষ্য করুন।',
            'সংখ্যার সাদৃশ্যে n²±1, n³±1 বা মৌলিক সংখ্যার ক্রম বেশি আসে।',
            'অক্ষর শ্রেণীকরণে স্বরবর্ণ/ব্যঞ্জনবর্ণের সংখ্যা ও বর্ণমালার স্থান যাচাই করুন।'
          ],
          hi: [
            'देश/राजधानी, उपकरण/माप, समानार्थी और विलोम संबंधों की जांच करें।',
            'संख्या सादृश्य में n²±1, n³±1 या अभाज्य संख्या पैटर्न देखें।',
            'अक्षर आधारित प्रश्नों में वर्णमाला स्थान की गणना करें।'
          ]
        },
        examTips: {
          en: 'Always test simpler relations (difference, prime numbers) before jumping into complex algebra.',
          bn: 'প্রথমে সাধারণ যোগ-বিয়োগ বা মৌলিক সংখ্যার সম্পর্ক যাচাই করুন, তারপর জটিল হিসেবে যান।',
          hi: 'जटिल गणना में जाने से पहले साधारण अंतर और अभाज्य संख्याओं की जांच करें।'
        },
        sampleQuestions: [
          {
            id: 'rs-q1',
            subject: 'Reasoning',
            topic: 'Analogy & Classification',
            difficulty: 'Easy',
            question: 'ভারত : নতুন দিল্লি :: ফ্রান্স : ?',
            options: ['A. রোম', 'B. প্যারিস', 'C. লন্ডন', 'D. বার্লিন'],
            correctOptionIndex: 1,
            explanation: 'ভারতের রাজধানী নতুন দিল্লি, ঠিক তেমনি ফ্রান্সের রাজধানী প্যারিস।',
            shortConcept: 'দেশ ও রাজধানীর সম্পর্ক (Country - Capital Analogy)',
            rememberPoint: 'প্রতিযোগিতামূলক পরীক্ষায় বিশ্বের প্রধান দেশসমূহের রাজধানী মুখস্থ রাখুন।'
          },
          {
            id: 'rs-q2',
            subject: 'Reasoning',
            topic: 'Analogy & Classification',
            difficulty: 'Medium',
            question: 'সাদৃশ্য সম্পূর্ণ করুন: 12 : 144 :: 15 : ?',
            options: ['A. 215', 'B. 225', 'C. 240', 'D. 250'],
            correctOptionIndex: 1,
            explanation: 'সম্পর্কটি হলো n : n²। তাই 12² = 144 এবং 15² = 225।',
            shortConcept: 'বর্গ সংখ্যার সাদৃশ্য (Square Numbers)',
            rememberPoint: '১ থেকে ৩০ পর্যন্ত সংখ্যার বর্গ মনে রাখা সময় বাঁচায়।'
          }
        ]
      },
      {
        id: 'rs-syllogism',
        topicName: 'Syllogism & Venn Diagrams',
        topicNameBn: 'সিলোজিজম ও ভেনচিত্র (Syllogism & Venn Diagrams)',
        topicNameHi: 'न्याय वाक्य और वेन आरेख',
        chapterNumber: 2,
        estimatedMinutes: 35,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Testing logical deductions from given statements (All, Some, No) without assuming real-world truth.',
          bn: 'প্রদত্ত বিবৃতি (সকল, কিছু, কোনোটি নয়) থেকে সঠিক সিদ্ধান্ত অনুমান করা ভেনচিত্রের মাধ্যমে। বাস্তব সত্যতা বিবেচনা না করে কেবল যুক্তির ভিত্তিতে সিদ্ধান্ত গ্রহণ।',
          hi: 'दिए गए कथनों (सभी, कुछ, कोई नहीं) से तार्किक निष्कर्ष निकालना।'
        },
        keyFormulasAndTricks: {
          en: [
            'Draw minimum overlapping Venn diagram first.',
            '"Some A are B" does NOT automatically imply "Some A are not B".',
            'In "Either/Or" cases: One positive, one negative, same elements, both false individually.'
          ],
          bn: [
            'সর্বদা ন্যূনতম ওভারল্যাপিং ভেনচিত্র আঁকুন।',
            '"কিছু A হলো B" মানেই "কিছু A নয় B" এমন সিদ্ধান্ত নিশ্চিত নয়।',
            'Either/Or শর্ত: একটি ইতিবাচক ও একটি নেতিবাচক সিদ্ধান্ত এবং উপাদান দুটি একই হতে হবে।'
          ],
          hi: [
            'न्यूनतम वेन आरेख बनाएं।',
            'Either/Or नियम: एक सकारात्मक, एक नकारात्मक और दोनों व्यक्तिगत रूप से गलत।'
          ]
        },
        examTips: {
          en: 'Never assume possibility as certainty. If it holds in all possible diagrams, only then it is true.',
          bn: 'সম্ভাবনাকে নিশ্চিত সিদ্ধান্ত মনে করবেন না। সব সম্ভাব্য চিত্রে সত্য হলে তবেই তা নির্ভুল।',
          hi: 'संभावना को निश्चित सत्य न मानें।'
        },
        sampleQuestions: [
          {
            id: 'rs-q3',
            subject: 'Reasoning',
            topic: 'Syllogism & Venn Diagrams',
            difficulty: 'Medium',
            question: 'বিবৃতি: সব আম হলো ফল। সব ফল হলো মিষ্টি।\nসিদ্ধান্ত:\nI. সব আম হলো মিষ্টি।\nII. কিছু মিষ্টি হলো আম।',
            options: ['A. কেবল I সঠিক', 'B. কেবল II সঠিক', 'C. I এবং II উভয়ই সঠিক', 'D. কোনোটিই সঠিক নয়'],
            correctOptionIndex: 2,
            explanation: 'যেহেতু সব আম ফলের মধ্যে এবং সব ফল মিষ্টির মধ্যে অবস্থিত, তাই সব আম নিশ্চিতভাবে মিষ্টি (I) এবং মিষ্টির কিছু অংশ আম দ্বারা আবৃত (II)।',
            shortConcept: 'অন্তর্ভুক্তি সিলোজিজম (Universal Affirmative Deduction)',
            rememberPoint: 'All A is B + All B is C = All A is C এবং Some C is A সত্য।'
          }
        ]
      },
      {
        id: 'rs-coding',
        topicName: 'Coding - Decoding',
        topicNameBn: 'কোডিং ও ডিকোডিং (Coding - Decoding)',
        topicNameHi: 'कोडिंग और डिकोडिंग',
        chapterNumber: 3,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Deciphering coded patterns of letters, numbers, and symbols based on shift, reverse, or substitution rules.',
          bn: 'বর্ণমালা ও সংখ্যার স্থানবদল, বিপরীত অক্ষর বা সাংকেতিক নিয়মের মাধ্যমে গুপ্ত সংকেত উদ্ধার করা।',
          hi: 'अक्षरों, संख्याओं और प्रतीकों के कोडित पैटर्न को समझना।'
        },
        keyFormulasAndTricks: {
          en: [
            'EJOTY formula for positions: E=5, J=10, O=15, T=20, Y=25.',
            'Opposite letters sum to 27 (A+Z = 1+26 = 27, B+Y = 2+25 = 27).',
            'Check for cross-coding (first to last letter shifts).'
          ],
          bn: [
            'EJOTY সূত্র মনে রাখুন: E=5, J=10, O=15, T=20, Y=25।',
            'বিপরীত অক্ষরের অবস্থানের যোগফল সর্বদা ২৭ (A+Z=27, M+N=27)।',
            'অক্ষর বা শব্দের আড়াআড়ি (Cross) কোডিং পরীক্ষা করুন।'
          ],
          hi: [
            'EJOTY नियम: E=5, J=10, O=15, T=20, Y=25।',
            'विपरीत अक्षरों का योग 27 होता है (A=1 + Z=26 = 27)।'
          ]
        },
        examTips: {
          en: 'Write alphabetical positions on scratch sheet quickly during exam start.',
          bn: 'পরীক্ষা শুরুর আগেই রাফ শিটে বর্ণমালার স্থান ও বিপরীত অক্ষর লিখে রাখলে ৫-১০ মিনিট সময় বাঁচে।',
          hi: 'रफ शीट पर तुरंत वर्णमाला के स्थान लिख लें।'
        },
        sampleQuestions: [
          {
            id: 'rs-q4',
            subject: 'Reasoning',
            topic: 'Coding - Decoding',
            difficulty: 'Easy',
            question: 'যদি "BOOK" কে সংকেত ভাষায় "CPPL" লেখা হয়, তবে "PEN" এর সংকেত কী হবে?',
            options: ['A. QFO', 'B. QFM', 'C. RFO', 'D. QEP'],
            correctOptionIndex: 0,
            explanation: 'প্রতিটি অক্ষর পরবর্তী অক্ষরে রূপান্তরিত হচ্ছে (+1 শিফট): B+1=C, O+1=P, O+1=P, K+1=L। অনুরূপভাবে P+1=Q, E+1=F, N+1=O। অর্থাৎ QFO।',
            shortConcept: 'প্লাস ওয়ান ক্রমিক শিফটিং কোডিং (+1 Shift)',
            rememberPoint: 'প্রতিটি অক্ষরের শিফটের মান (+1, +2, বা -1) ধাপে ধাপে যাচাই করুন।'
          }
        ]
      },
      {
        id: 'rs-blood',
        topicName: 'Blood Relations',
        topicNameBn: 'রক্তের সম্পর্ক (Blood Relations)',
        topicNameHi: 'रक्त संबंध',
        chapterNumber: 4,
        estimatedMinutes: 25,
        importance: 'High',
        conceptsSummary: {
          en: 'Deciphering family tree hierarchies, generational jumps, and indirect kinship representations.',
          bn: 'পারিবারিক সম্পর্ক, বংশলতিকা এবং পরোক্ষ পরিচয় সম্পর্কিত জটিল প্রশ্নের সহজ সমাধান।',
          hi: 'पारिवारिक वृक्ष और रिश्तों को समझना।'
        },
        keyFormulasAndTricks: {
          en: [
            'Use standard symbols: (+) for Male, (-) for Female, (=) for Spouses, (--) for Siblings, vertical lines for Generations.',
            'Never assume gender based only on names unless explicitly mentioned.',
            'Break down "Pointing to someone" statements from the end ("My mother\'s only son...").'
          ],
          bn: [
            'প্রতীক ব্যবহার করুন: পুরুষ (+), মহিলা (-), দম্পতি (=), ভাই-বোন (--), প্রজন্ম (উল্লম্ব রেখা)।',
            'নাম দেখে লিঙ্গ নির্ধারণ করবেন না, যতক্ষণ না সম্পর্কে বা বাক্যে স্পষ্ট করা হয়েছে।',
            '"একজন ব্যক্তির দিকে ইঙ্গিত করে..." প্রশ্নে বাক্যটির শেষ থেকে সম্পর্ক ভাঙুন।'
          ],
          hi: [
            'चिह्न: (+) पुरुष, (-) महिला, (=) पति-पत्नी, पीढ़ी के लिए खड़ी रेखा।',
            'केवल नाम के आधार पर लिंग न तय करें।'
          ]
        },
        examTips: {
          en: 'Assume yourself in the narrator’s place to solve verbal relations in seconds.',
          bn: 'নিজেকে বক্তার জায়গায় বসিয়ে ভাবলে রক্তের সম্পর্কের জটিল প্রশ্ন নিমেষে সমাধান হয়।',
          hi: 'स्वयं को वक्ता के स्थान पर रखकर सोचें।'
        },
        sampleQuestions: [
          {
            id: 'rs-q5',
            subject: 'Reasoning',
            topic: 'Blood Relations',
            difficulty: 'Medium',
            question: 'এক ব্যক্তির ছবির দিকে ইঙ্গিত করে রাহুল বলল, "উনি আমার বাবার একমাত্র ছেলের মেয়ে।" ছবিটি কার?',
            options: ['A. রাহুলের বোন', 'B. রাহুলের মেয়ে', 'C. রাহুলের মা', 'D. রাহুলের স্ত্রী'],
            correctOptionIndex: 1,
            explanation: 'রাহুলের বাবার একমাত্র ছেলে হলো স্বয়ং রাহুল। তার মেয়ে মানে রাহুলের নিজের মেয়ে।',
            shortConcept: 'আত্ম-সম্পর্ক নির্ণয় (Self Kinship Deduction)',
            rememberPoint: '"বাবার একমাত্র ছেলে" মানে বক্তা নিজেই যদি তিনি পুরুষ হন।'
          }
        ]
      }
    ]
  },

  'Quantitative Aptitude': {
    subjectKey: 'Quantitative Aptitude',
    displayName: {
      en: 'Quantitative Aptitude',
      bn: 'গণিত ও পাটিগণিত (Quantitative Aptitude)',
      hi: 'मात्रात्मक योग्यता (Maths)'
    },
    emoji: '🔢',
    gradient: 'from-blue-600 via-cyan-600 to-teal-600',
    accentColor: 'blue',
    topics: [
      {
        id: 'qa-percentage',
        topicName: 'Percentage & Profit-Loss',
        topicNameBn: 'শতকরা, লাভ ও ক্ষতি (Percentage & Profit-Loss)',
        topicNameHi: 'प्रतिशत, लाभ और हानि',
        chapterNumber: 1,
        estimatedMinutes: 35,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Base foundations of competitive math calculating fractions to percentages, markup prices, and net profit/loss percentages.',
          bn: 'শতকরা ও ভগ্নাংশের রূপান্তর, ধার্যমূল্য, ছাড় এবং প্রকৃত লাভ-ক্ষতির হার নির্ণয়।',
          hi: 'प्रतिशत, क्रय-विक्रय मूल्य और लाभ-हानि की गणना।'
        },
        keyFormulasAndTricks: {
          en: [
            'Fraction to %: 1/2=50%, 1/3=33.33%, 1/4=25%, 1/6=16.66%, 1/8=12.5%, 1/7=14.28%.',
            'Net Change formula: a + b + (ab/100)% for successive percentage changes.',
            'Profit % = (Profit / Cost Price) × 100.'
          ],
          bn: [
            'ভগ্নাংশ মান মুখস্থ রাখুন: ১/২=৫০%, ১/৩=৩৩.৩৩%, ১/৪=২৫%, ১/৬=১৬.৬৬%, ১/৭=১৪.২৮%, ১/৮=১২.৫%।',
            'ধারাবাহিক পরিবর্তনের সূত্র: a + b + (ab/১০০)%।',
            'শতকরা লাভ = (লাভ / ক্রয়মূল্য) × ১০০।'
          ],
          hi: [
            'क्रमागत प्रतिशत परिवर्तन: a + b + (ab/100)%।',
            'लाभ % = (लाभ / क्रय मूल्य) × 100।'
          ]
        },
        examTips: {
          en: 'Always use fractional multipliers (e.g. 20% increase = 6/5) to avoid lengthy decimal divisions.',
          bn: 'দশমিকের বদলে গুণক ভগ্নাংশ ব্যবহার করুন (যেমন ২০% বৃদ্ধি = ৬/৫ গুণ)।',
          hi: 'दशमलव के बजाय भिन्न का उपयोग करें।'
        },
        sampleQuestions: [
          {
            id: 'qa-q1',
            subject: 'Quantitative Aptitude',
            topic: 'Percentage & Profit-Loss',
            difficulty: 'Easy',
            question: 'একটি জামা ৮০০ টাকায় কিনে ৯৬০ টাকায় বিক্রি করলে শতকরা লাভের হার কত?',
            options: ['A. ১৫%', 'B. ১৮%', 'C. ২০%', 'D. ২৫%'],
            correctOptionIndex: 2,
            explanation: 'লাভ = ৯৬০ - ৮০০ = ১৬০ টাকা। শতকরা লাভ = (১৬০ / ৮০০) × ১০০ = ২০%।',
            shortConcept: 'ক্রয়মূল্যের ওপর লাভ নির্ণয় (Profit on CP)',
            rememberPoint: 'লাভ সবসময় ক্রয়মূল্যের (CP) ওপর হিসাব করা হয়।'
          }
        ]
      },
      {
        id: 'qa-time-work',
        topicName: 'Time & Work, Pipes & Cisterns',
        topicNameBn: 'সময় ও কার্য, নল ও চৌবাচ্চা (Time & Work)',
        topicNameHi: 'समय और कार्य, पाइप और टंकी',
        chapterNumber: 2,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Calculating combined work capacities and efficiency rates using total work LCM approach.',
          bn: 'ল.সা.গু (LCM) পদ্ধতির সাহায্যে মোট কাজ এবং ব্যক্তি বা নলের কার্যক্ষমতা (Efficiency) দ্রুত নির্ণয়।',
          hi: 'ल.स.प. (LCM) विधि से कार्य और दक्षता की गणना।'
        },
        keyFormulasAndTricks: {
          en: [
            'Total Work = LCM of individual days taken.',
            'Daily Efficiency = Total Work / Individual Days.',
            'Days required = Total Work / Combined Efficiency.'
          ],
          bn: [
            'মোট কাজ = দিনগুলির ল.সা.গু (LCM)।',
            'দৈনিক কার্যক্ষমতা (Efficiency) = মোট কাজ / একা কাজটি করার দিন।',
            'একত্রে লাগা সময় = মোট কাজ / সম্মিলিত কার্যক্ষমতা।'
          ],
          hi: [
            'कुल कार्य = दिनों का LCM।',
            'दैनिक कार्यक्षमता = कुल कार्य / दिन।'
          ]
        },
        examTips: {
          en: 'Treat outlet pipes or leaking cisterns as negative work efficiency.',
          bn: 'চৌবাচ্চার খালি করার নলকে ঋণাত্মক কার্যক্ষমতা হিসেবে ধরুন।',
          hi: 'खाली करने वाले पाइप को ऋणात्मक दक्षता मानें।'
        },
        sampleQuestions: [
          {
            id: 'qa-q2',
            subject: 'Quantitative Aptitude',
            topic: 'Time & Work',
            difficulty: 'Medium',
            question: 'A একটি কাজ ১০ দিনে এবং B সেই কাজটি ১৫ দিনে করতে পারে। তারা একসাথে কাজ করলে কাজটি কত দিনে শেষ হবে?',
            options: ['A. ৫ দিনে', 'B. ৬ দিনে', 'C. ৮ দিনে', 'D. ১২ দিনে'],
            correctOptionIndex: 1,
            explanation: '১০ ও ১৫ এর ল.সা.গু = ৩০ ইউনিট (মোট কাজ)। A এর দৈনিক কাজ = ৩ ইউনিট, B এর দৈনিক কাজ = ২ ইউনিট। মোট ক্ষমতা = ৫ ইউনিট/দিন। সময় = ৩০/৫ = ৬ দিন।',
            shortConcept: 'ল.সা.গু পদ্ধতি (LCM Work Efficiency Method)',
            rememberPoint: 'সূত্র: (A × B) / (A + B) = (১০ × ১৫) / ২৫ = ১৫০ / ২৫ = ৬ দিন।'
          }
        ]
      }
    ]
  },

  'General Knowledge': {
    subjectKey: 'General Knowledge',
    displayName: {
      en: 'General Knowledge',
      bn: 'সাধারণ জ্ঞান (General Knowledge & GS)',
      hi: 'सामान्य ज्ञान (GK & GS)'
    },
    emoji: '🌍',
    gradient: 'from-emerald-600 via-teal-600 to-cyan-600',
    accentColor: 'emerald',
    topics: [
      {
        id: 'gk-polity',
        topicName: 'Indian Polity & Constitution',
        topicNameBn: 'ভারতীয় সংবিধান ও শাসনব্যবস্থা (Indian Polity)',
        topicNameHi: 'भारतीय संविधान और राजव्यवस्था',
        chapterNumber: 1,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Structure of the Indian Constitution, Fundamental Rights (Articles 12-35), DPSP, President, Parliament, and Judiciary.',
          bn: 'ভারতের সংবিধান গঠন, মৌলিক অধিকার (ধারা ১২-৩৫), নির্দেশমূলক নীতি, রাষ্ট্রপতি, সংসদ ও বিচার ব্যবস্থার ক্ষমতা ও কার্যাবলী।',
          hi: 'भारतीय संविधान की संरचना, मौलिक अधिकार, संसद और न्यायपालिका।'
        },
        keyFormulasAndTricks: {
          en: [
            'Fundamental Rights: Equality (14-18), Freedom (19-22), Exploitation (23-24), Religion (25-28), Culture (29-30), Remedies (32).',
            'Article 32 is called the "Heart and Soul" of the Constitution by Dr. B.R. Ambedkar.',
            'Emergency Articles: 352 (National), 356 (State), 360 (Financial).'
          ],
          bn: [
            'মৌলিক অধিকারসমূহ: সমতা (১৪-১৮), স্বাধীনতা (১৯-২২), শোষণের বিরুদ্ধে (২৩-২৪), ধর্মীয় স্বাধীনতা (২৫-২৮), শিক্ষা ও সংস্কৃতি (২৯-৩০), সাংবিধানিক প্রতিবিধান (৩২)।',
            'ডঃ বি. আর. আম্বেদকর ৩২ নম্বর ধারাকে সংবিধানের "হৃদয় ও আত্মা" বলেছেন।',
            'জরুরি অবস্থার ধারা: ৩৫২ (জাতীয়), ৩৫৬ (রাজ্য), ৩৬০ (আর্থিক)।'
          ],
          hi: [
            'मौलिक अधिकार: समानता (14-18), स्वतंत्रता (19-22), शोषण के विरुद्ध (23-24), अनुच्छेद 32 (संविधान की आत्मा)।'
          ]
        },
        examTips: {
          en: 'Important constitutional amendments (42nd, 44th, 86th, 101st GST) are frequently asked.',
          bn: 'সংবিধান সংশোধনীসমূহ (৪২তম, ৪৪তম, ৮৬তম এবং ১০১তম জিএসটি) বারবার পরীক্ষায় আসে।',
          hi: 'प्रमुख संविधान संशोधन (42वां, 44वां, 86वां) याद रखें।'
        },
        sampleQuestions: [
          {
            id: 'gk-q1',
            subject: 'General Knowledge',
            topic: 'Indian Polity',
            difficulty: 'Easy',
            question: 'ভারতের সংবিধানের কোন ধারাটিকে ডঃ বি. আর. আম্বেদকর "সংবিধানের হৃদয় ও আত্মা" বলেছেন?',
            options: ['A. ধারা ১৯', 'B. ধারা ২১', 'C. ধারা ৩২', 'D. ধারা ৪৪'],
            correctOptionIndex: 2,
            explanation: '৩২ নম্বর ধারায় সাংবিধানিক প্রতিকারের অধিকার রয়েছে, যা মৌলিক অধিকার রক্ষায় সুপ্রিম কোর্টকে রিট জারির ক্ষমতা দেয়।',
            shortConcept: 'সাংবিধানিক প্রতিবিধানের অধিকার (Right to Constitutional Remedies)',
            rememberPoint: 'ধারা ৩২ সুপ্রিম কোর্ট এবং ধারা ২২৬ হাইকোর্টকে ৫ প্রকার রিট জারির ক্ষমতা দেয়।'
          }
        ]
      },
      {
        id: 'gk-history',
        topicName: 'Modern Indian History & INM',
        topicNameBn: 'আধুনিক ভারতের ইতিহাস ও স্বাধীনতা সংগ্রাম',
        topicNameHi: 'आधुनिक भारतीय इतिहास और स्वतंत्रता संग्राम',
        chapterNumber: 2,
        estimatedMinutes: 35,
        importance: 'Very High',
        conceptsSummary: {
          en: 'The Indian National Movement, 1857 Revolt, Congress sessions, Non-Cooperation, Civil Disobedience, and Quit India Movement.',
          bn: '১৮৫৭ সালের মহাবিদ্রোহ, জাতীয় কংগ্রেস প্রতিষ্ঠা, বঙ্গভঙ্গ আন্দোলন, অসহযোগ আন্দোলন, আইন অমান্য ও ভারত ছাড়ো আন্দোলনের কালানুক্রমিক ইতিহাস।',
          hi: '1857 का विद्रोह, कांग्रेस के अधिवेशन, असहयोग और भारत छोड़ो आंदोलन।'
        },
        keyFormulasAndTricks: {
          en: [
            'Key Years: 1885 (INC Founded), 1905 (Partition of Bengal), 1919 (Jallianwala Bagh), 1920 (Non-Cooperation), 1930 (Dandi March), 1942 (Quit India).',
            'Governor Generals: Dalhousie (Doctrine of Lapse), Curzon (Partition of Bengal), Mountbatten (Partition Plan).'
          ],
          bn: [
            'গুরুত্বপূর্ণ সাল: ১৮৮৫ (কংগ্রেস প্রতিষ্ঠা), ১৯০৫ (বঙ্গভঙ্গ), ১৯১৯ (জালিয়ানওয়ালাবাগ), ১৯২০ (অসহযোগ), ১৯৩০ (ডান্ডি অভিযান), ১৯৪২ (ভারত ছাড়ো)।',
            'প্রথম ভাইসরয় ছিলেন লর্ড ক্যানিং এবং স্বাধীন ভারতের শেষ ব্রিটিশ গভর্নর জেনারেল ছিলেন লর্ড মাউন্টব্যাটেন।'
          ],
          hi: [
            'प्रमुख वर्ष: 1885 (कांग्रेस), 1905 (बंगाल विभाजन), 1919 (जलियांवाला बाग), 1942 (भारत छोड़ो)।'
          ]
        },
        examTips: {
          en: 'Chronological ordering questions are very common in PSC, SSC, and Railway exams.',
          bn: 'ঘটনার ক্রমানুসারে সাজানোর প্রশ্ন ডাব্লুবিসিএস এবং রেলে অত্যন্ত জনপ্রিয়।',
          hi: 'घटनाओं के कालक्रम पर विशेष ध्यान दें।'
        },
        sampleQuestions: [
          {
            id: 'gk-q2',
            subject: 'General Knowledge',
            topic: 'Modern Indian History',
            difficulty: 'Easy',
            question: '১৮৮৫ সালে ভারতীয় জাতীয় কংগ্রেসের প্রথম অধিবেশনে কে সভাপতিত্ব করেছিলেন?',
            options: ['A. সুরেন্দ্রনাথ ব্যানার্জি', 'B. উমেশচন্দ্র বন্দ্যোপাধ্যায়', 'C. দাদাভাই নওরোজি', 'D. এ. ও. হিউম'],
            correctOptionIndex: 1,
            explanation: '১৮৮৫ সালে বোম্বাইয়ের গোকুলদাস তেজপাল সংস্কৃত কলেজে অনুষ্ঠিত প্রথম অধিবেশনে উমেশচন্দ্র বন্দ্যোপাধ্যায় (W.C. Bonnerjee) সভাপতিত্ব করেন।',
            shortConcept: 'জাতীয় কংগ্রেসের প্রারম্ভিক অধিবেশন',
            rememberPoint: 'এ. ও. হিউম ছিলেন কংগ্রেসের প্রতিষ্ঠাতা ও সাধারণ সম্পাদক।'
          }
        ]
      }
    ]
  },

  'Current Affairs': {
    subjectKey: 'Current Affairs',
    displayName: {
      en: 'Current Affairs',
      bn: 'সাম্প্রতিক ঘটনাবলী (Current Affairs)',
      hi: 'समसामयिकी (Current Affairs)'
    },
    emoji: '📰',
    gradient: 'from-pink-600 via-rose-600 to-amber-600',
    accentColor: 'rose',
    topics: [
      {
        id: 'ca-national',
        topicName: 'National Schemes & Science/Tech',
        topicNameBn: 'জাতীয় প্রকল্প, বিজ্ঞান ও মহাকাশ গবেষণা',
        topicNameHi: 'राष्ट्रीय योजनाएं और विज्ञान/प्रौद्योगिकी',
        chapterNumber: 1,
        estimatedMinutes: 20,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Recent government schemes, ISRO missions, national awards, and economic developments.',
          bn: 'ভারতের সাম্প্রতিক সরকারি প্রকল্প, ইসরো (ISRO) মিশন, জাতীয় পুরস্কার এবং বিজ্ঞান ও প্রযুক্তির গুরুত্বপূর্ণ অগ্রগতি।',
          hi: 'सरकारी योजनाएं, इसरो मिशन और राष्ट्रीय पुरस्कार।'
        },
        keyFormulasAndTricks: {
          en: [
            'Note mission targets: Gaganyaan (Human Spaceflight), Aditya-L1 (Sun observation at L1 point).',
            'Focus on launch vehicles (PSLV, LVM3) and launch dates.'
          ],
          bn: [
            'মিশন লক্ষ্য: গগনযান (মহাকাশে মানব প্রেরণ), আদিত্য-এল১ (সূর্য পর্যবেক্ষণ)।',
            'লঞ্চ যান (PSLV, LVM3) এবং সফল উৎক্ষেপণ তারিখ নোট করুন।'
          ],
          hi: [
            'इसरो के प्रमुख मिशन और योजनाओं के उद्देश्य याद रखें।'
          ]
        },
        examTips: {
          en: 'Current affairs questions of the last 6 to 12 months carry 15-20% weightage.',
          bn: 'পরীক্ষার আগের ৬ থেকে ১২ মাসের সাম্প্রতিক ঘটনা সবচেয়ে বেশি গুরুত্বপূর্ণ।',
          hi: 'पिछले 6-12 महीनों के करेंट अफेयर्स पर ध्यान दें।'
        },
        sampleQuestions: [
          {
            id: 'ca-q1',
            subject: 'Current Affairs',
            topic: 'Science & Space Missions',
            difficulty: 'Easy',
            question: 'ভারতের প্রথম সৌর পর্যবেক্ষণ মহাকাশযানের নাম কী?',
            options: ['A. ভাস্কর-১', 'B. আদিত্য-এল১', 'C. সূর্যযান', 'D. জ্যোতি-২'],
            correctOptionIndex: 1,
            explanation: 'আদিত্য-এল১ (Aditya-L1) ভারতের প্রথম ডেডিকেটেড সৌর মিশন, যা সূর্য-পৃথিবীর ল্যাগ্রাঞ্জ পয়েন্ট L1-এ স্থাপিত হয়েছে।',
            shortConcept: 'ইসরোর সৌর গবেষণা মিশন (Solar Mission)',
            rememberPoint: '২ সেপ্টেম্বর ২০২৩ শ্রীহরিকোটা থেকে PSLV-C57 এর মাধ্যমে এটি উৎক্ষেপণ করা হয়।'
          }
        ]
      }
    ]
  },

  'English Language': {
    subjectKey: 'English Language',
    displayName: {
      en: 'English Language',
      bn: 'ইংরেজি ভাষা ও ব্যাকরণ (English Language)',
      hi: 'अंग्रेजी भाषा और व्याकरण'
    },
    emoji: '🔤',
    gradient: 'from-amber-500 via-orange-600 to-rose-600',
    accentColor: 'amber',
    topics: [
      {
        id: 'eng-grammar',
        topicName: 'Error Spotting & Subject-Verb Agreement',
        topicNameBn: 'ত্রুটি চিহ্নিতকরণ ও ব্যাকরণ নিয়ম (Error Spotting)',
        topicNameHi: 'त्रुटि पहचान और व्याकरण',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Rules of subject-verb agreement, prepositions, tenses, and modifiers in sentence correction.',
          bn: 'Subject-Verb Agreement, উপযুক্ত Preposition এবং Tense সংক্রান্ত ভুল সংশোধন করার নিয়মাবলী।',
          hi: 'Subject-Verb Agreement और व्याकरण के बुनियादी नियम।'
        },
        keyFormulasAndTricks: {
          en: [
            '"Neither...nor" / "Either...or": Verb agrees with the NEAREST subject.',
            '"As well as" / "Along with" / "Together with": Verb agrees with the FIRST subject.',
            '"One of the + Plural Noun" takes a SINGULAR verb.'
          ],
          bn: [
            '"Neither...nor" বা "Either...or"-এ ক্রিয়া (Verb) নিকটবর্তী Subject অনুযায়ী বসে।',
            '"Along with", "As well as" থাকলে প্রথম Subject অনুযায়ী Verb বসে।',
            '"One of the + Plural Noun" এর পর সর্বদা Singular Verb বসে।'
          ],
          hi: [
            'Either/or में verb निकटतम subject के अनुसार बदलता है।',
            'One of the + plural noun के साथ singular verb आता है।'
          ]
        },
        examTips: {
          en: 'Break long sentences into subject, verb, and object components to spot errors instantly.',
          bn: 'বড় বাক্যকে Subject এবং Verb-এ ভাগ করলে ভুল সঙ্গে সঙ্গে ধরা পড়ে।',
          hi: 'लंबे वाक्यों को Subject और Verb में बांटकर देखें।'
        },
        sampleQuestions: [
          {
            id: 'eng-q1',
            subject: 'English Language',
            topic: 'Subject-Verb Agreement',
            difficulty: 'Medium',
            question: 'Find the correct sentence:\n"Neither the teacher nor the students ______ present in the classroom."',
            options: ['A. was', 'B. were', 'C. is', 'D. has been'],
            correctOptionIndex: 1,
            explanation: 'With "Neither...nor", the verb agrees with the closer subject "the students" (plural), hence "were" is correct.',
            shortConcept: 'Proximity Rule in Subject-Verb Agreement',
            rememberPoint: 'Always check the noun closest to the blank in "Neither...nor" structures.'
          }
        ]
      }
    ]
  }
};

import { ADDITIONAL_COMPETITIVE_SYLLABI } from './allCompetitiveSyllabus';

export const ALL_SYLLABUS_MAP: Record<string, SubjectSyllabus> = {
  ...SUBJECT_SYLLABUS_MAP,
  ...ADDITIONAL_COMPETITIVE_SYLLABI,
};

export function getSubjectSyllabus(subjectKey: string): SubjectSyllabus {
  if (ALL_SYLLABUS_MAP[subjectKey]) {
    return ALL_SYLLABUS_MAP[subjectKey];
  }
  const lower = (subjectKey || '').toLowerCase();
  for (const key of Object.keys(ALL_SYLLABUS_MAP)) {
    if (key.toLowerCase() === lower || lower.includes(key.toLowerCase()) || key.toLowerCase().includes(lower)) {
      return ALL_SYLLABUS_MAP[key];
    }
  }
  return ALL_SYLLABUS_MAP['General Knowledge'] || ALL_SYLLABUS_MAP['Reasoning'] || SUBJECT_SYLLABUS_MAP['Reasoning'];
}

// -----------------------------------------------------------------------------
// EXAM-SPECIFIC TOPIC RECOMMENDATION ENGINE
// -----------------------------------------------------------------------------
export function getRecommendedTopicForUser(
  subjectKey: string,
  targetExam: string,
  userAccuracy: number = 70
): { recommendedTopic: string; reason: string; reasonBn: string } {
  const syllabus = getSubjectSyllabus(subjectKey);
  const topics = syllabus?.topics || [];
  
  if (userAccuracy < 65) {
    const topic = (topics && topics.length > 0 ? topics[0] : null) || { topicName: 'Fundamentals', topicNameBn: 'মৌলিক ধারণা' };
    return {
      recommendedTopic: topic.topicName,
      reason: `Based on your recent accuracy (${userAccuracy}%), strengthen core concepts in ${topic.topicName} for ${targetExam}.`,
      reasonBn: `আপনার সাম্প্রতিক নির্ভুলতার হার (${userAccuracy}%) অনুযায়ী ${targetExam} পরীক্ষার জন্য "${topic.topicNameBn}" বিষয়টি রিভিশন দেওয়া প্রয়োজন।`
    };
  } else if (userAccuracy < 85) {
    const topic = (topics && topics.length > 1 ? topics[1] : null) || (topics && topics.length > 0 ? topics[0] : null) || { topicName: 'Core Practice', topicNameBn: 'মূল অনুশীলন' };
    return {
      recommendedTopic: topic.topicName,
      reason: `Boost your speed and solve high-weightage questions in ${topic.topicName} for ${targetExam}.`,
      reasonBn: `${targetExam} পরীক্ষায় সর্বোচ্চ নম্বরের জন্য "${topic.topicNameBn}" অধ্যায়ের প্র্যাকটিস বাড়ানো সুপারিশ করা হলো।`
    };
  } else {
    const topic = (topics && topics.length > 0 ? topics[topics.length - 1] : null) || { topicName: 'Advanced Test', topicNameBn: 'উন্নত পরীক্ষা' };
    return {
      recommendedTopic: topic.topicName,
      reason: `Excellent progress! Master advanced mock tests in ${topic.topicName}.`,
      reasonBn: `চমৎকার প্রস্তুতি! "${topic.topicNameBn}" অধ্যায়ের অ্যাডভান্সড মক টেস্ট সমাধান করে নিখুঁত প্রস্তুতি নিন।`
    };
  }
}
