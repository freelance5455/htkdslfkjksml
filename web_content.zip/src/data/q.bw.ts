// ============================================================
// >hl al-Bayt Quiz content — written in Buckwalter ASCII.
// Convert with: python3 tools/bw.py src/data/q.bw.ts src/data/q.ar.ts
// Arabic strings are wrapped in bw("...")
// ============================================================
declare function bw(s: string): string;

export const UI = {
  appTitle: bw(">nwAr >hl Albyt"),
  appSub: bw("10000 sw'Al Ely Alnby wAl<mAm wAlzhrA' mn Al<mAm Ely <lY Almhdy"),
  bismillah: bw("bsm Allh AlrHmn AlrHym"),
  startHint: bw("Axtr sw'AlA mn AlqA}mp l tbdA'"),
  all: bw("Alkl"),
  score: bw("Alntyjp"),
  done: bw("Almnjzp"),
  correct: bw("AlSHyHp"),
  wrong: bw("AlxAT}p"),
  qLabel: bw("sw'Al"),
  back: bw("rjwE"),
  next: bw("AltAly"),
  good: bw(">Hsnt!"),
  wrongMsg: bw("xsrt"),
  showAnswer: bw("AljwAb AlSHyH"),
  offline: bw("yEml bdwn Al<ntrnt"),
  reset: bw("EEAdp tSfyr AlntA}j"),
  loadMore: bw("AErD Almzyd mn Al>s}lp"),
  searchPh: bw("AbHv En sw'Al"),
  noQ: bw("lA twjd >s}lp"),
  qOf: bw("sw'Al"),
  catLabel: bw("Alqsm"),
  pts: "+10",
  optLetters: [bw(">"), bw("b"), bw("j")],
  streak: bw("AltwAly"),
  aboutNote: bw("h*A Alttbyq yEml kAm lA bdwn Al<ntrnt"),
  chooseCat: bw("Axtr Alqsm"),
  answered: bw("m jAwbp"),
  unanswered: bw("lm yjb bEd"),
  progress: bw("Altqdm"),
  titleSuffix: bw(">nwAr >hl Albyt - 10000 sw'Al"),
};

export const CATS = [
  { id: "aqida", icon: "\u262A\uFE0F", name: bw("EqdA}yp"), desc: bw("Al>sw'Al AlEqdA}yp En Al<mAm wAlmhdy") },
  { id: "dini", icon: "\uD83D\uDCD6", name: bw("dynyp"), desc: bw("Al>sw'Al Aldynyp fy AlEbdAt wAl>Hkm") },
  { id: "tarikhi", icon: "\uD83C\uDFDB\uFE0F", name: bw("tArykhyp"), desc: bw("Al>sw'Al AltArykhyp En Alnby wAl<mAm wAlzhrA'") },
];

export const COUNTS: Record<string, number> = { aqida: 4000, dini: 3500, tarikhi: 2500 };

// Stem parts: question text = prefix + core({X}) + suffix
export const PREFIX: Record<string, string[]> = {
  aqida: [
    bw(""), bw("fy AlEqdAt Al<mAmyp: "), bw("fy Al>sw'Al AlEqdA}yp: "), bw("mn nZrp AlEqdAt: "),
    bw("fy Altfsyr: "), bw("fy Al>Hdyv AlSHyHp: "), bw("fy AlbyAn: "), bw("fy mbAd} Al<mAm: "),
  ],
  dini: [
    bw(""), bw("fy Alfqh Al<mAmy: "), bw("fy Al$ryEp: "), bw("fy AlEbAdAt: "),
    bw("fy AlmEAmlAt: "), bw("fy AlThArp: "), bw("fy AlEdAlp: "), bw("fy Alslwk: "),
  ],
  tarikhi: [
    bw(""), bw("fy AltArykh: "), bw("fy Alsyrp Alnbwyp: "), bw("fy tArykh >hl Albyt: "),
    bw("fy AlmnAqb: "), bw("fy syrp Al<mAmyp: "), bw("fy tArykh Al<mAm Ely: "), bw("fy tArykh AlzhrA': "),
  ],
};

export const CORE: Record<string, string[]> = {
  aqida: [
    bw("mn hw {X}?"), bw("mA hw {X}?"), bw("mn hw {X} mn >hl Albyt?"), bw("mA mEnY {X}?"),
    bw("mn SAHb {X}?"), bw("mn {X} Al*y ytbE lY Al<mAm?"), bw("mA SfAt {X}?"), bw("mn {X} Al*y >$thr bh?"),
  ],
  dini: [
    bw("mA Hkm {X}?"), bw("Hkm {X} Ely Almslm?"), bw("mA Hkm {X} fy Al$ryEp?"), bw("Hkm {X} fy Alfqh?"),
    bw("mA ntyjp {X}?"), bw("Hkm {X} bEd AlTEAm?"), bw("mA >HkAm {X}?"), bw("fy >y Hkm {X}?"),
  ],
  tarikhi: [
    bw("fy >y snp {X}?"), bw("fy >y mdynp {X}?"), bw("fy >y mkAn {X}?"), bw("mA tArykh {X}?"),
    bw("fy >y snp Hdt {X}?"), bw("mA asm {X}?"), bw("mn qtl {X}?"), bw("fy >y snp wqE {X}?"),
  ],
};

export const SUFFIX: Record<string, string[]> = {
  aqida: [bw(""), bw(" wAlslAm"), bw(" fy AlSHyH AlwADH"), bw(" AlAn")],
  dini: [bw(""), bw(" fy Al m_hj Al<mAm"), bw(" fy ktb Alfqh"), bw(" wAlslAm")],
  tarikhi: [bw(""), bw(" bEd Alhjrp"), bw(" fy AltArykh"), bw(" wAlslAm")],
};

// Facts: { s: subject, a: correct answer } ; wrong options come from WRONGS pool
export const FACTS: Record<string, { s: string; a: string }[]> = {
  aqida: [
    { s: bw("Al<mAm Ely bn >by TAlb"), a: bw(">myr Alm'mnyn w wSy Alrswl [[saw]]") },
    { s: bw("AlzhrA' fatmp"), a: bw("sydp nsA' Aljnp w bnt Alrswl [[saw]]") },
    { s: bw("Al<mAm AlHsn bn Ely"), a: bw("sbT Alrswl Al>kbr") },
    { s: bw("Al<mAm AlHsyn bn Ely"), a: bw("sbT Alrswl AlSgyr w syd Al$hdA'") },
    { s: bw("Al<mAm zyn AlEAbdyn"), a: bw("EmAmp Al sjAd") },
    { s: bw("Al<mAm mHmd Al bAqr"), a: bw("bAqr AlElwm") },
    { s: bw("Al<mAm jEfr AlSAdq"), a: bw("AlSAdq") },
    { s: bw("Al<mAm mwsY AlkAZm"), a: bw("AlkAZm") },
    { s: bw("Al<mAm Ely AlrDA"), a: bw("AlrDA") },
    { s: bw("Al<mAm mHmd AljwAd"), a: bw("AljwAd") },
    { s: bw("Al<mAm Ely AlhAdy"), a: bw("AlhAdy") },
    { s: bw("Al<mAm AlHsn AlEskry"), a: bw("AlEskry") },
    { s: bw("Almhdy (Ej)"), a: bw("bqyp Allh fy >rDh") },
    { s: bw("Alnby mHmd [[saw]]"), a: bw("syd Al>wl w xAtm Al>nbyA'") },
    { s: bw("Edd Al<mAm"), a: bw("AvnA E$r") },
    { s: bw("AlESmp Al<mAm"), a: bw("HfZ mn Al* nwb") },
    { s: bw("AlwlAyp"), a: bw("lA ttm AlwlAyp bdwnhA") },
    { s: bw("AlrjEp"), a: bw("wEd Allh <ly Al>sw'Al") },
    { s: bw("Alghyb"), a: bw("AlElm Al*y y*kr Allh fyh") },
    { s: bw("Altwly"), a: bw("mHbp Allh wAlrswl wAl<mAm") },
    { s: bw("AlmErAj"), a: bw("lylp AlmErAj") },
    { s: bw("AlksA'"), a: bw("mlbs Allh fy AlHrb") },
    { s: bw("Alsjdp"), a: bw("qrbp <lY Allh") },
    { s: bw("Alqnwt"), a: bw("dEA' <lY Allh") },
    { s: bw("Altwly Al<mAm"), a: bw("twly Allh wAlrswl wAl<mAm") },
    { s: bw("AlzyArp"), a: bw("AlzyArp <ly Al<mAm") },
    { s: bw("Altq yyp"), a: bw("HfZ AllsAn") },
    { s: bw("AlHfZp AlqrAn"), a: bw("HfZp Allh") },
    { s: bw("Al$ fA'Ep AlEsl"), a: bw("AlEsl $fA' lkl dA'") },
    { s: bw("AlHjrm Al>swD"), a: bw("Hjr <smAEyl") },
    { s: bw("Alzmzm"), a: bw("b}r zmzm fy mkp") },
    { s: bw("AlTmr"), a: bw("mn AlfAkhp") },
    { s: bw("Al$fA'Ep AlHsn"), a: bw("Hsnp wrtp") },
    { s: bw("Alnsyk"), a: bw("AlHj AlEmrp") },
    { s: bw("AlrDA'"), a: bw("Al<mAm Al tAmn") },
    { s: bw("AlblA'"), a: bw("nSrp Allh wAlrswl") },
    { s: bw("AlSlAt AljmEp"), a: bw("snp fy AljmEp") },
    { s: bw("AlEyd AlfTr"), a: bw("Eyd lkl mslmyn") },
    { s: bw("AlEyd Al>DHA"), a: bw("Eyd lkl mslmyn") },
    { s: bw("SlAt Alxwf"), a: bw("mstHb") },
    { s: bw("AlmwAzyn"), a: bw("wzn bYn AlEbAd") },
    { s: bw("Al>mr bAlmErwf"), a: bw("wAjp <ly Almslm") },
    { s: bw("Alnhy En Almnkr"), a: bw("wAjp") },
    { s: bw("Altq yyp AlzmAn"), a: bw("wAjp <ly Almslm") },
    { s: bw("AlwSyp bAlwSyp"), a: bw("frDp Allh <ly Al>sw'Al") },
  ],
};

export const WRONGS: Record<string, string[]> = {
  aqida: [
    bw("Al<mAm Ely"), bw("AlzhrA'"), bw("Al<mAm AlHsyn"), bw("Almhdy"), bw("Alnby mHmd"),
    bw("Edd Al<mAm sbEp"), bw("AlESmp lAttm"), bw("wlAyp AlnAs"), bw("AlrjEp lAttm"),
    bw("Alghyb lAyElm"), bw("Hjr <smAEyl"), bw("mkp"), bw("Alqds"), bw("Almdynp"),
    bw("Alkwfp"), bw("byt Allh"), bw("AlqrAn ktAb Allh"), bw("Al$fA' Al$rb"), bw("Altwly AlnAs"),
  ],
};

FACTS.dini = [
  { s: bw("AlSlAt"), a: bw("wAjp") },
  { s: bw("AlSwm rmDAn"), a: bw("wAjp") },
  { s: bw("AlHj"), a: bw("wAjp <ly AlmstTE") },
  { s: bw("AlzkAp"), a: bw("wAjp") },
  { s: bw("AlSdqp"), a: bw("mndwb") },
  { s: bw("AlslAm"), a: bw("wAjp") },
  { s: bw("AlwDw'"), a: bw("wAjp qbl AlSlAt") },
  { s: bw("Algsl <ly AljnAbp"), a: bw("mfrD") },
  { s: bw("Altymm"), a: bw("ThArp mftAHhA") },
  { s: bw("AlrkwE"), a: bw("wAjb fy AlSlAt") },
  { s: bw("Alsjwd"), a: bw("wAjb fy AlSlAt") },
  { s: bw("AltsbyH qbl Al>kl"), a: bw("mndwb") },
  { s: bw("AlHmd bEd AlTEAm"), a: bw("mndwb") },
  { s: bw("AlTEAm AlHlAl"), a: bw("jA}z") },
  { s: bw("Alm ytp"), a: bw("HrAm") },
  { s: bw("Alqtl"), a: bw("HrAm") },
  { s: bw("Al$rb Alxmr"), a: bw("HrAm") },
  { s: bw("ZyArp Alqbwr"), a: bw("mndwb") },
  { s: bw("Slp AlrHm"), a: bw("mndwb") },
  { s: bw("br AlwAldyn"), a: bw("wAjp") },
  { s: bw("AlnZr"), a: bw("wAjp") },
  { s: bw("AlSwm nhAr rmDAn"), a: bw("HrAm") },
  { s: bw("AlTwAf"), a: bw("wAjp") },
  { s: bw("AlEtikAf"), a: bw("mstHb") },
  { s: bw("AljhAd"), a: bw("wAjp <ly AlkfAyp") },
  { s: bw("Altwbp"), a: bw("wAjp <ly Al*nwb") },
  { s: bw("AlAstgfAr"), a: bw("mndwb") },
  { s: bw("AldEA'"), a: bw("mndwb") },
  { s: bw("AlZkr"), a: bw("mndwb") },
  { s: bw("AlfTr"), a: bw("mndwb") },
  { s: bw("AlTrAwyH"), a: bw("snp") },
  { s: bw("AljmEp"), a: bw("snp") },
  { s: bw("Alq nwt fy Al lyl"), a: bw("mstHb") },
  { s: bw("Althjd"), a: bw("snp") },
  { s: bw("AlSlAt <ly Almyt"), a: bw("wAjp") },
  { s: bw("AlSdqp <ly Almskyn"), a: bw("mndwb") },
  { s: bw("AlH jrm Al>swD"), a: bw("HrAm") },
  { s: bw("Alwqwf ErfAt"), a: bw("wAjb") },
  { s: bw("TyEp AljnAzp"), a: bw("mndwb") },
  { s: bw("AlnZr <ly Almyt"), a: bw("mstHb") },
  { s: bw("ZyArp msjd Alnbwy"), a: bw("mndwb") },
  { s: bw("AlSlAt fy AljmEp"), a: bw("wAjp") },
  { s: bw("AljmAE fy AljmEp"), a: bw("mstHb") },
  { s: bw("AlTEAm AlmubAH"), a: bw("jA}z") },
  { s: bw("Al$rb qA}mA"), a: bw("mkrwh") },
];

WRONGS.dini = [
  bw("HrAm"), bw("mkrwh"), bw("mbAH"), bw("jA}z"), bw("mndwb"), bw("snp"),
  bw("wAjp"), bw("mstHb"), bw("mfrD"), bw("lA yjwz"), bw("jA}z bAl$ rT"),
];

FACTS.tarikhi = [
  { s: bw("wfAp Alnby mHmd [[saw]]"), a: bw("11 hjrp") },
  { s: bw("wfAp AlzhrA'"), a: bw("11 hjrp") },
  { s: bw("mqtl Al<mAm Ely"), a: bw("40 hjrp") },
  { s: bw("wqE p krblA'"), a: bw("61 hjrp") },
  { s: bw("mqtl Al<mAm AlHsn"), a: bw("61 hjrp") },
  { s: bw("dfn Al<mAm AlHsn"), a: bw("AlkrblA'") },
  { s: bw("wlAdp Al<mAm AlbAqr"), a: bw("57 hjrp") },
  { s: bw("wfAp Al<mAm AlbAqr"), a: bw("114 hjrp") },
  { s: bw("wlAdp Al<mAm AlSAdq"), a: bw("83 hjrp") },
  { s: bw("wfAp Al<mAm AlSAdq"), a: bw("148 hjrp") },
  { s: bw("mkAn Elm Al<mAm AlSAdq"), a: bw("Almdynp") },
  { s: bw("mqtl Al<mAm mwsY AlkAZm"), a: bw("183 hjrp") },
  { s: bw("wlAdp Al<mAm Ely AlrDA"), a: bw("148 hjrp") },
  { s: bw("mqtl Al<mAm Ely AlrDA"), a: bw("203 hjrp") },
  { s: bw("mhAjrp Al<mAm Ely AlrDA"), a: bw("m$hd") },
  { s: bw("wlAdp Al<mAm mHmd AljwAd"), a: bw("198 hjrp") },
  { s: bw("mqtl Al<mAm mHmd AljwAd"), a: bw("243 hjrp") },
  { s: bw("wlAdp Al<mAm Ely AlhAdy"), a: bw("212 hjrp") },
  { s: bw("mqtl Al<mAm Ely AlhAdy"), a: bw("260 hjrp") },
  { s: bw("wlAdp Al<mAm AlHsn AlEskry"), a: bw("235 hjrp") },
  { s: bw("mqtl Al<mAm AlHsn AlEskry"), a: bw("260 hjrp") },
  { s: bw("zhwr Almhdy (Ej)"), a: bw("fy AlsrdAb") },
  { s: bw("mkAn wldp Alnby"), a: bw("Almdynp") },
  { s: bw("nzwl AlqrAn"), a: bw("fy lylp Alqdr") },
  { s: bw("AlmErAj"), a: bw("lylp AlmErAj") },
  { s: bw("mkAn AlkEp"), a: bw("fy mkp Almkrmp") },
  { s: bw("Almsjd Alnbwy"), a: bw("Almdynp") },
  { s: bw("Almsjd AlHrAm"), a: bw("mkp") },
  { s: bw("Almsjd Al>qSA"), a: bw("Alqds") },
  { s: bw("AlHjr Al>swD"), a: bw("Hjr <smAEyl") },
  { s: bw("Alzmzm"), a: bw("b}r zmzm fy mkp") },
  { s: bw("wqE p bdr"), a: bw("2 hjrp") },
  { s: bw("wqE p >Hd"), a: bw("3 hjrp") },
  { s: bw("wqE p Al>HzAb"), a: bw("3 hjrp") },
  { s: bw("wqE p xndq"), a: bw("5 hjrp") },
  { s: bw("ftHmkp"), a: bw("8 hjrp") },
  { s: bw("Hj p AlwdA'E"), a: bw("10 hjrp") },
  { s: bw("wqE p Aljml"), a: bw("35 hjrp") },
  { s: bw("wqE p Sf fyn"), a: bw("17 hjrp") },
  { s: bw("bnA' AlkEp"), a: bw("fy Ehd Alnby [[saw]]") },
  { s: bw("mkAn dfn Alnby"), a: bw("Almdynp Almnwrp") },
  { s: bw("mkAn mqtl Al<mAm Ely"), a: bw("Alkwfp") },
  { s: bw("mdynp wfAp Al<mAm AlHsn"), a: bw("Alkwfp") },
  { s: bw("Al$ hAdp bEd mqtl Al<mAm AlHsn"), a: bw("fy AlkrblA'") },
  { s: bw("wlAdp Almhdy"), a: bw("255 hjrp") },
  { s: bw("Albyt Almqds"), a: bw("Alqds") },
  { s: bw("Almsjd Alqbltyn"), a: bw("Alqds") },
  { s: bw("mkAn zyArp Al<mAm AlHsyn"), a: bw("AlkrblA'") },
];

WRONGS.tarikhi = [
  bw("Almdynp"), bw("Alkwfp"), bw("mkp"), bw("Alqds"), bw("m$hd"), bw("AlkrblA'"), bw("Albsrp"),
  bw("11 hjrp"), bw("40 hjrp"), bw("61 hjrp"), bw("2 hjrp"), bw("8 hjrp"), bw("10 hjrp"),
  bw("148 hjrp"), bw("183 hjrp"), bw("203 hjrp"), bw("260 hjrp"), bw("fy mkp"), bw("AlsrdAb"),
  bw("Hjr <smAEyl"), bw("b}r zmzm fy mkp"),
];
