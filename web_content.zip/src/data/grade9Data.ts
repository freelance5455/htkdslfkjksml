import { StudyModule } from '../types/index.ts';

export const GRADE_9_STUDY_MODULES: StudyModule[] = [
  {
    id: 'afaan-oromoo-caasluga',
    title: 'Boqonnaa 1: Caasluga fi Dhamjecha',
    titleEn: 'Unit 1: Grammar & Morphology (Morphemes)',
    subject: 'Afaan Oromoo',
    subjectEn: 'Afaan Oromoo (Oromo Language)',
    grade: 'Kutaa 9ffaa (Grade 9)',
    category: 'Afaan Oromoo',
    estimatedMinutes: 12,
    topicSummary:
      'Qabiyyee bu\'uuraa caasluga Afaan Oromoo, gosoota dhamjechaa (walabaa fi hirkataa), fi seera ijaarsa himaa (Matima + Aantima + Gochima).',
    topicSummaryEn:
      'Core concepts of Afaan Oromoo grammar, morpheme classifications (free vs. bound), word formation rules, and canonical sentence structure (SOV).',
    sections: [
      {
        heading: '1. Maalummaa Dhamjechaa (Definition of Morphemes)',
        headingEn: '1. Definition of Morpheme',
        summary:
          'Dhamjechi kutaalee jechaa keessaa isa xiqqaa hiika qabu ykn tajaajila caaslugaa qabuudha. Jechi kamiyyuu dhamjecha tokko ykn isaa ol irraa tolfama.',
        summaryEn:
          'A morpheme is the smallest meaningful or grammatically functional unit in a language. Every word is composed of one or more morphemes.',
        bulletPoints: [
          'Dhamjechi qaama jechaa isa xiqqaa kan hiika of danda\'ee qabu ykn gar-tokkee hiikaa ta\'eedha.',
          'Dhamjechi addaan hin cabu; yoo cabe garuu hiika dhabuu ykn jijjiirrachuu danda\'a.',
          'Afaan Oromoo keessatti dhamjechi bakka gurguddoo lamatti qoodama: Dhamjecha Walabaa fi Dhamjecha Hirkataa.',
        ],
        bulletPointsEn: [
          'The smallest linguistic unit carrying semantic meaning or grammatical function.',
          'Cannot be divided further without losing or altering its core linguistic identity.',
          'Classified fundamentally into Free Morphemes and Bound Morphemes in Afaan Oromoo.',
        ],
        examples: [
          'Jechi "nama" jedhu dhamjecha tokkicha qaba (dhamjecha walabaa).',
          'Jechi "barattoota" jedhu dhamjecha lamarraa tolfame: "barat-" (dhamjecha walabaa) + "-oota" (dhamjecha hirkataa baay\'ina agarsiisu).',
        ],
      },
      {
        heading: '2. Dhamjecha Walabaa fi Hirkataa (Free & Bound Morphemes)',
        headingEn: '2. Free vs. Bound Morphemes',
        summary:
          'Garaagarummaa ijoon dhamjecha walabaa fi hirkataa gidduu jiru of-danda\'anii dhaabbachuu fi tajaajila isaaniitiin ibsama.',
        summaryEn:
          'The primary distinction between free and bound morphemes rests on independent syntactic existence and grammatical attachment.',
        bulletPoints: [
          'Dhamjecha Walabaa: Isa kophaa isaa dhaabbatee hiika guutuu kennuudha (fakkeenyaaf: mana, lafa, nyaata, muka, bishaan).',
          'Dhamjecha Hirkataa: Isa kophaa isaa dhaabbatee hiika guutuu hin kennine, kan dhamjecha walabaatti maxxanee tajaajila kennuudha.',
          'Dhamjechi hirkataan bakka lamatti qoodama: Maxxantuu Duraa (prefix) fi Maxxantuu Duubaa (suffix).',
          'Afaan Oromoo keessatti maxxantuun duubaa baay\'inaan hojiirra oola (akkuma: -ummaa, -eenya, -oota, -leeyyii).',
        ],
        bulletPointsEn: [
          'Free Morpheme: Can stand alone as an independent word carrying full semantic meaning.',
          'Bound Morpheme: Cannot occur independently; must attach to a free morpheme / root.',
          'Bound morphemes divide into Prefixes (before root) and Suffixes (after root).',
          'Afaan Oromoo predominantly uses suffixes for plurals, abstract nouns, and verb inflections.',
        ],
        examples: [
          'Tokkummaa = Tokko (walabaa) + -ummaa (hirkataa maq-ibsaa/abtiraktii).',
          'Gootummaa = Goota (walabaa) + -ummaa (hirkataa).',
          'Bareedina = Bareeda (walabaa) + -ina (hirkataa).',
        ],
      },
      {
        heading: '3. Caasaa Hima Afaan Oromoo (Sentence Structure - SOV)',
        headingEn: '3. Afaan Oromoo Sentence Word Order (SOV)',
        summary:
          'Afaan Oromoo seerluga isaan hima ijaaruuf caasaa Matima + Aantima + Gochima (Subject + Object + Verb) hordofa.',
        summaryEn:
          'Standard Afaan Oromoo follows the Subject + Object + Verb (SOV) syntactic order in declarative sentences.',
        bulletPoints: [
          'Matima (Subject): Isa gocha raawwatu ykn himni waa\'ee isaa odeessuudha (yeroo baay\'ee jalqaba himaa irratti argama).',
          'Aantima (Object): Isa gochi irratti raawwatamuudha (gidduutti argama).',
          'Gochima (Verb): Isa gocha ykn haala agarsiisuudha (dhuma himaa irratti argama).',
        ],
        bulletPointsEn: [
          'Subject (Matima): The doer or focal entity, usually positioned at the beginning.',
          'Object (Aantima): The recipient or target of the action, positioned centrally.',
          'Verb (Gochima): The action or state of being, concluding the clause.',
        ],
        examples: [
          'Tolasaan (Matima) + kitaaba (Aantima) + dubbise (Gochima).',
          'Barattoonni (Matima) + qormaata (Aantima) + qophaa\'u (Gochima).',
        ],
      },
    ],
    keyTerms: [
      {
        term: 'Dhamjecha',
        definition: 'Kutaa jechaa isa xiqqaa hiika qabu ykn tajaajila seerlugaa kennu.',
        translation: 'Morpheme - the smallest meaningful unit of language.',
        example: 'Jecha "barattoota" keessatti "-oota" dhamjecha.',
      },
      {
        term: 'Dhamjecha Walabaa',
        definition: 'Dhamjecha of danda\'ee dhaabbatee hiika guutuu kennuu danda\'u.',
        translation: 'Free Morpheme - an independent root word.',
        example: 'Mana, nama, lafa, bishaan.',
      },
      {
        term: 'Dhamjecha Hirkataa',
        definition: 'Dhamjecha kophaa dhaabbachuu hin dandeenye, kan maxxantuu ta\'ee dhufu.',
        translation: 'Bound Morpheme - affix attached to a base root.',
        example: '-oota, -ummaa, -eenya.',
      },
      {
        term: 'Matima fi Aantima',
        definition: 'Matimni gocha raawwataa, aantimni ammoo gocha fudhataadha.',
        translation: 'Subject and Object in sentence syntax.',
        example: 'Bilisummaan (Matima) sangaa (Aantima) bite.',
      },
    ],
    questions: [
      {
        id: 1,
        question: 'Dhamjecha kophaa isaa dhaabbatee hiika guutuu dabarsuu danda\'u maal jedhama?',
        questionTranslation: 'What is a morpheme that can stand alone with complete meaning called?',
        options: [
          'A. Dhamjecha Hirkataa',
          'B. Dhamjecha Walabaa',
          'C. Maxxantuu Duubaa',
          'D. Sagalee Qeenxee',
        ],
        correctIndex: 1,
        answerKey: 'B',
        explanation:
          'Dhamjecha Walabaa (Free Morpheme) jechuun dhamjecha of danda\'ee kophaa isaa dhaabbatee hiika guutuu kennuudha (fakkeenyaaf: mana, lafa). Dhamjechi hirkataan garuu of danda\'ee hin dhaabbatu.',
        explanationEn:
          'Option B is correct. A Free Morpheme can stand independently as an autonomous word with full semantic meaning (e.g. mana, lafa).',
      },
      {
        id: 2,
        question: 'Hima "Caaltuun bor qormaata fudhatti" jedhu keessatti jechi "qormaata" jedhu tajaajila maalii qaba?',
        questionTranslation: 'In the sentence "Caaltuun bor qormaata fudhatti", what grammatical role does "qormaata" serve?',
        options: [
          'A. Matima (Subject)',
          'B. Gochima (Verb)',
          'C. Aantima (Object)',
          'D. Ibsa-maqaa (Adjective)',
        ],
        correctIndex: 2,
        answerKey: 'C',
        explanation:
          'Himicha keessatti "Caaltuun" Matima (gocha raawwatu), "qormaata" Aantima (gochi fudhachuu irratti raawwatamu), "fudhatti" ammoo Gochima dha. Kanaaf deebiin sirriin Aantima (C) dha.',
        explanationEn:
          'Option C is correct. "Caaltuun" is the Subject, "fudhatti" is the Verb, and "qormaata" is the direct Object upon which the action acts.',
      },
      {
        id: 3,
        question: 'Jecha "Barsiisota" jedhu keessatti maxxantuun "-ota" tajaajila maalii kenna?',
        questionTranslation: 'In the word "Barsiisota", what function does the suffix "-ota" provide?',
        options: [
          'A. Koorniyaa dhalaa agarsiisuu',
          'B. Baay\'ina (Danuubummaa) agarsiisuu',
          'C. Yeroo darbe agarsiisuu',
          'D. Gochima gara maqaatti jijjiiruu',
        ],
        correctIndex: 1,
        answerKey: 'B',
        explanation:
          'Maxxantuun "-ota" ykn "-oota" maqaa qeenxee gara baay\'inaatti (plural form) jijjiiruuf tajaajila. Fakkeenya: Barsiisaa -> Barsiisota; Barataa -> Barattoota.',
        explanationEn:
          'Option B is correct. "-ota" and "-oota" are plural-forming morphemes turning singular nouns into plural nouns.',
      },
      {
        id: 4,
        question: 'Caasaan duraa-duuba jechootaa kan hima Afaan Oromoo isa kami?',
        questionTranslation: 'Which of the following is the standard word order in an Afaan Oromoo declarative sentence?',
        options: [
          'A. Gochima + Matima + Aantima (VSO)',
          'B. Matima + Gochima + Aantima (SVO)',
          'C. Matima + Aantima + Gochima (SOV)',
          'D. Aantima + Matima + Gochima (OSV)',
        ],
        correctIndex: 2,
        answerKey: 'C',
        explanation:
          'Afaan Oromoo keessatti himni baramaa Matima dura irratti, itti aanee Aantima, dhuma irratti ammoo Gochima qabaata (SOV). Fakkeenya: Barataan (S) kitaaba (O) dubbise (V).',
        explanationEn:
          'Option C is correct. Afaan Oromoo follows an SOV (Subject - Object - Verb) word order syntax.',
      },
      {
        id: 5,
        question: 'Jechoota armaan gadii keessaa kamtu Jecha Dachaa (Compound word) dha?',
        questionTranslation: 'Which of the following words is a Compound Word (Jecha Dachaa)?',
        options: [
          'A. Mana-barumsaa',
          'B. Bareedummaa',
          'C. Dhaabbate',
          'D. Qulqullina',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          '"Mana-barumsaa"n jechoota walabaa lama ("mana" fi "barumsaa") walitti fiduudhaan jecha haaraa ijaarame waan ta\'eef Jecha Dachaa (Compound word) jedhama. Warri kaan maxxantuudhaan ijaaramani.',
        explanationEn:
          'Option A is correct. "Mana-barumsaa" combines two autonomous root words ("mana" + "barumsaa") into a single compound word.',
      },
    ],
    examTip:
      'Qormaata Kutaa 9ffaa irratti addaan baafachuu dhamjecha walabaa fi hirkataa irratti xiyyeeffadhu; maxxantuuleen akka "-ummaa", "-eenya", fi "-oota" yeroo baay\'ee gaaffiif dhufu.',
    examTipEn:
      'Focus heavily on identifying bound morphemes versus free morphemes for Grade 9 exams; suffixes like "-ummaa" and "-oota" appear frequently in national assessments.',
  },
  {
    id: 'afaan-oromoo-afoola',
    title: 'Boqonnaa 2: Og-barruu fi Afoola Oromoo',
    titleEn: 'Unit 2: Folklore & Oral Literature (Afoola)',
    subject: 'Afaan Oromoo',
    subjectEn: 'Afaan Oromoo (Oromo Literature)',
    grade: 'Kutaa 9ffaa (Grade 9)',
    category: 'Afaan Oromoo',
    estimatedMinutes: 14,
    topicSummary:
      'Mammaksa, Hiibboo, Geerarsa, Weedduu, Eebba fi Abaarsa, fi caasaa Og-barruu afaanii kan uummata Oromoo.',
    topicSummaryEn:
      'Proverbs (Mammaksa), Riddles (Hiibboo), Heroic chants (Geerarsa), Traditional songs, and Oral literary forms of the Oromo people.',
    sections: [
      {
        heading: '1. Mammaksa Oromoo fi Tajaajila Isaa (Proverbs)',
        headingEn: '1. Oromo Proverbs and Societal Functions',
        summary:
          'Mammaaksi gosa og-barruu afaanii isa muuxannoo fi beekumsa uummata Oromoo dhalootaa dhalootatti dabarsuudha. Dubbii mi\'eessuuf, qeequuf, fi gorfachuuf tajaajila.',
        summaryEn:
          'Proverbs represent traditional oratory synthesizing centuries of community wisdom, used to enrich dialogue, advise, and critique behavior.',
        bulletPoints: [
          'Gabaabina fi qorqalbii qabaachuu: Jechoota muraasaan ergaa guddaa dabarsa.',
          'Ummanni Oromoo yeroo marii fi haasaa geggeessu dubbii cimsachuuf mammaaksatti dhimma baha.',
          'Mammaaksi haqa, dhugaa, obsa, fi jireenya hawaasummaa calaqqisiisa.',
        ],
        bulletPointsEn: [
          'Brevity and punchiness: Conveys profound multi-layered messages using economical phrasing.',
          'Serves as conversational authority during dispute resolutions, elder councils, and daily discourse.',
          'Reflects core cultural values: truth, justice, patience, diligence, and collective ethics.',
        ],
        examples: [
          '"Kan qotuuf kan nyaatu wal hin dhabu" - Gootummaa fi jabinni hojii bu\'aa akka qabu barsiisa.',
          '"Harka lamaan ibidda qaban" - Hojii baay\'ee walitti hin qabatinaa jedha.',
          '"Bishaan fagootti lafa hin qotani" - Wanta dhiyoo qabnutti gargaaramuu qabna.',
        ],
      },
      {
        heading: '2. Hiibboo fi Faayidaa Isaa (Riddles - Intellectual Brain Games)',
        headingEn: '2. Riddles (Hiibboo) & Cognitive Development',
        summary:
          'Hiibboon tapha afaanii kan dandeettii yaaduu, qorannoo, fi sammuu qaruuf daa\'immanii fi dargaggoota gidduutti taphatamuudha.',
        summaryEn:
          'Hiibboo is an interactive oral riddle tradition fostering deductive reasoning, mental agility, and observational acuity among young learners.',
        bulletPoints: [
          'Adeemsa taphaa: Taphataan jalqaba "Hiibboo?" jedha; deebisaan ammoo "Hibbakka!" jedhee deebisa.',
          'Yoo namni deebisuu dadhabe, "Biyyasaa kenni" jedhama; biyyi badhaasaaf kennama.',
          'Daa\'imman uumama naannoo isaanii akka hubatan taasisa.',
        ],
        bulletPointsEn: [
          'Call-and-response protocol: Initiator says "Hiibboo?", respondent accepts with "Hibbakka!".',
          'Penalty / reward mechanic: If stumped, the answerer cedes symbolic territories ("Biyya kenni").',
          'Sharpens children\'s comprehension of animal behaviors, biology, tools, and natural phenomena.',
        ],
        examples: [
          '"Ganama miila afuriin, guyyaa miila lamaan, galgala miila sadiin deema? - Nama (daa\'imummaa, ga\'eessummaa, manguddummaa)."',
          '"Waan adii dhagaa fakkaatu, kan caccabee dhangala\'u? - Hanqaaquu (Buupphii)."',
        ],
      },
      {
        heading: '3. Geerarsa fi Weedduu (Heroic Chants & Songs)',
        headingEn: '3. Heroic Poetry (Geerarsa) and Traditional Lyrics',
        summary:
          'Geerarsi gootummaa, jabinna, gumaa fi seenaa abbootii kan calaqqisiisu yoo ta\'u; weedduun ammoo sirboota hawaasummaa adda addaati.',
        summaryEn:
          'Geerarsa is heroic poetic chanting honoring courage and triumph; Weedduu encompasses diverse situational folk melodies.',
        bulletPoints: [
          'Geerarsi gootni yeroo adamsarraa galu ykn diina injifatee boonee geeraruudha.',
          'Weedduu Hojii: Yeroo qonnaa, haamaa, fi midhaan dhahuu kan sirbamu dadhabbiin akka hin dhagahamne godha.',
          'Weedduu Fuudhaaf Heerumaa: Sirna gaa\'ilaa irratti gammadanii sirbamu.',
        ],
        bulletPointsEn: [
          'Geerarsa: Chanted rhythmically by celebrated individuals upon courageous accomplishments or returns.',
          'Work Songs (Weedduu Hojii): Chanted during harvest, plowing, and threshing to coordinate labor rhythm.',
          'Wedding Songs: Celebrating kinship, heritage, and blessings during matrimony.',
        ],
        examples: [
          'Weedduu daa\'immanii (Urursuu): "Hurruubee koo hurruubaa, daa\'ima garaa jabaa..."',
        ],
      },
    ],
    keyTerms: [
      {
        term: 'Mammaksa',
        definition: 'Dubbii qolaa muuxannoo fi beekumsa hawaasaa irratti hundaa\'ee gorfachuuf oolu.',
        translation: 'Proverb - pithy community wisdom.',
        example: '"Loon abbaan gaafa hin qabne, kormi ija hin baasu."',
      },
      {
        term: 'Hiibboo',
        definition: 'Tapha afaanii sammuu qaruufi dandeettii yaaduu cimsachuuf taphatamu.',
        translation: 'Riddle - analytical word puzzle.',
        example: 'Hiibboo? - Hibbakka!',
      },
      {
        term: 'Geerarsa',
        definition: 'Sirba ykn jecha gootummaa kan gootni dhiiraa jabinna isaa ittiin mul\'isu.',
        translation: 'Heroic ballad / Victory chanting.',
        example: 'Geerarsa adamsaa fi lolaa.',
      },
      {
        term: 'Afoola',
        definition: 'Og-barruu afaaniin dhalootaa dhalootatti afaaniin darbaa dhufe.',
        translation: 'Folklore / Oral literature.',
        example: 'Dur-durii, mammaaksa, hiibboo.',
      },
    ],
    questions: [
      {
        id: 1,
        question: 'Tapha afaanii "Hiibboo... Hibbakka" jedhamee dhihaatu keessatti kaayyoon inni guddaan maali?',
        questionTranslation: 'What is the primary developmental goal of the traditional riddle game (Hiibboo)?',
        options: [
          'A. Dandeettii yaaduu fi sammuu qaruu',
          'B. Miilaan fiiganii morkachuu',
          'C. Galmee jechootaa qopheessuu',
          'D. Sirna gaa\'ilaa geggeessuu',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Hiibboon tapha dandeettii yaaduu, qorannoo sammuu, fi hubannoo naannoo daa\'immaniif gabbisuu fi qaruuf ooludha. Kanaaf (A)n sirriidha.',
        explanationEn:
          'Option A is correct. Hiibboo is designed to stimulate analytical thinking, creative deduction, and observational intelligence.',
      },
      {
        id: 2,
        question: 'Mammaaksi "Kan qotuuf kan nyaatu wal hin dhabu" jedhu ergaa akkamii dabarsa?',
        questionTranslation: 'What core lesson does the proverb "Kan qotuuf kan nyaatu wal hin dhabu" teach?',
        options: [
          'A. Hojii jibbisiisuu',
          'B. Jabinni hojii fi qonni bu\'aa fi jireenya akka fidu',
          'C. Harka maratanii taa\'uu',
          'D. Fira ofii komachuu',
        ],
        correctIndex: 1,
        answerKey: 'B',
        explanation:
          'Mammaaksi kun namni cimee qotee hojjete bu\'aa qabeessa akka ta\'uufi hojiin bu\'aa akka qabu barsiisa. Deebiin (B) dha.',
        explanationEn:
          'Option B is correct. It underscores the virtue of agricultural industry and conscientious labor leading to fruitful sustenance.',
      },
      {
        id: 3,
        question: 'Sirba gootummaa kan dhiirri gootni injifannoo ykn jabinna isaa ittiin ibsatu maal jedhama?',
        questionTranslation: 'What is the heroic chanting tradition in which achievements and courage are poetically voiced?',
        options: [
          'A. Geerarsa',
          'B. Urursuu',
          'C. Mirriisa',
          'D. Ateetee',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Geerarsi faaruu gootummaa fi jabinna dhiirri gootni ittiin boonuudha. Urursuun kan daa\'immaniiti, Ateeteen kan dubartootaati.',
        explanationEn:
          'Option A is correct. Geerarsa is the renowned Oromo heroic poetic chant celebrating bravery and victory.',
      },
      {
        id: 4,
        question: 'Sirboota yeroo midhaan qotan, haaman ykn dhawan sirbaman maaltu jedhama?',
        questionTranslation: 'What are the songs chanted collectively during plowing, harvesting, or threshing called?',
        options: [
          'A. Weedduu Hojii',
          'B. Weedduu Jaalalaa',
          'C. Weedduu Daa\'immanii',
          'D. Geerarsa',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Weedduun yeroo hojii qonnaa fi haamaa sirbamu "Weedduu Hojii" jedhama; dadhabbii hir\'isuufi hojicha saffisiisuuf tajaajila.',
        explanationEn:
          'Option A is correct. Work songs (Weedduu Hojii) energize communal labor, synchronizing rhythm and alleviating fatigue.',
      },
      {
        id: 5,
        question: 'Og-barruu afaanii keessatti seenaan durii kan haala uumamaa ykn beelladootaan fakkeeffamee dhihaatu maal jedhama?',
        questionTranslation: 'In oral literature, what is a traditional fictional fable featuring animal characters called?',
        options: [
          'A. Dur-durii (Fable / Folktale)',
          'B. Heera Caffee',
          'C. Sirna Gadaa',
          'D. Caasluga',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Dur-duriin (Folk story/Fable) seenaa durii kan afaaniin dhalootaa dhalootatti darbaa dhufee fi barsiisa jireenyaa of keessaa qabuudha.',
        explanationEn:
          'Option A is correct. Dur-durii refers to oral folktales, animal fables, and ancestral parables passed down orally.',
      },
    ],
    examTip:
      'Mammaaksa fi Hiibboo yeroo dubbiftu hiika qolaa isaanii irratti xiyyeeffadhu; qormaata keessatti "Mammaaksi kun maal barsiisa?" jedhamee gaafatama.',
    examTipEn:
      'Analyze the figurative and ethical meaning behind proverbs and riddles, as Grade 9 exams test your ability to interpret underlying themes.',
  },
  {
    id: 'afaan-oromoo-gadaa',
    title: 'Boqonnaa 3: Sirna Gadaa fi Seenaa Aadaa',
    titleEn: 'Unit 3: The Gadaa System & Cultural Heritage',
    subject: 'Afaan Oromoo',
    subjectEn: 'Afaan Oromoo & Social Studies',
    grade: 'Kutaa 9ffaa (Grade 9)',
    category: 'Aadaa',
    estimatedMinutes: 15,
    topicSummary:
      'Hundeeffama Sirna Gadaa, sadarkaalee Gadaa (waggaa 8-8n), qaamolee bulchiinsaa (Abbaa Gadaa, Caffee), fi falaasama Safuu fi Dhugaa.',
    topicSummaryEn:
      'Foundations of the democratic Gadaa system, the 8-year age-grade cycles, administrative councils, and the moral pillars of Safuu and Dhugaa.',
    sections: [
      {
        heading: '1. Maalummaa Sirna Gadaa (The Gadaa System)',
        headingEn: '1. Overview of the Gadaa Democratic System',
        summary:
          'Sirni Gadaa sirna dimokraatawaa, siyaasaa, dinagdee, hawaasummaa fi amantii kan uummanni Oromoo waggoota dhibbootaaf ittiin of bulchaa tureedha. UNESCOn hambaa addunyaa godhee galmeesseera.',
        summaryEn:
          'The Gadaa System is an indigenous socio-political democratic governance system developed by the Oromo people, officially inscribed on the UNESCO Representative List of Intangible Cultural Heritage.',
        bulletPoints: [
          'Aangoon karaa nagaa fi seera qabeessaan waggaa saddeet saddeetiin wal-harkaa fuudhama.',
          'Namni tokko sadarkaa Gadaa keessatti waggaa 8 qofa bulcha; aangoo irra tulluu hin taa\'u.',
          'Dubartoonni Sirna Siiqqeetiin mirga isaanii fi nagaa hawaasaa eegsisu.',
        ],
        bulletPointsEn: [
          'Power is transferred peacefully and constitutionally every eight years without armed conflict.',
          'Strict term limits prevent dynastic accumulation of arbitrary power.',
          'Women exercise parallel institutional authority through the venerated Siiqqee institution.',
        ],
        examples: [
          'Sadarkaan Gadaa tokko waggaa 8 tura (8 × 5 = 40 waggaa marsaa tokko keessatti).',
          'Odaan (fkn. Odaa Nabee, Odaa Bultum, Odaa Roobaa, Odaa Bisil) iddoo seera itti tumaniifi Caffee itti taa\'aniidha.',
        ],
      },
      {
        heading: '2. Sadarkaalee Gadaa (The 8-Year Gadaa Age-Grades)',
        headingEn: '2. The Progressive Gadaa Age-Grades',
        summary:
          'Namni dhalatee hanga dullumaatti sadarkaalee Gadaa adda addaa keessa darba. Sadarkaan tokko waggoota 8 qaba.',
        summaryEn:
          'Individuals transition through structured 8-year cohorts that cultivate childhood education, military defense, leadership, and judicial mentorship.',
        bulletPoints: [
          '1. Dabballee (Umurii 0 - 8): Daa\'imman; rifeensi isaanii hin haaddamu; haati fi abbaan jaalalaan guddifatu.',
          '2. Gaammee Xiqqa (Umurii 9 - 16): Barumsa aadaa, seenaa fi tika beelladaa baratu.',
          '3. Gaammee Gurguddaa / Kuusaa (Umurii 17 - 24 fi 25 - 32): Leenjii ittisa biyyaa fi hojii lolaa qophaa\'u.',
          '4. Raaba Doorii (Umurii 33 - 40): Bulchiinsaa fi seera barachuu; sirna fuudhaa raawwachuu.',
          '5. Gadaa / Luba (Umurii 41 - 48): Sadarkaa bulchiinsa ol-aanaa; Abbaan Gadaa sadarkaa kanaan biyya bulcha.',
          '6. Yuba fi Gadamojjii (Umurii 49 ol): Sadarkaa marii, eebbaa fi gorsaa.',
        ],
        bulletPointsEn: [
          'Dabballee (0-8 yrs): Innocent childhood phase; revered with special protective blessings.',
          'Gaammee Xiqqa (9-16 yrs): Pastoral duties, cultural lore, and oral history mentorship.',
          'Gaammee Gurguddaa & Kuusaa (17-32 yrs): Physical defense training and civic responsibility.',
          'Raaba Doorii (33-40 yrs): Constitutional preparation, civic apprenticeship, and family formation.',
          'Gadaa/Luba (41-48 yrs): Active governmental stewardship; governance under the Abbaa Gadaa.',
          'Yuba & Gadamojjii (49+ yrs): Transition to esteemed judicial counselors, mediators, and elder blessing givers.',
        ],
        examples: [
          'Dabballeen "ilmoo gubbaa" jedhama; adabni kamiyyuu irratti hin raawwatamu.',
        ],
      },
      {
        heading: '3. Falaasama Safuu fi Dhugaa (Moral Ethics: Safuu & Truth)',
        headingEn: '3. Moral Ethics: Safuu & Truth',
        summary:
          'Safuun daangaa kabajaa, naamusaa, fi dhimma uumamaa fi hawaasaa gidduu jiru eeguudha. Dhugaan ammoo bu\'uura murtee fi jireenyaati.',
        summaryEn:
          'Safuu is the foundational cosmic and moral equilibrium guiding respect between humans, natural ecology, generations, and the Creator.',
        bulletPoints: [
          'Safuun maatii gidduutti: Daa\'imni guddaa kabajuu, guddaan daa\'ima kunuunsuu.',
          'Safuun uumamaa: Muka uumamaa murtii malee hin mukan, bishaan hin xureessan.',
          'Laguu: Wanta aadaan dhowwu irraa of qusachuu.',
        ],
        bulletPointsEn: [
          'Intergenerational reverence: Youth honor elders; elders nurture and protect youth.',
          'Environmental stewardship: Trees are not felled needlessly; natural water sources are sacredly safeguarded.',
          'Laguu: Voluntary self-restraint and abstention from culturally prohibited transgression.',
        ],
        examples: [
          '"Dhugaan ni qal\'atti malee hin cittu" - Dhugaan yoomiyyuu akka mo\'atu agarsiisa.',
        ],
      },
    ],
    keyTerms: [
      {
        term: 'Sirna Gadaa',
        definition: 'Sirna dimokraatawaa Oromoon waggoota saddeet saddeetiin aangoofi heera ittiin wal-harkaa fuudhu.',
        translation: 'The Gadaa System - egalitarian Oromo democratic governance.',
        example: 'Gadaan UNESCOtti galmaa\'eera.',
      },
      {
        term: 'Abbaa Gadaa',
        definition: 'Hoggana ol-aanaa sirna Gadaa kan waggaa 8f uummataan filatamu.',
        translation: 'President / Leader of the Gadaa government.',
        example: 'Abbaan Gadaa Caffee geggeessa.',
      },
      {
        term: 'Safuu',
        definition: 'Naamusa, kabajaa fi daangaa uumamaa fi hawaasaa gidduu jiru eeguu.',
        translation: 'Moral equilibrium, sacred boundaries, and mutual respect.',
        example: 'Safuu cabsuun aadaa Oromoo keessatti dhowwaadha.',
      },
      {
        term: 'Caffee',
        definition: 'Yaa\'ii fi mana-marii ol-aanaa uummataa kan seera itti tumaniifi murteessan.',
        translation: 'Parliament / Legislative assembly of the Gadaa system.',
        example: 'Caffee Oromoo Odaa jalatti taa\'a.',
      },
    ],
    questions: [
      {
        id: 1,
        question: 'Sirna Gadaa keessatti sadarkaan Gadaa tokko waggaa meeqa tura?',
        questionTranslation: 'How many years does an individual stay in a single Gadaa age-grade?',
        options: [
          'A. Waggaa 4',
          'B. Waggaa 5',
          'C. Waggaa 8',
          'D. Waggaa 10',
        ],
        correctIndex: 2,
        answerKey: 'C',
        explanation:
          'Sirna Gadaa keessatti sadarkaan kamiyyuu waggaa saddeet (8) tura. Waggaa saddeet booda gara sadarkaa itti aanutti darbu.',
        explanationEn:
          'Option C is correct. Each sequential Gadaa grade spans an exact term of 8 years.',
      },
      {
        id: 2,
        question: 'Hogganaan ol-aanaan sirna Gadaa kan waggaa saddeetiif biyya bulchuuf filatamu eenyu?',
        questionTranslation: 'Who is the supreme elected leader of the Gadaa administrative term for eight years?',
        options: [
          'A. Abbaa Bokkuu / Abbaa Gadaa',
          'B. Abbaa Dulaa',
          'C. Gadamojjii',
          'D. Dabballee',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Hogganaan ol-aanaan sirna Gadaa Abbaa Gadaa (Abbaa Bokkuu) jedhama. Waggaa 8f seera Caffeen baase hordofee uummata tajaajila.',
        explanationEn:
          'Option A is correct. The Abbaa Gadaa presides over executive governance during the active 8-year Luba phase.',
      },
      {
        id: 3,
        question: 'Sadarkaa Gadaa isa jalqabaa kan daa\'imman umurii 0 hanga 8 qaban of keessatti qabatu kami?',
        questionTranslation: 'Which is the inaugural Gadaa age-grade comprising children between ages 0 and 8?',
        options: [
          'A. Dabballee',
          'B. Gaammee Xiqqa',
          'C. Raaba Doorii',
          'D. Kuusaa',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Sadarkaan inni jalqabaa "Dabballee" jedhama (umurii 0-8). Dabballeen daa\'ima kabajamaa kan rifeensi mataa isaa hin haadamneedha.',
        explanationEn:
          'Option A is correct. Dabballee is the childhood age grade spanning ages 0 to 8 years.',
      },
      {
        id: 4,
        question: 'Aadaa Oromoo keessatti "Safuu" jechuun maal ibsa?',
        questionTranslation: 'In Oromo ethical philosophy, what does the core concept of "Safuu" signify?',
        options: [
          'A. Waraana fi loltuu qindeessuu',
          'B. Naamusa, daangaa kabajaa fi hariiroo gaarii uumamaa fi nama gidduu jiru',
          'C. Gabaa ba\'anii daldalachuu',
          'D. Fardiin gammadanii fiiguu',
        ],
        correctIndex: 1,
        answerKey: 'B',
        explanation:
          'Safuun naamusa ol-aanaa, kabajaa maatii, jaarsolii, uumamaa fi uumaa gidduu jiru eeguudha. Kanaaf (B)n deebii sirriidha.',
        explanationEn:
          'Option B is correct. Safuu represents the moral boundaries, mutual reverence, and cosmic order governing life and nature.',
      },
      {
        id: 5,
        question: 'Iddoon uummanni Oromoo mukeen Odaa jalatti walga\'ee seera itti tumu maal jedhama?',
        questionTranslation: 'What is the sovereign assembly and supreme legislative council meeting beneath the Odaa tree called?',
        options: [
          'A. Caffee',
          'B. Dabballee',
          'C. Gadamojjii',
          'D. Siiqqee',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Caffeen mana-marii ol-aanaa Oromoo kan seera haaraa itti tumaniifi heera Gadaa itti haaromsaniidha. Iddoon kun yeroo baay\'ee Odaa jalatti ta\'a.',
        explanationEn:
          'Option A is correct. The Caffee is the parliamentary congress convened beneath the sacred Odaa sycamore fig tree.',
      },
    ],
    examTip:
      'Waggoota sadarkaalee Gadaa (0-8, 9-16, 17-24, 25-32, 33-40, 41-48) tartiibaan qomatti qabadhu; qormaata keessatti "Sadarkaan 3ffaan maali?" jedhamee gaafatama.',
    examTipEn:
      'Memorize the eight-year chronological brackets for each Gadaa grade; sequence questions are staple favorites on Grade 9 national examinations.',
  },
  {
    id: 'biology-kutaa9-seelii',
    title: 'Biology Kutaa 9: Caasaa Seelii fi Lubbuqabeeyyii',
    titleEn: 'Unit 4: Cell Biology & Microscopic Life',
    subject: 'Biology',
    subjectEn: 'Grade 9 Biology',
    grade: 'Kutaa 9ffaa (Grade 9)',
    category: 'Saayinsii',
    estimatedMinutes: 14,
    topicSummary:
      'Caasaa seelii biqiltootaa fi bineensotaa, qaamolee seelii (orgaaneloota), fi seera tiyoorii seelii.',
    topicSummaryEn:
      'Plant and animal cellular architecture, microscopic organelles (nucleus, mitochondria, chloroplast), and classical cell theory.',
    sections: [
      {
        heading: '1. Maalummaa Seelii fi Tiyooriisaa (Cell Theory)',
        headingEn: '1. Cell Concept & Modern Cell Theory',
        summary:
          'Seeliin yuuniitii bu\'uuraa jireenya lubbuqabeeyyii hundumaati. Saayintistiin Robert Hooke bara 1665tti seelii korqii (cork) keessatti arge.',
        summaryEn:
          'The cell is the structural and functional unit of all living organisms, first discovered by Robert Hooke in 1665 using an early microscope.',
        bulletPoints: [
          'Lubbuqabeeyyiin hundi seelii tokko (unicellular) ykn seelota baay\'ee (multicellular) irraa ijaaraman.',
          'Seeliin kamiyyuu seelii duraan ture irraa qofa dhalata (division of pre-existing cells).',
          'Sochiin jireenyaa fi wal-nyaatinsi keemikaalaa hundi seelii keessatti raawwatama.',
        ],
        bulletPointsEn: [
          'All living organisms are composed of one (unicellular) or more (multicellular) cells.',
          'New cells arise exclusively from the division of pre-existing living cells.',
          'Metabolic and life-sustaining biochemical processes occur within cell boundaries.',
        ],
        examples: [
          'Amiibaan (Amoeba) fi Baakteeriyaan lubbuqabeeyyii seel-qeenxeedha.',
          'Namni, bineensonni fi biqiltoonni lubbuqabeeyyii seel-danuudha.',
        ],
      },
      {
        heading: '2. Orgaaneloota Seelii (Cell Organelles & Functions)',
        headingEn: '2. Key Cellular Organelles and Their Roles',
        summary:
          'Seelii keessatti orgaanelonni tajaajila addaa addaa kennan ni argamu.',
        summaryEn:
          'Within the cytoplasm reside specialized organelles that carry out respiration, synthesis, storage, and genetic coordination.',
        bulletPoints: [
          'Niwukilaasii (Nucleus): Sammuu seeliiti; DNA fi odeeffannoo dhalootaa of keessatti qabata.',
          'Maayitookondiriyaa (Mitochondria): "Iddoo maddisiisa anniisaa" (Powerhouse of the cell); sukkaara gubuun ATP maddisiisa.',
          'Raayiboosoomii (Ribosome): Pirootiinii ijaaruuf tajaajila.',
          'Dicha Seelii (Cell Wall): Seelii biqiltootaa qofa keessatti argama; jabinna fi roga kennaaf.',
          'Kilooropilaastii (Chloroplast): Seelii biqiltootaa keessatti ifa aduu qabachuudhaan footoosinteesisiif oola.',
        ],
        bulletPointsEn: [
          'Nucleus: Control center regulating cell activities and harboring genetic DNA.',
          'Mitochondria: "Powerhouse of the cell" generating ATP via aerobic cellular respiration.',
          'Ribosomes: Molecular machines responsible for protein synthesis.',
          'Cell Wall: Rigid cellulose outer layer exclusive to plant cells providing structural support.',
          'Chloroplast: Organelle carrying chlorophyll for photosynthesis in green plants.',
        ],
        examples: [
          'Garaagarummaa: Seeliin biqiltootaa Cell Wall fi Chloroplast qaba; kan bineensotaa garuu hin qabu.',
        ],
      },
    ],
    keyTerms: [
      {
        term: 'Seelii (Cell)',
        definition: 'Yuuniitii bu\'uuraa caasaa fi tajaajila lubbuqabeeyyiiti.',
        translation: 'Cell - fundamental structural unit of life.',
        example: 'Seeliin dhiigaa, seeliin narvii.',
      },
      {
        term: 'Maayitookondiriyaa',
        definition: 'Orgaanelii seelii keessatti anniisaa (ATP) uumu.',
        translation: 'Mitochondria - the powerhouse of the cell.',
        example: 'Respiration takes place in mitochondria.',
      },
      {
        term: 'Kilooropilaastii',
        definition: 'Orgaanelii seelii biqiltootaa ifa aduu fayyadamee nyaata itti qopheessu.',
        translation: 'Chloroplast - site of photosynthesis.',
        example: 'Contains green chlorophyll pigment.',
      },
    ],
    questions: [
      {
        id: 1,
        question: 'Orgaanelii seelii isa "Madda Anniisaa Seelii" (Powerhouse of the cell) jedhamee beekamu kami?',
        questionTranslation: 'Which organelle is universally dubbed the "Powerhouse of the cell"?',
        options: [
          'A. Raayiboosoomii (Ribosome)',
          'B. Maayitookondiriyaa (Mitochondria)',
          'C. Niwukilaasii (Nucleus)',
          'D. Vaakiyoolii (Vacuole)',
        ],
        correctIndex: 1,
        answerKey: 'B',
        explanation:
          'Maayitookondiriyaan adeemsa hargansuu seelii (cellular respiration) geggeessuun anniisaa ATP uuma; kanaaf madda anniisaa seelii jedhama.',
        explanationEn:
          'Option B is correct. Mitochondria convert nutrients into adenosine triphosphate (ATP) through cellular respiration.',
      },
      {
        id: 2,
        question: 'Caasaan armaan gadii keessaa kamtu Seelii Biqiltootaa keessatti argama garuu Seelii Bineensotaa keessatti hin argamne?',
        questionTranslation: 'Which structural feature is present in plant cells but strictly absent from animal cells?',
        options: [
          'A. Dicha Seelii (Cell Wall) fi Kilooropilaastii',
          'B. Niwukilaasii fi Maayitookondiriyaa',
          'C. Membireenii Seelii fi Saayitoopilaazimii',
          'D. Raayiboosoomii qofa',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Seeliin biqiltootaa Dicha seelii (Cell Wall) jabaa fi Kilooropilaastii (footosinteesisii kan geggeessu) qaba; seeliin bineensotaa garuu lamaan kana hin qabu.',
        explanationEn:
          'Option A is correct. Both a rigid cellulose cell wall and chlorophyll-containing chloroplasts are distinct plant cell traits.',
      },
      {
        id: 3,
        question: 'Orgaaneliin seelii keessatti pirootiinii ijaaruuf tajaajilu kami?',
        questionTranslation: 'Which cellular structure is the primary site of protein synthesis?',
        options: [
          'A. Raayiboosoomii (Ribosome)',
          'B. Vaakiyoolii',
          'C. Kilooropilaastii',
          'D. Lysosome',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Raayiboosoomiin (Ribosome) orgaanelii seelii keessatti ergaa RNA bu\'uura godhachuun pirootiinoota ijaarudha.',
        explanationEn:
          'Option A is correct. Ribosomes translate genetic mRNA sequences to synthesize polypeptide protein chains.',
      },
      {
        id: 4,
        question: 'Saayintistiin bara 1665tti jalqaba seelii korqii (cork) ilaaluun maqaa "Cell" jedhu kenne eenyu?',
        questionTranslation: 'Who first observed cork compartments under a microscope in 1665 and coined the term "cell"?',
        options: [
          'A. Robert Hooke',
          'B. Charles Darwin',
          'C. Gregor Mendel',
          'D. Louis Pasteur',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Robert Hooke bara 1665tti mikirooskoppii isaa fayyadamee kutaalee akka manneen xixinnoo korqii keessatti arge "Cells" jedhee moggaase.',
        explanationEn:
          'Option A is correct. Robert Hooke coined the term cell in 1665 after viewing cell walls in cork slices.',
      },
      {
        id: 5,
        question: 'Sadarkaalee qindoomina lubbuqabeeyyii keessatti kan seeliitti aanee dhufu isa kami?',
        questionTranslation: 'In biological hierarchical organization, what tier directly follows individual cells?',
        options: [
          'A. Tishuu (Tissue)',
          'B. Qaama (Organ)',
          'C. Sirna Qaamaa (Organ System)',
          'D. Lubbuqabeessa (Organism)',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Dura-duubni qindoominaa: Seelii -> Tishuu (seelota wal-fakkaatan) -> Qaama -> Sirna Qaamaa -> Lubbuqabeessa guutuu. Kanaaf seeliitti kan aanu Tishuudha.',
        explanationEn:
          'Option A is correct. Groups of specialized cells aggregate to form biological tissues (e.g., epithelial, muscular, vascular tissues).',
      },
    ],
    examTip:
      'Garaagarummaa Seelii Biqiltootaa fi Bineensotaa (Cell wall, chloroplast, shape, vacuole size) taabiloodhaan yaadadhu; qormaata Ministry Grade 9 irratti gaaffii qulqulluudha.',
    examTipEn:
      'Always review the side-by-side contrast between plant and animal cells (wall, plastids, central vacuole); it is a guaranteed question on Grade 9 national exams.',
  },
  {
    id: 'chemistry-kutaa9-atami',
    title: 'Chemistry Kutaa 9: Caasaa Atamii fi Walnyaatinsa',
    titleEn: 'Unit 5: Atomic Structure & Chemical Bonding',
    subject: 'Chemistry',
    subjectEn: 'Grade 9 Chemistry',
    grade: 'Kutaa 9ffaa (Grade 9)',
    category: 'Saayinsii',
    estimatedMinutes: 13,
    topicSummary:
      'Partikiloota atamii (pirootoonii, niwutiroonii, elektiroonii), lakkoofsa atamawaa (Z), baay\'ina lakkoofsa massaa (A), fi hidhoo keemikaalaa.',
    topicSummaryEn:
      'Subatomic particles (protons, neutrons, electrons), atomic number (Z), mass number (A), electron shells, and chemical bonding mechanisms.',
    sections: [
      {
        heading: '1. Partikiloota Atamii (Subatomic Particles)',
        headingEn: '1. Subatomic Particles & Charges',
        summary:
          'Atamiin partikiloota bu\'uuraa sadii irraa ijaarama: Pirootoonii, Niwutiroonii, fi Elektiroonii.',
        summaryEn:
          'Every atom consists of a dense central nucleus harboring protons and neutrons, orbited by negative electrons.',
        bulletPoints: [
          'Pirootoonii (p+): Chaarjii pozaatiivii (+1) qaba, niwukilaasii keessatti argama.',
          'Niwutiroonii (n0): Chaarjii hin qabu (niwutiraala), niwukilaasii keessatti argama.',
          'Elektiroonii (e-): Chaarjii nagaatiivii (-1) qaba, naannoo niwukilaasiitti qola (shell) irra naanna\'a.',
          'Massaan atamii irra jireessi niwukilaasii (pirootoonii + niwutiroonii) keessatti kuufama.',
        ],
        bulletPointsEn: [
          'Proton (p+): Positive charge (+1), mass ~1 amu, resides inside nucleus.',
          'Neutron (n0): Neutral charge (0), mass ~1 amu, resides inside nucleus.',
          'Electron (e-): Negative charge (-1), negligible mass, revolves in energy shells.',
          'Almost all atomic mass is concentrated in the dense nucleus (protons + neutrons).',
        ],
        examples: [
          'Lakkoofsi Atamawaa (Z) = Baay\'ina Pirootoonii.',
          'Lakkoofsi Massaa (A) = Pirootoonii (p) + Niwutiroonii (n).',
        ],
      },
      {
        heading: '2. Hidhoo Keemikaalaa (Chemical Bonding: Ionic vs Covalent)',
        headingEn: '2. Chemical Bonding: Ionic vs Covalent',
        summary:
          'Atamoonni tasgabbaa\'uuf (octeeti eeggachuuf) elektiroonii wal-jijjiiru ykn waloo godhatu.',
        summaryEn:
          'Atoms react to attain stable noble gas electron configurations (the Octet rule) via electron exchange or sharing.',
        bulletPoints: [
          'Hidhoo Aayoonikii (Ionic Bond): Elektiroonii guutummaatti kennuu fi fudhachuun gidduu meetaalii fi al-meetaaliitti uumama (fkn. NaCl).',
          'Hidhoo Kovaalantii (Covalent Bond): Elektiroonii walootti qooddachuun al-meetaalota gidduutti uumama (fkn. H2O, CO2).',
        ],
        bulletPointsEn: [
          'Ionic Bond: Formed via complete electron transfer from a metal to a non-metal cation and anion attraction.',
          'Covalent Bond: Formed via mutual electron pair sharing between electronegative non-metal atoms.',
        ],
        examples: [
          'Soogidda Nyaataa (NaCl): Na+ fi Cl- hidhoo aayoonikiitiin walitti qabamu.',
          'Bishaan (H2O): Hidhoo kovaalantiitiin elektiroonota qooddachuun tolfama.',
        ],
      },
    ],
    keyTerms: [
      {
        term: 'Lakkoofsa Atamawaa (Z)',
        definition: 'Baay\'ina pirootoonota atamii tokko keessatti argamaniiti.',
        translation: 'Atomic Number (Z) - number of protons in a nucleus.',
        example: 'Kaarbooniin Z = 6 qaba.',
      },
      {
        term: 'Lakkoofsa Massaa (A)',
        definition: 'Ida\'ama pirootoonotaa fi niwutiroonota niwukilaasii keessaati.',
        translation: 'Mass Number (A) = Protons + Neutrons.',
        example: 'A = p + n.',
      },
      {
        term: 'Hidhoo Aayoonikii',
        definition: 'Hidhoo elektiroonii kennuu fi fudhachuun uumamu.',
        translation: 'Ionic Bond - electrostatic transfer bond.',
        example: 'NaCl, MgO.',
      },
    ],
    questions: [
      {
        id: 1,
        question: 'Partikiliin atamii chaarjii nagaatiivii (-1) qabuufi naannoo niwukilaasiitti naanna\'u kami?',
        questionTranslation: 'Which subatomic particle carries a negative charge (-1) orbiting outside the nucleus?',
        options: [
          'A. Pirootoonii',
          'B. Elektiroonii',
          'C. Niwutiroonii',
          'D. Positron',
        ],
        correctIndex: 1,
        answerKey: 'B',
        explanation:
          'Elektirooniin (e-) chaarjii nagaatiivii qaba, naannoo niwukilaasiitti qola anniisaa (shells) irratti saffisaan naanna\'a.',
        explanationEn:
          'Option B is correct. Electrons carry a unit negative charge (-1) and orbit the nucleus in defined atomic orbitals.',
      },
      {
        id: 2,
        question: 'Atamiin tokko pirootoonii 11 fi niwutiroonii 12 yoo qabaate, Lakkoofsi Massaa (A) isaa meeqa ta\'a?',
        questionTranslation: 'If an atom contains 11 protons and 12 neutrons, what is its Mass Number (A)?',
        options: [
          'A. 11',
          'B. 12',
          'C. 23',
          'D. 1',
        ],
        correctIndex: 2,
        answerKey: 'C',
        explanation:
          'Lakkoofsi Massaa (A) = Pirootoonii (11) + Niwutiroonii (12) = 23. Kun atamii Soodiyemii (Na) ti.',
        explanationEn:
          'Option C is correct. Mass number A = protons + neutrons = 11 + 12 = 23 (Sodium, Na-23).',
      },
      {
        id: 3,
        question: 'Hidhoon meetaalii fi al-meetaalii gidduutti elektiroonii kennuu fi fudhachuun uumamu maal jedhama?',
        questionTranslation: 'What type of chemical bond forms via complete electron transfer between metal and nonmetal?',
        options: [
          'A. Hidhoo Aayoonikii (Ionic Bond)',
          'B. Hidhoo Kovaalantii (Covalent Bond)',
          'C. Hidhoo Meetaalawaa',
          'D. Hidhoo Hayidiroojinii',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Hidhoon aayoonikii meetaalli elektiroonii dhabee pozaatiivii (cation) yommuu ta\'u, al-meetaalli ammoo fudhatee nagaatiivii (anion) ta\'uun uumama.',
        explanationEn:
          'Option A is correct. Ionic bonding occurs via electron transfer between electropositive metals and electronegative nonmetals.',
      },
      {
        id: 4,
        question: 'Molekiyuuliin bishaanii (H2O) gosa hidhoo kamiin tolfama?',
        questionTranslation: 'What type of chemical bond joins hydrogen and oxygen atoms in water (H2O)?',
        options: [
          'A. Hidhoo Aayoonikii',
          'B. Hidhoo Kovaalantii (Covalent bond)',
          'C. Hidhoo Niwukilaaraa',
          'D. Hidhoo sibiilaa',
        ],
        correctIndex: 1,
        answerKey: 'B',
        explanation:
          'Bishaan (H2O) keessatti atamoonni hayidiroojinii fi ooksijiinii elektiroonota isaanii waloo godhachuun (sharing electrons) waan walitti hidhamaniif Hidhoo Kovaalantiidha.',
        explanationEn:
          'Option B is correct. Water is formed by covalent bonds through electron sharing between oxygen and hydrogen.',
      },
      {
        id: 5,
        question: 'Qoliin anniisaa inni jalqabaa (K-shell) elektiroonota baay\'inaan meeqa baachuu danda\'a?',
        questionTranslation: 'According to the 2n² rule, what is the maximum electron capacity of the innermost K shell (n=1)?',
        options: [
          'A. Elektiroonota 2',
          'B. Elektiroonota 8',
          'C. Elektiroonota 18',
          'D. Elektiroonota 32',
        ],
        correctIndex: 0,
        answerKey: 'A',
        explanation:
          'Seera 2n^2 tiin, yommuu n = 1 ta\'u: 2(1)^2 = 2. Kanaaf qoliin K elektiroonota 2 qofa baata. Qoliin L ammoo 8 baata.',
        explanationEn:
          'Option A is correct. For the first principal energy level (n=1), maximum capacity is 2(1)² = 2 electrons.',
      },
    ],
    examTip:
      'Herrega atamii (A = p + n, Z = p, e = p) shaakali; lakkoofsa niwutiroonotaa argachuuf A - Z gochuun akka danda\'amu yaadadhu.',
    examTipEn:
      'Master the basic arithmetic: Neutrons = Mass number (A) - Atomic number (Z). Expect a direct calculation problem on your exam.',
  },
];
