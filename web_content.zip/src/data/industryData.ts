import { PaintingReport, MaintenanceReport, ProcedureReport } from '../types/domain';

import imgSandblasting from '../assets/images/op_sandblasting_sa25_1792393509954.jpg';
import imgPaintingAirless from '../assets/images/op_liquid_coating_airless_1792393510989.jpg';
import imgMaintenance from '../assets/images/op_maintenance_check_1792391863808.jpg';
import imgSafety from '../assets/images/op_safety_inspection_1792391864369.jpg';
import imgProduction from '../assets/images/op_production_line_1792391863492.jpg';

export const INITIAL_PAINTING_REPORTS: PaintingReport[] = [
  {
    id: 'paint-rep-001',
    reportNumber: '2026/042/SFL',
    date: '2026-10-18',
    documentRev: 'MOD. RV-U Rev 0 del 12/04/2013',

    // Dati Identificativi
    client: 'Gruppo Meccanico Industriale S.p.A.',
    subSupplier: 'Sfiller Sabbiatura & Verniciatura S.r.l.',
    jobSerialNumber: 'COMM-8841 / Matr. 0492-2026',
    purchaseOrderNumber: 'PO-2026-9932 / Pos. 02',
    itemName: 'Struttura skid di supporto per impianto oil & gas - Travi HEB 400',

    // Preparazione Superficiale
    surfacePreparationStd: 'ISO 8501-3',
    abrasiveTypeMesh: 'Garnet 30/60 Mesh',
    abrasiveContaminants: 'Dry, clean and free from oil, grease and other contaminants',
    incisionProfile: 'MEDIUM G (55 µm)',
    blastCleaningGrade: 'S.A. 2 1/2',
    dustTestingGrade: 'Classe 1 (ISO 8502-3)',
    surfacePrepWeather: {
      date: '2026-10-18',
      airTemperature: 21.5,
      surfaceTemperature: 19.8,
      relativeHumidity: 48.0,
      dewPoint: 10.1,
      isDeltaOk: true,
      statusText: 'OK'
    },

    // Specifica e Ciclo
    paintingSpecification: 'SPEC-COATING-ISO12944-C5M',
    paintSystem: 'Ciclo Epossidico-Poliuretanico a 3 Strati ad Alto Solido',

    layers: [
      {
        id: 'layer-1',
        coatNumber: 1,
        coatType: '1 - PRIMER',
        requiredDftUm: 75,
        paintName: 'Jotun Barrier 80 (Zinc-Rich Epoxy)',
        batchCompA: 'LT-A-98124',
        batchCompB: 'LT-B-98125',
        color: 'Zinco Grigio Metallico',
        applicationMethod: 'AIRLESS',
        date: '2026-10-18',
        airTemp: 21.7,
        relativeHumidity: 46.0,
        surfaceTemp: 19.5,
        dewPoint: 9.6,
        dftMeasured: {
          min: 72,
          med: 78,
          max: 85
        },
        visualCheck: 'OK',
        dftCheck: 'OK',
        pullOffTest: 'N.A.'
      },
      {
        id: 'layer-2',
        coatNumber: 2,
        coatType: '2 - INTERMEDIATE',
        requiredDftUm: 150,
        paintName: 'Jotamastic 90 High Solids Epoxy',
        batchCompA: 'LT-A-11029',
        batchCompB: 'LT-B-11030',
        color: 'Grigio Finestrante RAL 7035',
        applicationMethod: 'AIRLESS',
        date: '2026-10-19',
        airTemp: 22.0,
        relativeHumidity: 45.0,
        surfaceTemp: 20.2,
        dewPoint: 9.5,
        dftMeasured: {
          min: 145,
          med: 158,
          max: 168
        },
        visualCheck: 'OK',
        dftCheck: 'OK',
        pullOffTest: 'N.A.'
      },
      {
        id: 'layer-3',
        coatNumber: 3,
        coatType: '4 - FINISH',
        requiredDftUm: 60,
        paintName: 'Hardtop AX Aliphatic Acrylic Polyurethane',
        batchCompA: 'LT-A-44321',
        batchCompB: 'LT-B-44322',
        color: 'Blu Traffico RAL 5017 Lucido',
        applicationMethod: 'AIRLESS',
        date: '2026-10-19',
        airTemp: 22.4,
        relativeHumidity: 44.0,
        surfaceTemp: 20.8,
        dewPoint: 9.6,
        dftMeasured: {
          min: 58,
          med: 64,
          max: 70
        },
        visualCheck: 'OK',
        dftCheck: 'OK',
        pullOffTest: '7.8 MPa (Coesiva - OK)'
      }
    ],

    instrumentNotes:
      'Spessimetro PosiTector 6000 - Matricola 762963 - Sonda FS 234341 - Scadenza Certificato: 29/08/2027\nTemperatura PosiTector DPM - Matricola 762963 - Sonda 240387 - Scadenza Certificato: 04/09/2027\nRugosimetro PosiTector SPG - Matricola 882190',
    generalRemarks:
      'Trattamento superficiale eseguito a regola d\'arte. Assenza di colature, crateri o inclusioni. Spessori conformi a specifica ISO 19840.',

    signoffs: {
      companyInspection: {
        name: 'M. Preato (Responsabile Tecnico Sabbiatura & Verniciatura)',
        date: '2026-10-19',
        signed: true
      },
      qualityControl: {
        name: 'D. Zampieri (Controllo Qualità NACE/FROSIO Level 2)',
        date: '2026-10-19',
        signed: true
      },
      inspectionAgency: {
        name: 'Ing. L. Ferrari (Ente Terzo Bureau Veritas)',
        date: '2026-10-19',
        signed: true
      },
      customerInspector: {
        name: 'Ing. R. Colombo (Ispettore Cliente)',
        date: '2026-10-19',
        signed: true
      }
    },

    images: [
      {
        id: 'pimg-001-1',
        url: imgSandblasting,
        caption: 'Profilo di incisione dopo sabbiatura abrasiva Garnet grado SA 2.5 su flangia e anima trave HEB',
        stage: 'Preparazione Superficiale SA 2.5',
        uploadedAt: '2026-10-18T10:45:00.000Z',
        fileName: 'sabbiatura_sa25_profilo.jpg'
      },
      {
        id: 'pimg-001-2',
        url: imgPaintingAirless,
        caption: 'Applicazione a spruzzo airless strato finitura poliuretanica RAL 5017 in cabina pressurizzata',
        stage: 'Finitura',
        uploadedAt: '2026-10-19T11:30:00.000Z',
        fileName: 'applicazione_airless_finitura.jpg'
      }
    ],

    createdAt: '2026-10-18T09:00:00.000Z',
    updatedAt: '2026-10-19T14:30:00.000Z'
  }
];

export const INITIAL_MAINTENANCE_REPORTS: MaintenanceReport[] = [
  {
    id: 'maint-001',
    protocolNumber: 'MAN-2026-0038',
    date: '2026-10-17',
    time: '14:30',
    plantName: 'LINEA 1',
    equipmentServiced: 'Pompa Airless Graco King Xtreme 68:1 & Pistola XTR-7',
    interventionType: 'Revisione Pompa Airless / Pistoni',
    outcome: 'positivo',
    timeSpentHours: 3,
    timeSpentMinutes: 15,
    description:
      'Rilevata perdita di pressione intermittente e trafilamento di resina epossidica dallo stelo inferiore del motore pneumatico. Smontato il gruppo pompante, pulito con solvente nitro, sostituiti i pacchi guarnizioni V-pack in teflon e verificata la tenuta delle sfere di aspirazione.',
    spareParts: [
      {
        id: 'sp-1',
        code: 'GRC-244851',
        description: 'Kit guarnizioni pompante V-Packing PTFE/Pelle Graco Xtreme',
        quantity: 1,
        unit: 'kit',
        notes: 'Sostituzione ordinaria usura 500 ore'
      },
      {
        id: 'sp-2',
        code: 'FLT-060M',
        description: 'Filtro a cartuccia inox 60 mesh per pistola airless XTR',
        quantity: 2,
        unit: 'pz',
        notes: 'Sostituiti per intasamento vernice densa'
      },
      {
        id: 'sp-3',
        code: 'LUB-TSL',
        description: 'Fluido protettivo per gola pistone TSL Graco',
        quantity: 0.5,
        unit: 'l',
        notes: 'Rabbocco vaschetta superiore'
      }
    ],
    operatorName: 'Gianni Moretti',
    supervisorName: 'M. Preato',
    images: [
      {
        id: 'mimg-1',
        url: imgMaintenance,
        caption: 'Verifica tenuta circuito pneumatico 7 bar e serraggio ghiera pompante',
        tag: 'Impianto Ripristinato',
        uploadedAt: '2026-10-17T17:00:00.000Z',
        fileName: 'manutenzione_pompa_airless.jpg'
      }
    ],
    createdAt: '2026-10-17T14:30:00.000Z',
    updatedAt: '2026-10-17T17:45:00.000Z'
  },
  {
    id: 'maint-002',
    protocolNumber: 'MAN-2026-0039',
    date: '2026-10-18',
    time: '08:00',
    plantName: 'LINEA 2',
    equipmentServiced: 'Cabina di Sabbiatura Manuale - Tubazione e Ugello Venturi',
    interventionType: 'Sostituzione Ugelli / Tubazioni',
    outcome: 'positivo',
    timeSpentHours: 1,
    timeSpentMinutes: 30,
    description:
      'Controllo usura calibro ugello di sabbiatura venturi. Rilevato allargamento foro da 8.0 mm a 9.6 mm con conseguente calo di resa abrasiva Garnet. Sostituito ugello venturi in carburo di boro e verificata la guarnizione del porta-ugello.',
    spareParts: [
      {
        id: 'sp-4',
        code: 'UG-BC-VENT-8',
        description: 'Ugello Venturi carburo di boro diam. 8.0 mm con camicia alluminio',
        quantity: 1,
        unit: 'pz',
        notes: 'Nuovo montato su tubo 1 1/4"'
      },
      {
        id: 'sp-5',
        code: 'GUA-P114',
        description: 'Guarnizione sagomata in gomma antiabrasiva per portaugello',
        quantity: 2,
        unit: 'pz',
        notes: 'Tenuta stagna perfetta'
      }
    ],
    operatorName: 'Luca De Angelis',
    supervisorName: 'M. Preato',
    images: [],
    createdAt: '2026-10-18T08:00:00.000Z',
    updatedAt: '2026-10-18T09:30:00.000Z'
  },
  {
    id: 'maint-003',
    protocolNumber: 'MAN-2026-0040',
    date: '2026-10-18',
    time: '16:00',
    plantName: 'POLIN',
    equipmentServiced: 'Forno di Essiccazione e Polimerizzazione POLIN - Bruciatore e Scambiatore Termico',
    interventionType: 'Sostituzione Filtri a Maniche / Cartucce',
    outcome: 'positivo',
    timeSpentHours: 2,
    timeSpentMinutes: 0,
    description:
      'Controllo differenziale di pressione manometro differenziale dP filtri. Eseguito ciclo di pulizia con scuotitore pneumatico temporizzato e scarico polveri nella tramoggia inferiore.',
    spareParts: [
      {
        id: 'sp-6',
        code: 'MAN-ANT-500',
        description: 'Maniche filtranti poliestere antistatico diam. 120 x 2000 mm',
        quantity: 4,
        unit: 'pz',
        notes: 'Sostituite maniche danneggiate da abrasivo'
      }
    ],
    operatorName: 'Gianni Moretti',
    supervisorName: 'M. Preato',
    images: [],
    createdAt: '2026-10-18T16:00:00.000Z',
    updatedAt: '2026-10-18T18:00:00.000Z'
  }
];

export const INITIAL_PROCEDURE_REPORTS: ProcedureReport[] = [
  {
    id: 'proc-001',
    code: 'SPEC-2026-004',
    title: 'Specifica di Lavoro: Ciclo Anticorrosivo C5-M su Travature Sabbiate SA 2.5',
    category: 'Specifica di Lavoro',
    plantLine: 'LINEA 2',
    client: 'Ansaldo Energia S.p.A.',
    jobOrder: 'COMM-2026-ANS-44',
    date: '2026-10-18',
    revision: 'Rev. 01',
    status: 'approvato',
    author: 'M. Preato (Resp. Tecnico Verniciatura)',
    approver: 'Ing. R. Bianchi (Quality Assurance)',
    scope:
      'Definizione operativa delle sequenze di sabbiatura a metallo quasi bianco, mascheratura fori/zone lavorate, applicazione primer zincante e ciclo epossidico-poliuretanico ad alte prestazioni per ambiente marino aggressivo ISO 12944 C5-M.',
    safetyNotes:
      'DPI obbligatori in cabina: scafandro ventilato ad adduzione continua per granigliatura, semimaschera con filtri combinati A2P3 per spruzzatura, tuta antistatica integrale, scarpe antinfortunistiche S3.',
    preferredLayout: 'report_and_run',
    steps: [
      {
        id: 'step-1',
        stepNumber: 1,
        title: 'Ispezione iniziale grezzo e sgrassaggio a solvente (SSPC-SP 1)',
        description:
          'Verifica visiva dello stato superficiale del manufatto in acciaio al carbonio. Eliminazione preliminare di oli, grassi di lavorazione meccanica e composti protettivi mediante tamponamento con panno imbevuto di diluente sintetico sgrassante.',
        checkpoints:
          'Assenza totale di residui oleosi (test di bagnabilità o panno bianco pulito conforme SSPC-SP 1).',
        compliance: 'conforme',
        images: [
          {
            id: 'p-img-1',
            photoNumber: 1,
            url: imgProduction,
            caption:
              'Didascalia 1: Ricevimento trave HEB grezza e controllo preliminare zone contaminate prima dell\'avvio del ciclo.',
            tag: 'Prima Lavorazione',
            uploadedAt: '2026-10-18T08:30:00.000Z'
          }
        ]
      },
      {
        id: 'step-2',
        stepNumber: 2,
        title: 'Sabbiatura a metallo quasi bianco grado ISO 8501-1 SA 2.5',
        description:
          'Abrasione a pressione con graniglia angolare Garnet 30/60 Mesh, pressione all\'ugello 7.2 bar con venturi in carburo di boro. Rimozione integrale di ruggine, calamina e corpi estranei fino a colorazione grigio chiaro metallica.',
        checkpoints:
          'Grado di pulizia SA 2.5 riscontrato. Rugosità superficiale d\'ancoraggio (Incision Profile) compresa tra 50 e 75 µm misurata con comparatore Rugotest n.3 Medium G.',
        compliance: 'conforme',
        images: [
          {
            id: 'p-img-2',
            photoNumber: 2,
            url: imgSandblasting,
            caption:
              'Didascalia 2: Dettaglio della rugosità angolare ottenuta dopo sabbiatura SA 2.5 con graniglia Garnet.',
            tag: 'Evidenza Conforme',
            uploadedAt: '2026-10-18T10:15:00.000Z'
          }
        ]
      },
      {
        id: 'step-3',
        stepNumber: 3,
        title: 'Applicazione a spruzzo Airless: Primer Epossidico Zinc-Rich (75 µm)',
        description:
          'Miscelazione bicomponente con agitatore pneumatico. Applicazione mediante pompa airless Graco Xtreme 68:1, ugello 517, pressione 170 bar. Verificare che la temperatura superficiale dell\'acciaio sia almeno +3°C al di sopra del punto di rugiada (Dew Point).',
        checkpoints:
          'Spessore secco DFT nominale: 75 µm. Spessore a umido WFT rilevato con pettine a denti: 115-130 µm.',
        compliance: 'conforme',
        images: [
          {
            id: 'p-img-3',
            photoNumber: 3,
            url: imgPaintingAirless,
            caption:
              'Didascalia 3: Stesura uniforme del primer epossidico ad alto solido con pistola airless in cabina pressurizzata.',
            tag: 'Durante Lavorazione',
            uploadedAt: '2026-10-18T13:40:00.000Z'
          }
        ]
      },
      {
        id: 'step-4',
        stepNumber: 4,
        title: 'Collaudo dimensionale DFT e Rilascio Certificato di Qualità',
        description:
          'Misurazione spessori a secco DFT eseguita su griglia di 15 punti mediante sonda digitale PosiTector 6000 calibrata su provino sabbiato. Verifica adesione a croce (Cross-Hatch) o Pull-Off su piastra testimone.',
        checkpoints:
          'DFT totale medio riscontrato: 82 µm (Requisito minimo: 75 µm, 100% conforme a norma SSPC-PA2). Assenza di colature, forature o blistering.',
        compliance: 'conforme',
        images: [
          {
            id: 'p-img-4',
            photoNumber: 4,
            url: imgSafety,
            caption:
              'Didascalia 4: Collaudo e ispezione finale con spessimetro certificato prima dell\'imballo e della spedizione.',
            tag: 'Collaudo Finale',
            uploadedAt: '2026-10-18T16:20:00.000Z'
          }
        ]
      }
    ],
    createdAt: '2026-10-18T08:00:00.000Z',
    updatedAt: '2026-10-18T16:30:00.000Z'
  },
  {
    id: 'proc-002',
    code: 'I.O.-VERN-02',
    title: 'Istruzione Operativa: Mascheratura e Sigillatura Flange e Filettature Lavorate',
    category: 'Istruzione Tecnica',
    plantLine: 'LINEA 1',
    client: 'Commessa Standard Carpenterie',
    jobOrder: 'GEN-2026-LINEA1',
    date: '2026-10-16',
    revision: 'Rev. 00',
    status: 'approvato',
    author: 'D. Rossi (Capoturno Reparto)',
    approver: 'M. Preato',
    scope:
      'Istruzione dettagliata per la corretta protezione delle zone rettificate, piani di tenuta flange, fori filettati e bussole prima della fase di sabbiatura e successiva verniciatura.',
    safetyNotes: 'Guanti anti-taglio livello C per manipolazione lamiere e nastri protettivi ad alta aderenza.',
    preferredLayout: 'grid_2col',
    steps: [
      {
        id: 'step-201',
        stepNumber: 1,
        title: 'Applicazione nastro adesivo in tela speciale anti-abrasione',
        description:
          'Copertura ermetica dei piani di tenuta flangiati con doppio strato di nastro telato Heavy Duty resistente all\'impatto della graniglia metallica. Nessuna grinza o bordo sollevato ammesso.',
        checkpoints: 'Bordo mascheratura perfettamente allineato al raggio di battuta.',
        compliance: 'conforme',
        images: [
          {
            id: 'p-img-201',
            photoNumber: 1,
            url: imgMaintenance,
            caption:
              'Didascalia 1: Posizionamento della mascheratura protettiva su flangia lavorata a macchina utensile.',
            tag: 'Prima Lavorazione',
            uploadedAt: '2026-10-16T09:10:00.000Z'
          }
        ]
      },
      {
        id: 'step-202',
        stepNumber: 2,
        title: 'Inserimento tappi conici in silicone ad alta temperatura su fori filettati',
        description:
          'Protezione dei fori filettati M8, M12 e M16 mediante inserimento di tappi siliconici calibrati. I tappi garantiscono tenuta stagna e prevengono infiltrazioni di primer.',
        checkpoints: 'Tappi inseriti a fondo corsa e verificate tutte le filettature a disegno.',
        compliance: 'conforme',
        images: [
          {
            id: 'p-img-202',
            photoNumber: 2,
            url: imgProduction,
            caption:
              'Didascalia 2: Verifica alloggiamento tappi siliconici e controllo assenza contaminanti interni.',
            tag: 'Evidenza Conforme',
            uploadedAt: '2026-10-16T10:00:00.000Z'
          }
        ]
      }
    ],
    createdAt: '2026-10-16T09:00:00.000Z',
    updatedAt: '2026-10-16T11:30:00.000Z'
  }
];

