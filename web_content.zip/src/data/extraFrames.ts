export interface GalleryFrame {
  id: string;
  title: string;
  subtitle: string;
  category: "Architecture & Heritage" | "Interior Atmosphere" | "Kitchen Signatures" | "Morning Nutrition" | "All-Day Toast";
  description: string;
  defaultImageUrl: string;
  aspectRatio: string;
  frameStyle: "portrait" | "landscape" | "wide";
  badge: string;
  notes: string;
}

export const EXTRA_GALLERY_FRAMES: GalleryFrame[] = [
  {
    id: "frame-storefront",
    title: "The Olive Arch & Heritage Facade",
    subtitle: "Estd. 2013 · Sea Rock Building, Daspalla Hills",
    category: "Architecture & Heritage",
    description: "The signature textured olive-green stucco archway, vintage black lantern sconces, and patterned threshold mosaic that welcome diners into our tranquil coastal oasis.",
    defaultImageUrl: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80",
    aspectRatio: "3/4",
    frameStyle: "portrait",
    badge: "Facade & Archway",
    notes: "Modeled after the real Kaloreez exterior storefront with Sea Rock signage and black lanterns.",
  },
  {
    id: "frame-neon-dining",
    title: "The Warm Neon Dining Hall",
    subtitle: "Ambient Cove Lighting & Cane Craft",
    category: "Interior Atmosphere",
    description: "Backlit cove illumination warming the textured walls, complemented by bespoke woven cane chairs, solid wood tables, and Mediterranean tile floors beneath the glowing Kaloreez neon sign.",
    defaultImageUrl: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1400&q=80",
    aspectRatio: "16/9",
    frameStyle: "wide",
    badge: "Main Dining Room",
    notes: "Modeled after the interior dining room with neon script, hanging greenery, and tiled floors.",
  },
  {
    id: "frame-truffle-pasta",
    title: "Creamy Wild Mushroom & Truffle Penne",
    subtitle: "Coarse Pepper & Chargrilled Sourdough",
    category: "Kitchen Signatures",
    description: "Slow-simmered wild forest mushroom reduction coating al-dente whole grain penne in a handcrafted speckled ceramic shallow bowl, paired with crisp grilled sourdough.",
    defaultImageUrl: "https://images.unsplash.com/photo-1621996346565-e3d5d6281699?auto=format&fit=crop&w=1200&q=80",
    aspectRatio: "4/3",
    frameStyle: "landscape",
    badge: "Kitchen Signature",
    notes: "Modeled after the rich wild mushroom penne in shallow stone dish with grilled toast.",
  },
  {
    id: "frame-granola-bowl",
    title: "The Wholesome Baker Bowl",
    subtitle: "Crunchy Granola, Pumpkin Seeds & Dark Cacao",
    category: "Morning Nutrition",
    description: "Rich chilled whole-nutrition yogurt base served in an artisanal rectangular ceramic baker, generously topped with toasted oat clusters, roasted pumpkin seeds, and a ribbon of pure dark cacao.",
    defaultImageUrl: "https://images.unsplash.com/photo-1511690656952-34342bb7c2f2?auto=format&fit=crop&w=1000&q=80",
    aspectRatio: "3/4",
    frameStyle: "portrait",
    badge: "Breakfast & Bowls",
    notes: "Modeled after the rectangular baker dish breakfast bowl with granola and chocolate swirl.",
  },
  {
    id: "frame-garden-toast",
    title: "Charred Broccoli & Carrot Sourdough",
    subtitle: "Artisanal Multigrain Sourdough Tartines",
    category: "All-Day Toast",
    description: "Thick rustic sourdough toasts piled high with wok-seared garden broccoli florets, sweet carrot slivers, and cracked pepper, plated with a signature touch of hospitality.",
    defaultImageUrl: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=1000&q=80",
    aspectRatio: "3/4",
    frameStyle: "portrait",
    badge: "Artisanal Toast",
    notes: "Modeled after the double open-faced multigrain toasts with sautéed broccoli and carrots.",
  },
];
