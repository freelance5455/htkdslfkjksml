import { Song, Artist, Album, Playlist, User } from '../types/music';

export const INITIAL_SONGS: Song[] = [
  {
    id: 'song-1',
    title: 'Midnight Horizon',
    artist: 'The Weeknd & Kavinsky',
    artistId: 'artist-1',
    album: 'Cybernetic Soul',
    albumId: 'album-1',
    albumArt: 'cybernetic',
    duration: '3:45',
    durationSec: 225,
    genre: 'English',
    releaseDate: '2026-01-14',
    playCount: 1482000,
    bpm: 118,
    synthPreset: 'synthwave',
    colorTheme: {
      from: '#7928ca',
      via: '#2b1055',
      to: '#ff0080',
      accent: '#a855f7'
    },
    downloadSizeMb: 8.6,
    isLiked: true,
    isDownloaded: true,
    lyrics: [
      { time: 0, text: '♪ (Atmospheric analog synth intro) ♪' },
      { time: 6, text: 'Driving down the empty highway after midnight' },
      { time: 13, text: 'Streetlights bleeding purple in the rear view' },
      { time: 20, text: 'I feel the rhythm of your heartbeat next to mine' },
      { time: 27, text: 'No destination, just the stars we pursue' },
      { time: 35, text: 'Lost in the electric glow of the city lights' },
      { time: 42, text: 'We found the frequency where souls collide' },
      { time: 50, text: 'Hold on tight to the midnight horizon' },
      { time: 58, text: 'Where the music never stops and dreams awaken' },
      { time: 67, text: 'Can you hear the echo in the distance calling?' },
      { time: 76, text: '♪ (Harmonic synth drop & bassline) ♪' },
      { time: 92, text: 'Never look back, the night is still ours' },
      { time: 104, text: 'Dancing on the edge under neon towers' },
      { time: 120, text: 'Hold on tight to the midnight horizon' }
    ]
  },
  {
    id: 'song-2',
    title: 'Tomake Chhuye Dilam',
    artist: 'Anupam Roy & Shreya Ghoshal',
    artistId: 'artist-2',
    album: 'Acoustic Bengal',
    albumId: 'album-2',
    albumArt: 'bengal',
    duration: '4:12',
    durationSec: 252,
    genre: 'Bengali',
    releaseDate: '2025-11-20',
    playCount: 924000,
    bpm: 82,
    synthPreset: 'bengali',
    colorTheme: {
      from: '#0ea5e9',
      via: '#1e1b4b',
      to: '#ec4899',
      accent: '#38bdf8'
    },
    downloadSizeMb: 9.8,
    isLiked: true,
    isDownloaded: true,
    lyrics: [
      { time: 0, text: '♪ (Acoustic guitar & soft sitar strumming) ♪' },
      { time: 8, text: 'Tomake chhuye dilam moner shohor theke' },
      { time: 17, text: 'Ek fota brishti jhoruk du chokh dheke' },
      { time: 26, text: 'Koto raat eka chhilam ei gaaner majhe' },
      { time: 36, text: 'Aj tumi aasho jeno notun raaje' },
      { time: 48, text: 'Moneri janala khule dilam aj tomay' },
      { time: 59, text: 'Amar shob shure shudhu tomar chhayay' },
      { time: 72, text: '♪ (Melodic flute interlude) ♪' },
      { time: 88, text: 'Bhalobasha thakuk chirokaal eivabe' },
      { time: 102, text: 'Je pothe amra hete choli nirbhebe' }
    ]
  },
  {
    id: 'song-3',
    title: 'Tum Hi Ho (2026 Acoustic Revamp)',
    artist: 'Arijit Singh',
    artistId: 'artist-3',
    album: 'Heartstrings Unplugged',
    albumId: 'album-3',
    albumArt: 'heartstrings',
    duration: '3:50',
    durationSec: 230,
    genre: 'Bollywood',
    releaseDate: '2026-02-10',
    playCount: 3820000,
    bpm: 78,
    synthPreset: 'acoustic',
    colorTheme: {
      from: '#e11d48',
      via: '#4c0519',
      to: '#9333ea',
      accent: '#fb7185'
    },
    downloadSizeMb: 8.9,
    isLiked: true,
    lyrics: [
      { time: 0, text: '♪ (Grand piano prelude with subtle strings) ♪' },
      { time: 7, text: 'Hum tere bin ab reh nahi sakte' },
      { time: 15, text: 'Tere bina kya wajood mera' },
      { time: 23, text: 'Tujhse juda agar ho jayenge' },
      { time: 31, text: 'Toh khud se hi ho jayenge juda' },
      { time: 40, text: 'Kyunki tum hi ho, ab tum hi ho' },
      { time: 48, text: 'Zindagi ab tum hi ho' },
      { time: 56, text: 'Chain bhi, mera dard bhi' },
      { time: 64, text: 'Meri aashiqui ab tum hi ho' },
      { time: 75, text: '♪ (Cello crescendo) ♪' },
      { time: 88, text: 'Tera mera rishta hai kaisa, ek pal door gawaara nahi' }
    ]
  },
  {
    id: 'song-4',
    title: 'Levitate Tonight',
    artist: 'Dua Lipa',
    artistId: 'artist-4',
    album: 'Future Nostalgia Nights',
    albumId: 'album-4',
    albumArt: 'nostalgia',
    duration: '3:22',
    durationSec: 202,
    genre: 'Party',
    releaseDate: '2026-01-28',
    playCount: 2410000,
    bpm: 124,
    synthPreset: 'dance',
    colorTheme: {
      from: '#d946ef',
      via: '#3b0764',
      to: '#3b82f6',
      accent: '#f472b6'
    },
    downloadSizeMb: 7.7,
    isLiked: true,
    lyrics: [
      { time: 0, text: '♪ (Upbeat funky bass groove & 4/4 kicks) ♪' },
      { time: 6, text: 'If you wanna run away with me, I know a galaxy' },
      { time: 12, text: 'And I can take you for a ride' },
      { time: 18, text: 'I had a premonition that we fell into a rhythm' },
      { time: 24, text: 'Where the music don\'t stop for life' },
      { time: 30, text: 'Glitter in the sky, glitter in our eyes' },
      { time: 37, text: 'Shining just the way we like' },
      { time: 43, text: 'You want me, I want you, baby' },
      { time: 49, text: 'My sugarboo, I\'m levitating' },
      { time: 58, text: '♪ (Sparkling dance chorus drop) ♪' },
      { time: 72, text: 'Dancing into the neon morning' }
    ]
  },
  {
    id: 'song-5',
    title: 'Raindrops on Park Street',
    artist: 'Kolkata Chill Ensemble',
    artistId: 'artist-5',
    album: 'Kolkata After Dark',
    albumId: 'album-5',
    albumArt: 'lofi_kolkata',
    duration: '2:55',
    durationSec: 175,
    genre: 'Lo-Fi',
    releaseDate: '2026-03-01',
    playCount: 654000,
    bpm: 72,
    synthPreset: 'lofi',
    colorTheme: {
      from: '#14b8a6',
      via: '#042f2e',
      to: '#6366f1',
      accent: '#2dd4bf'
    },
    downloadSizeMb: 6.8,
    isLiked: false,
    lyrics: [
      { time: 0, text: '♪ (Vinyl crackle & rain falling on tin roof) ♪' },
      { time: 10, text: 'Old colonial tram lights blinking yellow' },
      { time: 22, text: 'Coffee mug warming tired cold hands' },
      { time: 34, text: 'Notes scribbled in the margin of a diary' },
      { time: 48, text: 'Lo-Fi electric piano softly meandering' },
      { time: 65, text: 'Let the noise of the world drift away' },
      { time: 82, text: 'Just you and the rain on Park Street' }
    ]
  },
  {
    id: 'song-6',
    title: 'Pulse Velocity (140 BPM)',
    artist: 'Apex Kinetic',
    artistId: 'artist-6',
    album: 'High Voltage Workout',
    albumId: 'album-6',
    albumArt: 'workout',
    duration: '3:30',
    durationSec: 210,
    genre: 'Workout',
    releaseDate: '2026-02-18',
    playCount: 1120000,
    bpm: 140,
    synthPreset: 'dance',
    colorTheme: {
      from: '#f97316',
      via: '#431407',
      to: '#e11d48',
      accent: '#fb923c'
    },
    downloadSizeMb: 8.1,
    isLiked: true,
    lyrics: [
      { time: 0, text: '♪ (Heavy heart-thumping kick & rising arpeggio) ♪' },
      { time: 8, text: 'Push the threshold, break the barrier' },
      { time: 15, text: 'Every rep brings you closer to the peak' },
      { time: 22, text: 'Feel the adrenaline burning inside' },
      { time: 30, text: 'No hesitation, no backing down' },
      { time: 40, text: 'One, two, push through!' },
      { time: 52, text: '♪ (Massive energetic synth drop) ♪' },
      { time: 70, text: 'Unstoppable momentum!' }
    ]
  },
  {
    id: 'song-7',
    title: 'Bhalobashar Shuru',
    artist: 'Anupam Roy',
    artistId: 'artist-2',
    album: 'Acoustic Bengal',
    albumId: 'album-2',
    albumArt: 'bengal',
    duration: '3:38',
    durationSec: 218,
    genre: 'Bengali',
    releaseDate: '2026-02-04',
    playCount: 780000,
    bpm: 90,
    synthPreset: 'bengali',
    colorTheme: {
      from: '#8b5cf6',
      via: '#2e1065',
      to: '#06b6d4',
      accent: '#a78bfa'
    },
    downloadSizeMb: 8.2,
    lyrics: [
      { time: 0, text: '♪ (Warm acoustic fingerpicking) ♪' },
      { time: 9, text: 'Bristir dine chobi aaka joto gaan' },
      { time: 18, text: 'Tomar kothaye khuje paoa shur o taan' },
      { time: 28, text: 'Ei je shuru holo bhalobashar alo' },
      { time: 39, text: 'Kothao jeno mon bhalo thakar daak dilo' },
      { time: 50, text: '♪ (Violin harmony) ♪' },
      { time: 64, text: 'Poth hariye gechhe oi paharer baanke' }
    ]
  },
  {
    id: 'song-8',
    title: 'Deep Focus Protocol',
    artist: 'MindState Audio Labs',
    artistId: 'artist-7',
    album: 'Binaural Serenity',
    albumId: 'album-7',
    albumArt: 'focus',
    duration: '4:45',
    durationSec: 285,
    genre: 'Focus',
    releaseDate: '2026-01-05',
    playCount: 1530000,
    bpm: 60,
    synthPreset: 'ambient',
    colorTheme: {
      from: '#059669',
      via: '#022c22',
      to: '#0284c7',
      accent: '#34d399'
    },
    downloadSizeMb: 11.2,
    lyrics: [
      { time: 0, text: '♪ (432Hz ambient harmonic drone) ♪' },
      { time: 15, text: 'Clear your mind of all distractions' },
      { time: 40, text: 'Focus on your breath and code' },
      { time: 80, text: '♪ (Binaural pulse shifting into deep flow) ♪' },
      { time: 140, text: 'Effortless productivity and deep calm' }
    ]
  },
  {
    id: 'song-9',
    title: 'Kesariya Serenade',
    artist: 'Arijit Singh & Pritam',
    artistId: 'artist-3',
    album: 'Heartstrings Unplugged',
    albumId: 'album-3',
    albumArt: 'heartstrings',
    duration: '3:40',
    durationSec: 220,
    genre: 'Romantic',
    releaseDate: '2026-02-14',
    playCount: 4210000,
    bpm: 86,
    synthPreset: 'acoustic',
    colorTheme: {
      from: '#f59e0b',
      via: '#451a03',
      to: '#dc2626',
      accent: '#fbbf24'
    },
    downloadSizeMb: 8.5,
    isLiked: true,
    lyrics: [
      { time: 0, text: '♪ (Sufi guitar intro) ♪' },
      { time: 8, text: 'Kesariya tera ishq hai piya' },
      { time: 17, text: 'Rang jaaun jo main haath lagaun' },
      { time: 26, text: 'Din beete saara teri fikr mein' },
      { time: 35, text: 'Rain saari teri khair manaun' },
      { time: 46, text: 'Patjhad ke mausam mein bhi phool khile hain' },
      { time: 58, text: 'Hum dono jabse is jahaan mein mile hain' }
    ]
  },
  {
    id: 'song-10',
    title: 'Echoes in the Rain',
    artist: 'Luna Solaris',
    artistId: 'artist-8',
    album: 'Velvet Midnight',
    albumId: 'album-8',
    albumArt: 'sad_rain',
    duration: '3:55',
    durationSec: 235,
    genre: 'Sad',
    releaseDate: '2025-12-19',
    playCount: 890000,
    bpm: 68,
    synthPreset: 'ambient',
    colorTheme: {
      from: '#64748b',
      via: '#0f172a',
      to: '#475569',
      accent: '#94a3b8'
    },
    downloadSizeMb: 9.1,
    lyrics: [
      { time: 0, text: '♪ (Subtle melancholy piano & distant thunder) ♪' },
      { time: 10, text: 'All the promises washed onto the sidewalk' },
      { time: 22, text: 'Walking home through empty streets we used to know' },
      { time: 36, text: 'I still hold conversations with your shadow' },
      { time: 50, text: 'Wondering if time will heal this hollow ache' },
      { time: 68, text: 'Echoes in the rain... fading away' }
    ]
  },
  {
    id: 'song-11',
    title: 'Sunset Chillout',
    artist: 'The Island Duo',
    artistId: 'artist-9',
    album: 'Tropical Dreamscape',
    albumId: 'album-9',
    albumArt: 'chillout',
    duration: '3:15',
    durationSec: 195,
    genre: 'Chill',
    releaseDate: '2026-03-12',
    playCount: 1340000,
    bpm: 105,
    synthPreset: 'pop',
    colorTheme: {
      from: '#06b6d4',
      via: '#164e63',
      to: '#ec4899',
      accent: '#22d3ee'
    },
    downloadSizeMb: 7.5,
    lyrics: [
      { time: 0, text: '♪ (Breezy steel drums & warm marimba) ♪' },
      { time: 12, text: 'Golden sun sinking into turquoise waters' },
      { time: 24, text: 'Feel the ocean breeze whispering in your hair' },
      { time: 38, text: 'Leave all your worries behind on the shore' },
      { time: 52, text: 'Tonight is just for peace and starry skies' }
    ]
  },
  {
    id: 'song-12',
    title: 'Dholak Groove 2026',
    artist: 'Pritam & Badshah',
    artistId: 'artist-10',
    album: 'Desi Electrified',
    albumId: 'album-10',
    albumArt: 'bollywood_groove',
    duration: '3:05',
    durationSec: 185,
    genre: 'Bollywood',
    releaseDate: '2026-03-25',
    playCount: 2950000,
    bpm: 128,
    synthPreset: 'dance',
    colorTheme: {
      from: '#ec4899',
      via: '#500724',
      to: '#eab308',
      accent: '#f43f5e'
    },
    downloadSizeMb: 7.2,
    lyrics: [
      { time: 0, text: '♪ (Energetic dholak beats & synth horns) ♪' },
      { time: 8, text: 'Nachle nachle saare aaj raat' },
      { time: 16, text: 'Desi beat pe ghoome poori kainaat' },
      { time: 25, text: 'DJ drop the bass and let it roll' },
      { time: 36, text: 'Feel the music deep inside your soul!' }
    ]
  }
];

export const INITIAL_ARTISTS: Artist[] = [
  {
    id: 'artist-1',
    name: 'The Weeknd & Kavinsky',
    image: 'the_weeknd',
    bio: 'Pioneers of cinematic retro-futuristic dark electronic synthwave and global chart-toppers.',
    followers: '48.2M',
    monthlyListeners: '89.4M',
    genres: ['English', 'Synthwave', 'Electronic'],
    topSongIds: ['song-1'],
    colorTheme: { from: '#7928ca', to: '#ff0080', accent: '#a855f7' },
    verified: true
  },
  {
    id: 'artist-2',
    name: 'Anupam Roy',
    image: 'anupam_roy',
    bio: 'National Award-winning Indian singer, lyricist and composer celebrated for poetic acoustic Bengali melodies.',
    followers: '6.4M',
    monthlyListeners: '4.8M',
    genres: ['Bengali', 'Acoustic', 'Folk Pop'],
    topSongIds: ['song-2', 'song-7'],
    colorTheme: { from: '#0ea5e9', to: '#ec4899', accent: '#38bdf8' },
    verified: true
  },
  {
    id: 'artist-3',
    name: 'Arijit Singh',
    image: 'arijit_singh',
    bio: 'The undisputed voice of romantic India, acclaimed for soul-stirring melodies and unmatched vocal range.',
    followers: '98.5M',
    monthlyListeners: '74.2M',
    genres: ['Bollywood', 'Romantic', 'Acoustic'],
    topSongIds: ['song-3', 'song-9'],
    colorTheme: { from: '#e11d48', to: '#9333ea', accent: '#fb7185' },
    verified: true
  },
  {
    id: 'artist-4',
    name: 'Dua Lipa',
    image: 'dua_lipa',
    bio: 'Global pop superstar crafting infectious disco-pop anthems that dominate dancefloors worldwide.',
    followers: '76.1M',
    monthlyListeners: '68.9M',
    genres: ['Party', 'Pop', 'Dance'],
    topSongIds: ['song-4'],
    colorTheme: { from: '#d946ef', to: '#3b82f6', accent: '#f472b6' },
    verified: true
  },
  {
    id: 'artist-5',
    name: 'Shreya Ghoshal',
    image: 'shreya_ghoshal',
    bio: 'Legendary playback singer with crystalline vocals across Hindi, Bengali and multilingual masterpieces.',
    followers: '42.8M',
    monthlyListeners: '39.1M',
    genres: ['Bollywood', 'Bengali', 'Classical'],
    topSongIds: ['song-2'],
    colorTheme: { from: '#8b5cf6', to: '#ec4899', accent: '#c084fc' },
    verified: true
  },
  {
    id: 'artist-6',
    name: 'Apex Kinetic',
    image: 'apex_kinetic',
    bio: 'High-octane electronic production unit creating the ultimate high-cadence workout soundtracks.',
    followers: '3.2M',
    monthlyListeners: '5.1M',
    genres: ['Workout', 'Electronic', 'EDM'],
    topSongIds: ['song-6'],
    colorTheme: { from: '#f97316', to: '#e11d48', accent: '#fb923c' },
    verified: true
  }
];

export const INITIAL_ALBUMS: Album[] = [
  {
    id: 'album-1',
    title: 'Cybernetic Soul',
    artist: 'The Weeknd & Kavinsky',
    artistId: 'artist-1',
    cover: 'cybernetic',
    releaseDate: '2026-01-14',
    year: '2026',
    songIds: ['song-1'],
    colorTheme: { from: '#7928ca', to: '#ff0080', accent: '#a855f7' }
  },
  {
    id: 'album-2',
    title: 'Acoustic Bengal',
    artist: 'Anupam Roy & Shreya Ghoshal',
    artistId: 'artist-2',
    cover: 'bengal',
    releaseDate: '2025-11-20',
    year: '2025',
    songIds: ['song-2', 'song-7'],
    colorTheme: { from: '#0ea5e9', to: '#ec4899', accent: '#38bdf8' }
  },
  {
    id: 'album-3',
    title: 'Heartstrings Unplugged',
    artist: 'Arijit Singh',
    artistId: 'artist-3',
    cover: 'heartstrings',
    releaseDate: '2026-02-10',
    year: '2026',
    songIds: ['song-3', 'song-9'],
    colorTheme: { from: '#e11d48', to: '#9333ea', accent: '#fb7185' }
  },
  {
    id: 'album-4',
    title: 'Future Nostalgia Nights',
    artist: 'Dua Lipa',
    artistId: 'artist-4',
    cover: 'nostalgia',
    releaseDate: '2026-01-28',
    year: '2026',
    songIds: ['song-4'],
    colorTheme: { from: '#d946ef', to: '#3b82f6', accent: '#f472b6' }
  },
  {
    id: 'album-5',
    title: 'Kolkata After Dark',
    artist: 'Kolkata Chill Ensemble',
    artistId: 'artist-5',
    cover: 'lofi_kolkata',
    releaseDate: '2026-03-01',
    year: '2026',
    songIds: ['song-5'],
    colorTheme: { from: '#14b8a6', to: '#6366f1', accent: '#2dd4bf' }
  },
  {
    id: 'album-6',
    title: 'High Voltage Workout',
    artist: 'Apex Kinetic',
    artistId: 'artist-6',
    cover: 'workout',
    releaseDate: '2026-02-18',
    year: '2026',
    songIds: ['song-6'],
    colorTheme: { from: '#f97316', to: '#e11d48', accent: '#fb923c' }
  }
];

export const INITIAL_PLAYLISTS: Playlist[] = [
  {
    id: 'playlist-1',
    title: 'Midnight Driving Vibes',
    description: 'Neon synthesizers, midnight skylines, and endless highway momentum.',
    cover: 'playlist_midnight',
    creator: 'Music Express Editorial',
    songIds: ['song-1', 'song-4', 'song-11', 'song-6'],
    isPublic: true,
    createdAt: '2026-01-01',
    colorTheme: { from: '#7928ca', to: '#ff0080', accent: '#a855f7' }
  },
  {
    id: 'playlist-2',
    title: 'Bengali Acoustic Bliss',
    description: 'Soulful poetry, rainy Kolkata afternoons, and acoustic warmth.',
    cover: 'playlist_bengali',
    creator: 'Music Express Bengal',
    songIds: ['song-2', 'song-7', 'song-5'],
    isPublic: true,
    createdAt: '2026-01-10',
    colorTheme: { from: '#0ea5e9', to: '#ec4899', accent: '#38bdf8' }
  },
  {
    id: 'playlist-3',
    title: 'Bollywood Romance Rewind',
    description: 'Timeless love anthems by Arijit Singh, Pritam, and Shreya Ghoshal.',
    cover: 'playlist_bollywood',
    creator: 'Music Express India',
    songIds: ['song-3', 'song-9', 'song-12'],
    isPublic: true,
    createdAt: '2026-01-15',
    colorTheme: { from: '#e11d48', to: '#9333ea', accent: '#fb7185' }
  },
  {
    id: 'playlist-4',
    title: 'Workout Beast Mode 140BPM',
    description: 'High cadence adrenaline-pumping tracks to shatter your personal records.',
    cover: 'playlist_workout',
    creator: 'Fitness Lab',
    songIds: ['song-6', 'song-4', 'song-1', 'song-12'],
    isPublic: true,
    createdAt: '2026-02-01',
    colorTheme: { from: '#f97316', to: '#e11d48', accent: '#fb923c' }
  },
  {
    id: 'playlist-5',
    title: 'Deep Focus & Lo-Fi Coding',
    description: 'Binaural frequencies and soothing rain loops for peak uninterrupted flow.',
    cover: 'playlist_focus',
    creator: 'Dev Beats',
    songIds: ['song-8', 'song-5', 'song-10'],
    isPublic: true,
    createdAt: '2026-02-12',
    colorTheme: { from: '#059669', to: '#0284c7', accent: '#34d399' }
  },
  {
    id: 'playlist-6',
    title: 'Sahanur\'s Daily Mix',
    description: 'Personalized combination of your favorite genres, Bengali gems & global hits.',
    cover: 'playlist_sahanur',
    creator: 'Made For Sahanur',
    songIds: ['song-1', 'song-2', 'song-3', 'song-4', 'song-9'],
    isPublic: false,
    createdAt: '2026-03-01',
    colorTheme: { from: '#8b5cf6', to: '#ec4899', accent: '#c084fc' }
  }
];

export const INITIAL_USER: User = {
  id: 'user-sahanur',
  name: 'Sahanur Alam',
  email: 'sahanuralam781108@gmail.com',
  avatar: 'sahanur',
  stats: {
    playlists: 8,
    likedSongs: 7,
    following: 19,
    followers: 128
  },
  settings: {
    darkMode: true,
    audioQuality: 'Very High',
    downloadQuality: 'High',
    notifications: true,
    dataSaver: false,
    language: 'English',
    crossfadeSec: 4,
    equalizerPreset: 'Bass Boost'
  }
};

export const GENRE_CATEGORIES = [
  { id: 'Chill', label: 'Chill', color: 'from-teal-600 to-emerald-900', icon: 'Coffee' },
  { id: 'Romantic', label: 'Romantic', color: 'from-rose-600 to-pink-900', icon: 'Heart' },
  { id: 'Workout', label: 'Workout', color: 'from-orange-600 to-amber-900', icon: 'Flame' },
  { id: 'Party', label: 'Party', color: 'from-purple-600 to-pink-900', icon: 'Sparkles' },
  { id: 'Sad', label: 'Sad', color: 'from-slate-600 to-indigo-950', icon: 'CloudRain' },
  { id: 'Focus', label: 'Focus', color: 'from-cyan-600 to-blue-950', icon: 'Compass' },
  { id: 'Lo-Fi', label: 'Lo-Fi', color: 'from-violet-600 to-purple-950', icon: 'Radio' },
  { id: 'Bollywood', label: 'Bollywood', color: 'from-amber-600 to-rose-950', icon: 'Disc3' },
  { id: 'Bengali', label: 'Bengali', color: 'from-blue-600 to-indigo-900', icon: 'Music' },
  { id: 'English', label: 'English', color: 'from-fuchsia-600 to-purple-900', icon: 'Globe' }
] as const;
