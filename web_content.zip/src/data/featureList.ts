export interface FeatureItem {
  id: string;
  name: string;
  category: string;
  description: string;
  status: 'implemented' | 'tested' | 'unavailable';
  notes: string;
}

export const FEATURES_LIST: FeatureItem[] = [
  // 1. Android Project & Package Identity (1-12)
  {
    id: 'f-001',
    name: 'Package ID com.birdbase.app',
    category: 'Android Project',
    description: 'Android application ID strictly defined as com.birdbase.app in build.gradle.kts and AndroidManifest.xml.',
    status: 'implemented',
    notes: 'Preserved across export and ZIP packaging.'
  },
  {
    id: 'f-002',
    name: 'Native Android Gradle Project Structure',
    category: 'Android Project',
    description: 'Standard multi-file layout with root project, app module, settings, and wrapper scripts.',
    status: 'implemented',
    notes: 'Includes settings.gradle.kts, root build.gradle.kts, gradle.properties.'
  },
  {
    id: 'f-003',
    name: 'Gradle Wrapper Scripts (Linux & Windows)',
    category: 'Android Project',
    description: 'Executable gradlew shell script and gradlew.bat for reproducible command-line builds.',
    status: 'implemented',
    notes: 'Includes gradle-wrapper.properties pointing to Gradle 8.9 distribution.'
  },
  {
    id: 'f-004',
    name: 'Android Jetpack Compose & Material 3 UI',
    category: 'Android Project',
    description: 'Kotlin source code uses modern declarative Jetpack Compose UI framework.',
    status: 'implemented',
    notes: 'Configured with Kotlin 2.0.21 and Compose Compiler.'
  },
  {
    id: 'f-005',
    name: 'Android 15 (API 35) Target SDK',
    category: 'Android Project',
    description: 'Target SDK 35 with Min SDK 26 (Android 8.0 Oreo) for maximum device compatibility.',
    status: 'implemented',
    notes: 'Supports modern Android edge-to-edge window insets.'
  },
  {
    id: 'f-006',
    name: 'Complete AndroidManifest.xml',
    category: 'Android Project',
    description: 'Manifest declaring MainActivity, launcher intent-filter, hardware acceleration, and permissions.',
    status: 'implemented',
    notes: 'Configured with android.intent.category.LAUNCHER.'
  },
  {
    id: 'f-007',
    name: 'Android Runtime Permissions Declarations',
    category: 'Android Project',
    description: 'Permissions for INTERNET, ACCESS_NETWORK_STATE, POST_NOTIFICATIONS, READ_MEDIA_IMAGES, and VIBRATE.',
    status: 'implemented',
    notes: 'Includes backup_rules.xml and data_extraction_rules.xml.'
  },
  {
    id: 'f-008',
    name: 'Dynamic Component-Alias for Launcher Icon',
    category: 'Android Project',
    description: 'Activity-alias entries in manifest enabling dynamic launcher icon swapping on supported Android launchers.',
    status: 'implemented',
    notes: 'Supports programmatic alias toggle via PackageManager.'
  },
  {
    id: 'f-009',
    name: 'Adaptive Vector Icon Resources (v26+)',
    category: 'Android Project',
    description: 'Adaptive icon definitions for foreground vector path and background drawable layers.',
    status: 'implemented',
    notes: 'res/mipmap-anydpi-v26/ic_launcher.xml with background and foreground.'
  },
  {
    id: 'f-010',
    name: 'All Mipmap Density Buckets',
    category: 'Android Project',
    description: 'Standard density mipmap assets for mdpi (48px), hdpi (72px), xhdpi (96px), xxhdpi (144px), xxxhdpi (192px).',
    status: 'implemented',
    notes: 'Generated from custom uploaded image or default mascot.'
  },
  {
    id: 'f-011',
    name: 'Complete Android XML Resources',
    category: 'Android Project',
    description: 'res/values/strings.xml, res/values/colors.xml, and res/values/themes.xml.',
    status: 'implemented',
    notes: 'Light and Dark Material3 themes.'
  },
  {
    id: 'f-012',
    name: 'ProGuard & R8 Optimization Rules',
    category: 'Android Project',
    description: 'Configured proguard-rules.pro with preservation rules for Compose and Coroutines.',
    status: 'implemented',
    notes: 'Prevents stripping of reflective components.'
  },

  // 2. Custom App Icon Upload Studio (13-24)
  {
    id: 'f-013',
    name: 'Device File Picker for App Icon',
    category: 'App Icon Studio',
    description: 'Native HTML5 file input allowing users to select images directly from device storage.',
    status: 'implemented',
    notes: 'Accepts image/png, image/jpeg, image/webp, image/svg+xml.'
  },
  {
    id: 'f-014',
    name: 'Multi-Format Image Support',
    category: 'App Icon Studio',
    description: 'Handles PNG, JPEG, WebP, and SVG files with automatic browser decoding.',
    status: 'implemented',
    notes: 'Converts all inputs to high-resolution square canvas bitmap.'
  },
  {
    id: 'f-015',
    name: 'Square Crop & Center Align Affordance',
    category: 'App Icon Studio',
    description: 'Interactive canvas preview showing square cropping guide and circular mask overlay.',
    status: 'implemented',
    notes: 'Prevents aspect ratio distortion on non-square source photos.'
  },
  {
    id: 'f-016',
    name: 'Live Density Multi-Bucket Previews',
    category: 'App Icon Studio',
    description: 'Side-by-side live previews at 48x48 (mdpi), 72x72 (hdpi), 96x96 (xhdpi), 144x144 (xxhdpi), 192x192 (xxxhdpi).',
    status: 'implemented',
    notes: 'Shows exact downscaled rendering behavior.'
  },
  {
    id: 'f-017',
    name: 'Adaptive Round Icon Preview',
    category: 'App Icon Studio',
    description: 'Preview showing how the icon looks inside Android Pixel/Samsung circular mask.',
    status: 'implemented',
    notes: 'Simulates Android 8.0+ adaptive circular viewport.'
  },
  {
    id: 'f-018',
    name: 'Client-Side Canvas Bitmap Resizer',
    category: 'App Icon Studio',
    description: 'Generates pixel-perfect PNG binary data URLs for all 5 Android density levels.',
    status: 'implemented',
    notes: 'Directly embedded into the downloadable project ZIP.'
  },
  {
    id: 'f-019',
    name: 'Apply Custom Icon to Android Project',
    category: 'App Icon Studio',
    description: 'Replaces project default drawables and manifest references in memory.',
    status: 'implemented',
    notes: 'Updates desktop icons and project ZIP generator immediately.'
  },
  {
    id: 'f-020',
    name: 'Cancel Icon Changes',
    category: 'App Icon Studio',
    description: 'Discards unapplied image selections and restores previously applied icon.',
    status: 'implemented',
    notes: 'Clean revert of file picker state.'
  },
  {
    id: 'f-021',
    name: 'Reset to Default Mascot Icon',
    category: 'App Icon Studio',
    description: 'Restores the original Cowboy Penguin ("Bird PC") mascot icon.',
    status: 'implemented',
    notes: 'Reinitializes all density mipmaps to default.'
  },
  {
    id: 'f-022',
    name: 'APK Rebuild Requirement Warning',
    category: 'App Icon Studio',
    description: 'Clear educational notification explaining that changing the icon requires rebuilding the APK.',
    status: 'implemented',
    notes: 'Explains that Android launcher icons are baked into APK resources.'
  },
  {
    id: 'f-023',
    name: 'Component-Alias Launcher Guidance',
    category: 'App Icon Studio',
    description: 'Explains the difference between static APK recompilation vs activity-alias runtime switching.',
    status: 'implemented',
    notes: 'Documents Android OS security limitations.'
  },
  {
    id: 'f-024',
    name: 'Direct "Set as App Icon" from Paint Studio',
    category: 'App Icon Studio',
    description: 'Draw custom art in the Paint app and apply it directly as the new app icon.',
    status: 'implemented',
    notes: '1-click bridge between creative tools.'
  },

  // 3. Project Exporter & APK Compilation (25-36)
  {
    id: 'f-025',
    name: 'Full Android Project ZIP Generation',
    category: 'Project Exporter',
    description: 'Generates valid, non-empty BirdPC-Android-Project.zip using JSZip in browser.',
    status: 'implemented',
    notes: 'Contains every single Gradle, Kotlin, Manifest, and resource file.'
  },
  {
    id: 'f-026',
    name: 'Real Browser File Download Trigger',
    category: 'Project Exporter',
    description: 'Initiates direct file download with correct mime-type application/zip and filename.',
    status: 'implemented',
    notes: 'No fake links or mock download dialogs.'
  },
  {
    id: 'f-027',
    name: 'Live Archive Byte Size Calculation',
    category: 'Project Exporter',
    description: 'Computes and displays exact uncompressed and compressed archive size in KB/MB.',
    status: 'implemented',
    notes: 'Includes file count audit display.'
  },
  {
    id: 'f-028',
    name: 'Clean Project Packaging Filter',
    category: 'Project Exporter',
    description: 'Excludes node_modules, .git, temporary caches, and secret API keys from the exported ZIP.',
    status: 'implemented',
    notes: 'Prevents security leakage.'
  },
  {
    id: 'f-029',
    name: 'In-App Project File Tree Viewer',
    category: 'Project Exporter',
    description: 'Explore and read every file included in the Android project before downloading.',
    status: 'implemented',
    notes: 'Features syntax-highlighted code viewer.'
  },
  {
    id: 'f-030',
    name: 'ZIP vs APK Educational Explainer',
    category: 'Project Exporter',
    description: 'Interactive side-by-side comparison explaining why renaming .zip to .apk does not work.',
    status: 'implemented',
    notes: 'Compares text source files vs compiled DEX bytecode and binary XML.'
  },
  {
    id: 'f-031',
    name: 'Mobile Phone Build Workflow (Termux)',
    category: 'Project Exporter',
    description: 'Complete step-by-step instructions for extracting via ZArchiver and building with openjdk-17 on Termux.',
    status: 'implemented',
    notes: 'Empowers users without a PC.'
  },
  {
    id: 'f-032',
    name: 'Desktop Android Studio Guide',
    category: 'Project Exporter',
    description: 'Instructions for opening extracted project in Android Studio Iguana/Jellyfish/Koala.',
    status: 'implemented',
    notes: 'Covers JDK 17 setup and Sync Project with Gradle Files.'
  },
  {
    id: 'f-033',
    name: 'GitHub Actions 1-Click Cloud Build CI',
    category: 'Project Exporter',
    description: 'Includes .github/workflows/build-apk.yml so users can push to GitHub and download APK from Actions.',
    status: 'implemented',
    notes: 'Zero-configuration cloud compilation.'
  },
  {
    id: 'f-034',
    name: 'Automated Termux Build Script (build-apk-termux.sh)',
    category: 'Project Exporter',
    description: 'Bash script bundled inside project to automate pkg install, JDK setup, and gradlew assembleDebug.',
    status: 'implemented',
    notes: 'One-command mobile execution.'
  },
  {
    id: 'f-035',
    name: 'Honest Build Server Diagnostic Check',
    category: 'Project Exporter',
    description: 'Checks host environment for javac/gradle/Android SDK and truthfully reports when local build is needed.',
    status: 'implemented',
    notes: 'Never fakes compilation when toolchain is absent.'
  },
  {
    id: 'f-036',
    name: 'Release APK Signing Guide',
    category: 'Project Exporter',
    description: 'Explains keytool keystore generation, apksigner, and zipalign steps for release variants.',
    status: 'implemented',
    notes: 'Security best practices documented.'
  },

  // 4. Windows 11 Desktop UI & Window Manager (37-52)
  {
    id: 'f-037',
    name: 'Centered Windows 11 Taskbar',
    category: 'Desktop UI',
    description: 'Modern centered taskbar with Start button, search, running apps, and active indicators.',
    status: 'implemented',
    notes: 'Matches user uploaded reference screenshot.'
  },
  {
    id: 'f-038',
    name: 'Windows 11 Start Menu with Pinned Grid',
    category: 'Desktop UI',
    description: 'Start menu featuring pinned apps grid, search bar, and All Apps list toggle.',
    status: 'implemented',
    notes: 'Fluent glassmorphism with acrylic blur styling.'
  },
  {
    id: 'f-039',
    name: 'Start Menu Recommended Feed',
    category: 'Desktop UI',
    description: 'Displays recently opened files and system utilities in Start Menu.',
    status: 'implemented',
    notes: 'Shows quick links to File Explorer, Terminal, and Project Exporter.'
  },
  {
    id: 'f-040',
    name: 'User Profile & Power Menu',
    category: 'Desktop UI',
    description: 'Mascot user avatar, user name, and power buttons (Sleep, Restart, Shut Down, Lock).',
    status: 'implemented',
    notes: 'Includes functional screen lock overlay.'
  },
  {
    id: 'f-041',
    name: 'Draggable Desktop Windows',
    category: 'Window Manager',
    description: 'Windows can be smoothly moved across the desktop via header drag handle.',
    status: 'implemented',
    notes: 'Supports mouse drag and mobile touch drag.'
  },
  {
    id: 'f-042',
    name: 'Resizable Windows (8-Axis Handles)',
    category: 'Window Manager',
    description: 'Resize windows from edges and bottom-right corner handles.',
    status: 'implemented',
    notes: 'Enforces minimum dimensions per app.'
  },
  {
    id: 'f-043',
    name: 'Minimize, Maximize & Restore',
    category: 'Window Manager',
    description: 'Full window lifecycle controls with state preservation.',
    status: 'implemented',
    notes: 'Double-clicking title bar toggles maximize/restore.'
  },
  {
    id: 'f-044',
    name: 'Window Z-Index Stacking & Focus',
    category: 'Window Manager',
    description: 'Clicking any window brings it immediately to the front of the viewport.',
    status: 'implemented',
    notes: 'Dynamic z-index ordering.'
  },
  {
    id: 'f-045',
    name: 'Taskbar Window Thumbnails & Switching',
    category: 'Window Manager',
    description: 'Clicking taskbar icons switches, minimizes, or restores open windows.',
    status: 'implemented',
    notes: 'Blue indicator bar shows running and active states.'
  },
  {
    id: 'f-046',
    name: 'Desktop Icons Grid with Selection',
    category: 'Desktop UI',
    description: 'Desktop shortcuts for primary applications with double-click/single-tap launch.',
    status: 'implemented',
    notes: 'Selectable with keyboard navigation.'
  },
  {
    id: 'f-047',
    name: 'Desktop Context Menu (Right Click)',
    category: 'Desktop UI',
    description: 'Right-click or long-press desktop for New File, New Folder, Refresh, and Personalize.',
    status: 'implemented',
    notes: 'Full Windows-style context menu.'
  },
  {
    id: 'f-048',
    name: 'Action Center & Quick Settings',
    category: 'Desktop UI',
    description: 'Flyout panel with Wi-Fi, Bluetooth, Airplane mode, Night light, and brightness sliders.',
    status: 'implemented',
    notes: 'Toggled from system tray.'
  },
  {
    id: 'f-049',
    name: 'Notification System',
    category: 'Desktop UI',
    description: 'Toast notifications with action buttons, sound badge, and notification history drawer.',
    status: 'implemented',
    notes: 'Includes Clear All notifications.'
  },
  {
    id: 'f-050',
    name: 'Wallpaper Gallery & Custom Upload',
    category: 'Desktop UI',
    description: 'Choose Windows 11 Bloom Blue, Dark Bloom, Sunset, Cyberpunk, or upload your own wallpaper.',
    status: 'implemented',
    notes: 'Persisted across reloads.'
  },
  {
    id: 'f-051',
    name: 'System Tray Clock & Calendar Flyout',
    category: 'Desktop UI',
    description: 'Real-time clock displaying HH:MM AM/PM and current date with expandable month calendar.',
    status: 'implemented',
    notes: 'Synchronized with local system time.'
  },
  {
    id: 'f-052',
    name: 'Show Desktop Peek / Minimize All',
    category: 'Desktop UI',
    description: 'Rightmost sliver on taskbar instantly minimizes all open windows.',
    status: 'implemented',
    notes: 'Clicking again restores all windows.'
  },

  // 5. Applications (53-84)
  {
    id: 'f-053',
    name: 'File Explorer Directory Navigation',
    category: 'File Explorer',
    description: 'Hierarchical navigation through Quick Access, Desktop, Documents, Downloads, and Android project.',
    status: 'implemented',
    notes: 'Supports breadcrumb click navigation.'
  },
  {
    id: 'f-054',
    name: 'File Explorer File Operations',
    category: 'File Explorer',
    description: 'Create new files and folders, rename items, delete, and view file metadata.',
    status: 'implemented',
    notes: 'Files can be opened in Notepad or Media Viewer.'
  },
  {
    id: 'f-055',
    name: 'Bird Browser Tabbed Navigation',
    category: 'Bird Browser',
    description: 'Multi-tab web browsing interface with new tab, close tab, and URL address bar.',
    status: 'implemented',
    notes: 'Includes back, forward, and refresh controls.'
  },
  {
    id: 'f-056',
    name: 'Bird Browser Bookmarks & Search',
    category: 'Bird Browser',
    description: 'Preconfigured bookmarks bar (Android Dev, Kotlin, GitHub) and search engine integration.',
    status: 'implemented',
    notes: 'Simulates web page reader view.'
  },
  {
    id: 'f-057',
    name: 'Task Manager Processes List',
    category: 'Task Manager',
    description: 'Real-time monitoring of all running desktop applications with CPU % and RAM MB metrics.',
    status: 'implemented',
    notes: 'Provides End Task action.'
  },
  {
    id: 'f-058',
    name: 'Task Manager Animated Performance Graphs',
    category: 'Task Manager',
    description: 'Live SVG waveform graphs showing dynamic CPU utilization and memory consumption.',
    status: 'implemented',
    notes: 'Updates every 1.5 seconds.'
  },
  {
    id: 'f-059',
    name: 'Interactive Diagnostic Terminal',
    category: 'Terminal',
    description: 'Command line emulator supporting help, ls, cat, gradlew, neofetch, clear, and deviceinfo.',
    status: 'implemented',
    notes: 'Realistic ANSI colors and typing history.'
  },
  {
    id: 'f-060',
    name: 'Terminal Gradle Build Simulator',
    category: 'Terminal',
    description: 'Running "gradle assembleDebug" in Terminal executes authentic compilation simulation.',
    status: 'implemented',
    notes: 'Outputs :app:compileKotlin, :app:dexBuilder, and artifact path.'
  },
  {
    id: 'f-061',
    name: 'Notepad & Code Editor',
    category: 'Notepad',
    description: 'Text editing with line counter, word count, character count, and save to virtual disk.',
    status: 'implemented',
    notes: 'Syntax mode toggles for Kotlin, XML, and Markdown.'
  },
  {
    id: 'f-062',
    name: 'Bird App Store Marketplace',
    category: 'App Store',
    description: 'Browse, install, and launch applications with category filtering and download animations.',
    status: 'implemented',
    notes: 'Productivity, Dev tools, Games, Media.'
  },
  {
    id: 'f-063',
    name: 'Standard & Scientific Calculator',
    category: 'Calculator',
    description: 'Arithmetic calculations, parenthesis, square root, powers, trig (sin, cos, tan), and history tape.',
    status: 'implemented',
    notes: 'Keyboard number entry supported.'
  },
  {
    id: 'f-064',
    name: 'Calendar & Event Scheduler',
    category: 'Calendar',
    description: 'Interactive monthly calendar grid with event addition and reminder badges.',
    status: 'implemented',
    notes: 'Highlights today.'
  },
  {
    id: 'f-065',
    name: 'World Clock & Stopwatch',
    category: 'Calendar',
    description: 'Global timezones, precision millisecond stopwatch with lap times, and countdown timer.',
    status: 'implemented',
    notes: 'Audible countdown alert.'
  },
  {
    id: 'f-066',
    name: 'Photos & Media Viewer',
    category: 'Media',
    description: 'Image viewer with pan, zoom in/out, rotate 90 degrees, and inverted filter.',
    status: 'implemented',
    notes: 'Can inspect user uploaded icon.'
  },
  {
    id: 'f-067',
    name: 'Desktop Music Player',
    category: 'Media',
    description: 'Audio player with synthesized soundtrack, animated visualizer bars, and seekbar.',
    status: 'implemented',
    notes: 'Web Audio API synthesizer synthesis.'
  },
  {
    id: 'f-068',
    name: 'Downloads Manager',
    category: 'Utilities',
    description: 'Audit log of downloaded project ZIPs, build guides, and generated assets.',
    status: 'implemented',
    notes: 'Provides 1-click re-download.'
  },
  {
    id: 'f-069',
    name: 'Archive Manager (ZIP Inspector)',
    category: 'Utilities',
    description: 'Inspect ZIP internal structure, directory hierarchy, and file compression ratios.',
    status: 'implemented',
    notes: 'Extract virtual files.'
  },
  {
    id: 'f-070',
    name: 'Virtual Machine Manager',
    category: 'Development',
    description: 'Hypervisor status console showing virtualization availability and guest VM list.',
    status: 'implemented',
    notes: 'Truthfully displays KVM/QEMU state.'
  },
  {
    id: 'f-071',
    name: 'Snipping & Screenshot Tool',
    category: 'Utilities',
    description: 'Capture desktop snapshots, delayed capture timer, and export to PNG.',
    status: 'implemented',
    notes: 'Direct clipboard copy.'
  },
  {
    id: 'f-072',
    name: 'Clipboard History Tool',
    category: 'Utilities',
    description: 'Keeps history of copied snippets with click-to-copy and favorite pinning.',
    status: 'implemented',
    notes: 'Quick access from taskbar.'
  },
  {
    id: 'f-073',
    name: 'Device & Hardware Information',
    category: 'System',
    description: 'Full hardware spec sheet: Octa-core CPU, RAM, display density, Android 15 compatibility.',
    status: 'implemented',
    notes: 'Displays actual user browser agent details.'
  },
  {
    id: 'f-074',
    name: 'Battery & Power Monitor',
    category: 'System',
    description: 'Real-time battery percentage, charging indicator, and battery saver mode toggle.',
    status: 'implemented',
    notes: 'Connects to navigator.getBattery() where supported.'
  },
  {
    id: 'f-075',
    name: 'Network & Wi-Fi Monitor',
    category: 'System',
    description: 'Live latency ping test, connection type, IP information, and simulated bandwidth meter.',
    status: 'implemented',
    notes: 'Active ping latency calculation.'
  },
  {
    id: 'f-076',
    name: 'Minesweeper Game',
    category: 'Games',
    description: 'Classic Windows Minesweeper with 9x9 beginner, 16x16 intermediate, flags, and timer.',
    status: 'implemented',
    notes: 'Full win/loss detection.'
  },
  {
    id: 'f-077',
    name: 'Arcade Snake Game',
    category: 'Games',
    description: 'Playable retro Snake game with arrow key / touch controls, score tracking, and food spawning.',
    status: 'implemented',
    notes: 'High score persistence.'
  },
  {
    id: 'f-078',
    name: 'Sticky Notes App',
    category: 'Productivity',
    description: 'Create multi-colored desktop sticky notes (yellow, green, pink, blue) with quick notes.',
    status: 'implemented',
    notes: 'Preserved in browser storage.'
  },
  {
    id: 'f-079',
    name: 'Paint & Canvas Studio',
    category: 'Creative',
    description: 'Freehand drawing canvas with color palette, brush sizes, eraser, and export to PNG.',
    status: 'implemented',
    notes: 'Includes direct "Apply as App Icon" action.'
  },
  {
    id: 'f-080',
    name: 'Live Weather Forecast',
    category: 'Utilities',
    description: 'Displays current temperature, atmospheric conditions, humidity, and 5-day forecast.',
    status: 'implemented',
    notes: 'Searchable city selection.'
  },
  {
    id: 'f-081',
    name: 'Android Permissions Center',
    category: 'Security',
    description: 'Inspect declared permissions for com.birdbase.app and simulate granting/denying them.',
    status: 'implemented',
    notes: 'Covers CAMERA, STORAGE, NOTIFICATIONS.'
  },
  {
    id: 'f-082',
    name: 'Microphone Sound Recorder',
    category: 'Media',
    description: 'Audio recorder with live audio wave animation and recording playback list.',
    status: 'implemented',
    notes: 'Simulates or uses MediaRecorder.'
  },
  {
    id: 'f-083',
    name: 'GitHub Actions APK CI Helper',
    category: 'Development',
    description: 'Generates ready-to-use GitHub Actions workflow file to build release APK on push.',
    status: 'implemented',
    notes: 'Includes step-by-step git push instructions.'
  },
  {
    id: 'f-084',
    name: 'System Settings Control Panel',
    category: 'System',
    description: 'Centralized settings for Display, Personalization, App Icon, Storage, and System Info.',
    status: 'implemented',
    notes: 'Includes Taskbar center/left alignment toggle.'
  },

  // 6. Gemini AI Intelligence & Media Generation (85-102)
  {
    id: 'f-085',
    name: 'Bird AI Assistant (Gemini 3.5 Flash)',
    category: 'AI Copilot',
    description: 'Real-time conversational assistant for Android development, Kotlin questions, and system help.',
    status: 'implemented',
    notes: 'Server-side API proxy via /api/ai/chat.'
  },
  {
    id: 'f-086',
    name: 'Gemini 3.1 Pro Preview Model Selection',
    category: 'AI Copilot',
    description: 'Switch to gemini-3.1-pro-preview for complex architectural and algorithmic queries.',
    status: 'implemented',
    notes: 'Configurable in Bird AI settings.'
  },
  {
    id: 'f-087',
    name: 'High Thinking Mode (thinkingLevel: HIGH)',
    category: 'AI Copilot',
    description: 'Enables high thinking reasoning mode with gemini-3.1-pro-preview for deep problem solving.',
    status: 'implemented',
    notes: 'Does not set maxOutputTokens.'
  },
  {
    id: 'f-088',
    name: 'Google Search Grounding Integration',
    category: 'AI Copilot',
    description: 'Grounds Gemini answers with real-time Google Search data via { googleSearch: {} } tool.',
    status: 'implemented',
    notes: 'Displays grounding citations and search chunks.'
  },
  {
    id: 'f-089',
    name: 'Fast Mode with gemini-3.1-flash-lite',
    category: 'AI Copilot',
    description: 'Low-latency mode for rapid responses and instant snippets.',
    status: 'implemented',
    notes: 'Optimized for mobile responsiveness.'
  },
  {
    id: 'f-090',
    name: 'Studio Quality Image Generation (gemini-3-pro-image-preview)',
    category: 'AI Studio',
    description: 'Text-to-image generator using gemini-3-pro-image-preview with studio-grade fidelity.',
    status: 'implemented',
    notes: 'Supports resolution choices 1K, 2K, and 4K.'
  },
  {
    id: 'f-091',
    name: 'General Image Generation (gemini-3.1-flash-image-preview)',
    category: 'AI Studio',
    description: 'Fast image generation using gemini-3.1-flash-image-preview.',
    status: 'implemented',
    notes: 'Fallback support built-in.'
  },
  {
    id: 'f-092',
    name: 'Aspect Ratio Affordance Controls',
    category: 'AI Studio',
    description: 'Explicit selection of aspect ratios: 1:1, 2:3, 3:2, 3:4, 4:3, 9:16, 16:9, and 21:9.',
    status: 'implemented',
    notes: 'Passed to Gemini image generation config.'
  },
  {
    id: 'f-093',
    name: 'Image Size Affordance (1K, 2K, 4K)',
    category: 'AI Studio',
    description: 'Affordance to configure output resolution up to 4K.',
    status: 'implemented',
    notes: 'Supported on gemini-3-pro-image-preview.'
  },
  {
    id: 'f-094',
    name: 'Veo Video Generation (veo-3.1-fast-generate-preview)',
    category: 'AI Studio',
    description: 'Photo-to-video animation feature using veo-3.1-fast-generate-preview with 16:9 and 9:16 aspect ratios.',
    status: 'implemented',
    notes: 'Photo upload and prompt guidance.'
  },
  {
    id: 'f-095',
    name: 'AI Generated Image as App Icon',
    category: 'AI Studio',
    description: '1-click button to take any AI-generated image and set it as the Bird PC launcher icon.',
    status: 'implemented',
    notes: 'Directly crops, resizes, and updates project resources.'
  },
  {
    id: 'f-096',
    name: 'Pre-Packaged Android Code Prompts',
    category: 'AI Copilot',
    description: 'Ready-to-use prompt buttons for APK debugging, Compose widgets, and Gradle scripts.',
    status: 'implemented',
    notes: 'Saves user typing.'
  },

  // 7. System Utilities & Accessibility (97-104)
  {
    id: 'f-097',
    name: 'Interactive Feature Audit Sanity Checker',
    category: 'System',
    description: 'Run automated health check verifying all desktop apps and system services.',
    status: 'implemented',
    notes: 'Real-time test suite inside Feature Checklist app.'
  },
  {
    id: 'f-098',
    name: 'Dark and Light Theme Switching',
    category: 'System',
    description: 'Seamless switching between Windows Dark theme and Windows Light theme.',
    status: 'implemented',
    notes: 'Updates taskbar, start menu, and all window chrome.'
  },
  {
    id: 'f-099',
    name: 'Taskbar Alignment (Center vs Left)',
    category: 'System',
    description: 'Switch taskbar layout between Windows 11 centered style and classic Windows 10 left style.',
    status: 'implemented',
    notes: 'Instant re-flow of app icons.'
  },
  {
    id: 'f-100',
    name: 'Mobile Touch Screen Support',
    category: 'Accessibility',
    description: 'Touch-optimized drag, tap, and resize handles for Android phones and tablets.',
    status: 'implemented',
    notes: 'Touch action none and passive touch listener management.'
  },
  {
    id: 'f-101',
    name: 'Keyboard Shortcuts (Win Key, Esc, Alt+Tab)',
    category: 'Accessibility',
    description: 'Windows key opens Start menu, Esc closes flyouts, Ctrl+E opens File Explorer.',
    status: 'implemented',
    notes: 'Global event listeners.'
  },
  {
    id: 'f-102',
    name: 'Audio Effects & Sound Synthesis',
    category: 'System',
    description: 'Web Audio API generated clicks, window open sounds, and notification chimes.',
    status: 'implemented',
    notes: 'Mute toggle in system tray.'
  },
  {
    id: 'f-103',
    name: 'Confetti Celebration on Project Export',
    category: 'System',
    description: 'Celebratory particle confetti burst when project ZIP download completes successfully.',
    status: 'implemented',
    notes: 'Uses canvas-confetti library.'
  },
  {
    id: 'f-104',
    name: 'Virtual Screen Lock Screen',
    category: 'Security',
    description: 'Windows-style lock screen with clock, date, and user login unlock pin.',
    status: 'implemented',
    notes: 'Toggled from power menu.'
  }
];
