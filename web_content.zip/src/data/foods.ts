import { FoodItem } from '../types/game';

export const FOOD_ITEMS: FoodItem[] = [
  // VEGETABLES
  { id: 'v1', name: 'Fresh Broccoli', emoji: '🥦', groupId: 'vegetables', servingSize: '1/2 cup cooked', funFact: 'Contains more vitamin C per gram than a standard orange!' },
  { id: 'v2', name: 'Crisp Carrots', emoji: '🥕', groupId: 'vegetables', servingSize: '1 medium carrot', funFact: 'Loaded with beta-carotene for sharp night vision.' },
  { id: 'v3', name: 'Baby Spinach', emoji: '🥬', groupId: 'vegetables', servingSize: '1 cup raw leaves', funFact: 'Rich in folate and plant iron for teen growth.' },
  { id: 'v4', name: 'Sweet Potato', emoji: '🍠', groupId: 'vegetables', servingSize: '1 medium potato', funFact: 'A complex carbohydrate vegetable rich in antioxidant carotenoids.' },
  { id: 'v5', name: 'Bell Pepper', emoji: '🫑', groupId: 'vegetables', servingSize: '1/2 cup sliced', funFact: 'Red and yellow peppers have over 200% of daily Vitamin C.' },
  { id: 'v6', name: 'Chickpeas / Garbanzo', emoji: '🫘', groupId: 'vegetables', servingSize: '1/2 cup cooked', funFact: 'Counts as both a vegetable (fiber) and a protein (amino acids)!' },
  { id: 'v7', name: 'Crispy Cucumber', emoji: '🥒', groupId: 'vegetables', servingSize: '1 cup sliced', funFact: '95% water—great for skin hydration during sports.' },
  { id: 'v8', name: 'Green Peas', emoji: '🫛', groupId: 'vegetables', servingSize: '1/2 cup cooked', funFact: 'Delivers 4 grams of protein and 4 grams of fiber per scoop.' },

  // FRUITS
  { id: 'f1', name: 'Red Apple', emoji: '🍎', groupId: 'fruits', servingSize: '1 medium apple', funFact: 'Pectin fiber feeds good gut bacteria and keeps you full.' },
  { id: 'f2', name: 'Ripe Banana', emoji: '🍌', groupId: 'fruits', servingSize: '1 medium banana', funFact: 'Packed with potassium to prevent sports muscle cramps.' },
  { id: 'f3', name: 'Blueberries', emoji: '🫐', groupId: 'fruits', servingSize: '1 cup fresh', funFact: 'Anthocyanins boost memory recall before exams.' },
  { id: 'f4', name: 'Juicy Strawberries', emoji: '🍓', groupId: 'fruits', servingSize: '1 cup halved', funFact: 'Rich in polyphenols and vitamin C for radiant skin.' },
  { id: 'f5', name: 'Sweet Orange', emoji: '🍊', groupId: 'fruits', servingSize: '1 medium orange', funFact: 'Eating whole fruit gives 3g fiber that juice filters out.' },
  { id: 'f6', name: 'Watermelon Slice', emoji: '🍉', groupId: 'fruits', servingSize: '1 cup diced', funFact: 'Contains lycopene, which protects skin cells from UV light.' },
  { id: 'f7', name: 'Tropical Mango', emoji: '🥭', groupId: 'fruits', servingSize: '1/2 cup cubed', funFact: 'High in digestive enzymes and Vitamin A for clear eyes.' },
  { id: 'f8', name: 'Kiwi Fruit', emoji: '🥝', groupId: 'fruits', servingSize: '2 small kiwis', funFact: 'Two kiwis pack more Vitamin C than three oranges combined!' },

  // GRAINS
  { id: 'g1', name: 'Rolled Oats', emoji: '🥣', groupId: 'grains', servingSize: '1/2 cup cooked', funFact: 'Beta-glucan fiber keeps morning hunger away for 4 hours.' },
  { id: 'g2', name: 'Brown Rice', emoji: '🍚', groupId: 'grains', servingSize: '1/2 cup cooked', funFact: 'Retains the outer bran layer with magnesium and B-vitamins.' },
  { id: 'g3', name: 'Whole Wheat Bread', emoji: '🍞', groupId: 'grains', servingSize: '1 slice', funFact: 'Provides complex carbs that fuel brain cells steadily.' },
  { id: 'g4', name: 'Quinoa Grain', emoji: '🌾', groupId: 'grains', servingSize: '1/2 cup cooked', funFact: 'Contains all 9 essential amino acids—a complete protein grain!' },
  { id: 'g5', name: 'Air-Popped Popcorn', emoji: '🍿', groupId: 'grains', servingSize: '3 cups popped', funFact: 'Popcorn is 100% whole grain with natural antioxidant ferulic acid.' },
  { id: 'g6', name: 'Whole Grain Pasta', emoji: '🍝', groupId: 'grains', servingSize: '1/2 cup cooked', funFact: 'Slow-burning carbs for pre-tournament sports loading.' },
  { id: 'g7', name: 'Whole Grain Tortilla', emoji: '🫓', groupId: 'grains', servingSize: '1 medium wrap', funFact: 'High in zinc and thiamine to convert food into energy.' },

  // PROTEINS
  { id: 'p1', name: 'Free-Range Eggs', emoji: '🍳', groupId: 'protein', servingSize: '2 large eggs', funFact: 'Gold standard biological protein value with memory-boosting choline.' },
  { id: 'p2', name: 'Grilled Chicken Breast', emoji: '🍗', groupId: 'protein', servingSize: '80g cooked', funFact: 'Dense lean protein with minimal saturated fat for muscle building.' },
  { id: 'p3', name: 'Salmon Fillet', emoji: '🐟', groupId: 'protein', servingSize: '100g cooked', funFact: 'High in Omega-3 fatty acids that elevate focus and reduce inflammation.' },
  { id: 'p4', name: 'Firm Tofu', emoji: '🌱', groupId: 'protein', servingSize: '170g cubed', funFact: 'Complete plant protein loaded with calcium and iron.' },
  { id: 'p5', name: 'Roasted Almonds', emoji: '🥜', groupId: 'protein', servingSize: '30g (handful)', funFact: 'Provides Vitamin E for glowing skin and healthy brain membranes.' },
  { id: 'p6', name: 'Pumpkin Seeds', emoji: '🌰', groupId: 'protein', servingSize: '30g', funFact: 'Packed with zinc, which supports teen immune function and acne recovery.' },
  { id: 'p7', name: 'Canned Light Tuna', emoji: '🥫', groupId: 'protein', servingSize: '1 small can (95g)', funFact: '25g of pure muscle-repair protein with zero sugar.' },

  // DAIRY & FORTIFIED ALTERNATIVES
  { id: 'd1', name: 'Fresh Milk', emoji: '🥛', groupId: 'dairy', servingSize: '1 cup (250ml)', funFact: 'Provides 300mg of bioavailable calcium for peak teen bone mass.' },
  { id: 'd2', name: 'Greek Yogurt', emoji: '🥣', groupId: 'dairy', servingSize: '3/4 cup (200g)', funFact: 'Strained to deliver 15-20g protein + gut-friendly live probiotics.' },
  { id: 'd3', name: 'Cheddar Cheese', emoji: '🧀', groupId: 'dairy', servingSize: '2 slices (40g)', funFact: 'High in calcium and phosphorus to remineralize tooth enamel.' },
  { id: 'd4', name: 'Fortified Soy Milk', emoji: '🧃', groupId: 'dairy', servingSize: '1 cup (250ml)', funFact: 'Fortified with calcium & Vit D to match dairy milk exactly.' },
  { id: 'd5', name: 'Cottage Cheese', emoji: '🍨', groupId: 'dairy', servingSize: '1/2 cup', funFact: 'Rich in slow-digesting casein protein—ideal bedtime snack.' },
  { id: 'd6', name: 'Kefir Probiotic Drink', emoji: '🍶', groupId: 'dairy', servingSize: '1 cup', funFact: 'Contains over 12 strains of live beneficial bacteria for digestion.' },
];
