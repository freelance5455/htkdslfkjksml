export interface SectAchievement {
  id: string;
  category: 'Cultivation' | 'Mentorship' | 'Treasury' | 'Pavilions' | 'Tournament' | 'Diplomacy';
  title: string;
  description: string;
  rewardText: string;
  meritReward: number;
}

export const SECT_ACHIEVEMENTS: SectAchievement[] = [
  // 1-10: Cultivation Milestones
  { id: 'ach_1', category: 'Cultivation', title: 'Qi Condensation Pioneer', description: 'Cultivate a disciple to Qi Condensation Layer 3.', rewardText: '+50 Merit', meritReward: 50 },
  { id: 'ach_2', category: 'Cultivation', title: 'Great Circle of Qi', description: 'Cultivate a disciple to Qi Condensation Layer 9.', rewardText: '+150 Merit', meritReward: 150 },
  { id: 'ach_3', category: 'Cultivation', title: 'Foundation Pillar', description: 'Breakthrough a disciple to Foundation Establishment.', rewardText: '+300 Merit', meritReward: 300 },
  { id: 'ach_4', category: 'Cultivation', title: 'Flawless Foundation', description: 'Reach Foundation Establishment Peak.', rewardText: '+600 Merit', meritReward: 600 },
  { id: 'ach_5', category: 'Cultivation', title: 'Golden Core Congealment', description: 'Congeal a Golden Core and survive lightning tribulation.', rewardText: '+1,200 Merit', meritReward: 1200 },
  { id: 'ach_6', category: 'Cultivation', title: 'Grade 1 Divine Core', description: 'Reach Golden Core Peak Stage.', rewardText: '+2,500 Merit', meritReward: 2500 },
  { id: 'ach_7', category: 'Cultivation', title: 'Nascent Soul Manifestation', description: 'Awaken the Nascent Soul avatar.', rewardText: '+5,000 Merit', meritReward: 5000 },
  { id: 'ach_8', category: 'Cultivation', title: 'Domain of Souls', description: 'Reach Nascent Soul Great Circle.', rewardText: '+10,000 Merit', meritReward: 10000 },
  { id: 'ach_9', category: 'Cultivation', title: 'Heavenly Deity', description: 'Ascend to Soul Formation realm.', rewardText: '+25,000 Merit', meritReward: 25000 },
  { id: 'ach_10', category: 'Cultivation', title: 'Mahayana Sovereign', description: 'Attain the Supreme Mahayana Immortal realm.', rewardText: '+100,000 Merit', meritReward: 100000 },

  // 11-20: Mentorship & Population
  { id: 'ach_11', category: 'Mentorship', title: 'First Disciples', description: 'Maintain 2 disciples in the sect.', rewardText: '+30 Merit', meritReward: 30 },
  { id: 'ach_12', category: 'Mentorship', title: 'Thriving Courtyard', description: 'Nurture 5 disciples at the mountain gate.', rewardText: '+100 Merit', meritReward: 100 },
  { id: 'ach_13', category: 'Mentorship', title: 'Mountain of Immortals', description: 'Reach the beginner cap of 10 disciples.', rewardText: '+250 Merit', meritReward: 250 },
  { id: 'ach_14', category: 'Mentorship', title: 'Expanded Sanctuary', description: 'Expand sect capacity to 15 or more disciples.', rewardText: '+500 Merit', meritReward: 500 },
  { id: 'ach_15', category: 'Mentorship', title: 'Inner Circle', description: 'Promote an eligible disciple to Inner Disciple rank.', rewardText: '+150 Merit', meritReward: 150 },
  { id: 'ach_16', category: 'Mentorship', title: 'Core Lineage', description: 'Promote an eligible disciple to Direct Disciple rank.', rewardText: '+350 Merit', meritReward: 350 },
  { id: 'ach_17', category: 'Mentorship', title: 'Elder Council', description: 'Appoint an Elder based on merit and realm.', rewardText: '+800 Merit', meritReward: 800 },
  { id: 'ach_18', category: 'Mentorship', title: 'Grand Elder Pillar', description: 'Appoint a Grand Elder to lead sect affairs.', rewardText: '+2,000 Merit', meritReward: 2000 },
  { id: 'ach_19', category: 'Mentorship', title: 'Sovereign Succession', description: 'Unlock and appoint a supreme Sect Leader.', rewardText: '+5,000 Merit', meritReward: 5000 },
  { id: 'ach_20', category: 'Mentorship', title: 'Daoist Companions', description: 'Forge a Lover or Soul Confidant bond between disciples.', rewardText: '+200 Merit', meritReward: 200 },

  // 21-28: Treasury & Economy
  { id: 'ach_21', category: 'Treasury', title: 'First Spirit Stones', description: 'Gather 1,000 Spirit Stones in the sect treasury.', rewardText: '+50 Merit', meritReward: 50 },
  { id: 'ach_22', category: 'Treasury', title: 'Wealth of the Vein', description: 'Accumulate 10,000 Spirit Stones.', rewardText: '+200 Merit', meritReward: 200 },
  { id: 'ach_23', category: 'Treasury', title: 'Golden Treasury', description: 'Accumulate 100,000 Spirit Stones.', rewardText: '+600 Merit', meritReward: 600 },
  { id: 'ach_24', category: 'Treasury', title: 'Millionaire Daoist', description: 'Accumulate 1,000,000 Spirit Stones.', rewardText: '+2,000 Merit', meritReward: 2000 },
  { id: 'ach_25', category: 'Treasury', title: 'Pure Spirit Springs', description: 'Gather 1,000 pure sect Qi.', rewardText: '+50 Merit', meritReward: 50 },
  { id: 'ach_26', category: 'Treasury', title: 'Ocean of Qi', description: 'Gather 50,000 pure sect Qi.', rewardText: '+500 Merit', meritReward: 500 },
  { id: 'ach_27', category: 'Treasury', title: 'Pill Cauldron', description: 'Store 50 or more pills in the treasury.', rewardText: '+150 Merit', meritReward: 150 },
  { id: 'ach_28', category: 'Treasury', title: 'Renowned Reputation', description: 'Accumulate 1,000 Sect Merit (Reputation).', rewardText: '+300 Merit', meritReward: 300 },

  // 29-36: Pavilions & Architecture
  { id: 'ach_29', category: 'Pavilions', title: 'Master Carpenter', description: 'Upgrade Grand Dao Hall to Level 2.', rewardText: '+50 Merit', meritReward: 50 },
  { id: 'ach_30', category: 'Pavilions', title: 'Daoist Stronghold', description: 'Upgrade Grand Dao Hall to Level 5.', rewardText: '+300 Merit', meritReward: 300 },
  { id: 'ach_31', category: 'Pavilions', title: 'Grand Sanctuary', description: 'Upgrade Grand Dao Hall to Level 10.', rewardText: '+1,000 Merit', meritReward: 1000 },
  { id: 'ach_32', category: 'Pavilions', title: 'Alchemical Mastery', description: 'Upgrade Eight Trigrams Alchemy Pavilion to Level 3.', rewardText: '+200 Merit', meritReward: 200 },
  { id: 'ach_33', category: 'Pavilions', title: 'Scripture Repository', description: 'Upgrade Scripture Pavilion to Level 3.', rewardText: '+200 Merit', meritReward: 200 },
  { id: 'ach_34', category: 'Pavilions', title: 'Beast & Herb Haven', description: 'Unlock Beast Taming & Herb Conservatory.', rewardText: '+400 Merit', meritReward: 400 },
  { id: 'ach_35', category: 'Pavilions', title: 'Sacred Forge', description: 'Unlock Nine Cauldrons Weapon Forge.', rewardText: '+600 Merit', meritReward: 600 },
  { id: 'ach_36', category: 'Pavilions', title: 'Harmonious Synergy', description: 'Assign staff with 90%+ compatibility to a building.', rewardText: '+150 Merit', meritReward: 150 },

  // 37-44: Peak Challenge & Martial Glory
  { id: 'ach_37', category: 'Tournament', title: 'Arena Initiate', description: 'Participate in your first Peak Challenge tournament.', rewardText: '+100 Merit', meritReward: 100 },
  { id: 'ach_38', category: 'Tournament', title: 'Promotion Victor', description: 'Win the Inner Promotion Tournament.', rewardText: '+300 Merit', meritReward: 300 },
  { id: 'ach_39', category: 'Tournament', title: 'Elder Challenger', description: 'Win a challenge against a Sect Elder.', rewardText: '+800 Merit', meritReward: 800 },
  { id: 'ach_40', category: 'Tournament', title: 'Leader Contender', description: 'Engage in a Sect Leader challenge.', rewardText: '+1,500 Merit', meritReward: 1500 },
  { id: 'ach_41', category: 'Tournament', title: 'Universal Gladiator', description: 'Compete in the All-Sects Universal Tournament.', rewardText: '+500 Merit', meritReward: 500 },
  { id: 'ach_42', category: 'Tournament', title: 'Crown of Champion I', description: 'Earn the Champion I Sect title for a disciple.', rewardText: '+1,000 Merit', meritReward: 1000 },
  { id: 'ach_43', category: 'Tournament', title: 'Crown of Champion II', description: 'Earn the Champion II Grand title for a disciple.', rewardText: '+2,500 Merit', meritReward: 2500 },
  { id: 'ach_44', category: 'Tournament', title: 'Sovereign Champion S', description: 'Conquer all sects and earn the supreme Champion S title.', rewardText: '+10,000 Merit', meritReward: 10000 },

  // 45-50: Daoist Alignments, Equipment & Diplomacy
  { id: 'ach_45', category: 'Diplomacy', title: 'Path Consecration', description: 'Consecrate your Sect permanent Alignment path.', rewardText: '+300 Merit', meritReward: 300 },
  { id: 'ach_46', category: 'Diplomacy', title: 'Armored Cultivator', description: 'Equip all 4 equipment slots on any disciple.', rewardText: '+150 Merit', meritReward: 150 },
  { id: 'ach_47', category: 'Diplomacy', title: 'Divine Relic', description: 'Equip an Earth or Heaven-tier weapon or artifact.', rewardText: '+800 Merit', meritReward: 800 },
  { id: 'ach_48', category: 'Diplomacy', title: 'Sacred Alliance', description: 'Form an alliance with a neighboring sect.', rewardText: '+600 Merit', meritReward: 600 },
  { id: 'ach_49', category: 'Diplomacy', title: 'Mountain Gate Defense', description: 'Successfully repel a foreign sect invasion.', rewardText: '+1,000 Merit', meritReward: 1000 },
  { id: 'ach_50', category: 'Diplomacy', title: 'Immortal Hegemony', description: 'Attain Steady or Flourishing sect stability.', rewardText: '+2,000 Merit', meritReward: 2000 }
];
