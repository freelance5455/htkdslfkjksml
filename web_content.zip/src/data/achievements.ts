export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  coinReward: number;
}

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_connect',
    title: 'First Spark',
    description: 'Complete your first matching color connection.',
    icon: '⚡',
    coinReward: 50
  },
  {
    id: 'level_5_clear',
    title: 'Neon Initiate',
    description: 'Complete the first 5 beginner levels.',
    icon: '🌟',
    coinReward: 100
  },
  {
    id: 'world_1_master',
    title: 'Neon Dawn Conqueror',
    description: 'Complete World 1 (Levels 1–10) with 3 stars on every stage.',
    icon: '👑',
    coinReward: 250
  },
  {
    id: 'combo_x3',
    title: 'Harmonic Flow',
    description: 'Trigger a 3x or higher combo multiplier in one level.',
    icon: '🔥',
    coinReward: 150
  },
  {
    id: 'speed_demon',
    title: 'Speed Demon',
    description: 'Solve a level with more than 5 remaining moves to spare.',
    icon: '⏱️',
    coinReward: 120
  },
  {
    id: 'daily_pioneer',
    title: 'Daily Pioneer',
    description: 'Complete your first Daily Challenge puzzle.',
    icon: '📅',
    coinReward: 150
  },
  {
    id: 'daily_streak_3',
    title: 'Dedicated Connector',
    description: 'Maintain a 3-day Daily Challenge completion streak.',
    icon: '🏆',
    coinReward: 300
  },
  {
    id: 'endless_stage_10',
    title: 'Infinite Spectrum',
    description: 'Reach Stage 10 in Endless Mode.',
    icon: '🌀',
    coinReward: 200
  },
  {
    id: 'color_customizer',
    title: 'Aesthetic Luminary',
    description: 'Unlock and equip a custom neon theme from the Shop.',
    icon: '🎨',
    coinReward: 100
  }
];
