import { DailySchedule } from '../types/prayer';

/**
 * Bangladesh Standard Time (UTC+06:00) prayer timetable for October 2026.
 * As officially specified for Dhaka and surrounding regions.
 */
export const OCTOBER_2026_TIMETABLE: DailySchedule[] = [
  { date: '2026-10-01', day: 1, month: 10, year: 2026, fajr: '04:35', sunrise: '05:50', dhuhr: '11:48', asr: '15:13', maghrib: '17:46', isha: '19:01' },
  { date: '2026-10-02', day: 2, month: 10, year: 2026, fajr: '04:35', sunrise: '05:50', dhuhr: '11:48', asr: '15:12', maghrib: '17:45', isha: '19:00' },
  { date: '2026-10-03', day: 3, month: 10, year: 2026, fajr: '04:36', sunrise: '05:51', dhuhr: '11:47', asr: '15:12', maghrib: '17:44', isha: '18:59' },
  { date: '2026-10-04', day: 4, month: 10, year: 2026, fajr: '04:36', sunrise: '05:51', dhuhr: '11:47', asr: '15:11', maghrib: '17:43', isha: '18:58' },
  { date: '2026-10-05', day: 5, month: 10, year: 2026, fajr: '04:36', sunrise: '05:51', dhuhr: '11:47', asr: '15:10', maghrib: '17:42', isha: '18:57' },
  { date: '2026-10-06', day: 6, month: 10, year: 2026, fajr: '04:37', sunrise: '05:52', dhuhr: '11:47', asr: '15:10', maghrib: '17:41', isha: '18:56' },
  { date: '2026-10-07', day: 7, month: 10, year: 2026, fajr: '04:37', sunrise: '05:52', dhuhr: '11:46', asr: '15:09', maghrib: '17:40', isha: '18:55' },
  { date: '2026-10-08', day: 8, month: 10, year: 2026, fajr: '04:38', sunrise: '05:53', dhuhr: '11:46', asr: '15:09', maghrib: '17:39', isha: '18:54' },
  { date: '2026-10-09', day: 9, month: 10, year: 2026, fajr: '04:38', sunrise: '05:53', dhuhr: '11:46', asr: '15:08', maghrib: '17:38', isha: '18:53' },
  { date: '2026-10-10', day: 10, month: 10, year: 2026, fajr: '04:38', sunrise: '05:53', dhuhr: '11:45', asr: '15:07', maghrib: '17:37', isha: '18:52' },
  { date: '2026-10-11', day: 11, month: 10, year: 2026, fajr: '04:39', sunrise: '05:54', dhuhr: '11:45', asr: '15:07', maghrib: '17:36', isha: '18:51' },
  { date: '2026-10-12', day: 12, month: 10, year: 2026, fajr: '04:39', sunrise: '05:54', dhuhr: '11:45', asr: '15:06', maghrib: '17:35', isha: '18:51' },
  { date: '2026-10-13', day: 13, month: 10, year: 2026, fajr: '04:39', sunrise: '05:55', dhuhr: '11:45', asr: '15:06', maghrib: '17:34', isha: '18:50' },
  { date: '2026-10-14', day: 14, month: 10, year: 2026, fajr: '04:40', sunrise: '05:55', dhuhr: '11:44', asr: '15:05', maghrib: '17:33', isha: '18:49' },
  { date: '2026-10-15', day: 15, month: 10, year: 2026, fajr: '04:40', sunrise: '05:56', dhuhr: '11:44', asr: '15:05', maghrib: '17:33', isha: '18:48' },
  { date: '2026-10-16', day: 16, month: 10, year: 2026, fajr: '04:41', sunrise: '05:56', dhuhr: '11:44', asr: '15:04', maghrib: '17:32', isha: '18:47' },
  { date: '2026-10-17', day: 17, month: 10, year: 2026, fajr: '04:41', sunrise: '05:56', dhuhr: '11:44', asr: '15:03', maghrib: '17:31', isha: '18:46' },
  { date: '2026-10-18', day: 18, month: 10, year: 2026, fajr: '04:41', sunrise: '05:57', dhuhr: '11:44', asr: '15:03', maghrib: '17:30', isha: '18:46' },
  { date: '2026-10-19', day: 19, month: 10, year: 2026, fajr: '04:42', sunrise: '05:57', dhuhr: '11:43', asr: '15:02', maghrib: '17:29', isha: '18:45' },
  { date: '2026-10-20', day: 20, month: 10, year: 2026, fajr: '04:42', sunrise: '05:58', dhuhr: '11:43', asr: '15:02', maghrib: '17:28', isha: '18:44' },
  { date: '2026-10-21', day: 21, month: 10, year: 2026, fajr: '04:43', sunrise: '05:58', dhuhr: '11:43', asr: '15:01', maghrib: '17:28', isha: '18:43' },
  { date: '2026-10-22', day: 22, month: 10, year: 2026, fajr: '04:43', sunrise: '05:59', dhuhr: '11:43', asr: '15:01', maghrib: '17:27', isha: '18:43' },
  { date: '2026-10-23', day: 23, month: 10, year: 2026, fajr: '04:43', sunrise: '05:59', dhuhr: '11:43', asr: '15:00', maghrib: '17:26', isha: '18:42' },
  { date: '2026-10-24', day: 24, month: 10, year: 2026, fajr: '04:44', sunrise: '06:00', dhuhr: '11:43', asr: '15:00', maghrib: '17:25', isha: '18:41' },
  { date: '2026-10-25', day: 25, month: 10, year: 2026, fajr: '04:44', sunrise: '06:00', dhuhr: '11:42', asr: '14:59', maghrib: '17:24', isha: '18:40' },
  { date: '2026-10-26', day: 26, month: 10, year: 2026, fajr: '04:45', sunrise: '06:01', dhuhr: '11:42', asr: '14:59', maghrib: '17:24', isha: '18:40' },
  { date: '2026-10-27', day: 27, month: 10, year: 2026, fajr: '04:45', sunrise: '06:01', dhuhr: '11:42', asr: '14:58', maghrib: '17:23', isha: '18:39' },
  { date: '2026-10-28', day: 28, month: 10, year: 2026, fajr: '04:46', sunrise: '06:02', dhuhr: '11:42', asr: '14:58', maghrib: '17:22', isha: '18:39' },
  { date: '2026-10-29', day: 29, month: 10, year: 2026, fajr: '04:46', sunrise: '06:02', dhuhr: '11:42', asr: '14:57', maghrib: '17:22', isha: '18:38' },
  { date: '2026-10-30', day: 30, month: 10, year: 2026, fajr: '04:46', sunrise: '06:03', dhuhr: '11:42', asr: '14:57', maghrib: '17:21', isha: '18:37' },
  { date: '2026-10-31', day: 31, month: 10, year: 2026, fajr: '04:47', sunrise: '06:03', dhuhr: '11:42', asr: '14:56', maghrib: '17:20', isha: '18:37' }
];
