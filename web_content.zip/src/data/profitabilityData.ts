import { CropProfitabilityModel } from '../types';

export const CROP_PROFITABILITY_MODELS: CropProfitabilityModel[] = [
  {
    id: 'crop-prof-sesame',
    cropKey: 'sesame',
    nameSw: 'Ufuta Mweupe wa Kisasa (Lindi 02)',
    nameEn: 'White Export Sesame (Lindi 02)',
    icon: '🌱',
    category: 'oilseeds',
    primaryExportMarket: {
      country: 'China',
      flag: '🇨🇳',
      corridor: 'Dar es Salaam ➔ Qingdao / Shanghai',
      fobUsdMt: 1820,
      tariffProtocolSw: 'Itifaki ya Ushuru 0% (China-Africa Zero-Tariff 98%)',
      tariffProtocolEn: 'China-Africa 98% Zero-Tariff Agreement',
      demandLevel: 'surging',
    },
    localMarketPriceTshKg: 3450,
    exportPriceTshKg: 4680,
    costBreakdownPerAcre: {
      seedsTsh: 35000,          // 5kg certified Lindi 02 from TOSCI depot
      landPrepTsh: 110000,      // Tractor ploughing & harrowing
      fertilizerTsh: 95000,     // Basal organic phosphate
      cropProtectionTsh: 45000, // Bio-neem & caterpillar control
      laborTsh: 85000,          // Thinning, weeding & stooking
      transportPortTsh: 50000,  // Bagging & transit to Dar warehouse/port
    },
    averageYieldKgPerAcre: 850,
    daysToHarvest: 105,
    climateRisk: 'low',
    waterRequirementSw: 'Kidogo (Inavumilia ukame vizuri sana, mvua mm 400-600)',
    waterRequirementEn: 'Low (Highly drought tolerant, 400-600mm rainfall)',
    bestSoilTypes: ['Kichanga chenye rutuba (Sandy loam)', 'Tifutifu (Loam)'],
    bestSeasons: ['masika', 'vuli'],
    aiVerdictSw: 'Zao namba moja kwa faida kubwa ya haraka! Mahitaji ya China ya ufuta safi wa Tanzania hayana kikomo na yana punguzo la ushuru 0%. Muda mfupi wa kukomaa (siku 105) unapunguza hatari ya hali ya hewa.',
    aiVerdictEn: 'Top ranked crop for fast, high-margin export returns! Uncapped Chinese zero-tariff demand ($1,820/MT) combined with modest production costs yields over 180% net return in just 105 days.',
    recommendedVarietySw: 'Lindi 02 au Songa (Mafuta 53%+, TOSCI certified)',
    recommendedVarietyEn: 'Lindi 02 or Songa (53%+ oil content, TOSCI certified)',
    buyerNetworkPartnerSw: 'Sinoma Agri & COFCO International (Dar Port FOB)',
    buyerNetworkPartnerEn: 'Sinoma Agri & COFCO International (Dar Port FOB)',
  },
  {
    id: 'crop-prof-soybean',
    cropKey: 'soybeans',
    nameSw: 'Soya Chotara ya Lishe (Uyole Soya 1)',
    nameEn: 'Non-GMO Yellow Soybeans (Uyole 1)',
    icon: '🌾',
    category: 'pulses',
    primaryExportMarket: {
      country: 'China',
      flag: '🇨🇳',
      corridor: 'Dar es Salaam ➔ Tianjin & Nantong',
      fobUsdMt: 890,
      tariffProtocolSw: 'Itifaki Rasmi ya GACC (General Administration of Customs China)',
      tariffProtocolEn: 'Official Bilateral Protocol with GACC China',
      demandLevel: 'very_high',
    },
    localMarketPriceTshKg: 1850,
    exportPriceTshKg: 2280,
    costBreakdownPerAcre: {
      seedsTsh: 48000,          // 10kg Uyole Soya 1 certified
      landPrepTsh: 120000,      // Deep tilling & bed formation
      fertilizerTsh: 125000,    // Rhizobium inoculant + Minjingu Nafaka
      cropProtectionTsh: 55000, // Rust & pod borer management
      laborTsh: 90000,          // Planting, weeding, threshing
      transportPortTsh: 55000,  // 50kg PP woven bags & trucking
    },
    averageYieldKgPerAcre: 1550,
    daysToHarvest: 100,
    climateRisk: 'low',
    waterRequirementSw: 'Kati (Inavumilia mvua za wastani na kurutubisha udongo kwa naitrojeni)',
    waterRequirementEn: 'Medium (Moderate rainfall, naturally fixes nitrogen in soil)',
    bestSoilTypes: ['Tifutifu (Loam)', 'Kichanga (Sandy Loam)', 'Udongo Mweusi (Clay Loam)'],
    bestSeasons: ['masika', 'vuli'],
    aiVerdictSw: 'Chaguo bora la kuongeza uzalishaji kwa hekari kubwa. Soya huongeza rutuba ya shamba kwa zao linalofuata na ina uhakika wa ununuzi wa tani laki kadhaa kwenda China na viwanda vya ndani vya mafuta.',
    aiVerdictEn: 'Superb balance of volume and market security. Nitrogen-fixing legume with guaranteed export uptake under the GACC China protocol and booming domestic animal-feed mill demand.',
    recommendedVarietySw: 'Uyole Soya 1 au Bossier (Protini 40%+)',
    recommendedVarietyEn: 'Uyole Soya 1 or Bossier (40%+ crude protein)',
    buyerNetworkPartnerSw: 'Wilmar Tanzania & China Grain Reserves Corp',
    buyerNetworkPartnerEn: 'Wilmar Tanzania & China Grain Reserves Corp',
  },
  {
    id: 'crop-prof-avocado',
    cropKey: 'avocado',
    nameSw: 'Parachichi la Hass (Export Grade A)',
    nameEn: 'Hass Export Avocado (Global GAP)',
    icon: '🥑',
    category: 'fruits',
    primaryExportMarket: {
      country: 'European Union',
      flag: '🇪🇺',
      corridor: 'Dar es Salaam ➔ Port of Rotterdam & Hamburg',
      fobUsdMt: 3250,
      tariffProtocolSw: 'Itifaki ya Ushuru Sifuri ya EU EBA (Everything But Arms)',
      tariffProtocolEn: 'EU Everything But Arms (EBA) Zero-Duty Protocol',
      demandLevel: 'surging',
    },
    localMarketPriceTshKg: 2800,
    exportPriceTshKg: 8350,
    costBreakdownPerAcre: {
      seedsTsh: 260000,         // Grafted certified seedlings (40 trees/ac prorated amortized)
      landPrepTsh: 140000,      // Tree pitting, compost blending
      fertilizerTsh: 280000,    // Organic potassium & calcium nitrate
      cropProtectionTsh: 180000,// Bio-copper fungicide & fruit fly traps
      laborTsh: 190000,         // Canopy pruning, selective picking
      transportPortTsh: 150000, // Cold-chain refrigerated van to port
    },
    averageYieldKgPerAcre: 3800,
    daysToHarvest: 180, // Harvest window
    climateRisk: 'medium',
    waterRequirementSw: 'Kati hadi Juu (Inahitaji unyevu endelevu au umwagiliaji wa matone)',
    waterRequirementEn: 'Medium to High (Consistent moisture or drip irrigation)',
    bestSoilTypes: ['Udongo wa Volkano (Volcanic)', 'Tifutifu yenye mifereji mizuri (Deep loam)'],
    bestSeasons: ['irrigation', 'masika'],
    aiVerdictSw: 'Zao lenye faida ya juu zaidi ya kifedha (Marginal Return > 230%). Soko la Uholanzi, Ufaransa na Ujerumani linalipa bei ya kipekee ($3,250/MT). Inahitaji usimamizi wa ubora wa Global GAP.',
    aiVerdictEn: 'The highest cash return per acre in East African horticulture (>230% ROI). European supermarkets pay premium spot prices for export-certified Hass avocados under cold chain.',
    recommendedVarietySw: 'Hass Seedlings (Zilizopandikizwa kwenye shina la kiasili)',
    recommendedVarietyEn: 'Grafted Hass Seedlings on Duke 7 rootstocks',
    buyerNetworkPartnerSw: 'Africado Ltd, Kuza Fresh & Nature’s Pride EU',
    buyerNetworkPartnerEn: 'Africado Ltd, Kuza Fresh & Nature’s Pride EU',
  },
  {
    id: 'crop-prof-cashew',
    cropKey: 'cashew',
    nameSw: 'Korosho Zilizobanguliwa (Wholes W320)',
    nameEn: 'Processed White Cashew Kernels (W320)',
    icon: '🥜',
    category: 'oilseeds',
    primaryExportMarket: {
      country: 'United States',
      flag: '🇺🇸',
      corridor: 'Mtwara / Dar ➔ Long Beach & Savannah Ports',
      fobUsdMt: 7550,
      tariffProtocolSw: 'Mpango wa AGOA wa Marekani (0% Duty + FDA FSMA)',
      tariffProtocolEn: 'US AGOA Duty-Free Treatment + FDA Safety Standard',
      demandLevel: 'high',
    },
    localMarketPriceTshKg: 4200, // Raw nut benchmark
    exportPriceTshKg: 19400, // Processed kernel
    costBreakdownPerAcre: {
      seedsTsh: 65000,          // Pruning & orchard maintenance
      landPrepTsh: 80000,       // Firebreaks & ring clearing
      fertilizerTsh: 190000,    // Sulfur dusting against powdery mildew
      cropProtectionTsh: 140000,// Helopeltis & coreid bug organic sprays
      laborTsh: 210000,         // Harvesting, sorting & cracking labor
      transportPortTsh: 95000,  // Nitrogen vacuum tins & freight
    },
    averageYieldKgPerAcre: 620, // Equivalent kernel yield
    daysToHarvest: 120,
    climateRisk: 'low',
    waterRequirementSw: 'Kidogo (Inavumilia ukame wa Pwani na Mtwara bila shida)',
    waterRequirementEn: 'Low (Ideal for coastal climate, highly drought resistant)',
    bestSoilTypes: ['Kichanga chekundu cha pwani', 'Tifutifu ya bondeni'],
    bestSeasons: ['masika', 'vuli'],
    aiVerdictSw: 'Bei za AGOA za Marekani zimepanda kwa 10.5% robo hii. Kubangulia nchini kunaongeza thamani mara 4 kulinganisha na kuuza korosho ghafi kwa madalali.',
    aiVerdictEn: 'US AGOA buyers are paying top dollar ($7,550/MT) for Tanzania-processed W320 kernels. Processing locally multiplies farmer gross margin 4-fold versus raw in-shell nuts.',
    recommendedVarietySw: 'Acheni Chotara (TARI Naliendele Clones AC4 & AC10)',
    recommendedVarietyEn: 'TARI Naliendele Clones AC4 & AC10',
    buyerNetworkPartnerSw: 'Costco Wholesale & Kraft Heinz Nut Division',
    buyerNetworkPartnerEn: 'Costco Wholesale & Kraft Heinz Nut Division',
  },
  {
    id: 'crop-prof-chili',
    cropKey: 'chili',
    nameSw: 'Pilipili Kichaa Iliyokaushwa (Bird\'s Eye Chili)',
    nameEn: 'African Bird\'s Eye Chili (Dried)',
    icon: '🌶️',
    category: 'spices',
    primaryExportMarket: {
      country: 'China',
      flag: '🇨🇳',
      corridor: 'Dar es Salaam ➔ Qingdao Spice Market',
      fobUsdMt: 4850,
      tariffProtocolSw: 'Itifaki ya Usafi na Afya ya Mimea ya China (GACC SPS)',
      tariffProtocolEn: 'GACC Phytosanitary Zero-Tariff Protocol',
      demandLevel: 'surging',
    },
    localMarketPriceTshKg: 6200,
    exportPriceTshKg: 12450,
    costBreakdownPerAcre: {
      seedsTsh: 55000,          // Certified high-capsaicin seed
      landPrepTsh: 130000,      // Raised beds & mulching
      fertilizerTsh: 175000,    // Organic chicken manure & DAP
      cropProtectionTsh: 120000,// Whitefly & thrips IPM control
      laborTsh: 240000,         // Multiple handpickings & solar drying
      transportPortTsh: 65000,  // Air-tight polyethylene packaging
    },
    averageYieldKgPerAcre: 1100, // Dry weight
    daysToHarvest: 90,
    climateRisk: 'medium',
    waterRequirementSw: 'Kati (Inapendelea unyevu wa wastani na jua kali la kukausha)',
    waterRequirementEn: 'Medium (Warm weather, solar drying sheds required)',
    bestSoilTypes: ['Tifutifu yenye rutuba (Loam)', 'Udongo mweusi usiotuamisha maji'],
    bestSeasons: ['masika', 'irrigation'],
    aiVerdictSw: 'Zao lenye mzunguko wa haraka zaidi wa mapato! Huanza kuvunwa baada ya siku 85 tu na huvunwa kila wiki kwa miezi minne mfululizo. Bei ya China ni mara 2 ya soko la ndani.',
    aiVerdictEn: 'Fastest cashflow turnover in modern agro. Harvest starts in 85 days with continuous pickings for 4 months. Export price in China delivers over 205% return on working capital.',
    recommendedVarietySw: 'Demon F1 au African Bird’s Eye (SHU 100,000+)',
    recommendedVarietyEn: 'Demon F1 or African Bird’s Eye (SHU 100,000+)',
    buyerNetworkPartnerSw: 'Hunan Chili Processing Hub & Qingdao Spices',
    buyerNetworkPartnerEn: 'Hunan Chili Processing Hub & Qingdao Spices',
  },
  {
    id: 'crop-prof-toor',
    cropKey: 'pigeon_peas',
    nameSw: 'Mbaazi Safi za Kuchemsha (Toor Dal)',
    nameEn: 'Grade A Pigeon Peas (Toor Dal)',
    icon: '🫛',
    category: 'pulses',
    primaryExportMarket: {
      country: 'India',
      flag: '🇮🇳',
      corridor: 'Dar es Salaam / Tanga ➔ JNPT Port Mumbai',
      fobUsdMt: 990,
      tariffProtocolSw: 'Mkataba wa Nchi na Nchi (Tanzania-India Bilateral G2G Quota 0%)',
      tariffProtocolEn: 'Tanzania-India Bilateral G2G Quota (0% Duty)',
      demandLevel: 'high',
    },
    localMarketPriceTshKg: 1750,
    exportPriceTshKg: 2550,
    costBreakdownPerAcre: {
      seedsTsh: 32000,          // 8kg certified seed (ICEAP 00040)
      landPrepTsh: 95000,       // Minimum tillage
      fertilizerTsh: 75000,     // Low phosphate basal
      cropProtectionTsh: 65000, // Pod borer control at flowering
      laborTsh: 75000,          // Harvesting & sun drying
      transportPortTsh: 45000,  // PP bags & Dar transport
    },
    averageYieldKgPerAcre: 1050,
    daysToHarvest: 130,
    climateRisk: 'low',
    waterRequirementSw: 'Kidogo Sana (Mzizi mrefu unaostahimili ukame mkali)',
    waterRequirementEn: 'Very Low (Deep taproot, thrives under extreme dry spells)',
    bestSoilTypes: ['Tifutifu (Loam)', 'Kichanga chepesi (Sandy loam)'],
    bestSeasons: ['masika', 'vuli'],
    aiVerdictSw: 'Zao lenye hatari ndogo zaidi ya mtaji (Lowest Capital Risk). Gharama ya uzalishaji ni Tsh 387,000 tu kwa hekari. Mkataba wa serikali na India (NAFED) unahakikisha soko thabiti.',
    aiVerdictEn: 'Lowest investment entry barrier with robust downside protection. Total acre cost is under Tsh 390,000. Secured through government-to-government bilateral quota to India (NAFED).',
    recommendedVarietySw: 'ICEAP 00040 au Komboa (Mbaazi nyeupe kubwa)',
    recommendedVarietyEn: 'ICEAP 00040 or Komboa (Large white seed)',
    buyerNetworkPartnerSw: 'NAFED India & Export Trading Group (ETG)',
    buyerNetworkPartnerEn: 'NAFED India & Export Trading Group (ETG)',
  },
  {
    id: 'crop-prof-cassava',
    cropKey: 'cassava',
    nameSw: 'Mihogo Mikavu ya Viwanda (HQCF Dried Chips)',
    nameEn: 'Industrial Cassava Chips (HQCF)',
    icon: '🥔',
    category: 'tubers',
    primaryExportMarket: {
      country: 'China',
      flag: '🇨🇳',
      corridor: 'Mtwara / Dar ➔ Rizhao Port & Shandong Biofuel',
      fobUsdMt: 340,
      tariffProtocolSw: 'Makubaliano ya Uuzaji wa Muhogo Mmkavu Tanzania-China',
      tariffProtocolEn: 'Tanzania-China Cassava Chips Trade Protocol',
      demandLevel: 'high',
    },
    localMarketPriceTshKg: 550,
    exportPriceTshKg: 870,
    costBreakdownPerAcre: {
      seedsTsh: 45000,          // High yielding virus-resistant cuttings (Kiroba)
      landPrepTsh: 110000,      // Ridge preparation
      fertilizerTsh: 65000,     // Farmyard manure topdress
      cropProtectionTsh: 30000, // Cassava mosaic prevention
      laborTsh: 95000,          // Cutting, planting, slicing & drying
      transportPortTsh: 40000,  // Bulk truckload shipping
    },
    averageYieldKgPerAcre: 5200, // Dry chips equivalent
    daysToHarvest: 240,
    climateRisk: 'low',
    waterRequirementSw: 'Kidogo Sana (Inastahimili ukame wa aina yoyote)',
    waterRequirementEn: 'Very Low (Survives severe drought effortlessly)',
    bestSoilTypes: ['Kichanga (Sandy)', 'Tifutifu kavu (Well-drained loam)'],
    bestSeasons: ['masika', 'vuli'],
    aiVerdictSw: 'Zao la kiasi kikubwa cha uzalishaji (High Volume Bulk). Hutoa tani 5+ za vipande vilivyokaushwa kwa hekari. Viwanda vya China vya bio-ethanol na wanga huchukua shehena nzima bila kikomo.',
    aiVerdictEn: 'Heavy volume staple with unmatched resilience. Delivers 5+ tons of dried chips per acre for bio-ethanol and food starch processors in China with zero crop failure risk.',
    recommendedVarietySw: 'Kiroba, Chereko au Mkuranga 1 (TOSCI Certified)',
    recommendedVarietyEn: 'Kiroba, Chereko or Mkuranga 1 (TOSCI Certified)',
    buyerNetworkPartnerSw: 'Shandong Bio-Starch & China National Cereals Corp',
    buyerNetworkPartnerEn: 'Shandong Bio-Starch & China National Cereals Corp',
  },
];
