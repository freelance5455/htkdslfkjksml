import { Badge, ShopItem } from '../types/game';

export const BADGES: Badge[] = [
  {
    id: 'first_quest',
    title: 'Quest Initiate',
    description: 'Completed your first NutriQuest challenge!',
    icon: '🎯',
    category: 'quest',
    rarity: 'common',
  },
  {
    id: 'veg_master',
    title: 'Veggie Vanguard',
    description: 'Mastered the Vegetables & Legumes food group!',
    icon: '🥦',
    category: 'mastery',
    rarity: 'rare',
  },
  {
    id: 'fruit_master',
    title: 'Fruit Fanatic',
    description: 'Conquered the Fruit Orchard and learned antioxidant superpowers!',
    icon: '🍎',
    category: 'mastery',
    rarity: 'rare',
  },
  {
    id: 'grain_master',
    title: 'Grain Gladiator',
    description: 'Unlocked whole grain sustained brain energy secrets!',
    icon: '🌾',
    category: 'mastery',
    rarity: 'rare',
  },
  {
    id: 'protein_master',
    title: 'Protein Powerhouse',
    description: 'Aced all questions on teen growth spurts and muscle repair!',
    icon: '🍗',
    category: 'mastery',
    rarity: 'epic',
  },
  {
    id: 'dairy_master',
    title: 'Bone Builder Titan',
    description: 'Understood peak teen bone density and calcium banking!',
    icon: '🥛',
    category: 'mastery',
    rarity: 'epic',
  },
  {
    id: 'plate_architect',
    title: 'Plate Architect',
    description: 'Constructed a perfectly balanced 5-group meal in the Teen Food Lab!',
    icon: '🍽️',
    category: 'mastery',
    rarity: 'epic',
  },
  {
    id: 'blitz_champion',
    title: 'Speed Sorter Champion',
    description: 'Achieved a score of 500+ in the fast-paced Plate Blitz!',
    icon: '⚡',
    category: 'blitz',
    rarity: 'epic',
  },
  {
    id: 'streak_master',
    title: 'Streak Titan',
    description: 'Kept a 5-answer or 3-day healthy eating streak alive!',
    icon: '🔥',
    category: 'streak',
    rarity: 'legendary',
  },
  {
    id: 'nutri_legend',
    title: 'NutriQuest Champion',
    description: 'Reached Level 5 and proved true healthy eating mastery!',
    icon: '👑',
    category: 'quest',
    rarity: 'legendary',
  },
];

export const SHOP_ITEMS: ShopItem[] = [
  // POWERUPS
  {
    id: 'powerup_5050',
    name: '50/50 Lifeline',
    description: 'Eliminates 2 incorrect answers during any quiz challenge!',
    price: 60,
    type: 'powerup',
    icon: '✂️',
  },
  {
    id: 'powerup_freeze',
    name: 'Time Freeze (+15s)',
    description: 'Adds 15 seconds to the timer in Plate Blitz and Speed Quizzes!',
    price: 80,
    type: 'powerup',
    icon: '⏱️',
  },
  {
    id: 'powerup_double_xp',
    name: 'Double XP Boost',
    description: 'Earn 2x NutriPoints for the next game round!',
    price: 100,
    type: 'powerup',
    icon: '⭐',
  },

  // AVATAR ACCESSORIES
  {
    id: 'gear_chef_hat',
    name: 'Master Chef Toque',
    description: 'Wear the majestic white hat of a nutrition culinary expert.',
    price: 150,
    type: 'headwear',
    icon: '👨‍🍳',
  },
  {
    id: 'gear_gamer_headset',
    name: 'Neon Gaming Headset',
    description: 'Stay in the zone with glowing teen gamer audio cans.',
    price: 180,
    type: 'headwear',
    icon: '🎧',
  },
  {
    id: 'gear_sweatband',
    name: 'Athletic Champion Headband',
    description: 'For active teen athletes ready for match day.',
    price: 120,
    type: 'headwear',
    icon: '🎽',
  },
  {
    id: 'gear_sunglasses',
    name: 'Cool Shades',
    description: 'Look effortlessly chill while eating your vegetables.',
    price: 140,
    type: 'headwear',
    icon: '🕶️',
  },
  {
    id: 'gear_cape',
    name: 'Nutri-Hero Cape',
    description: 'Every superhero defends their health with the 5 food groups.',
    price: 250,
    type: 'outfit',
    icon: '🦸',
  },
];

export const LEVELS = [
  { level: 1, title: 'Snack Scout', minXp: 0, rewardCoins: 50 },
  { level: 2, title: 'Veggie Explorer', minXp: 150, rewardCoins: 100 },
  { level: 3, title: 'Nutri Pioneer', minXp: 350, rewardCoins: 150 },
  { level: 4, title: 'Macro Master', minXp: 650, rewardCoins: 200 },
  { level: 5, title: 'Plate Architect', minXp: 1050, rewardCoins: 300 },
  { level: 6, title: 'Wellness Warrior', minXp: 1550, rewardCoins: 400 },
  { level: 7, title: 'Supreme Food Legend', minXp: 2200, rewardCoins: 500 },
];

export function getLevelInfo(xp: number) {
  let currentLevel = LEVELS[0];
  let nextLevel = LEVELS[1];

  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (xp >= LEVELS[i].minXp) {
      currentLevel = LEVELS[i];
      nextLevel = LEVELS[i + 1] || null;
      break;
    }
  }

  const prevXp = currentLevel.minXp;
  const targetXp = nextLevel ? nextLevel.minXp : currentLevel.minXp + 1000;
  const progressPercent = Math.min(100, Math.max(0, ((xp - prevXp) / (targetXp - prevXp)) * 100));

  return {
    currentLevel,
    nextLevel,
    progressPercent,
  };
}

export interface MealScenario {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  targetFocus: string;
  recommendedGroups: string[];
}

export const MEAL_SCENARIOS: MealScenario[] = [
  {
    id: 'exam_morning',
    title: 'Exam Day Power Breakfast',
    subtitle: 'High School Chemistry Midterm at 8:30 AM',
    description: 'You need sharp brain memory and calm focus that will last 4 hours without a caffeine or sugar crash.',
    targetFocus: 'Whole Grains + Dairy/Calcium + Fresh Fruit',
    recommendedGroups: ['grains', 'dairy', 'fruits'],
  },
  {
    id: 'sports_refuel',
    title: 'Post-Soccer Match Recovery Lunch',
    subtitle: '90 Minutes of Sprinting on the Field',
    description: 'Your muscles need immediate repair, electrolytes restored, and glycogen restocked.',
    targetFocus: 'Lean Protein + Whole Grains + Colorful Veggies + Hydration',
    recommendedGroups: ['protein', 'grains', 'vegetables', 'fruits'],
  },
  {
    id: 'cafeteria_smart_plate',
    title: 'School Cafeteria Full Balance Plate',
    subtitle: 'Everyday Teen Lunch Tray Dilemma',
    description: 'Build a balanced plate representing all 5 food groups from standard cafeteria options.',
    targetFocus: 'Cover all 5 Food Groups for complete nutritional coverage',
    recommendedGroups: ['vegetables', 'fruits', 'grains', 'protein', 'dairy'],
  },
  {
    id: 'study_night_snack',
    title: 'Late Night Study Session Snack',
    subtitle: 'Finishing a History Project at 9:00 PM',
    description: 'A light snack that fuels memory without causing restless sleep or acid indigestion.',
    targetFocus: 'Dairy/Casein or Fruit + Healthy Nut Protein',
    recommendedGroups: ['dairy', 'fruits', 'protein'],
  },
];
