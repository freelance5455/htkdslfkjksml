import { TrackConfig, TrackId } from '../types.ts';

export const TRACKS: Record<TrackId, TrackConfig> = {
  sahara: {
    id: 'sahara',
    name: 'Sahara Desert Highway',
    arabicName: 'طريق الصحراء الكبرى (غرداية - تمنراست)',
    roadColor: '#8b6f47',
    roadEdgeColor: '#6b5438',
    groundColor: '#d2a679',
    groundTextureColor: '#b5895c',
    curbColor1: '#e67e22',
    curbColor2: '#f1c40f',
    skyGradient: ['#2c003e', '#e67e22'],
    decorTypes: ['cactus', 'rock', 'camel', 'dune'],
    bgSilhouette: 'dunes'
  },
  corniche: {
    id: 'corniche',
    name: 'Algiers Coastal Corniche',
    arabicName: 'كورنيش الجزائر العاصمة (خليج الجزائر)',
    roadColor: '#3a404a',
    roadEdgeColor: '#2b3038',
    groundColor: '#1e6f9e',
    groundTextureColor: '#144e70',
    curbColor1: '#e74c3c',
    curbColor2: '#ffffff',
    skyGradient: ['#0f2027', '#203a43'],
    decorTypes: ['palm', 'rock'],
    bgSilhouette: 'monument'
  },
  atlas: {
    id: 'atlas',
    name: 'Atlas Mountain Pass',
    arabicName: 'منعرجات جبال الأطلس وجرجرة',
    roadColor: '#4a4e51',
    roadEdgeColor: '#2d3134',
    groundColor: '#3b5336',
    groundTextureColor: '#253521',
    curbColor1: '#27ae60',
    curbColor2: '#ffffff',
    skyGradient: ['#1c2833', '#566573'],
    decorTypes: ['pine', 'rock', 'sheep'],
    bgSilhouette: 'mountains'
  }
};

export const TRACK_LIST = Object.values(TRACKS);
