import { PharmacyStore } from '../types';

/**
 * Calculates straight-line distance in kilometers between two coordinates using Haversine formula
 */
export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100; // precision to 2 decimals
}

export function cleanPhoneNumber(rawPhone: string): string {
  if (!rawPhone) return '';
  const first = rawPhone.split(/;|,|\/|\||\bor\b/i)[0].trim();
  return first.replace(/\s+/g, ' ').trim();
}

export function getDialablePhoneNumber(phone: string): string {
  if (!phone) return '';
  return phone.replace(/[^0-9+]/g, '');
}

function extractPhoneFromTags(tags: Record<string, string>): string {
  if (!tags) return '';
  const possibleKeys = [
    'phone',
    'contact:phone',
    'telephone',
    'contact:telephone',
    'phone:mobile',
    'contact:mobile',
    'healthcare:phone',
    'operator:phone',
    'phone:en',
    'contact:phone:en',
  ];
  for (const key of possibleKeys) {
    if (tags[key] && tags[key].trim().length >= 3) {
      return tags[key].trim();
    }
  }
  return '';
}

/**
 * Searches real-time nearby pharmacies around user's GPS coordinates within a strict 15 km radius
 */
export async function fetchRealNearbyPharmacies(
  lat: number,
  lng: number,
  maxRadiusKm = 15.0
): Promise<PharmacyStore[]> {
  const maxRadiusMeters = Math.min(15000, Math.round(maxRadiusKm * 1000));
  
  // 1. Try OpenStreetMap Overpass API
  const overpassUrl = `https://overpass-api.de/api/interpreter?data=[out:json][timeout:12];(node["amenity"="pharmacy"](around:${maxRadiusMeters},${lat},${lng});way["amenity"="pharmacy"](around:${maxRadiusMeters},${lat},${lng});relation["amenity"="pharmacy"](around:${maxRadiusMeters},${lat},${lng});node["healthcare"="pharmacy"](around:${maxRadiusMeters},${lat},${lng});way["healthcare"="pharmacy"](around:${maxRadiusMeters},${lat},${lng});node["shop"="chemist"](around:${maxRadiusMeters},${lat},${lng});way["shop"="chemist"](around:${maxRadiusMeters},${lat},${lng});node["shop"="medical_supply"](around:${maxRadiusMeters},${lat},${lng});way["shop"="medical_supply"](around:${maxRadiusMeters},${lat},${lng}););out body center;`;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 9000);

    const res = await fetch(overpassUrl, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data && Array.isArray(data.elements)) {
        const rawResults: PharmacyStore[] = [];

        for (const el of data.elements) {
          const pharmLat = el.lat ?? el.center?.lat;
          const pharmLng = el.lon ?? el.center?.lon;
          if (!pharmLat || !pharmLng) continue;

          const distKm = calculateHaversineDistance(lat, lng, pharmLat, pharmLng);
          
          // STRICT 15 KM RADIUS FILTER (Must be within 15 km)
          if (distKm > maxRadiusKm) continue;

          const tags: Record<string, string> = el.tags || {};
          const rawName =
            tags.name ||
            tags['name:en'] ||
            tags.brand ||
            tags.operator ||
            (tags.shop === 'chemist' ? 'Chemist & Druggist' : 'Pharmacy & Medical Store');

          const operator = tags.operator || tags.brand || undefined;

          const addrParts = [
            tags['addr:street'],
            tags['addr:suburb'] || tags['addr:neighbourhood'],
            tags['addr:city'],
          ].filter(Boolean);

          const address =
            addrParts.length > 0
              ? addrParts.join(', ')
              : `${rawName}, Local Area`;

          const rawPhone = extractPhoneFromTags(tags);
          const phone = cleanPhoneNumber(rawPhone);

          const is24x7 =
            tags.opening_hours === '24/7' ||
            tags['dispensing:24_7'] === 'yes' ||
            tags['opening_hours:covid19'] === '24/7';

          const openingHours = tags.opening_hours || (is24x7 ? 'Open 24/7' : 'Standard Pharmacy Hours (8:00 AM - 11:00 PM)');

          const distMeters = Math.round(distKm * 1000);
          const distanceText = distKm < 1.0 ? `${distMeters} m` : `${distKm.toFixed(1)} km`;
          const travelMins = Math.max(1, Math.round((distKm / 30) * 60));
          const estimatedTime = `~${travelMins} mins drive`;

          const pharmacyId = `pharm_${el.id}`;

          rawResults.push({
            id: pharmacyId,
            name: rawName,
            address,
            phone,
            distanceKm: distKm,
            distanceText,
            estimatedTime,
            latitude: pharmLat,
            longitude: pharmLng,
            operator,
            openingHours,
            is24x7,
          });
        }

        // Deduplicate by name and proximity (< 50 meters)
        const uniquePharmacies: PharmacyStore[] = [];
        const seen = new Set<string>();

        for (const p of rawResults) {
          const key = `${p.name.toLowerCase().trim()}_${p.latitude.toFixed(3)}_${p.longitude.toFixed(3)}`;
          if (!seen.has(key)) {
            seen.add(key);
            uniquePharmacies.push(p);
          }
        }

        // Parallel phone enrichment for top pharmacies missing phone numbers
        const missingPhoneTargets = uniquePharmacies.filter((p) => !p.phone).slice(0, 5);
        if (missingPhoneTargets.length > 0) {
          await Promise.allSettled(
            missingPhoneTargets.map(async (p) => {
              try {
                const nomUrl = `https://nominatim.openstreetmap.org/search?format=json&extratags=1&addressdetails=1&q=${encodeURIComponent(
                  p.name
                )}&lat=${p.latitude}&lon=${p.longitude}&bounded=1&viewbox=${p.longitude - 0.03},${
                  p.latitude + 0.03
                },${p.longitude + 0.03},${p.latitude - 0.03}`;

                const nomRes = await fetch(nomUrl, {
                  headers: { 'User-Agent': 'MediguideAI/1.0' },
                });
                if (nomRes.ok) {
                  const nomItems = await nomRes.json();
                  if (Array.isArray(nomItems) && nomItems.length > 0) {
                    for (const nomItem of nomItems) {
                      const extra = nomItem.extratags || {};
                      const phoneStr = extractPhoneFromTags(extra);
                      if (phoneStr && phoneStr.trim().length >= 3) {
                        p.phone = cleanPhoneNumber(phoneStr);
                        return;
                      }
                    }
                  }
                }
              } catch (e) {
                // Ignore timeout
              }
            })
          );
        }

        // SORT BY NEAREST DISTANCE FIRST (Requirement 6)
        uniquePharmacies.sort((a, b) => a.distanceKm - b.distanceKm);

        if (uniquePharmacies.length > 0) {
          return uniquePharmacies;
        }
      }
    }
  } catch (err) {
    console.warn('[PharmacyData] Overpass API query error:', err);
  }

  // 2. Fallback query to Nominatim
  try {
    const delta = (maxRadiusKm / 111.0); // approx degrees for 15km
    const nominatimUrl = `https://nominatim.openstreetmap.org/search?format=json&extratags=1&addressdetails=1&q=pharmacy&lat=${lat}&lon=${lng}&bounded=1&viewbox=${lng - delta},${lat + delta},${lng + delta},${lat - delta}`;
    
    const res = await fetch(nominatimUrl, { headers: { 'User-Agent': 'MediguideAI/1.0' } });
    if (res.ok) {
      const items = await res.json();
      if (Array.isArray(items) && items.length > 0) {
        const results: PharmacyStore[] = [];
        for (const item of items) {
          const pharmLat = parseFloat(item.lat);
          const pharmLng = parseFloat(item.lon);
          const distKm = calculateHaversineDistance(lat, lng, pharmLat, pharmLng);

          // STRICT 15 KM RADIUS FILTER (Requirement 4)
          if (distKm > maxRadiusKm) continue;

          const name = item.display_name.split(',')[0] || 'Community Pharmacy';
          const address = item.display_name.split(',').slice(1, 4).join(', ').trim() || 'Local Area';
          const distMeters = Math.round(distKm * 1000);
          const distanceText = distKm < 1.0 ? `${distMeters} m` : `${distKm.toFixed(1)} km`;
          const travelMins = Math.max(1, Math.round((distKm / 30) * 60));

          const extra = item.extratags || {};
          const rawPhone = extractPhoneFromTags(extra);
          const phone = cleanPhoneNumber(rawPhone);

          const pharmacyId = `nom_${item.place_id}`;

          results.push({
            id: pharmacyId,
            name,
            address,
            phone,
            distanceKm: distKm,
            distanceText,
            estimatedTime: `~${travelMins} mins drive`,
            latitude: pharmLat,
            longitude: pharmLng,
            openingHours: 'Standard Pharmacy Hours (8:00 AM - 11:00 PM)',
          });
        }

        // SORT BY NEAREST DISTANCE FIRST (Requirement 6)
        results.sort((a, b) => a.distanceKm - b.distanceKm);
        return results;
      }
    }
  } catch (err) {
    console.warn('[PharmacyData] Nominatim query error:', err);
  }

  return [];
}
