import { GrammarRule, GrammarTopic } from '../types';

export const sarfTopics: GrammarTopic[] = [
  {
    id: 'intro_sarf',
    category: 'sarf',
    arabicTitle: 'مُقَدِّمَةُ عِلْمِ الصَّرْفِ',
    title: {
      pashto: 'د صرف علم پېژندنه او بنسټونه',
      urdu: 'علم الصرف کا تعارف اور بنیادی اصول',
      english: 'Introduction to Ilm-e-Sarf (Morphology)'
    },
    description: {
      pashto: 'د صرف علم تعریف، موضوع، غرض او موخه په بشپړه بڼه',
      urdu: 'علم الصرف کی تعریف، موضوع اور اس کا مقصد و غایت',
      english: 'Definition, subject matter, and primary objectives of Arabic morphology'
    },
    iconName: 'BookOpen',
    rulesCount: 3
  },
  {
    id: 'abwaab_mujarrad',
    category: 'sarf',
    arabicTitle: 'أَبْوَابُ الثُّلَاثِيِّ الْمُجَرَّدِ',
    title: {
      pashto: 'د ثلاثي مجرد شپږ واړه ابواب',
      urdu: 'ثلاثی مجرد کے چھ ابواب',
      english: 'The 6 Categories of Bare Triliteral Verbs'
    },
    description: {
      pashto: 'نصر، ضرب، سمع، فتح، حسب او کرم ابوابو بشپړ قواعد او نښې',
      urdu: 'نصر، ضرب، سمع، فتح، حسب اور کرم کے ابواب، علامات اور مثالیں',
      english: 'In-depth study of the six classical triliteral verb patterns'
    },
    iconName: 'Layers',
    rulesCount: 6
  },
  {
    id: 'abwaab_mazeed',
    category: 'sarf',
    arabicTitle: 'أَبْوَابُ الثُّلَاثِيِّ الْمَزِيدِ فِيهِ',
    title: {
      pashto: 'د ثلاثي مزید فیه مشهور ابواب',
      urdu: 'ثلاثی مزید فیہ کے مشہور ابواب',
      english: 'Triliteral Verbs with Derived Augmentations'
    },
    description: {
      pashto: 'افعال، تفعیل، مفاعلة، تفعل، تفاعل، افتعال، انفعال او استفعال',
      urdu: 'افعال، تفعیل، مفاعلہ، تفعل، تفاعل، افتعال، انفعال اور استفعال کے خواص',
      english: 'Derived verbal forms (Forms II to X) with specific semantic nuances'
    },
    iconName: 'Boxes',
    rulesCount: 4
  },
  {
    id: 'haft_aqsaam',
    category: 'sarf',
    arabicTitle: 'هَفْت أَقْسَام (الأَقْسَامُ السَّبْعَةُ)',
    title: {
      pashto: 'هفت اقسام (د حروفو له مخې اووه قسمه افعال)',
      urdu: 'ہفت اقسام (حروف کے اعتبار سے افعال کی ۷ قسمیں)',
      english: 'Haft Aqsaam (The Seven Morphological Root Classes)'
    },
    description: {
      pashto: 'صحیح، مثال، مضعف، لفیف، ناقص، مهموز او اجوف بشپړه پېژندنه',
      urdu: 'صحیح، مثال، مضاعف، لفیف، ناقص، مہموز اور اجوف کے قواعد',
      english: 'Sound, Assimilated, Doubled, Defective, Hollow, and Hamzated roots'
    },
    iconName: 'Shapes',
    rulesCount: 4
  },
  {
    id: 'mushtaqqaat',
    category: 'sarf',
    arabicTitle: 'الأَسْمَاءُ الْمُشْتَقَّةُ',
    title: {
      pashto: 'مشتق اسماء (اسم فاعل، اسم مفعول او نور)',
      urdu: 'اسماء مشتقہ اور ان کے اوزان',
      english: 'Derived Nouns (Participles, Instruments & Locatives)'
    },
    description: {
      pashto: 'د اسم فاعل، مفعول، ظرف، آله او تفضیل جوړولو طریقه',
      urdu: 'اسم فاعل، اسم مفعول، اسم ظرف، اسم آلہ اور اسم تفضیل کے اوزان',
      english: 'Active and passive participles, nouns of place, time, and instrument'
    },
    iconName: 'GitMerge',
    rulesCount: 3
  },
  {
    id: 'taleelat',
    category: 'sarf',
    arabicTitle: 'قَوَاعِدُ التَّعْلِيلِ وَالإِعْلَالِ',
    title: {
      pashto: 'د تعلیلاتو او حرف علت بدلېدو مهم قوانین',
      urdu: 'تعلیلات اور اعلال کے اہم ترین قواعد',
      english: 'Morphophonemic Rules (Ta\'leel & Weak Letters)'
    },
    description: {
      pashto: 'د واو او یاء الف ته اوښتل، حذف کېدل او ساکنېدل',
      urdu: 'واؤ اور یاء کے الف میں بدلنے، گرنے اور تسکین کے قواعد',
      english: 'Phonological transformation rules governing weak radical verbs'
    },
    iconName: 'Sparkles',
    rulesCount: 3
  }
];

export const sarfRules: GrammarRule[] = [
  {
    id: 'sarf_definition',
    category: 'sarf',
    topicId: 'intro_sarf',
    arabicTitle: 'تَعْرِيفُ عِلْمِ الصَّرْفِ وَمَوْضُوعُهُ وَغَايَتُهُ',
    title: {
      pashto: 'د صرف علم تعریف، موضوع او غرض',
      urdu: 'علم الصرف کی تعریف، موضوع اور غرض و غایت',
      english: 'Definition, Subject Matter, and Purpose of Ilm-e-Sarf'
    },
    summary: {
      pashto: 'صرف هغه علم دی چې په وسیله یې د کلمو جوړښت او د یوې مادې څخه بېلابېل صیغې جوړول زده کېږي.',
      urdu: 'علم الصرف وہ علم ہے جس سے صیغوں کی پہچان اور ایک کلمے سے مختلف معنی حاصل کرنے کے لیے مختلف صیغے بنانے کے قواعد معلوم ہوں۔',
      english: 'Ilm-e-Sarf is the science of Arabic morphology through which one learns word structure and how to derive various forms from a single root.'
    },
    definition: {
      pashto: 'صرف په لغت کې بدلولو او اړولو ته وایي. په اصطلاح کې: هغه علم دی چې په هغه کې د کلمې د بدلون او جوړښت احکام بیانېږي تر څو انسان په کلام کې له لفظي تېروتنې څخه وژغورل شي.',
      urdu: 'صرف لغت میں پھیرنے کو کہتے ہیں۔ اصطلاح میں: وہ علم ہے جس کے ذریعے ایک اصل (مصدر یا مادہ) کو مختلف صورتوں میں ڈھال کر مطلوبہ معانی حاصل کیے جائیں اور کلمہ سازی میں غلطی سے حفاظت ہو۔',
      english: 'Lexically, Sarf means change, shifting, or inflection. Terminologically, it is the systematic linguistic science that studies the structural variations of Arabic words, their internal vowel changes, root derivations, and morphological transformations.'
    },
    detailedRules: [
      {
        pashto: 'د صرف علم موضوع: هغه معرب اسماء او متصرف افعال دي چې بېلابېلو بڼو ته اوړي.',
        urdu: 'علم الصرف کا موضوع: معرب اسماء اور متصرف افعال ہیں جن میں تغیر اور گردان جاری ہوتی ہے۔',
        english: 'Subject Matter (Mawdoo\'): Declinable Arabic nouns (Asma Mu\'raba) and inflecting verbs (Af\'al Mutasarrifa).'
      },
      {
        pashto: 'غرض او ګټه: په لفظي جوړښت او د صیغې په سم تلفظ کې له غلطۍ څخه د ژبې ساتنه او د قرآن او حدیث د کلمو سمه پېژندنه ده.',
        urdu: 'غرض و غایت: صیغوں کو بنانے اور پڑھنے میں صوتی و لفظی غلطی سے زبان کو بچانا اور قرآنی کلمات کے دقیق معانی سمجھنا ہے۔',
        english: 'Benefit (Gharad): Protecting the tongue from phonological errors and properly grasping the precise meanings of divine revelation and prophetic traditions.'
      }
    ],
    examples: [
      {
        arabic: 'نَصَرَ (ماضي) ➔ يَنْصُرُ (مضارع) ➔ اُنْصُرْ (أمر) ➔ نَاصِرٌ (فاعل) ➔ مَنْصُورٌ (مفعول)',
        pashtoTranslation: 'له ن-ص-ر مادې څخه: هغه مرسته وکړه، هغه مرسته کوي، ته مرسته وکړه، مرسته کوونکی، هغه چې مرسته ورسره شوې ده.',
        urduTranslation: 'ایک مادہ ن-ص-ر سے: مدد کی اس نے، مدد کرتا ہے وہ، مدد کر تو، مدد کرنے والا، جس کی مدد کی گئی۔',
        englishTranslation: 'From the root N-S-R: He helped -> He helps -> Help! -> Helper -> One who is helped.',
        analysis: {
          pashto: 'ګورئ چې څرنګه د صرف د قوانینو له لارې له یوې مادې څخه بېلابېل صیغې او مفاهیم جوړ شول.',
          urdu: 'دیکھیے کہ کس طرح ایک ہی اصل سے صیغہ سازی کے ذریعے مختلف زمانے اور مشتقات وجود میں آئے۔',
          english: 'Demonstrates how a single triconsonantal root branches into multiple aspects and noun classes.'
        }
      }
    ],
    mnemonicOrNote: {
      pashto: 'یادښت: مشهور متل دی: "الصَّرْفُ أُمُّ الْعُلُومِ وَالنَّحْوُ أَبُوهَا" (صرف د ټولو علومو مور ده او نحو د ټولو علومو پلار دی).',
      urdu: 'مشہور مقولہ: "الصرف ام العلوم والنحو ابوها" (صرف تمام علوم کی ماں ہے اور نحو ان کا باپ ہے)۔',
      english: 'Classical Adage: "Al-Sarfu Ummu al-\'Uloom wa al-Nahwu Abooha" — Morphology is the mother of all sciences, and Syntax is their father.'
    },
    tags: ['تعریف', 'موضوع', 'غایت', 'بنسټ']
  },
  {
    id: 'sarf_kalimah',
    category: 'sarf',
    topicId: 'intro_sarf',
    arabicTitle: 'أَقْسَامُ الْكَلِمَةِ: الاسْمُ وَالْفِعْلُ وَالْحَرْفُ',
    title: {
      pashto: 'د کلمې درې قسمونه: اسم، فعل او حرف',
      urdu: 'کلمہ کی تین اقسام: اسم، فعل اور حرف',
      english: 'The Three Parts of Speech: Noun, Verb, and Particle'
    },
    summary: {
      pashto: 'په عربي ژبه کې هر با معنی لفظ ته کلمه ویل کېږي او هغه یوازې په درې ډوله ده: اسم، فعل او حرف.',
      urdu: 'عربی زبان میں بامعنی مفرد لفظ کو کلمہ کہتے ہیں اور اس کی تین قسمیں ہیں: اسم، فعل اور حرف۔',
      english: 'Every single meaningful word in Arabic belongs to one of three exhaustive categories: Ism, Fe\'l, or Harf.'
    },
    definition: {
      pashto: '۱. اسم: هغه کلمه ده چې په خپلواکه توګه معنی لري او له زمانې (تېر، اوس، راتلونکی) سره تړلې نه وي. ۲. فعل: هغه کلمه ده چې مستقل معنی ولري او له دریو زمانو څخه له یوې سره تړلې وي. ۳. حرف: هغه کلمه ده چې خپله مستقل معنی د بلې کلمې له ملګرتیا پرته نه ښکاره کوي.',
      urdu: '۱. اسم: وہ کلمہ جو اپنے معنی پر خود دلالت کرے اور اس میں تینوں زمانوں (ماضی، حال، استقبال) میں سے کوئی زمانہ نہ پایا جائے۔ ۲. فعل: وہ کلمہ جو اپنے معنی پر دلالت کرے اور اس میں تینوں زمانوں میں سے کوئی زمانہ موجود ہو۔ ۳. حرف: وہ کلمہ جو دوسرے کلمے کے ملے بغیر اپنے پورے معنی ظاہر نہ کر سکے۔',
      english: '1. Ism (Noun/Substantive): A word pointing to independent meaning without being tied to time. 2. Fe\'l (Verb): A word pointing to independent action intrinsically linked to past, present, or future tense. 3. Harf (Particle): A word that connects words and reveals its full function only in context.'
    },
    detailedRules: [
      {
        pashto: 'د اسم نښې: د الف لام (ال) قبلول، تنوین قبلول، حرف جر قبلول، مضاف کېدل، مسند الیه کېدل.',
        urdu: 'اسم کی علامات: شروع میں الف لام کا آنا، آخر میں تنوین کا آنا، حرفِ جر کا داخل ہونا، مضاف بننا، مسند الیہ ہونا۔',
        english: 'Signs of an Ism: Accepting the definite article "al-", accepting tanween, being preceded by a preposition, or serving as a subject.'
      },
      {
        pashto: 'د فعل نښې: د "قَدْ"، "سَوْفَ"، "سـ" داخلېدل، د جازمه او ناصبه حروفو راتلل، او د تاء تأنیث ساکنه قبلول (لکه: قَالَتْ).',
        urdu: 'فعل کی علامات: قد، سین، سوف کا داخل ہونا، حروفِ جازمہ یا ناصبہ کا آنا، تائے تانیث ساکنہ کا ملنا (جیسے: کَتَبَتْ)۔',
        english: 'Signs of a Fe\'l: Preceded by Qad, Sa-, Sawfa, accepting the silent feminine Ta (e.g. Qalat), or accepting jussive markers.'
      }
    ],
    examples: [
      {
        arabic: 'كَتَبَ زَيْدٌ بِالْقَلَمِ',
        pashtoTranslation: 'زید په قلم سره ولیکل.',
        urduTranslation: 'زید نے قلم سے لکھا۔',
        englishTranslation: 'Zayd wrote with the pen.',
        analysis: {
          pashto: 'كَتَبَ فعل دی، زَيْدٌ او الْقَلَمِ اسمونه دي، او د "بـ" توری حرف دی.',
          urdu: 'كَتَبَ فعل ہے، زَيْدٌ اور الْقَلَمِ اسم ہیں، اور "بـ" حرف ہے۔',
          english: 'Kataba is the verb (Fe\'l), Zayd and al-Qalam are nouns (Ism), and Bi- is the preposition particle (Harf).'
        }
      }
    ],
    tags: ['کلمہ', 'اسم', 'فعل', 'حرف']
  },
  {
    id: 'sarf_awzan',
    category: 'sarf',
    topicId: 'intro_sarf',
    arabicTitle: 'الْمِيزَانُ الصَّرْفِيُّ: الْفَاءُ وَالْعَيْنُ وَاللَّامُ',
    title: {
      pashto: 'د صرف تله (ميزان صرفي): ف - ع - ل',
      urdu: 'میزان صرفی: فاء، عین اور لام کلمہ',
      english: 'The Morphological Balance Scale: Fa, \'Ain, and Lam'
    },
    summary: {
      pashto: 'صرفیانو د عربي کلمو د وزن معلومولو لپاره د "ف ع ل" کلمې تله ټاکلې ده.',
      urdu: 'علمائے صرف نے عربی الفاظ کے اوزان اور حروفِ اصلیہ و زائدہ کو پرکھنے کے لیے "ف ع ل" کا ترازو مقرر کیا ہے۔',
      english: 'Classical grammarians devised the tripartite root paradigm F-\'A-L to measure Arabic root letters and morphological weights.'
    },
    definition: {
      pashto: 'لومړني اصلي حرف ته "فاء کلمه"، دویم ته "عین کلمه" او دریم ته "لام کلمه" ویل کېږي. که یو توری زیات شي، په وزن کې هم زیاتېږي.',
      urdu: 'پہلے اصلی حرف کے مقابلے میں آنے والے کو "فاء کلمہ"، دوسرے کو "عین کلمہ" اور تیسرے کو "لام کلمہ" کہتے ہیں۔ زائد حرف وزن میں ویسا ہی ظاہر کیا جاتا ہے۔',
      english: 'The first radical corresponds to the Fa-Kalimah, the second radical to the \'Ain-Kalimah, and the third to the Lam-Kalimah. Any affixes or augmented letters are mapped proportionally.'
    },
    detailedRules: [
      {
        pashto: 'اصلي حروف: هغه حروف چې په وزن کې د ف، ع، ل په مقابل کې راځي.',
        urdu: 'حروفِ اصلیہ: وہ حروف جو وزن میں فاء، عین، لام کے بالمقابل آتے ہیں۔',
        english: 'Radical letters (Huruf Asliyyah): Those matching the F-\'A-L template in the base pattern.'
      },
      {
        pashto: 'زائد حروف لس دي، چې په "سَأَلْتُمُونِيهَا" یا "الْيَوْمَ تَنْسَاهُ" کې راټول شوي دي.',
        urdu: 'حروفِ زائدہ دس ہیں جن کا مجموعہ "سَأَلْتُمُونِيْهَا" یا "الْيَوْمَ تَنْسَاهُ" ہے۔',
        english: 'The ten augmentative letters are collected in the mnemonic: "Sa\'altumooniha" (س أ ل ت م و ن ي ه ا).'
      }
    ],
    examples: [
      {
        arabic: 'نَصَرَ عَلَى وَزْنِ فَعَلَ | ضَارِبٌ عَلَى وَزْنِ فَاعِلٌ | اِسْتَخْرَجَ عَلَى وَزْنِ اِسْتَفْعَلَ',
        pashtoTranslation: 'نصر د فعل په وزن دی، ضارب د فاعل په وزن دی، استخرج د استَفعل په وزن دی.',
        urduTranslation: 'نَصَرَ کا وزن فَعَلَ ہے، ضَارِبٌ کا وزن فَاعِلٌ ہے، اِسْتَخْرَجَ کا وزن اِسْتَفْعَلَ ہے۔',
        englishTranslation: 'Nasara matches Fa\'ala; Daarib matches Faa\'il; Istakhraja matches Istaf\'ala.',
        analysis: {
          pashto: 'په "استخرج" کې خ-ر-ج اصلي حروف دي او ا، س، ت زائد دي.',
          urdu: 'اِسْتَخْرَجَ میں خ، ر، ج اصلی حروف ہیں اور الف، سین، تاء زائد ہیں۔',
          english: 'In Istakhraja, the root is Kh-R-J, augmented with the prefix I-S-T.'
        }
      }
    ],
    tags: ['میزان', 'تله', 'اوزان']
  },
  {
    id: 'bab_nasara',
    category: 'sarf',
    topicId: 'abwaab_mujarrad',
    arabicTitle: 'بَابُ نَصَرَ - يَنْصُرُ (فَعَلَ - يَفْعُلُ) [ن]',
    title: {
      pashto: 'لومړی باب: نَصَرَ - يَنْصُرُ (فَعَلَ - يَفْعُلُ)',
      urdu: 'پہلا باب: نَصَرَ - يَنْصُرُ (فَعَلَ - يَفْعُلُ) [علامت: ن]',
      english: 'Bab 1: Nasara - Yansuru (Fa\'ala - Yaf\'ulu)'
    },
    summary: {
      pashto: 'په ماضی کې د عین کلمې زبر (فتحه) او په مضارع کې د عین کلمې پېښ (ضمه) وي.',
      urdu: 'ماضی میں عین کلمہ پر زبر (فتحہ) اور مضارع میں عین کلمہ پر پیش (ضمہ) ہوتا ہے۔',
      english: 'Characterized by Fathah on the medial root in the past tense, and Dammah in the present tense.'
    },
    definition: {
      pashto: 'دا باب د ثلاثي مجرد له خورا مشهورو ابوابو څخه دی چې علامت یې [ن] دی. په ماضي کې فَعَلَ او په مضارع کې يَفْعُلُ راځي.',
      urdu: 'یہ ثلاثی مجرد کا سب سے مشہور اور کثیر الاستعمال باب ہے۔ اس کی پہچان یہ ہے کہ ماضی مفتوح العین اور مضارع مضموم العین ہوتا ہے۔',
      english: 'This is the most frequent and celebrated chapter of Form I triliteral verbs, conventionally abbreviated with the letter Noon [ن].'
    },
    detailedRules: [
      {
        pashto: 'نښه: ماضي یې فَعَلَ (نَصَرَ) او مضارع یې يَفْعُلُ (يَنْصُرُ) ده.',
        urdu: 'علامت: ماضی "فَعَلَ" اور مضارع "يَفْعُلُ"۔ صیغہ امر: اُنْصُرْ (پیش کے ساتھ)۔',
        english: 'Morphological Signature: Past tense Fa\'ala, Present tense Yaf\'ulu. Imperative: Unsur.'
      },
      {
        pashto: 'ځانګړنه: ډېری وختونه متعدي (مفعول غوښتونکی) وي، لکه نَصَرَ (مرسته یې وکړه)، خَلَقَ (پیدا یې کړ)، کَتَبَ (ویې لیکل).',
        urdu: 'اکثریت افعال اس باب میں متعدی ہوتے ہیں جیسے کَتَبَ (لکھا)، خَلَقَ (پیدا کیا)، طَلَبَ (مانگا)۔',
        english: 'Predominantly transitive verbs such as Kataba (wrote), Khalaqa (created), Talaba (sought).'
      }
    ],
    examples: [
      {
        arabic: 'خَلَقَ اللّٰهُ السَّمَاوَاتِ وَالأَرْضَ (خَلَقَ - يَخْلُقُ)',
        pashtoTranslation: 'الله تعالی اسمانونه او ځمکه پیدا کړل.',
        urduTranslation: 'اللہ نے آسمانوں اور زمین کو پیدا فرمایا۔',
        englishTranslation: 'Allah created the heavens and the earth.',
        analysis: {
          pashto: 'خَلَقَ له نَصَرَ يَنْصُرُ باب څخه دی: خَلَقَ - يَخْلُقُ.',
          urdu: 'خَلَقَ بابِ نصر ینصر سے ہے (خَلَقَ - يَخْلُقُ)۔',
          english: 'Khalaqa follows the pattern of Nasara - Yansuru.'
        }
      }
    ],
    mnemonicOrNote: {
      pashto: 'د ابوابو یادولو لپاره مشهور شعر: "فَتْحُ ضَمٍّ، فَتْحُ كَسْرٍ، فَتْحَتَانْ ... كَسْرُ فَتْحٍ، ضَمُّ ضَمٍّ، كَسْرَتَانْ"',
      urdu: 'ابواب کے حرکات یاد رکھنے کا مشہور منظوم قاعدہ: فتحُ ضمٍّ (نصر)، فتحُ کسرٍ (ضرب)، فتحتان (فتح)، کسرُ فتحٍ (سمع)، ضمُّ ضمٍّ (کرم)، کسرَتان (حسب)۔',
      english: 'Classical Mnemonic verse: "Fat-hu Dammin, Fat-hu Kasrin, Fat-hataan... Kasru Fat-hin, Dammu Dammin, Kasrataan."'
    },
    tags: ['نصر', 'ثلاثی مجرد', 'باب ن']
  },
  {
    id: 'bab_daraba',
    category: 'sarf',
    topicId: 'abwaab_mujarrad',
    arabicTitle: 'بَابُ ضَرَبَ - يَضْرِبُ (فَعَلَ - يَفْعِلُ) [ض]',
    title: {
      pashto: 'دویم باب: ضَرَبَ - يَضْرِبُ (فَعَلَ - يَفْعِلُ)',
      urdu: 'دوسرا باب: ضَرَبَ - يَضْرِبُ (فَعَلَ - يَفْعِلُ) [علامت: ض]',
      english: 'Bab 2: Daraba - Yadribu (Fa\'ala - Yaf\'ilu)'
    },
    summary: {
      pashto: 'په ماضی کې د عین کلمې زبر او په مضارع کې د عین کلمې زیر (کسره) وي.',
      urdu: 'ماضی میں عین کلمہ پر زبر (فتحہ) اور مضارع میں زیر (کسرہ) ہوتا ہے۔',
      english: 'Exhibits Fathah on the medial root in the past tense and Kasrah in the present tense.'
    },
    definition: {
      pashto: 'دویم مشهور باب دی چې نښه یې [ض] ده. ماضي یې فَعَلَ او مضارع یې يَفْعِلُ وي، لکه ضَرَبَ يَضْرِبُ، جَلَسَ يَجْلِسُ، غَفَرَ يَغْفِرُ.',
      urdu: 'یہ دوسرا کثیر الاستعمال باب ہے جس کی علامت [ض] ہے۔ ماضی مفتوح العین اور مضارع مکسور العین ہوتا ہے۔',
      english: 'The second major chapter, symbolized by the letter Daad [ض]. In the imperative it takes Kasrah: Idrib.'
    },
    detailedRules: [
      {
        pashto: 'نښه: فَعَلَ - يَفْعِلُ. امر یې "اِضْرِبْ" په زیر سره راځي.',
        urdu: 'پہچان: ماضی "فَعَلَ" اور مضارع "يَفْعِلُ"۔ امر: "اِضْرِبْ" مکسور الہمزہ ہوتا ہے۔',
        english: 'Pattern: Fa\'ala - Yaf\'ilu. The imperative prefix Hamzah receives a Kasrah (Idrib).'
      },
      {
        pashto: 'ډول: هم متعدي راځي (لکه ضَرَبَ، غَفَرَ) او هم لازم راځي (لکه جَلَسَ - کېناست، رَجَعَ - بېرته راستون شو).',
        urdu: 'یہ باب متعدی بھی بکثرت آتا ہے (جیسے غَفَرَ، عَرَفَ) اور لازم بھی (جیسے جَلَسَ، رَجَعَ)۔',
        english: 'Both transitive (e.g. Ghafara - forgave) and intransitive (e.g. Jalasa - sat down).'
      }
    ],
    examples: [
      {
        arabic: 'غَفَرَ اللّٰهُ لِلْمُؤْمِنِينَ (غَفَرَ - يَغْفِرُ)',
        pashtoTranslation: 'الله تعالی مؤمنانو ته بښنه وکړه.',
        urduTranslation: 'اللہ نے ایمان والوں کی بخشش فرمائی۔',
        englishTranslation: 'Allah forgave the believers.',
        analysis: {
          pashto: 'غَفَرَ يَغْفِرُ د ضرب باب صیغه ده.',
          urdu: 'غَفَرَ - يَغْفِرُ بابِ ضرب یضرب سے ہے۔',
          english: 'Ghafara - Yaghfiru follows the Daraba - Yadribu conjugation.'
        }
      }
    ],
    tags: ['ضرب', 'ثلاثی مجرد', 'باب ض']
  },
  {
    id: 'bab_samia',
    category: 'sarf',
    topicId: 'abwaab_mujarrad',
    arabicTitle: 'بَابُ سَمِعَ - يَسْمَعُ (فَعِلَ - يَفْعَلُ) [س]',
    title: {
      pashto: 'دریم باب: سَمِعَ - يَسْمَعُ (فَعِلَ - يَفْعَلُ)',
      urdu: 'تیسرا باب: سَمِعَ - يَسْمَعُ (فَعِلَ - يَفْعَلُ) [علامت: س]',
      english: 'Bab 3: Sami\'a - Yasma\'u (Fa\'ila - Yaf\'alu)'
    },
    summary: {
      pashto: 'په ماضی کې د عین کلمې زیر او په مضارع کې د عین کلمې زبر وي.',
      urdu: 'ماضی میں عین کلمہ پر زیر (کسرہ) اور مضارع میں زبر (فتحہ) ہوتا ہے۔',
      english: 'Exhibits Kasrah on the medial root in the past tense and Fathah in the present tense.'
    },
    definition: {
      pashto: 'د دې باب نښه [س] ده. ماضي فَعِلَ او مضارع يَفْعَلُ وي. لکه سَمِعَ يَسْمَعُ، عَلِمَ يَعْلَمُ، فَهِمَ يَفْهَمُ، شَرِبَ يَشْرَبُ.',
      urdu: 'اس باب کی علامت [س] ہے۔ ماضی مکسور العین اور مضارع مفتوح العین ہوتا ہے۔ جیسے: عَلِمَ يَعْلَمُ، فَهِمَ يَفْهَمُ۔',
      english: 'Symbolized by Seen [س]. Commonly denotes senses, knowledge, and inner emotional or mental states.'
    },
    detailedRules: [
      {
        pashto: 'نښه: فَعِلَ - يَفْعَلُ. امر یې: "اِسْمَعْ" په زیر او زبر سره.',
        urdu: 'پہچان: فَعِلَ - يَفْعَلُ۔ امر: اِسْمَعْ۔',
        english: 'Pattern: Fa\'ila - Yaf\'alu. Imperative: Isma\'.'
      },
      {
        pashto: 'ځانګړنه: زیاتره د پوهې، حواسو او احساساتو لپاره راځي، لکه: عَلِمَ (پوه شو)، سَمِعَ (واورېدل)، رَحِمَ (رحم یې وکړ).',
        urdu: 'یہ باب ادراک، باطنی کیفیات اور حواس کے لیے بہت عام ہے، جیسے عَلِمَ (جانا)، رَحِمَ (رحم کیا)۔',
        english: 'Often associates with internal cognition, sensory perception, and compassion.'
      }
    ],
    examples: [
      {
        arabic: 'سَمِعَ اللّٰهُ لِمَنْ حَمِدَهُ (سَمِعَ - يَسْمَعُ)',
        pashtoTranslation: 'الله د هغه چا خبره واورېده چې د هغه ستاینه یې وکړه.',
        urduTranslation: 'اللہ نے اس بندے کی سن لی جس نے اس کی تعریف کی۔',
        englishTranslation: 'Allah heard the one who praised Him.',
        analysis: {
          pashto: 'سَمِعَ د سمع باب صیغه ده.',
          urdu: 'سَمِعَ بابِ سمع یسمع کا فعل ماضی ہے۔',
          english: 'Sami\'a is a Form I past verb belonging to Bab Sami\'a.'
        }
      }
    ],
    tags: ['سمع', 'ثلاثی مجرد', 'باب س']
  },
  {
    id: 'bab_fataha',
    category: 'sarf',
    topicId: 'abwaab_mujarrad',
    arabicTitle: 'بَابُ فَتَحَ - يَفْتَحُ (فَعَلَ - يَفْعَلُ) [ف]',
    title: {
      pashto: 'څلورم باب: فَتَحَ - يَفْتَحُ (فَعَلَ - يَفْعَلُ)',
      urdu: 'چوتھا باب: فَتَحَ - يَفْتَحُ (فَعَلَ - يَفْعَلُ) [علامت: ف]',
      english: 'Bab 4: Fataha - Yaftahu (Fa\'ala - Yaf\'alu)'
    },
    summary: {
      pashto: 'په ماضی او مضارع دواړو کې د عین کلمې زبر (فتحه) وي او عین یا لام کلمه باید د حلق توری وي.',
      urdu: 'ماضی اور مضارع دونوں میں عین کلمہ پر زبر (فتحہ) ہوتا ہے اور عین یا لام کلمہ میں حروفِ حلقی کا ہونا لازمی شرط ہے۔',
      english: 'Features Fathah in both past and present tenses; obligatorily requires a guttural letter in the root.'
    },
    definition: {
      pashto: 'د دې باب نښه [ف] ده. قاعده: په دې باب کې باید عین کلمه یا لام کلمه د حلق له شپږو حروفو (ء، هـ، ع، ح، غ، خ) څخه یو وي.',
      urdu: 'اس باب کی علامت [ف] ہے۔ خاص قاعدہ: اس باب میں آنے کے لیے ضروری ہے کہ عین کلمہ یا لام کلمہ حروفِ حلقی (ء، ہ، ع، ح، غ، خ) میں سے ہو۔',
      english: 'Abbreviated [ف]. Strict phonological rule: Either the second or third root radical MUST be a guttural consonant (Hamzah, Haa, \'Ain, Haa, Ghayn, Khaa).'
    },
    detailedRules: [
      {
        pashto: 'د حلق حروف شپږ دي: همزه (ء)، هاء (هـ)، عین (ع)، حاء (ح)، غین (غ)، خاء (خ).',
        urdu: 'حروفِ حلقی چھ ہیں: ہمزہ، ہاء، عین، حاء، غین اور خاء۔',
        english: 'The 6 throat letters: ء, هـ, ع, ح, غ, خ.'
      },
      {
        pashto: 'مثالونه: فَتَحَ يَفْتَحُ (ح توری لام دی)، قَرَأَ يَقْرَأُ (ء لام دی)، جَعَلَ يَجْعَلُ (ع عین دی)، ذَهَبَ يَذْهَبُ (هـ عین دی).',
        urdu: 'مثالیں: فَتَحَ يَفْتَحُ (ح لام ہے)، قَرَأَ يَقْرَأُ (ء لام ہے)، ذَهَبَ يَذْهَبُ (ہ عین ہے)۔',
        english: 'Examples: Fataha (Haa is 3rd radical), Qara\'a (Hamzah is 3rd radical), Zahaba (Haa is 2nd radical).'
      }
    ],
    examples: [
      {
        arabic: 'إِذَا جَاءَ نَصْرُ اللّٰهِ وَالْفَتْحُ | فَتَحْنَا لَكَ فَتْحًا مُبِينًا',
        pashtoTranslation: 'موږ تا ته ښکاره بریا درکړه.',
        urduTranslation: 'بے شک ہم نے آپ کو واضح فتح عطا فرمائی۔',
        englishTranslation: 'Indeed We granted you a manifest victory.',
        analysis: {
          pashto: 'فَتَحَ د فَتَحَ يَفْتَحُ باب ماضي ده.',
          urdu: 'فَتَحَ باب فتح یفتح سے ہے۔',
          english: 'Fataha exemplifies Bab 4 with guttural Haa.'
        }
      }
    ],
    tags: ['فتح', 'ثلاثی مجرد', 'حروف حلقی']
  },
  {
    id: 'bab_hasiba',
    category: 'sarf',
    topicId: 'abwaab_mujarrad',
    arabicTitle: 'بَابُ حَسِبَ - يَحْسِبُ (فَعِلَ - يَفْعِلُ) [ح]',
    title: {
      pashto: 'پنځم باب: حَسِبَ - يَحْسِبُ (فَعِلَ - يَفْعِلُ)',
      urdu: 'پانچواں باب: حَسِبَ - يَحْسِبُ (فَعِلَ - يَفْعِلُ) [علامت: ح]',
      english: 'Bab 5: Hasiba - Yahsibu (Fa\'ila - Yaf\'ilu)'
    },
    summary: {
      pashto: 'په ماضی او مضارع دواړو کې د عین کلمې زیر (کسره) وي. دا باب په عربي کې ډېر لږ راځي.',
      urdu: 'ماضی اور مضارع دونوں میں عین کلمہ پر زیر (کسرہ) ہوتا ہے۔ یہ باب کلامِ عرب میں بہت قلیل الاستعمال ہے۔',
      english: 'Features Kasrah on the medial root in both past and present tenses; the rarest of the six chapters.'
    },
    definition: {
      pashto: 'د دې باب نښه [ح] ده. دا باب ډېر کم پیدا کېږي، لکه: حَسِبَ يَحْسِبُ (ګمان یې وکړ)، وَرِثَ يَرِثُ (وارث شو)، وَلِيَ يَلِي (نږدې شو يا واکمن شو).',
      urdu: 'اس باب کی علامت [ح] ہے۔ عربی زبان میں اس باب سے بہت محدود افعال آتے ہیں، جیسے حَسِبَ يَحْسِبُ (گمان کرنا)، وَرِثَ يَرِثُ (وارث بننا)۔',
      english: 'Abbreviated [ح]. Rare in occurrence. Notable examples include Hasiba (to reckon) and Waritha (to inherit).'
    },
    detailedRules: [
      {
        pashto: 'نښه: فَعِلَ - يَفْعِلُ. کسرتان (دوه زیره).',
        urdu: 'پہچان: فَعِلَ - يَفْعِلُ۔ دونوں زمانوں میں عین کلمہ مکسور ہوتا ہے۔',
        english: 'Pattern: Fa\'ila - Yaf\'ilu ("Kasrataan").'
      }
    ],
    examples: [
      {
        arabic: 'أَمْ حَسِبْتُمْ أَنْ تَدْخُلُوا الْجَنَّةَ',
        pashtoTranslation: 'ایا تاسو داسې ګمان کړی چې جنت ته به ننوځئ؟',
        urduTranslation: 'کیا تم نے یہ گمان کر رکھا ہے کہ تم یونہی جنت میں داخل ہو جاؤ گے؟',
        englishTranslation: 'Or do you reckon that you will enter Paradise?',
        analysis: {
          pashto: 'حَسِبْتُمْ له حَسِبَ يَحْسِبُ باب څخه دی.',
          urdu: 'حَسِبْتُمْ باب حسب یحسب سے ہے۔',
          english: 'Hasibtum is conjugated from Bab Hasiba.'
        }
      }
    ],
    tags: ['حسب', 'ثلاثی مجرد', 'کسرتان']
  },
  {
    id: 'bab_karuma',
    category: 'sarf',
    topicId: 'abwaab_mujarrad',
    arabicTitle: 'بَابُ كَرُمَ - يَكْرُمُ (فَعُلَ - يَفْعُلُ) [ك]',
    title: {
      pashto: 'شپږم باب: كَرُمَ - يَكْرُمُ (فَعُلَ - يَفْعُلُ)',
      urdu: 'چھٹا باب: كَرُمَ - يَكْرُمُ (فَعُلَ - يَفْعُلُ) [علامت: ک]',
      english: 'Bab 6: Karuma - Yakrumu (Fa\'ula - Yaf\'ulu)'
    },
    summary: {
      pashto: 'په ماضی او مضارع دواړو کې د عین کلمې پېښ (ضمه) وي او تل لازمي وي (مفعول نه غواړي).',
      urdu: 'ماضی اور مضارع دونوں میں عین کلمہ پر پیش (ضمہ) ہوتا ہے اور اس کے تمام افعال ہمیشہ لازم ہوتے ہیں۔',
      english: 'Features Dammah on the medial root in both tenses; entirely composed of intransitive stative verbs.'
    },
    definition: {
      pashto: 'د دې باب نښه [ك] ده. ځانګړنه: دا باب یوازې د انسان د ذاتي او طبیعي صفتونو او شرافت ښودلو لپاره راځي او تل لازمي وي.',
      urdu: 'اس باب کی علامت [ک] ہے۔ یہ باب طبعی اوصاف، خصلتوں اور ذاتی شرف کو ظاہر کرنے کے لیے مخصوص ہے اور ہمیشہ لازم ہوتا ہے (کبھی متعدی نہیں ہوتا)۔',
      english: 'Denotes intrinsic virtues, noble dispositions, and permanent innate qualities. Inherently intransitive (Laazim).'
    },
    detailedRules: [
      {
        pashto: 'نښه: فَعُلَ - يَكْرُمُ. ضَمُّ ضَمٍّ (دوه پېښونه).',
        urdu: 'پہچان: فَعُلَ - يَفْعُلُ (ضمُّ ضمٍّ)۔ امر: اُكْرُمْ۔',
        english: 'Pattern: Fa\'ula - Yaf\'ulu ("Dammu Dammin"). Imperative: Ukrum.'
      },
      {
        pashto: 'مثالونه: كَرُمَ يَكْرُمُ (سخي او شریف شو)، حَسُنَ يَحْسُنُ (ښایسته شو)، شَرُفَ يَشْرُفُ (عزتمند شو)، قَرُبَ يَقْرُبُ (نږدې شو).',
        urdu: 'مثالیں: كَرُمَ (شریف ہوا)، حَسُنَ (خوبصورت ہوا)، شَرُفَ (باوقار ہوا)، جَبُنَ (بزدل ہوا)۔',
        english: 'Examples: Karuma (became noble), Hasuna (became handsome), Sharufa (became dignified).'
      }
    ],
    examples: [
      {
        arabic: 'حَسُنَ أُولَئِكَ رَفِيقًا (حَسُنَ - يَحْسُنُ)',
        pashtoTranslation: 'او هغه څومره ښه ملګري دي!',
        urduTranslation: 'اور وہ کتنے ہی اچھے ساتھی ہیں!',
        englishTranslation: 'And how excellent are those as companions!',
        analysis: {
          pashto: 'حَسُنَ د كَرُمَ يَكْرُمُ له باب څخه دی او لازم دی.',
          urdu: 'حَسُنَ بابِ کرم یکرم سے فعلِ لازم ہے۔',
          english: 'Hasuna is an intransitive stative verb from Bab Karuma.'
        }
      }
    ],
    tags: ['کرم', 'ثلاثی مجرد', 'لازم', 'اوصاف']
  },
  {
    id: 'abwaab_mazeed_overview',
    category: 'sarf',
    topicId: 'abwaab_mazeed',
    arabicTitle: 'أَبْوَابُ الثُّلَاثِيِّ الْمَزِيدِ فِيهِ: التَّعْرِيفُ وَالأَبْوَابُ الرَّئِيسَةُ',
    title: {
      pashto: 'د ثلاثي مزید فیه مشهور اته ابواب او ځانګړنې',
      urdu: 'ثلاثی مزید فیہ کے مشہور آٹھ ابواب اور ان کی خصوصیات',
      english: 'The Derived Verb Forms (Forms II to X) & Semantic Nuances'
    },
    summary: {
      pashto: 'ثلاثي مزید فیه هغه فعل دی چې د اصلي دریو تورو تر څنګ پکې یو، دوه یا درې نور توري زیات شوي وي.',
      urdu: 'ثلاثی مزید فیہ وہ فعل ہے جس میں تین اصلی حروف کے علاوہ ایک، دو یا تین زائد حروف شامل کیے جائیں۔',
      english: 'Derived triliteral verbs augmented by one, two, or three letters to generate modified semantic meanings.'
    },
    definition: {
      pashto: 'دغه ابواب د ژبې د معنی د پراخوالي لپاره کارول کېږي لکه د لازم فعل متعدي کول، مبالغه، د غوښتنې معنی پیدا کول (طلب) او ګډون (مشارکت).',
      urdu: 'یہ ابواب کلام میں معانی کی وسعت پیدا کرنے کے لیے آتے ہیں، جیسے تعدیہ (لازم کو متعدی بنانا)، مبالغہ، طلب اور مشارکت وغیرہ۔',
      english: 'Augmentation serves specific semantic functions: causativity, reflexivity, intensity, reciprocity, and seeking (Talab).'
    },
    detailedRules: [
      {
        pashto: '۱. باب إفعال: أَكْرَمَ - يُكْرِمُ - إِكْرَامًا (د تعدیه لپاره راځي لکه نَزَلَ کوز شو ➔ أَنْزَلَ کوز یې کړ).',
        urdu: '۱. بابِ اِفْعَال: أَكْرَمَ - يُكْرِمُ - إِكْرَامًا (بنیادی خاصیت: تعدیہ، جیسے نَزَلَ اترا ➔ أَنْزَلَ اس نے اتارا)۔',
        english: 'Form IV (If\'aal): Akrama - Yukrimu - Ikraam. Primary function: Causation/transitivity.'
      },
      {
        pashto: '۲. باب تفعيل: فَرَّحَ - يُفَرِّحُ - تَفْرِيحًا / عَلَّمَ - يُعَلِّمُ - تَعْلِيمًا (د کثرت او تدریج لپاره).',
        urdu: '۲. بابِ تَفْعِيل: عَلَّمَ - يُعَلِّمُ - تَعْلِيمًا (بنیادی خاصیت: مبالغہ، تدریج اور تکثیر)۔',
        english: 'Form II (Taf\'eel): \'Allama - Yu\'allimu - Ta\'leem. Primary function: Intensification and gradual teaching.'
      },
      {
        pashto: '۳. باب مفاعلة: جَاهَدَ - يُجَاهِدُ - مُجَاهَدَةً (د دوه اړخیز ګډون/مشارکت لپاره).',
        urdu: '۳. بابِ مُفَاعَلَة: جَاهَدَ - يُجَاهِدُ - جِهَادًا وَمُفَاعَلَةً (بنیادی خاصیت: دو طرفہ مشارکت)۔',
        english: 'Form III (Mufa\'alah): Jaahada - Yujaahidu - Jihaad. Primary function: Reciprocity and mutual engagement.'
      },
      {
        pashto: '۴. باب استفعال: اِسْتَغْفَرَ - يَسْتَغْفِرُ - اِسْتِغْفَارًا (د غوښتنې لپاره لکه د بښنې غوښتنه).',
        urdu: '۴. بابِ اِسْتِفْعَال: اِسْتَغْفَرَ - يَسْتَغْفِرُ - اِسْتِغْفَارًا (بنیادی خاصیت: طلب، جیسے بخشش طلب کرنا)۔',
        english: 'Form X (Istif\'aal): Istaghfara - Yastaghfiru - Istighfaar. Primary function: Seeking, requesting, or considering.'
      }
    ],
    examples: [
      {
        arabic: 'إِنَّا أَنْزَلْنَاهُ فِي لَيْلَةِ الْقَدْرِ (أَنْزَلَ - باب إفعال)',
        pashtoTranslation: 'بېشکه موږ دا (قرآن) د قدر په شپه کې نازل کړ.',
        urduTranslation: 'بے شک ہم نے اسے شبِ قدر میں نازل فرمایا۔',
        englishTranslation: 'Indeed We revealed it in the Night of Decree.',
        analysis: {
          pashto: 'أَنْزَلَ د إفعال باب دی چې متعدي معنی ورکوي.',
          urdu: 'أَنْزَلَ بابِ افعال سے ہے جو نَزَلَ (اترا) کو متعدی (نازل کیا) بناتا ہے۔',
          english: 'Anzala is Form IV derived from Nazala to denote causative revelation.'
        }
      }
    ],
    tags: ['ثلاثی مزید', 'افعال', 'تفعیل', 'استفعال']
  },
  {
    id: 'haft_aqsaam_rules',
    category: 'sarf',
    topicId: 'haft_aqsaam',
    arabicTitle: 'الأَقْسَامُ السَّبْعَةُ (هَفْت أَقْسَام): الصَّحِيحُ وَالْمُعْتَلُّ',
    title: {
      pashto: 'هفت اقسام (د حروفو ډولونه: صحیح، مثال، مضعف، لفیف، ناقص، مهموز، اجوف)',
      urdu: 'ہفت اقسام کے مکمل قواعد اور تعریفات',
      english: 'The Seven Morphological Root Classes (Haft Aqsaam)'
    },
    summary: {
      pashto: 'د اصلي حروفو د سلامتیا او د علت حروفو (و، ا، ي) د شتون له مخې افعال په ۷ ډوله وېشل کېږي.',
      urdu: 'حروفِ اصلیہ کی صحت اور حروفِ علت (واؤ، الف، یاء) کے پائے جانے کے اعتبار سے کلمے کی ۷ قسمیں ہوتی ہیں۔',
      english: 'Root verbs are categorized into 7 classes depending on whether their consonants are sound or contain weak letters (Waw, Alif, Ya).'
    },
    definition: {
      pashto: '۱. صحيح: چې نه پکې د علت توری وي، نه همزه، او نه دوه یو شان توري (لکه: نَصَرَ). ۲. مثال: چې فاء کلمه یې د علت توری وي (لکه: وَعَدَ). ۳. مضعف: چې دوه اصلي توري یې یو شان وي (لکه: مَدَّ). ۴. لفیف: چې دوه د علت توري پکې وي (مقرون لکه طَوَى، یا مفروق لکه وَقَى). ۵. ناقص: چې لام کلمه یې د علت توری وي (لکه: دَعَا، رَمَى). ۶. مهموز: چې یو توری یې همزه وي (لکه: أَكَلَ، سَأَلَ، قَرَأَ). ۷. اجوف: چې عین کلمه یې د علت توری وي (لکه: قَالَ، بَاعَ).',
      urdu: '۱. صحیح: جس کے اصلی حروف میں نہ حرفِ علت ہو، نہ ہمزہ، نہ دو ہم جنس حروف (جیسے: نَصَرَ)۔ ۲. مثال: جس کا فاء کلمہ حرفِ علت ہو (جیسے: وَعَدَ، يَسَرَ)۔ ۳. مضاعف: جس میں دو اصلی حروف ایک جنس کے ہوں (جیسے: مَدَّ اصل میں مَدَدَ تھا)۔ ۴. لفیف: جس میں دو حروفِ علت جمع ہوں (مقرون جیسے: شَوَى، مفروق جیسے: وَقَى)۔ ۵. ناقص: جس کا لام کلمہ حرفِ علت ہو (جیسے: دَعَا، رَمَى)۔ ۶. مہموز: جس کے اصلی حروف میں ہمزہ ہو (مہموز الفاء: أَكَلَ، مہموز العین: سَأَلَ، مہموز اللام: قَرَأَ)۔ ۷. اجوف: جس کا عین کلمہ حرفِ علت ہو (جیسے: قَالَ، بَاعَ)۔',
      english: '1. Saheeh: Completely sound root lacking weak letters, hamzah, or gemination. 2. Mithal: 1st radical is weak (Waw or Ya). 3. Muda\'af: Doubled 2nd and 3rd radicals. 4. Lafif: Contains two weak radicals (Adjacent/Maqroon or Separated/Mafrooq). 5. Naqis: 3rd radical is weak. 6. Mahmuz: Contains a Hamzah. 7. Ajwaf: Hollow verb with 2nd radical weak.'
    },
    detailedRules: [
      {
        pashto: 'مشهور شعر: "صَحِيحٌ اسْتْ وَمِثَالٌ اسْتْ وَمُضَاعَفْ ... لَفِيفٌ وَنَاقِصٌ وَمَهْمُوزٌ وَأَجْوَفْ"',
        urdu: 'یاد رکھنے کا مشہور فارسی شعر: "صحیح است و مثال است و مضاعف / لفیف و ناقص و مہموز و اجوف"۔',
        english: 'Famous classical mnemonic poem reciting all 7 classes in single meter.'
      }
    ],
    examples: [
      {
        arabic: 'قَالَ زَيْدٌ (أَجْوَف) | وَعَدَ الصَّادِقُ (مِثَال) | دَعَا الْمُؤْمِنُ (نَاقِص)',
        pashtoTranslation: 'زید وویل (اجوف) | رښتیني وعده وکړه (مثال) | مؤمن دعا وکړه (ناقص).',
        urduTranslation: 'زید نے کہا (اجوف) | سچے نے وعدہ کیا (مثال) | مومن نے دعا کی (ناقص)۔',
        englishTranslation: 'Zayd said (Hollow) | The truthful promised (Assimilated) | The believer supplicated (Defective).',
        analysis: {
          pashto: 'قَالَ په اصل کې قَوَلَ و، وَعَدَ په فاء کې واو لري، او دَعَا په اصل کې دَعَوَ و.',
          urdu: 'قَالَ اصل میں قَوَلَ تھا، وَعَدَ کے فاء کلمہ میں واؤ ہے، اور دَعَا اصل میں دَعَوَ تھا۔',
          english: 'Demonstrates internal transformations of weak radicals.'
        }
      }
    ],
    tags: ['هفت اقسام', 'صحیح', 'اجوف', 'ناقص', 'مثال']
  },
  {
    id: 'sarf_conjugations_14',
    category: 'sarf',
    topicId: 'haft_aqsaam',
    arabicTitle: 'أَوْزَانُ التَّصْرِيفِ وَالصِّيَغُ الأَرْبَعَ عَشْرَةَ',
    title: {
      pashto: 'د فعل څوارلس (۱۴) صیغې او د هغو پېژندنه',
      urdu: 'فعل کے چودہ (۱۴) صیغے اور گردان کا نظام',
      english: 'The 14 Morphological Conjugation Person Forms'
    },
    summary: {
      pashto: 'په عربي ژبه کې هر فعل ۱۴ صیغې لري: ۶ د غایب لپاره، ۶ د حاضر لپاره او ۲ د متکلم لپاره.',
      urdu: 'عربی زبان میں ہر فعل کی ۱۴ گردانیں ہوتی ہیں: ۶ غائب، ۶ حاضر اور ۲ متکلم۔',
      english: 'Arabic verbs systematically conjugate into 14 distinct person, gender, and number configurations.'
    },
    definition: {
      pashto: 'په عربي کې د نورو ژبو پر خلاف د تثنیې (دوه تنو) صیغه هم شته: مذکر غایب (واحد، تثنیه، جمع)، مؤنث غایب (واحد، تثنیه، جمع)، مذکر حاضر (واحد، تثنیه، جمع)، مؤنث حاضر (واحد، تثنیه، جمع)، او متکلم (واحد او مع الغیر).',
      urdu: 'عربی میں فرد، تثنیہ اور جمع کا امتیاز مرد اور عورت دونوں کے لیے الگ رکھا گیا ہے: ۳ مذکر غائب، ۳ مؤنث غائب، ۳ مذکر حاضر، ۳ مؤنث حاضر، ۱ واحد متکلم اور ۱ جمع متکلم۔',
      english: 'The 14 persons comprise: 3 Masculine 3rd Person, 3 Feminine 3rd Person, 3 Masculine 2nd Person, 3 Feminine 2nd Person, 1 1st Person Singular, and 1 1st Person Plural/Dual.'
    },
    detailedRules: [
      {
        pashto: 'ماضي معروف صیغې: فَعَلَ، فَعَلَا، فَعَلُوا | فَعَلَتْ، فَعَلَتَا، فَعَلْنَ | فَعَلْتَ، فَعَلْتُمَا، فَعَلْتُمْ | فَعَلْتِ، فَعَلْتُمَا، فَعَلْتُنَّ | فَعَلْتُ، فَعَلْنَا.',
        urdu: 'گردانِ ماضی معروف: فَعَلَ، فَعَلَا، فَعَلُوا | فَعَلَتْ، فَعَلَتَا، فَعَلْنَ | فَعَلْتَ، فَعَلْتُمَا، فَعَلْتُمْ | فَعَلْتِ، فَعَلْتُمَا، فَعَلْتُنَّ | فَعَلْتُ، فَعَلْنَا۔',
        english: 'Standard Past Active paradigm: Fa\'ala, Fa\'alaa, Fa\'aloo | Fa\'alat, Fa\'alataa, Fa\'alna | Fa\'alta, Fa\'altumaa, Fa\'altum | Fa\'alti, Fa\'altumaa, Fa\'altunna | Fa\'altu, Fa\'alnaa.'
      },
      {
        pashto: 'مضارع معروف صیغې: يَفْعَلُ، يَفْعَلَانِ، يَفْعَلُونَ | تَفْعَلُ، تَفْعَلَانِ، يَفْعَلْنَ | تَفْعَلُ، تَفْعَلَانِ، تَفْعَلُونَ | تَفْعَلِينَ، تَفْعَلَانِ، تَفْعَلْنَ | أَفْعَلُ، نَفْعَلُ.',
        urdu: 'گردانِ مضارع معروف: يَفْعَلُ، يَفْعَلَانِ، يَفْعَلُونَ | تَفْعَلُ، تَفْعَلَانِ، يَفْعَلْنَ | تَفْعَلُ، تَفْعَلَانِ، تَفْعَلُونَ | تَفْعَلِينَ، تَفْعَلَانِ، تَفْعَلْنَ | أَفْعَلُ، نَفْعَلُ۔',
        english: 'Standard Present Active paradigm: Yaf\'alu, Yaf\'alaani, Yaf\'aloona | Taf\'alu, Taf\'alaani, Yaf\'alna | Taf\'alu, Taf\'alaani, Taf\'aloona | Taf\'aleena, Taf\'alaani, Taf\'alna | Af\'alu, Naf\'alu.'
      }
    ],
    examples: [
      {
        arabic: 'نَصَرُوا (جمع مذكر غائب) | تَنْصُرِينَ (واحد مؤنث حاضر) | نَصَرْنَا (جمع متكلم)',
        pashtoTranslation: 'هغوی ټولو سړو مرسته وکړه | ته یوې ښځې مرسته کوې | موږ ټولو مرسته وکړه.',
        urduTranslation: 'ان سب مردوں نے مدد کی | تو ایک عورت مدد کرتی ہے | ہم سب نے مدد کی۔',
        englishTranslation: 'They (all men) helped | You (one woman) help | We helped.',
        analysis: {
          pashto: 'د ضمیر او علامت له مخې د فاعل عدد او جنس په ډاګه کېږي.',
          urdu: 'ضمائر کے ذریعے فاعل کی جنس، عدد اور غائب/حاضر ہونا واضح ہوتا ہے۔',
          english: 'Suffixes unambiguously mark plurality, gender, and grammatical person.'
        }
      }
    ],
    tags: ['گردان', '۱۴ صیغې', 'ماضی', 'مضارع']
  },
  {
    id: 'sarf_mushtaqqaat_details',
    category: 'sarf',
    topicId: 'mushtaqqaat',
    arabicTitle: 'اسْمُ الْفَاعِلِ وَاسْمُ الْمَفْعُولِ وَأَوْزَانُهُمَا',
    title: {
      pashto: 'اسم فاعل او اسم مفعول او د هغو جوړول',
      urdu: 'اسم فاعل اور اسم مفعول کے اوزان اور بنانے کا طریقہ',
      english: 'Active Participle (Ism Fa\'il) and Passive Participle (Ism Maf\'ool)'
    },
    summary: {
      pashto: 'اسم فاعل کوونکي ته اشاره کوي او اسم مفعول په هغه ذات دلالت کوي چې کار پرې واقع شوی وي.',
      urdu: 'اسم فاعل کام کرنے والے کو اور اسم مفعول اس ذات کو ظاہر کرتا ہے جس پر کام واقع ہوا ہو۔',
      english: 'Ism Fa\'il signifies the active agent, while Ism Maf\'ool denotes the recipient of the action.'
    },
    definition: {
      pashto: 'په ثلاثي مجرد کې اسم فاعل تل په وزن د "فَاعِلٌ" راځي (لکه: نَاصِرٌ، كَاتِبٌ، ضَارِبٌ). او اسم مفعول په وزن د "مَفْعُولٌ" راځي (لکه: مَنْصُورٌ، مَكْتُوبٌ، مَضْرُوبٌ). په مزید فیه کې د مضارع په سر کې "مُـ" (مضمومه) او د پای مخکې توري ته د فاعل لپاره کسر او د مفعول لپاره فتح ورکول کېږي.',
      urdu: 'ثلاثی مجرد سے اسم فاعل کا وزن ہمیشہ "فَاعِلٌ" آتا ہے (جیسے عَالِمٌ، صَابِرٌ) اور اسم مفعول "مَفْعُولٌ" پر آتا ہے (جیسے مَعْلُومٌ، مَظْلُومٌ)۔ ثلاثی مزید فیہ میں علامتِ مضارع کی جگہ میم مضموم لگا کر ماقبل آخر کو فاعل میں کسرہ اور مفعول میں فتحہ دیا جاتا ہے (جیسے: مُعَلِّمٌ اور مُعَلَّمٌ)۔',
      english: 'In Form I, Ism Fa\'il is weighed upon Faa\'ilun and Ism Maf\'ool upon Maf\'oolun. In derived forms, prefix with Mu- and apply Kasrah before the end for active, or Fathah for passive.'
    },
    detailedRules: [
      {
        pashto: 'په ثلاثي مزید فیه کې مثال: أَكْرَمَ ➔ يُكْرِمُ ➔ مُكْرِمٌ (اسم فاعل) او مُكْرَمٌ (اسم مفعول).',
        urdu: 'ثلاثی مزید فیہ میں مثال: اِسْتَغْفَرَ ➔ مُسْتَغْفِرٌ (معافی مانگنے والا) اور مُسْتَغْفَرٌ (جس سے معافی مانگی گئی)۔',
        english: 'Derived paradigm: Istaghfara -> Mustaghfir (one seeking forgiveness) vs Mustaghfar (the one beseeched).'
      }
    ],
    examples: [
      {
        arabic: 'إِنَّ اللّٰهَ يُحِبُّ الصَّابِرِينَ | كِتَابٌ مَرْقُومٌ',
        pashtoTranslation: 'بېشکه الله له صبر کوونکو سره مینه لري | لیکل شوی کتاب.',
        urduTranslation: 'بے شک اللہ صبر کرنے والوں کو پسند فرماتا ہے | لکھی ہوئی کتاب۔',
        englishTranslation: 'Indeed Allah loves the patient ones | A written inscribed book.',
        analysis: {
          pashto: 'الصَّابِرِينَ د صَابِرٌ جمع ده (اسم فاعل) او مَرْقُومٌ د مَفْعُول په وزن دی (اسم مفعول).',
          urdu: 'الصَّابِرِينَ اسم فاعل کی جمع ہے اور مَرْقُومٌ مفعول کے وزن پر اسم مفعول ہے۔',
          english: 'Al-Saabireen is the plural active participle; Marqoom is the passive participle.'
        }
      }
    ],
    tags: ['اسم فاعل', 'اسم مفعول', 'مشتقات']
  },
  {
    id: 'sarf_taleelat_qawaid',
    category: 'sarf',
    topicId: 'taleelat',
    arabicTitle: 'أَهَمُّ قَوَاعِدِ التَّعْلِيلِ: قَلْبُ الْوَاوِ وَالْيَاءِ أَلِفًا',
    title: {
      pashto: 'د تعلیل خورا مشهور قانون: د واو او یاء الف ته اوښتل',
      urdu: 'تعلیل کا سنہری قاعدہ: واؤ اور یاء کا الف میں تبدیل ہونا',
      english: 'The Golden Rule of Ta\'leel: Vocalic Mutation of Waw and Ya into Alif'
    },
    summary: {
      pashto: 'کله چې واو یا یاء متحرک وي او مخکینی توری یې خلاص (مفتوح / زبر لرونکی) وي، نو هغه په الف بدلېږي.',
      urdu: 'جب واؤ یا یاء متحرک ہوں اور ان سے پہلے حرف پر زبر (فتحہ) ہو تو ان کو الف سے بدل دیا جاتا ہے۔',
      english: 'Whenever Waw or Ya is vowelled and preceded by a consonant with Fathah, it mutates into an Alif.'
    },
    definition: {
      pashto: 'قاعده: "إِذَا تَحَرَّكَتِ الْوَاوُ أَوِ الْيَاءُ وَانْفَتَحَ مَا قَبْلَهُمَا قُلِبَتَا أَلِفًا". لکه: قَوَلَ ➔ قَالَ، بَيَعَ ➔ بَاعَ، دَعَوَ ➔ دَعَا، رَمَيَ ➔ رَمَى.',
      urdu: 'قاعدہ: "واؤ اور یاء جب متحرک ہوں اور ان کا ماقبل مفتوح ہو تو ان کو الف سے بدلنا واجب ہے"۔ مثلاً: قَوَلَ سے قَالَ بنا، بَيَعَ سے بَاعَ بنا، دَعَوَ سے دَعَا بنا اور رَمَيَ سے رَمَى بنا۔',
      english: 'Classical formulation: When Waw or Ya is vowelled and preceded by Fathah, it transforms into Alif. E.g., Qawala -> Qaala; Baya\'a -> Baa\'a; Da\'awa -> Da\'aa.'
    },
    detailedRules: [
      {
        pashto: 'شرط دا دی چې حرکت اصلي وي او دواړه توري په یوه کلمه کې واقع وي.',
        urdu: 'شرط یہ ہے کہ حرکت عارضی نہ ہو اور ماقبل کا فتحہ اور حرفِ علت ایک ہی کلمے میں ہوں۔',
        english: 'Condition: The vowel must be inherent and both sounds must reside in the same morpheme.'
      }
    ],
    examples: [
      {
        arabic: 'قَالَ اللّٰهُ تَعَالَى (أَصْلُهُ قَوَلَ) | بَاعَ التَّاجِرُ (أَصْلُهُ بَيَعَ)',
        pashtoTranslation: 'الله تعالی وفرمایل (په اصل کې قَوَلَ و) | سوداګر وپلورل (په اصل کې بَيَعَ و).',
        urduTranslation: 'اللہ تعالیٰ نے فرمایا (اصل میں قَوَلَ تھا) | تاجر نے بیچا (اصل میں بَيَعَ تھا)۔',
        englishTranslation: 'Allah the Almighty said (originally Qawala) | The merchant sold (originally Baya\'a).',
        analysis: {
          pashto: 'په قَوَلَ کې واو متحرک او قاف زبر درلود، نو واو په الف واوښت او "قَالَ" ترې جوړ شو.',
          urdu: 'قَوَلَ میں واؤ پر زبر تھا اور ماقبل قاف پر بھی زبر، لہٰذا تعلیل کے تحت الف سے بدل کر قَالَ ہو گیا۔',
          english: 'Demonstrates the most ubiquitous morphophonemic rule in classical Arabic.'
        }
      }
    ],
    tags: ['تعلیلات', 'قواعد تعلیل', 'قال', 'باع']
  }
];
