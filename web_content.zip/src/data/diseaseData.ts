import { DiseaseItem } from '../types/disease';

export const DISEASES_DATA: DiseaseItem[] = [
  // 1. Diabetes
  {
    id: 'diabetes',
    iconName: 'Activity',
    category: 'Chronic',
    bgGradient: 'from-blue-500 to-indigo-600',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-700 border-blue-200',
    content: {
      English: {
        name: 'Diabetes Mellitus',
        category: 'Chronic Condition',
        summary: 'A metabolic disorder characterized by elevated blood glucose levels due to insulin deficiency or resistance.',
        whatIsIt: 'Diabetes Mellitus is a chronic health condition that affects how your body turns food into energy. Food is broken down into glucose (sugar) and released into your bloodstream. When blood sugar rises, your pancreas signals to release insulin. In diabetes, your body either does not make enough insulin or cannot use it as well as it should.',
        causes: [
          'Type 1 Diabetes: Autoimmune destruction of insulin-producing beta cells in the pancreas.',
          'Type 2 Diabetes: Progressive insulin resistance combined with insufficient compensatory insulin secretion.',
          'Gestational Diabetes: Hormonal changes during pregnancy reducing insulin sensitivity.',
          'Genetic predisposition and family history of metabolic disorders.',
          'Sedentary lifestyle and excess visceral body fat.'
        ],
        symptoms: [
          'Excessive thirst (Polydipsia) and frequent urination (Polyuria)',
          'Unexplained weight loss and persistent fatigue',
          'Blurry or fluctuating vision',
          'Slow-healing sores or frequent infections',
          'Increased hunger (Polyphagia) and tingling in hands or feet'
        ],
        riskFactors: [
          'Overweight or obesity (BMI > 25 kg/m²)',
          'Lack of physical exercise (less than 150 mins/week)',
          'Family history (parents or siblings with Type 2 diabetes)',
          'High blood pressure (≥ 140/90 mmHg) or abnormal cholesterol levels',
          'Age 45 or older'
        ],
        prevention: [
          'Maintain a healthy body weight through balanced calorie intake',
          'Engage in at least 30 minutes of moderate aerobic activity daily',
          'Consume a fiber-rich diet with whole grains, legumes, and vegetables',
          'Limit refined carbohydrates, sugary drinks, and processed snacks',
          'Undergo regular HbA1c screening if at elevated risk'
        ],
        diagnosis: [
          'Fasting Plasma Glucose (FPG) Test: Fasting value ≥ 126 mg/dL',
          'Glycated Hemoglobin (HbA1c) Test: HbA1c level ≥ 6.5%',
          'Oral Glucose Tolerance Test (OGTT): 2-hour blood sugar ≥ 200 mg/dL',
          'Random Blood Sugar Test: Blood sugar ≥ 200 mg/dL with classic symptoms'
        ],
        treatmentOverview: [
          'Lifestyle Modification: Medical nutrition therapy and routine physical activity',
          'Oral Antidiabetic Drugs: Metformin, SGLT2 inhibitors, DPP-4 inhibitors, or Sulfonylureas',
          'Insulin Therapy: Basal and bolus insulin injections (mandatory for Type 1)',
          'Routine Blood Glucose Monitoring: Glucometer or Continuous Glucose Monitors (CGM)',
          'Management of co-existing hypertension and dyslipidemia'
        ],
        lifestyleTips: [
          'Follow the Diabetes Plate Method: 1/2 non-starchy veggies, 1/4 lean protein, 1/4 complex carbs',
          'Stay well hydrated with clean water instead of fruit juices or sodas',
          'Perform daily foot checks for cuts, blisters, or numbness',
          'Maintain consistent sleep schedules to avoid cortisol spikes'
        ],
        whenToConsultDoctor: [
          'Persistent blood sugar readings above target range (> 180 mg/dL fasting)',
          'Frequent episodes of hypoglycemia (blood sugar < 70 mg/dL)',
          'Numbness, burning sensation, or tingling in feet',
          'Non-healing cuts or skin ulcers'
        ],
        emergencyWarningSigns: [
          'Kussmaul breathing (deep, rapid breathing) or fruity-smelling breath (Diabetic Ketoacidosis)',
          'Severe confusion, drowsiness, or loss of consciousness',
          'Blood glucose level above 300 mg/dL accompanied by nausea and vomiting',
          'Hypoglycemic shock (shaking, sweating, confusion not resolving with sugar)'
        ],
        faqs: [
          {
            question: 'Can Type 2 Diabetes be reversed?',
            answer: 'Through significant weight loss, healthy low-carb diet, and regular exercise, many individuals can achieve diabetes remission (normal HbA1c without medication).'
          },
          {
            question: 'Is fruit safe for diabetic patients?',
            answer: 'Yes, fruits with low glycemic index (like berries, apples, and oranges) can be eaten in controlled portions alongside healthy fats or fiber.'
          }
        ]
      },
      Hindi: {
        name: 'मधुमेह (डायबिटीज)',
        category: 'क्रोनिक स्थिति',
        summary: 'इंसुलिन की कमी या प्रतिरोध के कारण रक्त शर्करा (ग्लूकोज) के स्तर में वृद्धि से जुड़ा चयापचय विकार।',
        whatIsIt: 'मधुमेह एक पुरानी स्वास्थ्य स्थिति है जो यह प्रभावित करती है कि आपका शरीर भोजन को ऊर्जा में कैसे बदलता है। जब आप भोजन करते हैं, तो शरीर शर्करा (ग्लूकोज) बनाता है। अग्न्याशय इंसुलिन हार्मोन छोड़ता है जो ग्लूकोज को कोशिकाओं तक पहुँचाता है। मधुमेह में इंसुलिन पर्याप्त नहीं बनता या शरीर इसका ठीक से उपयोग नहीं कर पाता।',
        causes: [
          'टाइप 1 मधुमेह: प्रतिरक्षा प्रणाली द्वारा अग्न्याशय की इंसुलिन बनाने वाली कोशिकाओं को नष्ट करना।',
          'टाइप 2 मधुमेह: शरीर की कोशिकाओं में इंसुलिन प्रतिरोध और इंसुलिन उत्पादन में कमी।',
          'गर्भावस्थाकालीन मधुमेह (गेस्टेशनल): गर्भावस्था के दौरान हार्मोनल बदलाव।',
          'आनुवंशिक कारण और पारिवारिक इतिहास।',
          'अक्रिय जीवनशैली और मोटापा।'
        ],
        symptoms: [
          'अत्यधिक प्यास लगना और बार-बार पेशाब आना',
          'बिना किसी कारण के वजन कम होना और थकान महसूस होना',
          'धुंधली दृष्टि या देखने में परेशानी',
          'घाव और चोट का धीरे-धीरे भरना',
          'हाथों और पैरों में सुन्नता या झुनझुनी'
        ],
        riskFactors: [
          'अधिक वजन या मोटापा (BMI > 25)',
          'शारीरिक गतिविधि की कमी',
          'परिवार में माता-पिता या भाई-बहन को मधुमेह होना',
          'उच्च रक्तचाप (140/90 mmHg से अधिक)',
          '45 वर्ष या उससे अधिक आयु'
        ],
        prevention: [
          'संतुलित आहार द्वारा वजन नियंत्रित रखें',
          'प्रतिदिन कम से कम 30 मिनट पैदल चलें या व्यायाम करें',
          'आहार में फाइबर, हरी सब्जियाँ और साबुत अनाज शामिल करें',
          'मीठे पेय पदार्थों और प्रसंस्कृत खाद्य पदार्थों से बचें',
          'नियमित रूप से रक्त शर्करा की जाँच कराएं'
        ],
        diagnosis: [
          'फास्टिंग ब्लड ग्लूकोज टेस्ट: 126 mg/dL या उससे अधिक',
          'HbA1c टेस्ट: 6.5% या उससे अधिक',
          'रैंडम ब्लड शुगर टेस्ट: लक्षण होने पर 200 mg/dL या उससे अधिक'
        ],
        treatmentOverview: [
          'जीवनशैली में सुधार: खान-पान में बदलाव और नियमित व्यायाम',
          'ओरल दवाएं: मेटफॉर्मिन और अन्य डॉक्टर द्वारा सुझाई गई दवाएं',
          'इंसुलिन थेरेपी: इंसुलिन इंजेक्शन (टाइप 1 के लिए अनिवार्य)',
          'ग्लूकोमीटर से नियमित ब्लड शुगर मॉनिटरिंग'
        ],
        lifestyleTips: [
          'कम ग्लाइसेमिक इंडेक्स वाले खाद्य पदार्थ चुनें',
          'पैरों की सफाई और रोजाना कट/छाले की जाँच करें',
          'तनाव मुक्त रहें और पर्याप्त नींद लें'
        ],
        whenToConsultDoctor: [
          'रक्त शर्करा का लगातार 180 mg/dL से अधिक रहना',
          'बार-बार चक्कर आना या ब्लड शुगर 70 mg/dL से कम होना',
          'पैरों में घाव या सुन्नता होना'
        ],
        emergencyWarningSigns: [
          'सांस में फल जैसी गंध आना या तेजी से सांस लेना (कीटोएसिडोसिस)',
          'बेहोशी या अत्यधिक उलझन महसूस होना',
          'ब्लड शुगर 300 mg/dL से अधिक होने के साथ उल्टी होना'
        ],
        faqs: [
          {
            question: 'क्या टाइप 2 डायबिटीज को नियंत्रित या ठीक किया जा सकता है?',
            answer: 'वजन घटाकर, संतुलित आहार और व्यायाम से टाइप 2 डायबिटीज को काफी हद तक नियंत्रित (रिमिशन) किया जा सकता है।'
          }
        ]
      },
      Marathi: {
        name: 'मधुमेह (डायबिटीज)',
        category: 'दीर्घकालीन आजार',
        summary: 'इन्सुलिनच्या अभावामुळे किंवा प्रतिकारामुळे रक्तातील साखरेचे प्रमाण वाढणारा आजार.',
        whatIsIt: 'मधुमेह हा एक असा आजार आहे ज्यामध्ये शरीरातील रक्तातील साखरेचे (ग्लुकोज) प्रमाण अनियंत्रित होते. स्वादुपिंडातून इन्सुलिन नावाचे संप्रेरक तयार होते जे साखरेचे ऊर्जेत रूपांतर करते. मधुमेहात इन्सुलिन पुरेसे तयार होत नाही किंवा शरीर त्याचा वापर करू शकत नाही.',
        causes: [
          'टाइप १ मधुमेह: स्वादुपिंडातील पेशींवर शरीराची रोगप्रतिकारशक्ती हल्ला करते.',
          'टाइप २ मधुमेह: इन्सुलिनचा प्रतिकार आणि इन्सुलिनची कमतरता.',
          'गर्भधारणेदरम्यान होणारा मधुमेह.',
          'अनुवंशिकता आणि कौटुंबिक इतिहास.',
          'अयोग्य जीवनशैली आणि वजन वाढणे.'
        ],
        symptoms: [
          'अतिशय तहान लागणे आणि वारंवार लघवी होणे',
          'अचानक वजन कमी होणे आणि खूप थकवा येणे',
          'दृष्टी धुसर होणे',
          'जखम लवकर न भरणे',
          'हात आणि पायांना मुंग्या येणे'
        ],
        riskFactors: [
          'अतिरिक्त वजन किंवा लठ्ठपणा',
          'व्यायामाचा अभाव',
          'कुटुंबात मधुमेहाचा इतिहास',
          'उच्च रक्तदाब (140/90 mmHg पेक्षा जास्त)'
        ],
        prevention: [
          'वजन नियंत्रणात ठेवा',
          'दररोज ३० मिनिटे व्यायाम किंवा चालणे',
          'तंतूयुक्त (फायबर) पदार्थांचे सेवन वाढवा',
          'गोड आणि प्रक्रिया केलेले अन्न टाळा'
        ],
        diagnosis: [
          'फास्टिंग ब्लड शुगर चाचणी: १२६ mg/dL किंवा अधिक',
          'HbA1c चाचणी: ६.५% किंवा अधिक'
        ],
        treatmentOverview: [
          'योग्य आहार आणि नियमित व्यायाम',
          'गोळ्या (Metformin इत्यादी)',
          'इन्सुलिनचे इंजेक्शन',
          'रक्तातील साखरेची नियमित तपासणी'
        ],
        lifestyleTips: [
          'कमी साखरेचा आणि पौष्टिक आहार घ्या',
          'पायांची काळजी घ्या आणि नियमित तपासणी करा',
          'पुरेशी झोप घ्या'
        ],
        whenToConsultDoctor: [
          'रक्तातील साखर सतत १८० mg/dL पेक्षा जास्त असल्यास',
          'साखर ७० mg/dL पेक्षा कमी झाल्यास',
          'पायाला जखम झाल्यास'
        ],
        emergencyWarningSigns: [
          'घाबरल्यासारखे होणे, चक्कर येणे किंवा अतिशय गोंधळ होणे',
          'उलटी आणि ३०० mg/dL पेक्षा जास्त साखर असणे'
        ],
        faqs: [
          {
            question: 'टाइप २ मधुमेह नियंत्रणात ठेवता येतो का?',
            answer: 'होय, आहार नियंत्रण, वजन कमी करणे आणि नियमित व्यायामाने रक्तातील साखर पूर्ववत करता येते.'
          }
        ]
      }
    }
  },

  // 2. Hypertension
  {
    id: 'hypertension',
    iconName: 'HeartPulse',
    category: 'Chronic',
    bgGradient: 'from-rose-500 to-red-600',
    badgeBg: 'bg-rose-50',
    badgeText: 'text-rose-700 border-rose-200',
    content: {
      English: {
        name: 'Hypertension (High Blood Pressure)',
        category: 'Cardiovascular Condition',
        summary: 'A long-term condition where the force of blood against the artery walls is consistently too high (≥ 130/80 mmHg).',
        whatIsIt: 'Hypertension, commonly known as High Blood Pressure, occurs when the long-term force of blood pushing against the walls of your arteries is high enough to eventually cause health problems, such as heart disease and stroke.',
        causes: [
          'Primary Hypertension: Gradual development due to genetics, aging, and vascular stiffening.',
          'Secondary Hypertension: Caused by kidney disease, adrenal gland disorders, or thyroid dysfunction.',
          'Excessive dietary sodium intake (> 2,300 mg/day).',
          'Chronic stress, heavy alcohol consumption, and tobacco smoking.',
          'Obesity and lack of regular physical exercise.'
        ],
        symptoms: [
          'Often called "The Silent Killer" because it usually has no visible early symptoms.',
          'Severe occipital headaches (especially upon waking).',
          'Dizziness, lightheadedness, or feeling faint.',
          'Nosebleeds (Epistaxis) in acute severe spikes.',
          'Chest tightness, shortness of breath, or blurred vision.'
        ],
        riskFactors: [
          'Age over 65 years',
          'High salt (sodium) diet',
          'Family history of premature cardiovascular disease',
          'Sedentary habits and chronic sleep apnea',
          'High alcohol intake and nicotine use'
        ],
        prevention: [
          'Adopt the DASH (Dietary Approaches to Stop Hypertension) diet',
          'Reduce sodium intake to less than 1,500 - 2,000 mg daily',
          'Exercise moderately for at least 150 minutes per week',
          'Limit alcohol consumption and completely stop smoking',
          'Manage chronic stress through meditation and relaxation techniques'
        ],
        diagnosis: [
          'Normal: Systolic < 120 mmHg AND Diastolic < 80 mmHg',
          'Elevated: Systolic 120-129 mmHg AND Diastolic < 80 mmHg',
          'Stage 1 Hypertension: Systolic 130-139 mmHg OR Diastolic 80-89 mmHg',
          'Stage 2 Hypertension: Systolic ≥ 140 mmHg OR Diastolic ≥ 90 mmHg',
          '24-Hour Ambulatory Blood Pressure Monitoring (ABPM)'
        ],
        treatmentOverview: [
          'Lifestyle and Dietary Changes',
          'First-line Antihypertensive Medications: ACE inhibitors, ARBs, Calcium Channel Blockers, or Thiazide diuretics',
          'Regular home blood pressure logging'
        ],
        lifestyleTips: [
          'Cook meals with herbs and spices instead of extra salt',
          'Eat potassium-rich foods like bananas, spinach, and sweet potatoes',
          'Monitor blood pressure at the same time each morning and evening'
        ],
        whenToConsultDoctor: [
          'Blood pressure consistently reading ≥ 130/80 mmHg on multiple occasions',
          'Experiencing persistent headaches or dizziness',
          'Side effects from blood pressure medications'
        ],
        emergencyWarningSigns: [
          'Hypertensive Crisis: Blood pressure ≥ 180/120 mmHg',
          'Severe chest pain, pressure, or tightness (possible heart attack)',
          'Sudden weakness or numbness in face, arm, or leg (possible stroke)',
          'Sudden severe shortness of breath or visual impairment'
        ],
        faqs: [
          {
            question: 'Can I stop blood pressure medicine if my BP drops to normal?',
            answer: 'No. BP medication keeps blood pressure controlled. Never stop taking medication without explicit doctor instruction.'
          }
        ]
      },
      Hindi: {
        name: 'हाइपरटेंशन (उच्च रक्तचाप)',
        category: 'हृदय रोग स्थिति',
        summary: 'ऐसी स्थिति जिसमें धमनियों की दीवारों पर रक्त का दबाव लगातार बहुत अधिक (130/80 mmHg से ऊपर) रहता है।',
        whatIsIt: 'उच्च रक्तचाप, जिसे हाइपरटेंशन भी कहा जाता है, तब होता है जब धमनियों में बहने वाले खून का दबाव लगातार सामान्य से अधिक रहता है। इसे "साइलेंट किलर" कहा जाता है क्योंकि शुरुआती दौर में इसके कोई स्पष्ट लक्षण नहीं दिखते।',
        causes: [
          'भोजन में नमक का अधिक सेवन',
          'मोटापा और शारीरिक गतिविधि की कमी',
          'अत्यधिक मानसिक तनाव और चिंता',
          'धूम्रपान और शराब का सेवन',
          'आनुवंशिक कारण'
        ],
        symptoms: [
          'अक्सर कोई लक्षण नहीं होते (साइलेंट किलर)',
          'सुबह के समय तेज सिरदर्द होना',
          'चक्कर आना या घबराहट होना',
          'नाक से खून बहना',
          'सांस फूलना या छाती में भारीपन'
        ],
        riskFactors: [
          '65 वर्ष से अधिक आयु',
          'खान-पान में अधिक नमक का सेवन',
          'परिवार में उच्च रक्तचाप का इतिहास',
          'मोटापा और तनाव'
        ],
        prevention: [
          'भोजन में नमक (सोडियम) कम मात्रा में लें',
          'हरी सब्जियां, फल और पोटेशियम से भरपूर आहार लें',
          'प्रतिदिन नियमित व्यायाम या चालन करें',
          'धूम्रपान और शराब का त्याग करें'
        ],
        diagnosis: [
          'सामान्य: 120/80 mmHg से कम',
          'उच्च रक्तचाप स्टेज 1: 130-139 / 80-89 mmHg',
          'उच्च रक्तचाप स्टेज 2: 140/90 mmHg या अधिक'
        ],
        treatmentOverview: [
          'जीवनशैली में सुधार और कम नमक वाला आहार',
          'एंटीहाइपरटेंसिव दवाएं (डॉक्टर की सलाह अनुसार)',
          'घर पर नियमित बीपी मॉनिटरिंग'
        ],
        lifestyleTips: [
          'ताजे फल और सब्जियां खाएं',
          'ऊपर से नमक छिड़कना बंद करें',
          'योग और ध्यान करें'
        ],
        whenToConsultDoctor: [
          'ब्लड प्रेशर लगातार 130/80 से ऊपर रहना',
          'अक्सर सिरदर्द या चक्कर आना'
        ],
        emergencyWarningSigns: [
          'हाइपरटेंसिव क्राइसिस: बीपी 180/120 mmHg से अधिक',
          'छाती में तेज दर्द या दबाव',
          'चेहरे या हाथ-पैर में अचानक सुन्नता/कमजोरी (स्ट्रोक का संकेत)'
        ],
        faqs: [
          {
            question: 'क्या बीपी नॉर्मल होने पर दवा बंद की जा सकती है?',
            answer: 'नहीं, दवा के कारण ही बीपी नॉर्मल रहता है। बिना डॉक्टर से पूछे दवा कभी बंद न करें।'
          }
        ]
      },
      Marathi: {
        name: 'उच्च रक्तदाब (हायपरटेंशन)',
        category: 'हृदय आणि रक्तवाहिन्यांचा आजार',
        summary: 'रक्तवाहिन्यांच्या भिंतींवर रक्ताचा दाब सतत जास्त (१३०/८० mmHg पेक्षा जास्त) असण्याची स्थिती.',
        whatIsIt: 'उच्च रक्तदाब (हायपरटेंशन) हा एक गंभीर आजार आहे ज्यामध्ये रक्ताचा दाब सतत जास्त राहतो. याला "सायलेंट किलर" देखील म्हणतात कारण अनेकदा याची कोणतीही स्पष्ट लक्षणे दिसत नाहीत.',
        causes: [
          'आहारात मिठाचे जास्त प्रमाण',
          'लठ्ठपणा आणि व्यायामाचा अभाव',
          'मानसिक ताणतणाव',
          'धूम्रपान आणि मद्यपान',
          'अनुवंशिकता'
        ],
        symptoms: [
          'अनेकदा कोणतीही लक्षणे नसतात',
          'डोकेदुखी (विशेषतः सकाळी)',
          'चक्कर येणे किंवा अस्वस्थ वाटणे',
          'नाकपुडीतून रक्त येणे',
          'छातीवर दडपण येणे'
        ],
        riskFactors: [
          'वयाची ६५ वर्षे पूर्ण',
          'जास्त मीठ खाण्याची सवय',
          'कौटुंबिक इतिहास',
          'मानसिक ताण'
        ],
        prevention: [
          'आहारातील मिठाचे प्रमाण कमी करा',
          'दररोज नियमित व्यायाम करा',
          'धूम्रपान व मद्यपान पूर्णपणे टाळा',
          'तणावमुक्त राहा'
        ],
        diagnosis: [
          'सामान्य: १२०/८० mmHg पेक्षा कमी',
          'उच्च रक्तदाब: १४०/९० mmHg किंवा जास्त'
        ],
        treatmentOverview: [
          'जीवनशैलीत बदल आणि कमी मिठाचा आहार',
          'डॉक्टरांच्या सल्ल्याने नियमित औषधे',
          'रक्तदाबाची नियमित तपासणी'
        ],
        lifestyleTips: [
          'ताजी फळे आणि भाज्यांचा आहारात समावेश करा',
          'योगासने आणि ध्यान करा'
        ],
        whenToConsultDoctor: [
          'रक्तदाब सतत जास्त राहत असल्यास',
          'वारंवार डोके दुखत असल्यास'
        ],
        emergencyWarningSigns: [
          'रक्तदाब १८०/१२० mmHg पेक्षा जास्त होणे',
          'छातीत तीव्र वेदना किंवा श्वास घेण्यास त्रास',
          'हात-पाय किंवा चेहऱ्यावर अचानक अशक्तपणा (स्ट्रोक)'
        ],
        faqs: [
          {
            question: 'रक्तदाब सामान्य झाल्यावर औषध बंद करू शकतो का?',
            answer: 'नाही, औषध सुरू असल्यामुळेच रक्तदाब नियंत्रणात राहतो. डॉक्टरांच्या सल्ल्याशिवाय औषध बंद करू नका.'
          }
        ]
      }
    }
  },

  // 3. Asthma
  {
    id: 'asthma',
    iconName: 'Wind',
    category: 'Respiratory',
    bgGradient: 'from-sky-500 to-cyan-600',
    badgeBg: 'bg-sky-50',
    badgeText: 'text-sky-700 border-sky-200',
    content: {
      English: {
        name: 'Asthma',
        category: 'Respiratory Disease',
        summary: 'A chronic inflammatory disease of the airways causing periodic wheezing, breathlessness, chest tightness, and coughing.',
        whatIsIt: 'Asthma is a chronic condition in which your airways narrow, swell, and produce extra mucus. This makes breathing difficult and triggers coughing, wheezing, and shortness of breath.',
        causes: [
          'Inhalation of environmental triggers: Dust mites, pollen, pet dander, mold spores.',
          'Air pollution, cigarette smoke, chemical fumes, and cold air.',
          'Respiratory infections (such as common cold or flu).',
          'Physical exertion (Exercise-induced bronchoconstriction).',
          'Strong emotions or stress triggering hyperventilation.'
        ],
        symptoms: [
          'Wheezing (a high-pitched whistling sound during exhalation)',
          'Shortness of breath and rapid shallow breathing',
          'Chest tightness, pressure, or discomfort',
          'Persistent coughing fits, particularly at night or early morning'
        ],
        riskFactors: [
          'Family history of asthma or allergic conditions (Atopy)',
          'Personal history of allergic rhinitis or eczema',
          'Exposure to secondhand tobacco smoke or occupational chemicals',
          'Obesity and living in high-pollution urban environments'
        ],
        prevention: [
          'Identify and strictly avoid known personal asthma triggers',
          'Use HEPA air purifiers and wash bedding regularly in hot water',
          'Get annual influenza and pneumococcal vaccines',
          'Wear a face mask in cold or dusty outdoor weather'
        ],
        diagnosis: [
          'Spirometry: Measures airflow obstruction before and after bronchodilator',
          'Peak Expiratory Flow (PEF) Metering: Daily home monitoring',
          'Methacholine Challenge Test or Allergy Skin Testing'
        ],
        treatmentOverview: [
          'Quick-Relief (Rescue) Inhalers: Short-acting beta agonists (e.g., Albuterol/Salbutamol)',
          'Long-term Control Medications: Inhaled corticosteroids (ICS) and LABA combinations',
          'Leukotriene modifiers and biologic injections for severe asthma'
        ],
        lifestyleTips: [
          'Always carry your rescue inhaler wherever you go',
          'Keep living spaces dust-free and vacuum regularly',
          'Rinse mouth thoroughly after using steroid inhalers'
        ],
        whenToConsultDoctor: [
          'Frequent need for rescue inhaler (> 2 times per week)',
          'Worsening nighttime coughing or breathing difficulty',
          'Decreasing Peak Flow readings'
        ],
        emergencyWarningSigns: [
          'Severe breathlessness making it hard to speak full sentences',
          'Bluish or grayish lips, tongue, or fingernails (Cyanosis)',
          'Chest wall retracting sharply inward during inhalation',
          'No improvement after using rescue inhaler'
        ],
        faqs: [
          {
            question: 'Are asthma inhalers addictive?',
            answer: 'No. Asthma inhalers deliver targeted medicine directly to the lungs and are non-addictive.'
          }
        ]
      },
      Hindi: {
        name: 'दमा (अस्थमा)',
        category: 'श्वसन रोग',
        summary: 'श्वसन नलियों में सूजन और संकुचन के कारण बार-बार सांस फूलना, खड़खड़ाहट और खांसी होना।',
        whatIsIt: 'अस्थमा फेफड़ों की सांस लेने वाली नलियों से जुड़ी बीमारी है। इसमें नलियों में सूजन आ जाती है, जिससे वे पतली हो जाती हैं और उनमें बलगम बन जाता है। इससे हवा का प्रवाह रुकता है और सांस लेने में कठिनाई होती है।',
        causes: [
          'धूल-मिट्टी, परागकण (पोलन) और पालतू जानवरों के बाल',
          'धुआं, वायु प्रदूषण और ठंडी हवा',
          'सर्दी-जुकाम या वायरल इंफेक्शन',
          'अत्यधिक शारीरिक श्रम या व्यायाम',
          'मानसिक तनाव या अत्यधिक रोना/हंसना'
        ],
        symptoms: [
          'सांस लेते या छोड़ते समय सीटी जैसी आवाज (Wheezing)',
          'सांस फूलना या सांस लेने में तकलीफ होना',
          'छाती में जकड़न या भारीपन',
          'रात में या सुबह तड़के तेज खांसी आना'
        ],
        riskFactors: [
          'परिवार में किसी को अस्थमा या एलर्जी होना',
          'धूम्रपान करने वाले माहौल में रहना',
          'मोटापा और अत्यधिक प्रदूषण'
        ],
        prevention: [
          'अपनी एलर्जी और ट्रिगर्स (धूल, धुआं) से बचें',
          'घर में साफ-सफाई रखें और धूल जमने न दें',
          'ठंड के मौसम में मुंह और नाक ढककर रखें',
          'हर साल फ्लू का टीका लगवाएं'
        ],
        diagnosis: [
          'स्पायरोमेट्री टेस्ट (सांस की जांच)',
          'पीक फ्लो मीटर टेस्ट'
        ],
        treatmentOverview: [
          'रिलैक्सर इनहेलर (तुरंत राहत के लिए)',
          'कंट्रोलर इनहेलर (सूजन कम करने के लिए नियमित उपयोग)',
          'डॉक्टर द्वारा दी गई एंटी-एलर्जी दवाएं'
        ],
        lifestyleTips: [
          'हमेशा अपना इनहेलर पास रखें',
          'इनहेलर का उपयोग करने के बाद कुल्ला करें'
        ],
        whenToConsultDoctor: [
          'हफ्ते में 2 बार से ज्यादा इनहेलर की जरूरत पड़ना',
          'रात में सांस की तकलीफ से नींद खुलना'
        ],
        emergencyWarningSigns: [
          'बोलते समय सांस फूलना (पूरा वाक्य न बोल पाना)',
          'नाखून या होंठ नीले पड़ना',
          'इनहेलर लेने के बाद भी राहत न मिलना'
        ],
        faqs: [
          {
            question: 'क्या इनहेलर की आदत लग जाती है?',
            answer: 'नहीं, इनहेलर फेफड़ों को सीधे दवा पहुंचाते हैं और इनकी आदत नहीं पड़ती।'
          }
        ]
      },
      Marathi: {
        name: 'दमा (अस्थमा)',
        category: 'श्वसनसंस्थेचा आजार',
        summary: 'श्वासनलिकांना सूज आल्यामुळे श्वास घेण्यास त्रास होणे, खोकला आणि छातीत घरघर होणे.',
        whatIsIt: 'अस्थमा हा श्वासनलिकांचा एक आजार आहे ज्यामध्ये श्वासनलिका अरुंद होतात, सूज येते आणि त्यात कफ तयार होतो. यामुळे श्वासोच्छवासाला अडथळा निर्माण होतो.',
        causes: [
          'धूळ, परागकण आणि प्राण्यांचे केस',
          'प्रदूषण, धूर आणि थंड हवा',
          'सर्दी किंवा संसर्ग',
          'अतिश्रम'
        ],
        symptoms: [
          'श्वास घेताना किंवा सोडताना सीटीसारखा आवाज येणे',
          'श्वास घेण्यास त्रास होणे',
          'छातीत जकडन वाटणे',
          'रात्री किंवा पहाटे खोकला येणे'
        ],
        riskFactors: [
          'कुटुंबात अस्थमाचा इतिहास',
          'एलर्जीची पार्श्वभूमी',
          'प्रदूषित वातावरणात राहणे'
        ],
        prevention: [
          'धूळ आणि धुपासून दूर राहा',
          'थंडीच्या दिवसात काळजी घ्या',
          'नियमित स्वच्छता ठेवा'
        ],
        diagnosis: [
          'स्पायरोमेट्री चाचणी'
        ],
        treatmentOverview: [
          'इनहेलर (Inhaler) द्वारे उपचार',
          'नियमित औषधे'
        ],
        lifestyleTips: [
          'नेहमी सोबत इनहेलर ठेवा',
          'मास्कचा वापर करा'
        ],
        whenToConsultDoctor: [
          'वारंवार श्वास फुलत असल्यास',
          'औषधांचा फरक पडत नसल्यास'
        ],
        emergencyWarningSigns: [
          'बोलताना श्वास गुदमरणे',
          'ओठ किंवा नखे निळी पडणे',
          'अत्यंत तीव्र त्रास'
        ],
        faqs: [
          {
            question: 'इनहेलर सुरक्षित असतात का?',
            answer: 'होय, इनहेलर गोळ्यांपेक्षा जास्त सुरक्षित आणि थेट फुफ्फुसांवर काम करणारे असतात.'
          }
        ]
      }
    }
  },

  // 4. Dengue
  {
    id: 'dengue',
    iconName: 'Bug',
    category: 'Vector-borne',
    bgGradient: 'from-amber-500 to-orange-600',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-700 border-amber-200',
    content: {
      English: {
        name: 'Dengue Fever',
        category: 'Mosquito-Borne Viral Infection',
        summary: 'A tropical viral infection transmitted by Aedes mosquitoes characterized by sudden high fever, rash, and severe bone/joint pain.',
        whatIsIt: 'Dengue is a viral infection caused by any of four serotypes of the dengue virus (DENV-1 to DENV-4). It is spread to humans through the bite of infected female Aedes mosquitoes (Aedes aegypti and Aedes albopictus). Also known as "Breakbone Fever".',
        causes: [
          'Bite of infected female Aedes aegypti mosquitoes (active during daytime, especially dawn and dusk).',
          'Stagnant, clean standing water serving as mosquito breeding sites.',
          'Transfusion of infected blood products (rare).'
        ],
        symptoms: [
          'Sudden onset high fever (104°F / 40°C)',
          'Severe headache and pain behind the eyes (Retro-orbital pain)',
          'Severe muscle, joint, and bone aches ("Breakbone pain")',
          'Nausea, vomiting, and loss of appetite',
          'Maculopapular skin rash appearing 2-5 days after fever onset'
        ],
        riskFactors: [
          'Living or traveling in tropical and subtropical regions',
          'Previous dengue infection (subsequent infection increases risk of Severe Dengue)',
          'Presence of open water containers near living quarters'
        ],
        prevention: [
          'Eliminate stagnant water from coolers, tires, flowerpots, and buckets weekly',
          'Apply DEET or Picaridin mosquito repellents on exposed skin',
          'Wear long-sleeved shirts and full-length trousers',
          'Install wire mesh screens on doors and windows'
        ],
        diagnosis: [
          'Dengue NS1 Antigen Test: Positive in the first 1-5 days of fever',
          'Dengue IgM / IgG Antibody Tests: Positive after day 5',
          'Complete Blood Count (CBC): Monitoring Platelet count and Hematocrit (Hemoconcentration)'
        ],
        treatmentOverview: [
          'Supportive Care: Hydration with oral rehydration salts (ORS), coconut water, and fluids',
          'Analgesia: Paracetamol (Acetaminophen) for fever and pain',
          'CONTRAINDICATED: Avoid Aspirin, Ibuprofen, and NSAIDs due to bleeding risks',
          'Hospitalization and Intravenous (IV) fluids if platelet count drops significantly'
        ],
        lifestyleTips: [
          'Take complete bed rest during the febrile and critical phase',
          'Drink at least 3-4 liters of fluids daily to prevent dehydration',
          'Monitor platelet count daily during active infection'
        ],
        whenToConsultDoctor: [
          'Fever persisting beyond 3 days',
          'Platelet count dropping below 100,000 / µL',
          'Inability to tolerate oral liquids due to continuous vomiting'
        ],
        emergencyWarningSigns: [
          'Severe abdominal pain and persistent vomiting (> 3 times in 24 hours)',
          'Bleeding gums, nosebleeds, or mucosal bleeding',
          'Blood in vomit (hematemesis) or black tarry stools (melena)',
          'Platelet count dropping below 20,000 / µL or signs of Dengue Shock Syndrome'
        ],
        faqs: [
          {
            question: 'Can papaya leaf extract increase platelet count in dengue?',
            answer: 'Some studies suggest papaya leaf extract may help boost platelets, but adequate hydration and medical monitoring remain the standard treatment.'
          }
        ]
      },
      Hindi: {
        name: 'डेंगू बुखार',
        category: 'मच्छर जनित वायरल संक्रमण',
        summary: 'मादा एडीज मच्छर के काटने से फैलने वाला बुखार, जिसमें जोड़ों में तेज दर्द, सिरदर्द और प्लेटलेट्स में गिरावट होती है।',
        whatIsIt: 'डेंगू एक वायरल बीमारी है जो एडीज मच्छर के काटने से फैलती है। इसे "हड्डी तोड़ बुखार" भी कहा जाता है क्योंकि इसमें मांसपेशियों और जोड़ों में अत्यधिक तेज दर्द होता है। एडीज मच्छर दिन के समय काटते हैं।',
        causes: [
          'संक्रमित एडीज एजिप्टी मच्छर का काटना',
          'कूलर, गमलों, टायरों और बर्तनों में साफ पानी जमा रहना (मच्छरों के पनपने की जगह)'
        ],
        symptoms: [
          'अचानक तेज बुखार आना (103°F - 104°F)',
          'आंखों के पीछे तेज दर्द होना',
          'मांसपेशियों, जोड़ों और हड्डियों में असह्य दर्द होना',
          'उल्टी होना, जी मिचलाना और भूख न लगना',
          'शरीर पर लाल चकत्ते (रैश) होना'
        ],
        riskFactors: [
          'डेंगू प्रभावित क्षेत्रों में रहना या यात्रा करना',
          'पहले कभी डेंगू का संक्रमण हुआ होना',
          'आस-पास खुला जमा पानी होना'
        ],
        prevention: [
          'घर के आस-पास साफ पानी न जमा होने दें, कूलर और टंकियों की सफाई करें',
          'मच्छर भगाने वाली क्रीम (रिपेलेंट) लगाएं',
          'पूरे शरीर को ढकने वाले कपड़े पहनें',
          'सोते समय मच्छरदानी का प्रयोग करें'
        ],
        diagnosis: [
          'डेंगू NS1 एंटीजन टेस्ट (शुरुआती 1-5 दिनों में)',
          'डेंगू IgM / IgG एंटीबॉडी टेस्ट',
          'सीबीसी (CBC) टेस्ट - प्लेटलेट काउंट की नियमित जांच'
        ],
        treatmentOverview: [
          'भरपूर तरल पदार्थ पीएं (ORS, नारियल पानी, जूस)',
          'बुखार के लिए केवल पैरासिटामोल लें',
          'सावधानी: एस्पिरिन, ब्रूफेन या डिस्प्रिन न लें (रक्तस्राव का खतरा बढ़ सकता है)',
          'प्लेटलेट्स बहुत कम होने पर अस्पताल में भर्ती होना'
        ],
        lifestyleTips: [
          'पूर्ण विश्राम (बेड रेस्ट) करें',
          'पानी और तरल पदार्थों का पर्याप्त सेवन करें'
        ],
        whenToConsultDoctor: [
          'बुखार 3 दिन से अधिक रहना',
          'प्लेटलेट काउंट 1 लाख से कम होना'
        ],
        emergencyWarningSigns: [
          'मसूड़ों या नाक से खून बहना',
          'लगातार उल्टी होना और पेट में तेज दर्द होना',
          'उल्टी में खून आना या काला मल होना',
          'अत्यधिक सुस्ती या सांस लेने में तकलीफ'
        ],
        faqs: [
          {
            question: 'क्या डेंगू में पपीते के पत्ते का जूस असरदार है?',
            answer: 'पपीते के पत्ते के अर्क से प्लेटलेट्स बढ़ने के कुछ प्रमाण हैं, लेकिन डॉक्टर की निगरानी और पानी पीते रहना सबसे जरूरी है।'
          }
        ]
      },
      Marathi: {
        name: 'डेंग्यू ताप',
        category: 'डासांमुळे होणारा विषाणूजन्य आजार',
        summary: 'ॲडीज डासाच्या चावण्यामुळे होणारा ताप, ज्यामध्ये सांधेदुखी आणि प्लेटलेट्स कमी होतात.',
        whatIsIt: 'डेंग्यू हा ॲडीज इजिप्ती डासाच्या चावण्यामुळे होणारा विषाणूजन्य आजार आहे. या तापाला "हाडमोडी ताप" असेही म्हणतात कारण यामध्ये सांधे व स्नायूंमध्ये प्रचंड वेदना होतात.',
        causes: [
          'ॲडीज डासाचे चावणे (हा डास प्रामुख्याने दिवसा चावतो)',
          'साठलेले स्वच्छ पाणी'
        ],
        symptoms: [
          'अचानक खूप तीव्र ताप येणे',
          'डोळ्यांच्या मागे वेदना होणे',
          'अंगदुखी आणि सांधेदुखी',
          'अंगावर लाल पुरळ येणे'
        ],
        riskFactors: [
          'साठलेल्या पाण्याचा परिसर',
          'पूर्वी डेंग्यू झालेला असणे'
        ],
        prevention: [
          'पाणी साठू देऊ नका, साठवलेले पाणी झाकून ठेवा',
          'डास प्रतिबंधक क्रीम वापरा',
          'पूर्ण अंगाचे कपडे घाला'
        ],
        diagnosis: [
          'NS1 ॲंटिजन चाचणी',
          'CBC चाचणी (प्लेटलेट्स तपासणी)'
        ],
        treatmentOverview: [
          'भरपूर पाणी आणि द्रवपदार्थ पिणे',
          'पॅरासिटामॉल औषध',
          'ॲस्पिरिन किंवा आयब्युप्रोफेन टाळा'
        ],
        lifestyleTips: [
          'पूर्ण विश्रांती घ्या',
          'नारळ पाणी आणि ORS प्या'
        ],
        whenToConsultDoctor: [
          'प्लेटलेट्स १ लाखापेक्षा कमी झाल्यास',
          'बुधवारनंतरही ताप न उतरल्यास'
        ],
        emergencyWarningSigns: [
          'नाक किंवा हिरड्यांमधून रक्त येणे',
          'उलटीतून रक्त पडणे',
          'तीव्र पोटदुखी'
        ],
        faqs: [
          {
            question: 'डेंग्यूमध्ये काय खावे?',
            answer: 'हलका आहार, नारळ पाणी, फळांचा रस आणि भरपूर पाणी प्यावे.'
          }
        ]
      }
    }
  },

  // 5. Malaria
  {
    id: 'malaria',
    iconName: 'ShieldAlert',
    category: 'Vector-borne',
    bgGradient: 'from-emerald-500 to-teal-600',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-700 border-emerald-200',
    content: {
      English: {
        name: 'Malaria',
        category: 'Parasitic Vector-Borne Infection',
        summary: 'A life-threatening disease caused by Plasmodium parasites transmitted through the bite of infected female Anopheles mosquitoes.',
        whatIsIt: 'Malaria is a blood-borne disease caused by single-celled protozoan parasites of the genus Plasmodium (primarily Plasmodium falciparum and Plasmodium vivax). The parasites replicate inside red blood cells, causing them to rupture.',
        causes: [
          'Bite of infected female Anopheles mosquitoes (bite mainly at night between dusk and dawn).',
          'Blood transfusions or organ transplants from infected donors (rare).',
          'Congenital transmission from mother to baby during birth.'
        ],
        symptoms: [
          'Cyclical high fever episodes with shivering chills (rigors)',
          'Profuse sweating as fever drops',
          'Severe headache, generalized body aches, and fatigue',
          'Nausea, vomiting, and diarrhea',
          'Anemia and mild jaundice (yellowing of eyes and skin)'
        ],
        riskFactors: [
          'Living in or traveling to malaria-endemic regions',
          'Young children, pregnant women, and immunocompromised patients',
          'Lack of mosquito control measures'
        ],
        prevention: [
          'Sleep under Insecticide-Treated Nets (ITNs)',
          'Apply mosquito repellents containing DEET',
          'Take prophylactic antimalarial medication when traveling to endemic zones',
          'Spray indoor residual insecticides'
        ],
        diagnosis: [
          'Rapid Diagnostic Tests (RDT): Detects malaria antigens in blood within 15 minutes',
          'Peripheral Blood Smear Microscopy: Gold standard for identifying species and parasite density'
        ],
        treatmentOverview: [
          'Artemisinin-based Combination Therapies (ACT) for P. falciparum',
          'Chloroquine / Primaquine for P. vivax (to eradicate liver hypnozoites and prevent relapse)',
          'Intravenous Artesunate for severe or cerebral malaria cases'
        ],
        lifestyleTips: [
          'Ensure complete course of prescribed antimalarial medication even if fever stops',
          'Drink plenty of fluids and rest adequately'
        ],
        whenToConsultDoctor: [
          'High fever accompanied by severe shaking chills',
          'History of mosquito bites followed by unexplained fever'
        ],
        emergencyWarningSigns: [
          'Cerebral Malaria: Confusion, seizures, coma, or altered consciousness',
          'Severe Anemia or dark brown/black urine (Blackwater Fever)',
          'Difficulty breathing or pulmonary edema',
          'Spontaneous bleeding or circulatory collapse'
        ],
        faqs: [
          {
            question: 'Why does malaria fever come in cycles?',
            answer: 'Fever spikes coincide with the synchronized rupture of red blood cells releasing a new batch of parasites into the bloodstream every 48 to 72 hours.'
          }
        ]
      },
      Hindi: {
        name: 'मलेरिया',
        category: 'परजीवी संक्रमण',
        summary: 'मादा एनाफिलीज मच्छर के काटने से फैलने वाला परजीवी रोग, जिसमें ठंड लगकर तेज बुखार आता है।',
        whatIsIt: 'मलेरिया प्लास्मोडियम नामक परजीवी के कारण होता है, जो मादा एनाफिलीज मच्छर के काटने से शरीर में फैलता है। यह परजीवी खून की लाल रक्त कोशिकाओं पर हमला करता है।',
        causes: [
          'संक्रमित मादा एनाफिलीज मच्छर का काटना (मुख्य रूप से रात के समय)'
        ],
        symptoms: [
          'कंपकंपी और ठंड लगकर तेज बुखार आना',
          'बुखार उतरने पर अत्यधिक पसीना आना',
          'तेज सिरदर्द, उल्टी और जी मिचलाना',
          'शरीर में कमजोरी और खून की कमी (एनीमिया)'
        ],
        riskFactors: [
          'मलेरिया प्रभावित क्षेत्रों में रहना',
          'सोते समय मच्छरदानी न लगाना'
        ],
        prevention: [
          'कीटनाशक युक्त मच्छरदानी का प्रयोग करें',
          'शाम के समय मच्छर भगाने वाले साधनों का प्रयोग करें',
          'घर के आस-पास जलजमाव न होने दें'
        ],
        diagnosis: [
          'रैपिड डायग्नोस्टिक टेस्ट (RDT)',
          'ब्लड स्मियर माइक्रोस्कोपी (खून की जांच)'
        ],
        treatmentOverview: [
          'डॉक्टर की सलाह से मलेरिया रोधी दवाएं (जैसे आर्टेमिसिनिन, क्लोरोक्वीन)',
          'दवा का पूरा कोर्स खत्म करना बहुत जरूरी है'
        ],
        lifestyleTips: [
          'पूरा इलाज लें ताकि दोबारा बुखार न आए',
          'भरपूर पानी पीएं'
        ],
        whenToConsultDoctor: [
          'ठंड लगकर बुखार आने पर तुरंत डॉक्टर से मिलें'
        ],
        emergencyWarningSigns: [
          'सिरेब्रल मलेरिया: बेहोशी, दौरे पड़ना या उलझन',
          'गहरा पीला/काला पेशाब होना',
          'सांस लेने में भारी तकलीफ'
        ],
        faqs: [
          {
            question: 'क्या मलेरिया दोबारा हो सकता है?',
            answer: 'हां, प्लास्मोडियम वाइवैक्स लिवर में छिपा रह सकता है और पूरा इलाज न होने पर दोबारा हो सकता है।'
          }
        ]
      },
      Marathi: {
        name: 'मलेरिया',
        category: 'परजीवी आजार',
        summary: 'ॲनोफिलीस डासाच्या मादीमुळे होणारा परजीवी संसर्ग, ज्यामध्ये थंडी वाजून ताप येतो.',
        whatIsIt: 'मलेरिया हा प्लास्मोडियम परजीवीमुळे होणारा आजार आहे. डास चावल्याने हे परजीवी रक्तात पसरतात.',
        causes: [
          'मादा ॲनोफिलीस डास चावणे'
        ],
        symptoms: [
          'थंडी वाजून ताप येणे',
          'ताप उतरताना खूप घाम येणे',
          'डोकेदुखी व उलटी',
          'अशक्तपणा'
        ],
        riskFactors: [
          'प्रदूषित व डासयुक्त परिसर'
        ],
        prevention: [
          'मच्छरदाणीचा वापर करा',
          'डास प्रतिबंधक उपाय करा'
        ],
        diagnosis: [
          'रक्ताची सूक्ष्मदर्शक चाचणी (Blood Test)'
        ],
        treatmentOverview: [
          'मलेरियाविरोधी गोळ्यांचा पूर्ण कोर्स'
        ],
        lifestyleTips: [
          'औषधे अर्धवट सोडू नका'
        ],
        whenToConsultDoctor: [
          'थंडी वाजून ताप आल्यास ताबडतोब'
        ],
        emergencyWarningSigns: [
          'मेंदूचा मलेरिया (फिट्स येणे, गुंग असणे)',
          'अत्यंत कमी रक्त'
        ],
        faqs: [
          {
            question: 'मलेरिया कसा टाळावा?',
            answer: 'डासांचा प्रादुर्भाव रोखणे आणि मच्छरदाणी वापरणे उत्तम उपाय आहे.'
          }
        ]
      }
    }
  },

  // 6. Typhoid
  {
    id: 'typhoid',
    iconName: 'Thermometer',
    category: 'Infectious',
    bgGradient: 'from-violet-500 to-purple-600',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-purple-700 border-purple-200',
    content: {
      English: {
        name: 'Typhoid Fever',
        category: 'Bacterial Systemic Infection',
        summary: 'A bacterial infection caused by Salmonella Typhi spread through contaminated food and drinking water.',
        whatIsIt: 'Typhoid fever is a severe bacterial illness caused by Salmonella enterica serotype Typhi. It invades the intestinal tract and spreads into the bloodstream, affecting multiple organs.',
        causes: [
          'Consuming food or water contaminated with feces containing S. Typhi bacteria.',
          'Poor personal hygiene and lack of handwashing before meals.',
          'Eating raw unwashed vegetables or street food prepared in unsanitary conditions.'
        ],
        symptoms: [
          'Prolonged step-ladder fever rising steadily up to 104°F (40°C)',
          'Abdominal pain, constipation initially or watery diarrhea',
          'Rose-colored spots on the chest and abdomen',
          'Severe weakness, fatigue, headache, and coated tongue'
        ],
        riskFactors: [
          'Living in areas with limited access to clean water and sanitation',
          'Consuming unpasteurized milk or untreated water',
          'Close contact with a typhoid chronic carrier'
        ],
        prevention: [
          'Drink boiled, filtered, or bottled water',
          'Wash hands thoroughly with soap for at least 20 seconds before eating',
          'Get vaccinated (Typhoid Conjugate Vaccine - TCV)',
          'Avoid raw, uncooked street foods'
        ],
        diagnosis: [
          'Blood Culture: Most accurate diagnostic method in Week 1',
          'Widal Test: Serological detection (after 7-10 days)',
          'Stool or Urine Culture'
        ],
        treatmentOverview: [
          'Antibiotic Therapy: Ceftriaxone, Azithromycin, or Ciprofloxacin',
          'Adequate nutrition with easily digestible soft foods',
          'Fluid rehydration therapy'
        ],
        lifestyleTips: [
          'Eat warm, fresh, light cooked meals (khichdi, porridge)',
          'Avoid oily, spicy, fried, or heavy fibrous food during recovery'
        ],
        whenToConsultDoctor: [
          'Continuous high fever not responding to basic antipyretics',
          'Severe stomach distension or tenderness'
        ],
        emergencyWarningSigns: [
          'Intestinal Perforation or Severe Gastrointestinal Bleeding',
          'Delirium, extreme lethargy, or shock',
          'Severe sharp abdominal pain with rigid abdomen'
        ],
        faqs: [
          {
            question: 'How long does typhoid take to cure?',
            answer: 'With proper antibiotics, fever usually improves in 3-5 days, but full recovery takes 2-3 weeks.'
          }
        ]
      },
      Hindi: {
        name: 'टाइफाइड (मोतीझरा)',
        category: 'जीवाणु संक्रमण',
        summary: 'दूषित पानी और भोजन से फैलने वाला साल्मोनेला टाइफी बैक्टीरिया का संक्रमण।',
        whatIsIt: 'टाइफाइड एक गंभीर जीवाणु संक्रमण है जो दूषित भोजन या पानी के जरिए आंतों में प्रवेश करता है और खून में फैल जाता है।',
        causes: [
          'दूषित पानी या असुरक्षित भोजन का सेवन करना',
          'सफाई की कमी और बिना हाथ धोए खाना खाना'
        ],
        symptoms: [
          'लगातार तेज बुखार रहना जो दिन-ब-दिन बढ़ता है',
          'पेट दर्द, कब्ज या दस्त',
          'सिरदर्द, अत्यधिक कमजोरी और जीभ पर सफेद परत जमना',
          'सीने या पेट पर हल्के गुलाबी दाने'
        ],
        riskFactors: [
          'अस्वच्छ पानी पीना और खुले में बिकने वाला खाना खाना'
        ],
        prevention: [
          'उबला या फिल्टर किया हुआ पानी पीएं',
          'खाना खाने से पहले हाथ साबुन से धोएं',
          'टाइफाइड का टीका (वैक्सीन) लगवाएं'
        ],
        diagnosis: [
          'विडाल टेस्ट (Widal Test)',
          'ब्लड कल्चर टेस्ट'
        ],
        treatmentOverview: [
          'डॉक्टर द्वारा दी गई एंटीबायोटिक दवाओं का पूरा कोर्स',
          'सुपाच्य और हल्का भोजन (दलिया, खिचड़ी)'
        ],
        lifestyleTips: [
          'तला-भुना और मसालेदार खाना न खाएं',
          'आराम करें और तरल पदार्थ पीएं'
        ],
        whenToConsultDoctor: [
          'बुखार कई दिनों तक न उतरे'
        ],
        emergencyWarningSigns: [
          'पेट में असह्य दर्द होना (आंतों में छेद का खतरा)',
          'मल में खून आना या काला मल होना'
        ],
        faqs: [
          {
            question: 'टाइफाइड में क्या खाना चाहिए?',
            answer: 'खिचड़ी, दलिया, उबले आलू, केला और उबला पानी सबसे बेहतर है।'
          }
        ]
      },
      Marathi: {
        name: 'टाइफॉईड',
        category: 'जीवाणूजन्य संसर्ग',
        summary: 'दूषित पाणी व अन्नातून होणारा साल्मोनेला टायफी जिवाणूचा संसर्ग.',
        whatIsIt: 'टायफॉईड हा अस्वच्छ पाणी आणि अन्नपदार्थांमुळे होणारा गंभीर आजार आहे.',
        causes: [
          'दूषित पाणी व अन्न'
        ],
        symptoms: [
          'सतत वाढणारा तीव्र ताप',
          'पोटदुखी व अशक्तपणा',
          'जिभेवर पांढरा थर'
        ],
        riskFactors: [
          'अस्वच्छ वातावरण व उघड्यावरील अन्न'
        ],
        prevention: [
          'उकळून थंड केलेले पाणी प्या',
          'हातांची स्वच्छता ठेवा',
          'लशीकरण करा'
        ],
        diagnosis: [
          'विडाल (Widal) चाचणी'
        ],
        treatmentOverview: [
          'एंटीबायोटिक्सचा पूर्ण कोर्स'
        ],
        lifestyleTips: [
          'हलका व पचायला सोपा आहार घ्या'
        ],
        whenToConsultDoctor: [
          'ताप सतत जास्त राहिल्यास'
        ],
        emergencyWarningSigns: [
          'तीव्र पोटदुखी व शौचातून रक्त येणे'
        ],
        faqs: [
          {
            question: 'टायफॉईड पूर्ण बरा होतो का?',
            answer: 'होय, योग्य प्रतिजैविके (Antibiotics) घेतल्यास आजार पूर्ण बरा होतो.'
          }
        ]
      }
    }
  },

  // 7. Tuberculosis
  {
    id: 'tuberculosis',
    iconName: 'Lungs',
    category: 'Infectious',
    bgGradient: 'from-slate-600 to-zinc-800',
    badgeBg: 'bg-slate-100',
    badgeText: 'text-slate-800 border-slate-300',
    content: {
      English: {
        name: 'Tuberculosis (TB)',
        category: 'Contagious Bacterial Disease',
        summary: 'An airborne bacterial infection caused by Mycobacterium tuberculosis mainly affecting the lungs.',
        whatIsIt: 'Tuberculosis (TB) is a potentially serious infectious disease that mainly affects your lungs. The bacteria that cause tuberculosis are spread from one person to another through tiny droplets released into the air via coughs and sneezes.',
        causes: [
          'Inhalation of Mycobacterium tuberculosis bacteria from airborne droplets of an active TB patient.'
        ],
        symptoms: [
          'Persistent cough lasting more than 3 weeks',
          'Coughing up blood or sputum (Hemoptysis)',
          'Chest pain during breathing or coughing',
          'Unintentional weight loss and loss of appetite',
          'Low-grade fever and drenching night sweats'
        ],
        riskFactors: [
          'Weakened immune system (HIV/AIDS, diabetes, end-stage kidney disease)',
          'Close contact with active untreated TB patients',
          'Malnutrition and overcrowded poorly ventilated living spaces'
        ],
        prevention: [
          'BCG Vaccine at birth',
          'Cover mouth and nose when coughing or sneezing',
          'Ensure adequate room ventilation and sunlight exposure',
          'Complete Latent TB Infection (LTBI) preventive treatment'
        ],
        diagnosis: [
          'Sputum Smear Microscopy and CBNAAT / GeneXpert Test',
          'Chest X-ray',
          'Tuberculin Skin Test (Mantoux test)'
        ],
        treatmentOverview: [
          'Anti-TB Treatment (ATT) DOTS therapy for 6 months (Rifampicin, Isoniazid, Pyrazinamide, Ethambutol)',
          'Strict adherence to complete 6-month medication course without missing doses to avoid Multi-Drug Resistant TB (MDR-TB)'
        ],
        lifestyleTips: [
          'Eat high-protein calorie-dense nutritious food',
          'Never discontinue anti-TB medicines early even if feeling completely cured'
        ],
        whenToConsultDoctor: [
          'Coughing lasting more than 2-3 weeks',
          'Unexplained night sweats and weight loss'
        ],
        emergencyWarningSigns: [
          'Coughing up large amounts of blood',
          'Severe acute breathlessness and chest pain'
        ],
        faqs: [
          {
            question: 'Is TB completely curable?',
            answer: 'Yes, regular and uninterrupted completion of 6-month anti-TB treatment cures TB completely.'
          }
        ]
      },
      Hindi: {
        name: 'क्षयरोग (टीबी)',
        category: 'संक्रामक जीवाणु रोग',
        summary: 'माइकोबैक्टीरियम ट्यूबरकुलोसिस द्वारा हवा के माध्यम से फैलने वाला फेफड़ों का संक्रामक रोग।',
        whatIsIt: 'टीबी एक गंभीर संक्रामक बीमारी है जो मुख्य रूप से फेफड़ों को प्रभावित करती है। यह पीड़ित व्यक्ति के खांसने या छींकने पर हवा में फैलने वाली बूंदों से दूसरे लोगों में फैलती है।',
        causes: [
          'टीबी के मरीज के खांसने या छींकने से निकले ड्रॉपलेट्स सांस द्वारा अंदर जाना'
        ],
        symptoms: [
          '3 सप्ताह या उससे अधिक समय से लगातार खांसी',
          'खांसी में खून या बलगम आना',
          'अचानक वजन कम होना और भूख न लगना',
          'शाम के समय हल्का बुखार आना और रात में पसीना आना',
          'सीने में दर्द होना'
        ],
        riskFactors: [
          'कमजोर इम्युनिटी (जैसे डायबिटीज, एड्स)',
          'टीबी मरीज के संपर्क में रहना',
          'कुपोषण'
        ],
        prevention: [
          'जन्म के समय बीसीजी (BCG) का टीका',
          'खांसते समय मुंह पर रुमाल रखें',
          'घर में पर्याप्त धूप और हवा आने दें'
        ],
        diagnosis: [
          'बलगम की जांच (CBNAAT / GeneXpert)',
          'छाती का एक्स-रे (Chest X-Ray)'
        ],
        treatmentOverview: [
          'DOTS थेरेपी: 6 महीने तक लगातार सरकारी या प्रामाणिक टीबी की दवाएं लेना',
          'दवा बीच में न छोड़ें वरना MDR-TB (ड्रग रेजिस्टेंट) का खतरा होता है'
        ],
        lifestyleTips: [
          'प्रोटीन युक्त पौष्टिक भोजन खाएं',
          'समय पर दवा लें'
        ],
        whenToConsultDoctor: [
          '2-3 हफ्ते से ज्यादा खांसी होने पर तुरंत मुफ्त जांच कराएं'
        ],
        emergencyWarningSigns: [
          'खांसी के साथ ज्यादा मात्रा में खून आना',
          'सांस फूलना'
        ],
        faqs: [
          {
            question: 'क्या टीबी पूरी तरह ठीक हो सकती है?',
            answer: 'हां, 6 महीने तक बिना एक भी दिन छोड़े दवा लेने से टीबी पूरी तरह ठीक हो जाती है।'
          }
        ]
      },
      Marathi: {
        name: 'क्षयरोग (टीबी)',
        category: 'संसर्गजन्य आजार',
        summary: 'हवेद्वारे पसरणारा जिवाणूजन्य संसर्ग, जो प्रामुख्याने फुफ्फुसांवर परिणाम करतो.',
        whatIsIt: 'क्षयरोग (टीबी) हा मायकोबॅक्टेरियम ट्यूबरक्युलॉसिस जिवाणूमुळे होणारा संसर्गजन्य आजार आहे.',
        causes: [
          'हवेतील थेंबांद्वारे जिवाणूंचा प्रसार'
        ],
        symptoms: [
          '३ आठवड्यांपेक्षा जास्त काळ खोकला',
          'खोकल्यातून रक्त पडणे',
          'वजन कमी होणे व रात्री घाम येणे',
          'छातीत वेदना'
        ],
        riskFactors: [
          'कमी रोगप्रतिकारशक्ती',
          'कुपोषण'
        ],
        prevention: [
          'BCG लस',
          'खोकताना तोंडावर हात/रुमाल ठेवा'
        ],
        diagnosis: [
          'थुंकीची चाचणी (CBNAAT)',
          'छातीचा एक्स-रे'
        ],
        treatmentOverview: [
          '६ महिने नियमित औषधोपचार (DOTS)'
        ],
        lifestyleTips: [
          'पौष्टिक आहार घ्या'
        ],
        whenToConsultDoctor: [
          '२ आठवड्यांपेक्षा जास्त खोकला असल्यास'
        ],
        emergencyWarningSigns: [
          'उलटी किंवा खोकल्यातून जास्त रक्त येणे'
        ],
        faqs: [
          {
            question: 'टीबीचा उपचार मोफत मिळतो का?',
            answer: 'होय, सरकारी रुग्णालयांमध्ये (DOTS केंद्र) टीबीचा उपचार पूर्णपणे मोफत मिळतो.'
          }
        ]
      }
    }
  },

  // 8. COVID-19
  {
    id: 'covid19',
    iconName: 'ShieldPlus',
    category: 'Respiratory',
    bgGradient: 'from-teal-500 to-emerald-700',
    badgeBg: 'bg-teal-50',
    badgeText: 'text-teal-700 border-teal-200',
    content: {
      English: {
        name: 'COVID-19 (Coronavirus)',
        category: 'Viral Respiratory Disease',
        summary: 'Infectious respiratory disease caused by the SARS-CoV-2 coronavirus ranging from mild cold symptoms to severe pneumonia.',
        whatIsIt: 'COVID-19 is a contagious disease caused by the severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2). It primarily affects the upper and lower respiratory tracts.',
        causes: [
          'Transmission via respiratory droplets and aerosols when an infected person coughs, sneezes, or talks.',
          'Touching contaminated surfaces and then touching eyes, nose, or mouth.'
        ],
        symptoms: [
          'Fever or chills, dry cough, and fatigue',
          'Loss of taste (Ageusia) or smell (Anosmia)',
          'Sore throat, congestion, runny nose, and body aches',
          'Shortness of breath or difficulty breathing in moderate-to-severe cases'
        ],
        riskFactors: [
          'Older age (> 65 years)',
          'Pre-existing conditions: Diabetes, hypertension, heart disease, obesity, or asthma'
        ],
        prevention: [
          'Get vaccinated and boosted with updated COVID-19 vaccines',
          'Wear well-fitted N95 / KN95 masks in crowded indoor spaces',
          'Wash hands frequently with soap or alcohol sanitizer',
          'Maintain physical distancing and good indoor ventilation'
        ],
        diagnosis: [
          'Rapid Antigen Test (RAT)',
          'RT-PCR Test (Reverse Transcription Polymerase Chain Reaction) - Gold Standard'
        ],
        treatmentOverview: [
          'Symptomatic Management: Paracetamol, hydration, rest',
          'Antiviral medications (e.g., Paxlovid, Remdesivir) for high-risk patients',
          'Supplemental oxygen and steroids for severe hospitalized cases'
        ],
        lifestyleTips: [
          'Isolate at home if symptomatic',
          'Monitor blood oxygen levels using a Pulse Oximeter (SpO2 target ≥ 95%)'
        ],
        whenToConsultDoctor: [
          'Persistent fever above 101°F for over 3 days',
          'SpO2 reading dropping below 94%'
        ],
        emergencyWarningSigns: [
          'Trouble breathing or severe shortness of breath',
          'Persistent pain or pressure in the chest',
          'Bluish lips or face (Cyanosis)',
          'Inability to wake up or stay awake'
        ],
        faqs: [
          {
            question: 'Does vaccination prevent COVID-19 completely?',
            answer: 'Vaccines significantly reduce the risk of severe illness, hospitalization, and death, even if mild breakthrough infection occurs.'
          }
        ]
      },
      Hindi: {
        name: 'कोविड-19 (कोरोना वायरस)',
        category: 'श्वसन तंत्र संक्रमण',
        summary: 'SARS-CoV-2 वायरस से फैलने वाला संक्रामक रोग, जिसमें बुखार, सांस की तकलीफ और स्वाद/सुगंध का जाना शामिल है।',
        whatIsIt: 'कोविड-19 एक संक्रामक श्वसन बीमारी है जो नोवेल कोरोनावायरस (SARS-CoV-2) के कारण होती है।',
        causes: [
          'संक्रमित व्यक्ति के खांसने, छींकने या बात करने से निकली सांस की बूंदों से फैलना'
        ],
        symptoms: [
          'बुखार, सूखी खांसी और अत्यधिक थकान',
          'स्वाद और गंध (सुगंध) का महसूस न होना',
          'गले में खराश, सिरदर्द और बदन दर्द',
          'सांस लेने में दिक्कत'
        ],
        riskFactors: [
          'बुजुर्ग व्यक्ति और डायबिटीज/हृदय रोगी'
        ],
        prevention: [
          'कोविड का टीका (वैक्सीन) लगवाएं',
          'मास्क पहनें और हाथों की सफाई रखें',
          'भीड़भाड़ वाली जगहों से बचें'
        ],
        diagnosis: [
          'आरटी-पीसीआर (RT-PCR) टेस्ट',
          'रैपिड एंटीजन टेस्ट (RAT)'
        ],
        treatmentOverview: [
          'लक्षणों के आधार पर इलाज (पैरासिटामोल, भाप लेना, आराम)',
          'पल्स ऑक्सीमीटर से ऑक्सीजन (SpO2) लेवल जांचना'
        ],
        lifestyleTips: [
          'आइसोलेशन में रहें',
          'गुनगुना पानी पीएं'
        ],
        whenToConsultDoctor: [
          'ऑक्सीजन लेवल (SpO2) 94% से कम होना'
        ],
        emergencyWarningSigns: [
          'सांस लेने में भारी तकलीफ होना',
          'छाती में लगातार दर्द या दबाव होना',
          'होंठ नीले पड़ना'
        ],
        faqs: [
          {
            question: 'क्या वैक्सीन लगवाना जरूरी है?',
            answer: 'हां, वैक्सीन आपको गंभीर बीमारी और अस्पताल में भर्ती होने से बचाती है।'
          }
        ]
      },
      Marathi: {
        name: 'कोविड-१९ (कोरोना)',
        category: 'श्वसनसंस्थेचा विषाणूजन्य आजार',
        summary: 'SARS-CoV-2 या विषाणूमुळे होणारा संसर्गजन्य आजार.',
        whatIsIt: 'कोविड-१९ हा विषाणूजन्य संसर्ग आहे जो श्वासोच्छवासाद्वारे पसरतो.',
        causes: [
          'हवेतील थेंबांद्वारे प्रसार'
        ],
        symptoms: [
          'ताप, खोकला व थकवा',
          'वास आणि चव जाणे',
          'श्वास घेण्यास त्रास'
        ],
        riskFactors: [
          'ज्येष्ठ नागरिक व इतर आजार असलेले लोक'
        ],
        prevention: [
          'लसीकरण करा',
          'मास्क वापरा व हात स्वच्छ ठेवा'
        ],
        diagnosis: [
          'RT-PCR चाचणी'
        ],
        treatmentOverview: [
          'लक्षणानुसार उपचार व विश्रांती',
          'ऑक्सिजन पातळीवर लक्ष ठेवणे'
        ],
        lifestyleTips: [
          'विलगीकरणात (Isolation) राहा'
        ],
        whenToConsultDoctor: [
          'ऑक्सिजन ९४% पेक्षा कमी झाल्यास'
        ],
        emergencyWarningSigns: [
          'तीव्र श्वासकोंडी व छातीत वेदना'
        ],
        faqs: [
          {
            question: 'ऑक्सिजन कसा तपासावा?',
            answer: 'पल्स ऑक्सीमीटरद्वारे (Pulse Oximeter) बोटावर लावून ऑक्सिजन पातळी तपासावी.'
          }
        ]
      }
    }
  },

  // 9. Common Cold
  {
    id: 'common_cold',
    iconName: 'ThermometerSnowflake',
    category: 'Respiratory',
    bgGradient: 'from-cyan-500 to-blue-600',
    badgeBg: 'bg-cyan-50',
    badgeText: 'text-cyan-700 border-cyan-200',
    content: {
      English: {
        name: 'Common Cold',
        category: 'Viral Upper Respiratory Infection',
        summary: 'A mild viral infection of the nose, throat, and sinus passages typically clearing within 7-10 days.',
        whatIsIt: 'The common cold is a self-limiting viral infection of the upper respiratory tract. Over 200 strains of viruses can cause a cold, with Rhinoviruses being the most frequent.',
        causes: [
          'Rhinoviruses, Coronaviruses, Adenoviruses, or Respiratory Syncytial Virus (RSV).',
          'Inhaling viral particles or touching infected surfaces and touching face.'
        ],
        symptoms: [
          'Runny or stuffy nose (nasal congestion)',
          'Sore throat or tickle in the throat',
          'Sneezing and mild low-grade fever',
          'Mild body aches and watery eyes'
        ],
        riskFactors: [
          'Young children under 6 years',
          'Cold winter season and close contact in schools or daycare'
        ],
        prevention: [
          'Wash hands frequently with warm water and soap',
          'Avoid touching eyes, nose, and mouth with unwashed hands',
          'Disinfect high-touch surfaces like doorknobs and phones'
        ],
        diagnosis: [
          'Clinical diagnosis based on symptoms (no lab test needed).'
        ],
        treatmentOverview: [
          'Symptomatic relief: Decongestants, saline nasal sprays, antihistamines',
          'NOTE: Antibiotics are useless against viral colds and should NOT be taken.',
          'Warm fluids, steam inhalation, and throat lozenges'
        ],
        lifestyleTips: [
          'Get extra rest and stay hydrated with warm soups and tea',
          'Gargle with warm salt water'
        ],
        whenToConsultDoctor: [
          'Symptoms lasting longer than 10-14 days',
          'Fever higher than 101.3°F (38.5°C)'
        ],
        emergencyWarningSigns: [
          'Severe difficulty breathing or wheezing',
          'Severe ear pain or severe sinus facial pain (secondary bacterial infection)'
        ],
        faqs: [
          {
            question: 'Do antibiotics cure common cold?',
            answer: 'No. Colds are caused by viruses. Antibiotics kill bacteria, not viruses.'
          }
        ]
      },
      Hindi: {
        name: 'सामान्य सर्दी-जुकाम',
        category: 'ऊपरी श्वसन संक्रमण',
        summary: 'नाक और गले का हल्का वायरल संक्रमण जो 7-10 दिनों में अपने आप ठीक हो जाता है।',
        whatIsIt: 'सामान्य जुकाम ऊपरी श्वसन तंत्र का एक हल्का वायरल संक्रमण है। यह मुख्य रूप से राइनोवायरस (Rhinovirus) के कारण होता है।',
        causes: [
          'राइनोवायरस या अन्य जुकाम के वायरस का संपर्क में आना'
        ],
        symptoms: [
          'नाक बहना या बंद होना',
          'छींक आना और गले में खराश होना',
          'हल्का बुखार और सिरदर्द'
        ],
        riskFactors: [
          'छोटे बच्चे और कमजोर इम्युनिटी'
        ],
        prevention: [
          'हाथों को नियमित साबुन से धोएं',
          'संक्रमित व्यक्ति के बर्तन या तौलिया शेयर न करें'
        ],
        diagnosis: [
          'लक्षणों के आधार पर पहचान (किसी टेस्ट की जरूरत नहीं)'
        ],
        treatmentOverview: [
          'गर्म पानी और चाय पीएं, भाप लें',
          'एंटीबायोटिक की कोई जरूरत नहीं होती'
        ],
        lifestyleTips: [
          'गुनगुने पानी में नमक डालकर गरारे करें',
          'पर्याप्त आराम करें'
        ],
        whenToConsultDoctor: [
          '10 दिनों से ज्यादा जुकाम रहना'
        ],
        emergencyWarningSigns: [
          'सांस लेने में भारी तकलीफ होना'
        ],
        faqs: [
          {
            question: 'क्या जुकाम में एंटीबायोटिक लेना चाहिए?',
            answer: 'बिलकुल नहीं, जुकाम वायरस से होता है और एंटीबायोटिक केवल बैक्टीरिया पर काम करती हैं।'
          }
        ]
      },
      Marathi: {
        name: 'सामान्य सर्दी आणि पडसे',
        category: 'श्वसनसंस्थेचा सौम्य आजार',
        summary: 'नाक आणि घशाचा विषाणूजन्य संसर्ग जो स्वतःहून ७-१० दिवसांत बरा होतो.',
        whatIsIt: 'सर्दी हा एक अतिशय सामान्य विषाणूजन्य संसर्ग आहे.',
        causes: [
          'रायनोव्हायरस संसर्ग'
        ],
        symptoms: [
          'नाक वाहणे किंवा बंद होणे',
          'शिंका येणे व घशात खवखव',
          'हळुवार ताप'
        ],
        riskFactors: [
          'लहान मुले व हवामानातील बदल'
        ],
        prevention: [
          'हात स्वच्छ धुवा'
        ],
        diagnosis: [
          'लक्षणानुसार निदान'
        ],
        treatmentOverview: [
          'गरम पाणी, वाफ घेणे व विश्रांती',
          'एंटीबायोटिक्सची गरज नसते'
        ],
        lifestyleTips: [
          'मीठाच्या पाण्याच्या गुळण्या करा'
        ],
        whenToConsultDoctor: [
          '१० दिवसांपेक्षा जास्त काळ त्रास असल्यास'
        ],
        emergencyWarningSigns: [
          'श्वास घेण्यास तीव्र त्रास'
        ],
        faqs: [
          {
            question: 'सर्दीवर सर्वोत्तम उपाय कोणता?',
            answer: 'वाफ घेणे, गरम द्रवपदार्थ पिणे आणि विश्रांती हाच सर्वोत्तम उपाय आहे.'
          }
        ]
      }
    }
  },

  // 10. Influenza (Flu)
  {
    id: 'influenza',
    iconName: 'Flame',
    category: 'Respiratory',
    bgGradient: 'from-orange-500 to-red-600',
    badgeBg: 'bg-orange-50',
    badgeText: 'text-orange-700 border-orange-200',
    content: {
      English: {
        name: 'Influenza (Seasonal Flu)',
        category: 'Contagious Respiratory Infection',
        summary: 'A contagious respiratory illness caused by influenza viruses leading to sudden onset high fever, body aches, and fatigue.',
        whatIsIt: 'Influenza (flu) is a contagious viral respiratory infection affecting the nose, throat, and lungs. Unlike the common cold, flu symptoms strike suddenly and are much more severe.',
        causes: [
          'Influenza A and Influenza B viruses.',
          'Spreads via airborne droplets from infected coughs/sneezes.'
        ],
        symptoms: [
          'Sudden high fever (100°F to 104°F) and severe chills',
          'Severe muscle and joint aches (myalgia)',
          'Profound fatigue and exhaustion lasting days to weeks',
          'Dry persistent cough and severe headache'
        ],
        riskFactors: [
          'Children under 5 and adults over 65',
          'Pregnant women and chronic health patients'
        ],
        prevention: [
          'Annual Seasonal Flu Vaccine shot',
          'Frequent hand hygiene and avoiding close contact'
        ],
        diagnosis: [
          'Rapid Influenza Diagnostic Tests (RIDTs)',
          'Molecular Assays (RT-PCR)'
        ],
        treatmentOverview: [
          'Antiviral drugs (e.g., Oseltamivir / Tamiflu) if started within 48 hours of symptom onset',
          'Rest, fluids, and Paracetamol for body ache and fever'
        ],
        lifestyleTips: [
          'Stay home to prevent spreading flu to others',
          'Drink warm clear broths and herbal teas'
        ],
        whenToConsultDoctor: [
          'High fever persisting beyond 4 days',
          'Flu symptoms that improve then return with worse fever and cough'
        ],
        emergencyWarningSigns: [
          'Shortness of breath or difficulty breathing',
          'Chest pain or pressure',
          'Dizziness, confusion, or severe weakness'
        ],
        faqs: [
          {
            question: 'How is flu different from a common cold?',
            answer: 'Flu comes on suddenly with high fever and severe body aches, whereas a cold develops gradually with mild symptoms.'
          }
        ]
      },
      Hindi: {
        name: 'इन्फ्लूएंजा (फ्लू)',
        category: 'श्वसन वायरल संक्रमण',
        summary: 'इन्फ्लूएंजा वायरस से होने वाला अचानक तेज बुखार, बदन दर्द और थकान देने वाला संक्रामक रोग।',
        whatIsIt: 'इन्फ्लूएंजा (फ्लू) एक संक्रामक वायरल बीमारी है जो फेफड़ों, गले और नाक को प्रभावित करती है। यह सामान्य जुकाम से अधिक गंभीर होता है।',
        causes: [
          'इन्फ्लूएंजा ए और बी वायरस'
        ],
        symptoms: [
          'अचानक तेज बुखार आना और ठंड लगना',
          'मांसपेशियों और जोड़ों में तेज दर्द होना',
          'अत्यधिक थकान और कमजोरी महसूस होना',
          'सूखी खांसी और सिरदर्द'
        ],
        riskFactors: [
          'बच्चे, बुजुर्ग और गर्भवती महिलाएं'
        ],
        prevention: [
          'हर साल फ्लू का टीका (Seasonal Flu Vaccine) लगवाएं',
          'हाथों की सफाई रखें'
        ],
        diagnosis: [
          'फ्लू रैपिड एंटीजन टेस्ट'
        ],
        treatmentOverview: [
          'एंटीवायरल दवाएं (जैसे ओसेल्टामिविर/टेमीफ्लू)',
          'पैरासिटामोल और पर्याप्त आराम'
        ],
        lifestyleTips: [
          'घर पर आराम करें और तरल पदार्थ लें'
        ],
        whenToConsultDoctor: [
          'बुखार 4 दिन से ज्यादा रहना'
        ],
        emergencyWarningSigns: [
          'सांस लेने में भारी दिक्कत',
          'छाती में तेज दर्द होना'
        ],
        faqs: [
          {
            question: 'क्या फ्लू का टीका हर साल लगवाना पड़ता है?',
            answer: 'हां, क्योंकि फ्लू के वायरस हर साल अपना रूप बदलते हैं।'
          }
        ]
      },
      Marathi: {
        name: 'इन्फ्लूएंझा (फ्लू)',
        category: 'विषाणूजन्य ताप व संसर्ग',
        summary: 'इन्फ्लूएंझा विषाणूमुळे अचानक येणारा तीव्र ताप व अंगदुखी.',
        whatIsIt: 'फ्लू हा एक संसर्गजन्य आजार आहे जो अचानक सुरू होतो.',
        causes: [
          'इन्फ्लूएंझा विषाणू'
        ],
        symptoms: [
          'अचानक तीव्र ताप व थंडी',
          'तीव्र अंगदुखी व थकवा',
          'कोरडा खोकला'
        ],
        riskFactors: [
          'वयोवृद्ध नागरिक व लहान मुले'
        ],
        prevention: [
          'दरवर्षी फ्लूची लस घ्या'
        ],
        diagnosis: [
          'फ्लू चाचणी'
        ],
        treatmentOverview: [
          'अँटीव्हायरल औषधे व विश्रांती'
        ],
        lifestyleTips: [
          'गरम द्रवपदार्थ प्या'
        ],
        whenToConsultDoctor: [
          'ताप ४ दिवसांपेक्षा जास्त राहिल्यास'
        ],
        emergencyWarningSigns: [
          'श्वास कोंडणे व छातीत दुखणे'
        ],
        faqs: [
          {
            question: 'फ्लू आणि सर्दीत काय फरक आहे?',
            answer: 'फ्लूमध्ये अचानक खूप जास्त ताप आणि तीव्र अंगदुखी येते.'
          }
        ]
      }
    }
  },

  // 11. Migraine
  {
    id: 'migraine',
    iconName: 'Zap',
    category: 'General',
    bgGradient: 'from-purple-600 to-pink-600',
    badgeBg: 'bg-pink-50',
    badgeText: 'text-pink-700 border-pink-200',
    content: {
      English: {
        name: 'Migraine',
        category: 'Neurological Disorder',
        summary: 'A neurological condition characterized by intense throbbing headache usually on one side, accompanied by nausea and light sensitivity.',
        whatIsIt: 'Migraine is a complex neurological disorder involving recurrent attacks of moderate to severe headache, often throbbing, typically affecting one side of the head.',
        causes: [
          'Abnormal brain activity temporarily affecting nerve signals, chemicals, and blood vessels.',
          'Triggers: Stress, lack of sleep, bright lights, loud noises, hormonal fluctuations, skipped meals, weather changes, aged cheese, MSG, or red wine.'
        ],
        symptoms: [
          'Throbbing or pulsating headache usually on one side of head',
          'Nausea and vomiting',
          'Extreme sensitivity to light (Photophobia) and sound (Phonophobia)',
          'Visual Aura (flashing lights, zigzag lines, or blind spots before attack)'
        ],
        riskFactors: [
          'Family history of migraines',
          'Female gender (3 times more common in women due to hormonal shifts)'
        ],
        prevention: [
          'Maintain a consistent sleep-wake schedule',
          'Stay well hydrated and eat meals at regular times',
          'Identify and maintain a trigger diary',
          'Preventative medications (Beta-blockers, Topiramate, CGRP inhibitors)'
        ],
        diagnosis: [
          'Clinical neurological examination',
          'Brain MRI / CT scan if sudden onset or abnormal neurological signs are present'
        ],
        treatmentOverview: [
          'Abortive Therapy: Triptans (e.g., Sumatriptan), NSAIDs, or combination analgesics taken at first sign of attack',
          'Resting in a dark, quiet, cold room with an ice pack on forehead'
        ],
        lifestyleTips: [
          'Apply cold compress or ice pack to forehead or temples',
          'Practice stress relaxation techniques and yoga'
        ],
        whenToConsultDoctor: [
          'Migraines occurring more than 4-5 times per month',
          'Headache medication needed > 2 days per week'
        ],
        emergencyWarningSigns: [
          'Sudden severe "Thunderclap" headache (reaching peak intensity within 1 minute)',
          'Headache with fever, stiff neck, confusion, or seizures',
          'Headache accompanied by numbness, facial drooping, or paralysis'
        ],
        faqs: [
          {
            question: 'What is a migraine aura?',
            answer: 'An aura is a temporary neurological warning sign occurring before or during a migraine, such as seeing flashing lights, spots, or tingling in face/hand.'
          }
        ]
      },
      Hindi: {
        name: 'माइग्रेन (आधे सिर का दर्द)',
        category: 'न्यूरोलॉजिकल विकार',
        summary: 'सिर के एक तरफ तेज कसक भरा दर्द, जिसके साथ उल्टी, रोशनी और आवाज से परेशानी होती है।',
        whatIsIt: 'माइग्रेन तंत्रिका तंत्र (न्यूरोलॉजिकल) से जुड़ा एक विकार है जिसमें सिर के एक तरफ रुक-रुक कर तेज टीस मारने वाला दर्द होता है।',
        causes: [
          'दिमाग के रसायनों और तंत्रिकाओं में बदलाव',
          'ट्रिगर्स: तनाव, नींद पूरी न होना, तेज रोशनी, भूखे रहना, हार्मोनल बदलाव'
        ],
        symptoms: [
          'सिर के एक तरफ तेज टीस (टीस मारने वाला) दर्द होना',
          'जी मिचलाना और उल्टी होना',
          'रोशनी (प्रकाश) और आवाज से तेज परेशानी महसूस होना',
          'ऑरा (Aura): दर्द से पहले आंखों के आगे चमकती रेखाएं दिखना'
        ],
        riskFactors: [
          'पारिवारिक इतिहास',
          'महिलाओं में अधिक होना (हार्मोनल कारणों से)'
        ],
        prevention: [
          'सोने और जागने का समय तय रखें',
          'समय पर खाना खाएं और डिहाइड्रेशन से बचें',
          'तनाव कम करें'
        ],
        diagnosis: [
          'न्यूरोलॉजिस्ट द्वारा जांच'
        ],
        treatmentOverview: [
          'माइग्रेन की विशेष दवाएं (ट्रिप्टैन्स, दर्द निवारक)',
          'अंधेरे और शांत कमरे में आराम करना'
        ],
        lifestyleTips: [
          'माथे पर ठंडी पट्टी या बर्फ रखें',
          'कॉफी/चाय सीमित मात्रा में लें'
        ],
        whenToConsultDoctor: [
          'महीने में 4-5 बार से ज्यादा माइग्रेन अटैक होना'
        ],
        emergencyWarningSigns: [
          'अचानक थंडरक्लैप सिरदर्द (जीवन का सबसे तेज सिरदर्द)',
          'सिरदर्द के साथ गर्दन में अकड़न, तेज बुखार या मुंह टेढ़ा होना'
        ],
        faqs: [
          {
            question: 'माइग्रेन दर्द के समय क्या करना चाहिए?',
            answer: 'एक शांत, अंधेरे कमरे में लेट जाएं और माथे पर बर्फ की सिकाई करें।'
          }
        ]
      },
      Marathi: {
        name: 'मायग्रेन (अर्धशिशी)',
        category: 'मज्जासंस्थेचा आजार',
        summary: 'डोक्याच्या एका बाजूला होणारी तीव्र ठणकणारी डोकेदुखी.',
        whatIsIt: 'मायग्रेन हा चेतासंस्थेशी संबंधित आजार आहे ज्यामध्ये डोक्याच्या एका भागात प्रचंड वेदना होतात.',
        causes: [
          'मानसिक ताण, अपुरी झोप, तीव्र प्रकाश आणि उपाशी राहणे'
        ],
        symptoms: [
          'डोक्याच्या एका बाजूला तीव्र वेदना',
          'मळमळ व उलटी',
          'प्रकाश व आवाजाचा त्रास होणे'
        ],
        riskFactors: [
          'स्त्रियांमध्ये जास्त प्रमाण व अनुवंशिकता'
        ],
        prevention: [
          'नियमित झोप व जेवणाची वेळ पाळा',
          'ताणतणाव कमी करा'
        ],
        diagnosis: [
          'मज्जारोग तज्ज्ञांकडून तपासणी'
        ],
        treatmentOverview: [
          'विशेष औषधे आणि शांत खोलीत विश्रांती'
        ],
        lifestyleTips: [
          'कपाळावर बर्फाचा शेक घ्या'
        ],
        whenToConsultDoctor: [
          'वारंवार तीव्र डोकेदुखी होत असल्यास'
        ],
        emergencyWarningSigns: [
          'अचानक झालेली अतितीव्र डोकेदुखी व मान ताठ होणे'
        ],
        faqs: [
          {
            question: 'मायग्रेन पूर्ण बरा होतो का?',
            answer: 'जीवनशैलीत बदल आणि औषधांनी मायग्रेनचे झटके टाळता येतात.'
          }
        ]
      }
    }
  },

  // 12. Arthritis
  {
    id: 'arthritis',
    iconName: 'Activity',
    category: 'Chronic',
    bgGradient: 'from-amber-600 to-yellow-700',
    badgeBg: 'bg-yellow-50',
    badgeText: 'text-yellow-800 border-yellow-200',
    content: {
      English: {
        name: 'Arthritis',
        category: 'Joint & Musculoskeletal Disorder',
        summary: 'Inflammation of one or more joints causing joint pain, stiffness, and reduced range of motion.',
        whatIsIt: 'Arthritis encompasses over 100 conditions involving joint inflammation. The two most common types are Osteoarthritis (wear-and-tear breakdown of cartilage) and Rheumatoid Arthritis (an autoimmune disease attacking joint linings).',
        causes: [
          'Osteoarthritis: Degeneration of joint cartilage due to aging, joint injury, or mechanical stress.',
          'Rheumatoid Arthritis: Autoimmune reaction targeting the synovium (joint membrane).',
          'Gout: Uric acid crystal deposits in joint fluid.'
        ],
        symptoms: [
          'Joint pain, aching, and tenderness',
          'Joint stiffness (especially morning stiffness lasting > 30 mins in RA)',
          'Swelling, redness, and warmth around affected joints',
          'Decreased range of motion and joint deformity'
        ],
        riskFactors: [
          'Increasing age and female gender',
          'Obesity (increases load on knees and hips)',
          'Previous joint injuries or repetitive joint strain'
        ],
        prevention: [
          'Maintain an ideal body weight to relieve excess pressure on weight-bearing joints',
          'Engage in low-impact exercises (swimming, cycling, walking)',
          'Protect joints from sports injuries or occupational strain'
        ],
        diagnosis: [
          'Joint X-rays / MRI scan',
          'Blood Tests: Rheumatoid Factor (RF), Anti-CCP, Erythrocyte Sedimentation Rate (ESR), Uric Acid'
        ],
        treatmentOverview: [
          'Pain relievers and NSAIDs',
          'Disease-Modifying Antirheumatic Drugs (DMARDs) for Rheumatoid Arthritis',
          'Physical therapy, joint injections, or Joint Replacement Surgery in end-stage cases'
        ],
        lifestyleTips: [
          'Apply hot packs for stiffness and cold packs for acute swelling',
          'Eat anti-inflammatory Mediterranean diet (rich in omega-3 fish oils, walnuts, turmeric)'
        ],
        whenToConsultDoctor: [
          'Joint swelling, warmth, or redness lasting several days',
          'Morning stiffness lasting longer than 1 hour'
        ],
        emergencyWarningSigns: [
          'Sudden severe hot red swollen joint accompanied by high fever (Septic Arthritis emergency)'
        ],
        faqs: [
          {
            question: 'Is exercise safe for arthritis patients?',
            answer: 'Yes! Low-impact exercise strengthens muscles around joints and decreases pain significantly.'
          }
        ]
      },
      Hindi: {
        name: 'अर्थराइटिस (गठिया / जोड़ों का दर्द)',
        category: 'जोड़ों का रोग',
        summary: 'जोड़ों में सूजन, दर्द, अकड़न और गतिशीलता में कमी की स्थिति।',
        whatIsIt: 'अर्थराइटिस एक या एक से अधिक जोड़ों में सूजन और दर्द की बीमारी है। इसके दो मुख्य प्रकार हैं: ऑस्टियोअर्थराइटिस (उम्र बढ़ने पर उपास्थि का घिसना) और रूमेटाइड अर्थराइटिस (ऑटोइम्यून बीमारी)।',
        causes: [
          'उम्र के साथ जोड़ों के कार्टिलेज का घिसना',
          'प्रतिरक्षा प्रणाली का जोड़ों पर हमला (रूमेटाइड अर्थराइटिस)',
          'यूरिक एसिड बढ़ना (गाउट/गठिया)'
        ],
        symptoms: [
          'जोड़ों में दर्द, सूजन और लालिमा होना',
          'सुबह के समय जोड़ों में अकड़न होना',
          'चलने-फिरने, उठने-बैठने में तकलीफ'
        ],
        riskFactors: [
          'बढ़ती उम्र और मोटापा',
          'जोड़ों में पुरानी चोट'
        ],
        prevention: [
          'वजन नियंत्रित रखें',
          'नियमित हल्का व्यायाम और स्विमिंग करें',
          'कैल्शियम और विटामिन डी युक्त आहार लें'
        ],
        diagnosis: [
          'एक्स-रे और एमआरआई',
          'आरए फैक्टर और यूरिक एसिड ब्लड टेस्ट'
        ],
        treatmentOverview: [
          'दर्द निवारक और एंटी-इन्फ्लेमेटरी दवाएं',
          'फिजियोथेरेपी और गंभीर मामलों में नी/हिप रिप्लेसमेंट सर्जरी'
        ],
        lifestyleTips: [
          'अकड़न में गरम सिकाई करें',
          'हल्दी और ओमेगा-3 युक्त आहार लें'
        ],
        whenToConsultDoctor: [
          'जोड़ों में लगातार सूजन और दर्द रहना'
        ],
        emergencyWarningSigns: [
          'जोड़ में अत्यधिक लालिमा, तेज दर्द और साथ में तेज बुखार (संक्रमण का खतरा)'
        ],
        faqs: [
          {
            question: 'क्या गठिया में व्यायाम कर सकते हैं?',
            answer: 'हां, हल्का व्यायाम जैसे टहलना और स्विमिंग जोड़ों की मांसपेशियों को मजबूत बनाता है।'
          }
        ]
      },
      Marathi: {
        name: 'आर्थरायटिस (सांधेदुखी / संधिवात)',
        category: 'सांध्यांचा आजार',
        summary: 'सांध्यांना सूज येणे, तीव्र वेदना होणे आणि सांधे ताठ होणे.',
        whatIsIt: 'संधिवात हा सांध्याशी संबंधित आजार आहे ज्यामध्ये सांध्यांमध्ये जळजळ आणि वेदना होतात.',
        causes: [
          'वय वाढल्यामुळे सांधे घिसणे किंवा ऑटोइम्यून आजार'
        ],
        symptoms: [
          'सांध्यांमध्ये वेदना व सूज',
          'सकाळी उठल्यावर सांधे ताठ होणे'
        ],
        riskFactors: [
          'लठ्ठपणा आणि वाढते वय'
        ],
        prevention: [
          'वजन नियंत्रणात ठेवा',
          'नियमित व्यायाम करा'
        ],
        diagnosis: [
          'एक्स-रे व रक्तचाचणी'
        ],
        treatmentOverview: [
          'औषधोपचार आणि फिजियोथेरपी'
        ],
        lifestyleTips: [
          'सांध्यांना गरम पाण्याचा शेक द्या'
        ],
        whenToConsultDoctor: [
          'सांधे दुखणे आणि सूज न उतरल्यास'
        ],
        emergencyWarningSigns: [
          'सांध्याला प्रचंड सूज आणि सोबत तीव्र ताप'
        ],
        faqs: [
          {
            question: 'सांधेदुखीवर काय खावे?',
            answer: 'कॅल्शियम, व्हिटॅमिन डी, बदाम आणि हिरव्या भाज्या खाव्यात.'
          }
        ]
      }
    }
  },

  // 13. Kidney Stones
  {
    id: 'kidney_stones',
    iconName: 'Droplet',
    category: 'Digestive',
    bgGradient: 'from-stone-600 to-amber-800',
    badgeBg: 'bg-stone-100',
    badgeText: 'text-stone-800 border-stone-300',
    content: {
      English: {
        name: 'Kidney Stones',
        category: 'Urinary Tract Disorder',
        summary: 'Hard mineral and salt deposits that form inside the kidneys causing severe flank and lower abdominal pain.',
        whatIsIt: 'Kidney stones (nephrolithiasis) are hard deposits made of minerals and salts (most commonly calcium oxalate) that form inside your kidneys when urine becomes concentrated.',
        causes: [
          'Chronic dehydration (insufficient daily water intake)',
          'Diets high in sodium, animal protein, and oxalates (spinach, nuts, chocolate)',
          'Family history, obesity, or metabolic conditions like hyperparathyroidism'
        ],
        symptoms: [
          'Severe, sharp pain in the side, back, and below the ribs (Renal Colic)',
          'Pain radiating to the lower abdomen and groin',
          'Pain or burning sensation during urination',
          'Pink, red, or brown blood in urine (Hematuria)',
          'Nausea, vomiting, and frequent urge to urinate'
        ],
        riskFactors: [
          'Not drinking enough water (especially in hot climates)',
          'High salt diet and excessive animal protein intake'
        ],
        prevention: [
          'Drink 2.5 to 3 liters of fresh water throughout the day',
          'Reduce dietary sodium intake to < 2,000 mg/day',
          'Squeeze fresh lemon juice into water (citrate inhibits stone formation)'
        ],
        diagnosis: [
          'Non-contrast CT Scan of Abdomen/Pelvis (Gold standard)',
          'Kidney Ultrasound and Urinalysis'
        ],
        treatmentOverview: [
          'Small stones (< 5mm): Hydration, pain medications, and Alpha-blockers (e.g., Tamsulosin) to pass stone naturally',
          'Large stones (> 7mm): Extracorporeal Shock Wave Lithotripsy (ESWL), Ureteroscopy, or PCNL surgery'
        ],
        lifestyleTips: [
          'Monitor urine color: It should be pale and clear',
          'Limit spinach, beets, nuts, and tea if prone to calcium oxalate stones'
        ],
        whenToConsultDoctor: [
          'Severe flank pain that makes sitting still impossible',
          'Visible blood in urine'
        ],
        emergencyWarningSigns: [
          'Severe pain accompanied by high fever and chills (Urinary sepsis infection)',
          'Inability to pass urine at all (Complete urinary tract obstruction)'
        ],
        faqs: [
          {
            question: 'Should I avoid milk and calcium if I have kidney stones?',
            answer: 'No! Dietary calcium binds oxalate in the digestive tract, actually reducing stone risk. Do not restrict normal dairy calcium.'
          }
        ]
      },
      Hindi: {
        name: 'गुर्दे की पथरी (किडनी स्टोन)',
        category: 'मूत्र तंत्र विकार',
        summary: 'किडनी में खनिज और खनिजों के जमने से बनने वाले कठोर कण, जो पीठ और पेट में तेज दर्द करते हैं।',
        whatIsIt: 'गुर्दे की पथरी (किडनी स्टोन) खनिजों और नमक का एक ठोस जमाव है जो गुर्दे के अंदर बनता है। यह सबसे ज्यादा कम पानी पीने के कारण होता है।',
        causes: [
          'कम पानी पीना (शरीर में पानी की कमी होना)',
          'भोजन में अत्यधिक नमक, नॉनवेज और पालक/ऑक्सालेट का सेवन'
        ],
        symptoms: [
          'पीठ और पसलियों के नीचे तेज, अचानक दर्द होना (गुर्दे का दर्द)',
          'दर्द का पेट के निचले हिस्से और जांघों की तरफ फैलना',
          'पेशाब करते समय तेज जलन या दर्द होना',
          'पेशाब में खून आना (गुलाबी या लाल पेशाब)',
          'उल्टी और जी मिचलाना'
        ],
        riskFactors: [
          'कम पानी पीने की आदत',
          'अधिक नमक और प्रोसेस्ड खाना'
        ],
        prevention: [
          'प्रतिदिन 3 से 4 लीटर साफ पानी पीएं',
          'नींबू पानी पीएं (साइट्रेट पथरी बनने से रोकता है)',
          'नमक का सेवन कम करें'
        ],
        diagnosis: [
          'अल्ट्रासाउंड (USG) या सीटी स्कैन',
          'यूरिन टेस्ट'
        ],
        treatmentOverview: [
          'छोटी पथरी (< 5mm): भरपूर पानी, दर्द निवारक दवाएं और अल्फा ब्लॉकर्स',
          'बड़ी पथरी: लेजर या लिथोट्रिप्सी (ESWL) तकनीक से पथरी तोड़ना'
        ],
        lifestyleTips: [
          'पेशाब का रंग हल्का और साफ रखें',
          'नारियल पानी और नीबू पानी पीएं'
        ],
        whenToConsultDoctor: [
          'पीठ या पेट में तेज दर्द होना'
        ],
        emergencyWarningSigns: [
          'पेशाब बिलकुल बंद होना',
          'तेज दर्द के साथ तेज बुखार आना (इन्फेक्शन का संकेत)'
        ],
        faqs: [
          {
            question: 'क्या किडनी स्टोन में दूध पीना बंद कर देना चाहिए?',
            answer: 'नहीं, भोजन में प्राकृतिक कैल्शियम लेने से ऑक्सालेट पेट में ही बंध जाता है और पथरी का खतरा कम होता है।'
          }
        ]
      },
      Marathi: {
        name: 'किडनी स्टोन (मुतखडा)',
        category: 'मूत्रसंस्थेचा आजार',
        summary: 'मूत्रपिंडात खनिजे साचून तयार होणारे कडक खडे.',
        whatIsIt: 'मुतखडा हा क्षार आणि खनिजे साचून किडनीमध्ये तयार होणारा आजार आहे.',
        causes: [
          'कमी पाणी पिणे व आहारातील जास्त मीठ'
        ],
        symptoms: [
          'पाठ आणि पोटाच्या बाजूला तीव्र वेदना',
          'लघवी करताना जळजळ होणे',
          'लघवीतून रक्त जाणे'
        ],
        riskFactors: [
          'कमी पाणी पिण्याची सवय'
        ],
        prevention: [
          'दररोज ३-४ लिटर पाणी प्या',
          'लिंबू पाणी प्या',
          'मिठाचे प्रमाण कमी करा'
        ],
        diagnosis: [
          'सोनाग्राफी (Ultrasound) व CT Scan'
        ],
        treatmentOverview: [
          'भरपूर पाणी पिणे व औषधे',
          'मोठे खडे असल्यास लेझर किंवा शस्त्रक्रिया'
        ],
        lifestyleTips: [
          'नारळ पाणी आणि पाणी भरपूर प्या'
        ],
        whenToConsultDoctor: [
          'तीव्र वेदना व लघवीतून रक्त आल्यास'
        ],
        emergencyWarningSigns: [
          'लघवी पूर्णपणे बंद होणे व ताप येणे'
        ],
        faqs: [
          {
            question: 'मुतखडा निघून जाण्यासाठी काय करावे?',
            answer: 'भरपूर पाणी आणि डॉक्टरांच्या सल्ल्याने लघवी साफ होण्याची औषधे घ्यावीत.'
          }
        ]
      }
    }
  },

  // 14. Gastric Ulcer
  {
    id: 'gastric_ulcer',
    iconName: 'Flame',
    category: 'Digestive',
    bgGradient: 'from-rose-600 to-pink-700',
    badgeBg: 'bg-rose-50',
    badgeText: 'text-rose-700 border-rose-200',
    content: {
      English: {
        name: 'Gastric Ulcer (Peptic Ulcer)',
        category: 'Gastrointestinal Condition',
        summary: 'Painful sores on the inner lining of the stomach or duodenum caused by stomach acid damage.',
        whatIsIt: 'Gastric ulcers are open sores that develop on the inside lining of your stomach. They occur when the thick protective mucus layer that protects your stomach from digestive juices is reduced.',
        causes: [
          'Helicobacter pylori (H. pylori) bacterial infection.',
          'Long-term use of Nonsteroidal Anti-inflammatory Drugs (NSAIDs) like Ibuprofen, Aspirin, Naproxen.',
          'Excess stomach acid production exacerbated by stress, smoking, and alcohol.'
        ],
        symptoms: [
          'Burning stomach pain in upper abdomen (between navel and breastbone)',
          'Pain worsens on an empty stomach or at night',
          'Feeling of fullness, bloating, or belching',
          'Heartburn, indigestion, and mild nausea'
        ],
        riskFactors: [
          'Frequent painkiller (NSAID) use',
          'Smoking tobacco and heavy alcohol drinking',
          'Unmanaged high psychological stress'
        ],
        prevention: [
          'Avoid overuse of over-the-counter NSAID painkillers',
          'Wash hands thoroughly to prevent H. pylori infection',
          'Limit alcohol and quit smoking'
        ],
        diagnosis: [
          'Upper Gastrointestinal Endoscopy (UGI Endoscopy)',
          'H. pylori Stool Antigen Test or Urea Breath Test'
        ],
        treatmentOverview: [
          'Proton Pump Inhibitors (PPIs) like Omeprazole, Pantoprazole to reduce acid',
          'H. pylori Eradication Antibiotic Triple Therapy if infection present',
          'Antacids and mucosal protective agents (Sucralfate)'
        ],
        lifestyleTips: [
          'Eat smaller, more frequent meals instead of heavy delayed feasts',
          'Avoid spicy, acidic, greasy foods and caffeine'
        ],
        whenToConsultDoctor: [
          'Persistent burning stomach pain lasting weeks',
          'Unexplained weight loss and loss of appetite'
        ],
        emergencyWarningSigns: [
          'Vomiting blood or dark "coffee-ground" material',
          'Passing black, tarry stools (Melena)',
          'Sudden severe sharp, unrelenting stomach pain (perforated stomach wall)'
        ],
        faqs: [
          {
            question: 'Does spicy food cause stomach ulcers?',
            answer: 'Spicy food does not cause ulcers directly (H. pylori and painkillers do), but spicy food can irritate existing ulcers.'
          }
        ]
      },
      Hindi: {
        name: 'पेट का अल्सर (गैस्ट्रिक अल्सर)',
        category: 'पाचन तंत्र रोग',
        summary: 'पेट की भीतरी दीवार में एसिड के कारण होने वाले दर्दनाक घाव (अल्सर)।',
        whatIsIt: 'पेट का अल्सर (गैस्ट्रिक अल्सर) पेट की अंदरूनी परत में होने वाला घाव है। जब पेट का तेजाब (एसिड) पेट की सुरक्षात्मक परत को नुकसान पहुंचाता है, तब अल्सर बनता है।',
        causes: [
          'हेलिकोबैक्टर पायलोरी (H. pylori) बैक्टीरिया का संक्रमण',
          'बिना डॉक्टर के पूछे लंबे समय तक दर्द निवारक (पेनकिलर) दवाएं लेना',
          'अत्यधिक शराब, धूम्रपान और मिर्च-मसालेदार खाना'
        ],
        symptoms: [
          'पेट के ऊपरी हिस्से में तेज जलन या दर्द (खासकर खाली पेट)',
          'पेट फूलना, खट्टी डकारें आना और सीने में जलन',
          'जी मिचलाना और जल्दी पेट भरा महसूस होना'
        ],
        riskFactors: [
          'ज्यादा पेनकिलर खाना',
          'धूम्रपान और शराब'
        ],
        prevention: [
          'बिना जरूरत पेनकिलर गोलियां न खाएं',
          'मिर्च-मसालेदार और अधिक अम्लीय (एसिडिक) खाने से बचें',
          'समय पर खाना खाएं'
        ],
        diagnosis: [
          'अपर जीआई एंडोस्कोपी (Endoscopy)',
          'एच पायलोरी टेस्ट'
        ],
        treatmentOverview: [
          'एसिड कम करने वाली दवाएं (एंटासिड, ओमेप्राजोल, पेंटाप्राजोल)',
          'एच पायलोरी संक्रमण के लिए एंटीबायोटिक कोर्स'
        ],
        lifestyleTips: [
          'एक बार में ज्यादा खाने के बजाय थोड़ा-थोड़ा करके खाएं',
          'रात को खाना खाकर तुरंत न सोएं'
        ],
        whenToConsultDoctor: [
          'पेट में लगातार जलन और दर्द होना'
        ],
        emergencyWarningSigns: [
          'उल्टी में खून आना या कॉफी के रंग की उल्टी होना',
          'काला मल होना (आंतों से खून बहना)',
          'पेट में अचानक तेज असहाय दर्द होना'
        ],
        faqs: [
          {
            question: 'क्या ज्यादा मसालेदार खाना खाने से अल्सर होता है?',
            answer: 'मसालेदार खाना अल्सर का सीधा कारण नहीं है (बैक्टीरिया और पेनकिलर हैं), लेकिन यह बने हुए अल्सर के दर्द को बढ़ा देता है।'
          }
        ]
      },
      Marathi: {
        name: 'पोटातील अल्सर (गॅस्ट्रिक अल्सर)',
        category: 'पचनसंस्थेचा आजार',
        summary: 'पोटाच्या आतील स्तरात ॲसिडमुळे पडणारे व्रण (जखमा).',
        whatIsIt: 'पोटातील अल्सर हा पोटाच्या आतील भागातील जखम आहे, जो तीव्र ॲसिडमुळे होतो.',
        causes: [
          'एच पायलोरी (H. pylori) जिवाणू संसर्ग',
          'जास्त वेदनाशामक (Painkillers) गोळ्या घेणे'
        ],
        symptoms: [
          'पोटात जळजळ आणि वेदना (विशेषतः उपाशीपोटी)',
          'छातीत जळजळ व छातीत मळमळ'
        ],
        riskFactors: [
          'पेनकिलर गोळ्यांचे व्यसन, धूम्रपान'
        ],
        prevention: [
          'विनाकारण वेदनाशामक गोळ्या घेऊ नका',
          'वेळेवर जेवण करा'
        ],
        diagnosis: [
          'एंडोस्कोपी (Endoscopy) चाचणी'
        ],
        treatmentOverview: [
          'ॲसिडिटी कमी करणारी औषधे व अँटीबायोटिक्स'
        ],
        lifestyleTips: [
          'तिखट व तेलकट पदार्थ टाळा'
        ],
        whenToConsultDoctor: [
          'पोटात सतत तीव्र जळजळ होत असल्यास'
        ],
        emergencyWarningSigns: [
          'उलटीतून रक्त पडणे किंवा काळी शौच होणे'
        ],
        faqs: [
          {
            question: 'अल्सरमध्ये काय खावे?',
            answer: 'दूध, सफरचंद, दलिया आणि हलका सात्विक आहार घ्यावा.'
          }
        ]
      }
    }
  },

  // 15. Anemia
  {
    id: 'anemia',
    iconName: 'Heart',
    category: 'General',
    bgGradient: 'from-red-500 to-rose-700',
    badgeBg: 'bg-red-50',
    badgeText: 'text-red-700 border-red-200',
    content: {
      English: {
        name: 'Anemia (Iron Deficiency)',
        category: 'Blood Disorder',
        summary: 'A condition in which blood lacks adequate healthy red blood cells or hemoglobin to carry oxygen to tissues.',
        whatIsIt: 'Anemia occurs when your blood has a lower than normal amount of healthy red blood cells or hemoglobin. Hemoglobin is an iron-rich protein in red blood cells that carries oxygen from lungs to the rest of the body.',
        causes: [
          'Iron deficiency (most common worldwide cause).',
          'Vitamin deficiency (Vitamin B12 or Folate/Folic acid deficiency).',
          'Blood loss (heavy menstrual bleeding, stomach ulcers, hemorrhoids).',
          'Chronic diseases (kidney failure, cancer, inflammatory conditions).'
        ],
        symptoms: [
          'Persistent fatigue, exhaustion, and physical weakness',
          'Pale or yellowish skin, gums, and nail beds',
          'Shortness of breath with mild exertion',
          'Dizziness, lightheadedness, or cold hands and feet',
          'Brittle nails or unusual cravings for non-food items like ice/dirt (Pica)'
        ],
        riskFactors: [
          'Menstruating women and pregnant mothers',
          'Vegetarians/Vegans not eating iron-fortified foods',
          'Intestinal disorders affecting nutrient absorption (Celiac disease)'
        ],
        prevention: [
          'Eat iron-rich foods: Green leafy vegetables (spinach), lentils, jaggery, beetroot, red meat',
          'Pair iron foods with Vitamin C (lemons, oranges) to enhance absorption',
          'Avoid drinking tea/coffee immediately after meals (tannins block iron absorption)'
        ],
        diagnosis: [
          'Complete Blood Count (CBC): Hemoglobin level (< 12 g/dL in women, < 13 g/dL in men)',
          'Serum Ferritin, Iron, and Total Iron Binding Capacity (TIBC) tests',
          'Peripheral Blood Smear'
        ],
        treatmentOverview: [
          'Oral Iron Supplements (Ferrous sulfate/ascorbate)',
          'Vitamin B12 or Folic Acid supplements',
          'Treatment of underlying blood loss causes',
          'Blood Transfusion in severe life-threatening anemia (Hb < 7 g/dL)'
        ],
        lifestyleTips: [
          'Take iron supplements with citrus juice on an empty stomach',
          'Do not take iron supplements with milk, calcium, or antacids'
        ],
        whenToConsultDoctor: [
          'Unexplained fatigue despite adequate sleep',
          'Unusual pale skin tone and shortness of breath'
        ],
        emergencyWarningSigns: [
          'Severe chest pain, rapid pounding heart (palpitations), or fainting',
          'Severe acute blood loss'
        ],
        faqs: [
          {
            question: 'Why does tea block iron absorption?',
            answer: 'Tea and coffee contain tannins and polyphenols that bind to non-heme iron in food, preventing it from being absorbed in the intestine.'
          }
        ]
      },
      Hindi: {
        name: 'एनीमिया (खून की कमी)',
        category: 'रक्त विकार',
        summary: 'शरीर में लाल रक्त कोशिकाओं या हीमोग्लोबिन की कमी, जिससे अंगों तक पर्याप्त ऑक्सीजन नहीं पहुंच पाती।',
        whatIsIt: 'एनीमिया तब होता है जब आपके शरीर में स्वस्थ लाल रक्त कोशिकाओं या हीमोग्लोबिन की कमी हो जाती है। हीमोग्लोबिन फेफड़ों से शरीर के सभी अंगों तक ऑक्सीजन पहुंचाता है।',
        causes: [
          'आयरन (लोहे) की कमी (सबसे मुख्य कारण)',
          'विटामिन B12 और फोलिक एसिड की कमी',
          'अत्यधिक खून बहना (मासिक धर्म, बवासीर, अल्सर)',
          'पोषक तत्वों की कमी वाला आहार'
        ],
        symptoms: [
          'अत्यधिक थकान, सुस्ती और कमजोरी महसूस होना',
          'चेहरा, आंखें और नाखून पीले पड़ना',
          'थोड़ा काम करने पर सांस फूलना और चक्कर आना',
          'हाथ-पैर ठंडे रहना'
        ],
        riskFactors: [
          'महिलाएं और गर्भवती माताएं',
          'संतुलित आहार न लेना'
        ],
        prevention: [
          'आयरन से भरपूर भोजन लें: गुड़, चना, पालक, चुकंदर, अनार और दालें',
          'आयरन के अवशोषण के लिए नीम्बू/विटामिन सी लें',
          'खाना खाने के तुरंत बाद चाय या कॉफी न पीएं'
        ],
        diagnosis: [
          'सीबीसी (CBC) टेस्ट - हीमोग्लोबिन (Hb) का स्तर जांचना',
          'सिरम फेरिटिन टेस्ट'
        ],
        treatmentOverview: [
          'डॉक्टर की सलाह से आयरन की गोलियां या सिरप',
          'विटामिन B12 और फोलिक एसिड सप्लीमेंट्स'
        ],
        lifestyleTips: [
          'गुड़ और भुने चने खाएं',
          'आयरन की गोली को नींबू पानी के साथ लें'
        ],
        whenToConsultDoctor: [
          'लगातार थकान रहना और रंग पीला पड़ना'
        ],
        emergencyWarningSigns: [
          'छाती में दर्द होना, धड़कन तेज होना या बेहोश होकर गिरना'
        ],
        faqs: [
          {
            question: 'हीमोग्लोबिन जल्दी कैसे बढ़ाएं?',
            answer: 'आयरन की गोलियों के साथ पालक, चुकंदर, गुड़, खजूर और नींबू पानी का नियमित सेवन करें।'
          }
        ]
      },
      Marathi: {
        name: 'ॲनिमिया (रक्तक्षय)',
        category: 'रक्ताचा आजार',
        summary: 'रक्तातील हीमोग्लोबिन किंवा लाल रक्तपेशींची कमतरता.',
        whatIsIt: 'ॲनिमिया म्हणजे शरीरात रक्ताची कमतरता निर्माण होणे, ज्यामुळे ऑक्सिजन वहन कमी होते.',
        causes: [
          'लोहाची (Iron) कमतरता आणि व्हिटॅमिन B12 ची कमतरता'
        ],
        symptoms: [
          'अतिशय थकवा व अशक्तपणा',
          'त्वचा व नखे पिवळी/पांढरी पडणे',
          'श्वास फुलणे व चक्कर येणे'
        ],
        riskFactors: [
          'स्त्रिया, गरोदर माता व कुपोषण'
        ],
        prevention: [
          'पालक, गूळ, बीट, डाळिंब व खजूर खा',
          'जेवणानंतर लगेच चहा पिणे टाळा'
        ],
        diagnosis: [
          'CBC चाचणी (हीमोग्लोबिन तपासणी)'
        ],
        treatmentOverview: [
          'लोहाच्या गोळ्या व व्हिटॅमिन सप्लीमेंट्स'
        ],
        lifestyleTips: [
          'गूळ व फुटाणे खा'
        ],
        whenToConsultDoctor: [
          'सतत अशक्तपणा आणि चक्कर येत असल्यास'
        ],
        emergencyWarningSigns: [
          'छातीत दुखणे व चक्कर येऊन पडणे'
        ],
        faqs: [
          {
            question: 'रक्त वाढवण्यासाठी काय खावे?',
            answer: 'हिरव्या पालेभाज्या, बीट, खजूर आणि लोहाच्या गोळ्या घ्याव्यात.'
          }
        ]
      }
    }
  }
];
