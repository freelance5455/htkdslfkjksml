export interface PresetProduct {
  name: string;
  url: string;
  category: string;
  offer: string;
  hookStyle: string;
  persona: string;
  tone: string;
  imageUrl: string;
  sampleBenefits: string[];
}

export const PRESET_PRODUCTS: PresetProduct[] = [
  {
    name: 'GlowPeptide Barrier Glaze',
    url: 'https://example.com/glow-peptide',
    category: 'Beauty & Skincare',
    offer: 'Code GLOW20 for 20% OFF + Free Lip Oil',
    hookStyle: 'Stop Scrolling Hook',
    persona: 'Gen-Z Beauty Creator',
    tone: 'Hyper-enthusiastic, authentic, bestie vibe',
    imageUrl: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80',
    sampleBenefits: [
      'Instant glass-skin shine without stickiness',
      'Plumps fine lines in under 3 minutes',
      'Clinically tested peptide-hyaluronic matrix',
      'Dermatologist approved for sensitive skin'
    ]
  },
  {
    name: 'MagCharge 3-in-1 Foldable Orbit',
    url: 'https://example.com/magcharge-orbit',
    category: 'Tech & Gadgets',
    offer: 'Limited Stock: 40% OFF with code TECH40',
    hookStyle: 'Problem-Solution Hook',
    persona: 'Everyday Tech Reviewer',
    tone: 'Direct, honest, punchy, sleek',
    imageUrl: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=600&q=80',
    sampleBenefits: [
      'Replaces 3 messy cables on your nightstand',
      'Fast 15W Qi2 wireless charging with snap-alignment',
      'Folds down to the size of a wallet for travel',
      'Aircraft-grade aerospace aluminum build'
    ]
  },
  {
    name: 'HydroMist Nano Hydrogen Water Bottle',
    url: 'https://example.com/hydromist',
    category: 'Fitness & Wellness',
    offer: 'Code HYDRATE for Buy 1 Get 1 50% OFF',
    hookStyle: 'TikTok Made Me Buy It',
    persona: 'Aesthetic Wellness Guru',
    tone: 'Calm yet convincing, scientific yet simple',
    imageUrl: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=600&q=80',
    sampleBenefits: [
      'Infuses 3000 PPB molecular hydrogen in 3 minutes',
      'Reduces post-workout oxidative fatigue',
      'Self-cleaning UV-C titanium chamber',
      'Zero ozone and chlorine byproduct SPE/PEM tech'
    ]
  },
  {
    name: 'CloudFoam Ergo Slippers',
    url: 'https://example.com/cloudfoam-slides',
    category: 'Fashion & Apparel',
    offer: 'Free Express Shipping with code CLOUD',
    hookStyle: 'Contrarian Hook',
    persona: 'Relatable Storyteller',
    tone: 'Fun, relatable, conversational, shock-factor',
    imageUrl: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=600&q=80',
    sampleBenefits: [
      '4.5cm compression-molded EVA sole',
      'Instantly relieves heel and plantar pressure',
      'Waterproof, non-slip textured safety base',
      'Feels like walking on actual marshmallows'
    ]
  }
];

export interface CreatorAvatar {
  id: string;
  name: string;
  handle: string;
  role: string;
  avatarUrl: string;
  recommendedVoice: string;
  badge: string;
}

export const CREATOR_AVATARS: CreatorAvatar[] = [
  {
    id: 'maya_genz',
    name: 'Maya Lin',
    handle: '@mayalifestyle',
    role: 'Gen-Z Trendsetter',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=240&h=240&q=80',
    recommendedVoice: 'Kore',
    badge: 'VIRAL HOOK'
  },
  {
    id: 'liam_tech',
    name: 'Liam Vance',
    handle: '@liamunbox',
    role: 'Tech & Gadgets',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=240&h=240&q=80',
    recommendedVoice: 'Puck',
    badge: 'UNBOXING'
  },
  {
    id: 'chloe_beauty',
    name: 'Chloe Rivera',
    handle: '@chloeglow',
    role: 'Beauty & Skincare',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=240&h=240&q=80',
    recommendedVoice: 'Zephyr',
    badge: 'TUTORIAL'
  },
  {
    id: 'marcus_fitness',
    name: 'Marcus Cole',
    handle: '@marcusfit',
    role: 'Fitness & Energy',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=240&h=240&q=80',
    recommendedVoice: 'Fenrir',
    badge: 'HIGH ENERGY'
  },
  {
    id: 'elena_founder',
    name: 'Elena Rostova',
    handle: '@elenafounder',
    role: 'Brand Founder',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=240&h=240&q=80',
    recommendedVoice: 'Charon',
    badge: 'BEHIND SCENES'
  }
];

export interface VoiceModelOption {
  id: string;
  name: string;
  gender: 'Female' | 'Male';
  vibe: string;
  tempo: string;
}

export const GEMINI_VOICES: VoiceModelOption[] = [
  { id: 'Kore', name: 'Kore', gender: 'Female', vibe: 'Bright, energetic, viral TikTok creator', tempo: 'Fast & Punchy' },
  { id: 'Puck', name: 'Puck', gender: 'Male', vibe: 'Playful, tech-savvy, youth reviewer', tempo: 'Dynamic' },
  { id: 'Zephyr', name: 'Zephyr', gender: 'Female', vibe: 'Warm, trustworthy, conversational bestie', tempo: 'Smooth' },
  { id: 'Fenrir', name: 'Fenrir', gender: 'Male', vibe: 'Deep, authoritative, bold direct-response', tempo: 'Strong' },
  { id: 'Charon', name: 'Charon', gender: 'Male', vibe: 'Relaxed, confident, authentic storyteller', tempo: 'Natural' }
];

export const HOOK_STYLES = [
  { id: 'stop_scrolling', name: 'Stop Scrolling', tag: '0-3s Pattern Interrupt', example: 'Stop scrolling if you hate...' },
  { id: 'tiktok_made_me', name: 'TikTok Made Me Buy It', tag: 'Social Proof', example: 'I tested the viral...' },
  { id: 'problem_solution', name: 'Problem Callout', tag: 'Direct Response', example: 'If you struggle with...' },
  { id: 'why_no_talking', name: 'Curiosity Secret', tag: 'High CTR', example: 'Why is NO ONE talking about this?!' },
  { id: 'contrarian', name: 'Don\'t Buy This Unless', tag: 'Reverse Psychology', example: 'Do NOT buy this until you know...' }
];
