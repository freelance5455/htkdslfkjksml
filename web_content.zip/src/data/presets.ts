import { SamplePreset } from '../types';

export const SAMPLE_PRESETS: SamplePreset[] = [
  {
    id: 'gothic-clocktower',
    title: 'The Mist-Drowned Spire',
    genre: 'Gothic Victorian Mystery',
    tone: 'Melancholic, Suspenseful & Poetic',
    promptHint: 'An antique copper key turns in a cathedral lock as midnight tolls across the fog.',
    imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'cyberpunk-neon',
    title: 'Sub-Level Rain of Neo-Kyoto',
    genre: 'Cyberpunk Noir',
    tone: 'Gritty, Electric & Weary',
    promptHint: 'Flickering holographic advertisements reflect in oil slicks where a cybernetic courier waits.',
    imageUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'ancient-sanctuary',
    title: 'The Coral Sunken Temple',
    genre: 'Mythic Fantasy & Wonder',
    tone: 'Ethereal, Reverent & Ancient',
    promptHint: 'Submerged runes hum with biophotonic green light as tidal currents whisper forgotten oaths.',
    imageUrl: 'https://images.unsplash.com/photo-1518709766631-a6a7f45921c3?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'boreal-observatory',
    title: 'The Polar Ridge Outpost',
    genre: 'Cosmic Horror & Isolation',
    tone: 'Chilling, Solitary & Foreboding',
    promptHint: 'The barometer drops through the glass floor as a radio receiver catches a rhythmic pulse from deep ice.',
    imageUrl: 'https://images.unsplash.com/photo-1483921020237-2ff51e8e4b22?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'salt-dunes',
    title: 'Nomads of the Glass Sea',
    genre: 'Post-Apocalyptic Speculative',
    tone: 'Sun-bleached, Rugged & Mystical',
    promptHint: 'Solar skiffs skim across crystallized salt plains carrying relics of a forgotten ocean.',
    imageUrl: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=1200&q=80',
  },
];

export const VOICE_OPTIONS = [
  {
    id: 'Kore' as const,
    name: 'Kore',
    gender: 'Female' as const,
    description: 'Warm, lyrical, and cinematic with nuanced emotional cadence.',
    bestFor: 'Literary fiction, fantasy, emotional drama',
  },
  {
    id: 'Puck' as const,
    name: 'Puck',
    gender: 'Male' as const,
    description: 'Energetic, spirited, and expressive with rapid spark.',
    bestFor: 'Adventure, speculative mystery, brisk dialogue',
  },
  {
    id: 'Fenrir' as const,
    name: 'Fenrir',
    gender: 'Male' as const,
    description: 'Deep, resonant, gritty, and portentous timber.',
    bestFor: 'Gothic horror, epic dark fantasy, noir',
  },
  {
    id: 'Charon' as const,
    name: 'Charon',
    gender: 'Male' as const,
    description: 'Grave, ancient, steady, and weathered tone.',
    bestFor: 'Historical epics, cosmic chronicles, solemn lore',
  },
  {
    id: 'Zephyr' as const,
    name: 'Zephyr',
    gender: 'Female' as const,
    description: 'Intimate, breathy, gentle, and introspective murmur.',
    bestFor: 'Poetry, magical realism, internal monologues',
  },
];

export const VOICE_STYLES = [
  {
    label: 'Cinematic Audiobook',
    prompt: 'Expressive, evocative story narrator with dramatic pauses, deep resonance, and rich emotional cadence.',
  },
  {
    label: 'Dark & Whispered Tension',
    prompt: 'Intimate, slow, atmospheric whisper with suspenseful breath and chilling subtext.',
  },
  {
    label: 'Grand Bardic Epic',
    prompt: 'Bold, theatrical, soaring story chronicler with rhythmic cadence and grand cadence.',
  },
  {
    label: 'Nocturnal Noir Detective',
    prompt: 'Gravelly, weary, reflective first-person voice with cigarette smoke cadence and bitter irony.',
  },
];
