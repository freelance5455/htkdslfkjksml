import { ProductPreset } from '../types';

export const PRODUCT_PRESETS: ProductPreset[] = [
  {
    id: 'lumina-serum',
    title: 'Lumina Botanical Glow Serum',
    brand: 'Lumina Skin Lab',
    url: 'https://luminaskinlab.com/products/botanical-glow-serum',
    description:
      'Ultra-concentrated cold-pressed botanical facial oil with Vitamin C, Bakuchiol, and Rosehip for 72-hour deep cellular hydration and natural luminous radiance. Non-comedogenic and 100% vegan.',
    theme: 'Minimalist Luxury Studio',
    tone: 'Elegant, High-End, Rejuvenating',
    primaryColor: '#B45309', // Warm bronze/gold
    badge: 'NEW FORMULA • 20% OFF',
    sampleImage: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'aura-headphones',
    title: 'Aura Nova Pro Wireless Headphones',
    brand: 'Aura Acoustics',
    url: 'https://aura-acoustics.com/products/nova-pro-anc',
    description:
      'Engineered with 45mm custom graphene acoustic drivers, hybrid active noise cancellation up to 42dB, ultra-low latency wireless audio, and 55 hours battery life with fast Qi charging.',
    theme: 'Sleek Cybernetic Tech',
    tone: 'Innovative, Bold, Audiophile',
    primaryColor: '#0284C7', // Electric cyan/blue
    badge: 'LIMITED EDITION • FREE SHIPPING',
    sampleImage: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'peak-coffee',
    title: 'PeakOrigin Single-Origin Reserve Cold Brew',
    brand: 'PeakOrigin Roasters',
    url: 'https://peakoriginroasters.com/reserve-coldbrew',
    description:
      'Small-batch Ethiopian Yirgacheffe coffee beans slow-steeped for 24 hours at 4°C. Notes of bergamot, dark chocolate, and wildflower honey with zero bitterness and velvety mouthfeel.',
    theme: 'Artisanal Organic Craft',
    tone: 'Warm, Authentic, Gourmet',
    primaryColor: '#78350F', // Rich dark roast amber
    badge: 'CRAFT ROASTED • BESTSELLER',
    sampleImage: 'https://images.unsplash.com/photo-1517256064527-09c73fc73e38?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'pulse-watch',
    title: 'Veloce Pulse X Smartwatch',
    brand: 'Veloce Performance',
    url: 'https://veloceactive.com/pulse-x-gps',
    description:
      'Aerospace titanium multisport GPS smartwatch with biometric VO2 max tracking, offline topo maps, solar sapphire crystal lens, and 100-meter water resistance for elite endurance athletes.',
    theme: 'High Performance Athletic',
    tone: 'Dynamic, High-Energy, Precision',
    primaryColor: '#EA580C', // Energetic coral orange
    badge: 'SAVE $70 TODAY • RISK-FREE',
    sampleImage: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=80',
  },
];
