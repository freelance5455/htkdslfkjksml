import { StationEvent } from '../types/game';

export const RANDOM_EVENTS_POOL: StationEvent[] = [
  {
    id: 'evt-plantao-meteoro',
    title: 'PLANTÃO URGENTE: Fenômeno no Céu da Capital!',
    description: 'Moradores relatam uma bola de fogo misteriosa cruzando o horizonte. Entrar com a vinheta do plantão imediatamente e interromper a transmissão?',
    category: 'breaking',
    icon: 'Flame',
    choices: [
      {
        text: 'Chamar Vinheta do Plantão e Transmitir ao Vivo!',
        effectDescription: 'Pico estrondoso de audiência (+8.0 pts), mas gasta R$ 3.000 em equipe extra.',
        apply: () => ({
          message: 'O plantão foi um sucesso absurdo! O país inteiro parou para ver a bola de fogo.',
          moneyDelta: -3000,
          ibopeDelta: 8.5,
          repDelta: 4,
        }),
      },
      {
        text: 'Ignorar e Manter a Programação Normal',
        effectDescription: 'Evita custos, mas o público migra para a concorrência (-2.0 pts).',
        apply: () => ({
          message: 'A concorrência deu o furo antes de você e comemorou a liderança do IBOPE.',
          moneyDelta: 0,
          ibopeDelta: -2.0,
          repDelta: -2,
        }),
      },
    ],
  },
  {
    id: 'evt-bastidores-salario',
    title: 'Bafafá nos Bastidores: Exigência de Camarim Luxuoso!',
    description: 'Sua estrela principal ameaça não entrar em cena se não receber toalhas egípcias e um aumento no cachê.',
    category: 'backstage',
    icon: 'Drama',
    choices: [
      {
        text: 'Ceder aos Caprichos (Pagar R$ 5.000)',
        effectDescription: 'A estrela atua com paixão e carisma máximo (+4.0 pts na atração).',
        apply: () => ({
          message: 'A estrela gravou a cena mais emocionante do ano. O público foi às lágrimas!',
          moneyDelta: -5000,
          ibopeDelta: 4.0,
          repDelta: 2,
        }),
      },
      {
        text: 'Bater na Mesa e Cortar o Choro!',
        effectDescription: 'Economiza verba, mas a estrela atua desanimada (-3.0 pts).',
        apply: () => ({
          message: 'O programa foi ao ar com um climão pesado nos bastidores.',
          moneyDelta: 0,
          ibopeDelta: -3.0,
          repDelta: -1,
        }),
      },
    ],
  },
  {
    id: 'evt-patrocinador-gafe',
    title: 'Gafe Publicitária ao Vivo!',
    description: 'Durante o intervalo, o apresentador esqueceu o microfone aberto e disse: "Esse suco parece remédio de tosse". O patrocinador está ligando enfurecido!',
    category: 'sponsor',
    icon: 'AlertTriangle',
    choices: [
      {
        text: 'Pedir Desculpas ao Vivo e Oferecer Merchandising Duplo',
        effectDescription: 'Perde R$ 4.000 em espaço comercial, mas preserva a reputação.',
        apply: () => ({
          message: 'O apresentador fez uma piada, bebeu três copos na marra e o cliente perdoou.',
          moneyDelta: -4000,
          ibopeDelta: 1.5,
          repDelta: 3,
        }),
      },
      {
        text: 'Dizer que Era Piada e Ignorar a Reclamação',
        effectDescription: 'Multa de R$ 6.000 por quebra de cláusula moral contratual.',
        apply: () => ({
          message: 'O patrocinador cancelou parte das cotas e o departamento jurídico foi acionado.',
          moneyDelta: -6000,
          ibopeDelta: 0,
          repDelta: -4,
        }),
      },
    ],
  },
  {
    id: 'evt-novela-vilao',
    title: 'Reviravolta na Novela: O Vilão Virou Queridinho!',
    description: 'As pesquisas mostram que o público odeia o mocinho certinho e ama o vilão carismático. Os roteiristas pedem autorização para reescrever o final!',
    category: 'backstage',
    icon: 'HeartCrack',
    choices: [
      {
        text: 'Mudar o Roteiro! O Vilão Deve Vencer!',
        effectDescription: 'Custo de refilmagem R$ 7.000, mas a audiência vai explodir (+6.5 pts).',
        apply: () => ({
          message: 'A cena final quebrou a internet! O IBOPE bateu recordes históricos!',
          moneyDelta: -7000,
          ibopeDelta: 6.5,
          repDelta: 5,
        }),
      },
      {
        text: 'Manter a Moral Tradicional: O Bem Vence o Mal',
        effectDescription: 'Final clichê sem custos extras (+1.0 pt regular).',
        apply: () => ({
          message: 'Final morno, mas os patrocinadores tradicionais aprovaram o bom comportamento.',
          moneyDelta: 0,
          ibopeDelta: 1.0,
          repDelta: 1,
        }),
      },
    ],
  },
  {
    id: 'evt-auditorio-invasao',
    title: 'Invasão no Palco do Auditório!',
    description: 'Um espectador da caravana de Osasco pulou no palco no meio da gincana com uma fantasia de galinha dançarina!',
    category: 'breaking',
    icon: 'Smile',
    choices: [
      {
        text: 'Tocar a Música e Dançar Junto com a Galinha!',
        effectDescription: 'Gera um meme nacional instantâneo (+5.0 pts de audiência)!',
        apply: () => ({
          message: 'A dancinha da galinha virou febre no país todo! Auditório em delírio!',
          moneyDelta: 1500,
          ibopeDelta: 5.2,
          repDelta: 4,
        }),
      },
      {
        text: 'Seguranças no Palco e Cortar para os Comerciais',
        effectDescription: 'Comportamento profissional, sem risco (-1.0 pt).',
        apply: () => ({
          message: 'O corte rápido para o comercial evitou confusão, mas perdeu o entretenimento.',
          moneyDelta: 800,
          ibopeDelta: -1.0,
          repDelta: 0,
        }),
      },
    ],
  },
];
