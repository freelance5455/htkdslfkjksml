import { Skill } from '../types';

export const INITIAL_SKILLS: Skill[] = [
  {
    id: 'planche',
    name: 'Planche',
    subtitle: 'Supreme Straight-Arm Pushing Isometric',
    category: 'push',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    imagePath: '/src/assets/images/planche_skill_1790336455351.jpg',
    levels: [
      {
        level: 1,
        name: 'Planche Lean',
        description: 'Shoulders leaned far in front of wrists in a straight arm push-up position, building bicep tendon resilience and scapular protraction.',
        targetHoldSec: 30,
        trainingExercises: ['Planche Lean', 'Pseudo Planche Push-Up', 'Scapular Push-Up'],
        formCues: ['Locked elbows', 'Full scapular protraction (push floor away)', 'Posterior pelvic tilt']
      },
      {
        level: 2,
        name: 'Tuck Planche',
        description: 'Elevating the body completely off the floor with knees tucked tightly under the chest and hips level with shoulders.',
        targetHoldSec: 15,
        trainingExercises: ['Tuck Planche Holds', 'Tuck Planche Push-Ups', 'Planche Lean (Weighted)'],
        formCues: ['Do not bend elbows even 1 degree', 'Hips elevated to shoulder height', 'Spread shoulder blades']
      },
      {
        level: 3,
        name: 'Advanced Tuck Planche',
        description: 'Knees pushed back until thighs form a 90-degree angle with the torso and back is completely flat horizontal.',
        targetHoldSec: 12,
        trainingExercises: ['Adv Tuck Planche Rocks', 'Pseudo Planche Push-Ups', 'Band-Assisted Planche'],
        formCues: ['Flat lower back', 'Open hip angle beyond 90 degrees', 'Forward shoulder lean']
      },
      {
        level: 4,
        name: 'Straddle Planche',
        description: 'Legs fully extended outward in a wide straddle, shortening the center of gravity while maintaining horizontal hold.',
        targetHoldSec: 8,
        trainingExercises: ['Straddle Planche Negative', 'Straddle Planche Presses', 'Parallette Holds'],
        formCues: ['Point toes', 'Lock knees completely', 'Lean further forward than feels possible']
      },
      {
        level: 5,
        name: 'Full Planche',
        description: 'The holy grail of bodyweight gymnastics: legs together, perfectly straight body floating horizontally parallel to earth.',
        targetHoldSec: 5,
        trainingExercises: ['Full Planche Negatives', 'Eccentric Drops', 'Daily Tendon Conditioning'],
        formCues: ['Squeeze legs together', 'Straight arm lock', 'True horizontal alignment']
      }
    ]
  },
  {
    id: 'frontlever',
    name: 'Front Lever',
    subtitle: 'Ultimate Straight-Arm Pulling Strength',
    category: 'pull',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    imagePath: '/src/assets/images/front_lever_skill_1790336440114.jpg',
    levels: [
      {
        level: 1,
        name: 'Tuck Front Lever',
        description: 'Knees tucked into chest while holding torso completely horizontal underneath the bar with straight locked arms.',
        targetHoldSec: 25,
        trainingExercises: ['Tuck Front Lever Hold', 'Tuck Front Lever Rows', 'Scapular Pull-Ups'],
        formCues: ['Depress and retract scapula', 'Elbows fully locked', 'Hips horizontal with shoulders']
      },
      {
        level: 2,
        name: 'Advanced Tuck Front Lever',
        description: 'Extending knees away from chest so thighs are perpendicular (90 degrees) and back is flat horizontal.',
        targetHoldSec: 15,
        trainingExercises: ['Adv Tuck Holds', 'Adv Tuck Pulls', 'Dragon Flags'],
        formCues: ['Flat back (no rounded thoracic)', 'Lats firing intensely', 'Keep head neutral']
      },
      {
        level: 3,
        name: 'One-Leg Front Lever',
        description: 'One leg extended straight while the other leg remains tucked, testing unilateral hip flexor and asymmetrical lat balance.',
        targetHoldSec: 12,
        trainingExercises: ['One-Leg Lever Holds', 'One-Leg Switchers', 'Hanging Straight Leg Raises'],
        formCues: ['Alternate legs equally', 'Lock extended knee', 'Keep torso parallel to floor']
      },
      {
        level: 4,
        name: 'Straddle Front Lever',
        description: 'Both legs extended out wide in a straddle, lowering the torque demand on the lats while maintaining full extension.',
        targetHoldSec: 10,
        trainingExercises: ['Straddle Lever Negatives', 'Band-Assisted Straddle', 'Weighted Pull-Ups'],
        formCues: ['Wide straddle for better leverage', 'Point toes', 'Drive hips up']
      },
      {
        level: 5,
        name: 'Full Front Lever',
        description: 'Perfect horizontal suspension under the bar with straight legs together and unbending iron torso.',
        targetHoldSec: 5,
        trainingExercises: ['Full Lever Negatives', '360 Pulls', 'Weighted Pull-Ups'],
        formCues: ['Head-to-toe laser-straight line', 'Maximum lat depression', 'Pointed toes']
      }
    ]
  },
  {
    id: 'backlever',
    name: 'Back Lever',
    subtitle: 'Posterior & Bicep Tendon Mastery',
    category: 'pull',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Tuck Back Lever / German Hang',
        description: 'Passing through skin-the-cat into a German Hang stretch and holding a tucked body facing toward the floor.',
        targetHoldSec: 25,
        trainingExercises: ['German Hang', 'Skin the Cat', 'Tuck Back Lever'],
        formCues: ['Gentle shoulder stretch', 'Breathe through chest', 'Engage core gently']
      },
      {
        level: 2,
        name: 'Advanced Tuck Back Lever',
        description: 'Opening knees to 90 degrees behind you, flattening the spine parallel to ground.',
        targetHoldSec: 15,
        trainingExercises: ['Adv Tuck Back Lever', 'Slow Skin the Cat', 'Arch Holds'],
        formCues: ['Flat back', 'Supinated or pronated grip depending on comfort', 'Lock elbows']
      },
      {
        level: 3,
        name: 'One-Leg Back Lever',
        description: 'Extending one leg completely straight back while keeping one knee tucked to the chest.',
        targetHoldSec: 12,
        trainingExercises: ['One-Leg Back Lever', 'Alternating Lever Switches', 'Back Extensions'],
        formCues: ['Keep hips level', 'Point toes', 'Strong bicep tendon engagement']
      },
      {
        level: 4,
        name: 'Straddle Back Lever',
        description: 'Extending both legs in a straddle while holding horizontal torso facing the ground.',
        targetHoldSec: 10,
        trainingExercises: ['Straddle Negatives', 'Band-Assisted Back Lever', 'Inverted Hang to Lever'],
        formCues: ['Spread legs wide', 'Squeeze glutes', 'Protract shoulder blades slightly']
      },
      {
        level: 5,
        name: 'Full Back Lever',
        description: 'Complete horizontal hold facing downward with feet together, straight arms, and hollowed back.',
        targetHoldSec: 8,
        trainingExercises: ['Full Lever Holds', 'Skin the Cat Pull-Outs'],
        formCues: ['Straight bodyline', 'Elbows locked', 'Control entry and exit']
      }
    ]
  },
  {
    id: 'lsit',
    name: 'L-Sit',
    subtitle: 'Pike Compression & Tricep Depressor',
    category: 'core',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Tuck L-Sit',
        description: 'Hands pressing into floor or parallettes, shoulders depressed, knees tucked up against chest with feet suspended.',
        targetHoldSec: 30,
        trainingExercises: ['Tuck Hold on Parallettes', 'Seated Leg Lifts', 'Plank'],
        formCues: ['Shoulders pressed down away from ears', 'Lock elbows', 'Keep knees tight']
      },
      {
        level: 2,
        name: 'One-Leg Extended L-Sit',
        description: 'One leg extended straight horizontal while the other knee is tucked in, preparing hip flexor torque.',
        targetHoldSec: 20,
        trainingExercises: ['One-Leg L-Sit', 'L-Sit Kicks', 'Hanging Knee Raises'],
        formCues: ['Switch legs midway', 'Quad tight on extended leg', 'Keep hips pushed forward']
      },
      {
        level: 3,
        name: 'Full L-Sit',
        description: 'Both legs extended straight out horizontally parallel to the ground at a crisp 90-degree angle.',
        targetHoldSec: 15,
        trainingExercises: ['Full L-Sit on Parallettes', 'Floor L-Sit', 'Hanging Leg Raises'],
        formCues: ['Point toes', 'Lock knees', 'Push floor down relentlessly']
      },
      {
        level: 4,
        name: 'Straddle L-Sit',
        description: 'Legs wide in a straddle floating well above hand level, placing huge demand on active adductor flexibility.',
        targetHoldSec: 12,
        trainingExercises: ['Straddle L-Sit', 'Seated Straddle Leg Lifts', 'Pancake Stretch'],
        formCues: ['High hip compression', 'Chest proud', 'Active hamstring flexibility']
      },
      {
        level: 5,
        name: 'V-Sit / Manna Prep',
        description: 'Legs compressed upward past 45 degrees toward your face with hips pushed forward past hands.',
        targetHoldSec: 8,
        trainingExercises: ['High V-Sit Holds', 'Shoulder Extensions', 'Compression Drills'],
        formCues: ['Extreme abdominal pike compression', 'Shoulders depressed and retracted']
      }
    ]
  },
  {
    id: 'handstand',
    name: 'Handstand',
    subtitle: 'Equilibrium, Balance & Shoulder Stability',
    category: 'push',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Chest-to-Wall Handstand',
        description: 'Walking feet up a wall until nose and chest touch, establishing straight hollow line mechanics and shoulder elevation.',
        targetHoldSec: 45,
        trainingExercises: ['Wall Walks', 'Shoulder Taps', 'Hollow Body Holds'],
        formCues: ['Elevate shoulders to ears', 'Tuck pelvis', 'Press through fingers']
      },
      {
        level: 2,
        name: 'Wall Kick-Up & Balance Tap',
        description: 'Kicking up to wall and peeling heels off gently to find the 2-5 second freestanding balance sweet spot.',
        targetHoldSec: 15,
        trainingExercises: ['Heel Pulls from Wall', 'Toe Pulls from Wall', 'Wrist Conditioning'],
        formCues: ['Grip floor like tiger claws', 'Look between thumbs', 'Engage glutes']
      },
      {
        level: 3,
        name: 'Freestanding Handstand (10s)',
        description: 'Consistent kick-up into open floor holding a steady 10-15 second balanced handstand using finger micro-corrections.',
        targetHoldSec: 15,
        trainingExercises: ['Freestanding Kick-Ups', 'Bail Out Drills (Cartwheel)', 'Scapular Shrugs'],
        formCues: ['Cambré control with fingertips', 'Breathe calmly', 'No banana back arching']
      },
      {
        level: 4,
        name: 'Solid Handstand (30s+)',
        description: 'Mastery of open space balance holding for 30+ seconds with shape shifting (tuck, straddle, straight).',
        targetHoldSec: 35,
        trainingExercises: ['Shape Transitions (Straddle/Tuck)', 'Long Holds', 'One-Arm Weight Shifts'],
        formCues: ['Effortless breathing', 'Stillness in the core', 'Perfect vertical line']
      },
      {
        level: 5,
        name: 'Press to Handstand / Free HSPU',
        description: 'Slow pressing up from straddle/L-sit into handstand with zero momentum, or performing strict freestanding handstand push-ups.',
        targetHoldSec: 45,
        trainingExercises: ['Straddle Press Negatives', 'Eccentric Free HSPU', 'Pike Compression'],
        formCues: ['Shift shoulders forward to float hips', 'Total motor control']
      }
    ]
  },
  {
    id: 'muscleup',
    name: 'Muscle-Up',
    subtitle: 'The Explosive Calisthenics Transition',
    category: 'pull',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Explosive High Pull-Up',
        description: 'Pulling with maximum speed so the bar contacts sternum or lower ribs rather than just the chin.',
        targetHoldSec: 5, // reps
        trainingExercises: ['Explosive Chest-to-Bar Pull-Ups', 'Banded High Pulls', 'Dead Hang Shrugs'],
        formCues: ['Violent elbow drive back', 'Hollow body snap', 'Look over the bar']
      },
      {
        level: 2,
        name: 'Straight Bar Dip',
        description: 'Deep pressing strength over a single horizontal bar below chest height with forward torso lean.',
        targetHoldSec: 8, // reps
        trainingExercises: ['Straight Bar Dips', 'Parallel Bar Dips', 'Bar Support Hold'],
        formCues: ['Descend until sternum touches bar', 'Elbows track backward', 'Lock out fully']
      },
      {
        level: 3,
        name: 'Transition Technique & Band Assist',
        description: 'Learning the wrist rotation and chest-over-bar pivot using light resistance band or low-bar jump.',
        targetHoldSec: 3, // reps
        trainingExercises: ['Banded Muscle-Ups', 'Negative Muscle-Up Drops', 'Low Bar Jumping Transitions'],
        formCues: ['Keep bar tight against chest', 'Fast head and chest drive forward', 'False grip']
      },
      {
        level: 4,
        name: 'Strict Bar Muscle-Up',
        description: 'Clean unassisted bar muscle-up without excessive kipping, smoothly ascending from hang to lockout.',
        targetHoldSec: 3, // reps
        trainingExercises: ['Strict Muscle-Ups', 'Weighted High Pull-Ups', 'Deep Bar Dips'],
        formCues: ['Symmetrical arm turnover', 'No chicken-winging', 'Solid top lockout']
      },
      {
        level: 5,
        name: 'Slow / Strict False Grip Muscle-Up',
        description: 'Zero-momentum slow-motion muscle-up showcasing absolute raw tendon and pressing dominance.',
        targetHoldSec: 2, // reps
        trainingExercises: ['Slow Muscle-Ups', 'Ring Muscle-Ups', 'Weighted Muscle-Ups'],
        formCues: ['Deep false grip', 'Slow deliberate wrist roll', 'Unbroken control']
      }
    ]
  },
  {
    id: 'frogstand',
    name: 'Frog Stand (Crow)',
    subtitle: 'Foundational Arm Balance & Wrist Stability',
    category: 'push',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Knee-on-Elbow Frog Stand (Feet Grounded)',
        description: 'Squatting with knees rested against outside of bent elbows, rocking forward to load wrists while toes remain lightly on floor.',
        targetHoldSec: 30,
        trainingExercises: ['Wrist Conditioning', 'Forward Lean Rocks', 'Plank'],
        formCues: ['Spread fingers wide', 'Grip floor with fingertips', 'Gaze slightly forward']
      },
      {
        level: 2,
        name: 'Compact Bent-Arm Frog Stand',
        description: 'Knees firmly resting on triceps above elbows, lifting both feet cleanly off the floor in balanced suspension.',
        targetHoldSec: 25,
        trainingExercises: ['Single-Foot Lifts', 'Frog Hold Intervals', 'Scapular Shrugs'],
        formCues: ['Engage core tight', 'Elbows track straight back', 'Breathe calmly']
      },
      {
        level: 3,
        name: 'Extended Knee Crow Stand',
        description: 'Knees placed high into the armpits with deeper forward lean, lifting hips higher toward shoulder height.',
        targetHoldSec: 20,
        trainingExercises: ['High Knee Crow Drills', 'Pike Push-Ups', 'Wrist Rollers'],
        formCues: ['Elevate hips high', 'Drive knees into armpits', 'Point toes']
      },
      {
        level: 4,
        name: 'Crane Pose (Straight-Arm Frog)',
        description: 'Straightening arms into complete locked extension with knees hooked high in armpits, preparing true planche protraction.',
        targetHoldSec: 15,
        trainingExercises: ['Planche Lean', 'Straight-Arm Crow Taps', 'Hollow Body Hold'],
        formCues: ['Lock elbows completely', 'Protract shoulder blades', 'Look in front of hands']
      },
      {
        level: 5,
        name: 'Frog Stand to Handstand Press',
        description: 'Starting in compact crow and slowly shifting shoulders forward to float hips up into a vertical handstand.',
        targetHoldSec: 10,
        trainingExercises: ['Crow to Handstand Kick-Ups', 'Pike Wall Walks', 'Eccentric Lowering'],
        formCues: ['Shift shoulders forward as hips rise', 'Keep compression tight', 'Lock out at vertical']
      }
    ]
  },
  {
    id: 'elbowlever',
    name: 'Elbow Lever',
    subtitle: 'Horizontal Bodyweight Balance on Bent-Arm Fulcrum',
    category: 'push',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Tucked Elbow Lever on Floor',
        description: 'Hands turned backward or outward, tucking elbow tips securely into ASIS hip bones with knees curled in.',
        targetHoldSec: 25,
        trainingExercises: ['Wrist Extensions', 'Elbow Position Drills', 'Plank Hold'],
        formCues: ['Hands turned 45-90 degrees out', 'Elbows braced directly inside hip crests', 'Lean forward']
      },
      {
        level: 2,
        name: 'Straddle Elbow Lever on Floor',
        description: 'Legs wide in a straddle floating horizontally, shortening the rotational leverage on the torso.',
        targetHoldSec: 20,
        trainingExercises: ['Straddle Hip Lifts', 'Superman Holds', 'Lower Back Extensions'],
        formCues: ['Squeeze glutes', 'Keep chest parallel to floor', 'Look forward']
      },
      {
        level: 3,
        name: 'Full Straight-Body Floor Elbow Lever',
        description: 'Legs together, body in a horizontal line floating inches above the carpet or floor supported on both elbows.',
        targetHoldSec: 15,
        trainingExercises: ['Full Floor Holds', 'Back Extensions', 'Pike Stretches'],
        formCues: ['Feet glued together', 'Point toes', 'Lock knees and glutes']
      },
      {
        level: 4,
        name: 'Parallettes / Straight Bar Elbow Lever',
        description: 'Performing the full straight-body elbow lever on parallettes or a horizontal bar with zero floor proximity assistance.',
        targetHoldSec: 12,
        trainingExercises: ['Parallette Balance', 'Straight Bar Balance Drops', 'Tuck Lever on Bar'],
        formCues: ['Firm grip control', 'Symmetric elbow wedge', 'Neutral head alignment']
      },
      {
        level: 5,
        name: 'One-Arm Elbow Lever',
        description: 'Single elbow planted in the center of the abdomen/hip, balancing the entire horizontal body on one arm.',
        targetHoldSec: 8,
        trainingExercises: ['One-Arm Weight Shifts', 'Fingertip Supported Lever', 'Oblique Bracing'],
        formCues: ['Center elbow on naval/hip line', 'Counterbalance with legs wide', 'Torso rigid']
      }
    ]
  },
  {
    id: 'ninetydegree',
    name: '90-Degree Hold (Bent-Arm Planche)',
    subtitle: 'The Ultimate Bent-Arm Tricep & Shoulder Lock',
    category: 'push',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Deep Push-Up Bottom Isometric Hover',
        description: 'Holding chest 1 inch off the floor with elbows bent at precisely 90 degrees and body in rigid hollow plank.',
        targetHoldSec: 30,
        trainingExercises: ['Push-Up Isometric Pauses', 'Dips at 90°', 'Plank'],
        formCues: ['Elbows at strict 90 degrees', 'Forearms vertical', 'Glutes squeezed tight']
      },
      {
        level: 2,
        name: 'Bent-Arm Tuck Planche',
        description: 'Knees tucked into chest, suspending feet completely off the floor with elbows locked at 90 degrees (no elbow resting on hips).',
        targetHoldSec: 15,
        trainingExercises: ['Parallette Tuck Dips', 'Bent-Arm Rocks', 'Pseudo Planche Push-Ups'],
        formCues: ['Elbows flared slightly or tucked to ribs without resting on pelvis', 'Forearms perpendicular', 'Round upper back']
      },
      {
        level: 3,
        name: '90-Degree Straddle Hold (Parallettes)',
        description: 'Torso and wide straddle legs suspended horizontally in mid-air with elbows bent at strict 90-degree right angles.',
        targetHoldSec: 10,
        trainingExercises: ['Straddle Eccentric Drops from Handstand', 'Deep Bar Dips', 'Band-Assisted 90° Hold'],
        formCues: ['Horizontal torso alignment', 'Do not drop chest below elbow height', 'Spread legs wide']
      },
      {
        level: 4,
        name: 'Full 90-Degree Static Hold',
        description: 'Legs together, head-to-toe laser straight line floating parallel to earth at 90-degree elbow flexion.',
        targetHoldSec: 8,
        trainingExercises: ['Negative Drops from Handstand to 90°', 'Weighted Dips', 'Planche Lean'],
        formCues: ['Straight bodyline', 'Keep shoulders at elbow height', 'Point toes']
      },
      {
        level: 5,
        name: '90-Degree Push-Up (To Handstand)',
        description: 'From static 90-degree horizontal hold, pressing whole body directly up into a vertical freestanding handstand.',
        targetHoldSec: 5,
        trainingExercises: ['90° Push-Up Negatives', 'Handstand Push-Ups', 'Tiger Bend Push-Ups'],
        formCues: ['Smooth pressing transition', 'Shift shoulders as hips travel upward', 'Lock out overhead']
      }
    ]
  },
  {
    id: 'humanflag',
    name: 'Human Flag (Side Lever)',
    subtitle: 'Lateral Core & Unilateral Push-Pull Icon',
    category: 'pull',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Vertical Pole Chamber Hold',
        description: 'Grasping vertical pole or wall bars with top arm pulling and bottom arm pushing, knees tucked to chest in vertical orientation.',
        targetHoldSec: 25,
        trainingExercises: ['Pole Pull-Push Drills', 'Side Planks', 'Hanging Oblique Raises'],
        formCues: ['Top arm straight and pulling hard', 'Bottom arm locked and pushing pole away', 'Stack shoulders']
      },
      {
        level: 2,
        name: 'Tucked Horizontal Human Flag',
        description: 'Lifting torso into true horizontal alignment with knees curled tightly in towards chest.',
        targetHoldSec: 15,
        trainingExercises: ['Flag Pull-Ups', 'Band-Assisted Flag', 'Lateral Leg Raises'],
        formCues: ['Body parallel to floor', 'Keep hips in line with shoulders', 'Do not rotate face down']
      },
      {
        level: 3,
        name: 'One-Leg Extended Human Flag',
        description: 'One leg extended straight along the horizontal line while opposite knee remains tucked in.',
        targetHoldSec: 10,
        trainingExercises: ['One-Leg Switches', 'Flag Eccentric Drops', 'Weighted Side Planks'],
        formCues: ['Alternate legs equally', 'Drive top hip high', 'Lock bottom elbow']
      },
      {
        level: 4,
        name: 'Straddle Human Flag',
        description: 'Both legs extended in a wide V-straddle, holding the horizontal flag parallel to the earth.',
        targetHoldSec: 8,
        trainingExercises: ['Straddle Flag Lowers', 'Overhead Lat Pulls', 'Unilateral Push-Ups'],
        formCues: ['Wide straddle reduces torque', 'Point toes', 'Lock both arms like steel trusses']
      },
      {
        level: 5,
        name: 'Full Human Flag',
        description: 'The iconic calisthenics spectacle: body completely horizontal with straight legs together suspended sideways on a pole.',
        targetHoldSec: 5,
        trainingExercises: ['Full Flag Holds', 'Flag Pulls', 'Full Flag Negatives'],
        formCues: ['Laser-straight bodyline', 'Maximum oblique and lat tension', 'Lock bottom tricep']
      }
    ]
  },
  {
    id: 'onearmhandstand',
    name: 'One-Arm Handstand (OAHS)',
    subtitle: 'The Pinnacle of Gymnastic Equilibrium',
    category: 'push',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Straddle Wall Weight Shifts',
        description: 'Chest-to-wall or back-to-wall straddle handstand, shifting weight 90% onto one arm and tapping opposite shoulder.',
        targetHoldSec: 30,
        trainingExercises: ['Wall Shoulder Taps', 'Freestanding Handstand 30s+', 'Wrist Push-Ups'],
        formCues: ['Wide straddle for low center of gravity', 'Lock working shoulder into socket', 'Grip floor']
      },
      {
        level: 2,
        name: 'Fingertip-Assisted OAHS (3 Fingers)',
        description: 'Freestanding straddle handstand with non-working hand reduced to light 3-finger floor balance touch.',
        targetHoldSec: 15,
        trainingExercises: ['3-Finger Holds', 'Weight Shifting Drills', 'Scapular Elevation'],
        formCues: ['Lateral shoulder lean over working hand', 'Side flexion of torso', 'Breathe slowly']
      },
      {
        level: 3,
        name: '1-Finger Straddle OAHS',
        description: 'Only index fingertip lightly grazing the floor while single working arm bears 98% of bodyweight.',
        targetHoldSec: 10,
        trainingExercises: ['1-Finger Peels', 'Micro-Releases', 'Active Straddle Hold'],
        formCues: ['Do not bend working elbow', 'Maintain sharp straddle', 'Look at working thumb']
      },
      {
        level: 4,
        name: 'Freestanding Straddle OAHS',
        description: 'Complete release of non-working hand, floating freestanding on a single palm in wide straddle.',
        targetHoldSec: 6,
        trainingExercises: ['Kick to OAHS', 'Straddle Balance Holds', 'Wrist Prehab'],
        formCues: ['Fingertip micro-adjustments', 'Stillness in the pelvis', 'Non-working hand tucked to leg']
      },
      {
        level: 5,
        name: 'Full Straight Legs-Together OAHS',
        description: 'The ultimate hand balancing mastery: legs together straight vertical supported on a single locked arm.',
        targetHoldSec: 10,
        trainingExercises: ['Straddle to Straight OAHS Transitions', 'Daily Hand Balancing Practice'],
        formCues: ['Perfect alignment', 'Flawless shoulder lock', 'Effortless breathing']
      }
    ]
  },
  {
    id: 'vsit',
    name: 'V-Sit & Manna',
    subtitle: 'Supreme Active Pike Compression & Shoulder Extension',
    category: 'core',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'High L-Sit (Parallettes)',
        description: 'Full L-Sit with hips pushed slightly forward and feet elevated 2-4 inches above hand level.',
        targetHoldSec: 25,
        trainingExercises: ['Full L-Sit', 'Seated Pike Lifts', 'Shoulder Depressions'],
        formCues: ['Point toes', 'Lock knees firmly', 'Push parallettes downward']
      },
      {
        level: 2,
        name: '45-Degree V-Sit',
        description: 'Legs compressed upward to a 45-degree angle with knees locked and chest pulled toward quads.',
        targetHoldSec: 15,
        trainingExercises: ['V-Up Holds', 'Pancake Stretch', 'Seated Compression Pulses'],
        formCues: ['Lean torso slightly back to counter legs', 'Keep knees touching', 'Deep pike compression']
      },
      {
        level: 3,
        name: 'High Vertical V-Sit (Toes at Eye Level)',
        description: 'Feet lifted completely vertical at or above forehead level with hips pushed forward past wrist line.',
        targetHoldSec: 10,
        trainingExercises: ['High V-Sit Wall Kicks', 'Manna Prep Drills', 'German Hangs'],
        formCues: ['Active hamstring flexibility', 'Extreme hip flexor engagement', 'Depress shoulder blades']
      },
      {
        level: 4,
        name: 'Manna Prep (Hips Elevated Past Wrists)',
        description: 'Pelvis lifted forward and elevated above hands, torso leaning back with straight arms.',
        targetHoldSec: 8,
        trainingExercises: ['Tablemaker Lifts', 'Shoulder Extension Stretches', 'Reverse Hyperextensions'],
        formCues: ['Shoulder extension mobility', 'Do not bend arms', 'Drive hips upward']
      },
      {
        level: 5,
        name: 'Full Horizontal Manna',
        description: 'Torso and legs parallel to ceiling/floor with hips floating high above wrists in complete shoulder extension.',
        targetHoldSec: 5,
        trainingExercises: ['Manna Holds', 'High Compression Drills', 'Active Shoulder Mobility'],
        formCues: ['Straight arms locked', 'Legs parallel to ground above body', 'Mastery of gymnastics strength']
      }
    ]
  },
  {
    id: 'onearmpullup',
    name: 'One-Arm Pull-Up (OAP)',
    subtitle: 'Unilateral Vertical Pulling Supremacy',
    category: 'pull',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Heavy Weighted Pull-Up (+50% BW)',
        description: 'Building the fundamental base lat and elbow tendon density required for single-arm pulling.',
        targetHoldSec: 5, // reps
        trainingExercises: ['Weighted Pull-Ups', 'Archer Pull-Ups', 'Towel-Assisted Pull-Ups'],
        formCues: ['Dead hang on every rep', 'Chest touches bar', 'Control the eccentric']
      },
      {
        level: 2,
        name: 'Archer Pull-Up Top Lockout Hold',
        description: 'Pulling to top of archer with one arm fully bent and chin touching hand, holding statically.',
        targetHoldSec: 15,
        trainingExercises: ['Archer Pull-Up Holds', 'One-Arm Deadhangs', 'Finger-Assisted Pulls'],
        formCues: ['Keep working elbow tucked close', 'Depress scapula', 'Squeeze bicep']
      },
      {
        level: 3,
        name: 'Band-Assisted One-Arm Chin-Up',
        description: 'Working arm on bar, other hand holding light elastic loop to calibrate unilateral strength curve.',
        targetHoldSec: 5, // reps
        trainingExercises: ['Band-Assisted OAC', 'Typewriter Pull-Ups', 'Dumbbell Hammer Curls'],
        formCues: ['Minimal assistance from band', 'Keep core hollow', 'Full range motion']
      },
      {
        level: 4,
        name: '5-Second Eccentric OAP Negative',
        description: 'Jumping to chin over bar with single arm and controlling a grueling 5-second descent to active dead hang.',
        targetHoldSec: 5, // sec negative
        trainingExercises: ['OAP Negatives', 'One-Arm Lockouts at 90°', 'Forearm Grip Work'],
        formCues: ['Fight every inch of descent', 'Do not drop suddenly', 'Keep scapula active at bottom']
      },
      {
        level: 5,
        name: 'Strict Dead Hang One-Arm Pull-Up',
        description: 'From passive/active single arm dead hang, pulling straight up until chin clears the bar with zero kipping.',
        targetHoldSec: 2, // reps
        trainingExercises: ['Full OAP Reps', 'Weighted OAP Negatives'],
        formCues: ['Explosive initial scapular pull', 'Turn body slightly inward toward bar', 'Chin clearly over bar']
      }
    ]
  },
  {
    id: 'dragonflag',
    name: 'Dragon Flag Hold',
    subtitle: 'Legendary Bruce Lee Core Deceleration & Lever',
    category: 'core',
    currentLevel: 1,
    maxLevel: 5,
    currentHoldSec: 0,
    prHoldSec: 0,
    levels: [
      {
        level: 1,
        name: 'Tucked Dragon Flag Hold',
        description: 'Candlestick roll on upper traps, holding body suspended with knees tucked into chest.',
        targetHoldSec: 25,
        trainingExercises: ['Hollow Body Hold', 'Hanging Knee Raises', 'Trap Stands'],
        formCues: ['Weight on upper back/traps, not neck', 'Grip bench or pole firmly behind head', 'Tight abs']
      },
      {
        level: 2,
        name: 'One-Leg Extended Dragon Flag',
        description: 'One leg extended straight out while other knee stays tucked, increasing torque on the abdominal wall.',
        targetHoldSec: 15,
        trainingExercises: ['One-Leg Switches', 'Tuck Flag Raises', 'Ab Rollouts'],
        formCues: ['Keep hips locked in line with torso', 'Lower slowly', 'Squeeze glute of extended leg']
      },
      {
        level: 3,
        name: 'Straddle Dragon Flag Hold',
        description: 'Both legs spread in a wide straddle floating horizontally 6 inches above the floor or bench.',
        targetHoldSec: 12,
        trainingExercises: ['Straddle Flag Eccentrics', 'Dragon Flag Pulses', 'L-Sit Holds'],
        formCues: ['Wide straddle', 'Straight spine with no hip sagging', 'Point toes']
      },
      {
        level: 4,
        name: 'Full Straight-Body Dragon Flag Negatives',
        description: 'Lowering from vertical candlestick down to 2 inches above bench over 5 slow seconds with straight legs.',
        targetHoldSec: 5, // sec descent
        trainingExercises: ['5-Second Negatives', 'Band-Assisted Dragon Flag', 'Full Body Planks'],
        formCues: ['Laser-straight bodyline', 'Do not let lower back arch', 'Controlled descent']
      },
      {
        level: 5,
        name: 'Full Dragon Flag Static Hold & Raises',
        description: 'Holding body completely horizontal floating off the bench, and pulling back up to vertical with pure core power.',
        targetHoldSec: 10,
        trainingExercises: ['Full Dragon Flag Holds', 'Dragon Flag Raises to Candle'],
        formCues: ['Zero bending at hips', 'Unbroken core tension', 'Smooth breathing']
      }
    ]
  }
];
