import { RadiologyLesson } from '../types';

export const RADIOLOGY_LESSONS: RadiologyLesson[] = [
  {
    id: 'lesson-01',
    titleAr: 'الفيزياء الأساسية لإنتاج الأشعة السينية (Tube de Coolidge)',
    titleFr: 'Physique et Production des Rayons X',
    titleEn: 'Physics and Production of X-Rays',
    category: 'xray',
    rankRequired: 'E',
    xpReward: 150,
    readingMinutes: 6,
    summaryAr: 'شرح مفصل لمكونات أنبوب كوليدج، توليد الإلكترونات بالكاثود، وتسريعها نحو الأنود الدوار، والتفرقة بين طاقة الـ kVp وكمية الـ mAs.',
    summaryFr: 'Structure détaillée du tube à rayons X, émission thermoionique, freinage des électrons et distinction fondamentale entre kVp et mAs.',
    sections: [
      {
        titleAr: 'مكونات أنبوب كوليدج (Tube Radiogène)',
        titleFr: 'Composants du tube radiogène',
        contentAr: 'يتكون أنبوب الأشعة من غلاف زجاجي مفرغ من الهواء يحتوي على قطبين: الكاثود (المهبط السالب) الذي يحتوي على فتيلة تنجستن تسخن كهربائياً لإطلاق سحابة إلكترونات بالانبعاث الحراري، والأنود (المصعد الموجب) وهو قرص دوار من التنجستن والموليبدينوم يصطدم به سيل الإلكترونات لإنتاج الأشعة السينية.',
        contentFr: 'Le tube radiogène se compose d’une enveloppe sous vide scellée, d’une cathode négative à filament de tungstène chauffé (émission thermoionique) et d’une anode tournante en tungstène servant de cible pour freiner violemment les électrons incidents.',
        keyPoints: [
          'أكثر من 99% من طاقة الاصطدام تتحول إلى حرارة و 1% فقط يتحول إلى أشعة سينية.',
          'الأنود الدوار يدور بسرعة 3000 إلى 9000 دورة/دقيقة لتشتيت الحرارة الهائلة.',
          'الزيت المحيط بالأنبوب يمتص الحرارة ويوفر عزلاً كهربائياً عالياً.'
        ],
        warning: 'احذر تسخين الأنبوب دفعة واحدة دون إجراء دورة الإحماء الصباحية (Warm-up) لتفادي تشقق قرص الأنود.'
      },
      {
        titleAr: 'معايير التعريض: الفرق بين kVp و mAs',
        titleFr: 'Paramètres d’exposition : kVp vs mAs',
        contentAr: 'الـ kVp (كيلو فولت) هو فرق الجهد الذي يسرع الإلكترونات، ويحدد قدرة فوتونات الأشعة على اختراق الأنسجة (جودة الشعاع). بينما الـ mAs (ميلي أمبير ثانية) يمثل حاصل ضرب شدة التيار في زمن التعريض، ويحدد كمية وعدد الفوتونات المنبعثة (كثافة الصورة واسودادها).',
        contentFr: 'Le kVp définit l’énergie cinétique maximale des électrons et le pouvoir pénétrant des photons (qualité). Le mAs régit le produit courant-temps et détermine la quantité de photons (noircissement global).',
        keyPoints: [
          'زيادة kV بنسبة 15% تضاعف كثافة الصورة كما لو ضاعفت الـ mAs (قاعدة 15%).',
          'للأنسجة السميكة والعظام الكثيفة نحتاج kV أعلى.',
          'لتقليل تشوش الحركة نرفع mA ونخفض زمن التعريض (ms).'
        ]
      }
    ],
    technicalParams: {
      kv: '40 - 130 kV',
      mas: '1 - 200 mAs',
      distance: '1.00m (Squelette) à 1.80m (Thorax)',
      grid: true,
      patientInstructionAr: 'يرجى البقاء ثابتاً تماماً دون أي حركة أثناء صوت الإشارة.',
      patientInstructionFr: 'Restez parfaitement immobile pendant le déclenchement sonore.'
    },
    scenarioQuiz: {
      questionAr: 'أثناء تصوير مريض مسن يرتجف، ما هو الإجراء التقني الأمثل لمنع ضبابية الحركة (Flou cinétique)؟',
      questionFr: 'Pour éviter le flou cinétique chez un patient tremblant, quel paramètre modifier ?',
      optionsAr: [
        'تقليص زمن التعريض (ms) وزيادة شدة التيار (mA) لتعويض الـ mAs',
        'زيادة وقت التعريض إلى ثانيتين لجمع مزيد من الفوتونات',
        'إطفاء شبكة بوكي وتقليل المسافة البؤرية إلى 50 سم',
        'مضاعفة الـ mAs دون تغيير وقت التعريض'
      ],
      optionsFr: [
        'Diminuer le temps de pose (ms) et augmenter le courant (mA)',
        'Augmenter le temps de pose à 2 secondes',
        'Retirer la grille et réduire la distance à 50 cm',
        'Doubler le mAs sans changer le temps'
      ],
      correctIndex: 0,
      explanationAr: 'تقليص زمن التعريض بالملي ثانية يوقف حركة المريض اللارادية في الصورة مع الحفاظ على نفس الـ mAs برفع شدة تيار الفتيلة.',
      explanationFr: 'Réduire le temps de pose (temps court) fige le mouvement du patient tout en préservant la densité par l’augmentation de l’intensité mA.'
    }
  },
  {
    id: 'lesson-02',
    titleAr: 'إسقاطات الصدر: الوجه والجانب وتوجيه المريض (Thorax Face & Profil)',
    titleFr: 'Radiographie du Thorax : Incidences et Consignes',
    titleEn: 'Chest Radiography: PA & Lateral Projections',
    category: 'positioning',
    rankRequired: 'E',
    xpReward: 160,
    readingMinutes: 7,
    summaryAr: 'شرح الوضعية القياسية للصدر PA والجانبي الأيسر، معايير نجاح الصورة الشعاعية، والنصائح الحوارية بالدارجة الجزائرية والفرنسية.',
    summaryFr: 'Positionnement rigoureux en postéro-antérieure et profil gauche, critères de réussite radiologique et vocabulaire de guidage du patient.',
    sections: [
      {
        titleAr: 'إسقاط الصدر وجهاً PA (Postéro-Antérieure)',
        titleFr: 'Incidence Thorax Face PA',
        contentAr: 'يقف المريض مواجهاً للكاشف، ذقنه مرفوع ويستند على حافة اللوح، يضع ظهر كفيه على خاصرتيه مع تدوير المرفقين للأمام لطرد لوحي الكتف خارج الحقل الرئوي. مسافة البؤرة 1.80 متر لتقليص تضخم ظل القلب.',
        contentFr: 'Patient debout face au potter vertical, menton surélevé reposant sur le haut du récepteur, mains sur les hanches avec enroulement des épaules vers l’avant pour projeter les scapulas en dehors des plages pulmonaires. DFR = 1,80 m.',
        keyPoints: [
          'الشهيق العميق التام: ظهور 6 أضلاع أمامية أو 10 أضلاع خلفية فوق الحجاب الحاجز.',
          'التناظر التام: تساوي المسافة بين الحافتين الأنسيتين للترقوتين والخط الشوكي.',
          'وضوح الزوايا الضلعية الحجابية (Culs-de-sac costo-diaphragmatiques) كاملة.'
        ]
      },
      {
        titleAr: 'تعليمات المريض بالدارجة الجزائرية والفرنسية (Communication)',
        titleFr: 'Consignes au patient (Français et Darija)',
        contentAr: 'التواصل الفعال يضمن جودة الفحص من أول محاولة ويجنب إعادة التعريض الشعاعي:',
        contentFr: 'La clarté des consignes évite les reprises inutiles et rassure le patient :',
        keyPoints: [
          '🇫🇷 « Enlevez chaînes, colliers et soutiens-gorge avec armatures métalliques. »',
          '🇩🇿 « نحّي السنسلة، الخواتم، وحوايج الحديد اللي في صدرك. »',
          '🇫🇷 « Collez bien votre poitrine contre la plaque et mettez les coudes en avant. »',
          '🇩🇿 « لصّق صدرك مليح في اللوحة، ودور يديك ومرافقك للقدام. »',
          '🇫🇷 « Inspirez à fond... Bloquez la respiration ! ... Respirez normalement. »',
          '🇩🇿 « تنفّس بعمق... احكم النفس وما تتحركش ! ... تنفس عادي خلاص. »'
        ]
      }
    ],
    technicalParams: {
      kv: '115 - 125 kV (Haute tension)',
      mas: '2 - 4 mAs',
      distance: '1.80m',
      grid: true,
      patientInstructionAr: 'تنفس بعمق شديد... احبس النفس... لا تتحرك إطلاقاً!',
      patientInstructionFr: 'Grande inspiration... Bloquez la respiration... Ne bougez pas !'
    },
    scenarioQuiz: {
      questionAr: 'لماذا يُطلب من المريض تدوير كتفيه ومرفقيه للأمام أثناء صورة الصدر PA؟',
      questionFr: 'Pourquoi enroule-t-on les épaules et les coudes vers l’avant en thorax face ?',
      optionsAr: [
        'لإبعاد عظمتي لوح الكتف (Scapulas) عن التداخل مع النسيج الرئوي',
        'لزيادة تدفق الدم في الشريان الأبهر',
        'لتصغير حجم القلب على الفيلم',
        'لزيادة نسبة امتصاص الأشعة بالقص'
      ],
      optionsFr: [
        'Pour dégager les scapulas en dehors des champs pulmonaires',
        'Pour augmenter le débit aortique',
        'Pour diminuer la taille du cœur',
        'Pour absorber le rayonnement au sternum'
      ],
      correctIndex: 0,
      explanationAr: 'تدوير المرفقين والكتفين للأمام يزحزح لوحي الكتف نحو الخارج تماماً حتى لا يظهرا ككتل أو تكثفات داخل الرئتين.',
      explanationFr: 'L’antépulsion et l’enroulement des épaules dégagent les ombres des scapulas en dehors du parenchyme pulmonaire.'
    }
  },
  {
    id: 'lesson-03',
    titleAr: 'الحماية من الإشعاع وقوانين السلامة الاستشفائية في الجزائر',
    titleFr: 'Radioprotection et Réglementation Hospitalière DZ',
    titleEn: 'Radiation Protection & Hospital Safety Regulations',
    category: 'radioprotection',
    rankRequired: 'D',
    xpReward: 200,
    readingMinutes: 8,
    summaryAr: 'المبادئ الثلاثة للوقاية: التبرير، الأفضلية (ALARA)، وتحديد الجرعات. حدود الجرعات القانونية للمهنيين والجمهور، وإجراءات السلامة في المستشفيات الجزائرية.',
    summaryFr: 'Les trois piliers fondamentaux : Justification, Optimisation (ALARA), Limitation de dose. Normes légales pour les manipulateurs en Algérie.',
    sections: [
      {
        titleAr: 'المبادئ الأساسية للوقاية الإشعاعية (CIPR)',
        titleFr: 'Principes fondamentaux de la CIPR',
        contentAr: 'تقوم الحماية الإشعاعية على 3 أركان مقدسة: 1- التبرير (Justification): لا يُجرى أي فحص إلا بطلب طبي صريح يقدم فائدة تفوق خطر الإشعاع. 2- الأفضلية (Optimisation - ALARA): الحفاظ على الجرعة عند أقل مستوى ممكن. 3- الحد القانوني للجرعة (Limitation de dose): لا يجوز أبداً تجاوز الحدود القصوى المسموحة.',
        contentFr: 'La radioprotection repose sur : 1) La Justification médicale de l’acte ; 2) L’Optimisation de l’exposition (principe ALARA) ; 3) La Limitation stricte des doses reçues par le personnel et le public.',
        keyPoints: [
          'الحد السنوي للعاملين في الأشعة (Catégorie A) هو 20 ملي سيفرت (20 mSv) سنوياً.',
          'الحد السنوي لعموم الجمهور هو 1 ملي سيفرت (1 mSv) سنوياً.',
          'بالنسبة للمرأة الحامل العاملة بالأشعة، يجب ألا تتعدى الجرعة للجنين 1 mSv طوال فترة الحمل.'
        ]
      },
      {
        titleAr: 'قواعد الحماية الثلاث: الزمن والمسافة والدرع الرصاصي',
        titleFr: 'La règle d’or : Temps, Distance, Écran',
        contentAr: '1- الزمن: تقليل وقت التواجد قرب المصدر. 2- المسافة: مضاعفة البعد عن المصدر تقلل الجرعة إلى الربع (قانون التربيع العكسي 1/d²). 3- الحواجز: استخدام الحواجز الزجاجية الرصاصية، مآزر الرصاص (0.5 mm Pb)، واقيات الغدة الدرقية، ونظارات الرصاص.',
        contentFr: '1) Temps d’exposition minimal ; 2) Distance maximale (loi de l’inverse du carré de la distance) ; 3) Écrans protecteurs (tabliers plombés 0,35 ou 0,5 mm Pb, protège-thyroïde, paravents fixes).',
        keyPoints: [
          'الوقوف على بعد مترين من أنبوب الأشعة يقلل الجرعة المشتتة بنسبة تفوق 99%.',
          'ارتداء الدوزيمتر الصدري إجباري بموجب القانون ولا يُعار لزميل آخر تحت أي ظرف.'
        ]
      }
    ],
    technicalParams: {
      patientInstructionAr: 'لا يُسمح لأي مرافق بالدخول إلا في حالات الأطفال مع ارتداء مريلة رصاصية كاملة.',
      patientInstructionFr: 'Aucun accompagnateur sans tablier plombé réglementaire.'
    },
    scenarioQuiz: {
      questionAr: 'ما هو الحد الأقصى القانوني للجرعة الإشعاعية السنوية المسموحة لتقني الأشعة (Manipulateur radio)؟',
      questionFr: 'Quelle est la limite de dose efficace annuelle pour un travailleur de catégorie A ?',
      optionsAr: [
        '20 ميلي سيفرت (20 mSv) سنوياً',
        '100 ميلي سيفرت (100 mSv) سنوياً',
        '1 ميلي سيفرت (1 mSv) سنوياً',
        '500 ميلي سيفرت (500 mSv) سنوياً'
      ],
      optionsFr: [
        '20 mSv par an',
        '100 mSv par an',
        '1 mSv par an',
        '500 mSv par an'
      ],
      correctIndex: 0,
      explanationAr: 'وفقاً لتوصيات اللجنة الدولية للوقاية الإشعاعية والتشريع الجزائري، فإن الحد الأقصى للمهنيين هو 20 mSv في السنة موزعة بانتظام.',
      explanationFr: 'La limite réglementaire internationale et nationale pour le personnel directement exposé en imagerie médicale est de 20 mSv par an.'
    }
  },
  {
    id: 'lesson-04',
    titleAr: 'أساسيات المفراس الحلزوني TDM وحقن مادة التباين اليودية',
    titleFr: 'Scanner TDM : Principes et Injection de PDC Iodé',
    titleEn: 'CT Scanning: Principles & Contrast Media Protocols',
    category: 'ct',
    rankRequired: 'C',
    xpReward: 250,
    readingMinutes: 9,
    summaryAr: 'شرح آلية عمل جهاز السكانير، مقاييس هاونسفيلد، إدارة الحاقن الآلي، الفحوصات المخبرية القبلية، وإدارة أعراض فرط الحساسية.',
    summaryFr: 'Fonctionnement du scanner hélicoïdal, échelle de Hounsfield, maîtrise de l’injecteur automatique et prévention de la néphrotoxicité induite.',
    sections: [
      {
        titleAr: 'مقياس هاونسفيلd للأنسجة (Densités TDM)',
        titleFr: 'L’échelle des densités de Hounsfield',
        contentAr: 'يعتمد السكانير على حساب معاملات التوهين الخطي وتحويلها إلى أرقام رمادية على مقياس Hounsfield (HU): الهواء = -1000، الرئة = -600، الدهون = -100 إلى -50، الماء الرائق = 0، السائل الدماغي = +10، الأنسجة الرخوة والعضلات = +30 إلى +50، الدم الحاد = +60 إلى +75، والعظام الكثيفة = +700 إلى +2000.',
        contentFr: 'L’échelle UH quantifie l’atténuation : Air (-1000), Graisse (-100 à -50), Eau (0), LCR (+10), Tissus mous (+40), Sang frais (+65), Os cortical (> +1000).',
        keyPoints: [
          'النافذة الرئوية (Fenêtre parenchymateuse): عرض واسع لإبراز التفرعات الهوائية.',
          'النافذة العظمية (Fenêtre osseuse): تميز بدقة خطوط الكسور الدقيقة في القشرة العظمية.',
          'النافذة المنصفية الحشوية (Fenêtre médiastinale): لتقييم الأوعية والكتل اللمفاوية.'
        ]
      },
      {
        titleAr: 'بروتوكول حقن مادة التباين اليودية (Sécurité PDC)',
        titleFr: 'Protocole de sécurité pour l’injection de produit de contraste',
        contentAr: 'قبل أي حقن لمادة التباين اليودية، يجب: 1- التحقق من وظائف الكلى (الكرياتينين ومعدل الترشيح DFG > 30 ml/min). 2- التأكد من عدم وجود سوابق صدمة تحسسية. 3- تركيب كانيولا وريدية متينة (18G أو 20G) في وريد مرفقي واختبارها بالسيروم المالح. 4- شرح إحساس الحرارة الطبيعي للمريض لتهدئته.',
        contentFr: 'Vérifier la fonction rénale (créatininémie, DFG), les antécédents d’allergie sévère, poser une VVP de bon calibre (18G/20G) et rassurer le patient sur la sensation passagère de chaleur.',
        keyPoints: [
          'أخبر المريض: «ستشعر بحرارة دافئة تسري في حلقك وجسمك مع طعم معدني في الفم، هذا طبيعي تماماً ولن يدوم سوى 30 ثانية».',
          'في حال حدوث اختناق أو حكة معممة أو وذمة كوينكي، أوقف الحقن فوراً واطلب النجدة الطبية.'
        ]
      }
    ],
    technicalParams: {
      kv: '100 - 140 kV',
      mas: 'Automatique (Modulation de dose)',
      distance: 'Gantry Iso-centre',
      patientInstructionAr: 'ستشعر بسخونة تسري في جسمك، ابق مسترخياً ولا تتحرك إطلاقاً.',
      patientInstructionFr: 'Une sensation de chaleur va diffuser dans votre corps, c’est normal, restez calme.'
    },
    scenarioQuiz: {
      questionAr: 'ما هي كثافة الدم الحاد المتجلط في النزيف الدماغي على مقياس هاونسفيلد (UH) بدون حقن؟',
      questionFr: 'Quelle est la densité spontanée du sang frais intrakrânien en Unités Hounsfield ?',
      optionsAr: [
        '+55 إلى +75 UH (عالية الكثافة تظهر بيضاء)',
        '-100 UH (منخفضة الكثافة تظهر سوداء)',
        '0 UH (مطابقة لكثافة الماء النقية)',
        '+1000 UH (مطابقة للعظم الصلب)'
      ],
      optionsFr: [
        '+55 à +75 UH (hyperdense)',
        '-100 UH (hypodense)',
        '0 UH (isodense à l’eau)',
        '+1000 UH (densité osseuse)'
      ],
      correctIndex: 0,
      explanationAr: 'الهيموغلوبين البروتيني في الدم الحاد يمتص الأشعة بكثافة تتراوح بين +55 إلى +75 وحدة هاونسفيلد فيظهر متوهجاً بالأبيض في الساعات الأولى للنزيف.',
      explanationFr: 'La concentration en hémoglobine confère au sang extravasé récent une hyperdensité spontanée comprise entre +55 et +75 UH.'
    }
  },
  {
    id: 'lesson-05',
    titleAr: 'الرنين المغناطيسي IRM: الفيزياء وقائمة الموانع الصارمة',
    titleFr: 'IRM : Principes Physiques et Sécurité des Aimants',
    titleEn: 'MRI: Physical Principles & Magnet Safety',
    category: 'mri',
    rankRequired: 'B',
    xpReward: 300,
    readingMinutes: 10,
    summaryAr: 'المجال المغناطيسي الثابت B0، تموج البروتونات، تسلسلات T1 و T2 و FLAIR، وموانع الدخول الصارمة لقاعة الرنين المغناطيسي لحماية الأرواح.',
    summaryFr: 'Champ magnétique supraconducteur B0, relaxation T1/T2, séquences de référence et checklist absolue de non-compatibilité IRM.',
    sections: [
      {
        titleAr: 'فيزياء الرنين في كلمات مبسطة',
        titleFr: 'Physique de l’IRM expliquée simplement',
        contentAr: 'يحتوي جسم الإنسان على مليارات نوى الهيدروجين (البروتونات). داخل المغناطيس الضخم (1.5 أو 3 تسلا)، تصطف هذه البروتونات باتجاه المجال B0. عند إرسال نبضة موجات راديو (RF)، تميل البروتونات، وعند إيقاف النبضة تعود لوضعها الأصلي مطلقة إشارة كهربائية دقيقة تُسجلها الهوائيات (Antennes).',
        contentFr: 'L’aimant principal B0 aligne les spins des protons d’hydrogène corporels. Une onde RF les bascule hors de l’axe. Lors de la relaxation, les protons réémettent un signal capté par des antennes dédiées.',
        keyPoints: [
          'الزمن T1: قياس سرعة عودة المغنطة الطولية (الأنسجة الدهنية تسترخي سريعاً فتبدو بيضاء).',
          'الزمن T2: قياس تلاشي المغنطة العرضية (السوائل تحافظ على الإشارة طويلاً فتبدو بيضاء).',
          'تسلسل FLAIR: يطمس السائل الدماغي ليظهر التهاب المادة البيضاء (التصلب اللويحي).'
        ]
      },
      {
        titleAr: 'قائمة موانع الرنين المغناطيسي (Sécurité Absolue)',
        titleFr: 'Contre-indications strictes en salle d’aimant',
        contentAr: 'المجال المغناطيسي يعمل 24/24 ساعة حتى لو كان الجهاز مطفأ! الأجسام الحديدية تتحول إلى مقذوفات قاتلة تجذب بسرعة فائقة نحو مركز المغناطيس (Effet projectile).',
        contentFr: 'Le champ magnétique B0 est permanent, même machine à l’arrêt ! Les objets ferromagnétiques deviennent des missiles mortels propulsés vers le tunnel.',
        keyPoints: [
          'ممنوع دخول: منظم ضربات القلب (Pacemaker) غير المتوافق مع الرنين.',
          'ممنوع دخول: مشابك تمدد الأوعية الدماغية الفولاذية (Clips d’anévrisme ferromagnétiques).',
          'ممنوع دخول: شظايا معدنية في العين (يجب إجراء أشعة سينية للحجاجين مسبقاً للحدادين وعمال الخراطة).',
          'ممنوع دخول: قوارير الأكسجين العادية، الكراسي المتحركة غير المخصصة للرنين، والمقصات.'
        ]
      }
    ],
    technicalParams: {
      patientInstructionAr: 'ستسمع أصوات طرقات وإيقاعات عالية، سنضع لك سماعات واقية، ويوجد جرس طوارئ بيدك تضغطه إذا احتجت أي مساعدة.',
      patientInstructionFr: 'L’appareil émet des bruits rythmés intenses, un casque réducteur et une sonnette d’appel vous sont confiés.'
    },
    scenarioQuiz: {
      questionAr: 'عامل حدادة تعرض سابقاً لشظية في وجهه جاء لإجراء رنين مغناطيسي للركبة، ما هو الإجراء الإلزامي الواجب فعله قبل إدخاله؟',
      questionFr: 'Un ouvrier métallurgiste doit passer une IRM. Quelle précaution radiologique est impérative ?',
      optionsAr: [
        'إجراء صورة أشعة سينية بسيطة للحجاجين (RX des orbites) للتأكد من عدم وجود شظية حديدية عينية',
        'فحص نسبة الكرياتينين في الدم فقط',
        'إعطاؤه مهدئاً وإدخاله مباشرة لأن الفحص يخص الركبة وليس الرأس',
        'زيادة قوة المغناطيس إلى 3 تسلا'
      ],
      optionsFr: [
        'Radiographie des orbites pour éliminer tout éclat métallique intra-oculaire',
        'Vérifier uniquement la créatininémie',
        'L’admettre directement car l’examen concerne le genou',
        'Augmenter le champ à 3 Tesla'
      ],
      correctIndex: 0,
      explanationAr: 'وجود شظية حديدية في العين حتى لو كان الفحص للركبة قد يؤدي إلى تحرك الشظية بسبب المجال المغناطيسي القوي مسببة تمزقاً للشبكية والعمى الفوري.',
      explanationFr: 'Tout éclat métallique intra-oculaire peut migrer sous l’effet du champ magnétique B0 et perforer le globe oculaire, causant une cécité irréversible.'
    }
  }
];
