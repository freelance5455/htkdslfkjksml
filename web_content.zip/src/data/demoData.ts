import {
  Account,
  CustomCategory,
  DebtRecord,
  SubscriptionRecord,
  TransactionRecord,
} from '../types/finance';
import { getTodayISO } from '../utils/money';

export const DEFAULT_CATEGORIES: CustomCategory[] = [
  { id: 'cat-inc-sale', nameBn: 'পণ্য বিক্রয়', nameEn: 'পণ্য বিক্রয়', applicableTo: ['INCOME'] },
  { id: 'cat-inc-service', nameBn: 'সেবা হতে আয়', nameEn: 'সেবা হতে আয়', applicableTo: ['INCOME'] },
  { id: 'cat-inc-salary', nameBn: 'বেতন ও সম্মানী', nameEn: 'বেতন ও সম্মানী', applicableTo: ['INCOME'] },
  { id: 'cat-inc-profit', nameBn: 'ব্যবসায়িক মুনাফা', nameEn: 'ব্যবসায়িক মুনাফা', applicableTo: ['INCOME'] },
  { id: 'cat-inc-other', nameBn: 'অন্যান্য আয়', nameEn: 'অন্যান্য আয়', applicableTo: ['INCOME'] },
  { id: 'cat-exp-inventory', nameBn: 'মালামাল ক্রয়', nameEn: 'মালামাল ক্রয়', applicableTo: ['EXPENSE'] },
  { id: 'cat-exp-rent', nameBn: 'ভাড়া পরিশোধ', nameEn: 'ভাড়া পরিশোধ', applicableTo: ['EXPENSE'] },
  { id: 'cat-exp-utility', nameBn: 'বিদ্যুৎ ও ইন্টারনেট বিল', nameEn: 'বিদ্যুৎ ও ইন্টারনেট বিল', applicableTo: ['EXPENSE'] },
  { id: 'cat-exp-grocery', nameBn: 'পারিবারিক বাজার খরচ', nameEn: 'পারিবারিক বাজার খরচ', applicableTo: ['EXPENSE'] },
  { id: 'cat-exp-staff', nameBn: 'কর্মচারী বেতন', nameEn: 'কর্মচারী বেতন', applicableTo: ['EXPENSE'] },
  { id: 'cat-exp-transport', nameBn: 'যাতায়াত ও পরিবহন', nameEn: 'যাতায়াত ও পরিবহন', applicableTo: ['EXPENSE'] },
  { id: 'cat-exp-medical', nameBn: 'চিকিৎসা ও ওষুধ', nameEn: 'চিকিৎসা ও ওষুধ', applicableTo: ['EXPENSE'] },
  { id: 'cat-exp-other', nameBn: 'অন্যান্য ব্যয়', nameEn: 'অন্যান্য ব্যয়', applicableTo: ['EXPENSE'] },
];

export const DEFAULT_ACCOUNTS: Account[] = [
  {
    id: 'acc-cash',
    nameBn: 'নগদ ক্যাশ',
    nameEn: 'নগদ ক্যাশ',
    type: 'CASH',
    openingBalancePaisa: 2500000, // ৳ ২৫,০০০
    createdAt: '2026-10-01',
    isDemo: true,
  },
  {
    id: 'acc-bkash',
    nameBn: 'বিকাশ',
    nameEn: 'বিকাশ',
    type: 'MFS',
    openingBalancePaisa: 3250000, // ৳ ৩২,৫০০
    createdAt: '2026-10-01',
    isDemo: true,
  },
  {
    id: 'acc-nagad',
    nameBn: 'নগদ',
    nameEn: 'নগদ',
    type: 'MFS',
    openingBalancePaisa: 1200000, // ৳ ১২,০০০
    createdAt: '2026-10-01',
    isDemo: true,
  },
  {
    id: 'acc-rocket',
    nameBn: 'রকেট',
    nameEn: 'রকেট',
    type: 'MFS',
    openingBalancePaisa: 850000, // ৳ ৮,৫০০
    createdAt: '2026-10-01',
    isDemo: true,
  },
  {
    id: 'acc-bank',
    nameBn: 'ব্যাংক',
    nameEn: 'ব্যাংক',
    type: 'BANK',
    openingBalancePaisa: 14500000, // ৳ ১,৪৫,০০০
    createdAt: '2026-10-01',
    isDemo: true,
  },
];

export function createDemoTransactions(): TransactionRecord[] {
  const today = getTodayISO();
  const ym = today.slice(0, 7);

  return [
    {
      id: 'tx-demo-1',
      type: 'INCOME',
      amountPaisa: 1850000, // ৳ ১৮,৫০০
      date: today,
      category: 'পণ্য বিক্রয়',
      accountId: 'acc-cash',
      note: 'দৈনিক খুচরা বিক্রয়',
      createdAt: today,
      isDemo: true,
    },
    {
      id: 'tx-demo-2',
      type: 'INCOME',
      amountPaisa: 1240000, // ৳ ১২,৪০০
      date: today,
      category: 'পণ্য বিক্রয়',
      accountId: 'acc-bkash',
      note: 'অনলাইন অর্ডার পেমেন্ট',
      createdAt: today,
      isDemo: true,
    },
    {
      id: 'tx-demo-3',
      type: 'EXPENSE',
      amountPaisa: 165000, // ৳ ১,৬৫০
      date: today,
      category: 'যাতায়াত ও পরিবহন',
      accountId: 'acc-cash',
      note: 'কুরিয়ার চার্জ ও ভ্যান ভাড়া',
      createdAt: today,
      isDemo: true,
    },
    {
      id: 'tx-demo-4',
      type: 'EXPENSE',
      amountPaisa: 4200000, // ৳ ৪২,০০০
      date: `${ym}-12`,
      category: 'মালামাল ক্রয়',
      accountId: 'acc-bank',
      note: 'পাইকারি মার্কেট থেকে নতুন মাল ক্রয়',
      createdAt: `${ym}-12`,
      isDemo: true,
    },
    {
      id: 'tx-demo-5',
      type: 'INCOME',
      amountPaisa: 2800000, // ৳ ২৮,০০০
      date: `${ym}-10`,
      category: 'সেবা হতে আয়',
      accountId: 'acc-bank',
      note: 'সার্ভিস ও পরামর্শ ফি',
      createdAt: `${ym}-10`,
      isDemo: true,
    },
    {
      id: 'tx-demo-6',
      type: 'EXPENSE',
      amountPaisa: 1500000, // ৳ ১৫,০০০
      date: `${ym}-05`,
      category: 'ভাড়া পরিশোধ',
      accountId: 'acc-bank',
      note: 'দোকান ভাড়া পরিশোধ',
      createdAt: `${ym}-05`,
      isDemo: true,
    },
    {
      id: 'tx-demo-7',
      type: 'EXPENSE',
      amountPaisa: 480000, // ৳ ৪,৮০০
      date: `${ym}-15`,
      category: 'পারিবারিক বাজার খরচ',
      accountId: 'acc-bkash',
      note: 'সাপ্তাহিক কাঁচাবাজার ও মুদি সামগ্রী',
      createdAt: `${ym}-15`,
      isDemo: true,
    },
  ];
}

export function createDemoDebts(): DebtRecord[] {
  const today = getTodayISO();
  const ym = today.slice(0, 7);

  return [
    {
      id: 'debt-demo-1',
      direction: 'RECEIVABLE_OTHER',
      contactName: 'রফিকুল ইসলাম',
      phone: '01712-345678',
      principalPaisa: 3500000,
      date: `${ym}-04`,
      dueDate: `${ym}-25`,
      notes: 'পাইকারি মালামাল বাকিতে বিক্রয়',
      repayments: [
        {
          id: 'rep-demo-1',
          debtId: 'debt-demo-1',
          amountPaisa: 1500000,
          date: `${ym}-14`,
          accountId: 'acc-bkash',
          note: 'প্রথম কিস্তি বিকাশে প্রাপ্ত',
          createdAt: `${ym}-14`,
        },
      ],
      createdAt: `${ym}-04`,
      isDemo: true,
    },
    {
      id: 'debt-demo-2',
      direction: 'LENT',
      contactName: 'তানভীর আহমেদ',
      phone: '01819-223344',
      principalPaisa: 1200000,
      date: '2026-09-15',
      dueDate: '2026-10-15',
      accountId: 'acc-cash',
      notes: 'জরুরি চিকিৎসা প্রয়োজনে ধার দেওয়া হয়েছে',
      repayments: [],
      createdAt: '2026-09-15',
      isDemo: true,
    },
    {
      id: 'debt-demo-3',
      direction: 'PAYABLE_OTHER',
      contactName: 'আল-আমিন এন্টারপ্রাইজ',
      phone: '01911-887766',
      principalPaisa: 5000000,
      date: `${ym}-08`,
      dueDate: '2026-11-10',
      notes: 'শীতকালীন পণ্যের চালানের বকেয়া',
      repayments: [
        {
          id: 'rep-demo-2',
          debtId: 'debt-demo-3',
          amountPaisa: 2000000,
          date: `${ym}-19`,
          accountId: 'acc-bank',
          note: 'ব্যাংকের মাধ্যমে আংশিক পরিশোধ',
          createdAt: `${ym}-19`,
        },
      ],
      createdAt: `${ym}-08`,
      isDemo: true,
    },
  ];
}

export function createDemoSubscriptions(): SubscriptionRecord[] {
  return [
    {
      id: 'sub-demo-1',
      nameBn: 'দোকান ভাড়া',
      nameEn: 'দোকান ভাড়া',
      amountPaisa: 1500000,
      cycle: 'MONTHLY',
      nextDueDate: '2026-11-05',
      category: 'ভাড়া পরিশোধ',
      defaultAccountId: 'acc-bank',
      active: true,
      notes: 'প্রতি মাসের ৫ তারিখের মধ্যে পরিশোধযোগ্য',
      paymentHistory: [
        {
          id: 'subpay-1',
          subscriptionId: 'sub-demo-1',
          amountPaisa: 1500000,
          paidDate: '2026-10-05',
          forPeriodDueDate: '2026-10-05',
          accountId: 'acc-bank',
          note: 'অক্টোবর মাসের ভাড়া পরিশোধিত',
        },
      ],
      createdAt: '2026-09-01',
      isDemo: true,
    },
    {
      id: 'sub-demo-2',
      nameBn: 'ব্রডব্যান্ড ইন্টারনেট বিল',
      nameEn: 'ব্রডব্যান্ড ইন্টারনেট বিল',
      amountPaisa: 120000,
      cycle: 'MONTHLY',
      nextDueDate: '2026-10-25',
      category: 'বিদ্যুৎ ও ইন্টারনেট বিল',
      defaultAccountId: 'acc-bkash',
      active: true,
      notes: 'অফিস ও শোরুম ওয়াইফাই সংযোগ',
      paymentHistory: [
        {
          id: 'subpay-2',
          subscriptionId: 'sub-demo-2',
          amountPaisa: 120000,
          paidDate: '2026-09-24',
          forPeriodDueDate: '2026-09-25',
          accountId: 'acc-bkash',
          note: 'সেপ্টেম্বর মাসের ইন্টারনেট বিল',
        },
      ],
      createdAt: '2026-08-01',
      isDemo: true,
    },
    {
      id: 'sub-demo-3',
      nameBn: 'বিদ্যুৎ বিল',
      nameEn: 'বিদ্যুৎ বিল',
      amountPaisa: 320000,
      cycle: 'MONTHLY',
      nextDueDate: '2026-11-01',
      category: 'বিদ্যুৎ ও ইন্টারনেট বিল',
      defaultAccountId: 'acc-bkash',
      active: true,
      notes: 'প্রিপেইড মিটার রিচার্জ',
      paymentHistory: [],
      createdAt: '2026-09-01',
      isDemo: true,
    },
  ];
}
