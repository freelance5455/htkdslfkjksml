import { Stage } from '../types/crossword';
import {
  getGoldenStage1,
  getGoldenStage2,
  getGoldenStage3,
  getGoldenStage4,
  getGoldenStage5,
  getGoldenStage6,
  getGoldenStage7,
  getGoldenStage8,
  getGoldenStage9,
  getGoldenStage10,
  getGoldenStage11,
  getGoldenStage12,
  getGoldenStage13,
  getGoldenStage14,
  getGoldenStage15,
  getGoldenStage16,
  getGoldenStage17,
  getGoldenStage18,
  getGoldenStage19,
  getGoldenStage20,
  getGoldenStage21,
  getGoldenStage22,
  getGoldenStage23,
  getGoldenStage24,
  getGoldenStage25,
  getGoldenStage26,
  getGoldenStage27,
  getGoldenStage28,
  getGoldenStage29,
  getGoldenStage30,
  getGoldenStage31,
  getGoldenStage32,
  getGoldenStage33,
  getGoldenStage34,
  getGoldenStage35,
  getGoldenStage36,
  getGoldenStage37,
  getGoldenStage38,
  getGoldenStage39,
  getGoldenStage40,
  getGoldenStage41,
  getGoldenStage42,
  getGoldenStage43,
  getGoldenStage44,
  getGoldenStage45,
  getGoldenStage46,
  getGoldenStage47,
  getGoldenStage48,
  getGoldenStage49,
  getGoldenStage50
} from './goldenStageLoader';

/**
 * AUTHORITATIVE STAGES DATABASE
 * Stages 1 through 19 are loaded directly from verified golden layout files with 100% mathematical validation.
 */

export function convertToArabicNumerals(num: number): string {
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return num
    .toString()
    .split('')
    .map((d) => arabicDigits[parseInt(d, 10)] || d)
    .join('');
}

export const ARABIC_STAGE_ORDINALS: { [key: number]: string } = {
  1: 'الأولى',
  2: 'الثانية',
  3: 'الثالثة',
  4: 'الرابعة',
  5: 'الخامسة',
  6: 'السادسة',
  7: 'السابعة',
  8: 'الثامنة',
  9: 'التاسعة',
  10: 'العاشرة',
  11: 'الحادية عشرة',
  12: 'الثانية عشرة',
  13: 'الثالثة عشرة',
  14: 'الرابعة عشرة',
  15: 'الخامسة عشرة',
  16: 'السادسة عشرة',
  17: 'السابعة عشرة',
  18: 'الثامنة عشرة',
  19: 'التاسعة عشرة',
  20: 'العشرون',
  21: 'الحادية والعشرون',
  22: 'الثانية والعشرون',
  23: 'الثالثة والعشرون',
  24: 'الرابعة والعشرون',
  25: 'الخامسة والعشرون',
  26: 'السادسة والعشرون',
  27: 'السابعة والعشرون',
  28: 'الثامنة والعشرون',
  29: 'التاسعة والعشرون',
  30: 'الثلاثون',
  31: 'الحادية والثلاثون',
  32: 'الثانية والثلاثون',
  33: 'الثالثة والثلاثون',
  34: 'الرابعة والثلاثون',
  35: 'الخامسة والثلاثون',
  36: 'السادسة والثلاثون',
  37: 'السابعة والثلاثون',
  38: 'الثامنة والثلاثون',
  39: 'التاسعة والثلاثون',
  40: 'الأربعون',
  41: 'الحادية والأربعون',
  42: 'الثانية والأربعون',
  43: 'الثالثة والأربعون',
  44: 'الرابعة والأربعون',
  45: 'الخامسة والأربعون',
  46: 'السادسة والأربعون',
  47: 'السابعة والأربعون',
  48: 'الثامنة والأربعون',
  49: 'التاسعة والأربعون',
  50: 'الخمسون'
};

export function getArabicOrdinalStageTitle(stageId: number): string {
  if (ARABIC_STAGE_ORDINALS[stageId]) {
    return `المرحلة ${ARABIC_STAGE_ORDINALS[stageId]}`;
  }
  return `المرحلة ${convertToArabicNumerals(stageId)}`;
}

function createStubStage(stageId: number): Stage {
  const questions = [];

  for (let i = 1; i <= 13; i++) {
    questions.push({
      id: `h_${i}`,
      number: i,
      direction: 'horizontal' as const,
      clue: `سؤال أفقي ${i} للمرحلة ${stageId} (نموذج محجوز في إطار الهيكل العام)`,
      answer: 'نموذج',
      startPos: { row: (i - 1) % 12, col: 0 },
      length: 5
    });
  }

  for (let j = 1; j <= 12; j++) {
    questions.push({
      id: `v_${j}`,
      number: 13 + j,
      direction: 'vertical' as const,
      clue: `سؤال عمودي ${j} للمرحلة ${stageId} (نموذج محجوز في إطار الهيكل العام)`,
      answer: 'اختبار',
      startPos: { row: 0, col: (j - 1) % 12 },
      length: 5
    });
  }

  // Exact 15x15 grid
  const rows = 15;
  const cols = 15;
  const used = new Set<string>();
  for (const q of questions) {
    for (let i = 0; i < q.length; i++) {
      const r = q.direction === 'vertical' ? q.startPos.row + i : q.startPos.row;
      const c = q.direction === 'horizontal' ? q.startPos.col + i : q.startPos.col;
      used.add(`${r}_${c}`);
    }
  }

  const blockedCells: { row: number; col: number }[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (!used.has(`${r}_${c}`)) {
        blockedCells.push({ row: r, col: c });
      }
    }
  }

  return {
    id: stageId,
    title: getArabicOrdinalStageTitle(stageId),
    gridSize: { rows, cols },
    blockedCells,
    questions
  };
}

export const STAGES_DATABASE: Stage[] = [
  getGoldenStage1(),
  getGoldenStage2(),
  getGoldenStage3(),
  getGoldenStage4(),
  getGoldenStage5(),
  getGoldenStage6(),
  getGoldenStage7(),
  getGoldenStage8(),
  getGoldenStage9(),
  getGoldenStage10(),
  getGoldenStage11(),
  getGoldenStage12(),
  getGoldenStage13(),
  getGoldenStage14(),
  getGoldenStage15(),
  getGoldenStage16(),
  getGoldenStage17(),
  getGoldenStage18(),
  getGoldenStage19(),
  getGoldenStage20(),
  getGoldenStage21(),
  getGoldenStage22(),
  getGoldenStage23(),
  getGoldenStage24(),
  getGoldenStage25(),
  getGoldenStage26(),
  getGoldenStage27(),
  getGoldenStage28(),
  getGoldenStage29(),
  getGoldenStage30(),
  getGoldenStage31(),
  getGoldenStage32(),
  getGoldenStage33(),
  getGoldenStage34(),
  getGoldenStage35(),
  getGoldenStage36(),
  getGoldenStage37(),
  getGoldenStage38(),
  getGoldenStage39(),
  getGoldenStage40(),
  getGoldenStage41(),
  getGoldenStage42(),
  getGoldenStage43(),
  getGoldenStage44(),
  getGoldenStage45(),
  getGoldenStage46(),
  getGoldenStage47(),
  getGoldenStage48(),
  getGoldenStage49(),
  getGoldenStage50()
];

export const TOTAL_QUESTIONS_COUNT = 50 * 25;
