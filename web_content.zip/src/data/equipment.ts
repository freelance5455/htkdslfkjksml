import { EquipmentItem, EquipmentSlot, EquipmentTier } from '../types/cultivation';

export const EQUIPMENT_CATALOG: EquipmentItem[] = [
  // --- CLOTHING / ROBES ---
  // Mortal (Min Realm 0 - Qi Condensation 1)
  { id: 'eq_c_1', name: 'Hemp Daoist Robe', slot: 'clothing', tier: 'Mortal', minRealmIndex: 0, combatBonus: 5, cultivationRateBonus: 5, defenseBonus: 4, description: 'Simple linen garment woven with minor cooling runes.' },
  { id: 'eq_c_2', name: 'Pale Silk Skirt', slot: 'clothing', tier: 'Mortal', minRealmIndex: 0, combatBonus: 5, cultivationRateBonus: 5, defenseBonus: 4, description: 'Supple river-silk robes embroidered with aquatic lotus motifs.' },
  // Spiritual (Min Realm 9 - Foundation Establishment)
  { id: 'eq_c_3', name: 'Azure Cloud Dao Vestment', slot: 'clothing', tier: 'Spiritual', minRealmIndex: 9, combatBonus: 250, cultivationRateBonus: 10, defenseBonus: 180, description: 'Spun from heavenly mist cocoon threads; protects against miasma.' },
  { id: 'eq_c_4', name: 'Shadow Wolf Fur Coat', slot: 'clothing', tier: 'Spiritual', minRealmIndex: 9, combatBonus: 320, cultivationRateBonus: 8, defenseBonus: 220, description: 'Crafted from black demon wolf pelts; grants agility and stealth.' },
  // Earth (Min Realm 13 - Golden Core)
  { id: 'eq_c_5', name: 'Crimson Dragon Silk Mantle', slot: 'clothing', tier: 'Earth', minRealmIndex: 13, combatBonus: 2800, cultivationRateBonus: 15, defenseBonus: 2200, description: 'Bathed in dragon pool essence; grants fire resistance and draconic vigor.' },
  // Heaven (Min Realm 17 - Nascent Soul)
  { id: 'eq_c_6', name: 'Nine Heavens Phoenix Feather Robe', slot: 'clothing', tier: 'Heaven', minRealmIndex: 17, combatBonus: 28000, cultivationRateBonus: 25, defenseBonus: 24000, description: 'Woven with celestial phoenix plumage; revives wearer upon fatal trauma.' },
  // Divine (Min Realm 21 - Soul Formation)
  { id: 'eq_c_7', name: 'Primordial Chaos Emperor Gown', slot: 'clothing', tier: 'Divine', minRealmIndex: 21, combatBonus: 350000, cultivationRateBonus: 40, defenseBonus: 300000, description: 'Transformed from world-origin mist; absorbs 40% of all divine tribulation damage.' },

  // --- WEAPONS ---
  // Mortal
  { id: 'eq_w_1', name: 'Cold Iron Flying Sword', slot: 'weapon', tier: 'Mortal', minRealmIndex: 0, combatBonus: 15, cultivationRateBonus: 3, defenseBonus: 2, description: 'Tempered in spring water by mortal blacksmiths; sharp and responsive to Qi.' },
  { id: 'eq_w_2', name: 'Willow Wood Spirit Staff', slot: 'weapon', tier: 'Mortal', minRealmIndex: 0, combatBonus: 12, cultivationRateBonus: 6, defenseBonus: 3, description: 'Carved from century-old spirit willow; channels wood restorative Qi.' },
  // Spiritual
  { id: 'eq_w_3', name: 'Azure Wind Speed Blade', slot: 'weapon', tier: 'Spiritual', minRealmIndex: 9, combatBonus: 450, cultivationRateBonus: 10, defenseBonus: 50, description: 'Imbued with wind elemental crystals; swings with sonic slicing waves.' },
  { id: 'eq_w_4', name: 'Thunder Arc Halberd', slot: 'weapon', tier: 'Spiritual', minRealmIndex: 9, combatBonus: 520, cultivationRateBonus: 8, defenseBonus: 70, description: 'Attracts minor static lightning to paralyze demonic beasts.' },
  // Earth
  { id: 'eq_w_5', name: 'Seven Stars Dragon Slaying Blade', slot: 'weapon', tier: 'Earth', minRealmIndex: 13, combatBonus: 4200, cultivationRateBonus: 15, defenseBonus: 500, description: 'Forged from meteorite star metal; unleashes devastating astral sword beams.' },
  // Heaven
  { id: 'eq_w_6', name: 'Void Slicing Immortal Sword', slot: 'weapon', tier: 'Heaven', minRealmIndex: 17, combatBonus: 45000, cultivationRateBonus: 25, defenseBonus: 4000, description: 'Cuts through dimensional fabrics and bypasses standard defensive barriers.' },
  // Divine
  { id: 'eq_w_7', name: 'Taiji Yin-Yang Primordial Sword', slot: 'weapon', tier: 'Divine', minRealmIndex: 21, combatBonus: 500000, cultivationRateBonus: 45, defenseBonus: 60000, description: 'Supreme ancestral relic capable of overturning heavens and calming oceans.' },

  // --- ITEM BOOST / TALISMAN / MIRROR ---
  // Mortal
  { id: 'eq_i_1', name: 'Carved Peach Wood Amulet', slot: 'item', tier: 'Mortal', minRealmIndex: 0, combatBonus: 6, cultivationRateBonus: 6, defenseBonus: 4, description: 'Wards off malicious ghosts and purifies wandering thoughts.' },
  { id: 'eq_i_2', name: 'Bronze Qi Focusing Ring', slot: 'item', tier: 'Mortal', minRealmIndex: 0, combatBonus: 8, cultivationRateBonus: 8, defenseBonus: 2, description: 'Steadies the meridian flow during quiet meditation sessions.' },
  // Spiritual
  { id: 'eq_i_3', name: 'Warm Jade Spirit Pendant', slot: 'item', tier: 'Spiritual', minRealmIndex: 9, combatBonus: 200, cultivationRateBonus: 12, defenseBonus: 150, description: 'Continuously feeds pure spiritual fluid into the dantein.' },
  // Earth
  { id: 'eq_i_4', name: 'Soul Gathering Tourmaline Ring', slot: 'item', tier: 'Earth', minRealmIndex: 13, combatBonus: 2200, cultivationRateBonus: 20, defenseBonus: 1600, description: 'Extends spiritual awareness across 50 leagues.' },
  // Heaven
  { id: 'eq_i_5', name: 'Taiji Bagua Divine Mirror', slot: 'item', tier: 'Heaven', minRealmIndex: 17, combatBonus: 22000, cultivationRateBonus: 30, defenseBonus: 20000, description: 'Reflects 30% of incoming spells back at hostile attackers.' },
  // Divine
  { id: 'eq_i_6', name: 'Eternal Life Jade Pendant', slot: 'item', tier: 'Divine', minRealmIndex: 21, combatBonus: 280000, cultivationRateBonus: 50, defenseBonus: 250000, description: 'Directly bestows +500 years to carrier lifespan.' },

  // --- COMPANION / SPIRIT BEAST ---
  // Mortal
  { id: 'eq_b_1', name: 'Crested Mountain Sparrow', slot: 'companion', tier: 'Mortal', minRealmIndex: 0, combatBonus: 8, cultivationRateBonus: 4, defenseBonus: 2, description: 'Alert winged companion that scouts surrounding trails for herbs.' },
  // Spiritual
  { id: 'eq_b_2', name: 'Nine-Tailed Spirit Fox Cub', slot: 'companion', tier: 'Spiritual', minRealmIndex: 9, combatBonus: 350, cultivationRateBonus: 12, defenseBonus: 120, description: 'Playful spirit beast possessing illusion sorcery and keen gem senses.' },
  // Earth
  { id: 'eq_b_3', name: 'Thunder-Armored Saber Wolf', slot: 'companion', tier: 'Earth', minRealmIndex: 13, combatBonus: 3500, cultivationRateBonus: 16, defenseBonus: 1800, description: 'Terrifying apex predator galloping on crackling lightning clouds.' },
  // Heaven
  { id: 'eq_b_4', name: 'Azure Feather Phoenix Chick', slot: 'companion', tier: 'Heaven', minRealmIndex: 17, combatBonus: 32000, cultivationRateBonus: 28, defenseBonus: 16000, description: 'Divine celestial bird that showers heavenly dew upon its master.' },
  // Divine
  { id: 'eq_b_5', name: 'Golden Kirin Sacred Beast', slot: 'companion', tier: 'Divine', minRealmIndex: 21, combatBonus: 420000, cultivationRateBonus: 45, defenseBonus: 280000, description: 'Auspicious ruler of all terrestrial beasts; brings immortal destiny and luck.' }
];

export function getAvailableEquipmentsForDisciple(realmIndex: number, slot: EquipmentSlot): EquipmentItem[] {
  return EQUIPMENT_CATALOG.filter(e => e.slot === slot && e.minRealmIndex <= realmIndex);
}
