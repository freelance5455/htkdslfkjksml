export interface AndroidCodeFile {
  filename: string;
  path: string;
  language: string;
  description: string;
  code: string;
}

export const KOTLIN_ANDROID_FILES: AndroidCodeFile[] = [
  {
    filename: 'MainActivity.kt',
    path: 'app/src/main/java/com/indiajobhub/app/MainActivity.kt',
    language: 'kotlin',
    description: 'Main Android Activity hosting Jetpack Compose Navigation & Scaffold',
    code: `package com.indiajobhub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.indiajobhub.app.ui.navigation.AppNavGraph
import com.indiajobhub.app.ui.theme.IndiaJobHubTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IndiaJobHubTheme {
                val navController = rememberNavController()
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavGraph(navController = navController)
                }
            }
        }
    }
}`
  },
  {
    filename: 'JobPosting.kt',
    path: 'app/src/main/java/com/indiajobhub/app/data/model/JobPosting.kt',
    language: 'kotlin',
    description: 'Firebase Firestore Data Class with status enum, PDF URL, and verification fields',
    code: `package com.indiajobhub.app.data.model

import com.google.firebase.firestore.PropertyName

enum class JobStatus {
    DRAFT,
    PENDING,
    VERIFIED,
    PUBLISHED,
    EXPIRED,
    REJECTED
}

data class JobPosting(
    @get:PropertyName("id") @set:PropertyName("id") var id: String = "",
    @get:PropertyName("title") @set:PropertyName("title") var title: String = "",
    @get:PropertyName("organization") @set:PropertyName("organization") var organization: String = "",
    @get:PropertyName("sector") @set:PropertyName("sector") var sector: String = "Government", // Government or Private
    @get:PropertyName("categories") @set:PropertyName("categories") var categories: List<String> = emptyList(),
    @get:PropertyName("state") @set:PropertyName("state") var state: String = "",
    @get:PropertyName("district") @set:PropertyName("district") var district: String = "",
    @get:PropertyName("qualification") @set:PropertyName("qualification") var qualification: String = "",
    @get:PropertyName("salary") @set:PropertyName("salary") var salary: String = "",
    @get:PropertyName("vacancies") @set:PropertyName("vacancies") var vacancies: Int = 0,
    @get:PropertyName("openingDate") @set:PropertyName("openingDate") var openingDate: String = "",
    @get:PropertyName("closingDate") @set:PropertyName("closingDate") var closingDate: String = "",
    @get:PropertyName("lastDate") @set:PropertyName("lastDate") var lastDate: String = "",
    @get:PropertyName("postDate") @set:PropertyName("postDate") var postDate: String = "",
    @get:PropertyName("officialApplicationLink") @set:PropertyName("officialApplicationLink") var officialApplicationLink: String = "",
    @get:PropertyName("officialSource") @set:PropertyName("officialSource") var officialSource: String = "",
    @get:PropertyName("officialNotificationPdfUrl") @set:PropertyName("officialNotificationPdfUrl") var officialNotificationPdfUrl: String? = null,
    @get:PropertyName("status") @set:PropertyName("status") var status: String = "PUBLISHED",
    @get:PropertyName("isVerified") @set:PropertyName("isVerified") var isVerified: Boolean = true,
    @get:PropertyName("isFeatured") @set:PropertyName("isFeatured") var isFeatured: Boolean = false,
    @get:PropertyName("isUrgent") @set:PropertyName("isUrgent") var isUrgent: Boolean = false,
    @get:PropertyName("isLatest") @set:PropertyName("isLatest") var isLatest: Boolean = true,
    @get:PropertyName("applicationFee") @set:PropertyName("applicationFee") var applicationFee: String = "",
    @get:PropertyName("ageLimit") @set:PropertyName("ageLimit") var ageLimit: String = "",
    @get:PropertyName("selectionProcess") @set:PropertyName("selectionProcess") var selectionProcess: List<String> = emptyList(),
    @get:PropertyName("description") @set:PropertyName("description") var description: String = "",
    @get:PropertyName("demoDataBadge") @set:PropertyName("demoDataBadge") var demoDataBadge: Boolean = false
)`
  },
  {
    filename: 'JobRepository.kt',
    path: 'app/src/main/java/com/indiajobhub/app/data/repository/JobRepository.kt',
    language: 'kotlin',
    description: 'Repository handling real-time Firestore flow, query filters, and security validations',
    code: `package com.indiajobhub.app.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.indiajobhub.app.data.model.JobPosting
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class JobRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val jobsCollection = firestore.collection("jobs")

    // Real-time published jobs Flow with automatic status filtering
    fun getPublishedJobsFlow(): Flow<List<JobPosting>> = callbackFlow {
        val listener = jobsCollection
            .whereIn("status", listOf("PUBLISHED", "VERIFIED"))
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val jobs = snapshot.toObjects(JobPosting::class.java)
                    trySend(jobs)
                }
            }
        awaitClose { listener.remove() }
    }

    // State, District, and Category Filtered query
    suspend fun getFilteredJobs(
        state: String? = null,
        district: String? = null,
        category: String? = null
    ): List<JobPosting> {
        var query: Query = jobsCollection.whereIn("status", listOf("PUBLISHED", "VERIFIED"))
        if (!state.isNullOrEmpty() && state != "All") {
            query = query.whereEqualTo("state", state)
        }
        if (!district.isNullOrEmpty() && district != "All") {
            query = query.whereEqualTo("district", district)
        }
        if (!category.isNullOrEmpty() && category != "All") {
            query = query.whereArrayContains("categories", category)
        }

        val snapshot = query.get().await()
        return snapshot.toObjects(JobPosting::class.java)
    }

    // Save job into Cloud Firestore
    suspend fun saveJob(job: JobPosting): Result<Unit> = runCatching {
        val docRef = if (job.id.isEmpty()) jobsCollection.document() else jobsCollection.document(job.id)
        job.id = docRef.id
        docRef.set(job).await()
    }

    // Bookmark / Save job
    suspend fun toggleSaveJob(userId: String, jobId: String, isSaved: Boolean) {
        val docRef = firestore.collection("users").document(userId)
            .collection("saved_jobs").document(jobId)
        if (isSaved) {
            docRef.delete().await()
        } else {
            docRef.set(mapOf("jobId" to jobId, "savedAt" to com.google.firebase.Timestamp.now())).await()
        }
    }
}`
  },
  {
    filename: 'IndiaJobHubMessagingService.kt',
    path: 'app/src/main/java/com/indiajobhub/app/service/IndiaJobHubMessagingService.kt',
    language: 'kotlin',
    description: 'Firebase Cloud Messaging (FCM) service for new vacancy alerts and last date reminders',
    code: `package com.indiajobhub.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.indiajobhub.app.MainActivity
import com.indiajobhub.app.R

class IndiaJobHubMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Send device registration token to Firestore for personalized alerts
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        val title = remoteMessage.notification?.title ?: "New Job Vacancy Alert"
        val body = remoteMessage.notification?.body ?: "A new job matching your preferences has been posted."
        val jobId = remoteMessage.data["jobId"]

        showNotification(title, body, jobId)
    }

    private fun showNotification(title: String, body: String, jobId: String?) {
        val channelId = "job_vacancies_channel"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Job Vacancies & Gazette Alerts",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("EXTRA_JOB_ID", jobId)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }
}`
  },
  {
    filename: 'AppCheckConfig.kt',
    path: 'app/src/main/java/com/indiajobhub/app/security/AppCheckConfig.kt',
    language: 'kotlin',
    description: 'Firebase App Check configuration utilizing Google Play Integrity provider',
    code: `package com.indiajobhub.app.security

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

object AppCheckConfig {
    fun initialize(context: Context) {
        FirebaseApp.initializeApp(context)
        val firebaseAppCheck = FirebaseAppCheck.getInstance()
        
        // Enforce Google Play Integrity verification for Android production release
        firebaseAppCheck.installAppCheckProviderFactory(
            PlayIntegrityAppCheckProviderFactory.getInstance()
        )
    }
}`
  },
  {
    filename: 'LocationDrillDownScreen.kt',
    path: 'app/src/main/java/com/indiajobhub/app/ui/screens/LocationDrillDownScreen.kt',
    language: 'kotlin',
    description: 'State → District → Job Category → Jobs interactive drilldown in Jetpack Compose',
    code: `package com.indiajobhub.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationDrillDownScreen(
    onJobSelected: (String) -> Unit,
    onBack: () -> Unit
) {
    var step by remember { mutableStateOf(1) } // 1: State, 2: District, 3: Category, 4: Results
    var selectedState by remember { mutableStateOf("") }
    var selectedDistrict by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Select Location & Category", style = MaterialTheme.typography.titleMedium)
                        Text(
                            when(step) {
                                1 -> "Step 1 of 3: Select State"
                                2 -> "Step 2 of 3: $selectedState → Select District"
                                3 -> "Step 3 of 3: $selectedDistrict → Select Category"
                                else -> "$selectedDistrict • $selectedCategory"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (step > 1) step -= 1 else onBack()
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search " + if (step == 1) "States" else if (step == 2) "Districts" else "Categories") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            )

            AnimatedContent(targetState = step, label = "DrillDownTransition") { currentStep ->
                when (currentStep) {
                    1 -> StateList(searchQuery) { state ->
                        selectedState = state
                        searchQuery = ""
                        step = 2
                    }
                    2 -> DistrictList(selectedState, searchQuery) { district ->
                        selectedDistrict = district
                        searchQuery = ""
                        step = 3
                    }
                    3 -> CategoryList(searchQuery) { category ->
                        selectedCategory = category
                        searchQuery = ""
                        step = 4
                    }
                    4 -> FilteredJobsResult(selectedState, selectedDistrict, selectedCategory, onJobSelected)
                }
            }
        }
    }
}`
  },
  {
    filename: 'HomeScreen.kt',
    path: 'app/src/main/java/com/indiajobhub/app/ui/screens/HomeScreen.kt',
    language: 'kotlin',
    description: 'Jetpack Compose Home Screen with all 12 requested job categories and search',
    code: `package com.indiajobhub.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

val HOME_CATEGORIES = listOf(
    "All", "Government Jobs", "Private Jobs", "Latest Jobs",
    "Jobs Near Me", "ITI Jobs", "Diploma Jobs", "Graduate Jobs",
    "Railway Jobs", "Banking Jobs", "Defence Jobs", "Apprenticeship Jobs"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToDrillDown: () -> Unit,
    onNavigateToNearMe: () -> Unit,
    onJobClick: (String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("All") }
    var searchInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("India Job Hub", style = MaterialTheme.typography.titleLarge) },
                actions = {
                    IconButton(onClick = onNavigateToDrillDown) {
                        Icon(Icons.Default.LocationOn, contentDescription = "State Filter")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                OutlinedTextField(
                    value = searchInput,
                    onValueChange = { searchInput = it },
                    placeholder = { Text("Search job title, railway, banking, ITI...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Text("Job Categories", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(HOME_CATEGORIES) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = {
                                if (cat == "Jobs Near Me") onNavigateToNearMe()
                                else selectedCategory = cat
                            },
                            label = { Text(cat) }
                        )
                    }
                }
            }
        }
    }
}`
  },
  {
    filename: 'build.gradle.kts',
    path: 'app/build.gradle.kts',
    language: 'kotlin',
    description: 'Gradle configuration with Jetpack Compose BOM, Navigation, Coroutines & Firebase BoM',
    code: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.google.gms.google.services) // Google Services for Firebase
}

android {
    namespace = "com.indiajobhub.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.indiajobhub.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")

    // Firebase BoM & Services
    val firebaseBom = platform("com.google.firebase:firebase-bom:33.3.0")
    implementation(firebaseBom)
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-storage-ktx")
    implementation("com.google.firebase:firebase-messaging-ktx")
    implementation("com.google.firebase:firebase-appcheck-playintegrity")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}`
  }
];
