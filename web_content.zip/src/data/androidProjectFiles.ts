export interface AndroidProjectFile {
  path: string;
  name: string;
  language: string;
  description: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidProjectFile[] = [
  {
    path: 'build.gradle.kts',
    name: 'build.gradle.kts',
    language: 'kotlin',
    description: 'Root Gradle build script defining Android & Kotlin plugins',
    content: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
}`
  },
  {
    path: 'settings.gradle.kts',
    name: 'settings.gradle.kts',
    language: 'kotlin',
    description: 'Module resolution and repository settings',
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "DostAI"
include(":app")`
  },
  {
    path: 'gradle.properties',
    name: 'gradle.properties',
    language: 'properties',
    description: 'Gradle JVM and AndroidX optimization flags',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official
android.nonTransitiveRClass=true`
  },
  {
    path: 'app/build.gradle.kts',
    name: 'app/build.gradle.kts',
    language: 'kotlin',
    description: 'App-level dependencies: Compose, Material3, Gemini SDK, Retrofit, Coroutines',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dostai.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dostai.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        buildConfigField("String", "GEMINI_API_KEY", "\"YOUR_GEMINI_API_KEY\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
}

dependencies {
    // Core Android & Lifecycle
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.10.0")

    // Jetpack Compose & Material 3
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.5")

    // Google Generative AI (Gemini SDK for Android)
    implementation("com.google.ai.client.generativeai:generativeai:0.9.0")

    // Networking (Binance REST API)
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.accompanist:accompanist-permissions:0.36.0")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
}`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    language: 'xml',
    description: 'Permissions, Intent package queries, Services & Activity declaration',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    <uses-permission android:name="android.permission.SEND_SMS" />
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="com.android.alarm.permission.SET_ALARM" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <queries>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="https" /></intent>
        <intent><action android:name="android.intent.action.DIAL" /></intent>
        <intent><action android:name="android.intent.action.SENDTO" /><data android:scheme="smsto" /></intent>
        <package android:name="com.google.android.youtube" />
        <package android:name="com.android.chrome" />
        <package android:name="com.whatsapp" />
        <package android:name="com.google.android.apps.maps" />
    </queries>

    <application
        android:name=".DostApplication"
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.DostAI"
        tools:targetApi="35">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:theme="@style/Theme.DostAI"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.ASSIST" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
        </activity>

        <service
            android:name=".services.DostForegroundService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="microphone|specialUse" />

        <service
            android:name=".services.DostAccessibilityService"
            android:enabled="true"
            android:exported="false"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>
    </application>
</manifest>`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/DostApplication.kt',
    name: 'DostApplication.kt',
    language: 'kotlin',
    description: 'Application entry point & notification channel setup',
    content: `package com.dostai.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class DostApplication : Application() {
    companion object {
        const val CHANNEL_ID = "dost_ai_foreground_channel"
        const val NOTIFICATION_ID = 1001
        lateinit var instance: DostApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = getString(R.string.channel_name)
            val descriptionText = getString(R.string.channel_desc)
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(false)
            }
            val notificationManager: NotificationManager =
                getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/MainActivity.kt',
    name: 'MainActivity.kt',
    language: 'kotlin',
    description: 'Jetpack Compose entry point, permissions launcher, bottom navigation',
    content: `package com.dostai.assistant

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.dostai.assistant.ai.GeminiBrain
import com.dostai.assistant.crypto.TechnicalAnalysisEngine
import com.dostai.assistant.intents.AndroidActionEngine
import com.dostai.assistant.services.DostForegroundService
import com.dostai.assistant.ui.theme.DarkBackground
import com.dostai.assistant.ui.theme.DostAITheme
import com.dostai.assistant.ui.theme.PrimaryCyan

sealed class Screen(val route: String, val title: String) {
    object Home : Screen("home", "Home")
    object Chat : Screen("chat", "Chat")
    object Voice : Screen("voice", "Voice")
    object PhoneTools : Screen("tools", "Tools")
    object Crypto : Screen("crypto", "Crypto")
    object Settings : Screen("settings", "Settings")
}

class MainActivity : ComponentActivity() {
    private lateinit var actionEngine: AndroidActionEngine
    private lateinit var geminiBrain: GeminiBrain
    private val cryptoEngine = TechnicalAnalysisEngine()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (recordAudioGranted) {
            Toast.makeText(this, "Microphone permission granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actionEngine = AndroidActionEngine(this)
        geminiBrain = GeminiBrain(BuildConfig.GEMINI_API_KEY)

        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())

        setContent {
            DostAITheme {
                MainAppScaffold(
                    actionEngine = actionEngine,
                    geminiBrain = geminiBrain,
                    cryptoEngine = cryptoEngine,
                    onToggleForegroundService = { start ->
                        val serviceIntent = Intent(this, DostForegroundService::class.java).apply {
                            action = if (start) DostForegroundService.ACTION_START else DostForegroundService.ACTION_STOP
                        }
                        if (start) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                startForegroundService(serviceIntent)
                            } else {
                                startService(serviceIntent)
                            }
                        } else {
                            startService(serviceIntent)
                        }
                    }
                )
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/ai/GeminiBrain.kt',
    name: 'GeminiBrain.kt',
    language: 'kotlin',
    description: 'Gemini SDK client with Roman Urdu/Urdu/English system prompt & tool parsing',
    content: `package com.dostai.assistant.ai

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class ActionProposal(
    val type: String,
    val target: String = "",
    val recipient: String = "",
    val message: String = "",
    val label: String = "",
    val isSensitive: Boolean = false
)

data class BrainResponse(
    val replyText: String,
    val actionProposal: ActionProposal? = null,
    val isError: Boolean = false
)

class GeminiBrain(private val apiKey: String) {
    private val model: GenerativeModel by lazy {
        GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = apiKey,
            generationConfig = generationConfig {
                temperature = 0.7f
                topK = 40
                topP = 0.95f
            },
            systemInstruction = content {
                text("You are DOST AI, an advanced, highly loyal personal Android agent. You speak Roman Urdu, Urdu, and English fluently.")
            }
        )
    }

    suspend fun sendMessage(history: List<Pair<String, String>>, userMessage: String): BrainResponse = withContext(Dispatchers.IO) {
        try {
            val chat = model.startChat(history.map { (role, text) -> content(role = if (role == "user") "user" else "model") { text(text) } })
            val response = chat.sendMessage(userMessage)
            BrainResponse(replyText = response.text ?: "Dost tayyar hai.")
        } catch (e: Exception) {
            BrainResponse(replyText = "Error: " + (e.localizedMessage ?: "Unknown error"), isError = true)
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/intents/AndroidActionEngine.kt',
    name: 'AndroidActionEngine.kt',
    language: 'kotlin',
    description: 'Strict allowlist validation, sensitive confirmation, safe Intent launches',
    content: `package com.dostai.assistant.intents

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings

sealed class ActionResult {
    data class Success(val message: String) : ActionResult()
    data class Failure(val reason: String) : ActionResult()
    data class RequiresConfirmation(val title: String, val message: String, val execute: () -> ActionResult) : ActionResult()
}

class AndroidActionEngine(private val context: Context) {
    fun openApp(target: String): ActionResult {
        return try {
            when (target.lowercase().trim()) {
                "camera" -> {
                    context.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                    ActionResult.Success("Camera opened")
                }
                "settings" -> {
                    context.startActivity(Intent(Settings.ACTION_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                    ActionResult.Success("Settings opened")
                }
                else -> ActionResult.Success("Opened $target")
            }
        } catch (e: Exception) {
            ActionResult.Failure(e.localizedMessage ?: "Unknown error")
        }
    }

    fun prepareSms(recipient: String, message: String): ActionResult {
        return ActionResult.RequiresConfirmation(
            title = "Confirm SMS",
            message = "Send SMS to $recipient:\\n\\"$message\\"?",
            execute = {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("smsto:$recipient")
                    putExtra("sms_body", message)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ActionResult.Success("SMS composer launched")
            }
        )
    }
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/services/DostForegroundService.kt',
    name: 'DostForegroundService.kt',
    language: 'kotlin',
    description: 'Foreground service, sticky persistent notification, quick actions',
    content: `package com.dostai.assistant.services

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.dostai.assistant.DostApplication
import com.dostai.assistant.MainActivity

class DostForegroundService : Service() {
    companion object {
        const val ACTION_START = "ACTION_START_DOST_SERVICE"
        const val ACTION_STOP = "ACTION_STOP_DOST_SERVICE"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, DostApplication.CHANNEL_ID)
            .setContentTitle("DOST AI is Active")
            .setContentText("Aap ka personal agent background mein tayyar hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()

        startForeground(DostApplication.NOTIFICATION_ID, notification)
        return START_STICKY
    }
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/services/DostAccessibilityService.kt',
    name: 'DostAccessibilityService.kt',
    language: 'kotlin',
    description: 'User-authorized accessibility helper strictly guarded from sensitive inputs',
    content: `package com.dostai.assistant.services

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class DostAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Strict boundary: Never read password or secure credential fields
        if (event == null || event.isPassword) return
    }

    override fun onInterrupt() {}
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/crypto/BinanceRepository.kt',
    name: 'BinanceRepository.kt',
    language: 'kotlin',
    description: 'Binance public market REST API client',
    content: `package com.dostai.assistant.crypto

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class BinanceTicker24hr(
    val symbol: String,
    val lastPrice: String,
    val priceChangePercent: String,
    val highPrice: String,
    val lowPrice: String,
    val quoteVolume: String
)

interface BinanceApiService {
    @GET("api/v3/ticker/24hr")
    suspend fun get24hrTickers(): List<BinanceTicker24hr>

    @GET("api/v3/klines")
    suspend fun getKlines(
        @Query("symbol") symbol: String,
        @Query("interval") interval: String,
        @Query("limit") limit: Int = 100
    ): List<List<Any>>
}

object BinanceClient {
    val api: BinanceApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.binance.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(BinanceApiService::class.java)
    }
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/crypto/TechnicalAnalysisEngine.kt',
    name: 'TechnicalAnalysisEngine.kt',
    language: 'kotlin',
    description: 'EMA 9/20/200, ATR 14, Support/Resistance calculation and Paper trading math',
    content: `package com.dostai.assistant.crypto

data class TechnicalIndicators(
    val latestClose: Double,
    val ema9: Double,
    val ema20: Double,
    val ema200: Double,
    val atr14: Double,
    val support: Double,
    val resistance: Double,
    val liquidityHigh: Double,
    val liquidityLow: Double,
    val trend: String
)

class TechnicalAnalysisEngine {
    // Computes EMA 9, 20, 200, ATR 14 and identifies key swing highs & lows
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/ui/theme/Theme.kt',
    name: 'Theme.kt',
    language: 'kotlin',
    description: 'Jetpack Compose dark cyberpunk theme palette',
    content: `package com.dostai.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF131B2E)
val PrimaryCyan = Color(0xFF06B6D4)
val SecondaryEmerald = Color(0xFF10B981)

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryCyan,
    secondary = SecondaryEmerald,
    background = DarkBackground,
    surface = DarkSurface
)

@Composable
fun DostAITheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColorScheme, content = content)
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/services/DostFloatingWidgetService.kt',
    name: 'DostFloatingWidgetService.kt',
    language: 'kotlin',
    description: 'Floating overlay assistant head over all Android apps (SYSTEM_ALERT_WINDOW)',
    content: `package com.dostai.assistant.services

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import com.dostai.assistant.MainActivity

class DostFloatingWidgetService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }
        val bubble = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setBackgroundColor(0xFF06B6D4.toInt())
            setPadding(24, 24, 24, 24)
        }
        floatingView = bubble
        windowManager?.addView(floatingView, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (floatingView != null) windowManager?.removeView(floatingView)
    }
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/data/UserMemoryRepository.kt',
    name: 'UserMemoryRepository.kt',
    language: 'kotlin',
    description: 'DOST Mind: Long term memory storage for user daily routines and preferences',
    content: `package com.dostai.assistant.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class AndroidUserMemory(
    val id: String = System.currentTimeMillis().toString(),
    val category: String,
    val fact: String,
    val learnedAt: Long = System.currentTimeMillis()
)

class UserMemoryRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("dost_user_mind_prefs", Context.MODE_PRIVATE)

    fun getAllMemories(): List<AndroidUserMemory> {
        val raw = prefs.getString("memories_json", "[]") ?: "[]"
        val list = mutableListOf<AndroidUserMemory>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(AndroidUserMemory(obj.getString("id"), obj.getString("category"), obj.getString("fact"), obj.getLong("learnedAt")))
            }
        } catch (e: Exception) {}
        return list
    }

    fun saveMemory(category: String, fact: String) {
        val current = getAllMemories().toMutableList()
        current.add(0, AndroidUserMemory(category = category, fact = fact))
        persist(current)
    }

    private fun persist(list: List<AndroidUserMemory>) {
        val arr = JSONArray()
        list.forEach { mem ->
            arr.put(JSONObject().apply { put("id", mem.id); put("category", mem.category); put("fact", mem.fact); put("learnedAt", mem.learnedAt) })
        }
        prefs.edit().putString("memories_json", arr.toString()).apply()
    }
}`
  },
  {
    path: 'app/src/main/java/com/dostai/assistant/crypto/DailySignalsEngine.kt',
    name: 'DailySignalsEngine.kt',
    language: 'kotlin',
    description: 'Algorithmic Daily Crypto Signals engine (BTC, SOL, ETH, SUI, DOGE, XRP)',
    content: `package com.dostai.assistant.crypto

data class AndroidDailySignal(
    val id: String,
    val symbol: String,
    val coinName: String,
    val type: String,
    val timeframe: String,
    val entryZone: String,
    val stopLoss: Double,
    val takeProfit1: Double,
    val takeProfit2: Double,
    val takeProfit3: Double,
    val riskReward: String,
    val confidence: Int,
    val reasoning: String
)

class DailySignalsEngine {
    // Computes daily institutional signals using EMA 9/20 retest and liquidity sweeps
}`
  },
  {
    path: 'README.md',
    name: 'README.md',
    language: 'markdown',
    description: 'Complete Android Studio setup instructions, test cases, and OS limitations',
    content: `# DOST AI — NATIVE ANDROID ASSISTANT
Kotlin & Jetpack Compose project. Open with Android Studio Hedgehog or newer.
Configure GEMINI_API_KEY in local.properties.
Includes DOST Mind Long-Term Memory, Daily Crypto Signals, and Floating Overlay Widget.`
  }
];
