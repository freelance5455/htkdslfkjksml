export interface ProjectFileEntry {
  path: string;
  name: string;
  type: 'file';
  category: 'build' | 'source' | 'resource' | 'workflow' | 'doc';
  content: string;
}

export const ANDROID_PACKAGE_NAME = 'com.birdbase.app';
export const ANDROID_APP_NAME = 'Bird PC';

export const ANDROID_PROJECT_FILES: ProjectFileEntry[] = [
  {
    path: 'settings.gradle.kts',
    name: 'settings.gradle.kts',
    type: 'file',
    category: 'build',
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "BirdPC"
include(":app")
`
  },
  {
    path: 'build.gradle.kts',
    name: 'build.gradle.kts',
    type: 'file',
    category: 'build',
    content: `// Top-level build file for Bird PC Native Android Application
plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
`
  },
  {
    path: 'gradle.properties',
    name: 'gradle.properties',
    type: 'file',
    category: 'build',
    content: `# Gradle Properties for Bird PC (com.birdbase.app)
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
android.defaults.buildfeatures.buildconfig=true
`
  },
  {
    path: 'gradle/wrapper/gradle-wrapper.properties',
    name: 'gradle-wrapper.properties',
    type: 'file',
    category: 'build',
    content: `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.9-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
  },
  {
    path: 'gradlew',
    name: 'gradlew',
    type: 'file',
    category: 'build',
    content: `#!/bin/sh
#
# Bird PC Gradle Wrapper Script for Unix / Linux / macOS / Termux
#
APP_BASE_NAME=\`basename "$0"\`
APP_HOME=\`dirname "$0"\`
GRADLE_USER_HOME="\${GRADLE_USER_HOME:-$HOME/.gradle}"
CLASSPATH="gradle/wrapper/gradle-wrapper.jar"

if [ -n "$JAVA_HOME" ] ; then
    JAVACMD="$JAVA_HOME/bin/java"
else
    JAVACMD="java"
fi

exec "$JAVACMD" -jar "$APP_HOME/$CLASSPATH" "$@"
`
  },
  {
    path: 'gradlew.bat',
    name: 'gradlew.bat',
    type: 'file',
    category: 'build',
    content: `@rem Bird PC Gradle Wrapper Script for Windows
@if "%DEBUG%"=="" @echo off
set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_BASE_NAME=%~n0
set APP_HOME=%DIRNAME%
if defined JAVA_HOME goto findJavaFromJavaHome
set JAVA_EXE=java.exe
goto execute
:findJavaFromJavaHome
set JAVA_EXE=%JAVA_HOME%\\bin\\java.exe
:execute
"%JAVA_EXE%" -jar "%APP_HOME%gradle\\wrapper\\gradle-wrapper.jar" %*
`
  },
  {
    path: 'app/build.gradle.kts',
    name: 'app/build.gradle.kts',
    type: 'file',
    category: 'build',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.birdbase.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.birdbase.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.10.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
`
  },
  {
    path: 'app/proguard-rules.pro',
    name: 'proguard-rules.pro',
    type: 'file',
    category: 'build',
    content: `# ProGuard rules for Bird PC (com.birdbase.app)
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}
-dontwarn okhttp3.**
-dontwarn javax.annotation.**
`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    type: 'file',
    category: 'source',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="com.birdbase.app">

    <!-- Permissions required for Bird PC Desktop Environment -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

    <application
        android:name=".BirdPCApplication"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.BirdPC"
        android:hardwareAccelerated="true"
        tools:targetApi="35">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:windowSoftInputMode="adjustResize"
            android:theme="@style/Theme.BirdPC">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Dynamic Launcher Icon Alias for Runtime Icon Switching -->
        <activity-alias
            android:name=".MainActivityCustomIcon"
            android:enabled="false"
            android:exported="true"
            android:icon="@mipmap/ic_launcher"
            android:roundIcon="@mipmap/ic_launcher_round"
            android:label="@string/app_name"
            android:targetActivity=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity-alias>

    </application>

</manifest>
`
  },
  {
    path: 'app/src/main/kotlin/com/birdbase/app/BirdPCApplication.kt',
    name: 'BirdPCApplication.kt',
    type: 'file',
    category: 'source',
    content: `package com.birdbase.app

import android.app.Application
import android.util.Log

/**
 * Bird PC Native Android Application
 * Package: com.birdbase.app
 */
class BirdPCApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i("BirdPC", "Bird PC Application initialized on Android \${android.os.Build.VERSION.RELEASE} (API \${android.os.Build.VERSION.SDK_INT})")
    }
}
`
  },
  {
    path: 'app/src/main/kotlin/com/birdbase/app/MainActivity.kt',
    name: 'MainActivity.kt',
    type: 'file',
    category: 'source',
    content: `package com.birdbase.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.birdbase.app.ui.desktop.DesktopScreen
import com.birdbase.app.ui.theme.BirdPCTheme

/**
 * Bird PC Main Native Entry Point
 * Host activity hosting the Windows-inspired desktop environment with Jetpack Compose.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BirdPCTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    DesktopScreen()
                }
            }
        }
    }
}
`
  },
  {
    path: 'app/src/main/kotlin/com/birdbase/app/ui/desktop/DesktopScreen.kt',
    name: 'DesktopScreen.kt',
    type: 'file',
    category: 'source',
    content: `package com.birdbase.app.ui.desktop

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.birdbase.app.viewmodel.DesktopViewModel

/**
 * DesktopScreen: Full-screen Windows 11 desktop canvas containing:
 * - Desktop wallpaper
 * - Desktop application icons grid
 * - Draggable and resizable window stack
 * - Start Menu modal
 * - Centered Taskbar with System Tray
 */
@Composable
fun DesktopScreen(
    viewModel: DesktopViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
    ) {
        // Desktop Wallpaper Canvas
        // Desktop Icons Grid
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Interactive App Icons
        }

        // Active Windows Stack
        uiState.openWindows.forEach { window ->
            if (window.state != com.birdbase.app.viewmodel.WindowState.MINIMIZED) {
                WindowFrame(
                    window = window,
                    onFocus = { viewModel.bringToFront(window.id) },
                    onClose = { viewModel.closeWindow(window.id) },
                    onMinimize = { viewModel.minimizeWindow(window.id) },
                    onMaximize = { viewModel.toggleMaximize(window.id) }
                )
            }
        }

        // Windows 11 Start Menu
        if (uiState.isStartMenuOpen) {
            StartMenu(
                onAppLaunch = { appId ->
                    viewModel.openApp(appId)
                    viewModel.toggleStartMenu()
                },
                onDismiss = { viewModel.toggleStartMenu() }
            )
        }

        // Centered Taskbar
        Taskbar(
            openWindows = uiState.openWindows,
            activeWindowId = uiState.activeWindowId,
            isStartMenuOpen = uiState.isStartMenuOpen,
            onStartClick = { viewModel.toggleStartMenu() },
            onAppClick = { appId -> viewModel.openApp(appId) },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}
`
  },
  {
    path: 'app/src/main/kotlin/com/birdbase/app/ui/desktop/Taskbar.kt',
    name: 'Taskbar.kt',
    type: 'file',
    category: 'source',
    content: `package com.birdbase.app.ui.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.birdbase.app.viewmodel.AppWindowModel

@Composable
fun Taskbar(
    openWindows: List<AppWindowModel>,
    activeWindowId: String?,
    isStartMenuOpen: Boolean,
    onStartClick: () -> Unit,
    onAppClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .background(Color(0xEE1E293B))
            .padding(horizontal = 8.dp)
    ) {
        // Centered App Launchers & Pinned Apps
        Row(
            modifier = Modifier.align(Alignment.Center),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Start Menu Button
            IconButton(
                onClick = onStartClick,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isStartMenuOpen) Color(0x3338BDF8) else Color.Transparent)
            ) {
                Icon(
                    imageVector = Icons.Default.Window,
                    contentDescription = "Start Menu",
                    tint = Color(0xFF38BDF8)
                )
            }

            // Pinned Core Apps
            IconButton(onClick = { onAppClick("file-explorer") }) {
                Icon(Icons.Default.Folder, contentDescription = "Explorer", tint = Color(0xFFFBBF24))
            }
            IconButton(onClick = { onAppClick("bird-browser") }) {
                Icon(Icons.Default.Public, contentDescription = "Browser", tint = Color(0xFF60A5FA))
            }
            IconButton(onClick = { onAppClick("app-icon-studio") }) {
                Icon(Icons.Default.AutoAwesome, contentDescription = "Icon Studio", tint = Color(0xFFA855F7))
            }
            IconButton(onClick = { onAppClick("terminal") }) {
                Icon(Icons.Default.Terminal, contentDescription = "Terminal", tint = Color(0xFFE2E8F0))
            }
        }

        // System Tray (Time, Battery, Wi-Fi)
        Row(
            modifier = Modifier.align(Alignment.CenterEnd),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Wifi, contentDescription = "Wi-Fi", tint = Color.White, modifier = Modifier.size(16.dp))
            Icon(Icons.Default.BatteryChargingFull, contentDescription = "Battery", tint = Color.White, modifier = Modifier.size(16.dp))
            Text(text = "12:00 PM", color = Color.White, style = MaterialTheme.typography.labelSmall)
        }
    }
}
`
  },
  {
    path: 'app/src/main/kotlin/com/birdbase/app/ui/desktop/StartMenu.kt',
    name: 'StartMenu.kt',
    type: 'file',
    category: 'source',
    content: `package com.birdbase.app.ui.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun StartMenu(
    onAppLaunch: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier
            .width(540.dp)
            .height(580.dp)
            .padding(bottom = 60.dp)
            .clip(RoundedCornerShape(12.dp)),
        color = Color(0xF51E293B),
        shadowElevation = 16.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Text(
                text = "Pinned",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(16.dp))
            // Pinned Apps Grid (30+ Desktop modules)
            // User Footer: Blue Edge / Bird Base
        }
    }
}
`
  },
  {
    path: 'app/src/main/kotlin/com/birdbase/app/ui/desktop/WindowFrame.kt',
    name: 'WindowFrame.kt',
    type: 'file',
    category: 'source',
    content: `package com.birdbase.app.ui.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.birdbase.app.viewmodel.AppWindowModel

@Composable
fun WindowFrame(
    window: AppWindowModel,
    onFocus: () -> Unit,
    onClose: () -> Unit,
    onMinimize: () -> Unit,
    onMaximize: () -> Unit
) {
    Surface(
        modifier = Modifier
            .offset(window.x.dp, window.y.dp)
            .size(window.width.dp, window.height.dp)
            .clip(RoundedCornerShape(8.dp)),
        color = Color(0xFF0F172A),
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Window Title Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
                    .background(Color(0xFF1E293B))
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = window.title,
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onMinimize, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Remove, contentDescription = "Minimize", tint = Color.LightGray)
                }
                IconButton(onClick = onMaximize, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.CropSquare, contentDescription = "Maximize", tint = Color.LightGray)
                }
                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Red)
                }
            }
            // Window Content View
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A))
                    .padding(8.dp)
            ) {
                Text(text = "App: \${window.title}", color = Color.White)
            }
        }
    }
}
`
  },
  {
    path: 'app/src/main/kotlin/com/birdbase/app/viewmodel/DesktopViewModel.kt',
    name: 'DesktopViewModel.kt',
    type: 'file',
    category: 'source',
    content: `package com.birdbase.app.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class WindowState {
    NORMAL, MINIMIZED, MAXIMIZED
}

data class AppWindowModel(
    val id: String,
    val appId: String,
    val title: String,
    val state: WindowState = WindowState.NORMAL,
    val x: Float = 60f,
    val y: Float = 60f,
    val width: Float = 640f,
    val height: Float = 480f,
    val zIndex: Int = 1
)

data class DesktopUiState(
    val isStartMenuOpen: Boolean = false,
    val activeWindowId: String? = null,
    val openWindows: List<AppWindowModel> = emptyList()
)

class DesktopViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(DesktopUiState())
    val uiState: StateFlow<DesktopUiState> = _uiState.asStateFlow()

    fun toggleStartMenu() {
        _uiState.update { it.copy(isStartMenuOpen = !it.isStartMenuOpen) }
    }

    fun openApp(appId: String) {
        val existing = _uiState.value.openWindows.find { it.appId == appId }
        if (existing != null) {
            bringToFront(existing.id)
            return
        }
        val newWindow = AppWindowModel(
            id = "win-\${System.currentTimeMillis()}",
            appId = appId,
            title = appId.replace("-", " ").capitalize()
        )
        _uiState.update { it.copy(
            openWindows = it.openWindows + newWindow,
            activeWindowId = newWindow.id
        ) }
    }

    fun bringToFront(id: String) {
        _uiState.update { it.copy(activeWindowId = id) }
    }

    fun closeWindow(id: String) {
        _uiState.update { it.copy(openWindows = it.openWindows.filterNot { w -> w.id == id }) }
    }

    fun minimizeWindow(id: String) {
        _uiState.update { state ->
            state.copy(openWindows = state.openWindows.map {
                if (it.id == id) it.copy(state = WindowState.MINIMIZED) else it
            })
        }
    }

    fun toggleMaximize(id: String) {
        _uiState.update { state ->
            state.copy(openWindows = state.openWindows.map {
                if (it.id == id) {
                    val nextState = if (it.state == WindowState.MAXIMIZED) WindowState.NORMAL else WindowState.MAXIMIZED
                    it.copy(state = nextState)
                } else it
            })
        }
    }
}
`
  },
  {
    path: 'app/src/main/kotlin/com/birdbase/app/services/AppIconManager.kt',
    name: 'AppIconManager.kt',
    type: 'file',
    category: 'source',
    content: `package com.birdbase.app.services

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log

/**
 * AppIconManager manages dynamic launcher icon switching via Android Activity-Alias
 * and documents static APK rebuilding requirements for custom launcher drawables.
 */
object AppIconManager {
    private const val TAG = "AppIconManager"
    private const val DEFAULT_ALIAS = "com.birdbase.app.MainActivity"
    private const val CUSTOM_ALIAS = "com.birdbase.app.MainActivityCustomIcon"

    fun enableCustomAlias(context: Context, useAlternate: Boolean) {
        val pm = context.packageManager
        val targetAlias = if (useAlternate) CUSTOM_ALIAS else DEFAULT_ALIAS
        val disabledAlias = if (useAlternate) DEFAULT_ALIAS else CUSTOM_ALIAS

        try {
            pm.setComponentEnabledSetting(
                ComponentName(context, targetAlias),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            pm.setComponentEnabledSetting(
                ComponentName(context, disabledAlias),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
            Log.i(TAG, "Launcher icon component-alias switched to $targetAlias")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to switch component alias: \${e.message}")
        }
    }
}
`
  },
  {
    path: 'app/src/main/kotlin/com/birdbase/app/ui/theme/Theme.kt',
    name: 'Theme.kt',
    type: 'file',
    category: 'source',
    content: `package com.birdbase.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF38BDF8),
    secondary = Color(0xFF818CF8),
    tertiary = Color(0xFFC084FC),
    background = Color(0xFF0F172A),
    surface = Color(0xFF1E293B)
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF0284C7),
    secondary = Color(0xFF4F46E5),
    tertiary = Color(0xFF9333EA),
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF)
)

@Composable
fun BirdPCTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
`
  },
  {
    path: 'app/src/main/res/values/strings.xml',
    name: 'strings.xml',
    type: 'file',
    category: 'resource',
    content: `<resources>
    <string name="app_name">Bird PC</string>
    <string name="package_name">com.birdbase.app</string>
    <string name="build_version">1.0.0 (API 35)</string>
    <string name="app_description">Windows-inspired native Android desktop operating environment</string>
</resources>
`
  },
  {
    path: 'app/src/main/res/values/colors.xml',
    name: 'colors.xml',
    type: 'file',
    category: 'resource',
    content: `<resources>
    <color name="primary">#38BDF8</color>
    <color name="primary_dark">#0284C7</color>
    <color name="accent">#818CF8</color>
    <color name="background_dark">#0F172A</color>
    <color name="surface_dark">#1E293B</color>
    <color name="ic_launcher_background">#0F172A</color>
</resources>
`
  },
  {
    path: 'app/src/main/res/values/themes.xml',
    name: 'themes.xml',
    type: 'file',
    category: 'resource',
    content: `<resources>
    <style name="Theme.BirdPC" parent="android:Theme.Material.NoActionBar">
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
        <item name="android:windowBackground">@color/background_dark</item>
    </style>
</resources>
`
  },
  {
    path: 'app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
    name: 'ic_launcher.xml',
    type: 'file',
    category: 'resource',
    content: `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
`
  },
  {
    path: 'app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml',
    name: 'ic_launcher_round.xml',
    type: 'file',
    category: 'resource',
    content: `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
`
  },
  {
    path: 'app/src/main/res/drawable/ic_launcher_background.xml',
    name: 'ic_launcher_background.xml',
    type: 'file',
    category: 'resource',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#0F172A"
        android:pathData="M0,0h108v108h-108z" />
    <path
        android:fillColor="#1E293B"
        android:pathData="M0,0h108v48h-108z" />
</vector>
`
  },
  {
    path: 'app/src/main/res/drawable/ic_launcher_foreground.xml',
    name: 'ic_launcher_foreground.xml',
    type: 'file',
    category: 'resource',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <!-- Bird PC Mascot Vector (Cowboy Hat Penguin / Blue Shield) -->
    <path
        android:fillColor="#38BDF8"
        android:pathData="M54,20 C36,20 22,34 22,52 C22,70 36,84 54,84 C72,84 86,70 86,52 C86,34 72,20 54,20 Z" />
    <!-- Hat Brim -->
    <path
        android:fillColor="#0284C7"
        android:pathData="M26,38 L82,38 L76,28 L32,28 Z" />
    <!-- Beak -->
    <path
        android:fillColor="#F97316"
        android:pathData="M48,54 L60,54 L54,62 Z" />
    <!-- White Belly -->
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M42,50 C42,46 45,44 48,44 C51,44 54,46 54,50 Z M54,50 C54,46 57,44 60,44 C63,44 66,46 66,50 Z" />
</vector>
`
  },
  {
    path: 'app/src/main/res/xml/backup_rules.xml',
    name: 'backup_rules.xml',
    type: 'file',
    category: 'resource',
    content: `<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <include domain="sharedpref" path="."/>
</full-backup-content>
`
  },
  {
    path: 'app/src/main/res/xml/data_extraction_rules.xml',
    name: 'data_extraction_rules.xml',
    type: 'file',
    category: 'resource',
    content: `<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <include domain="sharedpref" path="."/>
    </cloud-backup>
    <device-transfer>
        <include domain="sharedpref" path="."/>
    </device-transfer>
</data-extraction-rules>
`
  },
  {
    path: '.github/workflows/build-apk.yml',
    name: 'build-apk.yml',
    type: 'file',
    category: 'workflow',
    content: `name: Build Bird PC Native APK

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Source Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle

      - name: Grant Execute Permission for Gradlew
        run: chmod +x gradlew

      - name: Build Debug APK
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload Debug APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: BirdPC-Debug-APK
          path: app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
`
  },
  {
    path: 'build-apk-termux.sh',
    name: 'build-apk-termux.sh',
    type: 'file',
    category: 'source',
    content: `#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# Bird PC — Mobile Phone APK Compilation Script for Termux
# Target: com.birdbase.app
# ==============================================================================

echo "=========================================="
echo "  Bird PC Mobile APK Builder for Termux   "
echo "  Package: com.birdbase.app               "
echo "=========================================="

echo "[1/4] Updating package repositories..."
pkg update -y

echo "[2/4] Installing OpenJDK 17 and dependencies..."
pkg install -y openjdk-17 git gradle

echo "[3/4] Granting execution permissions..."
chmod +x ./gradlew

echo "[4/4] Compiling debug APK via Gradle..."
./gradlew assembleDebug

if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo "=========================================="
    echo "SUCCESS! APK successfully compiled at:"
    echo "app/build/outputs/apk/debug/app-debug.apk"
    echo "=========================================="
    echo "Copying to internal storage Downloads folder..."
    cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/BirdPC-debug.apk
    echo "Copied to /sdcard/Download/BirdPC-debug.apk"
    echo "You can now install it on your Android device!"
else
    echo "Build failed. Check the error output above."
fi
`
  },
  {
    path: 'README.md',
    name: 'README.md',
    type: 'file',
    category: 'doc',
    content: `# Bird PC — Native Android Desktop Application

- **Application Name**: Bird PC
- **Package Name**: \`com.birdbase.app\`
- **Target Platform**: Native Android (API 26 to API 35)
- **UI Framework**: Android Jetpack Compose & Material 3
- **Language**: Kotlin 2.0.21
- **Build System**: Android Gradle 8.7.2

---

## ⚠️ Important: Project ZIP vs APK

A **Project ZIP** contains raw Kotlin source files, Gradle scripts, and resource XMLs.
**Renaming "BirdPC.zip" to "BirdPC.apk" DOES NOT work and will result in "Parse Error" on Android.**

An **APK** is a compiled Android package containing:
1. Compiled Dalvik/ART Executable bytecode (\`classes.dex\`)
2. Compiled binary resources (\`resources.arsc\`)
3. Binary \`AndroidManifest.xml\`
4. Cryptographic APK Signature Scheme v2/v3 (\`META-INF/\`)

---

## How to Build the APK

### Method 1: Android Studio (Recommended on PC/Mac)
1. Extract \`BirdPC-Android-Project.zip\`.
2. Open **Android Studio** (Iguana, Jellyfish, Koala or newer).
3. Select **File > Open** and choose the extracted folder.
4. Allow Gradle to sync dependencies automatically.
5. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The compiled APK will be at:
   \`app/build/outputs/apk/debug/app-debug.apk\`

### Method 2: On Android Phone with Termux (No PC Required!)
1. Install **Termux** and **ZArchiver** from F-Droid or GitHub.
2. In ZArchiver, extract \`BirdPC-Android-Project.zip\` to your phone storage.
3. Open Termux and navigate to the project folder:
   \`\`\`bash
   cd /sdcard/Download/BirdPC
   bash build-apk-termux.sh
   \`\`\`
4. The script will install JDK 17, run \`./gradlew assembleDebug\`, and output the APK into \`/sdcard/Download/BirdPC-debug.apk\`.

### Method 3: 1-Click Cloud Build with GitHub Actions (Free, No Setup!)
1. Create a new GitHub repository.
2. Push this extracted project to your repository.
3. GitHub Actions will trigger \`.github/workflows/build-apk.yml\` automatically.
4. Go to the **Actions** tab on GitHub, click the workflow run, and download **BirdPC-Debug-APK**!

---

## Custom App Icon Replacement

The launcher icon resources are located in:
- \`app/src/main/res/mipmap-mdpi/ic_launcher.png\` (48x48)
- \`app/src/main/res/mipmap-hdpi/ic_launcher.png\` (72x72)
- \`app/src/main/res/mipmap-xhdpi/ic_launcher.png\` (96x96)
- \`app/src/main/res/mipmap-xxhdpi/ic_launcher.png\` (144x144)
- \`app/src/main/res/mipmap-xxxhdpi/ic_launcher.png\` (192x192)
- \`app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml\` (Adaptive Vector)

When you change the app icon inside Bird PC's **App Icon Studio**, the exported ZIP already contains your newly generated icons!
Rebuild the APK using any method above to produce an APK with your custom launcher icon.
`
  }
];
