import { Question } from '../types';

export const QUESTIONS_DATA: Question[] = [
  {
    id: 1,
    topic: "Introduction",
    q: "What is pharmaceutical analytical chemistry?",
    a: [
      "The study of drug marketing only",
      "The science of identifying and quantifying chemical substances",
      "The study of anatomy",
      "The preparation of dosage forms only"
    ],
    c: 1,
    e: "الكيمياء التحليلية الصيدلية بتدرس تحديد هوية المواد الكيميائية (Identification) وقياس كميتها (Quantification). وده بيساعد في تحليل الأدوية والتأكد من جودتها ومطابقتها للمواصفات."
  },
  {
    id: 2,
    topic: "Qualitative Analysis",
    q: "What does qualitative analysis establish?",
    a: [
      "The exact mass of a sample",
      "The concentration only",
      "The identity of chemical species present",
      "The temperature of a sample"
    ],
    c: 2,
    e: "التحليل النوعي (Qualitative analysis) بيحدد هوية أو نوع المواد والعناصر الموجودة في العينة، مش كميتها أو تركيزها."
  },
  {
    id: 3,
    topic: "Qualitative Analysis",
    q: "Which question does qualitative analysis answer?",
    a: [
      "How much is present?",
      "What is present?",
      "How heavy is the container?",
      "How long does it take?"
    ],
    c: 1,
    e: "التحليل النوعي بيجاوب دايماً على سؤال: ?What is present (إيه المادة الموجودة؟)."
  },
  {
    id: 4,
    topic: "Qualitative Analysis",
    q: "Analysis of anions and cations is an example of:",
    a: [
      "Qualitative analysis",
      "Quantitative analysis only",
      "Gravimetric analysis only",
      "Instrument calibration"
    ],
    c: 0,
    e: "التعرف على الأيونات السالبة والموجبة (Anions & Cations) في العينة مثال كلاسيكي ومهم جداً على التحليل النوعي."
  },
  {
    id: 5,
    topic: "Quantitative Analysis",
    q: "What does quantitative analysis establish?",
    a: [
      "The color of the laboratory",
      "The identity only",
      "The amount of a chemical species present",
      "The analyst's name"
    ],
    c: 2,
    e: "التحليل الكمي (Quantitative analysis) بيحدد كمية المادة الموجودة في العينة بالضبط، زي كتلتها أو تركيزها."
  },
  {
    id: 6,
    topic: "Quantitative Analysis",
    q: "Which question does quantitative analysis answer?",
    a: [
      "What is present?",
      "How much is present?",
      "Where is the laboratory?",
      "What color is the label?"
    ],
    c: 1,
    e: "التحليل الكمي بيجاوب على سؤال: ?How much is present (كمية المادة الموجودة قد إيه؟)."
  },
  {
    id: 7,
    topic: "Quantitative Terms",
    q: "Which terms are commonly associated with quantitative analysis?",
    a: [
      "Assay, determination, estimation",
      "Filtering and washing only",
      "Diagnosis and therapy",
      "Mixing and packaging"
    ],
    c: 0,
    e: "المصطلحات الثلاثة: Assay (المعايرة التعيينية) و Determination (التحديد الدقيق) و Estimation (التقدير التقريبي) كلها مصطلحات مرتبطة بالتحليل الكمي."
  },
  {
    id: 8,
    topic: "Volumetric Analysis",
    q: "Volumetric analysis depends on measuring:",
    a: [
      "Volume of a solution",
      "Bottle color",
      "Mass of the balance",
      "Length of the flask"
    ],
    c: 0,
    e: "التحليل الحجمي (Volumetric analysis) بيعتمد أساساً على قياس حجم المحلول، وغالباً بيستخدم في المعايرات (Titrations) بمحلول قياسي معلوم التركيز."
  },
  {
    id: 9,
    topic: "Gravimetric Analysis",
    q: "Gravimetric analysis depends on measuring:",
    a: [
      "Pressure",
      "Volume only",
      "Mass or weight",
      "Electrical current only"
    ],
    c: 2,
    e: "التحليل الوزني (Gravimetric analysis) بيعتمد على قياس الكتلة أو الوزن بدقة لتحديد كمية المادة بعد الترسيب أو التجفيف."
  },
  {
    id: 10,
    topic: "Instrumental Analysis",
    q: "Instrumental analysis mainly depends on:",
    a: [
      "Guessing the result",
      "Analytical instruments measuring a property",
      "Counting containers",
      "Room temperature only"
    ],
    c: 1,
    e: "التحليل الآلي (Instrumental analysis) بيستخدم أجهزة تحليلية متطورة (زي الـ Spectrophotometer أو HPLC) لقياس خاصية فيزيائية أو كيميائية مرتبطة بالمادة."
  },
  {
    id: 11,
    topic: "Titration Types",
    q: "Which group contains common types of titration?",
    a: [
      "Acid-base, redox, precipitation, complexometric",
      "Freezing and cooling",
      "Grinding and packaging",
      "Filtering and storing"
    ],
    c: 0,
    e: "الأنواع الأربعة الرئيسية للمعايرات هي: Acid-base (حمض وقاعدة)، Redox (أكسدة واختزال)، Precipitation (ترسيب)، و Complexometric (تكوين معقدات)."
  },
  {
    id: 12,
    topic: "Acid-Base Titration",
    q: "Acid-base titrations may include:",
    a: [
      "Acidimetry and alkalimetry",
      "Only gravimetry",
      "Only chromatography",
      "Only microscopy"
    ],
    c: 0,
    e: "معايرات الأحماض والقواعد بتشمل الـ Acidimetry (معايرة القلويات بمحلول حمضي قياسي) والـ Alkalimetry (معايرة الأحماض بمحلول قلوي قياسي)."
  },
  {
    id: 13,
    topic: "Analytical Terminology",
    q: "In quantitative analysis, an 'assay' generally refers to:",
    a: [
      "Measuring the amount or content of a substance",
      "Identifying a room",
      "Cleaning glassware",
      "Measuring a label"
    ],
    c: 0,
    e: "مصطلح Assay معناه إجراء اختبار تحليلي دقيق لتقدير المحتوى أو نسبة المادة الفعالة (Active Ingredient) في المستحضر الصيدلي."
  },
  {
    id: 14,
    topic: "Analytical Terminology",
    q: "In analytical chemistry, 'determination' refers to:",
    a: [
      "Decorating the laboratory",
      "Establishing an analyte's amount or value",
      "Choosing a brand",
      "Changing a sample's color"
    ],
    c: 1,
    e: "الـ Determination معناه تحديد قيمة أو كمية المادة المراد تحليلها (Analyte) بشكل دقيق ومحدد باستخدام طريقة تحليلية مناسبة."
  },
  {
    id: 15,
    topic: "Analytical Terminology",
    q: "In quantitative analysis, 'estimation' refers to:",
    a: [
      "Estimating or assessing the amount of a substance",
      "Identifying a worker",
      "Measuring flask height",
      "Naming a chemical only"
    ],
    c: 0,
    e: "الـ Estimation بيشير لتقييم أو تقدير تقريبي محسوب لكمية المادة قبل أو أثناء التحليل المفصل."
  },
  {
    id: 16,
    topic: "Core Principles",
    q: "The process that establishes chemical identity is called:",
    a: [
      "Quantitative analysis",
      "Qualitative analysis",
      "Gravimetry",
      "Titration only"
    ],
    c: 1,
    e: "قاعدة ذهبية: تحديد الهوية (Identity) = Qualitative Analysis، وتحديد الكمية (Amount) = Quantitative Analysis."
  },
  {
    id: 17,
    topic: "Core Principles",
    q: "The process that establishes the amount of a species is called:",
    a: [
      "Qualitative analysis",
      "Visual inspection only",
      "Quantitative analysis",
      "Identification only"
    ],
    c: 2,
    e: "التحليل المسؤول عن قياس كمية المادة هو Quantitative analysis."
  },
  {
    id: 18,
    topic: "Methodologies",
    q: "Which method relies on measuring volume?",
    a: [
      "Volumetric analysis",
      "Gravimetric analysis",
      "Identification only",
      "Microscopy only"
    ],
    c: 0,
    e: "التحليل الحجمي (Volumetric analysis) يعتمد على قياس الحجوم السائلة بدقة بالماصات والسحاحات."
  },
  {
    id: 19,
    topic: "Methodologies",
    q: "Which method relies on measuring mass?",
    a: [
      "Volumetric analysis",
      "Gravimetric analysis",
      "Acidimetry only",
      "Color identification only"
    ],
    c: 1,
    e: "التحليل الوزني (Gravimetric analysis) يعتمد على قياس الكتلة بدقة بواسطة الميزان التحليلي الحساس (Analytical Balance)."
  },
  {
    id: 20,
    topic: "Methodologies",
    q: "Which method uses analytical instruments to measure properties?",
    a: [
      "Instrumental analysis",
      "Gravimetric analysis only",
      "Manual counting",
      "Visual labeling"
    ],
    c: 0,
    e: "التحليل الآلي (Instrumental analysis) بيقيس خواص زي امتصاص الضوء، أو التوصيل الكهربائي، أو الانبعاث الطيفي باستخدام أجهزة حديثة."
  }
];
