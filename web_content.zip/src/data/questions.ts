import { CATS, COUNTS, PREFIX, CORE, SUFFIX, FACTS, WRONGS } from "./q.ar";

export interface Question {
  id: number;
  cat: string;
  text: string;
  options: string[];
  correct: number;
}

// deterministic PRNG so the 10,000 questions are identical on every load (offline)
function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const TOTAL = 10000;

let cache: Question[] | null = null;

export function getQuestions(): Question[] {
  if (cache) return cache;
  const rng = mulberry32(20240613);
  const all: Question[] = [];
  const used = new Set<string>();

  for (const cat of CATS) {
    const cid = cat.id;
    const stems: string[] = [];
    for (const p of PREFIX[cid])
      for (const c of CORE[cid]) for (const s of SUFFIX[cid]) stems.push(p + c + s);
    const facts = FACTS[cid];
    const wrongs = WRONGS[cid];
    const need = COUNTS[cid] || 0;
    let made = 0;
    let guard = 0;
    while (made < need && guard++ < need * 80) {
      const stem = stems[Math.floor(rng() * stems.length)];
      const f = facts[Math.floor(rng() * facts.length)];
      const text = stem.split("{X}").join(f.s);
      if (used.has(text)) continue;
      used.add(text);
      const wpool = wrongs.filter((w) => w !== f.a);
      const w1 = wpool[Math.floor(rng() * wpool.length)];
      let w2 = wpool[Math.floor(rng() * wpool.length)];
      let g = 0;
      while (w2 === w1 && g++ < 25) w2 = wpool[Math.floor(rng() * wpool.length)];
      const options = [f.a, w1, w2];
      for (let i = options.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [options[i], options[j]] = [options[j], options[i]];
      }
      all.push({ id: 0, cat: cid, text, options, correct: options.indexOf(f.a) });
      made++;
    }
  }

  for (let i = all.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [all[i], all[j]] = [all[j], all[i]];
  }
  all.forEach((q, i) => (q.id = i + 1));
  cache = all;
  return all;
}

export function getQuestionById(id: number): Question | undefined {
  const list = getQuestions();
  return list[id - 1];
}
