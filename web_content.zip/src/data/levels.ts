import { LevelConfig } from '../types/game';
import { generateSolvableLevel } from '../utils/levelGenerator';

/**
 * Hand-tailored first 5 onboarding levels for intuitive learning
 */
const HANDCRAFTED_INTRO_LEVELS: LevelConfig[] = [
  {
    id: 1,
    worldIndex: 1,
    name: 'Level 1: Dual Pulse',
    rows: 5,
    cols: 5,
    pairs: [
      { color: 'red', start: { r: 1, c: 1 }, end: { r: 1, c: 3 } },
      { color: 'blue', start: { r: 3, c: 1 }, end: { r: 3, c: 3 } }
    ],
    maxMoves: 6,
    parMoves: 2
  },
  {
    id: 2,
    worldIndex: 1,
    name: 'Level 2: The Crossway',
    rows: 5,
    cols: 5,
    pairs: [
      { color: 'red', start: { r: 0, c: 2 }, end: { r: 4, c: 0 } },
      { color: 'blue', start: { r: 0, c: 4 }, end: { r: 4, c: 2 } },
      { color: 'green', start: { r: 2, c: 1 }, end: { r: 2, c: 4 } }
    ],
    maxMoves: 8,
    parMoves: 3
  },
  {
    id: 3,
    worldIndex: 1,
    name: 'Level 3: Tri-Spectrum',
    rows: 5,
    cols: 5,
    pairs: [
      { color: 'red', start: { r: 0, c: 0 }, end: { r: 4, c: 4 } },
      { color: 'yellow', start: { r: 0, c: 4 }, end: { r: 4, c: 0 } },
      { color: 'cyan', start: { r: 2, c: 0 }, end: { r: 2, c: 4 } }
    ],
    maxMoves: 8,
    parMoves: 3
  },
  {
    id: 4,
    worldIndex: 1,
    name: 'Level 4: Corner Circuit',
    rows: 5,
    cols: 5,
    pairs: [
      { color: 'red', start: { r: 0, c: 1 }, end: { r: 4, c: 1 } },
      { color: 'blue', start: { r: 0, c: 3 }, end: { r: 4, c: 3 } },
      { color: 'green', start: { r: 1, c: 0 }, end: { r: 3, c: 0 } },
      { color: 'purple', start: { r: 1, c: 4 }, end: { r: 3, c: 4 } }
    ],
    maxMoves: 9,
    parMoves: 4
  },
  {
    id: 5,
    worldIndex: 1,
    name: 'Level 5: Neon Weave',
    rows: 5,
    cols: 5,
    pairs: [
      { color: 'red', start: { r: 0, c: 0 }, end: { r: 2, c: 2 } },
      { color: 'blue', start: { r: 0, c: 4 }, end: { r: 4, c: 2 } },
      { color: 'yellow', start: { r: 4, c: 0 }, end: { r: 4, c: 4 } },
      { color: 'cyan', start: { r: 1, c: 1 }, end: { r: 3, c: 3 } }
    ],
    maxMoves: 9,
    parMoves: 4
  }
];

export const WORLDS = [
  { index: 1, title: 'Neon Dawn', range: '1–10', gridSize: '5 × 5', colorCount: '3–4 Colors' },
  { index: 2, title: 'Grid Horizon', range: '11–25', gridSize: '6 × 6', colorCount: '4–5 Colors' },
  { index: 3, title: 'Quantum Pulse', range: '26–50', gridSize: '7 × 7', colorCount: '5–6 Colors' },
  { index: 4, title: 'Cyber Nexus', range: '51–75', gridSize: '8 × 8', colorCount: 'Special Tiles' },
  { index: 5, title: 'Master Core', range: '76–100', gridSize: '9 × 9', colorCount: 'Full Matrix' }
];

export function getClassicLevel(levelNum: number): LevelConfig {
  if (levelNum >= 1 && levelNum <= 5) {
    return HANDCRAFTED_INTRO_LEVELS[levelNum - 1];
  }

  // Calculate parameters for levels 6 to 100
  let worldIndex = 1;
  let rows = 5;
  let cols = 5;
  let pairs = 4;
  let hasSpecial = false;

  if (levelNum <= 10) {
    worldIndex = 1;
    rows = 5;
    cols = 5;
    pairs = 4;
  } else if (levelNum <= 25) {
    worldIndex = 2;
    rows = 6;
    cols = 6;
    pairs = 4 + (levelNum % 2);
  } else if (levelNum <= 50) {
    worldIndex = 3;
    rows = 7;
    cols = 7;
    pairs = 5 + (levelNum % 2);
    hasSpecial = levelNum >= 40;
  } else if (levelNum <= 75) {
    worldIndex = 4;
    rows = 8;
    cols = 8;
    pairs = 6 + (levelNum % 2);
    hasSpecial = true;
  } else {
    worldIndex = 5;
    rows = 9;
    cols = 9;
    pairs = 7 + (levelNum % 2);
    hasSpecial = true;
  }

  return generateSolvableLevel({
    id: levelNum,
    worldIndex,
    name: `Level ${levelNum}: Stage ${worldIndex}.${levelNum % 10 || 10}`,
    rows,
    cols,
    pairCount: pairs,
    seed: levelNum * 31415 + 9265,
    hasSpecialTiles: hasSpecial
  });
}
