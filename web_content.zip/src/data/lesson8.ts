export type Word = {
  id: number;
  en: string;
  fa: string;
  pronunciation: string;
  image: string;
  category: string;
};

export type QuizQuestion = {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
  faQuestion: string;
};

export type GrammarItem = {
  id: number;
  title: string;
  faTitle: string;
  rule: string;
  faRule: string;
  example: string;
  faExample: string;
};

// Lesson 8 Vocabulary - 7th Grade English (Iran)
export const VOCABULARY: Word[] = [
  {
    id: 1,
    en: "Morning",
    fa: "صبح",
    pronunciation: "مورننگ",
    image: "☀️",
    category: "time",
  },
  {
    id: 2,
    en: "Afternoon",
    fa: "بعدازظهر",
    pronunciation: "آفترنون",
    image: "🌤️",
    category: "time",
  },
  {
    id: 3,
    en: "Evening",
    fa: "شب",
    pronunciation: "ایونننگ",
    image: "🌙",
    category: "time",
  },
  {
    id: 4,
    en: "Night",
    fa: "شب",
    pronunciation: "نایت",
    image: "🌃",
    category: "time",
  },
  {
    id: 5,
    en: "Breakfast",
    fa: "ناشتا",
    pronunciation: "برکفست",
    image: "🍳",
    category: "food",
  },
  {
    id: 6,
    en: "Lunch",
    fa: "نهار",
    pronunciation: "LANCH",
    image: "🍱",
    category: "food",
  },
  {
    id: 7,
    en: "Dinner",
    fa: "شام",
    pronunciation: "دینر",
    image: "🍲",
    category: "food",
  },
  {
    id: 8,
    en: "School",
    fa: "مدرسه",
    pronunciation: "مدرس",
    image: "🏫",
    category: "place",
  },
  {
    id: 9,
    en: "Home",
    fa: "خانه",
    pronunciation: "هوم",
    image: "🏠",
    category: "place",
  },
  {
    id: 10,
    en: "Park",
    fa: "پارک",
    pronunciation: "پارک",
    image: "🌳",
    category: "place",
  },
  {
    id: 11,
    en: "Read",
    fa: "خواندن",
    pronunciation: "رید",
    image: "📖",
    category: "action",
  },
  {
    id: 12,
    en: "Write",
    fa: "نوشتن",
    pronunciation: "رایت",
    image: "✏️",
    category: "action",
  },
  {
    id: 13,
    en: "Play",
    fa: "بازی کردن",
    pronunciation: "پلی",
    image: "⚽",
    category: "action",
  },
  {
    id: 14,
    en: "Study",
    fa: "دربzess",
    pronunciation: "استادی",
    image: "📚",
    category: "action",
  },
  {
    id: 15,
    en: "Watch TV",
    fa: "تماشای تلویزیون",
    pronunciation: "واچ تی وی",
    image: "📺",
    category: "action",
  },
];

// Lesson 8 Quiz Questions
export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "What time do you usually have breakfast?",
    options: ["At 7:00", "At 7:00s", "In 7:00", "On 7:00"],
    correct: 0,
    explanation: "We use 'at' for specific times. Example: at 7:00.",
    faQuestion: "معمولاً ناشتاتان را چه زمانی می‌خورید؟",
  },
  {
    id: 2,
    question: "I go to school ___ the morning.",
    options: ["in", "at", "on", "by"],
    correct: 0,
    explanation: "We use 'in' with parts of the day: in the morning, in the afternoon, in the evening.",
    faQuestion: "من ___ صبح به مدرسه می‌روم.",
  },
  {
    id: 3,
    question: "She ___ her homework every day.",
    options: ["do", "does", "doing", "did"],
    correct: 1,
    explanation: "With 'she', we use 'does' in present simple tense.",
    faQuestion: "او هر روز ___ کارخانه‌اش را انجام می‌دهد.",
  },
  {
    id: 4,
    question: "What do you do ___ the afternoon?",
    options: ["in", "at", "on", "by"],
    correct: 0,
    explanation: "We use 'in' with parts of the day.",
    faQuestion: "شما عصرها چه می‌کنید؟",
  },
  {
    id: 5,
    question: "He ___ TV in the evening.",
    options: ["watch", "watches", "watching", "watchs"],
    correct: 1,
    explanation: "With 'he', we add -es to the verb: watch → watches.",
    faQuestion: "او شب‌ها تلویزیون تماشای می‌کند.",
  },
  {
    id: 6,
    question: "We ___ lunch at 12:00.",
    options: ["have", "has", "having", "haves"],
    correct: 0,
    explanation: "With 'we', we use the base form of the verb: have.",
    faQuestion: "ما در ساعت ۱۲ نهار می‌خوریم.",
  },
  {
    id: 7,
    question: "Which is correct?",
    options: ["I study in night", "I study at night", "I study on night", "I study in the night"],
    correct: 1,
    explanation: "We say 'at night' (without 'the').",
    faQuestion: "کدام جمله درست است؟",
  },
  {
    id: 8,
    question: "They ___ to the park on Fridays.",
    options: ["go", "goes", "going", "went"],
    correct: 0,
    explanation: "With 'they', we use the base form: go.",
    faQuestion: "آنها روزهای جمع به پارک می‌روند.",
  },
];

// Grammar Rules for Lesson 8
export const GRAMMAR_ITEMS = [
  {
    id: 1,
    title: "Present Simple Tense",
    faTitle: "زمانی حال سادہ",
    rule: "Use present simple for daily routines and habits.",
    faRule: "از زمان حال سادہ برای کارهای روزانہ و عادت‌ها استفاده شود.",
    example: "I wake up at 6:00 every day.",
    faExample: "من هر روز در ساعت ۶ بیدار می‌شوم.",
  },
  {
    id: 2,
    title: "Prepositions of Time",
    faTitle: "حروف اضافه زمان",
    rule: "at + specific time (at 7:00, at night) | in + parts of day (in the morning) | on + days (on Friday)",
    faRule: "at + زمان خاص | in + بخش‌های روز | on + روزهای هفته",
    example: "at 8:00 | in the morning | on Monday",
    faExample: "ساعت ۸ | صبح | دوشنبه",
  },
  {
    id: 3,
    title: "Third Person -s / -es",
    faTitle: "ضمیر говоЎ ش الواحدة",
    rule: "With he, she, it: add -s to most verbs, -es to verbs ending in -s, -sh, -ch, -x, -o.",
    faRule: "با هو، او، چی: به अधिकांש افعال -s اضافه شود، به افعالی که با s, sh, ch, x, o خاتم می‌شوند -es اضافه شود.",
    example: "He plays football. She watches TV.",
    faExample: "او فوتبال بازی می‌کند. او تلویزیون می‌بیند.",
  },
];