import { BiText } from './types';

export interface AtoZEntry {
  letter: string;
  term: string;
  hindiTerm: string;
  summary: BiText;
  fieldTip: BiText;
}

export interface PipeSizeSpec {
  mm: number;
  inch: string;
  dn: string;
  materials: string;
  pressureRating: string;
  usage: BiText;
  wallNote: BiText;
}

export interface PipeMaterialSpec {
  id: string;
  name: string;
  fullName: string;
  colorCode: string;
  tempMax: string;
  pressureMax: string;
  joining: BiText;
  bestFor: BiText;
  sectorUsage: BiText;
}

export interface FittingSpec {
  id: string;
  name: string;
  hindiName: string;
  category: 'Direction & Branch' | 'Connection & Size' | 'Valves' | 'Traps';
  svgType:
    | 'elbow90'
    | 'elbow45'
    | 'tee'
    | 'socket'
    | 'reducer'
    | 'union'
    | 'valve'
    | 'bend'
    | 'ptrap'
    | 'floortrap';
  purpose: BiText;
  installationTip: BiText;
}

export interface JointingMethod {
  id: string;
  title: BiText;
  pipeTypes: string;
  temperature: string;
  steps: BiText[];
  mistakeToAvoid: BiText;
}

export interface PprFusionRow {
  sizeMm: string;
  depthMm: string;
  heatingSec: string;
  joiningSec: string;
  coolingMin: string;
}

export interface SupplyDwvCard {
  id: string;
  system: 'supply' | 'dwv';
  title: BiText;
  pipeSizes: string;
  colorOrSlope: string;
  description: BiText;
  keyPoints: BiText[];
}

export const ATOZ_ENTRIES: AtoZEntry[] = [
  {
    letter: 'A',
    term: 'Angle Valve (Stop Cock)',
    hindiTerm: 'एंगल वॉल्व (Angle Valve)',
    summary: {
      en: 'A 90-degree shutoff valve mounted on the wall before a wash basin tap, flush tank, or geyser to stop water during maintenance.',
      hi: 'दीवार पर लगने वाला 90-डिग्री छोटा वॉल्व जो वॉश बेसिन, फ्लश टैंक या गीजर से पहले लगाया जाता है ताकि रिपेयर के समय पानी रोका जा सके।',
    },
    fieldTip: {
      en: 'Always wrap 10–12 turns of PTFE Teflon tape clockwise on the 1/2" male thread before tightening.',
      hi: '1/2" चूड़ी (थ्रेड) पर हमेशा घड़ी की दिशा (Clockwise) में 10–12 राउंड टेफ्लॉन टेप लपेटकर ही टाइट करें।',
    },
  },
  {
    letter: 'B',
    term: 'Bib Cock / Ball Valve',
    hindiTerm: 'बिब कॉक / बॉल वॉल्व',
    summary: {
      en: 'Bib cock is a wall-mounted water tap. Ball valve uses a rotating drilled ball for quick quarter-turn (90°) main line shutoff.',
      hi: 'बिब कॉक दीवार पर लगने वाला सामान्य नल है। बॉल वॉल्व में अंदर एक छेद वाली बॉल होती है जो हैंडल को 90° घुमाने पर तुरंत पानी बंद या चालू करती है।',
    },
    fieldTip: {
      en: 'Use full-bore brass ball valves on main risers and pump outlets so water flow does not drop.',
      hi: 'मेन राइजर और पंप आउटलेट पर हमेशा फुल-बोर ब्रास बॉल वॉल्व लगाएं ताकि प्रेशर कम न हो।',
    },
  },
  {
    letter: 'C',
    term: 'Cleanout & Check Valve (NRV)',
    hindiTerm: 'क्लीनआउट और एनआरवी वॉल्व',
    summary: {
      en: 'A Cleanout is a removable screw-cap access fitting in drainage pipes for rod cleaning. A Check Valve (NRV) lets water flow in only one direction.',
      hi: 'क्लीनआउट ड्रेनेज पाइप में खुलने वाला ढक्कन है जिससे जाम पाइप साफ किया जाता है। NRV (Non-Return Valve) पानी को केवल एक दिशा में जाने देता है, वापस नहीं आने देता।',
    },
    fieldTip: {
      en: 'Install NRV arrow pointing in the direction of flow—never upside down on vertical pump lines.',
      hi: 'NRV लगाते समय उस पर बना तीर (Arrow) पानी बहने की दिशा में रखें, उल्टा कभी न लगाएं।',
    },
  },
  {
    letter: 'D',
    term: 'DWV (Drainage, Waste & Vent)',
    hindiTerm: 'ड्रेनेज, वेस्ट और वेंट सिस्टम',
    summary: {
      en: 'The complete gravity drainage network: Soil pipe carries toilet waste, Waste pipe carries basin/shower water, and Vent pipe releases sewer gas.',
      hi: 'गंदा पानी निकालने का पूरा सिस्टम: Soil पाइप टॉयलेट का पानी, Waste पाइप सिंक/नहाने का पानी और Vent पाइप बदबू व गैस बाहर निकालता है।',
    },
    fieldTip: {
      en: 'Never connect a bathroom waste line without a water-seal trap, or foul smell will enter the room.',
      hi: 'बाथरूम के वेस्ट पाइप को बिना ट्रैप (Water Seal) के कभी सीधे मेन ड्रेन में न जोड़ें, वरना बदबू आएगी।',
    },
  },
  {
    letter: 'E',
    term: 'Elbow (90° & 45°)',
    hindiTerm: 'एल्बो (90° और 45° मोड़)',
    summary: {
      en: 'Fitting used to turn pipe direction. 90° elbows make sharp turns; two 45° elbows reduce friction and blockage in drainage lines.',
      hi: 'पाइप को मोड़ने की फिटिंग। 90° एल्बो सीधा मोड़ देती है, जबकि ड्रेनेज में जाम से बचने के लिए दो 45° एल्बो लगाना बेहतर होता है।',
    },
    fieldTip: {
      en: 'In Dubai municipality specs, use two 45° elbows instead of a sharp 90° elbow at the bottom of a vertical soil stack.',
      hi: 'दुबई और बड़े प्रोजेक्ट्स में खड़ी ड्रेनेज लाइन के नीचे तेज 90° की जगह दो 45° एल्बो लगाए जाते हैं।',
    },
  },
  {
    letter: 'F',
    term: 'Floor Trap (Nahni Trap / Gully)',
    hindiTerm: 'फ्लोर ट्रैप (नहनी ट्रैप)',
    summary: {
      en: 'A U-shaped water-seal trap installed in the bathroom floor to collect shower, basin, and AC drain water while blocking sewer odors.',
      hi: 'बाथरूम के फर्श में लगने वाला वाटर-सील ट्रैप जो नहाने व बेसिन का पानी लेता है और सीवर की बदबू व कीड़ों को ऊपर आने से रोकता है।',
    },
    fieldTip: {
      en: 'Minimum water seal depth must be 50mm (2 inches) so evaporation does not break the odor barrier.',
      hi: 'फ्लोर ट्रैप में कम से कम 50mm पानी की सील होनी चाहिए ताकि बदबू न आए।',
    },
  },
  {
    letter: 'G',
    term: 'Gate Valve & GI Pipe',
    hindiTerm: 'गेट वॉल्व और जीआई पाइप',
    summary: {
      en: 'Gate valve raises a metal wedge slowly to isolate main water lines. GI (Galvanized Iron) is zinc-coated threaded steel pipe.',
      hi: 'गेट वॉल्व में व्हील घुमाने पर अंदर का गेट ऊपर-नीचे होकर मेन लाइन बंद करता है। GI पाइप जिंक कोटेड लोहे का पाइप होता है जिसमें चूड़ी काटी जाती है।',
    },
    fieldTip: {
      en: 'Open and close gate valves fully—never leave them half-open to control flow, as vibration damages the gate.',
      hi: 'गेट वॉल्व को हमेशा पूरा खोलें या पूरा बंद करें, आधा खुला छोड़ने से सीट खराब हो जाती है।',
    },
  },
  {
    letter: 'H',
    term: 'Hydrostatic Pressure Test',
    hindiTerm: 'हाइड्रोस्टैटिक प्रेशर टेस्ट',
    summary: {
      en: 'Filling closed water supply pipes with water using a test pump up to 10 Bar (150 PSI) to verify zero leaks before tiling.',
      hi: 'टाइल्स लगने से पहले पानी की पाइप लाइन में पंप से 10 Bar (150 PSI) तक पानी का प्रेशर भरकर लीकेज चेक करना।',
    },
    fieldTip: {
      en: 'Bleed all trapped air from the highest outlet before pumping pressure, or gauge readings will fluctuate.',
      hi: 'प्रेशर पंप करने से पहले सबसे ऊंचे पॉइंट से सारी हवा बाहर निकाल दें, वरना गेज की रीडिंग गलत आएगी।',
    },
  },
  {
    letter: 'I',
    term: 'Inspection Chamber (Manhole)',
    hindiTerm: 'इंस्पेक्शन चैंबर (मैनहोल)',
    summary: {
      en: 'An underground masonry or uPVC chamber with a heavy cover where building sewer pipes meet for inspection and rodding.',
      hi: 'जमीन के अंदर बना चैंबर जहां बिल्डिंग के सभी गंदे पानी के पाइप मिलते हैं और जहां से सफाई व जांच की जाती है।',
    },
    fieldTip: {
      en: 'Keep benching inside the chamber sloped smoothly toward the main channel so solids never settle.',
      hi: 'चैंबर के अंदर का फर्श (Benching) मेन नाली की तरफ ढलान वाला बनाएं ताकि कचरा न रुके।',
    },
  },
  {
    letter: 'J',
    term: 'Jointing & Solvent Cement',
    hindiTerm: 'जॉइंटिंग और सॉल्वेंट सीमेंट',
    summary: {
      en: 'Chemical welding of uPVC/CPVC pipes using solvent cement that melts and fuses the pipe outer wall into the fitting socket.',
      hi: 'सॉल्वेंट ग्लू की मदद से PVC/CPVC पाइप और फिटिंग की सतह को रासायनिक रूप से पिघलाकर पक्का जोड़ बनाना।',
    },
    fieldTip: {
      en: 'Give a 1/4 turn (90° twist) when pushing the pipe in and hold firmly for 30 seconds so it does not push back out.',
      hi: 'पाइप को फिटिंग में डालते समय हल्का सा 1/4 घुमाएं और 30 सेकंड दबाकर पकड़ें ताकि पाइप बाहर न सरके।',
    },
  },
  {
    letter: 'K',
    term: 'Kitchen Grease Trap',
    hindiTerm: 'किचन ग्रीस ट्रैप',
    summary: {
      en: 'A separator tank installed under commercial or villa kitchen sinks to catch cooking oil, fat, and food grease before entering drains.',
      hi: 'किचन सिंक के नीचे लगने वाला चैंबर जो तेल, घी और चिकनाई को रोकता है ताकि मेन ड्रेनेज लाइन चोक न हो।',
    },
    fieldTip: {
      en: 'Mandatory in Dubai Municipality commercial kitchens; schedule weekly skimming of trapped fat.',
      hi: 'दुबई के कमर्शियल किचन में ग्रीस ट्रैप अनिवार्य है; इसे हर हफ्ते साफ करना जरूरी है।',
    },
  },
  {
    letter: 'L',
    term: 'Level & Laser Alignment',
    hindiTerm: 'स्पिरिट लेवल और लेजर अलाइनमेंट',
    summary: {
      en: 'Checking horizontal plumb and exact pipe gradient using a bubble spirit level or laser line during rough-in.',
      hi: 'पाइप को बिल्कुल सीधा (90°/180°) या सही ढलान पर रखने के लिए स्पिरिट लेवल और लेजर का इस्तेमाल करना।',
    },
    fieldTip: {
      en: 'Wall mixer hot and cold points must be dead level horizontally at 150mm center-to-center.',
      hi: 'वॉल मिक्सर के गर्म और ठंडे पॉइंट बिल्कुल एक सीध में और केंद्र से केंद्र 150mm दूरी पर होने चाहिए।',
    },
  },
  {
    letter: 'M',
    term: 'Manifold & Concealed Mixer',
    hindiTerm: 'मैनिफोल्ड और कंसील्ड मिक्सर',
    summary: {
      en: 'A distribution header that feeds individual pipes to each fixture with dedicated shutoff valves, reducing pressure drops.',
      hi: 'एक मुख्य हेडर पाइप जिससे हर नल या बाथरूम पॉइंट के लिए अलग-अलग कंट्रोल वॉल्व के साथ लाइन निकलती है।',
    },
    fieldTip: {
      en: 'Label every manifold branch clearly (Basin, WC, Shower, Kitchen) before closing the access box.',
      hi: 'एक्सेस बॉक्स बंद करने से पहले हर ब्रांच पर नाम (Basin, Shower, WC) का टैग जरूर लगाएं।',
    },
  },
  {
    letter: 'N',
    term: 'Nipple & Hex Bush',
    hindiTerm: 'निप्पल और हेक्स बुश',
    summary: {
      en: 'A short pipe piece with male threads on both ends (Barrel/Hex Nipple) used to join two female-threaded fittings closely.',
      hi: 'दोनों तरफ बाहर की चूड़ी (Male Thread) वाला छोटा पीस जो दो फीमेल फिटिंग या वॉल्व को आपस में जोड़ता है।',
    },
    fieldTip: {
      en: 'Use brass or stainless steel nipples inside tiled walls—never use black iron or cheap zinc nipples in concealed work.',
      hi: 'दीवार के अंदर हमेशा पीतल (Brass) या SS निप्पल ही लगाएं, सस्ता लोहा कभी नहीं।',
    },
  },
  {
    letter: 'O',
    term: 'Offset (45° Pipe Offset)',
    hindiTerm: 'ऑफसेट (45° पाइप मोड़)',
    summary: {
      en: 'Shifting a pipe centerline around a beam or column using two matching elbows. Travel = Offset × 1.414 for 45° bends.',
      hi: 'बीम या कॉलम से बचाकर पाइप लाइन को थोड़ा किनारे खिसकाने का तरीका। 45° ऑफसेट में लंबाई = दूरी × 1.414 होती है।',
    },
    fieldTip: {
      en: 'Always subtract the socket insertion depth of both 45° elbows when cutting the travel piece.',
      hi: 'तिरछा टुकड़ा काटते समय दोनों 45° एल्बो के अंदर जाने वाली गहराई (Socket depth) घटाना न भूलें।',
    },
  },
  {
    letter: 'P',
    term: 'PPR (Polypropylene Random Copolymer)',
    hindiTerm: 'पीपीआर पाइप (PPR)',
    summary: {
      en: 'Heat-fused plastic pipe (usually green, white, or grey) rated PN20 for hot and cold pressurized water supply up to 95°C.',
      hi: 'हीट-वेल्डिंग से जुड़ने वाला मजबूत प्लास्टिक पाइप (हरा/सफेद) जो 95°C गर्म और ठंडे प्रेशर वाले पानी के लिए सबसे बेहतर है।',
    },
    fieldTip: {
      en: 'Keep fusion welder exactly at 260°C and never twist the pipe while inserting into the heated die.',
      hi: 'वेल्डिंग मशीन का तापमान 260°C रखें और डाई में पाइप डालते समय कभी घुमाएं नहीं।',
    },
  },
  {
    letter: 'Q',
    term: 'Quarter-Turn Ceramic Cartridge',
    hindiTerm: 'क्वार्टर-टर्न सिरेमिक कार्ट्रिज',
    summary: {
      en: 'Modern tap valve mechanism using two polished ceramic discs that open/close fully in a 90° turn with zero washer wear.',
      hi: 'आधुनिक नल के अंदर का स्पिंडल जो केवल 90° घुमाने पर पानी चालू/बंद करता है और जल्दी लीक नहीं होता।',
    },
    fieldTip: {
      en: 'Flush dirt and sand from new pipes before installing expensive ceramic mixer taps to avoid scratching the discs.',
      hi: 'नया मिक्सर नल लगाने से पहले पाइप लाइन को पानी चलाकर साफ कर लें ताकि रेत से कार्ट्रिज खराब न हो।',
    },
  },
  {
    letter: 'R',
    term: 'Reducer & PRV (Pressure Reducing Valve)',
    hindiTerm: 'रिड्यूसर और प्रेशर रिड्यूसिंग वॉल्व',
    summary: {
      en: 'A Reducer steps pipe diameter down (e.g. 32mm to 25mm). A PRV lowers excessive mains water pressure to a safe 3–4 Bar.',
      hi: 'रिड्यूसर बड़े पाइप को छोटे पाइप से जोड़ता है। PRV हाई-प्रेशर पानी को कम करके सुरक्षित 3–4 Bar पर लाता है।',
    },
    fieldTip: {
      en: 'In horizontal drainage lines, always use an Eccentric Reducer with the flat side on top to prevent air pockets.',
      hi: 'लेटी हुई ड्रेनेज लाइन में हमेशा Eccentric Reducer का सपाट हिस्सा ऊपर की तरफ रखें।',
    },
  },
  {
    letter: 'S',
    term: 'Slope / Gradient & Soil Stack',
    hindiTerm: 'स्लोप (ढलान) और सॉइल स्टैक',
    summary: {
      en: 'Gravity drainage pipes require proper downward fall (1:40 to 1:100) so water carries waste cleanly without leaving solids behind.',
      hi: 'ड्रेनेज पाइप में सही ढलान (1:40 से 1:100) होना जरूरी है ताकि पानी के साथ कचरा भी आसानी से बह जाए।',
    },
    fieldTip: {
      en: 'Too much slope causes water to rush ahead leaving solids stuck; stick to 1–2 cm drop per meter.',
      hi: 'बहुत ज्यादा ढलान देने पर पानी आगे निकल जाता है और कचरा पाइप में रुक जाता है—प्रति मीटर 1 से 2 सेमी ढलान सही है।',
    },
  },
  {
    letter: 'T',
    term: 'Tee & P-Trap',
    hindiTerm: 'टी (Tee) और पी-ट्रैप',
    summary: {
      en: 'A Tee splits or combines flow at 90°. A P-Trap creates a curved water seal under sinks and WCs to block sewer gases.',
      hi: 'टी फिटिंग एक पाइप से 90° पर दूसरी लाइन निकालती है। P-Trap सिंक या टॉयलेट के नीचे पानी रोककर गैस की बदबू बंद करता है।',
    },
    fieldTip: {
      en: 'For drainage branch connections, prefer a 45° Y-Tee (Wye) over a straight 90° Tee for smooth flow.',
      hi: 'ड्रेनेज लाइन में 90° Tee की जगह 45° Y-Tee (वाई-टी) लगाना जाम से बचाता है।',
    },
  },
  {
    letter: 'U',
    term: 'Union & uPVC Pipe',
    hindiTerm: 'यूनियन और यूपीवीसी पाइप',
    summary: {
      en: 'A 3-piece Union allows disconnecting a pipe near a pump or heater without cutting. uPVC is rigid unplasticized PVC for drainage and cold supply.',
      hi: 'यूनियन 3 हिस्सों वाला जोड़ है जिससे पंप या हीटर के पास पाइप को काटे बिना खोला जा सकता है। uPVC सख्त प्लास्टिक पाइप है।',
    },
    fieldTip: {
      en: 'Always install unions on both sides of pumps, water heaters, and booster manifolds for easy future replacement.',
      hi: 'पंप और वाटर हीटर के दोनों तरफ हमेशा यूनियन लगाएं ताकि बाद में खोलना आसान हो।',
    },
  },
  {
    letter: 'V',
    term: 'Vent Pipe & Vacuum Breaker',
    hindiTerm: 'वेंट पाइप और वैक्यूम ब्रेकर',
    summary: {
      en: 'A vertical pipe extending above roof level to equalize air pressure in drains so flushing a toilet does not siphon nearby traps dry.',
      hi: 'छत से ऊपर तक जाने वाला हवा का पाइप जो ड्रेनेज में एयर प्रेशर बराबर रखता है और ट्रैप का पानी खिंचने से रोकता है।',
    },
    fieldTip: {
      en: 'Terminate roof vent stacks at least 900mm above the roof slab or nearby windows with a bird/mesh cowl.',
      hi: 'वेंट पाइप को छत की स्लैब से कम से कम 900mm ऊपर रखें और ऊपर जाली (Cowl) लगाएं।',
    },
  },
  {
    letter: 'W',
    term: 'Water Hammer Arrester',
    hindiTerm: 'वाटर हैमर अरेस्टर',
    summary: {
      en: 'A sealed air/piston cushion installed near fast-closing solenoid or lever valves to absorb pressure shockwaves (banging pipes).',
      hi: 'वॉशिंग मशीन या तेज बंद होने वाले नल के पास लगने वाला उपकरण जो पाइप में होने वाली खटखट (Shockwave) को रोकता है।',
    },
    fieldTip: {
      en: 'Secure pipes properly with rubber-lined clamps every 1.2m to stop pipe rattling.',
      hi: 'पाइप में आवाज और कंपन रोकने के लिए हर 1.2 मीटर पर रबर वाले क्लैंप लगाएं।',
    },
  },
  {
    letter: 'X',
    term: 'Cross-Connection Control',
    hindiTerm: 'क्रॉस-कनेक्शन रोकथाम',
    summary: {
      en: 'Preventing dirty or non-potable water (irrigation, drainage, chilled water) from ever mixing back into clean drinking water lines.',
      hi: 'यह सुनिश्चित करना कि गंदा या बिना पीने वाला पानी किसी भी हालत में साफ पीने की लाइन में वापस न मिल सके।',
    },
    fieldTip: {
      en: 'Use an air gap or Double Check Valve Assembly (DCVA) when connecting booster tanks or irrigation headers.',
      hi: 'टैंक और गार्डन लाइन में एयर-गैप या डबल चेक वॉल्व का इस्तेमाल करें।',
    },
  },
  {
    letter: 'Y',
    term: 'Y-Strainer & Wye Fitting',
    hindiTerm: 'वाई-स्ट्रेनर और वाई-फिटिंग',
    summary: {
      en: 'A Y-Strainer houses a stainless mesh screen to trap sand/rust before pumps and PRVs. A Wye (45° Tee) joins drain branches smoothly.',
      hi: 'Y-Strainer पाइप में जाली की मदद से कचरा व रेत रोककर पंप व PRV को बचाता है। वाई-टी ड्रेनेज में 45° पर जोड़ देती है।',
    },
    fieldTip: {
      en: 'Install Y-Strainer with the mesh pocket pointing downward so debris collects for easy blow-down cleaning.',
      hi: 'Y-Strainer का जाली वाला हिस्सा नीचे की तरफ रखें ताकि कचरा उसमें जमा हो और आसानी से साफ हो सके।',
    },
  },
  {
    letter: 'Z',
    term: 'Zone Isolation Valve',
    hindiTerm: 'जोन आइसोलेशन वॉल्व',
    summary: {
      en: 'Main shutoff valves installed per bathroom, kitchen, or building floor so one area can be repaired without shutting water to the whole building.',
      hi: 'हर बाथरूम, किचन या मंजिल के बाहर लगने वाला मुख्य वॉल्व जिससे पूरी बिल्डिंग का पानी बंद किए बिना एक हिस्से की रिपेयर हो सके।',
    },
    fieldTip: {
      en: 'Always place zone isolation valves behind an accessible ceiling hatch or wall access panel—never plaster over them.',
      hi: 'जोन आइसोलेशन वॉल्व हमेशा एक्सेस डोर या खुली जगह पर लगाएं, कभी दीवार में प्लास्टर से बंद न करें।',
    },
  },
];

export const PIPE_SIZES: PipeSizeSpec[] = [
  {
    mm: 15,
    inch: '1/2"',
    dn: 'DN15',
    materials: 'CPVC / Copper / GI / PEX',
    pressureRating: 'PN16 – PN20',
    usage: {
      en: 'Individual fixture drops: wash basin tap, angle valve, flush cistern, bidet spray (shattaf), and kitchen faucet tail.',
      hi: 'सिंगल पॉइंट सप्लाई: वॉश बेसिन नल, एंगल वॉल्व, फ्लश टैंक, शत्ताफ (जेट स्प्रे) और किचन सिंक कनेक्शन।',
    },
    wallNote: {
      en: 'Standard 1/2" BSP female brass elbow at final tiled wall outlet.',
      hi: 'दीवार के अंतिम पॉइंट पर 1/2" ब्रास फीमेल एल्बो लगाया जाता है।',
    },
  },
  {
    mm: 20,
    inch: '3/4"',
    dn: 'DN20',
    materials: 'PPR / CPVC / PEX / Copper',
    pressureRating: 'PN20 (PPR)',
    usage: {
      en: 'Concealed bathroom branch lines, shower mixer feeds, water heater inlets/outlets, and small villa sub-branches.',
      hi: 'बाथरूम के अंदर की ब्रांच लाइन, शावर मिक्सर, गीजर (वाटर हीटर) लाइन और छोटे बाथरूम सप्लाई।',
    },
    wallNote: {
      en: '20mm PPR is the standard concealed bathroom pipe in Dubai & India.',
      hi: 'दुबई और भारत में बाथरूम की कंसील्ड सप्लाई के लिए 20mm PPR सबसे आम है।',
    },
  },
  {
    mm: 25,
    inch: '1"',
    dn: 'DN25',
    materials: 'PPR / CPVC / uPVC / GI',
    pressureRating: 'PN20',
    usage: {
      en: 'Bathroom main header feeding 2–3 fixtures together, kitchen + laundry feed, and small residential roof tank outlet.',
      hi: 'पूरे बाथरूम की मेन फीड लाइन (2–3 पॉइंट एक साथ), किचन+लॉन्ड्री लाइन और छोटे घर की टंकी आउटलेट।',
    },
    wallNote: {
      en: 'Reduces pressure drop when shower and toilet flush run simultaneously.',
      hi: 'एक साथ शावर और फ्लश चलने पर प्रेशर कम नहीं होने देता।',
    },
  },
  {
    mm: 32,
    inch: '1-1/4"',
    dn: 'DN32',
    materials: 'PPR / uPVC / HDPE',
    pressureRating: 'PN16 – PN20',
    usage: {
      en: 'Apartment main water entry line, AC condensate main header, wash basin multi-trap drain, and villa roof distribution.',
      hi: 'फ्लैट की मुख्य पानी की एंट्री लाइन, विला छत की मेन डिस्ट्रीब्यूशन लाइन और AC ड्रेन मेन हेडर।',
    },
    wallNote: {
      en: 'Commonly used between water meter/PRV and apartment manifold.',
      hi: 'वाटर मीटर या PRV से फ्लैट के मैनिफोल्ड तक इस्तेमाल होता है।',
    },
  },
  {
    mm: 40,
    inch: '1-1/2"',
    dn: 'DN40',
    materials: 'uPVC / PVC / PPR',
    pressureRating: 'Drainage BS EN 1329 / PN16',
    usage: {
      en: 'Wash basin waste drain, bathtub waste, washing machine standpipe, and medium booster pump suction/header.',
      hi: 'वॉश बेसिन का गंदा पानी (Waste), बाथटब ड्रेन, वॉशिंग मशीन ड्रेन और मध्यम पंप लाइन।',
    },
    wallNote: {
      en: 'Recommended minimum slope 1:40 (2.5 cm drop per meter) for 40mm waste.',
      hi: '40mm वेस्ट पाइप में 1:40 (प्रति मीटर 2.5 सेमी) ढलान रखना जरूरी है।',
    },
  },
  {
    mm: 50,
    inch: '2"',
    dn: 'DN50',
    materials: 'uPVC / PVC / PPR / HDPE',
    pressureRating: 'Drainage / PN16',
    usage: {
      en: 'Kitchen sink waste drain, shower tray waste, floor trap outlet pipe, and multi-floor building riser supply.',
      hi: 'किचन सिंक ड्रेन, शावर वेस्ट पाइप, फ्लोर ट्रैप की आउटलेट लाइन और बिल्डिंग सप्लाई राइजर।',
    },
    wallNote: {
      en: 'Standard Dubai bathroom floor trap outlet size (50mm to 75mm).',
      hi: 'दुबई में बाथरूम फ्लोर ट्रैप का आउटलेट कम से कम 50mm रखा जाता है।',
    },
  },
  {
    mm: 75,
    inch: '3"',
    dn: 'DN75',
    materials: 'uPVC / Cast Iron / HDPE',
    pressureRating: 'BS EN 1329 / SWR Type B',
    usage: {
      en: 'Vertical greywater waste stack, multi-bathroom waste collector, rainwater downpipe, and ventilation stack.',
      hi: 'खड़ी वेस्ट वाटर पाइप (Greywater Stack), कई बाथरूम जोड़ने वाली वेस्ट लाइन, बारिश का पाइप और वेंट पाइप।',
    },
    wallNote: {
      en: 'Standard slope 1:60 to 1:80 for horizontal 75mm collector lines.',
      hi: '75mm लेटी हुई लाइन में 1:60 से 1:80 का ढलान दिया जाता है।',
    },
  },
  {
    mm: 110,
    inch: '4"',
    dn: 'DN110',
    materials: 'uPVC / SWR / HDPE / Cast Iron',
    pressureRating: 'BS EN 1329 / Class 4–6 Bar',
    usage: {
      en: 'WC (Toilet) soil pipe, main vertical soil stack, underground manhole branch drain, and main roof storm pipe.',
      hi: 'टॉयलेट (WC) का मुख्य पाइप, बिल्डिंग का मेन सॉइल स्टैक और जमीन के नीचे मैनहोल की मेन ड्रेन।',
    },
    wallNote: {
      en: 'Maintain 1:80 to 1:100 slope (1–1.25 cm per meter) for 110mm soil lines.',
      hi: '110mm टॉयलेट पाइप में 1:80 से 1:100 (प्रति मीटर 1 से 1.25 सेमी) ढलान रखें।',
    },
  },
];

export const PIPE_MATERIALS: PipeMaterialSpec[] = [
  {
    id: 'ppr',
    name: 'PPR',
    fullName: 'Polypropylene Random Copolymer (Type 3)',
    colorCode: 'Green / White / Grey',
    tempMax: '95°C (Peak 110°C)',
    pressureMax: 'PN20 (20 Bar)',
    joining: {
      en: 'Socket heat fusion welding at 260°C',
      hi: '260°C तापमान पर हीटर मशीन से सॉकेट फ्यूजन वेल्डिंग',
    },
    bestFor: {
      en: 'Hot & cold pressurized water supply inside walls, risers, and Dubai villa/tower MEP.',
      hi: 'दीवार के अंदर गर्म और ठंडे प्रेशर वाले पानी की सप्लाई, राइजर और दुबई प्रोजेक्ट्स।',
    },
    sectorUsage: {
      en: 'Residential · Commercial Towers',
      hi: 'घरेलू और कमर्शियल बिल्डिंग',
    },
  },
  {
    id: 'upvc',
    name: 'uPVC',
    fullName: 'Unplasticized Polyvinyl Chloride',
    colorCode: 'Grey / Terracotta / White',
    tempMax: '60°C',
    pressureMax: 'Class E (15 Bar) / SWR Gravity',
    joining: {
      en: 'Solvent cement welding or push-fit rubber ring (EPDM)',
      hi: 'सॉल्वेंट ग्लू (पेस्ट) या रबर रिंग पुश-फिट जोड़',
    },
    bestFor: {
      en: 'Drainage, soil & waste stacks, rainwater, cold main headers, and underground sewer.',
      hi: 'ड्रेनेज, टॉयलेट-बाथरूम वेस्ट लाइन, बारिश का पानी और अंडरग्राउंड सीवर।',
    },
    sectorUsage: {
      en: 'Residential · Commercial · Municipal',
      hi: 'घरेलू, कमर्शियल और सीवरेज',
    },
  },
  {
    id: 'cpvc',
    name: 'CPVC',
    fullName: 'Chlorinated Polyvinyl Chloride',
    colorCode: 'Cream / Off-White',
    tempMax: '93°C',
    pressureMax: 'SDR 11 (28 Bar @ 23°C)',
    joining: {
      en: 'CPVC yellow/orange heavy-duty solvent cement',
      hi: 'CPVC स्पेशल सॉल्वेंट सीमेंट (बिना बिजली के जुड़ता है)',
    },
    bestFor: {
      en: 'Hot & cold domestic water supply where no electricity is available for fusion welding.',
      hi: 'जहां वेल्डिंग मशीन/बिजली उपलब्ध न हो वहां गर्म और ठंडे पानी की सप्लाई।',
    },
    sectorUsage: {
      en: 'Residential · Fast Retrofits',
      hi: 'घरेलू और रिपेयर कार्य',
    },
  },
  {
    id: 'hdpe',
    name: 'HDPE',
    fullName: 'High-Density Polyethylene',
    colorCode: 'Black (Blue or Orange Stripe)',
    tempMax: '60°C',
    pressureMax: 'PN10 – PN16',
    joining: {
      en: 'Butt fusion welding or Electrofusion couplings',
      hi: 'बट-फ्यूजन वेल्डिंग या इलेक्ट्रोफ्यूजन कपलर',
    },
    bestFor: {
      en: 'Underground main water supply, municipal water networks, basement sumps, and industrial drains.',
      hi: 'जमीन के नीचे मेन वाटर सप्लाई, म्युनिसिपल लाइन और इंडस्ट्रियल ड्रेनेज।',
    },
    sectorUsage: {
      en: 'Infrastructure · Industrial · Commercial',
      hi: 'इंफ्रास्ट्रक्चर और इंडस्ट्रियल',
    },
  },
  {
    id: 'pex',
    name: 'PEX',
    fullName: 'Cross-Linked Polyethylene (PEX-a / PEX-AL-PEX)',
    colorCode: 'Red (Hot) / Blue (Cold) / White',
    tempMax: '95°C',
    pressureMax: '10 Bar',
    joining: {
      en: 'Crimp ring, press-fit, or expansion sleeve fittings',
      hi: 'क्रिम्प रिंग, प्रेस-फिट या एक्सपेंशन स्लीव फिटिंग',
    },
    bestFor: {
      en: 'Manifold home-run flexible piping inside walls and underfloor heating loops.',
      hi: 'मैनिफोल्ड से सीधे नल तक बिना जोड़ की फ्लेक्सिबल सप्लाई लाइन।',
    },
    sectorUsage: {
      en: 'Modern Villas · Apartments',
      hi: 'आधुनिक विला और अपार्टमेंट',
    },
  },
  {
    id: 'copper',
    name: 'Copper',
    fullName: 'BS EN 1057 Copper Tube (Table X / Y)',
    colorCode: 'Metallic Copper (Red/Blue Insulation)',
    tempMax: '110°C+',
    pressureMax: '30+ Bar',
    joining: {
      en: 'Capillary soldering, silver brazing, brass compression, or press-fit',
      hi: 'सॉल्डरिंग, ब्रेजिंग, ब्रास कंप्रेशन या प्रेस-फिट',
    },
    bestFor: {
      en: 'Solar water heaters, boiler rooms, chilled water HVAC, and luxury hotel risers.',
      hi: 'सोलर हीटर, बॉयलर रूम, चिल्ड वाटर और लग्जरी होटल प्रोजेक्ट्स।',
    },
    sectorUsage: {
      en: 'Commercial · Industrial · HVAC',
      hi: 'कमर्शियल और इंडस्ट्रियल',
    },
  },
  {
    id: 'gi',
    name: 'GI',
    fullName: 'Galvanized Iron (Class A / B / C)',
    colorCode: 'Silver Zinc / Painted Red Fire',
    tempMax: '120°C+',
    pressureMax: '25+ Bar',
    joining: {
      en: 'BSP external threading with die stock + PTFE / hemp & jointing compound',
      hi: 'डाई से चूड़ी (Thread) काटकर टेफ्लॉन टेप या जूट-पुट्टी से जोड़ना',
    },
    bestFor: {
      en: 'Exposed outdoor risers, pump rooms, fire-fighting sprinkler mains, and heavy mechanical protection.',
      hi: 'बाहरी खुली लाइन, पंप रूम, फायर-फाइटिंग लाइन और भारी इंडस्ट्रियल काम।',
    },
    sectorUsage: {
      en: 'Industrial · Fire Fighting · Pump Rooms',
      hi: 'इंडस्ट्रियल और पंप रूम',
    },
  },
];

export const PIPE_FITTINGS: FittingSpec[] = [
  {
    id: 'elbow90',
    name: '90° Elbow',
    hindiName: '90° एल्बो (मोड़)',
    category: 'Direction & Branch',
    svgType: 'elbow90',
    purpose: {
      en: 'Turns a pipeline sharply by 90 degrees around wall corners or into fixture drops.',
      hi: 'दीवार के कोनों या नल पॉइंट की तरफ पाइप लाइन को ठीक 90 डिग्री मोड़ने के लिए।',
    },
    installationTip: {
      en: 'For buried drainage or vertical-to-horizontal soil transitions, use two 45° elbows instead of one 90°.',
      hi: 'ड्रेनेज लाइन के नीचे तेज मोड़ पर एक 90° की जगह दो 45° एल्बो लगाना हमेशा बेहतर रहता है।',
    },
  },
  {
    id: 'elbow45',
    name: '45° Elbow',
    hindiName: '45° एल्बो (तिरछा मोड़)',
    category: 'Direction & Branch',
    svgType: 'elbow45',
    purpose: {
      en: 'Creates a smooth 45-degree turn, reducing friction loss in pressurized water lines and preventing drain clogs.',
      hi: 'पाइप को 45 डिग्री पर आसानी से मोड़ता है जिससे प्रेशर कम नहीं होता और ड्रेनेज में कचरा नहीं फंसता।',
    },
    installationTip: {
      en: 'Travel distance between two 45° elbows = Center-to-center Offset × 1.414.',
      hi: 'दो 45° एल्बो के बीच का तिरछा पाइप निकालने का फॉर्मूला = दूरी × 1.414।',
    },
  },
  {
    id: 'tee',
    name: 'Tee (Equal & Reducing)',
    hindiName: 'टी फिटिंग (बराबर व रिड्यूसिंग)',
    category: 'Direction & Branch',
    svgType: 'tee',
    purpose: {
      en: 'Splits one main pipe into two 90° branches. Equal Tee keeps all three ports identical; Reducing Tee has a smaller side branch (e.g. 25×20×25mm).',
      hi: 'एक मेन पाइप से 90° पर नई ब्रांच निकालने के काम आती है। रिड्यूसिंग टी में मेन लाइन बड़ी और साइड ब्रांच छोटी (जैसे 25×20×25mm) होती है।',
    },
    installationTip: {
      en: 'Use 45° Y-Tee (Wye) for horizontal drainage branches so incoming waste flows forward, never backward.',
      hi: 'ड्रेनेज में ब्रांच जोड़ने के लिए हमेशा बहाव की दिशा वाली 45° Y-Tee लगाएं।',
    },
  },
  {
    id: 'socket',
    name: 'Socket / Coupler',
    hindiName: 'सॉकेट / कपलर (सीधा जोड़)',
    category: 'Connection & Size',
    svgType: 'socket',
    purpose: {
      en: 'Connects two straight pipes of the exact same diameter end-to-end.',
      hi: 'एक ही साइज के दो सीधे पाइपों को आपस में लंबाई बढ़ाने के लिए जोड़ता है।',
    },
    installationTip: {
      en: 'Use a Repair Slip Coupler (without center stop) when splicing into an existing fixed pipeline.',
      hi: 'पुरानी फिक्स पाइप लाइन में नया टुकड़ा जोड़ने के लिए बिना स्टॉप वाला Slip Coupler इस्तेमाल करें।',
    },
  },
  {
    id: 'reducer',
    name: 'Reducer (Socket / Bush)',
    hindiName: 'रिड्यूसर / बुश',
    category: 'Connection & Size',
    svgType: 'reducer',
    purpose: {
      en: 'Steps down pipe diameter safely, such as 32mm main riser to 25mm apartment branch or 110mm to 75mm.',
      hi: 'बड़े साइज के पाइप को छोटे साइज के पाइप से जोड़ने के लिए (जैसे 32mm से 25mm या 110mm से 75mm)।',
    },
    installationTip: {
      en: 'Always place eccentric reducers flat-side-up on horizontal suction/drain lines to eliminate air pockets.',
      hi: 'लेटी हुई ड्रेन या पंप सक्शन लाइन में Eccentric Reducer का सपाट भाग ऊपर रखें ताकि हवा न फंसे।',
    },
  },
  {
    id: 'union',
    name: '3-Piece Union',
    hindiName: 'यूनियन (खुलने वाला जोड़)',
    category: 'Connection & Size',
    svgType: 'union',
    purpose: {
      en: 'A demountable threaded collar joint allowing pumps, heaters, and valves to be removed cleanly without cutting pipes.',
      hi: 'तीन हिस्सों वाली फिटिंग जिससे पंप, गीजर या वॉल्व को पाइप काटे बिना आसानी से खोला और बदला जा सकता है।',
    },
    installationTip: {
      en: 'Verify the EPDM O-ring / rubber gasket sits flat inside the union face before hand-tightening the collar nut.',
      hi: 'यूनियन नट कसने से पहले अंदर की रबर वाशर (O-Ring) सही जगह पर होना पक्का करें।',
    },
  },
  {
    id: 'valve',
    name: 'Valves (Gate, Ball, NRV, PRV)',
    hindiName: 'वॉल्व (गेट, बॉल, NRV, PRV)',
    category: 'Valves',
    svgType: 'valve',
    purpose: {
      en: 'Ball & Gate valves shut off flow; NRV (Check Valve) stops backflow; PRV reduces high pressure; Float valve shuts off roof tank.',
      hi: 'बॉल/गेट वॉल्व पानी बंद करते हैं; NRV पानी वापस लौटने से रोकता है; PRV तेज प्रेशर कम करता है; फ्लोट वॉल्व टंकी भरने पर बंद होता है।',
    },
    installationTip: {
      en: 'Install isolation valves before every NRV and PRV so they can be serviced without draining the riser.',
      hi: 'हर NRV और PRV से पहले एक बॉल या गेट वॉल्व जरूर लगाएं ताकि सर्विस के समय पूरी लाइन खाली न करनी पड़े।',
    },
  },
  {
    id: 'bend',
    name: 'Long Sweep Bend',
    hindiName: 'लॉन्ग स्वीप बेंड (लंबा मोड़)',
    category: 'Direction & Branch',
    svgType: 'bend',
    purpose: {
      en: 'Large-radius 90° curve used in drainage soil pipes and pump deliveries to maintain high flow speed with minimal friction.',
      hi: 'बड़े घुमाव वाला 90° मोड़ जो टॉयलेट ड्रेनेज और पंप लाइन में पानी का बहाव तेज रखता है और जाम नहीं होने देता।',
    },
    installationTip: {
      en: 'Mandatory at the base of vertical 110mm soil stacks where flow changes from vertical to horizontal.',
      hi: '110mm खड़ी टॉयलेट लाइन जब जमीन में लेटी लाइन से मिलती है तो वहां लॉन्ग बेंड लगाना जरूरी है।',
    },
  },
  {
    id: 'ptrap',
    name: 'P-Trap / Bottle Trap',
    hindiName: 'पी-ट्रैप / बॉटल ट्रैप',
    category: 'Traps',
    svgType: 'ptrap',
    purpose: {
      en: 'Holds a constant 50mm water seal under wash basins and kitchen sinks to block foul sewer gases and insects.',
      hi: 'वॉश बेसिन और किचन सिंक के नीचे पानी की सील बनाकर सीवर की बदबू और कीड़ों को घर में आने से रोकता है।',
    },
    installationTip: {
      en: 'Bottle traps look neat under open pedestal/wall-hung basins and have a bottom screw cup for quick cleaning.',
      hi: 'खुले वॉश बेसिन के नीचे बॉटल ट्रैप देखने में अच्छा लगता है और नीचे का कैप खोलकर आसानी से साफ हो जाता है।',
    },
  },
  {
    id: 'floortrap',
    name: 'Floor Trap / Multi-Inlet Gully',
    hindiName: 'फ्लोर ट्रैप (नहनी ट्रैप)',
    category: 'Traps',
    svgType: 'floortrap',
    purpose: {
      en: 'Collects bathroom floor water plus side inlets (basin 40mm, shower 50mm, AC drain 25mm) through one single water-sealed outlet.',
      hi: 'बाथरूम फर्श के पानी के साथ बेसिन, शावर और AC ड्रेन की साइड लाइनों को लेकर एक ही वाटर-सील आउटलेट से बाहर निकालता है।',
    },
    installationTip: {
      en: 'Never drill random holes into a pipe—use factory-molded multi-inlet floor traps with rubber seal rings.',
      hi: 'पाइप में छेद करके जोड़ न बनाएं; हमेशा कंपनी से बने मल्टी-इनलेट फ्लोर ट्रैप का उपयोग करें।',
    },
  },
];

export const PPR_FUSION_TABLE: PprFusionRow[] = [
  { sizeMm: '20 mm', depthMm: '14 mm', heatingSec: '5 sec', joiningSec: '4 sec', coolingMin: '2 min' },
  { sizeMm: '25 mm', depthMm: '16 mm', heatingSec: '7 sec', joiningSec: '4 sec', coolingMin: '2 min' },
  { sizeMm: '32 mm', depthMm: '18 mm', heatingSec: '8 sec', joiningSec: '6 sec', coolingMin: '4 min' },
  { sizeMm: '40 mm', depthMm: '20 mm', heatingSec: '12 sec', joiningSec: '6 sec', coolingMin: '4 min' },
  { sizeMm: '50 mm', depthMm: '23 mm', heatingSec: '18 sec', joiningSec: '6 sec', coolingMin: '4 min' },
  { sizeMm: '63 mm', depthMm: '27 mm', heatingSec: '24 sec', joiningSec: '8 sec', coolingMin: '6 min' },
  { sizeMm: '75 mm', depthMm: '30 mm', heatingSec: '30 sec', joiningSec: '10 sec', coolingMin: '8 min' },
  { sizeMm: '110 mm', depthMm: '37 mm', heatingSec: '50 sec', joiningSec: '10 sec', coolingMin: '8 min' },
];

export const JOINTING_METHODS: JointingMethod[] = [
  {
    id: 'ppr-fusion',
    title: {
      en: 'PPR Socket Heat Fusion Welding (260°C)',
      hi: 'PPR हीट फ्यूजन वेल्डिंग (260°C)',
    },
    pipeTypes: 'PPR (20mm – 110mm)',
    temperature: '260°C ± 5°C',
    steps: [
      {
        en: 'Cut the pipe cleanly at 90° square using a sharp PPR ratchet cutter (no burrs).',
        hi: 'PPR कटर से पाइप को बिल्कुल सीधा 90° काटें ताकि किनारा टेढ़ा न हो।',
      },
      {
        en: 'Mark the exact insertion depth on the pipe end using a marker and template (e.g. 16mm for 25mm pipe).',
        hi: 'पाइप पर सही गहराई का निशान लगाएं (जैसे 25mm पाइप के लिए 16mm)।',
      },
      {
        en: 'Wait until the fusion welder indicator shows steady 260°C. Wipe pipe and fitting with clean cloth/alcohol.',
        hi: 'मशीन के 260°C पर पहुंचने का इंतजार करें। पाइप और फिटिंग को सूखे कपड़े से साफ करें।',
      },
      {
        en: 'Push pipe into the female die and fitting onto the male die simultaneously without twisting.',
        hi: 'बिना घुमाए एक साथ पाइप और फिटिंग को हीटर डाई में सीधा अंदर दबाएं।',
      },
      {
        en: 'Count the exact heating seconds (5s for 20mm, 7s for 25mm, 8s for 32mm).',
        hi: 'साइज के अनुसार ठीक समय गिनें (20mm: 5 सेकंड, 25mm: 7 सेकंड, 32mm: 8 सेकंड)।',
      },
      {
        en: 'Pull both off quickly and push pipe straight into the fitting up to the mark—hold still for 4–6 seconds.',
        hi: 'दोनों को तुरंत निकालकर बिना घुमाए निशान तक सीधा जोड़ दें और 4–6 सेकंड पकड़ कर रखें।',
      },
    ],
    mistakeToAvoid: {
      en: 'Never overheat or twist while pushing—overheating melts plastic inward and blocks water flow inside the pipe!',
      hi: 'जरूरत से ज्यादा गर्म न करें और न ही घुमाएं—ज्यादा गर्म होने से अंदर का प्लास्टिक पिघलकर रास्ता बंद कर देता है!',
    },
  },
  {
    id: 'solvent-cement',
    title: {
      en: 'uPVC / CPVC Solvent Cement Welding',
      hi: 'uPVC / CPVC सॉल्वेंट ग्लू जोड़ना',
    },
    pipeTypes: 'PVC / uPVC / CPVC (15mm – 160mm)',
    temperature: 'Ambient (5°C – 45°C)',
    steps: [
      {
        en: 'Cut pipe square and chamfer (bevel) the outside edge at 15° with a file so it does not scrape glue off.',
        hi: 'पाइप सीधा काटकर बाहरी किनारे को हल्का सा घिसें (Chamfer) ताकि अंदर जाते समय ग्लू साफ न हो।',
      },
      {
        en: 'Dry-fit first: pipe should enter 1/3 to 2/3 of the socket comfortably. Clean dust, oil, and moisture.',
        hi: 'पहले बिना ग्लू के चेक करें। धूल, तेल और नमी को साफ सूखे कपड़े से पोंछें।',
      },
      {
        en: 'Apply cleaner/primer first (for Class E high-pressure uPVC), then apply solvent cement evenly inside the fitting socket first, then heavier coat on the pipe end.',
        hi: 'हाई-प्रेशर लाइन में पहले प्राइमर लगाएं, फिर फिटिंग के अंदर पतला और पाइप के सिरे पर बराबर सॉल्वेंट सीमेंट लगाएं।',
      },
      {
        en: 'Push pipe home immediately with a 1/4 turn (90° twist) and hold firmly for 30 seconds.',
        hi: 'तुरंत पाइप को अंदर दबाते हुए 1/4 घुमाएं और 30 सेकंड तक मजबूती से पकड़े रहें।',
      },
      {
        en: 'Wipe excess glue bead outside and wait 2 hours before water flow (24 hours before 10 Bar pressure test).',
        hi: 'बाहर निकले अतिरिक्त ग्लू को पोंछ दें। पानी चलाने के लिए 2 घंटे और प्रेशर टेस्ट के लिए 24 घंटे रुकें।',
      },
    ],
    mistakeToAvoid: {
      en: 'Never apply glue over wet pipe or puddle excess glue inside the socket (puddles weaken the pipe wall).',
      hi: 'गीले पाइप पर ग्लू न लगाएं और फिटिंग के अंदर बहुत ज्यादा ग्लू इकट्ठा न होने दें।',
    },
  },
  {
    id: 'gi-threading',
    title: {
      en: 'GI Pipe Cutting & BSP Threading',
      hi: 'GI पाइप कटिंग और चूड़ी (थ्रेड) बनाना',
    },
    pipeTypes: 'Galvanized Iron (15mm – 50mm)',
    temperature: 'Cold Mechanical + Cutting Oil',
    steps: [
      {
        en: 'Clamp the GI pipe firmly in a pipe vice with the cut mark 15cm outside the jaws.',
        hi: 'पाइप को पाइप वाइस में कसकर बांधें और निशान जबड़ों से करीब 15 सेमी बाहर रखें।',
      },
      {
        en: 'Cut using a wheel pipe cutter or hacksaw; ream the inner burr smoothly.',
        hi: 'पाइप कटर या आरी से सीधा काटें और अंदर की तीखी धार (Burr) रीमर से साफ करें।',
      },
      {
        en: 'Select the matching BSP die head (1/2", 3/4", 1"), apply thread-cutting oil generously.',
        hi: 'सही साइज का डाई हेड लगाएं और कटिंग ऑयल अच्छी तरह डालें।',
      },
      {
        en: 'Rotate ratchet handle clockwise (1 forward, 1/4 back to break metal chips) until pipe end sits flush with die face.',
        hi: 'रैचेट को आगे घुमाएं और चिप्स तोड़ने के लिए थोड़ा पीछे लाएं जब तक चूड़ी पूरी न बन जाए।',
      },
      {
        en: 'Clean metal shavings, wrap PTFE tape clockwise (looking at pipe end) 10–15 turns, and tighten with pipe wrench.',
        hi: 'बुरादा साफ करके घड़ी की दिशा में टेफ्लॉन टेप या जूट-पुट्टी लपेटकर पाइप रिंच से कसें।',
      },
    ],
    mistakeToAvoid: {
      en: 'Never cut threads dry without cutting oil—dry threading tears threads and ruins the die teeth.',
      hi: 'बिना कटिंग ऑयल के सूखी चूड़ी कभी न काटें, इससे चूड़ी फट जाती है और डाई खराब होती है।',
    },
  },
];

export const SUPPLY_DWV_SYSTEMS: SupplyDwvCard[] = [
  {
    id: 'cold-water',
    system: 'supply',
    title: {
      en: 'Cold Water Supply (Gravity vs Booster Pressurized)',
      hi: 'ठंडे पानी की सप्लाई (टंकी प्रेशर व बूस्टर पंप)',
    },
    pipeSizes: '20mm – 50mm PPR / PEX',
    colorOrSlope: 'Blue Insulation / Cold Zone',
    description: {
      en: 'Feeds WCs, wash basins, cold shower inlets, kitchen cold taps, and water heaters. High-rise buildings use gravity down-feed with PRVs on lower floors and booster pumps on top 3–4 floors.',
      hi: 'टॉयलेट फ्लश, वॉश बेसिन, शावर और गीजर को ठंडा पानी देता है। ऊंची बिल्डिंग में ऊपर की मंजिलों पर बूस्टर पंप और नीचे की मंजिलों पर प्रेशर कम करने के लिए PRV लगाते हैं।',
    },
    keyPoints: [
      {
        en: 'Target pressure at fixtures: 2.5 to 4.0 Bar (35–60 PSI).',
        hi: 'नल पर आदर्श प्रेशर 2.5 से 4.0 Bar होना चाहिए।',
      },
      {
        en: 'Always place Cold tap on the RIGHT side of mixers and basins.',
        hi: 'मिक्सर और बेसिन में ठंडे पानी का पॉइंट हमेशा दाहिनी तरफ (Right) रखें।',
      },
    ],
  },
  {
    id: 'hot-water',
    system: 'supply',
    title: {
      en: 'Hot Water Supply & Recirculation Loop',
      hi: 'गर्म पानी की सप्लाई और री-सर्कुलेशन सिस्टम',
    },
    pipeSizes: '20mm – 25mm PPR / Copper (Insulated)',
    colorOrSlope: 'Red Insulation / Left Side',
    description: {
      en: 'Supplied from electric wall heaters, roof solar heaters, or central calorifiers. Must include NRV on cold inlet, Safety Relief Valve (6–8 Bar), and closed-cell thermal foam insulation.',
      hi: 'इलेक्ट्रिक गीजर, सोलर हीटर या सेंट्रल बॉयलर से आता है। ठंडे इनलेट पर NRV, सेफ्टी वॉल्व और पाइप पर थर्मल इंसुलेशन लगाना जरूरी है।',
    },
    keyPoints: [
      {
        en: 'Hot water outlet is always on the LEFT side of every mixer.',
        hi: 'गर्म पानी की लाइन हमेशा बाईं तरफ (Left) रखी जाती है।',
      },
      {
        en: 'In large villas/hotels, a hot-water return loop with a small bronze circulator gives instant hot water at every tap.',
        hi: 'बड़े विला और होटलों में रिटर्न लूप पंप लगाने से नल खोलते ही तुरंत गर्म पानी आता है।',
      },
    ],
  },
  {
    id: 'soil-waste',
    system: 'dwv',
    title: {
      en: 'Soil & Waste Drainage (Two-Pipe System)',
      hi: 'सॉइल और वेस्ट ड्रेनेज (टू-पाइप सिस्टम)',
    },
    pipeSizes: '110mm Soil · 50–75mm Waste',
    colorOrSlope: 'Slope 1:40 to 1:100',
    description: {
      en: 'In modern UAE and Indian projects, blackwater (WC 110mm Soil stack) and greywater (Basin/Shower/Kitchen 50–75mm Waste stack) run in separate vertical stacks before meeting at gully traps or manholes.',
      hi: 'आधुनिक बिल्डिंग में टॉयलेट का गंदा पानी (110mm Soil) और बाथरूम/किचन का पानी (50–75mm Waste) अलग-अलग खड़ी लाइनों में नीचे जाता है।',
    },
    keyPoints: [
      {
        en: 'Greywater can be routed to an STP/greywater recycling tank for landscape irrigation.',
        hi: 'ग्रे-वाटर को फिल्टर करके गार्डन सिंचाई के लिए दोबारा इस्तेमाल किया जा सकता है।',
      },
      {
        en: 'Provide cleanout plugs at every stack base and every 15m horizontal run.',
        hi: 'हर खड़ी लाइन के नीचे और हर 15 मीटर सीधी लाइन पर क्लीनआउट प्लग जरूर दें।',
      },
    ],
  },
  {
    id: 'vent-stack',
    system: 'dwv',
    title: {
      en: 'Ventilation & Anti-Siphonage System',
      hi: 'वेंटिलेशन और एंटी-साइफनेज पाइप',
    },
    pipeSizes: '50mm – 75mm uPVC',
    colorOrSlope: 'Roof Termination +900mm',
    description: {
      en: 'Balances positive and negative air pressure inside drainage stacks when toilets flush, protecting trap water seals and venting toxic methane/H2S gas safely above the roof.',
      hi: 'फ्लश करते समय पाइप के अंदर हवा का दबाव बराबर रखता है ताकि फ्लोर ट्रैप का पानी खिंचकर सूखे नहीं और बदबू छत के ऊपर निकल जाए।',
    },
    keyPoints: [
      {
        en: 'Connect vent branches at least 150mm above the flood-level rim of the highest fixture.',
        hi: 'वेंट क्रॉस कनेक्शन सबसे ऊंचे बेसिन या फ्लश लेवल से कम से कम 150mm ऊपर जोड़ें।',
      },
      {
        en: 'Install an Air Admittance Valve (AAV) only where roof penetration is structurally impossible.',
        hi: 'जहां छत तक पाइप न जा सके, वहां अप्रूव्ड एयर एडमिटेंस वॉल्व (AAV) लगाएं।',
      },
    ],
  },
];
