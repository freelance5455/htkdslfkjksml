export interface ScriptScene {
  id: string;
  order: number;
  titleBn: string;
  titleEn: string;
  badge: string;
  durationSeconds: number;
  textBn: string;
  keyTerms: string[];
  bRollPrompt: string;
  onScreenGraphics: string[];
  tools: { name: string; category: string; description: string }[];
  marketStat: {
    growthRate: string;
    remoteSalary: string;
    localSalary: string;
    demandLevel: 'Very High' | 'Critical' | 'Exponential';
  };
  learningSteps: string[];
  voiceNotes: string;
}

export const SCRIPT_SCENES: ScriptScene[] = [
  {
    id: 'intro',
    order: 0,
    titleBn: 'ভূমিকা: ২০২৭-এর জন্য সতর্কবার্তা ও সুযোগ',
    titleEn: 'Hook & Intro: The 2027 Shift',
    badge: 'Hook & Context',
    durationSeconds: 38,
    textBn: `আমরা কি কখনো ভেবে দেখেছি, আজ থেকে ৩-৪ বছর আগে যে স্কিলগুলোর বিশাল চাহিদা ছিল, তার অনেকগুলোরই কদর এখন কিন্তু আর আগের মতো নেই?

আপনি যদি একজন স্টুডেন্ট হন, ফ্রিল্যান্সার হতে চান, কিংবা কর্পোরেট ক্যারিয়ারে দ্রুত গ্রো করতে চান—তাহলে আগামী দিনগুলোতে টিকে থাকতে হলে শুধু প্রথাগত স্কিল নিয়ে বসে থাকলে চলবে না। প্রযুক্তি যেভাবে পাল্টাচ্ছে, তাতে নিজের স্কিলসেট আপডেট না করলে ২০২৭ সালে গিয়ে বড় ধাক্কা খেতে হবে।

আজকের এই ভিডিওতে আমরা আলোচনা করব এমন ৫টি মোস্ট ইন-ডিমান্ড স্কিল নিয়ে, যা ২০২৭ সালের আগেই আপনার শিখে নেওয়া উচিত।`,
    keyTerms: ['2027', 'Student', 'Freelancer', 'Corporate Career', 'Technology Shift'],
    bRollPrompt: 'Cinematic timelapse of a futuristic city with glowing digital data streams, switching to an ambitious student working on modern dual monitors.',
    onScreenGraphics: [
      'Warning: ৩-৪ বছরের আগের স্কিল এখন অচল!',
      'টার্গেট: ২০২৭ সালে টিকে থাকা ও গ্রো করা',
      'আলোচ্য বিষয়: ৫টি শীর্ষ ইন-ডিমান্ড স্কিল',
    ],
    tools: [
      { name: 'AI Ecosystem', category: 'Foundation', description: 'Understanding generative tools & autonomous agents' },
      { name: 'Continuous Learning', category: 'Soft Skill', description: 'Adapting to 6-month tech update cycles' },
    ],
    marketStat: {
      growthRate: '+340%',
      remoteSalary: '$25k - $60k/yr',
      localSalary: '৳৫০,০০০ - ৳১,২০,০০০/মাস',
      demandLevel: 'Critical',
    },
    learningSteps: [
      'পুরোনো বা রিপিটেটিভ কাজের বাইরে ক্রিয়েটিভ ও প্রবলেম-সলভিং মাইন্ডসেট তৈরি করা',
      'প্রযুক্তির নতুন আপডেট নিয়মিত ট্র্যাক করা (Tech newsletters, Twitter/X tech creators)',
      'প্রতিদিন অন্তত ১-২ ঘণ্টা একটি নির্দিষ্ট ফোকাসড স্কিলে ব্যয় করা',
    ],
    voiceNotes: 'Start with an urgent yet calm, confident tone. Emphasize "২০২৭ সালে গিয়ে বড় ধাক্কা খেতে হবে".',
  },
  {
    id: 'skill-1',
    order: 1,
    titleBn: '১. AI Prompt Engineering & Automation',
    titleEn: '1. AI Prompt Engineering & Automation',
    badge: 'Top Priority',
    durationSeconds: 46,
    textBn: `এক নম্বরে রয়েছে AI Prompt Engineering & Automation।

আপনি হয়তো ভাবছেন, ChatGPT-তে তো সবাই-ই কথা বলতে পারে, এতে আবার শেখার কী আছে? কিন্তু সত্যিটা হলো, সাধারণ একটা প্রম্পট দেওয়া আর সঠিক মেথডোলজি ব্যবহার করে AI থেকে পারফেক্ট কাজ আদায় করে নেওয়ার মধ্যে আকাশ-পাতাল তফাত।

শুধু তা-ই নয়, Zapier বা Make-এর মতো টুল ব্যবহার করে একটা পুরো বিজনেসের ডেইলি ডেলিভারি বা ক্লায়েন্ট কমিউনিকেশন অটোমেট করে দেওয়ার দক্ষতা থাকলে আন্তর্জাতিক মার্কেটে আপনার চাহিদা থাকবে সবার ওপরে। বাংলাদেশেই এখন এমন এআই অটোমেশন এজেন্সির কনসেপ্ট বেশ জনপ্রিয় হচ্ছে।`,
    keyTerms: ['AI Prompt Engineering', 'Automation', 'ChatGPT', 'Zapier', 'Make', 'AI Automation Agency (AAA)'],
    bRollPrompt: 'Animated flowcharts showing automated webhook connections between Gmail, Slack, CRM, and AI models executing workflows in milliseconds.',
    onScreenGraphics: [
      'Skill #1: AI Prompt Engineering & Automation',
      'টুলস: ChatGPT, Claude, Make, Zapier, n8n',
      'নতুন ট্রেন্ড: AI Automation Agency (AAA)',
    ],
    tools: [
      { name: 'Make.com', category: 'Workflow Automation', description: 'Visual drag-and-drop complex business automation' },
      { name: 'Zapier', category: 'Integration', description: 'Connecting 5,000+ business apps without code' },
      { name: 'n8n', category: 'Self-Hosted AI', description: 'Advanced AI agent orchestration pipelines' },
      { name: 'Prompt Frameworks', category: 'Methodology', description: 'Few-shot, Chain-of-Thought, Context injection' },
    ],
    marketStat: {
      growthRate: '+450%',
      remoteSalary: '$40k - $90k/yr',
      localSalary: '৳৭০,০০০ - ৳২,০০,০০০/মাস',
      demandLevel: 'Exponential',
    },
    learningSteps: [
      'সিস্টেম প্রম্পটিং ও মেথডোলজি শিখুন (Zero-shot vs Few-shot, Markdown formatting)',
      'Make.com এ ফ্রি অ্যাকাউন্ট খুলে ৩টি প্র্যাকটিক্যাল অটোমেশন ফ্লো তৈরি করুন',
      'বাংলাদেশি বা গ্লোবাল ছোট ব্যবসার একটি রিয়েল-লাইফ কমিউনিকেশন সমস্যা অটোমেট করার কেস স্টাডি বানান',
    ],
    voiceNotes: 'Dynamic, conversational. Sound enthusiastic about Make and Zapier automation.',
  },
  {
    id: 'skill-2',
    order: 2,
    titleBn: '২. Data Analytics',
    titleEn: '2. Data Analytics & Business Intelligence',
    badge: 'High Value',
    durationSeconds: 42,
    textBn: `দুই নম্বরে রয়েছে Data Analytics।

'Data is the new oil'—কথাটা আমরা অনেকেই শুনেছি। বর্তমান ই-কমার্স, ব্যাংক, টেলিকম বা দেশীয় বড় বড় কোম্পানির দিকে তাকালে দেখবেন, তারা প্রতিদিন লাখ লাখ ডেটা প্রসেস করছে।

Advanced Excel, SQL, Tableau কিংবা Power BI দিয়ে এই বিশাল পরিমাণ তথ্য অ্যানালাইসিস করে বিজনেসের সিদ্ধান্ত সহজ করতে পারেন যারা, তাদের চাহিদা সব সময় হাই-পেয়িং থাকবে। আপনি যেকোনো ব্যাকগ্রাউন্ডের হলেও কিন্তু ডেটা অ্যানালিটিক্স শেখা শুরু করতে পারেন।`,
    keyTerms: ['Data Analytics', 'Data is the new oil', 'Advanced Excel', 'SQL', 'Tableau', 'Power BI', 'E-commerce & Banking'],
    bRollPrompt: 'Sleek dark-mode financial dashboard with interactive heatmaps, interactive line charts, and SQL query editors glowing in cyan and violet.',
    onScreenGraphics: [
      'Skill #2: Data Analytics',
      'উদ্ধৃতি: "Data is the new oil"',
      'কোর টুলস: Excel • SQL • Power BI • Tableau',
      'যেকোনো ব্যাকগ্রাউন্ড থেকেই শুরু করা সম্ভব!',
    ],
    tools: [
      { name: 'Power BI', category: 'Visualization', description: 'Microsoft business analytics & interactive dashboards' },
      { name: 'SQL (PostgreSQL/MySQL)', category: 'Database Querying', description: 'Querying, filtering, and aggregating big tables' },
      { name: 'Advanced Excel', category: 'Spreadsheets', description: 'XLOOKUP, Power Query, pivot reporting' },
      { name: 'Tableau', category: 'Enterprise BI', description: 'High-end visual storytelling with multi-source data' },
    ],
    marketStat: {
      growthRate: '+280%',
      remoteSalary: '$35k - $75k/yr',
      localSalary: '৳৫৫,০০০ - ৳১,৫০,০০০/মাস',
      demandLevel: 'Very High',
    },
    learningSteps: [
      'এক্সেল দিয়ে শুরু করুন: Pivot Table, XLOOKUP এবং বেসিক চার্টিং আয়ত্ত করুন',
      'SQL এর কোর কুয়েরি শিখুন: SELECT, WHERE, JOINs, GROUP BY ও এগ্রিগেশন',
      'Power BI দিয়ে একটি আকর্ষণীয় ই-কমার্স সেলস ড্যাশবোর্ড তৈরি করে LinkedIn এ পোস্ট করুন',
    ],
    voiceNotes: 'Authoritative, encouraging. Stress that any background can enter Data Analytics.',
  },
  {
    id: 'skill-3',
    order: 3,
    titleBn: '৩. Video Editing and Motion Graphics',
    titleEn: '3. Video Editing & Motion Graphics',
    badge: 'Creator Economy',
    durationSeconds: 44,
    textBn: `তিন নম্বর স্কিলটি হলো Video Editing and Motion Graphics।

আমরা এখন শর্ট-ফর্ম কনটেন্টের যুগে বাস করছি। ফেইসবুক রিলস, ইউটিউব শর্টস থেকে শুরু করে ই-কমার্সের ভিডিও অ্যাড—সব জায়গাতেই ভিডিও কনটেন্টের জয়জয়কার।

তবে সাধারণ কাট-ছাট এডিটিং নয়; ভালো স্টোরিটেলিং, সাউন্ড ডিজাইন এবং Premiere Pro, After Effects বা CapCut দিয়ে আই-ক্যাচিং ভিজ্যুয়ালস তৈরি করতে পারলে এই সেক্টরে কাজের কোনো অভাব নেই। দেশীয় ব্র্যান্ডিং এজেন্সি থেকে শুরু করে গ্লোবাল রিমোট জবে এর ব্যাপক চাহিদা রয়েছে।`,
    keyTerms: ['Video Editing', 'Motion Graphics', 'Short-form content', 'Reels & Shorts', 'Premiere Pro', 'After Effects', 'CapCut', 'Sound Design'],
    bRollPrompt: 'Close up of a video editor working in Premiere Pro timeline with dynamic multi-track audio waves, fast kinetic typography popping on screen.',
    onScreenGraphics: [
      'Skill #3: Video Editing & Motion Graphics',
      'হট ট্রেন্ড: Short-Form (Reels, TikTok, Shorts)',
      'কোর শক্তি: Storytelling + Sound Design + Motion',
      'টুলস: Premiere Pro • After Effects • CapCut',
    ],
    tools: [
      { name: 'Adobe Premiere Pro', category: 'Non-Linear Editing', description: 'Industry standard video cutting and sequencing' },
      { name: 'Adobe After Effects', category: 'Motion Graphics', description: 'Kinetic typography, visual effects, and animated transitions' },
      { name: 'CapCut / CapCut Desktop', category: 'Fast Viral Editing', description: 'Speedy captioning, viral sound effects, social pacing' },
      { name: 'Audition / Sound Design', category: 'Audio Polish', description: 'Foley, risers, whooshes, atmospheric mixing' },
    ],
    marketStat: {
      growthRate: '+310%',
      remoteSalary: '$30k - $80k/yr',
      localSalary: '৳৫০,০০০ - ৳১,৮০,০০০/মাস',
      demandLevel: 'Very High',
    },
    learningSteps: [
      'প্রথমে সাউন্ড ডিজাইনের গুরুত্ব বুঝুন (whooshes, pop, bgm ducking)',
      'কাইনেটিক টাইপোগ্রাফি ও হুক এডিটিং (প্রথম ৩ সেকেন্ডের রিটেনশন টেকনিক) শিখুন',
      'জনপ্রিয় কনটেন্ট ক্রিয়েটরদের জন্য ৩টি ৬০-সেকেন্ডের নমুনা রিলস বানিয়ে সরাসরি কোল্ড পিচ দিন',
    ],
    voiceNotes: 'Punchy, lively, modern creator energy. Highlight "ভালো স্টোরিটেলিং ও সাউন্ড ডিজাইন".',
  },
  {
    id: 'skill-4',
    order: 4,
    titleBn: '৪. AI-Integrated Digital Marketing',
    titleEn: '4. AI-Integrated Digital Marketing',
    badge: 'Revenue Driver',
    durationSeconds: 32,
    textBn: `চার নম্বরে আছে AI-Integrated Digital Marketing।

এখন আর শুধু বুস্টিং বা সোশ্যাল মিডিয়া পোস্ট করা মানেই ডিজিটাল মার্কেটিং নয়। ডেটা-ড্রিভেন মার্কেটিং, Google Analytics 4, ট্র্যাকিং এবং এআই কনটেন্ট স্ট্র্যাটেজি যারা বোঝেন, ব্র্যান্ডগুলো তাদের পেছনেই বিনিয়োগ করছে।`,
    keyTerms: ['AI-Integrated Digital Marketing', 'Google Analytics 4 (GA4)', 'Data-Driven Marketing', 'Tracking & Pixels', 'AI Content Strategy'],
    bRollPrompt: 'Analytics dashboard displaying live conversion funnels, ROI multipliers, customer acquisition cost graphs with futuristic UI overlays.',
    onScreenGraphics: [
      'Skill #4: AI-Integrated Digital Marketing',
      'পুরোনো মেথড বাদ: সাধারণ বুস্টিং এখন অচল!',
      'নতুন যুগ: GA4 + Server-side Tracking + AI Strategy',
      'ব্র্যান্ডের ইনভেস্টমেন্ট: সরাসরি ROI ও গ্রোথে',
    ],
    tools: [
      { name: 'Google Analytics 4', category: 'Event Tracking', description: 'Cross-platform user journey measurement' },
      { name: 'Meta Pixel & CAPI', category: 'Conversion API', description: 'Accurate server-side tracking and attribution' },
      { name: 'AI Copywriting & Strategy', category: 'Ad Copy AI', description: 'Persona testing, high-converting ad copy iterations' },
      { name: 'Google Tag Manager', category: 'Tag Management', description: 'Advanced custom event triggers and dataLayer' },
    ],
    marketStat: {
      growthRate: '+260%',
      remoteSalary: '$35k - $70k/yr',
      localSalary: '৳৪৫,০০০ - ৳১,৪০,০০০/মাস',
      demandLevel: 'Very High',
    },
    learningSteps: [
      'শুধু বুস্টিং নয়, Google Tag Manager ও GA4 দিয়ে ট্র্যাকিং সেটআপ শিখুন',
      'এআই দিয়ে অডিয়েন্স পারসোনা রিসার্চ ও ১০টি ভিন্ন অ্যাঙ্গেলে অ্যাড কপি জেনারেট করুন',
      'ছোট ব্র্যান্ডের জন্য কনভার্সন অপটিমাইজেশন ফ্রেমওয়ার্ক বানিয়ে রেজাল্ট ডেলিভার করুন',
    ],
    voiceNotes: 'Smart, sharp business perspective. Direct emphasis on data-driven marketing.',
  },
  {
    id: 'skill-5',
    order: 5,
    titleBn: '৫. UI/UX Design',
    titleEn: '5. UI/UX Design & Product Strategy',
    badge: 'Product Craft',
    durationSeconds: 40,
    textBn: `এবং পাঁচ নম্বরটি হলো UI/UX Design।

আমাদের দেশে প্রতিদিন নতুন নতুন ওয়েবসাইট ও মোবাইল অ্যাপ তৈরি হচ্ছে। একটা অ্যাপ দেখতে কেমন হবে এবং ব্যবহারকারীর অভিজ্ঞতা কতটা সহজ হবে—সেটা ডিজাইন করাই UI/UX ডিজাইনারের কাজ।

Figma বা Adobe XD দিয়ে প্রোটোটাইপিং ও ইউজার রিসার্চ শিখতে পারলে স্থানীয় স্টার্টআপ এবং আন্তর্জাতিক ফ্রিল্যান্সিং দুই জায়গাতেই দারুণ স্কোপ তৈরি হয়।`,
    keyTerms: ['UI/UX Design', 'User Experience', 'Figma', 'Adobe XD', 'Prototyping', 'User Research', 'Startups & Freelancing'],
    bRollPrompt: 'Close up of a sleek MacBook display designing a dark-mode mobile banking app in Figma with smooth component auto-layout and interactive prototype wires.',
    onScreenGraphics: [
      'Skill #5: UI/UX Design',
      'কোর কাজ: লুক অ্যান্ড ফিল + ব্যবহারকারীর সহজ অভিজ্ঞতা',
      'টুলস: Figma • Adobe XD • FigJam',
      'মার্কেট: দেশীয় টেক স্টার্টআপ + গ্লোবাল রিমোট জব',
    ],
    tools: [
      { name: 'Figma', category: 'Design & Prototype', description: 'Collaborative vector design, design systems, interactive prototypes' },
      { name: 'FigJam / Miro', category: 'User Flow & Research', description: 'Information architecture, empathy mapping, wireframing' },
      { name: 'Design Systems', category: 'Scalability', description: 'Tokens, typography scale, responsive components' },
      { name: 'User Testing Tools', category: 'Validation', description: 'Usability testing, heatmaps, task success rate' },
    ],
    marketStat: {
      growthRate: '+290%',
      remoteSalary: '$40k - $85k/yr',
      localSalary: '৳৬০,০০০ - ৳১,৬৫,০০০/মাস',
      demandLevel: 'Very High',
    },
    learningSteps: [
      'Figma এর Auto-Layout, Components এবং Variants ভালোভাবে আয়ত্ত করুন',
      'অ্যাপ বা ওয়েবসাইটের ইউজার সাইকোলজি ও নেভিগেশন রিসার্চের ওপর জোর দিন',
      'একটি দেশীয় সমস্যার সমাধান করে (যেমন: রাইড শেয়ারিং বা টিউশন ফাইন্ডার) সম্পূর্ণ কেস স্টাডি Behance এ আপলোড করুন',
    ],
    voiceNotes: 'Polished, creative, inspiring. Clear pronunciation of UI/UX and Figma.',
  },
  {
    id: 'outro',
    order: 6,
    titleBn: 'উপসংহার: প্রতিদিন ১-২ ঘণ্টার অ্যাকশন প্ল্যান ও কমেন্ট CTA',
    titleEn: 'Outro & Action Plan',
    badge: 'Call to Action',
    durationSeconds: 35,
    textBn: `মনে রাখবেন, একসাথে সব স্কিল শেখার দরকার নেই। এই ৫টি স্কিলের মধ্যে যেটা আপনার আগ্রহের সাথে সবচেয়ে বেশি মেলে, সেটা বেছে নিন এবং প্রতিদিন অন্তত ১-২ ঘণ্টা সময় দিন।

আপনি বর্তমানে কোনো স্কিল শিখছেন কি না বা কোনটি শেখার কথা ভাবছেন, কমেন্ট বক্সে জানাতে পারেন। আর ভিডিওটি দরকারী মনে হলে লাইক ও শেয়ার করে বন্ধুদের দেখার সুযোগ করে দিন!

দেখা হচ্ছে পরের ভিডিওতে, ধন্যবাদ!`,
    keyTerms: ['1-2 hours daily', 'Action Plan', 'Comment CTA', 'Like & Share', 'Next Video'],
    bRollPrompt: 'Inspirational shot of a young professional closing a notebook, smiling with focused confidence, with animated subscribe and like buttons floating gently.',
    onScreenGraphics: [
      'রুল অফ থাম্ব: একসাথে সব নয়! যেকোনো ১টি বেছে নিন',
      'দৈনিক কমিটমেন্ট: প্রতিদিন ১-২ ঘণ্টা সময় দিন',
      'প্রশ্ন: আপনি বর্তমানে কোন স্কিলটি শিখছেন?',
      'লাইক ও শেয়ার করে বন্ধুদের জানিয়ে দিন!',
    ],
    tools: [
      { name: 'Notion / Habit Tracker', category: 'Discipline', description: 'Tracking daily 1-2 hours learning sprints' },
      { name: 'Portfolio Showcase', category: 'Visibility', description: 'Building in public on LinkedIn and YouTube' },
    ],
    marketStat: {
      growthRate: '100% Personal ROI',
      remoteSalary: 'Sky is the limit',
      localSalary: 'Consistent Growth',
      demandLevel: 'Critical',
    },
    learningSteps: [
      'আজকেই যেকোনো ১টি স্কিল চূড়ান্তভাবে নির্বাচন করুন',
      'ক্যালেন্ডারে প্রতিদিনের জন্য নির্দিষ্ট ১-২ ঘণ্টার টাইম-স্লট ব্লক করুন',
      'কমেন্টে আপনার প্রিয় স্কিলটি লিখে নিজের কমিটমেন্ট পাকা করুন',
    ],
    voiceNotes: 'Warm, encouraging, inspiring finale. Friendly outro smile.',
  },
];

export const SKILL_QUIZ_QUESTIONS = [
  {
    id: 'background',
    questionBn: 'আপনার বর্তমান পটভূমি বা ব্যাকগ্রাউন্ড কোনটি?',
    options: [
      { value: 'student', labelBn: 'আমি কলেজ বা বিশ্ববিদ্যালয়ের শিক্ষার্থী (Student)' },
      { value: 'creative', labelBn: 'ক্রিয়েটিভ বা ভিজ্যুয়াল কাজে আমার সহজাত আগ্রহ বেশি' },
      { value: 'tech', labelBn: 'আইটি, কোডিং বা টেকনোলজি ও লজিক্যাল ফিল্ড' },
      { value: 'business', labelBn: 'বিজনেস, ম্যানেজমেন্ট বা মার্কেটিং ব্যাকগ্রাউন্ড' },
    ],
  },
  {
    id: 'interest',
    questionBn: 'কোন ধরনের কাজে আপনি সবচেয়ে বেশি আনন্দ ও উত্তেজনা পান?',
    options: [
      { value: 'automation', labelBn: 'এআই ও অটোমেশন দিয়ে কোনো কাজ নিমিষে স্বয়ংক্রিয় করা' },
      { value: 'data', labelBn: 'চার্ট, সংখ্যা ও ডেটা অ্যানালিসিস করে সঠিক সিদ্ধান্ত নেওয়া' },
      { value: 'visual', labelBn: 'ভিডিও এডিটিং, মোশন গ্রাফিক্স ও সোশ্যাল রিলস তৈরি' },
      { value: 'growth', labelBn: 'অ্যাডভার্টাইজিং, সেলস গ্রোথ ও ডেটা-চালিত মার্কেটিং' },
      { value: 'design', labelBn: 'ওয়েবসাইট ও অ্যাপের ইউজার ফ্রেন্ডলি ডিজাইন করা' },
    ],
  },
  {
    id: 'mathComfort',
    questionBn: 'সংখ্যা, লজিক ও ডেটা নিয়ে কাজ করতে আপনার কেমন লাগে?',
    options: [
      { value: 'high', labelBn: 'খুব ভালো লাগে, ডেটা ও লজিক্যাল অ্যানালাইসিস আমি পছন্দ করি' },
      { value: 'low', labelBn: 'আমি ভিজ্যুয়াল, আর্ট এবং স্টোরিটেলিং পছন্দ করি বেশি' },
    ],
  },
  {
    id: 'creativityPreference',
    questionBn: 'আপনার ক্রিয়েটিভিটির ধরন কোনটি বেশি প্রকাশ পায়?',
    options: [
      { value: 'visual', labelBn: 'চোখে দেখার মতো সুন্দর আর্ট, কালার, মোশন ও ডিজাইন' },
      { value: 'logical', labelBn: 'সিস্টেম ডিজাইন, প্রসেস অটোমেশন ও স্মার্ট স্ট্র্যাটেজি' },
    ],
  },
];
