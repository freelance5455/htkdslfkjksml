import goldenLayout1Raw from './golden_stage_01.json';
import goldenLayout2Raw from './golden_stage_02.json';
import goldenLayout3Raw from './golden_stage_03.json';
import goldenLayout4Raw from './golden_stage_04.json';
import goldenLayout5Raw from './golden_stage_05.json';
import goldenLayout6Raw from './golden_stage_06.json';
import goldenLayout7Raw from './golden_stage_07.json';
import goldenLayout8Raw from './golden_stage_08.json';
import goldenLayout9Raw from './golden_stage_09.json';
import goldenLayout10Raw from './golden_stage_10.json';
import goldenLayout11Raw from './golden_stage_11.json';
import goldenLayout12Raw from './golden_stage_12.json';
import goldenLayout13Raw from './golden_stage_13.json';
import goldenLayout14Raw from './golden_stage_14.json';
import goldenLayout15Raw from './golden_stage_15.json';
import goldenLayout16Raw from './golden_stage_16.json';
import goldenLayout17Raw from './golden_stage_17.json';
import goldenLayout18Raw from './golden_stage_18.json';
import goldenLayout19Raw from './golden_stage_19.json';
import goldenLayout20Raw from './golden_stage_20.json';
import goldenLayout21Raw from './golden_stage_21.json';
import goldenLayout22Raw from './golden_stage_22.json';
import goldenLayout23Raw from './golden_stage_23.json';
import goldenLayout24Raw from './golden_stage_24.json';
import goldenLayout25Raw from './golden_stage_25.json';
import goldenLayout26Raw from './golden_stage_26.json';
import goldenLayout27Raw from './golden_stage_27.json';
import goldenLayout28Raw from './golden_stage_28.json';
import goldenLayout29Raw from './golden_stage_29.json';
import goldenLayout30Raw from './golden_stage_30.json';
import goldenLayout31Raw from './golden_stage_31.json';
import goldenLayout32Raw from './golden_stage_32.json';
import goldenLayout33Raw from './golden_stage_33.json';
import goldenLayout34Raw from './golden_stage_34.json';
import goldenLayout35Raw from './golden_stage_35.json';
import goldenLayout36Raw from './golden_stage_36.json';
import goldenLayout37Raw from './golden_stage_37.json';
import goldenLayout38Raw from './golden_stage_38.json';
import goldenLayout39Raw from './golden_stage_39.json';
import goldenLayout40Raw from './golden_stage_40.json';
import goldenLayout41Raw from './golden_stage_41.json';
import goldenLayout42Raw from './golden_stage_42.json';
import goldenLayout43Raw from './golden_stage_43.json';
import goldenLayout44Raw from './golden_stage_44.json';
import goldenLayout45Raw from './golden_stage_45.json';
import goldenLayout46Raw from './golden_stage_46.json';
import goldenLayout47Raw from './golden_stage_47.json';
import goldenLayout48Raw from './golden_stage_48.json';
import goldenLayout49Raw from './golden_stage_49.json';
import goldenLayout50Raw from './golden_stage_50.json';
import { CrosswordLayout } from '../types/crosswordLayout';
import { Stage } from '../types/crossword';
import { validateCrosswordLayout } from '../engine/CrosswordValidator';

export const goldenLayout: CrosswordLayout = goldenLayout1Raw as unknown as CrosswordLayout;
export const goldenLayout2: CrosswordLayout = goldenLayout2Raw as unknown as CrosswordLayout;
export const goldenLayout3: CrosswordLayout = goldenLayout3Raw as unknown as CrosswordLayout;
export const goldenLayout4: CrosswordLayout = goldenLayout4Raw as unknown as CrosswordLayout;
export const goldenLayout5: CrosswordLayout = goldenLayout5Raw as unknown as CrosswordLayout;
export const goldenLayout6: CrosswordLayout = goldenLayout6Raw as unknown as CrosswordLayout;
export const goldenLayout7: CrosswordLayout = goldenLayout7Raw as unknown as CrosswordLayout;
export const goldenLayout8: CrosswordLayout = goldenLayout8Raw as unknown as CrosswordLayout;
export const goldenLayout9: CrosswordLayout = goldenLayout9Raw as unknown as CrosswordLayout;
export const goldenLayout10: CrosswordLayout = goldenLayout10Raw as unknown as CrosswordLayout;
export const goldenLayout11: CrosswordLayout = goldenLayout11Raw as unknown as CrosswordLayout;
export const goldenLayout12: CrosswordLayout = goldenLayout12Raw as unknown as CrosswordLayout;
export const goldenLayout13: CrosswordLayout = goldenLayout13Raw as unknown as CrosswordLayout;
export const goldenLayout14: CrosswordLayout = goldenLayout14Raw as unknown as CrosswordLayout;
export const goldenLayout15: CrosswordLayout = goldenLayout15Raw as unknown as CrosswordLayout;
export const goldenLayout16: CrosswordLayout = goldenLayout16Raw as unknown as CrosswordLayout;
export const goldenLayout17: CrosswordLayout = goldenLayout17Raw as unknown as CrosswordLayout;
export const goldenLayout18: CrosswordLayout = goldenLayout18Raw as unknown as CrosswordLayout;
export const goldenLayout19: CrosswordLayout = goldenLayout19Raw as unknown as CrosswordLayout;
export const goldenLayout20: CrosswordLayout = goldenLayout20Raw as unknown as CrosswordLayout;
export const goldenLayout21: CrosswordLayout = goldenLayout21Raw as unknown as CrosswordLayout;
export const goldenLayout22: CrosswordLayout = goldenLayout22Raw as unknown as CrosswordLayout;
export const goldenLayout23: CrosswordLayout = goldenLayout23Raw as unknown as CrosswordLayout;
export const goldenLayout24: CrosswordLayout = goldenLayout24Raw as unknown as CrosswordLayout;
export const goldenLayout25: CrosswordLayout = goldenLayout25Raw as unknown as CrosswordLayout;
export const goldenLayout26: CrosswordLayout = goldenLayout26Raw as unknown as CrosswordLayout;
export const goldenLayout27: CrosswordLayout = goldenLayout27Raw as unknown as CrosswordLayout;
export const goldenLayout28: CrosswordLayout = goldenLayout28Raw as unknown as CrosswordLayout;
export const goldenLayout29: CrosswordLayout = goldenLayout29Raw as unknown as CrosswordLayout;
export const goldenLayout30: CrosswordLayout = goldenLayout30Raw as unknown as CrosswordLayout;
export const goldenLayout31: CrosswordLayout = goldenLayout31Raw as unknown as CrosswordLayout;
export const goldenLayout32: CrosswordLayout = goldenLayout32Raw as unknown as CrosswordLayout;
export const goldenLayout33: CrosswordLayout = goldenLayout33Raw as unknown as CrosswordLayout;
export const goldenLayout34: CrosswordLayout = goldenLayout34Raw as unknown as CrosswordLayout;
export const goldenLayout35: CrosswordLayout = goldenLayout35Raw as unknown as CrosswordLayout;
export const goldenLayout36: CrosswordLayout = goldenLayout36Raw as unknown as CrosswordLayout;
export const goldenLayout37: CrosswordLayout = goldenLayout37Raw as unknown as CrosswordLayout;
export const goldenLayout38: CrosswordLayout = goldenLayout38Raw as unknown as CrosswordLayout;
export const goldenLayout39: CrosswordLayout = goldenLayout39Raw as unknown as CrosswordLayout;
export const goldenLayout40: CrosswordLayout = goldenLayout40Raw as unknown as CrosswordLayout;
export const goldenLayout41: CrosswordLayout = goldenLayout41Raw as unknown as CrosswordLayout;
export const goldenLayout42: CrosswordLayout = goldenLayout42Raw as unknown as CrosswordLayout;
export const goldenLayout43: CrosswordLayout = goldenLayout43Raw as unknown as CrosswordLayout;
export const goldenLayout44: CrosswordLayout = goldenLayout44Raw as unknown as CrosswordLayout;
export const goldenLayout45: CrosswordLayout = goldenLayout45Raw as unknown as CrosswordLayout;
export const goldenLayout46: CrosswordLayout = goldenLayout46Raw as unknown as CrosswordLayout;
export const goldenLayout47: CrosswordLayout = goldenLayout47Raw as unknown as CrosswordLayout;
export const goldenLayout48: CrosswordLayout = goldenLayout48Raw as unknown as CrosswordLayout;
export const goldenLayout49: CrosswordLayout = goldenLayout49Raw as unknown as CrosswordLayout;
export const goldenLayout50: CrosswordLayout = goldenLayout50Raw as unknown as CrosswordLayout;

export const goldenValidation = validateCrosswordLayout(goldenLayout);
export const goldenValidation2 = validateCrosswordLayout(goldenLayout2);
export const goldenValidation3 = validateCrosswordLayout(goldenLayout3);
export const goldenValidation4 = validateCrosswordLayout(goldenLayout4);
export const goldenValidation5 = validateCrosswordLayout(goldenLayout5);
export const goldenValidation6 = validateCrosswordLayout(goldenLayout6);
export const goldenValidation7 = validateCrosswordLayout(goldenLayout7);
export const goldenValidation8 = validateCrosswordLayout(goldenLayout8);
export const goldenValidation9 = validateCrosswordLayout(goldenLayout9);
export const goldenValidation10 = validateCrosswordLayout(goldenLayout10);
export const goldenValidation11 = validateCrosswordLayout(goldenLayout11);
export const goldenValidation12 = validateCrosswordLayout(goldenLayout12);
export const goldenValidation13 = validateCrosswordLayout(goldenLayout13);
export const goldenValidation14 = validateCrosswordLayout(goldenLayout14);
export const goldenValidation15 = validateCrosswordLayout(goldenLayout15);
export const goldenValidation16 = validateCrosswordLayout(goldenLayout16);
export const goldenValidation17 = validateCrosswordLayout(goldenLayout17);
export const goldenValidation18 = validateCrosswordLayout(goldenLayout18);
export const goldenValidation19 = validateCrosswordLayout(goldenLayout19);
export const goldenValidation20 = validateCrosswordLayout(goldenLayout20);
export const goldenValidation21 = validateCrosswordLayout(goldenLayout21);
export const goldenValidation22 = validateCrosswordLayout(goldenLayout22);
export const goldenValidation23 = validateCrosswordLayout(goldenLayout23);
export const goldenValidation24 = validateCrosswordLayout(goldenLayout24);
export const goldenValidation25 = validateCrosswordLayout(goldenLayout25);
export const goldenValidation26 = validateCrosswordLayout(goldenLayout26);
export const goldenValidation27 = validateCrosswordLayout(goldenLayout27);
export const goldenValidation28 = validateCrosswordLayout(goldenLayout28);
export const goldenValidation29 = validateCrosswordLayout(goldenLayout29);
export const goldenValidation30 = validateCrosswordLayout(goldenLayout30);
export const goldenValidation31 = validateCrosswordLayout(goldenLayout31);
export const goldenValidation32 = validateCrosswordLayout(goldenLayout32);
export const goldenValidation33 = validateCrosswordLayout(goldenLayout33);
export const goldenValidation34 = validateCrosswordLayout(goldenLayout34);
export const goldenValidation35 = validateCrosswordLayout(goldenLayout35);
export const goldenValidation36 = validateCrosswordLayout(goldenLayout36);
export const goldenValidation37 = validateCrosswordLayout(goldenLayout37);
export const goldenValidation38 = validateCrosswordLayout(goldenLayout38);
export const goldenValidation39 = validateCrosswordLayout(goldenLayout39);
export const goldenValidation40 = validateCrosswordLayout(goldenLayout40);
export const goldenValidation41 = validateCrosswordLayout(goldenLayout41);
export const goldenValidation42 = validateCrosswordLayout(goldenLayout42);
export const goldenValidation43 = validateCrosswordLayout(goldenLayout43);
export const goldenValidation44 = validateCrosswordLayout(goldenLayout44);
export const goldenValidation45 = validateCrosswordLayout(goldenLayout45);
export const goldenValidation46 = validateCrosswordLayout(goldenLayout46);
export const goldenValidation47 = validateCrosswordLayout(goldenLayout47);
export const goldenValidation48 = validateCrosswordLayout(goldenLayout48);
export const goldenValidation49 = validateCrosswordLayout(goldenLayout49);
export const goldenValidation50 = validateCrosswordLayout(goldenLayout50);

export function getGoldenStage1(): Stage {
  return {
    id: 1,
    title: 'المرحلة الأولى',
    gridSize: {
      rows: goldenLayout.gridRows,
      cols: goldenLayout.gridColumns
    },
    blockedCells: goldenLayout.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage2(): Stage {
  return {
    id: 2,
    title: 'المرحلة الثانية',
    gridSize: {
      rows: goldenLayout2.gridRows,
      cols: goldenLayout2.gridColumns
    },
    blockedCells: goldenLayout2.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout2.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage3(): Stage {
  return {
    id: 3,
    title: 'المرحلة الثالثة',
    gridSize: {
      rows: goldenLayout3.gridRows,
      cols: goldenLayout3.gridColumns
    },
    blockedCells: goldenLayout3.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout3.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage4(): Stage {
  return {
    id: 4,
    title: 'المرحلة الرابعة',
    gridSize: {
      rows: goldenLayout4.gridRows,
      cols: goldenLayout4.gridColumns
    },
    blockedCells: goldenLayout4.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout4.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage5(): Stage {
  return {
    id: 5,
    title: 'المرحلة الخامسة',
    gridSize: {
      rows: goldenLayout5.gridRows,
      cols: goldenLayout5.gridColumns
    },
    blockedCells: goldenLayout5.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout5.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage6(): Stage {
  return {
    id: 6,
    title: 'المرحلة السادسة',
    gridSize: {
      rows: goldenLayout6.gridRows,
      cols: goldenLayout6.gridColumns
    },
    blockedCells: goldenLayout6.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout6.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage7(): Stage {
  return {
    id: 7,
    title: 'المرحلة السابعة',
    gridSize: {
      rows: goldenLayout7.gridRows,
      cols: goldenLayout7.gridColumns
    },
    blockedCells: goldenLayout7.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout7.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage8(): Stage {
  return {
    id: 8,
    title: 'المرحلة الثامنة',
    gridSize: {
      rows: goldenLayout8.gridRows,
      cols: goldenLayout8.gridColumns
    },
    blockedCells: goldenLayout8.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout8.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage9(): Stage {
  return {
    id: 9,
    title: 'المرحلة التاسعة',
    gridSize: {
      rows: goldenLayout9.gridRows,
      cols: goldenLayout9.gridColumns
    },
    blockedCells: goldenLayout9.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout9.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage10(): Stage {
  return {
    id: 10,
    title: 'المرحلة العاشرة',
    gridSize: {
      rows: goldenLayout10.gridRows,
      cols: goldenLayout10.gridColumns
    },
    blockedCells: goldenLayout10.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout10.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage11(): Stage {
  return {
    id: 11,
    title: 'المرحلة الحادية عشرة',
    gridSize: {
      rows: goldenLayout11.gridRows,
      cols: goldenLayout11.gridColumns
    },
    blockedCells: goldenLayout11.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout11.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage12(): Stage {
  return {
    id: 12,
    title: 'المرحلة الثانية عشرة',
    gridSize: {
      rows: goldenLayout12.gridRows,
      cols: goldenLayout12.gridColumns
    },
    blockedCells: goldenLayout12.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout12.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage13(): Stage {
  return {
    id: 13,
    title: 'المرحلة الثالثة عشرة',
    gridSize: {
      rows: goldenLayout13.gridRows,
      cols: goldenLayout13.gridColumns
    },
    blockedCells: goldenLayout13.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout13.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage14(): Stage {
  return {
    id: 14,
    title: 'المرحلة الرابعة عشرة',
    gridSize: {
      rows: goldenLayout14.gridRows,
      cols: goldenLayout14.gridColumns
    },
    blockedCells: goldenLayout14.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout14.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage15(): Stage {
  return {
    id: 15,
    title: 'المرحلة الخامسة عشرة',
    gridSize: {
      rows: goldenLayout15.gridRows,
      cols: goldenLayout15.gridColumns
    },
    blockedCells: goldenLayout15.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout15.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage16(): Stage {
  return {
    id: 16,
    title: 'المرحلة السادسة عشرة',
    gridSize: {
      rows: goldenLayout16.gridRows,
      cols: goldenLayout16.gridColumns
    },
    blockedCells: goldenLayout16.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout16.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage17(): Stage {
  return {
    id: 17,
    title: 'المرحلة السابعة عشرة',
    gridSize: {
      rows: goldenLayout17.gridRows,
      cols: goldenLayout17.gridColumns
    },
    blockedCells: goldenLayout17.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout17.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage18(): Stage {
  return {
    id: 18,
    title: 'المرحلة الثامنة عشرة',
    gridSize: {
      rows: goldenLayout18.gridRows,
      cols: goldenLayout18.gridColumns
    },
    blockedCells: goldenLayout18.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout18.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage19(): Stage {
  return {
    id: 19,
    title: 'المرحلة التاسعة عشرة',
    gridSize: {
      rows: goldenLayout19.gridRows,
      cols: goldenLayout19.gridColumns
    },
    blockedCells: goldenLayout19.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout19.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage20(): Stage {
  return {
    id: 20,
    title: 'المرحلة العشرون',
    gridSize: {
      rows: goldenLayout20.gridRows,
      cols: goldenLayout20.gridColumns
    },
    blockedCells: goldenLayout20.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout20.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage21(): Stage {
  return {
    id: 21,
    title: 'المرحلة الحادية والعشرون',
    gridSize: {
      rows: goldenLayout21.gridRows,
      cols: goldenLayout21.gridColumns
    },
    blockedCells: goldenLayout21.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout21.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage22(): Stage {
  return {
    id: 22,
    title: 'المرحلة الثانية والعشرون',
    gridSize: {
      rows: goldenLayout22.gridRows,
      cols: goldenLayout22.gridColumns
    },
    blockedCells: goldenLayout22.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout22.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage23(): Stage {
  return {
    id: 23,
    title: 'المرحلة الثالثة والعشرون',
    gridSize: {
      rows: goldenLayout23.gridRows,
      cols: goldenLayout23.gridColumns
    },
    blockedCells: goldenLayout23.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout23.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage24(): Stage {
  return {
    id: 24,
    title: 'المرحلة الرابعة والعشرون',
    gridSize: {
      rows: goldenLayout24.gridRows,
      cols: goldenLayout24.gridColumns
    },
    blockedCells: goldenLayout24.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout24.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage25(): Stage {
  return {
    id: 25,
    title: 'المرحلة الخامسة والعشرون',
    gridSize: {
      rows: goldenLayout25.gridRows,
      cols: goldenLayout25.gridColumns
    },
    blockedCells: goldenLayout25.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout25.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage26(): Stage {
  return {
    id: 26,
    title: 'المرحلة السادسة والعشرون',
    gridSize: {
      rows: goldenLayout26.gridRows,
      cols: goldenLayout26.gridColumns
    },
    blockedCells: goldenLayout26.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout26.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage27(): Stage {
  return {
    id: 27,
    title: 'المرحلة السابعة والعشرون',
    gridSize: {
      rows: goldenLayout27.gridRows,
      cols: goldenLayout27.gridColumns
    },
    blockedCells: goldenLayout27.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout27.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage28(): Stage {
  return {
    id: 28,
    title: 'المرحلة الثامنة والعشرون',
    gridSize: {
      rows: goldenLayout28.gridRows,
      cols: goldenLayout28.gridColumns
    },
    blockedCells: goldenLayout28.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout28.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage29(): Stage {
  return {
    id: 29,
    title: 'المرحلة التاسعة والعشرون',
    gridSize: {
      rows: goldenLayout29.gridRows,
      cols: goldenLayout29.gridColumns
    },
    blockedCells: goldenLayout29.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout29.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage30(): Stage {
  return {
    id: 30,
    title: 'المرحلة الثلاثون',
    gridSize: {
      rows: goldenLayout30.gridRows,
      cols: goldenLayout30.gridColumns
    },
    blockedCells: goldenLayout30.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout30.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage31(): Stage {
  return {
    id: 31,
    title: 'المرحلة الحادية والثلاثون',
    gridSize: {
      rows: goldenLayout31.gridRows,
      cols: goldenLayout31.gridColumns
    },
    blockedCells: goldenLayout31.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout31.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage32(): Stage {
  return {
    id: 32,
    title: 'المرحلة الثانية والثلاثون',
    gridSize: {
      rows: goldenLayout32.gridRows,
      cols: goldenLayout32.gridColumns
    },
    blockedCells: goldenLayout32.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout32.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage33(): Stage {
  return {
    id: 33,
    title: 'المرحلة الثالثة والثلاثون',
    gridSize: {
      rows: goldenLayout33.gridRows,
      cols: goldenLayout33.gridColumns
    },
    blockedCells: goldenLayout33.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout33.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage34(): Stage {
  return {
    id: 34,
    title: 'المرحلة الرابعة والثلاثون',
    gridSize: {
      rows: goldenLayout34.gridRows,
      cols: goldenLayout34.gridColumns
    },
    blockedCells: goldenLayout34.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout34.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage35(): Stage {
  return {
    id: 35,
    title: 'المرحلة الخامسة والثلاثون',
    gridSize: {
      rows: goldenLayout35.gridRows,
      cols: goldenLayout35.gridColumns
    },
    blockedCells: goldenLayout35.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout35.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage36(): Stage {
  return {
    id: 36,
    title: 'المرحلة السادسة والثلاثون',
    gridSize: {
      rows: goldenLayout36.gridRows,
      cols: goldenLayout36.gridColumns
    },
    blockedCells: goldenLayout36.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout36.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage37(): Stage {
  return {
    id: 37,
    title: 'المرحلة السابعة والثلاثون',
    gridSize: {
      rows: goldenLayout37.gridRows,
      cols: goldenLayout37.gridColumns
    },
    blockedCells: goldenLayout37.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout37.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage38(): Stage {
  return {
    id: 38,
    title: 'المرحلة الثامنة والثلاثون',
    gridSize: {
      rows: goldenLayout38.gridRows,
      cols: goldenLayout38.gridColumns
    },
    blockedCells: goldenLayout38.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout38.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage39(): Stage {
  return {
    id: 39,
    title: 'المرحلة التاسعة والثلاثون',
    gridSize: {
      rows: goldenLayout39.gridRows,
      cols: goldenLayout39.gridColumns
    },
    blockedCells: goldenLayout39.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout39.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage40(): Stage {
  return {
    id: 40,
    title: 'المرحلة الأربعون',
    gridSize: {
      rows: goldenLayout40.gridRows,
      cols: goldenLayout40.gridColumns
    },
    blockedCells: goldenLayout40.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout40.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage41(): Stage {
  return {
    id: 41,
    title: 'المرحلة الحادية والأربعون',
    gridSize: {
      rows: goldenLayout41.gridRows,
      cols: goldenLayout41.gridColumns
    },
    blockedCells: goldenLayout41.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout41.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage42(): Stage {
  return {
    id: 42,
    title: 'المرحلة الثانية والأربعون',
    gridSize: {
      rows: goldenLayout42.gridRows,
      cols: goldenLayout42.gridColumns
    },
    blockedCells: goldenLayout42.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout42.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage43(): Stage {
  return {
    id: 43,
    title: 'المرحلة الثالثة والأربعون',
    gridSize: {
      rows: goldenLayout43.gridRows,
      cols: goldenLayout43.gridColumns
    },
    blockedCells: goldenLayout43.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout43.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage44(): Stage {
  return {
    id: 44,
    title: 'المرحلة الرابعة والأربعون',
    gridSize: {
      rows: goldenLayout44.gridRows,
      cols: goldenLayout44.gridColumns
    },
    blockedCells: goldenLayout44.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout44.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage45(): Stage {
  return {
    id: 45,
    title: 'المرحلة الخامسة والأربعون',
    gridSize: {
      rows: goldenLayout45.gridRows,
      cols: goldenLayout45.gridColumns
    },
    blockedCells: goldenLayout45.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout45.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage46(): Stage {
  return {
    id: 46,
    title: 'المرحلة السادسة والأربعون',
    gridSize: {
      rows: goldenLayout46.gridRows,
      cols: goldenLayout46.gridColumns
    },
    blockedCells: goldenLayout46.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout46.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage47(): Stage {
  return {
    id: 47,
    title: 'المرحلة السابعة والأربعون',
    gridSize: {
      rows: goldenLayout47.gridRows,
      cols: goldenLayout47.gridColumns
    },
    blockedCells: goldenLayout47.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout47.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage48(): Stage {
  return {
    id: 48,
    title: 'المرحلة الثامنة والأربعون',
    gridSize: {
      rows: goldenLayout48.gridRows,
      cols: goldenLayout48.gridColumns
    },
    blockedCells: goldenLayout48.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout48.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage49(): Stage {
  return {
    id: 49,
    title: 'المرحلة التاسعة والأربعون',
    gridSize: {
      rows: goldenLayout49.gridRows,
      cols: goldenLayout49.gridColumns
    },
    blockedCells: goldenLayout49.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout49.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}

export function getGoldenStage50(): Stage {
  return {
    id: 50,
    title: 'المرحلة الخمسون والأخيرة',
    gridSize: {
      rows: goldenLayout50.gridRows,
      cols: goldenLayout50.gridColumns
    },
    blockedCells: goldenLayout50.blackCells.map((bc) => ({ row: bc.row, col: bc.col })),
    questions: goldenLayout50.words.map((w) => ({
      id: w.id,
      number: w.number,
      direction: w.direction === 'across' ? 'horizontal' : 'vertical',
      clue: w.clue,
      answer: w.answer,
      startPos: { row: w.startRow, col: w.startColumn },
      length: w.length,
      reversed: w.reversed
    }))
  };
}





