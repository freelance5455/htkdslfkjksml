export interface UXStep {
  stepNumber: number;
  screenName: string;
  userAction: string;
  systemResponse: string;
  uiElements: string[];
  edgeCaseOrTip?: string;
}

export interface UXFlow {
  id: string;
  number: string;
  title: string;
  goal: string;
  trigger: string;
  steps: UXStep[];
}

export const UX_FLOWS: UXFlow[] = [
  {
    id: 'registration',
    number: '01',
    title: 'Registration Flow',
    goal: 'Create a verified student account with zero friction under 30 seconds.',
    trigger: 'User opens PoketSafe for the first time.',
    steps: [
      {
        stepNumber: 1,
        screenName: 'Welcome / Splash Screen',
        userAction: 'Views brand value proposition ("Know what is truly safe to spend"). Taps "Get Started" or "Continue with Google".',
        systemResponse: 'Presents OAuth consent screen or standard email signup modal.',
        uiElements: ['Value proposition carousel', 'One-Tap Google Sign-In', 'Email signup button', 'Terms & Privacy link']
      },
      {
        stepNumber: 2,
        screenName: 'Account Credentials',
        userAction: 'Enters student email (.edu.my / university email), creates password, or confirms Google SSO profile.',
        systemResponse: 'Validates email format; sends verification token in background; generates student profile container.',
        uiElements: ['Email field with .edu detection badge', 'Password input with strength meter', 'Continue CTA'],
        edgeCaseOrTip: 'Non-university email allowed; university email unlocks campus-specific presets (hostels, cafeterias).'
      },
      {
        stepNumber: 3,
        screenName: 'Account Verified & Transition',
        userAction: 'Taps confirmation link / auto-proceeds from SSO.',
        systemResponse: 'Transitions seamlessly into Flow 2 (First Setup Wizard) without dropping user intent.',
        uiElements: ['Success animation checkmark', 'Auto-route loader (1.5s)']
      }
    ]
  },
  {
    id: 'first-setup',
    number: '02',
    title: 'First Setup (Onboarding Wizard)',
    goal: 'Anchor the student mental model from gross balance to net safe daily runway.',
    trigger: 'First login after registration.',
    steps: [
      {
        stepNumber: 1,
        screenName: 'Persona Archetype Selector',
        userAction: 'Selects funding category: PTPTN Loan, Scholarship/Sponsorship, Working Student, or Allowance.',
        systemResponse: 'Pre-configures currency (MYR/RM), baseline meal benchmarks, and semester duration defaults.',
        uiElements: ['4 selectable card tiles with student avatars', 'Currency picker dropdown (MYR, USD, SGD, GBP)']
      },
      {
        stepNumber: 2,
        screenName: 'Initial Cash & Disbursement Date',
        userAction: 'Enters current gross bank balance (e.g., RM 3,250) and selects date of next funding inflow (e.g., 68 days away).',
        systemResponse: 'Calculates active day countdown and stores primary cash baseline.',
        uiElements: ['Large numeric keypad input for balance', 'Visual calendar picker for next disbursement date', 'Days-remaining counter chip']
      },
      {
        stepNumber: 3,
        screenName: 'Quick Commitments Prompt',
        userAction: 'Selects 1–2 typical student commitments (e.g., Room Rent RM 450, Mobile Data RM 38) or taps "Skip for now".',
        systemResponse: 'Pre-quarantines fixed bills and calculates the initial Safe-to-Spend Balance.',
        uiElements: ['Pre-populated chips (Hostel, Mobile Data, Laptop EMI)', 'Amount input', '"Skip to Dashboard" secondary link']
      },
      {
        stepNumber: 4,
        screenName: 'The "Aha!" Reveal Screen',
        userAction: 'Views computed Safe Balance and Daily Safe Limit.',
        systemResponse: 'Highlights the disparity: "Your bank has RM 3,250, but your Safe Balance is RM 2,762 (RM 40.61/day). You are protected!"',
        uiElements: ['Comparison visual card (Gross vs Safe)', 'Primary CTA: "Enter My PoketSafe"']
      }
    ]
  },
  {
    id: 'add-income',
    number: '03',
    title: 'Add Income Flow',
    goal: 'Log lump-sum loans, family allowances, or part-time earnings and update runway.',
    trigger: 'User receives PTPTN loan tranche, parent allowance transfer, or side-job pay.',
    steps: [
      {
        stepNumber: 1,
        screenName: 'Dashboard or Balance Card',
        userAction: 'Taps "+ Add Inflow" or "Edit Balance" action on the Safe Balance hero card.',
        systemResponse: 'Opens bottom sheet drawer "Record New Income".',
        uiElements: ['Quick action trigger button', 'Modal backdrop blur']
      },
      {
        stepNumber: 2,
        screenName: 'Income Entry Sheet',
        userAction: 'Enters amount (e.g. RM 3,500), selects source (PTPTN, JPA Scholarship, Parents, Freelance), and sets recurrence.',
        systemResponse: 'Updates next disbursement target date and days remaining.',
        uiElements: ['Numeric currency keypad', 'Category chips (PTPTN, Scholarship, Part-Time, Allowance)', 'Date selector for next expected tranche']
      },
      {
        stepNumber: 3,
        screenName: 'Runway Recalculation Confirmation',
        userAction: 'Taps "Confirm Inflow".',
        systemResponse: 'Animates Safe Balance increase, adjusts daily allowance upward, and displays updated Survival Score.',
        uiElements: ['Success toast: "Safe Balance increased by RM 3,500 · Daily limit is now RM 45.20/day"', 'Auto-dismiss sheet']
      }
    ]
  },
  {
    id: 'add-expense',
    number: '04',
    title: 'Add Expense Flow (Micro-Interaction < 8s)',
    goal: 'Record daily campus meals and transit with minimum taps right at the cashier.',
    trigger: 'User finishes paying for lunch, coffee, or transport.',
    steps: [
      {
        stepNumber: 1,
        screenName: 'Global Screen / Bottom Bar',
        userAction: 'Taps the persistent floating "+ Log Expense" CTA in the bottom thumb zone or header.',
        systemResponse: 'Opens focused numeric entry pad with cursor active in amount field.',
        uiElements: ['Haptic feedback on tap', 'Focused currency amount input ($/RM)', 'Category pill row']
      },
      {
        stepNumber: 2,
        screenName: 'Expense Entry Pad',
        userAction: 'Types amount (e.g., 9.50) using on-screen number pad and taps category icon ("Food & Meals").',
        systemResponse: 'Highlight category chip; defaults title to category name or allows optional 1-line note ("Nasi Ayam").',
        uiElements: ['6 big category touch targets (Food, Campus, Transit, Groceries, Social, Other)', 'Note input field', 'Quick amount pills (+5, +10, +20)']
      },
      {
        stepNumber: 3,
        screenName: 'Instant Safe Balance Deduct',
        userAction: 'Taps primary CTA "Deduct Expense".',
        systemResponse: 'Deducts amount from Safe Balance; updates today\'s remaining daily allowance counter with instant visual feedback.',
        uiElements: ['Animated counter roll on Safe Balance', 'Today\'s spent meter update', 'Micro-banner: "RM 16.50 safe buffer remaining for today"']
      }
    ]
  },
  {
    id: 'add-debt',
    number: '05',
    title: 'Add Debt / IOU Flow',
    goal: 'Capture peer split bills and borrowings before they slip from memory.',
    trigger: 'Friend pays for dinner or user fronts money for group project.',
    steps: [
      {
        stepNumber: 1,
        screenName: 'Debts & Obligations Tab',
        userAction: 'Taps "Record IOU" button.',
        systemResponse: 'Presents Direction Selector: "I Owe Someone" vs "Someone Owes Me".',
        uiElements: ['Two large directional toggles with clear icons', 'Explanatory subtitle on Safe Balance impact']
      },
      {
        stepNumber: 2,
        screenName: 'IOU Details Form',
        userAction: 'Selects direction (e.g. "I Owe"), enters friend name ("Hafiz"), amount ("RM 35"), and purpose ("Hotpot split").',
        systemResponse: 'Applies core safety rule: "I Owe" will immediately deduct RM 35 from Safe Balance so you don\'t accidentally spend Hafiz\'s money.',
        uiElements: ['Friend name input with contact autosuggest', 'Amount field', 'Reason input (Hotpot, Grab, Printing)', 'Optional repayment target date']
      },
      {
        stepNumber: 3,
        screenName: 'Confirmation & Ledger Update',
        userAction: 'Taps "Save Debt".',
        systemResponse: 'Adds debt to active ledger, deducts amount from Safe Balance (if I Owe), and schedules subtle reminder.',
        uiElements: ['New row in Peer Debts list with "Settle" button', 'Safe Balance deduction badge']
      }
    ]
  },
  {
    id: 'add-commitment',
    number: '06',
    title: 'Add Commitment (Fixed Bill) Flow',
    goal: 'Ring-fence non-negotiable living costs so students never default on shelter or tuition.',
    trigger: 'User receives semester hostel invoice, signs wifi contract, or enrolls in tuition installment.',
    steps: [
      {
        stepNumber: 1,
        screenName: 'Commitments Tab',
        userAction: 'Taps "+ Add Fixed Bill" button.',
        systemResponse: 'Opens Commitment configuration drawer.',
        uiElements: ['Commitment modal drawer', 'Template suggestions: Hostel, Room Rental, Celcom/Digi Plan, Spotify Student']
      },
      {
        stepNumber: 2,
        screenName: 'Bill Parameters Entry',
        userAction: 'Enters obligation name ("Campus Hostel"), amount ("RM 450"), billing cycle ("Monthly"), and due day ("1st of every month").',
        systemResponse: 'Marks commitment as "Unpaid / Reserved for Cycle" by default.',
        uiElements: ['Bill name input', 'Amount input', 'Frequency dropdown (Monthly, Semester, One-time)', 'Due date picker']
      },
      {
        stepNumber: 3,
        screenName: 'Safe Balance Quarantine',
        userAction: 'Taps "Lock & Save Commitment".',
        systemResponse: 'Immediately reserves RM 450 from Safe Balance, recalculates daily allowance, and sets upcoming payment notification.',
        uiElements: ['Visual lock icon on Safe Balance breakdown', 'Due date countdown chip ("Due in 8 days")']
      }
    ]
  },
  {
    id: 'view-dashboard',
    number: '07',
    title: 'View Dashboard Flow (Core Habit Loop)',
    goal: 'Provide an instant cognitive snapshot of spending safety within 3 seconds of opening app.',
    trigger: 'Student opens app before making a purchase decision or during morning routine.',
    steps: [
      {
        stepNumber: 1,
        screenName: 'Main Dashboard Top Viewport',
        userAction: 'Scans top half of the screen.',
        systemResponse: 'Displays Safe Balance as primary visual anchor (e.g. RM 2,415.00), with unboxed breakdown of Gross Cash minus Commitments/Debts/Savings.',
        uiElements: ['Hero Safe Balance card', 'Disbursement date countdown', 'Formula transparency trigger ("?")']
      },
      {
        stepNumber: 2,
        screenName: 'Daily Safe Allowance Metric',
        userAction: 'Looks at Daily Cap tile (e.g. "RM 35.50 / day") and Today\'s Spending progress.',
        systemResponse: 'Shows remaining budget for the day: "Spent RM 11.50 · RM 24.00 remaining safe for dinner".',
        uiElements: ['Daily allowance metric tile', 'Today\'s spend progress bar', 'Remaining today badge']
      },
      {
        stepNumber: 3,
        screenName: 'Scroll to Recent Feed',
        userAction: 'Swipes down to view recent expenses, upcoming bills due this week, and unsettled peer debts.',
        systemResponse: 'Presents prioritized action items (e.g. "Hostel rent due in 4 days", "Zack owes you RM 18").',
        uiElements: ['Actionable alert cards', 'Recent expense log', 'Fixed bottom tab bar']
      }
    ]
  },
  {
    id: 'view-survival-score',
    number: '08',
    title: 'View Survival Score & Runway Diagnostic',
    goal: 'Deliver proactive financial health feedback and actionable guidance to prevent end-of-semester starvation.',
    trigger: 'User taps the Survival Score card on Dashboard or receives a burn-rate alert.',
    steps: [
      {
        stepNumber: 1,
        screenName: 'Survival Score Card / Detail View',
        userAction: 'Taps the radial score gauge (e.g., "78 / 100 · Stable Runway").',
        systemResponse: 'Expands into detailed Runway Health Diagnostic Sheet.',
        uiElements: ['Radial SVG gauge with dynamic color tier', 'Health tier badge (Thriving / Stable / Caution / Critical)', 'Days Runway metric']
      },
      {
        stepNumber: 2,
        screenName: 'Runway vs Inflow Analysis',
        userAction: 'Inspects Runway Days (e.g., 74 days safe) vs Days to Next Disbursement (68 days).',
        systemResponse: 'Confirms green buffer ("No gap: your funds safely cover the remaining semester at baseline burn") or red warning if shortfall exists.',
        uiElements: ['Runway gap comparison bar', 'Projected date of zero cash if current burn continues']
      },
      {
        stepNumber: 3,
        screenName: 'Actionable Student Prescription',
        userAction: 'Reads personalized mitigation recommendations.',
        systemResponse: 'Offers contextual campus survival tips based on score: "Maintain current meal budget at RM 20/day" or "Cap cafeteria meals to RM 12/day and collect Zack\'s RM 18 to restore Stable score."',
        uiElements: ['Prescription card with lightbulb icon', 'One-tap action: "Set Daily Cap to RM 18"', 'Dismiss button']
      }
    ]
  }
];
