import { AtmosphereImage } from "../types";

export const SPACE_GALLERY: AtmosphereImage[] = [
  {
    id: "space-dining-hall",
    title: "The Main Dining Room",
    caption: "Morning light pouring across lime-washed plaster walls, solid teak tables, and linen drapery.",
    aspectRatio: "16:9",
    imageUrl: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1400&q=80",
  },
  {
    id: "space-coffee-counter",
    title: "The Espresso Bar",
    caption: "Hand-poured filter brews and Araku Valley roasts prepared in quiet rhythm.",
    aspectRatio: "4:5",
    imageUrl: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: "space-courtyard",
    title: "Veranda & Foliage",
    caption: "Shaded outdoor seating beneath coastal palms, catching the gentle breeze from the Bay of Bengal.",
    aspectRatio: "1:1",
    imageUrl: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=1000&q=80",
  },
  {
    id: "space-table-detail",
    title: "Materiality & Table Details",
    caption: "Hand-thrown stoneware plates, unbleached linen napkins, and wild dry floral arrangements.",
    aspectRatio: "4:5",
    imageUrl: "https://images.unsplash.com/photo-1559925393-8be0ec4767c8?auto=format&fit=crop&w=900&q=80",
  },
];
