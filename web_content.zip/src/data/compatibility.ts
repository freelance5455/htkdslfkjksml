import { Building, Disciple } from '../types/cultivation';

export interface CompatibilityResult {
  percentage: number;
  grade: 'Flawless' | 'Harmonious' | 'Adept' | 'Average' | 'Discordant';
  yieldMultiplier: number;
  reason: string;
}

export function calculateStaffCompatibility(building: Building, disciple: Disciple): CompatibilityResult {
  let score = 50; // Base baseline
  const reasons: string[] = [];

  // Spirit Root synergy
  switch (building.id) {
    case 'b_array':
      if (['Wood', 'Water', 'Yin-Yang'].includes(disciple.spiritRoot)) {
        score += 20;
        reasons.push(`${disciple.spiritRoot} channels leylines seamlessly`);
      }
      if (disciple.preference === 'Meditation') { score += 15; reasons.push('Prefers serene meditation'); }
      if (disciple.temperament === 'Calm') score += 10;
      break;

    case 'b_mine':
      if (['Earth', 'Metal', 'Thunder'].includes(disciple.spiritRoot)) {
        score += 20;
        reasons.push(`${disciple.spiritRoot} harmonizes with subterranean ore`);
      }
      if (disciple.preference === 'Exploration') { score += 15; reasons.push('Keen eye for mineral veins'); }
      if (disciple.constitution === 'Ancient Desolate Sacred Physique') score += 15;
      break;

    case 'b_alchemy':
      if (['Fire', 'Wood'].includes(disciple.spiritRoot)) {
        score += 25;
        reasons.push(`${disciple.spiritRoot} controls cauldron flames and wood herbs`);
      }
      if (disciple.preference === 'Alchemy') { score += 20; reasons.push('Devoted to elixir refinement'); }
      if (['Pure Yang Divine Body', 'Nine Heavens Phoenix Body'].includes(disciple.constitution)) score += 10;
      break;

    case 'b_scripture':
      if (disciple.talent >= 80) { score += 20; reasons.push(`Exceptional Talent (${disciple.talent}) comprehends jade slips`); }
      if (disciple.preference === 'Meditation') score += 15;
      if (disciple.background === 'Daoist Temple Acolyte') score += 10;
      break;

    case 'b_discipline':
      if (['Metal', 'Thunder'].includes(disciple.spiritRoot)) { score += 20; reasons.push('Stern aura suppresses inner rebellion'); }
      if (['Ruthless', 'Loyal'].includes(disciple.temperament)) { score += 15; reasons.push('Unbending adherence to sect laws'); }
      if (disciple.preference === 'Combat') score += 10;
      break;

    case 'b_tribulation':
      if (['Thunder', 'Chaos'].includes(disciple.spiritRoot)) { score += 25; reasons.push('Natural conductor of lightning tribulations'); }
      if (['Innate Sword Embryo', 'Ancient Desolate Sacred Physique'].includes(disciple.constitution)) score += 15;
      if (disciple.currentRealmIndex >= 9) score += 10;
      break;

    case 'b_nursery':
      if (['Wood', 'Water'].includes(disciple.spiritRoot)) { score += 25; reasons.push('Nourishes spirit plants with verdant dew'); }
      if (disciple.preference === 'Alchemy') score += 15;
      if (disciple.background === 'Mountain Village Mortal') score += 10;
      break;

    case 'b_talisman':
      if (['Thunder', 'Wind', 'Water'].includes(disciple.spiritRoot)) { score += 20; reasons.push('Swift elemental ink channeling'); }
      if (disciple.talent >= 75) score += 15;
      break;

    case 'b_garden':
      if (['Wood', 'Earth'].includes(disciple.spiritRoot)) { score += 20; reasons.push('Naturally befriended by spirit beasts'); }
      if (disciple.temperament === 'Benevolent' || disciple.temperament === 'Carefree') score += 15;
      break;

    case 'b_forge':
      if (['Fire', 'Metal'].includes(disciple.spiritRoot)) { score += 25; reasons.push('Smelts earth flame and divine ores'); }
      if (disciple.preference === 'Combat') score += 15;
      break;

    case 'b_meditation':
      if (disciple.preference === 'Meditation') score += 20;
      if (disciple.talent >= 85) score += 15;
      if (disciple.temperament === 'Calm') score += 10;
      break;

    case 'b_astronomy':
      if (['Yin-Yang', 'Chaos', 'Ice'].includes(disciple.spiritRoot)) { score += 25; reasons.push('Attuned to celestial stellar paths'); }
      if (disciple.talent >= 85) score += 15;
      break;

    default:
      if (disciple.talent >= 70) score += 10;
      break;
  }

  const percentage = Math.min(100, Math.max(35, score));
  let grade: CompatibilityResult['grade'] = 'Average';
  let yieldMultiplier = 1.0;

  if (percentage >= 90) {
    grade = 'Flawless';
    yieldMultiplier = 1.5; // +50% yield!
  } else if (percentage >= 75) {
    grade = 'Harmonious';
    yieldMultiplier = 1.25; // +25% yield
  } else if (percentage >= 60) {
    grade = 'Adept';
    yieldMultiplier = 1.1; // +10% yield
  } else if (percentage >= 45) {
    grade = 'Average';
    yieldMultiplier = 1.0;
  } else {
    grade = 'Discordant';
    yieldMultiplier = 0.8;
  }

  const reason = reasons.length > 0 ? reasons.join(' · ') : 'Standard labor synergy';

  return { percentage, grade, yieldMultiplier, reason };
}
