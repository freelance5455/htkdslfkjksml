import type { CurriculumSource, CurriculumUnitInfo } from '../../types';

export const CURRICULUM_SOURCES: CurriculumSource[] = [
  { id: 'nccd-catalog', title: 'مكتبة الكتب المدرسية للصف الثالث الثانوي العلمي', organization: 'المركز الوطني لتطوير المناهج التربوية', url: 'https://nccd.gov.sy/book?i=15', kind: 'official-reference', accessedAt: '2026-11-11' },
  { id: 'math-book-part-1', title: 'كتاب الرياضيات العلمي — الجزء الأول', organization: 'المركز الوطني لتطوير المناهج التربوية', url: 'https://nccd.gov.sy/imges/books/Gr12/math12f1.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'math-book-part-2', title: 'كتاب الرياضيات العلمي — الجزء الثاني', organization: 'المركز الوطني لتطوير المناهج التربوية', url: 'https://nccd.gov.sy/imges/books/Gr12/math12f2.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'physics-book', title: 'كتاب الفيزياء — الصف الثالث الثانوي العلمي', organization: 'وزارة التربية السورية؛ المركز الوطني لتطوير المناهج التربوية', edition: '2021–2022 على الغلاف', url: 'https://nccd.gov.sy/imges/books/Gr12/ph12al.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'chemistry-book', title: 'كتاب الكيمياء — الصف الثالث الثانوي العلمي', organization: 'وزارة التربية السورية؛ المركز الوطني لتطوير المناهج التربوية', edition: '2021–2022 على الغلاف', url: 'https://nccd.gov.sy/imges/books/Gr12/k12al.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'biology-book', title: 'كتاب علم الأحياء — الصف الثالث الثانوي العلمي', organization: 'وزارة التربية السورية؛ المركز الوطني لتطوير المناهج التربوية', edition: '2021–2022 على الغلاف', url: 'https://nccd.gov.sy/imges/books/Gr12/sci12al.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'arabic-book', title: 'كتاب اللغة العربية وآدابها — العلمي', organization: 'وزارة التربية السورية؛ المركز الوطني لتطوير المناهج التربوية', edition: '2021–2022 على الغلاف', url: 'https://nccd.gov.sy/imges/books/Gr12/ar12al.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'english-book', title: 'Emar English Series — Scientific Section', organization: 'وزارة التربية السورية؛ المركز الوطني لتطوير المناهج التربوية', edition: 'أول طباعة للعام الدراسي 2021–2022', url: 'https://nccd.gov.sy/imges/books/E/e12kal.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'french-book', title: 'كتاب اللغة الفرنسية — الثالث الثانوي', organization: 'وزارة التربية السورية؛ المركز الوطني لتطوير المناهج التربوية', url: 'https://nccd.gov.sy/imges/books/F/f12.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'french-supplement', title: 'ملحق اللغة الفرنسية — الثالث الثانوي', organization: 'وزارة التربية السورية؛ المركز الوطني لتطوير المناهج التربوية', url: 'https://nccd.gov.sy/imges/books/F/f12m.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'religion-book', title: 'كتاب التربية الدينية الإسلامية — الصف الثالث الثانوي', organization: 'وزارة التربية السورية؛ المركز الوطني لتطوير المناهج التربوية', edition: '2021–2022 / 1442–1443 هـ على الغلاف', url: 'https://nccd.gov.sy/imges/books/Gr12/islm12.pdf', kind: 'textbook', accessedAt: '2026-11-09' },
  { id: 'sana-exam-scoring-news', title: 'خبر رسمي عن مناقشة سلالم امتحانات 2026؛ لا يرفق ملفاً', organization: 'وكالة سانا', url: 'https://sana.sy/education/2501318/', kind: 'official-reference', accessedAt: '2026-11-09' },
];

export interface CurriculumCoverage {
  subjectId: string;
  sourceIds: string[];
  unitIndexVerified: boolean;
  note: string;
}

export const CURRICULUM_COVERAGE: CurriculumCoverage[] = [
  { subjectId: 'math', sourceIds: ['math-book-part-1', 'math-book-part-2'], unitIndexVerified: true, note: 'تمت مراجعة فهرسي ملفي NCCD المصوّرين في صفحات PDF ٨–١٠: ٧ وحدات في كل جزء. سنة الطبعة غير مثبتة من الغلاف؛ اكتمل OCR ويجب مطابقة كل سؤال بصفحته قبل الإدراج.' },
  { subjectId: 'physics', sourceIds: ['physics-book'], unitIndexVerified: true, note: 'الوحدات من الفهرس الرسمي لنسخة 2021–2022؛ لم يُتحقق من وجود طبعة أحدث.' },
  { subjectId: 'chemistry', sourceIds: ['chemistry-book'], unitIndexVerified: true, note: 'الفهرس الرسمي في صفحة PDF ٤؛ الغلاف يظهر 2021–2022 وحقوق النشر تسجل أول طباعة 2019–2020. لم يُتحقق من أحدث إصدار؛ اكتمل OCR ويجب مطابقة كل سؤال بصفحته قبل الإدراج.' },
  { subjectId: 'biology', sourceIds: ['biology-book'], unitIndexVerified: true, note: 'الوحدات من الفهرس الرسمي لنسخة 2021–2022؛ لم يُتحقق من وجود طبعة أحدث.' },
  { subjectId: 'arabic', sourceIds: ['arabic-book'], unitIndexVerified: true, note: 'الوحدات من الفهرس الرسمي لنسخة 2021–2022؛ لم يُتحقق من وجود طبعة أحدث.' },
  { subjectId: 'english', sourceIds: ['english-book'], unitIndexVerified: true, note: 'الوحدات من الفهرس الرسمي؛ لم يُتحقق من وجود طبعة أحدث من أول طباعة 2021–2022.' },
  { subjectId: 'french', sourceIds: ['french-book', 'french-supplement'], unitIndexVerified: true, note: '٦ وحدات أساسية و٣ فصول منفصلة في الملحق؛ سنة الطبعة غير مثبتة صراحة.' },
  { subjectId: 'religion', sourceIds: ['religion-book'], unitIndexVerified: true, note: 'الوحدات من الفهرس الرسمي لنسخة 2021–2022؛ لم يُتحقق من وجود طبعة أحدث.' },
];

/** عناوين الوحدات والفصول من فهارس الكتب الرسمية؛ لا تُضاف أسئلة قبل توفر مرجع موثق. */
export const CURRICULUM_UNITS: CurriculumUnitInfo[] = [
  { id: 'math-sequences-induction', subjectId: 'math', title: 'الوحدة الأولى: المتتاليات والإثبات بالتدريج', lessonTitles: ['عموميات عن المتتاليات', 'البرهان بالتدريج أو بالاستقراء الرياضي'], lessonQuestionCounts: [14, 6], questionCount: 20, sourceIds: ['math-book-part-1'] },
  { id: 'math-functions-limits-continuity', subjectId: 'math', title: 'الوحدة الثانية: التوابع، النهايات والاستمرار', lessonTitles: ['نهاية تابع عند اللانهاية', 'نهاية تابع عند عدد حقيقي', 'العمليات على النهايات', 'مبرهنات المقارنة', 'نهاية تابع مركب', 'المقارب المائل', 'الاستمرار', 'التوابع المستمرة وحل المعادلات'], questionCount: 0, sourceIds: ['math-book-part-1'] },
  { id: 'math-differentiation', subjectId: 'math', title: 'الوحدة الثالثة: التوابع والاشتقاق', lessonTitles: ['تعاريف (تذكرة)', 'مشتقات بعض التوابع المألوفة (تذكرة)', 'تطبيقات الاشتقاق', 'اشتقاق تابع مركب', 'المشتقات من مراتب عليا'], questionCount: 0, sourceIds: ['math-book-part-1'] },
  { id: 'math-sequence-limits', subjectId: 'math', title: 'الوحدة الرابعة: متتاليات', lessonTitles: ['نهاية متتالية (تذكرة)', 'مبرهنات تخص النهايات', 'تقارب المتتاليات المطردة', 'متتاليات متجاورة'], questionCount: 0, sourceIds: ['math-book-part-1'] },
  { id: 'math-natural-log', subjectId: 'math', title: 'الوحدة الخامسة: التابع اللوغاريتمي النيبري', lessonTitles: ['التابع اللوغاريتمي النيبري', 'لوغاريتم جداء', 'دراسة التابع اللوغاريتمي ln', 'مشتق التابع المركب ln', 'نهايات مهمة تتعلق بالتابع اللوغاريتمي'], questionCount: 0, sourceIds: ['math-book-part-1'] },
  { id: 'math-exponential', subjectId: 'math', title: 'الوحدة السادسة: التابع الأسي', lessonTitles: ['التابع الأسي الطبيعي', 'خواص التابع الأسي', 'دراسة التابع الأسي', 'نهايات مهمة تتعلق بالتابع الأسي', 'دراسة توابع من النمط a^x حيث a > 0', 'معادلات تفاضلية بسيطة'], questionCount: 0, sourceIds: ['math-book-part-1'] },
  { id: 'math-definite-integral', subjectId: 'math', title: 'الوحدة السابعة: التكامل المحدد', lessonTitles: ['التوابع الأصلية', 'بعض قواعد حساب التوابع الأصلية', 'التكامل المحدد وخواصه', 'التكامل المحدد وحساب المساحة'], questionCount: 0, sourceIds: ['math-book-part-1'] },

  { id: 'math-vectors-space', subjectId: 'math', title: 'الوحدة الأولى: أشعة في الفراغ', lessonTitles: ['عموميات', 'الارتباط الخطي لثلاثة أشعة', 'المعلم في الفراغ', 'المسافة في الفراغ', 'مركز الأبعاد المتناسبة في الفراغ'], questionCount: 0, sourceIds: ['math-book-part-2'] },
  { id: 'math-dot-product-space', subjectId: 'math', title: 'الوحدة الثانية: الجداء السلمي في الفراغ', lessonTitles: ['الجداء السلمي في المستوي (تذكرة)', 'الجداء السلمي في الفراغ', 'التعامد في الفراغ', 'المعادلة الديكارتية لمستوى'], questionCount: 0, sourceIds: ['math-book-part-2'] },
  { id: 'math-lines-planes-space', subjectId: 'math', title: 'الوحدة الثالثة: المستقيمات والمستويات في الفراغ', lessonTitles: ['المستقيم والمستوي بصفتهما مراكز أبعاد متناسبة', 'التمثيلات الوسيطية', 'تقاطع مستقيمات ومستويات', 'تقاطع ثلاثة مستويات'], questionCount: 0, sourceIds: ['math-book-part-2'] },
  { id: 'math-complex-numbers', subjectId: 'math', title: 'الوحدة الرابعة: الأعداد العقدية', lessonTitles: ['مجموعة الأعداد العقدية', 'مرافق عدد عقدي', 'الشكل المثلثي لعدد عقدي', 'طويلة عدد عقدي وزاويته', 'الشكل الأسي لعدد عقدي', 'المعادلات من الدرجة الثانية ذات الأمثال الحقيقية'], questionCount: 0, sourceIds: ['math-book-part-2'] },
  { id: 'math-complex-geometry', subjectId: 'math', title: 'الوحدة الخامسة: تطبيقات الأعداد العقدية في الهندسة', lessonTitles: ['تمثيل الأشعة بأعداد عقدية', 'استعمال العدد العقدي الممثل لشعاع', 'الكتابة العقدية للتحويلات الهندسية'], questionCount: 0, sourceIds: ['math-book-part-2'] },
  { id: 'math-combinatorics', subjectId: 'math', title: 'الوحدة السادسة: التحليل التوافقي', lessonTitles: ['إنشاء قوائم من عناصر مجموعة', 'التوافيق', 'خواص عدد التوافيق ومنشور ذي الحدين'], questionCount: 0, sourceIds: ['math-book-part-2'] },
  { id: 'math-probability', subjectId: 'math', title: 'الوحدة السابعة: الاحتمالات', lessonTitles: ['الاحتمالات الشرطية', 'المتحولات العشوائية', 'الاستقلال الاحتمالي لمتحولين عشوائيين', 'المتحولات العشوائية الحدانية'], questionCount: 0, sourceIds: ['math-book-part-2'] },

  { id: 'physics-motion', subjectId: 'physics', title: 'الوحدة الأولى: الحركة والتحريك', lessonTitles: ['الحركة التوافقية البسيطة', 'النواس الفتلي غير المتخامد', 'النواس الثقلي غير المتخامد', 'ميكانيك الموائع', 'النسبية الخاصة'], lessonQuestionCounts: [20, 0, 0, 0, 0], questionCount: 20, sourceIds: ['physics-book'] },
  { id: 'physics-electricity-magnetism', subjectId: 'physics', title: 'الوحدة الثانية: الكهرباء والمغناطيسية', lessonTitles: ['المغناطيسية', 'فعل الحقل المغناطيسي في التيار الكهربائي', 'التحريض الكهرطيسي', 'الدارات المهتزة والتيارات عالية التواتر', 'التيار المتناوب الجيبي', 'المحولات الكهربائية'], questionCount: 0, sourceIds: ['physics-book'] },
  { id: 'physics-standing-waves', subjectId: 'physics', title: 'الوحدة الثالثة: الأمواج المستقرة', lessonTitles: ['الأمواج المستقرة العرضية', 'الأمواج المستقرة الطولية'], questionCount: 0, sourceIds: ['physics-book'] },
  { id: 'physics-electronics', subjectId: 'physics', title: 'الوحدة الرابعة: الإلكترونيات والجسم الصلب', lessonTitles: ['النماذج الذرية والطيوف', 'انتزاع الإلكترونات وتسريعها', 'الأشعة المهبطية', 'الفعل الكهرحراري', 'نظرية الكم والفعل الكهرضوئي', 'الأشعة السينية', 'أشعة الليزر'], questionCount: 0, sourceIds: ['physics-book'] },
  { id: 'physics-astrophysics', subjectId: 'physics', title: 'الوحدة الخامسة: الفيزياء الفلكية', lessonTitles: ['الفيزياء الفلكية'], questionCount: 0, sourceIds: ['physics-book'] },

  { id: 'chemistry-nuclear', subjectId: 'chemistry', title: 'الوحدة الأولى: الكيمياء النووية', lessonTitles: ['الكيمياء النووية'], questionCount: 0, sourceIds: ['chemistry-book'] },
  { id: 'chemistry-gases', subjectId: 'chemistry', title: 'الوحدة الثانية: الغازات', lessonTitles: ['الغازات'], questionCount: 0, sourceIds: ['chemistry-book'] },
  { id: 'chemistry-kinetics', subjectId: 'chemistry', title: 'الوحدة الثالثة: حركية التفاعلات الكيميائية', lessonTitles: ['سرعة التفاعل الكيميائي', 'التوازن الكيميائي'], questionCount: 0, sourceIds: ['chemistry-book'] },
  { id: 'chemistry-analytical', subjectId: 'chemistry', title: 'الوحدة الرابعة: الكيمياء التحليلية', lessonTitles: ['الحموض والأسس', 'المحاليل المائية للأملاح', 'المعايرة الحجمية'], questionCount: 0, sourceIds: ['chemistry-book'] },
  { id: 'chemistry-organic', subjectId: 'chemistry', title: 'الوحدة الخامسة: الكيمياء العضوية', lessonTitles: ['الأغوال', 'الألدهيدات والكيتونات', 'الحموض العضوية', 'مشتقات الحموض الكربوكسيلية', 'الأمينات'], questionCount: 0, sourceIds: ['chemistry-book'] },

  { id: 'biology-coordination', subjectId: 'biology', title: 'الوحدة الأولى: التنسيق العصبي والهرموني', lessonTitles: ['الجهاز والنسيج العصبي', 'خواص الأعصاب والنقل العصبي', 'وظائف الجهاز العصبي والفعل المنعكس', 'المستقبلات الحسية', 'التنسيق الهرموني والنباتي'], lessonQuestionCounts: [20, 0, 0, 0, 0], questionCount: 20, sourceIds: ['biology-book'] },
  { id: 'biology-reproduction', subjectId: 'biology', title: 'الوحدة الثانية: تكاثر الكائنات الحية', lessonTitles: ['تكاثر الفيروسات والأحياء', 'التقانات الحيوية والخلايا الجذعية', 'التكاثر لدى عاريات ومغلفات البذور', 'جهاز التكاثر لدى الإنسان', 'الدورة الجنسية والتنامي الجنيني', 'الصحة الإنجابية'], questionCount: 0, sourceIds: ['biology-book'] },
  { id: 'biology-genetics', subjectId: 'biology', title: 'الوحدة الثالثة: الوراثة', lessonTitles: ['تجارب مندل', 'التهجين الاختباري وتآثر المورثات', 'الارتباط والعبور', 'تحديد الجنس والوراثة عند الإنسان', 'الطفرات والهندسة الوراثية'], questionCount: 0, sourceIds: ['biology-book'] },

  { id: 'arabic-national-issues', subjectId: 'arabic', title: 'الوحدة الأولى: قضايا وطنية وقومية', lessonTitles: ['أدب القضايا الوطنية والقومية', 'نصوص شعرية من الوحدة', 'أدب المقاومة'], questionCount: 0, sourceIds: ['arabic-book'] },
  { id: 'arabic-mahjar', subjectId: 'arabic', title: 'الوحدة الثانية: الغربة والاغتراب في الأدب المهجري', lessonTitles: ['الأدب المهجري', 'نصوص جرجس صيدح ونسيب عريضة وجبران خليل جبران'], questionCount: 0, sourceIds: ['arabic-book'] },
  { id: 'arabic-novel', subjectId: 'arabic', title: 'الوحدة الثالثة: فن الرواية', lessonTitles: ['فن الرواية', 'نصوص حنا مينه وألفة الإدلبي', 'تجديد الرواية العربية'], questionCount: 0, sourceIds: ['arabic-book'] },
  { id: 'arabic-emotional', subjectId: 'arabic', title: 'الوحدة الرابعة: ظواهر وجدانية', lessonTitles: ['الشعر الوجداني', 'نصوص عدنان مردم بك وبدر الدين الحامد ونزار قباني', 'مهمة الشعر'], questionCount: 0, sourceIds: ['arabic-book'] },
  { id: 'arabic-social', subjectId: 'arabic', title: 'الوحدة الخامسة: أدب القضايا الاجتماعية', lessonTitles: ['الأدب الاجتماعي', 'نصوص محمود سامي البارودي وخير الدين الزركلي وأدونيس'], questionCount: 0, sourceIds: ['arabic-book'] },

  { id: 'english-life-choices', subjectId: 'english', title: 'Module 1 — Unit 1: Life Choices', lessonTitles: ['Future Career', 'زمن مراجعة الأزمنة 1', 'النصيحة'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-success', subjectId: 'english', title: 'Module 1 — Unit 2: Success', lessonTitles: ['Stop Wishing Start Doing', 'Personal experience writing', 'Tenses review 2'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-medicine', subjectId: 'english', title: 'Module 2 — Unit 3: Medicine', lessonTitles: ['History of Medicine', 'Health care in Syria', 'Passive voice'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-engineering', subjectId: 'english', title: 'Module 2 — Unit 4: Engineering', lessonTitles: ['History of Engineering', 'Causative form', 'Motion prepositions'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-civil-rights', subjectId: 'english', title: 'Module 3 — Unit 5: Civil Rights', lessonTitles: ['Civil Rights', 'Relative clauses', 'Complaints and apologies'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-united-nations', subjectId: 'english', title: 'Module 3 — Unit 6: United Nations', lessonTitles: ['History of the United Nations', 'Future forms', 'Prefixes'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-microorganism', subjectId: 'english', title: 'Module 4 — Unit 7: Microorganism', lessonTitles: ['Viruses and Bacteria', 'Second and third conditionals', 'Environmental health writing'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-human-body', subjectId: 'english', title: 'Module 4 — Unit 8: Facts about Human Body', lessonTitles: ['Human Body', 'Expressing wishes', 'Email writing'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-citizenship', subjectId: 'english', title: 'Module 5 — Unit 9: Citizenship', lessonTitles: ['Citizenship', 'Paired conjunctions', 'Good citizen writing'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-culture-shock', subjectId: 'english', title: 'Module 5 — Unit 10: Culture Shock', lessonTitles: ['Culture Shock', 'Modal verbs', 'Formal and informal letters'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-ai', subjectId: 'english', title: 'Module 6 — Unit 11: Artificial Intelligence', lessonTitles: ['Artificial Intelligence', 'Reported speech', 'Science and technology vocabulary'], questionCount: 0, sourceIds: ['english-book'] },
  { id: 'english-digital-literacy', subjectId: 'english', title: 'Module 6 — Unit 12: Digital Literacy', lessonTitles: ['E-government', 'Inversion', 'Internet and learning writing'], questionCount: 0, sourceIds: ['english-book'] },

  { id: 'french-fete', subjectId: 'french', title: 'Unité 1 — On fête ensemble …', lessonTitles: ['فعاليات اجتماعية', 'التعبير عن الغاية', 'رسالة في منتدى'], questionCount: 0, sourceIds: ['french-book'] },
  { id: 'french-solidarity', subjectId: 'french', title: 'Unité 2 — Chacun pour tous', lessonTitles: ['عمل إنساني', 'التنازل وأدوات الربط', 'رسالة اقتراح أعمال إنسانية'], questionCount: 0, sourceIds: ['french-book'] },
  { id: 'french-culture-space', subjectId: 'french', title: 'Unité 3 — Le salon, un espace culturel', lessonTitles: ['صالون ثقافي', 'الخطاب غير المباشر', 'كتابة دعوة'], questionCount: 0, sourceIds: ['french-book'] },
  { id: 'french-women-literature', subjectId: 'french', title: 'Unité 4 — La femme dans la littérature', lessonTitles: ['المرأة في الأدب والفن', 'السيرة الأدبية', 'صيغة التفضيل العليا'], questionCount: 0, sourceIds: ['french-book'] },
  { id: 'french-ai', subjectId: 'french', title: 'Unité 5 — L’intelligence artificielle', lessonTitles: ['الذكاء الاصطناعي', 'الموافقة والرفض والحجاج', 'الصفات والضمائر غير المحددة'], questionCount: 0, sourceIds: ['french-book'] },
  { id: 'french-space', subjectId: 'french', title: 'Unité 6 — La conquête de l’espace', lessonTitles: ['استكشاف الفضاء', 'تسلسل زمني', 'ضمائر الملكية والإشارة'], questionCount: 0, sourceIds: ['french-book'] },
  { id: 'french-play-comedy', subjectId: 'french', title: 'Chapitre I — La Comédie (ملحق)', kind: 'supplement-chapter', lessonTitles: [], questionCount: 0, sourceIds: ['french-supplement'] },
  { id: 'french-play-tragedy', subjectId: 'french', title: 'Chapitre II — La Tragédie (ملحق)', kind: 'supplement-chapter', lessonTitles: [], questionCount: 0, sourceIds: ['french-supplement'] },
  { id: 'french-play-syrian', subjectId: 'french', title: 'Chapitre III — Dramaturges Syriens (ملحق)', kind: 'supplement-chapter', lessonTitles: [], questionCount: 0, sourceIds: ['french-supplement'] },

  { id: 'religion-unit-1', subjectId: 'religion', title: 'الوحدة الأولى', lessonTitles: ['العلم والإيمان', 'المحافظة على الوطن', 'الوحدة الإنسانية', 'المواطنة', 'الكسب المشروع'], questionCount: 0, sourceIds: ['religion-book'] },
  { id: 'religion-unit-2', subjectId: 'religion', title: 'الوحدة الثانية', lessonTitles: ['مفاتح الغيب', 'حسن الظن بالله تعالى', 'حقوق الآباء والأبناء', 'التطرف والإرهاب'], questionCount: 0, sourceIds: ['religion-book'] },
  { id: 'religion-unit-3', subjectId: 'religion', title: 'الوحدة الثالثة', lessonTitles: ['بشارة وتكريم', 'جزاء المؤمنين', 'صلاح القلب', 'القضاء والقدر', 'الاستحسان', 'الكسب غير المشروع'], questionCount: 0, sourceIds: ['religion-book'] },
  { id: 'religion-unit-4', subjectId: 'religion', title: 'الوحدة الرابعة', lessonTitles: ['عاقبة المتقين', 'من صفات المتقين', 'عموم المسؤولية', 'الحج والعمرة', 'الذرائع والعرف', 'الكفالة والرعاية'], questionCount: 0, sourceIds: ['religion-book'] },
  { id: 'religion-unit-5', subjectId: 'religion', title: 'الوحدة الخامسة', lessonTitles: ['الوسطية والاعتدال', 'الطيبات من الرزق', 'قول الحق', 'المصالح المرسلة', 'التربية الأخلاقية'], questionCount: 0, sourceIds: ['religion-book'] },
  { id: 'religion-unit-6', subjectId: 'religion', title: 'الوحدة السادسة', lessonTitles: ['منهج حياة', 'شفاء ورحمة', 'حقوق إنسانية', 'الفراق بين الزوجين', 'العدل'], questionCount: 0, sourceIds: ['religion-book'] },
];

export function getCurriculumUnits(subjectId: string): CurriculumUnitInfo[] {
  return CURRICULUM_UNITS.filter((unit) => unit.subjectId === subjectId);
}

export function getCurriculumCoverage(subjectId: string): CurriculumCoverage | undefined {
  return CURRICULUM_COVERAGE.find((entry) => entry.subjectId === subjectId);
}

export function getCurriculumSource(sourceId: string): CurriculumSource | undefined {
  return CURRICULUM_SOURCES.find((source) => source.id === sourceId);
}
