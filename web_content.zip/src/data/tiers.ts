import { TierConfig, TierLevel } from '../types';

export const TIERS_CONFIG: Record<TierLevel, TierConfig> = {
  1: {
    level: 1,
    nameAr: 'المستوى 1: كشاف البداية',
    nameEn: 'Free Scout',
    badge: '🌱',
    requiredInvites: 0,
    requiresPayment: false,
    requiredPaidInvites: 0,
    color: '#10b981', // emerald
    summaryAr: 'المستوى المجاني الترحيبي لجميع المستخدمين الجدد',
    featuresAr: [
      'مسح الوجبات الذكي بالذكاء الاصطناعي (حتى 3 مسحات يومياً)',
      'حساب السعرات الحرارية المقدرة والماكروز الأساسية (بروتين، كارب، دهون)',
      'حلقة السعرات اليومية لتتبع الالتزام بالهدف',
      'تتبع كمية شرب الماء اليومي',
    ],
  },
  2: {
    level: 2,
    nameAr: 'المستوى 2: العضو النشط',
    nameEn: 'Active Member',
    badge: '⚡',
    requiredInvites: 1,
    requiresPayment: false,
    requiredPaidInvites: 0,
    color: '#06b6d4', // cyan
    summaryAr: 'يُفتح بمجرد دعوة صديق واحد فقط للتطبيق مجاناً',
    featuresAr: [
      'جميع ميزات المستوى الأول',
      'تفصيل المغذيات الدقيقة (ألياف، سكريات، صوديوم، دهون مشبعة)',
      'مؤشر جودة الوجبة الغذائية بالذكاء الاصطناعي (Food Health Score 1-100)',
      'سجل الوجبات الأسبوعي ومراجعة الأيام الـ 7 السابقة',
      'تحليل مكونات الطبق المحتلمة بالتفصيل',
    ],
  },
  3: {
    level: 3,
    nameAr: 'المستوى 3: العضو المحترف PRO',
    nameEn: 'PRO Member',
    badge: '🔥',
    requiredInvites: 4,
    requiresPayment: true,
    requiredPaidInvites: 2, // Either user pays OR at least 2 invitees pay!
    color: '#f59e0b', // amber
    summaryAr: 'مستوى احترافي يتطلب اشتراكاً مدفوعاً إما منك أو من 2 من مدعويك!',
    featuresAr: [
      'مسح غير محدود للوجبات عبر كاميرا الذكاء الاصطناعي بدون أي حد يومي',
      'اقتراحات بدائل الوجبات الصحية الذكية (AI Meal Swaps & Low-Cal)',
      'تنبيهات تلقائية لارتفاع السكر والصوديوم والدهون الضارة',
      'تصدير تقارير التغذية الشاملة بتنسيق PDF و CSV لأخصائي التغذية',
      'إلغاء جميع قيود الانتظار بين المسحات',
    ],
  },
  4: {
    level: 4,
    nameAr: 'المستوى 4: خبير التغذية النخبة',
    nameEn: 'Elite Master',
    badge: '💎',
    requiredInvites: 10,
    requiresPayment: true,
    requiredPaidInvites: 4, // Either user pays OR at least 4 invitees pay!
    color: '#8b5cf6', // violet
    summaryAr: 'يتطلب 10 دعوات واشتراك نشط (منك أو من 4 مدعوين)',
    featuresAr: [
      'جميع ميزات المستويات السابقة',
      'مساعد وموجه التغذية بالذكاء الاصطناعي التفاعلي المباشر (AI Coach)',
      'تعديل ديناميكي فوري للأهداف بناءً على مجهودك ونوع الوجبات',
      'مؤقت الصيام المتقطع الذكي المرتبط بأوقات مسح الوجبات تلقائياً',
      'تحليل سرعة الحرق الأيضي (Metabolic Rate Tracking)',
    ],
  },
  5: {
    level: 5,
    nameAr: 'المستوى 5: أسطورة النخبة VIP',
    nameEn: 'VIP Legend',
    badge: '👑',
    requiredInvites: 20,
    requiresPayment: true,
    requiredPaidInvites: 6, // Either user pays OR at least 6 invitees pay!
    color: '#eab308', // gold
    summaryAr: 'المستوى الأعلى والنهائي: 20 دعوة واشتراك مفعل (منك أو من 6 مدعوين)',
    featuresAr: [
      'المتنبئ الذكي لتطور الوزن ونسبة الدهون خلال 90 يوماً (AI Body Composition Trajectory)',
      'الشارة الذهبية الملكية الحصرية VIP Legend في الملف والترتيب',
      'استشارات غير محدودة من محرك الذكاء الاصطناعي التغذوي المتقدم',
      'خطة وجبات أسبوعية ذكية مخصصة بالكامل لأطباقك المفضلة الممسوحة',
      'أولوية معالجة قصوى وسرعة مسح مضاعفة في خوادم Cal AI',
    ],
  },
};

export function calculateUserTier(
  inviteCount: number,
  isDirectlySubscribed: boolean,
  paidInviteCount: number
): {
  currentTier: TierLevel;
  canAccessTier: (tier: TierLevel) => boolean;
  getTierLockReason: (tier: TierLevel) => string | null;
} {
  const canAccessTier = (tier: TierLevel): boolean => {
    const config = TIERS_CONFIG[tier];
    const hasInvites = inviteCount >= config.requiredInvites;
    if (!config.requiresPayment) {
      return hasInvites;
    }
    // For level 3 and above: user must be paid OR invitees paid >= requiredPaidInvites
    const hasPayment = isDirectlySubscribed || paidInviteCount >= config.requiredPaidInvites;
    return hasInvites && hasPayment;
  };

  const getTierLockReason = (tier: TierLevel): string | null => {
    const config = TIERS_CONFIG[tier];
    const hasInvites = inviteCount >= config.requiredInvites;
    const hasPayment = !config.requiresPayment || isDirectlySubscribed || paidInviteCount >= config.requiredPaidInvites;

    if (!hasInvites && !hasPayment) {
      return `تحتاج إلى ${config.requiredInvites} دعوة (لديك ${inviteCount}) واشتراك مدفوع (منك أو من ${config.requiredPaidInvites} مدعوين)`;
    }
    if (!hasInvites) {
      return `تحتاج إلى ${config.requiredInvites - inviteCount} دعوة إضافية للوصول لهذا المستوى`;
    }
    if (!hasPayment) {
      return `هذا المستوى إجباري الدفع: اشترك بنفسك أو اجعل ${config.requiredPaidInvites} من أصدقائك المدعوين يشتركون (مشترك منهم: ${paidInviteCount}/${config.requiredPaidInvites})`;
    }
    return null;
  };

  // Determine current active tier (highest accessible)
  let currentTier: TierLevel = 1;
  for (let t = 5; t >= 1; t--) {
    if (canAccessTier(t as TierLevel)) {
      currentTier = t as TierLevel;
      break;
    }
  }

  return {
    currentTier,
    canAccessTier,
    getTierLockReason,
  };
}
