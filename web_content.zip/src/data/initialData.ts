import { Product, ServiceItem, ShopSettings } from '../types';

export const INITIAL_SHOP_SETTINGS: ShopSettings = {
  shopName: 'A K Golu Computer',
  tagline: {
    en: 'Computer & Laptop Sales & Repair | CCTV Cameras | Printer Service & Networking',
    hi: 'कंप्यूटर और लैपटॉप बिक्री व रिपेयर | सीसीटीवी कैमरा | प्रिंटर सर्विस और नेटवर्किंग'
  },
  phone1: '7054304313',
  phone2: '8726356413',
  addressLine1: 'Main Market Road, Near Power House & Bus Stand',
  addressLine2: 'A K Golu Computer & CCTV Center',
  cityState: 'Uttar Pradesh',
  pincode: '226001',
  landmark: 'Opposite State Bank ATM',
  openingHours: {
    en: 'Monday - Saturday: 9:30 AM to 8:30 PM | Sunday: 10:00 AM to 4:00 PM',
    hi: 'सोमवार - शनिवार: सुबह 9:30 से रात 8:30 | रविवार: सुबह 10:00 से शाम 4:00'
  },
  googleMapsEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3559.873214561234!2d80.9462!3d26.8467!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDUwJzQ4LjEiTiA4MMKwNTYnNDYuMyJF!5e0!3m2!1sen!2sin!4v1600000000000!5m2!1sen!2sin',
  googleMapsDirectionsUrl: 'https://maps.google.com/?q=A+K+Golu+Computer',
  upiId: '7054304313@upi',
  adminPin: 'golu123'
};

export const INITIAL_PRODUCTS: Product[] = [
  // Refurbished Laptops
  {
    id: 'prod-lap-dell-7490',
    name: {
      en: 'Dell Latitude 7490 (Refurbished Grade-A)',
      hi: 'डेल लैटीट्यूड 7490 (रिफर्बिश्ड ग्रेड-ए लैपटॉप)'
    },
    category: 'laptops_refurbished',
    price: 18499,
    originalPrice: 65000,
    condition: 'refurbished',
    inStock: true,
    featured: true,
    brand: 'Dell',
    image: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Intel Core i5 8th Gen Processor',
        '8GB DDR4 RAM (Upgradable to 32GB)',
        '256GB High-Speed NVMe SSD',
        '14.0" Full HD Anti-Glare Display',
        'Original Charger + Backlit Keyboard',
        'Windows 11 Pro + MS Office Pre-installed'
      ],
      hi: [
        'इंटेल कोर i5 8th Gen प्रोसेसर',
        '8GB DDR4 रैम (32GB तक अपग्रेडेबल)',
        '256GB हाई-स्पीड NVMe SSD',
        '14.0 इंच फुल एचडी स्क्रीन',
        'ओरिजिनल चार्जर + बैकलिट कीबोर्ड',
        'विंडोज़ 11 प्रो और एमएस ऑफिस रेडी'
      ]
    },
    warranty: {
      en: '6 Months Shop Testing Warranty + 1 Year Free Software Support',
      hi: '6 महीने शॉप टेस्टिंग वारंटी + 1 साल फ्री सॉफ्टवेयर सपोर्ट'
    }
  },
  {
    id: 'prod-lap-hp-elitebook',
    name: {
      en: 'HP EliteBook 840 G5 Metal Body (Refurbished)',
      hi: 'एचपी एलीटबुक 840 G5 मेटल बॉडी (रिफर्बिश्ड)'
    },
    category: 'laptops_refurbished',
    price: 21999,
    originalPrice: 72000,
    condition: 'refurbished',
    inStock: true,
    featured: true,
    brand: 'HP',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Intel Core i5 8th Gen Quad-Core',
        '16GB DDR4 High-Performance RAM',
        '512GB Ultra-Fast M.2 SSD',
        'Bang & Olufsen Premium Audio',
        'Slim Lightweight Silver Metal Body',
        'Battery Backup 3-4 Hours'
      ],
      hi: [
        'इंटेल कोर i5 8th Gen क्वाड-कोर',
        '16GB DDR4 हाई-परफॉर्मेंस रैम',
        '512GB सुपरफास्ट M.2 SSD',
        'बैंग एंड ओल्फसेन प्रीमियम साउंड',
        'स्लिम और हल्की मेटल बॉडी',
        '3-4 घंटे बैटरी बैकअप'
      ]
    },
    warranty: {
      en: '6 Months Shop Warranty + 1 Month Battery Warranty',
      hi: '6 महीने शॉप वारंटी + 1 महीना बैटरी वारंटी'
    }
  },
  {
    id: 'prod-lap-lenovo-thinkpad',
    name: {
      en: 'Lenovo ThinkPad T480 Heavy-Duty Business Laptop',
      hi: 'लेनोवो थिंकपैड T480 बिज़नेस लैपटॉप (मजबूत बॉडी)'
    },
    category: 'laptops_refurbished',
    price: 19999,
    originalPrice: 68000,
    condition: 'refurbished',
    inStock: true,
    featured: false,
    brand: 'Lenovo',
    image: 'https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Intel Core i5 8th Gen',
        '8GB DDR4 RAM / 256GB SSD',
        'Dual Battery Technology for Long Backup',
        'Legendary Spill-Resistant Keyboard',
        'Type-C Fast Charging Support'
      ],
      hi: [
        'इंटेल कोर i5 8th Gen',
        '8GB DDR4 रैम / 256GB SSD',
        'लंबा बैकअप देने वाली ड्यूल बैटरी तकनीक',
        'मजबूत वाटर-रेसिस्टेंट कीबोर्ड',
        'टाइप-सी फास्ट चार्जिंग'
      ]
    },
    warranty: {
      en: '6 Months Shop Warranty + Free Bag & Mouse',
      hi: '6 महीने शॉप वारंटी + फ्री लैपटॉप बैग और माउस'
    }
  },

  // New Laptops
  {
    id: 'prod-lap-new-asus-vivobook',
    name: {
      en: 'ASUS VivoBook 15 (Brand New Seal Packed)',
      hi: 'आसुस वीवोबुक 15 (ब्रांड न्यू सील पैक)'
    },
    category: 'laptops_new',
    price: 36499,
    originalPrice: 45990,
    condition: 'new',
    inStock: true,
    featured: true,
    brand: 'ASUS',
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Intel Core i3 12th Gen 1215U',
        '8GB RAM (DDR4 3200MHz)',
        '512GB PCIe Gen 4.0 SSD',
        '15.6" Full HD NanoEdge Bezel',
        'Genuine Windows 11 Home + MS Office 2021',
        'Fingerprint Sensor & Fast Charge'
      ],
      hi: [
        'इंटेल कोर i3 12th Gen 1215U',
        '8GB रैम (DDR4 3200MHz)',
        '512GB PCIe 4.0 फास्ट SSD',
        '15.6 इंच फुल एचडी बेज़ेल-लेस स्क्रीन',
        'ओरिजिनल विंडोज़ 11 + ऑफिस 2021',
        'फिंगरप्रिंट सेंसर व फास्ट चार्जिंग'
      ]
    },
    warranty: {
      en: '1 Year ASUS Official On-Site Warranty Across India',
      hi: '1 साल आसुस ऑफिशियल ऑन-साइट वारंटी (पूरे भारत में)'
    }
  },

  // Desktops & Computers
  {
    id: 'prod-pc-assembled-office',
    name: {
      en: 'Assembled Office & CSC Center Desktop Full PC Set',
      hi: 'ऑफिस और सीएससी सेंटर के लिए फुल कंप्यूटर सेट'
    },
    category: 'computers_desktops',
    price: 14999,
    originalPrice: 22000,
    condition: 'new',
    inStock: true,
    featured: true,
    brand: 'AK Golu Custom Build',
    image: 'https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Intel Core i5 Processor',
        'H55/H61 Motherboard with 3 Yrs Warranty',
        '8GB High-Speed RAM',
        '256GB Solid State Drive (Super Fast 5s Boot)',
        '19-inch LED Monitor (HDMI & VGA)',
        'Multimedia Keyboard & Optical USB Mouse',
        'Cabinet with SMPS Power Supply + Wi-Fi Dongle'
      ],
      hi: [
        'इंटेल कोर i5 प्रोसेसर',
        'H55/H61 मदरबोर्ड (3 साल वारंटी)',
        '8GB हाई स्पीड रैम',
        '256GB SSD (5 सेकंड में स्टार्ट)',
        '19 इंच एलईडी मॉनिटर (एचडीएमआई/वीजीए)',
        'मल्टीमीडिया कीबोर्ड व ऑप्टिकल माउस',
        'कैबिनेट, एसएमपीएस व वाईफाई डोंगल शामिल'
      ]
    },
    warranty: {
      en: '1 Year Full Replacement Warranty on Components',
      hi: '1 साल पार्ट्स पर फुल रिप्लेसमेंट वारंटी'
    }
  },
  {
    id: 'prod-pc-gaming-i7',
    name: {
      en: 'RGB Gaming & Video Editing PC Beast',
      hi: 'आरजीबी गेमिंग और वीडियो एडिटिंग पीसी (सुपरफास्ट)'
    },
    category: 'computers_desktops',
    price: 38999,
    originalPrice: 52000,
    condition: 'new',
    inStock: true,
    featured: false,
    brand: 'AK Golu Custom Gaming',
    image: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Intel Core i7 Processor',
        '16GB Dual-Channel DDR4 RAM',
        '512GB NVMe M.2 SSD + 1TB Hard Disk',
        'Dedicated Graphics Card (GTX Series Support)',
        'Gaming Cabinet with 4x ARGB Ring Fans & Tempered Glass',
        '550W 80-Plus Bronze Certified SMPS'
      ],
      hi: [
        'इंटेल कोर i7 प्रोसेसर',
        '16GB ड्यूल चैनल रैम',
        '512GB NVMe SSD + 1TB हार्ड डिस्क',
        'डेडिकेटेड ग्राफिक्स कार्ड सपोर्ट',
        '4x आरजीबी कूलिंग फैन व टेम्पर्ड ग्लास कैबिनेट',
        '550W 80-प्लस ब्रॉन्ज सर्टिफाइड एसएमपीएस'
      ]
    },
    warranty: {
      en: '2 Years AK Golu Workshop Warranty & Lifetime Support',
      hi: '2 साल वर्कशॉप वारंटी और लाइफटाइम टेक्निकल सपोर्ट'
    }
  },

  // CCTV Surveillance & DVR/NVR
  {
    id: 'prod-cctv-hikvision-4cam-kit',
    name: {
      en: 'Hikvision 4-Camera HD Night Vision CCTV Full Kit',
      hi: 'हिकविज़न 4 कैमरा नाइट विज़न सीसीटीवी फुल किट'
    },
    category: 'cctv_surveillance',
    price: 11999,
    originalPrice: 16500,
    condition: 'new',
    inStock: true,
    featured: true,
    brand: 'Hikvision',
    image: 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        '4x Hikvision 2MP (1080P) Full HD Cameras (2 Dome + 2 Bullet)',
        '1x Hikvision 4-Channel Turbo HD DVR (Metal Body)',
        '1x 1TB Surveillance Hard Disk (Seagate/WD Purple)',
        '4-Channel Heavy SMPS Power Supply',
        '90-Meter Copper CCTV Cable Coil + BNC & DC Connectors',
        'Mobile Phone Live View Setup on Hik-Connect App'
      ],
      hi: [
        '4x हिकविज़न 2MP फुल एचडी कैमरे (2 इनडोर + 2 आउटडोर)',
        '1x हिकविज़न 4-चैनल टर्बो एचडी मेटल DVR',
        '1TB सर्विलांस स्पेशल हार्ड डिस्क (24/7 रिकॉर्डिंग)',
        '4-चैनल हेवी ड्यूटी पावर सप्लाई',
        '90 मीटर कॉपर केबल + सभी बीएनसी/डीसी कनेक्टर',
        'मोबाइल फोन पर लाइव देखने की पूरी सेटिंग'
      ]
    },
    warranty: {
      en: '2 Years Manufacturer Brand Warranty + Free Installation Guidance',
      hi: '2 साल कंपनी वारंटी + इंस्टॉलेशन सहायता'
    }
  },
  {
    id: 'prod-cctv-cpplus-wifi-4g',
    name: {
      en: 'CP PLUS 3MP Smart Wi-Fi 360° Pan-Tilt Camera (Audio)',
      hi: 'सीपी प्लस 3MP स्मार्ट वाई-फाई 360° कैमरा (माइक व स्पीकर)'
    },
    category: 'cctv_surveillance',
    price: 2199,
    originalPrice: 3800,
    condition: 'new',
    inStock: true,
    featured: true,
    brand: 'CP PLUS',
    image: 'https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        '3 Megapixel Ultra-Clear Resolution',
        '360° Panoramic View (Pan & Tilt via Mobile)',
        'Two-Way Audio (Listen and Talk from Phone)',
        'Smart Motion Tracking & Human Detection Alert',
        'MicroSD Card Slot up to 256GB + Cloud Storage',
        'Works with Mobile Wi-Fi & Hotspot'
      ],
      hi: [
        '3 मेगापिक्सल अल्ट्रा एचडी क्लैरिटी',
        '360 डिग्री पूरा कमरा घूमाकर देखें मोबाइल से',
        'दोनों तरफ से बात करने वाला माइक और स्पीकर',
        'इंसान की हलचल पर मोबाइल पर तुरंत सायरन/अलर्ट',
        '256GB मेमोरी कार्ड सपोर्ट',
        'आसान प्लग एंड प्ले सेटअप'
      ]
    },
    warranty: {
      en: '1 Year CP PLUS Brand Warranty',
      hi: '1 साल सीपी प्लस कंपनी वारंटी'
    }
  },
  {
    id: 'prod-cctv-hikvision-8ch-dvr',
    name: {
      en: 'Hikvision 8-Channel Turbo HD DVR Recorder',
      hi: 'हिकविज़न 8-चैनल टर्बो एचडी डीवीआर रिकॉर्डर'
    },
    category: 'cctv_surveillance',
    price: 3499,
    originalPrice: 5200,
    condition: 'new',
    inStock: true,
    featured: false,
    brand: 'Hikvision',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Supports up to 8 Analog/HD Cameras + 2 IP Cameras',
        'H.265+ Compression Saves 75% Storage Space',
        'HDMI & VGA 1080P Simultaneous Output',
        'Audio via Coaxial Cable Support',
        'Motion Detection 2.0 with Human/Vehicle Filtering'
      ],
      hi: [
        '8 एचडी कैमरे और 2 आईपी कैमरे तक सपोर्ट',
        'H.265+ तकनीक जिससे हार्ड डिस्क में 4 गुना ज्यादा रिकॉर्डिंग',
        'एचडीएमआई और वीजीए दोनों डिस्प्ले पोर्ट',
        'बिना अलग तार के आवाज रिकॉर्डिंग सपोर्ट',
        'स्मार्ट ह्यूमन व व्हीकल मोशन डिटेक्शन'
      ]
    },
    warranty: {
      en: '2 Years Manufacturer Warranty',
      hi: '2 साल निर्माता वारंटी'
    }
  },

  // Printers & Cartridges
  {
    id: 'prod-print-hp-laserjet-1020',
    name: {
      en: 'HP LaserJet 1020 Plus Heavy-Duty Monolith Printer',
      hi: 'एचपी लेज़रजेट 1020 प्लस रफ-एंड-टफ प्रिंटर (दुकान व ऑफिस)'
    },
    category: 'printers_toner',
    price: 14499,
    originalPrice: 17800,
    condition: 'new',
    inStock: true,
    featured: true,
    brand: 'HP',
    image: 'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'India’s Most Trusted 12A Cartridge Model',
        'Refilling Cost Only ₹200-₹250 per 2000 Pages',
        '14 Pages per Minute Fast Laser Printing',
        'Zero Paper Jam Heavy Duty Roller',
        'Compact Design for Cyber Cafe & Accounts Desk'
      ],
      hi: [
        'भारत का सबसे भरोसेमंद 12A कार्ट्रिज वाला मॉडल',
        'रिफिलिंग का खर्च मात्र ₹200-₹250 में 2000 पेज प्रिंट',
        '14 पेज प्रति मिनट तेज लेजर प्रिंटिंग',
        'कभी पेपर न फंसने वाला हैवी रोलर सिस्टम',
        'साइबर कैफे, सीएससी और दुकानों के लिए बेस्ट'
      ]
    },
    warranty: {
      en: '1 Year HP India Warranty',
      hi: '1 साल एचपी इंडिया कंपनी वारंटी'
    }
  },
  {
    id: 'prod-print-epson-l3210-allinone',
    name: {
      en: 'Epson EcoTank L3210 All-in-One Ink Tank Printer',
      hi: 'एप्सन इकोटैंक L3210 ऑल-इन-वन कलर प्रिंटर (प्रिंट, स्कैन, कॉपी)'
    },
    category: 'printers_toner',
    price: 12999,
    originalPrice: 15499,
    condition: 'new',
    inStock: true,
    featured: false,
    brand: 'Epson',
    image: 'https://images.unsplash.com/photo-1589739900266-43b2843f4c12?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Print, Scan, Copy in Vivid Color',
        'Super Low Cost: 7 Paise (Black) & 18 Paise (Color)',
        'Spill-Free Ink Refilling Bottle System',
        'Includes 4 Original Ink Bottles in the Box',
        'High Resolution Borderless Photo Printing'
      ],
      hi: [
        'कलर फोटो प्रिंट, स्कैन और फोटोकॉपी एक ही मशीन में',
        'अति सस्ता प्रिंट: 7 पैसे ब्लैक और 18 पैसे कलर',
        'आसानी से घर पर बोतल से इंक भरने की सुविधा',
        'बॉक्स में 4 ओरिजिनल इंक बोतल साथ मिलेंगी',
        'पासपोर्ट साइज फोटो और डॉक्यूमेंट्स के लिए बेस्ट'
      ]
    },
    warranty: {
      en: '1 Year or 30,000 Prints Epson India Warranty',
      hi: '1 साल या 30,000 प्रिंट एप्सन वारंटी'
    }
  },
  {
    id: 'prod-print-cartridge-12a',
    name: {
      en: 'ProDot / Formujet 12A High-Yield Black Laser Cartridge',
      hi: '12A हाई-यील्ड ब्लैक लेज़र टोनर कार्ट्रिज'
    },
    category: 'printers_toner',
    price: 599,
    originalPrice: 1200,
    condition: 'new',
    inStock: true,
    featured: false,
    brand: 'ProDot',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Compatible with HP 1020 Plus, 1005 MFD, Canon 2900B',
        'Up to 2,000 Deep Dark Crisp Pages',
        'High-Grade OPC Drum with Smooth Gear',
        'Refillable 3-4 Times with Quality Toner Powder'
      ],
      hi: [
        'HP 1020, 1005 और Canon 2900B प्रिंटर्स में कम्पैटिबल',
        '2000 पन्नों तक डार्क और साफ प्रिंट',
        'हाई क्वालिटी ओपीसी ड्रम',
        'बाद में 3-4 बार रिफिल कराने योग्य'
      ]
    },
    warranty: {
      en: 'Testing Warranty + Page Yield Guarantee',
      hi: 'शॉप टेस्टिंग वारंटी'
    }
  },

  // Accessories & Networking
  {
    id: 'prod-acc-crucial-500gb-ssd',
    name: {
      en: 'Crucial BX500 500GB 2.5" SATA SSD (Laptop & PC Boost)',
      hi: 'क्रूशियल 500GB SSD (लैपटॉप व पीसी को बनाए 10 गुना तेज)'
    },
    category: 'accessories_networking',
    price: 2799,
    originalPrice: 4500,
    condition: 'new',
    inStock: true,
    featured: true,
    brand: 'Crucial',
    image: 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Read Speed up to 540 MB/s (10x Faster than HDD)',
        'Revives Slow Laptops & Desktop PCs instantly',
        'Low Power Consumption & Shock Resistant',
        'Free OS / Windows Cloning Installation Service at Shop'
      ],
      hi: [
        'रीड स्पीड 540 MB/s (पुराने कंप्यूटर को बनाए रॉकेट)',
        'धीमे लैपटॉप को तुरंत तेज करने का बेस्ट समाधान',
        'कम बिजली खपत व मजबूत सॉलिड स्टेट',
        'दुकान पर फ्री विंडोज़ सेटअप उपलब्ध'
      ]
    },
    warranty: {
      en: '3 Years Official Brand Replacement Warranty',
      hi: '3 साल कंपनी डायरेक्ट रिप्लेसमेंट वारंटी'
    }
  },
  {
    id: 'prod-acc-tp-link-router',
    name: {
      en: 'TP-Link TL-WR845N 300Mbps High-Gain 3-Antenna Wi-Fi Router',
      hi: 'टीपी-लिंक 3-एंटीना हाई-स्पीड वाई-फाई राउटर'
    },
    category: 'accessories_networking',
    price: 1199,
    originalPrice: 1899,
    condition: 'new',
    inStock: true,
    featured: false,
    brand: 'TP-Link',
    image: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        '3x 5dBi High-Gain Antennas for Large Home/Shop Coverage',
        '300Mbps Wireless Speed for Smooth Video & CCTV Streaming',
        'Easy Setup with Tether Mobile App',
        'Parental Controls & Guest Wi-Fi Network Support'
      ],
      hi: [
        '3x 5dBi बड़े एंटीना से पूरे घर और दुकान में मजबूत सिग्नल',
        '300Mbps स्पीड - सीसीटीवी व वीडियो कॉलिंग के लिए उपयुक्त',
        'मोबाइल ऐप से आसान पासवर्ड और यूजर कंट्रोल',
        'गेस्ट नेटवर्क और स्पीड लिमिट फीचर'
      ]
    },
    warranty: {
      en: '3 Years TP-Link Warranty',
      hi: '3 साल टीपी-लिंक कंपनी वारंटी'
    }
  },
  {
    id: 'prod-acc-zebronics-kb-mouse',
    name: {
      en: 'Zebronics Judwaa USB Keyboard & Optical Mouse Combo',
      hi: 'ज़ेब्रोनिक्स कीबोर्ड और ऑप्टिकल माउस कॉम्बो'
    },
    category: 'accessories_networking',
    price: 499,
    originalPrice: 850,
    condition: 'new',
    inStock: true,
    featured: false,
    brand: 'Zebronics',
    image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80',
    specs: {
      en: [
        'Rupee (₹) Symbol Dedicated Key',
        'Silent Membrane Keys with UV Coated Characters',
        '1200 DPI High-Precision Optical Mouse',
        'Plug & Play USB for Windows, Mac & Linux'
      ],
      hi: [
        'रुपये (₹) सिंबल वाली स्पेशल की',
        'मखमली और साइलेंट टाइपिंग कीज',
        '1200 DPI तेज ऑप्टिकल माउस',
        'प्लग एंड प्ले - किसी भी कंप्यूटर में तुरंत चालू'
      ]
    },
    warranty: {
      en: '1 Year Zebronics Warranty',
      hi: '1 साल कंपनी वारंटी'
    }
  }
];

export const INITIAL_SERVICES: ServiceItem[] = [
  {
    id: 'serv-laptop-repair',
    name: {
      en: 'Laptop & Computer Repair (Chip-Level)',
      hi: 'लैपटॉप और कंप्यूटर रिपेयरिंग (चिप-लेवल)'
    },
    category: 'laptop_pc',
    icon: 'Laptop',
    description: {
      en: 'Motherboard repairing, broken screen replacement, body hinges repair, keyboard/touchpad fixing, heating issue resolving & SSD speed upgrade.',
      hi: 'मदरबोर्ड रिपेयर, टूटी स्क्रीन बदलना, बॉडी हिंज रिपेयर, कीबोर्ड/टचपैड ठीक करना, हीटिंग दूर करना व एसएसडी स्पीड बूस्ट।'
    },
    estimatedTime: {
      en: 'Same Day to 24 Hours',
      hi: 'उसी दिन से 24 घंटे के अंदर'
    },
    startingPrice: 299,
    homeServiceAvailable: true
  },
  {
    id: 'serv-windows-software',
    name: {
      en: 'Windows Installation & Software Support',
      hi: 'विंडोज़ इंस्टॉलेशन और सॉफ्टवेयर सपोर्ट'
    },
    category: 'windows_software',
    icon: 'Terminal',
    description: {
      en: 'Fresh Windows 10/11 setup, MS Office activation, Tally Prime / GST billing software setup, driver updates, virus & slow speed cleanup.',
      hi: 'विंडोज़ 10/11 नई इनस्टॉल करना, एमएस ऑफिस, टैली प्राइम/जीएसटी बिलिंग सॉफ्टवेयर, एंटीवायरस और धीमे कंप्यूटर की स्पीड बढ़ाना।'
    },
    estimatedTime: {
      en: '1 - 2 Hours',
      hi: '1 से 2 घंटे'
    },
    startingPrice: 350,
    homeServiceAvailable: true
  },
  {
    id: 'serv-cctv-install',
    name: {
      en: 'CCTV Camera Sales & Complete Installation',
      hi: 'सीसीटीवी कैमरा बिक्री व नई फिटिंग/इंस्टॉलेशन'
    },
    category: 'cctv',
    icon: 'Video',
    description: {
      en: 'New camera wiring and mounting for homes, shops, warehouses & schools. Night vision dome/bullet camera fitting with neat wire casing.',
      hi: 'घर, दुकान, गोदाम व स्कूल के लिए नए कैमरों की फिटिंग, साफ-सुथरी वायरिंग और रात में साफ दिखने वाले नाइट विज़न कैमरे लगाना।'
    },
    estimatedTime: {
      en: 'Site Inspection + 1 Day Setup',
      hi: 'साइट मुआयना + 1 दिन में चालू'
    },
    startingPrice: 499,
    homeServiceAvailable: true
  },
  {
    id: 'serv-dvr-nvr-config',
    name: {
      en: 'DVR/NVR Configuration & Mobile Online Setup',
      hi: 'डीवीआर/एनवीआर रिपेयर व मोबाइल पर ऑनलाइन सेटिंग'
    },
    category: 'dvr_nvr',
    icon: 'HardDrive',
    description: {
      en: 'DVR password reset, hard disk recording failure fix, connecting CCTV to Wi-Fi router so you can watch live video on your mobile phone anywhere.',
      hi: 'डीवीआर पासवर्ड भूल जाने पर रीसेट करना, रिकॉर्डिंग बंद होने पर ठीक करना और मोबाइल फोन पर दुनिया में कहीं से भी लाइव देखने की सेटिंग।'
    },
    estimatedTime: {
      en: '1 - 3 Hours',
      hi: '1 से 3 घंटे'
    },
    startingPrice: 350,
    homeServiceAvailable: true
  },
  {
    id: 'serv-printer-cartridge',
    name: {
      en: 'Printer Repair & Laser Toner Refilling',
      hi: 'प्रिंटर रिपेयरिंग और लेज़र टोनर रिफिलिंग'
    },
    category: 'printer',
    icon: 'Printer',
    description: {
      en: '12A/88A/85A cartridge toner refilling with deep black ink, paper jamming fix, light print repair, ink tank head cleaning & roller replacement.',
      hi: '12A/88A/85A लेज़र टोनर मात्र 10 मिनट में रिफिल, पेपर फंसने की समस्या, हल्का प्रिंट आना ठीक करना, हेड क्लीनिंग व रोलर बदलना।'
    },
    estimatedTime: {
      en: '15 Mins (Refill) / Same Day (Repair)',
      hi: '15 मिनट (रिफिल) / उसी दिन (रिपेयर)'
    },
    startingPrice: 200,
    homeServiceAvailable: true
  },
  {
    id: 'serv-networking-wifi',
    name: {
      en: 'Office Networking, LAN Cabling & Wi-Fi Extenders',
      hi: 'ऑफिस नेटवर्किंग, लैन केबल वायरिंग व वाई-फाई'
    },
    category: 'networking',
    icon: 'Network',
    description: {
      en: 'CAT6 LAN crimping, switch setup, router installation, Wi-Fi range extender setup for multi-floor buildings & sharing printers across PCs.',
      hi: 'लैन केबल क्लिपिंग, इंटरनेट स्विच, वाई-फाई रेंज बढ़ाने वाले एक्सटेंडर लगाना और एक प्रिंटर को कई कंप्यूटरों से कनेक्ट करना।'
    },
    estimatedTime: {
      en: '2 - 4 Hours',
      hi: '2 से 4 घंटे'
    },
    startingPrice: 450,
    homeServiceAvailable: true
  }
];

export const SPECIAL_OFFERS = [
  {
    id: 'offer-cctv-combo',
    title: {
      en: 'CCTV Security Super Saver Package',
      hi: 'सीसीटीवी सुरक्षा महा बचत पैकेज'
    },
    tag: {
      en: 'Best Value for Home & Shop',
      hi: 'दुकान और घर के लिए बेस्ट'
    },
    price: 11999,
    mrp: 16500,
    description: {
      en: '4 Hikvision Full HD Night Vision Cameras + 4-Ch Metal DVR + 1TB Hard Disk + Power Supply + Wire + Free Mobile Setup!',
      hi: '4 हिकविज़न नाइट विज़न कैमरे + 4-चैनल मेटल DVR + 1TB हार्ड डिस्क + पावर सप्लाई + वायर + मोबाइल पर फ्री ऑनलाइन सेटअप!'
    },
    expiryText: {
      en: 'Limited Stock Offer - Book Today',
      hi: 'सीमित स्टॉक ऑफर - आज ही बुक करें'
    }
  },
  {
    id: 'offer-laptop-speed-combo',
    title: {
      en: 'Slow Laptop Speed Booster Combo',
      hi: 'धीमे लैपटॉप को बनाएं रॉकेट कॉम्बो'
    },
    tag: {
      en: 'Speed Guarantee',
      hi: '10 गुना स्पीड की गारंटी'
    },
    price: 2499,
    mrp: 3800,
    description: {
      en: '256GB High-Speed SSD + Windows 11/10 Installation + Old Data Transfer + Full Thermal Paste Service & Dust Cleaning!',
      hi: '256GB हाई स्पीड SSD + नई विंडोज़ 10/11 + पुराना डेटा ट्रांसफर + कूलिंग पेस्ट सर्विस व धूल की सफाई!'
    },
    expiryText: {
      en: 'Includes Free Installation at Shop',
      hi: 'दुकान पर फ्री इंस्टॉलेशन शामिल'
    }
  }
];
