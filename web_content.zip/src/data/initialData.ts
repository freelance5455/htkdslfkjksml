import { Product, Customer, StoreSettings, CodeFile, Invoice } from '../types';

export const initialStoreSettings: StoreSettings = {
  storeName: 'مؤسسة التجارة الحديثة',
  storeNameEn: 'Modern Retail Trading',
  taxNumber: '310298475600003',
  commercialReg: '1010784920',
  phone: '0501234567',
  address: 'الرياض - طريق الملك فهد - المملكة العربية السعودية',
  currency: 'ر.س',
  vatRate: 15,
  enableVat: true,
  receiptFooter: 'شكراً لزيارتكم ونسعد بخدمتكم دائماً! البضاعة المباعة ترد وتستبدل خلال 3 أيام.',
  cashierName: 'أحمد محمود',
};

export const initialCategories: string[] = [
  'مواد غذائية',
  'مشروبات',
  'ألبان',
  'منظفات',
  'إلكترونيات',
  'عناية شخصية',
  'أخرى',
];

export const initialProducts: Product[] = [
  {
    id: 'prod-1',
    barcode: '6281001001',
    name: 'زيت زيتون بكر ممتاز 1 لتر',
    nameEn: 'Extra Virgin Olive Oil 1L',
    category: 'مواد غذائية',
    costPrice: 28.0,
    sellingPrice: 38.5,
    stock: 24,
    minStock: 5,
    unit: 'حبة',
  },
  {
    id: 'prod-2',
    barcode: '6281001002',
    name: 'أرز بسمتي هندي فاخر 5 كجم',
    nameEn: 'Premium Basmati Rice 5kg',
    category: 'مواد غذائية',
    costPrice: 42.0,
    sellingPrice: 58.0,
    stock: 18,
    minStock: 4,
    unit: 'كيس',
  },
  {
    id: 'prod-3',
    barcode: '6281001003',
    name: 'قهوة عربية أصيلة مع الهيل 500 جرام',
    nameEn: 'Arabic Coffee with Cardamom 500g',
    category: 'مشروبات',
    costPrice: 22.0,
    sellingPrice: 32.0,
    stock: 35,
    minStock: 8,
    unit: 'عبوة',
  },
  {
    id: 'prod-4',
    barcode: '6281001004',
    name: 'شاي سيلاني فاخر 100 كيس',
    nameEn: 'Ceylon Black Tea 100 Bags',
    category: 'مشروبات',
    costPrice: 11.5,
    sellingPrice: 17.0,
    stock: 40,
    minStock: 10,
    unit: 'علبة',
  },
  {
    id: 'prod-5',
    barcode: '6281001005',
    name: 'حليب كامل الدسم طويل الأجل 1 لتر',
    nameEn: 'Full Cream UHT Milk 1L',
    category: 'ألبان',
    costPrice: 3.8,
    sellingPrice: 5.5,
    stock: 60,
    minStock: 12,
    unit: 'كرتون',
  },
  {
    id: 'prod-6',
    barcode: '6281001006',
    name: 'سكر أبيض ناعم 2 كجم',
    nameEn: 'Refined White Sugar 2kg',
    category: 'مواد غذائية',
    costPrice: 6.5,
    sellingPrice: 9.5,
    stock: 3, // Low stock trigger!
    minStock: 6,
    unit: 'كيس',
  },
  {
    id: 'prod-7',
    barcode: '6281001007',
    name: 'مسحوق غسيل ملابس مركز 3 كجم',
    nameEn: 'Laundry Detergent Powder 3kg',
    category: 'منظفات',
    costPrice: 26.0,
    sellingPrice: 39.0,
    stock: 15,
    minStock: 5,
    unit: 'كيس',
  },
  {
    id: 'prod-8',
    barcode: '6281001008',
    name: 'مناديل ورقية ناعمة عبوة عائلية (6 علب)',
    nameEn: 'Facial Tissues Pack of 6',
    category: 'منظفات',
    costPrice: 14.0,
    sellingPrice: 21.0,
    stock: 2, // Low stock trigger!
    minStock: 8,
    unit: 'شدّة',
  },
  {
    id: 'prod-9',
    barcode: '6281001009',
    name: 'كابل شحن سريع Type-C إلى Type-C (1.5م)',
    nameEn: 'Fast Charging Cable Type-C 1.5m',
    category: 'إلكترونيات',
    costPrice: 12.0,
    sellingPrice: 25.0,
    stock: 28,
    minStock: 6,
    unit: 'قطعة',
  },
  {
    id: 'prod-10',
    barcode: '6281001010',
    name: 'شاحن جداري ذكي 30 واط منفذين',
    nameEn: 'Dual Port Smart Wall Charger 30W',
    category: 'إلكترونيات',
    costPrice: 29.0,
    sellingPrice: 49.0,
    stock: 14,
    minStock: 4,
    unit: 'قطعة',
  },
  {
    id: 'prod-11',
    barcode: '6281001011',
    name: 'عسل سدر طبيعي 500 جرام',
    nameEn: 'Natural Sidr Honey 500g',
    category: 'مواد غذائية',
    costPrice: 65.0,
    sellingPrice: 95.0,
    stock: 8,
    minStock: 3,
    unit: 'مرطبان',
  },
  {
    id: 'prod-12',
    barcode: '6281001012',
    name: 'معجون أسنان حماية متكاملة 100 مل',
    nameEn: 'Total Care Toothpaste 100ml',
    category: 'عناية شخصية',
    costPrice: 9.0,
    sellingPrice: 14.5,
    stock: 1, // Critically low!
    minStock: 5,
    unit: 'حبة',
  },
];

export const initialCustomers: Customer[] = [
  {
    id: 'cust-1',
    name: 'عبدالله بن فهد الشمري',
    phone: '0555123456',
    email: 'abdullah.f@example.com',
    balance: 145.0, // Existing debt
    notes: 'عميل دائم للتموينات الشهرية',
    createdAt: '2026-01-10T10:00:00Z',
  },
  {
    id: 'cust-2',
    name: 'محمد خالد السبيعي',
    phone: '0544987654',
    email: 'm.khalid@example.com',
    balance: 0.0,
    notes: 'يفضل الدفع بالبطاقة',
    createdAt: '2026-02-15T12:30:00Z',
  },
  {
    id: 'cust-3',
    name: 'مؤسسة إعمار الخليج للمقاولات',
    phone: '0500112233',
    email: 'procurement@emaar-gulf.com',
    balance: 420.0, // Company debt
    notes: 'فواتير ضريبية آجلة نهاية كل شهر',
    createdAt: '2026-03-01T09:15:00Z',
  },
];

export const initialInvoices: Invoice[] = [
  {
    id: 'inv-1001',
    invoiceNumber: 'INV-2026-001',
    date: new Date(Date.now() - 3600 * 1000 * 4).toISOString(),
    items: [
      { product: initialProducts[0], quantity: 2, discountPercent: 0 },
      { product: initialProducts[2], quantity: 1, discountPercent: 0 },
    ],
    subtotal: 109.0,
    taxRate: 15,
    taxAmount: 16.35,
    discountAmount: 0,
    grandTotal: 125.35,
    paymentMethod: 'cash',
    amountPaid: 150.0,
    changeAmount: 24.65,
    cashierName: 'أحمد محمود',
    customerName: 'عميل نقدي سريع',
    status: 'paid',
  },
  {
    id: 'inv-1002',
    invoiceNumber: 'INV-2026-002',
    date: new Date(Date.now() - 3600 * 1000 * 2).toISOString(),
    items: [
      { product: initialProducts[1], quantity: 1, discountPercent: 0 },
      { product: initialProducts[4], quantity: 4, discountPercent: 0 },
      { product: initialProducts[9], quantity: 1, discountPercent: 10 },
    ],
    subtotal: 124.1,
    taxRate: 15,
    taxAmount: 18.62,
    discountAmount: 4.9,
    grandTotal: 142.72,
    paymentMethod: 'card',
    amountPaid: 142.72,
    changeAmount: 0,
    cashierName: 'أحمد محمود',
    customerName: 'محمد خالد السبيعي',
    customerPhone: '0544987654',
    status: 'paid',
  },
  {
    id: 'inv-1003',
    invoiceNumber: 'INV-2026-003',
    date: new Date(Date.now() - 3600 * 1000 * 1).toISOString(),
    items: [
      { product: initialProducts[6], quantity: 2, discountPercent: 0 },
      { product: initialProducts[10], quantity: 1, discountPercent: 0 },
    ],
    subtotal: 173.0,
    taxRate: 15,
    taxAmount: 25.95,
    discountAmount: 0,
    grandTotal: 198.95,
    paymentMethod: 'debt',
    amountPaid: 0,
    changeAmount: 0,
    cashierName: 'أحمد محمود',
    customerId: 'cust-1',
    customerName: 'عبدالله بن فهد الشمري',
    customerPhone: '0555123456',
    status: 'pending',
    notes: 'آجل ومسجل في حساب العميل',
  },
];

export const initialCodeFiles: CodeFile[] = [
  {
    id: 'file-1',
    name: 'sales-analytics.ts',
    language: 'typescript',
    content: `/**
 * WinSales POS - Sales Performance & Profit Margin Calculator
 * Computes daily profit, gross margin percentage, and top selling products.
 */

export interface SalesRecord {
  invoiceId: string;
  totalCost: number;
  totalRevenue: number;
  itemsCount: number;
  timestamp: string;
}

export function calculateProfitSummary(records: SalesRecord[]) {
  const totalRevenue = records.reduce((sum, r) => sum + r.totalRevenue, 0);
  const totalCost = records.reduce((sum, r) => sum + r.totalCost, 0);
  const netProfit = totalRevenue - totalCost;
  const profitMarginPercent = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  return {
    totalRevenue: Number(totalRevenue.toFixed(2)),
    totalCost: Number(totalCost.toFixed(2)),
    netProfit: Number(netProfit.toFixed(2)),
    profitMarginPercent: Number(profitMarginPercent.toFixed(1)),
    transactionsCount: records.length,
  };
}

// Example usage
const todaySales: SalesRecord[] = [
  { invoiceId: 'INV-001', totalCost: 68.0, totalRevenue: 109.0, itemsCount: 3, timestamp: '2026-09-20T10:00:00Z' },
  { invoiceId: 'INV-002', totalCost: 83.8, totalRevenue: 124.1, itemsCount: 6, timestamp: '2026-09-20T12:00:00Z' },
];

console.log('Daily Summary:', calculateProfitSummary(todaySales));
`,
  },
  {
    id: 'file-2',
    name: 'inventory-audit.sql',
    language: 'sql',
    content: `-- SQL Query: Detect Low Stock Items & Calculate Reorder Cost
SELECT 
    id,
    barcode,
    name,
    category,
    stock AS current_stock,
    min_stock AS minimum_required,
    (min_stock * 2 - stock) AS suggested_order_qty,
    cost_price,
    ROUND((min_stock * 2 - stock) * cost_price, 2) AS estimated_reorder_cost
FROM products
WHERE stock <= min_stock
ORDER BY (min_stock - stock) DESC;

-- Daily Sales by Payment Method
SELECT 
    payment_method,
    COUNT(id) AS total_invoices,
    SUM(grand_total) AS total_amount,
    ROUND(AVG(grand_total), 2) AS average_ticket
FROM invoices
WHERE DATE(created_at) = CURRENT_DATE
GROUP BY payment_method;
`,
  },
  {
    id: 'file-3',
    name: 'barcode-validator.js',
    language: 'javascript',
    content: `/**
 * Fast Barcode Checksum Validator (EAN-13 & UPC-A)
 * Validates barcode input from USB barcode scanners or keyboard emulation.
 */
function validateEAN13(barcode) {
  const clean = String(barcode).trim();
  if (!/^\\d{13}$/.test(clean)) return false;

  let sum = 0;
  for (let i = 0; i < 12; i++) {
    const digit = parseInt(clean[i], 10);
    sum += i % 2 === 0 ? digit : digit * 3;
  }

  const checksum = (10 - (sum % 10)) % 10;
  return checksum === parseInt(clean[12], 10);
}

// Fast test cases
console.log('Valid EAN-13 (6281001001005):', validateEAN13('6281001001005'));
`,
  },
  {
    id: 'file-4',
    name: 'receipt-formatter.py',
    language: 'python',
    content: `# -*- coding: utf-8 -*-
"""
Thermal Receipt Generator (80mm ESC/POS layout)
Formats receipt data for 80mm roll printers on Windows
"""
def format_80mm_receipt(store_name, tax_no, invoice_no, items, total, vat):
    line = "-" * 42
    receipt = []
    receipt.append(store_name.center(42))
    receipt.append(f"الرقم الضريبي: {tax_no}".center(42))
    receipt.append(f"رقم الفاتورة: {invoice_no}".center(42))
    receipt.append(line)
    receipt.append(f"{'الصنف':<20}{'الكمية':^6}{'السعر':>8}{'الإجمالي':>8}")
    receipt.append(line)
    
    for item in items:
        item_line = f"{item['name'][:18]:<20}{item['qty']:^6}{item['price']:>8.2f}{item['total']:>8.2f}"
        receipt.append(item_line)
        
    receipt.append(line)
    receipt.append(f"{'ضريبة القيمة المضافة (15%):':<30}{vat:>12.2f}")
    receipt.append(f"{'المجموع الإجمالي النهائي:':<30}{total:>12.2f}")
    receipt.append(line)
    receipt.append("شكراً لتسوقكم معنا".center(42))
    return "\\n".join(receipt)
`,
  },
];
