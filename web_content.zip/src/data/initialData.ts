import { Achievement, DailyHabit, PersonalRecord, UserProfile, Workout } from '../types';

export const INITIAL_USER: UserProfile = {
  id: 'user_1',
  name: 'Alex Vance',
  athleteTitle: 'Calisthenics Athlete',
  bio: 'Calisthenics athlete chasing full planche & strict muscle-ups.',
  profileImage: '',
  createdAt: '2026-09-25T08:00:00.000Z',
  streak: 0,
  totalWorkouts: 0,
  totalTrainingTimeSec: 0,
  totalReps: 0,
  weeklyGoal: 4,
  units: 'metric',
  defaultRestTimeSec: 90,
  soundEnabled: true,
  vibrationEnabled: true,
  theme: 'dark'
};

export const INITIAL_PRS: PersonalRecord[] = [];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach_1',
    title: 'First Rep',
    description: 'Completed your very first calisthenics workout.',
    icon: 'Sparkles',
    category: 'consistency',
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'ach_2',
    title: '5 Workouts Strong',
    description: 'Logged 5 full training sessions in the books.',
    icon: 'Trophy',
    category: 'consistency',
    progress: 0,
    maxProgress: 5
  },
  {
    id: 'ach_3',
    title: 'Iron Consistency (10 Workouts)',
    description: 'Hit double digits with 10 completed workouts.',
    icon: 'Flame',
    category: 'consistency',
    progress: 0,
    maxProgress: 10
  },
  {
    id: 'ach_4',
    title: 'Bodyweight Beast (25 Workouts)',
    description: 'Completed 25 workouts. Tendons of titanium.',
    icon: 'Shield',
    category: 'consistency',
    progress: 0,
    maxProgress: 25
  },
  {
    id: 'ach_5',
    title: 'Centurion (100 Workouts)',
    description: 'Reach 100 total logged workouts.',
    icon: 'Crown',
    category: 'consistency',
    progress: 0,
    maxProgress: 100
  },
  {
    id: 'ach_6',
    title: '7-Day Streak',
    description: 'Maintained an unbroken daily calisthenics habit for 7 straight days.',
    icon: 'Zap',
    category: 'consistency',
    progress: 0,
    maxProgress: 7
  },
  {
    id: 'ach_7',
    title: 'Discipline Master (30-Day Streak)',
    description: 'Achieve a 30-day training streak.',
    icon: 'Award',
    category: 'consistency',
    progress: 0,
    maxProgress: 30
  },
  {
    id: 'ach_8',
    title: 'First Pull-Up PR',
    description: 'Set a new all-time personal best in Pull-Ups.',
    icon: 'TrendingUp',
    category: 'strength',
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'ach_9',
    title: 'Push-Up Prodigy',
    description: 'Surpassed 40 strict standard push-ups in a single set.',
    icon: 'Dumbbell',
    category: 'strength',
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'ach_10',
    title: 'Gravity Defier',
    description: 'Advanced to Level 3 or higher in any Calisthenics Skill.',
    icon: 'Feather',
    category: 'skill',
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'ach_11',
    title: 'Rucksack Warrior',
    description: 'Completed a workout utilizing loaded home backpack resistance.',
    icon: 'Package',
    category: 'strength',
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'ach_12',
    title: 'Routine Architect',
    description: 'Designed and saved a custom training routine.',
    icon: 'PenTool',
    category: 'builder',
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'ach_13',
    title: 'Elastic Armor',
    description: 'Integrated resistance band exercises to bulletproof joints and accelerate calisthenics skills.',
    icon: 'Activity',
    category: 'strength',
    progress: 0,
    maxProgress: 1
  }
];

export const INITIAL_WORKOUT_HISTORY: Workout[] = [];

export const INITIAL_DAILY_HABITS: DailyHabit[] = [
  {
    id: 'habit-hydration',
    title: 'Hydration (3.0L Water)',
    subtitle: 'Electrolytes & cellular tendon hydration',
    icon: 'droplets',
    completedDates: []
  },
  {
    id: 'habit-stretching',
    title: 'Mobility & Stretching',
    subtitle: '10 min wrist, thoracic & hip decompression',
    icon: 'stretch',
    completedDates: []
  },
  {
    id: 'habit-protein',
    title: 'High-Protein Nutrition',
    subtitle: 'Hit daily protein goal for muscle synthesis',
    icon: 'protein',
    completedDates: []
  },
  {
    id: 'habit-deadhang',
    title: 'Spinal Decompression Hang',
    subtitle: '2 min cumulative dead hang & scapular prep',
    icon: 'hang',
    completedDates: []
  },
  {
    id: 'habit-sleep',
    title: '8h Recovery Sleep',
    subtitle: 'Deep CNS & hormone regeneration',
    icon: 'sleep',
    completedDates: []
  }
];

