import { 
  Site, 
  Labour, 
  SiteAttendanceRecord, 
  LabourAdvancePayment, 
  EngineerPayment, 
  MessExpense, 
  MessCollection, 
  RoomOwnerConfig, 
  LandlordPayment 
} from '../types';

export const INITIAL_SITES: Site[] = [
  {
    id: 'site-1',
    name: 'নিউ টাউন অ্যাকশন এরিয়া ৩ রেসিডেন্সিয়াল কমপ্লেক্স',
    address: 'প্লট বি-১২, অ্যাকশন এরিয়া ৩, নিউ টাউন, কলকাতা - ৭০০০১৫৬',
    engineerName: 'ইঞ্জি. অসীম ব্যানার্জী',
    engineerPhone: '৯৮৩০১২৩৪৫৬',
    flatCommission: 65000, // নির্দিষ্ট ফ্ল্যাট কমিশন ₹৬৫,০০০ (কোনো % নয়)
    status: 'active',
    startDate: '2025-02-01',
    targetEndDate: '2025-05-30',
    notes: 'জি+৪ তলা বিল্ডিং নির্মাণ কাজ। প্রতি মাসে কিস্তিতে বিল ক্লিয়ারেন্স।'
  },
  {
    id: 'site-2',
    name: 'সল্টলেক সেক্টর ৫ কমার্শিয়াল রেনোভেশন',
    address: 'ইপি ব্লক, সেক্টর ৫, সল্টলেক, কলকাতা - ৭০০০৯১',
    engineerName: 'ইঞ্জি. সুব্রত মুখার্জী',
    engineerPhone: '৯৮৩১৬৭৮৯০১',
    flatCommission: 45000, // নির্দিষ্ট ফ্ল্যাট কমিশন ₹৪৫,০০০
    status: 'active',
    startDate: '2025-02-15',
    targetEndDate: '2025-04-15',
    notes: 'ইন্টেরিয়র ও ব্রিকওয়ার্ক পার্টিশন কাজ।'
  },
  {
    id: 'site-3',
    name: 'হাওড়া কদমতলা হাউজিং প্রজেক্ট',
    address: '৪৫ বেলিলিয়াস রোড, হাওড়া - ৭১১১০১',
    engineerName: 'ইঞ্জি. প্রদীপ দত্ত',
    engineerPhone: '৯৮৩২২২২৩৩৪',
    flatCommission: 35000,
    status: 'completed',
    startDate: '2024-11-01',
    targetEndDate: '2025-01-25',
    notes: 'কাজ সফলভাবে সমাপ্ত হয়েছে এবং সম্পূর্ণ বিল পরিশোধিত।'
  }
];

export const INITIAL_LABOURS: Labour[] = [
  {
    id: 'lab-1',
    name: 'স্বপন মণ্ডল',
    phone: '৯৭৪৮০১১২২৩',
    trade: 'হেড রাজমিস্ত্রি',
    roleType: 'mess_and_site', // মেসে থাকে ও সাইটে কাজ করে
    assignedSiteId: 'site-1',
    dailyWageRate: 750,
    messStayStartDate: '2025-01-01',
    messStayEndDate: null,
    isActive: true,
    notes: 'অভিজ্ঞ রাজমিস্ত্রি, মেসের খাদ্য কমিটির দায়িত্বে।',
    createdAt: '2025-01-01'
  },
  {
    id: 'lab-2',
    name: 'রহিম শেখ',
    phone: '৯৮৭৪৫৫৪৪৩২',
    trade: 'রড বাইন্ডার / ফিটার',
    roleType: 'mess_and_site', // মেসে থাকে ও সাইটে কাজ করে
    assignedSiteId: 'site-1',
    dailyWageRate: 650,
    messStayStartDate: '2025-01-10',
    messStayEndDate: null,
    isActive: true,
    notes: 'ছাদের রড বাঁধার প্রধান মিস্ত্রি।',
    createdAt: '2025-01-10'
  },
  {
    id: 'lab-3',
    name: 'বিকাশ পাত্র',
    phone: '৯৪৩৪১২৮৮৭৭',
    trade: 'জোগাড়ে / হেল্পার',
    roleType: 'mess_and_site', // মেসে থাকে ও সাইটে কাজ করে
    assignedSiteId: 'site-1',
    dailyWageRate: 480,
    messStayStartDate: '2025-02-01',
    messStayEndDate: null,
    isActive: true,
    notes: 'সাইটের সামগ্রী বহনের কাজ করে।',
    createdAt: '2025-02-01'
  },
  {
    id: 'lab-4',
    name: 'সুবীর দাস',
    phone: '৯৮৩০০১১২২১',
    trade: 'শাটারিং মিস্ত্রি',
    roleType: 'mess_and_site', // মেসে থাকে ও সাইটে কাজ করে
    assignedSiteId: 'site-2',
    dailyWageRate: 700,
    messStayStartDate: '2025-01-15',
    messStayEndDate: null,
    isActive: true,
    notes: 'শাটারিং ও সেন্টারিং কাজ করে।',
    createdAt: '2025-01-15'
  },
  {
    id: 'lab-5',
    name: 'জাহাঙ্গীর আলম',
    phone: '৮১০০৩৩৪৪৫৫',
    trade: 'পেইন্টার / রঙমিস্ত্রি',
    roleType: 'mess_only', // মেসে থাকে কিন্তু বাইরে নিজের কাজ খুঁজে খায়
    assignedSiteId: undefined,
    dailyWageRate: 650,
    messStayStartDate: '2025-02-05',
    messStayEndDate: null,
    isActive: true,
    notes: 'ব্যক্তিগতভাবে সেক্টর ৫ ও সল্টলেকে ফ্ল্যাট পেইন্টিং কাজ পায়। মেসে নিয়মিত থাকে।',
    createdAt: '2025-02-05'
  },
  {
    id: 'lab-6',
    name: 'দীপক রায়',
    phone: '৯১২৩৪৪৫৫৬৬',
    trade: 'ইলেকট্রিশিয়ান',
    roleType: 'mess_only', // মেসে থাকে কিন্তু বাইরে নিজের কাজ খুঁজে খায়
    assignedSiteId: undefined,
    dailyWageRate: 700,
    messStayStartDate: '2025-02-12',
    messStayEndDate: '2025-03-20', // ২০ মার্চ মেস ছেড়ে বাড়ি ফেরে
    isActive: true,
    notes: 'শহরে নিজস্ব ওয়্যারিং কাজ করে। ২০ মার্চ গ্রামের বাড়ি ফিরেছে।',
    createdAt: '2025-02-12'
  },
  {
    id: 'lab-7',
    name: 'অমর পাল',
    phone: '৯৭৩৩১১২২৩৩',
    trade: 'টাইলস মিস্ত্রি',
    roleType: 'site_only', // সাইটে কাজ করে কিন্তু মেসে থাকে না (স্থানীয় বাড়ি থেকে যাতায়াত করে)
    assignedSiteId: 'site-1',
    dailyWageRate: 750,
    messStayStartDate: '2025-02-10',
    messStayEndDate: null,
    isActive: true,
    notes: 'রাজারহাটে নিজের বাড়ি, প্রতিদিন সাইটে এসে কাজ করে চলে যায়। মেসে থাকে না।',
    createdAt: '2025-02-10'
  },
  {
    id: 'lab-8',
    name: 'নির্মল সর্দার',
    phone: '৯৮৭৬১০২০৩০',
    trade: 'জোগাড়ে / হেল্পার',
    roleType: 'site_only', // সাইটে কাজ করে কিন্তু মেসে থাকে না
    assignedSiteId: 'site-2',
    dailyWageRate: 480,
    messStayStartDate: '2025-02-15',
    messStayEndDate: null,
    isActive: true,
    notes: 'সল্টলেকের স্থানীয় লেবার। মেসের খাবার বা রুম ভাড়ার আওতাভুক্ত নয়।',
    createdAt: '2025-02-15'
  }
];

export const INITIAL_ATTENDANCE: SiteAttendanceRecord[] = [
  // সাইট ১ এর স্বপন মণ্ডল (২৬ দিন কাজ)
  { id: 'att-1', siteId: 'site-1', labourId: 'lab-1', date: '2025-03-01', daysWorked: 26, wageRate: 750, note: 'মার্চ মাসের মোট হাজিরা ২৬ দিন' },
  // সাইট ১ এর রহিম শেখ (২৪ দিন কাজ)
  { id: 'att-2', siteId: 'site-1', labourId: 'lab-2', date: '2025-03-01', daysWorked: 24, wageRate: 650, note: 'মার্চ মাসের মোট হাজিরা ২৪ দিন' },
  // সাইট ১ এর বিকাশ পাত্র (২৫ দিন কাজ)
  { id: 'att-3', siteId: 'site-1', labourId: 'lab-3', date: '2025-03-01', daysWorked: 25, wageRate: 480, note: 'মার্চ মাসের মোট হাজিরা ২৫ দিন' },
  // সাইট ১ এর অমর পাল (লোকাল লেবার, ২১ দিন কাজ)
  { id: 'att-4', siteId: 'site-1', labourId: 'lab-7', date: '2025-03-01', daysWorked: 21, wageRate: 750, note: 'মার্চ মাসের মোট হাজিরা ২১ দিন' },
  
  // সাইট ২ এর সুবীর দাস (২২ দিন কাজ)
  { id: 'att-5', siteId: 'site-2', labourId: 'lab-4', date: '2025-03-01', daysWorked: 22, wageRate: 700, note: 'মার্চ মাসের মোট হাজিরা ২২ দিন' },
  // সাইট ২ এর নির্মল সর্দার (২০ দিন কাজ)
  { id: 'att-6', siteId: 'site-2', labourId: 'lab-8', date: '2025-03-01', daysWorked: 20, wageRate: 480, note: 'মার্চ মাসের মোট হাজিরা ২০ দিন' }
];

export const INITIAL_LABOUR_ADVANCES: LabourAdvancePayment[] = [
  { id: 'adv-1', labourId: 'lab-1', siteId: 'site-1', date: '2025-03-07', amount: 4000, paymentMethod: 'cash', note: 'উৎসব ও পারিবারিক খরচ অগ্রিম' },
  { id: 'adv-2', labourId: 'lab-1', siteId: 'site-1', date: '2025-03-21', amount: 5000, paymentMethod: 'upi', note: 'দ্বিতীয় কিস্তিতে পার্ট পেমেন্ট' },
  { id: 'adv-3', labourId: 'lab-2', siteId: 'site-1', date: '2025-03-10', amount: 5000, paymentMethod: 'cash', note: 'বাড়ি পাঠানোর জন্য অগ্রিম' },
  { id: 'adv-4', labourId: 'lab-3', siteId: 'site-1', date: '2025-03-08', amount: 3000, paymentMethod: 'cash', note: 'মেসের খাওয়া ও হাতখরচ বাবদ অগ্রিম' },
  { id: 'adv-5', labourId: 'lab-4', siteId: 'site-2', date: '2025-03-12', amount: 4500, paymentMethod: 'cash', note: 'সাইট থেকে পার্ট পেমেন্ট' },
  { id: 'adv-6', labourId: 'lab-7', siteId: 'site-1', date: '2025-03-15', amount: 6000, paymentMethod: 'upi', note: 'সাইটের স্থানীয় লেবারকে পার্ট পেমেন্ট' }
];

export const INITIAL_ENGINEER_PAYMENTS: EngineerPayment[] = [
  { id: 'eng-1', siteId: 'site-1', date: '2025-02-15', amount: 40000, paymentMethod: 'bank', receiptNo: 'TXN-88392', note: '১ম তলা ঢালাই শুরুর আগে ১ম পার্ট পেমেন্ট' },
  { id: 'eng-2', siteId: 'site-1', date: '2025-03-05', amount: 35000, paymentMethod: 'cheque', receiptNo: 'CHQ-55019', note: '২য় কিস্তি লেবার মজুরি বিল পরিশোধ' },
  { id: 'eng-3', siteId: 'site-2', date: '2025-03-02', amount: 25000, paymentMethod: 'upi', receiptNo: 'UPI-77123', note: 'ইন্টেরিয়র অগ্রিম প্রাপ্তি' }
];

export const INITIAL_MESS_EXPENSES: MessExpense[] = [
  { id: 'exp-1', date: '2025-03-02', category: 'bazar', title: '১ম সপ্তাহের কাঁচাবাজার ও চাল-ডাল-তেল', amount: 3850, paidBy: 'মেস ম্যানেজার তহবিল', note: 'নিউ টাউন বাজার থেকে কেনা' },
  { id: 'exp-2', date: '2025-03-05', category: 'gas', title: 'ভারত গ্যাস কমার্শিয়াল সিলিন্ডার রিফিল', amount: 1850, paidBy: 'কন্ট্রাক্টর তহবিল', note: '১৯ কেজি সিলিন্ডার' },
  { id: 'exp-3', date: '2025-03-09', category: 'bazar', title: '২য় সপ্তাহের কাঁচাবাজার ও মাছ-মাংস', amount: 4200, paidBy: 'মেস ম্যানেজার তহবিল', note: 'সাপ্তাহিক রেশনের বাজার' },
  { id: 'exp-4', date: '2025-03-10', category: 'cook_salary', title: 'বাবুর্চি সুশান্ত মাঝির পার্ট বেতন', amount: 3000, paidBy: 'কন্ট্রাক্টর তহবিল', note: 'চলতি মাসের প্রথম কিস্তি' },
  { id: 'exp-5', date: '2025-03-16', category: 'bazar', title: '৩য় সপ্তাহের সবজি ও মশলাপাতি', amount: 3600, paidBy: 'মেস ম্যানেজার তহবিল', note: 'মেসের দৈনিক খাবার খরচের রেশন' },
  { id: 'exp-6', date: '2025-03-18', category: 'electricity', title: 'পশ্চিমবঙ্গ বিদ্যুৎ বিল (WBSEDCL)', amount: 1450, paidBy: 'কন্ট্রাক্টর তহবিল', note: 'গ্রাহক আইডি: ৮৮০২৩৯২' },
  { id: 'exp-7', date: '2025-03-22', category: 'water_repairs', title: 'মেসের বাথরুমের পাইপ ও জলের ট্যাপ মেরামত', amount: 650, paidBy: 'মেস ম্যানেজার তহবিল', note: 'প্লাম্বার খরচ ও পার্টস' }
];

export const INITIAL_MESS_COLLECTIONS: MessCollection[] = [
  // ১ম সপ্তাহ খাবার খরচ
  { id: 'col-1', labourId: 'lab-1', type: 'meal_cost', periodLabel: '১ম সপ্তাহ (মার্চ)', date: '2025-03-03', amount: 750, paymentMethod: 'cash' },
  { id: 'col-2', labourId: 'lab-2', type: 'meal_cost', periodLabel: '১ম সপ্তাহ (মার্চ)', date: '2025-03-03', amount: 750, paymentMethod: 'cash' },
  { id: 'col-3', labourId: 'lab-3', type: 'meal_cost', periodLabel: '১ম সপ্তাহ (মার্চ)', date: '2025-03-03', amount: 750, paymentMethod: 'cash' },
  { id: 'col-4', labourId: 'lab-4', type: 'meal_cost', periodLabel: '১ম সপ্তাহ (মার্চ)', date: '2025-03-03', amount: 750, paymentMethod: 'cash' },
  { id: 'col-5', labourId: 'lab-5', type: 'meal_cost', periodLabel: '১ম সপ্তাহ (মার্চ)', date: '2025-03-04', amount: 750, paymentMethod: 'upi', note: 'বাইরে কাজ করা লেবার' },
  { id: 'col-6', labourId: 'lab-6', type: 'meal_cost', periodLabel: '১ম সপ্তাহ (মার্চ)', date: '2025-03-04', amount: 750, paymentMethod: 'cash' },

  // ২য় সপ্তাহ খাবার খরচ
  { id: 'col-7', labourId: 'lab-1', type: 'meal_cost', periodLabel: '২য় সপ্তাহ (মার্চ)', date: '2025-03-10', amount: 800, paymentMethod: 'cash' },
  { id: 'col-8', labourId: 'lab-2', type: 'meal_cost', periodLabel: '২য় সপ্তাহ (মার্চ)', date: '2025-03-10', amount: 800, paymentMethod: 'cash' },
  { id: 'col-9', labourId: 'lab-3', type: 'meal_cost', periodLabel: '২য় সপ্তাহ (মার্চ)', date: '2025-03-10', amount: 800, paymentMethod: 'cash' },
  { id: 'col-10', labourId: 'lab-4', type: 'meal_cost', periodLabel: '২য় সপ্তাহ (মার্চ)', date: '2025-03-10', amount: 800, paymentMethod: 'cash' },
  { id: 'col-11', labourId: 'lab-5', type: 'meal_cost', periodLabel: '২য় সপ্তাহ (মার্চ)', date: '2025-03-11', amount: 800, paymentMethod: 'upi' },
  { id: 'col-12', labourId: 'lab-6', type: 'meal_cost', periodLabel: '২য় সপ্তাহ (মার্চ)', date: '2025-03-11', amount: 800, paymentMethod: 'cash' },

  // ৩য় সপ্তাহ খাবার খরচ
  { id: 'col-13', labourId: 'lab-1', type: 'meal_cost', periodLabel: '৩য় সপ্তাহ (মার্চ)', date: '2025-03-17', amount: 750, paymentMethod: 'cash' },
  { id: 'col-14', labourId: 'lab-2', type: 'meal_cost', periodLabel: '৩য় সপ্তাহ (মার্চ)', date: '2025-03-17', amount: 750, paymentMethod: 'cash' },
  { id: 'col-15', labourId: 'lab-3', type: 'meal_cost', periodLabel: '৩য় সপ্তাহ (মার্চ)', date: '2025-03-17', amount: 750, paymentMethod: 'cash' },
  { id: 'col-16', labourId: 'lab-4', type: 'meal_cost', periodLabel: '৩য় সপ্তাহ (মার্চ)', date: '2025-03-17', amount: 750, paymentMethod: 'cash' },
  { id: 'col-17', labourId: 'lab-5', type: 'meal_cost', periodLabel: '৩য় সপ্তাহ (মার্চ)', date: '2025-03-18', amount: 750, paymentMethod: 'upi' },

  // মাসিক রুম ভাড়া সংগ্রহ (লেবারদের থেকে)
  { id: 'col-18', labourId: 'lab-1', type: 'room_rent', periodLabel: 'মার্চ ২০২৫', date: '2025-03-15', amount: 1500, paymentMethod: 'cash', note: 'মাসিক রুম ভাড়া' },
  { id: 'col-19', labourId: 'lab-2', type: 'room_rent', periodLabel: 'মার্চ ২০২৫', date: '2025-03-15', amount: 1500, paymentMethod: 'cash', note: 'মাসিক রুম ভাড়া' },
  { id: 'col-20', labourId: 'lab-4', type: 'room_rent', periodLabel: 'মার্চ ২০২৫', date: '2025-03-16', amount: 1500, paymentMethod: 'cash', note: 'মাসিক রুম ভাড়া' },
  { id: 'col-21', labourId: 'lab-5', type: 'room_rent', periodLabel: 'মার্চ ২০২৫', date: '2025-03-15', amount: 1500, paymentMethod: 'upi', note: 'বাইরে কাজ করা লেবারের রুম ভাড়া' }
];

export const INITIAL_ROOM_OWNER_CONFIG: RoomOwnerConfig = {
  ownerName: 'শ্রী নারায়ণ চ্যাটার্জী',
  ownerPhone: '৯৮৩১৯৯৮৮৭৭',
  propertyAddress: '১৫/বি মহিষবাথান লেন, সেক্টর ৫ ও নিউ টাউন সংযোগ সড়ক, কলকাতা - ৭০০০৯১',
  totalRooms: 3,
  perHeadMonthlyRate: 1200, // বাড়িওয়ালার জন-প্রতি মাসিক রেট ₹১,২০০ (অর্থাৎ দিনে ₹৪০ হারে Pro-rata)
  billingMonth: '2025-03' // মার্চ ২০২৫ (৩১ দিন)
};

export const INITIAL_LANDLORD_PAYMENTS: LandlordPayment[] = [
  {
    id: 'lp-1',
    date: '2025-03-05',
    amount: 3000,
    forMonth: '2025-03',
    paymentMethod: 'cash',
    receiptNo: 'RENT-RCPT-01',
    note: 'মার্চ মাসের ১ম কিস্তি ভাড়া প্রদান'
  },
  {
    id: 'lp-2',
    date: '2025-03-20',
    amount: 2500,
    forMonth: '2025-03',
    paymentMethod: 'upi',
    receiptNo: 'UPI-RENT-4412',
    note: 'মার্চ মাসের ২য় কিস্তি ভাড়া প্রদান'
  }
];
