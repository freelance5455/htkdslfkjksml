import {
  ClimbingClub,
  ClimbEntry,
  ChecklistItem,
  CandidateProfile,
  TrainingNote
} from '../types/climbing';

export const INITIAL_CLUBS: ClimbingClub[] = [
  {
    id: 'club-castle-london',
    name: 'The Castle Climbing Centre',
    location: 'Green Lanes, Stoke Newington, London N4 2HA',
    region: 'London & South East',
    wallTypes: ['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'],
    isOfficialNicasCentre: true,
    notes: 'Historic Victorian waterworks pumping station converted into 5 floors of climbing.',
    phone: '020 8211 7000',
    mobile: '07700 900142',
    email: 'nicas@castle-climbing.co.uk',
    website: 'https://www.castle-climbing.co.uk'
  },
  {
    id: 'club-depot-mcr',
    name: 'Depot Climbing Manchester',
    location: 'Trafford Park, Manchester M17 1EH',
    region: 'North West',
    wallTypes: ['Bouldering', 'Auto-Belay'],
    isOfficialNicasCentre: true,
    notes: 'World-class dedicated bouldering arena with huge comp wall and training circuit.',
    phone: '0161 848 9481',
    mobile: '07700 900253',
    email: 'manchester@theclimbingdepot.com',
    website: 'https://www.theclimbingdepot.co.uk'
  },
  {
    id: 'club-reach-london',
    name: 'The Reach Climbing Wall',
    location: 'Mellish Industrial Estate, Woolwich, London SE18 5NU',
    region: 'London & South East',
    wallTypes: ['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'],
    isOfficialNicasCentre: true,
    notes: 'Extensive lead wall with 14m competition overhangs and dedicated youth coaching area.',
    phone: '020 8855 9598',
    mobile: '07700 900384',
    email: 'reception@thereach.org.uk',
    website: 'https://www.thereach.org.uk'
  },
  {
    id: 'club-westway-london',
    name: 'Westway Climbing Centre',
    location: '1 Crowthorne Road, London W10 6RP',
    region: 'London & South East',
    wallTypes: ['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'],
    isOfficialNicasCentre: true,
    notes: 'One of the UK’s premier training facilities with over 350 routes.',
    phone: '020 8969 0992',
    mobile: '07700 900495',
    email: 'climbing@westway.org',
    website: 'https://www.everyoneactive.com/centre/westway-sports-fitness-centre'
  },
  {
    id: 'club-tca-mothership',
    name: 'TCA The Mothership',
    location: 'Barton Hill, Bristol BS5 9RD',
    region: 'South West',
    wallTypes: ['Bouldering'],
    isOfficialNicasCentre: true,
    notes: 'Bristol’s hub for bouldering enthusiasts with slab, roof, and campus boards.',
    phone: '0117 907 2956',
    mobile: '07700 900612',
    email: 'mothership@theclimbingacademy.com',
    website: 'https://www.theclimbingacademy.com'
  },
  {
    id: 'club-parthian-soton',
    name: 'Parthian Climbing Southampton',
    location: 'Stag Gates, Southampton SO17 1XJ',
    region: 'South Coast',
    wallTypes: ['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'],
    isOfficialNicasCentre: true,
    notes: 'Modern wall with high competition routes and youth squad training programmes.',
    phone: '023 8067 0670',
    mobile: '07700 900723',
    email: 'southampton@parthianclimbing.com',
    website: 'https://parthianclimbing.com'
  },
  {
    id: 'club-kendal-wall',
    name: 'Lakeland Climbing Centre (Kendal Wall)',
    location: 'Mint Bridge, Kendal, Cumbria LA9 6NH',
    region: 'Lake District & North',
    wallTypes: ['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'],
    isOfficialNicasCentre: true,
    notes: 'Home of the tallest indoor wall in England (25m King Kong wall).',
    phone: '01539 721766',
    mobile: '07700 900834',
    email: 'climb@kendalwall.co.uk',
    website: 'https://www.kendalwall.co.uk'
  },
  {
    id: 'club-awesome-sheffield',
    name: 'Awesome Walls Sheffield',
    location: 'Garter Street, Sheffield S4 7QX',
    region: 'Yorkshire',
    wallTypes: ['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'],
    isOfficialNicasCentre: true,
    notes: 'Massive former steelworks building with 15.5m lead wall.',
    phone: '0114 244 6622',
    mobile: '07700 900945',
    email: 'sheffield@awesomewalls.co.uk',
    website: 'https://www.awesomewalls.co.uk'
  }
];

export const INITIAL_PROFILE: CandidateProfile = {
  candidateName: '',
  candidateNumber: '',
  age: '',
  dateOfBirth: '',
  schemeTrack: 'NICAS Roped Climbing',
  homeClubId: 'club-castle-london',
  currentLevel: 1,
  targetLevel: 2,
  leadInstructor: '',
  startDate: new Date().toISOString().split('T')[0],
  emergencyContactName: '',
  emergencyContactPhone: '',
  medicalNotes: ''
};

export const INITIAL_CHECKLIST: ChecklistItem[] = [
  // LEVEL 1: New Climber
  {
    id: 'l1-saf-1',
    level: 1,
    category: 'Safety',
    title: 'Warm-up & Mobility Protocol',
    description: 'Demonstrates a dynamic cardiovascular warm-up and finger/shoulder joint mobility routine before climbing.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l1-saf-2',
    level: 1,
    category: 'Safety',
    title: 'Climbing Centre Rules & Etiquette',
    description: 'Understands mat etiquette, keeping landing zones clear, and not walking beneath active climbers.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l1-saf-3',
    level: 1,
    category: 'Safety',
    title: 'Auto-Belay Awareness & Pre-Climb Checks',
    description: 'Understands auto-belay clip-in procedures, gate lock check, and visual descent corridor sweep.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l1-eq-1',
    level: 1,
    category: 'Equipment',
    title: 'Harness Fitting & Double-Back Check',
    description: 'Fits waistbelt above the iliac crest and adjusts leg loops comfortably. Checks buckles.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l1-eq-2',
    level: 1,
    category: 'Equipment',
    title: 'Climbing Shoe Selection & Care',
    description: 'Chooses suitable climbing footwear and keeps soles clean from chalk and dust.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l1-tech-1',
    level: 1,
    category: 'Technique',
    title: 'Three Points of Contact',
    description: 'Maintains balance using three points of contact on the wall while reaching for holds.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l1-tech-2',
    level: 1,
    category: 'Technique',
    title: 'Straight Arms & Hip Positioning',
    description: 'Climbs with skeletal support (straight arms) where possible to minimize bicep fatigue.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l1-sign-1',
    level: 1,
    category: 'Sign-Off',
    title: 'Level 1 Completion Assessment',
    description: 'Logged minimum 6 climbs with instructor validation and completed candidate logbook review.',
    status: 'Not Started',
    verified: false
  },

  // LEVEL 2: Foundation Climber
  {
    id: 'l2-saf-1',
    level: 2,
    category: 'Safety',
    title: 'Buddy Check Routine (A-B-C-D-E)',
    description: 'Performs pre-climb buddy check: Anchor/Apparel, Buckles, Carabiner lock, Device loaded correctly, End knot.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l2-saf-2',
    level: 2,
    category: 'Safety',
    title: 'Controlled Belay Stance & Distance',
    description: 'Maintains an athletic belay stance 1-2 meters out from the wall, clear of fall zones and ground hazards.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l2-saf-3',
    level: 2,
    category: 'Safety',
    title: 'Bouldering Spotting & Controlled Landings',
    description: 'Demonstrates defensive bouldering falls (feet absorb impact, roll to back, tuck chin) and active spotting.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l2-eq-1',
    level: 2,
    category: 'Equipment',
    title: 'Figure of Eight Knot with Stopper',
    description: 'Ties a neat re-threaded figure of eight knot through both harness tie-in loops with a barrel stopper knot.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l2-eq-2',
    level: 2,
    category: 'Equipment',
    title: 'Belay Device Threading & Locking Carabiner',
    description: 'Correctly threads a manual tubular or assisted braking device into the belay loop and secures the screwgate.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l2-tech-1',
    level: 2,
    category: 'Technique',
    title: 'V-B-S Belaying Method',
    description: 'Demonstrates the V-B-S (V-shape, Brake, Slide) technique without ever letting go of the live brake strand.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l2-tech-2',
    level: 2,
    category: 'Technique',
    title: 'Lowering Climber with Smooth Control',
    description: 'Controls lowering speed smoothly with both hands in the brake position and communicates clearly with climber.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l2-tech-3',
    level: 2,
    category: 'Technique',
    title: 'Silent Footwork & Precision Placements',
    description: 'Places toes cleanly on footholds without noise, scraping, or double-stepping.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l2-sign-1',
    level: 2,
    category: 'Sign-Off',
    title: 'Level 2 Foundation Sign-Off',
    description: 'Minimum 20 climbs logged across top rope and bouldering with full belay competency verified.',
    status: 'Not Started',
    verified: false
  },

  // LEVEL 3: Technical Climber
  {
    id: 'l3-saf-1',
    level: 3,
    category: 'Safety',
    title: 'Hazard Identification & Route Crossing',
    description: 'Identifies loose holds, swinging falls, and crosses between adjacent rope lines on steep walls.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l3-saf-2',
    level: 3,
    category: 'Safety',
    title: 'Rope Coil Management & Ground Care',
    description: 'Flakes rope neatly into rope bag or tarp, avoiding twists, kinks, and contamination.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l3-eq-1',
    level: 3,
    category: 'Equipment',
    title: 'Assisted Braking Devices (e.g. Grigri / Jul / ClickUp)',
    description: 'Demonstrates correct finger positioning and paying out slack smoothly without overriding cam lock.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l3-eq-2',
    level: 3,
    category: 'Equipment',
    title: 'Rope Care & Retirement Criteria',
    description: 'Inspects rope sheath for core shots, flat spots, abrasion, and understands date stamp logging.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l3-tech-1',
    level: 3,
    category: 'Technique',
    title: 'Flagging (Outside & Inside Flag)',
    description: 'Applies flagged foot positions to counterbalance body weight and prevent "barndoor" rotation.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l3-tech-2',
    level: 3,
    category: 'Technique',
    title: 'Smearing & Friction Trust',
    description: 'Weights shoe rubber on featureless volume or bare wall with dropped heels for maximum surface contact.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l3-tech-3',
    level: 3,
    category: 'Technique',
    title: 'Drop Knee & Twist Lock Movement',
    description: 'Turns hips perpendicular into steep or overhanging wall using drop-knees and twist locks to extend reach.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l3-tech-4',
    level: 3,
    category: 'Technique',
    title: 'Tactical Route Reading & Rest Positions',
    description: 'Identifies rest holds, chalk marks, clipping positions, and crux moves from the ground before climbing.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l3-sign-1',
    level: 3,
    category: 'Sign-Off',
    title: 'Level 3 Candidate Assessment & 40 Climbs Verification',
    description: 'Accumulate minimum 40 recorded climbs in candidate logbook and pass technical movement evaluation.',
    status: 'Not Started',
    verified: false
  },

  // LEVEL 4: Lead Climber
  {
    id: 'l4-saf-1',
    level: 4,
    category: 'Safety',
    title: 'Lead Fall Dynamics & Landing Zones',
    description: 'Understands fall factors, rope stretch, swing trajectory, and catching a soft dynamic fall without collision.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l4-saf-2',
    level: 4,
    category: 'Safety',
    title: 'Back-Clipping & Z-Clipping Awareness',
    description: 'Recognizes and avoids back-clipping and Z-clipping; corrects immediately and safely while in balance.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l4-saf-3',
    level: 4,
    category: 'Safety',
    title: 'Leg Behind Rope Hazard (Trip Hazard)',
    description: 'Maintains awareness of leg position relative to lead rope to prevent inversion during an unexpected fall.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l4-eq-1',
    level: 4,
    category: 'Equipment',
    title: 'Lead Ropes (Dynamic Single Ropes)',
    description: 'Understands UIAA impact force ratings, sheath percentage, middle mark inspection, and dynamic properties.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l4-eq-2',
    level: 4,
    category: 'Equipment',
    title: 'Quickdraw Gate Orientations & Bent Gate Placement',
    description: 'Inspects wall quickdraws, ensures rope runs cleanly through bent gate with gate facing away from climb direction.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l4-tech-1',
    level: 4,
    category: 'Technique',
    title: 'Stable Clipping Stance & Pinch Clipping',
    description: 'Executes rapid clipping from waist level using pinch and snap techniques with left and right hands.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l4-tech-2',
    level: 4,
    category: 'Technique',
    title: 'Active Dynamic Lead Belaying',
    description: 'Takes a small hop or step forward to give a cushioned soft catch when leader falls above bolt.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l4-sign-1',
    level: 4,
    category: 'Sign-Off',
    title: 'Level 4 Lead Climber Verification & 60 Lead Climbs',
    description: 'Official assessment with minimum 60 lead climbs logged and verified lead fall catch competency.',
    status: 'Not Started',
    verified: false
  },

  // LEVEL 5: Advanced & Performance Climber
  {
    id: 'l5-saf-1',
    level: 5,
    category: 'Safety',
    title: 'Injury Prevention & Finger Pulley Care',
    description: 'Understands A2/A4 pulley biomechanics, open-hand vs full crimp risk, and eccentric loading rehab.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l5-eq-1',
    level: 5,
    category: 'Equipment',
    title: 'Advanced Training Tools (Hangboards & System Boards)',
    description: 'Designs safe hangboard protocols (minimum edge, repeaters) adhering to growth plate guidelines for youths.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l5-tech-1',
    level: 5,
    category: 'Technique',
    title: 'Periodized Training Plan Formulation',
    description: 'Creates a 12-week macrocycle covering endurance, power endurance, maximum strength, and peaking phases.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l5-tech-2',
    level: 5,
    category: 'Technique',
    title: 'Advanced Competition Beta & Route Pacing',
    description: 'Demonstrates reading dynamic moves, coordination jumps, volume presses, and time management on circuit.',
    status: 'Not Started',
    verified: false
  },
  {
    id: 'l5-sign-1',
    level: 5,
    category: 'Sign-Off',
    title: 'Level 5 Master Climber Portfolio & Mentorship',
    description: 'Submits completed candidate logbook, peer mentoring log, and passes performance assessor review.',
    status: 'Not Started',
    verified: false
  }
];

// Start with blank climbs: no dummy data!
export const INITIAL_CLIMBS: ClimbEntry[] = [];

// Start with blank training notes: no dummy data!
export const INITIAL_TRAINING_NOTES: TrainingNote[] = [];
