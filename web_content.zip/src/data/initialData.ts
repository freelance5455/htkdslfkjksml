import { SubjectCategory, Topic, MotivationalReminder } from '../types';

export const INITIAL_CATEGORIES: SubjectCategory[] = [
  {
    id: 'cs',
    name: 'Computer Science & Systems',
    description: 'Algorithms, distributed systems, architecture, and network protocols.',
    color: '#0284c7', // sky-600
    iconName: 'Cpu',
  },
  {
    id: 'med',
    name: 'Medicine & Neuroscience',
    description: 'Physiology, neurobiology, pharmacology, and clinical anatomy.',
    color: '#f43f5e', // rose-500
    iconName: 'Activity',
  },
  {
    id: 'lang',
    name: 'Languages & Linguistics',
    description: 'Grammar mechanics, vocabulary acquisition, and syntax patterns.',
    color: '#10b981', // emerald-500
    iconName: 'Globe',
  },
  {
    id: 'math',
    name: 'Mathematics & Physics',
    description: 'Calculus, linear algebra, quantum mechanics, and probability.',
    color: '#6366f1', // indigo-500
    iconName: 'Compass',
  },
  {
    id: 'hist',
    name: 'History & Humanities',
    description: 'Geopolitics, intellectual history, literature, and philosophy.',
    color: '#f59e0b', // amber-500
    iconName: 'BookOpen',
  },
];

// Helper to construct dates relative to today
const today = new Date();
const formatDate = (offsetDays: number) => {
  const d = new Date(today);
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().split('T')[0];
};

export const INITIAL_TOPICS: Topic[] = [
  {
    id: 'topic-1',
    title: 'Raft Distributed Consensus Protocol',
    categoryId: 'cs',
    notes: 'Leader election, log replication, and safety guarantees in distributed state machines.',
    keyConcepts: ['Heartbeat timers', 'Term numbers', 'Quorum voting', 'Log matching invariant'],
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    lastReviewedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    nextReviewDate: formatDate(0), // Due today! (Day 1 milestone)
    stage: 1,
    masteryScore: 28,
    stability: 2.5,
    consecutiveSuccesses: 1,
    history: [
      {
        date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 0,
        stageAfter: 1,
      },
    ],
    flashcards: [
      {
        id: 'fc-1-1',
        topicId: 'topic-1',
        front: 'What triggers a Raft follower node to transition to a candidate state?',
        back: 'When its election timer expires without receiving an AppendEntries heartbeat or RequestVote from a valid leader.',
        hint: 'Think about timeout mechanisms.',
        createdAt: new Date().toISOString(),
        reviewCount: 1,
        ratingHistory: ['good'],
      },
      {
        id: 'fc-1-2',
        topicId: 'topic-1',
        front: 'What constitutes a quorum in a Raft cluster of N nodes?',
        back: 'A strict majority: floor(N / 2) + 1. For a 5-node cluster, 3 nodes must agree to commit an entry.',
        hint: 'Standard majority fraction.',
        createdAt: new Date().toISOString(),
        reviewCount: 1,
        ratingHistory: ['good'],
      },
      {
        id: 'fc-1-3',
        topicId: 'topic-1',
        front: 'State the Log Matching Invariant in Raft.',
        back: 'If two logs contain an entry with the same index and term, then the logs are identical in all entries up through the given index.',
        hint: 'Guarantees prefix agreement.',
        createdAt: new Date().toISOString(),
        reviewCount: 0,
        ratingHistory: [],
      },
      {
        id: 'fc-1-4',
        topicId: 'topic-1',
        front: 'Why are election timeouts randomized (e.g. 150ms-300ms)?',
        back: 'To prevent split-vote deadlocks where multiple candidates start elections simultaneously and divide the votes evenly.',
        hint: 'Prevents electoral tie deadlocks.',
        createdAt: new Date().toISOString(),
        reviewCount: 1,
        ratingHistory: ['good'],
      },
    ],
  },
  {
    id: 'topic-2',
    title: 'Synaptic Long-Term Potentiation (LTP)',
    categoryId: 'med',
    notes: 'Persistent strengthening of synapses based on recent patterns of activity. Cellular basis of learning and memory consolidation.',
    keyConcepts: ['NMDA receptor activation', 'Magnesium block release', 'AMPA receptor insertion', 'CaMKII kinase cascade'],
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    lastReviewedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    nextReviewDate: formatDate(1), // Due tomorrow (Day 7 milestone)
    stage: 3,
    masteryScore: 58,
    stability: 8.5,
    consecutiveSuccesses: 3,
    history: [
      {
        date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 0,
        stageAfter: 1,
      },
      {
        date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 1,
        stageAfter: 2,
      },
      {
        date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 2,
        stageAfter: 3,
      },
    ],
    flashcards: [
      {
        id: 'fc-2-1',
        topicId: 'topic-2',
        front: 'What two simultaneous conditions are required to open the NMDA receptor pore?',
        back: '1. Glutamate binding to the receptor.\n2. Strong membrane depolarization to expel the voltage-sensitive Mg2+ (magnesium) ion blocking the channel.',
        hint: 'Coincidence detector mechanism.',
        createdAt: new Date().toISOString(),
        reviewCount: 3,
        ratingHistory: ['good', 'good', 'good'],
      },
      {
        id: 'fc-2-2',
        topicId: 'topic-2',
        front: 'What primary ion enters through NMDA channels to initiate the LTP signaling cascade?',
        back: 'Calcium ions (Ca2+), which activate downstream second messengers including CaMKII and Protein Kinase C.',
        hint: 'Divalent cation messenger.',
        createdAt: new Date().toISOString(),
        reviewCount: 2,
        ratingHistory: ['good', 'easy'],
      },
      {
        id: 'fc-2-3',
        topicId: 'topic-2',
        front: 'What post-synaptic structural change increases synaptic strength during early LTP?',
        back: 'Trafficking and insertion of additional AMPA receptors into the postsynaptic density (PSD), increasing glutamate sensitivity.',
        hint: 'Receptor density modulation.',
        createdAt: new Date().toISOString(),
        reviewCount: 3,
        ratingHistory: ['good', 'good', 'good'],
      },
    ],
  },
  {
    id: 'topic-3',
    title: 'Spanish Subjunctive in Hypothetical Conditions',
    categoryId: 'lang',
    notes: 'Imperfect subjunctive with conditional clauses ("Si tuviera dinero, viajaría por el mundo").',
    keyConcepts: ['Si clauses with imperfect subjunctive', '-ra vs -se endings', 'Hypothetical present vs impossible past', 'Subordinate noun clauses'],
    createdAt: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000).toISOString(),
    lastReviewedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
    nextReviewDate: formatDate(4), // Due in 4 days (Day 21 milestone)
    stage: 4,
    masteryScore: 78,
    stability: 22.0,
    consecutiveSuccesses: 4,
    history: [
      {
        date: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 0,
        stageAfter: 1,
      },
      {
        date: new Date(Date.now() - 19 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 1,
        stageAfter: 2,
      },
      {
        date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 2,
        stageAfter: 3,
      },
      {
        date: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 3,
        stageAfter: 4,
      },
    ],
    flashcards: [
      {
        id: 'fc-3-1',
        topicId: 'topic-3',
        front: 'Complete the sentence: "Si yo ________ (tener) más tiempo, aprendería a tocar el piano."',
        back: '"tuviera" (or "tuviese") - Imperfect subjunctive form of tener for first-person singular.',
        hint: 'Irregular preterite stem tuv- + iera.',
        createdAt: new Date().toISOString(),
        reviewCount: 4,
        ratingHistory: ['good', 'good', 'easy', 'good'],
      },
      {
        id: 'fc-3-2',
        topicId: 'topic-3',
        front: 'What verb tense follows "Como si..." (as if) when referring to a hypothetical present situation?',
        back: 'The Imperfect Subjunctive (e.g., "Habla como si supiera todo").',
        hint: 'Untrue present hypothetical condition.',
        createdAt: new Date().toISOString(),
        reviewCount: 4,
        ratingHistory: ['good', 'good', 'good', 'good'],
      },
    ],
  },
  {
    id: 'topic-4',
    title: 'Fourier Transform & Frequency Domain Foundations',
    categoryId: 'math',
    notes: 'Decomposing continuous signals into constituent orthogonal sinusoids. Euler formula and spectral energy density.',
    keyConcepts: ['Euler formula e^(iθ) = cos θ + i sin θ', 'Orthogonality of harmonic basis functions', 'Time-frequency duality', 'Convolution theorem'],
    createdAt: new Date().toISOString(),
    lastReviewedAt: undefined,
    nextReviewDate: formatDate(1), // Due in 1 day (New topic / Stage 0)
    stage: 0,
    masteryScore: 8,
    stability: 1.2,
    consecutiveSuccesses: 0,
    history: [],
    flashcards: [
      {
        id: 'fc-4-1',
        topicId: 'topic-4',
        front: 'What is the mathematical definition of the continuous Fourier Transform X(f)?',
        back: 'X(f) = ∫_{-∞}^{∞} x(t) · e^{-i 2π f t} dt\nIt projects the signal onto rotating complex sinusoids of frequency f.',
        hint: 'Integral projection onto complex exponential.',
        createdAt: new Date().toISOString(),
        reviewCount: 0,
        ratingHistory: [],
      },
      {
        id: 'fc-4-2',
        topicId: 'topic-4',
        front: 'State the Convolution Theorem for Fourier Transforms.',
        back: 'Convolution in the time domain equals pointwise multiplication in the frequency domain: F{f * g} = F{f} · F{g}.',
        hint: 'Time convolution transforms to frequency product.',
        createdAt: new Date().toISOString(),
        reviewCount: 0,
        ratingHistory: [],
      },
    ],
  },
  {
    id: 'topic-5',
    title: 'Ebbinghaus Forgetting Curve & Spaced Consolidation',
    categoryId: 'med',
    notes: 'Exponential decay of unreinforced memory traces: R = e^(-t/S). Spaced repetitions systematically flatten the forgetting trajectory and expand memory stability.',
    keyConcepts: ['Memory stability (S)', 'Retrieval effort hypothesis', 'Synaptic consolidation window', 'Optimal review intervals: 1, 3, 7, 21, 30 days'],
    createdAt: new Date(Date.now() - 32 * 24 * 60 * 60 * 1000).toISOString(),
    lastReviewedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    nextReviewDate: formatDate(28), // Stage 5 (Day 30 completed -> next review Day 60)
    stage: 5,
    masteryScore: 92,
    stability: 45.0,
    consecutiveSuccesses: 5,
    history: [
      {
        date: new Date(Date.now() - 32 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 0,
        stageAfter: 1,
      },
      {
        date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 1,
        stageAfter: 2,
      },
      {
        date: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 2,
        stageAfter: 3,
      },
      {
        date: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 3,
        stageAfter: 4,
      },
      {
        date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        rating: 'good',
        stageBefore: 4,
        stageAfter: 5,
      },
    ],
    flashcards: [
      {
        id: 'fc-5-1',
        topicId: 'topic-5',
        front: 'What does parameter S represent in the forgetting formula R = e^(-t/S)?',
        back: 'Memory Stability: The time required for relative retention to drop to 1/e (~37%). Each successful spaced recall multiplies S.',
        hint: 'Stability factor that scales with repetitions.',
        createdAt: new Date().toISOString(),
        reviewCount: 5,
        ratingHistory: ['good', 'good', 'good', 'easy', 'good'],
      },
      {
        id: 'fc-5-2',
        topicId: 'topic-5',
        front: 'Why is testing (retrieval practice) significantly more effective than re-reading notes?',
        back: 'Active retrieval triggers reconsolidation, strengthening neural pathways and engaging prefrontal-hippocampal circuits, whereas passive reading creates an illusion of competence without structural synaptic change.',
        hint: 'Testing effect vs passive familiarity.',
        createdAt: new Date().toISOString(),
        reviewCount: 5,
        ratingHistory: ['good', 'good', 'good', 'good', 'good'],
      },
    ],
  },
];

export const INITIAL_REMINDERS: MotivationalReminder[] = [
  {
    id: 'rem-1',
    title: 'Morning Recall Ignition',
    message: 'Your brain consolidates memory during sleep. Review your Day 1 and Day 3 milestones now while mental clarity is peak!',
    timeOfDay: '08:30',
    enabled: true,
    frequency: 'daily',
    type: 'nudge',
  },
  {
    id: 'rem-2',
    title: 'Evening Synaptic Seal',
    message: 'Reviewing 5 flashcards before sleep primes the hippocampus for overnight memory replay and consolidation.',
    timeOfDay: '20:00',
    enabled: true,
    frequency: 'daily',
    type: 'streak',
  },
  {
    id: 'rem-3',
    title: 'Mid-Day Focus Check-in',
    message: 'Every revision today flattens the forgetting slope. 10 minutes of spaced retrieval now saves 2 hours of cramming later.',
    timeOfDay: '13:00',
    enabled: false,
    frequency: 'weekdays',
    type: 'quote',
  },
];

export const MOTIVATIONAL_QUOTES = [
  {
    quote: 'With any considerable number of repetitions, a suitable distribution of them over a space of time is decidedly more advantageous than massing them at a single time.',
    author: 'Hermann Ebbinghaus',
    role: 'Pioneer of Experimental Memory Research',
  },
  {
    quote: 'The act of retrieving information from memory produces more learning than rereading or reviewing the same material.',
    author: 'Dr. Henry L. Roediger III',
    role: 'Cognitive Neuroscientist, Make It Stick',
  },
  {
    quote: 'You do not truly learn something by consuming it; you learn it when your brain struggles slightly to pull it back from the brink of forgetting.',
    author: 'Dr. Barbara Oakley',
    role: 'Author of A Mind for Numbers',
  },
  {
    quote: 'If you want to master something, teach it, question it, and test your understanding at intervals that force active recall.',
    author: 'Richard Feynman',
    role: 'Nobel Laureate in Physics',
  },
  {
    quote: 'We are what we repeatedly do. Excellence, then, is not an act, but a habit.',
    author: 'Will Durant (on Aristotle)',
    role: 'Philosopher & Historian',
  },
  {
    quote: 'Memory is the residue of thought. What you pay attention to and repeatedly retrieve is what your brain preserves.',
    author: 'Daniel T. Willingham',
    role: 'Cognitive Psychologist',
  },
];
