import { ClassInfo, ClassSyllabus, ParchiExam, Student } from '../types';

export const INITIAL_CLASSES: ClassInfo[] = [
  // --- MALE SECTION ---
  {
    id: 'class_elem_a_m',
    levelId: 'elementary_a',
    nameEn: 'Elementary A (Boys)',
    namePs: 'لومړنی الف - نارینه (Elementary A)',
    nameUr: 'ابتدائی اے - بوائز (Elementary A)',
    gender: 'male',
    durationMonths: 2,
    durationLabelEn: '2 Months',
    durationLabelPs: '۲ میاشتې',
    durationLabelUr: '۲ ماہ',
    startTime: '08:00 AM',
    endTime: '09:30 AM',
    grammarHoursWeekly: 5,
    speakingHoursWeekly: 5,
    vocabListeningHoursWeekly: 2,
    monthlyFeePkr: 1500,
    imageUrl: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Sir Naseebullah Kakar',
    roomNumber: 'Room 01 - Main Campus',
    descriptionEn: 'Introduction to English sounds, alphabet, basic greetings, present simple tense, and daily conversation starters.',
    descriptionPs: 'د انګلیسي غږونو، الفبا، ورځنۍ روغبړ، ساده حال زمانې او اساسي جملو پیل.',
    descriptionUr: 'انگریزی حروف، بنیادی تعارف، روزمرہ سلام کلام اور بنیادی گرامر کا آغاز۔'
  },
  {
    id: 'class_elem_b_m',
    levelId: 'elementary_b',
    nameEn: 'Elementary B (Boys)',
    namePs: 'لومړنی ب - نارینه (Elementary B)',
    nameUr: 'ابتدائی بی - بوائز (Elementary B)',
    gender: 'male',
    durationMonths: 2,
    durationLabelEn: '2 Months',
    durationLabelPs: '۲ میاشتې',
    durationLabelUr: '۲ ماہ',
    startTime: '09:30 AM',
    endTime: '11:00 AM',
    grammarHoursWeekly: 5,
    speakingHoursWeekly: 5,
    vocabListeningHoursWeekly: 2,
    monthlyFeePkr: 1500,
    imageUrl: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Sir Abdul Samad Tareen',
    roomNumber: 'Room 02 - Quaid Hall',
    descriptionEn: 'Past simple, future will/going to, family descriptions, everyday routine speeches, and story building.',
    descriptionPs: 'تېره زمانه، راتلونکې زمانه، د کورنۍ او ورځني کارونو انګلیسي بیان او لنډې کیسې.',
    descriptionUr: 'ماضی کے جملے، مستقبل، روزمرہ معمولات پر بات چیت اور تحریر۔'
  },
  {
    id: 'class_pre_inter_m',
    levelId: 'pre_intermediate',
    nameEn: 'Pre-Intermediate (Boys)',
    namePs: 'تر منځنۍ مخکې - نارینه (Pre-Intermediate)',
    nameUr: 'پری انٹرمیڈیٹ - بوائز (Pre-Intermediate)',
    gender: 'male',
    durationMonths: 2,
    durationLabelEn: '2 Months',
    durationLabelPs: '۲ میاشتې',
    durationLabelUr: '۲ ماہ',
    startTime: '11:15 AM',
    endTime: '12:45 PM',
    grammarHoursWeekly: 4,
    speakingHoursWeekly: 6,
    vocabListeningHoursWeekly: 3,
    monthlyFeePkr: 1800,
    imageUrl: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Sir Hikmatullah Pishinwal',
    roomNumber: 'Room 03 - Iqbal Hall',
    descriptionEn: 'Modal verbs, conditionals (Type 0 & 1), classroom debates, picture stories, and public speaking foundation.',
    descriptionPs: 'د امکان او اړتیا فعلونه (Modals)، شرطیه جملې، ټولګيوالې مناظرې او عامه وینا.',
    descriptionUr: 'ماڈل وربز، شرطیہ جملے، کلاس مباحثے اور اعتماد کے ساتھ تقریر۔'
  },
  {
    id: 'class_inter_m',
    levelId: 'intermediate',
    nameEn: 'Intermediate (Boys)',
    namePs: 'منځنی ټولګی - نارینه (Intermediate)',
    nameUr: 'انٹرمیڈیٹ - بوائز (Intermediate)',
    gender: 'male',
    durationMonths: 2,
    durationLabelEn: '2 Months',
    durationLabelPs: '۲ میاشتې',
    durationLabelUr: '۲ ماہ',
    startTime: '02:00 PM',
    endTime: '03:30 PM',
    grammarHoursWeekly: 4,
    speakingHoursWeekly: 7,
    vocabListeningHoursWeekly: 3,
    monthlyFeePkr: 2000,
    imageUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Sir Engr. Noor Ahmad',
    roomNumber: 'Room 04 - Balochistan Wing',
    descriptionEn: 'Active & Passive voice, Direct/Indirect speech, presentation slides delivery, interview skills, and writing essays.',
    descriptionPs: 'مجهول او معلوم، نقل قول، پرزینټیشن وړاندې کول او د مرکې (Interview) روزنه.',
    descriptionUr: 'ایکٹو پیgraph وائس، ڈائریکٹ ان ڈائریکٹ، پریزنٹیشن اور ملازمت کے انٹرویو کی تیاری۔'
  },
  {
    id: 'class_jr_adv_m',
    levelId: 'junior_advanced',
    nameEn: 'Junior Advanced (Part 1 - 2 Months)',
    namePs: 'جونیئر اډوانس - لومړۍ برخه (Junior Advanced)',
    nameUr: 'جونیئر ایڈوانسڈ - حصہ اول (Junior Advanced)',
    gender: 'male',
    durationMonths: 2,
    durationLabelEn: '2 Months (Part 1 of 4-Month Advanced)',
    durationLabelPs: '۲ میاشتې (د څلور میاشتني پرمختللي کورس لومړۍ برخه)',
    durationLabelUr: '۲ ماہ (چار ماہ کے ایڈوانسڈ کورس کا پہلا مرحلہ)',
    startTime: '03:45 PM',
    endTime: '05:15 PM',
    grammarHoursWeekly: 3,
    speakingHoursWeekly: 8,
    vocabListeningHoursWeekly: 4,
    monthlyFeePkr: 2200,
    imageUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Director Sir Habibullah Rahbar',
    roomNumber: 'Auditorium A',
    descriptionEn: 'First phase of 4-month Advanced diploma. Complex compound sentences, idioms, extempore speeches, and accent clarity.',
    descriptionPs: 'د ۴ میاشتني پرمختللي پروګرام لومړی پړاو: اصطلاحات، متفرقه موضوعاتو باندې فی البدیهه ویناوې او تلفظ.',
    descriptionUr: 'ایڈوانسڈ ڈپلومہ کا پہلا حصہ: محاورات، روانی سے فی البدیہہ تقریر اور تلفظ کی درستگی۔'
  },
  {
    id: 'class_sr_adv_m',
    levelId: 'senior_advanced',
    nameEn: 'Senior Advanced (Part 2 - 2 Months)',
    namePs: 'سینئر اډوانس - دویمه برخه (Senior Advanced)',
    nameUr: 'سینئر ایڈوانسڈ - حصہ دوم (Senior Advanced)',
    gender: 'male',
    durationMonths: 2,
    durationLabelEn: '2 Months (Part 2 of 4-Month Advanced)',
    durationLabelPs: '۲ میاشتې (د څلور میاشتني پرمختللي کورس وروستۍ برخه)',
    durationLabelUr: '۲ ماہ (چار ماہ کے ایڈوانسڈ کورس کا اختتامی مرحلہ)',
    startTime: '05:30 PM',
    endTime: '07:00 PM',
    grammarHoursWeekly: 2,
    speakingHoursWeekly: 10,
    vocabListeningHoursWeekly: 4,
    monthlyFeePkr: 2500,
    imageUrl: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Director Sir Habibullah Rahbar',
    roomNumber: 'Executive Hall',
    descriptionEn: 'Final graduation level of 4-month Advanced diploma. IELTS/TOEFL foundation, parliamentary debates, and professional fluency.',
    descriptionPs: 'د ۴ میاشتني کورس اخري فارغېدونکې کچه: پارلماني مباحثې، تافل او آیلټس بنسټونه، او پوره رواني.',
    descriptionUr: 'ایڈوانسڈ کا آخری گریجویشن لیول: پارلیمانی مباحثے، انٹرویو اور مکمل روانی۔'
  },

  // --- FEMALE SECTION (Same order, dedicated morning/afternoon shift) ---
  {
    id: 'class_elem_a_f',
    levelId: 'elementary_a',
    nameEn: 'Elementary A (Girls)',
    namePs: 'لومړنی الف - ښځینه (Elementary A Girls)',
    nameUr: 'ابتدائی اے - گرلز (Elementary A Girls)',
    gender: 'female',
    durationMonths: 2,
    durationLabelEn: '2 Months',
    durationLabelPs: '۲ میاشتې',
    durationLabelUr: '۲ ماہ',
    startTime: '09:00 AM',
    endTime: '10:30 AM',
    grammarHoursWeekly: 5,
    speakingHoursWeekly: 5,
    vocabListeningHoursWeekly: 2,
    monthlyFeePkr: 1500,
    imageUrl: 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Madam Gulalai Kakar',
    roomNumber: 'Fatima Jinnah Wing - F1',
    descriptionEn: 'Dedicated female class with comfortable, private learning atmosphere. Alphabet, phonics, basic daily dialogues.',
    descriptionPs: 'د خویندو لپاره جلا، پردې لرونکی او هوسا چاپیریال. لومړني غږونه، الفبا او ورځنۍ جملې.',
    descriptionUr: 'طالبات کے لیے باپردہ اور پرسکون کلاس روم۔ انگریزی بنیادی حروف اور بول چال۔'
  },
  {
    id: 'class_elem_b_f',
    levelId: 'elementary_b',
    nameEn: 'Elementary B (Girls)',
    namePs: 'لومړنی ب - ښځینه (Elementary B Girls)',
    nameUr: 'ابتدائی بی - گرلز (Elementary B Girls)',
    gender: 'female',
    durationMonths: 2,
    durationLabelEn: '2 Months',
    durationLabelPs: '۲ میاشتې',
    durationLabelUr: '۲ ماہ',
    startTime: '10:45 AM',
    endTime: '12:15 PM',
    grammarHoursWeekly: 5,
    speakingHoursWeekly: 5,
    vocabListeningHoursWeekly: 2,
    monthlyFeePkr: 1500,
    imageUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Madam Malala Tareen',
    roomNumber: 'Fatima Jinnah Wing - F2',
    descriptionEn: 'Past simple, home & school conversational topics, reading fluency, and vocabulary expansion.',
    descriptionPs: 'تېره زمانه، ښوونځی او د کور خبرې اترې، د لوستلو رواني او لغات زده کړه.',
    descriptionUr: 'ماضی کا استعمال، اسکول اور روزمرہ زندگی کے موضوعات پر انگریزی گفتگو۔'
  },
  {
    id: 'class_pre_inter_f',
    levelId: 'pre_intermediate',
    nameEn: 'Pre-Intermediate (Girls)',
    namePs: 'تر منځنۍ مخکې - ښځینه (Pre-Intermediate Girls)',
    nameUr: 'پری انٹرمیڈیٹ - گرلز (Pre-Intermediate Girls)',
    gender: 'female',
    durationMonths: 2,
    durationLabelEn: '2 Months',
    durationLabelPs: '۲ میاشتې',
    durationLabelUr: '۲ ماہ',
    startTime: '12:30 PM',
    endTime: '02:00 PM',
    grammarHoursWeekly: 4,
    speakingHoursWeekly: 6,
    vocabListeningHoursWeekly: 3,
    monthlyFeePkr: 1800,
    imageUrl: 'https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Madam Malala Tareen',
    roomNumber: 'Fatima Jinnah Wing - F3',
    descriptionEn: 'Grammar tenses consolidation, story presentations, questions building, and confident speaking.',
    descriptionPs: 'د زمانو بشپړول، د کیسو بیانونو تمرین، پوښتنې جوړول او د خبرو زړه ورتیا.',
    descriptionUr: 'تمام زمانوں کی مشق، کہانیاں سنانا اور پراعتماد گفتگو کی صلاحیت۔'
  },
  {
    id: 'class_inter_f',
    levelId: 'intermediate',
    nameEn: 'Intermediate (Girls)',
    namePs: 'منځنی ټولګی - ښځینه (Intermediate Girls)',
    nameUr: 'انٹرمیڈیٹ - گرلز (Intermediate Girls)',
    gender: 'female',
    durationMonths: 2,
    durationLabelEn: '2 Months',
    durationLabelPs: '۲ میاشتې',
    durationLabelUr: '۲ ماہ',
    startTime: '02:15 PM',
    endTime: '03:45 PM',
    grammarHoursWeekly: 4,
    speakingHoursWeekly: 7,
    vocabListeningHoursWeekly: 3,
    monthlyFeePkr: 2000,
    imageUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Madam Zarghona Khan',
    roomNumber: 'Fatima Jinnah Wing - F4',
    descriptionEn: 'Academic essay writing, active/passive voice, professional email drafting, and debate sessions.',
    descriptionPs: 'مضامینو لیکل، د فعال او مجهول کارونه، ایمیل لیکل او ګروپي بحثونه.',
    descriptionUr: 'مضمون نگاری، ایکٹو پیسیو، پیشہ ورانہ ای میل اور مذاکرے۔'
  },
  {
    id: 'class_jr_adv_f',
    levelId: 'junior_advanced',
    nameEn: 'Junior Advanced (Girls - Part 1)',
    namePs: 'جونیئر اډوانس - ښځینه (Junior Advanced Girls)',
    nameUr: 'جونیئر ایڈوانسڈ - گرلز (Junior Advanced Girls)',
    gender: 'female',
    durationMonths: 2,
    durationLabelEn: '2 Months (Part 1 of 4-Month Advanced)',
    durationLabelPs: '۲ میاشتې (د پرمختللي څلور میاشتني کورس ۱ برخه)',
    durationLabelUr: '۲ ماہ (ایڈوانسڈ کورس کا حصہ اول)',
    startTime: '03:45 PM',
    endTime: '05:00 PM',
    grammarHoursWeekly: 3,
    speakingHoursWeekly: 8,
    vocabListeningHoursWeekly: 4,
    monthlyFeePkr: 2200,
    imageUrl: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Madam Zarghona Khan',
    roomNumber: 'Conference Room B',
    descriptionEn: 'First phase of 4-month Advanced diploma for female students. Advanced idioms, fluency, and critical thinking.',
    descriptionPs: 'د نجونو لپاره د ۴ میاشتني اډوانس لومړی پړاو: اصطلاحات او د ژبې فصاحت.',
    descriptionUr: 'ایڈوانسڈ کا پہلا مرحلہ: جدید محاورات اور روانی کے ساتھ تقاریر۔'
  },
  {
    id: 'class_sr_adv_f',
    levelId: 'senior_advanced',
    nameEn: 'Senior Advanced (Girls - Part 2)',
    namePs: 'سینئر اډوانس - ښځینه (Senior Advanced Girls)',
    nameUr: 'سینئر ایڈوانسڈ - گرلز (Senior Advanced Girls)',
    gender: 'female',
    durationMonths: 2,
    durationLabelEn: '2 Months (Part 2 of 4-Month Advanced)',
    durationLabelPs: '۲ میاشتې (د پرمختللي کورس د فراغت پړاو)',
    durationLabelUr: '۲ ماہ (ایڈوانسڈ کورس کا اختتامی گریجویشن مرحلہ)',
    startTime: '05:00 PM',
    endTime: '06:15 PM',
    grammarHoursWeekly: 2,
    speakingHoursWeekly: 10,
    vocabListeningHoursWeekly: 4,
    monthlyFeePkr: 2500,
    imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80',
    instructorName: 'Madam Zarghona Khan',
    roomNumber: 'Conference Room B',
    descriptionEn: 'Final graduation phase of 4-month Advanced diploma. Thesis presentations, IELTS speaking mastery, and graduation project.',
    descriptionPs: 'د ۴ میاشتني کورس د فراغت اخري پړاو: څېړنیز پریزینټیشنونه او بشپړه رواني.',
    descriptionUr: 'فراغت کا آخری مرحلہ: ریسرچ پریزنٹیشن اور اعلیٰ ترین روانی۔'
  }
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'std_01',
    name: 'Ahmad Khan Kakar',
    fatherName: 'Haji Abdul Wali Khan',
    whatsappNumber: '+923129876543',
    classId: 'class_sr_adv_m',
    gender: 'male',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80',
    position: '1st Position 🥇',
    behavior: 'moral_intelligent',
    behaviorNotes: 'Outstanding moral character, always attentive, leads classroom English debates with high vocabulary.',
    feeStatus: 'paid',
    feeAmount: 2500,
    feePaidDate: '2026-11-01',
    monthlyAttendancePresentDays: 25,
    monthlyTotalWorkingDays: 26,
    attendanceHistory: [
      { date: '2026-11-04', status: 'present' },
      { date: '2026-11-03', status: 'present' },
      { date: '2026-11-02', status: 'present' },
      { date: '2026-11-01', status: 'present' },
    ],
    isGraduated: true,
    graduationDate: '2026-10-28',
    graduationTime: '11:30 AM',
    graduationRemarks: 'Graduated with Distinction and Highest Honors in Senior Advanced English Diploma.',
    enrolledDate: '2026-03-01'
  },
  {
    id: 'std_02',
    name: 'Bilal Ahmad Tareen',
    fatherName: 'Malik Mohammad Jan',
    whatsappNumber: '+923007654321',
    classId: 'class_jr_adv_m',
    gender: 'male',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    position: '2nd Position 🥈',
    behavior: 'diligent_learner',
    behaviorNotes: 'Very respectful and hardworking. Prepares daily speaking assignments without delay.',
    feeStatus: 'paid',
    feeAmount: 2200,
    feePaidDate: '2026-11-02',
    monthlyAttendancePresentDays: 24,
    monthlyTotalWorkingDays: 26,
    attendanceHistory: [
      { date: '2026-11-04', status: 'present' },
      { date: '2026-11-03', status: 'present' },
      { date: '2026-11-02', status: 'present' },
      { date: '2026-11-01', status: 'present' }
    ],
    isGraduated: false,
    enrolledDate: '2026-07-01'
  },
  {
    id: 'std_03',
    name: 'Sanaullah Khan Pishinwal',
    fatherName: 'Haji Ghulam Rasool',
    whatsappNumber: '+923331122334',
    classId: 'class_inter_m',
    gender: 'male',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
    position: '3rd Position 🥉',
    behavior: 'moral_intelligent',
    behaviorNotes: 'Extremely polite, helpful to classmates, speaks English fluently in class.',
    feeStatus: 'paid',
    feeAmount: 2000,
    feePaidDate: '2026-11-03',
    monthlyAttendancePresentDays: 23,
    monthlyTotalWorkingDays: 26,
    attendanceHistory: [
      { date: '2026-11-04', status: 'present' },
      { date: '2026-11-03', status: 'present' },
      { date: '2026-11-02', status: 'present' },
      { date: '2026-11-01', status: 'leave' }
    ],
    isGraduated: false,
    enrolledDate: '2026-09-01'
  },
  {
    id: 'std_04',
    name: 'Zia-ur-Rahman',
    fatherName: 'Abdul Quddus',
    whatsappNumber: '+923456789012',
    classId: 'class_elem_a_m',
    gender: 'male',
    photoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=400&q=80',
    position: 'None',
    behavior: 'needs_improvement_lazy',
    behaviorNotes: 'Frequently forgets homework, inattentive during grammar lessons, needs parental monitoring.',
    feeStatus: 'unpaid',
    feeAmount: 1500,
    monthlyAttendancePresentDays: 14,
    monthlyTotalWorkingDays: 26,
    attendanceHistory: [
      { date: '2026-11-04', status: 'absent', notifiedWhatsApp: false },
      { date: '2026-11-03', status: 'absent', notifiedWhatsApp: true, notifiedAt: '2026-11-03 09:15 AM' },
      { date: '2026-11-02', status: 'present' },
      { date: '2026-11-01', status: 'present' }
    ],
    isGraduated: false,
    enrolledDate: '2026-10-01'
  },
  {
    id: 'std_05',
    name: 'Niamatullah Tratwal',
    fatherName: 'Saadullah Khan',
    whatsappNumber: '+923145678901',
    classId: 'class_pre_inter_m',
    gender: 'male',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=400&q=80',
    position: 'Top 5',
    behavior: 'moral_intelligent',
    behaviorNotes: 'Bright student, memorizes vocab lists fast, very disciplined.',
    feeStatus: 'paid',
    feeAmount: 1800,
    feePaidDate: '2026-11-01',
    monthlyAttendancePresentDays: 25,
    monthlyTotalWorkingDays: 26,
    attendanceHistory: [
      { date: '2026-11-04', status: 'present' },
      { date: '2026-11-03', status: 'present' },
      { date: '2026-11-02', status: 'present' },
      { date: '2026-11-01', status: 'present' }
    ],
    isGraduated: false,
    enrolledDate: '2026-08-01'
  },
  {
    id: 'std_06',
    name: 'Bibi Zarmeena Kakar',
    fatherName: 'Dr. Abdul Qadir',
    whatsappNumber: '+923348877665',
    classId: 'class_sr_adv_f',
    gender: 'female',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    position: '1st Position 🥇',
    behavior: 'moral_intelligent',
    behaviorNotes: 'Exceptional intellectual caliber, highest score in IELTS speaking simulator, exemplary morals.',
    feeStatus: 'paid',
    feeAmount: 2500,
    feePaidDate: '2026-11-01',
    monthlyAttendancePresentDays: 26,
    monthlyTotalWorkingDays: 26,
    attendanceHistory: [
      { date: '2026-11-04', status: 'present' },
      { date: '2026-11-03', status: 'present' },
      { date: '2026-11-02', status: 'present' },
      { date: '2026-11-01', status: 'present' }
    ],
    isGraduated: true,
    graduationDate: '2026-10-30',
    graduationTime: '02:00 PM',
    graduationRemarks: 'Graduated First in Senior Advanced Girls Wing with Gold Medal in Public Speaking.',
    enrolledDate: '2026-02-15'
  },
  {
    id: 'std_07',
    name: 'Bibi Maryam Tareen',
    fatherName: 'Engr. Mohammad Aslam',
    whatsappNumber: '+923159988776',
    classId: 'class_inter_f',
    gender: 'female',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80',
    position: '2nd Position 🥈',
    behavior: 'moral_intelligent',
    behaviorNotes: 'Hardworking, accurate pronunciation, writes structured essays.',
    feeStatus: 'paid',
    feeAmount: 2000,
    feePaidDate: '2026-11-02',
    monthlyAttendancePresentDays: 24,
    monthlyTotalWorkingDays: 26,
    attendanceHistory: [
      { date: '2026-11-04', status: 'present' },
      { date: '2026-11-03', status: 'present' },
      { date: '2026-11-02', status: 'present' },
      { date: '2026-11-01', status: 'present' }
    ],
    isGraduated: false,
    enrolledDate: '2026-08-15'
  },
  {
    id: 'std_08',
    name: 'Farooq Shah',
    fatherName: 'Syed Anwar Shah',
    whatsappNumber: '+923136655443',
    classId: 'class_elem_b_m',
    gender: 'male',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=400&q=80',
    position: 'None',
    behavior: 'needs_improvement_lazy',
    behaviorNotes: 'Struggles with regular attendance, does not practice conversation dialogues at home.',
    feeStatus: 'unpaid',
    feeAmount: 1500,
    monthlyAttendancePresentDays: 12,
    monthlyTotalWorkingDays: 26,
    attendanceHistory: [
      { date: '2026-11-04', status: 'absent', notifiedWhatsApp: false },
      { date: '2026-11-03', status: 'present' },
      { date: '2026-11-02', status: 'absent', notifiedWhatsApp: true },
      { date: '2026-11-01', status: 'present' }
    ],
    isGraduated: false,
    enrolledDate: '2026-09-10'
  }
];

export const INITIAL_SYLLABUS: ClassSyllabus[] = [
  {
    classLevelId: 'elementary_a',
    titleEn: 'Elementary A Syllabus (2 Months)',
    titlePs: 'د لومړني الف ټولګي نصاب (۲ میاشتې)',
    titleUr: 'ابتدائی اے کلاس کا نصاب (۲ ماہ)',
    units: [
      {
        week: 1,
        topicTitle: 'English Phonics & Alphabet Foundation',
        grammarFocus: 'Nouns, Pronouns (I, We, You, He, She, It, They), Articles (A, An, The)',
        speakingFocus: 'Self-introductions, Formal & Informal Greetings, Asking "How are you?"',
        vocabularyFocus: 'Numbers 1-100, Days of Week, Months, Classroom items',
        practiceActivity: 'Pair dialogue: Greeting your partner in English without Urdu/Pashto'
      },
      {
        week: 2,
        topicTitle: 'Verb To Be & Basic State Sentences',
        grammarFocus: 'Am, Is, Are in positive, negative and question structures',
        speakingFocus: 'Describing identity, profession, origin ("I am from Pishin, Balochistan")',
        vocabularyFocus: 'Countries, Nationalities, Occupations, Family relations',
        practiceActivity: 'Picture flashcard identification and speech drills'
      },
      {
        week: 3,
        topicTitle: 'Present Simple Tense - Daily Life',
        grammarFocus: 'Do / Does, 3rd person singular "-s/-es", frequency adverbs (Always, Usually, Never)',
        speakingFocus: 'Describing my daily morning routine from Fajr prayer to night',
        vocabularyFocus: 'Daily actions, meals (breakfast, lunch, dinner), household vocabulary',
        practiceActivity: 'Student role-play: Interviewing your classmate about their daily routine'
      },
      {
        week: 4,
        topicTitle: 'Possession & Asking Questions',
        grammarFocus: 'Have / Has got, Possessive adjectives (My, Your, His, Her, Our, Their)',
        speakingFocus: 'Talking about personal belongings, home, and favorite items',
        vocabularyFocus: 'Rooms in a house, furniture, colors, clothing adjectives',
        practiceActivity: 'Show & Tell: Bring one item and describe it in 5 complete sentences'
      },
      {
        week: 6,
        topicTitle: 'Present Continuous Tense & Mid-Term Speaking',
        grammarFocus: 'Subject + is/am/are + Verb-ing; difference between routine and happening now',
        speakingFocus: 'Describing ongoing actions in a busy market or bazaar',
        vocabularyFocus: 'Action verbs, weather terms, sports',
        practiceActivity: 'Classroom action mime: Guessing what the student is doing in English'
      },
      {
        week: 8,
        topicTitle: 'Prepositions of Place & Final Term Evaluation',
        grammarFocus: 'In, On, Under, Next to, Behind, In front of, Between',
        speakingFocus: 'Giving directions around Pishin and Trat town, describing rooms',
        vocabularyFocus: 'City locations (Mosque, School, Hospital, Market, Post office)',
        practiceActivity: 'Elementary A Parchi Exam and 2-minute spoken presentation'
      }
    ]
  },
  {
    classLevelId: 'elementary_b',
    titleEn: 'Elementary B Syllabus (2 Months)',
    titlePs: 'د لومړني ب ټولګي نصاب (۲ میاشتې)',
    titleUr: 'ابتدائی بی کلاس کا نصاب (۲ ماہ)',
    units: [
      {
        week: 1,
        topicTitle: 'Past Simple - Regular Verbs',
        grammarFocus: 'Past tense -ed endings, pronunciation of /t/, /d/, and /id/',
        speakingFocus: 'What I did last weekend in Trat / Quetta',
        vocabularyFocus: 'Time expressions (Yesterday, Last night, Two days ago)',
        practiceActivity: 'Weekend review conversation in groups'
      },
      {
        week: 3,
        topicTitle: 'Past Simple - Irregular Verbs & Did Questions',
        grammarFocus: 'Top 50 irregular verbs (Go->Went, See->Saw, Eat->Ate, Come->Came)',
        speakingFocus: 'Telling a memorable childhood story or school memory',
        vocabularyFocus: 'Storytelling connectors (First, Then, After that, Finally)',
        practiceActivity: 'Story reconstruction and question interrogation drill'
      },
      {
        week: 5,
        topicTitle: 'Future Intentions with "Going to" and "Will"',
        grammarFocus: 'Plans vs immediate promises, future predictions',
        speakingFocus: 'My goals after graduating from Rahbar English Center',
        vocabularyFocus: 'Career goals, ambition words, travel vocabulary',
        practiceActivity: 'Future planning speech: 3-minute stage address'
      },
      {
        week: 8,
        topicTitle: 'Comparative & Superlative Adjectives',
        grammarFocus: 'Short adjectives (-er/-est), long adjectives (More/Most), irregulars (Good/Better/Best)',
        speakingFocus: 'Comparing life in villages vs big cities, weather, transport',
        vocabularyFocus: 'Descriptive antonyms (Cheap/Expensive, Quiet/Noisy)',
        practiceActivity: 'Elementary B comprehensive Parchi & Graduation to Pre-Intermediate'
      }
    ]
  },
  {
    classLevelId: 'pre_intermediate',
    titleEn: 'Pre-Intermediate Syllabus (2 Months)',
    titlePs: 'د تر منځنۍ کچې مخکې نصاب (۲ میاشتې)',
    titleUr: 'پری انٹرمیڈیٹ نصاب (۲ ماہ)',
    units: [
      {
        week: 1,
        topicTitle: 'Present Perfect Tense & Experience',
        grammarFocus: 'Have/Has + Past Participle (V3), "Ever" and "Never"',
        speakingFocus: 'Have you ever travelled outside Balochistan? Unforgettable experiences',
        vocabularyFocus: 'Travel, adventure, cultural traditions',
        practiceActivity: 'Find Someone Who... class survey in English'
      },
      {
        week: 4,
        topicTitle: 'Modal Verbs of Obligation & Permission',
        grammarFocus: 'Must, Have to, Should, Can, May, Might, Ought to',
        speakingFocus: 'Rules of the institution, health advice, road safety',
        vocabularyFocus: 'Medical advice, rules, traffic, rights and duties',
        practiceActivity: 'Role-play: Doctor and patient consultation'
      },
      {
        week: 8,
        topicTitle: 'Zero & First Conditionals',
        grammarFocus: 'If + Present Simple, will + base verb (Cause and effect)',
        speakingFocus: 'If you study hard, you will succeed; climate discussions',
        vocabularyFocus: 'Environment, farming, modern science basics',
        practiceActivity: 'Chain conditional speaking game and written Parchi exam'
      }
    ]
  },
  {
    classLevelId: 'intermediate',
    titleEn: 'Intermediate Syllabus (2 Months)',
    titlePs: 'د منځني ټولګي نصاب (۲ میاشتې)',
    titleUr: 'انٹرمیڈیٹ نصاب (۲ ماہ)',
    units: [
      {
        week: 1,
        topicTitle: 'Passive Voice Across All Major Tenses',
        grammarFocus: 'Transforming Active to Passive (Present, Past, Future, Modals)',
        speakingFocus: 'Describing how local products, crops, and fruits of Pishin are processed',
        vocabularyFocus: 'Manufacturing, agriculture (apples, grapes of Pishin), governance',
        practiceActivity: 'Process demonstration presentation'
      },
      {
        week: 4,
        topicTitle: 'Direct & Indirect Reported Speech',
        grammarFocus: 'Reporting statements, questions, and commands with tense shifting',
        speakingFocus: 'Reporting news stories and speeches given by leaders',
        vocabularyFocus: 'Media, journalism, academic reporting verbs (Insisted, Denied, Urged)',
        practiceActivity: 'Live mock press conference & journalist reporting'
      },
      {
        week: 8,
        topicTitle: 'Second & Third Conditionals & Regrets',
        grammarFocus: 'If + Past Simple, would + V1 / If + Past Perfect, would have + V3',
        speakingFocus: 'Hypothetical situations: If I were the minister of education...',
        vocabularyFocus: 'Abstract thought, philosophical debates, formal vocabulary',
        practiceActivity: 'Intermediate Exit Parchi Exam & Board assessment'
      }
    ]
  },
  {
    classLevelId: 'junior_advanced',
    titleEn: 'Junior Advanced Syllabus (Part 1 - 2 Months)',
    titlePs: 'د جونیئر اډوانس نصاب - لومړۍ برخه (۲ میاشتې)',
    titleUr: 'جونیئر ایڈوانسڈ نصاب - حصہ اول (۲ ماہ)',
    units: [
      {
        week: 1,
        topicTitle: 'Advanced Clause Structures & Inversion',
        grammarFocus: 'Negative inversion (Rarely have I seen..., Not only... but also...)',
        speakingFocus: 'Persuasive oration and rhetorical speech techniques',
        vocabularyFocus: 'Formal academic word lists (AWL), rhetoric devices',
        practiceActivity: 'Debate: "Technology in rural education: blessing or distraction?"'
      },
      {
        week: 4,
        topicTitle: 'Collocations, Phrasal Verbs & English Idioms',
        grammarFocus: 'Separable vs inseparable phrasal verbs, figurative language',
        speakingFocus: 'Native expressions, natural conversational banter and wit',
        vocabularyFocus: '100 high-frequency British and American idioms',
        practiceActivity: 'Extempore speech on impromptu slips drawn from box'
      },
      {
        week: 8,
        topicTitle: 'Critical Discourse & Analytical Writing',
        grammarFocus: 'Complex cohesion markers (Notwithstanding, Whereas, Henceforth)',
        speakingFocus: 'Defending arguments under cross-examination',
        vocabularyFocus: 'Sociological, economic, and geopolitical discourse',
        practiceActivity: 'Mid-diploma evaluation & promotion to Senior Advanced'
      }
    ]
  },
  {
    classLevelId: 'senior_advanced',
    titleEn: 'Senior Advanced Syllabus (Part 2 - 2 Months)',
    titlePs: 'د سینئر اډوانس نصاب - دویمه برخه (۲ میاشتې)',
    titleUr: 'سینئر ایڈوانسڈ نصاب - حصہ دوم (۲ ماہ)',
    units: [
      {
        week: 1,
        topicTitle: 'IELTS / TOEFL Speaking Band 8+ Fluency',
        grammarFocus: 'Grammatical range and accuracy, complex mixed conditionals',
        speakingFocus: 'Part 1, 2, and 3 simulation: 2-minute cue card talks without pause',
        vocabularyFocus: 'Nuanced adjectives, idiomatic collocations, cohesive discourse markers',
        practiceActivity: 'One-on-one formal examiner simulation and audio recording'
      },
      {
        week: 4,
        topicTitle: 'Parliamentary Debate & Public Speaking Mastery',
        grammarFocus: 'Subjunctive mood, emphatic structures (What matters most is...)',
        speakingFocus: 'Government vs Opposition parliamentary debates',
        vocabularyFocus: 'Diplomacy, law, leadership terminology',
        practiceActivity: 'Auditorium public debate before parents and guest scholars'
      },
      {
        week: 8,
        topicTitle: 'Grand Graduation Capstone & Thesis Defense',
        grammarFocus: 'Stylistics, precision editing, native-like register',
        speakingFocus: 'Final Graduation Speech & Valedictorian address',
        vocabularyFocus: 'Academic leadership, vision statements, inspirational eloquence',
        practiceActivity: 'Graduation Ceremony, certificate awarding, and Hall of Fame induction'
      }
    ]
  }
];

export const INITIAL_PARCHI_EXAMS: ParchiExam[] = [
  {
    id: 'parchi_01',
    title: 'Elementary A - Monthly Grammar & Speaking Test Paper',
    classId: 'class_elem_a_m',
    examType: 'monthly',
    totalMarks: 50,
    timeAllowed: '60 Minutes',
    date: '2026-11-10',
    instructions: 'Attempt all questions. Write neatly. No cutting or overwriting. Speaking assessment will be conducted individually.',
    questions: [
      {
        id: 'q1',
        type: 'mcq',
        prompt: 'Choose the correct form of the verb to be: "He _______ a student at Rahbar English Center."',
        options: ['am', 'is', 'are', 'be'],
        correctAnswer: 'is',
        marks: 5
      },
      {
        id: 'q2',
        type: 'fill_in_the_blank',
        prompt: 'Complete with correct article (a / an / the): "Ahmad bought _______ English dictionary from the market in Pishin."',
        options: ['a', 'an', 'the'],
        correctAnswer: 'an',
        marks: 5
      },
      {
        id: 'q3',
        type: 'grammar_rule',
        prompt: 'Change the following sentence into Negative and Question form: "Bilal plays cricket every Friday."',
        marks: 10
      },
      {
        id: 'q4',
        type: 'speaking_dialogue',
        prompt: 'Write a short 4-line greeting dialogue between two students meeting in Trat for the first time.',
        marks: 10
      },
      {
        id: 'q5',
        type: 'translation_essay',
        prompt: 'Write five simple English sentences about your father and his daily work.',
        marks: 20
      }
    ]
  },
  {
    id: 'parchi_02',
    title: 'Intermediate - Active/Passive & Conversation Test Paper',
    classId: 'class_inter_m',
    examType: 'midterm',
    totalMarks: 50,
    timeAllowed: '75 Minutes',
    date: '2026-11-12',
    instructions: 'All sections are compulsory. Express your thoughts in grammatically coherent English.',
    questions: [
      {
        id: 'q1',
        type: 'mcq',
        prompt: 'Which sentence is in correct Passive Voice? "The teacher explained the difficult grammar rule."',
        options: [
          'The difficult grammar rule is explained by the teacher.',
          'The difficult grammar rule was explained by the teacher.',
          'The difficult grammar rule had explain by the teacher.',
          'The teacher was explained by the grammar rule.'
        ],
        correctAnswer: 'The difficult grammar rule was explained by the teacher.',
        marks: 5
      },
      {
        id: 'q2',
        type: 'fill_in_the_blank',
        prompt: 'Fill in the correct reported speech: Ali said, "I am going to Quetta tomorrow." -> Ali said that he _______ going to Quetta the next day.',
        options: ['is', 'was', 'were', 'will be'],
        correctAnswer: 'was',
        marks: 5
      },
      {
        id: 'q3',
        type: 'grammar_rule',
        prompt: 'Rewrite using Second Conditional: "I don’t have enough money, so I cannot buy that advanced grammar book."',
        marks: 10
      },
      {
        id: 'q4',
        type: 'speaking_dialogue',
        prompt: 'Dialogue Writing: Two friends discussing the benefits of learning spoken English for Balochistan’s youth.',
        marks: 15
      },
      {
        id: 'q5',
        type: 'translation_essay',
        prompt: 'Write a 100-word paragraph on: "Why Discipline and Moral Character are Essential for Education."',
        marks: 15
      }
    ]
  }
];
