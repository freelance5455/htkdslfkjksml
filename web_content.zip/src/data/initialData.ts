import { Client, ExpenseItem, Invoice, Payment, StudioSettings, TaskItem } from '../types';

export const DEFAULT_SETTINGS: StudioSettings = {
  adminName: 'Mainul',
  adminTitle: 'Founder & Admin',
  adminBio: 'Independent software engineer and product designer building web and mobile solutions.',
  adminEmail: 'mainulmti397@gmail.com',
  companyName: 'CoderStudios',
  companyAbout: 'Digital product engineering studio specializing in custom web platforms and mobile applications.',
  companyAddress: 'Daulatpur, Dakshin Dinajpur, West Bengal, 733124',
  upiId: 'coderstudios@okicici',
  invoiceNote: 'Thank you for your business. Please settle balance via UPI or bank transfer.',
  pinCode: '2006',
};

export const INITIAL_CLIENTS: Client[] = [];

export const INITIAL_PAYMENTS: Payment[] = [];

export const INITIAL_INVOICES: Invoice[] = [];

export const INITIAL_TASKS: TaskItem[] = [];

export const INITIAL_EXPENSES: ExpenseItem[] = [];
