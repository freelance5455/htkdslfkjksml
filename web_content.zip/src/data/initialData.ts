import {
  Building,
  Disciple,
  NeighborSect,
  SecretRealm,
  MerchantItem,
  ChronicleEvent,
  SectAlignmentData,
  DynamicSectEvent,
  DivinePetition,
  SectSector,
  EquipmentItem,
  StorageItem
} from '../types/cultivation';
import { EQUIPMENT_CATALOG } from './equipment';

export const INITIAL_BUILDINGS: Building[] = [
  {
    id: 'b_hall',
    name: 'Grand Dao Hall',
    description: 'The supreme administrative center of the sect. Determines sect level, prestige, and disciple capacity.',
    level: 1,
    maxLevel: 500,
    baseCost: { spiritStones: 120, qi: 50, merit: 10 },
    costMultiplier: 1.15,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Base Disciple Capacity: +2 per level. Increases Sect Power & Dignity.',
    type: 'hall',
    unlocked: true
  },
  {
    id: 'b_array',
    name: 'Spirit Gathering Array',
    description: 'Ancient Daoist formation channeling the spiritual veins of heaven and earth into the sect reservoir.',
    level: 1,
    maxLevel: 500,
    baseCost: { spiritStones: 80, qi: 40 },
    costMultiplier: 1.12,
    assignedDisciples: ['d_1'],
    maxDisciples: 2,
    effectDescription: 'Generates +2 Qi/s (+1 Qi/s per assigned disciple). Increases sect Qi cap.',
    type: 'array',
    unlocked: true
  },
  {
    id: 'b_mine',
    name: 'Spirit Stone Vein',
    description: 'Subterranean crystalline spiritual stone deposit guarded by defensive talismans.',
    level: 1,
    maxLevel: 500,
    baseCost: { spiritStones: 90, qi: 30 },
    costMultiplier: 1.12,
    assignedDisciples: ['d_2'],
    maxDisciples: 2,
    effectDescription: 'Generates +3 Spirit Stones/s (+1 Stone/s per assigned disciple). Increases Stone cap.',
    type: 'mine',
    unlocked: true
  },
  {
    id: 'b_alchemy',
    name: 'Eight Trigrams Alchemy Pavilion',
    description: 'Houses bronze cauldrons to refine breakthrough pills and body-tempering elixirs.',
    level: 1,
    maxLevel: 500,
    baseCost: { spiritStones: 100, qi: 50, merit: 5 },
    costMultiplier: 1.14,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Produces +1 Breakthrough Pill every 30s and reduces tribulation failure rate.',
    type: 'alchemy',
    unlocked: true
  },
  {
    id: 'b_scripture',
    name: 'Wandering Cloud Scripture Pavilion',
    description: 'Contains ancient jade slips, sword intent scrolls, and immortal manuals.',
    level: 1,
    maxLevel: 500,
    baseCost: { spiritStones: 90, merit: 10 },
    costMultiplier: 1.14,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Increases sect disciple cultivation speed by +10%.',
    type: 'scripture',
    unlocked: true
  },
  {
    id: 'b_discipline',
    name: 'Hall of Righteous Discipline',
    description: 'Enforces sect rules, suppresses internal feuds, resolves grudges, and maintains order.',
    level: 1,
    maxLevel: 500,
    baseCost: { spiritStones: 80, merit: 10 },
    costMultiplier: 1.12,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Suppresses disciple jealousy buildup by 25% and grants mediation rights.',
    type: 'discipline',
    unlocked: true
  },
  {
    id: 'b_tribulation',
    name: 'Celestial Tribulation Platform',
    description: 'Specially forged altar etched with lightning-grounding runes to deflect Heavenly Wrath.',
    level: 1,
    maxLevel: 500,
    baseCost: { spiritStones: 150, qi: 80, merit: 15 },
    costMultiplier: 1.18,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Absorbs 30% of Heavenly Lightning damage during realm breakthrough.',
    type: 'tribulation',
    unlocked: true
  },
  {
    id: 'b_nursery',
    name: 'Spirit Herb Nursery',
    description: 'Terraced herbal fields yielding spirit grass, jade dew, and pill refinement ingredients.',
    level: 1,
    maxLevel: 500,
    baseCost: { spiritStones: 90, qi: 30 },
    costMultiplier: 1.12,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Harvests medicinal herbs and spirit dew to nurture young disciples.',
    type: 'garden',
    unlocked: true
  },
  {
    id: 'b_talisman',
    name: 'Talisman Inscription Chamber',
    description: 'Workspace for drawing cinnabar protective seals and speed talismans.',
    level: 1,
    maxLevel: 500,
    baseCost: { spiritStones: 100, qi: 40 },
    costMultiplier: 1.12,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Yields defensive ward talismans for sect disciples on expeditions.',
    type: 'scripture',
    unlocked: true
  },
  {
    id: 'b_garden',
    name: 'Beast Taming & Herb Conservatory',
    description: 'Nurtures sacred spirit beasts and thousand-year medicinal herbs.',
    level: 0,
    maxLevel: 500,
    baseCost: { spiritStones: 250, qi: 120, merit: 25 },
    costMultiplier: 1.15,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Breeds guardian beasts and yields rare longevity fruits (+5% all resource rates).',
    type: 'garden',
    unlocked: false,
    unlockRequirement: {
      minHallLevel: 4,
      description: 'Requires Grand Dao Hall Lv 4'
    }
  },
  {
    id: 'b_forge',
    name: 'Nine Cauldrons Weapon Forge',
    description: 'Harnesses earth flame to smelt flying swords, protective armor, and immortal artifacts.',
    level: 0,
    maxLevel: 500,
    baseCost: { spiritStones: 300, qi: 150, merit: 30 },
    costMultiplier: 1.16,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Increases all disciples combat power by +10% and crafts divine treasures.',
    type: 'forge',
    unlocked: false,
    unlockRequirement: {
      minHallLevel: 6,
      description: 'Requires Grand Dao Hall Lv 6'
    }
  },
  {
    id: 'b_meditation',
    name: 'Bodhi Meditation Grotto',
    description: 'Secluded cavern echoing with natural Dao resonance for deep breakthrough contemplation.',
    level: 0,
    maxLevel: 500,
    baseCost: { spiritStones: 400, qi: 200, merit: 40 },
    costMultiplier: 1.18,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Cultivation exp gain in meditation increased by +25%.',
    type: 'hall',
    unlocked: false,
    unlockRequirement: {
      minHallLevel: 8,
      description: 'Requires Grand Dao Hall Lv 8'
    }
  },
  {
    id: 'b_astronomy',
    name: 'Star-Observing Celestial Astrolabe',
    description: 'Tracks constellations to forecast auspicious seasons and secret realm alignments.',
    level: 0,
    maxLevel: 500,
    baseCost: { spiritStones: 600, qi: 300, merit: 60 },
    costMultiplier: 1.20,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Increases secret realm expedition rewards by +30% and predicts invasions.',
    type: 'array',
    unlocked: false,
    unlockRequirement: {
      minHallLevel: 10,
      description: 'Requires Grand Dao Hall Lv 10'
    }
  },
  {
    id: 'b_soul_pagoda',
    name: 'Nine-Stories Soul Lantern Pagoda',
    description: 'Ancient jade tower preserving ancestral life-flames, shielding sect elders from inner heart-demons.',
    level: 0,
    maxLevel: 500,
    baseCost: { spiritStones: 1100, qi: 550, merit: 110 },
    costMultiplier: 1.20,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Increases all disciple cultivation speed by +15% & calms tribulation stress.',
    type: 'tribulation',
    unlocked: false,
    unlockRequirement: {
      minHallLevel: 12,
      description: 'Requires Grand Dao Hall Lv 12'
    }
  },
  {
    id: 'b_vein_core',
    name: 'Immortal Earth-Vein Core',
    description: 'Deep crystalline heart beneath the mountain that concentrates primordial Spirit Stone & Qi veins.',
    level: 0,
    maxLevel: 500,
    baseCost: { spiritStones: 1800, qi: 900, merit: 160 },
    costMultiplier: 1.22,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Boosts passive Spirit Stones & Pure Qi generation across the sect by +25%.',
    type: 'mine',
    unlocked: false,
    unlockRequirement: {
      minHallLevel: 14,
      description: 'Requires Grand Dao Hall Lv 14'
    }
  },
  {
    id: 'b_sword_stele',
    name: 'Myriad Sword Intent Stele',
    description: 'Monolithic monolith scarred by ancient Sword Immortals; sharpens martial intent of onlookers.',
    level: 0,
    maxLevel: 500,
    baseCost: { spiritStones: 2800, qi: 1400, merit: 240 },
    costMultiplier: 1.22,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Boosts all sect disciples Combat Power by +20% and intensifies arena strikes.',
    type: 'forge',
    unlocked: false,
    unlockRequirement: {
      minHallLevel: 16,
      description: 'Requires Grand Dao Hall Lv 16'
    }
  },
  {
    id: 'b_dao_temple',
    name: 'Primeval Dao Comprehension Temple',
    description: 'Sacred sanctuary echoing with the chants of bygone Immortal Emperors across Extreme World.',
    level: 0,
    maxLevel: 500,
    baseCost: { spiritStones: 4500, qi: 2200, merit: 400 },
    costMultiplier: 1.24,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Generates passive Sect Merit (+1/s per level) and enhances Breakthrough insights.',
    type: 'scripture',
    unlocked: false,
    unlockRequirement: {
      minHallLevel: 18,
      description: 'Requires Grand Dao Hall Lv 18'
    }
  },
  {
    id: 'b_chaos_altar',
    name: 'Primordial Chaos Ascension Altar',
    description: 'Supreme heaven-earth altar floating above the clouds to draw cosmic chaos energy directly into the sect.',
    level: 0,
    maxLevel: 500,
    baseCost: { spiritStones: 8000, qi: 4000, merit: 800 },
    costMultiplier: 1.25,
    assignedDisciples: [],
    maxDisciples: 2,
    effectDescription: 'Boosts ALL passive resource yields by +40% & Sect Combat Power by +25%.',
    type: 'array',
    unlocked: false,
    unlockRequirement: {
      minHallLevel: 20,
      description: 'Requires Grand Dao Hall Lv 20'
    }
  }
];

export const INITIAL_DISCIPLES: Disciple[] = [
  {
    id: 'd_1',
    name: 'Li Tianyun',
    gender: 'Male',
    age: 18,
    lifespan: 110,
    currentRealmIndex: 0, // Qi Condensation Layer 1
    cultivationExp: 15,
    maxExp: 100,
    talent: 78,
    talentTier: 'Talented',
    spiritRootPurity: 'Talented',
    temperament: 'Calm',
    preference: 'Meditation',
    spiritRoot: 'Wood',
    constitution: 'Five Elements Dao Body',
    background: 'Daoist Temple Acolyte',
    rank: 'Outer',
    status: 'Idle',
    contribution: 10,
    loyalty: 95,
    morale: 90,
    stress: 5,
    combatPower: 25,
    maxHp: 100,
    currentHp: 100,
    maxQiEnergy: 100,
    currentQiEnergy: 100,
    isFavorite: true,
    recruitedYear: 1,
    equippedItems: {
      clothing: {
        id: 'eq_c_1',
        name: 'Hemp Daoist Robe',
        slot: 'clothing',
        tier: 'Mortal',
        minRealmIndex: 0,
        combatBonus: 5,
        cultivationRateBonus: 5,
        defenseBonus: 4,
        description: 'Simple linen garment woven with minor cooling runes.'
      },
      weapon: {
        id: 'eq_w_1',
        name: 'Cold Iron Flying Sword',
        slot: 'weapon',
        tier: 'Mortal',
        minRealmIndex: 0,
        combatBonus: 15,
        cultivationRateBonus: 3,
        defenseBonus: 2,
        description: 'Tempered in spring water by mortal blacksmiths.'
      }
    },
    relations: [
      { targetId: 'd_2', type: 'Friend', level: 2, affinity: 70, jealousy: 0 }
    ],
    biography: [
      'The first apprentice who climbed the thousand stone steps to seek immortality.',
      'Earnest and steadfast in his daily morning Qi gathering.'
    ],
    coreMemories: [
      {
        id: 'mem_d1_init',
        year: 1,
        season: 'Spring',
        title: 'Consecrated at the Mountain Gate',
        impactText: 'Kneeled before the ancestral incense altar, vowing to master the Grand Dao.',
        category: 'Breakthrough',
        traitAcquired: 'Steadfast Resolve',
        timestamp: Date.now() - 3600000
      }
    ],
    avatarStyle: {
      robeColor: '#3b82f6',
      hairColor: '#16141a',
      auraColor: '#22c55e',
      accessory: 'Jade Guan Crown',
      appearanceIndex: 0,
      skinTone: 'Warm Honey',
      clothingColor: 'Azure',
      expression: 'Stoic'
    },
    expression: 'Stoic',
    cultivationType: 'Sword Cultivator',
    emotion: 'Determined',
    personalAlignment: 'Righteous Orthodox',
    negativeTraits: [],
    assignedBuildingId: 'b_array'
  },
  {
    id: 'd_2',
    name: 'Su Qingling',
    gender: 'Female',
    age: 16,
    lifespan: 110,
    currentRealmIndex: 0, // Qi Condensation Layer 1
    cultivationExp: 20,
    maxExp: 100,
    talent: 85,
    talentTier: 'Prodigy',
    spiritRootPurity: 'Prodigy',
    temperament: 'Carefree',
    preference: 'Alchemy',
    spiritRoot: 'Water',
    constitution: 'Nine Heavens Phoenix Body',
    background: 'Mountain Village Mortal',
    rank: 'Outer',
    status: 'Idle',
    contribution: 10,
    loyalty: 98,
    morale: 95,
    stress: 5,
    combatPower: 28,
    maxHp: 100,
    currentHp: 100,
    maxQiEnergy: 100,
    currentQiEnergy: 100,
    isFavorite: true,
    recruitedYear: 1,
    equippedItems: {
      clothing: {
        id: 'eq_c_2',
        name: 'Pale Silk Skirt',
        slot: 'clothing',
        tier: 'Mortal',
        minRealmIndex: 0,
        combatBonus: 5,
        cultivationRateBonus: 5,
        defenseBonus: 4,
        description: 'Supple river-silk robes embroidered with aquatic lotus motifs.'
      },
      item: {
        id: 'eq_i_1',
        name: 'Carved Peach Wood Amulet',
        slot: 'item',
        tier: 'Mortal',
        minRealmIndex: 0,
        combatBonus: 6,
        cultivationRateBonus: 6,
        defenseBonus: 4,
        description: 'Wards off malicious ghosts and purifies wandering thoughts.'
      }
    },
    relations: [
      { targetId: 'd_1', type: 'Friend', level: 2, affinity: 70, jealousy: 0 }
    ],
    biography: [
      'Accompanied Brother Tianyun to the mountain gate.',
      'Possesses natural intuition for tending spirit herbs and sensing aquatic currents.'
    ],
    coreMemories: [
      {
        id: 'mem_d2_init',
        year: 1,
        season: 'Spring',
        title: 'Awakening of Phoenix Currents',
        impactText: 'Sensory currents of water and fire resonated gently within her spiritual sea.',
        category: 'Breakthrough',
        traitAcquired: 'Natural Intuition',
        timestamp: Date.now() - 3600000
      }
    ],
    avatarStyle: {
      robeColor: '#0284c7',
      hairColor: '#16141a',
      auraColor: '#06b6d4',
      accessory: 'Silver Hair Comb',
      appearanceIndex: 1,
      skinTone: 'Fair Jade',
      clothingColor: 'Astral Jade',
      expression: 'Smile'
    },
    expression: 'Smile',
    cultivationType: 'Alchemy Dao',
    emotion: 'Serene',
    personalAlignment: 'Cloud Mist Neutral',
    negativeTraits: [],
    assignedBuildingId: 'b_mine'
  }
];

export const INITIAL_SECT_SECTORS: SectSector[] = [
  {
    id: 'sec_ancestral',
    name: 'Ancestral Cloud Peak',
    region: 'Central Mountain Crest',
    description: 'The sacred heart of Mystic Daoist Temple, veiled in perpetual white mist and anchored by the Dragon Vein.',
    level: 1,
    maxLevel: 20,
    unlocked: true,
    minHallLevel: 1,
    unlockCostStones: 0,
    unlockCostMerit: 0,
    upgradeBaseStones: 160,
    bonusType: 'qi',
    bonusValuePerLevel: 3,
    bonusLabel: '+3 Pure Qi/s per Sector Level',
    guardianDiscipleId: 'd_1',
    controlPercent: 100
  },
  {
    id: 'sec_sword_valley',
    name: 'Sword Intent Valley',
    region: 'Eastern Jagged Cliffs',
    description: 'Winds howl with residual sword Qi through ironstone canyons, honing martial instincts of every disciple.',
    level: 0,
    maxLevel: 20,
    unlocked: false,
    minHallLevel: 2,
    unlockCostStones: 280,
    unlockCostMerit: 40,
    upgradeBaseStones: 220,
    bonusType: 'combat',
    bonusValuePerLevel: 5,
    bonusLabel: '+5% All Disciple Combat Power per Level',
    controlPercent: 0
  },
  {
    id: 'sec_jade_mines',
    name: 'Jade Spirit Mine Ridge',
    region: 'Southern Foothills',
    description: 'Rich mineral quarries veins lined with glowing low-grade and mid-grade spirit crystals.',
    level: 0,
    maxLevel: 20,
    unlocked: false,
    minHallLevel: 3,
    unlockCostStones: 350,
    unlockCostMerit: 50,
    upgradeBaseStones: 250,
    bonusType: 'stones',
    bonusValuePerLevel: 4,
    bonusLabel: '+4 Spirit Stones/s per Sector Level',
    controlPercent: 0
  },
  {
    id: 'sec_alchemy_terrace',
    name: 'Crimson Cauldron Terrace',
    region: 'Western Geothermal Springs',
    description: 'Natural earth-fire fissures fuel perpetual alchemy furnaces and nourish century-old spirit herbs.',
    level: 0,
    maxLevel: 20,
    unlocked: false,
    minHallLevel: 5,
    unlockCostStones: 550,
    unlockCostMerit: 90,
    upgradeBaseStones: 360,
    bonusType: 'pills',
    bonusValuePerLevel: 1,
    bonusLabel: '+1 Bonus Pill Yield/s tick chance per Level',
    controlPercent: 0
  },
  {
    id: 'sec_thunder_ridge',
    name: 'Thunder Temperament Ridge',
    region: 'Northern Storm Spire',
    description: 'High altitude spire attracting heavenly lightning arcs, tempering cultivation comprehension under storm clouds.',
    level: 0,
    maxLevel: 20,
    unlocked: false,
    minHallLevel: 7,
    unlockCostStones: 900,
    unlockCostMerit: 150,
    upgradeBaseStones: 500,
    bonusType: 'cultivation',
    bonusValuePerLevel: 6,
    bonusLabel: '+6% Disciple Cultivation Speed per Level',
    controlPercent: 0
  },
  {
    id: 'sec_demon_watch',
    name: 'Demon-Subduing Watchtower',
    region: 'Outer Border Frontier',
    description: 'Fortified mountain barrier array that intercepts invading sects and beast tides before they breach the inner gate.',
    level: 0,
    maxLevel: 20,
    unlocked: false,
    minHallLevel: 9,
    unlockCostStones: 1400,
    unlockCostMerit: 220,
    upgradeBaseStones: 720,
    bonusType: 'defense',
    bonusValuePerLevel: 8,
    bonusLabel: '+8% Sect Gate Defense & Counter-Might per Level',
    controlPercent: 0
  }
];

export const SECRET_REALMS: SecretRealm[] = [
  {
    id: 'realm_cave',
    name: 'Ancient Immortal Cave',
    dangerLevel: 'Safe',
    minRealmIndex: 0,
    recommendedPower: 40,
    durationSeconds: 15,
    description: 'The hermit abode of a deceased Qi Condensation cultivator. Plentiful in spirit herbs and foundational scrolls.',
    drops: ['Spirit Condensation Grass', 'Low-Grade Spirit Stones', 'Lesser Qi Pill'],
    potentialStones: 85,
    potentialPills: 2,
    potentialMerit: 10
  },
  {
    id: 'realm_mountain',
    name: 'Thousand Beast Mountain Range',
    dangerLevel: 'Moderate',
    minRealmIndex: 4,
    recommendedPower: 350,
    durationSeconds: 25,
    description: 'Rugged jagged peaks inhabited by low-tier spirit beasts. Ferocious beast cores and rare iron veins await the courageous.',
    drops: ['Thunder Wolf Core', 'Deep Sea Cold Iron', 'Mid-Grade Spirit Stones'],
    potentialStones: 350,
    potentialPills: 8,
    potentialMerit: 40
  },
  {
    id: 'realm_marsh',
    name: 'Dragon Blood Marsh',
    dangerLevel: 'Dangerous',
    minRealmIndex: 9,
    recommendedPower: 3000,
    durationSeconds: 45,
    description: 'Ancient primordial swamp where a True Dragon fell in antiquity. Filled with poisonous miasma and draconic artifacts.',
    drops: ['True Dragon Scale', 'Longevity Spirit Fruit', 'Foundation Breakthrough Pill'],
    potentialStones: 1500,
    potentialPills: 25,
    potentialMerit: 150
  },
  {
    id: 'realm_celestial',
    name: 'Void Celestial Ruins',
    dangerLevel: 'Perilous',
    minRealmIndex: 13,
    recommendedPower: 25000,
    durationSeconds: 60,
    description: 'Shattered remnants of an ascended immortal sect floating in spatial turbulence. Highest realm mysteries and immortal treasures.',
    drops: ['Immortal Jade Scripture', 'Ascension Talisman', 'Chaos Primordial Stone'],
    potentialStones: 8000,
    potentialPills: 80,
    potentialMerit: 800
  }
];

export const NEIGHBOR_SECTS: NeighborSect[] = [
  {
    id: 'sect_sword',
    name: 'Heavenly Sword Sect',
    leaderName: 'Sword Saint Gu Canghai',
    alignment: 'Righteous Orthodox',
    strength: 450,
    invaderCount: 34,
    reputation: 60,
    attitude: 'Respectful',
    specialty: 'Peerless Sword Formations',
    territoryPoints: 35
  },
  {
    id: 'sect_pill',
    name: 'Myriad Pill Pavilion',
    leaderName: 'Grandmaster Dan Chen',
    alignment: 'Righteous Orthodox',
    strength: 380,
    invaderCount: 28,
    reputation: 75,
    attitude: 'Allied',
    specialty: 'Divine Pill Alchemy',
    territoryPoints: 25
  },
  {
    id: 'sect_demon',
    name: 'Blood Demon Hall',
    leaderName: 'Blood Patriarch Xue Li',
    alignment: 'Demonic Blood Cult',
    strength: 550,
    invaderCount: 46,
    reputation: -40,
    attitude: 'Hostile',
    specialty: 'Blood Sacrifice & Nether Arts',
    territoryPoints: 40
  },
  {
    id: 'sect_valley',
    name: 'Yin-Yang Valley',
    leaderName: 'Lady He Huan',
    alignment: 'Cloud Mist Neutral',
    strength: 320,
    invaderCount: 24,
    reputation: 15,
    attitude: 'Neutral',
    specialty: 'Dual Cultivation & Harmony',
    territoryPoints: 20
  },
  {
    id: 'sect_mist',
    name: 'Misty Cloud Palace',
    leaderName: 'Palace Master Yun Bing',
    alignment: 'Buddhic Zen',
    strength: 410,
    invaderCount: 31,
    reputation: 40,
    attitude: 'Wary',
    specialty: 'Frost Dao & Illusions',
    territoryPoints: 30
  }
];

export const MERCHANT_CATALOG_POOL: MerchantItem[] = [
  // Tier 1: Mortal Tier
  {
    id: 'm_t1_1',
    name: 'Low-Grade Qi Condensation Pill',
    tier: 'Mortal',
    type: 'Pill',
    rarity: 'Common',
    description: 'Refined from ordinary spiritual grasses. Cleanses mortal impurities for beginners.',
    price: 45,
    currency: 'spiritStones',
    effect: '+75 Cultivation EXP & +1 Breakthrough Pill Reserve',
    stock: 1,
    minRealmIndex: 0,
    bondXpValue: 22,
    preferredPreference: 'Alchemy'
  },
  {
    id: 'm_t1_2',
    name: 'Iron Skin Protective Talisman',
    tier: 'Mortal',
    type: 'Talisman',
    rarity: 'Common',
    description: 'Defensive jade-paper talisman inscribed with iron-bone runes.',
    price: 65,
    currency: 'spiritStones',
    effect: '+25 Permanent Combat Power to target disciple',
    stock: 1,
    minRealmIndex: 0,
    bondXpValue: 24,
    preferredPreference: 'Combat'
  },
  {
    id: 'm_t1_3',
    name: 'Willow Wood Spirit Staff',
    tier: 'Mortal',
    type: 'Artifact',
    rarity: 'Common',
    description: 'Carved from century-old spirit willow; channels wood restorative Qi.',
    price: 95,
    currency: 'spiritStones',
    effect: 'Weapon: +15 Combat Power, +6% Cultivation Speed (Qi Cond. 1+)',
    stock: 1,
    equipSlot: 'weapon',
    minRealmIndex: 0,
    combatBonus: 15,
    cultivationRateBonus: 6,
    defenseBonus: 4,
    bondXpValue: 28,
    preferredPreference: 'Meditation'
  },
  {
    id: 'm_t1_4',
    name: 'Mountain Spring Spirit Wine',
    tier: 'Mortal',
    type: 'Elixir',
    rarity: 'Common',
    description: 'Fragrant spiritual brew favored by wandering Daoists. Soothes cultivation stress.',
    price: 35,
    currency: 'spiritStones',
    effect: '-25 Stress, +15 Morale & +10 Loyalty on use',
    stock: 1,
    minRealmIndex: 0,
    bondXpValue: 26,
    preferredPreference: 'Social'
  },
  {
    id: 'm_t1_5',
    name: 'Carved Peach Wood Amulet',
    tier: 'Mortal',
    type: 'Artifact',
    rarity: 'Common',
    description: 'Wards off malicious ghosts and steadies restless heart-demons.',
    price: 75,
    currency: 'spiritStones',
    effect: 'Item: +8 Combat Power, +6% Cultivation Speed (Qi Cond. 1+)',
    stock: 1,
    equipSlot: 'item',
    minRealmIndex: 0,
    combatBonus: 8,
    cultivationRateBonus: 6,
    defenseBonus: 5,
    bondXpValue: 24,
    preferredPreference: 'Meditation'
  },

  // Tier 2: Spiritual Tier
  {
    id: 'm_t2_1',
    name: 'Foundation Establishment Pill',
    tier: 'Spiritual',
    type: 'Pill',
    rarity: 'Spiritual',
    description: 'Condensed elixir that fortifies meridians ahead of Foundation breakthroughs.',
    price: 380,
    currency: 'spiritStones',
    effect: '+260 Cultivation EXP & +2 Pills Reserve',
    stock: 1,
    minRealmIndex: 0,
    bondXpValue: 45,
    preferredPreference: 'Alchemy'
  },
  {
    id: 'm_t2_2',
    name: 'Azure Wind Speed Blade',
    tier: 'Spiritual',
    type: 'Artifact',
    rarity: 'Spiritual',
    description: 'Imbued with wind elemental crystals; swings with sonic slicing waves.',
    price: 680,
    currency: 'spiritStones',
    effect: 'Weapon: +450 Combat Power, +10% Cultivation Speed (Foundation+)',
    stock: 1,
    equipSlot: 'weapon',
    minRealmIndex: 9,
    combatBonus: 450,
    cultivationRateBonus: 10,
    defenseBonus: 50,
    bondXpValue: 50,
    preferredPreference: 'Combat'
  },
  {
    id: 'm_t2_3',
    name: 'Azure Cloud Dao Vestment',
    tier: 'Spiritual',
    type: 'Artifact',
    rarity: 'Spiritual',
    description: 'Spun from heavenly mist cocoon threads; shields against miasma.',
    price: 580,
    currency: 'spiritStones',
    effect: 'Clothing: +250 Combat Power, +180 Defense (Foundation+)',
    stock: 1,
    equipSlot: 'clothing',
    minRealmIndex: 9,
    combatBonus: 250,
    cultivationRateBonus: 10,
    defenseBonus: 180,
    bondXpValue: 48,
    preferredPreference: 'Social'
  },
  {
    id: 'm_t2_4',
    name: 'Warm Jade Spirit Pendant',
    tier: 'Spiritual',
    type: 'Artifact',
    rarity: 'Spiritual',
    description: 'Continuously feeds pure spiritual fluid into the dantian.',
    price: 520,
    currency: 'spiritStones',
    effect: 'Item: +200 Combat Power, +12% Cultivation Speed (Foundation+)',
    stock: 1,
    equipSlot: 'item',
    minRealmIndex: 9,
    combatBonus: 200,
    cultivationRateBonus: 12,
    defenseBonus: 150,
    bondXpValue: 46,
    preferredPreference: 'Meditation'
  },

  // Tier 3: Earth Tier
  {
    id: 'm_t3_1',
    name: 'Golden Core Condensation Elixir',
    tier: 'Earth',
    type: 'Elixir',
    rarity: 'Earth',
    description: 'Refines dantian pressure and awards massive realm comprehension.',
    price: 2800,
    currency: 'spiritStones',
    effect: '+1,200 Cultivation EXP, +40 Lifespan & Clears Stress',
    stock: 1,
    minRealmIndex: 6,
    bondXpValue: 78,
    preferredPreference: 'Alchemy'
  },
  {
    id: 'm_t3_2',
    name: 'Seven Stars Dragon Slaying Blade',
    tier: 'Earth',
    type: 'Artifact',
    rarity: 'Earth',
    description: 'Forged from meteorite star metal; unleashes devastating astral sword beams.',
    price: 4200,
    currency: 'spiritStones',
    effect: 'Weapon: +4,200 Combat Power, +15% Cultivation Speed (Golden Core+)',
    stock: 1,
    equipSlot: 'weapon',
    minRealmIndex: 13,
    combatBonus: 4200,
    cultivationRateBonus: 15,
    defenseBonus: 500,
    bondXpValue: 85,
    preferredPreference: 'Combat'
  },
  {
    id: 'm_t3_3',
    name: 'Crimson Dragon Silk Mantle',
    tier: 'Earth',
    type: 'Artifact',
    rarity: 'Earth',
    description: 'Bathed in dragon pool essence; grants fire resistance and draconic vigor.',
    price: 3600,
    currency: 'spiritStones',
    effect: 'Clothing: +2,800 Combat Power, +2,200 Defense (Golden Core+)',
    stock: 1,
    equipSlot: 'clothing',
    minRealmIndex: 13,
    combatBonus: 2800,
    cultivationRateBonus: 15,
    defenseBonus: 2200,
    bondXpValue: 80,
    preferredPreference: 'Exploration'
  },

  // Tier 4: Heaven Tier
  {
    id: 'm_t4_1',
    name: 'Grand Dao Scripture Slip',
    tier: 'Heaven',
    type: 'Manual',
    rarity: 'Heaven',
    description: 'Contains insights from an Ascended Immortal. Bestow to deepen innate aptitude.',
    price: 650,
    currency: 'merit',
    effect: 'Permanent +8 Talent & +150 Combat Power to target disciple',
    stock: 1,
    minRealmIndex: 0,
    bondXpValue: 115,
    preferredPreference: 'Meditation'
  },
  {
    id: 'm_t4_2',
    name: 'Nascent Soul Divine Pill',
    tier: 'Heaven',
    type: 'Pill',
    rarity: 'Heaven',
    description: 'Nourishes the newborn soul avatar with dense primordial vitality.',
    price: 18000,
    currency: 'spiritStones',
    effect: '+180 Lifespan, +4,000 Cultivation EXP & +500 Combat Power',
    stock: 1,
    minRealmIndex: 9,
    bondXpValue: 120,
    preferredPreference: 'Alchemy'
  },
  {
    id: 'm_t4_3',
    name: 'Nine Heavens Phoenix Feather Robe',
    tier: 'Heaven',
    type: 'Artifact',
    rarity: 'Heaven',
    description: 'Woven with celestial phoenix plumage; shields wearer from fatal trauma.',
    price: 24000,
    currency: 'spiritStones',
    effect: 'Clothing: +28,000 Combat Power, +24,000 Defense (Nascent Soul+)',
    stock: 1,
    equipSlot: 'clothing',
    minRealmIndex: 17,
    combatBonus: 28000,
    cultivationRateBonus: 25,
    defenseBonus: 24000,
    bondXpValue: 125,
    preferredPreference: 'Exploration'
  },

  // Tier 5: Divine Tier
  {
    id: 'm_t5_1',
    name: 'Primordial Chaos Dao Fruit',
    tier: 'Divine',
    type: 'Elixir',
    rarity: 'Divine',
    description: 'Mythical fruit that fell from the Heavenly Realm. Transmutes root to Chaos.',
    price: 2500,
    currency: 'merit',
    effect: 'Transforms Spirit Root to Chaos Root & +15 Talent',
    stock: 1,
    minRealmIndex: 0,
    bondXpValue: 160,
    preferredPreference: 'Meditation'
  },
  {
    id: 'm_t5_2',
    name: 'Taiji Yin-Yang Primordial Sword',
    tier: 'Divine',
    type: 'Artifact',
    rarity: 'Divine',
    description: 'Supreme ancestral relic capable of overturning heavens and calming oceans.',
    price: 120000,
    currency: 'spiritStones',
    effect: 'Weapon: +500,000 Combat Power, +45% Cultivation Speed (Soul Formation+)',
    stock: 1,
    equipSlot: 'weapon',
    minRealmIndex: 21,
    combatBonus: 500000,
    cultivationRateBonus: 45,
    defenseBonus: 60000,
    bondXpValue: 180,
    preferredPreference: 'Combat'
  }
];

export function pickDailyMerchantStock(): MerchantItem[] {
  const mortal = MERCHANT_CATALOG_POOL.filter(i => i.tier === 'Mortal').sort(() => Math.random() - 0.5).slice(0, 3);
  const spiritual = MERCHANT_CATALOG_POOL.filter(i => i.tier === 'Spiritual').sort(() => Math.random() - 0.5).slice(0, 2);
  const earth = MERCHANT_CATALOG_POOL.filter(i => i.tier === 'Earth').sort(() => Math.random() - 0.5).slice(0, 1);
  const high = MERCHANT_CATALOG_POOL.filter(i => i.tier === 'Heaven' || i.tier === 'Divine').sort(() => Math.random() - 0.5).slice(0, 2);
  return [...mortal, ...spiritual, ...earth, ...high].map(item => ({
    ...item,
    stock: 1,
    purchasedToday: false
  }));
}

export function getRandomMidTierEquipmentRewards(count: number = 3): StorageItem[] {
  const midPool = EQUIPMENT_CATALOG.filter(e => e.tier === 'Spiritual' || e.tier === 'Earth');
  const results: StorageItem[] = [];
  for (let i = 0; i < count; i++) {
    const picked: EquipmentItem = midPool[Math.floor(Math.random() * midPool.length)];
    const uniqueStorageId = `st_award_${picked.id}_${Date.now()}_${i}_${Math.random().toString(36).slice(2, 5)}`;
    results.push({
      storageId: uniqueStorageId,
      id: uniqueStorageId,
      sourceItemId: picked.id,
      name: picked.name,
      tier: picked.tier,
      type: 'Equipment',
      category: 'Equipment',
      rarity: picked.tier === 'Mortal' ? 'Common' : picked.tier,
      description: picked.description,
      effect: `${picked.slot.toUpperCase()}: +${picked.combatBonus} Combat, +${picked.cultivationRateBonus}% Cult Speed (Realm ${picked.minRealmIndex + 1}+)`,
      quantity: 1,
      minRealmIndex: picked.minRealmIndex,
      equipSlot: picked.slot,
      combatBonus: picked.combatBonus,
      cultivationRateBonus: picked.cultivationRateBonus,
      defenseBonus: picked.defenseBonus,
      bondXpValue: picked.tier === 'Earth' ? 80 : 48,
      preferredPreference: picked.slot === 'weapon' ? 'Combat' : 'Exploration'
    });
  }
  return results;
}

export const INITIAL_MERCHANT_ITEMS: MerchantItem[] = pickDailyMerchantStock();

export const INITIAL_CHRONICLE_EVENTS: ChronicleEvent[] = [
  {
    id: 'ch_1',
    year: 1,
    season: 'Autumn',
    dateStr: '2026-11-16',
    category: 'Sect',
    title: 'Mystic Daoist Temple Established',
    details: 'The sect foundations were consecrated on Extreme World under the auspicious alignment of the Dragon Vein. Apprentice brother Li Tianyun and sister Su Qingling lit the ancestral incense.',
    timestamp: Date.now() - 3600000,
    significance: 'divine'
  }
];

export const INITIAL_ALIGNMENT_DATA: SectAlignmentData = {
  chosen: false,
  currentAlignment: 'Cloud Mist Neutral',
  canChange: true,
  quests: {
    'Righteous Orthodox': [
      { id: 'aq_r1', title: 'Subdue Local Demons', description: 'Eliminate 3 rogue demonic beast incursions threatening mortal villages.', requirementDesc: 'Complete 3 Secret Realm Expeditions', completed: false, rewardDesc: '+500 Merit & Righteous Aura' },
      { id: 'aq_r2', title: 'Daoist Alliance Summit', description: 'Form an alliance treaty with Heavenly Sword Sect or Myriad Pill Pavilion.', requirementDesc: 'Reach Allied status with 1 Righteous Sect', completed: false, rewardDesc: '+1,200 Merit & Alliance Shield' },
      { id: 'aq_r3', title: 'Sanctify the Great Leyline', description: 'Upgrade the Grand Dao Hall to Level 5 to establish righteous sovereignty.', requirementDesc: 'Grand Dao Hall Level >= 5', completed: false, rewardDesc: 'Orthodox Dao Sovereign Title & +3,000 Merit' }
    ],
    'Demonic Blood Cult': [
      { id: 'aq_d1', title: 'Blood Vein Sacrificial Furnace', description: 'Amass combat might and gather beast cores from secret realms.', requirementDesc: 'Sect Combat Power >= 2,000', completed: false, rewardDesc: '+2,000 Spirit Stones & Demonic Blood Mark' },
      { id: 'aq_d2', title: 'Subjugate Neighboring Borders', description: 'Launch a successful invasion on a rival territory to demonstrate dominance.', requirementDesc: 'Invade 1 Rival Sect Territory', completed: false, rewardDesc: 'Nether Domain Control & +3,500 Stones' },
      { id: 'aq_d3', title: 'Ascendance of the Blood Patriarch', description: 'Have at least one disciple reach Foundation Establishment.', requirementDesc: '1 Disciple in Foundation Establishment+', completed: false, rewardDesc: 'Blood Sovereign Title & Unholy Dominance' }
    ],
    'Buddhic Zen': [
      { id: 'aq_b1', title: 'Purify Worldly Grudges', description: 'Resolve all internal disciple rivalries and maintain zero hatred in the sect.', requirementDesc: 'Zero active disciple grudges', completed: false, rewardDesc: '+600 Merit & Zen Mind Shield' },
      { id: 'aq_b2', title: 'Universal Compassion Outreach', description: 'Distribute pills to mortal realms and assist friendly sects.', requirementDesc: 'Stock >= 50 Pills and 2 Respectful Sects', completed: false, rewardDesc: '+1,500 Merit & Golden Lotus Aura' },
      { id: 'aq_b3', title: 'Enlightenment Under the Bodhi Tree', description: 'Have 2 disciples reach Qi Condensation Layer 5 with 100% Loyalty.', requirementDesc: '2 Disciples Layer 5+ with 100% Loyalty', completed: false, rewardDesc: 'Bodhisattva Dao Realm & Celestial Blessings' }
    ],
    'Cloud Mist Neutral': [
      { id: 'aq_n1', title: 'Hermit Self-Sufficiency', description: 'Ensure the sect produces at least +5 Stones/s and +5 Qi/s passively.', requirementDesc: 'Stone rate >= 5/s and Qi rate >= 5/s', completed: false, rewardDesc: '+400 Merit & Wandering Cloud Robes' },
      { id: 'aq_n2', title: 'Harmonious Trade Network', description: 'Establish commercial treaties with at least 2 neighboring sects.', requirementDesc: 'Trade treaties with 2 sects', completed: false, rewardDesc: '+800 Merit & Free Merchant Discount' },
      { id: 'aq_n3', title: 'Transcendent Isolation', description: 'Accumulate 5,000 Spirit Stones in the treasury without declaring any wars.', requirementDesc: '5,000 Spirit Stones & Zero wars', completed: false, rewardDesc: 'Immortal Hermit Domain & Calm Heart' }
    ],
    'Imperial Court': [
      { id: 'aq_i1', title: 'Imperial Mandate Decree', description: 'Recruit or cultivate at least 1 disciple of Imperial or Noble bloodlines.', requirementDesc: '1 Disciple with Noble/Imperial background', completed: false, rewardDesc: '+800 Merit & Golden Seal' },
      { id: 'aq_i2', title: 'Royal Martial Guard', description: 'Appoint at least 1 Inner Disciple to represent the imperial court.', requirementDesc: '1 Inner Disciple appointed', completed: false, rewardDesc: '+1,500 Merit & Imperial Tribute' },
      { id: 'aq_i3', title: 'Divine Dynasty Ascension', description: 'Reach 50,000 Sect Prestige rating across Extreme World.', requirementDesc: 'Sect Prestige >= 50,000', completed: false, rewardDesc: 'Supreme Imperial Court Sovereign & Dragon Throne' }
    ]
  }
};

export const INITIAL_DYNAMIC_EVENTS: DynamicSectEvent[] = [
  {
    id: 'evt_1',
    title: 'Injured Rogue Cultivator at the Mountain Gate',
    category: 'Encounter',
    description: 'A ragged cultivator clutching an ancient jade slip collapsed before the entrance steps, pursued by mountain bandits.',
    expiresAt: Date.now() + 180000,
    totalDurationSeconds: 180,
    choices: [
      {
        text: 'Offer healing pills and admit them to the sect',
        outcomeText: 'You bestowed healing pills. The cultivator pledged eternal loyalty and joined your sect as a talented disciple!',
        effect: { pills: -2, merit: 50, admitDisciple: true, alignmentShift: 'Righteous Orthodox' }
      },
      {
        text: 'Seize their jade slip and expel them from the mountain',
        outcomeText: 'You confiscated the ancient scroll and drove them away. Gained +150 Qi from the scroll.',
        effect: { qi: 150, merit: -30, alignmentShift: 'Demonic Blood Cult' }
      },
      {
        text: 'Ignore the mortal squabble and seal the mountain gate',
        outcomeText: 'You maintained serene detachment. The world continued its karmic cycles.',
        effect: {}
      }
    ]
  }
];

export const INITIAL_DIVINE_PETITIONS: DivinePetition[] = [
  {
    id: 'pet_1',
    discipleId: 'd_1',
    discipleName: 'Li Tianyun',
    title: 'Diligence in Morning Meditation',
    concernText: 'O Heavenly Ancestor, I have gathered the morning dew upon the cliff for 30 cycles. My meridians yearn for greater guidance in the Dao.',
    type: 'Suggestion',
    resolved: false
  },
  {
    id: 'pet_2',
    discipleId: 'd_2',
    discipleName: 'Su Qingling',
    title: 'Spring Water Essence for Herbs',
    concernText: 'Revered Sovereign, the spiritual herbs in our terrace require nourishment. May I channel the mountain brook into our nursery?',
    type: 'Suggestion',
    resolved: false
  }
];
