import { Sector, OperationalReport } from '../types/report';

import imgProduction from '../assets/images/op_production_line_1792391863492.jpg';
import imgMaintenance from '../assets/images/op_maintenance_check_1792391863808.jpg';
import imgLogistics from '../assets/images/op_warehouse_logistics_1792391864521.jpg';
import imgSafety from '../assets/images/op_safety_inspection_1792391864369.jpg';

export const DEFAULT_SECTORS: Sector[] = [
  {
    id: 'produzione',
    name: 'Produzione & Fabbricazione',
    shortCode: 'PRD',
    description: 'Linee di assemblaggio, turni di produzione, fermi macchina e controllo scarti',
    iconName: 'Factory',
    badgeColor: 'blue',
    metricFields: [
      { key: 'linea', label: 'Linea / Reparto', type: 'text', defaultValue: 'Linea 3 - Taglio e Robot' },
      { key: 'unitaProdotte', label: 'Unità Prodotte', type: 'number', unit: 'pz', defaultValue: 1450 },
      { key: 'scarti', label: 'Pezzi Scartati', type: 'number', unit: 'pz', defaultValue: 12 },
      { key: 'minutiFermo', label: 'Minuti di Fermo', type: 'number', unit: 'min', defaultValue: 15 },
      { key: 'efficienzaOEE', label: 'OEE Efficienza', type: 'number', unit: '%', defaultValue: 89.4 }
    ]
  },
  {
    id: 'manutenzione',
    name: 'Manutenzione & Impianti',
    shortCode: 'MAN',
    description: 'Interventi correttivi, manutenzione preventiva, quadri elettrici e collaudi',
    iconName: 'Wrench',
    badgeColor: 'amber',
    metricFields: [
      { key: 'tipoIntervento', label: 'Tipo Intervento', type: 'select', options: ['Preventiva Programmata', 'Correttiva Guasto', 'Migliorativa', 'Emergenza'], defaultValue: 'Preventiva Programmata' },
      { key: 'codiceImpianto', label: 'ID Macchinario / Impianto', type: 'text', defaultValue: 'CU-480V-QUADRO4' },
      { key: 'durataIntervento', label: 'Tempo Intervento', type: 'number', unit: 'ore', defaultValue: 2.5 },
      { key: 'costoRicambi', label: 'Costo Ricambi Stimato', type: 'number', unit: '€', defaultValue: 320 }
    ]
  },
  {
    id: 'sicurezza',
    name: 'Sicurezza, QHSE & Ambiente',
    shortCode: 'SIC',
    description: 'Audit periodici, conformità DPI, controlli ambientali e segnalazione pericoli',
    iconName: 'ShieldAlert',
    badgeColor: 'emerald',
    metricFields: [
      { key: 'tipologiaAudit', label: 'Tipo Audit', type: 'select', options: ['Verifica DPI', 'Near Miss / Quasi Incidente', 'Ispezione Antincendio', 'Audit ISO 45001'], defaultValue: 'Verifica DPI' },
      { key: 'tassoConformita', label: 'Conformità Rilevata', type: 'number', unit: '%', defaultValue: 98 },
      { key: 'nonConformita', label: 'Non Conformità Rilevate', type: 'number', unit: 'n°', defaultValue: 1 },
      { key: 'livelloRischio', label: 'Livello Rischio Residuo', type: 'select', options: ['Trascurabile', 'Basso', 'Moderato', 'Critico'], defaultValue: 'Basso' }
    ]
  },
  {
    id: 'logistica',
    name: 'Logistica & Magazzino',
    shortCode: 'LOG',
    description: 'Ricezione merci, stoccaggio corsie, spedizioni, bolle e rotazione pallet',
    iconName: 'PackageCheck',
    badgeColor: 'purple',
    metricFields: [
      { key: 'tipoMovimentazione', label: 'Attività', type: 'select', options: ['Ricezione Inbound', 'Picking Spedizione', 'Inventario Periodico', 'Riordino Corsia'], defaultValue: 'Ricezione Inbound' },
      { key: 'palletMovimentati', label: 'Pallet Gestiti', type: 'number', unit: 'pll', defaultValue: 84 },
      { key: 'numeroDDT', label: 'Rif. Bolla / DDT', type: 'text', defaultValue: 'DDT-2026-8819' },
      { key: 'tempoScaricoMin', label: 'Tempo Scarico/Messa a dimora', type: 'number', unit: 'min', defaultValue: 45 }
    ]
  },
  {
    id: 'qualita',
    name: 'Controllo Qualità & Laboratorio',
    shortCode: 'QA',
    description: 'Collaudo dimensionale lotti, certificati di conformità e test di laboratorio',
    iconName: 'CheckCircle2',
    badgeColor: 'cyan',
    metricFields: [
      { key: 'lottoProduzione', label: 'Numero Lotto', type: 'text', defaultValue: 'LT-2026-C09' },
      { key: 'esitoCollaudo', label: 'Esito Collaudo', type: 'select', options: ['Conforme 100%', 'Approvato con Deroga', 'Respinto / Blocco Lotto'], defaultValue: 'Conforme 100%' },
      { key: 'campioniTestati', label: 'Campioni Analizzati', type: 'number', unit: 'pz', defaultValue: 50 },
      { key: 'deviazioneStandard', label: 'Deviazione Tolleranza', type: 'text', defaultValue: '± 0.02 mm' }
    ]
  },
  {
    id: 'commerciale',
    name: 'Vendite & Customer Care',
    shortCode: 'COM',
    description: 'Avanzamento commesse, consegne ai clienti, segnalazioni e SLA contrattuali',
    iconName: 'Briefcase',
    badgeColor: 'rose',
    metricFields: [
      { key: 'commessaCliente', label: 'Cliente / Commessa', type: 'text', defaultValue: 'Gruppo Meccanico Nord S.p.A.' },
      { key: 'valoreLotto', label: 'Valore Commessa', type: 'number', unit: '€', defaultValue: 48500 },
      { key: 'statoAvanzamento', label: 'Avanzamento Fornitura', type: 'select', options: ['Pianificato', 'In Lavorazione', 'Pronto Spedizione', 'Consegnato'], defaultValue: 'Pronto Spedizione' },
      { key: 'soddisfazioneCliente', label: 'Valutazione Servizio', type: 'select', options: ['Ottima (5/5)', 'Buona (4/5)', 'Sufficiente (3/5)', 'Criticità Aperta'], defaultValue: 'Ottima (5/5)' }
    ]
  }
];

export const INITIAL_REPORTS: OperationalReport[] = [
  {
    id: 'rep-001',
    protocolNumber: 'REP-2026-0089',
    title: 'Audit Giornaliero Linea Robotizzata 3: Taratura Braccio KUKA',
    sectorId: 'produzione',
    timestamp: '2026-10-18T10:30:00.000Z',
    shift: 'mattina',
    operatorName: 'Marco Bellini',
    operatorRole: 'Capo Turno Linea Assemblaggio',
    status: 'completato',
    priority: 'media',
    location: 'Stabilimento Principale - Blocco B, Isola Robotica 3',
    description: 'Completata la taratura dei sensori di presa del braccio antropomorfo per il monoblocco motore. Verificata la velocità di ciclo e il posizionamento dei microinterruttori. La linea ha raggiunto una produttività di 1.450 pz con solo 12 scarti di collaudo.',
    correctiveActions: 'Sostituite le guarnizioni pneumatiche della pinza di presa e lubrificati i binari della navetta di alimentazione.',
    metrics: {
      linea: 'Isola Robotica 3 - Assemblaggio',
      unitaProdotte: 1450,
      scarti: 12,
      minutiFermo: 15,
      efficienzaOEE: 89.4
    },
    images: [
      {
        id: 'img-rep-001-1',
        url: imgProduction,
        caption: 'Posizionamento carter motore durante il ciclo robotico e verifica tolleranze su rulliera',
        tag: 'Dopo Intervento',
        uploadedAt: '2026-10-18T10:45:00.000Z',
        fileName: 'braccio_robotico_tarato.jpg'
      }
    ],
    tags: ['Automazione', 'OEE', 'Robot KUKA', 'Linea 3'],
    supervisorSignoff: {
      signed: true,
      supervisorName: 'Ing. Roberto Fabbri (Direttore di Produzione)',
      signedAt: '2026-10-18T12:00:00.000Z',
      notes: 'Parametri OEE in linea con il target di budget settimanale.'
    },
    createdAt: '2026-10-18T10:35:00.000Z',
    updatedAt: '2026-10-18T12:00:00.000Z'
  },
  {
    id: 'rep-002',
    protocolNumber: 'REP-2026-0090',
    title: 'Verifica Termografica e Tensione Quadro Elettrico Control Unit 4',
    sectorId: 'manutenzione',
    timestamp: '2026-10-18T14:15:00.000Z',
    shift: 'pomeriggio',
    operatorName: 'Gianni Moretti',
    operatorRole: 'Tecnico Elettromeccanico Senior',
    status: 'completato',
    priority: 'alta',
    location: 'Centrale Tecnica - Cabina Trasformazione Elettrica 2',
    description: 'Ispezione periodica sui contattori e morsettiere dell\'unità CU-480V. Eseguita misura delle tensioni di fase con multimetro digitale certificato e serraggio dinamometrico dei morsetti di potenza.',
    correctiveActions: 'Serrati n° 4 morsetti allentati sulle fasi L2 ed L3 del teleruttore principale; eliminato rischio di arco elettrico.',
    metrics: {
      tipoIntervento: 'Preventiva Programmata',
      codiceImpianto: 'CU-480V-QUADRO4',
      durataIntervento: 2.5,
      costoRicambi: 180
    },
    images: [
      {
        id: 'img-rep-002-1',
        url: imgMaintenance,
        caption: 'Misurazione voltmetrica 380V/480V sui teleruttori con multimetro calibrato John D.',
        tag: 'Durante',
        uploadedAt: '2026-10-18T14:30:00.000Z',
        fileName: 'quadro_controllo_multimetro.jpg'
      }
    ],
    tags: ['Elettrico', 'Prevenzione Guasti', 'Certificato Fluke'],
    supervisorSignoff: {
      signed: true,
      supervisorName: 'Ing. Claudio Vianello (Responsabile Impianti)',
      signedAt: '2026-10-18T16:00:00.000Z',
      notes: 'Collaudo superato regolarmente. Prossimo controllo programmato tra 6 mesi.'
    },
    createdAt: '2026-10-18T14:20:00.000Z',
    updatedAt: '2026-10-18T16:00:00.000Z'
  },
  {
    id: 'rep-003',
    protocolNumber: 'REP-2026-0091',
    title: 'Scarico e Stoccaggio Spedizione Materie Prime Rack C-14',
    sectorId: 'logistica',
    timestamp: '2026-10-18T16:00:00.000Z',
    shift: 'pomeriggio',
    operatorName: 'Luca De Angelis',
    operatorRole: 'Responsabile Flussi Magazzino Inbound',
    status: 'completato',
    priority: 'bassa',
    location: 'Hub Logistico A - Settore Stoccaggio Verticale C-14/B',
    description: 'Ricevuti 84 pallet con DDT fornitore metallurgico. Scansione codici a barre eseguita con lettore radiofrequenza, stoccaggio verticale su scaffalatura intensiva Rack C-14 a mezzo carrello retrattile elettrico.',
    correctiveActions: 'Nessuna anomalia. Tutti i bancali integri, reggiati e filmati secondo standard aziendali.',
    metrics: {
      tipoMovimentazione: 'Ricezione Inbound',
      palletMovimentati: 84,
      numeroDDT: 'DDT-2026-8819',
      tempoScaricoMin: 45
    },
    images: [
      {
        id: 'img-rep-003-1',
        url: imgLogistics,
        caption: 'Controllo codici barcode e posizionamento carrello retrattile presso baie C-14/8',
        tag: 'Conferma / Verbale',
        uploadedAt: '2026-10-18T16:20:00.000Z',
        fileName: 'stoccaggio_rack_c14.jpg'
      }
    ],
    tags: ['Magazzino', 'Bancali', 'Inbound', 'DDT'],
    createdAt: '2026-10-18T16:05:00.000Z',
    updatedAt: '2026-10-18T16:45:00.000Z'
  },
  {
    id: 'rep-004',
    protocolNumber: 'REP-2026-0092',
    title: 'Audit di Sicurezza e Verifica Conformità DPI Area Verniciatura & Linea C',
    sectorId: 'sicurezza',
    timestamp: '2026-10-18T17:15:00.000Z',
    shift: 'pomeriggio',
    operatorName: 'Dott.ssa Elena Rossi',
    operatorRole: 'RSPP & Coordinatore Sicurezza D.Lgs 81/08',
    status: 'in_revisione',
    priority: 'alta',
    location: 'Padiglione Nord - Passerella Ispezione Linea C',
    description: 'Sopralluogo programmato per la verifica dell\'uso corretto dei DPI (occhiali di protezione, scarpe antinfortunistiche S3, guanti chimici e otoprotettori). Riscontrata una segnaletica calpestabile parzialmente usurata presso la scala d\'accesso al soppalco tecnico.',
    correctiveActions: 'Emesso ordine di ripristino per la striscia antiscivolo fotoluminescente e richiesta sostituzione di 2 contenitori esausti per solventi.',
    metrics: {
      tipologiaAudit: 'Verifica DPI',
      tassoConformita: 96,
      nonConformita: 1,
      livelloRischio: 'Basso'
    },
    images: [
      {
        id: 'img-rep-004-1',
        url: imgSafety,
        caption: 'Ispezione visiva e verifica registro prescrizioni da passerella sopraelevata',
        tag: 'Prima Intervento',
        uploadedAt: '2026-10-18T17:30:00.000Z',
        fileName: 'ispezione_passerella_linea_c.jpg'
      }
    ],
    tags: ['D.Lgs 81/08', 'Audit DPI', 'RSPP', 'Sicurezza Impianti'],
    createdAt: '2026-10-18T17:20:00.000Z',
    updatedAt: '2026-10-18T17:35:00.000Z'
  },
  {
    id: 'rep-005',
    protocolNumber: 'REP-2026-0093',
    title: 'Anomalia Allineamento Presse Oleodinamiche - Fermo Tecnico Linea 1',
    sectorId: 'produzione',
    timestamp: '2026-10-17T22:40:00.000Z',
    shift: 'notte',
    operatorName: 'Davide Conti',
    operatorRole: 'Operatore Specializzato Presse',
    status: 'critico',
    priority: 'urgente',
    location: 'Reparto Stampaggio a Caldo - Pressa 400T',
    description: 'Rilevata vibrazione anomala e perdita di pressione nel circuito oleodinamico secondario durante il terzo ciclo di stampaggio. Linea arrestata per prevenire danni alla matrice di precisione.',
    correctiveActions: 'Bloccata la produzione, attivato allarme manutenzione notturna. Intervento in attesa di sostituzione elettrovalvola Parker.',
    metrics: {
      linea: 'Reparto Stampaggio Pressa 400T',
      unitaProdotte: 420,
      scarti: 34,
      minutiFermo: 110,
      efficienzaOEE: 54.2
    },
    images: [],
    tags: ['Fermo Macchina', 'Pressa 400T', 'Oleodinamica', 'Urgente'],
    createdAt: '2026-10-17T22:50:00.000Z',
    updatedAt: '2026-10-17T23:30:00.000Z'
  }
];
