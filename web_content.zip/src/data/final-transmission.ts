/**
 * Loaded only when the final sequence begins.
 * Do not import from boot, HUD, journal, or inventory modules.
 */

export type TransmissionPart = {
  kicker?: string;
  body: string;
};

export function buildFinalTransmission(player: string, searched: string): TransmissionPart[] {
  return [
    {
      kicker: "Première partie",
      body: `${player}.\n\nSi tu lis ceci, c'est que tu as suivi chaque lumière. Je n'ai pas disparu. Je me suis éloigné. Il y a des distances qu'on ne traverse pas en marchant. La mienne était de celles-là. J'ai cru, longtemps, qu'en restant je te protégerais. J'ai fini par comprendre que rester, pour moi, c'était t'apprendre à attendre quelqu'un qui n'arrivait plus à rester.\n\nAlors je suis parti. Pas pour te quitter. Pour cesser de te faire du mal en silence.`,
    },
    {
      kicker: "Deuxième partie",
      body: `J'ai laissé des traces parce que je n'arrivais pas à te parler en face. Chaque fragment n'était pas une épreuve. C'était une phrase. Le triangle du premier ciel, c'était ta façon de lever les yeux. La brume, c'était les jours où je n'arrivais plus à être net. Les anneaux, l'ordre que je n'ai jamais su garder. Le miroir, ce que je n'osais pas te montrer.\n\nJe ne voulais pas que tu me trouves. Je voulais que tu me lises.`,
    },
    {
      kicker: "Troisième partie",
      body: `Tu représentes, pour moi, l'endroit où le temps s'arrêtait sans faire de bruit. Pas une étoile. La pièce autour. Le seul lieu où je n'avais pas besoin de mériter l'air.\n\n${player}, je t'ai regardé comme on regarde une lumière qu'on n'allume pas soi-même. Avec reconnaissance. Avec peur. Avec ce sentiment stupide que si je m'approchais trop, elle s'éteindrait.`,
    },
    {
      kicker: "Quatrième partie",
      body: `Je me souviens du feu trop petit. Des deux tasses. De la tienne, propre, parce que tu n'étais pas là et que je te l'avais préparée quand même. Je me souviens de la lunette, de tes questions, de ta façon de chercher une logique même dans ce qui n'en avait pas.\n\nJe me souviens surtout des silences. Ce n'étaient pas des vides. C'étaient des phrases que je rangeais pour plus tard. Plus tard n'est pas venu. Alors je les ai mises dans le monde.`,
    },
    {
      kicker: "Cinquième partie",
      body: `La distance n'était pas des kilomètres. C'était cette chose entre ce que je ressentais et ce que je parvenais à dire. J'ai reculé en croyant te laisser de la place. J'ai seulement créé un ciel trop grand.\n\nSi tu as eu l'impression de toujours arriver après moi, c'est vrai. J'avançais pour que tu aies un chemin. J'avais trop peur d'être le lieu.`,
    },
    {
      kicker: "Sixième partie",
      body: `Ce que je n'ai jamais réussi à dire : je t'ai aimé plus simplement que toutes ces portes.\n\nSans cosmique. Sans destin. Sans métaphore. Juste ce fait, tenace, que le monde était plus respirable quand tu étais dans la pièce. Que je rangeais déjà les objets comme si tu allais tendre la main. Que je gravais ton nom, puis que je l'effaçais, parce que te nommer me rendait réel, et que le réel me faisait peur.`,
    },
    {
      kicker: "Septième partie",
      body: `Tu n'étais pas en train de me poursuivre. Depuis le premier éclat, tu étais en train de recevoir ce que je n'ai pas eu le courage de te laisser dans les mains.\n\nTout menait ici. Pas vers moi. Vers ces mots. J'ai construit un chemin pour que tu arrives jusqu'à eux sans que je sois là pour reculer encore une fois.\n\nC'est injuste. C'est aussi le seul geste vrai que j'ai su finir.`,
    },
    {
      kicker: "Dernière phrase",
      body: `Si une seule étoile reste, que ce soit celle-là :\n\n${player}, je t'ai attendu dans chaque silence. Même absent, surtout absent. Tu peux cesser de me chercher. Je n'étais plus un lieu. Je suis devenu ce que tu viens de traverser.\n\nReste.\n\n— ${searched}`,
    },
  ];
}

export { CREDITS_DEFAULT } from "./credits";
