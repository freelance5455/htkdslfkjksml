import { BEHAVIORS } from "@/data/behavior";
import { BOOKS } from "@/data/books";
import { NEWS, ANNOUNCED_MEDIA_TYPES, OFFICIAL_MEDIA } from "@/data/campaign";
import { CREATION } from "@/data/creation";
import { HADITHS } from "@/data/hadith";
import { NAMES } from "@/data/names";
import { VERSES } from "@/data/verses";
import { stripArabic } from "@/lib/utils";

export type SearchHit = {
  type: string;
  title: string;
  excerpt: string;
  href: string;
  score: number;
};

function scoreText(query: string, tokens: string[], text: string) {
  const normalized = stripArabic(text);
  if (!normalized || !query) return 0;
  if (normalized.includes(query)) return 8 + tokens.length;
  let score = 0;
  for (const token of tokens) {
    if (token.length > 1 && normalized.includes(token)) score += 2;
  }
  return score;
}

export function searchAll(raw: string): SearchHit[] {
  const query = stripArabic(raw);
  const tokens = query.split(" ").filter((token) => token.length > 1);
  if (query.length < 2) return [];
  const hits: SearchHit[] = [];

  const push = (type: string, title: string, excerpt: string, href: string, extra = "") => {
    const score = scoreText(query, tokens, `${title} ${excerpt} ${extra}`);
    if (score > 0) hits.push({ type, title, excerpt, href, score });
  };

  for (const name of NAMES) {
    push(
      "اسم",
      name.ar,
      name.mean,
      `/names/${name.slug}`,
      `${name.simple} ${name.deep} ${name.themes.join(" ")} ${name.pron}`,
    );
  }
  for (const verse of VERSES) {
    push("آية", `${verse.surah} ${verse.ayah}`, verse.text, `/quran/${verse.id}`, `${verse.tafsir} ${verse.topics.join(" ")}`);
  }
  for (const hadith of HADITHS) {
    push("حديث", hadith.source, hadith.text, `/hadith/${hadith.id}`, `${hadith.explanation} ${hadith.topics.join(" ")}`);
  }
  for (const book of BOOKS) {
    push("كتاب", book.title, `${book.author}. ${book.summary}`, `/library/${book.id}`, book.topic);
  }
  for (const topic of CREATION) {
    push("تأمل", topic.title, topic.science, `/creation/${topic.id}`, topic.reflection);
  }
  for (const item of BEHAVIORS) {
    push("سلوك", item.title, item.summary, `/behavior/${item.id}`, item.daleel);
  }
  for (const item of NEWS) {
    push("خبر", item.title, item.summary, "/campaign", item.source);
  }
  push("وسائط", OFFICIAL_MEDIA.title, OFFICIAL_MEDIA.description, "/media", OFFICIAL_MEDIA.speaker);
  for (const label of ANNOUNCED_MEDIA_TYPES) {
    push("وسائط", label, "أعلنت الوزارة عن هذا النوع من البرامج، ولم يُربط تسجيل محدد هنا بعد.", "/media", label);
  }
  push("مسابقة", "المسابقة الرسمية لحملة لأنه الله", "مسابقة أعلنتها وزارة الأوقاف وتنتهي في 20 تشرين الثاني 2026.", "/contests");
  push("نشاط", "مراجعة الأسماء والاختبار التعليمي", "نشاط داخل هذه المنصة وليس مسابقة رسمية.", "/study");

  return hits.sort((a, b) => b.score - a.score).slice(0, 40);
}
