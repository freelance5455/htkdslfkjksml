import {
  AnimatedScene,
  ChapterNote,
  ChapterVideo,
  ClassLevel,
  LanguageCode,
  Subject,
  VisualSceneKind,
} from '../types/edutoon';

interface TopicSeed {
  enTitle: string;
  hiTitle: string;
  enSummary: string;
  hiSummary: string;
  enKeyPoint: string;
  hiKeyPoint: string;
  enExplanation: string;
  hiExplanation: string;
  enQuestion: string;
  enAnswer: string;
  hiQuestion: string;
  hiAnswer: string;
  visualKind: VisualSceneKind;
  highlightValue: string;
}

const SUBJECT_CATALOG: Record<
  string,
  {
    id: string;
    titleEn: string;
    titleHi: string;
    descriptionEn: string;
    descriptionHi: string;
    accentHex: string;
    iconKey: Subject['iconKey'];
    minClass: number;
    maxClass: number;
  }
> = {
  math: {
    id: 'math',
    titleEn: 'Mathematics',
    titleHi: 'गणित',
    descriptionEn: 'Numbers, geometry, algebra, and visual problem solving',
    descriptionHi: 'संख्याएँ, ज्यामिति, बीजगणित और आसान दृश्य अभ्यास',
    accentHex: '#0284C7',
    iconKey: 'math',
    minClass: 1,
    maxClass: 10,
  },
  evs: {
    id: 'evs',
    titleEn: 'Environmental Studies',
    titleHi: 'पर्यावरण अध्ययन',
    descriptionEn: 'Nature, family, food, water, and our living surroundings',
    descriptionHi: 'प्रकृति, परिवार, जल, भोजन और हमारे आस-पास की दुनिया',
    accentHex: '#059669',
    iconKey: 'evs',
    minClass: 1,
    maxClass: 5,
  },
  science: {
    id: 'science',
    titleEn: 'Science',
    titleHi: 'विज्ञान',
    descriptionEn: 'Physics, chemistry, biology, and animated experiments',
    descriptionHi: 'भौतिकी, रसायन, जीव विज्ञान और एनिमेटेड प्रयोग',
    accentHex: '#059669',
    iconKey: 'science',
    minClass: 6,
    maxClass: 10,
  },
  social: {
    id: 'social',
    titleEn: 'Social Science',
    titleHi: 'सामाजिक विज्ञान',
    descriptionEn: 'History, geography, civics, and Indian heritage',
    descriptionHi: 'इतिहास, भूगोल, नागरिक शास्त्र और भारतीय संस्कृति',
    accentHex: '#D97706',
    iconKey: 'social',
    minClass: 6,
    maxClass: 10,
  },
  english: {
    id: 'english',
    titleEn: 'English',
    titleHi: 'अंग्रेजी (English)',
    descriptionEn: 'Grammar, comprehension, storytelling, and vocabulary',
    descriptionHi: 'व्याकरण, पठन कौशल, कहानियाँ और शब्दावली',
    accentHex: '#4F46E5',
    iconKey: 'english',
    minClass: 1,
    maxClass: 10,
  },
  hindi: {
    id: 'hindi',
    titleEn: 'Hindi',
    titleHi: 'हिंदी',
    descriptionEn: 'Vyakaran, kavita, kahani aur shuddh lekhan',
    descriptionHi: 'व्याकरण, कविता, कहानी और शुद्ध लेखन का अभ्यास',
    accentHex: '#DC2626',
    iconKey: 'hindi',
    minClass: 1,
    maxClass: 10,
  },
  gk: {
    id: 'gk',
    titleEn: 'General Knowledge',
    titleHi: 'सामान्य ज्ञान',
    descriptionEn: 'World wonders, national symbols, space, and curiosity',
    descriptionHi: 'राष्ट्रीय प्रतीक, अंतरिक्ष, विज्ञान और रोचक तथ्य',
    accentHex: '#7C3AED',
    iconKey: 'gk',
    minClass: 1,
    maxClass: 5,
  },
};

export function getSubjectsForClass(classLevel: ClassLevel): Subject[] {
  return Object.values(SUBJECT_CATALOG)
    .filter((s) => classLevel >= s.minClass && classLevel <= s.maxClass)
    .map((s) => ({
      id: s.id,
      classLevel,
      titleEn: s.titleEn,
      titleHi: s.titleHi,
      descriptionEn: s.descriptionEn,
      descriptionHi: s.descriptionHi,
      accentHex: s.accentHex,
      iconKey: s.iconKey,
    }));
}

export function getSubjectById(classLevel: ClassLevel, subjectId: string): Subject | undefined {
  return getSubjectsForClass(classLevel).find((s) => s.id === subjectId);
}

function getTopicsForSubjectAndClass(subjectId: string, classLevel: ClassLevel): TopicSeed[] {
  if (subjectId === 'math') {
    if (classLevel <= 2) {
      return [
        {
          enTitle: 'Counting & Number Line Fun',
          hiTitle: 'गिनती और संख्या रेखा की समझ',
          enSummary: 'Jump forward and backward on a visual number line to add and subtract.',
          hiSummary: 'संख्या रेखा पर आगे और पीछे कूदकर जोड़ और घटाव आसानी से सीखें।',
          enKeyPoint: 'Moving right adds (+); moving left subtracts (-).',
          hiKeyPoint: 'दाईं ओर बढ़ने पर जोड़ (+) और बाईं ओर बढ़ने पर घटाव (-) होता है।',
          enExplanation: 'Every number sits at an equal step on the number line. Starting at 4 and jumping 3 steps right lands cleanly on 7.',
          hiExplanation: 'संख्या रेखा पर हर संख्या बराबर दूरी पर होती है। 4 से शुरू करके 3 कदम दाईं ओर जाने पर हम 7 पर पहुँचते हैं।',
          enQuestion: 'If you start at 5 and jump 4 steps right, where do you land?',
          enAnswer: '9 (5 + 4 = 9)',
          hiQuestion: 'यदि आप 5 से शुरू करके 4 कदम दाईं ओर कूदते हैं, तो आप किस संख्या पर पहुँचेंगे?',
          hiAnswer: '9 (5 + 4 = 9)',
          visualKind: 'numberline',
          highlightValue: '5 + 4 = 9',
        },
        {
          enTitle: 'Shapes Around Us',
          hiTitle: 'हमारे आस-पास की आकृतियाँ',
          enSummary: 'Recognize circles, triangles, squares, and rectangles in everyday objects.',
          hiSummary: 'दैनिक जीवन की वस्तुओं में वृत्त, त्रिभुज, वर्ग और आयत पहचानें।',
          enKeyPoint: 'Triangle = 3 sides | Square = 4 equal sides | Circle = 0 corners',
          hiKeyPoint: 'त्रिभुज = 3 भुजाएँ | वर्ग = 4 बराबर भुजाएँ | वृत्त = 0 कोने',
          enExplanation: 'Flat 2D shapes help us describe wheels (circles), sandwiches (triangles), and windows (squares and rectangles).',
          hiExplanation: 'समतल आकृतियाँ हमें पहिये (वृत्त), सैंडविच (त्रिभुज) और खिड़कियों (वर्ग व आयत) को समझने में मदद करती हैं।',
          enQuestion: 'How many corners does a triangle have?',
          enAnswer: '3 corners and 3 straight sides.',
          hiQuestion: 'एक त्रिभुज में कितने कोने होते हैं?',
          hiAnswer: '3 कोने और 3 सीधी भुजाएँ।',
          visualKind: 'geometry',
          highlightValue: '3 Sides · 3 Corners',
        },
        {
          enTitle: 'Equal Sharing & Halves',
          hiTitle: 'बराबर बाँटना और आधा करना',
          enSummary: 'Split whole objects into two equal halves visually.',
          hiSummary: 'किसी पूरी वस्तु को दो बराबर भागों (आधा) में बाँटना सीखें।',
          enKeyPoint: '1 Whole = 1/2 + 1/2',
          hiKeyPoint: '1 पूरा = 1/2 + 1/2',
          enExplanation: 'When one chapati or pizza is cut into two identical pieces, each piece is called one-half (1/2).',
          hiExplanation: 'जब एक रोटी या पिज़्ज़ा को दो बिल्कुल बराबर टुकड़ों में बाँटा जाता है, तो हर टुकड़ा आधा (1/2) कहलाता है।',
          enQuestion: 'How many halves make one whole apple?',
          enAnswer: '2 equal halves make 1 whole.',
          hiQuestion: 'एक पूरा सेब बनाने के लिए कितने आधे टुकड़े चाहिए?',
          hiAnswer: '2 बराबर आधे टुकड़े मिलकर 1 पूरा बनाते हैं।',
          visualKind: 'fraction',
          highlightValue: '1/2 + 1/2 = 1',
        },
      ];
    }
    if (classLevel <= 5) {
      return [
        {
          enTitle: 'Fractions & Visual Parts',
          hiTitle: 'भिन्न (Fractions) और बराबर हिस्से',
          enSummary: 'Understand numerators, denominators, and equivalent fractions using visual bars.',
          hiSummary: 'चित्रों की मदद से अंश, हर और तुल्य भिन्न को आसानी से समझें।',
          enKeyPoint: 'Fraction = Numerator (selected parts) / Denominator (total equal parts)',
          hiKeyPoint: 'भिन्न = अंश (चुने गए भाग) / हर (कुल बराबर भाग)',
          enExplanation: 'In 3/4, the whole is split into 4 equal parts and 3 parts are shaded. Multiplying top and bottom by 2 gives the equivalent fraction 6/8.',
          hiExplanation: '3/4 में पूरी वस्तु को 4 बराबर भागों में बाँटा गया है और 3 भाग रंगे हैं। अंश और हर दोनों को 2 से गुणा करने पर तुल्य भिन्न 6/8 मिलता है।',
          enQuestion: 'What is an equivalent fraction for 1/2 with denominator 6?',
          enAnswer: '3/6 (multiply numerator and denominator by 3).',
          hiQuestion: '1/2 का हर 6 वाला तुल्य भिन्न क्या होगा?',
          hiAnswer: '3/6 (अंश और हर दोनों को 3 से गुणा करने पर)।',
          visualKind: 'fraction',
          highlightValue: '3/4 = 6/8',
        },
        {
          enTitle: 'Perimeter & Area of Rectangles',
          hiTitle: 'आयत का परिमाप और क्षेत्रफल',
          enSummary: 'Measure the boundary length and inside surface area of polygons.',
          hiSummary: 'बहुभुज की बाहरी सीमा (परिमाप) और अंदर की जगह (क्षेत्रफल) मापना सीखें।',
          enKeyPoint: 'Perimeter = 2 x (L + B) | Area = L x B',
          hiKeyPoint: 'परिमाप = 2 x (लंबाई + चौड़ाई) | क्षेत्रफल = लंबाई x चौड़ाई',
          enExplanation: 'Perimeter is the total fence around a field, while Area is the number of 1x1 unit squares covering the floor inside.',
          hiExplanation: 'परिमाप किसी मैदान के चारों ओर की कुल बाड़ की लंबाई है, जबकि क्षेत्रफल अंदर की कुल सतह का माप है।',
          enQuestion: 'Find the area of a rectangle with length 8 cm and breadth 5 cm.',
          enAnswer: '40 sq cm (8 x 5 = 40).',
          hiQuestion: '8 सेमी लंबाई और 5 सेमी चौड़ाई वाले आयत का क्षेत्रफल ज्ञात कीजिए।',
          hiAnswer: '40 वर्ग सेमी (8 x 5 = 40)।',
          visualKind: 'geometry',
          highlightValue: 'A = 8 x 5 = 40',
        },
        {
          enTitle: 'Factors, Multiples & Number Patterns',
          hiTitle: 'गुणनखंड, गुणज और संख्या पैटर्न',
          enSummary: 'Spot skip-counting multiples and prime building blocks on the number line.',
          hiSummary: 'संख्या रेखा पर गुणज और अभाज्य गुणनखंडों का पैटर्न पहचानें।',
          enKeyPoint: 'Every number has finite factors and infinite multiples.',
          hiKeyPoint: 'किसी संख्या के गुणनखंड सीमित होते हैं, लेकिन गुणज अनंत होते हैं।',
          enExplanation: 'Factors divide a number cleanly with zero remainder (factors of 12 are 1, 2, 3, 4, 6, 12). Multiples grow by repeated addition.',
          hiExplanation: 'गुणनखंड वे संख्याएँ हैं जो किसी संख्या को पूरा-पूरा विभाजित करती हैं। 12 के गुणनखंड 1, 2, 3, 4, 6 और 12 हैं।',
          enQuestion: 'List all factors of 10.',
          enAnswer: '1, 2, 5, and 10.',
          hiQuestion: '10 के सभी गुणनखंड लिखिए।',
          hiAnswer: '1, 2, 5 और 10।',
          visualKind: 'numberline',
          highlightValue: '12 = 2 x 2 x 3',
        },
      ];
    }
    if (classLevel <= 8) {
      return [
        {
          enTitle: 'Integers & Linear Equations',
          hiTitle: 'पूर्णांक और रैखिक समीकरण',
          enSummary: 'Balance positive and negative integers and solve single-variable equations.',
          hiSummary: 'धनात्मक और ऋणात्मक पूर्णांकों को संख्या रेखा पर समझें और समीकरण हल करें।',
          enKeyPoint: 'ax + b = c  =>  x = (c - b) / a',
          hiKeyPoint: 'ax + b = c  =>  x = (c - b) / a',
          enExplanation: 'An equation behaves like a balanced weighing scale. Whatever operation you apply to the left side must also be applied to the right side.',
          hiExplanation: 'एक समीकरण तराजू की तरह संतुलित रहता है। बाईं ओर जो संक्रिया की जाती है, वही दाईं ओर भी करनी होती है।',
          enQuestion: 'Solve for x: 3x + 4 = 19',
          enAnswer: '3x = 15 => x = 5.',
          hiQuestion: 'x का मान ज्ञात करें: 3x + 4 = 19',
          hiAnswer: '3x = 15 => x = 5।',
          visualKind: 'numberline',
          highlightValue: '3x + 4 = 19 -> x = 5',
        },
        {
          enTitle: 'Triangles & Angle Properties',
          hiTitle: 'त्रिभुज और कोणों के गुणधर्म',
          enSummary: 'Explore interior angle sums, exterior angles, and Pythagoras theorem.',
          hiSummary: 'त्रिभुज के अंतःकोणों का योग, बाह्य कोण और पाइथागोरस प्रमेय को दृश्य रूप में सीखें।',
          enKeyPoint: 'Angle A + Angle B + Angle C = 180 deg | a^2 + b^2 = c^2',
          hiKeyPoint: 'कोण A + कोण B + कोण C = 180° | आधार² + लंब² = कर्ण²',
          enExplanation: 'In every Euclidean triangle, the three interior angles always add up to 180 degrees. In a right triangle, the square on the hypotenuse equals the sum of squares on the other two sides.',
          hiExplanation: 'किसी भी त्रिभुज के तीनों अंतःकोणों का योग हमेशा 180 डिग्री होता है। समकोण त्रिभुज में कर्ण का वर्ग शेष दो भुजाओं के वर्गों के योग के बराबर होता है।',
          enQuestion: 'If two angles of a triangle are 50 deg and 65 deg, find the third angle.',
          enAnswer: '180 - (50 + 65) = 65 degrees.',
          hiQuestion: 'यदि किसी त्रिभुज के दो कोण 50° और 65° हैं, तो तीसरा कोण क्या होगा?',
          hiAnswer: '180 - (50 + 65) = 65 डिग्री।',
          visualKind: 'geometry',
          highlightValue: 'A + B + C = 180°',
        },
        {
          enTitle: 'Ratios, Percentages & Proportions',
          hiTitle: 'अनुपात, प्रतिशत और समानुपात',
          enSummary: 'Convert fractions to percentages and compare quantities proportionally.',
          hiSummary: 'भिन्नों को प्रतिशत में बदलना और दैनिक जीवन में अनुपात की तुलना सीखें।',
          enKeyPoint: 'Percentage = (Part / Whole) x 100%',
          hiKeyPoint: 'प्रतिशत = (भाग / कुल) x 100%',
          enExplanation: 'Percent literally means per hundred. Converting 3/4 to a percentage gives (3/4) x 100 = 75%.',
          hiExplanation: 'प्रतिशत का अर्थ प्रति सौ होता है। 3/4 को प्रतिशत में बदलने पर (3/4) x 100 = 75% प्राप्त होता है।',
          enQuestion: 'What is 25% of 240?',
          enAnswer: '60 (25/100 x 240 = 60).',
          hiQuestion: '240 का 25% कितना होगा?',
          hiAnswer: '60 (25/100 x 240 = 60)।',
          visualKind: 'fraction',
          highlightValue: '3/4 = 75%',
        },
      ];
    }
    return [
      {
        enTitle: 'Quadratic Equations & Parabolas',
        hiTitle: 'द्विघात समीकरण और परवलय',
        enSummary: 'Factorize quadratics and find roots using the discriminant formula.',
        hiSummary: 'गुणनखंड और विविक्तकर सूत्र की मदद से द्विघात समीकरण के मूल ज्ञात करें।',
        enKeyPoint: 'x = (-b +/- sqrt(b^2 - 4ac)) / (2a)',
        hiKeyPoint: 'x = (-b +/- sqrt(b^2 - 4ac)) / (2a)',
        enExplanation: 'The discriminant D = b^2 - 4ac tells us whether a quadratic curve crosses the x-axis twice (D > 0), touches once (D = 0), or has no real roots (D < 0).',
        hiExplanation: 'विविक्तकर D = b^2 - 4ac बताता है कि समीकरण के दो वास्तविक मूल हैं (D > 0), बराबर मूल हैं (D = 0), या कोई वास्तविक मूल नहीं है (D < 0)।',
        enQuestion: 'Find the roots of x^2 - 5x + 6 = 0.',
        enAnswer: '(x - 2)(x - 3) = 0 => x = 2 or x = 3.',
        hiQuestion: 'x^2 - 5x + 6 = 0 के मूल ज्ञात कीजिए।',
        hiAnswer: '(x - 2)(x - 3) = 0 => x = 2 या x = 3।',
        visualKind: 'numberline',
        highlightValue: 'D = b² - 4ac',
      },
      {
        enTitle: 'Trigonometry & Right Triangles',
        hiTitle: 'त्रिकोणमिति और समकोण त्रिभुज',
        enSummary: 'Master sine, cosine, tangent ratios and height-distance applications.',
        hiSummary: 'साइन, कोसाइन, टैन्जेंट अनुपात और ऊँचाई-दूरी के व्यावहारिक प्रश्न हल करें।',
        enKeyPoint: 'sin^2(theta) + cos^2(theta) = 1 | tan(theta) = Opp / Adj',
        hiKeyPoint: 'sin²θ + cos²θ = 1 | tan θ = लंब / आधार',
        enExplanation: 'Trigonometric ratios depend solely on the acute angle in a right-angled triangle, not on the overall size of the triangle.',
        hiExplanation: 'समकोण त्रिभुज में त्रिकोणमितीय अनुपात केवल कोण पर निर्भर करते हैं, त्रिभुज के आकार पर नहीं।',
        enQuestion: 'If sin(theta) = 3/5 in a right triangle, what is cos(theta)?',
        enAnswer: '4/5 (using 3-4-5 right triangle or sin^2 + cos^2 = 1).',
        hiQuestion: 'यदि समकोण त्रिभुज में sin θ = 3/5 है, तो cos θ का मान क्या होगा?',
        hiAnswer: '4/5 (sin²θ + cos²θ = 1 से)।',
        visualKind: 'geometry',
        highlightValue: 'sin²θ + cos²θ = 1',
      },
      {
        enTitle: 'Probability & Statistics',
        hiTitle: 'प्रायिकता और सांख्यिकी',
        enSummary: 'Compute mean, median, and theoretical event probabilities cleanly.',
        hiSummary: 'माध्य, माध्यिका और किसी घटना की प्रायिकता की गणना करना सीखें।',
        enKeyPoint: 'P(E) = Favorable Outcomes / Total Possible Outcomes',
        hiKeyPoint: 'P(E) = अनुकूल परिणाम / कुल संभावित परिणाम',
        enExplanation: 'Probability always lies between 0 (impossible event) and 1 (certain event). Complementary events satisfy P(E) + P(not E) = 1.',
        hiExplanation: 'प्रायिकता का मान सदैव 0 (असंभव घटना) से 1 (निश्चित घटना) के बीच होता है। P(E) + P(E-नहीं) = 1 होता है।',
        enQuestion: 'What is the probability of getting an even number on a fair 6-sided die?',
        enAnswer: '3/6 = 1/2 (outcomes 2, 4, 6).',
        hiQuestion: 'एक पासे को फेंकने पर सम संख्या आने की प्रायिकता क्या होगी?',
        hiAnswer: '3/6 = 1/2 (अनुकूल परिणाम: 2, 4, 6)।',
        visualKind: 'fraction',
        highlightValue: '0 <= P(E) <= 1',
      },
    ];
  }

  if (subjectId === 'evs' || subjectId === 'science') {
    if (classLevel <= 5) {
      return [
        {
          enTitle: 'Parts of a Plant & Photosynthesis',
          hiTitle: 'पौधे के भाग और प्रकाश संश्लेषण',
          enSummary: 'See how roots absorb water and leaves make food using sunlight.',
          hiSummary: 'देखें कि जड़ें पानी कैसे सोखती हैं और पत्तियाँ धूप में भोजन कैसे बनाती हैं।',
          enKeyPoint: 'Sunlight + Water + CO2 -> Plant Food (Glucose) + Oxygen',
          hiKeyPoint: 'सूर्य का प्रकाश + जल + CO2 -> भोजन (ग्लूकोज) + ऑक्सीजन',
          enExplanation: 'Green leaves contain chlorophyll, which acts like a solar kitchen. Roots drink minerals and water from soil while stems carry them upward.',
          hiExplanation: 'हरी पत्तियों में क्लोरोफिल होता है जो सूर्य के प्रकाश की मदद से पौधे के लिए भोजन बनाता है। जड़ें मिट्टी से जल और खनिज सोखती हैं।',
          enQuestion: 'Which gas do green plants release during photosynthesis?',
          enAnswer: 'Oxygen (O2).',
          hiQuestion: 'प्रकाश संश्लेषण के दौरान हरे पौधे कौन सी गैस छोड़ते हैं?',
          hiAnswer: 'ऑक्सीजन (O2)।',
          visualKind: 'plant',
          highlightValue: 'Chlorophyll + Sun -> O2',
        },
        {
          enTitle: 'Our Solar System & Planets',
          hiTitle: 'हमारा सौर मंडल और ग्रह',
          enSummary: 'Explore the Sun and the eight planets orbiting around it.',
          hiSummary: 'सूर्य और उसके चारों ओर घूमने वाले आठ ग्रहों की रोचक यात्रा करें।',
          enKeyPoint: '8 Planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune',
          hiKeyPoint: '8 ग्रह: बुध, शुक्र, पृथ्वी, मंगल, बृहस्पति, शनि, अरुण, वरुण',
          enExplanation: 'The Sun is a star at the center. Earth takes 365.25 days to orbit the Sun and 24 hours to spin once on its axis, creating day and night.',
          hiExplanation: 'सूर्य सौर मंडल के केंद्र में स्थित एक तारा है। पृथ्वी सूर्य की एक परिक्रमा लगभग 365 दिन में पूरी करती है और अपनी धुरी पर 24 घंटे में घूमकर दिन-रात बनाती है।',
          enQuestion: 'Which planet is known as the Red Planet?',
          enAnswer: 'Mars.',
          hiQuestion: 'किस ग्रह को लाल ग्रह कहा जाता है?',
          hiAnswer: 'मंगल ग्रह (Mars)।',
          visualKind: 'solar',
          highlightValue: 'Earth Orbit: 365 Days',
        },
        {
          enTitle: 'Simple Electric Torch Circuit',
          hiTitle: 'सरल विद्युत परिपथ (बल्ब और सेल)',
          enSummary: 'Learn how a battery, switch, and wire form a closed loop to glow a bulb.',
          hiSummary: 'बैटरी, स्विच और तार से बंद परिपथ बनाकर बल्ब जलाना सीखें।',
          enKeyPoint: 'Current flows only in a closed circuit.',
          hiKeyPoint: 'विद्युत धारा केवल बंद परिपथ (Closed Circuit) में ही प्रवाहित होती है।',
          enExplanation: 'When the switch is ON, the metal path is complete and electrons flow from the cell through the bulb filament, making it glow.',
          hiExplanation: 'जब स्विच चालू (ON) होता है, तो पथ पूरा हो जाता है और सेल से विद्युत धारा बल्ब के फिलामेंट से होकर बहती है जिससे बल्ब जल उठता है।',
          enQuestion: 'Why does a bulb stop glowing when the switch is OFF?',
          enAnswer: 'Because the circuit becomes open (broken), stopping current flow.',
          hiQuestion: 'स्विच बंद (OFF) करने पर बल्ब क्यों बुझ जाता है?',
          hiAnswer: 'क्योंकि परिपथ टूट (खुला) जाता है और धारा रुक जाती है।',
          visualKind: 'circuit',
          highlightValue: 'Closed Loop = Light ON',
        },
      ];
    }
    return [
      {
        enTitle: 'Atomic Structure & Electron Shells',
        hiTitle: 'परमाणु संरचना और इलेक्ट्रॉन कक्ष',
        enSummary: 'Visualize protons, neutrons in the nucleus, and orbiting electrons.',
        hiSummary: 'नाभिक में प्रोटॉन-न्यूट्रॉन और चारों ओर घूमते इलेक्ट्रॉनों की संरचना समझें।',
        enKeyPoint: 'Atomic Number (Z) = Protons | Max shell capacity = 2n^2',
        hiKeyPoint: 'परमाणु क्रमांक (Z) = प्रोटॉन | कक्ष क्षमता = 2n²',
        enExplanation: 'Atoms are electrically neutral when protons (+1) equal electrons (-1). Valence electrons in the outermost shell govern chemical bonding.',
        hiExplanation: 'परमाणु में धनावेशित प्रोटॉन और ऋणावेशित इलेक्ट्रॉन बराबर होने पर वह उदासीन होता है। बाहरी कक्ष के इलेक्ट्रॉन रासायनिक बंध बनाते हैं।',
        enQuestion: 'What is the maximum number of electrons in the L-shell (n = 2)?',
        enAnswer: '2 x (2^2) = 8 electrons.',
        hiQuestion: 'L-कक्ष (n = 2) में अधिकतम कितने इलेक्ट्रॉन आ सकते हैं?',
        hiAnswer: '2 x (2²) = 8 इलेक्ट्रॉन।',
        visualKind: 'atom',
        highlightValue: '2n² Shell Rule',
      },
      {
        enTitle: 'Force, Motion & Newton Laws',
        hiTitle: 'बल, गति और न्यूटन के नियम',
        enSummary: 'Understand inertia, acceleration (F = ma), and action-reaction pairs.',
        hiSummary: 'जड़त्व, त्वरण (F = ma) और क्रिया-प्रतिक्रिया के नियमों को एनिमेशन से समझें।',
        enKeyPoint: 'Force = Mass x Acceleration (F = m x a, Unit: Newton)',
        hiKeyPoint: 'बल = द्रव्यमान x त्वरण (F = m x a, मात्रक: न्यूटन)',
        enExplanation: 'An object stays at rest or constant velocity unless acted on by an unbalanced force. Doubling force on the same mass doubles acceleration.',
        hiExplanation: 'जब तक कोई बाहरी असंतुलित बल न लगे, वस्तु अपनी अवस्था नहीं बदलती। समान द्रव्यमान पर बल दोगुना करने से त्वरण भी दोगुना हो जाता है।',
        enQuestion: 'How much force accelerates a 4 kg block at 3 m/s^2?',
        enAnswer: '12 Newtons (4 x 3 = 12 N).',
        hiQuestion: '4 किग्रा द्रव्यमान में 3 मी/से² का त्वरण उत्पन्न करने के लिए कितना बल चाहिए?',
        hiAnswer: '12 न्यूटन (4 x 3 = 12 N)।',
        visualKind: 'force',
        highlightValue: 'F = m × a',
      },
      {
        enTitle: 'Ohm Law & Series-Parallel Circuits',
        hiTitle: 'ओम का नियम और विद्युत परिपथ',
        enSummary: 'Relate voltage, current, and resistance in interactive circuits.',
        hiSummary: 'विभवांतर, विद्युत धारा और प्रतिरोध के बीच संबंध को प्रयोग द्वारा समझें।',
        enKeyPoint: 'V = I x R (Volts = Amperes x Ohms)',
        hiKeyPoint: 'V = I × R (वोल्ट = एम्पीयर × ओम)',
        enExplanation: 'At constant temperature, current through a metallic conductor is directly proportional to potential difference across its ends.',
        hiExplanation: 'स्थिर ताप पर किसी चालक में प्रवाहित धारा उसके सिरों के बीच विभवांतर के समानुपाती होती है।',
        enQuestion: 'Find the current when a 12 V battery drives a 4 Ohm resistor.',
        enAnswer: 'I = V / R = 12 / 4 = 3 Amperes.',
        hiQuestion: '12 वोल्ट की बैटरी से 4 ओम के प्रतिरोध में कितनी धारा बहेगी?',
        hiAnswer: 'I = V / R = 12 / 4 = 3 एम्पीयर।',
        visualKind: 'circuit',
        highlightValue: 'V = I × R',
      },
    ];
  }

  if (subjectId === 'english') {
    return [
      {
        enTitle: 'Parts of Speech & Sentence Builder',
        hiTitle: 'Parts of Speech और वाक्य निर्माण',
        enSummary: 'Combine nouns, verbs, adjectives, and prepositions into crisp sentences.',
        hiSummary: 'संज्ञा, क्रिया, विशेषण और पूर्वसर्ग को मिलाकर सही अंग्रेजी वाक्य बनाना सीखें।',
        enKeyPoint: 'Subject + Helping/Main Verb + Object',
        hiKeyPoint: 'कर्ता (Subject) + क्रिया (Verb) + कर्म (Object)',
        enExplanation: 'Nouns name people or things, verbs show action or state, and adjectives enrich nouns with vivid detail.',
        hiExplanation: 'Noun नाम बताता है, Verb कार्य को दर्शाता है, और Adjective किसी संज्ञा की विशेषता बताता है।',
        enQuestion: 'Identify the verb and adjective in: "The bright student reads daily."',
        enAnswer: 'Adjective: bright | Verb: reads.',
        hiQuestion: '"The bright student reads daily." में Adjective और Verb पहचानें।',
        hiAnswer: 'Adjective: bright | Verb: reads।',
        visualKind: 'grammar',
        highlightValue: 'Subject + Verb + Object',
      },
      {
        enTitle: 'Tenses: Past, Present & Future',
        hiTitle: 'काल (Tenses): भूत, वर्तमान और भविष्य',
        enSummary: 'Master time markers and verb forms for clear everyday communication.',
        hiSummary: 'तीनों कालों के मुख्य नियम और क्रिया के रूप आसानी से सीखें।',
        enKeyPoint: 'Present: V1/V1+s | Past: V2 | Future: will + V1',
        hiKeyPoint: 'Present: V1/V1+s | Past: V2 | Future: will + V1',
        enExplanation: 'Choosing the right tense tells your listener whether an action happened yesterday, is happening right now, or will happen tomorrow.',
        hiExplanation: 'सही Tense का प्रयोग बताता है कि कार्य कल हुआ था, अभी हो रहा है, या आने वाले समय में होगा।',
        enQuestion: 'Convert to Past Simple: "Riya writes a letter."',
        enAnswer: 'Riya wrote a letter.',
        hiQuestion: '"Riya writes a letter." को Past Simple में बदलें।',
        hiAnswer: 'Riya wrote a letter.',
        visualKind: 'grammar',
        highlightValue: 'Past -> Present -> Future',
      },
      {
        enTitle: 'Active & Passive Voice Clarity',
        hiTitle: 'Active और Passive Voice के नियम',
        enSummary: 'Transform sentences cleanly by shifting focus from doer to action.',
        hiSummary: 'कर्ता और कर्म के स्थान बदलकर Active से Passive Voice बनाना सीखें।',
        enKeyPoint: 'Passive = Object + be-verb + V3 (Past Participle) + by + Subject',
        hiKeyPoint: 'Passive = Object + सहायक क्रिया + V3 + by + Subject',
        enExplanation: 'Active voice highlights who performs an action ("Aarav solved the puzzle"), whereas passive voice highlights what received the action ("The puzzle was solved by Aarav").',
        hiExplanation: 'Active voice में कर्ता प्रमुख होता है और Passive voice में कर्म पर जोर दिया जाता है।',
        enQuestion: 'Change to Passive Voice: "The teacher praised Ananya."',
        enAnswer: 'Ananya was praised by the teacher.',
        hiQuestion: 'Passive Voice में बदलें: "The teacher praised Ananya."',
        hiAnswer: 'Ananya was praised by the teacher.',
        visualKind: 'grammar',
        highlightValue: 'be + V3 + by Subject',
      },
    ];
  }

  if (subjectId === 'hindi') {
    return [
      {
        enTitle: 'Hindi Varnamala, Swar & Vyanjan',
        hiTitle: 'हिंदी वर्णमाला: स्वर और व्यंजन',
        enSummary: 'Understand pronunciation, matras, and word formation in Hindi.',
        hiSummary: 'स्वर, व्यंजन, मात्राओं और शुद्ध उच्चारण की संपूर्ण समझ।',
        enKeyPoint: '11 Swar (अ से औ) · 33 Vyanjan (क से ह)',
        hiKeyPoint: '11 मुख्य स्वर (अ–औ) · 33 मूल व्यंजन (क–ह)',
        enExplanation: 'Swar are pronounced freely without obstruction, while Vyanjan require the support of Swar for complete sound and matra formation.',
        hiExplanation: 'स्वर स्वतंत्र रूप से बोले जाते हैं, जबकि व्यंजनों के उच्चारण में स्वर की सहायता ली जाती है।',
        enQuestion: 'How many main vowels (Swar) are there in Hindi?',
        enAnswer: '11 main vowels (अ, आ, इ, ई, उ, ऊ, ऋ, ए, ऐ, ओ, औ).',
        hiQuestion: 'हिंदी वर्णमाला में मुख्य स्वरों की संख्या कितनी है?',
        hiAnswer: '11 मुख्य स्वर (अ, आ, इ, ई, उ, ऊ, ऋ, ए, ऐ, ओ, औ)।',
        visualKind: 'grammar',
        highlightValue: '11 स्वर · 33 व्यंजन',
      },
      {
        enTitle: 'Sangya, Sarvanam & Visheshan',
        hiTitle: 'संज्ञा, सर्वनाम और विशेषण',
        enSummary: 'Identify naming words, pronouns, and describing words in Hindi prose.',
        hiSummary: 'वाक्यों में संज्ञा, सर्वनाम और विशेषण की पहचान व प्रयोग सीखें।',
        enKeyPoint: 'Sangya (Name) · Sarvanam (Replaces Noun) · Visheshan (Describes)',
        hiKeyPoint: 'संज्ञा (नाम) · सर्वनाम (संज्ञा के स्थान पर) · विशेषण (गुण/संख्या)',
        enExplanation: 'Using Sarvanam avoids repeating nouns again and again, making stories smooth and expressive.',
        hiExplanation: 'संज्ञा किसी व्यक्ति, वस्तु या स्थान का नाम है। सर्वनाम संज्ञा की पुनरावृत्ति को रोकता है और भाषा को सुंदर बनाता है।',
        enQuestion: '"नीला आसमान बहुत सुंदर है" — इसमें विशेषण शब्द कौन सा है?',
        enAnswer: '"नीला" और "सुंदर" विशेषण शब्द हैं।',
        hiQuestion: '"नीला आसमान बहुत सुंदर है" — इसमें विशेषण शब्द कौन सा है?',
        hiAnswer: '"नीला" और "सुंदर" विशेषण शब्द हैं।',
        visualKind: 'grammar',
        highlightValue: 'संज्ञा -> सर्वनाम -> विशेषण',
      },
      {
        enTitle: 'Sandhi, Samas & Muhavare',
        hiTitle: 'संधि, समास और प्रमुख मुहावरे',
        enSummary: 'Master word joining rules and rich idiomatic expressions.',
        hiSummary: 'दो वर्णों के मेल (संधि), शब्दों के संक्षेप (समास) और मुहावरों का अभ्यास।',
        enKeyPoint: 'Vidya + Alaya = Vidyalaya (Dirgha Swar Sandhi)',
        hiKeyPoint: 'विद्या + आलय = विद्यालय (दीर्घ स्वर संधि)',
        enExplanation: 'Sandhi joins neighboring sounds smoothly, while Samas combines two or more meaningful words into a concise compound word.',
        hiExplanation: 'संधि दो निकटवर्ती वर्णों के मेल से होने वाला परिवर्तन है, जबकि समास शब्दों को संक्षिप्त करने की विधि है।',
        enQuestion: '"सूर्य + उदय" की संधि क्या होगी?',
        enAnswer: 'सूर्योदय (गुण स्वर संधि)।',
        hiQuestion: '"सूर्य + उदय" की संधि क्या होगी?',
        hiAnswer: 'सूर्योदय (गुण स्वर संधि)।',
        visualKind: 'grammar',
        highlightValue: 'विद्या + आलय = विद्यालय',
      },
    ];
  }

  if (subjectId === 'social') {
    return [
      {
        enTitle: 'Indian Geography: Rivers & Mountains',
        hiTitle: 'भारत का भूगोल: नदियाँ और पर्वत श्रृंखलाएँ',
        enSummary: 'Explore the Himalayas, fertile Northern Plains, Deccan Plateau, and major rivers.',
        hiSummary: 'हिमालय, उत्तर के विशाल मैदान, दक्कन का पठार और प्रमुख नदियों को मानचित्र पर समझें।',
        enKeyPoint: '6 Major Physiographic Divisions of India',
        hiKeyPoint: 'भारत के 6 प्रमुख भौतिक विभाग',
        enExplanation: 'Himalayan rivers like the Ganga and Brahmaputra flow year-round from glaciers, supporting fertile agriculture across the plains.',
        hiExplanation: 'हिमालय से निकलने वाली गंगा और ब्रह्मपुत्र जैसी नदियाँ वर्ष भर बहती हैं और मैदानों को उपजाऊ बनाती हैं।',
        enQuestion: 'Which mountain range forms the northern boundary of India?',
        enAnswer: 'The Himalayas.',
        hiQuestion: 'भारत की उत्तरी सीमा पर कौन सी विशाल पर्वत श्रृंखला स्थित है?',
        hiAnswer: 'हिमालय पर्वत श्रृंखला।',
        visualKind: 'map',
        highlightValue: 'Himalayas · Ganga · Deccan',
      },
      {
        enTitle: 'Indian Constitution & Fundamental Rights',
        hiTitle: 'भारतीय संविधान और मौलिक अधिकार',
        enSummary: 'Learn how democracy, equality, and fundamental rights protect every citizen.',
        hiSummary: 'लोकतंत्र, समानता और नागरिकों के छह मौलिक अधिकारों की स्पष्ट समझ।',
        enKeyPoint: '6 Fundamental Rights · Adopted on 26 Nov 1949',
        hiKeyPoint: '6 मौलिक अधिकार · संविधान लागू: 26 जनवरी 1950',
        enExplanation: 'The Constitution guarantees Equality, Freedom, Against Exploitation, Freedom of Religion, Cultural Rights, and Constitutional Remedies.',
        hiExplanation: 'संविधान सभी नागरिकों को समानता, स्वतंत्रता, शोषण के विरुद्ध अधिकार, धार्मिक स्वतंत्रता और संवैधानिक उपचार का अधिकार देता है।',
        enQuestion: 'On which date is Republic Day celebrated in India?',
        enAnswer: '26 January (Constitution came into force in 1950).',
        hiQuestion: 'भारत में गणतंत्र दिवस किस तिथि को मनाया जाता है?',
        hiAnswer: '26 जनवरी (1950 में संविधान लागू हुआ)।',
        visualKind: 'map',
        highlightValue: 'Article 14–32 · Rights',
      },
      {
        enTitle: 'Indus Valley & Ancient Heritage',
        hiTitle: 'सिंधु घाटी सभ्यता और प्राचीन विरासत',
        enSummary: 'Discover planned cities, drainage systems, and trade of Harappa and Mohenjo-daro.',
        hiSummary: 'हड़प्पा और मोहनजोदड़ो की नगर योजना, जल निकासी और व्यापार प्रणाली जानें।',
        enKeyPoint: 'Grid-pattern streets · Great Bath · Baked brick houses',
        hiKeyPoint: 'सुनियोजित नगर · विशाल स्नानागार · पकी ईंटों के घर',
        enExplanation: 'Nearly 4,500 years ago, Indus cities featured covered street drains, granaries, and standardized weights for trade.',
        hiExplanation: 'लगभग 4,500 वर्ष पूर्व सिंधु घाटी के शहरों में ढकी हुई नालियाँ, अन्नागार और मानक तौल प्रणाली मौजूद थी।',
        enQuestion: 'Name two famous cities of the Indus Valley Civilization.',
        enAnswer: 'Harappa and Mohenjo-daro (also Lothal, Dholavira).',
        hiQuestion: 'सिंधु घाटी सभ्यता के दो प्रमुख नगरों के नाम बताइए।',
        hiAnswer: 'हड़प्पा और मोहनजोदड़ो (लोथल, धोलावीरा भी)।',
        visualKind: 'map',
        highlightValue: '2500 BCE Urban Planning',
      },
    ];
  }

  // General Knowledge (Classes 1-5)
  return [
    {
      enTitle: 'National Symbols of India',
      hiTitle: 'भारत के राष्ट्रीय प्रतीक',
      enSummary: 'Know our National Flag, Emblem, Bird, Animal, Flower, and Anthem.',
      hiSummary: 'राष्ट्रीय ध्वज, चिह्न, पक्षी, पशु, पुष्प और राष्ट्रगान की जानकारी।',
      enKeyPoint: 'National Animal: Tiger | National Bird: Peacock | Flower: Lotus',
      hiKeyPoint: 'राष्ट्रीय पशु: बाघ | राष्ट्रीय पक्षी: मोर | राष्ट्रीय पुष्प: कमल',
      enExplanation: 'The Tiranga has three horizontal bands — saffron for courage, white with the 24-spoke Ashoka Chakra for truth, and green for growth.',
      hiExplanation: 'तिरंगे में तीन पट्टियाँ हैं — केसरिया साहस का, सफेद व 24 तीलियों वाला अशोक चक्र सत्य का, और हरा विकास का प्रतीक है।',
      enQuestion: 'How many spokes are there in the Ashoka Chakra?',
      enAnswer: '24 spokes.',
      hiQuestion: 'अशोक चक्र में कुल कितनी तीलियाँ होती हैं?',
      hiAnswer: '24 तीलियाँ।',
      visualKind: 'map',
      highlightValue: '24 Spokes · Tiranga',
    },
    {
      enTitle: 'Space Explorers & Chandrayaan',
      hiTitle: 'अंतरिक्ष यात्री और चंद्रयान मिशन',
      enSummary: 'Discover rockets, satellites, and India’s historic Moon landing.',
      hiSummary: 'रॉकेट, उपग्रह और भारत के ऐतिहासिक चंद्रयान-3 मिशन के बारे में जानें।',
      enKeyPoint: 'Chandrayaan-3 landed near Moon South Pole in August 2023',
      hiKeyPoint: 'चंद्रयान-3 ने अगस्त 2023 में चंद्रमा के दक्षिणी ध्रुव के पास सफल लैंडिंग की',
      enExplanation: 'ISRO sends satellites to study weather, guide ships, and explore planets like Mars and the Moon.',
      hiExplanation: 'इसरो (ISRO) मौसम की जानकारी, संचार और चंद्रमा-मंगल के अध्ययन के लिए उपग्रह भेजता है।',
      enQuestion: 'Which space agency launched Chandrayaan-3?',
      enAnswer: 'ISRO (Indian Space Research Organisation).',
      hiQuestion: 'चंद्रयान-3 किस अंतरिक्ष एजेंसी द्वारा भेजा गया था?',
      hiAnswer: 'इसरो (ISRO - भारतीय अंतरिक्ष अनुसंधान संगठन)।',
      visualKind: 'solar',
      highlightValue: 'ISRO · Chandrayaan-3',
    },
  ];
}

function buildScenes(topic: TopicSeed, language: LanguageCode): AnimatedScene[] {
  const isHi = language === 'hi';
  return [
    {
      id: 'scene-1',
      title: isHi ? '1. मुख्य अवधारणा (Core Concept)' : '1. Core Concept Visual',
      caption: isHi ? topic.hiSummary : topic.enSummary,
      visualKind: topic.visualKind,
      highlightValue: topic.highlightValue,
      durationSec: 12,
    },
    {
      id: 'scene-2',
      title: isHi ? '2. मुख्य सूत्र / नियम (Key Rule)' : '2. Key Formula & Rule',
      caption: isHi ? topic.hiKeyPoint : topic.enKeyPoint,
      visualKind: topic.visualKind,
      highlightValue: topic.highlightValue,
      durationSec: 14,
    },
    {
      id: 'scene-3',
      title: isHi ? '3. उदाहरण सहित व्याख्या' : '3. Animated Explanation',
      caption: isHi ? topic.hiExplanation : topic.enExplanation,
      visualKind: topic.visualKind,
      highlightValue: topic.highlightValue,
      durationSec: 14,
    },
    {
      id: 'scene-4',
      title: isHi ? '4. त्वरित अभ्यास (Quick Check)' : '4. Quick Check & Recap',
      caption: isHi
        ? `प्रश्न: ${topic.hiQuestion} — उत्तर: ${topic.hiAnswer}`
        : `Q: ${topic.enQuestion} — Ans: ${topic.enAnswer}`,
      visualKind: topic.visualKind,
      highlightValue: topic.highlightValue,
      durationSec: 10,
    },
  ];
}

export function getNotesForSubject(
  classLevel: ClassLevel,
  subjectId: string,
  language: LanguageCode
): ChapterNote[] {
  const topics = getTopicsForSubjectAndClass(subjectId, classLevel);
  const isHi = language === 'hi';
  return topics.map((t, index) => {
    const ch = index + 1;
    const id = `note_c${classLevel}_${subjectId}_${language}_ch${ch}`;
    return {
      id,
      subjectId,
      classLevel,
      language,
      chapterNumber: ch,
      title: isHi ? t.hiTitle : t.enTitle,
      summary: isHi ? t.hiSummary : t.enSummary,
      readTimeMinutes: 4 + index,
      sections: [
        {
          heading: isHi ? 'मुख्य बिंदु और परिभाषा' : 'Core Concept & Definition',
          body: isHi ? t.hiExplanation : t.enExplanation,
          keyFormulaOrPoint: isHi ? t.hiKeyPoint : t.enKeyPoint,
        },
        {
          heading: isHi ? 'त्वरित पुनरावृत्ति (Revision)' : 'Quick Revision Summary',
          body: isHi
            ? `कक्षा ${classLevel} के विद्यार्थियों के लिए अध्याय ${ch} का संक्षिप्त सारांश: ${t.hiSummary}`
            : `Class ${classLevel} Chapter ${ch} takeaway: ${t.enSummary}`,
          keyFormulaOrPoint: t.highlightValue,
        },
      ],
      practiceQuestion: {
        question: isHi ? t.hiQuestion : t.enQuestion,
        answer: isHi ? t.hiAnswer : t.enAnswer,
      },
    };
  });
}

export function getVideosForSubject(
  classLevel: ClassLevel,
  subjectId: string,
  language: LanguageCode
): ChapterVideo[] {
  const topics = getTopicsForSubjectAndClass(subjectId, classLevel);
  const isHi = language === 'hi';
  return topics.map((t, index) => {
    const ch = index + 1;
    const scenes = buildScenes(t, language);
    const totalSec = scenes.reduce((acc, s) => acc + s.durationSec, 0);
    const id = `vid_c${classLevel}_${subjectId}_${language}_ch${ch}`;
    return {
      id,
      subjectId,
      classLevel,
      language,
      chapterNumber: ch,
      title: isHi ? `${t.hiTitle} — एनिमेटेड पाठ` : `${t.enTitle} — Animated Lesson`,
      summary: isHi ? t.hiSummary : t.enSummary,
      durationLabel: `0:${totalSec < 10 ? `0${totalSec}` : totalSec} min`,
      durationSec: totalSec,
      scenes,
    };
  });
}

export function getAllNotesForClassAndLang(
  classLevel: ClassLevel,
  language: LanguageCode
): ChapterNote[] {
  return getSubjectsForClass(classLevel).flatMap((sub) =>
    getNotesForSubject(classLevel, sub.id, language)
  );
}

export function getAllVideosForClassAndLang(
  classLevel: ClassLevel,
  language: LanguageCode
): ChapterVideo[] {
  return getSubjectsForClass(classLevel).flatMap((sub) =>
    getVideosForSubject(classLevel, sub.id, language)
  );
}

export function findBuiltInNoteById(noteId: string): ChapterNote | undefined {
  for (let c = 1; c <= 10; c++) {
    const classLevel = c as ClassLevel;
    for (const lang of ['en', 'hi'] as LanguageCode[]) {
      const match = getAllNotesForClassAndLang(classLevel, lang).find((n) => n.id === noteId);
      if (match) return match;
    }
  }
  return undefined;
}

export function findBuiltInVideoById(videoId: string): ChapterVideo | undefined {
  for (let c = 1; c <= 10; c++) {
    const classLevel = c as ClassLevel;
    for (const lang of ['en', 'hi'] as LanguageCode[]) {
      const match = getAllVideosForClassAndLang(classLevel, lang).find((v) => v.id === videoId);
      if (match) return match;
    }
  }
  return undefined;
}
