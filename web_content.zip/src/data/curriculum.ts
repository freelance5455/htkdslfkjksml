export type Block =
  | { k: "h"; it: string; ar: string }
  | { k: "p"; it: string; ar: string }
  | { k: "note"; it: string; ar: string }
  | { k: "signs"; ids: string[] };

export type Chapter = {
  n: number;
  slug: string;
  titleIt: string;
  titleAr: string;
  summaryAr: string;
  blocks: Block[];
};

const h = (it: string, ar: string): Block => ({ k: "h", it, ar });
const p = (it: string, ar: string): Block => ({ k: "p", it, ar });
const note = (it: string, ar: string): Block => ({ k: "note", it, ar });
const signs = (ids: string[]): Block => ({ k: "signs", ids });

export const CHAPTERS: Chapter[] = [
  {
    n: 1,
    slug: "definizioni",
    titleIt: "Definizioni e doveri",
    titleAr: "تعريفات وواجبات الطريق",
    summaryAr: "أسماء أجزاء الطريق وأنواع المركبات، والواجب العام بعدم خلق خطر أو إعاقة.",
    blocks: [
      p(
        "La strada comprende la carreggiata, le banchine, i marciapiedi e le pertinenze. La carreggiata è la parte destinata al transito dei veicoli.",
        "الطريق يشمل سطح السير وأكتافه وأرصفة المشاة وملحقاته. سطح السير (carreggiata) هو الجزء المخصّص لمرور المركبات.",
      ),
      p(
        "La corsia è una banda longitudinale della carreggiata, larga abbastanza per una fila di veicoli. La banchina è lo spazio laterale fra carreggiata e limite esterno della strada.",
        "المسلك (corsia) شريط طولي يكفي لصف واحد من المركبات. الكتف (banchina) هو الفراغ الجانبي بين سطح السير وحد الطريق.",
      ),
      p(
        "L'intersezione è l'area in cui due o più strade si incontrano. Il passaggio a livello è l'incrocio fra una strada e una ferrovia.",
        "التقاطع هو المساحة التي تلتقي فيها طرق. المزلقان هو تلاقي طريق مع سكة حديد.",
      ),
      h("Tipi di strada", "أنواع الطرق"),
      p(
        "Nel centro abitato il limite ordinario per le autovetture è 50 km/h. Fuori, si distinguono la strada extraurbana secondaria (90), la strada extraurbana principale (110) e l'autostrada (130).",
        "داخل العمران الحد العادي للسيارات 50 كم/س. خارجه: طريق ثانوي 90، طريق رئيسي 110، وأوتوسترادا 130.",
      ),
      p(
        "L'autostrada ha carreggiate separate, è riservata a certe categorie ed è segnalata col verde. Non ci circolano pedoni, biciclette, ciclomotori, veicoli a trazione animale né veicoli non in grado di mantenere una velocità adeguata.",
        "الأوتوسترادا مسارات منفصلة ومخصّصة لفئات معيّنة وعلامتها خضراء. ممنوع المشاة والدراجات والدراجات البخارية الصغيرة ومركبات الجر الحيواني، وكل مركبة لا تستطيع الحفاظ على سرعة مناسبة.",
      ),
      h("Veicoli e patente B", "المركبات ورخصة B"),
      p(
        "Con la patente B si guidano autoveicoli fino a 3500 kg e fino a 8 passeggeri oltre il conducente. Si può trainare un rimorchio fino a 750 kg, oppure più pesante se la massa complessiva del complesso non supera 3500 kg.",
        "برخصة B تقود مركبات حتى 3500 كغ وحتى 8 ركّاب بالإضافة إلى السائق. يمكنك جر مقطورة حتى 750 كغ، أو أثقل إذا لم يزد مجموع الأوزان على 3500 كغ.",
      ),
      p(
        "La patente B abilita anche ai ciclomotori e, in Italia, ai motocicli fino a 125 centimetri cubi e 11 kW, nel rispetto dei limiti di potenza specifica.",
        "رخصة B تسمح أيضًا بالدراجات البخارية الصغيرة، وفي إيطاليا بالدراجات النارية حتى 125 سم³ و11 كيلوواط ضمن حد القدرة.",
      ),
      note(
        "Chi circola deve evitare pericolo o intralcio e non gettare oggetti sulla strada.",
        "كل من يسير على الطريق يجب ألا يسبب خطرًا أو إعاقة، وألا يلقي شيئًا على الطريق.",
      ),
    ],
  },
  {
    n: 2,
    slug: "pericolo",
    titleIt: "Segnali di pericolo",
    titleAr: "إشارات الخطر",
    summaryAr: "مثلث أبيض بحافة حمراء: الخطر أمامك، لا يبدأ بالضرورة عند الإشارة.",
    blocks: [
      p(
        "I segnali di pericolo sono triangoli con bordo rosso e fondo bianco. Preavvisano un pericolo, di regola a una distanza che permette di rallentare.",
        "إشارات الخطر مثلثات بحافة حمراء وخلفية بيضاء. تنبّه إلى خطر قادم، وعلى مسافة تسمح بتخفيف السرعة.",
      ),
      p(
        "Il vertice del triangolo è in alto, salvo il dare precedenza che è un triangolo rovesciato e non appartiene ai segnali di pericolo.",
        "رأس المثلث إلى الأعلى. أما «أعطِ الأولوية» فمثلث مقلوب وليس من إشارات الخطر.",
      ),
      signs(["curva-dx", "doppia-sx", "dosso", "strettoia", "sdrucciolevole", "bambini", "passaggio-barriere", "croce", "altri"]),
      p(
        "La croce di Sant'Andrea non è un triangolo: sta proprio vicino ai binari. Una sola croce indica di norma un binario; il pannello con più barre indica più binari.",
        "صليب سكة الحديد ليس مثلثًا: يكون لصيقًا بالقضبان. صليب واحد يعني عادة سكة واحدة، واللوحة بعدة أشرطة تعني أكثر من سكة.",
      ),
      note(
        "Un pannello sotto il triangolo può dire la distanza, per esempio 150 m, o il motivo, per esempio ghiaccio.",
        "لوحة تحت المثلث قد تبيّن المسافة مثل 150 متر، أو السبب مثل الجليد.",
      ),
    ],
  },
  {
    n: 3,
    slug: "divieto",
    titleIt: "Segnali di divieto",
    titleAr: "إشارات المنع",
    summaryAr: "قرص بحافة حمراء. فرّق بين اتجاه ممنوع، وممنوع المرور، وممنوع الوقوف، وممنوع التوقف.",
    blocks: [
      p(
        "I segnali di divieto sono in genere cerchi con bordo rosso. Vietano un comportamento dal punto in cui sono posti fino alla fine indicata, a un incrocio, o a un segnale di fine.",
        "إشارات المنع غالبًا دوائر بحافة حمراء. تسري من مكانها حتى إشارة النهاية أو تقاطع أو حيث ينصّ على انتهائها.",
      ),
      signs(["transito", "senso-vietato", "sosta", "fermata", "sorpasso", "fine-sorpasso", "limite-50", "fine-divieti"]),
      p(
        "Il divieto di transito è un cerchio rosso vuoto: niente veicoli nei due sensi. Il senso vietato è un disco rosso con barra bianca orizzontale: non si entra da quel lato perché la strada prosegue a senso unico.",
        "ممنوع المرور دائرة حمراء فارغة: لا مركبات في الاتجاهين. اتجاه ممنوع قرص أحمر بشريط أبيض أفقي: لا تدخل من هذه الجهة لأن الطريق باتجاه واحد.",
      ),
      p(
        "Il divieto di sosta (croce blu e rossa) permette ancora la fermata per far salire o scendere persone. Il divieto di fermata (croce tutta rossa) vieta fermata e sosta. L'arresto imposto dal traffico resta sempre possibile.",
        "ممنوع الوقوف (صليب أزرق وأحمر) ما زال يسمح بالتوقف القصير لصعود الأشخاص أو نزولهم. ممنوع التوقف (صليب أحمر بالكامل) يمنع الاثنين. أما الوقوف الذي تفرضه حركة السير فيبقى ممكنًا.",
      ),
      note(
        "La fine di un divieto ha bordo nero e una barra diagonale. Non confonderla con un nuovo divieto dal bordo rosso.",
        "نهاية المنع حافتها سوداء وبها خط مائل. لا تخلطها بمنع جديد حافته حمراء.",
      ),
    ],
  },
  {
    n: 4,
    slug: "obbligo",
    titleIt: "Segnali di obbligo",
    titleAr: "إشارات الإلزام",
    summaryAr: "قرص أزرق: اتجاه يجب اتباعه، أو ممر مخصّص، أو سرعة دنيا.",
    blocks: [
      p(
        "I segnali di obbligo sono cerchi blu con simbolo bianco. Impongono una direzione, un percorso o un comportamento.",
        "إشارات الإلزام دوائر زرقاء برمز أبيض. تفرض اتجاهًا أو مسارًا أو سلوكًا.",
      ),
      signs(["dritto", "destra", "rotatoria", "passaggio-dx", "bici-obb", "catene", "vmin-30"]),
      p(
        "La velocità minima è un numero bianco su disco blu. Non è un limite massimo: indica la velocità sotto la quale non si deve scendere, salvo code o motivi di sicurezza.",
        "السرعة الدنيا رقم أبيض على قرص أزرق. ليست حدًا أقصى: هي سرعة لا تنزل تحتها إلا بسبب ازدحام أو أمان.",
      ),
      p(
        "Il segnale di rotatoria obbliga il giro in senso antiorario. Da solo non dice chi ha la precedenza: di solito all'ingresso c'è anche il dare precedenza.",
        "إشارة الدوار تلزم بالدوران عكس عقارب الساعة. وحدها لا تحدد من له الأولوية: عند المدخل غالبًا توجد أيضًا إشارة أعطِ الأولوية.",
      ),
      note(
        "Le frecce dipinte in corsia obbligano come il segnale verticale corrispondente.",
        "الأسهم المرسومة على المسلك تُلزم مثل الإشارة العمودية المقابلة.",
      ),
    ],
  },
  {
    n: 5,
    slug: "precedenza-segnali",
    titleIt: "Segnali di precedenza",
    titleAr: "إشارات الأولوية",
    summaryAr: "قف، أعطِ الأولوية، طريق ذو أفضلية، ونهاية الأفضلية.",
    blocks: [
      signs(["dare", "stop", "diritto", "fine-diritto", "precedenza-incrocio"]),
      p(
        "Dare precedenza: triangolo rovesciato. Bisogna rallentare e cedere il passo. L'arresto completo non è obbligatorio se si può passare senza pericolo, ma si deve poter frenare in tempo.",
        "أعطِ الأولوية: مثلث مقلوب. يجب التهدئة وإفساح الطريق. الوقوف التام ليس واجبًا إذا كان العبور آمنًا، لكن يجب أن تقدر على الفرملة في الوقت.",
      ),
      p(
        "Lo STOP impone l'arresto completo in corrispondenza della striscia, anche se non si vede nessuno, e poi il dare precedenza.",
        "STOP يفرض وقوفًا تامًا عند الخط حتى لو لم ترَ أحدًا، ثم إعطاء الأولوية.",
      ),
      p(
        "La losanga gialla indica una strada con diritto di precedenza. Vale fino al segnale di fine o fino a quando la segnaletica cambia.",
        "المعيّن الأصفر يعني طريقًا ذا أولوية. يسري حتى إشارة النهاية أو حتى تتغير العلامات.",
      ),
      p(
        "Il triangolo con il ramo verticale grosso preannuncia un incrocio in cui hai la precedenza sulla strada che stai percorrendo.",
        "المثلث ذو الفرع العمودي السميك ينبّه إلى تقاطع لك فيه الأولوية على الطريق الذي تسير فيه.",
      ),
      note(
        "Senza segnali, all'incrocio vale la precedenza a destra. Fanno eccezione agenti, semafori, stop e strade principali.",
        "بلا إشارات، في التقاطع الأولوية لمن عن يمينك. الاستثناء: الشرطي، الإشارة الضوئية، STOP، والطرق الرئيسية.",
      ),
    ],
  },
  {
    n: 6,
    slug: "orizzontale",
    titleIt: "Segnaletica orizzontale",
    titleAr: "العلامات الأرضية",
    summaryAr: "الخط المتصل لا يُقطع. المتقطع يُقطع بحذر. خطوط المشاة أولوية للمشاة.",
    blocks: [
      signs(["continua", "discontinua", "doppia-continua", "zebrato", "stop-terra", "freccia-suolo", "corsia-bus"]),
      p(
        "La striscia continua non si attraversa. La striscia discontinua si può superare per cambiare corsia o sorpassare, se la manovra è sicura e non c'è un divieto.",
        "الخط المتصل لا يُعبر. الخط المتقطع يمكن تجاوزه لتغيير المسلك أو للتجاوز إذا كانت المناورة آمنة وليس هناك منع.",
      ),
      p(
        "Se fra due sensi c'è una continua affiancata a una discontinua, può attraversarla solo chi ha la discontinua dal proprio lato.",
        "إذا وُجد خط متصل بجانب متقطع بين الاتجاهين، يعبره فقط من يكون المتقطع في جهته.",
      ),
      p(
        "Sulle strisce pedonali il pedone che attraversa ha la precedenza. Non si sosta sulle strisce né le si ingombra.",
        "على خطوط المشاة، الماشي الذي يعبر له الأولوية. لا تقف عليها ولا تسدّها.",
      ),
      p(
        "Le frecce di corsia obbligano la direzione. La scritta BUS indica una corsia riservata ai mezzi pubblici: non si percorre e non ci si sosta.",
        "أسهم المسلك تُلزم الاتجاه. كلمة BUS تعني مسلكًا مخصصًا للنقل العام: لا تسير فيه ولا تقف.",
      ),
      note(
        "La segnaletica gialla di cantiere prevale su quella bianca permanente se si contraddicono.",
        "العلامات الصفراء للورشة تغلب البيضاء الدائمة إذا تعارضتا.",
      ),
    ],
  },
  {
    n: 7,
    slug: "semafori",
    titleIt: "Semafori e agenti",
    titleAr: "الإشارات الضوئية ورجال المرور",
    summaryAr: "الأصفر الثابت ليس أحمر. أمر الشرطي يغلب الإشارة واللوحة.",
    blocks: [
      signs(["rosso", "giallo", "verde", "lampeggiante", "freccia-verde", "agente-alt", "agente-fronte", "agente-profilo"]),
      p(
        "La luce rossa impone l'arresto prima della linea di arresto. La freccia verde consente il passaggio solo nella direzione indicata.",
        "الضوء الأحمر يفرض الوقوف قبل خط التوقف. السهم الأخضر يسمح بالمرور في اتجاهه فقط.",
      ),
      p(
        "La luce gialla fissa equivale al braccio alzato dell'agente: bisogna fermarsi, se si può farlo senza pericolo. Se si è già dentro l'incrocio, bisogna liberarlo in fretta. Non equivale al rosso e non autorizza solo la svolta a destra.",
        "الأصفر الثابت يعادل ذراع الشرطي المرفوعة: قف إذا أمكن بلا خطر. إن كنت داخل التقاطع فأخله بسرعة. لا يعادل الأحمر ولا يسمح بالانعطاف يمينًا فقط.",
      ),
      p(
        "Il giallo lampeggiante invita alla prudenza: non è un via libera e non sostituisce le regole di precedenza. Una luce rossa lampeggiante, specie ai passaggi a livello, impone l'arresto.",
        "الأصفر الوامض يدعو للحذر: ليس إذن مرور ولا يلغي قواعد الأولوية. الأحمر الوامض، خاصة عند المزلقان، يفرض الوقوف.",
      ),
      p(
        "Con le braccia dell'agente distese, si ferma chi vede il petto o la schiena. Ha via libera chi arriva di fianco, lungo la direzione delle braccia. Gli ordini dell'agente prevalgono su semafori e segnali.",
        "إذا مدّ الشرطي ذراعيه، يقف من يرى صدره أو ظهره. يمر من يأتي من الجنب مع اتجاه الذراعين. أوامر الشرطي تغلب الإشارات الضوئية واللوحات.",
      ),
      note(
        "Il verde non permette di investire chi è già sull'attraversamento né di ignorare un ingorgo: non si entra nell'incrocio se non si può uscire.",
        "الأخضر لا يبيح دهس من على ممر المشاة ولا دخول تقاطع لن تستطيع الخروج منه.",
      ),
    ],
  },
  {
    n: 8,
    slug: "indicazione",
    titleIt: "Segnali di indicazione",
    titleAr: "إشارات الإرشاد",
    summaryAr: "أخضر للأوتوسترادا، أزرق للطريق الرئيسي خارج العمران، أبيض لبداية البلدة.",
    blocks: [
      signs(["autostrada", "fine-autostrada", "abitato", "fine-abitato", "senso-unico", "parcheggio", "ospedale", "preavviso", "senza-uscita"]),
      p(
        "Il pannello bianco col nome del comune indica l'inizio del centro abitato: di regola scatta il limite di 50 km/h. La sbarra rossa indica la fine e il ritorno ai limiti extraurbani.",
        "اللوحة البيضاء باسم البلدة تعني بداية العمران: الأصل أن يبدأ حد 50. الخط الأحمر يعني النهاية والعودة لحدود خارج العمران.",
      ),
      p(
        "I preavvisi di direzione sono verdi in autostrada, blu sulle strade extraurbane principali e bianchi sulle altre strade. I segnali turistici sono spesso marroni.",
        "لوحات الاتجاه خضراء على الأوتوسترادا، زرقاء على الطرق الرئيسية خارج العمران، وبيضاء على غيرها. اللوحات السياحية غالبًا بنّية.",
      ),
      p(
        "Il quadrato blu col pedone indica dov'è l'attraversamento. Il triangolo col pedone è solo un preavviso di pericolo.",
        "المربع الأزرق مع المشاة يبيّن مكان الممر. المثلث مع المشاة مجرد إنذار خطر.",
      ),
      note(
        "Un segnale di indicazione non vieta da solo, salvo quando il suo significato è una riserva di percorso, come l'autostrada o una corsia riservata.",
        "إشارة الإرشاد لا تمنع وحدها، إلا إذا كان معناها تخصيص طريق مثل الأوتوسترادا أو مسلك محجوز.",
      ),
    ],
  },
  {
    n: 9,
    slug: "cantiere",
    titleIt: "Cantieri e segnali temporanei",
    titleAr: "الورش والإشارات المؤقتة",
    summaryAr: "الأصفر المؤقت يغلب الأبيض الدائم إذا تعارضا. لا تقطع الأقماع.",
    blocks: [
      signs(["cantiere", "deviazione", "coni", "lavori"]),
      p(
        "La segnaletica temporanea di cantiere ha fondo giallo. Se contrasta con i segnali permanenti, si segue quella temporanea.",
        "علامات الورشة المؤقتة خلفيتها صفراء. إذا تعارضت مع الدائمة فاتبع المؤقتة.",
      ),
      p(
        "Si riduce la velocità, si rispettano coni, barriere e frecce di deviazione e non ci si ferma nella zona dei lavori se intralcia.",
        "خفّف السرعة، واحترم الأقماع والحواجز وأسهم التحويلة، ولا تقف في منطقة العمل إذا أعاقت.",
      ),
      p(
        "Gli operai e i mezzi di cantiere possono occupare la carreggiata. Il triangolo bianco «lavori» preavvisa; il giallo organizza il passaggio sul posto.",
        "العمال وآلات الورشة قد تشغل سطح السير. مثلث «أعمال» الأبيض ينبّه مسبقًا، والأصفر ينظّم المرور في المكان.",
      ),
      note(
        "Di notte e con scarsa visibilità il cantiere è segnalato anche con luci. Il conducente accende almeno gli anabbaglianti.",
        "ليلًا ومع ضعف الرؤية تُضاء الورشة. السائق يشغّل على الأقل الأضواء المنخفضة.",
      ),
    ],
  },
  {
    n: 10,
    slug: "pannelli",
    titleIt: "Pannelli integrativi",
    titleAr: "اللوحات المكمّلة",
    summaryAr: "لوحة صغيرة تحت الإشارة تحدد المسافة أو المدة أو من يُستثنى.",
    blocks: [
      signs(["pannello-distanza", "pannello-estesa", "pannello-ghiaccio", "pannello-orario"]),
      p(
        "Il pannello integrativo non vive da solo: precisa il segnale sopra di lui. Può indicare la distanza (150 m), l'estesa (3 km), un orario, un giorno, o una categoria di veicoli.",
        "اللوحة المكمّلة لا تعمل وحدها: توضّح الإشارة فوقها. قد تبيّن المسافة (150 م) أو الامتداد (3 كم) أو ساعة أو يومًا أو فئة مركبات.",
      ),
      p(
        "Se sotto un limite di velocità c'è il disegno di un autocarro, il limite riguarda quei veicoli, non necessariamente le autovetture.",
        "إذا تحت حد السرعة رسم شاحنة، فالحد يخص تلك المركبات لا بالضرورة السيارات.",
      ),
      p(
        "Un pannello con la scritta eccezione, o con una freccia, può escludere una categoria o indicare il tratto laterale in cui vale il divieto.",
        "لوحة مكتوب عليها استثناء، أو سهم، قد تستثني فئة أو تحدد الجانب الذي يسري فيه المنع.",
      ),
      note(
        "Modello d'esame: il segnale raffigurato vale solo nelle ore scritte sul pannello. Se non c'è pannello, vale in continuità secondo le regole di quel segnale.",
        "نموذج امتحان: الإشارة تسري فقط في الساعات المكتوبة على اللوحة. بلا لوحة تسري باستمرار حسب قواعد تلك الإشارة.",
      ),
    ],
  },
  {
    n: 11,
    slug: "velocita",
    titleIt: "Limiti di velocità",
    titleAr: "حدود السرعة",
    summaryAr: "50 و90 و110 و130. المطر ينقص الأوتوسترادا والطريق الرئيسي. حديث الرخصة: 100 و90.",
    blocks: [
      h("Limiti ordinari delle autovetture", "الحدود العادية للسيارات"),
      p(
        "Centro abitato 50 km/h. Strada extraurbana secondaria 90. Strada extraurbana principale 110. Autostrada 130.",
        "داخل العمران 50. طريق خارج العمران ثانوي 90. طريق خارج العمران رئيسي 110. أوتوسترادا 130.",
      ),
      p(
        "Con precipitazioni atmosferiche il limite di 130 in autostrada scende a 110 e quello di 110 sulle extraurbane principali scende a 90.",
        "مع هطول الأمطار حد 130 على الأوتوسترادا ينزل إلى 110، وحد 110 على الطرق الرئيسية خارج العمران ينزل إلى 90.",
      ),
      h("Neopatentati e rimorchi", "حديثو الرخصة والمقطورات"),
      p(
        "Per i primi 3 anni dalla patente B non si superano 100 km/h in autostrada e 90 km/h sulle strade extraurbane principali. Il limite in città resta 50.",
        "في أول 3 سنوات من رخصة B لا تتجاوز 100 على الأوتوسترادا و90 على الطرق الرئيسية خارج العمران. داخل المدينة يبقى 50.",
      ),
      p(
        "Nello stesso periodo, per chi ha conseguito la patente secondo le regole vigenti dal 2024, la potenza specifica non supera 75 kW per tonnellata e, per le autovetture, la potenza assoluta non supera 105 kW. C'è deroga se a fianco siede un accompagnatore non oltre 65 anni con patente da almeno 10 anni, o se l'auto è al servizio di una persona con disabilità a bordo.",
        "في المدة نفسها، وحسب القواعد السارية منذ 2024، القدرة لا تتجاوز 75 كيلوواط للطن، وللسيارات لا تتجاوز القدرة المطلقة 105 كيلوواط. يُستثنى من يجلس بجانبه مرافق لا يزيد عمره على 65 سنة ورخصته من 10 سنوات على الأقل، أو سيارة في خدمة شخص من ذوي الإعاقة موجود على المتن.",
      ),
      p(
        "Un'autovettura con rimorchio non usa i limiti delle auto sole: in autostrada il limite tipico d'esame è 80 km/h, e scende ancora sulle extraurbane.",
        "سيارة بمقطورة لا تأخذ حدود السيارة وحدها: على الأوتوسترادا الحد النموذجي في الامتحان 80 كم/س، وينخفض أكثر خارج العمران.",
      ),
      note(
        "Il limite generale non autorizza a correre se la strada è bagnata, affollata o poco visibile. La velocità va sempre rapportata alle condizioni.",
        "الحد العام لا يبيح السرعة إذا كان الطريق مبللًا أو مزدحمًا أو الرؤية ضعيفة. السرعة دائمًا حسب الظروف.",
      ),
    ],
  },
  {
    n: 12,
    slug: "distanza",
    titleIt: "Distanza di sicurezza",
    titleAr: "مسافة الأمان",
    summaryAr: "حوالي ثانية لرد الفعل. مسافة تقريبية على الناشف: (السرعة ÷ 10) مربعة.",
    blocks: [
      p(
        "La distanza di sicurezza è lo spazio libero davanti al veicolo, sufficiente per fermarsi senza urtare chi precede, anche se quello frena all'improvviso.",
        "مسافة الأمان هي الفراغ أمام مركبتك، يكفي لتتوقف دون أن تصطدم بمن أمامك حتى لو فرمل فجأة.",
      ),
      p(
        "Lo spazio di arresto è la somma dello spazio percorso durante il tempo di reazione e dello spazio di frenata. Il tempo di reazione, da sveglio e sobrio, è circa un secondo e aumenta con fatica, alcol, farmaci e distrazione.",
        "مسافة التوقف = المسافة أثناء زمن رد الفعل + مسافة الفرملة. زمن رد الفعل وأنت منتبه وغير مخمور حوالي ثانية، ويزيد مع التعب والكحول والدواء والتشتت.",
      ),
      p(
        "In un secondo a 50 km/h si percorrono circa 14 metri, a 90 km/h circa 25 metri, a 130 km/h circa 36 metri. Non 15 metri a 130: è un trabocchetto classico.",
        "في ثانية واحدة عند 50 تسير نحو 14 مترًا، وعند 90 نحو 25 مترًا، وعند 130 نحو 36 مترًا. ليس 15 مترًا عند 130: هذا فخ كلاسيكي.",
      ),
      p(
        "Una stima d'esame, su asfalto asciutto e con buoni freni, è il quadrato delle decine della velocità: a 50 km/h circa 25 metri, a 100 km/h circa 100 metri. Sul bagnato la distanza cresce molto; sul ghiaccio può diventare enormemente più lunga.",
        "تقدير الامتحان على أسفلت ناشف وفرامل جيدة هو مربع عشرات السرعة: عند 50 نحو 25 مترًا، وعند 100 نحو 100 متر. على المبلل تزيد المسافة كثيرًا، وعلى الجليد قد تطول جدًا.",
      ),
      note(
        "Lo spazio di frenata cresce con il quadrato della velocità. Raddoppiare la velocità non raddoppia lo spazio: lo moltiplica circa per quattro.",
        "مسافة الفرملة تزيد مع مربع السرعة. مضاعفة السرعة لا تضاعف المسافة: تضربها تقريبًا في أربعة.",
      ),
    ],
  },
  {
    n: 13,
    slug: "circolazione",
    titleIt: "Posizione e manovre",
    titleAr: "موضع المركبة والمناورات",
    summaryAr: "اليمين هو الأصل. كل مناورة تُعلن بالغمّاز بعد النظر في المرايا.",
    blocks: [
      p(
        "Fuori dai centri abitati si marcia vicino al margine destro. In città si usa la corsia libera più a destra, salvo per predisporsi a svoltare o sorpassare.",
        "خارج العمران سر قرب الحافة اليمنى. في المدينة استخدم المسلك الحر الأيمن، إلا للاستعداد للانعطاف أو التجاوز.",
      ),
      p(
        "Prima di spostarti, guarda specchio e angolo cieco, segnala con l'indicatore di direzione e manovra senza tagliare la strada agli altri.",
        "قبل أن تنتقل انظر في المرآة والزاوية العمياء، وأشّر بالغمّاز، ثم ناور دون قطع الطريق على غيرك.",
      ),
      p(
        "Per svoltare a sinistra ci si porta sulla corsia o sul lato sinistro del proprio senso, senza invadere l'opposto prima del tempo. Si cede il passo a chi arriva di fronte e prosegue dritto.",
        "للانعطاف يسارًا انتقل إلى المسلك الأيسر من اتجاهك، دون دخول الاتجاه المقابل مبكرًا. أعطِ الطريق لمن يأتي من الأمام ويكمل مستقيمًا.",
      ),
      p(
        "L'inversione di marcia è vietata dove la visibilità è scarsa, in curva, sui dossi, in autostrada e dove c'è il segnale di divieto. La retromarcia è una manovra eccezionale, lenta, e vietata in autostrada.",
        "الالتفاف للخلف ممنوع حيث الرؤية ضعيفة، وفي المنحنى، وعلى المرتفع، وعلى الأوتوسترادا، وحيث توجد إشارة منع. الرجوع للخلف مناورة استثنائية بطيئة وممنوعة على الأوتوسترادا.",
      ),
      note(
        "Non si apre la portiera se si mette in pericolo un ciclista o un pedone. Si usa la mano più lontana, il cosiddetto controllo olandese.",
        "لا تفتح الباب إذا كان سيُعرّض درّاجًا أو ماشيًا للخطر. استخدم اليد البعيدة، وهو ما يُسمى الفحص الهولندي.",
      ),
    ],
  },
  {
    n: 14,
    slug: "esempi-precedenza",
    titleIt: "Esempi di precedenza",
    titleAr: "أمثلة الأولوية",
    summaryAr: "يمينك يمر أولًا إذا لم توجد إشارة. في الدوار الحديث يمر من بداخله.",
    blocks: [
      signs(["fig-destra", "fig-rotatoria", "fig-strettoia", "fig-svolta"]),
      p(
        "All'incrocio senza segnali passa prima chi viene dalla tua destra. Il veicolo rosso fermo in basso, nel disegno, lascia passare il veicolo blu che arriva da destra.",
        "في تقاطع بلا إشارات يمر أولًا من يأتي من يمينك. السيارة الحمراء في أسفل الرسم تترك الزرقاء القادمة من اليمين.",
      ),
      p(
        "Chi svolta a sinistra cede la precedenza ai veicoli che arrivano di fronte. In rotatoria, se all'ingresso c'è il dare precedenza, passano prima i veicoli già dentro.",
        "من ينعطف يسارًا يعطي الأولوية للقادم من الأمام. في الدوار، إذا عند المدخل إشارة أعطِ الأولوية، يمر أولًا من هو داخل الدوار.",
      ),
      p(
        "Nelle strettoie in salita, di regola ha precedenza chi sale. Chi scende retrocede se serve. Se c'è una piazzola, retrocede chi la ha più vicina.",
        "في التضيّق على مطلَع، الأصل أن الأولوية لمن يصعد. من ينزل يرجع إذا لزم. إذا وُجدت فسحة، يرجع من هي أقرب إليه.",
      ),
      p(
        "Si dà sempre precedenza ai veicoli di soccorso con sirena e luce blu lampeggiante, ai tram secondo le regole del caso, e ai pedoni sugli attraversamenti.",
        "تُعطى الأولوية دائمًا لمركبات الإغاثة بالصفّارة والضوء الأزرق الوامض، وللترام حسب الحالة، وللمشاة على الممرات.",
      ),
      p(
        "Uscendo da un passo carrabile, da un'area privata o da un parcheggio si cede la precedenza a tutti gli utenti della strada pubblica.",
        "عند الخروج من مدخل عقار أو مساحة خاصة أو موقف، تُعطى الأولوية لكل مستخدمي الطريق العام.",
      ),
      note(
        "Lo STOP batte la semplice regola di destra. Il semaforo e l'agente battono i cartelli.",
        "STOP يغلب قاعدة اليمين البسيطة. الإشارة الضوئية والشرطي يغلبان اللوحات.",
      ),
    ],
  },
  {
    n: 15,
    slug: "sorpasso",
    titleIt: "Sorpasso",
    titleAr: "التجاوز",
    summaryAr: "من اليسار كأصل. ممنوع على الخط المتصل وفي المنحنى بلا رؤية وعند ممر المشاة.",
    blocks: [
      p(
        "Il sorpasso si fa di norma a sinistra, dopo essersi accertati che la corsia sia libera e che nessuno dietro abbia già iniziato la manovra.",
        "التجاوز يكون عادة من اليسار، بعد التأكد أن المسلك خالٍ وأن أحدًا من الخلف لم يبدأ المناورة.",
      ),
      p(
        "È vietato in curva, sui dossi, quando la visibilità è insufficiente, sugli attraversamenti pedonali, ai passaggi a livello e dove c'è la striscia continua da non attraversare.",
        "ممنوع في المنحنى وعلى المرتفع وعند ضعف الرؤية وعلى ممرات المشاة والمزلقانات وحيث يوجد خط متصل لا يجوز عبوره.",
      ),
      p(
        "Il sorpasso a destra è eccezionale: per esempio se il veicolo davanti ha segnalato la svolta a sinistra e si è spostato, oppure in coda quando le corsie sono ben definite e il traffico è lento.",
        "التجاوز من اليمين استثنائي: مثلًا إذا أشّر من أمامك لليسار وانتقل، أو في الزحام إذا كانت المسالك واضحة والحركة بطيئة.",
      ),
      p(
        "Chi viene sorpassato non accelera e si tiene a destra. Chi sorpassa rientra a destra solo quando vede nello specchio il veicolo superato, senza stringerlo.",
        "من يُتجاوَز لا يزيد السرعة ويلتزم اليمين. المتجاوِز يعود يمينًا فقط عندما يرى المركبة في المرآة دون أن يضيّق عليها.",
      ),
      note(
        "Lampeggiare con gli abbaglianti per annunciare un sorpasso si può fuori dai centri abitati, non come gioco dentro la città.",
        "وميض الأضواء العالية للتنبيه بتجاوز يجوز خارج العمران، وليس عبثًا داخل المدينة.",
      ),
    ],
  },
  {
    n: 16,
    slug: "fermata",
    titleIt: "Fermata, sosta, arresto",
    titleAr: "التوقف والوقوف والوقوف الاضطراري",
    summaryAr: "الوقوف تترك السيارة. التوقف القصير تبقى جاهزًا. الوقوف الاضطراري تفرضه الحركة.",
    blocks: [
      p(
        "L'arresto è l'interruzione della marcia imposta dal traffico, da un semaforo, da uno stop o da un agente. Il conducente resta al posto di guida.",
        "Arresto هو انقطاع السير تفرضه الحركة أو إشارة أو STOP أو شرطي. السائق يبقى في مقعد القيادة.",
      ),
      p(
        "La fermata è breve e serve a far salire o scendere persone o a caricare. Il conducente è presente e pronto a ripartire. La sosta è più lunga e il veicolo può essere lasciato.",
        "Fermata قصيرة لصعود الأشخاص أو نزولهم أو التحميل. السائق حاضر وجاهز للانطلاق. Sosta أطول ويمكن ترك المركبة.",
      ),
      p(
        "Fermata e sosta sono vietate in curva, sui dossi, sugli attraversamenti, sulle piste ciclabili, sui marciapiedi salvo diversa segnalazione, e in corrispondenza degli incroci. In città la distanza dall'incrocio è di almeno 5 metri dal prolungamento del bordo della strada trasversale.",
        "التوقف والوقوف ممنوعان في المنحنى وعلى المرتفع وعلى ممرات المشاة ومسارات الدراجات وعلى الرصيف ما لم تسمح إشارة، وعند التقاطعات. في المدينة المسافة من التقاطع 5 أمتار على الأقل من امتداد حافة الطريق العرضي.",
      ),
      p(
        "La sola sosta è anche vietata in seconda fila (salvo i veicoli a due ruote), davanti ai passi carrabili, e a meno di 15 metri dal segnale di fermata dell'autobus se lo spazio non è già disegnato a terra.",
        "الوقوف وحده ممنوع أيضًا في الصف الثاني (إلا المركبات ذات العجلتين)، وأمام مداخل العقارات، وعلى أقل من 15 مترًا من لوحة موقف الحافلة إذا لم تكن المساحة مرسومة على الأرض.",
      ),
      note(
        "Lasciare il motore acceso durante una sosta prolungata spreca carburante e inquina, ed è regolato dalle norme locali anti-inquinamento.",
        "ترك المحرك يعمل أثناء وقوف طويل يُهدر الوقود ويلوّث، وتنظّمه قواعد محلية لمكافحة التلوث.",
      ),
    ],
  },
  {
    n: 17,
    slug: "norme-varie",
    titleIt: "Autostrada, ingombro, trasporto",
    titleAr: "أوتوسترادا وحمولة وأحكام متفرقة",
    summaryAr: "لا رجوع ولا وقوف على الأوتوسترادا. الحمولة لا تبرز بشكل خطر ولا تحجب الرؤية.",
    blocks: [
      p(
        "In autostrada si entra dalla corsia di accelerazione senza fermarsi se il flusso lo consente, si cede il passo a chi è già in corsia e non si usa la corsia di emergenza per viaggiare.",
        "على الأوتوسترادا تدخل من مسلك التسارع بلا توقف إذا سمحت الحركة، وتعطي الطريق لمن هو في المسلك، ولا تستخدم مسلك الطوارئ للسير.",
      ),
      p(
        "Sono vietati l'inversione, la retromarcia, il traino privato improvvisato e la sosta in corsia. In panne ci si porta sulla corsia di emergenza, si accendono le quattro frecce, si indossa il giubbotto retroriflettente prima di scendere e si piazza il triangolo.",
        "ممنوع الالتفاف والرجوع للخلف والقطر العشوائي والوقوف في المسلك. عند العطل انتقل لمسلك الطوارئ، وشغّل الأضواء الأربعة، والبس السترة العاكسة قبل النزول، وضع المثلث.",
      ),
      p(
        "Il carico non deve cadere, strisciare, superare i limiti di sagoma senza autorizzazione, né coprire luci, targa o specchi. Si assicura con mezzi idonei.",
        "الحمولة يجب ألا تسقط أو تجرّ على الأرض أو تتجاوز الأبعاد بلا تصريح، وألا تغطي الأضواء أو اللوحة أو المرايا. تُثبَّت بوسائل مناسبة.",
      ),
      p(
        "I passeggeri viaggiano seduti nei posti omologati, con la cintura. Non si trasportano persone nel vano di carico non attrezzato, né in numero superiore ai posti indicati sulla carta di circolazione.",
        "الركاب يجلسون في المقاعد المعتمدة ومع الحزام. لا يُنقل أشخاص في صندوق غير مهيأ، ولا بعدد يفوق المقاعد المذكورة في شهادة التسجيل.",
      ),
      note(
        "Sulle extraurbane principali valgono divieti simili all'autostrada per pedoni, animali e veicoli lenti, con le differenze segnate dai cartelli blu anziché verdi.",
        "على الطرق الرئيسية خارج العمران ممنوعات قريبة من الأوتوسترادا للمشاة والحيوانات والمركبات البطيئة، واللوحات زرقاء لا خضراء.",
      ),
    ],
  },
  {
    n: 18,
    slug: "luci",
    titleIt: "Luci e avvisatore acustico",
    titleAr: "الأضواء والبوق",
    summaryAr: "المنخفضة إجبارية خارج العمران ليلًا ونهارًا. البوق داخل البلد للخطر فقط.",
    blocks: [
      p(
        "Gli anabbaglianti si usano da mezz'ora dopo il tramonto a mezz'ora prima dell'alba, in galleria, con scarsa visibilità e, fuori dai centri abitati, anche di giorno. Dentro la città di giorno non sono obbligatori se la visibilità è buona.",
        "الأضواء المنخفضة تُستخدم من نصف ساعة بعد الغروب إلى نصف ساعة قبل الشروق، وفي الأنفاق، ومع ضعف الرؤية، وخارج العمران حتى نهارًا. داخل المدينة نهارًا ليست إجبارية إذا كانت الرؤية جيدة.",
      ),
      p(
        "Gli abbaglianti si usano di notte fuori città quando non si abbaglia chi precede o chi arriva di fronte. Si passa agli anabbaglianti incrociando o seguendo un altro veicolo. Nei centri abitati gli abbaglianti non si usano per viaggiare.",
        "الأضواء العالية ليلًا خارج المدينة عندما لا تُبهر من أمامك أو من يأتي مقابلًا. ترجع للمنخفضة عند التلاقي أو متابعة مركبة. داخل العمران لا تسافر بالأضواء العالية.",
      ),
      p(
        "I fendinebbia anteriori servono con nebbia, pioggia intensa o neve. Il retronebbia solo con visibilità molto ridotta e va spento appena non serve, perché abbaglia chi segue.",
        "ضباب الأمام للضباب أو المطر الشديد أو الثلج. الضباب الخلفي فقط عندما تنخفض الرؤية جدًا ويُطفأ فورًا عندما لا يلزم لأنه يُبهر من خلفك.",
      ),
      p(
        "Le quattro frecce segnalano un pericolo, una fermata di emergenza o un rallentamento improvviso, anche in coda. Il clacson si usa per evitare un incidente. In città è vietato suonare salvo pericolo immediato; di notte fuori città si preferiscono i lampeggi dei fari.",
        "الأضواء الأربعة تنبّه لخطر أو توقف اضطراري أو تباطؤ مفاجئ حتى في الزحام. البوق لتفادي حادث. في المدينة ممنوع إلا لخطر داهم؛ وليلًا خارج المدينة يُفضَّل وميض الأضواء.",
      ),
      note(
        "La spia rossa dell'olio, della temperatura o dei freni impone di fermarsi in sicurezza. Una spia gialla avvisa di un'anomalia da controllare presto.",
        "لمبة حمراء للزيت أو الحرارة أو الفرامل تفرض التوقف بأمان. اللمبة الصفراء تنبّه لعطل يُفحص قريبًا.",
      ),
    ],
  },
  {
    n: 19,
    slug: "cinture",
    titleIt: "Cinture, bambini, casco",
    titleAr: "الأحزمة والأطفال والخوذة",
    summaryAr: "الحزام للجميع. تحت 1.50 م مقعد مناسب. الخوذة للدراجة النارية.",
    blocks: [
      p(
        "Conducente e passeggeri devono usare le cinture omologate, anche dietro e anche in città. L'airbag non sostituisce la cintura: lavora insieme a essa.",
        "السائق والركاب يستخدمون أحزمة معتمدة، حتى الخلف وحتى داخل المدينة. الوسادة الهوائية لا تغني عن الحزام: تعمل معه.",
      ),
      p(
        "I bambini di statura inferiore a 1,50 m viaggiano con un sistema di ritenuta omologato, adatto a peso e altezza. Il seggiolino rivolto all'indietro non si mette davanti a un airbag attivo: l'airbag va disattivato.",
        "الأطفال الأقصر من 1.50 م يسافرون بنظام تثبيت معتمد مناسب للوزن والطول. المقعد المواجه للخلف لا يوضع أمام وسادة هوائية شغّالة: يجب إيقافها.",
      ),
      p(
        "Sui motocicli e sui ciclomotori il casco omologato è obbligatorio per conducente e passeggero, allacciato. La patente B non esonera dal casco chi guida un 125.",
        "على الدراجات النارية والبخارية الصغيرة الخوذة المعتمدة إجبارية للسائق والراكب ومربوطة. رخصة B لا تُعفي من الخوذة من يقود 125.",
      ),
      p(
        "Esenzioni strette esistono per certificati medici e per alcuni conducenti in servizio (forze dell'ordine, istruttori durante la lezione). La gravidanza da sola non è un permesso generico: serve valutazione medica.",
        "استثناءات ضيقة لشهادات طبية ولبعض السائقين أثناء الخدمة (الشرطة، المدربون أثناء الدرس). الحمل وحده ليس إذنًا عامًا: يلزم تقييم طبي.",
      ),
      note(
        "Una cintura slacciata o passata sotto il braccio non protegge e può aggravare le lesioni.",
        "حزام مفكوك أو مار تحت الذراع لا يحمي وقد يزيد الإصابة.",
      ),
    ],
  },
  {
    n: 20,
    slug: "documenti",
    titleIt: "Patente, punti, documenti",
    titleAr: "الرخصة والنقاط والوثائق",
    summaryAr: "20 نقطة في البداية. أثناء التفتيش تُبرز الرخصة وشهادة التسجيل. أوامر الشرطي تُطاع.",
    blocks: [
      p(
        "Alla guida si devono poter esibire la patente e la carta di circolazione. L'assicurazione RCA è obbligatoria e oggi è controllata per via telematica: il vecchio contrassegno di carta non va più esposto sul vetro.",
        "أثناء القيادة يجب أن تستطيع إبراز الرخصة وشهادة التسجيل. تأمين المسؤولية المدنية إجباري ويُفحص اليوم إلكترونيًا: الملصق الورقي القديم لم يعد يُوضع على الزجاج.",
      ),
      p(
        "La patente B, per chi ha meno di 50 anni, vale in genere 10 anni; poi gli intervalli di rinnovo si accorciano con l'età. Se la patente impone lenti, si guida solo con gli occhiali o le lenti indicati.",
        "رخصة B لمن دون 50 تسري عادة 10 سنوات، ثم تقصر مدد التجديد مع العمر. إذا كانت الرخصة تشترط عدسات، فلا تقود إلا بالنظارة أو العدسات المذكورة.",
      ),
      p(
        "La patente a punti parte da 20. Senza infrazioni che tolgono punti se ne guadagnano 2 ogni 2 anni, fino a un massimo di 30. Nei primi 3 anni le decurtazioni sono doppie.",
        "رخصة النقاط تبدأ من 20. بلا مخالفات تُنقص النقاط تربح 2 كل سنتين حتى 30 كحد أقصى. في أول 3 سنوات الخصم مضاعف.",
      ),
      p(
        "A zero punti la patente va in revisione: bisogna superare di nuovo gli esami nei tempi previsti. Non si guida come se nulla fosse.",
        "عند صفر نقطة تدخل الرخصة المراجعة: يجب إعادة الامتحانات في المواعيد. لا تقود كأن شيئًا لم يكن.",
      ),
      p(
        "Fermati dagli agenti, ci si accosta in sicurezza, si spegne il motore se richiesto e si consegnano i documenti. Fugare o rifiutare il controllo è un illecito grave.",
        "إذا أوقفك الشرطي، اقترب بأمان، وأطفئ المحرك إذا طُلب، وسلّم الوثائق. الهروب أو رفض الرقابة مخالفة جسيمة.",
      ),
      note(
        "I neopatentati che non perdono punti possono ricevere un bonus più piccolo di quello degli esperti, secondo le regole dei primi tre anni.",
        "حديثو الرخصة الذين لا يخسرون نقاطًا قد يحصلون على مكافأة أصغر من ذوي الخبرة، حسب قواعد السنوات الثلاث الأولى.",
      ),
    ],
  },
  {
    n: 21,
    slug: "incidenti",
    titleIt: "Incidenti",
    titleAr: "الحوادث",
    summaryAr: "قف، أمّن المكان، أسعف، اتصل. لا تترك مصابًا. لا تحرك الجريح بلا داعٍ.",
    blocks: [
      p(
        "Dopo un incidente ci si ferma sempre. Abbandonare le persone ferite è omissione di soccorso. Si accendono le quattro frecce, si indossa il giubbotto e si sistema il triangolo a distanza utile, senza esporsi al traffico.",
        "بعد الحادث تقف دائمًا. ترك المصابين تركٌ للإغاثة. شغّل الأضواء الأربعة والبس السترة وضع المثلث على مسافة مفيدة دون أن تعرّض نفسك للمرور.",
      ),
      p(
        "Si chiama il soccorso (112) indicando luogo, numero di feriti e rischi come incendio o merci pericolose. Non si sposta un ferito se non c'è pericolo immediato di fuoco o di investimento.",
        "اتصل بالإغاثة (112) وحدّد المكان وعدد المصابين والأخطار مثل حريق أو بضائع خطرة. لا تنقل مصابًا إلا إذا كان هناك خطر فوري من نار أو دهس.",
      ),
      p(
        "Fra i conducenti si scambiano i dati e, se è il caso, si compila la constatazione amichevole. Se ci sono feriti o un disaccordo grave si aspettano gli agenti.",
        "يتبادل السائقون البيانات، وعند اللزوم يُملأ المحضر الودّي. إذا كان هناك مصابون أو خلاف شديد يُنتظر الشرطي.",
      ),
      p(
        "Non si cancella con l'acqua una perdita di carburante vicino alle fiamme e non si fuma. Un principio di incendio si affronta con l'estintore solo se si può fare senza restare intrappolati.",
        "لا تغسل تسرب وقود قرب اللهب بالماء ولا تدخّن. حريق في بدايته يُواجه بالطفاية فقط إذا أمكن بلا احتجاز.",
      ),
      note(
        "Anche investire un animale e proseguire senza fermarsi può essere sanzionato. Ci si ferma e si attiva il soccorso quando è possibile.",
        "حتى صدم حيوان والمتابعة دون توقف قد يُعاقب. قف وفعّل الإغاثة عندما يمكن ذلك.",
      ),
    ],
  },
  {
    n: 22,
    slug: "condizioni",
    titleIt: "Alcol, droga, stato psicofisico",
    titleAr: "الكحول والمخدر والحالة البدنية",
    summaryAr: "الحد العام 0.5. لحديث الرخصة ومن دون 21: صفر. التعب يطيل زمن رد الفعل.",
    blocks: [
      p(
        "Il limite ordinario di alcolemia è 0,5 grammi per litro. Fra 0,5 e 0,8 la sanzione è amministrativa, con sospensione e perdita di punti. Da 0,8 in su scatta il reato, con pene più gravi oltre 1,5.",
        "الحد العادي للكحول 0.5 غرام في اللتر. بين 0.5 و0.8 العقوبة إدارية مع إيقاف وفقد نقاط. من 0.8 تبدأ الجريمة، وتشتد أكثر فوق 1.5.",
      ),
      p(
        "Per i neopatentati nei primi 3 anni, per chi ha meno di 21 anni e per i conducenti professionali il limite è zero. Qualsiasi valore positivo è già illecito.",
        "لحديثي الرخصة في أول 3 سنوات، ولمن دون 21، وللسائقين المهنيين الحد صفر. أي قيمة موجبة مخالفة أصلًا.",
      ),
      p(
        "Anche poca birra o un digestivo alterano riflessi e campo visivo. Caffè e doccia non abbassano l'alcolemia: serve tempo. Le droghe sono incompatibili con la guida anche in quantità piccole, e alcuni farmaci portano un pittogramma di pericolo.",
        "حتى قليل من البيرة أو كأس الهضم يغيّر ردود الفعل ومجال الرؤية. القهوة والدش لا ينقصان نسبة الكحول: يلزم وقت. المخدرات لا تجتمع مع القيادة حتى بكميات قليلة، وبعض الأدوية تحمل رمز خطر.",
      ),
      p(
        "La stanchezza allunga il tempo di reazione come l'alcol. Nei viaggi lunghi si fa pausa circa ogni due ore. Non si guida con febbre alta, vertigini o dopo un pasto così pesante da indurre sonno.",
        "التعب يطيل زمن رد الفعل مثل الكحول. في السفر الطويل خذ استراحة كل ساعتين تقريبًا. لا تقد مع حمى شديدة أو دوار أو بعد وجبة ثقيلة تجلب النعاس.",
      ),
      h("Primo soccorso essenziale", "إسعاف أولي أساسي"),
      p(
        "Si controlla se il ferito è cosciente e respira. Un'emorragia abbondante si comprime con un telo pulito. Non si danno da bere alcolici né medicine a caso. Si copre il ferito e si resta fino ai soccorsi.",
        "تحقق إن كان المصاب واعيًا ويتنفس. النزيف الغزير يُضغط بقطعة قماش نظيفة. لا تُعطِ مشروبًا كحوليًا ولا دواءً عشوائيًا. غطِّ المصاب وابقَ حتى يصل الإسعاف.",
      ),
      note(
        "Il cellulare si usa solo con viva voce o auricolare consentiti, e comunque non si scrive messaggi guidando. La distrazione è una causa frequente di incidente.",
        "الهاتف فقط بالسماعة المسموحة، ولا تكتب رسائل وأنت تقود. التشتت سبب شائع للحوادث.",
      ),
    ],
  },
  {
    n: 23,
    slug: "assicurazione",
    titleIt: "Responsabilità e RCA",
    titleAr: "المسؤولية والتأمين",
    summaryAr: "تأمين ضد الغير إجباري. السائق قد يُسأل مدنيًا وجنائيًا وإداريًا معًا.",
    blocks: [
      p(
        "L'assicurazione di responsabilità civile auto è obbligatoria per circolare. Copre i danni causati a terzi, non tutti i danni alla propria auto, salvo polizze ulteriori come furto, incendio o kasko.",
        "تأمين المسؤولية المدنية للسيارة إجباري للسير. يغطي الأضرار التي تسببها للغير، لا كل أضرار سيارتك، إلا بوثائق إضافية مثل السرقة أو الحريق أو الشامل.",
      ),
      p(
        "La responsabilità civile obbliga a risarcire il danno. Quella penale riguarda i reati, per esempio lesioni o omicidio stradale. Quella amministrativa riguarda multe e punti. Le tre possono cumularsi.",
        "المسؤولية المدنية تُلزم بالتعويض. الجنائية تخص الجرائم مثل الإيذاء أو القتل المروري. الإدارية تخص الغرامات والنقاط. والثلاث قد تجتمع.",
      ),
      p(
        "Il proprietario che affida l'auto a una persona senza patente, o in stato di ebbrezza evidente, può rispondere insieme al conducente. Il contratto RCA non è un permesso di guidare ubriachi.",
        "المالك الذي يسلّم السيارة لمن بلا رخصة، أو وهو سكران بشكل واضح، قد يُسأل مع السائق. وثيقة التأمين ليست إذنًا بالقيادة سكران.",
      ),
      p(
        "La constatazione amichevole accelera il risarcimento se è compilata in modo chiaro, con disegno e firme. Non si ammette una colpa che non c'è solo per far presto.",
        "المحضر الودّي يسرّع التعويض إذا كُتب بوضوح مع رسم وتوقيع. لا تعترف بذنب غير موجود لمجرد الإسراع.",
      ),
      note(
        "Guidare senza copertura RCA è illecito anche se il veicolo è in regola con la revisione.",
        "القيادة بلا تغطية تأمينية مخالفة حتى لو كانت المركبة ناجحة في الفحص الدوري.",
      ),
    ],
  },
  {
    n: 24,
    slug: "ambiente",
    titleIt: "Consumi e ambiente",
    titleAr: "الاستهلاك والبيئة",
    summaryAr: "سرعة ثابتة وغيار مناسب وصيانة تقلل الوقود والضجيج.",
    blocks: [
      p(
        "Accelerare e frenare di continuo aumenta consumi e inquinamento. Una velocità il più possibile costante, e il cambio usato senza tirare il motore al massimo, riduce i consumi.",
        "التسارع والفرملة باستمرار يزيدان الاستهلاك والتلوث. سرعة ثابتة قدر الإمكان، وغيار لا يدفع المحرك لأقصاه، يقللان الاستهلاك.",
      ),
      p(
        "Pneumatici sgonfi, un portapacchi inutile e i finestrini aperti in autostrada fanno lavorare di più il motore. Il climatizzatore si usa con misura.",
        "إطارات ناقصة الهواء، وحمالة سقف بلا لزوم، والنوافذ المفتوحة على الأوتوسترادا، كلها تزيد جهد المحرك. التكييف يُستخدم باعتدال.",
      ),
      p(
        "Il clacson e le accelerate a vuoto aumentano il rumore, specie vicino a ospedali e di notte. Non si abbandonano olio, batterie o filtri nell'ambiente: vanno conferiti nei punti di raccolta.",
        "البوق والتسخين في الفراغ يزيدان الضجيج، خاصة قرب المستشفيات وليلًا. لا تترك الزيت أو البطاريات أو الفلاتر في الطبيعة: تُسلَّم لنقاط الجمع.",
      ),
      p(
        "Un motore ben mantenuto, con filtro e scarico in ordine, inquina meno. Togliere il catalizzatore o il filtro antiparticolato è vietato.",
        "محرك مصان، بفلتر وعادم سليمين، يلوّث أقل. إزالة المحوّل الحفّاز أو فلتر الجسيمات ممنوعة.",
      ),
      note(
        "Nelle zone a traffico limitato si entra solo con i titoli previsti. Il divieto tutela l'aria del centro, non è un consiglio.",
        "مناطق المرور المحدود لا تُدخل إلا بالتصريح المطلوب. المنع يحمي هواء الوسط وليس نصيحة.",
      ),
    ],
  },
  {
    n: 25,
    slug: "veicolo",
    titleIt: "Veicolo, pneumatici, aderenza",
    titleAr: "المركبة والإطارات والتماسك",
    summaryAr: "الفحص الأول بعد 4 سنوات ثم كل سنتين. الإطار الأملس يطيل الفرملة ويسبب الانزلاق المائي.",
    blocks: [
      p(
        "La prima revisione dell'auto nuova è dopo 4 anni dalla prima immatricolazione, poi ogni 2 anni. Circolare con la revisione scaduta è illecito.",
        "الفحص الأول للسيارة الجديدة بعد 4 سنوات من أول ترخيص، ثم كل سنتين. السير بفحص منتهٍ مخالفة.",
      ),
      p(
        "I freni, lo sterzo, le luci, le sospensioni e gli pneumatici sono elementi di sicurezza. Una spia rossa dei freni o una perdita di olio freni impongono lo stop.",
        "الفرامل والمقود والأضواء والتعليق والإطارات عناصر أمان. لمبة فرامل حمراء أو تسرب زيت فرامل يفرض التوقف.",
      ),
      p(
        "Il battistrada deve avere incavi profondi almeno quanto impone la legge (il riferimento d'esame è 1,6 mm). Gomme lisce allungano la frenata, soprattutto sul bagnato.",
        "نقش الإطار يجب أن يبقى بعمق لا يقل عما يفرضه القانون (مرجع الامتحان 1.6 مم). الإطار الأملس يطيل الفرملة خصوصًا على المبلل.",
      ),
      p(
        "L'aquaplaning è la perdita di contatto quando l'acqua non viene espulsa. Favorito da velocità, gomme usurate e pozzanghere. Si alleggerisce l'acceleratore, si tiene il volante diritto e non si frena di colpo.",
        "الانزلاق المائي فقدان التلامس عندما لا يُطرد الماء. يساعده السرعة والإطار التالف والبرك. خفّف الوقود وأبقِ المقود مستقيمًا ولا تفرمل بعنف.",
      ),
      p(
        "Sulla neve servono pneumatici invernali o catene dove il segnale blu lo impone. In discesa ghiacciata si usano marce basse. L'ABS permette di sterzare durante una frenata decisa: non si pompa il pedale come coi freni vecchi.",
        "على الثلج تلزم إطارات شتوية أو سلاسل حيث يفرض القرص الأزرق ذلك. في نزول جليدي استخدم غيارًا منخفضًا. نظام ABS يسمح بالتوجيه أثناء فرملة قوية: لا تضخ الدواسة كالفرامل القديمة.",
      ),
      p(
        "La pressione si controlla a freddo, compresa la ruota di scorta. Una pressione sbagliata usura il battistrada ai bordi o al centro e peggiora la tenuta.",
        "يُفحص الضغط والإطار بارد، بما فيه الاحتياطي. الضغط الخطأ يآكل النقش من الأطراف أو الوسط ويُضعف الثبات.",
      ),
      note(
        "Specchi regolati e parabrezza pulito, dentro e fuori, sono parte della guida sicura quanto i freni.",
        "مرايا مضبوطة وزجاج نظيف من الداخل والخارج جزء من القيادة الآمنة مثل الفرامل.",
      ),
    ],
  },
];

export function chapterBySlug(slug: string) {
  return CHAPTERS.find((c) => c.slug === slug);
}
