export type Period = {
  no: number;
  start: string;
  end: string;
};

export type Course = {
  no: number;
  code: string;
  name: string;
  hours: number;
  place: string;
  teachers: string[];
  parentPlace: string;
};

export type Slot = {
  code: string;
  teacher: string;
  room?: string;
};

export type SchoolDay = {
  id: string;
  jsDay: number;
  name: string;
  short: string;
  slots: Array<Slot | null>;
};

export const school = {
  authority: "T.C. Yenişehir Kaymakamlığı",
  name: "Yahya Günsür Mesleki ve Teknik Anadolu Lisesi",
  grade: "9-F",
  totalHours: 45,
  homeroom: "Çiğdem Bilir",
  issued: "11 Ekim 2026",
  issuedNote:
    "Yukarıdaki dersler 11/10/2026 tarihinde verilmiştir. Bilgilerinizi rica ederim.",
  principal: "Adem Çelik",
  principalTitle: "Okul Müdürü",
} as const;

export const periods: Period[] = [
  { no: 1, start: "08:00", end: "08:40" },
  { no: 2, start: "08:50", end: "09:30" },
  { no: 3, start: "09:40", end: "10:20" },
  { no: 4, start: "10:30", end: "11:10" },
  { no: 5, start: "11:20", end: "12:00" },
  { no: 6, start: "12:40", end: "13:20" },
  { no: 7, start: "13:30", end: "14:10" },
  { no: 8, start: "14:20", end: "15:00" },
  { no: 9, start: "15:10", end: "15:50" },
  { no: 10, start: "15:55", end: "16:35" },
  { no: 11, start: "16:40", end: "17:20" },
];

export const lunch = { after: 5, start: "12:00", end: "12:40", label: "Öğle arası" };

const cigdem = "Çiğdem Bilir";
const hatice = "Hatice Cingöz";
const guzella = "Güzella Gökay";
const refah = "Refah Akış";
const kerim = "Kerim Eker";
const mustafa = "Mustafa Koç";
const hulyaKafali = "Hülya Kafalı";
const akif = "Akif Karaoğlan";
const adalet = "Adalet Çöçelli Satı";
const ahmet = "Ahmet Yıldırım";
const savas = "Savaş Tan";
const mehmet = "Mehmet Gölbol";
const gunes = "Güneş Zekioğulları";
const omer = "Ömer İl Faruk Yaşar";
const hulyaKarabulut = "Hülya Karabulut";

export const workshopRoom = "B-4, B-5, B-…";

export const courses: Course[] = [
  {
    no: 1,
    code: "9 TEEA",
    name: "9 Temel Elektrik-Elektronik",
    hours: 8,
    place: "Temel Elektrik-Elektronik",
    teachers: [kerim, mehmet, mustafa],
    parentPlace: "",
  },
  {
    no: 2,
    code: "BESPR",
    name: "Beden Eğitimi ve Spor / Görsel Sanatlar",
    hours: 2,
    place: "",
    teachers: [adalet, hatice],
    parentPlace: "",
  },
  {
    no: 3,
    code: "BİY",
    name: "Biyoloji",
    hours: 2,
    place: "",
    teachers: [ahmet],
    parentPlace: "",
  },
  {
    no: 4,
    code: "COĞ",
    name: "Coğrafya",
    hours: 2,
    place: "",
    teachers: [omer],
    parentPlace: "",
  },
  {
    no: 5,
    code: "DVAB",
    name: "Din Kültürü ve Ahlak Bilgisi",
    hours: 2,
    place: "",
    teachers: [savas],
    parentPlace: "",
  },
  {
    no: 6,
    code: "ETEKR",
    name: "Teknik Resim",
    hours: 2,
    place: "",
    teachers: [mustafa],
    parentPlace: "",
  },
  {
    no: 7,
    code: "FİZ",
    name: "Fizik",
    hours: 2,
    place: "",
    teachers: [hulyaKarabulut],
    parentPlace: "",
  },
  {
    no: 8,
    code: "KİM",
    name: "Kimya",
    hours: 2,
    place: "",
    teachers: [hulyaKafali],
    parentPlace: "",
  },
  {
    no: 9,
    code: "MATS",
    name: "Matematik",
    hours: 5,
    place: "",
    teachers: [akif],
    parentPlace: "",
  },
  {
    no: 10,
    code: "MESG",
    name: "Mesleki Gelişim Atölyesi",
    hours: 2,
    place: "",
    teachers: [kerim],
    parentPlace: "",
  },
  {
    no: 11,
    code: "RHY",
    name: "Rehberlik ve Yönlendirme",
    hours: 1,
    place: "",
    teachers: [cigdem],
    parentPlace: "",
  },
  {
    no: 12,
    code: "SÇDÜEĞ",
    name: "Seçmeli Düşünme Eğitimi",
    hours: 1,
    place: "",
    teachers: [refah],
    parentPlace: "",
  },
  {
    no: 13,
    code: "SÇSPOR",
    name: "Seçmeli Spor Eğitimi",
    hours: 2,
    place: "",
    teachers: [hatice],
    parentPlace: "",
  },
  {
    no: 14,
    code: "SÇTDİN",
    name: "Seçmeli Temel Dini Bilgiler",
    hours: 1,
    place: "",
    teachers: [savas],
    parentPlace: "",
  },
  {
    no: 15,
    code: "TAR",
    name: "Tarih",
    hours: 2,
    place: "",
    teachers: [gunes],
    parentPlace: "",
  },
  {
    no: 16,
    code: "TDE",
    name: "Türk Dili ve Edebiyatı",
    hours: 5,
    place: "",
    teachers: [guzella],
    parentPlace: "",
  },
  {
    no: 17,
    code: "YDİL4",
    name: "Yabancı Dil",
    hours: 4,
    place: "",
    teachers: [cigdem],
    parentPlace: "",
  },
];

const byCode = new Map(courses.map((course) => [course.code, course]));

export function courseByCode(code: string): Course {
  const course = byCode.get(code);
  if (!course) throw new Error(`Bilinmeyen ders kodu: ${code}`);
  return course;
}

function slot(code: string, teacher: string, room?: string): Slot {
  return room ? { code, teacher, room } : { code, teacher };
}

const empty: Array<Slot | null> = [null, null];

export const days: SchoolDay[] = [
  {
    id: "pazartesi",
    jsDay: 1,
    name: "Pazartesi",
    short: "Pzt",
    slots: [
      slot("YDİL4", cigdem),
      slot("YDİL4", cigdem),
      slot("SÇSPOR", hatice),
      slot("SÇSPOR", hatice),
      slot("RHY", cigdem),
      slot("TDE", guzella),
      slot("TDE", guzella),
      slot("SÇDÜEĞ", refah),
      slot("MESG", kerim),
      ...empty,
    ],
  },
  {
    id: "sali",
    jsDay: 2,
    name: "Salı",
    short: "Sal",
    slots: [
      slot("TDE", guzella),
      slot("TDE", guzella),
      slot("TDE", guzella),
      slot("ETEKR", mustafa),
      slot("ETEKR", mustafa),
      slot("YDİL4", cigdem),
      slot("YDİL4", cigdem),
      slot("KİM", hulyaKafali),
      slot("KİM", hulyaKafali),
      ...empty,
    ],
  },
  {
    id: "carsamba",
    jsDay: 3,
    name: "Çarşamba",
    short: "Çar",
    slots: [
      slot("MATS", akif),
      slot("MATS", akif),
      slot("BESPR", adalet),
      slot("BESPR", adalet),
      slot("BİY", ahmet),
      slot("BİY", ahmet),
      slot("DVAB", savas),
      slot("DVAB", savas),
      slot("SÇTDİN", savas),
      ...empty,
    ],
  },
  {
    id: "persembe",
    jsDay: 4,
    name: "Perşembe",
    short: "Per",
    slots: [
      slot("9 TEEA", mehmet, workshopRoom),
      slot("9 TEEA", mehmet, workshopRoom),
      slot("9 TEEA", mehmet, workshopRoom),
      slot("9 TEEA", mehmet, workshopRoom),
      slot("9 TEEA", mehmet, workshopRoom),
      slot("9 TEEA", mehmet, workshopRoom),
      slot("9 TEEA", mehmet, workshopRoom),
      slot("9 TEEA", mehmet, workshopRoom),
      slot("MESG", kerim),
      ...empty,
    ],
  },
  {
    id: "cuma",
    jsDay: 5,
    name: "Cuma",
    short: "Cum",
    slots: [
      slot("TAR", gunes),
      slot("TAR", gunes),
      slot("COĞ", omer),
      slot("COĞ", omer),
      slot("FİZ", hulyaKarabulut),
      slot("FİZ", hulyaKarabulut),
      slot("MATS", akif),
      slot("MATS", akif),
      slot("MATS", akif),
      ...empty,
    ],
  },
];

export const sourceNotes = [
  "Perşembe atölye satırında derslik belgede “B-4, B-5, B-” diye kesik görünüyor. Üçüncü kod tamamlanmadan bırakıldı.",
  "9 Temel Elektrik-Elektronik yer sütunu belgede “TEMEL ELEKTRİK-ELE…” diye kesiliyor. Görünen kısım yazıldı.",
  "Beden eğitimi dersinin adı belgede “BEDEN EĞİTİMİ VE SPOR / GÖRSEL SANATLAR /” diye bitiyor. Satır hücrede kesik olduğu için devamı eklenmedi.",
  "Türk Dili ve Edebiyatı adının yanında belgede bir yıldız var. Yıldızın açıklaması sayfada yok.",
  "Veli görüşme yeri sütunu belgede bütün dersler için boş.",
  "Perşembe atölyesinde hücrede Mehmet Gölbol yazılı. Dersin kayıtlı öğretmenleri Kerim Eker, Mehmet Gölbol ve Mustafa Koç.",
  "Çarşamba beden eğitiminde hücrede Adalet Çöçelli Satı yazılı. Dersin kayıtlı öğretmenleri Adalet Çöçelli Satı ve Hatice Cingöz.",
] as const;

function toMinutes(value: string): number {
  const [hour, minute] = value.split(":").map(Number);
  return hour * 60 + minute;
}

export type Focus = {
  kind: "now" | "next";
  day: SchoolDay;
  period: Period;
  slot: Slot;
};

export function findFocus(now: Date): Focus | null {
  const weekday = now.getDay();
  const minutes = now.getHours() * 60 + now.getMinutes();
  const order = [1, 2, 3, 4, 5];
  const start = order.indexOf(weekday);
  const sequence = start === -1 ? order : [...order.slice(start), ...order.slice(0, start)];

  for (let index = 0; index < sequence.length; index += 1) {
    const jsDay = sequence[index];
    const day = days.find((item) => item.jsDay === jsDay);
    if (!day) continue;
    const isToday = index === 0 && jsDay === weekday;

    for (let periodIndex = 0; periodIndex < periods.length; periodIndex += 1) {
      const period = periods[periodIndex];
      const lesson = day.slots[periodIndex];
      if (!lesson) continue;
      const startMinute = toMinutes(period.start);
      const endMinute = toMinutes(period.end);
      if (isToday) {
        if (minutes >= startMinute && minutes < endMinute) {
          return { kind: "now", day, period, slot: lesson };
        }
        if (minutes < startMinute) {
          return { kind: "next", day, period, slot: lesson };
        }
      } else {
        return { kind: "next", day, period, slot: lesson };
      }
    }
  }

  return null;
}
