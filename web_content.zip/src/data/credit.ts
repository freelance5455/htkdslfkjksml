export const CREDIT = "تم إنشاؤه بواسطة محمد صبح";
