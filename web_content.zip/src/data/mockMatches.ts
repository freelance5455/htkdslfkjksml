import { Match, SportsChannel, HighlightVideo } from '../types';

export const MOCK_MATCHES: Match[] = [
  {
    id: 'match-1',
    homeTeam: {
      name: 'ريال مدريد',
      shortName: 'RMA',
      logo: 'https://upload.wikimedia.org/wikipedia/en/5/56/Real_Madrid_CF.svg',
      country: 'إسبانيا'
    },
    awayTeam: {
      name: 'برشلونة',
      shortName: 'BAR',
      logo: 'https://upload.wikimedia.org/wikipedia/en/4/47/FC_Barcelona_%28crest%29.svg',
      country: 'إسبانيا'
    },
    tournament: {
      name: 'الدوري الإسباني - كلاسيكو الأرض',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/0/0f/LaLiga_logo_2023.svg',
      category: 'الدوري الإسباني'
    },
    status: 'live',
    minute: 76,
    homeScore: 2,
    awayScore: 1,
    date: 'اليوم',
    time: '22:00',
    dayGroup: 'today',
    channel: 'beIN Sports 1 HD',
    commentator: 'عصام الشوالي',
    stadium: 'سانتياغو برنابيو - مدريد',
    round: 'الجولة 28',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    servers: [
      { id: 's1', name: 'سيرفر VIP (سريع جداً - بدون تقطيع)', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4' },
      { id: 's2', name: 'سيرفر متعدد الجودات (لكل السرعات)', quality: '720p HD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
      { id: 's3', name: 'سيرفر أصحاب النت الضعيف (SD)', quality: '480p SD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4' },
      { id: 's4', name: 'سيرفر بث صوتي فقط (توفير باقة)', quality: 'Audio Only', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4' },
    ],
    events: [
      { id: 'ev-1', minute: 14, type: 'goal', team: 'home', player: 'فينيسيوس جونيور', assistPlayer: 'جود بيلينغهام', description: 'تسديدة قوية في الزاوية اليسرى' },
      { id: 'ev-2', minute: 38, type: 'yellow_card', team: 'away', player: 'غافي', description: 'تدخل قوي في وسط الميدان' },
      { id: 'ev-3', minute: 52, type: 'goal', team: 'away', player: 'لامين يامال', assistPlayer: 'بيدري', description: 'مراوغة مذهلة وتسديدة ساقطة' },
      { id: 'ev-4', minute: 67, type: 'goal', team: 'home', player: 'كيليان مبابي', assistPlayer: 'فالفيردي', description: 'انفراد سريع ولمسة في أقصى الشباك' },
      { id: 'ev-5', minute: 73, type: 'substitution', team: 'away', player: 'دخول رافينيا - خروج فيران توريس' },
    ],
    stats: {
      possession: [52, 48],
      shots: [14, 11],
      shotsOnTarget: [6, 5],
      corners: [5, 4],
      fouls: [9, 12],
      yellowCards: [1, 2],
      redCards: [0, 0],
      offsides: [2, 1],
      passesAccuracy: [88, 86]
    },
    lineup: {
      home: {
        formation: '4-3-3',
        coach: 'كارلو أنشيلوتي',
        startingXI: [
          { number: 1, name: 'تيبو كورتوا', position: 'GK' },
          { number: 2, name: 'داني كارفاخال', position: 'DF', isCaptain: true },
          { number: 3, name: 'إيدير ميليتاو', position: 'DF' },
          { number: 22, name: 'أنطونيو روديغر', position: 'DF' },
          { number: 23, name: 'فيرلاند ميندي', position: 'DF' },
          { number: 8, name: 'فيديريكو فالفيردي', position: 'MF' },
          { number: 14, name: 'أوريليان تشواميني', position: 'MF' },
          { number: 5, name: 'جود بيلينغهام', position: 'MF' },
          { number: 11, name: 'رودريغو غوس', position: 'FW' },
          { number: 9, name: 'كيليان مبابي', position: 'FW', goals: 1 },
          { number: 7, name: 'فينيسيوس جونيور', position: 'FW', goals: 1 }
        ],
        substitutes: [
          { number: 13, name: 'أندري لونين', position: 'GK' },
          { number: 10, name: 'لوكا مودريتش', position: 'MF' },
          { number: 21, name: 'إبراهيم دياز', position: 'FW' },
          { number: 16, name: 'إندريك', position: 'FW' }
        ]
      },
      away: {
        formation: '4-2-3-1',
        coach: 'هانز فليك',
        startingXI: [
          { number: 1, name: 'مارك أندريه تير شتيغن', position: 'GK', isCaptain: true },
          { number: 23, name: 'جول كوندي', position: 'DF' },
          { number: 2, name: 'باو كوبارسي', position: 'DF' },
          { number: 5, name: 'إينيغو مارتينيز', position: 'DF' },
          { number: 3, name: 'أليخاندرو بالدي', position: 'DF' },
          { number: 17, name: 'مارك كاسادو', position: 'MF' },
          { number: 8, name: 'بيدري', position: 'MF' },
          { number: 19, name: 'لامين يامال', position: 'FW', goals: 1 },
          { number: 20, name: 'داني أولمو', position: 'MF' },
          { number: 6, name: 'غافي', position: 'MF', yellowCard: true },
          { number: 9, name: 'روبرت ليفاندوفسكي', position: 'FW' }
        ],
        substitutes: [
          { number: 13, name: 'إينياكي بينيا', position: 'GK' },
          { number: 11, name: 'رافينيا', position: 'FW' },
          { number: 7, name: 'فيران توريس', position: 'FW' },
          { number: 21, name: 'فرينكي دي يونغ', position: 'MF' }
        ]
      }
    }
  },
  {
    id: 'match-2',
    homeTeam: {
      name: 'مانشستر سيتي',
      shortName: 'MCI',
      logo: 'https://upload.wikimedia.org/wikipedia/en/e/eb/Manchester_City_FC_badge.svg',
      country: 'إنجلترا'
    },
    awayTeam: {
      name: 'أرسنال',
      shortName: 'ARS',
      logo: 'https://upload.wikimedia.org/wikipedia/en/5/53/Arsenal_FC.svg',
      country: 'إنجلترا'
    },
    tournament: {
      name: 'الدوري الإنجليزي الممتاز',
      logo: 'https://upload.wikimedia.org/wikipedia/en/f/f2/Premier_League_Logo.svg',
      category: 'الدوري الإنجليزي'
    },
    status: 'live',
    minute: 62,
    homeScore: 1,
    awayScore: 1,
    date: 'اليوم',
    time: '19:30',
    dayGroup: 'today',
    channel: 'beIN Sports 2 HD',
    commentator: 'حفيظ دراجي',
    stadium: 'ملعب الاتحاد - مانشستر',
    round: 'الجولة 29',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    servers: [
      { id: 's2-1', name: 'سيرفر فائق السرعة HD', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4' },
      { id: 's2-2', name: 'سيرفر خفيف (نت متوسط)', quality: '720p HD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
      { id: 's2-3', name: 'سيرفر IRAQI LIVE البديل', quality: '480p SD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4' },
    ],
    events: [
      { id: 'm2-e1', minute: 9, type: 'goal', team: 'home', player: 'إيرلينغ هالاند', assistPlayer: 'كيفين دي بروين' },
      { id: 'm2-e2', minute: 41, type: 'yellow_card', team: 'home', player: 'روبن دياز' },
      { id: 'm2-e3', minute: 48, type: 'goal', team: 'away', player: 'بوكايو ساكا', assistPlayer: 'مارتن أوديغارد' }
    ],
    stats: {
      possession: [64, 36],
      shots: [12, 7],
      shotsOnTarget: [5, 3],
      corners: [8, 2],
      fouls: [6, 11],
      yellowCards: [1, 2],
      redCards: [0, 0],
      offsides: [1, 2],
      passesAccuracy: [91, 79]
    },
    lineup: {
      home: {
        formation: '4-1-4-1',
        coach: 'بيب غوارديولا',
        startingXI: [
          { number: 31, name: 'إيدرسون', position: 'GK' },
          { number: 2, name: 'كايل ووكر', position: 'DF', isCaptain: true },
          { number: 3, name: 'روبن دياز', position: 'DF', yellowCard: true },
          { number: 25, name: 'مانويل أكانجي', position: 'DF' },
          { number: 24, name: 'جوشكو غفارديول', position: 'DF' },
          { number: 16, name: 'رودري', position: 'MF' },
          { number: 20, name: 'برناردو سيلفا', position: 'MF' },
          { number: 17, name: 'كيفين دي بروين', position: 'MF' },
          { number: 47, name: 'فيل فودين', position: 'MF' },
          { number: 10, name: 'جاك غريليش', position: 'FW' },
          { number: 9, name: 'إيرلينغ هالاند', position: 'FW', goals: 1 }
        ],
        substitutes: []
      },
      away: {
        formation: '4-3-3',
        coach: 'ميكل أرتيتا',
        startingXI: [
          { number: 22, name: 'دافيد رايا', position: 'GK' },
          { number: 4, name: 'بن وايت', position: 'DF' },
          { number: 2, name: 'ويليام ساليبا', position: 'DF' },
          { number: 6, name: 'غابرييل ماغاليايس', position: 'DF' },
          { number: 12, name: 'يوريان تيمبر', position: 'DF' },
          { number: 41, name: 'ديكلان رايس', position: 'MF' },
          { number: 5, name: 'توماس بارتي', position: 'MF' },
          { number: 8, name: 'مارتن أوديغارد', position: 'MF', isCaptain: true },
          { number: 7, name: 'بوكايو ساكا', position: 'FW', goals: 1 },
          { number: 29, name: 'كاي هافيرتز', position: 'FW' },
          { number: 11, name: 'غابرييل مارتينيلي', position: 'FW' }
        ],
        substitutes: []
      }
    }
  },
  {
    id: 'match-3',
    homeTeam: {
      name: 'الهلال',
      shortName: 'HIL',
      logo: 'https://upload.wikimedia.org/wikipedia/ar/2/29/Al-Hilal_Saudi_FC.png',
      country: 'السعودية'
    },
    awayTeam: {
      name: 'النصر',
      shortName: 'NSR',
      logo: 'https://upload.wikimedia.org/wikipedia/ar/a/a2/Al_Nassr_Logo.png',
      country: 'السعودية'
    },
    tournament: {
      name: 'دوري روشن السعودي - ديربي الرياض',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/e/e0/Roshn_Saudi_League_logo.png',
      category: 'الدوري السعودي'
    },
    status: 'live',
    minute: 34,
    homeScore: 1,
    awayScore: 0,
    date: 'اليوم',
    time: '21:00',
    dayGroup: 'today',
    channel: 'SSC 1 HD',
    commentator: 'فارس عوض',
    stadium: 'المملكة أرينا - الرياض',
    round: 'قمة الجولة 24',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    servers: [
      { id: 's3-1', name: 'سيرفر SSC الرياضي (FHD)', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4' },
      { id: 's3-2', name: 'سيرفر الجوال السريع', quality: '720p HD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
      { id: 's3-3', name: 'بث تعليق صوتي مباشر', quality: 'Audio', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4' }
    ],
    events: [
      { id: 'm3-e1', minute: 18, type: 'goal', team: 'home', player: 'ألكسندر ميتروفيتش', assistPlayer: 'سالم الدوسري', description: 'رأسية نموذجية بعد عرضية متقنة' },
      { id: 'm3-e2', minute: 29, type: 'yellow_card', team: 'away', player: 'مارسيلو بروزوفيتش' }
    ],
    stats: {
      possession: [55, 45],
      shots: [7, 5],
      shotsOnTarget: [3, 2],
      corners: [3, 2],
      fouls: [5, 7],
      yellowCards: [0, 1],
      redCards: [0, 0],
      offsides: [1, 0],
      passesAccuracy: [85, 83]
    },
    lineup: {
      home: {
        formation: '4-2-3-1',
        coach: 'جورجي جيسوس',
        startingXI: [
          { number: 37, name: 'ياسين بونو', position: 'GK' },
          { number: 66, name: 'سعود عبد الحميد', position: 'DF' },
          { number: 3, name: 'خاليدو كوليبالي', position: 'DF' },
          { number: 5, name: 'علي البليهي', position: 'DF' },
          { number: 12, name: 'ياسر الشهراني', position: 'DF' },
          { number: 8, name: 'روبن نيفيز', position: 'MF' },
          { number: 22, name: 'سيرجي ميلينكوفيتش سافيتش', position: 'MF' },
          { number: 77, name: 'مالكوم', position: 'FW' },
          { number: 29, name: 'سالم الدوسري', position: 'FW', isCaptain: true },
          { number: 11, name: 'ماركوس ليوناردو', position: 'FW' },
          { number: 9, name: 'ألكسندر ميتروفيتش', position: 'FW', goals: 1 }
        ],
        substitutes: []
      },
      away: {
        formation: '4-2-3-1',
        coach: 'ستيفانو بيولي',
        startingXI: [
          { number: 24, name: 'بينتو ماثيوس', position: 'GK' },
          { number: 2, name: 'سلطان الغنام', position: 'DF' },
          { number: 3, name: 'محمد سيماكان', position: 'DF' },
          { number: 27, name: 'إيميرك لابورت', position: 'DF' },
          { number: 12, name: 'نواف بوشل', position: 'DF' },
          { number: 17, name: 'عبد الله الخيبري', position: 'MF' },
          { number: 77, name: 'مارسيلو بروزوفيتش', position: 'MF', yellowCard: true },
          { number: 25, name: 'أوتافيو', position: 'MF' },
          { number: 10, name: 'ساديو ماني', position: 'FW' },
          { number: 94, name: 'تاليسكا', position: 'FW' },
          { number: 7, name: 'كريستيانو رونالدو', position: 'FW', isCaptain: true }
        ],
        substitutes: []
      }
    }
  },
  {
    id: 'match-4',
    homeTeam: {
      name: 'ليفربول',
      shortName: 'LIV',
      logo: 'https://upload.wikimedia.org/wikipedia/en/0/0c/Liverpool_FC.svg',
      country: 'إنجلترا'
    },
    awayTeam: {
      name: 'تشيلسي',
      shortName: 'CHE',
      logo: 'https://upload.wikimedia.org/wikipedia/en/c/cc/Chelsea_FC.svg',
      country: 'إنجلترا'
    },
    tournament: {
      name: 'الدوري الإنجليزي الممتاز',
      logo: 'https://upload.wikimedia.org/wikipedia/en/f/f2/Premier_League_Logo.svg',
      category: 'الدوري الإنجليزي'
    },
    status: 'upcoming',
    date: 'اليوم',
    time: '23:00',
    dayGroup: 'today',
    channel: 'beIN Sports 1 HD',
    commentator: 'خليل البلوشي',
    stadium: 'أنفيلد - ليفربول',
    round: 'الجولة 29',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4',
    servers: [
      { id: 's4-1', name: 'سيرفر البث المباشر (جاهز)', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4' }
    ],
    events: [],
    stats: {
      possession: [50, 50],
      shots: [0, 0],
      shotsOnTarget: [0, 0],
      corners: [0, 0],
      fouls: [0, 0],
      yellowCards: [0, 0],
      redCards: [0, 0],
      offsides: [0, 0],
      passesAccuracy: [0, 0]
    },
    lineup: {
      home: {
        formation: '4-3-3',
        coach: 'أرني سلوت',
        startingXI: [
          { number: 1, name: 'أليسون بيكر', position: 'GK' },
          { number: 66, name: 'ترينت ألكسندر أرنولد', position: 'DF' },
          { number: 4, name: 'فيرجيل فان دايك', position: 'DF', isCaptain: true },
          { number: 5, name: 'إبراهيما كوناتي', position: 'DF' },
          { number: 26, name: 'أندي روبرتسون', position: 'DF' },
          { number: 38, name: 'ريان خرافينبيرخ', position: 'MF' },
          { number: 10, name: 'أليكسيس ماك أليستر', position: 'MF' },
          { number: 8, name: 'دومينيك سوبوسلاي', position: 'MF' },
          { number: 11, name: 'محمد صلاح', position: 'FW' },
          { number: 9, name: 'داروين نونيز', position: 'FW' },
          { number: 7, name: 'لويس دياز', position: 'FW' }
        ],
        substitutes: []
      },
      away: {
        formation: '4-2-3-1',
        coach: 'إنزو ماريسكا',
        startingXI: [
          { number: 1, name: 'روبرت سانشيز', position: 'GK' },
          { number: 27, name: 'مالو غوستو', position: 'DF' },
          { number: 29, name: 'ويسلي فوفانا', position: 'DF' },
          { number: 6, name: 'ليفي كولويل', position: 'DF' },
          { number: 3, name: 'مارك كوكورييا', position: 'DF' },
          { number: 25, name: 'مويسيس كايسيدو', position: 'MF' },
          { number: 8, name: 'إنزو فرنانديز', position: 'MF', isCaptain: true },
          { number: 11, name: 'نوني مادويكي', position: 'FW' },
          { number: 20, name: 'كول بالمر', position: 'MF' },
          { number: 19, name: 'جايدون سانشو', position: 'FW' },
          { number: 15, name: 'نيكولاس جاكسون', position: 'FW' }
        ],
        substitutes: []
      }
    }
  },
  {
    id: 'match-5',
    homeTeam: {
      name: 'الأهلي المصري',
      shortName: 'AHL',
      logo: 'https://upload.wikimedia.org/wikipedia/ar/8/8c/Al_Ahly_SC_logo.png',
      country: 'مصر'
    },
    awayTeam: {
      name: 'الترجي التونسي',
      shortName: 'EST',
      logo: 'https://upload.wikimedia.org/wikipedia/fr/5/53/Esp%C3%A9rance_sportive_de_Tunis_%28logo%29.svg',
      country: 'تونس'
    },
    tournament: {
      name: 'دوري أبطال إفريقيا - نصف النهائي',
      logo: 'https://upload.wikimedia.org/wikipedia/en/e/e0/CAF_Champions_League.png',
      category: 'دوري أبطال إفريقيا'
    },
    status: 'upcoming',
    date: 'اليوم',
    time: '23:00',
    dayGroup: 'today',
    channel: 'beIN Sports 4 HD',
    commentator: 'علي محمد علي',
    stadium: 'ستاد القاهرة الدولي',
    round: 'ذهاب نصف النهائي',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    servers: [
      { id: 's5-1', name: 'سيرفر إفريقيا مباشر', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' }
    ],
    events: [],
    stats: {
      possession: [50, 50],
      shots: [0, 0],
      shotsOnTarget: [0, 0],
      corners: [0, 0],
      fouls: [0, 0],
      yellowCards: [0, 0],
      redCards: [0, 0],
      offsides: [0, 0],
      passesAccuracy: [0, 0]
    },
    lineup: {
      home: {
        formation: '4-3-3',
        coach: 'مارسيل كولر',
        startingXI: [
          { number: 1, name: 'محمد الشناوي', position: 'GK', isCaptain: true },
          { number: 30, name: 'محمد هاني', position: 'DF' },
          { number: 6, name: 'ياسر إبراهيم', position: 'DF' },
          { number: 5, name: 'رامي ربيعة', position: 'DF' },
          { number: 21, name: 'علي معلول', position: 'DF' },
          { number: 8, name: 'أكرم توفيق', position: 'MF' },
          { number: 13, name: 'مروان عطية', position: 'MF' },
          { number: 22, name: 'إمام عاشور', position: 'MF' },
          { number: 14, name: 'حسين الشحات', position: 'FW' },
          { number: 9, name: 'وسام أبو علي', position: 'FW' },
          { number: 12, name: 'رضا سليم', position: 'FW' }
        ],
        substitutes: []
      },
      away: {
        formation: '4-3-3',
        coach: 'ميغيل كاردوزو',
        startingXI: [
          { number: 1, name: 'أمان الله مميش', position: 'GK' },
          { number: 2, name: 'محمد بن علي', position: 'DF' },
          { number: 5, name: 'ياسين مرياح', position: 'DF', isCaptain: true },
          { number: 4, name: 'محمد أمين توغاي', position: 'DF' },
          { number: 20, name: 'محمد أمين بن حميدة', position: 'DF' },
          { number: 8, name: 'حسام تقا', position: 'MF' },
          { number: 18, name: 'روجي أهولو', position: 'MF' },
          { number: 10, name: 'يان ساس', position: 'MF' },
          { number: 11, name: 'حسام الدين غشة', position: 'FW' },
          { number: 9, name: 'رودريغو رودريغيز', position: 'FW' },
          { number: 7, name: 'أندريه بوكيا', position: 'FW' }
        ],
        substitutes: []
      }
    }
  },
  {
    id: 'match-6',
    homeTeam: {
      name: 'بايرن ميونخ',
      shortName: 'BAY',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/1/1b/FC_Bayern_M%C3%BCnchen_logo_%282017%29.svg',
      country: 'ألمانيا'
    },
    awayTeam: {
      name: 'باريس سان جيرمان',
      shortName: 'PSG',
      logo: 'https://upload.wikimedia.org/wikipedia/en/a/a7/Paris_Saint-Germain_F.C..svg',
      country: 'فرنسا'
    },
    tournament: {
      name: 'دوري أبطال أوروبا',
      logo: 'https://upload.wikimedia.org/wikipedia/en/b/bf/UEFA_Champions_League_logo_2.svg',
      category: 'دوري أبطال أوروبا'
    },
    status: 'upcoming',
    date: 'غداً',
    time: '22:00',
    dayGroup: 'tomorrow',
    channel: 'beIN Sports 1 HD',
    commentator: 'عامر عبد الله',
    stadium: 'أليانز أرينا - ميونخ',
    round: 'دور الـ 16',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    servers: [
      { id: 's6-1', name: 'سيرفر البث المباشر 4K', quality: '4K Ultra', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' }
    ],
    events: [],
    stats: {
      possession: [50, 50],
      shots: [0, 0],
      shotsOnTarget: [0, 0],
      corners: [0, 0],
      fouls: [0, 0],
      yellowCards: [0, 0],
      redCards: [0, 0],
      offsides: [0, 0],
      passesAccuracy: [0, 0]
    },
    lineup: {
      home: {
        formation: '4-2-3-1',
        coach: 'فينسنت كومباني',
        startingXI: [{ number: 1, name: 'مانويل نوير', position: 'GK', isCaptain: true }, { number: 9, name: 'هاري كين', position: 'FW' }],
        substitutes: []
      },
      away: {
        formation: '4-3-3',
        coach: 'لويس إنريكي',
        startingXI: [{ number: 99, name: 'جانلويجي دوناروما', position: 'GK' }, { number: 10, name: 'عثمان ديمبيلي', position: 'FW' }],
        substitutes: []
      }
    }
  },
  {
    id: 'match-7',
    homeTeam: {
      name: 'إنتر ميلان',
      shortName: 'INT',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/0/05/FC_Internazionale_Milano_2021.svg',
      country: 'إيطاليا'
    },
    awayTeam: {
      name: 'يوفنتوس',
      shortName: 'JUV',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/b/bc/Juventus_FC_2017_icon_%28black%29.svg',
      country: 'إيطاليا'
    },
    tournament: {
      name: 'الدوري الإيطالي (سيريا آ)',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/e/e9/Serie_A_logo_2019.svg',
      category: 'الدوري الإيطالي'
    },
    status: 'finished',
    homeScore: 3,
    awayScore: 2,
    date: 'أمس',
    time: '21:45',
    dayGroup: 'yesterday',
    channel: 'Starzplay Sports 1 HD',
    commentator: 'فهد العتيبي',
    stadium: 'جوزيبي مياتزا (سان سيرو)',
    round: 'الجولة 27',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    servers: [
      { id: 's7-1', name: 'ملخص المباراة وإعادتها بالكامل', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4' }
    ],
    events: [
      { id: 'm7-e1', minute: 15, type: 'goal', team: 'home', player: 'لاوتارو مارتينيز' },
      { id: 'm7-e2', minute: 28, type: 'goal', team: 'away', player: 'دوشان فلاهوفيتش' },
      { id: 'm7-e3', minute: 53, type: 'goal', team: 'home', player: 'ماركوس تورام' },
      { id: 'm7-e4', minute: 71, type: 'goal', team: 'away', player: 'كينان يلديز' },
      { id: 'm7-e5', minute: 88, type: 'goal', team: 'home', player: 'نيكولو باريلا' }
    ],
    stats: {
      possession: [58, 42],
      shots: [16, 10],
      shotsOnTarget: [7, 5],
      corners: [7, 3],
      fouls: [10, 14],
      yellowCards: [2, 3],
      redCards: [0, 0],
      offsides: [1, 2],
      passesAccuracy: [87, 81]
    },
    lineup: {
      home: {
        formation: '3-5-2',
        coach: 'سيموني إنزاغي',
        startingXI: [{ number: 1, name: 'يان سومر', position: 'GK' }, { number: 10, name: 'لاوتارو مارتينيز', position: 'FW', isCaptain: true, goals: 1 }],
        substitutes: []
      },
      away: {
        formation: '4-2-3-1',
        coach: 'تياغو موتا',
        startingXI: [{ number: 29, name: 'ميكيل دي غريغوريو', position: 'GK' }, { number: 9, name: 'دوشان فلاهوفيتش', position: 'FW', goals: 1 }],
        substitutes: []
      }
    }
  },
  {
    id: 'match-8',
    homeTeam: {
      name: 'المغرب',
      shortName: 'MAR',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/2/2c/Flag_of_Morocco.svg',
      country: 'المغرب'
    },
    awayTeam: {
      name: 'البرازيل',
      shortName: 'BRA',
      logo: 'https://upload.wikimedia.org/wikipedia/en/0/05/Flag_of_Brazil.svg',
      country: 'البرازيل'
    },
    tournament: {
      name: 'مباراة دولية ودية كبرى',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/6/6f/FIFA_logo_without_tagline.svg',
      category: 'مباريات دولية'
    },
    status: 'finished',
    homeScore: 2,
    awayScore: 1,
    date: 'أمس',
    time: '22:00',
    dayGroup: 'yesterday',
    channel: 'المغربية الرياضية TNT',
    commentator: 'هشام فرج',
    stadium: 'ملعب طنجة الكبير',
    round: 'مباراة ودية',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4',
    servers: [
      { id: 's8-1', name: 'ملخص أهداف اللقاء التاريخي', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4' }
    ],
    events: [
      { id: 'm8-e1', minute: 29, type: 'goal', team: 'home', player: 'سفيان بوفال' },
      { id: 'm8-e2', minute: 67, type: 'goal', team: 'away', player: 'كاسيميرو' },
      { id: 'm8-e3', minute: 79, type: 'goal', team: 'home', player: 'عبد الحميد صابيري' }
    ],
    stats: {
      possession: [46, 54],
      shots: [9, 13],
      shotsOnTarget: [4, 5],
      corners: [4, 6],
      fouls: [14, 11],
      yellowCards: [3, 2],
      redCards: [0, 0],
      offsides: [1, 2],
      passesAccuracy: [82, 86]
    },
    lineup: {
      home: {
        formation: '4-3-3',
        coach: 'وليد الركراكي',
        startingXI: [{ number: 1, name: 'ياسين بونو', position: 'GK' }, { number: 2, name: 'أشرف حكيمي', position: 'DF' }],
        substitutes: []
      },
      away: {
        formation: '4-3-3',
        coach: 'دوريفال جونيور',
        startingXI: [{ number: 1, name: 'ويفرتون', position: 'GK' }, { number: 7, name: 'فينيسيوس جونيور', position: 'FW' }],
        substitutes: []
      }
    }
  }
];

export const MOCK_CHANNELS: SportsChannel[] = [
  {
    id: 'ch-bein1',
    name: 'beIN Sports 1 HD',
    category: 'beIN Sports',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/BeIN_SPORTS_logo.svg/320px-BeIN_SPORTS_logo.svg.png',
    quality: '4K',
    currentShow: 'مباشر: استوديو الدوري الإسباني (الكلاسيكو)',
    viewers: '284.5K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    servers: [
      { id: 'c1-s1', name: 'سيرفر رئيسي 1080p', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4' },
      { id: 'c1-s2', name: 'سيرفر جودة 720p', quality: '720p HD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
      { id: 'c1-s3', name: 'سيرفر ضعيف 480p', quality: '480p SD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4' }
    ]
  },
  {
    id: 'ch-bein2',
    name: 'beIN Sports 2 HD',
    category: 'beIN Sports',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/BeIN_SPORTS_logo.svg/320px-BeIN_SPORTS_logo.svg.png',
    quality: 'FHD',
    currentShow: 'مباشر: مانشستر سيتي ضد أرسنال (البريميرليغ)',
    viewers: '193.2K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    servers: [
      { id: 'c2-s1', name: 'سيرفر VIP عالي السرعة', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4' }
    ]
  },
  {
    id: 'ch-ssc1',
    name: 'SSC 1 HD الرياضية',
    category: 'SSC',
    logo: 'https://upload.wikimedia.org/wikipedia/ar/d/d4/SSC_Sports_Logo.png',
    quality: 'FHD',
    currentShow: 'مباشر: الهلال ضد النصر - ديربي الرياض',
    viewers: '312.0K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    servers: [
      { id: 'c-ssc-1', name: 'سيرفر الدوري السعودي 1', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4' }
    ]
  },
  {
    id: 'ch-alkass1',
    name: 'الكأس 1 HD',
    category: 'Alkass',
    logo: 'https://upload.wikimedia.org/wikipedia/ar/thumb/8/87/Al_Kass_Channel_Logo.svg/320px-Al_Kass_Channel_Logo.svg.png',
    quality: 'HD',
    currentShow: 'برنامج المجلس - خالد جاسم وضيوفه',
    viewers: '85.4K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    servers: [
      { id: 'c-kass-1', name: 'سيرفر المجلس المباشر', quality: '720p HD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4' }
    ]
  },
  {
    id: 'ch-ad-sport',
    name: 'أبوظبي الرياضية 1 HD',
    category: 'AD Sports',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Abu_Dhabi_Sports_logo.png/320px-Abu_Dhabi_Sports_logo.png',
    quality: 'FHD',
    currentShow: 'كأس رئيس الدولة الإماراتي',
    viewers: '64.1K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    servers: [
      { id: 'c-ad-1', name: 'سيرفر أبوظبي الرياضية HD', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' }
    ]
  },
  {
    id: 'ch-ontime',
    name: 'أون تايم سبورتس 1',
    category: 'Open',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/On_Time_Sports.png/320px-On_Time_Sports.png',
    quality: 'HD',
    currentShow: 'ستاد مصر - تحليل مباريات اليوم',
    viewers: '115.8K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4',
    servers: [
      { id: 'c-on-1', name: 'سيرفر البث المفتوح HD', quality: '720p HD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackSeeTheWorld.mp4' }
    ]
  },
  {
    id: 'ch-bein-news',
    name: 'beIN Sports الإخبارية (مفتوحة)',
    category: 'beIN Sports',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/BeIN_SPORTS_logo.svg/320px-BeIN_SPORTS_logo.svg.png',
    quality: 'FHD',
    currentShow: 'نشرة أخبار منتصف الليل وآخر الصفقات',
    viewers: '98.3K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    servers: [
      { id: 'c-news-1', name: 'سيرفر beIN الإخبارية المفتوحة', quality: '1080p FHD', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4' }
    ]
  }
];

export const MOCK_HIGHLIGHTS: HighlightVideo[] = [
  {
    id: 'hl-1',
    title: 'أهداف الكلاسيكو النارية: ريال مدريد 2 - 1 برشلونة',
    tournament: 'الدوري الإسباني',
    duration: '09:42',
    date: 'اليوم',
    views: '1.4M مشاهدة',
    thumbnail: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=800&auto=format&fit=crop',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    goalsSummary: 'فينيسيوس (14\')، مبابي (67\') | لامين يامال (52\')'
  },
  {
    id: 'hl-2',
    title: 'ملخص قمة إنجلترا المجنونة: مانشستر سيتي وأرسنال',
    tournament: 'الدوري الإنجليزي',
    duration: '11:15',
    date: 'اليوم',
    views: '920K مشاهدة',
    thumbnail: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=800&auto=format&fit=crop',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    goalsSummary: 'هالاند (9\') | ساكا (48\')'
  },
  {
    id: 'hl-3',
    title: 'صاروخية ميتروفيتش في مرمى النصر ومهارات الدون رونالدو',
    tournament: 'دوري روشن السعودي',
    duration: '08:30',
    date: 'اليوم',
    views: '2.1M مشاهدة',
    thumbnail: 'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?q=80&w=800&auto=format&fit=crop',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    goalsSummary: 'ميتروفيتش (18\')'
  },
  {
    id: 'hl-4',
    title: 'ريمونتادا إنتر ميلان التاريخية ضد يوفنتوس 3-2',
    tournament: 'الدوري الإيطالي',
    duration: '14:20',
    date: 'أمس',
    views: '650K مشاهدة',
    thumbnail: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?q=80&w=800&auto=format&fit=crop',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    goalsSummary: 'لاوتارو (15\')، تورام (53\')، باريلا (88\') | فلاهوفيتش (28\')، يلديز (71\')'
  }
];

export const INITIAL_CHAT_MESSAGES = [
  { id: 'c-1', user: 'أبو تميم المدريدي', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Madrilista', text: 'هلا مدريدد! فينيسيوس ومبابي ثنائية مرعبة اليوم 🔥🔥', time: '22:15', teamTag: 'RMA', likes: 14 },
  { id: 'c-2', user: 'كتلوني أصيل', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Barcelona', text: 'لامين يامال مو طبيعي بعمره هذا.. هدف خيالي!', time: '22:16', teamTag: 'BAR', likes: 21 },
  { id: 'c-3', user: 'عاشق الهلال', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Hilal', text: 'السيرفر رقم 1 شغال طيااارة بدون أي تقطيع شكراً IRAQI LIVE ❤️', time: '22:17', isSuperfan: true, likes: 9 },
  { id: 'c-4', user: 'يوسف الجزائري', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Youcef', text: 'شوالي مولع المباراة بالتعليق الله يا عيوني الله 🎙️', time: '22:18', likes: 18 },
  { id: 'c-5', user: 'كابتن ماجد', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Majed', text: 'يا حكم وين التسلل؟ اللقطة واضحة هدف صحيح 100%', time: '22:19', likes: 5 },
  { id: 'c-6', user: 'فخر العرب صلاح', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Salah', text: 'ننتظر ماتش ليفربول وتشيلسي بعد شوي.. سهرة كروية ممتعة', time: '22:20', likes: 11 },
];
