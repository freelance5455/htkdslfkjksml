export type Result='W'|'D'|'L';
export function nextRank(rank:number,championLosses:number,result:Result){
 if(rank>=18){if(result==='L'){const streak=championLosses+1;return streak>=3?{rank:17,championLosses:0}:{rank:18,championLosses:streak};}return{rank:18,championLosses:0};}
 if(result==='W')return{rank:Math.min(18,rank+1),championLosses:0};
 if(result==='L')return{rank:Math.max(0,rank-1),championLosses:0};
 return{rank,championLosses:0};
}
