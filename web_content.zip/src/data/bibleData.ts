import { BibleBookItem } from '../types';

export const OFFLINE_BIBLE_BOOKS: BibleBookItem[] = [
  {
    id: 'psalms',
    name: 'Psalms',
    testament: 'Old Testament',
    category: 'Poetry & Wisdom',
    totalChapters: 150,
    chapters: [
      {
        chapterNumber: 23,
        verses: [
          { verseNumber: 1, text: 'The LORD is my shepherd; I shall not want.', propheticNote: '528Hz Prophetic Alignment: Total divine provision and absence of lack.' },
          { verseNumber: 2, text: 'He maketh me to lie down in green pastures: he leadeth me beside the still waters.', propheticNote: 'Deep soaking peace enters the inner sanctuary.' },
          { verseNumber: 3, text: 'He restoreth my soul: he leadeth me in the paths of righteousness for his name\'s sake.' },
          { verseNumber: 4, text: 'Yea, though I walk through the valley of the shadow of death, I will fear no evil: for thou art with me; thy rod and thy staff they comfort me.', propheticNote: 'Spiritual warfare victory shield over every believer.' },
          { verseNumber: 5, text: 'Thou preparest a table before me in the presence of mine enemies: thou anointest my head with oil; my cup runneth over.', propheticNote: 'Prophetic overflow decree by Prophet JUHNKRIX.' },
          { verseNumber: 6, text: 'Surely goodness and mercy shall follow me all the days of my life: and I will dwell in the house of the LORD for ever.' }
        ]
      },
      {
        chapterNumber: 91,
        verses: [
          { verseNumber: 1, text: 'He that dwelleth in the secret place of the most High shall abide under the shadow of the Almighty.', propheticNote: 'Secret place activation in prophetic soaking worship.' },
          { verseNumber: 2, text: 'I will say of the LORD, He is my refuge and my fortress: my God; in him will I trust.' },
          { verseNumber: 3, text: 'Surely he shall deliver thee from the snare of the fowler, and from the noisome pestilence.' },
          { verseNumber: 4, text: 'He shall cover thee with his feathers, and under his wings shalt thou trust: his truth shall be thy shield and buckler.' },
          { verseNumber: 5, text: 'Thou shalt not be afraid for the terror by night; nor for the arrow that flieth by day;' },
          { verseNumber: 7, text: 'A thousand shall fall at thy side, and ten thousand at thy right hand; but it shall not come nigh thee.', propheticNote: 'Invincible spiritual immunity and divine protection decree.' },
          { verseNumber: 11, text: 'For he shall give his angels charge over thee, to keep thee in all thy ways.', propheticNote: 'Angelic ministry dispatch over your household.' },
          { verseNumber: 16, text: 'With long life will I satisfy him, and shew him my salvation.' }
        ]
      },
      {
        chapterNumber: 103,
        verses: [
          { verseNumber: 1, text: 'Bless the LORD, O my soul: and all that is within me, bless his holy name.' },
          { verseNumber: 2, text: 'Bless the LORD, O my soul, and forget not all his benefits:' },
          { verseNumber: 3, text: 'Who forgiveth all thine iniquities; who healeth all thy diseases;', propheticNote: 'Complete cellular healing frequency.' },
          { verseNumber: 4, text: 'Who redeemeth thy life from destruction; who crowneth thee with lovingkindness and tender mercies;' },
          { verseNumber: 5, text: 'Who satisfieth thy mouth with good things; so that thy youth is renewed like the eagle\'s.' }
        ]
      }
    ]
  },
  {
    id: 'proverbs',
    name: 'Proverbs',
    testament: 'Old Testament',
    category: 'Poetry & Wisdom',
    totalChapters: 31,
    chapters: [
      {
        chapterNumber: 3,
        verses: [
          { verseNumber: 5, text: 'Trust in the LORD with all thine heart; and lean not unto thine own understanding.', propheticNote: 'Prophetic wisdom key: Complete surrender of the intellectual will.' },
          { verseNumber: 6, text: 'In all thy ways acknowledge him, and he shall direct thy paths.' },
          { verseNumber: 9, text: 'Honour the LORD with thy substance, and with the firstfruits of all thine increase:', propheticNote: 'Covenant financial prosperity and seed multiplication.' },
          { verseNumber: 10, text: 'So shall thy barns be filled with plenty, and thy presses shall burst out with new wine.' }
        ]
      },
      {
        chapterNumber: 4,
        verses: [
          { verseNumber: 20, text: 'My son, attend to my words; incline thine ear unto my sayings.' },
          { verseNumber: 21, text: 'Let them not depart from thine eyes; keep them in the midst of thine heart.' },
          { verseNumber: 22, text: 'For they are life unto those that find them, and health to all their flesh.', propheticNote: 'The Word of God is divine medicine to your physical and spiritual body.' },
          { verseNumber: 23, text: 'Keep thy heart with all diligence; for out of it are the issues of life.' }
        ]
      }
    ]
  },
  {
    id: 'isaiah',
    name: 'Isaiah',
    testament: 'Old Testament',
    category: 'Prophets',
    totalChapters: 66,
    chapters: [
      {
        chapterNumber: 40,
        verses: [
          { verseNumber: 29, text: 'He giveth power to the faint; and to them that have no might he increaseth strength.' },
          { verseNumber: 31, text: 'But they that wait upon the LORD shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint.', propheticNote: 'Eagle anointing: Spiritual elevation beyond atmospheric turbulence.' }
        ]
      },
      {
        chapterNumber: 60,
        verses: [
          { verseNumber: 1, text: 'Arise, shine; for thy light is come, and the glory of the LORD is risen upon thee.', propheticNote: 'Prophetic awakening decree for JUHNKRIX MUSIKA global partners.' },
          { verseNumber: 2, text: 'For, behold, the darkness shall cover the earth, and gross darkness the people: but the LORD shall arise upon thee, and his glory shall be seen upon thee.' },
          { verseNumber: 3, text: 'And the Gentiles shall come to thy light, and kings to the brightness of thy rising.' },
          { verseNumber: 22, text: 'A little one shall become a thousand, and a small one a strong nation: I the LORD will hasten it in his time.' }
        ]
      }
    ]
  },
  {
    id: 'matthew',
    name: 'Matthew',
    testament: 'New Testament',
    category: 'Gospels',
    totalChapters: 28,
    chapters: [
      {
        chapterNumber: 6,
        verses: [
          { verseNumber: 9, text: 'After this manner therefore pray ye: Our Father which art in heaven, Hallowed be thy name.' },
          { verseNumber: 10, text: 'Thy kingdom come, Thy will be done in earth, as it is in heaven.' },
          { verseNumber: 11, text: 'Give us this day our daily bread.' },
          { verseNumber: 33, text: 'But seek ye first the kingdom of God, and his righteousness; and all these things shall be added unto you.', propheticNote: 'Kingdom priority unlocks supernatural wealth transfer.' }
        ]
      },
      {
        chapterNumber: 18,
        verses: [
          { verseNumber: 18, text: 'Verily I say unto you, Whatsoever ye shall bind on earth shall be bound in heaven: and whatsoever ye shall loose on earth shall be loosed in heaven.' },
          { verseNumber: 19, text: 'Again I say unto you, That if two of you shall agree on earth as touching any thing that they shall ask, it shall be done for them of my Father which is in heaven.', propheticNote: 'Global intercessory prayer agreement multiplier.' },
          { verseNumber: 20, text: 'For where two or three are gathered together in my name, there am I in the midst of them.' }
        ]
      }
    ]
  },
  {
    id: 'john',
    name: 'John',
    testament: 'New Testament',
    category: 'Gospels',
    totalChapters: 21,
    chapters: [
      {
        chapterNumber: 1,
        verses: [
          { verseNumber: 1, text: 'In the beginning was the Word, and the Word was with God, and the Word was God.' },
          { verseNumber: 4, text: 'In him was life; and the life was the light of men.' },
          { verseNumber: 5, text: 'And the light shineth in darkness; and the darkness comprehended it not.', propheticNote: 'The celestial light dispels all satanic oppression and demonic darkness.' },
          { verseNumber: 14, text: 'And the Word was made flesh, and dwelt among us, (and we beheld his glory, the glory as of the only begotten of the Father,) full of grace and truth.' }
        ]
      },
      {
        chapterNumber: 14,
        verses: [
          { verseNumber: 1, text: 'Let not your heart be troubled: ye believe in God, believe also in me.' },
          { verseNumber: 6, text: 'Jesus saith unto him, I am the way, the truth, and the life: no man cometh unto the Father, but by me.' },
          { verseNumber: 27, text: 'Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you. Let not your heart be troubled, neither let it be afraid.', propheticNote: 'Divine supernatural peace unshakeable by worldly economies.' }
        ]
      },
      {
        chapterNumber: 15,
        verses: [
          { verseNumber: 5, text: 'I am the vine, ye are the branches: He that abideth in me, and I in him, the same bringeth forth much fruit: for without me ye can do nothing.' },
          { verseNumber: 7, text: 'If ye abide in me, and my words abide in you, ye shall ask what ye will, and it shall be done unto you.', propheticNote: 'Answered prayer guarantee through word abiding.' }
        ]
      }
    ]
  },
  {
    id: 'romans',
    name: 'Romans',
    testament: 'New Testament',
    category: 'Epistles',
    totalChapters: 16,
    chapters: [
      {
        chapterNumber: 8,
        verses: [
          { verseNumber: 1, text: 'There is therefore now no condemnation to them which are in Christ Jesus, who walk not after the flesh, but after the Spirit.' },
          { verseNumber: 11, text: 'But if the Spirit of him that raised up Jesus from the dead dwell in you, he that raised up Christ from the dead shall also quicken your mortal bodies by his Spirit that dwelleth in you.', propheticNote: 'Resurrection life flowing into every cell and organ of your body.' },
          { verseNumber: 28, text: 'And we know that all things work together for good to them that love God, to them who are the called according to his purpose.', propheticNote: 'Prophetic orchestration: Even setbacks are working out your divine setup.' },
          { verseNumber: 31, text: 'What shall we then say to these things? If God be for us, who can be against us?' },
          { verseNumber: 37, text: 'Nay, in all these things we are more than conquerors through him that loved us.', propheticNote: 'Super-conqueror status through Christ Jesus!' }
        ]
      },
      {
        chapterNumber: 12,
        verses: [
          { verseNumber: 1, text: 'I beseech you therefore, brethren, by the mercies of God, that ye present your bodies a living sacrifice, holy, acceptable unto God, which is your reasonable service.' },
          { verseNumber: 2, text: 'And be not conformed to this world: but be ye transformed by the renewing of your mind, that ye may prove what is that good, and acceptable, and perfect, will of God.', propheticNote: 'Mind renewal through anointed soaking worship frequencies.' }
        ]
      }
    ]
  },
  {
    id: 'ephesians',
    name: 'Ephesians',
    testament: 'New Testament',
    category: 'Epistles',
    totalChapters: 6,
    chapters: [
      {
        chapterNumber: 3,
        verses: [
          { verseNumber: 16, text: 'That he would grant you, according to the riches of his glory, to be strengthened with might by his Spirit in the inner man;' },
          { verseNumber: 20, text: 'Now unto him that is able to do exceeding abundantly above all that we ask or think, according to the power that worketh in us,', propheticNote: 'Exceeding abundant breakthrough dimension activated!' },
          { verseNumber: 21, text: 'Unto him be glory in the church by Christ Jesus throughout all ages, world without end. Amen.' }
        ]
      },
      {
        chapterNumber: 6,
        verses: [
          { verseNumber: 10, text: 'Finally, my brethren, be strong in the Lord, and in the power of his might.' },
          { verseNumber: 11, text: 'Put on the whole armour of God, that ye may be able to stand against the wiles of the devil.' },
          { verseNumber: 16, text: 'Above all, taking the shield of faith, wherewith ye shall be able to quench all the fiery darts of the wicked.', propheticNote: 'Unbreakable shield of faith against witchcraft and curses.' },
          { verseNumber: 17, text: 'And take the helmet of salvation, and the sword of the Spirit, which is the word of God:' }
        ]
      }
    ]
  },
  {
    id: 'philippians',
    name: 'Philippians',
    testament: 'New Testament',
    category: 'Epistles',
    totalChapters: 4,
    chapters: [
      {
        chapterNumber: 4,
        verses: [
          { verseNumber: 4, text: 'Rejoice in the Lord alway: and again I say, Rejoice.' },
          { verseNumber: 6, text: 'Be careful for nothing; but in every thing by prayer and supplication with thanksgiving let your requests be made known unto God.', propheticNote: 'Instant anxiety eradication key.' },
          { verseNumber: 7, text: 'And the peace of God, which passeth all understanding, shall keep your hearts and minds through Christ Jesus.' },
          { verseNumber: 13, text: 'I can do all things through Christ which strengtheneth me.', propheticNote: 'Infinite supernatural capability through Christ.' },
          { verseNumber: 19, text: 'But my God shall supply all your need according to his riches in glory by Christ Jesus.', propheticNote: 'Covenant treasury supply: Heavenly banking account unlocked.' }
        ]
      }
    ]
  },
  {
    id: 'hebrews',
    name: 'Hebrews',
    testament: 'New Testament',
    category: 'Epistles',
    totalChapters: 13,
    chapters: [
      {
        chapterNumber: 11,
        verses: [
          { verseNumber: 1, text: 'Now faith is the substance of things hoped for, the evidence of things not seen.', propheticNote: 'Faith is the title deed to invisible spiritual realities.' },
          { verseNumber: 6, text: 'But without faith it is impossible to please him: for he that cometh to God must believe that he is, and that he is a rewarder of them that diligently seek him.' }
        ]
      },
      {
        chapterNumber: 12,
        verses: [
          { verseNumber: 1, text: 'Wherefore seeing we also are compassed about with so great a cloud of witnesses, let us lay aside every weight, and the sin which doth so easily beset us, and let us run with patience the race that is set before us,' },
          { verseNumber: 2, text: 'Looking unto Jesus the author and finisher of our faith; who for the joy that was set before him endured the cross, despising the shame, and is set down at the right hand of the throne of God.' }
        ]
      }
    ]
  },
  {
    id: 'revelation',
    name: 'Revelation',
    testament: 'New Testament',
    category: 'Prophecy',
    totalChapters: 22,
    chapters: [
      {
        chapterNumber: 1,
        verses: [
          { verseNumber: 8, text: 'I am Alpha and Omega, the beginning and the ending, saith the Lord, which is, and which was, and which is to come, the Almighty.' },
          { verseNumber: 18, text: 'I am he that liveth, and was dead; and, behold, I am alive for evermore, Amen; and have the keys of hell and of death.', propheticNote: 'Christ holds the sovereign master keys of authority.' }
        ]
      },
      {
        chapterNumber: 22,
        verses: [
          { verseNumber: 1, text: 'And he shewed me a pure river of water of life, clear as crystal, proceeding out of the throne of God and of the Lamb.' },
          { verseNumber: 2, text: 'In the midst of the street of it, and on either side of the river, was there the tree of life, which bare twelve manner of fruits, and yielded her fruit every month: and the leaves of the tree were for the healing of the nations.', propheticNote: 'River of living water soaking stream over the earth.' },
          { verseNumber: 20, text: 'He which testifieth these things saith, Surely I come quickly. Amen. Even so, come, Lord Jesus.' }
        ]
      }
    ]
  }
];

export const TRANSLATION_LABELS: Record<string, { name: string; tag: string; description: string }> = {
  KJV: { name: 'King James Version (KJV)', tag: 'Authorized Sacred', description: 'Classic poetic reverence and historical apostolic depth.' },
  NKJV: { name: 'New King James Version (NKJV)', tag: 'Modern Clarity', description: 'Updated contemporary wording preserving majesty.' },
  AMP: { name: 'Amplified Bible (AMP)', tag: 'Prophetic Nuance', description: 'Expanded word nuances revealing hidden Greek/Hebrew meanings.' },
  NIV: { name: 'New International Version (NIV)', tag: 'Universal Flow', description: 'Clear, modern reading experience for daily study.' },
  PROPHETIC: { name: 'JUHNKRIX Prophetic Edition', tag: 'Anointed Revelation', description: 'Includes Holy Ghost revelation notes and 528Hz soaking insights.' }
};
