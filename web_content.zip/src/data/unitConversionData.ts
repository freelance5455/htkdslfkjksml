export interface UnitDefinition {
  id: string;
  name: string;
  symbol: string;
  toBase: number | ((val: number) => number); // convert this unit to SI base
  fromBase: number | ((val: number) => number); // convert SI base to this unit
}

export interface UnitCategory {
  id: string;
  name: string;
  icon: string;
  baseUnit: string;
  units: UnitDefinition[];
}

export const UNIT_CATEGORIES: UnitCategory[] = [
  {
    id: 'length',
    name: 'Length',
    icon: 'Ruler',
    baseUnit: 'm',
    units: [
      { id: 'm', name: 'Meter', symbol: 'm', toBase: 1, fromBase: 1 },
      { id: 'km', name: 'Kilometer', symbol: 'km', toBase: 1000, fromBase: 0.001 },
      { id: 'cm', name: 'Centimeter', symbol: 'cm', toBase: 0.01, fromBase: 100 },
      { id: 'mm', name: 'Millimeter', symbol: 'mm', toBase: 0.001, fromBase: 1000 },
      { id: 'um', name: 'Micrometer', symbol: 'µm', toBase: 1e-6, fromBase: 1e6 },
      { id: 'nm', name: 'Nanometer', symbol: 'nm', toBase: 1e-9, fromBase: 1e9 },
      { id: 'in', name: 'Inch', symbol: 'in', toBase: 0.0254, fromBase: 39.3700787 },
      { id: 'ft', name: 'Foot', symbol: 'ft', toBase: 0.3048, fromBase: 3.2808399 },
      { id: 'yd', name: 'Yard', symbol: 'yd', toBase: 0.9144, fromBase: 1.0936133 },
      { id: 'mi', name: 'Mile', symbol: 'mi', toBase: 1609.344, fromBase: 0.000621371 },
      { id: 'nmi', name: 'Nautical Mile', symbol: 'nmi', toBase: 1852, fromBase: 1 / 1852 }
    ]
  },
  {
    id: 'mass',
    name: 'Mass',
    icon: 'Scale',
    baseUnit: 'kg',
    units: [
      { id: 'kg', name: 'Kilogram', symbol: 'kg', toBase: 1, fromBase: 1 },
      { id: 'g', name: 'Gram', symbol: 'g', toBase: 0.001, fromBase: 1000 },
      { id: 'mg', name: 'Milligram', symbol: 'mg', toBase: 1e-6, fromBase: 1e6 },
      { id: 't', name: 'Metric Tonne', symbol: 't', toBase: 1000, fromBase: 0.001 },
      { id: 'lb', name: 'Pound', symbol: 'lb', toBase: 0.45359237, fromBase: 2.20462262 },
      { id: 'oz', name: 'Ounce', symbol: 'oz', toBase: 0.028349523, fromBase: 35.27396 },
      { id: 'slug', name: 'Slug', symbol: 'slug', toBase: 14.5939, fromBase: 1 / 14.5939 }
    ]
  },
  {
    id: 'time',
    name: 'Time',
    icon: 'Clock',
    baseUnit: 's',
    units: [
      { id: 's', name: 'Second', symbol: 's', toBase: 1, fromBase: 1 },
      { id: 'ms', name: 'Millisecond', symbol: 'ms', toBase: 0.001, fromBase: 1000 },
      { id: 'us', name: 'Microsecond', symbol: 'µs', toBase: 1e-6, fromBase: 1e6 },
      { id: 'ns', name: 'Nanosecond', symbol: 'ns', toBase: 1e-9, fromBase: 1e9 },
      { id: 'min', name: 'Minute', symbol: 'min', toBase: 60, fromBase: 1 / 60 },
      { id: 'h', name: 'Hour', symbol: 'h', toBase: 3600, fromBase: 1 / 3600 },
      { id: 'd', name: 'Day', symbol: 'd', toBase: 86400, fromBase: 1 / 86400 },
      { id: 'wk', name: 'Week', symbol: 'wk', toBase: 604800, fromBase: 1 / 604800 },
      { id: 'yr', name: 'Julian Year', symbol: 'yr', toBase: 31557600, fromBase: 1 / 31557600 }
    ]
  },
  {
    id: 'speed',
    name: 'Speed',
    icon: 'Gauge',
    baseUnit: 'm/s',
    units: [
      { id: 'mps', name: 'Meters per second', symbol: 'm/s', toBase: 1, fromBase: 1 },
      { id: 'kph', name: 'Kilometers per hour', symbol: 'km/h', toBase: 1 / 3.6, fromBase: 3.6 },
      { id: 'mph', name: 'Miles per hour', symbol: 'mph', toBase: 0.44704, fromBase: 2.236936 },
      { id: 'knot', name: 'Knot', symbol: 'kn', toBase: 0.514444, fromBase: 1.94384 },
      { id: 'fps', name: 'Feet per second', symbol: 'ft/s', toBase: 0.3048, fromBase: 3.28084 },
      { id: 'mach', name: 'Mach (Standard sea level air)', symbol: 'M', toBase: 340.29, fromBase: 1 / 340.29 },
      { id: 'c', name: 'Speed of Light', symbol: 'c', toBase: 299792458, fromBase: 1 / 299792458 }
    ]
  },
  {
    id: 'area',
    name: 'Area',
    icon: 'Square',
    baseUnit: 'm²',
    units: [
      { id: 'sqm', name: 'Square Meter', symbol: 'm²', toBase: 1, fromBase: 1 },
      { id: 'sqkm', name: 'Square Kilometer', symbol: 'km²', toBase: 1e6, fromBase: 1e-6 },
      { id: 'sqcm', name: 'Square Centimeter', symbol: 'cm²', toBase: 0.0001, fromBase: 10000 },
      { id: 'sqmm', name: 'Square Millimeter', symbol: 'mm²', toBase: 1e-6, fromBase: 1e6 },
      { id: 'ha', name: 'Hectare', symbol: 'ha', toBase: 10000, fromBase: 0.0001 },
      { id: 'acre', name: 'Acre', symbol: 'ac', toBase: 4046.8564224, fromBase: 1 / 4046.8564224 },
      { id: 'sqft', name: 'Square Foot', symbol: 'ft²', toBase: 0.092903, fromBase: 10.7639 },
      { id: 'sqin', name: 'Square Inch', symbol: 'in²', toBase: 0.00064516, fromBase: 1550.003 }
    ]
  },
  {
    id: 'volume',
    name: 'Volume',
    icon: 'Box',
    baseUnit: 'm³',
    units: [
      { id: 'cum', name: 'Cubic Meter', symbol: 'm³', toBase: 1, fromBase: 1 },
      { id: 'l', name: 'Liter', symbol: 'L', toBase: 0.001, fromBase: 1000 },
      { id: 'ml', name: 'Milliliter', symbol: 'mL', toBase: 1e-6, fromBase: 1e6 },
      { id: 'cucm', name: 'Cubic Centimeter', symbol: 'cm³', toBase: 1e-6, fromBase: 1e6 },
      { id: 'gal_us', name: 'US Gallon', symbol: 'gal', toBase: 0.00378541, fromBase: 264.172 },
      { id: 'qt_us', name: 'US Quart', symbol: 'qt', toBase: 0.000946353, fromBase: 1056.69 },
      { id: 'cuft', name: 'Cubic Foot', symbol: 'ft³', toBase: 0.0283168, fromBase: 35.3147 },
      { id: 'cuin', name: 'Cubic Inch', symbol: 'in³', toBase: 1.6387e-5, fromBase: 61023.7 }
    ]
  },
  {
    id: 'temperature',
    name: 'Temperature',
    icon: 'Thermometer',
    baseUnit: 'K',
    units: [
      {
        id: 'c',
        name: 'Celsius',
        symbol: '°C',
        toBase: (c: number) => c + 273.15,
        fromBase: (k: number) => k - 273.15
      },
      {
        id: 'f',
        name: 'Fahrenheit',
        symbol: '°F',
        toBase: (f: number) => ((f - 32) * 5) / 9 + 273.15,
        fromBase: (k: number) => ((k - 273.15) * 9) / 5 + 32
      },
      {
        id: 'k',
        name: 'Kelvin',
        symbol: 'K',
        toBase: (k: number) => k,
        fromBase: (k: number) => k
      },
      {
        id: 'r',
        name: 'Rankine',
        symbol: '°R',
        toBase: (r: number) => (r * 5) / 9,
        fromBase: (k: number) => (k * 9) / 5
      }
    ]
  },
  {
    id: 'pressure',
    name: 'Pressure',
    icon: 'CircleDot',
    baseUnit: 'Pa',
    units: [
      { id: 'pa', name: 'Pascal', symbol: 'Pa', toBase: 1, fromBase: 1 },
      { id: 'kpa', name: 'Kilopascal', symbol: 'kPa', toBase: 1000, fromBase: 0.001 },
      { id: 'mpa', name: 'Megapascal', symbol: 'MPa', toBase: 1e6, fromBase: 1e-6 },
      { id: 'bar', name: 'Bar', symbol: 'bar', toBase: 100000, fromBase: 1e-5 },
      { id: 'mbar', name: 'Millibar', symbol: 'mbar', toBase: 100, fromBase: 0.01 },
      { id: 'atm', name: 'Standard Atmosphere', symbol: 'atm', toBase: 101325, fromBase: 1 / 101325 },
      { id: 'psi', name: 'Pounds per Square Inch', symbol: 'psi', toBase: 6894.757, fromBase: 1 / 6894.757 },
      { id: 'torr', name: 'Torr (mmHg)', symbol: 'Torr', toBase: 133.322, fromBase: 1 / 133.322 }
    ]
  },
  {
    id: 'energy',
    name: 'Energy',
    icon: 'Zap',
    baseUnit: 'J',
    units: [
      { id: 'j', name: 'Joule', symbol: 'J', toBase: 1, fromBase: 1 },
      { id: 'kj', name: 'Kilojoule', symbol: 'kJ', toBase: 1000, fromBase: 0.001 },
      { id: 'mj', name: 'Megajoule', symbol: 'MJ', toBase: 1e6, fromBase: 1e-6 },
      { id: 'cal', name: 'Gram Calorie', symbol: 'cal', toBase: 4.184, fromBase: 1 / 4.184 },
      { id: 'kcal', name: 'Kilocalorie (Food cal)', symbol: 'kcal', toBase: 4184, fromBase: 1 / 4184 },
      { id: 'wh', name: 'Watt-hour', symbol: 'Wh', toBase: 3600, fromBase: 1 / 3600 },
      { id: 'kwh', name: 'Kilowatt-hour', symbol: 'kWh', toBase: 3.6e6, fromBase: 1 / 3.6e6 },
      { id: 'btu', name: 'British Thermal Unit', symbol: 'BTU', toBase: 1055.056, fromBase: 1 / 1055.056 },
      { id: 'ev', name: 'Electronvolt', symbol: 'eV', toBase: 1.602176634e-19, fromBase: 1 / 1.602176634e-19 }
    ]
  },
  {
    id: 'power',
    name: 'Power',
    icon: 'Activity',
    baseUnit: 'W',
    units: [
      { id: 'w', name: 'Watt', symbol: 'W', toBase: 1, fromBase: 1 },
      { id: 'kw', name: 'Kilowatt', symbol: 'kW', toBase: 1000, fromBase: 0.001 },
      { id: 'mw', name: 'Megawatt', symbol: 'MW', toBase: 1e6, fromBase: 1e-6 },
      { id: 'hp', name: 'Horsepower (Mechanical)', symbol: 'hp', toBase: 745.69987, fromBase: 1 / 745.69987 },
      { id: 'btu_h', name: 'BTU per hour', symbol: 'BTU/h', toBase: 0.293071, fromBase: 3.41214 },
      { id: 'ftlb_s', name: 'Foot-pounds per second', symbol: 'ft·lb/s', toBase: 1.355818, fromBase: 1 / 1.355818 }
    ]
  },
  {
    id: 'force',
    name: 'Force',
    icon: 'Compass',
    baseUnit: 'N',
    units: [
      { id: 'n', name: 'Newton', symbol: 'N', toBase: 1, fromBase: 1 },
      { id: 'kn', name: 'Kilonewton', symbol: 'kN', toBase: 1000, fromBase: 0.001 },
      { id: 'mn', name: 'Meganewton', symbol: 'MN', toBase: 1e6, fromBase: 1e-6 },
      { id: 'dyn', name: 'Dyne', symbol: 'dyn', toBase: 1e-5, fromBase: 1e5 },
      { id: 'lbf', name: 'Pound-force', symbol: 'lbf', toBase: 4.448222, fromBase: 0.224809 },
      { id: 'kgf', name: 'Kilogram-force', symbol: 'kgf', toBase: 9.80665, fromBase: 1 / 9.80665 }
    ]
  }
];

export function convertUnits(
  val: number,
  category: UnitCategory,
  fromUnitId: string,
  toUnitId: string
): number {
  if (isNaN(val)) return NaN;
  if (fromUnitId === toUnitId) return val;

  const fromUnit = category.units.find((u) => u.id === fromUnitId);
  const toUnit = category.units.find((u) => u.id === toUnitId);
  if (!fromUnit || !toUnit) return NaN;

  // Convert to Base
  let baseVal: number;
  if (typeof fromUnit.toBase === 'function') {
    baseVal = fromUnit.toBase(val);
  } else {
    baseVal = val * fromUnit.toBase;
  }

  // Convert from Base
  let resultVal: number;
  if (typeof toUnit.fromBase === 'function') {
    resultVal = toUnit.fromBase(baseVal);
  } else {
    resultVal = baseVal * toUnit.fromBase;
  }

  return resultVal;
}
