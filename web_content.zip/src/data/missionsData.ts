import { Mission } from '../types/game';

export const MISSIONS_DATA: Mission[] = [
  {
    id: 1,
    title: {
      hinglish: 'Level 1: The TV Remote War (रिमोट का घमासान)',
      english: 'Level 1: The TV Remote War',
    },
    subtitle: {
      hinglish: 'Arav aur Akshhara ka remote jhagda suljhao!',
      english: 'Settle the remote battle between Arav & Akshhara!',
    },
    description: {
      hinglish: 'Akshhara aur Arav TV ke remote ke peeche lad rahe hain. Pehle Arav se baat karo, fir sofa ke aas-paas remote dhoondho aur dono ko shant karo!',
      english: 'Akshhara and Arav are arguing over the TV remote. Talk to Arav, search around the living room sofa to find the remote, and restore peace!',
    },
    location: 'Living Room',
    targetItems: ['remote'],
    totalObjectives: 2,
    introDialogue: [
      {
        speaker: 'akshhara',
        speakerName: { hinglish: 'Akshhara', english: 'Akshhara' },
        text: {
          hinglish: 'Arav! Remote mujhe do! Mera cartoon start ho gaya hai! Chhodo jaldi!',
          english: 'Arav! Give me the remote! My cartoon is starting right now! Let go!',
        },
        emotion: 'arguing',
      },
      {
        speaker: 'arav',
        speakerName: { hinglish: 'Arav', english: 'Arav' },
        text: {
          hinglish: 'Pehle maine pakda tha! Cricket ka last over baaki hai! Main nahi doonga!',
          english: 'I grabbed it first! It is the last over of the cricket match! No way!',
        },
        emotion: 'arguing',
      },
      {
        speaker: 'ayush',
        speakerName: { hinglish: 'Ayush', english: 'Ayush' },
        text: {
          hinglish: 'Bas, bas! Dono ladna band karo! Ab main iska solution nikalta hoon. Pehle pata lagata hoon remote gaya kahan!',
          english: 'Stop, stop! Both of you stop fighting! I will find a peaceful solution. First let me find where the remote ended up!',
        },
        emotion: 'thinking',
      },
      {
        speaker: 'anjeeta',
        speakerName: { hinglish: 'Mummy (Anjeeta)', english: 'Mom (Anjeeta)' },
        text: {
          hinglish: 'Bachcho, ladna band karo aur milkar kaam karo! Ayush beta, zara dekho sofa ke peeche gira hoga!',
          english: 'Kids, stop fighting and work together! Ayush dear, please check around the sofa, it probably slipped there!',
        },
        emotion: 'funny',
      },
    ],
    completeDialogue: [
      {
        speaker: 'ayush',
        speakerName: { hinglish: 'Ayush', english: 'Ayush' },
        text: {
          hinglish: 'Yeh lo remote mil gaya! Ab deal yeh hai: 10 minute cricket ka over, fir commercial breaks mein cartoon! Koi jhagda nahi!',
          english: 'Found the remote! Here is the deal: 10 minutes for cricket over, and during commercial breaks cartoon time! Deal?',
        },
        emotion: 'happy',
      },
      {
        speaker: 'arav',
        speakerName: { hinglish: 'Arav', english: 'Arav' },
        text: {
          hinglish: 'Super idea Bhaiya! Waise bhi Indian team jeetne wali hai!',
          english: 'Super idea big bro! Anyway Team India is about to win!',
        },
        emotion: 'happy',
      },
      {
        speaker: 'akshhara',
        speakerName: { hinglish: 'Akshhara', english: 'Akshhara' },
        text: {
          hinglish: 'Theek hai, sirf is baar maan rahi hoon! Thank you Ayush Bhaiya!',
          english: 'Fine, only agreeing this once! Thank you Ayush Bhaiya!',
        },
        emotion: 'funny',
      },
      {
        speaker: 'ripin',
        speakerName: { hinglish: 'Papa (Ripin)', english: 'Dad (Ripin)' },
        text: {
          hinglish: 'Shabash Ayush! Tumne diplomatic solution nikal liya. Mission 1 Complete!',
          english: 'Well done Ayush! You found a true diplomatic solution. Mission 1 Complete!',
        },
        emotion: 'proud',
      },
    ],
    cutsceneSummary: {
      hinglish: 'Ayush ne TV remote dhoondh kar Arav aur Akshhara ke beech samjhauta kara diya!',
      english: 'Ayush found the TV remote and brokered a peaceful treaty between the siblings!',
    },
  },

  {
    id: 2,
    title: {
      hinglish: 'Level 2: Kitchen Trouble (किचन की तलाश)',
      english: 'Level 2: Kitchen Trouble',
    },
    subtitle: {
      hinglish: 'Mummy ki special chai aur snacks ke ingredients dhoondho!',
      english: 'Find missing kitchen ingredients for Mom’s evening snacks!',
    },
    description: {
      hinglish: 'Mrs. Anjeeta sham ke liye garam samosa aur adrak wali chai bana rahi hain. Ghar mein bikhri 4 cheezein dhoondho: Masala Dabba, Belan, Adrak (Ginger), aur Doodh (Milk)!',
      english: 'Mrs. Anjeeta is making hot evening samosas and ginger tea. Find 4 missing kitchen items scattered around: Masala Dabba, Rolling Pin, Fresh Ginger, and Milk Jug!',
    },
    location: 'Kitchen & Dining',
    targetItems: ['masala_dabba', 'belan', 'ginger', 'milk_jug'],
    totalObjectives: 4,
    introDialogue: [
      {
        speaker: 'anjeeta',
        speakerName: { hinglish: 'Mummy (Anjeeta)', english: 'Mom (Anjeeta)' },
        text: {
          hinglish: 'Arre Ayush! Aaj main sabke liye special samose aur adrak wali kadak chai bana rahi hoon!',
          english: 'Oh Ayush! Today I am making special samosas and hot ginger chai for everyone!',
        },
        emotion: 'happy',
      },
      {
        speaker: 'anjeeta',
        speakerName: { hinglish: 'Mummy (Anjeeta)', english: 'Mom (Anjeeta)' },
        text: {
          hinglish: 'Lekin pata nahi Arav aur Akshhara ne khelte-khelte mera Masala Dabba, Belan, Adrak aur Doodh kahan chhipa diya! Meri madad karoge beta?',
          english: 'But while playing, Arav and Akshhara scattered my Spice Box, Rolling Pin, Ginger and Milk! Will you help me find them?',
        },
        emotion: 'thinking',
      },
      {
        speaker: 'ayush',
        speakerName: { hinglish: 'Ayush', english: 'Ayush' },
        text: {
          hinglish: 'Bilkul Mummy! Garam samoson ke liye toh main pura ghar chhan maarunga!',
          english: 'Of course Mom! For hot samosas, I will search every corner of the house!',
        },
        emotion: 'funny',
      },
    ],
    completeDialogue: [
      {
        speaker: 'anjeeta',
        speakerName: { hinglish: 'Mummy (Anjeeta)', english: 'Mom (Anjeeta)' },
        text: {
          hinglish: 'Wah mere sher bete! Saari cheezein mil gayin! Ab bas 15 minute mein swadisht samose taiyar!',
          english: 'Bravo my clever boy! You found all the ingredients! Hot delicious samosas in 15 minutes!',
        },
        emotion: 'happy',
      },
      {
        speaker: 'arav',
        speakerName: { hinglish: 'Arav', english: 'Arav' },
        text: {
          hinglish: 'Pehle 3 samose mere! Maine kitchen mein running practice ki thi!',
          english: 'First three samosas are mine! I practiced running in the kitchen!',
        },
        emotion: 'funny',
      },
      {
        speaker: 'akshhara',
        speakerName: { hinglish: 'Akshhara', english: 'Akshhara' },
        text: {
          hinglish: 'Nahi Arav! Pehle mujhe milenge, maine adrak chhipai thi!',
          english: 'No Arav! I get them first, I hid the ginger!',
        },
        emotion: 'arguing',
      },
    ],
    cutsceneSummary: {
      hinglish: 'Ayush ne kitchen ke saare ingredients dhoondh liye aur parivar ke liye snacks pakne lage!',
      english: 'Ayush gathered all ingredients and Mom is frying delicious golden samosas!',
    },
  },

  {
    id: 3,
    title: {
      hinglish: 'Level 3: Dad’s Challenge (पापा का चैलेंज)',
      english: 'Level 3: Dad’s Challenge',
    },
    subtitle: {
      hinglish: 'Mr. Ripin ka household challenge pura karo!',
      english: 'Complete Mr. Ripin’s household organization challenge!',
    },
    description: {
      hinglish: 'Papa apna chashma, akhbar aur office diary dhoondh rahe hain. Saath hi living room aur garden mein bikhre 2 toy piles saaf karke discipline dikhao!',
      english: 'Dad needs his reading glasses, morning newspaper, and office diary. Plus tidy 2 scattered toy piles in the house to prove top family discipline!',
    },
    location: 'Study & Garden',
    targetItems: ['glasses', 'newspaper', 'diary', 'toys_tidy_1', 'toys_tidy_2'],
    totalObjectives: 5,
    introDialogue: [
      {
        speaker: 'ripin',
        speakerName: { hinglish: 'Papa (Ripin)', english: 'Dad (Ripin)' },
        text: {
          hinglish: 'Ayush, suno! Aaj tumhari ek special mission hai! Family Discipline Challenge!',
          english: 'Ayush, listen! Today you have a special mission: The Family Discipline Challenge!',
        },
        emotion: 'proud',
      },
      {
        speaker: 'ripin',
        speakerName: { hinglish: 'Papa (Ripin)', english: 'Dad (Ripin)' },
        text: {
          hinglish: 'Mera chashma, subah ka akhbaar, aur diary kahan hain? Aur garden aur study mein Arav-Akshhara ke khilone bikhre hain. Pura ghar ekdum chamka do!',
          english: 'Where are my glasses, morning newspaper, and diary? Plus Arav and Akshhara left toys all over. Get the house in top order!',
        },
        emotion: 'thinking',
      },
      {
        speaker: 'ayush',
        speakerName: { hinglish: 'Ayush', english: 'Ayush' },
        text: {
          hinglish: 'Don’t worry Papa, Ayush is on duty! 5 minute mein sab apni jagah par hoga!',
          english: 'Don’t worry Dad, Ayush is on duty! Everything will be in its proper place in 5 minutes!',
        },
        emotion: 'happy',
      },
    ],
    completeDialogue: [
      {
        speaker: 'ripin',
        speakerName: { hinglish: 'Papa (Ripin)', english: 'Dad (Ripin)' },
        text: {
          hinglish: 'Shabash Ayush! Akhbaar, chashma aur diary mil gaye, aur ghar ekdum clean! You are a true champion son!',
          english: 'Splendid Ayush! Got my newspaper, glasses and diary, and the house is spotless! You are a true champion son!',
        },
        emotion: 'proud',
      },
      {
        speaker: 'anjeeta',
        speakerName: { hinglish: 'Mummy (Anjeeta)', english: 'Mom (Anjeeta)' },
        text: {
          hinglish: 'Sachi Ripin ji, Ayush jaisa samajhdaar beta sabko mile!',
          english: 'Truly dear, every home needs a smart and helpful boy like Ayush!',
        },
        emotion: 'happy',
      },
    ],
    cutsceneSummary: {
      hinglish: 'Ayush ne Papa ka challenge pura kiya aur ghar ko chamka kar sabka dil jeet liya!',
      english: 'Ayush completed Dad’s challenge and earned top marks for family discipline!',
    },
  },

  {
    id: 4,
    title: {
      hinglish: 'Level 4: The Great Sibling Argument (भाई-बहन का महायुद्ध)',
      english: 'Level 4: The Great Sibling Argument',
    },
    subtitle: {
      hinglish: 'Courtyard mein Arav aur Akshhara ka final faisla karo!',
      english: 'Judge the courtyard face-off and make both siblings laugh!',
    },
    description: {
      hinglish: 'Garden ke jhoola (swing) aur aakhri Mango Kulfi ke liye Arav aur Akshhara mein bahas chhid gayi hai! Ayush bankar sahi comic dialogue chuno aur dono ko gale milwao!',
      english: 'Arav and Akshhara are clashing in the courtyard garden over the jhoola swing and the last Mango Kulfi! Choose funny, peaceful dialogues to resolve it!',
    },
    location: 'Courtyard & Garden',
    targetItems: ['dialogue_settled'],
    totalObjectives: 1,
    introDialogue: [
      {
        speaker: 'akshhara',
        speakerName: { hinglish: 'Akshhara', english: 'Akshhara' },
        text: {
          hinglish: 'Yeh Jhoola mera hai! Aur fridge mein rakhi Mango Kulfi bhi meri hai! Arav ne kal meri drawing kharab ki thi!',
          english: 'This swing is mine! And the Mango Kulfi in the fridge is mine too! Arav messed up my drawing yesterday!',
        },
        emotion: 'arguing',
      },
      {
        speaker: 'arav',
        speakerName: { hinglish: 'Arav', english: 'Arav' },
        text: {
          hinglish: 'Drawing nahi, wo toh abstract art tha! Aur Kulfi par pehle mera right hai kyunki maine school mein 1st prize jeeta tha!',
          english: 'It wasn’t messed up, that was abstract art! And I deserve the kulfi because I won 1st prize at school!',
        },
        emotion: 'arguing',
      },
      {
        speaker: 'ayush',
        speakerName: { hinglish: 'Ayush', english: 'Ayush' },
        text: {
          hinglish: 'Arre baap re! Courtyard mein World War 3 shuru ho gaya! Chalo dono ko funny tareeke se shant karata hoon.',
          english: 'Oh boy! World War 3 in the courtyard! Time to use wit and humor to bring peace.',
        },
        emotion: 'thinking',
        choices: [
          {
            id: 'c1',
            label: {
              hinglish: 'Idea 1: "Kulfi main aadhi-aadhi kaat deta hoon, aur jhoola dono saath jhulenge!"',
              english: 'Option 1: "I will cut the Kulfi in half, and you both share the swing together!"',
            },
            nextIndex: 3,
            points: 100,
            isCorrect: true,
            feedback: {
              hinglish: 'Dono muskurane lage! Fair share rule hamesha kaam karta hai!',
              english: 'Both started smiling! The fair share rule always works!',
            },
          },
          {
            id: 'c2',
            label: {
              hinglish: 'Idea 2: "Kulfi main akele kha jaata hoon taaki ladne ka karan hi khatam ho jaye!"',
              english: 'Option 2: "I will just eat the Kulfi myself so the reason to fight disappears!"',
            },
            nextIndex: 4,
            points: 50,
            isCorrect: false,
            feedback: {
              hinglish: 'Dono ne milkar Ayush ko ghoora! Haha, lekin hasi chhoot gayi!',
              english: 'Both glared at Ayush together! Haha, but it made them laugh!',
            },
          },
        ],
      },
      {
        speaker: 'arav',
        speakerName: { hinglish: 'Arav', english: 'Arav' },
        text: {
          hinglish: 'Wah Bhaiya! Half-half kulfi aur swing par race! Yeh deal mast hai!',
          english: 'Awesome Bhaiya! Half-half kulfi and tandem swing! That is a great deal!',
        },
        emotion: 'happy',
      },
      {
        speaker: 'akshhara',
        speakerName: { hinglish: 'Akshhara', english: 'Akshhara' },
        text: {
          hinglish: 'Haha Ayush Bhaiya, aap bhi na! Chalo theek hai Arav, pehle tum jhul lo, fir main!',
          english: 'Haha Ayush Bhaiya, you are funny! Alright Arav, you swing first, then me!',
        },
        emotion: 'happy',
      },
    ],
    completeDialogue: [
      {
        speaker: 'ayush',
        speakerName: { hinglish: 'Ayush', english: 'Ayush' },
        text: {
          hinglish: 'Dekha! Hassi mazaak se har problem solve ho sakti hai! Ab dono gale milo!',
          english: 'See! Every problem can be solved with a smile and a hug! Now hug it out!',
        },
        emotion: 'happy',
      },
      {
        speaker: 'arav',
        speakerName: { hinglish: 'Arav', english: 'Arav' },
        text: {
          hinglish: 'Sorry Akshhara! Kal main tumhari drawing board frame karwaunga!',
          english: 'Sorry Akshhara! Tomorrow I will get your drawing framed!',
        },
        emotion: 'happy',
      },
      {
        speaker: 'akshhara',
        speakerName: { hinglish: 'Akshhara', english: 'Akshhara' },
        text: {
          hinglish: 'Aur main tumhare liye drawing banaungi! Love you Arav!',
          english: 'And I will draw a super portrait for you! Love you Arav!',
        },
        emotion: 'happy',
      },
    ],
    cutsceneSummary: {
      hinglish: 'Arav aur Akshhara ne ladna band kiya aur ek doosre ko gale laga liya!',
      english: 'Arav and Akshhara made peace and shared the swing with big smiles!',
    },
  },

  {
    id: 5,
    title: {
      hinglish: 'Level 5: Family Treasure Hunt (परिवार का खज़ाना)',
      english: 'Level 5: Family Treasure Hunt',
    },
    subtitle: {
      hinglish: 'Ghar ke 3 clues follow karke rooftop par khazana dhoondho!',
      english: 'Follow 3 secret clues around the house to uncover the grand heirloom!',
    },
    description: {
      hinglish: 'Papa aur Mummy ne ghar mein 3 secret clues chhipaye hain: Pehla Garden Tulsi plant ke paas, Doosra Living room photo ke paas, Teesra Rooftop Terrace par! Dhoondho aur parivar ka golden treasure unlock karo!',
      english: 'Dad and Mom have hidden 3 secret riddles: 1st by the garden Tulsi planter, 2nd by the Living Room family portrait, and 3rd on the Rooftop Terrace! Find them all to unlock the family treasure!',
    },
    location: 'Garden, Living Room & Rooftop Terrace',
    targetItems: ['clue_tulsi', 'clue_portrait', 'clue_rooftop', 'treasure_chest'],
    totalObjectives: 4,
    introDialogue: [
      {
        speaker: 'ripin',
        speakerName: { hinglish: 'Papa (Ripin)', english: 'Dad (Ripin)' },
        text: {
          hinglish: 'Dhyan se suno bacho! Aaj hamari family ka annual Grand Treasure Hunt shuru hota hai!',
          english: 'Listen up kids! Today begins our family’s annual Grand Treasure Hunt!',
        },
        emotion: 'proud',
      },
      {
        speaker: 'anjeeta',
        speakerName: { hinglish: 'Mummy (Anjeeta)', english: 'Mom (Anjeeta)' },
        text: {
          hinglish: 'Humne ghar mein 3 clues chhipaye hain. Pehla clue garden ke pavitra Tulsi paudhe ke paas hai! Clues padh kar aage badho!',
          english: 'We hid 3 clues around the house. The first clue is near the sacred Tulsi plant in the garden! Read the clues to find the chest!',
        },
        emotion: 'happy',
      },
      {
        speaker: 'ayush',
        speakerName: { hinglish: 'Ayush', english: 'Ayush' },
        text: {
          hinglish: 'Chalo Arav aur Akshhara, milkar clues dhoondhte hain! Team Ayush ready hai!',
          english: 'Let’s go Arav and Akshhara, we will find the clues as a team! Team Ayush is ready!',
        },
        emotion: 'happy',
      },
    ],
    completeDialogue: [
      {
        speaker: 'ayush',
        speakerName: { hinglish: 'Ayush', english: 'Ayush' },
        text: {
          hinglish: 'Rooftop par golden box mil gaya! Wow, isme hamari bachpan ki photos aur ek golden family trophy hai!',
          english: 'Found the golden chest on the rooftop! Wow, it has our childhood family album and a golden trophy!',
        },
        emotion: 'proud',
      },
      {
        speaker: 'ripin',
        speakerName: { hinglish: 'Papa (Ripin)', english: 'Dad (Ripin)' },
        text: {
          hinglish: 'Yeh trophy hamare ghar ke best beta aur mediator Ayush ke liye hai! Aur sabse bada khazana hamara pyar aur ekta hai!',
          english: 'This trophy is for our best son and mediator Ayush! And our greatest treasure is our love and family unity!',
        },
        emotion: 'proud',
      },
      {
        speaker: 'anjeeta',
        speakerName: { hinglish: 'Mummy (Anjeeta)', english: 'Mom (Anjeeta)' },
        text: {
          hinglish: 'Chalo sab milkar photo khinchwate hain aur nacho! Ayush Family Adventure Victory!',
          english: 'Let us all take a grand family picture and dance! Ayush Family Adventure Victory!',
        },
        emotion: 'happy',
      },
      {
        speaker: 'arav',
        speakerName: { hinglish: 'Arav', english: 'Arav' },
        text: {
          hinglish: 'Bhangra time! Hip hip hurray!',
          english: 'Bhangra dance time! Hip hip hurray!',
        },
        emotion: 'funny',
      },
      {
        speaker: 'akshhara',
        speakerName: { hinglish: 'Akshhara', english: 'Akshhara' },
        text: {
          hinglish: 'We are the best family in the world!',
          english: 'We are the best family in the world!',
        },
        emotion: 'happy',
      },
    ],
    cutsceneSummary: {
      hinglish: 'Poora parivar rooftop par khazana paakar ek sath jashn mana raha hai! Ayush ne sabka dil jeet liya!',
      english: 'The whole family celebrates together on the rooftop! Ayush brought unity, joy and happiness to all!',
    },
  },
];
