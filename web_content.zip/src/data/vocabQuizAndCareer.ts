import { BiText } from './types';

export interface VocabWord {
  id: string;
  english: string;
  arabic: string;
  arabicPronunciation: string;
  hindi: string;
  hinglish: string;
  category: 'Pipes & Fittings' | 'Tools' | 'Fixtures' | 'Site Commands';
}

export interface InterviewQA {
  id: string;
  category: 'Dubai / Gulf Trade Test' | 'Technical & Drawings' | 'Field Troubleshooting';
  question: BiText;
  answer: BiText;
}

export interface QuizQuestion {
  id: string;
  topic: string;
  question: BiText;
  options: BiText[];
  correctIndex: number;
  explanation: BiText;
}

export interface BoqTemplateItem {
  id: string;
  item: BiText;
  unit: string;
  qtyPerBathroom: number;
  qtyPerKitchen: number;
  approxRateAed: number;
  approxRateInr: number;
}

export const VOCAB_WORDS: VocabWord[] = [
  { id: 'v1', english: 'Pipe', arabic: 'ماسورة', arabicPronunciation: 'Masoora', hindi: 'पाइप / नली', hinglish: 'Pipe', category: 'Pipes & Fittings' },
  { id: 'v2', english: 'Elbow (90°)', arabic: 'كوع', arabicPronunciation: "Koo'a", hindi: 'एल्बो (मोड़)', hinglish: 'Elbow', category: 'Pipes & Fittings' },
  { id: 'v3', english: 'Tee Fitting', arabic: 'تي', arabicPronunciation: 'Tee / Musallas', hindi: 'टी फिटिंग', hinglish: 'Tee', category: 'Pipes & Fittings' },
  { id: 'v4', english: 'Socket / Coupler', arabic: 'جلبة', arabicPronunciation: 'Jalba', hindi: 'सॉकेट / कपलर', hinglish: 'Socket', category: 'Pipes & Fittings' },
  { id: 'v5', english: 'Reducer', arabic: 'نقاص', arabicPronunciation: 'Naqqas', hindi: 'रिड्यूसर (छोटा-बड़ा जोड़)', hinglish: 'Reducer', category: 'Pipes & Fittings' },
  { id: 'v6', english: 'Union', arabic: 'لاكور / يونيون', arabicPronunciation: 'Lakor / Union', hindi: 'यूनियन (खुलने वाला जोड़)', hinglish: 'Union', category: 'Pipes & Fittings' },
  { id: 'v7', english: 'Valve / Stop Cock', arabic: 'محبس', arabicPronunciation: 'Mahbas', hindi: 'वॉल्व (पानी रोकने का)', hinglish: 'Valve', category: 'Pipes & Fittings' },
  { id: 'v8', english: 'Check Valve (NRV)', arabic: 'شيك بلف / رداد', arabicPronunciation: 'Check Balf / Raddad', hindi: 'वन-वे वॉल्व (NRV)', hinglish: 'NRV', category: 'Pipes & Fittings' },
  { id: 'v9', english: 'Trap / Siphon', arabic: 'سيفون / كوع ريحة', arabicPronunciation: 'Sifon / Kooa Reeha', hindi: 'ट्रैप (बदबू रोकने वाला)', hinglish: 'Trap', category: 'Pipes & Fittings' },
  { id: 'v10', english: 'Nipple', arabic: 'نبل', arabicPronunciation: 'Nibal', hindi: 'निप्पल (दोनों तरफ चूड़ी)', hinglish: 'Nipple', category: 'Pipes & Fittings' },
  { id: 'v11', english: 'End Cap / Plug', arabic: 'طبة', arabicPronunciation: 'Tabba', hindi: 'एंड कैप / डमी प्लग', hinglish: 'Plug / Cap', category: 'Pipes & Fittings' },
  { id: 'v12', english: 'Pipe Clamp', arabic: 'قفيز / كلامب', arabicPronunciation: 'Qafeez / Clamp', hindi: 'पाइप क्लैंप', hinglish: 'Clamp', category: 'Pipes & Fittings' },
  { id: 'v13', english: 'Glue / Solvent Cement', arabic: 'غراء', arabicPronunciation: 'Ghira', hindi: 'सॉल्वेंट ग्लू (पेस्ट)', hinglish: 'Glue', category: 'Pipes & Fittings' },
  { id: 'v14', english: 'Teflon Tape', arabic: 'تفلون', arabicPronunciation: 'Teflon', hindi: 'टेफ्लॉन टेप', hinglish: 'Teflon Tape', category: 'Pipes & Fittings' },

  { id: 'v15', english: 'Pipe Wrench', arabic: 'مفتاح إنجليزي / مفتاح مواسير', arabicPronunciation: 'Miftah Mawaseer', hindi: 'पाइप रिंच', hinglish: 'Pipe Wrench', category: 'Tools' },
  { id: 'v16', english: 'Adjustable Spanner', arabic: 'مفتاح فرنساوي', arabicPronunciation: 'Miftah Faransawi', hindi: 'एडजस्टेबल पाना', hinglish: 'Slide Wrench', category: 'Tools' },
  { id: 'v17', english: 'PPR Welding Machine', arabic: 'ماكينة لحام حراري', arabicPronunciation: 'Makina Liham Harari', hindi: 'PPR हीटर मशीन', hinglish: 'Heater Machine', category: 'Tools' },
  { id: 'v18', english: 'Spirit Level', arabic: 'ميزان مياه', arabicPronunciation: 'Mizan Maya', hindi: 'स्पिरिट लेवल', hinglish: 'Level Scale', category: 'Tools' },
  { id: 'v19', english: 'Measuring Tape', arabic: 'متر', arabicPronunciation: 'Mitr', hindi: 'इंच टेप / मीटर', hinglish: 'Tape', category: 'Tools' },
  { id: 'v20', english: 'Pipe Cutter', arabic: 'مقص مواسير', arabicPronunciation: 'Maqass Mawaseer', hindi: 'पाइप कटर', hinglish: 'Cutter', category: 'Tools' },
  { id: 'v21', english: 'Grinder / Wall Chaser', arabic: 'صاروخ', arabicPronunciation: 'Sarookh', hindi: 'ग्राइंडर / कटर मशीन', hinglish: 'Grinder', category: 'Tools' },
  { id: 'v22', english: 'Drill Machine', arabic: 'شنيور / دريل', arabicPronunciation: 'Shanyoor / Drill', hindi: 'ड्रिल मशीन', hinglish: 'Drill', category: 'Tools' },
  { id: 'v23', english: 'Pressure Test Pump', arabic: 'ماكينة كبس / مضخة فحص', arabicPronunciation: 'Makina Kabs', hindi: 'प्रेशर टेस्ट पंप', hinglish: 'Test Pump', category: 'Tools' },

  { id: 'v24', english: 'Bathroom / Toilet', arabic: 'حمام', arabicPronunciation: 'Hammam', hindi: 'बाथरूम / शौचालय', hinglish: 'Bathroom', category: 'Fixtures' },
  { id: 'v25', english: 'Wash Basin', arabic: 'مغسلة', arabicPronunciation: 'Maghsala', hindi: 'वॉश बेसिन', hinglish: 'Basin', category: 'Fixtures' },
  { id: 'v26', english: 'WC / Toilet Seat', arabic: 'كرسي حمام / تواليت', arabicPronunciation: 'Kursi Hammam', hindi: 'टॉयलेट सीट (WC)', hinglish: 'Toilet Seat', category: 'Fixtures' },
  { id: 'v27', english: 'Kitchen Sink', arabic: 'مجلى مطبخ', arabicPronunciation: 'Majla Matbakh', hindi: 'किचन सिंक', hinglish: 'Kitchen Sink', category: 'Fixtures' },
  { id: 'v28', english: 'Mixer Tap', arabic: 'خلاط', arabicPronunciation: 'Khallat', hindi: 'मिक्सर नल', hinglish: 'Mixer', category: 'Fixtures' },
  { id: 'v29', english: 'Bidet Spray (Shattaf)', arabic: 'شطاف', arabicPronunciation: 'Shattaf', hindi: 'जेट स्प्रे / मुस्लिम शावर', hinglish: 'Shattaf / Jet Spray', category: 'Fixtures' },
  { id: 'v30', english: 'Shower', arabic: 'دش', arabicPronunciation: 'Dush', hindi: 'शावर (फव्वारा)', hinglish: 'Shower', category: 'Fixtures' },
  { id: 'v31', english: 'Water Heater (Geyser)', arabic: 'سخان مياه', arabicPronunciation: 'Sakhkhan Maya', hindi: 'वाटर हीटर (गीजर)', hinglish: 'Geyser', category: 'Fixtures' },
  { id: 'v32', english: 'Water Tank', arabic: 'خزان مياه', arabicPronunciation: 'Khazzan Maya', hindi: 'पानी की टंकी', hinglish: 'Water Tank', category: 'Fixtures' },
  { id: 'v33', english: 'Water Pump', arabic: 'مضخة / طلمبة / دينامو', arabicPronunciation: 'Madakha / Dinamu', hindi: 'पानी का पंप / मोटर', hinglish: 'Motor / Pump', category: 'Fixtures' },
  { id: 'v34', english: 'Floor Drain', arabic: 'صفاية / بلاعة', arabicPronunciation: 'Saffaya / Balla-a', hindi: 'फ्लोर ट्रैप जाली', hinglish: 'Floor Drain', category: 'Fixtures' },

  { id: 'v35', english: 'Water Leak', arabic: 'تهريب مياه', arabicPronunciation: 'Tahreeb Maya', hindi: 'पानी की लीकेज', hinglish: 'Leakage', category: 'Site Commands' },
  { id: 'v36', english: 'Pressure Test', arabic: 'كبس / فحص ضغط', arabicPronunciation: 'Kabs / Fahs Daght', hindi: 'प्रेशर टेस्टिंग', hinglish: 'Pressure Test', category: 'Site Commands' },
  { id: 'v37', english: 'Drainage Slope', arabic: 'ميول / ميل', arabicPronunciation: 'Muyool / Meel', hindi: 'पाइप का ढलान (स्लोप)', hinglish: 'Slope', category: 'Site Commands' },
  { id: 'v38', english: 'Blocked / Clogged', arabic: 'مسدود', arabicPronunciation: 'Masdood', hindi: 'जाम / चोक होना', hinglish: 'Block / Choke', category: 'Site Commands' },
  { id: 'v39', english: 'Hot Water', arabic: 'مياه حارة', arabicPronunciation: 'Maya Harra', hindi: 'गर्म पानी', hinglish: 'Garam Pani', category: 'Site Commands' },
  { id: 'v40', english: 'Cold Water', arabic: 'مياه باردة', arabicPronunciation: 'Maya Barida', hindi: 'ठंडा पानी', hinglish: 'Thanda Pani', category: 'Site Commands' },
  { id: 'v41', english: 'Close the Water', arabic: 'سكر المياه', arabicPronunciation: 'Sakkar Al-Maya', hindi: 'पानी बंद करो', hinglish: 'Pani Band Karo', category: 'Site Commands' },
  { id: 'v42', english: 'Open the Water', arabic: 'افتح المياه', arabicPronunciation: 'Iftah Al-Maya', hindi: 'पानी चालू करो', hinglish: 'Pani Kholo', category: 'Site Commands' },
  { id: 'v43', english: 'Drawing / Blueprint', arabic: 'مخطط', arabicPronunciation: 'Mukhattat', hindi: 'नक्शा / ड्रॉइंग', hinglish: 'Drawing', category: 'Site Commands' },
  { id: 'v44', english: 'Inspection / Engineer Check', arabic: 'تفتيش / استلام', arabicPronunciation: 'Tafteesh / Istilam', hindi: 'इंजीनियर इंस्पेक्शन', hinglish: 'Inspection', category: 'Site Commands' },
];

export const INTERVIEW_QAS: InterviewQA[] = [
  {
    id: 'iq1',
    category: 'Dubai / Gulf Trade Test',
    question: {
      en: 'What is the welding temperature and heating time for 20mm and 25mm PPR pipes?',
      hi: '20mm और 25mm PPR पाइप के लिए वेल्डिंग तापमान और गर्म करने का समय कितना होता है?',
    },
    answer: {
      en: 'Welding machine temperature must be 260°C. Heating time is 5 seconds for 20mm pipe (14mm depth) and 7 seconds for 25mm pipe (16mm depth), with 4 seconds joining hold time.',
      hi: 'वेल्डिंग मशीन का तापमान 260°C होना चाहिए। 20mm पाइप को 5 सेकंड (14mm गहराई) और 25mm पाइप को 7 सेकंड (16mm गहराई) गर्म करके 4 सेकंड सीधा दबाकर रखें।',
    },
  },
  {
    id: 'iq2',
    category: 'Dubai / Gulf Trade Test',
    question: {
      en: 'At what pressure and duration is a domestic water supply line tested on Dubai sites?',
      hi: 'दुबई साइट्स पर पानी की सप्लाई लाइन का प्रेशर टेस्ट कितने Bar पर और कितनी देर किया जाता है?',
    },
    answer: {
      en: 'Typically at 10 Bar (or 1.5 times the working pressure, whichever is higher) for 2 to 4 hours (or 24 hours per project specs) with zero pressure drop.',
      hi: 'आमतौर पर 10 Bar (या वर्किंग प्रेशर का 1.5 गुना) पर 2 से 4 घंटे (या 24 घंटे) के लिए टेस्ट किया जाता है और प्रेशर बिल्कुल गिरना नहीं चाहिए।',
    },
  },
  {
    id: 'iq3',
    category: 'Technical & Drawings',
    question: {
      en: 'What is the difference between a P-Trap, S-Trap, and Floor Trap?',
      hi: 'P-Trap, S-Trap और Floor Trap में क्या अंतर है?',
    },
    answer: {
      en: 'P-Trap exits horizontally into a wall; S-Trap exits vertically downward into the floor (rarely allowed in modern codes due to self-siphoning); Floor Trap collects bathroom floor and side basin/shower waste with a 50mm water seal.',
      hi: 'P-Trap का आउटलेट दीवार की तरफ सीधा निकलता है; S-Trap नीचे फर्श में जाता है; और Floor Trap बाथरूम फर्श व बेसिन/शावर के पानी को 50mm वाटर-सील से रोककर बाहर निकालता है।',
    },
  },
  {
    id: 'iq4',
    category: 'Technical & Drawings',
    question: {
      en: 'What is the standard slope for 50mm, 75mm, and 110mm drainage pipes?',
      hi: '50mm, 75mm और 110mm ड्रेनेज पाइप का सही ढलान (Slope) कितना होता है?',
    },
    answer: {
      en: '50mm waste pipe: 1:40 to 1:50 (20–25mm drop per meter). 75mm pipe: 1:60 to 1:80. 110mm soil pipe: 1:80 to 1:100 (10–12.5mm drop per meter).',
      hi: '50mm पाइप में 1:40 से 1:50 (प्रति मीटर 20–25mm ढलान), 75mm में 1:60, और 110mm टॉयलेट पाइप में 1:80 से 1:100 (प्रति मीटर 10–12.5mm ढलान) रखा जाता है।',
    },
  },
  {
    id: 'iq5',
    category: 'Technical & Drawings',
    question: {
      en: 'How do you calculate a 45-degree pipe offset?',
      hi: '45-डिग्री पाइप ऑफसेट की लंबाई कैसे निकाली जाती है?',
    },
    answer: {
      en: 'Multiply the center-to-center offset distance by 1.414 (√2). Then subtract the socket insertion allowances of both 45° elbows to get the exact cut pipe length.',
      hi: 'दोनों पाइप लाइनों के बीच की दूरी (Offset) को 1.414 से गुणा करें। फिर दोनों 45° एल्बो के अंदर जाने वाली गहराई घटाकर पाइप काटें।',
    },
  },
  {
    id: 'iq6',
    category: 'Field Troubleshooting',
    question: {
      en: 'Why must a Non-Return Valve (NRV) and Pressure Relief Valve be installed on a water heater or booster pump?',
      hi: 'वाटर हीटर या बूस्टर पंप पर NRV और सेफ्टी रिलीफ वॉल्व लगाना क्यों जरूरी है?',
    },
    answer: {
      en: 'NRV prevents hot water or pressurized discharge from flowing backward. The Safety Relief Valve releases excess expansion pressure (above 6–8 Bar) so the tank never bursts.',
      hi: 'NRV पानी को वापस पीछे आने से रोकता है, और सेफ्टी रिलीफ वॉल्व ज्यादा प्रेशर या भाप बनने पर पानी बाहर निकालकर टैंक फटने से बचाता है।',
    },
  },
  {
    id: 'iq7',
    category: 'Technical & Drawings',
    question: {
      en: 'Which side should Hot and Cold water outlets be placed for mixers and basins?',
      hi: 'मिक्सर और वॉश बेसिन में गर्म और ठंडे पानी के पॉइंट किस तरफ होने चाहिए?',
    },
    answer: {
      en: 'International & UAE/Indian standard: HOT water is ALWAYS on the LEFT side, and COLD water is ALWAYS on the RIGHT side (150mm centers for wall shower mixers).',
      hi: 'अंतर्राष्ट्रीय नियम के अनुसार गर्म पानी हमेशा बाईं तरफ (LEFT) और ठंडा पानी हमेशा दाईं तरफ (RIGHT) होना चाहिए (शावर मिक्सर सेंटर दूरी 150mm)।',
    },
  },
  {
    id: 'iq8',
    category: 'Field Troubleshooting',
    question: {
      en: 'Why do we use two 45° elbows or a long-radius bend instead of a short 90° elbow at the base of a 110mm stack?',
      hi: '110mm खड़ी ड्रेनेज लाइन के निचले मोड़ पर तेज 90° एल्बो की जगह दो 45° एल्बो क्यों लगाते हैं?',
    },
    answer: {
      en: 'A sharp 90° elbow slows falling waste abruptly, causing solids to hit the wall and block the pipe, and creates back-pressure that blows lower floor traps.',
      hi: 'तेज 90° एल्बो से गिरता हुआ कचरा टकराकर जाम हो सकता है और हवा के दबाव से निचली मंजिल के फ्लोर ट्रैप का पानी उछल सकता है।',
    },
  },
  {
    id: 'iq9',
    category: 'Dubai / Gulf Trade Test',
    question: {
      en: 'What is a Concealed Cistern rough-in height and WC wall-hung bolt spacing?',
      hi: 'कंसील्ड फ्लश टैंक फ्रेम और वॉल-हंग टॉयलेट बोल्ट की मानक दूरी कितनी होती है?',
    },
    answer: {
      en: 'Standard concealed cistern frame height is 1120mm from FFL; wall-hung WC mounting bolt spacing is 180mm or 230mm center-to-center, with seat height ~400–420mm FFL.',
      hi: 'कंसील्ड टैंक फ्रेम की ऊंचाई FFL से 1120mm होती है, सीट लगाने वाले बोल्ट के बीच की दूरी 180mm या 230mm होती है और सीट की ऊंचाई ~400–420mm रखी जाती है।',
    },
  },
  {
    id: 'iq10',
    category: 'Technical & Drawings',
    question: {
      en: 'What is the purpose of a Vent Pipe in a drainage system?',
      hi: 'ड्रेनेज सिस्टम में वेंट पाइप (Vent Pipe) क्यों लगाया जाता है?',
    },
    answer: {
      en: 'It lets sewer gases escape above roof level and admits air into the drain stack so toilet flushing never creates vacuum suction that pulls water out of nearby traps.',
      hi: 'यह बदबूदार गैस को छत के ऊपर निकालता है और पाइप में हवा बनाए रखता है ताकि फ्लश करने पर पास के फ्लोर ट्रैप का पानी खिंचकर सूखे नहीं।',
    },
  },
];

export const QUIZ_BANK: QuizQuestion[] = [
  {
    id: 'q1',
    topic: 'Pipe Sizes',
    question: {
      en: 'What is the standard inch equivalent of a 25mm pipe?',
      hi: '25mm पाइप का मानक इंच (Inch) साइज क्या होता है?',
    },
    options: [
      { en: '1/2 inch', hi: '1/2 इंच' },
      { en: '3/4 inch', hi: '3/4 इंच' },
      { en: '1 inch', hi: '1 इंच' },
      { en: '1-1/2 inch', hi: '1-1/2 इंच' },
    ],
    correctIndex: 2,
    explanation: {
      en: '15mm = 1/2", 20mm = 3/4", 25mm = 1", 32mm = 1-1/4", 40mm = 1-1/2", 50mm = 2", 75mm = 3", 110mm = 4".',
      hi: '15mm = 1/2", 20mm = 3/4", 25mm = 1", 32mm = 1-1/4", 40mm = 1-1/2", 50mm = 2", 75mm = 3", 110mm = 4" होता है।',
    },
  },
  {
    id: 'q2',
    topic: 'PPR Welding',
    question: {
      en: 'What is the correct heater temperature for PPR socket fusion welding?',
      hi: 'PPR पाइप की हीट वेल्डिंग के लिए मशीन का सही तापमान कितना होना चाहिए?',
    },
    options: [
      { en: '150°C', hi: '150°C' },
      { en: '260°C', hi: '260°C' },
      { en: '350°C', hi: '350°C' },
      { en: '100°C', hi: '100°C' },
    ],
    correctIndex: 1,
    explanation: {
      en: 'PPR melts cleanly at 260°C. Too cold gives weak joints; too hot burns and narrows the inside bore.',
      hi: 'PPR वेल्डिंग के लिए ठीक 260°C तापमान चाहिए। कम तापमान पर जोड़ कमजोर और ज्यादा पर पाइप अंदर से बंद हो सकता है।',
    },
  },
  {
    id: 'q3',
    topic: 'Dubai Standards',
    question: {
      en: 'What is the standard hydrostatic pressure test requirement on UAE/Dubai water lines before tiling?',
      hi: 'दुबई/UAE में टाइल्स से पहले पानी की लाइन का प्रेशर टेस्ट कितने Bar पर किया जाता है?',
    },
    options: [
      { en: '2 Bar', hi: '2 Bar' },
      { en: '5 Bar', hi: '5 Bar' },
      { en: '10 Bar', hi: '10 Bar' },
      { en: '25 Bar', hi: '25 Bar' },
    ],
    correctIndex: 2,
    explanation: {
      en: 'Domestic water supply networks in Dubai are typically tested at 10 Bar (150 PSI) for 2–4 hours.',
      hi: 'दुबई में पानी की पाइप लाइन को 10 Bar (150 PSI) प्रेशर पर 2 से 4 घंटे तक टेस्ट किया जाता है।',
    },
  },
  {
    id: 'q4',
    topic: 'Installations',
    question: {
      en: 'Which side of a wall shower mixer is connected to the HOT water pipe?',
      hi: 'वॉल शावर मिक्सर में गर्म पानी (Hot Water) का पाइप किस तरफ जोड़ा जाता है?',
    },
    options: [
      { en: 'Right side', hi: 'दाईं तरफ (Right)' },
      { en: 'Left side', hi: 'बाईं तरफ (Left)' },
      { en: 'Center', hi: 'बीच में' },
      { en: 'Either side', hi: 'किसी भी तरफ' },
    ],
    correctIndex: 1,
    explanation: {
      en: 'Hot water is always on the LEFT and Cold water is always on the RIGHT, spaced 150mm center-to-center.',
      hi: 'गर्म पानी हमेशा बाईं तरफ (Left) और ठंडा पानी दाईं तरफ (Right) 150mm की दूरी पर लगाया जाता है।',
    },
  },
  {
    id: 'q5',
    topic: 'Drainage Slope',
    question: {
      en: 'What is the ideal fall (drop) per meter for a 110mm toilet soil pipe at 1:100 slope?',
      hi: '1:100 ढलान पर 110mm टॉयलेट पाइप में प्रति मीटर कितना गिराव (Fall) होना चाहिए?',
    },
    options: [
      { en: '1 cm (10 mm) per meter', hi: '1 सेमी (10 mm) प्रति मीटर' },
      { en: '5 cm (50 mm) per meter', hi: '5 सेमी (50 mm) प्रति मीटर' },
      { en: '10 cm (100 mm) per meter', hi: '10 सेमी (100 mm) प्रति मीटर' },
      { en: '0 mm (dead level)', hi: '0 mm (बिल्कुल सीधा)' },
    ],
    correctIndex: 0,
    explanation: {
      en: '1:100 equals 1 meter divided by 100 = 0.01m = 10mm (1 cm) drop per 1 meter length.',
      hi: '1:100 का मतलब हर 100 सेमी (1 मीटर) लंबाई पर 1 सेमी (10 mm) नीचे ढलान।',
    },
  },
  {
    id: 'q6',
    topic: 'Arabic Vocab',
    question: {
      en: 'On a Dubai site, what does the Arabic word "Mahbas (محبس)" mean?',
      hi: 'दुबई साइट पर अरबी शब्द "महबस (Mahbas)" का क्या मतलब होता है?',
    },
    options: [
      { en: 'Elbow fitting', hi: 'एल्बो मोड़' },
      { en: 'Valve / Stop cock', hi: 'वॉल्व (पानी रोकने का)' },
      { en: 'Spirit level', hi: 'स्पिरिट लेवल' },
      { en: 'Water leak', hi: 'पानी की लीकेज' },
    ],
    correctIndex: 1,
    explanation: {
      en: 'Mahbas = Valve, Koo’a = Elbow, Mizan Maya = Spirit Level, Tahreeb = Leak.',
      hi: 'Mahbas = वॉल्व, Koo’a = एल्बो, Mizan Maya = स्पिरिट लेवल और Tahreeb = लीकेज होता है।',
    },
  },
  {
    id: 'q7',
    topic: 'Fittings',
    question: {
      en: 'Which fitting allows removing a booster pump or water heater without cutting the pipe?',
      hi: 'कौन सी फिटिंग पंप या गीजर को पाइप काटे बिना खोलने की सुविधा देती है?',
    },
    options: [
      { en: 'Reducer', hi: 'रिड्यूसर' },
      { en: 'Socket', hi: 'सॉकेट' },
      { en: '3-Piece Union', hi: '3-पीस यूनियन' },
      { en: '45° Elbow', hi: '45° एल्बो' },
    ],
    correctIndex: 2,
    explanation: {
      en: 'A 3-piece Union unscrews at the center collar nut so equipment can be lifted out cleanly.',
      hi: 'यूनियन के बीच का नट खोलकर पंप या हीटर को बिना पाइप काटे आसानी से निकाला जा सकता है।',
    },
  },
  {
    id: 'q8',
    topic: 'Calculations',
    question: {
      en: 'To find the travel pipe length between two 45° elbows, you multiply the offset distance by:',
      hi: 'दो 45° एल्बो के बीच तिरछे पाइप की लंबाई निकालने के लिए ऑफसेट दूरी को किससे गुणा करते हैं?',
    },
    options: [
      { en: '1.15', hi: '1.15' },
      { en: '1.414', hi: '1.414' },
      { en: '2.00', hi: '2.00' },
      { en: '0.707', hi: '0.707' },
    ],
    correctIndex: 1,
    explanation: {
      en: 'For a 45° triangle, hypotenuse (Travel) = Offset × √2 = Offset × 1.414.',
      hi: '45° कोण का नियम है: तिरछी लंबाई = ऑफसेट दूरी × 1.414।',
    },
  },
];

export const BOQ_ITEMS: BoqTemplateItem[] = [
  { id: 'b1', item: { en: '20mm PPR PN20 Pipe (4m length)', hi: '20mm PPR PN20 पाइप (4 मीटर पीस)' }, unit: 'Length', qtyPerBathroom: 4, qtyPerKitchen: 2, approxRateAed: 18, approxRateInr: 360 },
  { id: 'b2', item: { en: '25mm PPR PN20 Main Branch (4m length)', hi: '25mm PPR PN20 मेन पाइप (4 मीटर पीस)' }, unit: 'Length', qtyPerBathroom: 2, qtyPerKitchen: 1, approxRateAed: 26, approxRateInr: 520 },
  { id: 'b3', item: { en: '20mm PPR 90° Elbow & Tee Pack', hi: '20mm PPR एल्बो व टी फिटिंग' }, unit: 'Pcs', qtyPerBathroom: 16, qtyPerKitchen: 8, approxRateAed: 3, approxRateInr: 45 },
  { id: 'b4', item: { en: '20×1/2" Brass Female Wall Elbow', hi: '20×1/2" ब्रास फीमेल वॉल एल्बो' }, unit: 'Pcs', qtyPerBathroom: 7, qtyPerKitchen: 3, approxRateAed: 16, approxRateInr: 290 },
  { id: 'b5', item: { en: '25mm PPR Brass Ball Valve (Isolation)', hi: '25mm मेन आइसोलेशन बॉल वॉल्व' }, unit: 'Pcs', qtyPerBathroom: 2, qtyPerKitchen: 2, approxRateAed: 38, approxRateInr: 680 },
  { id: 'b6', item: { en: '50mm uPVC Waste Pipe (3m length)', hi: '50mm uPVC वेस्ट पाइप (3 मीटर)' }, unit: 'Length', qtyPerBathroom: 2, qtyPerKitchen: 2, approxRateAed: 24, approxRateInr: 440 },
  { id: 'b7', item: { en: '110mm uPVC Soil Pipe (3m length)', hi: '110mm uPVC टॉयलेट पाइप (3 मीटर)' }, unit: 'Length', qtyPerBathroom: 2, qtyPerKitchen: 0, approxRateAed: 55, approxRateInr: 980 },
  { id: 'b8', item: { en: 'Multi-Inlet Floor Trap + SS Grating', hi: 'मल्टी-इनलेट फ्लोर ट्रैप + SS जाली' }, unit: 'Set', qtyPerBathroom: 1, qtyPerKitchen: 1, approxRateAed: 45, approxRateInr: 750 },
  { id: 'b9', item: { en: '1/2" Chrome Angle Valves + PTFE Tape', hi: '1/2" एंगल वॉल्व + टेफ्लॉन टेप' }, unit: 'Set', qtyPerBathroom: 4, qtyPerKitchen: 3, approxRateAed: 22, approxRateInr: 420 },
  { id: 'b10', item: { en: 'uPVC Solvent Cement + Pipe Clamps', hi: 'सॉल्वेंट ग्लू और पाइप क्लैंप सेट' }, unit: 'Lot', qtyPerBathroom: 1, qtyPerKitchen: 1, approxRateAed: 35, approxRateInr: 550 },
];
