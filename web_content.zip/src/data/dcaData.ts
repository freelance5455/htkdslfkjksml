export interface Fighter {
  id: string;
  tagId: string;
  name: string;
  initials: string;
  discipline: string;
  weightClass: string;
  campTier: string;
  expiryDate: string;
  daysRemaining: number;
  status: 'Active' | 'Critical' | 'Overdue Soon' | 'Expiring' | 'Lapsed';
  phone: string;
  rfid: string;
  biometricVerified: boolean;
  medicalClearance: 'Cleared' | 'Pending Labs' | 'Renewal Due';
  boutRecord: string;
  lastCheckIn: string;
  feeBalance: number;
}

export interface MatClass {
  id: string;
  time: string;
  title: string;
  coach: string;
  zone: string;
  enrolled: number;
  capacity: number;
  status: 'Completed' | 'Live Sparring' | 'Upcoming';
  discipline: 'Boxing' | 'Muay Thai' | 'MMA' | 'BJJ' | 'Conditioning';
}

export interface AttendanceLog {
  id: string;
  fighterName: string;
  tagId: string;
  timeAgo: string;
  method: 'Biometrics' | 'Security PIN' | 'RFID Band';
  gateNode: string;
  rosterNote: string;
  icon: string;
}

export interface InvoiceRecord {
  id: string;
  invoiceNo: string;
  fighterName: string;
  tagId: string;
  planName: string;
  amount: number;
  date: string;
  method: 'UPI / QR' | 'HDFC Card' | 'Cash Desk' | 'NEFT';
  status: 'Paid' | 'Pending' | 'Overdue';
}

export interface FightNotice {
  id: string;
  title: string;
  date: string;
  category: 'Tournament' | 'Weigh-In' | 'Facility' | 'Medical';
  description: string;
  author: string;
  acknowledgedCount: number;
}

export const INITIAL_FIGHTERS: Fighter[] = [
  {
    id: 'f-1',
    tagId: 'DCA-7840',
    name: 'Aman Sharma',
    initials: 'AS',
    discipline: 'Pro MMA Training',
    weightClass: 'Welterweight Batch',
    campTier: 'Pro Octagon Pass',
    expiryDate: 'Nov 15',
    daysRemaining: 35,
    status: 'Active',
    phone: '+91 98112 44019',
    rfid: 'RF-9941-A',
    biometricVerified: true,
    medicalClearance: 'Cleared',
    boutRecord: '6-1-0 (Pro)',
    lastCheckIn: 'Just now • Mat Gate 1',
    feeBalance: 0,
  },
  {
    id: 'f-2',
    tagId: 'DCA-6102',
    name: 'Rohit Deshmukh',
    initials: 'RD',
    discipline: 'Muay Thai Intensive',
    weightClass: 'Middleweight Batch',
    campTier: 'Striker Elite Camp',
    expiryDate: 'Oct 14',
    daysRemaining: 3,
    status: 'Critical',
    phone: '+91 98730 11824',
    rfid: 'RF-8820-B',
    biometricVerified: true,
    medicalClearance: 'Cleared',
    boutRecord: '9-2-0 (Amateur)',
    lastCheckIn: '4 mins ago • Dojang Keypad #2',
    feeBalance: 8500,
  },
  {
    id: 'f-3',
    tagId: 'DCA-8921',
    name: 'Tarun Gill',
    initials: 'TG',
    discipline: 'Boxing Fundamentals',
    weightClass: 'Featherweight Batch',
    campTier: 'State Qualifier Pass',
    expiryDate: 'Oct 12',
    daysRemaining: 1,
    status: 'Overdue Soon',
    phone: '+91 99104 75390',
    rfid: 'RF-7731-C',
    biometricVerified: true,
    medicalClearance: 'Renewal Due',
    boutRecord: '4-0-0 (Amateur)',
    lastCheckIn: '12 mins ago • Boxing Ring A',
    feeBalance: 6000,
  },
  {
    id: 'f-4',
    tagId: 'DCA-5510',
    name: 'Simran Johal',
    initials: 'SJ',
    discipline: 'BJJ Gi & No-Gi Regular',
    weightClass: 'Flyweight Batch',
    campTier: 'Grappler Unlimited',
    expiryDate: 'Oct 18',
    daysRemaining: 7,
    status: 'Expiring',
    phone: '+91 98188 30291',
    rfid: 'RF-5510-D',
    biometricVerified: true,
    medicalClearance: 'Cleared',
    boutRecord: '11-3-0 (Purple Belt)',
    lastCheckIn: '26 mins ago • Cage Turnstile 01',
    feeBalance: 0,
  },
  {
    id: 'f-5',
    tagId: 'DCA-4290',
    name: 'Kabir Ahlawat',
    initials: 'KA',
    discipline: 'Pro MMA Training',
    weightClass: 'Lightweight Batch',
    campTier: 'Pro Octagon Pass',
    expiryDate: 'Dec 04',
    daysRemaining: 54,
    status: 'Active',
    phone: '+91 97172 88910',
    rfid: 'RF-4290-E',
    biometricVerified: true,
    medicalClearance: 'Cleared',
    boutRecord: '8-2-0 (Pro)',
    lastCheckIn: '41 mins ago • Mat Gate 2',
    feeBalance: 0,
  },
  {
    id: 'f-6',
    tagId: 'DCA-3108',
    name: 'Neha Phogat',
    initials: 'NP',
    discipline: 'Freestyle Wrestling & MMA',
    weightClass: 'Bantamweight Batch',
    campTier: 'National Camp Scholarship',
    expiryDate: 'Nov 28',
    daysRemaining: 48,
    status: 'Active',
    phone: '+91 98991 64201',
    rfid: 'RF-3108-F',
    biometricVerified: true,
    medicalClearance: 'Cleared',
    boutRecord: '14-1-0 (National)',
    lastCheckIn: '1 hr ago • Main Dojang',
    feeBalance: 0,
  },
  {
    id: 'f-7',
    tagId: 'DCA-9042',
    name: 'Devender Sangwan',
    initials: 'DS',
    discipline: 'Boxing Heavy Hands',
    weightClass: 'Heavyweight Batch',
    campTier: 'Quarterly Ring Pass',
    expiryDate: 'Oct 02',
    daysRemaining: -8,
    status: 'Lapsed',
    phone: '+91 98101 55219',
    rfid: 'RF-9042-G',
    biometricVerified: false,
    medicalClearance: 'Pending Labs',
    boutRecord: '3-2-0 (Amateur)',
    lastCheckIn: '9 days ago • Boxing Ring A',
    feeBalance: 12500,
  },
];

export const INITIAL_CLASSES: MatClass[] = [
  {
    id: 'c-1',
    time: '06:30 AM',
    title: 'Boxing Heavy Bag & Footwork',
    coach: 'Coach Rajesh Dahiya',
    zone: 'Boxing Ring',
    enrolled: 24,
    capacity: 24,
    status: 'Completed',
    discipline: 'Boxing',
  },
  {
    id: 'c-2',
    time: '12:00 PM',
    title: 'Muay Thai Clinch & Elbow Drills',
    coach: 'Coach Vikram Singh',
    zone: 'Main Mat A',
    enrolled: 20,
    capacity: 20,
    status: 'Live Sparring',
    discipline: 'Muay Thai',
  },
  {
    id: 'c-3',
    time: '05:30 PM',
    title: 'MMA Octagon Cage Wall-Work',
    coach: 'Coach Carlos Rivera',
    zone: 'The Cage',
    enrolled: 18,
    capacity: 20,
    status: 'Upcoming',
    discipline: 'MMA',
  },
  {
    id: 'c-4',
    time: '07:00 PM',
    title: 'Combat Conditioning & Ice Recovery',
    coach: 'Coach Priya Sharma',
    zone: 'Strength Zone',
    enrolled: 15,
    capacity: 15,
    status: 'Upcoming',
    discipline: 'Conditioning',
  },
];

export const INITIAL_ATTENDANCE: AttendanceLog[] = [
  {
    id: 'a-1',
    fighterName: 'Aman Sharma',
    tagId: 'DCA-7840',
    timeAgo: 'Just now',
    method: 'Biometrics',
    gateNode: 'Face ID • Mat Gate 1',
    rosterNote: 'Verified • Adult MMA Batch',
    icon: 'face',
  },
  {
    id: 'a-2',
    fighterName: 'Rohit Deshmukh',
    tagId: 'DCA-6102',
    timeAgo: '4 mins ago',
    method: 'Security PIN',
    gateNode: 'Dojang West Keypad #2',
    rosterNote: 'Member ID #DCA-6102',
    icon: 'pin',
  },
  {
    id: 'a-3',
    fighterName: 'Tarun Gill',
    tagId: 'DCA-8921',
    timeAgo: '12 mins ago',
    method: 'Biometrics',
    gateNode: 'Boxing Ring A Sensor',
    rosterNote: 'Attendance Logged • Member ID #DCA-8921',
    icon: 'fingerprint',
  },
  {
    id: 'a-4',
    fighterName: 'Simran Johal',
    tagId: 'DCA-5510',
    timeAgo: '26 mins ago',
    method: 'Biometrics',
    gateNode: 'Cage Turnstile Node 01',
    rosterNote: 'BJJ Squad • Member ID #DCA-5510',
    icon: 'sensor_door',
  },
];

export const INITIAL_INVOICES: InvoiceRecord[] = [
  {
    id: 'inv-1',
    invoiceNo: 'DCA-INV-2589',
    fighterName: 'Aman Sharma',
    tagId: 'DCA-7840',
    planName: 'Pro Octagon Fight Camp (Quarterly)',
    amount: 24500,
    date: 'Oct 10, 2025',
    method: 'UPI / QR',
    status: 'Paid',
  },
  {
    id: 'inv-2',
    invoiceNo: 'DCA-INV-2590',
    fighterName: 'Rohit Deshmukh',
    tagId: 'DCA-6102',
    planName: 'Striker Elite Camp Renewal + Sparring Gear',
    amount: 8500,
    date: 'Oct 11, 2025',
    method: 'UPI / QR',
    status: 'Pending',
  },
  {
    id: 'inv-3',
    invoiceNo: 'DCA-INV-2591',
    fighterName: 'Tarun Gill',
    tagId: 'DCA-8921',
    planName: 'State Qualifier Boxing Camp',
    amount: 6000,
    date: 'Oct 11, 2025',
    method: 'Cash Desk',
    status: 'Overdue',
  },
  {
    id: 'inv-4',
    invoiceNo: 'DCA-INV-2592',
    fighterName: 'Simran Johal',
    tagId: 'DCA-5510',
    planName: 'Grappler Unlimited (6 Months)',
    amount: 32000,
    date: 'Oct 08, 2025',
    method: 'HDFC Card',
    status: 'Paid',
  },
  {
    id: 'inv-5',
    invoiceNo: 'DCA-INV-2593',
    fighterName: 'Kabir Ahlawat',
    tagId: 'DCA-4290',
    planName: '1-on-1 Cage Work & Cornering Package',
    amount: 18000,
    date: 'Oct 06, 2025',
    method: 'NEFT',
    status: 'Paid',
  },
];

export const INITIAL_NOTICES: FightNotice[] = [
  {
    id: 'n-1',
    title: 'North India Amateur MMA Championship — Official Weigh-Ins',
    date: 'Oct 18, 2025 · 08:00 AM IST',
    category: 'Weigh-In',
    description:
      'All DCA roster fighters competing in the 61kg, 66kg, 70kg, and 77kg brackets must report to Rohini Main Dojang Scale Room with medical bloodwork clearance and state athlete ID.',
    author: 'Coach Vikram Rathore',
    acknowledgedCount: 94,
  },
  {
    id: 'n-2',
    title: 'Main Octagon Canvas Re-Tensioning & Sanitization Window',
    date: 'Oct 14, 2025 · 02:30 PM – 04:30 PM IST',
    category: 'Facility',
    description:
      'Cage 1 canvas and chain-link padding will undergo high-heat antimicrobial treatment. Afternoon pro sparring rounds move to Main Mat A.',
    author: 'Facility Ops Team',
    acknowledgedCount: 118,
  },
  {
    id: 'n-3',
    title: 'Mandatory Pre-Bout Concussion Baseline & Ophthalmology Check',
    date: 'Oct 20, 2025 · All Day',
    category: 'Medical',
    description:
      'Dr. Arvind Mehta (Sports Medicine) will be on-site at DCA Recovery Bay to sign off annual full-contact sparring clearances.',
    author: 'DCA Medical Board',
    acknowledgedCount: 76,
  },
];
