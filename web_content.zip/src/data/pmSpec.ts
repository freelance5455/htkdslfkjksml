export interface PMSpecSection {
  title: string;
  number: string;
  content: string;
  bullets?: string[];
  subsections?: { subtitle: string; details: string; points?: string[] }[];
}

export const PM_SPEC_DATA = {
  appName: "PoketSafe",
  tagline: "Know what's truly safe to spend before reality catches up.",
  version: "1.0 MVP Specification",
  author: "Senior Product Manager",
  lastUpdated: "November 2026",
  wordCount: "~780 words",
  sections: [
    {
      id: "problem-statement",
      number: "01",
      title: "Problem Statement",
      summary: "Students mistake bank balance for disposable income, triggering the 'Mid-Semester Cash Crash'.",
      content: `University students, PTPTN loan holders, and scholarship recipients receive funds in sporadic, lump-sum disbursements (e.g., RM 3,500 every 4–6 months). 

When logging into mobile banking, they see a single gross balance (e.g. RM 3,200). This creates a dangerous cognitive illusion of wealth:
• Unseen Commitments: Fixed obligations (room rent, hostel fees, wifi, exam fees) have not yet been deducted.
• Unrecorded P2P Debts: Informal peer borrowings (hotpot split bills, grab car rides, printing money) are forgotten.
• Absence of Burn Rate Visibility: Students spend aggressively in Weeks 1–4, and are forced into extreme distress ("Maggi cup noodles survival mode") in Weeks 9–14.

Existing generic budgeting apps (YNAB, Money Lover) fail because they demand tedious double-entry accounting and categorization that students abandon after 4 days. Students don't need accounting ledgers; they need a single, honest answer: "How much can I safely spend today without starving before next semester?"`
    },
    {
      id: "target-users",
      number: "02",
      title: "Target Users & Personas",
      summary: "Undergraduates and young adults juggling lump-sum inflows, irregular schedules, and peer splits.",
      content: "PoketSafe addresses four primary student cohorts with distinct cashflow anxieties:",
      subsections: [
        {
          subtitle: "1. The PTPTN Recipient (e.g. Ahmad, 21, Public University Undergrad)",
          details: "Receives a lump sum of RM 3,500 per semester. Must cover hostel, semester pack, and meals for 120 days. Struggles with pacing: spends RM 45/day early on, then drops to RM 8/day by week 10.",
          points: [
            "Pain: Anxiety of running out of money before exam week.",
            "Key Need: Daily Safe-to-Spend limit based on days remaining until the next disbursement."
          ]
        },
        {
          subtitle: "2. The Scholarship Recipient (e.g. Mei Ling, 20, Private College Scholar)",
          details: "Receives fixed monthly or quarterly stipends with strict GPA requirements. Has academic commitments (textbooks, lab kits, laptop savings).",
          points: [
            "Pain: Overspending on campus social life and jeopardizing textbook or rent payments.",
            "Key Need: Automatic commitment lock-in so rent is never compromised."
          ]
        },
        {
          subtitle: "3. The Social Roommate / Peer Debtor (e.g. Danial, 22, Final Year)",
          details: "Constantly splits Grab rides, mamak suppers, and groceries with roommates via DuitNow/cash.",
          points: [
            "Pain: 'Money leaking' through uncollected or unpaid peer debts (IOUs).",
            "Key Need: Lightweight IOU tracker directly subtracted from disposable funds."
          ]
        },
        {
          subtitle: "4. The First-Job Young Adult / Working Student (e.g. Sarah, 23)",
          details: "Entry-level income (RM 2,200–RM 2,800). First time managing rental deposits, telco contracts, and emergency buffers.",
          points: [
            "Pain: Spending paycheck in first 10 days, living paycheck-to-paycheck.",
            "Key Need: Clear separation between committed expenses and safe daily allowance."
          ]
        }
      ]
    },
    {
      id: "key-features",
      number: "03",
      title: "Key Features Architecture",
      summary: "Six opinionated mechanics that transform complex financial tracking into instant decision-making.",
      subsections: [
        {
          subtitle: "1. Safe Balance (Core Metric)",
          details: "The single source of truth. Calculated dynamically: Gross Bank Balance − (Upcoming Commitments + Due Debts Owed + Locked Savings Goal). Automatically derives 'Safe Daily Allowance' = Safe Balance ÷ Days to Next Inflow.",
        },
        {
          subtitle: "2. Survival Score (0–100 Diagnostic)",
          details: "A real-time health index comparing current burn rate against the baseline daily survival threshold (e.g., RM 15–20/day for food). Classifies financial runway into: Thriving (80–100), Stable (60–79), Warning (40–59), and Emergency (0–39) with contextual guidance.",
        },
        {
          subtitle: "3. Quick-Tap Expense Tracker",
          details: "Zero-friction friction entry designed for students walking out of campus cafeterias. Categorized into 5 student-native buckets (Food, Campus/Academic, Transport, Groceries, Social). Immediately reduces Safe Balance and updates Daily Allowance.",
        },
        {
          subtitle: "4. Peer Debt Tracker (Student IOU)",
          details: "Tracks two-way micro-debts: 'I Owe' (instantly deducted from Safe Balance) and 'Owed to Me' (pending collectibles). One-tap 'Settle' with payment notes.",
        },
        {
          subtitle: "5. Commitment Manager",
          details: "Schedules non-negotiable student bills: hostel/room rent, internet/telco data, semester fees, and subscriptions. These funds are walled off from Safe Balance so students never default on shelter or tuition.",
        },
        {
          subtitle: "6. Savings Goal (Untouchable Piggybank)",
          details: "Purpose-driven envelopes (Emergency Fund, Exam Gadget, Balik Kampung trip). Money moved to savings is quarantined from the Safe-to-Spend pool.",
        }
      ]
    },
    {
      id: "user-journey",
      number: "04",
      title: "End-to-End User Journey",
      summary: "From lump-sum disbursement anxiety to daily peace of mind.",
      subsections: [
        {
          subtitle: "Stage 1: Semester Onboarding (Time to complete: 90 seconds)",
          details: "Student logs in after PTPTN disbursement. Enters Current Balance (RM 3,500) and Next Disbursement Date (e.g., 90 days away).",
          points: [
            "Input 2–3 fixed commitments (Hostel RM 350/mo, Telco RM 35/mo).",
            "Result: PoketSafe reveals the real Safe Balance (RM 2,345) and sets Daily Safe Cap (RM 26.05/day).",
            "Aha Moment: 'I thought I had RM 3,500, but I actually have RM 26 per day.'"
          ]
        },
        {
          subtitle: "Stage 2: Daily Campus Routine (Micro-interactions: 10 seconds)",
          details: "Student pays RM 9.50 for lunch at the cafeteria. Opens PoketSafe, taps 'Food', enters 9.50.",
          points: [
            "Immediate feedback: 'RM 16.55 remaining for today. Survival Score: 88 (Thriving)'.",
            "Evening: Friend pays for Grab (RM 12). Student logs 'I owe Kevin RM 12' in 5 seconds."
          ]
        },
        {
          subtitle: "Stage 3: Mid-Semester Health Check & Course Correction",
          details: "Week 7: Student splurged on a weekend trip. Survival Score dips to 48 ('Warning: High Burn').",
          points: [
            "PoketSafe suggests: 'Cap daily food to RM 18 for the next 5 days to return to Stable zone.'",
            "Crisis prevented before student hits zero."
          ]
        },
        {
          subtitle: "Stage 4: Commitment Settlement & Cycle Close",
          details: "Rent due on the 1st. Student taps 'Pay Commitment' (RM 350). Balance updates smoothly with zero shock because the funds were already quarantined."
        }
      ]
    },
    {
      id: "mvp-scope",
      number: "05",
      title: "MVP Scope & Engineering Boundaries",
      summary: "Clear prioritization to validate product-market fit before building banking API integrations.",
      subsections: [
        {
          subtitle: "In-Scope for MVP (Phase 1)",
          details: "Core value proposition delivery:",
          points: [
            "Deterministic Safe Balance Engine (Gross Cash − Commitments − Debts − Savings).",
            "Dynamic Survival Score algorithm with daily runway projections.",
            "Fast Expense Logging (5 essential student categories, zero-latency update).",
            "Peer Debt Ledger ('I owe' vs 'They owe me' with instant settlement).",
            "Commitment Manager with due date alerts and cycle marking.",
            "Single active Savings Goal with visual progress ring.",
            "Local storage persistence with offline-first responsiveness."
          ]
        },
        {
          subtitle: "Explicitly Out-of-Scope (Deferred to Phase 2+)",
          details: "To avoid over-engineering and compliance bottlenecks:",
          points: [
            "Open Banking / Automated Bank Sync (requires regulatory bank licensing & API gateways).",
            "In-app peer money transfers (keep transactions via DuitNow/QR, track status only).",
            "Complex stock/crypto investment tracking.",
            "Receipt OCR scanning (adds mobile latency; manual tap is 3x faster for student meals).",
            "Multi-currency forex portfolio hedging."
          ]
        },
        {
          subtitle: "North Star Metric & MVP Success KPI",
          details: "Primary Metric: '7-Day Retention of Daily Safe Cap Awareness' (% of users who check Safe Balance at least 4x per week). Secondary Metric: Percentage of students who complete the semester with Survival Score > 50."
        }
      ]
    }
  ]
};
