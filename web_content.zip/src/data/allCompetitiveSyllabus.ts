import { SubjectSyllabus, SyllabusTopic } from './subjectSyllabusData';
import { MCQQuestion } from '../types';

export const ADDITIONAL_COMPETITIVE_SYLLABI: Record<string, SubjectSyllabus> = {
  'History': {
    subjectKey: 'History',
    displayName: {
      en: 'Indian & World History',
      bn: 'ইতিহাস (History)',
      hi: 'इतिहास'
    },
    emoji: '📜',
    gradient: 'from-amber-600 via-orange-600 to-yellow-600',
    accentColor: 'amber',
    topics: [
      {
        id: 'hist-indus',
        topicName: 'Indus Valley & Vedic Period',
        topicNameBn: 'সিন্ধু সভ্যতা ও বৈদিক যুগ',
        topicNameHi: 'सिंधु घाटी सभ्यता व वैदिक काल',
        chapterNumber: 1,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Urban town planning, Great Bath, Lothal dockyard, bronze sculptures, Rigvedic polity, and later Vedic social hierarchy.',
          bn: 'সিন্ধু সভ্যতার উন্নত নগর পরিকল্পনা, পয়ঃপ্রণালী, লোথাল বন্দর, হরপ্পা ও মহেঞ্জোদারো আবিষ্কার, ঋকবৈদিক সমাজ ও পরবর্তী বৈদিক সংস্কার।',
          hi: 'सिंधु घाटी सभ्यता का नगर नियोजन, लोथल बंदरगाह, और वैदिक संस्कृति।'
        },
        keyFormulasAndTricks: {
          en: [
            'Mohenjodaro = Great Bath & Dancing Girl (Discovered by RD Banerjee 1922).',
            'Lothal = World oldest dockyard in Gujarat on Bhogava river.',
            'Kalibangan = Ploughed field in Rajasthan.'
          ],
          bn: [
            'মহেঞ্জোদারো = স্নানাগার ও ব্রোঞ্জের নর্তকী (রাখালদাস বন্দ্যোপাধ্যায়, ১৯২২)।',
            'লোথাল = গুজরাটের প্রাচীন পোতাশ্রয় বা বন্দর।',
            'কালিবঙ্গান = রাজস্থানে অবস্থিত এবং কাঠের লাঙলের দাগ পাওয়া গেছে।'
          ],
          hi: [
            'लोथल = भोगवा नदी पर प्राचीन गोदीवाड़ा।',
            'मोहनजोदड़ो = विशाल स्नानागार।'
          ]
        },
        examTips: {
          en: 'Rivers on which ancient sites sit are frequently asked in RRB and SSC exams.',
          bn: 'কোন প্রত্নক্ষেত্র কোন নদীর তীরে অবস্থিত (যেমন হরপ্পা-রাভি, মহেঞ্জোদারো-সিন্ধু) তা বারবার পরীক্ষায় আসে।',
          hi: 'हड़प्पा स्थलों के नदी तटों को याद रखें।'
        },
        sampleQuestions: [
          {
            id: 'hist-q1',
            subject: 'History',
            topic: 'Indus Valley',
            difficulty: 'Easy',
            question: 'হরপ্পা সভ্যতার সর্ববৃহৎ শস্যভাণ্ডারটি (Great Granary) কোথায় আবিষ্কৃত হয়েছিল?',
            options: ['A. মহেঞ্জোদারো', 'B. লোথাল', 'C. রোপার', 'D. কালিবঙ্গান'],
            correctOptionIndex: 0,
            explanation: 'মহেঞ্জোদারোয় প্রাপ্ত বিশাল শস্যভাণ্ডারটি ছিল এই প্রাচীন নগরীর অন্যতম উল্লেখযোগ্য স্থাপত্য নিদর্শন।',
            shortConcept: 'মহেঞ্জোদারোর শস্যভাণ্ডার',
            rememberPoint: 'মহেঞ্জোদারো বর্তমান পাকিস্তানের সিন্ধু প্রদেশে অবস্থিত।'
          },
          {
            id: 'hist-q2',
            subject: 'History',
            topic: 'Vedic Period',
            difficulty: 'Medium',
            question: 'প্রাচীনতম বেদ কোনটি এবং এতে কতগুলি সূক্ত (Hymns) সংকলিত আছে?',
            options: ['A. ঋগ্বেদ - ১০২৮ টি', 'B. সামবেদ - ৫০০ টি', 'C. যজুर्वेद - ৭৫০ টি', 'D. অথর্ববেদ - ৯০০ টি'],
            correctOptionIndex: 0,
            explanation: 'ঋগ্বেদ হলো মানবজাতির প্রাচীনতম লিখিত ধর্মগ্রন্থ। এতে ১০টি মণ্ডলে মোট ১০২৮টি সূক্ত ও ১০,৫৮০টি শ্লোক রয়েছে।',
            shortConcept: 'ঋগ্বেদ ১০২৮ সূক্ত',
            rememberPoint: 'গায়েত্রী মন্ত্র ঋগ্বেদের ৩য় মণ্ডলে উল্লেখিত আছে।'
          }
        ]
      },
      {
        id: 'hist-modern',
        topicName: 'Indian National Movement (1857-1947)',
        topicNameBn: 'ভারতের স্বাধীনতা সংগ্রাম ও জাতীয় আন্দোলন',
        topicNameHi: 'भारतीय राष्ट्रीय आंदोलन (1857-1947)',
        chapterNumber: 2,
        estimatedMinutes: 35,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Revolt of 1857, Indian National Congress foundation (1885), Partition of Bengal (1905), Non-Cooperation (1920), Civil Disobedience (1930), and Quit India Movement (1942).',
          bn: '১৮৫৭ সালের মহাবিদ্রোহ, জাতীয় কংগ্রেসের প্রতিষ্ঠা (১৮৮৫), বঙ্গভঙ্গ আন্দোলন (১৯০৫), অসহযোগ, আইন অমান্য এবং ভারত ছাড়ো আন্দোলন (১৯৪২)।',
          hi: '1857 का विद्रोह, कांग्रेस स्थापना (1885), असहयोग और भारत छोड़ो आंदोलन।'
        },
        keyFormulasAndTricks: {
          en: [
            'Remember chronologies: Non-Cooperation (1920) -> Chauri Chaura (1922) -> Dandi March (1930) -> Quit India (1942).',
            'INC 1885 founded by AO Hume; 1st President WC Bonnerjee in Bombay.'
          ],
          bn: [
            'সাল মনে রাখার কৌশল: বঙ্গভঙ্গ ১৯০৫ -> জালিয়ানওয়ালাবাগ ১৯১৯ -> অসহযোগ ১৯২০ -> ডান্ডি অভিযান ১৯৩০ -> ভারত ছাড়ো ১৯৪২।',
            'জাতীয় কংগ্রেসের প্রথম সভাপতি উমেশচন্দ্র বন্দ্যোপাধ্যায় (বোম্বাই, ১৮৮৫)।'
          ],
          hi: [
            'क्रमानुगत वर्ष याद रखें: 1905, 1919, 1920, 1930, 1942।'
          ]
        },
        examTips: {
          en: 'Viceroys during key events (Curzon for 1905, Chelmsford for 1919, Irwin for 1931, Linlithgow for 1942) are high-yield questions.',
          bn: 'গুরুত্বপূর্ণ ঘটনার সময়কার ভাইসরয়দের নাম অবশ্যই মুখস্থ রাখুন।',
          hi: 'प्रमुख घटनाओं के समय वायसराय के नाम ध्यान रखें।'
        },
        sampleQuestions: [
          {
            id: 'hist-q3',
            subject: 'History',
            topic: 'National Movement',
            difficulty: 'Easy',
            question: 'মহাত্মা গান্ধী কোন গোলটেবিল বৈঠকে ভারতীয় জাতীয় কংগ্রেসের একমাত্র প্রতিনিধি হিসেবে যোগ দিয়েছিলেন?',
            options: ['A. দ্বিতীয় গোলটেবিল বৈঠক (1931)', 'B. প্রথম গোলটেবিল বৈঠক', 'C. তৃতীয় গোলটেবিল বৈঠক', 'D. কোনোটিতেই নয়'],
            correctOptionIndex: 0,
            explanation: 'গান্ধী-আরউইন চুক্তির (১৯৩১) পর গান্ধীজি লন্ডনে অনুষ্ঠিত দ্বিতীয় গোলটেবিল বৈঠকে কংগ্রেসের পক্ষ থেকে যোগ দেন।',
            shortConcept: 'দ্বিতীয় গোলটেবিল বৈঠক ১৯৩১',
            rememberPoint: 'ড. বি. আর. আম্বেদকর তিনটি গোলটেবিল বৈঠকেই অংশ নিয়েছিলেন।'
          }
        ]
      }
    ]
  },

  'Geography': {
    subjectKey: 'Geography',
    displayName: {
      en: 'Indian & Physical Geography',
      bn: 'ভূগোল (Geography)',
      hi: 'भूगोल'
    },
    emoji: '🗺️',
    gradient: 'from-emerald-600 via-teal-600 to-cyan-600',
    accentColor: 'emerald',
    topics: [
      {
        id: 'geo-physio',
        topicName: 'Physiography & River Systems of India',
        topicNameBn: 'ভারতের ভূপ্রকৃতি ও নদ-নদী ব্যবস্থা',
        topicNameHi: 'भारत की भू-आकृति व नदी तंत्र',
        chapterNumber: 1,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Himalayan drainage (Indus, Ganga, Brahmaputra), Peninsular rivers (Godavari, Krishna, Narmada, Tapi), and Western/Eastern Ghats.',
          bn: 'হিমালয়ের নদ-নদী (গঙ্গা, ব্রহ্মপুত্র, সিন্ধু), উপদ্বীপীয় নদী (গোদাবরী, কৃষ্ণা, নর্মদা, তাপ্তী) এবং পশ্চিমঘাট ও পূর্বঘাট পর্বতমালা।',
          hi: 'हिमालयी व प्रायद्वीपीय नदियां, प्रमुख पर्वत और दर्रे।'
        },
        keyFormulasAndTricks: {
          en: [
            'West flowing peninsular rivers that form estuaries: Narmada & Tapi (West flowing, into Arabian Sea).',
            'Dakshin Ganga = Godavari (longest peninsular river, 1465 km).'
          ],
          bn: [
            'পশ্চিমবাহিনী নদী যারা বদ্বীপ তৈরি করে না: নর্মদা ও তাপ্তী (আরব সাগরে পতিত)।',
            'দক্ষিণ ভারতের গঙ্গা বা বৃদ্ধ গঙ্গা = গোদাবরী (দৈর্ঘ্য ১৪৬৫ কিমি)।'
          ],
          hi: [
            'पश्चिम की ओर बहने वाली नदियां: नर्मदा व ताप्ती।',
            'दक्षिण गंगा = गोदावरी।'
          ]
        },
        examTips: {
          en: 'Origins and tributary matching questions appear in almost every competitive exam.',
          bn: 'কোন নদীর উৎপত্তি কোথায় এবং কার উপনদী কোনটি, তা ছক আকারে রিভিশন দিন।',
          hi: 'उद्गम स्थल और सहायक नदियों की सूची बनाएं।'
        },
        sampleQuestions: [
          {
            id: 'geo-q1',
            subject: 'Geography',
            topic: 'River Systems',
            difficulty: 'Easy',
            question: 'দক্ষিণ ভারতের দীর্ঘতম নদী কোনটি, যাকে "বৃদ্ধ গঙ্গা" বলা হয়?',
            options: ['A. গোদাবরী', 'B. কৃষ্ণা', 'C. কাবেরী', 'D. মহানদী'],
            correctOptionIndex: 0,
            explanation: 'গোদাবরী নদী মহারাষ্ট্রের নাসিকের ত্র্যম্বকেশ্বর থেকে উৎপন্ন হয়ে বঙ্গোপসাগরে পড়েছে। এর দৈর্ঘ্য ১৪৬৫ কিমি।',
            shortConcept: 'গোদাবরী = দক্ষিণ ভারতের দীর্ঘতম নদী',
            rememberPoint: 'গোদাবরীর প্রধান উপনদী: ইন্দ্রাবতী, প্রাণহিতা, পেনগঙ্গা, মঞ্জিরা।'
          }
        ]
      }
    ]
  },

  'Indian Polity': {
    subjectKey: 'Indian Polity',
    displayName: {
      en: 'Indian Polity & Governance',
      bn: 'ভারতীয় রাজনীতি ও শাসনব্যবস্থা (Indian Polity)',
      hi: 'भारतीय राजव्यवस्था'
    },
    emoji: '🏛️',
    gradient: 'from-purple-600 via-indigo-600 to-sky-600',
    accentColor: 'indigo',
    topics: [
      {
        id: 'pol-parliament',
        topicName: 'Parliament, President & Judiciary',
        topicNameBn: 'সংসদ, রাষ্ট্রপতি ও বিচারব্যবস্থা',
        topicNameHi: 'संसद, राष्ट्रपति और न्यायपालिका',
        chapterNumber: 1,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Lok Sabha, Rajya Sabha powers, Money Bill, President emergency powers (352, 356, 360), Supreme Court and High Courts writs.',
          bn: 'লোকসভা, রাজ্যসভা, অর্থবিল, রাষ্ট্রপতির জরুরি অবস্থা জারির ক্ষমতা (৩৫২, ৩৫৬, ৩৬০ ধারা) এবং সুপ্রিম কোর্টের রিট জারি করার ক্ষমতা।',
          hi: 'लोकसभा, राज्यसभा, राष्ट्रपति की आपातकालीन शक्तियां और सर्वोच्च न्यायालय।'
        },
        keyFormulasAndTricks: {
          en: [
            'National Emergency = Article 352; State Emergency (President Rule) = Article 356; Financial Emergency = Article 360.',
            'Money Bill can ONLY be introduced in Lok Sabha (Article 110).'
          ],
          bn: [
            'জরুরি অবস্থা মনে রাখার ট্রিক: ৩৫২ (জাতীয়) + ৪ = ৩৫৬ (রাজ্য/রাষ্ট্রপতি শাসন) + ৪ = ৩৬০ (আর্থিক জরুরি অবস্থা)।',
            'অর্থবিল (ধারা ১১০) শুধুমাত্র লোকসভায় উত্থাপিত হতে পারে।'
          ],
          hi: [
            'अनुच्छेद 352, 356 और 360 आपातकाल के प्रकार हैं।'
          ]
        },
        examTips: {
          en: 'Learn tenure, minimum age (Lok Sabha: 25, Rajya Sabha: 30, President: 35).',
          bn: 'ন্যূনতম বয়স: লোকসভা ২৫ বছর, রাজ্যসভা ৩০ বছর, রাষ্ট্রপতি ৩৫ বছর।',
          hi: 'न्यूनतम आयु सीमा हमेशा ध्यान रखें।'
        },
        sampleQuestions: [
          {
            id: 'pol-q1',
            subject: 'Indian Polity',
            topic: 'Parliament',
            difficulty: 'Easy',
            question: 'কোনো বিল "অর্থবিল" (Money Bill) কিনা তা চূড়ান্তভাবে কে নির্ধারণ করেন?',
            options: ['A. লোকসভার স্পিকার', 'B. রাষ্ট্রপতি', 'C. প্রধানমন্ত্রী', 'D. সুপ্রিম কোর্টের প্রধান বিচারপতি'],
            correctOptionIndex: 0,
            explanation: 'সংবিধানের ১১০(৩) ধারা অনুযায়ী কোনো বিল অর্থবিল কিনা সে বিষয়ে লোকসভার অধ্যক্ষের (স্পিকার) সিদ্ধান্তই চূড়ান্ত।',
            shortConcept: 'অর্থবিল নির্ধারণে স্পিকারের ক্ষমতা',
            rememberPoint: 'অর্থবিল রাজ্যসভা সর্বাধিক ১৪ দিন আটকে রাখতে পারে।'
          }
        ]
      }
    ]
  },

  'Indian Constitution': {
    subjectKey: 'Indian Constitution',
    displayName: {
      en: 'Indian Constitution & Articles',
      bn: 'ভারতীয় সংবিধান (Constitution & Articles)',
      hi: 'भारतीय संविधान'
    },
    emoji: '⚖️',
    gradient: 'from-blue-700 via-sky-600 to-indigo-600',
    accentColor: 'blue',
    topics: [
      {
        id: 'const-fr',
        topicName: 'Preamble, Fundamental Rights & Duties',
        topicNameBn: 'প্রস্তাবনা, মৌলিক অধিকার ও কর্তব্য',
        topicNameHi: 'प्रस्तावना, मौलिक अधिकार व कर्तव्य',
        chapterNumber: 1,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Articles 12-35 (Part III) Fundamental Rights, Article 32 constitutional remedies, Article 51A Fundamental Duties (42nd Amendment, 1976).',
          bn: '১২ থেকে ৩৫ ধারা (মৌলিক অধিকার), অনুচ্ছেদ ৩২ (সাংবিধানিক প্রতিবিধান), অনুচ্ছেদ ৫১ক (মৌলিক কর্তব্য - ৪২তম সংশোধনী, ১৯৭৬)।',
          hi: 'मूल अधिकार (अनुच्छेद 12-35) और मौलिक कर्तव्य (अनुच्छेद 51A)।'
        },
        keyFormulasAndTricks: {
          en: [
            'Fundamental Rights = Part III (Magna Carta of India).',
            'Fundamental Duties = Part IVA (Swaran Singh Committee, 11 duties).',
            'Right to Property removed by 44th Amendment 1978, now legal right (Art 300A).'
          ],
          bn: [
            'মৌলিক অধিকার = পার্ট ৩ (ভারতের ম্যাগনা কার্টা)।',
            'মৌলিক কর্তব্য = স্বর্ণ সিং কমিটির সুপারিশে ৪২তম সংশোধনীতে যুক্ত হয় (বর্তমানে ১১টি)।',
            'সম্পত্তির অধিকার ৪৪তম সংশোধনে মৌলিক অধিকার থেকে বাদ দিয়ে ৩০০ক ধারায় সাধারণ আইনি অধিকার করা হয়।'
          ],
          hi: [
            'भाग 3 = मूल अधिकार, भाग 4A = मूल कर्तव्य।'
          ]
        },
        examTips: {
          en: 'Writs under Article 32 (Habeas Corpus, Mandamus, Prohibition, Certiorari, Quo-Warranto) are top priority.',
          bn: '৫টি রিট (বন্দী প্রত্যক্ষীকরণ, পরমাদেশ, প্রতিষেধ, উৎপ্রেষণ, অধিকার পৃচ্ছা) বিশদে পড়ুন।',
          hi: 'अनुच्छेद 32 के तहत 5 रिट अवश्य याद करें।'
        },
        sampleQuestions: [
          {
            id: 'const-q1',
            subject: 'Indian Constitution',
            topic: 'Fundamental Rights',
            difficulty: 'Easy',
            question: 'ভারতীয় সংবিধানের কোন অনুচ্ছেদে অস্পৃশ্যতা দূরীকরণ (Abolition of Untouchability) নিশ্চিত করা হয়েছে?',
            options: ['A. অনুচ্ছেদ ১৭', 'B. অনুচ্ছেদ ১৪', 'C. অনুচ্ছেদ ১৯', 'D. অনুচ্ছেদ ২১'],
            correctOptionIndex: 0,
            explanation: 'সংবিধানের অনুচ্ছেদ ১৭ অস্পৃশ্যতা নিষিদ্ধ ও দণ্ডনীয় অপরাধ হিসেবে ঘোষণা করেছে।',
            shortConcept: 'অনুচ্ছেদ ১৭ = অস্পৃশ্যতা দূরীকরণ',
            rememberPoint: 'অনুচ্ছেদ ১৪: আইনের দৃষ্টিতে সমতা; অনুচ্ছেদ ১৮: খেতাব বিলোপ।'
          }
        ]
      }
    ]
  },

  'Indian Economy': {
    subjectKey: 'Indian Economy',
    displayName: {
      en: 'Indian Economy & Banking',
      bn: 'ভারতীয় অর্থনীতি ও ব্যাংকিং (Indian Economy)',
      hi: 'भारतीय अर्थव्यवस्था'
    },
    emoji: '📈',
    gradient: 'from-emerald-600 via-green-600 to-teal-600',
    accentColor: 'emerald',
    topics: [
      {
        id: 'econ-banking',
        topicName: 'National Income, Inflation & RBI Policy',
        topicNameBn: 'জাতীয় আয়, মুদ্রাস্ফীতি ও রিজার্ভ ব্যাংকের নীতি',
        topicNameHi: 'राष्ट्रीय आय, मुद्रास्फीति और आरबीआई नीतियां',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'High',
        conceptsSummary: {
          en: 'GDP vs GNP, Repo Rate, Reverse Repo Rate, CRR, SLR, Fiscal Deficit, and NITI Aayog Five-Year Plan transitions.',
          bn: 'জিডিপি ও জিএনপি, রেপো রেট, রিভার্স রেপো, সিআরআর, এসএলআর, মুদ্রাস্ফীতি নিয়ন্ত্রণ ও নীতি আয়োগের ভূমিকা।',
          hi: 'जीडीपी, रेपो रेट, रिवर्स रेपो, मुद्रास्फीति और नीति आयोग।'
        },
        keyFormulasAndTricks: {
          en: [
            'Repo Rate: Rate at which RBI lends short term funds to commercial banks.',
            'To control inflation: RBI INCREASES Repo rate and CRR to suck liquidity from market.'
          ],
          bn: [
            'রেপো রেট: যে সুদের হারে আরবিআই বাণিজ্যিক ব্যাংকগুলিকে ঋণ দেয়।',
            'মুদ্রাস্ফীতি নিয়ন্ত্রণের জন্য আরবিআই রেপো রেট বৃদ্ধি করে।'
          ],
          hi: [
            'रेपो दर बढ़ाने से बाजार में तरलता घटती है और मुद्रास्फीति नियंत्रित होती है।'
          ]
        },
        examTips: {
          en: 'RBI establishment year (1935, Hilton Young Commission) and nationalization (1949) are very common.',
          bn: 'আরবিআই প্রতিষ্ঠা ১৯৩৫ সালে এবং জাতীয়করণ ১৯৪৯ সালে।',
          hi: 'आरबीआई स्थापना 1935 व राष्ट्रीयकरण 1949।'
        },
        sampleQuestions: [
          {
            id: 'econ-q1',
            subject: 'Indian Economy',
            topic: 'RBI & Banking',
            difficulty: 'Easy',
            question: 'ভারতের কেন্দ্রীয় ব্যাংক "রিজার্ভ ব্যাংক অফ ইন্ডিয়া" (RBI) কোন সালে প্রতিষ্ঠিত হয়?',
            options: ['A. ১৯৩৫ সালের ১লা এপ্রিল', 'B. ১৯৪৭ সালের ১৫ই আগস্ট', 'C. ১৯৫০ সালের ২৬শে জানুয়ারি', 'D. ১৯৬৯ সালের ১৯শে জুলাই'],
            correctOptionIndex: 0,
            explanation: 'হিল্টন ইয়ং কমিশনের সুপারিশে রিজার্ভ ব্যাংক অফ ইন্ডিয়া অ্যাক্ট ১৯৩৪ অনুসারে ১৯৩৫ সালের ১লা এপ্রিল কলকাতায় আরবিআই প্রতিষ্ঠিত হয়।',
            shortConcept: 'আরবিআই প্রতিষ্ঠা ১ এপ্রিল ১৯৩৫',
            rememberPoint: 'আরবিআই-এর প্রথম গভর্নর ছিলেন স্যার ওসবোর্ন স্মিথ এবং প্রথম ভারতীয় গভর্নর সি. ডি. দেশমুখ।'
          }
        ]
      }
    ]
  },

  'General Science': {
    subjectKey: 'General Science',
    displayName: {
      en: 'General Science (Physics, Chem, Bio)',
      bn: 'সাধারণ বিজ্ঞান (General Science)',
      hi: 'सामान्य विज्ञान'
    },
    emoji: '🔬',
    gradient: 'from-cyan-600 via-blue-600 to-indigo-600',
    accentColor: 'cyan',
    topics: [
      {
        id: 'sci-everyday',
        topicName: 'Everyday Science & Discoveries',
        topicNameBn: 'দৈনন্দিন জীবনে বিজ্ঞান ও আবিষ্কার',
        topicNameHi: 'दैनिक जीवन में विज्ञान व आविष्कार',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'Very High',
        conceptsSummary: {
          en: 'SI units, scientific instruments, pH scale, vitamins & deficiency diseases, greenhouse gases.',
          bn: 'এসআই একক, বৈজ্ঞানিক পরিমাপক যন্ত্র, পিএইচ স্কেল, ভিটামিন ও অভাবজনিত রোগ, গ্রীনহাউস গ্যাস।',
          hi: 'एसआई मात्रक, पीएच मान, विटामिन और वैज्ञानिक उपकरण।'
        },
        keyFormulasAndTricks: {
          en: [
            'pH < 7 is Acidic; pH = 7 is Neutral; pH > 7 is Basic/Alkaline.',
            'Vitamin A = Night blindness; Vitamin C = Scurvy; Vitamin D = Rickets; Vitamin K = Blood clotting.'
          ],
          bn: [
            'ভিটামিন এ = রাতকানা; ভিটামিন বি১ = বেরিবেরি; ভিটামিন সি = স্কার্ভি; ভিটামিন ডি = রিকেট; ভিটামিন কে = রক্ত জমাট বাঁধতে সাহায্য করে।',
            'pH স্কেল আবিষ্কার করেছিলেন সোরেনসেন (১৯০৯)।'
          ],
          hi: [
            'विटामिन की कमी से होने वाले रोग सीधे पूछे जाते हैं।'
          ]
        },
        examTips: {
          en: 'SI units (Force: Newton, Work/Energy: Joule, Power: Watt, Pressure: Pascal) are guaranteed marks.',
          bn: 'মৌলিক ও লব্ধ রাশির এসআই একক নিয়মিত রিভিশন দিন।',
          hi: 'सभी प्रमुख भौतिक राशियों के एसआई मात्रक याद रखें।'
        },
        sampleQuestions: [
          {
            id: 'sci-q1',
            subject: 'General Science',
            topic: 'Units & Measurements',
            difficulty: 'Easy',
            question: 'আন্তর্জাতিক পদ্ধতিতে (SI) রোধের (Electrical Resistance) একক কী?',
            options: ['A. ওহম (Ohm)', 'B. অ্যাম্পিয়ার', 'C. ভোল্ট', 'D. ওয়াট'],
            correctOptionIndex: 0,
            explanation: 'তড়িৎ রোধের এসআই একক হলো ওহম (Ω)। জর্জ সাইমন ওহমের নামানুসারে এর নামকরণ করা হয়েছে।',
            shortConcept: 'রোধের একক ওহম (Ω)',
            rememberPoint: 'তড়িৎ প্রবাহের একক অ্যাম্পিয়ার, বিভবপ্রভেদের একক ভোল্ট।'
          }
        ]
      }
    ]
  },

  'Physics': {
    subjectKey: 'Physics',
    displayName: {
      en: 'Physics & Applied Mechanics',
      bn: 'পদার্থবিজ্ঞান (Physics)',
      hi: 'भौतिक विज्ञान'
    },
    emoji: '⚡',
    gradient: 'from-violet-600 via-purple-600 to-indigo-600',
    accentColor: 'purple',
    topics: [
      {
        id: 'phy-mechanics',
        topicName: 'Motion, Force, Gravitation & Optics',
        topicNameBn: 'গতিবিদ্যা, বল, মহাকর্ষ ও আলো',
        topicNameHi: 'गति, बल, गुरुत्वाकर्षण और प्रकाश',
        chapterNumber: 1,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Newton 3 laws of motion, kinetic and potential energy, total internal reflection, concave/convex mirrors and lenses.',
          bn: 'নিউটনের তিনটি গতিসূত্র, ভরবেগ সংরক্ষণ, মহাকর্ষ সূত্র, অভ্যন্তরীণ পূর্ণ প্রতিফলন এবং উত্তল ও অবতল লেন্সের ব্যবহার।',
          hi: 'न्यूटन के नियम, कार्य व ऊर्जा, और प्रकाश का अपवर्तन।'
        },
        keyFormulasAndTricks: {
          en: [
            'Total Internal Reflection: Mirage, sparkling of diamond, optical fiber communication.',
            'Dentist mirror & car headlights = Concave mirror (converging).',
            'Rear-view mirror of vehicles = Convex mirror (diverging, wide view field).'
          ],
          bn: [
            'অভ্যন্তরীণ পূর্ণ প্রতিফলন: মরীচিকা, হীরকের উজ্জ্বলতা ও অপটিক্যাল ফাইবার।',
            'গাড়ির রিয়ার-ভিউ ভিউ মিরর = উত্তল দর্পণ (কারণ ছোট ও সোজা প্রতিবিম্ব তৈরি করে বিস্তৃত এলাকা দেখায়)।',
            'দন্ত চিকিৎসকের দর্পণ ও হেডলাইট = অবতল দর্পণ।'
          ],
          hi: [
            'गाड़ियों का साइड मिरर = उत्तल दर्पण।',
            'मरीचिका = पूर्ण आंतरिक परावर्तन।'
          ]
        },
        examTips: {
          en: 'Applications of total internal reflection and mirror choices are high-frequency exam questions in Railways.',
          bn: 'রেলওয়ে পরীক্ষায় দর্পণ ও লেন্সের বাস্তব প্রয়োগ প্রচুর আসে।',
          hi: 'दर्पण और लेंस के अनुप्रयोग अच्छे से पढ़ें।'
        },
        sampleQuestions: [
          {
            id: 'phy-q1',
            subject: 'Physics',
            topic: 'Optics',
            difficulty: 'Easy',
            question: 'অপটিক্যাল ফাইবার (Optical Fibre) আলোর কোন ধর্মের ওপর ভিত্তি করে তথ্য পরিবহন করে?',
            options: ['A. অভ্যন্তরীণ পূর্ণ প্রতিফলন (Total Internal Reflection)', 'B. আলোর বিচ্ছুরণ', 'C. আলোর প্রতিসরণ', 'D. আলোর সমবর্তন'],
            correctOptionIndex: 0,
            explanation: 'অপটিক্যাল ফাইবারের কোরের মধ্য দিয়ে আলো অভ্যন্তরীণ পূর্ণ প্রতিফলনের মাধ্যমে অত্যন্ত দ্রুত গতিতে কোনো শক্তির অপচয় ছাড়াই সংকেত প্রেরণ করে।',
            shortConcept: 'অপটিক্যাল ফাইবার = অভ্যন্তরীণ পূর্ণ প্রতিফলন',
            rememberPoint: 'হীরকের অত্যধিক উজ্জ্বলতার কারণও এর সংকট কোণ কম ও অভ্যন্তরীণ পূর্ণ প্রতিফলন।'
          }
        ]
      }
    ]
  },

  'Chemistry': {
    subjectKey: 'Chemistry',
    displayName: {
      en: 'Chemistry & Elements',
      bn: 'রসায়নবিজ্ঞান (Chemistry)',
      hi: 'रसायन विज्ञान'
    },
    emoji: '🧪',
    gradient: 'from-pink-600 via-rose-600 to-amber-600',
    accentColor: 'pink',
    topics: [
      {
        id: 'chem-period',
        topicName: 'Periodic Table, Acids, Bases & Metals',
        topicNameBn: 'পর্যায় সারণি, অ্যাসিড, ক্ষার ও ধাতুবিদ্যা',
        topicNameHi: 'आवर्त सारणी, अम्ल, क्षार व धातु',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'High',
        conceptsSummary: {
          en: 'Modern Periodic Table (Moseley based on atomic number), common chemical formulas (Baking soda, Washing soda, Plaster of Paris), alloy compositions (Brass, Bronze).',
          bn: 'আধুনিক পর্যায় সারণি (পারমাণবিক সংখ্যার ওপর ভিত্তি করে), অ্যাসিড ও ক্ষারকের বৈশিষ্ট্য, নিত্যপ্রয়োজনীয় রাসায়নিক সংকেত (বেকিং সোডা, ওয়াশিং সোডা) ও সংকর ধাতু।',
          hi: 'आधुनिक आवर्त सारणी, प्रमुख रासायनिक सूत्र और मिश्र धातुएं।'
        },
        keyFormulasAndTricks: {
          en: [
            'Baking Soda = Sodium Bicarbonate (NaHCO₃).',
            'Washing Soda = Sodium Carbonate Decahydrate (Na₂CO₃·10H₂O).',
            'Brass = Copper + Zinc; Bronze = Copper + Tin.'
          ],
          bn: [
            'খাবার সোডা = সোডিয়াম বাইকার্বোনেট (NaHCO₃)।',
            'কাপড় কাচার সোডা = সোডিয়াম কার্বনেট (Na₂CO₃·10H₂O)।',
            'পিতল (Brass) = তামা (Cu) + দস্তা (Zn); কাঁসা (Bronze) = তামা (Cu) + টিন (Sn)।'
          ],
          hi: [
            'बेकिंग सोडा = NaHCO₃; धावन सोडा = Na₂CO₃·10H₂O।'
          ]
        },
        examTips: {
          en: 'Chemical names of everyday items (Bleaching powder, Plaster of Paris) appear in almost every GS paper.',
          bn: 'দৈনন্দিন রাসায়নিকের সাধারণ নাম ও সংকেত খুব মনোযোগ দিয়ে পড়ুন।',
          hi: 'दैनिक जीवन के रासायनिक नाम याद रखें।'
        },
        sampleQuestions: [
          {
            id: 'chem-q1',
            subject: 'Chemistry',
            topic: 'Everyday Chemistry',
            difficulty: 'Easy',
            question: 'খাবার সোডার (Baking Soda) রাসায়নিক নাম কী?',
            options: ['A. সোডিয়াম বাইকার্বোনেট (NaHCO₃)', 'B. সোডিয়াম কার্বনেট', 'C. ক্যালসিয়াম অক্সাইড', 'D. সোডিয়াম ক্লোরাইড'],
            correctOptionIndex: 0,
            explanation: 'খাবার সোডা হলো সোডিয়াম বাইকার্বোনেট (NaHCO₃)। উত্তপ্ত করলে এটি কার্বন ডাই অক্সাইড নির্গত করে কেক বা পাউরুটি ফোলাতে সাহায্য করে।',
            shortConcept: 'খাবার সোডা = NaHCO₃',
            rememberPoint: 'ওয়াশিং সোডার সংকেত হলো Na₂CO₃·10H₂O।'
          }
        ]
      }
    ]
  },

  'Biology': {
    subjectKey: 'Biology',
    displayName: {
      en: 'Biology & Human Physiology',
      bn: 'জীববিজ্ঞান ও শারীরবিদ্যা (Biology)',
      hi: 'जीव विज्ञान'
    },
    emoji: '🧬',
    gradient: 'from-green-600 via-emerald-600 to-teal-600',
    accentColor: 'emerald',
    topics: [
      {
        id: 'bio-cells',
        topicName: 'Cell Biology, Genetics & Human Body Systems',
        topicNameBn: 'কোষবিদ্যা, বংশগতি ও মানবদেহের অঙ্গসংস্থান',
        topicNameHi: 'कोशिका, आनुवंशिकी और मानव तंत्र',
        chapterNumber: 1,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Mitochondria (Powerhouse), Ribosome (Protein factory), Blood circulation (Universal donor O-, Universal recipient AB+), Endocrine hormones.',
          bn: 'মাইটোকনড্রিয়া (কোষের শক্তিঘর), রাইবোজোম (প্রোটিন তৈরির কারখানা), রক্ত সংবহন (সার্বজনীন দাতা O, গ্রহীতা AB), প্রধান অন্তঃক্ষরা গ্রন্থি ও হরমোন।',
          hi: 'कोशिका संरचना, माइटोकॉन्ड्रिया, रक्त समूह और अंतःस्रावी ग्रंथियां।'
        },
        keyFormulasAndTricks: {
          en: [
            'Powerhouse of cell = Mitochondria (ATP synthesis).',
            'Suicide bags = Lysosomes.',
            'Blood group O- is Universal Donor; AB+ is Universal Recipient.'
          ],
          bn: [
            'কোষের শক্তিঘর = মাইটোকনড্রিয়া (এটিপি তৈরি করে)।',
            'আত্মঘাতী থলি = লাইসোজোম।',
            'সার্বজনীন দাতা = ও (O-); সার্বজনীন গ্রহীতা = এবি (AB+)।'
          ],
          hi: [
            'कोशिका का पावरहाउस = माइटोकॉन्ड्रिया; आत्मघाती थैली = लाइसोसोम।'
          ]
        },
        examTips: {
          en: 'Endocrine glands (Insulin secreted by Beta cells of Pancreas, Master gland = Pituitary) are exam staples.',
          bn: 'ইনসুলিন অগ্ন্যাশয়ের আইলেটস অফ ল্যাঙ্গারহ্যান্সের বিটা কোষ থেকে ক্ষরিত হয়।',
          hi: 'इंसुलिन अग्न्याशय की बीटा कोशिकाओं से स्रावित होता है।'
        },
        sampleQuestions: [
          {
            id: 'bio-q1',
            subject: 'Biology',
            topic: 'Cell Biology',
            difficulty: 'Easy',
            question: 'কোষের "শক্তিঘর" (Powerhouse of the Cell) কাকে বলা হয়?',
            options: ['A. মাইটোকনড্রিয়া', 'B. লাইসোজোম', 'C. রাইবোজোম', 'D. গলগি বডি'],
            correctOptionIndex: 0,
            explanation: 'মাইটোকনড্রিয়ায় কোষীয় শ্বসনের মাধ্যমে জৈব শক্তি এটিপি (ATP) উৎপাদিত ও সঞ্চিত হয় বলে একে কোষের শক্তিঘর বলা হয়।',
            shortConcept: 'কোষের শক্তিঘর = মাইটোকনড্রিয়া',
            rememberPoint: 'লাইসোজোমকে বলা হয় আত্মঘাতী থলি (Suicide Bag)।'
          }
        ]
      }
    ]
  },

  'Mathematics': {
    subjectKey: 'Mathematics',
    displayName: {
      en: 'Quantitative Mathematics',
      bn: 'গণিত ও পাটিগণিত (Mathematics)',
      hi: 'गणित व अंकगणित'
    },
    emoji: '📐',
    gradient: 'from-indigo-600 via-blue-600 to-cyan-600',
    accentColor: 'indigo',
    topics: [
      {
        id: 'math-perc',
        topicName: 'Percentage, Profit-Loss & Ratio',
        topicNameBn: 'শতকরা, লাভ-ক্ষতি ও অনুপাত-সমানুপাত',
        topicNameHi: 'प्रतिशत, लाभ-हानि व अनुपात',
        chapterNumber: 1,
        estimatedMinutes: 30,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Fraction to percentage conversions, successive percentage change, Cost Price, Selling Price, Discount, and proportionality.',
          bn: 'ভগ্নাংশ থেকে শতকরা রূপান্তর, ধারাবাহিক লাভ-ক্ষতি, ক্রয়মূল্য ও বিক্রয়মূল্য, ছাড় (Discount) এবং অনুপাত-সমানুপাতের শর্টকাট টেকনিক।',
          hi: 'प्रतिशत मान, क्रय-विक्रय मूल्य, छूट और अनुपात की सरल विधियां।'
        },
        keyFormulasAndTricks: {
          en: [
            '1/2 = 50%, 1/3 = 33.33%, 1/4 = 25%, 1/5 = 20%, 1/6 = 16.66%, 1/8 = 12.5%, 1/9 = 11.11%.',
            'Successive change formula: Net % = a + b + (ab / 100).'
          ],
          bn: [
            'ভগ্নাংশ মান মুখস্থ রাখুন: ১/২ = ৫০%, ১/৪ = ২৫%, ১/৫ = ২০%, ১/৮ = ১২.৫%, ১/৬ = ১৬.৬৬%।',
            'ধারাবাহিক পরিবর্তনের সূত্র: a + b + (ab / ১০০)।'
          ],
          hi: [
            'सक्सेसिव प्रतिशत परिवर्तन = a + b + (ab / 100)।'
          ]
        },
        examTips: {
          en: 'Convert percentages to simplified ratios to solve questions without long decimal calculations.',
          bn: 'শতকরাকে অনুপাতের মাধ্যমে সমাধান করলে সময় বাঁচবে।',
          hi: 'प्रतिशत को भिन्न में बदलकर तेजी से गणना करें।'
        },
        sampleQuestions: [
          {
            id: 'math-q1',
            subject: 'Mathematics',
            topic: 'Percentage',
            difficulty: 'Easy',
            question: 'যদি চিনির মূল্য ২০% বৃদ্ধি পায়, তবে কোনো পরিবার খরচ অপরিবর্তিত রাখতে ব্যবহারের পরিমাণ শতকরা কত হ্রাস করবে?',
            options: ['A. ১৬.৬৬%', 'B. ২০%', 'C. ২৫%', 'D. ১৫%'],
            correctOptionIndex: 0,
            explanation: 'খরচ স্থির রাখার সূত্র: [r / (100 + r)] × 100% = [20 / 120] × 100% = (1/6) × 100% = ১৬.৬৬%।',
            shortConcept: 'দাম বৃদ্ধি হলে ব্যবহারে হ্রাস = [r / (100+r)] × 100%',
            rememberPoint: '১/৬ ভগ্নাংশের শতকরা রূপান্তর ১৬.৬৬% মনে রাখুন।'
          }
        ]
      }
    ]
  },

  'General Awareness': {
    subjectKey: 'General Awareness',
    displayName: {
      en: 'General Awareness & Global Facts',
      bn: 'সাধারণ সচেতনতা (General Awareness)',
      hi: 'सामान्य जागरूकता'
    },
    emoji: '🔔',
    gradient: 'from-sky-600 via-blue-600 to-indigo-600',
    accentColor: 'sky',
    topics: [
      {
        id: 'ga-intl',
        topicName: 'International Organizations, Summits & Capitals',
        topicNameBn: 'আন্তর্জাতিক সংস্থা, সদর দপ্তর ও শীর্ষ সম্মেলন',
        topicNameHi: 'अंतर्राष्ट्रीय संगठन, मुख्यालय व शिखर सम्मेलन',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'Very High',
        conceptsSummary: {
          en: 'UN bodies (UNESCO, WHO, IMF, World Bank), BRICS, G20, ASEAN, SAARC headquarters, and country currencies.',
          bn: 'জাতিসংঘের বিভিন্ন সংস্থা (ইউনেস্কো, হু, আইএমএফ, বিশ্বব্যাংক), ব্রিকস, জি-২০, আসিয়ান, সার্কের সদর দপ্তর ও বিভিন্ন দেশের মুদ্রা।',
          hi: 'यूएनओ, विश्व बैंक, आईएमएफ, जी20 और विभिन्न देशों के मुख्यालय।'
        },
        keyFormulasAndTricks: {
          en: [
            'Money/Finance based UN bodies are in Washington D.C. (IMF & World Bank).',
            'Geneva hosts: WHO, WTO, ILO, WIPO.',
            'UNESCO is in Paris, France.'
          ],
          bn: [
            'টাকা ও ব্যাংকিং সংস্থা ওয়াশিংটন ডিসিতে (IMF এবং World Bank)।',
            'জেনেভায় সদর দপ্তর: WHO, WTO, ILO।',
            'ইউনেস্কোর সদর দপ্তর প্যারিসে।'
          ],
          hi: [
            'वित्त से जुड़े संगठन (IMF, WB) वाशिंगटन में हैं।'
          ]
        },
        examTips: {
          en: 'Check recent member additions to BRICS and NATO for current exams.',
          bn: 'সংস্থাগুলির সাম্প্রতিকতম সদস্য দেশ ও বর্তমান প্রধানদের নাম রিভিশন দিন।',
          hi: 'नए सदस्य देशों की सूची याद रखें।'
        },
        sampleQuestions: [
          {
            id: 'ga-q1',
            subject: 'General Awareness',
            topic: 'International Organizations',
            difficulty: 'Easy',
            question: 'ইউনেস্কোর (UNESCO) প্রধান কার্যালয় বা সদর দপ্তর কোথায় অবস্থিত?',
            options: ['A. প্যারিস (ফ্রান্স)', 'B. জেনেভা', 'C. নিউ ইয়র্ক', 'D. ভিয়েনা'],
            correctOptionIndex: 0,
            explanation: 'ইউনেস্কোর (জাতিসংঘ শিক্ষা, বিজ্ঞান ও সংস্কৃতি সংস্থা) সদর দপ্তর ফ্রান্সের প্যারিসে অবস্থিত।',
            shortConcept: 'ইউনেস্কো সদর দপ্তর = প্যারিস',
            rememberPoint: 'ইউনেস্কো প্রতিষ্ঠিত হয়েছিল ১৯৪৫ সালে।'
          }
        ]
      }
    ]
  },

  'Computer': {
    subjectKey: 'Computer',
    displayName: {
      en: 'Computer Knowledge & IT',
      bn: 'কম্পিউটার জ্ঞান ও প্রযুক্তি (Computer)',
      hi: 'कंप्यूटर ज्ञान'
    },
    emoji: '💻',
    gradient: 'from-slate-700 via-gray-800 to-zinc-900',
    accentColor: 'slate',
    topics: [
      {
        id: 'comp-basics',
        topicName: 'Computer Fundamentals, Networking & Shortcuts',
        topicNameBn: 'কম্পিউটারের মৌলিক ধারণা, নেটওয়ার্কিং ও শর্টকাট কি',
        topicNameHi: 'कंप्यूटर मूल बातें, नेटवर्किंग व शॉर्टकट',
        chapterNumber: 1,
        estimatedMinutes: 20,
        importance: 'High',
        conceptsSummary: {
          en: 'Hardware vs Software, RAM vs ROM, IP address, HTTP vs HTTPS, full forms (URL, PDF, RAM, CPU), and MS Office shortcut keys.',
          bn: 'হার্ডওয়্যার ও সফটওয়্যার, র‍্যাম ও রম, আইপি অ্যাড্রেস, এইচটিটিপিএস, গুরুত্বপূর্ণ পূর্ণরূপ এবং এমএস অফিস শর্টকাট কি।',
          hi: 'रैम, रोम, हार्डवेयर, सॉफ्टवेयर और महत्वपूर्ण शॉर्टकट की।'
        },
        keyFormulasAndTricks: {
          en: [
            'RAM is Volatile (loses data on power off); ROM is Non-Volatile.',
            'Ctrl + Z = Undo; Ctrl + Y = Redo; Ctrl + K = Insert Hyperlink.'
          ],
          bn: [
            'র‍্যাম (RAM) হলো উদ্বায়ী (বিদ্যুৎ চলে গেলে তথ্য মুছে যায়); রম (ROM) স্থায়ী।',
            'Ctrl + K = হাইপারলিঙ্ক যোগ করার শর্টকাট।'
          ],
          hi: [
            'RAM अस्थाई मेमोरी है और ROM स्थाई।'
          ]
        },
        examTips: {
          en: 'Memory units hierarchy: Bit -> Byte (8 bits) -> KB (1024 bytes) -> MB -> GB -> TB -> PB.',
          bn: 'মেমোরি একক: ১ বাইট = ৮ বিট; ১ কেবি = ১০২৪ বাইট; ১ এমবি = ১০২৪ কেবি।',
          hi: 'मेमोरी इकाइयों का क्रम ध्यान रखें।'
        },
        sampleQuestions: [
          {
            id: 'comp-q1',
            subject: 'Computer',
            topic: 'Hardware & Memory',
            difficulty: 'Easy',
            question: 'কম্পিউটারের কোন মেমোরি বিদ্যুৎ সংযোগ বিচ্ছিন্ন হওয়ার সাথে সাথে সংরক্ষিত সমস্ত তথ্য হারিয়ে ফেলে (Volatile Memory)?',
            options: ['A. RAM (Random Access Memory)', 'B. ROM', 'C. Hard Disk', 'D. Pen Drive'],
            correctOptionIndex: 0,
            explanation: 'RAM হলো একটি ভোলাটাইল বা উদ্বায়ী মেমোরি। কম্পিউটার বন্ধ করলে এতে থাকা তথ্য মুছে যায়।',
            shortConcept: 'RAM = Volatile Memory',
            rememberPoint: 'ROM হলো নন-ভোলাটাইল বা স্থায়ী মেমোরি।'
          }
        ]
      }
    ]
  },

  'Environment': {
    subjectKey: 'Environment',
    displayName: {
      en: 'Environment, Ecology & Biodiversity',
      bn: 'পরিবেশবিদ্যা ও বাস্তুতন্ত্র (Environment)',
      hi: 'पर्यावरण व पारिस्थितिकी'
    },
    emoji: '🌿',
    gradient: 'from-teal-600 via-emerald-600 to-green-700',
    accentColor: 'teal',
    topics: [
      {
        id: 'env-eco',
        topicName: 'Ecosystem, Biodiversity & Climate Treaties',
        topicNameBn: 'বাস্তুতন্ত্র, জীববৈচিত্র্য ও পরিবেশ চুক্তি',
        topicNameHi: 'पारिस्थितिकी तंत्र, जैव विविधता व पर्यावरण समझौते',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'High',
        conceptsSummary: {
          en: 'Food chain trophic levels, 10% energy law (Lindeman), Ramsar Convention (wetlands), Montreal Protocol (Ozone layer), Project Tiger (1973).',
          bn: 'খাদ্যশৃঙ্খল ও পুষ্টিস্তর, লিন্ডেম্যানের ১০% শক্তির সূত্র, রামসার কনভেনশন (জলাভূমি), মন্ট্রিল প্রোটোকল (ওজোন স্তর রক্ষা) এবং প্রজেক্ট টাইগার (১৯৭৩)।',
          hi: 'खाद्य श्रृंखला, रामसर स्थल, मॉन्ट्रियल प्रोटोकॉल और प्रोजेक्ट टाइगर।'
        },
        keyFormulasAndTricks: {
          en: [
            'Montreal Protocol (1987) = Protection of Ozone layer (CFC phaseout).',
            'Kyoto Protocol (1997) = Greenhouse gas reduction.',
            'Project Tiger launched in 1973 from Jim Corbett National Park.'
          ],
          bn: [
            'মন্ট্রিল প্রোটোকল (১৯৮৭) = ওজোন স্তর সুরক্ষা (সিএফসি বর্জন)।',
            'কিয়োটো প্রোটোকল (১৯৯৭) = গ্রীনহাউস গ্যাস হ্রাস।',
            'ভারতে প্রজেক্ট টাইগার চালু হয় ১৯৭৩ সালে।'
          ],
          hi: [
            'मॉन्ट्रियल प्रोटोकॉल ओजोन परत से संबंधित है।'
          ]
        },
        examTips: {
          en: 'Important dates: World Environment Day (June 5), World Ozone Day (Sept 16), Earth Day (April 22).',
          bn: 'পরিবেশ দিবস ৫ই জুন, ওজোন দিবস ১৬ই সেপ্টেম্বর, ধরিত্রী দিবস ২২শে এপ্রিল।',
          hi: 'विश्व पर्यावरण दिवस 5 जून को मनाया जाता है।'
        },
        sampleQuestions: [
          {
            id: 'env-q1',
            subject: 'Environment',
            topic: 'Environmental Protocols',
            difficulty: 'Easy',
            question: 'বায়ুমণ্ডলের ওজোন স্তর সুরক্ষার জন্য কোন আন্তর্জাতিক চুক্তিটি ১৯৮৭ সালে স্বাক্ষরিত হয়েছিল?',
            options: ['A. মন্ট্রিল প্রোটোকল (Montreal Protocol)', 'B. কিয়োটো প্রোটোকল', 'C. প্যারিস চুক্তি', 'D. রামসার কনভেনশন'],
            correctOptionIndex: 0,
            explanation: '১৯৮৭ সালে কানাডার মন্ট্রিলে ওজোন হ্রাসকারী পদার্থ যেমন সিএফসি নিয়ন্ত্রণের জন্য মন্ট্রিল প্রোটোকল গৃহীত হয়।',
            shortConcept: 'মন্ট্রিল প্রোটোকল = ওজোন স্তর সংরক্ষণ',
            rememberPoint: 'প্রতি বছর ১৬ই সেপ্টেম্বর বিশ্ব ওজোন দিবস পালিত হয়।'
          }
        ]
      }
    ]
  },

  'Indian Culture': {
    subjectKey: 'Indian Culture',
    displayName: {
      en: 'Indian Culture, Dances & Heritage',
      bn: 'ভারতীয় সংস্কৃতি ও ঐতিহ্য (Indian Culture)',
      hi: 'भारतीय संस्कृति व कला'
    },
    emoji: '🛕',
    gradient: 'from-amber-600 via-yellow-600 to-orange-600',
    accentColor: 'amber',
    topics: [
      {
        id: 'cult-dance',
        topicName: 'Classical Dances, Music & Festivals',
        topicNameBn: 'ধ্রুপদী নৃত্য, বাদ্যযন্ত্র ও আঞ্চলিক উৎসব',
        topicNameHi: 'शास्त्रीय नृत्य, वाद्ययंत्र और प्रमुख उत्सव',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'Very High',
        conceptsSummary: {
          en: '8 Classical dances recognized by Sangeet Natak Akademi (Bharatanatyam, Kathak, Kathakali, Mohiniyattam, Odissi, Kuchipudi, Manipuri, Sattriya), folk dances (Bihu, Garba, Ghoomar, Chhau), eminent instrumentalists.',
          bn: 'ভারতের ৮টি ধ্রুপদী নৃত্য (ভরতনাট্যম, কথক, কথাকলি, মোহিনীআট্টম, ওড়িশি, কুচিপুড়ি, মণিপুরী, সত্রীয়া), প্রধান লোকনৃত্য (বিহু, গরবা, ঘুমর, ছৌ) এবং প্রখ্যাত সংগীতশিল্পীদের বাদ্যযন্ত্র।',
          hi: '8 शास्त्रीय नृत्य, लोक नृत्य व प्रमुख संगीत वाद्ययंत्र।'
        },
        keyFormulasAndTricks: {
          en: [
            'Bharatanatyam -> Tamil Nadu; Kathak -> North India; Kathakali & Mohiniyattam -> Kerala; Kuchipudi -> Andhra Pradesh; Sattriya -> Assam.'
          ],
          bn: [
            'ভরতনাট্যম -> তামিলনাড়ু; কথাকলি ও মোহিনীআট্টম -> কেরালা; কুচিপুড়ি -> অন্ধ্রপ্রদেশ; সত্রীয়া -> আসাম; কথক -> উত্তর প্রদেশ।'
          ],
          hi: [
            'भरतनाट्यम = तमिलनाडु; कथकली = केरल; कुचिपुड़ी = आंध्र प्रदेश।'
          ]
        },
        examTips: {
          en: 'Match exponents with instruments: Hariprasad Chaurasia (Flute), Zakir Hussain (Tabla), Bismillah Khan (Shehnai), Shivkumar Sharma (Santoor).',
          bn: 'বিখ্যাত বাদকদের নাম: হরিপ্রসাদ চৌরাসিয়া (বাঁশি), জাকির হোসেন (তবলা), বিসমিল্লাহ খান (সানাই), রবিশঙ্কর (সেতার)।',
          hi: 'प्रमुख वादक और उनके वाद्ययंत्र अवश्य याद करें।'
        },
        sampleQuestions: [
          {
            id: 'cult-q1',
            subject: 'Indian Culture',
            topic: 'Classical Dances',
            difficulty: 'Easy',
            question: '"কুচিপুড়ি" (Kuchipudi) ধ্রুপদী নৃত্যটি ভারতের কোন রাজ্যের সংস্কৃতিতে উৎপন্ন?',
            options: ['A. অন্ধ্রপ্রদেশ', 'B. তামিলনাড়ু', 'C. কেরালা', 'D. কর্ণাটক'],
            correctOptionIndex: 0,
            explanation: 'কুচিপুড়ি হলো অন্ধ্রপ্রদেশের কৃষ্ণা জেলার কুচিপুড়ি গ্রামের নামানুসারে সৃষ্ট একটি অন্যতম প্রাচীন ভারতীয় ধ্রুপদী নৃত্যনাট্য।',
            shortConcept: 'কুচিপুড়ি = অন্ধ্রপ্রদেশ',
            rememberPoint: 'তামিলনাড়ুর নৃত্য হলো ভরতনাট্যম এবং কেরালার নৃত্য হলো কথাকলি।'
          }
        ]
      }
    ]
  },

  'Sports': {
    subjectKey: 'Sports',
    displayName: {
      en: 'Sports, Games & Terminology',
      bn: 'ক্রীড়া সংবাদ ও জ্ঞান (Sports & Games)',
      hi: 'खेल कूद'
    },
    emoji: '⚽',
    gradient: 'from-orange-600 via-amber-600 to-yellow-600',
    accentColor: 'orange',
    topics: [
      {
        id: 'sports-events',
        topicName: 'Olympics, Trophies & Terminology',
        topicNameBn: 'অলিম্পিক, ট্রফি ও খেলাধুলার পরিভাষা',
        topicNameHi: 'ओलंपिक, ट्रॉफियां व खेल शब्दावली',
        chapterNumber: 1,
        estimatedMinutes: 20,
        importance: 'High',
        conceptsSummary: {
          en: 'Olympic venues and history, Grand Slam tennis tournaments in chronological order, cricket/football cups (Ranji Trophy, Durand Cup, Thomas Cup).',
          bn: 'অলিম্পিক ক্রীড়া, গ্র্যান্ড স্ল্যাম টেনিস টুর্নামেন্ট (অস্ট্রেলিয়ান ওপেন, ফরাসি ওপেন, উইম্বলডন, ইউএস ওপেন), ফুটবল ও ক্রিকেটের ঐতিহ্যবাহী কাপ ও ট্রফি।',
          hi: 'ग्रैंड स्लैम का क्रम, प्रमुख कप, ट्रॉफियां और शब्दावली।'
        },
        keyFormulasAndTricks: {
          en: [
            'Grand Slam Order: Australian Open (Hard) -> French Open (Clay) -> Wimbledon (Grass) -> US Open (Hard).'
          ],
          bn: [
            'গ্র্যান্ড স্ল্যামের সঠিক বার্ষিক ক্রম: অস্ট্রেলিয়ান ওপেন -> ফরাসি ওপেন -> উইম্বলডন -> ইউএস ওপেন।'
          ],
          hi: [
            'ऑस्ट्रेलियन, फ्रेंच, विंबलडन व यूएस ओपन।'
          ]
        },
        examTips: {
          en: 'Durand Cup is Asia\'s oldest football tournament, first played in Shimla (1888).',
          bn: 'ডুরান্ড কাপ হলো এশিয়ার প্রাচীনতম ফুটবল প্রতিযোগিতা (১৮৮৮)।',
          hi: 'डूरंड कप एशिया का सबसे पुराना फुटबॉल टूर्नामेंट है।'
        },
        sampleQuestions: [
          {
            id: 'sports-q1',
            subject: 'Sports',
            topic: 'Cups & Trophies',
            difficulty: 'Easy',
            question: 'ভারতের প্রাচীনতম এবং বিশ্বের তৃতীয় প্রাচীনতম ফুটবল টুর্নামেন্ট কোনটি?',
            options: ['A. ডুরান্ড কাপ (Durand Cup)', 'B. সন্তোষ ট্রফি', 'C. রোভার্স কাপ', 'D. আই-লিগ'],
            correctOptionIndex: 0,
            explanation: '১৮৮৮ সালে হিমাচল প্রদেশের সিমলায় স্যার মর্টিমার ডুরান্ড কর্তৃক প্রতিষ্ঠিত ডুরান্ড কাপ হলো এশিয়ার সবচেয়ে প্রাচীন ফুটবল টুর্নামেন্ট।',
            shortConcept: 'ডুরান্ড কাপ = প্রাচীনতম ফুটবল কাপ',
            rememberPoint: 'সন্তোষ ট্রফি হলো ভারতের সিনিয়র জাতীয় ফুটবল চ্যাম্পিয়নশিপ।'
          }
        ]
      }
    ]
  },

  'Government Schemes': {
    subjectKey: 'Government Schemes',
    displayName: {
      en: 'Government Schemes & Welfare',
      bn: 'সরকারি প্রকল্প ও সামাজিক উন্নয়ন (Govt Schemes)',
      hi: 'सरकारी योजनाएं'
    },
    emoji: '📋',
    gradient: 'from-blue-600 via-cyan-600 to-indigo-600',
    accentColor: 'blue',
    topics: [
      {
        id: 'scheme-central',
        topicName: 'Flagship Central & State Schemes',
        topicNameBn: 'কেন্দ্রীয় ও রাজ্য সরকারের ফ্ল্যাগশিপ প্রকল্প',
        topicNameHi: 'प्रमुख केंद्रीय व राज्य कल्याणकारी योजनाएं',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'Very High',
        conceptsSummary: {
          en: 'PM-KISAN, Ayushman Bharat (PM-JAY), Jal Jeevan Mission, PM Awas Yojana, MGNREGA, and flagship state welfare programs.',
          bn: 'প্রধানমন্ত্রী কিষাণ সম্মান নিধি (PM-KISAN), আয়ুষ্মান ভারত (PM-JAY), জল জীবন মিশন, প্রধানমন্ত্রী আবাস যোজনা, একশো দিনের কাজ (MGNREGA)।',
          hi: 'पीएम किसान, आयुष्मान भारत, जल जीवन मिशन और मनरेगा।'
        },
        keyFormulasAndTricks: {
          en: [
            'PM-KISAN provides Rs 6,000 annually in 3 equal installments of Rs 2,000.',
            'Ayushman Bharat (PM-JAY) provides Rs 5 lakh health insurance per family per year.'
          ],
          bn: [
            'পিএম-কিষাণ প্রকল্পে কৃষকদের বার্ষিক ৬,০০০ টাকা (২,০০০ টাকার ৩টি কিস্তিতে) দেওয়া হয়।',
            'আয়ুষ্মান ভারত প্রকল্পে পরিবার প্রতি বার্ষিক ৫ লাখ টাকার স্বাস্থ্য সুরক্ষা মেলে।'
          ],
          hi: [
            'पीएम किसान = 6000 रुपये प्रति वर्ष; आयुष्मान भारत = 5 लाख का स्वास्थ्य बीमा।'
          ]
        },
        examTips: {
          en: 'Ministry under which each scheme operates is a favorite exam trick.',
          bn: 'কোন প্রকল্পটি কোন মন্ত্রক পরিচালনা করে (যেমন জল জীবন মিশন - জলশক্তি মন্ত্রক) তা নোট করুন।',
          hi: 'संबंधित मंत्रालय का नाम ध्यान रखें।'
        },
        sampleQuestions: [
          {
            id: 'sch-q1',
            subject: 'Government Schemes',
            topic: 'Health Schemes',
            difficulty: 'Easy',
            question: '"আয়ুষ্মান ভারত প্রধানমন্ত্রী জন আরোগ্য যোজনা" (PM-JAY) এর অধীনে পরিবার প্রতি বার্ষিক কত টাকার স্বাস্থ্য সুরক্ষা প্রদান করা হয়?',
            options: ['A. ৫ লক্ষ টাকা', 'B. ২ লক্ষ টাকা', 'C. ১০ লক্ষ টাকা', 'D. ৩ লক্ষ টাকা'],
            correctOptionIndex: 0,
            explanation: 'আয়ুষ্মান ভারত হলো বিশ্বের সর্ববৃহৎ সরকার-অর্থায়িত স্বাস্থ্য প্রকল্প যা দুর্বল পরিবারগুলিকে প্রতি বছর ৫ লাখ টাকা পর্যন্ত ক্যাশলেস সেকেন্ডারি ও টারশিয়ারি হাসপাতালে চিকিৎসার সুযোগ দেয়।',
            shortConcept: 'আয়ুষ্মান ভারত = ৫ লক্ষ টাকার সুরক্ষা',
            rememberPoint: 'এটি ২০১৮ সালের ২৩শে সেপ্টেম্বর ঝাড়খণ্ডের রাঁচি থেকে চালু হয়।'
          }
        ]
      }
    ]
  },

  'Railway GK': {
    subjectKey: 'Railway GK',
    displayName: {
      en: 'Indian Railways GK & Zones',
      bn: 'রেলওয়ে জিকে ও জোন (Railway GK)',
      hi: 'रेलवे सामान्य ज्ञान'
    },
    emoji: '🚂',
    gradient: 'from-red-600 via-orange-600 to-amber-600',
    accentColor: 'red',
    topics: [
      {
        id: 'rly-history',
        topicName: 'History, Zones, Vande Bharat & Tech',
        topicNameBn: 'রেলের ইতিহাস, জোন, বন্দে ভারত ও প্রযুক্তি',
        topicNameHi: 'रेल इतिहास, प्रमुख ज़ोन व वंदे भारत एक्सप्रेस',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'Very High',
        conceptsSummary: {
          en: 'First passenger train (1853, Bombay to Thane, 34 km), 18 Railway Zones and their HQs, Kavach automatic train protection system, Vande Bharat (Train 18).',
          bn: 'ভারতের প্রথম যাত্রীবাহী ট্রেন (১৬ এপ্রিল ১৮৫৩, বোম্বাই থেকে থানে, ৩৪ কিমি), ১৮টি রেলওয়ে জোন ও তাদের সদর দপ্তর, ভারতের স্বয়ংক্রিয় সুরক্ষা ব্যবস্থা "কবচ" (Kavach), বন্দে ভারত এক্সপ্রেস।',
          hi: '1853 की पहली ट्रेन, 18 रेलवे ज़ोन के मुख्यालय और कवच तकनीक।'
        },
        keyFormulasAndTricks: {
          en: [
            'First Train: 16 April 1853 (Lord Dalhousie). 3 locomotives: Sultan, Sindh, Sahib.',
            'Eastern Railway & South Eastern Railway HQ = Kolkata.',
            'Northern Railway HQ = New Delhi; Western & Central Railway = Mumbai.'
          ],
          bn: [
            'প্রথম ট্রেন: ১৬ এপ্রিল ১৮৫৩ (লর্ড ডালহৌসি)। ৩টি ইঞ্জিন: সুলতান, সিন্ধু, সাহেব।',
            'পূর্ব রেল (ER), দক্ষিণ-পূর্ব রেল (SER) এবং কলকাতা মেট্রোর সদর দপ্তর কলকাতায় অবস্থিত।',
            'রেলের স্বয়ংক্রিয় ট্রেন সুরক্ষা প্রযুক্তি = কবচ (Kavach)।'
          ],
          hi: [
            '16 अप्रैल 1853 को मुंबई से ठाणे पहली ट्रेन चली।'
          ]
        },
        examTips: {
          en: 'Railway Zone Headquarters matching questions are guaranteed 2-3 marks in RRB NTPC and Group D.',
          bn: 'রেলওয়ে জোনের সদর দপ্তর মুখস্থ রাখা আবশ্যক (যেমন উত্তর-পূর্ব রেল = গোরক্ষপুর, উত্তর রেল = নতুন দিল্লি)।',
          hi: 'रेलवे ज़ोन के मुख्यालय अवश्य याद रखें।'
        },
        sampleQuestions: [
          {
            id: 'rly-q1',
            subject: 'Railway GK',
            topic: 'Railway History',
            difficulty: 'Easy',
            question: 'ভারতে প্রথম যাত্রীবাহী ট্রেন কোন সালে এবং কোন দুই স্টেশনের মধ্যে চলাচল করেছিল?',
            options: [
              'A. ১৮৫৩ সালে, বোম্বাই থেকে থানে',
              'B. ১৮৫৪ সালে, হাওড়া থেকে হুগলি',
              'C. ১৮৫৬ সালে, মাদ্রাজ থেকে আরকোট',
              'D. ১৯২৫ সালে, বোম্বাই থেকে কুরলা'
            ],
            correctOptionIndex: 0,
            explanation: '১৬ই এপ্রিল ১৮৫৩ সালে লর্ড ডালহৌসির আমলে ভারতের প্রথম যাত্রীবাহী ট্রেন বোম্বাইয়ের বোরিবন্দর থেকে থানের মধ্যে ৩৪ কিমি দূরত্ব অতিক্রম করে।',
            shortConcept: 'প্রথম ট্রেন ১৮৫৩, বোম্বাই-থানে',
            rememberPoint: 'পশ্চিমবঙ্গে প্রথম ট্রেন চলেছিল ১৫ আগস্ট ১৮৫৪ সালে হাওড়া থেকে হুগলির মধ্যে।'
          }
        ]
      }
    ]
  },

  'Static GK': {
    subjectKey: 'Static GK',
    displayName: {
      en: 'Static GK & National Records',
      bn: 'স্ট্যাটিক জিকে ও ভারতের রেকর্ড (Static GK)',
      hi: 'स्टैटिक सामान्य ज्ञान'
    },
    emoji: '📍',
    gradient: 'from-violet-600 via-indigo-600 to-purple-700',
    accentColor: 'indigo',
    topics: [
      {
        id: 'st-superlatives',
        topicName: 'First in India, Highest, Longest & Monuments',
        topicNameBn: 'ভারতের দীর্ঘতম, উচ্চতম, প্রথম ব্যক্তি ও স্মারক',
        topicNameHi: 'भारत में प्रथम, सबसे लंबा, ऊंचा व राष्ट्रीय स्मारक',
        chapterNumber: 1,
        estimatedMinutes: 25,
        importance: 'Very High',
        conceptsSummary: {
          en: 'Statue of Unity (tallest statue), Atal Tunnel, First President/PM, First Woman Governor/CM, National Parks and UNESCO Heritage Sites in India.',
          bn: 'স্ট্যাচু অফ ইউনিটি (বিশ্বের উচ্চতম মূর্তি), অটল টানেল, ভারতের প্রথম রাষ্ট্রপতি, প্রধানমন্ত্রী, প্রথম মহিলা রাজ্যপাল/মুখ্যমন্ত্রী, জাতীয় উদ্যান ও ব্যাঘ্র প্রকল্প।',
          hi: 'स्टैच्यू ऑफ यूनिटी, भारत के प्रथम पुरुष व महिलाएं, राष्ट्रीय उद्यान।'
        },
        keyFormulasAndTricks: {
          en: [
            'Statue of Unity: 182 meters tall, Kevadia Gujarat, sculptor Ram V. Sutar.',
            'Highest dam = Tehri Dam (Uttarakhand on Bhagirathi river, 260.5 m).',
            'Longest dam = Hirakud Dam (Odisha on Mahanadi, 25.79 km total).'
          ],
          bn: [
            'স্ট্যাচু অফ ইউনিটি: উচ্চতা ১৮২ মিটার, গুজরাটের নর্মদা নদীর সাধু বেট দ্বীপে (ভাস্কর রাম ভি সুতার)।',
            'উচ্চতম বাঁধ: তেহরি বাঁধ (উত্তরাখণ্ড, ভাগীরথী নদী)।',
            'দীর্ঘতম বাঁধ: হীরাকুঁদ বাঁধ (ওড়িশা, মহানদী)।'
          ],
          hi: [
            'सबसे ऊंचा बांध = टिहरी बांध; सबसे लंबा बांध = हीराकुंड।'
          ]
        },
        examTips: {
          en: 'UNESCO World Heritage Sites list and recent additions (e.g. Santiniketan, Hoysala temples) are prime topics.',
          bn: 'ভারতের ইউনেস্কো ওয়ার্ল্ড হেরিটেজ সাইট (যেমন শান্তিনিকেতন, হোয়সল মন্দির) খুব গুরুত্বপূর্ণ।',
          hi: 'यूनेस्को धरोहर स्थलों की सूची याद रखें।'
        },
        sampleQuestions: [
          {
            id: 'st-q1',
            subject: 'Static GK',
            topic: 'Monuments & Statues',
            difficulty: 'Easy',
            question: 'বিশ্বের উচ্চতম মূর্তি "স্ট্যাচু অফ ইউনিটি" (Statue of Unity) কার স্মরণে নির্মিত হয়েছে এবং এর উচ্চতা কত?',
            options: [
              'A. সর্দার বল্লভভাই প্যাটেল - ১৮২ মিটার',
              'B. মহাত্মা গান্ধী - ১৫০ মিটার',
              'C. ড. বি. আর. আম্বেদকর - ১৭৫ মিটার',
              'D. নেতাজি সুভাষচন্দ্র বসু - ১৮০ মিটার'
            ],
            correctOptionIndex: 0,
            explanation: 'ভারতের প্রথম উপ-প্রধানমন্ত্রী ও স্বরাষ্ট্রমন্ত্রী সর্দার বল্লভভাই প্যাটেলের স্মরণে গুজরাটের কেভাদিয়ায় নর্মদা নদীর তীরে ১৮২ মিটার (৫৯৭ ফুট) উচ্চতার স্ট্যাচু অফ ইউনিটি নির্মিত হয়েছে।',
            shortConcept: 'স্ট্যাচু অফ ইউনিটি = ১৮২ মিটার (সর্দার প্যাটেল)',
            rememberPoint: 'এর প্রধান ভাস্কর ছিলেন পদ্মভূষণ প্রাপক রাম ভি. সুতার।'
          }
        ]
      }
    ]
  }
};
