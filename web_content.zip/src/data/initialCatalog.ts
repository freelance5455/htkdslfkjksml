import { MarketItem } from '../types';

export const INITIAL_MARKET_ITEMS: MarketItem[] = [
  // ===================== الألقاب (Titles) - 12 items =====================
  {
    id: 'title-focus-legend',
    name: 'أسطورة التركيز',
    category: 'title',
    price: 350,
    description: 'يُمنح لمن يملك قدرة خارقة على عزل المشتتات والتركيز العميق.',
    icon: '⚡',
    rarity: 'legendary'
  },
  {
    id: 'title-time-tamer',
    name: 'مروض الوقت',
    category: 'title',
    price: 280,
    description: 'يتحكم في ساعاته ودقائقه كما يتحكم الفارس بفرسه.',
    icon: '⏳',
    rarity: 'epic'
  },
  {
    id: 'title-impossible-maker',
    name: 'صانع المستحيل',
    category: 'title',
    price: 400,
    description: 'لا يعترف بكلمة مستحيل، يحول الأهداف الكبرى لواقع ملموس.',
    icon: '🔮',
    rarity: 'legendary'
  },
  {
    id: 'title-task-ninja',
    name: 'نينجا المهام',
    category: 'title',
    price: 220,
    description: 'يقضي على قوائم المهام الصعبة في صمت وسرعة قياسية.',
    icon: '🥷',
    rarity: 'rare'
  },
  {
    id: 'title-minute-master',
    name: 'سيد الدقائق',
    category: 'title',
    price: 180,
    description: 'يعرف القيمة الحقيقية لكل دقيقة ويوظفها لصالحه.',
    icon: '⏱️',
    rarity: 'rare'
  },
  {
    id: 'title-achievement-knight',
    name: 'فارس الإنجاز',
    category: 'title',
    price: 200,
    description: 'يخوض معارك اليوم ويخرج منها بانتصارات متتالية.',
    icon: '🗡️',
    rarity: 'rare'
  },
  {
    id: 'title-slayer-procrastination',
    name: 'قاهر التسويف',
    category: 'title',
    price: 260,
    description: 'العدو الأول للمماطلة والتردد، يبدأ فوراً بلا تأخير.',
    icon: '🛡️',
    rarity: 'epic'
  },
  {
    id: 'title-energy-flame',
    name: 'شعلة النشاط',
    category: 'title',
    price: 150,
    description: 'طاقة إيجابية متجددة تحفز كل من حوله للعمل والعطاء.',
    icon: '🔥',
    rarity: 'common'
  },
  {
    id: 'title-dopamine-king',
    name: 'ملك الدوبامين',
    category: 'title',
    price: 320,
    description: 'يستمد نشوته وسعادته من شطب المهام المنجزة.',
    icon: '🧠',
    rarity: 'epic'
  },
  {
    id: 'title-willpower-emperor',
    name: 'إمبراطور العزيمة',
    category: 'title',
    price: 450,
    description: 'إرادة فولاذية لا تنكسر أمام أصعب الظروف والمشاريع.',
    icon: '👑',
    rarity: 'legendary'
  },
  {
    id: 'title-sage-mastery',
    name: 'حكيم الإتقان',
    category: 'title',
    price: 240,
    description: 'لا يكتفي بالإنهاء، بل يقدس الجودة والدقة في كل تفصيلة.',
    icon: '📜',
    rarity: 'rare'
  },
  {
    id: 'title-goal-hunter',
    name: 'صائد الأهداف',
    category: 'title',
    price: 190,
    description: 'يرصد الهدف بوضوح ولا يهدأ حتى يصيبه في المنتصف.',
    icon: '🎯',
    rarity: 'common'
  },

  // ===================== الإطارات البصرية المتحركة (Frames) - 11 items =====================
  {
    id: 'frame-cyber-neon',
    name: 'نيون سايبر (Cyber Neon)',
    category: 'frame',
    price: 300,
    description: 'إطار مشع بتوهج أزرق وبنفسجي رقمي بتأثير نبضي متكرر.',
    cssClass: 'frame-neon',
    rarity: 'epic'
  },
  {
    id: 'frame-volcanic-flame',
    name: 'لهب بركاني (Volcanic Flame)',
    category: 'frame',
    price: 380,
    description: 'إطار ناري متقد بحمم متوهجة تضخ الحماس والحيوية.',
    cssClass: 'frame-flame',
    rarity: 'legendary'
  },
  {
    id: 'frame-royal-gold',
    name: 'ملكي مذهب (Royal Gold)',
    category: 'frame',
    price: 420,
    description: 'إطار ذهبي نقي بلمعان الملوك والأمراء يبرز مكانتك.',
    cssClass: 'frame-royal',
    rarity: 'legendary'
  },
  {
    id: 'frame-emerald-glow',
    name: 'زمردي مشع (Emerald Glow)',
    category: 'frame',
    price: 250,
    description: 'إطار زمردي نضر يبعث على الهدوء والتركيز الطبيعي.',
    cssClass: 'frame-emerald',
    rarity: 'rare'
  },
  {
    id: 'frame-aurora-glow',
    name: 'الشفق القطبي (Aurora Glow)',
    category: 'frame',
    price: 310,
    description: 'تدرج سماوي وأخضر ساحر كأضواء القطب الشمالي الأسطورية.',
    cssClass: 'frame-aurora',
    rarity: 'epic'
  },
  {
    id: 'frame-cosmic-void',
    name: 'بنفسجي كوني (Cosmic Void)',
    category: 'frame',
    price: 360,
    description: 'هالة مجرات كونية تدور في فلك حسابك بتألق ساحر.',
    cssClass: 'frame-cosmic',
    rarity: 'epic'
  },
  {
    id: 'frame-electric-spark',
    name: 'برق كهربائي (Electric Spark)',
    category: 'frame',
    price: 290,
    description: 'صدمات كهربائية زرقاء خاطفة ترمز لسرعة إنجازك.',
    cssClass: 'frame-electric',
    rarity: 'rare'
  },
  {
    id: 'frame-diamond-crystal',
    name: 'ألماسي براق (Diamond Crystal)',
    category: 'frame',
    price: 500,
    description: 'بلورات الماس النقية تعكس نقاء تركيزك وصبرك الطويل.',
    cssClass: 'frame-diamond',
    rarity: 'legendary'
  },
  {
    id: 'frame-dragon-ember',
    name: 'حمم التنين (Dragon Ember)',
    category: 'frame',
    price: 340,
    description: 'شظايا حمم مستعرة من أنفاس التنانين القديمة.',
    cssClass: 'frame-dragon',
    rarity: 'epic'
  },
  {
    id: 'frame-portal-rift',
    name: 'بوابة الأبعاد (Portal Rift)',
    category: 'frame',
    price: 370,
    description: 'شرخ زمني بعدي ينقلك إلى مستوى جديد من الإنتاجية.',
    cssClass: 'frame-portal',
    rarity: 'epic'
  },
  {
    id: 'frame-cyber-pink',
    name: 'زهري فانتاسي (Cyber Pink)',
    category: 'frame',
    price: 270,
    description: 'لمعان فوشيا نيون مستوحى من مدن الخيال العلمي المستقبلية.',
    cssClass: 'frame-cyberpink',
    rarity: 'rare'
  },

  // ===================== الأفاتارات التعبيرية (Avatars) - 12 items =====================
  {
    id: 'avatar-falcon',
    name: 'صقر قريش',
    category: 'avatar',
    price: 180,
    description: 'نظرة حادة ترصد الفرص بدقة، رمز القوة والأصالة.',
    icon: '🦅',
    rarity: 'rare'
  },
  {
    id: 'avatar-dragon',
    name: 'تنين أسطوري',
    category: 'avatar',
    price: 350,
    description: 'حاكم العوالم الخارقة، ينفث العزيمة في كل خطوة.',
    icon: '🐉',
    rarity: 'legendary'
  },
  {
    id: 'avatar-robot',
    name: 'روبوت المستقبل',
    category: 'avatar',
    price: 200,
    description: 'دقة برمجية وعمل منهجي لا يعرف الكلل أو الإرهاق.',
    icon: '🤖',
    rarity: 'rare'
  },
  {
    id: 'avatar-crown',
    name: 'تاج المجد',
    category: 'avatar',
    price: 400,
    description: 'رمز السيادة والتفوق على كل الصعاب والمهام.',
    icon: '👑',
    rarity: 'legendary'
  },
  {
    id: 'avatar-tiger',
    name: 'نمر الليل',
    category: 'avatar',
    price: 230,
    description: 'هادئ ومفترس للأهداف، يقتنص المواعيد النهائية بدقة.',
    icon: '🐅',
    rarity: 'rare'
  },
  {
    id: 'avatar-wizard',
    name: 'ساحر الزمن',
    category: 'avatar',
    price: 260,
    description: 'يمتلك تعويذات تنظيم الوقت وتحويل الساعات لإنجازات.',
    icon: '🧙‍♂️',
    rarity: 'epic'
  },
  {
    id: 'avatar-samurai',
    name: 'محارب الساموراي',
    category: 'avatar',
    price: 280,
    description: 'الانضباط التام والشرف والتركيز الفائق على ضربة واحدة حاسمة.',
    icon: '⚔️',
    rarity: 'epic'
  },
  {
    id: 'avatar-astronaut',
    name: 'رائد الفضاء',
    category: 'avatar',
    price: 220,
    description: 'ينطلق أبعد من الغلاف الجوي باحثاً عن آفاق جديدة.',
    icon: '🚀',
    rarity: 'rare'
  },
  {
    id: 'avatar-lion',
    name: 'أسد الذهب',
    category: 'avatar',
    price: 320,
    description: 'هيبة ملكية لا تتردد في قيادة مسيرة الإنجاز.',
    icon: '🦁',
    rarity: 'epic'
  },
  {
    id: 'avatar-phoenix',
    name: 'عنقاء النار',
    category: 'avatar',
    price: 420,
    description: 'تنهض دائماً من تحت الرماد، رمز الإصرار المتجدد.',
    icon: '🔥',
    rarity: 'legendary'
  },
  {
    id: 'avatar-wolf',
    name: 'ذئب الثلج',
    category: 'avatar',
    price: 190,
    description: 'صامد في وجه العواصف، ذكاء استراتيجي ووفاء للهدف.',
    icon: '🐺',
    rarity: 'common'
  },
  {
    id: 'avatar-shield',
    name: 'درع الفولاذ',
    category: 'avatar',
    price: 160,
    description: 'حماية متينة تصد مشتتات الانتباه والإشعارات الزائفة.',
    icon: '🛡️',
    rarity: 'common'
  },

  // ===================== الثيمات البصرية المتكاملة (Themes) - 10 items =====================
  {
    id: 'theme-midnight',
    name: 'الداكن الفاخر (Midnight Obsidian)',
    category: 'theme',
    price: 0, // Default equipped theme
    description: 'ثيم داكن هادئ ومريح للعين مع لمسات رمادية وزرقاء فاخرة.',
    icon: '🌑',
    rarity: 'common'
  },
  {
    id: 'theme-cyberpunk',
    name: 'السايبربنك (Cyberpunk Neon)',
    category: 'theme',
    price: 350,
    description: 'تدرجات نيونية مستقبلية تجمع بين الأزرق السماوي والوردي الساطع.',
    icon: '🌆',
    rarity: 'legendary'
  },
  {
    id: 'theme-space',
    name: 'الفضاء الكوني (Cosmic Deep Space)',
    category: 'theme',
    price: 300,
    description: 'أعماق المجرات مع وميض أرجواني غامض وسديم كوني ساحر.',
    icon: '🌌',
    rarity: 'epic'
  },
  {
    id: 'theme-forest',
    name: 'الغابة الساحرة (Emerald Forest)',
    category: 'theme',
    price: 250,
    description: 'أخضر زمردي طبيعي يوحي بالهدوء والاستقرار الذهني التام.',
    icon: '🌲',
    rarity: 'rare'
  },
  {
    id: 'theme-royal',
    name: 'الملكي الذهبي (Royal Gold Velvet)',
    category: 'theme',
    price: 450,
    description: 'فخامة ملكية مطعمة بالذهب والياقوت تليق بالرواد والمنجزين.',
    icon: '👑',
    rarity: 'legendary'
  },
  {
    id: 'theme-sunset',
    name: 'غروب نيون (Sunset Vaporwave)',
    category: 'theme',
    price: 280,
    description: 'ألوان الشفق والغروب الدافئة، مزيج المرجاني والبرتقالي والبنفسجي.',
    icon: '🌇',
    rarity: 'rare'
  },
  {
    id: 'theme-ocean',
    name: 'أوشن ديب (Ocean Abyss)',
    category: 'theme',
    price: 270,
    description: 'أزرق محيطي غامق يمنحك تركيزاً عميقاً وهادئاً كقاع البحر.',
    icon: '🌊',
    rarity: 'rare'
  },
  {
    id: 'theme-amethyst',
    name: 'الشروق البنفسجي (Amethyst Dawn)',
    category: 'theme',
    price: 310,
    description: 'بنفسجي جمشتي أنيق يبعث على الابتكار والإلهام الإبداعي.',
    icon: '💎',
    rarity: 'epic'
  },
  {
    id: 'theme-matrix',
    name: 'الماتريكس الأخضر (Matrix Code)',
    category: 'theme',
    price: 330,
    description: 'أسود مطبق مع نيون رقمي فسفوري مستوحى من عالم البرمجة.',
    icon: '💻',
    rarity: 'epic'
  },
  {
    id: 'theme-ruby',
    name: 'الياقوت الإمبراطوري (Imperial Ruby)',
    category: 'theme',
    price: 390,
    description: 'أحمر قرمزي ناري مشبع بالشغف والطاقة المتقدة التي لا تنطفئ.',
    icon: '🩸',
    rarity: 'epic'
  }
];

export const THEME_STYLES: Record<string, {
  bg: string;
  card: string;
  border: string;
  accent: string;
  textAccent: string;
  gradient: string;
}> = {
  'theme-midnight': {
    bg: 'bg-slate-950',
    card: 'bg-slate-900/90',
    border: 'border-slate-800',
    accent: 'bg-indigo-600 hover:bg-indigo-500',
    textAccent: 'text-indigo-400',
    gradient: 'from-slate-950 via-slate-900 to-indigo-950/40'
  },
  'theme-cyberpunk': {
    bg: 'bg-neutral-950',
    card: 'bg-neutral-900/90 backdrop-blur-md',
    border: 'border-cyan-500/40',
    accent: 'bg-gradient-to-r from-cyan-500 to-pink-500 hover:from-cyan-400 hover:to-pink-400',
    textAccent: 'text-cyan-400',
    gradient: 'from-neutral-950 via-purple-950/40 to-cyan-950/30'
  },
  'theme-space': {
    bg: 'bg-slate-950',
    card: 'bg-indigo-950/50 backdrop-blur-md',
    border: 'border-purple-500/30',
    accent: 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500',
    textAccent: 'text-purple-400',
    gradient: 'from-slate-950 via-purple-950/50 to-indigo-950/60'
  },
  'theme-forest': {
    bg: 'bg-zinc-950',
    card: 'bg-emerald-950/40 backdrop-blur-md',
    border: 'border-emerald-600/40',
    accent: 'bg-emerald-600 hover:bg-emerald-500',
    textAccent: 'text-emerald-400',
    gradient: 'from-zinc-950 via-emerald-950/40 to-teal-950/30'
  },
  'theme-royal': {
    bg: 'bg-stone-950',
    card: 'bg-stone-900/90 backdrop-blur-md',
    border: 'border-amber-500/40',
    accent: 'bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-stone-950 font-bold',
    textAccent: 'text-amber-400',
    gradient: 'from-stone-950 via-amber-950/30 to-yellow-950/20'
  },
  'theme-sunset': {
    bg: 'bg-zinc-950',
    card: 'bg-zinc-900/90 backdrop-blur-md',
    border: 'border-rose-500/40',
    accent: 'bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-400 hover:to-rose-500',
    textAccent: 'text-rose-400',
    gradient: 'from-zinc-950 via-rose-950/40 to-orange-950/30'
  },
  'theme-ocean': {
    bg: 'bg-slate-950',
    card: 'bg-cyan-950/40 backdrop-blur-md',
    border: 'border-cyan-600/40',
    accent: 'bg-cyan-600 hover:bg-cyan-500',
    textAccent: 'text-cyan-400',
    gradient: 'from-slate-950 via-blue-950/40 to-cyan-950/40'
  },
  'theme-amethyst': {
    bg: 'bg-zinc-950',
    card: 'bg-fuchsia-950/40 backdrop-blur-md',
    border: 'border-fuchsia-600/40',
    accent: 'bg-fuchsia-600 hover:bg-fuchsia-500',
    textAccent: 'text-fuchsia-400',
    gradient: 'from-zinc-950 via-fuchsia-950/40 to-purple-950/40'
  },
  'theme-matrix': {
    bg: 'bg-black',
    card: 'bg-zinc-950/95 backdrop-blur-md',
    border: 'border-green-500/50',
    accent: 'bg-green-600 hover:bg-green-500 text-black font-mono font-bold',
    textAccent: 'text-green-400 font-mono',
    gradient: 'from-black via-green-950/30 to-black'
  },
  'theme-ruby': {
    bg: 'bg-stone-950',
    card: 'bg-red-950/40 backdrop-blur-md',
    border: 'border-red-600/40',
    accent: 'bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600',
    textAccent: 'text-red-400',
    gradient: 'from-stone-950 via-red-950/50 to-stone-950'
  }
};
