import { Formula } from '../../types';

export const PHYSICS_FORMULAS: Formula[] = [
  {
    id: 'newtons-second-law',
    title: "Newton's Second Law of Motion",
    category: 'Physics',
    subcategory: 'Force',
    formula: 'F = m × a',
    expression: 'm * a',
    solveFor: {
      F: 'm * a',
      m: 'F / a',
      a: 'F / m'
    },
    variables: [
      { symbol: 'F', name: 'Net Force', unit: 'N', defaultValue: 50 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 10, min: 0.0001 },
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 5 }
    ],
    description: 'The net force acting on an object equals its inertial mass multiplied by its acceleration.',
    studentExplanation: 'Force tells us how strongly an object is pushed or pulled. Heavier objects require more force to speed up.',
    engineeringExplanation: 'Governs dynamic translational equations of motion; dynamic load rating of actuators and structural members.',
    usage: 'Vehicle propulsion sizing, rocket launch thrust, elevator cable tension, and crane load safety.',
    example: 'A 10 kg mass accelerates at 5 m/s² ➔ Force F = 10 × 5 = 50 N.',
    difficulty: 'Beginner',
    tags: ['force', 'mass', 'acceleration', 'newton', 'mechanics'],
    popularity: 100,
    featured: true
  },
  {
    id: 'speed-formula',
    title: 'Speed Equation',
    category: 'Physics',
    subcategory: 'Motion',
    formula: 'v = d / t',
    expression: 'd / t',
    solveFor: {
      v: 'd / t',
      d: 'v * t',
      t: 'd / v'
    },
    variables: [
      { symbol: 'v', name: 'Speed / Velocity', unit: 'm/s', defaultValue: 10, min: 0 },
      { symbol: 'd', name: 'Distance', unit: 'm', defaultValue: 100, min: 0 },
      { symbol: 't', name: 'Elapsed Time', unit: 's', defaultValue: 10, min: 0.0001 }
    ],
    description: 'Rate of distance traversed per unit of time elapsed.',
    studentExplanation: 'How fast an object is moving over a given distance during a certain time.',
    engineeringExplanation: 'Kinematic definition of average velocity along a path.',
    usage: 'Travel estimation, conveyor velocity, conveyor cycle times, and automated guided vehicles.',
    example: 'A runner travels 100 m in 10 s ➔ Speed v = 100 / 10 = 10 m/s.',
    difficulty: 'Beginner',
    tags: ['speed', 'velocity', 'distance', 'time', 'kinematics'],
    popularity: 99
  },
  {
    id: 'acceleration-formula',
    title: 'Linear Acceleration',
    category: 'Physics',
    subcategory: 'Motion',
    formula: 'a = (v - u) / t',
    expression: '(v - u) / t',
    solveFor: {
      a: '(v - u) / t',
      v: 'u + (a * t)',
      u: 'v - (a * t)',
      t: '(v - u) / a'
    },
    variables: [
      { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 4 },
      { symbol: 'v', name: 'Final Velocity (v)', unit: 'm/s', defaultValue: 30 },
      { symbol: 'u', name: 'Initial Velocity (u)', unit: 'm/s', defaultValue: 10 },
      { symbol: 't', name: 'Time Interval (t)', unit: 's', defaultValue: 5, min: 0.0001 }
    ],
    description: 'Rate of change of velocity over time.',
    studentExplanation: 'How quickly an object speeds up or slows down.',
    engineeringExplanation: 'Time derivative of velocity governing inertial shock and jerk constraints.',
    usage: 'Vehicle braking distance, train speed curves, and elevator passenger comfort.',
    example: 'A car accelerates from 10 m/s to 30 m/s in 5 s ➔ a = (30 - 10) / 5 = 4 m/s².',
    difficulty: 'Beginner',
    tags: ['acceleration', 'velocity', 'motion', 'kinematics'],
    popularity: 97
  },
  {
    id: 'kinetic-energy',
    title: 'Kinetic Energy',
    category: 'Physics',
    subcategory: 'Energy & Work',
    formula: 'KE = ½ × m × v²',
    expression: '0.5 * m * (v ^ 2)',
    solveFor: {
      KE: '0.5 * m * (v ^ 2)',
      m: '(2 * KE) / (v ^ 2)',
      v: 'sqrt((2 * KE) / m)'
    },
    variables: [
      { symbol: 'KE', name: 'Kinetic Energy', unit: 'J', defaultValue: 200000, min: 0 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 1000, min: 0.0001 },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 20 }
    ],
    description: 'Energy possessed by an object due to its motion.',
    studentExplanation: 'The energy stored in any moving object. If you double the speed, the energy becomes 4 times larger!',
    engineeringExplanation: 'Mechanical work required to accelerate an inertial body from rest; crash absorption sizing.',
    usage: 'Automotive crash energy dissipation, flywheel energy storage, and ballistic impact absorption.',
    example: 'A 1000 kg vehicle at 20 m/s (72 km/h) ➔ KE = 0.5 × 1000 × 400 = 200,000 J (200 kJ).',
    difficulty: 'Beginner',
    tags: ['kinetic energy', 'energy', 'work', 'velocity'],
    popularity: 98
  },
  {
    id: 'gravitational-potential-energy',
    title: 'Gravitational Potential Energy',
    category: 'Physics',
    subcategory: 'Energy & Work',
    formula: 'PE = m × g × h',
    expression: 'm * g * h',
    solveFor: {
      PE: 'm * g * h',
      m: 'PE / (g * h)',
      h: 'PE / (m * g)'
    },
    variables: [
      { symbol: 'PE', name: 'Potential Energy', unit: 'J', defaultValue: 490.5, min: 0 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 10, min: 0.0001 },
      { symbol: 'g', name: 'Gravity Constant', unit: 'm/s²', defaultValue: 9.81, min: 0 },
      { symbol: 'h', name: 'Height Elevation', unit: 'm', defaultValue: 5 }
    ],
    description: 'Energy stored in an object by virtue of its elevated vertical position in a gravitational field.',
    studentExplanation: 'Energy an object stores when you lift it higher into the air.',
    engineeringExplanation: 'Static head potential utilized in pumped hydroelectric storage and counterweight design.',
    usage: 'Hydroelectric dam power heads, drop forge presses, and roller coaster design.',
    example: 'A 10 kg mass lifted 5 m under gravity g = 9.81 m/s² ➔ PE = 10 × 9.81 × 5 = 490.5 J.',
    difficulty: 'Beginner',
    tags: ['potential energy', 'gravity', 'height', 'energy'],
    popularity: 96
  },
  {
    id: 'weight-force',
    title: 'Weight Force',
    category: 'Physics',
    subcategory: 'Force',
    formula: 'W = m × g',
    expression: 'm * g',
    solveFor: {
      W: 'm * g',
      m: 'W / g',
      g: 'W / m'
    },
    variables: [
      { symbol: 'W', name: 'Weight Force', unit: 'N', defaultValue: 686.7 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 70, min: 0.0001 },
      { symbol: 'g', name: 'Local Gravity (g)', unit: 'm/s²', defaultValue: 9.81, min: 0 }
    ],
    description: 'Downward gravitational pull exerted upon a mass by a planetary body.',
    studentExplanation: 'Your mass is how much stuff you are made of; your weight is how strongly gravity pulls that stuff downward.',
    engineeringExplanation: 'Static vertical dead load vector in structural civil foundations and aircraft ballast.',
    usage: 'Civil foundation static load calculation, scale calibration, and aerospace payload weight.',
    example: 'A 70 kg person on Earth (g = 9.81 m/s²) weighs W = 70 × 9.81 = 686.7 N.',
    difficulty: 'Beginner',
    tags: ['weight', 'gravity', 'mass', 'newton'],
    popularity: 95
  },
  {
    id: 'mechanical-work',
    title: 'Mechanical Work Done',
    category: 'Physics',
    subcategory: 'Energy & Work',
    formula: 'W = F × d',
    expression: 'F * d',
    solveFor: {
      W: 'F * d',
      F: 'W / d',
      d: 'W / F'
    },
    variables: [
      { symbol: 'W', name: 'Work Done', unit: 'J', defaultValue: 500 },
      { symbol: 'F', name: 'Applied Force', unit: 'N', defaultValue: 100 },
      { symbol: 'd', name: 'Displacement', unit: 'm', defaultValue: 5 }
    ],
    description: 'Energy transferred to or from an object via the application of force along a displacement.',
    studentExplanation: 'Work is force applied across a distance. If an object does not move, no mechanical work is done.',
    engineeringExplanation: 'Line integral of force vector over displacement path; area under force-displacement curve.',
    usage: 'Linear actuator load sizing, winch pulling capacity, and spring work compression.',
    example: 'Pushing a crate with 100 N of force over 5 m ➔ W = 100 × 5 = 500 J.',
    difficulty: 'Beginner',
    tags: ['work', 'force', 'distance', 'energy', 'joules'],
    popularity: 94
  },
  {
    id: 'mechanical-power',
    title: 'Mechanical Power',
    category: 'Physics',
    subcategory: 'Energy & Work',
    formula: 'P = W / t',
    expression: 'W / t',
    solveFor: {
      P: 'W / t',
      W: 'P * t',
      t: 'W / P'
    },
    variables: [
      { symbol: 'P', name: 'Power Rating', unit: 'W', defaultValue: 400, min: 0 },
      { symbol: 'W', name: 'Work / Energy', unit: 'J', defaultValue: 2000 },
      { symbol: 't', name: 'Time Elapsed', unit: 's', defaultValue: 5, min: 0.0001 }
    ],
    description: 'Rate of performing work or transferring energy per unit time.',
    studentExplanation: 'Power tells you how fast work gets done. A powerful motor does the same work in less time.',
    engineeringExplanation: 'Time derivative of energy transfer defining motor size ratings in Watts and horsepower.',
    usage: 'Electric motor kW rating, pump drive sizing, and crane lift speed specs.',
    example: 'Doing 2000 J of work in 5 s ➔ P = 2000 / 5 = 400 W.',
    difficulty: 'Beginner',
    tags: ['power', 'watt', 'work', 'time', 'rate'],
    popularity: 96
  },
  {
    id: 'linear-momentum',
    title: 'Linear Momentum',
    category: 'Physics',
    subcategory: 'Motion',
    formula: 'p = m × v',
    expression: 'm * v',
    solveFor: {
      p: 'm * v',
      m: 'p / v',
      v: 'p / m'
    },
    variables: [
      { symbol: 'p', name: 'Momentum', unit: 'kg·m/s', defaultValue: 1200 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 80, min: 0.0001 },
      { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 15 }
    ],
    description: 'Quantity of motion an object possesses; conserved in isolated system collisions.',
    studentExplanation: 'Momentum is mass in motion. A heavy truck is much harder to stop than a bicycle at the same speed.',
    engineeringExplanation: 'Conserved mechanical state variable fundamental to collision modeling and rocket impulse.',
    usage: 'Vehicle crash barrier analysis, billiard physics, and pile driver impact force.',
    example: 'An 80 kg sprinter at 15 m/s ➔ Momentum p = 80 × 15 = 1200 kg·m/s.',
    difficulty: 'Beginner',
    tags: ['momentum', 'mass', 'velocity', 'collision'],
    popularity: 92
  },
  {
    id: 'mass-density',
    title: 'Volumetric Mass Density',
    category: 'Physics',
    subcategory: 'Mechanics',
    formula: 'ρ = m / V',
    expression: 'm / V',
    solveFor: {
      rho: 'm / V',
      m: 'rho * V',
      V: 'm / rho'
    },
    variables: [
      { symbol: 'rho', name: 'Density (ρ)', unit: 'kg/m³', defaultValue: 1000, min: 0.0001 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 500, min: 0 },
      { symbol: 'V', name: 'Volume', unit: 'm³', defaultValue: 0.5, min: 0.000001 }
    ],
    description: 'Mass contained per unit volume of a homogeneous substance.',
    studentExplanation: 'How tightly packed the matter inside an object is. Heavy metals have high density; wood is less dense.',
    engineeringExplanation: 'Material constitutive property governing buoyancy, gravitational loads, and flow inertia.',
    usage: 'Ship buoyancy flotation, structural material weight estimation, and fluid characterization.',
    example: 'Mass = 500 kg in volume 0.5 m³ ➔ Density ρ = 500 / 0.5 = 1000 kg/m³ (water).',
    difficulty: 'Beginner',
    tags: ['density', 'mass', 'volume', 'buoyancy'],
    popularity: 94
  },
  {
    id: 'fluid-pressure',
    title: 'Pressure Definition',
    category: 'Physics',
    subcategory: 'Mechanics',
    formula: 'P = F / A',
    expression: 'F / A',
    solveFor: {
      P: 'F / A',
      F: 'P * A',
      A: 'F / P'
    },
    variables: [
      { symbol: 'P', name: 'Pressure', unit: 'Pa', defaultValue: 10000, min: 0 },
      { symbol: 'F', name: 'Perpendicular Force', unit: 'N', defaultValue: 1000 },
      { symbol: 'A', name: 'Contact Area', unit: 'm²', defaultValue: 0.1, min: 0.000001 }
    ],
    description: 'Normal force distributed over a surface per unit area.',
    studentExplanation: 'Force spread out over a surface. A sharp needle exerts high pressure with little force because its area is tiny.',
    engineeringExplanation: 'Scalar stress tensor trace component in fluid hydraulics and pneumatic actuators.',
    usage: 'Hydraulic jack lifting force, pneumatic cylinders, and steam boiler safety valves.',
    example: 'Force = 1000 N applied over 0.1 m² ➔ Pressure P = 1000 / 0.1 = 10,000 Pa (10 kPa).',
    difficulty: 'Beginner',
    tags: ['pressure', 'force', 'area', 'pascal'],
    popularity: 95
  },
  {
    id: 'hydrostatic-pressure',
    title: 'Hydrostatic Fluid Pressure',
    category: 'Physics',
    subcategory: 'Mechanics',
    formula: 'P = ρ × g × h',
    expression: 'rho * g * h',
    solveFor: {
      P: 'rho * g * h',
      h: 'P / (rho * g)',
      rho: 'P / (g * h)'
    },
    variables: [
      { symbol: 'P', name: 'Hydrostatic Pressure', unit: 'Pa', defaultValue: 98100, min: 0 },
      { symbol: 'rho', name: 'Fluid Density (ρ)', unit: 'kg/m³', defaultValue: 1000, min: 0.001 },
      { symbol: 'g', name: 'Gravity', unit: 'm/s²', defaultValue: 9.81, min: 0 },
      { symbol: 'h', name: 'Fluid Column Depth', unit: 'm', defaultValue: 10, min: 0 }
    ],
    description: 'Pressure exerted by an incompressible fluid at equilibrium due to the force of gravity.',
    studentExplanation: 'The deeper you dive underwater, the more weight of water is above you, pushing down with greater pressure.',
    engineeringExplanation: 'Static head gauge pressure in liquid columns, reservoirs, and submarine hull design.',
    usage: 'Submarine depth ratings, dam wall thickness profiles, and municipal water towers.',
    example: 'Water (1000 kg/m³) at 10 m depth ➔ P = 1000 × 9.81 × 10 = 98,100 Pa (~0.97 atm).',
    difficulty: 'Intermediate',
    tags: ['hydrostatics', 'fluid', 'pressure', 'depth', 'water'],
    popularity: 91
  },
  {
    id: 'ohms-law-physics',
    title: "Ohm's Law (Voltage)",
    category: 'Physics',
    subcategory: 'Electricity',
    formula: 'V = I × R',
    expression: 'I * R',
    solveFor: {
      V: 'I * R',
      I: 'V / R',
      R: 'V / I'
    },
    variables: [
      { symbol: 'V', name: 'Voltage Potential', unit: 'V', defaultValue: 12 },
      { symbol: 'I', name: 'Electric Current', unit: 'A', defaultValue: 2 },
      { symbol: 'R', name: 'Electrical Resistance', unit: 'Ω', defaultValue: 6, min: 0.0001 }
    ],
    description: 'Electric potential difference across a conductor is proportional to the current through it.',
    studentExplanation: 'Voltage pushes electrical charge through a wire against the resistance of the circuit.',
    engineeringExplanation: 'Fundamental constitutive equation for linear resistive circuit analysis.',
    usage: 'DC circuit design, resistor sizing, voltage drop mitigation, and power supply design.',
    example: 'Current I = 2 A flowing through a 6 Ω resistor ➔ Voltage V = 2 × 6 = 12 V.',
    difficulty: 'Beginner',
    tags: ['ohm', 'voltage', 'current', 'resistance', 'electricity'],
    popularity: 100
  },
  {
    id: 'electrical-power-physics',
    title: 'Joule Electrical Power',
    category: 'Physics',
    subcategory: 'Electricity',
    formula: 'P = V × I',
    expression: 'V * I',
    solveFor: {
      P: 'V * I',
      V: 'P / I',
      I: 'P / V'
    },
    variables: [
      { symbol: 'P', name: 'Electric Power', unit: 'W', defaultValue: 120, min: 0 },
      { symbol: 'V', name: 'Voltage', unit: 'V', defaultValue: 12 },
      { symbol: 'I', name: 'Current', unit: 'A', defaultValue: 10 }
    ],
    description: 'Rate at which electrical energy is transferred by an electric circuit per second.',
    studentExplanation: 'Electric power is voltage multiplied by current. It tells you how much energy an appliance uses.',
    engineeringExplanation: 'Instantaneous active electrical power dissipation in direct current and resistive AC systems.',
    usage: 'Power supply sizing, battery discharge calculations, and cable ampacity selection.',
    example: 'A 12 V automotive system drawing 10 A ➔ Power P = 12 × 10 = 120 W.',
    difficulty: 'Beginner',
    tags: ['electricity', 'power', 'watt', 'voltage', 'current'],
    popularity: 98
  },
  {
    id: 'coulombs-law',
    title: "Coulomb's Law of Electrostatic Force",
    category: 'Physics',
    subcategory: 'Electricity',
    formula: 'F = (kₑ × |q₁ × q₂|) / r²',
    expression: '(8.98755e9 * abs(q1 * q2)) / (r ^ 2)',
    solveFor: {
      F: '(8.98755e9 * abs(q1 * q2)) / (r ^ 2)',
      r: 'sqrt((8.98755e9 * abs(q1 * q2)) / F)'
    },
    variables: [
      { symbol: 'F', name: 'Electrostatic Force', unit: 'N', defaultValue: 1.8, min: 0 },
      { symbol: 'q1', name: 'Charge 1 (q₁)', unit: 'C', defaultValue: 0.000001 },
      { symbol: 'q2', name: 'Charge 2 (q₂)', unit: 'C', defaultValue: 0.000002 },
      { symbol: 'r', name: 'Separation Distance (r)', unit: 'm', defaultValue: 0.1, min: 0.0001 }
    ],
    description: 'Electric force of attraction or repulsion between two static electric point charges.',
    studentExplanation: 'Like charges repel and opposite charges attract with a force that gets dramatically stronger as they get closer.',
    engineeringExplanation: 'Inverse-square electrostatic field interaction; dielectric breakdown limits.',
    usage: 'Electrostatic precipitators, particle accelerators, and semiconductor electrostatic discharge modeling.',
    example: 'q1 = 1 μC, q2 = 2 μC separated by 0.1 m ➔ F ≈ 1.8 N.',
    difficulty: 'Intermediate',
    tags: ['coulomb', 'electrostatics', 'charge', 'force'],
    popularity: 88
  },
  {
    id: 'universal-gravitation',
    title: "Newton's Law of Gravitation",
    category: 'Physics',
    subcategory: 'Gravity',
    formula: 'F = (G × m₁ × m₂) / r²',
    expression: '(6.6743e-11 * m1 * m2) / (r ^ 2)',
    solveFor: {
      F: '(6.6743e-11 * m1 * m2) / (r ^ 2)',
      r: 'sqrt((6.6743e-11 * m1 * m2) / F)'
    },
    variables: [
      { symbol: 'F', name: 'Gravitational Force', unit: 'N', defaultValue: 686.7, min: 0 },
      { symbol: 'm1', name: 'Mass 1 (Earth)', unit: 'kg', defaultValue: 5.972e24, min: 1 },
      { symbol: 'm2', name: 'Mass 2 (Object)', unit: 'kg', defaultValue: 70, min: 0.0001 },
      { symbol: 'r', name: 'Distance (r)', unit: 'm', defaultValue: 6.371e6, min: 1 }
    ],
    description: 'Mutual attractive gravitational force between two point masses across cosmic distances.',
    studentExplanation: 'Every mass in the universe attracts every other mass. The larger the masses and the closer they are, the stronger the pull.',
    engineeringExplanation: 'Orbital celestial mechanics; gravitational perturbation in satellite constellation orbits.',
    usage: 'Satellite orbit propagation, interplanetary trajectories, and tidal analysis.',
    example: 'Earth and 70 kg human at surface radius r = 6.371×10⁶ m ➔ F ≈ 687 N.',
    difficulty: 'Intermediate',
    tags: ['gravity', 'newton', 'astrophysics', 'orbit'],
    popularity: 91
  },
  {
    id: 'centripetal-force',
    title: 'Centripetal Force',
    category: 'Physics',
    subcategory: 'Motion',
    formula: 'Fc = (m × v²) / r',
    expression: '(m * (v ^ 2)) / r',
    solveFor: {
      Fc: '(m * (v ^ 2)) / r',
      m: '(Fc * r) / (v ^ 2)',
      v: 'sqrt((Fc * r) / m)',
      r: '(m * (v ^ 2)) / Fc'
    },
    variables: [
      { symbol: 'Fc', name: 'Centripetal Force', unit: 'N', defaultValue: 4000, min: 0 },
      { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 1000, min: 0.0001 },
      { symbol: 'v', name: 'Tangential Speed', unit: 'm/s', defaultValue: 10 },
      { symbol: 'r', name: 'Curvature Radius', unit: 'm', defaultValue: 25, min: 0.001 }
    ],
    description: 'Inward radial force required to curve an object along a circular trajectory.',
    studentExplanation: 'The inward pull needed to make something turn in a circle instead of flying off in a straight line.',
    engineeringExplanation: 'Lateral tire friction demand on curved roadways, centrifuge stress, and roller coaster loop g-forces.',
    usage: 'Highway curve banking angles, centrifuge design, and roller coaster track geometry.',
    example: 'A 1000 kg car turning a 25 m radius curve at 10 m/s ➔ Fc = (1000 × 100) / 25 = 4000 N.',
    difficulty: 'Intermediate',
    tags: ['circular motion', 'centripetal', 'rotation', 'curve'],
    popularity: 93
  },
  {
    id: 'hookes-law',
    title: "Hooke's Law (Spring Restoring Force)",
    category: 'Physics',
    subcategory: 'Force',
    formula: 'F = k × x',
    expression: 'k * x',
    solveFor: {
      F: 'k * x',
      k: 'F / x',
      x: 'F / k'
    },
    variables: [
      { symbol: 'F', name: 'Restoring Force', unit: 'N', defaultValue: 50 },
      { symbol: 'k', name: 'Spring Stiffness (k)', unit: 'N/m', defaultValue: 500, min: 0.0001 },
      { symbol: 'x', name: 'Displacement (x)', unit: 'm', defaultValue: 0.1 }
    ],
    description: 'The elastic restoring force of an ideal spring is directly proportional to its displacement from rest.',
    studentExplanation: 'The further you stretch or compress a spring, the harder it pulls or pushes back.',
    engineeringExplanation: 'Linear elastic compliance modeling for suspension springs, vibration isolators, and MEMS cantilevers.',
    usage: 'Vehicle suspension coil springs, weighing scales, and earthquake vibration isolators.',
    example: 'Spring k = 500 N/m stretched by 0.1 m ➔ Restoring Force F = 500 × 0.1 = 50 N.',
    difficulty: 'Beginner',
    tags: ['spring', 'hooke', 'elasticity', 'force'],
    popularity: 92
  },
  {
    id: 'wave-speed',
    title: 'Wave Velocity Equation',
    category: 'Physics',
    subcategory: 'Waves',
    formula: 'v = f × λ',
    expression: 'f * lambda',
    solveFor: {
      v: 'f * lambda',
      f: 'v / lambda',
      lambda: 'v / f'
    },
    variables: [
      { symbol: 'v', name: 'Wave Propagation Speed', unit: 'm/s', defaultValue: 340, min: 0 },
      { symbol: 'f', name: 'Frequency (f)', unit: 'Hz', defaultValue: 500, min: 0.0001 },
      { symbol: 'lambda', name: 'Wavelength (λ)', unit: 'm', defaultValue: 0.68, min: 0.0001 }
    ],
    description: 'Wave propagation speed equals the product of its oscillation frequency and spatial wavelength.',
    studentExplanation: 'Wave speed is how many wave crests pass per second multiplied by the distance between crests.',
    engineeringExplanation: 'Acoustic wave speed in media and electromagnetic carrier frequency propagation.',
    usage: 'RF antenna length tuning, acoustic transducer matching, and ultrasonic non-destructive testing.',
    example: 'Sound wave at 500 Hz with wavelength 0.68 m ➔ Speed v = 500 × 0.68 = 340 m/s.',
    difficulty: 'Beginner',
    tags: ['wave', 'frequency', 'wavelength', 'sound', 'light'],
    popularity: 90
  },
  {
    id: 'snells-law-refraction',
    title: "Snell's Law of Optical Refraction",
    category: 'Physics',
    subcategory: 'Waves',
    formula: 'θ₂ = asin((n₁ / n₂) × sin(θ₁))',
    expression: 'asin((n1 / n2) * sin((theta1 * pi) / 180)) * (180 / pi)',
    solveFor: {
      theta2: 'asin((n1 / n2) * sin((theta1 * pi) / 180)) * (180 / pi)'
    },
    variables: [
      { symbol: 'theta2', name: 'Refracted Angle (θ₂)', unit: 'deg', defaultValue: 19.47 },
      { symbol: 'n1', name: 'Medium 1 Index (n₁)', unit: '', defaultValue: 1.0, min: 0.1 },
      { symbol: 'n2', name: 'Medium 2 Index (n₂)', unit: '', defaultValue: 1.5, min: 0.1 },
      { symbol: 'theta1', name: 'Incident Angle (θ₁)', unit: 'deg', defaultValue: 30, min: 0, max: 90 }
    ],
    description: 'Bending of light rays at an interface between two isotropic media with different refractive indices.',
    studentExplanation: 'Light bends when entering water or glass because it slows down.',
    engineeringExplanation: 'Ray tracing for optical lenses, fiber optic total internal reflection, and prism spectrometers.',
    usage: 'Camera lens design, fiber optic core-cladding critical angles, and prism dispersion.',
    example: 'Light in air (n1 = 1.0) hits glass (n2 = 1.5) at 30° ➔ θ₂ = asin((1/1.5) × sin(30°)) ≈ 19.47°.',
    difficulty: 'Intermediate',
    tags: ['optics', 'snell', 'refraction', 'light', 'lens'],
    popularity: 87
  },
  {
    id: 'heat-energy-specific-heat',
    title: 'Specific Heat Thermal Transfer',
    category: 'Physics',
    subcategory: 'Heat',
    formula: 'Q = m × c × ΔT',
    expression: 'm * c * deltaT',
    solveFor: {
      Q: 'm * c * deltaT',
      m: 'Q / (c * deltaT)',
      deltaT: 'Q / (m * c)',
      c: 'Q / (m * deltaT)'
    },
    variables: [
      { symbol: 'Q', name: 'Heat Energy Transferred', unit: 'J', defaultValue: 20920 },
      { symbol: 'm', name: 'Substance Mass', unit: 'kg', defaultValue: 0.25, min: 0.0001 },
      { symbol: 'c', name: 'Specific Heat (c)', unit: 'J/(kg·°C)', defaultValue: 4184, min: 0.1 },
      { symbol: 'deltaT', name: 'Temp Change (ΔT)', unit: '°C', defaultValue: 20 }
    ],
    description: 'Heat energy absorbed or released by a substance during an isobaric temperature shift.',
    studentExplanation: 'How much thermal energy is needed to warm up or cool down an object by a certain temperature.',
    engineeringExplanation: 'Thermal capacitance modeling for heat sinks, cooling water jackets, and calorimeters.',
    usage: 'Engine coolant heat exchanger sizing, HVAC thermal loads, and heat sink thermal mass.',
    example: '250 g of water (c = 4184 J/(kg·°C)) warmed by 20 °C ➔ Q = 0.25 × 4184 × 20 = 20,920 J.',
    difficulty: 'Beginner',
    tags: ['heat', 'thermal', 'specific heat', 'energy'],
    popularity: 93
  },
  {
    id: 'simple-pendulum-period',
    title: 'Simple Pendulum Oscillation Period',
    category: 'Physics',
    subcategory: 'Motion',
    formula: 'T = 2 × π × √(L / g)',
    expression: '2 * pi * sqrt(L / g)',
    solveFor: {
      T: '2 * pi * sqrt(L / g)',
      L: 'g * ((T / (2 * pi)) ^ 2)'
    },
    variables: [
      { symbol: 'T', name: 'Oscillation Period (T)', unit: 's', defaultValue: 2.006, min: 0 },
      { symbol: 'L', name: 'Pendulum String Length (L)', unit: 'm', defaultValue: 1.0, min: 0.001 },
      { symbol: 'g', name: 'Gravity Constant', unit: 'm/s²', defaultValue: 9.81, min: 0.1 }
    ],
    description: 'Small-amplitude natural period of oscillation for an idealized simple gravity pendulum.',
    studentExplanation: 'The time it takes for a pendulum to swing back and forth once depends only on its length and gravity, not its mass!',
    engineeringExplanation: 'Small-angle approximation harmonic oscillator for clock pendulums and seismic damping mass dampers.',
    usage: 'Tuned mass dampers in skyscrapers, grandfather clocks, and seismometers.',
    example: 'A 1 m long pendulum on Earth (g = 9.81 m/s²) ➔ Period T = 2 × π × √(1 / 9.81) ≈ 2.006 s.',
    difficulty: 'Intermediate',
    tags: ['pendulum', 'period', 'oscillation', 'harmonics'],
    popularity: 89
  }
];
