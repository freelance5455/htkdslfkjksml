import { Formula } from '../../types';

export const ENGINEERING_FORMULAS: Formula[] = [
  {
    id: 'mechanical-normal-stress',
    title: 'Normal Mechanical Stress',
    category: 'Engineering',
    subcategory: 'Materials & Stress',
    formula: 'σ = F / A',
    expression: 'F / A',
    solveFor: {
      sigma: 'F / A',
      F: 'sigma * A',
      A: 'F / sigma'
    },
    variables: [
      { symbol: 'sigma', name: 'Stress (σ)', unit: 'MPa', defaultValue: 125, min: 0 },
      { symbol: 'F', name: 'Axial Load', unit: 'N', defaultValue: 25000 },
      { symbol: 'A', name: 'Cross-Section Area', unit: 'mm²', defaultValue: 200, min: 0.001 }
    ],
    description: 'Internal resisting force per unit cross-sectional area generated in a loaded member (1 N/mm² = 1 MPa).',
    studentExplanation: 'How much tension or compression force a structural bar experiences across its cross-sectional area.',
    engineeringExplanation: 'Primary design parameter compared against material yield strength with safety factor (σ ≤ σ_yield / SF).',
    usage: 'Tensile bolt load sizing, truss member tension, and structural column design.',
    example: 'Force = 25,000 N applied to an area of 200 mm² ➔ Stress σ = 25,000 / 200 = 125 MPa.',
    difficulty: 'Intermediate',
    tags: ['stress', 'materials', 'mechanics of materials', 'structural'],
    popularity: 98,
    featured: true
  },
  {
    id: 'engineering-strain',
    title: 'Engineering Axial Strain',
    category: 'Engineering',
    subcategory: 'Materials & Stress',
    formula: 'ε = ΔL / L₀',
    expression: 'deltaL / L0',
    solveFor: {
      epsilon: 'deltaL / L0',
      deltaL: 'epsilon * L0',
      L0: 'deltaL / epsilon'
    },
    variables: [
      { symbol: 'epsilon', name: 'Strain (ε)', unit: 'mm/mm', defaultValue: 0.0015 },
      { symbol: 'deltaL', name: 'Elongation (ΔL)', unit: 'mm', defaultValue: 1.5 },
      { symbol: 'L0', name: 'Original Length (L₀)', unit: 'mm', defaultValue: 1000, min: 0.001 }
    ],
    description: 'Dimensionless ratio of geometric deformation relative to original un-deformed length.',
    studentExplanation: 'The percentage stretch or squish an object undergoes when loaded.',
    engineeringExplanation: 'Cauchy infinitesimal strain tensor axial component for elastic range Hookean constitutive laws.',
    usage: 'Strain gauge sensor calibration, material tensile testing, and structural deflection monitoring.',
    example: 'A 1000 mm steel bar elongates by 1.5 mm ➔ Strain ε = 1.5 / 1000 = 0.0015 (1500 microstrain).',
    difficulty: 'Beginner',
    tags: ['strain', 'deformation', 'materials', 'elongation'],
    popularity: 94
  },
  {
    id: 'youngs-modulus-elastic',
    title: "Hooke's Law Elastic Deformation",
    category: 'Engineering',
    subcategory: 'Materials & Stress',
    formula: 'ΔL = (F × L₀) / (A × E)',
    expression: '(F * L0) / (A * E * 1000)',
    solveFor: {
      deltaL: '(F * L0) / (A * E * 1000)',
      F: '(deltaL * A * E * 1000) / L0'
    },
    variables: [
      { symbol: 'deltaL', name: 'Elastic Stretch (ΔL)', unit: 'mm', defaultValue: 0.5, min: 0 },
      { symbol: 'F', name: 'Tensile Load (F)', unit: 'N', defaultValue: 10000 },
      { symbol: 'L0', name: 'Length (L₀)', unit: 'mm', defaultValue: 1000, min: 0.1 },
      { symbol: 'A', name: 'Area (A)', unit: 'mm²', defaultValue: 100, min: 0.1 },
      { symbol: 'E', name: "Young's Modulus (E)", unit: 'GPa', defaultValue: 200, min: 0.1 }
    ],
    description: 'Axial elongation of an elastic prism bar under tensile axial load factoring Young’s modulus of elasticity E.',
    studentExplanation: 'Calculates how much a metal bar stretches under a heavy pulling force.',
    engineeringExplanation: 'Elastic stiffness deflection calculation for structural tie-rods, suspension cables, and tie-bars.',
    usage: 'Bridge suspension cable stretch, hydraulic tie-rod elongation, and aircraft wing spar deflection.',
    example: 'F = 10 kN, L0 = 1000 mm, A = 100 mm², Steel E = 200 GPa ➔ Stretch ΔL = (10000 × 1000)/(100 × 200,000) = 0.5 mm.',
    difficulty: 'Intermediate',
    tags: ['youngs modulus', 'elasticity', 'elongation', 'stiffness'],
    popularity: 96
  },
  {
    id: 'shaft-torque-from-power',
    title: 'Rotating Shaft Power from Torque',
    category: 'Engineering',
    subcategory: 'Mechanical Engineering',
    formula: 'P = (2 × π × N × T) / 60',
    expression: '(2 * pi * N * T) / 60',
    solveFor: {
      P: '(2 * pi * N * T) / 60',
      T: '(60 * P) / (2 * pi * N)',
      N: '(60 * P) / (2 * pi * T)'
    },
    variables: [
      { symbol: 'P', name: 'Shaft Power', unit: 'W', defaultValue: 9424.78, min: 0 },
      { symbol: 'N', name: 'Shaft Speed', unit: 'rpm', defaultValue: 1800, min: 0.001 },
      { symbol: 'T', name: 'Torque', unit: 'N·m', defaultValue: 50, min: 0 }
    ],
    description: 'Mechanical power transmitted through a rotating shaft given torque and rotational speed in RPM.',
    studentExplanation: 'Power equals torque (twisting force) multiplied by speed (how fast the shaft spins).',
    engineeringExplanation: 'Fundamental power delivery relation in mechanical powertrains, gearboxes, and electric dynos.',
    usage: 'Electric motor horsepower selection, dyno test power curves, and transmission torque ratings.',
    example: 'Shaft spinning at 1800 RPM with 50 N·m of torque ➔ Power P = (2 × π × 1800 × 50) / 60 ≈ 9425 W (9.4 kW).',
    difficulty: 'Intermediate',
    tags: ['torque', 'rpm', 'power', 'powertrain', 'motor'],
    popularity: 97
  },
  {
    id: 'gear-ratio-speeds',
    title: 'Mechanical Gear Ratio (Speed & Teeth)',
    category: 'Engineering',
    subcategory: 'Mechanical Engineering',
    formula: 'GR = N_driven / N_driver',
    expression: 'Ndriven / Ndriver',
    solveFor: {
      GR: 'Ndriven / Ndriver',
      Ndriven: 'GR * Ndriver',
      Ndriver: 'Ndriven / GR'
    },
    variables: [
      { symbol: 'GR', name: 'Gear Ratio (GR)', unit: '', defaultValue: 4.0, min: 0.001 },
      { symbol: 'Ndriven', name: 'Driven Gear Teeth', unit: 'teeth', defaultValue: 60, min: 1 },
      { symbol: 'Ndriver', name: 'Driver Pinion Teeth', unit: 'teeth', defaultValue: 15, min: 1 }
    ],
    description: 'Ratio of gear tooth counts determining torque multiplication and rotational speed reduction.',
    studentExplanation: 'If the big gear has 4 times more teeth than the small driving gear, torque is 4x higher and speed is 4x slower.',
    engineeringExplanation: 'Angular velocity reduction and torque amplification factor in mechanical gear trains and differential gearboxes.',
    usage: 'Automotive gearbox reductions, industrial conveyor gearmotors, and robotics reduction joints.',
    example: 'A 15-tooth pinion driving a 60-tooth gear ➔ Gear Ratio GR = 60 / 15 = 4.0:1.',
    difficulty: 'Beginner',
    tags: ['gear ratio', 'gears', 'speed', 'torque reduction'],
    popularity: 95
  },
  {
    id: 'bernoulli-dynamic-pressure',
    title: 'Bernoulli Dynamic Fluid Pressure',
    category: 'Engineering',
    subcategory: 'Fluid Mechanics',
    formula: 'q = ½ × ρ × v²',
    expression: '0.5 * rho * (v ^ 2)',
    solveFor: {
      q: '0.5 * rho * (v ^ 2)',
      v: 'sqrt((2 * q) / rho)',
      rho: '(2 * q) / (v ^ 2)'
    },
    variables: [
      { symbol: 'q', name: 'Dynamic Pressure (q)', unit: 'Pa', defaultValue: 1531.25, min: 0 },
      { symbol: 'rho', name: 'Fluid Density (ρ)', unit: 'kg/m³', defaultValue: 1.225, min: 0.001 },
      { symbol: 'v', name: 'Flow Velocity (v)', unit: 'm/s', defaultValue: 50 }
    ],
    description: 'Kinetic energy per unit volume of a fluid in motion according to Bernoulli’s conservation principle.',
    studentExplanation: 'The extra forward pressure created by the speed of a flowing fluid or moving wind.',
    engineeringExplanation: 'Dynamic pressure head measured by pitot tubes in airspeed indicators and aerodynamic drag formulations.',
    usage: 'Aircraft pitot-static airspeed sensors, wind turbine aerodynamic thrust, and ventilation duct sizing.',
    example: 'Air (ρ = 1.225 kg/m³) at 50 m/s ➔ Dynamic Pressure q = 0.5 × 1.225 × 2500 = 1531.25 Pa.',
    difficulty: 'Intermediate',
    tags: ['fluids', 'bernoulli', 'dynamic pressure', 'aerodynamics'],
    popularity: 92
  },
  {
    id: 'reynolds-number',
    title: 'Reynolds Number (Flow Regime)',
    category: 'Engineering',
    subcategory: 'Fluid Mechanics',
    formula: 'Re = (ρ × v × D) / μ',
    expression: '(rho * v * D) / mu',
    solveFor: {
      Re: '(rho * v * D) / mu',
      v: '(Re * mu) / (rho * D)'
    },
    variables: [
      { symbol: 'Re', name: 'Reynolds Number (Re)', unit: '', defaultValue: 100000, min: 0 },
      { symbol: 'rho', name: 'Density (ρ)', unit: 'kg/m³', defaultValue: 1000, min: 0.001 },
      { symbol: 'v', name: 'Flow Velocity (v)', unit: 'm/s', defaultValue: 2.0 },
      { symbol: 'D', name: 'Pipe Diameter (D)', unit: 'm', defaultValue: 0.05, min: 0.0001 },
      { symbol: 'mu', name: 'Dynamic Viscosity (μ)', unit: 'Pa·s', defaultValue: 0.001, min: 0.000001 }
    ],
    description: 'Dimensionless ratio of fluid inertial forces to viscous forces predicting laminar vs turbulent flow.',
    studentExplanation: 'Predicts whether fluid flows smoothly in straight layers (laminar, Re < 2300) or swirls chaotically (turbulent, Re > 4000).',
    engineeringExplanation: 'Primary scaling parameter for aerodynamic wind tunnel models and pipe friction Moody friction factor charts.',
    usage: 'Pipe friction head loss calculations, aerodynamic scale model scaling, and heat exchanger turbulence sizing.',
    example: 'Water (ρ = 1000, μ = 0.001) at 2 m/s in a 0.05 m pipe ➔ Re = (1000 × 2 × 0.05) / 0.001 = 100,000 (turbulent).',
    difficulty: 'Intermediate',
    tags: ['fluids', 'reynolds', 'turbulence', 'viscosity'],
    popularity: 93
  },
  {
    id: 'darcy-weisbach-pressure-loss',
    title: 'Darcy-Weisbach Pipe Head Loss',
    category: 'Engineering',
    subcategory: 'Fluid Mechanics',
    formula: 'ΔP = f × (L / D) × (½ × ρ × v²)',
    expression: 'f * (L / D) * 0.5 * rho * (v ^ 2)',
    solveFor: {
      deltaP: 'f * (L / D) * 0.5 * rho * (v ^ 2)',
      L: '(deltaP * D) / (f * 0.5 * rho * (v ^ 2))'
    },
    variables: [
      { symbol: 'deltaP', name: 'Frictional Pressure Drop', unit: 'Pa', defaultValue: 20000, min: 0 },
      { symbol: 'f', name: 'Darcy Friction Factor (f)', unit: '', defaultValue: 0.02, min: 0.001 },
      { symbol: 'L', name: 'Pipe Length (L)', unit: 'm', defaultValue: 50, min: 0.1 },
      { symbol: 'D', name: 'Internal Diameter (D)', unit: 'm', defaultValue: 0.05, min: 0.001 },
      { symbol: 'rho', name: 'Fluid Density (ρ)', unit: 'kg/m³', defaultValue: 1000, min: 0.1 },
      { symbol: 'v', name: 'Mean Velocity (v)', unit: 'm/s', defaultValue: 2.0 }
    ],
    description: 'Pressure loss along a length of pipe due to fluid boundary shear friction.',
    studentExplanation: 'Calculates the pressure lost as liquid rubs against the inside walls of a long pipe.',
    engineeringExplanation: 'Governs pipe friction loss in HVAC chilled water loops, municipal water lines, and oil pipelines.',
    usage: 'Pump head specification sizing, pipeline booster station spacing, and fire sprinkler line sizing.',
    example: 'f = 0.02, L = 50 m, D = 0.05 m, ρ = 1000 kg/m³, v = 2 m/s ➔ ΔP = 0.02 × (50/0.05) × 0.5 × 1000 × 4 = 40,000 Pa.',
    difficulty: 'Advanced',
    tags: ['fluids', 'pipe loss', 'friction', 'pressure drop'],
    popularity: 90
  },
  {
    id: 'carnot-efficiency',
    title: 'Carnot Heat Engine Maximum Efficiency',
    category: 'Engineering',
    subcategory: 'Thermodynamics',
    formula: 'η = (1 - (Tc / Th)) × 100',
    expression: '(1 - (Tc / Th)) * 100',
    solveFor: {
      eta: '(1 - (Tc / Th)) * 100',
      Tc: 'Th * (1 - (eta / 100))',
      Th: 'Tc / (1 - (eta / 100))'
    },
    variables: [
      { symbol: 'eta', name: 'Carnot Thermal Efficiency', unit: '%', defaultValue: 50.0, min: 0, max: 100 },
      { symbol: 'Tc', name: 'Cold Sink Temp (Tc)', unit: 'K', defaultValue: 300, min: 0.01 },
      { symbol: 'Th', name: 'Hot Reservoir Temp (Th)', unit: 'K', defaultValue: 600, min: 0.01 }
    ],
    description: 'Theoretical upper thermodynamic limit on the efficiency of any heat engine operating between two thermal reservoirs.',
    studentExplanation: 'No engine in the universe can be more efficient than a Carnot engine operating between the same two temperatures.',
    engineeringExplanation: 'Second law of thermodynamics benchmark against which real Rankine and Brayton cycles are compared.',
    usage: 'Power plant thermal efficiency benchmarking, geothermal cycle limits, and thermoelectric generator modeling.',
    example: 'Tc = 300 K (room temp), Th = 600 K (steam) ➔ Efficiency η = (1 - 300/600) × 100 = 50%.',
    difficulty: 'Intermediate',
    tags: ['thermodynamics', 'efficiency', 'carnot', 'heat engine'],
    popularity: 92
  },
  {
    id: 'hydraulic-actuator-force',
    title: 'Hydraulic Cylinder Piston Force',
    category: 'Engineering',
    subcategory: 'Mechanical Engineering',
    formula: 'F = P × (π × D² / 4)',
    expression: '(P * 1000000) * (pi * (D ^ 2) / 4)',
    solveFor: {
      F: '(P * 1000000) * (pi * (D ^ 2) / 4)',
      P: 'F / ((pi * (D ^ 2) / 4) * 1000000)'
    },
    variables: [
      { symbol: 'F', name: 'Piston Thrust Force', unit: 'N', defaultValue: 78539.8, min: 0 },
      { symbol: 'P', name: 'Fluid Pressure', unit: 'MPa', defaultValue: 10, min: 0 },
      { symbol: 'D', name: 'Cylinder Bore Diameter', unit: 'm', defaultValue: 0.1, min: 0.001 }
    ],
    description: 'Thrust force generated by a linear hydraulic piston actuator from supply fluid pressure and bore cross-section.',
    studentExplanation: 'High-pressure hydraulic fluid pushes against the circular piston face to lift heavy machinery loads.',
    engineeringExplanation: 'Actuator sizing for industrial presses, excavator booms, and flight control surfaces.',
    usage: 'Heavy construction excavator boom sizing, industrial stamping presses, and injection molding clamping force.',
    example: 'Pressure = 10 MPa (100 bar), Bore D = 0.1 m (Area ≈ 0.00785 m²) ➔ Force F ≈ 78,540 N (78.5 kN).',
    difficulty: 'Intermediate',
    tags: ['hydraulics', 'piston', 'actuator', 'fluid power'],
    popularity: 94
  }
];
