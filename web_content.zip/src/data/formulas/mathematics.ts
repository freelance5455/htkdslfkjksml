import { Formula } from '../../types';

export const MATHEMATICS_FORMULAS: Formula[] = [
  {
    id: 'pythagorean-theorem',
    title: 'Pythagorean Theorem',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'c = √(a² + b²)',
    expression: 'sqrt((a ^ 2) + (b ^ 2))',
    solveFor: {
      c: 'sqrt((a ^ 2) + (b ^ 2))',
      a: 'sqrt((c ^ 2) - (b ^ 2))',
      b: 'sqrt((c ^ 2) - (a ^ 2))'
    },
    variables: [
      { symbol: 'c', name: 'Hypotenuse', unit: 'm', defaultValue: 5, min: 0 },
      { symbol: 'a', name: 'Adjacent Side a', unit: 'm', defaultValue: 3, min: 0 },
      { symbol: 'b', name: 'Opposite Side b', unit: 'm', defaultValue: 4, min: 0 }
    ],
    description: 'Fundamental relationship among the three sides of a right-angled triangle in Euclidean space.',
    studentExplanation: 'In any right triangle, if you square the two shorter legs and add them together, you get the square of the longest side (the hypotenuse).',
    engineeringExplanation: 'Calculates Euclidean geometric displacement magnitude and vector norm in orthogonal 2D Cartesian coordinate transformations.',
    usage: 'Trigonometric surveying, structural diagonal bracing, robotic path plotting, and 2D spatial distance.',
    example: 'A building wall is 4 m tall and a ladder base is 3 m from the wall. The ladder length c = √(3² + 4²) = √25 = 5 m.',
    difficulty: 'Beginner',
    tags: ['geometry', 'triangle', 'hypotenuse', 'pythagoras'],
    popularity: 99
  },
  {
    id: 'quadratic-formula',
    title: 'Quadratic Equation Root',
    category: 'Mathematics',
    subcategory: 'Algebra',
    formula: 'x = (-b + √(b² - 4ac)) / (2a)',
    expression: '(-b + sqrt((b ^ 2) - (4 * a * c))) / (2 * a)',
    solveFor: {
      x: '(-b + sqrt((b ^ 2) - (4 * a * c))) / (2 * a)'
    },
    variables: [
      { symbol: 'x', name: 'Primary Root (x)', unit: '', defaultValue: 3 },
      { symbol: 'a', name: 'Quadratic Coefficient (a)', unit: '', defaultValue: 1, min: 0.00001 },
      { symbol: 'b', name: 'Linear Coefficient (b)', unit: '', defaultValue: -5 },
      { symbol: 'c', name: 'Constant Term (c)', unit: '', defaultValue: 6 }
    ],
    description: 'Closed-form algebraic formula computing real solutions for polynomial equation ax² + bx + c = 0.',
    studentExplanation: 'Solves equations where the highest power of x is squared, finding where the curve crosses the horizontal axis.',
    engineeringExplanation: 'Yields the eigenvalues, trajectory impact times, resonant frequencies, and equilibrium points of second-order dynamic systems.',
    usage: 'Projectile trajectory flight times, control feedback characteristic equations, and optimization maxima.',
    example: 'For x² - 5x + 6 = 0, a = 1, b = -5, c = 6 ➔ x = (5 + √(25 - 24)) / 2 = 3.',
    difficulty: 'Beginner',
    tags: ['algebra', 'polynomial', 'quadratic', 'roots'],
    popularity: 96
  },
  {
    id: 'circle-area',
    title: 'Area of a Circle',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'A = π × r²',
    expression: 'pi * (r ^ 2)',
    solveFor: {
      A: 'pi * (r ^ 2)',
      r: 'sqrt(A / pi)'
    },
    variables: [
      { symbol: 'A', name: 'Enclosed Area', unit: 'm²', defaultValue: 78.54, min: 0 },
      { symbol: 'r', name: 'Radius', unit: 'm', defaultValue: 5, min: 0 }
    ],
    description: 'Enclosed 2D planar space bounded by the circumference of a circle with radius r.',
    studentExplanation: 'How much flat surface is covered inside a round circle of radius r.',
    engineeringExplanation: 'Cross-sectional area of hydraulic pipes, round tensile coupons, and cylindrical pressure vessels.',
    usage: 'Pipe flow capacity sizing, piston surface calculations, and beam cross-sectional inertia.',
    example: 'For radius r = 5 m, Area A = π × 5² ≈ 78.54 m².',
    difficulty: 'Beginner',
    tags: ['circle', 'area', 'geometry', 'pi'],
    popularity: 95
  },
  {
    id: 'circle-circumference',
    title: 'Circumference of a Circle',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'C = 2 × π × r',
    expression: '2 * pi * r',
    solveFor: {
      C: '2 * pi * r',
      r: 'C / (2 * pi)'
    },
    variables: [
      { symbol: 'C', name: 'Circumference Length', unit: 'm', defaultValue: 31.42, min: 0 },
      { symbol: 'r', name: 'Radius', unit: 'm', defaultValue: 5, min: 0 }
    ],
    description: 'Linear perimeter or distance traveled in one complete revolution around a circular boundary.',
    studentExplanation: 'The total distance around the edge of a circle.',
    engineeringExplanation: 'Perimeter measurement for belt drives, circular track perimeters, and rolling wheel forward displacement per revolution.',
    usage: 'Pulley belt length sizing, wheel odometry forward travel per wheel rotation, and turning radii.',
    example: 'Radius r = 5 m ➔ Circumference C = 2 × π × 5 ≈ 31.42 m.',
    difficulty: 'Beginner',
    tags: ['circle', 'circumference', 'perimeter'],
    popularity: 92
  },
  {
    id: 'sphere-volume',
    title: 'Volume of a Sphere',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'V = (4/3) × π × r³',
    expression: '(4 / 3) * pi * (r ^ 3)',
    solveFor: {
      V: '(4 / 3) * pi * (r ^ 3)',
      r: '( (3 * V) / (4 * pi) ) ^ (1 / 3)'
    },
    variables: [
      { symbol: 'V', name: 'Enclosed Volume', unit: 'm³', defaultValue: 33.51, min: 0 },
      { symbol: 'r', name: 'Sphere Radius', unit: 'm', defaultValue: 2, min: 0 }
    ],
    description: 'Total three-dimensional volume contained within a sphere.',
    studentExplanation: 'How much water or air fills a ball of radius r.',
    engineeringExplanation: 'Volumetric capacity of spherical cryogenic storage tanks, raindrop mass estimation, and planetary volume.',
    usage: 'Spherical pressure vessels, gas storage tanks, and ball bearing volume sizing.',
    example: 'Radius r = 2 m ➔ Volume V = (4/3) × π × 8 ≈ 33.51 m³.',
    difficulty: 'Intermediate',
    tags: ['sphere', 'volume', 'geometry', '3d'],
    popularity: 90
  },
  {
    id: 'sphere-surface-area',
    title: 'Surface Area of a Sphere',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'A = 4 × π × r²',
    expression: '4 * pi * (r ^ 2)',
    solveFor: {
      A: '4 * pi * (r ^ 2)',
      r: 'sqrt(A / (4 * pi))'
    },
    variables: [
      { symbol: 'A', name: 'Total Surface Area', unit: 'm²', defaultValue: 50.27, min: 0 },
      { symbol: 'r', name: 'Radius', unit: 'm', defaultValue: 2, min: 0 }
    ],
    description: 'Total exterior outer surface area of a three-dimensional sphere.',
    studentExplanation: 'The total outer skin area needed to wrap completely around a ball.',
    engineeringExplanation: 'Radiative heat transfer area for celestial bodies and aerodynamic friction surface for spherical probes.',
    usage: 'Thermal radiation cooling area, skin friction drag modeling, and balloon membrane material requirements.',
    example: 'r = 2 m ➔ Area A = 4 × π × 4 ≈ 50.27 m².',
    difficulty: 'Intermediate',
    tags: ['sphere', 'surface area', 'geometry'],
    popularity: 88
  },
  {
    id: 'cylinder-volume',
    title: 'Volume of a Cylinder',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'V = π × r² × h',
    expression: 'pi * (r ^ 2) * h',
    solveFor: {
      V: 'pi * (r ^ 2) * h',
      r: 'sqrt(V / (pi * h))',
      h: 'V / (pi * (r ^ 2))'
    },
    variables: [
      { symbol: 'V', name: 'Cylinder Volume', unit: 'm³', defaultValue: 62.83, min: 0 },
      { symbol: 'r', name: 'Bore Radius', unit: 'm', defaultValue: 2, min: 0 },
      { symbol: 'h', name: 'Length / Height', unit: 'm', defaultValue: 5, min: 0 }
    ],
    description: 'Three-dimensional volumetric capacity of a right circular cylinder.',
    studentExplanation: 'The internal holding capacity of a round pipe or cylindrical tank.',
    engineeringExplanation: 'Displacement capacity of internal combustion engine combustion chambers and hydraulic actuators.',
    usage: 'Engine cylinder displacement, liquid storage tank sizing, and pipe containment volume.',
    example: 'r = 2 m, h = 5 m ➔ V = π × 4 × 5 ≈ 62.83 m³.',
    difficulty: 'Beginner',
    tags: ['cylinder', 'volume', 'geometry', 'tanks'],
    popularity: 91
  },
  {
    id: 'cone-volume',
    title: 'Volume of a Cone',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'V = (1/3) × π × r² × h',
    expression: '(1 / 3) * pi * (r ^ 2) * h',
    solveFor: {
      V: '(1 / 3) * pi * (r ^ 2) * h',
      h: '(3 * V) / (pi * (r ^ 2))',
      r: 'sqrt((3 * V) / (pi * h))'
    },
    variables: [
      { symbol: 'V', name: 'Cone Volume', unit: 'm³', defaultValue: 20.94, min: 0 },
      { symbol: 'r', name: 'Base Radius', unit: 'm', defaultValue: 2, min: 0 },
      { symbol: 'h', name: 'Height', unit: 'm', defaultValue: 5, min: 0 }
    ],
    description: 'Volume enclosed inside a circular right cone with base radius r and perpendicular height h.',
    studentExplanation: 'A cone holds exactly one third of the volume of a cylinder with the same base and height.',
    engineeringExplanation: 'Volumetric capacity of conical discharge hoppers, rocket fairings, and aggregate stockpiles.',
    usage: 'Industrial hopper design, rocket nose cone volume estimation, and civil earthwork surveys.',
    example: 'r = 2 m, h = 5 m ➔ V = (1/3) × π × 4 × 5 ≈ 20.94 m³.',
    difficulty: 'Intermediate',
    tags: ['cone', 'volume', 'geometry'],
    popularity: 85
  },
  {
    id: 'distance-2d',
    title: 'Euclidean 2D Distance',
    category: 'Mathematics',
    subcategory: 'Coordinate Geometry',
    formula: 'd = √((x₂ - x₁)² + (y₂ - y₁)²)',
    expression: 'sqrt(((x2 - x1) ^ 2) + ((y2 - y1) ^ 2))',
    solveFor: {
      d: 'sqrt(((x2 - x1) ^ 2) + ((y2 - y1) ^ 2))'
    },
    variables: [
      { symbol: 'd', name: 'Linear Distance', unit: 'm', defaultValue: 5, min: 0 },
      { symbol: 'x1', name: 'Point 1 x₁', unit: 'm', defaultValue: 1 },
      { symbol: 'y1', name: 'Point 1 y₁', unit: 'm', defaultValue: 2 },
      { symbol: 'x2', name: 'Point 2 x₂', unit: 'm', defaultValue: 4 },
      { symbol: 'y2', name: 'Point 2 y₂', unit: 'm', defaultValue: 6 }
    ],
    description: 'Straight line Euclidean geometric distance between two coordinate pairs on a 2D Cartesian plane.',
    studentExplanation: 'The straight ruler distance between two points on a graph grid.',
    engineeringExplanation: 'Computes trajectory tracking errors, planar robot tool head displacement, and GPS relative baseline lengths.',
    usage: 'Robotic navigation, waypoint following, CAD layout drafting, and radar range detection.',
    example: 'From (1, 2) to (4, 6) ➔ d = √((3)² + (4)²) = √25 = 5 m.',
    difficulty: 'Beginner',
    tags: ['coordinate geometry', 'distance', 'euclidean', 'cartesian'],
    popularity: 91
  },
  {
    id: 'slope-formula',
    title: 'Slope of a Line (Gradient)',
    category: 'Mathematics',
    subcategory: 'Coordinate Geometry',
    formula: 'm = (y₂ - y₁) / (x₂ - x₁)',
    expression: '(y2 - y1) / (x2 - x1)',
    solveFor: {
      m: '(y2 - y1) / (x2 - x1)'
    },
    variables: [
      { symbol: 'm', name: 'Slope Gradient', unit: '', defaultValue: 2 },
      { symbol: 'x1', name: 'Point 1 x₁', unit: '', defaultValue: 1 },
      { symbol: 'y1', name: 'Point 1 y₁', unit: '', defaultValue: 3 },
      { symbol: 'x2', name: 'Point 2 x₂', unit: '', defaultValue: 3 },
      { symbol: 'y2', name: 'Point 2 y₂', unit: '', defaultValue: 7 }
    ],
    description: 'Steepness or rate of vertical change with respect to horizontal change between two coordinate points.',
    studentExplanation: 'Rise over run: how much the line goes up divided by how much it goes across.',
    engineeringExplanation: 'First derivative approximation of linear calibration sensor responses and ramp gradient profiling.',
    usage: 'Road grading slope analysis, linear regression lines, and sensor scale factor calibration.',
    example: 'Point (1, 3) to (3, 7) ➔ m = (7 - 3) / (3 - 1) = 4 / 2 = 2.',
    difficulty: 'Beginner',
    tags: ['slope', 'gradient', 'linear', 'coordinates'],
    popularity: 89
  },
  {
    id: 'compound-interest-amount',
    title: 'Compound Interest Future Value',
    category: 'Mathematics',
    subcategory: 'Financial Math',
    formula: 'A = P × (1 + r/n)^(n×t)',
    expression: 'P * ((1 + ((r / 100) / n)) ^ (n * t))',
    solveFor: {
      A: 'P * ((1 + ((r / 100) / n)) ^ (n * t))',
      P: 'A / ((1 + ((r / 100) / n)) ^ (n * t))'
    },
    variables: [
      { symbol: 'A', name: 'Future Accrued Sum', unit: '$', defaultValue: 19671.51, min: 0 },
      { symbol: 'P', name: 'Principal Investment', unit: '$', defaultValue: 10000, min: 0 },
      { symbol: 'r', name: 'Annual Rate', unit: '%', defaultValue: 7, min: 0 },
      { symbol: 'n', name: 'Compounds Per Year', unit: '', defaultValue: 12, min: 1 },
      { symbol: 't', name: 'Duration', unit: 'yr', defaultValue: 10, min: 0 }
    ],
    description: 'Future accumulated sum of money compounding interest n times per annum over period t.',
    studentExplanation: 'How money grows over time when interest earns additional interest on itself.',
    engineeringExplanation: 'Economic capital expenditure depreciation, net present value analysis, and lifecycle cost estimation.',
    usage: 'Engineering economic feasibility studies, plant infrastructure financing, and asset replacement depreciation.',
    example: '$10,000 invested at 7% compounded monthly for 10 years ➔ A = 10,000 × (1 + 0.07/12)^120 ≈ $20,096.61.',
    difficulty: 'Intermediate',
    tags: ['compound interest', 'finance', 'exponential growth'],
    popularity: 93
  },
  {
    id: 'percentage-change-math',
    title: 'Percentage Relative Change',
    category: 'Mathematics',
    subcategory: 'Financial Math',
    formula: 'Δ% = ((V₂ - V₁) / |V₁|) × 100',
    expression: '((V2 - V1) / abs(V1)) * 100',
    solveFor: {
      pct: '((V2 - V1) / abs(V1)) * 100'
    },
    variables: [
      { symbol: 'pct', name: 'Percentage Shift', unit: '%', defaultValue: 50 },
      { symbol: 'V1', name: 'Initial Baseline Value (V₁)', unit: '', defaultValue: 50, min: 0.000001 },
      { symbol: 'V2', name: 'Final Measured Value (V₂)', unit: '', defaultValue: 75 }
    ],
    description: 'Relative proportionate increase or decrease between initial reference value and subsequent measurement.',
    studentExplanation: 'How much something grew or shrunk as a percentage of what it originally was.',
    engineeringExplanation: 'Thermal expansion strain percentages, experimental calibration variance, and operational efficiency gains.',
    usage: 'Experimental error bounds, quality control tolerance testing, and performance benchmarking.',
    example: 'From 50 kg to 75 kg ➔ Change = ((75 - 50) / 50) × 100 = +50%.',
    difficulty: 'Beginner',
    tags: ['percentage', 'increase', 'growth', 'change'],
    popularity: 94
  },
  {
    id: 'arithmetic-sequence-nth',
    title: 'Arithmetic Sequence Nth Term',
    category: 'Mathematics',
    subcategory: 'Algebra',
    formula: 'aₙ = a₁ + (n - 1) × d',
    expression: 'a1 + ((n - 1) * d)',
    solveFor: {
      an: 'a1 + ((n - 1) * d)',
      a1: 'an - ((n - 1) * d)',
      d: '(an - a1) / (n - 1)'
    },
    variables: [
      { symbol: 'an', name: 'N-th Term Value', unit: '', defaultValue: 29 },
      { symbol: 'a1', name: 'Initial Term (a₁)', unit: '', defaultValue: 2 },
      { symbol: 'n', name: 'Term Position (n)', unit: '', defaultValue: 10, min: 1 },
      { symbol: 'd', name: 'Common Difference (d)', unit: '', defaultValue: 3 }
    ],
    description: 'Value of any element at index n in a constant-step sequence where successive elements differ by d.',
    studentExplanation: 'Finds any number in a pattern of numbers that increases by the same fixed step each time.',
    engineeringExplanation: 'Discrete equidistant time-series indexing, digital clock cycle counters, and stepper motor pulse counting.',
    usage: 'Stepper motor stepping arrays, gear teeth indexing, and discrete digital sampling.',
    example: 'Starting at a1 = 2 with step d = 3, the 10th term is a10 = 2 + (9 × 3) = 29.',
    difficulty: 'Beginner',
    tags: ['sequence', 'arithmetic', 'series', 'algebra'],
    popularity: 87
  },
  {
    id: 'geometric-sequence-nth',
    title: 'Geometric Sequence Nth Term',
    category: 'Mathematics',
    subcategory: 'Algebra',
    formula: 'aₙ = a₁ × r^(n - 1)',
    expression: 'a1 * (r ^ (n - 1))',
    solveFor: {
      an: 'a1 * (r ^ (n - 1))',
      a1: 'an / (r ^ (n - 1))'
    },
    variables: [
      { symbol: 'an', name: 'N-th Term Value', unit: '', defaultValue: 512 },
      { symbol: 'a1', name: 'Initial Term (a₁)', unit: '', defaultValue: 2 },
      { symbol: 'r', name: 'Common Ratio (r)', unit: '', defaultValue: 2 },
      { symbol: 'n', name: 'Term Position (n)', unit: '', defaultValue: 9, min: 1 }
    ],
    description: 'Value of the n-th element in a sequence where each subsequent term is multiplied by a constant ratio r.',
    studentExplanation: 'Finds the number at any step in a multiplying pattern like doubling or tripling.',
    engineeringExplanation: 'Radioactive isotope half-life decay stages, binary memory cell address spaces, and gear reduction ratios.',
    usage: 'Binary digital word sizing, acoustic decibel steps, and chemical decay half-life countdowns.',
    example: 'a1 = 2, r = 2, n = 9 ➔ a9 = 2 × 2^8 = 2 × 256 = 512.',
    difficulty: 'Intermediate',
    tags: ['sequence', 'geometric', 'exponential', 'algebra'],
    popularity: 86
  },
  {
    id: 'law-of-cosines',
    title: 'Law of Cosines (Side c)',
    category: 'Mathematics',
    subcategory: 'Trigonometry',
    formula: 'c = √(a² + b² - 2ab × cos(C))',
    expression: 'sqrt((a ^ 2) + (b ^ 2) - (2 * a * b * cos((C * pi) / 180)))',
    solveFor: {
      c: 'sqrt((a ^ 2) + (b ^ 2) - (2 * a * b * cos((C * pi) / 180)))'
    },
    variables: [
      { symbol: 'c', name: 'Opposite Side c', unit: 'm', defaultValue: 6.08, min: 0 },
      { symbol: 'a', name: 'Adjacent Side a', unit: 'm', defaultValue: 5, min: 0 },
      { symbol: 'b', name: 'Adjacent Side b', unit: 'm', defaultValue: 7, min: 0 },
      { symbol: 'C', name: 'Included Angle C', unit: 'deg', defaultValue: 60, min: 0, max: 180 }
    ],
    description: 'Generalization of the Pythagorean theorem relating the sides of any arbitrary triangle to the cosine of its angle.',
    studentExplanation: 'Lets you find the third side of any triangle when you know two sides and the angle between them.',
    engineeringExplanation: 'Resolves resultant forces in non-orthogonal vector polygons and mechanical link arm lengths.',
    usage: 'Robot kinematic limb linkages, triangulation surveying, and non-orthogonal force vector addition.',
    example: 'a = 5, b = 7, Angle C = 60° ➔ c = √(25 + 49 - 2(5)(7)(0.5)) = √(74 - 35) = √39 ≈ 6.24 m.',
    difficulty: 'Intermediate',
    tags: ['trigonometry', 'law of cosines', 'triangle', 'vectors'],
    popularity: 91
  },
  {
    id: 'law-of-sines',
    title: 'Law of Sines (Side b)',
    category: 'Mathematics',
    subcategory: 'Trigonometry',
    formula: 'b = (a × sin(B)) / sin(A)',
    expression: '(a * sin((B * pi) / 180)) / sin((A * pi) / 180)',
    solveFor: {
      b: '(a * sin((B * pi) / 180)) / sin((A * pi) / 180)'
    },
    variables: [
      { symbol: 'b', name: 'Side b', unit: 'm', defaultValue: 7.07, min: 0 },
      { symbol: 'a', name: 'Side a', unit: 'm', defaultValue: 5, min: 0 },
      { symbol: 'A', name: 'Opposite Angle A', unit: 'deg', defaultValue: 30, min: 0.1, max: 179.9 },
      { symbol: 'B', name: 'Opposite Angle B', unit: 'deg', defaultValue: 45, min: 0.1, max: 179.9 }
    ],
    description: 'Relates lengths of sides of any planar triangle to the sines of their corresponding opposite angles.',
    studentExplanation: 'If you know one side and its opposite angle, you can find other sides using their angles.',
    engineeringExplanation: 'Solves unknown members in structural roof trusses and navigational triangulation fixes.',
    usage: 'Triangulation navigation, civil surveyor station positioning, and roof truss member load paths.',
    example: 'a = 5 m, A = 30°, B = 45° ➔ b = (5 × sin(45°)) / sin(30°) = (5 × 0.7071) / 0.5 ≈ 7.07 m.',
    difficulty: 'Intermediate',
    tags: ['trigonometry', 'law of sines', 'triangulation'],
    popularity: 89
  },
  {
    id: 'trapezoid-area',
    title: 'Area of a Trapezoid',
    category: 'Mathematics',
    subcategory: 'Geometry',
    formula: 'A = ((a + b) / 2) × h',
    expression: '((a + b) / 2) * h',
    solveFor: {
      A: '((a + b) / 2) * h',
      h: '(2 * A) / (a + b)'
    },
    variables: [
      { symbol: 'A', name: 'Trapezoid Area', unit: 'm²', defaultValue: 30, min: 0 },
      { symbol: 'a', name: 'Parallel Base a', unit: 'm', defaultValue: 4, min: 0 },
      { symbol: 'b', name: 'Parallel Base b', unit: 'm', defaultValue: 8, min: 0 },
      { symbol: 'h', name: 'Height', unit: 'm', defaultValue: 5, min: 0 }
    ],
    description: 'Enclosed 2D area of a quadrilateral having at least one pair of parallel boundary edges.',
    studentExplanation: 'Average the top and bottom parallel lengths and multiply by the straight vertical height.',
    engineeringExplanation: 'Numerical trapezoidal rule integration for fluid velocity profiles and canal cross-sections.',
    usage: 'Canal ditch excavating volume estimates, hydrodynamics channel flow cross-sections, and numerical integration.',
    example: 'Base a = 4 m, b = 8 m, height h = 5 m ➔ Area A = ((4 + 8) / 2) × 5 = 30 m².',
    difficulty: 'Beginner',
    tags: ['trapezoid', 'area', 'geometry', 'integration'],
    popularity: 87
  },
  {
    id: 'standard-score-z',
    title: 'Standard Normal Z-Score',
    category: 'Mathematics',
    subcategory: 'Statistics',
    formula: 'Z = (x - μ) / σ',
    expression: '(x - mu) / sigma',
    solveFor: {
      Z: '(x - mu) / sigma',
      x: 'mu + (Z * sigma)',
      mu: 'x - (Z * sigma)',
      sigma: '(x - mu) / Z'
    },
    variables: [
      { symbol: 'Z', name: 'Z-Score Value', unit: '', defaultValue: 1.5 },
      { symbol: 'x', name: 'Observed Sample (x)', unit: '', defaultValue: 85 },
      { symbol: 'mu', name: 'Population Mean (μ)', unit: '', defaultValue: 70 },
      { symbol: 'sigma', name: 'Std Deviation (σ)', unit: '', defaultValue: 10, min: 0.0001 }
    ],
    description: 'Dimensionless score expressing the distance of a raw observation from the population mean in standard deviation units.',
    studentExplanation: 'Tells you how many standard deviations above or below average a particular test score is.',
    engineeringExplanation: 'Statistical process quality control (Six Sigma), sensor tolerance distribution gating, and reliability bounds.',
    usage: 'Six Sigma manufacturing error limits, sensor outlier elimination, and component defect rate predictions.',
    example: 'Sample x = 85 on a test with mean μ = 70 and σ = 10 ➔ Z = (85 - 70) / 10 = +1.5 standard deviations.',
    difficulty: 'Beginner',
    tags: ['statistics', 'z-score', 'normal distribution', 'six-sigma'],
    popularity: 91
  },
  {
    id: 'sample-variance',
    title: 'Sample Variance Approximation',
    category: 'Mathematics',
    subcategory: 'Statistics',
    formula: 's² = SS / (n - 1)',
    expression: 'SS / (n - 1)',
    solveFor: {
      s2: 'SS / (n - 1)',
      SS: 's2 * (n - 1)'
    },
    variables: [
      { symbol: 's2', name: 'Sample Variance (s²)', unit: '', defaultValue: 12.5, min: 0 },
      { symbol: 'SS', name: 'Sum of Squared Deviations', unit: '', defaultValue: 112.5, min: 0 },
      { symbol: 'n', name: 'Sample Size (n)', unit: '', defaultValue: 10, min: 2 }
    ],
    description: 'Unbiased estimator of statistical dispersion measuring how far sample values spread out from their mean.',
    studentExplanation: 'Measures how widely spread out data values are around the center.',
    engineeringExplanation: 'Calculates sensor noise variance for Kalman filtering covariance matrices and tolerance scatter.',
    usage: 'Kalman filter noise tuning, manufacturing dimension spread analysis, and quality auditing.',
    example: 'Sum of squared deviations SS = 112.5 across sample n = 10 ➔ Variance s² = 112.5 / 9 = 12.5.',
    difficulty: 'Intermediate',
    tags: ['statistics', 'variance', 'dispersion', 'kalman'],
    popularity: 84
  },
  {
    id: 'logarithm-change-base',
    title: 'Logarithm Arbitrary Base',
    category: 'Mathematics',
    subcategory: 'Algebra',
    formula: 'log_b(x) = ln(x) / ln(b)',
    expression: 'ln(x) / ln(b)',
    solveFor: {
      y: 'ln(x) / ln(b)'
    },
    variables: [
      { symbol: 'y', name: 'Logarithm Output', unit: '', defaultValue: 3 },
      { symbol: 'x', name: 'Input Argument (x)', unit: '', defaultValue: 8, min: 0.000001 },
      { symbol: 'b', name: 'Desired Base (b)', unit: '', defaultValue: 2, min: 0.000001 }
    ],
    description: 'Evaluates logarithm of quantity x to an arbitrary positive base b using standard natural logarithms.',
    studentExplanation: 'Finds what power you must raise the base b to in order to get x.',
    engineeringExplanation: 'Information theory Shannon entropy bits (base 2), decibel power attenuation (base 10), and RC time constants (base e).',
    usage: 'Digital communication bit entropy, audio decibels, and exponential halflife solutions.',
    example: 'Argument x = 8 to base b = 2 ➔ log₂(8) = ln(8) / ln(2) = 3.',
    difficulty: 'Intermediate',
    tags: ['logarithm', 'algebra', 'exponential', 'shannon'],
    popularity: 88
  }
];
