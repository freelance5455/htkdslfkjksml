import { Formula } from '../../types';

export const CHEMISTRY_FORMULAS: Formula[] = [
  {
    id: 'ideal-gas-law-pressure',
    title: 'Ideal Gas Law (Pressure)',
    category: 'Chemistry',
    subcategory: 'Gas Laws',
    formula: 'P = (n × R × T) / V',
    expression: '(n * 8.31446 * T) / V',
    solveFor: {
      P: '(n * 8.31446 * T) / V',
      V: '(n * 8.31446 * T) / P',
      T: '(P * V) / (n * 8.31446)',
      n: '(P * V) / (8.31446 * T)'
    },
    variables: [
      { symbol: 'P', name: 'Pressure', unit: 'Pa', defaultValue: 101325, min: 0 },
      { symbol: 'n', name: 'Amount of Gas', unit: 'mol', defaultValue: 1, min: 0.0001 },
      { symbol: 'T', name: 'Absolute Temperature', unit: 'K', defaultValue: 298.15, min: 0.01 },
      { symbol: 'V', name: 'Gas Volume', unit: 'm³', defaultValue: 0.02446, min: 0.000001 }
    ],
    description: 'Equation of state of a hypothetical ideal gas relating pressure, volume, quantity, and absolute temperature.',
    studentExplanation: 'Describes how pressure, volume, temperature, and number of gas particles are all locked together.',
    engineeringExplanation: 'Thermodynamic equation of state for low-pressure gas compression, pneumatic tanks, and chamber pressures.',
    usage: 'Combustion cylinder pressure modeling, chemical reactor vessel design, and gas storage cylinder capacity.',
    example: 'n = 1 mol at T = 298.15 K in V = 0.02446 m³ ➔ P = (1 × 8.314 × 298.15) / 0.02446 ≈ 101,325 Pa (1 atm).',
    difficulty: 'Intermediate',
    tags: ['gas', 'ideal gas', 'chemistry', 'thermodynamics'],
    popularity: 97,
    featured: true
  },
  {
    id: 'molarity-formula',
    title: 'Molarity (Molar Concentration)',
    category: 'Chemistry',
    subcategory: 'Solutions',
    formula: 'M = n / V',
    expression: 'n / V',
    solveFor: {
      M: 'n / V',
      n: 'M * V',
      V: 'n / M'
    },
    variables: [
      { symbol: 'M', name: 'Molarity (Concentration)', unit: 'mol/L', defaultValue: 0.25, min: 0 },
      { symbol: 'n', name: 'Solute Amount', unit: 'mol', defaultValue: 0.5, min: 0 },
      { symbol: 'V', name: 'Solution Volume', unit: 'L', defaultValue: 2.0, min: 0.0001 }
    ],
    description: 'Molar concentration defined as the number of moles of solute dissolved per liter of total solution.',
    studentExplanation: 'Tells you how concentrated or dilute a chemical solution is based on how many molecules are in a liter of liquid.',
    engineeringExplanation: 'Chemical reactor reactant feed concentration governing reaction kinetic rates.',
    usage: 'Titration stoichiometry, chemical reagent preparation, and wastewater effluent dosing.',
    example: 'Dissolving 0.5 moles of NaCl into 2.0 L of water gives M = 0.5 / 2.0 = 0.25 mol/L.',
    difficulty: 'Beginner',
    tags: ['molarity', 'concentration', 'solution', 'stoichiometry'],
    popularity: 95
  },
  {
    id: 'moles-from-mass',
    title: 'Chemical Moles from Mass',
    category: 'Chemistry',
    subcategory: 'Stoichiometry',
    formula: 'n = m / M_mol',
    expression: 'm / M_mol',
    solveFor: {
      n: 'm / M_mol',
      m: 'n * M_mol',
      M_mol: 'm / n'
    },
    variables: [
      { symbol: 'n', name: 'Number of Moles', unit: 'mol', defaultValue: 1.0, min: 0 },
      { symbol: 'm', name: 'Mass of Substance', unit: 'g', defaultValue: 18.015, min: 0 },
      { symbol: 'M_mol', name: 'Molar Mass', unit: 'g/mol', defaultValue: 18.015, min: 0.001 }
    ],
    description: 'Calculates the number of chemical moles of a substance from its mass and known molar mass.',
    studentExplanation: 'A mole is just a chemist’s counting number (like a dozen). This converts weight in grams into chemical counts.',
    engineeringExplanation: 'Gravimetric stoichiometry conversion from laboratory scale weight to stoichiometric reaction equivalents.',
    usage: 'Industrial chemical feed batching, raw material consumption, and yield prediction.',
    example: '18.015 g of water (H₂O, M_mol = 18.015 g/mol) ➔ n = 18.015 / 18.015 = 1.0 mol.',
    difficulty: 'Beginner',
    tags: ['moles', 'mass', 'molar mass', 'stoichiometry'],
    popularity: 96
  },
  {
    id: 'boyles-law',
    title: "Boyle's Gas Law (Final Pressure)",
    category: 'Chemistry',
    subcategory: 'Gas Laws',
    formula: 'P₂ = (P₁ × V₁) / V₂',
    expression: '(P1 * V1) / V2',
    solveFor: {
      P2: '(P1 * V1) / V2',
      V2: '(P1 * V1) / P2',
      P1: '(P2 * V2) / V1',
      V1: '(P2 * V2) / P1'
    },
    variables: [
      { symbol: 'P2', name: 'Final Pressure (P₂)', unit: 'kPa', defaultValue: 200, min: 0 },
      { symbol: 'P1', name: 'Initial Pressure (P₁)', unit: 'kPa', defaultValue: 100, min: 0 },
      { symbol: 'V1', name: 'Initial Volume (V₁)', unit: 'L', defaultValue: 10, min: 0.001 },
      { symbol: 'V2', name: 'Final Volume (V₂)', unit: 'L', defaultValue: 5, min: 0.001 }
    ],
    description: 'At constant temperature, the absolute pressure of a fixed mass of gas is inversely proportional to its volume.',
    studentExplanation: 'If you squeeze a gas into half the space without changing temperature, its pressure doubles.',
    engineeringExplanation: 'Isothermal expansion and compression in positive displacement gas compressors and syringe pumps.',
    usage: 'Scuba diving tank expansion, syringe volume pumps, and pneumatic compressor sizing.',
    example: 'Gas at P1 = 100 kPa and V1 = 10 L compressed into V2 = 5 L ➔ P2 = (100 × 10) / 5 = 200 kPa.',
    difficulty: 'Beginner',
    tags: ['boyle', 'gas law', 'pressure', 'volume'],
    popularity: 91
  },
  {
    id: 'charles-law',
    title: "Charles's Gas Law (Final Volume)",
    category: 'Chemistry',
    subcategory: 'Gas Laws',
    formula: 'V₂ = (V₁ × T₂) / T₁',
    expression: '(V1 * T2) / T1',
    solveFor: {
      V2: '(V1 * T2) / T1',
      T2: '(V2 * T1) / V1',
      V1: '(V2 * T1) / T2',
      T1: '(V1 * T2) / V2'
    },
    variables: [
      { symbol: 'V2', name: 'Final Volume (V₂)', unit: 'L', defaultValue: 3.0, min: 0 },
      { symbol: 'V1', name: 'Initial Volume (V₁)', unit: 'L', defaultValue: 2.0, min: 0 },
      { symbol: 'T1', name: 'Initial Temp (T₁)', unit: 'K', defaultValue: 300, min: 0.01 },
      { symbol: 'T2', name: 'Final Temp (T₂)', unit: 'K', defaultValue: 450, min: 0.01 }
    ],
    description: 'At constant pressure, gas volume is directly proportional to absolute thermodynamic temperature.',
    studentExplanation: 'Heating a gas makes it expand; cooling a gas makes it shrink.',
    engineeringExplanation: 'Isobaric thermal expansion in hot air balloons and pneumatic thermal actuators.',
    usage: 'Hot air balloon buoyancy lifts, constant pressure thermal engines, and atmospheric ballooning.',
    example: 'V1 = 2 L at 300 K heated to 450 K ➔ V2 = (2 × 450) / 300 = 3.0 L.',
    difficulty: 'Beginner',
    tags: ['charles', 'temperature', 'volume', 'gas law'],
    popularity: 89
  },
  {
    id: 'solution-dilution',
    title: 'Chemical Dilution Law (C₁V₁ = C₂V₂)',
    category: 'Chemistry',
    subcategory: 'Solutions',
    formula: 'C₂ = (C₁ × V₁) / V₂',
    expression: '(C1 * V1) / V2',
    solveFor: {
      C2: '(C1 * V1) / V2',
      V2: '(C1 * V1) / C2',
      V1: '(C2 * V2) / C1',
      C1: '(C2 * V2) / V1'
    },
    variables: [
      { symbol: 'C2', name: 'Final Concentration (C₂)', unit: 'M', defaultValue: 0.6, min: 0 },
      { symbol: 'C1', name: 'Stock Concentration (C₁)', unit: 'M', defaultValue: 6.0, min: 0 },
      { symbol: 'V1', name: 'Stock Volume Added (V₁)', unit: 'mL', defaultValue: 50, min: 0 },
      { symbol: 'V2', name: 'Total Final Volume (V₂)', unit: 'mL', defaultValue: 500, min: 0.001 }
    ],
    description: 'Calculates target concentration after adding solvent to a concentrated stock chemical reagent.',
    studentExplanation: 'Adding pure water dilutes a concentrated juice or chemical, spreading the same molecules across a larger volume.',
    engineeringExplanation: 'Conservation of solute mass during non-reactive solvent blending in process tanks.',
    usage: 'Preparing bench chemicals from concentrated acids, automated liquid dosing, and pharmaceutical mixing.',
    example: '50 mL of 6 M stock acid diluted to 500 mL total ➔ C2 = (6 × 50) / 500 = 0.6 M.',
    difficulty: 'Beginner',
    tags: ['dilution', 'concentration', 'solution', 'chemistry lab'],
    popularity: 93
  },
  {
    id: 'ph-from-hydrogen',
    title: 'Aqueous pH from Hydrogen Ion [H⁺]',
    category: 'Chemistry',
    subcategory: 'Solutions',
    formula: 'pH = -log₁₀([H⁺])',
    expression: '-1 * log10(H)',
    solveFor: {
      pH: '-1 * log10(H)'
    },
    variables: [
      { symbol: 'pH', name: 'Solution pH', unit: '', defaultValue: 7.0 },
      { symbol: 'H', name: 'Hydrogen Ion [H⁺]', unit: 'mol/L', defaultValue: 0.0000001, min: 0.00000000000001 }
    ],
    description: 'Logarithmic scale expressing acidity or alkalinity of an aqueous chemical solution.',
    studentExplanation: 'A scale from 0 (very acidic) to 14 (very basic), where 7 is neutral pure water.',
    engineeringExplanation: 'Negative logarithm of hydronium ion activity governing electrochemical corrosion and chemical titration curves.',
    usage: 'Wastewater neutralizer dosing, biological fermentation broth monitoring, and swimming pool chemistry.',
    example: '[H⁺] = 1×10⁻⁷ mol/L ➔ pH = -log₁₀(10⁻⁷) = 7.0 (neutral).',
    difficulty: 'Intermediate',
    tags: ['ph', 'acid', 'base', 'acidity', 'log'],
    popularity: 94
  },
  {
    id: 'beer-lambert-absorbance',
    title: 'Beer-Lambert Spectrophotometry',
    category: 'Chemistry',
    subcategory: 'Solutions',
    formula: 'A = ε × b × c',
    expression: 'epsilon * b * c',
    solveFor: {
      A: 'epsilon * b * c',
      c: 'A / (epsilon * b)',
      b: 'A / (epsilon * c)',
      epsilon: 'A / (b * c)'
    },
    variables: [
      { symbol: 'A', name: 'Light Absorbance (A)', unit: '', defaultValue: 1.0, min: 0 },
      { symbol: 'epsilon', name: 'Molar Extinction (ε)', unit: 'L/(mol·cm)', defaultValue: 10000, min: 0 },
      { symbol: 'b', name: 'Path Length (b)', unit: 'cm', defaultValue: 1.0, min: 0.001 },
      { symbol: 'c', name: 'Analyte Concentration (c)', unit: 'mol/L', defaultValue: 0.0001, min: 0 }
    ],
    description: 'Linear relationship between light absorbance and concentration of an absorbing chemical substance.',
    studentExplanation: 'A darker or more concentrated liquid absorbs more light passing through it.',
    engineeringExplanation: 'Quantitative optical spectroscopy calibration curve for inline chemical concentration sensors.',
    usage: 'Colorimetric water purity testing, protein concentration assays, and automated chemical chromatography.',
    example: 'ε = 10,000, b = 1 cm, c = 0.0001 M ➔ Absorbance A = 10,000 × 1 × 0.0001 = 1.0.',
    difficulty: 'Intermediate',
    tags: ['spectroscopy', 'absorbance', 'concentration', 'beer-lambert'],
    popularity: 88
  },
  {
    id: 'gibbs-free-energy-chem',
    title: 'Gibbs Free Energy Reaction Spontaneity',
    category: 'Chemistry',
    subcategory: 'Thermochemistry',
    formula: 'ΔG = ΔH - (T × ΔS)',
    expression: 'deltaH - (T * (deltaS / 1000))',
    solveFor: {
      deltaG: 'deltaH - (T * (deltaS / 1000))'
    },
    variables: [
      { symbol: 'deltaG', name: 'Gibbs Free Energy (ΔG)', unit: 'kJ/mol', defaultValue: -20.2 },
      { symbol: 'deltaH', name: 'Enthalpy Change (ΔH)', unit: 'kJ/mol', defaultValue: -50.0 },
      { symbol: 'T', name: 'Temperature (T)', unit: 'K', defaultValue: 298.15, min: 0.01 },
      { symbol: 'deltaS', name: 'Entropy Change (ΔS)', unit: 'J/(mol·K)', defaultValue: -100.0 }
    ],
    description: 'Thermodynamic potential used to predict whether a chemical process is thermodynamically spontaneous (ΔG < 0).',
    studentExplanation: 'Tells you if a chemical reaction will happen on its own (spontaneously) at a given temperature.',
    engineeringExplanation: 'Criterion of chemical equilibrium; establishes maximum non-expansion work obtainable from a chemical reactor.',
    usage: 'Battery cell discharge potential, industrial catalyst operating temperatures, and fuel cell voltage limits.',
    example: 'ΔH = -50 kJ/mol, T = 298 K, ΔS = -100 J/(mol·K) ➔ ΔG = -50 - (298 × -0.1) = -20.2 kJ/mol (spontaneous).',
    difficulty: 'Advanced',
    tags: ['thermodynamics', 'gibbs', 'enthalpy', 'entropy', 'spontaneous'],
    popularity: 90
  },
  {
    id: 'radioactive-decay-halflife',
    title: 'Radioactive Isotope Decay',
    category: 'Chemistry',
    subcategory: 'Atomic',
    formula: 'N(t) = N₀ × (½)^(t / t_half)',
    expression: 'N0 * (0.5 ^ (t / thalf))',
    solveFor: {
      Nt: 'N0 * (0.5 ^ (t / thalf))',
      N0: 'Nt / (0.5 ^ (t / thalf))'
    },
    variables: [
      { symbol: 'Nt', name: 'Remaining Quantity N(t)', unit: 'g', defaultValue: 12.5, min: 0 },
      { symbol: 'N0', name: 'Initial Quantity (N₀)', unit: 'g', defaultValue: 100, min: 0 },
      { symbol: 't', name: 'Elapsed Time (t)', unit: 'yr', defaultValue: 30, min: 0 },
      { symbol: 'thalf', name: 'Half-Life (t½)', unit: 'yr', defaultValue: 10, min: 0.0001 }
    ],
    description: 'Exponential decay rate of unstable radioactive nuclides over multiple half-lives.',
    studentExplanation: 'Every time one half-life passes, exactly half of the remaining radioactive atoms decay away.',
    engineeringExplanation: 'First-order nuclear kinetics for radiocarbon dating and radioisotope thermoelectric generator power decline.',
    usage: 'Archaeological carbon dating, nuclear waste repository decay cooling, and medical tracer dosage timing.',
    example: 'Initial N0 = 100 g with half-life 10 yr after 30 yr (3 half-lives) ➔ Nt = 100 × (0.5)³ = 12.5 g.',
    difficulty: 'Intermediate',
    tags: ['decay', 'nuclear', 'half-life', 'exponential'],
    popularity: 91
  }
];
