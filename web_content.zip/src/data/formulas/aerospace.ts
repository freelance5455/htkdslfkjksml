import { Formula } from '../../types';

export const AEROSPACE_FORMULAS: Formula[] = [
  {
    id: 'tsiolkovsky-rocket-equation',
    title: 'Tsiolkovsky Rocket Equation (Delta-V)',
    category: 'Aerospace',
    subcategory: 'Rocket Propulsion',
    formula: 'Δv = Isp × g₀ × ln(m₀ / mf)',
    expression: 'Isp * 9.80665 * ln(m0 / mf)',
    solveFor: {
      deltav: 'Isp * 9.80665 * ln(m0 / mf)',
      m0: 'mf * (e ^ (deltav / (Isp * 9.80665)))',
      mf: 'm0 / (e ^ (deltav / (Isp * 9.80665)))'
    },
    variables: [
      { symbol: 'deltav', name: 'Velocity Change (Δv)', unit: 'm/s', defaultValue: 4729.8, min: 0 },
      { symbol: 'Isp', name: 'Specific Impulse (Isp)', unit: 's', defaultValue: 300, min: 1 },
      { symbol: 'm0', name: 'Initial Wet Mass (m₀)', unit: 'kg', defaultValue: 1000, min: 1 },
      { symbol: 'mf', name: 'Final Dry Mass (mf)', unit: 'kg', defaultValue: 200, min: 1 }
    ],
    description: 'Calculates the velocity change achieved by an unthrottled rocket from expelling reaction propellant mass.',
    studentExplanation: 'The foundational equation of spaceflight: tells you how fast a rocket can go based on its engine efficiency (Isp) and how much fuel it burns.',
    engineeringExplanation: 'Governs orbital payload mass fractions, multi-stage launch vehicle mass sizing, and interplanetary trajectory delta-v budgets.',
    usage: 'Launch vehicle staging design, orbital insertion maneuvers, and deep-space probe trajectory planning.',
    example: 'Isp = 300 s, m0 = 1000 kg, mf = 200 kg ➔ Δv = 300 × 9.80665 × ln(1000 / 200) ≈ 4730 m/s (~4.73 km/s).',
    difficulty: 'Advanced',
    tags: ['rocket equation', 'delta-v', 'tsiolkovsky', 'propulsion', 'spaceflight'],
    popularity: 100,
    featured: true
  },
  {
    id: 'circular-orbital-velocity',
    title: 'Circular Orbital Speed',
    category: 'Aerospace',
    subcategory: 'Orbital Mechanics',
    formula: 'v = √(G × M / r)',
    expression: 'sqrt((6.6743e-11 * M) / r)',
    solveFor: {
      v: 'sqrt((6.6743e-11 * M) / r)',
      r: '(6.6743e-11 * M) / (v ^ 2)'
    },
    variables: [
      { symbol: 'v', name: 'Orbital Velocity (v)', unit: 'm/s', defaultValue: 7672, min: 0 },
      { symbol: 'M', name: 'Central Body Mass (M)', unit: 'kg', defaultValue: 5.972e24, min: 1000 },
      { symbol: 'r', name: 'Orbit Radius from Center (r)', unit: 'm', defaultValue: 6771000, min: 1000 }
    ],
    description: 'Tangential orbital velocity required to maintain a circular Keplerian orbit around a primary gravitational body of mass M.',
    studentExplanation: 'How fast a satellite must fly sideways so that as it falls toward Earth, the Earth curves away beneath it at the exact same rate!',
    engineeringExplanation: 'Equates centripetal acceleration to gravitational field strength: v² / r = GM / r².',
    usage: 'Low Earth Orbit (LEO) satellite stationkeeping, International Space Station orbit velocity, and geostationary transfer.',
    example: 'Earth LEO at 400 km altitude (r = 6,771,000 m) ➔ v = √((6.6743×10⁻¹¹ × 5.972×10²⁴) / 6771000) ≈ 7672 m/s (~7.67 km/s).',
    difficulty: 'Intermediate',
    tags: ['orbital velocity', 'satellite', 'leo', 'orbit', 'gravity'],
    popularity: 97
  },
  {
    id: 'escape-velocity-space',
    title: 'Gravitational Escape Velocity',
    category: 'Aerospace',
    subcategory: 'Orbital Mechanics',
    formula: 'v_esc = √(2 × G × M / r)',
    expression: 'sqrt((2 * 6.6743e-11 * M) / r)',
    solveFor: {
      vesc: 'sqrt((2 * 6.6743e-11 * M) / r)',
      r: '(2 * 6.6743e-11 * M) / (vesc ^ 2)'
    },
    variables: [
      { symbol: 'vesc', name: 'Escape Speed (v_esc)', unit: 'm/s', defaultValue: 11186, min: 0 },
      { symbol: 'M', name: 'Primary Mass (M)', unit: 'kg', defaultValue: 5.972e24, min: 1 },
      { symbol: 'r', name: 'Distance from Center (r)', unit: 'm', defaultValue: 6371000, min: 1 }
    ],
    description: 'Minimum speed an unpropelled body needs to completely escape the gravitational influence of a primary body to infinity.',
    studentExplanation: 'The exact speed needed to break free from a planet’s gravity and never fall back down without ever firing engines again.',
    engineeringExplanation: 'Conservation of mechanical energy setting parabolic escape trajectory (total orbital specific energy ε = 0).',
    usage: 'Interplanetary departure hyperbolic excess velocity sizing and lunar trajectory injection.',
    example: 'From Earth surface (r = 6.371×10⁶ m) ➔ v_esc = √(2 × 6.6743×10⁻¹¹ × 5.972×10²⁴ / 6.371×10⁶) ≈ 11,186 m/s (~11.2 km/s).',
    difficulty: 'Intermediate',
    tags: ['escape velocity', 'gravity', 'spaceflight', 'interplanetary'],
    popularity: 96
  },
  {
    id: 'keplers-third-law-period',
    title: "Kepler's Third Law (Orbital Period)",
    category: 'Aerospace',
    subcategory: 'Orbital Mechanics',
    formula: 'T = 2 × π × √(a³ / (G × M))',
    expression: '2 * pi * sqrt((a ^ 3) / (6.6743e-11 * M))',
    solveFor: {
      T: '2 * pi * sqrt((a ^ 3) / (6.6743e-11 * M))',
      a: '(( (T / (2 * pi)) ^ 2 ) * (6.6743e-11 * M)) ^ (1 / 3)'
    },
    variables: [
      { symbol: 'T', name: 'Orbital Period (T)', unit: 's', defaultValue: 5554, min: 1 },
      { symbol: 'a', name: 'Semi-Major Axis (a)', unit: 'm', defaultValue: 6771000, min: 1000 },
      { symbol: 'M', name: 'Central Mass (M)', unit: 'kg', defaultValue: 5.972e24, min: 1000 }
    ],
    description: 'Time required for a satellite to complete one orbit around a primary body of mass M.',
    studentExplanation: 'The farther out an orbit is, the longer it takes to make one complete circle around the planet.',
    engineeringExplanation: 'Newtonian derivation of Kepler’s 3rd law establishing geostationary orbital altitudes (T = 86,164 s).',
    usage: 'Geostationary satellite altitude sizing, planetary ephemerides, and satellite pass repeat intervals.',
    example: 'LEO orbit at r = 6771 km (400 km ISS altitude) ➔ Period T ≈ 5554 s (~92.6 minutes).',
    difficulty: 'Advanced',
    tags: ['kepler', 'orbital period', 'satellite', 'celestial mechanics'],
    popularity: 93
  },
  {
    id: 'aerodynamic-lift-force',
    title: 'Aerodynamic Lift Equation',
    category: 'Aerospace',
    subcategory: 'Aerodynamics',
    formula: 'L = ½ × Cl × ρ × v² × S',
    expression: '0.5 * Cl * rho * (v ^ 2) * S',
    solveFor: {
      L: '0.5 * Cl * rho * (v ^ 2) * S',
      v: 'sqrt((2 * L) / (Cl * rho * S))',
      Cl: '(2 * L) / (rho * (v ^ 2) * S)',
      S: '(2 * L) / (Cl * rho * (v ^ 2))'
    },
    variables: [
      { symbol: 'L', name: 'Aerodynamic Lift Force (L)', unit: 'N', defaultValue: 21600, min: 0 },
      { symbol: 'Cl', name: 'Lift Coefficient (Cl)', unit: '', defaultValue: 0.5 },
      { symbol: 'rho', name: 'Air Density (ρ)', unit: 'kg/m³', defaultValue: 1.2, min: 0.001 },
      { symbol: 'v', name: 'True Airspeed (v)', unit: 'm/s', defaultValue: 60 },
      { symbol: 'S', name: 'Wing Planform Area (S)', unit: 'm²', defaultValue: 20, min: 0.1 }
    ],
    description: 'Vertical aerodynamic lifting force generated by wings moving through air of density ρ at speed v.',
    studentExplanation: 'How much upward lifting force airplane wings generate as air rushes over their airfoil shape.',
    engineeringExplanation: 'Primary equilibrium lift force balancing aircraft gross takeoff weight in steady level cruise (L = W).',
    usage: 'Aircraft stall speed determination, wing area sizing, and glider glide angle optimization.',
    example: 'Cl = 0.5, ρ = 1.2 kg/m³, v = 60 m/s, S = 20 m² ➔ Lift L = 0.5 × 0.5 × 1.2 × 3600 × 20 = 21,600 N.',
    difficulty: 'Intermediate',
    tags: ['lift', 'aerodynamics', 'wing', 'aircraft', 'flight'],
    popularity: 95
  },
  {
    id: 'aerodynamic-drag-force',
    title: 'Aerodynamic Drag Equation',
    category: 'Aerospace',
    subcategory: 'Aerodynamics',
    formula: 'D = ½ × Cd × ρ × v² × A',
    expression: '0.5 * Cd * rho * (v ^ 2) * A',
    solveFor: {
      D: '0.5 * Cd * rho * (v ^ 2) * A',
      v: 'sqrt((2 * D) / (Cd * rho * A))',
      Cd: '(2 * D) / (rho * (v ^ 2) * A)',
      A: '(2 * D) / (Cd * rho * (v ^ 2))'
    },
    variables: [
      { symbol: 'D', name: 'Aerodynamic Drag Force (D)', unit: 'N', defaultValue: 356.4, min: 0 },
      { symbol: 'Cd', name: 'Drag Coefficient (Cd)', unit: '', defaultValue: 0.3 },
      { symbol: 'rho', name: 'Fluid Density (ρ)', unit: 'kg/m³', defaultValue: 1.2, min: 0.001 },
      { symbol: 'v', name: 'Speed (v)', unit: 'm/s', defaultValue: 30 },
      { symbol: 'A', name: 'Frontal Area (A)', unit: 'm²', defaultValue: 2.2, min: 0.01 }
    ],
    description: 'Opposing aerodynamic drag force experienced by an object translating through a fluid.',
    studentExplanation: 'Air resistance pushing back against any moving car, airplane, or skydiver.',
    engineeringExplanation: 'Governs vehicle cruise thrust required, terminal velocity in freefall, and fuel consumption.',
    usage: 'Automotive drag reduction, parachute terminal velocity, and rocket atmospheric ascent drag.',
    example: 'Cd = 0.3, ρ = 1.2 kg/m³, v = 30 m/s (~108 km/h), A = 2.2 m² ➔ Drag D = 0.5 × 0.3 × 1.2 × 900 × 2.2 ≈ 356.4 N.',
    difficulty: 'Intermediate',
    tags: ['drag', 'aerodynamics', 'air resistance', 'terminal velocity'],
    popularity: 94
  },
  {
    id: 'rocket-thrust-equation',
    title: 'Rocket Engine Gross Thrust',
    category: 'Aerospace',
    subcategory: 'Rocket Propulsion',
    formula: 'F = (ṁ × ve) + (Pe - Pa) × Ae',
    expression: '(mdot * ve) + ((Pe - Pa) * Ae)',
    solveFor: {
      F: '(mdot * ve) + ((Pe - Pa) * Ae)',
      mdot: '(F - ((Pe - Pa) * Ae)) / ve'
    },
    variables: [
      { symbol: 'F', name: 'Rocket Thrust Force', unit: 'N', defaultValue: 750000, min: 0 },
      { symbol: 'mdot', name: 'Mass Flow Rate (ṁ)', unit: 'kg/s', defaultValue: 250, min: 0.1 },
      { symbol: 've', name: 'Effective Exhaust Velocity (ve)', unit: 'm/s', defaultValue: 3000 },
      { symbol: 'Pe', name: 'Nozzle Exit Pressure', unit: 'Pa', defaultValue: 101325 },
      { symbol: 'Pa', name: 'Ambient Atmospheric Pressure', unit: 'Pa', defaultValue: 101325 },
      { symbol: 'Ae', name: 'Nozzle Exit Area', unit: 'm²', defaultValue: 0.8, min: 0.001 }
    ],
    description: 'Gross propulsive thrust produced by a chemical rocket nozzle combining momentum flux and pressure differential.',
    studentExplanation: 'How much forward push a rocket engine produces by blasting exhaust gases out of its nozzle.',
    engineeringExplanation: 'Sum of momentum thrust (ṁ·ve) and pressure thrust ((Pe - Pa)·Ae) optimized at matched expansion Pe = Pa.',
    usage: 'Rocket nozzle expansion ratio optimization, launch vehicle liftoff thrust-to-weight ratio, and stage sizing.',
    example: 'ṁ = 250 kg/s, ve = 3000 m/s with matched expansion (Pe = Pa) ➔ Thrust F = 250 × 3000 = 750,000 N (750 kN).',
    difficulty: 'Advanced',
    tags: ['rocket thrust', 'propulsion', 'nozzle', 'aerospace'],
    popularity: 93
  },
  {
    id: 'planetary-atmospheric-pressure-height',
    title: 'Barometric Scale Height Pressure',
    category: 'Aerospace',
    subcategory: 'Aerodynamics',
    formula: 'P = P₀ × e^(-h / H)',
    expression: 'P0 * (e ^ (-h / H))',
    solveFor: {
      P: 'P0 * (e ^ (-h / H))',
      h: '-H * ln(P / P0)'
    },
    variables: [
      { symbol: 'P', name: 'Pressure at Altitude (P)', unit: 'Pa', defaultValue: 54048, min: 0 },
      { symbol: 'P0', name: 'Sea Level Pressure (P₀)', unit: 'Pa', defaultValue: 101325, min: 0 },
      { symbol: 'h', name: 'Geometric Altitude (h)', unit: 'm', defaultValue: 5000, min: 0 },
      { symbol: 'H', name: 'Scale Height (H ~ 8000m for Earth)', unit: 'm', defaultValue: 8000, min: 100 }
    ],
    description: 'Exponential drop in atmospheric pressure with increasing altitude above sea level.',
    studentExplanation: 'Air gets thinner exponentially the higher up you climb into the sky or mountains.',
    engineeringExplanation: 'Isothermal barometric formula for aerospace ascent trajectory density estimation and altimeter calibration.',
    usage: 'Altimeter pressure reference settings, space capsule reentry heating entry density, and balloon burst altitudes.',
    example: 'Altitude h = 5000 m on Earth (H = 8000 m) ➔ P = 101,325 × e^(-5000 / 8000) ≈ 54,048 Pa (~0.53 atm).',
    difficulty: 'Intermediate',
    tags: ['atmosphere', 'barometric', 'altitude', 'pressure', 'spaceflight'],
    popularity: 90
  }
];
