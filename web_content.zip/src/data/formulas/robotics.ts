import { Formula } from '../../types';

export const ROBOTICS_FORMULAS: Formula[] = [
  {
    id: 'diff-drive-velocity',
    title: 'Differential Drive Robot Speed',
    category: 'Robotics',
    subcategory: 'Kinematics',
    formula: 'v = (r / 2) × (ω_R + ω_L)',
    expression: '(r / 2) * (omegaR + omegaL)',
    solveFor: {
      v: '(r / 2) * (omegaR + omegaL)',
      omegaR: '((2 * v) / r) - omegaL',
      omegaL: '((2 * v) / r) - omegaR'
    },
    variables: [
      { symbol: 'v', name: 'Forward Robot Speed', unit: 'm/s', defaultValue: 1.0 },
      { symbol: 'r', name: 'Wheel Radius (r)', unit: 'm', defaultValue: 0.1, min: 0.001 },
      { symbol: 'omegaR', name: 'Right Wheel Speed (ω_R)', unit: 'rad/s', defaultValue: 10.0 },
      { symbol: 'omegaL', name: 'Left Wheel Speed (ω_L)', unit: 'rad/s', defaultValue: 10.0 }
    ],
    description: 'Forward linear velocity of a two-wheeled differential drive mobile robot from left and right wheel angular speeds.',
    studentExplanation: 'A two-wheeled robot’s forward speed is the average speed of both wheels multiplied by wheel radius.',
    engineeringExplanation: 'Forward kinematic equation relating wheel actuator velocity commands to mobile base linear trajectory.',
    usage: 'Autonomous mobile robot (AMR) trajectory planning, warehouse AGV odometry, and ROS navigation stack velocity control.',
    example: 'Radius r = 0.1 m, ωR = 10 rad/s, ωL = 10 rad/s ➔ Forward speed v = (0.1 / 2) × 20 = 1.0 m/s.',
    difficulty: 'Intermediate',
    tags: ['robotics', 'differential drive', 'kinematics', 'odometry', 'agv'],
    popularity: 96,
    featured: true
  },
  {
    id: 'diff-drive-yaw-rate',
    title: 'Differential Drive Angular Yaw Rate',
    category: 'Robotics',
    subcategory: 'Kinematics',
    formula: 'ω = (r / L) × (ω_R - ω_L)',
    expression: '(r / L) * (omegaR - omegaL)',
    solveFor: {
      omega: '(r / L) * (omegaR - omegaL)',
      omegaR: '((omega * L) / r) + omegaL',
      omegaL: 'omegaR - ((omega * L) / r)'
    },
    variables: [
      { symbol: 'omega', name: 'Chassis Yaw Rate (ω)', unit: 'rad/s', defaultValue: 0.8 },
      { symbol: 'r', name: 'Wheel Radius (r)', unit: 'm', defaultValue: 0.1, min: 0.001 },
      { symbol: 'L', name: 'Wheelbase Track (L)', unit: 'm', defaultValue: 0.5, min: 0.01 },
      { symbol: 'omegaR', name: 'Right Wheel Speed', unit: 'rad/s', defaultValue: 12.0 },
      { symbol: 'omegaL', name: 'Left Wheel Speed', unit: 'rad/s', defaultValue: 8.0 }
    ],
    description: 'Rotational turn rate (yaw velocity) of a differential drive robot about its vertical axis.',
    studentExplanation: 'If one wheel spins faster than the other, the robot turns. The difference in speeds sets how fast it rotates.',
    engineeringExplanation: 'Heading angle derivative in planar SE(2) mobile robot state estimation.',
    usage: 'In-place zero-radius turning control, waypoint yaw alignment, and dead-reckoning compass fusion.',
    example: 'r = 0.1 m, Track L = 0.5 m, ωR = 12 rad/s, ωL = 8 rad/s ➔ Turn rate ω = (0.1/0.5) × (12 - 8) = 0.8 rad/s (~45.8°/s).',
    difficulty: 'Intermediate',
    tags: ['robotics', 'yaw rate', 'rotation', 'kinematics'],
    popularity: 93
  },
  {
    id: 'wheel-rpm-from-speed',
    title: 'Wheel RPM from Target Speed',
    category: 'Robotics',
    subcategory: 'Kinematics',
    formula: 'RPM = (v × 60) / (2 × π × r)',
    expression: '(v * 60) / (2 * pi * r)',
    solveFor: {
      RPM: '(v * 60) / (2 * pi * r)',
      v: '(RPM * 2 * pi * r) / 60',
      r: '(v * 60) / (2 * pi * RPM)'
    },
    variables: [
      { symbol: 'RPM', name: 'Wheel Rotational Speed', unit: 'rpm', defaultValue: 190.99, min: 0 },
      { symbol: 'v', name: 'Target Linear Speed (v)', unit: 'm/s', defaultValue: 2.0 },
      { symbol: 'r', name: 'Wheel Radius (r)', unit: 'm', defaultValue: 0.1, min: 0.001 }
    ],
    description: 'Converts desired robot ground speed into electric motor output shaft rotations per minute.',
    studentExplanation: 'Tells you how many times per minute the wheels must spin to hit a target driving speed.',
    engineeringExplanation: 'Actuator setpoint computation translating high-level path velocity into low-level motor encoder target commands.',
    usage: 'BLDC motor driver speed setpoints, PID wheel governor tuning, and planetary gearbox selection.',
    example: 'Target speed v = 2 m/s with 0.1 m wheel radius ➔ RPM = (2 × 60) / (2 × π × 0.1) ≈ 191 RPM.',
    difficulty: 'Beginner',
    tags: ['rpm', 'wheel speed', 'motor setpoint', 'robotics'],
    popularity: 94
  },
  {
    id: 'motor-torque-sizing-robot',
    title: 'Mobile Robot Motor Sizing Torque',
    category: 'Robotics',
    subcategory: 'Motor Sizing & Torque',
    formula: 'τ = (m × a × r) / η',
    expression: '(m * a * r) / (eta / 100)',
    solveFor: {
      tau: '(m * a * r) / (eta / 100)',
      a: '(tau * (eta / 100)) / (m * r)',
      m: '(tau * (eta / 100)) / (a * r)'
    },
    variables: [
      { symbol: 'tau', name: 'Required Output Torque (τ)', unit: 'N·m', defaultValue: 5.88, min: 0 },
      { symbol: 'm', name: 'Total Robot Weight (m)', unit: 'kg', defaultValue: 50, min: 0.1 },
      { symbol: 'a', name: 'Target Acceleration (a)', unit: 'm/s²', defaultValue: 1.0 },
      { symbol: 'r', name: 'Wheel Radius (r)', unit: 'm', defaultValue: 0.1, min: 0.001 },
      { symbol: 'eta', name: 'Gearbox Efficiency (η)', unit: '%', defaultValue: 85, min: 1, max: 100 }
    ],
    description: 'Gearbox output torque required to accelerate a mobile robot platform factoring mechanical transmission losses.',
    studentExplanation: 'How much twisting power your robot’s motors need to accelerate without stalling.',
    engineeringExplanation: 'Drive motor stall and continuous torque sizing factoring inertial mass acceleration, friction, and gearbox mechanical efficiency.',
    usage: 'Specifying servomotors and planetary gearboxes for industrial AGVs and delivery robots.',
    example: '50 kg robot accelerating at 1 m/s² on 0.1 m wheels with 85% gearbox efficiency ➔ τ = (50 × 1 × 0.1) / 0.85 = 5.88 N·m.',
    difficulty: 'Intermediate',
    tags: ['motor sizing', 'torque', 'gearbox', 'robotics'],
    popularity: 95
  },
  {
    id: 'robotic-arm-single-link-torque',
    title: 'Single Link Robotic Arm Joint Holding Torque',
    category: 'Robotics',
    subcategory: 'Manipulators',
    formula: 'τ = (m_payload × L + ½ × m_link × L) × g',
    expression: '((mpayload * L) + (0.5 * mlink * L)) * g',
    solveFor: {
      tau: '((mpayload * L) + (0.5 * mlink * L)) * g',
      mpayload: '(tau / (g * L)) - (0.5 * mlink)'
    },
    variables: [
      { symbol: 'tau', name: 'Holding Joint Torque (τ)', unit: 'N·m', defaultValue: 34.34, min: 0 },
      { symbol: 'mpayload', name: 'Payload Mass (m_payload)', unit: 'kg', defaultValue: 3.0, min: 0 },
      { symbol: 'mlink', name: 'Link Arm Mass (m_link)', unit: 'kg', defaultValue: 1.0, min: 0 },
      { symbol: 'L', name: 'Arm Length (L)', unit: 'm', defaultValue: 1.0, min: 0.01 },
      { symbol: 'g', name: 'Gravity Constant', unit: 'm/s²', defaultValue: 9.81, min: 0.1 }
    ],
    description: 'Worst-case static holding torque required at a manipulator shoulder or elbow joint when held horizontally.',
    studentExplanation: 'Holding an outstretched robotic arm horizontal against gravity requires maximum motor torque.',
    engineeringExplanation: 'Static gravitational joint load torque vector G(q) in Euler-Lagrange manipulator dynamics.',
    usage: 'Industrial SCARA and 6-DOF robotic arm joint actuator selection and brake holding sizing.',
    example: 'L = 1 m arm weighing 1 kg holding a 3 kg tool horizontally ➔ τ = (3 × 1 + 0.5 × 1 × 1) × 9.81 = 3.5 × 9.81 ≈ 34.3 N·m.',
    difficulty: 'Advanced',
    tags: ['manipulator', 'robotic arm', 'torque', 'statics'],
    popularity: 92
  },
  {
    id: 'pid-controller-parallel',
    title: 'PID Controller Control Output',
    category: 'Robotics',
    subcategory: 'Control Systems',
    formula: 'u = (Kp × e) + (Ki × e_int) + (Kd × e_der)',
    expression: '(Kp * e) + (Ki * eint) + (Kd * eder)',
    solveFor: {
      u: '(Kp * e) + (Ki * eint) + (Kd * eder)'
    },
    variables: [
      { symbol: 'u', name: 'Control Signal (u)', unit: '%', defaultValue: 14.8 },
      { symbol: 'Kp', name: 'Proportional Gain (Kp)', unit: '', defaultValue: 2.0 },
      { symbol: 'Ki', name: 'Integral Gain (Ki)', unit: '', defaultValue: 0.5 },
      { symbol: 'Kd', name: 'Derivative Gain (Kd)', unit: '', defaultValue: 0.1 },
      { symbol: 'e', name: 'Current Error (e)', unit: '', defaultValue: 5.0 },
      { symbol: 'eint', name: 'Integrated Error (∫e dt)', unit: '', defaultValue: 10.0 },
      { symbol: 'eder', name: 'Derivative Error (de/dt)', unit: '', defaultValue: -2.0 }
    ],
    description: 'Instantaneous control variable command synthesized by a parallel proportional-integral-derivative feedback controller.',
    studentExplanation: 'The industry-standard algorithm that steers robots smoothly toward their target without overshooting.',
    engineeringExplanation: 'Closed-loop feedback regulation compensating present error (P), steady-state offset (I), and future rate (D).',
    usage: 'Drone altitude hold, robotic joint position servos, and automated cruise control.',
    example: 'Kp=2, Ki=0.5, Kd=0.1, e=5, eint=10, eder=-2 ➔ u = (2×5) + (0.5×10) + (0.1×-2) = 10 + 5 - 0.2 = 14.8%.',
    difficulty: 'Advanced',
    tags: ['pid', 'control systems', 'feedback', 'automation'],
    popularity: 94
  },
  {
    id: 'dc-motor-back-emf',
    title: 'DC Motor Back-EMF Voltage',
    category: 'Robotics',
    subcategory: 'Actuators',
    formula: 'V_emf = Ke × ω',
    expression: 'Ke * omega',
    solveFor: {
      Vemf: 'Ke * omega',
      omega: 'Vemf / Ke',
      Ke: 'Vemf / omega'
    },
    variables: [
      { symbol: 'Vemf', name: 'Back-EMF Voltage (V_emf)', unit: 'V', defaultValue: 10.0, min: 0 },
      { symbol: 'Ke', name: 'Back-EMF Constant (Ke)', unit: 'V/(rad/s)', defaultValue: 0.05, min: 0.0001 },
      { symbol: 'omega', name: 'Rotor Angular Speed (ω)', unit: 'rad/s', defaultValue: 200, min: 0 }
    ],
    description: 'Electromotive force generated internally by a rotating motor armature opposing supply voltage according to Lenz’s Law.',
    studentExplanation: 'As an electric motor spins faster, it acts like a generator producing an opposing voltage that naturally limits its top speed.',
    engineeringExplanation: 'Back-EMF limits armature current according to I = (V_applied - V_emf) / R; used in sensorless BLDC speed estimation.',
    usage: 'Sensorless BLDC motor commutation, regenerative braking voltage recovery, and motor top speed sizing.',
    example: 'Ke = 0.05 V/(rad/s) spinning at 200 rad/s ➔ V_emf = 0.05 × 200 = 10.0 V.',
    difficulty: 'Intermediate',
    tags: ['dc motor', 'back-emf', 'actuator', 'bldc'],
    popularity: 91
  }
];
