import { Formula } from '../../types';
import { MATHEMATICS_FORMULAS } from './mathematics';
import { PHYSICS_FORMULAS } from './physics';
import { CHEMISTRY_FORMULAS } from './chemistry';
import { ENGINEERING_FORMULAS } from './engineering';
import { ROBOTICS_FORMULAS } from './robotics';
import { AEROSPACE_FORMULAS } from './aerospace';

export const ALL_FORMULAS: Formula[] = [
  ...MATHEMATICS_FORMULAS,
  ...PHYSICS_FORMULAS,
  ...CHEMISTRY_FORMULAS,
  ...ENGINEERING_FORMULAS,
  ...ROBOTICS_FORMULAS,
  ...AEROSPACE_FORMULAS
];

export function getFormulaById(id: string): Formula | undefined {
  return ALL_FORMULAS.find((f) => f.id === id);
}

export function searchFormulas(query: string): Formula[] {
  if (!query || !query.trim()) return ALL_FORMULAS;
  const q = query.toLowerCase().trim();

  return ALL_FORMULAS.filter((f) => {
    return (
      f.title.toLowerCase().includes(q) ||
      f.formula.toLowerCase().includes(q) ||
      f.category.toLowerCase().includes(q) ||
      f.subcategory.toLowerCase().includes(q) ||
      f.description.toLowerCase().includes(q) ||
      f.tags.some((tag) => tag.toLowerCase().includes(q)) ||
      f.variables.some(
        (v) =>
          v.name.toLowerCase().includes(q) ||
          v.symbol.toLowerCase().includes(q) ||
          v.unit.toLowerCase().includes(q)
      )
    );
  });
}
