import { Hospital } from '../types';

/**
 * Calculates straight-line distance in kilometers between two coordinates using Haversine formula
 */
export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100; // precision to 2 decimals
}

export function cleanPhoneNumber(rawPhone: string): string {
  if (!rawPhone) return '';
  // Split multiple numbers separated by ;, comma, slash, pipe or 'or' or 'to'
  const first = rawPhone.split(/;|,|\/|\||\bor\b|\bto\b/i)[0].trim();
  const withoutLabel = first.replace(/^(phone|telephone|tel|ph|call|reception|opd|emergency|toll\s*free)\s*[:.-]?\s*/i, '').trim();
  return withoutLabel.replace(/\s+/g, ' ').trim();
}

export function getDialablePhoneNumber(phone: string): string {
  if (!phone) return '';
  // Keep digits and leading +, strip formatting characters for tel: URL
  return phone.replace(/[^0-9+]/g, '');
}

function extractPhoneFromTags(tags: Record<string, string>): string {
  if (!tags) return '';
  const possibleKeys = [
    'phone',
    'contact:phone',
    'emergency:phone',
    'telephone',
    'contact:telephone',
    'phone:mobile',
    'contact:mobile',
    'mobile',
    'healthcare:phone',
    'operator:phone',
    'phone:en',
    'contact:phone:en',
    'phone:emergency',
    'contact:emergency',
    'tel',
    'contact:tel',
    'phone:reception',
    'phone:helpdesk',
    'phone:opd',
    'phone:appointment',
    'contact:appointment',
    'phone:tollfree',
    'tollfree',
    'contact:tollfree',
  ];
  for (const key of possibleKeys) {
    if (tags[key] && tags[key].trim().length >= 3) {
      const cleaned = cleanPhoneNumber(tags[key]);
      const digits = cleaned.replace(/\D/g, '');
      if (digits.length >= 6 && !['100', '101', '102', '108', '112', '911', '104'].includes(digits)) {
        return cleaned;
      }
    }
  }
  for (const [k, v] of Object.entries(tags)) {
    if (typeof v === 'string' && /phone|telephone|mobile|tel/i.test(k)) {
      const cleaned = cleanPhoneNumber(v);
      const digits = cleaned.replace(/\D/g, '');
      if (digits.length >= 6 && !['100', '101', '102', '108', '112', '911', '104'].includes(digits)) {
        return cleaned;
      }
    }
  }
  return '';
}

/**
 * Searches real-time nearby hospitals around the user's GPS coordinates within a strict 10 km radius
 */
export async function fetchRealNearbyHospitals(lat: number, lng: number): Promise<Hospital[]> {
  const maxRadiusMeters = 10000; // strictly 10 km
  const overpassUrl = `https://overpass-api.de/api/interpreter?data=[out:json][timeout:12];(node["amenity"="hospital"](around:${maxRadiusMeters},${lat},${lng});way["amenity"="hospital"](around:${maxRadiusMeters},${lat},${lng});relation["amenity"="hospital"](around:${maxRadiusMeters},${lat},${lng});node["healthcare"="hospital"](around:${maxRadiusMeters},${lat},${lng});way["healthcare"="hospital"](around:${maxRadiusMeters},${lat},${lng});relation["healthcare"="hospital"](around:${maxRadiusMeters},${lat},${lng});node["amenity"="clinic"](around:${maxRadiusMeters},${lat},${lng});way["amenity"="clinic"](around:${maxRadiusMeters},${lat},${lng});relation["amenity"="clinic"](around:${maxRadiusMeters},${lat},${lng});node["amenity"="doctors"](around:${maxRadiusMeters},${lat},${lng});way["amenity"="doctors"](around:${maxRadiusMeters},${lat},${lng});node["healthcare"="clinic"](around:${maxRadiusMeters},${lat},${lng});way["healthcare"="clinic"](around:${maxRadiusMeters},${lat},${lng}););out body center;`;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 9000);

    const res = await fetch(overpassUrl, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data && Array.isArray(data.elements)) {
        const rawResults: { hospital: Hospital; tags: Record<string, string> }[] = [];

        for (const el of data.elements) {
          const hospLat = el.lat ?? el.center?.lat;
          const hospLng = el.lon ?? el.center?.lon;
          if (!hospLat || !hospLng) continue;

          const distKm = calculateHaversineDistance(lat, lng, hospLat, hospLng);
          // STRICT 10 KM RADIUS FILTER
          if (distKm > 10.0) continue;

          const tags: Record<string, string> = el.tags || {};
          const name =
            tags.name ||
            tags['name:en'] ||
            tags.operator ||
            (tags.amenity === 'clinic' ? 'Family Health Clinic' : 'Medical Center & Hospital');

          const addrParts = [
            tags['addr:street'],
            tags['addr:suburb'] || tags['addr:neighbourhood'],
            tags['addr:city'],
          ].filter(Boolean);

          const address =
            addrParts.length > 0
              ? addrParts.join(', ')
              : `${name}, Local Area`;

          const rawPhone = extractPhoneFromTags(tags);
          const phone = cleanPhoneNumber(rawPhone);

          // Specialty detection
          let specialty = tags['healthcare:speciality'] || tags['speciality'] || tags['medical_specialty'];
          if (!specialty) {
            const lowerName = name.toLowerCase();
            if (lowerName.includes('eye') || lowerName.includes('ophthalm')) specialty = 'Ophthalmology & Eye Care';
            else if (lowerName.includes('heart') || lowerName.includes('cardio')) specialty = 'Cardiology & Heart Care';
            else if (lowerName.includes('child') || lowerName.includes('pediatric')) specialty = 'Pediatrics & Child Health';
            else if (lowerName.includes('ortho') || lowerName.includes('bone')) specialty = 'Orthopedics & Joint Care';
            else if (lowerName.includes('skin') || lowerName.includes('derma')) specialty = 'Dermatology';
            else if (lowerName.includes('dental') || lowerName.includes('dentist')) specialty = 'Dental & Oral Care';
            else if (lowerName.includes('maternity') || lowerName.includes('women') || lowerName.includes('gynae')) specialty = 'Obstetrics & Gynaecology';
            else if (lowerName.includes('clinic') || lowerName.includes('dispensary')) specialty = 'General Practice & Family Medicine';
            else if (tags.amenity === 'clinic') specialty = 'Outpatient Care & General Practice';
            else specialty = 'General Medicine & Multi-Specialty';
          }

          const distMeters = Math.round(distKm * 1000);
          const distanceText = distKm < 1.0 ? `${distMeters} m` : `${distKm.toFixed(1)} km`;
          const travelMins = Math.max(2, Math.round((distKm / 35) * 60));
          const estimatedTime = `~${travelMins} mins drive`;

          const placeIdentifier = `${el.type ? el.type[0].toUpperCase() : 'N'}${el.id}`;

          rawResults.push({
            hospital: {
              id: `hosp_${el.id}`,
              name,
              address,
              phone,
              specialty,
              distanceKm: distKm,
              distanceText,
              estimatedTime,
              latitude: hospLat,
              longitude: hospLng,
              osmId: el.id,
              osmType: el.type,
              placeId: placeIdentifier,
              is24x7: true,
              hasICU: true,
            },
            tags,
          });
        }

        // Deduplicate by hospital name
        const uniqueHospitals: Hospital[] = [];
        const seenNames = new Set<string>();
        for (const item of rawResults) {
          const key = item.hospital.name.toLowerCase().trim();
          if (!seenNames.has(key)) {
            seenNames.add(key);
            uniqueHospitals.push(item.hospital);
          }
        }

        // Sort by distance ascending
        uniqueHospitals.sort((a, b) => a.distanceKm - b.distanceKm);
        return uniqueHospitals;
      }
    }
  } catch (err) {
    console.warn('[HospitalData] Overpass API query error:', err);
  }

  // Fallback query to Nominatim
  try {
    const nominatimUrl = `https://nominatim.openstreetmap.org/search?format=json&extratags=1&addressdetails=1&q=hospital&lat=${lat}&lon=${lng}&bounded=1&viewbox=${lng - 0.09},${lat + 0.09},${lng + 0.09},${lat - 0.09}`;
    const res = await fetch(nominatimUrl, { headers: { 'User-Agent': 'MediguideHealthcareApp/2.0 (contact: medicalapp@mediguide.org)' } });
    if (res.ok) {
      const items = await res.json();
      if (Array.isArray(items)) {
        const results: Hospital[] = [];
        for (const item of items) {
          const hospLat = parseFloat(item.lat);
          const hospLng = parseFloat(item.lon);
          const distKm = calculateHaversineDistance(lat, lng, hospLat, hospLng);

          // STRICT 10 KM RADIUS FILTER
          if (distKm > 10.0) continue;

          const name = item.display_name.split(',')[0] || 'Community Hospital';
          const address = item.display_name.split(',').slice(1, 4).join(', ').trim() || 'Medical Center';
          const distMeters = Math.round(distKm * 1000);
          const distanceText = distKm < 1.0 ? `${distMeters} m` : `${distKm.toFixed(1)} km`;
          const travelMins = Math.max(2, Math.round((distKm / 35) * 60));

          const extra = item.extratags || {};
          const rawPhone = extractPhoneFromTags(extra);
          const phone = cleanPhoneNumber(rawPhone);

          results.push({
            id: `nom_${item.place_id}`,
            name,
            address,
            phone,
            specialty: 'General Medicine & Multi-Specialty',
            distanceKm: distKm,
            distanceText,
            estimatedTime: `~${travelMins} mins drive`,
            latitude: hospLat,
            longitude: hospLng,
            placeId: item.place_id,
            osmId: item.osm_id,
            osmType: item.osm_type,
          });
        }
        results.sort((a, b) => a.distanceKm - b.distanceKm);
        return results;
      }
    }
  } catch (err) {
    console.warn('[HospitalData] Nominatim query error:', err);
  }

  return [];
}

export interface HospitalPlaceDetailsResult {
  phone: string;
  internationalPhone?: string;
  formattedPhone?: string;
  dialable?: string;
  verified: boolean;
}

/**
 * Performs a dedicated separate Place Details lookup for the official phone number
 * using the hospital's individual place information (OSM ID, Place ID, coordinates, name).
 * Supports both international phone numbers and formatted local numbers.
 */
export async function lookupHospitalPlaceDetails(
  hospital: Hospital
): Promise<HospitalPlaceDetailsResult | null> {
  if (!hospital || !hospital.name) return null;

  // 1. Primary: Server API lookup with full place parameters and explicit field mask
  try {
    const params = new URLSearchParams({
      name: hospital.name,
      address: hospital.address || '',
      lat: String(hospital.latitude),
      lng: String(hospital.longitude),
      fields: 'internationalPhoneNumber,nationalPhoneNumber,formattedPhoneNumber,phone,contact:phone',
    });
    if (hospital.placeId) params.set('placeId', String(hospital.placeId));
    if (hospital.osmId) params.set('osmId', String(hospital.osmId));
    if (hospital.osmType) params.set('osmType', String(hospital.osmType));

    const res = await fetch(`/api/hospital-phone?${params.toString()}`);
    if (res.ok) {
      const data = await res.json();
      if (data.verified && data.phone) {
        return {
          phone: cleanPhoneNumber(data.phone),
          internationalPhone: data.internationalPhone ? cleanPhoneNumber(data.internationalPhone) : undefined,
          formattedPhone: data.formattedPhone ? cleanPhoneNumber(data.formattedPhone) : undefined,
          dialable: data.dialable || getDialablePhoneNumber(data.phone),
          verified: true,
        };
      }
    }
  } catch (e) {
    console.warn('[HospitalData] /api/hospital-phone lookup call failed, trying client fallback');
  }

  // 2. Secondary client-side Place Details fallback using Official OpenStreetMap Element API
  try {
    if (hospital.osmId && hospital.osmType) {
      const typeLower = String(hospital.osmType).toLowerCase() === 'w' ? 'way' : String(hospital.osmType).toLowerCase() === 'r' ? 'relation' : 'node';
      const osmUrl = `https://api.openstreetmap.org/api/0.6/${typeLower}/${hospital.osmId}.json`;
      const res = await fetch(osmUrl, {
        headers: { 'Accept': 'application/json' },
      });
      if (res.ok) {
        const osmData = await res.json();
        const elem = osmData?.elements?.[0];
        if (elem && elem.tags) {
          const rawP = extractPhoneFromTags(elem.tags);
          if (rawP) {
            const cleaned = cleanPhoneNumber(rawP);
            return {
              phone: cleaned,
              internationalPhone: cleaned.startsWith('+') ? cleaned : undefined,
              formattedPhone: cleaned,
              dialable: getDialablePhoneNumber(cleaned),
              verified: true,
            };
          }
        }
      }
    }
  } catch (e) {
    // Client fallback failed
  }

  return null;
}

/**
 * Backward compatibility wrapper
 */
export async function lookupHospitalPhoneByNameAndAddress(
  name: string,
  address: string,
  lat: number,
  lng: number,
  osmId?: number | string,
  osmType?: string,
  placeId?: number | string
): Promise<string> {
  const result = await lookupHospitalPlaceDetails({
    id: `temp_${osmId || name}`,
    name,
    address,
    phone: '',
    distanceKm: 0,
    latitude: lat,
    longitude: lng,
    osmId,
    osmType,
    placeId,
  });
  return result?.phone || '';
}

