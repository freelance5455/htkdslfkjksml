export interface AndroidSourceFile {
  path: string;
  titleBn: string;
  titleEn: string;
  description: string;
  code: string;
}

export const ANDROID_KOTLIN_FILES: AndroidSourceFile[] = [
  {
    path: 'app/build.gradle.kts',
    titleBn: 'Gradle কনফিগারেশন (Compose, Room, Credential Manager, Drive, WorkManager)',
    titleEn: 'Module build.gradle.kts',
    description:
      'Configures Kotlin 2.0, Jetpack Compose Material 3, Room 2.6 KSP, Credential Manager, Play Services Auth, WorkManager, and Kotlinx Serialization.',
    code: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.hisabkhata.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hisabkhata.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"

        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")

    // Room Local Database (Offline-First Persistence)
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // Google Credential Manager API for Sign in with Google
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    // Google Play Services AuthorizationClient for Drive appdata Scope
    implementation("com.google.android.gms:play-services-auth:21.2.0")

    // Android WorkManager for Scheduled Daily Encrypted Backups with Network Retry
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Safe JSON Backup & Restore
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
}`,
  },
  {
    path: 'app/src/main/java/com/hisabkhata/app/backup/BackupCryptoManager.kt',
    titleBn: 'AES-256-GCM এনক্রিপশন ও SHA-256 যাচাইকরণ (BackupCryptoManager.kt)',
    titleEn: 'BackupCryptoManager.kt (AES-256-GCM + PBKDF2)',
    description:
      'Encrypts and decrypts backup payloads using AES-256-GCM (128-bit auth tag, 12-byte IV) and PBKDF2WithHmacSHA256 (150,000 iterations) with SHA-256 checksum validation.',
    code: `package com.hisabkhata.app.backup

import android.util.Base64
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

@Serializable
data class EncryptedBackupEnvelope(
    val app: String = "HisabKhata",
    val backupFormatVersion: Int = 2,
    val encryptedAt: String,
    val algorithm: String = "AES-256-GCM",
    val kdf: String = "PBKDF2WithHmacSHA256",
    val iterations: Int = 150000,
    val saltBase64: String,
    val ivBase64: String,
    val ciphertextBase64: String,
    val plaintextSha256Hex: String
)

object BackupCryptoManager {
    private const val PBKDF2_ITERATIONS = 150_000
    private const val KEY_LENGTH_BITS = 256
    private const val GCM_TAG_LENGTH_BITS = 128
    private const val SALT_BYTES = 16
    private const val IV_BYTES = 12

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun encryptJsonPayload(plaintextJson: String, passphrase: String, timestampIso: String): String {
        require(passphrase.trim().length >= 6) { "Passphrase must be at least 6 characters" }

        val plaintextBytes = plaintextJson.toByteArray(Charsets.UTF_8)
        val sha256Hex = sha256Hex(plaintextBytes)

        val random = SecureRandom()
        val salt = ByteArray(SALT_BYTES).also { random.nextBytes(it) }
        val iv = ByteArray(IV_BYTES).also { random.nextBytes(it) }

        val secretKey = deriveAesKey(passphrase, salt, PBKDF2_ITERATIONS)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
        val ciphertext = cipher.doFinal(plaintextBytes)

        val envelope = EncryptedBackupEnvelope(
            encryptedAt = timestampIso,
            iterations = PBKDF2_ITERATIONS,
            saltBase64 = Base64.encodeToString(salt, Base64.NO_WRAP),
            ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP),
            ciphertextBase64 = Base64.encodeToString(ciphertext, Base64.NO_WRAP),
            plaintextSha256Hex = sha256Hex
        )

        return json.encodeToString(envelope)
    }

    fun decryptAndVerifyPayload(envelopeJson: String, passphrase: String): String {
        val envelope = json.decodeFromString<EncryptedBackupEnvelope>(envelopeJson)
        require(envelope.app == "HisabKhata" && envelope.algorithm == "AES-256-GCM") {
            "Invalid or unsupported backup envelope"
        }

        val salt = Base64.decode(envelope.saltBase64, Base64.NO_WRAP)
        val iv = Base64.decode(envelope.ivBase64, Base64.NO_WRAP)
        val ciphertext = Base64.decode(envelope.ciphertextBase64, Base64.NO_WRAP)

        val secretKey = deriveAesKey(passphrase, salt, envelope.iterations)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))

        val decryptedBytes = cipher.doFinal(ciphertext)
        val actualHash = sha256Hex(decryptedBytes)
        check(actualHash == envelope.plaintextSha256Hex) {
            "SHA-256 integrity check failed: backup is corrupted"
        }

        return String(decryptedBytes, Charsets.UTF_8)
    }

    private fun deriveAesKey(passphrase: String, salt: ByteArray, iterations: Int): SecretKeySpec {
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, iterations, KEY_LENGTH_BITS)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = factory.generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(keyBytes, "AES")
    }

    private fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }
}`,
  },
  {
    path: 'app/src/main/java/com/hisabkhata/app/backup/GoogleDriveBackupManager.kt',
    titleBn: 'গুগল লগইন ও ড্রাইভ appDataFolder ব্যাকআপ (GoogleDriveBackupManager.kt)',
    titleEn: 'GoogleDriveBackupManager.kt (Credential Manager & Drive v3)',
    description:
      'Uses Credential Manager for Sign in with Google and AuthorizationClient with strictly https://www.googleapis.com/auth/drive.appdata scope.',
    code: `package com.hisabkhata.app.backup

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.HttpURLConnection
import java.net.URL

class GoogleDriveBackupManager(private val context: Context) {

    companion object {
        const val DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata"
        const val BACKUP_FILE_NAME = "hisab_khata_backup_v2.enc.json"
    }

    private val credentialManager = CredentialManager.create(context)

    suspend fun signInWithGoogle(webClientId: String): String {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(webClientId)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        val result = credentialManager.getCredential(context, request)
        val credential = result.credential
        if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
            return googleIdTokenCredential.id
        }
        throw IllegalStateException("Unexpected credential type")
    }

    suspend fun requestDriveAppDataAccessToken(): String {
        val authRequest = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scope(DRIVE_APPDATA_SCOPE)))
            .build()

        val authResult = Identity.getAuthorizationClient(context)
            .authorize(authRequest)
            .await()

        check(!authResult.hasResolution()) {
            "User consent resolution required via PendingIntent"
        }

        return requireNotNull(authResult.accessToken) {
            "Failed to obtain Drive appDataFolder access token"
        }
    }

    suspend fun disconnectAccount() {
        credentialManager.clearCredentialState(ClearCredentialStateRequest())
    }

    suspend fun uploadEncryptedBackup(accessToken: String, encryptedEnvelopeJson: String): Int =
        withContext(Dispatchers.IO) {
            val boundary = "hisab_khata_boundary_\${System.currentTimeMillis()}"
            val metadataJson = """
                {
                  "name": "\$BACKUP_FILE_NAME",
                  "parents": ["appDataFolder"],
                  "mimeType": "application/json"
                }
            """.trimIndent()

            val body = buildString {
                append("--\$boundary\\r\\n")
                append("Content-Type: application/json; charset=UTF-8\\r\\n\\r\\n")
                append(metadataJson).append("\\r\\n")
                append("--\$boundary\\r\\n")
                append("Content-Type: application/json; charset=UTF-8\\r\\n\\r\\n")
                append(encryptedEnvelopeJson).append("\\r\\n")
                append("--\$boundary--")
            }

            val url = URL("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,modifiedTime")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Authorization", "Bearer \$accessToken")
                setRequestProperty("Content-Type", "multipart/related; boundary=\$boundary")
            }

            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            conn.responseCode
        }
}`,
  },
  {
    path: 'app/src/main/java/com/hisabkhata/app/backup/DriveBackupWorker.kt',
    titleBn: 'স্বয়ংক্রিয় দৈনিক ব্যাকআপ ওয়ার্কার (WorkManager)',
    titleEn: 'DriveBackupWorker.kt (WorkManager Daily Sync & Retry)',
    description:
      'Runs daily encrypted backups in the background via WorkManager and automatically retries when internet becomes available without interrupting the user.',
    code: `package com.hisabkhata.app.backup

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class DriveBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val driveManager = GoogleDriveBackupManager(applicationContext)
            val accessToken = driveManager.requestDriveAppDataAccessToken()

            val payloadJson = inputData.getString("SNAPSHOT_JSON") ?: return Result.success()
            val passphrase = inputData.getString("PASSPHRASE") ?: return Result.failure()

            val encryptedJson = BackupCryptoManager.encryptJsonPayload(
                plaintextJson = payloadJson,
                passphrase = passphrase,
                timestampIso = java.time.Instant.now().toString()
            )

            val status = driveManager.uploadEncryptedBackup(accessToken, encryptedJson)
            if (status in 200..299) {
                Result.success()
            } else if (status in 500..599 || status == 429) {
                Result.retry()
            } else {
                Result.failure()
            }
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "HisabKhataDailyDriveBackup"

        fun scheduleDailyAutoBackup(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()

            val dailyRequest = PeriodicWorkRequestBuilder<DriveBackupWorker>(24, TimeUnit.HOURS)
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                dailyRequest
            )
        }

        fun cancelDailyAutoBackup(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        }
    }
}`,
  },
  {
    path: 'app/src/main/java/com/hisabkhata/app/data/local/Entities.kt',
    titleBn: 'Room ডাটাবেজ এন্টিটিসমূহ (Accounts, Transactions, Debts, Subscriptions)',
    titleEn: 'Entities.kt (Room Database Schema)',
    description:
      'Defines @Entity tables with ForeignKey constraints so editing or deleting records keeps balances and repayment history 100% consistent.',
    code: `package com.hisabkhata.app.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

enum class AccountType { CASH, BANK, MFS }
enum class TransactionType { SALE, INCOME, EXPENSE, PURCHASE, TRANSFER }
enum class DebtDirection { LENT, RECEIVABLE_OTHER, BORROWED, PAYABLE_OTHER }
enum class BillingCycle { MONTHLY, YEARLY, CUSTOM_DAYS }

@Serializable
@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val nameBn: String,
    val nameEn: String,
    val type: AccountType,
    val openingBalancePaisa: Long,
    val accountNumber: String? = null,
    val institution: String? = null,
    val createdAt: String,
    val isDemo: Boolean = false
)

@Serializable
@Entity(
    tableName = "transactions",
    indices = [Index("accountId"), Index("toAccountId"), Index("date"), Index("type")]
)
data class TransactionEntity(
    @PrimaryKey val id: String,
    val type: TransactionType,
    val amountPaisa: Long,
    val date: String,
    val category: String,
    val accountId: String,
    val toAccountId: String? = null,
    val note: String,
    val createdAt: String,
    val isDemo: Boolean = false
)

@Serializable
@Entity(tableName = "debts", indices = [Index("direction"), Index("dueDate")])
data class DebtEntity(
    @PrimaryKey val id: String,
    val direction: DebtDirection,
    val contactName: String,
    val phone: String? = null,
    val principalPaisa: Long,
    val date: String,
    val dueDate: String? = null,
    val accountId: String? = null,
    val notes: String,
    val createdAt: String,
    val isDemo: Boolean = false
)

@Serializable
@Entity(
    tableName = "debt_repayments",
    foreignKeys = [
        ForeignKey(
            entity = DebtEntity::class,
            parentColumns = ["id"],
            childColumns = ["debtId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("debtId")]
)
data class RepaymentEntity(
    @PrimaryKey val id: String,
    val debtId: String,
    val amountPaisa: Long,
    val date: String,
    val accountId: String? = null,
    val note: String,
    val createdAt: String
)`,
  },
  {
    path: 'docs/GOOGLE_CLOUD_CONSOLE_SETUP.md',
    titleBn: 'Google Cloud Console কনফিগারেশন নির্দেশিকা',
    titleEn: 'Google Cloud Console Setup Instructions',
    description:
      'Step-by-step instructions for configuring Google Cloud Console, OAuth Consent Screen, SHA-1 fingerprint, and Drive API v3 for Android.',
    code: `# Google Cloud Console কনফিগারেশন নির্দেশিকা (Android & Drive API v3)

১. Google Cloud প্রজেক্ট ও Google Drive API সক্রিয়করণ:
   - https://console.cloud.google.com এ প্রবেশ করে নতুন প্রজেক্ট তৈরি করুন বা বিদ্যমান প্রজেক্ট নির্বাচন করুন।
   - "APIs & Services" -> "Library" থেকে "Google Drive API" সার্চ করে "Enable" করুন।

২. OAuth Consent Screen কনফিগারেশন (ন্যূনতম স্কোপ):
   - "APIs & Services" -> "OAuth consent screen" এ যান।
   - User Type হিসেবে "External" নির্বাচন করুন।
   - App Name ("হিসাব খাতা"), User Support Email এবং Developer Contact ইমেইল দিন।
   - "Scopes" ধাপে "Add or Remove Scopes" ক্লিক করে শুধুমাত্র নিচের স্কোপটি যুক্ত করুন:
     https://www.googleapis.com/auth/drive.appdata
   - কখনোই পূর্ণ Google Drive স্কোপ (/auth/drive) যুক্ত করবেন না।
   - অ্যাপটি Testing মোডে থাকাকালীন "Test users" তালিকায় আপনার নিজের জিমেইল অ্যাড্রেস যোগ করুন।

৩. Android ও Web OAuth 2.0 Client ID তৈরি:
   - আপনার প্রজেক্টের SHA-1 ফিঙ্গারপ্রিন্ট বের করুন:
     ./gradlew signingReport
   - "APIs & Services" -> "Credentials" -> "Create Credentials" -> "OAuth client ID":
     (ক) Application type: "Android"
         - Package name: com.hisabkhata.app
         - SHA-1 certificate fingerprint: আপনার ডিবাগ/রিলিজ কী-স্টোরের SHA-1 দিন।
     (খ) Application type: "Web application"
         - নাম দিন: "HisabKhata Credential Manager Web Client"
         - তৈরি হওয়া এই Web Client ID-টি Credential Manager এর setServerClientId(webClientId) এ ব্যবহার করুন।
         - কোনো Client Secret অ্যাপের ভেতরে সংরক্ষণ করবেন না।`,
  },
];
