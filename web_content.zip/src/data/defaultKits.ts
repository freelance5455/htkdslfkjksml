import type { KitPreset, PadConfig, PadLayoutRect, PadZoneConfig, ZoneSplitMode } from '../types/octapad';
import { BUILT_IN_SOUNDS } from '../audio/synthEngine';

const DEFAULT_KEY_HINTS = ['1', '2', '3', '4', 'Q', 'W', 'E', 'R'];

const DEFAULT_FREEFORM_RECTS: PadLayoutRect[] = [
  { x: 2, y: 3, w: 22.5, h: 45 },
  { x: 26.5, y: 3, w: 22.5, h: 45 },
  { x: 51, y: 3, w: 22.5, h: 45 },
  { x: 75.5, y: 3, w: 22.5, h: 45 },
  { x: 2, y: 52, w: 22.5, h: 45 },
  { x: 26.5, y: 52, w: 22.5, h: 45 },
  { x: 51, y: 52, w: 22.5, h: 45 },
  { x: 75.5, y: 52, w: 22.5, h: 45 },
];

export function makeZone(
  id: 'primary' | 'secondary',
  soundId: string,
  overrides: Partial<PadZoneConfig> = {}
): PadZoneConfig {
  const meta = BUILT_IN_SOUNDS.find((s) => s.id === soundId);
  return {
    id,
    label: overrides.label ?? meta?.name ?? soundId,
    soundId,
    soundName: overrides.soundName ?? meta?.name ?? soundId,
    isCustom: false,
    volume: 0.95,
    pitch: 0,
    pan: 0,
    playbackMode: 'one-shot',
    chokeGroup: 0,
    startOffset: 0,
    endOffset: 1,
    accentColor: overrides.accentColor ?? meta?.color ?? '#10d2f2',
    muted: false,
    ...overrides,
  };
}

function makePad(
  index: number,
  primarySoundId: string,
  secondarySoundId = 'ac-rim',
  splitMode: ZoneSplitMode = 'single',
  options: {
    primaryLabel?: string;
    secondaryLabel?: string;
    chokeA?: number;
    chokeB?: number;
    pitchA?: number;
    pitchB?: number;
    splitRatio?: number;
    rimThickness?: number;
  } = {}
): PadConfig {
  return {
    index,
    keyHint: DEFAULT_KEY_HINTS[index],
    splitMode,
    splitRatio: options.splitRatio ?? 0.5,
    rimThickness: options.rimThickness ?? 0.28,
    hitboxInset: 0,
    velocityMode: 'fixed',
    layoutRect: { ...DEFAULT_FREEFORM_RECTS[index] },
    zones: [
      makeZone('primary', primarySoundId, {
        label: options.primaryLabel,
        chokeGroup: options.chokeA ?? 0,
        pitch: options.pitchA ?? 0,
      }),
      makeZone('secondary', secondarySoundId, {
        label: options.secondaryLabel,
        chokeGroup: options.chokeB ?? 0,
        pitch: options.pitchB ?? 0,
      }),
    ],
  };
}

export const DEFAULT_KITS: KitPreset[] = [
  {
    id: 'kit-timli-1',
    name: 'TIMLI 1',
    category: 'Folk & Live Percussion',
    isBuiltIn: true,
    layoutType: 'grid',
    gridArrangement: 'auto',
    padGap: 6,
    padRadius: 12,
    showLabels: false,
    showKeyHints: false,
    masterVolume: 0.92,
    updatedAt: 0,
    bankA: [
      makePad(0, 'manjira', 'ghunghroo', 'split-h', {
        primaryLabel: 'Manjira',
        secondaryLabel: 'Ghunghroo',
      }),
      makePad(1, 'duff-slap', 'dholak-ta', 'single', { primaryLabel: 'Duff Slap' }),
      makePad(2, 'timli-tom', 'tabla-ke', 'single', { primaryLabel: 'Timli Tom' }),
      makePad(3, 'folk-clap', 'brass-stab', 'single', { primaryLabel: 'Folk Clap' }),
      makePad(4, 'timli-kick', 'dhol-bass', 'single', { primaryLabel: 'Timli Kick' }),
      makePad(5, 'dholak-ge', 'dholak-na', 'center-rim', {
        primaryLabel: 'Dholak Ge',
        secondaryLabel: 'Dholak Na',
        rimThickness: 0.3,
      }),
      makePad(6, 'dholak-na', 'dholak-ta', 'single', { primaryLabel: 'Dholak Na' }),
      makePad(7, 'ghunghroo', 'manjira', 'single', { primaryLabel: 'Ghunghroo' }),
    ],
    bankB: [
      makePad(0, 'ac-crash', 'ac-ride', 'single', { primaryLabel: 'Crash' }),
      makePad(1, 'brass-stab', 'folk-clap', 'single', { primaryLabel: 'Brass Hit' }),
      makePad(2, 'dhol-bass', 'timli-kick', 'single', { primaryLabel: 'Dhol Boom' }),
      makePad(3, 'tabla-ke', 'dholak-ta', 'single', { primaryLabel: 'Tabla Ke', chokeA: 2 }),
      makePad(4, 'el-kick', 'timli-kick', 'single', { primaryLabel: 'Club Kick' }),
      makePad(5, '808-snare', 'ac-rim', 'center-rim', {
        primaryLabel: 'Snare',
        secondaryLabel: 'Rimshot',
      }),
      makePad(6, '808-hh', '808-oh', 'split-v', {
        primaryLabel: 'Closed HH',
        secondaryLabel: 'Open HH',
        chokeA: 1,
        chokeB: 1,
      }),
      makePad(7, 'el-shaker', 'manjira', 'single', { primaryLabel: 'Shaker' }),
    ],
  },
  {
    id: 'kit-timli-2',
    name: 'TIMLI 2 LIVE',
    category: 'Garba & Dholak Stage',
    isBuiltIn: true,
    layoutType: 'grid',
    gridArrangement: 'auto',
    padGap: 6,
    padRadius: 12,
    showLabels: true,
    showKeyHints: false,
    masterVolume: 0.94,
    updatedAt: 0,
    bankA: [
      makePad(0, 'dhol-bass', 'timli-kick', 'single', { primaryLabel: 'Dhol Bass', pitchA: -2 }),
      makePad(1, 'dholak-ta', 'tabla-ke', 'single', { primaryLabel: 'Dholak Ta', pitchA: 2 }),
      makePad(2, 'duff-slap', 'folk-clap', 'single', { primaryLabel: 'Duff Open' }),
      makePad(3, 'manjira', 'ac-crash', 'single', { primaryLabel: 'Manjira Hi' }),
      makePad(4, 'timli-kick', 'dhol-bass', 'single', { primaryLabel: 'Punch Kick' }),
      makePad(5, 'dholak-ge', 'dholak-na', 'single', { primaryLabel: 'Dholak Ge' }),
      makePad(6, 'dholak-na', 'dholak-ta', 'split-h', {
        primaryLabel: 'Na High',
        secondaryLabel: 'Ta Slap',
        pitchA: 1,
      }),
      makePad(7, 'ghunghroo', 'el-shaker', 'single', { primaryLabel: 'Ghunghroo' }),
    ],
    bankB: [
      makePad(0, 'brass-stab', 'el-chord', 'single', { primaryLabel: 'Brass Root' }),
      makePad(1, 'brass-stab', 'el-chord', 'single', { primaryLabel: 'Brass +3', pitchA: 3 }),
      makePad(2, 'brass-stab', 'el-chord', 'single', { primaryLabel: 'Brass +5', pitchA: 5 }),
      makePad(3, 'folk-clap', 'el-clap', 'single', { primaryLabel: 'Stage Clap' }),
      makePad(4, 'ac-kick', 'timli-kick', 'single', { primaryLabel: 'Stage Kick' }),
      makePad(5, 'ac-snare', 'ac-rim', 'single', { primaryLabel: 'Stage Snare' }),
      makePad(6, 'ac-hh-closed', 'ac-hh-open', 'split-h', {
        primaryLabel: 'HH Closed',
        secondaryLabel: 'HH Open',
        chokeA: 1,
        chokeB: 1,
      }),
      makePad(7, 'ac-crash', 'ac-ride', 'single', { primaryLabel: 'Crash' }),
    ],
  },
  {
    id: 'kit-studio-acoustic',
    name: 'STUDIO ACOUSTIC',
    category: 'Acoustic Drum Kit',
    isBuiltIn: true,
    layoutType: 'grid',
    gridArrangement: 'auto',
    padGap: 6,
    padRadius: 12,
    showLabels: true,
    showKeyHints: true,
    masterVolume: 0.9,
    updatedAt: 0,
    bankA: [
      makePad(0, 'ac-crash', 'ac-ride', 'single', { primaryLabel: 'Crash' }),
      makePad(1, 'ac-tom-hi', 'ac-tom-lo', 'single', { primaryLabel: 'Rack Tom' }),
      makePad(2, 'ac-tom-lo', 'ac-tom-hi', 'single', { primaryLabel: 'Floor Tom' }),
      makePad(3, 'ac-ride', 'ac-crash', 'single', { primaryLabel: 'Ride Bell' }),
      makePad(4, 'ac-kick', 'ac-tom-lo', 'single', { primaryLabel: 'Kick' }),
      makePad(5, 'ac-snare', 'ac-rim', 'center-rim', {
        primaryLabel: 'Snare',
        secondaryLabel: 'Rimshot',
        rimThickness: 0.28,
      }),
      makePad(6, 'ac-hh-closed', 'ac-hh-open', 'split-v', {
        primaryLabel: 'Closed HH',
        secondaryLabel: 'Open HH',
        chokeA: 1,
        chokeB: 1,
      }),
      makePad(7, 'ac-hh-open', 'ac-hh-closed', 'single', { primaryLabel: 'Open HH', chokeA: 1 }),
    ],
    bankB: [
      makePad(0, 'el-perc', 'ac-rim', 'single', { primaryLabel: 'Woodblock' }),
      makePad(1, '808-cowbell', 'ac-ride', 'single', { primaryLabel: 'Cowbell' }),
      makePad(2, 'el-shaker', 'ghunghroo', 'single', { primaryLabel: 'Shaker' }),
      makePad(3, 'folk-clap', '808-clap', 'single', { primaryLabel: 'Hand Clap' }),
      makePad(4, 'ac-kick', '808-sub', 'single', { primaryLabel: 'Sub Kick', pitchA: -3 }),
      makePad(5, 'ac-rim', 'ac-snare', 'single', { primaryLabel: 'Side Stick' }),
      makePad(6, 'ac-tom-hi', 'ac-tom-lo', 'single', { primaryLabel: 'Tom +4', pitchA: 4 }),
      makePad(7, 'ac-crash', 'ac-ride', 'single', { primaryLabel: 'Crash 2', pitchA: 3 }),
    ],
  },
  {
    id: 'kit-808-promix',
    name: '808 PRO MIX',
    category: 'Hip-Hop & Electronic',
    isBuiltIn: true,
    layoutType: 'grid',
    gridArrangement: 'auto',
    padGap: 6,
    padRadius: 12,
    showLabels: true,
    showKeyHints: true,
    masterVolume: 0.92,
    updatedAt: 0,
    bankA: [
      makePad(0, '808-cowbell', '808-rim', 'single', { primaryLabel: '808 Cowbell' }),
      makePad(1, 'el-zap', 'el-perc', 'single', { primaryLabel: 'Laser Tom' }),
      makePad(2, 'el-chord', 'brass-stab', 'single', { primaryLabel: 'Synth Stab' }),
      makePad(3, 'ac-crash', '808-oh', 'single', { primaryLabel: 'Crash FX' }),
      makePad(4, '808-sub', 'el-kick', 'single', { primaryLabel: '808 Sub' }),
      makePad(5, '808-snare', '808-clap', 'split-h', {
        primaryLabel: 'Trap Snare',
        secondaryLabel: '808 Clap',
      }),
      makePad(6, '808-hh', '808-oh', 'split-v', {
        primaryLabel: 'Tick Hat',
        secondaryLabel: 'Open Hat',
        chokeA: 1,
        chokeB: 1,
      }),
      makePad(7, '808-rim', 'el-shaker', 'single', { primaryLabel: 'Rim Click' }),
    ],
    bankB: [
      makePad(0, 'el-chord', 'brass-stab', 'single', { primaryLabel: 'Chord -2', pitchA: -2 }),
      makePad(1, 'el-chord', 'brass-stab', 'single', { primaryLabel: 'Chord +3', pitchA: 3 }),
      makePad(2, 'el-chord', 'brass-stab', 'single', { primaryLabel: 'Chord +5', pitchA: 5 }),
      makePad(3, 'el-chord', 'brass-stab', 'single', { primaryLabel: 'Chord +7', pitchA: 7 }),
      makePad(4, 'el-kick', '808-sub', 'single', { primaryLabel: 'Club Kick' }),
      makePad(5, 'el-clap', '808-snare', 'single', { primaryLabel: 'Electro Clap' }),
      makePad(6, 'el-shaker', '808-hh', 'single', { primaryLabel: 'Shaker' }),
      makePad(7, 'el-perc', 'el-zap', 'single', { primaryLabel: 'Perc Hit' }),
    ],
  },
];

export function cloneKit(kit: KitPreset, newId?: string, newName?: string): KitPreset {
  return {
    ...JSON.parse(JSON.stringify(kit)),
    id: newId ?? kit.id,
    name: newName ?? kit.name,
    isBuiltIn: newId ? false : kit.isBuiltIn,
    updatedAt: Date.now(),
  };
}
