import { ensureManagementState } from './relations.js';

const ROLES = new Set(['starter', 'rotation']);
const clampInt = (value, min, max) => {
  const n = Number(value);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < min || n > max) throw new Error('Conditions de contrat invalides');
  return n;
};

function locatePlayer(state, playerId) {
  for (const division of state.divisions) {
    for (const club of division.clubs) {
      const player = (club.damistes || []).find(item => item.id === playerId);
      if (player) return { club, player };
    }
  }
  return null;
}

/** Barème provisoire et transparent : 0,8 % du budget par niveau 50, ajusté au moral. */
export function getPlayerContractDemand(state, playerId) {
  const found = locatePlayer(state, playerId);
  if (!found) throw new Error('Damiste introuvable');
  const { club, player } = found;
  const morale = Number(ensureManagementState(state).relations.playerMorale[playerId] ?? 50);
  const level = Math.max(1, Number(player.level) || 1);
  const wage = Math.max(1, Math.round(Number(club.budget || 0) * 0.008 * (level / 50) * (1 + (50 - morale) / 500)));
  return {
    wage,
    bonus: Math.round(wage * 0.1),
    duration: level >= 75 ? 2 : 1,
    role: level >= 70 ? 'starter' : 'rotation',
    morale,
    clauses: { releaseClause: Math.round(wage * 12), appearanceBonus: Math.round(wage * 0.05), loyaltyBonus: Math.round(wage * 0.1), annualRaisePercent: 0, noTransfer: false }
  };
}

export function proposePlayerContract(state, playerId, terms) {
  const m = ensureManagementState(state);
  const found = locatePlayer(state, playerId);
  if (!found || found.club.id !== state.userClubId) throw new Error('Seuls les damistes du club dirigé peuvent être négociés ici');
  const wage = clampInt(terms?.wage, 0, 1_000_000_000);
  const bonus = clampInt(terms?.bonus ?? 0, 0, 1_000_000_000);
  const duration = clampInt(terms?.duration, 1, 5);
  const role = String(terms?.role || 'rotation');
  const clauses = { releaseClause: clampInt(terms?.clauses?.releaseClause ?? 0, 0, 1_000_000_000), appearanceBonus: clampInt(terms?.clauses?.appearanceBonus ?? 0, 0, 1_000_000_000), loyaltyBonus: clampInt(terms?.clauses?.loyaltyBonus ?? 0, 0, 1_000_000_000), annualRaisePercent: clampInt(terms?.clauses?.annualRaisePercent ?? 0, 0, 20), noTransfer: Boolean(terms?.clauses?.noTransfer) };
  if (!ROLES.has(role)) throw new Error('Statut sportif inconnu');
  const active = m.contractNegotiations.find(item => item.playerId === playerId && ['pending-player', 'player-countered', 'player-accepted'].includes(item.status));
  if (active) throw new Error('Une négociation est déjà en cours pour ce damiste');
  const demand = getPlayerContractDemand(state, playerId);
  const acceptable = wage >= demand.wage && bonus >= demand.bonus && duration >= demand.duration && (demand.role !== 'starter' || role === 'starter');
  const negotiation = {
    id: `player-contract:${state.season}:${playerId}:${m.contractNegotiations.length + 1}`,
    playerId, clubId: found.club.id, playerName: found.player.name,
    proposedTerms: { wage, bonus, duration, role, clauses },
    playerDemand: demand,
    status: acceptable ? 'player-accepted' : 'player-countered',
    playerCounter: acceptable ? null : { ...demand },
    createdAt: new Date().toISOString()
  };
  m.contractNegotiations.unshift(negotiation);
  return structuredClone(negotiation);
}

export function acceptPlayerCounter(state, negotiationId) {
  const m = ensureManagementState(state);
  const n = m.contractNegotiations.find(item => item.id === negotiationId);
  if (!n || n.status !== 'player-countered') throw new Error('Aucune contre-proposition du damiste à accepter');
  n.proposedTerms = { wage: n.playerCounter.wage, bonus: n.playerCounter.bonus, duration: n.playerCounter.duration, role: n.playerCounter.role, clauses: structuredClone(n.playerCounter.clauses || {}) };
  n.status = 'player-accepted';
  n.acceptedAt = new Date().toISOString();
  return structuredClone(n);
}

export function signPlayerContract(state, negotiationId) {
  const m = ensureManagementState(state);
  const n = m.contractNegotiations.find(item => item.id === negotiationId);
  if (!n) throw new Error('Négociation de contrat introuvable');
  const found = locatePlayer(state, n.playerId);
  if (n.status === 'signed' && found?.player.contract) return structuredClone(found.player.contract);
  if (n.status !== 'player-accepted') throw new Error('Le damiste doit avoir accepté les conditions avant la signature');
  if (!found || found.club.id !== n.clubId) throw new Error('Le damiste ne fait plus partie du club');
  if (n.contractId) return structuredClone(found.player.contract);
  const club = found.club;
  const previous = Number(found.player.contract?.wage || 0);
  const payroll = Math.max(0, Number(club.payrollCommitment || 0) - previous + n.proposedTerms.wage);
  if (payroll > Number(club.budget || 0)) throw new Error('La masse salariale engagée dépasserait le budget du club');
  found.player.contract = { ...structuredClone(n.proposedTerms), status: 'active', signedAt: new Date().toISOString(), signedSeason: state.season, expiresSeason: state.season + n.proposedTerms.duration, negotiationId };
  club.payrollCommitment = payroll;
  const relations = ensureManagementState(state).relations;
  relations.playerMorale[n.playerId] = Math.max(0, Math.min(100, Number(relations.playerMorale[n.playerId] ?? 50) + 5));
  const management = ensureManagementState(state);
  management.careerLog.unshift({ id: `decision:${n.id}`, type: 'contract-signed', season: state.season, playerId: n.playerId, clubId: club.id, impact: 'Moral du damiste renforcé ; engagement salarial et clauses contractuelles enregistrés.', at: found.player.contract.signedAt });
  n.status = 'signed';
  n.contractId = `contract:${n.id}`;
  n.signedAt = found.player.contract.signedAt;
  return structuredClone(found.player.contract);
}

export function validatePlayerContracts(state) {
  const m = ensureManagementState(state);
  const ids = m.contractNegotiations.map(item => item.id);
  if (new Set(ids).size !== ids.length) throw new Error('Négociation de contrat dupliquée');
  for (const item of m.contractNegotiations) {
    if (!locatePlayer(state, item.playerId)) throw new Error(`Damiste introuvable dans la négociation ${item.id}`);
    if (item.status === 'signed' && !item.contractId) throw new Error('Contrat signé sans identifiant');
  }
  return true;
}
