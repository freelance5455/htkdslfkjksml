import { getFixtureDamiste } from './dame-or.js';
import { BANKS, SPONSORS, PROMOTERS, PARTNERS, FIRMS } from './legacy-catalog.js';

const clamp = value => Math.max(0, Math.min(100, Number(value) || 0));
const COMMERCIAL_SOURCES = new Set([...BANKS, ...SPONSORS, ...PROMOTERS, ...PARTNERS, ...FIRMS.map(x => x.name)]);

export function ensureManagementState(state) {
  state.management ??= {};
  const m = state.management;
  m.inbox ??= [];
  m.relations ??= { boardConfidence: 50, supporterSatisfaction: 50, mediaReputation: 50, playerMorale: {} };
  m.relations.playerMorale ??= {};
  m.press ??= { history: [] };
  m.press.history ??= [];
  m.commercialOffers ??= [];
  m.commercialContracts ??= [];
  m.contractNegotiations ??= [];
  m.transferOffers ??= [];
  m.transferHistory ??= [];
  m.careerLog ??= [];
  m.offerMilestones ??= [];
  m.processedEvents ??= [];
  return m;
}

export function addCareerMessage(state, message) {
  const m = ensureManagementState(state);
  if (!message?.id || !['player', 'supporters', 'board', 'press'].includes(message.type)) throw new Error('Message de carrière invalide');
  const existing = m.inbox.find(item => item.id === message.id);
  if (existing) return existing;
  const choices = Array.isArray(message.choices) ? message.choices : [];
  if (!choices.length || choices.some(choice => !choice.id || !choice.label || !choice.effects)) throw new Error('Chaque message doit proposer des réponses avec conséquences explicites');
  const item = { ...structuredClone(message), requiresResponse: message.requiresResponse ?? message.type === 'board', status: 'unread', createdAt: message.createdAt ?? new Date().toISOString(), response: null };
  m.inbox.unshift(item);
  return item;
}

export function getCareerInbox(state, { status = null } = {}) {
  const rows = ensureManagementState(state).inbox;
  return rows.filter(item => !status || item.status === status).map(item => structuredClone(item));
}

export function replyToCareerMessage(state, messageId, choiceId) {
  const m = ensureManagementState(state);
  const message = m.inbox.find(item => item.id === messageId);
  if (!message || message.status === 'answered') return false;
  const choice = message.choices.find(item => item.id === choiceId);
  if (!choice) throw new Error('Réponse indisponible pour ce message');
  const effects = choice.effects;
  for (const key of ['boardConfidence', 'supporterSatisfaction', 'mediaReputation']) {
    if (effects[key] !== undefined) m.relations[key] = clamp((m.relations[key] ?? 50) + Number(effects[key]));
  }
  if (effects.playerMorale !== undefined) {
    const playerIds = message.playerId ? [message.playerId] : (message.clubId ? (state.divisions.flatMap(d => d.clubs).find(c => c.id === message.clubId)?.damistes || []).map(p => p.id) : []);
    for (const playerId of playerIds) {
      const current = m.relations.playerMorale[playerId] ?? 50;
      m.relations.playerMorale[playerId] = clamp(current + Number(effects.playerMorale));
    }
  }
  message.status = 'answered';
  message.response = { choiceId, label: choice.label, effects: structuredClone(effects), answeredAt: new Date().toISOString() };
  if (message.type === 'press') m.press.history.push({ messageId, subject: message.subject, response: choice.label, answeredAt: message.response.answeredAt });
  return structuredClone(message.response);
}

export function receiveCommercialOffer(state, offer) {
  const m = ensureManagementState(state);
  if (!offer?.id || !COMMERCIAL_SOURCES.has(offer.sourceName)) throw new Error('Offre commerciale entrante invalide : la structure doit appartenir au catalogue du CGD');
  if (!['sponsor', 'partner', 'promoter', 'bank', 'firm'].includes(offer.kind)) throw new Error('Type de partenaire inconnu');
  if (m.commercialOffers.some(item => item.id === offer.id)) return m.commercialOffers.find(item => item.id === offer.id);
  const terms = offer.terms;
  const limits = offer.limits;
  if (!terms || !limits || !Number.isFinite(Number(terms.cash)) || !Number.isInteger(Number(terms.duration)) || !Number.isFinite(Number(limits.maximumCash)) || !Number.isInteger(Number(limits.minimumDuration))) throw new Error('Conditions ou marges de négociation manquantes dans la proposition entrante');
  if (Number(terms.cash) < 0 || Number(terms.duration) < 1 || Number(limits.maximumCash) < Number(terms.cash) || Number(limits.minimumDuration) < 1 || Number(limits.minimumDuration) > Number(terms.duration)) throw new Error('Conditions commerciales incohérentes');
  const item = { ...structuredClone(offer), origin: 'inbound', status: 'received', receivedAt: offer.receivedAt ?? new Date().toISOString(), counterOffers: [] };
  m.commercialOffers.unshift(item);
  return item;
}

export function counterCommercialOffer(state, offerId, terms) {
  const offer = ensureManagementState(state).commercialOffers.find(item => item.id === offerId);
  if (!offer || !['received', 'counter-rejected'].includes(offer.status)) throw new Error('Cette proposition ne peut plus être négociée');
  if (!terms || !Number.isFinite(Number(terms.cash)) || !Number.isInteger(Number(terms.duration))) throw new Error('Contre-proposition incomplète');
  const cash = Number(terms.cash), duration = Number(terms.duration);
  const acceptable = cash <= Number(offer.limits.maximumCash) && duration >= Number(offer.limits.minimumDuration) && duration >= 1;
  const counter = { cash, duration, visibility: String(terms.visibility ?? offer.terms.visibility ?? 'standard'), exclusivity: Boolean(terms.exclusivity), submittedAt: new Date().toISOString(), partnerDecision: acceptable ? 'accepted' : 'rejected' };
  offer.counterOffers.push(counter);
  offer.status = acceptable ? 'partner-accepted' : 'counter-rejected';
  if (acceptable) offer.acceptedTerms = { cash, duration, visibility: counter.visibility, exclusivity: counter.exclusivity };
  return { accepted: acceptable, offer: structuredClone(offer), counter: structuredClone(counter) };
}

export function acceptCommercialOffer(state, offerId) {
  const m = ensureManagementState(state);
  const offer = m.commercialOffers.find(item => item.id === offerId);
  const existing = m.commercialContracts.find(item => item.offerId === offerId);
  if (existing) return structuredClone(existing);
  if (!offer || offer.status !== 'received') throw new Error('Cette offre ne peut pas être acceptée dans son état actuel');
  offer.acceptedTerms = structuredClone(offer.terms);
  offer.status = 'manager-accepted';
  return signCommercialOffer(state, offerId);
}

export function signCommercialOffer(state, offerId) {
  const m = ensureManagementState(state);
  const offer = m.commercialOffers.find(item => item.id === offerId);
  const existing = m.commercialContracts.find(item => item.offerId === offerId);
  if (existing) return structuredClone(existing);
  if (!offer || !['manager-accepted', 'partner-accepted'].includes(offer.status)) throw new Error('Le contrat exige l’accord des deux parties avant signature');
  const club = state.divisions.flatMap(d => d.clubs).find(item => item.id === state.userClubId);
  if (!club) throw new Error('Club dirigé introuvable');
  const contract = { id: `commercial:${offer.id}`, offerId, sourceName: offer.sourceName, kind: offer.kind, terms: structuredClone(offer.acceptedTerms), signedAt: new Date().toISOString(), status: 'active' };
  club.budget = Number(club.budget || 0) + Number(contract.terms.cash || 0);
  m.commercialContracts.push(contract);
  offer.status = 'signed';
  offer.signedContractId = contract.id;
  return structuredClone(contract);
}

export function rejectCommercialOffer(state, offerId) {
  const offer = ensureManagementState(state).commercialOffers.find(item => item.id === offerId);
  if (!offer || !['received', 'counter-rejected'].includes(offer.status)) return false;
  offer.status = 'rejected';
  return true;
}

export function recordPressResponse(state, messageId, choiceId) {
  const message = ensureManagementState(state).inbox.find(item => item.id === messageId);
  if (!message || message.type !== 'press') throw new Error('Cette demande ne provient pas de la presse');
  return replyToCareerMessage(state, messageId, choiceId);
}

/**
 * Les structures du catalogue approchent automatiquement le club après ses 3e, 6e et 9e matchs de championnat.
 * Les montants utilisent un coefficient de simulation provisoire indexé sur le budget et les relations du club.
 * Aucun démarchage sortant n'est créé.
 */
export function generateInboundCommercialOffers(state) {
  const m = ensureManagementState(state);
  const club = state.divisions.flatMap(d => d.clubs).find(c => c.id === state.userClubId);
  if (!club) return [];
  const played = state.calendar.fixtures.filter(f => f.status === 'played' && !f.competitionId && (f.home === club.id || f.away === club.id)).length;
  const milestone = Math.floor(played / 3) * 3;
  if (milestone < 3 || milestone > 9 || played % 3 !== 0) return [];
  const key = `${state.season}:${milestone}`;
  if (m.offerMilestones.includes(key)) return [];
  const world = state.world || {};
  const catalogues = [
    { kind: 'sponsor', rows: world.sponsors || SPONSORS },
    { kind: 'partner', rows: world.partners || PARTNERS },
    { kind: 'promoter', rows: world.promoters || PROMOTERS },
    { kind: 'bank', rows: world.banks || BANKS },
    { kind: 'firm', rows: (world.firms || FIRMS).map(x => typeof x === 'string' ? x : x.name) }
  ];
  const slot = Math.floor(milestone / 3) - 1;
  const catalogue = catalogues[(state.season + slot - 1) % catalogues.length];
  if (!catalogue.rows.length) return [];
  const sourceName = catalogue.rows[(state.season * 3 + slot) % catalogue.rows.length];
  const relations = m.relations;
  const reputationFactor = 0.002 + (Number(relations.mediaReputation || 50) / 10000) + (Number(relations.supporterSatisfaction || 50) / 20000);
  const cash = Math.max(1000, Math.round(Number(club.budget || 0) * reputationFactor));
  const id = `inbound:${state.season}:${milestone}:${catalogue.kind}:${sourceName.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}`;
  const offer = receiveCommercialOffer(state, {
    id, kind: catalogue.kind, sourceName,
    description: `${sourceName} prend contact avec ${club.name} après ${milestone} rencontres de championnat. La structure propose un premier accord à discuter.`,
    terms: { cash, duration: 1 + (slot % 2), visibility: slot === 0 ? 'standard' : 'renforcée', exclusivity: slot === 2 },
    limits: { maximumCash: Math.round(cash * 1.25), minimumDuration: 1 }
  });
  m.offerMilestones.push(key);
  return [structuredClone(offer)];
}

export function validateManagementState(state) {
  const m = ensureManagementState(state);
  const ids = m.inbox.map(item => item.id);
  if (new Set(ids).size !== ids.length) throw new Error('Identifiant de message dupliqué');
  const offerIds = m.commercialOffers.map(item => item.id);
  if (new Set(m.offerMilestones).size !== m.offerMilestones.length) throw new Error('Jalon commercial dupliqué');
  if (new Set(offerIds).size !== offerIds.length) throw new Error('Identifiant d’offre commerciale dupliqué');
  if (m.commercialContracts.some(contract => !m.commercialOffers.some(offer => offer.id === contract.offerId && offer.status === 'signed'))) throw new Error('Contrat commercial sans offre entrante signée');
  return true;
}

/** Génère les échanges liés au match du club dirigé, sans doublonner un événement. */
export function generatePostMatchMessages(state, fixture) {
  const m = ensureManagementState(state);
  if (!fixture || fixture.status !== 'played' || (!fixture.home || !fixture.away)) return [];
  const isHome = fixture.home === state.userClubId;
  const isAway = fixture.away === state.userClubId;
  if (!isHome && !isAway) return [];
  const eventKey = `post-match:${fixture.id}`;
  if (m.processedEvents.includes(eventKey)) return [];
  const club = state.divisions.flatMap(d => d.clubs).find(c => c.id === state.userClubId);
  const opponentId = isHome ? fixture.away : fixture.home;
  const clubScore = fixture.score[isHome ? 0 : 1];
  const opponentScore = fixture.score[isHome ? 1 : 0];
  const result = clubScore > opponentScore ? 'win' : clubScore < opponentScore ? 'loss' : 'draw';
  const messages = [];
  const side = isHome ? 'home' : 'away';
  const selectedPlayer = getFixtureDamiste(club, fixture, side);
  const previousMorale = m.relations.playerMorale[selectedPlayer.id] ?? 50;
  const currentMorale = clamp(previousMorale + (result === 'win' ? 2 : result === 'loss' ? -5 : 0));
  m.relations.playerMorale[selectedPlayer.id] = currentMorale;
  const pressMessage = addCareerMessage(state, {
    id: `press:${fixture.id}`, type: 'press', clubId: state.userClubId, from: 'Presse galactique', subject: `Réaction après ${fixture.competitionName || 'la rencontre'}`,
    body: `${club?.name || state.userClubId} vient de ${result === 'win' ? 'remporter' : result === 'loss' ? 'perdre' : 'faire match nul'} sa rencontre face à ${opponentId} (${clubScore}–${opponentScore}). La presse attend une réaction du manager.`,
    choices: [
      { id: 'ambitious', label: 'Assumer l’ambition et viser plus haut', effects: { mediaReputation: 2, supporterSatisfaction: result === 'win' ? 2 : -1, boardConfidence: result === 'win' ? 2 : -1 } },
      { id: 'protect-team', label: 'Protéger le groupe et responsabiliser collectivement', effects: { mediaReputation: 1, supporterSatisfaction: 1, playerMorale: 3 } },
      { id: 'measured', label: 'Rester mesuré et rappeler le travail à poursuivre', effects: { mediaReputation: 1, boardConfidence: 1 } }
    ]
  });
  messages.push(pressMessage);
  if (result === 'loss' || result === 'draw') {
    messages.push(addCareerMessage(state, {
      id: `supporters:${fixture.id}`, type: 'supporters', from: 'Collectif des supporters', subject: result === 'loss' ? 'Inquiétude des supporters' : 'Attentes après le match nul',
      body: result === 'loss' ? 'Les supporters demandent des explications après cette défaite et attendent une réaction sportive.' : 'Les supporters estiment que le club pouvait obtenir davantage et attendent des progrès.',
      choices: [
        { id: 'promise-work', label: 'Promettre du travail et des progrès', effects: { supporterSatisfaction: 3, boardConfidence: -1 } },
        { id: 'honest', label: 'Reconnaître les difficultés sans faire de promesse', effects: { supporterSatisfaction: 1, mediaReputation: 1 } },
        { id: 'firm', label: 'Demander aux supporters de rester derrière le club', effects: { supporterSatisfaction: -2, boardConfidence: 1 } }
      ]
    }));
  }
  if (currentMorale <= 45) {
    messages.push(addCareerMessage(state, {
      id: `player:${fixture.id}:${selectedPlayer.id}`, type: 'player', playerId: selectedPlayer.id, clubId: state.userClubId, from: selectedPlayer.name, subject: 'Préoccupation sur le moral et le rôle dans le groupe',
      body: `${selectedPlayer.name} exprime une préoccupation après la rencontre. Son moral est actuellement de ${currentMorale}/100.`,
      choices: [
        { id: 'reassure-player', label: 'Échanger et rassurer le damiste', effects: { playerMorale: 8 } },
        { id: 'set-expectations', label: 'Fixer des attentes claires pour la suite', effects: { playerMorale: 3, boardConfidence: 1 } },
        { id: 'be-firm-player', label: 'Lui demander de répondre sur le terrain', effects: { playerMorale: -4, boardConfidence: 1 } }
      ]
    }));
  }
  if (result === 'loss') {
    messages.push(addCareerMessage(state, {
      id: `board:${fixture.id}`, type: 'board', from: 'Direction du club', subject: 'Évaluation de la performance',
      body: 'La direction souhaite connaître les mesures envisagées après cette défaite.',
      choices: [
        { id: 'take-responsibility', label: 'Assumer la responsabilité et présenter un plan de réaction', effects: { boardConfidence: 3, playerMorale: 1 } },
        { id: 'analyze', label: 'Expliquer les causes et annoncer une analyse', effects: { boardConfidence: 1, mediaReputation: 1 } },
        { id: 'deflect', label: 'Écarter toute responsabilité du staff', effects: { boardConfidence: -3, mediaReputation: -1 } }
      ]
    }));
  }
  m.processedEvents.push(eventKey);
  generateInboundCommercialOffers(state);
  return messages;
}
