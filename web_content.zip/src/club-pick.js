// Étape 6.5 — Choix du club (écran 05, disposition FM27). Lecture seule : aucune donnée n'est créée ni modifiée.
const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const STARS = { 'super-league': 5, 'ligue-a': 4, 'ligue-b': 3, 'ligue-c': 2, 'ligue-d': 1 };
// Mêmes objectifs que ceux que le conseil donne à la prise de fonction (manager-office.js).
export const BOARD_OBJECTIVES = ['Obtenir des résultats réguliers en championnat', 'Maintenir les finances sous contrôle', 'Préserver l’harmonie du vestiaire'];

export function buildClubChoices(state, catalog) {
  const clubs = new Map((state?.divisions || []).flatMap(division => division.clubs || []).map(club => [club.id, club]));
  return (catalog?.clubs || []).filter(item => item.available).map(item => {
    const club = clubs.get(item.id);
    return { id: item.id, name: item.name, divisionName: item.divisionName, stars: STARS[item.divisionId] || 1, budget: Number(club?.budget) || 0, damistes: (club?.damistes || []).map(player => ({ name: player.name, level: Number(player.level) || 0 })) };
  });
}

export function renderClubListHtml(choices, selectedId) {
  return choices.map(choice => `<button type="button" class="fm-pl${choice.id === selectedId ? ' on' : ''}" data-club-pick="${esc(choice.id)}" aria-pressed="${choice.id === selectedId}"><span>${esc(choice.name)}</span><small>${esc(choice.divisionName)}</small><b>${'★'.repeat(choice.stars)}</b></button>`).join('');
}

export function renderClubCardHtml(choice, lockedCount) {
  const note = lockedCount ? `<p class="fm-hint">${lockedCount} emplacements restent verrouillés (Ligues C et D, ouverture aux saisons 3 et 5).</p>` : '';
  if (!choice) return `<h3>Choisis un club</h3><small>Touche un club dans la liste pour voir sa fiche</small>${note}`;
  const players = choice.damistes.length ? choice.damistes.map(player => `${esc(player.name)} (niv. ${player.level})`).join(' · ') : 'Effectif à venir';
  return `<h3>${esc(choice.name)}</h3><small>${esc(choice.divisionName)} · ${'★'.repeat(choice.stars)}</small>
<div class="fm-lab">Effectif</div><div class="fm-box"><b>${players}</b></div>
<div class="fm-lab">Budget</div><div class="fm-box"><b>${choice.budget.toLocaleString('fr-FR')} Gold</b></div>
<div class="fm-lab">Objectifs du conseil</div><ul class="fm-obj">${BOARD_OBJECTIVES.map(label => `<li>${esc(label)}</li>`).join('')}</ul>${note}`;
}
