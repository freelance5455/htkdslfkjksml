/**
 * Central App Configuration for E SPORTS TOUR
 * 
 * Strict Branding Rules:
 * 1. Official App Name: "E SPORTS TOUR" (Never "SABBIR TOUR", never replaced by "X SABBIR")
 * 2. Developer / Brand Name: "X SABBIR" (displayed in About, Developer Credits, Info)
 * 3. WhatsApp Support Number: "01336161980" (display format)
 * 4. WhatsApp International Format: "8801336161980"
 * 5. WhatsApp Direct URL: "https://wa.me/8801336161980"
 */

export const APP_CONFIG = {
  appName: "E SPORTS TOUR",
  developerName: "X SABBIR",
  appVersion: "2.4.0 (Build 2026-Release)",
  appPlatform: "Native Android APK & Web Companion",
  targetGame: "Garena Free Fire / Free Fire MAX",
  
  // Support & Contact
  support: {
    whatsappDisplay: "01336161980",
    whatsappInternational: "8801336161980",
    whatsappUrl: "https://wa.me/8801336161980",
    supportEmail: "support@esportstour.live",
    supportHours: "24/7 Live Discord & WhatsApp Support",
    telegramChannel: "https://t.me/esportstourofficial",
    youtubeChannel: "https://youtube.com/@esportstourofficial",
  },

  // Payment methods in Bangladesh
  paymentMethods: [
    {
      id: "bkash",
      name: "bKash",
      type: "Personal / Send Money",
      accountNumber: "01336161980",
      color: "#D12053",
      minDeposit: 20,
      minWithdrawal: 50,
      fee: "0%",
      instructions: "Go to your bKash app > Select Send Money > Send to 01336161980 > Copy the TrxID and enter below."
    },
    {
      id: "nagad",
      name: "Nagad",
      type: "Personal / Send Money",
      accountNumber: "01336161980",
      color: "#F6921E",
      minDeposit: 20,
      minWithdrawal: 50,
      fee: "0%",
      instructions: "Go to your Nagad app > Select Send Money > Send to 01336161980 > Copy the 8-character TrxID and submit."
    },
    {
      id: "rocket",
      name: "Rocket",
      type: "Personal / Send Money",
      accountNumber: "01336161980-8",
      color: "#8C3494",
      minDeposit: 30,
      minWithdrawal: 50,
      fee: "0%",
      instructions: "Dial *322# or use Rocket app > Send Money to 01336161980-8 > Input Txn ID below."
    },
    {
      id: "upay",
      name: "Upay",
      type: "Personal / Send Money",
      accountNumber: "01336161980",
      color: "#006FBA",
      minDeposit: 20,
      minWithdrawal: 50,
      fee: "0%",
      instructions: "Open Upay App > Send Money to 01336161980 > Enter Transaction Reference ID."
    }
  ],

  // Free Fire Tournament Rules & Policies
  tournamentRules: [
    "Room ID and Password will be provided 15 minutes before the match start time in 'My Matches' section.",
    "Do not share Room ID or Password with anyone. Unauthorized players will be kicked immediately.",
    "Emulators are strictly prohibited unless the tournament title explicitly states 'EMULATOR ALLOWED'.",
    "Teaming up with opposing players or using third-party scripts/hacks will result in an instant permanent ban and wallet forfeiture.",
    "Screenshot of the end-game victory/kill screen is mandatory in case of any dispute.",
    "Prize pool will be credited to your E SPORTS TOUR winning wallet within 30 minutes of match completion after validation."
  ],

  // Load Test Benchmark Specifications
  loadTesting: {
    targetRegisteredUsers: 100000,
    targetConcurrentUsers: 100000,
    maxP95LatencyMs: 120,
    targetSuccessRate: "99.98%",
    rateLimitingProtection: "Redis Token Bucket + Distributed Worker Pool"
  }
};
