export type SubscriptionPlanId = 'free' | 'plus' | 'pro';
export type BillingCycle = 'monthly' | 'annual';

export interface SubscriptionPlan {
  id: SubscriptionPlanId;
  name: string;
  tagline: string;
  monthlyPrice: number;
  annualPrice: number;
  highlighted?: boolean;
  features: string[];
}

/** Proposed launch pricing. Keep prices centralized and verify them before launch. */
export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: 'free',
    name: 'Free',
    tagline: 'Build a daily learning habit',
    monthlyPrice: 0,
    annualPrice: 0,
    features: [
      'AI tutoring with starter usage limits',
      'Core practice quizzes and flashcards',
      'Chat history saved on this device',
      'Essential study tools',
    ],
  },
  {
    id: 'plus',
    name: 'Plus',
    tagline: 'For consistent learners',
    monthlyPrice: 199,
    annualPrice: 1990,
    features: [
      'Higher AI tutoring allowances',
      'Generous flashcard creation allowances',
      'Personalized practice quizzes',
      'Study planning and revision workflows',
      'Detailed learning explanations',
    ],
  },
  {
    id: 'pro',
    name: 'Pro',
    tagline: 'For ambitious study goals',
    monthlyPrice: 499,
    annualPrice: 4990,
    highlighted: true,
    features: [
      'Everything in Plus',
      'Higher advanced tutoring allowances',
      'Step-by-step educational explanations',
      'Personalized mock tests and performance insights',
      'Document and notes analysis when enabled',
      'Eligible early access to new learning features',
    ],
  },
];

export function getPlan(planId: string) {
  return SUBSCRIPTION_PLANS.find((plan) => plan.id === planId);
}
