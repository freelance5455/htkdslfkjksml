// ضع هنا بيانات تطبيق الويب من Firebase Console:
// Project settings ← Your apps ← Add app ← Web (</>) ← انسخ firebaseConfig
export const firebaseConfig = {
  apiKey: "REPLACE_ME",
  authDomain: "REPLACE_ME.firebaseapp.com",
  projectId: "REPLACE_ME",
  storageBucket: "REPLACE_ME.appspot.com",
  messagingSenderId: "REPLACE_ME",
  appId: "REPLACE_ME"
};

// لا تغيّر هذا السطر إذا كانت لديك بيانات قديمة تريد الاحتفاظ بمساراتها
export const appId = "serag-residents-app";

export const isConfigPlaceholder = [firebaseConfig.apiKey, firebaseConfig.projectId, firebaseConfig.appId]
  .some(v => !v || String(v).includes("REPLACE_ME") || /demo/i.test(String(v)));
