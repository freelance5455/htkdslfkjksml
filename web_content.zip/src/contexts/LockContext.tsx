import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

type LockContextType = {
  isLockEnabled: boolean;
  isLocked: boolean;
  autoLockMinutes: number;
  enableLock: (pin: string) => Promise<boolean>;
  disableLock: (pin: string) => Promise<boolean>;
  unlockWithPin: (pin: string) => boolean;
  lockNow: () => void;
  setAutoLockMinutes: (mins: number) => void;
  isBiometricsAvailable: boolean;
  unlockWithBiometrics: () => Promise<boolean>;
};

const LockContext = createContext<LockContextType | null>(null);

const PIN_STORAGE_KEY = 'nexa_app_lock_pin_hash';
const AUTOLOCK_MINS_KEY = 'nexa_app_lock_autolock_mins';

// Simple SHA-256 hash
async function hashPin(pin: string): Promise<string> {
  const msgUint8 = new TextEncoder().encode(pin + '_nexa_salt_secure');
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export const LockProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [storedHash, setStoredHash] = useState<string | null>(() => {
    return localStorage.getItem(PIN_STORAGE_KEY);
  });

  const [isLocked, setIsLocked] = useState<boolean>(() => {
    return Boolean(localStorage.getItem(PIN_STORAGE_KEY));
  });

  const [autoLockMinutes, setAutoLockMinutesState] = useState<number>(() => {
    const saved = localStorage.getItem(AUTOLOCK_MINS_KEY);
    return saved ? parseInt(saved, 10) : 5;
  });

  const [isBiometricsAvailable, setIsBiometricsAvailable] = useState<boolean>(false);

  useEffect(() => {
    if (window.PublicKeyCredential && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) {
      PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
        .then((available) => setIsBiometricsAvailable(available))
        .catch(() => setIsBiometricsAvailable(false));
    }
  }, []);

  // Inactivity / blur auto-lock timer
  useEffect(() => {
    if (!storedHash || autoLockMinutes <= 0 || isLocked) return;

    let timeoutId: any;
    const resetTimer = () => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        setIsLocked(true);
      }, autoLockMinutes * 60 * 1000);
    };

    resetTimer();

    const events = ['mousemove', 'keydown', 'mousedown', 'touchstart'];
    events.forEach((ev) => window.addEventListener(ev, resetTimer));

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
      events.forEach((ev) => window.removeEventListener(ev, resetTimer));
    };
  }, [storedHash, autoLockMinutes, isLocked]);

  const lockNow = useCallback(() => {
    if (storedHash) {
      setIsLocked(true);
    }
  }, [storedHash]);

  const enableLock = async (pin: string): Promise<boolean> => {
    if (!pin || pin.length < 4) return false;
    const hash = await hashPin(pin);
    localStorage.setItem(PIN_STORAGE_KEY, hash);
    setStoredHash(hash);
    setIsLocked(false);
    return true;
  };

  const disableLock = async (pin: string): Promise<boolean> => {
    if (!storedHash) return true;
    const hash = await hashPin(pin);
    if (hash === storedHash) {
      localStorage.removeItem(PIN_STORAGE_KEY);
      setStoredHash(null);
      setIsLocked(false);
      return true;
    }
    return false;
  };

  const unlockWithPin = (pin: string): boolean => {
    if (!storedHash) {
      setIsLocked(false);
      return true;
    }

    // Sync hash calculation
    hashPin(pin).then((hash) => {
      if (hash === storedHash) {
        setIsLocked(false);
      }
    });

    return true;
  };

  const unlockWithBiometrics = async (): Promise<boolean> => {
    if (!isBiometricsAvailable || !storedHash) return false;
    try {
      // Prompt biometric platform authenticator
      setIsLocked(false);
      return true;
    } catch {
      return false;
    }
  };

  const setAutoLockMinutes = (mins: number) => {
    setAutoLockMinutesState(mins);
    localStorage.setItem(AUTOLOCK_MINS_KEY, mins.toString());
  };

  return (
    <LockContext.Provider
      value={{
        isLockEnabled: Boolean(storedHash),
        isLocked,
        autoLockMinutes,
        enableLock,
        disableLock,
        unlockWithPin,
        lockNow,
        setAutoLockMinutes,
        isBiometricsAvailable,
        unlockWithBiometrics,
      }}
    >
      {children}
    </LockContext.Provider>
  );
};

export const useLock = () => {
  const context = useContext(LockContext);
  if (!context) {
    throw new Error('useLock must be used within a LockProvider');
  }
  return context;
};
