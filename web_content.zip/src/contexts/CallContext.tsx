import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { supabase, getIceServers } from '../lib/supabase';
import { useAuth } from './AuthContext';
import { ActiveCallSession, CallType, Profile } from '../types';
import { logCall, updateCallRecord } from '../services/callService';

type CallContextType = {
  activeCall: ActiveCallSession | null;
  startCall: (targetUser: Profile, callType: CallType) => Promise<void>;
  acceptCall: () => Promise<void>;
  rejectCall: () => Promise<void>;
  endCall: () => Promise<void>;
  toggleMute: () => void;
  toggleVideo: () => void;
  toggleSpeaker: () => void;
};

const CallContext = createContext<CallContextType | undefined>(undefined);

// Web Audio Ringtone Generator (no external audio assets required)
class AudioToneGenerator {
  private ctx: AudioContext | null = null;
  private interval: any = null;

  startRingtone(type: 'ringing' | 'incoming') {
    this.stop();
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();

      const playPulse = () => {
        if (!this.ctx || this.ctx.state === 'closed') return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(type === 'ringing' ? 440 : 520, this.ctx.currentTime);

        gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 1.2);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 1.2);
      };

      playPulse();
      this.interval = setInterval(playPulse, 2800);
    } catch {}
  }

  stop() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
    if (this.ctx) {
      this.ctx.close().catch(() => {});
      this.ctx = null;
    }
  }
}

const toneGen = new AudioToneGenerator();

export const CallProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, profile, isConfigured } = useAuth();
  const [activeCall, setActiveCall] = useState<ActiveCallSession | null>(null);

  const activeCallRef = useRef<ActiveCallSession | null>(null);
  activeCallRef.current = activeCall;

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const callRoomChannelRef = useRef<any>(null);
  const durationTimerRef = useRef<any>(null);
  const callRecordIdRef = useRef<string | null>(null);
  const startTimeRef = useRef<Date | null>(null);

  // Stop ringtone when status changes away from ringing/incoming
  useEffect(() => {
    if (!activeCall || (activeCall.status !== 'ringing' && activeCall.status !== 'incoming')) {
      toneGen.stop();
    }
  }, [activeCall?.status]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      toneGen.stop();
      if (durationTimerRef.current) clearInterval(durationTimerRef.current);
      if (pcRef.current) {
        pcRef.current.close();
        pcRef.current = null;
      }
      if (callRoomChannelRef.current) {
        callRoomChannelRef.current.unsubscribe();
        callRoomChannelRef.current = null;
      }
    };
  }, []);

  // Listen to personal signaling channel: nexa-signal-<userId>
  useEffect(() => {
    if (!isConfigured || !user) return;

    const channelName = `nexa-signal-${user.id}`;
    const userSignalChannel = supabase.channel(channelName);

    userSignalChannel
      .on('broadcast', { event: 'call_invite' }, async ({ payload }) => {
        const current = activeCallRef.current;
        // If already in an active call, auto-reject with busy
        if (current && current.status !== 'ended') {
          const replyChannel = supabase.channel(`nexa-signal-${payload.caller.id}`);
          replyChannel.subscribe((st) => {
            if (st === 'SUBSCRIBED') {
              replyChannel.send({
                type: 'broadcast',
                event: 'call_busy',
                payload: { callId: payload.callId },
              });
            }
          });
          return;
        }

        toneGen.startRingtone('incoming');

        const session: ActiveCallSession = {
          callId: payload.callId,
          isCaller: false,
          peerUser: payload.caller,
          callType: payload.callType,
          status: 'incoming',
          isMuted: false,
          isVideoOff: false,
          isSpeakerOn: true,
          durationSeconds: 0,
        };

        setActiveCall(session);
      })
      .subscribe();

    return () => {
      userSignalChannel.unsubscribe();
    };
  }, [isConfigured, user?.id]);

  const startDurationTimer = () => {
    if (durationTimerRef.current) clearInterval(durationTimerRef.current);
    durationTimerRef.current = setInterval(() => {
      setActiveCall((prev) => {
        if (!prev || prev.status !== 'connected') return prev;
        return {
          ...prev,
          durationSeconds: prev.durationSeconds + 1,
        };
      });
    }, 1000);
  };

  const setupPeerConnection = (peerUser: Profile, callType: CallType, stream: MediaStream, callId: string) => {
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }

    const pc = new RTCPeerConnection({
      iceServers: getIceServers(),
    });
    pcRef.current = pc;

    // Add local tracks to peer connection
    stream.getTracks().forEach((track) => {
      pc.addTrack(track, stream);
    });

    // Handle incoming remote tracks
    pc.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        setActiveCall((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            remoteStream: event.streams[0],
            status: 'connected',
            startedAt: prev.startedAt || new Date(),
          };
        });

        if (!startTimeRef.current) {
          startTimeRef.current = new Date();
          startDurationTimer();
        }
      }
    };

    // Send ICE candidates to the dedicated call room
    pc.onicecandidate = (event) => {
      if (event.candidate && callRoomChannelRef.current) {
        callRoomChannelRef.current.send({
          type: 'broadcast',
          event: 'ice_candidate',
          payload: {
            callId,
            senderId: user?.id,
            candidate: event.candidate,
          },
        });
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') {
        toneGen.stop();
        setActiveCall((prev) => (prev ? { ...prev, status: 'connected' } : null));
        if (!startTimeRef.current) {
          startTimeRef.current = new Date();
          startDurationTimer();
        }
      } else if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
        handleCallEnd('failed');
      }
    };

    return pc;
  };

  // 1. Caller starts the call
  const startCall = async (targetUser: Profile, callType: CallType) => {
    if (!user || !profile) return;
    const callId = `call_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: callType === 'video',
      });

      // Log call record
      const recId = await logCall({
        callerId: user.id,
        receiverId: targetUser.id,
        callType,
        status: 'missed',
      }).catch(() => null);

      callRecordIdRef.current = recId;
      startTimeRef.current = null;

      const newSession: ActiveCallSession = {
        callId,
        isCaller: true,
        peerUser: targetUser,
        callType,
        status: 'ringing',
        localStream: stream,
        isMuted: false,
        isVideoOff: false,
        isSpeakerOn: true,
        durationSeconds: 0,
      };

      setActiveCall(newSession);
      toneGen.startRingtone('ringing');

      // Setup RTCPeerConnection
      setupPeerConnection(targetUser, callType, stream, callId);

      // Join the dedicated call room channel
      const callRoom = supabase.channel(`nexa-call-${callId}`);
      callRoomChannelRef.current = callRoom;

      callRoom
        .on('broadcast', { event: 'call_accepted' }, async () => {
          toneGen.stop();
          setActiveCall((prev) => (prev ? { ...prev, status: 'connecting' } : null));

          try {
            if (pcRef.current) {
              const offer = await pcRef.current.createOffer({
                offerToReceiveAudio: true,
                offerToReceiveVideo: callType === 'video',
              });
              await pcRef.current.setLocalDescription(offer);

              callRoom.send({
                type: 'broadcast',
                event: 'webrtc_offer',
                payload: { callId, offer },
              });
            }
          } catch (err) {
            console.error('Error creating WebRTC offer:', err);
            handleCallEnd('failed');
          }
        })
        .on('broadcast', { event: 'webrtc_answer' }, async ({ payload }) => {
          try {
            if (pcRef.current) {
              await pcRef.current.setRemoteDescription(new RTCSessionDescription(payload.answer));
            }
          } catch (err) {
            console.error('Error setting remote description from answer:', err);
          }
        })
        .on('broadcast', { event: 'ice_candidate' }, async ({ payload }) => {
          if (payload.senderId === user.id) return;
          try {
            if (pcRef.current && payload.candidate) {
              await pcRef.current.addIceCandidate(new RTCIceCandidate(payload.candidate));
            }
          } catch (err) {
            console.error('Error adding ICE candidate:', err);
          }
        })
        .on('broadcast', { event: 'call_rejected' }, () => {
          toneGen.stop();
          handleCallEnd('rejected');
        })
        .on('broadcast', { event: 'call_ended' }, () => {
          toneGen.stop();
          handleCallEnd('connected');
        })
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            // Once caller has joined the call room, send invite to target user's personal signaling channel
            const targetChannel = supabase.channel(`nexa-signal-${targetUser.id}`);
            targetChannel.subscribe((targetStatus) => {
              if (targetStatus === 'SUBSCRIBED') {
                targetChannel.send({
                  type: 'broadcast',
                  event: 'call_invite',
                  payload: {
                    callId,
                    caller: profile,
                    callType,
                  },
                });
              }
            });
          }
        });

      // Auto cancel after 40 seconds if no answer
      setTimeout(() => {
        const curr = activeCallRef.current;
        if (curr && curr.callId === callId && curr.status === 'ringing') {
          handleCallEnd('missed');
        }
      }, 40000);
    } catch (err: any) {
      console.error('Call initialization failed:', err);
      alert(
        err.name === 'NotAllowedError'
          ? 'Microphone or Camera permission denied. Please allow permissions in browser.'
          : 'Could not access audio/video devices.'
      );
    }
  };

  // 2. Receiver accepts the call
  const acceptCall = async () => {
    const call = activeCallRef.current;
    if (!call || !user) return;
    toneGen.stop();

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: call.callType === 'video',
      });

      setupPeerConnection(call.peerUser, call.callType, stream, call.callId);

      setActiveCall((prev) => (prev ? { ...prev, localStream: stream, status: 'connecting' } : null));

      // Join the dedicated call room channel
      const callRoom = supabase.channel(`nexa-call-${call.callId}`);
      callRoomChannelRef.current = callRoom;

      callRoom
        .on('broadcast', { event: 'webrtc_offer' }, async ({ payload }) => {
          try {
            if (pcRef.current) {
              await pcRef.current.setRemoteDescription(new RTCSessionDescription(payload.offer));
              const answer = await pcRef.current.createAnswer();
              await pcRef.current.setLocalDescription(answer);

              callRoom.send({
                type: 'broadcast',
                event: 'webrtc_answer',
                payload: { callId: call.callId, answer },
              });
            }
          } catch (err) {
            console.error('Error handling WebRTC offer:', err);
          }
        })
        .on('broadcast', { event: 'ice_candidate' }, async ({ payload }) => {
          if (payload.senderId === user.id) return;
          try {
            if (pcRef.current && payload.candidate) {
              await pcRef.current.addIceCandidate(new RTCIceCandidate(payload.candidate));
            }
          } catch (err) {
            console.error('Error adding ICE candidate:', err);
          }
        })
        .on('broadcast', { event: 'call_ended' }, () => {
          toneGen.stop();
          handleCallEnd('connected');
        })
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            // Signal caller that call was accepted
            callRoom.send({
              type: 'broadcast',
              event: 'call_accepted',
              payload: { callId: call.callId },
            });
          }
        });
    } catch (err: any) {
      console.error('Accept call failed:', err);
      alert('Could not access microphone/camera to accept call.');
      rejectCall();
    }
  };

  // 3. Receiver rejects the call
  const rejectCall = async () => {
    const call = activeCallRef.current;
    if (!call) return;
    toneGen.stop();

    if (callRoomChannelRef.current) {
      callRoomChannelRef.current.send({
        type: 'broadcast',
        event: 'call_rejected',
        payload: { callId: call.callId },
      });
    } else {
      const targetChannel = supabase.channel(`nexa-signal-${call.peerUser.id}`);
      targetChannel.subscribe((st) => {
        if (st === 'SUBSCRIBED') {
          targetChannel.send({
            type: 'broadcast',
            event: 'call_rejected',
            payload: { callId: call.callId },
          });
        }
      });
    }

    handleCallEnd('rejected');
  };

  // 4. Either user ends the call
  const endCall = async () => {
    const call = activeCallRef.current;
    if (!call) return;
    toneGen.stop();

    if (callRoomChannelRef.current) {
      callRoomChannelRef.current.send({
        type: 'broadcast',
        event: 'call_ended',
        payload: { callId: call.callId },
      });
    }

    handleCallEnd(call.status === 'connected' ? 'connected' : 'cancelled');
  };

  const handleCallEnd = async (finalStatus: 'connected' | 'missed' | 'rejected' | 'failed' | 'cancelled') => {
    toneGen.stop();
    if (durationTimerRef.current) {
      clearInterval(durationTimerRef.current);
      durationTimerRef.current = null;
    }

    const currentCall = activeCallRef.current;

    if (currentCall?.localStream) {
      currentCall.localStream.getTracks().forEach((t) => t.stop());
    }

    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }

    if (callRoomChannelRef.current) {
      callRoomChannelRef.current.unsubscribe();
      callRoomChannelRef.current = null;
    }

    const duration = currentCall?.durationSeconds || 0;
    if (callRecordIdRef.current) {
      await updateCallRecord(callRecordIdRef.current, {
        status: finalStatus,
        endedAt: new Date(),
        durationSeconds: duration,
      }).catch(() => {});
      callRecordIdRef.current = null;
    }

    setActiveCall(null);
    startTimeRef.current = null;
  };

  const toggleMute = () => {
    setActiveCall((prev) => {
      if (!prev || !prev.localStream) return prev;
      const audioTrack = prev.localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = prev.isMuted; // Toggle: if currently muted, enable it
      }
      return { ...prev, isMuted: !prev.isMuted };
    });
  };

  const toggleVideo = () => {
    setActiveCall((prev) => {
      if (!prev || !prev.localStream) return prev;
      const videoTrack = prev.localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = prev.isVideoOff; // Toggle: if currently off, enable it
      }
      return { ...prev, isVideoOff: !prev.isVideoOff };
    });
  };

  const toggleSpeaker = () => {
    setActiveCall((prev) => {
      if (!prev) return null;
      return { ...prev, isSpeakerOn: !prev.isSpeakerOn };
    });
  };

  return (
    <CallContext.Provider
      value={{
        activeCall,
        startCall,
        acceptCall,
        rejectCall,
        endCall,
        toggleMute,
        toggleVideo,
        toggleSpeaker,
      }}
    >
      {children}
    </CallContext.Provider>
  );
};

export const useCall = () => {
  const context = useContext(CallContext);
  if (!context) {
    throw new Error('useCall must be used within a CallProvider');
  }
  return context;
};
