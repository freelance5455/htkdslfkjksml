import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase, usernameToInternalEmail, isValidUsername, isSupabaseConfigured } from '../lib/supabase';
import { Profile } from '../types';

type AuthContextType = {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  isConfigured: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, displayName: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (updates: { display_name?: string; bio?: string; avatar_url?: string }) => Promise<void>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const configured = isSupabaseConfigured();

  const fetchProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error && error.code === 'PGRST116') {
        // Profile row doesn't exist yet, create it
        const authUser = (await supabase.auth.getUser()).data.user;
        if (authUser) {
          const defaultUsername = authUser.user_metadata?.username || `user_${userId.slice(0, 6)}`;
          const defaultName = authUser.user_metadata?.display_name || defaultUsername;
          const { data: newProf } = await supabase
            .from('profiles')
            .upsert({
              id: userId,
              username: defaultUsername,
              display_name: defaultName,
            })
            .select()
            .single();

          if (newProf) setProfile(newProf);
        }
      } else if (data) {
        setProfile(data);
      }
    } catch (err) {
      console.error('Error loading profile:', err);
    }
  };

  useEffect(() => {
    if (!configured) {
      setLoading(false);
      return;
    }

    // Check active session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    }).catch(() => {
      setLoading(false);
    });

    // Listen to auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        await fetchProfile(session.user.id);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [configured]);

  const login = async (username: string, password: string) => {
    if (!configured) throw new Error('Supabase credentials are not configured.');
    const cleanUsername = username.trim().toLowerCase().replace(/^@+/, '');
    if (!cleanUsername) throw new Error('Username is required.');
    if (!password) throw new Error('Password is required.');

    const email = usernameToInternalEmail(cleanUsername);
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      if (error.message.includes('Invalid login credentials')) {
        throw new Error('Incorrect username or password. Please verify your credentials.');
      }
      if (error.message.includes('Email not confirmed')) {
        throw new Error('Email verification is required by Supabase. Please disable "Confirm email" under Authentication > Providers > Email in your Supabase Dashboard.');
      }
      throw new Error(error.message);
    }

    if (data.user) {
      setUser(data.user);
      setSession(data.session);
      await fetchProfile(data.user.id);
    }
  };

  const register = async (username: string, displayName: string, password: string) => {
    if (!configured) throw new Error('Supabase credentials are not configured.');
    
    const cleanUsername = username.trim().toLowerCase().replace(/^@+/, '');
    if (!isValidUsername(cleanUsername)) {
      throw new Error('Username must be 3-24 characters and only contain letters, numbers, underscores or periods.');
    }
    if (!displayName.trim()) {
      throw new Error('Display name is required.');
    }
    if (password.length < 6) {
      throw new Error('Password must be at least 6 characters.');
    }

    const internalEmail = usernameToInternalEmail(cleanUsername);

    // 1. First, check username uniqueness in profiles table
    const { data: existing, error: checkError } = await supabase
      .from('profiles')
      .select('id')
      .ilike('username', cleanUsername)
      .limit(1);

    if (!checkError && existing && existing.length > 0) {
      throw new Error(`Username @${cleanUsername} is already taken. Please choose another.`);
    }

    let accountCreated = false;

    // 2. Call privileged server-side registration endpoint
    try {
      const serverRes = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: cleanUsername,
          displayName: displayName.trim(),
          password,
        }),
      });

      const serverData = await serverRes.json().catch(() => null);

      if (serverRes.ok && serverData?.success) {
        accountCreated = true;
      } else if (serverRes.status === 409) {
        throw new Error(`Username @${cleanUsername} is already registered. Please sign in.`);
      } else if (serverData?.error && !serverData.error.includes('Server requires SUPABASE_SERVICE_ROLE_KEY')) {
        throw new Error(serverData.error);
      }
    } catch (err: any) {
      if (err.message && (err.message.includes('already registered') || err.message.includes('already taken'))) {
        throw err;
      }
      // Server endpoint not reachable or missing service key, continue to direct fallbacks
    }

    // 3. Fallback: Try calling register_nexa_user RPC if server endpoint didn't handle it
    if (!accountCreated) {
      try {
        const { data: rpcData, error: rpcError } = await supabase.rpc('register_nexa_user', {
          p_username: cleanUsername,
          p_display_name: displayName.trim(),
          p_password: password,
        });

        if (!rpcError && rpcData?.success) {
          accountCreated = true;
        } else if (rpcData?.error) {
          throw new Error(rpcData.error);
        }
      } catch (err: any) {
        if (err.message && (err.message.includes('already registered') || err.message.includes('already taken'))) {
          throw err;
        }
      }
    }

    // 4. Fallback: Standard client-side signUp
    if (!accountCreated) {
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: internalEmail,
        password,
        options: {
          data: {
            username: cleanUsername,
            display_name: displayName.trim(),
          },
        },
      });

      if (signUpError) {
        if (signUpError.message.includes('User already registered')) {
          throw new Error(`Username @${cleanUsername} is already registered. Please sign in.`);
        }
        if (signUpError.message.includes('rate limit')) {
          throw new Error(
            'Supabase email confirmation rate limit reached. Please disable "Confirm email" under Authentication > Providers > Email in your Supabase Dashboard for instant zero-confirmation accounts.'
          );
        }
        throw new Error(signUpError.message);
      }

      if (signUpData.user) {
        try {
          await supabase.from('profiles').upsert(
            {
              id: signUpData.user.id,
              username: cleanUsername,
              display_name: displayName.trim(),
            },
            { onConflict: 'id' }
          );
        } catch {}
      }
    }

    // 5. Establish real Supabase session immediately
    await login(cleanUsername, password);
  };

  const logout = async () => {
    if (!configured) return;
    try {
      await supabase.auth.signOut();
    } catch {}
    setUser(null);
    setSession(null);
    setProfile(null);
  };

  const updateProfile = async (updates: { display_name?: string; bio?: string; avatar_url?: string }) => {
    if (!user || !profile) return;

    const payload: any = { updated_at: new Date().toISOString() };
    if (updates.display_name !== undefined) payload.display_name = updates.display_name.trim();
    if (updates.bio !== undefined) payload.bio = updates.bio;
    if (updates.avatar_url !== undefined) payload.avatar_url = updates.avatar_url;

    const { data, error } = await supabase
      .from('profiles')
      .update(payload)
      .eq('id', user.id)
      .select()
      .single();

    if (error) throw error;
    if (data) setProfile(data);
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        loading,
        isConfigured: configured,
        login,
        register,
        logout,
        updateProfile,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
