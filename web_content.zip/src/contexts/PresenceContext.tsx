import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

type PresenceContextType = {
  onlineUserIds: Set<string>;
  isUserOnline: (userId: string) => boolean;
  typingUsersByConv: Record<string, Set<string>>; // convId -> Set of typing userIds
  setTypingState: (convId: string, isTyping: boolean) => void;
};

const PresenceContext = createContext<PresenceContextType | undefined>(undefined);

export const PresenceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, profile, isConfigured } = useAuth();
  const [onlineUserIds, setOnlineUserIds] = useState<Set<string>>(new Set());
  const [typingUsersByConv, setTypingUsersByConv] = useState<Record<string, Set<string>>>({});
  
  const typingTimeouts = useRef<Record<string, NodeJS.Timeout>>({});
  const presenceChannelRef = useRef<any>(null);

  // Presence channel to track who is online
  useEffect(() => {
    if (!isConfigured || !user || !profile) return;

    const channel = supabase.channel('nexa-global-presence', {
      config: {
        presence: {
          key: user.id,
        },
      },
    });

    presenceChannelRef.current = channel;

    channel
      .on('presence', { event: 'sync' }, () => {
        const state = channel.presenceState();
        const activeIds = new Set<string>();
        Object.keys(state).forEach((key) => {
          activeIds.add(key);
        });
        setOnlineUserIds(activeIds);
      })
      .on('presence', { event: 'join' }, ({ key }) => {
        setOnlineUserIds((prev) => new Set([...prev, key]));
      })
      .on('presence', { event: 'leave' }, ({ key }) => {
        setOnlineUserIds((prev) => {
          const next = new Set(prev);
          next.delete(key);
          return next;
        });
      })
      .on('broadcast', { event: 'typing' }, ({ payload }) => {
        const { convId, userId, isTyping } = payload;
        if (!convId || !userId || userId === user.id) return;

        setTypingUsersByConv((prev) => {
          const current = new Set(prev[convId] || []);
          if (isTyping) {
            current.add(userId);
          } else {
            current.delete(userId);
          }
          return { ...prev, [convId]: current };
        });

        // Auto-clear typing indicator after 4 seconds
        const timerKey = `${convId}_${userId}`;
        if (typingTimeouts.current[timerKey]) {
          clearTimeout(typingTimeouts.current[timerKey]);
        }

        if (isTyping) {
          typingTimeouts.current[timerKey] = setTimeout(() => {
            setTypingUsersByConv((prev) => {
              const current = new Set(prev[convId] || []);
              current.delete(userId);
              return { ...prev, [convId]: current };
            });
          }, 4000);
        }
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await channel.track({
            online_at: new Date().toISOString(),
            username: profile.username,
          });

          // Also update last_seen in database
          try {
            await supabase
              .from('profiles')
              .update({ last_seen: new Date().toISOString() })
              .eq('id', user.id);
          } catch {
            // ignore offline / network error
          }
        }
      });

    const handleBeforeUnload = () => {
      try {
        void supabase
          .from('profiles')
          .update({ last_seen: new Date().toISOString() })
          .eq('id', user.id);
      } catch {
        // ignore
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      channel.unsubscribe();
      presenceChannelRef.current = null;
    };
  }, [isConfigured, user?.id, profile?.username]);

  const isUserOnline = (userId: string): boolean => {
    return onlineUserIds.has(userId);
  };

  const setTypingState = (convId: string, isTyping: boolean) => {
    if (!presenceChannelRef.current || !user) return;

    presenceChannelRef.current.send({
      type: 'broadcast',
      event: 'typing',
      payload: {
        convId,
        userId: user.id,
        isTyping,
      },
    });
  };

  return (
    <PresenceContext.Provider
      value={{
        onlineUserIds,
        isUserOnline,
        typingUsersByConv,
        setTypingState,
      }}
    >
      {children}
    </PresenceContext.Provider>
  );
};

export const usePresence = () => {
  const context = useContext(PresenceContext);
  if (!context) {
    throw new Error('usePresence must be used within a PresenceProvider');
  }
  return context;
};
