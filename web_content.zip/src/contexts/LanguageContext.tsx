import { createContext, useContext, useEffect, useMemo, type ReactNode } from 'react';
import type { UiLanguageCode } from '../types';
import {
  getLanguageMeta,
  getTranslations,
  SUPPORTED_LANGUAGES,
  type LanguageOption,
  type UiTranslationMap,
} from '../i18n/translations';

interface LanguageContextValue {
  lang: UiLanguageCode;
  meta: LanguageOption;
  dir: 'rtl' | 'ltr';
  isRtl: boolean;
  t: UiTranslationMap;
  languages: LanguageOption[];
  setLang: (code: UiLanguageCode) => void;
}

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({
  lang,
  onChangeLang,
  children,
}: {
  lang: UiLanguageCode;
  onChangeLang: (code: UiLanguageCode) => void;
  children: ReactNode;
}) {
  const meta = useMemo(() => getLanguageMeta(lang), [lang]);
  const t = useMemo(() => getTranslations(lang), [lang]);

  useEffect(() => {
    document.documentElement.lang = meta.code;
    document.documentElement.dir = meta.dir;
    document.title = `TMN — ${t.appTagline}`;
  }, [meta.code, meta.dir, t.appTagline]);

  const value = useMemo<LanguageContextValue>(
    () => ({
      lang: meta.code,
      meta,
      dir: meta.dir,
      isRtl: meta.dir === 'rtl',
      t,
      languages: SUPPORTED_LANGUAGES,
      setLang: onChangeLang,
    }),
    [meta, t, onChangeLang]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useI18n(): LanguageContextValue {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useI18n must be used inside LanguageProvider');
  return ctx;
}
