#|
$JSON
{"authURL":["creator.kodular.io"],"YaVersion":"247","Source":"Form","Properties":{"$Name":"Screen2","$Type":"Form","$Version":"46","AppId":"489354282698350687","AppName":"KRDGAME","CloseScreenAnimation":"fade","HighQuality":"True","ReceiveSharedText":"none","Theme":"AppTheme.Light","Title":"Screen2","Uuid":"0"}}
|#