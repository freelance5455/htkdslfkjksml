#|
$JSON
{"authURL":["creator.kodular.io"],"YaVersion":"247","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"46","AppId":"489354282698350687","AppName":"KRDGAME","ReceiveSharedText":"none","Theme":"AppTheme.Light","Title":"Screen1","Uuid":"0","$Components":[{"$Name":"Floating_Action_Button1","$Type":"MakeroidFab","$Version":"2","Uuid":"1691543793"}]}}
|#