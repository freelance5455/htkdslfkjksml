// Client side of the wallet. Every balance change goes through Cloud Functions;
// the app never writes coins, flowers or earnings itself.
import { httpsCallable } from 'firebase/functions';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { functions, db } from './firebase';
import { WalletTransaction } from './types';

export function walletErrorMessage(err: any): string {
  const msg: string = err?.message || '';
  const code: string = err?.code || '';
  // Server messages are Arabic. Raw English codes mean the function itself was not reached.
  if (!msg || /^[A-Za-z_ :.-]+$/.test(msg) || code === 'functions/unavailable' || code === 'functions/internal') {
    return 'خدمة المحفظة غير متاحة الآن. تأكد من الاتصال، ومن أن Cloud Functions منشورة.';
  }
  return msg;
}

async function call<T = any>(name: string, data: unknown): Promise<T> {
  const res = await httpsCallable(functions, name)(data);
  return res.data as T;
}

export type GiftContext =
  | { type: 'room'; roomId: string; targetUserId?: string }
  | { type: 'chat'; targetUserId: string }
  | { type: 'profile'; targetUserId: string }
  | { type: 'bag' };

export const sendGiftFn = (p: { giftId: string; currency: 'coins' | 'flowers'; quantity?: number; context: GiftContext }) =>
  call<{ ok: true; coins: number; flowersCount: number; earnedByReceiver: number }>('sendGift', p);

export const claimDailyBonusFn = () =>
  call<{ ok: true; coins: number; flowersCount: number; bonus: { coins: number; flowers: number } }>('claimDailyBonus', {});

export const reviewTopupFn = (requestId: string, decision: 'approve' | 'reject') =>
  call<{ ok: true }>('reviewTopup', { requestId, decision });

export const requestWithdrawalFn = (amount: number, phone: string) =>
  call<{ ok: true; id: string; amountEGP: number }>('requestWithdrawal', { amount, phone, method: 'vodafone_cash' });

export const cancelWithdrawalFn = (withdrawalId: string) =>
  call<{ ok: true }>('cancelWithdrawal', { withdrawalId });

export const reviewWithdrawalFn = (withdrawalId: string, decision: 'approve' | 'reject' | 'paid', note?: string) =>
  call<{ ok: true }>('reviewWithdrawal', { withdrawalId, decision, note });

export function subscribeTransactions(
  uid: string,
  onData: (list: WalletTransaction[]) => void,
  onError?: (e: unknown) => void
) {
  const q = query(collection(db, 'users', uid, 'transactions'), orderBy('createdAt', 'desc'), limit(50));
  return onSnapshot(
    q,
    (snap) => {
      onData(
        snap.docs.map((d) => {
          const data = d.data() as any;
          const created = data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : data.createdAt || '';
          return { id: d.id, ...data, createdAt: created } as WalletTransaction;
        })
      );
    },
    (e) => onError?.(e)
  );
}
