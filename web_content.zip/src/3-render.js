
/* =====================================================================
   RENDER
   ===================================================================== */
const cv=$('cv'),cx=cv.getContext('2d');
let cvScale=1;
function setupCanvas(){
  const dpr=Math.min(window.devicePixelRatio||1,2);
  cvScale=[.75,1,Math.max(1,Math.min(1.5,dpr))][S.gfx]||1;
  cv.width=Math.round(W*cvScale);cv.height=Math.round(H*cvScale);
}
const silCache={};
function sil(key,color){
  const id=key+color;if(silCache[id])return silCache[id];
  const im=IMG[key];if(!im)return null;
  const c=document.createElement('canvas');c.width=im.width;c.height=im.height;
  const g=c.getContext('2d');g.drawImage(im,0,0);g.globalCompositeOperation='source-in';g.fillStyle=color;g.fillRect(0,0,c.width,c.height);
  return silCache[id]=c;
}
/* gambar sprite: x tengah, y kaki, h tinggi. sf = arah hadap bawaan gambar */
function drawSpr(key,x,y,h,face,sf,o){
  const im=IMG[key];if(!im)return;o=o||{};
  const s=h/im.height,w=im.width*s,pv=o.pv==null?.5:o.pv;
  cx.save();cx.translate(x+(o.dx||0),y+(o.dy||0)-h*pv);
  if(o.rot)cx.rotate(o.rot);
  const flip=(sf!==0&&face!==sf)?-1:1;
  cx.scale(flip*(o.sx||1),o.sy||1);
  if(o.alpha!=null)cx.globalAlpha=o.alpha;
  cx.drawImage(im,-w/2,-h*(1-pv),w,h);
  if(o.tint){const sc=sil(key,o.tint);if(sc){cx.globalAlpha=(o.alpha==null?1:o.alpha)*(o.ta||.6);cx.drawImage(sc,-w/2,-h*(1-pv),w,h)}}
  cx.restore();
}
function shadow(x,w,a){cx.fillStyle='rgba(0,0,0,'+(a||.45)+')';cx.beginPath();cx.ellipse(x,GROUND+3,w,Math.max(3,w*.13),0,0,6.283);cx.fill()}
function glow(x,y,r,col,a){
  const g=cx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,col);g.addColorStop(1,'rgba(0,0,0,0)');
  cx.save();cx.globalCompositeOperation='lighter';cx.globalAlpha=a==null?1:a;cx.fillStyle=g;cx.fillRect(x-r,y-r,r*2,r*2);cx.restore();
}
/* --- ember global (layer partikel layar) --- */
const EMB=[];
function initEmbers(){EMB.length=0;const n=[18,42,80][S.gfx]||40;for(let i=0;i<n;i++)EMB.push({x:rnd(0,W),y:rnd(0,H),vy:rnd(14,46),vx:rnd(-10,14),s:rnd(1,2.6),ph:rnd(0,6.28),z:rnd(.4,1.4)})}
function updEmbers(dt){for(const e of EMB){e.y-=e.vy*dt*e.z;e.x+=(e.vx+Math.sin(G.now*1.3+e.ph)*14)*dt;if(e.y<-8){e.y=H+8;e.x=rnd(0,W)}if(e.x>W+8)e.x=-8;if(e.x<-8)e.x=W+8}}
function drawEmbers(colr){
  cx.save();cx.globalCompositeOperation='lighter';
  for(const e of EMB){const a=.35+.35*Math.sin(G.now*3+e.ph);cx.fillStyle=colr||'rgba(255,140,60,'+a.toFixed(2)+')';cx.fillRect(e.x,e.y,e.s*e.z,e.s*e.z)}
  cx.restore();
}
/* --- background parallax --- */
function drawBgImage(camx,fac){
  const im=IMG[(G.map&&G.map.bg)||'bg_map1'];if(!im)return;
  const s=H/im.height,iw=im.width*s,off=Math.min(camx*fac,iw-W);
  cx.drawImage(im,-off,0,iw,H);
}
function drawFogLayer(camx,fac,y,a,col){
  if(S.gfx<1)return;
  cx.save();cx.globalAlpha=a;
  for(let i=-1;i<6;i++){
    const x=((i*380-camx*fac+G.now*8*fac)%(6*380))-380;
    const g=cx.createRadialGradient(x+190,y,0,x+190,y,260);g.addColorStop(0,col);g.addColorStop(1,'rgba(0,0,0,0)');
    cx.fillStyle=g;cx.fillRect(x-70,y-90,520,180);
  }
  cx.restore();
}
function drawGround(camx){
  const y0=GROUND-14;
  const g=cx.createLinearGradient(0,y0,0,H);g.addColorStop(0,'#452630');g.addColorStop(.1,'#28141c');g.addColorStop(1,'#0b0509');
  cx.fillStyle=g;cx.fillRect(0,y0,W,H-y0);
  cx.fillStyle='rgba(255,130,80,.6)';cx.fillRect(0,y0,W,2);
  cx.fillStyle='rgba(255,170,110,.10)';cx.fillRect(0,y0+2,W,4);
  cx.strokeStyle='rgba(0,0,0,.5)';cx.lineWidth=2;cx.beginPath();
  const step=130,off=-(camx%step);
  for(let x=off-step;x<W+step;x+=step){cx.moveTo(x,y0+3);cx.lineTo(x-30,H)}
  cx.moveTo(0,y0+26);cx.lineTo(W,y0+26);cx.moveTo(0,y0+54);cx.lineTo(W,y0+54);cx.stroke();
  cx.strokeStyle='rgba(255,120,80,.07)';cx.beginPath();cx.moveTo(0,y0+28);cx.lineTo(W,y0+28);cx.stroke();
}
function drawTorch(sx,v){
  const f=.5+.5*Math.sin(G.now*11+v*40);
  cx.fillStyle='#1a0f14';cx.fillRect(sx-4,GROUND-130,8,130);cx.fillRect(sx-12,GROUND-136,24,9);
  glow(sx,GROUND-150,110+f*16,'rgba(255,140,50,.55)',.55);
  glow(sx,GROUND-4,150,'rgba(255,110,40,.35)',.35*(.8+f*.2));
  cx.save();cx.translate(sx,GROUND-140);
  cx.fillStyle='#ff9a3a';cx.beginPath();cx.moveTo(-8,0);cx.quadraticCurveTo(-10,-16-f*6,0,-32-f*8);cx.quadraticCurveTo(10,-16-f*4,8,0);cx.closePath();cx.fill();
  cx.fillStyle='#ffe9a8';cx.beginPath();cx.moveTo(-4,0);cx.quadraticCurveTo(-5,-9,0,-17-f*4);cx.quadraticCurveTo(5,-9,4,0);cx.closePath();cx.fill();
  cx.restore();
}
function drawDecor(camx){
  for(const it of G.decor){
    const sx=it.x-camx;if(sx<-160||sx>W+160)continue;
    switch(it.t){
      case 'torch':drawTorch(sx,it.v);break;
      case 'banner':{
        cx.fillStyle='#180d12';cx.fillRect(sx-3,GROUND-210,6,210);cx.fillRect(sx-30,GROUND-212,64,6);
        const sw=Math.sin(G.now*1.6+it.v*9)*5;
        cx.fillStyle='#6d0f1b';cx.beginPath();cx.moveTo(sx-24,GROUND-206);cx.lineTo(sx+24,GROUND-206);cx.lineTo(sx+24+sw,GROUND-120);cx.lineTo(sx+sw*1.4,GROUND-136);cx.lineTo(sx-24+sw,GROUND-118);cx.closePath();cx.fill();
        cx.strokeStyle='rgba(230,200,170,.55)';cx.lineWidth=2;cx.beginPath();cx.moveTo(sx+sw*.3,GROUND-192);cx.lineTo(sx+sw*.5,GROUND-146);cx.moveTo(sx-10+sw*.3,GROUND-176);cx.lineTo(sx+10+sw*.5,GROUND-176);cx.stroke();
        break;}
      case 'ruin':{
        cx.fillStyle='#22141b';cx.fillRect(sx-46,GROUND-66,92,66);cx.fillRect(sx-30,GROUND-108,58,44);cx.fillRect(sx+6,GROUND-136,30,30);
        cx.fillStyle='rgba(255,140,80,.12)';cx.fillRect(sx-46,GROUND-66,92,3);cx.fillRect(sx-30,GROUND-108,58,3);
        cx.strokeStyle='rgba(0,0,0,.5)';cx.lineWidth=2;cx.beginPath();cx.moveTo(sx-46,GROUND-33);cx.lineTo(sx+46,GROUND-33);cx.moveTo(sx,GROUND-66);cx.lineTo(sx,GROUND-33);cx.stroke();
        break;}
      case 'barrels':{
        for(let i=0;i<2;i++){const bx=sx+i*34-17;cx.fillStyle='#3a2216';cx.fillRect(bx-14,GROUND-46,28,46);cx.fillStyle='#1a0f0a';cx.fillRect(bx-15,GROUND-36,30,4);cx.fillRect(bx-15,GROUND-14,30,4);cx.fillStyle='rgba(255,150,80,.14)';cx.fillRect(bx-14,GROUND-46,28,2)}
        break;}
    }
  }
}
function drawFg(camx){
  const f=1.35;
  for(const it of G.fg){
    const sx=it.x-camx*f;if(sx<-60||sx>W+60)continue;
    cx.fillStyle='#07030a';
    if(it.t==='post'){cx.fillRect(sx-14,-10,28,H+10);cx.fillRect(sx-24,H-96,48,10)}
    else{const sw=Math.sin(G.now*1.2+it.v*7)*7;cx.strokeStyle='#07030a';cx.lineWidth=5;cx.setLineDash([9,5]);cx.beginPath();cx.moveTo(sx,-4);cx.lineTo(sx+sw,110+it.v*90);cx.stroke();cx.setLineDash([]);cx.fillRect(sx+sw-9,104+it.v*90,18,18)}
  }
}
/* --- barrel, pickup --- */
function drawBarrel(b){
  if(b.broken)return;const sx=b.x;
  shadow(sx,26,.4);
  cx.fillStyle='#4a2c1a';cx.beginPath();cx.moveTo(sx-20,GROUND);cx.lineTo(sx-24,GROUND-28);cx.lineTo(sx-20,GROUND-56);cx.lineTo(sx+20,GROUND-56);cx.lineTo(sx+24,GROUND-28);cx.lineTo(sx+20,GROUND);cx.closePath();cx.fill();
  cx.fillStyle='#1c100a';cx.fillRect(sx-23,GROUND-46,46,5);cx.fillRect(sx-23,GROUND-14,46,5);
  cx.fillStyle='rgba(255,170,100,.2)';cx.fillRect(sx-19,GROUND-56,38,3);
}
function drawPickup(k){
  if(k.k==='gold'){glow(k.x,k.y,16,'rgba(255,200,60,.7)',.6);cx.fillStyle='#f2c14e';cx.beginPath();cx.arc(k.x,k.y,5,0,6.283);cx.fill();cx.fillStyle='#fff3b0';cx.fillRect(k.x-1,k.y-3,2,4)}
  else{const c=k.k==='hp'?'#ff4a5a':'#4a8dff';glow(k.x,k.y,22,c,.6);cx.fillStyle=c;cx.beginPath();cx.arc(k.x,k.y+2,7,0,6.283);cx.fill();cx.fillStyle='#d9c9a0';cx.fillRect(k.x-2,k.y-11,4,6)}
}
/* --- karakter --- */
function smearRig(name,x,y,h,face,pose,col,n,step,a0){
  for(let i=1;i<=n;i++){const P2=JSON.parse(JSON.stringify(pose));P2.g.dx=(P2.g.dx||0)+step*i;drawRig(name,x,y,h,face,P2,{alpha:a0/i,tint:col,ta:.85})}
}
function drawPlayer(){
  const p=P,c=p.c,h=c.sprH*SC,t=p.anim;
  shadow(p.x,38*(1-Math.min(.5,(GROUND-p.y)/260)),.5);
  if(!p.dead)glow(p.x,GROUND-6,105,'rgba(200,20,40,.5)',.28+.05*Math.sin(t*4));
  const blink=p.inv>0&&!p.dead&&p.state!=='ult'&&Math.floor(p.inv*24)%2===0&&p.state!=='dash';
  if(p.state==='ult'&&p.stateT<.55)glow(p.x,p.y-80,170+p.stateT*160,'rgba(255,30,50,.7)',.6);
  if(framesReady()){
    const fr=slayerFrame(p),opt=fr.o;
    opt.alpha=blink?.45:1;
    if(p.flash>0){opt.tint='#ffffff';opt.ta=.75}else if(p.slowT>0){opt.tint='#9fb6d6';opt.ta=.35}
    drawFrame(fr.a,fr.i,p.x,p.y,p.face,opt);
    if(p.state==='atk'&&p.cur&&(p.cur.heavy||p.cur.glow)&&p.stateT>p.cur.hit[0]-.02&&p.stateT<p.cur.hit[1]+.06)glow(p.x+p.face*80,p.y-70,130,'rgba(255,40,60,.7)',.5);
    return;
  }
  for(const g of p.ghosts)drawSpr(c.sprite,g.x,g.y,h,g.face,c.sprFace,{rot:g.face*.36,sy:.9,sx:1.12,alpha:Math.max(0,g.a)*.7,tint:'#a3121f',ta:.9});
  const pose=poseSlayer(p),opt={alpha:blink?.45:1,tint:p.flash>0?'#ffffff':(p.slowT>0?'#9fb6d6':null),ta:p.flash>0?.75:.35};
  const striking=(p.state==='atk'&&p.cur&&p.stateT>=p.cur.hit[0]-.03&&p.stateT<=p.cur.hit[1]+.09)||p.state==='dash'||(p.state==='ult'&&p.stateT>.5);
  if(striking&&!blink)smearRig('slayer',p.x,p.y,h,p.face,pose,'#ff2a3a',2,p.state==='dash'?22:12,.32);
  if(!drawRig('slayer',p.x,p.y,h,p.face,pose,opt))drawSpr(c.sprite,p.x,p.y,h,p.face,c.sprFace,{alpha:opt.alpha});
}
function drawEnemy(e){
  const d=e.def,h=d.h*SC;
  const alpha=e.dead?Math.max(0,1-e.deathT/1.2):e.alpha;
  if(alpha<=0)return;
  if(d.fly)shadow(e.x,d.bw*.6*(1-Math.min(.6,(GROUND-e.y)/250)),.3);else shadow(e.x,d.bw*(d.boss?.9:.7),.45);
  if(d.boss&&!e.dead){glow(e.x,e.y-d.bh*.5,200+(e.phase===2?70:0),e.phase===2?'rgba(255,30,40,.75)':'rgba(190,20,30,.5)',.55+.1*Math.sin(G.now*5))}
  for(const g of e.gh)drawSpr(d.spr,g.x,g.y,h,g.face,d.sf,{alpha:Math.max(0,g.a)*.6,tint:d.boss?'#ff2a2a':'#8fa0d8',ta:.85});
  if(e.elite&&!e.dead)drawSpr(d.spr,e.x,e.y,h*1.07,e.face,d.sf,{alpha:.5*alpha,tint:'#ffcf3a',ta:1});
  let tint=null,ta=0;
  if(e.flash>0){tint='#ffffff';ta=d.boss?.5:.8}
  else if(e.state==='wind'){tint='#ff2a2a';ta=(d.boss?.10:.08)+(d.boss?.16:.2)*Math.abs(Math.sin(G.now*22))}
  else if(d.boss&&e.phase===2){tint='#ff1a2a';ta=.14+.08*Math.sin(G.now*6)}
  if(RIGS[d.spr]){
    const pose=d.spr==='gargoyle'?poseGargoyle(e):poseHumanoid(e);
    if(!e.dead&&e.state==='act'&&e.curAtk&&e.curAtk.kind==='melee'&&e.t<.18)smearRig(d.spr,e.x,e.y,h,e.face,pose,d.boss?'#ff2a3a':'#c8d0e0',2,10,.28);
    drawRig(d.spr,e.x,e.y,h,e.face,pose,{alpha,tint,ta});
  }else{
    const wp=warpFor(e),g=wp[0],o=wp[1];o.tint=tint;o.ta=ta;o.alpha=alpha*(o.alpha==null?1:o.alpha);
    drawWarp(d.spr,e.x,e.y,h,e.face,d.sf,g,o);
  }
  if(!e.dead&&e.state==='wind'&&!d.boss){
    cx.fillStyle='#ff3a3a';cx.font='bold 24px Georgia,serif';cx.textAlign='center';cx.fillText('!',e.x,e.y-h-6-Math.sin(G.now*20)*2);
  }
  if(!e.dead&&!d.boss&&e.hp<e.maxhp){
    const w=Math.max(40,d.bw+8),bx=e.x-w/2,by=e.y-h-(d.fly?2:-2)-14;
    cx.fillStyle='rgba(0,0,0,.65)';cx.fillRect(bx-1,by-1,w+2,7);cx.fillStyle=e.elite?'#ffcf3a':'#d1303a';cx.fillRect(bx,by,w*Math.max(0,e.hp/e.maxhp),5);
  }
  if(d.boss&&e.state==='act'&&e.curAtk&&e.curAtk.kind==='spin'){
    cx.save();cx.globalCompositeOperation='lighter';cx.strokeStyle='rgba(255,50,60,.8)';cx.lineWidth=8;
    for(let i=0;i<2;i++){cx.beginPath();cx.ellipse(e.x,e.y-70,e.curAtk.rad,e.curAtk.rad*.35,0,e.t*18+i*3.14,e.t*18+i*3.14+2.2);cx.stroke()}
    cx.restore();
  }
}
/* --- efek --- */
function drawFxWorld(){
  for(const f of FX){
    const k=f.age/f.life;
    switch(f.t){
      case 'slash':{
        const sweep=Math.min(1,k*2.4),fade=1-Math.pow(k,1.5),n=14,th=f.w*1.7;
        cx.save();cx.translate(f.x,f.y);cx.scale(f.face,1);cx.globalCompositeOperation='lighter';
        for(let pass=0;pass<2;pass++){
          const T2=pass?th*.35:th;cx.beginPath();
          for(let i=0;i<=n;i++){const t=i/n,a=f.a0+(f.a1-f.a0)*t*sweep;cx.lineTo(Math.cos(a)*f.r,Math.sin(a)*f.r)}
          for(let i=n;i>=0;i--){const t=i/n,a=f.a0+(f.a1-f.a0)*t*sweep,tk=Math.sin(Math.PI*t)*T2,rr=f.r-tk;cx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr)}
          cx.closePath();cx.fillStyle=pass?'#ffffff':f.col;cx.globalAlpha=pass?fade:fade*.85;cx.fill();
        }
        cx.restore();break}
      case 'ring':{
        const r=lerp(f.r0,f.r1,1-Math.pow(1-k,2));cx.save();cx.globalCompositeOperation='lighter';cx.strokeStyle=f.col;cx.globalAlpha=1-k;cx.lineWidth=f.w*(1-k);
        cx.beginPath();cx.ellipse(f.x,f.y,r,r*.32,0,0,6.283);cx.stroke();cx.restore();break}
      case 'tele':{
        const pulse=.25+.2*Math.sin(G.now*18);cx.save();
        cx.fillStyle='rgba(170,60,255,'+(.16+pulse*.4)+')';cx.strokeStyle='rgba(200,120,255,.9)';cx.lineWidth=2;
        cx.beginPath();cx.ellipse(f.x,GROUND-2,f.r,f.r*.3,0,0,6.283);cx.fill();cx.setLineDash([8,6]);cx.stroke();cx.restore();break}
      case 'lane':{
        const a=.14+.14*Math.sin(G.now*20);cx.fillStyle='rgba(255,40,40,'+a+')';
        cx.fillRect(f.face>0?f.x:f.x-f.len,GROUND-56,f.len,54);break}
      case 'pillar':{
        const g=cx.createLinearGradient(0,GROUND-420,0,GROUND);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,f.col);
        cx.save();cx.globalCompositeOperation='lighter';cx.globalAlpha=1-k;cx.fillStyle=g;const w=70*(1-k*.5);cx.fillRect(f.x-w/2,GROUND-420,w,420);cx.restore();break}
      case 'ultslash':{
        cx.save();cx.globalCompositeOperation='lighter';cx.lineCap='round';const fade=1-k,w=46*(1-k*.7);
        for(const s of [-1,1]){
          const g=cx.createLinearGradient(f.x-560,0,f.x+560,0);g.addColorStop(0,'rgba(255,30,50,0)');g.addColorStop(.5,'rgba(255,255,255,'+fade+')');g.addColorStop(1,'rgba(255,30,50,0)');
          cx.strokeStyle=g;cx.lineWidth=w;cx.beginPath();cx.moveTo(f.x-560,f.y-190*s);cx.lineTo(f.x+560,f.y+130*s);cx.stroke();
          cx.strokeStyle='rgba(255,30,50,'+fade*.5+')';cx.lineWidth=w*2;cx.stroke();
        }
        cx.restore();glow(f.x,f.y,340*(1-k*.5),'rgba(255,30,50,.8)',fade);break}
    }
  }
}
function drawProj(){
  for(const q of PR){
    cx.save();cx.translate(q.x,q.y);
    switch(q.kind){
      case 'orb':cx.restore();glow(q.x,q.y,q.r*3.2,q.col,.9);cx.fillStyle='#fff';cx.beginPath();cx.arc(q.x,q.y,q.r*.5,0,6.283);cx.fill();continue;
      case 'bone':cx.rotate(q.rot);cx.fillStyle=q.col;cx.fillRect(-9,-2.5,18,5);cx.fillRect(-11,-5,4,10);cx.fillRect(7,-5,4,10);break;
      case 'web':cx.strokeStyle='#e6ecf6';cx.lineWidth=2;cx.rotate(q.rot*.3);cx.beginPath();for(let i=0;i<4;i++){cx.moveTo(0,0);cx.lineTo(Math.cos(i*.785)*q.r*1.4,Math.sin(i*.785)*q.r*1.4);cx.moveTo(0,0);cx.lineTo(-Math.cos(i*.785)*q.r*1.4,-Math.sin(i*.785)*q.r*1.4)}cx.stroke();cx.beginPath();cx.arc(0,0,q.r*.8,0,6.283);cx.stroke();break;
      case 'crescent':{
        cx.scale(q.vx>=0?1:-1,1);cx.globalCompositeOperation='lighter';
        const R=q.hh*1.05;cx.fillStyle=q.col;cx.globalAlpha=.9;cx.beginPath();cx.arc(-R*.55,0,R,-1.1,1.1);cx.arc(-R*.2,0,R*.86,1.1,-1.1,true);cx.closePath();cx.fill();
        cx.fillStyle='#fff';cx.globalAlpha=.75;cx.beginPath();cx.arc(-R*.5,0,R*.94,-.9,.9);cx.arc(-R*.28,0,R*.86,.9,-.9,true);cx.closePath();cx.fill();
        cx.restore();glow(q.x,q.y,q.hh*1.6,q.col,.5);continue}
      case 'shock':{
        cx.globalCompositeOperation='lighter';cx.fillStyle=q.col;cx.globalAlpha=.85;cx.beginPath();cx.moveTo(-26,26);cx.lineTo(-12,-8);cx.lineTo(0,-30);cx.lineTo(12,-8);cx.lineTo(26,26);cx.closePath();cx.fill();break}
    }
    cx.restore();
  }
}
function drawParticles(){
  for(let pass=0;pass<2;pass++){
    cx.save();if(pass===1)cx.globalCompositeOperation='lighter';
    for(const p of PT){
      if(!p.on||(p.add?1:0)!==pass)continue;
      const a=p.life/p.max;cx.globalAlpha=Math.min(1,a*1.6);cx.fillStyle=p.color;const s=p.size*(.4+.6*a);cx.fillRect(p.x-s/2,p.y-s/2,s,s);
    }
    cx.restore();
  }
}
function drawFloaters(){
  cx.textAlign='center';cx.lineJoin='round';
  for(const f of FL){
    const a=f.t<.6?1:1-(f.t-.6)/.3,sc=f.big?1+Math.max(0,.4-f.t)*1.4:1;
    cx.globalAlpha=Math.max(0,a);cx.font='bold '+Math.round((f.big?26:17)*sc)+'px Georgia,serif';
    cx.lineWidth=4;cx.strokeStyle='rgba(0,0,0,.85)';cx.strokeText(f.text,f.x,f.y);cx.fillStyle=f.col;cx.fillText(f.text,f.x,f.y);
  }
  cx.globalAlpha=1;
}
/* --- vignette --- */
let vigCv=null;
function vignette(a,col){
  if(!vigCv||vigCv.width!==W){vigCv=document.createElement('canvas');vigCv.width=W;vigCv.height=H;const g=vigCv.getContext('2d'),r=g.createRadialGradient(W/2,H/2,H*.35,W/2,H/2,H*.95);r.addColorStop(0,'rgba(0,0,0,0)');r.addColorStop(1,'rgba(0,0,0,.85)');g.fillStyle=r;g.fillRect(0,0,W,H)}
  cx.globalAlpha=a;cx.drawImage(vigCv,0,0);cx.globalAlpha=1;
}
/* --- dunia --- */
function drawWorld(){
  const c=G.cam;
  cx.fillStyle='#0a0508';cx.fillRect(0,0,W,H);
  cx.save();
  const ox=(Math.random()-.5)*c.shake*2,oy=(Math.random()-.5)*c.shake*2;
  const pvx=clamp(P.x-c.x,240,720),pvy=380;
  cx.translate(pvx+ox,pvy+oy);cx.scale(c.zoom,c.zoom);cx.translate(-pvx,-pvy);
  drawBgImage(c.x,.22);
  cx.fillStyle='rgba(20,0,20,.18)';cx.fillRect(0,0,W,H);
  drawFogLayer(c.x,.45,GROUND-40,.16,'rgba(200,80,60,.55)');
  drawEmbers();
  drawDecor(c.x);
  drawGround(c.x);
  cx.save();cx.translate(-c.x,0);
  for(const b of BR)drawBarrel(b);
  for(const k of PK)drawPickup(k);
  const list=E.slice().sort((a,b)=>a.y-b.y);
  for(const e of list)drawEnemy(e);
  drawPlayer();
  drawProj();drawFxWorld();drawParticles();drawFloaters();
  cx.restore();
  drawFogLayer(c.x,1.1,GROUND+20,.10,'rgba(120,40,60,.5)');
  drawFg(c.x);
  cx.restore();
  vignette(.9);
  if(G.dark>0){cx.fillStyle='rgba(20,0,10,'+G.dark+')';cx.fillRect(0,0,W,H);if(P.state==='ult'){/* pusatkan sorot */}}
  if(G.redA>0){cx.fillStyle='rgba(200,0,20,'+(G.redA*.45)+')';cx.fillRect(0,0,W,H)}
  if(P&&P.hp/P.maxhp<.25&&!P.dead){const a=.12+.1*Math.sin(G.now*6);cx.fillStyle='rgba(180,0,20,'+a+')';cx.fillRect(0,0,W,H)}
  if(G.flashA>0){cx.fillStyle=G.flashCol;cx.globalAlpha=Math.min(1,G.flashA);cx.fillRect(0,0,W,H);cx.globalAlpha=1}
  drawHUD();
}
/* --- HUD --- */
const HUDT={hp:1,boss:1};
function bar(x,y,w,h,frac,c0,c1,trail){
  cx.fillStyle='rgba(8,4,8,.85)';cx.fillRect(x-1,y-1,w+2,h+2);
  if(trail!=null){cx.fillStyle='rgba(255,230,200,.8)';cx.fillRect(x,y,w*clamp(trail,0,1),h)}
  const g=cx.createLinearGradient(x,y,x,y+h);g.addColorStop(0,c0);g.addColorStop(1,c1);cx.fillStyle=g;cx.fillRect(x,y,w*clamp(frac,0,1),h);
  cx.fillStyle='rgba(255,255,255,.14)';cx.fillRect(x,y,w*clamp(frac,0,1),Math.max(1,h*.3));
  cx.strokeStyle='rgba(201,162,77,.7)';cx.lineWidth=1;cx.strokeRect(x-1.5,y-1.5,w+3,h+3);
}
function setFont(px,w,ls){cx.font=(w||'bold')+' '+px+'px "Palatino Linotype","Book Antiqua",Palatino,Georgia,serif';try{cx.letterSpacing=(ls||0)+'px'}catch(e){}}
function drawHUD(){
  const p=P,c=p.c,cs=SV.chars[p.cid];
  HUDT.hp=lerp(HUDT.hp,p.hp/p.maxhp,.07);
  // portrait
  const px=14,py=12,ps=70;
  cx.save();cx.beginPath();cx.arc(px+ps/2,py+ps/2,ps/2,0,6.283);cx.clip();
  const fi=IMG[c.face];if(fi)cx.drawImage(fi,0,0,fi.width,fi.height,px,py,ps,ps);
  cx.restore();
  cx.strokeStyle='#c9a24d';cx.lineWidth=2.5;cx.beginPath();cx.arc(px+ps/2,py+ps/2,ps/2,0,6.283);cx.stroke();
  cx.strokeStyle='rgba(120,20,30,.9)';cx.lineWidth=1.5;cx.beginPath();cx.arc(px+ps/2,py+ps/2,ps/2+3.5,0,6.283);cx.stroke();
  const bx=px+ps+14;
  cx.textAlign='left';setFont(16,'bold',2);cx.fillStyle='#eadfca';cx.strokeStyle='rgba(0,0,0,.8)';cx.lineWidth=3;
  const nm=c.name.toUpperCase(),nw=cx.measureText(nm).width;cx.strokeText(nm,bx,py+14);cx.fillText(nm,bx,py+14);
  setFont(13,'bold',0);cx.fillStyle='#d8b45c';const lt='Lv.'+p.lv;cx.strokeText(lt,bx+nw+10,py+14);cx.fillText(lt,bx+nw+10,py+14);
  bar(bx,py+22,200,15,p.hp/p.maxhp,'#ff4a4a','#9c1220',HUDT.hp);
  setFont(11,'bold',0);cx.fillStyle='#fff';cx.fillText(Math.ceil(p.hp)+' / '+p.maxhp,bx+7,py+34);
  bar(bx,py+43,200,10,p.mp/p.maxmp,'#5aa0ff','#1f4fb0');
  const need=expNeed(cs.lv);bar(bx,py+59,200,6,cs.lv>=MAXLV?1:cs.exp/need,'#f2d27a','#a8812a');
  const rdy=p.rage>=100&&skillUnlocked('ult');
  bar(bx,py+70,140,5,p.rage/100,rdy?'#ff8a8a':'#d12a3a',rdy?'#ff2233':'#661018');
  if(rdy){setFont(11,'bold',1.5);cx.fillStyle='rgba(255,90,100,'+(.6+.4*Math.sin(G.now*8))+')';cx.fillText('ULT',bx+148,py+76)}
  // kanan atas
  cx.textAlign='right';setFont(18,'bold',0);
  const rx=W-78;
  cx.fillStyle='#f2c14e';cx.beginPath();cx.arc(rx-cx.measureText(String(SV.gold)).width-14,30,8,0,6.283);cx.fill();
  cx.fillStyle='#fff3b0';cx.strokeStyle='rgba(0,0,0,.8)';cx.lineWidth=3;cx.strokeText(String(SV.gold),rx,36);cx.fillText(String(SV.gold),rx,36);
  const cw=cx.measureText(String(SV.crystal)).width;
  cx.fillStyle='#b06bff';cx.beginPath();const cxx=rx-cw-14,cyy=58;cx.moveTo(cxx,cyy-9);cx.lineTo(cxx+7,cyy);cx.lineTo(cxx,cyy+9);cx.lineTo(cxx-7,cyy);cx.closePath();cx.fill();
  cx.fillStyle='#e4ccff';cx.strokeText(String(SV.crystal),rx,64);cx.fillText(String(SV.crystal),rx,64);
  // combo
  if(G.combo>=2){
    const k=Math.min(1,G.comboT/2.4),pop=1+Math.max(0,.15-(2.4-G.comboT))*3;
    cx.textAlign='right';cx.globalAlpha=.4+.6*k;setFont(Math.round(44*pop),'bold',0);cx.lineWidth=5;cx.strokeStyle='rgba(0,0,0,.85)';cx.fillStyle=G.combo>=10?'#ff5a5a':'#ffd58a';
    cx.strokeText(String(G.combo),W-24,190);cx.fillText(String(G.combo),W-24,190);
    setFont(14,'bold',3);cx.lineWidth=3;cx.fillStyle='#eadfca';cx.strokeText('COMBO',W-26,210);cx.fillText('COMBO',W-26,210);cx.globalAlpha=1;
  }
  // boss
  const b=G.bossRef;
  if(b&&G.lock&&G.stage&&G.stage.boss&&(!b.dead||b.deathT<1.6)){
    const fr=Math.max(0,b.hp/b.maxhp);HUDT.boss=lerp(HUDT.boss,fr,.06);
    const w=340,x=(W-w)/2+6,y=44;
    cx.textAlign='center';setFont(17,'bold',5);cx.lineWidth=4;cx.strokeStyle='rgba(0,0,0,.9)';cx.fillStyle='#f0d8c0';
    cx.strokeText(b.def.name.toUpperCase(),W/2+6,y-10);cx.fillText(b.def.name.toUpperCase(),W/2+6,y-10);
    bar(x,y,w,16,fr,'#ff3a3a','#7a0a14',HUDT.boss);
    cx.fillStyle='rgba(255,255,255,.6)';cx.fillRect(x+w/2-1,y-4,2,24);
    setFont(11,'bold',2);cx.textAlign='right';cx.fillStyle='#d8b45c';cx.fillText('PHASE '+b.phase,x+w,y+34);
  }
  // banner
  if(G.banner){
    const t=G.banner.t,a=t<.4?t/.4:t>2.1?Math.max(0,1-(t-2.1)/.5):1;
    cx.save();cx.globalAlpha=a;cx.textAlign='center';setFont(46,'bold',10);cx.lineWidth=6;cx.strokeStyle='rgba(0,0,0,.9)';cx.fillStyle='#f3dcc0';
    const y=170+(1-Math.min(1,t/.4))*14;cx.strokeText(G.banner.text,W/2,y);cx.fillText(G.banner.text,W/2,y);
    cx.fillStyle='rgba(200,30,40,.9)';cx.fillRect(W/2-150,y+14,300,2);
    setFont(15,'normal',3);cx.lineWidth=3;cx.fillStyle='#d8b45c';cx.strokeText(G.banner.sub,W/2,y+40);cx.fillText(G.banner.sub,W/2,y+40);cx.restore();
  }
  if(G.phaseTxt){
    const t=G.phaseTxt.t,a=t<.2?t/.2:Math.max(0,1-(t-1.4)/.8),sc=1+Math.max(0,.4-t)*1.2;
    cx.save();cx.globalAlpha=a;cx.textAlign='center';setFont(Math.round(78*sc),'bold',14);cx.lineWidth=8;cx.strokeStyle='rgba(0,0,0,.9)';cx.fillStyle='#ff2b3a';
    cx.strokeText(G.phaseTxt.text,W/2,H/2-10);cx.fillText(G.phaseTxt.text,W/2,H/2-10);cx.restore();
  }
  if(G.goHint>0&&!G.lock&&!G.bossDown){
    const a=.5+.5*Math.sin(G.now*7);cx.textAlign='right';setFont(30,'bold',4);cx.fillStyle='rgba(255,220,150,'+a+')';cx.strokeStyle='rgba(0,0,0,.8)';cx.lineWidth=4;
    cx.strokeText('GO ▶',W-100,H/2-40);cx.fillText('GO ▶',W-100,H/2-40);
  }
  try{cx.letterSpacing='0px'}catch(e){}
}
/* --- latar menu (dipakai semua layar di luar gameplay) --- */
function drawMenuBg(){
  const im=IMG.bg_map1;cx.fillStyle='#0a0508';cx.fillRect(0,0,W,H);
  if(im){const s=H/im.height,iw=im.width*s,off=(iw-W)*(.5+.5*Math.sin(G.now*.06+1.2));cx.drawImage(im,-off,0,iw,H)}
  cx.fillStyle='rgba(15,0,10,'+(G.scene==='menu'?.28:.6)+')';cx.fillRect(0,0,W,H);
  drawFogLayer(G.now*30,.6,H-90,.2,'rgba(220,80,60,.5)');
  drawEmbers();
  if(G.scene==='menu'){
    const c=DATA.chars.slayer,t=G.now,by=Math.sin(t*3.2)*.014;
    glow(230,H-40,240,'rgba(210,20,40,.55)',.5+.1*Math.sin(t*2));
    cx.fillStyle='rgba(0,0,0,.5)';cx.beginPath();cx.ellipse(230,H-30,110,14,0,0,6.283);cx.fill();
    if(framesReady())drawFrame('atk1',1,230,H-30,1,{sc:1.55,sy:1+by,sx:1-by*.5});else drawSpr(c.sprite,230,H-30,340,1,c.sprFace,{sy:1+by,sx:1-by*.5,pv:0});
    if(Math.random()<.4*pmul())spark(230+rnd(-70,70),H-40-rnd(0,320),rnd(-10,10),rnd(-80,-30),1.1,rnd(1.5,3),'#ff2a3a',0,1);
    drawParticles();
  }
  vignette(.95);
}
