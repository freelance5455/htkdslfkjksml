import { useEffect, useState } from 'react';
import type { Product, ShopSession, StoreData } from './types';

export const STORAGE_KEY = 'mystore_pos_v1_data';
export const CURRENCY = '৳';

export const normalizeCode = (raw: string | undefined | null): string =>
  String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, '');

export const findProductByBarcodeOrSku = (products: Product[], rawCode: string): Product | undefined => {
  const exact = rawCode.trim().toLowerCase();
  if (!exact) return undefined;
  const compact = normalizeCode(rawCode);
  const stripped = compact.replace(/^0+/, '');

  // Priority 1: Exact barcode or SKU match
  const exactMatch = products.find(
    (p) => (p.barcode || '').trim().toLowerCase() === exact || (p.sku || '').trim().toLowerCase() === exact
  );
  if (exactMatch) return exactMatch;

  // Priority 2: Normalized / leading-zero-stripped match (EAN-13 <-> UPC-A)
  return products.find((p) => {
    const pb = normalizeCode(p.barcode);
    const ps = normalizeCode(p.sku);
    if (pb === compact || ps === compact) return true;
    if (stripped.length >= 4) {
      if ((pb && pb.replace(/^0+/, '') === stripped) || (ps && ps.replace(/^0+/, '') === stripped)) return true;
    }
    return false;
  });
};

export const uid = (): string => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

export const fmtMoney = (n: number | string | undefined | null): string => {
  const val = Number(n || 0);
  return `${CURRENCY}${val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

export const fmtInt = (n: number | undefined | null): string => Number(n || 0).toLocaleString('en-US');

export const toDateKey = (isoOrDate: string | number | Date): string => {
  const d = new Date(isoOrDate);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
};

export const fmtDateLabel = (dateKey: string): string => {
  const [y, m, d] = dateKey.split('-').map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  return dt.toLocaleDateString('en-US', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
};

export const fmtDateTime = (iso?: string): string => {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const fmtTimeOnly = (iso?: string): string => {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
};

export const fmtDuration = (ms: number): string => {
  const totalSec = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
};

export const fmtHoursMinutes = (ms: number): string => {
  const totalMin = Math.max(0, Math.floor(ms / 60000));
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h === 0) return `${m}m`;
  return `${h}h ${m}m`;
};

export const formatLiveClock = (
  nowMs: number,
  options: {
    clockFormat?: '12h' | '24h';
    clockShowSeconds?: boolean;
    clockShowDate?: boolean;
    clockOffsetMinutes?: number;
  }
): { timeText: string; dateText: string } => {
  const offsetMs = (options.clockOffsetMinutes || 0) * 60000;
  const d = new Date(nowMs + offsetMs);
  const hour12 = (options.clockFormat || '12h') === '12h';
  const showSec = options.clockShowSeconds !== false;

  const timeText = d.toLocaleTimeString('en-US', {
    hour12,
    hour: '2-digit',
    minute: '2-digit',
    ...(showSec ? { second: '2-digit' } : {}),
  });

  const dateText =
    options.clockShowDate !== false
      ? d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })
      : '';

  return { timeText, dateText };
};

export const useNowMs = (active = true, intervalMs = 1000): number => {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!active) return;
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(id);
  }, [active, intervalMs]);
  return now;
};

/**
 * Splits a ShopSession across midnight (24-hour boundary) so every completed calendar day
 * archives accurately into Time Analysis.
 */
export const splitSessionByDay = (openedIso: string, closedIso: string): ShopSession[] => {
  const start = new Date(openedIso);
  const end = new Date(closedIso);
  if (end.getTime() <= start.getTime()) return [];

  const result: ShopSession[] = [];
  let cursor = new Date(start.getTime());

  while (cursor.getTime() < end.getTime()) {
    const dayEnd = new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate(), 23, 59, 59, 999);
    const segmentEnd = end.getTime() <= dayEnd.getTime() ? end : dayEnd;
    const durationMs = Math.max(0, segmentEnd.getTime() - cursor.getTime());
    result.push({
      id: uid(),
      openedAt: cursor.toISOString(),
      closedAt: segmentEnd.toISOString(),
      durationMs,
      dateKey: toDateKey(cursor),
    });
    if (segmentEnd.getTime() >= end.getTime()) break;
    cursor = new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() + 1, 0, 0, 0, 0);
  }

  return result;
};

export const DEFAULT_DATA: StoreData = {
  settings: {
    storeName: 'My Store',
    storePhone: '',
    storeLogo: '',
    language: 'en',
    defaultLowStockLimit: 5,
    receiptHeader: 'Quality Products · Best Service',
    receiptFooter: 'Thank you for shopping with us! Goods once sold cannot be returned without receipt.',
    showClock: true,
    clockFormat: '12h',
    clockShowSeconds: true,
    clockShowDate: true,
    clockOffsetMinutes: 0,
    defaultWalkInName: 'Walk-in Customer',
    defaultCustomerId: 'walk-in',
    allowCreditSales: true,
    showCustomerPhoneOnReceipt: true,
  },
  categories: [
    { id: 'cat-1', name: 'Electronics', models: ['Standard', 'Pro', 'Mini', 'Wireless'] },
    { id: 'cat-2', name: 'Mobile & Gadgets', models: ['Android', 'iPhone', 'Adapter', 'Powerbank'] },
    { id: 'cat-3', name: 'Groceries', models: ['250g', '500g', '1kg', '5kg'] },
    { id: 'cat-4', name: 'Cosmetics', models: ['Cream', 'Lotion', 'Perfume', 'Serum', 'Facewash'] },
    { id: 'cat-5', name: 'Accessories', models: ['Black', 'White', 'Type-C', 'Universal'] },
    { id: 'cat-6', name: 'Beverages & Snacks', models: ['250ml', '500ml', '1L', 'Pack'] },
    { id: 'cat-7', name: 'Fashion & Clothing', models: ['S', 'M', 'L', 'XL', 'Free Size'] },
    { id: 'cat-8', name: 'Footwear & Bags', models: ['39', '40', '41', '42', 'Standard'] },
    { id: 'cat-9', name: 'Stationery & Books', models: ['Piece', 'Pack', 'Box', 'A4'] },
    { id: 'cat-10', name: 'Household & Cleaning', models: ['250ml', '500ml', '1L', 'Pack'] },
    { id: 'cat-11', name: 'Health & Pharmacy', models: ['Strip', 'Bottle', 'Box', '100ml'] },
    { id: 'cat-12', name: 'Personal Care & Hygiene', models: ['50g', '100g', '200ml', 'Family Pack'] },
    { id: 'cat-13', name: 'Hardware & Tools', models: ['Small', 'Medium', 'Large', 'Heavy Duty'] },
    { id: 'cat-14', name: 'Electrical & Lighting', models: ['5W', '12W', '20W', 'Heavy'] },
    { id: 'cat-15', name: 'Kitchen & Homeware', models: ['Set', 'Piece', 'Steel', 'Plastic'] },
    { id: 'cat-16', name: 'Baby & Kids', models: ['Newborn', 'Small', 'Medium', 'Large'] },
    { id: 'cat-17', name: 'Bakery & Dairy', models: ['Fresh', '250g', '500g', '1L'] },
    { id: 'cat-18', name: 'Frozen & Meat', models: ['500g', '1kg', 'Pack'] },
    { id: 'cat-19', name: 'Fruits & Vegetables', models: ['500g', '1kg', '2kg', 'Dozen'] },
    { id: 'cat-20', name: 'Toys & Gifts', models: ['Small', 'Medium', 'Large', 'Gift Box'] },
    { id: 'cat-21', name: 'Sports & Fitness', models: ['Standard', 'Pro', 'Pair'] },
    { id: 'cat-22', name: 'Jewelry & Watches', models: ['Classic', 'Gold Plated', 'Silver'] },
    { id: 'cat-23', name: 'Pet Supplies', models: ['500g', '1kg', 'Pack'] },
    { id: 'cat-24', name: 'Automotive & Bike', models: ['Standard', '1L', 'Universal'] },
  ],
  recentCategories: [],
  categoriesSeededV3: true,
  products: [
    {
      id: 'prod-1',
      name: 'Wireless Bluetooth Earbuds',
      sku: 'EL-1001',
      barcode: '8901001001',
      category: 'Electronics',
      model: 'Pro',
      purchasePrice: 850,
      sellingPrice: 1350,
      quantity: 18,
      minStock: 5,
      supplier: 'TechLink BD',
      notes: 'ANC supported',
    },
    {
      id: 'prod-2',
      name: 'Fast Charger 25W Adapter',
      sku: 'AC-2004',
      barcode: '8901001002',
      category: 'Accessories',
      model: 'Type-C',
      purchasePrice: 420,
      sellingPrice: 690,
      quantity: 4,
      minStock: 5,
      supplier: 'Gadget Hub',
      notes: 'PD fast charging',
    },
    {
      id: 'prod-3',
      name: 'Premium Basmati Rice',
      sku: 'GR-3010',
      barcode: '8901001003',
      category: 'Groceries',
      model: '1kg',
      purchasePrice: 135,
      sellingPrice: 175,
      quantity: 42,
      minStock: 10,
      supplier: 'Fresh Agro',
      notes: 'Aged long grain',
    },
    {
      id: 'prod-4',
      name: 'USB-C Braided Cable',
      sku: 'AC-2009',
      barcode: '8901001004',
      category: 'Accessories',
      model: 'Black',
      purchasePrice: 120,
      sellingPrice: 250,
      quantity: 3,
      minStock: 6,
      supplier: 'Gadget Hub',
      notes: '1.5m durable',
    },
  ],
  customers: [
    { id: 'walk-in', name: 'Walk-in Customer', phone: '-', address: '-', dueBalance: 0, totalSpent: 0, isDefault: true },
    { id: 'cust-1', name: 'Rahim Ahmed', phone: '01711-000111', address: 'Dhanmondi, Dhaka', dueBalance: 350, totalSpent: 2050 },
  ],
  suppliers: [
    { id: 'sup-1', name: 'Karim Traders', company: 'TechLink BD', phone: '01811-223344', address: 'Elephant Road, Dhaka', duePayable: 4500 },
    { id: 'sup-2', name: 'Hasan Enterprise', company: 'Gadget Hub', phone: '01911-556677', address: 'Gulistan, Dhaka', duePayable: 0 },
  ],
  expenses: [
    { id: 'exp-1', date: new Date().toISOString(), title: 'Shop Electricity Bill', category: 'Electricity', amount: 1200, paymentMethod: 'bKash', notes: 'Monthly meter bill' },
  ],
  sales: [],
  movements: [],
  shopSessions: [],
  activeSession: null,
};

export const loadInitialState = (): StoreData => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_DATA;
    const parsed = JSON.parse(raw);
    const merged: StoreData = { ...DEFAULT_DATA, ...parsed };
    merged.settings = { ...DEFAULT_DATA.settings, ...(parsed.settings || {}), language: 'en' };
    merged.expenses = Array.isArray(parsed.expenses) ? parsed.expenses : DEFAULT_DATA.expenses;
    merged.suppliers = Array.isArray(parsed.suppliers) ? parsed.suppliers : DEFAULT_DATA.suppliers;
    merged.shopSessions = Array.isArray(parsed.shopSessions) ? parsed.shopSessions : [];
    merged.recentCategories = Array.isArray(parsed.recentCategories) ? parsed.recentCategories : [];

    const existingCats = Array.isArray(parsed.categories) ? parsed.categories : DEFAULT_DATA.categories;
    if (!parsed.categoriesSeededV3) {
      const seenNames = new Set(existingCats.map((c: { name?: string }) => String(c?.name || '').trim().toLowerCase()));
      const additions = DEFAULT_DATA.categories.filter((c) => !seenNames.has(c.name.toLowerCase()));
      merged.categories = [...existingCats, ...additions];
      merged.categoriesSeededV3 = true;
    } else {
      merged.categories = existingCats;
    }

    if (!Array.isArray(merged.customers) || !merged.customers.some((c) => c.id === 'walk-in')) {
      merged.customers = [DEFAULT_DATA.customers[0], ...(merged.customers || [])];
    }
    return merged;
  } catch {
    return DEFAULT_DATA;
  }
};
