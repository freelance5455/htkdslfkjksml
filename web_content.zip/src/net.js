// 传输层：两种模式
//   mqtt：公共代理中转（要联网，跨网也能打）
//   rtc ：WebRTC 直连（不联网，手动交换一次连接码）

var NET = {
  role: 'solo',
  transport: 'mqtt',   // mqtt | rtc
  room: '',
  pid: 0,
  remote: { x: 0, y: 0, attack: false, jump: false, skill: false },
  snap: null,
  lastSnap: 0,
  lastInput: 0,
  lastPing: 0,
  lastRecv: 0,
  mq: null,
  dc: null,
  online: false,
  onMsg: null,
  onOpenCb: null
};

var MQ_URL = 'wss://broker.emqx.io:8084/mqtt';

// ---------- MQTT 模式 ----------
function netConnect(room, pid, onMsg) {
  netStop();
  NET.transport = 'mqtt';
  NET.role = pid === 1 ? 'host' : 'client';
  NET.room = room;
  NET.pid = pid;
  NET.onMsg = onMsg;

  NET.mq = new MQTTClient({
    url: MQ_URL,
    topic: 'fgame/v1/' + room,
    clientId: 'fgame_' + Math.random().toString(36).slice(2, 10),
    onMessage: function (msg) {
      if (!msg || msg.from === NET.pid) return;
      NET.lastRecv = Date.now();
      if (onMsg) onMsg(msg);
    },
    onOpen: function () {
      NET.online = true;
      if (pid === 2) netSend({ t: 'hello' });
      if (NET.onOpenCb) NET.onOpenCb();
    },
    onClose: function () { NET.online = false; }
  });
  NET.mq.connect();
}

// ---------- WebRTC 直连模式 ----------
function netRtcBind(channel, onMsg) {
  NET.transport = 'rtc';
  NET.dc = channel;
  NET.onMsg = onMsg;
  channel.onopen = function () {
    NET.online = true;
    if (NET.onOpenCb) NET.onOpenCb();
  };
  channel.onclose = function () { NET.online = false; };
  channel.onmessage = function (ev) {
    var msg;
    try { msg = JSON.parse(ev.data); } catch (e) { return; }
    if (!msg || msg.from === NET.pid) return;
    NET.lastRecv = Date.now();
    if (onMsg) onMsg(msg);
  };
}

// ---------- 通用 ----------
function netSend(obj) {
  obj.from = NET.pid;
  if (NET.transport === 'rtc') {
    if (NET.dc && NET.dc.readyState === 'open') {
      NET.dc.send(JSON.stringify(obj));
    }
    return;
  }
  if (NET.mq) NET.mq.publish(obj);
}

function netStop() {
  if (NET.mq) { NET.mq.close(); NET.mq = null; }
  if (typeof rtcClose === 'function') rtcClose();
  NET.dc = null;
  NET.role = 'solo';
  NET.transport = 'mqtt';
  NET.room = '';
  NET.pid = 0;
  NET.online = false;
  NET.snap = null;
  NET.onMsg = null;
  NET.onOpenCb = null;
}
