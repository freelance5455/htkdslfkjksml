// net.js — server socket manager with offline fallback
function getRoot() { try { return window.root || null; } catch (e) { return null; } }

export function createNet(hooks) {
  const N = {
    online: false, sock: null, retryMs: 1000, wantOpen: true, connecting: false,
    onChange: (on) => { N._cb = on; },
    _cb: null,
    _set(on) { if (N.online !== on) { N.online = on; try { N._cb && N._cb(on); } catch (e) {} } },
    connect() {
      if (N.connecting || (N.sock && (N.sock.readyState === 0 || N.sock.readyState === 1))) return;
      N.connecting = true;
      let s = null;
      try {
        const r = getRoot();
        if (!r || !r.createServerSocket) throw new Error("no-socket");
        s = r.createServerSocket();
      } catch (e) { N.connecting = false; N._set(false); N._retry(); return; }
      N.sock = s;
      try { s.binaryType = "arraybuffer"; } catch (e) {}
      s.addEventListener("open", () => {
        N.connecting = false; N.retryMs = 1000; N._set(true);
        try { hooks && hooks.onOpen && hooks.onOpen(); } catch (e) {}
      });
      s.addEventListener("close", (ev) => {
        N.connecting = false; N.sock = null; N._set(false);
        const code = ev && ev.code;
        if (!N.wantOpen) return;
        if (code === 4403) return; // perchance.org-only restriction: permanent
        if (code === 4429) { setTimeout(() => { if (N.wantOpen) N.connect(); }, 120000); return; }
        try { hooks && hooks.onClose && hooks.onClose(code); } catch (e) {}
        N._retry();
      });
      s.addEventListener("error", () => {});
    },
    _retry() {
      if (!N.wantOpen) return;
      const ms = Math.min(30000, N.retryMs + Math.random() * 1000);
      N.retryMs = Math.min(30000, N.retryMs * 2);
      setTimeout(() => { if (N.wantOpen) N.connect(); }, ms);
    },
    disconnect() { N.wantOpen = false; try { N.sock && N.sock.close(1000); } catch (e) {} N.sock = null; },
    async rpc(method, obj, timeoutMs) {
      if (!N.sock) throw new Error("offline");
      const p = N.sock.rpc[method](typeof obj === "string" ? obj : JSON.stringify(obj == null ? {} : obj));
      const t = timeoutMs || 20000;
      return await Promise.race([
        p,
        new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), t))
      ]);
    }
  };
  return N;
}
