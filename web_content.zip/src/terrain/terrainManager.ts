import { StreamingCell, Vector3D } from '../types';

export class TerrainManager {
  private cells: Map<string, StreamingCell> = new Map();
  public readonly gridSize = 4; // 4x4 grid: A1 to D4
  public readonly cellSize = 30; // meters per cell

  constructor() {
    this.initGridCells();
  }

  private initGridCells() {
    const letters = ['A', 'B', 'C', 'D'];
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        const id = `${letters[row]}${col + 1}`;
        const x = (col - 1.5) * this.cellSize;
        const z = (row - 1.5) * this.cellSize;
        this.cells.set(id, {
          id,
          x,
          z,
          status: 'loaded',
          entitiesCount: Math.floor(Math.random() * 8) + 2,
        });
      }
    }
  }

  public getCells(): StreamingCell[] {
    return Array.from(this.cells.values());
  }

  /**
   * Updates streaming cell states based on player/camera position
   * In DAVIENGINE 0.1, demonstrates dynamic cell loading/unloading
   */
  public updateStreaming(targetPos: Vector3D, streamingRadius = 45): { loaded: number; unloaded: number } {
    let loaded = 0;
    let unloaded = 0;

    this.cells.forEach((cell) => {
      const dx = cell.x - targetPos.x;
      const dz = cell.z - targetPos.z;
      const dist = Math.sqrt(dx * dx + dz * dz);

      if (dist <= streamingRadius) {
        cell.status = 'loaded';
        loaded++;
      } else if (dist <= streamingRadius + 15) {
        cell.status = 'loading';
        loaded++;
      } else {
        cell.status = 'unloaded';
        unloaded++;
      }
    });

    return { loaded, unloaded };
  }
}

export const terrainStreamingSystem = new TerrainManager();
