import heroBurger from "../public/images/hero-burger.jpg?inline";
import rider from "../public/images/rider.jpg?inline";
import kota from "../public/images/kota.jpg?inline";
import chips from "../public/images/chips.jpg?inline";
import papChicken from "../public/images/pap-chicken.jpg?inline";
import steakPap from "../public/images/steak-pap.jpg?inline";
import smashedBurger from "../public/images/smashed-burger.jpg?inline";
import braaiBox from "../public/images/braai-box.jpg?inline";
import friedChicken from "../public/images/fried-chicken.jpg?inline";
import appIcon from "../public/images/icon.png?inline";
import buzzCover from "../public/images/buzz-cover.svg?inline";
import buzzBadge from "../public/images/buzz-badge.svg?inline";
import logoNandos from "../public/images/logos/nandos.svg?inline";
import logoLicken from "../public/images/logos/chicken-licken.svg?inline";
import logoKfc from "../public/images/logos/kfc.svg?inline";
import logoMcd from "../public/images/logos/mcdonalds.svg?inline";
import logoKennys from "../public/images/logos/kennys.svg?inline";
import logoDebonairs from "../public/images/logos/debonairs.svg?inline";
import logoThrive from "../public/images/logos/thrive.svg?inline";
import logoGalitos from "../public/images/logos/galitos.svg?inline";
import logoClicks from "../public/images/logos/clicks.svg?inline";
import logoLocalChoice from "../public/images/logos/local-choice.svg?inline";
import logoCapitec from "../public/images/logos/capitec.svg?inline";
import logoFnb from "../public/images/logos/fnb.svg?inline";
import logoAbsa from "../public/images/logos/absa.svg?inline";
import logoStandard from "../public/images/logos/standardbank.svg?inline";
import logoNedbank from "../public/images/logos/nedbank.svg?inline";
import logoShoprite from "../public/images/logos/shoprite.svg?inline";
import logoRoots from "../public/images/logos/roots.svg?inline";
import logoBoxer from "../public/images/logos/boxer.svg?inline";
import coverShoprite from "../public/images/covers/shoprite.svg?inline";
import coverRoots from "../public/images/covers/roots.svg?inline";
import coverBoxer from "../public/images/covers/boxer.svg?inline";

export const IMG = {
  heroBurger,
  rider,
  kota,
  chips,
  papChicken,
  steakPap,
  smashedBurger,
  braaiBox,
  friedChicken,
  appIcon,
  buzzCover,
  buzzBadge,
  logoNandos,
  logoLicken,
  logoKfc,
  logoMcd,
  logoKennys,
  logoDebonairs,
  logoThrive,
  logoGalitos,
  logoClicks,
  logoLocalChoice,
  logoCapitec,
  logoFnb,
  logoAbsa,
  logoStandard,
  logoNedbank,
  logoShoprite,
  logoRoots,
  logoBoxer,
  coverShoprite,
  coverRoots,
  coverBoxer,
};
