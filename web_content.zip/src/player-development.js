import { ensureManagementState } from './relations.js';

const clamp = (n, min, max) => Math.max(min, Math.min(max, Number(n) || 0));
function locate(state, playerId) {
  for (const division of state.divisions || []) for (const club of division.clubs || []) {
    const player = (club.damistes || []).find(p => p.id === playerId);
    if (player) return { club, player };
  }
  return null;
}

/** Training is explicit, persisted and bounded; one session cannot exceed level 99. */
export function trainDamiste(state, playerId, focus = 'strategy') {
  const found = locate(state, playerId);
  if (!found) throw new Error('Damiste introuvable');
  const { club, player } = found;
  const allowed = ['strategy', 'attack', 'defense', 'anticipation', 'fitness'];
  if (!allowed.includes(focus)) throw new Error('Spécialité d’entraînement inconnue');
  player.development ??= { experience: 0, talents: {}, trainingSessions: 0, injuries: [] };
  player.development.talents ??= {};
  const before = Number(player.level) || 1;
  const form = clamp(player.form ?? 50, 0, 100);
  const gain = form < 25 ? 1 : form < 60 ? 2 : 3;
  player.development.experience = clamp(player.development.experience + 25, 0, 1000000);
  player.development.trainingSessions += 1;
  player.development.talents[focus] = clamp((player.development.talents[focus] || 0) + gain, 0, 100);
  const threshold = Math.max(100, before * 100);
  let levelsGained = 0;
  while (player.development.experience >= threshold && Number(player.level) < 99) {
    player.development.experience -= threshold;
    player.level = Number(player.level) + 1;
    levelsGained += 1;
  }
  player.form = clamp(form - 5, 0, 100);
  const m = ensureManagementState(state);
  m.careerLog.unshift({ id: `training:${state.season}:${playerId}:${player.development.trainingSessions}`, type: 'player-training', season: state.season, clubId: club.id, playerId, impact: `Entraînement ${focus} : +${gain} talent${levelsGained ? `, niveau +${levelsGained}` : ''}.`, at: new Date().toISOString() });
  return { playerId, focus, talentGain: gain, levelsGained, level: player.level, form: player.form, experience: player.development.experience };
}

export function restDamiste(state, playerId, days = 1) {
  const found = locate(state, playerId);
  if (!found) throw new Error('Damiste introuvable');
  const count = Number(days);
  if (!Number.isInteger(count) || count < 1 || count > 30) throw new Error('Durée de repos invalide');
  const p = found.player;
  p.form = clamp((p.form ?? 50) + count * 8, 0, 100);
  p.development ??= { experience: 0, talents: {}, trainingSessions: 0, injuries: [] };
  if (p.injury?.daysRemaining) {
    p.injury.daysRemaining = Math.max(0, p.injury.daysRemaining - count);
    if (!p.injury.daysRemaining) p.injury = null;
  }
  return { playerId, form: p.form, injury: p.injury || null };
}

export function injureDamiste(state, playerId, { type = 'musculaire', days = 7 } = {}) {
  const found = locate(state, playerId);
  if (!found) throw new Error('Damiste introuvable');
  const duration = Number(days);
  if (!Number.isInteger(duration) || duration < 1 || duration > 180) throw new Error('Durée de blessure invalide');
  const p = found.player;
  p.injury = { type: String(type).slice(0, 60), daysRemaining: duration, startedSeason: state.season, startedAt: new Date().toISOString() };
  p.form = clamp((p.form ?? 50) - Math.min(40, duration), 0, 100);
  p.development ??= { experience: 0, talents: {}, trainingSessions: 0, injuries: [] };
  p.development.injuries ??= [];
  p.development.injuries.unshift(structuredClone(p.injury));
  return structuredClone(p.injury);
}

export function getDamisteDevelopment(player) {
  const d = player?.development || {};
  return { experience: Number(d.experience) || 0, trainingSessions: Number(d.trainingSessions) || 0, talents: structuredClone(d.talents || {}), injury: player?.injury || null, form: clamp(player?.form ?? 50, 0, 100), level: clamp(player?.level ?? 1, 1, 99) };
}
