import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  updateDoc, 
  increment, 
  onSnapshot, 
  query, 
  orderBy, 
  limit 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { useAuth } from './AuthContext';
import { 
  Post, 
  Reel, 
  Story, 
  NotificationItem, 
  CommentItem, 
  ReactionType, 
  ContentReport 
} from '../types';
import { 
  INITIAL_POSTS, 
  INITIAL_REELS, 
  INITIAL_STORIES, 
  INITIAL_NOTIFICATIONS 
} from '../data/initialData';

interface SocialContextType {
  posts: Post[];
  reels: Reel[];
  stories: Story[];
  notifications: NotificationItem[];
  reports: ContentReport[];
  unreadNotifsCount: number;
  createPost: (content: string, mediaType: 'none' | 'image' | 'video', mediaUrl?: string, privacy?: 'public' | 'friends') => Promise<void>;
  deletePost: (postId: string) => Promise<void>;
  reactToPost: (postId: string, reaction: ReactionType) => void;
  addComment: (postId: string, text: string) => Promise<void>;
  getCommentsForPost: (postId: string) => CommentItem[];
  toggleSavePost: (postId: string) => void;
  reportContent: (targetType: 'post' | 'reel' | 'user', targetId: string, reason: string, authorName?: string) => void;
  createReel: (caption: string, videoUrl: string, soundTitle?: string) => Promise<void>;
  deleteReel: (reelId: string) => Promise<void>;
  toggleLikeReel: (reelId: string) => void;
  createStory: (mediaUrl: string, mediaType: 'image' | 'video') => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  resolveReport: (reportId: string) => void;
}

const SocialContext = createContext<SocialContextType | undefined>(undefined);

export const SocialProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>(() => {
    try {
      const saved = localStorage.getItem('facelook_posts');
      if (saved) {
        const parsed: Post[] = JSON.parse(saved);
        return parsed.map(p => {
          if (p.mediaType === 'video' && p.mediaUrl?.includes('commondatastorage.googleapis.com')) {
            return { ...p, mediaUrl: 'https://vjs.zencdn.net/v/oceans.mp4' };
          }
          return p;
        });
      }
    } catch {}
    return INITIAL_POSTS;
  });
  const [reels, setReels] = useState<Reel[]>(() => {
    try {
      const saved = localStorage.getItem('facelook_reels');
      if (saved) {
        const parsed: Reel[] = JSON.parse(saved);
        return parsed.map((r, i) => {
          if (r.videoUrl?.includes('commondatastorage.googleapis.com')) {
            const fallback = i === 1 
              ? 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4'
              : 'https://vjs.zencdn.net/v/oceans.mp4';
            return { ...r, videoUrl: fallback };
          }
          return r;
        });
      }
    } catch {}
    return INITIAL_REELS;
  });
  const [stories, setStories] = useState<Story[]>(() => {
    const saved = localStorage.getItem('facelook_stories');
    return saved ? JSON.parse(saved) : INITIAL_STORIES;
  });
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('facelook_notifications');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });
  const [commentsMap, setCommentsMap] = useState<Record<string, CommentItem[]>>({});
  const [reports, setReports] = useState<ContentReport[]>([
    {
      id: 'rep_1',
      reporterId: 'user_sophia_tech',
      reporterName: 'Sophia Chen',
      targetType: 'post',
      targetId: 'post_video_demo',
      targetAuthorName: 'Sophia Chen',
      reason: 'Quality verification check',
      status: 'resolved',
      createdAt: new Date().toISOString(),
    }
  ]);

  // Persist locally for instant offline/reload access
  useEffect(() => {
    localStorage.setItem('facelook_posts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('facelook_reels', JSON.stringify(reels));
  }, [reels]);

  useEffect(() => {
    localStorage.setItem('facelook_stories', JSON.stringify(stories));
  }, [stories]);

  useEffect(() => {
    localStorage.setItem('facelook_notifications', JSON.stringify(notifications));
  }, [notifications]);

  // Sync Posts with Firestore
  useEffect(() => {
    try {
      const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(50));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const remotePosts: Post[] = [];
          snapshot.forEach((doc) => {
            remotePosts.push({ id: doc.id, ...(doc.data() as any) });
          });

          // Merge Firestore posts with seed posts without duplicates
          setPosts(prev => {
            const map = new Map<string, Post>();
            remotePosts.forEach(p => map.set(p.id, p));
            prev.forEach(p => {
              if (!map.has(p.id)) map.set(p.id, p);
            });
            return Array.from(map.values()).sort(
              (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            );
          });
        }
      }, (err) => {
        console.warn('Firestore posts realtime subscription notice:', err.message);
      });
      return () => unsubscribe();
    } catch (err) {
      console.warn('Could not connect to Firestore posts:', err);
    }
  }, []);

  // Sync Reels with Firestore
  useEffect(() => {
    try {
      const q = query(collection(db, 'reels'), orderBy('createdAt', 'desc'), limit(50));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const remoteReels: Reel[] = [];
          snapshot.forEach((doc) => {
            remoteReels.push({ id: doc.id, ...(doc.data() as any) });
          });
          setReels(prev => {
            const map = new Map<string, Reel>();
            remoteReels.forEach(r => map.set(r.id, r));
            prev.forEach(r => {
              if (!map.has(r.id)) map.set(r.id, r);
            });
            return Array.from(map.values()).sort(
              (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            );
          });
        }
      }, (err) => {
        console.warn('Firestore reels subscription notice:', err.message);
      });
      return () => unsubscribe();
    } catch (err) {
      console.warn('Could not connect to Firestore reels:', err);
    }
  }, []);

  const createPost = async (
    content: string, 
    mediaType: 'none' | 'image' | 'video', 
    mediaUrl?: string, 
    privacy: 'public' | 'friends' = 'public'
  ) => {
    const newId = 'post_' + Date.now();
    const newPost: Post = {
      id: newId,
      authorId: user?.id || 'guest',
      authorName: user?.displayName || 'FaceLook User',
      authorUsername: user?.username || 'user',
      authorPhotoURL: user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80',
      authorIsAdmin: user?.role === 'admin',
      content,
      mediaType,
      mediaUrl,
      privacy,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      createdAt: new Date().toISOString(),
      userReaction: null,
    };

    // Optimistic UI update
    setPosts(prev => [newPost, ...prev]);

    // Push to Firestore
    try {
      await setDoc(doc(db, 'posts', newId), newPost);
    } catch (err) {
      console.warn('Firestore write fallback to local storage:', err);
    }
  };

  const deletePost = async (postId: string) => {
    setPosts(prev => prev.filter(p => p.id !== postId));
    try {
      await deleteDoc(doc(db, 'posts', postId));
    } catch (err) {
      console.warn('Could not delete post from firestore:', err);
    }
  };

  const reactToPost = (postId: string, reaction: ReactionType) => {
    setPosts(prev => prev.map(p => {
      if (p.id !== postId) return p;
      const isAlreadySame = p.userReaction === reaction;
      const wasReacted = !!p.userReaction;

      let newCount = p.likesCount;
      let newReaction: ReactionType | null = reaction;

      if (isAlreadySame) {
        newCount = Math.max(0, newCount - 1);
        newReaction = null;
      } else if (!wasReacted) {
        newCount += 1;
      }

      return {
        ...p,
        likesCount: newCount,
        userReaction: newReaction,
      };
    }));

    // Trigger notification if reacting to another user's post
    const targetPost = posts.find(p => p.id === postId);
    if (targetPost && targetPost.authorId !== user?.id) {
      addNotification({
        recipientId: targetPost.authorId,
        senderId: user?.id || 'guest',
        senderName: user?.displayName || 'Someone',
        senderPhotoURL: user?.photoURL || '',
        type: 'like',
        message: `reacted to your post with "${reaction}"`,
        targetId: postId,
      });
    }

    try {
      updateDoc(doc(db, 'posts', postId), {
        likesCount: increment(1)
      }).catch(() => {});
    } catch {}
  };

  const addComment = async (postId: string, text: string) => {
    if (!text.trim()) return;
    const commentId = 'comm_' + Date.now();
    const newComment: CommentItem = {
      id: commentId,
      postId,
      authorId: user?.id || 'guest',
      authorName: user?.displayName || 'FaceLook User',
      authorPhotoURL: user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80',
      text,
      createdAt: new Date().toISOString(),
      likesCount: 0,
    };

    setCommentsMap(prev => ({
      ...prev,
      [postId]: [...(prev[postId] || []), newComment],
    }));

    setPosts(prev => prev.map(p => p.id === postId ? { ...p, commentsCount: p.commentsCount + 1 } : p));

    const targetPost = posts.find(p => p.id === postId);
    if (targetPost && targetPost.authorId !== user?.id) {
      addNotification({
        recipientId: targetPost.authorId,
        senderId: user?.id || 'guest',
        senderName: user?.displayName || 'Someone',
        senderPhotoURL: user?.photoURL || '',
        type: 'comment',
        message: `commented: "${text.slice(0, 40)}${text.length > 40 ? '...' : ''}"`,
        targetId: postId,
      });
    }

    try {
      await setDoc(doc(db, 'posts', postId, 'comments', commentId), newComment);
      await updateDoc(doc(db, 'posts', postId), { commentsCount: increment(1) });
    } catch (err) {
      console.warn('Comment write error fallback:', err);
    }
  };

  const getCommentsForPost = (postId: string): CommentItem[] => {
    return commentsMap[postId] || [
      {
        id: 'mock_c1',
        postId,
        authorId: 'user_sophia_tech',
        authorName: 'Sophia Chen',
        authorPhotoURL: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=240&auto=format&fit=crop&q=80',
        text: 'Super sleek design! Works beautifully on Android! 🔥',
        createdAt: '2026-10-12T12:08:00Z',
        likesCount: 3,
      },
      {
        id: 'mock_c2',
        postId,
        authorId: 'user_marcus_travel',
        authorName: 'Marcus Vance',
        authorPhotoURL: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=240&auto=format&fit=crop&q=80',
        text: 'The gallery upload speed is so smooth. Great job! 👏',
        createdAt: '2026-10-12T12:12:00Z',
        likesCount: 1,
      }
    ];
  };

  const toggleSavePost = (postId: string) => {
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, isSaved: !p.isSaved } : p));
  };

  const reportContent = (targetType: 'post' | 'reel' | 'user', targetId: string, reason: string, authorName?: string) => {
    const report: ContentReport = {
      id: 'rep_' + Date.now(),
      reporterId: user?.id || 'guest',
      reporterName: user?.displayName || 'Anonymous',
      targetType,
      targetId,
      targetAuthorName: authorName,
      reason,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    setReports(prev => [report, ...prev]);

    if (targetType === 'post') {
      setPosts(prev => prev.map(p => p.id === targetId ? { ...p, flagged: true, flagReason: reason } : p));
    } else if (targetType === 'reel') {
      setReels(prev => prev.map(r => r.id === targetId ? { ...r, flagged: true } : r));
    }
  };

  const createReel = async (caption: string, videoUrl: string, soundTitle: string = 'Original Sound') => {
    const newId = 'reel_' + Date.now();
    const newReel: Reel = {
      id: newId,
      authorId: user?.id || 'guest',
      authorName: user?.displayName || 'FaceLook Creator',
      authorUsername: user?.username || 'creator',
      authorPhotoURL: user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80',
      caption,
      videoUrl,
      soundTitle,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      createdAt: new Date().toISOString(),
      userLiked: false,
    };

    setReels(prev => [newReel, ...prev]);

    try {
      await setDoc(doc(db, 'reels', newId), newReel);
    } catch (err) {
      console.warn('Reel firestore sync fallback:', err);
    }
  };

  const deleteReel = async (reelId: string) => {
    setReels(prev => prev.filter(r => r.id !== reelId));
    try {
      await deleteDoc(doc(db, 'reels', reelId));
    } catch {}
  };

  const toggleLikeReel = (reelId: string) => {
    setReels(prev => prev.map(r => {
      if (r.id !== reelId) return r;
      const willLike = !r.userLiked;
      return {
        ...r,
        userLiked: willLike,
        likesCount: willLike ? r.likesCount + 1 : Math.max(0, r.likesCount - 1),
      };
    }));
  };

  const createStory = (mediaUrl: string, mediaType: 'image' | 'video') => {
    const newStory: Story = {
      id: 'story_' + Date.now(),
      authorId: user?.id || 'guest',
      authorName: user?.displayName || 'Me',
      authorPhotoURL: user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80',
      mediaUrl,
      mediaType,
      createdAt: new Date().toISOString(),
    };
    setStories(prev => [newStory, ...prev]);
  };

  const addNotification = (notif: Omit<NotificationItem, 'id' | 'createdAt' | 'isRead'>) => {
    const item: NotificationItem = {
      ...notif,
      id: 'notif_' + Date.now(),
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    setNotifications(prev => [item, ...prev]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const resolveReport = (reportId: string) => {
    setReports(prev => prev.map(r => r.id === reportId ? { ...r, status: 'resolved' } : r));
  };

  const unreadNotifsCount = notifications.filter(n => !n.isRead).length;

  return (
    <SocialContext.Provider
      value={{
        posts,
        reels,
        stories,
        notifications,
        reports,
        unreadNotifsCount,
        createPost,
        deletePost,
        reactToPost,
        addComment,
        getCommentsForPost,
        toggleSavePost,
        reportContent,
        createReel,
        deleteReel,
        toggleLikeReel,
        createStory,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        resolveReport,
      }}
    >
      {children}
    </SocialContext.Provider>
  );
};

export const useSocial = () => {
  const context = useContext(SocialContext);
  if (!context) throw new Error('useSocial must be used within a SocialProvider');
  return context;
};
