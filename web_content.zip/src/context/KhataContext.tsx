import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  Category,
  FamilyMember,
  Transaction,
  Loan,
  BillReminder,
  SavingsGoal,
  BudgetConfig,
  AppSettings,
  AppDataBackup
} from '../types';
import { storage, initDatabase, DEFAULT_CATEGORIES, DEFAULT_FAMILY_MEMBERS } from '../services/db';
import { translations, Language } from '../i18n/translations';

interface KhataContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.hi;
  categories: Category[];
  familyMembers: FamilyMember[];
  transactions: Transaction[];
  loans: Loan[];
  bills: BillReminder[];
  savingsGoals: SavingsGoal[];
  budget: BudgetConfig;
  settings: AppSettings;
  selectedMonth: string;
  setSelectedMonth: (month: string) => void;
  
  // Security
  isLocked: boolean;
  unlockApp: (pin: string) => boolean;
  lockApp: () => void;
  setPin: (pin: string) => void;
  removePin: () => void;

  // Active modal
  activeModal: string | null;
  setActiveModal: (modal: string | null) => void;
  editingTransaction: Transaction | null;
  setEditingTransaction: (tx: Transaction | null) => void;

  // CRUD actions
  addTransaction: (tx: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>) => Transaction;
  updateTransaction: (id: string, updates: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  checkDuplicate: (amount: number, categoryId: string, date: string) => Transaction | undefined;

  addCategory: (cat: Omit<Category, 'id'>) => Category;
  addFamilyMember: (m: Omit<FamilyMember, 'id'>) => FamilyMember;

  addLoan: (loan: Omit<Loan, 'id' | 'createdAt' | 'updatedAt' | 'repayments'>) => Loan;
  recordLoanRepayment: (loanId: string, amount: number, note?: string) => void;
  markLoanPaid: (loanId: string) => void;
  deleteLoan: (loanId: string) => void;

  addBill: (bill: Omit<BillReminder, 'id' | 'createdAt'>) => BillReminder;
  markBillPaid: (billId: string, alsoAddExpense?: boolean) => void;
  deleteBill: (billId: string) => void;

  addSavingsGoal: (goal: Omit<SavingsGoal, 'id' | 'currentAmount' | 'history' | 'createdAt'>) => SavingsGoal;
  updateGoalSavings: (goalId: string, amount: number, type: 'deposit' | 'withdraw', note?: string) => void;
  deleteSavingsGoal: (goalId: string) => void;

  updateBudget: (overall: number, limits: Record<string, number>) => void;
  exportBackup: () => AppDataBackup;
  restoreBackup: (backup: AppDataBackup) => boolean;
  resetAllData: () => void;
  loadSampleData: () => void;

  // Computed
  currentMonthTransactions: Transaction[];
  monthlyIncome: number;
  monthlyExpense: number;
  remainingBalance: number;
  todayExpense: number;
  totalSavings: number;
  pendingToReceive: number;
  pendingToPay: number;
  budgetProgressPercent: number;
}

const KhataContext = createContext<KhataContextType | undefined>(undefined);

export const KhataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  useEffect(() => {
    initDatabase();
  }, []);

  const [settings, setSettings] = useState<AppSettings>(() => 
    storage.get<AppSettings>('settings', {
      language: 'hi',
      currency: '₹',
      pinLockEnabled: false,
      biometricEnabled: false
    })
  );

  const [language, setLanguageState] = useState<Language>(() => settings.language || 'hi');
  const [categories, setCategories] = useState<Category[]>(() => storage.get<Category[]>('categories', DEFAULT_CATEGORIES));
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(() => storage.get<FamilyMember[]>('family_members', DEFAULT_FAMILY_MEMBERS));
  const [transactions, setTransactions] = useState<Transaction[]>(() => storage.get<Transaction[]>('transactions', []));
  const [loans, setLoans] = useState<Loan[]>(() => storage.get<Loan[]>('loans', []));
  const [bills, setBills] = useState<BillReminder[]>(() => storage.get<BillReminder[]>('bills', []));
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>(() => storage.get<SavingsGoal[]>('savings_goals', []));

  const currentMonthStr = useMemo(() => new Date().toISOString().slice(0, 7), []);
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonthStr);

  const [budget, setBudget] = useState<BudgetConfig>(() =>
    storage.get<BudgetConfig>('budget', {
      month: currentMonthStr,
      overallBudget: 45000,
      categoryLimits: {}
    })
  );

  // Security Lock
  const [isLocked, setIsLocked] = useState<boolean>(() => settings.pinLockEnabled && !!settings.pinHash);

  // Modals state
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  // Sync state to storage
  useEffect(() => {
    storage.set('settings', settings);
  }, [settings]);

  useEffect(() => {
    storage.set('categories', categories);
  }, [categories]);

  useEffect(() => {
    storage.set('family_members', familyMembers);
  }, [familyMembers]);

  useEffect(() => {
    storage.set('transactions', transactions);
  }, [transactions]);

  useEffect(() => {
    storage.set('loans', loans);
  }, [loans]);

  useEffect(() => {
    storage.set('bills', bills);
  }, [bills]);

  useEffect(() => {
    storage.set('savings_goals', savingsGoals);
  }, [savingsGoals]);

  useEffect(() => {
    storage.set('budget', budget);
  }, [budget]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    setSettings(prev => ({ ...prev, language: lang }));
    document.documentElement.lang = lang;
  };

  const t = translations[language];

  // PIN Lock Actions
  const unlockApp = (pin: string): boolean => {
    if (!settings.pinHash) {
      setIsLocked(false);
      return true;
    }
    // Simple hash check
    const hash = btoa(pin);
    if (hash === settings.pinHash) {
      setIsLocked(false);
      return true;
    }
    return false;
  };

  const lockApp = () => {
    if (settings.pinLockEnabled && settings.pinHash) {
      setIsLocked(true);
    }
  };

  const setPin = (pin: string) => {
    const hash = btoa(pin);
    setSettings(prev => ({ ...prev, pinLockEnabled: true, pinHash: hash }));
    setIsLocked(false);
  };

  const removePin = () => {
    setSettings(prev => ({ ...prev, pinLockEnabled: false, pinHash: undefined }));
    setIsLocked(false);
  };

  // Duplicate Check
  const checkDuplicate = (amount: number, categoryId: string, date: string): Transaction | undefined => {
    return transactions.find(tx => tx.amount === amount && tx.categoryId === categoryId && tx.date === date);
  };

  // Transactions CRUD
  const addTransaction = (txData: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>): Transaction => {
    const newTx: Transaction = {
      ...txData,
      id: 'tx_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    setTransactions(prev => [newTx, ...prev]);
    return newTx;
  };

  const updateTransaction = (id: string, updates: Partial<Transaction>) => {
    setTransactions(prev =>
      prev.map(tx => (tx.id === id ? { ...tx, ...updates, updatedAt: Date.now() } : tx))
    );
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(tx => tx.id !== id));
  };

  // Category & Member CRUD
  const addCategory = (catData: Omit<Category, 'id'>): Category => {
    const newCat: Category = {
      ...catData,
      id: 'custom_' + Date.now(),
      isCustom: true
    };
    setCategories(prev => [...prev, newCat]);
    return newCat;
  };

  const addFamilyMember = (memberData: Omit<FamilyMember, 'id'>): FamilyMember => {
    const newMember: FamilyMember = {
      ...memberData,
      id: 'member_' + Date.now()
    };
    setFamilyMembers(prev => [...prev, newMember]);
    return newMember;
  };

  // Loans CRUD
  const addLoan = (loanData: Omit<Loan, 'id' | 'createdAt' | 'updatedAt' | 'repayments'>): Loan => {
    const newLoan: Loan = {
      ...loanData,
      id: 'loan_' + Date.now(),
      repayments: [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    setLoans(prev => [newLoan, ...prev]);
    return newLoan;
  };

  const recordLoanRepayment = (loanId: string, amount: number, note?: string) => {
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    
    setLoans(prev =>
      prev.map(l => {
        if (l.id !== loanId) return l;
        const newRepayments = [
          ...l.repayments,
          { id: 'rep_' + Date.now(), date: dateStr, amount, note }
        ];
        const totalRepaid = newRepayments.reduce((sum, r) => sum + r.amount, 0);
        const status = totalRepaid >= l.amount ? 'paid' : 'partial';

        return {
          ...l,
          repayments: newRepayments,
          status,
          updatedAt: Date.now()
        };
      })
    );
  };

  const markLoanPaid = (loanId: string) => {
    setLoans(prev =>
      prev.map(l => (l.id === loanId ? { ...l, status: 'paid', updatedAt: Date.now() } : l))
    );
  };

  const deleteLoan = (loanId: string) => {
    setLoans(prev => prev.filter(l => l.id !== loanId));
  };

  // Bills CRUD
  const addBill = (billData: Omit<BillReminder, 'id' | 'createdAt'>): BillReminder => {
    const newBill: BillReminder = {
      ...billData,
      id: 'bill_' + Date.now(),
      createdAt: Date.now()
    };
    setBills(prev => [newBill, ...prev]);
    return newBill;
  };

  const markBillPaid = (billId: string, alsoAddExpense: boolean = true) => {
    const bill = bills.find(b => b.id === billId);
    if (!bill) return;

    if (alsoAddExpense) {
      const now = new Date();
      const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      addTransaction({
        type: 'expense',
        amount: bill.amount,
        categoryId: bill.category || 'electricity',
        date: todayStr,
        description: `${bill.titleHi || bill.titleEn} (बिल भुगतान)`,
        paymentMode: 'upi'
      });
    }

    setBills(prev =>
      prev.map(b => (b.id === billId ? { ...b, status: 'paid' } : b))
    );
  };

  const deleteBill = (billId: string) => {
    setBills(prev => prev.filter(b => b.id !== billId));
  };

  // Savings Goals CRUD
  const addSavingsGoal = (goalData: Omit<SavingsGoal, 'id' | 'currentAmount' | 'history' | 'createdAt'>): SavingsGoal => {
    const newGoal: SavingsGoal = {
      ...goalData,
      id: 'goal_' + Date.now(),
      currentAmount: 0,
      history: [],
      createdAt: Date.now()
    };
    setSavingsGoals(prev => [newGoal, ...prev]);
    return newGoal;
  };

  const updateGoalSavings = (goalId: string, amount: number, type: 'deposit' | 'withdraw', note?: string) => {
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

    setSavingsGoals(prev =>
      prev.map(g => {
        if (g.id !== goalId) return g;
        const newEntry = {
          id: 'gh_' + Date.now(),
          date: dateStr,
          amount,
          type,
          note
        };
        const delta = type === 'deposit' ? amount : -amount;
        const newTotal = Math.max(0, g.currentAmount + delta);

        return {
          ...g,
          currentAmount: newTotal,
          history: [newEntry, ...g.history]
        };
      })
    );
  };

  const deleteSavingsGoal = (goalId: string) => {
    setSavingsGoals(prev => prev.filter(g => g.id !== goalId));
  };

  // Budget
  const updateBudget = (overall: number, limits: Record<string, number>) => {
    setBudget(prev => ({
      ...prev,
      overallBudget: overall,
      categoryLimits: limits
    }));
  };

  // Backup & Restore
  const exportBackup = (): AppDataBackup => {
    return {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      transactions,
      categories,
      loans,
      bills,
      savingsGoals,
      familyMembers,
      budget,
      settings
    };
  };

  const restoreBackup = (backup: AppDataBackup): boolean => {
    try {
      if (backup.transactions) setTransactions(backup.transactions);
      if (backup.categories) setCategories(backup.categories);
      if (backup.loans) setLoans(backup.loans);
      if (backup.bills) setBills(backup.bills);
      if (backup.savingsGoals) setSavingsGoals(backup.savingsGoals);
      if (backup.familyMembers) setFamilyMembers(backup.familyMembers);
      if (backup.budget) setBudget(backup.budget);
      if (backup.settings) setSettings(backup.settings);
      return true;
    } catch (e) {
      console.error('Failed to restore backup', e);
      return false;
    }
  };

  const resetAllData = () => {
    setTransactions([]);
    setLoans([]);
    setBills([]);
    setSavingsGoals([]);
    setBudget({
      month: currentMonthStr,
      overallBudget: 40000,
      categoryLimits: {}
    });
  };

  const loadSampleData = () => {
    storage.remove('initialized');
    initDatabase();
    setCategories(storage.get<Category[]>('categories', DEFAULT_CATEGORIES));
    setFamilyMembers(storage.get<FamilyMember[]>('family_members', DEFAULT_FAMILY_MEMBERS));
    setTransactions(storage.get<Transaction[]>('transactions', []));
    setLoans(storage.get<Loan[]>('loans', []));
    setBills(storage.get<BillReminder[]>('bills', []));
    setSavingsGoals(storage.get<SavingsGoal[]>('savings_goals', []));
    setBudget(storage.get<BudgetConfig>('budget', { month: currentMonthStr, overallBudget: 45000, categoryLimits: {} }));
  };

  // COMPUTED STATS
  const currentMonthTransactions = useMemo(() => {
    return transactions.filter(tx => tx.date.startsWith(selectedMonth));
  }, [transactions, selectedMonth]);

  const monthlyIncome = useMemo(() => {
    return currentMonthTransactions
      .filter(tx => tx.type === 'income')
      .reduce((sum, tx) => sum + tx.amount, 0);
  }, [currentMonthTransactions]);

  const monthlyExpense = useMemo(() => {
    return currentMonthTransactions
      .filter(tx => tx.type === 'expense')
      .reduce((sum, tx) => sum + tx.amount, 0);
  }, [currentMonthTransactions]);

  const remainingBalance = useMemo(() => {
    return monthlyIncome - monthlyExpense;
  }, [monthlyIncome, monthlyExpense]);

  const todayStr = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }, []);

  const todayExpense = useMemo(() => {
    return transactions
      .filter(tx => tx.type === 'expense' && tx.date === todayStr)
      .reduce((sum, tx) => sum + tx.amount, 0);
  }, [transactions, todayStr]);

  const totalSavings = useMemo(() => {
    return savingsGoals.reduce((sum, g) => sum + g.currentAmount, 0);
  }, [savingsGoals]);

  const pendingToReceive = useMemo(() => {
    // Lent to others, pending balance
    return loans
      .filter(l => l.type === 'lent' && l.status !== 'paid')
      .reduce((sum, l) => {
        const repaid = l.repayments.reduce((rSum, r) => rSum + r.amount, 0);
        return sum + Math.max(0, l.amount - repaid);
      }, 0);
  }, [loans]);

  const pendingToPay = useMemo(() => {
    // Borrowed from others, pending balance
    return loans
      .filter(l => l.type === 'borrowed' && l.status !== 'paid')
      .reduce((sum, l) => {
        const repaid = l.repayments.reduce((rSum, r) => rSum + r.amount, 0);
        return sum + Math.max(0, l.amount - repaid);
      }, 0);
  }, [loans]);

  const budgetProgressPercent = useMemo(() => {
    if (!budget.overallBudget || budget.overallBudget <= 0) return 0;
    return Math.min(100, Math.round((monthlyExpense / budget.overallBudget) * 100));
  }, [monthlyExpense, budget.overallBudget]);

  return (
    <KhataContext.Provider
      value={{
        language,
        setLanguage,
        t,
        categories,
        familyMembers,
        transactions,
        loans,
        bills,
        savingsGoals,
        budget,
        settings,
        selectedMonth,
        setSelectedMonth,
        isLocked,
        unlockApp,
        lockApp,
        setPin,
        removePin,
        activeModal,
        setActiveModal,
        editingTransaction,
        setEditingTransaction,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        checkDuplicate,
        addCategory,
        addFamilyMember,
        addLoan,
        recordLoanRepayment,
        markLoanPaid,
        deleteLoan,
        addBill,
        markBillPaid,
        deleteBill,
        addSavingsGoal,
        updateGoalSavings,
        deleteSavingsGoal,
        updateBudget,
        exportBackup,
        restoreBackup,
        resetAllData,
        loadSampleData,
        currentMonthTransactions,
        monthlyIncome,
        monthlyExpense,
        remainingBalance,
        todayExpense,
        totalSavings,
        pendingToReceive,
        pendingToPay,
        budgetProgressPercent
      }}
    >
      {children}
    </KhataContext.Provider>
  );
};

export const useKhata = () => {
  const context = useContext(KhataContext);
  if (!context) {
    throw new Error('useKhata must be used within a KhataProvider');
  }
  return context;
};
