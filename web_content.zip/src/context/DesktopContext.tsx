import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppWindow, CustomAppIconData, NotificationItem, WindowPosition, WindowSize } from '../types/desktop';
import { DESKTOP_APPS } from '../data/appsList';
import { generateDefaultBirdIcon } from '../services/iconGenerator';

interface DesktopContextType {
  openWindows: AppWindow[];
  activeWindowId: string | null;
  openApp: (appId: string) => void;
  closeWindow: (id: string) => void;
  minimizeWindow: (id: string) => void;
  maximizeWindow: (id: string) => void;
  restoreWindow: (id: string) => void;
  bringToFront: (id: string) => void;
  updateWindowPosition: (id: string, pos: WindowPosition) => void;
  updateWindowSize: (id: string, size: WindowSize) => void;
  minimizeAll: () => void;
  
  isStartMenuOpen: boolean;
  toggleStartMenu: () => void;
  closeStartMenu: () => void;
  
  isActionCenterOpen: boolean;
  toggleActionCenter: () => void;
  closeActionCenter: () => void;
  
  isLockScreenOpen: boolean;
  setLockScreenOpen: (val: boolean) => void;
  
  theme: 'dark' | 'light';
  setTheme: (t: 'dark' | 'light') => void;
  
  taskbarAlignment: 'center' | 'left';
  setTaskbarAlignment: (a: 'center' | 'left') => void;
  
  wallpaper: string;
  setWallpaper: (wp: string) => void;
  
  customIcon: CustomAppIconData | null;
  setCustomIcon: (icon: CustomAppIconData | null) => void;
  
  notifications: NotificationItem[];
  addNotification: (n: { title: string; message: string; type?: 'info' | 'success' | 'warning' | 'error' }) => void;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;
  
  volume: number;
  setVolume: (v: number) => void;
  brightness: number;
  setBrightness: (b: number) => void;
  
  quickSettings: {
    wifi: boolean;
    bluetooth: boolean;
    airplaneMode: boolean;
    batterySaver: boolean;
    nightLight: boolean;
    focusMode: boolean;
  };
  toggleQuickSetting: (key: keyof DesktopContextType['quickSettings']) => void;
}

const DesktopContext = createContext<DesktopContextType | undefined>(undefined);

// Default Bloom Wallpaper
export const DEFAULT_WALLPAPERS = [
  {
    id: 'bloom-blue',
    name: 'Windows 11 Bloom Blue',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1920&q=80'
  },
  {
    id: 'bloom-dark',
    name: 'Windows 11 Bloom Dark',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1920&q=80&sat=-100&bri=-30'
  },
  {
    id: 'sunset-cyber',
    name: 'Neon Horizon',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80'
  },
  {
    id: 'minimal-grid',
    name: 'Android Studio Tech',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1920&q=80'
  }
];

export const DesktopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [openWindows, setOpenWindows] = useState<AppWindow[]>([
    // Auto-launch APK Exporter & App Icon Studio on start
    {
      id: 'win-init-exporter',
      appId: 'project-exporter',
      title: 'APK Builder & Exporter',
      icon: 'Package',
      state: 'normal',
      position: { x: 70, y: 40 },
      size: { width: 780, height: 580 },
      zIndex: 10
    }
  ]);
  const [activeWindowId, setActiveWindowId] = useState<string | null>('win-init-exporter');
  const [maxZIndex, setMaxZIndex] = useState(15);
  
  const [isStartMenuOpen, setIsStartMenuOpen] = useState(false);
  const [isActionCenterOpen, setIsActionCenterOpen] = useState(false);
  const [isLockScreenOpen, setIsLockScreenOpen] = useState(false);
  
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [taskbarAlignment, setTaskbarAlignment] = useState<'center' | 'left'>('center');
  const [wallpaper, setWallpaper] = useState(DEFAULT_WALLPAPERS[0].url);
  const [customIcon, setCustomIcon] = useState<CustomAppIconData | null>(null);

  const [volume, setVolume] = useState(85);
  const [brightness, setBrightness] = useState(90);

  const [quickSettings, setQuickSettings] = useState({
    wifi: true,
    bluetooth: true,
    airplaneMode: false,
    batterySaver: false,
    nightLight: false,
    focusMode: false
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      title: 'Bird PC Initialized',
      message: 'Native Android project com.birdbase.app is ready for export and compilation.',
      time: 'Just now',
      read: false,
      type: 'info'
    },
    {
      id: 'notif-2',
      title: 'App Icon Ready',
      message: 'Default Cowboy Penguin mascot loaded. You can upload any custom icon in Settings.',
      time: '1m ago',
      read: false,
      type: 'success'
    }
  ]);

  // Load default mascot icon on start
  useEffect(() => {
    try {
      const defIcon = generateDefaultBirdIcon();
      setCustomIcon(defIcon);
    } catch (e) {
      console.warn('Default icon generation:', e);
    }
  }, []);

  const openApp = (appId: string) => {
    setIsStartMenuOpen(false);
    
    // Check if app window already open
    const existing = openWindows.find(w => w.appId === appId);
    if (existing) {
      if (existing.state === 'minimized') {
        setOpenWindows(prev => prev.map(w => w.id === existing.id ? { ...w, state: 'normal' } : w));
      }
      bringToFront(existing.id);
      return;
    }

    const appDef = DESKTOP_APPS.find(a => a.id === appId);
    if (!appDef) return;

    const newZ = maxZIndex + 1;
    setMaxZIndex(newZ);

    // Stagger window positions
    const offsetIndex = (openWindows.length % 5) * 30;
    const initialWidth = Math.min(appDef.defaultWidth || 760, window.innerWidth - 60);
    const initialHeight = Math.min(appDef.defaultHeight || 540, window.innerHeight - 120);

    const newWindow: AppWindow = {
      id: `win-${appId}-${Date.now()}`,
      appId,
      title: appDef.name,
      icon: appDef.icon,
      state: 'normal',
      position: {
        x: Math.max(20, Math.min(60 + offsetIndex, window.innerWidth - initialWidth - 30)),
        y: Math.max(30, Math.min(40 + offsetIndex, window.innerHeight - initialHeight - 70))
      },
      size: {
        width: initialWidth,
        height: initialHeight
      },
      zIndex: newZ
    };

    setOpenWindows(prev => [...prev, newWindow]);
    setActiveWindowId(newWindow.id);
  };

  const closeWindow = (id: string) => {
    setOpenWindows(prev => prev.filter(w => w.id !== id));
    if (activeWindowId === id) {
      setActiveWindowId(null);
    }
  };

  const minimizeWindow = (id: string) => {
    setOpenWindows(prev => prev.map(w => w.id === id ? { ...w, state: 'minimized' } : w));
    if (activeWindowId === id) {
      setActiveWindowId(null);
    }
  };

  const maximizeWindow = (id: string) => {
    setOpenWindows(prev => prev.map(w => w.id === id ? { ...w, state: 'maximized' } : w));
    bringToFront(id);
  };

  const restoreWindow = (id: string) => {
    setOpenWindows(prev => prev.map(w => w.id === id ? { ...w, state: 'normal' } : w));
    bringToFront(id);
  };

  const bringToFront = (id: string) => {
    const newZ = maxZIndex + 1;
    setMaxZIndex(newZ);
    setOpenWindows(prev => prev.map(w => w.id === id ? { ...w, zIndex: newZ, state: w.state === 'minimized' ? 'normal' : w.state } : w));
    setActiveWindowId(id);
  };

  const updateWindowPosition = (id: string, pos: WindowPosition) => {
    setOpenWindows(prev => prev.map(w => w.id === id ? { ...w, position: pos } : w));
  };

  const updateWindowSize = (id: string, size: WindowSize) => {
    setOpenWindows(prev => prev.map(w => w.id === id ? { ...w, size } : w));
  };

  const minimizeAll = () => {
    const hasUnminimized = openWindows.some(w => w.state !== 'minimized');
    if (hasUnminimized) {
      setOpenWindows(prev => prev.map(w => ({ ...w, state: 'minimized' })));
      setActiveWindowId(null);
    } else {
      setOpenWindows(prev => prev.map(w => ({ ...w, state: 'normal' })));
    }
  };

  const toggleStartMenu = () => {
    setIsStartMenuOpen(prev => !prev);
    setIsActionCenterOpen(false);
  };

  const closeStartMenu = () => setIsStartMenuOpen(false);

  const toggleActionCenter = () => {
    setIsActionCenterOpen(prev => !prev);
    setIsStartMenuOpen(false);
  };

  const closeActionCenter = () => setIsActionCenterOpen(false);

  const addNotification = (n: { title: string; message: string; type?: 'info' | 'success' | 'warning' | 'error' }) => {
    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: n.title,
      message: n.message,
      time: 'Just now',
      read: false,
      type: n.type || 'info'
    };
    setNotifications(prev => [newNotif, ...prev.slice(0, 19)]);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  const toggleQuickSetting = (key: keyof DesktopContextType['quickSettings']) => {
    setQuickSettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  return (
    <DesktopContext.Provider
      value={{
        openWindows,
        activeWindowId,
        openApp,
        closeWindow,
        minimizeWindow,
        maximizeWindow,
        restoreWindow,
        bringToFront,
        updateWindowPosition,
        updateWindowSize,
        minimizeAll,
        isStartMenuOpen,
        toggleStartMenu,
        closeStartMenu,
        isActionCenterOpen,
        toggleActionCenter,
        closeActionCenter,
        isLockScreenOpen,
        setLockScreenOpen: setIsLockScreenOpen,
        theme,
        setTheme,
        taskbarAlignment,
        setTaskbarAlignment,
        wallpaper,
        setWallpaper,
        customIcon,
        setCustomIcon,
        notifications,
        addNotification,
        removeNotification,
        clearNotifications,
        volume,
        setVolume,
        brightness,
        setBrightness,
        quickSettings,
        toggleQuickSetting
      }}
    >
      {children}
    </DesktopContext.Provider>
  );
};

export const useDesktop = () => {
  const context = useContext(DesktopContext);
  if (!context) {
    throw new Error('useDesktop must be used within a DesktopProvider');
  }
  return context;
};
