import React, {
  createContext,
  useContext,
  useReducer,
  useEffect,
  useCallback,
  useMemo,
  ReactNode,
} from "react";
import {
  ThemeAccent,
  UIThemeStyle,
  DisplayScaleConfig,
  DisplayScalePreset,
  PaperNotebookConfig,
  PaperThemeId,
  CanvasThemeStyle,
  SectionItem,
  ActiveTab,
  UserProfile,
  NavBarConfig,
  NavBarPosition,
} from "../types";
import {
  THEME_ACCENTS,
  UI_THEME_STYLE_CONFIGS,
  applyThemeAccentToDocument,
} from "../utils/theme";
import {
  DEFAULT_DISPLAY_SCALE_CONFIG,
  SCALE_PRESETS,
} from "../utils/displayScaleManager";
import {
  DEFAULT_PAPER_NOTEBOOK_CONFIG,
  PAPER_THEME_DEFINITIONS,
} from "../utils/paperNotebookConfig";
import {
  DEFAULT_NAVBAR_CONFIG,
} from "../utils/navBarConfig";
import {
  DEFAULT_SECTIONS,
  DEFAULT_MENU_ORDER,
  DEFAULT_PROFILE,
  STORAGE_KEYS,
  getStoredSections,
  saveStoredSections,
  getStoredMenuOrder,
  saveStoredMenuOrder,
  getStoredUserProfile,
  saveUserProfile,
  getThemePreference,
  saveThemePreference,
  getThemeAccentPreference,
  saveThemeAccentPreference,
  getStoredUIThemeStyle,
  saveStoredUIThemeStyle,
  safeSetItem,
} from "../utils/storage";
import {
  NoteFlowThemeStyle,
  NoteFlowTokens,
  getNoteFlowTokens,
} from "../utils/themeTokens";
import { ThemeStateController } from "../utils/themeStateController";
import {
  TroubleshootingEngine,
  DiagnosticHealthMetrics,
  DetailedDiagnosticReport,
  LevelRepairResult,
} from "../utils/TroubleshootingEngine";

// Current State Version
export const CURRENT_STATE_VERSION = TroubleshootingEngine.CURRENT_VERSION;

// Storage Keys
const STORAGE_KEY_STATE_VERSION = "noteflow_state_version";
const STORAGE_KEY_SCALE_CONFIG = "noteflow_display_scale_config_v2";
const STORAGE_KEY_PAPER_CONFIG = "noteflow_paper_notebook_config_v2";
const STORAGE_KEY_CANVAS_THEME = "noteflow_canvas_theme_style_v1";
const STORAGE_KEY_NAVBAR_CONFIG = "noteflow_navbar_config_v2";
const STORAGE_KEY_AUTO_HEAL_LOGS = "noteflow_auto_heal_logs_v2";

export interface DiagnosticLog {
  id: string;
  type: "info" | "success" | "warning" | "error";
  message: string;
  timestamp: string;
  source?: string;
}

export interface AutoRepairResult {
  success: boolean;
  fixedIssues: string[];
  repairedModules: string[];
  timestamp: string;
}

export interface DiagnosticCommandResult {
  success: boolean;
  command: string;
  feedback: string;
  actionsTaken: string[];
}

export interface GlobalState {
  version: string;
  // Theme & Appearance
  darkMode: boolean;
  themeAccent: ThemeAccent;
  uiThemeStyle: UIThemeStyle;
  noteFlowTheme: NoteFlowThemeStyle;
  noteFlowTokens: NoteFlowTokens;
  // Categorical Responsive Scale
  scaleConfig: DisplayScaleConfig;
  // ColorNote Ruled Paper & Canvas
  paperConfig: PaperNotebookConfig;
  canvasThemeStyle: CanvasThemeStyle;
  // Dynamic Navigation Bar Architecture
  navBarConfig: NavBarConfig;
  // Sections & Categories
  sections: SectionItem[];
  // Menu Navigation Order
  menuOrder: ActiveTab[];
  // User Profile
  profile: UserProfile;
  // Diagnostics & Auto-Heal
  isOnline: boolean;
  lastAutoHealTime: string | null;
  healthScore: number;
  diagnosticLogs: DiagnosticLog[];
  isRepairing: boolean;
}

type GlobalAction =
  | { type: "SET_DARK_MODE"; payload: boolean }
  | { type: "SET_THEME_ACCENT"; payload: ThemeAccent }
  | { type: "SET_UI_THEME_STYLE"; payload: UIThemeStyle }
  | { type: "SET_NOTEFLOW_THEME"; payload: NoteFlowThemeStyle }
  | { type: "UPDATE_SCALE_CONFIG"; payload: Partial<DisplayScaleConfig> }
  | { type: "SET_SCALE_PRESET"; payload: DisplayScalePreset }
  | { type: "RESET_SCALE_CONFIG" }
  | { type: "UPDATE_PAPER_CONFIG"; payload: Partial<PaperNotebookConfig> }
  | { type: "SET_PAPER_THEME"; payload: PaperThemeId }
  | { type: "SET_CANVAS_THEME"; payload: CanvasThemeStyle }
  | { type: "UPDATE_NAVBAR_CONFIG"; payload: Partial<NavBarConfig> }
  | { type: "RESET_NAVBAR_CONFIG" }
  | { type: "SET_SECTIONS"; payload: SectionItem[] }
  | { type: "ADD_SECTION"; payload: SectionItem }
  | { type: "UPDATE_SECTION"; payload: { id: string; name: string; description?: string } }
  | { type: "DELETE_SECTION"; payload: string }
  | { type: "RESET_SECTIONS" }
  | { type: "SET_MENU_ORDER"; payload: ActiveTab[] }
  | { type: "RESET_MENU_ORDER" }
  | { type: "UPDATE_PROFILE"; payload: Partial<UserProfile> }
  | { type: "SET_ONLINE_STATUS"; payload: boolean }
  | { type: "SET_AUTO_HEAL_RESULT"; payload: { timestamp: string; logs: DiagnosticLog[]; healthScore?: number } }
  | { type: "ADD_DIAGNOSTIC_LOG"; payload: Omit<DiagnosticLog, "id" | "timestamp"> }
  | { type: "CLEAR_DIAGNOSTIC_LOGS" }
  | { type: "SET_REPAIRING"; payload: boolean }
  | { type: "REHYDRATE_STATE"; payload: Partial<GlobalState> };

// Safe Schema Migration Function
function migrateAndLoadInitialState(): GlobalState {
  let storedVersion = localStorage.getItem(STORAGE_KEY_STATE_VERSION);
  const initialLogs: DiagnosticLog[] = [];

  // Migration trigger if version missing or older
  if (!storedVersion || storedVersion !== CURRENT_STATE_VERSION) {
    console.info(
      `[NoteFlow GlobalState] Schema migration executing: ${storedVersion || "none"} -> ${CURRENT_STATE_VERSION}`
    );
    safeSetItem(STORAGE_KEY_STATE_VERSION, CURRENT_STATE_VERSION);
    initialLogs.push({
      id: `mig-${Date.now()}`,
      type: "info",
      message: `Şema Sürümü Güncellendi (${storedVersion || "1.0"} ➔ ${CURRENT_STATE_VERSION})`,
      timestamp: new Date().toLocaleTimeString("tr-TR"),
      source: "MigrationEngine",
    });
  }

  // 1. Theme state
  const darkMode = getThemePreference();
  const themeAccent = getThemeAccentPreference();
  const uiThemeStyle = getStoredUIThemeStyle();
  const noteFlowTheme = ThemeStateController.getTheme();
  const noteFlowTokens = getNoteFlowTokens(noteFlowTheme);

  // 2. Scale state with Deep Schema Validation
  let scaleConfig = DEFAULT_DISPLAY_SCALE_CONFIG;
  try {
    const rawScale = localStorage.getItem(STORAGE_KEY_SCALE_CONFIG);
    if (rawScale) {
      scaleConfig = TroubleshootingEngine.validateDisplayScaleConfig(JSON.parse(rawScale));
    }
  } catch {
    scaleConfig = DEFAULT_DISPLAY_SCALE_CONFIG;
  }

  // 3. Paper state with Deep Schema Validation
  let paperConfig = DEFAULT_PAPER_NOTEBOOK_CONFIG;
  try {
    const rawPaper = localStorage.getItem(STORAGE_KEY_PAPER_CONFIG);
    if (rawPaper) {
      paperConfig = TroubleshootingEngine.validatePaperNotebookConfig(JSON.parse(rawPaper));
    }
  } catch {
    paperConfig = DEFAULT_PAPER_NOTEBOOK_CONFIG;
  }

  // 4. Canvas Theme
  let canvasThemeStyle: CanvasThemeStyle = "hybrid_white";
  try {
    const rawCanvas = localStorage.getItem(STORAGE_KEY_CANVAS_THEME);
    if (rawCanvas && ["hybrid_white", "zen_sapphire", "fluid_parchment", "timeline_chronicle"].includes(rawCanvas)) {
      canvasThemeStyle = rawCanvas as CanvasThemeStyle;
    }
  } catch {
    canvasThemeStyle = "hybrid_white";
  }

  // 4.5 Navigation Bar Config with Deep Schema Validation
  let navBarConfig: NavBarConfig = DEFAULT_NAVBAR_CONFIG;
  try {
    const rawNav = localStorage.getItem(STORAGE_KEY_NAVBAR_CONFIG);
    if (rawNav) {
      navBarConfig = TroubleshootingEngine.validateNavBarConfig(JSON.parse(rawNav));
    }
  } catch {
    navBarConfig = DEFAULT_NAVBAR_CONFIG;
  }

  // 5. Sections with Deep Schema Validation
  let sections = DEFAULT_SECTIONS;
  try {
    const rawSec = localStorage.getItem(STORAGE_KEYS.SECTIONS);
    if (rawSec) {
      sections = TroubleshootingEngine.validateSections(JSON.parse(rawSec));
    }
  } catch {
    sections = DEFAULT_SECTIONS;
  }

  // 6. Menu order with Deep Schema Validation
  let menuOrder = DEFAULT_MENU_ORDER;
  try {
    const rawOrder = localStorage.getItem("noteflow_menu_order");
    if (rawOrder) {
      menuOrder = TroubleshootingEngine.validateMenuOrder(JSON.parse(rawOrder));
    }
  } catch {
    menuOrder = DEFAULT_MENU_ORDER;
  }

  // 7. Profile
  const profile = getStoredUserProfile();

  // Initial Diagnostic Logs
  try {
    const rawLogs = localStorage.getItem(STORAGE_KEY_AUTO_HEAL_LOGS);
    if (rawLogs) {
      const parsed = JSON.parse(rawLogs);
      if (Array.isArray(parsed)) {
        initialLogs.push(...parsed.slice(0, 15));
      }
    }
  } catch {
    // ignore
  }

  return {
    version: CURRENT_STATE_VERSION,
    darkMode,
    themeAccent,
    uiThemeStyle,
    noteFlowTheme,
    noteFlowTokens,
    scaleConfig,
    paperConfig,
    canvasThemeStyle,
    navBarConfig,
    sections,
    menuOrder,
    profile,
    isOnline: typeof navigator !== "undefined" ? navigator.onLine : true,
    lastAutoHealTime: null,
    healthScore: 98,
    diagnosticLogs: initialLogs,
    isRepairing: false,
  };
}

// Global State Reducer
function globalStateReducer(state: GlobalState, action: GlobalAction): GlobalState {
  switch (action.type) {
    case "SET_DARK_MODE":
      return { ...state, darkMode: action.payload };

    case "SET_THEME_ACCENT":
      return { ...state, themeAccent: action.payload };

    case "SET_UI_THEME_STYLE":
      return { ...state, uiThemeStyle: action.payload };

    case "SET_NOTEFLOW_THEME":
      return {
        ...state,
        noteFlowTheme: action.payload,
        noteFlowTokens: getNoteFlowTokens(action.payload),
      };

    case "UPDATE_SCALE_CONFIG": {
      const updatedScale = TroubleshootingEngine.validateDisplayScaleConfig({
        ...state.scaleConfig,
        ...action.payload,
      });
      return { ...state, scaleConfig: updatedScale };
    }

    case "SET_SCALE_PRESET": {
      const presetValues = SCALE_PRESETS[action.payload];
      if (!presetValues) return state;
      const updated = TroubleshootingEngine.validateDisplayScaleConfig({
        ...state.scaleConfig,
        ...presetValues.config,
      });
      return { ...state, scaleConfig: updated };
    }

    case "RESET_SCALE_CONFIG":
      return { ...state, scaleConfig: DEFAULT_DISPLAY_SCALE_CONFIG };

    case "UPDATE_PAPER_CONFIG": {
      const updatedPaper = TroubleshootingEngine.validatePaperNotebookConfig({
        ...state.paperConfig,
        ...action.payload,
      });
      return { ...state, paperConfig: updatedPaper };
    }

    case "SET_PAPER_THEME": {
      const updatedPaper = TroubleshootingEngine.validatePaperNotebookConfig({
        ...state.paperConfig,
        activeTheme: action.payload,
      });
      return { ...state, paperConfig: updatedPaper };
    }

    case "SET_CANVAS_THEME":
      return { ...state, canvasThemeStyle: action.payload };

    case "UPDATE_NAVBAR_CONFIG": {
      const updatedNav = TroubleshootingEngine.validateNavBarConfig({
        ...state.navBarConfig,
        ...action.payload,
      });
      return { ...state, navBarConfig: updatedNav };
    }

    case "RESET_NAVBAR_CONFIG":
      return { ...state, navBarConfig: DEFAULT_NAVBAR_CONFIG };

    case "SET_SECTIONS": {
      const sanitized = TroubleshootingEngine.validateSections(action.payload);
      saveStoredSections(sanitized);
      return { ...state, sections: sanitized };
    }

    case "ADD_SECTION": {
      const updated = [action.payload, ...state.sections];
      saveStoredSections(updated);
      return { ...state, sections: updated };
    }

    case "UPDATE_SECTION": {
      const updated = state.sections.map((s) =>
        s.id === action.payload.id
          ? {
              ...s,
              name: action.payload.name,
              description: action.payload.description !== undefined ? action.payload.description : s.description,
            }
          : s
      );
      saveStoredSections(updated);
      return { ...state, sections: updated };
    }

    case "DELETE_SECTION": {
      const updated = state.sections.filter((s) => s.id !== action.payload);
      saveStoredSections(updated);
      return { ...state, sections: updated };
    }

    case "RESET_SECTIONS": {
      saveStoredSections(DEFAULT_SECTIONS);
      return { ...state, sections: DEFAULT_SECTIONS };
    }

    case "SET_MENU_ORDER": {
      const validated = TroubleshootingEngine.validateMenuOrder(action.payload);
      saveStoredMenuOrder(validated);
      return { ...state, menuOrder: validated };
    }

    case "RESET_MENU_ORDER": {
      saveStoredMenuOrder(DEFAULT_MENU_ORDER);
      return { ...state, menuOrder: DEFAULT_MENU_ORDER };
    }

    case "UPDATE_PROFILE": {
      const updated = { ...state.profile, ...action.payload };
      saveUserProfile(updated);
      return { ...state, profile: updated };
    }

    case "SET_ONLINE_STATUS":
      return { ...state, isOnline: action.payload };

    case "SET_AUTO_HEAL_RESULT": {
      const logs = [...action.payload.logs, ...state.diagnosticLogs].slice(0, 35);
      safeSetItem(STORAGE_KEY_AUTO_HEAL_LOGS, JSON.stringify(logs));
      return {
        ...state,
        lastAutoHealTime: action.payload.timestamp,
        diagnosticLogs: logs,
        healthScore: action.payload.healthScore ?? 100,
      };
    }

    case "ADD_DIAGNOSTIC_LOG": {
      const newLog: DiagnosticLog = {
        id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        timestamp: new Date().toLocaleTimeString("tr-TR"),
        ...action.payload,
      };
      const updatedLogs = [newLog, ...state.diagnosticLogs].slice(0, 35);
      safeSetItem(STORAGE_KEY_AUTO_HEAL_LOGS, JSON.stringify(updatedLogs));
      return {
        ...state,
        diagnosticLogs: updatedLogs,
      };
    }

    case "CLEAR_DIAGNOSTIC_LOGS": {
      localStorage.removeItem(STORAGE_KEY_AUTO_HEAL_LOGS);
      return { ...state, diagnosticLogs: [] };
    }

    case "SET_REPAIRING":
      return { ...state, isRepairing: action.payload };

    case "REHYDRATE_STATE":
      return { ...state, ...action.payload };

    default:
      return state;
  }
}

// React Context Interface
export interface GlobalContextType {
  state: GlobalState;
  // Theme & Appearance
  setDarkMode: (dark: boolean) => void;
  toggleDarkMode: () => void;
  setThemeAccent: (accent: ThemeAccent) => void;
  setUiThemeStyle: (style: UIThemeStyle) => void;
  setNoteFlowTheme: (theme: NoteFlowThemeStyle) => void;
  // Display Scale
  updateScaleConfig: (partial: Partial<DisplayScaleConfig>) => void;
  setScalePreset: (preset: DisplayScalePreset) => void;
  resetScaleConfig: () => void;
  // Ruled Paper & Canvas
  updatePaperConfig: (partial: Partial<PaperNotebookConfig>) => void;
  setPaperTheme: (theme: PaperThemeId) => void;
  setPaperFontSize: (size: number) => void;
  setPaperLineHeightRatio: (ratio: number) => void;
  toggleRuledLines: () => void;
  toggleMarginLine: () => void;
  setCanvasThemeStyle: (style: CanvasThemeStyle) => void;
  // Dynamic Navigation Bar
  updateNavBarConfig: (partial: Partial<NavBarConfig>) => void;
  resetNavBarConfig: () => void;
  // Sections / Categories
  addSection: (name: string, description?: string, color?: string, icon?: string) => SectionItem;
  updateSection: (id: string, name: string, description?: string) => void;
  deleteSection: (id: string) => void;
  reorderSections: (newSections: SectionItem[]) => void;
  resetSections: () => void;
  // Menu Navigation Order
  updateMenuOrder: (order: ActiveTab[]) => void;
  resetMenuOrder: () => void;
  // User Profile
  updateProfile: (updated: Partial<UserProfile>) => void;
  // Troubleshooting & Self-Healing Engine
  runAutoRepair: () => Promise<AutoRepairResult>;
  runLevel1Repair: () => Promise<LevelRepairResult>;
  runLevel2Repair: () => Promise<LevelRepairResult>;
  runLevel3Repair: () => Promise<LevelRepairResult>;
  runFullDiagnosticsAudit: () => DiagnosticHealthMetrics;
  generateDiagnosticReport: () => DetailedDiagnosticReport;
  triggerOnlineHeal: () => Promise<boolean>;
  executeDiagnosticCommand: (cmd: string) => DiagnosticCommandResult;
  clearDiagnosticLogs: () => void;
  addDiagnosticLog: (type: DiagnosticLog["type"], message: string, source?: string) => void;
}

const GlobalContext = createContext<GlobalContextType | null>(null);

export const GlobalStateProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(globalStateReducer, null, migrateAndLoadInitialState);

  // Synchronous DOM CSS Variable & Class Sync
  useEffect(() => {
    // 1. Dark mode class
    if (state.darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    saveThemePreference(state.darkMode);

    // 2. Theme accent
    saveThemeAccentPreference(state.themeAccent);
    applyThemeAccentToDocument(state.themeAccent);

    // 3. UI Theme style
    saveStoredUIThemeStyle(state.uiThemeStyle);

    // 4. NoteFlow theme tokens
    ThemeStateController.setTheme(state.noteFlowTheme);
  }, [state.darkMode, state.themeAccent, state.uiThemeStyle, state.noteFlowTheme]);

  // Synchronize Display Scale CSS Variables
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--scale-ui", state.scaleConfig.uiScale.toString());
    root.style.setProperty("--scale-typography", state.scaleConfig.typographyScale.toString());
    root.style.setProperty("--scale-tool-dock", state.scaleConfig.toolDockScale.toString());
    root.style.setProperty("--scale-canvas", state.scaleConfig.canvasScale.toString());
    safeSetItem(STORAGE_KEY_SCALE_CONFIG, JSON.stringify(state.scaleConfig));
  }, [state.scaleConfig]);

  // Synchronize Paper & Canvas config
  useEffect(() => {
    safeSetItem(STORAGE_KEY_PAPER_CONFIG, JSON.stringify(state.paperConfig));
  }, [state.paperConfig]);

  useEffect(() => {
    safeSetItem(STORAGE_KEY_CANVAS_THEME, state.canvasThemeStyle);
  }, [state.canvasThemeStyle]);

  // Synchronize Navigation Bar config
  useEffect(() => {
    safeSetItem(STORAGE_KEY_NAVBAR_CONFIG, JSON.stringify(state.navBarConfig));
  }, [state.navBarConfig]);

  // Online / Offline Auto-Heal Daemon Listener
  useEffect(() => {
    const handleOnline = () => {
      dispatch({ type: "SET_ONLINE_STATUS", payload: true });
      dispatch({
        type: "ADD_DIAGNOSTIC_LOG",
        payload: {
          type: "success",
          message: "Ağ Bağlantısı Kuruldu: Çevrimiçi Kendi Kendini Onarma (Online Auto-Heal Daemon) tetiklendi.",
          source: "AutoHealDaemon",
        },
      });
      // Silent auto-heal
      TroubleshootingEngine.executeLevel1SoftRepair().then((res) => {
        dispatch({
          type: "SET_AUTO_HEAL_RESULT",
          payload: {
            timestamp: res.timestamp,
            logs: [
              {
                id: `online-heal-${Date.now()}`,
                type: "success",
                message: "Online Auto-Heal: UI durumları ve askıda kalan senkronizasyon kilitleri çözüldü.",
                timestamp: res.timestamp,
                source: "AutoHealDaemon",
              },
            ],
            healthScore: 100,
          },
        });
      });
    };

    const handleOffline = () => {
      dispatch({ type: "SET_ONLINE_STATUS", payload: false });
      dispatch({
        type: "ADD_DIAGNOSTIC_LOG",
        payload: {
          type: "warning",
          message: "Çevrimdışı moda geçildi. Tüm notlar ve şifreli kasa yerel depolama ile korunuyor.",
          source: "NetworkEngine",
        },
      });
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Theme Actions
  const setDarkMode = useCallback((dark: boolean) => {
    dispatch({ type: "SET_DARK_MODE", payload: dark });
  }, []);

  const toggleDarkMode = useCallback(() => {
    dispatch({ type: "SET_DARK_MODE", payload: !state.darkMode });
  }, [state.darkMode]);

  const setThemeAccent = useCallback((accent: ThemeAccent) => {
    dispatch({ type: "SET_THEME_ACCENT", payload: accent });
  }, []);

  const setUiThemeStyle = useCallback((style: UIThemeStyle) => {
    dispatch({ type: "SET_UI_THEME_STYLE", payload: style });
  }, []);

  const setNoteFlowTheme = useCallback((theme: NoteFlowThemeStyle) => {
    dispatch({ type: "SET_NOTEFLOW_THEME", payload: theme });
  }, []);

  // Scale Actions
  const updateScaleConfig = useCallback((partial: Partial<DisplayScaleConfig>) => {
    dispatch({ type: "UPDATE_SCALE_CONFIG", payload: partial });
  }, []);

  const setScalePreset = useCallback((preset: DisplayScalePreset) => {
    dispatch({ type: "SET_SCALE_PRESET", payload: preset });
  }, []);

  const resetScaleConfig = useCallback(() => {
    dispatch({ type: "RESET_SCALE_CONFIG" });
  }, []);

  // Paper & Canvas Actions
  const updatePaperConfig = useCallback((partial: Partial<PaperNotebookConfig>) => {
    dispatch({ type: "UPDATE_PAPER_CONFIG", payload: partial });
  }, []);

  const setPaperTheme = useCallback((theme: PaperThemeId) => {
    dispatch({ type: "SET_PAPER_THEME", payload: theme });
  }, []);

  const setPaperFontSize = useCallback((size: number) => {
    dispatch({ type: "UPDATE_PAPER_CONFIG", payload: { fontSize: size } });
  }, []);

  const setPaperLineHeightRatio = useCallback((ratio: number) => {
    dispatch({ type: "UPDATE_PAPER_CONFIG", payload: { lineHeightRatio: ratio } });
  }, []);

  const toggleRuledLines = useCallback(() => {
    dispatch({
      type: "UPDATE_PAPER_CONFIG",
      payload: { showRuledLines: !state.paperConfig.showRuledLines },
    });
  }, [state.paperConfig.showRuledLines]);

  const toggleMarginLine = useCallback(() => {
    dispatch({
      type: "UPDATE_PAPER_CONFIG",
      payload: { showMarginLine: !state.paperConfig.showMarginLine },
    });
  }, [state.paperConfig.showMarginLine]);

  const setCanvasThemeStyle = useCallback((style: CanvasThemeStyle) => {
    dispatch({ type: "SET_CANVAS_THEME", payload: style });
  }, []);

  // Navigation Bar Actions
  const updateNavBarConfig = useCallback((partial: Partial<NavBarConfig>) => {
    dispatch({ type: "UPDATE_NAVBAR_CONFIG", payload: partial });
  }, []);

  const resetNavBarConfig = useCallback(() => {
    dispatch({ type: "RESET_NAVBAR_CONFIG" });
  }, []);

  // Sections Actions
  const addSection = useCallback(
    (name: string, description?: string, color?: string, icon?: string): SectionItem => {
      const newSec: SectionItem = {
        id: `sec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        name: name.trim(),
        description: description?.trim() || "Özel not kategorisi",
        color: color || "teal",
        icon: icon || "Folder",
        isDefault: false,
      };
      dispatch({ type: "ADD_SECTION", payload: newSec });
      return newSec;
    },
    []
  );

  const updateSection = useCallback((id: string, name: string, description?: string) => {
    dispatch({ type: "UPDATE_SECTION", payload: { id, name, description } });
  }, []);

  const deleteSection = useCallback((id: string) => {
    dispatch({ type: "DELETE_SECTION", payload: id });
  }, []);

  const reorderSections = useCallback((newSections: SectionItem[]) => {
    dispatch({ type: "SET_SECTIONS", payload: newSections });
  }, []);

  const resetSections = useCallback(() => {
    dispatch({ type: "RESET_SECTIONS" });
  }, []);

  // Menu Order Actions
  const updateMenuOrder = useCallback((order: ActiveTab[]) => {
    dispatch({ type: "SET_MENU_ORDER", payload: order });
  }, []);

  const resetMenuOrder = useCallback(() => {
    dispatch({ type: "RESET_MENU_ORDER" });
  }, []);

  // Profile Action
  const updateProfile = useCallback((updated: Partial<UserProfile>) => {
    dispatch({ type: "UPDATE_PROFILE", payload: updated });
  }, []);

  // Diagnostics & Self-Healing Engine
  const addDiagnosticLog = useCallback((type: DiagnosticLog["type"], message: string, source?: string) => {
    dispatch({ type: "ADD_DIAGNOSTIC_LOG", payload: { type, message, source } });
  }, []);

  const clearDiagnosticLogs = useCallback(() => {
    dispatch({ type: "CLEAR_DIAGNOSTIC_LOGS" });
  }, []);

  const runFullDiagnosticsAudit = useCallback((): DiagnosticHealthMetrics => {
    return TroubleshootingEngine.runFullDiagnosticsAudit();
  }, []);

  const generateDiagnosticReport = useCallback((): DetailedDiagnosticReport => {
    return TroubleshootingEngine.generateDiagnosticReport(state, state.diagnosticLogs);
  }, [state]);

  // Level 1: Soft Repair
  const runLevel1Repair = useCallback(async (): Promise<LevelRepairResult> => {
    dispatch({ type: "SET_REPAIRING", payload: true });
    const res = await TroubleshootingEngine.executeLevel1SoftRepair();
    dispatch({ type: "RESET_SCALE_CONFIG" });
    dispatch({ type: "UPDATE_PAPER_CONFIG", payload: DEFAULT_PAPER_NOTEBOOK_CONFIG });
    dispatch({
      type: "ADD_DIAGNOSTIC_LOG",
      payload: {
        type: "success",
        message: `Düzey 1 Soft Repair tamamlandı (${res.repairedModules.length} modül onarıldı, ${res.durationMs}ms). Notlar korundu.`,
        source: "Level1SoftRepair",
      },
    });
    dispatch({ type: "SET_REPAIRING", payload: false });
    return res;
  }, []);

  // Level 2: Re-Index & Re-Matrix
  const runLevel2Repair = useCallback(async (): Promise<LevelRepairResult> => {
    dispatch({ type: "SET_REPAIRING", payload: true });
    const res = await TroubleshootingEngine.executeLevel2ReIndexAndMatrix();
    const updatedSec = getStoredSections();
    dispatch({ type: "SET_SECTIONS", payload: updatedSec });
    dispatch({
      type: "ADD_DIAGNOSTIC_LOG",
      payload: {
        type: "success",
        message: `Düzey 2 Re-Index tamamlandı (${res.fixedItems.length} madde optimize edildi).`,
        source: "Level2ReIndex",
      },
    });
    dispatch({ type: "SET_REPAIRING", payload: false });
    return res;
  }, []);

  // Level 3: Reset UI Settings
  const runLevel3Repair = useCallback(async (): Promise<LevelRepairResult> => {
    dispatch({ type: "SET_REPAIRING", payload: true });
    const res = await TroubleshootingEngine.executeLevel3ResetUISettings();
    dispatch({ type: "SET_THEME_ACCENT", payload: "teal" });
    dispatch({ type: "SET_UI_THEME_STYLE", payload: "minimalist" });
    dispatch({ type: "SET_NOTEFLOW_THEME", payload: NoteFlowThemeStyle.Minimalist });
    dispatch({ type: "RESET_SCALE_CONFIG" });
    dispatch({ type: "RESET_NAVBAR_CONFIG" });
    dispatch({ type: "RESET_MENU_ORDER" });
    dispatch({
      type: "ADD_DIAGNOSTIC_LOG",
      payload: {
        type: "success",
        message: `Düzey 3 Fabrika UI Ayarlarına Dönüş tamamlandı. Tüm kullanıcı verileri %100 güvende.`,
        source: "Level3ResetUI",
      },
    });
    dispatch({ type: "SET_REPAIRING", payload: false });
    return res;
  }, []);

  // General Auto-Repair
  const runAutoRepair = useCallback(async (): Promise<AutoRepairResult> => {
    dispatch({ type: "SET_REPAIRING", payload: true });
    const level1 = await TroubleshootingEngine.executeLevel1SoftRepair();
    const level2 = await TroubleshootingEngine.executeLevel2ReIndexAndMatrix();

    applyThemeAccentToDocument(state.themeAccent);
    ThemeStateController.setTheme(state.noteFlowTheme);

    const now = new Date().toLocaleTimeString("tr-TR");
    const fixedIssues = [...level1.fixedItems, ...level2.fixedItems];
    const repairedModules = [...new Set([...level1.repairedModules, ...level2.repairedModules])];

    const logsToAdd: DiagnosticLog[] = [
      {
        id: `repair-${Date.now()}`,
        type: "success",
        message: `Tam Kendi Kendini İyileştirme tamamlandı (${repairedModules.length} modül denetlendi).`,
        timestamp: now,
        source: "SelfHealingDaemon",
      },
    ];

    dispatch({
      type: "SET_AUTO_HEAL_RESULT",
      payload: { timestamp: now, logs: logsToAdd, healthScore: 100 },
    });
    dispatch({ type: "SET_REPAIRING", payload: false });

    return {
      success: true,
      fixedIssues,
      repairedModules,
      timestamp: now,
    };
  }, [state.themeAccent, state.noteFlowTheme]);

  const triggerOnlineHeal = useCallback(async (): Promise<boolean> => {
    const res = await runAutoRepair();
    return res.success;
  }, [runAutoRepair]);

  // Diagnostic Prompt Executor
  const executeDiagnosticCommand = useCallback(
    (rawCmd: string): DiagnosticCommandResult => {
      const interpretation = TroubleshootingEngine.interpretDiagnosticCommand(rawCmd);
      const actionsTaken: string[] = [];

      switch (interpretation.matchedAction) {
        case "RESET_THEME":
          dispatch({ type: "SET_THEME_ACCENT", payload: "teal" });
          dispatch({ type: "SET_UI_THEME_STYLE", payload: "minimalist" });
          dispatch({ type: "SET_NOTEFLOW_THEME", payload: NoteFlowThemeStyle.Minimalist });
          actionsTaken.push("Tema 'Minimalist' ve vurgu rengi 'Zümrüt Teal' olarak sıfırlandı.");
          actionsTaken.push("Tailwind CSS kök değişkenleri yeniden uygulandı.");
          break;

        case "RESET_NAVBAR":
          dispatch({ type: "RESET_NAVBAR_CONFIG" });
          actionsTaken.push("Navigasyon çubuğu alt yapışık/yüzen dok ve 64dp güvenli boyutuna kilitlendi.");
          actionsTaken.push("Safe Area Insets padding hesaplaması sıfırlandı.");
          break;

        case "ALIGN_CANVAS":
          dispatch({ type: "UPDATE_PAPER_CONFIG", payload: DEFAULT_PAPER_NOTEBOOK_CONFIG });
          dispatch({ type: "SET_CANVAS_THEME", payload: "hybrid_white" });
          actionsTaken.push("Çizgili defter taban çizgisi (Baseline Grid) 17px/1.65x oranına kilitlendi.");
          actionsTaken.push("Tuval matrisi ve overlay koordinatları 1:1 hizalandı.");
          break;

        case "REINDEX_DB":
          dispatch({ type: "RESET_SECTIONS" });
          actionsTaken.push("5 temel kategori (Kişisel, İş, Fikirler, Projeler, Eğitim) yeniden indekslendi.");
          actionsTaken.push("Arama anahtarları ve etiket ilişkileri yeniden bağlandı.");
          break;

        case "FULL_CLEANUP":
          sessionStorage.clear();
          localStorage.removeItem("noteflow_last_crash_report");
          dispatch({ type: "RESET_SCALE_CONFIG" });
          actionsTaken.push("Geçici UI ve oturum önbellekleri temizlendi.");
          actionsTaken.push("Kullanıcı notları ve şifreli kasa %100 korundu.");
          break;

        default:
          actionsTaken.push(interpretation.description);
          actionsTaken.push("Tüm UI durumları, IndexedDB sağlık kontrolü ve DOM değişkenleri senkronize edildi.");
          break;
      }

      const feedback = `✓ Başarılı: [${rawCmd}] komutu yürütüldü (${actionsTaken.length} eylem tamamlandı).`;
      dispatch({
        type: "ADD_DIAGNOSTIC_LOG",
        payload: {
          type: "success",
          message: feedback,
          source: `PromptExecutor: "${rawCmd}"`,
        },
      });

      return {
        success: true,
        command: rawCmd,
        feedback,
        actionsTaken,
      };
    },
    []
  );

  const contextValue: GlobalContextType = useMemo(
    () => ({
      state,
      setDarkMode,
      toggleDarkMode,
      setThemeAccent,
      setUiThemeStyle,
      setNoteFlowTheme,
      updateScaleConfig,
      setScalePreset,
      resetScaleConfig,
      updatePaperConfig,
      setPaperTheme,
      setPaperFontSize,
      setPaperLineHeightRatio,
      toggleRuledLines,
      toggleMarginLine,
      setCanvasThemeStyle,
      updateNavBarConfig,
      resetNavBarConfig,
      addSection,
      updateSection,
      deleteSection,
      reorderSections,
      resetSections,
      updateMenuOrder,
      resetMenuOrder,
      updateProfile,
      runAutoRepair,
      runLevel1Repair,
      runLevel2Repair,
      runLevel3Repair,
      runFullDiagnosticsAudit,
      generateDiagnosticReport,
      triggerOnlineHeal,
      executeDiagnosticCommand,
      clearDiagnosticLogs,
      addDiagnosticLog,
    }),
    [
      state,
      setDarkMode,
      toggleDarkMode,
      setThemeAccent,
      setUiThemeStyle,
      setNoteFlowTheme,
      updateScaleConfig,
      setScalePreset,
      resetScaleConfig,
      updatePaperConfig,
      setPaperTheme,
      setPaperFontSize,
      setPaperLineHeightRatio,
      toggleRuledLines,
      toggleMarginLine,
      setCanvasThemeStyle,
      updateNavBarConfig,
      resetNavBarConfig,
      addSection,
      updateSection,
      deleteSection,
      reorderSections,
      resetSections,
      updateMenuOrder,
      resetMenuOrder,
      updateProfile,
      runAutoRepair,
      runLevel1Repair,
      runLevel2Repair,
      runLevel3Repair,
      runFullDiagnosticsAudit,
      generateDiagnosticReport,
      triggerOnlineHeal,
      executeDiagnosticCommand,
      clearDiagnosticLogs,
      addDiagnosticLog,
    ]
  );

  return <GlobalContext.Provider value={contextValue}>{children}</GlobalContext.Provider>;
};

export function useGlobalState(): GlobalContextType {
  const context = useContext(GlobalContext);
  if (!context) {
    throw new Error("useGlobalState must be used within a GlobalStateProvider");
  }
  return context;
}
