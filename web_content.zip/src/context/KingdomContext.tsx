import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, ReactNode } from 'react';
import {
  Kingdom,
  CivilizationId,
  BuildingType,
  TechType,
  UnitType,
  FoodLevel,
  WarFooting,
  MilitaryStrategy,
  TacticalFormation,
  EquipmentType,
  WorkerAllocation,
  ResourceRates,
  BattleReport,
  SpyReport,
  Territory,
  Challenge,
  PvPChallenge,
  PvPChallengeStatus,
} from '../types/kingdom';
import {
  createInitialKingdom,
  calculateResourceRates,
  getMaxStorageCapacity,
  getBuildingUpgradeCost,
  getBuildingUpgradeTimeSeconds,
  getTechUpgradeCost,
  getTechUpgradeTimeSeconds,
  BUILDINGS_CONFIG,
  TECHNOLOGIES_CONFIG,
  UNITS_CONFIG,
  EQUIPMENT_CONFIG,
  INITIAL_TERRITORIES,
  INITIAL_CHALLENGES,
  getHospitalCapacity,
  getTotalWoundedCount,
  getHealingUnitCost,
  getKingdomMaxPopulation,
  getDemographicGrowthRate,
  getPlayerMapCoordinates,
  calculateKingdomDistance,
  CIVILIZATIONS,
} from '../game/gameConfig';
import { resolveBattle, resolveEspionage } from '../game/battleEngine';
import confetti from 'canvas-confetti';
import { useAuth } from './AuthContext';
import { calculateOfflineGains, isBattleReadyForResolution } from '../game/gameTime';
import {
  db,
  doc,
  getDoc,
  setDoc,
  collection,
  onSnapshot,
  addDoc,
  updateDoc,
} from '../firebase/firebase';
import { audioManager, SoundEffectType } from '../game/audioManager';

const STORAGE_KEY = 'la_conquista_kingdom_v1';
const TERRITORIES_KEY = 'la_conquista_territories_v1';

interface KingdomContextType {
  kingdom: Kingdom | null;
  territories: Territory[];
  challenges: Challenge[];
  rates: ResourceRates;
  storageMax: { resourcesMax: number; foodMax: number };
  maxPopulation: number;
  demographicRate: {
    growthPerHour: number;
    happiness: number;
    isAtCap: boolean;
    maxPopulation: number;
    statusText: string;
  };
  hospitalCapacity: number;
  totalWoundedCount: number;
  isKingdomLoading: boolean;
  isSyncing: boolean;
  lastSyncedAt: Date | null;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  toggleSound: () => boolean;
  soundVolume: number;
  setSoundVolume: (volume: number) => void;
  saveKingdomToCloud: () => Promise<void>;
  startNewKingdom: (kingdomName: string, castleName: string, civId: CivilizationId) => void;
  resetKingdom: () => void;
  upgradeBuilding: (type: BuildingType) => { success: boolean; error?: string };
  cancelConstruction: (queueId: string) => void;
  instantCompleteConstruction: (queueId: string) => void;
  researchTechnology: (type: TechType) => { success: boolean; error?: string };
  cancelResearch: (queueId: string) => void;
  instantCompleteResearch: (queueId: string) => void;
  trainUnits: (type: UnitType, count: number) => { success: boolean; error?: string };
  cancelTraining: (queueId: string) => void;
  instantCompleteTraining: (queueId: string) => void;
  hireMercenaries: (type: UnitType, count: number, goldCost: number) => { success: boolean; error?: string };
  healUnits: (type: UnitType, count: number) => { success: boolean; error?: string };
  healAllUnits: () => { success: boolean; error?: string };
  setTaxRate: (rate: number) => void;
  setFoodLevel: (level: FoodLevel) => void;
  setWarFooting: (footing: WarFooting) => void;
  setMilitaryStrategy: (strategy: MilitaryStrategy) => void;
  setFormation: (formation: TacticalFormation) => void;
  upgradeEquipment: (type: EquipmentType) => { success: boolean; error?: string };
  setWorkerAllocation: (allocation: WorkerAllocation) => void;
  attackTerritory: (territoryId: string, attackerArmy: Partial<Record<UnitType, number>>) => BattleReport | null;
  spyTerritory: (territoryId: string) => SpyReport | null;
  claimChallengeReward: (challengeId: string) => void;
  playSound: (type: SoundEffectType) => void;
  pvpChallenges: PvPChallenge[];
  pendingPvPChallengesCount: number;
  sendPvPChallenge: (params: {
    defenderId: string;
    defenderKingdomName: string;
    defenderCastleName: string;
    defenderCivilization: CivilizationId;
    defenderGlory: number;
    preparationHours: number;
    goldStake: number;
    message: string;
    distance: number;
  }) => Promise<{ success: boolean; error?: string }>;
  respondPvPChallenge: (challengeId: string, accept: boolean, replyMessage?: string) => Promise<{ success: boolean; error?: string }>;
  cancelPvPChallenge: (challengeId: string) => Promise<{ success: boolean; error?: string }>;
  resolvePvPBattle: (challengeId: string) => Promise<BattleReport | null>;
}

const KingdomContext = createContext<KingdomContextType | undefined>(undefined);

function sanitizeKingdomState(k: Kingdom): Kingdom {
  if (!k.buildings) k.buildings = {} as Record<BuildingType, number>;
  if (k.buildings.hospital === undefined) k.buildings.hospital = 0;
  if (k.buildings.houses === undefined) k.buildings.houses = 1;
  if (!k.population || typeof k.population !== 'number' || k.population < 50) {
    const armyTotal = Object.values(k.army || {}).reduce((acc: number, curr) => acc + (curr || 0), 0);
    k.population = Math.max(180, armyTotal + 80);
  }
  if (!k.technologies) k.technologies = {} as Record<TechType, number>;
  if (k.technologies.medicinalHerbs === undefined) k.technologies.medicinalHerbs = 0;
  if (k.technologies.fieldSurgery === undefined) k.technologies.fieldSurgery = 0;
  if (k.technologies.battlefieldSanitation === undefined) k.technologies.battlefieldSanitation = 0;
  if (!k.woundedArmy) {
    k.woundedArmy = {
      militia: 0,
      swordsman: 0,
      archer: 0,
      crossbowman: 0,
      lightCavalry: 0,
      knight: 0,
      batteringRam: 0,
      catapult: 0,
      spy: 0,
    };
  }
  if (!k.formation) k.formation = 'balanced';
  if (!k.equipment) {
    k.equipment = {
      toledoSteel: 0,
      compositeArmor: 0,
      fireArrows: 0,
      reinforcedShields: 0,
      warhorseBarding: 0,
    };
  }
  if (!k.workerAllocation) {
    k.workerAllocation = {
      farmers: 25,
      woodcutters: 25,
      miners: 25,
      mintWorkers: 25,
    };
  }
  if (!Array.isArray(k.conqueredTerritories)) {
    k.conqueredTerritories = [];
  } else {
    k.conqueredTerritories = Array.from(new Set(k.conqueredTerritories));
  }
  return k;
}

export const KingdomProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [kingdom, setKingdom] = useState<Kingdom | null>(null);
  const [isKingdomLoading, setIsKingdomLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<Date | null>(null);
  const saveTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);

  // Centralized Audio Web API state
  const [soundEnabled, setSoundEnabledState] = useState<boolean>(() => audioManager.getEnabled());
  const [soundVolume, setSoundVolumeState] = useState<number>(() => audioManager.getVolume());

  const setSoundEnabled = useCallback((enabled: boolean) => {
    audioManager.setEnabled(enabled);
    setSoundEnabledState(enabled);
  }, []);

  const toggleSound = useCallback(() => {
    const next = audioManager.toggleMute();
    setSoundEnabledState(next);
    return next;
  }, []);

  const setSoundVolume = useCallback((vol: number) => {
    audioManager.setVolume(vol);
    setSoundVolumeState(vol);
  }, []);

  const playSound = useCallback((type: SoundEffectType) => {
    audioManager.play(type);
  }, []);

  const [baseTerritories, setBaseTerritories] = useState<Territory[]>(() => {
    try {
      const saved = localStorage.getItem(TERRITORIES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter((t: Territory) => !t.isRealPlayer && !t.id.startsWith('player_'));
        }
      }
      return INITIAL_TERRITORIES;
    } catch {
      return INITIAL_TERRITORIES;
    }
  });

  const [otherPlayerCastles, setOtherPlayerCastles] = useState<Territory[]>([]);
  const [pvpChallenges, setPvpChallenges] = useState<PvPChallenge[]>([]);

  // Dynamically combine real player kingdoms discovered on Firebase with neutral fiefs, strictly deduplicating by ID
  const territories: Territory[] = useMemo(() => {
    const map = new Map<string, Territory>();
    // First register base neutral territories (filtering out any misclassified player castles)
    baseTerritories.forEach((t) => {
      if (!t.isRealPlayer && !t.id.startsWith('player_')) {
        map.set(t.id, t);
      }
    });
    // Then register real player castles, ensuring each castle ID is unique
    otherPlayerCastles.forEach((t) => {
      map.set(t.id, t);
    });
    return Array.from(map.values());
  }, [otherPlayerCastles, baseTerritories]);

  const pendingPvPChallengesCount = useMemo(() => {
    if (!user) return 0;
    return pvpChallenges.filter((c) => c.defenderId === user.uid && c.status === 'pending').length;
  }, [user, pvpChallenges]);

  // Load user's kingdom from Firestore or local cache
  useEffect(() => {
    let isCancelled = false;
    async function loadUserKingdom() {
      if (!user) {
        setKingdom(null);
        setIsKingdomLoading(false);
        return;
      }
      setIsKingdomLoading(true);
      try {
        const userDocRef = doc(db, 'kingdoms', user.uid);
        const snap = await getDoc(userDocRef);
        if (snap.exists()) {
          let cloudKingdom = sanitizeKingdomState(snap.data() as Kingdom);
          // Calculate offline production if returning after absence
          if (cloudKingdom.lastUpdated && Date.now() - cloudKingdom.lastUpdated > 10000) {
            const currentRates = calculateResourceRates(cloudKingdom);
            const currentCaps = getMaxStorageCapacity(
              cloudKingdom.buildings.warehouse || 1,
              cloudKingdom.buildings.granary || 1
            );
            const offline = calculateOfflineGains(
              cloudKingdom.lastUpdated,
              cloudKingdom.resources,
              currentRates,
              currentCaps
            );
            if (offline.elapsedSeconds > 15) {
              cloudKingdom = {
                ...cloudKingdom,
                resources: {
                  food: Math.min(currentCaps.foodMax, cloudKingdom.resources.food + offline.foodGained),
                  wood: Math.min(currentCaps.resourcesMax, cloudKingdom.resources.wood + offline.woodGained),
                  stone: Math.min(currentCaps.resourcesMax, cloudKingdom.resources.stone + offline.stoneGained),
                  gold: Math.min(currentCaps.resourcesMax, cloudKingdom.resources.gold + offline.goldGained),
                },
                lastUpdated: Date.now(),
              };
            }
          }
          if (!isCancelled) {
            setKingdom(cloudKingdom);
            localStorage.setItem(STORAGE_KEY + '_' + user.uid, JSON.stringify(cloudKingdom));
            setLastSyncedAt(new Date());
          }
        } else {
          // Check local storage for this user or generic key to migrate
          const localSaved =
            localStorage.getItem(STORAGE_KEY + '_' + user.uid) ||
            localStorage.getItem(STORAGE_KEY);
          if (localSaved) {
            try {
              const parsed = sanitizeKingdomState(JSON.parse(localSaved));
              parsed.id = user.uid;
              parsed.userId = user.uid;
              if (!isCancelled) {
                setKingdom(parsed);
              }
              // Upload to cloud Firestore
              await setDoc(userDocRef, { ...parsed, lastUpdated: Date.now() }, { merge: true });
              if (!isCancelled) {
                setLastSyncedAt(new Date());
              }
            } catch (e) {
              console.warn('Failed migrating local kingdom:', e);
              if (!isCancelled) setKingdom(null);
            }
          } else {
            if (!isCancelled) setKingdom(null);
          }
        }
      } catch (err) {
        console.error('Error loading kingdom from Firestore:', err);
        // Offline fallback
        const localSaved =
          localStorage.getItem(STORAGE_KEY + '_' + user.uid) ||
          localStorage.getItem(STORAGE_KEY);
        if (localSaved && !isCancelled) {
          try {
            setKingdom(sanitizeKingdomState(JSON.parse(localSaved)));
          } catch {
            setKingdom(null);
          }
        }
      } finally {
        if (!isCancelled) {
          setIsKingdomLoading(false);
        }
      }
    }
    loadUserKingdom();
    return () => {
      isCancelled = true;
    };
  }, [user]);

  // Synchronize multiplayer castles and PvP challenges from Firebase
  useEffect(() => {
    if (!user) {
      setOtherPlayerCastles([]);
      setPvpChallenges([]);
      return;
    }

    let unsubKingdoms = () => {};
    let unsubChallenges = () => {};

    try {
      // 1. Listen for other player kingdoms registered in Firestore
      const kingdomsCol = collection(db, 'kingdoms');
      unsubKingdoms = onSnapshot(
        kingdomsCol,
        (snapshot) => {
          const playerTerritories: Territory[] = [];
          const myCoords = getPlayerMapCoordinates(user.uid);
          const seenPlayerIds = new Set<string>();

          snapshot.forEach((docSnap) => {
            const pUserId = docSnap.id;
            if (pUserId !== user.uid && !seenPlayerIds.has(pUserId)) {
              seenPlayerIds.add(pUserId);
              const data = docSnap.data() as Partial<Kingdom>;
              if (data.kingdomName && data.castleName) {
                const pCoords = getPlayerMapCoordinates(pUserId);
                const dist = calculateKingdomDistance(myCoords.x, myCoords.y, pCoords.x, pCoords.y);
                playerTerritories.push({
                  id: `player_${pUserId}`,
                  name: data.kingdomName,
                  x: pCoords.x,
                  y: pCoords.y,
                  zone: `Reino de ${data.kingdomName}`,
                  type: 'player_castle',
                  defenseLevel: data.buildings?.wall || 1,
                  garrison: data.army || { militia: 25, archer: 15 },
                  loot: {
                    food: Math.min(2500, Math.round((data.resources?.food || 800) * 0.25)),
                    wood: Math.min(2000, Math.round((data.resources?.wood || 800) * 0.2)),
                    stone: Math.min(2000, Math.round((data.resources?.stone || 700) * 0.2)),
                    gold: Math.min(1500, Math.round((data.resources?.gold || 500) * 0.3)),
                  },
                  gloryReward: Math.max(30, Math.round((data.gloryPoints || 100) * 0.15)),
                  isConquered: false,
                  ownerName: data.kingdomName,
                  ownerUserId: pUserId,
                  ownerCivilization: (data.civilization as CivilizationId) || 'iberos',
                  castleName: data.castleName,
                  population: data.population || 250,
                  isRealPlayer: true,
                  distance: dist,
                  description: `Castillo de jugador real gobernado por ${data.kingdomName}. Conforme a la ley feudal (Punto 38), no admite asaltos sorpresa; la contienda debe pactarse en el Parlamento.`,
                });
              }
            }
          });

          // Always provide a demonstration online rival so the player can test the mechanic immediately
          if (playerTerritories.length === 0) {
            const demoCoords = { x: 7, y: 3 };
            const dist = calculateKingdomDistance(myCoords.x, myCoords.y, demoCoords.x, demoCoords.y);
            playerTerritories.push({
              id: 'player_demo_asturias',
              name: 'Reino de Asturias',
              x: demoCoords.x,
              y: demoCoords.y,
              zone: 'Corona de Asturias (Norte)',
              type: 'player_castle',
              defenseLevel: 3,
              garrison: { militia: 30, swordsman: 20, archer: 15, lightCavalry: 8 },
              loot: { food: 950, wood: 800, stone: 650, gold: 600 },
              gloryReward: 120,
              isConquered: false,
              ownerName: 'Rey Pelayo II',
              ownerUserId: 'demo_lord_asturias',
              ownerCivilization: 'godos',
              castleName: 'Castillo de Covadonga',
              population: 320,
              isRealPlayer: true,
              distance: dist,
              description: 'Feudo soberano de otro señor de la corona. Conforme a las leyes de La Conquista, sus vasallos están listos para recibir embajadas diplomáticas.',
            });
          }

          setOtherPlayerCastles(playerTerritories);
        },
        (err) => {
          console.warn('Real-time kingdoms snapshot error:', err);
        }
      );

      // 2. Listen for PvP Challenges involving the player
      const challengesCol = collection(db, 'pvp_challenges');
      unsubChallenges = onSnapshot(
        challengesCol,
        (snapshot) => {
          const list: PvPChallenge[] = [];
          const seenChallengeIds = new Set<string>();
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as PvPChallenge;
            const cId = docSnap.id;
            if (
              (data.challengerId === user.uid || data.defenderId === user.uid) &&
              !seenChallengeIds.has(cId)
            ) {
              seenChallengeIds.add(cId);
              list.push({ ...data, id: cId });
            }
          });
          list.sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
          setPvpChallenges(list);
        },
        (err) => {
          console.warn('PvP challenges snapshot error:', err);
        }
      );
    } catch (err) {
      console.warn('Failed setting up Firestore multiplayer listeners:', err);
    }

    return () => {
      unsubKingdoms();
      unsubChallenges();
    };
  }, [user]);

  // Save kingdom to cloud Firestore
  const saveKingdomToCloud = useCallback(async () => {
    if (!user || !kingdom) return;
    try {
      setIsSyncing(true);
      const userDocRef = doc(db, 'kingdoms', user.uid);
      await setDoc(userDocRef, { ...kingdom, lastUpdated: Date.now() }, { merge: true });
      setLastSyncedAt(new Date());
    } catch (e) {
      console.warn('Error saving to Firestore:', e);
    } finally {
      setIsSyncing(false);
    }
  }, [user, kingdom]);

  // Calculate live challenges based on kingdom state
  const challenges: Challenge[] = INITIAL_CHALLENGES.map((ch) => {
    let currentVal = 0;
    if (kingdom) {
      if (ch.id === 'ch_first_farm') currentVal = kingdom.buildings.farm || 1;
      else if (ch.id === 'ch_build_houses') currentVal = kingdom.buildings.houses || 0;
      else if (ch.id === 'ch_first_barracks') currentVal = kingdom.buildings.barracks || 0;
      else if (ch.id === 'ch_train_army') {
        currentVal = Object.values(kingdom.army).reduce((acc: number, curr: number) => acc + (curr || 0), 0);
      } else if (ch.id === 'ch_first_tech') {
        currentVal = Object.values(kingdom.technologies).reduce((acc: number, curr: number) => acc + (curr > 0 ? 1 : 0), 0);
      } else if (ch.id === 'ch_conquer_territory') {
        currentVal = kingdom.conqueredTerritories.length;
      }
    }
    const isCompleted = currentVal >= ch.targetValue;
    const isClaimed = kingdom?.claimedChallenges?.includes(ch.id) || false;
    return {
      ...ch,
      currentValue: currentVal,
      isCompleted,
      isClaimed,
    };
  });

  // Sync to local storage and debounce cloud sync on change
  useEffect(() => {
    if (kingdom) {
      try {
        const key = user ? `${STORAGE_KEY}_${user.uid}` : STORAGE_KEY;
        localStorage.setItem(key, JSON.stringify(kingdom));
        localStorage.setItem(STORAGE_KEY, JSON.stringify(kingdom));
      } catch (e) {
        console.error('Failed saving kingdom state', e);
      }
      if (user) {
        if (saveTimeoutRef.current) {
          clearTimeout(saveTimeoutRef.current);
        }
        saveTimeoutRef.current = setTimeout(() => {
          saveKingdomToCloud();
        }, 3000);
      }
    }
  }, [kingdom, user, saveKingdomToCloud]);

  useEffect(() => {
    try {
      // ONLY persist neutral base territories, never dynamic player castles
      const cleanBase = baseTerritories.filter((t) => !t.isRealPlayer && !t.id.startsWith('player_'));
      localStorage.setItem(TERRITORIES_KEY, JSON.stringify(cleanBase));
    } catch (e) {
      console.error('Failed saving territories state', e);
    }
  }, [baseTerritories]);

  // Derived rates and capacities
  const rates = kingdom
    ? calculateResourceRates(kingdom)
    : { foodPerHour: 0, woodPerHour: 0, stonePerHour: 0, goldPerHour: 0 };

  const storageMax = kingdom
    ? getMaxStorageCapacity(kingdom.buildings.warehouse || 1, kingdom.buildings.granary || 1)
    : { resourcesMax: 3500, foodMax: 4000 };

  const maxPopulation = kingdom ? getKingdomMaxPopulation(kingdom) : 350;
  const demographicRate = kingdom
    ? getDemographicGrowthRate(kingdom)
    : { growthPerHour: 0, happiness: 75, isAtCap: false, maxPopulation: 350, statusText: '0/h' };

  // Main 1-second game loop ticker
  useEffect(() => {
    if (!kingdom) return;
    const interval = setInterval(() => {
      setKingdom((prev) => {
        if (!prev) return null;
        const now = Date.now();
        const deltaSeconds = Math.max(0.2, (now - prev.lastTickTimestamp) / 1000);
        const deltaHours = deltaSeconds / 3600;
        const currentRates = calculateResourceRates(prev);
        const currentCaps = getMaxStorageCapacity(prev.buildings.warehouse || 1, prev.buildings.granary || 1);

        // Accumulate resources capped by storage
        const newFood = Math.max(
          0,
          Math.min(currentCaps.foodMax, prev.resources.food + currentRates.foodPerHour * deltaHours)
        );
        const newWood = Math.min(
          currentCaps.resourcesMax,
          prev.resources.wood + currentRates.woodPerHour * deltaHours
        );
        const newStone = Math.min(
          currentCaps.resourcesMax,
          prev.resources.stone + currentRates.stonePerHour * deltaHours
        );
        const newGold = Math.min(
          currentCaps.resourcesMax,
          prev.resources.gold + currentRates.goldPerHour * deltaHours
        );

        // Process Demographic Growth
        const maxPop = getKingdomMaxPopulation(prev);
        const { growthPerHour } = getDemographicGrowthRate(prev);
        let newPopulation = prev.population || 180;
        if (newPopulation < maxPop && growthPerHour > 0) {
          newPopulation = Math.min(maxPop, newPopulation + growthPerHour * deltaHours);
        }

        // Process Construction Queue
        const newBuildings = { ...prev.buildings };
        const remainingConstruction: typeof prev.constructionQueue = [];
        let didCompleteBuilding = false;
        prev.constructionQueue.forEach((item) => {
          if (now >= item.finishTime) {
            newBuildings[item.buildingType] = item.targetLevel;
            didCompleteBuilding = true;
          } else {
            remainingConstruction.push(item);
          }
        });
        if (didCompleteBuilding) {
          audioManager.play('constructionComplete');
        }

        // Process Research Queue
        const newTechs = { ...prev.technologies };
        const remainingResearch: typeof prev.researchQueue = [];
        let didCompleteResearch = false;
        prev.researchQueue.forEach((item) => {
          if (now >= item.finishTime) {
            newTechs[item.techType] = item.targetLevel;
            didCompleteResearch = true;
          } else {
            remainingResearch.push(item);
          }
        });
        if (didCompleteResearch) {
          audioManager.play('researchComplete');
        }

        // Process Military Training Queue
        const newArmy = { ...prev.army };
        const remainingTraining: typeof prev.trainingQueue = [];
        let didCompleteTraining = false;
        prev.trainingQueue.forEach((item) => {
          const elapsed = now - item.startTime;
          const calculatedReady = Math.min(item.totalCount, Math.floor(elapsed / item.unitTimeMs));
          const freshlyReady = calculatedReady - item.trainedCount;
          if (freshlyReady > 0) {
            newArmy[item.unitType] = (newArmy[item.unitType] || 0) + freshlyReady;
            didCompleteTraining = true;
          }
          if (calculatedReady < item.totalCount) {
            remainingTraining.push({
              ...item,
              trainedCount: calculatedReady,
            });
          }
        });
        if (didCompleteTraining) {
          audioManager.play('trainingComplete');
        }

        return {
          ...prev,
          lastTickTimestamp: now,
          resources: {
            food: newFood,
            wood: newWood,
            stone: newStone,
            gold: newGold,
          },
          population: newPopulation,
          buildings: newBuildings,
          technologies: newTechs,
          army: newArmy,
          constructionQueue: remainingConstruction,
          researchQueue: remainingResearch,
          trainingQueue: remainingTraining,
        };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [kingdom]);

  const startNewKingdom = useCallback(
    (kName: string, cName: string, civId: CivilizationId) => {
      const newK = createInitialKingdom(kName, cName, civId);
      if (user) {
        newK.id = user.uid;
        newK.userId = user.uid;
      }
      setKingdom(newK);
      setBaseTerritories(INITIAL_TERRITORIES);
      audioManager.play('horn');
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
      if (user) {
        const userDocRef = doc(db, 'kingdoms', user.uid);
        setDoc(userDocRef, { ...newK, lastUpdated: Date.now() }).catch((err) => {
          console.warn('Error saving new kingdom to Firestore:', err);
        });
        setLastSyncedAt(new Date());
      }
    },
    [user]
  );

  const resetKingdom = useCallback(() => {
    if (user) {
      localStorage.removeItem(`${STORAGE_KEY}_${user.uid}`);
      try {
        const userDocRef = doc(db, 'kingdoms', user.uid);
        setDoc(userDocRef, { isDeleted: true, lastUpdated: Date.now() }, { merge: true }).catch(() => {});
      } catch (e) {
        console.warn('Error clearing cloud kingdom:', e);
      }
    }
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(TERRITORIES_KEY);
    setKingdom(null);
    setBaseTerritories(INITIAL_TERRITORIES);
  }, [user]);

  const upgradeBuilding = useCallback(
    (type: BuildingType) => {
      if (!kingdom) return { success: false, error: 'Reino no inicializado' };
      if (kingdom.constructionQueue.length >= 2) {
        return { success: false, error: 'Los albañiles ya tienen dos obras en marcha simultáneas.' };
      }
      if (kingdom.constructionQueue.some((q) => q.buildingType === type)) {
        return { success: false, error: 'Este edificio ya está siendo ampliado.' };
      }

      const currentLvl = kingdom.buildings[type] || 0;
      const targetLvl = currentLvl + 1;
      const cost = getBuildingUpgradeCost(type, currentLvl);

      if (type !== 'townHall' && targetLvl > (kingdom.buildings.townHall || 1)) {
        return {
          success: false,
          error: `Debes mejorar el Castillo al nivel ${targetLvl} antes de elevar este edificio.`,
        };
      }

      if (
        kingdom.resources.food < cost.food ||
        kingdom.resources.wood < cost.wood ||
        kingdom.resources.stone < cost.stone ||
        kingdom.resources.gold < cost.gold
      ) {
        return { success: false, error: 'Recursos insuficientes en tus almacenes.' };
      }

      const durationSec = getBuildingUpgradeTimeSeconds(
        type,
        currentLvl,
        kingdom.buildings.townHall || 1
      );
      const now = Date.now();
      const finish = now + durationSec * 1000;

      setKingdom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          resources: {
            food: prev.resources.food - cost.food,
            wood: prev.resources.wood - cost.wood,
            stone: prev.resources.stone - cost.stone,
            gold: prev.resources.gold - cost.gold,
          },
          constructionQueue: [
            ...prev.constructionQueue,
            {
              id: 'cq_' + Date.now().toString(36),
              buildingType: type,
              targetLevel: targetLvl,
              startTime: now,
              durationMs: durationSec * 1000,
              finishTime: finish,
            },
          ],
        };
      });
      audioManager.play('build');
      return { success: true };
    },
    [kingdom]
  );

  const cancelConstruction = useCallback((queueId: string) => {
    setKingdom((prev) => {
      if (!prev) return null;
      const item = prev.constructionQueue.find((q) => q.id === queueId);
      if (!item) return prev;
      const cost = getBuildingUpgradeCost(item.buildingType, item.targetLevel - 1);
      return {
        ...prev,
        resources: {
          food: prev.resources.food + Math.round(cost.food * 0.7),
          wood: prev.resources.wood + Math.round(cost.wood * 0.7),
          stone: prev.resources.stone + Math.round(cost.stone * 0.7),
          gold: prev.resources.gold + Math.round(cost.gold * 0.7),
        },
        constructionQueue: prev.constructionQueue.filter((q) => q.id !== queueId),
      };
    });
  }, []);

  const instantCompleteConstruction = useCallback((queueId: string) => {
    setKingdom((prev) => {
      if (!prev) return null;
      const item = prev.constructionQueue.find((q) => q.id === queueId);
      if (!item) return prev;
      audioManager.play('constructionComplete');
      confetti({ particleCount: 30, spread: 50, origin: { y: 0.7 } });
      return {
        ...prev,
        buildings: {
          ...prev.buildings,
          [item.buildingType]: item.targetLevel,
        },
        constructionQueue: prev.constructionQueue.filter((q) => q.id !== queueId),
      };
    });
  }, []);

  const researchTechnology = useCallback(
    (type: TechType) => {
      if (!kingdom) return { success: false, error: 'Reino no inicializado' };
      const univLvl = kingdom.buildings.university || 0;
      if (univLvl < 1) {
        return { success: false, error: 'Necesitas erigir la Universidad para investigar.' };
      }
      if (kingdom.researchQueue.length >= 1) {
        return { success: false, error: 'Los sabios ya están consagrados a una investigación.' };
      }
      const currentLvl = kingdom.technologies[type] || 0;
      const targetLvl = currentLvl + 1;
      const cfg = TECHNOLOGIES_CONFIG[type];
      if (cfg.maxLevel && targetLvl > cfg.maxLevel) {
        return { success: false, error: 'Esta tecnología ha alcanzado su máximo conocimiento.' };
      }
      const cost = getTechUpgradeCost(type, currentLvl);
      if (
        kingdom.resources.food < cost.food ||
        kingdom.resources.wood < cost.wood ||
        kingdom.resources.stone < cost.stone ||
        kingdom.resources.gold < cost.gold
      ) {
        return { success: false, error: 'No dispones de suficientes recursos para costear este saber.' };
      }
      const durationSec = getTechUpgradeTimeSeconds(type, currentLvl, univLvl);
      const now = Date.now();
      setKingdom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          resources: {
            food: prev.resources.food - cost.food,
            wood: prev.resources.wood - cost.wood,
            stone: prev.resources.stone - cost.stone,
            gold: prev.resources.gold - cost.gold,
          },
          researchQueue: [
            ...prev.researchQueue,
            {
              id: 'rq_' + Date.now().toString(36),
              techType: type,
              targetLevel: targetLvl,
              startTime: now,
              durationMs: durationSec * 1000,
              finishTime: now + durationSec * 1000,
            },
          ],
        };
      });
      audioManager.play('research');
      return { success: true };
    },
    [kingdom]
  );

  const cancelResearch = useCallback((queueId: string) => {
    setKingdom((prev) => {
      if (!prev) return null;
      const item = prev.researchQueue.find((q) => q.id === queueId);
      if (!item) return prev;
      const cost = getTechUpgradeCost(item.techType, item.targetLevel - 1);
      return {
        ...prev,
        resources: {
          food: prev.resources.food + Math.round(cost.food * 0.7),
          wood: prev.resources.wood + Math.round(cost.wood * 0.7),
          stone: prev.resources.stone + Math.round(cost.stone * 0.7),
          gold: prev.resources.gold + Math.round(cost.gold * 0.7),
        },
        researchQueue: prev.researchQueue.filter((q) => q.id !== queueId),
      };
    });
  }, []);

  const instantCompleteResearch = useCallback((queueId: string) => {
    setKingdom((prev) => {
      if (!prev) return null;
      const item = prev.researchQueue.find((q) => q.id === queueId);
      if (!item) return prev;
      audioManager.play('researchComplete');
      confetti({ particleCount: 35, spread: 60 });
      return {
        ...prev,
        technologies: {
          ...prev.technologies,
          [item.techType]: item.targetLevel,
        },
        researchQueue: prev.researchQueue.filter((q) => q.id !== queueId),
      };
    });
  }, []);

  const trainUnits = useCallback(
    (type: UnitType, count: number) => {
      if (!kingdom) return { success: false, error: 'Reino no inicializado' };
      if (count <= 0) return { success: false, error: 'Indica un número positivo de soldados.' };
      const uInfo = UNITS_CONFIG[type];
      const req = uInfo.requiredBuildingLevel;
      const userLvl = kingdom.buildings[req.building] || 0;
      if (userLvl < req.level) {
        return {
          success: false,
          error: `Requiere ${BUILDINGS_CONFIG[req.building].name} al nivel ${req.level}.`,
        };
      }

      // Check available recruits from kingdom population
      const activeArmy = Object.values(kingdom.army).reduce((acc: number, curr: number) => acc + (curr || 0), 0);
      const inTraining = kingdom.trainingQueue.reduce((acc, it) => acc + (it.totalCount - it.trainedCount), 0);
      const totalMilitary = activeArmy + inTraining;
      const currentPop = Math.floor(kingdom.population || 0);
      const availableRecruits = Math.max(0, currentPop - totalMilitary);

      if (count > availableRecruits) {
        return {
          success: false,
          error: `Población insuficiente (${availableRecruits} aldeanos disponibles de ${currentPop} habitantes). Espera el crecimiento demográfico o construye más Casas y Chozas.`,
        };
      }
      const totalCost = {
        food: uInfo.cost.food * count,
        wood: uInfo.cost.wood * count,
        stone: uInfo.cost.stone * count,
        gold: uInfo.cost.gold * count,
      };
      if (
        kingdom.resources.food < totalCost.food ||
        kingdom.resources.wood < totalCost.wood ||
        kingdom.resources.stone < totalCost.stone ||
        kingdom.resources.gold < totalCost.gold
      ) {
        return { success: false, error: 'No tienes suministros suficientes para instruir tantas tropas.' };
      }
      const barracksLvl = kingdom.buildings.barracks || 1;
      const speedMult = 1 / (1 + barracksLvl * 0.08);
      const unitTimeMs = Math.max(2000, Math.round(uInfo.trainingTimeSeconds * 1000 * speedMult));
      const totalTimeMs = unitTimeMs * count;
      const now = Date.now();
      setKingdom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          resources: {
            food: prev.resources.food - totalCost.food,
            wood: prev.resources.wood - totalCost.wood,
            stone: prev.resources.stone - totalCost.stone,
            gold: prev.resources.gold - totalCost.gold,
          },
          trainingQueue: [
            ...prev.trainingQueue,
            {
              id: 'tq_' + Date.now().toString(36),
              unitType: type,
              totalCount: count,
              trainedCount: 0,
              unitTimeMs,
              startTime: now,
              finishTime: now + totalTimeMs,
            },
          ],
        };
      });
      audioManager.play('horn');
      return { success: true };
    },
    [kingdom]
  );

  const cancelTraining = useCallback((queueId: string) => {
    setKingdom((prev) => {
      if (!prev) return null;
      const item = prev.trainingQueue.find((q) => q.id === queueId);
      if (!item) return prev;
      const remainingCount = item.totalCount - item.trainedCount;
      const uInfo = UNITS_CONFIG[item.unitType];
      const refund = {
        food: Math.round(uInfo.cost.food * remainingCount * 0.7),
        wood: Math.round(uInfo.cost.wood * remainingCount * 0.7),
        stone: Math.round(uInfo.cost.stone * remainingCount * 0.7),
        gold: Math.round(uInfo.cost.gold * remainingCount * 0.7),
      };
      return {
        ...prev,
        resources: {
          food: prev.resources.food + refund.food,
          wood: prev.resources.wood + refund.wood,
          stone: prev.resources.stone + refund.stone,
          gold: prev.resources.gold + refund.gold,
        },
        trainingQueue: prev.trainingQueue.filter((q) => q.id !== queueId),
      };
    });
  }, []);

  const instantCompleteTraining = useCallback((queueId: string) => {
    setKingdom((prev) => {
      if (!prev) return null;
      const item = prev.trainingQueue.find((q) => q.id === queueId);
      if (!item) return prev;
      const remainingCount = item.totalCount - item.trainedCount;
      audioManager.play('trainingComplete');
      return {
        ...prev,
        army: {
          ...prev.army,
          [item.unitType]: (prev.army[item.unitType] || 0) + remainingCount,
        },
        trainingQueue: prev.trainingQueue.filter((q) => q.id !== queueId),
      };
    });
  }, []);

  const hireMercenaries = useCallback(
    (type: UnitType, count: number, goldCost: number) => {
      if (!kingdom) return { success: false, error: 'Reino no inicializado' };
      const tavernLvl = kingdom.buildings.tavern || 0;
      if (tavernLvl < 1) {
        return { success: false, error: 'Debes erigir la Taberna para contratar compañías de mercenarios.' };
      }
      if (kingdom.resources.gold < goldCost) {
        return { success: false, error: 'No dispones de suficiente oro para pagar la soldada de los mercenarios.' };
      }
      setKingdom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          resources: {
            ...prev.resources,
            gold: prev.resources.gold - goldCost,
          },
          army: {
            ...prev.army,
            [type]: (prev.army[type] || 0) + count,
          },
        };
      });
      audioManager.play('coins');
      audioManager.play('horn');
      confetti({
        particleCount: 30,
        spread: 60,
        origin: { y: 0.6 },
      });
      return { success: true };
    },
    [kingdom]
  );

  const setTaxRate = useCallback((rate: number) => {
    setKingdom((prev) => (prev ? { ...prev, taxRate: Math.max(0, Math.min(100, rate)) } : null));
    audioManager.play('parliamentMessage');
  }, []);

  const setFoodLevel = useCallback((foodLevel: FoodLevel) => {
    setKingdom((prev) => (prev ? { ...prev, foodLevel } : null));
    audioManager.play('parliamentMessage');
  }, []);

  const setWarFooting = useCallback((warFooting: WarFooting) => {
    setKingdom((prev) => (prev ? { ...prev, warFooting } : null));
    audioManager.play('parliamentMessage');
  }, []);

  const setMilitaryStrategy = useCallback((militaryStrategy: MilitaryStrategy) => {
    setKingdom((prev) => (prev ? { ...prev, militaryStrategy } : null));
    audioManager.play('parliamentMessage');
  }, []);

  const setFormation = useCallback((formation: TacticalFormation) => {
    setKingdom((prev) => (prev ? { ...prev, formation } : null));
    audioManager.play('horn');
  }, []);

  const setWorkerAllocation = useCallback((workerAllocation: WorkerAllocation) => {
    setKingdom((prev) => (prev ? { ...prev, workerAllocation } : null));
    audioManager.play('click');
  }, []);

  const upgradeEquipment = useCallback(
    (type: EquipmentType) => {
      if (!kingdom) return { success: false, error: 'Reino no inicializado' };
      const currentLvl = kingdom.equipment?.[type] || 0;
      const cfg = EQUIPMENT_CONFIG[type];
      if (!cfg) return { success: false, error: 'Equipo no reconocido' };
      if (currentLvl >= cfg.maxLevel) {
        return { success: false, error: 'Este equipamiento ya ha alcanzado la cota máxima de maestría.' };
      }
      const mult = Math.pow(cfg.costMultiplier, currentLvl);
      const cost = {
        food: Math.round(cfg.cost.food * mult),
        wood: Math.round(cfg.cost.wood * mult),
        stone: Math.round(cfg.cost.stone * mult),
        gold: Math.round(cfg.cost.gold * mult),
      };
      if (
        kingdom.resources.food < cost.food ||
        kingdom.resources.wood < cost.wood ||
        kingdom.resources.stone < cost.stone ||
        kingdom.resources.gold < cost.gold
      ) {
        return { success: false, error: 'Recursos insuficientes en los almacenes para forjar esta mejora.' };
      }
      setKingdom((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          resources: {
            food: prev.resources.food - cost.food,
            wood: prev.resources.wood - cost.wood,
            stone: prev.resources.stone - cost.stone,
            gold: prev.resources.gold - cost.gold,
          },
          equipment: {
            ...(prev.equipment || {
              toledoSteel: 0,
              compositeArmor: 0,
              fireArrows: 0,
              reinforcedShields: 0,
              warhorseBarding: 0,
            }),
            [type]: currentLvl + 1,
          },
        };
      });
      audioManager.play('build');
      confetti({ particleCount: 35, spread: 60, origin: { y: 0.7 } });
      return { success: true };
    },
    [kingdom]
  );

  const attackTerritory = useCallback(
    (territoryId: string, attackerArmy: Partial<Record<UnitType, number>>) => {
      if (!kingdom) return null;
      const target = territories.find((t) => t.id === territoryId);
      if (!target) return null;

      let valid = false;
      Object.entries(attackerArmy).forEach(([k, c]) => {
        if (c && c > 0 && (kingdom.army[k as UnitType] || 0) >= c) {
          valid = true;
        }
      });
      if (!valid) return null;

      const report = resolveBattle(kingdom, target, attackerArmy);
      setKingdom((prev) => {
        if (!prev) return null;
        const newArmy = { ...prev.army };
        Object.entries(report.attackerCasualties).forEach(([uKey, lostCount]) => {
          if (lostCount && lostCount > 0) {
            newArmy[uKey as UnitType] = Math.max(0, (newArmy[uKey as UnitType] || 0) - lostCount);
          }
        });

        const newWoundedArmy = { ...(prev.woundedArmy || {}) };
        if (report.attackerWounded) {
          Object.entries(report.attackerWounded).forEach(([uKey, count]) => {
            if (count && count > 0) {
              newWoundedArmy[uKey as UnitType] = (newWoundedArmy[uKey as UnitType] || 0) + count;
            }
          });
        }

        const newRes = {
          food: prev.resources.food + report.lootCaptured.food,
          wood: prev.resources.wood + report.lootCaptured.wood,
          stone: prev.resources.stone + report.lootCaptured.stone,
          gold: prev.resources.gold + report.lootCaptured.gold,
        };

        const newConquered = report.victory && !prev.conqueredTerritories.includes(territoryId)
          ? [...prev.conqueredTerritories, territoryId]
          : prev.conqueredTerritories;

        let totalAttackerDead = 0;
        if (report.attackerDead) {
          Object.values(report.attackerDead).forEach((d) => {
            totalAttackerDead += d || 0;
          });
        }
        const updatedPop = Math.max(50, (prev.population || 180) - totalAttackerDead);

        return {
          ...prev,
          army: newArmy,
          woundedArmy: newWoundedArmy,
          resources: newRes,
          population: updatedPop,
          gloryPoints: prev.gloryPoints + report.gloryGained,
          conqueredTerritories: newConquered,
          battleReports: [report, ...prev.battleReports].slice(0, 20),
        };
      });

      if (report.victory) {
        audioManager.play('battleVictory');
        confetti({ particleCount: 70, spread: 80, origin: { y: 0.5 } });
      } else {
        audioManager.play('battleDefeat');
      }
      return report;
    },
    [kingdom, territories]
  );

  const healUnits = useCallback(
    (type: UnitType, count: number) => {
      if (!kingdom) return { success: false, error: 'Reino no inicializado' };
      if (count <= 0) return { success: false, error: 'Indica un número válido de soldados a curar.' };
      const currentWounded = kingdom.woundedArmy?.[type] || 0;
      if (currentWounded < count) {
        return { success: false, error: `Solo tienes ${currentWounded} soldados heridos de esta unidad.` };
      }
      const unitCost = getHealingUnitCost(type, kingdom);
      const totalCost = {
        food: unitCost.food * count,
        gold: unitCost.gold * count,
      };
      if (kingdom.resources.food < totalCost.food || kingdom.resources.gold < totalCost.gold) {
        return {
          success: false,
          error: `No dispones de suficientes suministros médicos (requiere ${totalCost.food} comida y ${totalCost.gold} oro).`,
        };
      }
      setKingdom((prev) => {
        if (!prev) return null;
        const newWounded = { ...(prev.woundedArmy || {}) };
        newWounded[type] = Math.max(0, (newWounded[type] || 0) - count);
        const newArmy = { ...prev.army };
        newArmy[type] = (newArmy[type] || 0) + count;
        return {
          ...prev,
          resources: {
            ...prev.resources,
            food: prev.resources.food - totalCost.food,
            gold: prev.resources.gold - totalCost.gold,
          },
          army: newArmy,
          woundedArmy: newWounded,
        };
      });
      audioManager.play('heal');
      confetti({ particleCount: 30, spread: 50, origin: { y: 0.6 } });
      return { success: true };
    },
    [kingdom]
  );

  const healAllUnits = useCallback(() => {
    if (!kingdom) return { success: false, error: 'Reino no inicializado' };
    const wounded = kingdom.woundedArmy || {};
    let totalFoodCost = 0;
    let totalGoldCost = 0;
    let woundedTotal = 0;
    Object.entries(wounded).forEach(([uKey, count]) => {
      if (count && count > 0) {
        woundedTotal += count;
        const cost = getHealingUnitCost(uKey as UnitType, kingdom);
        totalFoodCost += cost.food * count;
        totalGoldCost += cost.gold * count;
      }
    });
    if (woundedTotal === 0) {
      return { success: false, error: 'No hay soldados heridos en el hospital.' };
    }
    if (kingdom.resources.food < totalFoodCost || kingdom.resources.gold < totalGoldCost) {
      return {
        success: false,
        error: `Necesitas ${totalFoodCost} comida y ${totalGoldCost} oro para sanar a los ${woundedTotal} heridos.`,
      };
    }
    setKingdom((prev) => {
      if (!prev) return null;
      const newArmy = { ...prev.army };
      const newWounded = { ...(prev.woundedArmy || {}) };
      Object.entries(newWounded).forEach(([uKey, count]) => {
        if (count && count > 0) {
          newArmy[uKey as UnitType] = (newArmy[uKey as UnitType] || 0) + count;
          newWounded[uKey as UnitType] = 0;
        }
      });
      return {
        ...prev,
        resources: {
          ...prev.resources,
          food: prev.resources.food - totalFoodCost,
          gold: prev.resources.gold - totalGoldCost,
        },
        army: newArmy,
        woundedArmy: newWounded,
      };
    });
    audioManager.play('heal');
    confetti({ particleCount: 50, spread: 70, origin: { y: 0.5 } });
    return { success: true };
  }, [kingdom]);

  const hospitalCapacity = useMemo(() => {
    return kingdom ? getHospitalCapacity(kingdom) : 0;
  }, [kingdom]);

  const totalWoundedCount = useMemo(() => {
    return kingdom?.woundedArmy ? getTotalWoundedCount(kingdom.woundedArmy) : 0;
  }, [kingdom?.woundedArmy]);

  const spyTerritory = useCallback(
    (territoryId: string) => {
      if (!kingdom) return null;
      const target = territories.find((t) => t.id === territoryId);
      if (!target) return null;
      if ((kingdom.army.spy || 0) < 1) {
        return null;
      }
      const report = resolveEspionage(kingdom, target);
      setKingdom((prev) => {
        if (!prev) return null;
        const newArmy = { ...prev.army };
        if (report.detected && !report.success) {
          // 50% chance spy is caught
          newArmy.spy = Math.max(0, (newArmy.spy || 0) - 1);
        }
        return {
          ...prev,
          army: newArmy,
          spyReports: [report, ...prev.spyReports].slice(0, 20),
        };
      });
      audioManager.play('click');
      return report;
    },
    [kingdom, territories]
  );

  const claimChallengeReward = useCallback((challengeId: string) => {
    const ch = challenges.find((c) => c.id === challengeId);
    if (!ch || !ch.isCompleted || ch.isClaimed) return;
    setKingdom((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        gloryPoints: prev.gloryPoints + ch.rewardGlory,
        resources: {
          food: prev.resources.food + (ch.rewardResources.food || 0),
          wood: prev.resources.wood + (ch.rewardResources.wood || 0),
          stone: prev.resources.stone + (ch.rewardResources.stone || 0),
          gold: prev.resources.gold + (ch.rewardResources.gold || 0),
        },
        claimedChallenges: [...prev.claimedChallenges, challengeId],
      };
    });
    audioManager.play('parliamentMessage');
    audioManager.play('coins');
    confetti({ particleCount: 50, spread: 60 });
  }, [challenges]);

  const sendPvPChallenge = useCallback(
    async (params: {
      defenderId: string;
      defenderKingdomName: string;
      defenderCastleName: string;
      defenderCivilization: CivilizationId;
      defenderGlory: number;
      preparationHours: number;
      goldStake: number;
      message: string;
      distance: number;
    }) => {
      if (!user || !kingdom) {
        return { success: false, error: 'Debes iniciar sesión con una cuenta para enviar desafíos feudales.' };
      }
      if (params.goldStake > 0 && kingdom.resources.gold < params.goldStake) {
        return {
          success: false,
          error: `No dispones de suficiente oro (${params.goldStake}) en las arcas para respaldar la apuesta de la batalla.`,
        };
      }

      try {
        const scheduledTime = Date.now() + params.preparationHours * 60 * 60 * 1000;
        const challengeData = {
          challengerId: user.uid,
          challengerKingdomName: kingdom.kingdomName,
          challengerCastleName: kingdom.castleName,
          challengerCivilization: kingdom.civilization,
          challengerGlory: kingdom.gloryPoints,
          defenderId: params.defenderId,
          defenderKingdomName: params.defenderKingdomName,
          defenderCastleName: params.defenderCastleName,
          defenderCivilization: params.defenderCivilization,
          defenderGlory: params.defenderGlory,
          status: 'pending' as PvPChallengeStatus,
          scheduledTime,
          scheduledDateLabel: `En ${params.preparationHours} hora(s) (Año ${kingdom.seasonNumber || 1})`,
          preparationHours: params.preparationHours,
          goldStake: params.goldStake,
          message: params.message,
          distance: params.distance,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        if (params.defenderId === 'demo_lord_asturias') {
          // Local demo challenge simulation
          const localId = 'pvp_demo_' + Date.now();
          const newChallenge: PvPChallenge = { ...challengeData, id: localId };
          setPvpChallenges((prev) => [newChallenge, ...prev]);
          audioManager.play('horn');
          return { success: true };
        }

        await addDoc(collection(db, 'pvp_challenges'), challengeData);
        audioManager.play('horn');
        return { success: true };
      } catch (err: any) {
        console.error('Error creating challenge:', err);
        return { success: false, error: err?.message || 'Error al despachar el desafío diplomático.' };
      }
    },
    [user, kingdom]
  );

  const respondPvPChallenge = useCallback(
    async (challengeId: string, accept: boolean, replyMessage?: string) => {
      if (!user) return { success: false, error: 'No autenticado' };
      try {
        const status: PvPChallengeStatus = accept ? 'accepted' : 'declined';
        const finalReply =
          replyMessage ||
          (accept
            ? 'Nos veremos en el campo de batalla. 🔴'
            : 'Por el momento rechazo vuestro desafío formal.');

        if (challengeId.startsWith('pvp_demo_')) {
          setPvpChallenges((prev) =>
            prev.map((ch) =>
              ch.id === challengeId
                ? { ...ch, status, replyMessage: finalReply, updatedAt: Date.now() }
                : ch
            )
          );
          audioManager.play(accept ? 'horn' : 'click');
          return { success: true };
        }

        const challengeRef = doc(db, 'pvp_challenges', challengeId);
        await updateDoc(challengeRef, {
          status,
          replyMessage: finalReply,
          updatedAt: Date.now(),
        });
        audioManager.play(accept ? 'horn' : 'click');
        return { success: true };
      } catch (err: any) {
        console.error('Error responding to challenge:', err);
        return { success: false, error: err?.message || 'Error al responder al desafío.' };
      }
    },
    [user]
  );

  const cancelPvPChallenge = useCallback(
    async (challengeId: string) => {
      if (!user) return { success: false, error: 'No autenticado' };
      try {
        if (challengeId.startsWith('pvp_demo_')) {
          setPvpChallenges((prev) => prev.filter((c) => c.id !== challengeId));
          return { success: true };
        }
        const challengeRef = doc(db, 'pvp_challenges', challengeId);
        await updateDoc(challengeRef, {
          status: 'cancelled',
          updatedAt: Date.now(),
        });
        return { success: true };
      } catch (err: any) {
        console.error('Error cancelling challenge:', err);
        return { success: false, error: err?.message || 'Error al retirar el desafío.' };
      }
    },
    [user]
  );

  const resolvePvPBattle = useCallback(
    async (challengeId: string) => {
      if (!kingdom || !user) return null;
      const challenge = pvpChallenges.find((c) => c.id === challengeId);
      if (!challenge || challenge.status !== 'accepted') return null;

      const isAttacker = challenge.challengerId === user.uid;
      const rivalName = isAttacker ? challenge.defenderKingdomName : challenge.challengerKingdomName;
      const rivalCastle = isAttacker ? challenge.defenderCastleName : challenge.challengerCastleName;
      const rivalCiv = isAttacker ? challenge.defenderCivilization : challenge.challengerCivilization;
      const rivalGlory = isAttacker ? challenge.defenderGlory : challenge.challengerGlory;

      const rivalTerritory = otherPlayerCastles.find(
        (t) => t.ownerUserId === (isAttacker ? challenge.defenderId : challenge.challengerId)
      );

      const targetTerritory: Territory = rivalTerritory || {
        id: `pvp_target_${challenge.id}`,
        name: rivalName,
        x: 5,
        y: 5,
        zone: `Reino de ${rivalName} (${CIVILIZATIONS[rivalCiv]?.name || rivalCiv})`,
        type: 'player_castle',
        defenseLevel: 2,
        garrison: { militia: 30, swordsman: 20, archer: 15, lightCavalry: 10 },
        loot: {
          gold: challenge.goldStake * 2,
          food: 500,
          wood: 400,
          stone: 400,
        },
        gloryReward: Math.max(50, Math.round(rivalGlory * 0.15)),
        isConquered: false,
        ownerName: rivalName,
        ownerCivilization: rivalCiv,
        castleName: rivalCastle,
        isRealPlayer: true,
        description: `Castillo de ${rivalCastle}`,
      };

      const deployedArmy: Partial<Record<UnitType, number>> = {};
      Object.entries(kingdom.army).forEach(([k, count]) => {
        if (k !== 'spy' && count > 0) {
          deployedArmy[k as UnitType] = count;
        }
      });

      const report = resolveBattle(kingdom, targetTerritory, deployedArmy);
      report.targetName = `Batalla Pactada contra ${rivalName} (${rivalCastle})`;
      report.summary = report.victory
        ? `¡Victoria en el Parlamento! Has vencido al ejército de ${rivalName} en la batalla pactada. Tus mesnadas se alzan con la gloria y el botín convenido.`
        : `Derrota ante ${rivalName}. El monarca rival superó vuestra estrategia en la liza acordada. Vuestras bajas han sido evacuadas a la enfermería militar.`;

      setKingdom((prev) => {
        if (!prev) return null;
        const newArmy = { ...prev.army };
        Object.entries(report.attackerCasualties).forEach(([uKey, lostCount]) => {
          if (lostCount && lostCount > 0) {
            newArmy[uKey as UnitType] = Math.max(0, (newArmy[uKey as UnitType] || 0) - lostCount);
          }
        });

        const newWoundedArmy = { ...(prev.woundedArmy || {}) };
        if (report.attackerWounded) {
          Object.entries(report.attackerWounded).forEach(([uKey, count]) => {
            if (count && count > 0) {
              newWoundedArmy[uKey as UnitType] = (newWoundedArmy[uKey as UnitType] || 0) + count;
            }
          });
        }

        const netGoldChange = report.victory
          ? challenge.goldStake
          : -Math.min(prev.resources.gold, challenge.goldStake);
        const newRes = {
          ...prev.resources,
          gold: Math.max(0, prev.resources.gold + netGoldChange),
        };

        return {
          ...prev,
          army: newArmy,
          woundedArmy: newWoundedArmy,
          resources: newRes,
          gloryPoints: Math.max(0, prev.gloryPoints + (report.victory ? report.gloryGained + 50 : -20)),
          battleReports: [report, ...prev.battleReports].slice(0, 25),
        };
      });

      if (challengeId.startsWith('pvp_demo_')) {
        setPvpChallenges((prev) =>
          prev.map((c) =>
            c.id === challengeId ? { ...c, status: 'completed', battleReport: report } : c
          )
        );
      } else {
        try {
          const ref = doc(db, 'pvp_challenges', challengeId);
          await updateDoc(ref, {
            status: 'completed',
            battleReport: report,
            updatedAt: Date.now(),
          });
        } catch (e) {
          console.warn('Error updating resolved challenge in Firestore:', e);
        }
      }

      if (report.victory) {
        audioManager.play('battleVictory');
        confetti({ particleCount: 80, spread: 90, origin: { y: 0.5 } });
      } else {
        audioManager.play('battleDefeat');
      }

      return report;
    },
    [kingdom, user, pvpChallenges, otherPlayerCastles]
  );

  // Auto-resolve accepted PvP battles whose scheduled time has elapsed
  useEffect(() => {
    if (!kingdom || !user) return;
    const dueChallenge = pvpChallenges.find(
      (c) => c.status === 'accepted' && c.scheduledTime && isBattleReadyForResolution(c.scheduledTime)
    );
    if (dueChallenge) {
      resolvePvPBattle(dueChallenge.id);
    }
  }, [pvpChallenges, kingdom, user, resolvePvPBattle]);

  return (
    <KingdomContext.Provider
      value={{
        kingdom,
        territories,
        challenges,
        rates,
        storageMax,
        maxPopulation,
        demographicRate,
        hospitalCapacity,
        totalWoundedCount,
        isKingdomLoading,
        isSyncing,
        lastSyncedAt,
        soundEnabled,
        setSoundEnabled,
        toggleSound,
        soundVolume,
        setSoundVolume,
        saveKingdomToCloud,
        startNewKingdom,
        resetKingdom,
        upgradeBuilding,
        cancelConstruction,
        instantCompleteConstruction,
        researchTechnology,
        cancelResearch,
        instantCompleteResearch,
        trainUnits,
        cancelTraining,
        instantCompleteTraining,
        hireMercenaries,
        healUnits,
        healAllUnits,
        setTaxRate,
        setFoodLevel,
        setWarFooting,
        setMilitaryStrategy,
        setFormation,
        upgradeEquipment,
        setWorkerAllocation,
        attackTerritory,
        spyTerritory,
        claimChallengeReward,
        playSound,
        pvpChallenges,
        pendingPvPChallengesCount,
        sendPvPChallenge,
        respondPvPChallenge,
        cancelPvPChallenge,
        resolvePvPBattle,
      }}
    >
      {children}
    </KingdomContext.Provider>
  );
};

export function useKingdom() {
  const ctx = useContext(KingdomContext);
  if (!ctx) {
    throw new Error('useKingdom must be used within a KingdomProvider');
  }
  return ctx;
}
