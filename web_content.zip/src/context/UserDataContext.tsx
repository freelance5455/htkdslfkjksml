import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { UserBookmark, UserNote, UserProgress, UserQuizRecord } from '../types';

interface UserDataContextType {
  bookmarks: UserBookmark[];
  notes: Record<string, UserNote>; // ruleId -> UserNote
  progressMap: Record<string, UserProgress>; // ruleId -> UserProgress
  quizRecords: UserQuizRecord[];
  isBookmarked: (ruleId: string) => boolean;
  toggleBookmark: (ruleId: string, ruleType: 'sarf' | 'nahw', ruleTitle: string) => Promise<void>;
  saveNote: (ruleId: string, ruleType: 'sarf' | 'nahw', noteText: string) => Promise<void>;
  updateProgress: (ruleId: string, status: 'not_started' | 'studying' | 'mastered') => Promise<void>;
  recordQuizResult: (score: number, total: number, category: 'sarf' | 'nahw' | 'mixed') => Promise<void>;
  loading: boolean;
}

const UserDataContext = createContext<UserDataContextType | undefined>(undefined);

export const UserDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [bookmarks, setBookmarks] = useState<UserBookmark[]>([]);
  const [notes, setNotes] = useState<Record<string, UserNote>>({});
  const [progressMap, setProgressMap] = useState<Record<string, UserProgress>>({});
  const [quizRecords, setQuizRecords] = useState<UserQuizRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  // Firestore listeners when authenticated
  useEffect(() => {
    if (!user) {
      // Load local cache if available
      try {
        const localBm = localStorage.getItem('ilm_guest_bookmarks');
        if (localBm) setBookmarks(JSON.parse(localBm));
        const localProg = localStorage.getItem('ilm_guest_progress');
        if (localProg) setProgressMap(JSON.parse(localProg));
      } catch (e) {
        console.error('Error reading local guest state', e);
      }
      return;
    }

    setLoading(true);
    const userId = user.uid;

    // 1. Bookmarks listener
    const bmPath = `users/${userId}/bookmarks`;
    const unsubBookmarks = onSnapshot(
      collection(db, 'users', userId, 'bookmarks'),
      (snapshot) => {
        const list: UserBookmark[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as UserBookmark);
        });
        setBookmarks(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, bmPath);
      }
    );

    // 2. Notes listener
    const notesPath = `users/${userId}/notes`;
    const unsubNotes = onSnapshot(
      collection(db, 'users', userId, 'notes'),
      (snapshot) => {
        const map: Record<string, UserNote> = {};
        snapshot.forEach((docSnap) => {
          const item = docSnap.data() as UserNote;
          map[item.ruleId] = item;
        });
        setNotes(map);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, notesPath);
      }
    );

    // 3. Progress listener
    const progPath = `users/${userId}/progress`;
    const unsubProgress = onSnapshot(
      collection(db, 'users', userId, 'progress'),
      (snapshot) => {
        const map: Record<string, UserProgress> = {};
        snapshot.forEach((docSnap) => {
          const item = docSnap.data() as UserProgress;
          map[item.ruleId] = item;
        });
        setProgressMap(map);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, progPath);
      }
    );

    // 4. Quiz records listener
    const quizPath = `users/${userId}/quizRecords`;
    const unsubQuiz = onSnapshot(
      collection(db, 'users', userId, 'quizRecords'),
      (snapshot) => {
        const list: UserQuizRecord[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as UserQuizRecord);
        });
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setQuizRecords(list);
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, quizPath);
        setLoading(false);
      }
    );

    return () => {
      unsubBookmarks();
      unsubNotes();
      unsubProgress();
      unsubQuiz();
    };
  }, [user]);

  const isBookmarked = (ruleId: string): boolean => {
    return bookmarks.some((b) => b.ruleId === ruleId);
  };

  const toggleBookmark = async (ruleId: string, ruleType: 'sarf' | 'nahw', ruleTitle: string) => {
    const existing = bookmarks.find((b) => b.ruleId === ruleId);
    if (!user) {
      let updated: UserBookmark[];
      if (existing) {
        updated = bookmarks.filter((b) => b.ruleId !== ruleId);
      } else {
        const newBm: UserBookmark = {
          id: `bm_${Date.now()}`,
          userId: 'guest',
          ruleId,
          ruleType,
          ruleTitle,
          createdAt: new Date().toISOString()
        };
        updated = [...bookmarks, newBm];
      }
      setBookmarks(updated);
      localStorage.setItem('ilm_guest_bookmarks', JSON.stringify(updated));
      return;
    }

    const docId = `bm_${ruleId}`;
    const docRef = doc(db, 'users', user.uid, 'bookmarks', docId);
    const path = `users/${user.uid}/bookmarks/${docId}`;
    try {
      if (existing) {
        await deleteDoc(docRef);
      } else {
        const newBm: UserBookmark = {
          id: docId,
          userId: user.uid,
          ruleId,
          ruleType,
          ruleTitle,
          createdAt: new Date().toISOString()
        };
        await setDoc(docRef, newBm);
      }
    } catch (error) {
      handleFirestoreError(error, existing ? OperationType.DELETE : OperationType.WRITE, path);
    }
  };

  const saveNote = async (ruleId: string, ruleType: 'sarf' | 'nahw', noteText: string) => {
    const nowIso = new Date().toISOString();
    if (!user) {
      const updatedNotes = {
        ...notes,
        [ruleId]: {
          id: `note_${ruleId}`,
          userId: 'guest',
          ruleId,
          ruleType,
          noteText,
          createdAt: notes[ruleId]?.createdAt || nowIso,
          updatedAt: nowIso
        }
      };
      setNotes(updatedNotes);
      return;
    }

    const docId = `note_${ruleId}`;
    const docRef = doc(db, 'users', user.uid, 'notes', docId);
    const path = `users/${user.uid}/notes/${docId}`;
    const payload: UserNote = {
      id: docId,
      userId: user.uid,
      ruleId,
      ruleType,
      noteText: noteText.slice(0, 4900),
      createdAt: notes[ruleId]?.createdAt || nowIso,
      updatedAt: nowIso
    };

    try {
      await setDoc(docRef, payload);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const updateProgress = async (ruleId: string, status: 'not_started' | 'studying' | 'mastered') => {
    const nowIso = new Date().toISOString();
    if (!user) {
      const updatedProg = {
        ...progressMap,
        [ruleId]: {
          id: `prog_${ruleId}`,
          userId: 'guest',
          ruleId,
          status,
          updatedAt: nowIso
        }
      };
      setProgressMap(updatedProg);
      localStorage.setItem('ilm_guest_progress', JSON.stringify(updatedProg));
      return;
    }

    const docId = `prog_${ruleId}`;
    const docRef = doc(db, 'users', user.uid, 'progress', docId);
    const path = `users/${user.uid}/progress/${docId}`;
    const payload: UserProgress = {
      id: docId,
      userId: user.uid,
      ruleId,
      status,
      updatedAt: nowIso
    };

    try {
      await setDoc(docRef, payload);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const recordQuizResult = async (score: number, total: number, category: 'sarf' | 'nahw' | 'mixed') => {
    const nowIso = new Date().toISOString();
    const docId = `quiz_${Date.now()}`;
    if (!user) {
      const rec: UserQuizRecord = {
        id: docId,
        userId: 'guest',
        score,
        total,
        category,
        createdAt: nowIso
      };
      setQuizRecords([rec, ...quizRecords]);
      return;
    }

    const docRef = doc(db, 'users', user.uid, 'quizRecords', docId);
    const path = `users/${user.uid}/quizRecords/${docId}`;
    const payload: UserQuizRecord = {
      id: docId,
      userId: user.uid,
      score,
      total,
      category,
      createdAt: nowIso
    };

    try {
      await setDoc(docRef, payload);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  return (
    <UserDataContext.Provider
      value={{
        bookmarks,
        notes,
        progressMap,
        quizRecords,
        isBookmarked,
        toggleBookmark,
        saveNote,
        updateProgress,
        recordQuizResult,
        loading
      }}
    >
      {children}
    </UserDataContext.Provider>
  );
};

export const useUserData = () => {
  const context = useContext(UserDataContext);
  if (!context) {
    throw new Error('useUserData must be used within a UserDataProvider');
  }
  return context;
};
