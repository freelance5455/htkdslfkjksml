import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  AppLanguage,
  Ebook,
  Category,
  CartItem,
  Coupon,
  Order,
  ExamUpdate,
  CurrentAffairItem,
  UserProfile,
  AppNotification
} from '../types';
import {
  categoriesData,
  ebooksData,
  examUpdatesData,
  currentAffairsData,
  validCoupons
} from '../data/mockData';
import { translations, Translations } from '../translations';
import confetti from 'canvas-confetti';

interface AppContextType {
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  t: Translations;
  
  // Navigation & Modals
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedCategory: string | null;
  setSelectedCategory: (catId: string | null) => void;
  selectedEbook: Ebook | null;
  setSelectedEbook: (book: Ebook | null) => void;
  readerEbook: Ebook | null;
  setReaderEbook: (book: Ebook | null) => void;
  checkoutOpen: boolean;
  setCheckoutOpen: (open: boolean) => void;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  mockTestOpen: boolean;
  setMockTestOpen: (open: boolean) => void;
  sideDrawerOpen: boolean;
  setSideDrawerOpen: (open: boolean) => void;

  // Search
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  recentSearches: string[];
  addRecentSearch: (query: string) => void;
  clearRecentSearches: () => void;

  // Data
  ebooks: Ebook[];
  categories: Category[];
  examUpdates: ExamUpdate[];
  currentAffairs: CurrentAffairItem[];

  // Cart
  cart: CartItem[];
  addToCart: (ebook: Ebook) => boolean;
  removeFromCart: (ebookId: string) => void;
  clearCart: () => void;
  cartSubtotal: number;
  cartDiscount: number;
  cartTotal: number;
  appliedCoupon: Coupon | null;
  couponError: string | null;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (ebookId: string) => void;
  isWishlisted: (ebookId: string) => boolean;

  // Purchases & Orders
  purchasedBookIds: string[];
  orders: Order[];
  createOrder: (details: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    state: string;
    paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'Wallet' | 'Free';
    isDemoPayment: boolean;
  }) => Order;
  hasAccessToBook: (ebookId: string) => boolean;

  // User Profile
  userProfile: UserProfile;
  updateUserProfile: (profile: Partial<UserProfile>) => void;
  isLoggedIn: boolean;
  setIsLoggedIn: (logged: boolean) => void;
  loginUser: (email: string, name?: string) => void;
  logoutUser: () => void;

  // Notifications
  notifications: AppNotification[];
  markNotificationsAsRead: () => void;

  // Toast
  toastMessage: { text: string; type: 'success' | 'info' | 'error' } | null;
  showToast: (text: string, type?: 'success' | 'info' | 'error') => void;

  // Admin Methods
  addEbook: (book: Omit<Ebook, 'id'>) => void;
  updateEbook: (id: string, book: Partial<Ebook>) => void;
  deleteEbook: (id: string) => void;
  addExamUpdate: (update: Omit<ExamUpdate, 'id' | 'lastUpdated'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  LANG: 'nexa_lang',
  CART: 'nexa_cart',
  WISHLIST: 'nexa_wishlist',
  PURCHASES: 'nexa_purchases',
  ORDERS: 'nexa_orders',
  PROFILE: 'nexa_profile',
  SEARCHES: 'nexa_recent_searches',
  CUSTOM_BOOKS: 'nexa_custom_books',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Language
  const [language, setLanguageState] = useState<AppLanguage>(() => {
    return (localStorage.getItem(STORAGE_KEYS.LANG) as AppLanguage) || 'en';
  });

  const setLanguage = (lang: AppLanguage) => {
    setLanguageState(lang);
    localStorage.setItem(STORAGE_KEYS.LANG, lang);
  };

  const t = translations[language] || translations.en;

  // Navigation states
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedEbook, setSelectedEbook] = useState<Ebook | null>(null);
  const [readerEbook, setReaderEbook] = useState<Ebook | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [mockTestOpen, setMockTestOpen] = useState(false);
  const [sideDrawerOpen, setSideDrawerOpen] = useState(false);

  // Search
  const [searchQuery, setSearchQuery] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SEARCHES);
      return saved ? JSON.parse(saved) : ['Assam Police SI', 'ADRE Grade III', 'RRB NTPC', 'Assam History'];
    } catch {
      return ['Assam Police SI', 'ADRE Grade III', 'RRB NTPC'];
    }
  });

  const addRecentSearch = (query: string) => {
    if (!query.trim()) return;
    setRecentSearches((prev) => {
      const filtered = prev.filter((s) => s.toLowerCase() !== query.toLowerCase());
      const updated = [query.trim(), ...filtered].slice(0, 8);
      localStorage.setItem(STORAGE_KEYS.SEARCHES, JSON.stringify(updated));
      return updated;
    });
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem(STORAGE_KEYS.SEARCHES);
  };

  // Ebooks list (initialized with mockData + any admin added books in localStorage)
  const [ebooks, setEbooks] = useState<Ebook[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CUSTOM_BOOKS);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error(e);
    }
    return ebooksData;
  });

  const [categories] = useState<Category[]>(categoriesData);
  const [examUpdates, setExamUpdates] = useState<ExamUpdate[]>(examUpdatesData);
  const [currentAffairs] = useState<CurrentAffairItem[]>(currentAffairsData);

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CART);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
  }, [cart]);

  // Wishlist
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.WISHLIST);
      return saved ? JSON.parse(saved) : ['nx-adre-gr3-mastery', 'nx-assam-gk-history-encyclopedia'];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(wishlist));
  }, [wishlist]);

  // Purchases
  const [purchasedBookIds, setPurchasedBookIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PURCHASES);
      // Auto-unlock free books by default
      const freeBookIds = ebooksData.filter(b => b.isFree).map(b => b.id);
      if (saved) {
        const parsed = JSON.parse(saved);
        return Array.from(new Set([...parsed, ...freeBookIds]));
      }
      return freeBookIds;
    } catch {
      return ebooksData.filter(b => b.isFree).map(b => b.id);
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify(purchasedBookIds));
  }, [purchasedBookIds]);

  // Orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
      return saved ? JSON.parse(saved) : [
        {
          id: 'ord-initial-101',
          orderNumber: 'NX-2026-78421',
          createdAt: '18 March 2026, 11:30 AM',
          items: [
            {
              ebookId: 'nx-free-assam-budget-economic-survey',
              title: 'Assam State Budget 2026-27 & Economic Survey Highlights',
              price: 0,
              language: 'English'
            }
          ],
          subtotal: 0,
          discount: 0,
          total: 0,
          customerName: 'Arup Saikia',
          customerEmail: 'arup.saikia.assam@example.com',
          customerPhone: '+91 98640 12345',
          state: 'Assam',
          paymentMethod: 'Free',
          paymentStatus: 'VERIFIED_PAID',
          transactionId: 'TXN-FREE-001'
        }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  }, [orders]);

  // User Profile & Auth
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return saved
        ? JSON.parse(saved)
        : {
            id: 'usr-student-01',
            name: 'Arup Saikia',
            email: 'arup.saikia.assam@example.com',
            phone: '+91 98640 12345',
            state: 'Assam',
            targetExam: 'Assam Direct Recruitment (ADRE) & Police SI',
            preferredLanguage: 'as',
            joinedDate: 'January 2026',
            isAdmin: true, // Empowered for demonstration & full evaluation
            studyStreakDays: 14,
            hoursRead: 38
          };
    } catch {
      return {
        id: 'usr-student-01',
        name: 'Arup Saikia',
        email: 'arup.saikia.assam@example.com',
        phone: '+91 98640 12345',
        state: 'Assam',
        targetExam: 'Assam Direct Recruitment (ADRE)',
        preferredLanguage: 'as',
        joinedDate: 'January 2026',
        isAdmin: true,
        studyStreakDays: 14,
        hoursRead: 38
      };
    }
  });

  const updateUserProfile = (updated: Partial<UserProfile>) => {
    setUserProfile((prev) => {
      const next = { ...prev, ...updated };
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(next));
      return next;
    });
  };

  const loginUser = (email: string, name?: string) => {
    setIsLoggedIn(true);
    updateUserProfile({
      email,
      name: name || email.split('@')[0],
    });
    showToast(`Welcome back, ${name || email}!`, 'success');
  };

  const logoutUser = () => {
    setIsLoggedIn(false);
    showToast('You have been logged out.', 'info');
  };

  // Toast
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 3800);
  };

  // Notifications
  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'notif-1',
      title: 'ADRE 2.0 Exam Syllabus Guide Updated',
      message: 'New syllabus guidelines released for Class III & IV. Check the Official Updates section.',
      time: '1 hour ago',
      read: false,
      type: 'exam'
    },
    {
      id: 'notif-2',
      title: 'Flash Sale: 20% OFF with Code NEXA20',
      message: 'Use code NEXA20 at checkout on all Railway & Police combos.',
      time: '3 hours ago',
      read: false,
      type: 'offer'
    },
    {
      id: 'notif-3',
      title: 'Free Current Affairs March 2026 Ebook',
      message: 'March 2026 PDF is now available for free download in My Books.',
      time: '1 day ago',
      read: true,
      type: 'update'
    }
  ]);

  const markNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  // Cart operations
  const addToCart = (ebook: Ebook): boolean => {
    // Check if already in cart
    if (cart.some((item) => item.ebookId === ebook.id)) {
      showToast('This ebook is already in your cart.', 'info');
      return false;
    }
    // Check if already purchased
    if (purchasedBookIds.includes(ebook.id)) {
      showToast('You already own this ebook! Check My Books.', 'info');
      return false;
    }

    const newItem: CartItem = {
      ebookId: ebook.id,
      ebook,
      addedAt: new Date().toISOString()
    };
    setCart((prev) => [...prev, newItem]);
    showToast(`Added "${ebook.title.substring(0, 28)}..." to cart!`, 'success');
    return true;
  };

  const removeFromCart = (ebookId: string) => {
    setCart((prev) => prev.filter((item) => item.ebookId !== ebookId));
    showToast('Removed ebook from cart.', 'info');
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  // Cart Calculations
  const cartSubtotal = cart.reduce((sum, item) => sum + item.ebook.price, 0);

  let cartDiscount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.discountType === 'percentage') {
      cartDiscount = Math.round((cartSubtotal * appliedCoupon.discountValue) / 100);
    } else {
      cartDiscount = Math.min(appliedCoupon.discountValue, cartSubtotal);
    }
  }

  const cartTotal = Math.max(0, cartSubtotal - cartDiscount);

  const applyCoupon = (code: string): boolean => {
    const cleanCode = code.trim().toUpperCase();
    const coupon = validCoupons.find((c) => c.code.toUpperCase() === cleanCode);
    if (!coupon) {
      setCouponError('Invalid coupon code. Try NEXA20 or ASSAM100.');
      return false;
    }
    if (cartSubtotal < coupon.minOrderValue) {
      setCouponError(`Minimum order value of ₹${coupon.minOrderValue} required for this coupon.`);
      return false;
    }

    setAppliedCoupon(coupon);
    setCouponError(null);
    showToast(`Coupon ${coupon.code} applied successfully!`, 'success');
    try {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8 }
      });
    } catch (e) {
      console.error(e);
    }
    return true;
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponError(null);
    showToast('Coupon removed.', 'info');
  };

  // Wishlist operations
  const toggleWishlist = (ebookId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(ebookId);
      if (exists) {
        showToast('Removed from wishlist.', 'info');
        return prev.filter((id) => id !== ebookId);
      } else {
        showToast('Added to your wishlist!', 'success');
        return [...prev, ebookId];
      }
    });
  };

  const isWishlisted = (ebookId: string) => wishlist.includes(ebookId);

  const hasAccessToBook = (ebookId: string) => {
    const book = ebooks.find((b) => b.id === ebookId);
    if (book?.isFree) return true;
    return purchasedBookIds.includes(ebookId);
  };

  // Order Creation
  const createOrder = ({
    customerName,
    customerEmail,
    customerPhone,
    state,
    paymentMethod,
    isDemoPayment
  }: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    state: string;
    paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'Wallet' | 'Free';
    isDemoPayment: boolean;
  }): Order => {
    const orderNum = `NX-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber: orderNum,
      createdAt: new Date().toLocaleString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      items: cart.map((item) => ({
        ebookId: item.ebook.id,
        title: item.ebook.title,
        price: item.ebook.price,
        language: item.ebook.language
      })),
      subtotal: cartSubtotal,
      discount: cartDiscount,
      couponApplied: appliedCoupon ? appliedCoupon.code : undefined,
      total: cartTotal,
      customerName,
      customerEmail,
      customerPhone,
      state,
      paymentMethod,
      paymentStatus: isDemoPayment ? 'DEMO_PAID' : 'VERIFIED_PAID',
      transactionId: `TXN-${paymentMethod.toUpperCase()}-${Math.floor(10000000 + Math.random() * 90000000)}`
    };

    // Unlock books permanently
    const newlyPurchasedIds = cart.map((item) => item.ebook.id);
    setPurchasedBookIds((prev) => Array.from(new Set([...prev, ...newlyPurchasedIds])));

    // Append order
    setOrders((prev) => [newOrder, ...prev]);

    // Clear cart
    clearCart();

    // Trigger celebration
    try {
      confetti({
        particleCount: 120,
        spread: 90,
        origin: { y: 0.6 }
      });
    } catch (e) {
      console.error(e);
    }

    showToast(`Order #${orderNum} confirmed! Ebooks unlocked in My Books.`, 'success');
    return newOrder;
  };

  // Admin operations
  const addEbook = (newBookData: Omit<Ebook, 'id'>) => {
    const newBook: Ebook = {
      ...newBookData,
      id: `nx-custom-${Date.now()}`
    };
    setEbooks((prev) => {
      const updated = [newBook, ...prev];
      localStorage.setItem(STORAGE_KEYS.CUSTOM_BOOKS, JSON.stringify(updated));
      return updated;
    });
    showToast(`Ebook "${newBook.title}" created successfully!`, 'success');
  };

  const updateEbook = (id: string, updatedFields: Partial<Ebook>) => {
    setEbooks((prev) => {
      const updated = prev.map((book) => (book.id === id ? { ...book, ...updatedFields } : book));
      localStorage.setItem(STORAGE_KEYS.CUSTOM_BOOKS, JSON.stringify(updated));
      return updated;
    });
    showToast('Ebook details updated successfully!', 'success');
  };

  const deleteEbook = (id: string) => {
    setEbooks((prev) => {
      const updated = prev.filter((book) => book.id !== id);
      localStorage.setItem(STORAGE_KEYS.CUSTOM_BOOKS, JSON.stringify(updated));
      return updated;
    });
    showToast('Ebook removed from catalog.', 'info');
  };

  const addExamUpdate = (newUpdate: Omit<ExamUpdate, 'id' | 'lastUpdated'>) => {
    const item: ExamUpdate = {
      ...newUpdate,
      id: `up-custom-${Date.now()}`,
      lastUpdated: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
    };
    setExamUpdates((prev) => [item, ...prev]);
    showToast('Exam notification published to student feed!', 'success');
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        activeTab,
        setActiveTab,
        selectedCategory,
        setSelectedCategory,
        selectedEbook,
        setSelectedEbook,
        readerEbook,
        setReaderEbook,
        checkoutOpen,
        setCheckoutOpen,
        authModalOpen,
        setAuthModalOpen,
        mockTestOpen,
        setMockTestOpen,
        sideDrawerOpen,
        setSideDrawerOpen,
        searchQuery,
        setSearchQuery,
        recentSearches,
        addRecentSearch,
        clearRecentSearches,
        ebooks,
        categories,
        examUpdates,
        currentAffairs,
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        cartSubtotal,
        cartDiscount,
        cartTotal,
        appliedCoupon,
        couponError,
        applyCoupon,
        removeCoupon,
        wishlist,
        toggleWishlist,
        isWishlisted,
        purchasedBookIds,
        orders,
        createOrder,
        hasAccessToBook,
        userProfile,
        updateUserProfile,
        isLoggedIn,
        setIsLoggedIn,
        loginUser,
        logoutUser,
        notifications,
        markNotificationsAsRead,
        toastMessage,
        showToast,
        addEbook,
        updateEbook,
        deleteEbook,
        addExamUpdate
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
