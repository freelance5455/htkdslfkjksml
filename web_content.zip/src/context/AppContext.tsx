import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Site, 
  Labour, 
  SiteAttendanceRecord, 
  LabourAdvancePayment, 
  EngineerPayment, 
  MessExpense, 
  MessCollection, 
  RoomOwnerConfig, 
  LandlordPayment 
} from '../types';
import { 
  INITIAL_SITES, 
  INITIAL_LABOURS, 
  INITIAL_ATTENDANCE, 
  INITIAL_LABOUR_ADVANCES, 
  INITIAL_ENGINEER_PAYMENTS, 
  INITIAL_MESS_EXPENSES, 
  INITIAL_MESS_COLLECTIONS, 
  INITIAL_ROOM_OWNER_CONFIG, 
  INITIAL_LANDLORD_PAYMENTS 
} from '../data/initialData';

const STORAGE_KEY = 'contractor_mess_manager_v2';

interface AppContextType {
  sites: Site[];
  labours: Labour[];
  attendance: SiteAttendanceRecord[];
  advances: LabourAdvancePayment[];
  engineerPayments: EngineerPayment[];
  messExpenses: MessExpense[];
  messCollections: MessCollection[];
  roomOwnerConfig: RoomOwnerConfig;
  landlordPayments: LandlordPayment[];
  activeTab: 'dashboard' | 'sites' | 'mess' | 'landlord' | 'labours' | 'settings';
  setActiveTab: (tab: 'dashboard' | 'sites' | 'mess' | 'landlord' | 'labours' | 'settings') => void;
  selectedSiteId: string | null;
  setSelectedSiteId: (id: string | null) => void;

  // Site Operations
  addSite: (site: Omit<Site, 'id'>) => void;
  updateSite: (id: string, site: Partial<Site>) => void;
  deleteSite: (id: string) => void;

  // Labour Operations
  addLabour: (labour: Omit<Labour, 'id' | 'createdAt'>) => void;
  updateLabour: (id: string, labour: Partial<Labour>) => void;
  deleteLabour: (id: string) => void;

  // Attendance & Wage Operations
  addAttendanceRecord: (record: Omit<SiteAttendanceRecord, 'id'>) => void;
  deleteAttendanceRecord: (id: string) => void;

  // Labour Advance Operations
  addLabourAdvance: (adv: Omit<LabourAdvancePayment, 'id'>) => void;
  deleteLabourAdvance: (id: string) => void;

  // Engineer Payment Operations
  addEngineerPayment: (payment: Omit<EngineerPayment, 'id'>) => void;
  deleteEngineerPayment: (id: string) => void;

  // Mess Operations
  addMessExpense: (expense: Omit<MessExpense, 'id'>) => void;
  updateMessExpense: (id: string, expense: Partial<MessExpense>) => void;
  deleteMessExpense: (id: string) => void;
  addMessCollection: (collection: Omit<MessCollection, 'id'>) => void;
  deleteMessCollection: (id: string) => void;

  // Landlord Operations
  updateRoomOwnerConfig: (config: Partial<RoomOwnerConfig>) => void;
  addLandlordPayment: (payment: Omit<LandlordPayment, 'id'>) => void;
  updateLandlordPayment: (id: string, payment: Partial<LandlordPayment>) => void;
  deleteLandlordPayment: (id: string) => void;

  // Backup & Restore
  exportDataToJson: () => void;
  importDataFromJson: (jsonStr: string) => boolean;
  resetToDemoData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'sites' | 'mess' | 'landlord' | 'labours' | 'settings'>('dashboard');
  const [selectedSiteId, setSelectedSiteId] = useState<string | null>('site-1');

  // Initial State from LocalStorage or Default
  const [sites, setSites] = useState<Site[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_sites`);
      return saved ? JSON.parse(saved) : INITIAL_SITES;
    } catch {
      return INITIAL_SITES;
    }
  });

  const [labours, setLabours] = useState<Labour[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_labours`);
      return saved ? JSON.parse(saved) : INITIAL_LABOURS;
    } catch {
      return INITIAL_LABOURS;
    }
  });

  const [attendance, setAttendance] = useState<SiteAttendanceRecord[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_attendance`);
      return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
    } catch {
      return INITIAL_ATTENDANCE;
    }
  });

  const [advances, setAdvances] = useState<LabourAdvancePayment[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_advances`);
      return saved ? JSON.parse(saved) : INITIAL_LABOUR_ADVANCES;
    } catch {
      return INITIAL_LABOUR_ADVANCES;
    }
  });

  const [engineerPayments, setEngineerPayments] = useState<EngineerPayment[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_eng_payments`);
      return saved ? JSON.parse(saved) : INITIAL_ENGINEER_PAYMENTS;
    } catch {
      return INITIAL_ENGINEER_PAYMENTS;
    }
  });

  const [messExpenses, setMessExpenses] = useState<MessExpense[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_mess_expenses`);
      return saved ? JSON.parse(saved) : INITIAL_MESS_EXPENSES;
    } catch {
      return INITIAL_MESS_EXPENSES;
    }
  });

  const [messCollections, setMessCollections] = useState<MessCollection[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_mess_collections`);
      return saved ? JSON.parse(saved) : INITIAL_MESS_COLLECTIONS;
    } catch {
      return INITIAL_MESS_COLLECTIONS;
    }
  });

  const [roomOwnerConfig, setRoomOwnerConfig] = useState<RoomOwnerConfig>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_room_owner_config`);
      return saved ? JSON.parse(saved) : INITIAL_ROOM_OWNER_CONFIG;
    } catch {
      return INITIAL_ROOM_OWNER_CONFIG;
    }
  });

  const [landlordPayments, setLandlordPayments] = useState<LandlordPayment[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_landlord_payments`);
      return saved ? JSON.parse(saved) : INITIAL_LANDLORD_PAYMENTS;
    } catch {
      return INITIAL_LANDLORD_PAYMENTS;
    }
  });

  // Auto-Save Effect
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_sites`, JSON.stringify(sites));
      localStorage.setItem(`${STORAGE_KEY}_labours`, JSON.stringify(labours));
      localStorage.setItem(`${STORAGE_KEY}_attendance`, JSON.stringify(attendance));
      localStorage.setItem(`${STORAGE_KEY}_advances`, JSON.stringify(advances));
      localStorage.setItem(`${STORAGE_KEY}_eng_payments`, JSON.stringify(engineerPayments));
      localStorage.setItem(`${STORAGE_KEY}_mess_expenses`, JSON.stringify(messExpenses));
      localStorage.setItem(`${STORAGE_KEY}_mess_collections`, JSON.stringify(messCollections));
      localStorage.setItem(`${STORAGE_KEY}_room_owner_config`, JSON.stringify(roomOwnerConfig));
      localStorage.setItem(`${STORAGE_KEY}_landlord_payments`, JSON.stringify(landlordPayments));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [sites, labours, attendance, advances, engineerPayments, messExpenses, messCollections, roomOwnerConfig, landlordPayments]);

  // Site Operations
  const addSite = (site: Omit<Site, 'id'>) => {
    const newSite: Site = {
      ...site,
      id: `site-${Date.now()}`
    };
    setSites(prev => [newSite, ...prev]);
    setSelectedSiteId(newSite.id);
  };

  const updateSite = (id: string, updated: Partial<Site>) => {
    setSites(prev => prev.map(s => s.id === id ? { ...s, ...updated } : s));
  };

  const deleteSite = (id: string) => {
    if (window.confirm('আপনি কি নিশ্চিত যে এই সাইটটি মুছে ফেলতে চান?')) {
      setSites(prev => prev.filter(s => s.id !== id));
      if (selectedSiteId === id) {
        setSelectedSiteId(sites.find(s => s.id !== id)?.id || null);
      }
    }
  };

  // Labour Operations
  const addLabour = (labour: Omit<Labour, 'id' | 'createdAt'>) => {
    const newLabour: Labour = {
      ...labour,
      id: `lab-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setLabours(prev => [newLabour, ...prev]);
  };

  const updateLabour = (id: string, updated: Partial<Labour>) => {
    setLabours(prev => prev.map(l => l.id === id ? { ...l, ...updated } : l));
  };

  const deleteLabour = (id: string) => {
    if (window.confirm('আপনি কি এই লেবারকে তালিকা থেকে মুছে ফেলতে চান?')) {
      setLabours(prev => prev.filter(l => l.id !== id));
    }
  };

  // Attendance & Wage Operations
  const addAttendanceRecord = (record: Omit<SiteAttendanceRecord, 'id'>) => {
    const newRec: SiteAttendanceRecord = {
      ...record,
      id: `att-${Date.now()}`
    };
    setAttendance(prev => [newRec, ...prev]);
  };

  const deleteAttendanceRecord = (id: string) => {
    setAttendance(prev => prev.filter(a => a.id !== id));
  };

  // Labour Advance Operations
  const addLabourAdvance = (adv: Omit<LabourAdvancePayment, 'id'>) => {
    const newAdv: LabourAdvancePayment = {
      ...adv,
      id: `adv-${Date.now()}`
    };
    setAdvances(prev => [newAdv, ...prev]);
  };

  const deleteLabourAdvance = (id: string) => {
    setAdvances(prev => prev.filter(a => a.id !== id));
  };

  // Engineer Payment Operations
  const addEngineerPayment = (payment: Omit<EngineerPayment, 'id'>) => {
    const newPayment: EngineerPayment = {
      ...payment,
      id: `eng-${Date.now()}`
    };
    setEngineerPayments(prev => [newPayment, ...prev]);
  };

  const deleteEngineerPayment = (id: string) => {
    setEngineerPayments(prev => prev.filter(p => p.id !== id));
  };

  // Mess Operations
  const addMessExpense = (expense: Omit<MessExpense, 'id'>) => {
    const newExp: MessExpense = {
      ...expense,
      id: `exp-${Date.now()}`
    };
    setMessExpenses(prev => [newExp, ...prev]);
  };

  const updateMessExpense = (id: string, updated: Partial<MessExpense>) => {
    setMessExpenses(prev => prev.map(e => e.id === id ? { ...e, ...updated } : e));
  };

  const deleteMessExpense = (id: string) => {
    setMessExpenses(prev => prev.filter(e => e.id !== id));
  };

  const addMessCollection = (collection: Omit<MessCollection, 'id'>) => {
    const newCol: MessCollection = {
      ...collection,
      id: `col-${Date.now()}`
    };
    setMessCollections(prev => [newCol, ...prev]);
  };

  const deleteMessCollection = (id: string) => {
    setMessCollections(prev => prev.filter(c => c.id !== id));
  };

  // Landlord Operations
  const updateRoomOwnerConfig = (config: Partial<RoomOwnerConfig>) => {
    setRoomOwnerConfig(prev => ({ ...prev, ...config }));
  };

  const addLandlordPayment = (payment: Omit<LandlordPayment, 'id'>) => {
    const newPayment: LandlordPayment = {
      ...payment,
      id: `lp-${Date.now()}`
    };
    setLandlordPayments(prev => [newPayment, ...prev]);
  };

  const updateLandlordPayment = (id: string, updated: Partial<LandlordPayment>) => {
    setLandlordPayments(prev => prev.map(p => p.id === id ? { ...p, ...updated } : p));
  };

  const deleteLandlordPayment = (id: string) => {
    setLandlordPayments(prev => prev.filter(p => p.id !== id));
  };

  // JSON Export & Import
  const exportDataToJson = () => {
    const exportBundle = {
      version: '2.0',
      exportedAt: new Date().toISOString(),
      sites,
      labours,
      attendance,
      advances,
      engineerPayments,
      messExpenses,
      messCollections,
      roomOwnerConfig,
      landlordPayments
    };
    const blob = new Blob([JSON.stringify(exportBundle, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `contractor_mess_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importDataFromJson = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.sites && Array.isArray(data.sites)) setSites(data.sites);
      if (data.labours && Array.isArray(data.labours)) setLabours(data.labours);
      if (data.attendance && Array.isArray(data.attendance)) setAttendance(data.attendance);
      if (data.advances && Array.isArray(data.advances)) setAdvances(data.advances);
      if (data.engineerPayments && Array.isArray(data.engineerPayments)) setEngineerPayments(data.engineerPayments);
      if (data.messExpenses && Array.isArray(data.messExpenses)) setMessExpenses(data.messExpenses);
      if (data.messCollections && Array.isArray(data.messCollections)) setMessCollections(data.messCollections);
      if (data.roomOwnerConfig) setRoomOwnerConfig(data.roomOwnerConfig);
      if (data.landlordPayments && Array.isArray(data.landlordPayments)) setLandlordPayments(data.landlordPayments);
      return true;
    } catch (e) {
      console.error('Import failed:', e);
      return false;
    }
  };

  const resetToDemoData = () => {
    setSites(INITIAL_SITES);
    setLabours(INITIAL_LABOURS);
    setAttendance(INITIAL_ATTENDANCE);
    setAdvances(INITIAL_LABOUR_ADVANCES);
    setEngineerPayments(INITIAL_ENGINEER_PAYMENTS);
    setMessExpenses(INITIAL_MESS_EXPENSES);
    setMessCollections(INITIAL_MESS_COLLECTIONS);
    setRoomOwnerConfig(INITIAL_ROOM_OWNER_CONFIG);
    setLandlordPayments(INITIAL_LANDLORD_PAYMENTS);
    setSelectedSiteId('site-1');
  };

  return (
    <AppContext.Provider
      value={{
        sites,
        labours,
        attendance,
        advances,
        engineerPayments,
        messExpenses,
        messCollections,
        roomOwnerConfig,
        landlordPayments,
        activeTab,
        setActiveTab,
        selectedSiteId,
        setSelectedSiteId,
        addSite,
        updateSite,
        deleteSite,
        addLabour,
        updateLabour,
        deleteLabour,
        addAttendanceRecord,
        deleteAttendanceRecord,
        addLabourAdvance,
        deleteLabourAdvance,
        addEngineerPayment,
        deleteEngineerPayment,
        addMessExpense,
        updateMessExpense,
        deleteMessExpense,
        addMessCollection,
        deleteMessCollection,
        updateRoomOwnerConfig,
        addLandlordPayment,
        updateLandlordPayment,
        deleteLandlordPayment,
        exportDataToJson,
        importDataFromJson,
        resetToDemoData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
