import React, { createContext, useContext, useState, ReactNode } from 'react';
import { NavTab, LedgerItem, TournamentMatch, ChatMessage } from '../types/index.ts';

interface AppContextType {
  currentTab: NavTab;
  setCurrentTab: (tab: NavTab) => void;
  coins: number;
  diamonds: number;
  cashWon: number;
  ign: string;
  setIgn: (ign: string) => void;
  uid: string;
  guild: string;
  setGuild: (guild: string) => void;
  bio: string;
  setBio: (bio: string) => void;
  upiId: string;
  setUpiId: (upiId: string) => void;
  ledger: LedgerItem[];
  addLedgerEntry: (entry: Omit<LedgerItem, 'id'>) => void;
  addCoins: (amount: number, target: 'coins' | 'diamonds') => void;
  deductCoins: (amount: number) => boolean;
  toast: { message: string; isVisible: boolean; type: 'success' | 'error' | 'info' };
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  // Modals
  isJoinModalOpen: boolean;
  selectedMatch: TournamentMatch | null;
  openJoinModal: (match: TournamentMatch) => void;
  closeJoinModal: () => void;
  isDepositModalOpen: boolean;
  setIsDepositModalOpen: (open: boolean) => void;
  isOtpModalOpen: boolean;
  otpPayoutData: { amount: number; destination: string };
  openOtpModal: (amount: number, destination: string) => void;
  closeOtpModal: () => void;
  isEditProfileOpen: boolean;
  setIsEditProfileOpen: (open: boolean) => void;
  isEditUpiOpen: boolean;
  setIsEditUpiOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  // Chat
  chatMessages: ChatMessage[];
  sendChatMessage: (text: string) => void;
}

const initialLedger: LedgerItem[] = [
  {
    id: 'l1',
    title: '+₹100 UPI Deposit',
    subtitle: 'UTR #9281 Verified',
    amount: 110,
    type: 'deposit',
    timestamp: 'Today',
    isPositive: true,
  },
  {
    id: 'l2',
    title: 'Joined Solo #1039',
    subtitle: 'Bermuda Scrims',
    amount: 30,
    type: 'entry',
    timestamp: 'Yesterday',
    isPositive: false,
  },
  {
    id: 'l3',
    title: 'Won 4 Kills Bounty',
    subtitle: 'Match Solo #1039',
    amount: 80,
    type: 'bounty',
    timestamp: 'Yesterday',
    isPositive: true,
  },
  {
    id: 'l4',
    title: 'Squad Entry #1032',
    subtitle: 'Purgatory Clash',
    amount: 50,
    type: 'entry',
    timestamp: '2 days ago',
    isPositive: false,
  },
];

const initialMessages: ChatMessage[] = [
  {
    id: 'm1',
    sender: 'Arbiter #42 (Official)',
    text: 'Welcome players to Match #1042! Room is unpaused. Do not team up or use emulators. Match triggers at zero count.',
    isUser: false,
    role: 'Official',
  },
  {
    id: 'm2',
    sender: 'System Alert',
    text: 'Anti-cheat telemetry stream is actively recording all inputs.',
    isUser: false,
    role: 'System',
  },
  {
    id: 'm3',
    sender: 'You (Slot #24)',
    text: 'Lobby credentials confirmed. Slot occupied!',
    isUser: true,
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [coins, setCoins] = useState<number>(120);
  const [diamonds, setDiamonds] = useState<number>(450);
  const [cashWon] = useState<number>(8940);
  const [ign, setIgn] = useState<string>('ALPHA_V7');
  const [uid] = useState<string>('84920412');
  const [guild, setGuild] = useState<string>('VORTEX_ESPORTS');
  const [bio, setBio] = useState<string>('Assaulter & Rusher • Top Frag Free Fire Scrims');
  const [upiId, setUpiId] = useState<string>('alpha_v7@axl');
  const [ledger, setLedger] = useState<LedgerItem[]>(initialLedger);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(initialMessages);

  // Modals
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [selectedMatch, setSelectedMatch] = useState<TournamentMatch | null>(null);
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isOtpModalOpen, setIsOtpModalOpen] = useState(false);
  const [otpPayoutData, setOtpPayoutData] = useState({ amount: 500, destination: 'UPI (alpha_v7@axl)' });
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isEditUpiOpen, setIsEditUpiOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Toast
  const [toast, setToast] = useState<{ message: string; isVisible: boolean; type: 'success' | 'error' | 'info' }>({
    message: '',
    isVisible: false,
    type: 'success',
  });

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, isVisible: true, type });
    setTimeout(() => {
      setToast((prev) => ({ ...prev, isVisible: false }));
    }, 2800);
  };

  const addLedgerEntry = (entry: Omit<LedgerItem, 'id'>) => {
    const newItem: LedgerItem = {
      ...entry,
      id: 'l_' + Date.now(),
    };
    setLedger((prev) => [newItem, ...prev]);
  };

  const addCoins = (amount: number, target: 'coins' | 'diamonds') => {
    if (target === 'coins') {
      const bonus = amount >= 500 ? 60 : amount >= 100 ? 10 : 0;
      const total = amount + bonus;
      setCoins((prev) => prev + total);
      addLedgerEntry({
        title: `+₹${amount} UPI Deposit`,
        subtitle: `UTR Verified (+${bonus} Bonus)`,
        amount: total,
        type: 'deposit',
        timestamp: 'Just now',
        isPositive: true,
      });
      showToast(`Added ${total} Game Coins to your vault!`);
    } else {
      setDiamonds((prev) => prev + amount);
      addLedgerEntry({
        title: `+${amount} Free Fire Diamonds`,
        subtitle: `Synced to UID: ${uid}`,
        amount,
        type: 'deposit',
        timestamp: 'Just now',
        isPositive: true,
      });
      showToast(`Dispatched ${amount} Diamonds to Free Fire UID: ${uid}!`);
    }
  };

  const deductCoins = (amount: number): boolean => {
    if (coins < amount) {
      showToast(`Insufficient coins! You need ₹${amount} coins. Please deposit first.`, 'error');
      setIsDepositModalOpen(true);
      return false;
    }
    setCoins((prev) => prev - amount);
    return true;
  };

  const openJoinModal = (match: TournamentMatch) => {
    setSelectedMatch(match);
    setIsJoinModalOpen(true);
  };

  const closeJoinModal = () => {
    setIsJoinModalOpen(false);
    setSelectedMatch(null);
  };

  const openOtpModal = (amount: number, destination: string) => {
    setOtpPayoutData({ amount, destination });
    setIsOtpModalOpen(true);
  };

  const closeOtpModal = () => {
    setIsOtpModalOpen(false);
  };

  const sendChatMessage = (text: string) => {
    const newMsg: ChatMessage = {
      id: 'm_' + Date.now(),
      sender: `You (Slot #24)`,
      text,
      isUser: true,
    };
    setChatMessages((prev) => [...prev, newMsg]);

    setTimeout(() => {
      const replyMsg: ChatMessage = {
        id: 'm_reply_' + Date.now(),
        sender: 'Arbiter #42 (Official)',
        text: 'Ticket acknowledged. Match arbiter is actively overseeing slot allocations and lobby ping.',
        isUser: false,
        role: 'Official',
      };
      setChatMessages((prev) => [...prev, replyMsg]);
    }, 1200);
  };

  return (
    <AppContext.Provider
      value={{
        currentTab,
        setCurrentTab,
        coins,
        diamonds,
        cashWon,
        ign,
        setIgn,
        uid,
        guild,
        setGuild,
        bio,
        setBio,
        upiId,
        setUpiId,
        ledger,
        addLedgerEntry,
        addCoins,
        deductCoins,
        toast,
        showToast,
        isJoinModalOpen,
        selectedMatch,
        openJoinModal,
        closeJoinModal,
        isDepositModalOpen,
        setIsDepositModalOpen,
        isOtpModalOpen,
        otpPayoutData,
        openOtpModal,
        closeOtpModal,
        isEditProfileOpen,
        setIsEditProfileOpen,
        isEditUpiOpen,
        setIsEditUpiOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        chatMessages,
        sendChatMessage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
