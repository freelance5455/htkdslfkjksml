import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  User,
  UserRole,
  Provider,
  DeliveryPartner,
  CategoryMeta,
  ServiceItem,
  Order,
  ChatSession,
  ChatMessage,
  AdminConfig,
  WithdrawalRequest,
  SafetyIncidentReport,
  AppNotification,
  ServiceCategoryType
} from '../types';
import {
  CATEGORIES,
  ALL_SERVICES,
  MOCK_USERS,
  MOCK_PROVIDERS,
  MOCK_DELIVERY_PARTNERS,
  INITIAL_ADMIN_CONFIG,
  INITIAL_ORDERS,
  INITIAL_CHAT_SESSIONS,
  INITIAL_CHAT_MESSAGES,
  INITIAL_NOTIFICATIONS,
  INITIAL_WITHDRAWALS,
  INITIAL_SAFETY_INCIDENTS
} from '../data/mockData';
import { apiFetch } from '../services/api';

export interface CartItem {
  service: ServiceItem;
  quantity: number;
  selectedOptions?: string[];
}

export interface AppContextType {
  user: User;
  setUser: (u: User) => void;
  role: UserRole;
  setRole: (r: UserRole) => void;
  switchRoleQuickly: (role: UserRole) => void;
  currentLocation: {
    city: string;
    locality: string;
    coordinates?: { lat: number; lng: number };
  };
  setCurrentLocation: (loc: { city: string; locality: string; coordinates?: { lat: number; lng: number } }) => void;
  selectedCategory: ServiceCategoryType | 'all';
  setSelectedCategory: (cat: ServiceCategoryType | 'all') => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  categories: CategoryMeta[];
  services: ServiceItem[];
  providers: Provider[];
  deliveryPartners: DeliveryPartner[];
  orders: Order[];
  chatSessions: ChatSession[];
  chatMessages: Record<string, ChatMessage[]>;
  adminConfig: AdminConfig;
  withdrawals: WithdrawalRequest[];
  safetyIncidents: SafetyIncidentReport[];
  notifications: AppNotification[];
  cart: CartItem[];
  addToCart: (service: ServiceItem, selectedOptions?: string[]) => void;
  removeFromCart: (serviceId: string) => void;
  updateCartQuantity: (serviceId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: number;
  activeOrder: Order | null;
  setActiveOrderId: (id: string | null) => void;
  activeChatSession: ChatSession | null;
  setActiveChatSessionId: (id: string | null) => void;
  isChatOpen: boolean;
  setIsChatOpen: (open: boolean) => void;
  isSosOpen: boolean;
  setIsSosOpen: (open: boolean) => void;
  isAuthOpen: boolean;
  setIsAuthOpen: (open: boolean) => void;
  deviceFrame: 'iphone' | 'android' | 'responsive';
  setDeviceFrame: (frame: 'iphone' | 'android' | 'responsive') => void;

  // Actions
  placeOrder: (orderPayload: Partial<Order>) => Promise<Order>;
  updateOrderStatus: (orderId: string, status: Order['status']) => Promise<void>;
  cancelOrder: (orderId: string, reason: string) => Promise<void>;
  rateOrder: (orderId: string, rating: number, comment?: string) => Promise<void>;
  sendChatMessage: (sessionId: string, text: string) => Promise<{ success: boolean; error?: string; limitExceeded?: boolean }>;
  unlockPaidChat: (sessionId: string) => Promise<void>;
  addCustomService: (providerId: string, serviceData: Partial<ServiceItem>) => Promise<void>;
  updateProvider: (providerId: string, updates: Partial<Provider>) => Promise<void>;
  requestWithdrawal: (providerId: string, amount: number, bankAccount: string, ifscOrUpi: string) => Promise<void>;
  processWithdrawal: (withdrawalId: string, status: 'approved' | 'rejected') => Promise<void>;
  updateAdminConfig: (updates: Partial<AdminConfig>) => Promise<void>;
  triggerEmergencySos: (locationNote?: string) => Promise<void>;
  markNotificationAsRead: (id: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [user, setUser] = useState<User>(MOCK_USERS[0]);
  const [role, setRole] = useState<UserRole>('customer');
  const [currentLocation, setCurrentLocation] = useState({
    city: 'Gurugram',
    locality: 'DLF Phase 5, Golf Course Rd',
    coordinates: { lat: 28.4595, lng: 77.0266 }
  });
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategoryType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [categories, setCategories] = useState<CategoryMeta[]>(CATEGORIES);
  const [services, setServices] = useState<ServiceItem[]>(ALL_SERVICES);
  const [providers, setProviders] = useState<Provider[]>(MOCK_PROVIDERS);
  const [deliveryPartners, setDeliveryPartners] = useState<DeliveryPartner[]>(MOCK_DELIVERY_PARTNERS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>(INITIAL_CHAT_SESSIONS);
  const [chatMessages, setChatMessages] = useState<Record<string, ChatMessage[]>>(INITIAL_CHAT_MESSAGES);
  const [adminConfig, setAdminConfig] = useState<AdminConfig>(INITIAL_ADMIN_CONFIG);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>(INITIAL_WITHDRAWALS);
  const [safetyIncidents, setSafetyIncidents] = useState<SafetyIncidentReport[]>(INITIAL_SAFETY_INCIDENTS);
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);

  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeOrderId, setActiveOrderId] = useState<string | null>('ord_101');
  const [activeChatSessionId, setActiveChatSessionId] = useState<string | null>('chat_1');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isSosOpen, setIsSosOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [deviceFrame, setDeviceFrame] = useState<'iphone' | 'android' | 'responsive'>('iphone');

  // Load backend bootstrap if running
  useEffect(() => {
    apiFetch<any>('/api/bootstrap')
      .then(data => {
        if (data) {
          if (data.categories) setCategories(data.categories);
          if (data.services) setServices(data.services);
          if (data.providers) setProviders(data.providers);
          if (data.deliveryPartners) setDeliveryPartners(data.deliveryPartners);
          if (data.users) setUsers(data.users);
          if (data.orders) setOrders(data.orders);
          if (data.chatSessions) setChatSessions(data.chatSessions);
          if (data.chatMessages) setChatMessages(data.chatMessages);
          if (data.adminConfig) setAdminConfig(data.adminConfig);
          if (data.withdrawals) setWithdrawals(data.withdrawals);
          if (data.safetyIncidents) setSafetyIncidents(data.safetyIncidents);
          if (data.notifications) setNotifications(data.notifications);
        }
      })
      .catch(err => {
        console.warn('Using client-side initial database:', err.message);
      });
  }, []);

  const switchRoleQuickly = (newRole: UserRole) => {
    setRole(newRole);
    const matchedUser = users.find(u => u.role === newRole) || users[0];
    setUser(matchedUser);
  };

  // Cart operations
  const addToCart = (service: ServiceItem, selectedOptions?: string[]) => {
    setCart(prev => {
      const existing = prev.find(i => i.service.id === service.id);
      if (existing) {
        return prev.map(i =>
          i.service.id === service.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { service, quantity: 1, selectedOptions }];
    });
  };

  const removeFromCart = (serviceId: string) => {
    setCart(prev => prev.filter(i => i.service.id !== serviceId));
  };

  const updateCartQuantity = (serviceId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(serviceId);
      return;
    }
    setCart(prev =>
      prev.map(i => (i.service.id === serviceId ? { ...i, quantity } : i))
    );
  };

  const clearCart = () => setCart([]);

  const cartTotal = cart.reduce((acc, item) => {
    const price = item.service.discountPrice || item.service.price;
    return acc + price * item.quantity;
  }, 0);

  const activeOrder = orders.find(o => o.id === activeOrderId) || null;
  const activeChatSession = chatSessions.find(s => s.id === activeChatSessionId) || null;

  // Place Order
  const placeOrder = async (orderPayload: Partial<Order>): Promise<Order> => {
    try {
      const res = await apiFetch<{ order: Order; chatSession: ChatSession }>('/api/orders', {
        method: 'POST',
        body: JSON.stringify(orderPayload)
      });
      setOrders(prev => [res.order, ...prev]);
      setChatSessions(prev => [res.chatSession, ...prev]);
      setActiveOrderId(res.order.id);
      clearCart();
      return res.order;
    } catch (e) {
      // Fallback local creation
      const newOrder: Order = {
        id: `ord_${Date.now()}`,
        orderNumber: `ALLJI-${Math.floor(10000 + Math.random() * 90000)}`,
        customerId: user.id,
        customerName: user.name,
        customerPhone: user.phone,
        category: orderPayload.category || 'food',
        items: orderPayload.items || [],
        deliveryAddress: orderPayload.deliveryAddress,
        scheduledSlot: orderPayload.scheduledSlot,
        rideDetails: orderPayload.rideDetails,
        courierDetails: orderPayload.courierDetails,
        itemTotal: orderPayload.itemTotal || 0,
        deliveryFee: orderPayload.deliveryFee || 0,
        platformFee: 5,
        taxes: orderPayload.taxes || 0,
        discount: orderPayload.discount || 0,
        grandTotal: orderPayload.grandTotal || 0,
        paymentMethod: orderPayload.paymentMethod || 'cash',
        paymentStatus: orderPayload.paymentMethod === 'cash' ? 'pending' : 'paid',
        status: orderPayload.category === 'ride' ? 'assigned' : 'accepted',
        eta: orderPayload.category === 'ride' ? '3 mins' : '25-35 mins',
        deliveryOtp: `${Math.floor(1000 + Math.random() * 9000)}`,
        createdAt: new Date().toISOString(),
        ...orderPayload
      } as Order;

      const newChatSession: ChatSession = {
        id: `chat_${Date.now()}`,
        orderId: newOrder.id,
        customerId: user.id,
        customerName: user.name,
        participantId: newOrder.deliveryPartnerId || 'deliv_1',
        participantName: newOrder.deliveryPartnerName || 'AllJi Partner',
        participantRole: 'delivery',
        freeMessagesAllowed: adminConfig.chatRules.freeMessageLimit,
        freeMessagesUsed: 0,
        isPaidUnlocked: false,
        paidUnlockPrice: adminConfig.chatRules.unlockFee,
        lastMessage: `Order ${newOrder.orderNumber} initiated.`,
        updatedAt: new Date().toISOString()
      };

      setOrders(prev => [newOrder, ...prev]);
      setChatSessions(prev => [newChatSession, ...prev]);
      setChatMessages(prev => ({
        ...prev,
        [newChatSession.id]: [
          {
            id: `msg_${Date.now()}`,
            sessionId: newChatSession.id,
            senderId: 'system',
            senderRole: 'admin',
            senderName: 'AllJi Super App',
            text: `Welcome! Order #${newOrder.orderNumber} placed. You have ${adminConfig.chatRules.freeMessageLimit} free chat messages.`,
            timestamp: new Date().toISOString(),
            isSystem: true
          }
        ]
      }));

      setActiveOrderId(newOrder.id);
      clearCart();
      return newOrder;
    }
  };

  // Order status
  const updateOrderStatus = async (orderId: string, status: Order['status']) => {
    try {
      await apiFetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
    } catch {
      // client update
    }
    setOrders(prev =>
      prev.map(o => (o.id === orderId ? { ...o, status } : o))
    );
  };

  // Cancel order
  const cancelOrder = async (orderId: string, reason: string) => {
    try {
      const res = await apiFetch<{ order: Order; refundAmount: number }>(`/api/orders/${orderId}/cancel`, {
        method: 'POST',
        body: JSON.stringify({ reason })
      });
      setOrders(prev => prev.map(o => (o.id === orderId ? res.order : o)));
      if (res.refundAmount > 0) {
        setUser(u => ({ ...u, walletBalance: u.walletBalance + res.refundAmount }));
      }
    } catch {
      setOrders(prev =>
        prev.map(o => {
          if (o.id === orderId) {
            const refund = o.paymentStatus === 'paid' ? o.grandTotal : 0;
            if (refund > 0) {
              setUser(u => ({ ...u, walletBalance: u.walletBalance + refund }));
            }
            return {
              ...o,
              status: 'cancelled',
              cancelReason: reason,
              refundAmount: refund
            };
          }
          return o;
        })
      );
    }
  };

  // Rate order
  const rateOrder = async (orderId: string, rating: number, comment?: string) => {
    try {
      await apiFetch(`/api/orders/${orderId}/rate`, {
        method: 'POST',
        body: JSON.stringify({ rating, reviewComment: comment })
      });
    } catch {}
    setOrders(prev =>
      prev.map(o => (o.id === orderId ? { ...o, rating, reviewComment: comment } : o))
    );
  };

  // Send chat message with free messages check
  const sendChatMessage = async (
    sessionId: string,
    text: string
  ): Promise<{ success: boolean; error?: string; limitExceeded?: boolean }> => {
    const session = chatSessions.find(s => s.id === sessionId);
    if (!session) return { success: false, error: 'Session not found' };

    // Free message limit check for customer
    if (role === 'customer' && !session.isPaidUnlocked) {
      const limit = session.freeMessagesAllowed || adminConfig.chatRules.freeMessageLimit;
      if (session.freeMessagesUsed >= limit) {
        return {
          success: false,
          limitExceeded: true,
          error: `You've used all ${limit} free messages for this order. Unlock unlimited paid chat for ₹${session.paidUnlockPrice}.`
        };
      }
    }

    try {
      const res = await apiFetch<{ message: ChatMessage; session: ChatSession }>('/api/chat/message', {
        method: 'POST',
        body: JSON.stringify({
          sessionId,
          senderId: user.id,
          senderRole: role,
          senderName: user.name,
          text
        })
      });
      setChatSessions(prev =>
        prev.map(s => (s.id === sessionId ? res.session : s))
      );
      setChatMessages(prev => ({
        ...prev,
        [sessionId]: [...(prev[sessionId] || []), res.message]
      }));
      return { success: true };
    } catch (err: any) {
      if (err.message && err.message.includes('limit')) {
        return { success: false, limitExceeded: true, error: err.message };
      }
      // Local fallback
      const newMsg: ChatMessage = {
        id: `msg_${Date.now()}`,
        sessionId,
        senderId: user.id,
        senderRole: role,
        senderName: user.name,
        text,
        timestamp: new Date().toISOString()
      };
      setChatMessages(prev => ({
        ...prev,
        [sessionId]: [...(prev[sessionId] || []), newMsg]
      }));
      setChatSessions(prev =>
        prev.map(s => {
          if (s.id === sessionId) {
            return {
              ...s,
              freeMessagesUsed: role === 'customer' ? s.freeMessagesUsed + 1 : s.freeMessagesUsed,
              lastMessage: text,
              updatedAt: new Date().toISOString()
            };
          }
          return s;
        })
      );
      return { success: true };
    }
  };

  // Unlock paid chat
  const unlockPaidChat = async (sessionId: string) => {
    try {
      const res = await apiFetch<{ session: ChatSession; message: ChatMessage }>('/api/chat/unlock', {
        method: 'POST',
        body: JSON.stringify({ sessionId, customerId: user.id })
      });
      setChatSessions(prev =>
        prev.map(s => (s.id === sessionId ? res.session : s))
      );
      setChatMessages(prev => ({
        ...prev,
        [sessionId]: [...(prev[sessionId] || []), res.message]
      }));
    } catch {
      // Local unlock
      const fee = adminConfig.chatRules.unlockFee;
      if (user.walletBalance >= fee) {
        setUser(u => ({ ...u, walletBalance: u.walletBalance - fee }));
      }
      setChatSessions(prev =>
        prev.map(s => (s.id === sessionId ? { ...s, isPaidUnlocked: true } : s))
      );
      const unlockMsg: ChatMessage = {
        id: `msg_unlock_${Date.now()}`,
        sessionId,
        senderId: 'system',
        senderRole: 'admin',
        senderName: 'AllJi Security',
        text: `🎉 Paid Chat Unlocked for ₹${fee}. Direct unlimited messaging enabled.`,
        timestamp: new Date().toISOString(),
        isSystem: true
      };
      setChatMessages(prev => ({
        ...prev,
        [sessionId]: [...(prev[sessionId] || []), unlockMsg]
      }));
    }
  };

  // Provider add custom service
  const addCustomService = async (providerId: string, serviceData: Partial<ServiceItem>) => {
    try {
      const res = await apiFetch<{ service: ServiceItem }>('/api/providers/services', {
        method: 'POST',
        body: JSON.stringify({ providerId, serviceData })
      });
      setServices(prev => [...prev, res.service]);
      setProviders(prev =>
        prev.map(p =>
          p.id === providerId
            ? { ...p, customServices: [...p.customServices, res.service] }
            : p
        )
      );
    } catch {
      const newService: ServiceItem = {
        id: `custom_${Date.now()}`,
        categoryId: serviceData.categoryId || 'custom',
        providerId,
        title: serviceData.title || 'Custom Service',
        description: serviceData.description || '',
        price: serviceData.price || 499,
        durationMinutes: serviceData.durationMinutes || 45,
        imageUrl: serviceData.imageUrl || 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400&auto=format&fit=crop&q=80',
        rating: 5.0,
        unit: serviceData.unit || 'service'
      };
      setServices(prev => [...prev, newService]);
      setProviders(prev =>
        prev.map(p =>
          p.id === providerId
            ? { ...p, customServices: [...p.customServices, newService] }
            : p
        )
      );
    }
  };

  // Update provider status or radius
  const updateProvider = async (providerId: string, updates: Partial<Provider>) => {
    try {
      const res = await apiFetch<{ provider: Provider }>(`/api/providers/${providerId}`, {
        method: 'PATCH',
        body: JSON.stringify(updates)
      });
      setProviders(prev => prev.map(p => (p.id === providerId ? res.provider : p)));
    } catch {
      setProviders(prev =>
        prev.map(p => (p.id === providerId ? { ...p, ...updates } : p))
      );
    }
  };

  // Request withdrawal
  const requestWithdrawal = async (
    providerId: string,
    amount: number,
    bankAccount: string,
    ifscOrUpi: string
  ) => {
    const prov = providers.find(p => p.id === providerId);
    try {
      const res = await apiFetch<{ withdrawal: WithdrawalRequest }>('/api/withdrawals', {
        method: 'POST',
        body: JSON.stringify({
          providerId,
          providerName: prov?.businessName || 'Provider',
          amount,
          bankAccount,
          ifscOrUpi
        })
      });
      setWithdrawals(prev => [res.withdrawal, ...prev]);
      setProviders(prev =>
        prev.map(p =>
          p.id === providerId
            ? {
                ...p,
                earnings: {
                  ...p.earnings,
                  pendingPayout: p.earnings.pendingPayout - amount
                }
              }
            : p
        )
      );
    } catch {
      const newW: WithdrawalRequest = {
        id: `w_${Date.now()}`,
        providerId,
        providerName: prov?.businessName || 'Provider',
        amount,
        bankAccount,
        ifscOrUpi,
        status: 'pending',
        requestedAt: new Date().toISOString()
      };
      setWithdrawals(prev => [newW, ...prev]);
      setProviders(prev =>
        prev.map(p =>
          p.id === providerId
            ? {
                ...p,
                earnings: {
                  ...p.earnings,
                  pendingPayout: p.earnings.pendingPayout - amount
                }
              }
            : p
        )
      );
    }
  };

  // Process withdrawal by Admin
  const processWithdrawal = async (withdrawalId: string, status: 'approved' | 'rejected') => {
    try {
      const res = await apiFetch<{ withdrawal: WithdrawalRequest }>(`/api/withdrawals/${withdrawalId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
      setWithdrawals(prev => prev.map(w => (w.id === withdrawalId ? res.withdrawal : w)));
    } catch {
      setWithdrawals(prev =>
        prev.map(w =>
          w.id === withdrawalId ? { ...w, status, processedAt: new Date().toISOString() } : w
        )
      );
    }
  };

  // Update admin config
  const updateAdminConfig = async (updates: Partial<AdminConfig>) => {
    try {
      const res = await apiFetch<{ adminConfig: AdminConfig }>('/api/admin/config', {
        method: 'POST',
        body: JSON.stringify(updates)
      });
      setAdminConfig(res.adminConfig);
    } catch {
      setAdminConfig(prev => ({ ...prev, ...updates }));
    }
  };

  // Emergency SOS Trigger
  const triggerEmergencySos = async (locationNote?: string) => {
    const payload = {
      userId: user.id,
      userName: user.name,
      userPhone: user.phone,
      location: locationNote || `${currentLocation.locality}, ${currentLocation.city}`,
      coordinates: currentLocation.coordinates,
      orderId: activeOrderId || undefined
    };

    try {
      const res = await apiFetch<{ incident: SafetyIncidentReport }>('/api/safety/sos', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      setSafetyIncidents(prev => [res.incident, ...prev]);
    } catch {
      const incident: SafetyIncidentReport = {
        id: `sos_${Date.now()}`,
        userId: user.id,
        userName: user.name,
        userPhone: user.phone,
        location: payload.location,
        coordinates: payload.coordinates,
        orderId: payload.orderId,
        emergencyType: 'sos',
        status: 'active',
        timestamp: new Date().toISOString(),
        notes: 'EMERGENCY SOS TRIGGERED: Police 112 alerted, emergency contacts pinged with live GPS.'
      };
      setSafetyIncidents(prev => [incident, ...prev]);
    }

    setNotifications(prev => [
      {
        id: `notif_${Date.now()}`,
        userId: user.id,
        title: '🚨 Emergency SOS Dispatched',
        message: 'Security assistance & live GPS location broadcasted to police helpline and emergency contacts.',
        type: 'safety',
        read: false,
        timestamp: 'Just now'
      },
      ...prev
    ]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, read: true } : n))
    );
  };

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        role,
        setRole,
        switchRoleQuickly,
        currentLocation,
        setCurrentLocation,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        categories,
        services,
        providers,
        deliveryPartners,
        orders,
        chatSessions,
        chatMessages,
        adminConfig,
        withdrawals,
        safetyIncidents,
        notifications,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartTotal,
        activeOrder,
        setActiveOrderId,
        activeChatSession,
        setActiveChatSessionId,
        isChatOpen,
        setIsChatOpen,
        isSosOpen,
        setIsSosOpen,
        isAuthOpen,
        setIsAuthOpen,
        deviceFrame,
        setDeviceFrame,
        placeOrder,
        updateOrderStatus,
        cancelOrder,
        rateOrder,
        sendChatMessage,
        unlockPaidChat,
        addCustomService,
        updateProvider,
        requestWithdrawal,
        processWithdrawal,
        updateAdminConfig,
        triggerEmergencySos,
        markNotificationAsRead
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
