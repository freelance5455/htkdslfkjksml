import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserRole,
  Language,
  UserProfile,
  Product,
  Order,
  CartItem,
  WholesalerInventoryItem,
  DriverTrip,
  PlatformCommissionConfig,
  SettlementRecord,
  ComplaintRecord,
  AppNotification
} from '../types';
import {
  initialCurrentUser,
  initialProducts,
  initialOrders,
  initialWholesaleInventory,
  initialDriverTrips,
  initialCommissionConfig,
  initialSettlements,
  initialComplaints,
  initialNotifications
} from '../data/mockData';
import { translations } from '../localization/translations';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations.en) => string;
  
  // Role & navigation
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  currentUser: UserProfile;
  updateCurrentUser: (updates: Partial<UserProfile>) => void;
  
  // Onboarding screens
  isOnboarding: boolean;
  onboardingStep: number; // 1: Splash, 2: Language, 3: Login, 4: OTP, 5: Profile, 6: Role Selection
  setOnboardingStep: (step: number) => void;
  startOnboarding: () => void;
  completeOnboarding: (selectedRole?: UserRole) => void;

  // Active navigation tab per app
  customerTab: 'home' | 'products' | 'orders' | 'wallet' | 'profile';
  setCustomerTab: (tab: 'home' | 'products' | 'orders' | 'wallet' | 'profile') => void;
  selectedProductId: string | null;
  setSelectedProductId: (id: string | null) => void;
  trackingOrderId: string | null;
  setTrackingOrderId: (id: string | null) => void;
  selectedOrderForDetails: string | null;
  setSelectedOrderForDetails: (id: string | null) => void;
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantityThousand: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantityThousand: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotalAmount: number;

  // Products & Inventory
  products: Product[];
  addProduct: (product: Omit<Product, 'id' | 'rating' | 'reviewCount' | 'isApproved' | 'isActive'>) => void;
  updateProductStock: (productId: string, newStockThousand: number, newPrice?: number) => void;
  toggleProductApproval: (productId: string) => void;

  // Orders
  orders: Order[];
  createOrder: (orderData: Partial<Order>) => string;
  updateOrderStatus: (orderId: string, status: Order['orderStatus']) => void;
  advanceOrderStage: (orderId: string) => void;

  // Wholesaler
  wholesaleInventory: WholesalerInventoryItem[];
  updateWholesaleStock: (id: string, currentStock: number) => void;
  addWholesalePurchase: (productId: string, quantityThousand: number, pricePerThousand: number) => void;

  // Driver
  driverTrips: DriverTrip[];
  acceptDriverTrip: (tripId: string) => void;
  rejectDriverTrip: (tripId: string) => void;
  confirmLoading: (tripId: string, vehicleNo: string, photoUrl?: string) => void;
  startTripNavigation: (tripId: string) => void;
  completeDriverDelivery: (tripId: string, otp: string, signature: string, photoUrl?: string) => { success: boolean; message: string };

  // Admin & Settings
  commissionConfig: PlatformCommissionConfig;
  updateCommissionConfig: (config: Partial<PlatformCommissionConfig>) => void;
  settlements: SettlementRecord[];
  updateSettlementStatus: (id: string, status: SettlementRecord['status']) => void;
  complaints: ComplaintRecord[];
  raiseComplaint: (orderId: string, category: ComplaintRecord['category'], description: string) => void;
  updateComplaintStatus: (id: string, status: ComplaintRecord['status'], resolutionNotes?: string) => void;
  
  // Wallet
  walletBalance: number;
  addMoneyToWallet: (amount: number, description: string) => void;

  // Notifications
  notifications: AppNotification[];
  markNotificationAsRead: (id: string) => void;
  sendBroadcastNotification: (title: string, message: string, recipientRole: UserRole | 'all', type: AppNotification['type']) => void;

  // Modal helpers
  invoiceModalOrderId: string | null;
  setInvoiceModalOrderId: (id: string | null) => void;
  complaintModalOrderId: string | null;
  setComplaintModalOrderId: (id: string | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');
  const [currentRole, setCurrentRole] = useState<UserRole>('customer');
  const [currentUser, setCurrentUser] = useState<UserProfile>(initialCurrentUser);
  
  // Onboarding
  const [isOnboarding, setIsOnboarding] = useState<boolean>(false);
  const [onboardingStep, setOnboardingStep] = useState<number>(1);

  // Tabs & Views
  const [customerTab, setCustomerTab] = useState<'home' | 'products' | 'orders' | 'wallet' | 'profile'>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [trackingOrderId, setTrackingOrderId] = useState<string | null>('BRK-ORD-88219');
  const [selectedOrderForDetails, setSelectedOrderForDetails] = useState<string | null>(null);

  // Modals
  const [invoiceModalOrderId, setInvoiceModalOrderId] = useState<string | null>(null);
  const [complaintModalOrderId, setComplaintModalOrderId] = useState<string | null>(null);

  // Cart
  const [cart, setCart] = useState<CartItem[]>([
    {
      product: initialProducts[0],
      quantityThousand: 4
    }
  ]);

  // Data states
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [wholesaleInventory, setWholesaleInventory] = useState<WholesalerInventoryItem[]>(initialWholesaleInventory);
  const [driverTrips, setDriverTrips] = useState<DriverTrip[]>(initialDriverTrips);
  const [commissionConfig, setCommissionConfig] = useState<PlatformCommissionConfig>(initialCommissionConfig);
  const [settlements, setSettlements] = useState<SettlementRecord[]>(initialSettlements);
  const [complaints, setComplaints] = useState<ComplaintRecord[]>(initialComplaints);
  const [notifications, setNotifications] = useState<AppNotification[]>(initialNotifications);
  const [walletBalance, setWalletBalance] = useState<number>(14850);

  // Translation helper
  const t = (key: keyof typeof translations.en): string => {
    const langDict = translations[language] || translations.en;
    return (langDict as Record<string, string>)[key] || translations.en[key] || key;
  };

  const updateCurrentUser = (updates: Partial<UserProfile>) => {
    setCurrentUser((prev) => ({ ...prev, ...updates }));
  };

  const startOnboarding = () => {
    setOnboardingStep(1);
    setIsOnboarding(true);
  };

  const completeOnboarding = (selectedRole?: UserRole) => {
    if (selectedRole) {
      setCurrentRole(selectedRole);
      updateCurrentUser({ role: selectedRole });
    }
    setIsOnboarding(false);
  };

  // Cart operations
  const addToCart = (product: Product, quantityThousand: number) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantityThousand: item.quantityThousand + quantityThousand }
            : item
        );
      }
      return [...prev, { product, quantityThousand }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantityThousand: number) => {
    if (quantityThousand <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantityThousand } : item))
    );
  };

  const clearCart = () => setCart([]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantityThousand, 0);
  const cartTotalAmount = cart.reduce((sum, item) => sum + item.quantityThousand * item.product.pricePerThousand, 0);

  // Products
  const addProduct = (productData: Omit<Product, 'id' | 'rating' | 'reviewCount' | 'isApproved' | 'isActive'>) => {
    const newProduct: Product = {
      ...productData,
      id: `prod_${Date.now()}`,
      rating: 5.0,
      reviewCount: 1,
      isApproved: true,
      isActive: true
    };
    setProducts((prev) => [newProduct, ...prev]);
  };

  const updateProductStock = (productId: string, newStockThousand: number, newPrice?: number) => {
    setProducts((prev) =>
      prev.map((prod) =>
        prod.id === productId
          ? {
              ...prod,
              availableStockThousand: Math.max(0, newStockThousand),
              ...(newPrice ? { pricePerThousand: newPrice } : {})
            }
          : prod
      )
    );
  };

  const toggleProductApproval = (productId: string) => {
    setProducts((prev) =>
      prev.map((prod) => (prod.id === productId ? { ...prod, isApproved: !prod.isApproved } : prod))
    );
  };

  // Orders
  const createOrder = (orderData: Partial<Order>): string => {
    const orderId = `BRK-ORD-${Math.floor(10000 + Math.random() * 90000)}`;
    const newOrder: Order = {
      id: orderId,
      customerId: currentUser.id,
      customerName: currentUser.name,
      customerMobile: currentUser.mobile,
      deliveryAddress: orderData.deliveryAddress || currentUser.address,
      deliveryPinCode: orderData.deliveryPinCode || currentUser.pinCode,
      deliveryDate: orderData.deliveryDate || new Date().toISOString().split('T')[0],
      items: orderData.items || [],
      productTotal: orderData.productTotal || 0,
      transportCharge: orderData.transportCharge || 3500,
      discount: orderData.discount || 0,
      gstAmount: orderData.gstAmount || 0,
      totalAmount: orderData.totalAmount || 0,
      paymentMethod: orderData.paymentMethod || 'UPI',
      paymentStatus: 'Paid',
      orderStatus: 'Order Confirmed',
      manufacturerId: orderData.manufacturerId || 'mfg_01',
      manufacturerName: orderData.manufacturerName || 'Maa Tara Brick Kiln (BFB Bhatta)',
      vehicleType: orderData.vehicleType || '10-Wheeler Heavy Truck',
      deliveryOtp: `${Math.floor(100000 + Math.random() * 900000)}`,
      createdAt: new Date().toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }),
      ...orderData
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Add to settlements (pending)
    const newSettlementMfg: SettlementRecord = {
      id: `SETTL-${Math.floor(1000 + Math.random() * 9000)}`,
      orderId: newOrder.id,
      beneficiaryType: 'Manufacturer',
      beneficiaryName: newOrder.manufacturerName,
      grossAmount: newOrder.productTotal,
      platformCommission: Math.round((newOrder.productTotal * commissionConfig.manufacturerCommissionPercent) / 100),
      transportFee: newOrder.transportCharge,
      netPayable: Math.round(newOrder.productTotal * (1 - commissionConfig.manufacturerCommissionPercent / 100)),
      status: 'Pending',
      date: new Date().toISOString().split('T')[0]
    };

    setSettlements((prev) => [newSettlementMfg, ...prev]);

    // Send in-app notification
    sendBroadcastNotification(
      `New Order Placed: ${orderId}`,
      `Order of ₹${newOrder.totalAmount.toLocaleString()} received. Kiln has been notified for preparation.`,
      'customer',
      'order'
    );

    return orderId;
  };

  const updateOrderStatus = (orderId: string, status: Order['orderStatus']) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, orderStatus: status } : ord))
    );
  };

  const advanceOrderStage = (orderId: string) => {
    const stages: Order['orderStatus'][] = [
      'Order Confirmed',
      'Manufacturer Preparing',
      'Vehicle Assigned',
      'Loading',
      'Out for Delivery',
      'Delivered'
    ];

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          const currentIndex = stages.indexOf(ord.orderStatus);
          if (currentIndex >= 0 && currentIndex < stages.length - 1) {
            const nextStatus = stages[currentIndex + 1];
            return { ...ord, orderStatus: nextStatus };
          }
        }
        return ord;
      })
    );
  };

  // Wholesale actions
  const updateWholesaleStock = (id: string, currentStock: number) => {
    setWholesaleInventory((prev) =>
      prev.map((item) => (item.id === id ? { ...item, currentStockThousand: currentStock } : item))
    );
  };

  const addWholesalePurchase = (productId: string, quantityThousand: number, pricePerThousand: number) => {
    setWholesaleInventory((prev) =>
      prev.map((item) => {
        if (item.productId === productId) {
          return {
            ...item,
            purchasedThousand: item.purchasedThousand + quantityThousand,
            currentStockThousand: item.currentStockThousand + quantityThousand,
            purchasePricePerThousand: pricePerThousand
          };
        }
        return item;
      })
    );
  };

  // Driver actions
  const acceptDriverTrip = (tripId: string) => {
    setDriverTrips((prev) =>
      prev.map((trip) => (trip.id === tripId ? { ...trip, status: 'accepted' } : trip))
    );
  };

  const rejectDriverTrip = (tripId: string) => {
    setDriverTrips((prev) =>
      prev.map((trip) => (trip.id === tripId ? { ...trip, status: 'rejected' } : trip))
    );
  };

  const confirmLoading = (tripId: string, vehicleNo: string, photoUrl?: string) => {
    setDriverTrips((prev) =>
      prev.map((trip) =>
        trip.id === tripId ? { ...trip, status: 'loading', vehicleNumber: vehicleNo } : trip
      )
    );
  };

  const startTripNavigation = (tripId: string) => {
    setDriverTrips((prev) =>
      prev.map((trip) => (trip.id === tripId ? { ...trip, status: 'in_transit' } : trip))
    );
  };

  const completeDriverDelivery = (
    tripId: string,
    otp: string,
    signature: string,
    photoUrl?: string
  ): { success: boolean; message: string } => {
    const trip = driverTrips.find((t) => t.id === tripId);
    if (!trip) return { success: false, message: 'Trip not found' };

    const order = orders.find((o) => o.id === trip.orderId);
    if (order && order.deliveryOtp !== otp.trim()) {
      return { success: false, message: `Invalid Delivery OTP. Expected customer's 6-digit OTP.` };
    }

    setDriverTrips((prev) =>
      prev.map((t) => (t.id === tripId ? { ...t, status: 'delivered' } : t))
    );

    if (order) {
      setOrders((prev) =>
        prev.map((o) =>
          o.id === order.id
            ? {
                ...o,
                orderStatus: 'Delivered',
                customerSignature: signature,
                deliveryPhoto: photoUrl
              }
            : o
        )
      );

      // Create transporter settlement
      const transporterSettlement: SettlementRecord = {
        id: `SETTL-${Math.floor(1000 + Math.random() * 9000)}`,
        orderId: order.id,
        beneficiaryType: 'Transporter',
        beneficiaryName: trip.vehicleNumber || 'Driver Partner',
        grossAmount: trip.transportCharge,
        platformCommission: Math.round((trip.transportCharge * commissionConfig.transportCommissionPercent) / 100),
        transportFee: 0,
        netPayable: Math.round(trip.transportCharge * (1 - commissionConfig.transportCommissionPercent / 100)),
        status: 'Paid',
        paymentRef: `IMPS/${Date.now().toString().slice(-8)}`,
        date: new Date().toISOString().split('T')[0]
      };
      setSettlements((prev) => [transporterSettlement, ...prev]);
    }

    return { success: true, message: 'Delivery completed successfully and recorded.' };
  };

  // Commission & Admin
  const updateCommissionConfig = (config: Partial<PlatformCommissionConfig>) => {
    setCommissionConfig((prev) => ({ ...prev, ...config }));
  };

  const updateSettlementStatus = (id: string, status: SettlementRecord['status']) => {
    setSettlements((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status, paymentRef: status === 'Paid' ? `TXN${Date.now().toString().slice(-6)}` : s.paymentRef } : s))
    );
  };

  const raiseComplaint = (
    orderId: string,
    category: ComplaintRecord['category'],
    description: string
  ) => {
    const newComplaint: ComplaintRecord = {
      id: `CMP-${Math.floor(500 + Math.random() * 500)}`,
      orderId,
      raisedByName: currentUser.name,
      raisedByRole: currentRole,
      category,
      description,
      status: 'Open',
      createdAt: new Date().toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })
    };
    setComplaints((prev) => [newComplaint, ...prev]);
  };

  const updateComplaintStatus = (
    id: string,
    status: ComplaintRecord['status'],
    resolutionNotes?: string
  ) => {
    setComplaints((prev) =>
      prev.map((c) =>
        c.id === id ? { ...c, status, ...(resolutionNotes ? { resolutionNotes } : {}) } : c
      )
    );
  };

  const addMoneyToWallet = (amount: number, description: string) => {
    setWalletBalance((prev) => prev + amount);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const sendBroadcastNotification = (
    title: string,
    message: string,
    recipientRole: UserRole | 'all',
    type: AppNotification['type']
  ) => {
    const newNotif: AppNotification = {
      id: `notif_${Date.now()}`,
      recipientRole,
      title,
      message,
      type,
      timestamp: 'Just now',
      read: false
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        currentRole,
        setCurrentRole,
        currentUser,
        updateCurrentUser,
        isOnboarding,
        onboardingStep,
        setOnboardingStep,
        startOnboarding,
        completeOnboarding,
        customerTab,
        setCustomerTab,
        selectedProductId,
        setSelectedProductId,
        trackingOrderId,
        setTrackingOrderId,
        selectedOrderForDetails,
        setSelectedOrderForDetails,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartCount,
        cartTotalAmount,
        products,
        addProduct,
        updateProductStock,
        toggleProductApproval,
        orders,
        createOrder,
        updateOrderStatus,
        advanceOrderStage,
        wholesaleInventory,
        updateWholesaleStock,
        addWholesalePurchase,
        driverTrips,
        acceptDriverTrip,
        rejectDriverTrip,
        confirmLoading,
        startTripNavigation,
        completeDriverDelivery,
        commissionConfig,
        updateCommissionConfig,
        settlements,
        updateSettlementStatus,
        complaints,
        raiseComplaint,
        updateComplaintStatus,
        walletBalance,
        addMoneyToWallet,
        notifications,
        markNotificationAsRead,
        sendBroadcastNotification,
        invoiceModalOrderId,
        setInvoiceModalOrderId,
        complaintModalOrderId,
        setComplaintModalOrderId
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
