import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppSettings, LearningMode } from '../types';
import {
  getLocalSettings,
  updateLocalSettings,
  getLocalFavorites,
  toggleLocalFavorite,
  resetAllAppData
} from '../services/storage';
import { playSound as playSoundUtil, triggerHaptic as triggerHapticUtil } from '../utils/sound';
import { TRANSLATIONS, Translations } from '../i18n/translations';

interface Toast {
  id: string;
  message: string;
  type?: 'success' | 'info' | 'error';
}

interface AppContextType {
  settings: AppSettings;
  updateSettings: (partial: Partial<AppSettings>) => void;
  favorites: string[];
  toggleFavorite: (formulaId: string) => boolean;
  isFavorite: (formulaId: string) => boolean;
  playSound: (type: 'button' | 'tab' | 'calculate' | 'favorite' | 'copy' | 'correct' | 'incorrect') => void;
  triggerHaptic: (type?: 'light' | 'medium' | 'success' | 'error') => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
  toasts: Toast[];
  t: Translations;
  resetAppData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettingsState] = useState<AppSettings>(getLocalSettings);
  const [favorites, setFavorites] = useState<string[]>(getLocalFavorites);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Apply theme class
  useEffect(() => {
    const root = document.documentElement;
    if (
      settings.theme === 'dark' ||
      (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)
    ) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings.theme]);

  const updateSettings = (partial: Partial<AppSettings>) => {
    const updated = updateLocalSettings(partial);
    setSettingsState(updated);
  };

  const toggleFavorite = (formulaId: string) => {
    const isNowFav = toggleLocalFavorite(formulaId);
    setFavorites(getLocalFavorites());
    playSoundUtil('favorite', settings.soundEnabled);
    triggerHapticUtil('medium', settings.hapticEnabled);
    return isNowFav;
  };

  const isFavorite = (formulaId: string) => {
    return favorites.includes(formulaId);
  };

  const playSound = (type: 'button' | 'tab' | 'calculate' | 'favorite' | 'copy' | 'correct' | 'incorrect') => {
    playSoundUtil(type, settings.soundEnabled);
  };

  const triggerHaptic = (type: 'light' | 'medium' | 'success' | 'error' = 'light') => {
    triggerHapticUtil(type, settings.hapticEnabled);
  };

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = `${Date.now()}_${Math.random()}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 2800);
  };

  const resetAppData = () => {
    resetAllAppData();
    setSettingsState(getLocalSettings());
    setFavorites([]);
    showToast('All local data and preferences reset to defaults');
  };

  const t = TRANSLATIONS[settings.language] || TRANSLATIONS.en;

  return (
    <AppContext.Provider
      value={{
        settings,
        updateSettings,
        favorites,
        toggleFavorite,
        isFavorite,
        playSound,
        triggerHaptic,
        showToast,
        toasts,
        t,
        resetAppData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
