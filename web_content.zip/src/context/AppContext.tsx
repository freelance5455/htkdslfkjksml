import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Language, 
  Store, 
  Product, 
  Order, 
  Customer, 
  CartItem, 
  StoreTheme,
  OrderStatus,
  PaymentStatus,
  MerchantUser,
  PaymentGatewayConfig,
  SubscriptionPayment,
  PaymentGatewayProvider,
  DraftOrder,
  AbandonedCheckout,
  ReturnRefundRecord,
  ShippingSettings,
  Collection
} from '../types';
import { 
  initialStores, 
  initialProducts, 
  initialOrders, 
  initialCustomers, 
  initialMerchantUsers, 
  initialPaymentGateways, 
  initialSubscriptionPayments 
} from '../data/initialData';
import { useAuth } from './AuthContext';
import { 
  fetchStoresFromDB, 
  saveStoreToDB, 
  fetchProductsFromDB, 
  saveProductToDB, 
  deleteProductFromDB, 
  fetchOrdersFromDB, 
  saveOrderToDB, 
  updateOrderStatusInDB, 
  fetchCustomersFromDB, 
  saveCustomerToDB, 
  fetchMerchantUsersFromDB, 
  saveMerchantUserToDB, 
  deleteMerchantUserFromDB, 
  fetchGatewaysFromDB, 
  saveGatewayToDB, 
  fetchSubscriptionPaymentsFromDB, 
  saveSubscriptionPaymentToDB,
  fetchDraftOrdersFromDB,
  saveDraftOrderToDB,
  deleteDraftOrderFromDB,
  fetchAbandonedCheckoutsFromDB,
  saveAbandonedCheckoutToDB,
  updateAbandonedCheckoutStatusInDB,
  fetchReturnsRefundsFromDB,
  saveReturnRefundToDB,
  updateReturnRefundStatusInDB,
  fetchShippingSettingsFromDB,
  saveShippingSettingsToDB,
  fetchCollectionsFromDB,
  saveCollectionToDB,
  deleteCollectionFromDB
} from '../utils/firestoreService';
import { saveSafeLocalStorage, saveToIndexedDB, loadFromIndexedDB } from '../utils/storage';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  stores: Store[];
  setStores: React.Dispatch<React.SetStateAction<Store[]>>;
  activeStoreId: string;
  setActiveStoreId: (id: string) => void;
  activeStore: Store;
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  orders: Order[];
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
  customers: Customer[];
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
  merchantUsers: MerchantUser[];
  setMerchantUsers: React.Dispatch<React.SetStateAction<MerchantUser[]>>;
  paymentGateways: PaymentGatewayConfig[];
  setPaymentGateways: React.Dispatch<React.SetStateAction<PaymentGatewayConfig[]>>;
  subscriptionPayments: SubscriptionPayment[];
  setSubscriptionPayments: React.Dispatch<React.SetStateAction<SubscriptionPayment[]>>;
  draftOrders: DraftOrder[];
  setDraftOrders: React.Dispatch<React.SetStateAction<DraftOrder[]>>;
  abandonedCheckouts: AbandonedCheckout[];
  setAbandonedCheckouts: React.Dispatch<React.SetStateAction<AbandonedCheckout[]>>;
  returnsRefunds: ReturnRefundRecord[];
  setReturnsRefunds: React.Dispatch<React.SetStateAction<ReturnRefundRecord[]>>;
  shippingSettings: ShippingSettings | null;
  setShippingSettings: React.Dispatch<React.SetStateAction<ShippingSettings | null>>;
  collections: Collection[];
  setCollections: React.Dispatch<React.SetStateAction<Collection[]>>;
  cart: CartItem[];
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCreateStoreWizardOpen: boolean;
  setIsCreateStoreWizardOpen: (open: boolean) => void;
  isExportModalOpen: boolean;
  setIsExportModalOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authModalMode: 'login' | 'register';
  setAuthModalMode: (mode: 'login' | 'register') => void;
  totalCartCount: number;
  handleCreateStore: (name: string, category: string) => void;
  handleWizardStoreCreated: (newStore: Store, starterProducts: Product[]) => void;
  handleAddProduct: (newProdData: Omit<Product, 'id'>) => void;
  handleUpdateProduct: (updatedProd: Product) => void;
  handleDeleteProduct: (productId: string) => void;
  handleUpdateOrderStatus: (orderId: string, status: OrderStatus, trackingId?: string, courier?: string) => void;
  handleUpdatePaymentStatus: (orderId: string, status: PaymentStatus) => void;
  handleUpdateOrderNotes: (orderId: string, notes: string) => void;
  handleBulkUpdateOrderStatus: (orderIds: string[], status: OrderStatus) => void;
  handleSaveDraftOrder: (draft: DraftOrder) => void;
  handleDeleteDraftOrder: (draftId: string) => void;
  handleConvertDraftToOrder: (draft: DraftOrder) => void;
  handleSaveAbandonedCheckout: (session: AbandonedCheckout) => void;
  handleUpdateAbandonedCheckoutStatus: (id: string, status: 'incomplete' | 'recovered' | 'blocked') => void;
  handleSaveReturnRefund: (record: ReturnRefundRecord) => void;
  handleUpdateReturnRefundStatus: (id: string, status: 'pending' | 'approved' | 'processed' | 'rejected') => void;
  handleSaveShippingSettings: (settings: ShippingSettings) => void;
  handleAddCollection: (newColData: Omit<Collection, 'id'>) => Promise<void>;
  handleUpdateCollection: (updatedCol: Collection) => Promise<void>;
  handleDeleteCollection: (collectionId: string) => Promise<void>;
  handleUpdateStoreTheme: (storeId: string, updatedTheme: Partial<StoreTheme>, storeName?: string) => void;
  handleUpdateStorePlan: (storeId: string, newPlan: 'starter' | 'growth' | 'enterprise') => void;
  handleAddSubscriptionPayment: (payment: SubscriptionPayment) => void;
  handleAddUser: (newUser: Omit<MerchantUser, 'id'>) => void;
  handleUpdateUser: (updatedUser: MerchantUser) => void;
  handleDeleteUser: (userId: string) => void;
  handleUpdateGateway: (updatedGateway: PaymentGatewayConfig) => void;
  handleToggleGateway: (gatewayId: PaymentGatewayProvider) => void;
  handleAddToCart: (product: Product) => void;
  handleUpdateCartQuantity: (productId: string, quantity: number) => void;
  handleClearCart: () => void;
  handleCreateOrder: (newOrder: Order) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  // Navigation & Localization
  const [language, setLanguage] = useState<Language>('bn');
  const [isCreateStoreWizardOpen, setIsCreateStoreWizardOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');

  // Multi-tenant Stores state
  const [stores, setStores] = useState<Store[]>(() => {
    try {
      const saved = localStorage.getItem('shopforge_stores');
      return saved ? JSON.parse(saved) : initialStores;
    } catch {
      return initialStores;
    }
  });

  const [activeStoreId, setActiveStoreId] = useState<string>(stores[0]?.id || 'store-1');

  // Products state
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('shopforge_products');
      return saved ? JSON.parse(saved) : initialProducts;
    } catch {
      return initialProducts;
    }
  });

  // Orders state
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('shopforge_orders');
      return saved ? JSON.parse(saved) : initialOrders;
    } catch {
      return initialOrders;
    }
  });

  // Customers state
  const [customers, setCustomers] = useState<Customer[]>(() => {
    try {
      const saved = localStorage.getItem('shopforge_customers');
      return saved ? JSON.parse(saved) : initialCustomers;
    } catch {
      return initialCustomers;
    }
  });

  // SaaS Merchant Users state (Admin Panel)
  const [merchantUsers, setMerchantUsers] = useState<MerchantUser[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_merchant_users');
      return saved ? JSON.parse(saved) : initialMerchantUsers;
    } catch {
      return initialMerchantUsers;
    }
  });

  // Platform Payment Gateways Config (AamarPay, Shohoz Pay, ShurjoPay)
  const [paymentGateways, setPaymentGateways] = useState<PaymentGatewayConfig[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_payment_gateways');
      return saved ? JSON.parse(saved) : initialPaymentGateways;
    } catch {
      return initialPaymentGateways;
    }
  });

  // Subscription Payments Ledger
  const [subscriptionPayments, setSubscriptionPayments] = useState<SubscriptionPayment[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_subscription_payments');
      return saved ? JSON.parse(saved) : initialSubscriptionPayments;
    } catch {
      return initialSubscriptionPayments;
    }
  });

  // OMS: Draft Orders
  const [draftOrders, setDraftOrders] = useState<DraftOrder[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_draft_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // OMS: Abandoned Checkouts
  const [abandonedCheckouts, setAbandonedCheckouts] = useState<AbandonedCheckout[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_abandoned_checkouts');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // OMS: Returns & Refunds
  const [returnsRefunds, setReturnsRefunds] = useState<ReturnRefundRecord[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_returns_refunds');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // OMS: Shipping & Delivery Settings
  const [shippingSettings, setShippingSettings] = useState<ShippingSettings | null>(() => {
    try {
      const saved = localStorage.getItem('shanju_shipping_settings');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Collections state
  const [collections, setCollections] = useState<Collection[]>(() => {
    try {
      const saved = localStorage.getItem('shanju_collections');
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    if (Array.isArray(collections)) {
      saveSafeLocalStorage('shanju_collections', JSON.stringify(collections));
    }
  }, [collections]);

  // Shopping Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  // Firestore DB Hydration on Startup
  useEffect(() => {
    let isMounted = true;

    async function loadDatabaseData() {
      try {
        const [
          dbStores, 
          dbProds, 
          dbOrders, 
          dbCusts, 
          dbUsers, 
          dbGateways, 
          dbPayments,
          dbDrafts,
          dbAbandoned,
          dbReturns,
          dbCollections
        ] = await Promise.all([
          fetchStoresFromDB(),
          fetchProductsFromDB(),
          fetchOrdersFromDB(),
          fetchCustomersFromDB(),
          fetchMerchantUsersFromDB(),
          fetchGatewaysFromDB(),
          fetchSubscriptionPaymentsFromDB(),
          fetchDraftOrdersFromDB(),
          fetchAbandonedCheckoutsFromDB(),
          fetchReturnsRefundsFromDB(),
          fetchCollectionsFromDB()
        ]);

        if (isMounted) {
          if (dbStores.length > 0) setStores(dbStores);
          if (dbProds.length > 0) setProducts(dbProds);
          if (dbOrders.length > 0) setOrders(dbOrders);
          if (dbCusts.length > 0) setCustomers(dbCusts);
          if (dbUsers.length > 0) setMerchantUsers(dbUsers);
          if (dbGateways.length > 0) setPaymentGateways(dbGateways);
          if (dbPayments.length > 0) setSubscriptionPayments(dbPayments);
          if (dbDrafts.length > 0) setDraftOrders(dbDrafts);
          if (dbAbandoned.length > 0) setAbandonedCheckouts(dbAbandoned);
          if (dbReturns.length > 0) setReturnsRefunds(dbReturns);
          if (Array.isArray(dbCollections) && dbCollections.length > 0) setCollections(dbCollections);
        }
      } catch (err) {
        console.warn('Initial Firestore sync note:', err);
      }
    }

    loadDatabaseData();

    // Also hydrate media from IndexedDB fallback
    loadFromIndexedDB<Product[]>('shopforge_products').then((dbProducts) => {
      if (isMounted && dbProducts && Array.isArray(dbProducts) && dbProducts.length > 0) {
        setProducts(dbProducts);
      }
    }).catch(() => {});

    return () => {
      isMounted = false;
    };
  }, []);

  // Safe Persistence
  useEffect(() => {
    saveSafeLocalStorage('shopforge_stores', stores);
    saveToIndexedDB('shopforge_stores', stores).catch(() => {});
  }, [stores]);

  useEffect(() => {
    saveSafeLocalStorage('shopforge_products', products);
    saveToIndexedDB('shopforge_products', products).catch(() => {});
  }, [products]);

  useEffect(() => {
    saveSafeLocalStorage('shopforge_orders', orders);
    saveToIndexedDB('shopforge_orders', orders).catch(() => {});
  }, [orders]);

  useEffect(() => {
    saveSafeLocalStorage('shanju_merchant_users', merchantUsers);
  }, [merchantUsers]);

  useEffect(() => {
    saveSafeLocalStorage('shanju_payment_gateways', paymentGateways);
  }, [paymentGateways]);

  useEffect(() => {
    saveSafeLocalStorage('shanju_subscription_payments', subscriptionPayments);
  }, [subscriptionPayments]);

  // Sync activeStoreId to merchant's owned store when logged in
  useEffect(() => {
    if (currentUser) {
      const userStore = stores.find((s) => s.ownerId === currentUser.uid);
      if (userStore) {
        const currentBelongs = stores.some((s) => s.id === activeStoreId && s.ownerId === currentUser.uid);
        if (!currentBelongs) {
          setActiveStoreId(userStore.id);
        }
      }
    }
  }, [currentUser, stores, activeStoreId]);

  // Find active store object
  const activeStore = stores.find((s) => s.id === activeStoreId) || stores[0] || initialStores[0];

  // Actions with Firestore Persistence
  const handleCreateStore = (name: string, category: string) => {
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const newStore: Store = {
      id: `store-${Date.now()}`,
      name,
      slug,
      logo: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=160&q=80',
      category,
      currency: 'BDT',
      currencySymbol: '৳',
      status: 'active',
      plan: 'starter',
      createdAt: new Date().toISOString().split('T')[0],
      ownerId: currentUser?.uid,
      theme: {
        primaryColor: '#059669',
        accentColor: '#10b981',
        fontFamily: 'Plus Jakarta Sans',
        announcementText: '🎉 Welcome to our brand new store! Get 10% off your first order.',
        announcementTextBn: '🎉 আমাদের নতুন অনলাইন স্টোরে স্বাগতম! প্রথম অর্ডারে পান ১০% ছাড়।',
        showAnnouncement: true,
        heroHeadline: `Welcome to ${name}`,
        heroHeadlineBn: `${name}-এ আপনাকে স্বাগতম`,
        heroSubheadline: 'Curated premium products delivered right to your door with fast delivery.',
        heroSubheadlineBn: 'সেরা মানের পণ্য এবং দ্রুততম হোম ডেলিভারি সেবা।',
        heroBannerImage: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80',
        layoutStyle: 'modern',
      },
    };

    setStores((prev) => [newStore, ...prev]);
    saveStoreToDB(newStore);
    setActiveStoreId(newStore.id);
  };

  const handleWizardStoreCreated = (newStore: Store, starterProducts: Product[]) => {
    const storeWithAuth: Store = {
      ...newStore,
      ownerId: currentUser?.uid || newStore.ownerId
    };
    setStores((prev) => [storeWithAuth, ...prev]);
    saveStoreToDB(storeWithAuth);

    if (starterProducts && starterProducts.length > 0) {
      setProducts((prev) => [...starterProducts, ...prev]);
      starterProducts.forEach((p) => saveProductToDB(p));
    }
    setActiveStoreId(storeWithAuth.id);
  };

  const handleAddProduct = (newProdData: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...newProdData,
      id: `prod-${Date.now()}`,
    };
    setProducts((prev) => [newProduct, ...prev]);
    saveProductToDB(newProduct);
  };

  const handleUpdateProduct = (updatedProd: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updatedProd.id ? updatedProd : p)));
    saveProductToDB(updatedProd);
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    deleteProductFromDB(productId);
  };

  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus, trackingId?: string, courier?: string) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          // Safe inventory reversal if cancelling or returning an active order
          if ((status === 'cancelled' || status === 'returned') && o.orderStatus !== 'cancelled' && o.orderStatus !== 'returned') {
            setProducts((prodPrev) =>
              prodPrev.map((p) => {
                const item = o.items.find((it) => it.productId === p.id);
                if (item) {
                  const restored = { ...p, stock: p.stock + item.quantity };
                  saveProductToDB(restored);
                  return restored;
                }
                return p;
              })
            );
          }

          const updated: Order = {
            ...o,
            orderStatus: status,
            courierTrackingId: trackingId !== undefined ? trackingId : o.courierTrackingId,
            courierName: courier !== undefined ? courier : o.courierName,
            updatedAt: new Date().toISOString()
          };
          saveOrderToDB(updated);
          return updated;
        }
        return o;
      })
    );
  };

  const handleUpdatePaymentStatus = (orderId: string, status: PaymentStatus) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          const updated = { ...o, paymentStatus: status, updatedAt: new Date().toISOString() };
          saveOrderToDB(updated);
          return updated;
        }
        return o;
      })
    );
  };

  const handleUpdateOrderNotes = (orderId: string, notes: string) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          const updated = { ...o, notes, updatedAt: new Date().toISOString() };
          saveOrderToDB(updated);
          return updated;
        }
        return o;
      })
    );
  };

  const handleBulkUpdateOrderStatus = (orderIds: string[], status: OrderStatus) => {
    orderIds.forEach((id) => handleUpdateOrderStatus(id, status));
  };

  // OMS Handlers
  const handleSaveDraftOrder = (draft: DraftOrder) => {
    setDraftOrders((prev) => {
      const exists = prev.some((d) => d.id === draft.id);
      if (exists) {
        return prev.map((d) => (d.id === draft.id ? draft : d));
      }
      return [draft, ...prev];
    });
    saveDraftOrderToDB(draft);
  };

  const handleDeleteDraftOrder = (draftId: string) => {
    setDraftOrders((prev) => prev.filter((d) => d.id !== draftId));
    deleteDraftOrderFromDB(draftId);
  };

  const handleConvertDraftToOrder = (draft: DraftOrder) => {
    // 1. Create real order from draft
    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber: draft.orderNumber.replace('DRAFT-', 'ORD-'),
      storeId: draft.storeId,
      customerName: draft.customerName,
      customerPhone: draft.customerPhone,
      customerEmail: draft.customerEmail,
      deliveryAddress: draft.deliveryAddress,
      city: draft.city,
      items: draft.items,
      subtotal: draft.subtotal,
      discount: draft.discount,
      shippingFee: draft.shippingFee,
      totalAmount: draft.totalAmount,
      paymentMethod: draft.paymentMethod,
      paymentStatus: draft.paymentMethod === 'cod' ? 'pending' : 'paid',
      orderStatus: 'confirmed',
      notes: draft.notes,
      createdAt: new Date().toISOString()
    };

    // 2. Decrement inventory and save order
    handleCreateOrder(newOrder);

    // 3. Delete draft from state and DB
    handleDeleteDraftOrder(draft.id);
  };

  const handleSaveAbandonedCheckout = (session: AbandonedCheckout) => {
    setAbandonedCheckouts((prev) => [session, ...prev]);
    saveAbandonedCheckoutToDB(session);
  };

  const handleUpdateAbandonedCheckoutStatus = (id: string, status: 'incomplete' | 'recovered' | 'blocked') => {
    setAbandonedCheckouts((prev) =>
      prev.map((c) => (c.id === id ? { ...c, recoveryStatus: status, updatedAt: new Date().toISOString() } : c))
    );
    updateAbandonedCheckoutStatusInDB(id, status);
  };

  const handleSaveReturnRefund = (record: ReturnRefundRecord) => {
    setReturnsRefunds((prev) => [record, ...prev]);
    saveReturnRefundToDB(record);
  };

  const handleUpdateReturnRefundStatus = (id: string, status: 'pending' | 'approved' | 'processed' | 'rejected') => {
    setReturnsRefunds((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          // If approved or processed, safely restore inventory
          if ((status === 'approved' || status === 'processed') && r.status !== 'approved' && r.status !== 'processed') {
            setProducts((prodPrev) =>
              prodPrev.map((p) => {
                const item = r.items.find((it) => it.productId === p.id);
                if (item) {
                  const restored = { ...p, stock: p.stock + item.quantity };
                  saveProductToDB(restored);
                  return restored;
                }
                return p;
              })
            );
          }
          return { ...r, status, updatedAt: new Date().toISOString() };
        }
        return r;
      })
    );
    updateReturnRefundStatusInDB(id, status);
  };

  const handleSaveShippingSettings = (settings: ShippingSettings) => {
    setShippingSettings(settings);
    saveShippingSettingsToDB(settings);

    if (settings.storeLocation) {
      setStores((prev) =>
        prev.map((s) => {
          if (s.id === settings.storeId) {
            const updated: Store = {
              ...s,
              city: settings.storeLocation?.city || settings.storeLocation?.district || s.city,
              address: settings.storeLocation?.address || s.address,
              storeLocation: settings.storeLocation,
            };
            saveStoreToDB(updated);
            return updated;
          }
          return s;
        })
      );
    }
  };

  const handleAddCollection = async (newColData: Omit<Collection, 'id'>) => {
    const newCol: Collection = {
      ...newColData,
      id: `col-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: newColData.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setCollections((prev) => {
      const arr = Array.isArray(prev) ? prev : [];
      return [newCol, ...arr];
    });
    await saveCollectionToDB(newCol);
  };

  const handleUpdateCollection = async (updated: Collection) => {
    const withUpdate: Collection = {
      ...updated,
      updatedAt: new Date().toISOString(),
    };
    setCollections((prev) => prev.map((c) => (c.id === withUpdate.id ? withUpdate : c)));
    await saveCollectionToDB(withUpdate);
  };

  const handleDeleteCollection = async (collectionId: string) => {
    setCollections((prev) => prev.filter((c) => c.id !== collectionId));
    await deleteCollectionFromDB(collectionId);
  };

  const handleUpdateStoreTheme = (
    storeId: string,
    updatedTheme: Partial<StoreTheme>,
    storeName?: string
  ) => {
    setStores((prev) =>
      prev.map((s) => {
        if (s.id === storeId) {
          const updatedStore: Store = {
            ...s,
            name: storeName || s.name,
            theme: {
              ...s.theme,
              ...updatedTheme,
            },
          };
          saveStoreToDB(updatedStore);
          return updatedStore;
        }
        return s;
      })
    );
  };

  const handleUpdateStorePlan = (
    storeId: string,
    newPlan: 'starter' | 'growth' | 'enterprise'
  ) => {
    setStores((prev) =>
      prev.map((s) => {
        if (s.id === storeId) {
          const updated = { ...s, plan: newPlan };
          saveStoreToDB(updated);
          return updated;
        }
        return s;
      })
    );
    setMerchantUsers((prev) =>
      prev.map((u) => {
        if (u.storeId === storeId) {
          const updated = { ...u, plan: newPlan };
          saveMerchantUserToDB(updated);
          return updated;
        }
        return u;
      })
    );
  };

  // Subscription payment completion handler
  const handleAddSubscriptionPayment = (payment: SubscriptionPayment) => {
    setSubscriptionPayments((prev) => [payment, ...prev]);
    saveSubscriptionPaymentToDB(payment);

    setStores((prev) =>
      prev.map((s) => {
        if (s.id === payment.storeId) {
          const updated = { ...s, plan: payment.planId };
          saveStoreToDB(updated);
          return updated;
        }
        return s;
      })
    );
    setMerchantUsers((prev) =>
      prev.map((u) => {
        if (u.storeId === payment.storeId) {
          const updated = { ...u, plan: payment.planId };
          saveMerchantUserToDB(updated);
          return updated;
        }
        return u;
      })
    );
  };

  // Admin Panel merchant user handlers
  const handleAddUser = (newUser: Omit<MerchantUser, 'id'>) => {
    const createdUser: MerchantUser = {
      ...newUser,
      id: `usr-${Date.now()}`,
    };
    setMerchantUsers((prev) => [createdUser, ...prev]);
    saveMerchantUserToDB(createdUser);
  };

  const handleUpdateUser = (updatedUser: MerchantUser) => {
    setMerchantUsers((prev) =>
      prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    );
    saveMerchantUserToDB(updatedUser);

    setStores((prev) =>
      prev.map((s) => {
        if (s.id === updatedUser.storeId) {
          const updated = { ...s, plan: updatedUser.plan };
          saveStoreToDB(updated);
          return updated;
        }
        return s;
      })
    );
  };

  const handleDeleteUser = (userId: string) => {
    setMerchantUsers((prev) => prev.filter((u) => u.id !== userId));
    deleteMerchantUserFromDB(userId);
  };

  // Admin Payment Gateways Setup handlers
  const handleUpdateGateway = (updatedGateway: PaymentGatewayConfig) => {
    setPaymentGateways((prev) =>
      prev.map((g) => (g.id === updatedGateway.id ? updatedGateway : g))
    );
    saveGatewayToDB(updatedGateway);
  };

  const handleToggleGateway = (gatewayId: PaymentGatewayProvider) => {
    setPaymentGateways((prev) =>
      prev.map((g) => {
        if (g.id === gatewayId) {
          const toggled = { ...g, isEnabled: !g.isEnabled };
          saveGatewayToDB(toggled);
          return toggled;
        }
        return g;
      })
    );
  };

  // Cart operations
  const handleAddToCart = (product: Product) => {
    if (product.stock <= 0) {
      alert(language === 'bn' ? 'দুঃখিত, এই পণ্যটির স্টক বর্তমানে শেষ।' : 'Sorry, this product is currently out of stock.');
      return;
    }

    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          alert(language === 'bn' ? 'স্টকে থাকা পরিমাণের বেশি যোগ করা যাবে না।' : 'Cannot add more than available stock.');
          return prev;
        }
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((item) => item.product.id !== productId));
    } else {
      const prod = products.find((p) => p.id === productId);
      if (prod && quantity > prod.stock) {
        alert(language === 'bn' ? 'স্টকে থাকা পরিমাণের বেশি যোগ করা যাবে না।' : 'Quantity exceeds available stock.');
        return;
      }
      setCart((prev) =>
        prev.map((item) =>
          item.product.id === productId ? { ...item, quantity } : item
        )
      );
    }
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleCreateOrder = (newOrder: Order) => {
    // 1. Decrement Stock in Products (including variant stocks)
    setProducts((prev) =>
      prev.map((p) => {
        const orderItemsForProd = newOrder.items.filter((item) => item.productId === p.id);
        if (orderItemsForProd.length > 0) {
          const totalQtyDeducted = orderItemsForProd.reduce((sum, i) => sum + i.quantity, 0);
          const updatedStock = Math.max(0, p.stock - totalQtyDeducted);
          let updatedVariants = p.variants;
          if (Array.isArray(p.variants)) {
            updatedVariants = p.variants.map((v) => {
              const matchedItem = orderItemsForProd.find((item) => item.variant === v.name || item.variant === v.id);
              if (matchedItem) {
                return { ...v, stock: Math.max(0, v.stock - matchedItem.quantity) };
              }
              return v;
            });
          }
          const updatedProd = { ...p, stock: updatedStock, variants: updatedVariants };
          saveProductToDB(updatedProd);
          return updatedProd;
        }
        return p;
      })
    );

    // 2. Save Order to state and Firestore
    setOrders((prev) => [newOrder, ...prev]);
    saveOrderToDB(newOrder);

    // 3. Record or update customer
    setCustomers((prev) => {
      const existing = prev.find((c) => c.phone === newOrder.customerPhone);
      if (existing) {
        const updatedCust: Customer = {
          ...existing,
          totalOrders: existing.totalOrders + 1,
          totalSpent: existing.totalSpent + newOrder.totalAmount,
          lastOrderDate: new Date().toISOString().split('T')[0],
        };
        saveCustomerToDB(updatedCust);
        return prev.map((c) => (c.id === existing.id ? updatedCust : c));
      } else {
        const newCust: Customer = {
          id: `cust-${Date.now()}`,
          storeId: activeStore.id,
          name: newOrder.customerName,
          email: newOrder.customerEmail,
          phone: newOrder.customerPhone,
          city: newOrder.city,
          totalOrders: 1,
          totalSpent: newOrder.totalAmount,
          lastOrderDate: new Date().toISOString().split('T')[0],
          status: 'new',
        };
        saveCustomerToDB(newCust);
        return [newCust, ...prev];
      }
    });
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        stores,
        setStores,
        activeStoreId,
        setActiveStoreId,
        activeStore,
        products,
        setProducts,
        orders,
        setOrders,
        customers,
        setCustomers,
        merchantUsers,
        setMerchantUsers,
        paymentGateways,
        setPaymentGateways,
        subscriptionPayments,
        setSubscriptionPayments,
        draftOrders,
        setDraftOrders,
        abandonedCheckouts,
        setAbandonedCheckouts,
        returnsRefunds,
        setReturnsRefunds,
        shippingSettings,
        setShippingSettings,
        collections,
        setCollections,
        cart,
        isCartOpen,
        setIsCartOpen,
        isCreateStoreWizardOpen,
        setIsCreateStoreWizardOpen,
        isExportModalOpen,
        setIsExportModalOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authModalMode,
        setAuthModalMode,
        totalCartCount,
        handleCreateStore,
        handleWizardStoreCreated,
        handleAddProduct,
        handleUpdateProduct,
        handleDeleteProduct,
        handleUpdateOrderStatus,
        handleUpdatePaymentStatus,
        handleUpdateOrderNotes,
        handleBulkUpdateOrderStatus,
        handleSaveDraftOrder,
        handleDeleteDraftOrder,
        handleConvertDraftToOrder,
        handleSaveAbandonedCheckout,
        handleUpdateAbandonedCheckoutStatus,
        handleSaveReturnRefund,
        handleUpdateReturnRefundStatus,
        handleSaveShippingSettings,
        handleAddCollection,
        handleUpdateCollection,
        handleDeleteCollection,
        handleUpdateStoreTheme,
        handleUpdateStorePlan,
        handleAddSubscriptionPayment,
        handleAddUser,
        handleUpdateUser,
        handleDeleteUser,
        handleUpdateGateway,
        handleToggleGateway,
        handleAddToCart,
        handleUpdateCartQuantity,
        handleClearCart,
        handleCreateOrder,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
