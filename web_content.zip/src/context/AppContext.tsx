import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Language,
  UserProfile,
  Account,
  Category,
  Transaction,
  AccountTransfer,
  Loan,
  LoanRepayment,
  LoanDisbursement,
  AppBackupData
} from '../types';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  currentUser: UserProfile;
  users: UserProfile[];
  setCurrentUserId: (id: string) => void;
  createUser: (name: string, pin?: string, question?: string, answer?: string) => void;
  updateUser: (user: Partial<UserProfile>) => void;
  deleteUser: (id: string) => void;

  isLocked: boolean;
  unlockWithPin: (pin: string) => boolean;
  unlockWithSecurityAnswer: (answer: string) => boolean;
  lockApp: () => void;
  changeUserPin: (newPin: string, enabled: boolean) => void;

  accounts: Account[];
  addAccount: (acc: Omit<Account, 'id' | 'userId'>) => void;
  updateAccount: (id: string, acc: Partial<Account>) => void;
  deleteAccount: (id: string) => void;

  categories: Category[];
  addCategory: (cat: Omit<Category, 'id'>) => void;
  updateCategory: (id: string, cat: Partial<Category>) => void;
  deleteCategory: (id: string) => void;

  transactions: Transaction[];
  addTransaction: (tx: Omit<Transaction, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => void;
  updateTransaction: (id: string, tx: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;

  transfers: AccountTransfer[];
  addTransfer: (tf: Omit<AccountTransfer, 'id' | 'userId' | 'createdAt'>) => void;
  deleteTransfer: (id: string) => void;

  loans: Loan[];
  addLoan: (loan: Omit<Loan, 'id' | 'userId' | 'repayments' | 'createdAt' | 'updatedAt'>) => string;
  updateLoan: (id: string, loan: Partial<Loan>) => void;
  deleteLoan: (id: string) => void;
  addLoanRepayment: (loanId: string, repayment: Omit<LoanRepayment, 'id' | 'createdAt'>) => void;
  deleteLoanRepayment: (loanId: string, repaymentId: string) => void;
  addLoanDisbursement: (loanId: string, disb: Omit<LoanDisbursement, 'id' | 'createdAt'>) => void;
  settleLoan: (loanId: string, settleDate: string) => void;

  backupData: () => AppBackupData;
  restoreData: (data: AppBackupData) => { success: boolean; error?: string };
  loadDemoData: () => void;
  resetAllData: () => void;
  getAccountBalance: (accountId: string) => number;
}

const STORAGE_KEYS = {
  USERS: 'khatavahi_users_v2',
  CURRENT_USER_ID: 'khatavahi_current_user_v2',
  ACCOUNTS: 'khatavahi_accounts_v2',
  CATEGORIES: 'khatavahi_categories_v2',
  TRANSACTIONS: 'khatavahi_transactions_v2',
  TRANSFERS: 'khatavahi_transfers_v2',
  LOANS: 'khatavahi_loans_v2',
  LANGUAGE: 'khatavahi_language_v2'
};

const DEFAULT_USERS: UserProfile[] = [
  {
    id: 'u-default',
    name: 'અંગત ખાતાવહી / Personal Book',
    pinEnabled: false,
    securityQuestion: 'તમારું જન્મ સ્થળ કયું છે? / What is your birthplace?',
    securityAnswer: 'અમદાવાદ',
    createdAt: new Date().toISOString()
  }
];

const DEFAULT_CATEGORIES: Category[] = [
  // Income
  { id: 'cat-inc-1', nameEn: 'Salary & Wages', nameGu: 'પગાર / વેતન', type: 'income', icon: 'Briefcase', color: 'emerald', isDefault: true },
  { id: 'cat-inc-2', nameEn: 'Business & Trade', nameGu: 'વેપાર-ધંધો / વ્યાપાર', type: 'income', icon: 'Store', color: 'blue', isDefault: true },
  { id: 'cat-inc-3', nameEn: 'Agriculture / Farming', nameGu: 'ખેતીવાડી આવક', type: 'income', icon: 'Wheat', color: 'green', isDefault: true },
  { id: 'cat-inc-4', nameEn: 'Interest Received', nameGu: 'વ્યાજ આવક', type: 'income', icon: 'TrendingUp', color: 'amber', isDefault: true },
  { id: 'cat-inc-5', nameEn: 'Rental Income', nameGu: 'ભાડાની આવક', type: 'income', icon: 'Home', color: 'indigo', isDefault: true },
  { id: 'cat-inc-6', nameEn: 'Other Income', nameGu: 'અન્ય આવક', type: 'income', icon: 'Tag', color: 'purple', isDefault: true },

  // Expense
  { id: 'cat-exp-1', nameEn: 'Groceries & Provisions', nameGu: 'કરિયાણું અને રાશન', type: 'expense', icon: 'ShoppingBag', color: 'orange', isDefault: true },
  { id: 'cat-exp-2', nameEn: 'Household & Family', nameGu: 'ઘરખર્ચ / કુટુંબ', type: 'expense', icon: 'Home', color: 'amber', isDefault: true },
  { id: 'cat-exp-3', nameEn: 'Electricity & Utilities', nameGu: 'લાઇટબિલ / ગેસ / પાણી', type: 'expense', icon: 'Zap', color: 'yellow', isDefault: true },
  { id: 'cat-exp-4', nameEn: 'Medical & Healthcare', nameGu: 'દવા / સારવાર / હોસ્પિટલ', type: 'expense', icon: 'HeartPulse', color: 'rose', isDefault: true },
  { id: 'cat-exp-5', nameEn: 'Travel & Fuel', nameGu: 'મુસાફરી અને પેટ્રોલ/ડીઝલ', type: 'expense', icon: 'Car', color: 'cyan', isDefault: true },
  { id: 'cat-exp-6', nameEn: 'Agriculture Expenses', nameGu: 'ખેતી ખર્ચ / ખાતર / બિયારણ', type: 'expense', icon: 'Sprout', color: 'emerald', isDefault: true },
  { id: 'cat-exp-7', nameEn: 'Interest Paid', nameGu: 'વ્યાજ ચૂકવણી', type: 'expense', icon: 'Percent', color: 'red', isDefault: true },
  { id: 'cat-exp-8', nameEn: 'Education & Fees', nameGu: 'શિક્ષણ અને ફી', type: 'expense', icon: 'GraduationCap', color: 'blue', isDefault: true },
  { id: 'cat-exp-9', nameEn: 'Other Expenses', nameGu: 'અન્ય પરચુરણ ખર્ચ', type: 'expense', icon: 'MoreHorizontal', color: 'slate', isDefault: true }
];

const DEFAULT_ACCOUNTS: Account[] = [
  {
    id: 'acc-cash',
    userId: 'u-default',
    name: 'રોકડ મેળ (Cash in Hand)',
    type: 'cash',
    initialBalance: 25000,
    color: '#059669',
    isDefault: true
  },
  {
    id: 'acc-sbi',
    userId: 'u-default',
    name: 'State Bank of India (SBI)',
    type: 'bank',
    bankName: 'SBI - Main Branch',
    accountNumber: '**** 4589',
    initialBalance: 75000,
    color: '#2563eb',
    isDefault: false
  },
  {
    id: 'acc-hdfc',
    userId: 'u-default',
    name: 'HDFC Bank Ltd',
    type: 'bank',
    bankName: 'HDFC Vyapar',
    accountNumber: '**** 8821',
    initialBalance: 40000,
    color: '#dc2626',
    isDefault: false
  }
];

export const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Language
  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Language) || 'gu';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
  };

  // 2. Users
  const [users, setUsers] = useState<UserProfile[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.USERS);
      return stored ? JSON.parse(stored) : DEFAULT_USERS;
    } catch {
      return DEFAULT_USERS;
    }
  });

  const [currentUserId, setCurrentUserIdState] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID) || (users[0]?.id || 'u-default');
  });

  const currentUser = users.find((u) => u.id === currentUserId) || users[0] || DEFAULT_USERS[0];

  // 3. Lock State
  const [isLocked, setIsLocked] = useState<boolean>(() => {
    return Boolean(currentUser?.pinEnabled && currentUser?.pin);
  });

  const lockApp = () => {
    if (currentUser?.pinEnabled && currentUser?.pin) {
      setIsLocked(true);
    }
  };

  const unlockWithPin = (pin: string): boolean => {
    if (!currentUser.pinEnabled || currentUser.pin === pin) {
      setIsLocked(false);
      return true;
    }
    return false;
  };

  const unlockWithSecurityAnswer = (answer: string): boolean => {
    if (
      currentUser.securityAnswer &&
      currentUser.securityAnswer.trim().toLowerCase() === answer.trim().toLowerCase()
    ) {
      setIsLocked(false);
      return true;
    }
    return false;
  };

  const changeUserPin = (newPin: string, enabled: boolean) => {
    const updated = users.map((u) => {
      if (u.id === currentUser.id) {
        return { ...u, pin: newPin, pinEnabled: enabled };
      }
      return u;
    });
    setUsers(updated);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updated));
    if (!enabled) {
      setIsLocked(false);
    }
  };

  const setCurrentUserId = (id: string) => {
    setCurrentUserIdState(id);
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, id);
    const targetUser = users.find((u) => u.id === id);
    if (targetUser?.pinEnabled && targetUser?.pin) {
      setIsLocked(true);
    } else {
      setIsLocked(false);
    }
  };

  const createUser = (name: string, pin?: string, question?: string, answer?: string) => {
    const newUser: UserProfile = {
      id: `u-${Date.now()}`,
      name,
      pin: pin || '',
      pinEnabled: Boolean(pin && pin.length >= 4),
      securityQuestion: question,
      securityAnswer: answer,
      createdAt: new Date().toISOString()
    };
    const updated = [...users, newUser];
    setUsers(updated);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updated));
    setCurrentUserId(newUser.id);
  };

  const updateUser = (data: Partial<UserProfile>) => {
    const updated = users.map((u) => (u.id === currentUser.id ? { ...u, ...data } : u));
    setUsers(updated);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updated));
  };

  const deleteUser = (id: string) => {
    if (users.length <= 1) return;
    const remaining = users.filter((u) => u.id !== id);
    setUsers(remaining);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(remaining));
    if (currentUserId === id) {
      setCurrentUserId(remaining[0].id);
    }
  };

  // 4. Accounts
  const [accounts, setAccounts] = useState<Account[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
      return stored ? JSON.parse(stored) : DEFAULT_ACCOUNTS;
    } catch {
      return DEFAULT_ACCOUNTS;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
  }, [accounts]);

  const addAccount = (acc: Omit<Account, 'id' | 'userId'>) => {
    const newAcc: Account = {
      ...acc,
      id: `acc-${Date.now()}`,
      userId: currentUser.id
    };
    setAccounts((prev) => [...prev, newAcc]);
  };

  const updateAccount = (id: string, acc: Partial<Account>) => {
    setAccounts((prev) => prev.map((a) => (a.id === id ? { ...a, ...acc } : a)));
  };

  const deleteAccount = (id: string) => {
    setAccounts((prev) => prev.filter((a) => a.id !== id));
  };

  // 5. Categories
  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      return stored ? JSON.parse(stored) : DEFAULT_CATEGORIES;
    } catch {
      return DEFAULT_CATEGORIES;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  }, [categories]);

  const addCategory = (cat: Omit<Category, 'id'>) => {
    const newCat: Category = {
      ...cat,
      id: `cat-${Date.now()}`,
      userId: currentUser.id
    };
    setCategories((prev) => [...prev, newCat]);
  };

  const updateCategory = (id: string, cat: Partial<Category>) => {
    setCategories((prev) => prev.map((c) => (c.id === id ? { ...c, ...cat } : c)));
  };

  const deleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
  };

  // 6. Transactions
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
      if (stored) return JSON.parse(stored);
      // Seed initial sample transactions
      return [
        {
          id: 'tx-1',
          userId: 'u-default',
          type: 'income',
          amount: 50000,
          date: '2025-01-05',
          categoryId: 'cat-inc-1',
          accountId: 'acc-sbi',
          title: 'માસિક પગાર જમા / Monthly Salary',
          partyName: 'શ્રી ટેક્સટાઇલ્સ પ્રા. લિ.',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: 'tx-2',
          userId: 'u-default',
          type: 'expense',
          amount: 8500,
          date: '2025-01-08',
          categoryId: 'cat-exp-1',
          accountId: 'acc-cash',
          title: 'ઘર રાશન અને કરિયાણું / Groceries',
          partyName: 'શ્રી ગણેશ પ્રોવિઝન સ્ટોર',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: 'tx-3',
          userId: 'u-default',
          type: 'expense',
          amount: 3200,
          date: '2025-01-12',
          categoryId: 'cat-exp-3',
          accountId: 'acc-sbi',
          title: 'લાઇટબિલ યુજીવીસીએલ / Electricity Bill',
          partyName: 'UGVCL',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (tx: Omit<Transaction, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
    const newTx: Transaction = {
      ...tx,
      id: `tx-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      userId: currentUser.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const updateTransaction = (id: string, tx: Partial<Transaction>) => {
    setTransactions((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...tx, updatedAt: new Date().toISOString() } : t))
    );
  };

  const deleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  // 7. Account Transfers
  const [transfers, setTransfers] = useState<AccountTransfer[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.TRANSFERS);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSFERS, JSON.stringify(transfers));
  }, [transfers]);

  const addTransfer = (tf: Omit<AccountTransfer, 'id' | 'userId' | 'createdAt'>) => {
    const newTf: AccountTransfer = {
      ...tf,
      id: `tf-${Date.now()}`,
      userId: currentUser.id,
      createdAt: new Date().toISOString()
    };
    setTransfers((prev) => [newTf, ...prev]);
  };

  const deleteTransfer = (id: string) => {
    setTransfers((prev) => prev.filter((t) => t.id !== id));
  };

  // 8. Loans & Vyaj
  const [loans, setLoans] = useState<Loan[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LOANS);
      if (stored) return JSON.parse(stored);
      // Realistic default seed loans demonstrating leap year precision & partial repayments!
      return [
        {
          id: 'loan-sample-lent-1',
          userId: 'u-default',
          type: 'lent', // Money given on interest
          partyName: 'રમેશભાઈ ગોવિંદભાઈ પટેલ (Ramesh Patel)',
          partyPhone: '+91 98250 12345',
          partyAddress: 'મોટા વરાછા, સુરત',
          initialPrincipal: 100000,
          startDate: '2024-02-15', // Leap year 2024!
          interestType: 'simple',
          interestRate: 1.5, // 1.5% per month (18% p.a.)
          ratePeriod: 'monthly',
          compoundingFrequency: 'monthly',
          status: 'active',
          notes: 'દુકાનના માલ ભરવા માટે ધીરેલ રકમ. દર મહિને દોઢ ટકા વ્યાજ.',
          repayments: [
            {
              id: 'rep-1',
              date: '2024-08-15',
              amount: 15000,
              note: '૬ મહિનાનું વ્યાજ અને બાકી મુદ્દલ પેટે ચૂકવણી',
              createdAt: '2024-08-15T10:00:00Z'
            }
          ],
          createdAt: '2024-02-15T09:00:00Z',
          updatedAt: '2024-08-15T10:00:00Z'
        },
        {
          id: 'loan-sample-borrowed-1',
          userId: 'u-default',
          type: 'borrowed', // Money taken on interest
          partyName: 'સુરેશભાઈ અમૃતલાલ શાહ (Suresh Shah)',
          partyPhone: '+91 94260 67890',
          partyAddress: 'માણેકચોક, અમદાવાદ',
          initialPrincipal: 200000,
          startDate: '2024-04-01',
          interestType: 'compound',
          interestRate: 12, // 12% per year
          ratePeriod: 'yearly',
          compoundingFrequency: 'yearly',
          status: 'active',
          notes: 'નવું મશીન ખરીદવા માટે લીધેલી લોન. વાર્ષિક ચક્રવૃદ્ધિ વ્યાજ.',
          repayments: [
            {
              id: 'rep-borrow-1',
              date: '2025-01-10',
              amount: 50000,
              note: 'પ્રથમ હપ્તો જમા',
              createdAt: '2025-01-10T12:00:00Z'
            }
          ],
          createdAt: '2024-04-01T10:00:00Z',
          updatedAt: '2025-01-10T12:00:00Z'
        }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOANS, JSON.stringify(loans));
  }, [loans]);

  const addLoan = (loan: Omit<Loan, 'id' | 'userId' | 'repayments' | 'createdAt' | 'updatedAt'>): string => {
    const newId = `loan-${Date.now()}`;
    const newLoan: Loan = {
      ...loan,
      id: newId,
      userId: currentUser.id,
      repayments: [],
      disbursements: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setLoans((prev) => [newLoan, ...prev]);
    return newId;
  };

  const updateLoan = (id: string, loan: Partial<Loan>) => {
    setLoans((prev) =>
      prev.map((l) => (l.id === id ? { ...l, ...loan, updatedAt: new Date().toISOString() } : l))
    );
  };

  const deleteLoan = (id: string) => {
    setLoans((prev) => prev.filter((l) => l.id !== id));
  };

  const addLoanRepayment = (loanId: string, repayment: Omit<LoanRepayment, 'id' | 'createdAt'>) => {
    const newRep: LoanRepayment = {
      ...repayment,
      id: `rep-${Date.now()}`,
      createdAt: new Date().toISOString()
    };

    setLoans((prev) =>
      prev.map((l) => {
        if (l.id === loanId) {
          const updatedReps = [...(l.repayments || []), newRep];
          return {
            ...l,
            repayments: updatedReps,
            updatedAt: new Date().toISOString()
          };
        }
        return l;
      })
    );
  };

  const deleteLoanRepayment = (loanId: string, repaymentId: string) => {
    setLoans((prev) =>
      prev.map((l) => {
        if (l.id === loanId) {
          return {
            ...l,
            repayments: (l.repayments || []).filter((r) => r.id !== repaymentId),
            updatedAt: new Date().toISOString()
          };
        }
        return l;
      })
    );
  };

  const addLoanDisbursement = (loanId: string, disb: Omit<LoanDisbursement, 'id' | 'createdAt'>) => {
    const newDisb: LoanDisbursement = {
      ...disb,
      id: `disb-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setLoans((prev) =>
      prev.map((l) => {
        if (l.id === loanId) {
          return {
            ...l,
            disbursements: [...(l.disbursements || []), newDisb],
            updatedAt: new Date().toISOString()
          };
        }
        return l;
      })
    );
  };

  const settleLoan = (loanId: string, settleDate: string) => {
    setLoans((prev) =>
      prev.map((l) => {
        if (l.id === loanId) {
          return {
            ...l,
            status: 'settled',
            settledDate: settleDate,
            updatedAt: new Date().toISOString()
          };
        }
        return l;
      })
    );
  };

  // 9. Account Balance Calculation
  const getAccountBalance = (accountId: string): number => {
    const target = accounts.find((a) => a.id === accountId);
    if (!target) return 0;

    let balance = target.initialBalance || 0;

    // Income (+) & Expense (-) from transactions
    transactions.forEach((tx) => {
      if (tx.accountId === accountId) {
        if (tx.type === 'income') balance += tx.amount;
        else if (tx.type === 'expense') balance -= tx.amount;
      }
    });

    // Transfers: Out (-) & In (+)
    transfers.forEach((tf) => {
      if (tf.fromAccountId === accountId) balance -= tf.amount;
      if (tf.toAccountId === accountId) balance += tf.amount;
    });

    // Loans:
    // If we lent money from this account: balance -= initialPrincipal
    // If repayment received into this account: balance += amount
    loans.forEach((l) => {
      if (l.accountId === accountId) {
        if (l.type === 'lent') balance -= l.initialPrincipal;
        else if (l.type === 'borrowed') balance += l.initialPrincipal;
      }

      (l.repayments || []).forEach((r) => {
        if (r.accountId === accountId) {
          if (l.type === 'lent') balance += r.amount; // repayment from borrower received
          else if (l.type === 'borrowed') balance -= r.amount; // repayment to lender paid
        }
      });
    });

    return balance;
  };

  // 10. Backup and Restore
  const backupData = (): AppBackupData => {
    return {
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      users,
      currentUserId,
      accounts,
      categories,
      transactions,
      transfers,
      loans,
      language
    };
  };

  const restoreData = (data: AppBackupData): { success: boolean; error?: string } => {
    try {
      if (!data || !data.version) {
        return { success: false, error: 'અમાન્ય બેકઅપ ફાઇલ / Invalid backup file format' };
      }

      if (data.users && Array.isArray(data.users)) {
        setUsers(data.users);
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(data.users));
      }
      if (data.currentUserId) {
        setCurrentUserIdState(data.currentUserId);
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, data.currentUserId);
      }
      if (data.accounts && Array.isArray(data.accounts)) {
        setAccounts(data.accounts);
        localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(data.accounts));
      }
      if (data.categories && Array.isArray(data.categories)) {
        setCategories(data.categories);
        localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(data.categories));
      }
      if (data.transactions && Array.isArray(data.transactions)) {
        setTransactions(data.transactions);
        localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(data.transactions));
      }
      if (data.transfers && Array.isArray(data.transfers)) {
        setTransfers(data.transfers);
        localStorage.setItem(STORAGE_KEYS.TRANSFERS, JSON.stringify(data.transfers));
      }
      if (data.loans && Array.isArray(data.loans)) {
        setLoans(data.loans);
        localStorage.setItem(STORAGE_KEYS.LOANS, JSON.stringify(data.loans));
      }
      if (data.language) {
        setLanguageState(data.language);
        localStorage.setItem(STORAGE_KEYS.LANGUAGE, data.language);
      }

      setIsLocked(false);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to restore data' };
    }
  };

  const resetAllData = () => {
    localStorage.clear();
    setUsers(DEFAULT_USERS);
    setCurrentUserIdState('u-default');
    setAccounts(DEFAULT_ACCOUNTS);
    setCategories(DEFAULT_CATEGORIES);
    setTransactions([]);
    setTransfers([]);
    setLoans([]);
    setIsLocked(false);
  };

  const loadDemoData = () => {
    setAccounts(DEFAULT_ACCOUNTS);
    setCategories(DEFAULT_CATEGORIES);
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        currentUser,
        users,
        setCurrentUserId,
        createUser,
        updateUser,
        deleteUser,

        isLocked,
        unlockWithPin,
        unlockWithSecurityAnswer,
        lockApp,
        changeUserPin,

        accounts,
        addAccount,
        updateAccount,
        deleteAccount,

        categories,
        addCategory,
        updateCategory,
        deleteCategory,

        transactions,
        addTransaction,
        updateTransaction,
        deleteTransaction,

        transfers,
        addTransfer,
        deleteTransfer,

        loans,
        addLoan,
        updateLoan,
        deleteLoan,
        addLoanRepayment,
        deleteLoanRepayment,
        addLoanDisbursement,
        settleLoan,

        backupData,
        restoreData,
        loadDemoData,
        resetAllData,
        getAccountBalance
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
