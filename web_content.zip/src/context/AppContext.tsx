import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type {
  AppNotification,
  JobPosting,
  JobStatus,
  Review,
  Role,
  ToastMessage,
  Transaction,
  Worker,
} from "../types";
import {
  JOBS,
  NOTIFICATIONS_SEED,
  REVIEWS,
  TRANSACTIONS,
  WORKERS,
} from "../data/mockData";

export type ThemeMode = "light" | "dark" | "system";

export type Screen =
  | "splash"
  | "landing"
  | "auth"
  | "role-select"
  | "onboarding-worker"
  | "onboarding-contractor"
  | "worker-home"
  | "job-discovery"
  | "job-detail"
  | "worker-map"
  | "worker-profile"
  | "shram-score"
  | "earnings"
  | "contractor-home"
  | "post-job"
  | "worker-matching"
  | "contractor-dashboard"
  | "workers-directory"
  | "contractor-payments"
  | "active-job"
  | "completion"
  | "payment-gateway"
  | "rate"
  | "notifications"
  | "safety"
  | "search"
  | "admin-dashboard"
  | "impact-dashboard"
  | "sustainability"
  | "settings"
  | "demo-center"
  | "bventure-demo";

interface NavEntry {
  screen: Screen;
  params?: Record<string, unknown>;
}

interface PostJobDraft {
  category?: string;
  categoryLabel?: string;
  emoji?: string;
  description?: string;
  areaOverride?: string;
  schedule?: string;
  workersRequired?: number;
  budget?: number;
}

interface AppContextValue {
  // theme
  theme: ThemeMode;
  resolvedTheme: "light" | "dark";
  setTheme: (t: ThemeMode) => void;

  // nav
  screen: Screen;
  params: Record<string, unknown>;
  navigate: (screen: Screen, params?: Record<string, unknown>) => void;
  goBack: () => void;
  canGoBack: boolean;
  replace: (screen: Screen, params?: Record<string, unknown>) => void;

  // role & users
  role: Role;
  setRole: (r: Role) => void;
  currentWorker: Worker;
  currentContractorName: string;
  isFirstTime: boolean;
  markOnboarded: () => void;

  // data
  jobs: JobPosting[];
  workers: Worker[];
  reviews: Review[];
  notifications: AppNotification[];
  transactions: Transaction[];
  walletBalance: number;
  postJobDraft: PostJobDraft;
  setPostJobDraft: (d: Partial<PostJobDraft>) => void;
  resetPostJobDraft: () => void;

  activeJobId: string | null;
  setActiveJobId: (id: string | null) => void;
  matchedWorkerIds: string[];

  postJob: (draft: PostJobDraft) => JobPosting;
  runMatching: (jobId: string) => void;
  selectWorkerForJob: (jobId: string, workerId: string) => void;
  advanceJobStatus: (jobId: string, status: JobStatus) => void;
  completeJob: (jobId: string) => void;
  releasePayment: (jobId: string, amount: number) => void;
  submitReview: (review: Omit<Review, "id" | "date" | "demo">) => void;
  markNotificationRead: (id: string) => void;
  pushNotification: (n: Omit<AppNotification, "id" | "time" | "read">) => void;
  withdrawFunds: (amount: number) => void;

  // demo
  demoMode: boolean;
  resetDemo: () => void;
  loadWorkerDemo: () => void;
  loadContractorDemo: () => void;
  bVentureRunning: boolean;
  bVentureStep: number;
  startBVentureDemo: () => void;
  stopBVentureDemo: () => void;

  // toasts
  toasts: ToastMessage[];
  pushToast: (kind: ToastMessage["kind"], message: string) => void;
  dismissToast: (id: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  // THEME
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      return (localStorage.getItem("shram-theme") as ThemeMode) || "dark";
    } catch {
      return "dark";
    }
  });
  const [systemPrefersDark, setSystemPrefersDark] = useState(true);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    setSystemPrefersDark(mq.matches);
    const handler = (e: MediaQueryListEvent) => setSystemPrefersDark(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  const resolvedTheme: "light" | "dark" =
    theme === "system" ? (systemPrefersDark ? "dark" : "light") : theme;

  useEffect(() => {
    const root = document.documentElement;
    if (resolvedTheme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
  }, [resolvedTheme]);

  const setTheme = useCallback((t: ThemeMode) => {
    setThemeState(t);
    try {
      localStorage.setItem("shram-theme", t);
    } catch {
      /* ignore */
    }
  }, []);

  // NAV STACK
  const [stack, setStack] = useState<NavEntry[]>([{ screen: "splash" }]);
  const current = stack[stack.length - 1];

  const navigate = useCallback((screen: Screen, params: Record<string, unknown> = {}) => {
    setStack((s) => [...s, { screen, params }]);
    window.scrollTo({ top: 0 });
  }, []);

  const replace = useCallback((screen: Screen, params: Record<string, unknown> = {}) => {
    setStack((s) => [...s.slice(0, -1), { screen, params }]);
    window.scrollTo({ top: 0 });
  }, []);

  const goBack = useCallback(() => {
    setStack((s) => (s.length > 1 ? s.slice(0, -1) : s));
    window.scrollTo({ top: 0 });
  }, []);

  // ROLE / USER
  const [role, setRole] = useState<Role>(null);
  const [isFirstTime, setIsFirstTime] = useState(true);
  const markOnboarded = useCallback(() => setIsFirstTime(false), []);

  const [workerStats, setWorkerStats] = useState({
    jobsCompleted: WORKERS[0].jobsCompleted,
    shramScore: WORKERS[0].shramScore,
    earningsTotal: WORKERS[0].earningsTotal,
  });

  const currentWorker: Worker = useMemo(
    () => ({ ...WORKERS[0], ...workerStats }),
    [workerStats]
  );

  const currentContractorName = "Suresh Jain";

  // DATA
  const [jobs, setJobs] = useState<JobPosting[]>(JOBS);
  const [workers] = useState<Worker[]>(WORKERS);
  const [reviews, setReviews] = useState<Review[]>(REVIEWS);
  const [notifications, setNotifications] = useState<AppNotification[]>(NOTIFICATIONS_SEED);
  const [transactions, setTransactions] = useState<Transaction[]>(TRANSACTIONS);
  const [walletBalance, setWalletBalance] = useState(32450);

  const [postJobDraft, setPostJobDraftState] = useState<PostJobDraft>({});
  const setPostJobDraft = useCallback((d: Partial<PostJobDraft>) => {
    setPostJobDraftState((prev) => ({ ...prev, ...d }));
  }, []);
  const resetPostJobDraft = useCallback(() => setPostJobDraftState({}), []);

  const [activeJobId, setActiveJobId] = useState<string | null>(null);
  const [matchedWorkerIds, setMatchedWorkerIds] = useState<string[]>([]);

  const pushNotification = useCallback(
    (n: Omit<AppNotification, "id" | "time" | "read">) => {
      setNotifications((prev) => [
        { ...n, id: uid("notif"), time: "Just now", read: false },
        ...prev,
      ]);
    },
    []
  );

  const markNotificationRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  }, []);

  const postJob = useCallback(
    (draft: PostJobDraft) => {
      const cat = draft.category || "electrical";
      const newJob: JobPosting = {
        id: uid("job"),
        title: draft.categoryLabel ? `${draft.categoryLabel} Work` : "New Job",
        category: cat as JobPosting["category"],
        categoryLabel: draft.categoryLabel || "General",
        emoji: draft.emoji || "🛠",
        description: draft.description || "No description provided.",
        location: { x: 50, y: 50, area: draft.areaOverride || "Sardarpura, Jodhpur" },
        distanceKm: Number((Math.random() * 4 + 1).toFixed(1)),
        budgetMin: draft.budget ? Math.round(draft.budget * 0.85) : 1000,
        budgetMax: draft.budget || 1500,
        fixedBudget: draft.budget,
        schedule: draft.schedule || "Tomorrow · 10:00 AM",
        durationEstimate: "Approx. 2–3 hours",
        workersRequired: draft.workersRequired || 1,
        requirements: ["Verified SHRAM professional", "Own tools"],
        status: "matching",
        postedBy: currentContractorName,
        createdAt: Date.now(),
      };
      setJobs((prev) => [newJob, ...prev]);
      setActiveJobId(newJob.id);
      return newJob;
    },
    [currentContractorName]
  );

  const runMatching = useCallback(
    (jobId: string) => {
      const job = jobs.find((j) => j.id === jobId);
      const cat = job?.category;
      const matches = workers
        .filter((w) => w.skill === cat)
        .concat(workers.filter((w) => w.skill !== cat).slice(0, 3))
        .slice(0, 8)
        .map((w) => w.id);
      setMatchedWorkerIds(matches.length ? matches : workers.slice(0, 5).map((w) => w.id));
    },
    [jobs, workers]
  );

  const selectWorkerForJob = useCallback(
    (jobId: string, workerId: string) => {
      setJobs((prev) =>
        prev.map((j) =>
          j.id === jobId ? { ...j, assignedWorkerId: workerId, status: "accepted" } : j
        )
      );
      const w = workers.find((x) => x.id === workerId);
      pushNotification({
        type: "match",
        title: "Worker assigned to your job",
        body: `${w?.name ?? "A professional"} accepted your job request.`,
        target: { screen: "active-job" },
      });
    },
    [pushNotification, workers]
  );

  const advanceJobStatus = useCallback(
    (jobId: string, status: JobStatus) => {
      setJobs((prev) => prev.map((j) => (j.id === jobId ? { ...j, status } : j)));
    },
    []
  );

  const completeJob = useCallback(
    (jobId: string) => {
      setJobs((prev) => prev.map((j) => (j.id === jobId ? { ...j, status: "completed" } : j)));
      pushNotification({
        type: "job",
        title: "Customer confirmed completion",
        body: "Work has been marked as complete. Payment is now processing.",
        target: { screen: "active-job" },
      });
    },
    [pushNotification]
  );

  const releasePayment = useCallback(
    (jobId: string, amount: number) => {
      setJobs((prev) => prev.map((j) => (j.id === jobId ? { ...j, status: "paid" } : j)));
      setTransactions((prev) => [
        {
          id: uid("txn"),
          label: jobs.find((j) => j.id === jobId)?.title || "SHRAM Job",
          amount,
          status: "released",
          date: "Today",
          jobId,
        },
        ...prev,
      ]);
      setWalletBalance((prev) => prev + amount);
      setWorkerStats((prev) => ({
        ...prev,
        jobsCompleted: prev.jobsCompleted + 1,
        earningsTotal: prev.earningsTotal + amount,
        shramScore: Math.min(99, prev.shramScore + 1),
      }));
      pushNotification({
        type: "payment",
        title: `₹${amount.toLocaleString("en-IN")} payment released`,
        body: "Payment has been added to your SHRAM Wallet.",
        target: { screen: "earnings" },
      });
      pushNotification({
        type: "score",
        title: `Your SHRAM Score increased to ${Math.min(99, workerStats.shramScore + 1)}`,
        body: "Great job! Your reliability and on-time rate improved your score.",
        target: { screen: "shram-score" },
      });
    },
    [jobs, pushNotification, workerStats.shramScore]
  );

  const submitReview = useCallback((review: Omit<Review, "id" | "date" | "demo">) => {
    setReviews((prev) => [{ ...review, id: uid("rev"), date: "Just now", demo: true }, ...prev]);
  }, []);

  const withdrawFunds = useCallback(
    (amount: number) => {
      setWalletBalance((prev) => Math.max(0, prev - amount));
      pushToastRef.current?.("info", `Demo withdrawal initiated — ₹${amount.toLocaleString("en-IN")} · Processing`);
    },
    []
  );

  // TOASTS
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const pushToast = useCallback((kind: ToastMessage["kind"], message: string) => {
    const id = uid("toast");
    setToasts((prev) => [...prev, { id, kind, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3400);
  }, []);
  const pushToastRef = useRef(pushToast);
  pushToastRef.current = pushToast;

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // DEMO MODE
  const demoMode = true;

  const resetDemo = useCallback(() => {
    setJobs(JOBS);
    setReviews(REVIEWS);
    setNotifications(NOTIFICATIONS_SEED);
    setTransactions(TRANSACTIONS);
    setWalletBalance(32450);
    setWorkerStats({
      jobsCompleted: WORKERS[0].jobsCompleted,
      shramScore: WORKERS[0].shramScore,
      earningsTotal: WORKERS[0].earningsTotal,
    });
    setActiveJobId(null);
    setMatchedWorkerIds([]);
    setPostJobDraftState({});
    setStack([{ screen: "splash" }]);
    setRole(null);
    setIsFirstTime(true);
    pushToast("success", "Demo environment reset successfully.");
  }, [pushToast]);

  const loadWorkerDemo = useCallback(() => {
    setRole("worker");
    setIsFirstTime(false);
    setStack([{ screen: "worker-home" }]);
  }, []);

  const loadContractorDemo = useCallback(() => {
    setRole("contractor");
    setIsFirstTime(false);
    setStack([{ screen: "contractor-home" }]);
  }, []);

  const [bVentureRunning, setBVentureRunning] = useState(false);
  const [bVentureStep, setBVentureStep] = useState(0);

  const startBVentureDemo = useCallback(() => {
    setBVentureRunning(true);
    setBVentureStep(0);
  }, []);
  const stopBVentureDemo = useCallback(() => {
    setBVentureRunning(false);
    setBVentureStep(0);
  }, []);

  const value: AppContextValue = {
    theme,
    resolvedTheme,
    setTheme,
    screen: current.screen,
    params: current.params || {},
    navigate,
    goBack,
    canGoBack: stack.length > 1,
    replace,
    role,
    setRole,
    currentWorker,
    currentContractorName,
    isFirstTime,
    markOnboarded,
    jobs,
    workers,
    reviews,
    notifications,
    transactions,
    walletBalance,
    postJobDraft,
    setPostJobDraft,
    resetPostJobDraft,
    activeJobId,
    setActiveJobId,
    matchedWorkerIds,
    postJob,
    runMatching,
    selectWorkerForJob,
    advanceJobStatus,
    completeJob,
    releasePayment,
    submitReview,
    markNotificationRead,
    pushNotification,
    withdrawFunds,
    demoMode,
    resetDemo,
    loadWorkerDemo,
    loadContractorDemo,
    bVentureRunning,
    bVentureStep,
    startBVentureDemo,
    stopBVentureDemo,
    toasts,
    pushToast,
    dismissToast,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
