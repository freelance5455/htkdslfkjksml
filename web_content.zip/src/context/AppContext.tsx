import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  buildBackupPackage,
  type DatabaseSnapshot,
  generateId,
  loadFullSnapshot,
  restoreFullBackup,
  runTransactionalWrites,
  type StoreName,
  type TransactionalWriteOp,
} from '../db/indexedDb';
import { DEFAULT_SETTINGS, DEFAULT_THEME } from '../db/defaults';
import {
  calculatePersonLoanSummary,
  evaluateRecordValues,
  validateRepaymentAmount,
} from '../engine/calculations';
import { extractReferencedFields } from '../engine/formulaParser';
import type {
  ActiveNavRoute,
  AppSettings,
  AuditAction,
  AuditLogEntry,
  BackupPackage,
  Committee,
  CommitteeTransaction,
  CustomModule,
  CustomRecord,
  CustomReportConfig,
  CustomSubmodule,
  DashboardCardConfig,
  FieldDefinition,
  FieldMapping,
  FormulaDefinition,
  LoanPerson,
  LoanTransaction,
  MasterList,
  RecycleBinItem,
  RecycleEntityType,
} from '../types/app';

export interface ActionResult<T = void> {
  ok: boolean;
  error?: string;
  data?: T;
}

interface AppContextValue {
  loading: boolean;
  error: string | null;
  activeRoute: ActiveNavRoute;
  setActiveRoute: (route: ActiveNavRoute) => void;
  settingsSection: string;
  setSettingsSection: (section: string) => void;
  toastMessage: { text: string; type: 'success' | 'error' | 'info' } | null;
  notify: (text: string, type?: 'success' | 'error' | 'info') => void;
  snapshot: DatabaseSnapshot;
  reload: () => Promise<void>;

  // Loan Operations
  saveLoanPerson: (input: Omit<LoanPerson, 'id' | 'createdAt' | 'updatedAt' | 'archived'> & { id?: string }) => Promise<ActionResult<LoanPerson>>;
  deleteLoanPerson: (personId: string) => Promise<ActionResult>;
  saveLoanTransaction: (
    input: Omit<LoanTransaction, 'id' | 'createdAt' | 'updatedAt'> & { id?: string },
    options?: { allowOverpayment?: boolean; allowDuplicate?: boolean }
  ) => Promise<ActionResult<LoanTransaction>>;
  deleteLoanTransaction: (txId: string) => Promise<ActionResult>;

  // Committee Operations
  saveCommittee: (input: Omit<Committee, 'id' | 'createdAt' | 'updatedAt' | 'archived'> & { id?: string }) => Promise<ActionResult<Committee>>;
  deleteCommittee: (committeeId: string) => Promise<ActionResult>;
  saveCommitteeTransaction: (
    input: Omit<CommitteeTransaction, 'id' | 'createdAt' | 'updatedAt'> & { id?: string },
    options?: { allowDuplicate?: boolean }
  ) => Promise<ActionResult<CommitteeTransaction>>;
  deleteCommitteeTransaction: (txId: string) => Promise<ActionResult>;

  // Dynamic Builder: Modules & Submodules
  saveModule: (input: Omit<CustomModule, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<ActionResult<CustomModule>>;
  deleteModule: (moduleId: string) => Promise<ActionResult>;
  saveSubmodule: (input: Omit<CustomSubmodule, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<ActionResult<CustomSubmodule>>;
  deleteSubmodule: (submoduleId: string) => Promise<ActionResult>;

  // Dynamic Builder: Fields, Master Lists, Formulas, Mappings
  saveField: (input: Omit<FieldDefinition, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<ActionResult<FieldDefinition>>;
  deleteField: (fieldId: string) => Promise<ActionResult>;
  saveMasterList: (input: Omit<MasterList, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<ActionResult<MasterList>>;
  deleteMasterList: (listId: string) => Promise<ActionResult>;
  saveFormula: (input: Omit<FormulaDefinition, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<ActionResult<FormulaDefinition>>;
  deleteFormula: (formulaId: string) => Promise<ActionResult>;
  saveFieldMapping: (input: Omit<FieldMapping, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<ActionResult<FieldMapping>>;
  deleteFieldMapping: (mappingId: string) => Promise<ActionResult>;

  // Custom Module Records
  saveCustomRecord: (input: { id?: string; moduleId: string; submoduleId: string; values: Record<string, unknown>; archived?: boolean }) => Promise<ActionResult<CustomRecord>>;
  toggleArchiveCustomRecord: (recordId: string, archived: boolean) => Promise<ActionResult>;
  deleteCustomRecord: (recordId: string) => Promise<ActionResult>;

  // Dashboard Cards & Reports
  saveDashboardCard: (input: Omit<DashboardCardConfig, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<ActionResult<DashboardCardConfig>>;
  deleteDashboardCard: (cardId: string) => Promise<ActionResult>;
  saveReport: (input: Omit<CustomReportConfig, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<ActionResult<CustomReportConfig>>;
  deleteReport: (reportId: string) => Promise<ActionResult>;

  // Settings & Theme
  updateSettings: (next: Partial<AppSettings>) => Promise<ActionResult>;
  resetTheme: () => Promise<ActionResult>;

  // Recycle Bin & Backup
  restoreFromRecycleBin: (binId: string) => Promise<ActionResult>;
  purgeFromRecycleBin: (binIds: string[]) => Promise<ActionResult>;
  exportBackupPackage: () => Promise<BackupPackage>;
  restoreBackupPackage: (pkg: BackupPackage) => Promise<ActionResult>;
}

const EMPTY_SNAPSHOT: DatabaseSnapshot = {
  loanPersons: [],
  loanTransactions: [],
  committees: [],
  committeeTransactions: [],
  modules: [],
  submodules: [],
  fields: [],
  masterLists: [],
  formulas: [],
  fieldMappings: [],
  customRecords: [],
  dashboardCards: [],
  reports: [],
  settings: DEFAULT_SETTINGS,
  auditLogs: [],
  recycleBin: [],
};

const AppContext = createContext<AppContextValue | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [snapshot, setSnapshot] = useState<DatabaseSnapshot>(EMPTY_SNAPSHOT);
  const [activeRoute, setActiveRoute] = useState<ActiveNavRoute>('dashboard');
  const [settingsSection, setSettingsSection] = useState<string>('general');
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  const notify = useCallback((text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage({ text, type });
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const t = setTimeout(() => setToastMessage(null), 4000);
    return () => clearTimeout(t);
  }, [toastMessage]);

  const applyThemeVars = useCallback((settings: AppSettings) => {
    const t = settings.theme || DEFAULT_THEME;
    const root = document.documentElement;
    root.style.setProperty('--theme-primary', t.primaryColor);
    root.style.setProperty('--theme-secondary', t.secondaryColor);
    root.style.setProperty('--theme-bg', t.backgroundColor);
    root.style.setProperty('--theme-card', t.cardColor);
    root.style.setProperty('--theme-sidebar', t.sidebarColor);
    root.style.setProperty('--theme-text', t.textColor);
    root.style.setProperty('--theme-button', t.buttonColor);
  }, []);

  const reload = useCallback(async () => {
    try {
      const data = await loadFullSnapshot();
      setSnapshot(data);
      applyThemeVars(data.settings);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load IndexedDB');
    } finally {
      setLoading(false);
    }
  }, [applyThemeVars]);

  useEffect(() => {
    reload();
  }, [reload]);

  const makeAudit = (
    action: AuditAction,
    entityType: string,
    entityId: string,
    summary: string,
    details?: string
  ): AuditLogEntry => ({
    id: generateId('audit'),
    timestamp: new Date().toISOString(),
    action,
    entityType,
    entityId,
    summary,
    details,
  });

  const makeRecycleItem = (
    entityType: RecycleEntityType,
    originalId: string,
    label: string,
    payload: unknown
  ): RecycleBinItem => ({
    id: generateId('bin'),
    entityType,
    originalId,
    label,
    payload,
    deletedAt: new Date().toISOString(),
  });

  // --- LOANS ---
  const saveLoanPerson: AppContextValue['saveLoanPerson'] = async (input) => {
    const name = input.name.trim();
    if (!name) return { ok: false, error: 'Person name is required.' };
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.loanPersons.find((p) => p.id === input.id) : undefined;
    const duplicate = snapshot.loanPersons.find(
      (p) => !p.archived && p.id !== input.id && p.name.trim().toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      return { ok: false, error: `A person named "${name}" already exists.` };
    }
    const person: LoanPerson = {
      id: existing?.id || generateId('lp'),
      name,
      contactNumber: input.contactNumber.trim(),
      openingBalance: Number(input.openingBalance) || 0,
      remarks: input.remarks.trim(),
      archived: existing?.archived ?? false,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    const audit = makeAudit(
      existing ? 'RECORD_EDITED' : 'RECORD_CREATED',
      'LoanPerson',
      person.id,
      `${existing ? 'Updated' : 'Added'} loan person: ${person.name}`
    );
    await runTransactionalWrites([
      { store: 'loanPersons', type: 'put', value: person },
      { store: 'auditLogs', type: 'put', value: audit },
    ]);
    await reload();
    return { ok: true, data: person };
  };

  const deleteLoanPerson: AppContextValue['deleteLoanPerson'] = async (personId) => {
    const person = snapshot.loanPersons.find((p) => p.id === personId);
    if (!person) return { ok: false, error: 'Person not found.' };
    const linkedTx = snapshot.loanTransactions.filter((t) => t.personId === personId);
    const ops: TransactionalWriteOp[] = [
      { store: 'loanPersons', type: 'delete', key: personId },
      { store: 'recycleBin', type: 'put', value: makeRecycleItem('loanPerson', personId, person.name, { person, transactions: linkedTx }) },
      { store: 'auditLogs', type: 'put', value: makeAudit('RECORD_DELETED', 'LoanPerson', personId, `Deleted loan person: ${person.name}`) },
    ];
    for (const tx of linkedTx) {
      ops.push({ store: 'loanTransactions', type: 'delete', key: tx.id });
    }
    await runTransactionalWrites(ops);
    await reload();
    return { ok: true };
  };

  const saveLoanTransaction: AppContextValue['saveLoanTransaction'] = async (input, options) => {
    const person = snapshot.loanPersons.find((p) => p.id === input.personId);
    if (!person) return { ok: false, error: 'Please select a valid person.' };
    const amount = Number(input.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      return { ok: false, error: 'Amount must be greater than zero.' };
    }
    if (!input.date) return { ok: false, error: 'Transaction date is required.' };

    // Overpayment protection on repayments
    if (input.type === 'repayment') {
      const txsExcludingCurrent = snapshot.loanTransactions.filter((t) => t.id !== input.id);
      const personSummary = calculatePersonLoanSummary(person, txsExcludingCurrent);
      const check = validateRepaymentAmount(personSummary.closingPayable, amount, options?.allowOverpayment);
      if (!check.valid) return { ok: false, error: check.error };
    }

    // Accidental duplicate guard
    if (!input.id && !options?.allowDuplicate) {
      const dup = snapshot.loanTransactions.find(
        (t) =>
          t.personId === input.personId &&
          t.type === input.type &&
          Number(t.amount) === amount &&
          t.date === input.date &&
          (t.transactionRef || '') === (input.transactionRef || '')
      );
      if (dup) {
        return {
          ok: false,
          error: 'Duplicate transaction detected (same person, type, date, and amount). Confirm if intentional.',
        };
      }
    }

    const now = new Date().toISOString();
    const existing = input.id ? snapshot.loanTransactions.find((t) => t.id === input.id) : undefined;
    const tx: LoanTransaction = {
      id: existing?.id || generateId('ltx'),
      personId: input.personId,
      type: input.type,
      amount,
      date: input.date,
      description: input.description.trim(),
      paymentMethod: input.paymentMethod?.trim() || '',
      transactionRef: input.transactionRef?.trim() || '',
      remarks: input.remarks.trim(),
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };

    await runTransactionalWrites([
      { store: 'loanTransactions', type: 'put', value: tx },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit(
          existing ? 'RECORD_EDITED' : 'RECORD_CREATED',
          'LoanTransaction',
          tx.id,
          `${existing ? 'Edited' : 'Recorded'} ${tx.type === 'received' ? 'Loan Received' : 'Loan Repayment'} of ${amount} for ${person.name}`
        ),
      },
    ]);
    await reload();
    return { ok: true, data: tx };
  };

  const deleteLoanTransaction: AppContextValue['deleteLoanTransaction'] = async (txId) => {
    const tx = snapshot.loanTransactions.find((t) => t.id === txId);
    if (!tx) return { ok: false, error: 'Transaction not found.' };
    const person = snapshot.loanPersons.find((p) => p.id === tx.personId);
    await runTransactionalWrites([
      { store: 'loanTransactions', type: 'delete', key: txId },
      { store: 'recycleBin', type: 'put', value: makeRecycleItem('loanTransaction', txId, `${tx.type} (${tx.amount}) - ${person?.name || ''}`, tx) },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit('RECORD_DELETED', 'LoanTransaction', txId, `Deleted loan ${tx.type} (${tx.amount}) for ${person?.name || 'Unknown'}`),
      },
    ]);
    await reload();
    return { ok: true };
  };

  // --- COMMITTEES ---
  const saveCommittee: AppContextValue['saveCommittee'] = async (input) => {
    const name = input.name.trim();
    const personName = input.personName.trim();
    if (!name || !personName) return { ok: false, error: 'Committee name and person name are required.' };
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.committees.find((c) => c.id === input.id) : undefined;
    const committee: Committee = {
      id: existing?.id || generateId('com'),
      name,
      personName,
      openingBalance: Number(input.openingBalance) || 0,
      totalCommitteeAmount: Number(input.totalCommitteeAmount) || 0,
      installmentAmount: Number(input.installmentAmount) || 0,
      startDate: input.startDate,
      endDate: input.endDate,
      paymentFrequency: input.paymentFrequency,
      remarks: input.remarks.trim(),
      archived: existing?.archived ?? false,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    await runTransactionalWrites([
      { store: 'committees', type: 'put', value: committee },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit(existing ? 'RECORD_EDITED' : 'RECORD_CREATED', 'Committee', committee.id, `${existing ? 'Updated' : 'Created'} committee: ${committee.name}`),
      },
    ]);
    await reload();
    return { ok: true, data: committee };
  };

  const deleteCommittee: AppContextValue['deleteCommittee'] = async (committeeId) => {
    const comm = snapshot.committees.find((c) => c.id === committeeId);
    if (!comm) return { ok: false, error: 'Committee not found.' };
    const linkedTx = snapshot.committeeTransactions.filter((t) => t.committeeId === committeeId);
    const ops: TransactionalWriteOp[] = [
      { store: 'committees', type: 'delete', key: committeeId },
      { store: 'recycleBin', type: 'put', value: makeRecycleItem('committee', committeeId, comm.name, { committee: comm, transactions: linkedTx }) },
      { store: 'auditLogs', type: 'put', value: makeAudit('RECORD_DELETED', 'Committee', committeeId, `Deleted committee: ${comm.name}`) },
    ];
    for (const tx of linkedTx) {
      ops.push({ store: 'committeeTransactions', type: 'delete', key: tx.id });
    }
    await runTransactionalWrites(ops);
    await reload();
    return { ok: true };
  };

  const saveCommitteeTransaction: AppContextValue['saveCommitteeTransaction'] = async (input, options) => {
    const comm = snapshot.committees.find((c) => c.id === input.committeeId);
    if (!comm) return { ok: false, error: 'Select a valid committee.' };
    const amount = Number(input.amount);
    if (!Number.isFinite(amount) || amount <= 0) return { ok: false, error: 'Amount must be greater than zero.' };
    if (!input.date) return { ok: false, error: 'Date is required.' };

    if (!input.id && !options?.allowDuplicate) {
      const dup = snapshot.committeeTransactions.find(
        (t) =>
          t.committeeId === input.committeeId &&
          t.type === input.type &&
          Number(t.amount) === amount &&
          t.date === input.date &&
          t.personName.trim().toLowerCase() === input.personName.trim().toLowerCase()
      );
      if (dup) {
        return { ok: false, error: 'Duplicate committee transaction detected for same date and amount.' };
      }
    }

    const now = new Date().toISOString();
    const existing = input.id ? snapshot.committeeTransactions.find((t) => t.id === input.id) : undefined;
    const tx: CommitteeTransaction = {
      id: existing?.id || generateId('ctx'),
      committeeId: input.committeeId,
      personName: input.personName.trim() || comm.personName,
      type: input.type,
      amount,
      date: input.date,
      paymentMethod: input.paymentMethod?.trim() || '',
      paymentRef: input.paymentRef?.trim() || '',
      remarks: input.remarks.trim(),
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };

    await runTransactionalWrites([
      { store: 'committeeTransactions', type: 'put', value: tx },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit(
          existing ? 'RECORD_EDITED' : 'RECORD_CREATED',
          'CommitteeTransaction',
          tx.id,
          `${existing ? 'Updated' : 'Recorded'} committee ${tx.type} (${amount}) in ${comm.name}`
        ),
      },
    ]);
    await reload();
    return { ok: true, data: tx };
  };

  const deleteCommitteeTransaction: AppContextValue['deleteCommitteeTransaction'] = async (txId) => {
    const tx = snapshot.committeeTransactions.find((t) => t.id === txId);
    if (!tx) return { ok: false, error: 'Transaction not found.' };
    const comm = snapshot.committees.find((c) => c.id === tx.committeeId);
    await runTransactionalWrites([
      { store: 'committeeTransactions', type: 'delete', key: txId },
      { store: 'recycleBin', type: 'put', value: makeRecycleItem('committeeTransaction', txId, `${tx.type} (${tx.amount}) - ${comm?.name || ''}`, tx) },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit('RECORD_DELETED', 'CommitteeTransaction', txId, `Deleted committee ${tx.type} (${tx.amount})`),
      },
    ]);
    await reload();
    return { ok: true };
  };

  // --- DYNAMIC MODULES & SUBMODULES ---
  const saveModule: AppContextValue['saveModule'] = async (input) => {
    const name = input.name.trim();
    if (!name) return { ok: false, error: 'Module name is required.' };
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.modules.find((m) => m.id === input.id) : undefined;
    const mod: CustomModule = {
      id: existing?.id || generateId('mod'),
      name,
      description: input.description.trim(),
      icon: input.icon || 'FolderKanban',
      color: input.color || '#059669',
      position: Number.isFinite(input.position) ? input.position : snapshot.modules.length,
      visible: input.visible,
      archived: input.archived,
      status: input.status,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    await runTransactionalWrites([
      { store: 'modules', type: 'put', value: mod },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit(existing ? 'MODULE_UPDATED' : 'MODULE_CREATED', 'CustomModule', mod.id, `${existing ? 'Updated' : 'Created'} module: ${mod.name}`),
      },
    ]);
    await reload();
    return { ok: true, data: mod };
  };

  const deleteModule: AppContextValue['deleteModule'] = async (moduleId) => {
    const mod = snapshot.modules.find((m) => m.id === moduleId);
    if (!mod) return { ok: false, error: 'Module not found.' };
    const subs = snapshot.submodules.filter((s) => s.moduleId === moduleId);
    const flds = snapshot.fields.filter((f) => f.moduleId === moduleId);
    const recs = snapshot.customRecords.filter((r) => r.moduleId === moduleId);
    const ops: TransactionalWriteOp[] = [
      { store: 'modules', type: 'delete', key: moduleId },
      { store: 'recycleBin', type: 'put', value: makeRecycleItem('module', moduleId, mod.name, { module: mod, submodules: subs, fields: flds, records: recs }) },
      { store: 'auditLogs', type: 'put', value: makeAudit('MODULE_DELETED', 'CustomModule', moduleId, `Deleted module: ${mod.name}`) },
    ];
    subs.forEach((s) => ops.push({ store: 'submodules', type: 'delete', key: s.id }));
    flds.forEach((f) => ops.push({ store: 'fields', type: 'delete', key: f.id }));
    recs.forEach((r) => ops.push({ store: 'customRecords', type: 'delete', key: r.id }));
    await runTransactionalWrites(ops);
    if (activeRoute === `module:${moduleId}`) setActiveRoute('dashboard');
    await reload();
    return { ok: true };
  };

  const saveSubmodule: AppContextValue['saveSubmodule'] = async (input) => {
    const name = input.name.trim();
    if (!name || !input.moduleId) return { ok: false, error: 'Parent module and submodule name are required.' };
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.submodules.find((s) => s.id === input.id) : undefined;
    const sub: CustomSubmodule = {
      id: existing?.id || generateId('sub'),
      moduleId: input.moduleId,
      name,
      icon: input.icon || 'FileText',
      color: input.color || '#0B1F3A',
      position: Number.isFinite(input.position) ? input.position : snapshot.submodules.filter((s) => s.moduleId === input.moduleId).length,
      visible: input.visible,
      archived: input.archived,
      status: input.status,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    await runTransactionalWrites([
      { store: 'submodules', type: 'put', value: sub },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit(existing ? 'SUBMODULE_UPDATED' : 'SUBMODULE_CREATED', 'CustomSubmodule', sub.id, `${existing ? 'Updated' : 'Created'} submodule: ${sub.name}`),
      },
    ]);
    await reload();
    return { ok: true, data: sub };
  };

  const deleteSubmodule: AppContextValue['deleteSubmodule'] = async (submoduleId) => {
    const sub = snapshot.submodules.find((s) => s.id === submoduleId);
    if (!sub) return { ok: false, error: 'Submodule not found.' };
    const flds = snapshot.fields.filter((f) => f.submoduleId === submoduleId);
    const recs = snapshot.customRecords.filter((r) => r.submoduleId === submoduleId);
    const ops: TransactionalWriteOp[] = [
      { store: 'submodules', type: 'delete', key: submoduleId },
      { store: 'recycleBin', type: 'put', value: makeRecycleItem('submodule', submoduleId, sub.name, { submodule: sub, fields: flds, records: recs }) },
      { store: 'auditLogs', type: 'put', value: makeAudit('SUBMODULE_DELETED', 'CustomSubmodule', submoduleId, `Deleted submodule: ${sub.name}`) },
    ];
    flds.forEach((f) => ops.push({ store: 'fields', type: 'delete', key: f.id }));
    recs.forEach((r) => ops.push({ store: 'customRecords', type: 'delete', key: r.id }));
    await runTransactionalWrites(ops);
    await reload();
    return { ok: true };
  };

  // --- FIELDS, MASTER LISTS, FORMULAS, MAPPINGS ---
  const saveField: AppContextValue['saveField'] = async (input) => {
    const name = input.name.trim();
    const label = (input.label || name).trim();
    if (!name || !input.moduleId || !input.submoduleId) {
      return { ok: false, error: 'Module, Submodule, and Field Name are required.' };
    }
    const duplicate = snapshot.fields.find(
      (f) =>
        f.id !== input.id &&
        f.submoduleId === input.submoduleId &&
        f.name.toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      return { ok: false, error: `A field named "${name}" already exists in this submodule.` };
    }
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.fields.find((f) => f.id === input.id) : undefined;
    const field: FieldDefinition = {
      ...input,
      id: existing?.id || generateId('fld'),
      name,
      label,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    await runTransactionalWrites([
      { store: 'fields', type: 'put', value: field },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit(existing ? 'FIELD_UPDATED' : 'FIELD_CREATED', 'FieldDefinition', field.id, `${existing ? 'Updated' : 'Created'} field: ${field.label} (${field.type})`),
      },
    ]);
    await reload();
    return { ok: true, data: field };
  };

  const deleteField: AppContextValue['deleteField'] = async (fieldId) => {
    const field = snapshot.fields.find((f) => f.id === fieldId);
    if (!field) return { ok: false, error: 'Field not found.' };

    // Dependency protection check!
    const dependentFormulas = snapshot.formulas.filter((fm) => {
      if (fm.targetFieldId === fieldId) return false;
      const { fields: refs } = extractReferencedFields(fm.expression);
      return refs.some((r) => r.toLowerCase() === field.name.toLowerCase() || r.toLowerCase() === field.label.toLowerCase() || r.toLowerCase().endsWith(`.${field.name.toLowerCase()}`));
    });
    const dependentFieldFormulas = snapshot.fields.filter((other) => {
      if (other.id === fieldId || other.type !== 'formula' || !other.formulaExpression) return false;
      const { fields: refs } = extractReferencedFields(other.formulaExpression);
      return refs.some((r) => r.toLowerCase() === field.name.toLowerCase() || r.toLowerCase() === field.label.toLowerCase());
    });
    const dependentMappings = snapshot.fieldMappings.filter(
      (m) => m.sourceFieldId === fieldId || m.destFieldId === fieldId
    );
    const dependentCards = snapshot.dashboardCards.filter((c) => c.fieldId === fieldId);

    const blockers: string[] = [];
    if (dependentFormulas.length > 0 || dependentFieldFormulas.length > 0) {
      blockers.push(`Formula(s): ${[...dependentFormulas.map((x) => x.name), ...dependentFieldFormulas.map((x) => x.label)].join(', ')}`);
    }
    if (dependentMappings.length > 0) {
      blockers.push(`Field Mapping(s): ${dependentMappings.map((m) => m.name).join(', ')}`);
    }
    if (dependentCards.length > 0) {
      blockers.push(`Dashboard Card(s): ${dependentCards.map((c) => c.title).join(', ')}`);
    }
    if (blockers.length > 0) {
      return {
        ok: false,
        error: `Cannot delete "${field.label}" because it is referenced by:\n${blockers.join('\n')}\nRemove those dependencies first.`,
      };
    }

    const linkedFormulas = snapshot.formulas.filter((fm) => fm.targetFieldId === fieldId);
    const ops: TransactionalWriteOp[] = [
      { store: 'fields', type: 'delete', key: fieldId },
      { store: 'recycleBin', type: 'put', value: makeRecycleItem('field', fieldId, field.label, field) },
      { store: 'auditLogs', type: 'put', value: makeAudit('FIELD_DELETED', 'FieldDefinition', fieldId, `Deleted field: ${field.label}`) },
    ];
    linkedFormulas.forEach((fm) => ops.push({ store: 'formulas', type: 'delete', key: fm.id }));
    await runTransactionalWrites(ops);
    await reload();
    return { ok: true };
  };

  const saveMasterList: AppContextValue['saveMasterList'] = async (input) => {
    const name = input.name.trim();
    if (!name) return { ok: false, error: 'Master list name is required.' };
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.masterLists.find((l) => l.id === input.id) : undefined;
    const list: MasterList = {
      id: existing?.id || generateId('ml'),
      name,
      description: input.description.trim(),
      options: input.options,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    await runTransactionalWrites([
      { store: 'masterLists', type: 'put', value: list },
      { store: 'auditLogs', type: 'put', value: makeAudit(existing ? 'RECORD_EDITED' : 'RECORD_CREATED', 'MasterList', list.id, `${existing ? 'Updated' : 'Created'} dropdown master list: ${list.name}`) },
    ]);
    await reload();
    return { ok: true, data: list };
  };

  const deleteMasterList: AppContextValue['deleteMasterList'] = async (listId) => {
    const linked = snapshot.fields.filter((f) => f.masterListId === listId);
    if (linked.length > 0) {
      return {
        ok: false,
        error: `Cannot delete master list because it is linked to field(s): ${linked.map((f) => f.label).join(', ')}`,
      };
    }
    await runTransactionalWrites([
      { store: 'masterLists', type: 'delete', key: listId },
      { store: 'auditLogs', type: 'put', value: makeAudit('RECORD_DELETED', 'MasterList', listId, `Deleted master list`) },
    ]);
    await reload();
    return { ok: true };
  };

  const saveFormula: AppContextValue['saveFormula'] = async (input) => {
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.formulas.find((f) => f.id === input.id) : undefined;
    const fm: FormulaDefinition = {
      ...input,
      id: existing?.id || generateId('fm'),
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };

    const ops: TransactionalWriteOp[] = [{ store: 'formulas', type: 'put', value: fm }];
    const targetField = snapshot.fields.find((f) => f.id === fm.targetFieldId);
    if (targetField) {
      ops.push({
        store: 'fields',
        type: 'put',
        value: {
          ...targetField,
          formulaExpression: fm.expression,
          decimalPlaces: fm.decimalPlaces,
          status: fm.status,
          updatedAt: now,
        },
      });
    }

    // Recalculate existing saved records in this submodule when formula changes
    if (fm.status === 'published') {
      const nextFormulas = existing
        ? snapshot.formulas.map((x) => (x.id === fm.id ? fm : x))
        : [...snapshot.formulas, fm];
      const nextFields = targetField
        ? snapshot.fields.map((f) =>
            f.id === targetField.id ? { ...f, formulaExpression: fm.expression, decimalPlaces: fm.decimalPlaces } : f
          )
        : snapshot.fields;

      for (const rec of snapshot.customRecords) {
        if (rec.submoduleId === fm.submoduleId && !rec.archived) {
          const evalRes = evaluateRecordValues({
            submoduleId: rec.submoduleId,
            rawValues: rec.values,
            fields: nextFields,
            formulas: nextFormulas,
            mappings: snapshot.fieldMappings,
            allRecords: snapshot.customRecords,
            modules: snapshot.modules,
            submodules: snapshot.submodules,
          });
          ops.push({
            store: 'customRecords',
            type: 'put',
            value: { ...rec, values: evalRes.values, updatedAt: now },
          });
        }
      }
    }

    ops.push({
      store: 'auditLogs',
      type: 'put',
      value: makeAudit('FORMULA_CHANGED', 'FormulaDefinition', fm.id, `Saved formula "${fm.name}": ${fm.expression}`),
    });

    await runTransactionalWrites(ops);
    await reload();
    return { ok: true, data: fm };
  };

  const deleteFormula: AppContextValue['deleteFormula'] = async (formulaId) => {
    await runTransactionalWrites([
      { store: 'formulas', type: 'delete', key: formulaId },
      { store: 'auditLogs', type: 'put', value: makeAudit('FORMULA_CHANGED', 'FormulaDefinition', formulaId, `Deleted formula`) },
    ]);
    await reload();
    return { ok: true };
  };

  const saveFieldMapping: AppContextValue['saveFieldMapping'] = async (input) => {
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.fieldMappings.find((m) => m.id === input.id) : undefined;
    const mapping: FieldMapping = {
      ...input,
      id: existing?.id || generateId('map'),
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    await runTransactionalWrites([
      { store: 'fieldMappings', type: 'put', value: mapping },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit('MAPPING_CHANGED', 'FieldMapping', mapping.id, `Saved field mapping "${mapping.name}"`),
      },
    ]);
    await reload();
    return { ok: true, data: mapping };
  };

  const deleteFieldMapping: AppContextValue['deleteFieldMapping'] = async (mappingId) => {
    await runTransactionalWrites([
      { store: 'fieldMappings', type: 'delete', key: mappingId },
      { store: 'auditLogs', type: 'put', value: makeAudit('MAPPING_CHANGED', 'FieldMapping', mappingId, `Deleted field mapping`) },
    ]);
    await reload();
    return { ok: true };
  };

  // --- CUSTOM RECORDS ---
  const saveCustomRecord: AppContextValue['saveCustomRecord'] = async (input) => {
    const subFields = snapshot.fields.filter((f) => f.submoduleId === input.submoduleId && f.visible);
    for (const f of subFields) {
      if (f.required && f.type !== 'formula' && f.type !== 'checkbox') {
        const val = input.values[f.name];
        if (val === undefined || val === null || String(val).trim() === '') {
          return { ok: false, error: `Field "${f.label}" is required.` };
        }
      }
      if ((f.type === 'number' || f.type === 'currency' || f.type === 'percentage') && input.values[f.name] !== '' && input.values[f.name] !== undefined) {
        const n = Number(input.values[f.name]);
        if (Number.isNaN(n)) return { ok: false, error: `Field "${f.label}" must be a valid number.` };
        if (f.minValue !== undefined && n < f.minValue) {
          return { ok: false, error: `Field "${f.label}" cannot be less than ${f.minValue}.` };
        }
        if (f.maxValue !== undefined && n > f.maxValue) {
          return { ok: false, error: `Field "${f.label}" cannot exceed ${f.maxValue}.` };
        }
      }
    }

    const evalRes = evaluateRecordValues({
      submoduleId: input.submoduleId,
      rawValues: input.values,
      fields: snapshot.fields,
      formulas: snapshot.formulas,
      mappings: snapshot.fieldMappings,
      allRecords: snapshot.customRecords,
      modules: snapshot.modules,
      submodules: snapshot.submodules,
    });

    const firstErr = Object.entries(evalRes.errors)[0];
    if (firstErr) {
      return { ok: false, error: `Formula error in ${firstErr[0]}: ${firstErr[1]}` };
    }

    const now = new Date().toISOString();
    const existing = input.id ? snapshot.customRecords.find((r) => r.id === input.id) : undefined;
    const rec: CustomRecord = {
      id: existing?.id || generateId('rec'),
      moduleId: input.moduleId,
      submoduleId: input.submoduleId,
      values: evalRes.values,
      archived: input.archived ?? existing?.archived ?? false,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };

    await runTransactionalWrites([
      { store: 'customRecords', type: 'put', value: rec },
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit(existing ? 'RECORD_EDITED' : 'RECORD_CREATED', 'CustomRecord', rec.id, `${existing ? 'Updated' : 'Created'} custom record`),
      },
    ]);
    await reload();
    return { ok: true, data: rec };
  };

  const toggleArchiveCustomRecord: AppContextValue['toggleArchiveCustomRecord'] = async (recordId, archived) => {
    const rec = snapshot.customRecords.find((r) => r.id === recordId);
    if (!rec) return { ok: false, error: 'Record not found.' };
    await runTransactionalWrites([
      { store: 'customRecords', type: 'put', value: { ...rec, archived, updatedAt: new Date().toISOString() } },
      { store: 'auditLogs', type: 'put', value: makeAudit(archived ? 'RECORD_ARCHIVED' : 'RECORD_RESTORED', 'CustomRecord', recordId, `${archived ? 'Archived' : 'Unarchived'} custom record`) },
    ]);
    await reload();
    return { ok: true };
  };

  const deleteCustomRecord: AppContextValue['deleteCustomRecord'] = async (recordId) => {
    const rec = snapshot.customRecords.find((r) => r.id === recordId);
    if (!rec) return { ok: false, error: 'Record not found.' };
    await runTransactionalWrites([
      { store: 'customRecords', type: 'delete', key: recordId },
      { store: 'recycleBin', type: 'put', value: makeRecycleItem('customRecord', recordId, `Custom Record (${recordId.slice(-6)})`, rec) },
      { store: 'auditLogs', type: 'put', value: makeAudit('RECORD_DELETED', 'CustomRecord', recordId, `Deleted custom record to Recycle Bin`) },
    ]);
    await reload();
    return { ok: true };
  };

  // --- DASHBOARD CARDS & REPORTS ---
  const saveDashboardCard: AppContextValue['saveDashboardCard'] = async (input) => {
    const title = input.title.trim();
    if (!title) return { ok: false, error: 'Card title is required.' };
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.dashboardCards.find((c) => c.id === input.id) : undefined;
    const card: DashboardCardConfig = {
      ...input,
      id: existing?.id || generateId('card'),
      title,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    await runTransactionalWrites([
      { store: 'dashboardCards', type: 'put', value: card },
      { store: 'auditLogs', type: 'put', value: makeAudit('CARD_CHANGED', 'DashboardCard', card.id, `${existing ? 'Updated' : 'Created'} dashboard card: ${card.title}`) },
    ]);
    await reload();
    return { ok: true, data: card };
  };

  const deleteDashboardCard: AppContextValue['deleteDashboardCard'] = async (cardId) => {
    const card = snapshot.dashboardCards.find((c) => c.id === cardId);
    if (card?.isSystem) {
      return { ok: false, error: 'System financial cards can be hidden, not permanently deleted.' };
    }
    await runTransactionalWrites([
      { store: 'dashboardCards', type: 'delete', key: cardId },
      { store: 'auditLogs', type: 'put', value: makeAudit('CARD_CHANGED', 'DashboardCard', cardId, `Deleted dashboard card: ${card?.title || cardId}`) },
    ]);
    await reload();
    return { ok: true };
  };

  const saveReport: AppContextValue['saveReport'] = async (input) => {
    const name = input.name.trim();
    if (!name) return { ok: false, error: 'Report name is required.' };
    const now = new Date().toISOString();
    const existing = input.id ? snapshot.reports.find((r) => r.id === input.id) : undefined;
    const report: CustomReportConfig = {
      ...input,
      id: existing?.id || generateId('rep'),
      name,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    await runTransactionalWrites([
      { store: 'reports', type: 'put', value: report },
      { store: 'auditLogs', type: 'put', value: makeAudit('REPORT_CHANGED', 'CustomReport', report.id, `${existing ? 'Updated' : 'Created'} report: ${report.name}`) },
    ]);
    await reload();
    return { ok: true, data: report };
  };

  const deleteReport: AppContextValue['deleteReport'] = async (reportId) => {
    const rep = snapshot.reports.find((r) => r.id === reportId);
    if (!rep) return { ok: false, error: 'Report not found.' };
    await runTransactionalWrites([
      { store: 'reports', type: 'delete', key: reportId },
      { store: 'recycleBin', type: 'put', value: makeRecycleItem('report', reportId, rep.name, rep) },
      { store: 'auditLogs', type: 'put', value: makeAudit('REPORT_CHANGED', 'CustomReport', reportId, `Deleted report: ${rep.name}`) },
    ]);
    await reload();
    return { ok: true };
  };

  // --- SETTINGS & THEME ---
  const updateSettings: AppContextValue['updateSettings'] = async (next) => {
    const updated: AppSettings = {
      ...snapshot.settings,
      ...next,
      theme: next.theme ? { ...snapshot.settings.theme, ...next.theme } : snapshot.settings.theme,
      id: 'app_settings',
      updatedAt: new Date().toISOString(),
    };
    await runTransactionalWrites([
      { store: 'settings', type: 'put', value: updated },
      { store: 'auditLogs', type: 'put', value: makeAudit('SETTINGS_UPDATED', 'AppSettings', 'app_settings', `Updated application settings`) },
    ]);
    await reload();
    return { ok: true };
  };

  const resetTheme: AppContextValue['resetTheme'] = async () => {
    return updateSettings({ theme: DEFAULT_THEME });
  };

  // --- RECYCLE BIN & BACKUP ---
  const restoreFromRecycleBin: AppContextValue['restoreFromRecycleBin'] = async (binId) => {
    const item = snapshot.recycleBin.find((b) => b.id === binId);
    if (!item) return { ok: false, error: 'Recycle bin item not found.' };
    const ops: TransactionalWriteOp[] = [{ store: 'recycleBin', type: 'delete', key: binId }];

    if (item.entityType === 'loanPerson') {
      const p = item.payload as { person: LoanPerson; transactions: LoanTransaction[] };
      ops.push({ store: 'loanPersons', type: 'put', value: p.person });
      p.transactions.forEach((t) => ops.push({ store: 'loanTransactions', type: 'put', value: t }));
    } else if (item.entityType === 'loanTransaction') {
      ops.push({ store: 'loanTransactions', type: 'put', value: item.payload });
    } else if (item.entityType === 'committee') {
      const c = item.payload as { committee: Committee; transactions: CommitteeTransaction[] };
      ops.push({ store: 'committees', type: 'put', value: c.committee });
      c.transactions.forEach((t) => ops.push({ store: 'committeeTransactions', type: 'put', value: t }));
    } else if (item.entityType === 'committeeTransaction') {
      ops.push({ store: 'committeeTransactions', type: 'put', value: item.payload });
    } else if (item.entityType === 'customRecord') {
      ops.push({ store: 'customRecords', type: 'put', value: item.payload });
    } else if (item.entityType === 'module') {
      const m = item.payload as { module: CustomModule; submodules: CustomSubmodule[]; fields: FieldDefinition[]; records: CustomRecord[] };
      ops.push({ store: 'modules', type: 'put', value: m.module });
      m.submodules.forEach((s) => ops.push({ store: 'submodules', type: 'put', value: s }));
      m.fields.forEach((f) => ops.push({ store: 'fields', type: 'put', value: f }));
      m.records.forEach((r) => ops.push({ store: 'customRecords', type: 'put', value: r }));
    } else if (item.entityType === 'submodule') {
      const s = item.payload as { submodule: CustomSubmodule; fields: FieldDefinition[]; records: CustomRecord[] };
      ops.push({ store: 'submodules', type: 'put', value: s.submodule });
      s.fields.forEach((f) => ops.push({ store: 'fields', type: 'put', value: f }));
      s.records.forEach((r) => ops.push({ store: 'customRecords', type: 'put', value: r }));
    } else if (item.entityType === 'field') {
      ops.push({ store: 'fields', type: 'put', value: item.payload });
    } else if (item.entityType === 'report') {
      ops.push({ store: 'reports', type: 'put', value: item.payload });
    }

    ops.push({
      store: 'auditLogs',
      type: 'put',
      value: makeAudit('RECORD_RESTORED', item.entityType, item.originalId, `Restored from Recycle Bin: ${item.label}`),
    });
    await runTransactionalWrites(ops);
    await reload();
    return { ok: true };
  };

  const purgeFromRecycleBin: AppContextValue['purgeFromRecycleBin'] = async (binIds) => {
    const ops: TransactionalWriteOp[] = binIds.map((id) => ({
      store: 'recycleBin' as StoreName,
      type: 'delete',
      key: id,
    }));
    ops.push({
      store: 'auditLogs',
      type: 'put',
      value: makeAudit('RECORD_PURGED', 'RecycleBin', binIds.join(','), `Permanently deleted ${binIds.length} item(s) from Recycle Bin`),
    });
    await runTransactionalWrites(ops);
    await reload();
    return { ok: true };
  };

  const exportBackupPackage: AppContextValue['exportBackupPackage'] = async () => {
    const pkg = buildBackupPackage(snapshot);
    await runTransactionalWrites([
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit('BACKUP_CREATED', 'Backup', 'full_backup', `Created full JSON/Database backup`),
      },
    ]);
    await reload();
    return pkg;
  };

  const restoreBackupPackage: AppContextValue['restoreBackupPackage'] = async (pkg) => {
    await restoreFullBackup(pkg);
    await runTransactionalWrites([
      {
        store: 'auditLogs',
        type: 'put',
        value: makeAudit('DATA_RESTORED', 'Backup', 'full_restore', `Restored full backup exported on ${pkg.exportedAt}`),
      },
    ]);
    await reload();
    return { ok: true };
  };

  return (
    <AppContext.Provider
      value={{
        loading,
        error,
        activeRoute,
        setActiveRoute,
        settingsSection,
        setSettingsSection,
        toastMessage,
        notify,
        snapshot,
        reload,
        saveLoanPerson,
        deleteLoanPerson,
        saveLoanTransaction,
        deleteLoanTransaction,
        saveCommittee,
        deleteCommittee,
        saveCommitteeTransaction,
        deleteCommitteeTransaction,
        saveModule,
        deleteModule,
        saveSubmodule,
        deleteSubmodule,
        saveField,
        deleteField,
        saveMasterList,
        deleteMasterList,
        saveFormula,
        deleteFormula,
        saveFieldMapping,
        deleteFieldMapping,
        saveCustomRecord,
        toggleArchiveCustomRecord,
        deleteCustomRecord,
        saveDashboardCard,
        deleteDashboardCard,
        saveReport,
        deleteReport,
        updateSettings,
        resetTheme,
        restoreFromRecycleBin,
        purgeFromRecycleBin,
        exportBackupPackage,
        restoreBackupPackage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
