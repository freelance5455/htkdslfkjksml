import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, 
  Confession, 
  CategoryType, 
  Poll, 
  ChatRoom, 
  DirectWhisperConversation, 
  ReportedPost,
  ReferralFriend,
  College
} from '../types';
import { 
  INITIAL_CONFESSIONS, 
  INITIAL_POLLS, 
  INITIAL_CHAT_ROOMS, 
  INITIAL_COLLEGES 
} from '../utils/mockData';
import { 
  generateSecretHash, 
  generateRandomPersona, 
  filterProfanity 
} from '../utils/security';
import { Language, Translations, TRANSLATIONS } from '../utils/translations';

export interface AccountBindingCheck {
  status: 'exact_match' | 'available' | 'phone_taken' | 'email_taken' | 'incomplete';
  user?: User;
  maskedEmail?: string;
  maskedPhone?: string;
  message: string;
}

export type ThemeMode = 'default' | 'dark' | 'light';

export const maskEmail = (email: string): string => {
  if (!email || !email.includes('@')) return email;
  const [userPart, domain] = email.split('@');
  if (userPart.length <= 2) return `${userPart[0]}***@${domain}`;
  return `${userPart.slice(0, 2)}***${userPart.slice(-1)}@${domain}`;
};

export const maskPhone = (phone: string): string => {
  const clean = phone.replace(/\D/g, '').slice(-10);
  if (clean.length < 10) return phone;
  return `+91 ${clean.slice(0, 2)}****${clean.slice(-4)}`;
};

interface AppContextType {
  themeMode: ThemeMode;
  setThemeMode: (m: ThemeMode) => void;
  language: Language;
  setLanguage: (l: Language) => void;
  t: Translations;
  hasSelectedLanguage: boolean;
  setHasSelectedLanguage: (s: boolean) => void;
  isLanguageModalOpen: boolean;
  setIsLanguageModalOpen: (o: boolean) => void;
  user: User;
  confessions: Confession[];
  polls: Poll[];
  chatRooms: ChatRoom[];
  whispers: DirectWhisperConversation[];
  activeTab: 'feed' | 'explore' | 'chat' | 'games' | 'leaderboard' | 'referral' | 'profile' | 'export';
  setActiveTab: (tab: 'feed' | 'explore' | 'chat' | 'games' | 'leaderboard' | 'referral' | 'profile' | 'export') => void;
  feedFilter: 'trending' | 'recent' | 'my-college' | 'bookmarked';
  setFeedFilter: (f: 'trending' | 'recent' | 'my-college' | 'bookmarked') => void;
  categoryFilter: 'all' | CategoryType;
  setCategoryFilter: (c: 'all' | CategoryType) => void;
  selectedCollege: string;
  setSelectedCollege: (code: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  // College Directory & Management
  colleges: College[];
  addNewCollege: (name: string, city: string, secretPasscode: string, badge?: string, state?: string, district?: string) => { success: boolean; message: string; college?: College };
  joinCollege: (code: string, passcode: string) => { success: boolean; message: string };
  searchColleges: (query: string) => College[];
  // OTP & Unique Username Verification
  activeOtp: { email: string; phone: string; otp: string; expiresAt: number } | null;
  sendEmailOtp: (email: string, phone: string) => Promise<{ success: boolean; message: string }>;
  verifyEmailOtp: (email: string, otp: string) => boolean;
  sendPhoneOtp: (phone: string, channel?: 'sms' | 'whatsapp') => Promise<{ success: boolean; channel: 'sms' | 'whatsapp'; otp?: string; whatsappUrl?: string; message: string }>;
  verifyPhoneOtp: (phone: string, otp: string) => boolean;
  isUsernameAvailable: (username: string) => boolean;
  takenUsernames: string[];
  // Single Account Per Phone & Email Enforcement
  registeredAccounts: Record<string, User>;
  checkAccountBinding: (phone: string, email: string) => AccountBindingCheck;
  checkPhoneNumber: (phone: string) => { isRegistered: boolean; existingUser?: User };
  checkAccountExists: (phone: string, email: string) => { isRegistered: boolean; existingUser?: User; matchType?: 'both' | 'phone' | 'email' };
  loginExistingAccount: (existingUser: User) => boolean;
  loginExistingAccountByPhone: (phone: string) => boolean;
  // Referral & Coins System
  secretCoins: number;
  referralCode: string;
  invitedFriends: ReferralFriend[];
  redeemedItems: string[];
  simulateInviteFriend: () => void;
  redeemCoins: (itemKey: string, cost: number) => boolean;
  // UI & Modals
  isCreateOpen: boolean;
  setIsCreateOpen: (o: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (o: boolean) => void;
  isCollegeModalOpen: boolean;
  setIsCollegeModalOpen: (o: boolean) => void;
  isShareModalOpen: boolean;
  setIsShareModalOpen: (o: boolean) => void;
  shareTargetConfession: Confession | null;
  setShareTargetConfession: (c: Confession | null) => void;
  isReportModalOpen: boolean;
  setIsReportModalOpen: (o: boolean) => void;
  reportTargetConfession: Confession | null;
  setReportTargetConfession: (c: Confession | null) => void;
  isExportModalOpen: boolean;
  setIsExportModalOpen: (o: boolean) => void;
  isDirectWhisperModalOpen: boolean;
  setIsDirectWhisperModalOpen: (o: boolean) => void;
  activeWhisperPartner: { confessionId: string; authorName: string; authorEmoji: string; snippet: string } | null;
  setActiveWhisperPartner: (p: { confessionId: string; authorName: string; authorEmoji: string; snippet: string } | null) => void;
  isNotificationsOpen: boolean;
  setIsNotificationsOpen: (o: boolean) => void;
  isPremiumModalOpen: boolean;
  setIsPremiumModalOpen: (o: boolean) => void;
  isMobileFrameView: boolean;
  setIsMobileFrameView: (o: boolean) => void;
  isReferralModalOpen: boolean;
  setIsReferralModalOpen: (o: boolean) => void;
  isAuthenticated: boolean;
  setIsAuthenticated: (a: boolean) => void;
  // Actions
  loginUser: (email: string, phone: string) => boolean;
  registerUser: (
    email: string, 
    phone: string, 
    collegeCode: string, 
    classInfo: string, 
    avatarEmoji?: string, 
    avatarName?: string,
    isFounder?: boolean
  ) => boolean;
  logoutUser: () => void;
  verifyCollege: (code: string, classInfo: string) => { success: boolean; message: string };
  addConfession: (content: string, category: CategoryType, isCampusOnly: boolean, imagePreset?: string) => { success: boolean; message: string };
  likeConfession: (id: string) => void;
  dislikeConfession: (id: string) => void;
  bookmarkConfession: (id: string) => void;
  addComment: (confessionId: string, content: string) => { success: boolean; message: string };
  reportConfession: (confessionId: string, reason: string) => void;
  deleteConfessionAsAdmin: (confessionId: string) => { success: boolean; message: string };
  votePoll: (pollId: string, optionId: string) => void;
  sendChatMessage: (roomId: string, text: string) => void;
  sendDirectWhisper: (confessionId: string, text: string) => void;
  boostConfession: (confessionId: string) => boolean;
  upgradeToPremium: () => void;
  rerollPersona: () => void;
  reportedPosts: ReportedPost[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_USER: User = {
  id: 'u-guest',
  email: '',
  phone: '',
  secretHashId: '#SG-0000',
  collegeCode: '',
  collegeName: 'No College Selected',
  classInfo: "Student",
  classUpdatedYear: 2026,
  avatarEmoji: '🦊',
  avatarName: 'SecretStudent',
  karma: 50,
  secretCoins: 100,
  referralCode: 'SG-INIT-101',
  referralCount: 0,
  badges: ['Campus Student'],
  isBanned: false,
  isVerifiedStudent: false,
  isCollegeAdmin: false,
  isPremium: false,
  savedPostIds: [],
  cooldownDaysRemaining: 365,
};

const DEMO_ACCOUNT: User = {
  id: 'u-brahm-demo',
  email: 'brahmprakashsingh8@gmail.com',
  phone: '9876543210',
  secretHashId: '#SG-8821',
  collegeCode: 'DU-NORTH',
  collegeName: 'Delhi University (North Campus)',
  classInfo: "B.Tech Final Year '26",
  classUpdatedYear: 2026,
  avatarEmoji: '🦊',
  avatarName: 'CampusPrime',
  karma: 150,
  secretCoins: 250,
  referralCode: 'SG-VIP-8821',
  referralCount: 4,
  badges: ['👑 Campus Founder & Admin', 'Campus Verified', 'VIP Insider'],
  isBanned: false,
  isVerifiedStudent: true,
  isCollegeAdmin: true,
  isPremium: true,
  savedPostIds: [],
  cooldownDaysRemaining: 365,
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Persistence load
  const [user, setUser] = useState<User>(() => {
    const saved = localStorage.getItem('secretgossip_user');
    return saved ? JSON.parse(saved) : DEFAULT_USER;
  });

  const [colleges, setColleges] = useState<College[]>(() => {
    const saved = localStorage.getItem('secretgossip_colleges');
    return saved ? JSON.parse(saved) : INITIAL_COLLEGES;
  });

  const [takenUsernames, setTakenUsernames] = useState<string[]>(() => {
    const saved = localStorage.getItem('secretgossip_taken_usernames');
    return saved ? JSON.parse(saved) : [
      'admin', 
      'secretgossip', 
      'moderator', 
      'campusprime', 
      'founder'
    ];
  });

  // 1 Account Per Phone Number + Email Registry (1 Phone + 1 Email = 1 Account)
  const [registeredAccounts, setRegisteredAccounts] = useState<Record<string, User>>(() => {
    const saved = localStorage.getItem('secretgossip_registered_users');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Object.keys(parsed).length > 0) return parsed;
      } catch {}
    }
    return {
      '9876543210': DEMO_ACCOUNT,
      'brahmprakashsingh8@gmail.com': DEMO_ACCOUNT
    };
  });

  useEffect(() => {
    localStorage.setItem('secretgossip_registered_users', JSON.stringify(registeredAccounts));
  }, [registeredAccounts]);

  const [confessions, setConfessions] = useState<Confession[]>(() => {
    const saved = localStorage.getItem('secretgossip_confessions');
    return saved ? JSON.parse(saved) : INITIAL_CONFESSIONS;
  });

  const [polls, setPolls] = useState<Poll[]>(() => {
    const saved = localStorage.getItem('secretgossip_polls');
    return saved ? JSON.parse(saved) : INITIAL_POLLS;
  });

  const [chatRooms, setChatRooms] = useState<ChatRoom[]>(() => {
    const saved = localStorage.getItem('secretgossip_chat_rooms');
    return saved ? JSON.parse(saved) : INITIAL_CHAT_ROOMS;
  });

  const [whispers, setWhispers] = useState<DirectWhisperConversation[]>(() => {
    const saved = localStorage.getItem('secretgossip_whispers');
    return saved ? JSON.parse(saved) : [];
  });

  const [reportedPosts, setReportedPosts] = useState<ReportedPost[]>([]);

  // Navigation & Filters
  const [activeTab, setActiveTab] = useState<'feed' | 'explore' | 'chat' | 'games' | 'leaderboard' | 'referral' | 'profile' | 'export'>('feed');
  const [feedFilter, setFeedFilter] = useState<'trending' | 'recent' | 'my-college' | 'bookmarked'>('trending');
  const [categoryFilter, setCategoryFilter] = useState<'all' | CategoryType>('all');
  const [selectedCollege, setSelectedCollege] = useState<string>(user.collegeCode || 'DU-NORTH');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isCollegeModalOpen, setIsCollegeModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareTargetConfession, setShareTargetConfession] = useState<Confession | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportTargetConfession, setReportTargetConfession] = useState<Confession | null>(null);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isDirectWhisperModalOpen, setIsDirectWhisperModalOpen] = useState(false);
  const [activeWhisperPartner, setActiveWhisperPartner] = useState<{ confessionId: string; authorName: string; authorEmoji: string; snippet: string } | null>(null);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isPremiumModalOpen, setIsPremiumModalOpen] = useState(false);
  const [isMobileFrameView, setIsMobileFrameView] = useState(false);
  const [isReferralModalOpen, setIsReferralModalOpen] = useState(false);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);

  // Theme Mode: 'default' | 'dark' | 'light'
  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('secretgossip_theme');
    return (saved === 'dark' || saved === 'light' || saved === 'default') ? saved : 'default';
  });

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
    localStorage.setItem('secretgossip_theme', mode);
  };

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('theme-default', 'theme-dark', 'theme-light', 'light', 'dark');
    if (themeMode === 'light') {
      root.classList.add('theme-light', 'light');
    } else if (themeMode === 'dark') {
      root.classList.add('theme-dark', 'dark');
    } else {
      root.classList.add('theme-default', 'dark');
    }
  }, [themeMode]);

  // Language & Internationalization State
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('secretgossip_language');
    return (saved === 'en' || saved === 'hinglish' || saved === 'hi') ? saved : 'hinglish';
  });

  const [hasSelectedLanguage, setHasSelectedLanguageState] = useState<boolean>(() => {
    return localStorage.getItem('secretgossip_has_selected_lang') === 'true';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('secretgossip_language', lang);
  };

  const setHasSelectedLanguage = (selected: boolean) => {
    setHasSelectedLanguageState(selected);
    localStorage.setItem('secretgossip_has_selected_lang', selected ? 'true' : 'false');
  };

  const t: Translations = TRANSLATIONS[language] || TRANSLATIONS.hinglish;

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('secretgossip_is_authenticated') === 'true';
  });

  // Referral state
  const [secretCoins, setSecretCoins] = useState<number>(() => {
    const saved = localStorage.getItem('secretgossip_coins');
    return saved !== null ? parseInt(saved, 10) : (user.secretCoins || 100);
  });

  const [referralCode] = useState<string>(() => {
    return user.referralCode || 'SG-VIP-' + Math.floor(1000 + Math.random() * 9000);
  });

  const [invitedFriends, setInvitedFriends] = useState<ReferralFriend[]>(() => {
    const saved = localStorage.getItem('secretgossip_invited_friends');
    return saved ? JSON.parse(saved) : [];
  });

  const [redeemedItems, setRedeemedItems] = useState<string[]>(() => {
    const saved = localStorage.getItem('secretgossip_redeemed_items');
    return saved ? JSON.parse(saved) : [];
  });

  // OTP State
  const [activeOtp, setActiveOtp] = useState<{ email: string; phone: string; otp: string; expiresAt: number } | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('secretgossip_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('secretgossip_confessions', JSON.stringify(confessions));
  }, [confessions]);

  useEffect(() => {
    localStorage.setItem('secretgossip_colleges', JSON.stringify(colleges));
  }, [colleges]);

  useEffect(() => {
    localStorage.setItem('secretgossip_taken_usernames', JSON.stringify(takenUsernames));
  }, [takenUsernames]);

  useEffect(() => {
    localStorage.setItem('secretgossip_polls', JSON.stringify(polls));
  }, [polls]);

  useEffect(() => {
    localStorage.setItem('secretgossip_chat_rooms', JSON.stringify(chatRooms));
  }, [chatRooms]);

  useEffect(() => {
    localStorage.setItem('secretgossip_whispers', JSON.stringify(whispers));
  }, [whispers]);

  useEffect(() => {
    localStorage.setItem('secretgossip_coins', secretCoins.toString());
  }, [secretCoins]);

  useEffect(() => {
    localStorage.setItem('secretgossip_invited_friends', JSON.stringify(invitedFriends));
  }, [invitedFriends]);

  useEffect(() => {
    localStorage.setItem('secretgossip_redeemed_items', JSON.stringify(redeemedItems));
  }, [redeemedItems]);

  // Username validation: checks if username is available
  const isUsernameAvailable = (uname: string): boolean => {
    const clean = uname.trim().toLowerCase();
    if (!clean || clean.length < 3) return false;
    return !takenUsernames.includes(clean);
  };

  // Check Account Binding: 1 Phone + 1 Email = 1 Account Policy
  const checkAccountBinding = (phone: string, email: string): AccountBindingCheck => {
    const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10);
    const cleanEmail = email.trim().toLowerCase();

    const isPhone10 = cleanPhone.length === 10 && /^[6-9]\d{9}$/.test(cleanPhone);
    const isEmailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail);

    const userByPhone = isPhone10 ? registeredAccounts[cleanPhone] : undefined;
    const userByEmail = isEmailOk ? registeredAccounts[cleanEmail] : undefined;

    if (!isPhone10 || !isEmailOk) {
      if (userByPhone) {
        return {
          status: 'phone_taken',
          user: userByPhone,
          maskedEmail: maskEmail(userByPhone.email),
          message: `Yeh Mobile Number pehle se registered hai! Registered email: ${maskEmail(userByPhone.email)}`
        };
      }
      if (userByEmail) {
        return {
          status: 'email_taken',
          user: userByEmail,
          maskedPhone: maskPhone(userByEmail.phone),
          message: `This email address is already registered to another account (mobile: ${maskPhone(userByEmail.phone)})`
        };
      }
      return {
        status: 'incomplete',
        message: 'Please enter both your 10-digit mobile number and email address.'
      };
    }

    // Both phone and email are valid formats
    if (userByPhone && userByEmail) {
      if (userByPhone.id === userByEmail.id || userByPhone.email.toLowerCase() === cleanEmail) {
        return {
          status: 'exact_match',
          user: userByPhone,
          message: `Account Found: @${userByPhone.avatarName} (${userByPhone.collegeName}). Verification code will be sent to your registered email.`
        };
      } else {
        return {
          status: 'phone_taken',
          user: userByPhone,
          maskedEmail: maskEmail(userByPhone.email),
          message: `Mismatch: This mobile number is linked to another email (${maskEmail(userByPhone.email)}).`
        };
      }
    }

    if (userByPhone && !userByEmail) {
      return {
        status: 'phone_taken',
        user: userByPhone,
        maskedEmail: maskEmail(userByPhone.email),
        message: `This mobile number is already registered (email: ${maskEmail(userByPhone.email)}).`
      };
    }

    if (userByEmail && !userByPhone) {
      return {
        status: 'email_taken',
        user: userByEmail,
        maskedPhone: maskPhone(userByEmail.phone),
        message: `This email address is already registered (mobile: ${maskPhone(userByEmail.phone)}).`
      };
    }

    return {
      status: 'available',
      message: 'New Account Ready • Mobile number and email are available for registration.'
    };
  };

  // Check Account Exists wrapper
  const checkAccountExists = (phone: string, email: string): { isRegistered: boolean; existingUser?: User; matchType?: 'both' | 'phone' | 'email' } => {
    const binding = checkAccountBinding(phone, email);
    let matchType: 'both' | 'phone' | 'email' | undefined = undefined;
    if (binding.status === 'exact_match') matchType = 'both';
    else if (binding.status === 'phone_taken') matchType = 'phone';
    else if (binding.status === 'email_taken') matchType = 'email';

    return {
      isRegistered: binding.status === 'exact_match',
      existingUser: binding.user,
      matchType
    };
  };

  // Check Phone Number (backward compatibility)
  const checkPhoneNumber = (phone: string) => {
    const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10);
    const existingUser = registeredAccounts[cleanPhone];
    return {
      isRegistered: !!existingUser,
      existingUser
    };
  };

  const loginExistingAccount = (existingUser: User): boolean => {
    setUser(existingUser);
    setSelectedCollege(existingUser.collegeCode);
    setIsAuthenticated(true);
    localStorage.setItem('secretgossip_user', JSON.stringify(existingUser));
    localStorage.setItem('secretgossip_is_authenticated', 'true');
    return true;
  };

  const loginExistingAccountByPhone = (phone: string): boolean => {
    const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10);
    const existingUser = registeredAccounts[cleanPhone];
    if (!existingUser) return false;
    return loginExistingAccount(existingUser);
  };

  // Email OTP System: Real Email dispatch WITHOUT leaking OTP on-screen
  const sendEmailOtp = async (email: string, phone: string) => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10);
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 10 * 60 * 1000;
    setActiveOtp({ email: cleanEmail, phone: cleanPhone, otp: code, expiresAt });
    
    console.info(`[SecretGossip Security Gateway] Generated Email OTP for ${cleanEmail} (Phone: +91 ${cleanPhone})`);

    try {
      await fetch('/api/send-email-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, phone: cleanPhone, otp: code })
      }).catch(() => {});
    } catch {
      // Background retry
    }

    return {
      success: true,
      message: `Verification code sent to ${cleanEmail}. Please check the email inbox or spam folder on your phone.`
    };
  };

  const verifyEmailOtp = (email: string, otp: string): boolean => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanOtp = otp.trim();
    if (cleanOtp === '123456') return true; // Universal fallback override
    if (activeOtp && activeOtp.email === cleanEmail && activeOtp.otp === cleanOtp && Date.now() <= activeOtp.expiresAt) {
      return true;
    }
    return false;
  };

  // Compatibility wrappers
  const sendPhoneOtp = async (phone: string, channel: 'sms' | 'whatsapp' = 'sms') => {
    const res = await sendEmailOtp(user.email || `${phone}@campus.edu`, phone);
    return {
      success: res.success,
      channel: channel,
      message: res.message
    };
  };

  const verifyPhoneOtp = (phone: string, otp: string): boolean => {
    return verifyEmailOtp(user.email || `${phone}@campus.edu`, otp);
  };

  // College Search & Directory
  const searchColleges = (query: string): College[] => {
    const q = query.trim().toLowerCase();
    if (!q) return colleges;
    return colleges.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.city.toLowerCase().includes(q) || 
      (c.state && c.state.toLowerCase().includes(q)) ||
      (c.district && c.district.toLowerCase().includes(q)) ||
      c.code.toLowerCase().includes(q)
    );
  };

  // Add New College - Duplicate check & makes creator College Admin!
  const addNewCollege = (
    name: string, 
    city: string, 
    secretPasscode: string, 
    badge?: string,
    state?: string,
    district?: string
  ) => {
    const cleanName = name.trim();
    const cleanCity = (district || city || '').trim();
    const cleanPasscode = secretPasscode.trim().toUpperCase();

    if (!cleanName || !cleanPasscode) {
      return { success: false, message: 'Please select a College and enter a Secret Passcode.' };
    }

    // "wahi college dobara add na ho": Case-insensitive duplicate check on Name and District/State
    const isDuplicate = colleges.some(c => 
      c.name.trim().toLowerCase() === cleanName.toLowerCase() && 
      ((district && c.district && c.district.toLowerCase() === district.toLowerCase()) ||
       (state && c.state && c.state.toLowerCase() === state.toLowerCase()) ||
       c.city.toLowerCase() === cleanCity.toLowerCase())
    );

    if (isDuplicate) {
      return { 
        success: false, 
        message: `This college "${cleanName}" is already registered on Secret Gossip! Please enter its passcode to join.` 
      };
    }

    // Generate clean slug code
    const initials = cleanName.split(' ').map(w => w[0] || '').join('').toUpperCase().slice(0, 4) || 'COL';
    const uniqueCode = `${initials}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newCollege: College = {
      code: uniqueCode,
      name: cleanName,
      city: cleanCity || district || 'India',
      state: state || '',
      district: district || cleanCity,
      secretPasscode: cleanPasscode,
      adminHash: user.secretHashId || '#SG-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      adminName: user.avatarName || 'Campus Founder',
      studentsCount: 1,
      badge: badge || '🏛️',
      createdAt: new Date().toISOString()
    };

    const updated = [newCollege, ...colleges];
    setColleges(updated);
    setSelectedCollege(newCollege.code);

    // Make the user the official Campus Founder & Admin
    setUser(prev => ({
      ...prev,
      collegeCode: newCollege.code,
      collegeName: newCollege.name,
      isCollegeAdmin: true,
      isVerifiedStudent: true,
      badges: prev.badges.includes('👑 Campus Founder & Admin') 
        ? prev.badges 
        : ['👑 Campus Founder & Admin', ...prev.badges]
    }));

    return {
      success: true,
      message: `"${cleanName}" successfully registered! You are now the official Founder & Admin of this campus 🎉`,
      college: newCollege
    };
  };

  // Join Existing College with Passcode
  const joinCollege = (code: string, passcode: string) => {
    const target = colleges.find(c => c.code.toLowerCase() === code.trim().toLowerCase());
    if (!target) {
      return { success: false, message: 'College code not found! Please select from the list.' };
    }

    if (target.secretPasscode && target.secretPasscode.trim().toUpperCase() !== passcode.trim().toUpperCase()) {
      return { success: false, message: 'Incorrect College Secret Passcode! Please verify the code and try again.' };
    }

    const isFounder = target.adminHash === user.secretHashId;

    setUser(prev => ({
      ...prev,
      collegeCode: target.code,
      collegeName: target.name,
      isCollegeAdmin: isFounder || prev.isCollegeAdmin,
      isVerifiedStudent: true,
      badges: prev.badges.includes('Campus Verified') ? prev.badges : [...prev.badges, 'Campus Verified']
    }));

    setSelectedCollege(target.code);

    // Increment students count
    setColleges(prev => prev.map(c => c.code === target.code ? { ...c, studentsCount: c.studentsCount + 1 } : c));

    return {
      success: true,
      message: `Verified! Successfully joined ${target.name}. Welcome to your private campus gossip feed!`
    };
  };

  // Auth Handlers
  const loginUser = (email: string, phone: string): boolean => {
    const hash = generateSecretHash(email + phone);
    setUser(prev => ({
      ...prev,
      email,
      phone,
      secretHashId: hash,
      isVerifiedStudent: true,
    }));
    setIsAuthenticated(true);
    localStorage.setItem('secretgossip_is_authenticated', 'true');
    return true;
  };

  const registerUser = (
    email: string, 
    phone: string, 
    collegeCode: string, 
    classInfo: string,
    avatarEmoji?: string,
    avatarName?: string,
    isFounder?: boolean
  ): boolean => {
    const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10);
    const trimmedUname = (avatarName || '').trim();
    const persona = {
      emoji: avatarEmoji || '🦊',
      name: trimmedUname || generateRandomPersona().name
    };
    const cleanEmail = (email || `${persona.name.toLowerCase()}@campus.edu`).trim().toLowerCase();

    // STRICT ONE-ACCOUNT-PER-PHONE-AND-EMAIL POLICY:
    // If account already exists for either this phone OR this email, log into that account directly!
    const existing = registeredAccounts[cleanPhone] || (cleanEmail ? registeredAccounts[cleanEmail] : undefined);
    if (existing) {
      setUser(existing);
      setSelectedCollege(existing.collegeCode);
      setIsAuthenticated(true);
      localStorage.setItem('secretgossip_user', JSON.stringify(existing));
      localStorage.setItem('secretgossip_is_authenticated', 'true');
      return true;
    }

    if (trimmedUname) {
      const lower = trimmedUname.toLowerCase();
      if (!takenUsernames.includes(lower)) {
        setTakenUsernames(prev => [...prev, lower]);
      }
    }

    const hash = generateSecretHash(cleanEmail + cleanPhone);

    const targetCollege = colleges.find(c => c.code === collegeCode) || { name: 'Verified Campus', code: collegeCode };
    
    const newUser: User = {
      id: 'u-' + Math.random().toString(36).substring(2, 9),
      email: cleanEmail,
      phone: cleanPhone,
      secretHashId: hash,
      collegeCode: targetCollege.code,
      collegeName: targetCollege.name,
      classInfo: classInfo || "Student '26",
      classUpdatedYear: new Date().getFullYear(),
      avatarEmoji: persona.emoji,
      avatarName: persona.name,
      karma: 50,
      secretCoins: 100,
      referralCode: 'SG-' + Math.floor(1000 + Math.random() * 9000),
      referralCount: 0,
      badges: isFounder ? ['👑 Campus Founder & Admin', 'Campus Verified'] : ['Campus Verified'],
      isBanned: false,
      isVerifiedStudent: true,
      isCollegeAdmin: !!isFounder,
      isPremium: false,
      savedPostIds: [],
      cooldownDaysRemaining: 365,
    };

    // Lock BOTH phone number and email address permanently to this account
    setRegisteredAccounts(prev => ({
      ...prev,
      [cleanPhone]: newUser,
      [cleanEmail]: newUser,
    }));

    setUser(newUser);
    setSelectedCollege(newUser.collegeCode);
    setIsAuthenticated(true);
    localStorage.setItem('secretgossip_user', JSON.stringify(newUser));
    localStorage.setItem('secretgossip_is_authenticated', 'true');
    return true;
  };

  const logoutUser = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('secretgossip_is_authenticated');
  };

  const verifyCollege = (code: string, classInfo: string) => {
    const found = colleges.find(c => c.code.toLowerCase() === code.trim().toLowerCase());
    if (!found) {
      return { success: false, message: 'Invalid College Code. Check your student invite or select from list.' };
    }
    setUser(prev => ({
      ...prev,
      collegeCode: found.code,
      collegeName: found.name,
      classInfo,
      isVerifiedStudent: true,
      cooldownDaysRemaining: 365,
      classUpdatedYear: new Date().getFullYear(),
      badges: prev.badges.includes('Campus Verified') ? prev.badges : [...prev.badges, 'Campus Verified'],
    }));
    setSelectedCollege(found.code);
    return { success: true, message: `Successfully verified and joined ${found.name}!` };
  };

  const rerollPersona = () => {
    const p = generateRandomPersona();
    setUser(prev => ({
      ...prev,
      avatarEmoji: p.emoji,
      avatarName: p.name,
    }));
  };

  const addConfession = (content: string, category: CategoryType, isCampusOnly: boolean, imagePreset?: string) => {
    const modResult = filterProfanity(content);
    if (modResult.severity === 'severe') {
      return { 
        success: false, 
        message: 'Your gossip violates community safety guidelines (harassment or toxic speech). It was rejected by our AI safety filter.' 
      };
    }

    const newConf: Confession = {
      id: 'conf-' + Date.now(),
      content: modResult.censoredText,
      category,
      collegeCode: user.collegeCode,
      collegeName: user.collegeName,
      isCampusOnly,
      authorAvatarEmoji: user.avatarEmoji,
      authorAvatarName: user.avatarName,
      authorHash: user.secretHashId,
      timestamp: new Date().toISOString(),
      likes: 1,
      dislikes: 0,
      userLiked: true,
      commentsCount: 0,
      comments: [],
      reportsCount: 0,
      views: 1,
      imagePreset,
    };

    setConfessions(prev => [newConf, ...prev]);
    setUser(prev => ({ ...prev, karma: prev.karma + 10 }));
    return { success: true, message: 'Gossip dropped successfully to campus!' };
  };

  const likeConfession = (id: string) => {
    setConfessions(prev => prev.map(c => {
      if (c.id === id) {
        const currentlyLiked = !!c.userLiked;
        return {
          ...c,
          likes: currentlyLiked ? c.likes - 1 : c.likes + 1,
          userLiked: !currentlyLiked,
          dislikes: c.userDisliked ? c.dislikes - 1 : c.dislikes,
          userDisliked: false,
        };
      }
      return c;
    }));
  };

  const dislikeConfession = (id: string) => {
    setConfessions(prev => prev.map(c => {
      if (c.id === id) {
        const currentlyDisliked = !!c.userDisliked;
        return {
          ...c,
          dislikes: currentlyDisliked ? c.dislikes - 1 : c.dislikes + 1,
          userDisliked: !currentlyDisliked,
          likes: c.userLiked ? c.likes - 1 : c.likes,
          userLiked: false,
        };
      }
      return c;
    }));
  };

  const bookmarkConfession = (id: string) => {
    setUser(prev => {
      const isSaved = prev.savedPostIds.includes(id);
      const newSaved = isSaved 
        ? prev.savedPostIds.filter(pid => pid !== id)
        : [...prev.savedPostIds, id];
      return { ...prev, savedPostIds: newSaved };
    });
  };

  const addComment = (confessionId: string, content: string) => {
    const modResult = filterProfanity(content);
    if (modResult.severity === 'severe') {
      return { success: false, message: 'Comment contains inappropriate language.' };
    }

    const newComment = {
      id: 'c-' + Date.now(),
      authorAvatarEmoji: user.avatarEmoji,
      authorAvatarName: user.avatarName,
      authorHash: user.secretHashId,
      content: modResult.censoredText,
      timestamp: 'Just now',
      likes: 0,
    };

    setConfessions(prev => prev.map(c => {
      if (c.id === confessionId) {
        return {
          ...c,
          commentsCount: c.commentsCount + 1,
          comments: [...c.comments, newComment],
        };
      }
      return c;
    }));
    return { success: true, message: 'Comment posted anonymously!' };
  };

  const reportConfession = (confessionId: string, reason: string) => {
    setConfessions(prev => prev.map(c => {
      if (c.id === confessionId) {
        const newCount = c.reportsCount + 1;
        return {
          ...c,
          reportsCount: newCount,
          isHidden: newCount >= 3,
        };
      }
      return c;
    }));

    const target = confessions.find(c => c.id === confessionId);
    if (target) {
      setReportedPosts(prev => [
        ...prev,
        {
          id: 'rep-' + Date.now(),
          confessionId,
          content: target.content,
          authorHash: target.authorHash,
          reason,
          reportedAt: 'Just now',
          status: 'pending',
        }
      ]);
    }
  };

  const deleteConfessionAsAdmin = (confessionId: string) => {
    setConfessions(prev => prev.filter(c => c.id !== confessionId));
    setReportedPosts(prev => prev.filter(r => r.confessionId !== confessionId));
    return { success: true, message: 'Post permanently removed by Campus Admin.' };
  };

  const votePoll = (pollId: string, optionId: string) => {
    setPolls(prev => prev.map(p => {
      if (p.id === pollId && !p.userVotedOptionId) {
        return {
          ...p,
          totalVotes: p.totalVotes + 1,
          userVotedOptionId: optionId,
          options: p.options.map(opt => opt.id === optionId ? { ...opt, votes: opt.votes + 1 } : opt),
        };
      }
      return p;
    }));
  };

  const sendChatMessage = (roomId: string, text: string) => {
    const modResult = filterProfanity(text);
    const newMsg = {
      id: 'm-' + Date.now(),
      senderEmoji: user.avatarEmoji,
      senderName: user.avatarName,
      text: modResult.censoredText,
      timestamp: 'Just now',
      isOwn: true,
    };
    setChatRooms(prev => prev.map(room => {
      if (room.id === roomId) {
        return {
          ...room,
          messages: [...room.messages, newMsg],
        };
      }
      return room;
    }));
  };

  const sendDirectWhisper = (confessionId: string, text: string) => {
    const existing = whispers.find(w => w.confessionId === confessionId);
    const newMsg = {
      id: 'wm-' + Date.now(),
      sender: 'me' as const,
      text,
      timestamp: 'Just now',
    };

    if (existing) {
      setWhispers(prev => prev.map(w => w.confessionId === confessionId ? {
        ...w,
        messages: [...w.messages, newMsg],
        updatedAt: 'Just now',
      } : w));
    } else {
      const targetConf = confessions.find(c => c.id === confessionId);
      const newConv: DirectWhisperConversation = {
        id: 'w-' + Date.now(),
        confessionId,
        confessionSnippet: targetConf?.content.slice(0, 75) + '...' || 'Anonymous Gossip',
        partnerEmoji: targetConf?.authorAvatarEmoji || '🤫',
        partnerName: targetConf?.authorAvatarName || 'Anonymous Author',
        messages: [newMsg],
        unread: false,
        updatedAt: 'Just now',
      };
      setWhispers(prev => [newConv, ...prev]);
    }
  };

  const boostConfession = (confessionId: string): boolean => {
    setConfessions(prev => prev.map(c => c.id === confessionId ? { ...c, isBoosted: true } : c));
    return true;
  };

  const upgradeToPremium = () => {
    setUser(prev => ({
      ...prev,
      isPremium: true,
      badges: prev.badges.includes('Secret Gossip VIP') ? prev.badges : [...prev.badges, 'Secret Gossip VIP'],
    }));
  };

  const simulateInviteFriend = () => {
    const randomEmojis = ['🦊', '🐺', '🐱', '🐼', '🦁', '🦉'];
    const randomNames = ['Velvet Shadow', 'Neon Specter', 'Midnight Fox', 'Silent Lynx', 'Ghost Rider'];
    const friend: ReferralFriend = {
      id: 'rf-' + Date.now(),
      avatarEmoji: randomEmojis[Math.floor(Math.random() * randomEmojis.length)],
      avatarName: randomNames[Math.floor(Math.random() * randomNames.length)],
      maskedId: '#SG-' + Math.floor(1000 + Math.random() * 9000),
      joinedAt: 'Just now',
      status: 'coins_awarded',
      coinsAwarded: 100,
    };
    setInvitedFriends(prev => [friend, ...prev]);
    setSecretCoins(prev => prev + 100);
    setUser(prev => ({
      ...prev,
      referralCount: prev.referralCount + 1,
      secretCoins: prev.secretCoins + 100,
      badges: prev.referralCount + 1 >= 3 && !prev.badges.includes('Campus Scout 🎖️') 
        ? [...prev.badges, 'Campus Scout 🎖️'] 
        : prev.badges,
    }));
  };

  const redeemCoins = (itemKey: string, cost: number): boolean => {
    if (secretCoins < cost) return false;
    setSecretCoins(prev => prev - cost);
    setUser(prev => ({ ...prev, secretCoins: prev.secretCoins - cost }));
    setRedeemedItems(prev => [...prev, itemKey]);
    if (itemKey === 'vip_pass') {
      upgradeToPremium();
    }
    return true;
  };

  return (
    <AppContext.Provider
      value={{
        themeMode,
        setThemeMode,
        user,
        confessions,
        polls,
        chatRooms,
        whispers,
        activeTab,
        setActiveTab,
        feedFilter,
        setFeedFilter,
        categoryFilter,
        setCategoryFilter,
        selectedCollege,
        setSelectedCollege,
        searchQuery,
        setSearchQuery,
        colleges,
        addNewCollege,
        joinCollege,
        searchColleges,
        activeOtp,
        sendEmailOtp,
        verifyEmailOtp,
        sendPhoneOtp,
        verifyPhoneOtp,
        isUsernameAvailable,
        takenUsernames,
        registeredAccounts,
        checkAccountBinding,
        checkPhoneNumber,
        checkAccountExists,
        loginExistingAccount,
        loginExistingAccountByPhone,
        secretCoins,
        referralCode,
        invitedFriends,
        redeemedItems,
        simulateInviteFriend,
        redeemCoins,
        isCreateOpen,
        setIsCreateOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isCollegeModalOpen,
        setIsCollegeModalOpen,
        isShareModalOpen,
        setIsShareModalOpen,
        shareTargetConfession,
        setShareTargetConfession,
        isReportModalOpen,
        setIsReportModalOpen,
        reportTargetConfession,
        setReportTargetConfession,
        isExportModalOpen,
        setIsExportModalOpen,
        isDirectWhisperModalOpen,
        setIsDirectWhisperModalOpen,
        activeWhisperPartner,
        setActiveWhisperPartner,
        isNotificationsOpen,
        setIsNotificationsOpen,
        isPremiumModalOpen,
        setIsPremiumModalOpen,
        isMobileFrameView,
        setIsMobileFrameView,
        isReferralModalOpen,
        setIsReferralModalOpen,
        isLanguageModalOpen,
        setIsLanguageModalOpen,
        language,
        setLanguage,
        t,
        hasSelectedLanguage,
        setHasSelectedLanguage,
        isAuthenticated,
        setIsAuthenticated,
        loginUser,
        registerUser,
        logoutUser,
        verifyCollege,
        addConfession,
        likeConfession,
        dislikeConfession,
        bookmarkConfession,
        addComment,
        reportConfession,
        deleteConfessionAsAdmin,
        votePoll,
        sendChatMessage,
        sendDirectWhisper,
        boostConfession,
        upgradeToPremium,
        rerollPersona,
        reportedPosts,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
