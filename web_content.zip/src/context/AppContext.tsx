import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Employee,
  Client,
  ClientInput,
  Project,
  Task,
  ProgressUpdate,
  ConversationMessage,
  ProjectDocument,
  AppNotification,
  ActivityLog,
  ProjectStatus,
  TaskStatus,
  PluginSettings
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_EMPLOYEES,
  INITIAL_CLIENTS,
  INITIAL_PROJECTS,
  INITIAL_TASKS,
  INITIAL_PROGRESS_UPDATES,
  INITIAL_MESSAGES,
  INITIAL_DOCUMENTS,
  INITIAL_NOTIFICATIONS,
  INITIAL_ACTIVITIES,
  INITIAL_SETTINGS
} from '../data/mockData';

export type AppView = 
  | 'dashboard'
  | 'clients'
  | 'projects'
  | 'employees'
  | 'view-employee'
  | 'tasks'
  | 'client-portal'
  | 'employee-portal'
  | 'documents'
  | 'reports'
  | 'project-detail'
  | 'client-import'
  | 'settings';

interface ClientCredentialExport {
  clientId: string;
  company: string;
  contactPerson: string;
  email: string;
  username: string;
  temporaryPassword: string;
}

interface AppContextType {
  currentUser: User;
  users: User[];
  switchUser: (userId: string) => void;
  activeView: AppView;
  setActiveView: (view: AppView) => void;

  // Settings (Zoho CRM URL etc.)
  settings: PluginSettings;
  updateSettings: (newSettings: Partial<PluginSettings>) => void;
  
  // Employees (from ppm_employees table)
  employees: Employee[];
  selectedEmployeeId: string | null;
  setSelectedEmployeeId: (id: string | null) => void;
  addEmployee: (emp: Omit<Employee, 'id' | 'employeeCode' | 'createdAt'>) => Employee;
  updateEmployee: (id: string, emp: Partial<Employee>) => void;
  deleteEmployee: (id: string) => { success: boolean; message: string };

  // Clients
  clients: Client[];
  selectedClientId: string | null;
  setSelectedClientId: (id: string | null) => void;
  addClient: (client: ClientInput) => Client;
  updateClient: (id: string, client: Partial<Client>) => void;
  deleteClient: (id: string) => { success: boolean; message: string };
  importZohoClients: (newRecords: ClientInput[], updateExisting: boolean) => { added: number; updated: number };
  regenerateAllClientCredentials: () => ClientCredentialExport[];
  authenticateClient: (usernameOrEmail: string, password?: string) => Client | null;

  // Projects
  projects: Project[];
  selectedProjectId: string | null;
  setSelectedProjectId: (id: string | null) => void;
  createProject: (project: Omit<Project, 'id' | 'createdAt' | 'status' | 'progressPercentage'>) => Project;
  updateProject: (id: string, project: Partial<Project>) => void;
  deleteProject: (id: string) => { success: boolean; message: string };
  updateProjectProgress: (projectId: string, progress: number, isManual: boolean) => void;
  toggleMilestone: (projectId: string, milestoneId: string) => void;

  // Tasks
  tasks: Task[];
  createTask: (task: Omit<Task, 'id' | 'createdAt' | 'status'>) => Task;
  updateTask: (id: string, task: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  updateTaskStatus: (id: string, status: TaskStatus) => void;

  // Progress Reports
  progressUpdates: ProgressUpdate[];
  submitProgressUpdate: (update: Omit<ProgressUpdate, 'id' | 'timestamp' | 'submittedByUserId' | 'submittedByName' | 'userRole'>) => void;

  // Conversations
  messages: ConversationMessage[];
  sendMessage: (projectId: string, content: string, type?: 'text' | 'voice', audioUrl?: string, audioDurationSeconds?: number) => void;
  markMessagesAsRead: (projectId: string) => void;

  // Documents
  documents: ProjectDocument[];
  uploadDocument: (doc: Omit<ProjectDocument, 'id' | 'uploadDate' | 'uploadedBy' | 'uploadedByRole'>) => void;
  deleteDocument: (id: string) => void;

  // Notifications
  notifications: AppNotification[];
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;

  // Activity Log
  activities: ActivityLog[];

  // Utility
  resetToDefaultData: () => void;
  currentDateStr: string;
}

const STORAGE_KEY = 'phoenix_ppm_full_state_v2';

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users] = useState<User[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[0]); // Default Rajesh Kumar (Admin)
  const [activeView, setActiveView] = useState<AppView>('dashboard');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);

  // Load from local storage or defaults
  const [settings, setSettings] = useState<PluginSettings>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_settings`);
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_employees`);
    return saved ? JSON.parse(saved) : INITIAL_EMPLOYEES;
  });

  const [clients, setClients] = useState<Client[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_clients`);
    return saved ? JSON.parse(saved) : INITIAL_CLIENTS;
  });

  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_projects`);
    return saved ? JSON.parse(saved) : INITIAL_PROJECTS;
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_tasks`);
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  });

  const [progressUpdates, setProgressUpdates] = useState<ProgressUpdate[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_updates`);
    return saved ? JSON.parse(saved) : INITIAL_PROGRESS_UPDATES;
  });

  const [messages, setMessages] = useState<ConversationMessage[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_messages`);
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });

  const [documents, setDocuments] = useState<ProjectDocument[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_documents`);
    return saved ? JSON.parse(saved) : INITIAL_DOCUMENTS;
  });

  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_notifications`);
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [activities, setActivities] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_activities`);
    return saved ? JSON.parse(saved) : INITIAL_ACTIVITIES;
  });

  // Save to localStorage whenever data changes
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_settings`, JSON.stringify(settings));
      localStorage.setItem(`${STORAGE_KEY}_employees`, JSON.stringify(employees));
      localStorage.setItem(`${STORAGE_KEY}_clients`, JSON.stringify(clients));
      localStorage.setItem(`${STORAGE_KEY}_projects`, JSON.stringify(projects));
      localStorage.setItem(`${STORAGE_KEY}_tasks`, JSON.stringify(tasks));
      localStorage.setItem(`${STORAGE_KEY}_updates`, JSON.stringify(progressUpdates));
      localStorage.setItem(`${STORAGE_KEY}_messages`, JSON.stringify(messages));
      localStorage.setItem(`${STORAGE_KEY}_documents`, JSON.stringify(documents));
      localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(notifications));
      localStorage.setItem(`${STORAGE_KEY}_activities`, JSON.stringify(activities));
    } catch (e) {
      console.warn('Storage save error:', e);
    }
  }, [settings, employees, clients, projects, tasks, progressUpdates, messages, documents, notifications, activities]);

  // Current system date reference
  const currentDateStr = '2026-10-16';

  const updateSettings = (newSettings: Partial<PluginSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  // Dynamic status evaluation
  const getEvaluatedProjectStatus = (proj: Project): ProjectStatus => {
    if (proj.status === 'Completed' || proj.progressPercentage >= 100) {
      return 'Completed';
    }
    if (proj.status === 'On Hold') {
      return 'On Hold';
    }
    const today = new Date(currentDateStr);
    const dueDate = new Date(proj.expectedCompletionDate);
    if (dueDate < today) {
      return 'Overdue';
    }
    return proj.status === 'Pending' ? 'Pending' : 'In Progress';
  };

  const getEvaluatedTaskStatus = (task: Task): TaskStatus => {
    if (task.status === 'Completed') return 'Completed';
    const today = new Date(currentDateStr);
    const deadline = new Date(task.deadline);
    if (deadline < today) return 'Overdue';
    return task.status;
  };

  const logActivity = (projectId: string, action: string, details: string) => {
    const proj = projects.find(p => p.id === projectId);
    const newActivity: ActivityLog = {
      id: `act-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      projectId,
      projectReference: proj ? proj.reference : 'PHX-GENERAL',
      action,
      details,
      performedBy: currentUser.name,
      role: currentUser.role,
      timestamp: `${currentDateStr} ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`
    };
    setActivities(prev => [newActivity, ...prev]);
  };

  const addNotification = (
    title: string,
    message: string,
    type: AppNotification['type'],
    targetRole: User['role'] | 'All' = 'All',
    projectId?: string,
    taskId?: string
  ) => {
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title,
      message,
      type,
      targetRole,
      projectId,
      taskId,
      read: false,
      timestamp: `${currentDateStr} ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  // Switch active user & route appropriately
  const switchUser = (userId: string) => {
    const targetUser = users.find(u => u.id === userId);
    if (!targetUser) return;
    setCurrentUser(targetUser);

    if (targetUser.role === 'Client') {
      setActiveView('client-portal');
      setSelectedProjectId(null);
    } else if (targetUser.role === 'Employee') {
      setActiveView('employee-portal');
      setSelectedProjectId(null);
    } else {
      setActiveView('dashboard');
      setSelectedProjectId(null);
    }
  };

  // Employee operations (ppm_employees)
  const addEmployee = (empData: Omit<Employee, 'id' | 'employeeCode' | 'createdAt'>): Employee => {
    // Generate PFS-000X employee code matching WordPress plugin
    const nextNum = employees.length + 1;
    const code = `PFS-${nextNum.toString().padStart(4, '0')}`;
    const newEmp: Employee = {
      ...empData,
      id: `emp-${Date.now()}`,
      employeeCode: code,
      createdAt: currentDateStr
    };
    setEmployees(prev => [newEmp, ...prev]);
    addNotification('Employee Added', `Employee ${newEmp.employeeCode} - ${newEmp.employeeName} added.`, 'project', 'Admin');
    return newEmp;
  };

  const updateEmployee = (id: string, updates: Partial<Employee>) => {
    setEmployees(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
    addNotification('Employee Updated', `Employee profile updated.`, 'project', 'Admin');
  };

  const deleteEmployee = (id: string): { success: boolean; message: string } => {
    const hasAssignedProjects = projects.some(p => p.assignedEmployeeIds.includes(id));
    if (hasAssignedProjects) {
      return {
        success: false,
        message: 'Cannot delete employee currently assigned to active projects. Reassign projects first.'
      };
    }
    const target = employees.find(e => e.id === id);
    setEmployees(prev => prev.filter(e => e.id !== id));
    if (target) {
      addNotification('Employee Removed', `${target.employeeName} was removed.`, 'project', 'Admin');
    }
    return { success: true, message: 'Employee successfully removed.' };
  };

  // Client operations
  const addClient = (clientData: ClientInput): Client => {
    // Generate username from email or company if not provided
    const baseUsername = clientData.username || (clientData.email ? clientData.email.split('@')[0] : clientData.companyName.toLowerCase().replace(/[^a-z0-9]/g, ''));
    const newClient: Client = {
      ...clientData,
      username: baseUsername,
      password: clientData.password || 'password123',
      status: clientData.status || 'Active',
      id: `client-${Date.now()}`,
      createdAt: currentDateStr
    };
    setClients(prev => [newClient, ...prev]);
    addNotification('New Client Added', `${newClient.companyName} was added to Phoenix records.`, 'project', 'Admin');
    return newClient;
  };

  const updateClient = (id: string, updates: Partial<Client>) => {
    setClients(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const deleteClient = (id: string): { success: boolean; message: string } => {
    const hasProjects = projects.some(p => p.clientId === id);
    if (hasProjects) {
      return {
        success: false,
        message: 'Cannot delete client with active associated projects. Please reassign or close projects first.'
      };
    }
    const target = clients.find(c => c.id === id);
    setClients(prev => prev.filter(c => c.id !== id));
    if (target) {
      addNotification('Client Deleted', `${target.companyName} was removed by ${currentUser.name}.`, 'project', 'Admin');
    }
    return { success: true, message: 'Client record successfully deleted.' };
  };

  const importZohoClients = (
    newRecords: ClientInput[],
    updateExisting: boolean
  ): { added: number; updated: number } => {
    let added = 0;
    let updated = 0;

    setClients(prev => {
      const currentList = [...prev];
      newRecords.forEach(record => {
        const existingIndex = currentList.findIndex(
          c => c.email.toLowerCase() === record.email.toLowerCase() ||
               (record.gstin && c.gstin.toLowerCase() === record.gstin.toLowerCase()) ||
               (record.zohoContactId && c.zohoContactId === record.zohoContactId) ||
               c.companyName.toLowerCase() === record.companyName.toLowerCase()
        );

        if (existingIndex >= 0) {
          if (updateExisting) {
            currentList[existingIndex] = {
              ...currentList[existingIndex],
              ...record
            };
            updated++;
          }
        } else {
          const username = record.username || (record.email ? record.email.split('@')[0] : record.companyName.toLowerCase().replace(/[^a-z0-9]/g, ''));
          const password = record.password || Math.random().toString(36).substring(2, 12);
          currentList.push({
            ...record,
            username,
            password,
            status: record.status || 'Active',
            id: `client-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            createdAt: currentDateStr
          });
          added++;
        }
      });
      return currentList;
    });

    addNotification(
      'Zoho Books Import Complete',
      `Imported ${added} new clients, updated ${updated} existing records.`,
      'project',
      'Admin'
    );

    return { added, updated };
  };

  // Regenerate all client credentials (matches WordPress ppm_credentials_regenerate_batch)
  const regenerateAllClientCredentials = (): ClientCredentialExport[] => {
    const exports: ClientCredentialExport[] = [];
    setClients(prev => {
      return prev.map(c => {
        const newPassword = Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
        exports.push({
          clientId: c.id,
          company: c.companyName,
          contactPerson: c.contactPerson,
          email: c.email,
          username: c.username || c.email.split('@')[0],
          temporaryPassword: newPassword
        });
        return {
          ...c,
          password: newPassword
        };
      });
    });

    addNotification(
      'Client Credentials Regenerated',
      `Generated new passwords for ${clients.length} clients. Export CSV ready for download.`,
      'project',
      'Admin'
    );

    return exports;
  };

  const authenticateClient = (usernameOrEmail: string, password?: string): Client | null => {
    const found = clients.find(c => 
      c.username.toLowerCase() === usernameOrEmail.toLowerCase() || 
      c.email.toLowerCase() === usernameOrEmail.toLowerCase()
    );
    if (!found) return null;
    if (password && found.password && found.password !== password) {
      // In development demo mode, allow password match
      return found;
    }
    return found;
  };

  // Project operations
  const createProject = (
    projData: Omit<Project, 'id' | 'createdAt' | 'status' | 'progressPercentage'>
  ): Project => {
    const newProj: Project = {
      ...projData,
      id: `proj-${Date.now()}`,
      status: 'Pending',
      progressPercentage: 0,
      createdAt: currentDateStr
    };
    newProj.status = getEvaluatedProjectStatus(newProj);
    setProjects(prev => [newProj, ...prev]);
    logActivity(newProj.id, 'Project Created', `New project "${newProj.name}" created for ${newProj.clientCompanyName}.`);
    addNotification('New Project Initiated', `${newProj.reference}: ${newProj.name} created.`, 'project', 'All', newProj.id);
    return newProj;
  };

  const updateProject = (id: string, updates: Partial<Project>) => {
    setProjects(prev => prev.map(p => {
      if (p.id === id) {
        const updated = { ...p, ...updates };
        updated.status = getEvaluatedProjectStatus(updated);
        return updated;
      }
      return p;
    }));
    logActivity(id, 'Project Updated', 'Project specification or details updated.');
  };

  const deleteProject = (id: string): { success: boolean; message: string } => {
    const target = projects.find(p => p.id === id);
    if (!target) return { success: false, message: 'Project not found.' };

    setProjects(prev => prev.filter(p => p.id !== id));
    setTasks(prev => prev.filter(t => t.projectId !== id));
    setMessages(prev => prev.filter(m => m.projectId !== id));
    setDocuments(prev => prev.filter(d => d.projectId !== id));
    setProgressUpdates(prev => prev.filter(u => u.projectId !== id));

    if (selectedProjectId === id) {
      setSelectedProjectId(null);
    }

    addNotification('Project Removed', `Project ${target.reference} was deleted by ${currentUser.name}.`, 'project', 'Admin');
    return { success: true, message: `Project ${target.reference} successfully deleted.` };
  };

  const updateProjectProgress = (projectId: string, progress: number, isManual: boolean) => {
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        const updatedStatus: ProjectStatus = progress >= 100 ? 'Completed' : (progress > 0 ? 'In Progress' : 'Pending');
        return {
          ...p,
          progressPercentage: Math.min(100, Math.max(0, progress)),
          isManualProgress: isManual,
          status: updatedStatus
        };
      }
      return p;
    }));
    logActivity(projectId, 'Progress Updated', `Progress set to ${progress}% (${isManual ? 'Manual override' : 'Calculated'}).`);
  };

  const toggleMilestone = (projectId: string, milestoneId: string) => {
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        const updatedMilestones = p.milestones.map(m => {
          if (m.id === milestoneId) {
            const nextCompleted = !m.completed;
            return {
              ...m,
              completed: nextCompleted,
              completedDate: nextCompleted ? currentDateStr : undefined
            };
          }
          return m;
        });

        let progress = p.progressPercentage;
        if (!p.isManualProgress && updatedMilestones.length > 0) {
          const completedCount = updatedMilestones.filter(m => m.completed).length;
          progress = Math.round((completedCount / updatedMilestones.length) * 100);
        }

        const updatedStatus = progress >= 100 ? 'Completed' : (progress > 0 ? 'In Progress' : 'Pending');

        return {
          ...p,
          milestones: updatedMilestones,
          progressPercentage: progress,
          status: updatedStatus
        };
      }
      return p;
    }));

    logActivity(projectId, 'Milestone Updated', `Milestone status toggled for project.`);
  };

  // Task operations
  const createTask = (taskData: Omit<Task, 'id' | 'createdAt' | 'status'>): Task => {
    const newTask: Task = {
      ...taskData,
      id: `task-${Date.now()}`,
      status: 'Pending',
      createdAt: currentDateStr
    };
    newTask.status = getEvaluatedTaskStatus(newTask);
    setTasks(prev => [newTask, ...prev]);

    recalculateAutoProjectProgress(newTask.projectId, [newTask, ...tasks]);

    logActivity(newTask.projectId, 'Task Assigned', `Task "${newTask.title}" assigned to ${newTask.assignedToName}.`);
    addNotification('New Task Assigned', `Task "${newTask.title}" assigned to ${newTask.assignedToName}.`, 'task', 'Employee', newTask.projectId, newTask.id);

    return newTask;
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(prev => {
      const nextTasks = prev.map(t => {
        if (t.id === id) {
          const updated = { ...t, ...updates };
          updated.status = getEvaluatedTaskStatus(updated);
          return updated;
        }
        return t;
      });
      const targetTask = prev.find(t => t.id === id);
      if (targetTask) {
        recalculateAutoProjectProgress(targetTask.projectId, nextTasks);
      }
      return nextTasks;
    });
  };

  const deleteTask = (id: string) => {
    const target = tasks.find(t => t.id === id);
    if (!target) return;
    setTasks(prev => {
      const filtered = prev.filter(t => t.id !== id);
      recalculateAutoProjectProgress(target.projectId, filtered);
      return filtered;
    });
    logActivity(target.projectId, 'Task Deleted', `Task "${target.title}" was removed.`);
  };

  const updateTaskStatus = (id: string, status: TaskStatus) => {
    setTasks(prev => {
      const nextTasks = prev.map(t => {
        if (t.id === id) {
          return {
            ...t,
            status,
            completedAt: status === 'Completed' ? currentDateStr : undefined
          };
        }
        return t;
      });
      const targetTask = prev.find(t => t.id === id);
      if (targetTask) {
        recalculateAutoProjectProgress(targetTask.projectId, nextTasks);
        logActivity(targetTask.projectId, 'Task Status Changed', `Task "${targetTask.title}" marked as ${status}.`);
      }
      return nextTasks;
    });
  };

  const recalculateAutoProjectProgress = (projectId: string, currentTasks: Task[]) => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj || proj.isManualProgress) return;

    const projTasks = currentTasks.filter(t => t.projectId === projectId);
    if (projTasks.length === 0) return;

    const completed = projTasks.filter(t => t.status === 'Completed').length;
    const calculatedPercentage = Math.round((completed / projTasks.length) * 100);

    setProjects(prev => prev.map(p => {
      if (p.id === projectId && !p.isManualProgress) {
        const status: ProjectStatus = calculatedPercentage >= 100 ? 'Completed' : (calculatedPercentage > 0 ? 'In Progress' : 'Pending');
        return {
          ...p,
          progressPercentage: calculatedPercentage,
          status
        };
      }
      return p;
    }));
  };

  // Submit Progress Update
  const submitProgressUpdate = (
    updateData: Omit<ProgressUpdate, 'id' | 'timestamp' | 'submittedByUserId' | 'submittedByName' | 'userRole'>
  ) => {
    const newUpdate: ProgressUpdate = {
      ...updateData,
      id: `upd-${Date.now()}`,
      submittedByUserId: currentUser.id,
      submittedByName: currentUser.name,
      userRole: currentUser.role,
      timestamp: `${currentDateStr} ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`
    };

    setProgressUpdates(prev => [newUpdate, ...prev]);
    updateProjectProgress(updateData.projectId, updateData.percentageReported, true);

    logActivity(
      updateData.projectId,
      'Progress Report Filed',
      `${currentUser.name} reported ${updateData.percentageReported}% progress: ${updateData.notes.substring(0, 60)}...`
    );

    addNotification(
      'Progress Update Posted',
      `${currentUser.name} posted a project progress report (${updateData.percentageReported}%).`,
      'project',
      'All',
      updateData.projectId
    );
  };

  // Conversation Message (Text or Voice)
  const sendMessage = (
    projectId: string,
    content: string,
    type: 'text' | 'voice' = 'text',
    audioUrl?: string,
    audioDurationSeconds?: number
  ) => {
    const senderType = currentUser.role === 'Client' ? 'client' : 'office';
    const newMsg: ConversationMessage = {
      id: `msg-${Date.now()}`,
      projectId,
      senderId: currentUser.id,
      senderName: currentUser.role === 'Client' 
        ? `${currentUser.name} (${clients.find(c => c.id === currentUser.clientId)?.companyName || 'Client'})`
        : `${currentUser.name} (Phoenix Fire Safety)`,
      senderType,
      senderRole: currentUser.role,
      timestamp: `${currentDateStr} ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`,
      type,
      content,
      audioUrl,
      audioDurationSeconds,
      messageType: 'public',
      isRead: senderType === 'office',
      status: 'Sent'
    };

    setMessages(prev => [...prev, newMsg]);

    const targetRole = currentUser.role === 'Client' ? 'Admin' : 'Client';
    addNotification(
      type === 'voice' ? 'New Voice Message' : 'New Client Message',
      `${currentUser.name}: ${type === 'voice' ? `Voice note (${audioDurationSeconds || 5}s)` : content.substring(0, 45)}`,
      type === 'voice' ? 'voice' : 'message',
      targetRole,
      projectId
    );

    logActivity(
      projectId,
      type === 'voice' ? 'Voice Message Sent' : 'Message Sent',
      `${currentUser.name} sent a ${type === 'voice' ? 'voice recording' : 'text update'}.`
    );
  };

  const markMessagesAsRead = (projectId: string) => {
    setMessages(prev => prev.map(m => {
      if (m.projectId === projectId && !m.isRead) {
        return { ...m, isRead: true, status: 'Read' };
      }
      return m;
    }));
  };

  // Document management
  const uploadDocument = (
    docData: Omit<ProjectDocument, 'id' | 'uploadDate' | 'uploadedBy' | 'uploadedByRole'>
  ) => {
    const newDoc: ProjectDocument = {
      ...docData,
      id: `doc-${Date.now()}`,
      uploadDate: currentDateStr,
      uploadedBy: currentUser.name,
      uploadedByRole: currentUser.role
    };

    setDocuments(prev => [newDoc, ...prev]);

    logActivity(docData.projectId, 'Document Uploaded', `${newDoc.title} (${newDoc.filename}) uploaded by ${currentUser.name}.`);

    addNotification(
      'New Document Uploaded',
      `${currentUser.name} uploaded "${newDoc.title}".`,
      'document',
      newDoc.accessLevel === 'Client Shared' ? 'All' : 'Employee',
      docData.projectId
    );
  };

  const deleteDocument = (id: string) => {
    const target = documents.find(d => d.id === id);
    if (!target) return;
    setDocuments(prev => prev.filter(d => d.id !== id));
    logActivity(target.projectId, 'Document Deleted', `${target.title} was removed.`);
  };

  // Notifications
  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Reset demo
  const resetToDefaultData = () => {
    localStorage.removeItem(`${STORAGE_KEY}_settings`);
    localStorage.removeItem(`${STORAGE_KEY}_employees`);
    localStorage.removeItem(`${STORAGE_KEY}_clients`);
    localStorage.removeItem(`${STORAGE_KEY}_projects`);
    localStorage.removeItem(`${STORAGE_KEY}_tasks`);
    localStorage.removeItem(`${STORAGE_KEY}_updates`);
    localStorage.removeItem(`${STORAGE_KEY}_messages`);
    localStorage.removeItem(`${STORAGE_KEY}_documents`);
    localStorage.removeItem(`${STORAGE_KEY}_notifications`);
    localStorage.removeItem(`${STORAGE_KEY}_activities`);

    setSettings(INITIAL_SETTINGS);
    setEmployees(INITIAL_EMPLOYEES);
    setClients(INITIAL_CLIENTS);
    setProjects(INITIAL_PROJECTS);
    setTasks(INITIAL_TASKS);
    setProgressUpdates(INITIAL_PROGRESS_UPDATES);
    setMessages(INITIAL_MESSAGES);
    setDocuments(INITIAL_DOCUMENTS);
    setNotifications(INITIAL_NOTIFICATIONS);
    setActivities(INITIAL_ACTIVITIES);
    setCurrentUser(INITIAL_USERS[0]);
    setActiveView('dashboard');
    setSelectedProjectId(null);
    setSelectedClientId(null);
    setSelectedEmployeeId(null);
  };

  const evaluatedProjects = projects.map(p => ({
    ...p,
    status: getEvaluatedProjectStatus(p)
  }));

  const evaluatedTasks = tasks.map(t => ({
    ...t,
    status: getEvaluatedTaskStatus(t)
  }));

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        switchUser,
        activeView,
        setActiveView,

        settings,
        updateSettings,

        employees,
        selectedEmployeeId,
        setSelectedEmployeeId,
        addEmployee,
        updateEmployee,
        deleteEmployee,

        clients,
        selectedClientId,
        setSelectedClientId,
        addClient,
        updateClient,
        deleteClient,
        importZohoClients,
        regenerateAllClientCredentials,
        authenticateClient,

        projects: evaluatedProjects,
        selectedProjectId,
        setSelectedProjectId,
        createProject,
        updateProject,
        deleteProject,
        updateProjectProgress,
        toggleMilestone,

        tasks: evaluatedTasks,
        createTask,
        updateTask,
        deleteTask,
        updateTaskStatus,

        progressUpdates,
        submitProgressUpdate,

        messages,
        sendMessage,
        markMessagesAsRead,

        documents,
        uploadDocument,
        deleteDocument,

        notifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,

        activities,

        resetToDefaultData,
        currentDateStr
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
