import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  Task,
  Habit,
  Goal,
  DailyPrayers,
  QuranProgress,
  IslamicDhikrItem,
  UserProfile,
  ActiveTab,
} from '../types';
import { translations, Translations } from '../i18n/translations';
import { triggerCelebration, triggerBigCelebration } from '../utils/confetti';
import { playTaskCompletionSound } from '../utils/audioManager';

interface AppContextType {
  // Navigation & UI
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  language: 'en' | 'bn';
  setLanguage: (lang: 'en' | 'bn') => void;
  t: Translations;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  selectedDate: string; // YYYY-MM-DD
  setSelectedDate: (date: string) => void;

  // Data
  tasks: Task[];
  habits: Habit[];
  goals: Goal[];
  prayers: Record<string, DailyPrayers>;
  quran: QuranProgress;
  dhikr: IslamicDhikrItem[];
  profile: UserProfile;

  // Task Actions
  addTask: (task: Omit<Task, 'id' | 'createdAt'>) => Task;
  updateTask: (task: Task) => void;
  deleteTask: (id: string) => void;
  toggleTaskCompleted: (id: string) => void;

  // Habit Actions
  addHabit: (habit: Omit<Habit, 'id' | 'history' | 'currentStreak' | 'bestStreak' | 'createdAt'>) => Habit;
  updateHabit: (habit: Habit) => void;
  deleteHabit: (id: string) => void;
  incrementHabitCount: (id: string, date?: string) => void;
  decrementHabitCount: (id: string, date?: string) => void;

  // Goal Actions
  addGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => Goal;
  updateGoal: (goal: Goal) => void;
  deleteGoal: (id: string) => void;
  toggleGoalMilestone: (goalId: string, milestoneId: string) => void;
  updateGoalProgress: (goalId: string, progress: number) => void;

  // Prayer Actions
  togglePrayer: (prayerKey: keyof DailyPrayers, date?: string) => void;
  setPrayerTime: (prayerKey: keyof DailyPrayers, timeStr: string, date?: string) => void;
  setPrayerWaqtTimes: (prayerKey: string, startTime: string, endTime: string, date?: string) => void;

  // Quran Actions
  updateQuran: (progress: Partial<QuranProgress>) => void;
  addQuranPages: (pages: number) => void;

  // Dhikr Actions
  incrementDhikr: (id: string) => void;
  resetDhikr: (id: string) => void;
  resetAllDhikr: () => void;

  // Profile Actions
  updateProfile: (profile: Partial<UserProfile>) => void;

  // Data Management
  exportData: () => string;
  importData: (jsonStr: string) => boolean;
  clearAllData: () => void;
  resetToDefaultData: () => void;

  // Reminders & Notifications
  notificationStatus: NotificationPermission | 'unsupported';
  requestNotificationPermission: () => Promise<boolean>;

  // Metrics
  todayMetrics: {
    tasksTotal: number;
    tasksDone: number;
    habitsTotal: number;
    habitsDone: number;
    prayersTotal: number;
    prayersDone: number;
    overallPercent: number;
    currentStreak: number;
    bestStreak: number;
  };
  weeklyActivity: Array<{
    date: string;
    dayLabel: string;
    percent: number;
    isToday: boolean;
  }>;
}

const STORAGE_KEYS = {
  TASKS: 'habivio_tasks_v1',
  HABITS: 'habivio_habits_v1',
  GOALS: 'habivio_goals_v1',
  PRAYERS: 'habivio_prayers_v1',
  QURAN: 'habivio_quran_v1',
  DHIKR: 'habivio_dhikr_v1',
  PROFILE: 'habivio_profile_v1',
};

export function getTodayString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

const DEFAULT_PROFILE: UserProfile = {
  name: 'Ahmad Mir',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  title: 'Focused Professional & Lifelong Learner',
  dailyTaskTarget: 4,
  dailyHabitTarget: 3,
  dailyQuranPagesTarget: 4,
  language: 'en',
  theme: 'light',
  notificationsEnabled: false,
  soundEnabled: true,
};

const DEFAULT_TASKS: Task[] = [
  {
    id: 't-1',
    title: 'Review Q4 Project Deliverables & Roadmap',
    notes: 'Verify team milestones and client feedback notes.',
    dueDate: getTodayString(),
    dueTime: '10:30',
    priority: 'high',
    category: 'work',
    completed: true,
    completedAt: new Date().toISOString(),
    isRoutine: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-2',
    title: 'Morning Quran Recitation & Reflection',
    notes: 'Surah Al-Mulk with English translation study.',
    dueDate: getTodayString(),
    dueTime: '06:30',
    priority: 'high',
    category: 'worship',
    completed: true,
    completedAt: new Date().toISOString(),
    isRoutine: true,
    routineFrequency: 'daily',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-3',
    title: '30-minute Brisk Walk & Mobility Stretch',
    notes: 'Focus on posture and deep breathing outdoors.',
    dueDate: getTodayString(),
    dueTime: '17:30',
    priority: 'medium',
    category: 'health',
    completed: false,
    isRoutine: true,
    routineFrequency: 'daily',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-4',
    title: 'Read 20 pages of Strategic Thinking book',
    notes: 'Highlight core mental models and take quick notes.',
    dueDate: getTodayString(),
    dueTime: '21:00',
    priority: 'low',
    category: 'study',
    completed: false,
    isRoutine: false,
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_HABITS: Habit[] = [
  {
    id: 'h-1',
    title: 'Hydration (8 Glasses)',
    description: 'Keep water bottle nearby and stay energized.',
    category: 'health',
    frequency: 'daily',
    targetCount: 8,
    unit: 'glasses',
    color: '#0284c7',
    iconName: 'Droplets',
    history: {
      [getTodayString()]: 6,
    },
    currentStreak: 5,
    bestStreak: 14,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'h-2',
    title: 'Daily Quran Recitation',
    description: 'Connect with Allah’s words every day.',
    category: 'worship',
    frequency: 'daily',
    targetCount: 4,
    unit: 'pages',
    color: '#7c3aed',
    iconName: 'BookOpen',
    history: {
      [getTodayString()]: 4,
    },
    currentStreak: 12,
    bestStreak: 30,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'h-3',
    title: 'Physical Exercise / Steps',
    description: 'At least 30 mins or 8,000 steps.',
    category: 'fitness',
    frequency: 'daily',
    targetCount: 1,
    unit: 'times',
    color: '#10b981',
    iconName: 'Activity',
    history: {
      [getTodayString()]: 1,
    },
    currentStreak: 4,
    bestStreak: 21,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'h-4',
    title: 'Evening Journaling & Wind-down',
    description: 'Reflect on 3 gratitude moments and plan tomorrow.',
    category: 'mindfulness',
    frequency: 'daily',
    targetCount: 1,
    unit: 'times',
    color: '#f59e0b',
    iconName: 'Moon',
    history: {},
    currentStreak: 3,
    bestStreak: 9,
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_GOALS: Goal[] = [
  {
    id: 'g-1',
    title: 'Memorize Juz Amma (Last 30 Surahs)',
    description: 'Deepen personal prayer and connection to the Quran.',
    category: 'spiritual',
    targetDate: '2026-12-31',
    progress: 70,
    milestones: [
      { id: 'm-1', title: 'Memorize Surah An-Naba to Al-Mutaffifin', completed: true },
      { id: 'm-2', title: 'Memorize Al-Inshiqaq to Al-Balad', completed: true },
      { id: 'm-3', title: 'Memorize Ash-Shams to An-Nas', completed: true },
      { id: 'm-4', title: 'Consolidate full Juz recitation with Tajweed teacher', completed: false },
    ],
    color: '#8b5cf6',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'g-2',
    title: 'Build Resilient Health & Run 5K Endurance',
    description: 'Improve cardiovascular health, sleep quality, and daily energy.',
    category: 'health',
    targetDate: '2026-11-30',
    progress: 60,
    milestones: [
      { id: 'm-21', title: 'Run continuous 2 km without fatigue', completed: true },
      { id: 'm-22', title: 'Run continuous 3.5 km at consistent pace', completed: true },
      { id: 'm-23', title: 'Complete full 5 km official weekend run', completed: false },
    ],
    color: '#0284c7',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'g-3',
    title: 'Master Modern Cloud System Architecture',
    description: 'Acquire practical knowledge in scalable distributed systems.',
    category: 'career',
    targetDate: '2027-01-15',
    progress: 40,
    milestones: [
      { id: 'm-31', title: 'Finish microservices design patterns module', completed: true },
      { id: 'm-32', title: 'Build and deploy full-stack resilience lab', completed: false },
      { id: 'm-33', title: 'Pass certification mock assessment', completed: false },
    ],
    color: '#ec4899',
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_PRAYERS: Record<string, DailyPrayers> = {
  [getTodayString()]: {
    fajr: true,
    dhuhr: true,
    asr: true,
    maghrib: false,
    isha: false,
    tahajjud: true,
    fajrTime: '05:15',
    dhuhrTime: '12:45',
    asrTime: '16:10',
    fajrStart: '05:00',
    fajrEnd: '06:15',
    dhuhrStart: '12:05',
    dhuhrEnd: '15:45',
    asrStart: '15:45',
    asrEnd: '17:35',
    maghribStart: '17:35',
    maghribEnd: '18:50',
    ishaStart: '18:50',
    ishaEnd: '05:00',
    tahajjudStart: '03:30',
    tahajjudEnd: '05:00',
  },
};

const DEFAULT_QURAN: QuranProgress = {
  currentSurah: 67, // Al-Mulk
  currentAyah: 15,
  pagesReadToday: 4,
  dailyGoalPages: 4,
  lastReadDate: getTodayString(),
  totalFinishedTimes: 2,
  favoriteSurah: 'Al-Kahf',
  notes: 'Memorizing key thematic passages in Juz 29.',
};

const DEFAULT_DHIKR: IslamicDhikrItem[] = [
  {
    id: 'd-1',
    title: 'SubhanAllah (Glory be to Allah)',
    arabic: 'سُبْحَانَ اللَّهِ',
    meaning: 'Glory be to Allah',
    targetCount: 33,
    currentCount: 33,
    completed: true,
    category: 'general',
  },
  {
    id: 'd-2',
    title: 'Alhamdulillah (Praise be to Allah)',
    arabic: 'الْحَمْدُ لِلَّهِ',
    meaning: 'All praise is for Allah alone',
    targetCount: 33,
    currentCount: 33,
    completed: true,
    category: 'general',
  },
  {
    id: 'd-3',
    title: 'Allahu Akbar (Allah is Greatest)',
    arabic: 'اللَّهُ أَكْبَرُ',
    meaning: 'Allah is the Greatest',
    targetCount: 34,
    currentCount: 34,
    completed: true,
    category: 'general',
  },
  {
    id: 'd-4',
    title: 'Astaghfirullah (Seek Forgiveness)',
    arabic: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ',
    meaning: 'I seek forgiveness from Allah and repent to Him',
    targetCount: 100,
    currentCount: 65,
    completed: false,
    category: 'morning',
  },
  {
    id: 'd-5',
    title: 'Salawat on the Prophet ﷺ',
    arabic: 'اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَعَلَىٰ آلِ مُحَمَّدٍ',
    meaning: 'O Allah, send blessings upon Muhammad and the family of Muhammad',
    targetCount: 100,
    currentCount: 40,
    completed: false,
    category: 'sunnah',
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  // Navigation
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [selectedDate, setSelectedDate] = useState<string>(getTodayString());

  // Load state from localStorage safely
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return saved ? { ...DEFAULT_PROFILE, ...JSON.parse(saved) } : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TASKS);
      return saved ? JSON.parse(saved) : DEFAULT_TASKS;
    } catch {
      return DEFAULT_TASKS;
    }
  });

  const [habits, setHabits] = useState<Habit[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HABITS);
      return saved ? JSON.parse(saved) : DEFAULT_HABITS;
    } catch {
      return DEFAULT_HABITS;
    }
  });

  const [goals, setGoals] = useState<Goal[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GOALS);
      return saved ? JSON.parse(saved) : DEFAULT_GOALS;
    } catch {
      return DEFAULT_GOALS;
    }
  });

  const [prayers, setPrayers] = useState<Record<string, DailyPrayers>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRAYERS);
      return saved ? JSON.parse(saved) : DEFAULT_PRAYERS;
    } catch {
      return DEFAULT_PRAYERS;
    }
  });

  const [quran, setQuran] = useState<QuranProgress>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.QURAN);
      return saved ? { ...DEFAULT_QURAN, ...JSON.parse(saved) } : DEFAULT_QURAN;
    } catch {
      return DEFAULT_QURAN;
    }
  });

  const [dhikr, setDhikr] = useState<IslamicDhikrItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DHIKR);
      return saved ? JSON.parse(saved) : DEFAULT_DHIKR;
    } catch {
      return DEFAULT_DHIKR;
    }
  });

  // Notification status
  const [notificationStatus, setNotificationStatus] = useState<NotificationPermission | 'unsupported'>('unsupported');

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotificationStatus(Notification.permission);
    }
  }, []);

  // Sync theme with DOM
  useEffect(() => {
    const root = document.documentElement;
    if (profile.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [profile.theme]);

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch (e) {
      console.warn('Storage error:', e);
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
    } catch (e) {
      console.warn('Storage error:', e);
    }
  }, [tasks]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HABITS, JSON.stringify(habits));
    } catch (e) {
      console.warn('Storage error:', e);
    }
  }, [habits]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.GOALS, JSON.stringify(goals));
    } catch (e) {
      console.warn('Storage error:', e);
    }
  }, [goals]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PRAYERS, JSON.stringify(prayers));
    } catch (e) {
      console.warn('Storage error:', e);
    }
  }, [prayers]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.QURAN, JSON.stringify(quran));
    } catch (e) {
      console.warn('Storage error:', e);
    }
  }, [quran]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.DHIKR, JSON.stringify(dhikr));
    } catch (e) {
      console.warn('Storage error:', e);
    }
  }, [dhikr]);

  // Language & Translation
  const language = profile.language;
  const setLanguage = (lang: 'en' | 'bn') => {
    setProfile((prev) => ({ ...prev, language: lang }));
  };
  const t = translations[language] || translations.en;

  const toggleTheme = () => {
    setProfile((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark',
    }));
  };

  const updateProfile = (changes: Partial<UserProfile>) => {
    setProfile((prev) => ({ ...prev, ...changes }));
  };

  // Notification permission requester
  const requestNotificationPermission = async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setNotificationStatus('unsupported');
      return false;
    }
    try {
      const permission = await Notification.requestPermission();
      setNotificationStatus(permission);
      if (permission === 'granted') {
        setProfile((prev) => ({ ...prev, notificationsEnabled: true }));
        try {
          new Notification('Habivio Reminders Enabled', {
            body: 'You will receive reminders for scheduled tasks.',
            icon: '/favicon.ico',
          });
        } catch {
          // ignore
        }
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  // Task Actions
  const addTask = (taskData: Omit<Task, 'id' | 'createdAt'>): Task => {
    const newTask: Task = {
      ...taskData,
      id: `task-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
    };
    setTasks((prev) => [newTask, ...prev]);
    return newTask;
  };

  const updateTask = (updated: Task) => {
    setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const toggleTaskCompleted = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const nextCompleted = !t.completed;
          if (nextCompleted) {
            triggerCelebration(0.65);
            playTaskCompletionSound();
          }
          return {
            ...t,
            completed: nextCompleted,
            completedAt: nextCompleted ? new Date().toISOString() : null,
          };
        }
        return t;
      })
    );
  };

  // Habit Actions
  const addHabit = (
    habitData: Omit<Habit, 'id' | 'history' | 'currentStreak' | 'bestStreak' | 'createdAt'>
  ): Habit => {
    const newHabit: Habit = {
      ...habitData,
      id: `habit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      history: {},
      currentStreak: 0,
      bestStreak: 0,
      createdAt: new Date().toISOString(),
    };
    setHabits((prev) => [...prev, newHabit]);
    return newHabit;
  };

  const updateHabit = (updated: Habit) => {
    setHabits((prev) => prev.map((h) => (h.id === updated.id ? updated : h)));
  };

  const deleteHabit = (id: string) => {
    setHabits((prev) => prev.filter((h) => h.id !== id));
  };

  const incrementHabitCount = (id: string, date = getTodayString()) => {
    setHabits((prev) =>
      prev.map((habit) => {
        if (habit.id === id) {
          const currentCount = habit.history[date] || 0;
          const nextCount = currentCount + 1;
          const updatedHistory = { ...habit.history, [date]: nextCount };

          // Re-calculate streak
          let streak = 0;
          const checkDate = new Date();
          // check backwards
          for (let i = 0; i < 90; i++) {
            const d = new Date(checkDate);
            d.setDate(d.getDate() - i);
            const ds = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
              d.getDate()
            ).padStart(2, '0')}`;
            const count = updatedHistory[ds] || 0;
            if (count >= habit.targetCount) {
              streak++;
            } else if (i === 0 && count > 0) {
              // today partially done, count towards streak if user is working on it
              streak++;
            } else if (i > 0) {
              break;
            }
          }

          if (nextCount >= habit.targetCount) {
            triggerCelebration(0.5);
          }

          return {
            ...habit,
            history: updatedHistory,
            currentStreak: Math.max(streak, habit.currentStreak),
            bestStreak: Math.max(habit.bestStreak, streak),
          };
        }
        return habit;
      })
    );
  };

  const decrementHabitCount = (id: string, date = getTodayString()) => {
    setHabits((prev) =>
      prev.map((habit) => {
        if (habit.id === id) {
          const currentCount = habit.history[date] || 0;
          const nextCount = Math.max(0, currentCount - 1);
          const updatedHistory = { ...habit.history, [date]: nextCount };
          return {
            ...habit,
            history: updatedHistory,
          };
        }
        return habit;
      })
    );
  };

  // Goal Actions
  const addGoal = (goalData: Omit<Goal, 'id' | 'createdAt'>): Goal => {
    const newGoal: Goal = {
      ...goalData,
      id: `goal-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
    };
    setGoals((prev) => [...prev, newGoal]);
    return newGoal;
  };

  const updateGoal = (updated: Goal) => {
    setGoals((prev) => prev.map((g) => (g.id === updated.id ? updated : g)));
  };

  const deleteGoal = (id: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== id));
  };

  const toggleGoalMilestone = (goalId: string, milestoneId: string) => {
    setGoals((prev) =>
      prev.map((goal) => {
        if (goal.id === goalId) {
          const updatedMilestones = goal.milestones.map((m) =>
            m.id === milestoneId ? { ...m, completed: !m.completed } : m
          );
          const completedCount = updatedMilestones.filter((m) => m.completed).length;
          const computedProgress =
            updatedMilestones.length > 0
              ? Math.round((completedCount / updatedMilestones.length) * 100)
              : goal.progress;

          if (computedProgress === 100) {
            triggerBigCelebration();
          } else {
            triggerCelebration();
          }

          return {
            ...goal,
            milestones: updatedMilestones,
            progress: computedProgress,
          };
        }
        return goal;
      })
    );
  };

  const updateGoalProgress = (goalId: string, progress: number) => {
    setGoals((prev) =>
      prev.map((goal) => {
        if (goal.id === goalId) {
          const nextProgress = Math.min(100, Math.max(0, progress));
          if (nextProgress === 100 && goal.progress < 100) {
            triggerBigCelebration();
          }
          return { ...goal, progress: nextProgress };
        }
        return goal;
      })
    );
  };

  // Prayer Actions
  const togglePrayer = (prayerKey: keyof DailyPrayers, date = getTodayString()) => {
    setPrayers((prev) => {
      const todayRecord = prev[date] || {
        fajr: false,
        dhuhr: false,
        asr: false,
        maghrib: false,
        isha: false,
        tahajjud: false,
      };

      const nextVal = !todayRecord[prayerKey];
      if (nextVal) {
        triggerCelebration(0.7);
      }

      return {
        ...prev,
        [date]: {
          ...todayRecord,
          [prayerKey]: nextVal,
        },
      };
    });
  };

  const setPrayerTime = (prayerKey: keyof DailyPrayers, timeStr: string, date = getTodayString()) => {
    setPrayers((prev) => {
      const current = prev[date] || {
        fajr: false,
        dhuhr: false,
        asr: false,
        maghrib: false,
        isha: false,
        tahajjud: false,
      };
      return {
        ...prev,
        [date]: {
          ...current,
          [`${String(prayerKey)}Time`]: timeStr,
        },
      };
    });
  };

  const setPrayerWaqtTimes = (prayerKey: string, startTime: string, endTime: string, date = getTodayString()) => {
    setPrayers((prev) => {
      const current = prev[date] || {
        fajr: false,
        dhuhr: false,
        asr: false,
        maghrib: false,
        isha: false,
        tahajjud: false,
      };
      return {
        ...prev,
        [date]: {
          ...current,
          [`${prayerKey}Start`]: startTime,
          [`${prayerKey}End`]: endTime,
        },
      };
    });
  };

  // Quran Actions
  const updateQuran = (changes: Partial<QuranProgress>) => {
    setQuran((prev) => ({
      ...prev,
      ...changes,
      lastReadDate: getTodayString(),
    }));
  };

  const addQuranPages = (delta: number) => {
    setQuran((prev) => {
      const nextPages = Math.max(0, prev.pagesReadToday + delta);
      if (nextPages >= prev.dailyGoalPages && prev.pagesReadToday < prev.dailyGoalPages) {
        triggerCelebration(0.6);
      }
      return {
        ...prev,
        pagesReadToday: nextPages,
        lastReadDate: getTodayString(),
      };
    });
  };

  // Dhikr Actions
  const incrementDhikr = (id: string) => {
    setDhikr((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nextCount = item.currentCount + 1;
          const completed = nextCount >= item.targetCount;
          if (completed && !item.completed) {
            triggerCelebration(0.6);
          }
          return {
            ...item,
            currentCount: nextCount,
            completed,
          };
        }
        return item;
      })
    );
  };

  const resetDhikr = (id: string) => {
    setDhikr((prev) =>
      prev.map((item) => (item.id === id ? { ...item, currentCount: 0, completed: false } : item))
    );
  };

  const resetAllDhikr = () => {
    setDhikr((prev) => prev.map((item) => ({ ...item, currentCount: 0, completed: false })));
  };

  // Data Import / Export
  const exportData = () => {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      profile,
      tasks,
      habits,
      goals,
      prayers,
      quran,
      dhikr,
    };
    return JSON.stringify(backup, null, 2);
  };

  const importData = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (!parsed || typeof parsed !== 'object') return false;

      if (parsed.profile) setProfile(parsed.profile);
      if (Array.isArray(parsed.tasks)) setTasks(parsed.tasks);
      if (Array.isArray(parsed.habits)) setHabits(parsed.habits);
      if (Array.isArray(parsed.goals)) setGoals(parsed.goals);
      if (parsed.prayers) setPrayers(parsed.prayers);
      if (parsed.quran) setQuran(parsed.quran);
      if (Array.isArray(parsed.dhikr)) setDhikr(parsed.dhikr);
      return true;
    } catch {
      return false;
    }
  };

  const clearAllData = () => {
    setTasks([]);
    setHabits([]);
    setGoals([]);
    setPrayers({});
    setQuran({
      currentSurah: 1,
      currentAyah: 1,
      pagesReadToday: 0,
      dailyGoalPages: 4,
      lastReadDate: getTodayString(),
      totalFinishedTimes: 0,
    });
    setDhikr(DEFAULT_DHIKR.map((d) => ({ ...d, currentCount: 0, completed: false })));
    localStorage.clear();
  };

  const resetToDefaultData = () => {
    setTasks(DEFAULT_TASKS);
    setHabits(DEFAULT_HABITS);
    setGoals(DEFAULT_GOALS);
    setPrayers(DEFAULT_PRAYERS);
    setQuran(DEFAULT_QURAN);
    setDhikr(DEFAULT_DHIKR);
    setProfile(DEFAULT_PROFILE);
  };

  // Metrics calculation
  const todayStr = getTodayString();

  const todayMetrics = useMemo(() => {
    // Tasks today
    const todaysTasks = tasks.filter((t) => t.dueDate === todayStr || t.isRoutine);
    const tasksTotal = todaysTasks.length;
    const tasksDone = todaysTasks.filter((t) => t.completed).length;

    // Habits today
    const habitsTotal = habits.length;
    const habitsDone = habits.filter((h) => (h.history[todayStr] || 0) >= h.targetCount).length;

    // Prayers today (5 obligatory)
    const todayPrayers = prayers[todayStr] || {
      fajr: false,
      dhuhr: false,
      asr: false,
      maghrib: false,
      isha: false,
      tahajjud: false,
    };
    const obligatoryKeys: Array<keyof DailyPrayers> = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
    const prayersTotal = 5;
    const prayersDone = obligatoryKeys.filter((k) => todayPrayers[k]).length;

    // Overall completion percentage
    const totalWeightedItems = tasksTotal + habitsTotal + prayersTotal;
    const completedWeightedItems = tasksDone + habitsDone + prayersDone;
    const overallPercent =
      totalWeightedItems > 0 ? Math.round((completedWeightedItems / totalWeightedItems) * 100) : 0;

    // Compute active streak (based on days where habits or prayers were actively completed)
    const habitStreaks = habits.map((h) => h.currentStreak);
    const bestHabitStreaks = habits.map((h) => h.bestStreak);
    const currentStreak = habitStreaks.length > 0 ? Math.max(...habitStreaks, 1) : 0;
    const bestStreak = bestHabitStreaks.length > 0 ? Math.max(...bestHabitStreaks, currentStreak) : 0;

    return {
      tasksTotal,
      tasksDone,
      habitsTotal,
      habitsDone,
      prayersTotal,
      prayersDone,
      overallPercent,
      currentStreak,
      bestStreak,
    };
  }, [tasks, habits, prayers, todayStr]);

  // Weekly Activity for visual progress chart (past 7 days)
  const weeklyActivity = useMemo(() => {
    const days: Array<{ date: string; dayLabel: string; percent: number; isToday: boolean }> = [];
    const dayNames = language === 'bn' 
      ? ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি']
      : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const ds = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
        d.getDate()
      ).padStart(2, '0')}`;
      const dayLabel = dayNames[d.getDay()];
      const isToday = ds === todayStr;

      // Estimate activity for that day
      let dayPoints = 0;
      let totalPoints = 0;

      // Check prayers
      const p = prayers[ds];
      if (p) {
        const pKeys: Array<keyof DailyPrayers> = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
        totalPoints += 5;
        dayPoints += pKeys.filter((k) => p[k]).length;
      } else {
        totalPoints += 5;
      }

      // Check habits
      habits.forEach((h) => {
        totalPoints += 1;
        if ((h.history[ds] || 0) >= h.targetCount) {
          dayPoints += 1;
        }
      });

      // Check tasks
      const dayTasks = tasks.filter((t) => t.dueDate === ds);
      if (dayTasks.length > 0) {
        totalPoints += dayTasks.length;
        dayPoints += dayTasks.filter((t) => t.completed).length;
      }

      const percent = totalPoints > 0 ? Math.round((dayPoints / totalPoints) * 100) : 0;
      days.push({
        date: ds,
        dayLabel,
        percent: Math.min(100, percent),
        isToday,
      });
    }

    return days;
  }, [prayers, habits, tasks, todayStr, language]);

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        language,
        setLanguage,
        t,
        theme: profile.theme,
        toggleTheme,
        selectedDate,
        setSelectedDate,

        tasks,
        habits,
        goals,
        prayers,
        quran,
        dhikr,
        profile,

        addTask,
        updateTask,
        deleteTask,
        toggleTaskCompleted,

        addHabit,
        updateHabit,
        deleteHabit,
        incrementHabitCount,
        decrementHabitCount,

        addGoal,
        updateGoal,
        deleteGoal,
        toggleGoalMilestone,
        updateGoalProgress,

        togglePrayer,
        setPrayerTime,
        setPrayerWaqtTimes,

        updateQuran,
        addQuranPages,

        incrementDhikr,
        resetDhikr,
        resetAllDhikr,

        updateProfile,

        exportData,
        importData,
        clearAllData,
        resetToDefaultData,

        notificationStatus,
        requestNotificationPermission,

        todayMetrics,
        weeklyActivity,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
