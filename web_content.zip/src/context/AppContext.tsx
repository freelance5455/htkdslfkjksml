import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import {
  TabType,
  Language,
  ThemeMode,
  AngleMode,
  CalculationHistoryItem,
  NoteItem,
  TodoItem,
  ShoppingItem,
  ExpenseSplit,
  DeviceSpecs,
  UserSettings,
} from '../types';
import { getDeviceSpecs } from '../utils/deviceDiagnostics';

const DEFAULT_SETTINGS: UserSettings = {
  theme: 'system',
  language: 'en',
  hapticFeedback: true,
  angleMode: 'deg',
  saveHistory: true,
  maxHistoryItems: 100,
  dashboardCards: {
    device: true,
    battery: true,
    storage: true,
    memory: true,
    network: true,
    shortcuts: true,
  },
};

interface ToastMessage {
  id: string;
  text: string;
  type?: 'info' | 'success' | 'warning';
}

interface AppContextType {
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
  settings: UserSettings;
  updateSettings: (newSettings: Partial<UserSettings>) => void;
  deviceSpecs: DeviceSpecs | null;
  refreshDeviceSpecs: () => Promise<void>;
  isLoadingSpecs: boolean;

  // Haptics & Feedback
  triggerHaptic: () => void;
  toasts: ToastMessage[];
  showToast: (text: string, type?: 'info' | 'success' | 'warning') => void;

  // History
  history: CalculationHistoryItem[];
  addHistoryItem: (expression: string, result: string, category?: CalculationHistoryItem['category']) => void;
  deleteHistoryItem: (id: string) => void;
  clearHistory: () => void;

  // Notes
  notes: NoteItem[];
  addNote: (title: string, content: string, category?: string) => void;
  updateNote: (id: string, updates: Partial<NoteItem>) => void;
  deleteNote: (id: string) => void;

  // Todos
  todos: TodoItem[];
  addTodo: (text: string, priority?: TodoItem['priority'], dueDate?: string) => void;
  toggleTodo: (id: string) => void;
  deleteTodo: (id: string) => void;

  // Shopping List
  shoppingList: ShoppingItem[];
  addShoppingItem: (name: string, quantity: string, estimatedPrice?: number, category?: string) => void;
  toggleShoppingItem: (id: string) => void;
  deleteShoppingItem: (id: string) => void;
  clearCheckedShopping: () => void;

  // Expense Splitter
  expenses: ExpenseSplit[];
  addExpense: (expense: Omit<ExpenseSplit, 'id' | 'date'>) => void;
  deleteExpense: (id: string) => void;

  // Device Frame Toggle (for desktop testing / preview mode)
  phoneFrameMode: boolean;
  togglePhoneFrameMode: () => void;

  // Data management
  exportAllData: () => string;
  importAllData: (jsonStr: string) => boolean;
  clearAllAppData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [phoneFrameMode, setPhoneFrameMode] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Settings
  const [settings, setSettings] = useState<UserSettings>(() => {
    try {
      const saved = localStorage.getItem('ptk_settings');
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // History
  const [history, setHistory] = useState<CalculationHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('ptk_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Notes
  const [notes, setNotes] = useState<NoteItem[]>(() => {
    try {
      const saved = localStorage.getItem('ptk_notes');
      return saved
        ? JSON.parse(saved)
        : [
            {
              id: 'sample-1',
              title: 'Welcome to Pocket Toolkit',
              content:
                'Pocket Toolkit is an all-in-one offline Android utility application created by Syed Salman Mehdi.\n\nAll tools, calculations, notes, and records are stored 100% locally on your device.',
              isPinned: true,
              category: 'General',
              createdAt: Date.now(),
              updatedAt: Date.now(),
            },
          ];
    } catch {
      return [];
    }
  });

  // Todos
  const [todos, setTodos] = useState<TodoItem[]>(() => {
    try {
      const saved = localStorage.getItem('ptk_todos');
      return saved
        ? JSON.parse(saved)
        : [
            { id: 'todo-1', text: 'Explore scientific calculator', completed: true, priority: 'high', createdAt: Date.now() - 3600000 },
            { id: 'todo-2', text: 'Test offline unit converter & privacy tools', completed: false, priority: 'medium', createdAt: Date.now() },
            { id: 'todo-3', text: 'Download Android Studio project ZIP', completed: false, priority: 'high', createdAt: Date.now() },
          ];
    } catch {
      return [];
    }
  });

  // Shopping List
  const [shoppingList, setShoppingList] = useState<ShoppingItem[]>(() => {
    try {
      const saved = localStorage.getItem('ptk_shopping');
      return saved
        ? JSON.parse(saved)
        : [
            { id: 'shop-1', name: 'USB-C Cable', quantity: '1 pc', estimatedPrice: 15, checked: false, category: 'Tech' },
            { id: 'shop-2', name: 'Notebook', quantity: '2 pcs', estimatedPrice: 8, checked: true, category: 'Stationery' },
          ];
    } catch {
      return [];
    }
  });

  // Expenses
  const [expenses, setExpenses] = useState<ExpenseSplit[]>(() => {
    try {
      const saved = localStorage.getItem('ptk_expenses');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Device specs
  const [deviceSpecs, setDeviceSpecs] = useState<DeviceSpecs | null>(null);
  const [isLoadingSpecs, setIsLoadingSpecs] = useState<boolean>(false);

  const refreshDeviceSpecs = async () => {
    setIsLoadingSpecs(true);
    try {
      const specs = await getDeviceSpecs();
      setDeviceSpecs(specs);
    } catch (e) {
      console.error('Error fetching device specs:', e);
    } finally {
      setIsLoadingSpecs(false);
    }
  };

  useEffect(() => {
    refreshDeviceSpecs();

    // Listen for online/offline changes
    const handleOnline = () => refreshDeviceSpecs();
    const handleOffline = () => refreshDeviceSpecs();
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Theme Syncing
  useEffect(() => {
    const root = document.documentElement;
    const isDark =
      settings.theme === 'dark' ||
      (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem('ptk_settings', JSON.stringify(settings));
    } catch {}
  }, [settings]);

  // Sync state to local storage
  useEffect(() => {
    try {
      localStorage.setItem('ptk_history', JSON.stringify(history));
    } catch {}
  }, [history]);

  useEffect(() => {
    try {
      localStorage.setItem('ptk_notes', JSON.stringify(notes));
    } catch {}
  }, [notes]);

  useEffect(() => {
    try {
      localStorage.setItem('ptk_todos', JSON.stringify(todos));
    } catch {}
  }, [todos]);

  useEffect(() => {
    try {
      localStorage.setItem('ptk_shopping', JSON.stringify(shoppingList));
    } catch {}
  }, [shoppingList]);

  useEffect(() => {
    try {
      localStorage.setItem('ptk_expenses', JSON.stringify(expenses));
    } catch {}
  }, [expenses]);

  const triggerHaptic = () => {
    if (settings.hapticFeedback && typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(12);
      } catch {}
    }
  };

  const showToast = (text: string, type: 'info' | 'success' | 'warning' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 2800);
  };

  const updateSettings = (newSettings: Partial<UserSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
    showToast('Settings saved', 'success');
  };

  // History operations
  const addHistoryItem = (expression: string, result: string, category: CalculationHistoryItem['category'] = 'scientific') => {
    if (!settings.saveHistory) return;
    const newItem: CalculationHistoryItem = {
      id: Math.random().toString(36).substring(2, 9),
      expression,
      result,
      timestamp: Date.now(),
      category,
    };
    setHistory((prev) => [newItem, ...prev.slice(0, settings.maxHistoryItems - 1)]);
  };

  const deleteHistoryItem = (id: string) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
  };

  const clearHistory = () => {
    setHistory([]);
    showToast('Calculation history cleared', 'info');
  };

  // Notes operations
  const addNote = (title: string, content: string, category: string = 'General') => {
    const newNote: NoteItem = {
      id: Math.random().toString(36).substring(2, 9),
      title: title || 'Untitled Note',
      content,
      isPinned: false,
      category,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setNotes((prev) => [newNote, ...prev]);
    showToast('Note created', 'success');
  };

  const updateNote = (id: string, updates: Partial<NoteItem>) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, ...updates, updatedAt: Date.now() } : n))
    );
    showToast('Note updated', 'success');
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    showToast('Note deleted', 'info');
  };

  // Todo operations
  const addTodo = (text: string, priority: TodoItem['priority'] = 'medium', dueDate?: string) => {
    if (!text.trim()) return;
    const newTodo: TodoItem = {
      id: Math.random().toString(36).substring(2, 9),
      text: text.trim(),
      completed: false,
      priority,
      dueDate,
      createdAt: Date.now(),
    };
    setTodos((prev) => [newTodo, ...prev]);
    showToast('Task added', 'success');
  };

  const toggleTodo = (id: string) => {
    triggerHaptic();
    setTodos((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const deleteTodo = (id: string) => {
    setTodos((prev) => prev.filter((t) => t.id !== id));
  };

  // Shopping list operations
  const addShoppingItem = (name: string, quantity: string, estimatedPrice?: number, category: string = 'General') => {
    if (!name.trim()) return;
    const newItem: ShoppingItem = {
      id: Math.random().toString(36).substring(2, 9),
      name: name.trim(),
      quantity: quantity.trim() || '1',
      estimatedPrice,
      checked: false,
      category,
    };
    setShoppingList((prev) => [newItem, ...prev]);
    showToast('Item added', 'success');
  };

  const toggleShoppingItem = (id: string) => {
    triggerHaptic();
    setShoppingList((prev) =>
      prev.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item))
    );
  };

  const deleteShoppingItem = (id: string) => {
    setShoppingList((prev) => prev.filter((item) => item.id !== id));
  };

  const clearCheckedShopping = () => {
    setShoppingList((prev) => prev.filter((item) => !item.checked));
    showToast('Completed items cleared', 'info');
  };

  // Expenses operations
  const addExpense = (expense: Omit<ExpenseSplit, 'id' | 'date'>) => {
    const newExpense: ExpenseSplit = {
      ...expense,
      id: Math.random().toString(36).substring(2, 9),
      date: Date.now(),
    };
    setExpenses((prev) => [newExpense, ...prev]);
    showToast('Expense saved', 'success');
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  };

  const togglePhoneFrameMode = () => {
    setPhoneFrameMode((prev) => !prev);
  };

  // Full backup export
  const exportAllData = (): string => {
    const backup = {
      app: 'Pocket Toolkit',
      developer: 'Syed Salman Mehdi',
      exportDate: new Date().toISOString(),
      settings,
      history,
      notes,
      todos,
      shoppingList,
      expenses,
    };
    return JSON.stringify(backup, null, 2);
  };

  const importAllData = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.settings) setSettings(data.settings);
      if (Array.isArray(data.history)) setHistory(data.history);
      if (Array.isArray(data.notes)) setNotes(data.notes);
      if (Array.isArray(data.todos)) setTodos(data.todos);
      if (Array.isArray(data.shoppingList)) setShoppingList(data.shoppingList);
      if (Array.isArray(data.expenses)) setExpenses(data.expenses);
      showToast('All local data imported successfully', 'success');
      return true;
    } catch (e) {
      showToast('Failed to import data: Invalid file format', 'warning');
      return false;
    }
  };

  const clearAllAppData = () => {
    setHistory([]);
    setNotes([]);
    setTodos([]);
    setShoppingList([]);
    setExpenses([]);
    localStorage.clear();
    showToast('All application data reset', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        currentTab,
        setCurrentTab,
        settings,
        updateSettings,
        deviceSpecs,
        refreshDeviceSpecs,
        isLoadingSpecs,
        triggerHaptic,
        toasts,
        showToast,
        history,
        addHistoryItem,
        deleteHistoryItem,
        clearHistory,
        notes,
        addNote,
        updateNote,
        deleteNote,
        todos,
        addTodo,
        toggleTodo,
        deleteTodo,
        shoppingList,
        addShoppingItem,
        toggleShoppingItem,
        deleteShoppingItem,
        clearCheckedShopping,
        expenses,
        addExpense,
        deleteExpense,
        phoneFrameMode,
        togglePhoneFrameMode,
        exportAllData,
        importAllData,
        clearAllAppData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
