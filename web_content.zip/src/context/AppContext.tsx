import React, { createContext, useContext, useState, useEffect, useRef, useMemo } from 'react';
import { 
  DhikrItem, 
  DhikrProgress, 
  UserSettings, 
  FontSizeOption, 
  ArabicFontOption, 
  TabType,
  InAppNotification,
  AmbientSoundType
} from '../types';
import { ALL_ADHKAR, MORNING_ADHKAR, EVENING_ADHKAR } from '../data/adhkarData';
import { playTapSound, playCompleteSound, playMilestoneSound, triggerVibration } from '../utils/audioFeedback';
import { ambientEngine } from '../utils/ambientSoundService';
import { 
  requestNotificationPermission, 
  sendLocalNotification, 
  checkAndTriggerScheduledReminders, 
  getNotificationStatus,
  getNextReminderInfo,
  NextReminderInfo 
} from '../utils/notificationService';
import { 
  getSolarTimes, 
  requestCoordinates, 
  getSavedCoordinates, 
  SolarTimes,
  UserCoordinates 
} from '../utils/solarTimeService';
import { User, onAuthStateChanged } from 'firebase/auth';
import { collection, onSnapshot } from 'firebase/firestore';
import { 
  auth, 
  db, 
  testConnection, 
  loginWithGoogle, 
  logoutUser, 
  saveFavoriteToFirestore, 
  removeFavoriteFromFirestore, 
  saveTasbeehToFirestore, 
  saveDailyProgressToFirestore 
} from '../services/firebase';

interface AppContextType {
  // Firebase Auth & Cloud Sync
  user: User | null;
  isAuthReady: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  isSyncing: boolean;

  // Navigation
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  openMorningEveningView: (category?: 'morning' | 'evening') => void;
  selectedDhikr: DhikrItem | null;
  openDhikr: (dhikr: DhikrItem) => void;
  closeDhikr: () => void;
  nextDhikr: () => void;
  prevDhikr: () => void;
  showAboutModal: boolean;
  setShowAboutModal: (show: boolean) => void;
  splashDismissed: boolean;
  dismissSplash: () => void;

  // Favorites
  favorites: string[];
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;

  // Daily Counter Progress
  progress: DhikrProgress;
  incrementProgress: (id: string) => void;
  decrementProgress: (id: string) => void;
  resetDhikrProgress: (id: string) => void;
  setProgressValue: (id: string, value: number) => void;
  resetAllProgress: () => void;
  resetCategoryProgress: (category: 'morning' | 'evening') => void;
  getProgressFor: (id: string) => number;

  // Settings
  settings: UserSettings;
  updateSettings: (newSettings: Partial<UserSettings>) => void;
  toggleNotifications: (enable: boolean) => Promise<void>;
  sendTestReminderNotification: () => void;

  // In-App Notification System
  inAppAlert: InAppNotification | null;
  dismissInAppAlert: () => void;
  snoozeInAppAlert: (minutes?: number) => void;
  notificationHistory: InAppNotification[];
  clearNotificationHistory: () => void;
  triggerTestReminder: (category: 'morning' | 'evening') => void;
  showNotificationCenter: boolean;
  setShowNotificationCenter: (show: boolean) => void;
  nextReminderInfo: NextReminderInfo | null;

  // Ambient Soundscape (أصوات السكينة والخشوع)
  ambientType: AmbientSoundType;
  ambientPlaying: boolean;
  ambientVolume: number;
  showAmbientModal: boolean;
  setShowAmbientModal: (show: boolean) => void;
  setAmbientType: (type: AmbientSoundType) => void;
  toggleAmbientPlay: () => void;
  setAmbientVolume: (vol: number) => void;
  setAmbientTimer: (minutes: number) => void;

  // Solar, Geographic Location & Automatic Theme Switching
  solarTimes: SolarTimes;
  userCoordinates: UserCoordinates | null;
  updateUserCoordinates: (coords: UserCoordinates) => void;
  isDetectingLocation: boolean;
  refreshLocationForSolarTimes: (silent?: boolean) => Promise<void>;

  // Cumulative Lifetime Dhikr Count (عداد التسبيح التراكمي طوال فترة الاستخدام)
  totalDhikrCount: number;
  incrementTotalDhikrCount: (amount?: number) => void;
  resetTotalDhikrCount: () => void;

  // Standalone Smart Tasbeeh Counter (عداد التسبيح الرقمي المستقل)
  showTasbeehModal: boolean;
  setShowTasbeehModal: (show: boolean) => void;

  // Toast
  toastMessage: string | null;
  showToast: (msg: string) => void;

  // Active Category filter for the list screen
  selectedCategory: 'all' | 'morning' | 'evening';
  setSelectedCategory: (cat: 'all' | 'morning' | 'evening') => void;
}

const DEFAULT_SETTINGS: UserSettings = {
  darkMode: true,
  themeMode: 'dark',
  amoledMode: false,
  fontSize: 'lg',
  arabicFont: 'cairo',
  vibration: true,
  vibrationMilestone: '33',
  sound: true,
  autoAdvance: true,
  notificationsEnabled: true, // Enabled by default with in-app notifications
  morningNotification: true,
  morningNotificationTime: '06:30',
  eveningNotification: true,
  eveningNotificationTime: '17:30',
  ambientSound: {
    enabled: false,
    type: 'rain',
    volume: 0.5,
    autoPlayInDhikr: false,
  },
  nightReadingMode: 'auto',
  nightWarmthLevel: 'warm',
  selectedReciter: 'alafasy',
};

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation states
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [selectedDhikr, setSelectedDhikr] = useState<DhikrItem | null>(null);
  const [showAboutModal, setShowAboutModal] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'morning' | 'evening'>('all');

  const openMorningEveningView = (category?: 'morning' | 'evening') => {
    if (category) {
      setSelectedCategory(category);
    } else if (selectedCategory !== 'morning' && selectedCategory !== 'evening') {
      const currentHour = new Date().getHours();
      setSelectedCategory(currentHour >= 3 && currentHour < 15 ? 'morning' : 'evening');
    }
    setActiveTab('morning_evening');
  };

  // Splash screen state
  const [splashDismissed, setSplashDismissed] = useState<boolean>(() => {
    return sessionStorage.getItem('hisn_splash_dismissed') === 'true';
  });

  const dismissSplash = () => {
    setSplashDismissed(true);
    sessionStorage.setItem('hisn_splash_dismissed', 'true');
  };

  // Toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 2400);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  // Firebase Authentication & Cloud Sync State
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Initialize connection test and Firebase Auth state listener
  useEffect(() => {
    testConnection();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Google Login & Logout handlers
  const login = async () => {
    try {
      const loggedUser = await loginWithGoogle();
      if (loggedUser) {
        showToast(`مرحباً ${loggedUser.displayName || ''} 🌿 تم تسجيل الدخول بنجاح`);
      }
    } catch (error) {
      console.error('Login error:', error);
      showToast('تعذر تسجيل الدخول عبر Google');
    }
  };

  const logout = async () => {
    try {
      await logoutUser();
      showToast('تم تسجيل الخروج بنجاح');
    } catch (error) {
      console.error('Logout error:', error);
      showToast('تعذر تسجيل الخروج');
    }
  };

  // Favorites state persisted in localStorage
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('hisn_favorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('hisn_favorites', JSON.stringify(favorites));
    } catch {
      // ignore
    }
  }, [favorites]);

  // Real-time Firestore sync for favorites when user is authenticated
  useEffect(() => {
    if (!user) return;
    setIsSyncing(true);
    const favCol = collection(db, 'users', user.uid, 'favorites');
    const unsubscribe = onSnapshot(favCol, (snapshot) => {
      const remoteFavs: string[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        if (data.dhikrId) {
          remoteFavs.push(data.dhikrId);
        }
      });
      if (remoteFavs.length > 0) {
        setFavorites(prev => Array.from(new Set([...prev, ...remoteFavs])));
      }
      setIsSyncing(false);
    }, (error) => {
      console.warn('Firestore favorites sync note:', error);
      setIsSyncing(false);
    });

    return () => unsubscribe();
  }, [user]);

  const toggleFavorite = (id: string) => {
    setFavorites(prev => {
      const exists = prev.includes(id);
      const next = exists ? prev.filter(fId => fId !== id) : [...prev, id];
      showToast(exists ? 'تمت الإزالة من المفضلة' : 'تمت الإضافة إلى المفضلة ❤️');

      // Persist to Firestore if authenticated
      if (user) {
        if (exists) {
          removeFavoriteFromFirestore(user.uid, id).catch(e => console.warn(e));
        } else {
          const item = ALL_ADHKAR.find(d => d.id === id);
          saveFavoriteToFirestore(
            user.uid,
            id,
            item ? item.title : id,
            item ? item.category : 'all'
          ).catch(e => console.warn(e));
        }
      }

      return next;
    });
  };

  const isFavorite = (id: string) => favorites.includes(id);

  // Settings state persisted in localStorage
  const [settings, setSettings] = useState<UserSettings>(() => {
    try {
      const saved = localStorage.getItem('hisn_settings');
      if (saved) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
    } catch {
      // ignore
    }
    return DEFAULT_SETTINGS;
  });

  const updateSettings = (newSettings: Partial<UserSettings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...newSettings };
      try {
        localStorage.setItem('hisn_settings', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  };

  const [solarTimes, setSolarTimes] = useState<SolarTimes>(() => {
    return getSolarTimes(getSavedCoordinates());
  });

  // Calculate and synchronize Theme (Dark/Light/Auto according to Sunset/Sunrise)
  useEffect(() => {
    const checkAndSyncTheme = () => {
      const coords = getSavedCoordinates();
      const currentSolar = getSolarTimes(coords);
      setSolarTimes(currentSolar);

      let effectiveDark = settings.darkMode;
      if (settings.themeMode === 'dark') {
        effectiveDark = true;
      } else if (settings.themeMode === 'light') {
        effectiveDark = false;
      } else if (settings.themeMode === 'auto') {
        effectiveDark = currentSolar.isNight;
      }

      if (settings.darkMode !== effectiveDark) {
        updateSettings({ darkMode: effectiveDark });
      }

      const root = document.documentElement;
      if (effectiveDark) {
        root.classList.add('dark');
        if (settings.amoledMode) {
          root.classList.add('amoled');
        } else {
          root.classList.remove('amoled');
        }
      } else {
        root.classList.remove('dark');
        root.classList.remove('amoled');
      }
    };

    checkAndSyncTheme();

    const interval = setInterval(checkAndSyncTheme, 30000);

    const onVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        checkAndSyncTheme();
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, [settings.themeMode, settings.darkMode, settings.amoledMode]);

  // =========================================================================
  // GEOGRAPHIC LOCATION & AUTOMATIC ONLINE SYNC (تحديد الموقع الجغرافي التلقائي)
  // =========================================================================
  const [userCoordinates, setUserCoordinates] = useState<UserCoordinates | null>(() => getSavedCoordinates());
  const [isDetectingLocation, setIsDetectingLocation] = useState<boolean>(false);

  const updateUserCoordinates = (coords: UserCoordinates) => {
    setUserCoordinates(coords);
    try {
      localStorage.setItem('hisn_coords', JSON.stringify(coords));
    } catch {}
    const updatedSolar = getSolarTimes(coords);
    setSolarTimes(updatedSolar);
    if (settings.themeMode === 'auto') {
      updateSettings({ darkMode: updatedSolar.isNight });
    }
  };

  const refreshLocationForSolarTimes = async (silent: boolean = false) => {
    setIsDetectingLocation(true);
    if (!silent) {
      showToast('جاري سحب وتحديث موقعك الجغرافي الحالي عبر الإنترنت والأقمار الصناعية 🛰️...');
    }
    const coords = await requestCoordinates(true);
    if (coords) {
      setUserCoordinates(coords);
      const updatedSolar = getSolarTimes(coords);
      setSolarTimes(updatedSolar);
      if (settings.themeMode === 'auto') {
        updateSettings({ darkMode: updatedSolar.isNight });
      }
      if (!silent) {
        showToast(`تم تحديد وتحديث موقعك بنجاح (${coords.city || 'موقعك الحالي'}) 📍`);
      }
    } else if (!silent) {
      showToast('تعذر سحب الموقع الجغرافي بدقة، تم الاعتماد على التوقيت الحالي');
    }
    setIsDetectingLocation(false);
  };

  // Automatically fetch real geographic location whenever connected to the internet
  useEffect(() => {
    const handleOnline = () => {
      // Reconnected to internet -> auto-pull current location
      refreshLocationForSolarTimes(true);
    };

    // Auto-detect on startup if connected to internet
    if (typeof navigator !== 'undefined' && navigator.onLine) {
      refreshLocationForSolarTimes(true);
    }

    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, []);

  // =========================================================================
  // IN-APP NOTIFICATION & REMINDER SYSTEM (نظام التذكيرات والإشعارات المجدولة)
  // =========================================================================
  const [inAppAlert, setInAppAlert] = useState<InAppNotification | null>(null);
  const [showNotificationCenter, setShowNotificationCenter] = useState<boolean>(false);
  const snoozeTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Notification History state
  const [notificationHistory, setNotificationHistory] = useState<InAppNotification[]>(() => {
    try {
      const saved = localStorage.getItem('hisn_notif_history');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem('hisn_notif_history', JSON.stringify(notificationHistory));
    } catch {
      // ignore
    }
  }, [notificationHistory]);

  const handleTriggerInApp = (notif: InAppNotification) => {
    setInAppAlert(notif);
    setNotificationHistory(prev => [notif, ...prev.filter(n => n.id !== notif.id).slice(0, 29)]);
    
    if (settings.sound) {
      playMilestoneSound(true);
    }
    triggerVibration(settings.vibration, 'milestone');
  };

  const dismissInAppAlert = () => {
    setInAppAlert(null);
  };

  const snoozeInAppAlert = (minutes: number = 10) => {
    if (!inAppAlert) return;
    const alertToSnooze = { ...inAppAlert };
    setInAppAlert(null);

    if (snoozeTimerRef.current) {
      clearTimeout(snoozeTimerRef.current);
    }

    snoozeTimerRef.current = setTimeout(() => {
      const snoozedNotif: InAppNotification = {
        ...alertToSnooze,
        id: `snooze-${Date.now()}`,
        title: `تذكير متأخر: ${alertToSnooze.title}`,
        timestamp: Date.now(),
      };
      handleTriggerInApp(snoozedNotif);
    }, minutes * 60 * 1000);
  };

  const clearNotificationHistory = () => {
    setNotificationHistory([]);
    try {
      localStorage.removeItem('hisn_notif_history');
    } catch {}
    showToast('تم مسح سجل التنبيهات');
  };

  const triggerTestReminder = (category: 'morning' | 'evening') => {
    const isMorning = category === 'morning';
    const testNotif: InAppNotification = {
      id: `test-${Date.now()}`,
      title: isMorning ? 'تجربة: حان وقت أذكار الصباح المباركة ☀️' : 'تجربة: حان وقت أذكار المساء الهادئة 🌙',
      body: isMorning 
        ? 'أصبحنا وأصبح الملك لله والحمد لله.. ابدأ يومك ببركة الذكر وحصن نفسك وبيتك.'
        : 'أمسينا وأمسى الملك لله والحمد لله.. اختم يومك بسكينة القلب وحفظ النفس والأهل.',
      category,
      time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      timestamp: Date.now(),
      read: false,
    };

    handleTriggerInApp(testNotif);
    showToast(`تم إطلاق إشعار تجريبي لـ ${isMorning ? 'أذكار الصباح ☀️' : 'أذكار المساء 🌙'}`);
  };

  // Next upcoming reminder calculation
  const nextReminderInfo = useMemo(() => {
    return getNextReminderInfo(
      settings.morningNotification && settings.notificationsEnabled,
      settings.morningNotificationTime,
      settings.eveningNotification && settings.notificationsEnabled,
      settings.eveningNotificationTime
    );
  }, [
    settings.notificationsEnabled,
    settings.morningNotification,
    settings.morningNotificationTime,
    settings.eveningNotification,
    settings.eveningNotificationTime,
  ]);

  // Periodic check for scheduled morning and evening reminders
  useEffect(() => {
    if (!settings.notificationsEnabled) return;

    // Run check immediately on load
    checkAndTriggerScheduledReminders(
      settings.morningNotification,
      settings.morningNotificationTime,
      settings.eveningNotification,
      settings.eveningNotificationTime,
      handleTriggerInApp
    );

    // Periodic check every 20 seconds
    const interval = setInterval(() => {
      checkAndTriggerScheduledReminders(
        settings.morningNotification,
        settings.morningNotificationTime,
        settings.eveningNotification,
        settings.eveningNotificationTime,
        handleTriggerInApp
      );
    }, 20000);

    return () => clearInterval(interval);
  }, [
    settings.notificationsEnabled,
    settings.morningNotification,
    settings.morningNotificationTime,
    settings.eveningNotification,
    settings.eveningNotificationTime,
    settings.sound,
    settings.vibration,
  ]);

  const toggleNotifications = async (enable: boolean) => {
    if (enable) {
      updateSettings({ notificationsEnabled: true });
      showToast('تم تفعيل نظام تذكيرات الأذكار بنجاح 🔔');

      // Request browser system notifications if available as bonus
      const status = getNotificationStatus();
      if (status.supported && status.permission !== 'granted' && status.permission !== 'denied') {
        try {
          const res = await requestNotificationPermission();
          if (res === 'granted') {
            sendLocalNotification(
              'حصن المسلم 🌿',
              'تم تفعيل تذكيرات أذكار الصباح والمساء، نسأل الله أن يبارك في وقتك وعمرك.'
            );
          }
        } catch {
          // ignore
        }
      }
    } else {
      updateSettings({ notificationsEnabled: false });
      showToast('تم إيقاف تذكيرات الأذكار');
    }
  };

  const sendTestReminderNotification = () => {
    triggerTestReminder('morning');
  };

  // =========================================================================
  // AMBIENT SOUNDSCAPE SYSTEM (نظام أصوات السكينة والخشوع أثناء قراءة الأذكار)
  // =========================================================================
  const [ambientType, setAmbientTypeState] = useState<AmbientSoundType>('none');
  const [ambientPlaying, setAmbientPlaying] = useState<boolean>(false);
  const [ambientVolume, setAmbientVolumeState] = useState<number>(0.5);
  const [showAmbientModal, setShowAmbientModal] = useState<boolean>(false);

  const setAmbientType = (type: AmbientSoundType) => {
    setAmbientTypeState(type);
    if (type === 'none') {
      ambientEngine.stop();
      setAmbientPlaying(false);
    } else {
      ambientEngine.play(type, ambientVolume);
      setAmbientPlaying(true);
    }
  };

  const toggleAmbientPlay = () => {
    if (ambientPlaying) {
      ambientEngine.stop();
      setAmbientPlaying(false);
    } else {
      const typeToPlay = ambientType === 'none' ? 'rain' : ambientType;
      setAmbientTypeState(typeToPlay);
      ambientEngine.play(typeToPlay, ambientVolume);
      setAmbientPlaying(true);
    }
  };

  const setAmbientVolume = (vol: number) => {
    setAmbientVolumeState(vol);
    ambientEngine.setVolume(vol);
  };

  const setAmbientTimer = (minutes: number) => {
    ambientEngine.setTimer(minutes, () => {
      setAmbientPlaying(false);
      setAmbientTypeState('none');
      showToast('انتهى مؤقت أصوات السكينة ⏰');
    });
  };

  // Cumulative Lifetime Dhikr Count (عداد التسبيح التراكمي طوال فترة الاستخدام)
  const [totalDhikrCount, setTotalDhikrCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('hisn_total_dhikr_count');
      if (saved) {
        const parsed = parseInt(saved, 10);
        return isNaN(parsed) ? 0 : parsed;
      }
    } catch {
      // ignore
    }
    return 0;
  });

  useEffect(() => {
    try {
      localStorage.setItem('hisn_total_dhikr_count', totalDhikrCount.toString());
    } catch {
      // ignore
    }
  }, [totalDhikrCount]);

  const incrementTotalDhikrCount = (amount: number = 1) => {
    setTotalDhikrCount(prev => {
      const next = prev + amount;
      try {
        localStorage.setItem('hisn_total_dhikr_count', next.toString());
      } catch {
        // ignore
      }
      return next;
    });
  };

  const resetTotalDhikrCount = () => {
    setTotalDhikrCount(0);
    try {
      localStorage.setItem('hisn_total_dhikr_count', '0');
    } catch {
      // ignore
    }
    showToast('تم تصفير عداد التسبيح التراكمي بنجاح');
  };

  // Standalone Smart Tasbeeh Counter Modal State
  const [showTasbeehModal, setShowTasbeehModal] = useState<boolean>(false);

  // Progress state persisted in localStorage
  const [progress, setProgress] = useState<DhikrProgress>(() => {
    try {
      const today = new Date().toISOString().slice(0, 10);
      const savedDate = localStorage.getItem('hisn_progress_date');
      if (savedDate === today) {
        const saved = localStorage.getItem('hisn_progress');
        return saved ? JSON.parse(saved) : {};
      }
      localStorage.setItem('hisn_progress_date', today);
      return {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('hisn_progress', JSON.stringify(progress));
    } catch {
      // ignore
    }
  }, [progress]);

  const incrementProgress = (id: string) => {
    const targetDhikr = ALL_ADHKAR.find(d => d.id === id);
    const targetCount = targetDhikr ? targetDhikr.count : 1;
    const current = progress[id] || 0;

    if (current >= targetCount) {
      if (settings.sound) playCompleteSound();
      triggerVibration(settings.vibration, 'complete');
      return;
    }

    const nextCount = current + 1;
    const isCompleted = nextCount === targetCount;

    let isMilestone = false;
    const msOption = settings.vibrationMilestone || '33';
    if (msOption === '33' && (nextCount % 33 === 0 || nextCount === 100)) {
      isMilestone = true;
    } else if (msOption === '10' && nextCount % 10 === 0) {
      isMilestone = true;
    } else if (msOption === 'target' && isCompleted) {
      isMilestone = true;
    }

    if (isCompleted) {
      if (settings.sound) playCompleteSound();
      triggerVibration(settings.vibration, 'complete');
    } else if (isMilestone) {
      if (settings.sound) playMilestoneSound(true);
      triggerVibration(settings.vibration, 'milestone');
    } else {
      if (settings.sound) playTapSound();
      triggerVibration(settings.vibration, 'tap');
    }

    setProgress(prev => ({
      ...prev,
      [id]: nextCount,
    }));

    incrementTotalDhikrCount(1);
  };

  const setProgressValue = (id: string, value: number) => {
    const targetDhikr = ALL_ADHKAR.find(d => d.id === id);
    const targetCount = targetDhikr ? targetDhikr.count : 100;
    const cleanVal = Math.max(0, Math.min(value, targetCount));

    if (cleanVal >= targetCount) {
      if (settings.sound) playCompleteSound();
      triggerVibration(settings.vibration, 'complete');
    } else {
      if (settings.sound) playTapSound();
      triggerVibration(settings.vibration, 'tap');
    }

    setProgress(prev => ({
      ...prev,
      [id]: cleanVal,
    }));
  };

  const decrementProgress = (id: string) => {
    const current = progress[id] || 0;
    if (current <= 0) return;

    if (settings.sound) playTapSound();
    triggerVibration(settings.vibration, 'tap');

    setProgress(prev => ({
      ...prev,
      [id]: current - 1,
    }));

    setTotalDhikrCount(prev => Math.max(0, prev - 1));
  };

  const resetDhikrProgress = (id: string) => {
    setProgress(prev => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    showToast('تمت إعادة تعيين العداد للذكر الحالي');
  };

  const resetAllProgress = () => {
    setProgress({});
    try {
      localStorage.removeItem('hisn_progress');
    } catch {
      // ignore
    }
    showToast('تمت إعادة ضبط جميع العدادات لليوم');
  };

  const resetCategoryProgress = (category: 'morning' | 'evening') => {
    const list = category === 'morning' ? MORNING_ADHKAR : EVENING_ADHKAR;
    const catIds = new Set(list.map(d => d.id));
    setProgress(prev => {
      const next = { ...prev };
      Object.keys(next).forEach(k => {
        if (catIds.has(k)) {
          delete next[k];
        }
      });
      return next;
    });
    showToast(category === 'morning' ? 'تمت إعادة ضبط أذكار الصباح' : 'تمت إعادة ضبط أذكار المساء');
  };

  const getProgressFor = (id: string): number => {
    return progress[id] || 0;
  };

  const openDhikr = (dhikr: DhikrItem) => {
    setSelectedDhikr(dhikr);
  };

  const closeDhikr = () => {
    setSelectedDhikr(null);
  };

  const getCurrentList = (): DhikrItem[] => {
    if (!selectedDhikr) return MORNING_ADHKAR;
    if (selectedDhikr.category === 'morning') return MORNING_ADHKAR;
    if (selectedDhikr.category === 'evening') return EVENING_ADHKAR;
    return ALL_ADHKAR;
  };

  const nextDhikr = () => {
    if (!selectedDhikr) return;
    const list = getCurrentList();
    const currentIndex = list.findIndex(d => d.id === selectedDhikr.id);
    if (currentIndex < list.length - 1) {
      setSelectedDhikr(list[currentIndex + 1]);
    } else {
      closeDhikr();
      showToast('أتممت هذه المجموعة بحمد الله وتوفيقه 🌿');
    }
  };

  const prevDhikr = () => {
    if (!selectedDhikr) return;
    const list = getCurrentList();
    const currentIndex = list.findIndex(d => d.id === selectedDhikr.id);
    if (currentIndex > 0) {
      setSelectedDhikr(list[currentIndex - 1]);
    }
  };

  return (
    <AppContext.Provider
      value={{
        user,
        isAuthReady,
        login,
        logout,
        isSyncing,
        activeTab,
        setActiveTab,
        openMorningEveningView,
        selectedDhikr,
        openDhikr,
        closeDhikr,
        nextDhikr,
        prevDhikr,
        showAboutModal,
        setShowAboutModal,
        splashDismissed,
        dismissSplash,
        favorites,
        toggleFavorite,
        isFavorite,
        progress,
        incrementProgress,
        decrementProgress,
        resetDhikrProgress,
        setProgressValue,
        resetAllProgress,
        resetCategoryProgress,
        getProgressFor,
        settings,
        updateSettings,
        toggleNotifications,
        sendTestReminderNotification,
        inAppAlert,
        dismissInAppAlert,
        snoozeInAppAlert,
        notificationHistory,
        clearNotificationHistory,
        triggerTestReminder,
        showNotificationCenter,
        setShowNotificationCenter,
        nextReminderInfo,
        ambientType,
        ambientPlaying,
        ambientVolume,
        showAmbientModal,
        setShowAmbientModal,
        setAmbientType,
        toggleAmbientPlay,
        setAmbientVolume,
        setAmbientTimer,
        solarTimes,
        userCoordinates,
        updateUserCoordinates,
        isDetectingLocation,
        refreshLocationForSolarTimes,
        totalDhikrCount,
        incrementTotalDhikrCount,
        resetTotalDhikrCount,
        showTasbeehModal,
        setShowTasbeehModal,
        toastMessage,
        showToast,
        selectedCategory,
        setSelectedCategory,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
