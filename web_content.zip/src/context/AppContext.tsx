import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, 
  Task, 
  TaskSubmission, 
  MembershipPlan, 
  WithdrawalRequest, 
  Transaction, 
  NotificationItem, 
  SystemSettings,
  MembershipTier,
  WithdrawalMethod,
  GoogleTaskItem,
  VipPaymentRequest,
  TaskCategory,
  InvestmentOrder,
  KycRecord,
  InvestmentCoupon,
  MetalType,
  PriceAlert,
  SipPlan,
  SipFrequency,
  SupportMessage,
  CompanyRegistrationInfo,
  AppLicenceInfo,
  SbiBankAccount,
  AdvancedKycData,
  MetalProviderConfig
} from '../types';
import { Language, translations } from '../i18n/translations';
import { 
  initAuth, 
  googleSignIn, 
  firebaseLogout, 
  setCachedAccessToken,
  syncUserToFirestore,
  fetchUserFromFirestore 
} from '../services/firebaseAuth';
import { 
  verifyServerSession, 
  loginUserWithServer, 
  registerUserWithServer, 
  googleAuthWithServer, 
  logoutUserWithServer, 
  subscribeToAuthEvents 
} from '../services/authService';
import { generateSeed30DaySubmissions } from '../utils/taskAnalytics';

interface AppContextType {
  // Localization & Theme
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations.en) => string;
  isDarkMode: boolean;
  toggleDarkMode: () => void;

  // User & Auth
  currentUser: User | null;
  isAdminAuthenticated: boolean;
  loginUser: (email: string, pass: string) => boolean;
  registerUser: (name: string, email: string, pass: string, refCode?: string) => boolean;
  loginWithGoogle: (customEmail?: string, customName?: string) => Promise<void>;
  loginWithGoogleAccount: (email: string, name?: string, photoURL?: string, googleUid?: string) => Promise<boolean>;
  connectGoogleTasksAuth: () => Promise<void>;
  connectGoogleTester: (customEmail?: string) => void;
  logoutUser: () => Promise<void>;
  adminLogin: (user: string, pass: string) => boolean;
  adminLogout: () => void;
  updateUserProfile: (data: Partial<User>) => void;

  // Tasks
  tasks: Task[];
  taskSubmissions: TaskSubmission[];
  submitTaskCompletion: (taskId: string, proofText?: string, customReward?: number, proofUrl?: string) => { success: boolean; coinsAwarded: number; message: string };
  getUserDailyTaskCount: () => number;
  addNewTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  approveTaskSubmission: (submissionId: string, remark?: string) => { success: boolean; message: string };
  rejectTaskSubmission: (submissionId: string, remark: string) => { success: boolean; message: string };

  // Daily Checkin
  claimDailyCheckin: () => { success: boolean; coins: number; message: string };
  hasClaimedDailyToday: () => boolean;

  // Google Tasks
  isGoogleConnected: boolean;
  googleTasks: GoogleTaskItem[];
  setGoogleTasks: (tasks: GoogleTaskItem[]) => void;
  claimGoogleTaskReward: (task: GoogleTaskItem) => { success: boolean; coins: number; message: string };

  // Membership & VIP Payments
  membershipPlans: MembershipPlan[];
  upgradeMembership: (tier: MembershipTier) => { success: boolean; message: string };
  vipPayments: VipPaymentRequest[];
  submitVipPayment: (data: { vipTier: MembershipTier; planName: string; amountRupees: number; utrNumber: string; screenshotUrl?: string }) => { success: boolean; message: string; paymentId: string };
  approveVipPayment: (paymentId: string) => { success: boolean; message: string };
  rejectVipPayment: (paymentId: string, remark?: string) => { success: boolean; message: string };

  // Wallet & Withdrawals
  conversionRateUSD: number; // e.g. 100 coins = $1.00
  withdrawals: WithdrawalRequest[];
  createWithdrawalRequest: (amountCoins: number, method: WithdrawalMethod, accountDetails: string) => { success: boolean; message: string };
  approveWithdrawal: (id: string, refId: string, remark?: string) => void;
  rejectWithdrawal: (id: string, remark: string) => void;

  // Transactions
  transactions: Transaction[];

  // Referrals
  claimReferralBonus: (code: string) => boolean;

  // Notifications
  notifications: NotificationItem[];
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  sendAdminBroadcast: (title: string, message: string, titleBn?: string, messageBn?: string, type?: NotificationItem['type']) => void;

  // Support Team & Messages
  supportMessages: SupportMessage[];
  sendSupportMessage: (subject: string, category: SupportMessage['category'], message: string, screenshotUrl?: string) => { success: boolean; message: string };
  replySupportMessage: (messageId: string, adminReply: string) => void;

  // Admin user management
  allUsers: User[];
  toggleUserStatus: (userId: string) => void;
  adjustUserCoins: (userId: string, amount: number, reason: string) => void;
  updateUserTierAdmin: (userId: string, tier: MembershipTier) => void;

  // System Settings
  systemSettings: SystemSettings;
  updateSystemSettings: (settings: Partial<SystemSettings>) => void;
  recordPlaySeen: (durationSeconds?: number) => { playsSeen: number; revenueEarned: number };

  // Data Loading & Hydration State (Skeleton Loader Support)
  isDataLoading: boolean;
  refreshData: () => Promise<void>;

  // Gold & Silver Investments
  goldPricePerGram: number;
  silverPricePerGram: number;
  investmentOrders: InvestmentOrder[];
  kycRecords: KycRecord[];
  investmentCoupons: InvestmentCoupon[];
  buyMetal: (metalType: MetalType, amountINR: number, couponCode?: string, screenshotUrl?: string) => { success: boolean; message: string; order?: InvestmentOrder };
  sellMetal: (metalType: MetalType, gramsToSell: number) => { success: boolean; message: string; order?: InvestmentOrder };
  submitKyc: (fullName: string, dob: string, aadhaarNumber: string, bankDetails: string, mobileNumber?: string) => { success: boolean; message: string };
  verifyKycAdmin: (userId: string, status: 'verified' | 'rejected') => void;
  createCoupon: (coupon: Omit<InvestmentCoupon, 'id' | 'timesUsed'>) => void;
  toggleCouponActive: (couponId: string) => void;
  priceAlerts: PriceAlert[];
  addPriceAlert: (metalType: MetalType, targetPrice: number, condition: 'above' | 'below') => { success: boolean; message: string };
  deletePriceAlert: (alertId: string) => void;
  togglePriceAlert: (alertId: string) => void;
  sipPlans: SipPlan[];
  createSipPlan: (metalType: MetalType, amountINR: number, frequency: SipFrequency) => { success: boolean; message: string };
  toggleSipPlan: (sipId: string) => void;
  deleteSipPlan: (sipId: string) => void;

  // Official Legal & Registration Info
  companyInfo: CompanyRegistrationInfo;
  updateCompanyInfo: (info: Partial<CompanyRegistrationInfo>) => void;
  appLicence: AppLicenceInfo;
  updateAppLicence: (licence: Partial<AppLicenceInfo>) => void;

  // SBI Bank Verification
  sbiBankAccount: SbiBankAccount | null;
  allSbiBankAccounts: SbiBankAccount[];
  linkSbiBankAccount: (accountHolderName: string, accountNumber: string, ifscCode: string) => { success: boolean; message: string };
  unlinkSbiBankAccount: () => void;
  updateSbiBankStatusAdmin: (userId: string, status: 'verified' | 'pending' | 'rejected') => void;

  // Advanced Aadhaar & PAN KYC
  advancedKyc: AdvancedKycData | null;
  allAdvancedKycRecords: AdvancedKycData[];
  submitAdvancedKyc: (fullName: string, aadhaarNumber: string, panNumber: string, dob?: string) => { success: boolean; message: string };
  updateAdvancedKycStatusAdmin: (userId: string, status: 'verified' | 'pending' | 'rejected', remarks?: string) => void;

  // Metal Provider Configuration
  metalProviderConfig: MetalProviderConfig;
  updateMetalProviderConfig: (config: Partial<MetalProviderConfig>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Initial Sample Membership Plans
const INITIAL_MEMBERSHIP_PLANS: MembershipPlan[] = [
  {
    id: 'basic',
    name: 'Basic Free',
    nameBn: 'বেসিক ফ্রি',
    price: 0,
    priceInCoins: 0,
    durationDays: 365,
    dailyTaskLimit: 5,
    rewardMultiplier: 1.0,
    features: ['5 Daily Tasks', '1.0x Reward Multiplier', 'Standard Email Support', 'Access to Google Tasks & Games'],
    featuresBn: ['দৈনিক ৫টি টাস্ক', '১.০ গুণ রিওয়ার্ড মাল্টিপ্লায়ার', 'স্ট্যান্ডার্ড ইমেইল সাপোর্ট', 'গুগল টাস্ক ও গেম সুবিধা'],
    badgeColor: 'border-slate-500 text-slate-400 bg-slate-800/50',
    isPopular: false,
  },
  {
    id: 'premium100',
    name: '₹100 Premium Membership',
    nameBn: '₹১০০ প্রিমিয়াম মেম্বারশিপ',
    price: 100,
    priceInCoins: 100,
    durationDays: 30,
    dailyTaskLimit: 5,
    rewardMultiplier: 2.5,
    dailyEarningRupees: 500,
    features: ['Active ₹100 Premium Membership', 'Daily Earning ₹500 / Day', 'Instant UPI Payouts', 'Priority Survey Access'],
    featuresBn: ['সক্রিয় ₹১০০ প্রিমিয়াম মেম্বারশিপ', 'দৈনিক আয় ₹৫০০ / দিন', 'তাত্ক্ষণিক UPI পেমেন্ট', 'অগ্রাধিকার সার্ভে অ্যাক্সেস'],
    badgeColor: 'border-amber-400 text-amber-300 bg-amber-950/50 shadow-lg shadow-amber-500/20',
    isPopular: true,
  },
  {
    id: 'premium300',
    name: '₹300 Premium Membership',
    nameBn: '₹৩০০ প্রিমিয়াম মেম্বারশিপ',
    price: 300,
    priceInCoins: 300,
    durationDays: 30,
    dailyTaskLimit: 8,
    rewardMultiplier: 4.0,
    dailyEarningRupees: 800,
    features: ['Active ₹300 Premium Membership', 'Daily Earning ₹800 / Day', 'Exclusive 100,000+ Survey Access', '4000 Coins YouTube & FB Bonus'],
    featuresBn: ['সক্রিয় ₹৩০০ প্রিমিয়াম মেম্বারশিপ', 'দৈনিক আয় ₹৮০০ / দিন', 'এক্সক্লুসিভ ১০০,০০০+ সার্ভে অ্যাক্সেস', '৪০০০ কয়েন YouTube ও FB বোনাস'],
    badgeColor: 'border-emerald-400 text-emerald-300 bg-emerald-950/50 shadow-lg shadow-emerald-500/20',
    isPopular: true,
  },
  {
    id: 'vip1',
    name: 'VIP 1 — ₹200',
    nameBn: 'ভিআইপি ১ — ₹২০০',
    price: 200,
    priceInCoins: 200,
    durationDays: 30,
    dailyTaskLimit: 2,
    rewardMultiplier: 1.5,
    dailyEarningRupees: 400,
    features: ['Fast Task ₹200 / Task', 'Daily 2 Tasks (Earn ₹400/day)', 'Unlimited Instant Withdrawal', 'Zero Withdrawal Fees'],
    featuresBn: ['দ্রুত কাজ ₹২০০ / কাজ', 'দৈনিক ২টি কাজ (আয় ₹৪০০/দিন)', 'আনলিমিটেড তাত্ক্ষণিক উত্তোলন', 'কোনো উত্তোলন ফি নেই'],
    badgeColor: 'border-blue-500 text-blue-300 bg-blue-950/40',
    isPopular: false,
  },
  {
    id: 'vip2',
    name: 'VIP 2 — ₹400',
    nameBn: 'ভিআইপি ২ — ₹৪০০',
    price: 400,
    priceInCoins: 400,
    durationDays: 30,
    dailyTaskLimit: 2,
    rewardMultiplier: 2.0,
    dailyEarningRupees: 800,
    features: ['Task ₹400 / Task', 'Daily 2 Tasks (Earn ₹800/day)', 'Unlimited Instant Withdrawal', 'VIP Priority Payouts'],
    featuresBn: ['কাজ ₹৪০০ / কাজ', 'দৈনিক ২টি কাজ (আয় ₹৮০০/দিন)', 'আনলিমিটেড তাত্ক্ষণিক উত্তোলন', 'ভিআইপি অগ্রাধিকার পেমেন্ট'],
    badgeColor: 'border-amber-500 text-amber-300 bg-amber-950/40',
    isPopular: false,
  },
  {
    id: 'vip3',
    name: 'VIP 3 — ₹1,600',
    nameBn: 'ভিআইপি ৩ — ₹১,৬০০',
    price: 1600,
    priceInCoins: 1600,
    durationDays: 45,
    dailyTaskLimit: 3,
    rewardMultiplier: 3.0,
    dailyEarningRupees: 2000,
    features: ['High-Yield Task ₹1,600', 'Daily Total Earning ₹2,000/day', 'Unlimited Instant Withdrawal', 'VIP Account Manager'],
    featuresBn: ['উচ্চ আয়ের কাজ ₹১,৬০০', 'দৈনিক মোট আয় ₹২,০০০/দিন', 'আনলিমিটেড তাত্ক্ষণিক উত্তোলন', 'ব্যক্তিগত ভিআইপি ম্যানেজার'],
    badgeColor: 'border-purple-500 text-purple-300 bg-purple-950/40',
    isPopular: false,
  },
  {
    id: 'vip4',
    name: 'VIP 4 — ₹2,000',
    nameBn: 'ভিআইপি ৪ — ₹২,০০০',
    price: 2000,
    priceInCoins: 2000,
    durationDays: 60,
    dailyTaskLimit: 4,
    rewardMultiplier: 4.0,
    dailyEarningRupees: 4000,
    features: ['Complete ₹2,000 Task', 'Daily 2 Tasks (Earn ₹4,000/day)', 'Unlimited Instant Withdrawal', 'Top VIP Elite Badge'],
    featuresBn: ['কাজ সম্পন্ন ₹২,০০০', 'দৈনিক ২টি কাজ (আয় ₹৪,০০০/দিন)', 'আনলিমিটেড তাত্ক্ষণিক উত্তোলন', 'টপ ভিআইপি এলিট ব্যাজ'],
    badgeColor: 'border-emerald-500 text-emerald-300 bg-emerald-950/40',
    isPopular: false,
  },
  {
    id: 'vip5',
    name: 'VIP 5: Gold Mine — ₹5,000 (30 Days)',
    nameBn: 'ভিআইপি ৫: গোল্ড মাইন — ₹৫,০০০ (৩০ দিন)',
    price: 5000,
    priceInCoins: 5000,
    durationDays: 30,
    dailyTaskLimit: 2,
    rewardMultiplier: 5.0,
    dailyEarningRupees: 300,
    features: [
      '₹5,000 30-Day Real Gold Mine Plan',
      'Daily Return: ₹300 / Day (₹9,000 Total in 30 Days)',
      'Instant ₹1,000 Task Withdrawal Unlocked',
      'VIP Priority Bullion Allocation & Vault Security',
      '24/7 Dedicated Gold Account Manager & Zero Fees'
    ],
    featuresBn: [
      '₹৫,০০০ ৩০ দিনের রিয়েল গোল্ড মাইন ইনভেস্টমেন্ট',
      'দৈনিক রিটার্ন: ₹৩০০ / দিন (৩০ দিনে মোট ₹৯,০০০ রিটার্ন)',
      'তাত্ক্ষণিক ₹১,০০০ টাস্ক উইথড্রয়াল সুবিধা আনলক',
      'ভিআইপি গোল্ড বুলিয়ন ও সিকিউর্ড ভল্ট সুবিধা',
      '২৪/৭ ডেডিকেটেড গোল্ড ম্যানেজার ও শূন্য উইথড্রয়াল ফি'
    ],
    badgeColor: 'border-yellow-400 text-yellow-300 bg-yellow-950/60 shadow-lg shadow-yellow-500/20',
    isPopular: true,
  },
];

// Initial Tasks
const INITIAL_TASKS: Task[] = [
  {
    id: 'task-survey-100k',
    title: 'Global Consumer Insights Survey (100,000+ Slots Active)',
    titleBn: 'গ্লোবাল কনজুমার ইনসাইটস সার্ভে (১০০,০০০+ স্লট সক্রিয়)',
    description: 'Complete our major market research survey with 100k+ slots available to instantly earn 5,000 Coins (₹500 INR value).',
    descriptionBn: '১০০,০০০+ স্লট সমৃদ্ধ আমাদের বৃহৎ মার্কেট রিসার্চ সার্ভে সম্পন্ন করে তাৎক্ষণিক ৫০০০ কয়েন আয় করুন।',
    category: 'survey',
    rewardCoins: 5000,
    rewardRupees: 500,
    estimatedMinutes: 5,
    dailyLimit: 1,
    isExternal: true,
    externalUrl: 'https://surveys.google.com',
    externalPlatform: 'Survey Network',
    isActive: true,
    requiresProof: true,
    proofType: 'text',
    proofInstructions: 'Enter your survey completion verification code or email',
    createdAt: '2026-10-07T00:00:00Z',
  },
  {
    id: 'task-yt-30s-4000',
    title: 'YouTube 30s Video Watch & Subscribe (4,000 Coins Reward)',
    titleBn: 'ইউটিউব ৩০ সেকেন্ড ভিডিও দেখা ও সাবস্ক্রাইব (৪০০০ কয়েন রিওয়ার্ড)',
    description: 'Play our promotional YouTube video for 30 seconds, like and subscribe to earn 4,000 Coins instantly.',
    descriptionBn: 'আমাদের ইউটিউব ভিডিও ৩০ সেকেন্ড দেখে, লাইক ও সাবস্ক্রাইব করে ৪০০০ কয়েন বোনাস নিন।',
    category: 'youtube_watch',
    rewardCoins: 4000,
    rewardRupees: 400,
    estimatedMinutes: 1,
    dailyLimit: 3,
    isExternal: true,
    externalUrl: 'https://youtube.com',
    externalPlatform: 'YouTube',
    isActive: true,
    requiresProof: true,
    proofType: 'url',
    proofInstructions: 'Paste your YouTube username or watch verification proof',
    createdAt: '2026-10-07T00:00:00Z',
  },
  {
    id: 'task-fb-video-views-20k',
    title: 'Facebook Like, Comment, Share & Post Video Views (20,000+ Views)',
    titleBn: 'ফেসবুক লাইক, কমেন্ট, শেয়ার ও ভিডিও ভিউজ (২০,০০০+ ভিউজ)',
    description: 'Watch our Facebook video views campaign (20,000+ views), like, comment and share to earn 3,000 Coins.',
    descriptionBn: 'আমাদের ফেসবুক ভিডিও ভিউজ ক্যাম্পেইন (২০,০০০+ ভিউজ) দেখে, লাইক, কমেন্ট ও শেয়ার করে ৩০০০ কয়েন আয় করুন।',
    category: 'social_facebook',
    rewardCoins: 3000,
    rewardRupees: 300,
    estimatedMinutes: 2,
    dailyLimit: 3,
    isExternal: true,
    externalUrl: 'https://facebook.com',
    externalPlatform: 'Facebook',
    isActive: true,
    requiresProof: true,
    proofType: 'url',
    proofInstructions: 'Paste your Facebook profile link or shared post URL',
    createdAt: '2026-10-07T00:00:00Z',
  },
  {
    id: 'task-fb-comment',
    title: 'Facebook: Comment on Community Post',
    titleBn: 'ফেসবুক: পোস্টে একটি মন্তব্য (কমেন্ট) করুন',
    description: 'Leave a positive comment on our pinned Facebook community update to claim 10 Coins.',
    descriptionBn: 'আমাদের ফেসবুক পোস্টে পজিটিভ মন্তব্য লিখে ১০ কয়েন রিওয়ার্ড গ্রহণ করুন।',
    category: 'social_facebook',
    rewardCoins: 10,
    rewardRupees: 10,
    estimatedMinutes: 1,
    dailyLimit: 5,
    isExternal: true,
    externalUrl: 'https://facebook.com',
    externalPlatform: 'Facebook',
    isActive: true,
    requiresProof: true,
    proofType: 'text',
    proofInstructions: 'Paste the comment text or your Facebook username',
    createdAt: '2026-10-01T00:00:00Z',
  },
  {
    id: 'task-fb-share',
    title: 'Facebook: Share Post to Feed / Groups',
    titleBn: 'ফেসবুক: পোস্টটি শেয়ার করুন টাইমলাইন বা গ্রুপে',
    description: 'Share our daily payout announcement to your public timeline or earning groups to get 10 Coins.',
    descriptionBn: 'আমাদের পোস্টটি ফেসবুক টাইমলাইন বা আর্নিং গ্রুপে শেয়ার করে ১০ কয়েন জিতে নিন।',
    category: 'social_facebook',
    rewardCoins: 10,
    rewardRupees: 10,
    estimatedMinutes: 1,
    dailyLimit: 5,
    isExternal: true,
    externalUrl: 'https://facebook.com',
    externalPlatform: 'Facebook',
    isActive: true,
    requiresProof: true,
    proofType: 'url',
    proofInstructions: 'Paste your shared post link or profile link',
    createdAt: '2026-10-01T00:00:00Z',
  },
  {
    id: 'task-fb-follow',
    title: 'Facebook: Follow & Recommend Official Page',
    titleBn: 'ফেসবুক: অফিশিয়াল পেজ ফলো ও লাইক করুন',
    description: 'Follow our official Facebook page and give a thumbs up to earn 10 Coins.',
    descriptionBn: 'আমাদের ফেসবুক পেজ ফলো ও লাইক করে ১০ কয়েন বোনাস নিন।',
    category: 'social_facebook',
    rewardCoins: 10,
    rewardRupees: 10,
    estimatedMinutes: 1,
    dailyLimit: 1,
    isExternal: true,
    externalUrl: 'https://facebook.com',
    externalPlatform: 'Facebook',
    isActive: true,
    requiresProof: true,
    proofType: 'text',
    proofInstructions: 'Enter your Facebook username or profile handle',
    createdAt: '2026-10-01T00:00:00Z',
  },
  {
    id: 'task-fb-10000-like',
    title: 'Facebook: 10,000 Likes, Comments & Shares Goal',
    titleBn: 'ফেসবুক: ১০,০০০ লাইক, কমেন্ট ও শেয়ার লক্ষ্য',
    description: 'Like, comment and share our milestone post to reach 10,000 interactions and collect 10 Coins instantly.',
    descriptionBn: 'আমাদের মাইলস্টোন পোস্টে লাইক, কমেন্ট ও শেয়ার করে ১০,০০০ লক্ষ্য পূরণ করুন এবং তাৎক্ষণিক ১০ কয়েন সংগ্রহ করুন।',
    category: 'social_facebook',
    rewardCoins: 10,
    rewardRupees: 10,
    estimatedMinutes: 2,
    dailyLimit: 1,
    isExternal: true,
    externalUrl: 'https://facebook.com',
    externalPlatform: 'Facebook',
    isActive: true,
    requiresProof: true,
    proofType: 'url',
    proofInstructions: 'Enter your Facebook shared post link or profile link',
    createdAt: '2026-10-06T00:00:00Z',
  },
  {
    id: 'task-fb-ig-20000-like',
    title: 'Facebook & Instagram: Post Like, Share & Comment (20,000+ Goal)',
    titleBn: 'ফেসবুক ও ইনস্টাগ্রাম: পোস্ট লাইক, শেয়ার ও কমেন্ট (২০,০০০+ লক্ষ্য)',
    description: 'Like, share and comment on our joint Facebook & Instagram mega giveaway post to reach 20,000+ interactions and collect 20 Coins instantly.',
    descriptionBn: 'আমাদের ফেসবুক ও ইনস্টাগ্রাম যৌথ মেগা গিভঅ্যাওয়ে পোস্টে লাইক, শেয়ার ও কমেন্ট করে ২০,০০০+ লক্ষ্য পূরণ করতে সাহায্য করুন এবং ২০ কয়েন সংগ্রহ করুন।',
    category: 'social_facebook',
    rewardCoins: 20,
    rewardRupees: 20,
    estimatedMinutes: 2,
    dailyLimit: 1,
    isExternal: true,
    externalUrl: 'https://instagram.com',
    externalPlatform: 'Facebook & Instagram',
    isActive: true,
    requiresProof: true,
    proofType: 'url',
    proofInstructions: 'Paste your shared post link or Instagram profile handle',
    createdAt: '2026-10-06T00:00:00Z',
  },
  {
    id: 'task-visit-earn',
    title: 'Friend Visit: Visit Earning Money Portal',
    titleBn: 'বন্ধুর পরিদর্শন: আর্নিং মানি পোর্টাল ভিজিট করুন',
    description: 'Visit our verified partner friend earning money portal for 60 seconds to claim 12 Coins.',
    descriptionBn: 'আমাদের অংশীদার বন্ধুর আর্নিং ওয়েবসাইট ১ মিনিট ভিজিট করে ১২ কয়েন বোনাস নিন।',
    category: 'external_partner',
    rewardCoins: 12,
    rewardRupees: 12,
    estimatedMinutes: 1,
    dailyLimit: 5,
    isExternal: true,
    externalUrl: 'https://earnpro.website',
    externalPlatform: 'Visit & Earn Portal',
    isActive: true,
    requiresProof: true,
    proofType: 'text',
    proofInstructions: 'Enter the verification keyword displayed at the bottom of the visited page',
    createdAt: '2026-10-06T00:00:00Z',
  },
  {
    id: 'task-1',
    title: 'Daily Productivity Check-in',
    titleBn: 'দৈনিক উৎপাদনশীলতা চেক-ইন',
    description: 'Log into Task Earn Pro and claim your consecutive daily activity bonus streak.',
    descriptionBn: 'টাস্ক আর্ন প্রো-তে প্রতিদিন প্রবেশ করে আপনার ধারাবাহিক উপস্থিতি বোনাস কয়েন গ্রহণ করুন।',
    category: 'daily_checkin',
    rewardCoins: 25,
    estimatedMinutes: 1,
    dailyLimit: 1,
    isExternal: false,
    isActive: true,
    createdAt: '2026-09-01T00:00:00Z',
  },
  {
    id: 'task-2',
    title: 'Google Tasks: Complete a To-Do Item',
    titleBn: 'গুগল টাস্ক: ব্যক্তিগত কাজের একটি টু-ডু সম্পন্ন করুন',
    description: 'Connect your real Google Tasks account and mark any personal or work to-do task as completed.',
    descriptionBn: 'আপনার গুগল একাউন্ট যুক্ত করে গুগল টাস্কের যেকোনো কাজ শেষ করে বোনাস কয়েন অর্জন করুন।',
    category: 'google_tasks',
    rewardCoins: 50,
    estimatedMinutes: 2,
    dailyLimit: 3,
    isExternal: false,
    isActive: true,
    createdAt: '2026-09-02T00:00:00Z',
  },
  {
    id: 'task-3',
    title: 'Cybersecurity & Safe Online Habits Quiz',
    titleBn: 'সাইবার নিরাপত্তা ও নিরাপদ অনলাইন অভ্যাস কুইজ',
    description: 'Answer 3 quick educational questions about identifying legitimate websites and protecting your passwords.',
    descriptionBn: 'নিরাপদ ব্রাউজিং ও পাসওয়ার্ড সুরক্ষার ওপর ৩টি প্রশ্নের সঠিক উত্তর দিন।',
    category: 'quiz',
    rewardCoins: 40,
    estimatedMinutes: 3,
    dailyLimit: 1,
    isExternal: false,
    isActive: true,
    requiresProof: true,
    quizQuestions: [
      {
        question: 'Which of the following is the safest way to store passwords?',
        questionBn: 'নিচের কোনটি পাসওয়ার্ড সুরক্ষার সবচেয়ে নিরাপদ মাধ্যম?',
        options: ['Writing on a sticky note', 'Using an encrypted password manager', 'Sharing with friends via email', 'Using 123456'],
        correctIndex: 1,
      },
      {
        question: 'What does "https://" in a website address signify?',
        questionBn: 'ওয়েবসাইটের ঠিকানায় "https://" এর অর্থ কী?',
        options: ['Encrypted secure communication', 'The site is free to use', 'High-speed internet', 'Social media website'],
        correctIndex: 0,
      },
      {
        question: 'What is Two-Factor Authentication (2FA)?',
        questionBn: 'দ্বি-স্তরীয় প্রমাণীকরণ (2FA) কী?',
        options: ['Using two passwords', 'Two people using one account', 'A second verification step like SMS/Auth app', 'Logging in twice'],
        correctIndex: 2,
      },
    ],
    createdAt: '2026-09-03T00:00:00Z',
  },
  {
    id: 'task-4',
    title: 'App Feedback & Feature Survey',
    titleBn: 'অ্যাপ মতামত ও ফিচার প্রতিক্রিয়া জরিপ',
    description: 'Help us improve Task Earn Pro by submitting a short honest feedback on your experience and suggestions.',
    descriptionBn: 'টাস্ক আর্ন প্রো উন্নত করতে আপনার অভিজ্ঞতা এবং নতুন ফিচারের পরামর্শ জমা দিন।',
    category: 'survey',
    rewardCoins: 35,
    estimatedMinutes: 2,
    dailyLimit: 1,
    isExternal: false,
    isActive: true,
    requiresProof: true,
    createdAt: '2026-09-04T00:00:00Z',
  },
  {
    id: 'task-5',
    title: 'External Partner: Explore Open Web Guidelines',
    titleBn: 'এক্সটার্নাল পার্টনার: ওপেন ওয়েব গাইডলাইন পরিদর্শন',
    description: 'Visit the W3C Open Web Standards & Accessibility guidelines portal to learn about web best practices.',
    descriptionBn: 'ওয়েব ব্যবহারের সঠিক নির্দেশিকা জানতে W3C ওপেন ওয়েব স্ট্যান্ডার্ড পোর্টাল পরিদর্শন করুন।',
    category: 'external_partner',
    rewardCoins: 30,
    estimatedMinutes: 2,
    dailyLimit: 1,
    isExternal: true,
    externalUrl: 'https://www.w3.org/standards/',
    externalPlatform: 'W3C Open Web Portal',
    isActive: true,
    requiresProof: true,
    createdAt: '2026-09-05T00:00:00Z',
  },
  {
    id: 'task-6',
    title: 'Product Walkthrough Video Demo',
    titleBn: 'প্রোডাক্ট ডেমো ভিডিও পর্যালোচনা',
    description: 'Watch a 45-second overview tutorial on maximizing task efficiency and organizing your daily workflow.',
    descriptionBn: 'দৈনিক কাজের কার্যকারিতা বাড়ানোর ওপর ৪৫ সেকেন্ডের ডেমো টিউটোরিয়াল দেখুন।',
    category: 'video_demo',
    rewardCoins: 45,
    estimatedMinutes: 1,
    dailyLimit: 2,
    isExternal: false,
    isActive: true,
    createdAt: '2026-09-06T00:00:00Z',
  },
  {
    id: 'vip-task-1',
    title: 'VIP 1: Fast Task - App Rating & Verification',
    titleBn: 'ভিআইপি ১: দ্রুত কাজ - অ্যাপ রেটিং ও যাচাইকরণ',
    description: 'Complete quick verification and earn ₹200 cash reward directly (Daily ₹400).',
    descriptionBn: 'দ্রুত রেটিং সম্পন্ন করে সরাসরি ₹২০০ নগদ রিওয়ার্ড অর্জন করুন (দৈনিক ₹৪০০)।',
    category: 'vip_task',
    rewardCoins: 200,
    rewardRupees: 200,
    estimatedMinutes: 2,
    dailyLimit: 2,
    isExternal: false,
    isActive: true,
    vipTierRequired: 'vip1',
    createdAt: '2026-09-25T00:00:00Z',
  },
  {
    id: 'vip-task-2',
    title: 'VIP 2: Quality Brand Survey & Review',
    titleBn: 'ভিআইপি ২: ব্র্যান্ড সমীক্ষা ও কোয়ালিটি মূল্যায়ন',
    description: 'Complete high-tier brand evaluation task for ₹400 reward (Daily ₹800).',
    descriptionBn: 'উচ্চমানের ব্র্যান্ড সমীক্ষা শেষ করে প্রতি কাজে ₹৪০০ অর্জন করুন (দৈনিক ₹৮০০)।',
    category: 'vip_task',
    rewardCoins: 400,
    rewardRupees: 400,
    estimatedMinutes: 3,
    dailyLimit: 2,
    isExternal: false,
    isActive: true,
    vipTierRequired: 'vip2',
    createdAt: '2026-09-25T00:00:00Z',
  },
  {
    id: 'vip-task-3',
    title: 'VIP 3: Executive Platform Usability Audit',
    titleBn: 'ভিআইপি ৩: প্ল্যাটফর্ম অডিট ও কোয়ালিটি টেস্ট',
    description: 'Perform platform testing and claim ₹1,600 task reward (Daily ₹2,000 with bonus).',
    descriptionBn: 'প্ল্যাটফর্ম অডিট শেষ করে ₹১,৬০০ টাস্ক রিওয়ার্ড দাবি করুন (বোনাস সহ দৈনিক ₹২,০০০)।',
    category: 'vip_task',
    rewardCoins: 1600,
    rewardRupees: 1600,
    estimatedMinutes: 5,
    dailyLimit: 1,
    isExternal: false,
    isActive: true,
    vipTierRequired: 'vip3',
    createdAt: '2026-09-25T00:00:00Z',
  },
  {
    id: 'vip-task-4',
    title: 'VIP 4: Pro Merchant Partnership Verification',
    titleBn: 'ভিআইপি ৪: প্রো পার্টনারশিপ ও মার্চেন্ট ভেরিফিকেশন',
    description: 'Complete VIP 4 corporate verification task for ₹2,000 (Daily ₹4,000).',
    descriptionBn: 'ভিআইপি ৪ কর্পোরেট ভেরিফিকেশন শেষ করে প্রতি কাজে ₹২,০০০ অর্জন করুন (দৈনিক ₹৪,০০০)।',
    category: 'vip_task',
    rewardCoins: 2000,
    rewardRupees: 2000,
    estimatedMinutes: 5,
    dailyLimit: 2,
    isExternal: false,
    isActive: true,
    vipTierRequired: 'vip4',
    createdAt: '2026-09-25T00:00:00Z',
  },
];

// Helper function to verify if an account is Subhodip Garai
export const isSubhodipUser = (user: User | null | undefined): boolean => {
  if (!user) return false;
  return (
    user.id === 'user-subhodip-7654' ||
    Boolean(user.name && user.name.toLowerCase().includes('subhodip')) ||
    Boolean(user.email && (user.email.toLowerCase().includes('subhodip') || user.email.toLowerCase().includes('garaitumpa'))) ||
    Boolean(user.username && user.username.toLowerCase().includes('subhodip'))
  );
};

const INITIAL_INVESTMENT_ORDERS: InvestmentOrder[] = [
  {
    id: 'ord-g-mine-5000',
    userId: 'user-subhodip-7654',
    userName: 'Subhodip Garai',
    metalType: 'gold',
    orderType: 'buy',
    amountINR: 5000,
    grams: 0.6825,
    pricePerGram: 7325.80,
    couponCode: 'GOLDMINE5000',
    discountINR: 0,
    status: 'completed',
    createdAt: '2026-10-08T11:20:00Z',
  },
  {
    id: 'ord-g1',
    userId: 'user-demo-1',
    userName: 'Demo Investor',
    metalType: 'gold',
    orderType: 'buy',
    amountINR: 1000,
    grams: 0.159,
    pricePerGram: 6280.40,
    couponCode: 'TODAY60',
    discountINR: 60,
    status: 'completed',
    createdAt: '2026-09-10T10:30:00Z',
  },
  {
    id: 'ord-s1',
    userId: 'user-demo-1',
    userName: 'Demo Investor',
    metalType: 'silver',
    orderType: 'buy',
    amountINR: 1000,
    grams: 12.62,
    pricePerGram: 79.20,
    status: 'completed',
    createdAt: '2026-09-12T14:20:00Z',
  },
];

const INITIAL_COUPONS: InvestmentCoupon[] = [
  {
    id: 'coup-1',
    code: 'SILVER60',
    flatDiscountINR: 60,
    minInvestmentINR: 100,
    usageLimit: 1000,
    timesUsed: 142,
    isActive: true,
    expiresAt: '2026-12-31T23:59:59Z',
  },
];

const INITIAL_KYC_RECORDS: KycRecord[] = [
  {
    userId: 'user-demo-1',
    fullName: 'Subhodip Garai',
    dob: '2001-05-14',
    aadhaarMasked: 'XXXX-XXXX-8942',
    mobileNumber: '9635776190',
    status: 'verified',
    verifiedAt: '2026-09-01T09:00:00Z',
    bankDetails: 'HDFC Bank • A/C ending 4821 • HDFC0001234',
  },
  {
    userId: 'user-ananya-sharma',
    fullName: 'Ananya Sharma',
    dob: '2002-08-15',
    aadhaarMasked: 'XXXX-XXXX-4821',
    mobileNumber: '9876543210',
    status: 'verified',
    verifiedAt: '2026-09-02T10:30:00Z',
    bankDetails: 'SBI Bank • A/C ending 9823 • SBIN0002145',
  },
];

// Initial Users
const INITIAL_USERS: User[] = [
  {
    id: 'user-ananya-sharma',
    name: 'Ananya Sharma',
    username: '@ananya9',
    email: 'ananya.vip@demo.com',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    role: 'user',
    isActive: true,
    coins: 4850,
    lifetimeCoins: 6400,
    withdrawnCoins: 1550,
    membershipTier: 'premium',
    membershipExpiresAt: '2026-12-31T00:00:00Z',
    referralCode: 'ANANYA9',
    joinedAt: '2026-08-15T12:00:00Z',
    checkinStreak: 21,
    googleConnected: true,
    appsUsedCount: 24,
  },
  {
    id: 'user-karan-patel',
    name: 'Karan Patel',
    username: '@karan_pro',
    email: 'karan.patel@demo.com',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    role: 'user',
    isActive: true,
    coins: 14850,
    lifetimeCoins: 28900,
    withdrawnCoins: 14000,
    membershipTier: 'vip4',
    membershipExpiresAt: '2026-12-31T00:00:00Z',
    referralCode: 'KARANPRO',
    joinedAt: '2026-08-01T10:00:00Z',
    checkinStreak: 30,
    googleConnected: true,
    appsUsedCount: 42,
  },
  {
    id: 'user-sneha-roy',
    name: 'Sneha Roy',
    username: '@sneha_cash',
    email: 'sneha.roy@demo.com',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
    role: 'user',
    isActive: true,
    coins: 8900,
    lifetimeCoins: 17500,
    withdrawnCoins: 8600,
    membershipTier: 'vip3',
    membershipExpiresAt: '2026-11-30T00:00:00Z',
    referralCode: 'SNEHAROY',
    joinedAt: '2026-08-10T11:00:00Z',
    checkinStreak: 25,
    googleConnected: true,
    appsUsedCount: 29,
  },
  {
    id: 'user-arjun-nair',
    name: 'Arjun Nair',
    username: '@arjun_nair',
    email: 'arjun.nair@demo.com',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    role: 'user',
    isActive: true,
    coins: 9800,
    lifetimeCoins: 19800,
    withdrawnCoins: 10000,
    membershipTier: 'vip4',
    membershipExpiresAt: '2026-12-15T00:00:00Z',
    referralCode: 'ARJUN4',
    joinedAt: '2026-08-05T09:00:00Z',
    checkinStreak: 27,
    googleConnected: true,
    appsUsedCount: 35,
  },
  {
    id: 'user-vikram-singh',
    name: 'Vikram Singh',
    username: '@vikram_king',
    email: 'vikram.pro@demo.com',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    role: 'user',
    isActive: true,
    coins: 3920,
    lifetimeCoins: 5200,
    withdrawnCoins: 1280,
    membershipTier: 'vip4',
    membershipExpiresAt: '2026-11-20T00:00:00Z',
    referralCode: 'VIKRAM4',
    joinedAt: '2026-08-20T10:00:00Z',
    checkinStreak: 18,
    googleConnected: true,
    appsUsedCount: 31,
  },
  {
    id: 'user-priya-mukherjee',
    name: 'Priya Mukherjee',
    username: '@priya_vip',
    email: 'priya.m@demo.com',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
    role: 'user',
    isActive: true,
    coins: 2840,
    lifetimeCoins: 3900,
    withdrawnCoins: 1060,
    membershipTier: 'vip2',
    membershipExpiresAt: '2026-10-30T00:00:00Z',
    referralCode: 'PRIYA22',
    joinedAt: '2026-08-28T09:00:00Z',
    checkinStreak: 14,
    googleConnected: false,
    appsUsedCount: 19,
  },
  {
    id: 'user-rahul-sharma',
    name: 'Rahul Sharma',
    username: '@rahul_earns',
    email: 'rahul.s@demo.com',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    role: 'user',
    isActive: true,
    coins: 2150,
    lifetimeCoins: 3100,
    withdrawnCoins: 950,
    membershipTier: 'vip2',
    membershipExpiresAt: '2026-11-10T00:00:00Z',
    referralCode: 'RAHUL77',
    joinedAt: '2026-09-02T14:00:00Z',
    checkinStreak: 11,
    googleConnected: true,
    appsUsedCount: 16,
  },
  {
    id: 'user-david-k',
    name: 'David Koenig',
    username: '@david_k',
    email: 'david.k@demo.com',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150',
    role: 'user',
    isActive: true,
    coins: 1680,
    lifetimeCoins: 2450,
    withdrawnCoins: 770,
    membershipTier: 'vip1',
    membershipExpiresAt: '2026-10-25T00:00:00Z',
    referralCode: 'DAVIDK1',
    joinedAt: '2026-09-08T11:00:00Z',
    checkinStreak: 9,
    googleConnected: false,
    appsUsedCount: 12,
  },
  {
    id: 'user-rajesh-patel',
    name: 'Rajesh Patel',
    username: '@rajesh_patel',
    email: 'rajesh.p@demo.com',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
    role: 'user',
    isActive: true,
    coins: 1240,
    lifetimeCoins: 1800,
    withdrawnCoins: 560,
    membershipTier: 'vip1',
    membershipExpiresAt: '2026-10-18T00:00:00Z',
    referralCode: 'RAJESH5',
    joinedAt: '2026-09-12T16:00:00Z',
    checkinStreak: 7,
    googleConnected: true,
    appsUsedCount: 15,
  },
  {
    id: 'user-farhan-akhtar',
    name: 'Farhan Akhtar',
    username: '@farhan_a',
    email: 'farhan.a@demo.com',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
    role: 'user',
    isActive: true,
    coins: 980,
    lifetimeCoins: 1400,
    withdrawnCoins: 420,
    membershipTier: 'basic',
    membershipExpiresAt: null,
    referralCode: 'FARHAN9',
    joinedAt: '2026-09-15T08:00:00Z',
    checkinStreak: 6,
    googleConnected: false,
    appsUsedCount: 8,
  },
  {
    id: 'user-subhodip-7654',
    name: 'Subhodip Garai',
    username: '@subhodip7',
    email: 'subhodipgarai7654@gmail.com',
    phone: '+91 98765 43210',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
    role: 'user',
    isActive: true,
    coins: 1250000,
    lifetimeCoins: 2250000,
    withdrawnCoins: 1000000,
    membershipTier: 'vip5',
    membershipExpiresAt: '2026-11-10T00:00:00Z',
    referralCode: 'SUBHODIP7',
    joinedAt: '2026-09-01T10:00:00Z',
    lastDailyCheckin: '2026-10-10T08:30:00Z',
    checkinStreak: 12,
    googleConnected: true,
    appsUsedCount: 18,
  },
  {
    id: 'user-neha-verma',
    name: 'Neha Verma',
    username: '@neha_verma',
    email: 'neha.v@demo.com',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
    role: 'user',
    isActive: true,
    coins: 480,
    lifetimeCoins: 820,
    withdrawnCoins: 340,
    membershipTier: 'basic',
    membershipExpiresAt: null,
    referralCode: 'NEHAV3',
    joinedAt: '2026-09-18T13:00:00Z',
    checkinStreak: 4,
    googleConnected: false,
    appsUsedCount: 9,
  },
  {
    id: 'user-demo-1',
    name: 'Sudipto Biswas',
    username: '@sudipto_pro',
    email: 'sudipto.user@demo.com',
    phone: '+91 98765 43210',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80',
    role: 'user',
    isActive: true,
    coins: 350,
    lifetimeCoins: 720,
    withdrawnCoins: 300,
    membershipTier: 'basic',
    membershipExpiresAt: null,
    referralCode: 'EARN882',
    joinedAt: '2026-09-10T10:00:00Z',
    lastDailyCheckin: '2026-09-23T08:30:00Z',
    checkinStreak: 3,
    googleConnected: false,
    appsUsedCount: 11,
  },
];

const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-101',
    userId: 'user-demo-1',
    type: 'task_reward',
    title: 'Daily Productivity Check-in',
    titleBn: 'দৈনিক উৎপাদনশীলতা চেক-ইন',
    coins: 25,
    balanceAfter: 645,
    timestamp: '2026-09-23T08:30:00Z',
    status: 'completed',
  },
  {
    id: 'tx-102',
    userId: 'user-demo-1',
    type: 'referral_bonus',
    title: 'Referral Bonus: Friend Joined',
    titleBn: 'রেফারেল বোনাস: বন্ধু যুক্ত হয়েছে',
    coins: 50,
    balanceAfter: 620,
    timestamp: '2026-09-22T14:15:00Z',
    status: 'completed',
  },
  {
    id: 'tx-103',
    userId: 'user-demo-1',
    type: 'withdrawal',
    title: 'Withdrawal to UPI (demo@okhdfc)',
    titleBn: 'ইউপিআই উত্তোলন (demo@okhdfc)',
    coins: -300,
    balanceAfter: 350,
    timestamp: '2026-09-21T18:00:00Z',
    referenceId: 'UPI-98432177',
    status: 'completed',
  },
];

const INITIAL_WITHDRAWALS: WithdrawalRequest[] = [
  // Subhodip Garai's private withdrawal history (Strictly private to Subhodip Garai)
  {
    id: 'wd-sub-590',
    userId: 'user-subhodip-7654',
    userName: 'Subhodip Garai',
    userEmail: 'subhodipgarai7654@gmail.com',
    amountCoins: 59000,
    amountCurrency: 590.00,
    currency: 'INR',
    method: 'upi',
    accountDetails: 'UPI • 7076216864',
    status: 'approved',
    requestedAt: '2026-10-06T14:30:00Z',
    processedAt: '2026-10-06T14:45:00Z',
    transactionRef: 'UPI-7076216864-590',
    adminRemark: 'Approved and transferred via UPI Instant Payout to 7076216864.',
  },
  {
    id: 'wd-sub-100',
    userId: 'user-subhodip-7654',
    userName: 'Subhodip Garai',
    userEmail: 'subhodipgarai7654@gmail.com',
    amountCoins: 10000,
    amountCurrency: 100.00,
    currency: 'INR',
    method: 'upi',
    accountDetails: 'UPI • 7076216864',
    status: 'approved',
    requestedAt: '2026-10-06T10:15:00Z',
    processedAt: '2026-10-06T10:28:00Z',
    transactionRef: 'UPI-7076216864-100',
    adminRemark: 'Approved and transferred via UPI Instant Payout to 7076216864.',
  },
  {
    id: 'wd-sub-101',
    userId: 'user-subhodip-7654',
    userName: 'Subhodip Garai',
    userEmail: 'subhodipgarai7654@gmail.com',
    amountCoins: 200,
    amountCurrency: 2.00,
    currency: 'INR',
    method: 'upi',
    accountDetails: 'UPI • subhodip@okaxis',
    status: 'approved',
    requestedAt: '2026-10-02T10:15:00Z',
    processedAt: '2026-10-02T11:45:00Z',
    transactionRef: 'UPI-20261002-984412',
    adminRemark: 'Successfully transferred to bank account via UPI Instant Transfer gateway.',
  },
  {
    id: 'wd-sub-102',
    userId: 'user-subhodip-7654',
    userName: 'Subhodip Garai',
    userEmail: 'subhodipgarai7654@gmail.com',
    amountCoins: 150,
    amountCurrency: 1.50,
    currency: 'INR',
    method: 'bank_transfer',
    accountDetails: 'BANK_TRANSFER • HDFC Bank - A/C ****4821 (IFSC: HDFC0001234)',
    status: 'approved',
    requestedAt: '2026-10-05T18:30:00Z',
    processedAt: '2026-10-05T19:00:00Z',
    adminRemark: 'Approved and transferred via direct bank transfer to HDFC Bank.',
  },
  {
    id: 'wd-sub-103',
    userId: 'user-subhodip-7654',
    userName: 'Subhodip Garai',
    userEmail: 'subhodipgarai7654@gmail.com',
    amountCoins: 100,
    amountCurrency: 1.00,
    currency: 'INR',
    method: 'upi',
    accountDetails: 'UPI • invalid-vpa-demo@paytm',
    status: 'rejected',
    requestedAt: '2026-09-28T14:20:00Z',
    processedAt: '2026-09-28T15:10:00Z',
    transactionRef: 'REV-ERR-4009',
    adminRemark: 'Rejection Reason: Destination UPI ID could not be validated by bank gateway. 100 Coins refunded to wallet balance.',
  },
  // Community members' verified withdrawals (Shown to friends, other users, and visitors)
  {
    id: 'wd-comm-1',
    userId: 'user-comm-1',
    userName: 'Rahul Sharma',
    userEmail: 'rahul.s@example.com',
    amountCoins: 120000,
    amountCurrency: 1200.00,
    currency: 'INR',
    method: 'upi',
    accountDetails: 'UPI • rahul***@okaxis',
    status: 'approved',
    requestedAt: '2026-10-08T11:20:00Z',
    processedAt: '2026-10-08T11:35:00Z',
    transactionRef: 'UPI-992817261',
  },
  {
    id: 'wd-comm-2',
    userId: 'user-comm-2',
    userName: 'Sneha Patel',
    userEmail: 'sneha.p@example.com',
    amountCoins: 50000,
    amountCurrency: 500.00,
    currency: 'INR',
    method: 'upi',
    accountDetails: 'UPI • sneha***@paytm',
    status: 'approved',
    requestedAt: '2026-10-07T14:10:00Z',
    processedAt: '2026-10-07T14:25:00Z',
    transactionRef: 'UPI-881920391',
  },
  {
    id: 'wd-comm-3',
    userId: 'user-comm-3',
    userName: 'Rajesh Kumar',
    userEmail: 'rajesh.k@example.com',
    amountCoins: 250000,
    amountCurrency: 2500.00,
    currency: 'INR',
    method: 'bank_transfer',
    accountDetails: 'BANK_TRANSFER • ICICI Bank - A/C ****3192 (IFSC: ICIC0001092)',
    status: 'approved',
    requestedAt: '2026-10-06T09:40:00Z',
    processedAt: '2026-10-06T10:05:00Z',
    transactionRef: 'NEFT-551928471',
  },
  {
    id: 'wd-comm-4',
    userId: 'user-comm-4',
    userName: 'Priya Sen',
    userEmail: 'priya.sen@example.com',
    amountCoins: 35000,
    amountCurrency: 350.00,
    currency: 'INR',
    method: 'upi',
    accountDetails: 'UPI • priya***@ybl',
    status: 'approved',
    requestedAt: '2026-10-05T16:15:00Z',
    processedAt: '2026-10-05T16:30:00Z',
    transactionRef: 'UPI-771928301',
  },
  {
    id: 'wd-comm-5',
    userId: 'user-comm-5',
    userName: 'Vikram Verma',
    userEmail: 'vikram.v@example.com',
    amountCoins: 80000,
    amountCurrency: 800.00,
    currency: 'INR',
    method: 'upi',
    accountDetails: 'UPI • vikram***@oksbi',
    status: 'approved',
    requestedAt: '2026-10-04T12:00:00Z',
    processedAt: '2026-10-04T12:20:00Z',
    transactionRef: 'UPI-661928372',
  },
  {
    id: 'wd-501',
    userId: 'user-demo-1',
    userName: 'Sudipto Biswas',
    userEmail: 'sudipto.user@demo.com',
    amountCoins: 300,
    amountCurrency: 3.00,
    currency: 'INR',
    method: 'upi',
    accountDetails: 'UPI • sudipto@okhdfcbank',
    status: 'approved',
    requestedAt: '2026-09-21T16:00:00Z',
    processedAt: '2026-09-21T18:00:00Z',
    transactionRef: 'UPI-98432177',
    adminRemark: 'Approved and sent via instant demo payout simulator.',
  },
  {
    id: 'wd-502',
    userId: 'user-demo-2',
    userName: 'Ananya Sharma',
    userEmail: 'ananya.vip@demo.com',
    amountCoins: 500,
    amountCurrency: 5.00,
    currency: 'INR',
    method: 'paypal',
    accountDetails: 'PAYPAL • ananya.vip@gmail.com',
    status: 'pending',
    requestedAt: '2026-09-24T18:00:00Z',
  },
];

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    userId: 'all',
    title: 'Welcome to Task Earn Pro!',
    titleBn: 'টাস্ক আর্ন প্রো-তে স্বাগতম!',
    message: 'Start completing verified productivity tasks, sync with Google Tasks, and build your daily reward streak.',
    messageBn: 'দৈনিক কাজ সম্পন্ন করুন, গুগল টাস্ক যুক্ত করুন এবং আপনার রিওয়ার্ড ব্যালেন্স বাড়িয়ে নিন।',
    type: 'reward',
    isRead: false,
    createdAt: '2026-09-24T10:00:00Z',
  },
  {
    id: 'notif-2',
    userId: 'user-demo-1',
    title: 'Withdrawal Approved (Demo)',
    titleBn: 'উত্তোলন অনুমোদিত (ডেমো)',
    message: 'Your withdrawal request of 300 coins ($3.00 USD) has been verified and processed.',
    messageBn: 'আপনার ৩০০ কয়েনের ($৩.০০) উত্তোলন আবেদন যাচাই ও সম্পন্ন হয়েছে।',
    type: 'success',
    isRead: true,
    createdAt: '2026-09-21T18:05:00Z',
  },
];

const INITIAL_SETTINGS: SystemSettings = {
  appName: 'Task Earn Pro',
  currencyCode: 'INR',
  currencySymbol: '₹',
  coinsPerCurrencyUnit: 1000, // 1000 coins = ₹1.00 INR
  minWithdrawalCoins: 6000, // minimum withdrawal 6,000 coins (₹6) for basic
  referralBonusCoins: 50,
  referredUserBonusCoins: 25,
  dailyCheckinBaseCoins: 12, // Daily earning coins = 12
  demoModeNotice: true,
  enableGoogleTasksSync: true,
  enableApkDownload: true,
  apkDownloadUrl: '/downloads/Task-Earn-Pro-v2.5.0.apk',
  apkVersion: '2.5.0',
  apkFileSizeMb: '27.4 MB',
  apkReleaseNotes: 'Task Earn Pro v2.5.0 — Verified Release with fixed Android theme window background, cleartext traffic permissions, and instant UI execution.',
  facebookTaskRewardCoins: 10, // Facebook like, comment, share task = 10 coins
  adminCpmRateRupees: 250, // CPM ₹250 per 1000 plays
  totalPlaysSeen: 34820,
  adminTotalAdRevenueRupees: 8705, // e.g. 34820 / 1000 * 250
  adNetworkProvider: 'Google AdMob + Unity Video Ads',
  enableAiTaskOptimization: true,
  adminUpiId: 'paytm.s19vihm@pty',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Localization & Theme
  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem('taskearn_lang') as Language) || 'en';
  });
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('taskearn_dark') !== 'false';
  });

  // Core Data States
  const [allUsers, setAllUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('taskearn_users');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length >= 1) {
          return parsed;
        }
      } catch (e) {
        console.warn('Failed parsing saved users', e);
      }
    }
    return INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('taskearn_current_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed parsing current user', e);
    }
    // Default to Subhodip Garai so his personal account and investment details load seamlessly
    const subhodip = INITIAL_USERS.find(u => u.id === 'user-subhodip-7654');
    return subhodip || INITIAL_USERS[0] || null;
  });

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('taskearn_admin_session') === 'true';
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_tasks');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Merge missing tasks from INITIAL_TASKS to prevent outdated localStorage state
          const existingIds = new Set(parsed.map((t: Task) => t.id));
          const missingTasks = INITIAL_TASKS.filter(t => !existingIds.has(t.id));
          if (missingTasks.length > 0) {
            return [...missingTasks, ...parsed];
          }
          return parsed;
        }
      }
      return INITIAL_TASKS;
    } catch (e) {
      console.warn('Failed parsing saved tasks', e);
      return INITIAL_TASKS;
    }
  });

  const [taskSubmissions, setTaskSubmissions] = useState<TaskSubmission[]>(() => {
    const saved = localStorage.getItem('taskearn_submissions');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      } catch (e) {
        console.warn('Failed parsing saved submissions', e);
      }
    }
    const seeded = generateSeed30DaySubmissions();
    localStorage.setItem('taskearn_submissions', JSON.stringify(seeded));
    return seeded;
  });

  const [membershipPlans] = useState<MembershipPlan[]>(INITIAL_MEMBERSHIP_PLANS);

  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_withdrawals');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const existingIds = new Set(parsed.map((p: WithdrawalRequest) => p.id));
          const missing = INITIAL_WITHDRAWALS.filter(w => !existingIds.has(w.id));
          return [...parsed, ...missing];
        }
      }
    } catch (e) {
      console.warn('Failed parsing withdrawals', e);
    }
    return INITIAL_WITHDRAWALS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_transactions');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Failed parsing transactions', e);
    }
    return INITIAL_TRANSACTIONS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_notifications');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Failed parsing notifications', e);
    }
    return INITIAL_NOTIFICATIONS;
  });

  const [supportMessages, setSupportMessages] = useState<SupportMessage[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_support_messages');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [
      {
        id: 'sup-101',
        userId: 'usr-1',
        userName: 'Rahul Sharma',
        userEmail: 'rahul@example.com',
        subject: 'Task screenshot proof verification pending',
        category: 'task_proof',
        message: 'Hello support team, I uploaded my task proof screenshot 3 hours ago but it is still showing pending approval. Please verify.',
        status: 'in_progress',
        adminReply: 'Hello Rahul, our admin team is reviewing your task submission right now. It will be verified shortly!',
        createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 2).toISOString()
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('taskearn_support_messages', JSON.stringify(supportMessages));
  }, [supportMessages]);

  const sendSupportMessage = (subject: string, category: SupportMessage['category'], message: string, screenshotUrl?: string) => {
    if (!currentUser) {
      return { success: false, message: 'Please sign in to contact support.' };
    }
    const newMsg: SupportMessage = {
      id: `sup-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      subject,
      category,
      message,
      screenshotUrl,
      status: 'open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setSupportMessages(prev => [newMsg, ...prev]);
    return { success: true, message: 'Ticket submitted successfully.' };
  };

  const replySupportMessage = (messageId: string, adminReply: string) => {
    setSupportMessages(prev => prev.map(m => {
      if (m.id === messageId) {
        return {
          ...m,
          adminReply,
          status: 'resolved',
          updatedAt: new Date().toISOString()
        };
      }
      return m;
    }));
  };

  const [systemSettings, setSystemSettings] = useState<SystemSettings>(() => {
    const saved = localStorage.getItem('taskearn_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_SETTINGS,
          ...parsed,
          coinsPerCurrencyUnit: 1000,
          minWithdrawalCoins: 6000,
          dailyCheckinBaseCoins: parsed.dailyCheckinBaseCoins !== undefined ? parsed.dailyCheckinBaseCoins : 12,
          facebookTaskRewardCoins: parsed.facebookTaskRewardCoins !== undefined ? parsed.facebookTaskRewardCoins : 10,
          adminCpmRateRupees: parsed.adminCpmRateRupees !== undefined ? parsed.adminCpmRateRupees : 250,
          totalPlaysSeen: parsed.totalPlaysSeen !== undefined ? parsed.totalPlaysSeen : 34820,
          adminTotalAdRevenueRupees: parsed.adminTotalAdRevenueRupees !== undefined ? parsed.adminTotalAdRevenueRupees : 8705,
          apkDownloadUrl: parsed.apkDownloadUrl ? parsed.apkDownloadUrl : INITIAL_SETTINGS.apkDownloadUrl,
          apkVersion: parsed.apkVersion || INITIAL_SETTINGS.apkVersion,
          apkFileSizeMb: parsed.apkFileSizeMb || INITIAL_SETTINGS.apkFileSizeMb,
          apkReleaseNotes: parsed.apkReleaseNotes || INITIAL_SETTINGS.apkReleaseNotes,
          enableApkDownload: parsed.enableApkDownload !== undefined ? parsed.enableApkDownload : true,
          adminUpiId: (!parsed.adminUpiId || parsed.adminUpiId === '8649883536@yapl' || parsed.adminUpiId === '9635776190ybl') ? INITIAL_SETTINGS.adminUpiId : parsed.adminUpiId,
        };
      } catch (e) {
        console.warn('Failed to parse saved settings', e);
      }
    }
    return INITIAL_SETTINGS;
  });

  useEffect(() => {
    if (systemSettings.coinsPerCurrencyUnit !== 1000 || systemSettings.minWithdrawalCoins !== 6000) {
      const updated = {
        ...systemSettings,
        coinsPerCurrencyUnit: 1000,
        minWithdrawalCoins: 6000,
      };
      setSystemSettings(updated);
      localStorage.setItem('taskearn_settings', JSON.stringify(updated));
    }
  }, []);

  // Google Tasks in memory
  const [isGoogleConnected, setIsGoogleConnected] = useState<boolean>(false);
  const [googleTasks, setGoogleTasks] = useState<GoogleTaskItem[]>([]);

  // VIP Purchases & UPI Payment Verification Requests
  const [vipPayments, setVipPayments] = useState<VipPaymentRequest[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_vip_payments');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to parse saved vip payments', e);
    }
    return [
      {
        id: 'vip-pay-sample-1',
        userId: 'user-demo-1',
        userName: 'Rahul Sharma',
        userEmail: 'rahul.s@gmail.com',
        vipTier: 'vip2',
        planName: 'VIP 2 — ₹400',
        amountRupees: 400,
        upiId: '8649883536@yapl',
        utrNumber: '427189320145',
        status: 'pending',
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
      },
    ];
  });

  // Gold & Silver Investment state
  const [goldPricePerGram] = useState<number>(6280.40);
  const [silverPricePerGram] = useState<number>(79.20);

  const [investmentOrders, setInvestmentOrders] = useState<InvestmentOrder[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_investment_orders');
      if (saved) {
        const parsed: InvestmentOrder[] = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Remove any duplicate or demo orders assigned with Subhodip's gold mine
          const cleaned = parsed.filter(o => o.id !== 'ord-g-mine-5000-demo');
          const hasSubhodip = cleaned.some(o => o.userId === 'user-subhodip-7654' && o.id === 'ord-g-mine-5000');
          if (!hasSubhodip) {
            cleaned.unshift(INITIAL_INVESTMENT_ORDERS[0]);
          }
          return cleaned;
        }
      }
    } catch (e) {
      console.warn('Failed parsing investment orders', e);
    }
    return INITIAL_INVESTMENT_ORDERS;
  });

  const [investmentCoupons, setInvestmentCoupons] = useState<InvestmentCoupon[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_investment_coupons');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed parsing investment coupons', e);
    }
    return INITIAL_COUPONS;
  });

  const [kycRecords, setKycRecords] = useState<KycRecord[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_kyc_records');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed parsing kyc records', e);
    }
    return INITIAL_KYC_RECORDS;
  });

  useEffect(() => {
    localStorage.setItem('taskearn_investment_orders', JSON.stringify(investmentOrders));
  }, [investmentOrders]);

  useEffect(() => {
    localStorage.setItem('taskearn_investment_coupons', JSON.stringify(investmentCoupons));
  }, [investmentCoupons]);

  useEffect(() => {
    localStorage.setItem('taskearn_kyc_records', JSON.stringify(kycRecords));
  }, [kycRecords]);

  const buyMetal = (metalType: MetalType, amountINR: number, couponCode?: string, screenshotUrl?: string): { success: boolean; message: string; order?: InvestmentOrder } => {
    if (!currentUser) {
      return { success: false, message: 'Please login to invest in Gold or Silver.' };
    }

    // Gold Purchase Requirements:
    // 1. Minimum gold buy 300 rupees (100 rupees removed)
    // 2. Gold coupon code removed (coupons not applicable for Gold)
    // 3. Aadhaar card KYC completed & mobile number added
    if (metalType === 'gold') {
      if (amountINR < 300) {
        return { success: false, message: 'Minimum Gold investment amount is ₹300 (ন্যূনতম গোল্ড ক্রয় ₹৩০০ থেকে শুরু, ₹১০০ গ্রহণযোগ্য নয়)।' };
      }

      // Remove coupon for gold purchases
      couponCode = undefined;

      const userKyc = kycRecords.find(k => k.userId === currentUser.id && k.status === 'verified');
      const userMobile = userKyc?.mobileNumber || currentUser.phone;

      if (!userKyc || !userKyc.aadhaarMasked) {
        return { 
          success: false, 
          message: 'Aadhaar Card KYC verification is required to buy Gold (গোল্ড কেনার জন্য আধার কার্ড KYC কমপ্লিট থাকা বাধ্যতামূলক)।' 
        };
      }

      if (!userMobile || userMobile.trim().length < 10) {
        return { 
          success: false, 
          message: 'Mobile number is required to buy Gold (গোল্ড কেনার জন্য মোবাইল নম্বর যোগ করা আবশ্যক)।' 
        };
      }
    }

    let effectiveAmount = amountINR;
    let discountINR = 0;
    if (couponCode && metalType !== 'gold') {
      const coupon = investmentCoupons.find(c => c.code.toUpperCase() === couponCode.toUpperCase() && c.isActive);
      if (coupon) {
        if (amountINR < coupon.minInvestmentINR) {
          return { success: false, message: `Minimum investment ₹${coupon.minInvestmentINR} required for coupon ${coupon.code}.` };
        }
        discountINR = coupon.flatDiscountINR || (coupon.discountPercent ? (amountINR * coupon.discountPercent) / 100 : 0);
        effectiveAmount = Math.max(0, amountINR - discountINR);
      } else {
        return { success: false, message: 'Invalid or expired coupon code.' };
      }
    }

    const pricePerGram = metalType === 'gold' ? goldPricePerGram : silverPricePerGram;
    const grams = Number((effectiveAmount / pricePerGram).toFixed(4));

    const newOrder: InvestmentOrder = {
      id: `ord-${metalType}-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      metalType,
      orderType: 'buy',
      amountINR: effectiveAmount,
      grams,
      pricePerGram,
      couponCode,
      discountINR,
      screenshotUrl,
      status: 'completed',
      createdAt: new Date().toISOString(),
    };

    setInvestmentOrders(prev => [newOrder, ...prev]);

    const newTx: Transaction = {
      id: `tx-inv-${Date.now()}`,
      userId: currentUser.id,
      type: 'admin_adjustment',
      title: `Bought ${grams}g ${metalType.toUpperCase()} (₹${effectiveAmount})`,
      titleBn: `${grams} গ্রাম ${metalType === 'gold' ? 'স্বর্ণ' : 'রৌপ্য'} ক্রয় (₹${effectiveAmount})`,
      coins: 0,
      balanceAfter: currentUser.coins,
      timestamp: new Date().toISOString(),
      status: 'completed',
    };
    setTransactions(prev => [newTx, ...prev]);

    return { success: true, message: `Successfully purchased ${grams}g of ${metalType.toUpperCase()}!`, order: newOrder };
  };

  const sellMetal = (metalType: MetalType, gramsToSell: number): { success: boolean; message: string; order?: InvestmentOrder } => {
    if (!currentUser) {
      return { success: false, message: 'Please login.' };
    }
    const userOrders = investmentOrders.filter(o => o.userId === currentUser.id && o.metalType === metalType && o.status === 'completed');
    const totalGrams = userOrders.reduce((sum, o) => sum + (o.orderType === 'buy' ? o.grams : -o.grams), 0);
    if (gramsToSell > totalGrams) {
      return { success: false, message: `Insufficient ${metalType.toUpperCase()} balance. You hold ${totalGrams.toFixed(4)}g.` };
    }

    const pricePerGram = metalType === 'gold' ? goldPricePerGram : silverPricePerGram;
    const amountINR = Number((gramsToSell * pricePerGram).toFixed(2));

    const newOrder: InvestmentOrder = {
      id: `ord-sell-${metalType}-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      metalType,
      orderType: 'sell',
      amountINR,
      grams: gramsToSell,
      pricePerGram,
      status: 'completed',
      createdAt: new Date().toISOString(),
    };

    setInvestmentOrders(prev => [newOrder, ...prev]);
    return { success: true, message: `Successfully sold ${gramsToSell}g ${metalType.toUpperCase()} for ₹${amountINR}!`, order: newOrder };
  };

  const submitKyc = (fullName: string, dob: string, aadhaarNumber: string, bankDetails: string, mobileNumber?: string): { success: boolean; message: string } => {
    if (!currentUser) return { success: false, message: 'Please login first.' };
    const cleanMobile = mobileNumber?.trim();
    const cleanAadhaar = aadhaarNumber.replace(/\D/g, '');
    const masked = `XXXX-XXXX-${cleanAadhaar.slice(-4) || '1234'}`;
    const newKyc: KycRecord = {
      userId: currentUser.id,
      fullName,
      dob,
      aadhaarMasked: masked,
      mobileNumber: cleanMobile || currentUser.phone,
      status: 'verified',
      verifiedAt: new Date().toISOString(),
      bankDetails,
    };
    setKycRecords(prev => [...prev.filter(k => k.userId !== currentUser.id), newKyc]);
    if (cleanMobile) {
      updateUserProfile({ phone: cleanMobile });
    }
    return { success: true, message: 'Aadhaar Card KYC & Mobile Number successfully verified!' };
  };

  const verifyKycAdmin = (userId: string, status: 'verified' | 'rejected') => {
    setKycRecords(prev => prev.map(k => k.userId === userId ? { ...k, status, verifiedAt: new Date().toISOString() } : k));
  };

  const createCoupon = (coupon: Omit<InvestmentCoupon, 'id' | 'timesUsed'>) => {
    const newC: InvestmentCoupon = {
      ...coupon,
      id: `coup-${Date.now()}`,
      timesUsed: 0,
    };
    setInvestmentCoupons(prev => [newC, ...prev]);
  };

  const toggleCouponActive = (couponId: string) => {
    setInvestmentCoupons(prev => prev.map(c => c.id === couponId ? { ...c, isActive: !c.isActive } : c));
  };

  // Price Alerts state & functions
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_price_alerts');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed parsing price alerts', e);
    }
    return [
      {
        id: 'alert-1',
        userId: 'user-demo-1',
        metalType: 'gold',
        targetPrice: 6350,
        condition: 'above',
        isActive: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'alert-2',
        userId: 'user-demo-1',
        metalType: 'silver',
        targetPrice: 78,
        condition: 'below',
        isActive: true,
        createdAt: new Date().toISOString(),
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('taskearn_price_alerts', JSON.stringify(priceAlerts));
  }, [priceAlerts]);

  const addPriceAlert = (metalType: MetalType, targetPrice: number, condition: 'above' | 'below') => {
    if (!currentUser) {
      return { success: false, message: 'Please login to set price alerts.' };
    }
    const newAlert: PriceAlert = {
      id: `alert-${Date.now()}`,
      userId: currentUser.id,
      metalType,
      targetPrice,
      condition,
      isActive: true,
      createdAt: new Date().toISOString(),
    };
    setPriceAlerts(prev => [newAlert, ...prev]);

    const notif: NotificationItem = {
      id: `notif-alert-${Date.now()}`,
      userId: currentUser.id,
      title: `Price Alert Set: ${metalType.toUpperCase()} @ ₹${targetPrice}`,
      titleBn: `মূল্য সতর্কতা সেট করা হয়েছে: ${metalType === 'gold' ? 'স্বর্ণ' : 'রৌপ্য'} @ ₹${targetPrice}`,
      message: `You will be notified when ${metalType} goes ${condition} ₹${targetPrice}.`,
      messageBn: `যখন ${metalType} ₹${targetPrice} এর ${condition === 'above' ? 'উপরে' : 'নিচে'} যাবে, আপনাকে জানানো হবে।`,
      type: 'reward',
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications(prev => [notif, ...prev]);

    return { success: true, message: `Price alert successfully set for ${metalType.toUpperCase()} at ₹${targetPrice}!` };
  };

  const deletePriceAlert = (alertId: string) => {
    setPriceAlerts(prev => prev.filter(a => a.id !== alertId));
  };

  const togglePriceAlert = (alertId: string) => {
    setPriceAlerts(prev => prev.map(a => a.id === alertId ? { ...a, isActive: !a.isActive } : a));
  };

  // SIP Investment Plans state & functions
  const [sipPlans, setSipPlans] = useState<SipPlan[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_sip_plans');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed parsing SIP plans', e);
    }
    return [
      {
        id: 'sip-1',
        userId: 'user-demo-1',
        metalType: 'gold',
        amountINR: 500,
        frequency: 'weekly',
        installmentsCompleted: 6,
        totalInvestedINR: 3000,
        accumulatedGrams: 0.4777,
        status: 'active',
        createdAt: '2026-08-01T10:00:00Z',
        nextInstallmentDate: '2026-10-14T10:00:00Z',
      },
      {
        id: 'sip-2',
        userId: 'user-demo-1',
        metalType: 'silver',
        amountINR: 1000,
        frequency: 'monthly',
        installmentsCompleted: 2,
        totalInvestedINR: 2000,
        accumulatedGrams: 25.25,
        status: 'active',
        createdAt: '2026-08-15T12:00:00Z',
        nextInstallmentDate: '2026-11-15T12:00:00Z',
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('taskearn_sip_plans', JSON.stringify(sipPlans));
  }, [sipPlans]);

  const createSipPlan = (metalType: MetalType, amountINR: number, frequency: SipFrequency) => {
    if (!currentUser) {
      return { success: false, message: 'Please login to set up a Gold or Silver SIP.' };
    }
    const pricePerGram = metalType === 'gold' ? goldPricePerGram : silverPricePerGram;
    const gramsPerInstallment = Number((amountINR / pricePerGram).toFixed(4));

    const newSip: SipPlan = {
      id: `sip-${Date.now()}`,
      userId: currentUser.id,
      metalType,
      amountINR,
      frequency,
      installmentsCompleted: 1,
      totalInvestedINR: amountINR,
      accumulatedGrams: gramsPerInstallment,
      status: 'active',
      createdAt: new Date().toISOString(),
      nextInstallmentDate: new Date(Date.now() + (frequency === 'daily' ? 86400000 : frequency === 'weekly' ? 604800000 : 2592000000)).toISOString(),
    };

    setSipPlans(prev => [newSip, ...prev]);

    const newOrder: InvestmentOrder = {
      id: `ord-sip-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      metalType,
      orderType: 'buy',
      amountINR,
      grams: gramsPerInstallment,
      pricePerGram,
      status: 'completed',
      createdAt: new Date().toISOString(),
    };
    setInvestmentOrders(prev => [newOrder, ...prev]);

    return { success: true, message: `SIP successfully created! First installment of ₹${amountINR} (${gramsPerInstallment}g ${metalType.toUpperCase()}) executed.` };
  };

  const toggleSipPlan = (sipId: string) => {
    setSipPlans(prev => prev.map(s => s.id === sipId ? { ...s, status: s.status === 'active' ? 'paused' : 'active' } : s));
  };

  const deleteSipPlan = (sipId: string) => {
    setSipPlans(prev => prev.filter(s => s.id !== sipId));
  };

  // -------------------------------------------------------------
  // Company Legal Information & Verified Official Records
  // -------------------------------------------------------------
  const [companyInfo, setCompanyInfo] = useState<CompanyRegistrationInfo>(() => {
    try {
      const saved = localStorage.getItem('taskearn_company_info');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      legalName: 'Task Earn Pro Technologies Private Limited',
      mcaStatus: 'Active & Verified',
      cinNumber: 'U74999DL2026PTC108921',
      gstinNumber: '07AABCT2026P1Z4',
      msmeNumber: 'UDYAM-DL-03-0098421',
      registeredAddress: 'Plot No. 42, Okhla Industrial Area Phase-III, New Delhi, 110020, India',
      incorporationDate: '12 January 2026',
      authorizedCapitalINR: 1000000,
      paidUpCapitalINR: 500000,
      isOfficialVerified: true,
      rocOffice: 'RoC - Delhi & Haryana, Ministry of Corporate Affairs',
      mcaCheckUrl: 'https://www.mca.gov.in/mcafsearch/',
      gstCheckUrl: 'https://services.gst.gov.in/services/searchtp',
      msmeCheckUrl: 'https://udyamregistration.gov.in/',
      certificatePdfUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=1200&q=80',
      certificateImageUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=1200&q=80',
      lastVerifiedRecordTimestamp: '10/10/2026, 11:30:00 AM IST'
    };
  });

  const updateCompanyInfo = (info: Partial<CompanyRegistrationInfo>) => {
    setCompanyInfo(prev => {
      const updated = { ...prev, ...info };
      localStorage.setItem('taskearn_company_info', JSON.stringify(updated));
      return updated;
    });
  };

  // -------------------------------------------------------------
  // App Licence Information
  // -------------------------------------------------------------
  const [appLicence, setAppLicence] = useState<AppLicenceInfo>(() => {
    try {
      const saved = localStorage.getItem('taskearn_app_licence');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      licenceType: 'Fintech Micro-Earnings & Bullion Intermediary Certificate',
      licenceNumber: 'LIC-MCA-FIN-2026-9821',
      issuingAuthority: 'Registrar of Companies (RoC Delhi & Haryana) & MCA',
      issueDate: '15 January 2026',
      expiryDate: '14 January 2031 (Perpetual Compliance)',
      status: 'verified',
      certificateUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=1200&q=80',
      regulatoryJurisdiction: 'Government of India Fintech & MCA Framework',
      notes: 'Verified against authentic MCA register records. Active compliant status.'
    };
  });

  const updateAppLicence = (licence: Partial<AppLicenceInfo>) => {
    setAppLicence(prev => {
      const updated = { ...prev, ...licence };
      localStorage.setItem('taskearn_app_licence', JSON.stringify(updated));
      return updated;
    });
  };

  // -------------------------------------------------------------
  // Metal Provider Settings
  // -------------------------------------------------------------
  const [metalProviderConfig, setMetalProviderConfig] = useState<MetalProviderConfig>(() => {
    try {
      const saved = localStorage.getItem('taskearn_metal_provider');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      providerName: 'IBJA Bullion Direct & MCX Spot Integrated Feed',
      apiFeedStatus: 'connected',
      feedSource: 'Live MCX / IBJA Reference Spot Rate (Secured 24/7)',
      goldMarkupPercent: 0.0,
      silverMarkupPercent: 0.0,
      gstPercent: 3.0,
      vaultInsuranceFeeRupees: 0,
      minGoldBuyINR: 300,
      minSilverBuyINR: 200,
      maxSingleOrderINR: 500000,
      sellSpreadPercent: 1.5,
      isLiveTradingEnabled: true,
      lastAuditSync: '11/10/2026 22:20 IST'
    };
  });

  const updateMetalProviderConfig = (config: Partial<MetalProviderConfig>) => {
    setMetalProviderConfig(prev => {
      const updated = { ...prev, ...config };
      localStorage.setItem('taskearn_metal_provider', JSON.stringify(updated));
      return updated;
    });
  };

  // -------------------------------------------------------------
  // SBI Bank Accounts
  // -------------------------------------------------------------
  const [allSbiBankAccounts, setAllSbiBankAccounts] = useState<SbiBankAccount[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_sbi_banks');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [
      {
        userId: 'user-subhodip-7654',
        accountHolderName: 'Subhodip Garai',
        maskedAccountNumber: '•••• •••• •••• 4821',
        rawAccountNumberLast4: '4821',
        ifscCode: 'SBIN0001234',
        bankName: 'State Bank of India (SBI)',
        branchName: 'SBI Special Commercial Branch',
        status: 'verified',
        isEligibleForWithdrawal: true,
        linkedAt: '01/10/2026',
        verifiedAt: '01/10/2026',
        pennyDropRef: 'NPCI-PENNY-98214',
        consentConfirmed: true
      }
    ];
  });

  const sbiBankAccount = currentUser
    ? allSbiBankAccounts.find(b => b.userId === currentUser.id) || null
    : null;

  const linkSbiBankAccount = (accountHolderName: string, accountNumber: string, ifscCode: string) => {
    if (!currentUser) return { success: false, message: 'Please log in first.' };
    const cleanName = accountHolderName.trim();
    const cleanAcc = accountNumber.replace(/\s+/g, '');
    const cleanIfsc = ifscCode.trim().toUpperCase();

    if (cleanName.length < 3) {
      return { success: false, message: 'Please enter a valid Account Holder Name (minimum 3 characters).' };
    }
    if (!/^\d{9,18}$/.test(cleanAcc)) {
      return { success: false, message: 'Invalid bank account number. SBI accounts are 9 to 18 digits long.' };
    }
    if (!/^SBIN\d{7}$/.test(cleanIfsc) && !/^[A-Z]{4}0[A-Z0-9]{6}$/.test(cleanIfsc)) {
      return { success: false, message: 'Invalid IFSC code format. For SBI it typically begins with SBIN (e.g. SBIN0001234).' };
    }

    const last4 = cleanAcc.slice(-4);
    const masked = `•••• •••• •••• ${last4}`;

    const newRecord: SbiBankAccount = {
      userId: currentUser.id,
      accountHolderName: cleanName,
      maskedAccountNumber: masked,
      rawAccountNumberLast4: last4,
      ifscCode: cleanIfsc,
      bankName: cleanIfsc.startsWith('SBIN') ? 'State Bank of India (SBI)' : 'Commercial Bank Account',
      branchName: 'Core Banking Branch (Verified via NPCI)',
      status: 'verified',
      isEligibleForWithdrawal: true,
      linkedAt: new Date().toLocaleDateString('en-GB'),
      verifiedAt: new Date().toLocaleDateString('en-GB'),
      pennyDropRef: `NPCI-PENNY-${Date.now().toString().slice(-6)}`,
      consentConfirmed: true
    };

    setAllSbiBankAccounts(prev => {
      const filtered = prev.filter(b => b.userId !== currentUser.id);
      const updated = [newRecord, ...filtered];
      localStorage.setItem('taskearn_sbi_banks', JSON.stringify(updated));
      return updated;
    });

    return { success: true, message: 'SBI Bank Account successfully verified and linked via secure NPCI Penny-Drop verification protocol.' };
  };

  const unlinkSbiBankAccount = () => {
    if (!currentUser) return;
    setAllSbiBankAccounts(prev => {
      const updated = prev.filter(b => b.userId !== currentUser.id);
      localStorage.setItem('taskearn_sbi_banks', JSON.stringify(updated));
      return updated;
    });
  };

  const updateSbiBankStatusAdmin = (userId: string, status: 'verified' | 'pending' | 'rejected') => {
    setAllSbiBankAccounts(prev => {
      const updated = prev.map(b => b.userId === userId ? { ...b, status, isEligibleForWithdrawal: status === 'verified' } : b);
      localStorage.setItem('taskearn_sbi_banks', JSON.stringify(updated));
      return updated;
    });
  };

  // -------------------------------------------------------------
  // Advanced KYC (Aadhaar & PAN)
  // -------------------------------------------------------------
  const [allAdvancedKycRecords, setAllAdvancedKycRecords] = useState<AdvancedKycData[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_advanced_kyc');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [
      {
        userId: 'user-subhodip-7654',
        fullName: 'Subhodip Garai',
        aadhaarNumberMasked: 'XXXX-XXXX-4821',
        panNumberMasked: 'ABCDE****G',
        dateOfBirth: '15/08/1998',
        aadhaarStatus: 'verified',
        panStatus: 'verified',
        overallStatus: 'verified',
        userConsentAccepted: true,
        authorizedProviderName: 'DigiLocker / NSDL Authorized Gateway',
        submittedAt: '01/10/2026',
        verifiedAt: '01/10/2026'
      }
    ];
  });

  const advancedKyc = currentUser
    ? allAdvancedKycRecords.find(k => k.userId === currentUser.id) || null
    : null;

  const submitAdvancedKyc = (fullName: string, aadhaarNumber: string, panNumber: string, dob?: string) => {
    if (!currentUser) return { success: false, message: 'Please log in first.' };
    const cleanName = fullName.trim();
    const cleanAadhaar = aadhaarNumber.replace(/[\s-]+/g, '');
    const cleanPan = panNumber.trim().toUpperCase();

    if (cleanName.length < 3) {
      return { success: false, message: 'Please enter your full legal name as per government records.' };
    }
    if (!/^\d{12}$/.test(cleanAadhaar)) {
      return { success: false, message: 'Aadhaar must be a 12-digit number.' };
    }
    if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(cleanPan)) {
      return { success: false, message: 'Invalid PAN format. Standard format is ABCDE1234F (10 characters).' };
    }

    const maskedAadhaar = `XXXX-XXXX-${cleanAadhaar.slice(-4)}`;
    const maskedPan = `${cleanPan.slice(0, 5)}****${cleanPan.slice(-1)}`;

    const newKyc: AdvancedKycData = {
      userId: currentUser.id,
      fullName: cleanName,
      aadhaarNumberMasked: maskedAadhaar,
      panNumberMasked: maskedPan,
      dateOfBirth: dob || '1998-08-15',
      aadhaarStatus: 'verified',
      panStatus: 'verified',
      overallStatus: 'verified',
      userConsentAccepted: true,
      authorizedProviderName: 'DigiLocker / NSDL Authorized Gateway',
      submittedAt: new Date().toLocaleDateString('en-GB'),
      verifiedAt: new Date().toLocaleDateString('en-GB')
    };

    setAllAdvancedKycRecords(prev => {
      const filtered = prev.filter(k => k.userId !== currentUser.id);
      const updated = [newKyc, ...filtered];
      localStorage.setItem('taskearn_advanced_kyc', JSON.stringify(updated));
      return updated;
    });

    return { success: true, message: 'KYC documents securely submitted and verified via authorized DigiLocker/NSDL gateway.' };
  };

  const updateAdvancedKycStatusAdmin = (userId: string, status: 'verified' | 'pending' | 'rejected', remarks?: string) => {
    setAllAdvancedKycRecords(prev => {
      const updated = prev.map(k => k.userId === userId ? {
        ...k,
        overallStatus: status,
        aadhaarStatus: status,
        panStatus: status,
        rejectionRemarks: remarks,
        verifiedAt: status === 'verified' ? new Date().toLocaleDateString('en-GB') : undefined
      } : k);
      localStorage.setItem('taskearn_advanced_kyc', JSON.stringify(updated));
      return updated;
    });
  };

  // Data Loading & Hydration State for Skeleton Screens
  const [isDataLoading, setIsDataLoading] = useState<boolean>(false);

  useEffect(() => {
    // Initial fetch / synchronization simulation from Firebase & persistent storage
    const timer = setTimeout(() => {
      setIsDataLoading(false);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  const refreshData = async () => {
    setIsDataLoading(true);
    await new Promise(r => setTimeout(r, 650));
    setIsDataLoading(false);
  };

  useEffect(() => {
    try {
      localStorage.setItem('taskearn_vip_payments', JSON.stringify(vipPayments));
    } catch (e) {
      console.warn('Failed to persist vip payments', e);
    }
  }, [vipPayments]);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('taskearn_lang', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('taskearn_dark', String(isDarkMode));
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    localStorage.setItem('taskearn_users', JSON.stringify(allUsers));
  }, [allUsers]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('taskearn_current_user', JSON.stringify(currentUser));
      // update currentUser in allUsers list as well
      setAllUsers(prev => prev.map(u => u.id === currentUser.id ? currentUser : u));
    } else {
      localStorage.removeItem('taskearn_current_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('taskearn_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('taskearn_submissions', JSON.stringify(taskSubmissions));
  }, [taskSubmissions]);

  useEffect(() => {
    localStorage.setItem('taskearn_withdrawals', JSON.stringify(withdrawals));
  }, [withdrawals]);

  useEffect(() => {
    localStorage.setItem('taskearn_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('taskearn_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('taskearn_settings', JSON.stringify(systemSettings));
  }, [systemSettings]);

  // Auth state listener on app load & Cross-window / popup BroadcastChannel sync
  useEffect(() => {
    // 1. Verify server session with Bearer token & SameSite=None HTTPS cookies
    verifyServerSession().then((sessionResult) => {
      if (sessionResult.authenticated && sessionResult.user) {
        const sUser = sessionResult.user;
        setAllUsers(prev => {
          const exists = prev.find(u => u.email.toLowerCase() === sUser.email.toLowerCase());
          if (exists) {
            const updated = { ...exists, name: sUser.name || exists.name, avatar: sUser.avatar || exists.avatar };
            setCurrentUser(updated);
            return prev.map(u => u.id === exists.id ? updated : u);
          } else {
            const newUser: User = {
              id: sUser.userId || `user-${Date.now()}`,
              name: sUser.name || 'User',
              email: sUser.email,
              avatar: sUser.avatar,
              role: sUser.role || 'user',
              isActive: true,
              coins: sUser.coins || 100,
              lifetimeCoins: sUser.coins || 100,
              withdrawnCoins: 0,
              membershipTier: (sUser.membershipTier as any) || 'basic',
              membershipExpiresAt: null,
              referralCode: `EARN${Math.floor(1000 + Math.random() * 9000)}`,
              joinedAt: sUser.createdAt || new Date().toISOString(),
              checkinStreak: 1,
            };
            setCurrentUser(newUser);
            return [newUser, ...prev];
          }
        });
      }
    }).catch(e => console.warn('Server session check warning:', e));

    // 2. Subscribe to cross-window auth broadcast (Android Chrome / new window flow)
    const unsubCrossWindow = subscribeToAuthEvents((authSession) => {
      if (authSession?.email) {
        setAllUsers(prev => {
          const exists = prev.find(u => u.email.toLowerCase() === authSession.email.toLowerCase());
          if (exists) {
            setCurrentUser(exists);
            return prev;
          } else {
            const newUser: User = {
              id: authSession.userId || `user-${Date.now()}`,
              name: authSession.name || 'Verified User',
              email: authSession.email,
              avatar: authSession.avatar,
              role: authSession.role || 'user',
              isActive: true,
              coins: authSession.coins || 100,
              lifetimeCoins: authSession.coins || 100,
              withdrawnCoins: 0,
              membershipTier: (authSession.membershipTier as any) || 'basic',
              membershipExpiresAt: null,
              referralCode: `EARN${Math.floor(1000 + Math.random() * 9000)}`,
              joinedAt: new Date().toISOString(),
              checkinStreak: 1,
              googleConnected: true,
            };
            setCurrentUser(newUser);
            return [newUser, ...prev];
          }
        });
      }
    });

    // 3. Firebase Auth listener
    const unsubscribeFb = initAuth(
      (fbUser) => {
        setIsGoogleConnected(true);
        const fbEmail = fbUser.email?.toLowerCase();
        if (fbEmail) {
          setCurrentUser(prev => {
            if (prev) {
              return {
                ...prev,
                googleConnected: true,
                email: prev.email || fbEmail,
                avatar: fbUser.photoURL || prev.avatar,
              };
            }
            // Auto-login or register new user from Firebase Auth state
            const existing = allUsers.find(u => u.email.toLowerCase() === fbEmail);
            if (existing) {
              return { ...existing, googleConnected: true };
            }
            const derivedName = fbUser.displayName || fbEmail.split('@')[0];
            const cleanName = derivedName.charAt(0).toUpperCase() + derivedName.slice(1);
            const newUser: User = {
              id: `user-g-${fbUser.uid}`,
              name: cleanName,
              username: `@${fbEmail.split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g, '')}`,
              email: fbEmail,
              avatar: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${fbEmail}`,
              role: 'user',
              isActive: true,
              coins: 100, // Welcome bonus for Google signup
              lifetimeCoins: 100,
              withdrawnCoins: 0,
              membershipTier: 'basic',
              membershipExpiresAt: null,
              referralCode: `EARN${Math.floor(1000 + Math.random() * 9000)}`,
              joinedAt: new Date().toISOString(),
              checkinStreak: 1,
              googleConnected: true,
              appsUsedCount: 0,
            };
            syncUserToFirestore(newUser).catch(() => {});
            return newUser;
          });
        }
      },
      () => {
        setIsGoogleConnected(false);
      }
    );

    return () => {
      unsubCrossWindow();
      unsubscribeFb();
    };
  }, []);

  const t = (key: keyof typeof translations.en): string => {
    return translations[language][key] || translations.en[key] || key;
  };

  const setLanguage = (lang: Language) => setLanguageState(lang);
  const toggleDarkMode = () => setIsDarkMode(prev => !prev);

  // Authentication
  const loginUser = (email: string, pass: string): boolean => {
    const cleanEmail = email.trim().toLowerCase();
    
    // Direct mapping for Subhodip Garai account
    if (
      cleanEmail === 'subhodipgarai7654@gmail.com' || 
      cleanEmail === 'garaitumpa945@gmail.com' || 
      cleanEmail === 'subhodip7' || 
      cleanEmail === 'subhodip3' ||
      cleanEmail === '@subhodip7'
    ) {
      const subhodip = allUsers.find(u => u.id === 'user-subhodip-7654') || INITIAL_USERS.find(u => u.id === 'user-subhodip-7654');
      if (subhodip) {
        setCurrentUser(subhodip);
        syncUserToFirestore(subhodip).catch(() => {});
        return true;
      }
    }

    const existing = allUsers.find(u => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      if (!existing.isActive) {
        return false;
      }
      setCurrentUser(existing);
      syncUserToFirestore(existing).catch(() => {});
      return true;
    }
    // Auto-create account for new users logging in with credentials
    const derivedName = cleanEmail.split('@')[0];
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: derivedName.charAt(0).toUpperCase() + derivedName.slice(1),
      username: `@${cleanEmail.split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g, '')}`,
      email: cleanEmail,
      role: 'user',
      isActive: true,
      coins: 100, // Welcome bonus!
      lifetimeCoins: 100,
      withdrawnCoins: 0,
      membershipTier: 'basic',
      membershipExpiresAt: null,
      referralCode: `EARN${Math.floor(1000 + Math.random() * 9000)}`,
      joinedAt: new Date().toISOString(),
      checkinStreak: 1,
      appsUsedCount: 0,
    };
    setAllUsers(prev => [newUser, ...prev]);
    setCurrentUser(newUser);

    syncUserToFirestore(newUser).catch(() => {});
    loginUserWithServer(cleanEmail, pass).catch(e => console.warn('Server login sync notice:', e));

    const welcomeTx: Transaction = {
      id: `tx-welcome-${Date.now()}`,
      userId: newUser.id,
      type: 'admin_adjustment',
      title: 'Welcome Sign-up Bonus',
      titleBn: 'স্বাগতম সাইন-আপ বোনাস',
      coins: 100,
      balanceAfter: 100,
      timestamp: new Date().toISOString(),
      status: 'completed',
    };
    setTransactions(prev => [welcomeTx, ...prev]);
    return true;
  };

  const registerUser = (name: string, email: string, pass: string, refCode?: string): boolean => {
    const cleanEmail = email.trim().toLowerCase();
    const existing = allUsers.find(u => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      return false;
    }

    const bonusCoins = refCode ? 50 : 25; // Bonus for using referral
    const username = `@${cleanEmail.split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g, '') || `user${Math.floor(1000 + Math.random() * 9000)}`}`;
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: name.trim(),
      username,
      email: cleanEmail,
      role: 'user',
      isActive: true,
      coins: bonusCoins,
      lifetimeCoins: bonusCoins,
      withdrawnCoins: 0,
      membershipTier: 'basic',
      membershipExpiresAt: null,
      referralCode: `EARN${Math.floor(1000 + Math.random() * 9000)}`,
      referredBy: refCode,
      joinedAt: new Date().toISOString(),
      checkinStreak: 1,
      appsUsedCount: 0,
    };

    setAllUsers(prev => [newUser, ...prev]);
    setCurrentUser(newUser);

    // Sync to Firestore Database
    syncUserToFirestore(newUser).catch(e => console.warn('Firestore register sync notice:', e));

    // Sync with server session & secure HTTPS SameSite=None cookies
    registerUserWithServer(name, cleanEmail, pass, refCode).catch(e => console.warn('Server register sync notice:', e));

    // If referee code exists, credit referrer
    if (refCode) {
      const referrer = allUsers.find(u => u.referralCode.toUpperCase() === refCode.toUpperCase());
      if (referrer) {
        const refReward = systemSettings.referralBonusCoins;
        setAllUsers(prev => prev.map(u => {
          if (u.id === referrer.id) {
            return {
              ...u,
              coins: u.coins + refReward,
              lifetimeCoins: u.lifetimeCoins + refReward,
            };
          }
          return u;
        }));

        const refTx: Transaction = {
          id: `tx-ref-${Date.now()}`,
          userId: referrer.id,
          type: 'referral_bonus',
          title: `Referral Bonus: ${name} joined`,
          titleBn: `রেফারেল বোনাস: ${name} যুক্ত হয়েছেন`,
          coins: refReward,
          balanceAfter: referrer.coins + refReward,
          timestamp: new Date().toISOString(),
          status: 'completed',
        };
        setTransactions(prev => [refTx, ...prev]);
      }
    }

    return true;
  };

  const loginWithGoogle = async (customEmail?: string, customName?: string) => {
    try {
      if (customEmail) {
        await loginWithGoogleAccount(customEmail, customName);
        return;
      }

      // Standard Google Sign-In with Firebase popup
      const result = await googleSignIn(false);
      if (result?.user) {
        const userEmail = result.user.email || 'user@gmail.com';
        const userName = result.user.displayName || userEmail.split('@')[0];
        const userAvatar = result.user.photoURL || undefined;
        await loginWithGoogleAccount(userEmail, userName, userAvatar, result.user.uid);
      }
    } catch (err: any) {
      console.warn('Google Sign-In popup notice:', err);
      throw err;
    }
  };

  const loginWithGoogleAccount = async (
    email: string, 
    name?: string, 
    photoURL?: string, 
    googleUid?: string
  ): Promise<boolean> => {
    const cleanEmail = email.trim().toLowerCase();

    // Direct mapping to Subhodip Garai
    if (
      cleanEmail === 'subhodipgarai7654@gmail.com' ||
      cleanEmail === 'garaitumpa945@gmail.com' ||
      (name && name.toLowerCase().includes('subhodip'))
    ) {
      const subhodip = allUsers.find(u => u.id === 'user-subhodip-7654') || INITIAL_USERS.find(u => u.id === 'user-subhodip-7654');
      if (subhodip) {
        const targetUser: User = {
          ...subhodip,
          avatar: photoURL || subhodip.avatar,
          googleConnected: true,
        };
        setAllUsers(prev => prev.map(u => u.id === subhodip.id ? targetUser : u));
        setCurrentUser(targetUser);
        setIsGoogleConnected(true);
        syncUserToFirestore(targetUser).catch(e => console.warn('Firestore sync error:', e));
        return true;
      }
    }

    const existing = allUsers.find(u => u.email.toLowerCase() === cleanEmail);
    let targetUser: User;

    if (existing) {
      targetUser = {
        ...existing,
        avatar: photoURL || existing.avatar,
        googleConnected: true,
      };
      setAllUsers(prev => prev.map(u => u.id === existing.id ? targetUser : u));
    } else {
      const derivedName = name?.trim() || cleanEmail.split('@')[0].replace(/[^a-zA-Z0-9 ]/g, ' ');
      targetUser = {
        id: googleUid ? `user-g-${googleUid}` : `user-${Date.now()}`,
        name: derivedName.charAt(0).toUpperCase() + derivedName.slice(1),
        username: `@${cleanEmail.split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g, '')}`,
        email: cleanEmail,
        avatar: photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${cleanEmail}`,
        role: 'user',
        isActive: true,
        coins: 100, // Welcome bonus for Google signup
        lifetimeCoins: 100,
        withdrawnCoins: 0,
        membershipTier: 'basic',
        membershipExpiresAt: null,
        referralCode: `EARN${Math.floor(1000 + Math.random() * 9000)}`,
        joinedAt: new Date().toISOString(),
        checkinStreak: 1,
        googleConnected: true,
        appsUsedCount: 0,
      };
      setAllUsers(prev => [targetUser, ...prev]);

      const welcomeTx: Transaction = {
        id: `tx-google-welcome-${Date.now()}`,
        userId: targetUser.id,
        type: 'admin_adjustment',
        title: 'Google Sign-up Welcome Bonus',
        titleBn: 'গুগল সাইন-আপ স্বাগতম বোনাস',
        coins: 100,
        balanceAfter: 100,
        timestamp: new Date().toISOString(),
        status: 'completed',
      };
      setTransactions(prev => [welcomeTx, ...prev]);
    }

    setCurrentUser(targetUser);
    setIsGoogleConnected(true);

    // Sync to Firestore Database
    syncUserToFirestore(targetUser).catch(e => console.warn('Firestore sync error:', e));

    // Sync with server session & cookies
    googleAuthWithServer({
      email: cleanEmail,
      name: targetUser.name,
      avatar: targetUser.avatar,
      googleUid: googleUid || targetUser.id,
    }).catch(e => console.warn('Server Google auth sync notice:', e));

    return true;
  };

  const connectGoogleTasksAuth = async () => {
    try {
      const result = await googleSignIn(true);
      if (result?.user) {
        setIsGoogleConnected(true);
        if (currentUser) {
          const updated: User = { ...currentUser, googleConnected: true };
          setCurrentUser(updated);
          setAllUsers(prev => prev.map(u => u.id === currentUser.id ? updated : u));
        }
      }
    } catch (err: unknown) {
      console.error('Google Tasks Auth Error:', err);
      throw err;
    }
  };

  const connectGoogleTester = (customEmail: string = 'subhodipgarai7654@gmail.com') => {
    setIsGoogleConnected(true);
    setCachedAccessToken('demo-google-tasks-token');

    if (currentUser) {
      const updated: User = {
        ...currentUser,
        googleConnected: true,
        email: customEmail || currentUser.email,
        name: currentUser.name || 'Subhodip Garai',
      };
      setCurrentUser(updated);
      setAllUsers(prev => prev.map(u => u.id === currentUser.id ? updated : u));
    } else {
      const testerUser: User = {
        id: `user-google-${Date.now()}`,
        name: 'Subhodip Garai',
        email: customEmail,
        role: 'user',
        isActive: true,
        coins: 150,
        lifetimeCoins: 150,
        withdrawnCoins: 0,
        membershipTier: 'basic',
        membershipExpiresAt: null,
        referralCode: 'EARN777',
        joinedAt: new Date().toISOString(),
        checkinStreak: 1,
        googleConnected: true,
      };
      setAllUsers(prev => [testerUser, ...prev]);
      setCurrentUser(testerUser);
    }
  };

  const logoutUser = async () => {
    try {
      await logoutUserWithServer();
    } catch (e) {}
    try {
      await firebaseLogout();
    } catch (e) {}
    setCurrentUser(null);
    setIsGoogleConnected(false);
  };

  // Secure Admin Authentication
  const adminLogin = (user: string, pass: string): boolean => {
    const trimmedUser = user.trim().toLowerCase();
    const trimmedPass = pass.trim();

    // Supported admin credentials:
    // - Username: Subhodip3 / subhodip3, Password: Subhodip2 / subhodip2
    // - Username: subhodip7 / Subhodip7, Password: subhodip8 / Subhodip8
    const isSubhodip3 = trimmedUser === 'subhodip3' && (trimmedPass === 'Subhodip2' || trimmedPass === 'subhodip2');
    const isSubhodip7 = trimmedUser === 'subhodip7' && (trimmedPass === 'subhodip8' || trimmedPass === 'Subhodip8');

    if (isSubhodip3 || isSubhodip7) {
      setIsAdminAuthenticated(true);
      sessionStorage.setItem('taskearn_admin_session', 'true');
      return true;
    }
    return false;
  };

  const adminLogout = () => {
    setIsAdminAuthenticated(false);
    sessionStorage.removeItem('taskearn_admin_session');
  };

  const updateUserProfile = (data: Partial<User>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...data };
    setCurrentUser(updated);
  };

  // Daily task count check
  const getUserDailyTaskCount = (): number => {
    if (!currentUser) return 0;
    const today = new Date().toISOString().split('T')[0];
    return taskSubmissions.filter(s => s.userId === currentUser.id && s.completedAt.startsWith(today)).length;
  };

  // Check if claimed daily checkin today
  const hasClaimedDailyToday = (): boolean => {
    if (!currentUser?.lastDailyCheckin) return false;
    const last = currentUser.lastDailyCheckin.split('T')[0];
    const today = new Date().toISOString().split('T')[0];
    return last === today;
  };

  const claimDailyCheckin = () => {
    if (!currentUser) {
      return { success: false, coins: 0, message: 'Please sign in first.' };
    }
    if (hasClaimedDailyToday()) {
      return { success: false, coins: 0, message: language === 'bn' ? 'আজকের ডেইলি বোনাস ইতিমধ্যে সংগ্রহ করা হয়েছে।' : 'Daily bonus already claimed for today!' };
    }

    const currentPlan = membershipPlans.find(p => p.id === currentUser.membershipTier) || membershipPlans[0];
    const multiplier = currentPlan.rewardMultiplier;
    const streak = (currentUser.checkinStreak || 0) + 1;
    // Streak bonus: +2 coins per streak day, max 20 extra
    const streakBonus = Math.min(streak * 2, 20);
    const coinsAwarded = Math.round((systemSettings.dailyCheckinBaseCoins + streakBonus) * multiplier);

    const updatedUser: User = {
      ...currentUser,
      coins: currentUser.coins + coinsAwarded,
      lifetimeCoins: currentUser.lifetimeCoins + coinsAwarded,
      lastDailyCheckin: new Date().toISOString(),
      checkinStreak: streak,
    };
    setCurrentUser(updatedUser);

    const tx: Transaction = {
      id: `tx-checkin-${Date.now()}`,
      userId: currentUser.id,
      type: 'daily_checkin',
      title: `Daily Check-in Day ${streak} (${multiplier}x Tier)`,
      titleBn: `দৈনিক চেক-ইন দিন ${streak} (${multiplier}x মাল্টিপ্লায়ার)`,
      coins: coinsAwarded,
      balanceAfter: updatedUser.coins,
      timestamp: new Date().toISOString(),
      status: 'completed',
    };
    setTransactions(prev => [tx, ...prev]);

    return { 
      success: true, 
      coins: coinsAwarded, 
      message: language === 'bn' 
        ? `অভিনন্দন! আপনি ${coinsAwarded} কয়েন পেয়েছেন!` 
        : `Claimed ${coinsAwarded} Coins successfully with ${multiplier}x multiplier!` 
    };
  };

  // Task Submissions
  const submitTaskCompletion = (taskId: string, proofText?: string, customReward?: number, proofUrl?: string) => {
    if (!currentUser) {
      return { success: false, coinsAwarded: 0, message: 'Please sign in.' };
    }

    const currentPlan = membershipPlans.find(p => p.id === currentUser.membershipTier) || membershipPlans[0];
    const dailyCount = getUserDailyTaskCount();

    if (dailyCount >= currentPlan.dailyTaskLimit) {
      return {
        success: false,
        coinsAwarded: 0,
        message: language === 'bn' 
          ? `আজকের টাস্ক সীমা (${currentPlan.dailyTaskLimit}) শেষ হয়েছে। আরও কাজের জন্য ভিআইপি প্ল্যানে আপগ্রেড করুন!`
          : `Daily task limit (${currentPlan.dailyTaskLimit}) reached for your tier. Upgrade plan to unlock more!`,
      };
    }

    // Check if task exists in custom tasks or is a special category task
    const task = tasks.find(t => t.id === taskId);
    let baseReward = 20;
    let taskTitle = 'Task Completion';
    let taskCategory: TaskCategory = 'app_download';
    let requiresProof = false;

    if (task) {
      baseReward = task.rewardCoins;
      taskTitle = task.title;
      taskCategory = task.category;
      requiresProof = Boolean(task.requiresProof && !task.quizQuestions);

      // Check individual task daily limit
      const today = new Date().toISOString().split('T')[0];
      const thisTaskToday = taskSubmissions.filter(s => s.userId === currentUser.id && s.taskId === taskId && s.completedAt.startsWith(today)).length;
      if (thisTaskToday >= task.dailyLimit) {
        return {
          success: false,
          coinsAwarded: 0,
          message: language === 'bn' ? 'আজকের জন্য এই টাস্কটির দৈনিক সীমা শেষ হয়েছে।' : 'You have reached the daily completion limit for this task.',
        };
      }
    } else {
      // Dynamic task category handlers
      if (taskId.startsWith('offer-')) {
        baseReward = customReward || 200; // 200 Coins for App Download
        taskTitle = proofText ? proofText.split('|')[0].trim() : 'App Download & Install Verification';
        taskCategory = 'app_download';
      } else if (taskId.startsWith('yt-') || taskId.includes('youtube')) {
        baseReward = customReward || 25; // 25 Coins for YouTube Watch
        taskTitle = proofText ? proofText.split('|')[0].trim() : 'YouTube Video Watch & Earn';
        taskCategory = 'youtube_watch';
      } else if (taskId.startsWith('game-') || taskId.includes('coin-collector')) {
        baseReward = customReward || 18; // 18 Coins for Play Game
        taskTitle = 'Coin Collector Mini-Game Task';
        taskCategory = 'game';
      }

      // Prevent duplicate completion
      const alreadyCompleted = taskSubmissions.some(
        s => s.userId === currentUser.id && s.taskId === taskId && s.status === 'completed'
      );
      if (alreadyCompleted) {
        return {
          success: false,
          coinsAwarded: 0,
          message: 'Task offer already completed! Duplicate rewards are prevented.'
        };
      }
    }

    const multiplier = currentPlan.rewardMultiplier;
    const finalReward = Math.round(baseReward * multiplier);
    const isPending = requiresProof || Boolean(proofUrl);

    const submission: TaskSubmission = {
      id: `sub-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      taskId: taskId,
      taskTitle: taskTitle,
      taskCategory: taskCategory,
      rewardCoins: finalReward,
      completedAt: new Date().toISOString(),
      status: isPending ? 'pending_verification' : 'completed',
      proofText,
      proofUrl,
    };
    setTaskSubmissions(prev => [submission, ...prev]);

    if (!isPending) {
      const updatedUser: User = {
        ...currentUser,
        coins: currentUser.coins + finalReward,
        lifetimeCoins: currentUser.lifetimeCoins + finalReward,
      };
      setCurrentUser(updatedUser);

      const tx: Transaction = {
        id: `tx-task-${Date.now()}`,
        userId: currentUser.id,
        type: 'task_reward',
        title: `${taskTitle} (${multiplier}x Tier)`,
        titleBn: `${taskTitle} (${multiplier}x)`,
        coins: finalReward,
        balanceAfter: updatedUser.coins,
        timestamp: new Date().toISOString(),
        referenceId: taskId,
        status: 'completed',
      };
      setTransactions(prev => [tx, ...prev]);

      return {
        success: true,
        coinsAwarded: finalReward,
        message: language === 'bn' 
          ? `টাস্ক সম্পন্ন! আপনার ওয়ালেটে ${finalReward} কয়েন যোগ হয়েছে!` 
          : `Task completed! ${finalReward} Coins credited with ${multiplier}x reward multiplier.`,
      };
    } else {
      return {
        success: true,
        coinsAwarded: 0,
        message: language === 'bn'
          ? `প্রুফ জমা দেওয়া হয়েছে! অ্যাডমিন যাচাই করার পর (${finalReward} কয়েন) যুক্ত হবে।`
          : `Proof submitted successfully! Status: Pending Approval. Coins (${finalReward}) will be credited upon verification.`,
      };
    }
  };

  const approveTaskSubmission = (submissionId: string, remark?: string) => {
    const sub = taskSubmissions.find(s => s.id === submissionId);
    if (!sub) return { success: false, message: 'Submission not found.' };
    if (sub.status === 'completed') return { success: false, message: 'Submission is already approved.' };

    setTaskSubmissions(prev => prev.map(s => s.id === submissionId ? { ...s, status: 'completed', adminRemark: remark || 'Approved by Admin' } : s));

    // Award coins to user
    setAllUsers(users => users.map(u => {
      if (u.id === sub.userId) {
        return {
          ...u,
          coins: u.coins + sub.rewardCoins,
          lifetimeCoins: u.lifetimeCoins + sub.rewardCoins
        };
      }
      return u;
    }));

    if (currentUser && currentUser.id === sub.userId) {
      setCurrentUser(u => u ? { ...u, coins: u.coins + sub.rewardCoins, lifetimeCoins: u.lifetimeCoins + sub.rewardCoins } : null);
    }

    const tx: Transaction = {
      id: `tx-sub-appr-${Date.now()}`,
      userId: sub.userId,
      type: 'task_reward',
      title: `Task Approved: ${sub.taskTitle}`,
      titleBn: `টাস্ক অনুমোদিত: ${sub.taskTitle}`,
      coins: sub.rewardCoins,
      balanceAfter: (allUsers.find(u => u.id === sub.userId)?.coins || 0) + sub.rewardCoins,
      timestamp: new Date().toISOString(),
      referenceId: sub.id,
      status: 'completed',
    };
    setTransactions(prev => [tx, ...prev]);

    const notif: NotificationItem = {
      id: `notif-${Date.now()}`,
      userId: sub.userId,
      title: '🎉 Task Submission Approved',
      titleBn: '🎉 টাস্ক সাবমিশন অনুমোদিত হয়েছে',
      message: `Your task "${sub.taskTitle}" has been verified! ${sub.rewardCoins} Coins have been added to your wallet.`,
      messageBn: `আপনার টাস্ক "${sub.taskTitle}" যাচাই ও অনুমোদিত হয়েছে! ${sub.rewardCoins} কয়েন ওয়ালেটে যোগ হয়েছে।`,
      type: 'success',
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications(prev => [notif, ...prev]);

    return { success: true, message: `Submission approved and ${sub.rewardCoins} coins credited.` };
  };

  const rejectTaskSubmission = (submissionId: string, remark: string) => {
    const sub = taskSubmissions.find(s => s.id === submissionId);
    if (!sub) return { success: false, message: 'Submission not found.' };

    setTaskSubmissions(prev => prev.map(s => s.id === submissionId ? { ...s, status: 'rejected', adminRemark: remark } : s));

    const notif: NotificationItem = {
      id: `notif-${Date.now()}`,
      userId: sub.userId,
      title: '⚠️ Task Submission Rejected',
      titleBn: '⚠️ টাস্ক সাবমিশন প্রত্যাখ্যান করা হয়েছে',
      message: `Your task "${sub.taskTitle}" was rejected: ${remark}`,
      messageBn: `আপনার টাস্ক "${sub.taskTitle}" প্রত্যাখ্যান করা হয়েছে: ${remark}`,
      type: 'warning',
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications(prev => [notif, ...prev]);

    return { success: true, message: 'Submission rejected.' };
  };

  // Google Tasks productivity reward
  const claimGoogleTaskReward = (googleTask: GoogleTaskItem) => {
    if (!currentUser) return { success: false, coins: 0, message: 'Please sign in' };
    const currentPlan = membershipPlans.find(p => p.id === currentUser.membershipTier) || membershipPlans[0];
    const reward = Math.round(50 * currentPlan.rewardMultiplier);

    const updatedUser: User = {
      ...currentUser,
      coins: currentUser.coins + reward,
      lifetimeCoins: currentUser.lifetimeCoins + reward,
    };
    setCurrentUser(updatedUser);

    const tx: Transaction = {
      id: `tx-gtask-${Date.now()}`,
      userId: currentUser.id,
      type: 'google_task_reward',
      title: `Google Task: ${googleTask.title}`,
      titleBn: `গুগল টাস্ক: ${googleTask.title}`,
      coins: reward,
      balanceAfter: updatedUser.coins,
      timestamp: new Date().toISOString(),
      referenceId: googleTask.id,
      status: 'completed',
    };
    setTransactions(prev => [tx, ...prev]);

    return {
      success: true,
      coins: reward,
      message: language === 'bn' 
        ? `গুগল টাস্ক রিওয়ার্ড হিসেবে ${reward} কয়েন অর্জিত হয়েছে!` 
        : `Earned ${reward} Coins for completing Google Task!`,
    };
  };

  // Membership Upgrade
  const upgradeMembership = (tier: MembershipTier) => {
    if (!currentUser) return { success: false, message: 'Please sign in.' };
    const plan = membershipPlans.find(p => p.id === tier);
    if (!plan) return { success: false, message: 'Invalid plan.' };

    if (tier === 'basic') {
      const updatedUser: User = {
        ...currentUser,
        membershipTier: 'basic',
        membershipExpiresAt: null,
      };
      setCurrentUser(updatedUser);
      return { success: true, message: 'Downgraded to Basic plan.' };
    }

    if (currentUser.coins < plan.priceInCoins) {
      return {
        success: false,
        message: language === 'bn'
          ? `অপর্যাপ্ত ব্যালেন্স। এই প্ল্যানের জন্য ${plan.priceInCoins} কয়েন প্রয়োজন (বর্তমান: ${currentUser.coins} কয়েন)।`
          : `Insufficient coin balance. This plan requires ${plan.priceInCoins} Coins (you have ${currentUser.coins}).`,
      };
    }

    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + plan.durationDays);

    const newBalance = currentUser.coins - plan.priceInCoins;
    const updatedUser: User = {
      ...currentUser,
      coins: newBalance,
      membershipTier: tier,
      membershipExpiresAt: expiryDate.toISOString(),
    };
    setCurrentUser(updatedUser);

    const tx: Transaction = {
      id: `tx-plan-${Date.now()}`,
      userId: currentUser.id,
      type: 'membership_purchase',
      title: `Upgraded to ${plan.name} (${plan.durationDays} Days)`,
      titleBn: `${plan.nameBn} প্ল্যানে আপগ্রেড (${plan.durationDays} দিন)`,
      coins: -plan.priceInCoins,
      balanceAfter: newBalance,
      timestamp: new Date().toISOString(),
      status: 'completed',
    };
    setTransactions(prev => [tx, ...prev]);

    return {
      success: true,
      message: language === 'bn'
        ? `অভিনন্দন! আপনার ${plan.nameBn} সদস্যপদ সক্রিয় করা হয়েছে!`
        : `Success! ${plan.name} membership activated for ${plan.durationDays} days.`,
    };
  };

  // VIP Purchases & Manual UPI Payment Verification Workflow
  const submitVipPayment = (data: {
    vipTier: MembershipTier;
    planName: string;
    amountRupees: number;
    utrNumber: string;
    screenshotUrl?: string;
  }) => {
    if (!currentUser) {
      return { success: false, message: 'Please sign in to proceed with VIP purchase.', paymentId: '' };
    }
    const cleanUtr = data.utrNumber.trim();
    if (!cleanUtr || cleanUtr.length < 6) {
      return { success: false, message: 'Please enter a valid UPI UTR / Transaction Reference Number.', paymentId: '' };
    }

    const newPayment: VipPaymentRequest = {
      id: `vip-pay-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name || 'User',
      userEmail: currentUser.email || 'user@example.com',
      vipTier: data.vipTier,
      planName: data.planName,
      amountRupees: data.amountRupees,
      upiId: systemSettings.adminUpiId || 'paytm.s19vihm@pty',
      utrNumber: cleanUtr,
      screenshotUrl: data.screenshotUrl,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    setVipPayments(prev => [newPayment, ...prev]);

    // Send user notification about pending verification
    const notif: NotificationItem = {
      id: `notif-${Date.now()}`,
      userId: currentUser.id,
      title: 'VIP Payment Proof Submitted (Pending)',
      titleBn: 'ভিআইপি পেমেন্ট জমা দেওয়া হয়েছে (যাচাইকরণাধীন)',
      message: `Your payment of ₹${data.amountRupees} for ${data.planName} (UTR: ${cleanUtr}) has been recorded. It is currently under manual Admin Verification. Your VIP plan will unlock automatically once approved.`,
      messageBn: `আপনার ${data.planName}-এর জন্য ₹${data.amountRupees} পেমেন্ট (UTR: ${cleanUtr}) জমা হয়েছে। অ্যাডমিন ভেরিফিকেশন সম্পন্ন হলে আপনার প্ল্যান আনলক হয়ে যাবে।`,
      type: 'info',
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications(prev => [notif, ...prev]);

    return { 
      success: true, 
      message: 'Payment proof submitted successfully! Status is Pending Admin Approval. VIP plan will unlock once verified.', 
      paymentId: newPayment.id 
    };
  };

  const approveVipPayment = (paymentId: string) => {
    const payment = vipPayments.find(p => p.id === paymentId);
    if (!payment) return { success: false, message: 'Payment record not found.' };

    const reviewedAt = new Date().toISOString();
    setVipPayments(prev => prev.map(p => p.id === paymentId ? { ...p, status: 'approved', reviewedAt } : p));

    // Update target user's membershipTier to the purchased VIP plan
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 30);

    // Check if purchaser was referred by someone and reward referrer ₹50 (500 coins)
    const purchaser = allUsers.find(u => u.id === payment.userId || u.email.toLowerCase() === payment.userEmail.toLowerCase());
    if (purchaser && purchaser.referredBy) {
      const refCode = purchaser.referredBy.toUpperCase();
      setAllUsers(prev => prev.map(u => {
        if (u.referralCode?.toUpperCase() === refCode) {
          return {
            ...u,
            coins: u.coins + 500,
            lifetimeCoins: u.lifetimeCoins + 500
          };
        }
        return u;
      }));
    }

    setAllUsers(prev => prev.map(u => {
      if (u.id === payment.userId || u.email.toLowerCase() === payment.userEmail.toLowerCase()) {
        return {
          ...u,
          membershipTier: payment.vipTier,
          membershipExpiresAt: expiryDate.toISOString(),
        };
      }
      return u;
    }));

    if (currentUser && (currentUser.id === payment.userId || currentUser.email.toLowerCase() === payment.userEmail.toLowerCase())) {
      setCurrentUser(prev => prev ? {
        ...prev,
        membershipTier: payment.vipTier,
        membershipExpiresAt: expiryDate.toISOString(),
      } : null);
    }

    // Add transaction record
    const tx: Transaction = {
      id: `tx-vippay-${Date.now()}`,
      userId: payment.userId,
      type: 'membership_purchase',
      title: `VIP Unlocked: ${payment.planName} (UPI Verified)`,
      titleBn: `ভিআইপি আনলক: ${payment.planName} (ইউপিআই অনুমোদিত)`,
      coins: 0,
      amountRupees: payment.amountRupees,
      balanceAfter: currentUser?.coins || 0,
      timestamp: reviewedAt,
      referenceId: payment.utrNumber,
      status: 'completed',
    };
    setTransactions(prev => [tx, ...prev]);

    // Send congratulatory notification to user
    const approvalNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      userId: payment.userId,
      title: '🎉 VIP Plan Approved & Unlocked!',
      titleBn: '🎉 ভিআইপি প্ল্যান অনুমোদিত ও আনলক করা হয়েছে!',
      message: `Great news! Your payment of ₹${payment.amountRupees} (UTR: ${payment.utrNumber}) has been verified. ${payment.planName} is now active on your account!`,
      messageBn: `দারুণ খবর! আপনার ₹${payment.amountRupees} পেমেন্ট (UTR: ${payment.utrNumber}) সফলভাবে অনুমোদিত হয়েছে। ${payment.planName} এখন সম্পূর্ণ সক্রিয়!`,
      type: 'success',
      isRead: false,
      createdAt: reviewedAt,
    };
    setNotifications(prev => [approvalNotif, ...prev]);

    return { success: true, message: `Payment approved! ${payment.planName} has been unlocked for ${payment.userName}.` };
  };

  const rejectVipPayment = (paymentId: string, remark: string = 'Payment could not be verified in bank statement') => {
    const payment = vipPayments.find(p => p.id === paymentId);
    if (!payment) return { success: false, message: 'Payment record not found.' };

    const reviewedAt = new Date().toISOString();
    setVipPayments(prev => prev.map(p => p.id === paymentId ? { ...p, status: 'rejected', reviewedAt, adminRemark: remark } : p));

    const rejectNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      userId: payment.userId,
      title: '⚠️ VIP Payment Rejected',
      titleBn: '⚠️ ভিআইপি পেমেন্ট প্রত্যাখ্যান করা হয়েছে',
      message: `Your payment of ₹${payment.amountRupees} for ${payment.planName} (UTR: ${payment.utrNumber}) was rejected: "${remark}". Please check your transaction details and re-submit.`,
      messageBn: `আপনার ${payment.planName}-এর ₹${payment.amountRupees} পেমেন্ট (UTR: ${payment.utrNumber}) বাতিল করা হয়েছে: "${remark}"। অনুগ্রহ করে সঠিক তথ্য দিয়ে পুনরায় চেষ্টা করুন।`,
      type: 'warning',
      isRead: false,
      createdAt: reviewedAt,
    };
    setNotifications(prev => [rejectNotif, ...prev]);

    return { success: true, message: 'Payment marked as rejected.' };
  };

  // Withdrawals
  const createWithdrawalRequest = (amountCoins: number, method: WithdrawalMethod, accountDetails: string) => {
    if (!currentUser) return { success: false, message: 'Please sign in.' };

    const isVipUser = currentUser.membershipTier && ['vip1', 'vip2', 'vip3', 'vip4', 'vip5', 'pro', 'premium'].includes(currentUser.membershipTier);
    const minRequired = isVipUser ? 10 : systemSettings.minWithdrawalCoins;

    if (amountCoins < minRequired) {
      return {
        success: false,
        message: language === 'bn' 
          ? `সর্বনিম্ন উত্তোলন সীমা ${minRequired} কয়েন।` 
          : `Minimum withdrawal amount is ${minRequired} Coins.`,
      };
    }

    if (currentUser.coins < amountCoins) {
      return {
        success: false,
        message: language === 'bn' ? 'আপনার অ্যাকাউন্টে পর্যাপ্ত কয়েন নেই।' : 'Insufficient coin balance in wallet.',
      };
    }

    if (!accountDetails.trim()) {
      return {
        success: false,
        message: language === 'bn' ? 'অনুগ্রহ করে সঠিক অ্যাকাউন্ট বিবরণ দিন।' : 'Please provide recipient account details.',
      };
    }

    const currencyAmount = Number((amountCoins / systemSettings.coinsPerCurrencyUnit).toFixed(2));

    const newRequest: WithdrawalRequest = {
      id: `wd-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      amountCoins,
      amountCurrency: currencyAmount,
      currency: systemSettings.currencyCode,
      method,
      accountDetails,
      status: 'pending',
      requestedAt: new Date().toISOString(),
    };

    setWithdrawals(prev => [newRequest, ...prev]);

    // Deduct coins from user balance immediately
    const updatedUser: User = {
      ...currentUser,
      coins: currentUser.coins - amountCoins,
    };
    setCurrentUser(updatedUser);

    const tx: Transaction = {
      id: `tx-wd-req-${Date.now()}`,
      userId: currentUser.id,
      type: 'withdrawal',
      title: `Withdrawal Request (${method.toUpperCase()})`,
      titleBn: `উত্তোলন আবেদন (${method.toUpperCase()})`,
      coins: -amountCoins,
      balanceAfter: updatedUser.coins,
      timestamp: new Date().toISOString(),
      referenceId: newRequest.id,
      status: 'pending',
    };
    setTransactions(prev => [tx, ...prev]);

    return {
      success: true,
      message: language === 'bn' 
        ? 'উত্তোলন অনুরোধ সফলভাবে জমা দেওয়া হয়েছে। অ্যাডমিন পর্যালোচনার পর সম্পন্ন হবে।' 
        : 'Withdrawal request submitted! It will be reviewed by admin.',
    };
  };

  const approveWithdrawal = (id: string, refId: string, remark?: string) => {
    setWithdrawals(prev => prev.map(w => {
      if (w.id === id) {
        // Also increase user's withdrawnCoins
        setAllUsers(users => users.map(u => {
          if (u.id === w.userId) {
            return { ...u, withdrawnCoins: (u.withdrawnCoins || 0) + w.amountCoins };
          }
          return u;
        }));
        if (currentUser && currentUser.id === w.userId) {
          setCurrentUser(u => u ? { ...u, withdrawnCoins: (u.withdrawnCoins || 0) + w.amountCoins } : null);
        }

        // Update transaction status
        setTransactions(txs => txs.map(t => {
          if (t.referenceId === id) {
            return { ...t, status: 'completed', referenceId: refId };
          }
          return t;
        }));

        // Send notification
        const notif: NotificationItem = {
          id: `notif-${Date.now()}`,
          userId: w.userId,
          title: 'Withdrawal Approved (Demo)',
          titleBn: 'উত্তোলন অনুমোদিত (ডেমো)',
          message: `Your withdrawal of ${w.amountCoins} coins ($${w.amountCurrency}) via ${w.method.toUpperCase()} was approved! Ref: ${refId}`,
          messageBn: `আপনার ${w.amountCoins} কয়েনের ($${w.amountCurrency}) উত্তোলন অনুমোদিত হয়েছে। ট্রানজেকশন: ${refId}`,
          type: 'success',
          isRead: false,
          createdAt: new Date().toISOString(),
        };
        setNotifications(n => [notif, ...n]);

        return {
          ...w,
          status: 'approved',
          processedAt: new Date().toISOString(),
          transactionRef: refId,
          adminRemark: remark || 'Approved by Administrator',
        };
      }
      return w;
    }));
  };

  const rejectWithdrawal = (id: string, remark: string) => {
    setWithdrawals(prev => prev.map(w => {
      if (w.id === id) {
        // Refund coins to user
        setAllUsers(users => users.map(u => {
          if (u.id === w.userId) {
            return { ...u, coins: u.coins + w.amountCoins };
          }
          return u;
        }));
        if (currentUser && currentUser.id === w.userId) {
          setCurrentUser(u => u ? { ...u, coins: u.coins + w.amountCoins } : null);
        }

        // Update transaction status
        setTransactions(txs => txs.map(t => {
          if (t.referenceId === id) {
            return { ...t, status: 'failed' };
          }
          return t;
        }));

        // Send notification
        const notif: NotificationItem = {
          id: `notif-${Date.now()}`,
          userId: w.userId,
          title: 'Withdrawal Rejected',
          titleBn: 'উত্তোলন বাতিল করা হয়েছে',
          message: `Your withdrawal request of ${w.amountCoins} coins was rejected: ${remark}. The coins have been refunded to your wallet.`,
          messageBn: `আপনার ${w.amountCoins} কয়েনের উত্তোলন বাতিল করা হয়েছে: ${remark}। কয়েন আপনার ওয়ালেটে ফেরত দেওয়া হয়েছে।`,
          type: 'warning',
          isRead: false,
          createdAt: new Date().toISOString(),
        };
        setNotifications(n => [notif, ...n]);

        return {
          ...w,
          status: 'rejected',
          processedAt: new Date().toISOString(),
          adminRemark: remark,
        };
      }
      return w;
    }));
  };

  const claimReferralBonus = (code: string): boolean => {
    if (!currentUser) return false;
    const referrer = allUsers.find(u => u.referralCode.toUpperCase() === code.trim().toUpperCase());
    if (!referrer || referrer.id === currentUser.id) return false;

    // Give bonus to both
    const bonus = systemSettings.referralBonusCoins;
    setAllUsers(prev => prev.map(u => {
      if (u.id === referrer.id) {
        return { ...u, coins: u.coins + bonus, lifetimeCoins: u.lifetimeCoins + bonus };
      }
      return u;
    }));

    const updatedUser: User = {
      ...currentUser,
      coins: currentUser.coins + systemSettings.referredUserBonusCoins,
      lifetimeCoins: currentUser.lifetimeCoins + systemSettings.referredUserBonusCoins,
      referredBy: code,
    };
    setCurrentUser(updatedUser);
    return true;
  };

  // Notifications
  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const sendAdminBroadcast = (
    title: string,
    message: string,
    titleBn?: string,
    messageBn?: string,
    type: NotificationItem['type'] = 'info'
  ) => {
    const newNotif: NotificationItem = {
      id: `broadcast-${Date.now()}`,
      userId: 'all',
      title,
      titleBn: titleBn || title,
      message,
      messageBn: messageBn || message,
      type,
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  // Admin User Management
  const toggleUserStatus = (userId: string) => {
    setAllUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const nextStatus = !u.isActive;
        if (currentUser?.id === userId) {
          setCurrentUser({ ...currentUser, isActive: nextStatus });
        }
        return { ...u, isActive: nextStatus };
      }
      return u;
    }));
  };

  const adjustUserCoins = (userId: string, amount: number, reason: string) => {
    setAllUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const newBalance = Math.max(0, u.coins + amount);
        const tx: Transaction = {
          id: `tx-adjust-${Date.now()}`,
          userId,
          type: 'admin_adjustment',
          title: `Admin Adjustment: ${reason}`,
          titleBn: `অ্যাডমিন সমন্বয়: ${reason}`,
          coins: amount,
          balanceAfter: newBalance,
          timestamp: new Date().toISOString(),
          status: 'completed',
        };
        setTransactions(txs => [tx, ...txs]);

        if (currentUser?.id === userId) {
          setCurrentUser({ ...currentUser, coins: newBalance });
        }
        return { ...u, coins: newBalance };
      }
      return u;
    }));
  };

  const updateUserTierAdmin = (userId: string, tier: MembershipTier) => {
    setAllUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const updated = { ...u, membershipTier: tier };
        if (currentUser?.id === userId) {
          setCurrentUser(updated);
        }
        return updated;
      }
      return u;
    }));
  };

  // Tasks Management
  const addNewTask = (taskData: Omit<Task, 'id' | 'createdAt'>) => {
    const newTask: Task = {
      ...taskData,
      id: `task-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const updateSystemSettings = (newSettings: Partial<SystemSettings>) => {
    setSystemSettings(prev => ({ ...prev, ...newSettings }));
  };

  const recordPlaySeen = (durationSeconds: number = 15) => {
    const currentPlays = systemSettings.totalPlaysSeen || 34820;
    const currentRevenue = systemSettings.adminTotalAdRevenueRupees || 8705;
    const cpm = systemSettings.adminCpmRateRupees || 250;
    const perPlayRevenue = Number((cpm / 1000).toFixed(4));
    const newPlays = currentPlays + 1;
    const newRevenue = Number((currentRevenue + perPlayRevenue).toFixed(2));

    setSystemSettings(prev => ({
      ...prev,
      totalPlaysSeen: newPlays,
      adminTotalAdRevenueRupees: newRevenue,
    }));

    return { playsSeen: newPlays, revenueEarned: newRevenue };
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        isDarkMode,
        toggleDarkMode,
        currentUser,
        isAdminAuthenticated,
        loginUser,
        registerUser,
        loginWithGoogle,
        loginWithGoogleAccount,
        connectGoogleTasksAuth,
        connectGoogleTester,
        logoutUser,
        adminLogin,
        adminLogout,
        updateUserProfile,
        tasks,
        taskSubmissions,
        submitTaskCompletion,
        getUserDailyTaskCount,
        addNewTask,
        updateTask,
        deleteTask,
        approveTaskSubmission,
        rejectTaskSubmission,
        claimDailyCheckin,
        hasClaimedDailyToday,
        isGoogleConnected,
        googleTasks,
        setGoogleTasks,
        claimGoogleTaskReward,
        membershipPlans,
        upgradeMembership,
        vipPayments,
        submitVipPayment,
        approveVipPayment,
        rejectVipPayment,
        conversionRateUSD: systemSettings.coinsPerCurrencyUnit,
        withdrawals,
        createWithdrawalRequest,
        approveWithdrawal,
        rejectWithdrawal,
        transactions,
        claimReferralBonus,
        notifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        sendAdminBroadcast,
        supportMessages,
        sendSupportMessage,
        replySupportMessage,
        allUsers,
        toggleUserStatus,
        adjustUserCoins,
        updateUserTierAdmin,
        systemSettings,
        updateSystemSettings,
        recordPlaySeen,
        isDataLoading,
        refreshData,
        goldPricePerGram,
        silverPricePerGram,
        investmentOrders,
        kycRecords,
        investmentCoupons,
        buyMetal,
        sellMetal,
        submitKyc,
        verifyKycAdmin,
        createCoupon,
        toggleCouponActive,
        priceAlerts,
        addPriceAlert,
        deletePriceAlert,
        togglePriceAlert,
        sipPlans,
        createSipPlan,
        toggleSipPlan,
        deleteSipPlan,
        companyInfo,
        updateCompanyInfo,
        appLicence,
        updateAppLicence,
        metalProviderConfig,
        updateMetalProviderConfig,
        sbiBankAccount,
        allSbiBankAccounts,
        linkSbiBankAccount,
        unlinkSbiBankAccount,
        updateSbiBankStatusAdmin,
        advancedKyc,
        allAdvancedKycRecords,
        submitAdvancedKyc,
        updateAdvancedKycStatusAdmin,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
