import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type {
  AppDataState,
  AppSettings,
  AuditAction,
  AuditLogEntry,
  CommitteeAccount,
  CommitteeTransaction,
  CustomModuleDef,
  CustomRecord,
  CustomReportDef,
  ExpenseCategory,
  ExpenseRecord,
  LeaveRecord,
  LeaveYearOpening,
  LoanPerson,
  LoanTransaction,
  NavSection,
  OfficeTaskRecord,
  PurchaseRecord,
  RecycleBinItem,
  RecycleModuleType,
  ThemePreset,
} from '../types';
import {
  generateId,
  loadAppState,
  loadSafetyBackup,
  saveAppState,
  saveSafetyBackup,
} from '../utils/storage';
import { t } from '../utils/i18n';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  text: string;
}

export interface ThemeTokens {
  sidebarBg: string;
  sidebarText: string;
  sidebarHover: string;
  sidebarActive: string;
  accentBg: string;
  accentHover: string;
  accentText: string;
  accentSoft: string;
  brandBadgeBg: string;
  headerAccent: string;
}

export const THEME_TOKENS: Record<ThemePreset, ThemeTokens> = {
  'navy-emerald': {
    sidebarBg: 'bg-[#0C203D]',
    sidebarText: 'text-slate-200',
    sidebarHover: 'hover:bg-[#143058]',
    sidebarActive: 'bg-[#059669] text-white',
    accentBg: 'bg-[#059669]',
    accentHover: 'hover:bg-[#047857]',
    accentText: 'text-[#059669]',
    accentSoft: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    brandBadgeBg: 'bg-[#059669]',
    headerAccent: 'text-[#0C203D]',
  },
  'slate-teal': {
    sidebarBg: 'bg-slate-900',
    sidebarText: 'text-slate-200',
    sidebarHover: 'hover:bg-slate-800',
    sidebarActive: 'bg-teal-600 text-white',
    accentBg: 'bg-teal-600',
    accentHover: 'hover:bg-teal-700',
    accentText: 'text-teal-700',
    accentSoft: 'bg-teal-50 text-teal-800 border-teal-200',
    brandBadgeBg: 'bg-teal-600',
    headerAccent: 'text-slate-900',
  },
  'charcoal-forest': {
    sidebarBg: 'bg-zinc-900',
    sidebarText: 'text-zinc-200',
    sidebarHover: 'hover:bg-zinc-800',
    sidebarActive: 'bg-green-700 text-white',
    accentBg: 'bg-green-700',
    accentHover: 'hover:bg-green-800',
    accentText: 'text-green-700',
    accentSoft: 'bg-green-50 text-green-800 border-green-200',
    brandBadgeBg: 'bg-green-700',
    headerAccent: 'text-zinc-900',
  },
};

interface AppContextValue {
  state: AppDataState;
  activeSection: NavSection;
  activeSubTab: string;
  focusedRecordId: string | null;
  navigate: (section: NavSection, subTab?: string, recordId?: string | null) => void;
  clearFocusedRecord: () => void;
  tr: (key: string, fallback?: string) => string;
  themeTokens: ThemeTokens;
  toasts: ToastMessage[];
  notify: (text: string, type?: 'success' | 'error' | 'info') => void;
  dismissToast: (id: string) => void;

  // Settings
  updateSettings: (patch: Partial<AppSettings>, auditSummary?: string) => void;

  // Home: Purchases
  upsertPurchase: (record: Omit<PurchaseRecord, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => void;
  deletePurchase: (id: string) => void;

  // Home: Expenses & Categories
  upsertExpense: (record: Omit<ExpenseRecord, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => void;
  deleteExpense: (id: string) => void;
  saveExpenseCategories: (categories: ExpenseCategory[], summary?: string) => void;

  // Factory: Leave
  upsertLeave: (record: Omit<LeaveRecord, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => void;
  deleteLeave: (id: string) => void;
  upsertLeaveYearOpening: (opening: LeaveYearOpening) => void;

  // Factory: Office Tasks
  upsertTask: (record: Omit<OfficeTaskRecord, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => void;
  deleteTask: (id: string) => void;

  // Personal: Loan
  upsertLoanPerson: (person: Omit<LoanPerson, 'id' | 'createdAt'>, existingId?: string) => string;
  deleteLoanPerson: (id: string) => void;
  upsertLoanTx: (tx: Omit<LoanTransaction, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => void;
  deleteLoanTx: (id: string) => void;

  // Personal: Committee
  upsertCommittee: (c: Omit<CommitteeAccount, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => string;
  deleteCommittee: (id: string) => void;
  upsertCommitteeTx: (tx: Omit<CommitteeTransaction, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => void;
  deleteCommitteeTx: (id: string) => void;

  // Dynamic Settings: Custom Modules & Records & Reports
  saveCustomModules: (modules: CustomModuleDef[], summary?: string) => void;
  upsertCustomRecord: (
    moduleId: string,
    values: Record<string, string | number | boolean | string[]>,
    submoduleId?: string,
    existingId?: string
  ) => void;
  deleteCustomRecord: (id: string) => void;
  saveCustomReports: (reports: CustomReportDef[], summary?: string) => void;

  // Recycle Bin
  restoreRecycleItem: (recycleId: string) => void;
  permanentDeleteRecycleItem: (recycleId: string) => void;
  emptyRecycleBin: () => void;

  // Backup & Restore
  replaceAllData: (nextState: AppDataState, mode: 'replace' | 'merge') => void;
  restoreSafetyBackup: () => boolean;
  hasSafetyBackup: boolean;
}

const AppContext = createContext<AppContextValue | null>(null);

function makeAudit(
  action: AuditAction,
  module: string,
  recordRef: string,
  summary: string
): AuditLogEntry {
  return {
    id: generateId('aud'),
    timestamp: new Date().toISOString(),
    action,
    module,
    recordRef,
    summary,
  };
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppDataState>(() => loadAppState());
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [activeSubTab, setActiveSubTab] = useState<string>('');
  const [focusedRecordId, setFocusedRecordId] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [hasSafetyBackup, setHasSafetyBackup] = useState<boolean>(() => Boolean(loadSafetyBackup()));

  useEffect(() => {
    saveAppState(state);
  }, [state]);

  useEffect(() => {
    document.documentElement.dir = state.settings.language === 'ur' ? 'rtl' : 'ltr';
    document.documentElement.lang = state.settings.language;
  }, [state.settings.language]);

  const notify = useCallback((text: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = generateId('toast');
    setToasts((prev) => [...prev.slice(-3), { id, type, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 4000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const navigate = useCallback((section: NavSection, subTab = '', recordId: string | null = null) => {
    setActiveSection(section);
    setActiveSubTab(subTab);
    setFocusedRecordId(recordId);
  }, []);

  const clearFocusedRecord = useCallback(() => setFocusedRecordId(null), []);

  const tr = useCallback(
    (key: string, fallback?: string) => t(state.settings.language, key, fallback),
    [state.settings.language]
  );

  const themeTokens = useMemo(
    () => THEME_TOKENS[state.settings.theme] || THEME_TOKENS['navy-emerald'],
    [state.settings.theme]
  );

  const updateSettings = useCallback(
    (patch: Partial<AppSettings>, auditSummary = 'Updated application settings') => {
      setState((prev) => ({
        ...prev,
        settings: { ...prev.settings, ...patch },
        auditLog: [makeAudit('Settings Change', 'Settings', 'settings', auditSummary), ...prev.auditLog],
      }));
    },
    []
  );

  // --- Purchases ---
  const upsertPurchase = useCallback(
    (record: Omit<PurchaseRecord, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => {
      const now = new Date().toISOString();
      setState((prev) => {
        if (existingId) {
          const next = prev.purchases.map((p) =>
            p.id === existingId ? { ...p, ...record, updatedAt: now } : p
          );
          return {
            ...prev,
            purchases: next,
            auditLog: [
              makeAudit(
                'Edit',
                'Home / Purchase',
                existingId,
                `Edited purchase: ${record.quantityMaund} Maund from ${record.supplier || 'Supplier'} (${record.totalAmount})`
              ),
              ...prev.auditLog,
            ],
          };
        }
        const newRec: PurchaseRecord = {
          ...record,
          id: generateId('pur'),
          createdAt: now,
          updatedAt: now,
        };
        return {
          ...prev,
          purchases: [newRec, ...prev.purchases],
          auditLog: [
            makeAudit(
              'Create',
              'Home / Purchase',
              newRec.id,
              `Added purchase: ${record.quantityMaund} Maund (${record.equivalentKg} KG) from ${record.supplier || 'Supplier'}`
            ),
            ...prev.auditLog,
          ],
        };
      });
    },
    []
  );

  const deletePurchase = useCallback((id: string) => {
    setState((prev) => {
      const target = prev.purchases.find((p) => p.id === id);
      if (!target) return prev;
      const binItem: RecycleBinItem = {
        id: generateId('bin'),
        deletedAt: new Date().toISOString(),
        moduleType: 'purchase',
        moduleLabel: 'Home / Purchase',
        summary: `${target.date} · ${target.quantityMaund} Maund · ${target.supplier || 'Purchase'} · ${target.totalAmount}`,
        recordId: target.id,
        payload: target,
      };
      return {
        ...prev,
        purchases: prev.purchases.filter((p) => p.id !== id),
        recycleBin: [binItem, ...prev.recycleBin],
        auditLog: [
          makeAudit('Delete', 'Home / Purchase', id, `Moved purchase (${target.quantityMaund} Maund) to Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  // --- Expenses ---
  const upsertExpense = useCallback(
    (record: Omit<ExpenseRecord, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => {
      const now = new Date().toISOString();
      setState((prev) => {
        if (existingId) {
          return {
            ...prev,
            expenses: prev.expenses.map((e) =>
              e.id === existingId ? { ...e, ...record, updatedAt: now } : e
            ),
            auditLog: [
              makeAudit('Edit', 'Home / Expenses', existingId, `Edited expense: ${record.category} — ${record.description} (${record.amount})`),
              ...prev.auditLog,
            ],
          };
        }
        const newRec: ExpenseRecord = {
          ...record,
          id: generateId('exp'),
          createdAt: now,
          updatedAt: now,
        };
        return {
          ...prev,
          expenses: [newRec, ...prev.expenses],
          auditLog: [
            makeAudit('Create', 'Home / Expenses', newRec.id, `Added expense: ${record.category} — ${record.description} (${record.amount})`),
            ...prev.auditLog,
          ],
        };
      });
    },
    []
  );

  const deleteExpense = useCallback((id: string) => {
    setState((prev) => {
      const target = prev.expenses.find((e) => e.id === id);
      if (!target) return prev;
      const binItem: RecycleBinItem = {
        id: generateId('bin'),
        deletedAt: new Date().toISOString(),
        moduleType: 'expense',
        moduleLabel: 'Home / Expenses',
        summary: `${target.date} · ${target.category} · ${target.description} · ${target.amount}`,
        recordId: target.id,
        payload: target,
      };
      return {
        ...prev,
        expenses: prev.expenses.filter((e) => e.id !== id),
        recycleBin: [binItem, ...prev.recycleBin],
        auditLog: [
          makeAudit('Delete', 'Home / Expenses', id, `Moved expense (${target.description}) to Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  const saveExpenseCategories = useCallback(
    (categories: ExpenseCategory[], summary = 'Updated household expense categories') => {
      setState((prev) => ({
        ...prev,
        expenseCategories: categories,
        auditLog: [makeAudit('Settings Change', 'Home / Expenses', 'categories', summary), ...prev.auditLog],
      }));
    },
    []
  );

  // --- Factory Leave ---
  const upsertLeave = useCallback(
    (record: Omit<LeaveRecord, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => {
      const now = new Date().toISOString();
      setState((prev) => {
        if (existingId) {
          return {
            ...prev,
            leaves: prev.leaves.map((l) =>
              l.id === existingId ? { ...l, ...record, updatedAt: now } : l
            ),
            auditLog: [
              makeAudit('Edit', 'Factory / Leave', existingId, `Edited leave entry: ${record.type} (${record.days}) on ${record.date}`),
              ...prev.auditLog,
            ],
          };
        }
        const newRec: LeaveRecord = {
          ...record,
          id: generateId('lv'),
          createdAt: now,
          updatedAt: now,
        };
        return {
          ...prev,
          leaves: [newRec, ...prev.leaves],
          auditLog: [
            makeAudit('Create', 'Factory / Leave', newRec.id, `Added leave entry: ${record.type} (${record.days}) on ${record.date}`),
            ...prev.auditLog,
          ],
        };
      });
    },
    []
  );

  const deleteLeave = useCallback((id: string) => {
    setState((prev) => {
      const target = prev.leaves.find((l) => l.id === id);
      if (!target) return prev;
      const binItem: RecycleBinItem = {
        id: generateId('bin'),
        deletedAt: new Date().toISOString(),
        moduleType: 'leave',
        moduleLabel: 'Factory / Leave',
        summary: `${target.date} · ${target.type} (${target.days}) · ${target.reason || target.employee}`,
        recordId: target.id,
        payload: target,
      };
      return {
        ...prev,
        leaves: prev.leaves.filter((l) => l.id !== id),
        recycleBin: [binItem, ...prev.recycleBin],
        auditLog: [
          makeAudit('Delete', 'Factory / Leave', id, `Moved leave entry (${target.type}, ${target.days}) to Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  const upsertLeaveYearOpening = useCallback((opening: LeaveYearOpening) => {
    setState((prev) => {
      const exists = prev.leaveYearOpenings.some((o) => o.leaveYear === opening.leaveYear);
      const next = exists
        ? prev.leaveYearOpenings.map((o) => (o.leaveYear === opening.leaveYear ? opening : o))
        : [...prev.leaveYearOpenings, opening];
      return {
        ...prev,
        leaveYearOpenings: next,
        auditLog: [
          makeAudit(
            'Settings Change',
            'Factory / Leave',
            opening.leaveYear,
            `Updated leave year ${opening.leaveYear} entitlements/openings (CL ${opening.clEntitlement}, SL ${opening.slEntitlement})`
          ),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  // --- Office Tasks ---
  const upsertTask = useCallback(
    (record: Omit<OfficeTaskRecord, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => {
      const now = new Date().toISOString();
      setState((prev) => {
        if (existingId) {
          return {
            ...prev,
            tasks: prev.tasks.map((task) =>
              task.id === existingId ? { ...task, ...record, updatedAt: now } : task
            ),
            auditLog: [
              makeAudit('Edit', 'Factory / Tasks', existingId, `Updated task "${record.title}" (${record.status})`),
              ...prev.auditLog,
            ],
          };
        }
        const newRec: OfficeTaskRecord = {
          ...record,
          id: generateId('tsk'),
          createdAt: now,
          updatedAt: now,
        };
        return {
          ...prev,
          tasks: [newRec, ...prev.tasks],
          auditLog: [
            makeAudit('Create', 'Factory / Tasks', newRec.id, `Created task "${record.title}" (${record.priority})`),
            ...prev.auditLog,
          ],
        };
      });
    },
    []
  );

  const deleteTask = useCallback((id: string) => {
    setState((prev) => {
      const target = prev.tasks.find((task) => task.id === id);
      if (!target) return prev;
      const binItem: RecycleBinItem = {
        id: generateId('bin'),
        deletedAt: new Date().toISOString(),
        moduleType: 'task',
        moduleLabel: 'Factory / Tasks',
        summary: `${target.title} · ${target.status} · Due ${target.dueDate || '—'}`,
        recordId: target.id,
        payload: target,
      };
      return {
        ...prev,
        tasks: prev.tasks.filter((task) => task.id !== id),
        recycleBin: [binItem, ...prev.recycleBin],
        auditLog: [
          makeAudit('Delete', 'Factory / Tasks', id, `Moved task "${target.title}" to Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  // --- Personal: Loan ---
  const upsertLoanPerson = useCallback(
    (person: Omit<LoanPerson, 'id' | 'createdAt'>, existingId?: string): string => {
      const id = existingId || generateId('lp');
      const now = new Date().toISOString();
      setState((prev) => {
        if (existingId) {
          return {
            ...prev,
            loanPersons: prev.loanPersons.map((p) => (p.id === existingId ? { ...p, ...person } : p)),
            loanTransactions: prev.loanTransactions.map((tx) =>
              tx.personId === existingId ? { ...tx, personName: person.name } : tx
            ),
            auditLog: [
              makeAudit('Edit', 'Personal / Loan', existingId, `Updated lender "${person.name}"`),
              ...prev.auditLog,
            ],
          };
        }
        return {
          ...prev,
          loanPersons: [...prev.loanPersons, { ...person, id, createdAt: now }],
          auditLog: [
            makeAudit('Create', 'Personal / Loan', id, `Added lender "${person.name}" (Opening: ${person.openingBalance})`),
            ...prev.auditLog,
          ],
        };
      });
      return id;
    },
    []
  );

  const deleteLoanPerson = useCallback((id: string) => {
    setState((prev) => {
      const target = prev.loanPersons.find((p) => p.id === id);
      if (!target) return prev;
      const binItem: RecycleBinItem = {
        id: generateId('bin'),
        deletedAt: new Date().toISOString(),
        moduleType: 'loan_person',
        moduleLabel: 'Personal / Loan Lender',
        summary: `${target.name} · Opening ${target.openingBalance}`,
        recordId: target.id,
        payload: target,
      };
      return {
        ...prev,
        loanPersons: prev.loanPersons.filter((p) => p.id !== id),
        recycleBin: [binItem, ...prev.recycleBin],
        auditLog: [
          makeAudit('Delete', 'Personal / Loan', id, `Moved lender "${target.name}" to Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  const upsertLoanTx = useCallback(
    (tx: Omit<LoanTransaction, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => {
      const now = new Date().toISOString();
      setState((prev) => {
        if (existingId) {
          return {
            ...prev,
            loanTransactions: prev.loanTransactions.map((item) =>
              item.id === existingId ? { ...item, ...tx, updatedAt: now } : item
            ),
            auditLog: [
              makeAudit('Edit', 'Personal / Loan', existingId, `Edited loan ${tx.type}: ${tx.personName} (${tx.amount})`),
              ...prev.auditLog,
            ],
          };
        }
        const newRec: LoanTransaction = {
          ...tx,
          id: generateId('ltx'),
          createdAt: now,
          updatedAt: now,
        };
        return {
          ...prev,
          loanTransactions: [newRec, ...prev.loanTransactions],
          auditLog: [
            makeAudit('Create', 'Personal / Loan', newRec.id, `Recorded loan ${tx.type}: ${tx.personName} (${tx.amount})`),
            ...prev.auditLog,
          ],
        };
      });
    },
    []
  );

  const deleteLoanTx = useCallback((id: string) => {
    setState((prev) => {
      const target = prev.loanTransactions.find((tx) => tx.id === id);
      if (!target) return prev;
      const binItem: RecycleBinItem = {
        id: generateId('bin'),
        deletedAt: new Date().toISOString(),
        moduleType: 'loan_tx',
        moduleLabel: 'Personal / Loan',
        summary: `${target.transactionDate} · ${target.personName} · ${target.type} · ${target.amount}`,
        recordId: target.id,
        payload: target,
      };
      return {
        ...prev,
        loanTransactions: prev.loanTransactions.filter((tx) => tx.id !== id),
        recycleBin: [binItem, ...prev.recycleBin],
        auditLog: [
          makeAudit('Delete', 'Personal / Loan', id, `Moved loan transaction (${target.personName}, ${target.amount}) to Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  // --- Personal: Committee ---
  const upsertCommittee = useCallback(
    (c: Omit<CommitteeAccount, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string): string => {
      const id = existingId || generateId('com');
      const now = new Date().toISOString();
      setState((prev) => {
        if (existingId) {
          return {
            ...prev,
            committees: prev.committees.map((item) =>
              item.id === existingId ? { ...item, ...c, updatedAt: now } : item
            ),
            committeeTransactions: prev.committeeTransactions.map((tx) =>
              tx.committeeId === existingId ? { ...tx, committeeTitle: c.title } : tx
            ),
            auditLog: [
              makeAudit('Edit', 'Personal / Committee', existingId, `Updated committee "${c.title}"`),
              ...prev.auditLog,
            ],
          };
        }
        return {
          ...prev,
          committees: [{ ...c, id, createdAt: now, updatedAt: now }, ...prev.committees],
          auditLog: [
            makeAudit('Create', 'Personal / Committee', id, `Created committee "${c.title}" (Total: ${c.totalAmount})`),
            ...prev.auditLog,
          ],
        };
      });
      return id;
    },
    []
  );

  const deleteCommittee = useCallback((id: string) => {
    setState((prev) => {
      const target = prev.committees.find((c) => c.id === id);
      if (!target) return prev;
      const binItem: RecycleBinItem = {
        id: generateId('bin'),
        deletedAt: new Date().toISOString(),
        moduleType: 'committee',
        moduleLabel: 'Personal / Committee',
        summary: `${target.title} · ${target.personOrGroup} · ${target.totalAmount}`,
        recordId: target.id,
        payload: target,
      };
      return {
        ...prev,
        committees: prev.committees.filter((c) => c.id !== id),
        recycleBin: [binItem, ...prev.recycleBin],
        auditLog: [
          makeAudit('Delete', 'Personal / Committee', id, `Moved committee "${target.title}" to Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  const upsertCommitteeTx = useCallback(
    (tx: Omit<CommitteeTransaction, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => {
      const now = new Date().toISOString();
      setState((prev) => {
        if (existingId) {
          return {
            ...prev,
            committeeTransactions: prev.committeeTransactions.map((item) =>
              item.id === existingId ? { ...item, ...tx, updatedAt: now } : item
            ),
            auditLog: [
              makeAudit('Edit', 'Personal / Committee', existingId, `Edited committee ${tx.type}: ${tx.committeeTitle} (${tx.amount})`),
              ...prev.auditLog,
            ],
          };
        }
        const newRec: CommitteeTransaction = {
          ...tx,
          id: generateId('ctx'),
          createdAt: now,
          updatedAt: now,
        };
        return {
          ...prev,
          committeeTransactions: [newRec, ...prev.committeeTransactions],
          auditLog: [
            makeAudit('Create', 'Personal / Committee', newRec.id, `Recorded committee ${tx.type}: ${tx.committeeTitle} (${tx.amount})`),
            ...prev.auditLog,
          ],
        };
      });
    },
    []
  );

  const deleteCommitteeTx = useCallback((id: string) => {
    setState((prev) => {
      const target = prev.committeeTransactions.find((tx) => tx.id === id);
      if (!target) return prev;
      const binItem: RecycleBinItem = {
        id: generateId('bin'),
        deletedAt: new Date().toISOString(),
        moduleType: 'committee_tx',
        moduleLabel: 'Personal / Committee Entry',
        summary: `${target.date} · ${target.committeeTitle} · ${target.type} · ${target.amount}`,
        recordId: target.id,
        payload: target,
      };
      return {
        ...prev,
        committeeTransactions: prev.committeeTransactions.filter((tx) => tx.id !== id),
        recycleBin: [binItem, ...prev.recycleBin],
        auditLog: [
          makeAudit('Delete', 'Personal / Committee', id, `Moved committee entry (${target.committeeTitle}, ${target.amount}) to Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  // --- Dynamic Settings / Custom Modules ---
  const saveCustomModules = useCallback(
    (modules: CustomModuleDef[], summary = 'Updated custom modules configuration') => {
      setState((prev) => ({
        ...prev,
        customModules: modules,
        auditLog: [makeAudit('Settings Change', 'Dynamic Settings', 'custom_modules', summary), ...prev.auditLog],
      }));
    },
    []
  );

  const upsertCustomRecord = useCallback(
    (
      moduleId: string,
      values: Record<string, string | number | boolean | string[]>,
      submoduleId?: string,
      existingId?: string
    ) => {
      const now = new Date().toISOString();
      setState((prev) => {
        const modName = prev.customModules.find((m) => m.id === moduleId)?.name || 'Custom Module';
        if (existingId) {
          return {
            ...prev,
            customRecords: prev.customRecords.map((r) =>
              r.id === existingId ? { ...r, values, submoduleId, updatedAt: now } : r
            ),
            auditLog: [
              makeAudit('Edit', modName, existingId, `Updated record in ${modName}`),
              ...prev.auditLog,
            ],
          };
        }
        const newRec: CustomRecord = {
          id: generateId('crec'),
          moduleId,
          submoduleId,
          values,
          createdAt: now,
          updatedAt: now,
        };
        return {
          ...prev,
          customRecords: [newRec, ...prev.customRecords],
          auditLog: [
            makeAudit('Create', modName, newRec.id, `Added record in ${modName}`),
            ...prev.auditLog,
          ],
        };
      });
    },
    []
  );

  const deleteCustomRecord = useCallback((id: string) => {
    setState((prev) => {
      const target = prev.customRecords.find((r) => r.id === id);
      if (!target) return prev;
      const modName = prev.customModules.find((m) => m.id === target.moduleId)?.name || 'Custom Module';
      const firstVal = Object.values(target.values).find((v) => v !== '' && v !== null) ?? target.id;
      const binItem: RecycleBinItem = {
        id: generateId('bin'),
        deletedAt: new Date().toISOString(),
        moduleType: 'custom_record',
        moduleLabel: modName,
        summary: `${modName} · ${String(firstVal)}`,
        recordId: target.id,
        payload: target,
      };
      return {
        ...prev,
        customRecords: prev.customRecords.filter((r) => r.id !== id),
        recycleBin: [binItem, ...prev.recycleBin],
        auditLog: [
          makeAudit('Delete', modName, id, `Moved record from ${modName} to Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  const saveCustomReports = useCallback(
    (reports: CustomReportDef[], summary = 'Updated custom reports') => {
      setState((prev) => ({
        ...prev,
        customReports: reports,
        auditLog: [makeAudit('Settings Change', 'Dynamic Settings', 'custom_reports', summary), ...prev.auditLog],
      }));
    },
    []
  );

  // --- Recycle Bin ---
  const restoreRecycleItem = useCallback((recycleId: string) => {
    setState((prev) => {
      const item = prev.recycleBin.find((b) => b.id === recycleId);
      if (!item) return prev;
      const nextBin = prev.recycleBin.filter((b) => b.id !== recycleId);
      const audit = makeAudit('Restore', item.moduleLabel, item.recordId, `Restored from Recycle Bin: ${item.summary}`);

      const type: RecycleModuleType = item.moduleType;
      const nextState: AppDataState = {
        ...prev,
        recycleBin: nextBin,
        auditLog: [audit, ...prev.auditLog],
      };

      if (type === 'purchase') {
        nextState.purchases = [item.payload as PurchaseRecord, ...prev.purchases];
      } else if (type === 'expense') {
        nextState.expenses = [item.payload as ExpenseRecord, ...prev.expenses];
      } else if (type === 'leave') {
        nextState.leaves = [item.payload as LeaveRecord, ...prev.leaves];
      } else if (type === 'task') {
        nextState.tasks = [item.payload as OfficeTaskRecord, ...prev.tasks];
      } else if (type === 'loan_person') {
        nextState.loanPersons = [...prev.loanPersons, item.payload as LoanPerson];
      } else if (type === 'loan_tx') {
        nextState.loanTransactions = [item.payload as LoanTransaction, ...prev.loanTransactions];
      } else if (type === 'committee') {
        nextState.committees = [item.payload as CommitteeAccount, ...prev.committees];
      } else if (type === 'committee_tx') {
        nextState.committeeTransactions = [
          item.payload as CommitteeTransaction,
          ...prev.committeeTransactions,
        ];
      } else if (type === 'custom_record') {
        nextState.customRecords = [item.payload as CustomRecord, ...prev.customRecords];
      }

      return nextState;
    });
  }, []);

  const permanentDeleteRecycleItem = useCallback((recycleId: string) => {
    setState((prev) => {
      const item = prev.recycleBin.find((b) => b.id === recycleId);
      if (!item) return prev;
      return {
        ...prev,
        recycleBin: prev.recycleBin.filter((b) => b.id !== recycleId),
        auditLog: [
          makeAudit('Permanent Delete', item.moduleLabel, item.recordId, `Permanently deleted: ${item.summary}`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  const emptyRecycleBin = useCallback(() => {
    setState((prev) => {
      const count = prev.recycleBin.length;
      if (count === 0) return prev;
      return {
        ...prev,
        recycleBin: [],
        auditLog: [
          makeAudit('Permanent Delete', 'Recycle Bin', 'all', `Permanently cleared ${count} item(s) from Recycle Bin`),
          ...prev.auditLog,
        ],
      };
    });
  }, []);

  // --- Backup & Restore ---
  const replaceAllData = useCallback((nextState: AppDataState, mode: 'replace' | 'merge') => {
    setState((prev) => {
      saveSafetyBackup(prev);
      setHasSafetyBackup(true);

      const dedupeById = <T extends { id: string }>(a: T[], b: T[]): T[] => {
        const map = new Map<string, T>();
        for (const x of a) map.set(x.id, x);
        for (const x of b) map.set(x.id, x);
        return Array.from(map.values());
      };

      const merged: AppDataState =
        mode === 'replace'
          ? {
              ...nextState,
              auditLog: [
                makeAudit('Import/Restore', 'Backup & Restore', 'json_import', 'Replaced application data from JSON backup'),
                ...(nextState.auditLog || []),
              ],
            }
          : {
              ...prev,
              settings: { ...prev.settings, ...nextState.settings },
              purchases: dedupeById(prev.purchases, nextState.purchases),
              expenseCategories: dedupeById(prev.expenseCategories, nextState.expenseCategories),
              expenses: dedupeById(prev.expenses, nextState.expenses),
              leaves: dedupeById(prev.leaves, nextState.leaves),
              leaveYearOpenings: prev.leaveYearOpenings,
              tasks: dedupeById(prev.tasks, nextState.tasks),
              loanPersons: dedupeById(prev.loanPersons, nextState.loanPersons),
              loanTransactions: dedupeById(prev.loanTransactions, nextState.loanTransactions),
              committees: dedupeById(prev.committees, nextState.committees),
              committeeTransactions: dedupeById(prev.committeeTransactions, nextState.committeeTransactions),
              customModules: dedupeById(prev.customModules, nextState.customModules),
              customRecords: dedupeById(prev.customRecords, nextState.customRecords),
              customReports: dedupeById(prev.customReports, nextState.customReports),
              recycleBin: dedupeById(prev.recycleBin, nextState.recycleBin),
              auditLog: [
                makeAudit('Import/Restore', 'Backup & Restore', 'json_merge', 'Merged JSON backup into existing application data'),
                ...prev.auditLog,
              ],
            };

      return merged;
    });
  }, []);

  const restoreSafetyBackup = useCallback((): boolean => {
    const backup = loadSafetyBackup();
    if (!backup) return false;
    setState({
      ...backup.data,
      auditLog: [
        makeAudit('Import/Restore', 'Backup & Restore', 'safety_backup', `Restored safety backup from ${backup.savedAt}`),
        ...backup.data.auditLog,
      ],
    });
    return true;
  }, []);

  const value = useMemo<AppContextValue>(
    () => ({
      state,
      activeSection,
      activeSubTab,
      focusedRecordId,
      navigate,
      clearFocusedRecord,
      tr,
      themeTokens,
      toasts,
      notify,
      dismissToast,
      updateSettings,
      upsertPurchase,
      deletePurchase,
      upsertExpense,
      deleteExpense,
      saveExpenseCategories,
      upsertLeave,
      deleteLeave,
      upsertLeaveYearOpening,
      upsertTask,
      deleteTask,
      upsertLoanPerson,
      deleteLoanPerson,
      upsertLoanTx,
      deleteLoanTx,
      upsertCommittee,
      deleteCommittee,
      upsertCommitteeTx,
      deleteCommitteeTx,
      saveCustomModules,
      upsertCustomRecord,
      deleteCustomRecord,
      saveCustomReports,
      restoreRecycleItem,
      permanentDeleteRecycleItem,
      emptyRecycleBin,
      replaceAllData,
      restoreSafetyBackup,
      hasSafetyBackup,
    }),
    [
      state,
      activeSection,
      activeSubTab,
      focusedRecordId,
      navigate,
      clearFocusedRecord,
      tr,
      themeTokens,
      toasts,
      notify,
      dismissToast,
      updateSettings,
      upsertPurchase,
      deletePurchase,
      upsertExpense,
      deleteExpense,
      saveExpenseCategories,
      upsertLeave,
      deleteLeave,
      upsertLeaveYearOpening,
      upsertTask,
      deleteTask,
      upsertLoanPerson,
      deleteLoanPerson,
      upsertLoanTx,
      deleteLoanTx,
      upsertCommittee,
      deleteCommittee,
      upsertCommitteeTx,
      deleteCommitteeTx,
      saveCustomModules,
      upsertCustomRecord,
      deleteCustomRecord,
      saveCustomReports,
      restoreRecycleItem,
      permanentDeleteRecycleItem,
      emptyRecycleBin,
      replaceAllData,
      restoreSafetyBackup,
      hasSafetyBackup,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
