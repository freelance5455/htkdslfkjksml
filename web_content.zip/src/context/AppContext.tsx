import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  ChatMessage,
  Goal,
  Habit,
  MemoryItem,
  Reminder,
  ScreenId,
  Task,
  Transaction,
  UserProfile,
  ChatAction,
} from '../types';
import {
  initialChatMessages,
  initialGoals,
  initialHabits,
  initialMemories,
  initialProfile,
  initialReminders,
  initialTasks,
  initialTransactions,
} from '../data/mockData';
import { sound } from '../utils/sound';

interface AppContextType {
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
  activeScreen: ScreenId;
  setActiveScreen: (screen: ScreenId) => void;
  isMobileFrameView: boolean;
  setIsMobileFrameView: (val: boolean) => void;
  isOnboarded: boolean;
  completeOnboarding: (data?: Partial<UserProfile>) => void;

  // Tasks
  tasks: Task[];
  addTask: (task: Omit<Task, 'id'>) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  aiAutoSchedule: () => void;

  // Reminders
  reminders: Reminder[];
  addReminder: (reminder: Omit<Reminder, 'id' | 'completed'>) => void;
  toggleReminder: (id: string) => void;
  deleteReminder: (id: string) => void;

  // Goals
  goals: Goal[];
  addGoal: (goal: Omit<Goal, 'id'>) => void;
  updateGoalProgress: (id: string, delta: number) => void;

  // Habits
  habits: Habit[];
  addHabit: (habit: Omit<Habit, 'id' | 'completedToday' | 'streakDays'>) => void;
  toggleHabit: (id: string) => void;

  // Money / Transactions
  transactions: Transaction[];
  monthlyBudget: number;
  setMonthlyBudget: (amount: number) => void;
  totalIncome: number;
  totalExpense: number;
  addTransaction: (tx: Omit<Transaction, 'id'>) => void;

  // Memory
  memories: MemoryItem[];
  addMemory: (item: Omit<MemoryItem, 'id' | 'dateAdded'>) => void;
  deleteMemory: (id: string) => void;
  clearAllMemories: () => void;

  // Chat
  chatMessages: ChatMessage[];
  sendMessage: (text: string, isVoice?: boolean) => void;
  executeChatAction: (action: ChatAction, messageId: string) => void;
  clearChatHistory: () => void;
  isBuddyThinking: boolean;

  // Voice & Sound
  isListening: boolean;
  speechSupported: boolean;
  startSpeechRecognition: () => void;
  stopSpeechRecognition: () => void;
  speakText: (text: string) => void;
  isSpeaking: boolean;

  // Global Quick Action sheet
  isQuickActionOpen: boolean;
  setQuickActionOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Theme & Onboarding state
  const [isOnboarded, setIsOnboarded] = useState<boolean>(() => {
    const saved = localStorage.getItem('hibuddy_onboarded');
    return saved ? JSON.parse(saved) : true; // Default to true for smooth exploration, can restart from settings
  });

  const [isMobileFrameView, setIsMobileFrameView] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.innerWidth < 768) {
      return false; // Native mobile view on real small screens
    }
    const saved = localStorage.getItem('hibuddy_frame_view');
    return saved ? JSON.parse(saved) : true; // On desktop, show realistic phone simulator frame by default
  });

  const [activeScreen, setActiveScreen] = useState<ScreenId>('home');
  const [isQuickActionOpen, setQuickActionOpen] = useState(false);

  // Profile
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('hibuddy_profile');
    return saved ? JSON.parse(saved) : initialProfile;
  });

  // Sync dark class on HTML
  useEffect(() => {
    const isDark =
      profile.theme === 'dark' ||
      (profile.theme === 'system' &&
        typeof window !== 'undefined' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    sound.enabled = profile.soundEnabled;
  }, [profile.theme, profile.soundEnabled]);

  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile((prev) => {
      const next = { ...prev, ...updates };
      localStorage.setItem('hibuddy_profile', JSON.stringify(next));
      return next;
    });
  };

  const completeOnboarding = (data?: Partial<UserProfile>) => {
    if (data) {
      updateProfile(data);
    }
    setIsOnboarded(true);
    localStorage.setItem('hibuddy_onboarded', 'true');
    setActiveScreen('home');
    sound.playHabitStreak();
  };

  // Tasks
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('hibuddy_tasks');
    return saved ? JSON.parse(saved) : initialTasks;
  });

  useEffect(() => {
    localStorage.setItem('hibuddy_tasks', JSON.stringify(tasks));
  }, [tasks]);

  const addTask = (taskData: Omit<Task, 'id'>) => {
    const newTask: Task = {
      ...taskData,
      id: 't-' + Date.now(),
    };
    setTasks((prev) => [newTask, ...prev]);
    sound.playClick();
  };

  const toggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const nextCompleted = !t.completed;
          if (nextCompleted) {
            sound.playTaskComplete();
          } else {
            sound.playClick();
          }
          return { ...t, completed: nextCompleted };
        }
        return t;
      })
    );
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    sound.playClick();
  };

  const aiAutoSchedule = () => {
    sound.playHabitStreak();
    // Intelligent reorganization of tasks based on energy windows
    setTasks((prev) => {
      const slots = ['09:00 AM', '11:00 AM', '02:00 PM', '04:00 PM', '06:00 PM'];
      return prev.map((t, idx) => ({
        ...t,
        time: slots[idx % slots.length],
        aiSuggested: true,
      }));
    });
  };

  // Reminders
  const [reminders, setReminders] = useState<Reminder[]>(() => {
    const saved = localStorage.getItem('hibuddy_reminders');
    return saved ? JSON.parse(saved) : initialReminders;
  });

  useEffect(() => {
    localStorage.setItem('hibuddy_reminders', JSON.stringify(reminders));
  }, [reminders]);

  const addReminder = (remData: Omit<Reminder, 'id' | 'completed'>) => {
    const newRem: Reminder = {
      ...remData,
      id: 'r-' + Date.now(),
      completed: false,
    };
    setReminders((prev) => [newRem, ...prev]);
    sound.playClick();
  };

  const toggleReminder = (id: string) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, completed: !r.completed } : r))
    );
    sound.playTaskComplete();
  };

  const deleteReminder = (id: string) => {
    setReminders((prev) => prev.filter((r) => r.id !== id));
    sound.playClick();
  };

  // Goals
  const [goals, setGoals] = useState<Goal[]>(() => {
    const saved = localStorage.getItem('hibuddy_goals');
    return saved ? JSON.parse(saved) : initialGoals;
  });

  useEffect(() => {
    localStorage.setItem('hibuddy_goals', JSON.stringify(goals));
  }, [goals]);

  const addGoal = (goalData: Omit<Goal, 'id'>) => {
    const newGoal: Goal = {
      ...goalData,
      id: 'g-' + Date.now(),
    };
    setGoals((prev) => [...prev, newGoal]);
    sound.playClick();
  };

  const updateGoalProgress = (id: string, delta: number) => {
    setGoals((prev) =>
      prev.map((g) => {
        if (g.id === id) {
          const next = Math.min(100, Math.max(0, g.progressPercentage + delta));
          if (next === 100 || (next > g.progressPercentage && next % 25 === 0)) {
            sound.playHabitStreak();
          } else {
            sound.playClick();
          }
          return { ...g, progressPercentage: next };
        }
        return g;
      })
    );
  };

  // Habits
  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem('hibuddy_habits');
    return saved ? JSON.parse(saved) : initialHabits;
  });

  useEffect(() => {
    localStorage.setItem('hibuddy_habits', JSON.stringify(habits));
  }, [habits]);

  const addHabit = (hData: Omit<Habit, 'id' | 'completedToday' | 'streakDays'>) => {
    const newHabit: Habit = {
      ...hData,
      id: 'h-' + Date.now(),
      completedToday: false,
      streakDays: 1,
    };
    setHabits((prev) => [...prev, newHabit]);
    sound.playClick();
  };

  const toggleHabit = (id: string) => {
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id === id) {
          const nextDone = !h.completedToday;
          const streak = nextDone ? h.streakDays + 1 : Math.max(0, h.streakDays - 1);
          if (nextDone) {
            sound.playHabitStreak();
          } else {
            sound.playClick();
          }
          return { ...h, completedToday: nextDone, streakDays: streak };
        }
        return h;
      })
    );
  };

  // Transactions & Budget
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('hibuddy_transactions');
    return saved ? JSON.parse(saved) : initialTransactions;
  });

  const [monthlyBudget, setMonthlyBudget] = useState<number>(3000);

  useEffect(() => {
    localStorage.setItem('hibuddy_transactions', JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (txData: Omit<Transaction, 'id'>) => {
    const newTx: Transaction = {
      ...txData,
      id: 'tx-' + Date.now(),
    };
    setTransactions((prev) => [newTx, ...prev]);
    sound.playClick();
  };

  const totalExpense = transactions
    .filter((t) => t.type === 'expense')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((acc, curr) => acc + curr.amount, 0);

  // Memories
  const [memories, setMemories] = useState<MemoryItem[]>(() => {
    const saved = localStorage.getItem('hibuddy_memories');
    return saved ? JSON.parse(saved) : initialMemories;
  });

  useEffect(() => {
    localStorage.setItem('hibuddy_memories', JSON.stringify(memories));
  }, [memories]);

  const addMemory = (memData: Omit<MemoryItem, 'id' | 'dateAdded'>) => {
    const newMem: MemoryItem = {
      ...memData,
      id: 'm-' + Date.now(),
      dateAdded: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
    };
    setMemories((prev) => [newMem, ...prev]);
    sound.playClick();
  };

  const deleteMemory = (id: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== id));
    sound.playClick();
  };

  const clearAllMemories = () => {
    setMemories([]);
    sound.playClick();
  };

  // Chat & AI Assistant
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('hibuddy_chat');
    return saved ? JSON.parse(saved) : initialChatMessages;
  });
  const [isBuddyThinking, setIsBuddyThinking] = useState(false);

  useEffect(() => {
    localStorage.setItem('hibuddy_chat', JSON.stringify(chatMessages));
  }, [chatMessages]);

  const clearChatHistory = () => {
    setChatMessages([
      {
        id: 'c-welcome',
        sender: 'buddy',
        text: `Hey ${profile.name}! I'm refreshed and ready to help. What's on your mind?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  // Speech Output
  const [isSpeaking, setIsSpeaking] = useState(false);
  const speakText = (text: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const cleanText = text.replace(/[*_#`]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } catch {
      setIsSpeaking(false);
    }
  };

  // Speech Recognition (Voice Input)
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const [recognitionInstance, setRecognitionInstance] = useState<any>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        setSpeechSupported(true);
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => setIsListening(true);
        recognition.onend = () => setIsListening(false);
        recognition.onerror = () => setIsListening(false);

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          if (transcript) {
            sendMessage(transcript, true);
          }
        };
        setRecognitionInstance(recognition);
      }
    }
  }, []);

  const startSpeechRecognition = () => {
    if (recognitionInstance) {
      try {
        sound.playClick();
        recognitionInstance.start();
      } catch (err) {
        console.warn('Speech recognition start error:', err);
      }
    }
  };

  const stopSpeechRecognition = () => {
    if (recognitionInstance) {
      try {
        recognitionInstance.stop();
      } catch (err) {
        console.warn('Speech recognition stop error:', err);
      }
    }
  };

  // Intelligent Contextual Assistant Response Generator
  const generateAssistantResponse = (userPrompt: string): { text: string; actions?: ChatAction[] } => {
    const lower = userPrompt.toLowerCase();
    const actions: ChatAction[] = [];

    // 1. Task Scheduling detection
    if (lower.includes('task') || lower.includes('schedule') || lower.includes('meeting') || lower.includes('call') || lower.includes('workout') || lower.includes('study')) {
      const cleanTitle = userPrompt
        .replace(/^(add|create|schedule|set up|please add|remind me to schedule)\s+(a|an)?\s*(task|meeting)?\s*:?/i, '')
        .trim();
      const detectedTitle = cleanTitle.length > 3 ? cleanTitle : 'Strategy Sync & Priority Review';
      
      actions.push({
        id: 'act-' + Date.now(),
        label: `Add to Planner: "${detectedTitle.slice(0, 32)}"`,
        actionType: 'create_task',
        payload: {
          title: detectedTitle,
          category: lower.includes('workout') ? 'health' : lower.includes('study') ? 'learning' : 'work',
          priority: lower.includes('urgent') || lower.includes('high') ? 'high' : 'medium',
          time: '02:30 PM',
          durationMinutes: 45,
          completed: false,
          date: new Date().toISOString().split('T')[0],
        },
      });

      return {
        text: `Got it! I can schedule "${detectedTitle}" into your afternoon focus block. Tap the action below to instantly confirm it in your Smart Planner:`,
        actions,
      };
    }

    // 2. Expense / Money Tracking detection
    if (lower.includes('spent') || lower.includes('bought') || lower.includes('paid') || lower.includes('dollar') || lower.includes('$') || lower.includes('cost') || lower.includes('expense')) {
      const numMatch = userPrompt.match(/\$?(\d+(\.\d{1,2})?)/);
      const amount = numMatch ? parseFloat(numMatch[1]) : 24.5;
      
      let cat: any = 'Food & Dining';
      if (lower.includes('uber') || lower.includes('gas') || lower.includes('flight') || lower.includes('train') || lower.includes('bus')) cat = 'Transport';
      if (lower.includes('rent') || lower.includes('home') || lower.includes('clean')) cat = 'Housing';
      if (lower.includes('gym') || lower.includes('doctor') || lower.includes('medicine')) cat = 'Wellness';
      if (lower.includes('amazon') || lower.includes('clothes') || lower.includes('shoes')) cat = 'Shopping';

      actions.push({
        id: 'act-' + Date.now(),
        label: `Log $${amount.toFixed(2)} under ${cat}`,
        actionType: 'log_expense',
        payload: {
          title: userPrompt.slice(0, 35),
          amount,
          type: 'expense',
          category: cat,
          date: 'Just now',
          iconName: 'Receipt',
        },
      });

      return {
        text: `I've prepared an expense entry for $${amount.toFixed(2)} under ${cat}. Tap to add it to your Money Manager:`,
        actions,
      };
    }

    // 3. Reminder detection
    if (lower.includes('remind') || lower.includes('remember to') || lower.includes("don't forget")) {
      const cleanTitle = userPrompt.replace(/^(remind me to|remember to|don't forget to|set reminder for)\s*/i, '').trim();
      actions.push({
        id: 'act-' + Date.now(),
        label: `Set Reminder: "${cleanTitle.slice(0, 30)}"`,
        actionType: 'create_reminder',
        payload: {
          title: cleanTitle || 'Important check-in',
          timeStr: 'In 2 hours',
          category: 'Personal',
        },
      });

      return {
        text: `I can set a reminder for "${cleanTitle}". Tap to confirm:`,
        actions,
      };
    }

    // 4. Memory / Note detection
    if (lower.includes('remember that') || lower.includes('i prefer') || lower.includes('i love') || lower.includes('i dislike') || lower.includes('note that') || lower.includes('allergic to')) {
      actions.push({
        id: 'act-' + Date.now(),
        label: `Save to Personal Memory`,
        actionType: 'save_memory',
        payload: {
          title: 'Personal Note',
          content: userPrompt,
          category: 'Preferences',
          userApproved: true,
          tags: ['personal', 'ai-memory'],
        },
      });

      return {
        text: `Noted! I can save this insight into your Personal Memory bank so I can adapt future recommendations to your style.`,
        actions,
      };
    }

    // 5. Daily Briefing / Summary request
    if (lower.includes('day') || lower.includes('briefing') || lower.includes('summary') || lower.includes('morning') || lower.includes('schedule') || lower.includes('how am i doing')) {
      const completedCount = tasks.filter((t) => t.completed).length;
      const totalCount = tasks.length;
      return {
        text: `Here's your current overview: You've completed ${completedCount} of ${totalCount} planned tasks today. Your top priority right now is "${tasks.find((t) => !t.completed)?.title || 'Well done! All caught up'}". Habit streak for hydration is strong, and you have $${(monthlyBudget - totalExpense).toFixed(0)} remaining in your monthly budget. Would you like me to auto-balance your afternoon?`,
        actions: [
          {
            id: 'act-auto',
            label: 'Auto-Schedule My Day',
            actionType: 'create_task',
            payload: { autoSchedule: true },
          },
          {
            id: 'act-nav-plan',
            label: 'Open Smart Planner',
            actionType: 'navigate',
            payload: 'planner',
          },
        ],
      };
    }

    // 6. Habit & Motivation
    if (lower.includes('habit') || lower.includes('streak') || lower.includes('motivat') || lower.includes('tired') || lower.includes('focus')) {
      return {
        text: `Take a deep breath. Focus is a rhythm, not a marathon. Even 15 minutes of uninterrupted presence creates immense momentum. Your 19-day streak proves your consistency! Ready for your next micro-win?`,
        actions: [
          {
            id: 'act-nav-habits',
            label: 'View Habits & Goals',
            actionType: 'navigate',
            payload: 'goals',
          },
        ],
      };
    }

    // 7. General friendly companion reply
    const friendlyGreetings = [
      `I'm right here with you! Whether you want to plan your day, log an expense, or clear mental clutter, let's do it together. What's our next step?`,
      `Always here to help you live intentionally! I'm tracking your schedule, budget, and habits. How can I lighten your load right now?`,
      `You got it! I'm keeping everything synchronized so you don't have to hold it all in your head.`,
    ];
    return {
      text: friendlyGreetings[Math.floor(Math.random() * friendlyGreetings.length)],
      actions: [
        {
          id: 'act-add-task',
          label: 'Plan a New Task',
          actionType: 'navigate',
          payload: 'planner',
        },
        {
          id: 'act-log-exp',
          label: 'Log Quick Expense',
          actionType: 'navigate',
          payload: 'money',
        },
      ],
    };
  };

  const sendMessage = (text: string, isVoice: boolean = false) => {
    if (!text.trim()) return;

    sound.playClick();
    const userMsg: ChatMessage = {
      id: 'usr-' + Date.now(),
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isVoice,
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setIsBuddyThinking(true);

    setTimeout(() => {
      const response = generateAssistantResponse(text);
      const buddyMsg: ChatMessage = {
        id: 'bud-' + Date.now(),
        sender: 'buddy',
        text: response.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        actions: response.actions,
      };

      setChatMessages((prev) => [...prev, buddyMsg]);
      setIsBuddyThinking(false);
      sound.playMessage();

      if (profile.voiceOutputEnabled) {
        speakText(response.text);
      }
    }, 600);
  };

  const executeChatAction = (action: ChatAction, messageId: string) => {
    sound.playClick();
    if (action.actionType === 'create_task') {
      if (action.payload?.autoSchedule) {
        aiAutoSchedule();
      } else {
        addTask(action.payload);
      }
    } else if (action.actionType === 'create_reminder') {
      addReminder(action.payload);
    } else if (action.actionType === 'log_expense') {
      addTransaction(action.payload);
    } else if (action.actionType === 'save_memory') {
      addMemory(action.payload);
    } else if (action.actionType === 'navigate') {
      setActiveScreen(action.payload as ScreenId);
    }

    // Mark as executed in message
    setChatMessages((prev) =>
      prev.map((msg) => {
        if (msg.id === messageId && msg.actions) {
          return {
            ...msg,
            actions: msg.actions.map((act) =>
              act.id === action.id ? { ...act, executed: true } : act
            ),
          };
        }
        return msg;
      })
    );
  };

  return (
    <AppContext.Provider
      value={{
        profile,
        updateProfile,
        activeScreen,
        setActiveScreen,
        isMobileFrameView,
        setIsMobileFrameView,
        isOnboarded,
        completeOnboarding,

        tasks,
        addTask,
        toggleTask,
        deleteTask,
        aiAutoSchedule,

        reminders,
        addReminder,
        toggleReminder,
        deleteReminder,

        goals,
        addGoal,
        updateGoalProgress,

        habits,
        addHabit,
        toggleHabit,

        transactions,
        monthlyBudget,
        setMonthlyBudget,
        totalIncome,
        totalExpense,
        addTransaction,

        memories,
        addMemory,
        deleteMemory,
        clearAllMemories,

        chatMessages,
        sendMessage,
        executeChatAction,
        clearChatHistory,
        isBuddyThinking,

        isListening,
        speechSupported,
        startSpeechRecognition,
        stopSpeechRecognition,
        speakText,
        isSpeaking,

        isQuickActionOpen,
        setQuickActionOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
