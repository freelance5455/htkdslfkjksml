import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  ActiveCall,
  ChatChannel,
  ChatMessage,
  ChatAttachment,
  Product,
  CartItem,
  Order,
  OrderStatus,
  StudentAttendance,
  AttendanceStatus,
  Assignment,
  StudentReportCard,
  TimetableSlot,
  TaskItem,
  TaskStatus,
  PunchLogEntry,
  LeaveRequest,
  PaidGig,
  WalletTransaction,
} from '../types';
import {
  INITIAL_USER,
  AVAILABLE_USERS,
  INITIAL_CALLS,
  INITIAL_CHANNELS,
  INITIAL_MESSAGES,
  INITIAL_PRODUCTS,
  INITIAL_ORDERS,
  INITIAL_STUDENTS_ATTENDANCE,
  INITIAL_ASSIGNMENTS,
  INITIAL_REPORT_CARDS,
  INITIAL_TIMETABLE,
  INITIAL_TASKS,
  INITIAL_PUNCH_LOGS,
  INITIAL_LEAVE_REQUESTS,
  INITIAL_WALLET_BALANCE,
  INITIAL_PAID_GIGS,
  INITIAL_WALLET_TRANSACTIONS,
} from '../data/initialData';

export type MainPillar = 'communication' | 'ecommerce' | 'education' | 'office' | 'wallet';

interface AppContextType {
  // Navigation & User
  currentPillar: MainPillar;
  setCurrentPillar: (pillar: MainPillar) => void;
  activeSubView: string;
  setActiveSubView: (view: string) => void;
  currentUser: UserProfile;
  switchUser: (userId: string) => void;
  availableUsers: UserProfile[];

  // 1. Communication & Calling
  calls: ActiveCall[];
  currentCallId: string | null;
  joinCall: (callId: string) => void;
  leaveCall: () => void;
  channels: ChatChannel[];
  activeChannelId: string;
  setActiveChannelId: (id: string) => void;
  messages: ChatMessage[];
  sendMessage: (text: string, attachments?: ChatAttachment[]) => void;
  addReaction: (messageId: string, emoji: string) => void;

  // 2. E-Commerce & Ordering
  products: Product[];
  addProduct: (product: Omit<Product, 'id' | 'rating' | 'reviewsCount'>) => void;
  updateStock: (productId: string, stock: number) => void;
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  orders: Order[];
  createOrder: (orderData: {
    customerName: string;
    customerEmail: string;
    customerDepartment: string;
    shippingAddress: string;
    paymentMethod: 'Credit Card' | 'Department Invoice' | 'Campus Purchase Order' | 'Cash on Delivery';
  }) => Order;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  selectedReceiptOrder: Order | null;
  setSelectedReceiptOrder: (order: Order | null) => void;

  // 3. School & Education Hub
  attendance: StudentAttendance[];
  updateAttendance: (studentId: string, status: AttendanceStatus, notes?: string) => void;
  markAllAttendance: (status: AttendanceStatus) => void;
  assignments: Assignment[];
  createAssignment: (data: {
    title: string;
    subject: string;
    classGroup: string;
    dueDate: string;
    totalMarks: number;
    instructions: string;
    attachmentName?: string;
  }) => void;
  gradeSubmission: (assignmentId: string, submissionId: string, score: number, feedback: string) => void;
  reportCards: StudentReportCard[];
  selectedReportCard: StudentReportCard | null;
  setSelectedReportCard: (card: StudentReportCard | null) => void;
  timetable: TimetableSlot[];
  addTimetableSlot: (slot: Omit<TimetableSlot, 'id'>) => void;

  // 4. Office & Professional Tools
  tasks: TaskItem[];
  createTask: (task: {
    title: string;
    project: string;
    assigneeName: string;
    priority: 'high' | 'medium' | 'low';
    dueDate: string;
    description: string;
    tags: string[];
  }) => void;
  updateTaskStatus: (taskId: string, status: TaskStatus) => void;
  toggleSubtask: (taskId: string, subtaskId: string) => void;
  punchLogs: PunchLogEntry[];
  isOnDuty: boolean;
  clockInTime: string | null;
  punchIn: () => void;
  punchOut: () => void;
  leaveRequests: LeaveRequest[];
  createLeaveRequest: (req: {
    leaveType: LeaveRequest['leaveType'];
    startDate: string;
    endDate: string;
    daysCount: number;
    reason: string;
    handoverTo: string;
  }) => void;
  reviewLeaveRequest: (id: string, status: 'approved' | 'rejected', comment?: string) => void;

  // 5. Money, Earnings & Wallet Hub
  walletBalance: number;
  gigs: PaidGig[];
  walletTransactions: WalletTransaction[];
  claimGig: (gigId: string) => void;
  completeGig: (gigId: string, submissionNotes: string) => void;
  postGig: (gig: {
    title: string;
    category: PaidGig['category'];
    reward: number;
    description: string;
    estimatedHours: string;
    deadline: string;
  }) => void;
  sendTransfer: (recipient: string, amount: number, note: string) => boolean;
  withdrawFunds: (amount: number, destination: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation & User
  const [currentPillar, setCurrentPillar] = useState<MainPillar>('communication');
  const [activeSubView, setActiveSubView] = useState<string>('calls');
  const [currentUser, setCurrentUser] = useState<UserProfile>(INITIAL_USER);

  // Sync subview when pillar switches
  useEffect(() => {
    if (currentPillar === 'communication' && activeSubView !== 'calls' && activeSubView !== 'messaging') {
      setActiveSubView('calls');
    } else if (currentPillar === 'ecommerce' && activeSubView !== 'marketplace' && activeSubView !== 'orders') {
      setActiveSubView('marketplace');
    } else if (
      currentPillar === 'education' &&
      !['attendance', 'homework', 'gradebook', 'timetable'].includes(activeSubView)
    ) {
      setActiveSubView('attendance');
    } else if (
      currentPillar === 'office' &&
      !['tasks', 'staff_attendance', 'leave_management'].includes(activeSubView)
    ) {
      setActiveSubView('tasks');
    } else if (
      currentPillar === 'wallet' &&
      !['gigs', 'wallet'].includes(activeSubView)
    ) {
      setActiveSubView('gigs');
    }
  }, [currentPillar]);

  const switchUser = (userId: string) => {
    const found = AVAILABLE_USERS.find((u) => u.id === userId);
    if (found) setCurrentUser(found);
  };

  // 1. Communication & Calling
  const [calls] = useState<ActiveCall[]>(INITIAL_CALLS);
  const [currentCallId, setCurrentCallId] = useState<string | null>(null);
  const [channels] = useState<ChatChannel[]>(INITIAL_CHANNELS);
  const [activeChannelId, setActiveChannelId] = useState<string>('ch_general');
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('synapse_messages');
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });

  useEffect(() => {
    localStorage.setItem('synapse_messages', JSON.stringify(messages));
  }, [messages]);

  const joinCall = (callId: string) => {
    setCurrentCallId(callId);
  };

  const leaveCall = () => {
    setCurrentCallId(null);
  };

  const sendMessage = (text: string, attachments?: ChatAttachment[]) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      channelId: activeChannelId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.title,
      senderAvatar: currentUser.avatar,
      text,
      timestamp: timeStr,
      attachments,
    };
    setMessages((prev) => [...prev, newMsg]);
  };

  const addReaction = (messageId: string, emoji: string) => {
    setMessages((prev) =>
      prev.map((msg) => {
        if (msg.id !== messageId) return msg;
        const currentReactions = msg.reactions || {};
        const existingUsers = currentReactions[emoji] || [];
        const hasReacted = existingUsers.includes(currentUser.name);
        const updatedUsers = hasReacted
          ? existingUsers.filter((u) => u !== currentUser.name)
          : [...existingUsers, currentUser.name];

        const updatedReactions = { ...currentReactions };
        if (updatedUsers.length > 0) {
          updatedReactions[emoji] = updatedUsers;
        } else {
          delete updatedReactions[emoji];
        }
        return { ...msg, reactions: updatedReactions };
      })
    );
  };

  // 2. E-Commerce & Ordering
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('synapse_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  useEffect(() => {
    localStorage.setItem('synapse_products', JSON.stringify(products));
  }, [products]);

  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('synapse_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });
  const [selectedReceiptOrder, setSelectedReceiptOrder] = useState<Order | null>(null);

  useEffect(() => {
    localStorage.setItem('synapse_orders', JSON.stringify(orders));
  }, [orders]);

  const addProduct = (prodData: Omit<Product, 'id' | 'rating' | 'reviewsCount'>) => {
    const newProd: Product = {
      ...prodData,
      id: `prod_${Date.now()}`,
      rating: 5.0,
      reviewsCount: 1,
    };
    setProducts((prev) => [newProd, ...prev]);
  };

  const updateStock = (productId: string, stock: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stock: Math.max(0, stock), inStock: stock > 0 } : p))
    );
  };

  const addToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const idx = prev.findIndex((item) => item.product.id === product.id);
      if (idx > -1) {
        const next = [...prev];
        next[idx] = { ...next[idx], quantity: next[idx].quantity + quantity };
        return next;
      }
      return [...prev, { product, quantity }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => setCart([]);

  const createOrder = (orderData: {
    customerName: string;
    customerEmail: string;
    customerDepartment: string;
    shippingAddress: string;
    paymentMethod: 'Credit Card' | 'Department Invoice' | 'Campus Purchase Order' | 'Cash on Delivery';
  }) => {
    const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
    const tax = +(subtotal * 0.08).toFixed(2);
    const shippingFee = subtotal > 100 ? 0 : 15;
    const total = +(subtotal + tax + shippingFee).toFixed(2);

    const date = new Date();
    const orderDateStr = `${date.toISOString().split('T')[0]} ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    const estDelivery = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const newOrder: Order = {
      id: `ORD-${Math.floor(10000 + Math.random() * 90000)}`,
      customerName: orderData.customerName,
      customerEmail: orderData.customerEmail,
      customerDepartment: orderData.customerDepartment,
      shippingAddress: orderData.shippingAddress,
      items: [...cart],
      subtotal,
      tax,
      shippingFee,
      total,
      status: 'pending',
      paymentMethod: orderData.paymentMethod,
      paymentStatus: 'Authorized',
      orderDate: orderDateStr,
      estimatedDelivery: estDelivery,
      timeline: [
        {
          status: 'pending',
          date: orderDateStr,
          description: 'Order placed and logged in procurement system.',
        },
      ],
    };

    // Deduct stock
    setProducts((prev) =>
      prev.map((p) => {
        const cartItem = cart.find((ci) => ci.product.id === p.id);
        if (cartItem) {
          const newStock = Math.max(0, p.stock - cartItem.quantity);
          return { ...p, stock: newStock, inStock: newStock > 0 };
        }
        return p;
      })
    );

    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    setSelectedReceiptOrder(newOrder);
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== orderId) return o;
        const now = new Date();
        const timeStr = `${now.toISOString().split('T')[0]} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
        const descriptions: Record<OrderStatus, string> = {
          pending: 'Order pending review.',
          processing: 'Items picked and packaged for internal courier routing.',
          shipped: 'Dispatched to target campus building / office station.',
          delivered: 'Package received and delivery signed.',
          cancelled: 'Order marked cancelled by administration.',
        };
        return {
          ...o,
          status,
          timeline: [...o.timeline, { status, date: timeStr, description: descriptions[status] }],
        };
      })
    );
  };

  // 3. School & Education Hub
  const [attendance, setAttendance] = useState<StudentAttendance[]>(() => {
    const saved = localStorage.getItem('synapse_attendance');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS_ATTENDANCE;
  });

  useEffect(() => {
    localStorage.setItem('synapse_attendance', JSON.stringify(attendance));
  }, [attendance]);

  const updateAttendance = (studentId: string, status: AttendanceStatus, notes?: string) => {
    setAttendance((prev) =>
      prev.map((s) => (s.studentId === studentId ? { ...s, status, notes: notes !== undefined ? notes : s.notes } : s))
    );
  };

  const markAllAttendance = (status: AttendanceStatus) => {
    setAttendance((prev) => prev.map((s) => ({ ...s, status })));
  };

  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    const saved = localStorage.getItem('synapse_assignments');
    return saved ? JSON.parse(saved) : INITIAL_ASSIGNMENTS;
  });

  useEffect(() => {
    localStorage.setItem('synapse_assignments', JSON.stringify(assignments));
  }, [assignments]);

  const createAssignment = (data: {
    title: string;
    subject: string;
    classGroup: string;
    dueDate: string;
    totalMarks: number;
    instructions: string;
    attachmentName?: string;
  }) => {
    const newAsg: Assignment = {
      id: `asg_${Date.now()}`,
      title: data.title,
      subject: data.subject,
      classGroup: data.classGroup,
      teacherName: currentUser.name,
      dueDate: data.dueDate,
      totalMarks: data.totalMarks,
      instructions: data.instructions,
      attachmentName: data.attachmentName,
      submissions: [],
    };
    setAssignments((prev) => [newAsg, ...prev]);
  };

  const gradeSubmission = (assignmentId: string, submissionId: string, score: number, feedback: string) => {
    setAssignments((prev) =>
      prev.map((asg) => {
        if (asg.id !== assignmentId) return asg;
        return {
          ...asg,
          submissions: asg.submissions.map((sub) => {
            if (sub.id !== submissionId) return sub;
            return {
              ...sub,
              score,
              feedback,
              status: 'graded',
            };
          }),
        };
      })
    );
  };

  const [reportCards] = useState<StudentReportCard[]>(INITIAL_REPORT_CARDS);
  const [selectedReportCard, setSelectedReportCard] = useState<StudentReportCard | null>(null);

  const [timetable, setTimetable] = useState<TimetableSlot[]>(() => {
    const saved = localStorage.getItem('synapse_timetable');
    return saved ? JSON.parse(saved) : INITIAL_TIMETABLE;
  });

  const addTimetableSlot = (slot: Omit<TimetableSlot, 'id'>) => {
    const newSlot: TimetableSlot = {
      ...slot,
      id: `tt_${Date.now()}`,
    };
    setTimetable((prev) => [...prev, newSlot]);
  };

  // 4. Office & Professional Tools
  const [tasks, setTasks] = useState<TaskItem[]>(() => {
    const saved = localStorage.getItem('synapse_tasks');
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  });

  useEffect(() => {
    localStorage.setItem('synapse_tasks', JSON.stringify(tasks));
  }, [tasks]);

  const createTask = (taskData: {
    title: string;
    project: string;
    assigneeName: string;
    priority: 'high' | 'medium' | 'low';
    dueDate: string;
    description: string;
    tags: string[];
  }) => {
    const assignedUser = AVAILABLE_USERS.find((u) => u.name === taskData.assigneeName) || {
      name: taskData.assigneeName,
      title: 'Staff Specialist',
      role: 'employee' as const,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=256',
    };

    const newTask: TaskItem = {
      id: `tsk_${Date.now()}`,
      title: taskData.title,
      project: taskData.project,
      assignee: {
        name: assignedUser.name,
        role: assignedUser.title || 'Staff Member',
        avatar: assignedUser.avatar,
      },
      priority: taskData.priority,
      status: 'todo',
      dueDate: taskData.dueDate,
      description: taskData.description,
      tags: taskData.tags,
      subtasks: [
        { id: `st_${Date.now()}_1`, title: 'Initial task kickoff & requirements sync', completed: false },
        { id: `st_${Date.now()}_2`, title: 'Implementation & deliverable preparation', completed: false },
      ],
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  const updateTaskStatus = (taskId: string, status: TaskStatus) => {
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, status } : t)));
  };

  const toggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        const updatedSubtasks = t.subtasks.map((st) =>
          st.id === subtaskId ? { ...st, completed: !st.completed } : st
        );
        const allCompleted = updatedSubtasks.length > 0 && updatedSubtasks.every((st) => st.completed);
        return {
          ...t,
          subtasks: updatedSubtasks,
          status: allCompleted ? 'done' : t.status,
        };
      })
    );
  };

  // Staff Attendance & Punch Logs
  const [punchLogs, setPunchLogs] = useState<PunchLogEntry[]>(() => {
    const saved = localStorage.getItem('synapse_punch_logs');
    return saved ? JSON.parse(saved) : INITIAL_PUNCH_LOGS;
  });
  const [isOnDuty, setIsOnDuty] = useState(true);
  const [clockInTime, setClockInTime] = useState<string | null>('07:55 AM');

  useEffect(() => {
    localStorage.setItem('synapse_punch_logs', JSON.stringify(punchLogs));
  }, [punchLogs]);

  const punchIn = () => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const dateStr = now.toISOString().split('T')[0];

    const newLog: PunchLogEntry = {
      id: `pnch_${Date.now()}`,
      employeeId: currentUser.id,
      employeeName: currentUser.name,
      department: currentUser.department,
      date: dateStr,
      clockIn: timeStr,
      status: 'on_duty',
      ipAddress: '10.0.8.44 (Direct Gateway)',
    };
    setPunchLogs((prev) => [newLog, ...prev]);
    setIsOnDuty(true);
    setClockInTime(timeStr);
  };

  const punchOut = () => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setPunchLogs((prev) =>
      prev.map((log) => {
        if (log.employeeName === currentUser.name && log.status === 'on_duty' && !log.clockOut) {
          return {
            ...log,
            clockOut: timeStr,
            totalHours: 8.5,
            status: 'completed',
          };
        }
        return log;
      })
    );
    setIsOnDuty(false);
    setClockInTime(null);
  };

  // Leave Management
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>(() => {
    const saved = localStorage.getItem('synapse_leave');
    return saved ? JSON.parse(saved) : INITIAL_LEAVE_REQUESTS;
  });

  useEffect(() => {
    localStorage.setItem('synapse_leave', JSON.stringify(leaveRequests));
  }, [leaveRequests]);

  const createLeaveRequest = (req: {
    leaveType: LeaveRequest['leaveType'];
    startDate: string;
    endDate: string;
    daysCount: number;
    reason: string;
    handoverTo: string;
  }) => {
    const today = new Date().toISOString().split('T')[0];
    const newReq: LeaveRequest = {
      id: `lv_${Date.now()}`,
      employeeName: currentUser.name,
      department: currentUser.department,
      leaveType: req.leaveType,
      startDate: req.startDate,
      endDate: req.endDate,
      daysCount: req.daysCount,
      reason: req.reason,
      handoverTo: req.handoverTo,
      status: 'pending',
      appliedDate: today,
    };
    setLeaveRequests((prev) => [newReq, ...prev]);
  };

  const reviewLeaveRequest = (id: string, status: 'approved' | 'rejected', comment?: string) => {
    const today = new Date().toISOString().split('T')[0];
    setLeaveRequests((prev) =>
      prev.map((lr) => {
        if (lr.id !== id) return lr;
        return {
          ...lr,
          status,
          reviewedBy: currentUser.name,
          reviewDate: today,
          reviewComment: comment || (status === 'approved' ? 'Request approved.' : 'Request declined due to coverage requirements.'),
        };
      })
    );
  };

  // 5. Money, Earnings & Wallet Hub
  const [walletBalance, setWalletBalance] = useState<number>(() => {
    const saved = localStorage.getItem('makefriend_wallet_balance');
    return saved ? parseFloat(saved) : INITIAL_WALLET_BALANCE;
  });

  const [gigs, setGigs] = useState<PaidGig[]>(() => {
    const saved = localStorage.getItem('makefriend_gigs');
    return saved ? JSON.parse(saved) : INITIAL_PAID_GIGS;
  });

  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(() => {
    const saved = localStorage.getItem('makefriend_wallet_txns');
    return saved ? JSON.parse(saved) : INITIAL_WALLET_TRANSACTIONS;
  });

  useEffect(() => {
    localStorage.setItem('makefriend_wallet_balance', walletBalance.toString());
  }, [walletBalance]);

  useEffect(() => {
    localStorage.setItem('makefriend_gigs', JSON.stringify(gigs));
  }, [gigs]);

  useEffect(() => {
    localStorage.setItem('makefriend_wallet_txns', JSON.stringify(walletTransactions));
  }, [walletTransactions]);

  const claimGig = (gigId: string) => {
    setGigs((prev) =>
      prev.map((g) => (g.id === gigId ? { ...g, status: 'claimed', claimedBy: currentUser.name } : g))
    );
  };

  const completeGig = (gigId: string, submissionNotes: string) => {
    const targetGig = gigs.find((g) => g.id === gigId);
    if (!targetGig) return;

    const today = new Date().toISOString().split('T')[0];
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setGigs((prev) =>
      prev.map((g) =>
        g.id === gigId
          ? {
              ...g,
              status: 'completed',
              completedAt: today,
              submissionNotes,
              claimedBy: g.claimedBy || currentUser.name,
            }
          : g
      )
    );

    // Credit user's wallet
    setWalletBalance((prev) => +(prev + targetGig.reward).toFixed(2));

    // Record wallet transaction
    const newTxn: WalletTransaction = {
      id: `txn_${Date.now()}`,
      type: 'gig_payout',
      title: `${targetGig.title} (Bounty Payout)`,
      amount: targetGig.reward,
      timestamp: `${today} ${nowTime}`,
      status: 'completed',
      destinationOrSource: targetGig.posterDepartment,
      referenceId: targetGig.id.toUpperCase(),
    };
    setWalletTransactions((prev) => [newTxn, ...prev]);
  };

  const postGig = (gigData: {
    title: string;
    category: PaidGig['category'];
    reward: number;
    description: string;
    estimatedHours: string;
    deadline: string;
  }) => {
    const newGig: PaidGig = {
      id: `gig_${Date.now()}`,
      title: gigData.title,
      category: gigData.category,
      reward: gigData.reward,
      posterName: currentUser.name,
      posterRole: currentUser.title,
      posterAvatar: currentUser.avatar,
      posterDepartment: currentUser.department,
      description: gigData.description,
      estimatedHours: gigData.estimatedHours,
      deadline: gigData.deadline,
      status: 'available',
    };
    setGigs((prev) => [newGig, ...prev]);
  };

  const sendTransfer = (recipient: string, amount: number, note: string): boolean => {
    if (amount <= 0 || amount > walletBalance) return false;

    const today = new Date().toISOString().split('T')[0];
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setWalletBalance((prev) => +(prev - amount).toFixed(2));

    const newTxn: WalletTransaction = {
      id: `txn_${Date.now()}`,
      type: 'peer_transfer',
      title: `Transfer to ${recipient} (${note || 'Peer Payment'})`,
      amount: -amount,
      timestamp: `${today} ${nowTime}`,
      status: 'completed',
      destinationOrSource: recipient,
      referenceId: `TRF-${Math.floor(1000 + Math.random() * 9000)}`,
    };

    setWalletTransactions((prev) => [newTxn, ...prev]);
    return true;
  };

  const withdrawFunds = (amount: number, destination: string): boolean => {
    if (amount <= 0 || amount > walletBalance) return false;

    const today = new Date().toISOString().split('T')[0];
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setWalletBalance((prev) => +(prev - amount).toFixed(2));

    const newTxn: WalletTransaction = {
      id: `txn_${Date.now()}`,
      type: 'cash_withdrawal',
      title: `Cashout to ${destination}`,
      amount: -amount,
      timestamp: `${today} ${nowTime}`,
      status: 'completed',
      destinationOrSource: destination,
      referenceId: `WD-${Math.floor(10000 + Math.random() * 90000)}`,
    };

    setWalletTransactions((prev) => [newTxn, ...prev]);
    return true;
  };

  return (
    <AppContext.Provider
      value={{
        currentPillar,
        setCurrentPillar,
        activeSubView,
        setActiveSubView,
        currentUser,
        switchUser,
        availableUsers: AVAILABLE_USERS,
        calls,
        currentCallId,
        joinCall,
        leaveCall,
        channels,
        activeChannelId,
        setActiveChannelId,
        messages,
        sendMessage,
        addReaction,
        products,
        addProduct,
        updateStock,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        orders,
        createOrder,
        updateOrderStatus,
        selectedReceiptOrder,
        setSelectedReceiptOrder,
        attendance,
        updateAttendance,
        markAllAttendance,
        assignments,
        createAssignment,
        gradeSubmission,
        reportCards,
        selectedReportCard,
        setSelectedReportCard,
        timetable,
        addTimetableSlot,
        tasks,
        createTask,
        updateTaskStatus,
        toggleSubtask,
        punchLogs,
        isOnDuty,
        clockInTime,
        punchIn,
        punchOut,
        leaveRequests,
        createLeaveRequest,
        reviewLeaveRequest,
        walletBalance,
        gigs,
        walletTransactions,
        claimGig,
        completeGig,
        postGig,
        sendTransfer,
        withdrawFunds,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
