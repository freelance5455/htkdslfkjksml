import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Language, 
  ServiceType, 
  RequestStatus, 
  PatientRequest, 
  MedicalCenter, 
  Doctor, 
  RehabCenter, 
  HealingDestination, 
  TranslatorEscort, 
  DemoInvoice 
} from '../types';
import { 
  INITIAL_REQUESTS, 
  MEDICAL_CENTERS, 
  DOCTORS, 
  REHAB_CENTERS, 
  HEALING_DESTINATIONS, 
  TRANSLATORS, 
  DEMO_INVOICES 
} from '../data/initialData';

export type ViewType = 
  | 'welcome'
  | 'home' 
  | 'medical' 
  | 'rehab' 
  | 'tourism' 
  | 'reception' 
  | 'tracking' 
  | 'international' 
  | 'request-form' 
  | 'admin'
  | 'about';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  
  // Data State
  requests: PatientRequest[];
  medicalCenters: MedicalCenter[];
  doctors: Doctor[];
  rehabCenters: RehabCenter[];
  healingDestinations: HealingDestination[];
  translators: TranslatorEscort[];
  invoices: DemoInvoice[];
  
  // Active workflow
  selectedServiceForForm: ServiceType | null;
  setSelectedServiceForForm: (service: ServiceType | null) => void;
  openRequestModalForService: (service: ServiceType) => void;
  
  // Tracking
  trackingCode: string;
  setTrackingCode: (code: string) => void;
  currentTrackedRequest: PatientRequest | null;
  lookupTracking: (code: string) => boolean;

  // Actions
  addNewRequest: (data: {
    patientName: string;
    country: string;
    phone: string;
    email: string;
    preferredLanguage: string;
    serviceType: ServiceType;
    specialtyOrNeed: string;
    description: string;
    preferredContact: 'whatsapp' | 'phone' | 'email';
    agreedToPrivacy: boolean;
  }) => string;
  updateRequestStatus: (id: string, status: RequestStatus, note?: string) => void;
  resetDemoData: () => void;

  // Admin Auth
  isAdminLoggedIn: boolean;
  setIsAdminLoggedIn: (val: boolean) => void;
  demoAdminLogin: () => void;
  demoAdminLogout: () => void;

  // Toasts / Notifications
  toastMessage: string | null;
  showToast: (msg: string) => void;
  clearToast: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY = 'al_mowasat_demo_requests_v1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('ar');
  const [currentView, setCurrentView] = useState<ViewType>('welcome');
  const [selectedServiceForForm, setSelectedServiceForForm] = useState<ServiceType | null>(null);
  const [trackingCode, setTrackingCode] = useState<string>('ALM-REQ-7924');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Initialize requests from localStorage or fallback to initial
  const [requests, setRequests] = useState<PatientRequest[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_REQUESTS;
  });

  const [medicalCenters] = useState<MedicalCenter[]>(MEDICAL_CENTERS);
  const [doctors] = useState<Doctor[]>(DOCTORS);
  const [rehabCenters] = useState<RehabCenter[]>(REHAB_CENTERS);
  const [healingDestinations] = useState<HealingDestination[]>(HEALING_DESTINATIONS);
  const [translators] = useState<TranslatorEscort[]>(TRANSLATORS);
  const [invoices] = useState<DemoInvoice[]>(DEMO_INVOICES);

  // Persist requests
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(requests));
    } catch {
      // ignore
    }
  }, [requests]);

  // Update HTML document dir and lang when language changes
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const toggleLanguage = () => {
    setLanguageState(prev => (prev === 'ar' ? 'en' : 'ar'));
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => (prev === msg ? null : prev));
    }, 4000);
  };

  const clearToast = () => setToastMessage(null);

  const openRequestModalForService = (service: ServiceType) => {
    setSelectedServiceForForm(service);
    setCurrentView('request-form');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const addNewRequest = (data: {
    patientName: string;
    country: string;
    phone: string;
    email: string;
    preferredLanguage: string;
    serviceType: ServiceType;
    specialtyOrNeed: string;
    description: string;
    preferredContact: 'whatsapp' | 'phone' | 'email';
    agreedToPrivacy: boolean;
  }): string => {
    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const newId = `ALM-REQ-${randomDigits}`;
    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const newReq: PatientRequest = {
      id: newId,
      ...data,
      status: 'new',
      createdAt: formattedDate,
      coordinatorNotes: 'طلب جديد مسجل حديثاً في منصة العرض التجريبي.',
      estimatedCost: 'قيد التقدير والتنسيق المبدئي',
      airportPickup: data.serviceType === 'foreign_reception' || data.serviceType === 'international_services',
      hotelBooked: false,
    };

    setRequests(prev => [newReq, ...prev]);
    setTrackingCode(newId);
    showToast(
      language === 'ar'
        ? `تم تسجيل طلبك بنجاح! رقم المتابعة التجريبي هو: ${newId}`
        : `Request submitted successfully! Demo tracking code: ${newId}`
    );
    return newId;
  };

  const updateRequestStatus = (id: string, status: RequestStatus, note?: string) => {
    setRequests(prev =>
      prev.map(item => {
        if (item.id === id) {
          return {
            ...item,
            status,
            coordinatorNotes: note ? `${note} (تحديث: ${new Date().toLocaleDateString('ar-EG')})` : item.coordinatorNotes
          };
        }
        return item;
      })
    );
    showToast(
      language === 'ar'
        ? `تم تحديث حالة الطلب ${id} إلى: ${status}`
        : `Request ${id} status updated to: ${status}`
    );
  };

  const resetDemoData = () => {
    setRequests(INITIAL_REQUESTS);
    setTrackingCode('ALM-REQ-7924');
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
    showToast(
      language === 'ar'
        ? 'تمت استعادة البيانات التجريبية الافتراضية بنجاح'
        : 'Demo data reset to factory initial state'
    );
  };

  const lookupTracking = (code: string): boolean => {
    const trimmed = code.trim().toUpperCase();
    const found = requests.some(r => r.id.toUpperCase() === trimmed);
    if (found) {
      setTrackingCode(trimmed);
      return true;
    }
    return false;
  };

  const currentTrackedRequest = requests.find(
    r => r.id.toUpperCase() === trackingCode.toUpperCase()
  ) || requests[0] || null;

  const demoAdminLogin = () => {
    setIsAdminLoggedIn(true);
    showToast(language === 'ar' ? 'تم الدخول بحساب المشرف التجريبي' : 'Logged in as Demo Admin');
  };

  const demoAdminLogout = () => {
    setIsAdminLoggedIn(false);
    showToast(language === 'ar' ? 'تم تسجيل الخروج من لوحة الإدارة' : 'Logged out of admin dashboard');
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        toggleLanguage,
        currentView,
        setCurrentView,
        requests,
        medicalCenters,
        doctors,
        rehabCenters,
        healingDestinations,
        translators,
        invoices,
        selectedServiceForForm,
        setSelectedServiceForForm,
        openRequestModalForService,
        trackingCode,
        setTrackingCode,
        currentTrackedRequest,
        lookupTracking,
        addNewRequest,
        updateRequestStatus,
        resetDemoData,
        isAdminLoggedIn,
        setIsAdminLoggedIn,
        demoAdminLogin,
        demoAdminLogout,
        toastMessage,
        showToast,
        clearToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
