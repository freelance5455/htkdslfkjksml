import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Product, 
  ServiceItem, 
  CartItem, 
  Language, 
  ProductCategory, 
  SavedOrder, 
  SavedBooking, 
  ShopSettings,
  OrderFormData,
  ServiceBookingFormData
} from '../types';
import { INITIAL_PRODUCTS, INITIAL_SERVICES, INITIAL_SHOP_SETTINGS } from '../data/initialData';
import { translations } from '../data/translations';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.en;
  
  // Products
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  addProduct: (newProd: Product) => void;
  updateProduct: (updated: Product) => void;
  deleteProduct: (id: string) => void;
  toggleStock: (id: string) => void;
  resetSampleProducts: () => void;
  
  // Services
  services: ServiceItem[];
  
  // Settings
  shopSettings: ShopSettings;
  updateShopSettings: (settings: ShopSettings) => void;
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, delta: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  
  // Orders & Bookings logs
  savedOrders: SavedOrder[];
  updateOrderStatus: (id: string, status: SavedOrder['status']) => void;
  savedBookings: SavedBooking[];
  updateBookingStatus: (id: string, status: SavedBooking['status']) => void;
  
  // WhatsApp Actions
  sendOrderViaWhatsApp: (formData: OrderFormData) => void;
  sendServiceBookingViaWhatsApp: (formData: ServiceBookingFormData) => void;
  
  // Admin State
  isAdminAuthenticated: boolean;
  loginAdmin: (pin: string) => boolean;
  logoutAdmin: () => void;
  
  // Modals & UI Navigation
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isServiceModalOpen: boolean;
  openServiceModal: (service?: ServiceItem) => void;
  closeServiceModal: () => void;
  selectedServiceForBooking: ServiceItem | null;
  selectedProductForModal: Product | null;
  setSelectedProductForModal: (prod: Product | null) => void;
  isAdminModalOpen: boolean;
  setIsAdminModalOpen: (open: boolean) => void;
  isPWAGuideOpen: boolean;
  setIsPWAGuideOpen: (open: boolean) => void;
  
  // Filters
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: ProductCategory;
  setSelectedCategory: (category: ProductCategory) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Language
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('ak_golu_lang');
      return (saved === 'hi' || saved === 'en') ? saved : 'hi'; // Default Hindi for authentic local feel
    } catch {
      return 'hi';
    }
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('ak_golu_lang', lang);
    } catch (e) {
      console.warn('Storage unavailable', e);
    }
  };

  const t = translations[language];

  // Products
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('ak_golu_products_v2');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading products from storage', e);
    }
    return INITIAL_PRODUCTS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('ak_golu_products_v2', JSON.stringify(products));
    } catch (e) {
      console.warn('Error saving products', e);
    }
  }, [products]);

  const addProduct = (newProd: Product) => {
    setProducts(prev => [newProd, ...prev]);
  };

  const updateProduct = (updated: Product) => {
    setProducts(prev => prev.map(p => (p.id === updated.id ? updated : p)));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const toggleStock = (id: string) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, inStock: !p.inStock } : p));
  };

  const resetSampleProducts = () => {
    setProducts(INITIAL_PRODUCTS);
  };

  // Services
  const [services] = useState<ServiceItem[]>(INITIAL_SERVICES);

  // Shop Settings
  const [shopSettings, setShopSettings] = useState<ShopSettings>(() => {
    try {
      const saved = localStorage.getItem('ak_golu_settings_v2');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading settings', e);
    }
    return INITIAL_SHOP_SETTINGS;
  });

  const updateShopSettings = (settings: ShopSettings) => {
    setShopSettings(settings);
    try {
      localStorage.setItem('ak_golu_settings_v2', JSON.stringify(settings));
    } catch (e) {
      console.warn('Error saving settings', e);
    }
  };

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('ak_golu_cart');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading cart', e);
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem('ak_golu_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn('Error saving cart', e);
    }
  }, [cart]);

  const addToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev =>
      prev
        .map(item => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Orders Log
  const [savedOrders, setSavedOrders] = useState<SavedOrder[]>(() => {
    try {
      const saved = localStorage.getItem('ak_golu_orders_log');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading orders log', e);
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem('ak_golu_orders_log', JSON.stringify(savedOrders));
    } catch (e) {
      console.warn('Error saving orders log', e);
    }
  }, [savedOrders]);

  const updateOrderStatus = (id: string, status: SavedOrder['status']) => {
    setSavedOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
  };

  // Bookings Log
  const [savedBookings, setSavedBookings] = useState<SavedBooking[]>(() => {
    try {
      const saved = localStorage.getItem('ak_golu_bookings_log');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading bookings log', e);
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem('ak_golu_bookings_log', JSON.stringify(savedBookings));
    } catch (e) {
      console.warn('Error saving bookings log', e);
    }
  }, [savedBookings]);

  const updateBookingStatus = (id: string, status: SavedBooking['status']) => {
    setSavedBookings(prev => prev.map(b => b.id === id ? { ...b, status } : b));
  };

  // Admin authentication
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);

  const loginAdmin = (pin: string) => {
    if (pin.trim() === shopSettings.adminPin.trim()) {
      setIsAdminAuthenticated(true);
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminAuthenticated(false);
  };

  // Modals & Navigation
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isServiceModalOpen, setIsServiceModalOpen] = useState(false);
  const [selectedServiceForBooking, setSelectedServiceForBooking] = useState<ServiceItem | null>(null);
  const [selectedProductForModal, setSelectedProductForModal] = useState<Product | null>(null);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isPWAGuideOpen, setIsPWAGuideOpen] = useState(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');

  const openServiceModal = (service?: ServiceItem) => {
    setSelectedServiceForBooking(service || null);
    setIsServiceModalOpen(true);
  };

  const closeServiceModal = () => {
    setSelectedServiceForBooking(null);
    setIsServiceModalOpen(false);
  };

  // WhatsApp Order Submission
  const sendOrderViaWhatsApp = (formData: OrderFormData) => {
    const orderId = `ORD-${Date.now().toString().slice(-6)}`;
    const dateStr = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

    // Save to local admin log
    const newRecord: SavedOrder = {
      id: orderId,
      timestamp: dateStr,
      customerName: formData.customerName,
      phoneNumber: formData.phoneNumber,
      deliveryAddress: formData.deliveryAddress,
      cityPincode: formData.cityPincode,
      items: cart.map(item => ({
        id: item.product.id,
        name: item.product.name[language] || item.product.name.en,
        quantity: item.quantity,
        price: item.product.price
      })),
      totalAmount: cartTotal,
      status: 'Pending',
      assignedNumber: formData.targetWhatsAppNumber
    };
    setSavedOrders(prev => [newRecord, ...prev]);

    // Format prefilled WhatsApp message
    const lines = [
      `🛒 *NEW ORDER ENQUIRY - A K GOLU COMPUTER* 🛒`,
      `*Order ID:* ${orderId}`,
      `*Date:* ${dateStr}`,
      `---------------------------------`,
      `👤 *Customer Name:* ${formData.customerName}`,
      `📞 *Mobile:* ${formData.phoneNumber}`,
      `📍 *Address:* ${formData.deliveryAddress}`,
      `🏷️ *Pincode / Area:* ${formData.cityPincode}`,
      formData.specialNotes ? `📝 *Note:* ${formData.specialNotes}` : '',
      `---------------------------------`,
      `📦 *ORDERED ITEMS:*`,
      ...cart.map((item, idx) => {
        const itemTotal = item.product.price * item.quantity;
        return `${idx + 1}. ${item.product.name.en} (${item.product.condition.toUpperCase()})\n   Qty: ${item.quantity} x ₹${item.product.price.toLocaleString('en-IN')} = ₹${itemTotal.toLocaleString('en-IN')}`;
      }),
      `---------------------------------`,
      `💰 *Estimated Total:* ₹${cartTotal.toLocaleString('en-IN')}`,
      `⚠️ *Payment Status:* Unpaid / Pending Confirmation (To be confirmed with shop owner via Cash On Delivery or UPI).`,
      `---------------------------------`,
      `_Please confirm availability and dispatch schedule. Thank you!_`
    ].filter(Boolean);

    const message = lines.join('\n');
    const encoded = encodeURIComponent(message);
    const targetNumber = formData.targetWhatsAppNumber || shopSettings.phone1;
    const cleanNumber = targetNumber.replace(/\D/g, '');
    const waUrl = `https://wa.me/91${cleanNumber}?text=${encoded}`;

    // Open WhatsApp
    window.open(waUrl, '_blank');
  };

  // WhatsApp Service Booking Submission
  const sendServiceBookingViaWhatsApp = (formData: ServiceBookingFormData) => {
    const bookingId = `SRV-${Date.now().toString().slice(-6)}`;
    const dateStr = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

    // Save to local admin log
    const newRecord: SavedBooking = {
      id: bookingId,
      timestamp: dateStr,
      customerName: formData.customerName,
      phoneNumber: formData.phoneNumber,
      address: formData.address,
      deviceType: formData.deviceType,
      problem: formData.problemDescription,
      serviceMode: formData.serviceMode,
      preferredDate: formData.preferredDate,
      preferredSlot: formData.preferredTimeSlot,
      status: 'Received',
      assignedNumber: formData.targetWhatsAppNumber
    };
    setSavedBookings(prev => [newRecord, ...prev]);

    const serviceModeLabel = formData.serviceMode === 'home_service' 
      ? '🏠 Doorstep Home Service (घर पर विजिट)' 
      : '🏬 Shop Visit (दुकान पर लाना)';

    const lines = [
      `🔧 *NEW SERVICE / REPAIR BOOKING - A K GOLU COMPUTER* 🔧`,
      `*Booking ID:* ${bookingId}`,
      `*Date:* ${dateStr}`,
      `---------------------------------`,
      `👤 *Customer Name:* ${formData.customerName}`,
      `📞 *Mobile:* ${formData.phoneNumber}`,
      formData.alternatePhone ? `📞 *Alt Mobile:* ${formData.alternatePhone}` : '',
      `📍 *Address:* ${formData.address}`,
      `---------------------------------`,
      `🛠️ *Service Required:* ${formData.serviceType}`,
      `💻 *Device Type:* ${formData.deviceType}`,
      `📍 *Location Preference:* ${serviceModeLabel}`,
      `📅 *Preferred Date:* ${formData.preferredDate}`,
      `⏰ *Preferred Slot:* ${formData.preferredTimeSlot}`,
      `---------------------------------`,
      `📝 *Problem Details:*`,
      `"${formData.problemDescription}"`,
      `---------------------------------`,
      `_Please confirm technician availability and visit time slot. Thank you!_`
    ].filter(Boolean);

    const message = lines.join('\n');
    const encoded = encodeURIComponent(message);
    const targetNumber = formData.targetWhatsAppNumber || shopSettings.phone1;
    const cleanNumber = targetNumber.replace(/\D/g, '');
    const waUrl = `https://wa.me/91${cleanNumber}?text=${encoded}`;

    window.open(waUrl, '_blank');
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        products,
        setProducts,
        addProduct,
        updateProduct,
        deleteProduct,
        toggleStock,
        resetSampleProducts,
        services,
        shopSettings,
        updateShopSettings,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartTotal,
        cartCount,
        savedOrders,
        updateOrderStatus,
        savedBookings,
        updateBookingStatus,
        sendOrderViaWhatsApp,
        sendServiceBookingViaWhatsApp,
        isAdminAuthenticated,
        loginAdmin,
        logoutAdmin,
        isCartOpen,
        setIsCartOpen,
        isServiceModalOpen,
        openServiceModal,
        closeServiceModal,
        selectedServiceForBooking,
        selectedProductForModal,
        setSelectedProductForModal,
        isAdminModalOpen,
        setIsAdminModalOpen,
        isPWAGuideOpen,
        setIsPWAGuideOpen,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
