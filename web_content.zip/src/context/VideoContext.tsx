import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { VideoItem, WatchProgress, UserProfile } from '../types/video';
import {
  getProfilesFromDb,
  saveProfileToDb,
  deleteProfileFromDb,
  subscribeToProfileWatchlist,
  toggleProfileWatchlistInDb,
  subscribeToProfileWatchHistory,
  saveProfileWatchProgressToDb,
  INITIAL_PROFILES,
} from '../services/firebaseProfileService';
import { auth, onAuthStateChanged, signOut, type User } from '../firebase';

interface VideoContextType {
  videos: VideoItem[];
  filteredVideos: VideoItem[];
  isLoading: boolean;
  activeVideo: VideoItem | null;
  detailVideo: VideoItem | null;
  youtubeVideo: VideoItem | null;
  isUploadModalOpen: boolean;
  isAuthModalOpen: boolean;
  currentUser: User | null;
  myList: string[];
  likedVideos: string[];
  dislikedVideos: string[];
  watchHistory: WatchProgress[];
  searchQuery: string;
  activeTab: string;
  language: 'en' | 'ur';
  currentProfile: UserProfile | null;
  profiles: UserProfile[];
  isSelectingProfile: boolean;
  stats: { totalVideos: number; uploadedVideos: number };
  setActiveVideo: (video: VideoItem | null) => void;
  setDetailVideo: (video: VideoItem | null) => void;
  setYoutubeVideo: (video: VideoItem | null) => void;
  setIsUploadModalOpen: (open: boolean) => void;
  setIsAuthModalOpen: (open: boolean) => void;
  setSearchQuery: (query: string) => void;
  setActiveTab: (tab: string) => void;
  setLanguage: (lang: 'en' | 'ur') => void;
  selectProfile: (profile: UserProfile) => void;
  setIsSelectingProfile: (selecting: boolean) => void;
  addProfile: (name: string, avatar: string, isKids: boolean) => Promise<void>;
  updateProfile: (profile: UserProfile) => Promise<void>;
  deleteProfile: (profileId: string) => Promise<void>;
  toggleMyList: (videoId: string) => Promise<void>;
  reactToVideo: (videoId: string, action: 'like' | 'dislike' | 'none') => Promise<void>;
  saveWatchProgress: (videoId: string, currentTime: number, duration: number) => Promise<void>;
  deleteVideo: (videoId: string) => Promise<boolean>;
  refreshVideos: () => Promise<void>;
  playNextVideo: () => void;
  logOut: () => Promise<void>;
}

const VideoContext = createContext<VideoContextType | undefined>(undefined);

export const VideoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeVideo, setActiveVideo] = useState<VideoItem | null>(null);
  const [detailVideo, setDetailVideo] = useState<VideoItem | null>(null);
  const [youtubeVideo, setYoutubeVideo] = useState<VideoItem | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [myList, setMyList] = useState<string[]>([]);
  const [likedVideos, setLikedVideos] = useState<string[]>([]);
  const [dislikedVideos, setDislikedVideos] = useState<string[]>([]);
  const [watchHistory, setWatchHistory] = useState<WatchProgress[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('home');
  const [language, setLanguage] = useState<'en' | 'ur'>('en');
  const [stats, setStats] = useState({ totalVideos: 0, uploadedVideos: 0 });

  // Profiles management with Firebase Firestore
  const [profiles, setProfiles] = useState<UserProfile[]>(INITIAL_PROFILES);
  const [currentProfile, setCurrentProfile] = useState<UserProfile | null>(null);
  const [isSelectingProfile, setIsSelectingProfile] = useState(true);

  const unsubscribeWatchlistRef = useRef<(() => void) | null>(null);
  const unsubscribeHistoryRef = useRef<(() => void) | null>(null);

  const fetchVideos = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/videos');
      if (res.ok) {
        const data = await res.json();
        setVideos(data);
      }
    } catch (err) {
      console.error('Failed to load videos:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/stats');
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (err) {
      console.error('Failed to load stats:', err);
    }
  };

  // Load profiles from Firestore on startup
  useEffect(() => {
    fetchVideos();
    fetchStats();

    const loadProfiles = async () => {
      try {
        const dbProfiles = await getProfilesFromDb();
        if (dbProfiles && dbProfiles.length > 0) {
          setProfiles(dbProfiles);
          // Check saved profile in local storage
          const savedProfileId = localStorage.getItem('cinestream_active_profile');
          const found = dbProfiles.find((p) => p.id === savedProfileId);
          if (found) {
            selectProfile(found);
          } else {
            setIsSelectingProfile(true);
          }
        }
      } catch (err) {
        console.error('Failed to load Firestore profiles:', err);
      }
    };

    // Listen for Firebase Auth state changes
    const unsubAuth = onAuthStateChanged(auth, (user: User | null) => {
      setCurrentUser(user);
    });

    loadProfiles();

    return () => {
      unsubAuth();
    };
  }, []);

  // When current profile changes, subscribe to its unique Firestore Watchlist & Watch History
  useEffect(() => {
    if (!currentProfile) {
      setMyList([]);
      setWatchHistory([]);
      return;
    }

    // Clean up previous profile listeners
    if (unsubscribeWatchlistRef.current) {
      unsubscribeWatchlistRef.current();
    }
    if (unsubscribeHistoryRef.current) {
      unsubscribeHistoryRef.current();
    }

    // Subscribe to Firestore Watchlist for this profile
    unsubscribeWatchlistRef.current = subscribeToProfileWatchlist(
      currentProfile.id,
      (videoIds) => {
        setMyList(videoIds);
      }
    );

    // Subscribe to Firestore Watch History for this profile
    unsubscribeHistoryRef.current = subscribeToProfileWatchHistory(
      currentProfile.id,
      (historyList) => {
        setWatchHistory(historyList);
      }
    );

    return () => {
      if (unsubscribeWatchlistRef.current) unsubscribeWatchlistRef.current();
      if (unsubscribeHistoryRef.current) unsubscribeHistoryRef.current();
    };
  }, [currentProfile?.id]);

  const selectProfile = (profile: UserProfile) => {
    setCurrentProfile(profile);
    setIsSelectingProfile(false);
    localStorage.setItem('cinestream_active_profile', profile.id);
  };

  const addProfile = async (name: string, avatar: string, isKids: boolean) => {
    const newProfile: UserProfile = {
      id: `profile-${Date.now()}`,
      name: name.trim(),
      avatar,
      isKids,
    };
    await saveProfileToDb(newProfile);
    setProfiles((prev) => [...prev, newProfile]);
  };

  const updateProfile = async (updated: UserProfile) => {
    await saveProfileToDb(updated);
    setProfiles((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    if (currentProfile?.id === updated.id) {
      setCurrentProfile(updated);
    }
  };

  const deleteProfile = async (profileId: string) => {
    await deleteProfileFromDb(profileId);
    setProfiles((prev) => prev.filter((p) => p.id !== profileId));
    if (currentProfile?.id === profileId) {
      const remaining = profiles.filter((p) => p.id !== profileId);
      if (remaining.length > 0) {
        selectProfile(remaining[0]);
      } else {
        setCurrentProfile(null);
        setIsSelectingProfile(true);
      }
    }
  };

  const toggleMyList = async (videoId: string) => {
    if (!currentProfile) return;
    try {
      await toggleProfileWatchlistInDb(currentProfile.id, videoId);
    } catch (err) {
      console.error('Failed to toggle watchlist in Firestore:', err);
    }
  };

  const saveWatchProgress = async (videoId: string, currentTime: number, duration: number) => {
    if (!currentProfile) return;
    try {
      await saveProfileWatchProgressToDb(currentProfile.id, videoId, currentTime, duration);
    } catch (err) {
      console.error('Failed to save progress to Firestore:', err);
    }
  };

  const reactToVideo = async (videoId: string, action: 'like' | 'dislike' | 'none') => {
    try {
      const res = await fetch(`/api/videos/${videoId}/react`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      if (res.ok) {
        const data = await res.json();
        setLikedVideos((prev) =>
          data.userLiked ? [...prev.filter((id) => id !== videoId), videoId] : prev.filter((id) => id !== videoId)
        );
        setDislikedVideos((prev) =>
          data.userDisliked ? [...prev.filter((id) => id !== videoId), videoId] : prev.filter((id) => id !== videoId)
        );
        setVideos((prev) =>
          prev.map((v) => (v.id === videoId ? { ...v, likes: data.likes, dislikes: data.dislikes } : v))
        );
      }
    } catch (err) {
      console.error('Failed to react to video:', err);
    }
  };

  const deleteVideo = async (videoId: string): Promise<boolean> => {
    try {
      const res = await fetch(`/api/videos/${videoId}`, { method: 'DELETE' });
      if (res.ok) {
        setVideos((prev) => prev.filter((v) => v.id !== videoId));
        if (detailVideo?.id === videoId) setDetailVideo(null);
        if (activeVideo?.id === videoId) setActiveVideo(null);
        fetchStats();
        return true;
      }
    } catch (err) {
      console.error('Failed to delete video:', err);
    }
    return false;
  };

  const playNextVideo = () => {
    if (!activeVideo || videos.length === 0) return;
    const currentIndex = videos.findIndex((v) => v.id === activeVideo.id);
    const nextIndex = (currentIndex + 1) % videos.length;
    setActiveVideo(videos[nextIndex]);
  };

  // If Kids profile is active, automatically filter out 16+ and 18+ titles
  const filteredVideos = currentProfile?.isKids
    ? videos.filter((v) => v.rating === 'All' || v.rating === '13+')
    : videos;

  return (
    <VideoContext.Provider
      value={{
        videos,
        filteredVideos,
        isLoading,
        activeVideo,
        detailVideo,
        isUploadModalOpen,
        myList,
        likedVideos,
        dislikedVideos,
        watchHistory,
        searchQuery,
        activeTab,
        language,
        currentProfile,
        profiles,
        isSelectingProfile,
        stats,
        youtubeVideo,
        isAuthModalOpen,
        currentUser,
        setActiveVideo,
        setDetailVideo,
        setYoutubeVideo,
        setIsUploadModalOpen,
        setIsAuthModalOpen,
        setSearchQuery,
        setActiveTab,
        setLanguage,
        selectProfile,
        setIsSelectingProfile,
        addProfile,
        updateProfile,
        deleteProfile,
        toggleMyList,
        reactToVideo,
        saveWatchProgress,
        deleteVideo,
        refreshVideos: async () => {
          await fetchVideos();
          await fetchStats();
        },
        playNextVideo,
        logOut: async () => {
          await signOut(auth);
        },
      }}
    >
      {children}
    </VideoContext.Provider>
  );
};

export const useVideo = () => {
  const context = useContext(VideoContext);
  if (!context) {
    throw new Error('useVideo must be used within a VideoProvider');
  }
  return context;
};
