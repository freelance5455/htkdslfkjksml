import React, { createContext, useContext, useEffect, useState } from 'react';
import { LanguageCode, TRANSLATIONS, Translations } from '../i18n/translations';

export interface CalculationSettings {
  showStepByStep: boolean;
  autoSaveHistory: boolean;
  scientificNotation: boolean;
}

interface ToastMessage {
  id: string;
  message: string;
  type?: 'success' | 'info' | 'error';
}

interface ThemeContextType {
  theme: 'dark' | 'light' | 'system';
  setTheme: (t: 'dark' | 'light' | 'system') => void;
  language: LanguageCode;
  setLanguage: (l: LanguageCode) => void;
  t: Translations;
  settings: CalculationSettings;
  updateSettings: (s: Partial<CalculationSettings>) => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
  toasts: ToastMessage[];
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<'dark' | 'light' | 'system'>(() => {
    return (localStorage.getItem('formulax_theme') as any) || 'dark';
  });

  const [language, setLanguageState] = useState<LanguageCode>(() => {
    return (localStorage.getItem('formulax_lang') as any) || 'en';
  });

  const [settings, setSettings] = useState<CalculationSettings>(() => {
    const saved = localStorage.getItem('formulax_calc_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return {
      showStepByStep: true,
      autoSaveHistory: true,
      scientificNotation: false
    };
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    localStorage.setItem('formulax_theme', theme);
    const root = document.documentElement;
    if (theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const setTheme = (t: 'dark' | 'light' | 'system') => {
    setThemeState(t);
  };

  const setLanguage = (l: LanguageCode) => {
    setLanguageState(l);
    localStorage.setItem('formulax_lang', l);
  };

  const updateSettings = (newPartial: Partial<CalculationSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newPartial };
      localStorage.setItem('formulax_calc_settings', JSON.stringify(updated));
      return updated;
    });
  };

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = `${Date.now()}_${Math.random()}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id));
    }, 3000);
  };

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  return (
    <ThemeContext.Provider
      value={{
        theme,
        setTheme,
        language,
        setLanguage,
        t,
        settings,
        updateSettings,
        showToast,
        toasts
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
