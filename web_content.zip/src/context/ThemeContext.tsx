import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';

export type ThemeMode = 'auto' | 'light' | 'dark';
export type ResolvedTheme = 'light' | 'dark';

interface ThemeContextType {
  mode: ThemeMode;
  resolvedTheme: ResolvedTheme;
  isAuto: boolean;
  isDaytime: boolean;
  deviceHour: number;
  deviceTimeStr: string;
  setMode: (mode: ThemeMode) => void;
  toggleNext: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const STORAGE_KEY = 'iraqi_live_theme_mode';

// Day hours: 06:00 (6 AM) to 17:59 (5:59 PM). Night hours: 18:00 (6 PM) to 05:59 (5:59 AM)
export function isDeviceDaytime(date = new Date()): boolean {
  const hour = date.getHours();
  return hour >= 6 && hour < 18;
}

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Saved mode preference ('auto', 'light', 'dark'). Default is 'auto' (automatic based on device time)
  const [mode, setModeState] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === 'light' || saved === 'dark' || saved === 'auto') {
        return saved;
      }
    } catch {
      // ignore
    }
    return 'auto';
  });

  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  // Track device time and update every 15 seconds to catch transitions accurately
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 15000);
    return () => clearInterval(timer);
  }, []);

  const deviceHour = currentTime.getHours();
  const isDaytime = useMemo(() => isDeviceDaytime(currentTime), [currentTime]);

  const deviceTimeStr = useMemo(() => {
    return currentTime.toLocaleTimeString('ar-SA', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  }, [currentTime]);

  // Compute the resolved active theme
  const resolvedTheme: ResolvedTheme = useMemo(() => {
    if (mode === 'light') return 'light';
    if (mode === 'dark') return 'dark';
    // Mode is 'auto': strictly based on device local time
    return isDaytime ? 'light' : 'dark';
  }, [mode, isDaytime]);

  // Synchronize with documentElement class and color-scheme meta
  useEffect(() => {
    const root = document.documentElement;
    if (resolvedTheme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
      root.style.colorScheme = 'dark';
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
      root.style.colorScheme = 'light';
    }

    // Also update theme-color meta tag for mobile browsers
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute('content', resolvedTheme === 'dark' ? '#080b12' : '#f8fafc');
    }
  }, [resolvedTheme]);

  const setMode = (newMode: ThemeMode) => {
    setModeState(newMode);
    try {
      localStorage.setItem(STORAGE_KEY, newMode);
    } catch {
      // ignore
    }
  };

  const toggleNext = () => {
    if (mode === 'auto') {
      setMode('light');
    } else if (mode === 'light') {
      setMode('dark');
    } else {
      setMode('auto');
    }
  };

  return (
    <ThemeContext.Provider
      value={{
        mode,
        resolvedTheme,
        isAuto: mode === 'auto',
        isDaytime,
        deviceHour,
        deviceTimeStr,
        setMode,
        toggleNext,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export function useTheme(): ThemeContextType {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
