import React, { createContext, useContext, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  VentureConfig,
  VentureState,
  Upgrade,
  RealmAchievement,
  GameSaveState,
  CustomIconRecord,
  CustomIconPreset,
} from '../types/game';
import { INITIAL_VENTURES } from '../data/venturesData';
import { INITIAL_UPGRADES } from '../data/upgradesData';
import { INITIAL_ACHIEVEMENTS } from '../data/achievementsData';
import {
  calculateVentureCost,
  calculateMaxAffordable,
  calculateNextMilestoneTarget,
  calculateArchonsFromGold,
} from '../utils/formatters';
import { sound } from '../utils/audio';

export type BuyMode = '1' | '10' | '25' | '100' | 'NEXT' | 'MAX';

export interface FloatingText {
  id: number;
  text: string;
  x: number;
  y: number;
  color?: string;
}

export interface TapPoint {
  clientX: number;
  clientY: number;
}

export interface OfflineReport {
  secondsOffline: number;
  goldEarned: number;
}

interface GameContextType {
  // Currencies
  gold: number;
  lifetimeGold: number;
  archons: number;
  lifetimeArchons: number;
  archonBoostPercent: number;
  pendingArchons: number;

  // Ventures
  ventures: VentureConfig[];
  ventureStates: Record<string, VentureState>;
  getVentureProfit: (id: string) => number;
  getVentureCycleTime: (id: string) => number;
  getVentureCostForMode: (id: string) => { count: number; cost: number; canAfford: boolean };
  buyVenture: (id: string) => void;
  startVentureCycle: (id: string) => void;
  hireManager: (ventureId: string) => void;

  // Upgrades
  upgrades: Upgrade[];
  buyUpgrade: (upgradeId: string) => void;

  // Ascension (Prestige)
  ascendRealm: () => void;
  ascensionsCount: number;

  // Manual Clicker / Frenzy
  clickOrb: (taps?: TapPoint[] | React.MouseEvent | TapPoint) => void;
  totalClicks: number;
  frenzyMeter: number; // 0 to 100
  isFrenzyActive: boolean;
  frenzyTimeRemaining: number;

  // UI / Controls
  buyMode: BuyMode;
  setBuyMode: (mode: BuyMode) => void;
  floatingTexts: FloatingText[];
  achievements: RealmAchievement[];
  offlineReport: OfflineReport | null;
  dismissOfflineReport: () => void;

  // Settings & Utilities
  numberFormat: 'SUFFIX' | 'SCIENTIFIC';
  setNumberFormat: (fmt: 'SUFFIX' | 'SCIENTIFIC') => void;
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
  musicEnabled: boolean;
  setMusicEnabled: (val: boolean) => void;
  musicVolume: number;
  setMusicVolume: (val: number) => void;
  toggleMusic: () => void;
  totalRealmProfitPerSec: number;
  effectiveProfitPerSec: number;
  tapsPerSec: number;
  tapProfitPerSec: number;
  resetAllProgress: () => void;
  exportSaveString: () => string;
  importSaveString: (str: string) => boolean;

  // Custom .JPG Icons Management (Saved Venture Icons + Guildmaster Portraits)
  customIcons: Record<string, CustomIconRecord>;
  ventureIcons: Record<string, CustomIconRecord>;
  guildmasterIcons: Record<string, CustomIconRecord>;
  customPresets: CustomIconPreset[];
  uploadCustomIcon: (
    guildmasterId: string,
    fileOrBase64: File | string,
    name?: string
  ) => Promise<{ success: boolean; error?: string }>;
  applyPresetIcon: (
    guildmasterId: string,
    presetUrl: string,
    presetName?: string
  ) => Promise<{ success: boolean; error?: string }>;
  removeCustomIcon: (guildmasterId: string) => Promise<{ success: boolean; error?: string }>;
  resetAllCustomIcons: () => Promise<{ success: boolean; error?: string }>;
  refreshCustomIcons: () => Promise<void>;
}

const SAVE_KEY = 'realm_capitalist_save_v2';
const SAVE_BACKUP_KEY = 'realm_capitalist_save_backup_v2';

function getInitialSaveData(): GameSaveState | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(SAVE_KEY) || localStorage.getItem(SAVE_BACKUP_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as GameSaveState;
  } catch (err) {
    console.warn('Failed to parse saved game data', err);
    try {
      const backupRaw = localStorage.getItem(SAVE_BACKUP_KEY);
      if (backupRaw) return JSON.parse(backupRaw) as GameSaveState;
    } catch {
      // ignore
    }
    return null;
  }
}

export interface AudioContextType {
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
  musicEnabled: boolean;
  setMusicEnabled: (val: boolean) => void;
  musicVolume: number;
  setMusicVolume: (val: number) => void;
  toggleMusic: () => void;
}

export const AudioContext = createContext<AudioContextType | null>(null);

export function useAudio(): AudioContextType {
  const context = useContext(AudioContext);
  if (!context) {
    throw new Error('useAudio must be used within a GameProvider');
  }
  return context;
}

const GameContext = createContext<GameContextType | null>(null);

export function GameProvider({ children }: { children: React.ReactNode }) {
  // Synchronous initial state load from local storage
  const initialSave = useMemo(() => getInitialSaveData(), []);

  // State
  const [gold, setGold] = useState<number>(() =>
    typeof initialSave?.gold === 'number' && !isNaN(initialSave.gold) ? initialSave.gold : 4
  );
  const [lifetimeGold, setLifetimeGold] = useState<number>(() =>
    typeof initialSave?.lifetimeGold === 'number' && !isNaN(initialSave.lifetimeGold) ? initialSave.lifetimeGold : 4
  );
  const [archons, setArchons] = useState<number>(() =>
    typeof initialSave?.archons === 'number' && !isNaN(initialSave.archons) ? initialSave.archons : 0
  );
  const [lifetimeArchons, setLifetimeArchons] = useState<number>(() =>
    typeof initialSave?.lifetimeArchons === 'number' && !isNaN(initialSave.lifetimeArchons) ? initialSave.lifetimeArchons : 0
  );
  const [archonBoostPercent, setArchonBoostPercent] = useState<number>(() =>
    typeof initialSave?.archonBoostPercent === 'number' && !isNaN(initialSave.archonBoostPercent) ? initialSave.archonBoostPercent : 2
  );
  const [ascensionsCount, setAscensionsCount] = useState<number>(() =>
    typeof initialSave?.ascensionsCount === 'number' && !isNaN(initialSave.ascensionsCount) ? initialSave.ascensionsCount : 0
  );
  const [totalClicks, setTotalClicks] = useState<number>(() =>
    typeof initialSave?.totalClicks === 'number' && !isNaN(initialSave.totalClicks) ? initialSave.totalClicks : 0
  );

  const [buyMode, setBuyMode] = useState<BuyMode>('1');
  const [numberFormat, setNumberFormat] = useState<'SUFFIX' | 'SCIENTIFIC'>(() =>
    initialSave?.numberFormat === 'SCIENTIFIC' ? 'SCIENTIFIC' : 'SUFFIX'
  );
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() =>
    typeof initialSave?.soundEnabled === 'boolean' ? initialSave.soundEnabled : true
  );
  const [musicEnabled, setMusicEnabled] = useState<boolean>(() =>
    typeof initialSave?.musicEnabled === 'boolean' ? initialSave.musicEnabled : true
  );
  const [musicVolume, setMusicVolume] = useState<number>(() =>
    typeof initialSave?.musicVolume === 'number' && !isNaN(initialSave.musicVolume) ? initialSave.musicVolume : 0.35
  );

  // Upgrades & Achievements
  const [upgrades, setUpgrades] = useState<Upgrade[]>(() => {
    if (initialSave?.purchasedUpgrades && Array.isArray(initialSave.purchasedUpgrades)) {
      return INITIAL_UPGRADES.map((u) => ({
        ...u,
        purchased: initialSave.purchasedUpgrades!.includes(u.id),
      }));
    }
    return INITIAL_UPGRADES;
  });

  const [achievements, setAchievements] = useState<RealmAchievement[]>(() => {
    if (initialSave?.unlockedAchievements && Array.isArray(initialSave.unlockedAchievements)) {
      return INITIAL_ACHIEVEMENTS.map((a) => ({
        ...a,
        unlocked: initialSave.unlockedAchievements!.includes(a.id),
      }));
    }
    return INITIAL_ACHIEVEMENTS;
  });

  // Floating text feedback
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const nextFloatId = useRef<number>(1);

  // Frenzy mechanics
  const [frenzyMeter, setFrenzyMeter] = useState<number>(0);
  const [isFrenzyActive, setIsFrenzyActive] = useState<boolean>(false);
  const [frenzyTimeRemaining, setFrenzyTimeRemaining] = useState<number>(0);

  // Offline report
  const [offlineReport, setOfflineReport] = useState<OfflineReport | null>(null);

  // Active Taps tracking (sliding 1-second window for real-time taps/sec & gold/sec addition)
  const recentTapsRef = useRef<Array<{ timestamp: number; count: number; gold: number }>>([]);
  const [tapsPerSec, setTapsPerSec] = useState<number>(0);
  const [tapProfitPerSec, setTapProfitPerSec] = useState<number>(0);

const DEFAULT_VENTURE_ICONS: Record<string, CustomIconRecord> = {
  mana_herbs: {
    id: 'mana_herbs',
    ventureId: 'mana_herbs',
    url: '/custom_icons/venture_1791477667407.jpg',
    filename: 'venture_1791477667407.jpg',
    name: 'Mana Herbs Plot Icon',
  },
  potion_brewery: {
    id: 'potion_brewery',
    ventureId: 'potion_brewery',
    url: '/custom_icons/venture_1791477831914.jpg',
    filename: 'venture_1791477831914.jpg',
    name: 'Alchemical Brewery Icon',
  },
  dwarven_forge: {
    id: 'dwarven_forge',
    ventureId: 'dwarven_forge',
    url: '/custom_icons/venture_1791478583643.jpg',
    filename: 'venture_1791478583643.jpg',
    name: 'Dwarven Ironforge Icon',
  },
  goblin_vaults: {
    id: 'goblin_vaults',
    ventureId: 'goblin_vaults',
    url: '/custom_icons/venture_1791478587953.jpg',
    filename: 'venture_1791478587953.jpg',
    name: 'Goblin Vaults & Courier Icon',
  },
  griffin_aviary: {
    id: 'griffin_aviary',
    ventureId: 'griffin_aviary',
    url: '/custom_icons/venture_1791479074157.jpg',
    filename: 'venture_1791479074157.jpg',
    name: 'Griffin Aviary & Skyway Icon',
  },
  arcane_spire: {
    id: 'arcane_spire',
    ventureId: 'arcane_spire',
    url: '/custom_icons/venture_1791479411650.jpg',
    filename: 'venture_1791479411650.jpg',
    name: 'Wizard’s Arcane Spire Icon',
  },
  dragon_roost: {
    id: 'dragon_roost',
    ventureId: 'dragon_roost',
    url: '/custom_icons/venture_1791479426798.jpg',
    filename: 'venture_1791479426798.jpg',
    name: 'Dragon Roost Hatchery Icon',
  },
  astral_observatory: {
    id: 'astral_observatory',
    ventureId: 'astral_observatory',
    url: '/custom_icons/venture_1791479473203.jpg',
    filename: 'venture_1791479473203.jpg',
    name: 'Astral Observatory Icon',
  },
  titan_citadel: {
    id: 'titan_citadel',
    ventureId: 'titan_citadel',
    url: '/custom_icons/venture_1791479552044.jpg',
    filename: 'venture_1791479552044.jpg',
    name: 'Titan Citadel Bastion Icon',
  },
  celestial_core: {
    id: 'celestial_core',
    ventureId: 'celestial_core',
    url: '/custom_icons/venture_1791479592901.jpg',
    filename: 'venture_1791479592901.jpg',
    name: 'Celestial Aether Core Icon',
  },
};

const DEFAULT_GUILDMASTER_ICONS: Record<string, CustomIconRecord> = {
  mana_herbs: {
    id: 'mana_herbs',
    guildmasterId: 'mana_herbs',
    ventureId: 'mana_herbs',
    url: '/custom_icons/gm_mana_herbs_1791481515089.jpg',
    filename: 'gm_mana_herbs_1791481515089.jpg',
    name: 'Botanist Bramble Portrait',
  },
  potion_brewery: {
    id: 'potion_brewery',
    guildmasterId: 'potion_brewery',
    ventureId: 'potion_brewery',
    url: '/custom_icons/gm_potion_brewery_1791481998820.jpg',
    filename: 'gm_potion_brewery_1791481998820.jpg',
    name: 'Morwen the Alchemist Portrait',
  },
  dwarven_forge: {
    id: 'dwarven_forge',
    guildmasterId: 'dwarven_forge',
    ventureId: 'dwarven_forge',
    url: '/custom_icons/gm_dwarven_forge_1791482178747.jpg',
    filename: 'gm_dwarven_forge_1791482178747.jpg',
    name: 'Master Smith Thrain Portrait',
  },
  goblin_vaults: {
    id: 'goblin_vaults',
    guildmasterId: 'goblin_vaults',
    ventureId: 'goblin_vaults',
    url: '/custom_icons/gm_goblin_vaults_1791482269476.jpg',
    filename: 'gm_goblin_vaults_1791482269476.jpg',
    name: 'Gilded Griphook Portrait',
  },
  griffin_aviary: {
    id: 'griffin_aviary',
    guildmasterId: 'griffin_aviary',
    ventureId: 'griffin_aviary',
    url: '/custom_icons/gm_griffin_aviary_1791482404341.jpg',
    filename: 'gm_griffin_aviary_1791482404341.jpg',
    name: 'Skywarden Zephyr Portrait',
  },
  arcane_spire: {
    id: 'arcane_spire',
    guildmasterId: 'arcane_spire',
    ventureId: 'arcane_spire',
    url: '/custom_icons/gm_arcane_spire_1791482469977.jpg',
    filename: 'gm_arcane_spire_1791482469977.jpg',
    name: 'Archmage Vaelin Portrait',
  },
  dragon_roost: {
    id: 'dragon_roost',
    guildmasterId: 'dragon_roost',
    ventureId: 'dragon_roost',
    url: '/custom_icons/gm_dragon_roost_1791482550852.jpg',
    filename: 'gm_dragon_roost_1791482550852.jpg',
    name: 'Dragon Warden Ignis Portrait',
  },
  astral_observatory: {
    id: 'astral_observatory',
    guildmasterId: 'astral_observatory',
    ventureId: 'astral_observatory',
    url: '/custom_icons/gm_astral_observatory_1791482986127.jpg',
    filename: 'gm_astral_observatory_1791482986127.jpg',
    name: 'Stargazer Lyra Portrait',
  },
  titan_citadel: {
    id: 'titan_citadel',
    guildmasterId: 'titan_citadel',
    ventureId: 'titan_citadel',
    url: '/custom_icons/gm_titan_citadel_1791483251841.jpg',
    filename: 'gm_titan_citadel_1791483251841.jpg',
    name: 'Lord Vorok the Iron-Grown Portrait',
  },
  celestial_core: {
    id: 'celestial_core',
    guildmasterId: 'celestial_core',
    ventureId: 'celestial_core',
    url: '/custom_icons/gm_celestial_core_1791483441717.jpg',
    filename: 'gm_celestial_core_1791483441717.jpg',
    name: 'Seraphina Dawnweaver Portrait',
  },
};

  // Custom .JPG Icons Backend State (Preserves saved venture icons + Guildmaster portraits)
  const [customIcons, setCustomIcons] = useState<Record<string, CustomIconRecord>>(() => {
    if (typeof window !== 'undefined') {
      try {
        const cached = localStorage.getItem('realm_custom_icons_cache');
        if (cached) return { ...DEFAULT_VENTURE_ICONS, ...JSON.parse(cached) };
      } catch {
        // ignore
      }
    }
    return DEFAULT_VENTURE_ICONS;
  });
  const [ventureIcons, setVentureIcons] = useState<Record<string, CustomIconRecord>>(() => {
    if (typeof window !== 'undefined') {
      try {
        const cached = localStorage.getItem('realm_custom_icons_cache');
        if (cached) return { ...DEFAULT_VENTURE_ICONS, ...JSON.parse(cached) };
      } catch {
        // ignore
      }
    }
    return DEFAULT_VENTURE_ICONS;
  });
  const [guildmasterIcons, setGuildmasterIcons] = useState<Record<string, CustomIconRecord>>(() => {
    if (typeof window !== 'undefined') {
      try {
        const cached = localStorage.getItem('realm_gm_icons_cache');
        if (cached) return { ...DEFAULT_GUILDMASTER_ICONS, ...JSON.parse(cached) };
      } catch {
        // ignore
      }
    }
    return DEFAULT_GUILDMASTER_ICONS;
  });
  const [customPresets, setCustomPresets] = useState<CustomIconPreset[]>([]);

  // Venture states: count, managerHired, progress, isRunning, lastRunStart
  const [ventureStates, setVentureStates] = useState<Record<string, VentureState>>(() => {
    const init: Record<string, VentureState> = {};
    INITIAL_VENTURES.forEach((v, index) => {
      init[v.id] = {
        count: index === 0 ? 1 : 0,
        managerHired: false,
        progress: 0,
        isRunning: false,
        lastRunStart: 0,
      };
    });
    if (initialSave?.ventures) {
      Object.keys(initialSave.ventures).forEach((k) => {
        if (init[k]) {
          init[k] = { ...init[k], ...initialSave.ventures[k] };
        }
      });
    }
    return init;
  });

  // Keep sound class and music engine synced with state
  useEffect(() => {
    sound.enabled = soundEnabled;
  }, [soundEnabled]);

  useEffect(() => {
    sound.musicEnabled = musicEnabled;
    sound.setMusicVolume(musicVolume);
    if (musicEnabled) {
      sound.ensureActive().then(() => {
        sound.startBgm();
      });
    } else {
      sound.stopBgm();
    }
  }, [musicEnabled, musicVolume]);

  // Awaken audio context and start theme music on first user gesture (respects browser autoplay policy)
  useEffect(() => {
    const handleUserInteraction = () => {
      sound.ensureActive();
    };

    window.addEventListener('click', handleUserInteraction, { passive: true });
    window.addEventListener('touchstart', handleUserInteraction, { passive: true });
    window.addEventListener('pointerdown', handleUserInteraction, { passive: true });
    window.addEventListener('keydown', handleUserInteraction, { passive: true });

    return () => {
      window.removeEventListener('click', handleUserInteraction);
      window.removeEventListener('touchstart', handleUserInteraction);
      window.removeEventListener('pointerdown', handleUserInteraction);
      window.removeEventListener('keydown', handleUserInteraction);
    };
  }, []);

  const toggleMusic = useCallback(() => {
    setMusicEnabled((prev) => {
      const next = !prev;
      sound.musicEnabled = next;
      if (next) {
        sound.ensureActive();
        sound.startBgm();
      } else {
        sound.stopBgm();
      }
      return next;
    });
  }, []);

  // Calculate Venture Multipliers
  const getVentureMultipliers = useCallback(
    (ventureId: string, currentCount: number) => {
      const config = INITIAL_VENTURES.find((v) => v.id === ventureId);
      if (!config) return { profitMult: 1, speedMult: 1 };

      let profitMult = 1;
      let speedMult = 1;

      // 1. Milestones
      config.milestones.forEach((m) => {
        if (currentCount >= m.count) {
          profitMult *= m.profitMultiplier;
          speedMult *= m.speedMultiplier;
        }
      });

      // 2. Purchased Upgrades
      upgrades.forEach((u) => {
        if (u.purchased) {
          if (u.targetVentureId === ventureId || u.targetVentureId === 'ALL') {
            if (u.type === 'PROFIT') {
              profitMult *= u.multiplier;
            } else if (u.type === 'SPEED') {
              speedMult *= u.multiplier;
            }
          }
        }
      });

      // 3. Archons (Prestige) bonus
      const totalArchonBoost = 1 + (archons * archonBoostPercent) / 100;
      profitMult *= totalArchonBoost;

      // 4. Frenzy Boost (3x when active)
      if (isFrenzyActive) {
        profitMult *= 3;
      }

      return { profitMult, speedMult };
    },
    [upgrades, archons, archonBoostPercent, isFrenzyActive]
  );

  const getVentureProfit = useCallback(
    (ventureId: string) => {
      const config = INITIAL_VENTURES.find((v) => v.id === ventureId);
      const state = ventureStates[ventureId];
      if (!config || !state || state.count === 0) return 0;

      const { profitMult } = getVentureMultipliers(ventureId, state.count);
      return config.baseRevenue * state.count * profitMult;
    },
    [ventureStates, getVentureMultipliers]
  );

  const getVentureCycleTime = useCallback(
    (ventureId: string) => {
      const config = INITIAL_VENTURES.find((v) => v.id === ventureId);
      const state = ventureStates[ventureId];
      if (!config || !state) return 1;

      const { speedMult } = getVentureMultipliers(ventureId, state.count);
      return Math.max(0.05, config.baseTimeSec / speedMult);
    },
    [ventureStates, getVentureMultipliers]
  );

  // Total realm profit per second
  const totalRealmProfitPerSec = useMemo(() => {
    let sum = 0;
    INITIAL_VENTURES.forEach((v) => {
      const state = ventureStates[v.id];
      if (state && state.count > 0 && (state.managerHired || state.isRunning)) {
        const cycleTime = getVentureCycleTime(v.id);
        const profit = getVentureProfit(v.id);
        sum += profit / cycleTime;
      }
    });
    return sum;
  }, [ventureStates, getVentureProfit, getVentureCycleTime]);

  // Total effective profit per second (realm passive revenue + real-time active tapping revenue)
  const effectiveProfitPerSec = useMemo(() => {
    return totalRealmProfitPerSec + tapProfitPerSec;
  }, [totalRealmProfitPerSec, tapProfitPerSec]);

  // Pending Archons for next ascension
  const pendingArchons = useMemo(() => {
    const totalPotential = calculateArchonsFromGold(lifetimeGold);
    return Math.max(0, totalPotential - lifetimeArchons);
  }, [lifetimeGold, lifetimeArchons]);

  // Calculate Venture Cost for current BuyMode
  const getVentureCostForMode = useCallback(
    (ventureId: string) => {
      const config = INITIAL_VENTURES.find((v) => v.id === ventureId);
      const state = ventureStates[ventureId];
      if (!config || !state) return { count: 1, cost: 0, canAfford: false };

      const currentCount = state.count;

      if (buyMode === 'MAX') {
        const { count, cost } = calculateMaxAffordable(config.baseCost, config.costFactor, currentCount, gold);
        return { count, cost, canAfford: gold >= cost && count >= 1 };
      }

      if (buyMode === 'NEXT') {
        const needed = calculateNextMilestoneTarget(currentCount, config.milestones);
        const count = Math.max(1, needed);
        const cost = calculateVentureCost(config.baseCost, config.costFactor, currentCount, count);
        return { count, cost, canAfford: gold >= cost };
      }

      const count = parseInt(buyMode, 10) || 1;
      const cost = calculateVentureCost(config.baseCost, config.costFactor, currentCount, count);
      return { count, cost, canAfford: gold >= cost };
    },
    [buyMode, ventureStates, gold]
  );

  // Trigger floating text
  const spawnFloatingText = useCallback((text: string, x?: number, y?: number, color?: string) => {
    const id = nextFloatId.current++;
    const defaultX = typeof window !== 'undefined' ? window.innerWidth / 2 + (Math.random() * 80 - 40) : 200;
    const defaultY = typeof window !== 'undefined' ? window.innerHeight / 2 : 200;

    setFloatingTexts((prev) => [
      ...prev.slice(-15),
      {
        id,
        text,
        x: x ?? defaultX,
        y: y ?? defaultY,
        color: color ?? 'text-amber-300',
      },
    ]);

    setTimeout(() => {
      setFloatingTexts((prev) => prev.filter((item) => item.id !== id));
    }, 850);
  }, []);

  // Purchase Venture
  const buyVenture = useCallback(
    (ventureId: string) => {
      const { count, cost, canAfford } = getVentureCostForMode(ventureId);
      if (!canAfford) return;

      const config = INITIAL_VENTURES.find((v) => v.id === ventureId);
      if (!config) return;

      setGold((prev) => Math.max(0, prev - cost));
      setVentureStates((prev) => {
        const oldState = prev[ventureId] || { count: 0, managerHired: false, progress: 0, isRunning: false, lastRunStart: 0 };
        const newCount = oldState.count + count;

        // Check if crossed milestone
        config.milestones.forEach((m) => {
          if (oldState.count < m.count && newCount >= m.count) {
            sound.playMilestone();
            spawnFloatingText(`★ ${m.label}!`, undefined, undefined, 'text-yellow-300 font-bold text-base');
          }
        });

        return {
          ...prev,
          [ventureId]: {
            ...oldState,
            count: newCount,
          },
        };
      });

      sound.playBuy();
    },
    [getVentureCostForMode, spawnFloatingText]
  );

  // Start Manual Run
  const startVentureCycle = useCallback(
    (ventureId: string) => {
      const state = ventureStates[ventureId];
      if (!state || state.count === 0 || state.isRunning) return;

      setVentureStates((prev) => ({
        ...prev,
        [ventureId]: {
          ...prev[ventureId],
          isRunning: true,
          progress: 0,
          lastRunStart: Date.now(),
        },
      }));
      sound.playCoin();
    },
    [ventureStates]
  );

  // Hire Guildmaster Manager
  const hireManager = useCallback(
    (ventureId: string) => {
      const config = INITIAL_VENTURES.find((v) => v.id === ventureId);
      const state = ventureStates[ventureId];
      if (!config || !state || state.managerHired) return;

      if (gold < config.manager.cost) return;

      setGold((prev) => Math.max(0, prev - config.manager.cost));
      setVentureStates((prev) => ({
        ...prev,
        [ventureId]: {
          ...prev[ventureId],
          managerHired: true,
          isRunning: true,
        },
      }));

      sound.playManagerHire();
      spawnFloatingText(`Guildmaster ${config.manager.name} Hired!`, undefined, undefined, 'text-emerald-300 font-bold text-base');
    },
    [gold, ventureStates, spawnFloatingText]
  );

  // Buy Upgrade
  const buyUpgrade = useCallback(
    (upgradeId: string) => {
      const upg = upgrades.find((u) => u.id === upgradeId);
      if (!upg || upg.purchased) return;

      if (upg.currency === 'GOLD') {
        if (gold < upg.cost) return;
        setGold((prev) => Math.max(0, prev - upg.cost));
      } else {
        if (archons < upg.cost) return;
        setArchons((prev) => Math.max(0, prev - upg.cost));
        if (upg.type === 'ARCHON_POWER') {
          setArchonBoostPercent((prev) => prev + upg.multiplier);
        }
      }

      setUpgrades((prev) =>
        prev.map((u) => (u.id === upgradeId ? { ...u, purchased: true } : u))
      );

      sound.playMilestone();
      spawnFloatingText(`Relic Unlocked: ${upg.name}`, undefined, undefined, 'text-cyan-300 font-bold');
    },
    [upgrades, gold, archons, spawnFloatingText]
  );

  // Tap Arcane Orb (Supports single-click and multi-finger simultaneous touches)
  const clickOrb = useCallback(
    (input?: TapPoint[] | React.MouseEvent | TapPoint) => {
      let points: TapPoint[] = [];

      if (Array.isArray(input)) {
        points = input;
      } else if (input && 'clientX' in input && 'clientY' in input) {
        points = [{ clientX: input.clientX, clientY: input.clientY }];
      } else {
        const defaultX = typeof window !== 'undefined' ? window.innerWidth / 2 : 200;
        const defaultY = typeof window !== 'undefined' ? window.innerHeight / 2 : 200;
        points = [{ clientX: defaultX, clientY: defaultY }];
      }

      const tapCount = Math.max(1, points.length);
      const baseProfitPerSec = isFrenzyActive ? totalRealmProfitPerSec / 3 : totalRealmProfitPerSec;
      const baseTapGold = Math.max(1, Math.round(baseProfitPerSec * 0.02 + 1));
      const tapGold = isFrenzyActive ? baseTapGold * 3 : baseTapGold;
      const totalGoldAwarded = tapGold * tapCount;

      setGold((prev) => prev + totalGoldAwarded);
      setLifetimeGold((prev) => prev + totalGoldAwarded);
      setTotalClicks((prev) => prev + tapCount);

      // Record tap timestamp & reward for real-time tap rate calculations
      const now = Date.now();
      recentTapsRef.current.push({
        timestamp: now,
        count: tapCount,
        gold: totalGoldAwarded,
      });

      // Filter window within last 1000ms
      const cutoff = now - 1000;
      recentTapsRef.current = recentTapsRef.current.filter((t) => t.timestamp >= cutoff);
      const activeTaps = recentTapsRef.current.reduce((sum, t) => sum + t.count, 0);
      const activeGold = recentTapsRef.current.reduce((sum, t) => sum + t.gold, 0);
      setTapsPerSec(activeTaps);
      setTapProfitPerSec(activeGold);

      // Frenzy charging scaled by finger count (balanced to be moderately harder to achieve)
      setFrenzyMeter((prev) => {
        if (isFrenzyActive) return prev;
        const frenzyCharge = tapCount === 1 ? 1.8 : 1.8 + (tapCount - 1) * 1.1;
        const next = prev + frenzyCharge;
        if (next >= 100) {
          setIsFrenzyActive(true);
          setFrenzyTimeRemaining(12);
          sound.playFrenzy();
          spawnFloatingText('⚡ ARCANE OVERDRIVE! (3x Revenue & 3x Taps)', undefined, undefined, 'text-amber-300 font-bold text-lg');
          return 0;
        }
        return next;
      });

      if (tapCount > 1) {
        sound.playMultiTouch(tapCount);
      } else {
        sound.playOrbClick();
      }

      // Spawn individual floating spark numbers for each finger coordinate
      points.forEach((pt) => {
        spawnFloatingText(
          `+${tapGold}`,
          pt.clientX,
          pt.clientY - 20,
          isFrenzyActive ? 'text-amber-200 font-bold' : 'text-cyan-200 font-bold'
        );
      });

      // If multi-touch (2+ fingers), spawn bonus multi-touch feedback banner
      if (tapCount > 1) {
        const avgX = points.reduce((sum, p) => sum + p.clientX, 0) / tapCount;
        const avgY = points.reduce((sum, p) => sum + p.clientY, 0) / tapCount;
        spawnFloatingText(
          `⚡ ${tapCount}-FINGER COMBO (+${totalGoldAwarded})`,
          avgX,
          avgY - 45,
          'text-amber-300 font-black text-sm tracking-wide [text-shadow:0_2px_4px_rgba(0,0,0,0.85)]'
        );
      }
    },
    [totalRealmProfitPerSec, isFrenzyActive, spawnFloatingText]
  );

  // Ascend Realm (Rebirth / Prestige)
  const ascendRealm = useCallback(() => {
    if (pendingArchons <= 0) return;

    sound.playAscension();
    spawnFloatingText(`✦ CELESTIAL ASCENSION! +${pendingArchons} Archons`, undefined, undefined, 'text-amber-200 font-bold text-lg');

    const newArchons = archons + pendingArchons;
    const newLifetimeArchons = lifetimeArchons + pendingArchons;

    setArchons(newArchons);
    setLifetimeArchons(newLifetimeArchons);
    setAscensionsCount((prev) => prev + 1);

    // Reset mortal wealth and ventures, keep archon upgrades
    setGold(4);
    setVentureStates(() => {
      const fresh: Record<string, VentureState> = {};
      INITIAL_VENTURES.forEach((v, index) => {
        fresh[v.id] = {
          count: index === 0 ? 1 : 0,
          managerHired: false,
          progress: 0,
          isRunning: false,
          lastRunStart: 0,
        };
      });
      return fresh;
    });

    // Reset cash upgrades, keep Archon upgrades
    setUpgrades((prev) =>
      prev.map((u) => (u.currency === 'GOLD' ? { ...u, purchased: false } : u))
    );

    recentTapsRef.current = [];
    setTapsPerSec(0);
    setTapProfitPerSec(0);

    spawnFloatingText(`Ascended! +${pendingArchons} Celestial Archons`, undefined, undefined, 'text-yellow-300 font-bold text-lg');
  }, [pendingArchons, archons, lifetimeArchons, spawnFloatingText]);

  // Main High-Precision Game Loop
  const lastTickRef = useRef<number>(Date.now());
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      const dt = Math.min(10, Math.max(0.001, (now - lastTickRef.current) / 1000));
      lastTickRef.current = now;

      // Handle Frenzy Decay or Active Timer
      if (isFrenzyActive) {
        setFrenzyTimeRemaining((prev) => {
          const next = prev - dt;
          if (next <= 0) {
            setIsFrenzyActive(false);
            return 0;
          }
          return next;
        });
      } else {
        setFrenzyMeter((prev) => Math.max(0, prev - dt * 3.5));
      }

      let goldToAdd = 0;
      let shouldPlayManualFinishSound = false;

      setVentureStates((prevStates) => {
        const nextStates: Record<string, VentureState> = { ...prevStates };
        let stateChanged = false;

        INITIAL_VENTURES.forEach((config) => {
          const state = nextStates[config.id];
          if (!state || state.count === 0) return;

          const cycleTime = getVentureCycleTime(config.id);
          const profit = getVentureProfit(config.id);

          // Fast mode (cycle < 0.1s)
          if (cycleTime < 0.1) {
            if (state.managerHired) {
              const perSec = profit / cycleTime;
              goldToAdd += perSec * dt;
              if (state.progress !== 1 || !state.isRunning) {
                nextStates[config.id] = { ...state, progress: 1, isRunning: true };
                stateChanged = true;
              }
            } else if (state.isRunning) {
              // Single manual run finishes immediately
              goldToAdd += profit;
              shouldPlayManualFinishSound = true;
              nextStates[config.id] = { ...state, progress: 0, isRunning: false };
              stateChanged = true;
            }
          } else {
            // Standard cycle progress
            if (state.managerHired || state.isRunning) {
              const newProgress = state.progress + dt / cycleTime;
              if (newProgress >= 1) {
                if (state.managerHired) {
                  const cyclesFinished = Math.floor(newProgress);
                  const remainder = newProgress - cyclesFinished;
                  goldToAdd += profit * cyclesFinished;
                  nextStates[config.id] = {
                    ...state,
                    progress: remainder,
                    isRunning: true,
                  };
                } else {
                  // Single manual run completed
                  goldToAdd += profit;
                  shouldPlayManualFinishSound = true;
                  nextStates[config.id] = {
                    ...state,
                    progress: 0,
                    isRunning: false,
                  };
                }
                stateChanged = true;
              } else {
                nextStates[config.id] = {
                  ...state,
                  progress: newProgress,
                  isRunning: true,
                };
                stateChanged = true;
              }
            }
          }
        });

        return stateChanged ? nextStates : prevStates;
      });

      if (shouldPlayManualFinishSound) {
        sound.playCoin();
      }

      if (goldToAdd > 0) {
        setGold((prev) => prev + goldToAdd);
        setLifetimeGold((prev) => prev + goldToAdd);
      }

      // Update sliding-window tap rate and tap profit
      const tapNow = Date.now();
      const tapCutoff = tapNow - 1000;
      if (recentTapsRef.current.length > 0) {
        recentTapsRef.current = recentTapsRef.current.filter((t) => t.timestamp >= tapCutoff);
        const activeTaps = recentTapsRef.current.reduce((sum, t) => sum + t.count, 0);
        const activeGold = recentTapsRef.current.reduce((sum, t) => sum + t.gold, 0);
        setTapsPerSec((prev) => (prev !== activeTaps ? activeTaps : prev));
        setTapProfitPerSec((prev) => (prev !== activeGold ? activeGold : prev));
      } else {
        setTapsPerSec((prev) => (prev !== 0 ? 0 : prev));
        setTapProfitPerSec((prev) => (prev !== 0 ? 0 : prev));
      }
    }, 60);

    return () => clearInterval(interval);
  }, [getVentureCycleTime, getVentureProfit, isFrenzyActive]);

  // Check achievements periodically
  useEffect(() => {
    const currentState: GameSaveState = {
      gold,
      lifetimeGold,
      archons,
      lifetimeArchons,
      archonBoostPercent,
      ventures: ventureStates,
      purchasedUpgrades: upgrades.filter((u) => u.purchased).map((u) => u.id),
      unlockedAchievements: achievements.filter((a) => a.unlocked).map((a) => a.id),
      totalClicks,
      ascensionsCount,
      lastSavedTime: Date.now(),
      numberFormat,
      soundEnabled,
      soundVolume: sound.volume,
    };

    setAchievements((prev) => {
      let anyUnlocked = false;
      const updated = prev.map((ach) => {
        if (!ach.unlocked && ach.condition(currentState)) {
          anyUnlocked = true;
          sound.playMilestone();
          spawnFloatingText(`🏆 Achievement: ${ach.title}`, undefined, undefined, 'text-yellow-400 font-bold');
          return { ...ach, unlocked: true };
        }
        return ach;
      });
      return anyUnlocked ? updated : prev;
    });
  }, [gold, lifetimeGold, archons, ventureStates, totalClicks, ascensionsCount, upgrades, numberFormat, soundEnabled, archonBoostPercent, lifetimeArchons, spawnFloatingText]);

  // Ref to hold the freshest game state for immediate saving without effect-cancellation lag
  const latestStateRef = useRef<GameSaveState>({
    gold,
    lifetimeGold,
    archons,
    lifetimeArchons,
    archonBoostPercent,
    ventures: ventureStates,
    purchasedUpgrades: upgrades.filter((u) => u.purchased).map((u) => u.id),
    unlockedAchievements: achievements.filter((a) => a.unlocked).map((a) => a.id),
    totalClicks,
    ascensionsCount,
    lastSavedTime: Date.now(),
    numberFormat,
    soundEnabled,
    soundVolume: sound.volume,
    musicEnabled,
    musicVolume,
  });

  // Always keep latestStateRef synchronized with latest active state on every render
  useEffect(() => {
    latestStateRef.current = {
      gold,
      lifetimeGold,
      archons,
      lifetimeArchons,
      archonBoostPercent,
      ventures: ventureStates,
      purchasedUpgrades: upgrades.filter((u) => u.purchased).map((u) => u.id),
      unlockedAchievements: achievements.filter((a) => a.unlocked).map((a) => a.id),
      totalClicks,
      ascensionsCount,
      lastSavedTime: Date.now(),
      numberFormat,
      soundEnabled,
      soundVolume: sound.volume,
      musicEnabled,
      musicVolume,
    };
  });

  // Atomic storage persistence method (primary + secondary backup)
  const saveToStorage = useCallback(() => {
    try {
      const stateToSave: GameSaveState = {
        ...latestStateRef.current,
        lastSavedTime: Date.now(),
      };
      const serialized = JSON.stringify(stateToSave);
      localStorage.setItem(SAVE_KEY, serialized);
      localStorage.setItem(SAVE_BACKUP_KEY, serialized);
    } catch (e) {
      console.warn('Failed to persist game state to local storage', e);
    }
  }, []);

  // Calculate Offline Progress on Mount (using synchronously loaded initial data)
  useEffect(() => {
    if (!initialSave?.lastSavedTime) return;

    try {
      const offlineSeconds = Math.min(86400 * 3, Math.floor((Date.now() - initialSave.lastSavedTime) / 1000));
      if (offlineSeconds > 5) {
        let offlineRate = 0;
        const savedArchons = initialSave.archons || 0;
        const savedArchonBoost = initialSave.archonBoostPercent || 2;
        const totalArchonBoost = 1 + (savedArchons * savedArchonBoost) / 100;
        const loadedVentures = initialSave.ventures || {};
        const loadedPurchasedUpgrades = initialSave.purchasedUpgrades || [];

        INITIAL_VENTURES.forEach((v) => {
          const vState = loadedVentures[v.id];
          if (vState && vState.count > 0 && vState.managerHired) {
            let profitMult = 1;
            let speedMult = 1;

            v.milestones.forEach((m) => {
              if (vState.count >= m.count) {
                profitMult *= m.profitMultiplier;
                speedMult *= m.speedMultiplier;
              }
            });

            INITIAL_UPGRADES.forEach((u) => {
              if (loadedPurchasedUpgrades.includes(u.id)) {
                if (u.targetVentureId === v.id || u.targetVentureId === 'ALL') {
                  if (u.type === 'PROFIT') profitMult *= u.multiplier;
                  if (u.type === 'SPEED') speedMult *= u.multiplier;
                }
              }
            });

            profitMult *= totalArchonBoost;

            const cycleTime = Math.max(0.05, v.baseTimeSec / speedMult);
            const profit = v.baseRevenue * vState.count * profitMult;
            offlineRate += profit / cycleTime;
          }
        });

        const earned = Math.floor(offlineRate * offlineSeconds);
        if (earned > 0) {
          setGold((g) => g + earned);
          setLifetimeGold((lg) => lg + earned);
          setOfflineReport({
            secondsOffline: offlineSeconds,
            goldEarned: earned,
          });
          // Immediately persist offline progress
          setTimeout(() => saveToStorage(), 50);
        }
      }
    } catch (e) {
      console.warn('Failed to calculate offline earnings', e);
    }
  }, [initialSave, saveToStorage]);

  // Periodic Auto-Save: stable 1.5s interval that NEVER gets reset on every state tick
  useEffect(() => {
    const saveTimer = setInterval(() => {
      saveToStorage();
    }, 1500);

    return () => clearInterval(saveTimer);
  }, [saveToStorage]);

  // Mobile / Android Lifecycle Persistence Listeners
  // Catches when the app is closed, tab switched, phone locked, or task killed
  useEffect(() => {
    const handleImmediateSave = () => {
      saveToStorage();
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        saveToStorage();
      }
    };

    // Standard mobile visibility and lifecycle events
    document.addEventListener('visibilitychange', handleVisibilityChange, { capture: true });
    window.addEventListener('pagehide', handleImmediateSave, { capture: true });
    window.addEventListener('beforeunload', handleImmediateSave, { capture: true });
    window.addEventListener('freeze', handleImmediateSave, { capture: true });
    window.addEventListener('blur', handleImmediateSave);

    // Request persistent storage from Android browser so OS does not clear local data
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
      navigator.storage.persist().catch(() => {});
    }

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange, { capture: true });
      window.removeEventListener('pagehide', handleImmediateSave, { capture: true });
      window.removeEventListener('beforeunload', handleImmediateSave, { capture: true });
      window.removeEventListener('freeze', handleImmediateSave, { capture: true });
      window.removeEventListener('blur', handleImmediateSave);
    };
  }, [saveToStorage]);

  const resetAllProgress = useCallback(() => {
    localStorage.removeItem(SAVE_KEY);
    localStorage.removeItem(SAVE_BACKUP_KEY);
    setGold(4);
    setLifetimeGold(4);
    setArchons(0);
    setLifetimeArchons(0);
    setArchonBoostPercent(2);
    setAscensionsCount(0);
    setTotalClicks(0);
    setUpgrades(INITIAL_UPGRADES);
    setAchievements(INITIAL_ACHIEVEMENTS);
    const fresh: Record<string, VentureState> = {};
    INITIAL_VENTURES.forEach((v, index) => {
      fresh[v.id] = {
        count: index === 0 ? 1 : 0,
        managerHired: false,
        progress: 0,
        isRunning: false,
        lastRunStart: 0,
      };
    });
    setVentureStates(fresh);
    recentTapsRef.current = [];
    setTapsPerSec(0);
    setTapProfitPerSec(0);
    sound.playCoin();
  }, []);

  // Fetch custom icons & presets from backend API
  const refreshCustomIcons = useCallback(async () => {
    try {
      const res = await fetch('/api/icons');
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          if (data.icons) {
            setCustomIcons(data.icons);
            setVentureIcons(data.icons);
            if (typeof window !== 'undefined') {
              localStorage.setItem('realm_custom_icons_cache', JSON.stringify(data.icons));
            }
          }
          if (data.guildmasterIcons) {
            setGuildmasterIcons(data.guildmasterIcons);
            if (typeof window !== 'undefined') {
              localStorage.setItem('realm_gm_icons_cache', JSON.stringify(data.guildmasterIcons));
            }
          }
        }
        if (data.presets && Array.isArray(data.presets)) {
          setCustomPresets(data.presets);
        }
      }
    } catch (e) {
      console.warn('Could not connect to /api/icons backend:', e);
    }
  }, []);

  useEffect(() => {
    refreshCustomIcons();
  }, [refreshCustomIcons]);

  // Upload a .jpg portrait for a guildmaster to backend
  const uploadCustomIcon = useCallback(
    async (guildmasterId: string, fileOrBase64: File | string, name?: string) => {
      try {
        const uploadUrl = `/api/icons/upload?guildmasterId=${encodeURIComponent(guildmasterId)}`;
        let res: Response;
        if (typeof fileOrBase64 === 'string') {
          res = await fetch(uploadUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ guildmasterId, imageData: fileOrBase64, name }),
          });
        } else {
          const formData = new FormData();
          formData.append('guildmasterId', guildmasterId);
          if (name) formData.append('name', name);
          formData.append('image', fileOrBase64);
          res = await fetch(uploadUrl, {
            method: 'POST',
            body: formData,
          });
        }

        const data = await res.json();
        if (data.success && data.icon) {
          setGuildmasterIcons((prev) => {
            const updated = { ...prev, [guildmasterId]: data.icon };
            if (typeof window !== 'undefined') {
              localStorage.setItem('realm_gm_icons_cache', JSON.stringify(updated));
            }
            return updated;
          });
          sound.playMilestone();
          spawnFloatingText('✦ Guildmaster Portrait Installed!', undefined, undefined, 'text-emerald-300 font-bold');
          return { success: true };
        }
        return { success: false, error: data.error || 'Failed to upload guildmaster portrait' };
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Upload failed';
        return { success: false, error: msg };
      }
    },
    [spawnFloatingText]
  );

  // Apply bundled fantasy artwork .jpg preset to a guildmaster
  const applyPresetIcon = useCallback(
    async (guildmasterId: string, presetUrl: string, presetName?: string) => {
      try {
        const res = await fetch('/api/icons/preset', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ guildmasterId, presetUrl, presetName }),
        });
        const data = await res.json();
        if (data.success && data.icon) {
          setGuildmasterIcons((prev) => {
            const updated = { ...prev, [guildmasterId]: data.icon };
            if (typeof window !== 'undefined') {
              localStorage.setItem('realm_gm_icons_cache', JSON.stringify(updated));
            }
            return updated;
          });
          sound.playCoin();
          spawnFloatingText('✦ Guildmaster Portrait Set!', undefined, undefined, 'text-cyan-300 font-bold');
          return { success: true };
        }
        return { success: false, error: data.error || 'Failed to apply preset' };
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Preset application failed';
        return { success: false, error: msg };
      }
    },
    [spawnFloatingText]
  );

  // Remove custom portrait for a guildmaster and revert to default RPG art
  const removeCustomIcon = useCallback(
    async (guildmasterId: string) => {
      try {
        const res = await fetch(`/api/icons/${guildmasterId}?type=guildmaster`, { method: 'DELETE' });
        const data = await res.json();
        if (data.success) {
          setGuildmasterIcons((prev) => {
            const updated = { ...prev };
            delete updated[guildmasterId];
            if (typeof window !== 'undefined') {
              localStorage.setItem('realm_gm_icons_cache', JSON.stringify(updated));
            }
            return updated;
          });
          sound.playCoin();
          spawnFloatingText('Reverted to Default Portrait', undefined, undefined, 'text-amber-300 font-bold');
          return { success: true };
        }
        return { success: false, error: data.error || 'Failed to reset portrait' };
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Reset failed';
        return { success: false, error: msg };
      }
    },
    [spawnFloatingText]
  );

  // Reset ALL custom guildmaster portraits back to default (preserves saved venture icons!)
  const resetAllCustomIcons = useCallback(async () => {
    try {
      const res = await fetch('/api/icons?type=guildmaster', { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setGuildmasterIcons({});
        if (typeof window !== 'undefined') {
          localStorage.removeItem('realm_gm_icons_cache');
        }
        sound.playCoin();
        spawnFloatingText('All Guildmaster Portraits Reverted to Default', undefined, undefined, 'text-amber-300 font-bold');
        return { success: true };
      }
      return { success: false, error: data.error || 'Failed to reset portraits' };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Reset failed';
      return { success: false, error: msg };
    }
  }, [spawnFloatingText]);

  const exportSaveString = useCallback(() => {
    const state: GameSaveState = {
      gold,
      lifetimeGold,
      archons,
      lifetimeArchons,
      archonBoostPercent,
      ventures: ventureStates,
      purchasedUpgrades: upgrades.filter((u) => u.purchased).map((u) => u.id),
      unlockedAchievements: achievements.filter((a) => a.unlocked).map((a) => a.id),
      totalClicks,
      ascensionsCount,
      lastSavedTime: Date.now(),
      numberFormat,
      soundEnabled,
      soundVolume: sound.volume,
      musicEnabled,
      musicVolume,
    };
    return btoa(JSON.stringify(state));
  }, [
    gold,
    lifetimeGold,
    archons,
    lifetimeArchons,
    archonBoostPercent,
    ventureStates,
    upgrades,
    achievements,
    totalClicks,
    ascensionsCount,
    numberFormat,
    soundEnabled,
    musicEnabled,
    musicVolume,
  ]);

  const importSaveString = useCallback((b64: string): boolean => {
    try {
      const decoded = atob(b64.trim());
      const data: GameSaveState = JSON.parse(decoded);
      if (data.gold !== undefined) setGold(data.gold);
      if (data.lifetimeGold !== undefined) setLifetimeGold(data.lifetimeGold);
      if (data.archons !== undefined) setArchons(data.archons);
      if (data.lifetimeArchons !== undefined) setLifetimeArchons(data.lifetimeArchons);
      if (data.archonBoostPercent !== undefined) setArchonBoostPercent(data.archonBoostPercent);
      if (data.totalClicks !== undefined) setTotalClicks(data.totalClicks);
      if (data.ascensionsCount !== undefined) setAscensionsCount(data.ascensionsCount);
      if (data.numberFormat) setNumberFormat(data.numberFormat);
      if (data.soundEnabled !== undefined) setSoundEnabled(data.soundEnabled);
      if (data.musicEnabled !== undefined) setMusicEnabled(data.musicEnabled);
      if (data.musicVolume !== undefined) setMusicVolume(data.musicVolume);
      if (data.ventures) setVentureStates(data.ventures);
      if (data.purchasedUpgrades) {
        setUpgrades((prev) =>
          prev.map((u) => ({ ...u, purchased: data.purchasedUpgrades!.includes(u.id) }))
        );
      }
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
      localStorage.setItem(SAVE_BACKUP_KEY, JSON.stringify(data));
      return true;
    } catch {
      return false;
    }
  }, []);

  const audioValue = useMemo<AudioContextType>(
    () => ({
      soundEnabled,
      setSoundEnabled,
      musicEnabled,
      setMusicEnabled,
      musicVolume,
      setMusicVolume,
      toggleMusic,
    }),
    [soundEnabled, musicEnabled, musicVolume, toggleMusic]
  );

  return (
    <AudioContext.Provider value={audioValue}>
      <GameContext.Provider
        value={{
          gold,
          lifetimeGold,
          archons,
          lifetimeArchons,
          archonBoostPercent,
          pendingArchons,
          ventures: INITIAL_VENTURES,
          ventureStates,
          getVentureProfit,
          getVentureCycleTime,
          getVentureCostForMode,
          buyVenture,
          startVentureCycle,
          hireManager,
          upgrades,
          buyUpgrade,
          ascendRealm,
          ascensionsCount,
          clickOrb,
          totalClicks,
          frenzyMeter,
          isFrenzyActive,
          frenzyTimeRemaining,
          buyMode,
          setBuyMode,
          floatingTexts,
          achievements,
          offlineReport,
          dismissOfflineReport: () => setOfflineReport(null),
          numberFormat,
          setNumberFormat,
          soundEnabled,
          setSoundEnabled,
          musicEnabled,
          setMusicEnabled,
          musicVolume,
          setMusicVolume,
          toggleMusic,
          totalRealmProfitPerSec,
          effectiveProfitPerSec,
          tapsPerSec,
          tapProfitPerSec,
          resetAllProgress,
          exportSaveString,
          importSaveString,
          customIcons,
          ventureIcons,
          guildmasterIcons,
          customPresets,
          uploadCustomIcon,
          applyPresetIcon,
          removeCustomIcon,
          resetAllCustomIcons,
          refreshCustomIcons,
        }}
      >
        {children}
      </GameContext.Provider>
    </AudioContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
}
