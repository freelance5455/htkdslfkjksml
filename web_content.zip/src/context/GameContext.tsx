import React, { createContext, useContext, useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { PlayerState, AvatarConfig, Badge } from '../types/game';
import { BADGES, LEVELS, SHOP_ITEMS, getLevelInfo } from '../data/rewards';
import { sound } from '../utils/sound';

interface GameContextType {
  state: PlayerState;
  addXp: (amount: number, reason?: string) => void;
  addCoins: (amount: number) => void;
  recordAnswer: (isCorrect: boolean, baseMultiplier?: number) => { xpEarned: number; coinsEarned: number };
  unlockBadge: (badgeId: string) => boolean;
  purchaseItem: (itemId: string) => boolean;
  usePowerup: (powerupId: string) => boolean;
  updateAvatar: (avatar: Partial<AvatarConfig>) => void;
  completeQuest: (questId: string) => void;
  updateBlitzScore: (score: number) => void;
  resetProgress: () => void;
  newBadgeUnlocked: Badge | null;
  clearNewBadge: () => void;
  isMuted: boolean;
  toggleMute: () => void;
}

const STORAGE_KEY = 'nutriquest_teen_save_v1';

const INITIAL_AVATAR: AvatarConfig = {
  gender: 'teen_neutral',
  skinTone: '#fcd34d',
  hairStyle: 'curls',
  headwear: 'none',
  outfit: 'hoodie',
  expression: 'happy',
};

const INITIAL_STATE: PlayerState = {
  xp: 0,
  level: 1,
  coins: 100, // starting bonus coins
  streak: 0,
  badges: ['first_quest'],
  unlockedLevels: ['level_intro', 'level_veg', 'level_fruit', 'level_grain', 'level_protein', 'level_dairy', 'level_boss'],
  inventory: {
    powerup_5050: 1, // starter free lifelines
    powerup_freeze: 1,
  },
  avatar: INITIAL_AVATAR,
  stats: {
    totalQuestionsAnswered: 0,
    correctAnswers: 0,
    blitzHighScore: 0,
    platesBuilt: 0,
    questsCompleted: 0,
    dailyStreak: 1,
    lastPlayedDate: new Date().toISOString().split('T')[0],
  },
};

const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<PlayerState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_STATE,
          ...parsed,
          stats: { ...INITIAL_STATE.stats, ...parsed.stats },
          inventory: { ...INITIAL_STATE.inventory, ...parsed.inventory },
        };
      }
    } catch {
      // fallback
    }
    return INITIAL_STATE;
  });

  const [newBadgeUnlocked, setNewBadgeUnlocked] = useState<Badge | null>(null);
  const [isMuted, setIsMuted] = useState(sound.getMuted());

  // Save on changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // ignore quota errors
    }
  }, [state]);

  const toggleMute = () => {
    const val = sound.toggleMute();
    setIsMuted(val);
  };

  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.65 },
        colors: ['#10b981', '#f43f5e', '#f59e0b', '#8b5cf6', '#0ea5e9'],
      });
    } catch {
      // safe fallback
    }
  };

  const unlockBadge = (badgeId: string): boolean => {
    if (state.badges.includes(badgeId)) return false;
    const badge = BADGES.find((b) => b.id === badgeId);
    if (!badge) return false;

    setState((prev) => ({
      ...prev,
      badges: [...prev.badges, badgeId],
      coins: prev.coins + 50, // reward for badge
    }));

    setNewBadgeUnlocked(badge);
    sound.playLevelUp();
    triggerConfetti();
    return true;
  };

  const addXp = (amount: number) => {
    setState((prev) => {
      const newXp = prev.xp + amount;
      const { currentLevel } = getLevelInfo(newXp);
      const leveledUp = currentLevel.level > prev.level;

      if (leveledUp) {
        sound.playLevelUp();
        triggerConfetti();
        if (currentLevel.level >= 5) {
          unlockBadge('nutri_legend');
        }
      }

      return {
        ...prev,
        xp: newXp,
        level: currentLevel.level,
        coins: leveledUp ? prev.coins + currentLevel.rewardCoins : prev.coins,
      };
    });
  };

  const addCoins = (amount: number) => {
    sound.playCoin();
    setState((prev) => ({
      ...prev,
      coins: prev.coins + amount,
    }));
  };

  const recordAnswer = (isCorrect: boolean, baseMultiplier = 1) => {
    let xpEarned = 0;
    let coinsEarned = 0;

    setState((prev) => {
      const newStreak = isCorrect ? prev.streak + 1 : 0;
      const streakMultiplier = isCorrect ? Math.min(2.5, 1 + newStreak * 0.15) : 1;

      if (isCorrect) {
        sound.playCorrect();
        xpEarned = Math.round(50 * baseMultiplier * streakMultiplier);
        coinsEarned = Math.round(15 * streakMultiplier);
      } else {
        sound.playWrong();
        xpEarned = 5; // small consolation XP for trying
        coinsEarned = 0;
      }

      const totalAnswered = prev.stats.totalQuestionsAnswered + 1;
      const totalCorrect = prev.stats.correctAnswers + (isCorrect ? 1 : 0);

      // Check for streak badge
      if (newStreak >= 5) {
        setTimeout(() => unlockBadge('streak_master'), 600);
      }

      const updatedXp = prev.xp + xpEarned;
      const { currentLevel } = getLevelInfo(updatedXp);
      if (currentLevel.level > prev.level) {
        sound.playLevelUp();
        triggerConfetti();
      }

      return {
        ...prev,
        xp: updatedXp,
        level: currentLevel.level,
        coins: prev.coins + coinsEarned,
        streak: newStreak,
        stats: {
          ...prev.stats,
          totalQuestionsAnswered: totalAnswered,
          correctAnswers: totalCorrect,
        },
      };
    });

    return { xpEarned, coinsEarned };
  };

  const purchaseItem = (itemId: string): boolean => {
    const item = SHOP_ITEMS.find((i) => i.id === itemId);
    if (!item) return false;
    if (state.coins < item.price) return false;

    setState((prev) => {
      const currentQty = prev.inventory[itemId] || 0;
      return {
        ...prev,
        coins: prev.coins - item.price,
        inventory: {
          ...prev.inventory,
          [itemId]: currentQty + 1,
        },
      };
    });

    sound.playCoin();
    return true;
  };

  const usePowerup = (powerupId: string): boolean => {
    const currentQty = state.inventory[powerupId] || 0;
    if (currentQty <= 0) return false;

    setState((prev) => ({
      ...prev,
      inventory: {
        ...prev.inventory,
        [powerupId]: prev.inventory[powerupId] - 1,
      },
    }));
    sound.playTap();
    return true;
  };

  const updateAvatar = (partial: Partial<AvatarConfig>) => {
    setState((prev) => ({
      ...prev,
      avatar: { ...prev.avatar, ...partial },
    }));
    sound.playTap();
  };

  const completeQuest = (questId: string) => {
    setState((prev) => {
      const questsCompleted = prev.stats.questsCompleted + 1;
      return {
        ...prev,
        stats: {
          ...prev.stats,
          questsCompleted,
        },
      };
    });
  };

  const updateBlitzScore = (score: number) => {
    if (score >= 500) {
      unlockBadge('blitz_champion');
    }
    setState((prev) => ({
      ...prev,
      stats: {
        ...prev.stats,
        blitzHighScore: Math.max(prev.stats.blitzHighScore, score),
      },
    }));
  };

  const resetProgress = () => {
    localStorage.removeItem(STORAGE_KEY);
    setState(INITIAL_STATE);
  };

  const clearNewBadge = () => {
    setNewBadgeUnlocked(null);
  };

  return (
    <GameContext.Provider
      value={{
        state,
        addXp,
        addCoins,
        recordAnswer,
        unlockBadge,
        purchaseItem,
        usePowerup,
        updateAvatar,
        completeQuest,
        updateBlitzScore,
        resetProgress,
        newBadgeUnlocked,
        clearNewBadge,
        isMuted,
        toggleMute,
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const ctx = useContext(GameContext);
  if (!ctx) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return ctx;
};
