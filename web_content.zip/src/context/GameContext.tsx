import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import type {
  PlayerStats,
  SoilPlot,
  AnimalPen,
  AquaticTank,
  OrchardSlot,
  BeeHive,
  ActiveCraftBatch,
  MerchantShip,
  InventoryItem,
  OfflineReport,
  ZoneId,
  WeatherType,
  TimeOfDay,
  Tier,
} from '../types/game.ts';
import { ALL_SPECIES, SPECIES_MAP, BEE_SPECIES_DATA } from '../data/species.ts';
import { ALL_RECIPES, RECIPES_MAP } from '../data/recipes.ts';
import {
  addExperience,
  getRequiredExp,
  calculateAnimalHarvest,
  calculateAquaticHarvest,
  getTimeOfDayFromHour,
  getBeeGachaRate,
  getBatchCraftWaitTime,
  getAnimalSellPrice,
  getButlerPerks,
} from '../utils/gameLogic.ts';
import confetti from 'canvas-confetti';

const STORAGE_KEY = 'PIXEL_FARM_RPG_SAVE_V1';

export interface GameContextType {
  player: PlayerStats;
  plots: SoilPlot[];
  animalPens: Record<string, AnimalPen>;
  aquaticTanks: Record<string, AquaticTank>;
  orchardSlots: OrchardSlot[];
  beeHives: BeeHive[];
  activeCraftBatches: ActiveCraftBatch[];
  merchantShip: MerchantShip;
  inventory: InventoryItem[];
  activeZone: ZoneId;
  navCollapsed: boolean;
  shovelModeActive: boolean;
  offlineReport: OfflineReport | null;
  levelUpData: { oldLevel: number; newLevel: number; unlocks: string[] } | null;
  notificationBadges: Record<ZoneId, boolean>;
  setActiveZone: (zone: ZoneId) => void;
  setNavCollapsed: (collapsed: boolean | ((prev: boolean) => boolean)) => void;
  setShovelModeActive: (active: boolean | ((prev: boolean) => boolean)) => void;
  closeLevelUpModal: () => void;
  closeOfflineReport: () => void;
  // Inventory actions
  addItemToInventory: (itemId: string, name: string, icon: string, tier: Tier, count: number, tab: 1 | 2 | 3 | 4 | 5 | 6, sellPrice: number, isGolden?: boolean) => void;
  removeItemFromInventory: (itemId: string, count: number) => boolean;
  toggleItemLock: (itemId: string) => void;
  toggleKeepTenUnits: () => void;
  bulkSellCategory: (categoryTab: 1 | 2 | 3 | 4 | 5 | 6) => { countSold: number; goldEarned: number };
  sellSingleItem: (itemId: string, count: number) => boolean;
  // Zone 1 - Field
  unlockNextPlot: () => boolean;
  tillPlot: (plotId: number) => void;
  tillAllPlots: () => void;
  waterPlot: (plotId: number) => void;
  waterAllPlots: () => void;
  fertilizePlot: (plotId: number, type: 'organic' | 'growth' | 'crystal') => boolean;
  fertilizeAllQuick: () => void;
  plantPlot: (plotId: number, speciesId: string) => boolean;
  harvestPlot: (plotId: number) => void;
  harvestAllPlots: () => void;
  shovelPlot: (plotId: number) => void;
  // Zone 2 - Coop
  feedAnimal: (speciesId: string, feedType: 'basic' | 'premium') => boolean;
  petAnimal: (speciesId: string) => void;
  harvestAnimal: (speciesId: string) => void;
  toggleAnimalButler: (speciesId: string) => void;
  sellAnimal: (speciesId: string, count: number) => void;
  buyAnimal: (speciesId: string) => boolean;
  // Zone 3 - Aquatic
  feedAquatic: (speciesId: string, feedType: 'basic' | 'favorite') => boolean;
  harvestAquatic: (speciesId: string) => void;
  sellAquatic: (speciesId: string, count: number) => void;
  buyAquatic: (speciesId: string) => boolean;
  toggleAquaticAerator: () => void;
  cleanAquaticFilter: () => void;
  collectMineralMud: () => void;
  // Zone 4 - Orchard & Bees
  plantFruitTreeOrMushroom: (slotId: number, speciesId: string) => boolean;
  harvestOrchardSlot: (slotId: number) => void;
  shovelOrchardSlot: (slotId: number) => void;
  graftTreeOrMushroom: (species1Id: string, species2Id: string) => { success: boolean; resultSpeciesId?: string };
  harvestBeeHive: (hiveId: number) => void;
  breedBeeGacha: (beeSpeciesId: string, flowerItemId: string) => { success: boolean; newBeeId?: string; pity: number };
  // Zone 5 - Breeding Lab
  synthesizeMutation: (speciesId: string) => boolean;
  // Zone 6 - Workshop
  startCraftBatch: (recipeId: string, quantity: number) => boolean;
  claimCraftBatch: (batchId: string) => void;
  // Zone 7 - Port
  buyStoreItem: (itemId: string, count: number, priceEach: number) => boolean;
  fulfillMerchantOrder: (orderId: string) => boolean;
  claimShipFormula: () => void;
  // Settings & Storage
  setTimeSpeed: (speed: 1 | 2 | 5 | 10) => void;
  toggleRealtimeSync: () => void;
  exportSaveToJson: () => void;
  importSaveFromJson: (jsonStr: string) => boolean;
  resetGameData: () => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

// Initial state generators
function createInitialPlots(): SoilPlot[] {
  const plots: SoilPlot[] = [];
  for (let i = 0; i < 50; i++) {
    plots.push({
      id: i,
      unlocked: i < 10, // First 10 unlocked
      tilled: false,
      watered: false,
      fertilizerType: 'none',
      plantedSpeciesId: null,
      plantedAt: null,
      readyAt: null,
      stage: 0,
    });
  }
  return plots;
}

function createInitialPlayer(): PlayerStats {
  const now = Date.now();
  const hour = new Date().getHours();
  return {
    level: 1,
    currentExp: 0,
    gold: 500,
    jade: 10,
    timeSpeed: 1,
    isRealtimeSync: true,
    keepTenUnitsActive: true,
    simulatedTimeMs: now,
    weather: 'sunny',
    timeOfDay: getTimeOfDayFromHour(hour),
    lastSavedTimestamp: now,
    unlockedRecipes: ['feed_poultry', 'feed_herbivore', 'feed_aquatic_basic', 'fert_organic_super', 'bakery_1', 'juice_1'],
    speciesMastery: {},
    beeGachaPityCount: 0,
    aquaticAeratorOn: true,
    aquaticFilterDurability: 100,
    aquaticMineralMudReady: 0,
    claimedAlmanacMilestones: [],
  };
}

function createInitialInventory(): InventoryItem[] {
  return [
    {
      id: 'rice',
      name: 'Hạt Giống Lúa Nước',
      categoryTab: 1,
      tier: 1,
      icon: '🌾',
      count: 5,
      locked: false,
      sellPrice: 10,
    },
    {
      id: 'tomato',
      name: 'Hạt Giống Cà Chua',
      categoryTab: 1,
      tier: 1,
      icon: '🍅',
      count: 5,
      locked: false,
      sellPrice: 12,
    },
    {
      id: 'thức_ăn_gia_cầm',
      name: 'Thức Ăn Gia Cầm Cơ Bản',
      categoryTab: 6,
      tier: 1,
      icon: '🥣',
      count: 5,
      locked: true,
      sellPrice: 15,
    },
  ];
}

function createInitialAnimalPens(): Record<string, AnimalPen> {
  // Starts with 1 Chuồng Gà Ta with 2/10 Gà Ta inside!
  return {
    chicken: {
      speciesId: 'chicken',
      count: 2,
      hunger: 0,
      satisfaction: 0,
      affection: 10,
      isPetToday: false,
      startedProducingAt: null,
      readyAt: null,
      butlerActive: false,
    },
  };
}

function createInitialOrchardSlots(): OrchardSlot[] {
  const slots: OrchardSlot[] = [];
  for (let i = 0; i < 8; i++) {
    slots.push({
      id: i,
      type: i < 4 ? 'fruit_tree' : 'mushroom',
      speciesId: null,
      plantedAt: null,
      readyAt: null,
      isRipe: false,
    });
  }
  return slots;
}

function createInitialMerchantShip(playerLevel: number): MerchantShip {
  const now = Date.now();
  return {
    docked: playerLevel >= 5,
    arrivedAt: now,
    leavesAt: now + 3600 * 4 * 1000, // 4 hours
    nextArrivalAt: now + 3600 * 5 * 1000,
    orders: [
      {
        id: 'ord_1',
        itemId: 'prod_rice',
        itemName: 'Lúa Nước',
        itemIcon: '🌾',
        countRequired: 6,
        rewardGold: 280,
        rewardJade: 2,
        rewardExpRatio: 0.1,
        fulfilled: false,
      },
      {
        id: 'ord_2',
        itemId: 'prod_chicken',
        itemName: 'Trứng Gà Tươi',
        itemIcon: '🥚',
        countRequired: 4,
        rewardGold: 320,
        rewardJade: 2,
        rewardExpRatio: 0.12,
        fulfilled: false,
      },
    ],
    droppedFormulaId: null,
    formulaClaimed: false,
  };
}

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [player, setPlayer] = useState<PlayerStats>(createInitialPlayer);
  const [plots, setPlots] = useState<SoilPlot[]>(createInitialPlots);
  const [animalPens, setAnimalPens] = useState<Record<string, AnimalPen>>(createInitialAnimalPens);
  const [aquaticTanks, setAquaticTanks] = useState<Record<string, AquaticTank>>({});
  const [orchardSlots, setOrchardSlots] = useState<OrchardSlot[]>(createInitialOrchardSlots);
  const [beeHives, setBeeHives] = useState<BeeHive[]>([]);
  const [activeCraftBatches, setActiveCraftBatches] = useState<ActiveCraftBatch[]>([]);
  const [merchantShip, setMerchantShip] = useState<MerchantShip>(() => createInitialMerchantShip(1));
  const [inventory, setInventory] = useState<InventoryItem[]>(createInitialInventory);

  const [activeZone, setActiveZone] = useState<ZoneId>(1);
  const [navCollapsed, setNavCollapsed] = useState<boolean>(false);
  const [shovelModeActive, setShovelModeActive] = useState<boolean>(false);
  const [offlineReport, setOfflineReport] = useState<OfflineReport | null>(null);
  const [levelUpData, setLevelUpData] = useState<{ oldLevel: number; newLevel: number; unlocks: string[] } | null>(null);

  const playerRef = useRef(player);
  playerRef.current = player;
  const plotsRef = useRef(plots);
  plotsRef.current = plots;
  const animalPensRef = useRef(animalPens);
  animalPensRef.current = animalPens;
  const aquaticTanksRef = useRef(aquaticTanks);
  aquaticTanksRef.current = aquaticTanks;
  const orchardSlotsRef = useRef(orchardSlots);
  orchardSlotsRef.current = orchardSlots;
  const beeHivesRef = useRef(beeHives);
  beeHivesRef.current = beeHives;
  const activeCraftBatchesRef = useRef(activeCraftBatches);
  activeCraftBatchesRef.current = activeCraftBatches;
  const inventoryRef = useRef(inventory);
  inventoryRef.current = inventory;

  // Load save on mount
  useEffect(() => {
    try {
      const savedStr = localStorage.getItem(STORAGE_KEY);
      if (savedStr) {
        const data = JSON.parse(savedStr);
        if (data.player) setPlayer(data.player);
        if (data.plots) setPlots(data.plots);
        if (data.animalPens) setAnimalPens(data.animalPens);
        if (data.aquaticTanks) setAquaticTanks(data.aquaticTanks);
        if (data.orchardSlots) setOrchardSlots(data.orchardSlots);
        if (data.beeHives) setBeeHives(data.beeHives);
        if (data.activeCraftBatches) setActiveCraftBatches(data.activeCraftBatches);
        if (data.merchantShip) setMerchantShip(data.merchantShip);
        if (data.inventory) setInventory(data.inventory);

        // Calculate offline progress
        const now = Date.now();
        const diffSeconds = Math.floor((now - (data.player.lastSavedTimestamp || now)) / 1000);
        if (diffSeconds > 10) {
          processOfflineProgress(diffSeconds, data);
        }
      }
    } catch (e) {
      console.warn('Failed to load save from localStorage', e);
    }
  }, []);

  // Auto-save every 5 seconds & on visibilitychange
  useEffect(() => {
    const saveToLocalStorage = () => {
      try {
        const fullSave = {
          player: { ...playerRef.current, lastSavedTimestamp: Date.now() },
          plots: plotsRef.current,
          animalPens: animalPensRef.current,
          aquaticTanks: aquaticTanksRef.current,
          orchardSlots: orchardSlotsRef.current,
          beeHives: beeHivesRef.current,
          activeCraftBatches: activeCraftBatchesRef.current,
          merchantShip,
          inventory: inventoryRef.current,
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(fullSave));
      } catch (e) {
        console.error('Error auto-saving', e);
      }
    };

    const interval = setInterval(saveToLocalStorage, 5000);

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        saveToLocalStorage();
      }
    };
    window.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearInterval(interval);
      window.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [merchantShip]);

  // Game clock, weather and simulation loop (runs every 1 second)
  useEffect(() => {
    const simInterval = setInterval(() => {
      const p = playerRef.current;
      const speed = p.timeSpeed || 1;
      const simulatedDeltaMs = 1000 * speed;
      const newSimTime = p.simulatedTimeMs + simulatedDeltaMs;

      // Update time of day
      const dateObj = p.isRealtimeSync ? new Date() : new Date(newSimTime);
      const hour = dateObj.getHours();
      const currentTod = getTimeOfDayFromHour(hour);

      // Random weather change roughly every 5-10 minutes of simulated time
      let newWeather = p.weather;
      if (Math.random() < 0.003 * speed) {
        const weathers: WeatherType[] = ['sunny', 'sunny', 'rainy', 'foggy', 'stormy', 'rainbow'];
        newWeather = weathers[Math.floor(Math.random() * weathers.length)];
      }

      setPlayer((prev) => ({
        ...prev,
        simulatedTimeMs: newSimTime,
        timeOfDay: currentTod,
        weather: newWeather,
      }));

      // Rain auto-watering logic
      if (newWeather === 'rainy' || newWeather === 'stormy') {
        setPlots((prev) =>
          prev.map((pl) => (pl.unlocked && pl.tilled && !pl.watered ? { ...pl, watered: true } : pl))
        );
      }

      // Check Pet Butlers
      handleButlerTick(newSimTime, speed);

      // Filter durability check for Aquatic
      if (p.level >= 8 && p.aquaticAeratorOn) {
        const drain = newWeather === 'foggy' ? 0.08 : 0.04;
        setPlayer((prev) => {
          const nextDurability = Math.max(0, prev.aquaticFilterDurability - drain * speed);
          const newMud = prev.aquaticFilterDurability > 0 && Math.random() < 0.02 * speed ? prev.aquaticMineralMudReady + 1 : prev.aquaticMineralMudReady;
          return {
            ...prev,
            aquaticFilterDurability: nextDurability,
            aquaticMineralMudReady: newMud,
          };
        });
      }
    }, 1000);

    return () => clearInterval(simInterval);
  }, []);

  // Offline calculation
  const processOfflineProgress = (awaySeconds: number, savedData: any) => {
    let cropsGrown = 0;
    let animalsReady = 0;
    let aquaticsReady = 0;
    let craftsCompleted = 0;
    let expGained = 0;
    let goldGained = 0;
    const notes: string[] = [];

    const now = Date.now();

    // Check plots
    const updatedPlots = (savedData.plots || []).map((pl: SoilPlot) => {
      if (pl.plantedSpeciesId && pl.readyAt && pl.readyAt <= now) {
        cropsGrown++;
      }
      return pl;
    });

    // Check animal pens
    const updatedPens = { ...(savedData.animalPens || {}) };
    for (const key in updatedPens) {
      const pen: AnimalPen = updatedPens[key];
      if (pen.readyAt && pen.readyAt <= now) {
        animalsReady++;
      }
    }

    // Check craft batches
    const updatedBatches = (savedData.activeCraftBatches || []).filter((b: ActiveCraftBatch) => {
      if (b.finishAt <= now) {
        craftsCompleted++;
        expGained += b.expTotal;
        return false;
      }
      return true;
    });

    if (cropsGrown > 0) notes.push(`${cropsGrown} ô đất nông sản đã chín rộ sẵn sàng thu hoạch.`);
    if (animalsReady > 0) notes.push(`${animalsReady} chuồng thú đã tạo xong sản phẩm tươi mới.`);
    if (craftsCompleted > 0) notes.push(`${craftsCompleted} mẻ chế biến đã hoàn tất tại xưởng.`);

    notes.push(`Thời gian vắng mặt: ${Math.round(awaySeconds / 60)} phút`);

    // Add safe exp
    if (expGained > 0) {
      applyExpGained(expGained, false);
    }

    setOfflineReport({
      awaySeconds,
      cropsGrown,
      animalsReady,
      aquaticsReady,
      orchardHarvests: 0,
      craftsCompleted,
      butlerHarvests: 0,
      expGained,
      goldGained,
      notes,
    });
  };

  // Safe EXP gain applying anti-level-skip rules
  const applyExpGained = (rawGainedExp: number, isSingleHarvest = false) => {
    setPlayer((prev) => {
      const result = addExperience(prev.level, prev.currentExp, rawGainedExp, isSingleHarvest);
      if (result.leveledUp) {
        handleLevelUpRewards(prev.level, result.newLevel);
      }
      return {
        ...prev,
        level: result.newLevel,
        currentExp: result.newExp,
      };
    });
  };

  const handleLevelUpRewards = (oldLevel: number, newLevel: number) => {
    try {
      confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    } catch (e) {}

    const unlocks: string[] = [];
    if (newLevel === 3) {
      unlocks.push('Mở khóa Khu 6: Xưởng Chế Biến Thủ Công & Tháp Phân Bón');
    }
    if (newLevel === 5) {
      unlocks.push('Mở khóa Khu 4: Vườn Quả, Rừng Nấm & 10 Loài Ong Mật');
      unlocks.push('Mở khóa Bến Tàu Buôn tại Khu 7 (Thương Cảng)');
      // Grant starter fruit tree, mushroom, and bee
      grantZone4Starters();
    }
    if (newLevel === 8) {
      unlocks.push('Mở khóa Khu 3: Hồ Thủy Sinh & Đầm Sen (3 vùng nước)');
    }
    if (newLevel === 12) {
      unlocks.push('Mở khóa Khu 5: Nhà Kính Sinh Học & Trung Tâm Lai Gen (Bậc 4 Thần Thoại)');
      unlocks.push('Mở khóa Dây chuyền chế biến Đặc Biệt tại Khu 6');
    }
    if (newLevel === 25) {
      unlocks.push('Nâng cấp tối đa Khu 5: Lai Tạo Bậc 5 Vũ Trụ');
      unlocks.push('Mở khóa toàn bộ công suất Dây chuyền Đặc Biệt');
    }

    setLevelUpData({
      oldLevel,
      newLevel,
      unlocks,
    });
  };

  const grantZone4Starters = () => {
    // 1 Apple tree, 1 Straw mushroom, 1 Beehive with Grass Honeybee
    setOrchardSlots((prev) => [
      { id: 0, type: 'fruit_tree', speciesId: 'tree_apple', plantedAt: Date.now(), readyAt: Date.now() + 40000, isRipe: false },
      { id: 1, type: 'mushroom', speciesId: 'mush_straw', plantedAt: Date.now(), readyAt: Date.now() + 35000, isRipe: false },
      ...prev.slice(2),
    ]);
    setBeeHives([
      { id: 1, beeSpeciesId: 'bee_grass', startedProducingAt: Date.now(), readyAt: Date.now() + 40000, isReady: false },
    ]);
  };

  const handleButlerTick = (currentTime: number, speed: number) => {
    const pens = animalPensRef.current;
    for (const spId in pens) {
      const pen = pens[spId];
      if (!pen.butlerActive) continue;
      const sp = SPECIES_MAP.get(spId);
      if (!sp) continue;
      const perks = getButlerPerks(sp.tier);
      const lastAction = pen.lastButlerActionAt || 0;
      if (currentTime - lastAction >= perks.intervalSeconds * 1000) {
        // Run butler action
        setAnimalPens((prev) => {
          const currentPen = prev[spId];
          if (!currentPen) return prev;

          // Miss chance
          if (Math.random() < perks.missChance) {
            return {
              ...prev,
              [spId]: { ...currentPen, lastButlerActionAt: currentTime },
            };
          }

          // Auto-feed if hungry
          let newHunger = currentPen.hunger;
          let newSat = currentPen.satisfaction;
          let newStarted = currentPen.startedProducingAt;
          let newReady = currentPen.readyAt;

          if (currentPen.hunger < 100) {
            newHunger = 100;
            newSat = Math.min(100, newSat + 50);
            newStarted = currentTime;
            const waitMs = sp.growthTime * 1000 * (1 - perks.timeReduction);
            newReady = currentTime + waitMs;
          } else {
            // Auto-pet to 100% satisfaction
            newSat = 100;
          }

          // Auto-harvest if ready
          if (newReady && currentTime >= newReady) {
            // Harvest!
            const h = calculateAnimalHarvest(currentPen.count, newSat, sp.harvestBaseYield, sp.baseExp);
            const totalYield = Math.round(h.totalYield * (1 + perks.yieldBonus));

            addItemToInventory(
              sp.harvestProductId,
              sp.harvestProductName,
              sp.harvestProductIcon,
              sp.tier,
              totalYield,
              3,
              sp.baseSellPrice,
              h.isGoldenStar
            );

            applyExpGained(h.totalExp, false);

            if (perks.gemDropChance > 0 && Math.random() < perks.gemDropChance) {
              setPlayer((p) => ({ ...p, jade: p.jade + 1 }));
            }

            return {
              ...prev,
              [spId]: {
                ...currentPen,
                hunger: 0,
                satisfaction: 0,
                affection: Math.min(100, currentPen.affection + 2),
                startedProducingAt: null,
                readyAt: null,
                lastButlerActionAt: currentTime,
              },
            };
          }

          return {
            ...prev,
            [spId]: {
              ...currentPen,
              hunger: newHunger,
              satisfaction: newSat,
              startedProducingAt: newStarted,
              readyAt: newReady,
              lastButlerActionAt: currentTime,
            },
          };
        });
      }
    }
  };

  // Inventory helpers
  const addItemToInventory = (
    itemId: string,
    name: string,
    icon: string,
    tier: Tier,
    count: number,
    tab: 1 | 2 | 3 | 4 | 5 | 6,
    sellPrice: number,
    isGolden = false
  ) => {
    setInventory((prev) => {
      const idx = prev.findIndex((i) => i.id === itemId && (isGolden ? i.isGoldenQuality : !i.isGoldenQuality));
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], count: next[idx].count + count };
        return next;
      }
      return [
        ...prev,
        {
          id: itemId,
          name: isGolden ? `${name} (Ánh Kim ⭐)` : name,
          categoryTab: tab,
          tier,
          icon,
          count,
          locked: false,
          sellPrice: isGolden ? Math.round(sellPrice * 1.3) : sellPrice,
          isGoldenQuality: isGolden,
        },
      ];
    });
  };

  const removeItemFromInventory = (itemId: string, count: number): boolean => {
    const item = inventoryRef.current.find((i) => i.id === itemId);
    if (!item || item.count < count) return false;
    setInventory((prev) =>
      prev
        .map((i) => (i.id === itemId ? { ...i, count: i.count - count } : i))
        .filter((i) => i.count > 0)
    );
    return true;
  };

  const toggleItemLock = (itemId: string) => {
    setInventory((prev) =>
      prev.map((i) => (i.id === itemId ? { ...i, locked: !i.locked } : i))
    );
  };

  const toggleKeepTenUnits = () => {
    setPlayer((prev) => ({ ...prev, keepTenUnitsActive: !prev.keepTenUnitsActive }));
  };

  const bulkSellCategory = (categoryTab: 1 | 2 | 3 | 4 | 5 | 6): { countSold: number; goldEarned: number } => {
    let countSold = 0;
    let goldEarned = 0;
    const keepTen = playerRef.current.keepTenUnitsActive;

    setInventory((prev) => {
      const next: InventoryItem[] = [];
      for (const item of prev) {
        if (item.categoryTab !== categoryTab || item.locked) {
          next.push(item);
          continue;
        }

        const keepAmount = keepTen ? 10 : 0;
        const sellable = Math.max(0, item.count - keepAmount);

        if (sellable > 0) {
          countSold += sellable;
          goldEarned += sellable * item.sellPrice;
          const remaining = item.count - sellable;
          if (remaining > 0) {
            next.push({ ...item, count: remaining });
          }
        } else {
          next.push(item);
        }
      }
      return next;
    });

    if (goldEarned > 0) {
      setPlayer((prev) => ({ ...prev, gold: prev.gold + goldEarned }));
    }

    return { countSold, goldEarned };
  };

  const sellSingleItem = (itemId: string, count: number): boolean => {
    const item = inventoryRef.current.find((i) => i.id === itemId);
    if (!item || item.count < count) return false;

    const goldEarned = count * item.sellPrice;
    removeItemFromInventory(itemId, count);
    setPlayer((prev) => ({ ...prev, gold: prev.gold + goldEarned }));
    return true;
  };

  // Zone 1 - Field actions
  const unlockNextPlot = (): boolean => {
    const lockedIdx = plots.findIndex((p) => !p.unlocked);
    if (lockedIdx === -1) return false;
    const cost = 250 + lockedIdx * 50;
    if (player.gold < cost) return false;

    setPlayer((prev) => ({ ...prev, gold: prev.gold - cost }));
    setPlots((prev) =>
      prev.map((p, idx) => (idx === lockedIdx ? { ...p, unlocked: true } : p))
    );
    return true;
  };

  const tillPlot = (plotId: number) => {
    setPlots((prev) =>
      prev.map((p) => (p.id === plotId && p.unlocked && !p.tilled ? { ...p, tilled: true } : p))
    );
  };

  const tillAllPlots = () => {
    setPlots((prev) =>
      prev.map((p) => (p.unlocked && !p.tilled && !p.plantedSpeciesId ? { ...p, tilled: true } : p))
    );
  };

  const waterPlot = (plotId: number) => {
    setPlots((prev) =>
      prev.map((p) => (p.id === plotId && p.unlocked && p.tilled && !p.watered ? { ...p, watered: true } : p))
    );
  };

  const waterAllPlots = () => {
    setPlots((prev) =>
      prev.map((p) => (p.unlocked && p.tilled && !p.watered ? { ...p, watered: true } : p))
    );
  };

  const fertilizePlot = (plotId: number, type: 'organic' | 'growth' | 'crystal'): boolean => {
    const itemMap = {
      organic: 'phân_hữu_cơ',
      growth: 'phân_kích_tốc',
      crystal: 'phân_tinh_thể',
    };
    const requiredItem = itemMap[type];
    if (!removeItemFromInventory(requiredItem, 1)) return false;

    setPlots((prev) =>
      prev.map((p) => (p.id === plotId ? { ...p, fertilizerType: type } : p))
    );
    return true;
  };

  const fertilizeAllQuick = () => {
    const unfertPlots = plots.filter((p) => p.unlocked && p.fertilizerType === 'none' && p.plantedSpeciesId);
    let used = 0;
    for (const plot of unfertPlots) {
      if (removeItemFromInventory('phân_hữu_cơ', 1)) {
        setPlots((prev) =>
          prev.map((p) => (p.id === plot.id ? { ...p, fertilizerType: 'organic' } : p))
        );
        used++;
      } else {
        break;
      }
    }
  };

  const plantPlot = (plotId: number, speciesId: string): boolean => {
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp) return false;
    // Check seed inventory
    if (!removeItemFromInventory(speciesId, 1)) return false;

    const plot = plots.find((p) => p.id === plotId);
    if (!plot || !plot.unlocked || plot.plantedSpeciesId) return false;

    let growthSec = sp.growthTime;
    if (plot.fertilizerType === 'growth') growthSec = Math.round(growthSec * 0.65);

    const now = Date.now();
    const readyAt = now + growthSec * 1000;

    setPlots((prev) =>
      prev.map((p) =>
        p.id === plotId
          ? {
              ...p,
              tilled: true,
              watered: true,
              plantedSpeciesId: speciesId,
              plantedAt: now,
              readyAt,
              stage: 1,
            }
          : p
      )
    );
    return true;
  };

  const harvestPlot = (plotId: number) => {
    const plot = plots.find((p) => p.id === plotId);
    if (!plot || !plot.plantedSpeciesId || !plot.readyAt || Date.now() < plot.readyAt) return;

    const sp = SPECIES_MAP.get(plot.plantedSpeciesId);
    if (!sp) return;

    let yieldMultiplier = 1;
    if (plot.fertilizerType === 'organic') yieldMultiplier = 1.75;
    if (player.weather === 'rainbow') yieldMultiplier *= 2;

    const isGolden = player.timeOfDay === 'golden' && Math.random() < 0.2;
    const finalYield = Math.max(1, Math.round(sp.harvestBaseYield * yieldMultiplier));

    addItemToInventory(
      sp.harvestProductId,
      sp.harvestProductName,
      sp.harvestProductIcon,
      sp.tier,
      finalYield,
      2,
      sp.baseSellPrice,
      isGolden
    );

    // Apply EXP with anti-skip single harvest cap
    applyExpGained(sp.baseExp, true);

    // Increment Species Mastery
    setPlayer((prev) => ({
      ...prev,
      speciesMastery: {
        ...prev.speciesMastery,
        [sp.id]: (prev.speciesMastery[sp.id] || 0) + 1,
      },
    }));

    // Reset plot
    setPlots((prev) =>
      prev.map((p) =>
        p.id === plotId
          ? {
              ...p,
              tilled: true,
              watered: false,
              fertilizerType: 'none',
              plantedSpeciesId: null,
              plantedAt: null,
              readyAt: null,
              stage: 0,
            }
          : p
      )
    );
  };

  const harvestAllPlots = () => {
    const readyPlotIds = plots
      .filter((p) => p.unlocked && p.plantedSpeciesId && p.readyAt && Date.now() >= p.readyAt)
      .map((p) => p.id);

    readyPlotIds.forEach((id) => harvestPlot(id));
  };

  const shovelPlot = (plotId: number) => {
    setPlots((prev) =>
      prev.map((p) =>
        p.id === plotId
          ? {
              ...p,
              plantedSpeciesId: null,
              plantedAt: null,
              readyAt: null,
              fertilizerType: 'none',
              stage: 0,
            }
          : p
      )
    );
  };

  // Zone 2 - Coop
  const feedAnimal = (speciesId: string, feedType: 'basic' | 'premium'): boolean => {
    const pen = animalPens[speciesId];
    if (!pen || pen.hunger >= 100) return false;
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp) return false;

    const requiredFood = feedType === 'premium' ? 'cám_cao_cấp' : sp.favoriteFoodId || 'thức_ăn_gia_cầm';
    // Must feed 1 unit per animal in pen
    if (!removeItemFromInventory(requiredFood, pen.count)) return false;

    const satGain = feedType === 'premium' ? 60 : 50;
    const now = Date.now();
    let waitSec = sp.growthTime;
    if (feedType === 'premium') waitSec = Math.round(waitSec * 0.75);

    setAnimalPens((prev) => ({
      ...prev,
      [speciesId]: {
        ...pen,
        hunger: 100,
        satisfaction: Math.min(100, pen.satisfaction + satGain),
        startedProducingAt: now,
        readyAt: now + waitSec * 1000,
      },
    }));
    return true;
  };

  const petAnimal = (speciesId: string) => {
    const pen = animalPens[speciesId];
    if (!pen || pen.isPetToday) return;

    let satBonus = 30;
    if (player.weather === 'sunny') satBonus += 10;

    const affBonus = 15;

    setAnimalPens((prev) => ({
      ...prev,
      [speciesId]: {
        ...pen,
        satisfaction: Math.min(100, pen.satisfaction + satBonus),
        affection: Math.min(100, pen.affection + affBonus),
        isPetToday: true,
      },
    }));
  };

  const harvestAnimal = (speciesId: string) => {
    const pen = animalPens[speciesId];
    if (!pen || !pen.readyAt || Date.now() < pen.readyAt) return;
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp) return;

    const isRainbow = player.weather === 'rainbow';
    const h = calculateAnimalHarvest(pen.count, pen.satisfaction, sp.harvestBaseYield, sp.baseExp, isRainbow);

    addItemToInventory(
      sp.harvestProductId,
      sp.harvestProductName,
      sp.harvestProductIcon,
      sp.tier,
      h.totalYield,
      3,
      sp.baseSellPrice,
      h.isGoldenStar
    );

    applyExpGained(h.totalExp, false);

    // Increment mastery
    setPlayer((prev) => ({
      ...prev,
      speciesMastery: {
        ...prev.speciesMastery,
        [sp.id]: (prev.speciesMastery[sp.id] || 0) + pen.count,
      },
    }));

    // Reset pen hunger and satisfaction
    setAnimalPens((prev) => ({
      ...prev,
      [speciesId]: {
        ...pen,
        hunger: 0,
        satisfaction: 0,
        isPetToday: false,
        startedProducingAt: null,
        readyAt: null,
      },
    }));
  };

  const toggleAnimalButler = (speciesId: string) => {
    const pen = animalPens[speciesId];
    if (!pen || pen.affection < 100) return;
    setAnimalPens((prev) => ({
      ...prev,
      [speciesId]: {
        ...pen,
        butlerActive: !pen.butlerActive,
        lastButlerActionAt: Date.now(),
      },
    }));
  };

  const sellAnimal = (speciesId: string, count: number) => {
    const pen = animalPens[speciesId];
    if (!pen || pen.count < count) return;
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp) return;

    const priceEach = getAnimalSellPrice(sp.tier, sp.seedBuyPrice, sp.baseSellPrice * 10);
    const totalGold = priceEach * count;

    setPlayer((prev) => ({ ...prev, gold: prev.gold + totalGold }));

    setAnimalPens((prev) => {
      const remaining = pen.count - count;
      if (remaining <= 0) {
        const next = { ...prev };
        delete next[speciesId];
        return next;
      }
      return {
        ...prev,
        [speciesId]: { ...pen, count: remaining },
      };
    });
  };

  const buyAnimal = (speciesId: string): boolean => {
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp || sp.seedBuyPrice <= 0 || player.gold < sp.seedBuyPrice) return false;

    const existingPen = animalPens[speciesId];
    if (existingPen && existingPen.count >= 10) return false;

    setPlayer((prev) => ({ ...prev, gold: prev.gold - sp.seedBuyPrice }));
    setAnimalPens((prev) => {
      if (existingPen) {
        return {
          ...prev,
          [speciesId]: { ...existingPen, count: existingPen.count + 1 },
        };
      }
      return {
        ...prev,
        [speciesId]: {
          speciesId,
          count: 1,
          hunger: 0,
          satisfaction: 0,
          affection: 0,
          isPetToday: false,
          startedProducingAt: null,
          readyAt: null,
          butlerActive: false,
        },
      };
    });
    return true;
  };

  // Zone 3 - Aquatic
  const feedAquatic = (speciesId: string, feedType: 'basic' | 'favorite'): boolean => {
    const tank = aquaticTanks[speciesId];
    if (!tank || tank.hunger >= 100) return false;
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp) return false;

    const reqFood = feedType === 'favorite' ? sp.favoriteFoodId || 'mồi_tôm_đặc_biệt' : 'thức_ăn_thủy_sinh';
    if (!removeItemFromInventory(reqFood, tank.count)) return false;

    const favGain = feedType === 'favorite' ? 25 : 5;
    const now = Date.now();

    setAquaticTanks((prev) => ({
      ...prev,
      [speciesId]: {
        ...tank,
        hunger: 100,
        favoriteFoodLevel: Math.min(100, tank.favoriteFoodLevel + favGain),
        startedProducingAt: now,
        readyAt: now + sp.growthTime * 1000,
      },
    }));
    return true;
  };

  const harvestAquatic = (speciesId: string) => {
    const tank = aquaticTanks[speciesId];
    if (!tank || !tank.readyAt || Date.now() < tank.readyAt) return;
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp) return;

    const isRainbow = player.weather === 'rainbow';
    const h = calculateAquaticHarvest(tank.count, tank.favoriteFoodLevel, sp.harvestBaseYield, sp.baseExp, isRainbow);

    addItemToInventory(
      sp.harvestProductId,
      sp.harvestProductName,
      sp.harvestProductIcon,
      sp.tier,
      h.totalYield,
      4,
      sp.baseSellPrice
    );

    applyExpGained(h.totalExp, false);

    setPlayer((prev) => ({
      ...prev,
      speciesMastery: {
        ...prev.speciesMastery,
        [sp.id]: (prev.speciesMastery[sp.id] || 0) + tank.count,
      },
    }));

    setAquaticTanks((prev) => ({
      ...prev,
      [speciesId]: {
        ...tank,
        hunger: 0,
        startedProducingAt: null,
        readyAt: null,
      },
    }));
  };

  const sellAquatic = (speciesId: string, count: number) => {
    const tank = aquaticTanks[speciesId];
    if (!tank || tank.count < count) return;
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp) return;

    const priceEach = getAnimalSellPrice(sp.tier, sp.seedBuyPrice, sp.baseSellPrice * 10);
    const totalGold = priceEach * count;

    setPlayer((prev) => ({ ...prev, gold: prev.gold + totalGold }));
    setAquaticTanks((prev) => {
      const remaining = tank.count - count;
      if (remaining <= 0) {
        const next = { ...prev };
        delete next[speciesId];
        return next;
      }
      return {
        ...prev,
        [speciesId]: { ...tank, count: remaining },
      };
    });
  };

  const buyAquatic = (speciesId: string): boolean => {
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp || sp.seedBuyPrice <= 0 || player.gold < sp.seedBuyPrice) return false;

    const existingTank = aquaticTanks[speciesId];
    if (existingTank && existingTank.count >= 10) return false;

    setPlayer((prev) => ({ ...prev, gold: prev.gold - sp.seedBuyPrice }));
    setAquaticTanks((prev) => {
      if (existingTank) {
        return {
          ...prev,
          [speciesId]: { ...existingTank, count: existingTank.count + 1 },
        };
      }
      return {
        ...prev,
        [speciesId]: {
          speciesId,
          count: 1,
          waterZone: (sp as any).water || 'freshwater',
          hunger: 0,
          favoriteFoodLevel: 0,
          startedProducingAt: null,
          readyAt: null,
        },
      };
    });
    return true;
  };

  const toggleAquaticAerator = () => {
    setPlayer((prev) => ({ ...prev, aquaticAeratorOn: !prev.aquaticAeratorOn }));
  };

  const cleanAquaticFilter = () => {
    setPlayer((prev) => ({ ...prev, aquaticFilterDurability: 100 }));
  };

  const collectMineralMud = () => {
    if (player.aquaticMineralMudReady <= 0) return;
    addItemToInventory(
      'item_mineral_mud',
      'Bùn Khoáng Đáy Hồ',
      '🏺',
      2,
      player.aquaticMineralMudReady,
      6,
      40
    );
    setPlayer((prev) => ({ ...prev, aquaticMineralMudReady: 0 }));
  };

  // Zone 4 - Orchard & Bees
  const plantFruitTreeOrMushroom = (slotId: number, speciesId: string): boolean => {
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp) return false;
    if (!removeItemFromInventory(speciesId, 1)) return false;

    const now = Date.now();
    setOrchardSlots((prev) =>
      prev.map((slot) =>
        slot.id === slotId
          ? {
              ...slot,
              speciesId,
              plantedAt: now,
              readyAt: now + sp.growthTime * 1000,
              isRipe: false,
            }
          : slot
      )
    );
    return true;
  };

  const harvestOrchardSlot = (slotId: number) => {
    const slot = orchardSlots.find((s) => s.id === slotId);
    if (!slot || !slot.speciesId || !slot.readyAt || Date.now() < slot.readyAt) return;
    const sp = SPECIES_MAP.get(slot.speciesId);
    if (!sp) return;

    let multiplier = 1;
    if (player.weather === 'foggy') multiplier = 1.5;
    if (player.weather === 'rainbow') multiplier *= 2;

    const totalYield = Math.max(1, Math.round(sp.harvestBaseYield * multiplier));
    addItemToInventory(
      sp.harvestProductId,
      sp.harvestProductName,
      sp.harvestProductIcon,
      sp.tier,
      totalYield,
      sp.category === 'fruit_tree' ? 2 : 3,
      sp.baseSellPrice
    );

    applyExpGained(sp.baseExp, true);

    const now = Date.now();
    setOrchardSlots((prev) =>
      prev.map((s) =>
        s.id === slotId
          ? {
              ...s,
              plantedAt: now,
              readyAt: now + sp.growthTime * 1000,
            }
          : s
      )
    );
  };

  const shovelOrchardSlot = (slotId: number) => {
    setOrchardSlots((prev) =>
      prev.map((s) => (s.id === slotId ? { ...s, speciesId: null, plantedAt: null, readyAt: null } : s))
    );
  };

  const graftTreeOrMushroom = (species1Id: string, species2Id: string) => {
    const sp1 = SPECIES_MAP.get(species1Id);
    const sp2 = SPECIES_MAP.get(species2Id);
    if (!sp1 || !sp2) return { success: false };

    // Find candidate of higher tier
    const nextTier = Math.min(5, Math.max(sp1.tier, sp2.tier) + 1) as Tier;
    const candidate = ALL_SPECIES.find((s) => s.category === sp1.category && s.tier === nextTier);
    if (!candidate) return { success: false };

    if (!removeItemFromInventory(species1Id, 1) || !removeItemFromInventory(species2Id, 1)) {
      return { success: false };
    }

    addItemToInventory(candidate.id, candidate.name, candidate.icon, candidate.tier, 1, 1, candidate.seedBuyPrice);
    applyExpGained(candidate.tier * 30, false);
    return { success: true, resultSpeciesId: candidate.id };
  };

  const harvestBeeHive = (hiveId: number) => {
    const hive = beeHives.find((h) => h.id === hiveId);
    if (!hive || Date.now() < hive.readyAt) return;
    const bee = SPECIES_MAP.get(hive.beeSpeciesId);
    if (!bee) return;

    addItemToInventory(
      bee.harvestProductId,
      bee.harvestProductName,
      bee.harvestProductIcon,
      bee.tier,
      1,
      3,
      bee.baseSellPrice
    );

    applyExpGained(bee.baseExp, true);

    const now = Date.now();
    setBeeHives((prev) =>
      prev.map((h) =>
        h.id === hiveId ? { ...h, startedProducingAt: now, readyAt: now + bee.growthTime * 1000 } : h
      )
    );
  };

  const breedBeeGacha = (beeSpeciesId: string, flowerItemId: string) => {
    // Check flower in inventory
    if (!removeItemFromInventory(flowerItemId, 1)) return { success: false, pity: player.beeGachaPityCount };

    const rate = getBeeGachaRate(player.beeGachaPityCount);
    const rolled = Math.random() < rate;

    if (rolled) {
      // Find a higher tier bee
      const curBee = SPECIES_MAP.get(beeSpeciesId);
      const targetTier = curBee ? (Math.min(5, curBee.tier + 1) as Tier) : 2;
      const targetBees = BEE_SPECIES_DATA.filter((b) => b.tier === targetTier);
      const newBee = targetBees[Math.floor(Math.random() * targetBees.length)];

      // Add hive or replace
      setBeeHives((prev) => [
        ...prev,
        {
          id: prev.length + 1,
          beeSpeciesId: newBee.id,
          startedProducingAt: Date.now(),
          readyAt: Date.now() + newBee.time * 1000,
          isReady: false,
        },
      ]);

      applyExpGained(targetTier * 45, false);
      setPlayer((prev) => ({ ...prev, beeGachaPityCount: 0 }));
      try {
        confetti({ particleCount: 50, spread: 50 });
      } catch (e) {}
      return { success: true, newBeeId: newBee.id, pity: 0 };
    } else {
      const nextPity = Math.min(5, player.beeGachaPityCount + 1);
      setPlayer((prev) => ({ ...prev, beeGachaPityCount: nextPity }));
      return { success: false, pity: nextPity };
    }
  };

  // Zone 5 - Lab
  const synthesizeMutation = (speciesId: string): boolean => {
    const sp = SPECIES_MAP.get(speciesId);
    if (!sp || sp.tier < 4) return false;

    // Check player level
    if (sp.tier === 4 && player.level < 12) return false;
    if (sp.tier === 5 && player.level < 25) return false;

    // Check parents mastery
    if (sp.breedingParents) {
      const [p1, p2] = sp.breedingParents;
      const m1 = player.speciesMastery[p1] || 0;
      const m2 = player.speciesMastery[p2] || 0;
      if (m1 < 20 || m2 < 20) return false;
    }

    // Add mutated seed or young to inventory
    addItemToInventory(sp.id, sp.name, sp.icon, sp.tier, 1, 1, sp.baseSellPrice * 2);
    applyExpGained(sp.tier === 4 ? 120 : 250, false);
    try {
      confetti({ particleCount: 60, spread: 60 });
    } catch (e) {}
    return true;
  };

  // Zone 6 - Workshop
  const startCraftBatch = (recipeId: string, quantity: number): boolean => {
    const recipe = RECIPES_MAP.get(recipeId);
    if (!recipe || quantity <= 0) return false;

    // Check inputs
    for (const inp of recipe.inputs) {
      const totalNeeded = inp.count * quantity;
      const invItem = inventory.find((i) => i.id === inp.itemId);
      if (!invItem || invItem.count < totalNeeded) return false;
    }

    // Deduct inputs
    for (const inp of recipe.inputs) {
      removeItemFromInventory(inp.itemId, inp.count * quantity);
    }

    const waitSeconds = getBatchCraftWaitTime(recipe.craftTimeSeconds, quantity);
    const now = Date.now();

    setActiveCraftBatches((prev) => [
      ...prev,
      {
        id: `batch_${now}_${Math.random()}`,
        recipeId,
        quantity,
        startedAt: now,
        finishAt: now + waitSeconds * 1000,
        expTotal: recipe.expPerUnit * quantity,
      },
    ]);
    return true;
  };

  const claimCraftBatch = (batchId: string) => {
    const batch = activeCraftBatches.find((b) => b.id === batchId);
    if (!batch || Date.now() < batch.finishAt) return;
    const recipe = RECIPES_MAP.get(batch.recipeId);
    if (!recipe) return;

    addItemToInventory(
      recipe.outputItemId,
      recipe.name,
      recipe.icon,
      recipe.tier,
      recipe.outputCount * batch.quantity,
      5,
      recipe.tier * 65
    );

    applyExpGained(batch.expTotal, false);

    setActiveCraftBatches((prev) => prev.filter((b) => b.id !== batchId));
  };

  // Zone 7 - Port
  const buyStoreItem = (itemId: string, count: number, priceEach: number): boolean => {
    const total = count * priceEach;
    if (player.gold < total) return false;

    const sp = SPECIES_MAP.get(itemId);
    if (sp) {
      if (sp.category === 'animal') {
        for (let i = 0; i < count; i++) {
          if (!buyAnimal(itemId)) return false;
        }
        return true;
      }
      if (sp.category === 'aquatic') {
        for (let i = 0; i < count; i++) {
          if (!buyAquatic(itemId)) return false;
        }
        return true;
      }
      // Crop or fruit seed
      setPlayer((prev) => ({ ...prev, gold: prev.gold - total }));
      addItemToInventory(sp.id, sp.name, sp.icon, sp.tier, count, 1, sp.seedBuyPrice);
      return true;
    }

    // Material or food item
    setPlayer((prev) => ({ ...prev, gold: prev.gold - total }));
    addItemToInventory(itemId, itemId, '📦', 1, count, 6, Math.floor(priceEach * 0.7));
    return true;
  };

  const fulfillMerchantOrder = (orderId: string): boolean => {
    const order = merchantShip.orders.find((o) => o.id === orderId);
    if (!order || order.fulfilled) return false;

    if (!removeItemFromInventory(order.itemId, order.countRequired)) return false;

    // Calculate EXP
    const reqExp = getRequiredExp(player.level);
    const gainedExp = Math.round(reqExp * order.rewardExpRatio);

    setPlayer((prev) => ({
      ...prev,
      gold: prev.gold + order.rewardGold,
      jade: prev.jade + order.rewardJade,
    }));
    applyExpGained(gainedExp, false);

    // 15% chance to drop new recipe
    let droppedFormula: string | null = null;
    if (Math.random() < 0.15 && !merchantShip.droppedFormulaId) {
      const lockedRecipes = ALL_RECIPES.filter((r) => !player.unlockedRecipes.includes(r.id));
      if (lockedRecipes.length > 0) {
        droppedFormula = lockedRecipes[Math.floor(Math.random() * lockedRecipes.length)].id;
      }
    }

    setMerchantShip((prev) => ({
      ...prev,
      orders: prev.orders.map((o) => (o.id === orderId ? { ...o, fulfilled: true } : o)),
      droppedFormulaId: droppedFormula || prev.droppedFormulaId,
    }));
    return true;
  };

  const claimShipFormula = () => {
    if (!merchantShip.droppedFormulaId || merchantShip.formulaClaimed) return;
    const formulaId = merchantShip.droppedFormulaId;
    setPlayer((prev) => ({
      ...prev,
      unlockedRecipes: [...prev.unlockedRecipes, formulaId],
    }));
    setMerchantShip((prev) => ({ ...prev, formulaClaimed: true }));
    try {
      confetti({ particleCount: 40 });
    } catch (e) {}
  };

  // Settings
  const setTimeSpeed = (speed: 1 | 2 | 5 | 10) => {
    setPlayer((prev) => ({ ...prev, timeSpeed: speed }));
  };

  const toggleRealtimeSync = () => {
    setPlayer((prev) => ({ ...prev, isRealtimeSync: !prev.isRealtimeSync }));
  };

  const exportSaveToJson = () => {
    const saveState = {
      player: playerRef.current,
      plots: plotsRef.current,
      animalPens: animalPensRef.current,
      aquaticTanks: aquaticTanksRef.current,
      orchardSlots: orchardSlotsRef.current,
      beeHives: beeHivesRef.current,
      activeCraftBatches: activeCraftBatchesRef.current,
      merchantShip,
      inventory: inventoryRef.current,
    };
    const blob = new Blob([JSON.stringify(saveState, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NongTraiDieuKy_Save_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importSaveFromJson = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.player && data.plots) {
        setPlayer(data.player);
        setPlots(data.plots);
        setAnimalPens(data.animalPens || {});
        setAquaticTanks(data.aquaticTanks || {});
        setOrchardSlots(data.orchardSlots || []);
        setBeeHives(data.beeHives || []);
        setActiveCraftBatches(data.activeCraftBatches || []);
        setMerchantShip(data.merchantShip || createInitialMerchantShip(data.player.level || 1));
        setInventory(data.inventory || []);
        localStorage.setItem(STORAGE_KEY, jsonStr);
        return true;
      }
    } catch (e) {
      console.error(e);
    }
    return false;
  };

  const resetGameData = () => {
    localStorage.removeItem(STORAGE_KEY);
    setPlayer(createInitialPlayer());
    setPlots(createInitialPlots());
    setAnimalPens(createInitialAnimalPens());
    setAquaticTanks({});
    setOrchardSlots(createInitialOrchardSlots());
    setBeeHives([]);
    setActiveCraftBatches([]);
    setMerchantShip(createInitialMerchantShip(1));
    setInventory(createInitialInventory());
  };

  const closeLevelUpModal = () => setLevelUpData(null);
  const closeOfflineReport = () => setOfflineReport(null);

  // Compute notification badges for the 7 zones
  const now = Date.now();
  const notificationBadges: Record<ZoneId, boolean> = {
    1: plots.some((p) => p.unlocked && p.readyAt && now >= p.readyAt),
    2: Object.values(animalPens).some((p) => (p.readyAt && now >= p.readyAt) || p.hunger === 0),
    3: Object.values(aquaticTanks).some((t) => (t.readyAt && now >= t.readyAt) || t.hunger === 0),
    4: orchardSlots.some((s) => s.readyAt && now >= s.readyAt) || beeHives.some((h) => now >= h.readyAt),
    5: false,
    6: activeCraftBatches.some((b) => now >= b.finishAt),
    7: merchantShip.orders.some((o) => !o.fulfilled),
  };

  return (
    <GameContext.Provider
      value={{
        player,
        plots,
        animalPens,
        aquaticTanks,
        orchardSlots,
        beeHives,
        activeCraftBatches,
        merchantShip,
        inventory,
        activeZone,
        navCollapsed,
        shovelModeActive,
        offlineReport,
        levelUpData,
        notificationBadges,
        setActiveZone,
        setNavCollapsed,
        setShovelModeActive,
        closeLevelUpModal,
        closeOfflineReport,
        addItemToInventory,
        removeItemFromInventory,
        toggleItemLock,
        toggleKeepTenUnits,
        bulkSellCategory,
        sellSingleItem,
        unlockNextPlot,
        tillPlot,
        tillAllPlots,
        waterPlot,
        waterAllPlots,
        fertilizePlot,
        fertilizeAllQuick,
        plantPlot,
        harvestPlot,
        harvestAllPlots,
        shovelPlot,
        feedAnimal,
        petAnimal,
        harvestAnimal,
        toggleAnimalButler,
        sellAnimal,
        buyAnimal,
        feedAquatic,
        harvestAquatic,
        sellAquatic,
        buyAquatic,
        toggleAquaticAerator,
        cleanAquaticFilter,
        collectMineralMud,
        plantFruitTreeOrMushroom,
        harvestOrchardSlot,
        shovelOrchardSlot,
        graftTreeOrMushroom,
        harvestBeeHive,
        breedBeeGacha,
        synthesizeMutation,
        startCraftBatch,
        claimCraftBatch,
        buyStoreItem,
        fulfillMerchantOrder,
        claimShipFormula,
        setTimeSpeed,
        toggleRealtimeSync,
        exportSaveToJson,
        importSaveFromJson,
        resetGameData,
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error('useGame must be used within GameProvider');
  return ctx;
};
