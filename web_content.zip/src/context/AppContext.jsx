import React,{createContext,useContext,useMemo,useState} from "react";
const AppContext=createContext(null);
export function AppProvider({children}){
  const [loggedIn,setLoggedIn]=useState(false);
  const [wallpaper,setWallpaper]=useState("");
  const [memory,setMemory]=useState({lastScript:"",engineLogs:[],completed:0,activeState:"Maharashtra"});
  const [outputs,setOutputs]=useState([]);
  const value=useMemo(()=>({loggedIn,setLoggedIn,wallpaper,setWallpaper,memory,setMemory,outputs,setOutputs}),[loggedIn,wallpaper,memory,outputs]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}
export const useApp=()=>useContext(AppContext);