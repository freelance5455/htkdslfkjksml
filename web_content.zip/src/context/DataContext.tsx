import React, { createContext, useContext, useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  AppData,
  ProjectSubmission,
  Founder,
  Project,
  FinancialRecord,
  FaqItem,
  GalleryItem,
  UserAccount,
  SupportTicket,
  ServiceProductItem,
  TicketStatus,
  TicketStats,
  AiChatMessage,
  AiClientSession,
  AiAssistantSettings,
  VouchItem,
  VouchStatus,
  VouchStats
} from '../types/index.ts';
import { defaultStore } from '../data/defaults.ts';
import { db, auth, CUBIX_STORE_COLLECTION, CUBIX_MAIN_DOC, CUBIX_VOUCHES_COLLECTION } from '../firebase.ts';
import { doc, setDoc, getDoc, onSnapshot, collection, runTransaction, deleteDoc } from 'firebase/firestore';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

const VERIFIED_SNAPSHOT_KEY = 'cubix_verified_firestore_snapshot_v3';
const HERO_BG_CACHE_KEY = 'cubix_hero_bg_cache_v1';

export function syncHeroBackgroundToDomAndCache(heroBg?: any): void {
  try {
    if (!heroBg || typeof heroBg !== 'object') return;
    localStorage.setItem(HERO_BG_CACHE_KEY, JSON.stringify(heroBg));
    if (typeof document !== 'undefined' && document.documentElement) {
      const root = document.documentElement;
      const imgUrl =
        heroBg.imageUrl && heroBg.imageUrl !== 'none' && String(heroBg.imageUrl).trim() !== ''
          ? String(heroBg.imageUrl).trim()
          : '/b90c9408e77c5a808a0f1adfab828f1b.jpg';
      let pos = heroBg.position || 'top center';
      if (pos === 'top') pos = 'top center';
      else if (pos === 'bottom') pos = 'bottom center';
      else if (pos === 'center') pos = 'center center';

      const blurVal = typeof heroBg.blur === 'number' ? Math.min(Math.max(heroBg.blur, 0), 40) : 0;
      const overlayVal =
        typeof heroBg.overlayOpacity === 'number'
          ? Math.min(Math.max(heroBg.overlayOpacity, 0), 100) / 100
          : 0.8;
      const solidCol = heroBg.solidColor || '#06101e';

      root.style.setProperty('--cubix-bg-image', `url("${imgUrl.replace(/"/g, '\\"')}")`);
      root.style.setProperty('--cubix-bg-position', pos);
      root.style.setProperty('--cubix-bg-size', heroBg.size || 'cover');
      root.style.setProperty('--cubix-bg-repeat', heroBg.repeat || 'no-repeat');
      root.style.setProperty('--cubix-bg-blur', `${blurVal}px`);
      root.style.setProperty('--cubix-bg-scale', blurVal > 0 ? '1.08' : '1');
      root.style.setProperty('--cubix-bg-overlay', String(overlayVal));
      root.style.setProperty('--cubix-bg-color', solidCol);
    }
  } catch {
    // ignore storage errors
  }
}

function loadVerifiedSnapshot(): AppData | null {
  try {
    const raw = localStorage.getItem(VERIFIED_SNAPSHOT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && Array.isArray(parsed.founders)) {
      return parsed as AppData;
    }
  } catch {
    // ignore
  }
  return null;
}

function saveVerifiedSnapshot(snapshotData: AppData): void {
  try {
    if (snapshotData?.settings?.heroBackground) {
      syncHeroBackgroundToDomAndCache(snapshotData.settings.heroBackground);
    }
    localStorage.setItem(VERIFIED_SNAPSHOT_KEY, JSON.stringify(snapshotData));
  } catch {
    // ignore storage quota errors
  }
}

async function optimizeImageDataUrl(dataUrl: string, maxDim = 1280): Promise<string> {
  if (!dataUrl || !dataUrl.startsWith('data:image/')) {
    return dataUrl;
  }
  if (dataUrl.startsWith('data:image/svg+xml') || dataUrl.startsWith('data:image/gif')) {
    return dataUrl;
  }
  return new Promise((resolve) => {
    try {
      const img = new Image();
      img.onload = () => {
        try {
          let width = img.naturalWidth || img.width || 800;
          let height = img.naturalHeight || img.height || 800;
          if (width > maxDim || height > maxDim) {
            if (width >= height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(dataUrl);
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          let out = canvas.toDataURL('image/webp', 0.85);
          if (!out || !out.startsWith('data:image/webp')) {
            out = canvas.toDataURL('image/jpeg', 0.85);
          }
          resolve(out.length < dataUrl.length ? out : dataUrl);
        } catch {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    } catch {
      resolve(dataUrl);
    }
  });
}

interface DataContextType {
  data: AppData;
  loading: boolean;
  syncing: boolean;
  syncError: string | null;
  clearSyncError: () => void;
  databaseStatus: {
    configured: boolean;
    connected: boolean;
    storageType: string;
    error?: string | null;
    message?: string;
  } | null;
  lastUpdated: string | null;
  error: string | null;
  refreshData: (showIndicator?: boolean) => Promise<void>;
  updateAppData: (updatedFields: Partial<AppData>) => Promise<{ success: boolean; data?: AppData; error?: string }>;
  submitProjectBrief: (brief: {
    name: string;
    email: string;
    discord?: string;
    projectType: string;
    budget?: string;
    timeline?: string;
    description: string;
    referenceLinks?: string;
  }) => Promise<{ success: boolean; submissionId?: string; error?: string }>;
  submitContactMessage: (msg: {
    name: string;
    email: string;
    message: string;
  }) => Promise<{ success: boolean; message?: string; error?: string }>;
  uploadAdminFile: (fileName: string, fileData: string) => Promise<{ success: boolean; fileUrl?: string; downloadUrl?: string; error?: string }>;
  adminToken: string | null;
  currentUser: UserAccount | null;
  firebaseUser: any | null;
  isFirebaseAuthed: boolean;
  isAdmin: boolean;
  isFounder: boolean;
  loginAdmin: (identifier: string, pass: string) => Promise<{ success: boolean; user?: UserAccount; error?: string }>;
  logoutAdmin: () => void;
  // Account Management
  accounts: UserAccount[];
  fetchAccounts: () => Promise<void>;
  createAccount: (data: {
    email: string;
    username?: string;
    name: string;
    password: string;
    role: 'admin' | 'founder';
    founderId?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  updateAccount: (
    id: string,
    updates: {
      email?: string;
      username?: string;
      name?: string;
      role?: 'admin' | 'founder';
      status?: 'active' | 'inactive';
      founderId?: string;
    }
  ) => Promise<{ success: boolean; error?: string }>;
  resetAccountPassword: (id: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  deleteAccount: (id: string) => Promise<{ success: boolean; error?: string }>;
  // Submissions
  adminSubmissions: ProjectSubmission[];
  fetchAdminSubmissions: () => Promise<void>;
  updateSubmissionStatus: (id: string, status: ProjectSubmission['status'], internalNotes?: string) => Promise<boolean>;
  deleteSubmission: (id: string) => Promise<boolean>;
  resetToDefaults: () => Promise<boolean>;
  // Gallery Management
  addGalleryItem: (item: Partial<GalleryItem>) => Promise<{ success: boolean; error?: string }>;
  deleteGalleryItem: (id: string) => Promise<{ success: boolean; error?: string }>;
  updateFounderProfile: (profile: Partial<Founder>) => Promise<{ success: boolean; error?: string }>;
  // Support Tickets (Client)
  clientTickets: SupportTicket[];
  createSupportTicket: (ticket: {
    email: string;
    username: string;
    discordId: string;
    serviceProductId?: string;
    serviceProductName: string;
    requestDetails: string;
    attachments?: any[];
  }) => Promise<{ success: boolean; ticket?: SupportTicket; error?: string }>;
  lookupClientTicket: (ticketNumber: string, pinOrToken: string) => Promise<{ success: boolean; ticket?: SupportTicket; error?: string }>;
  sendClientTicketMessage: (ticketNumber: string, clientToken: string, message: string, attachments?: any[]) => Promise<{ success: boolean; message?: any; error?: string }>;
  // Support Tickets (Admin)
  adminTickets: SupportTicket[];
  adminTicketStats: TicketStats | null;
  fetchAdminTickets: () => Promise<void>;
  updateAdminTicket: (id: string, updates: { status?: TicketStatus; internalNotes?: string; note?: string }) => Promise<{ success: boolean; ticket?: SupportTicket; error?: string }>;
  sendAdminTicketReply: (id: string, message: string, attachments?: any[], setStatus?: TicketStatus) => Promise<{ success: boolean; message?: any; error?: string }>;
  deleteAdminTicket: (id: string) => Promise<{ success: boolean; error?: string }>;
  // Services & Products (Admin)
  addServiceProduct: (item: Partial<ServiceProductItem>) => Promise<{ success: boolean; item?: ServiceProductItem; error?: string }>;
  updateServiceProduct: (id: string, updates: Partial<ServiceProductItem>) => Promise<{ success: boolean; item?: ServiceProductItem; error?: string }>;
  deleteServiceProduct: (id: string) => Promise<{ success: boolean; error?: string }>;
  reorderServiceProducts: (orderedIds: string[]) => Promise<{ success: boolean; error?: string }>;
  // Ticket Discord Voice Channel URL Setting
  saveTicketDiscordUrl: (url: string) => Promise<{ success: boolean; error?: string }>;
  // AI Assistant & Sequential Client Identity (Cubes-1, Cubes-2, ...)
  cubesId: string;
  ensureCubesClient: () => Promise<string>;
  aiMessages: AiChatMessage[];
  aiSending: boolean;
  allAiSessions: AiClientSession[];
  sendAiChatMessage: (text: string) => Promise<{ success: boolean; reply?: string; error?: string }>;
  clearAiChat: () => Promise<void>;
  submitTalkWithFounders: (requestDetails?: string) => Promise<{ success: boolean; ticket?: SupportTicket; error?: string }>;
  sendCubesTicketReply: (ticketId: string, message: string) => Promise<{ success: boolean; error?: string }>;
  // Cubix Vouches & Reputation System
  vouches: VouchItem[];
  approvedVouches: VouchItem[];
  latestApprovedVouch: VouchItem | null;
  vouchStats: VouchStats;
  vouchProductOptions: string[];
  submitVouch: (payload: {
    name: string;
    discordUsername: string;
    productOrService: string;
    feedback: string;
    rating: number;
  }) => Promise<{ success: boolean; vouch?: VouchItem; message?: string; error?: string }>;
  updateVouchAdmin: (
    id: string,
    updates: {
      status?: VouchStatus;
      isVerified?: boolean;
      name?: string;
      discordUsername?: string;
      productOrService?: string;
      feedback?: string;
      rating?: number;
    }
  ) => Promise<{ success: boolean; vouch?: VouchItem; error?: string }>;
  deleteVouchAdmin: (id: string) => Promise<{ success: boolean; error?: string }>;
}

const DataContext = createContext<DataContextType | null>(null);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initialCachedSnapshot = useRef<AppData | null>(loadVerifiedSnapshot());

  const [data, setData] = useState<AppData>(() => {
    if (initialCachedSnapshot.current) {
      return initialCachedSnapshot.current;
    }
    return {
      founders: defaultStore.founders,
      projects: defaultStore.projects,
      services: defaultStore.services,
      serviceProducts: defaultStore.serviceProducts || [],
      gallery: defaultStore.gallery || [],
      financialRecords: defaultStore.financialRecords,
      submissions: defaultStore.submissions,
      faqs: defaultStore.faqs,
      settings: defaultStore.settings,
      reputationData: defaultStore.reputationData,
      aiAssistant: defaultStore.aiAssistant,
      vouches: defaultStore.vouches || [],
      lastUpdated: defaultStore.lastUpdated
    };
  });

  // Real-time Vouches collection state
  const [vouchesList, setVouchesList] = useState<VouchItem[]>(() => {
    if (initialCachedSnapshot.current && Array.isArray(initialCachedSnapshot.current.vouches)) {
      return initialCachedSnapshot.current.vouches;
    }
    return defaultStore.vouches || [];
  });

  const [loading, setLoading] = useState<boolean>(false);
  const [syncing, setSyncing] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [databaseStatus, setDatabaseStatus] = useState<{
    configured: boolean;
    connected: boolean;
    storageType: string;
    error?: string | null;
    message?: string;
  } | null>(null);

  const clearSyncError = useCallback(() => {
    setSyncError(null);
  }, []);

  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return sessionStorage.getItem('cubix_admin_token') || localStorage.getItem('cubix_admin_token');
  });

  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    const saved = sessionStorage.getItem('cubix_user_session') || localStorage.getItem('cubix_user_session');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    return null;
  });

  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [isFirebaseAuthed, setIsFirebaseAuthed] = useState(false);

  const [accounts, setAccounts] = useState<UserAccount[]>([]);
  const [adminSubmissions, setAdminSubmissions] = useState<ProjectSubmission[]>([]);

  // Client tickets loaded securely from client session tokens
  const [clientTickets, setClientTickets] = useState<SupportTicket[]>(() => {
    try {
      const saved = localStorage.getItem('cubix_client_cached_tickets');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Admin ticket management
  const [adminTickets, setAdminTickets] = useState<SupportTicket[]>([]);
  const [adminTicketStats, setAdminTicketStats] = useState<TicketStats | null>(null);

  // Sequential Client Identity (Cubes-1, Cubes-2, Cubes-3, ...)
  const [cubesId, setCubesId] = useState<string>(() => {
    try {
      return localStorage.getItem('cubix_client_cubes_id') || '';
    } catch {
      return '';
    }
  });
  const [aiMessages, setAiMessages] = useState<AiChatMessage[]>([]);
  const [aiSending, setAiSending] = useState(false);
  const [allAiSessions, setAllAiSessions] = useState<AiClientSession[]>([]);
  const allocatingCubesRef = useRef<Promise<string> | null>(null);

  const ensureCubesClient = useCallback(async (): Promise<string> => {
    try {
      const existing = localStorage.getItem('cubix_client_cubes_id');
      if (existing && /^Cubes-\d+$/i.test(existing)) {
        setCubesId(existing);
        return existing;
      }
    } catch (_) {}

    if (allocatingCubesRef.current) {
      return allocatingCubesRef.current;
    }

    const promise = (async () => {
      try {
        const counterRef = doc(db, 'cubix_meta', 'client_counter');
        const assignedNumber = await runTransaction(db, async (transaction) => {
          const snap = await transaction.get(counterRef);
          let nextNum = 1;
          if (snap.exists()) {
            const current = Number(snap.data()?.lastClientNumber) || 0;
            nextNum = current + 1;
          }
          transaction.set(
            counterRef,
            {
              lastClientNumber: nextNum,
              updatedAt: new Date().toISOString()
            },
            { merge: true }
          );
          return nextNum;
        });

        const newId = `Cubes-${assignedNumber}`;
        try {
          localStorage.setItem('cubix_client_cubes_id', newId);
        } catch (_) {}
        setCubesId(newId);

        const nowIso = new Date().toISOString();
        const welcomeText =
          data?.aiAssistant?.welcomeMessage ||
          defaultStore.aiAssistant?.welcomeMessage ||
          'Hello! Welcome to Cubix Studio AI Assistant. How can I help you today?';

        const initialMsg: AiChatMessage = {
          id: 'ai_welcome_' + Date.now(),
          sender: 'ai',
          text: welcomeText,
          createdAt: nowIso
        };

        await setDoc(
          doc(db, 'cubix_ai_chats', newId),
          {
            cubesId: newId,
            clientNumber: assignedNumber,
            messages: [initialMsg],
            createdAt: nowIso,
            updatedAt: nowIso
          },
          { merge: true }
        );
        setAiMessages([initialMsg]);
        return newId;
      } catch (err) {
        const fallbackNum = Math.floor(1 + Math.random() * 999);
        const fallbackId = `Cubes-${fallbackNum}`;
        try {
          localStorage.setItem('cubix_client_cubes_id', fallbackId);
        } catch (_) {}
        setCubesId(fallbackId);
        return fallbackId;
      } finally {
        allocatingCubesRef.current = null;
      }
    })();

    allocatingCubesRef.current = promise;
    return promise;
  }, [data?.aiAssistant?.welcomeMessage]);

  // Automatically ensure every visitor gets a sequential Cubes-N ID
  useEffect(() => {
    ensureCubesClient();
  }, [ensureCubesClient]);

  // Real-time listener for current client's separate AI conversation
  useEffect(() => {
    if (!cubesId) return;
    let unsub: (() => void) | undefined;
    try {
      const chatRef = doc(db, 'cubix_ai_chats', cubesId);
      unsub = onSnapshot(chatRef, async (snap) => {
        if (snap.exists()) {
          const d = snap.data();
          if (Array.isArray(d.messages) && d.messages.length > 0) {
            setAiMessages(d.messages);
          }
        } else {
          const nowIso = new Date().toISOString();
          const welcomeText =
            data?.aiAssistant?.welcomeMessage ||
            defaultStore.aiAssistant?.welcomeMessage ||
            'Hello! Welcome to Cubix Studio AI Assistant. How can I help you today?';
          const initialMsg: AiChatMessage = {
            id: 'ai_welcome_' + Date.now(),
            sender: 'ai',
            text: welcomeText,
            createdAt: nowIso
          };
          const numMatch = cubesId.match(/(\d+)/);
          const clientNumber = numMatch ? parseInt(numMatch[1], 10) : 1;
          setAiMessages([initialMsg]);
          try {
            await setDoc(
              chatRef,
              {
                cubesId,
                clientNumber,
                messages: [initialMsg],
                createdAt: nowIso,
                updatedAt: nowIso
              },
              { merge: true }
            );
          } catch (_) {}
        }
      });
    } catch (_) {}
    return () => {
      if (unsub) unsub();
    };
  }, [cubesId, data?.aiAssistant?.welcomeMessage]);

  // Real-time listener for all AI client sessions & support_tickets in Firestore
  useEffect(() => {
    let unsubTickets: (() => void) | undefined;
    let unsubChats: (() => void) | undefined;

    try {
      unsubTickets = onSnapshot(collection(db, 'support_tickets'), (snap) => {
        const firestoreTickets: SupportTicket[] = [];
        snap.forEach((docSnap) => {
          const tData = docSnap.data() as SupportTicket;
          if (tData && tData.ticketNumber) {
            firestoreTickets.push({ ...tData, id: tData.id || docSnap.id });
          }
        });

        firestoreTickets.sort(
          (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        );

        setAdminTickets((prev) => {
          const mergedMap = new Map<string, SupportTicket>();
          for (const t of prev) mergedMap.set(t.ticketNumber || t.id, t);
          for (const t of firestoreTickets) mergedMap.set(t.ticketNumber || t.id, t);
          const merged = Array.from(mergedMap.values()).sort(
            (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
          );
          setAdminTicketStats({
            total: merged.length,
            open: merged.filter((x) => x.status === 'Open' || x.status === 'Pending').length,
            inProgress: merged.filter((x) => x.status === 'In Progress').length,
            waitingForClient: merged.filter((x) => x.status === 'Waiting for Client').length,
            completed: merged.filter((x) => x.status === 'Completed' || x.status === 'Resolved').length,
            closed: merged.filter((x) => x.status === 'Closed').length
          });
          return merged;
        });

        if (cubesId) {
          const myTickets = firestoreTickets.filter(
            (t) =>
              (t.cubesId && t.cubesId.toLowerCase() === cubesId.toLowerCase()) ||
              (t.username && t.username.toLowerCase() === cubesId.toLowerCase())
          );
          if (myTickets.length > 0) {
            setClientTickets((prev) => {
              const map = new Map<string, SupportTicket>();
              for (const p of prev) map.set(p.ticketNumber || p.id, p);
              for (const m of myTickets) map.set(m.ticketNumber || m.id, m);
              const list = Array.from(map.values()).sort(
                (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
              );
              try {
                localStorage.setItem('cubix_client_cached_tickets', JSON.stringify(list));
              } catch (_) {}
              return list;
            });
          }
        }
      });
    } catch (_) {}

    try {
      unsubChats = onSnapshot(collection(db, 'cubix_ai_chats'), (snap) => {
        const sessions: AiClientSession[] = [];
        snap.forEach((docSnap) => {
          const sData = docSnap.data() as AiClientSession;
          if (sData && sData.cubesId) {
            sessions.push(sData);
          }
        });
        sessions.sort((a, b) => (b.clientNumber || 0) - (a.clientNumber || 0));
        setAllAiSessions(sessions);
      });
    } catch (_) {}

    let unsubVouches: (() => void) | undefined;
    try {
      unsubVouches = onSnapshot(collection(db, CUBIX_VOUCHES_COLLECTION), (snap) => {
        const loadedVouches: VouchItem[] = [];
        snap.forEach((docSnap) => {
          const vData = docSnap.data() as VouchItem;
          if (vData && vData.name && vData.feedback) {
            loadedVouches.push({
              ...vData,
              id: vData.id || docSnap.id
            });
          }
        });
        loadedVouches.sort(
          (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        );
        setVouchesList(loadedVouches);
      });
    } catch (_) {}

    return () => {
      if (unsubTickets) unsubTickets();
      if (unsubChats) unsubChats();
      if (unsubVouches) unsubVouches();
    };
  }, [cubesId]);

  // Sync client tickets from stored client tokens or cubesId on initial load
  useEffect(() => {
    const syncClientTickets = async () => {
      try {
        if (cubesId) {
          const resCubes = await fetch(`/api/tickets/by-cubes/${encodeURIComponent(cubesId)}`);
          if (resCubes.ok) {
            const jsonCubes = await resCubes.json();
            if (jsonCubes.success && Array.isArray(jsonCubes.tickets) && jsonCubes.tickets.length > 0) {
              setClientTickets((prev) => {
                const map = new Map<string, SupportTicket>();
                for (const p of prev) map.set(p.ticketNumber || p.id, p);
                for (const m of jsonCubes.tickets) map.set(m.ticketNumber || m.id, m);
                const list = Array.from(map.values()).sort(
                  (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
                );
                localStorage.setItem('cubix_client_cached_tickets', JSON.stringify(list));
                return list;
              });
            }
          }
        }

        const storedTokensRaw = localStorage.getItem('cubix_client_ticket_tokens');
        if (!storedTokensRaw) return;
        const tokens: string[] = JSON.parse(storedTokensRaw);
        if (!Array.isArray(tokens) || tokens.length === 0) return;

        const res = await fetch('/api/tickets/lookup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ clientTokens: tokens })
        });
        if (res.ok) {
          const json = await res.json();
          if (json.success && Array.isArray(json.tickets)) {
            setClientTickets((prev) => {
              const map = new Map<string, SupportTicket>();
              for (const p of prev) map.set(p.ticketNumber || p.id, p);
              for (const m of json.tickets) map.set(m.ticketNumber || m.id, m);
              const list = Array.from(map.values()).sort(
                (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
              );
              localStorage.setItem('cubix_client_cached_tickets', JSON.stringify(list));
              return list;
            });
          }
        }
      } catch (err) {
        console.warn('Notice: Could not sync returning client tickets:', err);
      }
    };
    syncClientTickets();
  }, [cubesId]);

  // Check database configuration status
  const checkDatabaseStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/database/status', { cache: 'no-store' });
      if (res.ok) {
        const json = await res.json();
        setDatabaseStatus(json);
      }
    } catch (_) {}
  }, []);

  // Helper to normalize metrics from Firestore format to tuples [label, value]
  const normalizeMetricsFromFirestore = (rep: any): any => {
    if (!rep) return {};
    const copy = JSON.parse(JSON.stringify(rep));
    for (const key of Object.keys(copy)) {
      if (copy[key] && Array.isArray(copy[key].metrics)) {
        copy[key].metrics = copy[key].metrics.map((m: any) => {
          if (Array.isArray(m)) return m;
          if (m && typeof m === 'object' && ('label' in m || 'value' in m)) {
            return [m.label || '', m.value || ''];
          }
          return m;
        });
      }
    }
    return copy;
  };

  // Helper to normalize metrics for Firestore (which forbids nested arrays)
  const normalizeMetricsForFirestore = (rep: any): any => {
    if (!rep) return {};
    const copy = JSON.parse(JSON.stringify(rep));
    for (const key of Object.keys(copy)) {
      if (copy[key] && Array.isArray(copy[key].metrics)) {
        copy[key].metrics = copy[key].metrics.map((m: any) => {
          if (Array.isArray(m)) {
            return { label: String(m[0] || ''), value: String(m[1] || '') };
          }
          return m;
        });
      }
    }
    return copy;
  };

  // Concurrency, hydration, and race-condition guards
  const hasHydratedRef = useRef(false);
  const isSavingRef = useRef(false);
  const activeFetchAbortRef = useRef<AbortController | null>(null);

  // Initial website data load and refresh handler (fallback when Firestore snapshot hasn't hydrated yet)
  const refreshData = useCallback(async (showIndicator = false) => {
    if (isSavingRef.current) return;
    if (hasHydratedRef.current && !showIndicator) return;
    try {
      if (showIndicator) setSyncing(true);
      const res = await fetch('/api/data', { cache: 'no-store' });
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          if (hasHydratedRef.current && !showIndicator) return;
          const docData = json.data;
          const cleanReputation = normalizeMetricsFromFirestore(docData.reputationData);
          const fullData: AppData = {
            ...defaultStore,
            ...docData,
            settings: {
              ...defaultStore.settings,
              ...(docData.settings || {}),
              heroBackground: {
                ...defaultStore.settings.heroBackground,
                ...(docData.settings?.heroBackground || {})
              }
            },
            reputationData: cleanReputation,
            founders: docData.founders || defaultStore.founders,
            projects: docData.projects || defaultStore.projects,
            services: docData.services || defaultStore.services,
            serviceProducts: docData.serviceProducts || defaultStore.serviceProducts || [],
            gallery: docData.gallery || defaultStore.gallery || [],
            financialRecords: docData.financialRecords || defaultStore.financialRecords,
            faqs: docData.faqs || defaultStore.faqs,
            vouches: Array.isArray(docData.vouches) ? docData.vouches : defaultStore.vouches || [],
            lastUpdated: docData.lastUpdated || new Date().toISOString()
          };

          if (Array.isArray(docData.vouches) && docData.vouches.length > 0) {
            setVouchesList((prev) => {
              const map = new Map<string, VouchItem>();
              for (const v of docData.vouches) map.set(v.id, v);
              for (const v of prev) map.set(v.id, v);
              return Array.from(map.values()).sort(
                (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
              );
            });
          }

          hasHydratedRef.current = true;
          setData(fullData);
          saveVerifiedSnapshot(fullData);
          setLastUpdated(docData.lastUpdated || new Date().toISOString());
          setError(null);
          setSyncError(null);
        }
      }
    } catch (err: any) {
      console.warn('[DataContext] Data load notice:', err.message);
    } finally {
      setLoading(false);
      if (showIndicator) setSyncing(false);
    }
  }, []);

  // Firebase Auth state listener
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      setIsFirebaseAuthed(!!user);
    });
    return () => unsubAuth();
  }, []);

  // Authoritative real-time Firestore synchronization listener
  useEffect(() => {
    let unsubDoc: (() => void) | undefined;
    try {
      const mainDocRef = doc(db, CUBIX_STORE_COLLECTION, CUBIX_MAIN_DOC);
      unsubDoc = onSnapshot(
        mainDocRef,
        (snapshot) => {
          if (snapshot.exists()) {
            const firestoreData = snapshot.data();
            // Guard against resetting admin forms while editing/saving
            if (isSavingRef.current) return;

            const cleanReputation = normalizeMetricsFromFirestore(firestoreData.reputationData);
            const fullData: AppData = {
              ...defaultStore,
              ...firestoreData,
              settings: {
                ...defaultStore.settings,
                ...(firestoreData.settings || {}),
                heroBackground: {
                  ...defaultStore.settings.heroBackground,
                  ...(firestoreData.settings?.heroBackground || {})
                }
              },
              aiAssistant: {
                ...defaultStore.aiAssistant,
                ...(firestoreData.aiAssistant || {})
              } as AiAssistantSettings,
              reputationData: cleanReputation,
              founders: firestoreData.founders || defaultStore.founders,
              projects: firestoreData.projects || defaultStore.projects,
              services: firestoreData.services || defaultStore.services,
              serviceProducts: firestoreData.serviceProducts || defaultStore.serviceProducts || [],
              gallery: firestoreData.gallery || defaultStore.gallery || [],
              financialRecords: firestoreData.financialRecords || defaultStore.financialRecords,
              faqs: firestoreData.faqs || defaultStore.faqs,
              vouches: Array.isArray(firestoreData.vouches) ? firestoreData.vouches : defaultStore.vouches || [],
              lastUpdated: firestoreData.lastUpdated || new Date().toISOString()
            };

            if (Array.isArray(firestoreData.vouches) && firestoreData.vouches.length > 0) {
              setVouchesList((prev) => {
                if (prev.length > 0) return prev;
                return [...firestoreData.vouches].sort(
                  (a: VouchItem, b: VouchItem) =>
                    new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
                );
              });
            }

            hasHydratedRef.current = true;
            setData(fullData);
            saveVerifiedSnapshot(fullData);
            setLastUpdated(firestoreData.lastUpdated || new Date().toISOString());
            setError(null);
            setSyncError(null);
            setLoading(false);
            setSyncing(false);
          } else {
            setLoading(false);
          }
        },
        (snapErr) => {
          console.warn('[DataContext] Real-time Firestore listener notice:', snapErr.message);
          refreshData(false);
        }
      );
    } catch (err: any) {
      console.warn('[DataContext] Firestore listener initialization notice:', err.message);
      refreshData(false);
    }

    return () => {
      if (unsubDoc) unsubDoc();
    };
  }, [refreshData]);

  useEffect(() => {
    checkDatabaseStatus();
  }, [checkDatabaseStatus]);

  // Validate session on load
  useEffect(() => {
    if (!adminToken) return;

    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${adminToken}` }
    })
      .then((res) => {
        if (!res.ok) throw new Error('Invalid token');
        return res.json();
      })
      .then((json) => {
        if (json.success && json.user) {
          setCurrentUser(json.user);
          sessionStorage.setItem('cubix_user_session', JSON.stringify(json.user));
          localStorage.setItem('cubix_user_session', JSON.stringify(json.user));
        }
      })
      .catch(() => {
        // Token expired or invalid
        setAdminToken(null);
        setCurrentUser(null);
        sessionStorage.removeItem('cubix_admin_token');
        localStorage.removeItem('cubix_admin_token');
        sessionStorage.removeItem('cubix_user_session');
        localStorage.removeItem('cubix_user_session');
      });
  }, [adminToken]);

  // Fetch accounts list (for admins)
  const fetchAccounts = useCallback(async () => {
    if (!adminToken || currentUser?.role !== 'admin') return;
    try {
      const res = await fetch('/api/admin/accounts', {
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.accounts) {
          setAccounts(json.accounts);
        }
      }
    } catch (err) {
      console.error('[DataContext] Error fetching accounts:', err);
    }
  }, [adminToken, currentUser?.role]);

  // Fetch admin submissions
  const fetchAdminSubmissions = useCallback(async () => {
    if (!adminToken) return;
    try {
      const res = await fetch('/api/admin/submissions', {
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      if (res.ok) {
        const json = await res.json();
        if (json.submissions) setAdminSubmissions(json.submissions);
      }
    } catch (err) {
      console.error('[DataContext] Error fetching submissions:', err);
    }
  }, [adminToken]);

  useEffect(() => {
    if (adminToken) {
      fetchAdminSubmissions();
      if (currentUser?.role === 'admin') {
        fetchAccounts();
      }
    }
  }, [adminToken, currentUser?.role, fetchAdminSubmissions, fetchAccounts]);

  // Public Project Brief submission
  const submitProjectBrief = async (brief: {
    name: string;
    email: string;
    discord?: string;
    projectType: string;
    budget?: string;
    timeline?: string;
    description: string;
    referenceLinks?: string;
  }) => {
    try {
      const res = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(brief)
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Failed to submit project brief.' };
      }
      return { success: true, submissionId: json.submission?.submissionId };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error submitting brief.' };
    }
  };

  // Public Contact message submission
  const submitContactMessage = async (msg: { name: string; email: string; message: string }) => {
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(msg)
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Failed to send message.' };
      }
      return { success: true, message: json.message };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error sending message.' };
    }
  };

  // Admin upload file (optimizes images into persistent self-contained data URLs for Firestore + syncs to server)
  const uploadAdminFile = async (fileName: string, fileData: string) => {
    try {
      if (fileData && fileData.startsWith('data:image/')) {
        const optimizedDataUrl = await optimizeImageDataUrl(fileData, 1280);
        // Fire background server backup without blocking or failing on serverless ephemeral disk
        fetch('/api/admin/upload', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {})
          },
          body: JSON.stringify({ fileName, fileData: optimizedDataUrl })
        }).catch(() => {});

        return {
          success: true,
          fileUrl: optimizedDataUrl,
          downloadUrl: optimizedDataUrl
        };
      }

      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {})
        },
        body: JSON.stringify({ fileName, fileData })
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Upload failed.' };
      }
      return { success: true, fileUrl: json.fileUrl, downloadUrl: json.downloadUrl };
    } catch (err: any) {
      return { success: false, error: err.message || 'Upload failed.' };
    }
  };

  // Update website content via Admin (persisting to Firebase Cloud Firestore)
  const updateAppData = async (updatedFields: Partial<AppData>): Promise<{ success: boolean; data?: AppData; error?: string }> => {
    if (activeFetchAbortRef.current) {
      activeFetchAbortRef.current.abort();
      activeFetchAbortRef.current = null;
    }

    isSavingRef.current = true;
    setSyncing(true);

    try {
      const nowIso = new Date().toISOString();
      const payload: any = {
        ...updatedFields,
        lastUpdated: nowIso,
        status: 'active'
      };

      if (payload.reputationData) {
        payload.reputationData = normalizeMetricsForFirestore(payload.reputationData);
      }

      // 1. Direct write to authoritative Firebase Cloud Firestore
      const mainDocRef = doc(db, CUBIX_STORE_COLLECTION, CUBIX_MAIN_DOC);
      await setDoc(mainDocRef, payload, { merge: true });

      // 2. Synchronize to server API endpoint for in-memory cache and disk backup
      try {
        await fetch('/api/admin/data', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {})
          },
          body: JSON.stringify(payload)
        });
      } catch (srvErr) {
        console.warn('[DataContext] Server sync notice (Firestore write succeeded):', srvErr);
      }

      const mergedSettings = updatedFields.settings
        ? {
            ...data.settings,
            ...updatedFields.settings,
            heroBackground: {
              ...defaultStore.settings.heroBackground,
              ...(data.settings?.heroBackground || {}),
              ...(updatedFields.settings.heroBackground || {})
            }
          }
        : data.settings;

      const confirmedData: AppData = {
        ...data,
        ...updatedFields,
        settings: mergedSettings,
        lastUpdated: nowIso
      };

      hasHydratedRef.current = true;
      setData(confirmedData);
      saveVerifiedSnapshot(confirmedData);
      setLastUpdated(nowIso);
      setSyncError(null);

      return { success: true, data: confirmedData };
    } catch (err: any) {
      console.error('[DataContext] Failed to save changes:', err);
      const errMsg = err.message || 'Database error: Could not save changes.';
      setSyncError(errMsg);
      return { success: false, error: errMsg };
    } finally {
      isSavingRef.current = false;
      setSyncing(false);
    }
  };

  // Helper for granular updates to Firestore
  const syncFirestoreStoreField = async (field: string, value: any) => {
    try {
      const nowIso = new Date().toISOString();
      const mainDocRef = doc(db, CUBIX_STORE_COLLECTION, CUBIX_MAIN_DOC);
      if (field === 'settings.ticketDiscordUrl') {
        const nextSettings = {
          ...(data.settings || defaultStore.settings),
          ticketDiscordUrl: value
        };
        await setDoc(mainDocRef, { settings: nextSettings, lastUpdated: nowIso }, { merge: true });
        saveVerifiedSnapshot({ ...data, settings: nextSettings, lastUpdated: nowIso });
      } else {
        await setDoc(mainDocRef, { [field]: value, lastUpdated: nowIso }, { merge: true });
        saveVerifiedSnapshot({ ...data, [field]: value, lastUpdated: nowIso } as AppData);
      }
    } catch (err: any) {
      console.warn('[Firestore] Granular field sync notice:', err.message);
    }
  };

  // Login handler (Accepts Username "OscarCruz" or Email "admin@cubix.std")
  const loginAdmin = async (identifier: string, pass: string) => {
    const trimmedId = identifier.trim();
    const trimmedPass = pass.trim();
    if (!trimmedId || !trimmedPass) {
      return { success: false, error: 'Please enter both Username/Email and Password.' };
    }

    try {
      let res: Response;
      try {
        res = await fetch('/api/admin/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({ identifier: trimmedId, password: trimmedPass })
        });
        // If 404 on /api/admin/login, retry with /api/auth/login
        if (res.status === 404) {
          res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json'
            },
            body: JSON.stringify({ identifier: trimmedId, password: trimmedPass })
          });
        }
      } catch (networkErr: any) {
        console.error('[Auth] Network request error:', networkErr);
        return {
          success: false,
          error: 'Could not connect to authentication server. Please check your network connection.'
        };
      }

      const text = await res.text();
      let json: any = null;
      try {
        json = JSON.parse(text);
      } catch (jsonErr) {
        console.error('[Auth] Server returned non-JSON response:', text.slice(0, 150));
        return {
          success: false,
          error:
            res.status === 405
              ? 'Backend API method not allowed (HTTP 405). The serverless API endpoint may still be deploying.'
              : res.status >= 500
              ? 'Authentication server error. Please try again shortly.'
              : text.trim().startsWith('<!')
              ? 'Authentication server returned an HTML page instead of JSON API response.'
              : 'Authentication server returned an unexpected response format.'
        };
      }

      if (res.ok && json?.success && json?.token) {
        const token = json.token;
        setAdminToken(token);
        setCurrentUser(json.user);
        sessionStorage.setItem('cubix_admin_token', token);
        localStorage.setItem('cubix_admin_token', token);
        sessionStorage.setItem('cubix_user_session', JSON.stringify(json.user));
        localStorage.setItem('cubix_user_session', JSON.stringify(json.user));
        return { success: true, user: json.user };
      }

      return {
        success: false,
        error:
          json?.error ||
          (res.status === 401
            ? 'Invalid username/email or password.'
            : 'Authentication failed. Please verify your credentials.')
      };
    } catch (err: any) {
      console.error('[Auth] Unexpected error during authentication:', err);
      return { success: false, error: 'Could not connect to authentication server.' };
    }
  };

  const logoutAdmin = () => {
    setAdminToken(null);
    setCurrentUser(null);
    sessionStorage.removeItem('cubix_admin_token');
    localStorage.removeItem('cubix_admin_token');
    sessionStorage.removeItem('cubix_user_session');
    localStorage.removeItem('cubix_user_session');
    try {
      auth.signOut();
    } catch (_) {}
  };

  // Account Management API calls
  const createAccount = async (accountData: {
    email: string;
    username?: string;
    name: string;
    password: string;
    role: 'admin' | 'founder';
    founderId?: string;
  }) => {
    try {
      const res = await fetch('/api/admin/accounts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(accountData)
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Failed to create account.' };
      }
      await fetchAccounts();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error creating account.' };
    }
  };

  const updateAccount = async (
    id: string,
    updates: {
      email?: string;
      username?: string;
      name?: string;
      role?: 'admin' | 'founder';
      status?: 'active' | 'inactive';
      founderId?: string;
    }
  ) => {
    try {
      const res = await fetch(`/api/admin/accounts/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(updates)
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Failed to update account.' };
      }
      await fetchAccounts();
      // If updating own profile, update state
      if (currentUser?.id === id) {
        setCurrentUser((prev) => (prev ? { ...prev, ...updates } : null));
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error updating account.' };
    }
  };

  const resetAccountPassword = async (id: string, newPassword: string) => {
    try {
      const res = await fetch(`/api/admin/accounts/${id}/reset-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({ newPassword })
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Failed to reset password.' };
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error resetting password.' };
    }
  };

  const deleteAccount = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/accounts/${id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${adminToken}`
        }
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Failed to delete account.' };
      }
      await fetchAccounts();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error deleting account.' };
    }
  };

  // Gallery CRUD
  const addGalleryItem = async (item: Partial<GalleryItem>) => {
    try {
      const res = await fetch('/api/admin/gallery', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(item)
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Failed to add gallery item.' };
      }
      if (json.item) {
        const nextGallery = [json.item, ...(data.gallery || [])];
        setData((prev) => ({
          ...prev,
          gallery: nextGallery
        }));
        await syncFirestoreStoreField('gallery', nextGallery);
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error adding gallery item.' };
    }
  };

  const deleteGalleryItem = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/gallery/${id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${adminToken}`
        }
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Failed to delete gallery item.' };
      }
      const nextGallery = (data.gallery || []).filter((g) => g.id !== id);
      setData((prev) => ({
        ...prev,
        gallery: nextGallery
      }));
      await syncFirestoreStoreField('gallery', nextGallery);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error deleting gallery item.' };
    }
  };

  // Founder Profile Update
  const updateFounderProfile = async (profile: Partial<Founder>) => {
    try {
      const res = await fetch('/api/founder/profile', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(profile)
      });
      const json = await res.json();
      if (!res.ok) {
        return { success: false, error: json.error || 'Failed to update profile.' };
      }
      if (json.profile) {
        const nextFounders = data.founders.map((f) => (f.id === json.profile.id ? json.profile : f));
        setData((prev) => ({
          ...prev,
          founders: nextFounders
        }));
        await syncFirestoreStoreField('founders', nextFounders);
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error updating profile.' };
    }
  };

  const updateSubmissionStatus = async (id: string, status: ProjectSubmission['status'], internalNotes?: string) => {
    try {
      const res = await fetch(`/api/admin/submissions/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({ status, internalNotes })
      });
      if (res.ok) {
        setAdminSubmissions((prev) =>
          prev.map((s) => (s.id === id || s.submissionId === id ? { ...s, status, internalNotes: internalNotes ?? s.internalNotes } : s))
        );
        return true;
      }
      return false;
    } catch (err) {
      return false;
    }
  };

  const deleteSubmission = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/submissions/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      if (res.ok) {
        setAdminSubmissions((prev) => prev.filter((s) => s.id !== id && s.submissionId !== id));
        return true;
      }
      return false;
    } catch (err) {
      return false;
    }
  };

  const resetToDefaults = async () => {
    try {
      const res = await fetch('/api/admin/reset-defaults', {
        method: 'POST',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      const json = await res.json();
      if (res.ok && json.data) {
        setData(json.data);
        return true;
      }
      return false;
    } catch (err) {
      return false;
    }
  };

  // ================= SUPPORT TICKETS (CLIENT) =================
  const createSupportTicket = async (ticketData: {
    email: string;
    username: string;
    discordId: string;
    serviceProductId?: string;
    serviceProductName: string;
    requestDetails: string;
    attachments?: any[];
  }) => {
    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ticketData)
      });
      const json = await res.json();
      if (res.ok && json.success && json.ticket) {
        const newTicket: SupportTicket = json.ticket;
        try {
          const storedTokensRaw = localStorage.getItem('cubix_client_ticket_tokens');
          const tokens: string[] = storedTokensRaw ? JSON.parse(storedTokensRaw) : [];
          if (newTicket.clientToken && !tokens.includes(newTicket.clientToken)) {
            tokens.push(newTicket.clientToken);
            localStorage.setItem('cubix_client_ticket_tokens', JSON.stringify(tokens));
          }
        } catch (_) {}

        setClientTickets((prev) => {
          const next = [newTicket, ...prev.filter((t) => t.ticketNumber !== newTicket.ticketNumber)];
          localStorage.setItem('cubix_client_cached_tickets', JSON.stringify(next));
          return next;
        });
        return { success: true, ticket: newTicket };
      }
      return { success: false, error: json.error || 'Failed to submit ticket.' };
    } catch (err: any) {
      return { success: false, error: 'Network error submitting ticket.' };
    }
  };

  const lookupClientTicket = async (ticketNumber: string, pinOrToken: string) => {
    try {
      const res = await fetch('/api/tickets/lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticketNumber, pin: pinOrToken, token: pinOrToken })
      });
      const json = await res.json();
      if (res.ok && json.success && json.ticket) {
        const foundTicket: SupportTicket = json.ticket;
        const foundToken = json.clientToken || foundTicket.clientToken;
        if (foundToken) {
          try {
            const storedTokensRaw = localStorage.getItem('cubix_client_ticket_tokens');
            const tokens: string[] = storedTokensRaw ? JSON.parse(storedTokensRaw) : [];
            if (!tokens.includes(foundToken)) {
              tokens.push(foundToken);
              localStorage.setItem('cubix_client_ticket_tokens', JSON.stringify(tokens));
            }
          } catch (_) {}
        }
        setClientTickets((prev) => {
          const next = [foundTicket, ...prev.filter((t) => t.ticketNumber !== foundTicket.ticketNumber)];
          localStorage.setItem('cubix_client_cached_tickets', JSON.stringify(next));
          return next;
        });
        return { success: true, ticket: foundTicket };
      }
      return { success: false, error: json.error || 'Ticket not found or invalid verification credentials.' };
    } catch (err: any) {
      return { success: false, error: 'Network error looking up ticket.' };
    }
  };

  const sendClientTicketMessage = async (ticketNumber: string, clientToken: string, message: string, attachments?: any[]) => {
    try {
      const res = await fetch(`/api/tickets/${encodeURIComponent(ticketNumber)}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-client-token': clientToken
        },
        body: JSON.stringify({ clientToken, message, attachments })
      });
      const json = await res.json();
      if (res.ok && json.success) {
        if (json.ticket) {
          setClientTickets((prev) => {
            const next = prev.map((t) => (t.ticketNumber === ticketNumber ? json.ticket : t));
            localStorage.setItem('cubix_client_cached_tickets', JSON.stringify(next));
            return next;
          });
        }
        return { success: true, message: json.message };
      }
      return { success: false, error: json.error || 'Failed to send message.' };
    } catch (err: any) {
      return { success: false, error: 'Network error sending message.' };
    }
  };

  // ================= SUPPORT TICKETS (ADMIN) =================
  const fetchAdminTickets = useCallback(async () => {
    if (!adminToken) return;
    try {
      const res = await fetch('/api/admin/tickets', {
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success) {
          setAdminTickets(json.tickets || []);
          setAdminTicketStats(json.stats || null);
        }
      }
    } catch (err) {
      console.warn('Failed to fetch admin tickets:', err);
    }
  }, [adminToken]);

  const updateAdminTicket = async (id: string, updates: { status?: TicketStatus; internalNotes?: string; note?: string }) => {
    if (!adminToken) return { success: false, error: 'Unauthorized.' };
    try {
      const res = await fetch(`/api/admin/tickets/${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(updates)
      });
      const json = await res.json();
      if (res.ok && json.success && json.ticket) {
        setAdminTickets((prev) => prev.map((t) => (t.id === id || t.ticketNumber === id ? json.ticket : t)));
        try {
          await setDoc(doc(db, 'support_tickets', json.ticket.id), JSON.parse(JSON.stringify(json.ticket)), { merge: true });
        } catch (_) {}
        return { success: true, ticket: json.ticket };
      }
      return { success: false, error: json.error || 'Failed to update ticket.' };
    } catch (err) {
      return { success: false, error: 'Network error.' };
    }
  };

  const sendAdminTicketReply = async (id: string, message: string, attachments?: any[], setStatus?: TicketStatus) => {
    if (!adminToken) return { success: false, error: 'Unauthorized.' };
    try {
      const res = await fetch(`/api/admin/tickets/${encodeURIComponent(id)}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({ message, attachments, setStatus })
      });
      const json = await res.json();
      if (res.ok && json.success && json.ticket) {
        setAdminTickets((prev) => prev.map((t) => (t.id === id || t.ticketNumber === id ? json.ticket : t)));
        try {
          await setDoc(doc(db, 'support_tickets', json.ticket.id), JSON.parse(JSON.stringify(json.ticket)), { merge: true });
        } catch (_) {}
        return { success: true, message: json.message };
      }
      return { success: false, error: json.error || 'Failed to send reply.' };
    } catch (err) {
      return { success: false, error: 'Network error.' };
    }
  };

  const deleteAdminTicket = async (id: string) => {
    if (!adminToken) return { success: false, error: 'Unauthorized.' };
    try {
      const target = adminTickets.find((t) => t.id === id || t.ticketNumber === id);
      const res = await fetch(`/api/admin/tickets/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      const json = await res.json();
      if (res.ok && json.success) {
        setAdminTickets((prev) => prev.filter((t) => t.id !== id && t.ticketNumber !== id));
        if (target) {
          try {
            await deleteDoc(doc(db, 'support_tickets', target.id));
          } catch (_) {}
        }
        return { success: true };
      }
      return { success: false, error: json.error || 'Failed to delete ticket.' };
    } catch (err) {
      return { success: false, error: 'Network error.' };
    }
  };

  // ================= AI ASSISTANT & TALK WITH FOUNDERS ACTIONS =================
  const sendAiChatMessage = async (text: string): Promise<{ success: boolean; reply?: string; error?: string }> => {
    const cleanText = String(text || '').trim();
    if (!cleanText) return { success: false, error: 'Please enter a message.' };

    setAiSending(true);
    try {
      const activeCubesId = cubesId || (await ensureCubesClient());
      const nowIso = new Date().toISOString();
      const userMsg: AiChatMessage = {
        id: 'msg_u_' + Date.now(),
        sender: 'user',
        text: cleanText,
        createdAt: nowIso
      };

      const updatedWithUser = [...aiMessages, userMsg];
      setAiMessages(updatedWithUser);

      const numMatch = activeCubesId.match(/(\d+)/);
      const clientNumber = numMatch ? parseInt(numMatch[1], 10) : 1;

      try {
        await setDoc(
          doc(db, 'cubix_ai_chats', activeCubesId),
          {
            cubesId: activeCubesId,
            clientNumber,
            messages: updatedWithUser,
            updatedAt: nowIso
          },
          { merge: true }
        );
      } catch (_) {}

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cubesId: activeCubesId,
          message: cleanText,
          history: updatedWithUser.slice(-10)
        })
      });

      const json = await res.json();
      const replyText =
        res.ok && json.success && json.reply
          ? String(json.reply)
          : `Hello ${activeCubesId}! I've noted your message. If you'd like direct assistance from our Founders, click the "Talk With Founders" button to create a priority support request.`;

      const aiMsg: AiChatMessage = {
        id: 'msg_ai_' + (Date.now() + 1),
        sender: 'ai',
        text: replyText,
        createdAt: new Date().toISOString()
      };

      const finalMessages = [...updatedWithUser, aiMsg];
      setAiMessages(finalMessages);

      try {
        await setDoc(
          doc(db, 'cubix_ai_chats', activeCubesId),
          {
            cubesId: activeCubesId,
            clientNumber,
            messages: finalMessages,
            updatedAt: new Date().toISOString()
          },
          { merge: true }
        );
      } catch (_) {}

      return { success: true, reply: replyText };
    } catch (err: any) {
      return { success: false, error: err.message || 'Could not reach AI Assistant.' };
    } finally {
      setAiSending(false);
    }
  };

  const clearAiChat = async (): Promise<void> => {
    const activeCubesId = cubesId || (await ensureCubesClient());
    const nowIso = new Date().toISOString();
    const welcomeText =
      data?.aiAssistant?.welcomeMessage ||
      defaultStore.aiAssistant?.welcomeMessage ||
      'Hello! Welcome to Cubix Studio AI Assistant. How can I help you today?';
    const initialMsg: AiChatMessage = {
      id: 'ai_welcome_' + Date.now(),
      sender: 'ai',
      text: welcomeText,
      createdAt: nowIso
    };
    setAiMessages([initialMsg]);
    try {
      await setDoc(
        doc(db, 'cubix_ai_chats', activeCubesId),
        {
          cubesId: activeCubesId,
          messages: [initialMsg],
          updatedAt: nowIso
        },
        { merge: true }
      );
    } catch (_) {}
  };

  const submitTalkWithFounders = async (
    requestDetails?: string
  ): Promise<{ success: boolean; ticket?: SupportTicket; error?: string }> => {
    try {
      const activeCubesId = cubesId || (await ensureCubesClient());
      const userChatSummary = aiMessages
        .filter((m) => m.sender === 'user')
        .slice(-3)
        .map((m) => m.text)
        .join(' | ');
      const finalDetails =
        (requestDetails && requestDetails.trim()) ||
        (userChatSummary
          ? `Talk With Founders Request from ${activeCubesId}. Recent inquiry: ${userChatSummary}`
          : `Client ${activeCubesId} requested a direct conversation with the Cubix Studio Founders.`);

      const res = await fetch('/api/tickets/founder-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cubesId: activeCubesId,
          requestDetails: finalDetails
        })
      });

      const json = await res.json();
      if (res.ok && json.success && json.ticket) {
        const createdTicket: SupportTicket = json.ticket;
        try {
          await setDoc(
            doc(db, 'support_tickets', createdTicket.id),
            JSON.parse(JSON.stringify(createdTicket)),
            { merge: true }
          );
        } catch (_) {}

        setClientTickets((prev) => {
          const next = [createdTicket, ...prev.filter((t) => t.ticketNumber !== createdTicket.ticketNumber)];
          try {
            localStorage.setItem('cubix_client_cached_tickets', JSON.stringify(next));
          } catch (_) {}
          return next;
        });

        return { success: true, ticket: createdTicket };
      }

      return { success: false, error: json.error || 'Could not submit request.' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error submitting founder request.' };
    }
  };

  const sendCubesTicketReply = async (
    ticketId: string,
    message: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const activeCubesId = cubesId || (await ensureCubesClient());
      const res = await fetch(`/api/tickets/cubes-reply/${encodeURIComponent(ticketId)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cubesId: activeCubesId, message })
      });
      const json = await res.json();
      if (res.ok && json.success && json.ticket) {
        try {
          await setDoc(
            doc(db, 'support_tickets', json.ticket.id),
            JSON.parse(JSON.stringify(json.ticket)),
            { merge: true }
          );
        } catch (_) {}
        setClientTickets((prev) =>
          prev.map((t) => (t.id === ticketId || t.ticketNumber === ticketId ? json.ticket : t))
        );
        return { success: true };
      }
      return { success: false, error: json.error || 'Failed to send reply.' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error.' };
    }
  };

  // ================= ADMIN SERVICES & PRODUCTS =================
  const addServiceProduct = async (item: Partial<ServiceProductItem>) => {
    if (!adminToken) return { success: false, error: 'Unauthorized.' };
    try {
      const res = await fetch('/api/admin/service-products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(item)
      });
      const json = await res.json();
      if (res.ok && json.success && json.item) {
        const nextProducts = [...(data.serviceProducts || []), json.item];
        setData((prev) => ({
          ...prev,
          serviceProducts: nextProducts
        }));
        await syncFirestoreStoreField('serviceProducts', nextProducts);
        return { success: true, item: json.item };
      }
      return { success: false, error: json.error || 'Failed to add item.' };
    } catch (err) {
      return { success: false, error: 'Network error.' };
    }
  };

  const updateServiceProduct = async (id: string, updates: Partial<ServiceProductItem>) => {
    if (!adminToken) return { success: false, error: 'Unauthorized.' };
    try {
      const res = await fetch(`/api/admin/service-products/${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(updates)
      });
      const json = await res.json();
      if (res.ok && json.success && json.item) {
        const nextProducts = (data.serviceProducts || []).map((p) => (p.id === id ? json.item : p));
        setData((prev) => ({
          ...prev,
          serviceProducts: nextProducts
        }));
        await syncFirestoreStoreField('serviceProducts', nextProducts);
        return { success: true, item: json.item };
      }
      return { success: false, error: json.error || 'Failed to update item.' };
    } catch (err) {
      return { success: false, error: 'Network error.' };
    }
  };

  const deleteServiceProduct = async (id: string) => {
    if (!adminToken) return { success: false, error: 'Unauthorized.' };
    try {
      const res = await fetch(`/api/admin/service-products/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      const json = await res.json();
      if (res.ok && json.success) {
        const nextProducts = (data.serviceProducts || []).filter((p) => p.id !== id);
        setData((prev) => ({
          ...prev,
          serviceProducts: nextProducts
        }));
        await syncFirestoreStoreField('serviceProducts', nextProducts);
        return { success: true };
      }
      return { success: false, error: json.error || 'Failed to delete item.' };
    } catch (err) {
      return { success: false, error: 'Network error.' };
    }
  };

  const reorderServiceProducts = async (orderedIds: string[]) => {
    if (!adminToken) return { success: false, error: 'Unauthorized.' };
    try {
      const res = await fetch('/api/admin/service-products/reorder', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({ orderedIds })
      });
      const json = await res.json();
      if (res.ok && json.success && json.items) {
        setData((prev) => ({
          ...prev,
          serviceProducts: json.items
        }));
        await syncFirestoreStoreField('serviceProducts', json.items);
        return { success: true };
      }
      return { success: false, error: json.error || 'Failed to reorder items.' };
    } catch (err) {
      return { success: false, error: 'Network error.' };
    }
  };

  const saveTicketDiscordUrl = async (url: string) => {
    if (!adminToken) return { success: false, error: 'Unauthorized. Admin credentials required.' };
    const trimmed = (url || '').trim();
    if (!trimmed) {
      return { success: false, error: 'Discord URL cannot be empty.' };
    }
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      return { success: false, error: 'The URL must start with https:// or http://' };
    }

    setSyncing(true);
    setSyncError(null);
    try {
      const res = await fetch('/api/admin/ticket-settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({ ticketDiscordUrl: trimmed })
      });
      const json = await res.json();
      if (res.ok && json.success) {
        setData((prev) => ({
          ...prev,
          settings: {
            ...prev.settings,
            ticketDiscordUrl: trimmed
          }
        }));
        await syncFirestoreStoreField('settings.ticketDiscordUrl', trimmed);
        setSyncError(null);
        return { success: true };
      }
      const errMsg = json.error || 'Failed to save ticket destination URL.';
      setSyncError(errMsg);
      return { success: false, error: errMsg };
    } catch (err: any) {
      const errMsg = err.message || 'Network error saving ticket URL.';
      setSyncError(errMsg);
      return { success: false, error: errMsg };
    } finally {
      setSyncing(false);
    }
  };

  // ================= CUBIX VOUCHES & REPUTATION SYSTEM =================
  const vouches = useMemo(() => {
    const map = new Map<string, VouchItem>();
    if (Array.isArray(data.vouches)) {
      for (const v of data.vouches) {
        if (v && v.id) map.set(v.id, v);
      }
    }
    for (const v of vouchesList) {
      if (v && v.id) map.set(v.id, v);
    }
    return Array.from(map.values()).sort(
      (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }, [data.vouches, vouchesList]);

  const approvedVouches = useMemo(() => {
    return vouches
      .filter((v) => v.status === 'approved')
      .sort(
        (a, b) =>
          new Date(b.approvedAt || b.createdAt || 0).getTime() -
          new Date(a.approvedAt || a.createdAt || 0).getTime()
      );
  }, [vouches]);

  const latestApprovedVouch = useMemo<VouchItem | null>(() => {
    return approvedVouches.length > 0 ? approvedVouches[0] : null;
  }, [approvedVouches]);

  const vouchStats = useMemo<VouchStats>(() => {
    const totalVouches = approvedVouches.length;
    if (totalVouches === 0) {
      return {
        totalVouches: 0,
        averageRating: 0,
        formattedRating: '0.0/5'
      };
    }
    const sum = approvedVouches.reduce((acc, v) => acc + (Number(v.rating) || 0), 0);
    const averageRating = Number((sum / totalVouches).toFixed(1));
    return {
      totalVouches,
      averageRating,
      formattedRating: `${averageRating.toFixed(1)}/5`
    };
  }, [approvedVouches]);

  const vouchProductOptions = useMemo<string[]>(() => {
    const seen = new Set<string>();
    const options: string[] = [];

    const addOption = (raw?: string) => {
      const clean = String(raw || '').trim();
      if (!clean || clean.toLowerCase() === 'other') return;
      const key = clean.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        options.push(clean);
      }
    };

    for (const sp of data.serviceProducts || []) {
      if (sp.available !== false) addOption(sp.name);
    }
    for (const srv of data.services || []) {
      if (srv.published !== false) addOption(srv.name);
    }
    for (const proj of data.projects || []) {
      if (proj.published !== false) addOption(proj.name);
    }

    options.push('Other');
    return options;
  }, [data.serviceProducts, data.services, data.projects]);

  const submitVouch = async (payload: {
    name: string;
    discordUsername: string;
    productOrService: string;
    feedback: string;
    rating: number;
  }): Promise<{ success: boolean; vouch?: VouchItem; message?: string; error?: string }> => {
    const cleanName = String(payload.name || '').trim();
    const cleanDiscord = String(payload.discordUsername || '').trim();
    const cleanProduct = String(payload.productOrService || '').trim();
    const cleanFeedback = String(payload.feedback || '').trim();
    const numericRating = Math.round(Number(payload.rating));

    if (!cleanName || cleanName.length < 2) {
      return { success: false, error: 'Please enter your name (at least 2 characters).' };
    }
    if (!cleanDiscord || cleanDiscord.length < 2) {
      return { success: false, error: 'Discord Username is required.' };
    }
    if (!cleanProduct) {
      return { success: false, error: 'Please select a Product or Service purchased.' };
    }
    if (!cleanFeedback || cleanFeedback.length < 10) {
      return { success: false, error: 'Please write at least 10 characters in your vouch feedback.' };
    }
    if (!Number.isInteger(numericRating) || numericRating < 1 || numericRating > 5) {
      return { success: false, error: 'Please select a star rating between 1 and 5.' };
    }

    try {
      const res = await fetch('/api/vouches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: cleanName,
          discordUsername: cleanDiscord,
          productOrService: cleanProduct,
          feedback: cleanFeedback,
          rating: numericRating
        })
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        return {
          success: false,
          error: json.error || 'Could not submit your vouch. Please try again.'
        };
      }

      const createdVouch: VouchItem = json.vouch;
      // Ensure client-side Firestore write to vouches/{id} with pending status
      try {
        await setDoc(doc(db, CUBIX_VOUCHES_COLLECTION, createdVouch.id), {
          id: createdVouch.id,
          name: createdVouch.name,
          discordUsername: createdVouch.discordUsername,
          productOrService: createdVouch.productOrService,
          feedback: createdVouch.feedback,
          rating: createdVouch.rating,
          status: 'pending',
          isVerified: false,
          createdAt: createdVouch.createdAt,
          approvedAt: null,
          updatedAt: createdVouch.updatedAt
        });
      } catch (_) {}

      setVouchesList((prev) => {
        const next = [createdVouch, ...prev.filter((v) => v.id !== createdVouch.id)];
        return next;
      });

      return {
        success: true,
        vouch: createdVouch,
        message: json.message || 'Your vouch has been submitted successfully and is awaiting approval.'
      };
    } catch (err: any) {
      return {
        success: false,
        error: err.message || 'Network error while submitting vouch.'
      };
    }
  };

  const updateVouchAdmin = async (
    id: string,
    updates: {
      status?: VouchStatus;
      isVerified?: boolean;
      name?: string;
      discordUsername?: string;
      productOrService?: string;
      feedback?: string;
      rating?: number;
    }
  ): Promise<{ success: boolean; vouch?: VouchItem; error?: string }> => {
    if (!adminToken) return { success: false, error: 'Unauthorized.' };
    try {
      const res = await fetch(`/api/admin/vouches/${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify(updates)
      });
      const json = await res.json();
      if (res.ok && json.success && json.vouch) {
        const updatedVouch: VouchItem = json.vouch;
        try {
          await setDoc(doc(db, CUBIX_VOUCHES_COLLECTION, updatedVouch.id), updatedVouch, { merge: true });
        } catch (_) {}

        const nextVouches = vouches.map((v) => (v.id === id ? updatedVouch : v));
        setVouchesList(nextVouches);
        setData((prev) => ({ ...prev, vouches: nextVouches }));
        await syncFirestoreStoreField('vouches', nextVouches);
        return { success: true, vouch: updatedVouch };
      }
      return { success: false, error: json.error || 'Failed to update vouch.' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error updating vouch.' };
    }
  };

  const deleteVouchAdmin = async (id: string): Promise<{ success: boolean; error?: string }> => {
    if (!adminToken) return { success: false, error: 'Unauthorized.' };
    try {
      const res = await fetch(`/api/admin/vouches/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${adminToken}`
        }
      });
      const json = await res.json();
      if (res.ok && json.success) {
        try {
          await deleteDoc(doc(db, CUBIX_VOUCHES_COLLECTION, id));
        } catch (_) {}

        const nextVouches = vouches.filter((v) => v.id !== id);
        setVouchesList(nextVouches);
        setData((prev) => ({ ...prev, vouches: nextVouches }));
        await syncFirestoreStoreField('vouches', nextVouches);
        return { success: true };
      }
      return { success: false, error: json.error || 'Failed to delete vouch.' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error deleting vouch.' };
    }
  };

  const isUserAdmin = Boolean(adminToken && (!currentUser || currentUser.role === 'admin'));
  const isUserFounder = Boolean(adminToken && currentUser?.role === 'founder');

  return (
    <DataContext.Provider
      value={{
        data,
        loading,
        syncing,
        syncError,
        clearSyncError,
        databaseStatus,
        lastUpdated,
        error,
        refreshData,
        updateAppData,
        submitProjectBrief,
        submitContactMessage,
        uploadAdminFile,
        adminToken,
        currentUser,
        firebaseUser,
        isFirebaseAuthed,
        isAdmin: isUserAdmin,
        isFounder: isUserFounder,
        loginAdmin,
        logoutAdmin,
        accounts,
        fetchAccounts,
        createAccount,
        updateAccount,
        resetAccountPassword,
        deleteAccount,
        adminSubmissions,
        fetchAdminSubmissions,
        updateSubmissionStatus,
        deleteSubmission,
        resetToDefaults,
        addGalleryItem,
        deleteGalleryItem,
        updateFounderProfile,
        // Support Tickets (Client)
        clientTickets,
        createSupportTicket,
        lookupClientTicket,
        sendClientTicketMessage,
        // Support Tickets (Admin)
        adminTickets,
        adminTicketStats,
        fetchAdminTickets,
        updateAdminTicket,
        sendAdminTicketReply,
        deleteAdminTicket,
        // Services & Products (Admin)
        addServiceProduct,
        updateServiceProduct,
        deleteServiceProduct,
        reorderServiceProducts,
        // Ticket Setting
        saveTicketDiscordUrl,
        // AI Assistant & Sequential Client Identity
        cubesId,
        ensureCubesClient,
        aiMessages,
        aiSending,
        allAiSessions,
        sendAiChatMessage,
        clearAiChat,
        submitTalkWithFounders,
        sendCubesTicketReply,
        // Cubix Vouches & Reputation System
        vouches,
        approvedVouches,
        latestApprovedVouch,
        vouchStats,
        vouchProductOptions,
        submitVouch,
        updateVouchAdmin,
        deleteVouchAdmin
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within DataProvider');
  }
  return context;
};
