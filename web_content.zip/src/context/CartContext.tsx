import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { CartItem, Product } from '../types/store';
import { getEffectivePrice } from '../lib/formatters';

interface CartContextValue {
  items: CartItem[];
  isCartOpen: boolean;
  totalItems: number;
  subtotal: number;
  totalSavings: number;
  openCart: () => void;
  closeCart: () => void;
  addToCart: (
    product: Product,
    selectedSize: string,
    selectedColor: string,
    quantity?: number
  ) => { ok: boolean; message?: string };
  removeFromCart: (productId: string, selectedSize: string, selectedColor: string) => void;
  updateQuantity: (
    productId: string,
    selectedSize: string,
    selectedColor: string,
    quantity: number
  ) => void;
  clearCart: () => void;
}

const CART_STORAGE_KEY = 'fashionhub_shopping_bag_v1';
const LEGACY_CART_STORAGE_KEY = 'stylehub_shopping_bag_v1';
const MAX_DISTINCT_CHECKOUT_ITEMS = 6;

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const raw =
        localStorage.getItem(CART_STORAGE_KEY) ||
        localStorage.getItem(LEGACY_CART_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch {
      // Ignore storage quota issues
    }
  }, [items]);

  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);

  const addToCart = (
    product: Product,
    selectedSize: string,
    selectedColor: string,
    quantity = 1
  ): { ok: boolean; message?: string } => {
    if (product.stock <= 0) {
      return { ok: false, message: 'This item is currently out of stock.' };
    }

    const effectivePrice = getEffectivePrice(product);
    const existingIndex = items.findIndex(
      (i) =>
        i.productId === product.id &&
        i.selectedSize === selectedSize &&
        i.selectedColor === selectedColor
    );

    if (existingIndex === -1 && items.length >= MAX_DISTINCT_CHECKOUT_ITEMS) {
      return {
        ok: false,
        message: `You can check out up to ${MAX_DISTINCT_CHECKOUT_ITEMS} distinct items per order.`,
      };
    }

    setItems((prev) => {
      const idx = prev.findIndex(
        (i) =>
          i.productId === product.id &&
          i.selectedSize === selectedSize &&
          i.selectedColor === selectedColor
      );

      if (idx > -1) {
        const next = [...prev];
        const target = next[idx];
        const newQty = Math.min(product.stock, target.quantity + quantity);
        next[idx] = {
          ...target,
          price: product.price,
          discountPrice: product.discountPrice,
          effectivePrice,
          maxStock: product.stock,
          quantity: newQty,
        };
        return next;
      }

      return [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          imageUrl: product.imageUrl,
          category: product.category,
          price: product.price,
          discountPrice: product.discountPrice,
          effectivePrice,
          selectedSize,
          selectedColor,
          quantity: Math.min(product.stock, Math.max(1, quantity)),
          maxStock: product.stock,
        },
      ];
    });

    return { ok: true };
  };

  const removeFromCart = (productId: string, selectedSize: string, selectedColor: string) => {
    setItems((prev) =>
      prev.filter(
        (i) =>
          !(
            i.productId === productId &&
            i.selectedSize === selectedSize &&
            i.selectedColor === selectedColor
          )
      )
    );
  };

  const updateQuantity = (
    productId: string,
    selectedSize: string,
    selectedColor: string,
    quantity: number
  ) => {
    if (quantity <= 0) {
      removeFromCart(productId, selectedSize, selectedColor);
      return;
    }

    setItems((prev) =>
      prev.map((item) => {
        if (
          item.productId === productId &&
          item.selectedSize === selectedSize &&
          item.selectedColor === selectedColor
        ) {
          return {
            ...item,
            quantity: Math.min(item.maxStock, Math.max(1, quantity)),
          };
        }
        return item;
      })
    );
  };

  const clearCart = () => setItems([]);

  const { totalItems, subtotal, totalSavings } = useMemo(() => {
    return items.reduce(
      (acc, item) => {
        const qty = item.quantity;
        const unit = item.effectivePrice;
        const orig = item.price;
        acc.totalItems += qty;
        acc.subtotal += unit * qty;
        if (orig > unit) {
          acc.totalSavings += (orig - unit) * qty;
        }
        return acc;
      },
      { totalItems: 0, subtotal: 0, totalSavings: 0 }
    );
  }, [items]);

  return (
    <CartContext.Provider
      value={{
        items,
        isCartOpen,
        totalItems,
        subtotal,
        totalSavings,
        openCart,
        closeCart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
