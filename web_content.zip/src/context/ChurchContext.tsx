import React, { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import { Visitor, ServiceInfo, TabletRole, AltarTheme, FontSizeLevel } from '../types';
import { churchAudio } from '../utils/audio';

interface ChurchContextType {
  role: TabletRole;
  setRole: (role: TabletRole) => void;
  service: ServiceInfo;
  visitors: Visitor[];
  connectionStatus: 'connected' | 'connecting' | 'disconnected';
  isAudioEnabled: boolean;
  setIsAudioEnabled: (val: boolean) => void;
  altarTheme: AltarTheme;
  setAltarTheme: (theme: AltarTheme) => void;
  fontSizeLevel: FontSizeLevel;
  setFontSizeLevel: (size: FontSizeLevel) => void;
  activeNewVisitorBanner: Visitor | null;
  dismissNewVisitorBanner: () => void;
  addVisitor: (data: Omit<Visitor, 'id' | 'registeredAt' | 'status' | 'serviceId'>) => Promise<boolean>;
  markAsPresented: (id: string) => void;
  markAsPending: (id: string) => void;
  togglePin: (id: string) => void;
  deleteVisitor: (id: string) => void;
  updateService: (updates: Partial<ServiceInfo>) => void;
  unreadCountForAltar: number;
  resetUnreadCount: () => void;
  lastConnectedAt: Date | null;
}

const ChurchContext = createContext<ChurchContextType | null>(null);

const DEFAULT_SERVICE: ServiceInfo = {
  id: 'culto-padrao',
  title: 'Culto de Celebração',
  leaderName: 'Pastor Dirigente',
  date: new Date().toISOString().split('T')[0],
  churchName: 'Nossa Igreja',
  notes: 'Recepção e Púlpito Conectados',
};

export const ChurchProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Role stored per device
  const [role, setRoleState] = useState<TabletRole>(() => {
    const saved = localStorage.getItem('church_tablet_role');
    return (saved as TabletRole) || 'reception';
  });

  const [service, setService] = useState<ServiceInfo>(DEFAULT_SERVICE);
  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'connecting' | 'disconnected'>('connecting');
  const [lastConnectedAt, setLastConnectedAt] = useState<Date | null>(null);

  // Audio preference
  const [isAudioEnabled, setIsAudioEnabledState] = useState<boolean>(() => {
    const saved = localStorage.getItem('church_audio_enabled');
    return saved !== null ? saved === 'true' : true;
  });

  // Altar theme & font size
  const [altarTheme, setAltarThemeState] = useState<AltarTheme>(() => {
    const saved = localStorage.getItem('church_altar_theme');
    return (saved as AltarTheme) || 'pulpito_dark';
  });

  const [fontSizeLevel, setFontSizeLevelState] = useState<FontSizeLevel>(() => {
    const saved = localStorage.getItem('church_font_size');
    return (saved as FontSizeLevel) || 'grande';
  });

  // Notification for incoming visitor (specifically for Altar view)
  const [activeNewVisitorBanner, setActiveNewVisitorBanner] = useState<Visitor | null>(null);
  const [unreadCountForAltar, setUnreadCountForAltar] = useState<number>(0);

  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);
  const bannerTimeoutRef = useRef<number | null>(null);
  const roleRef = useRef<TabletRole>(role);
  const audioEnabledRef = useRef<boolean>(isAudioEnabled);

  useEffect(() => {
    roleRef.current = role;
  }, [role]);

  useEffect(() => {
    audioEnabledRef.current = isAudioEnabled;
  }, [isAudioEnabled]);

  const setRole = (newRole: TabletRole) => {
    setRoleState(newRole);
    localStorage.setItem('church_tablet_role', newRole);
    if (newRole === 'altar') {
      setUnreadCountForAltar(0);
    }
  };

  const setIsAudioEnabled = (val: boolean) => {
    setIsAudioEnabledState(val);
    localStorage.setItem('church_audio_enabled', String(val));
  };

  const setAltarTheme = (theme: AltarTheme) => {
    setAltarThemeState(theme);
    localStorage.setItem('church_altar_theme', theme);
  };

  const setFontSizeLevel = (size: FontSizeLevel) => {
    setFontSizeLevelState(size);
    localStorage.setItem('church_font_size', size);
  };

  const dismissNewVisitorBanner = () => {
    setActiveNewVisitorBanner(null);
  };

  const resetUnreadCount = () => {
    setUnreadCountForAltar(0);
  };

  // Helper to trigger alert when new visitor arrives
  const notifyNewVisitor = useCallback((visitor: Visitor) => {
    if (roleRef.current === 'altar') {
      setActiveNewVisitorBanner(visitor);
      setUnreadCountForAltar((prev) => prev + 1);

      if (audioEnabledRef.current) {
        churchAudio.playVisitorArrivalBell();
      }

      if (bannerTimeoutRef.current) {
        window.clearTimeout(bannerTimeoutRef.current);
      }
      bannerTimeoutRef.current = window.setTimeout(() => {
        setActiveNewVisitorBanner(null);
      }, 9000);
    }
  }, []);

  // Connect WebSocket
  const connectWebSocket = useCallback(() => {
    if (socketRef.current?.readyState === WebSocket.OPEN) return;

    setConnectionStatus('connecting');

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    const ws = new WebSocket(wsUrl);
    socketRef.current = ws;

    ws.onopen = () => {
      setConnectionStatus('connected');
      setLastConnectedAt(new Date());
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        switch (msg.type) {
          case 'INIT_STATE':
            if (msg.data.service) setService(msg.data.service);
            if (Array.isArray(msg.data.visitors)) setVisitors(msg.data.visitors);
            break;

          case 'VISITOR_ADDED': {
            const newVisitor: Visitor = msg.visitor;
            setVisitors((prev) => {
              if (prev.some((v) => v.id === newVisitor.id)) return prev;
              return [newVisitor, ...prev];
            });
            notifyNewVisitor(newVisitor);
            break;
          }

          case 'VISITOR_UPDATED': {
            const updated: Visitor = msg.visitor;
            setVisitors((prev) => prev.map((v) => (v.id === updated.id ? updated : v)));
            break;
          }

          case 'VISITOR_DELETED': {
            const { id } = msg;
            setVisitors((prev) => prev.filter((v) => v.id !== id));
            break;
          }

          case 'SERVICE_UPDATED': {
            setService(msg.service);
            break;
          }

          default:
            break;
        }
      } catch (err) {
        console.error('Failed to parse WebSocket message', err);
      }
    };

    ws.onclose = () => {
      setConnectionStatus('disconnected');
      socketRef.current = null;
      // Auto-reconnect after 3 seconds
      if (reconnectTimeoutRef.current) {
        window.clearTimeout(reconnectTimeoutRef.current);
      }
      reconnectTimeoutRef.current = window.setTimeout(() => {
        connectWebSocket();
      }, 3000);
    };

    ws.onerror = (err) => {
      console.warn('WebSocket encountered error, falling back to polling...', err);
      ws.close();
    };
  }, [notifyNewVisitor]);

  // Initial connect & heartbeat
  useEffect(() => {
    connectWebSocket();

    // Fallback REST fetch on mount to guarantee immediate data
    fetch('/api/state')
      .then((res) => res.json())
      .then((data) => {
        if (data.service) setService(data.service);
        if (Array.isArray(data.visitors)) setVisitors(data.visitors);
      })
      .catch((err) => console.warn('REST initial fetch note:', err));

    // Ping interval to keep connection alive
    const pingInterval = setInterval(() => {
      if (socketRef.current?.readyState === WebSocket.OPEN) {
        socketRef.current.send(JSON.stringify({ type: 'PING' }));
      }
    }, 25000);

    return () => {
      clearInterval(pingInterval);
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      if (bannerTimeoutRef.current) clearTimeout(bannerTimeoutRef.current);
      if (socketRef.current) socketRef.current.close();
    };
  }, [connectWebSocket]);

  // Add Visitor action (from reception)
  const addVisitor = async (
    data: Omit<Visitor, 'id' | 'registeredAt' | 'status' | 'serviceId'>
  ): Promise<boolean> => {
    try {
      if (isAudioEnabled) {
        churchAudio.playSendConfirmation();
      }

      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.send(
          JSON.stringify({
            type: 'ADD_VISITOR',
            data,
          })
        );
        return true;
      }

      // Fallback to HTTP POST if socket offline
      const res = await fetch('/api/visitors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        const created = await res.json();
        setVisitors((prev) => [created, ...prev]);
        return true;
      }
      return false;
    } catch (e) {
      console.error('Error adding visitor:', e);
      return false;
    }
  };

  // Mark visitor as presented by church leader
  const markAsPresented = (id: string) => {
    if (isAudioEnabled) {
      churchAudio.playPresentationSuccess();
    }
    const updates = { status: 'presented' as const };

    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(
        JSON.stringify({
          type: 'UPDATE_VISITOR',
          data: { id, updates },
        })
      );
    } else {
      fetch(`/api/visitors/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    }

    setVisitors((prev) =>
      prev.map((v) =>
        v.id === id ? { ...v, status: 'presented', presentedAt: new Date().toISOString() } : v
      )
    );
  };

  // Revert back to pending
  const markAsPending = (id: string) => {
    const updates = { status: 'pending' as const, presentedAt: undefined };
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(
        JSON.stringify({
          type: 'UPDATE_VISITOR',
          data: { id, updates },
        })
      );
    } else {
      fetch(`/api/visitors/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    }
    setVisitors((prev) =>
      prev.map((v) => (v.id === id ? { ...v, status: 'pending', presentedAt: undefined } : v))
    );
  };

  // Toggle Pinned status (e.g. guest pastor, special visitor)
  const togglePin = (id: string) => {
    const current = visitors.find((v) => v.id === id);
    if (!current) return;
    const updates = { isPinned: !current.isPinned };

    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(
        JSON.stringify({
          type: 'UPDATE_VISITOR',
          data: { id, updates },
        })
      );
    } else {
      fetch(`/api/visitors/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    }

    setVisitors((prev) =>
      prev.map((v) => (v.id === id ? { ...v, isPinned: !v.isPinned } : v))
    );
  };

  // Delete visitor
  const deleteVisitor = (id: string) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(
        JSON.stringify({
          type: 'DELETE_VISITOR',
          data: { id },
        })
      );
    } else {
      fetch(`/api/visitors/${id}`, {
        method: 'DELETE',
      });
    }
    setVisitors((prev) => prev.filter((v) => v.id !== id));
  };

  // Update Service
  const updateService = (updates: Partial<ServiceInfo>) => {
    const updated = { ...service, ...updates };
    setService(updated);
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(
        JSON.stringify({
          type: 'UPDATE_SERVICE',
          data: updates,
        })
      );
    } else {
      fetch('/api/service', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    }
  };

  return (
    <ChurchContext.Provider
      value={{
        role,
        setRole,
        service,
        visitors,
        connectionStatus,
        isAudioEnabled,
        setIsAudioEnabled,
        altarTheme,
        setAltarTheme,
        fontSizeLevel,
        setFontSizeLevel,
        activeNewVisitorBanner,
        dismissNewVisitorBanner,
        addVisitor,
        markAsPresented,
        markAsPending,
        togglePin,
        deleteVisitor,
        updateService,
        unreadCountForAltar,
        resetUnreadCount,
        lastConnectedAt,
      }}
    >
      {children}
    </ChurchContext.Provider>
  );
};

export const useChurch = () => {
  const context = useContext(ChurchContext);
  if (!context) {
    throw new Error('useChurch must be used within a ChurchProvider');
  }
  return context;
};
