import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  AchievementItem,
  AscendState,
  CharacterAttribute,
  CharacterProfile,
  CharacterTitle,
  CustomTheme,
  DashboardWidgetConfig,
  EducationSubject,
  FocusConfig,
  FocusSessionRecord,
  GoalItem,
  HabitItem,
  JournalEntry,
  LifeDomain,
  MissionItem,
  ModuleId,
  NavItemConfig,
  PlannerBlock,
  ProjectItem,
  RewardItem,
  RoutineItem,
  SecondBrainNote,
  SkillNode,
  TaskItem,
  TypographyConfig,
  VisionBoardItem,
  WeeklyReviewRecord,
  XPSettingsConfig,
  XPTransaction,
} from '../types/ascend';
import { getTodayStr, INITIAL_ASCEND_STATE } from '../data/initialAscendState';
import {
  calculateLevelStatus,
  isHabitCompletedOnDate,
  LevelStatus,
  playAscendChime,
} from '../utils/progressionEngine';

const STORAGE_KEY = 'ascend_os_master_state_v3';

interface AscendContextValue {
  state: AscendState;
  levelStatus: LevelStatus;
  toastMessage: string | null;
  clearToast: () => void;
  setActiveModule: (mod: ModuleId) => void;
  setActiveTheme: (themeId: string) => void;
  saveCustomTheme: (theme: CustomTheme) => void;
  deleteCustomTheme: (themeId: string) => void;
  updateTypography: (typo: Partial<TypographyConfig>) => void;
  updateNavigation: (nav: NavItemConfig[]) => void;
  updateWidgets: (widgets: DashboardWidgetConfig[]) => void;
  updateCharacter: (profile: Partial<CharacterProfile>) => void;
  // Attributes & Domains & Titles
  saveAttribute: (attr: CharacterAttribute) => void;
  deleteAttribute: (attrId: string) => void;
  saveDomain: (domain: LifeDomain) => void;
  deleteDomain: (domainId: string) => void;
  saveTitle: (title: CharacterTitle) => void;
  // Habits
  saveHabit: (habit: HabitItem) => void;
  deleteHabit: (habitId: string) => void;
  logHabitProgress: (habitId: string, dateStr: string, newValue: number) => void;
  // Goals
  saveGoal: (goal: GoalItem) => void;
  deleteGoal: (goalId: string) => void;
  toggleGoalMilestone: (goalId: string, milestoneId: string) => void;
  addGoalCategory: (cat: string) => void;
  // Tasks & Projects
  saveTask: (task: TaskItem) => void;
  deleteTask: (taskId: string) => void;
  toggleTaskStatus: (taskId: string) => void;
  saveProject: (project: ProjectItem) => void;
  deleteProject: (projectId: string) => void;
  toggleProjectMilestone: (projectId: string, milestoneId: string) => void;
  // Daily Planner & Routines
  savePlannerBlock: (block: PlannerBlock) => void;
  deletePlannerBlock: (blockId: string) => void;
  togglePlannerBlock: (blockId: string) => void;
  saveRoutine: (routine: RoutineItem) => void;
  deleteRoutine: (routineId: string) => void;
  toggleRoutineActivity: (routineId: string, activityId: string, dateStr: string) => void;
  // Skills & Education
  saveSkill: (skill: SkillNode) => void;
  deleteSkill: (skillId: string) => void;
  upgradeSkillNode: (skillId: string) => void;
  addSkillBranch: (branch: string) => void;
  saveSubject: (subject: EducationSubject) => void;
  deleteSubject: (subjectId: string) => void;
  logSubjectStudyHours: (subjectId: string, hoursDelta: number) => void;
  toggleSubjectChapter: (subjectId: string, chapterId: string) => void;
  // Missions, Rewards, Achievements
  saveMission: (mission: MissionItem) => void;
  deleteMission: (missionId: string) => void;
  incrementMissionProgress: (missionId: string, delta: number) => void;
  saveReward: (reward: RewardItem) => void;
  deleteReward: (rewardId: string) => void;
  toggleRewardRedeem: (rewardId: string) => void;
  saveAchievement: (ach: AchievementItem) => void;
  unlockAchievement: (achId: string) => void;
  // Journal, Weekly Review, Second Brain, Vision Board
  saveJournalEntry: (entry: JournalEntry) => void;
  deleteJournalEntry: (entryId: string) => void;
  saveWeeklyReview: (review: WeeklyReviewRecord) => void;
  saveNote: (note: SecondBrainNote) => void;
  deleteNote: (noteId: string) => void;
  saveVisionItem: (item: VisionBoardItem) => void;
  deleteVisionItem: (itemId: string) => void;
  // Focus
  updateFocusConfig: (cfg: Partial<FocusConfig>) => void;
  recordFocusSession: (session: Omit<FocusSessionRecord, 'id' | 'xpEarned'> & { customXp?: number }) => void;
  // XP Engine & Ledger
  updateXPSettings: (cfg: Partial<XPSettingsConfig>) => void;
  recordManualXP: (xpAmount: number, reason: string, attributeIds: string[]) => void;
  reverseXPTransaction: (txId: string) => void;
  // System Backup / Restore
  importFullState: (newState: AscendState) => void;
  resetToDefaults: () => void;
}

const AscendContext = createContext<AscendContextValue | null>(null);

export const AscendProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AscendState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...INITIAL_ASCEND_STATE, ...parsed };
      }
    } catch {
      // Fallback to initial state
    }
    return INITIAL_ASCEND_STATE;
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (!toastMessage) return;
    const t = setTimeout(() => setToastMessage(null), 3800);
    return () => clearTimeout(t);
  }, [toastMessage]);

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore quota errors
    }
  }, [state]);

  // Apply dynamic theme and typography CSS variables
  useEffect(() => {
    const activeTheme =
      state.themes.find((t) => t.id === state.activeThemeId) || state.themes[0];
    const root = document.documentElement;

    root.style.setProperty('--bg-canvas', activeTheme.bgCanvas);
    root.style.setProperty('--bg-surface', activeTheme.bgSurface);
    root.style.setProperty('--bg-elevated', activeTheme.bgElevated);
    root.style.setProperty('--text-primary', activeTheme.textPrimary);
    root.style.setProperty('--text-secondary', activeTheme.textSecondary);
    root.style.setProperty('--text-muted', activeTheme.textMuted);
    root.style.setProperty('--border-subtle', activeTheme.borderSubtle);
    root.style.setProperty('--accent-primary', activeTheme.accentPrimary);
    root.style.setProperty('--accent-soft', `${activeTheme.accentPrimary}1F`);

    const typo = state.typography;
    root.style.setProperty('--font-heading', `'${typo.headingFont}', sans-serif`);
    root.style.setProperty('--font-subheading', `'${typo.subheadingFont}', sans-serif`);
    root.style.setProperty('--font-body', `'${typo.bodyFont}', sans-serif`);
    root.style.setProperty('--font-task', `'${typo.taskFont}', sans-serif`);
    root.style.setProperty('--font-notes', `'${typo.notesFont}', sans-serif`);
    root.style.setProperty('--font-character', `'${typo.characterFont}', sans-serif`);
    root.style.setProperty('--font-journal', `'${typo.journalFont}', cursive, sans-serif`);
    root.style.setProperty('--font-handwriting', `'${typo.handwritingFont}', cursive, sans-serif`);
    root.style.setProperty('--heading-weight', typo.headingWeight);
    root.style.setProperty('--body-scale', String(typo.bodyScale || 1));
  }, [state.activeThemeId, state.themes, state.typography]);

  const levelStatus = calculateLevelStatus(state.xpTransactions, state.xpSettings);

  // Internal helper to append or reverse XP transactions & attribute XP
  const applyXpDelta = (
    prevState: AscendState,
    params: {
      activityId: string;
      activityType: XPTransaction['activityType'];
      xpAmount: number;
      reason: string;
      relatedRecordTitle: string;
      attributeIds: string[];
    }
  ): AscendState => {
    if (!prevState.xpSettings.xpEnabled || params.xpAmount === 0) {
      return prevState;
    }

    const oldStatus = calculateLevelStatus(prevState.xpTransactions, prevState.xpSettings);

    const now = new Date();
    const tx: XPTransaction = {
      id: `xpt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      activityId: params.activityId,
      activityType: params.activityType,
      xpAmount: params.xpAmount,
      date: getTodayStr(),
      timestamp: now.toTimeString().split(' ')[0],
      reason: params.reason,
      relatedRecordTitle: params.relatedRecordTitle,
      attributeIds: params.attributeIds,
    };

    const nextTransactions = [tx, ...prevState.xpTransactions];
    const perAttrShare =
      params.attributeIds.length > 0
        ? Math.round(params.xpAmount / params.attributeIds.length)
        : 0;

    const nextAttributes = prevState.attributes.map((attr) => {
      if (params.attributeIds.includes(attr.id)) {
        return {
          ...attr,
          xpEarned: Math.max(0, attr.xpEarned + perAttrShare),
        };
      }
      return attr;
    });

    const newStatus = calculateLevelStatus(nextTransactions, prevState.xpSettings);
    if (newStatus.level > oldStatus.level && prevState.xpSettings.levelUpNotifications) {
      playAscendChime('levelup');
      setTimeout(() => {
        triggerToast(`LEVEL UP! Reached Level ${newStatus.level} (${newStatus.totalXp.toLocaleString()} XP)`);
      }, 60);
    } else if (params.xpAmount > 0) {
      playAscendChime('complete');
      setTimeout(() => {
        triggerToast(`+${params.xpAmount} XP — ${params.relatedRecordTitle}`);
      }, 40);
    } else if (params.xpAmount < 0) {
      setTimeout(() => {
        triggerToast(`${params.xpAmount} XP adjusted — ${params.relatedRecordTitle}`);
      }, 40);
    }

    // Unlock titles automatically if level threshold reached
    const nextTitles = prevState.titles.map((t) =>
      newStatus.level >= t.requiredLevel ? { ...t, unlocked: true } : t
    );

    return {
      ...prevState,
      xpTransactions: nextTransactions,
      attributes: nextAttributes,
      titles: nextTitles,
    };
  };

  const setActiveModule = (mod: ModuleId) => {
    setState((prev) => ({ ...prev, activeModule: mod }));
  };

  const setActiveTheme = (themeId: string) => {
    setState((prev) => ({ ...prev, activeThemeId: themeId }));
  };

  const saveCustomTheme = (theme: CustomTheme) => {
    setState((prev) => {
      const exists = prev.themes.some((t) => t.id === theme.id);
      const themes = exists
        ? prev.themes.map((t) => (t.id === theme.id ? theme : t))
        : [...prev.themes, theme];
      return { ...prev, themes, activeThemeId: theme.id };
    });
    triggerToast(`Theme "${theme.name}" applied & saved`);
  };

  const deleteCustomTheme = (themeId: string) => {
    setState((prev) => {
      if (prev.themes.length <= 1) return prev;
      const themes = prev.themes.filter((t) => t.id !== themeId);
      const activeThemeId =
        prev.activeThemeId === themeId ? themes[0].id : prev.activeThemeId;
      return { ...prev, themes, activeThemeId };
    });
  };

  const updateTypography = (typo: Partial<TypographyConfig>) => {
    setState((prev) => ({
      ...prev,
      typography: { ...prev.typography, ...typo },
    }));
  };

  const updateNavigation = (navigation: NavItemConfig[]) => {
    setState((prev) => ({ ...prev, navigation }));
  };

  const updateWidgets = (dashboardWidgets: DashboardWidgetConfig[]) => {
    setState((prev) => ({ ...prev, dashboardWidgets }));
  };

  const updateCharacter = (profile: Partial<CharacterProfile>) => {
    setState((prev) => ({
      ...prev,
      character: { ...prev.character, ...profile },
    }));
    triggerToast('Character profile updated');
  };

  const saveAttribute = (attr: CharacterAttribute) => {
    setState((prev) => {
      const exists = prev.attributes.some((a) => a.id === attr.id);
      const attributes = exists
        ? prev.attributes.map((a) => (a.id === attr.id ? attr : a))
        : [...prev.attributes, attr];
      return { ...prev, attributes };
    });
    triggerToast(`Attribute "${attr.name}" saved`);
  };

  const deleteAttribute = (attrId: string) => {
    setState((prev) => ({
      ...prev,
      attributes: prev.attributes.filter((a) => a.id !== attrId),
    }));
  };

  const saveDomain = (domain: LifeDomain) => {
    setState((prev) => {
      const exists = prev.domains.some((d) => d.id === domain.id);
      const domains = exists
        ? prev.domains.map((d) => (d.id === domain.id ? domain : d))
        : [...prev.domains, domain];
      return { ...prev, domains };
    });
    triggerToast(`Domain "${domain.name}" saved`);
  };

  const deleteDomain = (domainId: string) => {
    setState((prev) => ({
      ...prev,
      domains: prev.domains.filter((d) => d.id !== domainId),
    }));
  };

  const saveTitle = (title: CharacterTitle) => {
    setState((prev) => {
      const exists = prev.titles.some((t) => t.id === title.id);
      const titles = exists
        ? prev.titles.map((t) => (t.id === title.id ? title : t))
        : [...prev.titles, title];
      return { ...prev, titles };
    });
    triggerToast(`Title "${title.name}" saved`);
  };

  const saveHabit = (habit: HabitItem) => {
    setState((prev) => {
      const exists = prev.habits.some((h) => h.id === habit.id);
      const habits = exists
        ? prev.habits.map((h) => (h.id === habit.id ? habit : h))
        : [...prev.habits, habit];
      return { ...prev, habits };
    });
    triggerToast(`Habit "${habit.name}" saved`);
  };

  const deleteHabit = (habitId: string) => {
    setState((prev) => ({
      ...prev,
      habits: prev.habits.filter((h) => h.id !== habitId),
    }));
  };

  const logHabitProgress = (habitId: string, dateStr: string, newValue: number) => {
    setState((prev) => {
      const habit = prev.habits.find((h) => h.id === habitId);
      if (!habit) return prev;

      const wasComplete = isHabitCompletedOnDate(habit, dateStr);
      const updatedHabit: HabitItem = {
        ...habit,
        history: {
          ...habit.history,
          [dateStr]: Math.max(0, newValue),
        },
      };
      const isNowComplete = isHabitCompletedOnDate(updatedHabit, dateStr);

      let nextState: AscendState = {
        ...prev,
        habits: prev.habits.map((h) => (h.id === habitId ? updatedHabit : h)),
      };

      if (prev.xpSettings.autoXpEnabled && habit.xpReward > 0) {
        if (!wasComplete && isNowComplete) {
          nextState = applyXpDelta(nextState, {
            activityId: `${habit.id}-${dateStr}`,
            activityType: 'habit',
            xpAmount: habit.xpReward,
            reason: `Completed Habit (${dateStr}): ${habit.name}`,
            relatedRecordTitle: habit.name,
            attributeIds: habit.attributeIds,
          });
        } else if (wasComplete && !isNowComplete) {
          nextState = applyXpDelta(nextState, {
            activityId: `${habit.id}-${dateStr}`,
            activityType: 'habit',
            xpAmount: -habit.xpReward,
            reason: `Reverted Habit Completion (${dateStr}): ${habit.name}`,
            relatedRecordTitle: habit.name,
            attributeIds: habit.attributeIds,
          });
        }
      }

      return nextState;
    });
  };

  const saveGoal = (goal: GoalItem) => {
    setState((prev) => {
      const exists = prev.goals.some((g) => g.id === goal.id);
      const goals = exists
        ? prev.goals.map((g) => (g.id === goal.id ? goal : g))
        : [...prev.goals, goal];
      return { ...prev, goals };
    });
    triggerToast(`Goal "${goal.title}" saved`);
  };

  const deleteGoal = (goalId: string) => {
    setState((prev) => ({
      ...prev,
      goals: prev.goals.filter((g) => g.id !== goalId),
    }));
  };

  const toggleGoalMilestone = (goalId: string, milestoneId: string) => {
    setState((prev) => {
      const goal = prev.goals.find((g) => g.id === goalId);
      if (!goal) return prev;
      const ms = goal.milestones.find((m) => m.id === milestoneId);
      if (!ms) return prev;

      const nextCompleted = !ms.completed;
      const nextMilestones = goal.milestones.map((m) =>
        m.id === milestoneId ? { ...m, completed: nextCompleted } : m
      );
      const allDone = nextMilestones.length > 0 && nextMilestones.every((m) => m.completed);

      const updatedGoal: GoalItem = {
        ...goal,
        milestones: nextMilestones,
        status: allDone ? 'Completed' : goal.status === 'Completed' ? 'Active' : goal.status,
        completedAt: allDone ? getTodayStr() : undefined,
      };

      let nextState: AscendState = {
        ...prev,
        goals: prev.goals.map((g) => (g.id === goalId ? updatedGoal : g)),
      };

      if (prev.xpSettings.autoXpEnabled && ms.xpReward > 0) {
        nextState = applyXpDelta(nextState, {
          activityId: ms.id,
          activityType: 'milestone',
          xpAmount: nextCompleted ? ms.xpReward : -ms.xpReward,
          reason: `${nextCompleted ? 'Completed' : 'Reopened'} Milestone: ${ms.title}`,
          relatedRecordTitle: `${goal.title} — ${ms.title}`,
          attributeIds: goal.attributeIds,
        });
      }

      if (allDone && goal.status !== 'Completed' && prev.xpSettings.autoXpEnabled && goal.xpReward > 0) {
        nextState = applyXpDelta(nextState, {
          activityId: goal.id,
          activityType: 'goal',
          xpAmount: goal.xpReward,
          reason: `Completed Strategic Goal: ${goal.title}`,
          relatedRecordTitle: goal.title,
          attributeIds: goal.attributeIds,
        });
      }

      return nextState;
    });
  };

  const addGoalCategory = (cat: string) => {
    const trimmed = cat.trim();
    if (!trimmed) return;
    setState((prev) => {
      if (prev.goalCategories.includes(trimmed)) return prev;
      return { ...prev, goalCategories: [...prev.goalCategories, trimmed] };
    });
  };

  const saveTask = (task: TaskItem) => {
    setState((prev) => {
      const exists = prev.tasks.some((t) => t.id === task.id);
      const tasks = exists
        ? prev.tasks.map((t) => (t.id === task.id ? task : t))
        : [task, ...prev.tasks];
      return { ...prev, tasks };
    });
    triggerToast(`Task "${task.title}" saved`);
  };

  const deleteTask = (taskId: string) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((t) => t.id !== taskId),
    }));
  };

  const toggleTaskStatus = (taskId: string) => {
    setState((prev) => {
      const task = prev.tasks.find((t) => t.id === taskId);
      if (!task) return prev;

      const wasCompleted = task.status === 'Completed';
      const nextStatus: TaskItem['status'] = wasCompleted ? 'To-do' : 'Completed';
      const updatedTask: TaskItem = {
        ...task,
        status: nextStatus,
        completedAt: nextStatus === 'Completed' ? getTodayStr() : undefined,
      };

      let nextState: AscendState = {
        ...prev,
        tasks: prev.tasks.map((t) => (t.id === taskId ? updatedTask : t)),
      };

      if (prev.xpSettings.autoXpEnabled && task.xpReward > 0) {
        nextState = applyXpDelta(nextState, {
          activityId: task.id,
          activityType: 'task',
          xpAmount: !wasCompleted ? task.xpReward : -task.xpReward,
          reason: `${!wasCompleted ? 'Completed' : 'Reopened'} Task: ${task.title}`,
          relatedRecordTitle: task.title,
          attributeIds: task.attributeIds,
        });
      }

      return nextState;
    });
  };

  const saveProject = (project: ProjectItem) => {
    setState((prev) => {
      const exists = prev.projects.some((p) => p.id === project.id);
      const projects = exists
        ? prev.projects.map((p) => (p.id === project.id ? project : p))
        : [...prev.projects, project];
      return { ...prev, projects };
    });
    triggerToast(`Project "${project.name}" saved`);
  };

  const deleteProject = (projectId: string) => {
    setState((prev) => ({
      ...prev,
      projects: prev.projects.filter((p) => p.id !== projectId),
    }));
  };

  const toggleProjectMilestone = (projectId: string, milestoneId: string) => {
    setState((prev) => ({
      ...prev,
      projects: prev.projects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              milestones: p.milestones.map((m) =>
                m.id === milestoneId ? { ...m, completed: !m.completed } : m
              ),
            }
          : p
      ),
    }));
  };

  const savePlannerBlock = (block: PlannerBlock) => {
    setState((prev) => {
      const exists = prev.plannerBlocks.some((b) => b.id === block.id);
      const plannerBlocks = exists
        ? prev.plannerBlocks.map((b) => (b.id === block.id ? block : b))
        : [...prev.plannerBlocks, block];
      return { ...prev, plannerBlocks };
    });
    triggerToast(`Time block "${block.title}" scheduled`);
  };

  const deletePlannerBlock = (blockId: string) => {
    setState((prev) => ({
      ...prev,
      plannerBlocks: prev.plannerBlocks.filter((b) => b.id !== blockId),
    }));
  };

  const togglePlannerBlock = (blockId: string) => {
    setState((prev) => ({
      ...prev,
      plannerBlocks: prev.plannerBlocks.map((b) =>
        b.id === blockId ? { ...b, completed: !b.completed } : b
      ),
    }));
  };

  const saveRoutine = (routine: RoutineItem) => {
    setState((prev) => {
      const exists = prev.routines.some((r) => r.id === routine.id);
      const routines = exists
        ? prev.routines.map((r) => (r.id === routine.id ? routine : r))
        : [...prev.routines, routine];
      return { ...prev, routines };
    });
    triggerToast(`Routine "${routine.name}" saved`);
  };

  const deleteRoutine = (routineId: string) => {
    setState((prev) => ({
      ...prev,
      routines: prev.routines.filter((r) => r.id !== routineId),
    }));
  };

  const toggleRoutineActivity = (routineId: string, activityId: string, dateStr: string) => {
    setState((prev) => ({
      ...prev,
      routines: prev.routines.map((r) => {
        if (r.id !== routineId) return r;
        return {
          ...r,
          activities: r.activities.map((act) => {
            if (act.id !== activityId) return act;
            const done = act.completedDates.includes(dateStr);
            const completedDates = done
              ? act.completedDates.filter((d) => d !== dateStr)
              : [...act.completedDates, dateStr];
            return { ...act, completedDates };
          }),
        };
      }),
    }));
  };

  const saveSkill = (skill: SkillNode) => {
    setState((prev) => {
      const exists = prev.skills.some((s) => s.id === skill.id);
      const skills = exists
        ? prev.skills.map((s) => (s.id === skill.id ? skill : s))
        : [...prev.skills, skill];
      return { ...prev, skills };
    });
    triggerToast(`Skill node "${skill.name}" saved`);
  };

  const deleteSkill = (skillId: string) => {
    setState((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s.id !== skillId),
    }));
  };

  const upgradeSkillNode = (skillId: string) => {
    setState((prev) => {
      const skill = prev.skills.find((s) => s.id === skillId);
      if (!skill) return prev;
      if (skill.currentLevel >= skill.maxLevel) return prev;

      const nextLevel = skill.currentLevel + 1;
      const updatedSkill: SkillNode = {
        ...skill,
        unlocked: true,
        currentLevel: nextLevel,
        xpInvested: skill.xpInvested + skill.xpPerLevel,
      };

      let nextState: AscendState = {
        ...prev,
        skills: prev.skills.map((s) => (s.id === skillId ? updatedSkill : s)),
      };

      if (prev.xpSettings.autoXpEnabled && skill.xpRewardOnLevelUp > 0) {
        nextState = applyXpDelta(nextState, {
          activityId: `${skill.id}-lv${nextLevel}`,
          activityType: 'skill',
          xpAmount: skill.xpRewardOnLevelUp,
          reason: `Advanced Skill "${skill.name}" to Level ${nextLevel}`,
          relatedRecordTitle: `${skill.name} (Lv.${nextLevel})`,
          attributeIds: skill.attributeIds,
        });
      }

      return nextState;
    });
  };

  const addSkillBranch = (branch: string) => {
    const trimmed = branch.trim();
    if (!trimmed) return;
    setState((prev) => {
      if (prev.skillBranches.includes(trimmed)) return prev;
      return { ...prev, skillBranches: [...prev.skillBranches, trimmed] };
    });
  };

  const saveSubject = (subject: EducationSubject) => {
    setState((prev) => {
      const exists = prev.subjects.some((s) => s.id === subject.id);
      const subjects = exists
        ? prev.subjects.map((s) => (s.id === subject.id ? subject : s))
        : [...prev.subjects, subject];
      return { ...prev, subjects };
    });
    triggerToast(`Subject "${subject.name}" saved`);
  };

  const deleteSubject = (subjectId: string) => {
    setState((prev) => ({
      ...prev,
      subjects: prev.subjects.filter((s) => s.id !== subjectId),
    }));
  };

  const logSubjectStudyHours = (subjectId: string, hoursDelta: number) => {
    setState((prev) => {
      const subj = prev.subjects.find((s) => s.id === subjectId);
      if (!subj || hoursDelta <= 0) return prev;

      const updated: EducationSubject = {
        ...subj,
        loggedHours: Number((subj.loggedHours + hoursDelta).toFixed(1)),
      };

      let nextState: AscendState = {
        ...prev,
        subjects: prev.subjects.map((s) => (s.id === subjectId ? updated : s)),
      };

      const xpEarned = Math.round(hoursDelta * (subj.xpPerHour || prev.xpSettings.defaultLearningHourXp));
      if (prev.xpSettings.autoXpEnabled && xpEarned > 0) {
        nextState = applyXpDelta(nextState, {
          activityId: `${subj.id}-${Date.now()}`,
          activityType: 'education',
          xpAmount: xpEarned,
          reason: `Logged ${hoursDelta}h Study Session in ${subj.name}`,
          relatedRecordTitle: subj.name,
          attributeIds: subj.attributeIds,
        });
      }

      return nextState;
    });
  };

  const toggleSubjectChapter = (subjectId: string, chapterId: string) => {
    setState((prev) => {
      const subj = prev.subjects.find((s) => s.id === subjectId);
      if (!subj) return prev;
      const ch = subj.chapters.find((c) => c.id === chapterId);
      if (!ch) return prev;
      const nextCompleted = !ch.completed;

      const updatedSubj: EducationSubject = {
        ...subj,
        chapters: subj.chapters.map((c) =>
          c.id === chapterId ? { ...c, completed: nextCompleted } : c
        ),
      };

      let nextState: AscendState = {
        ...prev,
        subjects: prev.subjects.map((s) => (s.id === subjectId ? updatedSubj : s)),
      };

      if (prev.xpSettings.autoXpEnabled) {
        nextState = applyXpDelta(nextState, {
          activityId: ch.id,
          activityType: 'education',
          xpAmount: nextCompleted ? 40 : -40,
          reason: `${nextCompleted ? 'Completed' : 'Reopened'} Chapter: ${ch.title}`,
          relatedRecordTitle: `${subj.name} — ${ch.title}`,
          attributeIds: subj.attributeIds,
        });
      }

      return nextState;
    });
  };

  const saveMission = (mission: MissionItem) => {
    setState((prev) => {
      const exists = prev.missions.some((m) => m.id === mission.id);
      const missions = exists
        ? prev.missions.map((m) => (m.id === mission.id ? mission : m))
        : [...prev.missions, mission];
      return { ...prev, missions };
    });
    triggerToast(`Mission "${mission.name}" saved`);
  };

  const deleteMission = (missionId: string) => {
    setState((prev) => ({
      ...prev,
      missions: prev.missions.filter((m) => m.id !== missionId),
    }));
  };

  const incrementMissionProgress = (missionId: string, delta: number) => {
    setState((prev) => {
      const mis = prev.missions.find((m) => m.id === missionId);
      if (!mis) return prev;
      const wasCompleted = mis.status === 'Completed';
      const nextCount = Math.max(0, Math.min(mis.targetCount, mis.currentCount + delta));
      const nowCompleted = nextCount >= mis.targetCount;

      const updated: MissionItem = {
        ...mis,
        currentCount: nextCount,
        status: nowCompleted ? 'Completed' : 'Active',
      };

      let nextState: AscendState = {
        ...prev,
        missions: prev.missions.map((m) => (m.id === missionId ? updated : m)),
      };

      if (prev.xpSettings.autoXpEnabled && mis.xpReward > 0) {
        if (!wasCompleted && nowCompleted) {
          nextState = applyXpDelta(nextState, {
            activityId: mis.id,
            activityType: 'mission',
            xpAmount: mis.xpReward,
            reason: `Completed Mission: ${mis.name}`,
            relatedRecordTitle: mis.name,
            attributeIds: mis.attributeIds,
          });
        } else if (wasCompleted && !nowCompleted) {
          nextState = applyXpDelta(nextState, {
            activityId: mis.id,
            activityType: 'mission',
            xpAmount: -mis.xpReward,
            reason: `Reopened Mission: ${mis.name}`,
            relatedRecordTitle: mis.name,
            attributeIds: mis.attributeIds,
          });
        }
      }

      return nextState;
    });
  };

  const saveReward = (reward: RewardItem) => {
    setState((prev) => {
      const exists = prev.rewards.some((r) => r.id === reward.id);
      const rewards = exists
        ? prev.rewards.map((r) => (r.id === reward.id ? reward : r))
        : [...prev.rewards, reward];
      return { ...prev, rewards };
    });
    triggerToast(`Reward "${reward.name}" saved`);
  };

  const deleteReward = (rewardId: string) => {
    setState((prev) => ({
      ...prev,
      rewards: prev.rewards.filter((r) => r.id !== rewardId),
    }));
  };

  const toggleRewardRedeem = (rewardId: string) => {
    setState((prev) => ({
      ...prev,
      rewards: prev.rewards.map((r) =>
        r.id === rewardId
          ? { ...r, unlocked: true, redeemed: !r.redeemed, unlockedDate: getTodayStr() }
          : r
      ),
    }));
  };

  const saveAchievement = (ach: AchievementItem) => {
    setState((prev) => {
      const exists = prev.achievements.some((a) => a.id === ach.id);
      const achievements = exists
        ? prev.achievements.map((a) => (a.id === ach.id ? ach : a))
        : [...prev.achievements, ach];
      return { ...prev, achievements };
    });
    triggerToast(`Achievement "${ach.name}" saved`);
  };

  const unlockAchievement = (achId: string) => {
    setState((prev) => {
      const ach = prev.achievements.find((a) => a.id === achId);
      if (!ach || ach.unlocked) return prev;
      const updated: AchievementItem = {
        ...ach,
        unlocked: true,
        unlockedDate: getTodayStr(),
      };
      let nextState: AscendState = {
        ...prev,
        achievements: prev.achievements.map((a) => (a.id === achId ? updated : a)),
      };
      if (prev.xpSettings.autoXpEnabled && ach.xpReward > 0) {
        nextState = applyXpDelta(nextState, {
          activityId: ach.id,
          activityType: 'achievement',
          xpAmount: ach.xpReward,
          reason: `Unlocked Achievement Badge: ${ach.name}`,
          relatedRecordTitle: ach.name,
          attributeIds: ['attr-dis', 'attr-con'],
        });
      }
      return nextState;
    });
  };

  const saveJournalEntry = (entry: JournalEntry) => {
    setState((prev) => {
      const exists = prev.journalEntries.some((j) => j.id === entry.id);
      const journalEntries = exists
        ? prev.journalEntries.map((j) => (j.id === entry.id ? entry : j))
        : [entry, ...prev.journalEntries];
      return { ...prev, journalEntries };
    });
    triggerToast('Journal reflection saved');
  };

  const deleteJournalEntry = (entryId: string) => {
    setState((prev) => ({
      ...prev,
      journalEntries: prev.journalEntries.filter((j) => j.id !== entryId),
    }));
  };

  const saveWeeklyReview = (review: WeeklyReviewRecord) => {
    setState((prev) => {
      let nextState: AscendState = {
        ...prev,
        weeklyReviews: [review, ...prev.weeklyReviews.filter((r) => r.id !== review.id)],
      };
      if (prev.xpSettings.autoXpEnabled) {
        nextState = applyXpDelta(nextState, {
          activityId: review.id,
          activityType: 'manual',
          xpAmount: 60,
          reason: `Completed Weekly Architecture Review (${review.weekStartDate})`,
          relatedRecordTitle: 'Weekly Review',
          attributeIds: ['attr-wis', 'attr-org'],
        });
      }
      return nextState;
    });
  };

  const saveNote = (note: SecondBrainNote) => {
    setState((prev) => {
      const exists = prev.notes.some((n) => n.id === note.id);
      const notes = exists
        ? prev.notes.map((n) => (n.id === note.id ? note : n))
        : [note, ...prev.notes];
      return { ...prev, notes };
    });
    triggerToast(`Note "${note.title}" saved in Second Brain`);
  };

  const deleteNote = (noteId: string) => {
    setState((prev) => ({
      ...prev,
      notes: prev.notes.filter((n) => n.id !== noteId),
    }));
  };

  const saveVisionItem = (item: VisionBoardItem) => {
    setState((prev) => {
      const exists = prev.visionBoard.some((v) => v.id === item.id);
      const visionBoard = exists
        ? prev.visionBoard.map((v) => (v.id === item.id ? item : v))
        : [...prev.visionBoard, item];
      return { ...prev, visionBoard };
    });
    triggerToast('Vision board updated');
  };

  const deleteVisionItem = (itemId: string) => {
    setState((prev) => ({
      ...prev,
      visionBoard: prev.visionBoard.filter((v) => v.id !== itemId),
    }));
  };

  const updateFocusConfig = (cfg: Partial<FocusConfig>) => {
    setState((prev) => ({
      ...prev,
      focusConfig: { ...prev.focusConfig, ...cfg },
    }));
  };

  const recordFocusSession = (
    session: Omit<FocusSessionRecord, 'id' | 'xpEarned'> & { customXp?: number }
  ) => {
    setState((prev) => {
      const xpEarned =
        session.customXp ??
        Math.max(
          5,
          Math.round(
            (session.durationMinutes / 25) * prev.focusConfig.xpPer25MinSession
          )
        );
      const record: FocusSessionRecord = {
        id: `fs-${Date.now()}`,
        date: session.date,
        timestamp: session.timestamp,
        label: session.label,
        mode: session.mode,
        durationMinutes: session.durationMinutes,
        linkedGoalId: session.linkedGoalId,
        linkedTaskId: session.linkedTaskId,
        linkedSubjectId: session.linkedSubjectId,
        xpEarned,
      };

      let nextState: AscendState = {
        ...prev,
        focusSessions: [record, ...prev.focusSessions],
      };

      if (prev.xpSettings.autoXpEnabled && xpEarned > 0) {
        nextState = applyXpDelta(nextState, {
          activityId: record.id,
          activityType: 'focus',
          xpAmount: xpEarned,
          reason: `Focus Session (${session.durationMinutes}m): ${session.label}`,
          relatedRecordTitle: session.label,
          attributeIds: ['attr-foc', 'attr-dis'],
        });
      }

      return nextState;
    });
  };

  const updateXPSettings = (cfg: Partial<XPSettingsConfig>) => {
    setState((prev) => ({
      ...prev,
      xpSettings: { ...prev.xpSettings, ...cfg },
    }));
    triggerToast('XP & progression engine rules updated');
  };

  const recordManualXP = (xpAmount: number, reason: string, attributeIds: string[]) => {
    setState((prev) =>
      applyXpDelta(prev, {
        activityId: `manual-${Date.now()}`,
        activityType: 'manual',
        xpAmount,
        reason,
        relatedRecordTitle: reason,
        attributeIds,
      })
    );
  };

  const reverseXPTransaction = (txId: string) => {
    setState((prev) => {
      const tx = prev.xpTransactions.find((t) => t.id === txId);
      if (!tx) return prev;
      const perAttrShare =
        tx.attributeIds.length > 0
          ? Math.round(tx.xpAmount / tx.attributeIds.length)
          : 0;
      const nextAttributes = prev.attributes.map((attr) =>
        tx.attributeIds.includes(attr.id)
          ? { ...attr, xpEarned: Math.max(0, attr.xpEarned - perAttrShare) }
          : attr
      );
      return {
        ...prev,
        xpTransactions: prev.xpTransactions.filter((t) => t.id !== txId),
        attributes: nextAttributes,
      };
    });
    triggerToast('XP Transaction safely reversed');
  };

  const importFullState = (newState: AscendState) => {
    setState(newState);
    triggerToast('Ascend OS database restored successfully');
  };

  const resetToDefaults = () => {
    setState(INITIAL_ASCEND_STATE);
    triggerToast('Reset to initial Ascend OS master state');
  };

  return (
    <AscendContext.Provider
      value={{
        state,
        levelStatus,
        toastMessage,
        clearToast: () => setToastMessage(null),
        setActiveModule,
        setActiveTheme,
        saveCustomTheme,
        deleteCustomTheme,
        updateTypography,
        updateNavigation,
        updateWidgets,
        updateCharacter,
        saveAttribute,
        deleteAttribute,
        saveDomain,
        deleteDomain,
        saveTitle,
        saveHabit,
        deleteHabit,
        logHabitProgress,
        saveGoal,
        deleteGoal,
        toggleGoalMilestone,
        addGoalCategory,
        saveTask,
        deleteTask,
        toggleTaskStatus,
        saveProject,
        deleteProject,
        toggleProjectMilestone,
        savePlannerBlock,
        deletePlannerBlock,
        togglePlannerBlock,
        saveRoutine,
        deleteRoutine,
        toggleRoutineActivity,
        saveSkill,
        deleteSkill,
        upgradeSkillNode,
        addSkillBranch,
        saveSubject,
        deleteSubject,
        logSubjectStudyHours,
        toggleSubjectChapter,
        saveMission,
        deleteMission,
        incrementMissionProgress,
        saveReward,
        deleteReward,
        toggleRewardRedeem,
        saveAchievement,
        unlockAchievement,
        saveJournalEntry,
        deleteJournalEntry,
        saveWeeklyReview,
        saveNote,
        deleteNote,
        saveVisionItem,
        deleteVisionItem,
        updateFocusConfig,
        recordFocusSession,
        updateXPSettings,
        recordManualXP,
        reverseXPTransaction,
        importFullState,
        resetToDefaults,
      }}
    >
      {children}
    </AscendContext.Provider>
  );
};

export const useAscend = (): AscendContextValue => {
  const ctx = useContext(AscendContext);
  if (!ctx) throw new Error('useAscend must be used within AscendProvider');
  return ctx;
};
