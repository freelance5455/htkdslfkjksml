import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserAccount, UserHealthProfile } from '../types';
import { hashPassword, calculateBMI } from '../utils/security';

interface AuthContextType {
  user: UserAccount | null;
  isLoggedIn: boolean;
  isLoading: boolean;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string }>;
  register: (data: {
    fullName: string;
    email: string;
    mobileNumber: string;
    password: string;
  }) => Promise<{ success: boolean; user?: UserAccount; error?: string }>;
  updateHealthProfile: (profile: Partial<UserHealthProfile>) => Promise<boolean>;
  changePassword: (oldPass: string, newPass: string) => Promise<{ success: boolean; error?: string }>;
  forgotPasswordReset: (email: string, newPass: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateUserBasicInfo: (fullName: string, mobileNumber: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const USERS_STORAGE_KEY = 'mediguide_users_v2';
const SESSION_STORAGE_KEY = 'mediguide_session_v2';

// Seed initial default user with hashed password
const DEFAULT_SEED_USER_EMAIL = 'alex.morgan@healthmail.com';

async function createSeedUser(): Promise<UserAccount> {
  const defaultHash = await hashPassword('Alex@1234');
  return {
    id: 'usr_default_01',
    fullName: 'Alex Morgan',
    email: DEFAULT_SEED_USER_EMAIL,
    mobileNumber: '9876543210',
    passwordHash: defaultHash,
    role: 'Premium Member',
    createdAt: new Date().toISOString(),
    healthProfile: {
      age: 28,
      gender: 'Male',
      height: 178,
      weight: 72,
      bloodGroup: 'O+',
      allergies: 'Penicillin, Peanuts',
      existingDiseases: 'Mild Asthma',
      emergencyContact: 'Sarah Morgan (Wife) - +1 (555) 987-6543',
      preferredLanguage: 'English',
      bmi: calculateBMI(178, 72),
    },
  };
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserAccount | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Initialize Auth state from localStorage
  useEffect(() => {
    const initAuth = async () => {
      try {
        let storedUsersRaw = localStorage.getItem(USERS_STORAGE_KEY);
        let usersList: UserAccount[] = [];

        if (storedUsersRaw) {
          usersList = JSON.parse(storedUsersRaw);
        } else {
          // Seed initial user
          const seedUser = await createSeedUser();
          usersList = [seedUser];
          localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(usersList));
        }

        // Check active session
        const sessionRaw = localStorage.getItem(SESSION_STORAGE_KEY);
        if (sessionRaw) {
          const session = JSON.parse(sessionRaw);
          const foundUser = usersList.find((u) => u.email.toLowerCase() === session.email.toLowerCase());
          if (foundUser) {
            setUser(foundUser);
            setIsLoggedIn(true);
          }
        }
      } catch (err) {
        console.error('Failed to initialize auth state:', err);
      } finally {
        setIsLoading(false);
      }
    };

    initAuth();
  }, []);

  const getUsersFromStorage = (): UserAccount[] => {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  };

  const saveUsersToStorage = (users: UserAccount[]) => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  };

  const login = async (email: string, password: string, rememberMe: boolean = true) => {
    setIsLoading(true);
    try {
      const users = getUsersFromStorage();
      const targetUser = users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());

      if (!targetUser) {
        setIsLoading(false);
        return { success: false, error: 'No user account found with this email address.' };
      }

      const inputHash = await hashPassword(password);
      if (inputHash !== targetUser.passwordHash) {
        setIsLoading(false);
        return { success: false, error: 'Incorrect password. Please verify and try again.' };
      }

      // Success
      setUser(targetUser);
      setIsLoggedIn(true);

      if (rememberMe) {
        localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ email: targetUser.email, loginTime: Date.now() }));
      } else {
        sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ email: targetUser.email, loginTime: Date.now() }));
      }

      setIsLoading(false);
      return { success: true };
    } catch {
      setIsLoading(false);
      return { success: false, error: 'Authentication service error. Please try again.' };
    }
  };

  const register = async (data: {
    fullName: string;
    email: string;
    mobileNumber: string;
    password: string;
  }) => {
    setIsLoading(true);
    try {
      const users = getUsersFromStorage();
      const existing = users.find((u) => u.email.toLowerCase() === data.email.trim().toLowerCase());

      if (existing) {
        setIsLoading(false);
        return { success: false, error: 'An account with this email address already exists.' };
      }

      const hashedPassword = await hashPassword(data.password);
      const newUser: UserAccount = {
        id: `usr_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        fullName: data.fullName.trim(),
        email: data.email.trim().toLowerCase(),
        mobileNumber: data.mobileNumber.trim(),
        passwordHash: hashedPassword,
        role: 'Standard Member',
        createdAt: new Date().toISOString(),
        healthProfile: {
          preferredLanguage: 'English',
        },
      };

      users.push(newUser);
      saveUsersToStorage(users);

      // Auto login session
      setUser(newUser);
      setIsLoggedIn(true);
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({ email: newUser.email, loginTime: Date.now() }));

      setIsLoading(false);
      return { success: true, user: newUser };
    } catch {
      setIsLoading(false);
      return { success: false, error: 'Registration failed due to a server error.' };
    }
  };

  const updateHealthProfile = async (profileUpdate: Partial<UserHealthProfile>) => {
    if (!user) return false;

    const updatedHealth: UserHealthProfile = {
      ...user.healthProfile,
      ...profileUpdate,
    };

    if (updatedHealth.height || updatedHealth.weight) {
      updatedHealth.bmi = calculateBMI(updatedHealth.height, updatedHealth.weight);
    }

    const updatedUser: UserAccount = {
      ...user,
      healthProfile: updatedHealth,
    };

    setUser(updatedUser);

    const users = getUsersFromStorage();
    const idx = users.findIndex((u) => u.id === user.id);
    if (idx !== -1) {
      users[idx] = updatedUser;
      saveUsersToStorage(users);
    }
    return true;
  };

  const updateUserBasicInfo = async (fullName: string, mobileNumber: string) => {
    if (!user) return false;
    const updatedUser: UserAccount = {
      ...user,
      fullName: fullName.trim(),
      mobileNumber: mobileNumber.trim(),
    };
    setUser(updatedUser);
    const users = getUsersFromStorage();
    const idx = users.findIndex((u) => u.id === user.id);
    if (idx !== -1) {
      users[idx] = updatedUser;
      saveUsersToStorage(users);
    }
    return true;
  };

  const changePassword = async (oldPass: string, newPass: string) => {
    if (!user) return { success: false, error: 'No active session found.' };

    const oldHash = await hashPassword(oldPass);
    if (oldHash !== user.passwordHash) {
      return { success: false, error: 'Current password does not match our records.' };
    }

    const newHash = await hashPassword(newPass);
    const updatedUser: UserAccount = {
      ...user,
      passwordHash: newHash,
    };

    setUser(updatedUser);
    const users = getUsersFromStorage();
    const idx = users.findIndex((u) => u.id === user.id);
    if (idx !== -1) {
      users[idx] = updatedUser;
      saveUsersToStorage(users);
    }

    return { success: true };
  };

  const forgotPasswordReset = async (email: string, newPass: string) => {
    const users = getUsersFromStorage();
    const targetUserIndex = users.findIndex((u) => u.email.toLowerCase() === email.trim().toLowerCase());

    if (targetUserIndex === -1) {
      return { success: false, error: 'No account found matching this email address.' };
    }

    const newHash = await hashPassword(newPass);
    users[targetUserIndex].passwordHash = newHash;
    saveUsersToStorage(users);

    if (user && user.email.toLowerCase() === email.trim().toLowerCase()) {
      setUser({ ...user, passwordHash: newHash });
    }

    return { success: true };
  };

  const logout = () => {
    setUser(null);
    setIsLoggedIn(false);
    localStorage.removeItem(SESSION_STORAGE_KEY);
    sessionStorage.removeItem(SESSION_STORAGE_KEY);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoggedIn,
        isLoading,
        login,
        register,
        updateHealthProfile,
        updateUserBasicInfo,
        changePassword,
        forgotPasswordReset,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
