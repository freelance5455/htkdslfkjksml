import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User as FirebaseUser,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { UserProfile } from '../types/store';

interface AuthContextValue {
  user: FirebaseUser | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  authLoading: boolean;
  signInWithGoogle: (initialLocation?: string) => Promise<FirebaseUser>;
  signInWithEmail: (email: string, password: string, initialLocation?: string) => Promise<FirebaseUser>;
  registerWithEmail: (
    name: string,
    email: string,
    password: string,
    initialLocation?: string
  ) => Promise<FirebaseUser>;
  resendVerification: () => Promise<void>;
  updateCustomerProfile: (data: {
    displayName: string;
    phone: string;
    location: string;
    address: string;
    city: string;
    pinCode: string;
  }) => Promise<void>;
  logout: () => Promise<void>;
  refreshAdminStatus: (firebaseUser?: FirebaseUser | null) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function mapFirebaseAuthError(err: unknown): Error {
  const code = (err as { code?: string })?.code || '';
  if (code === 'auth/operation-not-allowed' || code === 'auth/configuration-not-found') {
    return new Error(
      'Email/Password sign-in is not enabled in your Firebase project yet. Please sign in with Google below, or enable Email/Password under Firebase Console → Authentication → Sign-in method.'
    );
  }
  if (code === 'auth/invalid-credential' || code === 'auth/wrong-password' || code === 'auth/user-not-found') {
    return new Error('Invalid email or password. Please check your credentials and try again.');
  }
  if (code === 'auth/email-already-in-use') {
    return new Error('An account with this email already exists. Please sign in instead.');
  }
  if (code === 'auth/weak-password') {
    return new Error('Password must be at least 6 characters long.');
  }
  if (code === 'auth/popup-closed-by-user') {
    return new Error('Sign-in window was closed before completing.');
  }
  if (code === 'auth/popup-blocked') {
    return new Error('Pop-up was blocked by your browser. Please allow pop-ups and try again.');
  }
  return err instanceof Error ? err : new Error('Authentication failed. Please try again.');
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);

  const checkAndBootstrapAdmin = async (
    firebaseUser: FirebaseUser | null = auth.currentUser
  ): Promise<boolean> => {
    if (!firebaseUser || !firebaseUser.emailVerified) {
      setIsAdmin(false);
      return false;
    }

    try {
      const adminDocRef = doc(db, 'admins', firebaseUser.uid);
      const adminSnap = await getDoc(adminDocRef);
      if (adminSnap.exists()) {
        setIsAdmin(true);
        return true;
      }

      // Probe admin list access; Firestore rules only allow authorized admins.
      // Never checks hardcoded emails in frontend code.
      await getDocs(query(collection(db, 'admins'), limit(1)));
      await setDoc(adminDocRef, {
        uid: firebaseUser.uid,
        email: firebaseUser.email || '',
        name: firebaseUser.displayName || 'Store Administrator',
        role: 'admin',
        addedBy: firebaseUser.uid,
        createdAt: serverTimestamp(),
      });
      setIsAdmin(true);
      return true;
    } catch {
      setIsAdmin(false);
      return false;
    }
  };

  const ensureCustomerProfile = async (
    firebaseUser: FirebaseUser,
    explicitName?: string,
    initialLocation?: string
  ) => {
    const userRef = doc(db, 'users', firebaseUser.uid);
    const cleanLoc = (initialLocation || '').trim().slice(0, 160);
    try {
      const snap = await getDoc(userRef);
      if (!snap.exists()) {
        await setDoc(userRef, {
          uid: firebaseUser.uid,
          displayName: explicitName || firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Customer',
          email: firebaseUser.email || '',
          phone: '',
          location: cleanLoc,
          address: '',
          city: '',
          pinCode: '',
          role: 'customer',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } else if (cleanLoc) {
        await updateDoc(userRef, {
          location: cleanLoc,
          updatedAt: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${firebaseUser.uid}`);
    }
  };

  useEffect(() => {
    let profileUnsub: (() => void) | null = null;

    const authUnsub = onAuthStateChanged(auth, async (firebaseUser) => {
      if (profileUnsub) {
        profileUnsub();
        profileUnsub = null;
      }

      setUser(firebaseUser);

      if (!firebaseUser) {
        setUserProfile(null);
        setIsAdmin(false);
        setAuthLoading(false);
        return;
      }

      try {
        await ensureCustomerProfile(firebaseUser);
        await checkAndBootstrapAdmin(firebaseUser);

        const userRef = doc(db, 'users', firebaseUser.uid);
        profileUnsub = onSnapshot(
          userRef,
          (snap) => {
            if (snap.exists()) {
              setUserProfile(snap.data() as UserProfile);
            }
          },
          (error) => {
            handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
          }
        );
      } catch (err) {
        console.error('Auth sync error:', err);
      } finally {
        setAuthLoading(false);
      }
    });

    return () => {
      authUnsub();
      if (profileUnsub) profileUnsub();
    };
  }, []);

  const signInWithGoogle = async (initialLocation?: string): Promise<FirebaseUser> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      await ensureCustomerProfile(result.user, undefined, initialLocation);
      await checkAndBootstrapAdmin(result.user);
      return result.user;
    } catch (err) {
      throw mapFirebaseAuthError(err);
    }
  };

  const signInWithEmail = async (
    email: string,
    password: string,
    initialLocation?: string
  ): Promise<FirebaseUser> => {
    try {
      const result = await signInWithEmailAndPassword(auth, email.trim(), password);
      await ensureCustomerProfile(result.user, undefined, initialLocation);
      await checkAndBootstrapAdmin(result.user);
      return result.user;
    } catch (err) {
      throw mapFirebaseAuthError(err);
    }
  };

  const registerWithEmail = async (
    name: string,
    email: string,
    password: string,
    initialLocation?: string
  ): Promise<FirebaseUser> => {
    try {
      const result = await createUserWithEmailAndPassword(auth, email.trim(), password);
      await updateProfile(result.user, { displayName: name.trim() });
      await ensureCustomerProfile(result.user, name.trim(), initialLocation);
      try {
        await sendEmailVerification(result.user);
      } catch {
        // Ignore if email verification dispatch rate-limited
      }
      return result.user;
    } catch (err) {
      throw mapFirebaseAuthError(err);
    }
  };

  const resendVerification = async () => {
    if (!auth.currentUser) throw new Error('No active session.');
    await sendEmailVerification(auth.currentUser);
  };

  const updateCustomerProfile = async (data: {
    displayName: string;
    phone: string;
    location: string;
    address: string;
    city: string;
    pinCode: string;
  }) => {
    if (!user) throw new Error('Please sign in first.');
    const userRef = doc(db, 'users', user.uid);
    try {
      await updateDoc(userRef, {
        displayName: data.displayName.trim().slice(0, 100),
        phone: data.phone.trim().slice(0, 20),
        location: data.location.trim().slice(0, 160),
        address: data.address.trim().slice(0, 300),
        city: data.city.trim().slice(0, 80),
        pinCode: data.pinCode.trim().slice(0, 12),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const logout = async () => {
    await signOut(auth);
    setIsAdmin(false);
    setUserProfile(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        isAdmin,
        authLoading,
        signInWithGoogle,
        signInWithEmail,
        registerWithEmail,
        resendVerification,
        updateCustomerProfile,
        logout,
        refreshAdminStatus: checkAndBootstrapAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
