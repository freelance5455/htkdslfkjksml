import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signOut as fbSignOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../services/firebase';
import { UserProfile } from '../types';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, username: string, displayName: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfileData: (data: Partial<UserProfile>) => Promise<{ success: boolean; error?: string }>;
  canChangeUsername: boolean;
  daysUntilUsernameChange: number;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Sync real profile from Firestore or initialize clean real user profile
  const syncProfile = async (fbUser: FirebaseUser) => {
    try {
      const userRef = doc(db, 'users', fbUser.uid);
      const snap = await getDoc(userRef);

      if (snap.exists()) {
        setUserProfile(snap.data() as UserProfile);
      } else {
        const cleanUsername = fbUser.email
          ? fbUser.email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '').toLowerCase()
          : `user_${fbUser.uid.substring(0, 6)}`;

        const initialProfile: UserProfile = {
          id: fbUser.uid,
          username: cleanUsername,
          displayName: fbUser.displayName || cleanUsername,
          email: fbUser.email || '',
          photoURL: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${cleanUsername}`,
          bio: 'Criador no ClipShare ✨',
          isVerified: false,
          postsCount: 0,
          followersCount: 0,
          followingCount: 0,
          hasInfluencerCertificate: false,
          usernameLastChangedAt: new Date().toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await setDoc(userRef, initialProfile);
        setUserProfile(initialProfile);
      }
    } catch (err) {
      console.warn('Failed to sync profile from Firestore:', err);
      const fallbackUsername = fbUser.email ? fbUser.email.split('@')[0] : 'usuario';
      setUserProfile({
        id: fbUser.uid,
        username: fallbackUsername,
        displayName: fbUser.displayName || fallbackUsername,
        photoURL: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${fallbackUsername}`,
        bio: 'Criador no ClipShare ✨',
        isVerified: false,
        postsCount: 0,
        followersCount: 0,
        followingCount: 0,
        hasInfluencerCertificate: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        await syncProfile(user);
      } else {
        // Clean default guest user without fake stats
        setUserProfile({
          id: 'guest-user',
          username: 'meu_perfil',
          displayName: 'Criador ClipShare',
          photoURL: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ClipShareUser',
          bio: 'Criador no ClipShare ✨',
          isVerified: false,
          postsCount: 0,
          followersCount: 0,
          followingCount: 0,
          hasInfluencerCertificate: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      await syncProfile(res.user);
    } catch (err: unknown) {
      console.error('Google Sign-In error:', err);
      throw err;
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    const res = await signInWithEmailAndPassword(auth, email, pass);
    await syncProfile(res.user);
  };

  const signUpWithEmail = async (email: string, pass: string, username: string, displayName: string) => {
    const res = await createUserWithEmailAndPassword(auth, email, pass);
    const newProfile: UserProfile = {
      id: res.user.uid,
      username: username.toLowerCase().replace(/[^a-z0-9_]/g, ''),
      displayName,
      email,
      photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      bio: 'Criador no ClipShare ✨',
      isVerified: false,
      postsCount: 0,
      followersCount: 0,
      followingCount: 0,
      hasInfluencerCertificate: false,
      usernameLastChangedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'users', res.user.uid), newProfile);
    setUserProfile(newProfile);
  };

  const signOut = async () => {
    await fbSignOut(auth).catch(() => {});
    setCurrentUser(null);
  };

  // 14-day rule calculation for username changes
  let canChangeUsername = true;
  let daysUntilUsernameChange = 0;
  if (userProfile?.usernameLastChangedAt) {
    const lastChanged = new Date(userProfile.usernameLastChangedAt).getTime();
    const now = Date.now();
    const diffDays = (now - lastChanged) / (1000 * 60 * 60 * 24);
    if (diffDays < 14) {
      canChangeUsername = false;
      daysUntilUsernameChange = Math.ceil(14 - diffDays);
    }
  }

  const updateProfileData = async (data: Partial<UserProfile>): Promise<{ success: boolean; error?: string }> => {
    if (!userProfile) return { success: false, error: 'Usuário não autenticado.' };

    // Check 14 days rule if username is being changed
    if (data.username && data.username !== userProfile.username) {
      if (!canChangeUsername) {
        return {
          success: false,
          error: `Você só pode alterar seu nome de usuário a cada 14 dias. Aguarde ${daysUntilUsernameChange} dia(s).`,
        };
      }
      data.usernameLastChangedAt = new Date().toISOString();
    }

    const updated = {
      ...userProfile,
      ...data,
      updatedAt: new Date().toISOString(),
    };

    try {
      if (currentUser) {
        await updateDoc(doc(db, 'users', userProfile.id), updated);
      }
      setUserProfile(updated);
      return { success: true };
    } catch {
      setUserProfile(updated);
      return { success: true };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        signOut,
        updateProfileData,
        canChangeUsername,
        daysUntilUsernameChange,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
