import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  auth, 
  db, 
  signInWithPopup, 
  googleAuthProvider, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail, 
  onAuthStateChanged,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  FirebaseUser
} from '../utils/firebase';
import { AuthUserProfile, UserRole } from '../types';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: AuthUserProfile | null;
  role: UserRole;
  storeId?: string;
  loading: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string, name: string, role?: UserRole, storeId?: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  changePassword: (oldPass: string, newPass: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfileData: (data: Partial<AuthUserProfile>) => Promise<void>;
  error: string | null;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Known Super Admins list (Admin account)
const SYSTEM_SUPER_ADMIN_EMAILS = [
  'mdsujatali20@gmail.com',
  'alimdsujat4@gmail.com',
  'admin@shanju.com'
];

// Friendly error formatter for Firebase Authentication codes
const formatAuthError = (err: any): string => {
  const code = err?.code || '';
  const message = err?.message || '';

  if (
    code === 'auth/operation-not-allowed' || 
    message.includes('PASSWORD_LOGIN_DISABLED') || 
    message.includes('operation-not-allowed')
  ) {
    return 'Firebase Authentication-এ Email/Password লগইন সক্রিয় (Enable) নেই। অনুগ্রহ করে "গুগল দিয়ে প্রবেশ করুন" (Google Sign-In) ব্যবহার করুন অথবা Firebase Console > Authentication > Sign-in method থেকে Email/Password চালু (Enable) করুন।';
  }
  if (code === 'auth/user-not-found' || code === 'auth/invalid-credential' || code === 'auth/wrong-password') {
    return 'ভুল ইমেইল বা পাসওয়ার্ড দেওয়া হয়েছে। অনুগ্রহ করে পুনরায় সঠিক তথ্য দিয়ে চেষ্টা করুন।';
  }
  if (code === 'auth/email-already-in-use') {
    return 'এই ইমেইল দিয়ে ইতোমধ্যে একটি অ্যাকাউন্ট রয়েছে। দয়া করে লগইন করুন।';
  }
  if (code === 'auth/weak-password') {
    return 'পাসওয়ার্ডটি দুর্বল। অন্তত ৬ অক্ষরের একটি শক্তিশালী পাসওয়ার্ড দিন।';
  }
  if (code === 'auth/invalid-email') {
    return 'ইমেইল অ্যাড্রেসের ফরম্যাট সঠিক নয়।';
  }
  if (code === 'auth/popup-closed-by-user') {
    return 'গুগল সাইন-ইন উইন্ডো বন্ধ করা হয়েছে। পুনরায় চেষ্টা করুন।';
  }
  if (code === 'auth/popup-blocked') {
    return 'ব্রাউজার পপআপ ব্লক করেছে। অনুগ্রহ করে ব্রাউজারে পপআপ অনুমোদন করুন।';
  }
  if (code === 'auth/network-request-failed') {
    return 'ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। সংযোগ চেক করে আবার চেষ্টা করুন।';
  }
  if (code === 'auth/api-key-not-valid') {
    return 'Firebase API কী কনফিগারেশন পুনরায় লোড করা হচ্ছে, দয়া করে আবার চেষ্টা করুন।';
  }

  return message || 'একটি অপ্রত্যাশিত ত্রুটি ঘটেছে। পুনরায় চেষ্টা করুন।';
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<AuthUserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const clearError = () => setError(null);

  // Sync Auth User and Fetch/Create Firestore Profile
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const userDocRef = doc(db, 'users', user.uid);
          const userDocSnap = await getDoc(userDocRef);

          if (userDocSnap.exists()) {
            const data = userDocSnap.data() as AuthUserProfile;
            // Check if Super Admin email
            if (user.email && SYSTEM_SUPER_ADMIN_EMAILS.includes(user.email.toLowerCase()) && data.role !== 'SUPER_ADMIN') {
              const updatedProfile = { ...data, role: 'SUPER_ADMIN' as UserRole };
              await updateDoc(userDocRef, { role: 'SUPER_ADMIN' });
              setUserProfile(updatedProfile);
            } else {
              setUserProfile(data);
            }
          } else {
            // Determine initial role
            const isSuperAdmin = user.email && SYSTEM_SUPER_ADMIN_EMAILS.includes(user.email.toLowerCase());
            const newProfile: AuthUserProfile = {
              uid: user.uid,
              email: user.email || '',
              displayName: user.displayName || user.email?.split('@')[0] || 'User',
              role: isSuperAdmin ? 'SUPER_ADMIN' : 'MERCHANT',
              createdAt: new Date().toISOString(),
              avatarUrl: user.photoURL || undefined,
              isEmailVerified: user.emailVerified,
            };
            await setDoc(userDocRef, newProfile);
            setUserProfile(newProfile);
          }
        } catch (err: any) {
          console.warn('Could not read/write Firestore user profile, using fallback session:', err);
          // Graceful fallback for local/offline session
          const isSuperAdmin = user.email && SYSTEM_SUPER_ADMIN_EMAILS.includes(user.email.toLowerCase());
          setUserProfile({
            uid: user.uid,
            email: user.email || '',
            displayName: user.displayName || user.email?.split('@')[0] || 'User',
            role: isSuperAdmin ? 'SUPER_ADMIN' : 'MERCHANT',
            createdAt: new Date().toISOString(),
          });
        }
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    setError(null);
    try {
      await signInWithPopup(auth, googleAuthProvider);
    } catch (err: any) {
      setError(formatAuthError(err));
      throw err;
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    setError(null);
    const normalizedEmail = email.trim().toLowerCase();
    try {
      await signInWithEmailAndPassword(auth, normalizedEmail, pass);
    } catch (err: any) {
      // Auto-provision Super Admin if account does not exist in Firebase Auth yet
      if (
        (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') &&
        (normalizedEmail === 'mdsujatali20@gmail.com' && pass === '26518013Sujat')
      ) {
        try {
          const cred = await createUserWithEmailAndPassword(auth, normalizedEmail, pass);
          const adminProfile: AuthUserProfile = {
            uid: cred.user.uid,
            email: normalizedEmail,
            displayName: 'Md Sujat Ali (Platform Root Admin)',
            role: 'SUPER_ADMIN',
            createdAt: new Date().toISOString(),
          };
          try {
            await setDoc(doc(db, 'users', cred.user.uid), adminProfile);
          } catch (e) {
            console.warn('Set admin profile note:', e);
          }
          setUserProfile(adminProfile);
          return;
        } catch (createErr: any) {
          setError(formatAuthError(createErr));
          throw createErr;
        }
      }

      setError(formatAuthError(err));
      throw err;
    }
  };

  const changePassword = async (oldPass: string, newPass: string) => {
    setError(null);
    if (!currentUser || !currentUser.email) {
      throw new Error('No user is currently signed in');
    }
    try {
      // Reauthenticate user before changing password
      const credential = EmailAuthProvider.credential(currentUser.email, oldPass);
      await reauthenticateWithCredential(currentUser, credential);
      await updatePassword(currentUser, newPass);
    } catch (err: any) {
      setError(formatAuthError(err));
      throw err;
    }
  };

  const registerWithEmail = async (
    email: string,
    pass: string,
    name: string,
    requestedRole: UserRole = 'MERCHANT',
    storeId?: string
  ) => {
    setError(null);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      const isSuperAdmin = SYSTEM_SUPER_ADMIN_EMAILS.includes(email.toLowerCase());
      const roleToAssign: UserRole = isSuperAdmin ? 'SUPER_ADMIN' : requestedRole;

      const newProfile: AuthUserProfile = {
        uid: cred.user.uid,
        email,
        displayName: name,
        role: roleToAssign,
        storeId,
        createdAt: new Date().toISOString(),
      };

      try {
        await setDoc(doc(db, 'users', cred.user.uid), newProfile);
      } catch (e) {
        console.warn('Firestore setDoc user profile warning:', e);
      }
      setUserProfile(newProfile);
    } catch (err: any) {
      setError(formatAuthError(err));
      throw err;
    }
  };

  const resetPassword = async (email: string) => {
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (err: any) {
      setError(formatAuthError(err));
      throw err;
    }
  };

  const logout = async () => {
    setError(null);
    try {
      await signOut(auth);
      setUserProfile(null);
    } catch (err: any) {
      setError(formatAuthError(err));
      throw err;
    }
  };

  const updateProfileData = async (data: Partial<AuthUserProfile>) => {
    if (!currentUser || !userProfile) return;
    const updated = { ...userProfile, ...data };
    setUserProfile(updated);
    try {
      await updateDoc(doc(db, 'users', currentUser.uid), data);
    } catch (err) {
      console.warn('Update user profile warning:', err);
    }
  };

  const role: UserRole = userProfile?.role || 'CUSTOMER';
  const storeId = userProfile?.storeId;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        role,
        storeId,
        loading,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        resetPassword,
        changePassword,
        logout,
        updateProfileData,
        error,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
