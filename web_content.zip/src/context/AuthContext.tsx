import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { api } from '../services/api';
import { wsClient } from '../services/websocket';

interface AuthContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  login: (user: User) => void;
  logout: () => void;
  switchUser: (user: User) => void;
  updateCurrentUserProfile: (data: Partial<User>) => Promise<User>;
  isAuthModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  authModalTab: 'login' | 'register' | 'recover';
  setAuthModalTab: (tab: 'login' | 'register' | 'recover') => void;
  availableDemoUsers: User[];
  loadDemoUsers: () => Promise<void>;
  onlineUsers: string[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEY = 'angola_connect_current_user';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUserState] = useState<User | null>(null);
  const [isAuthModalOpen, setAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register' | 'recover'>('login');
  const [availableDemoUsers, setAvailableDemoUsers] = useState<User[]>([]);
  const [onlineUsers, setOnlineUsers] = useState<string[]>([]);

  const loadDemoUsers = async () => {
    try {
      const res = await api.searchUsers();
      if (res.users) {
        setAvailableDemoUsers(res.users);
      }
    } catch (err) {
      console.warn('Erro ao carregar lista de utilizadores:', err);
    }
  };

  useEffect(() => {
    // 1. Load cached user or set default seed user
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setCurrentUserState(parsed);
        wsClient.init(parsed.id);
      } catch (e) {
        localStorage.removeItem(STORAGE_KEY);
      }
    } else {
      // Auto-login with Maria Tchizé or Admin for seamless experience
      api.searchUsers().then(res => {
        if (res.users && res.users.length > 0) {
          const defaultUser = res.users[0]; // Admin or Maria
          setCurrentUserState(defaultUser);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultUser));
          wsClient.init(defaultUser.id);
        }
      }).catch(() => {});
    }

    loadDemoUsers();

    // Listen to presence updates
    const unsub = wsClient.on('presence:change', (data) => {
      if (data?.onlineUsers) {
        setOnlineUsers(data.onlineUsers);
      }
    });

    return () => {
      unsub();
      wsClient.disconnect();
    };
  }, []);

  const login = (user: User) => {
    setCurrentUserState(user);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    wsClient.init(user.id);
    setAuthModalOpen(false);
  };

  const logout = () => {
    wsClient.disconnect();
    setCurrentUserState(null);
    localStorage.removeItem(STORAGE_KEY);
    setAuthModalOpen(true);
    setAuthModalTab('login');
  };

  const switchUser = (user: User) => {
    wsClient.disconnect();
    setCurrentUserState(user);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    wsClient.init(user.id);
  };

  const updateCurrentUserProfile = async (data: Partial<User>): Promise<User> => {
    if (!currentUser) throw new Error('Não autenticado');
    const res = await api.updateProfile(currentUser.id, data);
    const updated = { ...currentUser, ...res.user };
    setCurrentUserState(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        setCurrentUser: setCurrentUserState,
        login,
        logout,
        switchUser,
        updateCurrentUserProfile,
        isAuthModalOpen,
        setAuthModalOpen,
        authModalTab,
        setAuthModalTab,
        availableDemoUsers,
        loadDemoUsers,
        onlineUsers
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth deve ser utilizado dentro de AuthProvider');
  }
  return ctx;
};
