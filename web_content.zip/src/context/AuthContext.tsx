// Application Authentication & RBAC Session Provider
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Branch, PermissionCode } from '../types';
import { dbStore } from '../server/services/dbStore';
import { hasPermission } from '../server/auth/roles';

interface AuthContextType {
  currentUser: User | null;
  currentBranch: Branch;
  allBranches: Branch[];
  setCurrentBranch: (branch: Branch) => void;
  can: (permission: PermissionCode) => boolean;
  login: (usernameOrEmail: string, passwordPlain: string) => { success: boolean; error?: string };
  logout: () => void;
  switchUser: (userId: string) => void;
  availableUsers: User[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [availableUsers, setAvailableUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [allBranches, setAllBranches] = useState<Branch[]>([]);
  const [currentBranch, setCurrentBranchState] = useState<Branch>({
    id: 'branch-01-downtown',
    code: 'MAIN-01',
    name: 'Main Flagship Supermarket - Downtown',
    address: 'Bole Road, Central Plaza, Addis Ababa',
    isMain: true,
    active: true,
  });

  useEffect(() => {
    const users = dbStore.getUsers();
    setAvailableUsers(users);

    const branches = dbStore.getBranches();
    setAllBranches(branches);

    // Default to Super Admin for initial session or read stored
    const savedUserId = typeof window !== 'undefined' ? localStorage.getItem('apex_pos_session_user') : null;
    const defaultUser = (savedUserId && users.find((u) => u.id === savedUserId)) || users[0] || null;
    setCurrentUser(defaultUser);

    if (defaultUser?.branchId) {
      const b = branches.find((br) => br.id === defaultUser.branchId);
      if (b) setCurrentBranchState(b);
    }
  }, []);

  const setCurrentBranch = (branch: Branch) => {
    setCurrentBranchState(branch);
  };

  const can = (permission: PermissionCode): boolean => {
    if (!currentUser) return false;
    return hasPermission(currentUser.role, permission);
  };

  const login = (usernameOrEmail: string, passwordPlain: string): { success: boolean; error?: string } => {
    const res = dbStore.authenticate(usernameOrEmail, passwordPlain);
    if (res.user) {
      setCurrentUser(res.user);
      if (typeof window !== 'undefined') {
        localStorage.setItem('apex_pos_session_user', res.user.id);
      }
      return { success: true };
    }
    return { success: false, error: res.error || 'Authentication failed' };
  };

  const logout = () => {
    if (currentUser) {
      dbStore.createAuditLog(currentUser.id, currentUser.name, 'LOGOUT', 'USER', currentUser.id);
    }
    setCurrentUser(null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem('apex_pos_session_user');
    }
  };

  const switchUser = (userId: string) => {
    const user = dbStore.getUserById(userId);
    if (user) {
      setCurrentUser(user);
      if (typeof window !== 'undefined') {
        localStorage.setItem('apex_pos_session_user', user.id);
      }
      dbStore.createAuditLog(user.id, user.name, 'SESSION_SWITCH', 'USER', user.id, {
        switchedToRole: user.role,
      });
      if (user.branchId) {
        const b = allBranches.find((br) => br.id === user.branchId);
        if (b) setCurrentBranchState(b);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentBranch,
        allBranches,
        setCurrentBranch,
        can,
        login,
        logout,
        switchUser,
        availableUsers,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
