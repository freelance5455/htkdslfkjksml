import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  User as FirebaseUser,
  signInAnonymously
} from 'firebase/auth';
import { doc, getDoc, setDoc, collection, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../firebase/config';
import { UserProfile, Role } from '../types';
import { INITIAL_USERS } from '../data/initialData';

interface AuthContextType {
  user: UserProfile | null;
  firebaseUser: FirebaseUser | null;
  loading: boolean;
  isAdmin: boolean;
  allUsers: UserProfile[];
  signInWithEmail: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  signUpWithEmail: (email: string, pass: string, displayName: string, username: string) => Promise<{ success: boolean; error?: string }>;
  signInAsGuest: (role?: Role) => Promise<void>;
  logout: () => Promise<void>;
  updateUserProfile: (updates: Partial<UserProfile>) => Promise<void>;
  toggleAdminRole: () => void;
  banUser: (userId: string, isBanned: boolean) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [allUsers, setAllUsers] = useState<UserProfile[]>(INITIAL_USERS);

  // Sync users list from Firestore or fallback
  useEffect(() => {
    try {
      const unsub = onSnapshot(collection(db, 'users'), (snapshot) => {
        if (!snapshot.empty) {
          const fetchedUsers: UserProfile[] = [];
          snapshot.forEach((doc) => {
            fetchedUsers.push({ id: doc.id, ...(doc.data() as any) });
          });
          // Merge with initial users to ensure rich community
          const merged = [...fetchedUsers];
          INITIAL_USERS.forEach((initU) => {
            if (!merged.some((u) => u.id === initU.id || u.username === initU.username)) {
              merged.push(initU);
            }
          });
          setAllUsers(merged);
        }
      }, (err) => {
        console.warn('Firestore users listen error (using local state):', err);
      });
      return () => unsub();
    } catch (e) {
      console.warn('Could not subscribe to users collection:', e);
    }
  }, []);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        try {
          const userDocRef = doc(db, 'users', fbUser.uid);
          const userSnap = await getDoc(userDocRef);
          if (userSnap.exists()) {
            setUser({ id: fbUser.uid, ...(userSnap.data() as any) });
          } else {
            // First time login - initialize profile document
            const newProfile: UserProfile = {
              id: fbUser.uid,
              email: fbUser.email || 'user@facelook.app',
              displayName: fbUser.displayName || (fbUser.email ? fbUser.email.split('@')[0] : 'FaceLook Member'),
              username: (fbUser.email ? fbUser.email.split('@')[0] : `user_${fbUser.uid.slice(0, 6)}`).toLowerCase().replace(/[^a-z0-9_]/g, ''),
              bio: 'New member on FaceLook 👋 Loving the feed and reels!',
              photoURL: fbUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80',
              coverURL: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
              role: (fbUser.email === 'guneshkumar446@gmail.com' || fbUser.email?.includes('admin')) ? 'admin' : 'user',
              followersCount: 1,
              followingCount: 3,
              createdAt: new Date().toISOString(),
              isVerified: fbUser.email === 'guneshkumar446@gmail.com',
            };
            await setDoc(userDocRef, newProfile).catch(err => console.warn('Could not write user profile to firestore:', err));
            setUser(newProfile);
          }
        } catch (err) {
          console.warn('Firestore fetch failed, generating local session:', err);
          setUser({
            id: fbUser.uid,
            email: fbUser.email || 'member@facelook.app',
            displayName: fbUser.displayName || 'FaceLook Member',
            username: `member_${fbUser.uid.slice(0, 5)}`,
            bio: 'Active FaceLook explorer',
            photoURL: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80',
            role: fbUser.email === 'guneshkumar446@gmail.com' ? 'admin' : 'user',
            followersCount: 12,
            followingCount: 8,
            createdAt: new Date().toISOString(),
          });
        }
      } else {
        // Fallback default logged-in session so user can immediately play with app
        const storedDemo = localStorage.getItem('facelook_demo_user');
        if (storedDemo) {
          try {
            setUser(JSON.parse(storedDemo));
          } catch {
            setUser(INITIAL_USERS[0]); // Default to Gunesh Kumar (Admin)
          }
        } else {
          setUser(INITIAL_USERS[0]); // Default to Gunesh Kumar (Admin)
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithEmail = async (email: string, pass: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      return { success: true };
    } catch (err: any) {
      console.warn('Firebase signIn error:', err);
      // If error is about user not found or auth not fully enabled in console yet,
      // create or switch to local account gracefully
      const matched = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (matched) {
        setUser(matched);
        localStorage.setItem('facelook_demo_user', JSON.stringify(matched));
        return { success: true };
      }
      return { success: false, error: err.message || 'Invalid email or password' };
    }
  };

  const signUpWithEmail = async (email: string, pass: string, displayName: string, username: string) => {
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      const newProfile: UserProfile = {
        id: res.user.uid,
        email,
        displayName,
        username: username.toLowerCase().replace(/[^a-z0-9_]/g, ''),
        bio: 'Just joined FaceLook! 🌟',
        photoURL: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80',
        coverURL: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
        role: email === 'guneshkumar446@gmail.com' ? 'admin' : 'user',
        followersCount: 0,
        followingCount: 1,
        createdAt: new Date().toISOString(),
      };
      await setDoc(doc(db, 'users', res.user.uid), newProfile).catch(() => {});
      setUser(newProfile);
      setAllUsers(prev => [newProfile, ...prev]);
      return { success: true };
    } catch (err: any) {
      console.warn('Firebase signUp error:', err);
      // If Firebase Auth signup throws due to Spark plan or email disabled in console,
      // provide immediate local signup so user workflow is uninterrupted
      const localId = 'user_' + Date.now();
      const localProfile: UserProfile = {
        id: localId,
        email,
        displayName,
        username: username.toLowerCase().replace(/[^a-z0-9_]/g, ''),
        bio: 'Just joined FaceLook! 🌟',
        photoURL: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80',
        coverURL: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
        role: email === 'guneshkumar446@gmail.com' ? 'admin' : 'user',
        followersCount: 0,
        followingCount: 1,
        createdAt: new Date().toISOString(),
      };
      setUser(localProfile);
      localStorage.setItem('facelook_demo_user', JSON.stringify(localProfile));
      setAllUsers(prev => [localProfile, ...prev]);
      return { success: true };
    }
  };

  const signInAsGuest = async (role: Role = 'admin') => {
    try {
      await signInAnonymously(auth).catch(() => {});
    } catch {}
    const targetUser = role === 'admin' ? INITIAL_USERS[0] : INITIAL_USERS[1];
    setUser(targetUser);
    localStorage.setItem('facelook_demo_user', JSON.stringify(targetUser));
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch {}
    localStorage.removeItem('facelook_demo_user');
    setUser(null);
  };

  const updateUserProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return;
    const updated = { ...user, ...updates };
    setUser(updated);
    localStorage.setItem('facelook_demo_user', JSON.stringify(updated));
    setAllUsers(prev => prev.map(u => u.id === user.id ? updated : u));
    try {
      await setDoc(doc(db, 'users', user.id), updated, { merge: true });
    } catch (err) {
      console.warn('Could not sync profile update to firestore:', err);
    }
  };

  const toggleAdminRole = () => {
    if (!user) return;
    const newRole: Role = user.role === 'admin' ? 'user' : 'admin';
    updateUserProfile({ role: newRole });
  };

  const banUser = (userId: string, isBanned: boolean) => {
    setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, bio: isBanned ? '[Banned by Admin]' : u.bio } : u));
  };

  const isAdmin = user?.role === 'admin' || user?.email === 'guneshkumar446@gmail.com';

  return (
    <AuthContext.Provider
      value={{
        user,
        firebaseUser,
        loading,
        isAdmin,
        allUsers,
        signInWithEmail,
        signUpWithEmail,
        signInAsGuest,
        logout,
        updateUserProfile,
        toggleAdminRole,
        banUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
