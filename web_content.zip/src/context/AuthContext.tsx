import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, googleProvider, db, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile } from '../types';

import { generateUniqueUserId } from '../services/hartTeamService';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isPublisher: boolean;
  isOwner: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, name: string) => Promise<void>;
  signOutUser: () => Promise<void>;
  updateUserProfile: (data: Partial<UserProfile>) => Promise<void>;
  activatePublisherAccount: () => Promise<void>;
}

const OWNER_EMAIL = '17noranimations17@gmail.com';

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  isPublisher: false,
  isOwner: false,
  signInWithGoogle: async () => {},
  signInWithEmail: async () => {},
  signUpWithEmail: async () => {},
  signOutUser: async () => {},
  updateUserProfile: async () => {},
  activatePublisherAccount: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isPublisher, setIsPublisher] = useState(false);
  const [isOwner, setIsOwner] = useState(false);

  const syncUserProfile = async (currentUser: User | null) => {
    if (!currentUser) {
      setProfile(null);
      setIsPublisher(false);
      setIsOwner(false);
      return;
    }

    const isPlatformOwner = currentUser.email?.toLowerCase() === OWNER_EMAIL.toLowerCase();
    setIsOwner(isPlatformOwner);

    try {
      const userDocRef = doc(db, 'users', currentUser.uid);
      const userSnap = await getDoc(userDocRef);

      if (userSnap.exists()) {
        const data = userSnap.data() as UserProfile;
        let needsUpdate = false;
        const updates: Partial<UserProfile> = {};

        // If user is platform owner, ensure role is owner
        if (isPlatformOwner && data.role !== 'owner') {
          updates.role = 'owner';
          data.role = 'owner';
          needsUpdate = true;
        }

        // Ensure permanent Unique ID exists
        if (!data.uniqueId) {
          const generatedId = generateUniqueUserId(currentUser.uid);
          updates.uniqueId = generatedId;
          data.uniqueId = generatedId;
          needsUpdate = true;
        }

        // Ensure userTag exists
        if (!data.userTag) {
          const generatedTag = (data.displayName || currentUser.email?.split('@')[0] || 'user')
            .toLowerCase()
            .replace(/[^a-z0-9_]/g, '_');
          updates.userTag = generatedTag;
          data.userTag = generatedTag;
          needsUpdate = true;
        }

        if (needsUpdate) {
          await updateDoc(userDocRef, updates);
        }

        setProfile(data);
        setIsPublisher(data.role === 'owner' || data.role === 'admin' || data.role === 'publisher' || data.role === 'team_leader');
      } else {
        // Initialize new user profile document in Firestore
        const uniqueId = generateUniqueUserId(currentUser.uid);
        const userTag = (currentUser.displayName || currentUser.email?.split('@')[0] || 'user')
          .toLowerCase()
          .replace(/[^a-z0-9_]/g, '_');

        const newProfile: UserProfile = {
          uid: currentUser.uid,
          uniqueId,
          userTag,
          email: currentUser.email || '',
          displayName: currentUser.displayName || currentUser.email?.split('@')[0] || 'قارئ مانهوا',
          photoUrl: currentUser.photoURL || '',
          bio: 'عاشق للمانهوا والمانجا في مانهوا هارت',
          role: isPlatformOwner ? 'owner' : 'publisher', // default every registered user can also publish / lead teams
          createdAt: new Date().toISOString()
        };

        await setDoc(userDocRef, newProfile);
        setProfile(newProfile);
        setIsPublisher(true);
      }

      // Also ensure publishers document for backward compatibility
      const pubDocRef = doc(db, 'publishers', currentUser.uid);
      const pubSnap = await getDoc(pubDocRef);
      if (!pubSnap.exists()) {
        await setDoc(pubDocRef, {
          uid: currentUser.uid,
          email: currentUser.email || '',
          displayName: currentUser.displayName || 'ناشر',
          role: isPlatformOwner ? 'owner' : 'publisher',
          createdAt: new Date().toISOString()
        });
      }
    } catch (error) {
      console.warn('Sync user profile notice:', error);
      if (isPlatformOwner) {
        setIsPublisher(true);
        setIsOwner(true);
      }
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      await syncUserProfile(currentUser);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      await syncUserProfile(cred.user);
    } catch (error) {
      console.error('Google Sign In Error:', error);
      throw error;
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    try {
      const cred = await signInWithEmailAndPassword(auth, email, pass);
      await syncUserProfile(cred.user);
    } catch (error) {
      console.error('Email Sign In Error:', error);
      throw error;
    }
  };

  const signUpWithEmail = async (email: string, pass: string, name: string) => {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      if (name) {
        await updateProfile(cred.user, { displayName: name });
      }
      await syncUserProfile(cred.user);
    } catch (error) {
      console.error('Email Sign Up Error:', error);
      throw error;
    }
  };

  const signOutUser = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setProfile(null);
      setIsPublisher(false);
      setIsOwner(false);
    } catch (error) {
      console.error('Sign Out Error:', error);
    }
  };

  const updateUserProfile = async (data: Partial<UserProfile>) => {
    if (!user) return;
    try {
      const userDocRef = doc(db, 'users', user.uid);
      await updateDoc(userDocRef, data);
      setProfile((prev) => (prev ? { ...prev, ...data } : null));

      if (data.displayName && auth.currentUser) {
        await updateProfile(auth.currentUser, { displayName: data.displayName });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const activatePublisherAccount = async () => {
    if (!user) {
      await signInWithGoogle();
      return;
    }
    await updateUserProfile({ role: isOwner ? 'owner' : 'publisher' });
    setIsPublisher(true);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        isPublisher,
        isOwner,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        signOutUser,
        updateUserProfile,
        activatePublisherAccount
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
