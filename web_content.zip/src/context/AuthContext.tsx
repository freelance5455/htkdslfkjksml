import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { storageService } from '../services/storage';

interface AuthContextType {
  currentUser: User | null;
  isAdmin: boolean;
  isEmployee: boolean;
  login: (username: string, pass: string) => { success: boolean; message?: string };
  quickLogin: (user: User) => void;
  logout: () => void;
  refreshUser: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_USER_KEY = 'resto_current_user_session';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    if (typeof window === 'undefined') return null;
    try {
      const saved = localStorage.getItem(AUTH_USER_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return null;
  });

  // Keep session synced if user data gets updated in storage
  const refreshUser = () => {
    if (!currentUser) return;
    const allUsers = storageService.getUsers();
    const found = allUsers.find((u) => u.id === currentUser.id);
    if (found) {
      setCurrentUser(found);
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(found));
    }
  };

  const login = (username: string, pass: string) => {
    const user = storageService.authenticate(username, pass);
    if (!user) {
      return { success: false, message: 'Usuario o contraseña incorrectos, o usuario inactivo.' };
    }
    setCurrentUser(user);
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
    return { success: true };
  };

  const quickLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem(AUTH_USER_KEY);
  };

  const isAdmin = currentUser?.role === 'ADMIN';
  const isEmployee = currentUser?.role === 'EMPLEADO';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAdmin,
        isEmployee,
        login,
        quickLogin,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
