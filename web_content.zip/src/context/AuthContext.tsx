import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import type { User } from "@/types";
import {
  getSession,
  login as authLogin,
  logout as authLogout,
  directAccess as authDirectAccess,
  registerDirect as authRegisterDirect,
  verifyServerSession,
  AuthSession,
} from "@/lib/auth";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  authenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  directAccess: (name?: string, email?: string) => Promise<boolean>;
  registerDirect: (name: string, email: string) => Promise<boolean>;
  logout: () => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => getSession()?.user ?? null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const syncSession = useCallback((session: AuthSession | null) => {
    if (session?.user) {
      setUser(session.user);
    } else {
      setUser(null);
    }
  }, []);

  useEffect(() => {
    // Initial check
    const current = getSession();
    if (current?.user) {
      setUser(current.user);
    }

    // Verify session with server asynchronously
    verifyServerSession().then((verified) => {
      if (verified?.user) {
        setUser(verified.user);
      }
    });

    // Listen for storage events (e.g. cross-tab or direct storage changes)
    const handleStorage = (e: StorageEvent) => {
      if (e.key === "acs_session") {
        const fresh = getSession();
        syncSession(fresh);
      }
    };
    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, [syncSession]);

  const clearError = useCallback(() => setError(null), []);

  const handleLogin = useCallback(async (email: string, password: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const result = await authLogin(email, password);
      if (result.success && result.session) {
        setUser(result.session.user);
        setLoading(false);
        return true;
      } else {
        setError(result.error ?? "Credenciais inválidas");
        setLoading(false);
        return false;
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Falha na autenticação";
      setError(msg);
      setLoading(false);
      return false;
    }
  }, []);

  const handleDirectAccess = useCallback(async (name?: string, email?: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const result = await authDirectAccess(name, email);
      if (result.success && result.session) {
        setUser(result.session.user);
        setLoading(false);
        return true;
      } else {
        setError(result.error ?? "Erro ao entrar diretamente");
        setLoading(false);
        return false;
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro no acesso";
      setError(msg);
      setLoading(false);
      return false;
    }
  }, []);

  const handleRegisterDirect = useCallback(async (name: string, email: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const result = await authRegisterDirect(name, email);
      if (result.success && result.session) {
        setUser(result.session.user);
        setLoading(false);
        return true;
      } else {
        setError(result.error ?? "Erro no cadastro");
        setLoading(false);
        return false;
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro no cadastro";
      setError(msg);
      setLoading(false);
      return false;
    }
  }, []);

  const handleLogout = useCallback(async () => {
    await authLogout();
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        error,
        authenticated: !!user,
        login: handleLogin,
        directAccess: handleDirectAccess,
        registerDirect: handleRegisterDirect,
        logout: handleLogout,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export { AuthContext };

