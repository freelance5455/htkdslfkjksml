import React, { createContext, useContext, useState, useEffect } from 'react';
import { api, getStoredToken } from '../services/api';
import {
  signInWithGoogle,
  signOutUser,
  subscribeToAuthState,
} from '../firebase/authService';
import {
  createOrUpdateUserProfile,
  updateUserProfile as updateFirestoreProfile,
} from '../firebase/userProfileService';

export interface User {
  id: string; // Firebase UID
  uid: string; // Explicit Firebase UID
  name: string; // Display name
  email: string; // Gmail address
  photoURL?: string; // Profile photo URL
  role: 'CUSTOMER' | 'ADMIN' | 'SUPER_ADMIN';
  phone?: string;
  createdAt?: string;
}

export interface Address {
  id: string;
  userId: string;
  fullName: string;
  phone: string;
  house?: string;
  street: string;
  landmark?: string;
  city: string;
  state: string;
  pincode: string;
  isDefault: boolean;
  type: 'home' | 'work' | 'other';
  latitude?: number;
  longitude?: number;
  createdAt?: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
  image: string;
}

export interface TrackingEvent {
  id: string;
  eventType: string;
  status: string;
  message: string;
  location?: string;
  timestamp: string;
  courierName?: string;
  awbNumber?: string;
}

export interface ReturnExchangeDetails {
  id: string;
  type: 'return' | 'exchange';
  reason: string;
  comments?: string;
  exchangeSize?: string;
  exchangeColor?: string;
  status:
    | 'REQUESTED'
    | 'APPROVED'
    | 'PICKUP_SCHEDULED'
    | 'PICKED_UP'
    | 'IN_TRANSIT'
    | 'QC_PASSED'
    | 'REFUND_INITIATED'
    | 'COMPLETED'
    | 'REJECTED';
  pickupAddress: {
    fullName: string;
    phone: string;
    street: string;
    city: string;
    state: string;
    pincode: string;
  };
  courierPartner?: string;
  awbNumber?: string;
  requestedAt: string;
  updatedAt: string;
}

export interface NotificationItem {
  id: string;
  userId?: string;
  orderId?: string;
  title: string;
  message: string;
  type: string;
  channel: 'in_app' | 'email' | 'sms' | 'whatsapp' | 'push';
  read: boolean;
  createdAt: string;
}

export interface Order {
  id: string;
  userId: string;
  userEmail: string;
  items: OrderItem[];
  subtotal: number;
  discountAmount: number;
  couponCode?: string;
  shippingFee: number;
  taxAmount: number;
  total: number;
  shippingAddress: {
    fullName: string;
    phone: string;
    street: string;
    city: string;
    state: string;
    pincode: string;
  };
  paymentMethod: 'cod'; // Exclusively Cash on Delivery
  taxBreakup?: {
    cgst: number;
    sgst: number;
    igst: number;
    rate: number;
  };
  countryOfOrigin?: string;
  paymentStatus: 'PAID' | 'PENDING' | 'REFUNDED' | 'FAILED';
  orderStatus:
    | 'PENDING'
    | 'CONFIRMED'
    | 'PROCESSING'
    | 'PACKED'
    | 'READY_FOR_PICKUP'
    | 'PICKED_UP'
    | 'SHIPPED'
    | 'IN_TRANSIT'
    | 'OUT_FOR_DELIVERY'
    | 'DELIVERED'
    | 'CANCELLED'
    | 'RETURN_REQUESTED'
    | 'RETURN_APPROVED'
    | 'RETURN_PICKED_UP'
    | 'RETURNED'
    | 'REFUNDED';
  trackingNumber?: string;
  courierPartner?: string;
  awbNumber?: string;
  shipmentId?: string;
  trackingUrl?: string;
  expectedDeliveryDate?: string;
  dispatchedAt?: string;
  deliveredAt?: string;
  cancellationReason?: string;
  cancellationDate?: string;
  refundStatus?: 'NOT_APPLICABLE' | 'PENDING' | 'PROCESSING' | 'REFUNDED' | 'FAILED';
  refundAmount?: number;
  refundTxnId?: string;
  returnDetails?: ReturnExchangeDetails;
  trackingEvents?: TrackingEvent[];
  createdAt: string;
  updatedAt: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  loginWithGoogle: (flowHint?: 'google' | 'gmail') => Promise<void>;
  loginWithGmail: () => Promise<void>;
  googleLogin: (credential?: string, email?: string, name?: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (name?: string, phone?: string) => Promise<void>;
  addresses: Address[];
  fetchAddresses: () => Promise<void>;
  addAddress: (addr: Omit<Address, 'id' | 'userId'>) => Promise<Address>;
  updateAddress: (id: string, addr: Partial<Omit<Address, 'id' | 'userId'>>) => Promise<Address>;
  setDefaultAddress: (id: string) => Promise<void>;
  deleteAddress: (id: string) => Promise<void>;
  orders: Order[];
  fetchOrders: () => Promise<void>;
  cancelOrder: (orderId: string, reason?: string) => Promise<void>;
  requestReturnOrExchange: (orderId: string, payload: any) => Promise<void>;
  createOrder: (payload: any) => Promise<Order>;
  wishlistIds: Set<string>;
  toggleWishlist: (productId: string) => Promise<void>;
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  fetchNotifications: () => Promise<void>;
  markNotificationRead: (id: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  clearAllNotifications: () => Promise<void>;
  addRealNotification: (item: Omit<NotificationItem, 'id' | 'createdAt' | 'read'> & { id?: string }) => void;
  requestNotificationPermission: () => Promise<boolean>;
  notificationPermission: NotificationPermission | 'unsupported';
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const GUEST_WISHLIST_KEY = 'ntix_guest_wishlist';
const GUEST_NOTIFICATIONS_KEY = 'ntix_guest_notifications';

// Clean Web Audio chime for real-time notification feedback
export function playNotificationSound() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    gain1.gain.setValueAtTime(0.04, now);
    gain1.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.15);

    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880, now + 0.08); // A5
    gain2.gain.setValueAtTime(0.05, now + 0.08);
    gain2.gain.exponentialRampToValueAtTime(0.0001, now + 0.3);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.08);
    osc2.stop(now + 0.3);
  } catch {
    // Audio autoplay policy
  }
}

// Native Browser Push Notification
export function triggerBrowserNotification(title: string, body: string) {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: 'https://i.ibb.co/DPSH5zWH/file-0000000097e0820e8fee2af4891849a5.png',
        badge: 'https://i.ibb.co/DPSH5zWH/file-0000000097e0820e8fee2af4891849a5.png',
      });
    } catch {
      // Ignored
    }
  }
}

function getGuestNotifications(): NotificationItem[] {
  try {
    const raw = localStorage.getItem(GUEST_NOTIFICATIONS_KEY);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) {
        const realItems = arr.filter(
          (n: any) =>
            n &&
            typeof n.id === 'string' &&
            !n.id.startsWith('notif-welcome') &&
            !n.id.startsWith('notif-coupon') &&
            !n.id.startsWith('notif-security')
        );
        return realItems;
      }
    }
  } catch {
    // Ignore
  }
  return [];
}

function saveGuestNotifications(notifs: NotificationItem[]) {
  try {
    localStorage.setItem(GUEST_NOTIFICATIONS_KEY, JSON.stringify(notifs));
  } catch {
    // Ignore
  }
}

function getGuestWishlist(): Set<string> {
  try {
    const raw = localStorage.getItem(GUEST_WISHLIST_KEY);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) return new Set(arr);
    }
  } catch {
    // Ignore
  }
  return new Set();
}

function saveGuestWishlist(set: Set<string>) {
  try {
    localStorage.setItem(GUEST_WISHLIST_KEY, JSON.stringify(Array.from(set)));
  } catch {
    // Ignore
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>(getGuestNotifications());
  const [unreadNotificationCount, setUnreadNotificationCount] = useState<number>(() => {
    return getGuestNotifications().filter((n) => !n.read).length;
  });
  const [wishlistIds, setWishlistIds] = useState<Set<string>>(getGuestWishlist());
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission | 'unsupported'>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'unsupported';
  });

  const requestNotificationPermission = async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('Notification' in window)) return false;
    try {
      const res = await Notification.requestPermission();
      setNotificationPermission(res);
      if (res === 'granted') {
        playNotificationSound();
        triggerBrowserNotification(
          'OMAZIFY Alerts Enabled',
          'You will receive instant delivery and order tracking updates.'
        );
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const addRealNotification = (
    item: Omit<NotificationItem, 'id' | 'createdAt' | 'read'> & { id?: string }
  ) => {
    const newNotif: NotificationItem = {
      id: item.id || `notif-real-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString(),
      read: false,
      ...item,
    };
    setNotifications((prev) => {
      if (prev.some((n) => n.id === newNotif.id)) return prev;
      const updated = [newNotif, ...prev];
      if (!user) saveGuestNotifications(updated);
      return updated;
    });
    setUnreadNotificationCount((prev) => prev + 1);
    playNotificationSound();
    triggerBrowserNotification(newNotif.title, newNotif.message);
  };

  const fetchNotifications = async () => {
    if (user) {
      try {
        const res = await api.getNotifications();
        if (res && Array.isArray(res.notifications) && res.notifications.length > 0) {
          setNotifications(res.notifications);
          setUnreadNotificationCount(res.unreadCount || 0);
          return;
        }
      } catch {
        // Fallback to guest below
      }
    }
    const guestNotifs = getGuestNotifications();
    setNotifications(guestNotifs);
    setUnreadNotificationCount(guestNotifs.filter((n) => !n.read).length);
  };

  const markNotificationRead = async (id: string) => {
    if (user) {
      try {
        await api.markNotificationRead(id);
      } catch {
        // Ignore
      }
    }
    setNotifications((prev) => {
      const updated = prev.map((n) => (n.id === id ? { ...n, read: true } : n));
      if (!user) saveGuestNotifications(updated);
      return updated;
    });
    setUnreadNotificationCount((prev) => Math.max(0, prev - 1));
  };

  const markAllNotificationsRead = async () => {
    if (user) {
      try {
        await api.markAllNotificationsRead();
      } catch {
        // Ignore
      }
    }
    setNotifications((prev) => {
      const updated = prev.map((n) => ({ ...n, read: true }));
      if (!user) saveGuestNotifications(updated);
      return updated;
    });
    setUnreadNotificationCount(0);
  };

  const deleteNotification = async (id: string) => {
    if (user) {
      try {
        await api.deleteNotification(id);
      } catch {
        // Ignore
      }
    }
    setNotifications((prev) => {
      const target = prev.find((n) => n.id === id);
      const updated = prev.filter((n) => n.id !== id);
      if (!user) saveGuestNotifications(updated);
      if (target && !target.read) {
        setUnreadNotificationCount((c) => Math.max(0, c - 1));
      }
      return updated;
    });
  };

  const clearAllNotifications = async () => {
    if (user) {
      try {
        await api.clearAllNotifications();
      } catch {
        // Ignore
      }
    }
    setNotifications([]);
    if (!user) saveGuestNotifications([]);
    setUnreadNotificationCount(0);
  };

  const loadUserData = async (currentUser?: User) => {
    try {
      const [addrRes, ordRes, wishRes] = await Promise.all([
        api.getUserAddresses().catch(() => ({ addresses: [] })),
        api.getUserOrders().catch(() => ({ orders: [] })),
        api.getWishlist().catch(() => ({ productIds: [] })),
      ]);
      setAddresses(addrRes.addresses || []);
      setOrders(ordRes.orders || []);
      fetchNotifications();
      const guestIds = getGuestWishlist();
      const serverIds = new Set<string>(wishRes.productIds || []);
      const mergedSet = new Set<string>([...guestIds, ...serverIds]);
      if (guestIds.size > 0) {
        try {
          const syncRes = await api.syncWishlist(Array.from(mergedSet));
          if (syncRes.productIds) {
            setWishlistIds(new Set(syncRes.productIds));
          } else {
            setWishlistIds(mergedSet);
          }
        } catch {
          setWishlistIds(mergedSet);
        }
        saveGuestWishlist(new Set());
      } else {
        setWishlistIds(mergedSet);
      }
    } catch {
      // Ignore
    }
  };

  useEffect(() => {
    let isMounted = true;
    const safetyTimer = setTimeout(() => {
      if (isMounted) {
        setIsLoading(false);
      }
    }, 2000);

    const unsubscribe = subscribeToAuthState(async (firebaseUser) => {
      clearTimeout(safetyTimer);
      if (!isMounted) return;
      if (firebaseUser) {
        try {
          const profile = await createOrUpdateUserProfile(firebaseUser);
          const syncedUser: User = {
            id: firebaseUser.uid,
            uid: firebaseUser.uid,
            name: firebaseUser.displayName || profile.name || 'OMAZIFY Shopper',
            email: firebaseUser.email || profile.email || '',
            photoURL: firebaseUser.photoURL || profile.photoURL || '',
            role: profile.role || 'CUSTOMER',
            phone: profile.phone,
          };
          if (isMounted) {
            setUser(syncedUser);
          }
          try {
            await api.googleAuth({
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              name: firebaseUser.displayName || '',
              photoURL: firebaseUser.photoURL || '',
            });
          } catch {
            // Ignore backend sync error
          }
          await loadUserData(syncedUser);
        } catch (err) {
          console.error('[OMAZIFY] Error during auth state sync:', err);
        } finally {
          if (isMounted) setIsLoading(false);
        }
      } else {
        const token = getStoredToken();
        if (token) {
          try {
            const res = await api.getMe();
            if (res.user && isMounted) {
              const localUser: User = {
                id: res.user.id,
                uid: res.user.id,
                name: res.user.name,
                email: res.user.email,
                photoURL: res.user.avatarUrl || '',
                role: res.user.role,
                phone: res.user.phone,
              };
              setUser(localUser);
              loadUserData(localUser);
            } else if (isMounted) {
              setUser(null);
            }
          } catch {
            if (isMounted) setUser(null);
          }
        } else {
          if (isMounted) {
            setUser(null);
            setWishlistIds(getGuestWishlist());
          }
        }
        if (isMounted) setIsLoading(false);
      }
    });

    return () => {
      isMounted = false;
      clearTimeout(safetyTimer);
      unsubscribe();
    };
  }, []);

  const loginWithGoogle = async (flowHint?: 'google' | 'gmail') => {
    setIsLoading(true);
    try {
      const result = await signInWithGoogle(flowHint);
      const firebaseUser = result.firebaseUser;
      const profile = result.profile;
      const newUser: User = {
        id: firebaseUser.uid,
        uid: firebaseUser.uid,
        name: firebaseUser.displayName || profile.name || 'OMAZIFY Shopper',
        email: firebaseUser.email || profile.email || '',
        photoURL: firebaseUser.photoURL || profile.photoURL || '',
        role: profile.role || 'CUSTOMER',
        phone: profile.phone,
      };
      setUser(newUser);
      try {
        await api.googleAuth({
          uid: firebaseUser.uid,
          email: firebaseUser.email || '',
          name: firebaseUser.displayName || '',
          photoURL: firebaseUser.photoURL || '',
        });
      } catch {
        // Continue
      }
      await loadUserData(newUser);
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGmail = async () => {
    return loginWithGoogle('gmail');
  };

  const googleLogin = async (_credential?: string, _email?: string, _name?: string) => {
    return loginWithGoogle('google');
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      await signOutUser();
      try {
        await api.logout();
      } catch {
        // Ignore
      }
    } finally {
      setUser(null);
      setAddresses([]);
      setOrders([]);
      setWishlistIds(getGuestWishlist());
      setIsLoading(false);
    }
  };

  const updateProfile = async (name?: string, phone?: string) => {
    if (!user) return;
    try {
      await updateFirestoreProfile(user.uid, { name, phone });
    } catch {
      // Ignore
    }
    try {
      const res = await api.updateProfile({ name, phone });
      if (res.user) {
        setUser((prev) => (prev ? { ...prev, name: res.user.name, phone: res.user.phone } : null));
      }
    } catch {
      setUser((prev) => (prev ? { ...prev, name: name || prev.name, phone: phone || prev.phone } : null));
    }
  };

  const fetchAddresses = async () => {
    const res = await api.getUserAddresses();
    setAddresses(res.addresses || []);
  };

  const addAddress = async (addrData: Omit<Address, 'id' | 'userId'>) => {
    const res = await api.addAddress(addrData);
    setAddresses((prev) => {
      if (res.address.isDefault) {
        return [...prev.map((a) => ({ ...a, isDefault: false })), res.address];
      }
      return [...prev, res.address];
    });
    addRealNotification({
      id: `notif-addr-${Date.now()}`,
      userId: user ? user.uid || user.id : 'guest',
      type: 'ACCOUNT',
      channel: 'in_app',
      title: 'Delivery Address Saved',
      message: `Address in ${res.address.city || addrData.city} (${res.address.pincode || addrData.pincode}) saved for Cash on Delivery checkout.`,
    });
    return res.address;
  };

  const updateAddress = async (id: string, addrData: Partial<Omit<Address, 'id' | 'userId'>>) => {
    const res = await api.updateAddress(id, addrData);
    setAddresses((prev) =>
      prev.map((a) => {
        if (a.id === id) return res.address;
        if (res.address.isDefault) return { ...a, isDefault: false };
        return a;
      })
    );
    return res.address;
  };

  const setDefaultAddress = async (id: string) => {
    await api.setDefaultAddress(id);
    setAddresses((prev) =>
      prev.map((a) => ({
        ...a,
        isDefault: a.id === id,
      }))
    );
  };

  const deleteAddress = async (id: string) => {
    await api.deleteAddress(id);
    setAddresses((prev) => prev.filter((a) => a.id !== id));
  };

  const fetchOrders = async () => {
    const res = await api.getUserOrders();
    setOrders(res.orders || []);
  };

  const cancelOrder = async (orderId: string, reason?: string) => {
    const res = await api.cancelOrder(orderId, reason);
    setOrders((prev) => prev.map((o) => (o.id === orderId ? res.order : o)));
    addRealNotification({
      id: `notif-cancel-${orderId}-${Date.now()}`,
      userId: user ? user.uid || user.id : 'guest',
      orderId,
      type: 'CANCELLED',
      channel: 'in_app',
      title: `Order #${orderId} Cancelled`,
      message: `Your order #${orderId} has been successfully cancelled. ${reason ? `(${reason})` : ''}`,
    });
    fetchNotifications();
  };

  const requestReturnOrExchange = async (orderId: string, payload: any) => {
    const res = await api.requestReturnOrExchange(orderId, payload);
    setOrders((prev) => prev.map((o) => (o.id === orderId ? res.order : o)));
    addRealNotification({
      id: `notif-return-${orderId}-${Date.now()}`,
      userId: user ? user.uid || user.id : 'guest',
      orderId,
      type: 'RETURN_REQUESTED',
      channel: 'in_app',
      title: `Return Request Submitted (#${orderId})`,
      message: `Return request registered for #${orderId}. Doorstep verification scheduled.`,
    });
    fetchNotifications();
  };

  const createOrder = async (payload: any) => {
    const res = await api.createOrder(payload);
    setOrders((prev) => [res.order, ...prev]);
    const orderId = res.order.id;
    const total = res.order.totalAmount || res.order.total || 0;
    addRealNotification({
      id: `notif-order-${orderId}`,
      userId: user ? user.uid || user.id : 'guest',
      orderId,
      type: 'ORDER_CONFIRMED',
      channel: 'in_app',
      title: `COD Order Confirmed! (#${orderId})`,
      message: `Your Cash on Delivery order of ₹${total.toLocaleString()} is confirmed. Pay cash at your doorstep.`,
    });
    fetchNotifications();
    return res.order;
  };

  const toggleWishlist = async (productId: string) => {
    const newSet = new Set(wishlistIds);
    if (newSet.has(productId)) {
      newSet.delete(productId);
    } else {
      newSet.add(productId);
    }
    setWishlistIds(newSet);
    if (user) {
      try {
        await api.toggleWishlist(productId);
      } catch {
        setWishlistIds(wishlistIds);
      }
    } else {
      saveGuestWishlist(newSet);
    }
  };

  const isAuthenticated = !!user;
  const isAdmin = user?.role === 'ADMIN' || user?.role === 'SUPER_ADMIN';
  const isSuperAdmin = user?.role === 'SUPER_ADMIN';

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated,
        isAdmin,
        isSuperAdmin,
        loginWithGoogle,
        loginWithGmail,
        googleLogin,
        logout,
        updateProfile,
        addresses,
        fetchAddresses,
        addAddress,
        updateAddress,
        setDefaultAddress,
        deleteAddress,
        orders,
        fetchOrders,
        cancelOrder,
        requestReturnOrExchange,
        createOrder,
        wishlistIds,
        toggleWishlist,
        notifications,
        unreadNotificationCount,
        fetchNotifications,
        markNotificationRead,
        markAllNotificationsRead,
        deleteNotification,
        clearAllNotifications,
        addRealNotification,
        requestNotificationPermission,
        notificationPermission,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
