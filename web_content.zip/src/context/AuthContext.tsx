import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserPreferences, PageView } from '../types.js';

interface AuthContextType {
  user: User | null;
  token: string | null;
  preferences: UserPreferences | null;
  loading: boolean;
  currentPage: PageView;
  setCurrentPage: (page: PageView) => void;
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;
  login: (token: string, user: User, preferences: UserPreferences) => void;
  logout: () => Promise<void>;
  updateUser: (updatedUser: User) => void;
  updatePreferences: (newPrefs: Partial<UserPreferences>) => Promise<void>;
  refreshAuth: () => Promise<void>;
  authFetch: (url: string, options?: RequestInit) => Promise<Response>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const TOKEN_KEY = 'aipc_session_token';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem(TOKEN_KEY));
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<PageView>('splash');
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);

  // Authenticated fetch helper
  const authFetch = async (url: string, options: RequestInit = {}): Promise<Response> => {
    const headers = new Headers(options.headers || {});
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }
    if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
      headers.set('Content-Type', 'application/json');
    }
    return fetch(url, { credentials: 'omit', ...options, headers });
  };

  // Check auth session on startup
  const refreshAuth = async () => {
    const storedToken = localStorage.getItem(TOKEN_KEY);
    if (!storedToken) {
      setUser(null);
      setPreferences(null);
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${storedToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setPreferences(data.preferences);
        setToken(storedToken);
      } else {
        // Token expired or invalid
        localStorage.removeItem(TOKEN_KEY);
        setToken(null);
        setUser(null);
      }
    } catch (err) {
      console.warn('Network error checking auth:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshAuth();
  }, []);

  // Sync theme with DOM
  useEffect(() => {
    const theme = preferences?.theme || 'system';
    const root = document.documentElement;

    const applyTheme = (isDark: boolean) => {
      if (isDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };

    if (theme === 'dark') {
      applyTheme(true);
    } else if (theme === 'light') {
      applyTheme(false);
    } else {
      const mql = window.matchMedia('(prefers-color-scheme: dark)');
      applyTheme(mql.matches);
      const listener = (e: MediaQueryListEvent) => applyTheme(e.matches);
      mql.addEventListener('change', listener);
      return () => mql.removeEventListener('change', listener);
    }
  }, [preferences?.theme]);

  const login = (newToken: string, newUser: User, newPreferences: UserPreferences) => {
    localStorage.setItem(TOKEN_KEY, newToken);
    setToken(newToken);
    setUser(newUser);
    setPreferences(newPreferences);
    setCurrentPage('chat');
  };

  const logout = async () => {
    if (token) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
      } catch (err) {
        console.warn('Logout API failed:', err);
      }
    }
    localStorage.removeItem(TOKEN_KEY);
    setToken(null);
    setUser(null);
    setActiveConversationId(null);
    setCurrentPage('login');
  };

  const updateUser = (updatedUser: User) => {
    setUser(updatedUser);
  };

  const updatePreferences = async (newPrefs: Partial<UserPreferences>) => {
    if (!token) return;
    try {
      const res = await authFetch('/api/user/preferences', {
        method: 'PUT',
        body: JSON.stringify(newPrefs),
      });
      if (res.ok) {
        const data = await res.json();
        setPreferences(data.preferences);
      }
    } catch (err) {
      console.error('Error updating preferences:', err);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        preferences,
        loading,
        currentPage,
        setCurrentPage,
        activeConversationId,
        setActiveConversationId,
        login,
        logout,
        updateUser,
        updatePreferences,
        refreshAuth,
        authFetch,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
