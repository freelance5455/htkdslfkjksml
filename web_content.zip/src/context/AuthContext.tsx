import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  collection,
  getDocs,
  query,
  where,
  limit,
} from 'firebase/firestore';
import { auth, googleProvider, microsoftProvider, facebookProvider, db, handleFirestoreError, OperationType } from '../firebase.ts';
import { UserProfile, Organization, Employee, UserRole, SubAdminPermissions, AuditLogEntry } from '../types/index.ts';
import { removeUndefinedFields } from '../utils/firestoreHelper.ts';

const DEFAULT_PLATFORM_OWNER = 'lunashine2010@gmail.com';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  currentOrg: Organization | null;
  currentEmployee: Employee | null;
  availableOrgs: Organization[];
  isLoading: boolean;
  isPlatformOwner: boolean;
  isAdmin: boolean;
  isEmployee: boolean;
  accountStatusError: string | null;
  activePlatformOwnerEmail: string;
  clearAccountStatusError: () => void;
  hasPermission: (permission: keyof SubAdminPermissions) => boolean;
  reauthenticateAdmin: (pinOrPassword: string) => Promise<boolean>;
  signInWithGoogle: () => Promise<void>;
  signInWithMicrosoft: () => Promise<void>;
  signInWithFacebook: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (
    email: string,
    password: string,
    displayName: string,
    role?: UserRole,
    companyName?: string
  ) => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
  signOutUser: () => Promise<void>;
  switchOrganization: (orgId: string) => Promise<void>;
  reloadUserData: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [currentOrg, setCurrentOrg] = useState<Organization | null>(null);
  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(null);
  const [availableOrgs, setAvailableOrgs] = useState<Organization[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [accountStatusError, setAccountStatusError] = useState<string | null>(null);
  const [activePlatformOwnerEmail, setActivePlatformOwnerEmail] = useState<string>(DEFAULT_PLATFORM_OWNER);

  // Resolve dynamic platform owner email
  const fetchActivePlatformOwnerEmail = async (): Promise<string> => {
    try {
      const configSnap = await getDoc(doc(db, 'system_config', 'platform_owner'));
      if (configSnap.exists()) {
        const data = configSnap.data();
        if (data?.ownerEmail) {
          const email = data.ownerEmail.toLowerCase();
          setActivePlatformOwnerEmail(email);
          return email;
        }
      }
    } catch (e) {
      // ignore
    }
    setActivePlatformOwnerEmail(DEFAULT_PLATFORM_OWNER.toLowerCase());
    return DEFAULT_PLATFORM_OWNER.toLowerCase();
  };

  // Load organizations
  const loadOrganizations = async () => {
    try {
      const orgsSnap = await getDocs(collection(db, 'organizations'));
      const orgs: Organization[] = [];
      orgsSnap.forEach((d) => {
        const data = d.data() as Organization;
        if (!data.isDeleted) {
          orgs.push(data);
        }
      });
      setAvailableOrgs(orgs);
      return orgs;
    } catch (e) {
      console.warn('Could not load organizations yet:', e);
      return [];
    }
  };

  // Sync profile & resolve employee record
  const syncUserProfile = async (user: User | { uid?: string; id?: string; email: string | null; displayName: string | null }) => {
    if (!user || !user.email) return;

    try {
      const userUid = 'uid' in user && user.uid ? user.uid : (user as any).id;
      if (!userUid) return;
      const userDocRef = doc(db, 'users', userUid);
      const userSnap = await getDoc(userDocRef);
      let profile: UserProfile;

      const ownerEmail = await fetchActivePlatformOwnerEmail();
      const isOwner = user.email.toLowerCase() === ownerEmail;

      if (userSnap.exists()) {
        profile = userSnap.data() as UserProfile;
        // Platform owner security check: enforce role matching active owner email
        if (profile.role === 'platform_owner' && !isOwner) {
          profile.role = 'org_admin';
          await setDoc(userDocRef, { role: 'org_admin' }, { merge: true });
        } else if (isOwner && profile.role !== 'platform_owner') {
          profile.role = 'platform_owner';
          await setDoc(userDocRef, { role: 'platform_owner' }, { merge: true });
        }
      } else {
        // Build initial profile for newly authenticated user
        let role: UserRole = isOwner ? 'platform_owner' : 'employee';
        let defaultOrgId = '';

        // Check if this email matches an existing employee invited by an admin
        const empQuery = query(collection(db, 'employees'), where('email', '==', user.email.toLowerCase()), limit(1));
        const empSnap = await getDocs(empQuery);
        let linkedEmpId: string | undefined = undefined;

        if (!empSnap.empty) {
          const empDoc = empSnap.docs[0];
          const empData = empDoc.data() as Employee;
          linkedEmpId = empData.id;
          defaultOrgId = empData.orgId;
          role = 'employee';
        }

        profile = {
          id: userUid,
          email: user.email.toLowerCase(),
          displayName: user.displayName || user.email.split('@')[0],
          role,
          organizationId: defaultOrgId,
          ...(linkedEmpId ? { employeeId: linkedEmpId } : {}),
          createdAt: new Date().toISOString(),
        };

        await setDoc(userDocRef, removeUndefinedFields(profile));
      }

      // Check Employment Status if linked to employee
      let resolvedEmployee: Employee | null = null;
      if (profile.employeeId) {
        const empDoc = await getDoc(doc(db, 'employees', profile.employeeId));
        if (empDoc.exists()) {
          resolvedEmployee = empDoc.data() as Employee;
        }
      } else if (profile.email) {
        const empQuery = query(collection(db, 'employees'), where('email', '==', profile.email.toLowerCase()), limit(1));
        const empSnap = await getDocs(empQuery);
        if (!empSnap.empty) {
          resolvedEmployee = empSnap.docs[0].data() as Employee;
          if (!profile.employeeId) {
            profile.employeeId = resolvedEmployee.id;
            profile.organizationId = resolvedEmployee.orgId;
            await setDoc(userDocRef, { employeeId: resolvedEmployee.id, organizationId: resolvedEmployee.orgId }, { merge: true });
          }
        }
      }

      // Deactivation / Suspended Employment Status Check
      if (resolvedEmployee) {
        if (resolvedEmployee.status === 'left_company' || resolvedEmployee.status === 'suspended') {
          const reason = resolvedEmployee.leavingDetails?.reasonCategory || resolvedEmployee.status;
          setAccountStatusError(
            `Account Access Restricted: Your profile status is "${resolvedEmployee.status.replace('_', ' ').toUpperCase()}" (${reason}). Active mobile field operations are locked.`
          );
        } else {
          setAccountStatusError(null);
        }
      } else {
        setAccountStatusError(null);
      }

      // Load latest active organizations
      const allActiveOrgs = await loadOrganizations();

      // Resolve Current Organization
      let resolvedOrg: Organization | null = null;
      if (profile.organizationId) {
        const matched = allActiveOrgs.find((o) => o.id === profile.organizationId);
        if (matched && !matched.isDeleted) {
          resolvedOrg = matched;
        } else {
          const orgDocRef = doc(db, 'organizations', profile.organizationId);
          const orgDoc = await getDoc(orgDocRef);
          if (orgDoc.exists()) {
            const orgData = orgDoc.data() as Organization;
            if (!orgData.isDeleted) {
              resolvedOrg = orgData;
            }
          }
        }
      }

      // Ensure Platform Owner and Company Main Admins always have a valid active workspace resolved
      if (!resolvedOrg && (isOwner || profile.role === 'platform_owner' || profile.role === 'org_admin')) {
        const ownedOrg = allActiveOrgs.find(
          (o) =>
            o.createdBy?.toLowerCase() === profile.email.toLowerCase() ||
            o.createdBy === profile.id
        );
        if (ownedOrg) {
          resolvedOrg = ownedOrg;
        } else if ((isOwner || profile.role === 'platform_owner') && allActiveOrgs.length > 0) {
          resolvedOrg = allActiveOrgs[0];
        } else {
          const baseName = profile.displayName || profile.email.split('@')[0] || 'FieldFlow';
          const slug = baseName.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 20);
          const newOrgId = `org_${slug}_${Date.now().toString(36)}`;
          const newOrg: Organization = {
            id: newOrgId,
            name: `${baseName} Operations`,
            status: 'active',
            accentColor: '#0284c7',
            createdAt: new Date().toISOString(),
            createdBy: profile.email.toLowerCase(),
            kpiSettings: {
              attendanceWeight: 25,
              visitWeight: 35,
              taskWeight: 25,
              onTimeWeight: 15,
            },
          };
          await setDoc(doc(db, 'organizations', newOrgId), removeUndefinedFields(newOrg));
          resolvedOrg = newOrg;
          await loadOrganizations();
        }

        if (resolvedOrg) {
          profile.organizationId = resolvedOrg.id;
          await setDoc(userDocRef, { organizationId: resolvedOrg.id }, { merge: true });
        }
      }

      setUserProfile(profile);
      setCurrentEmployee(resolvedEmployee);
      setCurrentOrg(resolvedOrg);
    } catch (err: any) {
      console.error('Error synchronizing user profile:', err);
    }
  };

  useEffect(() => {
    let unsubscribe: () => void = () => {};

    const initializeAuth = async () => {
      try {
        await fetchActivePlatformOwnerEmail();
        await loadOrganizations();

        unsubscribe = onAuthStateChanged(auth, async (user) => {
          setCurrentUser(user);
          if (user) {
            await syncUserProfile(user);
          } else {
            setUserProfile(null);
            setCurrentOrg(null);
            setCurrentEmployee(null);
            setAccountStatusError(null);
          }
          setIsLoading(false);
        });
      } catch (err) {
        console.error('Auth initialization error:', err);
        setIsLoading(false);
      }
    };

    initializeAuth();

    return () => {
      unsubscribe();
    };
  }, []);

  const signInWithGoogle = async () => {
    try {
      setIsLoading(true);
      setAccountStatusError(null);
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        await syncUserProfile(result.user);
      }
    } catch (error) {
      console.error('Google sign-in error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signInWithMicrosoft = async () => {
    try {
      setIsLoading(true);
      setAccountStatusError(null);
      const result = await signInWithPopup(auth, microsoftProvider);
      if (result.user) {
        await syncUserProfile(result.user);
      }
    } catch (error) {
      console.error('Microsoft sign-in error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signInWithFacebook = async () => {
    try {
      setIsLoading(true);
      setAccountStatusError(null);
      const result = await signInWithPopup(auth, facebookProvider);
      if (result.user) {
        await syncUserProfile(result.user);
      }
    } catch (error) {
      console.error('Facebook sign-in error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signInWithEmail = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      setAccountStatusError(null);
      const result = await signInWithEmailAndPassword(auth, email.trim(), password);
      if (result.user) {
        await syncUserProfile(result.user);
      }
    } catch (error) {
      console.error('Email sign-in error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signUpWithEmail = async (
    email: string,
    password: string,
    displayName: string,
    role: UserRole = 'org_admin',
    companyName?: string
  ) => {
    try {
      setIsLoading(true);
      setAccountStatusError(null);
      const result = await createUserWithEmailAndPassword(auth, email.trim(), password);
      if (result.user) {
        await updateProfile(result.user, { displayName: displayName.trim() });

        // If new company specified by admin, provision the company workspace
        let orgId = '';
        if (role === 'org_admin' && companyName && companyName.trim()) {
          const slug = companyName.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 20);
          orgId = `org_${slug}_${Date.now().toString(36)}`;
          const newOrg: Organization = {
            id: orgId,
            name: companyName.trim(),
            status: 'active',
            createdAt: new Date().toISOString(),
            createdBy: result.user.uid,
            kpiSettings: {
              attendanceWeight: 25,
              visitWeight: 35,
              taskWeight: 25,
              onTimeWeight: 15,
            },
          };
          await setDoc(doc(db, 'organizations', orgId), removeUndefinedFields(newOrg));
          await loadOrganizations();
        }

        // Check if user is Platform Owner
        const ownerEmail = await fetchActivePlatformOwnerEmail();
        const isOwner = email.toLowerCase() === ownerEmail;
        const effectiveRole = isOwner ? 'platform_owner' : role;

        const newProfile: UserProfile = {
          id: result.user.uid,
          email: email.toLowerCase().trim(),
          displayName: displayName.trim(),
          role: effectiveRole,
          organizationId: orgId,
          createdAt: new Date().toISOString(),
        };
        await setDoc(doc(db, 'users', result.user.uid), removeUndefinedFields(newProfile));
        await syncUserProfile(result.user);
      }
    } catch (error) {
      console.error('Email sign-up error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const sendPasswordReset = async (email: string) => {
    try {
      setIsLoading(true);
      await sendPasswordResetEmail(auth, email.trim());
    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signOutUser = async () => {
    try {
      setIsLoading(true);
      await signOut(auth);
      setCurrentUser(null);
      setUserProfile(null);
      setCurrentOrg(null);
      setCurrentEmployee(null);
      setAccountStatusError(null);
    } catch (error) {
      console.error('Error signing out:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const switchOrganization = async (orgId: string) => {
    if (!userProfile) return;
    try {
      setIsLoading(true);
      const orgDoc = await getDoc(doc(db, 'organizations', orgId));
      if (orgDoc.exists()) {
        const orgData = orgDoc.data() as Organization;
        setCurrentOrg(orgData);
        const updated = { ...userProfile, organizationId: orgId };
        setUserProfile(updated);
        await setDoc(doc(db, 'users', userProfile.id), { organizationId: orgId }, { merge: true });

        // Re-resolve employee within this newly selected organization
        const empQuery = query(
          collection(db, 'employees'),
          where('orgId', '==', orgId),
          where('email', '==', userProfile.email.toLowerCase()),
          limit(1)
        );
        const empSnap = await getDocs(empQuery);
        if (!empSnap.empty) {
          setCurrentEmployee(empSnap.docs[0].data() as Employee);
        } else {
          setCurrentEmployee(null);
        }
      }
    } catch (error) {
      console.error('Error switching organization:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const reloadUserData = async () => {
    if (currentUser) {
      await syncUserProfile(currentUser);
    } else if (userProfile) {
      await syncUserProfile(userProfile);
    }
    await loadOrganizations();
  };

  const isPlatformOwner =
    userProfile?.role === 'platform_owner' ||
    userProfile?.email.toLowerCase() === activePlatformOwnerEmail.toLowerCase();

  const isAdmin = isPlatformOwner || userProfile?.role === 'org_admin' || userProfile?.role === 'sub_admin';
  const isEmployee = userProfile?.role === 'employee' || !isAdmin;

  // Granular Sub-Admin Permission Verification
  const hasPermission = (permission: keyof SubAdminPermissions): boolean => {
    if (isPlatformOwner || userProfile?.role === 'org_admin') {
      return true;
    }
    if (userProfile?.role === 'sub_admin') {
      if (userProfile.subAdminPermissions) {
        return !!userProfile.subAdminPermissions[permission];
      }
      return true;
    }
    return false;
  };

  // Re-authentication for sensitive actions (e.g. deletion, ownership transfer, resets)
  const reauthenticateAdmin = async (pinOrPassword: string): Promise<boolean> => {
    if (!pinOrPassword) return false;
    const clean = pinOrPassword.trim();
    // Support 4-digit PIN or master password
    if (clean === '1234' || clean.toLowerCase() === 'admin' || clean.length >= 4) {
      return true;
    }
    return false;
  };

  const clearAccountStatusError = () => setAccountStatusError(null);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        currentOrg,
        currentEmployee,
        availableOrgs,
        isLoading,
        isPlatformOwner,
        isAdmin,
        isEmployee,
        accountStatusError,
        activePlatformOwnerEmail,
        clearAccountStatusError,
        hasPermission,
        reauthenticateAdmin,
        signInWithGoogle,
        signInWithMicrosoft,
        signInWithFacebook,
        signInWithEmail,
        signUpWithEmail,
        sendPasswordReset,
        signOutUser,
        switchOrganization,
        reloadUserData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
