import React, { createContext, useContext, useEffect, useState } from 'react';
import { TestFolder, TestAttempt } from '../types';

interface StoreContextType {
  folders: TestFolder[];
  attempts: TestAttempt[];
  addFolder: (folder: TestFolder) => void;
  updateFolder: (folder: TestFolder) => void;
  addAttempt: (attempt: TestAttempt) => void;
  role: 'admin' | 'student';
  setRole: (role: 'admin' | 'student') => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [folders, setFolders] = useState<TestFolder[]>([]);
  const [attempts, setAttempts] = useState<TestAttempt[]>([]);
  const [role, setRole] = useState<'admin' | 'student'>('student');

  // Load from local storage
  useEffect(() => {
    const savedFolders = localStorage.getItem('dox_neet_folders');
    const savedAttempts = localStorage.getItem('dox_neet_attempts');
    if (savedFolders) setFolders(JSON.parse(savedFolders));
    if (savedAttempts) setAttempts(JSON.parse(savedAttempts));
  }, []);

  // Save to local storage
  useEffect(() => {
    localStorage.setItem('dox_neet_folders', JSON.stringify(folders));
  }, [folders]);

  useEffect(() => {
    localStorage.setItem('dox_neet_attempts', JSON.stringify(attempts));
  }, [attempts]);

  const addFolder = (folder: TestFolder) => setFolders(prev => [...prev, folder]);
  
  const updateFolder = (updated: TestFolder) => {
    setFolders(prev => prev.map(f => f.id === updated.id ? updated : f));
  };

  const addAttempt = (attempt: TestAttempt) => setAttempts(prev => [...prev, attempt]);

  return (
    <StoreContext.Provider value={{ folders, attempts, addFolder, updateFolder, addAttempt, role, setRole }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
