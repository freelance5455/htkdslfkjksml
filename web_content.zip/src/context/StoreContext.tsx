import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Product, 
  CartItem, 
  Order, 
  StockMovement, 
  PaymentMethod, 
  CustomerData, 
  Plan, 
  ProductCategory,
  MerchantPayoutSettings,
  PayoutTransaction
} from '../types';
import { INITIAL_PRODUCTS, INITIAL_PLANS } from '../data/mockData';

export type AppView = 'store' | 'inventory' | 'plans' | 'orders' | 'checkout' | 'payouts';

export interface ToastNotification {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'warning' | 'info' | 'error';
  timestamp: string;
}

interface StoreContextType {
  // Navigation & View
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  selectedCategory: ProductCategory;
  setSelectedCategory: (cat: ProductCategory) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  
  // Products & Real-time Stock
  products: Product[];
  selectedProduct: Product | null;
  setSelectedProduct: (p: Product | null) => void;
  decreaseStock: (productId: string, quantity: number, orderRef: string) => boolean;
  restockProduct: (productId: string, quantity: number, reason?: string) => void;
  updateProduct: (updated: Product) => void;
  addProduct: (newProd: Omit<Product, 'id' | 'salesCount' | 'rating' | 'ratingCount'>) => void;
  deleteProduct: (productId: string) => void;
  
  // Stock Movements Log
  stockMovements: StockMovement[];
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartSubtotal: number;
  cartCount: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  buyNow: (product: Product) => void;
  
  // Checkout & Orders
  orders: Order[];
  currentOrder: Order | null;
  customerData: CustomerData;
  setCustomerData: React.Dispatch<React.SetStateAction<CustomerData>>;
  checkoutItem: Product | null; // If buying single product directly
  setCheckoutItem: (p: Product | null) => void;
  processPayment: (
    method: PaymentMethod,
    phoneOrCard: string,
    onSuccess: (order: Order) => void
  ) => Promise<boolean>;
  
  // User & Credits
  userCredits: number;
  setUserCredits: React.Dispatch<React.SetStateAction<number>>;
  purchasePlan: (plan: Plan) => void;

  // Merchant Wallet & Payouts (Como o Dono Recebe os Pagamentos)
  merchantSettings: MerchantPayoutSettings;
  updateMerchantSettings: (settings: Partial<MerchantPayoutSettings>) => void;
  payouts: PayoutTransaction[];
  requestPayout: (amount: number) => Promise<boolean>;
  availableBalance: number;
  totalRevenue: number;
  totalWithdrawn: number;
  
  // Toasts
  toasts: ToastNotification[];
  removeToast: (id: string) => void;
  addToast: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'error') => void;

  // Real-time Simulation Trigger
  simulateIncomingSale: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY_PRODUCTS = 'escale_products_v2';
const LOCAL_STORAGE_KEY_ORDERS = 'escale_orders_v2';
const LOCAL_STORAGE_KEY_MOVEMENTS = 'escale_movements_v2';
const LOCAL_STORAGE_KEY_CREDITS = 'escale_credits_v2';

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation
  const [currentView, setCurrentView] = useState<AppView>('store');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [checkoutItem, setCheckoutItem] = useState<Product | null>(null);

  // Products with localStorage persistence
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_PRODUCTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_PRODUCTS;
  });

  // Stock movements
  const [stockMovements, setStockMovements] = useState<StockMovement[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_MOVEMENTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: 'mov-1',
        productId: 'prod-1',
        productName: 'Empreendedorismo da Elite',
        type: 'restock',
        quantityChange: 15,
        stockBefore: 0,
        stockAfter: 15,
        reason: 'Lote inicial de licenças digitais',
        timestamp: new Date(Date.now() - 3600000 * 24 * 3).toISOString()
      },
      {
        id: 'mov-2',
        productId: 'prod-1',
        productName: 'Empreendedorismo da Elite',
        type: 'sale',
        quantityChange: -1,
        stockBefore: 15,
        stockAfter: 14,
        reason: 'Venda Checkout M-Pesa #815391',
        timestamp: new Date(Date.now() - 3600000 * 5).toISOString()
      },
      {
        id: 'mov-3',
        productId: 'prod-8',
        productName: 'Mega Pack Criativos & Banners de Alta Conversão',
        type: 'sale',
        quantityChange: -2,
        stockBefore: 4,
        stockAfter: 2,
        reason: 'Venda Directa e-Mola #815340',
        timestamp: new Date(Date.now() - 3600000 * 2).toISOString()
      }
    ];
  });

  // Cart
  const [cart, setCart] = useState<CartItem[]>([]);

  // Customer Data (Pre-filled with Momade Cássimo Sumaila as shown in user's screenshots)
  const [customerData, setCustomerData] = useState<CustomerData>({
    fullName: 'Momade Cássimo',
    email: 'jucunozawayajacob@gmail.com',
    phone: '841634528',
    whatsapp: '841634528',
    address: 'Av. Julius Nyerere, Maputo',
    city: 'Maputo',
    notes: 'Prioridade no envio'
  });

  // Credits (starts at 0 as in screenshot "Sem créditos")
  const [userCredits, setUserCredits] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_CREDITS);
      if (saved) return Number(saved);
    } catch (e) {
      console.error(e);
    }
    return 0;
  });

  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);

  // Merchant Wallet & Payout Settings
  const LOCAL_STORAGE_KEY_MERCHANT = 'escale_merchant_settings_v3';
  const LOCAL_STORAGE_KEY_PAYOUTS = 'escale_payouts_v3';

  const [merchantSettings, setMerchantSettings] = useState<MerchantPayoutSettings>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_MERCHANT);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {
      payoutMethod: 'mpesa',
      accountHolder: 'Momade Cássimo Sumaila',
      mpesaNumber: '841634528',
      emolaNumber: '861234567',
      bankName: 'Millennium BIM',
      accountNumber: '2910842019',
      nib: '0001 0000 2910 8420 1902 4',
      autoPayout: true,
      gatewayProvider: 'escalepay_direct',
      apiKey: 'sec_live_esc_mz_91823901'
    };
  });

  const [payouts, setPayouts] = useState<PayoutTransaction[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_PAYOUTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: 'PAY-001',
        amount: 800,
        method: 'mpesa',
        destination: '+258 84 16 34 528 (Momade Cássimo)',
        status: 'completed',
        reference: 'VOD-B2C-98213812',
        requestedAt: new Date(Date.now() - 3600000 * 24 * 2).toISOString()
      }
    ];
  });

  // Initial orders with historical revenue if empty
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_ORDERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: 'ORD-815391',
        transactionRef: 'TX-ESC-8153910',
        customer: {
          fullName: 'Momade Cássimo',
          email: 'jucunozawayajacob@gmail.com',
          phone: '841634528',
          whatsapp: '841634528'
        },
        items: [
          {
            productId: 'prod-1',
            productName: 'Empreendedorismo da Elite',
            price: 497,
            quantity: 1,
            type: 'digital',
            sku: 'EB-EMP-01'
          }
        ],
        subtotal: 497,
        tax: 0,
        total: 497,
        paymentMethod: 'mpesa',
        paymentStatus: 'paid',
        paymentDetails: {
          phoneOrCard: '+258 84 16 34 528',
          operatorRef: 'MPESA-91823192'
        },
        deliveryStatus: 'delivered',
        createdAt: new Date(Date.now() - 3600000 * 5).toISOString()
      },
      {
        id: 'ORD-815340',
        transactionRef: 'TX-ESC-8153402',
        customer: {
          fullName: 'Célia Macuácua',
          email: 'celia.macuacua@gmail.com',
          phone: '861234567',
          whatsapp: '861234567'
        },
        items: [
          {
            productId: 'prod-8',
            productName: 'Mega Pack Criativos & Banners de Alta Conversão',
            price: 320,
            quantity: 2,
            type: 'digital',
            sku: 'ADS-BNR-250'
          }
        ],
        subtotal: 640,
        tax: 0,
        total: 640,
        paymentMethod: 'emola',
        paymentStatus: 'paid',
        paymentDetails: {
          phoneOrCard: '+258 86 12 34 567',
          operatorRef: 'EMOLA-77461823'
        },
        deliveryStatus: 'delivered',
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString()
      },
      {
        id: 'ORD-815302',
        transactionRef: 'TX-ESC-8153029',
        customer: {
          fullName: 'Dionísio Tembe',
          email: 'dionisio.tembe@outlook.com',
          phone: '848912345',
          whatsapp: '848912345'
        },
        items: [
          {
            productId: 'prod-3',
            productName: 'Curso Editor Master Jacques',
            price: 997,
            quantity: 1,
            type: 'digital',
            sku: 'CRS-JAC-09'
          }
        ],
        subtotal: 997,
        tax: 0,
        total: 997,
        paymentMethod: 'mpesa',
        paymentStatus: 'paid',
        paymentDetails: {
          phoneOrCard: '+258 84 89 12 345',
          operatorRef: 'MPESA-33291048'
        },
        deliveryStatus: 'delivered',
        createdAt: new Date(Date.now() - 3600000 * 1).toISOString()
      }
    ];
  });

  // Calculate gross revenue, withdrawn and available balance
  const totalRevenue = orders
    .filter(o => o.paymentStatus === 'paid')
    .reduce((sum, o) => sum + o.total, 0);

  const totalWithdrawn = payouts
    .filter(p => p.status === 'completed')
    .reduce((sum, p) => sum + p.amount, 0);

  const availableBalance = Math.max(0, totalRevenue - totalWithdrawn);

  // Save merchant settings and payouts to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_MERCHANT, JSON.stringify(merchantSettings));
    } catch (e) {
      console.error(e);
    }
  }, [merchantSettings]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_PAYOUTS, JSON.stringify(payouts));
    } catch (e) {
      console.error(e);
    }
  }, [payouts]);

  const updateMerchantSettings = (settings: Partial<MerchantPayoutSettings>) => {
    setMerchantSettings(prev => ({ ...prev, ...settings }));
    addToast('Conta de Recebimento Atualizada', 'Os dados bancários e número de M-Pesa foram salvos.', 'success');
  };

  const requestPayout = async (amount: number): Promise<boolean> => {
    if (amount <= 0 || amount > availableBalance) {
      addToast('Saldo Insuficiente', `O valor máximo para saque disponível é de ${availableBalance.toLocaleString('pt-MZ')} MT.`, 'error');
      return false;
    }

    const destination = merchantSettings.payoutMethod === 'mpesa' 
      ? `M-Pesa +258 ${merchantSettings.mpesaNumber} (${merchantSettings.accountHolder})`
      : merchantSettings.payoutMethod === 'emola'
      ? `e-Mola +258 ${merchantSettings.emolaNumber} (${merchantSettings.accountHolder})`
      : `${merchantSettings.bankName} NIB: ${merchantSettings.nib} (${merchantSettings.accountHolder})`;

    const ref = `VOD-B2C-${Math.floor(10000000 + Math.random() * 90000000)}`;

    const newPayout: PayoutTransaction = {
      id: `PAY-${Date.now().toString().slice(-4)}`,
      amount,
      method: merchantSettings.payoutMethod,
      destination,
      status: 'completed',
      reference: ref,
      requestedAt: new Date().toISOString()
    };

    setPayouts(prev => [newPayout, ...prev]);

    addToast(
      'Saque Efetuado com Sucesso!',
      `Mt ${amount.toLocaleString('pt-MZ')},00 MZN foram transferidos para ${destination}. Ref: ${ref}`,
      'success'
    );

    return true;
  };

  // Toasts
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_PRODUCTS, JSON.stringify(products));
    } catch (e) {
      console.error(e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_ORDERS, JSON.stringify(orders));
    } catch (e) {
      console.error(e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_MOVEMENTS, JSON.stringify(stockMovements));
    } catch (e) {
      console.error(e);
    }
  }, [stockMovements]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_CREDITS, userCredits.toString());
    } catch (e) {
      console.error(e);
    }
  }, [userCredits]);

  const addToast = (
    title: string, 
    message: string, 
    type: 'success' | 'warning' | 'info' | 'error' = 'info'
  ) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const newToast: ToastNotification = {
      id,
      title,
      message,
      type,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setToasts(prev => [newToast, ...prev].slice(0, 5));

    setTimeout(() => {
      removeToast(id);
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Stock management logic
  const decreaseStock = (productId: string, quantity: number, orderRef: string): boolean => {
    let success = false;
    setProducts(prev => {
      return prev.map(p => {
        if (p.id === productId) {
          if (p.stock >= quantity) {
            success = true;
            const newStock = p.stock - quantity;
            
            // Record movement
            const movement: StockMovement = {
              id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
              productId: p.id,
              productName: p.name,
              type: 'sale',
              quantityChange: -quantity,
              stockBefore: p.stock,
              stockAfter: newStock,
              reason: `Venda no Checkout ${orderRef}`,
              timestamp: new Date().toISOString()
            };
            setStockMovements(m => [movement, ...m]);

            // Low stock warning
            if (newStock <= p.minStockAlert) {
              addToast(
                'Alerta de Estoque Baixo!',
                `"${p.name}" tem apenas ${newStock} unidade(s) restantes em estoque.`,
                'warning'
              );
            }

            return {
              ...p,
              stock: newStock,
              salesCount: p.salesCount + quantity
            };
          } else {
            addToast('Estoque Insuficiente', `"${p.name}" não tem unidades suficientes.`, 'error');
            return p;
          }
        }
        return p;
      });
    });
    return success;
  };

  const restockProduct = (productId: string, quantity: number, reason: string = 'Reabastecimento Manual') => {
    if (quantity <= 0) return;
    setProducts(prev => {
      return prev.map(p => {
        if (p.id === productId) {
          const newStock = p.stock + quantity;
          const movement: StockMovement = {
            id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            productId: p.id,
            productName: p.name,
            type: 'restock',
            quantityChange: quantity,
            stockBefore: p.stock,
            stockAfter: newStock,
            reason,
            timestamp: new Date().toISOString()
          };
          setStockMovements(m => [movement, ...m]);
          addToast('Estoque Atualizado', `+${quantity} unidade(s) adicionadas a "${p.name}".`, 'success');
          return { ...p, stock: newStock };
        }
        return p;
      });
    });
  };

  const updateProduct = (updated: Product) => {
    setProducts(prev => prev.map(p => {
      if (p.id === updated.id) {
        if (p.stock !== updated.stock) {
          const diff = updated.stock - p.stock;
          const movement: StockMovement = {
            id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            productId: updated.id,
            productName: updated.name,
            type: 'adjustment',
            quantityChange: diff,
            stockBefore: p.stock,
            stockAfter: updated.stock,
            reason: 'Ajuste manual de inventário',
            timestamp: new Date().toISOString()
          };
          setStockMovements(m => [movement, ...m]);
        }
        return updated;
      }
      return p;
    }));
    addToast('Produto Atualizado', `Os detalhes de "${updated.name}" foram salvos.`, 'success');
  };

  const addProduct = (newProd: Omit<Product, 'id' | 'salesCount' | 'rating' | 'ratingCount'>) => {
    const id = `prod-${Date.now()}`;
    const product: Product = {
      ...newProd,
      id,
      salesCount: 0,
      rating: 5.0,
      ratingCount: 1
    };

    setProducts(prev => [product, ...prev]);

    // Record initial stock movement
    if (product.stock > 0) {
      const movement: StockMovement = {
        id: `mov-${Date.now()}`,
        productId: product.id,
        productName: product.name,
        type: 'restock',
        quantityChange: product.stock,
        stockBefore: 0,
        stockAfter: product.stock,
        reason: 'Cadastro inicial de produto com estoque',
        timestamp: new Date().toISOString()
      };
      setStockMovements(m => [movement, ...m]);
    }

    addToast('Produto Criado', `"${product.name}" foi cadastrado no catálogo e no estoque.`, 'success');
  };

  const deleteProduct = (productId: string) => {
    const prod = products.find(p => p.id === productId);
    setProducts(prev => prev.filter(p => p.id !== productId));
    setCart(prev => prev.filter(item => item.product.id !== productId));
    addToast('Produto Removido', `O produto "${prod?.name || ''}" foi removido do catálogo.`, 'info');
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1) => {
    if (product.stock <= 0) {
      addToast('Produto Esgotado', 'Este item não possui unidades disponíveis no momento.', 'warning');
      return;
    }

    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        const nextQty = existing.quantity + quantity;
        if (nextQty > product.stock) {
          addToast('Limite de Estoque', `Apenas ${product.stock} unidades disponíveis.`, 'warning');
          return prev;
        }
        addToast('Carrinho Atualizado', `Quantidade aumentada para ${nextQty}.`, 'success');
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: nextQty } : item);
      } else {
        addToast('Adicionado ao Carrinho', `"${product.name}" adicionado com sucesso.`, 'success');
        return [...prev, { product, quantity: Math.min(quantity, product.stock) }];
      }
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    const product = products.find(p => p.id === productId);
    if (!product) return;

    if (quantity > product.stock) {
      addToast('Limite de Estoque', `Estoque máximo disponível: ${product.stock}`, 'warning');
      quantity = product.stock;
    }

    setCart(prev => prev.map(item => item.product.id === productId ? { ...item, quantity } : item));
  };

  const clearCart = () => setCart([]);

  const buyNow = (product: Product) => {
    if (product.stock <= 0) {
      addToast('Produto Esgotado', 'Não é possível comprar este item no momento.', 'warning');
      return;
    }
    setCheckoutItem(product);
    setCurrentView('checkout');
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const cartCount = cart.reduce((count, item) => count + item.quantity, 0);

  // Process payment simulation
  const processPayment = async (
    method: PaymentMethod,
    phoneOrCard: string,
    onSuccess: (order: Order) => void
  ): Promise<boolean> => {
    // Generate order ID
    const orderId = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
    const txRef = `TX-ESC-${Math.floor(1000000 + Math.random() * 9000000)}`;

    const itemsToBuy = checkoutItem 
      ? [{ product: checkoutItem, quantity: 1 }]
      : cart;

    if (itemsToBuy.length === 0) {
      addToast('Erro no Pedido', 'Nenhum item selecionado para pagamento.', 'error');
      return false;
    }

    // Verify all stock beforehand
    for (const item of itemsToBuy) {
      const current = products.find(p => p.id === item.product.id);
      if (!current || current.stock < item.quantity) {
        addToast('Estoque Insuficiente', `Desculpe, "${item.product.name}" não possui estoque suficiente.`, 'error');
        return false;
      }
    }

    // Calculate totals
    const subtotal = itemsToBuy.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const tax = 0; // Grátis conforme screenshots de Moçambique
    const total = subtotal + tax;

    // Deduct stock for each item in real time!
    for (const item of itemsToBuy) {
      decreaseStock(item.product.id, item.quantity, `#${orderId}`);
    }

    // Construct confirmed order
    const newOrder: Order = {
      id: orderId,
      transactionRef: txRef,
      customer: { ...customerData },
      items: itemsToBuy.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        price: item.product.price,
        quantity: item.quantity,
        type: item.product.type,
        sku: item.product.sku
      })),
      subtotal,
      tax,
      total,
      paymentMethod: method,
      paymentStatus: 'paid',
      paymentDetails: {
        phoneOrCard,
        authCode: `AUTH-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
        operatorRef: method === 'mpesa' ? `MPESA-${Date.now().toString().slice(-8)}` : `EMOLA-${Date.now().toString().slice(-8)}`
      },
      deliveryStatus: itemsToBuy.some(i => i.product.type === 'physical') ? 'pending_shipping' : 'delivered',
      createdAt: new Date().toISOString()
    };

    setOrders(prev => [newOrder, ...prev]);
    setCurrentOrder(newOrder);

    // Clear cart or checkout item
    if (checkoutItem) {
      setCheckoutItem(null);
    } else {
      clearCart();
    }

    addToast(
      'Pagamento Confirmado!',
      `Pedido #${orderId} de ${total.toLocaleString('pt-MZ')} MT processado via ${method.toUpperCase()}.`,
      'success'
    );

    onSuccess(newOrder);
    return true;
  };

  // Purchase plan to add credits
  const purchasePlan = (plan: Plan) => {
    // Add credits to user balance
    const totalCreditsGained = plan.credits;
    setUserCredits(prev => prev + totalCreditsGained);
    addToast(
      'Plano Ativado com Sucesso!',
      `Foram creditados ${totalCreditsGained} créditos na tua conta EscaleBuilder.`,
      'success'
    );
  };

  // Real-time incoming sale simulation for interactive demo
  const simulateIncomingSale = () => {
    const available = products.filter(p => p.stock > 0);
    if (available.length === 0) {
      addToast('Aviso', 'Todos os produtos estão esgotados!', 'warning');
      return;
    }
    const randomProduct = available[Math.floor(Math.random() * available.length)];
    const orderNum = Math.floor(100000 + Math.random() * 900000);
    decreaseStock(randomProduct.id, 1, `#${orderNum} (Cliente Externo)`);
    addToast(
      'Nova Venda em Tempo Real!',
      `Um cliente comprou 1x "${randomProduct.name}" por ${randomProduct.price} MT. Estoque atualizado!`,
      'info'
    );
  };

  return (
    <StoreContext.Provider
      value={{
        currentView,
        setCurrentView,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        products,
        selectedProduct,
        setSelectedProduct,
        decreaseStock,
        restockProduct,
        updateProduct,
        addProduct,
        deleteProduct,
        stockMovements,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartSubtotal,
        cartCount,
        isCartOpen,
        setIsCartOpen,
        buyNow,
        orders,
        currentOrder,
        customerData,
        setCustomerData,
        checkoutItem,
        setCheckoutItem,
        processPayment,
        userCredits,
        setUserCredits,
        purchasePlan,
        merchantSettings,
        updateMerchantSettings,
        payouts,
        requestPayout,
        availableBalance,
        totalRevenue,
        totalWithdrawn,
        toasts,
        removeToast,
        addToast,
        simulateIncomingSale
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
