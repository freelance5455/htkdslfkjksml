import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { ChildDevice, AlertNotification, RemoteCommandLog, DeviceSettings, InstalledApp, ToastInfo } from '../types';
import { INITIAL_DEVICES, INITIAL_ALERTS } from '../data/mockData';
import { db, testFirestoreConnection } from '../lib/firebase';
import { collection, doc, onSnapshot, setDoc } from 'firebase/firestore';
import { sirenPlayer } from '../lib/audioAlert';

interface ParentControlContextType {
  devices: ChildDevice[];
  activeDeviceId: string;
  activeDevice: ChildDevice;
  alerts: AlertNotification[];
  unreadAlertsCount: number;
  commandsLog: RemoteCommandLog[];
  isSimulatorOpen: boolean;
  simulatorScreen: 'home' | 'app' | 'lock' | 'incoming_call';
  simulatorActiveAppId: string | null;
  language: 'ar' | 'en';
  isAudioMuted: boolean;
  isLiveCameraStreaming: boolean;
  cameraFacing: 'user' | 'environment';
  isFlashlightActive: boolean;
  isMicListening: boolean;
  micDecibels: number;
  sirenPlaying: boolean;
  cloudSyncStatus: 'connected' | 'syncing' | 'offline';

  // Theme & Dark Mode
  themeMode: 'light' | 'dark' | 'auto';
  isDarkMode: boolean;
  setThemeMode: (mode: 'light' | 'dark' | 'auto') => void;
  toggleTheme: () => void;

  // Parent PIN & Security
  isParentDashboardLocked: boolean;
  parentPin: string;
  lockParentDashboard: () => void;
  unlockParentDashboard: (pin: string) => boolean;
  setParentPin: (newPin: string) => void;
  
  // Actions
  setActiveDeviceId: (id: string) => void;
  toggleLanguage: () => void;
  setIsSimulatorOpen: (open: boolean) => void;
  setSimulatorScreen: (screen: 'home' | 'app' | 'lock' | 'incoming_call') => void;
  launchAppInSimulator: (appId: string) => void;
  
  // Device Controls
  toggleAppBlock: (appId: string) => void;
  setAppLimit: (appId: string, minutes: number) => void;
  uninstallApp: (appId: string) => void;
  installApp: (appData: { name: string; nameAr: string; packageName: string; category: any; icon: string; sizeMb: number }) => void;
  
  // Hardware & Device Settings Controls
  toggleHardwareSetting: (settingKey: keyof DeviceSettings) => void;
  updateSliderSetting: (settingKey: 'volumeMedia' | 'volumeRing' | 'volumeAlarm' | 'brightness', value: number) => void;
  setDeviceLockdown: (locked: boolean, message?: string) => void;
  triggerEmergencySiren: () => void;
  stopEmergencySiren: () => void;
  
  // Camera & Mic Controls
  startCameraStream: (facing?: 'user' | 'environment') => void;
  stopCameraStream: () => void;
  toggleCameraFacing: () => void;
  toggleFlashlight: () => void;
  startMicListening: () => void;
  stopMicListening: () => void;
  
  // Alerts & Geofences
  markAlertAsRead: (alertId: string) => void;
  markAllAlertsAsRead: () => void;
  deleteAlert: (alertId: string) => void;
  addGeofence: (zone: { name: string; nameAr: string; lat: number; lng: number; radiusMeters: number; address: string; type: 'safe' | 'danger' }) => void;
  removeGeofence: (zoneId: string) => void;
  pairNewDevice: (deviceData: { childName: string; childNameAr: string; childAge: number; deviceName: string; platform: 'android' | 'ios' }) => string;
  pairDeviceByCode: (code: string, extraData?: { childName?: string; childNameAr?: string; deviceName?: string; platform?: 'android' | 'ios'; deviceId?: string }) => { success: boolean; device: ChildDevice };
  pairDeviceFromQr: (qrRawText: string) => { success: boolean; device?: ChildDevice; message: string };

  // Real Child Telemetry & SOS
  reportChildTelemetry: (deviceId: string, telemetry: { batteryLevel?: number; isCharging?: boolean; latitude?: number; longitude?: number; address?: string }) => void;
  sendChildSOS: (deviceId: string, note?: string) => void;

  // In-app Toast notifications
  toast: ToastInfo | null;
  showToast: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  hideToast: () => void;
}

const STORAGE_KEY = 'parentguard_devices_v1';
const ALERTS_KEY = 'parentguard_alerts_v1';
const PIN_KEY = 'parentguard_pin_v1';
const THEME_KEY = 'parentguard_theme_mode_v1';

const ParentControlContext = createContext<ParentControlContextType | undefined>(undefined);

export const ParentControlProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [themeMode, setThemeModeState] = useState<'light' | 'dark' | 'auto'>(() => {
    try {
      const saved = localStorage.getItem(THEME_KEY);
      if (saved === 'light' || saved === 'dark' || saved === 'auto') return saved;
    } catch (e) {
      console.error(e);
    }
    return 'auto';
  });

  const [isSystemDark, setIsSystemDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const matchesMedia = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const hours = new Date().getHours();
      return matchesMedia || (hours >= 19 || hours < 6);
    }
    return false;
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const checkDark = () => {
      const hours = new Date().getHours();
      const isNight = hours >= 19 || hours < 6;
      setIsSystemDark(mediaQuery.matches || isNight);
    };

    checkDark();
    mediaQuery.addEventListener('change', checkDark);
    const interval = setInterval(checkDark, 60000);
    return () => {
      mediaQuery.removeEventListener('change', checkDark);
      clearInterval(interval);
    };
  }, []);

  const isDarkMode = themeMode === 'dark' || (themeMode === 'auto' && isSystemDark);

  useEffect(() => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [isDarkMode]);

  const setThemeMode = useCallback((mode: 'light' | 'dark' | 'auto') => {
    setThemeModeState(mode);
    try {
      localStorage.setItem(THEME_KEY, mode);
    } catch (e) {
      console.error(e);
    }
  }, []);

  const toggleTheme = useCallback(() => {
    setThemeModeState(prev => {
      let next: 'light' | 'dark' | 'auto' = 'dark';
      if (prev === 'light') next = 'dark';
      else if (prev === 'dark') next = 'auto';
      else next = 'light';
      try {
        localStorage.setItem(THEME_KEY, next);
      } catch (e) {
        console.error(e);
      }
      return next;
    });
  }, []);

  // Global Toast Notifications
  const [toast, setToast] = useState<ToastInfo | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'info' | 'warning' | 'error' = 'success') => {
    const id = 'toast_' + Date.now();
    setToast({ id, message, type });
    setTimeout(() => {
      setToast(current => (current?.id === id ? null : current));
    }, 3800);
  }, []);

  const hideToast = useCallback(() => {
    setToast(null);
  }, []);

  const [devices, setDevices] = useState<ChildDevice[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_DEVICES;
  });

  const [activeDeviceId, setActiveDeviceId] = useState<string>(() => {
    return devices[0]?.id || 'dev_ahmed_01';
  });

  const [alerts, setAlerts] = useState<AlertNotification[]>(() => {
    try {
      const saved = localStorage.getItem(ALERTS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_ALERTS;
  });

  const [parentPin, setParentPinState] = useState<string>(() => {
    return localStorage.getItem(PIN_KEY) || '1234';
  });
  const [isParentDashboardLocked, setIsParentDashboardLocked] = useState(false);
  const [cloudSyncStatus, setCloudSyncStatus] = useState<'connected' | 'syncing' | 'offline'>('syncing');

  const [commandsLog, setCommandsLog] = useState<RemoteCommandLog[]>([]);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [simulatorScreen, setSimulatorScreen] = useState<'home' | 'app' | 'lock' | 'incoming_call'>('home');
  const [simulatorActiveAppId, setSimulatorActiveAppId] = useState<string | null>(null);
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [isLiveCameraStreaming, setIsLiveCameraStreaming] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('environment');
  const [isFlashlightActive, setIsFlashlightActive] = useState(false);
  const [isMicListening, setIsMicListening] = useState(false);
  const [micDecibels, setMicDecibels] = useState(38);
  const [sirenPlaying, setSirenPlaying] = useState(false);
  const [isAudioMuted] = useState(false);

  // Broadcast Channel setup for zero-latency inter-tab testing
  const broadcastChannelRef = React.useRef<BroadcastChannel | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      const bc = new BroadcastChannel('parentguard_live_channel');
      broadcastChannelRef.current = bc;

      bc.onmessage = (event) => {
        const msg = event.data;
        if (!msg) return;

        if (msg.type === 'DEVICE_UPDATE' && msg.device) {
          setDevices(prev => prev.map(d => (d.id === msg.device.id ? msg.device : d)));
        } else if (msg.type === 'SIREN_STATE') {
          if (msg.active) {
            setSirenPlaying(true);
            sirenPlayer.start();
          } else {
            setSirenPlaying(false);
            sirenPlayer.stop();
          }
        } else if (msg.type === 'NEW_ALERT' && msg.alert) {
          setAlerts(prev => [msg.alert, ...prev]);
        }
      };

      return () => {
        bc.close();
      };
    }
  }, []);

  // Firestore Realtime Synchronization
  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    async function initFirestore() {
      try {
        const isOnline = await testFirestoreConnection();
        if (isOnline) {
          setCloudSyncStatus('connected');
        }

        // Subscribe to devices collection
        unsubscribe = onSnapshot(collection(db, 'devices'), (snapshot) => {
          if (!snapshot.empty) {
            const remoteDevices: ChildDevice[] = [];
            snapshot.forEach((docSnap) => {
              remoteDevices.push(docSnap.data() as ChildDevice);
            });
            setDevices(prev => {
              // Merge remote devices with local state
              const map = new Map<string, ChildDevice>();
              prev.forEach(d => map.set(d.id, d));
              remoteDevices.forEach(d => map.set(d.id, d));
              return Array.from(map.values());
            });
            setCloudSyncStatus('connected');
          } else {
            // Seed initial devices into Firestore
            INITIAL_DEVICES.forEach(dev => {
              setDoc(doc(db, 'devices', dev.id), dev).catch(console.error);
            });
            setCloudSyncStatus('connected');
          }
        }, (err) => {
          console.warn('[Firestore] Sync status offline:', err.message);
          setCloudSyncStatus('offline');
        });
      } catch (err) {
        console.warn('[Firestore] Error initializing:', err);
        setCloudSyncStatus('offline');
      }
    }

    initFirestore();

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Sync state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(devices));
    } catch (e) {
      console.error(e);
    }
  }, [devices]);

  useEffect(() => {
    try {
      localStorage.setItem(ALERTS_KEY, JSON.stringify(alerts));
    } catch (e) {
      console.error(e);
    }
  }, [alerts]);

  // Master Parent PIN methods
  const lockParentDashboard = useCallback(() => {
    setIsParentDashboardLocked(true);
  }, []);

  const unlockParentDashboard = useCallback((pin: string): boolean => {
    if (pin === parentPin) {
      setIsParentDashboardLocked(false);
      return true;
    }
    return false;
  }, [parentPin]);

  const setParentPin = useCallback((newPin: string) => {
    setParentPinState(newPin);
    localStorage.setItem(PIN_KEY, newPin);
  }, []);

  // Active Device Memo
  const activeDevice = useMemo(() => {
    return devices.find(d => d.id === activeDeviceId) || devices[0];
  }, [devices, activeDeviceId]);

  // Unread alerts count
  const unreadAlertsCount = useMemo(() => {
    return alerts.filter(a => !a.isRead).length;
  }, [alerts]);

  // Log remote command
  const logCommand = useCallback((cmdEn: string, cmdAr: string, target?: string) => {
    const newLog: RemoteCommandLog = {
      id: 'cmd_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5),
      deviceId: activeDeviceId,
      command: cmdEn,
      commandAr: cmdAr,
      status: 'executed',
      timestamp: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      target
    };
    setCommandsLog(prev => [newLog, ...prev.slice(0, 19)]);
  }, [activeDeviceId]);

  // Toggle Language
  const toggleLanguage = useCallback(() => {
    setLanguage(prev => {
      const next = prev === 'ar' ? 'en' : 'ar';
      document.documentElement.dir = next === 'ar' ? 'rtl' : 'ltr';
      document.documentElement.lang = next;
      return next;
    });
  }, []);

  // Update specific active device state
  const updateActiveDevice = useCallback((updater: (dev: ChildDevice) => ChildDevice) => {
    setDevices(prev => {
      const next = prev.map(d => (d.id === activeDeviceId ? updater(d) : d));
      const updated = next.find(d => d.id === activeDeviceId);
      if (updated) {
        broadcastChannelRef.current?.postMessage({ type: 'DEVICE_UPDATE', device: updated });
        setDoc(doc(db, 'devices', updated.id), updated, { merge: true }).catch(err => {
          console.warn('[Firestore] Sync device error:', err);
        });
      }
      return next;
    });
  }, [activeDeviceId]);

  // Report Child Telemetry directly from Child device
  const reportChildTelemetry = useCallback((deviceId: string, telemetry: { batteryLevel?: number; isCharging?: boolean; latitude?: number; longitude?: number; address?: string }) => {
    setDevices(prev => {
      const next = prev.map(d => {
        if (d.id !== deviceId) return d;
        const updated: ChildDevice = {
          ...d,
          batteryLevel: telemetry.batteryLevel !== undefined ? telemetry.batteryLevel : d.batteryLevel,
          isCharging: telemetry.isCharging !== undefined ? telemetry.isCharging : d.isCharging,
          lastSyncTime: 'الآن (محدث حياً)',
          currentLocation: {
            ...d.currentLocation,
            lat: telemetry.latitude !== undefined ? telemetry.latitude : d.currentLocation.lat,
            lng: telemetry.longitude !== undefined ? telemetry.longitude : d.currentLocation.lng,
            address: telemetry.address || d.currentLocation.address,
            lastUpdated: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
          }
        };
        broadcastChannelRef.current?.postMessage({ type: 'DEVICE_UPDATE', device: updated });
        setDoc(doc(db, 'devices', updated.id), updated, { merge: true }).catch(console.error);
        return updated;
      });
      return next;
    });
  }, []);

  // Send Child SOS Alert
  const sendChildSOS = useCallback((deviceId: string, note?: string) => {
    const targetDev = devices.find(d => d.id === deviceId) || activeDevice;
    const newAlert: AlertNotification = {
      id: 'sos_' + Date.now(),
      deviceId: targetDev.id,
      childName: targetDev.childNameAr,
      title: '🚨 نداء استغاثة طارئ (SOS)!',
      titleAr: '🚨 نداء استغاثة طارئ (SOS)!',
      message: note || `أطلق ${targetDev.childNameAr} نداء استغاثة فوري من جهازه. موقع الطفل الآن مسجل.`,
      messageAr: note || `أطلق ${targetDev.childNameAr} نداء استغاثة فوري من جهازه. موقع الطفل الآن مسجل.`,
      severity: 'critical',
      type: 'sos',
      timestamp: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      isRead: false,
    };

    setAlerts(prev => [newAlert, ...prev]);
    broadcastChannelRef.current?.postMessage({ type: 'NEW_ALERT', alert: newAlert });
    setDoc(doc(db, 'alerts', newAlert.id), newAlert).catch(console.error);
    sirenPlayer.start();
    setSirenPlaying(true);
  }, [activeDevice, devices]);

  // Launch App in Child Simulator
  const launchAppInSimulator = useCallback((appId: string) => {
    const app = activeDevice?.installedApps.find(a => a.id === appId);
    if (!app) return;
    if (app.isBlocked || activeDevice.settings.screenLocked) {
      setSimulatorScreen('lock');
    } else {
      setSimulatorActiveAppId(appId);
      setSimulatorScreen('app');
    }
    setIsSimulatorOpen(true);
  }, [activeDevice]);

  // Block / Unblock App
  const toggleAppBlock = useCallback((appId: string) => {
    updateActiveDevice(dev => {
      const app = dev.installedApps.find(a => a.id === appId);
      const willBlock = app ? !app.isBlocked : false;
      const updatedApps = dev.installedApps.map(a => 
        a.id === appId ? { ...a, isBlocked: willBlock } : a
      );
      return {
        ...dev,
        installedApps: updatedApps,
        lastSyncTime: 'الآن (محدث)'
      };
    });

    const app = activeDevice?.installedApps.find(a => a.id === appId);
    const appName = app ? app.nameAr : 'تطبيق';
    const isNowBlocked = !app?.isBlocked;
    logCommand(
      `${isNowBlocked ? 'Block' : 'Unblock'} app: ${app?.name}`,
      `${isNowBlocked ? 'حظر' : 'إلغاء حظر'} تطبيق: ${appName}`,
      app?.name
    );

    // If simulator is displaying this blocked app, switch to lock screen
    if (simulatorActiveAppId === appId && isNowBlocked) {
      setSimulatorScreen('lock');
    }
  }, [activeDevice, logCommand, simulatorActiveAppId, updateActiveDevice]);

  // Set App Daily Time Limit
  const setAppLimit = useCallback((appId: string, minutes: number) => {
    updateActiveDevice(dev => ({
      ...dev,
      installedApps: dev.installedApps.map(a => 
        a.id === appId ? { ...a, dailyLimitMinutes: minutes } : a
      ),
      lastSyncTime: 'الآن (محدث)'
    }));
    const app = activeDevice?.installedApps.find(a => a.id === appId);
    logCommand(
      `Set daily limit: ${minutes}m for ${app?.name}`,
      `تحديد حد يومي: ${minutes} دقيقة لتطبيق ${app?.nameAr}`
    );
  }, [activeDevice, logCommand, updateActiveDevice]);

  // Uninstall App Remotely
  const uninstallApp = useCallback((appId: string) => {
    const app = activeDevice?.installedApps.find(a => a.id === appId);
    if (!app) return;
    updateActiveDevice(dev => ({
      ...dev,
      installedApps: dev.installedApps.filter(a => a.id !== appId),
      lastSyncTime: 'الآن (محدث)'
    }));
    logCommand(
      `Remote Uninstall: ${app.name}`,
      `حذف التطبيق عن بُعد: ${app.nameAr}`
    );
    if (simulatorActiveAppId === appId) {
      setSimulatorScreen('home');
      setSimulatorActiveAppId(null);
    }
  }, [activeDevice, logCommand, simulatorActiveAppId, updateActiveDevice]);

  // Install Curated App
  const installApp = useCallback((appData: { name: string; nameAr: string; packageName: string; category: any; icon: string; sizeMb: number }) => {
    const newApp: InstalledApp = {
      id: 'app_' + Date.now(),
      name: appData.name,
      nameAr: appData.nameAr,
      packageName: appData.packageName,
      icon: appData.icon,
      category: appData.category,
      isBlocked: false,
      dailyLimitMinutes: 60,
      usedMinutesToday: 0,
      installDate: new Date().toISOString().split('T')[0],
      sizeMb: appData.sizeMb,
      version: '1.0.0',
      isSystemApp: false,
    };

    updateActiveDevice(dev => ({
      ...dev,
      installedApps: [newApp, ...dev.installedApps],
      lastSyncTime: 'الآن (محدث)'
    }));

    logCommand(
      `Remote Install Pushed: ${appData.name}`,
      `تثبيت التطبيق عن بُعد: ${appData.nameAr}`
    );
  }, [logCommand, updateActiveDevice]);

  // Toggle Hardware Setting (WiFi, Bluetooth, etc.)
  const toggleHardwareSetting = useCallback((settingKey: keyof DeviceSettings) => {
    updateActiveDevice(dev => {
      const currentVal = Boolean(dev.settings[settingKey]);
      const updatedVal = !currentVal;
      return {
        ...dev,
        settings: {
          ...dev.settings,
          [settingKey]: updatedVal
        },
        lastSyncTime: 'الآن (محدث)'
      };
    });

    const labelsAr: Record<string, string> = {
      wifiEnabled: 'واي فاي (WiFi)',
      bluetoothEnabled: 'بلوتوث (Bluetooth)',
      cellularDataEnabled: 'بيانات الهاتف (5G/4G)',
      airplaneMode: 'وضع الطيران (Airplane Mode)',
      gpsEnabled: 'خدمات الموقع الجغرافي (GPS)',
      hotspotEnabled: 'نقطة الاتصال (Hotspot)',
      flashlightEnabled: 'الفلاش كشاف (Torch)',
      doNotDisturb: 'عدم الإزعاج (DND)',
      safeSearchEnabled: 'البحث الآمن وفلترة الويب',
      installAppsBlocked: 'منع تثبيت التطبيقات',
      uninstallAppsBlocked: 'منع حذف التطبيقات',
      cameraBlocked: 'تعطيل الكاميرا كلياً',
      micBlocked: 'تعطيل الميكروفون',
      screenLocked: 'قفل شاشة الجهاز الفوري',
      bedtimeActive: 'وضع النوم الليلي',
    };

    const isNowOn = !activeDevice?.settings[settingKey];
    logCommand(
      `Toggle ${String(settingKey)} -> ${isNowOn}`,
      `تبديل ${labelsAr[String(settingKey)] || String(settingKey)} -> ${isNowOn ? 'تفعيل' : 'إيقاف'}`
    );
  }, [activeDevice, logCommand, updateActiveDevice]);

  // Update Slider Setting
  const updateSliderSetting = useCallback((settingKey: 'volumeMedia' | 'volumeRing' | 'volumeAlarm' | 'brightness', value: number) => {
    updateActiveDevice(dev => ({
      ...dev,
      settings: {
        ...dev.settings,
        [settingKey]: value
      }
    }));
  }, [updateActiveDevice]);

  // Instant Screen Lockdown
  const setDeviceLockdown = useCallback((locked: boolean, message?: string) => {
    const lockMsg = message || 'تم قفل هذا الهاتف بواسطة ولي الأمر. يرجى التوقف عن استخدام الجهاز الآن.';
    updateActiveDevice(dev => ({
      ...dev,
      settings: {
        ...dev.settings,
        screenLocked: locked,
        lockMessage: lockMsg
      },
      lastSyncTime: 'الآن (محدث)'
    }));

    if (locked) {
      setSimulatorScreen('lock');
    } else if (simulatorScreen === 'lock') {
      setSimulatorScreen('home');
    }

    logCommand(
      locked ? 'Instant Device Lockdown Enabled' : 'Device Unlocked',
      locked ? 'تفعيل القفل الفوري للجهاز' : 'إلغاء قفل الجهاز والسماح بالاستخدام'
    );
  }, [logCommand, simulatorScreen, updateActiveDevice]);

  // Emergency Siren
  const triggerEmergencySiren = useCallback(() => {
    setSirenPlaying(true);
    sirenPlayer.start();
    updateActiveDevice(dev => ({
      ...dev,
      sirenActive: true,
      settings: {
        ...dev.settings,
        sirenActive: true
      }
    }));
    broadcastChannelRef.current?.postMessage({ type: 'SIREN_STATE', active: true, deviceId: activeDeviceId });
    logCommand('Trigger Remote Loud Siren', 'تشغيل صفارة الإنذار بصوت مرتفع جداً للبحث عن الهاتف');
  }, [activeDeviceId, logCommand, updateActiveDevice]);

  const stopEmergencySiren = useCallback(() => {
    setSirenPlaying(false);
    sirenPlayer.stop();
    updateActiveDevice(dev => ({
      ...dev,
      sirenActive: false,
      settings: {
        ...dev.settings,
        sirenActive: false
      }
    }));
    broadcastChannelRef.current?.postMessage({ type: 'SIREN_STATE', active: false, deviceId: activeDeviceId });
    logCommand('Stop Remote Siren', 'إيقاف صفارة الإنذار');
  }, [activeDeviceId, logCommand, updateActiveDevice]);

  // Camera Controls
  const startCameraStream = useCallback((facing: 'user' | 'environment' = 'environment') => {
    setCameraFacing(facing);
    setIsLiveCameraStreaming(true);
    logCommand(
      `Start remote camera stream (${facing})`,
      `بدء البث المباشر للكاميرا عن بُعد (${facing === 'user' ? 'الأمامية' : 'الخلفية'})`
    );
  }, [logCommand]);

  const stopCameraStream = useCallback(() => {
    setIsLiveCameraStreaming(false);
    setIsFlashlightActive(false);
    logCommand('Stop remote camera stream', 'إيقاف البث المباشر للكاميرا');
  }, [logCommand]);

  const toggleCameraFacing = useCallback(() => {
    setCameraFacing(prev => {
      const next = prev === 'user' ? 'environment' : 'user';
      logCommand(
        `Switch camera to ${next}`,
        `تبديل الكاميرا إلى ${next === 'user' ? 'الأمامية (Selfie)' : 'الخلفية (Main)'}`
      );
      return next;
    });
  }, [logCommand]);

  const toggleFlashlight = useCallback(() => {
    setIsFlashlightActive(prev => {
      const next = !prev;
      logCommand(
        `Toggle flashlight -> ${next}`,
        `تشغيل/إيقاف الفلاش عن بُعد -> ${next ? 'مفعل' : 'مغلق'}`
      );
      return next;
    });
  }, [logCommand]);

  // Mic Controls
  const startMicListening = useCallback(() => {
    setIsMicListening(true);
    logCommand('Start remote ambient mic listening', 'بدء الاستماع للمحيط الصوتي عبر ميكروفون الهاتف');
  }, [logCommand]);

  const stopMicListening = useCallback(() => {
    setIsMicListening(false);
    logCommand('Stop remote mic listening', 'إيقاف الاستماع للميكروفون');
  }, [logCommand]);

  // Simulating sound level fluctuations when mic is active
  useEffect(() => {
    if (!isMicListening) return;
    const interval = setInterval(() => {
      const randomDb = Math.floor(35 + Math.random() * 45);
      setMicDecibels(randomDb);
    }, 400);
    return () => clearInterval(interval);
  }, [isMicListening]);

  // Alert Actions
  const markAlertAsRead = useCallback((alertId: string) => {
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, isRead: true } : a));
  }, []);

  const markAllAlertsAsRead = useCallback(() => {
    setAlerts(prev => prev.map(a => ({ ...a, isRead: true })));
  }, []);

  const deleteAlert = useCallback((alertId: string) => {
    setAlerts(prev => prev.filter(a => a.id !== alertId));
  }, []);

  // Geofence Actions
  const addGeofence = useCallback((zone: { name: string; nameAr: string; lat: number; lng: number; radiusMeters: number; address: string; type: 'safe' | 'danger' }) => {
    const newZone = {
      id: 'geo_' + Date.now(),
      name: zone.name,
      nameAr: zone.nameAr,
      lat: zone.lat,
      lng: zone.lng,
      radiusMeters: zone.radiusMeters,
      type: zone.type,
      address: zone.address,
      notifyOnEnter: true,
      notifyOnExit: true,
    };
    updateActiveDevice(dev => ({
      ...dev,
      geofenceZones: [...dev.geofenceZones, newZone]
    }));
    logCommand(
      `Added Geofence: ${zone.name}`,
      `إضافة منطقة جغرافية آمنة: ${zone.nameAr}`
    );
  }, [logCommand, updateActiveDevice]);

  const removeGeofence = useCallback((zoneId: string) => {
    updateActiveDevice(dev => ({
      ...dev,
      geofenceZones: dev.geofenceZones.filter(z => z.id !== zoneId)
    }));
    logCommand('Removed Geofence', 'حذف المنطقة الجغرافية');
  }, [logCommand, updateActiveDevice]);

  // Pair New Device
  const pairNewDevice = useCallback((deviceData: { childName: string; childNameAr: string; childAge: number; deviceName: string; platform: 'android' | 'ios' }): string => {
    const randomCode = 'PG-' + Math.floor(1000 + Math.random() * 9000);
    const newId = 'dev_' + Date.now();
    const newDev: ChildDevice = {
      id: newId,
      childName: deviceData.childName,
      childNameAr: deviceData.childNameAr,
      childAge: deviceData.childAge,
      avatarUrl: deviceData.platform === 'android' 
        ? 'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?w=150&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
      deviceName: deviceData.deviceName,
      platform: deviceData.platform,
      model: deviceData.platform === 'android' ? 'Android Device' : 'Apple iPhone',
      osVersion: deviceData.platform === 'android' ? 'Android 14' : 'iOS 17.4',
      batteryLevel: 95,
      isCharging: false,
      isOnline: true,
      lastSyncTime: 'الآن (متصل حديثاً)',
      screenTimeTodayMinutes: 45,
      screenTimeLimitMinutes: 180,
      currentLocation: {
        lat: 24.7136,
        lng: 46.6753,
        address: 'الرياض، المملكة العربية السعودية',
        speedKmh: 0,
        accuracyMeters: 5,
        lastUpdated: 'الآن',
      },
      simCarrier: '5G متصل',
      pairingCode: randomCode,
      geofenceZones: [],
      settings: {
        wifiEnabled: true,
        bluetoothEnabled: true,
        cellularDataEnabled: true,
        airplaneMode: false,
        gpsEnabled: true,
        hotspotEnabled: false,
        flashlightEnabled: false,
        doNotDisturb: false,
        volumeMedia: 70,
        volumeRing: 80,
        volumeAlarm: 90,
        brightness: 70,
        autoBrightness: true,
        safeSearchEnabled: true,
        installAppsBlocked: true,
        uninstallAppsBlocked: true,
        cameraBlocked: false,
        micBlocked: false,
        screenLocked: false,
        lockMessage: 'تم قفل هذا الهاتف بواسطة ولي الأمر',
        bedtimeStart: '21:30',
        bedtimeEnd: '06:30',
        bedtimeActive: false,
      },
      installedApps: [
        {
          id: 'app_yt_' + Date.now(),
          name: 'YouTube Kids',
          nameAr: 'يوتيوب أطفال',
          packageName: 'com.google.android.youtubekids',
          icon: 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png',
          category: 'entertainment',
          isBlocked: false,
          dailyLimitMinutes: 60,
          usedMinutesToday: 20,
          installDate: new Date().toISOString().split('T')[0],
          sizeMb: 110,
          version: '8.45',
          isSystemApp: false,
        },
        {
          id: 'app_duo_' + Date.now(),
          name: 'Duolingo',
          nameAr: 'دويولينجو لغات',
          packageName: 'com.duolingo',
          icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968841.png',
          category: 'education',
          isBlocked: false,
          dailyLimitMinutes: 0,
          usedMinutesToday: 15,
          installDate: new Date().toISOString().split('T')[0],
          sizeMb: 85,
          version: '5.14',
          isSystemApp: false,
        }
      ]
    };

    setDevices(prev => [...prev, newDev]);
    setActiveDeviceId(newId);
    logCommand(
      `Paired New Device: ${deviceData.deviceName} (${randomCode})`,
      `تم إقران جهاز جديد: ${deviceData.deviceName} برمز (${randomCode})`
    );

    return randomCode;
  }, [logCommand]);

  // Pair Device by Code or QR payload
  const pairDeviceByCode = useCallback((code: string, extraData?: { childName?: string; childNameAr?: string; deviceName?: string; platform?: 'android' | 'ios'; deviceId?: string }): { success: boolean; device: ChildDevice } => {
    const cleanCode = code.trim().toUpperCase();
    
    // Check if device already exists with this pairingCode or id
    const existingIndex = devices.findIndex(d => 
      (d.pairingCode && d.pairingCode.toUpperCase() === cleanCode) || 
      (extraData?.deviceId && d.id === extraData.deviceId)
    );

    if (existingIndex !== -1) {
      const existing = devices[existingIndex];
      const updated: ChildDevice = {
        ...existing,
        isOnline: true,
        lastSyncTime: 'الآن (متصل عبر QR)',
        batteryLevel: Math.max(existing.batteryLevel, 88),
      };

      setDevices(prev => {
        const next = [...prev];
        next[existingIndex] = updated;
        return next;
      });
      setActiveDeviceId(updated.id);

      // Broadcast and Firestore
      broadcastChannelRef.current?.postMessage({ type: 'DEVICE_UPDATE', device: updated });
      setDoc(doc(db, 'devices', updated.id), updated, { merge: true }).catch(console.error);

      // Add alert
      const newAlert: AlertNotification = {
        id: 'alt_' + Date.now(),
        deviceId: updated.id,
        childName: updated.childName,
        title: 'تم تأكيد الإقران عبر QR',
        titleAr: 'تم إقران الجهاز بنجاح عبر رمز QR',
        message: `تم ربط هاتف ${updated.childNameAr} (${updated.deviceName}) بنجاح عبر مسح باركود QR!`,
        messageAr: `تم ربط هاتف ${updated.childNameAr} (${updated.deviceName}) بنجاح عبر مسح باركود QR!`,
        timestamp: 'الآن',
        severity: 'info',
        type: 'setting_change',
        isRead: false
      };
      setAlerts(prev => [newAlert, ...prev]);

      logCommand(
        `Device Paired via QR: ${updated.deviceName} (${cleanCode})`,
        `تم إقران الهاتف بنجاح عبر رمز الـ QR: ${updated.deviceName}`
      );

      return { success: true, device: updated };
    }

    // Otherwise, create a new device dynamically from the QR data
    const newId = extraData?.deviceId || ('dev_' + Date.now());
    const cName = extraData?.childName || 'طفل جديد';
    const cNameAr = extraData?.childNameAr || extraData?.childName || 'طفل جديد';
    const devName = extraData?.deviceName || 'هاتف مقترن حديثاً';
    const plat = extraData?.platform || 'android';

    const newDev: ChildDevice = {
      id: newId,
      childName: cName,
      childNameAr: cNameAr,
      childAge: 10,
      avatarUrl: plat === 'android' 
        ? 'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?w=150&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
      deviceName: devName,
      platform: plat,
      model: plat === 'android' ? 'Galaxy Phone (QR Paired)' : 'Apple iPhone (QR Paired)',
      osVersion: plat === 'android' ? 'Android 14' : 'iOS 17',
      batteryLevel: 94,
      isCharging: false,
      isOnline: true,
      lastSyncTime: 'الآن (مقترن عبر QR)',
      screenTimeTodayMinutes: 10,
      screenTimeLimitMinutes: 180,
      currentLocation: {
        lat: 24.7136,
        lng: 46.6753,
        address: 'الرياض، المملكة العربية السعودية',
        speedKmh: 0,
        accuracyMeters: 4,
        lastUpdated: 'الآن',
      },
      simCarrier: '5G متصل',
      pairingCode: cleanCode,
      geofenceZones: [],
      settings: {
        wifiEnabled: true,
        bluetoothEnabled: true,
        cellularDataEnabled: true,
        airplaneMode: false,
        gpsEnabled: true,
        hotspotEnabled: false,
        flashlightEnabled: false,
        doNotDisturb: false,
        volumeMedia: 75,
        volumeRing: 80,
        volumeAlarm: 90,
        brightness: 75,
        autoBrightness: true,
        safeSearchEnabled: true,
        installAppsBlocked: true,
        uninstallAppsBlocked: true,
        cameraBlocked: false,
        micBlocked: false,
        screenLocked: false,
        lockMessage: 'تم قفل هذا الهاتف بواسطة ولي الأمر',
        bedtimeStart: '21:30',
        bedtimeEnd: '06:30',
        bedtimeActive: false,
      },
      installedApps: [
        {
          id: 'app_yt_' + Date.now(),
          name: 'YouTube Kids',
          nameAr: 'يوتيوب أطفال',
          packageName: 'com.google.android.youtubekids',
          icon: 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png',
          category: 'entertainment',
          isBlocked: false,
          dailyLimitMinutes: 60,
          usedMinutesToday: 10,
          installDate: new Date().toISOString().split('T')[0],
          sizeMb: 110,
          version: '8.45',
          isSystemApp: false,
        },
        {
          id: 'app_duo_' + Date.now(),
          name: 'Duolingo',
          nameAr: 'دويولينجو لغات',
          packageName: 'com.duolingo',
          icon: 'https://cdn-icons-png.flaticon.com/512/5968/5968841.png',
          category: 'education',
          isBlocked: false,
          dailyLimitMinutes: 0,
          usedMinutesToday: 5,
          installDate: new Date().toISOString().split('T')[0],
          sizeMb: 85,
          version: '5.14',
          isSystemApp: false,
        }
      ]
    };

    setDevices(prev => [...prev, newDev]);
    setActiveDeviceId(newDev.id);
    broadcastChannelRef.current?.postMessage({ type: 'DEVICE_UPDATE', device: newDev });
    setDoc(doc(db, 'devices', newDev.id), newDev).catch(console.error);

    logCommand(
      `New Device Paired via QR: ${newDev.deviceName} (${cleanCode})`,
      `تم إقران جهاز جديد بالكامل عبر رمز QR: ${newDev.deviceName}`
    );

    return { success: true, device: newDev };
  }, [devices, logCommand]);

  const pairDeviceFromQr = useCallback((qrRawText: string): { success: boolean; device?: ChildDevice; message: string } => {
    try {
      const text = qrRawText.trim();
      let code = '';
      let deviceId = '';
      let childName = '';
      let childNameAr = '';
      let deviceName = '';
      let platform: 'android' | 'ios' = 'android';

      // Case 1: JSON payload
      if (text.startsWith('{') && text.endsWith('}')) {
        const parsed = JSON.parse(text);
        code = parsed.code || parsed.pairingCode || '';
        deviceId = parsed.deviceId || '';
        childName = parsed.childName || '';
        childNameAr = parsed.childNameAr || parsed.childName || '';
        deviceName = parsed.deviceName || '';
        if (parsed.platform === 'ios' || parsed.platform === 'android') {
          platform = parsed.platform;
        }
      }
      // Case 2: URL with query params
      else if (text.includes('?')) {
        const url = new URL(text.startsWith('http') ? text : `https://dummy.com/${text}`);
        code = url.searchParams.get('pairCode') || url.searchParams.get('code') || '';
        deviceId = url.searchParams.get('deviceId') || url.searchParams.get('devId') || '';
        childName = url.searchParams.get('childName') || '';
        childNameAr = url.searchParams.get('childNameAr') || childName;
        deviceName = url.searchParams.get('deviceName') || url.searchParams.get('device') || '';
        const platParam = url.searchParams.get('platform');
        if (platParam === 'ios' || platParam === 'android') {
          platform = platParam;
        }
      }
      // Case 3: Plain text code
      else {
        code = text;
      }

      if (!code) {
        return { success: false, message: 'لم يتم العثور على رمز إقران صالح في الباركود.' };
      }

      const res = pairDeviceByCode(code, { childName, childNameAr, deviceName, deviceId, platform });
      return { 
        success: true, 
        device: res.device, 
        message: `تم الاقتران بنجاح مع ${res.device.childNameAr || res.device.deviceName}!` 
      };
    } catch (e: any) {
      return { success: false, message: 'خطأ في معالجة بيانات الباركود: ' + (e?.message || 'غير صالح') };
    }
  }, [pairDeviceByCode]);

  return (
    <ParentControlContext.Provider
      value={{
        devices,
        activeDeviceId,
        activeDevice,
        alerts,
        unreadAlertsCount,
        commandsLog,
        isSimulatorOpen,
        simulatorScreen,
        simulatorActiveAppId,
        language,
        themeMode,
        isDarkMode,
        setThemeMode,
        toggleTheme,
        isAudioMuted,
        isLiveCameraStreaming,
        cameraFacing,
        isFlashlightActive,
        isMicListening,
        micDecibels,
        sirenPlaying,
        cloudSyncStatus,
        isParentDashboardLocked,
        parentPin,
        lockParentDashboard,
        unlockParentDashboard,
        setParentPin,
        setActiveDeviceId,
        toggleLanguage,
        setIsSimulatorOpen,
        setSimulatorScreen,
        launchAppInSimulator,
        toggleAppBlock,
        setAppLimit,
        uninstallApp,
        installApp,
        toggleHardwareSetting,
        updateSliderSetting,
        setDeviceLockdown,
        triggerEmergencySiren,
        stopEmergencySiren,
        startCameraStream,
        stopCameraStream,
        toggleCameraFacing,
        toggleFlashlight,
        startMicListening,
        stopMicListening,
        markAlertAsRead,
        markAllAlertsAsRead,
        deleteAlert,
        addGeofence,
        removeGeofence,
        pairNewDevice,
        pairDeviceByCode,
        pairDeviceFromQr,
        reportChildTelemetry,
        sendChildSOS,
        toast,
        showToast,
        hideToast,
      }}
    >
      {children}
    </ParentControlContext.Provider>
  );
};

export const useParentControl = () => {
  const context = useContext(ParentControlContext);
  if (!context) {
    throw new Error('useParentControl must be used within a ParentControlProvider');
  }
  return context;
};
