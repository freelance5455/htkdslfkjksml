import React, { createContext, useContext, useEffect, useState, useMemo, useCallback } from 'react';
import {
  Song,
  Artist,
  Album,
  Playlist,
  User,
  UserSettings,
  NavTab,
  RepeatMode,
  SongColorTheme
} from '../types/music';
import {
  INITIAL_SONGS,
  INITIAL_ARTISTS,
  INITIAL_ALBUMS,
  INITIAL_PLAYLISTS,
  INITIAL_USER
} from '../data/musicData';
import { audioEngine } from '../services/audioEngine';

interface MusicContextType {
  // Navigation & UI state
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isNowPlayingOpen: boolean;
  setIsNowPlayingOpen: (open: boolean) => void;
  isLyricsOpen: boolean;
  setIsLyricsOpen: (open: boolean) => void;
  isQueueOpen: boolean;
  setIsQueueOpen: (open: boolean) => void;
  isSleepTimerOpen: boolean;
  setIsSleepTimerOpen: (open: boolean) => void;
  sleepTimerRemaining: number | null;
  selectedPlaylistId: string | null;
  setSelectedPlaylistId: (id: string | null) => void;
  selectedArtistId: string | null;
  setSelectedArtistId: (id: string | null) => void;
  isAdminOpen: boolean;
  setIsAdminOpen: (open: boolean) => void;
  isOnboardingOpen: boolean;
  setIsOnboardingOpen: (open: boolean) => void;
  isAuthOpen: boolean;
  setIsAuthOpen: (open: boolean) => void;
  offlineMode: boolean;
  setOfflineMode: (offline: boolean) => void;

  // Music playback state
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  queue: Song[];
  queueIndex: number;
  shuffle: boolean;
  repeat: RepeatMode;
  volume: number;

  // Catalog data
  songs: Song[];
  artists: Artist[];
  albums: Album[];
  playlists: Playlist[];
  user: User;
  likedSongIds: string[];
  downloadedSongIds: string[];
  searchHistory: string[];
  listeningHistory: Song[];

  // Player controls
  playSong: (song: Song, contextQueue?: Song[]) => void;
  togglePlayPause: () => void;
  playNext: () => void;
  playPrevious: () => void;
  seekTo: (seconds: number) => void;
  setVolume: (vol: number) => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  setSleepTimer: (minutes: number | null) => void;

  // Collection management
  toggleLikeSong: (songId: string) => void;
  toggleDownloadSong: (songId: string) => void;
  createPlaylist: (title: string, description: string, colorTheme?: SongColorTheme) => Playlist;
  addSongToPlaylist: (playlistId: string, songId: string) => void;
  removeSongFromPlaylist: (playlistId: string, songId: string) => void;
  deletePlaylist: (playlistId: string) => void;
  updateUserSettings: (settings: Partial<UserSettings>) => void;
  updateUserProfile: (name: string, email: string) => void;
  addSearchHistory: (query: string) => void;
  clearSearchHistory: () => void;

  // Queue actions
  removeFromQueue: (index: number) => void;
  reorderQueue: (from: number, to: number) => void;
  addToQueueNext: (song: Song) => void;

  // Admin actions
  addSongAdmin: (songData: Omit<Song, 'id' | 'playCount'>) => void;
  editSongAdmin: (songId: string, updates: Partial<Song>) => void;
  deleteSongAdmin: (songId: string) => void;
}

const MusicContext = createContext<MusicContextType | null>(null);

export const MusicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // State initialization with localStorage recovery
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [isNowPlayingOpen, setIsNowPlayingOpen] = useState(false);
  const [isLyricsOpen, setIsLyricsOpen] = useState(false);
  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const [isSleepTimerOpen, setIsSleepTimerOpen] = useState(false);
  const [sleepTimerRemaining, setSleepTimerRemaining] = useState<number | null>(null);
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [selectedArtistId, setSelectedArtistId] = useState<string | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [offlineMode, setOfflineMode] = useState(false);

  // Playback
  const [currentSong, setCurrentSong] = useState<Song | null>(() => INITIAL_SONGS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(INITIAL_SONGS[0].durationSec);
  const [queue, setQueue] = useState<Song[]>(() => INITIAL_SONGS);
  const [queueIndex, setQueueIndex] = useState(0);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<RepeatMode>('off');
  const [volume, setVolumeState] = useState(0.85);

  // Collections
  const [songs, setSongs] = useState<Song[]>(() => {
    const saved = localStorage.getItem('music_express_songs');
    return saved ? JSON.parse(saved) : INITIAL_SONGS;
  });

  const [artists, setArtists] = useState<Artist[]>(() => {
    const saved = localStorage.getItem('music_express_artists');
    return saved ? JSON.parse(saved) : INITIAL_ARTISTS;
  });

  const [albums] = useState<Album[]>(INITIAL_ALBUMS);

  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    const saved = localStorage.getItem('music_express_playlists');
    return saved ? JSON.parse(saved) : INITIAL_PLAYLISTS;
  });

  const [user, setUser] = useState<User>(() => {
    const saved = localStorage.getItem('music_express_user');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [likedSongIds, setLikedSongIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('music_express_liked');
    return saved ? JSON.parse(saved) : ['song-1', 'song-2', 'song-3', 'song-4', 'song-6', 'song-9'];
  });

  const [downloadedSongIds, setDownloadedSongIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('music_express_downloads');
    return saved ? JSON.parse(saved) : ['song-1', 'song-2', 'song-6'];
  });

  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    const saved = localStorage.getItem('music_express_search_history');
    return saved ? JSON.parse(saved) : ['Arijit Singh', 'Midnight Horizon', 'Bengali Lo-Fi', 'Dua Lipa'];
  });

  const [listeningHistory, setListeningHistory] = useState<Song[]>(() => [
    INITIAL_SONGS[0],
    INITIAL_SONGS[1],
    INITIAL_SONGS[3]
  ]);

  // Persist collections
  useEffect(() => {
    localStorage.setItem('music_express_songs', JSON.stringify(songs));
  }, [songs]);

  useEffect(() => {
    localStorage.setItem('music_express_playlists', JSON.stringify(playlists));
  }, [playlists]);

  useEffect(() => {
    localStorage.setItem('music_express_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('music_express_liked', JSON.stringify(likedSongIds));
  }, [likedSongIds]);

  useEffect(() => {
    localStorage.setItem('music_express_downloads', JSON.stringify(downloadedSongIds));
  }, [downloadedSongIds]);

  useEffect(() => {
    localStorage.setItem('music_express_search_history', JSON.stringify(searchHistory));
  }, [searchHistory]);

  // Sync Dark/Light theme class with user settings
  useEffect(() => {
    const root = document.documentElement;
    if (user.settings.darkMode) {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.remove('dark');
      root.classList.add('light');
    }
  }, [user.settings.darkMode]);

  // Wire up audio engine callbacks
  useEffect(() => {
    audioEngine.setCallbacks(
      (curr, dur) => {
        setCurrentTime(curr);
        if (dur) setDuration(dur);
      },
      (playing) => {
        setIsPlaying(playing);
      },
      () => {
        // Track ended
        handleTrackEnded();
      }
    );

    // Apply initial equalizer preset
    audioEngine.setEqualizer(user.settings.equalizerPreset);
  }, [user.settings.equalizerPreset]);

  // Sleep timer interval countdown
  useEffect(() => {
    if (sleepTimerRemaining === null) return;
    if (sleepTimerRemaining <= 0) {
      audioEngine.pause();
      setSleepTimerRemaining(null);
      return;
    }

    const timer = setInterval(() => {
      setSleepTimerRemaining((prev) => (prev && prev > 1 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, [sleepTimerRemaining]);

  const handleTrackEnded = useCallback(() => {
    if (repeat === 'one' && currentSong) {
      audioEngine.loadAndPlay(currentSong, 0);
      return;
    }

    if (queueIndex < queue.length - 1) {
      const nextIdx = queueIndex + 1;
      const nextSong = queue[nextIdx];
      setQueueIndex(nextIdx);
      setCurrentSong(nextSong);
      audioEngine.loadAndPlay(nextSong, 0);
    } else if (repeat === 'all' && queue.length > 0) {
      const nextSong = queue[0];
      setQueueIndex(0);
      setCurrentSong(nextSong);
      audioEngine.loadAndPlay(nextSong, 0);
    } else {
      audioEngine.pause();
      setIsPlaying(false);
    }
  }, [repeat, currentSong, queueIndex, queue]);

  const playSong = useCallback((song: Song, contextQueue?: Song[]) => {
    // If in offline mode, verify if song is downloaded
    if (offlineMode && !downloadedSongIds.includes(song.id)) {
      alert(`"${song.title}" is not available in offline mode. Download it first or switch off Offline Mode.`);
      return;
    }

    const activeQ = contextQueue && contextQueue.length > 0 ? contextQueue : queue;
    const songIndex = activeQ.findIndex((s) => s.id === song.id);

    if (contextQueue) {
      setQueue(contextQueue);
      setQueueIndex(songIndex >= 0 ? songIndex : 0);
    } else if (songIndex >= 0) {
      setQueueIndex(songIndex);
    } else {
      setQueue([song, ...queue]);
      setQueueIndex(0);
    }

    setCurrentSong(song);
    setDuration(song.durationSec);
    setCurrentTime(0);

    // Audio Engine play
    audioEngine.loadAndPlay(song, 0);

    // Add to listening history & update play count
    setListeningHistory((prev) => [song, ...prev.filter((s) => s.id !== song.id)].slice(0, 30));
    setSongs((prev) =>
      prev.map((s) => (s.id === song.id ? { ...s, playCount: s.playCount + 1 } : s))
    );
  }, [offlineMode, downloadedSongIds, queue]);

  const togglePlayPause = useCallback(() => {
    if (!currentSong) return;

    if (isPlaying) {
      audioEngine.pause();
    } else {
      audioEngine.play();
    }
  }, [currentSong, isPlaying]);

  const playNext = useCallback(() => {
    if (queue.length === 0) return;

    let nextIdx: number;
    if (shuffle) {
      nextIdx = Math.floor(Math.random() * queue.length);
    } else {
      nextIdx = (queueIndex + 1) % queue.length;
    }

    const nextSong = queue[nextIdx];
    setQueueIndex(nextIdx);
    setCurrentSong(nextSong);
    setDuration(nextSong.durationSec);
    setCurrentTime(0);
    audioEngine.loadAndPlay(nextSong, 0);
  }, [queue, queueIndex, shuffle]);

  const playPrevious = useCallback(() => {
    if (currentTime > 4) {
      // Seek to start if already played past 4 seconds
      audioEngine.seek(0);
      setCurrentTime(0);
      return;
    }

    if (queue.length === 0) return;
    const prevIdx = queueIndex === 0 ? queue.length - 1 : queueIndex - 1;
    const prevSong = queue[prevIdx];
    setQueueIndex(prevIdx);
    setCurrentSong(prevSong);
    setDuration(prevSong.durationSec);
    setCurrentTime(0);
    audioEngine.loadAndPlay(prevSong, 0);
  }, [currentTime, queue, queueIndex]);

  const seekTo = useCallback((sec: number) => {
    audioEngine.seek(sec);
    setCurrentTime(sec);
  }, []);

  const setVolume = useCallback((val: number) => {
    setVolumeState(val);
    audioEngine.setVolume(val);
  }, []);

  const toggleShuffle = useCallback(() => {
    setShuffle((prev) => !prev);
  }, []);

  const toggleRepeat = useCallback(() => {
    setRepeat((prev) => {
      if (prev === 'off') return 'all';
      if (prev === 'all') return 'one';
      return 'off';
    });
  }, []);

  const setSleepTimer = useCallback((minutes: number | null) => {
    if (minutes === null) {
      setSleepTimerRemaining(null);
    } else {
      setSleepTimerRemaining(minutes * 60);
    }
    setIsSleepTimerOpen(false);
  }, []);

  const toggleLikeSong = useCallback((songId: string) => {
    setLikedSongIds((prev) => {
      const isLiked = prev.includes(songId);
      const nextLiked = isLiked ? prev.filter((id) => id !== songId) : [...prev, songId];

      // Update liked count in user stats
      setUser((u) => ({
        ...u,
        stats: { ...u.stats, likedSongs: nextLiked.length }
      }));

      return nextLiked;
    });
  }, []);

  const toggleDownloadSong = useCallback((songId: string) => {
    setDownloadedSongIds((prev) => {
      if (prev.includes(songId)) {
        return prev.filter((id) => id !== songId);
      } else {
        return [...prev, songId];
      }
    });
  }, []);

  const createPlaylist = useCallback((title: string, description: string, colorTheme?: SongColorTheme) => {
    const newPlaylist: Playlist = {
      id: `playlist-${Date.now()}`,
      title,
      description: description || 'Personalized custom playlist on Music Express.',
      cover: 'custom_playlist',
      creator: user.name,
      songIds: [],
      isPublic: true,
      createdAt: new Date().toISOString().split('T')[0],
      isCustom: true,
      colorTheme: colorTheme || { from: '#9333ea', to: '#3b82f6', accent: '#c084fc' }
    };

    setPlaylists((prev) => [newPlaylist, ...prev]);
    setUser((u) => ({
      ...u,
      stats: { ...u.stats, playlists: u.stats.playlists + 1 }
    }));

    return newPlaylist;
  }, [user.name]);

  const addSongToPlaylist = useCallback((playlistId: string, songId: string) => {
    setPlaylists((prev) =>
      prev.map((pl) => {
        if (pl.id === playlistId && !pl.songIds.includes(songId)) {
          return { ...pl, songIds: [...pl.songIds, songId] };
        }
        return pl;
      })
    );
  }, []);

  const removeSongFromPlaylist = useCallback((playlistId: string, songId: string) => {
    setPlaylists((prev) =>
      prev.map((pl) => {
        if (pl.id === playlistId) {
          return { ...pl, songIds: pl.songIds.filter((id) => id !== songId) };
        }
        return pl;
      })
    );
  }, []);

  const deletePlaylist = useCallback((playlistId: string) => {
    setPlaylists((prev) => prev.filter((pl) => pl.id !== playlistId));
    setUser((u) => ({
      ...u,
      stats: { ...u.stats, playlists: Math.max(0, u.stats.playlists - 1) }
    }));
  }, []);

  const updateUserSettings = useCallback((newSettings: Partial<UserSettings>) => {
    setUser((prev) => {
      const updated = {
        ...prev,
        settings: { ...prev.settings, ...newSettings }
      };

      if (newSettings.equalizerPreset) {
        audioEngine.setEqualizer(newSettings.equalizerPreset);
      }

      return updated;
    });
  }, []);

  const updateUserProfile = useCallback((name: string, email: string) => {
    setUser((prev) => ({ ...prev, name, email }));
  }, []);

  const addSearchHistory = useCallback((term: string) => {
    if (!term.trim()) return;
    setSearchHistory((prev) => [term.trim(), ...prev.filter((t) => t.toLowerCase() !== term.toLowerCase())].slice(0, 10));
  }, []);

  const clearSearchHistory = useCallback(() => {
    setSearchHistory([]);
  }, []);

  const removeFromQueue = useCallback((index: number) => {
    setQueue((prev) => prev.filter((_, idx) => idx !== index));
    if (index < queueIndex) {
      setQueueIndex((prev) => prev - 1);
    }
  }, [queueIndex]);

  const reorderQueue = useCallback((from: number, to: number) => {
    setQueue((prev) => {
      const copy = [...prev];
      const [moved] = copy.splice(from, 1);
      copy.splice(to, 0, moved);
      return copy;
    });
  }, []);

  const addToQueueNext = useCallback((song: Song) => {
    setQueue((prev) => {
      const copy = [...prev];
      copy.splice(queueIndex + 1, 0, song);
      return copy;
    });
  }, [queueIndex]);

  // Admin Catalog actions
  const addSongAdmin = useCallback((songData: Omit<Song, 'id' | 'playCount'>) => {
    const newSong: Song = {
      ...songData,
      id: `song-${Date.now()}`,
      playCount: 100
    };
    setSongs((prev) => [newSong, ...prev]);
  }, []);

  const editSongAdmin = useCallback((songId: string, updates: Partial<Song>) => {
    setSongs((prev) => prev.map((s) => (s.id === songId ? { ...s, ...updates } : s)));
    if (currentSong?.id === songId) {
      setCurrentSong((prev) => (prev ? { ...prev, ...updates } : null));
    }
  }, [currentSong]);

  const deleteSongAdmin = useCallback((songId: string) => {
    setSongs((prev) => prev.filter((s) => s.id !== songId));
    setQueue((prev) => prev.filter((s) => s.id !== songId));
  }, []);

  const contextValue = useMemo<MusicContextType>(
    () => ({
      activeTab,
      setActiveTab,
      isNowPlayingOpen,
      setIsNowPlayingOpen,
      isLyricsOpen,
      setIsLyricsOpen,
      isQueueOpen,
      setIsQueueOpen,
      isSleepTimerOpen,
      setIsSleepTimerOpen,
      sleepTimerRemaining,
      selectedPlaylistId,
      setSelectedPlaylistId,
      selectedArtistId,
      setSelectedArtistId,
      isAdminOpen,
      setIsAdminOpen,
      isOnboardingOpen,
      setIsOnboardingOpen,
      isAuthOpen,
      setIsAuthOpen,
      offlineMode,
      setOfflineMode,

      currentSong,
      isPlaying,
      currentTime,
      duration,
      queue,
      queueIndex,
      shuffle,
      repeat,
      volume,

      songs,
      artists,
      albums,
      playlists,
      user,
      likedSongIds,
      downloadedSongIds,
      searchHistory,
      listeningHistory,

      playSong,
      togglePlayPause,
      playNext,
      playPrevious,
      seekTo,
      setVolume,
      toggleShuffle,
      toggleRepeat,
      setSleepTimer,

      toggleLikeSong,
      toggleDownloadSong,
      createPlaylist,
      addSongToPlaylist,
      removeSongFromPlaylist,
      deletePlaylist,
      updateUserSettings,
      updateUserProfile,
      addSearchHistory,
      clearSearchHistory,

      removeFromQueue,
      reorderQueue,
      addToQueueNext,

      addSongAdmin,
      editSongAdmin,
      deleteSongAdmin
    }),
    [
      activeTab,
      isNowPlayingOpen,
      isLyricsOpen,
      isQueueOpen,
      isSleepTimerOpen,
      sleepTimerRemaining,
      selectedPlaylistId,
      selectedArtistId,
      isAdminOpen,
      isOnboardingOpen,
      isAuthOpen,
      offlineMode,
      currentSong,
      isPlaying,
      currentTime,
      duration,
      queue,
      queueIndex,
      shuffle,
      repeat,
      volume,
      songs,
      artists,
      albums,
      playlists,
      user,
      likedSongIds,
      downloadedSongIds,
      searchHistory,
      listeningHistory,
      playSong,
      togglePlayPause,
      playNext,
      playPrevious,
      seekTo,
      setVolume,
      toggleShuffle,
      toggleRepeat,
      setSleepTimer,
      toggleLikeSong,
      toggleDownloadSong,
      createPlaylist,
      addSongToPlaylist,
      removeSongFromPlaylist,
      deletePlaylist,
      updateUserSettings,
      updateUserProfile,
      addSearchHistory,
      clearSearchHistory,
      removeFromQueue,
      reorderQueue,
      addToQueueNext,
      addSongAdmin,
      editSongAdmin,
      deleteSongAdmin
    ]
  );

  return <MusicContext.Provider value={contextValue}>{children}</MusicContext.Provider>;
};

export const useMusic = () => {
  const context = useContext(MusicContext);
  if (!context) {
    throw new Error('useMusic must be used within a MusicProvider');
  }
  return context;
};
