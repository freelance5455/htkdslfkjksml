import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { Song, Playlist, EqualizerPreset, PlaybackMode, VibeMode } from '../types/music';
import { INITIAL_SONGS, INITIAL_PLAYLISTS, EQUALIZER_PRESETS } from '../data/musicCatalog';
import { audioEngine } from '../services/audioEngine';
import {
  getNextVibeTrack,
  generateVibeRadioQueue,
  fetchLiveVibeTracksFromYouTube,
  detectSongVibeCluster
} from '../services/vibeRadioService';

interface MusicContextType {
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  queue: Song[];
  queueIndex: number;
  playbackMode: PlaybackMode;
  isShuffle: boolean;
  volume: number;
  playbackRate: number;
  activePreset: EqualizerPreset;
  customBands: [number, number, number, number, number];
  bassBoost: number;
  reverb: number;
  likedSongIds: Set<string>;
  downloadedSongIds: Set<string>;
  historySongIds: string[];
  playlists: Playlist[];
  isFullScreenPlayerOpen: boolean;
  playerTab: 'upNext' | 'lyrics' | 'related' | 'equalizer';
  playerMode: 'song' | 'video';
  sleepTimerMinutes: number | null;
  sleepTimerRemaining: number | null;
  isSameTypeMode: boolean;
  isAutoplayOn: boolean;
  vibeMode: VibeMode;

  // Actions
  playSong: (song: Song, newQueue?: Song[]) => void;
  playYouTubeTrack: (videoIdOrUrl: string, customTitle?: string, customArtist?: string) => void;
  togglePlayPause: () => void;
  stopMusic: () => void;
  seek: (seconds: number) => void;
  nextTrack: () => void;
  prevTrack: () => void;
  toggleLike: (songId: string) => void;
  toggleDownload: (songId: string) => void;
  toggleShuffle: () => void;
  cyclePlaybackMode: () => void;
  setPlaybackModeDirect: (mode: PlaybackMode) => void;
  toggleSameTypeMode: () => void;
  toggleAutoplay: () => void;
  setVibeMode: (mode: VibeMode) => void;
  startVibeRadio: (song: Song, mode?: VibeMode) => void;
  setVolume: (val: number) => void;
  volumeUp: () => void;
  volumeDown: () => void;
  setPlaybackRate: (rate: number) => void;
  setEqualizerPreset: (preset: EqualizerPreset) => void;
  setBandGain: (bandIndex: number, gainDb: number) => void;
  setBassBoost: (val: number) => void;
  setReverb: (val: number) => void;
  createPlaylist: (title: string, description?: string) => Playlist;
  addSongToPlaylist: (playlistId: string, song: Song) => void;
  removeSongFromPlaylist: (playlistId: string, songId: string) => void;
  setSleepTimer: (minutes: number | null) => void;
  setIsFullScreenPlayerOpen: (open: boolean) => void;
  setPlayerTab: (tab: 'upNext' | 'lyrics' | 'related' | 'equalizer') => void;
  setPlayerMode: (mode: 'song' | 'video') => void;
  addToQueue: (song: Song) => void;
  removeFromQueue: (index: number) => void;
  clearQueue: () => void;
}

const MusicContext = createContext<MusicContextType | null>(null);

const STORAGE_KEY_LIKED = 'ytm_liked_songs';
const STORAGE_KEY_DOWNLOADED = 'ytm_downloaded_songs';
const STORAGE_KEY_PLAYLISTS = 'ytm_user_playlists';
const STORAGE_KEY_HISTORY = 'ytm_history_songs';
const STORAGE_KEY_SAME_TYPE = 'ytm_same_type_mode';
const STORAGE_KEY_VIBE_MODE = 'ytm_vibe_mode';

export const MusicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentSong, setCurrentSong] = useState<Song | null>(() => INITIAL_SONGS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(() => INITIAL_SONGS[0].duration);
  const [queue, setQueue] = useState<Song[]>(() => INITIAL_SONGS);
  const [queueIndex, setQueueIndex] = useState(0);
  const [playbackMode, setPlaybackMode] = useState<PlaybackMode>('repeat-all');
  const [isShuffle, setIsShuffle] = useState(false);
  const [volume, setVolumeState] = useState(0.9);
  const [playbackRate, setPlaybackRateState] = useState(1.0);
  const [activePreset, setActivePresetState] = useState<EqualizerPreset>(EQUALIZER_PRESETS[0]);
  const [customBands, setCustomBands] = useState<[number, number, number, number, number]>([0, 0, 0, 0, 0]);
  const [bassBoost, setBassBoostState] = useState(0);
  const [reverb, setReverbState] = useState(0);

  // "Same wave, different songs" state
  const [isSameTypeMode, setIsSameTypeMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SAME_TYPE);
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  const [vibeMode, setVibeModeState] = useState<VibeMode>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_VIBE_MODE);
      return (saved as VibeMode) || 'same-wave';
    } catch {
      return 'same-wave';
    }
  });

  const [isAutoplayOn, setIsAutoplayOn] = useState<boolean>(true);

  const [likedSongIds, setLikedSongIds] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_LIKED);
      return saved ? new Set(JSON.parse(saved)) : new Set(['yt-1', 'yt-2']);
    } catch {
      return new Set(['yt-1', 'yt-2']);
    }
  });

  const [downloadedSongIds, setDownloadedSongIds] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DOWNLOADED);
      return saved ? new Set(JSON.parse(saved)) : new Set(['yt-1']);
    } catch {
      return new Set(['yt-1']);
    }
  });

  const [historySongIds, setHistorySongIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_HISTORY);
      return saved ? JSON.parse(saved) : ['yt-1'];
    } catch {
      return ['yt-1'];
    }
  });

  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PLAYLISTS);
      return saved ? JSON.parse(saved) : INITIAL_PLAYLISTS;
    } catch {
      return INITIAL_PLAYLISTS;
    }
  });

  const [isFullScreenPlayerOpen, setIsFullScreenPlayerOpen] = useState(false);
  const [playerTab, setPlayerTab] = useState<'upNext' | 'lyrics' | 'related' | 'equalizer'>('upNext');
  const [playerMode, setPlayerMode] = useState<'song' | 'video'>('song');

  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepTimerRemaining, setSleepTimerRemaining] = useState<number | null>(null);
  const sleepTimerIntervalRef = useRef<number | null>(null);

  // Toggle same-type continuous play mode
  const toggleSameTypeMode = useCallback(() => {
    setIsSameTypeMode((prev) => {
      const next = !prev;
      localStorage.setItem(STORAGE_KEY_SAME_TYPE, JSON.stringify(next));
      return next;
    });
  }, []);

  const setVibeMode = useCallback((mode: VibeMode) => {
    setVibeModeState(mode);
    localStorage.setItem(STORAGE_KEY_VIBE_MODE, mode);
    // When vibe tuner is adjusted, regenerate future queue with the new wave preference!
    if (currentSong) {
      setQueue((prevQueue) => {
        const playedSoFar = prevQueue.slice(0, queueIndex + 1);
        const tunedTail = generateVibeRadioQueue(currentSong, mode, INITIAL_SONGS).slice(1);
        return [...playedSoFar, ...tunedTail];
      });
    }
  }, [currentSong, queueIndex]);

  const toggleAutoplay = useCallback(() => {
    setIsAutoplayOn((prev) => !prev);
  }, []);

  // Sleep timer ticker
  useEffect(() => {
    if (sleepTimerMinutes !== null && sleepTimerMinutes > 0) {
      setSleepTimerRemaining(sleepTimerMinutes * 60);

      if (sleepTimerIntervalRef.current) clearInterval(sleepTimerIntervalRef.current);

      sleepTimerIntervalRef.current = window.setInterval(() => {
        setSleepTimerRemaining((prev) => {
          if (prev === null || prev <= 1) {
            audioEngine.pause();
            setIsPlaying(false);
            if (sleepTimerIntervalRef.current) clearInterval(sleepTimerIntervalRef.current);
            setSleepTimerMinutes(null);
            return null;
          }
          return prev - 1;
        });
      }, 1000);

      return () => {
        if (sleepTimerIntervalRef.current) clearInterval(sleepTimerIntervalRef.current);
      };
    } else {
      setSleepTimerRemaining(null);
      if (sleepTimerIntervalRef.current) clearInterval(sleepTimerIntervalRef.current);
    }
  }, [sleepTimerMinutes]);

  // Persist storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_LIKED, JSON.stringify(Array.from(likedSongIds)));
  }, [likedSongIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_DOWNLOADED, JSON.stringify(Array.from(downloadedSongIds)));
  }, [downloadedSongIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PLAYLISTS, JSON.stringify(playlists));
  }, [playlists]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(historySongIds));
  }, [historySongIds]);

  const playSong = useCallback((song: Song, newQueue?: Song[]) => {
    setCurrentSong(song);
    setDuration(song.duration);
    setCurrentTime(0);

    if (newQueue && newQueue.length > 0) {
      setQueue(newQueue);
      const idx = newQueue.findIndex((s) => s.id === song.id);
      setQueueIndex(idx !== -1 ? idx : 0);
    } else {
      const idx = queue.findIndex((s) => s.id === song.id);
      if (idx !== -1) {
        setQueueIndex(idx);
      } else {
        // If playing a standalone song with Same Vibe active, auto-generate a same wave queue
        if (isSameTypeMode) {
          const generatedQueue = generateVibeRadioQueue(song, vibeMode, INITIAL_SONGS);
          setQueue(generatedQueue);
          setQueueIndex(0);
        } else {
          setQueue((prev) => [song, ...prev]);
          setQueueIndex(0);
        }
      }
    }

    setHistorySongIds((prev) => [song.id, ...prev.filter((id) => id !== song.id)].slice(0, 50));
    audioEngine.playSong(song);
  }, [queue, isSameTypeMode, vibeMode]);

  // Start dedicated Vibe Radio for any song
  const startVibeRadio = useCallback((song: Song, mode: VibeMode = 'same-wave') => {
    setVibeModeState(mode);
    const radioQueue = generateVibeRadioQueue(song, mode, INITIAL_SONGS);
    playSong(song, radioQueue);
  }, [playSong]);

  const playYouTubeTrack = useCallback((videoIdOrUrl: string, customTitle?: string, customArtist?: string) => {
    let videoId = videoIdOrUrl.trim();
    if (videoId.includes('youtube.com/watch?v=')) {
      const match = videoId.match(/v=([a-zA-Z0-9_-]{11})/);
      if (match) videoId = match[1];
    } else if (videoId.includes('youtu.be/')) {
      const match = videoId.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/);
      if (match) videoId = match[1];
    }

    const title = customTitle || `YouTube Track (${videoId.slice(0, 8)})`;
    const artist = customArtist || 'YouTube Music';

    const newSong: Song = {
      id: `custom-yt-${Date.now()}`,
      title,
      artist,
      album: 'YouTube Music Stream',
      duration: 210,
      youtubeId: videoId,
      coverUrl: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
      audioUrl: '',
      genre: 'YouTube Music',
      mood: 'Energize',
      bpm: 110,
      plays: 100000,
      year: new Date().getFullYear(),
      lyrics: [{ time: 0, text: `♪ Playing ${title} directly from YouTube ♪` }]
    };

    const initialVibeQueue = generateVibeRadioQueue(newSong, vibeMode, INITIAL_SONGS);
    playSong(newSong, initialVibeQueue);
  }, [playSong, vibeMode]);

  const togglePlayPause = useCallback(() => {
    if (isPlaying) {
      audioEngine.pause();
    } else {
      if (!currentSong && queue.length > 0) {
        playSong(queue[0]);
      } else {
        audioEngine.resume();
      }
    }
  }, [isPlaying, currentSong, queue, playSong]);

  const stopMusic = useCallback(() => {
    audioEngine.stop();
    setIsPlaying(false);
    setCurrentTime(0);
  }, []);

  const seek = useCallback((seconds: number) => {
    setCurrentTime(seconds);
    audioEngine.seek(seconds);
  }, []);

  // Next Track with "Same Wave, Different Songs" intelligence
  const nextTrack = useCallback(() => {
    if (queue.length === 0) return;

    if (isShuffle) {
      const nextIdx = Math.floor(Math.random() * queue.length);
      setQueueIndex(nextIdx);
      playSong(queue[nextIdx]);
      return;
    }

    if (queueIndex < queue.length - 1) {
      const nextIdx = queueIndex + 1;
      setQueueIndex(nextIdx);
      playSong(queue[nextIdx]);
    } else if (isSameTypeMode && currentSong) {
      // Pick next song using the "Same Vibe, Different Artists" algorithm!
      const nextVibeSong = getNextVibeTrack(currentSong, vibeMode, historySongIds, INITIAL_SONGS);
      setQueue((prev) => [...prev, nextVibeSong]);
      setQueueIndex((prev) => prev + 1);
      playSong(nextVibeSong);

      // Background fetch of fresh related YouTube tracks
      fetchLiveVibeTracksFromYouTube(currentSong).then((extraYtTracks) => {
        if (extraYtTracks && extraYtTracks.length > 0) {
          setQueue((prev) => [...prev, ...extraYtTracks]);
        }
      });
    } else if (playbackMode === 'repeat-all') {
      setQueueIndex(0);
      playSong(queue[0]);
    }
  }, [queue, queueIndex, isShuffle, isSameTypeMode, currentSong, vibeMode, historySongIds, playbackMode, playSong]);

  // Previous Track logic
  const prevTrack = useCallback(() => {
    if (currentTime > 4) {
      seek(0);
      return;
    }

    if (queue.length === 0) return;

    if (queueIndex > 0) {
      const prevIdx = queueIndex - 1;
      setQueueIndex(prevIdx);
      playSong(queue[prevIdx]);
    } else if (playbackMode === 'repeat-all') {
      const lastIdx = queue.length - 1;
      setQueueIndex(lastIdx);
      playSong(queue[lastIdx]);
    } else {
      seek(0);
    }
  }, [currentTime, queue, queueIndex, playbackMode, playSong, seek]);

  // Track Ended event - Autoplaying next song & Same Wave Loop
  const handleTrackEnded = useCallback(() => {
    if (playbackMode === 'repeat-one' && currentSong) {
      // Loop this exact one song!
      seek(0);
      audioEngine.playSong(currentSong);
    } else if (queueIndex < queue.length - 1) {
      nextTrack();
    } else if (isSameTypeMode && currentSong) {
      // Autoplay: select a track with the same wave, but different song/artist!
      const nextSimilarSong = getNextVibeTrack(currentSong, vibeMode, historySongIds, INITIAL_SONGS);
      setQueue((prev) => [...prev, nextSimilarSong]);
      setQueueIndex(queue.length);
      playSong(nextSimilarSong);
    } else {
      // Autoplay next in queue
      nextTrack();
    }
  }, [playbackMode, currentSong, queueIndex, queue.length, isSameTypeMode, vibeMode, historySongIds, playSong, seek, nextTrack]);

  // Sync Audio Engine callbacks
  useEffect(() => {
    audioEngine.onTimeUpdate((curr, dur) => {
      setCurrentTime(curr);
      if (dur > 0) setDuration(dur);
    });

    audioEngine.onPlay(() => setIsPlaying(true));
    audioEngine.onPause(() => setIsPlaying(false));

    audioEngine.onEnded(() => {
      handleTrackEnded();
    });
  }, [handleTrackEnded]);

  // Sync MediaSession hardware/lockscreen buttons
  useEffect(() => {
    audioEngine.setMediaSessionNavCallbacks(
      () => prevTrack(),
      () => nextTrack()
    );
  }, [prevTrack, nextTrack]);

  const toggleLike = useCallback((songId: string) => {
    setLikedSongIds((prev) => {
      const next = new Set(prev);
      if (next.has(songId)) next.delete(songId);
      else next.add(songId);
      return next;
    });
  }, []);

  const toggleDownload = useCallback((songId: string) => {
    setDownloadedSongIds((prev) => {
      const next = new Set(prev);
      if (next.has(songId)) next.delete(songId);
      else next.add(songId);
      return next;
    });
  }, []);

  const toggleShuffle = useCallback(() => {
    setIsShuffle((prev) => !prev);
  }, []);

  const cyclePlaybackMode = useCallback(() => {
    setPlaybackMode((prev) => {
      if (prev === 'repeat-all') return 'repeat-one';
      if (prev === 'repeat-one') return 'repeat-off';
      return 'repeat-all';
    });
  }, []);

  const setPlaybackModeDirect = useCallback((mode: PlaybackMode) => {
    setPlaybackMode(mode);
  }, []);

  const setVolume = useCallback((val: number) => {
    const clamped = Math.max(0, Math.min(1, val));
    setVolumeState(clamped);
    audioEngine.setVolume(clamped);
  }, []);

  // Sound Up button (+10%)
  const volumeUp = useCallback(() => {
    setVolumeState((prev) => {
      const next = Math.min(1.0, parseFloat((prev + 0.1).toFixed(2)));
      audioEngine.setVolume(next);
      return next;
    });
  }, []);

  // Sound Down button (-10%)
  const volumeDown = useCallback(() => {
    setVolumeState((prev) => {
      const next = Math.max(0.0, parseFloat((prev - 0.1).toFixed(2)));
      audioEngine.setVolume(next);
      return next;
    });
  }, []);

  const setPlaybackRate = useCallback((rate: number) => {
    setPlaybackRateState(rate);
    audioEngine.setPlaybackRate(rate);
  }, []);

  const setEqualizerPreset = useCallback((preset: EqualizerPreset) => {
    setActivePresetState(preset);
    setCustomBands([...preset.bands]);
    if (preset.bassBoost !== undefined) setBassBoostState(preset.bassBoost);
    if (preset.reverb !== undefined) setReverbState(preset.reverb);
    audioEngine.applyEqualizerPreset(preset);
  }, []);

  const setBandGain = useCallback((bandIndex: number, gainDb: number) => {
    setCustomBands((prev) => {
      const next: [number, number, number, number, number] = [...prev];
      next[bandIndex] = gainDb;
      return next;
    });
    audioEngine.setCustomBand(bandIndex, gainDb);
  }, []);

  const setBassBoost = useCallback((val: number) => {
    setBassBoostState(val);
    const bassGain = (val / 10) * 10;
    setBandGain(0, bassGain);
  }, [setBandGain]);

  const setReverb = useCallback((val: number) => {
    setReverbState(val);
  }, []);

  const createPlaylist = useCallback((title: string, description = ''): Playlist => {
    const newPl: Playlist = {
      id: `custom-pl-${Date.now()}`,
      title,
      description: description || 'Custom playlist created on YouTube Music',
      coverUrl: 'https://img.youtube.com/vi/BddP6PYo2gs/hqdefault.jpg',
      songs: [],
      isCustom: true,
      createdAt: new Date().toLocaleDateString()
    };
    setPlaylists((prev) => [newPl, ...prev]);
    return newPl;
  }, []);

  const addSongToPlaylist = useCallback((playlistId: string, song: Song) => {
    setPlaylists((prev) =>
      prev.map((pl) => {
        if (pl.id !== playlistId) return pl;
        if (pl.songs.some((s) => s.id === song.id)) return pl;
        return { ...pl, songs: [...pl.songs, song] };
      })
    );
  }, []);

  const removeSongFromPlaylist = useCallback((playlistId: string, songId: string) => {
    setPlaylists((prev) =>
      prev.map((pl) => {
        if (pl.id !== playlistId) return pl;
        return { ...pl, songs: pl.songs.filter((s) => s.id !== songId) };
      })
    );
  }, []);

  const setSleepTimer = useCallback((minutes: number | null) => {
    setSleepTimerMinutes(minutes);
  }, []);

  const addToQueue = useCallback((song: Song) => {
    setQueue((prev) => [...prev, song]);
  }, []);

  const removeFromQueue = useCallback((index: number) => {
    setQueue((prev) => prev.filter((_, idx) => idx !== index));
  }, []);

  const clearQueue = useCallback(() => {
    if (currentSong) {
      setQueue([currentSong]);
      setQueueIndex(0);
    } else {
      setQueue([]);
      setQueueIndex(0);
    }
  }, [currentSong]);

  return (
    <MusicContext.Provider
      value={{
        currentSong,
        isPlaying,
        currentTime,
        duration,
        queue,
        queueIndex,
        playbackMode,
        isShuffle,
        volume,
        playbackRate,
        activePreset,
        customBands,
        bassBoost,
        reverb,
        likedSongIds,
        downloadedSongIds,
        historySongIds,
        playlists,
        isFullScreenPlayerOpen,
        playerTab,
        playerMode,
        sleepTimerMinutes,
        sleepTimerRemaining,
        isSameTypeMode,
        isAutoplayOn,
        vibeMode,
        playSong,
        playYouTubeTrack,
        togglePlayPause,
        stopMusic,
        seek,
        nextTrack,
        prevTrack,
        toggleLike,
        toggleDownload,
        toggleShuffle,
        cyclePlaybackMode,
        setPlaybackModeDirect,
        toggleSameTypeMode,
        toggleAutoplay,
        setVibeMode,
        startVibeRadio,
        setVolume,
        volumeUp,
        volumeDown,
        setPlaybackRate,
        setEqualizerPreset,
        setBandGain,
        setBassBoost,
        setReverb,
        createPlaylist,
        addSongToPlaylist,
        removeSongFromPlaylist,
        setSleepTimer,
        setIsFullScreenPlayerOpen,
        setPlayerTab,
        setPlayerMode,
        addToQueue,
        removeFromQueue,
        clearQueue,
      }}
    >
      {children}
    </MusicContext.Provider>
  );
};

export const useMusic = () => {
  const ctx = useContext(MusicContext);
  if (!ctx) throw new Error('useMusic must be used within MusicProvider');
  return ctx;
};
