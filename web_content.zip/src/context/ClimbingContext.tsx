import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  ClimbEntry,
  ClimbingClub,
  ChecklistItem,
  CandidateProfile,
  NICASLevelNumber,
  CriterionStatus,
  ClimbingStyle,
  ClimbOutcome,
  WallAngle,
  TrainingNote
} from '../types/climbing';
import {
  INITIAL_CLUBS,
  INITIAL_PROFILE,
  INITIAL_CHECKLIST,
  INITIAL_CLIMBS,
  INITIAL_TRAINING_NOTES
} from '../data/initialData';

interface ClimbingContextType {
  climbs: ClimbEntry[];
  clubs: ClimbingClub[];
  checklist: ChecklistItem[];
  profile: CandidateProfile;
  trainingNotes: TrainingNote[];
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  setTheme: (theme: 'light' | 'dark') => void;
  // Climb methods
  addClimb: (climb: Omit<ClimbEntry, 'id' | 'createdAt'>) => ClimbEntry;
  updateClimb: (id: string, climb: Partial<ClimbEntry>) => void;
  deleteClimb: (id: string) => void;
  // Club methods
  addClub: (club: Omit<ClimbingClub, 'id'>) => ClimbingClub;
  updateClub: (id: string, club: Partial<ClimbingClub>) => void;
  deleteClub: (id: string) => boolean;
  getClubById: (id: string) => ClimbingClub | undefined;
  // Checklist methods
  updateChecklistItem: (id: string, updates: Partial<ChecklistItem>) => void;
  toggleChecklistItemStatus: (id: string) => void;
  signOffAllInLevel: (level: NICASLevelNumber, instructorName: string, signOffDate: string) => void;
  // Profile methods
  updateProfile: (profile: Partial<CandidateProfile>) => void;
  // Training Notes methods
  addTrainingNote: (note: Omit<TrainingNote, 'id' | 'createdAt'>) => TrainingNote;
  updateTrainingNote: (id: string, updates: Partial<TrainingNote>) => void;
  deleteTrainingNote: (id: string) => void;
  toggleTrainingNote: (id: string) => void;
  // Backup / Data management
  exportToCSV: () => string;
  downloadCSV: () => void;
  exportToJSON: () => string;
  downloadJSON: () => void;
  importFromJSON: (jsonString: string) => { success: boolean; message: string };
  importFromCSV: (csvString: string) => { success: boolean; message: string; count?: number };
  resetToDefaultData: () => void;
}

const STORAGE_KEYS = {
  CLIMBS: 'nicas_climbs_v2',
  CLUBS: 'nicas_clubs_v2',
  CHECKLIST: 'nicas_checklist_v2',
  PROFILE: 'nicas_profile_v2',
  NOTES: 'nicas_notes_v2',
  THEME: 'nicas_theme_v2'
};

const ClimbingContext = createContext<ClimbingContextType | undefined>(undefined);

export const ClimbingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<'light' | 'dark'>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.THEME);
      if (stored === 'dark' || stored === 'light') return stored;
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  });

  const [climbs, setClimbs] = useState<ClimbEntry[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CLIMBS);
      return stored ? JSON.parse(stored) : INITIAL_CLIMBS;
    } catch {
      return INITIAL_CLIMBS;
    }
  });

  const [clubs, setClubs] = useState<ClimbingClub[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CLUBS);
      return stored ? JSON.parse(stored) : INITIAL_CLUBS;
    } catch {
      return INITIAL_CLUBS;
    }
  });

  const [checklist, setChecklist] = useState<ChecklistItem[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CHECKLIST);
      return stored ? JSON.parse(stored) : INITIAL_CHECKLIST;
    } catch {
      return INITIAL_CHECKLIST;
    }
  });

  const [profile, setProfile] = useState<CandidateProfile>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return stored ? JSON.parse(stored) : INITIAL_PROFILE;
    } catch {
      return INITIAL_PROFILE;
    }
  });

  const [trainingNotes, setTrainingNotes] = useState<TrainingNote[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.NOTES);
      return stored ? JSON.parse(stored) : INITIAL_TRAINING_NOTES;
    } catch {
      return INITIAL_TRAINING_NOTES;
    }
  });

  // Apply dark mode class to html element
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.THEME, theme);
      if (theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    } catch (e) {
      console.error('Failed to update theme', e);
    }
  }, [theme]);

  const toggleTheme = () => {
    setThemeState(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const setTheme = (t: 'light' | 'dark') => {
    setThemeState(t);
  };

  // LocalStorage sync
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CLIMBS, JSON.stringify(climbs));
    } catch (e) {
      console.error('Failed to save climbs to localStorage', e);
    }
  }, [climbs]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CLUBS, JSON.stringify(clubs));
    } catch (e) {
      console.error('Failed to save clubs to localStorage', e);
    }
  }, [clubs]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CHECKLIST, JSON.stringify(checklist));
    } catch (e) {
      console.error('Failed to save checklist to localStorage', e);
    }
  }, [checklist]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to save profile to localStorage', e);
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(trainingNotes));
    } catch (e) {
      console.error('Failed to save notes to localStorage', e);
    }
  }, [trainingNotes]);

  // Climbs CRUD
  const addClimb = (climbData: Omit<ClimbEntry, 'id' | 'createdAt'>): ClimbEntry => {
    const newClimb: ClimbEntry = {
      ...climbData,
      id: `climb-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: Date.now()
    };
    setClimbs(prev => [newClimb, ...prev]);
    return newClimb;
  };

  const updateClimb = (id: string, updates: Partial<ClimbEntry>) => {
    setClimbs(prev => prev.map(c => (c.id === id ? { ...c, ...updates } : c)));
  };

  const deleteClimb = (id: string) => {
    setClimbs(prev => prev.filter(c => c.id !== id));
  };

  // Clubs CRUD
  const addClub = (clubData: Omit<ClimbingClub, 'id'>): ClimbingClub => {
    const newClub: ClimbingClub = {
      ...clubData,
      id: `club-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
    };
    setClubs(prev => [...prev, newClub]);
    return newClub;
  };

  const updateClub = (id: string, updates: Partial<ClimbingClub>) => {
    setClubs(prev => prev.map(c => (c.id === id ? { ...c, ...updates } : c)));
  };

  const deleteClub = (id: string): boolean => {
    const climbsUsingClub = climbs.some(c => c.clubId === id);
    if (climbsUsingClub) {
      return false;
    }
    setClubs(prev => prev.filter(c => c.id !== id));
    return true;
  };

  const getClubById = (id: string) => {
    return clubs.find(c => c.id === id);
  };

  // Checklist methods
  const updateChecklistItem = (id: string, updates: Partial<ChecklistItem>) => {
    setChecklist(prev =>
      prev.map(item => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const toggleChecklistItemStatus = (id: string) => {
    setChecklist(prev =>
      prev.map(item => {
        if (item.id !== id) return item;
        const nextStatus: CriterionStatus =
          item.status === 'Completed'
            ? 'Not Started'
            : item.status === 'In Progress'
            ? 'Completed'
            : 'In Progress';
        return {
          ...item,
          status: nextStatus,
          verified: nextStatus === 'Completed',
          signOffDate: nextStatus === 'Completed' ? (item.signOffDate || new Date().toISOString().split('T')[0]) : undefined
        };
      })
    );
  };

  const signOffAllInLevel = (level: NICASLevelNumber, instructorName: string, signOffDate: string) => {
    setChecklist(prev =>
      prev.map(item => {
        if (item.level !== level) return item;
        return {
          ...item,
          status: 'Completed',
          verified: true,
          instructorName: instructorName || item.instructorName || profile.leadInstructor,
          signOffDate: signOffDate || new Date().toISOString().split('T')[0]
        };
      })
    );
  };

  // Profile methods
  const updateProfile = (updates: Partial<CandidateProfile>) => {
    setProfile(prev => ({ ...prev, ...updates }));
  };

  // Training Notes methods
  const addTrainingNote = (noteData: Omit<TrainingNote, 'id' | 'createdAt'>): TrainingNote => {
    const newNote: TrainingNote = {
      ...noteData,
      id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now()
    };
    setTrainingNotes(prev => [newNote, ...prev]);
    return newNote;
  };

  const updateTrainingNote = (id: string, updates: Partial<TrainingNote>) => {
    setTrainingNotes(prev => prev.map(n => (n.id === id ? { ...n, ...updates } : n)));
  };

  const deleteTrainingNote = (id: string) => {
    setTrainingNotes(prev => prev.filter(n => n.id !== id));
  };

  const toggleTrainingNote = (id: string) => {
    setTrainingNotes(prev => prev.map(n => (n.id === id ? { ...n, isCompleted: !n.isCompleted } : n)));
  };

  // Export to CSV
  const exportToCSV = (): string => {
    const headers = [
      'Date',
      'Route Name / Problem',
      'Style',
      'Grade',
      'Wall Angle',
      'Outcome',
      'Climbing Centre',
      'Attempts',
      'Notes'
    ];

    const rows = climbs.map(climb => {
      const club = getClubById(climb.clubId);
      const clubName = club ? club.name : climb.clubId;
      const cleanNotes = (climb.notes || '').replace(/"/g, '""');
      const cleanRoute = (climb.routeName || '').replace(/"/g, '""');
      return [
        climb.date,
        `"${cleanRoute}"`,
        climb.style,
        climb.grade,
        climb.wallAngle,
        climb.outcome,
        `"${clubName}"`,
        climb.attemptsCount ?? 1,
        `"${cleanNotes}"`
      ].join(',');
    });

    return [headers.join(','), ...rows].join('\n');
  };

  const downloadCSV = () => {
    const csvContent = exportToCSV();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `NICAS_Climbing_Log_${profile.candidateNumber || 'export'}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Export to JSON (full backup)
  const exportToJSON = (): string => {
    const backup = {
      version: '2.0',
      exportedAt: new Date().toISOString(),
      profile,
      clubs,
      checklist,
      climbs,
      trainingNotes
    };
    return JSON.stringify(backup, null, 2);
  };

  const downloadJSON = () => {
    const jsonContent = exportToJSON();
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `NICAS_Complete_Backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Import JSON
  const importFromJSON = (jsonString: string): { success: boolean; message: string } => {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed || typeof parsed !== 'object') {
        return { success: false, message: 'Invalid JSON format.' };
      }
      if (Array.isArray(parsed.climbs)) {
        setClimbs(parsed.climbs);
      }
      if (Array.isArray(parsed.clubs)) {
        setClubs(parsed.clubs);
      }
      if (Array.isArray(parsed.checklist)) {
        setChecklist(parsed.checklist);
      }
      if (Array.isArray(parsed.trainingNotes)) {
        setTrainingNotes(parsed.trainingNotes);
      }
      if (parsed.profile && typeof parsed.profile === 'object') {
        setProfile(parsed.profile);
      }
      return { success: true, message: 'Logbook data restored successfully!' };
    } catch (err: any) {
      return { success: false, message: `Failed to parse backup JSON: ${err.message}` };
    }
  };

  // Import CSV
  const importFromCSV = (csvString: string): { success: boolean; message: string; count?: number } => {
    try {
      const lines = csvString.trim().split(/\r\n|\n/);
      if (lines.length < 2) {
        return { success: false, message: 'CSV file is empty or missing data rows.' };
      }

      const importedClimbs: ClimbEntry[] = [];
      const parseCSVLine = (line: string): string[] => {
        const result: string[] = [];
        let current = '';
        let inQuotes = false;
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"' && line[i + 1] === '"') {
            current += '"';
            i++;
          } else if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }
        result.push(current.trim());
        return result;
      };

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const cols = parseCSVLine(line);
        if (cols.length < 4) continue;

        const date = cols[0] || new Date().toISOString().split('T')[0];
        const routeName = cols[1] || 'Imported Route';
        const rawStyle = cols[2];
        const style: ClimbingStyle = ['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'].includes(rawStyle)
          ? (rawStyle as ClimbingStyle)
          : 'Top Rope';
        const grade = cols[3] || '6a';
        const rawAngle = cols[4];
        const wallAngle: WallAngle = ['Slab', 'Vertical', 'Overhang', 'Roof'].includes(rawAngle)
          ? (rawAngle as WallAngle)
          : 'Vertical';
        const rawOutcome = cols[5];
        const outcome: ClimbOutcome = ['Onsite', 'Flash', 'Redpoint', 'Attempt'].includes(rawOutcome)
          ? (rawOutcome as ClimbOutcome)
          : 'Redpoint';
        const rawClub = cols[6] || 'The Castle Climbing Centre';
        const attempts = parseInt(cols[7], 10) || 1;
        const notes = cols[8] || '';

        let matchedClub = clubs.find(
          c => c.name.toLowerCase() === rawClub.toLowerCase() || c.id === rawClub
        );
        let clubId = matchedClub ? matchedClub.id : clubs[0]?.id || 'club-castle-london';

        importedClimbs.push({
          id: `climb-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 6)}`,
          date,
          routeName,
          style,
          grade,
          wallAngle,
          outcome,
          clubId,
          notes,
          attemptsCount: attempts,
          createdAt: Date.now() - i * 1000
        });
      }

      if (importedClimbs.length === 0) {
        return { success: false, message: 'Could not extract valid climb entries from CSV.' };
      }

      setClimbs(prev => [...importedClimbs, ...prev]);
      return {
        success: true,
        message: `Successfully imported ${importedClimbs.length} climbs into your logbook!`,
        count: importedClimbs.length
      };
    } catch (err: any) {
      return { success: false, message: `Failed to import CSV: ${err.message}` };
    }
  };

  const resetToDefaultData = () => {
    setClimbs(INITIAL_CLIMBS);
    setClubs(INITIAL_CLUBS);
    setChecklist(INITIAL_CHECKLIST);
    setProfile(INITIAL_PROFILE);
    setTrainingNotes(INITIAL_TRAINING_NOTES);
    localStorage.removeItem(STORAGE_KEYS.CLIMBS);
    localStorage.removeItem(STORAGE_KEYS.CLUBS);
    localStorage.removeItem(STORAGE_KEYS.CHECKLIST);
    localStorage.removeItem(STORAGE_KEYS.PROFILE);
    localStorage.removeItem(STORAGE_KEYS.NOTES);
  };

  return (
    <ClimbingContext.Provider
      value={{
        climbs,
        clubs,
        checklist,
        profile,
        trainingNotes,
        theme,
        toggleTheme,
        setTheme,
        addClimb,
        updateClimb,
        deleteClimb,
        addClub,
        updateClub,
        deleteClub,
        getClubById,
        updateChecklistItem,
        toggleChecklistItemStatus,
        signOffAllInLevel,
        updateProfile,
        addTrainingNote,
        updateTrainingNote,
        deleteTrainingNote,
        toggleTrainingNote,
        exportToCSV,
        downloadCSV,
        exportToJSON,
        downloadJSON,
        importFromJSON,
        importFromCSV,
        resetToDefaultData
      }}
    >
      {children}
    </ClimbingContext.Provider>
  );
};

export const useClimbing = () => {
  const context = useContext(ClimbingContext);
  if (!context) {
    throw new Error('useClimbing must be used within a ClimbingProvider');
  }
  return context;
};
