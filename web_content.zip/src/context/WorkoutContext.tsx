import React, { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import {
  Achievement,
  CustomRoutine,
  DailyHabit,
  DifficultyLevel,
  Exercise,
  HabitIconName,
  PersonalRecord,
  SetType,
  Skill,
  UserProfile,
  Workout,
  WorkoutExercise,
  WorkoutSet
} from '../types';
import { INITIAL_EXERCISES } from '../data/initialExercises';
import { INITIAL_SKILLS } from '../data/skillsData';
import { PRESET_ROUTINES } from '../data/presetRoutines';
import {
  INITIAL_USER,
  INITIAL_PRS,
  INITIAL_ACHIEVEMENTS,
  INITIAL_WORKOUT_HISTORY,
  INITIAL_DAILY_HABITS
} from '../data/initialData';
import {
  playCountdownTick,
  playTimerFinishSound,
  playSetCompleteSound,
  playCelebrationSound,
  playPopSound,
  playConfettiPopSound,
  triggerHaptic,
  triggerTimerZeroHaptic
} from '../utils/audio';

export interface ActiveWorkoutSession {
  id: string;
  name: string;
  startTime: number; // timestamp
  elapsedSeconds: number;
  exercises: WorkoutExercise[];
  isPaused: boolean;
  notes?: string;
}

export interface WorkoutSummaryResult {
  workout: Workout;
  newPRs: PersonalRecord[];
  unlockedAchievements: Achievement[];
  newDifficultyTier?: DifficultyLevel | null;
}

interface WorkoutContextType {
  user: UserProfile;
  updateUser: (updates: Partial<UserProfile>) => void;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  exercises: Exercise[];
  skills: Skill[];
  updateSkillLevel: (skillId: string, level: number) => void;
  logSkillHold: (skillId: string, holdSec: number) => { isNewPr: boolean; leveledUp: boolean };
  customRoutines: CustomRoutine[];
  saveCustomRoutine: (routine: CustomRoutine) => void;
  overloadRoutine: (routineId: string, mode: 'reps' | 'sets' | 'weight') => void;
  deleteCustomRoutine: (id: string) => void;
  duplicateCustomRoutine: (id: string) => void;
  personalRecords: PersonalRecord[];
  addPersonalRecord: (exerciseId: string, exerciseName: string, value: number, unit: 'reps' | 'seconds' | 'kg' | 'lbs') => boolean;
  achievements: Achievement[];
  workoutHistory: Workout[];
  deleteWorkoutFromHistory: (workoutId: string) => void;

  // Active Workout Tracking
  activeWorkout: ActiveWorkoutSession | null;
  startWorkout: (routine?: CustomRoutine, customName?: string) => void;
  startEmptyWorkout: () => void;
  logQuickSingleSet: (params: {
    exerciseId: string;
    reps?: number;
    durationSec?: number;
    weightKg?: number;
    setType?: SetType;
  }) => { isNewPr: boolean };
  addSetToActiveExercise: (exerciseIndex: number, setType?: SetType) => void;
  removeSetFromActiveExercise: (exerciseIndex: number, setId: string) => void;
  updateActiveSet: (exerciseIndex: number, setId: string, updates: Partial<WorkoutSet>) => void;
  toggleActiveSetComplete: (exerciseIndex: number, setId: string) => void;
  addExerciseToActiveWorkout: (exerciseId: string) => void;
  removeExerciseFromActiveWorkout: (exerciseIndex: number) => void;
  reorderActiveExercises: (fromIndex: number, toIndex: number) => void;
  updateActiveExerciseNotes: (exerciseIndex: number, notes: string) => void;
  updateActiveWorkoutNotes: (notes: string) => void;
  finishActiveWorkout: () => WorkoutSummaryResult | null;
  cancelActiveWorkout: () => void;
  isWorkoutModalOpen: boolean;
  setIsWorkoutModalOpen: (open: boolean) => void;

  // Rest Timer
  isTimerRunning: boolean;
  isTimerPaused: boolean;
  timerSecondsLeft: number;
  timerTotalDuration: number;
  timerJustFinished: boolean;
  isTimerModalOpen: boolean;
  setIsTimerModalOpen: (open: boolean) => void;
  startRestTimer: (seconds?: number) => void;
  pauseRestTimer: () => void;
  resumeRestTimer: () => void;
  resetRestTimer: () => void;
  adjustRestTimer: (deltaSec: number) => void;
  stopRestTimer: () => void;

  // Notifications
  recentPRNotification: PersonalRecord | null;
  dismissPRNotification: () => void;
  triggerPRNotification: (pr: PersonalRecord) => void;
  recentAchievementNotification: Achievement | null;
  dismissAchievementNotification: () => void;
  triggerAchievementNotification: (achievement: Achievement) => void;
  levelUpTierNotification: DifficultyLevel | null;
  dismissLevelUpTierNotification: () => void;
  triggerLevelUpTierNotification: (tier: DifficultyLevel) => void;

  // Daily Habit Tracking
  dailyHabits: DailyHabit[];
  toggleDailyHabit: (habitId: string, dateKey?: string) => { completed: boolean; allCompleted: boolean };
  addDailyHabit: (title: string, subtitle: string, icon: HabitIconName) => void;
  deleteDailyHabit: (habitId: string) => void;

  // Data persistence
  exportDataJSON: () => string;
  importDataJSON: (jsonString: string) => boolean;
  resetAllData: () => void;
}

const WorkoutContext = createContext<WorkoutContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'liftbody_user_v2',
  SKILLS: 'liftbody_skills_v2',
  ROUTINES: 'liftbody_routines_v2',
  PRS: 'liftbody_prs_v2',
  ACHIEVEMENTS: 'liftbody_achievements_v2',
  HISTORY: 'liftbody_history_v2',
  ACTIVE_WORKOUT: 'liftbody_active_workout_v2',
  DAILY_HABITS: 'liftbody_daily_habits_v2',
  RESET_FLAG: 'liftbody_progress_reset_v2'
};

const ensureCleanReset = () => {
  try {
    if (typeof window !== 'undefined' && !localStorage.getItem(STORAGE_KEYS.RESET_FLAG)) {
      // Preserve custom profile identity if user customized name/logo in v1
      let preservedUser = { ...INITIAL_USER };
      const oldUserRaw = localStorage.getItem('liftbody_user_v1');
      if (oldUserRaw) {
        try {
          const oldUser = JSON.parse(oldUserRaw);
          preservedUser = {
            ...INITIAL_USER,
            name: oldUser.name || INITIAL_USER.name,
            athleteTitle: oldUser.athleteTitle || INITIAL_USER.athleteTitle,
            bio: oldUser.bio || INITIAL_USER.bio,
            profileImage: oldUser.profileImage || INITIAL_USER.profileImage,
            weeklyGoal: oldUser.weeklyGoal || INITIAL_USER.weeklyGoal,
            units: oldUser.units || INITIAL_USER.units,
            defaultRestTimeSec: oldUser.defaultRestTimeSec || INITIAL_USER.defaultRestTimeSec,
            soundEnabled: oldUser.soundEnabled ?? INITIAL_USER.soundEnabled,
            vibrationEnabled: oldUser.vibrationEnabled ?? INITIAL_USER.vibrationEnabled,
            streak: 0,
            totalWorkouts: 0,
            totalTrainingTimeSec: 0,
            totalReps: 0
          };
        } catch {
          // ignore
        }
      }

      localStorage.removeItem('liftbody_user_v1');
      localStorage.removeItem('liftbody_skills_v1');
      localStorage.removeItem('liftbody_routines_v1');
      localStorage.removeItem('liftbody_prs_v1');
      localStorage.removeItem('liftbody_achievements_v1');
      localStorage.removeItem('liftbody_history_v1');
      localStorage.removeItem('liftbody_active_workout_v1');

      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(preservedUser));
      localStorage.setItem(STORAGE_KEYS.SKILLS, JSON.stringify(INITIAL_SKILLS));
      localStorage.setItem(STORAGE_KEYS.ROUTINES, JSON.stringify(PRESET_ROUTINES));
      localStorage.setItem(STORAGE_KEYS.PRS, JSON.stringify(INITIAL_PRS));
      localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(INITIAL_ACHIEVEMENTS));
      localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(INITIAL_WORKOUT_HISTORY));
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_WORKOUT);
      localStorage.setItem(STORAGE_KEYS.RESET_FLAG, 'true');
    }
  } catch {
    // ignore storage errors
  }
};

export const WorkoutProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  ensureCleanReset();

  // Load State from LocalStorage or Fallback
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.USER);
      return stored ? JSON.parse(stored) : INITIAL_USER;
    } catch {
      return INITIAL_USER;
    }
  });

  const [skills, setSkills] = useState<Skill[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SKILLS);
      if (stored) {
        const parsed: Skill[] = JSON.parse(stored);
        return INITIAL_SKILLS.map((initial) => {
          const found = parsed.find((p) => p.id === initial.id);
          return found || initial;
        });
      }
      return INITIAL_SKILLS;
    } catch {
      return INITIAL_SKILLS;
    }
  });

  const [customRoutines, setCustomRoutines] = useState<CustomRoutine[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ROUTINES);
      if (stored) {
        const parsed: CustomRoutine[] = JSON.parse(stored);
        const customOnly = parsed.filter((r) => r.isCustom);
        const mergedPresets = PRESET_ROUTINES.map((p) => {
          const found = parsed.find((r) => r.id === p.id);
          return found || p;
        });
        return [...mergedPresets, ...customOnly];
      }
      return PRESET_ROUTINES;
    } catch {
      return PRESET_ROUTINES;
    }
  });

  const [personalRecords, setPersonalRecords] = useState<PersonalRecord[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PRS);
      return stored ? JSON.parse(stored) : INITIAL_PRS;
    } catch {
      return INITIAL_PRS;
    }
  });

  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ACHIEVEMENTS);
      return stored ? JSON.parse(stored) : INITIAL_ACHIEVEMENTS;
    } catch {
      return INITIAL_ACHIEVEMENTS;
    }
  });

  const [workoutHistory, setWorkoutHistory] = useState<Workout[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.HISTORY);
      return stored ? JSON.parse(stored) : INITIAL_WORKOUT_HISTORY;
    } catch {
      return INITIAL_WORKOUT_HISTORY;
    }
  });

  const [dailyHabits, setDailyHabits] = useState<DailyHabit[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.DAILY_HABITS);
      return stored ? JSON.parse(stored) : INITIAL_DAILY_HABITS;
    } catch {
      return INITIAL_DAILY_HABITS;
    }
  });

  const [activeWorkout, setActiveWorkout] = useState<ActiveWorkoutSession | null>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ACTIVE_WORKOUT);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [isWorkoutModalOpen, setIsWorkoutModalOpen] = useState<boolean>(false);

  // Rest Timer State
  const [timerTotalDuration, setTimerTotalDuration] = useState<number>(user.defaultRestTimeSec || 90);
  const [timerSecondsLeft, setTimerSecondsLeft] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [isTimerPaused, setIsTimerPaused] = useState<boolean>(false);
  const [timerJustFinished, setTimerJustFinished] = useState<boolean>(false);
  const [isTimerModalOpen, setIsTimerModalOpen] = useState<boolean>(false);

  // Popup banners
  const [recentPRNotification, setRecentPRNotification] = useState<PersonalRecord | null>(null);
  const [recentAchievementNotification, setRecentAchievementNotification] = useState<Achievement | null>(null);
  const [levelUpTierNotification, setLevelUpTierNotification] = useState<DifficultyLevel | null>(null);

  // References for intervals
  const workoutTimerRef = useRef<number | null>(null);
  const restTimerRef = useRef<number | null>(null);

  // Persist State to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  }, [user]);

  const currentTheme: 'dark' | 'light' = user.theme === 'light' ? 'light' : 'dark';

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.classList.toggle('light-mode', currentTheme === 'light');
      document.documentElement.setAttribute('data-theme', currentTheme);
    }
  }, [currentTheme]);

  const toggleTheme = useCallback(() => {
    setUser((prev) => ({
      ...prev,
      theme: prev.theme === 'light' ? 'dark' : 'light'
    }));
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SKILLS, JSON.stringify(skills));
  }, [skills]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROUTINES, JSON.stringify(customRoutines));
  }, [customRoutines]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRS, JSON.stringify(personalRecords));
  }, [personalRecords]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));
  }, [achievements]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(workoutHistory));
  }, [workoutHistory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DAILY_HABITS, JSON.stringify(dailyHabits));
  }, [dailyHabits]);

  useEffect(() => {
    if (activeWorkout) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_WORKOUT, JSON.stringify(activeWorkout));
    } else {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_WORKOUT);
    }
  }, [activeWorkout]);

  // Active Workout Elapsed Seconds Interval
  useEffect(() => {
    if (activeWorkout && !activeWorkout.isPaused) {
      workoutTimerRef.current = window.setInterval(() => {
        setActiveWorkout(prev => {
          if (!prev || prev.isPaused) return prev;
          return {
            ...prev,
            elapsedSeconds: prev.elapsedSeconds + 1
          };
        });
      }, 1000);
    } else {
      if (workoutTimerRef.current) clearInterval(workoutTimerRef.current);
    }

    return () => {
      if (workoutTimerRef.current) clearInterval(workoutTimerRef.current);
    };
  }, [activeWorkout?.isPaused, !!activeWorkout]);

  // Rest Timer Interval
  useEffect(() => {
    if (isTimerRunning && !isTimerPaused) {
      restTimerRef.current = window.setInterval(() => {
        setTimerSecondsLeft(prev => {
          if (prev <= 1) {
            // Timer Reached Zero: Trigger Subtle Haptic & Selected Audio Chime
            if (user.soundEnabled) {
              playTimerFinishSound(user.timerChimeStyle || 'singing-bowl');
            }
            if (user.vibrationEnabled) {
              triggerTimerZeroHaptic(user.timerHapticStyle || 'subtle-pulse');
            }
            setIsTimerRunning(false);
            setIsTimerPaused(false);
            setTimerJustFinished(true);
            window.setTimeout(() => setTimerJustFinished(false), 4500);
            return 0;
          }
          if (prev <= 4 && prev > 1) {
            if (user.soundEnabled && user.timerChimeStyle !== 'silent') playCountdownTick();
            if (user.vibrationEnabled && user.timerHapticStyle !== 'off') triggerHaptic(25);
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (restTimerRef.current) clearInterval(restTimerRef.current);
    }

    return () => {
      if (restTimerRef.current) clearInterval(restTimerRef.current);
    };
  }, [
    isTimerRunning,
    isTimerPaused,
    user.soundEnabled,
    user.vibrationEnabled,
    user.timerChimeStyle,
    user.timerHapticStyle
  ]);

  const updateUser = useCallback((updates: Partial<UserProfile>) => {
    setUser(prev => ({ ...prev, ...updates }));
  }, []);

  // Check achievements against current stats
  const checkAchievements = useCallback((
    currentWorkoutsCount: number,
    currentStreak: number,
    isPR: boolean,
    isSkillLevel3: boolean,
    isBackpackWorkout: boolean,
    hasCustomRoutine: boolean
  ) => {
    setAchievements(prev => {
      const now = new Date().toISOString();
      let newlyUnlocked: Achievement | null = null;

      const updated = prev.map(ach => {
        if (ach.unlockedAt) return ach; // Already unlocked

        let newProgress = ach.progress;
        let shouldUnlock = false;

        switch (ach.id) {
          case 'ach_1':
            newProgress = currentWorkoutsCount >= 1 ? 1 : 0;
            shouldUnlock = newProgress >= 1;
            break;
          case 'ach_2':
            newProgress = Math.min(currentWorkoutsCount, 5);
            shouldUnlock = newProgress >= 5;
            break;
          case 'ach_3':
            newProgress = Math.min(currentWorkoutsCount, 10);
            shouldUnlock = newProgress >= 10;
            break;
          case 'ach_4':
            newProgress = Math.min(currentWorkoutsCount, 25);
            shouldUnlock = newProgress >= 25;
            break;
          case 'ach_5':
            newProgress = Math.min(currentWorkoutsCount, 100);
            shouldUnlock = newProgress >= 100;
            break;
          case 'ach_6':
            newProgress = Math.min(currentStreak, 7);
            shouldUnlock = newProgress >= 7;
            break;
          case 'ach_7':
            newProgress = Math.min(currentStreak, 30);
            shouldUnlock = newProgress >= 30;
            break;
          case 'ach_8':
            if (isPR) {
              newProgress = 1;
              shouldUnlock = true;
            }
            break;
          case 'ach_10':
            if (isSkillLevel3) {
              newProgress = 1;
              shouldUnlock = true;
            }
            break;
          case 'ach_11':
            if (isBackpackWorkout) {
              newProgress = 1;
              shouldUnlock = true;
            }
            break;
          case 'ach_12':
            if (hasCustomRoutine) {
              newProgress = 1;
              shouldUnlock = true;
            }
            break;
          default:
            break;
        }

        if (shouldUnlock) {
          newlyUnlocked = { ...ach, progress: ach.maxProgress, unlockedAt: now };
          return newlyUnlocked;
        }

        return { ...ach, progress: newProgress };
      });

      if (newlyUnlocked) {
        setRecentAchievementNotification(newlyUnlocked);
        playCelebrationSound();
      }

      return updated;
    });
  }, []);

  // PR Handler
  const addPersonalRecord = useCallback((
    exerciseId: string,
    exerciseName: string,
    value: number,
    unit: 'reps' | 'seconds' | 'kg' | 'lbs'
  ): boolean => {
    let isNewRecord = false;
    let newPRItem: PersonalRecord | null = null;

    setPersonalRecords(prev => {
      const existing = prev.find(p => p.exerciseId === exerciseId && p.unit === unit);
      if (!existing || value > existing.value) {
        isNewRecord = true;
        newPRItem = {
          id: `pr_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          exerciseId,
          exerciseName,
          value,
          unit,
          date: new Date().toISOString(),
          previousValue: existing?.value
        };

        const filtered = prev.filter(p => !(p.exerciseId === exerciseId && p.unit === unit));
        return [newPRItem, ...filtered];
      }
      return prev;
    });

    if (isNewRecord && newPRItem) {
      setRecentPRNotification(newPRItem);
      if (user.soundEnabled) playCelebrationSound();
      if (user.vibrationEnabled) triggerHaptic([50, 80, 120]);
      checkAchievements(user.totalWorkouts, user.streak, true, false, false, false);
    }

    return isNewRecord;
  }, [user, checkAchievements]);

  // Skill Level update & hold log
  const updateSkillLevel = useCallback((skillId: string, level: number) => {
    setSkills(prev => prev.map(s => {
      if (s.id === skillId) {
        const boundedLevel = Math.max(1, Math.min(s.maxLevel, level));
        return { ...s, currentLevel: boundedLevel };
      }
      return s;
    }));
  }, []);

  const logSkillHold = useCallback((skillId: string, holdSec: number) => {
    let isNewPr = false;
    let leveledUp = false;

    setSkills(prev => prev.map(s => {
      if (s.id === skillId) {
        const newPr = Math.max(s.prHoldSec, holdSec);
        isNewPr = holdSec > s.prHoldSec;

        // Auto level up if reached target of current level
        const currentLevelObj = s.levels.find(l => l.level === s.currentLevel);
        let nextLevel = s.currentLevel;
        if (currentLevelObj && holdSec >= currentLevelObj.targetHoldSec && s.currentLevel < s.maxLevel) {
          nextLevel = s.currentLevel + 1;
          leveledUp = true;
        }

        return {
          ...s,
          currentHoldSec: holdSec,
          prHoldSec: newPr,
          currentLevel: nextLevel
        };
      }
      return s;
    }));

    if (isNewPr) {
      const skillName = skills.find(s => s.id === skillId)?.name || 'Skill';
      addPersonalRecord(skillId, `Longest ${skillName} Hold`, holdSec, 'seconds');
    }

    if (leveledUp) {
      if (user.soundEnabled) playCelebrationSound();
      checkAchievements(user.totalWorkouts, user.streak, false, true, false, false);
    }

    return { isNewPr, leveledUp };
  }, [skills, addPersonalRecord, user, checkAchievements]);

  // Custom & Preset Routines (supports editing both preset and custom routines + progressive overload)
  const saveCustomRoutine = useCallback((routine: CustomRoutine) => {
    setCustomRoutines(prev => {
      const exists = prev.some(r => r.id === routine.id);
      if (exists) {
        return prev.map(r =>
          r.id === routine.id ? { ...routine, isCustom: r.isCustom ?? routine.isCustom } : r
        );
      }
      return [{ ...routine, isCustom: true }, ...prev];
    });
    checkAchievements(user.totalWorkouts, user.streak, false, false, false, true);
  }, [user, checkAchievements]);

  const overloadRoutine = useCallback((routineId: string, mode: 'reps' | 'sets' | 'weight') => {
    setCustomRoutines(prev =>
      prev.map(r => {
        if (r.id !== routineId) return r;
        const overloadedExercises = r.exercises.map(item => {
          const exDef = INITIAL_EXERCISES.find(e => e.id === item.exerciseId);
          const isHold = exDef?.isHold || false;
          if (mode === 'sets') {
            return { ...item, setsCount: Math.min(12, item.setsCount + 1) };
          }
          if (mode === 'weight') {
            return { ...item, targetWeightKg: Math.round(((item.targetWeightKg || 0) + 2.5) * 10) / 10 };
          }
          // mode === 'reps': +2 reps for dynamic exercises, +5s for isometric holds
          if (isHold) {
            return {
              ...item,
              defaultHoldSec: (item.defaultHoldSec || exDef?.defaultHoldSec || 30) + 5
            };
          }
          return {
            ...item,
            defaultReps: (item.defaultReps || exDef?.defaultReps || 10) + 2
          };
        });
        return {
          ...r,
          exercises: overloadedExercises,
          estimatedDurationMin: Math.max(15, overloadedExercises.reduce((s, e) => s + e.setsCount * 2, 0))
        };
      })
    );
    if (user.soundEnabled) playPopSound('overload');
    if (user.vibrationEnabled) triggerHaptic(35);
  }, [user.soundEnabled, user.vibrationEnabled]);

  const deleteCustomRoutine = useCallback((id: string) => {
    setCustomRoutines(prev => prev.filter(r => r.id !== id));
  }, []);

  const duplicateCustomRoutine = useCallback((id: string) => {
    const target = customRoutines.find(r => r.id === id);
    if (!target) return;
    const duplicated: CustomRoutine = {
      ...target,
      id: `routine_${Date.now()}`,
      name: `${target.name} (Copy)`,
      isCustom: true
    };
    setCustomRoutines(prev => [duplicated, ...prev]);
  }, [customRoutines]);

  // Rest Timer Controls
  const startRestTimer = useCallback((seconds?: number) => {
    const duration = seconds || user.defaultRestTimeSec || 90;
    setTimerTotalDuration(duration);
    setTimerSecondsLeft(duration);
    setIsTimerRunning(true);
    setIsTimerPaused(false);
    setIsTimerModalOpen(true);
  }, [user.defaultRestTimeSec]);

  const pauseRestTimer = useCallback(() => {
    setIsTimerPaused(true);
  }, []);

  const resumeRestTimer = useCallback(() => {
    setIsTimerPaused(false);
  }, []);

  const resetRestTimer = useCallback(() => {
    setTimerSecondsLeft(timerTotalDuration);
    setIsTimerRunning(true);
    setIsTimerPaused(false);
  }, [timerTotalDuration]);

  const adjustRestTimer = useCallback((deltaSec: number) => {
    setTimerSecondsLeft(prev => Math.max(5, prev + deltaSec));
    setTimerTotalDuration(prev => Math.max(5, prev + deltaSec));
  }, []);

  const stopRestTimer = useCallback(() => {
    if (restTimerRef.current) {
      clearInterval(restTimerRef.current);
      restTimerRef.current = null;
    }
    setIsTimerRunning(false);
    setIsTimerPaused(false);
    setTimerSecondsLeft(0);
    setIsTimerModalOpen(false);
  }, []);

  // Active Workout Actions
  const startWorkout = useCallback((routine?: CustomRoutine, customName?: string) => {
    const exercises: WorkoutExercise[] = (routine?.exercises || [
      { exerciseId: 'pull-up', setsCount: 3, defaultReps: 8, restTimeSec: 90 },
      { exerciseId: 'push-up', setsCount: 3, defaultReps: 12, restTimeSec: 60 }
    ]).map(re => {
      const exDef = INITIAL_EXERCISES.find(e => e.id === re.exerciseId);
      const isHold = exDef?.isHold || false;
      const sets: WorkoutSet[] = Array.from({ length: re.setsCount }).map((_, idx) => ({
        id: `set_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        setNumber: idx + 1,
        setType: re.defaultSetType || 'normal',
        reps: isHold ? undefined : (re.defaultReps || exDef?.defaultReps || 10),
        durationSec: isHold ? (re.defaultHoldSec || exDef?.defaultHoldSec || 30) : undefined,
        weightKg: re.targetWeightKg || 0,
        completed: false,
        targetReps: isHold ? undefined : (re.defaultReps || exDef?.defaultReps || 10),
        targetHoldSec: isHold ? (re.defaultHoldSec || exDef?.defaultHoldSec || 30) : undefined,
        targetWeightKg: re.targetWeightKg || 0
      }));

      return {
        exerciseId: re.exerciseId,
        sets,
        restTimeSec: re.restTimeSec ?? 60,
        supersetWithNext: re.supersetWithNext || false,
        notes: ''
      };
    });

    const newSession: ActiveWorkoutSession = {
      id: `active_${Date.now()}`,
      name: customName || routine?.name || 'Quick Workout',
      startTime: Date.now(),
      elapsedSeconds: 0,
      exercises,
      isPaused: false,
      notes: ''
    };

    setActiveWorkout(newSession);
    setIsWorkoutModalOpen(true);
  }, []);

  const startEmptyWorkout = useCallback(() => {
    const newSession: ActiveWorkoutSession = {
      id: `active_${Date.now()}`,
      name: 'Freestyle Calisthenics',
      startTime: Date.now(),
      elapsedSeconds: 0,
      exercises: [],
      isPaused: false,
      notes: ''
    };
    setActiveWorkout(newSession);
    setIsWorkoutModalOpen(true);
    if (user.soundEnabled) playPopSound('bright');
  }, [user.soundEnabled]);

  const logQuickSingleSet = useCallback(
    ({
      exerciseId,
      reps,
      durationSec,
      weightKg = 0,
      setType = 'normal'
    }: {
      exerciseId: string;
      reps?: number;
      durationSec?: number;
      weightKg?: number;
      setType?: SetType;
    }): { isNewPr: boolean } => {
      const exDef = INITIAL_EXERCISES.find((e) => e.id === exerciseId);
      const exName = exDef?.name || exerciseId;
      const isHold = exDef?.isHold || false;

      const finalReps = isHold ? undefined : Math.max(1, reps || exDef?.defaultReps || 10);
      const finalHold = isHold ? Math.max(1, durationSec || exDef?.defaultHoldSec || 30) : undefined;
      const finalWeight = Math.max(0, weightKg || 0);

      let isNewPr = false;
      const newPRs: PersonalRecord[] = [];

      if (finalReps && finalReps > 0) {
        const didPR = addPersonalRecord(exerciseId, exName, finalReps, 'reps');
        if (didPR) {
          isNewPr = true;
          newPRs.push({
            id: `pr_${Date.now()}_${exerciseId}_reps`,
            exerciseId,
            exerciseName: exName,
            value: finalReps,
            unit: 'reps',
            date: new Date().toISOString()
          });
        }
      }

      if (finalHold && finalHold > 0) {
        const didPR = addPersonalRecord(exerciseId, exName, finalHold, 'seconds');
        if (didPR) {
          isNewPr = true;
          newPRs.push({
            id: `pr_${Date.now()}_${exerciseId}_hold`,
            exerciseId,
            exerciseName: exName,
            value: finalHold,
            unit: 'seconds',
            date: new Date().toISOString()
          });
        }
      }

      if (finalWeight > 0) {
        const weightUnit: 'kg' | 'lbs' = user.units === 'imperial' ? 'lbs' : 'kg';
        const weightExId = `${exerciseId}-weight`;
        const didPR = addPersonalRecord(
          weightExId,
          `${exName} (Max Load)`,
          finalWeight,
          weightUnit
        );
        if (didPR) {
          isNewPr = true;
          newPRs.push({
            id: `pr_${Date.now()}_${exerciseId}_weight`,
            exerciseId: weightExId,
            exerciseName: `${exName} (Max Load)`,
            value: finalWeight,
            unit: weightUnit,
            date: new Date().toISOString()
          });
        }
      }

      const quickSet: WorkoutSet = {
        id: `qset_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        setNumber: 1,
        setType,
        trackingMode: isHold ? 'time' : finalWeight > 0 ? 'weight' : 'reps',
        reps: finalReps,
        durationSec: finalHold,
        weightKg: finalWeight,
        completed: true
      };

      const quickWorkoutEntry: Workout = {
        id: `workout_quick_${Date.now()}`,
        name: `Quick Set · ${exName}`,
        date: new Date().toISOString(),
        durationSec: 90,
        exercises: [
          {
            exerciseId,
            sets: [quickSet],
            restTimeSec: user.defaultRestTimeSec
          }
        ],
        totalSets: 1,
        totalReps: finalReps || 0,
        prsEarned: newPRs.map((p) => `${p.exerciseName}: ${p.value} ${p.unit}`),
        prDetails: newPRs,
        difficultyTier: exDef?.difficulty || 'beginner'
      };

      setWorkoutHistory((prev) => [quickWorkoutEntry, ...prev]);

      updateUser({
        totalWorkouts: user.totalWorkouts + 1,
        totalTrainingTimeSec: user.totalTrainingTimeSec + 90,
        totalReps: user.totalReps + (finalReps || 0),
        streak: Math.max(1, user.streak)
      });

      if (!isNewPr) {
        if (user.soundEnabled) playSetCompleteSound();
        if (user.vibrationEnabled) triggerHaptic([40, 60]);
      }

      return { isNewPr };
    },
    [addPersonalRecord, user, updateUser]
  );

  const addSetToActiveExercise = useCallback((exerciseIndex: number, setType: SetType = 'normal') => {
    setActiveWorkout(prev => {
      if (!prev) return prev;
      const exercises = [...prev.exercises];
      const targetEx = exercises[exerciseIndex];
      if (!targetEx) return prev;

      const lastSet = targetEx.sets[targetEx.sets.length - 1];
      const exDef = INITIAL_EXERCISES.find(e => e.id === targetEx.exerciseId);
      const isHold = exDef?.isHold || false;

      // For a drop set, automatically suggest slightly reduced weight or adjusted reps
      const baseWeight = lastSet?.weightKg || 0;
      const suggestedWeight =
        setType === 'dropset' && baseWeight > 0
          ? Math.max(0, Math.round(baseWeight * 0.7))
          : baseWeight;

      const newSet: WorkoutSet = {
        id: `set_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        setNumber: targetEx.sets.length + 1,
        setType,
        trackingMode: lastSet?.trackingMode || (isHold ? 'time' : 'reps'),
        reps: lastSet?.reps ?? exDef?.defaultReps ?? 10,
        durationSec: lastSet?.durationSec ?? exDef?.defaultHoldSec ?? 30,
        weightKg: suggestedWeight,
        completed: false,
        targetReps: isHold ? undefined : (lastSet?.targetReps || 10),
        targetHoldSec: isHold ? (lastSet?.targetHoldSec || 30) : undefined
      };

      exercises[exerciseIndex] = {
        ...targetEx,
        sets: [...targetEx.sets, newSet]
      };

      return { ...prev, exercises };
    });
    if (user.soundEnabled) playPopSound(setType === 'normal' ? 'bright' : 'overload');
  }, [user.soundEnabled]);

  const removeSetFromActiveExercise = useCallback((exerciseIndex: number, setId: string) => {
    setActiveWorkout(prev => {
      if (!prev) return prev;
      const exercises = [...prev.exercises];
      const targetEx = exercises[exerciseIndex];
      if (!targetEx) return prev;

      const remainingSets = targetEx.sets
        .filter(s => s.id !== setId)
        .map((s, idx) => ({ ...s, setNumber: idx + 1 }));

      exercises[exerciseIndex] = {
        ...targetEx,
        sets: remainingSets
      };

      return { ...prev, exercises };
    });
  }, []);

  const updateActiveSet = useCallback((exerciseIndex: number, setId: string, updates: Partial<WorkoutSet>) => {
    setActiveWorkout(prev => {
      if (!prev) return prev;
      const exercises = [...prev.exercises];
      const targetEx = exercises[exerciseIndex];
      if (!targetEx) return prev;

      const updatedSets = targetEx.sets.map(s => (s.id === setId ? { ...s, ...updates } : s));
      exercises[exerciseIndex] = { ...targetEx, sets: updatedSets };
      return { ...prev, exercises };
    });
  }, []);

  const toggleActiveSetComplete = useCallback((exerciseIndex: number, setId: string) => {
    let shouldStartRest = false;
    let restDuration = 60;

    setActiveWorkout(prev => {
      if (!prev) return prev;
      const exercises = [...prev.exercises];
      const targetEx = exercises[exerciseIndex];
      if (!targetEx) return prev;

      const updatedSets = targetEx.sets.map(s => {
        if (s.id === setId) {
          const nextCompleted = !s.completed;
          if (nextCompleted) {
            shouldStartRest = true;
            restDuration = targetEx.restTimeSec || user.defaultRestTimeSec || 60;
          }
          return { ...s, completed: nextCompleted };
        }
        return s;
      });

      exercises[exerciseIndex] = { ...targetEx, sets: updatedSets };
      return { ...prev, exercises };
    });

    if (shouldStartRest) {
      if (user.soundEnabled) playSetCompleteSound();
      if (user.vibrationEnabled) triggerHaptic(40);
      startRestTimer(restDuration);
    }
  }, [user, startRestTimer]);

  const addExerciseToActiveWorkout = useCallback((exerciseId: string) => {
    const exDef = INITIAL_EXERCISES.find(e => e.id === exerciseId);
    if (!exDef) return;

    const isHold = exDef.isHold || false;
    const initialSets: WorkoutSet[] = [1, 2, 3].map(num => ({
      id: `set_${Date.now()}_${num}`,
      setNumber: num,
      reps: isHold ? undefined : (exDef.defaultReps || 10),
      durationSec: isHold ? (exDef.defaultHoldSec || 30) : undefined,
      weightKg: 0,
      completed: false
    }));

    const newEx: WorkoutExercise = {
      exerciseId,
      sets: initialSets,
      restTimeSec: 60,
      notes: ''
    };

    setActiveWorkout(prev => {
      if (!prev) {
        return {
          id: `active_${Date.now()}`,
          name: 'Quick Calisthenics',
          startTime: Date.now(),
          elapsedSeconds: 0,
          exercises: [newEx],
          isPaused: false
        };
      }
      return {
        ...prev,
        exercises: [...prev.exercises, newEx]
      };
    });
  }, []);

  const removeExerciseFromActiveWorkout = useCallback((exerciseIndex: number) => {
    setActiveWorkout(prev => {
      if (!prev) return prev;
      const exercises = prev.exercises.filter((_, idx) => idx !== exerciseIndex);
      return { ...prev, exercises };
    });
  }, []);

  const reorderActiveExercises = useCallback((fromIndex: number, toIndex: number) => {
    setActiveWorkout(prev => {
      if (!prev) return prev;
      const exercises = [...prev.exercises];
      const [moved] = exercises.splice(fromIndex, 1);
      exercises.splice(toIndex, 0, moved);
      return { ...prev, exercises };
    });
  }, []);

  const updateActiveExerciseNotes = useCallback((exerciseIndex: number, notes: string) => {
    setActiveWorkout(prev => {
      if (!prev) return prev;
      const exercises = [...prev.exercises];
      if (exercises[exerciseIndex]) {
        exercises[exerciseIndex] = { ...exercises[exerciseIndex], notes };
      }
      return { ...prev, exercises };
    });
  }, []);

  const updateActiveWorkoutNotes = useCallback((notes: string) => {
    setActiveWorkout(prev => {
      if (!prev) return prev;
      const updated = { ...prev, notes };
      try {
        localStorage.setItem(STORAGE_KEYS.ACTIVE_WORKOUT, JSON.stringify(updated));
        localStorage.setItem('liftbody_workout_notes_v2', notes);
      } catch {
        // ignore storage errors
      }
      return updated;
    });
  }, []);

  const cancelActiveWorkout = useCallback(() => {
    setActiveWorkout(null);
    setIsWorkoutModalOpen(false);
    setIsTimerRunning(false);
  }, []);

  const finishActiveWorkout = useCallback((): WorkoutSummaryResult | null => {
    if (!activeWorkout) return null;

    let totalSets = 0;
    let totalReps = 0;
    const newPRs: PersonalRecord[] = [];
    let isBackpackUsed = false;

    const anySetMarkedComplete = activeWorkout.exercises.some((ex) =>
      ex.sets.some((s) => s.completed)
    );

    activeWorkout.exercises.forEach((ex) => {
      const exDef = INITIAL_EXERCISES.find((e) => e.id === ex.exerciseId);
      const exName = exDef?.name || ex.exerciseId;
      if (exDef?.category === 'backpack') isBackpackUsed = true;

      // If the user forgot to check individual set boxes before tapping Finish, evaluate all sets with positive values
      const effectiveSets = anySetMarkedComplete
        ? ex.sets.filter((s) => s.completed)
        : ex.sets.filter((s) => (s.reps && s.reps > 0) || (s.durationSec && s.durationSec > 0));

      let bestReps = 0;
      let bestHoldSec = 0;
      let bestWeightKg = 0;

      effectiveSets.forEach((s) => {
        totalSets += 1;
        if (s.reps && s.reps > 0) {
          totalReps += s.reps;
          if (s.reps > bestReps) bestReps = s.reps;
        }
        if (s.durationSec && s.durationSec > 0) {
          if (s.durationSec > bestHoldSec) bestHoldSec = s.durationSec;
        }
        if (s.weightKg && s.weightKg > 0) {
          isBackpackUsed = true;
          if (s.weightKg > bestWeightKg) bestWeightKg = s.weightKg;
        }
      });

      // 1. Check Max Reps PR for this exercise
      if (bestReps > 0) {
        const currentRepPR = personalRecords.find(
          (p) => p.exerciseId === ex.exerciseId && p.unit === 'reps'
        );
        if (!currentRepPR || bestReps > currentRepPR.value) {
          const pr: PersonalRecord = {
            id: `pr_${Date.now()}_${ex.exerciseId}_reps`,
            exerciseId: ex.exerciseId,
            exerciseName: exName,
            value: bestReps,
            unit: 'reps',
            date: new Date().toISOString(),
            previousValue: currentRepPR?.value
          };
          newPRs.push(pr);
          addPersonalRecord(ex.exerciseId, exName, bestReps, 'reps');
        }
      }

      // 2. Check Max Hold Duration PR for this exercise
      if (bestHoldSec > 0) {
        const currentHoldPR = personalRecords.find(
          (p) => p.exerciseId === ex.exerciseId && p.unit === 'seconds'
        );
        if (!currentHoldPR || bestHoldSec > currentHoldPR.value) {
          const pr: PersonalRecord = {
            id: `pr_${Date.now()}_${ex.exerciseId}_hold`,
            exerciseId: ex.exerciseId,
            exerciseName: exName,
            value: bestHoldSec,
            unit: 'seconds',
            date: new Date().toISOString(),
            previousValue: currentHoldPR?.value
          };
          newPRs.push(pr);
          addPersonalRecord(ex.exerciseId, exName, bestHoldSec, 'seconds');
        }
      }

      // 3. Check Max Added Weight PR for this exercise
      if (bestWeightKg > 0) {
        const weightUnit: 'kg' | 'lbs' = user.units === 'imperial' ? 'lbs' : 'kg';
        const weightExerciseId = `${ex.exerciseId}-weight`;
        const currentWeightPR = personalRecords.find(
          (p) =>
            p.exerciseId === weightExerciseId ||
            (p.exerciseId === ex.exerciseId && (p.unit === 'kg' || p.unit === 'lbs'))
        );
        if (!currentWeightPR || bestWeightKg > currentWeightPR.value) {
          const pr: PersonalRecord = {
            id: `pr_${Date.now()}_${ex.exerciseId}_weight`,
            exerciseId: weightExerciseId,
            exerciseName: `${exName} (Max Load)`,
            value: bestWeightKg,
            unit: weightUnit,
            date: new Date().toISOString(),
            previousValue: currentWeightPR?.value
          };
          newPRs.push(pr);
          addPersonalRecord(weightExerciseId, `${exName} (Max Load)`, bestWeightKg, weightUnit);
        }
      }
    });

    const normalizedExercises: WorkoutExercise[] = anySetMarkedComplete
      ? activeWorkout.exercises
      : activeWorkout.exercises.map((ex) => ({
          ...ex,
          sets: ex.sets.map((s) => ({ ...s, completed: true }))
        }));

    // Helper to determine the difficulty tier of a workout from its exercises
    const computeWorkoutTier = (exList: WorkoutExercise[]): DifficultyLevel => {
      let hasAdvanced = false;
      let hasIntermediate = false;
      exList.forEach((we) => {
        const def = INITIAL_EXERCISES.find((e) => e.id === we.exerciseId);
        if (def?.difficulty === 'advanced') hasAdvanced = true;
        else if (def?.difficulty === 'intermediate') hasIntermediate = true;
      });
      if (hasAdvanced) return 'advanced';
      if (hasIntermediate) return 'intermediate';
      return 'beginner';
    };

    const currentWorkoutTier = computeWorkoutTier(normalizedExercises);

    // Check which difficulty tiers the user has already completed in prior workouts
    const previouslyCompletedTiers = new Set<DifficultyLevel>();
    workoutHistory.forEach((pastWorkout) => {
      const pastTier = pastWorkout.difficultyTier || computeWorkoutTier(pastWorkout.exercises);
      previouslyCompletedTiers.add(pastTier);
    });

    // If this workout's difficulty tier has never been completed before, trigger Level Up!
    const newDifficultyTier: DifficultyLevel | null = !previouslyCompletedTiers.has(currentWorkoutTier)
      ? currentWorkoutTier
      : null;

    const newWorkout: Workout = {
      id: `workout_${Date.now()}`,
      name: activeWorkout.name,
      date: new Date().toISOString(),
      durationSec: Math.max(60, activeWorkout.elapsedSeconds),
      exercises: normalizedExercises,
      totalSets,
      totalReps,
      notes: activeWorkout.notes?.trim() || undefined,
      prsEarned: newPRs.map((p) => `${p.exerciseName}: ${p.value} ${p.unit}`),
      prDetails: newPRs,
      difficultyTier: currentWorkoutTier
    };

    // Save to workout history
    setWorkoutHistory(prev => [newWorkout, ...prev]);

    // Trigger subtle Level Up confetti overlay if this is the user's first workout in this difficulty tier
    if (newDifficultyTier) {
      setLevelUpTierNotification(newDifficultyTier);
    }

    // Update user stats & streak
    const nextTotalWorkouts = user.totalWorkouts + 1;
    const nextTotalTime = user.totalTrainingTimeSec + newWorkout.durationSec;
    const nextTotalReps = user.totalReps + totalReps;
    const nextStreak = user.streak + 1;

    updateUser({
      totalWorkouts: nextTotalWorkouts,
      totalTrainingTimeSec: nextTotalTime,
      totalReps: nextTotalReps,
      streak: nextStreak
    });

    // Check achievements
    checkAchievements(nextTotalWorkouts, nextStreak, newPRs.length > 0, false, isBackpackUsed, false);

    // Audio cue
    playCelebrationSound();
    triggerHaptic([60, 100, 60, 100, 150]);

    // Clear active workout
    setActiveWorkout(null);
    setIsTimerRunning(false);

    return {
      workout: newWorkout,
      newPRs,
      unlockedAchievements: [],
      newDifficultyTier
    };
  }, [activeWorkout, personalRecords, addPersonalRecord, user, updateUser, checkAchievements, workoutHistory]);

  const deleteWorkoutFromHistory = useCallback((workoutId: string) => {
    setWorkoutHistory(prev => prev.filter(w => w.id !== workoutId));
  }, []);

  const dismissPRNotification = useCallback(() => {
    setRecentPRNotification(null);
  }, []);

  const triggerPRNotification = useCallback((pr: PersonalRecord) => {
    setRecentPRNotification(pr);
    if (user.soundEnabled) playCelebrationSound();
    if (user.vibrationEnabled) triggerHaptic([50, 80, 120]);
  }, [user.soundEnabled, user.vibrationEnabled]);

  const dismissAchievementNotification = useCallback(() => {
    setRecentAchievementNotification(null);
  }, []);

  const triggerAchievementNotification = useCallback((achievement: Achievement) => {
    setRecentAchievementNotification(achievement);
    if (user.soundEnabled) playCelebrationSound();
    if (user.vibrationEnabled) triggerHaptic([50, 80, 120]);
  }, [user.soundEnabled, user.vibrationEnabled]);

  const dismissLevelUpTierNotification = useCallback(() => {
    setLevelUpTierNotification(null);
  }, []);

  const triggerLevelUpTierNotification = useCallback((tier: DifficultyLevel) => {
    setLevelUpTierNotification(tier);
    if (user.soundEnabled) playCelebrationSound();
    if (user.vibrationEnabled) triggerHaptic([40, 70, 110]);
  }, [user.soundEnabled, user.vibrationEnabled]);

  // Export / Import
  const exportDataJSON = useCallback(() => {
    const fullState = {
      user,
      skills,
      customRoutines,
      personalRecords,
      achievements,
      workoutHistory,
      exportedAt: new Date().toISOString(),
      app: 'Liftbody'
    };
    return JSON.stringify(fullState, null, 2);
  }, [user, skills, customRoutines, personalRecords, achievements, workoutHistory]);

  const importDataJSON = useCallback((jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString);
      if (data.user) setUser(data.user);
      if (data.skills) setSkills(data.skills);
      if (data.customRoutines) setCustomRoutines(data.customRoutines);
      if (data.personalRecords) setPersonalRecords(data.personalRecords);
      if (data.achievements) setAchievements(data.achievements);
      if (data.workoutHistory) setWorkoutHistory(data.workoutHistory);
      return true;
    } catch {
      return false;
    }
  }, []);

  const getTodayKey = () => {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  const toggleDailyHabit = useCallback(
    (habitId: string, dateKey?: string): { completed: boolean; allCompleted: boolean } => {
      const targetDate = dateKey || getTodayKey();
      let nowCompleted = false;
      let allDone = false;

      const updated = dailyHabits.map((h) => {
        if (h.id !== habitId) return h;
        const alreadyDone = h.completedDates.includes(targetDate);
        nowCompleted = !alreadyDone;
        return {
          ...h,
          completedDates: alreadyDone
            ? h.completedDates.filter((d) => d !== targetDate)
            : [...h.completedDates, targetDate]
        };
      });

      allDone = updated.length > 0 && updated.every((h) => h.completedDates.includes(targetDate));
      setDailyHabits(updated);

      if (nowCompleted) {
        if (allDone) {
          if (user.soundEnabled) playConfettiPopSound();
          if (user.vibrationEnabled) triggerHaptic([50, 70, 50, 120]);
        } else {
          if (user.soundEnabled) playPopSound('habit');
          if (user.vibrationEnabled) triggerHaptic(40);
        }
      } else {
        if (user.soundEnabled) playPopSound('soft');
      }

      return { completed: nowCompleted, allCompleted: allDone };
    },
    [dailyHabits, user.soundEnabled, user.vibrationEnabled]
  );

  const addDailyHabit = useCallback((title: string, subtitle: string, icon: HabitIconName) => {
    const newHabit: DailyHabit = {
      id: `habit_${Date.now()}`,
      title: title.trim(),
      subtitle: subtitle.trim() || 'Daily discipline habit',
      icon,
      completedDates: [],
      isCustom: true
    };
    setDailyHabits((prev) => [...prev, newHabit]);
  }, []);

  const deleteDailyHabit = useCallback((habitId: string) => {
    setDailyHabits((prev) => prev.filter((h) => h.id !== habitId));
  }, []);

  const resetAllData = useCallback(() => {
    localStorage.clear();
    localStorage.setItem(STORAGE_KEYS.RESET_FLAG, 'true');
    setUser((prev) => ({
      ...INITIAL_USER,
      name: prev.name || INITIAL_USER.name,
      athleteTitle: prev.athleteTitle || INITIAL_USER.athleteTitle,
      bio: prev.bio || INITIAL_USER.bio,
      profileImage: prev.profileImage || INITIAL_USER.profileImage,
      streak: 0,
      totalWorkouts: 0,
      totalTrainingTimeSec: 0,
      totalReps: 0
    }));
    setSkills(INITIAL_SKILLS);
    setCustomRoutines(PRESET_ROUTINES);
    setPersonalRecords(INITIAL_PRS);
    setAchievements(INITIAL_ACHIEVEMENTS);
    setWorkoutHistory(INITIAL_WORKOUT_HISTORY);
    setDailyHabits(INITIAL_DAILY_HABITS);
    setActiveWorkout(null);
  }, []);

  return (
    <WorkoutContext.Provider
      value={{
        user,
        updateUser,
        theme: currentTheme,
        toggleTheme,
        exercises: INITIAL_EXERCISES,
        skills,
        updateSkillLevel,
        logSkillHold,
        customRoutines,
        saveCustomRoutine,
        overloadRoutine,
        deleteCustomRoutine,
        duplicateCustomRoutine,
        personalRecords,
        addPersonalRecord,
        achievements,
        workoutHistory,
        deleteWorkoutFromHistory,
        activeWorkout,
        startWorkout,
        startEmptyWorkout,
        logQuickSingleSet,
        addSetToActiveExercise,
        removeSetFromActiveExercise,
        updateActiveSet,
        toggleActiveSetComplete,
        addExerciseToActiveWorkout,
        removeExerciseFromActiveWorkout,
        reorderActiveExercises,
        updateActiveExerciseNotes,
        updateActiveWorkoutNotes,
        finishActiveWorkout,
        cancelActiveWorkout,
        isWorkoutModalOpen,
        setIsWorkoutModalOpen,
        isTimerRunning,
        isTimerPaused,
        timerSecondsLeft,
        timerTotalDuration,
        timerJustFinished,
        isTimerModalOpen,
        setIsTimerModalOpen,
        startRestTimer,
        pauseRestTimer,
        resumeRestTimer,
        resetRestTimer,
        adjustRestTimer,
        stopRestTimer,
        recentPRNotification,
        dismissPRNotification,
        triggerPRNotification,
        recentAchievementNotification,
        dismissAchievementNotification,
        triggerAchievementNotification,
        levelUpTierNotification,
        dismissLevelUpTierNotification,
        triggerLevelUpTierNotification,
        dailyHabits,
        toggleDailyHabit,
        addDailyHabit,
        deleteDailyHabit,
        exportDataJSON,
        importDataJSON,
        resetAllData
      }}
    >
      {children}
    </WorkoutContext.Provider>
  );
};

export function useWorkout() {
  const context = useContext(WorkoutContext);
  if (!context) {
    throw new Error('useWorkout must be used within a WorkoutProvider');
  }
  return context;
}
