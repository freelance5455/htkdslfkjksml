import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserRole,
  ProviderProfile,
  ServiceCategory,
  Booking,
  Review,
  ChatMessage,
  AppNotification,
  UserReport,
  PlatformSettings,
  BookingStatus,
} from '../types';
import {
  INITIAL_CATEGORIES,
  INITIAL_PROVIDERS,
  INITIAL_USERS,
  INITIAL_BOOKINGS,
  INITIAL_REVIEWS,
  INITIAL_SETTINGS,
  INITIAL_REPORTS,
} from '../data/mockData';
import { KARACHI_AREAS, KarachiArea } from '../utils/geo';
import { Language, translations } from '../utils/i18n';
import { authService, RegisterPayload } from '../services/authService';

interface MohallaContextType {
  currentUser: User;
  switchUserRole: (role: UserRole) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations['en']) => string;
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  selectedArea: KarachiArea;
  setSelectedArea: (area: KarachiArea) => void;
  categories: ServiceCategory[];
  providers: ProviderProfile[];
  bookings: Booking[];
  reviews: Review[];
  chatMessages: ChatMessage[];
  notifications: AppNotification[];
  reports: UserReport[];
  favorites: string[];
  settings: PlatformSettings;
  
  // Actions
  toggleFavorite: (providerId: string) => void;
  createBooking: (bookingData: Omit<Booking, 'id' | 'createdAt' | 'updatedAt' | 'statusHistory' | 'hasReview' | 'status' | 'platformCommissionRate'>) => Booking;
  updateBookingStatus: (bookingId: string, newStatus: BookingStatus, note?: string, extraData?: Partial<Booking>) => void;
  submitReview: (bookingId: string, providerId: string, rating: number, comment: string, tags?: string[]) => void;
  sendChatMessage: (bookingId: string, text: string, senderRole: 'customer' | 'provider') => void;
  toggleProviderAvailability: (providerId: string) => void;
  approveProviderVerification: (providerId: string) => void;
  rejectProviderVerification: (providerId: string, reason: string) => void;
  updateSettings: (newSettings: Partial<PlatformSettings>) => void;
  submitReport: (report: Omit<UserReport, 'id' | 'createdAt' | 'status'>) => void;
  addCategory: (category: ServiceCategory) => void;
  markNotificationRead: (notifId: string) => void;
  unreadNotificationCount: number;
  resetAllData: () => void;

  // Authentication & Security
  isAuthenticated: boolean;
  loginUser: (identifier: string, password: string, expectedRole?: UserRole) => Promise<User>;
  adminLoginUser: (identifier: string, password: string) => Promise<User>;
  registerUser: (payload: any) => Promise<User>;
  logoutUser: () => Promise<void>;
  showAuthModal: boolean;
  openAuthModal: (defaultRole?: UserRole, defaultMode?: 'login' | 'signup') => void;
  closeAuthModal: () => void;
  authModalConfig: { role: UserRole; mode: 'login' | 'signup' };
}

const MohallaContext = createContext<MohallaContextType | undefined>(undefined);

export const MohallaProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Authentication & session state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return !!localStorage.getItem('mohalla_auth_token');
  });

  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authModalConfig, setAuthModalConfig] = useState<{ role: UserRole; mode: 'login' | 'signup' }>({
    role: 'customer',
    mode: 'login',
  });

  // Load state or fallback to defaults
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem('mohalla_user');
    const token = localStorage.getItem('mohalla_auth_token');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.role === 'admin' && !token) {
          return INITIAL_USERS[0];
        }
        return parsed;
      } catch {
        return INITIAL_USERS[0];
      }
    }
    return INITIAL_USERS[0]; // Default to customer
  });

  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('mohalla_lang') as Language) || 'en';
  });

  const [selectedCity, setSelectedCity] = useState<string>('Karachi');
  const [selectedArea, setSelectedArea] = useState<KarachiArea>(() => KARACHI_AREAS[0]); // Gulshan-e-Iqbal

  const [categories, setCategories] = useState<ServiceCategory[]>(() => {
    const saved = localStorage.getItem('mohalla_categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [providers, setProviders] = useState<ProviderProfile[]>(() => {
    const saved = localStorage.getItem('mohalla_providers');
    return saved ? JSON.parse(saved) : INITIAL_PROVIDERS;
  });

  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem('mohalla_bookings');
    return saved ? JSON.parse(saved) : INITIAL_BOOKINGS;
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem('mohalla_reviews');
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('mohalla_chats');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'msg_1',
        bookingId: 'bk_101',
        senderId: 'u_prov_1',
        senderRole: 'provider',
        text: 'Assalam-o-Alaikum Ahmed bhai! I have accepted your request. Leaving Gulshan block 13-D on my bike now.',
        timestamp: '2026-10-20T08:10:00Z',
        read: true,
      },
      {
        id: 'msg_2',
        bookingId: 'bk_101',
        senderId: 'u_customer_demo',
        senderRole: 'customer',
        text: 'Walaikum Assalam Ali bhai. House is right beside Disco Bakery, let me know when you reach main street.',
        timestamp: '2026-10-20T08:12:00Z',
        read: true,
      },
      {
        id: 'msg_3',
        bookingId: 'bk_101',
        senderId: 'u_prov_1',
        senderRole: 'provider',
        text: 'Noted! I am at your street corner now.',
        timestamp: '2026-10-20T08:24:00Z',
        read: false,
      },
    ];
  });

  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'notif_1',
      userId: 'u_customer_demo',
      title: 'Provider Arriving',
      message: 'Ali Electrician is arriving at your location (1.2 km away).',
      type: 'booking',
      bookingId: 'bk_101',
      read: false,
      createdAt: new Date().toISOString(),
    },
  ]);

  const [reports, setReports] = useState<UserReport[]>(() => {
    const saved = localStorage.getItem('mohalla_reports');
    return saved ? JSON.parse(saved) : INITIAL_REPORTS;
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('mohalla_favorites');
    return saved ? JSON.parse(saved) : ['prov_1', 'prov_3'];
  });

  const [settings, setSettings] = useState<PlatformSettings>(() => {
    const saved = localStorage.getItem('mohalla_settings');
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('mohalla_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('mohalla_lang', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('mohalla_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('mohalla_providers', JSON.stringify(providers));
  }, [providers]);

  useEffect(() => {
    localStorage.setItem('mohalla_bookings', JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    localStorage.setItem('mohalla_reviews', JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem('mohalla_chats', JSON.stringify(chatMessages));
  }, [chatMessages]);

  useEffect(() => {
    localStorage.setItem('mohalla_reports', JSON.stringify(reports));
  }, [reports]);

  useEffect(() => {
    localStorage.setItem('mohalla_favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('mohalla_settings', JSON.stringify(settings));
  }, [settings]);

  // Switch role helper
  const switchUserRole = (role: UserRole) => {
    if (role === 'customer') {
      setCurrentUser(INITIAL_USERS[0]);
    } else if (role === 'provider') {
      setCurrentUser(INITIAL_USERS[1]);
    } else {
      // Security: Admin access strictly requires server authentication
      openAuthModal('admin', 'login');
    }
  };

  // Translation helper
  const t = (key: keyof typeof translations['en']): string => {
    return translations[language][key] || translations['en'][key] || key;
  };

  // Toggle favorite
  const toggleFavorite = (providerId: string) => {
    setFavorites((prev) =>
      prev.includes(providerId) ? prev.filter((id) => id !== providerId) : [...prev, providerId]
    );
  };

  // Create booking
  const createBooking = (
    bookingData: Omit<Booking, 'id' | 'createdAt' | 'updatedAt' | 'statusHistory' | 'hasReview' | 'status' | 'platformCommissionRate'>
  ): Booking => {
    const newId = `bk_${Date.now()}`;
    const now = new Date().toISOString();
    const newBooking: Booking = {
      ...bookingData,
      id: newId,
      status: 'PENDING',
      platformCommissionRate: settings.commissionPercentage / 100,
      hasReview: false,
      statusHistory: [
        {
          status: 'PENDING',
          timestamp: now,
          note: 'Booking requested by customer',
        },
      ],
      createdAt: now,
      updatedAt: now,
    };

    setBookings((prev) => [newBooking, ...prev]);

    // Send notification
    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: bookingData.providerId,
        title: 'New Booking Request!',
        message: `${bookingData.customerName} requested ${bookingData.categoryName} service in ${bookingData.location.area}.`,
        type: 'booking',
        bookingId: newId,
        read: false,
        createdAt: now,
      },
      ...prev,
    ]);

    return newBooking;
  };

  // Update booking status
  const updateBookingStatus = (
    bookingId: string,
    newStatus: BookingStatus,
    note?: string,
    extraData?: Partial<Booking>
  ) => {
    const now = new Date().toISOString();
    setBookings((prev) =>
      prev.map((b) => {
        if (b.id !== bookingId) return b;

        let platformCommissionAmount = b.platformCommissionAmount;
        let providerEarnings = b.providerEarnings;
        let finalBill = extraData?.finalBill ?? b.finalBill;

        // If completed, compute commission and provider earnings
        if (newStatus === 'COMPLETED') {
          const totalAmount = finalBill || (b.visitFee + (extraData?.additionalCharges || 0));
          finalBill = totalAmount;
          platformCommissionAmount = Math.round(totalAmount * (b.platformCommissionRate || 0.1));
          providerEarnings = totalAmount - platformCommissionAmount;
        }

        const updated: Booking = {
          ...b,
          ...extraData,
          status: newStatus,
          finalBill,
          platformCommissionAmount,
          providerEarnings,
          updatedAt: now,
          statusHistory: [
            ...b.statusHistory,
            {
              status: newStatus,
              timestamp: now,
              note: note || `Status updated to ${newStatus}`,
            },
          ],
        };
        return updated;
      })
    );

    // If completed, increment provider's completed jobs and recalculate trust score
    if (newStatus === 'COMPLETED') {
      const currentBooking = bookings.find((b) => b.id === bookingId);
      if (currentBooking) {
        setProviders((prev) =>
          prev.map((p) => {
            if (p.id !== currentBooking.providerId) return p;
            const newJobs = p.completedJobs + 1;
            // Trust score algorithm: verification (30) + rating weight (40) + jobs volume (20) + on-time (10)
            const ratingScore = (p.rating / 5) * 40;
            const verificationScore = p.verificationStatus === 'verified' ? 30 : 10;
            const volumeScore = Math.min(20, (newJobs / 100) * 20);
            const onTimeScore = (p.onTimePercentage / 100) * 10;
            const newTrust = Math.round(ratingScore + verificationScore + volumeScore + onTimeScore);

            return {
              ...p,
              completedJobs: newJobs,
              trustScore: Math.min(100, Math.max(50, newTrust)),
            };
          })
        );
      }
    }

    // Add alert notification
    const targetBooking = bookings.find((b) => b.id === bookingId);
    if (targetBooking) {
      setNotifications((prev) => [
        {
          id: `notif_${Date.now()}`,
          userId: targetBooking.customerId,
          title: `Booking ${newStatus}`,
          message: `Your booking with ${targetBooking.providerName} is now ${newStatus}.`,
          type: 'booking',
          bookingId: bookingId,
          read: false,
          createdAt: now,
        },
        ...prev,
      ]);
    }
  };

  // Submit Review
  const submitReview = (
    bookingId: string,
    providerId: string,
    rating: number,
    comment: string,
    tags?: string[]
  ) => {
    const newReview: Review = {
      id: `rev_${Date.now()}`,
      bookingId,
      customerId: currentUser.id,
      customerName: currentUser.name,
      providerId,
      rating,
      comment,
      tags: tags || ['Polite', 'Recommended'],
      createdAt: new Date().toISOString(),
    };

    setReviews((prev) => [newReview, ...prev]);

    // Update booking hasReview
    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, hasReview: true } : b))
    );

    // Update provider's overall rating
    setProviders((prev) =>
      prev.map((p) => {
        if (p.id !== providerId) return p;
        const totalReviews = p.reviewCount + 1;
        const newRating = Number(
          ((p.rating * p.reviewCount + rating) / totalReviews).toFixed(1)
        );
        return {
          ...p,
          rating: newRating,
          reviewCount: totalReviews,
        };
      })
    );
  };

  // Chat message
  const sendChatMessage = (
    bookingId: string,
    text: string,
    senderRole: 'customer' | 'provider'
  ) => {
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      bookingId,
      senderId: currentUser.id,
      senderRole,
      text,
      timestamp: new Date().toISOString(),
      read: false,
    };
    setChatMessages((prev) => [...prev, newMsg]);
  };

  // Provider toggle available
  const toggleProviderAvailability = (providerId: string) => {
    setProviders((prev) =>
      prev.map((p) =>
        p.id === providerId ? { ...p, isAvailableNow: !p.isAvailableNow } : p
      )
    );
  };

  // Admin approves verification
  const approveProviderVerification = (providerId: string) => {
    setProviders((prev) =>
      prev.map((p) =>
        p.id === providerId
          ? {
              ...p,
              verificationStatus: 'verified',
              verificationBadge: 'Identity & Documents Verified',
              trustScore: Math.min(100, p.trustScore + 15),
            }
          : p
      )
    );
  };

  // Admin rejects verification
  const rejectProviderVerification = (providerId: string, reason: string) => {
    setProviders((prev) =>
      prev.map((p) =>
        p.id === providerId
          ? {
              ...p,
              verificationStatus: 'rejected',
              verificationBadge: `Rejected: ${reason}`,
            }
          : p
      )
    );
  };

  // Update platform settings
  const updateSettings = (newSettings: Partial<PlatformSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Submit report
  const submitReport = (report: Omit<UserReport, 'id' | 'createdAt' | 'status'>) => {
    const newReport: UserReport = {
      ...report,
      id: `rep_${Date.now()}`,
      status: 'OPEN',
      createdAt: new Date().toISOString(),
    };
    setReports((prev) => [newReport, ...prev]);
  };

  // Add category
  const addCategory = (cat: ServiceCategory) => {
    setCategories((prev) => [...prev, cat]);
  };

  // Mark notification read
  const markNotificationRead = (notifId: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notifId ? { ...n, read: true } : n))
    );
  };

  const unreadNotificationCount = notifications.filter((n) => !n.read).length;

  // Check session token on initial mount
  useEffect(() => {
    const checkSession = async () => {
      try {
        const session = await authService.getCurrentUser();
        if (session && session.user) {
          setCurrentUser(session.user);
          setIsAuthenticated(true);
        } else if (!authService.getToken()) {
          setIsAuthenticated(false);
        }
      } catch (err) {
        console.error('Session check failed:', err);
      }
    };
    checkSession();
  }, []);

  const openAuthModal = (defaultRole: UserRole = 'customer', defaultMode: 'login' | 'signup' = 'login') => {
    setAuthModalConfig({ role: defaultRole, mode: defaultMode });
    setShowAuthModal(true);
  };

  const closeAuthModal = () => {
    setShowAuthModal(false);
  };

  const loginUser = async (identifier: string, password: string, expectedRole?: UserRole): Promise<User> => {
    const response = await authService.login(identifier, password, expectedRole);
    setCurrentUser(response.user);
    setIsAuthenticated(true);
    closeAuthModal();

    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: response.user.id,
        title: 'Welcome Back!',
        message: `Logged in successfully as ${response.user.name}.`,
        type: 'system',
        read: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);

    return response.user;
  };

  const adminLoginUser = async (identifier: string, password: string): Promise<User> => {
    const response = await authService.adminLogin(identifier, password);
    setCurrentUser(response.user);
    setIsAuthenticated(true);
    closeAuthModal();

    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: response.user.id,
        title: 'Admin Session Activated',
        message: 'Mohalla Central Operations dashboard unlocked.',
        type: 'system',
        read: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);

    return response.user;
  };

  const registerUser = async (payload: RegisterPayload): Promise<User> => {
    const response = await authService.register(payload);
    setCurrentUser(response.user);
    setIsAuthenticated(true);
    closeAuthModal();

    // If new service provider registered, instantiate their ProviderProfile
    if (payload.role === 'provider') {
      const newProvId = `prov_${Date.now()}`;
      const newProviderProfile: ProviderProfile = {
        id: newProvId,
        userId: response.user.id,
        businessName: payload.providerDetails?.businessName || `${response.user.name} Services`,
        category: payload.providerDetails?.category || 'electrician',
        subServices: payload.providerDetails?.subServices || ['General Repairs', 'Diagnostic Check'],
        bio: `Verified local technician based in ${response.user.area || 'Karachi'}. Professional quality workmanship guaranteed.`,
        visitCharge: Number(payload.providerDetails?.visitCharge) || 500,
        rating: 5.0,
        reviewCount: 0,
        completedJobs: 0,
        trustScore: 85,
        verificationStatus: 'pending',
        verificationBadge: 'Under KYC Verification',
        isAvailableNow: true,
        city: 'Karachi',
        serviceAreas: payload.providerDetails?.serviceAreas || [response.user.area || 'Gulshan-e-Iqbal'],
        serviceRadiusKm: 6.0,
        location: {
          lat: selectedArea.lat,
          lng: selectedArea.lng,
          areaName: response.user.area || selectedArea.name,
        },
        cnicMasked: payload.providerDetails?.cnicMasked || '42101-*******-5',
        responseTimeMinutes: 15,
        onTimePercentage: 100,
        cancellationRatePercentage: 0,
        portfolio: [],
        emergencyService: true,
        weeklySchedule: {
          Monday: { open: '08:00', close: '20:00', active: true },
          Tuesday: { open: '08:00', close: '20:00', active: true },
          Wednesday: { open: '08:00', close: '20:00', active: true },
          Thursday: { open: '08:00', close: '20:00', active: true },
          Friday: { open: '08:00', close: '20:00', active: true },
          Saturday: { open: '08:00', close: '20:00', active: true },
          Sunday: { open: '10:00', close: '18:00', active: true },
        },
      };

      setProviders((prev) => [newProviderProfile, ...prev]);
    }

    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: response.user.id,
        title: 'Account Created Successfully!',
        message: `Welcome to Mohalla, ${response.user.name}.`,
        type: 'system',
        read: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);

    return response.user;
  };

  const logoutUser = async () => {
    await authService.logout();
    setIsAuthenticated(false);
    setCurrentUser(INITIAL_USERS[0]);
  };

  const resetAllData = () => {
    localStorage.clear();
    setCategories(INITIAL_CATEGORIES);
    setProviders(INITIAL_PROVIDERS);
    setBookings(INITIAL_BOOKINGS);
    setReviews(INITIAL_REVIEWS);
    setReports(INITIAL_REPORTS);
    setSettings(INITIAL_SETTINGS);
    setCurrentUser(INITIAL_USERS[0]);
    setIsAuthenticated(false);
  };

  return (
    <MohallaContext.Provider
      value={{
        currentUser,
        switchUserRole,
        language,
        setLanguage,
        t,
        selectedCity,
        setSelectedCity,
        selectedArea,
        setSelectedArea,
        categories,
        providers,
        bookings,
        reviews,
        chatMessages,
        notifications,
        reports,
        favorites,
        settings,
        toggleFavorite,
        createBooking,
        updateBookingStatus,
        submitReview,
        sendChatMessage,
        toggleProviderAvailability,
        approveProviderVerification,
        rejectProviderVerification,
        updateSettings,
        submitReport,
        addCategory,
        markNotificationRead,
        unreadNotificationCount,
        resetAllData,

        // Authentication & Session
        isAuthenticated,
        loginUser,
        adminLoginUser,
        registerUser,
        logoutUser,
        showAuthModal,
        openAuthModal,
        closeAuthModal,
        authModalConfig,
      }}
    >
      {children}
    </MohallaContext.Provider>
  );
};

export const useMohalla = () => {
  const context = useContext(MohallaContext);
  if (!context) {
    throw new Error('useMohalla must be used within a MohallaProvider');
  }
  return context;
};
