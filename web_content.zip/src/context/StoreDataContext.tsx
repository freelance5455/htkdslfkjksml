import React, { createContext, useContext, useEffect, useState } from 'react';
import { collection, doc, onSnapshot, orderBy, query } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { DEFAULT_STORE_SETTINGS } from '../lib/catalogDefaults';
import { Category, Product, StoreSettings } from '../types/store';

export interface ToastNotice {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface StoreDataContextValue {
  products: Product[];
  categories: Category[];
  settings: StoreSettings;
  catalogLoading: boolean;
  toasts: ToastNotice[];
  notify: (message: string, type?: 'success' | 'error' | 'info') => void;
  dismissToast: (id: string) => void;
}

const StoreDataContext = createContext<StoreDataContextValue | null>(null);

export function StoreDataProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<StoreSettings>(DEFAULT_STORE_SETTINGS);
  const [catalogLoading, setCatalogLoading] = useState(true);
  const [toasts, setToasts] = useState<ToastNotice[]>([]);

  const notify = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-3), { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  useEffect(() => {
    let productsLoaded = false;
    let categoriesLoaded = false;

    const markLoaded = () => {
      if (productsLoaded && categoriesLoaded) {
        setCatalogLoading(false);
      }
    };

    const prodUnsub = onSnapshot(
      query(collection(db, 'products'), orderBy('createdAt', 'desc')),
      (snap) => {
        const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as Product));
        setProducts(list);
        productsLoaded = true;
        markLoaded();
      },
      (error) => {
        productsLoaded = true;
        markLoaded();
        handleFirestoreError(error, OperationType.LIST, 'products');
      }
    );

    const catUnsub = onSnapshot(
      query(collection(db, 'categories'), orderBy('displayOrder', 'asc')),
      (snap) => {
        const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as Category));
        setCategories(list);
        categoriesLoaded = true;
        markLoaded();
      },
      (error) => {
        categoriesLoaded = true;
        markLoaded();
        handleFirestoreError(error, OperationType.LIST, 'categories');
      }
    );

    const settingsUnsub = onSnapshot(
      doc(db, 'settings', 'storeConfig'),
      (snap) => {
        if (snap.exists()) {
          const data = snap.data() as StoreSettings;
          setSettings({
            ...data,
            storeName:
              !data.storeName || data.storeName.trim().toUpperCase() === 'STYLEHUB'
                ? 'Fashion Hub'
                : data.storeName,
            supportEmail:
              data.supportEmail === 'concierge@stylehub-atelier.com'
                ? 'concierge@fashionhub-atelier.com'
                : data.supportEmail,
            announcementText: data.announcementText
              ? data.announcementText.replace(/\$/g, '₹')
              : data.announcementText,
          });
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, 'settings/storeConfig');
      }
    );

    return () => {
      prodUnsub();
      catUnsub();
      settingsUnsub();
    };
  }, []);

  return (
    <StoreDataContext.Provider
      value={{
        products,
        categories,
        settings,
        catalogLoading,
        toasts,
        notify,
        dismissToast,
      }}
    >
      {children}
    </StoreDataContext.Provider>
  );
}

export function useStoreData() {
  const ctx = useContext(StoreDataContext);
  if (!ctx) throw new Error('useStoreData must be used within StoreDataProvider');
  return ctx;
}
