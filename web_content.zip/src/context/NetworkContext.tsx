/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { 
  NetworkDevice, 
  MetricHistoryPoint, 
  RouterConfig, 
  WifiChannelInfo, 
  DnsBenchmarkResult, 
  GameServerPing, 
  PriorityTier 
} from '../types/network';
import { 
  INITIAL_DEVICES, 
  INITIAL_ROUTER_CONFIG, 
  INITIAL_CHANNELS_24, 
  INITIAL_CHANNELS_5, 
  DNS_SERVERS, 
  GAME_SERVERS 
} from '../data/mockNetworkData';

interface NetworkMetrics {
  currentDownloadMbps: number;
  currentUploadMbps: number;
  pingMs: number;
  jitterMs: number;
  packetLossPct: number;
  bufferbloatGrade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
  mosScore: number; // 1.0 to 5.0
  dnsResponseMs: number;
  totalDownloadedGb: number;
  totalUploadedGb: number;
  peakDownloadMbps: number;
  peakUploadMbps: number;
  ispName: string;
  gatewayIp: string;
  publicIp: string;
  wifiSsid: string;
  wifiBand: string;
  wifiSignalDbm: number;
  linkSpeedMbps: number;
}

export type DistributionMode = 'dynamic_fair' | 'gaming_first' | 'work_focus' | 'equal_split';

interface GamingConfig {
  enabled: boolean;
  algorithm: 'Cake (SQM)' | 'fq_codel' | 'Adaptive QoS';
  dscpTagging: boolean;
  bufferbloatMitigation: boolean;
  bandwidthCeilingPct: number; // usually 90-95% to avoid buffer buildup
}

interface SpeedTestState {
  isRunning: boolean;
  phase: 'idle' | 'ping' | 'download' | 'upload' | 'completed';
  progress: number; // 0-100
  currentSpeedMbps: number;
  resultPing: number;
  resultJitter: number;
  resultDownload: number;
  resultUpload: number;
  resultBufferbloat: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
}

interface NetworkContextType {
  metrics: NetworkMetrics;
  history: MetricHistoryPoint[];
  devices: NetworkDevice[];
  router: RouterConfig;
  gamingConfig: GamingConfig;
  distributionMode: DistributionMode;
  ispBandwidthLimitMbps: number;
  channels24: WifiChannelInfo[];
  channels5: WifiChannelInfo[];
  dnsServers: DnsBenchmarkResult[];
  gameServers: GameServerPing[];
  isScanningDevices: boolean;
  scanProgress: number;
  speedTest: SpeedTestState;
  
  // Actions
  toggleDevicePause: (deviceId: string) => void;
  updateDeviceLimits: (deviceId: string, dlLimit: number | null, ulLimit: number | null) => void;
  updateDevicePriority: (deviceId: string, tier: PriorityTier) => void;
  toggleDeviceGamingPriority: (deviceId: string) => void;
  updateDeviceDetails: (deviceId: string, alias: string, staticIp?: boolean) => void;
  addDevice: (device: Omit<NetworkDevice, 'id'>) => void;
  removeDevice: (deviceId: string) => void;
  scanForDevices: () => Promise<void>;
  
  setGamingModeEnabled: (enabled: boolean) => void;
  updateGamingConfig: (config: Partial<GamingConfig>) => void;
  
  setDistributionMode: (mode: DistributionMode) => void;
  setIspBandwidthLimit: (limit: number) => void;
  
  applyChannelOptimization: (band: '2.4GHz' | '5GHz', newChannel: number) => void;
  applyDnsServer: (dnsName: string) => void;
  runDnsBenchmark: () => Promise<void>;
  
  startSpeedTest: () => void;
  stopSpeedTest: () => void;
  
  updateRouterConfig: (config: Partial<RouterConfig>) => void;
  simulateRouterReboot: () => Promise<void>;
}

const NetworkContext = createContext<NetworkContextType | undefined>(undefined);

const LOCAL_STORAGE_DEVICES_KEY = 'netpulse_devices_v1';
const LOCAL_STORAGE_GAMING_KEY = 'netpulse_gaming_v1';
const LOCAL_STORAGE_ROUTER_KEY = 'netpulse_router_v1';
const LOCAL_STORAGE_DISTRIB_KEY = 'netpulse_distrib_v1';

export const NetworkProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Saved states
  const [devices, setDevices] = useState<NetworkDevice[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_DEVICES_KEY);
      return saved ? JSON.parse(saved) : INITIAL_DEVICES;
    } catch {
      return INITIAL_DEVICES;
    }
  });

  const [router, setRouter] = useState<RouterConfig>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_ROUTER_KEY);
      return saved ? JSON.parse(saved) : INITIAL_ROUTER_CONFIG;
    } catch {
      return INITIAL_ROUTER_CONFIG;
    }
  });

  const [gamingConfig, setGamingConfig] = useState<GamingConfig>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_GAMING_KEY);
      return saved ? JSON.parse(saved) : {
        enabled: true,
        algorithm: 'Cake (SQM)',
        dscpTagging: true,
        bufferbloatMitigation: true,
        bandwidthCeilingPct: 92,
      };
    } catch {
      return {
        enabled: true,
        algorithm: 'Cake (SQM)',
        dscpTagging: true,
        bufferbloatMitigation: true,
        bandwidthCeilingPct: 92,
      };
    }
  });

  const [distributionMode, setDistributionMode] = useState<DistributionMode>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_DISTRIB_KEY);
      return (saved as DistributionMode) || 'dynamic_fair';
    } catch {
      return 'dynamic_fair';
    }
  });

  const [ispBandwidthLimitMbps, setIspBandwidthLimitMbps] = useState<number>(500);
  const [channels24, setChannels24] = useState<WifiChannelInfo[]>(INITIAL_CHANNELS_24);
  const [channels5, setChannels5] = useState<WifiChannelInfo[]>(INITIAL_CHANNELS_5);
  const [dnsServers, setDnsServers] = useState<DnsBenchmarkResult[]>(DNS_SERVERS);
  const [gameServers, setGameServers] = useState<GameServerPing[]>(GAME_SERVERS);

  const [isScanningDevices, setIsScanningDevices] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);

  // Speed test state
  const [speedTest, setSpeedTest] = useState<SpeedTestState>({
    isRunning: false,
    phase: 'idle',
    progress: 0,
    currentSpeedMbps: 0,
    resultPing: 14,
    resultJitter: 2,
    resultDownload: 486.2,
    resultUpload: 88.5,
    resultBufferbloat: 'A+',
  });

  // Base metrics state
  const [metrics, setMetrics] = useState<NetworkMetrics>({
    currentDownloadMbps: 184.2,
    currentUploadMbps: 28.6,
    pingMs: 16,
    jitterMs: 1.8,
    packetLossPct: 0.0,
    bufferbloatGrade: 'A+',
    mosScore: 4.8,
    dnsResponseMs: 11,
    totalDownloadedGb: 28.4,
    totalUploadedGb: 5.6,
    peakDownloadMbps: 488.5,
    peakUploadMbps: 92.1,
    ispName: 'Comcast / Xfinity Gigabit Fiber',
    gatewayIp: '192.168.1.1',
    publicIp: '73.189.42.118',
    wifiSsid: 'HomeNet_5G_Pro',
    wifiBand: '5GHz (Wi-Fi 6 AX)',
    wifiSignalDbm: -44,
    linkSpeedMbps: 1201,
  });

  // Rolling history for live SVG / Canvas graph (last 40 points)
  const [history, setHistory] = useState<MetricHistoryPoint[]>(() => {
    const initial: MetricHistoryPoint[] = [];
    const now = Date.now();
    for (let i = 30; i >= 0; i--) {
      const d = new Date(now - i * 2000);
      const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      initial.push({
        time: timeStr,
        download: Math.floor(140 + Math.sin(i * 0.5) * 60 + Math.random() * 20),
        upload: Math.floor(20 + Math.cos(i * 0.4) * 10 + Math.random() * 5),
        ping: Math.floor(14 + Math.random() * 6),
        jitter: +(1 + Math.random() * 1.5).toFixed(1),
      });
    }
    return initial;
  });

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_DEVICES_KEY, JSON.stringify(devices));
  }, [devices]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_GAMING_KEY, JSON.stringify(gamingConfig));
  }, [gamingConfig]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_ROUTER_KEY, JSON.stringify(router));
  }, [router]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_DISTRIB_KEY, distributionMode);
  }, [distributionMode]);

  // Real ping helper: ping an active HTTP endpoint to measure true browser latency
  const measureRealPing = useCallback(async () => {
    try {
      const start = performance.now();
      // Fast HEAD / no-cache fetch to detect live network responsiveness
      await fetch('/manifest.webmanifest?ping=' + Date.now(), { method: 'HEAD', cache: 'no-store' });
      const duration = Math.round(performance.now() - start);
      return Math.max(4, Math.min(duration, 150));
    } catch {
      return 15 + Math.floor(Math.random() * 5);
    }
  }, []);

  // Real-time dynamic simulator tick (runs every 2 seconds)
  useEffect(() => {
    const interval = setInterval(async () => {
      // If speed test is currently taking over, skip periodic simulation fluctuation
      if (speedTest.isRunning) return;

      const liveBrowserPing = await measureRealPing();

      setDevices(prevDevices => {
        return prevDevices.map(dev => {
          if (!dev.isOnline || dev.isPaused) {
            return { ...dev, currentDlMbps: 0, currentUlMbps: 0 };
          }

          // Compute realistic variation around device's typical bandwidth
          let baseDl = dev.currentDlMbps;
          let baseUl = dev.currentUlMbps;

          // Introduce small organic fluctuations
          const dlDelta = (Math.random() - 0.48) * 4;
          const ulDelta = (Math.random() - 0.48) * 1.5;

          baseDl = Math.max(0.1, baseDl + dlDelta);
          baseUl = Math.max(0.05, baseUl + ulDelta);

          // Apply Bandwidth limits if configured
          if (dev.downloadLimitMbps !== null) {
            baseDl = Math.min(baseDl, dev.downloadLimitMbps);
          }
          if (dev.uploadLimitMbps !== null) {
            baseUl = Math.min(baseUl, dev.uploadLimitMbps);
          }

          // Apply Gaming priority bonus or distribution mode weight
          if (gamingConfig.enabled && dev.isGamingPriority) {
            // Gaming traffic is kept stable and prioritized
            baseDl = Math.max(baseDl, 35);
          } else if (gamingConfig.enabled && !dev.isGamingPriority && dev.type === 'iot') {
            // IoT slightly deprioritized during gaming mode
            baseDl = Math.min(baseDl, 4);
          }

          return {
            ...dev,
            currentDlMbps: +baseDl.toFixed(1),
            currentUlMbps: +baseUl.toFixed(1),
            totalUsageMb: dev.totalUsageMb + Math.round((baseDl + baseUl) * 0.25),
          };
        });
      });

      // Update total download & upload throughput
      setMetrics(prev => {
        const totalDl = devices
          .filter(d => d.isOnline && !d.isPaused)
          .reduce((acc, d) => acc + d.currentDlMbps, 0);

        const totalUl = devices
          .filter(d => d.isOnline && !d.isPaused)
          .reduce((acc, d) => acc + d.currentUlMbps, 0);

        const activeDl = +Math.max(12, totalDl).toFixed(1);
        const activeUl = +Math.max(3, totalUl).toFixed(1);

        // Ping calculation: if gaming mode is enabled, jitter is reduced by SQM Cake
        let ping = liveBrowserPing;
        let jitter = 1.2;
        let grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F' = 'A+';
        let mos = 4.85;

        if (gamingConfig.enabled) {
          // Zero bufferbloat under SQM Cake
          ping = Math.min(ping, 18);
          jitter = +(0.8 + Math.random() * 0.8).toFixed(1);
          grade = 'A+';
          mos = 4.9;
        } else {
          // High load induces bufferbloat when gaming mode is off
          if (activeDl > 250) {
            ping += 35;
            jitter = +(4 + Math.random() * 6).toFixed(1);
            grade = 'C';
            mos = 3.6;
          } else {
            grade = 'A';
            mos = 4.4;
          }
        }

        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

        setHistory(prevHistory => {
          const next = [...prevHistory.slice(1), {
            time: timeStr,
            download: activeDl,
            upload: activeUl,
            ping,
            jitter,
          }];
          return next;
        });

        return {
          ...prev,
          currentDownloadMbps: activeDl,
          currentUploadMbps: activeUl,
          pingMs: ping,
          jitterMs: jitter,
          bufferbloatGrade: grade,
          mosScore: mos,
          totalDownloadedGb: +(prev.totalDownloadedGb + (activeDl * 0.25) / 8000).toFixed(2),
          totalUploadedGb: +(prev.totalUploadedGb + (activeUl * 0.25) / 8000).toFixed(2),
          peakDownloadMbps: Math.max(prev.peakDownloadMbps, activeDl),
          peakUploadMbps: Math.max(prev.peakUploadMbps, activeUl),
        };
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [devices, gamingConfig, speedTest.isRunning, measureRealPing]);

  // Actions
  const toggleDevicePause = useCallback((deviceId: string) => {
    setDevices(prev => prev.map(d => {
      if (d.id === deviceId) {
        return { ...d, isPaused: !d.isPaused };
      }
      return d;
    }));
  }, []);

  const updateDeviceLimits = useCallback((deviceId: string, dlLimit: number | null, ulLimit: number | null) => {
    setDevices(prev => prev.map(d => {
      if (d.id === deviceId) {
        return { 
          ...d, 
          downloadLimitMbps: dlLimit, 
          uploadLimitMbps: ulLimit 
        };
      }
      return d;
    }));
  }, []);

  const updateDevicePriority = useCallback((deviceId: string, tier: PriorityTier) => {
    setDevices(prev => prev.map(d => {
      if (d.id === deviceId) {
        return { ...d, priorityTier: tier };
      }
      return d;
    }));
  }, []);

  const toggleDeviceGamingPriority = useCallback((deviceId: string) => {
    setDevices(prev => prev.map(d => {
      if (d.id === deviceId) {
        const nextVal = !d.isGamingPriority;
        return { 
          ...d, 
          isGamingPriority: nextVal,
          priorityTier: nextVal ? 'critical' : d.priorityTier 
        };
      }
      return d;
    }));
  }, []);

  const updateDeviceDetails = useCallback((deviceId: string, alias: string, staticIp?: boolean) => {
    setDevices(prev => prev.map(d => {
      if (d.id === deviceId) {
        return { 
          ...d, 
          customAlias: alias,
          staticIpAssigned: staticIp !== undefined ? staticIp : d.staticIpAssigned 
        };
      }
      return d;
    }));
  }, []);

  const addDevice = useCallback((newDev: Omit<NetworkDevice, 'id'>) => {
    const id = `dev-${Date.now()}`;
    setDevices(prev => [{ ...newDev, id }, ...prev]);
  }, []);

  const removeDevice = useCallback((deviceId: string) => {
    setDevices(prev => prev.filter(d => d.id !== deviceId));
  }, []);

  // Network discovery scanner
  const scanForDevices = useCallback(async () => {
    setIsScanningDevices(true);
    setScanProgress(5);

    for (let p = 15; p <= 100; p += 20) {
      await new Promise(r => setTimeout(r, 350));
      setScanProgress(p);
    }

    // Wake up offline devices or add an newly discovered smart IoT device
    setDevices(prev => {
      const hasUnfound = prev.some(d => !d.isOnline);
      if (hasUnfound) {
        return prev.map(d => ({ ...d, isOnline: true }));
      }
      // Add newly probed device
      const newDiscovered: NetworkDevice = {
        id: `dev-${Date.now()}`,
        name: 'Amazon Echo Dot (5th Gen)',
        customAlias: 'Kitchen Alexa',
        vendor: 'Amazon Technologies Inc.',
        ip: '192.168.1.155',
        mac: '50:F5:DA:44:90:3A',
        type: 'iot',
        isOnline: true,
        currentDlMbps: 0.2,
        currentUlMbps: 0.1,
        totalUsageMb: 120,
        downloadLimitMbps: null,
        uploadLimitMbps: null,
        isPaused: false,
        isGamingPriority: false,
        priorityTier: 'low',
        wifiBand: '2.4GHz',
        rssiDbm: -54,
        hostname: 'echo-kitchen',
        staticIpAssigned: false,
      };
      return [...prev, newDiscovered];
    });

    await new Promise(r => setTimeout(r, 300));
    setIsScanningDevices(false);
  }, []);

  const setGamingModeEnabled = useCallback((enabled: boolean) => {
    setGamingConfig(prev => ({ ...prev, enabled }));
  }, []);

  const updateGamingConfig = useCallback((config: Partial<GamingConfig>) => {
    setGamingConfig(prev => ({ ...prev, ...config }));
  }, []);

  // Channel optimizer
  const applyChannelOptimization = useCallback((band: '2.4GHz' | '5GHz', newChannel: number) => {
    if (band === '2.4GHz') {
      setChannels24(prev => prev.map(c => ({
        ...c,
        isCurrent: c.channel === newChannel,
        isRecommended: false,
      })));
    } else {
      setChannels5(prev => prev.map(c => ({
        ...c,
        isCurrent: c.channel === newChannel,
        isRecommended: false,
      })));
    }
  }, []);

  const applyDnsServer = useCallback((dnsName: string) => {
    setDnsServers(prev => prev.map(d => ({
      ...d,
      isCurrent: d.name === dnsName,
    })));
  }, []);

  const runDnsBenchmark = useCallback(async () => {
    // Re-test DNS latency with slight randomized jitter reflecting live internet
    setDnsServers(prev => prev.map(d => ({
      ...d,
      latencyMs: Math.max(6, Math.round(d.latencyMs + (Math.random() - 0.5) * 4)),
    })));
  }, []);

  // Speed test runner
  const startSpeedTest = useCallback(async () => {
    setSpeedTest({
      isRunning: true,
      phase: 'ping',
      progress: 10,
      currentSpeedMbps: 0,
      resultPing: 12,
      resultJitter: 1.5,
      resultDownload: 0,
      resultUpload: 0,
      resultBufferbloat: 'A+',
    });

    // Phase 1: Ping
    await new Promise(r => setTimeout(r, 1200));
    setSpeedTest(s => ({ ...s, phase: 'download', progress: 30, resultPing: 13, resultJitter: 1.8 }));

    // Phase 2: Download ramp up
    for (let p = 35; p <= 70; p += 5) {
      await new Promise(r => setTimeout(r, 200));
      const simulatedSpeed = Math.round(320 + Math.sin(p / 10) * 160 + (p / 70) * 60);
      setSpeedTest(s => ({
        ...s,
        progress: p,
        currentSpeedMbps: simulatedSpeed,
        resultDownload: simulatedSpeed,
      }));
    }

    // Phase 3: Upload ramp up
    setSpeedTest(s => ({ ...s, phase: 'upload', progress: 75 }));
    for (let p = 75; p <= 95; p += 5) {
      await new Promise(r => setTimeout(r, 220));
      const simulatedUpload = Math.round(75 + (p / 95) * 18);
      setSpeedTest(s => ({
        ...s,
        progress: p,
        currentSpeedMbps: simulatedUpload,
        resultUpload: simulatedUpload,
      }));
    }

    // Completion
    await new Promise(r => setTimeout(r, 300));
    setSpeedTest(s => ({
      ...s,
      isRunning: false,
      phase: 'completed',
      progress: 100,
      currentSpeedMbps: 0,
      resultDownload: 489.4,
      resultUpload: 91.8,
      resultPing: 14,
      resultJitter: 1.6,
      resultBufferbloat: 'A+',
    }));
  }, []);

  const stopSpeedTest = useCallback(() => {
    setSpeedTest(s => ({ ...s, isRunning: false, phase: 'idle', progress: 0 }));
  }, []);

  const updateRouterConfig = useCallback((cfg: Partial<RouterConfig>) => {
    setRouter(prev => ({ ...prev, ...cfg, lastSynced: 'Just now' }));
  }, []);

  const simulateRouterReboot = useCallback(async () => {
    setRouter(prev => ({ ...prev, connectedStatus: 'syncing' }));
    await new Promise(r => setTimeout(r, 2000));
    setRouter(prev => ({ 
      ...prev, 
      connectedStatus: 'connected', 
      uptime: '0 days, 0 hours, 1 min', 
      lastSynced: 'Just now' 
    }));
  }, []);

  const value = useMemo(() => ({
    metrics,
    history,
    devices,
    router,
    gamingConfig,
    distributionMode,
    ispBandwidthLimitMbps,
    channels24,
    channels5,
    dnsServers,
    gameServers,
    isScanningDevices,
    scanProgress,
    speedTest,
    toggleDevicePause,
    updateDeviceLimits,
    updateDevicePriority,
    toggleDeviceGamingPriority,
    updateDeviceDetails,
    addDevice,
    removeDevice,
    scanForDevices,
    setGamingModeEnabled,
    updateGamingConfig,
    setDistributionMode,
    setIspBandwidthLimit: setIspBandwidthLimitMbps,
    applyChannelOptimization,
    applyDnsServer,
    runDnsBenchmark,
    startSpeedTest,
    stopSpeedTest,
    updateRouterConfig,
    simulateRouterReboot,
  }), [
    metrics,
    history,
    devices,
    router,
    gamingConfig,
    distributionMode,
    ispBandwidthLimitMbps,
    channels24,
    channels5,
    dnsServers,
    gameServers,
    isScanningDevices,
    scanProgress,
    speedTest,
    toggleDevicePause,
    updateDeviceLimits,
    updateDevicePriority,
    toggleDeviceGamingPriority,
    updateDeviceDetails,
    addDevice,
    removeDevice,
    scanForDevices,
    setGamingModeEnabled,
    updateGamingConfig,
    setDistributionMode,
    applyChannelOptimization,
    applyDnsServer,
    runDnsBenchmark,
    startSpeedTest,
    stopSpeedTest,
    updateRouterConfig,
    simulateRouterReboot,
  ]);

  return (
    <NetworkContext.Provider value={value}>
      {children}
    </NetworkContext.Provider>
  );
};

export function useNetwork() {
  const context = useContext(NetworkContext);
  if (!context) {
    throw new Error('useNetwork must be used within a NetworkProvider');
  }
  return context;
}
