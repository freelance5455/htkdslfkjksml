import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, MultilingualText } from '../types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  showAllLanguages: boolean;
  setShowAllLanguages: (show: boolean) => void;
  isRtl: boolean;
  getText: (textObj: MultilingualText) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('ilm_academy_lang');
    if (saved === 'pashto' || saved === 'urdu' || saved === 'english') {
      return saved;
    }
    return 'pashto'; // Default to Pashto as prominent in request
  });

  const [showAllLanguages, setShowAllLanguages] = useState<boolean>(() => {
    return localStorage.getItem('ilm_academy_multiview') === 'true';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('ilm_academy_lang', lang);
  };

  const toggleShowAllLanguages = (show: boolean) => {
    setShowAllLanguages(show);
    localStorage.setItem('ilm_academy_multiview', String(show));
  };

  const isRtl = language === 'pashto' || language === 'urdu';

  useEffect(() => {
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = language === 'pashto' ? 'ps' : language === 'urdu' ? 'ur' : 'en';
  }, [language, isRtl]);

  const getText = (textObj: MultilingualText): string => {
    if (!textObj) return '';
    return textObj[language] || textObj.pashto || textObj.urdu || textObj.english || '';
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        showAllLanguages,
        setShowAllLanguages: toggleShowAllLanguages,
        isRtl,
        getText
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
