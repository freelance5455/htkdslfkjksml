import React, { createContext, useContext, useState, useEffect } from 'react';
import { LanguageCode, LanguageMeta, SUPPORTED_LANGUAGES } from '../types/language';
import { TranslationDictionary, getTranslation } from '../data/translations';

interface LanguageContextType {
  currentLanguage: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: keyof TranslationDictionary, fallback?: string) => string;
  languages: LanguageMeta[];
  currentLanguageMeta: LanguageMeta;
  isRTL: boolean;
  isLanguageModalOpen: boolean;
  openLanguageModal: () => void;
  closeLanguageModal: () => void;
}

const LANGUAGE_STORAGE_KEY = 'ntix_language';
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentLanguage, setCurrentLanguageState] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem(LANGUAGE_STORAGE_KEY);
      if (saved && SUPPORTED_LANGUAGES.some((l) => l.code === saved)) {
        return saved as LanguageCode;
      }
      const browserLang = navigator.language?.split('-')[0]?.toLowerCase();
      const matched = SUPPORTED_LANGUAGES.find((l) => l.code === browserLang);
      if (matched) return matched.code;
    } catch {
      // Ignore
    }
    return 'en';
  });

  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const currentLanguageMeta =
    SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage) || SUPPORTED_LANGUAGES[0];
  const isRTL = Boolean(currentLanguageMeta.isRTL);

  useEffect(() => {
    document.documentElement.lang = currentLanguage;
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, currentLanguage);
    } catch {
      // Ignore
    }
  }, [currentLanguage, isRTL]);

  const setLanguage = (lang: LanguageCode) => {
    if (SUPPORTED_LANGUAGES.some((l) => l.code === lang)) {
      setCurrentLanguageState(lang);
    }
  };

  const t = (key: keyof TranslationDictionary, fallback?: string): string => {
    return getTranslation(currentLanguage, key, fallback);
  };

  const openLanguageModal = () => setIsLanguageModalOpen(true);
  const closeLanguageModal = () => setIsLanguageModalOpen(false);

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        setLanguage,
        t,
        languages: SUPPORTED_LANGUAGES,
        currentLanguageMeta,
        isRTL,
        isLanguageModalOpen,
        openLanguageModal,
        closeLanguageModal,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
