(function () {
  'use strict';

  var cv = document.getElementById('game');
  var ctx = cv.getContext('2d');

  // 等比缩放，坐标换算才准
  function fit() {
    var r = Math.min(window.innerWidth / W, window.innerHeight / H);
    cv.style.width = Math.floor(W * r) + 'px';
    cv.style.height = Math.floor(H * r) + 'px';
  }
  window.addEventListener('resize', fit);
  window.addEventListener('orientationchange', function () { setTimeout(fit, 120); });
  fit();

  // ---------- 资源 ----------
  var IMG = {};
  var SRC = {
    huangyi: 'assets/characters/黄衣哥/idle.png',
    xizhuang: 'assets/characters/西装哥/idle.png',
    tangyi: 'assets/characters/躺椅哥/idle.png',
    jianzi: 'assets/characters/剪刀手哥/idle.png',
    datou: 'assets/characters/大头哥/idle.png',
    card: 'assets/projectiles/card.png',
    tadpole: 'assets/projectiles/tadpole.png',
    poop: 'assets/projectiles/poop.png'
  };

  function loadAll(cb) {
    var keys = Object.keys(SRC), left = keys.length;
    keys.forEach(function (k) {
      var im = new Image();
      im.onload = im.onerror = function () { if (--left === 0) cb(); };
      im.src = SRC[k];
      IMG[k] = im;
    });
  }

  // ---------- 小工具 ----------
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function rand(a, b) { return a + Math.random() * (b - a); }
  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function rectHit(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }
  function angleTo(a, b) {
    return Math.atan2((b.y + b.h / 2) - (a.y + a.h / 2), (b.x + b.w / 2) - (a.x + a.w / 2));
  }

  // ---------- 状态 ----------
  var S = {
    screen: 'lobby',
    t: 0, introT: 0, overT: 0,
    map: null, players: [], projectiles: [], particles: [], texts: [],
    timer: ROUND_TIME, round: 1, wins: [0, 0], winner: -1, matchOver: false,
    shake: 0,
    wind: { on: false, t: 6, dir: 1 },
    fanOn: false, fanT: 7,
    healOn: false, healT: 0,
    moving: [],
    rt: 0
  };

  // ---------- 输入 ----------
  var keys = {};
  window.addEventListener('keydown', function (e) {
    keys[e.code] = true;
    if (e.code.indexOf('Arrow') === 0 || e.code === 'Space') e.preventDefault();
  });
  window.addEventListener('keyup', function (e) { keys[e.code] = false; });

  var JOY = { x: 210, y: 520, r: 108, on: false, id: null, dx: 0, dy: 0 };
  var held = { attack: false, jump: false, skill: false };
  var pressQ = { attack: false, jump: false, skill: false };
  var ptrs = {};

  function logical(e) {
    var r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) * W / r.width, y: (e.clientY - r.top) * H / r.height };
  }

  function btnLayout() {
    var c = S.players[MYIDX] ? S.players[MYIDX].cfg : CHARS.huangyi;
    var b = {};
    if (c.hasAttack) b.attack = { x: 1120, y: 540, r: 66 };
    if (c.hasJump) b.jump = { x: 995, y: 620, r: 54 };
    if (c.hasSkill) b.skill = { x: 1180, y: 388, r: 72 };
    return b;
  }

  cv.addEventListener('pointerdown', function (e) {
    e.preventDefault();
    var pt = logical(e);
    if (S.screen === 'matchover' && NET.role !== 'client') { newMatch(); return; }
    var b = btnLayout();
    var names = ['attack', 'jump', 'skill'];
    for (var i = 0; i < names.length; i++) {
      var k = names[i], bb = b[k];
      if (bb && Math.hypot(pt.x - bb.x, pt.y - bb.y) < bb.r * 1.2) {
        held[k] = true; pressQ[k] = true;
        ptrs[e.pointerId] = k;
        return;
      }
    }
    if (pt.x < 620 && !JOY.on) {
      JOY.on = true; JOY.id = e.pointerId; JOY.dx = 0; JOY.dy = 0;
      ptrs[e.pointerId] = 'joy';
    }
  });

  window.addEventListener('pointermove', function (e) {
    if (ptrs[e.pointerId] !== 'joy') return;
    var pt = logical(e);
    JOY.dx = clamp(pt.x - JOY.x, -90, 90);
    JOY.dy = clamp(pt.y - JOY.y, -90, 90);
    if (Math.hypot(JOY.dx, JOY.dy) > 90) {
      var a = Math.atan2(JOY.dy, JOY.dx);
      JOY.dx = Math.cos(a) * 90; JOY.dy = Math.sin(a) * 90;
    }
  });

  function endPtr(e) {
    var k = ptrs[e.pointerId];
    if (!k) return;
    if (k === 'joy') { JOY.on = false; JOY.dx = 0; JOY.dy = 0; }
    else held[k] = false;
    delete ptrs[e.pointerId];
  }
  window.addEventListener('pointerup', endPtr);
  window.addEventListener('pointercancel', endPtr);

  function readInput(idx) {
    if (NET.role === 'host' && idx === 1) return NET.remote;
    if (NET.role === 'client' && idx === 1) {
      return { x: 0, y: 0, attack: false, jump: false, skill: false };
    }
    if (idx === 0) {
      var x = JOY.on ? JOY.dx / 80 : 0;
      var y = JOY.on ? JOY.dy / 80 : 0;
      if (keys.KeyA) x -= 1;
      if (keys.KeyD) x += 1;
      if (keys.KeyW) y -= 1;
      if (keys.KeyS) y += 1;
      return {
        x: clamp(x, -1, 1), y: clamp(y, -1, 1),
        attack: !!keys.KeyJ || held.attack,
        jump: !!keys.KeyK || held.jump,
        skill: !!keys.KeyL || held.skill
      };
    }
    var x2 = 0, y2 = 0;
    if (keys.ArrowLeft) x2 -= 1;
    if (keys.ArrowRight) x2 += 1;
    if (keys.ArrowUp) y2 -= 1;
    if (keys.ArrowDown) y2 += 1;
    return { x: x2, y: y2, attack: !!keys.Digit1, jump: !!keys.Digit2, skill: !!keys.Digit3 };
  }

  // ---------- 对局 ----------
  function makePlayer(idx, key) {
    var c = CHARS[key];
    return {
      idx: idx, key: key, cfg: c,
      x: idx === 0 ? 170 : 1050, y: GROUND_Y - c.h, w: c.w, h: c.h,
      vx: 0, vy: 0, facing: idx === 0 ? 1 : -1,
      hp: c.hp, maxHp: c.hp, energy: 0,
      onGround: false, atkCd: 0, stun: 0, flash: 0, slowT: 0,
      dashT: 0, dashDir: 1, hitPending: 0,
      spinT: 0, spinTick: 0, diarrheaT: 0, diarrheaTick: 0,
      ammo: c.ammoMax || 0, ammoT: 0, coyote: 0, jumpBuf: 0,
      headT: c.headEvery || 2.2, portalCd: 0,
      prev: { x: 0, y: 0, attack: false, jump: false, skill: false }
    };
  }

  function newMatch() {
    S.wins = [0, 0]; S.round = 1; S.matchOver = false;
    newRound();
  }

  function newRound() {
    var picked = shuffle(Object.keys(CHARS)).slice(0, 2);
    S.map = MAPS[Math.floor(Math.random() * MAPS.length)];
    S.players = [makePlayer(0, picked[0]), makePlayer(1, picked[1])];
    S.projectiles = []; S.particles = []; S.texts = [];
    S.timer = ROUND_TIME; S.screen = 'intro'; S.introT = 3.2; S.overT = 0;
    S.winner = -1; S.shake = 0;
    S.wind = { on: false, t: S.map.wind ? S.map.wind.interval : 6, dir: 1 };
    S.fanOn = false; S.fanT = S.map.fan ? S.map.fan.interval : 7;
    S.healOn = !!S.map.heal; S.healT = 0;
    S.moving = (S.map.moving || []).map(function (m) {
      return { x: m.x, y: m.y, w: m.w, h: m.h, from: m.from, to: m.to, period: m.period, t: m.phase * m.period, cy: m.y };
    });
    if (S.players[0].cfg.gravity === false) S.players[0].y = GROUND_Y - S.players[0].h - 40;
    if (S.players[1].cfg.gravity === false) S.players[1].y = GROUND_Y - S.players[1].h - 40;
    if (NET.role === 'host') {
      netSend({
        t: 'start', mapId: S.map.id,
        chars: [S.players[0].key, S.players[1].key]
      });
    }
  }

  function enemyOf(p) { return S.players[p.idx === 0 ? 1 : 0]; }

  function allSolids() {
    var out = S.map.platforms.slice();
    for (var i = 0; i < S.moving.length; i++) {
      var m = S.moving[i];
      out.push({ x: m.x, y: m.cy, w: m.w, h: m.h, moving: true });
    }
    return out;
  }

  // ---------- 战斗 ----------
  function hit(att, tgt, dmg, opt) {
    if (!tgt || tgt.hp <= 0) return;
    opt = opt || {};
    tgt.hp = Math.max(0, tgt.hp - dmg);
    tgt.flash = 0.18;
    tgt.stun = opt.stun !== undefined ? opt.stun : 0.12;
    if (opt.slow) tgt.slowT = Math.max(tgt.slowT || 0, opt.slow);
    var dirx = 1;
    if (att) dirx = ((tgt.x + tgt.w / 2) >= (att.x + att.w / 2)) ? 1 : -1;
    var kbx = clamp(dmg * 68, 260, 1250);
    var kby = clamp(dmg * 40, 180, 800);
    tgt.vx += dirx * kbx;
    tgt.vy = Math.min(tgt.vy, -kby);
    if (att && att.cfg.hasSkill && opt.noEnergy !== true) {
      var eg = dmg * (750 / Math.max(1, tgt.maxHp));
      att.energy = Math.min(MAX_ENERGY, att.energy + eg);
    }
    S.texts.push({ id: ++FX_ID, x: tgt.x + tgt.w / 2, y: tgt.y - 6, t: 0.8, txt: '-' + dmg, color: '#ffd95e' });
    spark(tgt.x + tgt.w / 2, tgt.y + tgt.h / 2, opt.color || '#fff');
    S.shake = Math.max(S.shake, opt.shake || 5);
    if (tgt.hp <= 0) endRound();
  }

  function spark(x, y, color) {
    for (var i = 0; i < 9; i++) {
      S.particles.push({
        x: x, y: y, vx: rand(-240, 240), vy: rand(-280, 120),
        life: rand(0.22, 0.5), color: color, r: rand(2, 5)
      });
    }
  }

  function spawnProj(o) {
    var p = {
      type: 'card', x: 0, y: 0, vx: 0, vy: 0, w: 20, h: 28,
      dmg: 5, owner: null, blockable: true, homing: 0, homingDelay: 0,
      life: 2, rot: 0, spin: 0
    };
    for (var k in o) p[k] = o[k];
    S.projectiles.push(p);
    return p;
  }

  function spawnCard(p, ang, speed, dmg, curved, delay, noEnergy) {
    spawnProj({
      type: 'card', x: p.x + p.w / 2, y: p.y + p.h * 0.35,
      vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed,
      w: 22, h: 30, dmg: dmg, owner: p, blockable: true,
      homing: curved ? 4.5 : 0, homingDelay: delay || 0, life: 2.6, rot: ang,
      noEnergy: !!noEnergy
    });
  }

  function spawnTadpole(p, ang, speed, turn, dmg, blockable, w, h, life, noEnergy) {
    spawnProj({
      type: 'tadpole', x: p.x + p.w / 2, y: p.y + p.h / 2,
      vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed,
      w: w, h: h, dmg: dmg, owner: p, blockable: blockable,
      homing: turn, homingDelay: 0, life: life, rot: ang,
      noEnergy: !!noEnergy
    });
  }

  function spawnPoop(p) {
    spawnProj({
      type: 'poop', x: p.x + p.w / 2, y: p.y + p.h - 4,
      vx: 0, vy: 700, w: 44, h: 44, dmg: p.cfg.dmg,
      owner: p, blockable: true, homing: 0, life: 2.5, rot: rand(0, 6)
    });
  }

  function spawnHead(p) {
    spawnProj({
      type: 'head', x: p.x + p.w / 2, y: p.y + p.h / 2,
      vx: 0, vy: 0, w: 46, h: 46, dmg: p.cfg.dmg,
      owner: p, blockable: false, homing: 1.5, life: 5, rot: 0, noEnergy: true
    });
    var pr = S.projectiles[S.projectiles.length - 1];
    var e = enemyOf(p);
    var ang = angleTo(pr, e);
    pr.vx = Math.cos(ang) * 260; pr.vy = Math.sin(ang) * 260;
  }

  function doAttack(p) {
    var cfg = p.cfg, e = enemyOf(p);
    if (!e) return;
    var dir = (e.x + e.w / 2) > (p.x + p.w / 2) ? 1 : -1;
    p.facing = dir;

    if (p.key === 'huangyi') {
      p.atkCd = cfg.atkCd;
      p.dashT = 0.1; p.dashDir = dir; p.hitPending = 0.09;
    } else if (p.key === 'xizhuang') {
      p.atkCd = cfg.atkCd;
      spawnCard(p, angleTo(p, e), 900, cfg.dmg, false, 0);
    } else if (p.key === 'tangyi') {
      p.atkCd = cfg.atkCd;
      spawnTadpole(p, angleTo(p, e), 420, 3.0, cfg.dmg, true, 42, 28, 3.0);
    } else if (p.key === 'jianzi') {
      if (!(p.ammo > 0)) return;
      p.ammo--;
      p.atkCd = cfg.atkCd;
      spawnPoop(p);
      p.vy = -cfg.recoil; p.onGround = false; p.coyote = 0;
    }
  }

  function punchHit(p) {
    var e = enemyOf(p);
    var box = { x: p.facing > 0 ? p.x + p.w : p.x - 95, y: p.y + 20, w: 95, h: 110 };
    spark(box.x + box.w / 2, box.y + box.h / 2, '#ffd34d');
    if (e && rectHit(box, e)) {
      hit(p, e, p.cfg.dmg, { kx: p.facing * 260, ky: 200, shake: 7 });
    }
  }

  function spinHit(p) {
    var e = enemyOf(p);
    if (!e) return;
    var cx = p.x + p.w / 2, cy = p.y + p.h / 2;
    var ex = e.x + e.w / 2, ey = e.y + e.h / 2;
    if (Math.hypot(ex - cx, ey - cy) < 122) {
      hit(p, e, 9, { kx: (ex > cx ? 1 : -1) * 220, ky: 180, shake: 7, noEnergy: true });
    }
  }

  function diarrheaTick(p) {
    if (Math.random() < 0.75) {
      S.particles.push({
        x: p.x + p.w / 2 + rand(-16, 16), y: p.y + p.h - 6,
        vx: rand(-40, 40), vy: rand(320, 620), life: 0.55, color: '#9ad64d', r: rand(3, 7)
      });
    }
    if (p.diarrheaTick <= 0) {
      p.diarrheaTick = 0.12;
      var e = enemyOf(p);
      if (e && e.hp > 0) {
        var cx = p.x + p.w / 2;
        if (Math.abs(e.x + e.w / 2 - cx) < 72 && e.y > p.y - 20) {
          hit(p, e, 3, { stun: 0.02, kx: 0, shake: 2, noEnergy: true });
          e.slowT = 1.2;
        }
      }
    }
  }

  function doSkill(p) {
    var cfg = p.cfg;
    if (!cfg.hasSkill || p.energy < MAX_ENERGY) return;
    p.energy = 0;
    var e = enemyOf(p);
    if (p.key === 'huangyi') {
      p.spinT = 0.9; p.spinTick = 0.05;
    } else if (p.key === 'xizhuang') {
      var base = angleTo(p, e);
      for (var i = 0; i < 9; i++) {
        spawnCard(p, base + (-60 + i * 15) * Math.PI / 180, 620, cfg.skillDmg, true, 0.22, true);
      }
    } else if (p.key === 'tangyi') {
      spawnTadpole(p, angleTo(p, e), 260, 1.8, 26, false, 78, 52, 6, true);
    } else if (p.key === 'jianzi') {
      p.diarrheaT = 2.5; p.diarrheaTick = 0;
    }
  }

  // ---------- 玩家更新 ----------
  function movePlayer(p, dt) {
    var sol = allSolids(), i, s;
    var prevBottom = p.y + p.h;

    p.x += p.vx * dt;
    for (i = 0; i < sol.length; i++) {
      s = sol[i];
      if (!(s.solid || s.ground)) continue; // 单向平台不挡横向
      if (rectHit(p, s)) {
        if (p.vx > 0) p.x = s.x - p.w;
        else if (p.vx < 0) p.x = s.x + s.w;
        if (p.cfg.gravity) p.vx = 0;
      }
    }
    p.x = clamp(p.x, 0, W - p.w);

    p.y += p.vy * dt;
    var ground = false;
    for (i = 0; i < sol.length; i++) {
      s = sol[i];
      if (!rectHit(p, s)) continue;
      var hard = !!(s.solid || s.ground);
      if (p.vy >= 0) {
        if (!hard && prevBottom > s.y + 10) continue; // 从下面穿上去
        p.y = s.y - p.h;
        p.vy = 0;
        ground = true;
        if (s.tramp) {
          var jv = (p.cfg.jumpV || 1126) * 1.5;
          p.vy = -jv; ground = false;
          spark(p.x + p.w / 2, p.y + p.h, '#7bff9a');
        }
      } else {
        if (!hard) continue;
        p.y = s.y + s.h;
        p.vy = 0;
      }
    }
    p.onGround = ground;

    if (p.y < 0) { p.y = 0; if (p.vy < 0) p.vy = 0; }

    if (p.y > H + 40) {
      if (S.map.id === 'roof') {
        p.hp = Math.max(0, p.hp - 10);
        S.texts.push({ id: ++FX_ID, x: p.x + p.w / 2, y: 300, t: 1, txt: '-10', color: '#ff6b6b' });
        p.x = clamp(p.x, 60, W - 120); p.y = GROUND_Y - p.h - 30; p.vy = 0;
        if (p.hp <= 0) endRound();
      } else {
        p.y = H - p.h; p.vy = 0;
      }
    }
  }

  function stepPlayer(p, dt) {
    var cfg = p.cfg;
    var inp = readInput(p.idx);
    var atkEdge = inp.attack && !p.prev.attack;
    var jumpEdge = inp.jump && !p.prev.jump;
    var skillEdge = inp.skill && !p.prev.skill;
    p.prev = { x: inp.x, y: inp.y, attack: inp.attack, jump: inp.jump, skill: inp.skill };

    if (p.stun > 0) p.stun -= dt;
    if (p.atkCd > 0) p.atkCd -= dt;
    if (p.slowT > 0) p.slowT -= dt;
    if (p.flash > 0) p.flash -= dt;
    if (p.portalCd > 0) p.portalCd -= dt;

    var canAct = p.stun <= 0;
    var spd = cfg.speed * (p.slowT > 0 ? 0.7 : 1);

    if (p.spinT > 0) {
      p.spinT -= dt; p.spinTick -= dt;
      if (p.spinTick <= 0) { p.spinTick = 0.15; spinHit(p); }
    }
    if (p.diarrheaT > 0) {
      p.diarrheaT -= dt;
      p.diarrheaTick -= dt;
      diarrheaTick(p);
    }
    if (p.hitPending > 0) {
      p.hitPending -= dt;
      if (p.hitPending <= 0) punchHit(p);
    }

    if (cfg.gravity) {
      if (p.dashT > 0) { p.dashT -= dt; p.vx = p.dashDir * cfg.speed * 1.7; }
      else {
        var tvx = inp.x * spd;
        var kk = S.map.ice ? 3.0 : (p.onGround ? 15 : 8);
        p.vx += (tvx - p.vx) * Math.min(1, dt * kk);
        if (Math.abs(p.vx) < 4 && Math.abs(tvx) < 4) p.vx = 0;
      }
      if (p.diarrheaT > 0) p.vy = 0;
      else {
        p.vy += GRAVITY * dt;
        if (S.map.fan && S.fanOn) p.vy += S.map.fan.force * dt;
      }
    } else {
      p.vx += (inp.x * spd - p.vx) * Math.min(1, dt * 12);
      p.vy += (inp.y * spd - p.vy) * Math.min(1, dt * 12);
    }

    if (S.map.wind && S.wind.on) p.vx += S.wind.dir * S.map.wind.force * dt;

    if (Math.abs(inp.x) > 0.15) p.facing = inp.x > 0 ? 1 : -1;

    if (atkEdge && canAct && cfg.hasAttack && p.atkCd <= 0 && p.diarrheaT <= 0) doAttack(p);
    if (jumpEdge) p.jumpBuf = 0.12;
    if (p.jumpBuf > 0 && p.coyote > 0 && canAct && cfg.hasJump) {
      p.vy = -cfg.jumpV; p.onGround = false; p.coyote = 0; p.jumpBuf = 0;
    }
    if (skillEdge && canAct) doSkill(p);

    movePlayer(p, dt);
    if (p.onGround) p.coyote = 0.09;

    // 剪刀手弹药回复
    if (p.key === 'jianzi' && p.ammo < cfg.ammoMax) {
      p.ammoT += dt;
      if (p.ammoT >= cfg.ammoRegen) { p.ammoT = 0; p.ammo++; if (p.ammo >= cfg.ammoMax) p.ammoT = 0; }
    }

    // 大头哥自动头
    if (p.key === 'datou') {
      p.headT -= dt;
      if (p.headT <= 0) { p.headT = cfg.headEvery; spawnHead(p); }
    }

    // 传送门
    if (S.map.portals && p.portalCd <= 0) {
      for (var i = 0; i < S.map.portals.length; i++) {
        var pt = S.map.portals[i], other = S.map.portals[i ^ 1];
        if (rectHit(p, pt)) {
          p.x = other.x + other.w / 2 - p.w / 2;
          p.y = other.y + other.h - p.h - 10;
          p.portalCd = 1;
          spark(p.x + p.w / 2, p.y + p.h / 2, '#c89bff');
          break;
        }
      }
    }

    // 米饭回血
    if (S.healOn && S.map.heal) {
      var h = S.map.heal;
      if (Math.abs(p.x + p.w / 2 - h.x) < 60 && Math.abs(p.y + p.h - h.y) < 70) {
        S.healOn = false; S.healT = h.respawn;
        p.hp = Math.min(p.maxHp, p.hp + h.amount);
        S.texts.push({ id: ++FX_ID, x: h.x, y: h.y - 20, t: 1, txt: '+' + h.amount, color: '#7bff9a' });
      }
    }
  }

  // ---------- 地图 ----------
  function updateMap(dt) {
    var i, m = S.map;
    for (i = 0; i < S.moving.length; i++) {
      var mp = S.moving[i];
      mp.t += dt;
      var k = (mp.t / mp.period) % 1;
      var e = 0.5 - 0.5 * Math.cos(k * Math.PI * 2);
      mp.cy = mp.from + (mp.to - mp.from) * e;
      // 站在平台上的玩家跟着走
      for (var j = 0; j < S.players.length; j++) {
        var p = S.players[j];
        if (p.onGround && Math.abs((p.y + p.h) - mp.cy) < 6 && p.x + p.w > mp.x && p.x < mp.x + mp.w) {
          p.y = mp.cy - p.h;
        }
      }
    }
    if (m.wind) {
      S.wind.t -= dt;
      if (S.wind.on) {
        if (S.wind.t <= 0) { S.wind.on = false; S.wind.t = m.wind.interval; }
      } else if (S.wind.t <= 0) {
        S.wind.on = true; S.wind.t = m.wind.duration; S.wind.dir *= -1;
      }
    }
    if (m.fan) {
      S.fanT -= dt;
      if (S.fanOn) { if (S.fanT <= 0) { S.fanOn = false; S.fanT = m.fan.interval; } }
      else if (S.fanT <= 0) { S.fanOn = true; S.fanT = m.fan.duration; }
    }
    if (m.heal && !S.healOn) {
      S.healT -= dt;
      if (S.healT <= 0) S.healOn = true;
    }
  }

  // ---------- 投射物 ----------
  function steer(pr, tgt, turn, dt) {
    var want = Math.atan2((tgt.y + tgt.h / 2) - pr.y, (tgt.x + tgt.w / 2) - pr.x);
    var cur = Math.atan2(pr.vy, pr.vx);
    var d = want - cur;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    var mx = turn * dt;
    cur += clamp(d, -mx, mx);
    var sp = Math.hypot(pr.vx, pr.vy) || 1;
    pr.vx = Math.cos(cur) * sp;
    pr.vy = Math.sin(cur) * sp;
  }

  function updateProjectiles(dt) {
    for (var i = S.projectiles.length - 1; i >= 0; i--) {
      var pr = S.projectiles[i];
      pr.life -= dt;
      if (pr.life <= 0) { S.projectiles.splice(i, 1); continue; }

      var e = enemyOf(pr.owner);
      if (pr.homingDelay > 0) pr.homingDelay -= dt;
      else if (pr.homing > 0 && e && e.hp > 0) steer(pr, e, pr.homing, dt);

      if (S.map.wind && S.wind.on) pr.vx += S.wind.dir * S.map.wind.force * 0.6 * dt;

      pr.x += pr.vx * dt;
      pr.y += pr.vy * dt;
      pr.rot = Math.atan2(pr.vy, pr.vx);
      if (pr.type === 'poop') pr.rot += dt * 3;

      var box = { x: pr.x - pr.w / 2, y: pr.y - pr.h / 2, w: pr.w, h: pr.h };

      if (e && e.hp > 0 && rectHit(box, e)) {
        var kb = pr.type === 'card' ? 60 : 180;
        hit(pr.owner, e, pr.dmg, { slow: pr.type === 'tadpole' ? 5 : 0, shake: 4, noEnergy: pr.noEnergy === true });
        spark(pr.x, pr.y, '#ffef9e');
        S.projectiles.splice(i, 1);
        continue;
      }

      if (pr.type === 'head' || pr.blockable === false) { /* 无视地形 */ }
      else {
        var sol = allSolids(), dead = false;
        for (var j = 0; j < sol.length; j++) {
          if (rectHit(box, sol[j])) { dead = true; break; }
        }
        if (dead) {
          spark(pr.x, pr.y, '#c9c9c9');
          S.projectiles.splice(i, 1);
          continue;
        }
      }

      if (pr.x < -60 || pr.x > W + 60 || pr.y < -80 || pr.y > H + 80) {
        S.projectiles.splice(i, 1);
      }
    }
  }

  function updateFX(dt) {
    for (var i = S.particles.length - 1; i >= 0; i--) {
      var p = S.particles[i];
      p.life -= dt;
      if (p.life <= 0) { S.particles.splice(i, 1); continue; }
      p.vy += 900 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (var j = S.texts.length - 1; j >= 0; j--) {
      var t = S.texts[j];
      t.t -= dt;
      t.y -= 40 * dt;
      if (t.t <= 0) S.texts.splice(j, 1);
    }
  }

  // ---------- 回合 ----------
  function endRound() {
    if (S.screen !== 'fight') return;
    var a = S.players[0], b = S.players[1], w = -1;
    if (a.hp <= 0 && b.hp <= 0) w = -1;
    else if (a.hp <= 0) w = 1;
    else if (b.hp <= 0) w = 0;
    else if (S.timer <= 0) {
      if (a.hp === b.hp) w = -1;
      else w = a.hp > b.hp ? 0 : 1;
    }
    S.winner = w;
    if (w >= 0) S.wins[w]++;
    S.matchOver = S.wins[0] >= 2 || S.wins[1] >= 2;
    S.screen = 'over';
    S.overT = 3;
  }

  function nextRound() {
    if (S.matchOver) { S.screen = 'matchover'; return; }
    S.round++;
    newRound();
  }

  function update(dt) {
    S.t += dt;
    if (NET.role === 'client') { clientUpdate(dt); return; }
    if (S.screen === 'lobby') return;
    if (S.screen === 'intro') {
      S.introT -= dt;
      if (S.introT <= 0) S.screen = 'fight';
      return;
    }
    if (S.screen === 'over') {
      S.overT -= dt;
      updateFX(dt);
      if (S.overT <= 0) nextRound();
      return;
    }
    if (S.screen === 'matchover') return;

    S.timer -= dt;
    if (S.timer <= 0) { S.timer = 0; endRound(); return; }

    updateMap(dt);
    for (var i = 0; i < S.players.length; i++) stepPlayer(S.players[i], dt);
    updateProjectiles(dt);
    updateFX(dt);
    if (S.shake > 0) S.shake = Math.max(0, S.shake - dt * 40);
  }

  // ---------- 渲染 ----------
  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function drawBG() {
    var m = S.map;
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, m.sky[0]);
    g.addColorStop(1, m.sky[1]);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    ctx.globalAlpha = 0.12;
    ctx.fillStyle = '#ffffff';
    for (var i = 0; i < 6; i++) {
      var x = (i * 240 + 80) % W;
      ctx.fillRect(x, 90 + (i % 3) * 40, 120, 4);
    }
    ctx.globalAlpha = 1;
  }

  function drawMap() {
    var m = S.map, i;
    var sol = m.platforms;
    for (i = 0; i < sol.length; i++) {
      var p = sol[i];
      if (p.tramp) {
        ctx.fillStyle = '#3ad07a';
        roundRect(p.x, p.y, p.w, p.h, 10); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.4)';
        ctx.fillRect(p.x + 10, p.y + 4, p.w - 20, 4);
      } else {
        ctx.fillStyle = p.ground ? m.floor : m.accent;
        roundRect(p.x, p.y, p.w, p.h, p.ground ? 0 : 6); ctx.fill();
        if (!p.ground) {
          ctx.fillStyle = 'rgba(255,255,255,.18)';
          ctx.fillRect(p.x + 4, p.y + 3, p.w - 8, 3);
        }
      }
    }
    for (i = 0; i < S.moving.length; i++) {
      var mp = S.moving[i];
      ctx.fillStyle = '#d9a441';
      roundRect(mp.x, mp.cy, mp.w, mp.h, 6); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,.25)';
      ctx.fillRect(mp.x + 4, mp.cy + mp.h - 5, mp.w - 8, 3);
    }
    if (m.portals) {
      for (i = 0; i < m.portals.length; i++) {
        var pt = m.portals[i];
        var pg = ctx.createLinearGradient(pt.x, pt.y, pt.x + pt.w, pt.y + pt.h);
        pg.addColorStop(0, 'rgba(180,140,255,.75)');
        pg.addColorStop(1, 'rgba(90,60,180,.35)');
        ctx.fillStyle = pg;
        roundRect(pt.x, pt.y, pt.w, pt.h, 14); ctx.fill();
      }
    }
    if (m.heal && S.healOn) {
      var h = m.heal;
      ctx.save();
      ctx.translate(h.x, h.y);
      ctx.fillStyle = '#fff3c4';
      ctx.beginPath(); ctx.arc(0, 0, 26, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#8a6b36';
      ctx.font = 'bold 26px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('饭', 0, 1);
      ctx.restore();
    }
    if (m.wind && S.wind.on) {
      ctx.strokeStyle = 'rgba(200,230,255,.55)';
      ctx.lineWidth = 3;
      for (i = 0; i < 9; i++) {
        var y = 120 + i * 55, x0 = S.wind.dir > 0 ? i * 90 : W - i * 90;
        ctx.beginPath();
        ctx.moveTo(x0, y);
        ctx.lineTo(x0 + S.wind.dir * 70, y);
        ctx.stroke();
      }
    }
    if (m.fan && S.fanOn) {
      ctx.fillStyle = 'rgba(180,200,255,.14)';
      for (i = 0; i < 7; i++) ctx.fillRect(m.fan.x - 300 + i * 100, 0, 26, 320);
    }
  }

  function drawPlayer(p) {
    var img = IMG[p.key];
    var cx = p.x + p.w / 2, by = p.y + p.h;
    ctx.save();
    ctx.translate(cx, by);
    if (p.key === 'tangyi') {
      var mv = Math.abs(p.vx) + Math.abs(p.vy);
      var tilt = mv > 20 ? clamp(Math.atan2(p.vy, p.vx), -0.62, 0.62) : 0;
      ctx.rotate(tilt);
    }
    ctx.scale(p.facing, 1);
    if (img && img.width) {
      var dh = p.cfg.drawH, dw = dh * img.width / img.height;
      ctx.drawImage(img, -dw / 2, -dh, dw, dh);
    } else {
      ctx.fillStyle = p.cfg.color;
      ctx.fillRect(-p.w / 2, -p.h, p.w, p.h);
    }
    if (p.flash > 0) {
      ctx.globalAlpha = 0.55;
      ctx.fillStyle = '#fff';
      ctx.fillRect(-p.w / 2, -p.h, p.w, p.h);
      ctx.globalAlpha = 1;
    }
    ctx.restore();

    // 能量满：脚下一圈光
    if (p.energy >= MAX_ENERGY && p.cfg.hasSkill) {
      ctx.strokeStyle = 'rgba(255,220,80,.85)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(cx, by - 4, p.w * 0.8, 12, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    // 旋转技能
    if (p.spinT > 0) {
      ctx.strokeStyle = 'rgba(255,220,90,.75)';
      ctx.lineWidth = 10;
      ctx.beginPath();
      ctx.arc(cx, p.y + p.h / 2, 90, S.t * 14, S.t * 14 + Math.PI * 1.4);
      ctx.stroke();
    }
  }

  function drawProjectiles() {
    for (var i = 0; i < S.projectiles.length; i++) {
      var pr = S.projectiles[i];
      ctx.save();
      ctx.translate(pr.x, pr.y);
      ctx.rotate(pr.rot);
      var img = IMG[pr.type === 'card' ? 'card' : (pr.type === 'poop' ? 'poop' : (pr.type === 'head' ? 'datou' : 'tadpole'))];
      if (img && img.width) {
        var w = pr.w, h = w * img.height / img.width;
        ctx.drawImage(img, -w / 2, -h / 2, w, h);
      } else {
        ctx.fillStyle = pr.type === 'card' ? '#fff' : '#8fd3ff';
        ctx.fillRect(-pr.w / 2, -pr.h / 2, pr.w, pr.h);
      }
      ctx.restore();
    }
  }

  function drawFX() {
    for (var i = 0; i < S.particles.length; i++) {
      var p = S.particles[i];
      ctx.globalAlpha = clamp(p.life * 2, 0, 1);
      ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.textAlign = 'center';
    ctx.font = 'bold 28px sans-serif';
    for (var j = 0; j < S.texts.length; j++) {
      var t = S.texts[j];
      ctx.globalAlpha = clamp(t.t * 1.6, 0, 1);
      ctx.fillStyle = t.color;
      ctx.fillText(t.txt, t.x, t.y);
    }
    ctx.globalAlpha = 1;
  }

  function bar(x, y, w, h, v, color) {
    ctx.fillStyle = 'rgba(0,0,0,.45)';
    roundRect(x, y, w, h, h / 2); ctx.fill();
    ctx.fillStyle = color;
    roundRect(x + 2, y + 2, Math.max(0, (w - 4) * v), h - 4, (h - 4) / 2); ctx.fill();
  }

  function drawHUD() {
    var a = S.players[0], b = S.players[1];
    if (!a || !b) return;
    ctx.textBaseline = 'middle';

    // P1
    ctx.textAlign = 'left';
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText(a.cfg.name, 40, 34);
    bar(40, 50, 430, 26, a.hp / a.maxHp, a.hp / a.maxHp > 0.3 ? '#57d97b' : '#e35d5d');
    if (a.cfg.hasSkill) bar(40, 82, 320, 12, a.energy / MAX_ENERGY, '#ffcf4d');

    // 剪刀手弹药
    if (a.key === 'jianzi') {
      for (var mi = 0; mi < a.cfg.ammoMax; mi++) {
        ctx.beginPath();
        ctx.arc(62 + mi * 28, 118, 9, 0, Math.PI * 2);
        ctx.fillStyle = mi < a.ammo ? '#b9e08d' : 'rgba(255,255,255,.18)';
        ctx.fill();
      }
      var ammoProg = a.ammo >= a.cfg.ammoMax ? 1 : (a.ammo + a.ammoT / a.cfg.ammoRegen) / a.cfg.ammoMax;
      bar(40, 136, 220, 10, ammoProg, '#8ed46a');
      ctx.fillStyle = 'rgba(255,255,255,.7)';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('弹药 ' + a.ammo + '/' + a.cfg.ammoMax, 40, 164);
    }

    // P2
    ctx.textAlign = 'right';
    ctx.fillText(b.cfg.name, W - 40, 34);
    ctx.fillStyle = 'rgba(0,0,0,.45)';
    roundRect(W - 470, 50, 430, 26, 13); ctx.fill();
    ctx.fillStyle = b.hp / b.maxHp > 0.3 ? '#57d97b' : '#e35d5d';
    var bw = (430 - 4) * (b.hp / b.maxHp);
    roundRect(W - 40 - bw - 2, 52, Math.max(0, bw), 22, 11); ctx.fill();
    if (b.cfg.hasSkill) {
      ctx.fillStyle = 'rgba(0,0,0,.45)';
      roundRect(W - 360, 82, 320, 12, 6); ctx.fill();
      ctx.fillStyle = '#ffcf4d';
      var ew = (320 - 4) * (b.energy / MAX_ENERGY);
      roundRect(W - 40 - ew - 2, 84, Math.max(0, ew), 8, 4); ctx.fill();
    }

    // 计时
    ctx.textAlign = 'center';
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 40px sans-serif';
    ctx.fillText(Math.ceil(S.timer).toString(), W / 2, 48);
    ctx.font = 'bold 16px sans-serif';
    ctx.fillStyle = 'rgba(255,255,255,.7)';
    ctx.fillText('第 ' + S.round + ' 局', W / 2, 80);
    ctx.fillText(S.map.name, W / 2, 102);
  }

  function drawControls() {
    var p = S.players[MYIDX];
    if (!p) return;
    var c = p.cfg;

    // 摇杆
    ctx.save();
    ctx.globalAlpha = 0.45;
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(JOY.x, JOY.y, JOY.r, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath();
    ctx.arc(JOY.x + JOY.dx * 0.75, JOY.y + JOY.dy * 0.75, 34, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.restore();

    var b = btnLayout();
    function btn(pos, label, color, ready) {
      ctx.save();
      ctx.globalAlpha = ready ? 0.9 : 0.55;
      ctx.fillStyle = color;
      ctx.beginPath(); ctx.arc(pos.x, pos.y, pos.r, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#0b0f18';
      ctx.font = 'bold ' + Math.round(pos.r * 0.5) + 'px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, pos.x, pos.y + 2);
      ctx.restore();
    }
    if (b.attack) btn(b.attack, '攻', '#ffb04d', true);
    if (b.jump) btn(b.jump, '跳', '#7bd7ff', true);
    if (b.skill) btn(b.skill, '技', c.color, p.energy >= MAX_ENERGY);
  }

  function drawOverlay() {
    if (S.screen === 'lobby') return;
    if (S.screen === 'intro') {
      ctx.fillStyle = 'rgba(4,7,14,.72)';
      ctx.fillRect(0, 0, W, H);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 30px sans-serif';
      ctx.fillText('地图：' + S.map.name, W / 2, 150);
      ctx.font = '18px sans-serif';
      ctx.fillStyle = 'rgba(255,255,255,.65)';
      ctx.fillText(S.map.desc, W / 2, 190);

      var a = S.players[0], b = S.players[1];
      ctx.font = 'bold 46px sans-serif';
      ctx.fillStyle = a.cfg.color; ctx.fillText(a.cfg.name, W / 2 - 220, 330);
      ctx.fillStyle = '#fff'; ctx.fillText('VS', W / 2, 330);
      ctx.fillStyle = b.cfg.color; ctx.fillText(b.cfg.name, W / 2 + 220, 330);
      ctx.font = '20px sans-serif';
      ctx.fillStyle = 'rgba(255,255,255,.8)';
      ctx.fillText('技能：' + a.cfg.skillName, W / 2 - 220, 385);
      ctx.fillText('技能：' + b.cfg.skillName, W / 2 + 220, 385);

      ctx.font = 'bold 64px sans-serif';
      ctx.fillStyle = '#ffd75e';
      ctx.fillText(Math.ceil(S.introT).toString(), W / 2, 520);
      ctx.font = '16px sans-serif';
      ctx.fillStyle = 'rgba(255,255,255,.6)';
      ctx.fillText('左边摇杆移动 · 右边攻击/跳跃/技能', W / 2, 600);
      ctx.fillText('键盘：WASD + J/K/L ｜ 二号玩家：方向键 + 1/2/3', W / 2, 630);
    } else if (S.screen === 'over') {
      ctx.fillStyle = 'rgba(4,7,14,.6)';
      ctx.fillRect(0, 0, W, H);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      var txt = S.winner < 0 ? '平局' : (S.players[S.winner].cfg.name + ' 获胜！');
      ctx.fillStyle = S.winner < 0 ? '#ddd' : S.players[S.winner].cfg.color;
      ctx.font = 'bold 64px sans-serif';
      ctx.fillText(txt, W / 2, H / 2 - 30);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 30px sans-serif';
      ctx.fillText(S.wins[0] + ' : ' + S.wins[1], W / 2, H / 2 + 50);
    } else if (S.screen === 'matchover') {
      ctx.fillStyle = 'rgba(4,7,14,.82)';
      ctx.fillRect(0, 0, W, H);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      var winIdx = S.wins[0] > S.wins[1] ? 0 : 1;
      ctx.fillStyle = S.players[winIdx].cfg.color;
      ctx.font = 'bold 70px sans-serif';
      ctx.fillText(S.players[winIdx].cfg.name + ' 赢下比赛！', W / 2, H / 2 - 40);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 34px sans-serif';
      ctx.fillText(S.wins[0] + ' : ' + S.wins[1], W / 2, H / 2 + 40);
      ctx.font = '20px sans-serif';
      ctx.fillStyle = 'rgba(255,255,255,.65)';
      ctx.fillText('点击屏幕重新开始', W / 2, H / 2 + 110);
    }
  }

  function render() {
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, W, H);
    if (!S.map) return;

    ctx.save();
    if (S.shake > 0) {
      ctx.translate(rand(-S.shake, S.shake), rand(-S.shake, S.shake));
    }
    drawBG();
    drawMap();
    drawProjectiles();
    for (var i = 0; i < S.players.length; i++) drawPlayer(S.players[i]);
    drawFX();
    ctx.restore();

    drawHUD();
    if (S.screen === 'fight') drawControls();
    drawOverlay();
  }

  // ---------- 联机 ----------
  var MYIDX = 0;

  function lobbyMsg(t) {
    var el = document.getElementById('lobbyMsg');
    if (el) el.textContent = t || '';
  }

  function hideLobby() {
    var el = document.getElementById('lobby');
    if (el) el.style.display = 'none';
  }

  function startSolo() {
    netStop();
    NET.role = 'solo'; MYIDX = 0;
    hideLobby();
    newMatch();
  }

  function randomRoom() {
    var s = '', chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    for (var i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
    return s;
  }

  function startHost() {
    var room = randomRoom();
    MYIDX = 0;
    lobbyMsg('正在连中转服务器…');
    netConnect(room, 1, onNetMsg);
    NET.onOpenCb = function () {
      lobbyMsg('房间码 ' + room + ' ｜ 等对面进来…');
    };
    setTimeout(function () {
      if (NET.role === 'host' && !NET.online) lobbyMsg('连不上中转服务器，检查手机有没有网');
    }, 7000);
  }

  function startClient(room) {
    if (!room) { lobbyMsg('先填房间码'); return; }
    room = room.toUpperCase().trim();
    MYIDX = 1;
    lobbyMsg('正在连中转服务器…');
    netConnect(room, 2, onNetMsg);
    NET.onOpenCb = function () {
      lobbyMsg('已进房 ' + room + '，等主机开局…');
    };
    setTimeout(function () {
      if (NET.role === 'client' && !NET.online) lobbyMsg('连不上中转服务器，检查手机有没有网');
    }, 7000);
  }

  function onNetMsg(d) {
    if (!d || !d.t) return;
    if (d.t === 'ping' && NET.role === 'client') {
      netSend({ t: 'hello' });
    } else if (d.t === 'hello' && NET.role === 'host') {
      if (S.screen === 'lobby') { hideLobby(); newMatch(); }
    } else if (d.t === 'input' && NET.role === 'host') {
      NET.remote = d.v;
    } else if (d.t === 'start' && NET.role === 'client') {
      hideLobby();
      clientStart(d);
    } else if (d.t === 's' && NET.role === 'client') {
      NET.snap = d;
    }
  }

  function clientStart(d) {
    S.map = MAPS.filter(function (m) { return m.id === d.mapId; })[0] || MAPS[0];
    S.players = [makePlayer(0, d.chars[0]), makePlayer(1, d.chars[1])];
    S.projectiles = []; S.particles = []; S.texts = [];
    S.moving = (S.map.moving || []).map(function (m) {
      return { x: m.x, y: m.y, w: m.w, h: m.h, cy: m.y };
    });
    S.screen = 'intro'; S.introT = 3.2;
    S.wins = [0, 0]; S.round = 1; S.winner = -1;
  }

  function makeSnap() {
    return {
      t: 's',
      mapId: S.map.id, screen: S.screen, timer: S.timer, round: S.round,
      wins: S.wins, winner: S.winner, introT: S.introT, overT: S.overT,
      chars: [S.players[0].key, S.players[1].key],
      p: S.players.map(function (p) {
        return {
          x: p.x, y: p.y, vx: p.vx, vy: p.vy, hp: p.hp, energy: p.energy,
          facing: p.facing, ammo: p.ammo, onGround: p.onGround, flash: p.flash,
          spinT: p.spinT, diarrheaT: p.diarrheaT, stun: p.stun
        };
      }),
      pr: S.projectiles.map(function (q) {
        return { type: q.type, x: q.x, y: q.y, rot: q.rot, w: q.w, h: q.h };
      }),
      tx: S.texts.map(function (t) {
        return { x: t.x, y: t.y, txt: t.txt, color: t.color, t: t.t };
      }),
      wind: S.wind.on, fan: S.fanOn, heal: S.healOn,
      moving: S.moving.map(function (m) { return m.cy; })
    };
  }

  function clientUpdate(dt) {
    var s = NET.snap;
    if (s) {
      if (!S.map || S.map.id !== s.mapId) {
        S.map = MAPS.filter(function (m) { return m.id === s.mapId; })[0] || S.map;
        S.moving = (S.map.moving || []).map(function (m) {
          return { x: m.x, y: m.y, w: m.w, h: m.h, cy: m.y };
        });
      }
      if (S.players.length !== 2 || S.players[0].key !== s.chars[0] || S.players[1].key !== s.chars[1]) {
        S.players = [makePlayer(0, s.chars[0]), makePlayer(1, s.chars[1])];
      }
      S.screen = s.screen; S.timer = s.timer; S.round = s.round;
      S.wins = s.wins; S.winner = s.winner; S.introT = s.introT; S.overT = s.overT;
      S.wind.on = s.wind; S.fanOn = s.fan; S.healOn = s.heal;
      for (var mi = 0; mi < s.moving.length; mi++) {
        if (S.moving[mi]) S.moving[mi].cy = s.moving[mi];
      }
      for (var i = 0; i < S.players.length; i++) {
        var p = S.players[i], t = s.p[i];
        if (!t) continue;
        p.hp = t.hp; p.energy = t.energy; p.vx = t.vx; p.vy = t.vy;
        p.facing = t.facing; p.ammo = t.ammo; p.onGround = t.onGround;
        p.flash = t.flash; p.spinT = t.spinT; p.diarrheaT = t.diarrheaT; p.stun = t.stun;
        p.x += (t.x - p.x) * 0.5;
        p.y += (t.y - p.y) * 0.5;
      }
      S.projectiles = s.pr.map(function (q) {
        return { type: q.type, x: q.x, y: q.y, rot: q.rot, w: q.w, h: q.h, owner: null };
      });
      if (s.tx) {
        S.texts = s.tx.map(function (t) {
          return { x: t.x, y: t.y, txt: t.txt, color: t.color, t: t.t };
        });
      }
    }
    updateFX(dt);
  }


  // ---------- 内网直连（WebRTC，手动交换码）----------
  var RTC_MODE = null;

  function rtcPanel(show) {
    var el = document.getElementById('rtcPanel');
    if (el) el.style.display = show ? 'block' : 'none';
  }
  function rtcSetCode(txt) {
    var el = document.getElementById('rtcCode');
    if (el) el.value = txt;
  }
  function rtcGetCode() {
    var el = document.getElementById('rtcCode');
    return el ? el.value.trim() : '';
  }

  function rtcHostStart() {
    netStop();
    MYIDX = 0;
    NET.role = 'host'; NET.pid = 1; NET.transport = 'rtc';
    RTC_MODE = 'host';
    rtcPanel(true);
    rtcSetCode('');
    lobbyMsg('正在生成连接码…');
    rtcMakeOffer(function (ch) {
      netRtcBind(ch, onNetMsg);
      ch.onopen = function () {
        NET.online = true;
        lobbyMsg('直连成功，开局！');
        hideLobby();
        newMatch();
      };
    }).then(function (code) {
      rtcSetCode(code);
      lobbyMsg('① 把这段发给对面 → ② 他把应答码发回来，粘进框里 → ③ 点「收应答」');
    }).catch(function (e) {
      lobbyMsg('生成失败：' + (e && e.message ? e.message : e));
    });
  }

  function rtcClientJoin() {
    var code = rtcGetCode();
    if (!code || code.length < 40) {
      rtcPanel(true);
      lobbyMsg('先把主机发来的连接码粘进框里，再点「内网直连 · 加入」');
      return;
    }
    netStop();
    MYIDX = 1;
    NET.role = 'client'; NET.pid = 2; NET.transport = 'rtc';
    RTC_MODE = 'client';
    rtcPanel(true);
    lobbyMsg('正在解析连接码…');
    rtcTakeOffer(code, function (ch) {
      netRtcBind(ch, onNetMsg);
      ch.onopen = function () {
        NET.online = true;
        lobbyMsg('直连成功，等主机开局…');
        hideLobby();
      };
    }).then(function (answer) {
      rtcSetCode(answer);
      lobbyMsg('把这一段发回给主机，他点「收应答」就开局');
    }).catch(function (e) {
      lobbyMsg('连接码无效：' + (e && e.message ? e.message : e));
    });
  }

  function rtcUseCode() {
    var code = rtcGetCode();
    if (!code) { lobbyMsg('先把对方的码粘进来'); return; }
    if (RTC_MODE !== 'host') {
      lobbyMsg('只有建房的那一方需要点「收应答」，加入方请点「内网直连 · 加入」');
      return;
    }
    rtcTakeAnswer(code).then(function () {
      lobbyMsg('应答码已收下，正在建立通道…（成功会直接开局）');
    }).catch(function (e) {
      lobbyMsg('应答码无效：' + (e && e.message ? e.message : e));
    });
  }

  // ---------- 主循环 ----------
  var last = 0, acc = 0;
  function loop(t) {
    if (!last) last = t;
    var dt = Math.min(0.05, (t - last) / 1000);
    last = t;
    acc += dt;
    while (acc >= 1 / 60) {
      update(1 / 60);
      acc -= 1 / 60;
    }

    if (NET.role === 'host') {
      if (S.screen === 'lobby') {
        if (t - (NET.lastPing || 0) > 1500) {
          NET.lastPing = t;
          netSend({ t: 'ping' });
        }
      } else if (S.map && t - NET.lastSnap > 55) {
        NET.lastSnap = t;
        netSend(makeSnap());
      }
    } else if (NET.role === 'client' && S.screen !== 'lobby' && t - NET.lastInput > 33) {
      NET.lastInput = t;
      netSend({ t: 'input', v: readInput(0) });
    }

    render();
    requestAnimationFrame(loop);
  }

  function clearPress() { pressQ = { attack: false, jump: false, skill: false }; }

  var bSolo = document.getElementById('btnSolo');
  var bHost = document.getElementById('btnHost');
  var bJoin = document.getElementById('btnJoin');
  if (bSolo) bSolo.onclick = startSolo;
  if (bHost) bHost.onclick = startHost;
  if (bJoin) bJoin.onclick = function () {
    var el = document.getElementById('roomInput');
    startClient(el ? el.value.trim() : '');
  };
  var bRtcHost = document.getElementById('btnRtcHost');
  var bRtcClient = document.getElementById('btnRtcClient');
  var bRtcUse = document.getElementById('btnRtcUse');
  if (bRtcHost) bRtcHost.onclick = rtcHostStart;
  if (bRtcClient) bRtcClient.onclick = rtcClientJoin;
  if (bRtcUse) bRtcUse.onclick = rtcUseCode;

  loadAll(function () {
    requestAnimationFrame(loop);
  });

  setInterval(clearPress, 50);
})();
