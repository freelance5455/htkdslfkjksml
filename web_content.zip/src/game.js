(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const canvas = $("game"), ctx = canvas.getContext("2d");
  const screens = ["homeScreen", "garageScreen", "howScreen", "pauseScreen", "resultScreen"];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const rand = (a, b) => a + Math.random() * (b - a);
  const save = loadSave();
  let W = 0, H = 0, dpr = 1, state = "home", last = 0;
  let elapsed = 0, distance = 0, runCoins = 0, speed = 0, nitro = 100;
  let steering = 0, joystickPointer = null, gyroOn = false, gyroValue = 0;
  let accel = false, braking = false, boosting = false, drifting = false;
  let traffic = [], pickups = [], particles = [], roadOffset = 0, spawnTimer = 0;
  let shake = 0, shield = 0, collisionCooldown = 0, combo = 1, comboTimer = 0;
  let soundOn = true, audio = null, scene = 0, bestCombo = 1;
  const scenes = [
    { sky1: "#07182c", sky2: "#25718a", ground: "#123b3d", road: "#252d38", accent: "#24e8fa", name: "NEON CITY" },
    { sky1: "#10213b", sky2: "#d17d5d", ground: "#335c57", road: "#34343a", accent: "#ffbd73", name: "COASTLINE" },
    { sky1: "#1b1831", sky2: "#9e5e68", ground: "#695036", road: "#343039", accent: "#ff8e77", name: "DESERT RUN" }
  ];

  function loadSave() {
    try { return Object.assign({ coins: 0, best: 0, speedLevel: 1, nitroLevel: 1, handlingLevel: 1 }, JSON.parse(localStorage.getItem("nbr-save") || "{}")); }
    catch (_) { return { coins: 0, best: 0, speedLevel: 1, nitroLevel: 1, handlingLevel: 1 }; }
  }
  function persist() { try { localStorage.setItem("nbr-save", JSON.stringify(save)); } catch (_) {} updateWallet(); }
  function updateWallet() {
    $("wallet").textContent = save.coins;
    $("garageWallet").textContent = save.coins;
    $("homeBest").textContent = save.best + " m";
    ["speed", "nitro", "handling"].forEach(type => {
      const level = save[type + "Level"];
      $(type + "Level").textContent = level + " / 5";
      $(type + "Track").style.width = (level * 20) + "%";
      const btn = $(type + "Upgrade");
      btn.textContent = level >= 5 ? "MAX LEVEL" : "UPGRADE · " + (level * 150) + " ◈";
      btn.disabled = level >= 5 || save.coins < level * 150;
    });
  }
  function resize() {
    const r = canvas.getBoundingClientRect(); W = r.width; H = r.height;
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  addEventListener("resize", resize);
  addEventListener("orientationchange", resize);
  document.addEventListener("fullscreenchange", resize);
  resize();
  function show(id) { screens.forEach(s => $(s).classList.add("hidden")); $(id).classList.remove("hidden"); }
  function toast(msg) {
    $("toast").textContent = msg; $("toast").classList.remove("hidden");
    clearTimeout(toast.timer); toast.timer = setTimeout(() => $("toast").classList.add("hidden"), 1450);
  }
  function beep(freq = 500, dur = .07, wave = "sine") {
    if (!soundOn) return;
    try {
      audio = audio || new (window.AudioContext || window.webkitAudioContext)();
      if (audio.state === "suspended") audio.resume();
      const o = audio.createOscillator(), g = audio.createGain(); o.connect(g); g.connect(audio.destination);
      o.frequency.value = freq; o.type = wave; g.gain.setValueAtTime(.045, audio.currentTime);
      g.gain.exponentialRampToValueAtTime(.001, audio.currentTime + dur); o.start(); o.stop(audio.currentTime + dur);
    } catch (_) {}
  }
  function roadHalfAt(y) { const t = clamp((y - H * .23) / (H * .77), 0, 1); return W * (.105 + .39 * t); }
  function laneX(lane, y = H * .3) { return W / 2 + lane * roadHalfAt(y) * .66; }
  function playerX() { return W / 2 + steering * roadHalfAt(H * .82) * .7; }
  function roundRect(x, y, w, h, r) { ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill(); }

  // Attempt landscape mode only after a real tap. This is deliberately silent:
  // the game never blocks behind a rotate-device screen if the browser refuses.
  function requestLandscapeMode() {
    const lockOrientation = () => {
      try {
        if (screen.orientation && typeof screen.orientation.lock === "function") {
          const lockRequest = screen.orientation.lock("landscape");
          if (lockRequest && typeof lockRequest.catch === "function") lockRequest.catch(() => {});
        }
      } catch (_) {}
    };
    let fullscreenRequest = null;
    try {
      const root = document.documentElement;
      if (!document.fullscreenElement && root.requestFullscreen) {
        fullscreenRequest = root.requestFullscreen({ navigationUI: "hide" });
      }
    } catch (_) {}
    // Lock after fullscreen has been entered where the browser requires it.
    if (fullscreenRequest && typeof fullscreenRequest.then === "function") {
      fullscreenRequest.then(lockOrientation).catch(lockOrientation);
    } else {
      lockOrientation();
    }
  }

  function startRace() {
    requestLandscapeMode();
    state = "playing"; elapsed = distance = runCoins = 0;
    speed = 115; nitro = Math.min(100, 75 + save.nitroLevel * 5); steering = 0;
    accel = braking = boosting = drifting = false; shield = 0; collisionCooldown = 0;
    combo = 1; comboTimer = 0; bestCombo = 1;
    traffic = []; pickups = []; particles = []; roadOffset = 0; spawnTimer = .45; shake = 0;
    scene = Math.floor(Math.random() * scenes.length);
    show("homeScreen"); $("homeScreen").classList.add("hidden");
    $("hud").classList.remove("hidden"); $("touchControls").classList.remove("hidden");
    $("progressBar").style.width = "0%"; last = performance.now(); beep(650, .16, "triangle");
  }
  function pause() {
    if (state !== "playing") return;
    state = "paused"; accel = braking = boosting = drifting = false;
    show("pauseScreen");
  }
  function resume() {
    if (state !== "paused") return;
    state = "playing"; show("homeScreen"); $("homeScreen").classList.add("hidden"); last = performance.now();
  }
  function endRace() {
    if (state !== "playing") return;
    state = "result"; accel = braking = boosting = drifting = false;
    $("hud").classList.add("hidden"); $("touchControls").classList.add("hidden");
    save.coins += runCoins; save.best = Math.max(save.best, Math.floor(distance)); persist();
    $("resultDistance").textContent = Math.floor(distance) + " m";
    $("resultCoins").textContent = runCoins;
    $("bestDistance").textContent = save.best + " m";
    $("resultTitle").innerHTML = distance > 1000 ? "ROAD <em>LEGEND</em>" : "RIDE <em>COMPLETE</em>";
    $("resultMessage").textContent = bestCombo > 1 ? "Peak combo ×" + bestCombo + " — keep the streak alive." : "Every ride makes you a better racer.";
    show("resultScreen"); beep(190, .25, "sawtooth");
  }
  function burst(x, y, color, count = 12) {
    for (let i = 0; i < count; i++) particles.push({ x, y, vx: rand(-160, 160), vy: rand(-170, 100), life: rand(.25, .7), max: .7, color, size: rand(2, 5) });
  }
  function addPickup() {
    const r = Math.random();
    const kind = r < .68 ? "coin" : r < .88 ? "nitro" : "shield";
    const lane = [-.72, 0, .72][Math.floor(Math.random() * 3)];
    pickups.push({ lane, y: H * .26, kind, taken: false, spin: rand(0, 6) });
  }
  function spawnTraffic() {
    const lane = [-.72, 0, .72][Math.floor(Math.random() * 3)];
    const bike = Math.random() < .22;
    traffic.push({ lane, y: H * .25, bike, color: ["#ff477c", "#ffb14b", "#9b80ff", "#57dc9a", "#f2f4fa"][Math.floor(Math.random() * 5)], dead: false, passed: false });
  }
  function drawBackground() {
    const sc = scenes[scene];
    const sky = ctx.createLinearGradient(0, 0, 0, H); sky.addColorStop(0, sc.sky1); sky.addColorStop(.55, sc.sky2); sky.addColorStop(1, sc.ground);
    ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
    // Horizon glow and distant skyline / hills.
    const glow = ctx.createRadialGradient(W * .5, H * .24, 5, W * .5, H * .24, W * .55);
    glow.addColorStop(0, sc.accent + "55"); glow.addColorStop(1, "transparent"); ctx.fillStyle = glow; ctx.fillRect(0, 0, W, H * .6);
    if (scene === 0) {
      for (let i = 0; i < 30; i++) {
        const bw = W / 23, x = i * bw - 8, bh = 18 + ((i * 43) % Math.max(35, H * .22));
        ctx.fillStyle = i % 2 ? "#091d30" : "#102d40"; ctx.fillRect(x, H * .25 - bh, bw - 3, bh);
        ctx.fillStyle = "#42c9da55"; for (let wy = H * .25 - bh + 7; wy < H * .25 - 5; wy += 13) ctx.fillRect(x + 5, wy, 3, 4);
      }
    } else {
      ctx.fillStyle = scene === 1 ? "#183c42" : "#493c3c";
      ctx.beginPath(); ctx.moveTo(0, H * .32);
      for (let x = 0; x <= W; x += W / 10) ctx.lineTo(x, H * (.27 + Math.sin(x * .014 + roadOffset * .0008) * .06));
      ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath(); ctx.fill();
    }
  }
  function drawRoad() {
    const hy = H * .24, topHalf = roadHalfAt(hy), bottomHalf = roadHalfAt(H);
    ctx.fillStyle = scene === 1 ? "#1f474b" : scene === 2 ? "#554531" : "#102d33"; ctx.fillRect(0, hy, W, H - hy);
    ctx.fillStyle = scenes[scene].road; ctx.beginPath(); ctx.moveTo(W / 2 - topHalf, hy); ctx.lineTo(W / 2 + topHalf, hy); ctx.lineTo(W / 2 + bottomHalf, H); ctx.lineTo(W / 2 - bottomHalf, H); ctx.closePath(); ctx.fill();
    // Reflective shoulder rails.
    ctx.lineWidth = 4; ctx.strokeStyle = scenes[scene].accent; ctx.shadowColor = ctx.strokeStyle; ctx.shadowBlur = 8;
    ctx.beginPath(); ctx.moveTo(W / 2 - topHalf, hy); ctx.lineTo(W / 2 - bottomHalf, H); ctx.moveTo(W / 2 + topHalf, hy); ctx.lineTo(W / 2 + bottomHalf, H); ctx.stroke(); ctx.shadowBlur = 0;
    // Lane dividers scale with perspective.
    for (const lane of [-1 / 3, 1 / 3]) {
      ctx.strokeStyle = "#d5e4e988"; ctx.lineWidth = 1.5; ctx.setLineDash([18, 19]); ctx.lineDashOffset = -roadOffset;
      ctx.beginPath(); ctx.moveTo(W / 2 + lane * topHalf * 2, hy); ctx.lineTo(W / 2 + lane * bottomHalf * 2, H); ctx.stroke();
    }
    ctx.setLineDash([]);
    // Animated short edge dashes.
    for (let i = 0; i < 14; i++) {
      const t = ((i / 14 + (roadOffset / 430) % 1) % 1), y = hy + t * (H - hy), half = roadHalfAt(y), mark = 3 + t * 5;
      ctx.fillStyle = i % 2 ? "#eafaff" : scenes[scene].accent;
      ctx.fillRect(W / 2 - half - 9, y, mark, 3 + t * 4); ctx.fillRect(W / 2 + half + 5, y, mark, 3 + t * 4);
    }
    // Passing roadside lights.
    for (let i = 0; i < 8; i++) {
      const t = ((i / 8 + (roadOffset / 620) % 1) % 1), y = hy + t * (H - hy), half = roadHalfAt(y), s = .25 + t * .8;
      for (const side of [-1, 1]) {
        const x = W / 2 + side * (half + 22 * s);
        ctx.fillStyle = "#081a24"; ctx.fillRect(x - 2 * s, y - 26 * s, 4 * s, 26 * s);
        ctx.fillStyle = scenes[scene].accent; ctx.shadowColor = ctx.fillStyle; ctx.shadowBlur = 12 * s;
        ctx.beginPath(); ctx.arc(x, y - 28 * s, 4 * s, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
      }
    }
  }
  function drawBike(x, y, scale, color, lean = 0, isPlayer = false) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(lean); ctx.scale(scale, scale);
    // Tire and contact shadow.
    ctx.fillStyle = "#0009"; ctx.beginPath(); ctx.ellipse(0, 17, 27, 9, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#080c12"; ctx.strokeStyle = "#8fa7b4"; ctx.lineWidth = 2.5;
    for (const yy of [-18, 20]) { ctx.beginPath(); ctx.ellipse(0, yy, 8.5, 13, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); }
    // Rear fairing, tail light and tank.
    ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(-14, -19); ctx.lineTo(-10, -8); ctx.lineTo(-18, 9); ctx.lineTo(-11, 18); ctx.lineTo(11, 18); ctx.lineTo(18, 8); ctx.lineTo(10, -9); ctx.lineTo(13, -20); ctx.lineTo(0, -27); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#142637"; ctx.beginPath(); ctx.moveTo(-8, -16); ctx.lineTo(0, -23); ctx.lineTo(8, -16); ctx.lineTo(6, -6); ctx.lineTo(-6, -6); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#e8fbff"; ctx.fillRect(-3, -24, 6, 3); ctx.fillStyle = "#ff315c"; ctx.fillRect(-5, 14, 10, 4);
    // Rider and helmet.
    ctx.strokeStyle = "#111923"; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(-7, -13); ctx.lineTo(-9, -29); ctx.lineTo(0, -34); ctx.lineTo(9, -28); ctx.lineTo(7, -13); ctx.stroke();
    ctx.fillStyle = isPlayer ? "#152c43" : "#262539"; ctx.beginPath(); ctx.ellipse(0, -34, 9, 10, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = isPlayer ? "#70f5ff" : "#ffb7c5"; ctx.fillRect(1, -37, 7, 4);
    if (isPlayer && shield > 0) { ctx.strokeStyle = "#4af1ffbb"; ctx.lineWidth = 2; ctx.shadowColor = "#22eaff"; ctx.shadowBlur = 18; ctx.beginPath(); ctx.ellipse(0, -5, 32, 51, 0, 0, Math.PI * 2); ctx.stroke(); ctx.shadowBlur = 0; }
    ctx.restore();
  }
  function drawCar(o) {
    const t = clamp((o.y - H * .24) / (H * .76), 0, 1), s = .3 + t * .92, x = laneX(o.lane, o.y), y = o.y;
    if (o.bike) { drawBike(x, y, s * .75, o.color, 0, false); return; }
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
    ctx.fillStyle = "#0008"; ctx.beginPath(); ctx.ellipse(0, 24, 27, 8, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#10151d"; roundRect(-24, -19, 7, 17, 2); roundRect(17, -19, 7, 17, 2); roundRect(-24, 9, 7, 17, 2); roundRect(17, 9, 7, 17, 2);
    ctx.fillStyle = o.color; roundRect(-21, -28, 42, 56, 8);
    ctx.fillStyle = "#163346"; ctx.beginPath(); ctx.moveTo(-15, -19); ctx.lineTo(14, -19); ctx.lineTo(17, -3); ctx.lineTo(-17, -3); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#eafaff"; ctx.fillRect(-16, 19, 8, 4); ctx.fillRect(8, 19, 8, 4); ctx.fillStyle = "#ff345e"; ctx.fillRect(-15, -25, 7, 3); ctx.fillRect(8, -25, 7, 3);
    ctx.restore();
  }
  function drawPickup(p) {
    const t = clamp((p.y - H * .24) / (H * .76), 0, 1), s = .4 + t * .9, x = laneX(p.lane, p.y);
    ctx.save(); ctx.translate(x, p.y); ctx.rotate(p.spin); ctx.scale(s, s);
    const color = p.kind === "coin" ? "#ffd34d" : p.kind === "nitro" ? "#36eaff" : "#86ffbd";
    ctx.fillStyle = color; ctx.shadowColor = color; ctx.shadowBlur = 18; ctx.beginPath();
    if (p.kind === "coin") ctx.arc(0, 0, 10, 0, Math.PI * 2); else ctx.moveTo(0, -13), ctx.lineTo(11, -5), ctx.lineTo(9, 9), ctx.lineTo(0, 14), ctx.lineTo(-9, 9), ctx.lineTo(-11, -5), ctx.closePath();
    ctx.fill(); ctx.shadowBlur = 0; ctx.fillStyle = "#092033"; ctx.font = "bold 12px Arial"; ctx.textAlign = "center";
    ctx.fillText(p.kind === "coin" ? "◈" : p.kind === "nitro" ? "⚡" : "+", 0, 4); ctx.restore();
  }
  function update(dt) {
    if (state !== "playing") return;
    elapsed += dt; collisionCooldown = Math.max(0, collisionCooldown - dt);
    const maxSpeed = 265 + save.speedLevel * 18;
    let targetSpeed = accel ? maxSpeed : 145;
    if (braking) targetSpeed = 62;
    if (boosting && nitro > 0) { targetSpeed = maxSpeed + 95; nitro = Math.max(0, nitro - (23 - save.nitroLevel * 1.5) * dt); }
    else nitro = Math.min(100, nitro + (4.5 + save.nitroLevel * .6) * dt);
    speed += (targetSpeed - speed) * Math.min(1, dt * (braking ? 3.8 : 1.25));

    let steerInput = gyroOn ? gyroValue : 0;
    if (Math.abs(joystickAxis) > .04) steerInput = joystickAxis;
    steering = clamp(steering + steerInput * dt * (1.9 + save.handlingLevel * .12), -1, 1);
    if (Math.abs(steerInput) <= .04) steering *= Math.max(0, 1 - dt * 1.4);
    if (drifting && Math.abs(steerInput) > .12) { combo = Math.min(5, combo + dt * .4); comboTimer = 2.2; }
    if (comboTimer > 0) comboTimer -= dt; else combo = Math.max(1, combo - dt * .9);
    bestCombo = Math.max(bestCombo, Math.floor(combo));

    const distanceRate = speed / 3.6;
    distance += distanceRate * dt; roadOffset += speed * dt * .85;
    if (boosting && nitro > 0 && Math.random() < .8) burst(playerX(), H * .82, "#37eaff", 1);
    spawnTimer -= dt;
    if (spawnTimer <= 0) { spawnTraffic(); if (Math.random() < .88) addPickup(); spawnTimer = Math.max(.48, 1.25 - elapsed * .0025); }

    const px = playerX(), py = H * .82;
    for (const o of traffic) {
      o.y += dt * (105 + speed * .72); o.x = laneX(o.lane, o.y);
      if (o.y > H + 70) o.dead = true;
      if (!o.passed && o.y > py + 35) { o.passed = true; combo = Math.min(5, combo + .12); }
      if (collisionCooldown <= 0 && Math.abs(o.x - px) < (o.bike ? 22 : 27) && Math.abs(o.y - py) < (o.bike ? 30 : 35)) {
        if (shield > 0) { shield = 0; collisionCooldown = 1.1; o.dead = true; burst(px, py, "#5cfff0", 24); toast("SHIELD ABSORBED IMPACT"); beep(880, .15, "triangle"); }
        else { burst(px, py, "#ff507a", 25); shake = 13; endRace(); return; }
      }
    }
    for (const p of pickups) {
      p.y += dt * (105 + speed * .72); p.spin += dt * 2.4;
      const x = laneX(p.lane, p.y);
      if (!p.taken && Math.abs(x - px) < 27 && Math.abs(p.y - py) < 34) {
        p.taken = true;
        if (p.kind === "coin") { const amount = Math.max(5, Math.round(5 * combo)); runCoins += amount; toast("+" + amount + " CREDITS  ·  ×" + combo.toFixed(1)); beep(880, .06); }
        if (p.kind === "nitro") { nitro = Math.min(100, nitro + 35); toast("NITRO RECHARGED"); beep(1050, .1); }
        if (p.kind === "shield") { shield = 1; toast("SHIELD ACTIVATED"); beep(720, .12); }
        burst(x, p.y, p.kind === "coin" ? "#ffd34d" : p.kind === "nitro" ? "#35eaff" : "#86ffbd", 15);
      }
    }
    traffic = traffic.filter(o => !o.dead); pickups = pickups.filter(p => !p.taken && p.y < H + 35);
    for (const p of particles) { p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt; }
    particles = particles.filter(p => p.life > 0);

    $("distance").innerHTML = Math.floor(distance) + " <i>m</i>";
    $("speed").innerHTML = Math.floor(speed) + " <i>km/h</i>";
    $("runCoins").textContent = runCoins;
    $("nitroBar").style.width = nitro + "%";
    $("progressBar").style.width = (distance % 1000) / 10 + "%";
    $("steerReadout").textContent = shield ? "SHIELD ACTIVE" : drifting ? "DRIFT MODE" : gyroOn ? "GYRO STEER" : "STEERING";
  }
  function render() {
    ctx.save();
    if (shake > 0) { ctx.translate(rand(-shake, shake), rand(-shake, shake)); shake *= .84; }
    drawBackground(); drawRoad();
    pickups.forEach(drawPickup);
    traffic.sort((a, b) => a.y - b.y).forEach(drawCar);
    if (state === "playing" || state === "paused") {
      const lean = clamp((gyroOn ? gyroValue : joystickAxis) * -.18 + (drifting ? -.12 : 0), -.25, .25);
      drawBike(playerX(), H * .82, 1.18, "#14dcef", lean, true);
      if (boosting && nitro > 0) {
        const x = playerX(); ctx.fillStyle = "#34ecff"; ctx.shadowColor = "#2beaff"; ctx.shadowBlur = 22;
        ctx.beginPath(); ctx.moveTo(x - 7, H * .84); ctx.lineTo(x, H * .96 + Math.random() * 9); ctx.lineTo(x + 7, H * .84); ctx.fill(); ctx.shadowBlur = 0;
      }
      if (drifting) { const x = playerX(); ctx.strokeStyle = "#b68dff"; ctx.lineWidth = 3; ctx.globalAlpha = .7; ctx.beginPath(); ctx.moveTo(x - 17, H * .86); ctx.lineTo(x - 60, H * .91); ctx.moveTo(x + 17, H * .86); ctx.lineTo(x + 60, H * .91); ctx.stroke(); ctx.globalAlpha = 1; }
    }
    for (const p of particles) { ctx.globalAlpha = clamp(p.life / p.max, 0, 1); ctx.fillStyle = p.color; ctx.fillRect(p.x, p.y, p.size, p.size); }
    ctx.globalAlpha = 1;
    if (state === "home") { ctx.fillStyle = "#ffffff22"; ctx.font = "bold 10px Arial"; ctx.textAlign = "center"; ctx.fillText("RIDE THE NIGHT", W / 2, H * .92); }
    ctx.restore();
  }
  function frame(t) { const dt = Math.min((t - last) / 1000 || 0, .04); last = t; update(dt); render(); requestAnimationFrame(frame); }
  requestAnimationFrame(frame);

  // UI navigation and garage upgrades.
  $("playBtn").addEventListener("click", startRace);
  $("garageBtn").onclick = () => { updateWallet(); show("garageScreen"); };
  $("howBtn").onclick = () => show("howScreen");
  document.querySelectorAll("[data-back]").forEach(b => b.onclick = () => show("homeScreen"));
  $("pauseBtn").onclick = pause; $("resumeBtn").onclick = resume;
  $("quitBtn").onclick = () => { state = "home"; $("hud").classList.add("hidden"); $("touchControls").classList.add("hidden"); show("homeScreen"); };
  $("againBtn").onclick = startRace;
  $("homeBtn").onclick = () => { state = "home"; show("homeScreen"); };
  $("soundBtn").onclick = () => { soundOn = !soundOn; $("soundBtn").textContent = soundOn ? "♫" : "♩̸"; };
  function upgrade(type) {
    const level = save[type + "Level"], cost = level * 150;
    if (level >= 5) { toast("MAX LEVEL REACHED"); return; }
    if (save.coins < cost) { toast("NOT ENOUGH CREDITS"); return; }
    save.coins -= cost; save[type + "Level"]++; persist(); updateWallet(); toast(type.toUpperCase() + " UPGRADED"); beep(740, .12, "triangle");
  }
  $("speedUpgrade").onclick = () => upgrade("speed");
  $("nitroUpgrade").onclick = () => upgrade("nitro");
  $("handlingUpgrade").onclick = () => upgrade("handling");

  // Left-side virtual joystick. It continuously supplies an analogue steering value.
  let joystickAxis = 0;
  const joystick = $("joystick"), knob = $("joyKnob");
  function moveJoystick(e) {
    const r = joystick.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const dx = e.clientX - cx, dy = e.clientY - cy, radius = r.width * .34;
    const nx = clamp(dx / radius, -1, 1), ny = clamp(dy / radius, -1, 1);
    joystickAxis = nx; knob.style.transform = `translate(${nx * 22}px,${ny * 22}px)`;
  }
  joystick.addEventListener("pointerdown", e => { joystickPointer = e.pointerId; joystick.setPointerCapture(e.pointerId); moveJoystick(e); });
  joystick.addEventListener("pointermove", e => { if (e.pointerId === joystickPointer) moveJoystick(e); });
  function releaseJoystick(e) { if (e.pointerId !== joystickPointer) return; joystickPointer = null; joystickAxis = 0; knob.style.transform = "translate(0,0)"; }
  joystick.addEventListener("pointerup", releaseJoystick); joystick.addEventListener("pointercancel", releaseJoystick);

  // Gyro/phone tilt steering. Permission request is made in the button's user gesture.
  async function enableGyro() {
    if (gyroOn) { gyroOn = false; gyroValue = 0; $("gyroBtn").classList.remove("active"); $("gyroBtn").innerHTML = "<span class=\"gyro-btn-icon\">◉</span><span>GYRO OFF</span>"; toast("GYRO STEERING OFF"); return; }
    try {
      if (typeof DeviceOrientationEvent === "undefined") throw new Error("Motion sensor unavailable");
      if (typeof DeviceOrientationEvent.requestPermission === "function") {
        const permission = await DeviceOrientationEvent.requestPermission();
        if (permission !== "granted") throw new Error("Motion permission denied");
      }
      gyroOn = true; $("gyroBtn").classList.add("active"); $("gyroBtn").innerHTML = "<span class=\"gyro-btn-icon\">◉</span><span>GYRO ON</span>"; toast("TILT PHONE TO STEER");
    } catch (err) { gyroOn = false; toast("GYRO UNAVAILABLE · USE JOYSTICK"); }
  }
  $("gyroBtn").onclick = enableGyro;
  addEventListener("deviceorientation", e => {
    if (!gyroOn || e.gamma == null) return;
    // Gamma is left/right tilt in degrees; the dead zone reduces accidental drift.
    let angle = (screen.orientation && typeof screen.orientation.angle === "number") ? screen.orientation.angle : (window.orientation || 0);
    angle = ((angle % 360) + 360) % 360;
    const tilt = angle === 90 ? e.beta : angle === 270 ? -e.beta : e.gamma;
    const raw = clamp(tilt / 25, -1, 1);
    gyroValue = Math.abs(raw) < .08 ? 0 : raw;
  }, true);

  // Left-side action buttons, with pointer capture to prevent stuck buttons.
  function bindHold(id, setter) {
    const el = $(id);
    const down = e => { e.preventDefault(); setter(true); el.classList.add("pressed"); };
    const up = e => { e.preventDefault(); setter(false); el.classList.remove("pressed"); };
    el.addEventListener("pointerdown", down);
    ["pointerup", "pointercancel", "pointerleave"].forEach(ev => el.addEventListener(ev, up));
  }
  bindHold("accelBtn", v => accel = v);
  bindHold("brakeBtn", v => braking = v);
  bindHold("nitroBtn", v => boosting = v);
  bindHold("driftBtn", v => drifting = v);

  addEventListener("keydown", e => {
    if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", " "].includes(e.key)) e.preventDefault();
    if (e.key === "ArrowLeft" || e.key.toLowerCase() === "a") joystickAxis = -1;
    if (e.key === "ArrowRight" || e.key.toLowerCase() === "d") joystickAxis = 1;
    if (e.key === "ArrowUp" || e.key.toLowerCase() === "w") accel = true;
    if (e.key === "ArrowDown" || e.key.toLowerCase() === "s") braking = true;
    if (e.key === " " || e.key === "Shift") boosting = true;
    if (e.key.toLowerCase() === "x") drifting = true;
    if (e.key === "Escape" || e.key.toLowerCase() === "p") { if (state === "playing") pause(); else if (state === "paused") resume(); }
  });
  addEventListener("keyup", e => {
    if (e.key === "ArrowLeft" || e.key === "ArrowRight" || e.key.toLowerCase() === "a" || e.key.toLowerCase() === "d") joystickAxis = 0;
    if (e.key === "ArrowUp" || e.key.toLowerCase() === "w") accel = false;
    if (e.key === "ArrowDown" || e.key.toLowerCase() === "s") braking = false;
    if (e.key === " " || e.key === "Shift") boosting = false;
    if (e.key.toLowerCase() === "x") drifting = false;
  });
  document.addEventListener("visibilitychange", () => { if (document.hidden && state === "playing") pause(); });
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("sw.js").catch(() => {});
  updateWallet();
})();
