(()=>{'use strict';
const C=document.getElementById('game'),X=C.getContext('2d',{alpha:false}),$=id=>document.getElementById(id),W=720,H=1000,TS=68,OX=54,OY=104,NC=9,NR=12,PI2=Math.PI*2,clamp=(n,a,b)=>Math.max(a,Math.min(b,n)),rand=(a,b)=>a+Math.random()*(b-a),len=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),cell=(c,r)=>({x:OX+(c+.5)*TS,y:OY+(r+.5)*TS});
const MAPS=[{title:'Пригород',icon:'🏚️',desc:'Первые улицы заражённого города',route:[[4,0],[4,2],[1,2],[1,5],[7,5],[7,8],[3,8],[3,11]],bg:0},{title:'Больница',icon:'🏥',desc:'Зигзаги у разрушенной больницы',route:[[1,0],[1,3],[6,3],[6,6],[2,6],[2,9],[7,9],[7,11]],bg:1},{title:'Метро',icon:'🚇',desc:'Узкие пути и тяжёлые атаки',route:[[7,0],[7,2],[2,2],[2,5],[6,5],[6,9],[1,9],[1,11]],bg:2},{title:'Последний мост',icon:'🌉',desc:'Решающая битва за убежище',route:[[4,0],[4,3],[7,3],[7,6],[1,6],[1,9],[4,9],[4,11]],bg:3}];
const TOWERS=[{name:'Автомат',icon:'🔫',cost:65,damage:13,cool:.34,range:147,color:'#84ffc4',kind:'bullet',desc:'Быстрые пули'},{name:'Гранатомёт',icon:'💣',cost:105,damage:38,cool:1.5,range:168,color:'#ffba6a',kind:'cannon',desc:'Взрыв по группе'},{name:'Морозилка',icon:'❄️',cost:105,damage:10,cool:.79,range:168,color:'#9bdfff',kind:'ice',desc:'Тормозит зомби'},{name:'Лазер',icon:'🔴',cost:155,damage:12,cool:.18,range:176,color:'#ff7899',kind:'laser',desc:'Сжигает броню'},{name:'Тесла',icon:'⚡',cost:190,damage:28,cool:.72,range:175,color:'#d5aeff',kind:'tesla',desc:'Цепной разряд'},{name:'Огнемёт',icon:'🔥',cost:148,damage:15,cool:.26,range:125,color:'#ff9560',kind:'flame',desc:'Поджигает толпу'},{name:'Снайпер',icon:'🎯',cost:188,damage:113,cool:2.0,range:300,color:'#ffe69e',kind:'sniper',desc:'Сильный одиночный'},{name:'Рельсотрон',icon:'🚀',cost:285,damage:175,cool:2.6,range:335,color:'#72f5ff',kind:'rail',desc:'Пробивает линию врагов'},{name:'Плазма',icon:'🟣',cost:225,damage:37,cool:.93,range:180,color:'#e59aff',kind:'plasma',desc:'Импульс по группе'}];
const ENEMIES={walker:{name:'Шатун',hp:65,spd:46,prize:11,size:17,skin:'#8dd38f'},runner:{name:'Бегун',hp:48,spd:99,prize:15,size:14,skin:'#e2bc71'},brute:{name:'Громила',hp:260,spd:29,prize:26,size:24,armor:.32,skin:'#9bc0a2'},toxic:{name:'Токсик',hp:142,spd:46,prize:23,size:19,regen:5,skin:'#6bf0aa'},split:{name:'Матка',hp:155,spd:43,prize:23,size:21,split:true,skin:'#e4b3ef'},crawler:{name:'Ползун',hp:40,spd:112,prize:5,size:10,skin:'#d4a4bc'},shield:{name:'Щитоносец',hp:190,spd:41,prize:30,size:20,armor:.15,skin:'#8bd3c1'},spitter:{name:'Плевун',hp:120,spd:57,prize:25,size:17,skin:'#b9d67d'},boss:{name:'Альфа-зомби',hp:1650,spd:24,prize:250,size:37,armor:.17,skin:'#ef8898',boss:true}};
const HEROES=[
{id:'ray',name:'Рэй',role:'Штурмовик',icon:'🔫',color:'#50e8ff',bio:'Бывший спецназовец. Скорострельность и урон повышены.',damage:1.3,rate:.77,skill:'ЭМИ-импульс'},
{id:'iris',name:'Айрис',role:'Инженер',icon:'🛠️',color:'#ffc36a',bio:'Механик убежища. Башни дешевле, её импульс усиливает оборону.',damage:.88,rate:1,skill:'Перегрузка турелей'},
{id:'mira',name:'Мира',role:'Медик',icon:'💚',color:'#76ffaa',bio:'Полевой врач. Лечит баррикаду между волнами и применяет лечебный импульс.',damage:.96,rate:.94,skill:'Исцеляющий импульс'}
];
const CHAPTERS=[
{title:'Глава I. Первый сигнал',line:'Связь с пригородом оборвалась. Удержите эвакуационный путь.',boss:'Мясник',ability:'Вызывает орду бегунов',color:'#ff8b79'},
{title:'Глава II. Нулевой пациент',line:'В больнице найден источник мутации. Не дайте заражению выйти наружу.',boss:'Чумная мать',ability:'Исцеляет зомби и выделяет токсичный газ',color:'#9afc86'},
{title:'Глава III. Чёрный туннель',line:'Под метро слышен механический гул. Захватите узел питания.',boss:'Электро-призрак',ability:'Отключает боевые башни импульсом',color:'#a4bcff'},
{title:'Глава IV. Последняя надежда',line:'Мост — единственный выход из города. Сразитесь с вожаком орды.',boss:'Титан Апокалипсиса',ability:'Входит в ярость и вызывает подкрепления',color:'#ff6b97'}
];
let chosenHero='ray';const heroData=()=>HEROES.find(h=>h.id===(game?.hero.kind||chosenHero))||HEROES[0];
const TECH=[['damage','⚔️ Баллистика','+8% урона',5],['income','🪙 Снабжение','+45 начальных монет',5],['range','🔭 Оптика','+5% дальности',4],['fort','❤️ Баррикада','+3 прочности базы',5]];
const BOOSTS=[{title:'Ускорители',icon:'⚡',desc:'Все башни стреляют на 18% быстрее',apply:s=>s.rateBonus+=.18},{title:'Тяжёлые пули',icon:'🎯',desc:'Урон всех башен +20%',apply:s=>s.dmgBonus+=.20},{title:'Припасы',icon:'🪙',desc:'+240 монет для строительства',apply:s=>s.gold+=240},{title:'Укрепление',icon:'❤️',desc:'Восстанавливает 7 прочности базы',apply:s=>s.hp=Math.min(s.hpMax,s.hp+7)},{title:'Дальнобойность',icon:'🔭',desc:'Дальность башен +15%',apply:s=>s.rangeBonus+=.15},{title:'Энергоячейка',icon:'🔋',desc:'Полное восстановление энергии',apply:s=>s.energy=100}];
const KEY='zombie_bastion_cinematic_assault_v1';let saved={gems:0,unlocked:1,sound:true,tech:{damage:0,income:0,range:0,fort:0},best:{},hero:'ray',voice:false,heroTech:{}};try{const s=JSON.parse(localStorage.getItem(KEY));if(s&&typeof s==='object')saved={...saved,...s,tech:{...saved.tech,...s.tech},best:s.best||{},heroTech:s.heroTech||{}}}catch(e){}const persist=()=>{try{localStorage.setItem(KEY,JSON.stringify(saved))}catch(e){}};

const DIFFICULTIES=[{title:'🌱 Легко',hp:1.25,gold:1.13,horde:.91,reward:.85},{title:'⚔️ Норма',hp:1,gold:1,horde:1.17,reward:1},{title:'💀 Хардкор',hp:.73,gold:.78,horde:1.49,reward:1.4}];
let chosenMode='campaign';let chosenDifficulty=Number(saved.difficulty||1);if(![0,1,2].includes(chosenDifficulty))chosenDifficulty=1;
const ACHIEVEMENTS=[['first','🎖️ Первые шаги','Уничтожить 25 зомби',4],['hundred','🧟 Истребитель','Уничтожить 150 зомби за миссию',8],['builder','🏗️ Фортификатор','Построить 10 башен за миссию',7],['boss','👑 Охотник','Убить босса',10],['survivor','🛡️ Несокрушимый','Победить без повреждений базы',14],['hero','⭐ Ветеран','Достигнуть 8-го уровня героем',8]];
saved.achievements ||= {};
const CONTRACT_POOL=[{id:'kills',title:'Уничтожить 75 зомби',target:75,bonus:9},{id:'build',title:'Поставить 8 башен',target:8,bonus:6},{id:'levels',title:'Улучшить башни 6 раз',target:6,bonus:7},{id:'waves',title:'Продержаться до 10-й волны',target:10,bonus:10}];
function award(id){if(saved.achievements[id])return;const a=ACHIEVEMENTS.find(v=>v[0]===id);if(!a)return;saved.achievements[id]=true;saved.gems+=a[3];persist();note('🏆 Достижение: '+a[1]+'! +'+a[3]+' 💎');audio(990,.2,'triangle',.05)}
function checkAchievements(){if(!game)return;if(game.kills>=25)award('first');if(game.kills>=150)award('hundred');if(game.built>=10)award('builder');if(game.bossKilled)award('boss');if(game.hero.level>=8)award('hero')}
function contractValue(){if(!game)return 0;return ({kills:game.kills,build:game.built,levels:game.improved,waves:game.wave})[game.contract?.id]||0}
function checkContract(){if(!game||!game.contract||game.contractDone)return;if(contractValue()<game.contract.target)return;game.contractDone=true;saved.gems+=game.contract.bonus;game.gold+=150;persist();note('🎯 КОНТРАКТ ВЫПОЛНЕН! +'+game.contract.bonus+' 💎 и +150 🪙');audio(1040,.22,'triangle',.04)}
chosenHero=saved.hero||'ray';let heroMoveMode=false;let game=null,scene='menu',chosenMap=0,selectedType=null,selectedTower=null,power=null,speed=1,paused=false,last=0,frame=0,uid=0,fx=[],projectiles=[],textFx=[],stains=[],fallen=[],shakes=0,hover=null,touchStart=null,sfxContext=null,toastTimer=0;
const UPGRADE_PATHS=[{id:'damage',icon:'🎯',name:'Меткость',detail:'+12% урона героя / ур.',max:5},{id:'rate',icon:'⚡',name:'Рефлексы',detail:'+8% скорости стрельбы / ур.',max:5},{id:'power',icon:'💥',name:'Супернавык',detail:'+18% эффекта способности / ур.',max:5}];
function heroTechLevel(id,hero=chosenHero){return Math.max(0,Number(saved.heroTech?.[hero]?.[id]||0))}
function trainHero(id){const a=UPGRADE_PATHS.find(x=>x.id===id);if(!a)return;const lv=heroTechLevel(id),cost=9+lv*12;if(lv>=a.max||saved.gems<cost)return;saved.gems-=cost;saved.heroTech[chosenHero]??={};saved.heroTech[chosenHero][id]=lv+1;persist();audio(900,.22);trainingScreen()}
function voiceLine(phrase){if(!saved.voice||!('speechSynthesis' in window))return;try{window.speechSynthesis.cancel();const v=new SpeechSynthesisUtterance(phrase);v.lang='ru-RU';v.rate=1.09;v.pitch=chosenHero==='mira'?1.2:chosenHero==='iris'?1.06:.84;v.volume=.9;const options=window.speechSynthesis.getVoices();const ru=options.find(o=>o.lang.toLowerCase().startsWith('ru'));if(ru)v.voice=ru;window.speechSynthesis.speak(v)}catch(e){}}
function heroTrainingHTML(){return `<div class="hero-progression-label">🧬 ПРОКАЧКА ${HEROES.find(h=>h.id===chosenHero).name.toUpperCase()} · 💎 ${saved.gems}</div><div class="hero-progress">${UPGRADE_PATHS.map(p=>{let level=heroTechLevel(p.id),cost=5+level*7;return `<button data-train="${p.id}" ${level>=p.max||saved.gems<cost?'disabled':''}><b>${p.icon} ${p.name} · ${level}/${p.max}</b><small>${p.detail}</small><small style="color:#e6c7ff;margin-top:5px">${level===p.max?'⭐ МАКС':'💎 '+cost}</small></button>`}).join('')}</div>`}

function trainingScreen(){
 scene='training';paused=true;
 const hero=HEROES.find(h=>h.id===chosenHero);
 overlay(`<div class="crest">${hero.icon}</div><div class="story-heading">ШТАБ ВЫЖИВШИХ</div>
 <h1>РАЗВИТИЕ <em>${hero.name.toUpperCase()}</em></h1>
 <p>${hero.role}. ${hero.bio}</p>
 <div class="training-hero" style="--heroGlow:${hero.color}">
 <div class="portrait" style="color:${hero.color}">${hero.icon}</div>
 <div><strong>${hero.name}</strong><small>Особая способность: ${hero.skill}</small><small>Кристаллы: 💎 ${saved.gems}</small></div></div>
 ${heroTrainingHTML()}
 <p class="training-footnote">Эти улучшения сохраняются между миссиями отдельно для каждого героя.</p>
 <button class="go" id="backToMenu">← К ВЫБОРУ ГЛАВЫ</button>`);
 setupTraining();
 $('backToMenu').onclick=menu;
}

function setupTraining(){document.querySelectorAll('[data-train]').forEach(b=>b.onclick=()=>trainHero(b.dataset.train))}
// Sprite atlases are drawn once at load, then switched frame-by-frame in the game loop.
// This avoids re-drawing every limb on each frame on low-end phones.
const spriteAtlases={};function makeSprite(kind,hero=false){const data=hero?HEROES.find(h=>h.id===kind):ENEMIES[kind];if(!data)return;const atlas=document.createElement('canvas');atlas.width=96*8;atlas.height=96;const s=atlas.getContext('2d');const skin=hero?'#efc9a1':data.skin;const coat=hero?(kind==='ray'?'#296b85':kind==='iris'?'#806442':'#34765e'):(kind==='brute'?'#41505a':kind==='toxic'?'#247e5b':kind==='split'?'#70376c':kind==='boss'?'#7a324e':'#42556a');for(let f=0;f<8;f++){s.save();s.translate(f*96+48,48);const walk=Math.sin(f*Math.PI/4),arm=Math.sin(f*Math.PI/4+Math.PI);s.fillStyle='#06131d55';s.beginPath();s.ellipse(0,27,23,7,0,0,Math.PI*2);s.fill();s.lineCap='round';s.strokeStyle='#18232e';s.lineWidth=12;s.beginPath();s.moveTo(-9,11);s.lineTo(-11+walk*6,28);s.moveTo(9,11);s.lineTo(11-walk*6,28);s.stroke();s.strokeStyle=coat;s.lineWidth=10;s.beginPath();s.moveTo(-16,-10);s.lineTo(-21+arm*5,9);s.moveTo(16,-10);s.lineTo(21-arm*5,9);s.stroke();s.fillStyle=coat;s.beginPath();s.roundRect(-17,-17,34,37,7);s.fill();s.strokeStyle=hero?'#95fbe9':'#172d34';s.lineWidth=3;s.strokeRect(-11,-8,22,15);s.fillStyle=skin;s.beginPath();s.arc(0,-23,14,0,Math.PI*2);s.fill();if(hero){s.fillStyle=kind==='mira'?'#fcffff':kind==='iris'?'#d6ab61':'#223e57';s.beginPath();s.roundRect(-15,-37,30,12,5);s.fill();if(kind==='mira'){s.fillStyle='#39db9b';s.fillRect(-2,-35,4,10);s.fillRect(-6,-31,12,3)}if(kind==='iris'){s.fillStyle='#b7e8f4';s.fillRect(-12,-25,24,5)}}else{const scars=kind==='boss'||kind==='brute';s.fillStyle=scars?'#4a223c':'#263837';s.fillRect(-13,-31,26,5);if(kind==='toxic'){s.fillStyle='#87ffc7';s.fillRect(-7,0,14,5)}if(kind==='split'){s.fillStyle='#ff9fec';s.beginPath();s.arc(0,-39,5,0,Math.PI*2);s.fill()}}s.fillStyle=hero?'#172a42':'#e7ffa1';s.fillRect(-8,-26,5,3);s.fillRect(4,-26,5,3);
 if(hero){s.fillStyle=kind==='ray'?'#d7eeff':kind==='iris'?'#ffda91':'#aaffdc';s.fillRect(13,-9,16,6);s.fillStyle='#1c2b39';s.fillRect(22,-7,7,3)}
 else if(kind==='runner'){s.strokeStyle='#ffdb77';s.lineWidth=3;s.beginPath();s.moveTo(-29,9);s.lineTo(-37,9+walk*3);s.stroke()}
 else if(kind==='brute'){s.fillStyle='#a9b4c4';s.fillRect(-20,-7,40,9)}
 else if(kind==='toxic'){s.strokeStyle='#5fffd1';s.lineWidth=3;s.beginPath();s.arc(0,5,10+Math.abs(walk)*3,0,Math.PI*2);s.stroke()}
 else if(kind==='split'){s.fillStyle='#e8a7f8';s.beginPath();s.arc(16,12,7,0,Math.PI*2);s.fill()}
 if(kind==='boss'){s.strokeStyle='#ff6c87';s.lineWidth=4;s.beginPath();s.arc(0,-17,29,0,Math.PI*2);s.stroke()}s.restore()}spriteAtlases[(hero?'hero:':'zombie:')+kind]=atlas}
for(const name of Object.keys(ENEMIES))makeSprite(name,false);for(const h of HEROES)makeSprite(h.id,true);
function spriteDraw(key,x,y,size,tick,alpha=1){const atlas=spriteAtlases[key];if(!atlas)return;const frame=(Math.floor(tick)%8+8)%8;X.save();X.globalAlpha=alpha;X.imageSmoothingEnabled=true;X.drawImage(atlas,frame*96,0,96,96,x-size*1.42,y-size*1.69,size*2.84,size*2.84);X.restore()}
function heroXpNeed(level){return 8+level*5}
function heroWeaponCost(){return Math.round(200*Math.pow(1.6,game?.hero.weapon||0))}
function heroUpgrade(){if(!game||scene!=='play')return;const h=game.hero,price=heroWeaponCost();if(h.weapon>=5){note('⭐ Оружие командира максимально усилено');return}if(game.gold<price){note('🪙 Нужно '+price+' монет для улучшения героя');return}game.gold-=price;h.weapon++;burst(h.x,h.y,'#86f7ff',25,105);note('🔧 Герой: оружие уровня '+(h.weapon+1)+'! Увеличены урон и темп стрельбы.');audio(890,.18);refresh()}
function audio(f=420,d=.07,shape='triangle',volume=.024){if(!saved.sound)return;try{const AC=window.AudioContext||window.webkitAudioContext;sfxContext=sfxContext||new AC();if(sfxContext.state==='suspended')sfxContext.resume();const o=sfxContext.createOscillator(),g=sfxContext.createGain();o.type=shape;o.frequency.setValueAtTime(f,sfxContext.currentTime);o.frequency.exponentialRampToValueAtTime(Math.max(65,f*.63),sfxContext.currentTime+d);g.gain.setValueAtTime(volume,sfxContext.currentTime);g.gain.exponentialRampToValueAtTime(.0001,sfxContext.currentTime+d);o.connect(g).connect(sfxContext.destination);o.start();o.stop(sfxContext.currentTime+d)}catch(e){}}

const SCORES=[
 {bpm:104,bass:[38,38,41,36,38,38,43,36],lead:[62,65,69,65,60,65,67,62],wave:'triangle'},
 {bpm:84,bass:[36,36,39,34,36,41,39,34],lead:[60,63,67,65,60,58,63,62],wave:'sine'},
 {bpm:126,bass:[33,33,36,38,33,41,38,36],lead:[57,60,64,60,57,64,65,60],wave:'square'},
 {bpm:138,bass:[31,31,34,36,38,34,31,29],lead:[55,58,62,65,62,58,60,55],wave:'sawtooth'}
];
saved.music ??= true;
let musicNext=0,musicIndex=0,musicChapter=-1;
function musicNote(n,start,dur,type='triangle',volume=.012){
 if(!saved.music||!saved.sound||!sfxContext)return;
 const o=sfxContext.createOscillator(),g=sfxContext.createGain(),filter=sfxContext.createBiquadFilter();
 const frequency=440*Math.pow(2,(n-69)/12);
 o.type=type;o.frequency.setValueAtTime(frequency,start);
 filter.type='lowpass';filter.frequency.value=type==='sawtooth'?950:1700;
 g.gain.setValueAtTime(.00001,start);
 g.gain.exponentialRampToValueAtTime(volume,start+.02);
 g.gain.exponentialRampToValueAtTime(.00001,start+dur);
 o.connect(filter).connect(g).connect(sfxContext.destination);o.start(start);o.stop(start+dur+.02)
}
function musicTick(){
 if(!saved.music||!saved.sound||!game||scene!=='play'||paused||!sfxContext||sfxContext.state!=='running')return;
 const score=SCORES[game.world]||SCORES[0],step=60/score.bpm/2,clock=sfxContext.currentTime;
 if(musicChapter!==game.world){musicChapter=game.world;musicIndex=0;musicNext=clock+.08}
 if(musicNext<clock-.4)musicNext=clock;
 let iterations=0;
 while(musicNext<clock+.12&&iterations++<4){
  const i=musicIndex%8;
  const intensity=game.active?1:.46;
  musicNote(score.bass[i],musicNext,step*.92,'sine',.012*intensity);
  if(i%2===0||game.active)musicNote(score.lead[i]+(game.bossCinematic>0?12:0),musicNext,step*.74,score.wave,.008*intensity);
  musicIndex++;musicNext+=step;
 }
}
function updateAudioButtons(){
 const b=document.getElementById('music');
 if(b){b.textContent=saved.music?'🎵':'🎼';b.title=saved.music?'Выключить музыку':'Включить музыку';b.setAttribute('aria-label',b.title)}
}

function noise(duration=.08,volume=.012,cutoff=900){if(!saved.sound)return;try{const AC=window.AudioContext||window.webkitAudioContext;sfxContext=sfxContext||new AC();if(sfxContext.state==='suspended')sfxContext.resume();const rate=sfxContext.sampleRate,len=Math.max(1,Math.floor(rate*duration));const buf=sfxContext.createBuffer(1,len,rate),data=buf.getChannelData(0);for(let i=0;i<len;i++)data[i]=(Math.random()*2-1)*(1-i/len);const src=sfxContext.createBufferSource();src.buffer=buf;const filter=sfxContext.createBiquadFilter();filter.type='lowpass';filter.frequency.value=cutoff;const gain=sfxContext.createGain();gain.gain.value=volume;gain.gain.exponentialRampToValueAtTime(.0001,sfxContext.currentTime+duration);src.connect(filter).connect(gain).connect(sfxContext.destination);src.start();src.stop(sfxContext.currentTime+duration)}catch(e){}}
function playFx(name){switch(name){case 'build':audio(680,.09,'triangle',.026);audio(980,.04,'square',.008);break;case 'upgrade':audio(820,.13,'triangle',.03);audio(1160,.05,'square',.008);break;case 'shot-bullet':audio(530,.03,'square',.006);break;case 'shot-laser':audio(860,.06,'sine',.008);break;case 'shot-cannon':audio(160,.11,'sawtooth',.024);noise(.06,.012,700);break;case 'shot-sniper':audio(520,.08,'square',.015);audio(220,.04,'triangle',.006);break;case 'explosion':audio(130,.24,'sawtooth',.03);noise(.12,.014,850);break;case 'flame':audio(300,.05,'triangle',.007);noise(.05,.007,1200);break;case 'impact':audio(430,.04,'triangle',.006);break;case 'death':audio(105+Math.random()*35,.07,'sawtooth',.01);noise(.035,.005,650);break;case 'groan':audio(95+Math.random()*18,.2,'sawtooth',.006);break;case 'alert':audio(220,.16,'sawtooth',.026);audio(440,.12,'triangle',.012);break;case 'boss-arrive':audio(84,.42,'sawtooth',.055);audio(180,.25,'triangle',.018);noise(.18,.01,500);break;case 'hero-skill':audio(610,.18,'triangle',.03);audio(930,.1,'sine',.012);break;}}
function note(text){$('status').textContent=text;const t=$('toast');t.textContent=text;t.classList.add('visible');toastTimer=2.3}const overlay=(html)=>{$('cover').classList.remove('hide');$('modal').innerHTML=html};const hideOverlay=()=>$('cover').classList.add('hide');
// ── ACTIVE QUESTS ─────────────────────────────────────
const QUEST_POOL=[
 {id:'kills',icon:'🧟',name:'Охота на заражённых',targets:[20,55,115,220],gems:3,gold:70},
 {id:'build',icon:'🔧',name:'Построй оборону',targets:[2,5,9,13],gems:3,gold:90},
 {id:'levels',icon:'⬆️',name:'Усиль вооружение',targets:[2,4,7,11],gems:4,gold:120},
 {id:'waves',icon:'🛡️',name:'Выдержи атаки',targets:[2,4,6,9],gems:5,gold:140},
 {id:'bosses',icon:'👑',name:'Уничтожь боссов',targets:[1,2,3,4],gems:7,gold:200},
 {id:'abilities',icon:'⚡',name:'Используй навыки',targets:[2,4,6,9],gems:4,gold:95}
];
function questValue(id){if(!game)return 0;return ({kills:game.kills,build:game.built,levels:game.improved,waves:game.wave,bosses:game.bosses||0,abilities:game.abilities||0})[id]||0}
function setupQuests(){if(!game)return;game.questTier??=0;game.quests??=QUEST_POOL.slice(0,3).map((q,i)=>({id:q.id,target:q.targets[0],base:0,bonus:q.gems,gold:q.gold,stage:0}));}
function questProgress(q){return Math.max(0,questValue(q.id)-q.base)}
function checkQuests(){if(!game||!game.quests)return;for(let j=0;j<game.quests.length;j++){
 const q=game.quests[j];if(questProgress(q)<q.target)continue;
 saved.gems+=q.bonus;game.gold+=q.gold;
 const used=new Set(game.quests.filter((_,i)=>i!==j).map(x=>x.id));const start=(QUEST_POOL.findIndex(v=>v.id===q.id)+3+game.questTier+j)%QUEST_POOL.length;const next=Array.from({length:QUEST_POOL.length},(_,k)=>QUEST_POOL[(start+k)%QUEST_POOL.length]).find(v=>!used.has(v.id))||QUEST_POOL[start];
 game.questTier++;const stage=Math.min(3,Math.floor(game.questTier/3));
 game.quests[j]={id:next.id,target:next.targets[stage],base:questValue(next.id),bonus:next.gems+stage*2,gold:next.gold+stage*60,stage};
 note('🏆 Квест выполнен! +'+q.bonus+' 💎 и +'+q.gold+' 🪙');playFx('upgrade');persist();
 }}
function renderQuests(){const el=$('questList');if(!el)return;
 if(!game||!game.quests){el.innerHTML='<div class="quest-empty">Выберите главу, чтобы получить три задания.</div>';return}
 const markup=game.quests.map(q=>{const def=QUEST_POOL.find(v=>v.id===q.id),p=Math.min(q.target,questProgress(q)),pct=Math.min(100,p/q.target*100);
 return `<div class="quest-row"><div class="quest-title"><b>${def.icon} ${def.name}</b><small>${p}/${q.target}</small></div><div class="quest-meter"><i style="width:${pct}%"></i></div><small class="quest-reward">💎 ${q.bonus} · 🪙 ${q.gold}</small></div>`}).join('');
 if(el.innerHTML!==markup)el.innerHTML=markup;
}
// ── SINGLE PLAYER COMBAT CHECKPOINT ─────────────────────
const SAVE_KEY='zombie_bastion_survival_checkpoint_v1';let checkpointTimer=0;
function savedCheckpoint(){try{const c=JSON.parse(localStorage.getItem(SAVE_KEY));return c?.version===1&&c?.state&&Number.isInteger(c.map)&&c.map>=0&&c.map<MAPS.length?c:null}catch(e){return null}}
function clearCheckpoint(){try{localStorage.removeItem(SAVE_KEY)}catch(e){}}
function checkpoint(){if(!game||scene!=='play'||game.done||coop.role==='guest'||coop.role==='host'&&coop.peer)return;
 try{const state={...game,points:undefined,blocked:undefined,enemies:game.enemies,quests:game.quests};
 const shots=projectiles.map(p=>({...p,targetId:p.target?.id??null,target:undefined}));
 localStorage.setItem(SAVE_KEY,JSON.stringify({version:1,time:Date.now(),map:chosenMap,mode:game.mode||'campaign',state,shots,uid}));return true;
 }catch(e){console.warn('Не удалось сохранить бой:',e);return false}
}
function restoreCheckpoint(){const c=savedCheckpoint();if(!c)return;
 const rd=routeData(MAPS[c.map]);chosenMap=c.map;chosenMode=c.mode==='endless'?'endless':'campaign';chosenHero=c.state.hero?.kind||'ray';chosenDifficulty=c.state.difficulty??1;
 game={...c.state,points:rd.points,blocked:rd.blocked,towers:Array.isArray(c.state.towers)?c.state.towers:[],enemies:Array.isArray(c.state.enemies)?c.state.enemies:[],queue:Array.isArray(c.state.queue)?c.state.queue:[],quests:Array.isArray(c.state.quests)?c.state.quests:[],mode:chosenMode};
 setupQuests();uid=Math.max(c.uid||0,...game.enemies.map(e=>e.id||0),...game.towers.map(t=>t.id||0),0);
 const byId=new Map(game.enemies.map(e=>[e.id,e]));projectiles=(c.shots||[]).map(p=>({...p,target:byId.get(p.targetId)||null}));
 rays.length=0;rings.length=0;fx=[];fallen=[];stains=[];textFx=[];shakes=0;selectedTower=null;selectedType=0;power=null;heroMoveMode=false;scene='play';paused=false;speed=1;musicChapter=-1;last=0;
 hideOverlay();$('areaName').innerHTML='☣️ <b>'+MAPS[chosenMap].title.toUpperCase()+'</b> · '+(chosenMode==='endless'?'∞ БЕСКОНЕЧНЫЙ':'КАМПАНИЯ');
 $('speed').textContent='⏩ ×1';$('pause').textContent='⏸ Пауза';note('💾 Бой восстановлен. Волна '+game.wave+' · башен '+game.towers.length);refresh();
}
window.addEventListener('pagehide',checkpoint);
document.addEventListener('visibilitychange',()=>{if(document.hidden)checkpoint()});

function routeData(map){const points=map.route.map(([c,r])=>cell(c,r)),blocked=new Set();for(let i=1;i<map.route.length;i++){const [x1,y1]=map.route[i-1],[x2,y2]=map.route[i];if(x1===x2){for(let y=Math.min(y1,y2);y<=Math.max(y1,y2);y++)blocked.add(x1+','+y)}else{for(let x=Math.min(x1,x2);x<=Math.max(x1,x2);x++)blocked.add(x+','+y1)}}return{points,blocked}}
function menu(){if(scene==='play')checkpoint();if(coop.role==='guest')coopLeave();scene='menu';paused=true;musicChapter=-1;const opts=MAPS.map((m,i)=>`<button class="mission ${i===chosenMap?'active':''}" data-map="${i}" ${i>=saved.unlocked?'disabled':''}><span>${i>=saved.unlocked?'🔒':m.icon}</span><b>${CHAPTERS[i].title}</b><small>${i>=saved.unlocked?'Пройдите предыдущую главу':CHAPTERS[i].line}</small><small>☠️ ${CHAPTERS[i].boss} · ${saved.best[i]||0}/15 · ♾️ ${saved.endlessBest?.[i]||0}</small></button>`).join('');const heroes=HEROES.map(h=>`<button class="hero-select ${h.id===chosenHero?'active':''}" data-hero="${h.id}"><span class="hface" style="--hc:${h.color}">${h.icon}</span><strong>${h.name}</strong><small>${h.role}</small><small>${h.bio}</small></button>`).join('');overlay(`<div class="crest">☣️</div><h1>ZOMBIE <em>BASTION</em><br>ULTIMATE SURVIVAL</h1><p>Сюжетная кампания или бесконечная оборона. Усиленные враги, дорогая прокачка, три активных квеста, сохранение боя и кооператив на двоих.</p><div class="story-heading">🎮 РЕЖИМ ИГРЫ</div><div class="difficulty mode-picker"><button data-mode="campaign" class="${chosenMode==='campaign'?'active':''}">📖 КАМПАНИЯ · 15 ВОЛН</button><button data-mode="endless" class="${chosenMode==='endless'?'active':''}">♾️ БЕСКОНЕЧНЫЙ</button></div><div class="story-heading">⚙️ СЛОЖНОСТЬ</div><div class="difficulty">${DIFFICULTIES.map((d,i)=>`<button data-difficulty="${i}" class="${chosenDifficulty===i?'active':''}">${d.title}</button>`).join('')}</div><div class="story-heading">🗺️ ВЫБЕРИТЕ ГЛАВУ</div><div class="missions">${opts}</div><div class="story-heading">🦸 ВЫБЕРИТЕ ГЕРОЯ</div><div class="hero-selection">${heroes}</div><button class="go" id="openTraining" style="margin:8px 0">🧬 ОТКРЫТЬ ШТАБ И ПРОКАЧКУ ГЕРОЯ</button><div class="story-heading">🏆 ДОСТИЖЕНИЯ</div><div class="achievement-list">${ACHIEVEMENTS.map(a=>`<div class="achievement ${saved.achievements[a[0]]?'awarded':''}"><strong>${saved.achievements[a[0]]?'✅':'🔒'} ${a[1]}</strong><small>${a[2]} · 💎${a[3]}</small></div>`).join('')}</div><button class="go" id="play">${chosenMode==='endless'?'♾️ НАЧАТЬ БЕСКОНЕЧНУЮ ОБОРОНУ':'▶ НАЧАТЬ ГЛАВУ'}</button>${savedCheckpoint()?'<button class="go" id="resumeSave" style="margin-top:9px;background:linear-gradient(120deg,#2259a1,#218b86)">💾 ПРОДОЛЖИТЬ СОХРАНЁННЫЙ БОЙ</button>':''}<button class="coop-button" id="coopOpen">👥 ИГРАТЬ ВДВОЁМ ПО СЕТИ</button><p style="font-size:11px;margin:10px 0">🎧 Включите музыку и эффекты вверху • 📱 управление одним пальцем • прогресс сохраняется</p>`);$('modal').querySelectorAll('[data-map]').forEach(b=>b.onclick=()=>{chosenMap=Number(b.dataset.map);menu()});$('modal').querySelectorAll('[data-hero]').forEach(b=>b.onclick=()=>{chosenHero=b.dataset.hero;saved.hero=chosenHero;persist();menu()});$('modal').querySelectorAll('[data-difficulty]').forEach(b=>b.onclick=()=>{chosenDifficulty=Number(b.dataset.difficulty);saved.difficulty=chosenDifficulty;persist();menu()});$('modal').querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{chosenMode=b.dataset.mode;menu()});$('play').onclick=()=>start(chosenMap);if($('resumeSave'))$('resumeSave').onclick=restoreCheckpoint;$('openTraining').onclick=trainingScreen;$('coopOpen').onclick=coopLobby;refresh()}
function start(i){chosenMap=i;const rd=routeData(MAPS[i]),diff=DIFFICULTIES[chosenDifficulty],hpMax=Math.round((20+(saved.tech.fort||0)*3)*diff.hp);clearCheckpoint();game={mode:chosenMode,hp:hpMax,hpMax,gold:Math.round((335+40*(saved.tech.income||0))*diff.gold),wave:0,maxWaves:15,energy:55,towers:[],enemies:[],queue:[],spawnClock:0,active:false,kills:0,dmgBonus:0,rateBonus:0,rangeBonus:0,elapsed:0,points:rd.points,blocked:rd.blocked,awaitReward:false,done:false,world:i,hero:{kind:chosenHero,x:cell(5,10).x,y:cell(5,10).y,cool:0,dir:-1,pulseCool:0,level:1,xp:0,weapon:0},bloodMoon:false,combo:0,comboTime:0,eliteWave:false,bossTimer:0,built:0,improved:0,contract:CONTRACT_POOL[(i+chosenDifficulty+Math.floor(Math.random()*4))%4],contractDone:false,bossKilled:false,damageTaken:0,difficulty:chosenDifficulty};heroMoveMode=false;selectedType=0;selectedTower=null;power=null;speed=1;paused=false;scene='play';fx=[];projectiles=[];textFx=[];stains=[];fallen=[];fireballs.length=0;shakes=0;game.bossCinematic=0;game.lowHpWarned=false;game.bossAnnounced=false;setupQuests();hideOverlay();$('speed').textContent='⏩ ×1';$('pause').textContent='⏸ Пауза';$('areaName').innerHTML='☣️ <b>'+MAPS[i].title.toUpperCase()+'</b> · '+(game.mode==='endless'?'♾️ БЕСКОНЕЧНЫЙ':'КАМПАНИЯ');note('🎯 Контракт: '+game.contract.title+'. Автомат выбран — коснитесь клетки.');refresh();storyIntro()}
function storyIntro(){paused=true;const c=CHAPTERS[chosenMap],h=heroData();overlay(`<div class="crest">${MAPS[chosenMap].icon}</div><div class="story-heading">${c.title}</div><h1 style="font-size:clamp(24px,7vw,40px)">${MAPS[chosenMap].title.toUpperCase()}</h1><p>${c.line}</p><div class="dialog">🦸 <b>${h.name}:</b> «Мы не можем отступать. Я прикрою оборону, а вы размещайте турели!»</div><div class="boss-intro">☠️ Главный противник: <b>${c.boss}</b><small>${c.ability}</small></div><button class="go" id="deploy">⚔️ НАЧАТЬ ОБОРОНУ</button>`);$('deploy').onclick=()=>{paused=false;hideOverlay();voiceLine(c.title+'. '+c.line+' '+(chosenHero==='ray'?'Цель обнаружена. Держим оборону!':chosenHero==='iris'?'Системы готовы. Включаю турели!':'Я рядом. Никого не бросаем!'));refresh()}}
function beginWave(){if(!game||scene!=='play'||game.active||game.awaitReward||game.done)return;game.wave++;checkContract();checkQuests();game.active=true;game.queue=[];game.spawnClock=.28;game.bloodMoon=game.wave%4===0;game.eliteWave=game.wave%3===0&&!game.bloodMoon;const n=Math.min(110,Math.ceil((9+game.wave*2.15+game.world*2+(game.bloodMoon?7:0))*DIFFICULTIES[game.difficulty].horde));for(let i=0;i<n;i++){let key='walker',r=Math.random();if(game.wave>=3&&r<.23)key='runner';else if(game.wave>=5&&r<.44)key='brute';else if(game.wave>=7&&r<.60)key='toxic';else if(game.wave>=9&&r<.74)key='split';else if(game.wave>=6&&r<.85)key='shield';else if(game.wave>=8&&r<.94)key='spitter';game.queue.push(key)}if(game.wave%4===0){for(let i=0;i<4+game.world;i++)game.queue.push('runner');}if(game.eliteWave){for(let j=0;j<3+game.world;j++)game.queue.push('brute')}if(game.wave%5===0)for(let b=0;b<Math.min(3,1+Math.floor(game.wave/25));b++)game.queue.push('boss');note(game.bloodMoon?'🌕 КРОВАВАЯ ЛУНА! Быстрые зомби, двойная награда!':game.eliteWave?'🛡️ ЭЛИТНАЯ ВОЛНА! Впереди бронированные громилы.':'☣️ Волна '+game.wave+'! Зомби атакуют баррикаду.');playFx(game.wave===15?'alert':'impact');if(game.wave%5===0)voiceLine(game.mode==='endless'?'Внимание! Новая волна боссов! Обороняйте базу!':'Внимание! Опасная волна! Обороняйте базу!');refresh()}
function addZombie(kind,source){const e=ENEMIES[kind],scale=(1+game.wave*.16+game.world*.24)*Math.pow(1.12,Math.floor(Math.max(0,game.wave-10)/5)),hp=e.hp*scale*(kind==='boss'?1+game.wave*.03:1);const p=game.points[0];game.enemies.push({id:++uid,type:kind,x:source?source.x:p.x,y:source?source.y:p.y-55,seg:source?source.seg:0,hp,max:hp,spd:e.spd*(1+Math.min(.65,game.wave*.011))*(game.bloodMoon?1.26:1),armor:e.armor||0,slow:0,burn:0,flash:0,phase:rand(0,PI2),progress:source?source.progress:0,dead:false,ability:kind==='boss'?5.5:0,bossMap:kind==='boss'?game.world:-1,disabledTimer:0,shield:kind==='shield'?hp*.6:0,spitCooldown:kind==='spitter'?3+rand(0,2):0});if(kind==='boss'&&!game.bossAnnounced){game.bossAnnounced=true;game.bossCinematic=2.6;playFx('boss-arrive');voiceLine(chosenHero==='iris'?'Контакт с боссом. Все турели, огонь!':chosenHero==='mira'?'Это огромная цель... держимся вместе!':'Босс на поле. Не подпускайте его к базе!');note('☠️ '+CHAPTERS[game.world].boss+' выходит на поле!');}else if(!source&&Math.random()<.07){playFx('groan')}}
function towerCost(t){return Math.floor(TOWERS[t.type].cost*(1.15*Math.pow(1.64,t.level-1)))}function towerDamage(t){return TOWERS[t.type].damage*(1+(t.level-1)*.53)*(1+game.dmgBonus+(saved.tech.damage||0)*.08+(t.boost>0?.5:0))}function towerRange(t){return TOWERS[t.type].range*(1+(t.level-1)*.07)*(1+game.rangeBonus+(saved.tech.range||0)*.05)}function towerCooldown(t){return TOWERS[t.type].cool/(1+(t.level-1)*.125+game.rateBonus)}
function canBuild(c,r){return c>=0&&c<NC&&r>=0&&r<NR&&!game.blocked.has(c+','+r)&&!game.towers.some(t=>t.c===c&&t.r===r)}
function build(c,r){if(selectedType===null||!game)return;if(!canBuild(c,r)){note('⛔ Здесь строить нельзя. Выберите свободную клетку.');audio(145,.08);return}const base=TOWERS[selectedType],cost=Math.ceil(base.cost*(game.hero.kind==='iris'?.87:1));if(game.gold<cost){note('🪙 Недостаточно монет для '+base.name);audio(150,.08);return}const pos=cell(c,r);game.towers.push({id:++uid,c,r,x:pos.x,y:pos.y,type:selectedType,level:1,angle:-Math.PI/2,cool:rand(0,.2),spent:cost});game.gold-=cost;game.built++;checkContract();checkQuests();checkAchievements();burst(pos.x,pos.y,'#73ffca',12);playFx('build');note('✅ '+base.name+' установлена. Можно строить следующую.');refresh()}
function improve(){if(!selectedTower||scene!=='play')return;const t=selectedTower,price=towerCost(t);if(t.level>=6||game.gold<price){note(t.level>=6?'⭐ Максимальный уровень':'🪙 Недостаточно монет');return}game.gold-=price;t.spent+=price;t.level++;game.improved++;checkContract();checkQuests();burst(t.x,t.y,'#fce18a',17);playFx('upgrade');note('⬆ '+TOWERS[t.type].name+': уровень '+t.level);refresh()}
function sell(){if(!selectedTower||scene!=='play')return;const t=selectedTower,back=Math.floor(t.spent*.72);game.towers=game.towers.filter(v=>v!==t);game.gold+=back;burst(t.x,t.y,'#ffcf83',11);selectedTower=null;note('🪙 Получено '+back+' монет');refresh()}
function choosePower(name){if(scene!=='play'||!game)return;heroMoveMode=false;if(power===name){power=null;refresh();return}const n=name==='strike'?70:50;if(game.energy<n){note('🔋 Не хватает энергии');return}power=name;selectedType=null;selectedTower=null;note(name==='strike'?'☄️ Коснитесь участка дороги для авиаудара':'❄️ Коснитесь толпы зомби для заморозки');refresh()}
function hitPower(p){const strike=power==='strike',radius=strike?146:185,price=strike?70:50;if(!power||game.energy<price)return;game.energy-=price;game.abilities=(game.abilities||0)+1;checkQuests();for(const e of game.enemies){if(len(e,p)<radius){if(strike)damage(e,410+game.wave*13,true);else{e.slow=Math.max(e.slow,5.5);damage(e,30,true)}}}burst(p.x,p.y,strike?'#ffb065':'#b2efff',strike?70:40,200);rings.push({x:p.x,y:p.y,r:0,max:radius,life:.55,color:strike?'#ffae72':'#a2eeff'});if(strike)shakes=11;power=null;audio(strike?145:690,.3,'sawtooth',.075);note(strike?'☄️ Авиаудар выполнен':'❄️ Зомби заморожены');refresh()}
const rings=[];
function damage(e,n,pierce=false){
if(e.dead)return;
let v=n*(pierce?1:1-e.armor);
if(e.shield>0){
 let absorbed=Math.min(e.shield,v);
 e.shield-=absorbed;
 v-=absorbed;
 if(e.shield<=0){
  rings.push({x:e.x,y:e.y,r:0,max:46,life:.35,color:'#85eaff'});
  burst(e.x,e.y,'#9beaff',12,40);
 }
}
e.hp-=v;
e.flash=.1;
burst(e.x+rand(-5,5),e.y+rand(-5,5),ENEMIES[e.type].skin,e.type==='boss'?3:2,16,3);
if(e.hp>0)return;
e.dead=true;
const def=ENEMIES[e.type];
game.gold+=Math.ceil(def.prize*(game.bloodMoon?1.35:1)*.88);
game.kills++;
if(def.boss){game.bossKilled=true;game.bosses=(game.bosses||0)+1;}
checkAchievements();
checkContract();
if(game.hero){
 const h=game.hero;
 h.xp+=def.boss?16:def.prize>=23?2:1;
 while(h.level<12&&h.xp>=heroXpNeed(h.level)){
  h.xp-=heroXpNeed(h.level);
  h.level++;
  checkAchievements();
  burst(h.x,h.y,'#ffe59b',24,90);
  textFx.push({x:h.x,y:h.y-26,text:'⭐ УРОВЕНЬ '+h.level,color:'#ffe59b',life:1});
  audio(910,.19);
 }
}
game.combo++;
game.comboTime=3;
game.energy=Math.min(100,game.energy+(def.boss?28:2.1));
textFx.push({x:e.x,y:e.y-8,text:'+'+(def.prize*(game.bloodMoon?2:1)),color:'#ffdf94',life:1});
burst(e.x,e.y,def.skin,def.boss?55:17,def.boss?130:80);
fallen.push({x:e.x,y:e.y,kind:e.type,size:def.size,phase:e.phase,life:.7,max:.7,tilt:rand(-1.1,1.1)});if(fallen.length>40)fallen.shift();stains.push({x:e.x+rand(-4,4),y:e.y+rand(0,8),r:def.boss?26:rand(8,15),life:def.boss?1:.75,color:def.boss?'rgba(255,72,119,.34)':'rgba(91,14,31,.23)'});
if(stains.length>70)stains.shift();checkQuests();
if(def.split){
 for(let i=0;i<2;i++)addZombie('crawler',{x:e.x+rand(-9,9),y:e.y+rand(-8,8),seg:e.seg,progress:e.progress});
}
if(def.boss){
 saved.gems+=7;
 persist();
 shakes=13;
 voiceLine(chosenHero==='mira'?'Босс уничтожен! Держим линию!':chosenHero==='iris'?'Цель нейтрализована. Отличная работа!':'Босс уничтожен! Продолжаем зачистку!');
 playFx('boss-arrive');
}else if(Math.random()<.5){
 playFx('death');
}
}
function burst(x,y,color,count=10,power=80,size=4){for(let i=0;i<count&&fx.length<420;i++){const a=rand(0,PI2),s=rand(power*.24,power);fx.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:rand(.16,.55),max:.55,color,size:rand(1,size)})}}
function complete(win){if(game.done)return;game.done=true;scene='over';paused=true;if(win&&game.damageTaken===0)award('survivor');clearCheckpoint();const gems=Math.floor((win?26+chosenMap*8:Math.floor(game.wave/5))*DIFFICULTIES[game.difficulty].reward);if(win&&game.mode!=='endless')saved.unlocked=Math.max(saved.unlocked,Math.min(MAPS.length,chosenMap+2));saved.gems+=gems;if(game.mode==='endless'){saved.endlessBest??={};saved.endlessBest[chosenMap]=Math.max(saved.endlessBest[chosenMap]||0,game.wave)}else saved.best[chosenMap]=Math.max(saved.best[chosenMap]||0,game.wave);persist();if(win)voiceLine('Миссия завершена. '+CHAPTERS[chosenMap].title+'. '+(chosenHero==='iris'?'Район зачищен. Переходим к следующей зоне.':chosenHero==='mira'?'Мы справились. Люди в безопасности.':'Рубеж удержан. Отличная работа!'));else voiceLine('Рубеж потерян. '+(chosenHero==='mira'?'Нужно спасти раненых и отступить.':chosenHero==='iris'?'Нужна новая схема обороны.':'Отходим. Перегруппировка и снова в бой.'));overlay(`<div class="crest">${win?'🏆':'💀'}</div><h1>${win?'РАЙОН <em>СПАСЁН</em>':game.mode==='endless'?'♾️ РЕКОРД <em>ОБОРОНЫ</em>':'ОБОРОНА <em>ПРОРВАНА</em>'}</h1><p>${win?'Вы выдержали все 15 волн, победили босса и освободили район!':'Постарайтесь поставить башни на поворотах и комбинировать оружие.'}<br><br>☣️ Волна: <b>${game.wave}</b> · 🧟 Убито: <b>${game.kills}</b><br>💎 Кристаллы: <b>+${gems}</b></p><button class="go" id="again">↻ ПОВТОРИТЬ БОЙ</button><button class="alt" id="back">🗺️ ВЫБРАТЬ РАЙОН</button>`);$('again').onclick=()=>start(chosenMap);$('back').onclick=menu;if(win&&chosenMap<MAPS.length-1){const next=document.createElement('button');next.className='go';next.textContent='➡ СЛЕДУЮЩАЯ ГЛАВА';next.onclick=()=>start(chosenMap+1);$('modal').appendChild(next)}refresh()}
function bonus(){game.awaitReward=true;scene='bonus';paused=true;const options=[...BOOSTS].sort(()=>Math.random()-.5).slice(0,3);overlay(`<div class="crest">🎁</div><h1>ВОЕННЫЕ <em>ПРИПАСЫ</em></h1><p>Вы отразили пять волн. Выберите одно усиление до конца боя.</p><div class="reward-grid">${options.map((b,i)=>`<button data-reward="${i}"><span class="big">${b.icon}</span><b>${b.title}</b><small>${b.desc}</small></button>`).join('')}</div>`);$('modal').querySelectorAll('[data-reward]').forEach(b=>b.onclick=()=>{options[Number(b.dataset.reward)].apply(game);game.awaitReward=false;scene='play';paused=false;hideOverlay();audio(860,.18);note('🎁 Усиление получено. Готовьтесь к новой волне!');refresh()})}
function fireTower(t,enemy){const d=towerDamage(t),type=TOWERS[t.type],kind=type.kind;t.angle=Math.atan2(enemy.y-t.y,enemy.x-t.x);if(fx.length<230){const ax=t.x+Math.cos(t.angle)*35,ay=t.y+Math.sin(t.angle)*35;for(let i=0;i<3;i++)fx.push({x:ax,y:ay,vx:rand(-55,55),vy:rand(-55,55),life:.12,max:.12,size:rand(2,5),color:'#fff1b1'});}const start={x:t.x+Math.cos(t.angle)*25,y:t.y+Math.sin(t.angle)*25};if(kind==='rail'){const a=Math.atan2(enemy.y-t.y,enemy.x-t.x);const end={x:t.x+Math.cos(a)*440,y:t.y+Math.sin(a)*440};let count=0;for(const z of game.enemies){const along=(z.x-t.x)*Math.cos(a)+(z.y-t.y)*Math.sin(a),perp=Math.abs((z.x-t.x)*Math.sin(a)-(z.y-t.y)*Math.cos(a));if(!z.dead&&along>=0&&along<440&&perp<23){damage(z,d,true);count++}}rays.push({x1:start.x,y1:start.y,x2:end.x,y2:end.y,color:type.color,life:.24,max:.24,width:8});rings.push({x:enemy.x,y:enemy.y,r:0,max:52,life:.3,color:'#85faff'});shakes=Math.max(shakes,3); }else if(kind==='laser'||kind==='tesla'){const chain=kind==='tesla'?game.enemies.filter(e=>!e.dead&&len(e,enemy)<115).slice(0,Math.min(5,2+Math.floor(t.level/2))):[enemy];let previous=start;chain.forEach((e,i)=>{damage(e,d*(i===0?1:.64),kind==='laser');rays.push({x1:previous.x,y1:previous.y,x2:e.x,y2:e.y,color:type.color,life:kind==='laser'?.15:.23,max:kind==='laser'?.15:.23,width:kind==='laser'?5:3,zig:kind==='tesla'});previous=e});}else{projectiles.push({x:start.x,y:start.y,px:start.x,py:start.y,target:enemy,tx:enemy.x,ty:enemy.y,kind,damage:d,color:type.color,spd:kind==='cannon'?340:kind==='sniper'?1000:kind==='ice'?420:kind==='flame'?450:kind==='plasma'?480:650,life:1.5,level:t.level})}if(kind==='cannon')playFx('shot-cannon');else if(kind==='sniper'||kind==='rail')playFx('shot-sniper');else if(kind==='flame')playFx('flame');else if(Math.random()<.36)playFx(kind==='laser'||kind==='tesla'?'shot-laser':'shot-bullet')}

const fireballs=[];
function explosionBloom(x,y,kind){if(fireballs.length>28)fireballs.shift();fireballs.push({x,y,kind,age:0,max:kind==='cannon'?.58:.46,radius:kind==='cannon'?100:118})}
function renderFireballs(){
 for(const f of fireballs){const q=f.age/f.max,rad=f.radius*(.23+q*.84),a=Math.max(0,1-q);
  X.save();X.globalCompositeOperation='lighter';X.globalAlpha=a*.84;
  const c=f.kind==='plasma'?'#b459ff':'#ff7c2e';const core=f.kind==='plasma'?'#f6d7ff':'#fff5bd';
  let g=X.createRadialGradient(f.x,f.y,3,f.x,f.y,rad);g.addColorStop(0,core);g.addColorStop(.20,c);g.addColorStop(.53,c+'82');g.addColorStop(1,c+'00');
  X.fillStyle=g;X.beginPath();X.arc(f.x,f.y,rad,0,PI2);X.fill();
  X.lineWidth=5*(1-q);X.strokeStyle=core;X.beginPath();X.arc(f.x,f.y,rad*.66,0,PI2);X.stroke();
  X.restore();
 }
}

const rays=[];
function explode(p,x,y){const kind=p.kind;if(kind==='cannon'||kind==='plasma'){const r=kind==='plasma'?108:82;for(const e of game.enemies){if(!e.dead&&Math.hypot(e.x-x,e.y-y)<r)damage(e,p.damage*(e===p.target?1:.72))}rings.push({x,y,r:0,max:r,life:.35,color:kind==='plasma'?'#e8a4ff':'#ffad67'});burst(x,y,kind==='plasma'?'#dfafff':'#ffc279',25,155);explosionBloom(x,y,kind);shakes=Math.max(shakes,4);playFx('explosion')}else if(kind==='flame'){for(const e of game.enemies){if(!e.dead&&Math.hypot(e.x-x,e.y-y)<49){damage(e,p.damage);e.burn=Math.max(e.burn,1.4)}}burst(x,y,'#ff9d50',7,40);if(Math.random()<.55)playFx('flame')}else{const e=p.target;if(e&&!e.dead&&Math.hypot(e.x-x,e.y-y)<34){damage(e,p.damage,kind==='sniper');if(kind==='ice')e.slow=Math.max(e.slow,2.7+p.level*.2)}burst(x,y,p.color,kind==='sniper'?9:5,35);if(Math.random()<.4)playFx('impact')}}
function update(dt){if(!game||scene!=='play'||paused)return;const g=game;g.elapsed+=dt;for(const f of fireballs)f.age+=dt;for(let i=fireballs.length-1;i>=0;i--)if(fireballs[i].age>=fireballs[i].max)fireballs.splice(i,1);frame++;g.comboTime-=dt;if(g.comboTime<=0)g.combo=0;toastTimer=Math.max(0,toastTimer-dt);if(toastTimer===0)$('toast').classList.remove('visible');shakes=Math.max(0,shakes-dt*42);g.bossCinematic=Math.max(0,(g.bossCinematic||0)-dt);if(g.hp<=6&&!g.lowHpWarned){g.lowHpWarned=true;playFx('alert');voiceLine(chosenHero==='mira'?'Баррикада критически повреждена!':chosenHero==='iris'?'Система сообщает: база на пределе!':'База под угрозой! Всем держать рубеж!');note('🚨 База на грани разрушения! Срочно сдержите зомби.')}for(const s of stains)s.life=Math.max(0,s.life-dt*.018);stains=stains.filter(s=>s.life>0);for(const d of fallen)d.life-=dt;fallen=fallen.filter(d=>d.life>0);for(const f of fx){f.life-=dt;f.x+=f.vx*dt;f.y+=f.vy*dt;f.vx*=.97;f.vy*=.97}fx=fx.filter(f=>f.life>0);for(const f of textFx){f.life-=dt;f.y-=dt*26}textFx=textFx.filter(f=>f.life>0);for(const r of rings){r.life-=dt;r.r+=(r.max-r.r)*Math.min(1,dt*13)}for(let i=rings.length-1;i>=0;i--)if(rings[i].life<=0)rings.splice(i,1);for(const r of rays)r.life-=dt;for(let i=rays.length-1;i>=0;i--)if(rays[i].life<=0)rays.splice(i,1);
if(g.active&&g.queue.length){g.spawnClock-=dt;if(g.spawnClock<=0){addZombie(g.queue.shift());g.spawnClock=Math.max(.24,.82-g.wave*.017)}}
for(const e of [...g.enemies]){if(e.dead)continue;e.flash=Math.max(0,e.flash-dt);e.slow=Math.max(0,e.slow-dt);if(e.burn>0){e.burn=Math.max(0,e.burn-dt);damage(e,11*dt,true)}if(e.dead)continue;if(e.type==='spitter'){e.spitCooldown-=dt;if(e.spitCooldown<=0){e.spitCooldown=4.5;const nearby=g.towers.filter(t=>Math.hypot(e.x-t.x,e.y-t.y)<175);if(nearby.length){const t=nearby[Math.floor(Math.random()*nearby.length)];t.stun=Math.max(t.stun||0,1.9);rays.push({x1:e.x,y1:e.y,x2:t.x,y2:t.y,color:'#c4f16c',life:.4,max:.4,width:5});burst(t.x,t.y,'#c4f16c',14,55);textFx.push({x:t.x,y:t.y-30,text:'☣️ КИСЛОТА',color:'#d5ff8d',life:1})}}}const dest=g.points[e.seg+1];if(!dest){e.dead=true;const loss=e.type==='boss'?5:e.type==='brute'?2:1;g.hp=Math.max(0,g.hp-loss);g.damageTaken+=loss;shakes=7;burst(e.x,e.y,'#ff7d95',12);stains.push({x:e.x,y:e.y+6,r:rand(10,18),life:.6,color:'rgba(255,60,90,.18)'});textFx.push({x:e.x,y:e.y,text:'-'+loss+' ❤️',color:'#ff8594',life:1});playFx('alert');if(g.hp<=0){complete(false);return}continue}const d=Math.hypot(dest.x-e.x,dest.y-e.y),step=e.spd*(e.slow>0?.4:1)*dt;if(d<=step){e.x=dest.x;e.y=dest.y;e.seg++;e.progress=e.seg}else{e.x+=(dest.x-e.x)/d*step;e.y+=(dest.y-e.y)/d*step;e.progress=e.seg+1-d/(TS*5)}if(ENEMIES[e.type].regen)e.hp=Math.min(e.max,e.hp+ENEMIES[e.type].regen*dt);
if(e.type==='boss'&&!e.dead){e.ability-=dt;if(e.ability<=0){e.ability=7.2;const world=e.bossMap;
if(world===0){for(let k=0;k<6;k++)addZombie('runner',{x:e.x+rand(-20,20),y:e.y+rand(-20,20),seg:e.seg,progress:e.progress});textFx.push({x:e.x,y:e.y-54,text:'🩸 ОРДА!',color:'#ff9c76',life:1});}
else if(world===1){for(const z of g.enemies){if(!z.dead&&Math.hypot(z.x-e.x,z.y-e.y)<210)z.hp=Math.min(z.max,z.hp+z.max*.28)}for(const z of g.enemies){if(!z.dead&&Math.hypot(z.x-e.x,z.y-e.y)<165)z.spd*=1.04}rings.push({x:e.x,y:e.y,r:0,max:200,life:.6,color:'#8eff8b'});textFx.push({x:e.x,y:e.y-54,text:'☣️ ЗАРАЖЕНИЕ!',color:'#a6ff8b',life:1});}
else if(world===2){for(const tw of g.towers){if(Math.hypot(tw.x-e.x,tw.y-e.y)<260){tw.stun=Math.max(tw.stun||0,4)}}rings.push({x:e.x,y:e.y,r:0,max:260,life:.6,color:'#92baff'});textFx.push({x:e.x,y:e.y-54,text:'⚡ ЭМИ!',color:'#a6c5ff',life:1});}
else{e.spd=Math.min(e.spd*1.18,105);for(let k=0;k<3;k++)addZombie(k%2?'brute':'runner',{x:e.x+rand(-12,12),y:e.y+rand(-12,12),seg:e.seg,progress:e.progress});for(const tw of g.towers)if(Math.hypot(tw.x-e.x,tw.y-e.y)<170)tw.stun=Math.max(tw.stun||0,1.5);textFx.push({x:e.x,y:e.y-54,text:'🔥 ЯРОСТЬ!',color:'#ff86ab',life:1});}
shakes=6;playFx('alert')}}}g.enemies=g.enemies.filter(e=>!e.dead);
const hero=g.hero;if(hero){hero.cool-=dt;hero.pulseCool=Math.max(0,hero.pulseCool-dt);if(hero.cool<=0){let target=null,score=999999;for(const e of g.enemies){if(e.dead)continue;const dd=Math.hypot(e.x-hero.x,e.y-hero.y);if(dd<225&&dd<score){score=dd;target=e}}if(target){hero.dir=Math.atan2(target.y-hero.y,target.x-hero.x);projectiles.push({x:hero.x+Math.cos(hero.dir)*24,y:hero.y+Math.sin(hero.dir)*24,px:hero.x,py:hero.y,target,tx:target.x,ty:target.y,kind:'sniper',damage:(22+Math.floor(g.wave/3)*4+hero.level*7+hero.weapon*14)*heroData().damage*(1+heroTechLevel('damage',hero.kind)*.12),color:'#83fff5',spd:900,life:1.2,level:1});hero.cool=Math.max(.12,(.31-hero.weapon*.028-hero.level*.004)*heroData().rate/(1+heroTechLevel('rate',hero.kind)*.08));burst(hero.x+Math.cos(hero.dir)*24,hero.y+Math.sin(hero.dir)*24,'#c6faff',3,20,3)}}} 
for(const t of g.towers){t.boost=Math.max(0,(t.boost||0)-dt);if(t.stun>0){t.stun=Math.max(0,t.stun-dt);continue}t.cool-=dt;if(t.cool>0)continue;const targets=g.enemies.filter(e=>!e.dead&&Math.hypot(t.x-e.x,t.y-e.y)<towerRange(t));if(!targets.length)continue;targets.sort((a,b)=>b.progress-a.progress);fireTower(t,targets[0]);t.cool=towerCooldown(t)}
for(const p of projectiles){p.life-=dt;p.px=p.x;p.py=p.y;if(p.target&&!p.target.dead){p.tx=p.target.x;p.ty=p.target.y}const dx=p.tx-p.x,dy=p.ty-p.y,d=Math.hypot(dx,dy),m=p.spd*dt;if(d<=m+8){p.x=p.tx;p.y=p.ty;p.life=0;explode(p,p.x,p.y)}else{p.x+=dx/d*m;p.y+=dy/d*m;if(Math.random()<.35&&fx.length<350)burst(p.x,p.y,p.color,1,7,2)}}projectiles=projectiles.filter(p=>p.life>0);
if(g.active&&!g.queue.length&&!g.enemies.length&&!projectiles.length){g.active=false;const prize=Math.floor(62+Math.min(155,g.wave*10)+Math.max(0,g.wave-15)*2);g.gold+=prize;if(g.hero.kind==='mira')g.hp=Math.min(g.hpMax,g.hp+2);if(g.hero.kind==='iris')g.gold+=55;g.energy=Math.min(100,g.energy+15);if(g.mode==='endless'){saved.endlessBest??={};saved.endlessBest[chosenMap]=Math.max(saved.endlessBest[chosenMap]||0,g.wave)}else saved.best[chosenMap]=Math.max(saved.best[chosenMap]||0,g.wave);persist();checkQuests();checkpoint();note('✅ Волна '+g.wave+' отражена! +'+prize+' монет');audio(780,.18);checkContract();checkAchievements();if(g.mode!=='endless'&&g.wave>=g.maxWaves){complete(true);return}if(g.wave%5===0)bonus();refresh()}}

// Original 2D level artwork. Each themed backdrop is rasterized once and reused.
const backdropCache=[];
function paintBackdrop(n){
 const c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d');
 let seed=9721+n*1234;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
 const col=[['#112c30','#1e3e42','#345f60','#69ffbf'],['#111f2c','#1f333b','#426268','#92f5c2'],['#0c1b35','#122b48','#254f65','#77c9ff'],['#291928','#40263b','#764353','#ff9a76']][n];
 let grad=g.createLinearGradient(0,0,0,H);grad.addColorStop(0,col[0]);grad.addColorStop(.5,col[1]);grad.addColorStop(1,col[0]);g.fillStyle=grad;g.fillRect(0,0,W,H);
 // Far city skyline; cold haze and illuminated window holes.
 g.fillStyle=col[2]+'99';for(let k=0;k<23;k++){
  const x=-15+k*35+rnd()*16,y=55+rnd()*165,height=155+rnd()*180;
  g.fillRect(x,y,24+rnd()*25,height);
  g.fillStyle=col[3]+'25';for(let wx=x+5;wx<x+25;wx+=8)for(let wy=y+10;wy<y+height-10;wy+=17)if(rnd()>.72)g.fillRect(wx,wy,3,5);
  g.fillStyle=col[2]+'99';
 }
 // Geometric urban landmarks, visible at the field edges and top.
 const neon=col[3];
 if(n===0){ // deserted residential streets
  for(const x of [17,575]){g.fillStyle='#213a40';g.fillRect(x,250,128,158);g.fillStyle='#3e5960';g.fillRect(x+11,262,105,8);g.fillStyle='#0d1e29';for(let y=290;y<385;y+=35)for(let xx=x+16;xx<x+115;xx+=32)g.fillRect(xx,y,21,24);g.fillStyle='#ffda8a50';g.fillRect(x+17,291,18,22);}
  g.fillStyle='#24434a';g.fillRect(20,720,140,185);g.fillRect(580,730,125,180);
 }else if(n===1){ // hospital roof and ambulance bay
  for(const x of [5,540]){g.fillStyle='#314e56';g.fillRect(x,205,177,450);g.fillStyle='#0d2530';for(let y=223;y<650;y+=52)for(let xx=x+17;xx<x+168;xx+=44)g.fillRect(xx,y,26,37);g.fillStyle='#69ffc740';g.fillRect(x+17,225,23,33)}
  g.fillStyle='#c9f1d6';g.fillRect(604,148,12,59);g.fillRect(580,172,60,12);
 }else if(n===2){ // underground metro rails and signal cabinets
  g.fillStyle='#233b58';for(let y=150;y<950;y+=145){g.fillRect(0,y,160,26);g.fillRect(564,y,156,26)}
  g.strokeStyle='#6194ba';g.lineWidth=11;for(const x of [35,107,610,687]){g.beginPath();g.moveTo(x,0);g.lineTo(x,1000);g.stroke()}
  g.fillStyle='#9cd5ff';g.fillRect(20,94,127,9);g.fillRect(573,94,127,9);
 }else{ // collapsed bridge, harbor fire and girders
  g.fillStyle='#3d2436';for(const x of [25,570]){g.fillRect(x,100,120,790);g.fillStyle='#bb615049';for(let y=155;y<880;y+=89)g.fillRect(x+11,y,94,15);g.fillStyle='#3d2436'}
  g.strokeStyle='#e47866a0';g.lineWidth=7;for(let i=0;i<8;i++){g.beginPath();g.moveTo(0,i*130);g.lineTo(182,i*130+90);g.moveTo(541,i*130+90);g.lineTo(720,i*130);g.stroke()}
 }
 // Smoke, crack fragments, puddles, grass tufts and warning lights.
 for(let i=0;i<420;i++){let x=rnd()*W,y=85+rnd()*880;
  const k=rnd();g.fillStyle=k>.95?neon+'20':k>.52?'#010b1699':'#84b9ae13';
  g.fillRect(x,y,1+rnd()*15,1+rnd()*9);
 }
 for(let k=0;k<85;k++){let x=rnd()*W,y=120+rnd()*820;g.strokeStyle='#020d17b3';g.lineWidth=1.5;g.beginPath();g.moveTo(x,y);g.lineTo(x+5+rnd()*27,y-3-rnd()*13);g.lineTo(x+17+rnd()*27,y+9);g.stroke()}
 for(let i=0;i<22;i++){let x=rnd()*W,y=110+rnd()*800;let radius=8+rnd()*38;g.fillStyle=col[3]+'0b';g.beginPath();g.arc(x,y,radius,0,PI2);g.fill()}
 const vig=g.createRadialGradient(W/2,H*.5,120,W/2,H*.5,660);vig.addColorStop(0,'#00000000');vig.addColorStop(1,'#030711bd');g.fillStyle=vig;g.fillRect(0,0,W,H);
 return c;
}
function cinematicWeather(time){
 X.save();X.globalCompositeOperation='screen';
 const tint=['#a0e8cd','#b6f9df','#75b8ff','#ffad79'][chosenMap];
 for(let i=0;i<34;i++){
  const y=(i*61+time*(chosenMap===2?115:33)*(i%4+1))%(H+90)-40;
  const x=(i*173+40+Math.sin(i+time*.3)*26)%W;
  X.globalAlpha=.08+(i%5)*.015;X.strokeStyle=tint;X.lineWidth=i%4===0?1.8:1;
  X.beginPath();X.moveTo(x,y);X.lineTo(x-7,y-(chosenMap===2?37:14));X.stroke();
 }
 // soft colored floodlight sweeps across the upper field
 const lightX=W/2+Math.sin(time*.4+chosenMap)*240;
 const grad=X.createRadialGradient(lightX,40,3,lightX,80,410);grad.addColorStop(0,tint+'18');grad.addColorStop(1,tint+'00');X.globalAlpha=1;X.fillStyle=grad;X.fillRect(0,0,W,470);
 X.restore();
}

function circle(x,y,r,color){X.beginPath();X.arc(x,y,r,0,PI2);X.fillStyle=color;X.fill()}
function terrain(){
 const arena=!!(game?.active&&game.wave%5===0),t=game?.elapsed||0, n=chosenMap, pal=[['#152d34','#254542','#0a1a21'],['#16202b','#303f41','#0a131c'],['#101d33','#293952','#0b1124'],['#2c1c29','#463039','#130f1d']][n];
 let sky=X.createLinearGradient(0,0,0,H);sky.addColorStop(0,pal[0]);sky.addColorStop(.62,pal[1]);sky.addColorStop(1,pal[2]);X.fillStyle=sky;X.fillRect(0,0,W,H);if(!backdropCache[n])backdropCache[n]=paintBackdrop(n);X.drawImage(backdropCache[n],0,0);if(arena){const color=CHAPTERS[n].color;X.fillStyle='#07091599';X.fillRect(0,0,W,H);X.strokeStyle=color+'88';X.lineWidth=8;X.strokeRect(14,72,W-28,H-115);X.globalAlpha=.12+.07*Math.sin(t*3);X.fillStyle=color;X.fillRect(0,0,W,H);X.globalAlpha=1;X.font='900 24px system-ui';X.textAlign='center';X.fillStyle=color;X.fillText('☠ БОЕВАЯ АРЕНА: '+CHAPTERS[n].boss.toUpperCase(),W/2,49)}
 // Broken asphalt sections and illuminated pavement tiles
 for(let r=0;r<NR;r++)for(let c=0;c<NC;c++){
  const x=OX+c*TS,y=OY+r*TS,k=(c*89+r*131+n*53)%23,occupied=game?.blocked.has(c+','+r);
  X.fillStyle=k%2?'#ffffff07':'#00000012';X.fillRect(x+1,y+1,TS-2,TS-2);
  if(!occupied){
   if(k%7===0){X.fillStyle='#1c3135';X.fillRect(x+12,y+8,TS-23,TS-16);X.strokeStyle='#54736a66';X.lineWidth=2;X.strokeRect(x+12,y+8,TS-23,TS-16);X.fillStyle='#d5c87529';X.fillRect(x+20,y+15,8,7);X.fillRect(x+41,y+31,7,7)}
   if(k%11===0){X.fillStyle='#273c40';X.beginPath();X.moveTo(x+8,y+18);X.lineTo(x+30,y+8);X.lineTo(x+40,y+39);X.lineTo(x+14,y+48);X.closePath();X.fill();X.fillStyle='#8e8e7975';X.fillRect(x+19,y+22,23,5)}
   if(k%5===0){X.strokeStyle='#75997e88';X.lineWidth=2;X.beginPath();X.moveTo(x+20,y+53);X.lineTo(x+18,y+38);X.moveTo(x+20,y+53);X.lineTo(x+35,y+44);X.stroke()}
   if(k%13===0){X.fillStyle='#ff9f4d24';X.beginPath();X.arc(x+45,y+33,16,0,PI2);X.fill();circle(x+45,y+33,4,'#ffba7390')}
  }
 }
 X.strokeStyle='#b3ffe210';X.lineWidth=1;for(let c=0;c<=NC;c++){X.beginPath();X.moveTo(OX+c*TS,OY);X.lineTo(OX+c*TS,OY+NR*TS);X.stroke()}for(let r=0;r<=NR;r++){X.beginPath();X.moveTo(OX,OY+r*TS);X.lineTo(OX+NC*TS,OY+r*TS);X.stroke()}
 if(!game)return;
 const pts=game.points;X.lineJoin='round';X.lineCap='round';
 for(const [size,col] of [[78,'#0a151b'],[69,'#39474a'],[58,'#515959'],[50,'#384145']]){X.beginPath();pts.forEach((p,i)=>i?X.lineTo(p.x,p.y):X.moveTo(p.x,p.y));X.lineWidth=size;X.strokeStyle=col;X.stroke()}
 X.strokeStyle='#99aba45e';X.lineWidth=2;X.beginPath();pts.forEach((p,i)=>i?X.lineTo(p.x,p.y):X.moveTo(p.x,p.y));X.setLineDash([12,22]);X.stroke();X.setLineDash([]);
 // Animated contamination fog and isolated road fragments
 for(let i=0;i<14;i++){let x=(i*191+n*71)%W,y=(i*311+n*31+t*(i%2?.7:-.5)+1000)%H;X.fillStyle=i%3?'#a7ffb30a':'#e5b9ff0a';X.beginPath();X.ellipse(x,y,38+(i%4)*14,14+(i%3)*7,0,0,PI2);X.fill()}
 for(let i=0;i<30;i++){const x=(i*127+83)%W,y=(i*307+41)%H;X.fillStyle=i%4?'#f8dda621':'#ff6f7330';X.fillRect(x,y,2+i%3,2+i%4)}
 const a=pts[0],b=pts.at(-1);X.shadowColor='#3ff9b7';X.shadowBlur=19;circle(a.x,a.y,28,'#1f6e57');X.shadowBlur=0;circle(a.x,a.y,21,'#123e35');X.fillStyle='#baffdc';X.font='bold 28px system-ui';X.textAlign='center';X.textBaseline='middle';X.fillText('☣',a.x,a.y);X.shadowColor='#ff627c';X.shadowBlur=25;circle(b.x,b.y,32,'#813c52');X.shadowBlur=0;circle(b.x,b.y,23,'#2e1b2c');X.fillText('🛡',b.x,b.y)
}
function towerArt(t){
 const d=TOWERS[t.type];X.save();X.translate(t.x,t.y);
 X.fillStyle='#07131ca9';X.beginPath();X.ellipse(0,11,33,19,0,0,PI2);X.fill();
 // riveted hexagonal foundation
 X.beginPath();for(let i=0;i<6;i++){let a=i*PI2/6+Math.PI/6;let x=Math.cos(a)*31,y=Math.sin(a)*31;i?X.lineTo(x,y):X.moveTo(x,y)}X.closePath();X.fillStyle=selectedTower===t?'#73ffe0':'#607d8c';X.fill();X.strokeStyle='#b9dcd7a0';X.lineWidth=2;X.stroke();circle(0,0,26,'#182e3b');
 for(let i=0;i<6;i++){const a=i*PI2/6;circle(Math.cos(a)*22,Math.sin(a)*22,2.4,'#d0ede0')}
 X.save();X.rotate(t.angle);
 X.fillStyle='#0a131d';X.fillRect(-11,-11,47,22);X.fillStyle='#344a56';X.fillRect(-8,-8,41,16);X.fillStyle=d.color;X.fillRect(9,-5,27,10);X.fillStyle='#c9e9de';X.fillRect(31,-6,5,12);
 if(t.type===0){X.fillStyle='#9df9d1';X.fillRect(15,-10,19,4);X.fillRect(15,6,19,4)}
 if(t.type===1){X.fillStyle='#5e6b73';X.fillRect(15,-12,24,24);X.fillStyle='#ffcb80';X.fillRect(33,-8,6,16)}
 if(t.type===2){X.fillStyle='#a1edff';X.fillRect(18,-12,12,24);circle(10,0,10,'#6fb8cf')}
 if(t.type===3){X.fillStyle='#ff6f98';X.fillRect(16,-2,24,4);circle(40,0,5,'#ffb8cb')}
 if(t.type===4){X.strokeStyle='#c8b2ff';X.lineWidth=3;X.beginPath();X.moveTo(-4,-19);X.lineTo(1,-29);X.moveTo(6,-19);X.lineTo(10,-27);X.stroke()}
 if(t.type===5){X.fillStyle='#ff934e';X.fillRect(5,-13,24,26);circle(27,0,9,'#ffbd77')}
 if(t.type===6){X.fillStyle='#ffe6a2';X.fillRect(12,-3,44,6);X.fillRect(50,-9,7,18)}if(t.type===7){X.fillStyle='#80fbff';X.fillRect(12,-4,48,8);X.fillRect(50,-12,8,24)}if(t.type===8){X.fillStyle='#df9aff';circle(24,0,15,'#ba70ff');circle(24,0,7,'#ffebff')}
 circle(0,0,15,'#30485a');circle(0,0,10,d.color);circle(-3,-4,4,'#e6fff9b7');X.restore();
 X.strokeStyle=d.color;X.lineWidth=4;X.beginPath();X.arc(0,0,28,-Math.PI/2,-Math.PI/2+PI2*t.level/6);X.stroke();X.fillStyle='#eafff7';X.font='900 12px system-ui';X.textAlign='center';X.fillText(''+t.level,22,25);X.restore()
}
function zombieArt(e){
 const z=ENEMIES[e.type],s=z.size,phase=game.elapsed*(e.type==='runner'?16:8)+e.phase,walking=Math.sin(phase),headColor=e.flash?'#fff':z.skin;
 X.save();X.translate(e.x,e.y);X.rotate(Math.sin(phase*.5)*.07);
 X.fillStyle='#020b10a0';X.beginPath();X.ellipse(0,s*.93,s*1.05,s*.43,0,0,PI2);X.fill();
 // Independent articulated feet and moving arms
 X.strokeStyle='#15292d';X.lineWidth=Math.max(4,s*.27);X.lineCap='round';
 X.beginPath();X.moveTo(-s*.28,s*.35);X.lineTo(-s*.35+walking*s*.34,s*.94);X.moveTo(s*.28,s*.35);X.lineTo(s*.35-walking*s*.34,s*.94);X.stroke();
 X.strokeStyle=headColor;X.lineWidth=Math.max(3,s*.22);X.beginPath();X.moveTo(-s*.58,-s*.18);X.lineTo(-s*.92,s*.18+walking*s*.14);X.lineTo(-s*1.05,s*.30);X.moveTo(s*.58,-s*.18);X.lineTo(s*.92,s*.18-walking*s*.14);X.lineTo(s*1.05,s*.30);X.stroke();
 const coat=e.type==='runner'?'#b68639':e.type==='brute'?'#3d4d57':e.type==='split'?'#783d83':e.type==='boss'?'#6e2737':e.type==='toxic'?'#1c685b':'#4a5152';
 X.fillStyle=coat;X.beginPath();X.moveTo(-s*.58,-s*.33);X.lineTo(s*.58,-s*.33);X.lineTo(s*.66,s*.44);X.lineTo(-s*.57,s*.43);X.closePath();X.fill();
 X.fillStyle=headColor;X.beginPath();X.ellipse(0,-s*.79,s*.56,s*.57,.05,0,PI2);X.fill();
 X.fillStyle='#1c2730';X.beginPath();X.arc(-s*.22,-s*.83,Math.max(1.7,s*.14),0,PI2);X.arc(s*.22,-s*.83,Math.max(1.7,s*.14),0,PI2);X.fill();
 X.shadowColor=e.type==='boss'?'#ff4b6c':'#d9ff73';X.shadowBlur=z.boss?14:7;X.fillStyle=e.type==='boss'?'#ff576e':'#ebff8a';circle(-s*.22,-s*.83,Math.max(1,s*.072),X.fillStyle);circle(s*.22,-s*.83,Math.max(1,s*.072),X.fillStyle);X.shadowBlur=0;
 X.fillStyle='#243036';X.fillRect(-s*.21,-s*.48,s*.43,Math.max(2,s*.12));X.fillStyle='#e7dba7';for(let k=0;k<3;k++)X.fillRect(-s*.15+k*s*.13,-s*.47,Math.max(1,s*.06),Math.max(1,s*.085));
 // Character-specific silhouettes
 if(e.type==='runner'){X.fillStyle='#ffcd5e';X.fillRect(-s*.55,-s*.3,s*1.1,s*.22);X.strokeStyle='#f6e6a6';X.lineWidth=2;X.beginPath();X.moveTo(-s*1.2,s*.4);X.lineTo(-s*1.6,s*.4);X.stroke()}
 if(e.type==='brute'){X.fillStyle='#8e9ea3';X.fillRect(-s*.79,-s*.20,s*1.58,s*.4);X.fillStyle='#a5b3b1';X.fillRect(-s*.8,-s*.2,s*.22,s*.3);X.fillRect(s*.55,-s*.2,s*.22,s*.3)}
 if(e.type==='toxic'){X.shadowColor='#44ffb2';X.shadowBlur=12;X.strokeStyle='#42ffc6';X.lineWidth=3;X.beginPath();X.arc(0,-s*.1,s*1.04,0,PI2);X.stroke();X.shadowBlur=0;circle(s*.35,s*.15,s*.19,'#83ffc8')}
 if(e.type==='split'){circle(-s*.65,-s*.67,s*.21,'#edb9ff');circle(s*.7,-s*.32,s*.26,'#e69df4');circle(0,s*.42,s*.20,'#ad6ac0')}
 if(e.type==='crawler'){X.scale(1.25,.72);X.fillStyle='#d2b1cd';X.beginPath();X.ellipse(0,s*.33,s*.6,s*.29,0,0,PI2);X.fill()}
 if(e.type==='boss'){X.shadowColor=CHAPTERS[e.bossMap??chosenMap].color;X.shadowBlur=21;X.strokeStyle=CHAPTERS[e.bossMap??chosenMap].color;X.lineWidth=5;X.beginPath();X.arc(0,-s*.15,s*1.1,0,PI2);X.stroke();X.shadowBlur=0;X.fillStyle=['#b95d48','#6fce68','#697bc5','#c83468'][e.bossMap??chosenMap];X.beginPath();X.moveTo(-s*.55,-s*1.08);X.lineTo(-s*.95,-s*1.65);X.lineTo(-s*.17,-s*1.35);X.lineTo(s*.5,-s*1.78);X.lineTo(s*.82,-s*.99);X.closePath();X.fill();X.strokeStyle='#ff9b96';X.lineWidth=3;X.beginPath();X.moveTo(-s*.87,-s*.15);X.lineTo(-s*1.24,-s*.58);X.moveTo(s*.82,-s*.15);X.lineTo(s*1.24,-s*.58);X.stroke()}
 if(e.slow>0){X.shadowColor='#6bbcff';X.shadowBlur=14;X.strokeStyle='#a5e6ff';X.lineWidth=3;X.beginPath();X.arc(0,0,s*1.18,0,PI2);X.stroke();X.shadowBlur=0}
 if(e.burn>0){X.fillStyle='#ff953b';for(let i=0;i<3;i++){const f=Math.sin(phase+i)*5;X.beginPath();X.moveTo(i*s*.42-s*.4,s*.3);X.quadraticCurveTo(i*s*.4-s*.6+f,-s*.8,i*s*.4-s*.48,-s*1.35);X.quadraticCurveTo(i*s*.42-s*.15,-s*.5,i*s*.4-s*.4,s*.3);X.fill()}}
 X.restore();
 spriteDraw('zombie:'+e.type,e.x,e.y,z.size*1.55,game.elapsed*(e.type==='runner'?13:7)+e.phase,e.flash>0?.67:.94);
 if(z.boss){X.font='900 15px system-ui';X.textAlign='center';X.fillStyle=CHAPTERS[e.bossMap??chosenMap].color;X.fillText(CHAPTERS[e.bossMap??chosenMap].boss.toUpperCase(),e.x,e.y-s*1.95-23)}const width=z.boss?100:Math.max(33,s*2.2),x=e.x-width/2,y=e.y-s*1.72-14;X.fillStyle='#07121c';X.fillRect(x-2,y-2,width+4,9);X.fillStyle=e.hp/e.max<.32?'#ff6c7f':'#75efb5';X.fillRect(x,y,width*clamp(e.hp/e.max,0,1),5)
}
function effects(){
 for(const p of projectiles){X.save();const ang=Math.atan2(p.y-p.py,p.x-p.px),l=p.kind==='sniper'?45:19;X.globalCompositeOperation='lighter';X.strokeStyle=p.color;X.shadowColor=p.color;X.shadowBlur=p.kind==='cannon'?24:16;X.lineCap='round';X.lineWidth=p.kind==='sniper'?5:p.kind==='cannon'?7:3;X.beginPath();X.moveTo(p.x-Math.cos(ang)*l,p.y-Math.sin(ang)*l);X.lineTo(p.x,p.y);X.stroke();circle(p.x,p.y,p.kind==='cannon'?10:4,'#fff5d9');X.restore()}
 for(const r of rays){X.save();X.globalAlpha=clamp(r.life/r.max,0,1);X.globalCompositeOperation='lighter';X.shadowColor=r.color;X.shadowBlur=21;X.lineCap='round';X.strokeStyle=r.color;X.lineWidth=r.width+5;X.beginPath();X.moveTo(r.x1,r.y1);if(r.zig){const a=(Math.sin((game?.elapsed||0)*90)*17);X.lineTo((r.x1+r.x2)*.5+a,(r.y1+r.y2)*.5-a)}X.lineTo(r.x2,r.y2);X.stroke();X.strokeStyle='#ffffffb9';X.lineWidth=Math.max(1,r.width*.35);X.stroke();X.restore()}
 for(const r of rings){X.save();X.globalAlpha=clamp(r.life/.55,0,1);X.shadowColor=r.color;X.shadowBlur=18;X.strokeStyle=r.color;X.lineWidth=6*r.life/.55;X.beginPath();X.arc(r.x,r.y,r.r,0,PI2);X.stroke();X.restore()}
 for(const f of fx){X.save();X.globalAlpha=clamp(f.life/f.max,0,1);X.shadowColor=f.color;X.shadowBlur=f.size>3?8:0;circle(f.x,f.y,f.size,f.color);X.restore()}
 for(const f of textFx){X.save();X.globalAlpha=clamp(f.life,0,1);X.font='900 19px system-ui';X.textAlign='center';X.shadowColor='#06111c';X.shadowBlur=5;X.fillStyle=f.color;X.fillText(f.text,f.x,f.y);X.restore()}
}
function drawHero(){if(!game||!game.hero)return;const h=game.hero,hd=heroData(),walk=Math.sin(game.elapsed*5);X.save();X.translate(h.x,h.y);X.shadowColor=hd.color;X.shadowBlur=18;circle(0,7,29,'#0b2634');X.shadowBlur=0;X.strokeStyle=hd.color;X.lineWidth=3;X.beginPath();X.arc(0,2,26,0,PI2);X.stroke();X.strokeStyle='#101e2e';X.lineWidth=9;X.lineCap='round';X.beginPath();X.moveTo(-9,14);X.lineTo(-11+walk*2,27);X.moveTo(9,14);X.lineTo(11-walk*2,27);X.stroke();X.fillStyle=hd.id==='ray'?'#275e73':hd.id==='iris'?'#765832':'#326a51';X.beginPath();X.roundRect(-16,-11,32,33,8);X.fill();X.fillStyle=hd.color;X.fillRect(-15,-1,30,4);X.fillStyle='#f2cda6';circle(0,-17,11,'#f2cda6');X.fillStyle=hd.id==='mira'?'#ffffff':hd.id==='iris'?'#e8a950':'#1b364d';X.beginPath();X.roundRect(-12,-29,24,11,4);X.fill();if(hd.id==='mira'){X.fillStyle='#41dba7';X.fillRect(-2,-27,4,9);X.fillRect(-5,-24,10,3)}else if(hd.id==='iris'){X.fillStyle='#243b4a';X.fillRect(-11,-21,22,5)}X.fillStyle='#172536';X.fillRect(-7,-19,5,3);X.fillRect(4,-19,5,3);X.save();X.rotate(h.dir);X.fillStyle='#d5eaf4';X.fillRect(7,-5,32,10);X.fillStyle=hd.color;X.fillRect(23,-3,15,6);X.restore();spriteDraw('hero:'+hd.id,0,0,31,game.elapsed*7,.92);X.font='bold 12px system-ui';X.textAlign='center';X.fillStyle='#ffffff';X.fillText(hd.name,0,-43);X.restore()}
function draw(){X.save();if(shakes>0)X.translate(rand(-shakes,shakes),rand(-shakes,shakes));terrain();cinematicWeather(game?.elapsed||performance.now()/1000);if(game){if(game.eliteWave&&game.active){X.textAlign='right';X.fillStyle='#ffe9a0';X.font='bold 19px system-ui';X.fillText('🛡️ ЭЛИТНАЯ ВОЛНА',W-20,85)}if(game.bloodMoon&&game.active){X.fillStyle='rgba(150,12,44,.10)';X.fillRect(0,0,W,H);X.textAlign='right';X.fillStyle='#ff9ea7';X.font='bold 18px system-ui';X.fillText('🌕 КРОВАВАЯ ЛУНА',W-24,85)}if(game.bossCinematic>0){const a=Math.min(1,game.bossCinematic/.35);X.save();X.globalAlpha=Math.min(.95,a);X.fillStyle='rgba(0,0,0,.62)';X.fillRect(0,0,W,135);X.fillRect(0,H-135,W,135);X.textAlign='center';X.font='900 24px system-ui';X.fillStyle='#fff';X.fillText('⚠️ БОСС ВЫШЕЛ НА ПОЛЕ',W/2,58);X.font='900 42px system-ui';X.fillStyle=CHAPTERS[chosenMap].color;X.shadowColor=CHAPTERS[chosenMap].color;X.shadowBlur=20;X.fillText(CHAPTERS[chosenMap].boss.toUpperCase(),W/2,H/2-12);X.shadowBlur=0;X.font='bold 18px system-ui';X.fillStyle='#dbe9ef';X.fillText(CHAPTERS[chosenMap].ability,W/2,H/2+26);X.restore()}if(heroMoveMode&&hover){const h=cell(hover.c,hover.r);X.fillStyle='#63ffe633';X.strokeStyle='#8fffe6';X.lineWidth=3;X.beginPath();X.arc(h.x,h.y,27,0,PI2);X.fill();X.stroke()}if(selectedType!==null&&hover){const {c,r}=hover,p=cell(c,r),ok=canBuild(c,r);X.fillStyle=ok?'#7effbf44':'#ff758877';X.fillRect(OX+c*TS+2,OY+r*TS+2,TS-4,TS-4);X.strokeStyle=ok?'#a2ffdf':'#ff8e9b';X.lineWidth=3;X.strokeRect(OX+c*TS+3,OY+r*TS+3,TS-6,TS-6);X.fillStyle='#7bffdd10';X.beginPath();X.arc(p.x,p.y,TOWERS[selectedType].range,0,PI2);X.fill()}if(selectedTower){X.fillStyle='#6dffcd14';X.strokeStyle='#8affd490';X.lineWidth=2;X.beginPath();X.arc(selectedTower.x,selectedTower.y,towerRange(selectedTower),0,PI2);X.fill();X.stroke()}if(power&&hover){const p=cell(hover.c,hover.r),r=power==='strike'?146:185;X.fillStyle=power==='strike'?'#ffad6840':'#95efff30';X.strokeStyle=power==='strike'?'#ffaf72':'#95efff';X.beginPath();X.arc(p.x,p.y,r,0,PI2);X.fill();X.stroke()}for(const s of stains){X.save();X.globalAlpha=clamp(s.life,0,1);X.fillStyle=s.color;X.beginPath();X.ellipse(s.x,s.y,s.r*1.25,s.r*.72,Math.sin(s.x*.12+s.y*.03),0,PI2);X.fill();X.restore()}for(const d of fallen){X.save();X.globalAlpha=Math.max(0,d.life/d.max)*.8;X.translate(d.x,d.y);X.rotate(d.tilt*(1-d.life/d.max));X.scale(1,.55+.45*d.life/d.max);spriteDraw('zombie:'+d.kind,0,0,d.size*1.55,4,1);X.restore()}
 for(const t of game.towers){towerArt(t);if(t.stun>0){X.save();X.strokeStyle='#ff789f';X.lineWidth=3;X.shadowColor='#ff4d8c';X.shadowBlur=12;X.beginPath();X.arc(t.x,t.y,31+Math.sin(game.elapsed*9)*2,0,PI2);X.stroke();X.font='bold 24px system-ui';X.textAlign='center';X.fillText('⚠️',t.x,t.y-26);X.restore()}}drawHero();for(const e of game.enemies){zombieArt(e);if(e.shield>0){X.save();X.strokeStyle='#a1f1ff';X.lineWidth=4;X.globalAlpha=.55+.2*Math.sin(game.elapsed*5);X.beginPath();X.arc(e.x,e.y,ENEMIES[e.type].size+11,0,PI2);X.stroke();X.restore()}if(e.type==='spitter'){X.save();X.fillStyle='#c3ff69';X.shadowColor='#a8ff55';X.shadowBlur=15;X.beginPath();X.arc(e.x,e.y-13,4,0,PI2);X.fill();X.restore()}}effects();renderFireballs();}X.restore()}
function refresh(){if(game){$('contractText').textContent=game.contractDone?'✅ Выполнен':game.contract.title+' · 💎'+game.contract.bonus;$('contractProgress').textContent=Math.min(game.contract.target,contractValue())+'/'+game.contract.target}else{$('contractText').textContent='Выберите главу';$('contractProgress').textContent='—'}renderQuests();const boss=game?.enemies?.find(e=>e.type==='boss'&&!e.dead);$('bossHud').classList.toggle('visible',!!boss);$('bossWarning').style.display=game?.active&&game.wave%5===0&&!boss?'block':'none';if(boss){$('bossTitle').textContent='☠️ '+CHAPTERS[chosenMap].boss.toUpperCase();$('bossHp').textContent=Math.max(0,Math.ceil(boss.hp/boss.max*100))+'%';$('bossMeter').style.width=clamp(boss.hp/boss.max*100,0,100)+'%'}if(game){$('heroMove').classList.toggle('active',heroMoveMode);$('heroPulse').classList.toggle('ready',game.hero.pulseCool<=0);$('heroPulse').disabled=scene!=='play'||game.hero.pulseCool>0;$('heroMove').disabled=scene!=='play';$('heroStatus').textContent=heroData().name+' · Ур. '+game.hero.level+' · '+(game.hero.pulseCool>0?heroData().skill+' '+Math.ceil(game.hero.pulseCool)+' сек':heroData().skill+' готов');$('heroLevelText').textContent='⭐ Ур. '+game.hero.level+' · '+game.hero.xp+'/'+heroXpNeed(game.hero.level)+' XP';$('heroXpBar').style.width=Math.min(100,game.hero.xp/heroXpNeed(game.hero.level)*100)+'%';$('heroUpgrade').disabled=scene!=='play'||game.hero.weapon>=5||game.gold<heroWeaponCost();$('heroUpgrade').textContent=game.hero.weapon>=5?'⭐ Оружие улучшено до максимума':'🔧 Оружие '+(game.hero.weapon+1)+' → '+(game.hero.weapon+2)+' · '+heroWeaponCost()+' 🪙';$('hp').textContent=game.hp;$('gold').textContent=Math.floor(game.gold);$('wave').textContent=game.mode==='endless'?game.wave+' / ∞':game.wave+'/15';$('energyBar').style.width=game.energy+'%';$('energyText').textContent='Энергия '+Math.floor(game.energy)+'/100';$('waveBtn').disabled=game.active||scene!=='play'||game.awaitReward;$('waveBtn').textContent=game.active?'⚔️ ЗОМБИ ИДУТ':'▶ НАЧАТЬ ВОЛНУ';$('strike').disabled=game.energy<70||scene!=='play';$('freeze').disabled=game.energy<50||scene!=='play';}else{$('hp').textContent='—';$('gold').textContent='—';$('wave').textContent='0/15';$('waveBtn').disabled=true}$('gems').textContent=saved.gems;$('sound').textContent=saved.sound?'🔊':'🔇';const shopScroll=$('shop').scrollLeft;$('shop').innerHTML=TOWERS.map((t,i)=>`<button class="unit ${selectedType===i?'active':''} ${game&&game.gold<t.cost?'locked':''}" data-type="${i}" ${!game||scene!=='play'?'disabled':''}><span class="uicon">${t.icon}</span><span class="price">${t.cost}🪙</span><b>${t.name}</b><small>${t.desc}</small></button>`).join('');$('shop').scrollLeft=shopScroll;$('shop').querySelectorAll('[data-type]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.type);selectedType=selectedType===i?null:i;selectedTower=null;power=null;heroMoveMode=false;note(selectedType===null?'Режим строительства выключен':'🔫 '+TOWERS[selectedType].name+': коснитесь свободной клетки');refresh()});const t=selectedTower;if(t){const base=TOWERS[t.type],price=towerCost(t);$('towerName').textContent=base.name+' · ур. '+t.level;$('detail').innerHTML=`<strong>${base.name}</strong> · уровень ${t.level}/6<br>Урон: ${Math.round(towerDamage(t))} · Дальность: ${Math.round(towerRange(t))}<br>Следующее улучшение: ${t.level>=6?'МАКСИМУМ':price+' 🪙'}`;$('upgrade').disabled=scene!=='play'||t.level>=6||game.gold<price;$('sell').disabled=scene!=='play';$('quickbar').classList.toggle('visible',scene==='play');$('quickUpgrade').disabled=t.level>=6||game.gold<price;$('quickUpgrade').textContent=t.level>=6?'⭐ МАКСИМУМ':'⬆ УРОВЕНЬ '+t.level+' → '+(t.level+1)+' · '+price+'🪙';$('quickSell').textContent='🪙 +'+Math.floor(t.spent*.72);$('upgrade').textContent=t.level>=6?'⭐ МАКСИМУМ':'⬆ '+price+' 🪙';$('sell').textContent='🪙 +'+Math.floor(t.spent*.72)}else{$('quickbar').classList.remove('visible');$('towerName').textContent='нет';$('detail').textContent='Коснитесь установленной башни. Улучшения стали дороже — следите за бюджетом.';$('upgrade').disabled=true;$('sell').disabled=true;$('upgrade').textContent='⬆ УЛУЧШИТЬ';$('sell').textContent='🪙 ПРОДАТЬ'}$('tech').innerHTML=TECH.map(([id,name,desc,max])=>{const level=saved.tech[id]||0,cost=9+level*9;return `<button data-tech="${id}" ${level>=max||saved.gems<cost?'disabled':''}><b>${name} · ${level}/${max}</b><small>${desc}</small><small style="color:#e8bdff">${level>=max?'МАКСИМУМ':'💎 '+cost}</small></button>`}).join('');$('tech').querySelectorAll('[data-tech]').forEach(b=>b.onclick=()=>{const id=b.dataset.tech,level=saved.tech[id]||0,cost=9+level*9,config=TECH.find(x=>x[0]===id);if(level>=config[3]||saved.gems<cost)return;saved.gems-=cost;saved.tech[id]++;persist();audio(800,.15);note('🧬 Исследование приобретено!');refresh()})}
function pointer(e){const b=C.getBoundingClientRect();return{x:(e.clientX-b.left)*W/b.width,y:(e.clientY-b.top)*H/b.height}}function locationOf(p){return{c:Math.floor((p.x-OX)/TS),r:Math.floor((p.y-OY)/TS)}}
C.addEventListener('pointermove',e=>{const o=locationOf(pointer(e));hover=o.c>=0&&o.c<NC&&o.r>=0&&o.r<NR?o:null});C.addEventListener('pointerleave',()=>{hover=null});C.addEventListener('pointerdown',e=>{touchStart=pointer(e);C.setPointerCapture?.(e.pointerId)});C.addEventListener('pointerup',e=>{if(!game||scene!=='play'||!touchStart)return;const p=pointer(e);if(Math.hypot(p.x-touchStart.x,p.y-touchStart.y)>24){touchStart=null;return}touchStart=null;const o=locationOf(p);if(heroMoveMode){const c=locationOf(p);if(c.c>=0&&c.c<NC&&c.r>=0&&c.r<NR&&!game.blocked.has(c.c+','+c.r)){const place=cell(c.c,c.r);game.hero.x=place.x;game.hero.y=place.y;burst(place.x,place.y,'#7cfcec',15);note('🦸 Командир перемещён')}else note('📍 Выберите свободную клетку вне дороги');heroMoveMode=false;refresh();return}if(power){hitPower(p);return}if(o.c<0||o.c>=NC||o.r<0||o.r>=NR)return;const existing=game.towers.find(t=>t.c===o.c&&t.r===o.r);if(existing){selectedTower=existing;selectedType=null;audio(550,.05);refresh();return}if(selectedType!==null){build(o.c,o.r);return}selectedTower=null;refresh()});C.addEventListener('pointercancel',()=>{touchStart=null});
$('saveGame').onclick=()=>{if(coop.role==='guest'||coop.role==='host'&&coop.peer){note('💾 В сетевом бою сохранение ведёт сервер комнаты — локальная запись недоступна');return}if(checkpoint()){note('💾 Бой сохранён! Продолжить можно из главного меню.')}else{note('⚠️ Не удалось сохранить бой. Проверьте доступное место и настройки браузера.')}};$('heroUpgrade').onclick=heroUpgrade;$('heroMove').onclick=()=>{if(scene!=='play')return;heroMoveMode=!heroMoveMode;selectedType=null;selectedTower=null;power=null;note(heroMoveMode?'📍 Коснитесь свободной клетки для командира':'Перемещение отменено');refresh()};$('heroPulse').onclick=()=>{if(scene!=='play'||!game||game.hero.pulseCool>0)return;const h=game.hero,hd=heroData();let hits=0;
if(h.kind==='iris'){for(const t of game.towers){if(Math.hypot(t.x-h.x,t.y-h.y)<245){t.stun=0;t.cool=Math.min(t.cool,0);t.boost=7+heroTechLevel('power',h.kind)*1.5;hits++}}rings.push({x:h.x,y:h.y,r:0,max:245,life:.55,color:hd.color});note('⚡ Перегрузка: '+hits+' турелей усилено на 7 секунд');}
else if(h.kind==='mira'){game.hp=Math.min(game.hpMax,game.hp+5+h.level+heroTechLevel('power',h.kind)*2);for(const e of game.enemies)if(!e.dead&&Math.hypot(e.x-h.x,e.y-h.y)<180){damage(e,75+h.level*12,true);e.slow=Math.max(e.slow,2);hits++}rings.push({x:h.x,y:h.y,r:0,max:180,life:.55,color:hd.color});note('💚 Баррикада восстановлена! Поражено зомби: '+hits);}
else{for(const e of game.enemies)if(!e.dead&&Math.hypot(e.x-h.x,e.y-h.y)<220){damage(e,(155+game.wave*14+h.level*20+h.weapon*24)*(1+heroTechLevel('power',h.kind)*.18),true);e.slow=Math.max(e.slow,2);hits++}rings.push({x:h.x,y:h.y,r:0,max:220,life:.55,color:hd.color});note('💥 Импульс Рея поразил '+hits+' зомби');}
burst(h.x,h.y,hd.color,32,200);shakes=6;h.pulseCool=Math.max(10,19-heroTechLevel('power',h.kind)*1.4);game.abilities=(game.abilities||0)+1;checkQuests();voiceLine(h.kind==='ray'?'Импульс!':h.kind==='iris'?'Ускоряем турели!':'Восстанавливаю оборону!');playFx('hero-skill');refresh()};$('waveBtn').onclick=beginWave;$('upgrade').onclick=improve;$('sell').onclick=sell;$('quickUpgrade').onclick=improve;$('quickSell').onclick=sell;$('strike').onclick=()=>choosePower('strike');$('freeze').onclick=()=>choosePower('freeze');$('sound').onclick=()=>{saved.sound=!saved.sound;persist();refresh();if(saved.sound)audio(590,.1);updateAudioButtons()};$('music').onclick=()=>{saved.music=!saved.music;persist();if(saved.music){audio(560,.08);musicChapter=-1}else musicNext=0;updateAudioButtons()};updateAudioButtons();$('voice').onclick=()=>{saved.voice=!saved.voice;persist();$('voice').textContent=saved.voice?'🗣️':'🔕';if(saved.voice)voiceLine('Голосовые команды включены')};$('voice').textContent=saved.voice?'🗣️':'🔕';$('speed').onclick=()=>{speed=speed===1?2:speed===2?3:1;$('speed').textContent='⏩ ×'+speed};$('pause').onclick=()=>{if(!game||scene!=='play')return;paused=!paused;$('pause').textContent=paused?'▶ Дальше':'⏸ Пауза';note(paused?'⏸ Игра приостановлена':'▶ Игра продолжается')};$('menu').onclick=()=>{if(game&&scene==='play'){paused=true;overlay(`<div class="crest">⏸</div><h1>ПАУЗА</h1><p>Ваши исследования сохраняются. Одиночный бой сохраняется при выходе в меню. В сетевом бою локальное сохранение недоступно.</p><button class="go" id="resume">▶ ПРОДОЛЖИТЬ</button><button class="alt" id="exit">🗺️ В МЕНЮ</button>`);$('resume').onclick=()=>{paused=false;hideOverlay()};$('exit').onclick=menu}else menu()};$('showTech').onclick=()=>{$('techPanel').classList.toggle('open')};window.addEventListener('keydown',e=>{if(e.key==='Escape'){heroMoveMode=false;selectedType=null;power=null;selectedTower=null;refresh()}if(e.key===' '){e.preventDefault();if(game&&scene==='play'){if(!game.active)beginWave();else $('pause').click()}}if(e.key>='1'&&e.key<='7'&&game&&scene==='play'){selectedType=Number(e.key)-1;selectedTower=null;power=null;refresh()}});document.addEventListener('visibilitychange',()=>{if(document.hidden&&game&&scene==='play'&&!paused){paused=true;$('pause').textContent='▶ Дальше'}});

// ━━━━━━━━━━━━━━━━━━━━━ NETWORK CO-OP ━━━━━━━━━━━━━━━━━━━━━
// The host is authoritative: it alone advances simulation and handles money,
// damage, wave progression, and purchases. Guest sends validated requests.
const coop={role:null,code:null,ws:null,peer:false,connected:false,lastFrame:0,lastSeen:0,hostURL:null};
function coopInfo(s){const el=document.getElementById('coopIndicator');if(el){el.textContent=s;el.style.display=s?'block':'none'}}
function coopSend(obj){if(coop.ws?.readyState===1)try{coop.ws.send(JSON.stringify(obj))}catch(e){coopInfo('Сеть: ошибка передачи')}}
function coopLeave(){const ws=coop.ws;if(ws&&ws.readyState===1)try{ws.send(JSON.stringify({type:'leave'}));ws.close()}catch(e){}coop.role=null;coop.code=null;coop.ws=null;coop.peer=false;coop.connected=false;coopInfo('')}
function coopLobby(){
 paused=true;
 const defaultAddress=(()=>{let v='';try{v=localStorage.getItem('zombie_coop_server')||''}catch(e){}return v||((location.protocol==='http:'||location.protocol==='https:')&&!['localhost','127.0.0.1'].includes(location.hostname)?location.host:'');})();
 overlay(`<div class="crest">👥</div><h1>ZOMBIE <em>TOGETHER</em></h1>
 <p>Два игрока на одной карте: общий бюджет, совместные башни и специальные способности. Для связи нужно запустить входящий в архив сервер.</p>
 <div class="coop-box"><label>Адрес игрового сервера</label><input id="coopServer" type="text" spellcheck="false" placeholder="192.168.1.10:8080" value="${defaultAddress}"><small>Укажите адрес сервера (например, 192.168.1.10:8080). На телефоне localhost не подходит. Для игры через интернет нужен защищённый сервер wss://.</small></div>
 <button class="go" id="coopCreate">🎮 СОЗДАТЬ КОМНАТУ</button>
 <div class="coop-box"><label>Код комнаты напарника</label><input id="coopCode" type="text" maxlength="6" placeholder="Например, 8AB23C" autocapitalize="characters"></div>
 <button class="coop-button" id="coopJoin">🔗 ПРИСОЕДИНИТЬСЯ</button>
 <p id="coopMsg">Сначала запустите сервер, затем создайте комнату или введите код.</p>
 <button class="alt" id="coopBack">← В МЕНЮ</button>`);
 $('coopBack').onclick=menu;
 $('coopCreate').onclick=()=>coopConnect('host');
 $('coopJoin').onclick=()=>coopConnect('guest',$('coopCode').value);
}
function coopConnect(role,code=''){
 if(coop.ws)coopLeave();
 const inputAddress=$('coopServer').value.trim();let raw=inputAddress.replace(/^https?:\/\//,'').replace(/^wss?:\/\//,'').replace(/\/$/,'');
 if(!/^[\w.\-\[\]:]+(?::\d+)?$/.test(raw)){ $('coopMsg').textContent='Введите действительный адрес сервера';return}
 const protocol=/^(wss:|https:)/i.test(inputAddress)||(location.protocol==='https:'&&!(window.Capacitor&&window.Capacitor.isNativePlatform?.()))?'wss':'ws';
 const url=protocol+'://'+raw+'/ws';try{localStorage.setItem('zombie_coop_server',raw)}catch(e){}
 const codeText=String(code).trim().toUpperCase();
 if(role==='guest'&&!/^[A-Z0-9]{6}$/.test(codeText)){$('coopMsg').textContent='Укажите шестизначный код комнаты';return}
 $('coopMsg').textContent='Подключение к '+raw+'…';
 try{
  const ws=new WebSocket(url);
  coop.ws=ws;coop.hostURL=raw;
  ws.onopen=()=>{coop.connected=true;coopSend(role==='host'?{type:'create'}:{type:'join',code:codeText})};
  ws.onmessage=e=>{let msg;try{msg=JSON.parse(e.data)}catch(_){return}coopMessage(msg)};
  ws.onerror=()=>{if($('coopMsg'))$('coopMsg').textContent='Сервер недоступен. Проверьте адрес и запуск сервера.';coopInfo('⚠️ Нет связи')};
  ws.onclose=()=>{if(coop.ws!==ws)return;coop.connected=false;coop.peer=false;coopInfo('⚠️ Связь потеряна');if(coop.role==='guest'&&scene==='play'){paused=true;note('Напарник отключился. Вернитесь в главное меню.')}};
 }catch(e){$('coopMsg').textContent='Невозможно подключиться: '+e.message}
}
function coopMessage(msg){
 if(msg.type==='created'){coop.role='host';coop.code=msg.code;coop.peer=false;coopInfo('👑 Код '+msg.code+' · ожидаем игрока');
  overlay(`<div class="crest">🎮</div><h1>КОМНАТА <em>${msg.code}</em></h1><p>Передайте этот код второму игроку. Оба устройства должны открывать страницу на одном сервере.</p><button class="go" id="coopPlay">▶ ВЫБРАТЬ ГЛАВУ И ИГРАТЬ</button><button class="alt" id="coopCancel">✕ Закрыть комнату</button>`);
  $('coopPlay').onclick=menu;$('coopCancel').onclick=()=>{coopLeave();menu()};return}
 if(msg.type==='joined'){coop.role='guest';coop.code=msg.code;coopInfo('🤝 Комната '+msg.code+' · ожидание ведущего');
  overlay(`<div class="crest">🤝</div><h1>ВЫ <em>ПОДКЛЮЧИЛИСЬ</em></h1><p>Комната ${msg.code}. Когда ведущий начнёт главу, поле автоматически появится здесь. Вы сможете строить и улучшать башни из общего бюджета.</p><button class="alt" id="coopLeaveBtn">✕ Выйти</button>`);
  $('coopLeaveBtn').onclick=()=>{coopLeave();menu()};return}
 if(msg.type==='peer_joined'){coop.peer=true;coopInfo('🟢 Напарник в комнате '+coop.code);note('🤝 Напарник подключился. Обороняйте город вместе!');return}
 if(msg.type==='peer_left'){coop.peer=false;coopInfo('👑 Комната '+coop.code+' · напарник вышел');note('Напарник отключился. Вы можете играть дальше.');return}
 if(msg.type==='ended'){coop.role=null;coop.code=null;coopInfo('⚠️ Ведущий отключился');paused=true;overlay(`<div class="crest">📡</div><h1>СЕАНС ЗАВЕРШЁН</h1><p>Ведущий закрыл комнату.</p><button class="go" id="coopExit">В МЕНЮ</button>`);$('coopExit').onclick=()=>{coopLeave();menu()};return}
 if(msg.type==='error'){if($('coopMsg'))$('coopMsg').textContent=msg.message;else note(msg.message);return}
 if(msg.type==='notice'){note(msg.message);return}
 if(msg.type==='snapshot'&&coop.role==='guest')coopSnapshot(msg.state);
 if(msg.type==='action'&&coop.role==='host')coopAction(msg.action);
}
function coopSnapshot(data){
 if(!data||!data.state||!Number.isInteger(data.map)||data.map<0||data.map>=MAPS.length)return;
 const s=data.state;coop.lastSeen=Date.now();
 if(!game||game.world!==data.map||scene!=='play'){
  chosenMap=data.map;chosenHero=s.hero?.kind||'ray';scene='play';selectedType=0;selectedTower=null;power=null;paused=false;hideOverlay();musicChapter=-1;
 }
 const rd=routeData(MAPS[data.map]);
 const oldSelected=selectedTower?.id;
 game={...s,points:rd.points,blocked:rd.blocked,towers:Array.isArray(s.towers)?s.towers:[],enemies:Array.isArray(s.enemies)?s.enemies:[],queue:Array.isArray(s.queue)?s.queue:[],contract:s.contract||CONTRACT_POOL[0]};
 chosenHero=game.hero?.kind||'ray';
 chosenDifficulty=game.difficulty??1;
 selectedTower=game.towers.find(t=>t.id===oldSelected)||null;
 projectiles=data.projectiles||[];rays.length=0;rays.push(...(data.rays||[]));rings.length=0;rings.push(...(data.rings||[]));
 fx=data.fx||[];fallen=data.fallen||[];stains=data.stains||[];
 paused=!!data.paused;
 if(data.scene==='over'||game.done){scene='over';paused=true;note('🏆 Глава завершена. Ведущий выбирает следующую миссию.');}
 refresh();coopInfo('🟢 Напарник · '+coop.code+' · волна '+game.wave);
}
function coopAction(a){if(!a||!game||scene!=='play'||coop.role!=='host')return;
 const kind=a.kind;
 const cellOK=Number.isInteger(a.c)&&Number.isInteger(a.r)&&a.c>=0&&a.c<NC&&a.r>=0&&a.r<NR;
 if(kind==='build'&&cellOK&&Number.isInteger(a.type)&&a.type>=0&&a.type<TOWERS.length){
  const old=selectedType;selectedType=a.type;build(a.c,a.r);selectedType=old;
 }else if((kind==='upgrade'||kind==='sell')&&Number.isInteger(a.id)){
  const t=game.towers.find(t=>t.id===a.id);if(t){const old=selectedTower;selectedTower=t;if(kind==='upgrade')improve();else sell();selectedTower=old&&game.towers.includes(old)?old:null}
 }else if(kind==='wave')beginWave();
 else if(kind==='heroUpgrade')heroUpgrade();
 else if(kind==='heroPulse'){$('heroPulse').click()}
 else if(kind==='power'&&Number.isFinite(a.x)&&Number.isFinite(a.y)&&a.x>=0&&a.x<=W&&a.y>=0&&a.y<=H&&['strike','freeze'].includes(a.name)){
  if(game.energy>=(a.name==='strike'?70:50)){power=a.name;hitPower({x:a.x,y:a.y})}
 }else if(kind==='move'&&cellOK&&!game.blocked.has(a.c+','+a.r)){
  const p=cell(a.c,a.r);game.hero.x=p.x;game.hero.y=p.y;burst(p.x,p.y,'#6efed5',12)
 }
}
function coopTick(t){if(coop.role!=='host'||!coop.peer||coop.ws?.readyState!==1||t-coop.lastFrame<125||!game)return;coop.lastFrame=t;
 const s={...game,points:undefined,blocked:undefined};
 coopSend({type:'snapshot',state:{map:chosenMap,scene,paused,state:s,projectiles,rays, rings,fx:fx.slice(0,65),fallen:fallen.slice(-25),stains:stains.slice(-45)}})
}
// Intercept guest controls in capture phase: all economic operations happen on host.
C.addEventListener('pointerup',e=>{
 if(coop.role!=='guest'||scene!=='play')return;
 e.stopImmediatePropagation();
 const p=pointer(e),o=locationOf(p);
 if(heroMoveMode){if(o.c>=0&&o.r>=0&&o.c<NC&&o.r<NR)coopSend({type:'action',action:{kind:'move',c:o.c,r:o.r}});heroMoveMode=false;refresh();return}
 if(power){coopSend({type:'action',action:{kind:'power',name:power,x:p.x,y:p.y}});power=null;refresh();return}
 if(o.c<0||o.r<0||o.c>=NC||o.r>=NR)return;
 const found=game.towers.find(t=>t.c===o.c&&t.r===o.r);
 if(found){selectedTower=found;selectedType=null;refresh()}
 else if(selectedType!==null)coopSend({type:'action',action:{kind:'build',c:o.c,r:o.r,type:selectedType}});
 else{selectedTower=null;refresh()}
},true);
document.addEventListener('click',e=>{
 if(coop.role!=='guest'||scene!=='play')return;
 const btn=e.target.closest('button');if(!btn)return;
 const id=btn.id;
 const blocked={waveBtn:'wave',upgrade:'upgrade',quickUpgrade:'upgrade',sell:'sell',quickSell:'sell',heroUpgrade:'heroUpgrade',heroPulse:'heroPulse'};
 if(blocked[id]){
  e.preventDefault();e.stopImmediatePropagation();
  const kind=blocked[id];coopSend({type:'action',action:{kind,id:selectedTower?.id}});
 }
},true);

let uiClock=0;function tick(t){const dt=last?Math.min(.04,(t-last)/1000):0;last=t;try{if(!paused&&scene==='play'&&game){if(coop.role!=='guest')for(let i=0;i<speed;i++)update(dt);uiClock+=dt;if(uiClock>.32){uiClock=0;refresh()}if(coop.role!=='guest'){checkpointTimer+=dt;if(checkpointTimer>6){checkpointTimer=0;checkpoint()}}}coopTick(t);musicTick();draw()}catch(e){console.error('Game frame error',e)}requestAnimationFrame(tick)}menu();requestAnimationFrame(tick);
})();