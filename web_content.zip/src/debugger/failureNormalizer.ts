/**
 * GODEX Phase 5 - Failure Normalizer
 * Ingests multi-tool compilation, testing, bundling, and runtime diagnostic output
 * and normalizes them into structured, evidence-preserving FailureEvents.
 */

import { FailureEvent, FailureType, FailureLocation } from './debuggerTypes';
import { ExecutionResult } from '../execution/executionTypes';

export class FailureNormalizer {
  /**
   * Normalizes an ExecutionResult into a structured FailureEvent (or multiple if batching)
   */
  public static normalize(result: ExecutionResult): FailureEvent {
    const rawStdout = result.stdout || '';
    const rawStderr = result.stderr || '';
    const combinedOutput = `${rawStdout}\n${rawStderr}`.trim();
    const command = result.command || '';
    const exitCode = result.exitCode;

    // 1. Check for TypeScript compilation errors
    const tsMatch = this.parseTypeScriptError(combinedOutput);
    if (tsMatch) {
      return this.buildEvent(
        result.id,
        'TYPE_ERROR',
        command,
        exitCode,
        tsMatch.location,
        tsMatch.message,
        combinedOutput,
        rawStdout,
        rawStderr,
        0.95,
        [
          `TypeScript compiler diagnostic on line ${tsMatch.location.line}`,
          tsMatch.message,
          tsMatch.location.surroundingContext || ''
        ].filter(Boolean)
      );
    }

    // 2. Check for Network / External dependencies
    const externalMatch = this.parseExternalFailure(combinedOutput);
    if (externalMatch) {
      return this.buildEvent(
        result.id,
        'EXTERNAL_DEPENDENCY_FAILURE',
        command,
        exitCode,
        { file: 'external', isExact: false },
        externalMatch.message,
        combinedOutput,
        rawStdout,
        rawStderr,
        0.85,
        [externalMatch.message, 'Failure originates from external network or remote service unreachable']
      );
    }

    // 3. Check for Test Runner failures (Vitest / Jest)
    const testMatch = this.parseTestFailure(combinedOutput);
    if (testMatch) {
      return this.buildEvent(
        result.id,
        'TEST_FAILURE',
        command,
        exitCode,
        testMatch.location,
        testMatch.message,
        combinedOutput,
        rawStdout,
        rawStderr,
        0.92,
        [
          `Test suite assertion failure in ${testMatch.location.file}`,
          testMatch.message,
          testMatch.expectationSummary || ''
        ].filter(Boolean)
      );
    }

    // 3. Check for Bundler / Module resolution errors (Vite, Rollup, Webpack)
    const moduleMatch = this.parseModuleOrImportError(combinedOutput);
    if (moduleMatch) {
      return this.buildEvent(
        result.id,
        moduleMatch.type,
        command,
        exitCode,
        moduleMatch.location,
        moduleMatch.message,
        combinedOutput,
        rawStdout,
        rawStderr,
        0.94,
        [
          `Module / import resolution failed: ${moduleMatch.message}`,
          `Target path: ${moduleMatch.location.file}`
        ]
      );
    }

    // 4. Check for Runtime exceptions / Stack traces (Node.js ReferenceError, TypeError)
    const runtimeMatch = this.parseRuntimeStackTrace(combinedOutput);
    if (runtimeMatch) {
      return this.buildEvent(
        result.id,
        'RUNTIME_ERROR',
        command,
        exitCode,
        runtimeMatch.location,
        runtimeMatch.message,
        combinedOutput,
        rawStdout,
        rawStderr,
        0.88,
        [
          `Runtime exception thrown: ${runtimeMatch.message}`,
          `Stack pointer at ${runtimeMatch.location.file}:${runtimeMatch.location.line}`
        ],
        runtimeMatch.stackTrace
      );
    }

    // 5. Check for Lint failures (ESLint)
    const lintMatch = this.parseLintError(combinedOutput);
    if (lintMatch) {
      return this.buildEvent(
        result.id,
        'LINT_FAILURE',
        command,
        exitCode,
        lintMatch.location,
        lintMatch.message,
        combinedOutput,
        rawStdout,
        rawStderr,
        0.9,
        [`Static linter diagnostic in ${lintMatch.location.file}: ${lintMatch.message}`]
      );
    }

    // 6. Check for Timeout or Process Crash
    if (exitCode === 124 || combinedOutput.includes('timed out') || combinedOutput.includes('SIGTERM')) {
      return this.buildEvent(
        result.id,
        'TIMEOUT',
        command,
        exitCode,
        { file: 'system', isExact: false },
        'Command execution exceeded maximum allowed time limit and was terminated.',
        combinedOutput,
        rawStdout,
        rawStderr,
        0.98,
        [`Process timed out (exit code ${exitCode})`]
      );
    }

    // 8. Fallback / Unknown failure
    const firstLine = combinedOutput.split('\n').find(l => l.trim().length > 0) || 'Command failed with non-zero exit code';
    return this.buildEvent(
      result.id,
      exitCode !== 0 ? 'BUILD_ERROR' : 'UNKNOWN_FAILURE',
      command,
      exitCode,
      { file: 'unknown', isExact: false },
      firstLine.slice(0, 200),
      combinedOutput,
      rawStdout,
      rawStderr,
      0.5,
      [`Non-zero exit code: ${exitCode}`, firstLine]
    );
  }

  // --- Parser Subroutines ---

  private static parseTypeScriptError(output: string): { location: FailureLocation; message: string } | null {
    // Example: src/math.ts:14:25 - error TS2304: Cannot find name 'missingValue'.
    // Or: src/math.ts(14,25): error TS2304: Cannot find name 'missingValue'.
    const tsRegex = /(?:([a-zA-Z0-9_\-\.\/]+)(?::|\()(\d+)(?::|,)(\d+)\)?:?\s*(?:-\s*error\s*TS\d+:\s*)?(.*))/;
    const match = output.match(tsRegex);
    if (match) {
      const file = match[1].trim();
      const line = parseInt(match[2], 10);
      const column = parseInt(match[3], 10);
      const message = match[4].trim();

      // Extract symbol name if possible
      const symbolMatch = message.match(/'([^']+)'/);
      const symbol = symbolMatch ? symbolMatch[1] : undefined;

      return {
        location: {
          file,
          line: isNaN(line) ? undefined : line,
          column: isNaN(column) ? undefined : column,
          symbol,
          isExact: !isNaN(line)
        },
        message
      };
    }
    return null;
  }

  private static parseTestFailure(output: string): { location: FailureLocation; message: string; expectationSummary?: string } | null {
    // Example: FAIL src/auth.test.ts > suite > test name
    // Expected: 200, Received: 401
    const failRegex = /(?:FAIL|FAILED)\s+([a-zA-Z0-9_\-\.\/]+)(?:[\s\S]*?(?:Expected:?\s*(.*?)\s+Received:?\s*(.*?)|Error:\s*(.*)|AssertionError:\s*(.*)))?/i;
    const match = output.match(failRegex);
    if (match) {
      const file = match[1].trim();
      const expected = match[2]?.trim();
      const received = match[3]?.trim();
      const errorMsg = match[4]?.trim() || match[5]?.trim() || 'Assertion test failed';

      // Look for line in stack trace within test file
      const lineRegex = new RegExp(`${file.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')}:(\\d+):(\\d+)`);
      const lineMatch = output.match(lineRegex);
      const line = lineMatch ? parseInt(lineMatch[1], 10) : undefined;
      const column = lineMatch ? parseInt(lineMatch[2], 10) : undefined;

      const expectationSummary = expected && received ? `Expected: "${expected}", but Received: "${received}"` : undefined;

      return {
        location: {
          file,
          line,
          column,
          isExact: line !== undefined
        },
        message: expectationSummary || errorMsg,
        expectationSummary
      };
    }
    return null;
  }

  private static parseModuleOrImportError(output: string): { type: FailureType; location: FailureLocation; message: string } | null {
    // Example: Failed to resolve import "./utils" from "src/main.ts". Does the file exist?
    // Or: Cannot find module './missing' or its corresponding type declarations.
    const viteImportRegex = /Failed to resolve import ["']([^"']+)["'] from ["']([^"']+)["']/i;
    const viteMatch = output.match(viteImportRegex);
    if (viteMatch) {
      return {
        type: 'MODULE_NOT_FOUND',
        location: {
          file: viteMatch[2].trim(),
          symbol: viteMatch[1].trim(),
          isExact: true
        },
        message: `Failed to resolve import "${viteMatch[1]}" from file "${viteMatch[2]}"`
      };
    }

    const nodeModuleRegex = /Cannot find module ["']([^"']+)["']/i;
    const nodeMatch = output.match(nodeModuleRegex);
    if (nodeMatch) {
      return {
        type: 'MODULE_NOT_FOUND',
        location: {
          file: 'package.json',
          symbol: nodeMatch[1].trim(),
          isExact: false
        },
        message: `Cannot find module "${nodeMatch[1]}"`
      };
    }

    return null;
  }

  private static parseRuntimeStackTrace(output: string): { location: FailureLocation; message: string; stackTrace: string } | null {
    // Example: ReferenceError: missingVar is not defined\n    at Object.<anonymous> (src/index.ts:15:3)
    const errorRegex = /([A-Za-z]+Error):\s*(.*?)\n([\s\S]*?)(?:\n\s*at\s+.*)/;
    const match = output.match(errorRegex);
    if (match) {
      const errType = match[1];
      const errDetail = match[2];
      const fullStack = match[0];

      // Extract first application file from stack
      const stackFrameRegex = /\bat\s+(?:.*?\s+\()?([a-zA-Z0-9_\-\.\/]+):(\d+):(\d+)\)?/;
      const frameMatch = output.match(stackFrameRegex);

      const file = frameMatch ? frameMatch[1].trim() : 'runtime';
      const line = frameMatch ? parseInt(frameMatch[2], 10) : undefined;
      const column = frameMatch ? parseInt(frameMatch[3], 10) : undefined;

      const symbolMatch = errDetail.match(/'([^']+)'|([a-zA-Z0-9_$]+)\s+is not/);
      const symbol = symbolMatch ? (symbolMatch[1] || symbolMatch[2]) : undefined;

      return {
        location: {
          file,
          line,
          column,
          symbol,
          isExact: line !== undefined
        },
        message: `${errType}: ${errDetail}`,
        stackTrace: fullStack
      };
    }
    return null;
  }

  private static parseLintError(output: string): { location: FailureLocation; message: string } | null {
    // Example: src/App.tsx:42:10: 'foo' is defined but never used [@typescript-eslint/no-unused-vars]
    const lintRegex = /([a-zA-Z0-9_\-\.\/]+):(\d+):(\d+):\s*(.*)/;
    const match = output.match(lintRegex);
    if (match && (output.includes('eslint') || output.includes('warning') || output.includes('error'))) {
      return {
        location: {
          file: match[1].trim(),
          line: parseInt(match[2], 10),
          column: parseInt(match[3], 10),
          isExact: true
        },
        message: match[4].trim()
      };
    }
    return null;
  }

  private static parseExternalFailure(output: string): { message: string } | null {
    const netErrors = [
      'ENOTFOUND',
      'ECONNREFUSED',
      'ETIMEDOUT',
      'fetch failed',
      'getaddrinfo',
      '401 Unauthorized',
      '403 Forbidden',
      '429 Too Many Requests',
      '502 Bad Gateway',
      '503 Service Unavailable'
    ];

    for (const err of netErrors) {
      if (output.includes(err)) {
        return { message: `External network dependency failed: ${err}` };
      }
    }
    return null;
  }

  private static buildEvent(
    executionId: string,
    type: FailureType,
    command: string,
    exitCode: number,
    location: FailureLocation,
    message: string,
    originalOutput: string,
    stdout: string,
    stderr: string,
    confidence: number,
    evidence: string[],
    stackTrace?: string
  ): FailureEvent {
    return {
      id: 'fail-' + Math.random().toString(36).slice(2, 9),
      executionId,
      type,
      status: 'ACTIVE',
      command,
      exitCode,
      location,
      file: location.file !== 'unknown' && location.file !== 'system' ? location.file : undefined,
      line: location.line,
      column: location.column,
      symbol: location.symbol,
      message,
      stackTrace,
      stdout,
      stderr,
      timestamp: Date.now(),
      confidence,
      evidence,
      originalOutput
    };
  }
}
