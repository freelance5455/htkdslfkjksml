/**
 * GODEX Phase 5 - Root Cause Analyzer
 * Synthesizes FailureEvent, FailureContext, and recent execution evidence into a structured
 * multi-hypothesis RootCauseAnalysis model with epistemic categorization (KNOWN, LIKELY, UNKNOWN).
 */

import { 
  FailureEvent, 
  FailureContext, 
  RootCauseAnalysis, 
  FailureHypothesis 
} from './debuggerTypes';

export class RootCauseAnalyzer {
  /**
   * Performs evidence-driven root cause diagnosis across multi-layer hypotheses
   */
  public static analyze(
    failure: FailureEvent,
    context: FailureContext
  ): RootCauseAnalysis {
    const targetFile = context.affectedFiles[0]?.path || failure.file || 'unknown';
    const msg = failure.message.toLowerCase();
    const isSecuritySensitive = this.checkSecuritySensitivity(targetFile, msg);
    const isDependencyRelated = failure.type === 'DEPENDENCY_ERROR' || failure.type === 'MODULE_NOT_FOUND' || msg.includes('cannot find module') || msg.includes('not installed');
    const isExternalFailure = failure.type === 'EXTERNAL_DEPENDENCY_FAILURE' || msg.includes('enotfound') || msg.includes('econnrefused') || msg.includes('fetch failed');
    const isFlakyCandidate = failure.type === 'TEST_FAILURE' && (msg.includes('timeout') || msg.includes('intermittent'));

    const knownFacts: string[] = [];
    const likelyInferences: string[] = [];
    const unknownFactors: string[] = [];

    // Formulate Primary and Alternative Hypotheses based on failure type and evidence
    let primary: FailureHypothesis;
    const alternatives: FailureHypothesis[] = [];

    switch (failure.type) {
      case 'TYPE_ERROR': {
        knownFacts.push(`TypeScript diagnostic failed in "${targetFile}" at line ${failure.line ?? 'unknown'}.`);
        knownFacts.push(`Diagnostic: "${failure.message}".`);

        if (context.recentChanges.includes(targetFile)) {
          likelyInferences.push(`Recent edits to "${targetFile}" introduced a type signature mismatch or missing reference.`);
        } else {
          likelyInferences.push(`The type declaration in "${targetFile}" does not conform to caller or imported interface.`);
        }

        unknownFactors.push('Whether other runtime call sites exist that rely on the previous shape.');

        const symbol = failure.symbol || 'referenced identifier';
        primary = {
          cause: `Type error involving '${symbol}': ${failure.message}`,
          confidence: 0.92,
          evidence: [
            `Line ${failure.line}: ${failure.message}`,
            `File: ${targetFile}`
          ],
          suggestedFiles: [targetFile],
          suggestedSymbols: failure.symbol ? [failure.symbol] : []
        };

        alternatives.push({
          cause: `Imported module or interface in "${targetFile}" was updated without updating local usages`,
          confidence: 0.65,
          evidence: context.relatedFiles.length > 0 ? [`Related imports: ${context.relatedFiles.join(', ')}`] : []
        });
        break;
      }

      case 'TEST_FAILURE': {
        knownFacts.push(`Test assertion failed in test suite "${targetFile}".`);
        knownFacts.push(`Assertion output: "${failure.message}".`);

        likelyInferences.push(`Implementation logic in tested unit diverged from expected assertion value.`);
        unknownFactors.push('Whether the test specification is outdated or the implementation code has a regression.');

        primary = {
          cause: `Assertion failure in test: ${failure.message}`,
          confidence: 0.88,
          evidence: failure.evidence,
          suggestedFiles: [targetFile, ...context.relatedFiles],
          suggestedSymbols: failure.symbol ? [failure.symbol] : []
        };

        alternatives.push({
          cause: `Test expectation is outdated following intentional functional refactoring`,
          confidence: 0.55,
          evidence: ['Requires explicit review before proposing test modifications.']
        });
        break;
      }

      case 'MODULE_NOT_FOUND':
      case 'IMPORT_ERROR': {
        knownFacts.push(`Bundler or runtime failed to resolve import target "${failure.symbol || 'module'}".`);
        likelyInferences.push(`File path typo in relative import statement or package not added to dependencies.`);
        unknownFactors.push('Whether module was deleted, renamed, or never created.');

        primary = {
          cause: `Unresolved import or module: "${failure.symbol || failure.message}"`,
          confidence: 0.94,
          evidence: failure.evidence,
          suggestedFiles: [targetFile],
          suggestedSymbols: failure.symbol ? [failure.symbol] : []
        };

        alternatives.push({
          cause: `Missing package declaration in package.json`,
          confidence: 0.70,
          evidence: ['Module may need to be installed in workspace.']
        });
        break;
      }

      case 'RUNTIME_ERROR': {
        knownFacts.push(`Runtime exception thrown: "${failure.message}".`);
        likelyInferences.push(`Unchecked undefined property access or uninitialized variable at runtime.`);
        unknownFactors.push('Dynamic state values that triggered this execution path.');

        if (msg.includes('usereducedmotion is not a function') || msg.includes('reducedmotion') || msg.includes('invalid hook call')) {
          primary = {
            cause: `Unsafe animation hook invocation or missing export: "${failure.message}". Requires replacement with safe hook 'useSafeReducedMotion()'.`,
            confidence: 0.98,
            evidence: failure.evidence,
            suggestedFiles: [targetFile],
            suggestedSymbols: ['useSafeReducedMotion']
          };
          alternatives.push({
            cause: `Import from motion/react or framer-motion does not export useReducedMotion in current environment`,
            confidence: 0.85,
            evidence: ['Safe hook fallback needed to prevent blank screen crashes.']
          });
        } else {
          primary = {
            cause: `Runtime exception: ${failure.message}`,
            confidence: 0.85,
            evidence: failure.evidence,
            suggestedFiles: [targetFile],
            suggestedSymbols: failure.symbol ? [failure.symbol] : []
          };
        }
        break;
      }

      case 'EXTERNAL_DEPENDENCY_FAILURE': {
        knownFacts.push(`External remote service or network connection failed: "${failure.message}".`);
        likelyInferences.push(`Network endpoint is offline, rate-limited, or host environment lacks internet connectivity.`);
        unknownFactors.push('Remote API health status and availability.');

        primary = {
          cause: `External dependency or remote network failure: ${failure.message}`,
          confidence: 0.89,
          evidence: failure.evidence,
          suggestedFiles: []
        };
        break;
      }

      default: {
        knownFacts.push(`Process exited with code ${failure.exitCode}.`);
        knownFacts.push(`Diagnostic: ${failure.message}`);
        likelyInferences.push(`Execution failed during build or command step.`);
        unknownFactors.push('Full environmental factors.');

        primary = {
          cause: failure.message,
          confidence: 0.6,
          evidence: failure.evidence,
          suggestedFiles: [targetFile]
        };
      }
    }

    return {
      failureId: failure.id,
      primaryHypothesis: primary,
      alternativeHypotheses: alternatives,
      epistemic: {
        known: knownFacts,
        likely: likelyInferences,
        unknown: unknownFactors
      },
      isSecuritySensitive,
      isDependencyRelated,
      isExternalFailure,
      isFlakyCandidate,
      analyzedAt: Date.now()
    };
  }

  private static checkSecuritySensitivity(filePath: string, message: string): boolean {
    const sensitiveTerms = [
      'auth',
      'password',
      'secret',
      'token',
      'jwt',
      'encryption',
      'permission',
      'credential',
      'oauth',
      'security',
      'privilege'
    ];

    const lowerPath = filePath.toLowerCase();
    const lowerMsg = message.toLowerCase();

    return sensitiveTerms.some(term => lowerPath.includes(term) || lowerMsg.includes(term));
  }
}
