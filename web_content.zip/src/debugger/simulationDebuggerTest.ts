/**
 * GODEX Phase 5 - Self-Healing Debugger Quality Gate & Simulation Test Suite
 * Fully automated 12-point deterministic test suite verifying the complete
 * ERROR -> DIAGNOSE -> PLAN -> PATCH -> RUN -> COMPARE -> VERIFY cycle.
 */

import { FailureNormalizer } from './failureNormalizer';
import { FailureLocalizer } from './failureLocalizer';
import { FailureContextBuilder } from './failureContextBuilder';
import { RootCauseAnalyzer } from './rootCauseAnalyzer';
import { RepairPlanner } from './repairPlanner';
import { RegressionDetector } from './regressionDetector';
import { SelfHealingEngine } from './selfHealingEngine';
import { ExecutionResult } from '../execution/executionTypes';

export interface DebuggerTestCaseResult {
  name: string;
  passed: boolean;
  details: string;
}

export interface DebuggerTestSuiteResult {
  passed: boolean;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  durationMs: number;
  cases: DebuggerTestCaseResult[];
}

function createMockResult(partial: {
  id: string;
  command: string;
  exitCode: number;
  stdout?: string;
  stderr?: string;
  durationMs?: number;
  outputSummary?: string;
}): ExecutionResult {
  const now = Date.now();
  const dur = partial.durationMs || 50;
  return {
    id: partial.id,
    command: partial.command,
    status: partial.exitCode === 0 ? 'COMPLETED' : 'FAILED',
    exitCode: partial.exitCode,
    stdout: partial.stdout || '',
    stderr: partial.stderr || '',
    durationMs: dur,
    chunks: [],
    policy: {
      allowed: true,
      classification: 'SAFE',
      reasons: [],
      requiresApproval: false,
      normalizedWorkingDirectory: '.',
      sanitizedCommand: partial.command,
      matchedRules: []
    },
    evidence: {
      executionId: partial.id,
      command: partial.command,
      status: partial.exitCode === 0 ? 'COMPLETED' : 'FAILED',
      exitCode: partial.exitCode,
      startedAt: now - dur,
      finishedAt: now,
      durationMs: dur,
      requestedBy: 'SYSTEM_VALIDATION',
      workingDirectory: '.',
      outputSummary: partial.outputSummary || (partial.stderr || partial.stdout || '').slice(0, 100),
      totalStdoutLines: (partial.stdout || '').split('\n').filter(Boolean).length,
      totalStderrLines: (partial.stderr || '').split('\n').filter(Boolean).length,
      epistemic: { known: [], likely: [], unknown: [] },
      source: 'actual_process_output'
    }
  };
}

export class SimulationDebuggerTestSuite {
  public static async runSuite(): Promise<DebuggerTestSuiteResult> {
    const startTime = Date.now();
    const cases: DebuggerTestCaseResult[] = [];

    // --- TEST 1: Failure Normalization (TypeScript, Test, Bundler, StackTrace) ---
    try {
      const mockTsResult = createMockResult({
        id: 'exec-ts-1',
        command: 'npm run lint',
        exitCode: 2,
        stderr: `src/math.ts:14:25 - error TS2304: Cannot find name 'missingValue'.`,
        durationMs: 120,
        outputSummary: 'TS2304: Cannot find name missingValue'
      });

      const event = FailureNormalizer.normalize(mockTsResult);
      const passed = event.type === 'TYPE_ERROR' && 
                     event.location.file === 'src/math.ts' && 
                     event.location.line === 14 && 
                     event.symbol === 'missingValue';

      cases.push({
        name: 'Failure Normalization (TypeScript Error)',
        passed,
        details: passed 
          ? `Normalized TS2304 error to TYPE_ERROR at ${event.location.file}:${event.location.line} for symbol '${event.symbol}'`
          : `Normalization failed: ${JSON.stringify(event.location)}`
      });
    } catch (err: any) {
      cases.push({ name: 'Failure Normalization', passed: false, details: err.message });
    }

    // --- TEST 2: Failure Localization & AST Scope Resolution ---
    try {
      const mockFiles: Record<string, string> = {
        'src/math.ts': `export function calculateTotal(a: number, b: number): number {\n  const factor = 2;\n  return (a + b) * factor + missingValue;\n}`
      };

      const localized = FailureLocalizer.localize(
        { file: 'src/math.ts', line: 3, column: 29, isExact: true },
        mockFiles
      );

      const passed = localized.isExact && localized.file === 'src/math.ts' && localized.surroundingSnippet !== undefined;
      cases.push({
        name: 'Failure Localization & Snippet Extraction',
        passed,
        details: passed 
          ? `Extracted snippet with exact line pointer at line ${localized.line}`
          : 'Localization snippet extraction failed.'
      });
    } catch (err: any) {
      cases.push({ name: 'Failure Localization', passed: false, details: err.message });
    }

    // --- TEST 3: Failure Context Builder Integration ---
    try {
      const mockFiles: Record<string, string> = {
        'src/auth.ts': `export class AuthService { login() {} }`,
        'src/auth.test.ts': `import { AuthService } from './auth'; test('login', () => {});`
      };

      const mockEvent = FailureNormalizer.normalize(createMockResult({
        id: 'exec-ctx-1',
        command: 'npm test',
        exitCode: 1,
        stdout: 'FAIL src/auth.test.ts\nExpected: 200, Received: 401',
        durationMs: 90,
        outputSummary: 'Test failed'
      }));

      const localized = FailureLocalizer.localize(mockEvent.location, mockFiles);
      const context = FailureContextBuilder.build(mockEvent, localized, mockFiles);

      const passed = context.failure.type === 'TEST_FAILURE' && context.affectedFiles.length > 0;
      cases.push({
        name: 'Failure Context Builder (Phase 1 & Phase 2 Linkage)',
        passed,
        details: passed 
          ? `Built context with ${context.affectedFiles.length} affected files and summary.`
          : 'FailureContext construction incomplete.'
      });
    } catch (err: any) {
      cases.push({ name: 'Failure Context Builder', passed: false, details: err.message });
    }

    // --- TEST 4: Root Cause Epistemic Categorization (KNOWN/LIKELY/UNKNOWN) ---
    try {
      const mockFiles: Record<string, string> = {
        'src/user.ts': `export interface User { id: string; name: string; }`
      };

      const mockEvent = FailureNormalizer.normalize(createMockResult({
        id: 'exec-rca-1',
        command: 'npm run lint',
        exitCode: 2,
        stderr: `src/user.ts:1:10 - error TS2304: Cannot find name 'Role'.`,
        durationMs: 80,
        outputSummary: 'TS2304'
      }));

      const localized = FailureLocalizer.localize(mockEvent.location, mockFiles);
      const context = FailureContextBuilder.build(mockEvent, localized, mockFiles);
      const rca = RootCauseAnalyzer.analyze(mockEvent, context);

      const passed = rca.epistemic.known.length > 0 && 
                     rca.epistemic.likely.length > 0 && 
                     rca.epistemic.unknown.length > 0 && 
                     rca.primaryHypothesis.confidence > 0.8;

      cases.push({
        name: 'Root Cause Multi-Hypothesis & Epistemic Analysis',
        passed,
        details: passed 
          ? `Generated primary (${(rca.primaryHypothesis.confidence * 100).toFixed(0)}% conf) with ${rca.epistemic.known.length} knowns, ${rca.epistemic.likely.length} likelies.`
          : 'Root cause analysis did not generate expected epistemic categories.'
      });
    } catch (err: any) {
      cases.push({ name: 'Root Cause Epistemic Analysis', passed: false, details: err.message });
    }

    // --- TEST 5: Security Sensitivity & Approval Enforcement ---
    try {
      const mockFiles: Record<string, string> = {
        'src/auth/jwtSecret.ts': `export const JWT_SECRET = 'abc';`
      };

      const mockEvent = FailureNormalizer.normalize(createMockResult({
        id: 'exec-sec-1',
        command: 'npm run lint',
        exitCode: 2,
        stderr: `src/auth/jwtSecret.ts:1:20 - error TS2322: Type 'string' is not assignable to type 'Buffer'.`,
        durationMs: 50,
        outputSummary: 'Auth TS2322'
      }));

      const localized = FailureLocalizer.localize(mockEvent.location, mockFiles);
      const context = FailureContextBuilder.build(mockEvent, localized, mockFiles);
      const rca = RootCauseAnalyzer.analyze(mockEvent, context);
      const plan = RepairPlanner.plan(rca, context);

      const passed = rca.isSecuritySensitive === true && plan.approvalRequired === true;
      cases.push({
        name: 'Security-Sensitive Repair Approval Enforcement',
        passed,
        details: passed 
          ? `Detected security-critical module. Flagged approvalRequired=true (${plan.approvalReason}).`
          : 'Failed to flag security-sensitive module for approval.'
      });
    } catch (err: any) {
      cases.push({ name: 'Security-Sensitive Approval', passed: false, details: err.message });
    }

    // --- TEST 6: External Network Failure Classification ---
    try {
      const mockEvent = FailureNormalizer.normalize(createMockResult({
        id: 'exec-net-1',
        command: 'npm run fetch-data',
        exitCode: 1,
        stderr: `TypeError: fetch failed\n  code: 'ENOTFOUND'\n  hostname: 'api.external.com'`,
        durationMs: 300,
        outputSummary: 'ENOTFOUND fetch failed'
      }));

      const passed = mockEvent.type === 'EXTERNAL_DEPENDENCY_FAILURE';
      cases.push({
        name: 'External Network Failure Classification',
        passed,
        details: passed 
          ? `Correctly classified ENOTFOUND as EXTERNAL_DEPENDENCY_FAILURE instead of code bug.`
          : `Failed: type was ${mockEvent.type}`
      });
    } catch (err: any) {
      cases.push({ name: 'External Network Failure Classification', passed: false, details: err.message });
    }

    // --- TEST 7: Stale Repair & User Modification Protection ---
    try {
      const mockFiles: Record<string, string> = {
        'src/counter.ts': `let count = 0;`
      };

      const engine = SelfHealingEngine.getInstance();
      const mockResult = createMockResult({
        id: 'exec-stale-1',
        command: 'npm run lint',
        exitCode: 2,
        stderr: `src/counter.ts:1:5 - error TS2304: Cannot find name 'count'.`,
        durationMs: 50,
        outputSummary: 'TS2304'
      });

      await engine.handleExecutionFailure(mockResult, mockFiles, () => {});
      
      // User modifies file before repair is applied
      mockFiles['src/counter.ts'] = `let count = 100; // user modified`;

      const session = await engine.executeRepairCycle(
        {
          path: 'src/counter.ts',
          targetContent: `let count = 0;`,
          replacementContent: `export let count = 0;`,
          explanation: 'Export count'
        },
        mockFiles,
        () => {}
      );

      const passed = session.state === 'BLOCKED' && session.statusMessage.includes('SOURCE CHANGED');
      cases.push({
        name: 'Stale Repair & Source Modification Protection',
        passed,
        details: passed 
          ? 'Detected external file change between diagnosis and patch. Discarded stale repair.'
          : `State was ${session.state}: ${session.statusMessage}`
      });
    } catch (err: any) {
      cases.push({ name: 'Stale Repair Protection', passed: false, details: err.message });
    }

    // --- TEST 8: Regression Detection (New Errors Introduced) ---
    try {
      const previousFailure = FailureNormalizer.normalize(createMockResult({
        id: 'exec-prev-1',
        command: 'npm run lint',
        exitCode: 2,
        stderr: `src/math.ts:10:5 - error TS2304: Cannot find name 'foo'.`,
        durationMs: 60,
        outputSummary: 'TS2304 foo'
      }));

      const newResultWithRegression = createMockResult({
        id: 'exec-reg-1',
        command: 'npm run lint',
        exitCode: 2,
        stderr: `src/math.ts:10:5 - error TS2322: Type 'number' is not assignable to type 'string'.\nsrc/math.ts:12:1 - error TS2304: Cannot find name 'bar'.`,
        durationMs: 70,
        outputSummary: '2 new errors introduced'
      });

      const comparison = RegressionDetector.compare(previousFailure, newResultWithRegression, 70);
      const passed = comparison.outcome === 'REGRESSED';

      cases.push({
        name: 'Regression Detection (Introduced Errors)',
        passed,
        details: passed 
          ? `Correctly classified result as REGRESSED instead of false positive recovery.`
          : `Outcome was ${comparison.outcome}`
      });
    } catch (err: any) {
      cases.push({ name: 'Regression Detection', passed: false, details: err.message });
    }

    // --- TEST 9: Bounded Repair Limit Enforcement (max 3 attempts) ---
    try {
      const mockFiles: Record<string, string> = {
        'src/unfixable.ts': `syntax error`
      };

      const engine = SelfHealingEngine.getInstance();
      const mockResult = createMockResult({
        id: 'exec-limit-1',
        command: 'npm run lint',
        exitCode: 2,
        stderr: `src/unfixable.ts:1:1 - error TS1005: ';' expected.`,
        durationMs: 40,
        outputSummary: 'TS1005 syntax error'
      });

      await engine.handleExecutionFailure(mockResult, mockFiles, () => {});

      // Simulate 3 unsuccessful attempts
      for (let i = 0; i < 3; i++) {
        await engine.executeRepairCycle(
          {
            path: 'src/unfixable.ts',
            targetContent: 'syntax error',
            replacementContent: `syntax error // attempt ${i}`,
            explanation: `Attempt ${i}`
          },
          mockFiles,
          () => {}
        );
      }

      const session = engine.getSession();
      const passed = session?.finalOutcome === 'REPAIR_LIMIT_REACHED' || session?.state === 'FAILED';

      cases.push({
        name: 'Bounded Repair Limit Enforcement',
        passed: passed === true,
        details: passed 
          ? `Engine halted after ${session?.attempts.length} attempts without entering infinite loop.`
          : `Session state: ${session?.state}, outcome: ${session?.finalOutcome}`
      });
    } catch (err: any) {
      cases.push({ name: 'Bounded Repair Limit Enforcement', passed: false, details: err.message });
    }

    // --- TEST 10: End-to-End Self-Healing Repair (Math Error -> Diagnosis -> Fix -> Verified Recovery) ---
    try {
      const workspaceFiles: Record<string, string> = {
        'src/math.ts': `export function add(a: number, b: number): number {\n  const missingValue = 0;\n  return a + b + missingValue;\n}`,
        'package.json': `{\n  "name": "math-test",\n  "scripts": { "lint": "tsc --noEmit" }\n}`
      };

      // Set bad code
      workspaceFiles['src/math.ts'] = `export function add(a: number, b: number): number {\n  return a + b + missingValue;\n}`;

      const engine = SelfHealingEngine.getInstance();
      const initialFailureResult = createMockResult({
        id: 'exec-e2e-1',
        command: 'npm run lint',
        exitCode: 2,
        stderr: `src/math.ts:2:18 - error TS2304: Cannot find name 'missingValue'.`,
        durationMs: 80,
        outputSummary: 'TS2304 missingValue'
      });

      // 1. Ingest Failure
      await engine.handleExecutionFailure(
        initialFailureResult,
        workspaceFiles,
        (p, c) => { workspaceFiles[p] = c; }
      );

      // 2. Execute Repair Cycle with working fix
      const session = await engine.executeRepairCycle(
        {
          path: 'src/math.ts',
          targetContent: `  return a + b + missingValue;`,
          replacementContent: `  const missingValue = 0;\n  return a + b + missingValue;`,
          explanation: 'Define missingValue constant before return statement.'
        },
        workspaceFiles,
        (p, c) => { workspaceFiles[p] = c; }
      );

      const passed = session.state === 'RECOVERED' && session.finalOutcome === 'RECOVERED';

      cases.push({
        name: 'End-to-End Verified Self-Healing (Math TS2304 -> RECOVERED)',
        passed,
        details: passed 
          ? `Successfully localized, patched, re-validated with AST parser, and verified RECOVERED.`
          : `State: ${session.state}, Outcome: ${session.finalOutcome}`
      });
    } catch (err: any) {
      cases.push({ name: 'End-to-End Verified Self-Healing', passed: false, details: err.message });
    }

    // --- TEST 11: Rollback Reversibility Verification ---
    try {
      const workspaceFiles: Record<string, string> = {
        'src/feature.ts': `const initial = 'A';`
      };

      const engine = SelfHealingEngine.getInstance();
      const mockResult = createMockResult({
        id: 'exec-rb-1',
        command: 'npm run lint',
        exitCode: 2,
        stderr: `src/feature.ts:1:7 - error TS2304: Cannot find name 'foo'.`,
        durationMs: 50,
        outputSummary: 'TS2304'
      });

      await engine.handleExecutionFailure(mockResult, workspaceFiles, (p, c) => { workspaceFiles[p] = c; });
      await engine.executeRepairCycle(
        {
          path: 'src/feature.ts',
          targetContent: `const initial = 'A';`,
          replacementContent: `const initial = 'MODIFIED_IN_REPAIR';`,
          explanation: 'Modify initial'
        },
        workspaceFiles,
        (p, c) => { workspaceFiles[p] = c; }
      );

      const rbResult = engine.rollbackAttempt(workspaceFiles, (p, c) => { workspaceFiles[p] = c; });
      const passed = rbResult.success && workspaceFiles['src/feature.ts'] === `const initial = 'A';`;

      cases.push({
        name: 'Atomic Rollback & State Reversibility',
        passed,
        details: passed 
          ? 'Rollback successfully restored file content to pre-repair snapshot.'
          : `Rollback failed: ${rbResult.message}`
      });
    } catch (err: any) {
      cases.push({ name: 'Atomic Rollback', passed: false, details: err.message });
    }

    // --- TEST 12: Test Modification Labeling ---
    try {
      const mockFiles: Record<string, string> = {
        'src/calc.test.ts': `test('calc', () => { expect(1).toBe(2); });`
      };

      const mockEvent = FailureNormalizer.normalize(createMockResult({
        id: 'exec-tst-1',
        command: 'npm test',
        exitCode: 1,
        stdout: 'FAIL src/calc.test.ts\nExpected: 2, Received: 1',
        durationMs: 90,
        outputSummary: 'Test assertion fail'
      }));

      const localized = FailureLocalizer.localize(mockEvent.location, mockFiles);
      const context = FailureContextBuilder.build(mockEvent, localized, mockFiles);
      const rca = RootCauseAnalyzer.analyze(mockEvent, context);
      const plan = RepairPlanner.plan(rca, context);

      const passed = plan.isTestModification === true && plan.approvalRequired === true;

      cases.push({
        name: 'Test Modification Explicit Label & Approval',
        passed,
        details: passed 
          ? `Correctly flagged test modification with TEST MODIFICATION label & required approval.`
          : 'Failed to label test modification.'
      });
    } catch (err: any) {
      cases.push({ name: 'Test Modification Labeling', passed: false, details: err.message });
    }

    const passedTests = cases.filter(c => c.passed).length;
    const failedTests = cases.length - passedTests;

    return {
      passed: failedTests === 0,
      totalTests: cases.length,
      passedTests,
      failedTests,
      durationMs: Date.now() - startTime,
      cases
    };
  }
}

if (typeof process !== 'undefined' && process.argv && process.argv[1] && process.argv[1].endsWith('simulationDebuggerTest.ts')) {
  SimulationDebuggerTestSuite.runSuite().then(suite => {
    console.log(`\n=== P0.1 DEBUGGER SIMULATION TEST SUITE: ${suite.passedTests}/${suite.totalTests} PASSED ===`);
    for (const c of suite.cases) {
      console.log(` ${c.passed ? '✅' : '❌'} ${c.name}: ${c.details}`);
    }
    if (!suite.passed) {
      process.exit(1);
    }
  }).catch(err => {
    console.error(err);
    process.exit(1);
  });
}
