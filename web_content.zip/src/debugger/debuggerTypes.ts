/**
 * GODEX Phase 5 - Evidence-Driven Self-Healing Debugger Types
 * Formal state machine, failure models, root-cause analyses, repair plans, and regression telemetry.
 */

export type DebuggerState =
  | 'IDLE'
  | 'OBSERVING'
  | 'FAILURE_DETECTED'
  | 'DETECTED'
  | 'LOCALIZING'
  | 'ANALYZING'
  | 'HYPOTHESIS_CREATED'
  | 'PLANNING_REPAIR'
  | 'AWAITING_APPROVAL'
  | 'APPLYING_REPAIR'
  | 'PATCHING'
  | 'TYPECHECKING'
  | 'BUILDING'
  | 'RETESTING'
  | 'VALIDATING_REPAIR'
  | 'REGRESSION_CHECK'
  | 'REVERIFYING'
  | 'VERIFIED'
  | 'RECOVERED'
  | 'FAILED'
  | 'BLOCKED'
  | 'NOT_VERIFIED'
  | 'CANCELLED';

export type FailureType =
  | 'TYPE_ERROR'
  | 'SYNTAX_ERROR'
  | 'BUILD_ERROR'
  | 'TEST_FAILURE'
  | 'LINT_FAILURE'
  | 'RUNTIME_ERROR'
  | 'MODULE_NOT_FOUND'
  | 'IMPORT_ERROR'
  | 'CONFIG_ERROR'
  | 'DEPENDENCY_ERROR'
  | 'PORT_ERROR'
  | 'PROCESS_CRASH'
  | 'TIMEOUT'
  | 'EXTERNAL_DEPENDENCY_FAILURE'
  | 'UNKNOWN_FAILURE';

export type RepairOutcome =
  | 'FIXED'
  | 'IMPROVED'
  | 'UNCHANGED'
  | 'REGRESSED'
  | 'UNKNOWN';

export type EpistemicClassification = 'KNOWN' | 'LIKELY' | 'UNKNOWN';

export interface FailureLocation {
  file: string;
  line?: number;
  column?: number;
  symbol?: string;
  isExact: boolean;
  surroundingContext?: string;
}

export interface FailureEvent {
  id: string;
  executionId: string;
  type: FailureType;
  status: 'ACTIVE' | 'RESOLVED' | 'UNRESOLVED';
  command: string;
  exitCode: number;
  location: FailureLocation;
  file?: string;
  line?: number;
  column?: number;
  symbol?: string;
  message: string;
  stackTrace?: string;
  stdout: string;
  stderr: string;
  timestamp: number;
  confidence: number;
  evidence: string[];
  originalOutput: string;
}

export interface FailureHypothesis {
  cause: string;
  confidence: number;
  evidence: string[];
  suggestedFiles?: string[];
  suggestedSymbols?: string[];
}

export interface RootCauseAnalysis {
  failureId: string;
  primaryHypothesis: FailureHypothesis;
  alternativeHypotheses: FailureHypothesis[];
  epistemic: {
    known: string[];
    likely: string[];
    unknown: string[];
  };
  isSecuritySensitive: boolean;
  isDependencyRelated: boolean;
  isExternalFailure: boolean;
  isFlakyCandidate: boolean;
  analyzedAt: number;
}

export interface AffectedSymbolInfo {
  name: string;
  kind: string;
  file: string;
  line: number;
  signature?: string;
  callers?: string[];
  dependencies?: string[];
}

export interface FailureContext {
  failure: FailureEvent;
  affectedFiles: Array<{
    path: string;
    content: string;
    language: string;
    lineRange?: { start: number; end: number };
  }>;
  affectedSymbols: AffectedSymbolInfo[];
  relatedFiles: string[];
  relatedTests: string[];
  dependencyPath: string[];
  architectureLayer?: string;
  recentChanges: string[];
  previousAttempts: RepairAttempt[];
  executionEvidence: string[];
  contextPackSummary?: string;
}

export interface RepairPatch {
  path: string;
  operation: 'UPDATE_FILE' | 'CREATE_FILE' | 'DELETE_FILE' | 'APPLY_PATCH';
  explanation: string;
  beforeContent?: string;
  patchContent: string;
  targetContent?: string;
  replacementContent?: string;
}

export interface RepairPlan {
  id: string;
  failureId: string;
  problem: string;
  evidence: string[];
  likelyCause: string;
  proposedFix: string;
  files: string[];
  patches: RepairPatch[];
  expectedEffect: string;
  validationSteps: Array<{
    command: string;
    scriptType?: 'TEST' | 'BUILD' | 'LINT' | 'TYPECHECK' | 'DEV_SERVER';
    expectedExitCode: number;
  }>;
  approvalRequired: boolean;
  approvalReason?: string;
  isTestModification: boolean;
  isSecuritySensitive: boolean;
  isDependencyRelated: boolean;
  createdAt: number;
}

export interface BeforeAfterComparison {
  outcome: RepairOutcome;
  previousExitCode: number;
  newExitCode: number;
  previousErrorCount: number;
  newErrorCount: number;
  resolvedErrors: string[];
  introducedErrors: string[];
  retainedErrors: string[];
  evidenceComparison: string;
  executionDurationMs: number;
}

export interface RepairAttempt {
  attemptNumber: number;
  timestamp: number;
  cause: string;
  plan: RepairPlan;
  patchesApplied: string[];
  checkpointId?: string;
  comparison?: BeforeAfterComparison;
  status: 'PASSED' | 'FAILED' | 'REGRESSED' | 'ABORTED' | 'PENDING';
  durationMs: number;
}

export interface DebuggerSession {
  id: string;
  state: DebuggerState;
  executionId: string;
  currentFailure?: FailureEvent;
  rootCause?: RootCauseAnalysis;
  context?: FailureContext;
  currentPlan?: RepairPlan;
  attempts: RepairAttempt[];
  maxRepairAttempts: number;
  baselineValidated: boolean;
  startTime: number;
  endTime?: number;
  finalOutcome?: 'RECOVERED' | 'REPAIR_LIMIT_REACHED' | 'BLOCKED' | 'FAILED' | 'CANCELLED';
  statusMessage: string;
}

export type DebuggerEventListener = (event: {
  type:
    | 'STATE_CHANGED'
    | 'FAILURE_DETECTED'
    | 'FAILURE_LOCALIZED'
    | 'CONTEXT_BUILT'
    | 'ROOT_CAUSE_ANALYZED'
    | 'REPAIR_PLAN_GENERATED'
    | 'APPROVAL_REQUIRED'
    | 'REPAIR_APPLIED'
    | 'REVALIDATION_STARTED'
    | 'REVALIDATION_COMPLETED'
    | 'ROLLBACK_TRIGGERED'
    | 'SESSION_COMPLETED'
    | 'SESSION_FAILED';
  sessionId: string;
  timestamp: number;
  state: DebuggerState;
  data: any;
}) => void;
