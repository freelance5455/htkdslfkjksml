/**
 * GODEX Phase 5 - Repair Planner
 * Formulates a structured, safe RepairPlan based on RootCauseAnalysis and FailureContext.
 * Evaluates approval policies, checks test modification safety, and prepares Phase 3 patches.
 */

import { 
  RepairPlan, 
  RepairPatch, 
  RootCauseAnalysis, 
  FailureContext 
} from './debuggerTypes';
import { FileEditEngine } from '../coding/fileEditEngine';

export class RepairPlanner {
  /**
   * Generates a concrete, verifiable RepairPlan from diagnosis
   */
  public static plan(
    analysis: RootCauseAnalysis,
    context: FailureContext,
    candidatePatch?: {
      path: string;
      targetContent: string;
      replacementContent: string;
      explanation: string;
    }
  ): RepairPlan {
    const failure = context.failure;
    const targetFile = context.affectedFiles[0]?.path || failure.file || 'unknown';
    const isTestModification = targetFile.includes('.test.') || targetFile.includes('.spec.');
    const isSecuritySensitive = analysis.isSecuritySensitive;
    const isDependencyRelated = analysis.isDependencyRelated;

    // Determine approval requirements based on Phase 3 and Phase 5 rules
    let approvalRequired = false;
    let approvalReason: string | undefined;

    if (isSecuritySensitive) {
      approvalRequired = true;
      approvalReason = `Security-sensitive code repair in "${targetFile}" requires explicit developer authorization.`;
    } else if (isDependencyRelated) {
      approvalRequired = true;
      approvalReason = `Dependency modification required. External package changes require explicit authorization.`;
    } else if (isTestModification) {
      approvalRequired = true;
      approvalReason = `TEST MODIFICATION: Proposed repair modifies a test file rather than source implementation.`;
    } else if (analysis.isExternalFailure) {
      approvalRequired = true;
      approvalReason = `External network or service outage detected. Code modification is paused to avoid hallucinated repairs.`;
    }

    // Formulate patches
    const patches: RepairPatch[] = [];
    if (candidatePatch) {
      const beforeContent = context.affectedFiles.find(f => f.path === candidatePatch.path)?.content;
      patches.push({
        path: candidatePatch.path,
        operation: 'UPDATE_FILE',
        explanation: candidatePatch.explanation,
        beforeContent,
        patchContent: candidatePatch.replacementContent,
        targetContent: candidatePatch.targetContent,
        replacementContent: candidatePatch.replacementContent
      });
    }

    // Determine validation steps
    const validationSteps: RepairPlan['validationSteps'] = [];
    if (failure.type === 'TYPE_ERROR' || failure.type === 'SYNTAX_ERROR') {
      validationSteps.push({
        command: 'npm run lint',
        scriptType: 'TYPECHECK',
        expectedExitCode: 0
      });
    } else if (failure.type === 'TEST_FAILURE') {
      validationSteps.push({
        command: 'npm test',
        scriptType: 'TEST',
        expectedExitCode: 0
      });
    } else if (failure.type === 'BUILD_ERROR' || failure.type === 'MODULE_NOT_FOUND') {
      validationSteps.push({
        command: 'npm run build',
        scriptType: 'BUILD',
        expectedExitCode: 0
      });
    } else {
      validationSteps.push({
        command: failure.command || 'npm run build',
        expectedExitCode: 0
      });
    }

    return {
      id: 'plan-' + Math.random().toString(36).slice(2, 9),
      failureId: failure.id,
      problem: failure.message,
      evidence: failure.evidence,
      likelyCause: analysis.primaryHypothesis.cause,
      proposedFix: candidatePatch ? candidatePatch.explanation : `Repair offending statement in "${targetFile}".`,
      files: candidatePatch ? [candidatePatch.path] : (targetFile !== 'unknown' ? [targetFile] : []),
      patches,
      expectedEffect: `Eliminates the diagnostic error "${failure.message.slice(0, 80)}" and restores clean execution.`,
      validationSteps,
      approvalRequired,
      approvalReason,
      isTestModification,
      isSecuritySensitive,
      isDependencyRelated,
      createdAt: Date.now()
    };
  }
}
