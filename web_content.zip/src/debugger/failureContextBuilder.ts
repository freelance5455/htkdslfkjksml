/**
 * GODEX Phase 5 - Failure Context Builder
 * Assembles a bounded, high-relevance FailureContext by querying Phase 1 Project Intelligence
 * and Phase 2 ContextPack components.
 */

import { 
  FailureEvent, 
  FailureContext, 
  AffectedSymbolInfo, 
  RepairAttempt 
} from './debuggerTypes';
import { LocalizedScope } from './failureLocalizer';
import { IntelligenceEngine } from '../intelligence/intelligenceEngine';
import { ContextPackBuilder } from '../intelligence/contextPackBuilder';
import { IntentClassifier } from '../intelligence/intentClassifier';
import { TaskExtractor } from '../intelligence/taskExtractor';

export class FailureContextBuilder {
  /**
   * Builds a structured FailureContext for the AI Brain and Self-Healing Engine
   */
  public static build(
    failure: FailureEvent,
    localized: LocalizedScope,
    rawFiles: Record<string, string>,
    recentChanges: string[] = [],
    previousAttempts: RepairAttempt[] = []
  ): FailureContext {
    const intel = IntelligenceEngine.getInstance();
    const intelState = intel.getState();
    const targetFile = localized.file;

    // 1. Collect affected files
    const affectedFiles: FailureContext['affectedFiles'] = [];
    if (targetFile && rawFiles[targetFile]) {
      const ext = targetFile.split('.').pop() || 'ts';
      const lang = ext === 'ts' || ext === 'tsx' ? 'typescript' : ext === 'js' || ext === 'jsx' ? 'javascript' : 'plaintext';
      
      const lineRange = localized.line !== undefined 
        ? { start: Math.max(1, localized.line - 15), end: localized.line + 15 }
        : undefined;

      affectedFiles.push({
        path: targetFile,
        content: rawFiles[targetFile],
        language: lang,
        lineRange
      });
    }

    // 2. Identify affected symbols from SymbolIndex
    const affectedSymbols: AffectedSymbolInfo[] = [];
    if (targetFile && localized.symbol) {
      const symbolsInFile = intelState.files[targetFile]?.symbols || [];
      const match = symbolsInFile.find(s => s.name === localized.symbol || (localized.line && s.line <= localized.line && (s.endLine ?? s.line) >= localized.line));
      if (match) {
        // Find callers
        const callers = intelState.graph.edges
          .filter(e => e.target === targetFile)
          .map(e => e.source);

        affectedSymbols.push({
          name: match.name,
          kind: match.kind,
          file: targetFile,
          line: match.line,
          signature: match.signature,
          callers,
          dependencies: match.dependencies
        });
      }
    }

    // 3. Find related files (direct imports and direct dependents)
    const relatedFilesSet = new Set<string>();
    if (targetFile) {
      // Outgoing imports
      const outgoing = intelState.graph.edges.filter(e => e.source === targetFile).map(e => e.target);
      outgoing.forEach(f => relatedFilesSet.add(f));

      // Incoming callers
      const incoming = intelState.graph.edges.filter(e => e.target === targetFile).map(e => e.source);
      incoming.forEach(f => relatedFilesSet.add(f));
    }
    const relatedFiles = Array.from(relatedFilesSet).slice(0, 5);

    // 4. Find related test files
    const relatedTests: string[] = [];
    if (targetFile) {
      const baseName = targetFile.replace(/\.[^/.]+$/, '').split('/').pop();
      if (baseName) {
        Object.keys(rawFiles).forEach(f => {
          if ((f.includes('.test.') || f.includes('.spec.')) && (f.includes(baseName) || f.includes(targetFile))) {
            relatedTests.push(f);
          }
        });
      }
    }

    // 5. Dependency path from entry point
    const dependencyPath: string[] = [];
    if (targetFile) {
      const entryPoints = Object.values(intelState.metadata.entryPoints);
      if (entryPoints.length > 0) {
        dependencyPath.push(entryPoints[0], targetFile);
      }
    }

    // 6. Architecture layer identification
    let architectureLayer: string | undefined;
    if (targetFile) {
      const matchedNode = intelState.graph.nodes.find(n => n.id === targetFile);
      architectureLayer = matchedNode?.layer;
    }

    // 7. Leverage Phase 2 ContextPackBuilder for a high-level summary
    let contextPackSummary: string | undefined;
    try {
      const prompt = `Fix failure in ${targetFile}: ${failure.message}`;
      const intent = IntentClassifier.classify(prompt);
      const task = TaskExtractor.extract(prompt);
      const pack = ContextPackBuilder.build(
        prompt,
        intent.intent,
        task,
        intelState,
        rawFiles,
        undefined,
        recentChanges
      );
      contextPackSummary = `Context Pack (Health Score: ${pack.architectureSummary.healthScore}, Budget: ${pack.totalTokensEstimate} tokens, Budget Used: ${pack.budgetUsagePercent.toFixed(1)}%)`;
    } catch {
      contextPackSummary = 'Standard Context Pack assembled.';
    }

    return {
      failure,
      affectedFiles,
      affectedSymbols,
      relatedFiles,
      relatedTests,
      dependencyPath,
      architectureLayer,
      recentChanges,
      previousAttempts,
      executionEvidence: failure.evidence,
      contextPackSummary
    };
  }
}
