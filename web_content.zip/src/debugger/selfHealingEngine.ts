/**
 * GODEX Phase 5 - Self-Healing Debugger Orchestrator
 * Full state machine coordinating diagnosis, localization, root cause analysis,
 * safe patching, bounded repair loops, regression checks, and truthful verification.
 */

import { 
  DebuggerState, 
  DebuggerSession, 
  FailureEvent, 
  RootCauseAnalysis, 
  FailureContext, 
  RepairPlan, 
  RepairAttempt, 
  DebuggerEventListener 
} from './debuggerTypes';
import { FailureNormalizer } from './failureNormalizer';
import { FailureLocalizer } from './failureLocalizer';
import { FailureContextBuilder } from './failureContextBuilder';
import { RootCauseAnalyzer } from './rootCauseAnalyzer';
import { RepairPlanner } from './repairPlanner';
import { RegressionDetector } from './regressionDetector';
import { RollbackManager } from '../coding/rollbackManager';
import { IntelligenceEngine } from '../intelligence/intelligenceEngine';
import { ContextCache } from '../intelligence/contextCache';
import { ExecutionEngine } from '../execution/executor';
import { ExecutionResult } from '../execution/executionTypes';
import { EngineeringMemoryEngine } from '../memory/engineeringMemory';

export class SelfHealingEngine {
  private static instance: SelfHealingEngine | null = null;
  private currentSession: DebuggerSession | null = null;
  private listeners: Set<DebuggerEventListener> = new Set();
  private maxAttempts = 3;
  private isPaused = false;
  private isCancelled = false;

  private constructor() {}

  public static getInstance(): SelfHealingEngine {
    if (!SelfHealingEngine.instance) {
      SelfHealingEngine.instance = new SelfHealingEngine();
    }
    return SelfHealingEngine.instance;
  }

  public subscribe(listener: DebuggerEventListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(type: any, data?: any): void {
    if (!this.currentSession) return;
    const event = {
      type,
      sessionId: this.currentSession.id,
      timestamp: Date.now(),
      state: this.currentSession.state,
      data
    };
    this.listeners.forEach(l => {
      try {
        l(event);
      } catch (err) {
        console.error('Debugger listener error:', err);
      }
    });
  }

  public getSession(): DebuggerSession | null {
    return this.currentSession ? { ...this.currentSession } : null;
  }

  /**
   * Starts a new Self-Healing Debugger session for a failed execution
   */
  public async handleExecutionFailure(
    executionResult: ExecutionResult,
    rawFiles: Record<string, string>,
    onFileMutation: (path: string, content: string) => void,
    recentChanges: string[] = []
  ): Promise<DebuggerSession> {
    const sessionId = 'dbg-' + Math.random().toString(36).slice(2, 9);
    this.isPaused = false;
    this.isCancelled = false;

    this.currentSession = {
      id: sessionId,
      state: 'FAILURE_DETECTED',
      executionId: executionResult.id,
      attempts: [],
      maxRepairAttempts: this.maxAttempts,
      baselineValidated: false,
      startTime: Date.now(),
      statusMessage: 'Execution failure captured. Initiating normalization...'
    };
    this.emit('STATE_CHANGED', { state: this.currentSession.state });

    // Step 1: Normalization
    const failure = FailureNormalizer.normalize(executionResult);
    this.currentSession.currentFailure = failure;
    this.emit('FAILURE_DETECTED', { failure });

    // Step 2: Localization
    this.transitionState('LOCALIZING', 'Localizing error source from AST and symbol index...');
    const localized = FailureLocalizer.localize(failure.location, rawFiles);
    this.emit('FAILURE_LOCALIZED', { localized });

    // Step 3: Failure Context Construction
    this.transitionState('ANALYZING', 'Constructing bounded FailureContext via Phase 2 ContextPack...');
    const context = FailureContextBuilder.build(
      failure,
      localized,
      rawFiles,
      recentChanges,
      this.currentSession.attempts
    );
    this.currentSession.context = context;
    this.emit('CONTEXT_BUILT', { context });

    // Step 4: Root Cause Analysis
    const rootCause = RootCauseAnalyzer.analyze(failure, context);
    this.currentSession.rootCause = rootCause;
    this.emit('ROOT_CAUSE_ANALYZED', { rootCause });

    // Record failure in Phase 7 Engineering Memory
    try {
      EngineeringMemoryEngine.getInstance().recordFailure({
        errorCode: failure.type,
        errorMessage: failure.message,
        location: failure.location ? `${failure.location.file}:${failure.location.line || 1}` : undefined,
        symbol: failure.symbol || localized.symbol || localized.containingSymbol?.name,
        relatedFiles: failure.location?.file ? [failure.location.file] : [],
        rootCause: rootCause.primaryHypothesis.cause,
        classification: failure.exitCode !== 0 ? 'RUNTIME_ERROR' : 'UNKNOWN',
        executionId: executionResult.id,
        source: 'DEBUGGER'
      });
    } catch (err) {
      console.warn('Could not record failure memory:', err);
    }

    return this.currentSession;
  }

  /**
   * Plans and executes a single self-healing repair cycle with full verification
   */
  public async executeRepairCycle(
    candidatePatch: {
      path: string;
      targetContent: string;
      replacementContent: string;
      explanation: string;
    },
    rawFiles: Record<string, string>,
    onFileMutation: (path: string, content: string) => void
  ): Promise<DebuggerSession> {
    if (!this.currentSession || !this.currentSession.currentFailure || !this.currentSession.rootCause || !this.currentSession.context) {
      throw new Error('No active debugger session to repair.');
    }

    if (this.currentSession.attempts.length >= this.currentSession.maxRepairAttempts) {
      this.transitionState('FAILED', `Maximum repair budget (${this.currentSession.maxRepairAttempts} attempts) reached. Halting self-healing loop.`);
      this.currentSession.finalOutcome = 'REPAIR_LIMIT_REACHED';
      this.emit('SESSION_FAILED', { outcome: 'REPAIR_LIMIT_REACHED' });
      return this.currentSession;
    }

    const attemptNumber = this.currentSession.attempts.length + 1;
    const attemptStartTime = Date.now();

    // Step 5: Planning Repair
    this.transitionState('PLANNING_REPAIR', `Formulating Repair Plan (Attempt ${attemptNumber}/${this.currentSession.maxRepairAttempts})...`);
    const plan = RepairPlanner.plan(this.currentSession.rootCause, this.currentSession.context, candidatePatch);
    this.currentSession.currentPlan = plan;
    this.emit('REPAIR_PLAN_GENERATED', { plan });

    // Step 6: Approval Check
    if (plan.approvalRequired) {
      this.transitionState('AWAITING_APPROVAL', `Approval required: ${plan.approvalReason}`);
      this.emit('APPROVAL_REQUIRED', { plan });
      return this.currentSession;
    }

    // Step 7: Apply Repair Safely
    return await this.applyAndVerifyRepair(plan, rawFiles, onFileMutation, attemptNumber, attemptStartTime);
  }

  /**
   * Approves an awaiting repair plan and triggers its execution
   */
  public async approveAndProceed(
    rawFiles: Record<string, string>,
    onFileMutation: (path: string, content: string) => void
  ): Promise<DebuggerSession> {
    if (!this.currentSession || !this.currentSession.currentPlan) {
      throw new Error('No pending plan to approve.');
    }

    const attemptNumber = this.currentSession.attempts.length + 1;
    const attemptStartTime = Date.now();
    return await this.applyAndVerifyRepair(this.currentSession.currentPlan, rawFiles, onFileMutation, attemptNumber, attemptStartTime);
  }

  /**
   * Applies the patch, refreshes Phase 1 & 2 intelligence, runs Phase 4 validation, and detects regression
   */
  private async applyAndVerifyRepair(
    plan: RepairPlan,
    rawFiles: Record<string, string>,
    onFileMutation: (path: string, content: string) => void,
    attemptNumber: number,
    attemptStartTime: number
  ): Promise<DebuggerSession> {
    if (!this.currentSession) throw new Error('No active session.');

    this.transitionState('APPLYING_REPAIR', `Applying verified patch to ${plan.files.join(', ')}...`);

    // Check for Stale Repair / User modification protection
    for (const patch of plan.patches) {
      const currentContent = rawFiles[patch.path];
      if (patch.beforeContent !== undefined && currentContent !== patch.beforeContent) {
        this.transitionState('BLOCKED', `SOURCE CHANGED: File "${patch.path}" was modified since diagnosis. Stale repair discarded.`);
        this.emit('SESSION_FAILED', { reason: 'STALE_REPAIR_DISCARDED' });
        return this.currentSession;
      }
    }

    // Capture Rollback Checkpoint
    const checkpoint = RollbackManager.createCheckpoint(
      this.currentSession.id,
      `Self-healing attempt ${attemptNumber}: ${plan.proposedFix}`,
      rawFiles
    );

    // Apply Patches
    const appliedFiles: string[] = [];
    for (const patch of plan.patches) {
      let updated = rawFiles[patch.path] || '';
      const before = rawFiles[patch.path];
      if (patch.targetContent && patch.replacementContent) {
        updated = updated.replace(patch.targetContent, patch.replacementContent);
      } else {
        updated = patch.patchContent;
      }

      RollbackManager.recordOperation(this.currentSession.id, {
        id: `op-repair-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        operation: 'UPDATE_FILE',
        target: patch.path,
        beforeState: before || '',
        afterState: updated,
        reason: patch.explanation || 'Self-healing repair patch',
        isDestructive: false,
        approvalRequired: false,
        additions: 1,
        deletions: 0,
        status: 'applied',
        appliedAt: Date.now()
      });

      onFileMutation(patch.path, updated);
      rawFiles[patch.path] = updated;
      appliedFiles.push(patch.path);

      // Phase 1 Incremental Intelligence Update
      try {
        IntelligenceEngine.getInstance().updateFile(patch.path, updated);
      } catch (err) {
        console.warn('Phase 1 incremental update warning:', err);
      }
    }

    // Phase 2 Context Cache Invalidation
    ContextCache.invalidateForFile(appliedFiles[0] || '');

    this.emit('REPAIR_APPLIED', { plan, appliedFiles, checkpointId: checkpoint.id });

    // Step 8: Re-validation via Phase 4 Execution Engine
    this.transitionState('VALIDATING_REPAIR', `Executing Phase 4 validation step...`);
    this.emit('REVALIDATION_STARTED', { validationSteps: plan.validationSteps });

    const step = plan.validationSteps[0] || { command: 'npm run lint', scriptType: 'TYPECHECK' };
    const execResult = await ExecutionEngine.execute(
      {
        id: `repair-val-${Date.now()}`,
        command: step.command,
        resolvedScriptType: (step.scriptType as any) || 'TYPECHECK',
        workingDirectory: '.',
        timeoutMs: 15000,
        requestedBy: 'SYSTEM_VALIDATION',
        reason: 'Revalidating patch after repair cycle',
        createdAt: Date.now()
      },
      rawFiles
    );

    this.transitionState('REVERIFYING', `Analyzing revalidation outcome (exit code ${execResult.exitCode})...`);

    // Step 9: Regression Detection & Comparison
    const comparison = RegressionDetector.compare(
      this.currentSession.currentFailure!,
      execResult,
      Date.now() - attemptStartTime
    );

    const attempt: RepairAttempt = {
      attemptNumber,
      timestamp: Date.now(),
      cause: plan.likelyCause,
      plan,
      patchesApplied: appliedFiles,
      checkpointId: checkpoint.id,
      comparison,
      status: comparison.outcome === 'FIXED' ? 'PASSED' : comparison.outcome === 'REGRESSED' ? 'REGRESSED' : 'FAILED',
      durationMs: Date.now() - attemptStartTime
    };

    this.currentSession.attempts.push(attempt);
    this.emit('REVALIDATION_COMPLETED', { attempt, comparison });

    // Record Repair and Verification into Phase 7 Engineering Memory
    try {
      EngineeringMemoryEngine.getInstance().recordRepair({
        failureId: this.currentSession.id,
        errorCode: this.currentSession.currentFailure?.type,
        attemptNumber,
        strategy: plan.likelyCause || plan.problem,
        files: appliedFiles,
        outcome: comparison.outcome === 'FIXED' ? 'SUCCESS' : comparison.outcome === 'REGRESSED' ? 'REGRESSED' : 'FAILED',
        proposedFix: plan.proposedFix,
        verificationEvidence: [`ExitCode: ${execResult.exitCode}`, `Outcome: ${comparison.outcome}`],
        source: 'DEBUGGER'
      });

      if (comparison.outcome === 'FIXED') {
        EngineeringMemoryEngine.getInstance().recordVerification({
          verificationType: 'TYPECHECK',
          passed: true,
          exitCode: execResult.exitCode,
          evidenceId: execResult.id,
          summary: `Self-healing repair verified clean validation with exit code ${execResult.exitCode}.`,
          relatedFiles: appliedFiles,
          source: 'DEBUGGER'
        });
      }
    } catch (err) {
      console.warn('Could not record repair memory:', err);
    }

    // Update context baseline with the result of this attempt for subsequent attempts
    if (this.currentSession.context) {
      this.currentSession.context.affectedFiles = this.currentSession.context.affectedFiles.map(af => ({
        ...af,
        content: rawFiles[af.path] ?? af.content
      }));
    }

    // Step 10: State Machine Conclusion
    if (comparison.outcome === 'FIXED') {
      this.transitionState('RECOVERED', `Self-healing completed successfully. Verified clean validation.`);
      this.currentSession.finalOutcome = 'RECOVERED';
      this.currentSession.endTime = Date.now();
      this.emit('SESSION_COMPLETED', { outcome: 'RECOVERED', attempt });
    } else if (comparison.outcome === 'REGRESSED') {
      this.transitionState('FAILED', `Regression detected after patch! New errors introduced. Halting or rolling back.`);
      this.currentSession.finalOutcome = 'FAILED';
      this.emit('SESSION_FAILED', { outcome: 'REGRESSED', attempt });
    } else if (this.currentSession.attempts.length >= this.currentSession.maxRepairAttempts) {
      this.transitionState('FAILED', `Max repair budget (${this.currentSession.maxRepairAttempts}) reached without resolution.`);
      this.currentSession.finalOutcome = 'REPAIR_LIMIT_REACHED';
      this.emit('SESSION_FAILED', { outcome: 'REPAIR_LIMIT_REACHED' });
    } else {
      this.transitionState('ANALYZING', `Attempt ${attemptNumber} resulted in ${comparison.outcome}. Preparing subsequent hypothesis...`);
    }

    return this.currentSession;
  }

  /**
   * Rolls back the last applied repair attempt
   */
  public rollbackAttempt(
    rawFiles: Record<string, string>,
    onFileMutation: (path: string, content: string) => void
  ): { success: boolean; message: string } {
    if (!this.currentSession || this.currentSession.attempts.length === 0) {
      return { success: false, message: 'No repair attempts available to roll back.' };
    }

    const res = RollbackManager.rollbackTask(this.currentSession.id, rawFiles);
    if (res.success) {
      Object.entries(res.restoredFiles).forEach(([p, c]) => {
        rawFiles[p] = c;
        onFileMutation(p, c);
        try {
          IntelligenceEngine.getInstance().updateFile(p, c);
        } catch {}
      });
      ContextCache.clear();
      this.transitionState('IDLE', `Repair attempt rolled back to pre-repair state.`);
      this.emit('ROLLBACK_TRIGGERED', { restoredFiles: Object.keys(res.restoredFiles) });
    }

    return res;
  }

  public cancelSession(): void {
    this.isCancelled = true;
    if (this.currentSession) {
      this.transitionState('CANCELLED', 'Self-healing session cancelled by user.');
      this.currentSession.finalOutcome = 'CANCELLED';
      this.emit('SESSION_COMPLETED', { outcome: 'CANCELLED' });
    }
  }

  private transitionState(newState: DebuggerState, statusMessage: string): void {
    if (this.currentSession) {
      this.currentSession.state = newState;
      this.currentSession.statusMessage = statusMessage;
      this.emit('STATE_CHANGED', { state: newState, statusMessage });
    }
  }
}
