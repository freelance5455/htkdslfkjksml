/**
 * GODEX Phase 5 - Failure Localizer
 * Correlates failure coordinates with Phase 1 AST symbol indexes and source code trees
 * to precisely locate the offending symbol, containing scope, and surrounding lines.
 */

import { FailureLocation } from './debuggerTypes';
import { IntelligenceEngine } from '../intelligence/intelligenceEngine';
import { AstParser, ParsedFileAst } from '../intelligence/astParser';

export interface LocalizedScope {
  file: string;
  line?: number;
  column?: number;
  symbol?: string;
  containingSymbol?: {
    name: string;
    kind: string;
    startLine: number;
    endLine: number;
  };
  surroundingSnippet?: string;
  isExact: boolean;
}

export class FailureLocalizer {
  /**
   * Localizes the failure within the actual project files using AST and Symbol Indexes
   */
  public static localize(
    location: FailureLocation,
    rawFiles: Record<string, string>
  ): LocalizedScope {
    const rawFile = location.file;

    // Check if location points to a known file or if path needs normalizing
    let targetPath = rawFile;
    if (targetPath && !rawFiles[targetPath]) {
      // Try resolving relative path variations e.g. "./src/math.ts" vs "src/math.ts"
      const cleaned = targetPath.replace(/^\.\//, '');
      if (rawFiles[cleaned]) {
        targetPath = cleaned;
      } else {
        // Search by basename
        const matchingKey = Object.keys(rawFiles).find(k => k.endsWith(cleaned) || k.endsWith(targetPath));
        if (matchingKey) {
          targetPath = matchingKey;
        }
      }
    }

    const fileContent = targetPath ? rawFiles[targetPath] : undefined;

    // If file doesn't exist in workspace, mark as unknown
    if (!fileContent || !targetPath) {
      return {
        file: targetPath || 'UNKNOWN',
        line: location.line,
        column: location.column,
        symbol: location.symbol,
        isExact: false
      };
    }

    const lines = fileContent.split('\n');
    let surroundingSnippet: string | undefined;

    if (location.line !== undefined && location.line > 0 && location.line <= lines.length) {
      const lineIdx = location.line - 1;
      const startIdx = Math.max(0, lineIdx - 4);
      const endIdx = Math.min(lines.length - 1, lineIdx + 4);

      surroundingSnippet = lines
        .slice(startIdx, endIdx + 1)
        .map((l, i) => {
          const currentLineNum = startIdx + i + 1;
          const marker = currentLineNum === location.line ? ' > ' : '   ';
          return `${marker}${currentLineNum.toString().padStart(4, ' ')} | ${l}`;
        })
        .join('\n');
    }

    // Attempt to locate containing symbol from AST
    let containingSymbol: LocalizedScope['containingSymbol'];
    try {
      const ast = AstParser.parse(targetPath, fileContent);
      if (location.line !== undefined) {
        // Find symbol spanning this line
        const found = ast.symbols.find(s => s.line <= location.line! && (s.endLine ?? s.line) >= location.line!);
        if (found) {
          containingSymbol = {
            name: found.name,
            kind: found.kind,
            startLine: found.line,
            endLine: found.endLine ?? found.line
          };
        }
      }

      // If symbol is undefined, but symbol name is in location, verify existence
      if (!location.symbol && containingSymbol) {
        location.symbol = containingSymbol.name;
      }
    } catch {
      // AST parse failed on invalid syntax, keep raw coordinates
    }

    return {
      file: targetPath,
      line: location.line,
      column: location.column,
      symbol: location.symbol || containingSymbol?.name,
      containingSymbol,
      surroundingSnippet,
      isExact: location.line !== undefined
    };
  }
}
