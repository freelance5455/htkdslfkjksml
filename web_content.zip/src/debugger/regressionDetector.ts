/**
 * GODEX Phase 5 - Regression Detector & Outcome Comparator
 * Truthfully compares BEFORE and AFTER execution results.
 * Distinguishes genuine RECOVERY from REGRESSION and PARTIAL IMPROVEMENT.
 */

import { 
  BeforeAfterComparison, 
  RepairOutcome, 
  FailureEvent 
} from './debuggerTypes';
import { ExecutionResult } from '../execution/executionTypes';
import { FailureNormalizer } from './failureNormalizer';

export class RegressionDetector {
  /**
   * Compares the previous FailureEvent against the post-repair ExecutionResult
   */
  public static compare(
    previousFailure: FailureEvent,
    newResult: ExecutionResult,
    durationMs: number
  ): BeforeAfterComparison {
    const prevExit = previousFailure.exitCode;
    const newExit = newResult.exitCode;

    const previousErrors = [previousFailure.message];
    const prevCount = previousErrors.length;

    // Analyze new result
    const newStdout = newResult.stdout || '';
    const newStderr = newResult.stderr || '';
    const newOutput = `${newStdout}\n${newStderr}`.trim();

    // Check if new run succeeded cleanly
    if (newResult.status === 'COMPLETED' && newExit === 0) {
      return {
        outcome: 'FIXED',
        previousExitCode: prevExit,
        newExitCode: newExit,
        previousErrorCount: prevCount,
        newErrorCount: 0,
        resolvedErrors: previousErrors,
        introducedErrors: [],
        retainedErrors: [],
        evidenceComparison: `Previous failure "${previousFailure.message.slice(0, 60)}" was successfully resolved. Execution succeeded with exit code 0.`,
        executionDurationMs: durationMs
      };
    }

    // New run also failed — normalize the new failure
    const newFailure = FailureNormalizer.normalize(newResult);
    const newErrors = [newFailure.message];
    const newCount = newErrors.length;

    // Check if original error is still present
    const originalStillPresent = newOutput.includes(previousFailure.message) ||
      (previousFailure.location.symbol ? newOutput.includes(previousFailure.location.symbol) : false) ||
      (newFailure.message === previousFailure.message);

    // Check if new, different errors were introduced
    const isDifferentError = !originalStillPresent && newFailure.message !== previousFailure.message;

    let outcome: RepairOutcome = 'UNCHANGED';
    let summary = '';

    if (isDifferentError) {
      // Original error disappeared, but a new error emerged -> REGRESSED
      outcome = 'REGRESSED';
      summary = `REGRESSION DETECTED: Original error was replaced by new failure: "${newFailure.message}".`;
    } else if (originalStillPresent) {
      outcome = 'UNCHANGED';
      summary = `FAILURE PERSISTS: Original diagnostic remains unresolved: "${previousFailure.message}".`;
    } else if (newCount < prevCount) {
      outcome = 'IMPROVED';
      summary = `PARTIAL IMPROVEMENT: Error count reduced from ${prevCount} to ${newCount}.`;
    } else {
      outcome = 'UNKNOWN';
      summary = `Execution completed with non-zero exit code (${newExit}).`;
    }

    return {
      outcome,
      previousExitCode: prevExit,
      newExitCode: newExit,
      previousErrorCount: prevCount,
      newErrorCount: newCount,
      resolvedErrors: originalStillPresent ? [] : previousErrors,
      introducedErrors: isDifferentError ? newErrors : [],
      retainedErrors: originalStillPresent ? previousErrors : [],
      evidenceComparison: summary,
      executionDurationMs: durationMs
    };
  }
}
