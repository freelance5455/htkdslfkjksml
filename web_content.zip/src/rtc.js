// 内网直连：WebRTC 数据通道 + 手动交换连接码（不经过任何服务器）

var RTC = { pc: null, dc: null, mode: null };

function rtcB64Encode(str) {
  return btoa(unescape(encodeURIComponent(str)));
}
function rtcB64Decode(str) {
  var s = String(str).replace(/\s+/g, '');
  return decodeURIComponent(escape(atob(s)));
}

function rtcNewPeer() {
  return new RTCPeerConnection({ iceServers: [] });
}

function rtcWaitIce(pc) {
  return new Promise(function (resolve) {
    if (pc.iceGatheringState === 'complete') return resolve();
    var done = false;
    var finish = function () {
      if (done) return;
      done = true;
      resolve();
    };
    pc.addEventListener('icegatheringstatechange', function () {
      if (pc.iceGatheringState === 'complete') finish();
    });
    setTimeout(finish, 2500);
  });
}

// 主机：建 pc + 数据通道，返回 offer 码
function rtcMakeOffer(onChannel) {
  var pc = rtcNewPeer();
  RTC.pc = pc;
  RTC.mode = 'host';
  var dc = pc.createDataChannel('game', { ordered: true });
  RTC.dc = dc;
  onChannel(dc);
  return pc.createOffer()
    .then(function (offer) { return pc.setLocalDescription(offer); })
    .then(function () { return rtcWaitIce(pc); })
    .then(function () { return rtcB64Encode(pc.localDescription.sdp); });
}

// 客户端：吃掉 offer 码，返回 answer 码
function rtcTakeOffer(code, onChannel) {
  var pc = rtcNewPeer();
  RTC.pc = pc;
  RTC.mode = 'client';
  pc.ondatachannel = function (ev) {
    RTC.dc = ev.channel;
    onChannel(ev.channel);
  };
  return pc.setRemoteDescription({ type: 'offer', sdp: rtcB64Decode(code) })
    .then(function () { return pc.createAnswer(); })
    .then(function (answer) { return pc.setLocalDescription(answer); })
    .then(function () { return rtcWaitIce(pc); })
    .then(function () { return rtcB64Encode(pc.localDescription.sdp); });
}

// 主机：吃掉 answer 码
function rtcTakeAnswer(code) {
  if (!RTC.pc) return Promise.reject(new Error('还没有生成连接码'));
  return RTC.pc.setRemoteDescription({ type: 'answer', sdp: rtcB64Decode(code) });
}

function rtcClose() {
  try { if (RTC.dc) RTC.dc.close(); } catch (e) {}
  try { if (RTC.pc) RTC.pc.close(); } catch (e) {}
  RTC.pc = null; RTC.dc = null; RTC.mode = null;
}
