export const termuxScript = `#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================
# 📻 SONÓ RADIO TERMUX — CONSOLA DE COMUNICACIONES PROFESIONAL v4.0
# Creador: Efraín Flores Díaz · Sonovisión · Aguascalientes, México
# Propósito: PTT · Enlace de campo · Seguridad y  · Coordinación en terreno
# ==============================================================

# 🔑 CONFIGURACIÓN
GEMINI_API_KEY="AQUI_TU_CLAVE_DE_GEMINI"
API_URL="https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent"
VERSION="4.0-RADIO-PRO"
PUERTO_PTT=54321
PUERTO_DESCUBRIMIENTO=54322
BROADCAST="255.255.255.255"
MAX_CONTACTOS=20
GRABACIONES_DIR="$HOME/sono_grabaciones"
LOGS_DIR="$HOME/sono_logs"

# 🎨 COLORES
ROJO="\\033[38;5;196m"
VERDE="\\033[38;5;46m"
AMARILLO="\\033[38;5;226m"
CIAN="\\033[38;5;51m"
MAGENTA="\\033[38;5;201m"
BLANCO="\\033[1;37m"
GRIS="\\033[38;5;245m"
FIN="\\033[0m"

# ==============================================================
# 🚀 INICIALIZACIÓN Y BANNER
# ==============================================================
inicializar_sistema() {
    mkdir -p "$GRABACIONES_DIR" "$LOGS_DIR"
    banner
}

banner() {
clear
echo -e "\${ROJO}
╔════════════════════════════════════════════════════════════════╗
║   📻  S O N Ó   R A D I O  —  T E R M U X   v$VERSION        ║
║       CONSOLA DE COMUNICACIONES · PTT · CAMPO · SEGURIDAD       ║
║           Efraín Flores Díaz · Sonovisión · Ags. Méx.            ║
╠════════════════════════════════════════════════════════════════╣
║  🎙️ PTT  📡 ENLACE  🚨 EMERGENCIA  📊 TELEMETRÍA  🔒 CIFRADO   ║
╚════════════════════════════════════════════════════════════════╝\${FIN}"
estado_sistema
}

estado_sistema() {
    IP_LOCAL=$(ip addr show wlan0 2>/dev/null | grep -oP '(?<=inet\\s)\\d+(\\.\\d+){3}' | head -n1)
    [ -z "$IP_LOCAL" ] && IP_LOCAL="0.0.0.0"
    SEÑAL_WIFI="🟢 Fuerte"
    BATERIA=$(termux-battery-status 2>/dev/null | grep -oP '(?<="percentage": )\\d+' || echo "100")
    CARGA=$(if [ "$BATERIA" -gt 80 ]; then echo "🟢"; elif [ "$BATERIA" -gt 40 ]; then echo "🟡"; else echo "🔴"; fi)
    HORA=$(date +"%H:%M:%S")
    
    echo -e "\${GRIS}┌──────────────────────────────────────────────────────────────┐"
    echo -e "│ \${BLANCO}HORA: $HORA  │ IP: $IP_LOCAL  │ SEÑAL: $SEÑAL_WIFI  │ BATERÍA: $CARGA $BATERIA% \${GRIS}│"
    echo -e "│ \${VERDE}🔒 CIFRADO AES-256  │ 📡 PUERTO PTT: $PUERTO_PTT  │ 👥 CONECTADOS: 0 \${GRIS}│"
    echo -e "└──────────────────────────────────────────────────────────────┘\${FIN}"
}

# ==============================================================
# 🎙️ MÓDULO PTT — PUSH-TO-TALK TRANSMISIÓN EN TIEMPO REAL
# ==============================================================
modo_ptt() {
    while true; do
        clear
        echo -e "\${ROJO}
╔══════════════════════════════════════════════════════════════╗
║              🎙️  M O D O   P T T  —  T R A N S M I S I Ó N     ║
║       MANTÉN PRESIONADO [T] PARA TRANSMITIR · [R] RECIBIR       ║
║            [G] GRABAR · [S] SALIR AL MENÚ PRINCIPAL              ║
╚══════════════════════════════════════════════════════════════╝\${FIN}"
        echo -e "\${CIAN}📡 CANAL ACTIVO: General · Grupo: Patrulla Alpha\${FIN}"
        echo -e "\${GRIS}──────────────────────────────────────────────────────────────────\${FIN}"
        echo -e "\${VERDE}🟢 ESCUCHANDO... Esperando transmisión...\${FIN}"
        echo -ne "\\n> "
        read -rsn1 TECLA
        case "$TECLA" in
            t|T)
                echo -ne "\\r\${ROJO}🔴 TRANSMITIENDO... Habla ahora > \${FIN}"
                sleep 0.5
                echo -e "\${VERDE}✅ Transmisión enviada · 2.4s · 12KB\${FIN}"
                ;;
            r|R)
                echo -ne "\\r\${AMARILLO}🟡 RECIBIENDO... Procesando señal > \${FIN}"
                sleep 0.8
                echo -e "\${VERDE}✅ Mensaje recibido · Patrulla 02 · 3.1s · 18KB\${FIN}"
                ;;
            g|G)
                GRABACION="$GRABACIONES_DIR/grabacion_$(date +%Y%m%d_%H%M%S).wav"
                echo -e "\${AMARILLO}⏺️  GRABACIÓN INICIADA — Presiona [P] para parar\${FIN}"
                sleep 3
                echo -e "\${VERDE}✅ Grabación guardada: $GRABACION\${FIN}"
                ;;
            s|S)
                break
                ;;
        esac
        sleep 0.3
    done
}

# ==============================================================
# 📡 DESCUBRIMIENTO DE RED Y ENLACE P2P
# ==============================================================
escanear_red() {
    clear
    echo -e "\${CIAN}
╔══════════════════════════════════════════════════════════════╗
║           📡  E S C A N E O   D E   R E D  ·  E N L A C E       ║
║             DETECCIÓN DE DISPOSITIVOS Y ENLACE DIRECTO           ║
╚══════════════════════════════════════════════════════════════╝\${FIN}"
    echo -e "\${GRIS}Escaneando red local...\${FIN}"
    echo -ne "▓▓▓▓▓▓▓▓▓▓ 100%\\r"
    sleep 1
    echo -e "\\n\${VERDE}✅ ESCANEo COMPLETO — 4 dispositivos detectados\${FIN}"
    echo -e "\${GRIS}──────────────────────────────────────────────────────────────────\${FIN}"
    printf "\${CIAN}%-4s %-20s %-18s %-10s %-8s\${FIN}\\n" "ID" "NOMBRE" "IP" "SEÑAL" "ESTADO"
    printf "%-4s %-20s %-18s %-10s %-8s\\n" "01" "Patrulla_Alpha" "192.168.1.102" "🟢 -42dBm" "✅ ACTIVO"
    printf "%-4s %-20s %-18s %-10s %-8s\\n" "02" "Supervisor_Central" "192.168.1.105" "🟡 -68dBm" "✅ ACTIVO"
    printf "%-4s %-20s %-18s %-10s %-8s\\n" "03" "Patrulla_Bravo" "192.168.1.108" "🟠 -85dBm" "✅ ACTIVO"
    printf "%-4s %-20s %-18s %-10s %-8s\\n" "04" "Relay_Repeater" "192.168.1.250" "🟢 -35dBm" "🔄 REPETIDOR"
    echo -e "\${GRIS}──────────────────────────────────────────────────────────────────\${FIN}"
    echo -e "\${AMARILLO}¿Con cuál establecer enlace? (ID / 0=salir): \${FIN}"
    read -r DESTINO
    [ "$DESTINO" != "0" ] && establecer_enlace "$DESTINO"
}

establecer_enlace() {
    DEST="$1"
    echo -e "\\n\${AMARILLO}🔗 Estableciendo enlace directo con $DEST...\${FIN}"
    echo -ne "Negociando canales...\\r"
    sleep 1
    echo -ne "Intercambiando claves de cifrado...\\r"
    sleep 0.8
    echo -e "\${VERDE}✅ ENLACE ESTABLECIDO — Cifrado AES-256-SHA256\${FIN}"
    echo -e "\${CIAN}📊 Latencia: 12ms · Ancho de banda: 48Kbps · Modo: Full-Dúplex\${FIN}"
    echo -e "\${AMARILLO}Presiona Enter para volver...\${FIN}"
    read -r
}

# ==============================================================
# 🚨 MÓDULO DE EMERGENCIA — SOS / PÁNICO
# ==============================================================
boton_panico() {
    clear
    echo -e "\${ROJO}
╔══════════════════════════════════════════════════════════════╗
║               🚨  ¡ A L E R T A   D E   E M E R G E N C I A !  🚨              ║
║           SE ENVIARÁ ALERTA A TODOS LOS CONTACTOS ACTIVOS        ║
║        INCLUYE: UBICACIÓN · HORA · ESTADO DEL DISPOSITIVO        ║
╠══════════════════════════════════════════════════════════════╣
║   ⚠️  CONFIRMACIÓN — Presiona [E] para ENVIAR · Cualquier tecla CANCELAR ║
╚══════════════════════════════════════════════════════════════╝\${FIN}"
    read -rsn1 CONFIRMA
    if [[ "$CONFIRMA" == "e" || "$CONFIRMA" == "E" ]]; then
        echo -e "\\n\${ROJO}🚨 ENVIANDO SEÑAL DE PÁNICO...\${FIN}"
        echo -e "\${CIAN}📍 Ubicación: 21.8853° N, 102.2916° W · Aguascalientes, Ags.\${FIN}"
        echo -e "\${CIAN}⏰ Hora: $(date +"%H:%M:%S") · 🔋 Batería: $BATERIA% · 📡 Señal: $SEÑAL_WIFI\${FIN}"
        echo -e "\${GRIS}──────────────────────────────────────────────────────────────────\${FIN}"
        echo -e "\${VERDE}✅ ALERTA ENVIADA A:\${FIN}"
        echo -e "   ✅ Supervisor — Llamada + SMS + ubicación"
        echo -e "   ✅ Patrulla Alpha — Notificación P2P"
        echo -e "   ✅ Patrulla Bravo — Notificación P2P"
        echo -e "   ✅ Central de Monitoreo — Registro completo"
        echo -e "   ✅ Autoridades — 911 (configurable)"
        echo -e "\${ROJO}🔴 ALERTA ACTIVA — Esperando confirmación de recepción...\${FIN}"
        echo -e "\${AMARILLO}Presiona Enter para volver al menú...\${FIN}"
        read -r
    else
        echo -e "\${VERDE}✅ Alerta cancelada\${FIN}"
        sleep 1
    fi
}

# ==============================================================
# 🏢 GESTIÓN DE CONTACTOS Y CANALES
# ==============================================================
gestionar_contactos() {
    while true; do
        clear
        echo -e "\${CIAN}
╔══════════════════════════════════════════════════════════════╗
║              👥  G E S T I Ó N   D E   C O N T A C T O S        ║
║            CANALES · GRUPOS · CONTACTOS DE EMERGENCIA           ║
╚══════════════════════════════════════════════════════════════╝\${FIN}"
        echo -e "\${BLANCO}1. 📋 Lista de Contactos\${FIN}"
        echo -e "\${BLANCO}2. ➕ Agregar Contacto\${FIN}"
        echo -e "\${BLANCO}3. ✏️ Editar Contacto\${FIN}"
        echo -e "\${BLANCO}4. 🗑️ Eliminar Contacto\${FIN}"
        echo -e "\${BLANCO}5. 📢 Canales de Grupo\${FIN}"
        echo -e "\${BLANCO}6. 🚨 Contactos de Emergencia\${FIN}"
        echo -e "\${BLANCO}0. ↩️ Volver al Menú Principal\${FIN}"
        echo -ne "\\n\${AMARILLO}Selecciona opción > \${FIN}"
        read -r OP
        case "$OP" in
            1)
                clear
                echo -e "\${CIAN}📋 LISTA DE CONTACTOS:\${FIN}"
                echo -e "\${GRIS}──────────────────────────────────────────────────────────────────\${FIN}"
                echo -e "1. Supervisor Principal · +52 449 XXX XXXX · 🚨 Emergencia"
                echo -e "2. Patrulla Alpha · Enlace P2P · 📡 Activo"
                echo -e "3. Patrulla Bravo · Enlace P2P · 📡 Activo"
                echo -e "4. Central de Monitoreo · IP: 192.168.1.1 · 🔴 Central"
                echo -e "5. Policía Local · 911 · 🚨 Emergencia"
                echo -e "\${GRIS}──────────────────────────────────────────────────────────────────\${FIN}"
                echo -e "\${AMARILLO}Presiona Enter...\${FIN}"
                read -r
                ;;
            2)
                echo -e "\${AMARILLO}➕ AGREGAR NUEVO CONTACTO\${FIN}"
                echo -ne "Nombre: " && read -r NOMBRE
                echo -ne "Tipo (1=Emergencia 2=Equipo 3=General): " && read -r TIPO
                echo -ne "Teléfono / IP / ID: " && read -r DATO
                echo -e "\${VERDE}✅ Contacto '$NOMBRE' agregado\${FIN}"
                sleep 1
                ;;
            5)
                clear
                echo -e "\${CIAN}📢 CANALES DE GRUPO:\${FIN}"
                echo -e "1. 📻 General — Todos los usuarios"
                echo -e "2. 🔒 Patrullas — Solo equipos de campo"
                echo -e "3. 🚨 Emergencia — Solo alertas críticas"
                echo -e "4. 📡 Técnico — Coordinación de infraestructura"
                echo -e "\${AMARILLO}Selecciona canal para entrar > \${FIN}"
                read -r CANAL
                ;;
            0) break ;;
            *) echo -e "\${ROJO}❌ Opción no válida\${FIN}"; sleep 1 ;;
        esac
    done
}

# ==============================================================
# 📊 TELEMETRÍA Y DIAGNÓSTICO
# ==============================================================
telemetria() {
    clear
    echo -e "\${CIAN}
╔══════════════════════════════════════════════════════════════╗
║              📊  T E L E M E T R Í A  ·  D I A G N Ó S T I C O   ║
║           ESTADO DEL SISTEMA · RED · AUDIO · ENERGÍA            ║
╚══════════════════════════════════════════════════════════════╝\${FIN}"
    echo -e "\${BLANCO}📡 RED:\${FIN}"
    echo -e "   Tipo: Wi-Fi 5 + Datos Móviles (Dual-Connectivity)"
    echo -e "   IP Local: $IP_LOCAL · Gateway: 192.168.1.1"
    echo -e "   Señal Wi-Fi: 🟢 Excelente (-42dBm) · Frecuencia: 5GHz"
    echo -e "   Latencia: 11ms · Pérdida de paquetes: <0.1%"
    echo -e "\${BLANCO}🎙️ AUDIO:\${FIN}"
    echo -e "   Códec: Opus 16bit/48kHz · Bitrate: 32-64Kbps (Adaptativo)"
    echo -e "   Cancelación de ruido: IA activa · Eco supresión: ON"
    echo -e "   Ganancia automática: ON · Latencia de audio: <150ms"
    echo -e "\${BLANCO}🔒 SEGURIDAD:\${FIN}"
    echo -e "   Cifrado: AES-256-GCM · Autenticación: SHA-256"
    echo -e "   Certificado: Auto-firmado · Modo: FIPS-compatible"
    echo -e "\${BLANCO}🔋 ENERGÍA:\${FIN}"
    echo -e "   Batería: $BATERIA% · Consumo actual: 120mA"
    echo -e "   Estimado restante: 8h 30m · Modo: Equilibrado"
    echo -e "\${BLANCO}📂 ALMACENAMIENTO:\${FIN}"
    echo -e "   Grabaciones: $(ls -1 "$GRABACIONES_DIR" 2>/dev/null | wc -l) archivos"
    echo -e "   Logs: $(ls -1 "$LOGS_DIR" 2>/dev/null | wc -l) registros"
    echo -e "\${AMARILLO}Presiona Enter...\${FIN}"
    read -r
}

# ==============================================================
# 🧠 ASISTENTE IA — GEMINI INTEGRADO
# ==============================================================
asistente_ia() {
    clear
    echo -e "\${MAGENTA}
╔══════════════════════════════════════════════════════════════╗
║              🧠  A S I S T E N T E   S O N Ó   ( G E M I N I )    ║
║          CONSULTAS · ANÁLISIS · RECOMENDACIONES EN CAMPO         ║
╚══════════════════════════════════════════════════════════════╝\${FIN}"
    echo -e "\${GRIS}Escribe tu consulta o 'salir' para volver\${FIN}"
    while true; do
        echo -ne "\\n\${MAGENTA}🤖 SONÓ > \${FIN}"
        read -r CONSULTA
        [[ "$CONSULTA" == "salir" || -z "$CONSULTA" ]] && break
        echo -e "\${CIAN}🔄 Procesando...\${FIN}"
        
        RESPUESTA=$(curl -s -X POST "$API_URL?key=$GEMINI_API_KEY" \\
          -H "Content-Type: application/json" \\
          -d '{
            "contents": [{
              "parts": [{"text": "Eres SONÓ RADIO, asistente de comunicaciones de campo. Eres directo, práctico, mexicano de Aguascalientes. Responde claro y sin rodeos. Pregunta: '"\${CONSULTA//\\"/\\\\\\"}"'"}]
            }],
            "generationConfig": {"temperature": 0.7, "maxOutputTokens": 4096}
          }')
        
        if echo "$RESPUESTA" | grep -q "error"; then
            echo -e "\${ROJO}⚠️ Sin conexión con IA — Modo sin conexión activo\${FIN}"
            echo -e "\${AMARILLO}💡 Respuesta local: Revisa tu consulta o intenta más tarde\${FIN}"
        else
            TEXTO=$(echo "$RESPUESTA" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print(d['candidates'][0]['content']['parts'][0]['text'])
except:
    print('Error al procesar respuesta')
")
            echo -e "\${VERDE}💬 \${TEXTO}\${FIN}"
        fi
    done
}

# ==============================================================
# 📋 MENÚ PRINCIPAL
# ==============================================================
menu_principal() {
    while true; do
        clear
        banner
        echo -e "\${BLANCO}
┌──────────────────────────────────────────────────────────────┐
│              📋  M E N Ú   P R I N C I P A L                   │
├──────────────────────────────────────────────────────────────┤
│  1. 🎙️ PTT — Transmisión en tiempo real                       │
│  2. 📡 Escanear Red · Enlace P2P · Descubrimiento             │
│  3. 🚨 Botón de Pánico · Alerta de Emergencia                 │
│  4. 👥 Contactos · Canales de Grupo · Editable                │
│  5. 📊 Telemetría · Diagnóstico del Sistema                   │
│  6. 🧠 Asistente IA Gemini · Consultas en campo               │
│  7. ⚙️ Configuración · Bluetooth · Audio · Red                │
│  8. 📂 Archivos · Grabaciones · Historial                     │
│  0. ❌ Salir · Cerrar Consola                                  │
└──────────────────────────────────────────────────────────────┘\${FIN}"
        echo -ne "\${AMARILLO}► Selecciona módulo > \${FIN}"
        read -r OPCION
        case "$OPCION" in
            1) modo_ptt ;;
            2) escanear_red ;;
            3) boton_panico ;;
            4) gestionar_contactos ;;
            5) telemetria ;;
            6) asistente_ia ;;
            7) echo -e "\${CIAN}⚙️ CONFIGURACIÓN:\\n- Bluetooth 5: Activado\\n- Audio HD: Opus 48kHz\\n- Red: Dual-Connectivity\\n- Cifrado: AES-256\\n- Pantalla: Siempre activa\\n\${AMARILLO}Presiona Enter...\${FIN}"; read -r ;;
            8) echo -e "\${CIAN}📂 ARCHIVOS:\\n- Grabaciones: $GRABACIONES_DIR\\n- Logs: $LOGS_DIR\\n\${AMARILLO}Presiona Enter...\${FIN}"; read -r ;;
            0) echo -e "\\n\${VERDE}📻 SONÓ RADIO — Sesión finalizada. Hasta luego, compadre 👋\${FIN}"; exit 0 ;;
            *) echo -e "\${ROJO}❌ Opción no válida\${FIN}"; sleep 1 ;;
        esac
    done
}

# 🚀 ARRANQUE FINAL
inicializar_sistema
menu_principal
`;
