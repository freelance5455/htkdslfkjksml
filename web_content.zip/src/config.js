// 全局常量与数据表
const W = 1280, H = 720;
const GROUND_Y = 620;
const GRAVITY = 2880;
const MAX_ENERGY = 100;
const ROUND_TIME = 90;

const CHARS = {
  huangyi: {
    key: 'huangyi', name: '黄衣哥', dir: '黄衣哥',
    hp: 750, speed: 572, jumpV: 1126, gravity: true,
    w: 46, h: 118, drawH: 170,
    atkCd: 0.36, dmg: 33,
    hasAttack: true, hasJump: true, hasSkill: true,
    skillName: '旋风', color: '#f3c30b',
    desc: '近战，容错高，贴身压人'
  },
  xizhuang: {
    key: 'xizhuang', name: '西装哥', dir: '西装哥',
    hp: 675, speed: 616, jumpV: 1140, gravity: true,
    w: 46, h: 118, drawH: 170,
    atkCd: 0.18, dmg: 4, skillDmg: 5,
    hasAttack: true, hasJump: true, hasSkill: true,
    skillName: '九连翻牌', color: '#e9e9f2',
    desc: '高速直线弹幕，靠射速蹭血'
  },
  tangyi: {
    key: 'tangyi', name: '躺椅哥', dir: '躺椅哥',
    hp: 700, speed: 660, jumpV: 0, gravity: false,
    w: 80, h: 88, drawH: 150,
    atkCd: 1.0, dmg: 12,
    hasAttack: true, hasJump: false, hasSkill: true,
    skillName: '大蝌蚪', color: '#8fd3ff',
    desc: '全向浮空，蝌蚪必中但慢'
  },
  jianzi: {
    key: 'jianzi', name: '剪刀手', dir: '剪刀手哥',
    hp: 675, speed: 584, jumpV: 0, gravity: true,
    w: 46, h: 118, drawH: 170,
    atkCd: 0.12, dmg: 9, recoil: 1126,
    ammoMax: 6, ammoRegen: 1.0,
    hasAttack: true, hasJump: false, hasSkill: true,
    skillName: '拉稀', color: '#b9e08d',
    desc: '弹药反向弹射，靠屎上天'
  },
  datou: {
    key: 'datou', name: '大头哥', dir: '大头哥',
    hp: 625, speed: 1012, jumpV: 1350, gravity: true,
    w: 46, h: 46, drawH: 80,
    atkCd: 0, dmg: 6, headEvery: 2.2,
    hasAttack: false, hasJump: true, hasSkill: false,
    skillName: '自动头', color: '#ffb3c1',
    desc: '高机动，只跑不打，靠自动头拖时间'
  }
};

// 地图：8 张。所有小平台都是单向平台（从下面能穿上去），只有标了 solid 的才挡移动
const MAPS = [
  {
    id: 'classroom', name: '教室', sky: ['#242c46', '#0d1220'], floor: '#39405a', accent: '#7783ad',
    desc: '两张课桌平台，高低错落、挡子弹',
    platforms: [
      { x: 0, y: 620, w: 1280, h: 100, ground: true },
      { x: 210, y: 490, w: 230, h: 22 },
      { x: 840, y: 490, w: 230, h: 22 },
      { x: 520, y: 360, w: 240, h: 22 }
    ]
  },
  {
    id: 'roof', name: '天台', sky: ['#3d4c74', '#141a2b'], floor: '#4a5163', accent: '#8ea3c9',
    desc: '中间缺口，掉下去扣血；周期横风',
    platforms: [
      { x: 0, y: 620, w: 530, h: 100, ground: true },
      { x: 750, y: 620, w: 530, h: 100, ground: true }
    ],
    wind: { interval: 6, duration: 1.6, force: 260 }
  },
  {
    id: 'playground', name: '操场', sky: ['#2d4a63', '#101a26'], floor: '#3f5a4a', accent: '#7fbf8f',
    desc: '中央旗杆挡路，两侧弹床',
    platforms: [
      { x: 0, y: 620, w: 1280, h: 100, ground: true },
      { x: 635, y: 200, w: 26, h: 270, solid: true },
      { x: 150, y: 600, w: 180, h: 20, tramp: true },
      { x: 950, y: 600, w: 180, h: 20, tramp: true }
    ]
  },
  {
    id: 'site', name: '工地', sky: ['#4a3a2a', '#1a1410'], floor: '#4d4234', accent: '#c8a05a',
    desc: '两台升降平台反向上下，可站',
    platforms: [
      { x: 0, y: 620, w: 1280, h: 100, ground: true }
    ],
    moving: [
      { x: 220, y: 300, w: 200, h: 22, from: 330, to: 540, period: 4, phase: 0 },
      { x: 860, y: 300, w: 200, h: 22, from: 330, to: 540, period: 4, phase: 0.5 }
    ]
  },
  {
    id: 'lab', name: '实验室', sky: ['#2a2145', '#0c0818'], floor: '#3a3157', accent: '#b48cff',
    desc: '六个传送门，三对互通',
    platforms: [
      { x: 0, y: 620, w: 1280, h: 100, ground: true },
      { x: 250, y: 430, w: 150, h: 20 },
      { x: 880, y: 430, w: 150, h: 20 }
    ],
    portals: [
      { x: 80, y: 470, w: 70, h: 150 },
      { x: 1130, y: 470, w: 70, h: 150 },
      { x: 290, y: 280, w: 70, h: 130 },
      { x: 920, y: 280, w: 70, h: 130 },
      { x: 555, y: 460, w: 70, h: 160 },
      { x: 655, y: 460, w: 70, h: 160 }
    ]
  },
  {
    id: 'canteen', name: '食堂', sky: ['#3a3320', '#151208'], floor: '#4a3f2a', accent: '#e0c274',
    desc: '长桌平台，中间有米饭回血点',
    platforms: [
      { x: 0, y: 620, w: 1280, h: 100, ground: true },
      { x: 310, y: 500, w: 660, h: 22 }
    ],
    heal: { x: 640, y: 470, amount: 15, respawn: 25 }
  },
  {
    id: 'dorm', name: '宿舍', sky: ['#2c2a3d', '#12101a'], floor: '#3d3a52', accent: '#9b8fd6',
    desc: '上下铺平台，吊扇周期下压',
    platforms: [
      { x: 0, y: 620, w: 1280, h: 100, ground: true },
      { x: 150, y: 450, w: 300, h: 20 },
      { x: 830, y: 450, w: 300, h: 20 }
    ],
    fan: { x: 640, y: 60, interval: 7, duration: 1.6, force: 1400 }
  },
  {
    id: 'ice', name: '冰场', sky: ['#1c3a44', '#07131a'], floor: '#8fd8e8', accent: '#d7f6ff',
    desc: '地面打滑，刹车很慢',
    platforms: [
      { x: 0, y: 620, w: 1280, h: 100, ground: true },
      { x: 0, y: 0, w: 30, h: 720, solid: true },
      { x: 1250, y: 0, w: 30, h: 720, solid: true }
    ],
    ice: true
  }
];
