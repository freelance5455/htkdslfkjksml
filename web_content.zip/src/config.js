export const GAME = Object.freeze({ title: 'Championnat Galactique de Dames', version: 'CGD — édition galactique' });
export const DIVISIONS = Object.freeze([
  { id: 'super-league', name: 'Super League', rank: 1, initial: true, clubs: 12 },
  { id: 'ligue-a', name: 'Ligue A', rank: 2, initial: true, clubs: 12 },
  { id: 'ligue-b', name: 'Ligue B', rank: 3, initial: true, clubs: 12 },
  { id: 'ligue-c', name: 'Ligue C', rank: 4, initial: false, clubs: 12, activationSeason: 3 },
  { id: 'ligue-d', name: 'Ligue D', rank: 5, initial: false, clubs: 12, activationSeason: 5 }
]);
// Les sept compétitions historiques restent distinctes ; la Coupe Fédéral est ajoutée comme huitième compétition.
// Les moteurs validés sont déclarés prêts ; les autres restent explicitement à intégrer.
export const COMPETITIONS = Object.freeze([
  { id: 'coupe-galactique', name: 'Coupe Galactique', authority: 'FGD', calendarEngineReady: true, status: 'active-knockout-16' },
  { id: 'coupe-des-clubs', name: 'Coupe des Clubs', authority: 'FGD', calendarEngineReady: true, status: 'active-knockout-all-clubs' },
  { id: 'champions-league', name: 'Champions League', authority: 'FGD', calendarEngineReady: true, status: 'active-groups-then-knockout' },
  { id: 'intergalactique-clubs', name: 'Intergalactique des Clubs', authority: 'AGD', calendarEngineReady: true, status: 'active-groups-knockout-32-sexennial' },
  { id: 'intergalactique', name: 'Coupe Intergalactique des galaxies', authority: 'AGD', calendarEngineReady: true, status: 'active-groups-knockout-24-sexennial' },
  { id: 'coupe-lunaire', name: 'Coupe Lunaire', authority: 'AGD', calendarEngineReady: true, status: 'active-galaxy-groups-knockout-16' },
  { id: 'dame-or', name: 'Dame d’Or', authority: 'FGD avec la collaboration de l’AGD', calendarEngineReady: true, status: 'individual-season-ranking' },
  { id: 'coupe-federal', name: 'Coupe Fédéral', authority: 'AGD', calendarEngineReady: true, status: 'active-knockout-32' }
]);
export const STORAGE_KEY = 'cgd-v117-career';
