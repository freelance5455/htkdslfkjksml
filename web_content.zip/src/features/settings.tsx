import { useEffect, useState } from "react";
import { ArrowDown, ArrowUp } from "lucide-react";
import { Button, Field, Notice, PageHeader, Panel } from "@/components/ui";
import { exportBackup, parseBackup } from "@/lib/backup";
import { stopClicker } from "@/lib/clicker-runtime";
import {
  ACCENTS,
  BACKGROUNDS,
  DENSITIES,
  MOTIONS,
  NEEDS_NATIVE,
  THEMES,
  WIDGETS,
  WORKS_NOW,
  formatBytes,
  presetLabel,
} from "@/lib/model";
import { useAppStore, useRuntime, useSelectedGame } from "@/lib/store";

export function SettingsPage() {
  return (
    <div className="stack">
      <PageHeader
        id="customize"
        kicker="Customize"
        title="Settings"
        subtitle="Appearance, home layout, and the data stored in this browser. No account."
      />
      <Appearance />
      <Widgets />
      <OverlayPreview />
      <DataPanel />
      <InstallPanel />
      <Limits />
    </div>
  );
}

function Appearance() {
  const theme = useAppStore((state) => state.theme);
  const accent = useAppStore((state) => state.accent);
  const background = useAppStore((state) => state.background);
  const density = useAppStore((state) => state.density);
  const motion = useAppStore((state) => state.motion);
  const cardStyle = useAppStore((state) => state.cardStyle);
  const keepAwake = useAppStore((state) => state.keepAwake);
  const setTheme = useAppStore((state) => state.setTheme);
  const setAccent = useAppStore((state) => state.setAccent);
  const setBackground = useAppStore((state) => state.setBackground);
  const setDensity = useAppStore((state) => state.setDensity);
  const setMotion = useAppStore((state) => state.setMotion);
  const setCardStyle = useAppStore((state) => state.setCardStyle);
  const setKeepAwake = useAppStore((state) => state.setKeepAwake);
  const wakeSupported = useWakeSupport();

  return (
    <Panel id="appearance" title="Appearance">
      <div className="stack">
        <Choice label="Theme" value={theme} options={THEMES.map((id) => ({ id, label: id === "system" ? "System" : id === "dark" ? "Dark" : "Light" }))} onChange={setTheme} />
        <Choice label="Background" value={background} options={BACKGROUNDS.map((item) => ({ id: item.id, label: item.label }))} onChange={setBackground} />
        <div>
          <p className="mb-2 text-sm font-semibold">Accent</p>
          <div className="flex flex-wrap gap-2">
            {ACCENTS.map((item) => (
              <button
                key={item.id}
                type="button"
                aria-pressed={accent === item.id}
                onClick={() => setAccent(item.id)}
                className={`min-h-11 rounded-lg px-3 text-sm font-semibold ${accent === item.id ? "bg-primary text-primary-fg" : "bg-surface-2"}`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
        <Choice label="Density" value={density} options={DENSITIES.map((id) => ({ id, label: id === "compact" ? "Compact" : "Comfortable" }))} onChange={setDensity} />
        <Choice label="Animation" value={motion} options={MOTIONS.map((id) => ({ id, label: id === "off" ? "Off" : id === "full" ? "Full" : "Subtle" }))} onChange={setMotion} />
        <Choice
          label="Game cards"
          value={cardStyle}
          options={[
            { id: "poster" as const, label: "Poster" },
            { id: "row" as const, label: "Row" },
          ]}
          onChange={setCardStyle}
        />
        <label className="flex min-h-11 items-start gap-3">
          <input
            type="checkbox"
            className="mt-1 size-5"
            checked={keepAwake}
            disabled={wakeSupported === false}
            onChange={(event) => setKeepAwake(event.target.checked)}
          />
          <span>
            <span className="block text-sm font-semibold">Keep the screen awake during a session</span>
            <span className="block text-sm text-muted">
              {wakeSupported === false
                ? "Not available in this version."
                : "Uses the Screen Wake Lock API only while the session timer is running and this tab is visible."}
            </span>
          </span>
        </label>
      </div>
    </Panel>
  );
}

function Widgets() {
  const widgets = useAppStore((state) => state.widgets);
  const setVisible = useAppStore((state) => state.setWidgetVisible);
  const move = useAppStore((state) => state.moveWidget);
  return (
    <Panel id="widgets" title="Home widgets">
      <ul className="stack">
        {widgets.map((widget, index) => {
          const meta = WIDGETS.find((item) => item.id === widget.id);
          return (
            <li key={widget.id} className="flex items-center gap-2 rounded-lg bg-surface-2 p-2">
              <label className="flex min-h-11 min-w-0 flex-1 items-center gap-3">
                <input type="checkbox" className="size-5" checked={widget.visible} onChange={(event) => setVisible(widget.id, event.target.checked)} />
                <span className="min-w-0">
                  <span className="block text-sm font-semibold">{meta?.label}</span>
                  <span className="block text-xs text-faint">{meta?.detail}</span>
                </span>
              </label>
              <Button variant="ghost" className="px-2" aria-label={`Move ${meta?.label} up`} disabled={index === 0} onClick={() => move(widget.id, -1)}>
                <ArrowUp className="size-4" />
              </Button>
              <Button variant="ghost" className="px-2" aria-label={`Move ${meta?.label} down`} disabled={index === widgets.length - 1} onClick={() => move(widget.id, 1)}>
                <ArrowDown className="size-4" />
              </Button>
            </li>
          );
        })}
      </ul>
    </Panel>
  );
}

function OverlayPreview() {
  const game = useSelectedGame();
  const logs = useAppStore((state) => state.fpsLogs);
  const sample = useAppStore((state) => state.refreshSample);
  const last = logs.find((entry) => (game ? entry.gameId === game.id : true));
  return (
    <Panel id="overlay" title="Performance overlay">
      <p className="mb-3 text-sm font-semibold">Preview only. Not a system overlay.</p>
      <div className="rounded-xl bg-bg p-4 shadow-[var(--shadow-ring)]">
        <p className="text-xs font-semibold tracking-widest text-primary uppercase">Preview</p>
        <p className="mt-2 text-sm text-muted">{game?.name ?? "No profile selected"}</p>
        <dl className="mt-3 grid grid-cols-3 gap-2 text-center">
          <div>
            <dt className="text-xs text-faint">Target</dt>
            <dd className="font-display text-2xl font-semibold tabular-nums">{game ? game.fpsTarget : "—"}</dd>
          </div>
          <div>
            <dt className="text-xs text-faint">Measured</dt>
            <dd className="font-display text-2xl font-semibold tabular-nums">{last ? last.measuredFps : "—"}</dd>
          </div>
          <div>
            <dt className="text-xs text-faint">Refresh</dt>
            <dd className="font-display text-2xl font-semibold tabular-nums">{sample ? sample.displayHz : "—"}</dd>
          </div>
        </dl>
        <p className="mt-3 text-xs text-faint">
          {game ? `${presetLabel(game.preset)} preset saved on the profile.` : "Select a profile to fill the target."}{" "}
          {last ? "Measured value is your last manual log." : "No manual FPS log yet."} Frame generation unavailable in this version.
        </p>
      </div>
      <p className="mt-3 text-sm text-muted">A real overlay on top of other apps needs a native Android implementation. This mockup never leaves this page.</p>
    </Panel>
  );
}

function DataPanel() {
  const storageMode = useRuntime((state) => state.storageMode);
  const replaceState = useAppStore((state) => state.replaceState);
  const restoreDefaults = useAppStore((state) => state.restoreDefaults);
  const resetAll = useAppStore((state) => state.resetAll);
  const [bytes, setBytes] = useState<number | null>(null);
  useEffect(() => {
    const update = () => {
      const state = useAppStore.getState();
      const payload = exportBackup({
        theme: state.theme,
        accent: state.accent,
        background: state.background,
        density: state.density,
        motion: state.motion,
        cardStyle: state.cardStyle,
        keepAwake: state.keepAwake,
        widgets: state.widgets,
        selectedGameId: state.selectedGameId,
        games: state.games,
        session: state.session,
        fpsLogs: state.fpsLogs,
        compares: state.compares,
        notes: state.notes,
        clicker: state.clicker,
        clickPresets: state.clickPresets,
        refreshSample: state.refreshSample,
        thermal: state.thermal,
        tutorialsSeen: state.tutorialsSeen,
      });
      setBytes(new Blob([JSON.stringify(payload)]).size);
    };
    update();
    return useAppStore.subscribe(update);
  }, []);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [confirmImport, setConfirmImport] = useState(false);
  const [confirmDefaults, setConfirmDefaults] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  function download() {
    const payload = exportBackup(useAppStore.getState());
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "frameforge-booyah.json";
    link.click();
    URL.revokeObjectURL(url);
    setError(null);
    setMessage("Backup file downloaded. It stays on this device unless you share it.");
  }

  async function applyImport() {
    if (!pendingFile) return;
    if (pendingFile.size > 1_500_000) {
      setError("That file is too large to import.");
      return;
    }
    try {
      const text = await pendingFile.text();
      const parsed = parseBackup(JSON.parse(text) as unknown);
      if (!parsed.ok) {
        setError(parsed.error);
        setMessage(null);
        return;
      }
      stopClicker("Stopped because a backup was imported.");
      replaceState(parsed.data);
      setMessage("Backup imported on this device. Previous data in this browser was replaced.");
      setError(null);
      setPendingFile(null);
      setConfirmImport(false);
    } catch {
      setError("Could not read that JSON file.");
      setMessage(null);
    }
  }

  return (
    <Panel id="data" title="Data">
      <div className="stack">
        <p className="text-sm text-muted">
          Profiles, logs, presets, and appearance are stored in this browser with localStorage. Nothing is uploaded, and basic use does not need an account. Clearing site data in the browser, or Reset all data below, removes it. A private tab may drop it when the tab closes.
        </p>
        <p className="text-sm text-muted">
          Storage status: {storageMode === "local" ? "saving on this device" : storageMode === "memory" ? "memory only for this tab" : storageMode === "unreadable" ? "saved data could not be read" : "checking"}
          . Current backup size about {bytes == null ? "…" : formatBytes(bytes)}.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button onClick={download}>Export JSON</Button>
          <label className="inline-flex min-h-11 items-center rounded-lg bg-surface-2 px-4 text-sm font-semibold">
            Choose backup
            <input
              className="sr-only"
              type="file"
              accept="application/json,.json"
              onChange={(event) => {
                setPendingFile(event.target.files?.[0] ?? null);
                setConfirmImport(false);
                setError(null);
                event.target.value = "";
              }}
            />
          </label>
        </div>
        {pendingFile ? <p className="text-sm">Selected {pendingFile.name}</p> : null}
        {pendingFile && !confirmImport ? (
          <Button variant="quiet" onClick={() => setConfirmImport(true)}>
            Import and replace saved data
          </Button>
        ) : null}
        {confirmImport ? (
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => void applyImport()}>Replace saved data</Button>
            <Button variant="quiet" onClick={() => setConfirmImport(false)}>
              Cancel
            </Button>
          </div>
        ) : null}
        {confirmDefaults ? (
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={() => {
                restoreDefaults();
                setConfirmDefaults(false);
                setMessage("Appearance, widgets, and the clicker setup were restored. Games and logs were kept.");
              }}
            >
              Confirm restore
            </Button>
            <Button variant="quiet" onClick={() => setConfirmDefaults(false)}>
              Cancel
            </Button>
          </div>
        ) : (
          <Button variant="quiet" onClick={() => setConfirmDefaults(true)}>
            Restore defaults
          </Button>
        )}
        {confirmReset ? (
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={() => {
                stopClicker("Stopped because data was reset.");
                resetAll();
                setConfirmReset(false);
                setMessage("All FrameForge data in this browser was reset.");
              }}
            >
              Confirm reset all data
            </Button>
            <Button variant="quiet" onClick={() => setConfirmReset(false)}>
              Cancel
            </Button>
          </div>
        ) : (
          <Button variant="quiet" onClick={() => setConfirmReset(true)}>
            Reset all data
          </Button>
        )}
        {message ? <Notice tone="ok">{message}</Notice> : null}
        {error ? <Notice tone="warn">{error}</Notice> : null}
      </div>
    </Panel>
  );
}

function InstallPanel() {
  const [standalone, setStandalone] = useState<boolean | null>(null);
  useEffect(() => {
    setStandalone(window.matchMedia("(display-mode: standalone)").matches);
  }, []);

  return (
    <Panel id="install" title="Add to the Android home screen">
      <div className="stack text-sm text-muted">
        {standalone ? <p className="font-semibold text-ok">This session is already running from the home screen.</p> : <p>This session is running in a browser tab.</p>}
        <ol className="list-decimal space-y-2 pl-5">
          <li>Publish the app from the Grok builder, then open the public link in Android Chrome.</li>
          <li>Tap the Chrome menu, the three dots.</li>
          <li>Tap Install app or Add to Home screen.</li>
          <li>Confirm. Launch FrameForge from the icon like any other app.</li>
        </ol>
        <p>Samsung Internet has its own menu item for adding a page to the home screen. The preview inside chat may not offer install. Use the published link in the phone's browser.</p>
        <p>This is an installable web app. It is not an Android APK, and it does not need root.</p>
      </div>
    </Panel>
  );
}

function Limits() {
  return (
    <Panel id="limits" title="What this version can do">
      <h3 className="font-display text-base font-semibold">Works now</h3>
      <ul className="mt-2 list-disc space-y-2 pl-5 text-sm text-muted">
        {WORKS_NOW.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
      <h3 className="mt-4 font-display text-base font-semibold">Needs a native Android app</h3>
      <ul className="mt-2 list-disc space-y-2 pl-5 text-sm text-muted">
        {NEEDS_NATIVE.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
      <p className="mt-4 text-sm text-muted">No Steam, no Lossless Scaling, no paid API, no subscription, and no account are required for what this page actually does.</p>
    </Panel>
  );
}

function Choice<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { id: T; label: string }[];
  onChange: (value: T) => void;
}) {
  return (
    <Field label={label}>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <button
            key={option.id}
            type="button"
            aria-pressed={value === option.id}
            onClick={() => onChange(option.id)}
            className={`min-h-11 rounded-lg px-3 text-sm font-semibold capitalize ${value === option.id ? "bg-primary text-primary-fg" : "bg-surface-2"}`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </Field>
  );
}

function useWakeSupport() {
  const [supported, setSupported] = useState<boolean | null>(null);
  useEffect(() => {
    setSupported("wakeLock" in navigator);
  }, []);
  return supported;
}
