import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { CompareTool, FpsLogTool } from "@/components/fps-tools";
import { DevicePanel } from "@/components/device-panel";
import { RefreshMeasure } from "@/components/refresh-measure";
import { SessionClock } from "@/components/session-clock";
import { Button, Field, Notice, PageHeader, Panel } from "@/components/ui";
import { BACKGROUND_TIPS, THERMAL_CHECKS, THERMAL_TIPS, formatWhen } from "@/lib/model";
import { TUTORIALS } from "@/lib/tutorials";
import { useAppStore } from "@/lib/store";

const INDEX = [
  ["stopwatch", "Session stopwatch"],
  ["fps-log", "Manual FPS log"],
  ["refresh-guide", "Refresh-rate guide"],
  ["capabilities", "Device checklist"],
  ["notes", "Settings notes"],
  ["compare", "Comparison log"],
  ["thermal", "Thermal guide"],
  ["tutorials", "Tutorials"],
] as const;

export function ToolsPage() {
  return (
    <div className="stack">
      <PageHeader kicker="Tools" title="Toolkit" subtitle="Each tool records something you enter, measures this page, or explains a limit. None of them invent a benchmark." />
      <nav aria-label="Tools on this page" className="flex flex-wrap gap-2">
        {INDEX.map(([id, label]) => (
          <a key={id} href={`#${id}`} className="inline-flex min-h-11 items-center rounded-lg bg-surface px-3 text-sm font-semibold shadow-[var(--shadow-ring)]">
            {label}
          </a>
        ))}
      </nav>
      <Panel id="stopwatch" title="Session stopwatch">
        <SessionClock />
      </Panel>
      <Panel id="fps-log" title="Manual FPS log">
        <p className="mb-3 text-sm text-muted">Type a frame rate you measured in the game. The chart only plots those rows. The latest 200 are kept.</p>
        <FpsLogTool />
      </Panel>
      <Panel id="refresh-guide" title="Refresh-rate guide">
        <ul className="mb-4 list-disc space-y-2 pl-5 text-sm text-muted">
          <li>Refresh rate is the display. A 60 Hz panel can present about 60 frames each second. A 120 Hz panel can present more, if the phone is actually running at that mode.</li>
          <li>Rendered FPS is how many frames the game produces. A 120 Hz screen does not make a 30 FPS game into 120.</li>
          <li>Interpolated FPS is extra frames created between real ones. Frame generation unavailable in this version.</li>
          <li>The measurement below counts animation frames on this page. Chrome may lower it in the background or in a power-saving mode, so it can read under the panel's hardware maximum.</li>
        </ul>
        <RefreshMeasure />
      </Panel>
      <Panel id="capabilities" title="Device capability checklist">
        <DevicePanel />
      </Panel>
      <Panel id="notes" title="Game settings notes">
        <NotesTool />
      </Panel>
      <Panel id="compare" title="Performance comparison log">
        <p className="mb-3 text-sm text-muted">Record manual runs side by side. This is a log, not an automated benchmark.</p>
        <CompareTool />
      </Panel>
      <Panel id="thermal" title="Thermal management">
        <p className="mb-3 text-sm font-semibold">Temperature: Not available in this version.</p>
        <ul className="list-disc space-y-2 pl-5 text-sm text-muted">
          {THERMAL_TIPS.map((tip) => (
            <li key={tip}>{tip}</li>
          ))}
        </ul>
        <h3 className="mt-4 font-display text-base font-semibold">Also worth doing</h3>
        <ul className="mt-2 list-disc space-y-2 pl-5 text-sm text-muted">
          {BACKGROUND_TIPS.map((tip) => (
            <li key={tip}>{tip}</li>
          ))}
        </ul>
        <ThermalList />
      </Panel>
      <Panel id="tutorials" title="Tutorials">
        <TutorialList />
      </Panel>
      <p className="text-sm text-muted">
        Need the install steps or the native-app limits? They live in <Link to="/settings" hash="limits" className="font-semibold text-primary">Settings</Link>.
      </p>
    </div>
  );
}

function NotesTool() {
  const notes = useAppStore((state) => state.notes);
  const games = useAppStore((state) => state.games);
  const addNote = useAppStore((state) => state.addNote);
  const removeNote = useAppStore((state) => state.removeNote);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [gameId, setGameId] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="stack">
      <Field label="Title" error={error}>
        <input className="field-input" value={title} maxLength={80} onChange={(event) => setTitle(event.target.value)} placeholder="Shadows that stayed stable" />
      </Field>
      <Field label="Note">
        <textarea className="field-input min-h-28" value={body} maxLength={2000} onChange={(event) => setBody(event.target.value)} />
      </Field>
      <Field label="Linked profile">
        <select className="field-input" value={gameId} onChange={(event) => setGameId(event.target.value)}>
          <option value="">No specific game</option>
          {games.map((game) => (
            <option key={game.id} value={game.id}>
              {game.name}
            </option>
          ))}
        </select>
      </Field>
      <Button
        onClick={() => {
          if (!title.trim()) {
            setError("Add a title.");
            return;
          }
          addNote({ title, body, gameId: gameId || null });
          setTitle("");
          setBody("");
          setError(null);
        }}
      >
        Save note
      </Button>
      {notes.length === 0 ? <p className="text-sm text-muted">No notes yet.</p> : null}
      <ul className="divide-y divide-line">
        {notes.map((note) => {
          const game = games.find((item) => item.id === note.gameId);
          return (
            <li key={note.id} className="py-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">{note.title}</p>
                  <p className="text-xs text-faint">{formatWhen(note.at)}{game ? ` · ${game.name}` : ""}</p>
                </div>
                <Button variant="ghost" className="px-2" onClick={() => removeNote(note.id)}>
                  Remove
                </Button>
              </div>
              {note.body ? <p className="mt-2 text-sm text-muted whitespace-pre-wrap">{note.body}</p> : null}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function ThermalList() {
  const thermal = useAppStore((state) => state.thermal);
  const toggle = useAppStore((state) => state.toggleThermal);
  return (
    <fieldset className="mt-4">
      <legend className="text-sm font-semibold">Checklist for this device</legend>
      <p className="mt-1 mb-2 text-sm text-muted">Ticks are reminders you set. They are not sensor readings.</p>
      <ul className="stack">
        {THERMAL_CHECKS.map((item) => (
          <li key={item.id}>
            <label className="flex min-h-11 items-center gap-3 text-sm">
              <input type="checkbox" className="size-5" checked={Boolean(thermal[item.id])} onChange={() => toggle(item.id)} />
              {item.label}
            </label>
          </li>
        ))}
      </ul>
    </fieldset>
  );
}

function TutorialList() {
  const seen = useAppStore((state) => state.tutorialsSeen);
  const mark = useAppStore((state) => state.markTutorial);
  return (
    <div className="stack">
      {TUTORIALS.map((tutorial) => (
        <article key={tutorial.id} className="rounded-lg bg-surface-2 p-3">
          <header className="flex items-start justify-between gap-3">
            <div>
              <h3 className="font-display text-base font-semibold">{tutorial.title}</h3>
              <p className="text-sm text-muted">{tutorial.summary}</p>
            </div>
            {seen[tutorial.id] ? <span className="text-xs font-semibold tracking-widest text-ok uppercase">Read</span> : null}
          </header>
          <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-muted">
            {tutorial.steps.map((step) => (
              <li key={step}>{step}</li>
            ))}
          </ol>
          <Button className="mt-3" variant={seen[tutorial.id] ? "quiet" : "primary"} onClick={() => mark(tutorial.id, !seen[tutorial.id])}>
            {seen[tutorial.id] ? "Mark as unread" : "Mark as read"}
          </Button>
        </article>
      ))}
      <Notice>Marking a tutorial only stores that choice on this device.</Notice>
    </div>
  );
}
