import { useEffect, useState, type ReactNode } from "react";
import { Button, Field, Notice, PageHeader, Panel } from "@/components/ui";
import {
  pauseClicker,
  resumeClicker,
  startClicker,
  stopClicker,
  useClickerRuntime,
  validateClicker,
} from "@/lib/clicker-runtime";
import { uid, type ClickPoint } from "@/lib/model";
import { useAppStore } from "@/lib/store";

export function ClickerPage() {
  const config = useAppStore((state) => state.clicker);
  const presets = useAppStore((state) => state.clickPresets);
  const setClicker = useAppStore((state) => state.setClicker);
  const setPoints = useAppStore((state) => state.setClickerPoints);
  const savePreset = useAppStore((state) => state.saveClickPreset);
  const removePreset = useAppStore((state) => state.removeClickPreset);
  const phase = useClickerRuntime((state) => state.phase);
  const taps = useClickerRuntime((state) => state.taps);
  const cycles = useClickerRuntime((state) => state.cycles);
  const pulse = useClickerRuntime((state) => state.pulse);
  const activePointId = useClickerRuntime((state) => state.activePointId);
  const nextFireAt = useClickerRuntime((state) => state.nextFireAt);
  const error = useClickerRuntime((state) => state.error);
  const lastSummary = useClickerRuntime((state) => state.lastSummary);
  const [presetName, setPresetName] = useState("");
  const [presetError, setPresetError] = useState<string | null>(null);
  const [now, setNow] = useState<number | null>(null);
  const locked = phase !== "stopped";

  useEffect(() => {
    if (!locked || nextFireAt == null) return;
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), 100);
    return () => window.clearInterval(id);
  }, [locked, nextFireAt]);

  const waitMs = nextFireAt != null && now != null ? Math.max(0, nextFireAt - now) : null;
  const validation = validateClicker(config);
  const unlimited = config.repeat === 0 && config.durationSec === 0;

  function place(x: number, y: number) {
    if (locked) return;
    if (config.mode === "single") {
      const current = config.points[0] ?? { id: uid(), label: "Point 1", x: 50, y: 50, delayMs: config.intervalMs };
      setPoints([{ ...current, x, y }]);
      return;
    }
    if (config.points.length >= 12) {
      setPresetError("This sequence is limited to 12 points.");
      return;
    }
    const point: ClickPoint = {
      id: uid(),
      label: `Point ${config.points.length + 1}`,
      x,
      y,
      delayMs: config.intervalMs,
    };
    setPoints([...config.points, point]);
    setPresetError(null);
  }

  function updatePoint(id: string, patch: Partial<ClickPoint>) {
    setPoints(config.points.map((point) => (point.id === id ? { ...point, ...patch } : point)));
  }

  function movePoint(index: number, direction: -1 | 1) {
    const next = index + direction;
    if (next < 0 || next >= config.points.length) return;
    const points = [...config.points];
    const [item] = points.splice(index, 1);
    points.splice(next, 0, item);
    setPoints(points);
  }

  return (
    <div className="stack">
      <PageHeader
        kicker="Practice only"
        title="Auto Clicker"
        subtitle="Taps stay on this pad. Cross-app execution is unavailable. This page will not click other apps, games, ads, or purchases."
      />
      <Panel>
        <p className="text-sm font-semibold">Cross-app execution: unavailable</p>
        <p className="mt-2 text-sm text-muted">
          A browser page cannot inject clicks into other Android apps. System-wide automation needs a separate native app and an accessibility service you explicitly turn on. This app never enables that, never hides automation, and never bypasses anti-cheat.
        </p>
      </Panel>
      <Panel title="Status">
        <p className="font-display text-2xl font-semibold" role="status">
          {phase === "running" ? "Running inside this practice pad" : phase === "paused" ? "Paused" : phase === "preview" ? "Previewing one cycle" : "Stopped"}
        </p>
        <p className="mt-1 text-sm tabular-nums text-muted">
          {taps} practice taps · {cycles} cycles
          {waitMs != null && (phase === "running" || phase === "preview") ? ` · next in ${Math.ceil(waitMs / 100) / 10}s` : ""}
        </p>
        {error ? <div className="mt-2"><Notice tone="warn">{error}</Notice></div> : null}
        {!error && lastSummary ? <div className="mt-2"><Notice>{lastSummary}</Notice></div> : null}
        {unlimited ? <p className="mt-2 text-sm text-primary">No repeat or duration limit. It runs until you press Stop.</p> : null}
      </Panel>
      <Panel title="Practice pad">
        <p className="mb-3 text-sm text-muted">
          {config.mode === "single" ? "Tap the pad to place the single point. Drag the point to move it." : "Tap empty space to add a point. Drag a point to move it."}
        </p>
        <div
          className="relative h-64 w-full overflow-hidden rounded-xl bg-bg shadow-[var(--shadow-ring)]"
          onPointerDown={(event) => {
            if (event.target !== event.currentTarget) return;
            const rect = event.currentTarget.getBoundingClientRect();
            const x = clampPercent((event.clientX - rect.left) / rect.width);
            const y = clampPercent((event.clientY - rect.top) / rect.height);
            place(x, y);
          }}
        >
          {config.points.map((point, index) => (
            <PointMarker
              key={point.id}
              point={point}
              index={index}
              active={activePointId === point.id}
              pulse={pulse}
              locked={locked}
              onMove={(x, y) => updatePoint(point.id, { x, y })}
            />
          ))}
          {config.points.length === 0 ? (
            <p className="pointer-events-none absolute inset-0 grid place-items-center text-sm text-faint">Tap to add a point</p>
          ) : null}
        </div>
        <p className="mt-3 text-xs text-faint">If this browser tab is in the background, timing can drift. That still does not click outside this page.</p>
      </Panel>
      <div className="grid grid-cols-2 gap-2">
        {phase === "paused" ? (
          <Button onClick={resumeClicker}>Resume</Button>
        ) : (
          <Button onClick={() => startClicker("run")} disabled={locked || Boolean(validation)}>
            Start
          </Button>
        )}
        <Button variant="quiet" onClick={pauseClicker} disabled={phase !== "running" && phase !== "preview"}>
          Pause
        </Button>
        <Button variant="quiet" onClick={() => startClicker("preview")} disabled={locked || Boolean(validation)}>
          Preview one cycle
        </Button>
        <Button onClick={() => stopClicker("Stopped.")} disabled={!locked}>
          Stop
        </Button>
      </div>
      {validation && !locked ? <Notice tone="warn">{validation}</Notice> : null}
      <Panel title="Timing">
        <div className="stack">
          <div className="flex flex-wrap gap-2" role="group" aria-label="Click mode">
            <Chip pressed={config.mode === "single"} disabled={locked} onClick={() => setClicker({ mode: "single" })}>
              Single point
            </Chip>
            <Chip pressed={config.mode === "sequence"} disabled={locked} onClick={() => setClicker({ mode: "sequence" })}>
              Sequence
            </Chip>
          </div>
          <NumberCommit
            label="Interval (ms)"
            hint="Gap between taps in single mode, and between cycles in a sequence. Minimum 50 ms."
            value={config.intervalMs}
            min={50}
            max={60000}
            disabled={locked}
            onCommit={(intervalMs) => setClicker({ intervalMs })}
          />
          <div className="flex flex-wrap gap-2">
            {[100, 250, 500, 1000].map((interval) => (
              <Chip key={interval} pressed={config.intervalMs === interval} disabled={locked} onClick={() => setClicker({ intervalMs: interval })}>
                {interval} ms
              </Chip>
            ))}
          </div>
          <NumberCommit
            label="Repetitions"
            hint="Cycles to run. 0 means no count limit."
            value={config.repeat}
            min={0}
            max={9999}
            disabled={locked}
            onCommit={(repeat) => setClicker({ repeat })}
          />
          <div className="flex flex-wrap gap-2">
            <Chip pressed={config.repeat === 1} disabled={locked} onClick={() => setClicker({ repeat: 1 })}>Once</Chip>
            <Chip pressed={config.repeat === 10} disabled={locked} onClick={() => setClicker({ repeat: 10 })}>10 times</Chip>
            <Chip pressed={config.repeat === 0} disabled={locked} onClick={() => setClicker({ repeat: 0 })}>No count limit</Chip>
          </div>
          <NumberCommit
            label="Duration (seconds)"
            hint="0 means no time limit. Pause does not count toward the duration."
            value={config.durationSec}
            min={0}
            max={86400}
            disabled={locked}
            onCommit={(durationSec) => setClicker({ durationSec })}
          />
          {locked ? <Notice>Stop the practice run to edit timing.</Notice> : null}
        </div>
      </Panel>
      <Panel title="Points">
        {config.points.length === 0 ? <p className="text-sm text-muted">No points yet.</p> : null}
        <ul className="stack">
          {config.points.map((point, index) => (
            <li key={point.id} className="rounded-lg bg-surface-2 p-3">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-semibold">{config.mode === "single" ? "Single point" : `Step ${index + 1}`}</p>
                <div className="flex gap-1">
                  <Button variant="ghost" className="px-2" disabled={locked || index === 0} onClick={() => movePoint(index, -1)}>Up</Button>
                  <Button variant="ghost" className="px-2" disabled={locked || index === config.points.length - 1} onClick={() => movePoint(index, 1)}>Down</Button>
                  <Button variant="ghost" className="px-2" disabled={locked} onClick={() => setPoints(config.points.filter((item) => item.id !== point.id))}>Remove</Button>
                </div>
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <input
                  className="field-input"
                  aria-label={`Label for point ${index + 1}`}
                  value={point.label}
                  maxLength={40}
                  disabled={locked}
                  onChange={(event) => updatePoint(point.id, { label: event.target.value })}
                />
                <input
                  className="field-input tabular-nums"
                  aria-label={`Delay before point ${index + 1} in milliseconds`}
                  inputMode="numeric"
                  disabled={locked}
                  value={point.delayMs}
                  onChange={(event) => updatePoint(point.id, { delayMs: clampDelay(Number(event.target.value)) })}
                />
              </div>
              <p className="mt-1 text-xs text-faint tabular-nums">x {point.x.toFixed(0)} · y {point.y.toFixed(0)} · delay before tap</p>
            </li>
          ))}
        </ul>
      </Panel>
      <Panel id="presets" title="Presets">
        <Field label="Preset name" error={presetError}>
          <input className="field-input" value={presetName} maxLength={40} onChange={(event) => setPresetName(event.target.value)} placeholder="Warm-up sequence" />
        </Field>
        <Button
          className="mt-3"
          variant="quiet"
          onClick={() => {
            const id = savePreset(presetName);
            if (!id) {
              setPresetError("Name the preset before saving.");
              return;
            }
            setPresetName("");
            setPresetError(null);
          }}
        >
          Save current setup
        </Button>
        <ul className="mt-4 divide-y divide-line">
          {presets.map((preset) => (
            <li key={preset.id} className="flex items-center justify-between gap-3 py-3">
              <div className="min-w-0">
                <p className="truncate font-semibold">{preset.name}</p>
                <p className="text-xs text-faint">
                  {preset.mode === "single" ? "Single" : `${preset.points.length} points`} · {preset.intervalMs} ms · {preset.repeat || "no"} repeats
                </p>
              </div>
              <div className="flex shrink-0 gap-1">
                <Button
                  variant="quiet"
                  onClick={() => {
                    if (locked) stopClicker("Stopped to load a preset.");
                    setClicker({
                      intervalMs: preset.intervalMs,
                      repeat: preset.repeat,
                      durationSec: preset.durationSec,
                      mode: preset.mode,
                    });
                    setPoints(preset.points.map((point) => ({ ...point })));
                  }}
                >
                  Load
                </Button>
                <Button variant="ghost" onClick={() => removePreset(preset.id)}>
                  Delete
                </Button>
              </div>
            </li>
          ))}
        </ul>
        {presets.length === 0 ? <p className="text-sm text-muted">No presets saved yet.</p> : null}
      </Panel>
    </div>
  );
}

function PointMarker({
  point,
  index,
  active,
  pulse,
  locked,
  onMove,
}: {
  point: ClickPoint;
  index: number;
  active: boolean;
  pulse: number;
  locked: boolean;
  onMove: (x: number, y: number) => void;
}) {
  return (
    <button
      type="button"
      aria-label={point.label}
      className="absolute z-10 grid size-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-primary text-sm font-semibold text-primary-fg"
      style={{ left: `${point.x}%`, top: `${point.y}%` }}
      onPointerDown={(event) => {
        if (locked) return;
        event.stopPropagation();
        const pad = event.currentTarget.parentElement;
        if (!pad) return;
        const id = event.pointerId;
        const move = (ev: PointerEvent) => {
          if (ev.pointerId !== id) return;
          const rect = pad.getBoundingClientRect();
          onMove(clampPercent((ev.clientX - rect.left) / rect.width), clampPercent((ev.clientY - rect.top) / rect.height));
        };
        const up = (ev: PointerEvent) => {
          if (ev.pointerId !== id) return;
          window.removeEventListener("pointermove", move);
          window.removeEventListener("pointerup", up);
        };
        window.addEventListener("pointermove", move);
        window.addEventListener("pointerup", up);
      }}
    >
      {active ? <span key={pulse} className="tap-pulse pointer-events-none absolute left-1/2 top-1/2 size-11 rounded-full bg-primary" /> : null}
      <span className="relative">{index + 1}</span>
    </button>
  );
}

function Chip({
  pressed,
  disabled,
  onClick,
  children,
}: {
  pressed: boolean;
  disabled?: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      disabled={disabled}
      onClick={onClick}
      className={`min-h-11 rounded-lg px-3 text-sm font-semibold disabled:opacity-50 ${pressed ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`}
    >
      {children}
    </button>
  );
}

function NumberCommit({
  label,
  hint,
  value,
  min,
  max,
  disabled,
  onCommit,
}: {
  label: string;
  hint: string;
  value: number;
  min: number;
  max: number;
  disabled?: boolean;
  onCommit: (value: number) => void;
}) {
  const [text, setText] = useState(String(value));
  useEffect(() => setText(String(value)), [value]);
  return (
    <Field label={label} hint={hint}>
      <input
        className="field-input tabular-nums"
        inputMode="numeric"
        disabled={disabled}
        value={text}
        onChange={(event) => setText(event.target.value)}
        onBlur={() => {
          const next = Number(text);
          if (!Number.isFinite(next)) {
            setText(String(value));
            return;
          }
          const clamped = Math.min(max, Math.max(min, Math.round(next)));
          onCommit(clamped);
          setText(String(clamped));
        }}
      />
    </Field>
  );
}

function clampPercent(value: number) {
  if (!Number.isFinite(value)) return 50;
  return Math.min(96, Math.max(4, Math.round(value * 10) / 10));
}

function clampDelay(value: number) {
  if (!Number.isFinite(value)) return 500;
  return Math.min(60000, Math.max(50, Math.round(value)));
}
