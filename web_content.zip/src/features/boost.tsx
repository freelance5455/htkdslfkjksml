import { Link } from "@tanstack/react-router";
import { FpsLogTool } from "@/components/fps-tools";
import { RefreshMeasure } from "@/components/refresh-measure";
import { buttonClass, PageHeader, Panel } from "@/components/ui";
import {
  BACKGROUND_TIPS,
  FPS_TARGETS,
  PRESETS,
  THERMAL_TIPS,
  formatWhen,
  guidanceFor,
  presetLabel,
  visualsForPreset,
} from "@/lib/model";
import { useAppStore, useSelectedGame } from "@/lib/store";

export function BoostPage() {
  const game = useSelectedGame();
  const games = useAppStore((state) => state.games);
  const selectGame = useAppStore((state) => state.selectGame);
  const updateGame = useAppStore((state) => state.updateGame);
  const logs = useAppStore((state) => state.fpsLogs);
  const sample = useAppStore((state) => state.refreshSample);
  const last = logs.find((entry) => (game ? entry.gameId === game.id : true));

  function apply(preset: (typeof PRESETS)[number]) {
    if (!game || preset === "custom") {
      if (game && preset === "custom") updateGame(game.id, { preset: "custom" });
      return;
    }
    updateGame(game.id, { preset, ...visualsForPreset(preset, game.fpsTarget) });
  }

  return (
    <div className="stack">
      <PageHeader
        kicker="Optimizer"
        title="FPS targets"
        subtitle="Pick a target and a preset. FrameForge saves the recommendation. It does not change clocks, inject frames, or unlock a game's FPS."
      />
      <Panel title="Three different numbers">
        <div className="grid grid-cols-3 gap-2">
          <Stat label="Target" value={game ? String(game.fpsTarget) : "—"} hint="Your goal" />
          <Stat label="Measured" value={last ? String(last.measuredFps) : "—"} hint={last ? "Manual log" : "None yet"} />
          <Stat label="Refresh" value={sample ? String(sample.displayHz) : "—"} hint="This page" />
        </div>
        <p className="mt-3 text-sm text-muted">
          Display refresh is how often the panel can present frames. Rendered FPS is what the game draws. Interpolated FPS would be extra frames invented between those. This app can only estimate the first, and only for this page.
        </p>
      </Panel>
      <Panel title="Profile">
        {games.length === 0 ? (
          <p className="text-sm text-muted">
            Add a game in the <Link to="/games" className="font-semibold text-primary">library</Link> first.
          </p>
        ) : (
          <label className="block">
            <span className="sr-only">Selected game</span>
            <select
              className="field-input"
              value={game?.id ?? ""}
              onChange={(event) => selectGame(event.target.value || null)}
            >
              {games.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>
        )}
      </Panel>
      <Panel title="Target FPS">
        <p className="mb-3 text-sm text-muted">These are targets, not guaranteed results.</p>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Target FPS">
          {FPS_TARGETS.map((target) => (
            <button
              key={target}
              type="button"
              disabled={!game}
              aria-pressed={game?.fpsTarget === target}
              className={`min-h-11 min-w-14 rounded-lg px-3 text-sm font-semibold tabular-nums disabled:opacity-50 ${game?.fpsTarget === target ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`}
              onClick={() => game && updateGame(game.id, { fpsTarget: target })}
            >
              {target}
            </button>
          ))}
        </div>
      </Panel>
      <Panel title="Preset">
        <div className="grid grid-cols-2 gap-2">
          {PRESETS.map((preset) => (
            <button
              key={preset}
              type="button"
              disabled={!game}
              aria-pressed={game?.preset === preset}
              className={`min-h-16 rounded-lg px-3 text-sm font-semibold disabled:opacity-50 ${game?.preset === preset ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`}
              onClick={() => apply(preset)}
            >
              {presetLabel(preset)}
            </button>
          ))}
        </div>
        <p className="mt-3 text-sm text-muted">
          Battery Saver suggests 30. Balanced suggests 60. Performance keeps your current target and lightens a few effects. None of them raise a hidden FPS cap.
        </p>
      </Panel>
      <Panel title="In-game settings to try">
        {game ? (
          <ul className="list-disc space-y-2 pl-5 text-sm text-muted">
            {guidanceFor(game).map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted">Select a profile to see recommendations.</p>
        )}
        <Link to="/games" className={buttonClass("quiet", "mt-4")}>
          Edit the full profile
        </Link>
      </Panel>
      <Panel title="Background activity">
        <ul className="list-disc space-y-2 pl-5 text-sm text-muted">
          {BACKGROUND_TIPS.map((tip) => (
            <li key={tip}>{tip}</li>
          ))}
        </ul>
      </Panel>
      <Panel title="Heat">
        <ul className="list-disc space-y-2 pl-5 text-sm text-muted">
          {THERMAL_TIPS.map((tip) => (
            <li key={tip}>{tip}</li>
          ))}
        </ul>
        <p className="mt-3 text-sm font-semibold">Temperature: Not available in this version.</p>
      </Panel>
      <Panel title="Frame generation">
        <p className="font-semibold">Frame generation unavailable in this version.</p>
        <p className="mt-2 text-sm text-muted">
          There is no frame interpolation running, and no counter pretending there is. A native capture or scaling tool would be a different app, with its own permissions. This page does not inject frames into games.
        </p>
      </Panel>
      <Panel title="Refresh estimate">
        <RefreshMeasure />
      </Panel>
      <Panel title="Log a measured FPS">
        <FpsLogTool compact />
        {last ? <p className="text-xs text-faint">Latest entry {formatWhen(last.at)}.</p> : null}
        <Link to="/tools" hash="fps-log" className="text-sm font-semibold text-primary">
          Open the full log
        </Link>
      </Panel>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-lg bg-surface-2 px-2 py-3 text-center">
      <p className="text-xs font-semibold tracking-widest text-faint uppercase">{label}</p>
      <p className="font-display text-2xl font-semibold tabular-nums">{value}</p>
      <p className="text-xs text-muted">{hint}</p>
    </div>
  );
}
