import { useEffect, useState } from "react";
import { useRouterState } from "@tanstack/react-router";
import { ExternalLink, ImagePlus, Trash2 } from "lucide-react";
import { Button, Field, Notice, PageHeader, Panel } from "@/components/ui";
import { imageFileToDataUrl } from "@/lib/image";
import {
  AA,
  DETAIL,
  FPS_TARGETS,
  GRAPHICS,
  PRESETS,
  SCALE,
  aaLabel,
  detailLabel,
  graphicsLabel,
  presetLabel,
  safeLaunchUrl,
  scaleLabel,
  visualsForGraphics,
  visualsForPreset,
  type Game,
  type GraphicsLevel,
  type PerfPreset,
} from "@/lib/model";
import { useAppStore } from "@/lib/store";

export function GamesPage() {
  const games = useAppStore((state) => state.games);
  const selectedId = useAppStore((state) => state.selectedGameId);
  const cardStyle = useAppStore((state) => state.cardStyle);
  const addGame = useAppStore((state) => state.addGame);
  const selectGame = useAppStore((state) => state.selectGame);
  const hash = useRouterState({ select: (state) => state.location.hash });
  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);

  useEffect(() => {
    const id = decodeURIComponent(hash.replace(/^#/, ""));
    if (!id.startsWith("g-")) return;
    const gameId = id.slice(2);
    if (!useAppStore.getState().games.some((game) => game.id === gameId)) return;
    selectGame(gameId);
    setOpenId(gameId);
  }, [hash, selectGame]);

  useEffect(() => {
    if (!openId) return;
    const node = document.getElementById(`g-${openId}`);
    node?.scrollIntoView({ block: "start" });
  }, [openId]);

  const filtered = games.filter((game) => game.name.toLowerCase().includes(query.trim().toLowerCase()));
  const open = games.find((game) => game.id === openId) ?? null;

  return (
    <div className="stack">
      <PageHeader
        kicker="Library"
        title="Games"
        subtitle="Profiles are manual. This app cannot scan installed Android packages or launch a game you did not link."
      />
      <div className="flex gap-2">
        <input
          className="field-input"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Filter profiles"
          aria-label="Filter profiles"
        />
        <Button
          className="shrink-0"
          onClick={() => {
            const id = addGame("New game");
            setOpenId(id);
            setQuery("");
          }}
        >
          Add game
        </Button>
      </div>
      {games.length === 0 ? (
        <Panel title="No games yet">
          <p className="text-sm text-muted">Add a game by name. Where Winds Meet can be one of them. Icons and links are optional.</p>
        </Panel>
      ) : filtered.length === 0 ? (
        <Panel title="No matches">
          <p className="text-sm text-muted">Nothing in the library matches that filter.</p>
        </Panel>
      ) : (
        <ul className="stack">
          {filtered.map((game) => (
            <li key={game.id}>
              <GameCard
                game={game}
                selected={game.id === selectedId}
                poster={cardStyle === "poster"}
                onOpen={() => {
                  selectGame(game.id);
                  setOpenId(game.id);
                }}
              />
            </li>
          ))}
        </ul>
      )}
      {open ? <GameEditor game={open} onClose={() => setOpenId(null)} /> : null}
    </div>
  );
}

function GameCard({
  game,
  selected,
  poster,
  onOpen,
}: {
  game: Game;
  selected: boolean;
  poster: boolean;
  onOpen: () => void;
}) {
  return (
    <article className={poster ? "surface overflow-hidden" : "surface"}>
      <button type="button" onClick={onOpen} className={poster ? "block w-full text-left" : "flex w-full items-center gap-3 p-3 text-left"}>
        {poster ? (
          <div className="relative h-28 bg-surface-2">
            <Mark name={game.name} image={game.image} poster />
          </div>
        ) : (
          <Mark name={game.name} image={game.image} />
        )}
        <div className={poster ? "p-4" : "min-w-0 flex-1"}>
          <div className="flex items-center justify-between gap-2">
            <h2 className="truncate font-display text-xl font-semibold">{game.name}</h2>
            {selected ? <span className="shrink-0 text-xs font-semibold tracking-widest text-ok uppercase">Selected</span> : null}
          </div>
          <p className="mt-1 text-sm text-muted">
            Target {game.fpsTarget} · {presetLabel(game.preset)} · Shadows {detailLabel(game.shadows)}
          </p>
        </div>
      </button>
    </article>
  );
}

function Mark({ name, image, poster = false }: { name: string; image: string | null; poster?: boolean }) {
  if (image) {
    return <img src={image} alt="" className={poster ? "media-frame h-full w-full object-cover" : "media-frame size-14 shrink-0 rounded-lg object-cover"} />;
  }
  const letter = name.trim().slice(0, 1).toUpperCase() || "?";
  return (
    <div className={poster ? "grid h-full place-items-center font-display text-4xl text-primary" : "grid size-14 shrink-0 place-items-center rounded-lg bg-surface-2 font-display text-xl text-primary"} aria-hidden="true">
      {letter}
    </div>
  );
}

function GameEditor({ game, onClose }: { game: Game; onClose: () => void }) {
  const updateGame = useAppStore((state) => state.updateGame);
  const removeGame = useAppStore((state) => state.removeGame);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);
  const launch = safeLaunchUrl(game.launchUrl);

  async function onFile(file: File | undefined) {
    if (!file) return;
    try {
      const image = await imageFileToDataUrl(file);
      updateGame(game.id, { image });
      setImageError(null);
    } catch (error) {
      setImageError(error instanceof Error ? error.message : "Could not use that image.");
    }
  }

  function applyPreset(preset: PerfPreset) {
    if (preset === "custom") {
      updateGame(game.id, { preset: "custom" });
      return;
    }
    updateGame(game.id, { preset, ...visualsForPreset(preset, game.fpsTarget) });
  }

  function applyGraphics(level: GraphicsLevel) {
    if (level === "custom") {
      updateGame(game.id, { graphics: "custom", preset: "custom" });
      return;
    }
    updateGame(game.id, { preset: "custom", ...visualsForGraphics(level) });
  }

  return (
    <Panel id={`g-${game.id}`} title={game.name}>
      <div className="stack">
        <Field label="Name">
          <input
            className="field-input"
            value={game.name}
            maxLength={60}
            onChange={(event) => updateGame(game.id, { name: event.target.value.slice(0, 60) || game.name })}
          />
        </Field>
        <Field label="Icon" hint="Stored on this device as a small image. Optional." error={imageError}>
          <div className="flex items-center gap-3">
            <Mark name={game.name} image={game.image} />
            <label className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-surface-2 px-4 text-sm font-semibold">
              <ImagePlus className="size-4" aria-hidden="true" />
              Add icon
              <input
                className="sr-only"
                type="file"
                accept="image/*"
                onChange={(event) => {
                  void onFile(event.target.files?.[0]);
                  event.target.value = "";
                }}
              />
            </label>
            {game.image ? (
              <Button variant="ghost" onClick={() => updateGame(game.id, { image: null })}>
                Remove
              </Button>
            ) : null}
          </div>
        </Field>
        <Field
          label="Launch link"
          hint="http(s) or an app link you already have. Javascript links are blocked."
          error={game.launchUrl.trim() && !launch ? "That link cannot be opened." : null}
        >
          <input
            className="field-input"
            value={game.launchUrl}
            maxLength={500}
            placeholder="https:// or yourgame://"
            onChange={(event) => updateGame(game.id, { launchUrl: event.target.value })}
          />
        </Field>
        {launch ? (
          <a className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-primary" href={launch} target="_blank" rel="noopener noreferrer">
            <ExternalLink className="size-4" aria-hidden="true" />
            Open link
          </a>
        ) : (
          <p className="text-sm text-faint">Add a link to enable launch. Installed apps are not scanned.</p>
        )}
        <fieldset>
          <legend className="mb-2 text-sm font-semibold">Target FPS</legend>
          <p className="mb-2 text-sm text-muted">Targets, not guaranteed frame rates.</p>
          <div className="flex flex-wrap gap-2">
            {FPS_TARGETS.map((target) => (
              <button
                key={target}
                type="button"
                aria-pressed={game.fpsTarget === target}
                className={`min-h-11 min-w-11 rounded-lg px-3 text-sm font-semibold tabular-nums ${game.fpsTarget === target ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`}
                onClick={() => updateGame(game.id, { fpsTarget: target })}
              >
                {target}
              </button>
            ))}
          </div>
        </fieldset>
        <Field label="Performance preset" hint="Writes recommended settings onto this profile. You still change them in the game.">
          <div className="grid grid-cols-2 gap-2">
            {PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                aria-pressed={game.preset === preset}
                className={`min-h-11 rounded-lg px-3 text-sm font-semibold ${game.preset === preset ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`}
                onClick={() => applyPreset(preset)}
              >
                {presetLabel(preset)}
              </button>
            ))}
          </div>
        </Field>
        <Field label="Graphics bundle">
          <select className="field-input" value={game.graphics} onChange={(event) => applyGraphics(event.target.value as GraphicsLevel)}>
            {GRAPHICS.map((level) => (
              <option key={level} value={level}>
                {graphicsLabel(level)}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Resolution scale">
            <select
              className="field-input"
              value={game.resolutionScale}
              onChange={(event) => updateGame(game.id, { resolutionScale: event.target.value as Game["resolutionScale"], preset: "custom", graphics: "custom" })}
            >
              {SCALE.map((scale) => (
                <option key={scale} value={scale}>
                  {scaleLabel(scale)}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Shadows">
            <select
              className="field-input"
              value={game.shadows}
              onChange={(event) => updateGame(game.id, { shadows: event.target.value as Game["shadows"], preset: "custom", graphics: "custom" })}
            >
              {DETAIL.map((level) => (
                <option key={level} value={level}>
                  {detailLabel(level)}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Effects">
            <select
              className="field-input"
              value={game.effects}
              onChange={(event) => updateGame(game.id, { effects: event.target.value as Game["effects"], preset: "custom", graphics: "custom" })}
            >
              {DETAIL.map((level) => (
                <option key={level} value={level}>
                  {detailLabel(level)}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Anti-aliasing">
            <select
              className="field-input"
              value={game.aa}
              onChange={(event) => updateGame(game.id, { aa: event.target.value as Game["aa"], preset: "custom", graphics: "custom" })}
            >
              {AA.map((level) => (
                <option key={level} value={level}>
                  {aaLabel(level)}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="VSync note">
          <select
            className="field-input"
            value={game.vsync}
            onChange={(event) => updateGame(game.id, { vsync: event.target.value === "off" ? "off" : "on", preset: "custom", graphics: "custom" })}
          >
            <option value="on">On</option>
            <option value="off">Off</option>
          </select>
        </Field>
        <Field label="Notes">
          <textarea className="field-input min-h-28" maxLength={2000} value={game.notes} onChange={(event) => updateGame(game.id, { notes: event.target.value })} />
        </Field>
        <Notice>Changes save on this device as you edit.</Notice>
        <div className="flex flex-wrap gap-2">
          <Button variant="quiet" onClick={onClose}>
            Close editor
          </Button>
          {confirmDelete ? (
            <Button
              onClick={() => {
                removeGame(game.id);
                onClose();
              }}
            >
              <Trash2 className="size-4" aria-hidden="true" />
              Confirm delete
            </Button>
          ) : (
            <Button variant="quiet" onClick={() => setConfirmDelete(true)}>
              Delete profile
            </Button>
          )}
        </div>
      </div>
    </Panel>
  );
}
