import { Link } from "@tanstack/react-router";
import { DevicePanel } from "@/components/device-panel";
import { RefreshMeasure } from "@/components/refresh-measure";
import { SessionClock } from "@/components/session-clock";
import { buttonClass, MetricRow, PageHeader, Panel } from "@/components/ui";
import { useDeviceSnapshot } from "@/lib/device";
import { formatWhen, presetLabel, type WidgetId } from "@/lib/model";
import { useAppStore, useSelectedGame } from "@/lib/store";

const QUICK = [
  { to: "/boost" as const, label: "Optimize", variant: "primary" as const },
  { to: "/games" as const, label: "Game Library", variant: "quiet" as const },
  { to: "/clicker" as const, label: "Auto Clicker", variant: "quiet" as const },
  { to: "/tools" as const, hash: "tutorials", label: "Tutorials", variant: "quiet" as const },
  { to: "/settings" as const, hash: "customize", label: "Customize", variant: "quiet" as const },
];

export function HomePage() {
  const widgets = useAppStore((state) => state.widgets);
  const visible = widgets.filter((widget) => widget.visible);

  return (
    <div className="stack">
      <PageHeader
        kicker="Dashboard"
        title="Session desk"
        subtitle="Recommendations and measurements you can check. Nothing here is a live overlay on a game."
      />
      {visible.length === 0 ? (
        <Panel title="Widgets hidden">
          <p className="text-sm text-muted">Every home widget is turned off.</p>
          <Link to="/settings" hash="widgets" className="mt-3 inline-flex text-sm font-semibold text-primary">
            Edit home widgets
          </Link>
        </Panel>
      ) : (
        visible.map((widget) => <HomeWidget key={widget.id} id={widget.id} />)
      )}
    </div>
  );
}

function HomeWidget({ id }: { id: WidgetId }) {
  if (id === "quick") return <QuickActions />;
  if (id === "session") {
    return (
      <Panel title="Session timer">
        <SessionClock prominent />
      </Panel>
    );
  }
  if (id === "profile") return <ProfileCard />;
  if (id === "status") return <StatusCard />;
  if (id === "refresh") {
    return (
      <Panel title="Display refresh">
        <RefreshMeasure />
      </Panel>
    );
  }
  return (
    <Panel title="Device and browser">
      <DevicePanel />
    </Panel>
  );
}

function QuickActions() {
  const [primary, ...rest] = QUICK;
  return (
    <Panel title="Quick actions">
      <div className="stack">
        <Link to={primary.to} className={buttonClass("primary", "w-full")}>
          {primary.label}
        </Link>
        <div className="grid grid-cols-2 gap-2">
          {rest.map((action) => (
            <Link key={action.label} to={action.to} hash={action.hash} className={buttonClass("quiet", "w-full")}>
              {action.label}
            </Link>
          ))}
        </div>
      </div>
    </Panel>
  );
}

function ProfileCard() {
  const game = useSelectedGame();
  if (!game) {
    return (
      <Panel title="Selected game">
        <p className="text-sm text-muted">No profile selected.</p>
        <Link to="/games" className="mt-3 inline-flex text-sm font-semibold text-primary">
          Open the library
        </Link>
      </Panel>
    );
  }
  return (
    <Panel
      title="Selected game"
      action={
        <Link to="/games" hash={`g-${game.id}`} className="text-sm font-semibold text-primary">
          Edit
        </Link>
      }
    >
      <div className="flex items-center gap-3">
        <Monogram name={game.name} image={game.image} />
        <div className="min-w-0">
          <p className="truncate font-display text-xl font-semibold">{game.name}</p>
          <p className="text-sm text-muted">{presetLabel(game.preset)}</p>
        </div>
      </div>
      <p className="mt-4 text-xs font-semibold tracking-widest text-faint uppercase">Target</p>
      <p className="font-display text-3xl font-semibold tabular-nums">{game.fpsTarget}</p>
      <p className="text-sm text-muted">Not a measured frame rate.</p>
    </Panel>
  );
}

function StatusCard() {
  const game = useSelectedGame();
  const logs = useAppStore((state) => state.fpsLogs);
  const sample = useAppStore((state) => state.refreshSample);
  const batteryLine = useBatteryLine();
  const last = logs.find((entry) => (game ? entry.gameId === game.id : true)) ?? logs[0];

  return (
    <Panel title="Performance status">
      <dl>
        <MetricRow label="Profile" value={game?.name ?? "None selected"} source="Your library" />
        <MetricRow label="Preset" value={game ? presetLabel(game.preset) : "—"} source="Saved preference. Not a system power mode." />
        <MetricRow label="Target FPS" value={game ? String(game.fpsTarget) : "—"} source="Target only. This app cannot force it." />
        <MetricRow
          label="Last measured FPS"
          value={last ? String(last.measuredFps) : "No manual measurement yet"}
          source={last ? `You entered this ${formatWhen(last.at)}.` : "Manual FPS log"}
        />
        <MetricRow
          label="Display refresh"
          value={sample ? `${sample.displayHz} Hz` : "Not measured yet"}
          source="Separate from rendered FPS and from interpolated FPS. Page estimate only."
        />
        <MetricRow label="Battery" value={batteryLine.value} unavailable={batteryLine.unavailable} source={batteryLine.source} />
      </dl>
      <p className="mt-3 text-sm font-semibold">Frame generation unavailable in this version.</p>
      <p className="mt-1 text-sm text-muted">CPU load, GPU load, and temperature are not available in this version. They are listed on the device card.</p>
    </Panel>
  );
}

function useBatteryLine() {
  const snap = useDeviceSnapshot();
  if (!snap) return { value: "Checking…", unavailable: false, source: "Battery Status API" };
  if (!snap.battery) {
    return {
      value: null,
      unavailable: true,
      source: snap.batterySupported ? "Battery Status API returned nothing." : "Battery Status API is not in this browser.",
    };
  }
  return {
    value: `${Math.round(snap.battery.level * 100)}% · ${snap.battery.charging ? "charging" : "not charging"}`,
    unavailable: false,
    source: "Battery Status API",
  };
}

function Monogram({ name, image }: { name: string; image: string | null }) {
  if (image) {
    return <img src={image} alt="" className="media-frame size-14 rounded-lg object-cover" />;
  }
  const letter = name.trim().slice(0, 1).toUpperCase() || "?";
  return (
    <div className="grid size-14 place-items-center rounded-lg bg-surface-2 font-display text-xl text-primary" aria-hidden="true">
      {letter}
    </div>
  );
}
