/**
 * Paysage style Football Manager 27.
 * - Verrouille en landscape dès que le navigateur / WebView le permet.
 * - En portrait : écran de guidage (pas de rotation CSS cassée).
 * - Sur APK WebIntoApp : Orientation = Landscape (obligatoire pour un vrai lock natif).
 */

export function isPortraitViewport(win = globalThis) {
  try {
    if (win.matchMedia?.('(orientation: portrait)').matches) return true;
    const w = win.innerWidth || 0;
    const h = win.innerHeight || 0;
    return w > 0 && h > 0 && w < h;
  } catch {
    return false;
  }
}

export function shouldShowLandscapeGuidance() {
  return isPortraitViewport();
}

export function initLandscapeGuidance({ doc = globalThis.document, win = globalThis.window } = {}) {
  if (!doc?.documentElement || !win) return null;

  let guidance = doc.getElementById('orientationGuidance');
  if (!guidance) {
    guidance = doc.createElement('div');
    guidance.id = 'orientationGuidance';
    guidance.className = 'orientation-guidance';
    guidance.hidden = true;
    guidance.innerHTML = `
      <div class="orientation-card" role="dialog" aria-modal="true" aria-labelledby="orientationTitle">
        <div class="orientation-icon" aria-hidden="true" style="font-size:42px">📱↔️</div>
        <h2 id="orientationTitle">Mode paysage</h2>
        <p>CGD s'affiche en <strong>horizontal</strong>, comme Football Manager.</p>
        <p>Tournez le téléphone <strong>à l'horizontal</strong> pour continuer.</p>
        <p class="muted" style="font-size:12px;margin-top:12px;line-height:1.4">
          APK WebIntoApp : dans les réglages de génération, choisissez
          <b>Orientation = Landscape</b> pour que le jeu se lance directement en paysage
          sans tourner l'appareil.
        </p>
      </div>`;
    doc.body.appendChild(guidance);
  }

  let lockOk = false;

  const applyMode = () => {
    const portrait = isPortraitViewport(win);
    const showGuide = portrait && !lockOk;
    guidance.hidden = !showGuide;
    doc.documentElement.classList.toggle('portrait-blocked', showGuide);
    doc.documentElement.classList.toggle('landscape-ready', !showGuide);
    doc.documentElement.classList.remove('force-landscape-css');
    if (doc.body) {
      doc.body.classList.toggle('is-portrait', showGuide);
      doc.body.classList.toggle('is-landscape', !showGuide);
      doc.body.classList.remove('force-landscape-css');
    }
  };

  const requestLock = async () => {
    applyMode();
    try {
      const orientation = win.screen?.orientation;
      if (!orientation?.lock) {
        applyMode();
        return false;
      }
      try {
        await orientation.lock('landscape');
        lockOk = true;
        applyMode();
        return true;
      } catch {
        try {
          if (!doc.fullscreenElement && doc.documentElement.requestFullscreen) {
            await doc.documentElement.requestFullscreen();
          }
          await orientation.lock('landscape');
          lockOk = true;
          applyMode();
          return true;
        } catch {
          lockOk = false;
          applyMode();
          return false;
        }
      }
    } catch {
      lockOk = false;
      applyMode();
      return false;
    }
  };

  applyMode();
  requestLock();
  setTimeout(requestLock, 400);
  setTimeout(requestLock, 1500);

  win.addEventListener('resize', applyMode, { passive: true });
  win.addEventListener('orientationchange', () => {
    setTimeout(() => { applyMode(); requestLock(); }, 120);
  }, { passive: true });
  win.addEventListener('fullscreenchange', () => { requestLock(); }, { passive: true });
  doc.addEventListener('visibilitychange', () => {
    if (!doc.hidden) requestLock();
  }, { passive: true });

  let gestures = 0;
  const onGesture = () => {
    gestures++;
    requestLock();
    if (gestures >= 6) {
      win.removeEventListener('pointerdown', onGesture);
      win.removeEventListener('touchstart', onGesture);
    }
  };
  win.addEventListener('pointerdown', onGesture, { passive: true });
  win.addEventListener('touchstart', onGesture, { passive: true });

  return {
    update: requestLock,
    get requested() { return lockOk; },
    get lockOk() { return lockOk; }
  };
}
