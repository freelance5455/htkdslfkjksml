/** Orientation : le conteneur APKForge doit déclarer l'orientation landscape.
 * Le jeu ne bloque plus son démarrage avec un écran demandant de tourner le téléphone.
 * Les navigateurs qui exposent Screen Orientation peuvent recevoir une demande non bloquante.
 */
export function shouldShowLandscapeGuidance() { return false; }

export function initLandscapeGuidance({ doc = globalThis.document, win = globalThis.window } = {}) {
  if (!doc?.documentElement || !win) return null;
  const request = async () => {
    try {
      if (win.screen?.orientation?.lock && doc.fullscreenElement) {
        await win.screen.orientation.lock('landscape');
      }
    } catch { /* Le réglage landscape du conteneur APK reste prioritaire. */ }
  };
  request();
  win.addEventListener?.('fullscreenchange', request, { passive: true });
  return { update: request };
}
