/**
 * Paysage forcé style Football Manager 27.
 * - Tente screen.orientation.lock('landscape') (et plein écran si besoin).
 * - Si le WebView refuse le lock et que l'appareil est en portrait :
 *   bascule en mode CSS "force-landscape" : l'UI est tournée à 90°
 *   et joue en horizontal SANS que l'utilisateur tourne le téléphone.
 * Sur APK WebIntoApp : régler Orientation = Landscape pour le lock natif
 * (meilleure solution, comme une vraie app FM).
 */

export function isPortraitViewport(win = globalThis) {
  try {
    if (win.matchMedia?.('(orientation: portrait)').matches) return true;
    const w = win.innerWidth || 0;
    const h = win.innerHeight || 0;
    return w > 0 && h > 0 && w < h;
  } catch {
    return false;
  }
}

/** Ancien nom conservé pour compat */
export function shouldShowLandscapeGuidance() {
  return false; // plus d'overlay "tournez l'appareil"
}

export function initLandscapeGuidance({ doc = globalThis.document, win = globalThis.window } = {}) {
  if (!doc?.documentElement || !win) return null;

  // Retirer l'ancien overlay de guidage s'il existe
  const existing = doc.getElementById('orientationGuidance');
  if (existing) existing.remove();

  let lockOk = false;

  const applyMode = () => {
    const portrait = isPortraitViewport(win);
    // Portrait + pas de lock natif → CSS rotate pour jouer en horizontal
    const useCssForce = portrait && !lockOk;
    doc.documentElement.classList.toggle('force-landscape-css', useCssForce);
    doc.documentElement.classList.toggle('landscape-ready', !portrait || lockOk);
    doc.documentElement.classList.remove('portrait-blocked');
    if (doc.body) {
      doc.body.classList.toggle('is-landscape', !portrait || lockOk || useCssForce);
      doc.body.classList.toggle('is-portrait', false);
      doc.body.classList.toggle('force-landscape-css', useCssForce);
    }
    if (useCssForce) {
      const w = win.innerWidth || 360;
      const h = win.innerHeight || 640;
      doc.documentElement.style.setProperty('--fl-w', h + 'px');
      doc.documentElement.style.setProperty('--fl-h', w + 'px');
    } else {
      doc.documentElement.style.removeProperty('--fl-w');
      doc.documentElement.style.removeProperty('--fl-h');
    }
  };

  const requestLock = async () => {
    applyMode();
    try {
      const orientation = win.screen?.orientation;
      if (!orientation?.lock) {
        applyMode();
        return false;
      }
      try {
        await orientation.lock('landscape');
        lockOk = true;
        applyMode();
        return true;
      } catch {
        try {
          if (!doc.fullscreenElement && doc.documentElement.requestFullscreen) {
            await doc.documentElement.requestFullscreen();
          }
          await orientation.lock('landscape');
          lockOk = true;
          applyMode();
          return true;
        } catch {
          lockOk = false;
          applyMode();
          return false;
        }
      }
    } catch {
      lockOk = false;
      applyMode();
      return false;
    }
  };

  applyMode();
  requestLock();
  setTimeout(requestLock, 300);
  setTimeout(requestLock, 1000);
  setTimeout(requestLock, 2500);

  win.addEventListener('resize', applyMode, { passive: true });
  win.addEventListener('orientationchange', () => {
    setTimeout(() => { applyMode(); requestLock(); }, 150);
  }, { passive: true });
  win.addEventListener('fullscreenchange', () => { requestLock(); }, { passive: true });
  doc.addEventListener('visibilitychange', () => {
    if (!doc.hidden) requestLock();
  }, { passive: true });

  let gestures = 0;
  const onGesture = () => {
    gestures++;
    requestLock();
    if (gestures >= 8) {
      win.removeEventListener('pointerdown', onGesture);
      win.removeEventListener('touchstart', onGesture);
    }
  };
  win.addEventListener('pointerdown', onGesture, { passive: true });
  win.addEventListener('touchstart', onGesture, { passive: true });

  return {
    update: requestLock,
    get requested() { return lockOk; },
    get lockOk() { return lockOk; }
  };
}
