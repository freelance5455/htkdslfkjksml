import { COMPETITIONS } from './config.js';
export function getCompetition(state, id) { return state.competitions.find(c => c.id === id) ?? null; }
export function validateCompetitionRegistry(state) {
  const ids = state.competitions.map(c => c.id);
  if (ids.length !== 8 || new Set(ids).size !== 8) throw new Error('Le CGD doit conserver les sept compétitions historiques et la Coupe Fédéral, soit huit compétitions distinctes');
  for (const c of COMPETITIONS) { if (!ids.includes(c.id)) throw new Error(`Compétition manquante: ${c.name}`); const saved=state.competitions.find(x=>x.id===c.id); if(saved.authority!==c.authority) throw new Error(`Autorité organisatrice incohérente pour ${c.name}`); if(saved.calendarEngineReady!==c.calendarEngineReady) throw new Error(`État du moteur de calendrier incohérent pour ${c.name}`); }
  return true;
}
