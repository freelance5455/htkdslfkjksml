import { initRouter, registerRoute } from './core/router.js';
import { initXPEngine } from './core/xp/xpEngine.js';
import { initToastListeners } from './core/notifications/toast.js';
import { renderNavBar } from './components/layout/navBar.js';
import { Dashboard } from './pages/Dashboard.js';
import { Settings, settingsCategoryRoute, SETTINGS_CATEGORY_KEYS } from './pages/Settings.js';
import { AboutPage } from './pages/AboutPage.js';
import { BodyPage } from './pages/BodyPage.js';
import { MindPage } from './pages/MindPage.js';
import { DisciplinePage } from './pages/DisciplinePage.js';
import { PresencePage } from './pages/PresencePage.js';
import { ProgressPage } from './pages/ProgressPage.js';
import { icon } from './components/icons.js';
import { navigate } from './core/router.js';
import { initPreferences, applyPreferences, getPrefsSync } from './core/profile/prefsService.js';
import { applyTheme } from './core/profile/profileService.js';
import { showLockIfNeeded, initIdleLock } from './core/security/pinLock.js';
import { showGreeting } from './components/layout/greeting.js';
import { initPomodoroMiniBar } from './modules/mind/pomodoro/pomodoroUI.js';
import { initQuickAdd } from './components/layout/quickAdd.js';
import { rescheduleAll, startInAppReminders } from './core/notifications/reminderService.js';
import { initCelebrations } from './components/layout/celebrate.js';
import { restorePomodoro } from './modules/mind/pomodoro/pomodoroService.js';

// --- Boot core services (order matters: XP engine before any events fire) ---
initXPEngine();
initToastListeners();
initCelebrations();

// --- Register routes ---
registerRoute('/', Dashboard);
registerRoute('/body', BodyPage);
registerRoute('/mind', MindPage);
registerRoute('/discipline', DisciplinePage);
registerRoute('/presence', PresencePage);
registerRoute('/progress', ProgressPage);
registerRoute('/settings', Settings);
SETTINGS_CATEGORY_KEYS.forEach((k) => registerRoute(`/settings/${k}`, settingsCategoryRoute(k)));
registerRoute('/about', AboutPage);

async function boot() {
  try {
    applyPreferences(getPrefsSync());  // instant look (accent, font, density…) before the database opens
    await applyTheme();
    await initPreferences();
    await restorePomodoro();           // timer survives Android unloading the app
    await showLockIfNeeded();          // PIN screen first (only if a PIN is set)
    const greeted = getPrefsSync().greeting ? showGreeting() : Promise.resolve();    // "Good Morning, Abbas!" every time you open the app

    // --- Mount ---
    if (!window.location.hash && getPrefsSync().startScreen !== '/') window.location.hash = getPrefsSync().startScreen;
    const appRoot = document.getElementById('app');
    initRouter(appRoot);
    renderNavBar();
    initPomodoroMiniBar();
    initQuickAdd();
    rescheduleAll().catch(() => {});   // keeps phone reminders in step with your settings
    startInAppReminders();
    initIdleLock();

    // --- Floating settings access (top-right, present on every route) ---
    const settingsBtn = document.createElement('button');
    settingsBtn.id = 'settings-fab';
    settingsBtn.setAttribute('aria-label', 'Settings');
    settingsBtn.append(icon('settings'));
    settingsBtn.addEventListener('click', () => navigate('/settings'));
    document.body.appendChild(settingsBtn);

    await greeted;
  } catch (err) {
    console.error('[boot] failed', err);
    document.body.innerHTML = `<div style="padding:24px;font-family:system-ui;color:#eee;background:#111;min-height:100vh"><h2>Something went wrong while opening the app</h2><p>${String(err && err.message || err)}</p><p>Your data has not been deleted. Close the app fully and reopen it.</p></div>`;
  }
}
boot();

// --- Register service worker ---
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    const hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.register('./sw.js').catch((err) => {
      console.error('[sw] registration failed', err);
    });
    // When a NEW version takes over, reload once so you see it immediately.
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (hadController && !window.__reloadedForUpdate) { window.__reloadedForUpdate = true; window.location.reload(); }
    });
  });
}

// --- Custom install prompt handling ---
let deferredInstallPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  document.dispatchEvent(new CustomEvent('pwa:installable'));
});

export function triggerInstallPrompt() {
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  deferredInstallPrompt = null;
}
