import './style.css';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import * as lamejsModule from 'lamejs';
const lamejs = lamejsModule.default ?? lamejsModule;

const app = document.querySelector('#app');
const instruments = [
  { id:'kick', name:'BUM', color:'pink', type:'kick', key:'1' },
  { id:'snare', name:'PÁ', color:'orange', type:'snare', key:'2' },
  { id:'hat', name:'TSS', color:'yellow', type:'hat', key:'3' },
  { id:'clap', name:'CLAP', color:'purple', type:'clap', key:'4' },
  { id:'bass', name:'BASS', color:'green', type:'bass', key:'5' },
  { id:'bell', name:'DOCE', color:'blue', type:'bell', key:'6' }
];
const steps = 16;
let pattern = Object.fromEntries(instruments.map(i => [i.id, Array(steps).fill(false)]));
pattern.kick[0]=true; pattern.kick[8]=true;
pattern.snare[4]=true; pattern.snare[12]=true;
for (let i=2;i<16;i+=4) pattern.hat[i]=true;
let bpm=110, currentStep=-1, playing=false, timer=null, audioCtx=null, master=null, micStream=null, mediaRecorder=null, recordedChunks=[];
let projectName='Minha primeira batida';

app.innerHTML = `
<header class="topbar">
  <div class="brand"><img src="/assets/logo.png" alt="NeruNeruNeruNe" onerror="this.style.display='none'"><span>Music Maker <b>Studio</b></span></div>
  <button class="small-btn" id="saveProject">Salvar projeto</button>
</header>
<main>
  <section class="hero">
    <div><p class="eyebrow">ESTÚDIO MUSICAL DOCINHO</p><h1>Crie sua própria<br><em>batida!</em></h1>
    <p class="sub">Monte ritmos, toque os pads e exporte sua música.</p></div>
    <img class="mascot" src="/assets/mascot.png" alt="Mascote NeruNeruNeruNe">
  </section>
  <section class="panel transport">
    <div class="project"><label for="projectName">NOME DO PROJETO</label><input id="projectName" value="${projectName}" maxlength="40"></div>
    <div class="tempo"><label for="bpm">VELOCIDADE <b id="bpmValue">${bpm} BPM</b></label><input id="bpm" type="range" min="60" max="180" value="${bpm}"></div>
    <div class="transport-buttons"><button class="play" id="play">▶ Tocar</button><button class="stop" id="stop">■ Parar</button></div>
  </section>
  <section class="panel">
    <div class="section-title"><div><span class="eyebrow">SEQUENCIADOR</span><h2>Gummy Beat Grid</h2></div><span class="hint">Toque nos quadradinhos</span></div>
    <div class="grid-wrap"><div id="sequencer" class="sequencer"></div></div>
    <div class="legend"><span>● Passo ativo</span><span>16 passos por compasso</span></div>
  </section>
  <section class="panel">
    <div class="section-title"><div><span class="eyebrow">TOQUE AO VIVO</span><h2>Sound Pads</h2></div></div>
    <div class="pads" id="pads"></div>
  </section>
  <section class="panel tools">
    <div class="section-title"><div><span class="eyebrow">GRAVAÇÃO E EXPORTAÇÃO</span><h2>Seu som, seu arquivo</h2></div></div>
    <div class="tool-grid">
      <button class="tool-btn" id="record"><span>🎙️</span><b>Gravar microfone</b><small>Grave sua voz ou som externo</small></button>
      <button class="tool-btn" id="stopRecord" disabled><span>⏹️</span><b>Parar gravação</b><small>Finalizar captura de áudio</small></button>
      <button class="tool-btn export" id="exportMp3"><span>🍬</span><b>Exportar MP3</b><small>Renderizar a batida em MP3</small></button>
      <button class="tool-btn" id="exportWav"><span>🎵</span><b>Exportar WAV</b><small>Áudio sem compressão</small></button>
    </div>
    <p id="status" class="status" role="status">Pronto para criar! Ative os passos e aperte Tocar.</p>
    <audio id="recordingPlayer" controls hidden></audio>
  </section>
  <section class="panel downloader">
    <div class="section-title"><div><span class="eyebrow">DOWNLOAD AUTORIZADO</span><h2>Baixador de áudio</h2></div><span class="download-icon">⬇️</span></div>
    <p class="download-help">Cole um link direto para um arquivo de áudio que você tenha autorização para baixar (por exemplo, MP3 ou WAV hospedado em um site que permita downloads).</p>
    <label class="url-label" for="audioUrl">LINK DIRETO DO ÁUDIO</label>
    <input id="audioUrl" class="url-input" type="url" inputmode="url" placeholder="https://exemplo.com/minha-musica.mp3" autocomplete="url">
    <div class="download-actions"><button class="play" id="downloadAudio">⬇ Baixar áudio</button><button class="stop" id="clearAudioUrl">Limpar</button></div>
    <p class="download-note">Não baixa vídeos, não contorna DRM, paywalls, logins ou restrições de plataformas. O servidor do link precisa permitir acesso direto e, no navegador, downloads via CORS.</p>
  </section>
  <footer>NERUNERUNERUNE MUSIC MAKER STUDIO · Feito para criar e se divertir 🍭</footer>
</main>`;

function renderGrid(){
  const grid=document.querySelector('#sequencer');
  grid.innerHTML=`<div class="grid-head"><span>FAIXA</span>${Array.from({length:steps},(_,i)=>`<span>${i+1}</span>`).join('')}</div>`+
    instruments.map(inst=>`<div class="track"><div class="track-name"><i class="${inst.color}"></i>${inst.name}</div>${pattern[inst.id].map((on,i)=>`<button class="step ${inst.color} ${on?'on':''} ${i%4===0?'beat':''}" data-track="${inst.id}" data-step="${i}" aria-label="${inst.name}, passo ${i+1}" aria-pressed="${on}"></button>`).join('')}</div>`).join('');
  grid.querySelectorAll('.step').forEach(btn=>btn.addEventListener('click',()=>{
    const t=btn.dataset.track, s=Number(btn.dataset.step); pattern[t][s]=!pattern[t][s];
    btn.classList.toggle('on',pattern[t][s]); btn.setAttribute('aria-pressed',pattern[t][s]);
  }));
}
function renderPads(){
  document.querySelector('#pads').innerHTML=instruments.map(i=>`<button class="pad ${i.color}" data-sound="${i.id}"><span>${i.id==='kick'?'🥁':i.id==='snare'?'🪘':i.id==='hat'?'✨':i.id==='clap'?'👏':i.id==='bass'?'🎸':'🔔'}</span><b>${i.name}</b><small>Tecla ${i.key}</small></button>`).join('');
  document.querySelectorAll('.pad').forEach(b=>b.addEventListener('pointerdown',()=>{playSound(b.dataset.sound);b.classList.add('pressed');setTimeout(()=>b.classList.remove('pressed'),120)}));
}
async function audio(){
  if(!audioCtx){const AC=window.AudioContext||window.webkitAudioContext; audioCtx=new AC(); master=audioCtx.createGain(); master.gain.value=.78; master.connect(audioCtx.destination);}
  if(audioCtx.state==='suspended') await audioCtx.resume();
  return audioCtx;
}
function tone(freq,duration,wave='sine',volume=.25,when=null){
  const t=when??audioCtx.currentTime, osc=audioCtx.createOscillator(), gain=audioCtx.createGain();
  osc.type=wave; osc.frequency.setValueAtTime(freq,t); gain.gain.setValueAtTime(volume,t); gain.gain.exponentialRampToValueAtTime(.001,t+duration);
  osc.connect(gain);gain.connect(master);osc.start(t);osc.stop(t+duration);
}
function noise(duration,volume,filterType='highpass',freq=1500,when=null){
  const t=when??audioCtx.currentTime, n=Math.floor(audioCtx.sampleRate*duration), buf=audioCtx.createBuffer(1,n,audioCtx.sampleRate), d=buf.getChannelData(0);
  for(let i=0;i<n;i++)d[i]=Math.random()*2-1;
  const src=audioCtx.createBufferSource(), filter=audioCtx.createBiquadFilter(), gain=audioCtx.createGain();
  src.buffer=buf;filter.type=filterType;filter.frequency.value=freq;gain.gain.setValueAtTime(volume,t);gain.gain.exponentialRampToValueAtTime(.001,t+duration);
  src.connect(filter);filter.connect(gain);gain.connect(master);src.start(t);
}
async function playSound(id,when=null){
  await audio(); const t=when??audioCtx.currentTime;
  if(id==='kick'){const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(42,t+.16);g.gain.setValueAtTime(.9,t);g.gain.exponentialRampToValueAtTime(.001,t+.22);o.connect(g);g.connect(master);o.start(t);o.stop(t+.23);}
  else if(id==='snare'){noise(.19,.42,'highpass',1200,t);tone(185,.12,'triangle',.22,t);}
  else if(id==='hat')noise(.055,.20,'highpass',6500,t);
  else if(id==='clap'){noise(.12,.3,'bandpass',1800,t);noise(.10,.18,'bandpass',1300,t+.035);}
  else if(id==='bass')tone(82,.28,'sawtooth',.24,t);
  else if(id==='bell'){tone(880,.45,'sine',.20,t);tone(1320,.32,'sine',.10,t+.01);}
}
function tick(){
  currentStep=(currentStep+1)%steps;
  document.querySelectorAll('.step').forEach(b=>b.classList.toggle('current',Number(b.dataset.step)===currentStep));
  instruments.forEach(i=>{if(pattern[i.id][currentStep])playSound(i.id)});
}
function start(){if(playing)return;playing=true;tick();timer=setInterval(tick,60000/bpm/4);document.querySelector('#play').textContent='♫ Tocando';}
function stop(){playing=false;clearInterval(timer);timer=null;currentStep=-1;document.querySelectorAll('.step').forEach(b=>b.classList.remove('current'));document.querySelector('#play').textContent='▶ Tocar';}
document.querySelector('#play').onclick=start;document.querySelector('#stop').onclick=stop;
document.querySelector('#bpm').oninput=e=>{bpm=Number(e.target.value);document.querySelector('#bpmValue').textContent=bpm+' BPM';if(playing){stop();start();}};
document.querySelector('#projectName').oninput=e=>projectName=e.target.value;
document.addEventListener('keydown',e=>{if(e.target.matches('input'))return;const i=instruments.find(x=>x.key===e.key);if(i)playSound(i.id);});
renderGrid();renderPads();

function getName(ext){return (document.querySelector('#projectName').value.trim().replace(/[^a-z0-9-_ ]/gi,'').replace(/\s+/g,'_')||'minha_batida')+'.'+ext;}
function setStatus(msg){document.querySelector('#status').textContent=msg;}
async function saveBlob(blob,filename){
  if(Capacitor.isNativePlatform()){
    const base64=await blobToBase64(blob);
    const saved=await Filesystem.writeFile({path:filename,data:base64,directory:Directory.Documents,recursive:true});
    try{await Share.share({title:'Minha música',text:'Música criada no NeruNeruNeruNe Music Maker Studio',url:saved.uri,dialogTitle:'Compartilhar música'});}catch(e){/* arquivo já foi salvo */}
    setStatus('Arquivo salvo em Documentos: '+filename);
  }else{
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);
    setStatus('Download iniciado: '+filename);
  }
}
function blobToBase64(blob){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=reject;r.readAsDataURL(blob);});}
function makeWav(buffer){
  const channels=buffer.numberOfChannels, length=buffer.length, rate=buffer.sampleRate, bytes= new ArrayBuffer(44+length*channels*2),v=new DataView(bytes);
  const write=(o,s)=>{for(let i=0;i<s.length;i++)v.setUint8(o+i,s.charCodeAt(i));};
  write(0,'RIFF');v.setUint32(4,36+length*channels*2,true);write(8,'WAVE');write(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,channels,true);v.setUint32(24,rate,true);v.setUint32(28,rate*channels*2,true);v.setUint16(32,channels*2,true);v.setUint16(34,16,true);write(36,'data');v.setUint32(40,length*channels*2,true);
  let offset=44;for(let i=0;i<length;i++)for(let c=0;c<channels;c++){let s=Math.max(-1,Math.min(1,buffer.getChannelData(c)[i]));v.setInt16(offset,s<0?s*32768:s*32767,true);offset+=2;}
  return new Blob([bytes],{type:'audio/wav'});
}
async function renderSong(){
  stop();setStatus('Preparando sua música...');
  const rate=44100, beat=60/bpm/4, duration=steps*beat*4, offline=new OfflineAudioContext(2,Math.ceil(rate*(duration+.8)),rate), out=offline.destination;
  const oldCtx=audioCtx, oldMaster=master; audioCtx=offline;master=out;
  for(let s=0;s<steps;s++)for(const inst of instruments)if(pattern[inst.id][s])await playSound(inst.id,s*beat);
  const rendered=await offline.startRendering();audioCtx=oldCtx;master=oldMaster;return rendered;
}
document.querySelector('#exportWav').onclick=async()=>{try{const b=await renderSong();await saveBlob(makeWav(b),getName('wav'));}catch(e){console.error(e);setStatus('Não foi possível exportar WAV: '+e.message);}};
document.querySelector('#exportMp3').onclick=async()=>{
  try{
    const b=await renderSong();
    if(!lamejs.Mp3Encoder){setStatus('Codificador MP3 indisponível nesta compilação. Você também pode exportar WAV.');return;}
    const channels=Math.min(2,b.numberOfChannels), encoder=new lamejs.Mp3Encoder(channels,b.sampleRate,192), left=b.getChannelData(0), right=channels===2?b.getChannelData(1):null;
    const chunk=1152, parts=[];
    for(let i=0;i<left.length;i+=chunk){
      const l=new Int16Array(Math.min(chunk,left.length-i)),r=channels===2?new Int16Array(l.length):null;
      for(let j=0;j<l.length;j++){l[j]=Math.max(-32768,Math.min(32767,left[i+j]*32767));if(r)r[j]=Math.max(-32768,Math.min(32767,right[i+j]*32767));}
      const data=channels===2?encoder.encodeBuffer(l,r):encoder.encodeBuffer(l);if(data.length)parts.push(new Uint8Array(data));
    }
    const end=encoder.flush();if(end.length)parts.push(new Uint8Array(end));
    await saveBlob(new Blob(parts,{type:'audio/mpeg'}),getName('mp3'));
  }catch(e){console.error(e);setStatus('Erro ao exportar MP3: '+e.message);}
};
document.querySelector('#record').onclick=async()=>{
  try{micStream=await navigator.mediaDevices.getUserMedia({audio:true});recordedChunks=[];mediaRecorder=new MediaRecorder(micStream);
    mediaRecorder.ondataavailable=e=>{if(e.data.size)recordedChunks.push(e.data);};
    mediaRecorder.onstop=()=>{const blob=new Blob(recordedChunks,{type:mediaRecorder.mimeType||'audio/webm'});const url=URL.createObjectURL(blob);const player=document.querySelector('#recordingPlayer');player.src=url;player.hidden=false;setStatus('Gravação pronta. Use o player para ouvir.');micStream.getTracks().forEach(t=>t.stop());};
    mediaRecorder.start();document.querySelector('#record').disabled=true;document.querySelector('#stopRecord').disabled=false;setStatus('Gravando pelo microfone...');
  }catch(e){setStatus('Permita o acesso ao microfone para gravar. '+e.message);}
};
document.querySelector('#stopRecord').onclick=()=>{if(mediaRecorder?.state==='recording')mediaRecorder.stop();document.querySelector('#record').disabled=false;document.querySelector('#stopRecord').disabled=true;};
document.querySelector('#saveProject').onclick=async()=>{
  const data={name:projectName,bpm,pattern};await saveBlob(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),getName('json'));
};


// Downloader: accepts direct audio-file URLs only. It intentionally does not extract
// audio from streaming pages or bypass DRM, authentication, or platform restrictions.
const audioUrlInput=document.querySelector('#audioUrl');
document.querySelector('#clearAudioUrl').onclick=()=>{audioUrlInput.value='';setStatus('Link limpo.');};
document.querySelector('#downloadAudio').onclick=async()=>{
  const raw=audioUrlInput.value.trim();
  let url;
  try{url=new URL(raw);}catch(e){setStatus('Informe um link HTTPS válido para um arquivo de áudio.');return;}
  if(!['https:','http:'].includes(url.protocol)){setStatus('Por segurança, use um link HTTP ou HTTPS.');return;}
  if(url.username||url.password){setStatus('Links com usuário ou senha embutidos não são aceitos.');return;}
  const button=document.querySelector('#downloadAudio');button.disabled=true;setStatus('Verificando e baixando o arquivo...');
  try{
    const response=await fetch(url.href,{method:'GET'});
    if(!response.ok)throw new Error('O servidor respondeu HTTP '+response.status+'.');
    const type=(response.headers.get('content-type')||'').toLowerCase();
    const blob=await response.blob();
    const audioType=/audio\//.test(type)||/\.(mp3|wav|ogg|oga|m4a|aac|flac|opus)(?:$|[?#])/i.test(url.pathname);
    if(!audioType)throw new Error('O link não parece apontar diretamente para um arquivo de áudio (MP3, WAV, OGG, M4A, AAC, FLAC ou OPUS).');
    if(!blob.size)throw new Error('O arquivo recebido está vazio.');
    const extMatch=url.pathname.match(/\.(mp3|wav|ogg|oga|m4a|aac|flac|opus)$/i);
    const ext=extMatch?extMatch[1].toLowerCase():(type.includes('mpeg')?'mp3':type.includes('wav')?'wav':type.includes('ogg')?'ogg':type.includes('mp4')?'m4a':'audio');
    const safeBase=(url.pathname.split('/').pop()||'audio').replace(/\.[^.]+$/,'').replace(/[^a-z0-9-_]/gi,'_').slice(0,50)||'audio';
    await saveBlob(blob, safeBase+'.'+ext);
    setStatus('Download concluído. Verifique Documentos ou a opção de compartilhamento.');
  }catch(e){
    console.error(e);
    const cors=/failed to fetch|networkerror|load failed/i.test(e.message);
    setStatus(cors?'Não foi possível acessar o link. O site pode bloquear downloads externos (CORS) ou exigir autorização. Use um link direto permitido.':e.message);
  }finally{button.disabled=false;}
};
