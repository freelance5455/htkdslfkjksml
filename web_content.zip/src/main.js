import * as THREE from 'three';
import { AtmosphericLighting } from './gfx/AtmosphericLighting.js';
import { ThirdPersonCamera } from './core/Camera.js';
import { PlayerController } from './entities/PlayerController.js';
import { CombatSystem } from './weapons/CombatSystem.js';
import { InventorySystem } from './inventory/InventorySystem.js';
import { HealthSystem } from './entities/HealthSystem.js';
import { ZombieAI } from './entities/AI/ZombieAI.js';
import { LickerAI } from './entities/AI/LickerAI.js';
import { MrXAI } from './entities/AI/MrXAI.js';
import { BossAI } from './entities/AI/BossAI.js';
import { WorldBuilder } from './world/WorldBuilder.js';
import { DoorSystem } from './world/DoorSystem.js';
import { MapUI } from './ui/MapUI.js';
import { ObjectiveManager } from './ui/ObjectiveManager.js';
import { MedallionPuzzle, SafeCombinationPuzzle } from './puzzles/Puzzles.js';
import { SaveManager } from './core/SaveManager.js';
import { audioManager } from './audio/AudioManager.js';

class GameEngine {
  constructor() {
    this.canvas = document.getElementById('canvas3d');
    this.uiLayer = document.getElementById('ui-layer');

    // Setup Three.js WebGL Renderer
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, alpha: false });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100);

    // Engine Systems
    this.lighting = new AtmosphericLighting(this.scene);
    this.player = new PlayerController(this.scene, this.camera);
    this.cameraManager = new ThirdPersonCamera(this.camera, this.player.mesh);
    this.combat = new CombatSystem(this.scene, this.player, this.cameraManager);
    this.inventory = new InventorySystem();
    this.healthSystem = new HealthSystem(this.player);
    this.world = new WorldBuilder(this.scene);
    this.doorSystem = new DoorSystem(this.scene);
    this.mapUI = new MapUI(this.uiLayer);
    this.objectives = new ObjectiveManager();

    // Puzzles
    this.medallionPuzzle = new MedallionPuzzle();
    this.safePuzzle = new SafeCombinationPuzzle();

    // World & Enemies Setup
    this.world.buildRaccoonCityStreets();
    this.world.buildRPDPoliceStation();
    this.world.buildNESTSecretLab();

    // Spawn Doors
    this.mainDoor = this.doorSystem.addDoor(new THREE.Vector3(0, 0, 15), 'key_spade', 'RPD Main Hall');
    this.nestDoor = this.doorSystem.addDoor(new THREE.Vector3(0, 0, 65), 'key_card_nest', 'NEST Lab');

    // Spawn Enemies
    this.enemies = [
      new ZombieAI(this.scene, new THREE.Vector3(2, 0, 8)),
      new ZombieAI(this.scene, new THREE.Vector3(-3, 0, 12)),
      new LickerAI(this.scene, new THREE.Vector3(5, 0, 32)),
      new MrXAI(this.scene, new THREE.Vector3(-10, 0, 25)),
      new BossAI(this.scene, new THREE.Vector3(0, 0, 75))
    ];

    // Selected Inventory Slot for Combination
    this.selectedInvSlot = null;

    // Game Loop Timer
    this.clock = new THREE.Clock();
    this.gameState = 'MENU'; // MENU, PLAYING, INVENTORY, PUZZLE, GAMEOVER, VICTORY

    this.setupUI();
    this.setupWindowResize();

    // Start Animation Loop
    this.animate = this.animate.bind(this);
    requestAnimationFrame(this.animate);
  }

  setupUI() {
    this.renderMenuUI();

    // Mouse Shoot listener
    window.addEventListener('mousedown', (e) => {
      if (e.button === 0 && this.gameState === 'PLAYING' && this.player.isAiming) {
        this.combat.performAttack(this.enemies);
      }
    });

    // Keydown listeners for HUD menus
    window.addEventListener('keydown', (e) => {
      if (this.gameState !== 'PLAYING' && this.gameState !== 'INVENTORY' && this.gameState !== 'MAP') return;

      if (e.code === 'KeyI' || e.code === 'Tab') {
        e.preventDefault();
        this.toggleInventory();
      }
      if (e.code === 'KeyM') {
        e.preventDefault();
        this.mapUI.toggle();
      }
      if (e.code === 'KeyE') {
        this.checkInteraction();
      }
    });
  }

  checkInteraction() {
    const pPos = this.player.mesh.position;

    // Check doors
    for (const d of this.doorSystem.doors) {
      if (pPos.distanceTo(d.group.position) < 2.5) {
        const result = this.doorSystem.interactWithDoor(d, this.inventory);
        this.showToast(result.message);
        return;
      }
    }

    // Check world interactables (Typewriter, Item Box, Puzzle)
    for (const obj of this.world.interactables) {
      if (pPos.distanceTo(obj.mesh.position) < 3.0) {
        if (obj.type === 'typewriter') {
          SaveManager.saveGame(this.player, this.objectives, this.inventory);
          this.showToast('💾 تم حفظ اللعبة بنجاح عند الآلة الكاتبة!');
        } else if (obj.type === 'item_box') {
          this.toggleInventory(true); // Open with Item Box mode
        } else if (obj.type === 'statue_puzzle') {
          this.openPuzzleModal();
        } else if (obj.type === 'nest_escape') {
          this.triggerVictory();
        }
        return;
      }
    }
  }

  showToast(msg) {
    let toast = document.getElementById('toast-msg');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'toast-msg';
      toast.style.cssText = `
        position: absolute;
        bottom: 120px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(0,0,0,0.85);
        border: 1px solid #ffcc00;
        color: #fff;
        padding: 12px 24px;
        font-weight: bold;
        font-size: 16px;
        border-radius: 6px;
        z-index: 200;
        pointer-events: none;
      `;
      this.uiLayer.appendChild(toast);
    }
    toast.innerText = msg;
    toast.style.display = 'block';
    setTimeout(() => { toast.style.display = 'none'; }, 3000);
  }

  openPuzzleModal() {
    this.gameState = 'PUZZLE';
    let pEl = document.getElementById('puzzle-modal');
    if (!pEl) {
      pEl = document.createElement('div');
      pEl.id = 'puzzle-modal';
      pEl.className = 'interactive';
      pEl.style.cssText = `
        position: absolute;
        top: 20%;
        left: 30%;
        width: 40%;
        background: rgba(15,20,30,0.95);
        border: 2px solid #d4af37;
        color: #fff;
        padding: 24px;
        border-radius: 8px;
        text-align: center;
        z-index: 250;
      `;
      this.uiLayer.appendChild(pEl);
    }
    pEl.innerHTML = `
      <h2 style="color:#d4af37; margin-bottom:12px;">🏛️ لغز تمثال Goddess Statue</h2>
      <p>أدخل رموز الميداليات الثلاث (Lion, Crown, Bird) لفتح الممر:</p>
      <div style="display:flex; justify-content:center; gap:10px; margin:20px 0;">
        <select id="p1" style="padding:8px; font-weight:bold;"><option>lion</option><option>twin</option><option>maiden</option></select>
        <select id="p2" style="padding:8px; font-weight:bold;"><option>crown</option><option>scale</option><option>bow</option></select>
        <select id="p3" style="padding:8px; font-weight:bold;"><option>bird</option><option>worm</option><option>snake</option></select>
      </div>
      <button id="submit-puz-btn" style="background:#28a745; color:#fff; border:none; padding:10px 20px; font-weight:bold; cursor:pointer; margin-right:10px;">تأكيد الحل</button>
      <button id="close-puz-btn" style="background:#dc3545; color:#fff; border:none; padding:10px 20px; font-weight:bold; cursor:pointer;">إلغاء</button>
    `;

    document.getElementById('submit-puz-btn').onclick = () => {
      const c1 = document.getElementById('p1').value;
      const c2 = document.getElementById('p2').value;
      const c3 = document.getElementById('p3').value;

      if (this.medallionPuzzle.solveStatue('lion', [c1, c2, c3])) {
        this.showToast('🔓 تم حل اللغز وفتح مفتاح spade_key في مخزنك!');
        this.inventory.addItem({ id: 'key_spade', name: 'Spade Key', type: 'key', count: 1, icon: '🗝️', description: 'مفتاح رمزي يفتح أبواب RPD.' });
        this.objectives.completeObjective('find_medallions');
        pEl.remove();
        this.gameState = 'PLAYING';
      } else {
        this.showToast('❌ الرموز غير صحيحة!');
      }
    };

    document.getElementById('close-puz-btn').onclick = () => {
      pEl.remove();
      this.gameState = 'PLAYING';
    };
  }

  renderMenuUI() {
    this.uiLayer.innerHTML = `
      <div id="main-menu" class="interactive" style="
        position: absolute; width: 100%; height: 100%;
        background: radial-gradient(circle, #1a0505 0%, #000 100%);
        display: flex; flex-direction: column; justify-content: center; align-items: center;
        z-index: 500;
      ">
        <h1 style="font-size: 52px; color: #cc1111; letter-spacing: 4px; text-shadow: 0 0 20px #ff0000; margin-bottom: 8px;">RESIDENT EVIL 2</h1>
        <h3 style="color: #aaa; margin-bottom: 40px; font-weight: 300;">BIOHAZARD AI 3D EDITION</h3>

        <div style="display:flex; flex-direction:column; gap:16px; width: 280px;">
          <button id="btn-newgame" style="padding:14px; font-size:18px; font-weight:bold; background:#a50000; color:#fff; border:none; border-radius:4px; cursor:pointer; box-shadow:0 0 10px #ff0000;">لعبة جديدة (New Game)</button>
          <button id="btn-loadgame" style="padding:14px; font-size:18px; font-weight:bold; background:#223355; color:#fff; border:1px solid #446699; border-radius:4px; cursor:pointer;">متابعة (Continue)</button>
        </div>
      </div>
    `;

    document.getElementById('btn-newgame')?.addEventListener('click', () => {
      audioManager.init();
      document.getElementById('main-menu').remove();
      this.gameState = 'PLAYING';
      this.renderHUDUI();
    });

    document.getElementById('btn-loadgame')?.addEventListener('click', () => {
      audioManager.init();
      if (SaveManager.loadGame(this.player, this.objectives, this.inventory)) {
        document.getElementById('main-menu').remove();
        this.gameState = 'PLAYING';
        this.renderHUDUI();
        this.showToast('تم تحميل التقدم المحفوظ بنجاح!');
      } else {
        alert('لا يوجد ملف حفظ سابق!');
      }
    });
  }

  renderHUDUI() {
    const hudContainer = document.createElement('div');
    hudContainer.id = 'hud-ui';
    hudContainer.style.cssText = `
      position: absolute; top:0; left:0; width:100%; height:100%; pointer-events:none;
    `;

    const status = this.healthSystem.getStatus();

    hudContainer.innerHTML = `
      <!-- Top Right Health EKG & Objective -->
      <div style="position:absolute; top:20px; right:20px; background:rgba(0,0,0,0.7); border:1px solid #444; padding:12px 20px; border-radius:6px; text-align:right;">
        <div style="font-size:14px; color:#aaa;">الحالة: <span id="hud-status" style="font-weight:bold; color:${status.color};">${status.label}</span></div>
        <div style="font-size:13px; color:#88ccff; margin-top:6px;">الهدف: <span id="hud-objective">${this.objectives.getCurrentObjective().text}</span></div>
      </div>

      <!-- Bottom Right Weapon Ammo -->
      <div style="position:absolute; bottom:20px; right:20px; background:rgba(0,0,0,0.85); border:2px solid #555; padding:16px 28px; border-radius:8px; text-align:center;">
        <div id="hud-weapon-name" style="font-size:18px; font-weight:bold; color:#f4a261;">VP70 Handgun</div>
        <div id="hud-ammo" style="font-size:32px; font-weight:bold; color:#fff; margin-top:4px;">15 / 30</div>
      </div>

      <!-- Touch Controls Mobile Overlay -->
      <div id="touch-controls" class="interactive" style="position:absolute; bottom:20px; left:20px; display:flex; gap:12px;">
        <button id="btn-touch-shoot" style="width:60px; height:60px; border-radius:50%; background:#aa1111; color:#fff; font-weight:bold; border:2px solid #fff;">إطلاق</button>
        <button id="btn-touch-aim" style="width:60px; height:60px; border-radius:50%; background:#2255aa; color:#fff; font-weight:bold; border:2px solid #fff;">تصويب</button>
        <button id="btn-touch-interact" style="width:60px; height:60px; border-radius:50%; background:#22aa55; color:#fff; font-weight:bold; border:2px solid #fff;">تفاعل</button>
      </div>
    `;

    this.uiLayer.appendChild(hudContainer);

    // Touch listeners
    document.getElementById('btn-touch-shoot')?.addEventListener('click', () => {
      this.combat.performAttack(this.enemies);
    });
    document.getElementById('btn-touch-aim')?.addEventListener('touchstart', () => {
      this.player.isAiming = true;
    });
    document.getElementById('btn-touch-aim')?.addEventListener('touchend', () => {
      this.player.isAiming = false;
    });
    document.getElementById('btn-touch-interact')?.addEventListener('click', () => {
      this.checkInteraction();
    });
  }

  toggleInventory(isItemBox = false) {
    if (this.gameState === 'INVENTORY') {
      document.getElementById('inv-modal')?.remove();
      this.selectedInvSlot = null;
      this.gameState = 'PLAYING';
      return;
    }

    this.gameState = 'INVENTORY';
    const invEl = document.createElement('div');
    invEl.id = 'inv-modal';
    invEl.className = 'interactive';
    invEl.style.cssText = `
      position: absolute; top:10%; left:10%; width:80%; height:80%;
      background: rgba(10,12,18,0.96); border:2px solid #4466aa; border-radius:8px;
      padding:24px; color:#fff; display:flex; flex-direction:column; z-index:300;
    `;

    invEl.innerHTML = `
      <div style="display:flex; justify-between; border-bottom:1px solid #444; padding-bottom:10px;">
        <h2>🎒 ${isItemBox ? 'صندوق التخزين والمخزون (ITEM BOX)' : 'الحقيبة والمخزون (INVENTORY)'}</h2>
        <button id="close-inv-btn" style="background:#881111; color:#fff; border:none; padding:8px 16px; font-weight:bold; cursor:pointer;">إغلاق (I)</button>
      </div>

      <div style="display:flex; flex:1; gap:20px; margin-top:20px;">
        <!-- Player Slots -->
        <div style="flex:1;">
          <h3>محتويات الحقيبة (${this.inventory.items.length}/${this.inventory.maxSlots})</h3>
          <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:12px; margin-top:12px;">
            ${this.inventory.items.map((item, idx) => `
              <div class="inv-slot" data-idx="${idx}" style="background:#1a2233; border:1px solid ${this.selectedInvSlot === idx ? '#ffcc00' : '#335588'}; border-radius:6px; padding:12px; text-align:center; cursor:pointer;">
                <div style="font-size:32px;">${item.icon}</div>
                <div style="font-size:12px; font-weight:bold; margin-top:6px;">${item.name}</div>
                <div style="font-size:11px; color:#aaa;">x${item.count}</div>
              </div>
            `).join('')}
          </div>
        </div>

        ${isItemBox ? `
          <!-- Item Box Storage Slots -->
          <div style="flex:1; border-right:1px solid #334466; padding-right:20px;">
            <h3>صندوق التخزين (${this.inventory.itemBox.length} عناصر)</h3>
            <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:12px; margin-top:12px;">
              ${this.inventory.itemBox.map((item, idx) => `
                <div class="box-slot" data-boxidx="${idx}" style="background:#2d1b1b; border:1px solid #883333; border-radius:6px; padding:12px; text-align:center; cursor:pointer;">
                  <div style="font-size:32px;">${item.icon}</div>
                  <div style="font-size:12px; font-weight:bold; margin-top:6px;">${item.name}</div>
                  <div style="font-size:11px; color:#aaa;">x${item.count}</div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}
      </div>
    `;

    this.uiLayer.appendChild(invEl);

    document.getElementById('close-inv-btn')?.addEventListener('click', () => this.toggleInventory());

    // Player inventory slot click (Use, Combine, Transfer to Box)
    invEl.querySelectorAll('.inv-slot').forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.getAttribute('data-idx'));
        const item = this.inventory.items[idx];
        if (!item) return;

        if (isItemBox) {
          // Transfer from inventory to Item Box
          if (this.inventory.moveToBox(idx)) {
            document.getElementById('inv-modal')?.remove();
            this.toggleInventory(true);
          }
        } else {
          // Normal Inventory Mode
          if (this.selectedInvSlot === null) {
            // Select first item for combine / usage
            if (item.type === 'herb') {
              if (this.healthSystem.useItem(item)) {
                this.inventory.removeItem(idx);
                this.showToast(`استخدمت ${item.name} واستعدت صحتك!`);
                this.toggleInventory();
                return;
              }
            } else if (item.type === 'weapon') {
              this.player.currentWeapon = item.id;
              this.showToast(`تم تجهيز سلاح ${item.name}`);
              this.toggleInventory();
              return;
            }
            this.selectedInvSlot = idx;
            this.toggleInventory(); // Re-render selected border
          } else {
            // Second item selected -> Try combination
            if (this.inventory.combineItems(this.selectedInvSlot, idx)) {
              this.showToast('✨ تم دمج العناصر بنجاح!');
            } else {
              this.showToast('لا يمكن دمج هذين العنصرين!');
            }
            this.selectedInvSlot = null;
            this.toggleInventory();
          }
        }
      });
    });

    // Storage Box slot click (Transfer to Inventory)
    if (isItemBox) {
      invEl.querySelectorAll('.box-slot').forEach(el => {
        el.addEventListener('click', () => {
          const boxIdx = parseInt(el.getAttribute('data-boxidx'));
          if (this.inventory.takeFromBox(boxIdx)) {
            document.getElementById('inv-modal')?.remove();
            this.toggleInventory(true);
          } else {
            this.showToast('حقيبتك مليئة بالعناصر!');
          }
        });
      });
    }
  }

  triggerVictory() {
    this.gameState = 'VICTORY';
    this.uiLayer.innerHTML = `
      <div class="interactive" style="position:absolute; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.9); color:#fff; display:flex; flex-direction:column; justify-center; align-items:center; z-index:600;">
        <h1 style="color:#00ff66; font-size:48px;">🏆 تم الهروب بنجاح! VICTORY</h1>
        <p style="font-size:20px; margin-top:16px;">لقد نجحت في الهروب من Raccoon City والمختبر السري NEST!</p>
        <button onclick="location.reload()" style="margin-top:30px; padding:12px 24px; background:#a50000; color:#fff; font-weight:bold; border:none; cursor:pointer;">إعادة اللعب</button>
      </div>
    `;
  }

  triggerGameOver() {
    this.gameState = 'GAMEOVER';
    this.uiLayer.innerHTML = `
      <div class="interactive" style="position:absolute; top:0; left:0; width:100%; height:100%; background:rgba(100,0,0,0.9); color:#fff; display:flex; flex-direction:column; justify-center; align-items:center; z-index:600;">
        <h1 style="color:#ff0000; font-size:52px;">YOU DIED</h1>
        <p style="font-size:20px; margin-top:16px;">لقد قضت عليك الوحوش في Raccoon City...</p>
        <button onclick="location.reload()" style="margin-top:30px; padding:12px 24px; background:#fff; color:#000; font-weight:bold; border:none; cursor:pointer;">إعادة المحاولة</button>
      </div>
    `;
  }

  setupWindowResize() {
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });
  }

  animate() {
    requestAnimationFrame(this.animate);

    const delta = this.clock.getDelta();

    if (this.gameState === 'PLAYING') {
      this.player.update(delta, this.world.colliders, this.doorSystem.doors);
      this.cameraManager.update(delta, this.player.isAiming);
      this.lighting.update(delta);
      this.combat.update(delta);

      // Check Game Over
      if (this.player.isDead) {
        this.triggerGameOver();
        return;
      }

      // Update Enemies
      this.enemies.forEach(e => e.update(delta, this.player));

      // Update HUD elements
      const status = this.healthSystem.getStatus();
      const statusEl = document.getElementById('hud-status');
      if (statusEl) {
        statusEl.innerText = status.label;
        statusEl.style.color = status.color;
      }

      const weaponNameEl = document.getElementById('hud-weapon-name');
      if (weaponNameEl) {
        const weaponNames = {
          handgun: 'VP70 Handgun',
          shotgun: 'W-870 Shotgun',
          magnum: 'Lightning Hawk Magnum',
          knife: 'Combat Knife'
        };
        weaponNameEl.innerText = weaponNames[this.player.currentWeapon] || this.player.currentWeapon;
      }

      const ammoEl = document.getElementById('hud-ammo');
      if (ammoEl) {
        const weaponKey = this.player.currentWeapon;
        if (weaponKey === 'knife') {
          ammoEl.innerText = `متانة: 100%`;
        } else {
          ammoEl.innerText = `${this.player.ammo[weaponKey] || 0} / ${this.player.ammo[weaponKey + 'Reserve'] || 0}`;
        }
      }
    }

    this.renderer.render(this.scene, this.camera);
  }
}

window.addEventListener('DOMContentLoaded', () => {
  new GameEngine();
});
