import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { GLTFLoader } from 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/loaders/GLTFLoader.js';
import { OBJLoader } from 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/loaders/OBJLoader.js';

const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const boot=$('#boot'), app=$('#app'), canvas=$('#game');
const scene=new THREE.Scene(); scene.background=new THREE.Color(0xcbd6df); scene.fog=new THREE.Fog(0xcbd6df,35,100);
const camera=new THREE.PerspectiveCamera(55,1,.1,250);
const renderer=new THREE.WebGLRenderer({canvas,antialias:true, powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.6)); renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.outputColorSpace=THREE.SRGBColorSpace;
scene.add(new THREE.HemisphereLight(0xeaf4ff,0x7c8791,2.0));
const sun=new THREE.DirectionalLight(0xffffff,2.0); sun.position.set(-12,22,10); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024); sun.shadow.camera.left=-35; sun.shadow.camera.right=35; sun.shadow.camera.top=35; sun.shadow.camera.bottom=-35; scene.add(sun);
const mat=(c,r=.85)=>new THREE.MeshStandardMaterial({color:c,roughness:r});
const mats={ground:mat(0x7c9c78),tile:mat(0x91a9b9),skin:mat(0xe1b99c),shirt:mat(0x4c83ad),pants:mat(0x384b66),dark:mat(0x28323b),white:mat(0xf4f4ee),red:mat(0xb85b55),wood:mat(0x997553)};
let worldGroup=new THREE.Group(); scene.add(worldGroup);
let avatar=new THREE.Group(); scene.add(avatar); let avatarParts={}; let imported=null;
const player={x:0,z:0,y:0,vy:0,rot:0,speed:6,grounded:true};
let keys={},joy={x:0,y:0},lastTime=0,face='smile',style='classic',skinColor=0xe1b99c,outfitColor=0x4c83ad,pantsColor=0x384b66;
function block(parent,name,size,pos,material,round=0){let g=new THREE.BoxGeometry(...size);let m=new THREE.Mesh(g,material);m.name=name;m.position.set(...pos);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function makeWorld(kind){
  while(worldGroup.children.length) {const c=worldGroup.children.pop(); c.geometry?.dispose();}
  const ground=block(worldGroup,'ground',[180,.5,180],[0,-.3,0],mat(kind==='town'?0x7b8e78:0x83a1b2));ground.receiveShadow=true;
  const grid=new THREE.GridHelper(180,90,0x627d90,0x9bb0bd);grid.position.y=-.04;worldGroup.add(grid);
  if(kind==='baseplate'){for(let x=-4;x<=4;x++)for(let z=-4;z<=4;z++){if((x+z)%2===0)block(worldGroup,'tile',[9,.08,9],[x*10,.02,z*10],mat(0x8ba8b9));}}
  if(kind==='town'){
    // Small original block town, inspired by classic low-poly sandbox maps.
    for(let i=-2;i<=2;i++){block(worldGroup,'road',[8,.12,48],[i*11,.02,0],mat(0x606d76));}
    for(let z=-2;z<=2;z++)block(worldGroup,'crossroad',[54,.13,7],[0,.03,z*10],mat(0x606d76));
    for(let x=-2;x<=2;x++)for(let z=-2;z<=2;z++){if(Math.abs(x)+Math.abs(z)<2)continue;let h=3+(Math.abs(x*7+z*3)%4);let b=block(worldGroup,'house',[7,h,7],[x*11,h/2,z*10],mat([0xc4a27d,0xa8b7c3,0xc6c5a4,0x9daeb1][(x+z+8)%4]));block(worldGroup,'roof',[7.5,.35,7.5],[x*11,h+.18,z*10],mat(0x665b58));}
    for(let i=0;i<8;i++){let t=block(worldGroup,'tree-trunk',[.6,2,.6],[-22+i*6,1,23],mat(0x76543c));let crown=new THREE.Mesh(new THREE.SphereGeometry(1.6,8,6),mat(0x638b69));crown.position.set(-22+i*6,3,23);crown.castShadow=true;worldGroup.add(crown)}
  }
  if(kind==='social'){
    block(worldGroup,'floor',[40,.4,40],[0,0,0],mat(0x8b8c9e));
    for(let x of [-20,20])for(let z of [-20,20])block(worldGroup,'wall',[.5,6,40],[x,3,0],mat(0xabb5c2));
    block(worldGroup,'back-wall',[40,6,.5],[0,3,-20],mat(0xabb5c2));
    for(let i=0;i<5;i++){let p=block(worldGroup,'seat',[3,1,1.5],[-12+i*6,.7,-10],mat(0x7796ae));}
    for(let i=0;i<4;i++)block(worldGroup,'planter',[3,1,3],[-12+i*8,.5,12],mat(0x708b72));
    block(worldGroup,'stage',[12,.6,5],[0,.3,7],mat(0x6d83a0));
  }
  $('#world-name').textContent=({baseplate:'CLASSIC BASEPLATE',town:'OLD TOWN',social:'SOCIAL CONDO'})[kind];
  $$('.world-row').forEach(b=>b.classList.toggle('selected',b.dataset.world===kind));
  player.x=0;player.z=0;player.y=0;player.vy=0;
}
function createAvatar(){
  while(avatar.children.length){let c=avatar.children.pop();c.geometry?.dispose();}
  avatarParts={};
  const skin=mat(skinColor),shirt=mat(outfitColor),pants=mat(pantsColor),dark=mat(0x252b30),white=mat(0xf8f8f3),blush=mat(0xd78e8e);
  const torso=block(avatar,'Torso',[style==='shaped'?1.35:1.5,1.55,.72],[0,2.25,0],shirt);avatarParts.torso=torso;
  const head=block(avatar,'Head',[.92,.92,.86],[0,3.55,0],skin);head.geometry=new THREE.BoxGeometry(.92,.92,.86,2,2,2);avatarParts.head=head;
  const armL=block(avatar,'Left Arm',[.48,1.5,.52],[-1.05,2.25,0],skin),armR=block(avatar,'Right Arm',[.48,1.5,.52],[1.05,2.25,0],skin);
  avatarParts.armL=armL;avatarParts.armR=armR;
  if(style==='shaped'){
    const upper=block(avatar,'UpperBodyShape',[1.25,.48,.8],[0,2.35,.03],skin);
    upper.scale.set(1,1,.92);
  }
  const legL=block(avatar,'Left Leg',[.62,1.45,.65],[-.37,.75,0],pants),legR=block(avatar,'Right Leg',[.62,1.45,.65],[.37,.75,0],pants);avatarParts.legL=legL;avatarParts.legR=legR;
  // Face details on the front (-Z)
  const eyeGeo=new THREE.SphereGeometry(.085,12,8);
  for(let x of [-.2,.2]){let e=new THREE.Mesh(eyeGeo,white);e.position.set(x,3.62,-.438);avatar.add(e);let pupil=new THREE.Mesh(new THREE.SphereGeometry(.045,10,8),dark);pupil.position.set(x,3.61,-.51);avatar.add(pupil);}
  if(face!=='cool'){
    const browMat=mat(0x292a2d);for(let x of [-.2,.2]){let brow=block(avatar,'brow',[.2,.035,.035],[x,3.78,-.45],browMat);}
    const mouth=new THREE.Mesh(new THREE.TorusGeometry(.105,.018,6,16,Math.PI),dark);mouth.position.set(0,3.39,-.45);mouth.rotation.z=Math.PI;avatar.add(mouth);
    for(let x of [-.29,.29]){let b=new THREE.Mesh(new THREE.SphereGeometry(.07,10,8),blush);b.scale.set(1,.45,.2);b.position.set(x,3.48,-.44);avatar.add(b);}
  }else{
    const glasses=block(avatar,'glasses',[.65,.09,.04],[0,3.62,-.49],dark);
  }
  if($('#hat')?.checked){let cap=block(avatar,'Cap',[1,.22,.9],[0,4.05,0],mat(0x315a83));block(avatar,'Cap brim',[.9,.08,.5],[0,3.98,-.48],mat(0x315a83));}
  if($('#backpack')?.checked){block(avatar,'Backpack',[.8,.8,.35],[0,2.35,.5],mat(0x6b5547));}
  avatar.position.set(player.x,player.y,player.z);
}
function resize(){let w=$('#viewport').clientWidth,h=$('#viewport').clientHeight;if(!w||!h)return;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false)}
function toast(t){let el=$('#toast');el.textContent=t;el.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove('show'),2100)}
function changeWorld(kind){makeWorld(kind);toast('Loaded: '+kind.toUpperCase())}
function setTab(name){$$('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));$$('.tab-page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));if(innerWidth<760)$('#panel').classList.remove('closed')}
$$('.tab').forEach(b=>b.addEventListener('click',()=>setTab(b.dataset.tab)));
$$('[data-world]').forEach(b=>b.addEventListener('click',()=>changeWorld(b.dataset.world)));
$$('[data-style]').forEach(b=>b.addEventListener('click',()=>{$$('[data-style]').forEach(x=>x.classList.toggle('selected',x===b));style=b.dataset.style;createAvatar()}));
$$('[data-face]').forEach(b=>b.addEventListener('click',()=>{$$('[data-face]').forEach(x=>x.classList.toggle('selected',x===b));face=b.dataset.face;createAvatar()}));
function swatches(id,colors,initial,cb){let el=$(id);colors.forEach(c=>{let b=document.createElement('button');b.className='swatch'+(c===initial?' selected':'');b.style.background='#'+c.toString(16).padStart(6,'0');b.addEventListener('click',()=>{el.querySelectorAll('.swatch').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');cb(c)});el.append(b)})}
swatches('#skin-swatches',[0xe1b99c,0xf0d0b4,0x9b6d50,0x70503f,0xd3d3d3],skinColor,c=>{skinColor=c;createAvatar()});
swatches('#outfit-swatches',[0x4c83ad,0x9c4f50,0x4f806b,0x6e638f,0xe1e4e7,0x303943,0xd1a54e],outfitColor,c=>{outfitColor=c;createAvatar()});
$('#hat').addEventListener('change',createAvatar);$('#backpack').addEventListener('change',createAvatar);
$('#apply-avatar').addEventListener('click',()=>{createAvatar();toast('Avatar applied')});
$('#save-avatar').addEventListener('click',()=>{localStorage.setItem('hyosui-avatar',JSON.stringify({style,face,skinColor,outfitColor,pantsColor,hat:$('#hat').checked,backpack:$('#backpack').checked}));toast('Outfit saved on this device')});
try{let saved=JSON.parse(localStorage.getItem('hyosui-avatar'));if(saved){Object.assign({},{ });style=saved.style||style;face=saved.face||face;skinColor=saved.skinColor||skinColor;outfitColor=saved.outfitColor||outfitColor;$('#hat').checked=!!saved.hat;$('#backpack').checked=!!saved.backpack;}}catch{}
$('#btn-menu').addEventListener('click',()=>$('#menu-modal').classList.remove('hidden'));$('#close-menu').addEventListener('click',()=>$('#menu-modal').classList.add('hidden'));$('#resume').addEventListener('click',()=>$('#menu-modal').classList.add('hidden'));$('#exit-world').addEventListener('click',()=>{$('#menu-modal').classList.add('hidden');changeWorld('baseplate')});
function jump(){if(player.grounded){player.vy=7.5;player.grounded=false}}
$('#jump').addEventListener('pointerdown',e=>{e.preventDefault();jump()});$('#emote').addEventListener('click',()=>{avatarParts.armR.rotation.z=-1.5;setTimeout(()=>{if(avatarParts.armR)avatarParts.armR.rotation.z=0},900);toast('Wave emote')});
window.addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='Space'){e.preventDefault();jump()}if(e.code==='KeyE')$('#emote').click();if(e.code==='Escape')$('#btn-menu').click()});
window.addEventListener('keyup',e=>keys[e.code]=false);
const joyEl=$('#joystick'),stick=$('#stick');let joyActive=false;
joyEl.addEventListener('pointerdown',e=>{joyActive=true;joyEl.setPointerCapture(e.pointerId);moveJoy(e)});
joyEl.addEventListener('pointermove',e=>{if(joyActive)moveJoy(e)});
function moveJoy(e){let r=joyEl.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),len=Math.hypot(dx,dy),max=34;if(len>max){dx=dx/len*max;dy=dy/len*max}joy.x=dx/max;joy.y=dy/max;stick.style.transform=`translate(${dx}px,${dy}px)`}
function releaseJoy(){joyActive=false;joy.x=joy.y=0;stick.style.transform='translate(0,0)'}
joyEl.addEventListener('pointerup',releaseJoy);joyEl.addEventListener('pointercancel',releaseJoy);joyEl.addEventListener('lostpointercapture',releaseJoy);
$('#map-file').addEventListener('change',async e=>{
 const file=e.target.files[0];if(!file)return;const ext=file.name.split('.').pop().toLowerCase();$('#import-result').textContent='กำลังนำเข้า '+file.name+'...';
 try{let obj;if(ext==='glb'||ext==='gltf'){let url=URL.createObjectURL(file);obj=await new GLTFLoader().loadAsync(url);obj=obj.scene;obj.userData.objectUrl=url;}else if(ext==='obj'){let text=await file.text();obj=new OBJLoader().parse(text);}else throw Error('Unsupported file');
 if(imported){scene.remove(imported);disposeObject(imported)}imported=obj;imported.position.set(4,0,0);imported.scale.setScalar(1);scene.add(imported);$('#import-result').textContent='นำเข้าสำเร็จ: '+file.name;toast('3D model imported');}
 catch(err){$('#import-result').textContent='นำเข้าไม่สำเร็จ: '+err.message;toast('Import failed');}
});
function disposeObject(o){o.traverse?.(n=>{n.geometry?.dispose();if(n.material){(Array.isArray(n.material)?n.material:[n.material]).forEach(m=>m.dispose())}});if(o.userData.objectUrl)URL.revokeObjectURL(o.userData.objectUrl)}
$('#clear-import').addEventListener('click',()=>{if(imported){scene.remove(imported);disposeObject(imported);imported=null;$('#import-result').textContent='นำโมเดลออกแล้ว';toast('Imported model removed')}});
function animate(t){requestAnimationFrame(animate);let dt=Math.min((t-lastTime)/1000||0,.04);lastTime=t;
 let forward=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0)-joy.y;
 let side=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0)+joy.x;
 let v=new THREE.Vector3(side,0,-forward);if(v.length()>1)v.normalize();
 player.x+=v.x*player.speed*dt;player.z+=v.z*player.speed*dt;
 if(v.lengthSq()>.01){player.rot=Math.atan2(v.x,-v.z);avatar.rotation.y=THREE.MathUtils.lerp(avatar.rotation.y,player.rot,Math.min(1,dt*10));}
 player.vy-=19*dt;player.y+=player.vy*dt;if(player.y<=0){player.y=0;player.vy=0;player.grounded=true}
 avatar.position.set(player.x,player.y,player.z);
 let target=new THREE.Vector3(player.x,2.2+player.y,player.z);let desired=new THREE.Vector3(player.x+7,7+player.y,player.z+10);camera.position.lerp(desired,Math.min(1,dt*3));camera.lookAt(target);
 $('#coords').textContent=`X: ${player.x.toFixed(1)} · Z: ${player.z.toFixed(1)}`;
 renderer.render(scene,camera);
}
makeWorld('baseplate');createAvatar();resize();window.addEventListener('resize',resize);camera.position.set(7,7,10);camera.lookAt(0,2,0);requestAnimationFrame(animate);
boot.classList.add('hidden');app.classList.remove('hidden');
