// Root entrypoint for HTML-to-APK builders and Vite.
import '../www/js/boot.js';
