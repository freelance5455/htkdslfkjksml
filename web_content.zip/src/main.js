import "./style.css";

const STORAGE_KEY = "gatossapatos-ficha-v1";

const senseDefinitions = [
  { id: "visao", label: "Visão", cue: "O que chama seu olhar?", glyph: "◌", color: "peach" },
  { id: "audicao", label: "Audição", cue: "O que chega antes do resto?", glyph: ")))", color: "lilac" },
  { id: "olfato", label: "Olfato", cue: "Que pista mora no ar?", glyph: "∿", color: "sage" },
  { id: "paladar", label: "Paladar", cue: "Que sabor conta uma história?", glyph: "⌁", color: "yellow" },
  { id: "tato", label: "Tato", cue: "O que suas patinhas percebem?", glyph: "✧", color: "blue" },
];

const defaultSenses = Object.fromEntries(
  senseDefinitions.map(({ id }) => [id, { value: 0, lastRoll: null }]),
);

const emptyState = () => ({
  version: 1,
  name: "",
  player: "",
  species: "",
  shoe: "",
  concept: "",
  description: "",
  inventory: "",
  notes: "",
  motivation: "",
  danger: 0,
  dangerMax: 6,
  senses: structuredClone(defaultSenses),
  skills: [],
});

let state = loadState();
let saveTimer;

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!saved) return emptyState();
    const fresh = emptyState();
    return {
      ...fresh,
      ...saved,
      senses: { ...fresh.senses, ...(saved.senses || {}) },
      skills: Array.isArray(saved.skills) ? saved.skills : [],
      danger: clampNumber(saved.danger, 0, 20),
      dangerMax: clampNumber(saved.dangerMax, 1, 20),
    };
  } catch {
    return emptyState();
  }
}

function clampNumber(value, min, max) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return min;
  return Math.min(max, Math.max(min, Math.round(numeric)));
}

function saveState() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    const status = $("#saveState");
    status.classList.add("saved-now");
    status.innerHTML = '<span class="status-dot"></span>Salvo agora';
    setTimeout(() => {
      status.classList.remove("saved-now");
      status.innerHTML = '<span class="status-dot"></span>Salvo neste aparelho';
    }, 1800);
  }, 180);
}

function updateHero() {
  $("#heroCharacterName").textContent = state.name.trim() || "Sem nome ainda";
  $("#heroCharacterConcept").textContent = state.concept.trim() || "Preencha os dados ao lado";
}

function bindFormFields() {
  const fieldNames = ["name", "player", "species", "shoe", "concept", "description", "inventory", "notes", "motivation"];
  fieldNames.forEach((name) => {
    const field = $(`#${name}`);
    field.value = state[name] || "";
    field.addEventListener("input", (event) => {
      state[name] = event.target.value;
      if (name === "name") clearFieldError("name");
      updateHero();
      saveState();
    });
    if (name === "name") {
      field.addEventListener("blur", () => validateName(false));
    }
  });

  const dangerMax = $("#dangerMax");
  dangerMax.value = state.dangerMax;
  dangerMax.addEventListener("input", (event) => {
    state.dangerMax = clampNumber(event.target.value, 1, 20);
    event.target.value = state.dangerMax;
    state.danger = Math.min(state.danger, state.dangerMax);
    renderDanger();
    saveState();
  });
}

function renderSenses() {
  const grid = $("#sensesGrid");
  grid.innerHTML = senseDefinitions.map((sense) => {
    const current = state.senses[sense.id] || { value: 0, lastRoll: null };
    const rollText = current.lastRoll ? `d6: ${current.lastRoll.die} + ${current.value} = ${current.lastRoll.total}` : "Nenhuma rolagem ainda";
    return `
      <article class="sense-card ${sense.color}" data-sense="${sense.id}">
        <div class="sense-topline"><span class="sense-glyph" aria-hidden="true">${sense.glyph}</span><span class="sense-label">${sense.label}</span><span class="sense-value-display" id="display-${sense.id}">${current.value}</span></div>
        <p>${sense.cue}</p>
        <div class="sense-controls">
          <label class="sr-only" for="sense-${sense.id}">Valor de ${sense.label}</label>
          <input id="sense-${sense.id}" class="sense-input" type="number" min="0" max="10" inputmode="numeric" value="${current.value}" />
          <button class="roll-button" type="button" data-roll-sense="${sense.id}"><span aria-hidden="true">↯</span> Rolar d6</button>
        </div>
        <div class="roll-result" id="roll-${sense.id}">${rollText}</div>
      </article>`;
  }).join("");

  $$(".sense-input", grid).forEach((input) => {
    input.addEventListener("input", (event) => {
      const id = event.target.id.replace("sense-", "");
      const value = clampNumber(event.target.value, 0, 10);
      event.target.value = value;
      state.senses[id] = { ...(state.senses[id] || {}), value };
      $(`#display-${id}`).textContent = value;
      const currentRoll = state.senses[id].lastRoll;
      $(`#roll-${id}`).textContent = currentRoll ? `d6: ${currentRoll.die} + ${value} = ${currentRoll.die + value}` : "Nenhuma rolagem ainda";
      saveState();
    });
  });

  $$("[data-roll-sense]", grid).forEach((button) => {
    button.addEventListener("click", () => {
      const id = button.dataset.rollSense;
      const die = Math.floor(Math.random() * 6) + 1;
      const value = state.senses[id]?.value || 0;
      state.senses[id].lastRoll = { die, total: die + value };
      const result = $(`#roll-${id}`);
      result.textContent = `d6: ${die} + ${value} = ${die + value}`;
      result.classList.remove("roll-pop");
      void result.offsetWidth;
      result.classList.add("roll-pop");
      button.classList.add("is-rolling");
      setTimeout(() => button.classList.remove("is-rolling"), 350);
      saveState();
    });
  });
}

function renderSkills(focusNew = false) {
  const list = $("#skillsList");
  if (!state.skills.length) {
    list.innerHTML = '<div class="empty-skills"><span>✦</span><p>Nenhuma habilidade adicionada.<br /><small>Use o + para registrar um talento.</small></p></div>';
    return;
  }
  list.innerHTML = state.skills.map((skill, index) => `
    <div class="skill-row" data-skill-index="${index}">
      <span class="skill-number">${String(index + 1).padStart(2, "0")}</span>
      <label class="sr-only" for="skill-name-${index}">Nome da habilidade ${index + 1}</label>
      <input id="skill-name-${index}" class="skill-name" type="text" maxlength="60" placeholder="Nome do talento" value="${escapeAttribute(skill.name || "")}" />
      <label class="sr-only" for="skill-detail-${index}">Detalhe da habilidade ${index + 1}</label>
      <input id="skill-detail-${index}" class="skill-detail" type="text" maxlength="100" placeholder="Como aparece na história" value="${escapeAttribute(skill.detail || "")}" />
      <button class="remove-skill" type="button" data-remove-skill="${index}" aria-label="Remover habilidade ${index + 1}">×</button>
    </div>`).join("");

  $$(".skill-row", list).forEach((row) => {
    const index = Number(row.dataset.skillIndex);
    $(".skill-name", row).addEventListener("input", (event) => { state.skills[index].name = event.target.value; saveState(); });
    $(".skill-detail", row).addEventListener("input", (event) => { state.skills[index].detail = event.target.value; saveState(); });
  });
  $$('[data-remove-skill]', list).forEach((button) => {
    button.addEventListener("click", () => {
      state.skills.splice(Number(button.dataset.removeSkill), 1);
      renderSkills();
      saveState();
    });
  });
  if (focusNew) {
    const last = list.querySelector(".skill-name:last-of-type");
    last?.focus();
  }
}

function renderDanger() {
  const value = clampNumber(state.danger, 0, state.dangerMax);
  state.danger = value;
  $("#dangerValue").textContent = value;
  $("#dangerMax").value = state.dangerMax;
  const track = $("#dangerTrack");
  track.innerHTML = Array.from({ length: state.dangerMax }, (_, index) => `<span class="danger-dot ${index < value ? "filled" : ""}" aria-hidden="true"></span>`).join("");
  track.setAttribute("aria-label", `${value} de ${state.dangerMax} pontos de perigo marcados`);
  $(".danger-panel").classList.toggle("danger-high", value >= Math.ceil(state.dangerMax * 0.7));
}

function validateName(showToast = true) {
  const input = $("#name");
  if (!input.value.trim()) {
    $("[data-error-for='name']").textContent = "Dê um nome para sua personagem.";
    input.classList.add("has-error");
    if (showToast) showToastMessage("Só falta dar um nome para a personagem.");
    return false;
  }
  clearFieldError("name");
  return true;
}

function clearFieldError(name) {
  const input = $(`#${name}`);
  const error = $(`[data-error-for='${name}']`);
  input?.classList.remove("has-error");
  if (error) error.textContent = "";
}

function showToastMessage(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toast.hideTimer);
  toast.hideTimer = setTimeout(() => toast.classList.remove("show"), 3000);
}

function exportSheet() {
  const valid = validateName(false);
  const payload = { ...state, exportedAt: new Date().toISOString(), app: "Gatos & Sapatos — Gerador de Ficha" };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const safeName = (state.name.trim() || "nova-ficha").toLowerCase().replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "");
  link.href = url;
  link.download = `${safeName || "nova-ficha"}-gatos-e-sapatos.json`;
  link.click();
  URL.revokeObjectURL(url);
  showToastMessage(valid ? "Ficha exportada em JSON." : "Ficha exportada — você pode nomeá-la depois.");
}

function escapeAttribute(value) {
  return String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function setupNavigation() {
  const links = $$(".nav-link");
  const sections = links.map((link) => $(link.getAttribute("href"))).filter(Boolean);
  const observer = new IntersectionObserver((entries) => {
    const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!visible) return;
    links.forEach((link) => link.classList.toggle("active", link.getAttribute("href") === `#${visible.target.id}`));
  }, { rootMargin: "-20% 0px -65% 0px", threshold: [0, 0.2, 0.6] });
  sections.forEach((section) => observer.observe(section));
}

function setupActions() {
  $("#addSkill").addEventListener("click", () => {
    state.skills.push({ name: "", detail: "" });
    renderSkills(true);
    saveState();
  });
  $("#dangerMinus").addEventListener("click", () => { state.danger = Math.max(0, state.danger - 1); renderDanger(); saveState(); });
  $("#dangerPlus").addEventListener("click", () => { state.danger = Math.min(state.dangerMax, state.danger + 1); renderDanger(); saveState(); });
  $("#resetSenses").addEventListener("click", () => {
    state.senses = structuredClone(defaultSenses);
    renderSenses();
    saveState();
    showToastMessage("Sentidos voltaram ao valor padrão.");
  });
  $("#printButton").addEventListener("click", () => {
    validateName(false);
    window.print();
  });
  $("#exportButton").addEventListener("click", exportSheet);

  const dialog = $("#clearDialog");
  $("#clearButton").addEventListener("click", () => dialog.showModal());
  $("#cancelClear").addEventListener("click", () => dialog.close());
  $("#confirmClear").addEventListener("click", () => {
    state = emptyState();
    localStorage.removeItem(STORAGE_KEY);
    $("#characterForm").reset();
    bindFormFields();
    renderSenses();
    renderSkills();
    renderDanger();
    updateHero();
    dialog.close();
    showToastMessage("Nova ficha pronta para receber uma história.");
  });
}

bindFormFields();
renderSenses();
renderSkills();
renderDanger();
updateHero();
setupActions();
setupNavigation();
