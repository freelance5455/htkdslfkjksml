/* AccoNova main: boot, shell, onboarding. */
(function (root) {
  "use strict";
  var UI = root.AN_UI, h = UI.h, t = UI.t, AN = root.AN, J = root.AN_J, F = UI.fmt;
  var TABS = ["home", "sales", "purchases", "payments", "journal", "accounts", "contacts", "reports", "settings", "eval"];
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }

  /* ───── boot ───── */
  var storage = null, storageOk = true;
  try { localStorage.setItem("acconova.probe", "1"); localStorage.removeItem("acconova.probe"); storage = localStorage; } catch (e) { storageOk = false; storage = AN.memoryStorage(); }
  UI.store = AN.createStore({ storage: storage });
  UI.storageOk = storageOk;
  var nav = (navigator.language || "en").toLowerCase();
  UI.lang = lsGet("acconova.lang") || nav.slice(0, 2); if (UI.LANGS.indexOf(UI.lang) < 0) UI.lang = "en";
  UI.tab = lsGet("acconova.tab") || "home"; if (TABS.indexOf(UI.tab) < 0) UI.tab = "home";

  UI.unlocked = {}; UI.hist = []; UI.histOk = true; UI.noTrack = false;
  function where() { var sub = UI.tab === "settings" ? (UI.sub.settings || "company") : UI.tab === "reports" ? ((UI.sub.rep && UI.sub.rep.id) || "tb") : ""; return UI.tab + "|" + (sub || ""); }
  function applyWhere(w) { var a = w.split("|"); UI.tab = a[0]; if (a[0] === "settings" && a[1]) UI.sub.settings = a[1]; if (a[0] === "reports" && a[1]) (UI.sub.rep = UI.sub.rep || {}).id = a[1]; lsSet("acconova.tab", UI.tab); }
  function track() {
    if (UI.noTrack) { UI.noTrack = false; return; }
    var w = where(); if (UI.hist[UI.hist.length - 1] === w) return;
    UI.hist.push(w); if (UI.hist.length > 60) UI.hist.shift();
    if (UI.hist.length > 1) { try { history.pushState({ an: UI.hist.length }, ""); } catch (e) { UI.histOk = false; } }
  }
  UI.canBack = function () { return UI.hist.length > 1; };
  function backInternal() { if (UI.hist.length < 2) return; UI.hist.pop(); applyWhere(UI.hist[UI.hist.length - 1]); UI.noTrack = true; UI.render(); if (window.scrollTo) window.scrollTo(0, 0); }
  UI.back = function () { if (!UI.canBack()) return; if (UI.histOk) { try { history.back(); return; } catch (e) { UI.histOk = false; } } backInternal(); };
  window.addEventListener("popstate", function () { if (UI.canBack()) backInternal(); else { try { history.pushState({ an: 0 }, ""); } catch (e) { } } });
  UI.lock = function () { if (UI.ctx) { delete UI.unlocked[UI.ctx.uid]; UI.render(); } };

  function lockScreen() {
    var uid = UI.ctx.uid, user = UI.store.users()[uid], pw = h("input", { class: "inp", type: "password", autocomplete: "current-password", maxlength: 128, "aria-label": t("password") }), msg = h("div", { class: "form-error", role: "alert", hidden: "" });
    var btn = h("button", { class: "btn", type: "submit" }, t("unlock"));
    var form = h("form", { class: "form", onsubmit: function (ev) {
      ev.preventDefault();
      UI.busy(btn, async function () {
        try { if (await UI.store.verifyPassword(uid, pw.value)) { UI.unlocked[uid] = true; UI.render(); return; } msg.textContent = UI.errMsg({ code: "WRONG_PASSWORD" }); }
        catch (e) { msg.textContent = UI.errMsg(e); } msg.hidden = false; pw.value = ""; pw.focus();
      });
    } }, UI.field(t("password"), pw), btn);
    var users = UI.store.users(), others = Object.keys(users).filter(function (k) { return k !== uid && UI.store.listCompaniesFor(k).length; });
    var wrap = h("div", { class: "onboard-wrap" }, h("section", { class: "card onboard" }, h("h2", { text: t("lockedTitle") }), h("p", { class: "muted", text: t("lockedText", { name: user.name }) }), msg, form,
      others.length ? h("div", { class: "field" }, h("label", { class: "muted small", text: t("signedInAs") }), UI.select(others.map(function (k) { return { value: k, label: users[k].name }; }).concat([{ value: uid, label: user.name }]), uid, function () { var v = this.value; if (v !== uid) { var c = UI.store.listCompaniesFor(v)[0]; UI.ctx = { uid: v, cid: c.id }; UI.store.setSession(v, c.id); UI.render(); } })) : null));
    setTimeout(function () { pw.focus(); }, 30);
    return wrap;
  }

  function resolveSession() {
    var s = UI.store.session(), users = UI.store.users(), uid = s.uid, cid = s.cid;
    var okCompany = uid && cid && users[uid] && UI.store.listCompaniesFor(uid).some(function (c) { return c.id === cid; });
    if (okCompany) { UI.ctx = { uid: uid, cid: cid }; return; }
    var all = Object.keys(users);
    for (var i = 0; i < all.length; i++) { var cs = UI.store.listCompaniesFor(all[i]); if (cs.length) { UI.ctx = { uid: all[i], cid: cs[0].id }; UI.store.setSession(UI.ctx.uid, UI.ctx.cid); return; } }
    UI.ctx = null;
  }

  UI.go = function (tab, action) {
    UI.tab = tab; UI.pending = null;
    if (tab === "settings" && action) UI.sub.settings = action; else UI.pending = action || null;
    lsSet("acconova.tab", tab); UI.render(); if (window.scrollTo) window.scrollTo(0, 0);
  };
  UI.setLang = function (l) { UI.lang = l; lsSet("acconova.lang", l); UI.render(); };

  /* ───── render ───── */
  UI.render = function () {
    UI.clearTimers();
    document.querySelectorAll("dialog.modal").forEach(function (d) { try { d.close(); } catch (e) { } d.remove(); });
    var d = document.documentElement; d.lang = UI.lang; d.dir = UI.isRtl() ? "rtl" : "ltr"; document.title = t("appTitle");
    resolveSession();
    var app = UI.$("app"); UI.clear(app);
    app.appendChild(langBar());
    if (!storageOk) app.appendChild(h("div", { class: "banner warn", text: t("storageBlocked") }));
    if (!UI.legalAccepted()) { app.appendChild(UI.legalGate()); return; }
    if (!UI.ctx) { app.appendChild(onboarding(false)); return; }
    if (UI.store.hasPassword(UI.ctx.uid) && !UI.unlocked[UI.ctx.uid]) { app.appendChild(lockScreen()); return; }
    track();
    app.appendChild(header());
    app.appendChild(tabsNav());
    var view = h("main", { class: "view", id: "view", tabindex: "-1" }); app.appendChild(view);
    app.appendChild(UI.legalFooter());
    try { UI.views[UI.tab](view); }
    catch (e) { view.appendChild(h("div", { class: "form-error", text: t("viewError") + " " + (e && e.message) })); if (root.console) console.error(e); }
  };

  function langBar() {
    var sel = UI.select(UI.LANGS.map(function (l) { return { value: l, label: UI.LANG_NAMES[l] }; }), UI.lang, function () { UI.setLang(sel.value); });
    sel.className = "inp lang-sel"; sel.setAttribute("aria-label", "Language / زبان / اللغة / Langue / Sprache");
    return h("div", { class: "langbar" }, UI.icon("globe"), sel);
  }
  function header() {
    var co = UI.co(), uid = UI.ctx.uid, users = UI.store.users(), plan = UI.store.effectivePlan(co);
    var companies = UI.store.listCompaniesFor(uid);
    var cSel = UI.select(companies.map(function (c) { return { value: c.id, label: c.name }; }).concat([{ value: "__new", label: "＋ " + t("newCompany") }]), UI.ctx.cid, function () {
      if (cSel.value === "__new") { cSel.value = UI.ctx.cid; var app = UI.$("app"); UI.clear(app); app.appendChild(langBar()); app.appendChild(onboarding(true)); return; }
      UI.ctx = { uid: uid, cid: cSel.value }; UI.store.setSession(uid, cSel.value); UI.render();
    });
    cSel.setAttribute("aria-label", t("company"));
    var members = Object.keys(co.members).filter(function (m) { return users[m]; });
    var uSel = UI.select(members.map(function (m) { return { value: m, label: users[m].name + " · " + t("role_" + co.members[m].role) }; }), uid, function () { UI.ctx = { uid: uSel.value, cid: UI.ctx.cid }; UI.store.setSession(uSel.value, UI.ctx.cid); UI.render(); });
    uSel.setAttribute("aria-label", t("signedInAs"));
    return h("header", { class: "top" },
      h("div", { class: "brand" }, h("div", { class: "logo", "aria-hidden": "true", html: '<svg viewBox="0 0 24 24" fill="none" stroke="#2a1505" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="3"/><path d="M8 7h8M8 12h2M12 12h2M16 12h0M8 16h2M12 16h2M16 16h0"/></svg>' }),
        h("div", {}, h("h1", { text: "AccoNova" }), h("p", { class: "muted", text: t("tagline") }))),
      h("div", { class: "ctx" }, h("div", { class: "ctx-item" }, h("label", { class: "muted small", text: t("company") }), cSel), h("div", { class: "ctx-item" }, h("label", { class: "muted small", text: t("signedInAs") }), uSel), UI.badge(t("plan_" + plan), plan === "free" ? "" : "ok"), UI.store.hasPassword(uid) ? h("button", { class: "icon-btn", type: "button", title: t("lockNow"), "aria-label": t("lockNow"), onclick: function () { UI.lock(); } }, UI.icon("lock")) : null));
  }
  function tabsNav() {
    return h("nav", { class: "tabs", "aria-label": t("navigation") }, h("button", { class: "tab back", type: "button", title: t("backTip"), "aria-label": t("backTip"), disabled: !UI.canBack(), onclick: function () { UI.back(); } }, UI.icon("back"), t("back")), TABS.map(function (k) { return h("button", { class: "tab" + (UI.tab === k ? " on" : ""), type: "button", "aria-current": UI.tab === k ? "page" : null, onclick: function () { UI.go(k); } }, t("tab_" + k), (k === "purchases" && UI.ctx && !UI.store.planOf(UI.co()).purchases) ? UI.icon("lock") : null); }));
  }

  /* ───── onboarding ───── */
  function onboarding(additional) {
    var fa = UI.isFa(), users = UI.store.users(), uidExisting = UI.ctx && UI.ctx.uid;
    var owner = h("input", { class: "inp", maxlength: 80, value: additional && users[uidExisting] ? users[uidExisting].name : "", disabled: additional, autocomplete: "name" });
    var name = h("input", { class: "inp", maxlength: 120, autocomplete: "organization" });
    var base = UI.select(Object.keys(AN.CURRENCIES).map(function (c) { return { value: c, label: c + " · " + UI.curName(c) }; }), fa ? "IRR" : "USD");
    var cal = UI.select([{ value: "jalali", label: t("cal_jalali") }, { value: "gregorian", label: t("cal_gregorian") }], fa ? "jalali" : "gregorian");
    var err = h("div", { class: "form-error", role: "alert", hidden: "" });
    function create() {
      try {
        var uid = additional ? uidExisting : UI.store.createUser(owner.value);
        var cid = UI.store.createCompany(uid, { name: name.value, baseCurrency: base.value, calendar: cal.value });
        UI.ctx = { uid: uid, cid: cid };
        UI.tab = "home"; UI.render();
      } catch (e) { err.textContent = UI.errMsg(e); err.hidden = false; }
    }
    var card = h("section", { class: "card onboard" }, h("h2", { text: additional ? t("newCompany") : t("welcome") }), h("p", { class: "muted", text: t("onboardIntro") }), err,
      h("div", { class: "form" }, UI.field(t("yourName"), owner), UI.field(t("companyName"), name), UI.field(t("baseCurrency"), base, t("baseCurrencyHint")), UI.field(t("calendar"), cal, t("calendarHint"))),
      h("div", { class: "actions" }, h("button", { class: "btn", type: "button", onclick: function () { create(); } }, t("createCompany")), additional ? h("button", { class: "btn sec", type: "button", onclick: function () { UI.render(); } }, t("cancel")) : null), h("p", { class: "muted small", text: t("localNote") }));
    var wrap = h("div", { class: "onboard-wrap" }, h("div", { class: "brand big" }, h("div", { class: "logo", "aria-hidden": "true", html: '<svg viewBox="0 0 24 24" fill="none" stroke="#2a1505" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="3"/><path d="M8 7h8M8 12h2M12 12h2M16 12h0M8 16h2M12 16h2M16 16h0"/></svg>' }), h("div", {}, h("h1", { text: "AccoNova" }), h("p", { class: "muted", text: t("tagline") }))), card);
    return wrap;
  }


  /* ───── start ───── */
  function start() {
    var toasts = h("div", { id: "toasts", class: "toasts", "aria-live": "polite" }); document.body.appendChild(toasts);
    UI.render();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})(typeof globalThis !== "undefined" ? globalThis : this);
