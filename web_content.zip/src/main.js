import * as THREE from 'three';
import {createRenderer,getViewportSize} from '../renderer.js';
import {createWorld} from '../world.js';
import {createPlayer} from '../player.js';
import {createUI} from '../ui.js';
import {currentPreset,PRESETS} from '../settings.js';
import {getNight,getOrder,getCustomerRemark,getEndingSummary} from './campaign.js';
import {createAudio} from './audio.js';

const SAVE_KEY='ramenShiftProgress';
const SCARE_KEY='ramenShiftScareLevel';
const EVIDENCE_KEY='ramenShiftCaseEvidence';
function readScareLevel(){try{const value=localStorage.getItem(SCARE_KEY);return ['full','reduced','off'].includes(value)?value:'full';}catch{return 'full';}}
let scareLevel=readScareLevel();
const audio=createAudio();
function readProgress(){try{const saved=JSON.parse(localStorage.getItem(SAVE_KEY)||'{}');return{day:Number.isInteger(saved.day)&&saved.day>=1&&saved.day<=7?saved.day:1,completed:saved.completed===true};}catch{return{day:1,completed:false};}}
function writeProgress(day,completed=false){try{localStorage.setItem(SAVE_KEY,JSON.stringify({day,completed}));}catch{/* The current run still works when browser storage is disabled. */}}
function readEvidence(){try{const value=JSON.parse(localStorage.getItem(EVIDENCE_KEY)||'[]');return{items:Array.isArray(value)?value.filter(item=>typeof item==='string'):[]};}catch{return{items:[]};}}
let evidence=readEvidence();
function saveEvidence(){try{localStorage.setItem(EVIDENCE_KEY,JSON.stringify(evidence.items));}catch{}}
function recordEvidence(key){if(!evidence.items.includes(key)){evidence.items.push(key);saveEvidence();}return getEvidenceCounts();}
function clearEvidence(){evidence={items:[]};saveEvidence();}
function getEvidenceCounts(){const count=prefix=>evidence.items.filter(item=>item.startsWith(prefix)).length;return{emails:count('email-'),profiles:count('profile-'),ghostClips:count('ghost-')};}

function syncPortraitFallback(){const rotate=(navigator.maxTouchPoints||0)>0&&innerWidth>innerHeight&&innerHeight<560;document.body.classList.toggle('portrait-rotated',rotate);}
syncPortraitFallback();
const appStage=document.querySelector('#app-stage');
async function requestPortraitFullscreen(){try{if(!document.fullscreenElement&&appStage.requestFullscreen)await appStage.requestFullscreen({navigationUI:'hide'});}catch{}try{if(screen.orientation?.lock)await screen.orientation.lock('portrait');}catch{}syncPortraitFallback();resize();}
const canvas=document.querySelector('#game');
const view=createRenderer(canvas,currentPreset);
const scene=new THREE.Scene();
const initialSize=getViewportSize();
const camera=new THREE.PerspectiveCamera(65,initialSize.width/initialSize.height,.1,45);
const world=createWorld(scene,view.psx);
const saved=readProgress();
let day=saved.day,completed=saved.completed,night=null,started=false,paused=false,solved=false,elapsed=0,ghostAt=Infinity,watcherAt=Infinity,watcherUntil=0,watcherVisible=false,watcherCount=0,jumpScaresDone=0,ghostCCTVAt=Infinity,nextLightFlicker=Infinity,lightFlickerActive=false,lightFlickerIndex=0,lightSegmentRemaining=0,lightFlickerCount=0,nextVisit=8,visitorIndex=0,frameId=0,previous=0,accumulator=0,lastBed=false,lastComputer=false,activeCustomer=null,currentOrder=null,currentRemark='',serviceStage=0,servedCount=0,serviceMistakes=0,mistakesTotal=0,nextHonkAt=Infinity,earnings=0;
let player,menuFrameId=0,lastMenuRender=0;
const ui=createUI({
  applyGraphics:(name,config)=>{view.applyPreset(name);document.querySelector('#grain').style.opacity=String(config.grain);},
  onStart:()=>{requestPortraitFullscreen();if(completed){day=1;completed=false;clearEvidence();writeProgress(1,false);}startShift(day);},
  onAccuse:record=>{
    if(solved||!night||visitorIndex<night.records.length||servedCount<night.records.length)return;
    if(record.killer){solved=true;world.clearHaunting();view.setLightIntensity(1);audio.correct();ui.solved();writeProgress(day,false);}
    else{started=false;paused=false;audio.wrong();audio.setPaused(true);if(frameId)cancelAnimationFrame(frameId);frameId=0;ui.gameOver();}
  },
  onSleep:()=>sleepThroughNight(),
  onPause:()=>pauseShift(),
  onResume:()=>resumeShift(),
  onRestart:()=>restartRun(),
  onSoundToggle:()=>audio.toggle(),
  onScareSetting:value=>{if(['full','reduced','off'].includes(value)){scareLevel=value;try{localStorage.setItem(SCARE_KEY,value);}catch{}}},
  scareLevel,
  onEvidence:recordEvidence,
  getEvidenceCounts,
  graphicsPreset:currentPreset,
  soundEnabled:audio.enabled
});
player=createPlayer(camera,handleInteract,world.collides);
ui.setContinue(day,completed);
function menuFrame(now=0){menuFrameId=0;if(started||document.hidden)return;if(now-lastMenuRender>66){camera.position.set(player.pose.x,1.62,player.pose.z);camera.rotation.order='YXZ';camera.rotation.set(.015,Math.sin(now*.00012)*.035,0);view.render(scene,camera,now/1000);lastMenuRender=now;}menuFrameId=requestAnimationFrame(menuFrame);}
menuFrameId=requestAnimationFrame(menuFrame);

function serviceLabel(position){if(!activeCustomer)return null;const sushi=currentOrder?.type==='sushi';if(serviceStage===0&&world.nearCustomer(position))return 'Take order';if(serviceStage===1&&world.nearStove(position))return sushi?'Cook rice':'Cook noodles';if(serviceStage===2&&world.nearBowl(position))return sushi?'Assemble sushi':'Add broth';if(serviceStage===3&&world.nearServingPass(position))return sushi?'Serve sushi':'Serve ramen';return null;}
function handleInteract(){
  if(!started||paused||ui.computerIsOpen)return;
  const position=player.pose,action=serviceLabel(position);
  if(solved&&world.nearBed(position)){sleepThroughNight();return;}
  if(action){advanceService();return;}
  if(activeCustomer){const targets=['the customer at the window',currentOrder.type==='sushi'?'the rice cooker':'the stove',currentOrder.type==='sushi'?'the sushi prep counter':'the broth station','the serving pass'];if(serviceStage>0){serviceMistakes++;mistakesTotal++;ui.customerMistake(serviceMistakes,targets[serviceStage],mistakesTotal);}else ui.setPrompt(`Take the order to ${targets[serviceStage]}.`);return;}
  if(world.nearComputer(position)){audio.computer();ui.openComputer();return;}
  ui.setPrompt('Nothing close enough to use. Find the customer, kitchen station, computer, or bed.');
}
function advanceService(){
  if(!activeCustomer)return;
  if(serviceStage===0){serviceStage=1;audio.order();ui.customerOrder(activeCustomer,currentOrder,currentRemark,serviceStage);ui.setPrompt(`Order taken: ${currentOrder.dish}. ${currentOrder.type==='sushi'?'Cook the sushi rice.':'Cook the noodles.'}`);return;}
  if(serviceStage===1){serviceStage=2;audio.cook();ui.serviceStep(serviceStage,currentOrder.type);ui.setPrompt(currentOrder.type==='sushi'?`Rice is ready. Assemble ${currentOrder.topping}.`:`Noodles are ready. Add ${currentOrder.broth} and ${currentOrder.topping}.`);return;}
  if(serviceStage===2){serviceStage=3;audio.cook();ui.serviceStep(serviceStage,currentOrder.type);ui.setPrompt(currentOrder.type==='sushi'?'Sushi is assembled. Take the plate to the serving pass.':'Bowl is ready. Take it to the serving pass.');return;}
  audio.serve();const guest=activeCustomer,price=currentOrder.price;servedCount++;earnings+=price;serviceMistakes=0;nextHonkAt=Infinity;activeCustomer=null;currentOrder=null;currentRemark='';world.customerLeaves();ui.customerServed(servedCount,night.records.length,earnings,guest,price,mistakesTotal);if(servedCount===night.records.length&&visitorIndex===night.records.length)ui.setShiftReady(true);else nextVisit=elapsed+3;
}
function startShift(number){
  if(menuFrameId)cancelAnimationFrame(menuFrameId);menuFrameId=0;audio.start();day=Math.max(1,Math.min(7,number));night=getNight(day);activeCustomer=null;currentOrder=null;currentRemark='';serviceStage=0;servedCount=0;serviceMistakes=0;mistakesTotal=0;nextHonkAt=Infinity;earnings=0;solved=false;paused=false;started=true;elapsed=0;watcherAt=day>=2?14:Infinity;ghostAt=day>=2?36-Math.max(0,day-2)*2:Infinity;ghostCCTVAt=day>=2?9:Infinity;watcherUntil=0;watcherVisible=false;watcherCount=0;jumpScaresDone=0;nextLightFlicker=day>=2?25-Math.max(0,day-2)*2:Infinity;lightFlickerActive=false;lightFlickerIndex=0;lightSegmentRemaining=0;lightFlickerCount=0;view.setLightIntensity(1);nextVisit=8;visitorIndex=0;previous=0;accumulator=0;lastBed=false;lastComputer=false;
  writeProgress(day,false);world.setCustomer(null);world.clearHaunting();ui.beginShift(day,night);ui.setContinue(day,false);startLoop();
}
function sleepThroughNight(){
  if(!solved||!world.nearBed(player.pose))return;
  started=false;paused=false;if(frameId)cancelAnimationFrame(frameId);frameId=0;previous=0;accumulator=0;
  audio.sleep();audio.setPaused(true);view.setLightIntensity(1);activeCustomer=null;currentOrder=null;world.setCustomer(null);world.clearHaunting();player.setPosition(6.5,2.55,-Math.PI/2);player.update(0);ui.setPrompt('You fall asleep beside the bed.');
  if(day===7){completed=true;writeProgress(7,true);setTimeout(()=>{ui.finish(getEndingSummary(getEvidenceCounts()));ui.setContinue(7,true);menuFrameId=requestAnimationFrame(menuFrame);},1500);return;}
  const nextDay=day+1;writeProgress(nextDay,false);ui.setContinue(nextDay,false);setTimeout(()=>startShift(nextDay),1700);
}
function restartRun(){
  started=false;paused=false;solved=false;day=1;completed=false;night=null;visitorIndex=0;elapsed=0;if(frameId)cancelAnimationFrame(frameId);frameId=0;
  audio.setPaused(true);view.setLightIntensity(1);clearEvidence();try{localStorage.removeItem(SAVE_KEY);}catch{}player.setPosition(0,3.8,0);player.update(0);activeCustomer=null;currentOrder=null;world.setCustomer(null);world.clearHaunting();ui.resetToTitle();ui.setContinue(1,false);menuFrameId=requestAnimationFrame(menuFrame);
}
function pauseShift(){if(!started||paused)return;paused=true;audio.setPaused(true);if(frameId)cancelAnimationFrame(frameId);frameId=0;previous=0;ui.pause();}
function resumeShift(){if(!started||!paused)return;paused=false;audio.setPaused(false);previous=0;accumulator=0;ui.resume();startLoop();}
function startLoop(){if(started&&!paused&&!frameId&&!document.hidden)frameId=requestAnimationFrame(frame);}
function resize(){syncPortraitFallback();const size=getViewportSize();camera.aspect=size.width/size.height;camera.updateProjectionMatrix();view.resize();}
addEventListener('resize',resize,{passive:true});
addEventListener('orientationchange',resize,{passive:true});
document.addEventListener('fullscreenchange',resize);
const FRAME_MS=1000/30;
const FLICKER_PATTERN=[.12,.08,.1,.14,.16,.07,.5,.11,.72,.13];
function updateHauntingLights(dt,pose){
  if(solved||day<2){lightFlickerActive=false;view.setLightIntensity(1);return;}
  if(!lightFlickerActive&&elapsed>=nextLightFlicker){
    lightFlickerActive=true;lightFlickerIndex=0;lightSegmentRemaining=FLICKER_PATTERN[0];view.setLightIntensity(.035);
    world.setWatcher(true,pose,day+lightFlickerCount);watcherVisible=true;watcherUntil=elapsed+2.2;audio.lightFlicker();
    ui.setPrompt('The lights snap off. Something is standing outside.');
  }
  if(!lightFlickerActive)return;
  lightSegmentRemaining-=dt;
  if(lightSegmentRemaining>0)return;
  lightFlickerIndex++;
  if(lightFlickerIndex>=FLICKER_PATTERN.length){
    lightFlickerActive=false;lightFlickerCount++;view.setLightIntensity(1);world.setWatcher(false);watcherVisible=false;
    nextLightFlicker=elapsed+Math.max(25,46-day*2)+Math.random()*6;ui.setPrompt('The lanterns come back. The road is empty.');return;
  }
  lightSegmentRemaining=FLICKER_PATTERN[lightFlickerIndex];
  const lightsOn=lightFlickerIndex%2===1;view.setLightIntensity(lightsOn?1:.035);
}
function updateStep(dt){
  player.update(dt);
  const pose=player.pose;
  const nearBed=world.nearBed(pose),nearComputer=world.nearComputer(pose),action=serviceLabel(pose);
  ui.updateContext({nearComputer,nearBed,solved,serviceLabel:action});
  if(solved&&nearBed&&!lastBed)ui.setPrompt('You are beside the bed. Tap Sleep or Interact to start the next night.');
  else if(solved&&!nearBed&&lastBed)ui.setPrompt('Walk over to the bed in your room to sleep.');
  else if(!solved&&nearComputer&&!lastComputer)ui.setPrompt('The computer is here. Tap Interact or open it with C.');
  lastBed=nearBed;lastComputer=nearComputer;
  if(!solved){
    elapsed+=dt;
    if(elapsed>=ghostCCTVAt){ghostCCTVAt=Infinity;ui.revealGhostCCTV();ui.setPrompt('The CCTV terminal logged movement. Check the archived clip.');}
    if(!activeCustomer&&visitorIndex<night.records.length&&elapsed>=nextVisit){
      const customerNumber=visitorIndex,visitor=night.records[visitorIndex++];activeCustomer=visitor;serviceStage=0;nextHonkAt=elapsed+14;
      currentOrder=getOrder(day,customerNumber);currentRemark=getCustomerRemark(day,customerNumber);world.setCustomer(visitor);
      audio.carArrival();ui.observe(visitor);ui.customerWaiting(visitor,currentRemark);
      ui.setPrompt('Customer '+visitorIndex+' of '+night.records.length+' is waiting. Take their order.');nextVisit=Infinity;
    }
    if(!watcherVisible&&watcherCount<2&&elapsed>=watcherAt){
      world.setWatcher(true,pose,day+watcherCount);watcherVisible=true;watcherUntil=elapsed+5.5;watcherCount++;
      audio.watcher();ui.setPrompt('A white figure stands across the road. It is watching you.');
    }
    if(watcherVisible&&elapsed>=watcherUntil){world.setWatcher(false);watcherVisible=false;watcherAt=watcherCount<2?elapsed+11+day%3*2:Infinity;}
    if(activeCustomer&&elapsed>=nextHonkAt){audio.horn();ui.customerHonk(activeCustomer);nextHonkAt=elapsed+14;}
    const scareLimit=scareLevel==='off'?0:scareLevel==='reduced'?1:day===7?3:day>=4?2:1;
    if(jumpScaresDone<scareLimit&&elapsed>=ghostAt){
      world.setWatcher(false);watcherVisible=false;world.scare(pose,pose.yaw);audio.scare(scareLevel==='reduced');
      ui.flashScare(['DON’T TURN AROUND','IT CAME CLOSER','IT KNOWS YOUR NAME'][jumpScaresDone%3],scareLevel==='reduced'?900:1450);
      ui.setPrompt('The pale figure is gone. You heard it inside.');jumpScaresDone++;
      ghostAt=jumpScaresDone<scareLimit?elapsed+12+day%3*2:Infinity;
    }
  }
  updateHauntingLights(dt,pose);
  world.updateWatcher(dt,pose);world.updateGhost(dt,pose);world.updateDeparture(dt);
}
function frame(now){
  frameId=0;if(document.hidden||!started||paused)return;
  if(!previous)previous=now;
  accumulator+=Math.min(Math.max(0,now-previous),100);previous=now;
  let steps=0;
  while(accumulator>=FRAME_MS&&steps<3){updateStep(1/30);accumulator-=FRAME_MS;steps++;}
  if(steps===3&&accumulator>=FRAME_MS)accumulator%=FRAME_MS;
  if(steps)view.render(scene,camera,now/1000);
  frameId=requestAnimationFrame(frame);
}
document.addEventListener('visibilitychange',()=>{if(document.hidden){audio.setPaused(true);if(frameId)cancelAnimationFrame(frameId);if(menuFrameId)cancelAnimationFrame(menuFrameId);frameId=menuFrameId=0;previous=0;}else{audio.setPaused(paused);if(started)startLoop();else menuFrameId=requestAnimationFrame(menuFrame);}});
 document.querySelector('#grain').style.opacity=String(PRESETS[currentPreset].grain);
document.addEventListener('click',event=>{if(event.target.closest?.('button'))audio.uiClick();});
addEventListener('pagehide',()=>{if(frameId)cancelAnimationFrame(frameId);if(menuFrameId)cancelAnimationFrame(menuFrameId);audio.dispose();world.dispose();view.dispose();},{once:true});
