import * as THREE from 'three';
import { createRenderer } from '../renderer.js';
import { createWorld } from '../world.js';
import { createPlayer } from '../player.js';
import { createUI } from '../ui.js';
import { currentPreset, PRESETS } from '../settings.js';
import { getNight } from './campaign.js';

const canvas=document.querySelector('#game');
const view=createRenderer(canvas,currentPreset);
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,45);
const world=createWorld(scene,view.psx);
let day=1,night=null,started=false,solved=false,elapsed=0,ghostAt=16,nextVisit=8,visitorIndex=0,frameId=0,previous=0,accumulator=0;
const player=createPlayer(camera,()=>ui.openComputer());
const ui=createUI({
  applyGraphics:(name,config)=>{view.applyPreset(name);document.querySelector('#grain').style.opacity=String(config.grain);},
  onStart:()=>startShift(1),
  onAccuse:record=>{
    if(solved)return;
    if(record.killer){solved=true;ui.solved();}
    else{ui.setPrompt('The match is wrong. Something noticed you.');world.scare(player.pose,player.pose.yaw);ui.flashScare();}
  },
  onSleep:()=>sleepThroughNight()
});
function startShift(number){
  day=number;night=getNight(day);solved=false;elapsed=0;ghostAt=14+day*1.7;nextVisit=8;visitorIndex=0;
  world.setCustomer(null);ui.beginShift(day,night);started=true;startLoop();
}
function sleepThroughNight(){
  started=false;if(frameId)cancelAnimationFrame(frameId);frameId=0;
  world.setCustomer(null);player.setPosition(6.05,3.2,-Math.PI/2);player.update(0);
  ui.setPrompt('You fall asleep while the old computer hums.');
  if(day===7){setTimeout(()=>ui.finish(),1500);return;}
  setTimeout(()=>startShift(day+1),1700);
}
function startLoop(){if(started&&!frameId&&!document.hidden)frameId=requestAnimationFrame(frame);}
function resize(){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();view.resize();}
addEventListener('resize',resize,{passive:true});
function frame(now){
  frameId=0;if(document.hidden||!started)return;
  if(!previous)previous=now;accumulator+=Math.min(now-previous,100);previous=now;
  if(accumulator>=1000/30){
    const dt=Math.min(accumulator/1000,1/30);accumulator%=1000/30;
    player.update(dt);
    if(!solved){
      elapsed+=dt;
      if(visitorIndex<night.records.length&&elapsed>=nextVisit){const visitor=night.records[visitorIndex++];world.setCustomer(visitor);ui.observe(visitor);ui.setPrompt(`A car pulls in. Check the CCTV.`);nextVisit=elapsed+10;}
      if(elapsed>=ghostAt){ghostAt=Infinity;world.scare(player.pose,player.pose.yaw);ui.flashScare();ui.setPrompt('Something is moving outside the cameras.');}
    }
    world.updateGhost(dt,player.pose);
    view.render(scene,camera,now/1000);
  }
  frameId=requestAnimationFrame(frame);
}
document.addEventListener('visibilitychange',()=>{
  if(document.hidden){if(frameId)cancelAnimationFrame(frameId);frameId=0;previous=0;}
  else startLoop();
});
document.querySelector('#grain').style.opacity=String(PRESETS[currentPreset].grain);
addEventListener('pagehide',()=>{if(frameId)cancelAnimationFrame(frameId);world.dispose();view.dispose();},{once:true});
