import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const loading = document.querySelector('#loading');
const errorBox = document.querySelector('#error');
const status = document.querySelector('#status');

let scene, camera, renderer, clock, player, yaw = 0, pitch = -0.12;
let moveX = 0, moveY = 0, verticalVelocity = 0, grounded = true;
const keys = new Set();
const WORLD_SIZE = 420;
const temp = new THREE.Object3D();

try { init(); animate(); }
catch (err) { showError(err); }

function init() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x9bb8c2);
  scene.fog = new THREE.FogExp2(0xb6c7c0, 0.0026);
  clock = new THREE.Clock();

  camera = new THREE.PerspectiveCamera(68, innerWidth / innerHeight, 0.1, 900);
  camera.position.set(0, 3.2, 7);

  renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  document.body.insertBefore(renderer.domElement, document.querySelector('#hud'));

  const hemi = new THREE.HemisphereLight(0xddeeff, 0x4d5942, 2.0);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffedcf, 3.2);
  sun.position.set(-80, 120, 45);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.left = -90; sun.shadow.camera.right = 90;
  sun.shadow.camera.top = 90; sun.shadow.camera.bottom = -90;
  scene.add(sun);

  buildLandscape();
  buildPlayer();
  loadExternalModels();

  window.addEventListener('resize', onResize);
  window.addEventListener('keydown', e => { keys.add(e.key.toLowerCase()); if (['arrowup','arrowdown','arrowleft','arrowright',' '].includes(e.key.toLowerCase())) e.preventDefault(); });
  window.addEventListener('keyup', e => keys.delete(e.key.toLowerCase()));
  setupTouchControls();
  document.querySelector('#jump').addEventListener('pointerdown', e => { e.preventDefault(); jump(); });
  document.querySelector('#reset').addEventListener('click', resetPlayer);
  loading.style.display = 'none';
}

function terrainHeight(x, z) {
  return 0.8 * Math.sin(x * 0.025) * Math.cos(z * 0.022)
       + 1.8 * Math.sin((x + z) * 0.011)
       + 0.5 * Math.cos(z * 0.055);
}

function buildLandscape() {
  const geo = new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE, 180, 180);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  const colors = [];
  const low = new THREE.Color(0x3d5c3c), mid = new THREE.Color(0x71845a), high = new THREE.Color(0x8b9275);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    const h = terrainHeight(x, z);
    pos.setY(i, h);
    const c = low.clone().lerp(mid, THREE.MathUtils.clamp((h + 1.5) / 4, 0, 1));
    if (h > 1.7) c.lerp(high, 0.35);
    colors.push(c.r, c.g, c.b);
  }
  geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geo.computeVertexNormals();
  const ground = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 }));
  ground.receiveShadow = true;
  scene.add(ground);

  // A winding river-like strip gives the prototype a visible landmark.
  const riverPts = [];
  for (let i = 0; i <= 90; i++) {
    const z = -WORLD_SIZE / 2 + i * WORLD_SIZE / 90;
    const x = 35 + Math.sin(z * 0.025) * 18;
    riverPts.push(new THREE.Vector3(x, terrainHeight(x, z) + 0.08, z));
  }
  const riverCurve = new THREE.CatmullRomCurve3(riverPts);
  const riverGeo = new THREE.TubeGeometry(riverCurve, 260, 2.8, 8, false);
  const river = new THREE.Mesh(riverGeo, new THREE.MeshStandardMaterial({ color: 0x4f9295, roughness: 0.25, metalness: 0.05, transparent: true, opacity: 0.88 }));
  scene.add(river);

  addTrees(620);
  addRocks(110);
  addLandmark();
}

function addTrees(count) {
  const trunkGeo = new THREE.CylinderGeometry(0.13, 0.22, 2.4, 6);
  const crownGeo = new THREE.ConeGeometry(1.25, 3.4, 7);
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x59422c, roughness: 1 });
  const crownMats = [0x294d35, 0x355e3b, 0x466b43].map(c => new THREE.MeshStandardMaterial({ color: c, roughness: 1 }));
  const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, count);
  const crowns = crownMats.map(m => new THREE.InstancedMesh(crownGeo, m, Math.ceil(count / 3)));
  let crownCounts = [0, 0, 0];
  let placed = 0;
  for (let i = 0; i < count; i++) {
    const x = (Math.random() - 0.5) * (WORLD_SIZE - 18);
    const z = (Math.random() - 0.5) * (WORLD_SIZE - 18);
    if (Math.hypot(x, z) < 12 || Math.abs(x - 35) < 8) continue;
    const y = terrainHeight(x, z);
    temp.position.set(x, y + 1.2, z);
    temp.rotation.set(0, Math.random() * Math.PI, 0);
    temp.scale.setScalar(0.7 + Math.random() * 1.2);
    temp.updateMatrix(); trunks.setMatrixAt(placed, temp.matrix);
    const k = Math.floor(Math.random() * 3);
    temp.position.set(x, y + 3.2 * temp.scale.y, z);
    temp.scale.setScalar(0.7 + Math.random() * 1.2);
    temp.rotation.set(0, Math.random() * Math.PI, 0);
    temp.updateMatrix(); crowns[k].setMatrixAt(crownCounts[k]++, temp.matrix);
    placed++;
  }
  trunks.count = placed; trunks.castShadow = true; trunks.receiveShadow = true; scene.add(trunks);
  crowns.forEach((mesh, i) => { mesh.count = crownCounts[i]; mesh.castShadow = true; mesh.receiveShadow = true; scene.add(mesh); });
}

function addRocks(count) {
  const geo = new THREE.DodecahedronGeometry(1, 0);
  const mat = new THREE.MeshStandardMaterial({ color: 0x777b70, roughness: 1 });
  const mesh = new THREE.InstancedMesh(geo, mat, count);
  for (let i = 0; i < count; i++) {
    const x = (Math.random() - 0.5) * WORLD_SIZE, z = (Math.random() - 0.5) * WORLD_SIZE;
    temp.position.set(x, terrainHeight(x, z) + 0.15, z);
    temp.rotation.set(Math.random(), Math.random() * 3, Math.random());
    temp.scale.set(0.3 + Math.random() * 1.4, 0.25 + Math.random() * 0.8, 0.3 + Math.random());
    temp.updateMatrix(); mesh.setMatrixAt(i, temp.matrix);
  }
  mesh.castShadow = true; mesh.receiveShadow = true; scene.add(mesh);
}

function addLandmark() {
  // Small abandoned watchtower placeholder; replace with a licensed GLB later.
  const stone = new THREE.MeshStandardMaterial({ color: 0x827d6b, roughness: 0.95 });
  const base = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 3.2, 7, 8), stone);
  base.position.set(-22, terrainHeight(-22, -30) + 3.5, -30);
  base.castShadow = true; base.receiveShadow = true; scene.add(base);
  const roof = new THREE.Mesh(new THREE.ConeGeometry(3.2, 2.2, 8), new THREE.MeshStandardMaterial({ color: 0x493d30, roughness: 0.9 }));
  roof.position.set(-22, terrainHeight(-22, -30) + 8.1, -30); roof.castShadow = true; scene.add(roof);
}

function buildPlayer() {
  player = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.42, 0.9, 4, 8), new THREE.MeshStandardMaterial({ color: 0x394e49, roughness: 0.8 }));
  body.position.y = 1.1; body.castShadow = true; player.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 10), new THREE.MeshStandardMaterial({ color: 0xb98e6b, roughness: 0.9 }));
  head.position.y = 1.95; head.castShadow = true; player.add(head);
  player.position.set(0, terrainHeight(0, 0), 0);
  scene.add(player);
}

function loadExternalModels() {
  // Add licensed .glb/.gltf files to assets/models and list them here.
  const loader = new GLTFLoader();
  loader.load('./assets/models/player.glb', gltf => {
    const model = gltf.scene;
    model.scale.setScalar(1);
    model.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    scene.add(model);
    player.visible = false;
    window.externalPlayer = model;
  }, undefined, () => { /* Optional model: use built-in placeholder if not supplied. */ });

  loader.load('./assets/models/landmark.glb', gltf => {
    const model = gltf.scene;
    model.position.set(-22, terrainHeight(-22, -30), -30);
    model.scale.setScalar(1);
    model.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    scene.add(model);
  }, undefined, () => {});
}

function setupTouchControls() {
  const joy = document.querySelector('#joystick');
  const stick = document.querySelector('#stick');
  let activeId = null;
  function update(e) {
    const r = joy.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const dx = e.clientX - cx, dy = e.clientY - cy;
    const max = 35, len = Math.hypot(dx, dy), scale = len > max ? max / len : 1;
    const x = dx * scale, y = dy * scale;
    stick.style.transform = `translate(${x}px, ${y}px)`;
    moveX = x / max; moveY = y / max;
  }
  joy.addEventListener('pointerdown', e => { activeId = e.pointerId; joy.setPointerCapture(activeId); update(e); });
  joy.addEventListener('pointermove', e => { if (e.pointerId === activeId) update(e); });
  const stop = e => { if (e.pointerId === activeId) { activeId = null; moveX = 0; moveY = 0; stick.style.transform = ''; } };
  joy.addEventListener('pointerup', stop); joy.addEventListener('pointercancel', stop);

  let lookId = null, lastX = 0, lastY = 0;
  renderer.domElement.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse') { renderer.domElement.requestPointerLock?.(); return; }
    lookId = e.pointerId; lastX = e.clientX; lastY = e.clientY;
    renderer.domElement.setPointerCapture?.(lookId);
  });
  renderer.domElement.addEventListener('pointermove', e => {
    if (e.pointerType === 'mouse' && document.pointerLockElement === renderer.domElement) {
      yaw -= e.movementX * 0.003; pitch = THREE.MathUtils.clamp(pitch - e.movementY * 0.002, -0.8, 0.35);
    } else if (e.pointerId === lookId) {
      yaw -= (e.clientX - lastX) * 0.006; pitch = THREE.MathUtils.clamp(pitch - (e.clientY - lastY) * 0.004, -0.8, 0.35);
      lastX = e.clientX; lastY = e.clientY;
    }
  });
  renderer.domElement.addEventListener('pointerup', e => { if (e.pointerId === lookId) lookId = null; });
}

function jump() { if (grounded) { verticalVelocity = 6.5; grounded = false; } }
function resetPlayer() { player.position.set(0, terrainHeight(0, 0), 0); verticalVelocity = 0; yaw = 0; pitch = -0.12; }

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.04);
  if (player) {
    let forward = -moveY + (keys.has('w') || keys.has('arrowup') ? 1 : 0) - (keys.has('s') || keys.has('arrowdown') ? 1 : 0);
    let side = moveX + (keys.has('d') || keys.has('arrowright') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') ? 1 : 0);
    const len = Math.hypot(forward, side);
    if (len > 1) { forward /= len; side /= len; }
    const speed = keys.has('shift') ? 9 : 5;
    const dirX = Math.sin(yaw), dirZ = -Math.cos(yaw);
    player.position.x += (dirX * forward + Math.cos(yaw) * side) * speed * dt;
    player.position.z += (dirZ * forward - Math.sin(yaw) * side) * speed * dt;
    player.position.x = THREE.MathUtils.clamp(player.position.x, -WORLD_SIZE/2 + 4, WORLD_SIZE/2 - 4);
    player.position.z = THREE.MathUtils.clamp(player.position.z, -WORLD_SIZE/2 + 4, WORLD_SIZE/2 - 4);
    const groundY = terrainHeight(player.position.x, player.position.z);
    verticalVelocity -= 15 * dt;
    player.position.y += verticalVelocity * dt;
    if (player.position.y <= groundY) { player.position.y = groundY; verticalVelocity = 0; grounded = true; }
    player.rotation.y = yaw;
    const camDistance = 6.5;
    const target = new THREE.Vector3(player.position.x, player.position.y + 1.6, player.position.z);
    camera.position.set(
      target.x - Math.sin(yaw) * Math.cos(pitch) * camDistance,
      target.y + 2.0 - Math.sin(pitch) * camDistance,
      target.z + Math.cos(yaw) * Math.cos(pitch) * camDistance
    );
    camera.lookAt(target);
    if (window.externalPlayer) window.externalPlayer.position.copy(player.position);
    status.textContent = `الموقع: ${Math.round(player.position.x)} ، ${Math.round(player.position.z)}`;
  }
  renderer.render(scene, camera);
}

function onResize() {
  if (!camera || !renderer) return;
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5)); renderer.setSize(innerWidth, innerHeight);
}
function showError(err) {
  console.error(err);
  errorBox.hidden = false;
  errorBox.textContent = 'تعذّر تشغيل اللعبة. افتحها عبر خادم محلي أو استضافة تدعم ES Modules، وتأكد من اتصال الإنترنت. التفاصيل: ' + (err?.message || err);
  loading.style.display = 'none';
}
