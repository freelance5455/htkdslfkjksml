import './style.css'
import { GoogleGenAI, Modality } from '@google/genai'

document.querySelector('#app').innerHTML = `
  <main class="screen">
    <header>
      <div class="brand"><span class="logo">H</span><div><h1>Hayat AI</h1><small>YOUR PERSONAL AI</small></div></div>
      <button class="icon-btn" id="settings" aria-label="Settings">⚙</button>
    </header>
    <section class="hero">
      <div class="status"><span class="dot"></span> <span id="status">READY TO CONNECT</span></div>
      <div class="orb-wrap" id="orb"><div class="ring ring-one"></div><div class="ring ring-two"></div><div class="orb"><div class="orb-core"></div></div><div class="spark spark-one"></div><div class="spark spark-two"></div></div>
      <h2 id="greeting">Hello, I'm Hayat.</h2>
      <p id="subtitle">Your world, connected through conversation.</p>
      <div class="response" id="response">Tap Start Live Voice to talk naturally.</div>
    </section>
    <section class="voice-panel">
      <button id="mic" class="mic"><span>🎙</span></button>
      <p id="mic-label">START LIVE VOICE</p>
      <div class="actions">
        <button id="chat" class="action"><span>✧</span><b>AI CHAT</b><small>Conversation</small></button>
        <button id="apps" class="action"><span>▦</span><b>MY APPS</b><small>Quick access</small></button>
        <button id="device" class="action"><span>⌘</span><b>DEVICE</b><small>Controls</small></button>
      </div>
    </section>
    <footer><span class="footer-dot"></span> HAYAT AI <span>•</span> YOUR ASSISTANT</footer>
  </main>
  <div id="hayat-float" class="hayat-float">
    <div class="mini-avatar"><span>H</span><i></i></div>
    <div class="mini-info">
      <strong>Hayat</strong>
      <span id="mini-status">Quiet</span>
    </div>
    <span class="mini-wave">◖▂▅▃◗</span>
  </div>
  <div id="modal" class="modal hidden"><div class="modal-card"><button id="close" class="close">✕</button><h2 id="modal-title">Hayat AI</h2><div id="modal-body"></div></div></div>
`

const $ = id => document.getElementById(id)
const showModal = (title, html) => {
  $('modal-title').textContent = title
  $('modal-body').innerHTML = html
  $('modal').classList.remove('hidden')
}

$('close').onclick = () => $('modal').classList.add('hidden')
$('settings').onclick = () => showModal('Settings',
  '<p>Hayat AI uses Gemini Live for real-time voice conversations.</p><p>Your permanent API key stays on the backend.</p>')
$('chat').onclick = () => showModal('AI Chat',
  '<p>Live voice is the current conversation mode. Text chat can be added separately.</p>')
$('apps').onclick = () => showModal('My Apps',
  '<p>Opening installed Android apps requires Android integration.</p>')
$('device').onclick = () => showModal('Device Controls',
  '<p>Device controls require Android permissions and a native integration layer.</p>')

let session = null
let stream = null
let audioContext = null
let processor = null
let micSource = null
let silentGain = null
let live = false
let connecting = false
let nextPlayTime = 0
const playingSources = new Set()

function setStatus(status, label) {
  $('status').textContent = status
  $('mic-label').textContent = label

  const mini = $('mini-status')
  const screen = document.querySelector('.screen')
  if (mini) {
    const value = String(status).toUpperCase()
    if (value.includes('SPEAKING')) mini.textContent = 'Speaking'
    else if (value.includes('PROCESSING') || value.includes('CONNECTING')) mini.textContent = 'Processing'
    else if (value.includes('LISTENING')) mini.textContent = 'Listening'
    else mini.textContent = 'Quiet'
  }

  if (screen) {
    screen.classList.toggle('hayat-active', Boolean(live || connecting))
    screen.classList.toggle('hayat-speaking', String(status).toUpperCase().includes('SPEAKING'))
  }
}

function base64FromBytes(bytes) {
  let binary = ''
  const step = 0x8000
  for (let i = 0; i < bytes.length; i += step) {
    binary += String.fromCharCode(...bytes.subarray(i, i + step))
  }
  return btoa(binary)
}

function resampleTo16k(input, inputRate) {
  if (inputRate === 16000) return input
  const ratio = inputRate / 16000
  const length = Math.floor(input.length / ratio)
  const output = new Float32Array(length)
  for (let i = 0; i < length; i++) {
    const start = Math.floor(i * ratio)
    const end = Math.min(Math.floor((i + 1) * ratio), input.length)
    let sum = 0
    for (let j = start; j < end; j++) sum += input[j]
    output[i] = sum / Math.max(1, end - start)
  }
  return output
}

function floatToPcm16(floatSamples) {
  const pcm = new Int16Array(floatSamples.length)
  for (let i = 0; i < floatSamples.length; i++) {
    const s = Math.max(-1, Math.min(1, floatSamples[i]))
    pcm[i] = s < 0 ? s * 32768 : s * 32767
  }
  return pcm
}

function stopPlayback() {
  for (const source of playingSources) {
    try { source.stop() } catch {}
  }
  playingSources.clear()
  if (audioContext) nextPlayTime = audioContext.currentTime
}

function playAudio(base64) {
  if (!audioContext) return

  const binary = atob(base64)
  const pcm = new Int16Array(binary.length / 2)
  for (let i = 0; i < pcm.length; i++) {
    pcm[i] = (binary.charCodeAt(i * 2) & 255) |
      (binary.charCodeAt(i * 2 + 1) << 8)
  }

  const buffer = audioContext.createBuffer(1, pcm.length, 24000)
  const channel = buffer.getChannelData(0)
  for (let i = 0; i < pcm.length; i++) channel[i] = pcm[i] / 32768

  const source = audioContext.createBufferSource()
  source.buffer = buffer
  source.connect(audioContext.destination)
  source.onended = () => playingSources.delete(source)

  const startAt = Math.max(audioContext.currentTime + 0.02, nextPlayTime)
  source.start(startAt)
  nextPlayTime = startAt + buffer.duration
  playingSources.add(source)
}

async function stopLive() {
  live = false
  connecting = false

  if (processor) {
    processor.onaudioprocess = null
    try { processor.disconnect() } catch {}
    processor = null
  }
  if (micSource) {
    try { micSource.disconnect() } catch {}
    micSource = null
  }
  if (silentGain) {
    try { silentGain.disconnect() } catch {}
    silentGain = null
  }
  if (stream) {
    stream.getTracks().forEach(track => track.stop())
    stream = null
  }
  if (session) {
    const oldSession = session
    session = null
    try { oldSession.close() } catch {}
  }
  stopPlayback()
  if (audioContext) {
    const oldContext = audioContext
    audioContext = null
    try { await oldContext.close() } catch {}
  }

  $('orb').classList.remove('active')
  setStatus('READY TO CONNECT', 'START LIVE VOICE')
  $('response').textContent = 'Live conversation ended. Tap to talk again.'
}

async function startLive() {
  if (connecting || live) return
  connecting = true
  $('response').textContent = 'Connecting to Gemini Live...'
  setStatus('CONNECTING...', 'CONNECTING...')

  try {
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error('Microphone access is unavailable. Open Hayat through localhost or HTTPS.')
    }

    const tokenResponse = await fetch('/api/token', { method: 'POST' })
    const tokenData = await tokenResponse.json()
    if (!tokenResponse.ok || !tokenData.token) {
      throw new Error(tokenData.error || 'Could not create a Live session token.')
    }

    stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      }
    })

    audioContext = new AudioContext()
    await audioContext.resume()

    const ai = new GoogleGenAI({ apiKey: tokenData.token })
    session = await ai.live.connect({
      model: 'gemini-3.8-live',
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' }
          }
        },
        systemInstruction: {
          parts: [{
            text: 'You are Hayat, a friendly personal AI assistant. Speak naturally and concisely. Adapt to the language the user speaks, including Hindi, Urdu, Nepali, and English. This is a real-time voice conversation.'
          }]
        },
        inputAudioTranscription: {},
        outputAudioTranscription: {}
      },
      callbacks: {
        onopen: () => {
          live = true
          connecting = false
          $('orb').classList.add('active')
          setStatus('LIVE • LISTENING', 'STOP LIVE VOICE')
            $('response').textContent = "I'm listening. Speak naturally."
        },
        onmessage: message => {
          const content = message.serverContent
          if (content?.interrupted) stopPlayback()

          const inputText = content?.inputTranscription?.text
          const outputText = content?.outputTranscription?.text
          if (inputText) { $('response').textContent = 'You: ' + inputText; setStatus('LIVE • PROCESSING', 'STOP LIVE VOICE') }
          if (outputText) $('response').textContent = 'Hayat: ' + outputText

          for (const part of content?.modelTurn?.parts || []) {
            if (part.inlineData?.data && part.inlineData.mimeType?.startsWith('audio/')) {
              playAudio(part.inlineData.data)
              setStatus('LIVE • HAYAT SPEAKING', 'STOP LIVE VOICE')
            }
          }

          if (content?.turnComplete) {
            setStatus('LIVE • LISTENING', 'STOP LIVE VOICE')
          }
        },
        onerror: error => {
          console.error('Gemini Live error:', error)
          $('response').textContent = 'Live connection error. Stop the session and try again.'
          setStatus('CONNECTION ERROR', 'STOP / RETRY')
        },
        onclose: () => {
          if (live) {
            live = false
            connecting = false
            $('orb').classList.remove('active')
            setStatus('CONNECTION CLOSED', 'START LIVE VOICE')
          }
        }
      }
    })

    micSource = audioContext.createMediaStreamSource(stream)
    processor = audioContext.createScriptProcessor(2048, 1, 1)
    silentGain = audioContext.createGain()
    silentGain.gain.value = 0

    processor.onaudioprocess = event => {
      if (!live || !session) return
      const input = event.inputBuffer.getChannelData(0)
      const resampled = resampleTo16k(input, audioContext.sampleRate)
      const pcm = floatToPcm16(resampled)
      const bytes = new Uint8Array(pcm.buffer)

      session.sendRealtimeInput({
        audio: {
          data: base64FromBytes(bytes),
          mimeType: 'audio/pcm;rate=16000'
        }
      })
    }

    micSource.connect(processor)
    processor.connect(silentGain)
    silentGain.connect(audioContext.destination)

  } catch (error) {
    console.error('Hayat Live setup failed:', error)
    const message = error?.message || 'Unknown error'
    await stopLive()
    $('response').textContent = 'Could not start Live Voice: ' + message
    setStatus('SETUP FAILED', 'TAP TO RETRY')
  }
}

$('mic').onclick = () => {
  if (live || connecting) stopLive()
  else startLive()
}

window.addEventListener('beforeunload', () => {
  try { session?.close() } catch {}
  try { stream?.getTracks().forEach(track => track.stop()) } catch {}
})
