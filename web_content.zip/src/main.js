import { createClient } from "@supabase/supabase-js";
import "./style.css";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = (SUPABASE_URL && SUPABASE_ANON_KEY)
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const SCHOOL_CODE = "21511";
const app = document.querySelector("#app");
let session = null;
let profile = null;
let route = "home";

const demo = {
  posts: [
    {id:"demo1", user:"Hallway", handle:"@hallway", text:"Welcome to Hallway! Your school's private community starts here.", time:"Just now", likes:0, comments:0},
    {id:"demo2", user:"School News", handle:"@schoolnews", text:"Use the Events tab for school announcements and upcoming activities.", time:"Today", likes:0, comments:0}
  ]
};

function esc(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function avatar(name="H"){return `<div class="avatar">${esc(name.trim().charAt(0).toUpperCase()||"H")}</div>`;}
function toast(msg){const t=document.createElement("div");t.className="toast";t.textContent=msg;document.body.append(t);setTimeout(()=>t.remove(),2400);}
function saveLocal(key,val){localStorage.setItem(key,JSON.stringify(val));}
function getLocal(key, fallback){try{return JSON.parse(localStorage.getItem(key)) ?? fallback}catch{return fallback}}

async function getProfile(){
  if(!supabase || !session) return null;
  const {data} = await supabase.from("profiles").select("*").eq("id",session.user.id).maybeSingle();
  return data;
}

async function signOut(){
  if(supabase) await supabase.auth.signOut();
  session=null; profile=null; render();
}

function shell(content){
  return `<div class="app-shell">
    <header class="topbar"><div class="brand"><span class="logo">H</span><b>Hallway</b></div>
      ${session ? `<button class="icon-btn" id="logout" aria-label="Sign out">↪</button>` : ""}
    </header>
    <main class="content">${content}</main>
    ${session ? `<nav class="nav">
      <button data-route="home" class="${route==="home"?"active":""}">⌂<span>Home</span></button>
      <button data-route="search" class="${route==="search"?"active":""}">⌕<span>Search</span></button>
      <button data-route="create" class="create">＋</button>
      <button data-route="messages" class="${route==="messages"?"active":""}">✉<span>Chats</span></button>
      <button data-route="profile" class="${route==="profile"?"active":""}">◉<span>Profile</span></button>
    </nav>` : ""}
  </div>`;
}

function loginView(){
 return `<div class="auth">
   <div class="hero"><div class="big-logo">H</div><h1>Hallway</h1><p>Your school's private community.</p></div>
   <section class="card">
     <h2>Join your school</h2><p class="muted">Enter the school code to continue.</p>
     <input id="schoolCode" inputmode="numeric" maxlength="5" placeholder="School code" />
     <input id="email" type="email" placeholder="Email address" />
     <button class="primary" id="continue">Continue</button>
     <p class="tiny">For school communities only. Your school code is verified before account access.</p>
   </section>
 </div>`;
}

async function login(){
 const code=document.querySelector("#schoolCode").value.trim();
 const email=document.querySelector("#email").value.trim();
 if(code!==SCHOOL_CODE) return toast("That school code isn't recognized.");
 if(!email || !email.includes("@")) return toast("Enter a valid email.");
 if(!supabase){ saveLocal("hallway_guest",{email,school_code:code}); toast("Website preview mode is ready."); session={user:{id:"local"}}; profile={username:email.split("@")[0],display_name:email.split("@")[0]}; render(); return; }
 const {error}=await supabase.auth.signInWithOtp({email, options:{emailRedirectTo:location.origin}});
 if(error) return toast(error.message);
 toast("Check your email for the sign-in link.");
}

async function homeView(){
 let posts=demo.posts;
 if(supabase && session){
   const {data}=await supabase.from("posts").select("id,body,created_at,profiles(username,display_name)").order("created_at",{ascending:false}).limit(50);
   if(data?.length) posts=data.map(p=>({id:p.id,user:p.profiles?.display_name||p.profiles?.username||"Student",handle:p.profiles?.username?`@${p.profiles.username}`:"",text:p.body,time:new Date(p.created_at).toLocaleString(),likes:0,comments:0}));
 }
 return `<div class="page-head"><div><h1>Home</h1><p class="muted">What's happening at school?</p></div><button class="pill" data-route="create">Post</button></div>
 <div class="notice">🔒 <b>School-only space</b><br><span>You're viewing the Hallway community for code ${SCHOOL_CODE}.</span></div>
 <div id="feed">${posts.map(postCard).join("")}</div>`;
}
function postCard(p){
 return `<article class="post card"><div class="post-head">${avatar(p.user)}<div><b>${esc(p.user)}</b><small>${esc(p.handle)} · ${esc(p.time)}</small></div><button class="more">•••</button></div>
 <p>${esc(p.text)}</p><div class="actions"><button data-like="${p.id}">♡ ${p.likes}</button><button data-comment="${p.id}">◯ ${p.comments}</button><button data-share="${p.id}">↗ Share</button></div></article>`;
}
function createView(){
 return `<div class="page-head"><h1>Create post</h1></div>
 <section class="card compose"><textarea id="postBody" maxlength="1000" placeholder="What's happening?"></textarea>
 <div class="compose-row"><span class="muted">Be respectful. Don't share private information.</span><button class="primary small" id="publish">Post</button></div></section>`;
}
function searchView(){
 return `<div class="page-head"><h1>Search</h1></div><div class="searchbox"><span>⌕</span><input id="searchInput" placeholder="Find students or posts..." /></div>
 <section class="card"><h3>Student directory</h3><p class="muted">Search is limited to your school community.</p><div id="results"><div class="empty">Start typing to search.</div></div></section>`;
}
function messagesView(){
 return `<div class="page-head"><div><h1>Chats</h1><p class="muted">Private conversations with your school community.</p></div><button class="pill" id="newChat">New</button></div>
 <section class="card"><div class="empty"><div class="empty-icon">✉</div><b>No conversations yet</b><p>When you message someone, your conversations will appear here.</p></div></section>`;
}
function profileView(){
 const p=profile||getLocal("hallway_guest",{});
 const name=p.display_name||p.username||"Student";
 return `<div class="profile-hero"><div class="profile-avatar">${esc(name.charAt(0).toUpperCase())}</div><h1>${esc(name)}</h1><p class="muted">@${esc(p.username||"student")}</p><button class="secondary">Edit profile</button></div>
 <div class="stats"><div><b>0</b><span>Posts</span></div><div><b>0</b><span>Followers</span></div><div><b>0</b><span>Following</span></div></div>
 <section class="card settings"><button>🔔 Notifications <span>›</span></button><button>🔒 Privacy <span>›</span></button><button>🚫 Blocked accounts <span>›</span></button><button>⚠ Report a problem <span>›</span></button></section>`;
}

async function render(){
 if(!session){app.innerHTML=loginView(); document.querySelector("#continue").onclick=login; return;}
 let body="";
 if(route==="home") body=await homeView();
 if(route==="create") body=createView();
 if(route==="search") body=searchView();
 if(route==="messages") body=messagesView();
 if(route==="profile") body=profileView();
 app.innerHTML=shell(body);
 document.querySelector("#logout")?.addEventListener("click",signOut);
 document.querySelectorAll("[data-route]").forEach(b=>b.addEventListener("click",()=>{route=b.dataset.route;render();}));
 document.querySelector("#publish")?.addEventListener("click",publish);
 document.querySelector("#searchInput")?.addEventListener("input",e=>searchStudents(e.target.value));
 document.querySelector("#newChat")?.addEventListener("click",()=>toast("Choose a student from Search to start a chat."));
 document.querySelectorAll("[data-like]").forEach(b=>b.onclick=()=>{b.textContent="♥ "+(Number(b.textContent.replace(/\D/g,""))+1);});
 document.querySelectorAll("[data-comment]").forEach(b=>b.onclick=()=>toast("Comments are ready once the database is connected."));
 document.querySelectorAll("[data-share]").forEach(b=>b.onclick=()=>navigator.clipboard?.writeText(location.href).then(()=>toast("Link copied.")));
}
async function publish(){
 const body=document.querySelector("#postBody").value.trim();
 if(!body) return toast("Write something first.");
 if(supabase && session){
   const {error}=await supabase.from("posts").insert({author_id:session.user.id,body});
   if(error) return toast(error.message);
 }else{
   const posts=getLocal("hallway_posts",[]);
   posts.unshift({id:crypto.randomUUID(),user:profile?.display_name||"You",handle:"@"+(profile?.username||"you"),text:body,time:"Just now",likes:0,comments:0});
   saveLocal("hallway_posts",posts);
 }
 toast("Posted!"); route="home"; render();
}
async function searchStudents(q){
 const el=document.querySelector("#results"); if(!el)return;
 if(!q.trim()){el.innerHTML='<div class="empty">Start typing to search.</div>';return;}
 if(!supabase){el.innerHTML=`<div class="person">${avatar(q)}<div><b>${esc(q)}</b><small>Connect the database to search real students.</small></div></div>`;return;}
 const {data}=await supabase.from("profiles").select("username,display_name").or(`username.ilike.%${q}%,display_name.ilike.%${q}%`).limit(20);
 el.innerHTML=data?.length?data.map(p=>`<div class="person">${avatar(p.display_name||p.username)}<div><b>${esc(p.display_name||p.username)}</b><small>@${esc(p.username)}</small></div><button class="secondary">Message</button></div>`).join(""):'<div class="empty">No students found.</div>';
}

if(supabase){
 supabase.auth.getSession().then(async ({data})=>{session=data.session;if(session) profile=await getProfile();render();});
 supabase.auth.onAuthStateChange((_e,s)=>{session=s;render();});
}else{
 const guest=getLocal("hallway_guest",null);
 if(guest){session={user:{id:"local"}};profile={username:guest.email.split("@")[0],display_name:guest.email.split("@")[0]};}
 render();
}