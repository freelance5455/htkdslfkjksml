
        // ============================================================
        // أبناء د. سراج — V2.0 Performance Edition
        // الهدف: فتح فوري، تحميل Firebase عند الحاجة، كاش محلي،
        // وتقليل إعادة رسم الجدول على الهواتف.
        // ============================================================
        import './style.css';
        import '@fontsource/cairo/400.css';
        import '@fontsource/cairo/600.css';
        import '@fontsource/cairo/700.css';
        import '@fontsource/cairo/800.css';
        import { initializeApp } from 'firebase/app';
        import { initializeAuth, indexedDBLocalPersistence, browserLocalPersistence, signInAnonymously } from 'firebase/auth';
        import { initializeFirestore, persistentLocalCache, persistentSingleTabManager, collection, onSnapshot, doc, setDoc, deleteDoc } from 'firebase/firestore';
        import { Capacitor } from '@capacitor/core';
        import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
        import { Share } from '@capacitor/share';
        import { initNative, tap } from './native.js';
        import { firebaseConfig, isConfigPlaceholder, appId } from './firebase-config.js';

        const CACHE_KEY = 'serag_residents_backup_v2';
        const PENDING_KEY = 'serag_pending_ops_v1';
        let app = null, auth = null, db = null;
        const firestoreApi = { collection, onSnapshot, doc, setDoc, deleteDoc };
        try {
            app = initializeApp(firebaseConfig);
            auth = initializeAuth(app, { persistence: [indexedDBLocalPersistence, browserLocalPersistence] });
            try {
                db = initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentSingleTabManager() }) });
            } catch (e) {
                db = initializeFirestore(app, {});
            }
        } catch (e) {
            console.error('Firebase init failed:', e);
        }

        let currentUser = null;
        let residents = [];
        let residentsMap = new Map();
        let deleteIdTarget = null;
        let unsubscribeResidents = null;
        let renderFrame = 0;

        // عناصر DOM
        const form = document.getElementById('residentForm');
        const tableBody = document.getElementById('residentsTableBody');
        const formTitle = document.getElementById('formTitle');
        const cancelEditBtn = document.getElementById('cancelEditBtn');
        const searchInput = document.getElementById('searchInput');
        const cloudStatusDot = document.getElementById('cloudStatusDot');
        const cloudStatusText = document.getElementById('cloudStatusText');
        const cloudStatusBadge = document.getElementById('cloudStatusBadge');
        const savingSpinner = document.getElementById('savingSpinner');

        // ---------- أدوات الأداء ----------
        function scheduleRender() {
            cancelAnimationFrame(renderFrame);
            renderFrame = requestAnimationFrame(() => renderTable());
        }

        function saveLocalCache() {
            try {
                localStorage.setItem(CACHE_KEY, JSON.stringify(residents));
            } catch (e) {
                console.warn('تعذر حفظ الكاش المحلي:', e);
            }
        }

        function loadLocalCache() {
            try {
                const saved = localStorage.getItem(CACHE_KEY) ||
                               localStorage.getItem('serag_residents_backup');
                if (!saved) return false;
                const data = JSON.parse(saved);
                if (!Array.isArray(data)) return false;
                residents = data;
                residentsMap = new Map(data.map(r => [r.id, r]));
                scheduleRender();
                return true;
            } catch (e) {
                console.warn('تعذر قراءة الكاش المحلي:', e);
                return false;
            }
        }

        function paintStatus(status) {
            if (!cloudStatusDot || !cloudStatusText || !cloudStatusBadge) return;

            if (status === 'connected') {
                cloudStatusDot.className = "w-2 h-2 rounded-full bg-emerald-500";
                cloudStatusText.textContent = "متصل بالسحابة ☁️";
                cloudStatusBadge.className = "inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-700 text-xs font-semibold rounded-full border border-emerald-200/60";
            } else if (status === 'saving') {
                // بدون animate-ping لتقليل استهلاك الرسم على الهاتف.
                cloudStatusDot.className = "w-2 h-2 rounded-full bg-indigo-500";
                cloudStatusText.textContent = "جاري الحفظ...";
                cloudStatusBadge.className = "inline-flex items-center gap-1.5 px-2.5 py-1 bg-indigo-50 text-indigo-700 text-xs font-semibold rounded-full border border-indigo-200/60";
            } else if (status === 'offline') {
                cloudStatusDot.className = "w-2 h-2 rounded-full bg-amber-500";
                cloudStatusText.textContent = "يعمل من النسخة المحلية";
                cloudStatusBadge.className = "inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 text-amber-700 text-xs font-semibold rounded-full border border-amber-200/60";
            } else {
                cloudStatusDot.className = "w-2 h-2 rounded-full bg-red-500";
                cloudStatusText.textContent = "غير متصل";
                cloudStatusBadge.className = "inline-flex items-center gap-1.5 px-2.5 py-1 bg-red-50 text-red-700 text-xs font-semibold rounded-full border border-red-200/60";
            }
        }

        function updateCloudStatus(status, text) {
            paintStatus(status);
            if (text && cloudStatusText) cloudStatusText.textContent = text;
        }

        // ---------- تصنيف الأخطاء ----------
        function explainError(err) {
            const code = (err && err.code) || '';
            if (!netOnline || code === 'auth/network-request-failed' || code === 'unavailable')
                return { kind: 'network', msg: 'لا يوجد اتصال بالإنترنت — يعمل من النسخة المحلية' };
            if (code === 'auth/operation-not-allowed' || code === 'auth/admin-restricted-operation')
                return { kind: 'config', msg: 'فعّل Anonymous من Firebase ← Authentication' };
            if (code.startsWith('auth/invalid-api-key') || code.startsWith('auth/api-key'))
                return { kind: 'config', msg: 'مفتاح Firebase غير صحيح' };
            if (code === 'permission-denied')
                return { kind: 'rules', msg: 'قواعد Firestore ترفض الوصول' };
            if (code === 'auth/too-many-requests')
                return { kind: 'retry', msg: 'محاولات كثيرة، سيعاد الاتصال تلقائياً' };
            return { kind: 'unknown', msg: 'تعذر الاتصال بالسحابة' };
        }

        function withTimeout(p, ms) {
            return Promise.race([p, new Promise((_, rej) => setTimeout(() => rej({ code: 'auth/network-request-failed' }), ms))]);
        }

        // ---------- طابور العمليات المحلية (يعمل بدون إنترنت) ----------
        function loadPending() { try { return JSON.parse(localStorage.getItem(PENDING_KEY) || '[]'); } catch (e) { return []; } }
        function savePending(list) { try { localStorage.setItem(PENDING_KEY, JSON.stringify(list)); } catch (e) {} }
        function queueOp(op) {
            const list = loadPending().filter(o => o.id !== op.id);
            list.push({ ...op, ts: Date.now() });
            savePending(list);
        }

        let flushP = null;
        function flushPending() {
            if (!flushP) flushP = flushLoop().finally(() => { flushP = null; });
            return flushP;
        }
        async function flushLoop() {
            if (!db || !currentUser) return;
            for (;;) {
                const op = loadPending()[0];
                if (!op) return;
                const ref = doc(db, 'artifacts', appId, 'public', 'data', 'residents', op.id);
                try {
                    if (op.type === 'delete') await withTimeout(deleteDoc(ref), 15000);
                    else await withTimeout(setDoc(ref, op.data, { merge: true }), 15000);
                } catch (e) {
                    throw e && e.code === 'permission-denied' ? e : { code: 'unavailable' };
                }
                savePending(loadPending().filter(o => !(o.id === op.id && o.ts === op.ts)));
            }
        }

        function persistOp(op) {
            queueOp(op);
            if (currentUser && db) {
                flushPending()
                    .then(() => updateCloudStatus('connected'))
                    .catch(() => connectToCloud());
            } else {
                connectToCloud();
            }
        }

        // ---------- الاتصال مع إعادة المحاولة ----------
        let connecting = false, retryTimer = 0, retryDelay = 3000;
        let netOnline = navigator.onLine;

        async function connectToCloud(manual = false) {
            if (connecting) return;
            clearTimeout(retryTimer);

            if (isConfigPlaceholder || !db || !auth) {
                updateCloudStatus('error', 'إعدادات Firebase غير مكتملة');
                if (manual) showMessage('أدخل بيانات Firebase الحقيقية في src/firebase-config.js', 'error');
                return;
            }
            if (!netOnline) {
                updateCloudStatus('offline', 'بدون إنترنت — يعمل من النسخة المحلية');
                return;
            }

            connecting = true;
            updateCloudStatus('saving', 'جاري الاتصال بالسحابة...');
            try {
                if (!auth.currentUser) await withTimeout(signInAnonymously(auth), 15000);
                currentUser = auth.currentUser;
                await flushPending();
                listenToCloudData();
                retryDelay = 3000;
                updateCloudStatus('connected');
                if (manual) showMessage('تم الاتصال بالسحابة ✅', 'success');
            } catch (err) {
                console.error('خطأ في الاتصال بالسحابة:', err);
                const info = explainError(err);
                updateCloudStatus(info.kind === 'network' ? 'offline' : 'error', info.msg + ' — اضغط للمحاولة');
                if (manual) showMessage(info.msg, 'error');
                if (['network', 'unknown', 'retry'].includes(info.kind)) {
                    retryTimer = setTimeout(() => connectToCloud(), retryDelay);
                    retryDelay = Math.min(retryDelay * 2, 60000);
                }
            } finally {
                connecting = false;
            }
        }

        function initializeCloudSync() {
            loadLocalCache();
            cloudStatusBadge.style.cursor = 'pointer';
            cloudStatusBadge.addEventListener('click', () => { retryDelay = 3000; connectToCloud(true); });
            const handleNet = (connected) => {
                netOnline = connected;
                if (connected) { retryDelay = 3000; connectToCloud(); }
                else updateCloudStatus('offline', 'بدون إنترنت — يعمل من النسخة المحلية');
            };
            window.addEventListener('online', () => handleNet(true));
            window.addEventListener('offline', () => handleNet(false));
            initNative({
                showMessage,
                onNetwork: handleNet,
                onBack: () => {
                    const modal = document.getElementById('deleteModal');
                    if (modal && !modal.classList.contains('hidden')) { window.closeDeleteModal(); return true; }
                    if (document.getElementById('residentId').value) { window.resetForm(); return true; }
                    return false;
                }
            });
            connectToCloud();
        }

        function listenToCloudData() {
            if (!currentUser || !db) return;
            const residentsCollection = collection(db, 'artifacts', appId, 'public', 'data', 'residents');
            if (unsubscribeResidents) unsubscribeResidents();
            let first = true;

            unsubscribeResidents = onSnapshot(
                residentsCollection,
                (snapshot) => {
                    // كاش فارغ أثناء انقطاع الإنترنت: لا نمسح البيانات المحلية.
                    if (snapshot.metadata.fromCache && snapshot.empty && residentsMap.size) return;

                    if (first) {
                        residentsMap = new Map();
                        snapshot.docs.forEach(d => residentsMap.set(d.id, { id: d.id, ...d.data() }));
                        first = false;
                    } else {
                        snapshot.docChanges().forEach(change => {
                            if (change.type === 'removed') residentsMap.delete(change.doc.id);
                            else residentsMap.set(change.doc.id, { id: change.doc.id, ...change.doc.data() });
                        });
                    }
                    residents = Array.from(residentsMap.values()).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
                    saveLocalCache();
                    updateCloudStatus('connected');
                    scheduleRender();
                },
                (error) => {
                    console.error('خطأ في الاستماع للبيانات:', error);
                    const info = explainError(error);
                    updateCloudStatus(info.kind === 'network' ? 'offline' : 'error', info.msg + ' — اضغط للمحاولة');
                }
            );
        }

        // ---------- الجدول ----------
        function escapeHTML(value) {
            return String(value ?? '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function buildResidentRow(resident) {
            const tr = document.createElement('tr');
            // إزالة fade-in لكل صف: هذا مهم عند وجود عدد كبير من السكان.
            tr.className = 'border-b border-slate-100';

            let statusBadge = '';
            if (resident.status === 'paid') {
                statusBadge = '<span class="px-2.5 py-1 bg-emerald-100/80 text-emerald-800 rounded-full text-xs font-bold border border-emerald-200/50">تم الدفع ✅</span>';
            } else if (resident.status === 'unpaid') {
                statusBadge = '<span class="px-2.5 py-1 bg-red-100/80 text-red-800 rounded-full text-xs font-bold border border-red-200/50">لم يدفع ❌</span>';
            } else {
                statusBadge = '<span class="px-2.5 py-1 bg-amber-100/80 text-amber-800 rounded-full text-xs font-bold border border-amber-200/50">دفع جزئي ⏳</span>';
            }

            const id = escapeHTML(resident.id);
            const unit = escapeHTML(resident.unit || '-');
            const name = escapeHTML(resident.name || '-');
            const phone = escapeHTML(resident.phone || '');
            const amount = escapeHTML(resident.amount || 0);
            const notes = escapeHTML(resident.notes || '');

            tr.innerHTML = `
                <td class="px-4 py-3.5 font-bold text-slate-900 whitespace-nowrap">${unit}</td>
                <td class="px-4 py-3.5">
                    <div class="font-bold text-slate-800">${name}</div>
                    ${phone ? `<a href="tel:${phone}" class="text-xs text-indigo-600 inline-block mt-0.5" dir="ltr">${phone}</a>` : ''}
                </td>
                <td class="px-4 py-3.5 font-semibold text-slate-800">${amount} ج.م</td>
                <td class="px-4 py-3.5 text-center">${statusBadge}</td>
                <td class="px-4 py-3.5 text-center">
                    <div class="flex justify-center items-center gap-1.5">
                        <button data-action="edit" data-id="${id}" class="text-indigo-600 bg-indigo-50 w-11 h-11 flex items-center justify-center rounded-xl" title="تعديل">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                        </button>
                        <button data-action="delete" data-id="${id}" class="text-red-600 bg-red-50 w-11 h-11 flex items-center justify-center rounded-xl" title="حذف">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                        </button>
                    </div>
                </td>
            `;

            if (notes.trim()) {
                const notesTr = document.createElement('tr');
                notesTr.className = 'border-b border-slate-100 bg-slate-50/60';
                notesTr.innerHTML = `
                    <td colspan="5" class="px-4 py-2 text-xs text-slate-500">
                        <span class="font-bold text-slate-600">ملاحظة:</span> ${notes}
                    </td>
                `;
                return [tr, notesTr];
            }
            return [tr];
        }

        function renderTable() {
            const searchTerm = (searchInput.value || '').trim().toLocaleLowerCase('ar-EG');
            const filtered = searchTerm
                ? residents.filter(r =>
                    String(r.name || '').toLocaleLowerCase('ar-EG').includes(searchTerm) ||
                    String(r.unit || '').toLocaleLowerCase('ar-EG').includes(searchTerm) ||
                    String(r.phone || '').includes(searchTerm)
                )
                : residents;

            const fragment = document.createDocumentFragment();

            if (!filtered.length) {
                const tr = document.createElement('tr');
                tr.innerHTML = `<td colspan="5" class="px-4 py-8 text-center text-slate-400 font-medium">لا توجد بيانات مطابقة للبحث</td>`;
                fragment.appendChild(tr);
            } else {
                // نعرض جميع السجلات بدون إنشاء عناصر إضافية غير ضرورية.
                for (const resident of filtered) {
                    const rows = buildResidentRow(resident);
                    rows.forEach(row => fragment.appendChild(row));
                }
            }

            tableBody.replaceChildren(fragment);
            updateStats();
        }

        // تحديث الإحصائيات في عملية واحدة بدلاً من 3 عمليات filter.
        function updateStats() {
            const statsContainer = document.getElementById('statsContainer');
            if (!statsContainer) return;

            let paidCount = 0, unpaidCount = 0;
            let expectedIncome = 0, collectedIncome = 0;

            for (const r of residents) {
                const amt = Number(r.amount) || 0;
                expectedIncome += amt;
                if (r.status === 'paid') {
                    paidCount++;
                    collectedIncome += amt;
                } else if (r.status === 'unpaid') {
                    unpaidCount++;
                } else if (r.status === 'partial') {
                    collectedIncome += amt / 2;
                }
            }

            statsContainer.innerHTML = `
                <div class="bg-indigo-50/70 p-3 rounded-xl text-center border border-indigo-100">
                    <div class="text-[11px] text-indigo-700 font-bold mb-0.5">إجمالي الوحدات</div>
                    <div class="text-lg sm:text-xl font-extrabold text-indigo-900">${residents.length}</div>
                </div>
                <div class="bg-emerald-50/70 p-3 rounded-xl text-center border border-emerald-100">
                    <div class="text-[11px] text-emerald-700 font-bold mb-0.5">تم الدفع</div>
                    <div class="text-lg sm:text-xl font-extrabold text-emerald-900">${paidCount}</div>
                </div>
                <div class="bg-red-50/70 p-3 rounded-xl text-center border border-red-100">
                    <div class="text-[11px] text-red-700 font-bold mb-0.5">لم يدفع</div>
                    <div class="text-lg sm:text-xl font-extrabold text-red-900">${unpaidCount}</div>
                </div>
                <div class="bg-amber-50/70 p-3 rounded-xl text-center border border-amber-100">
                    <div class="text-[11px] text-amber-700 font-bold mb-0.5">التحصيل الحسابي</div>
                    <div class="text-base sm:text-lg font-extrabold text-amber-900">${collectedIncome} <span class="text-xs font-normal">من ${expectedIncome}</span></div>
                </div>
            `;
        }

        // تفويض الأحداث: زر واحد للجدول بدلاً من onclick لكل صف.
        tableBody.addEventListener('click', (e) => {
            const btn = e.target.closest('button[data-action]');
            if (!btn) return;
            const id = btn.dataset.id;
            if (btn.dataset.action === 'edit') editResident(id);
            if (btn.dataset.action === 'delete') openDeleteModal(id);
        });

        // البحث مع debounce 120ms.
        let searchTimer = 0;
        searchInput.addEventListener('input', () => {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(scheduleRender, 120);
        });

        window.renderTable = renderTable;

        // ---------- الحفظ والتعديل ----------
        form.addEventListener('submit', function(e) {
            e.preventDefault();

            const id = document.getElementById('residentId').value;
            const name = document.getElementById('name').value.trim();
            const unit = document.getElementById('unit').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const amount = parseFloat(document.getElementById('amount').value) || 0;
            const status = document.getElementById('status').value;
            const notes = document.getElementById('notes').value.trim();

            if (!name || !unit) {
                showMessage('يرجى ملء كافة الحقول المطلوبة', 'error');
                return;
            }

            const residentDocId = id || ('res_' + Date.now());
            const data = { name, unit, phone, amount, status, notes, updatedAt: Date.now() };
            if (!id) data.createdAt = Date.now();

            // حفظ فوري محلياً (بدون انتظار الشبكة) ثم مزامنة في الخلفية.
            const old = residentsMap.get(residentDocId) || {};
            residentsMap.set(residentDocId, { ...old, ...data, id: residentDocId });
            residents = Array.from(residentsMap.values()).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            saveLocalCache();
            scheduleRender();
            persistOp({ type: 'set', id: residentDocId, data });

            showMessage(id ? 'تم تحديث البيانات ✅' : 'تمت إضافة الساكن ✅', 'success');
            resetForm();
        });

        window.editResident = function(id) {
            const resident = residentsMap.get(id);
            if (!resident) return;

            document.getElementById('residentId').value = resident.id;
            document.getElementById('name').value = resident.name || '';
            document.getElementById('unit').value = resident.unit || '';
            document.getElementById('phone').value = resident.phone || '';
            document.getElementById('amount').value = resident.amount || 0;
            document.getElementById('status').value = resident.status || 'unpaid';
            document.getElementById('notes').value = resident.notes || '';

            formTitle.innerHTML = '<span class="w-2.5 h-2.5 bg-amber-500 rounded-full"></span> تعديل بيانات الساكن';
            cancelEditBtn.classList.remove('hidden');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        };

        window.resetForm = function() {
            form.reset();
            document.getElementById('residentId').value = '';
            formTitle.innerHTML = '<span class="w-2.5 h-2.5 bg-indigo-600 rounded-full"></span> إضافة ساكن جديد';
            cancelEditBtn.classList.add('hidden');
        };

        // ---------- الحذف ----------
        window.openDeleteModal = function(id) {
            deleteIdTarget = id;
            document.getElementById('deleteModal').classList.remove('hidden');
        };

        window.closeDeleteModal = function() {
            deleteIdTarget = null;
            document.getElementById('deleteModal').classList.add('hidden');
        };

        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            if (!deleteIdTarget) return;
            const id = deleteIdTarget;
            residentsMap.delete(id);
            residents = Array.from(residentsMap.values()).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            saveLocalCache();
            scheduleRender();
            persistOp({ type: 'delete', id });
            showMessage('تم حذف الساكن ✅', 'success');
            if (document.getElementById('residentId').value === id) resetForm();
            closeDeleteModal();
        });

        function showMessage(msg, type = 'success') {
            const toast = document.createElement('div');
            const bgColor = type === 'success' ? 'bg-emerald-600' : 'bg-red-600';
            toast.className = `fixed bottom-5 right-5 left-5 sm:left-auto ${bgColor} text-white px-5 py-3 rounded-2xl shadow-xl z-50 flex items-center justify-center sm:justify-start gap-2 text-xs sm:text-sm font-bold`;
            toast.innerHTML = `<span>${escapeHTML(msg)}</span>`;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 2600);
        }

        // ---------- CSV ----------
        window.exportToCSV = async function() {
            if (!residents.length) {
                showMessage("لا توجد بيانات للتصدير", "error");
                return;
            }

            const headers = ['الوحدة', 'الاسم', 'رقم الهاتف', 'المبلغ', 'الحالة', 'ملاحظات'];
            const statusMap = { paid: 'تم الدفع', unpaid: 'لم يدفع', partial: 'دفع جزئي' };
            const csvRows = [headers.join(',')];

            for (const row of residents) {
                csvRows.push([
                    `"${String(row.unit || '').replace(/"/g, '""')}"`,
                    `"${String(row.name || '').replace(/"/g, '""')}"`,
                    `"${String(row.phone || '').replace(/"/g, '""')}"`,
                    row.amount || 0,
                    `"${statusMap[row.status] || row.status || ''}"`,
                    `"${String(row.notes || '').replace(/"/g, '""')}"`
                ].join(','));
            }

            const csv = "\uFEFF" + csvRows.join('\n');
            if (Capacitor.isNativePlatform()) {
                try {
                    const fileName = `residents_${new Date().toISOString().slice(0, 10)}.csv`;
                    const res = await Filesystem.writeFile({ path: fileName, data: csv, directory: Directory.Cache, encoding: Encoding.UTF8 });
                    await Share.share({ title: 'سجل السكان', url: res.uri, dialogTitle: 'حفظ أو مشاركة السجل' });
                } catch (e) {
                    if (!/cancel/i.test(String((e && e.message) || e))) showMessage('تعذر تصدير الملف', 'error');
                }
                return;
            }
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `residents_${new Date().toISOString().slice(0, 10)}.csv`;
            link.click();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        };

        
        // ---------- سجل الأخطاء العام ----------
        function logError(kind, err) {
            try {
                const log = JSON.parse(localStorage.getItem('serag_error_log') || '[]');
                log.push({ t: new Date().toISOString(), kind, msg: String((err && (err.message || err.code)) || err).slice(0, 200) });
                localStorage.setItem('serag_error_log', JSON.stringify(log.slice(-20)));
            } catch (e) {}
        }
        let lastErrToast = 0;
        function onUnexpected(kind, err) {
            console.error(kind, err);
            logError(kind, err);
            if (Date.now() - lastErrToast > 5000) { lastErrToast = Date.now(); showMessage('حدث خطأ غير متوقع، البيانات محفوظة', 'error'); }
        }
        window.addEventListener('error', e => onUnexpected('error', e.error || e.message));
        window.addEventListener('unhandledrejection', e => onUnexpected('promise', e.reason));

        // ---------- لوحة المفاتيح: إبقاء الحقل ظاهراً ----------
        document.addEventListener('focusin', e => {
            if (e.target.matches('input, textarea, select'))
                setTimeout(() => e.target.scrollIntoView({ block: 'center', behavior: 'smooth' }), 300);
        });

        // ---------- اهتزاز خفيف عند الضغط ----------
        document.addEventListener('click', e => { if (e.target.closest('button')) tap(); }, { passive: true });

        // ---------- نسخ احتياطي واستعادة (JSON) ----------
        window.backupJSON = async function() {
            if (!residents.length) { showMessage('لا توجد بيانات للنسخ', 'error'); return; }
            const text = JSON.stringify({ app: 'serag-residents', version: 1, exportedAt: new Date().toISOString(), residents }, null, 2);
            const fileName = `siraj_backup_${new Date().toISOString().slice(0, 10)}.json`;
            if (Capacitor.isNativePlatform()) {
                try {
                    const res = await Filesystem.writeFile({ path: fileName, data: text, directory: Directory.Cache, encoding: Encoding.UTF8 });
                    await Share.share({ title: 'نسخة احتياطية', url: res.uri, dialogTitle: 'احفظ النسخة الاحتياطية' });
                } catch (e) {
                    if (!/cancel/i.test(String((e && e.message) || e))) showMessage('تعذر إنشاء النسخة', 'error');
                }
                return;
            }
            const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
            const a = document.createElement('a'); a.href = url; a.download = fileName; a.click();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        };

        window.restoreJSON = function() { document.getElementById('restoreInput').click(); };
        document.getElementById('restoreInput').addEventListener('change', async (e) => {
            const file = e.target.files[0];
            e.target.value = '';
            if (!file) return;
            try {
                const data = JSON.parse(await file.text());
                const list = Array.isArray(data) ? data : data.residents;
                if (!Array.isArray(list)) throw new Error('bad format');
                let n = 0;
                for (const r of list) {
                    if (!r || !r.name || !r.unit) continue;
                    const id = String(r.id || ('res_' + Date.now() + '_' + n));
                    const item = {
                        name: String(r.name), unit: String(r.unit), phone: String(r.phone || ''),
                        amount: Number(r.amount) || 0,
                        status: ['paid', 'unpaid', 'partial'].includes(r.status) ? r.status : 'unpaid',
                        notes: String(r.notes || ''), createdAt: r.createdAt || Date.now(), updatedAt: Date.now()
                    };
                    residentsMap.set(id, { ...item, id });
                    queueOp({ type: 'set', id, data: item });
                    n++;
                }
                residents = Array.from(residentsMap.values()).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
                saveLocalCache(); scheduleRender();
                showMessage(`تمت استعادة ${n} سجل ✅`, 'success');
                connectToCloud();
            } catch (err) {
                showMessage('ملف النسخة غير صالح', 'error');
            }
        });

        // تشغيل الكاش والواجهة فوراً، ثم الاتصال بالسحابة في الخلفية.
        scheduleRender();
        initializeCloudSync();
    