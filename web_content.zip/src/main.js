import { auth, db } from "./firebase.js";
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, onAuthStateChanged, sendPasswordResetEmail
} from "firebase/auth";
import {
  collection, doc, getDoc, getDocs, setDoc, addDoc, query, where,
  orderBy, serverTimestamp, runTransaction, onSnapshot
} from "firebase/firestore";

const $ = (s) => document.querySelector(s);
const screen = $("#screen");
let currentUser = null, userData = null, currentPage = "home", unsubscribe = null;
const money = (n=0) => `${Number(n).toLocaleString("en-IN")} pts`;
const safe = (v="") => String(v).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(msg) { const t=$("#toast"); t.textContent=msg; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),2600); }
function button(label, cls="primary", attrs="") { return `<button class="${cls}" ${attrs}>${label}</button>`; }

function authView(mode="login") {
  const signup = mode==="signup";
  screen.innerHTML = `<section class="auth-wrap"><div class="hero"><div class="logo big">C2</div><h1>CLASH <span>2.0</span></h1><p>Play fair. Compete together.</p></div>
  <div class="panel"><div class="tabs"><button id="loginTab" class="${!signup?"selected":""}">Login</button><button id="signupTab" class="${signup?"selected":""}">Sign Up</button></div>
  <form id="authForm">
  ${signup ? `<label>Full name<input name="fullName" required maxlength="70"></label>
  <label>Username<input name="username" required minlength="3" maxlength="20" pattern="[A-Za-z0-9_]+" placeholder="letters, numbers, underscore"></label>
  <label>Game UID<input name="gameUid" required maxlength="30"></label>
  <label>Game name<input name="gameName" required maxlength="30"></label>
  <label>Mobile number<input name="mobile" type="tel" required pattern="[0-9]{10}" maxlength="10"></label>
  <label>Gender<select name="gender"><option value="">Prefer not to say</option><option>Male</option><option>Female</option></select></label>
  <label>Date of birth<input name="dob" type="date" required></label>
  <label>Referral code (optional)<input name="referralCode" maxlength="24"></label>` : `<label>Email address<input name="email" type="email" required></label>`}
  ${signup?'<label>Email address<input name="email" type="email" required></label>':''}
  <label>Password<input name="password" type="password" required minlength="8"></label>
  ${signup?'<label>Confirm password<input name="confirmPassword" type="password" required minlength="8"></label>':''}
  ${signup?'<label class="check"><input name="terms" type="checkbox" required> I agree to the Terms and Privacy Policy.</label>':''}
  ${button(signup?"Create account":"Login","primary","type=submit")}
  ${!signup?'<button type="button" id="forgotBtn" class="text-btn">Forgot password?</button>':''}
  </form><p class="muted tiny">Community tournament app. No cash deposits, paid entry or cash withdrawals are enabled.</p></div></section>`;
  $("#loginTab").onclick=()=>authView("login"); $("#signupTab").onclick=()=>authView("signup");
  $("#authForm").onsubmit=async e=>{
    e.preventDefault(); const f=new FormData(e.currentTarget), email=String(f.get("email")).trim().toLowerCase(), pass=String(f.get("password"));
    try {
      if(signup){
        if(pass!==f.get("confirmPassword")) return toast("Passwords do not match.");
        const dob=new Date(String(f.get("dob"))+"T00:00:00");
        const age=(Date.now()-dob.getTime())/(365.2425*86400000);
        if(!Number.isFinite(age)||age<13) return toast("You must meet the minimum age requirement.");
        const username=String(f.get("username")).trim().toLowerCase();
        const unameRef=doc(db,"usernames",username);
        await runTransaction(db, async tx=>{
          const exists=await tx.get(unameRef); if(exists.exists()) throw new Error("Username already taken.");
          const cred=await createUserWithEmailAndPassword(auth,email,pass);
          const profile={uid:cred.user.uid,fullName:f.get("fullName"),username,gameUid:f.get("gameUid"),gameName:f.get("gameName"),mobile:f.get("mobile"),gender:f.get("gender"),dob:f.get("dob"),email,createdAt:serverTimestamp(),rewardPoints:0,totalMatches:0,totalWins:0,totalWinRewards:0};
          tx.set(unameRef,{uid:cred.user.uid});
          tx.set(doc(db,"users",cred.user.uid),profile);
        });
        toast("Account created.");
      } else { await signInWithEmailAndPassword(auth,email,pass); toast("Welcome back."); }
    } catch(err){ toast(err.message || "Could not complete request."); }
  };
  if(!signup) $("#forgotBtn").onclick=async()=>{const email=prompt("Enter your account email"); if(email){try{await sendPasswordResetEmail(auth,email);toast("Password reset email sent.");}catch(e){toast(e.message);}}};
}

async function loadProfile() {
  const snap=await getDoc(doc(db,"users",currentUser.uid));
  userData=snap.exists()?snap.data():null;
  if(!userData) { toast("Profile missing. Contact support."); await signOut(auth); }
}
function shell(page) {
  currentPage=page;
  document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  if(page==="home") homePage();
  if(page==="matches") matchesPage();
  if(page==="my") myPage();
  if(page==="wallet") walletPage();
  if(page==="profile") profilePage();
  if(page==="admin") adminPage();
}
function header(title, sub="") { return `<div class="section-head"><div><h2>${title}</h2><p>${sub}</p></div></div>`; }
function homePage(){
  screen.innerHTML=`<div class="welcome"><div><small>WELCOME BACK</small><h1>${safe(userData?.username||"Player")}</h1><p>Ready for your next match?</p></div><div class="balance-pill">◈ ${money(userData?.rewardPoints)}</div></div>
  <div class="ticker">📢 Follow tournament rules • Play fair • Respect every player</div>
  ${header("IMPORTANT","Updates and alerts")}<div id="announcements" class="stack"><div class="card">Loading announcements…</div></div>
  ${header("FEATURED","Community events")}<div class="banner"><b>CLASH 2.0</b><span>YOUR NEXT MATCH STARTS HERE</span></div>
  ${header("TOURNAMENTS","Find a community match")}<div id="featuredMatches" class="stack"><div class="card">Loading tournaments…</div></div>`;
  listenAnnouncements(); loadTournaments("featuredMatches",true);
}
function listenAnnouncements(){
  if(unsubscribe) unsubscribe();
  unsubscribe=onSnapshot(query(collection(db,"announcements"),orderBy("createdAt","desc")),snap=>{
    const el=$("#announcements"); if(!el)return;
    el.innerHTML=snap.empty?'<div class="card muted">No new announcements.</div>':snap.docs.slice(0,5).map(d=>`<div class="card"><b>${safe(d.data().title)}</b><p>${safe(d.data().message)}</p></div>`).join("");
  },()=>{const el=$("#announcements");if(el)el.innerHTML='<div class="card muted">Announcements unavailable.</div>';});
}
async function loadTournaments(target="tournamentList",limited=false){
  const el=$("#"+target); if(!el)return;
  try{
    const snap=await getDocs(query(collection(db,"tournaments"),orderBy("startAt","asc")));
    let docs=snap.docs.map(d=>({id:d.id,...d.data()})).filter(t=>["upcoming","registration_open","ongoing"].includes(t.status));
    if(limited)docs=docs.slice(0,3);
    el.innerHTML=docs.length?docs.map(t=>tournamentCard(t)).join(""):'<div class="card muted">No tournaments available yet.</div>';
    el.querySelectorAll("[data-join]").forEach(b=>b.onclick=()=>joinTournament(b.dataset.join));
  }catch(e){el.innerHTML='<div class="card muted">Could not load tournaments. Check Firebase setup.</div>';}
}
function tournamentCard(t){
  const date=t.startAt?.toDate?t.startAt.toDate().toLocaleString(): "Schedule to be announced";
  return `<article class="match-card"><div class="match-top"><span class="tag">${safe((t.mode||"solo").toUpperCase())}</span><span class="status">${safe((t.status||"upcoming").replaceAll("_"," "))}</span></div><h3>${safe(t.title)}</h3><p>${safe(t.map||"Map TBA")} • ${safe(date)}</p><div class="stats"><span>Slots <b>${Number(t.joinedCount||0)}/${Number(t.slots||0)}</b></span><span>Entry <b>FREE</b></span><span>Reward <b>${safe(t.rewardLabel||"Points")}</b></span></div>${t.status==="registration_open"?button("Join Free Match","primary","data-join='"+safe(t.id)+"'"):'<div class="muted tiny">Registration is not open.</div>'}</article>`;
}
async function joinTournament(id){
  try{
    await runTransaction(db,async tx=>{
      const tr=doc(db,"tournaments",id), part=doc(db,"tournaments",id,"participants",currentUser.uid);
      const [ts,ps]=await Promise.all([tx.get(tr),tx.get(part)]);
      if(!ts.exists())throw new Error("Tournament not found.");
      const t=ts.data(); if(t.status!=="registration_open")throw new Error("Registration is closed.");
      if(ps.exists())throw new Error("You already joined this match.");
      if(Number(t.joinedCount||0)>=Number(t.slots||0))throw new Error("All slots are full.");
      tx.set(part,{uid:currentUser.uid,username:userData.username,joinedAt:serverTimestamp(),status:"joined"});
      tx.update(tr,{joinedCount:Number(t.joinedCount||0)+1});
    });
    toast("Joined tournament successfully."); shell("my");
  }catch(e){toast(e.message);}
}
function matchesPage(){screen.innerHTML=header("TOURNAMENTS","Join free community matches")+`<div id="tournamentList" class="stack"><div class="card">Loading…</div></div>`;loadTournaments();}
async function myPage(){
  screen.innerHTML=header("MY CONTESTS","Your tournament journey")+`<div id="myList" class="stack"><div class="card">Loading…</div></div>`;
  const el=$("#myList");
  try{
    const all=await getDocs(collection(db,"tournaments")); const items=[];
    for(const d of all.docs){const p=await getDoc(doc(db,"tournaments",d.id,"participants",currentUser.uid));if(p.exists())items.push({id:d.id,...d.data()});}
    el.innerHTML=items.length?items.map(t=>tournamentCard(t).replace('data-join=','data-join=')).join(""):'<div class="card muted">You have not joined any matches yet.</div>';
    // Room credentials are intentionally not shown in this starter. Admin-controlled, server-verified release should be added before production.
  }catch(e){el.innerHTML='<div class="card muted">Could not load your contests.</div>';}
}
async function walletPage(){
  const fresh=await getDoc(doc(db,"users",currentUser.uid)); if(fresh.exists())userData=fresh.data();
  screen.innerHTML=header("MY WALLET","Community reward points")+`<div class="wallet-hero"><small>AVAILABLE REWARD POINTS</small><h1>${money(userData.rewardPoints)}</h1><p>Points have no cash value in this version.</p></div><div class="grid2"><div class="card"><small>TOTAL MATCHES</small><h2>${userData.totalMatches||0}</h2></div><div class="card"><small>TOTAL WINS</small><h2>${userData.totalWins||0}</h2></div><div class="card"><small>WIN REWARDS</small><h2>${money(userData.totalWinRewards)}</h2></div><div class="card"><small>REWARD CASH</small><h2>Disabled</h2></div></div><div class="card notice">Cash deposits, cash withdrawals and paid-entry tournaments are disabled. Only non-transferable demo reward points are supported.</div>`;
}
function profilePage(){
  screen.innerHTML=header("PLAYER PROFILE","Your account information")+`<div class="profile-card"><div class="avatar">${safe((userData.fullName||"P").slice(0,1).toUpperCase())}</div><h2>${safe(userData.fullName)}</h2><p>@${safe(userData.username)}</p></div><div class="card details">${[["Game UID",userData.gameUid],["Game Name",userData.gameName],["Email",userData.email],["Mobile",userData.mobile],["Gender",userData.gender||"Not set"],["Date of birth",userData.dob]].map(([a,b])=>`<div><small>${a}</small><b>${safe(b||"—")}</b></div>`).join("")}</div><div class="card"><p class="muted tiny">Need help? Contact the tournament administrator through the official support channel.</p></div>`;
}
async function adminPage(){
  screen.innerHTML=header("ADMIN PANEL","Tournament controls")+`<div class="card notice">Admin access is granted only by a trusted project owner through Firebase custom claims. Never make yourself admin from this screen.</div><div class="card"><h3>Create free tournament</h3><form id="createTournament"><label>Tournament name<input name="title" required></label><label>Mode<select name="mode"><option>solo</option><option>duo</option><option>squad</option></select></label><label>Map<input name="map" required></label><label>Start date & time<input name="startAt" type="datetime-local" required></label><label>Total slots<input name="slots" type="number" min="2" max="100" required></label><label>Reward label<input name="rewardLabel" value="Reward points"></label><button class="primary">Create tournament</button></form></div><div class="card"><h3>Publish announcement</h3><form id="announcementForm"><label>Title<input name="title" required></label><label>Message<textarea name="message" required></textarea></label><button class="primary">Publish</button></form></div>`;
  $("#createTournament").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await addDoc(collection(db,"tournaments"),{title:f.get("title"),mode:f.get("mode"),map:f.get("map"),startAt:new Date(f.get("startAt")),slots:Number(f.get("slots")),joinedCount:0,rewardLabel:f.get("rewardLabel"),status:"registration_open",createdAt:serverTimestamp(),createdBy:currentUser.uid});toast("Tournament created.");e.currentTarget.reset();}catch(err){toast(err.message);}};
  $("#announcementForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await addDoc(collection(db,"announcements"),{title:f.get("title"),message:f.get("message"),createdAt:serverTimestamp(),createdBy:currentUser.uid});toast("Announcement published.");e.currentTarget.reset();}catch(err){toast(err.message);}};
}
async function updateAdminVisibility(){
  const token=await currentUser.getIdTokenResult(true);
  if(token.claims.admin){const nav=document.createElement("button");nav.dataset.page="admin";nav.innerHTML='⚙<small>Admin</small>';$("#bottomNav").append(nav);nav.onclick=()=>shell("admin");}
}
$("#bottomNav").addEventListener("click",e=>{const b=e.target.closest("button[data-page]");if(b)shell(b.dataset.page);});
$("#logoutBtn").onclick=()=>signOut(auth);
onAuthStateChanged(auth,async user=>{
  currentUser=user;
  if(!user){if(unsubscribe)unsubscribe();$("#bottomNav").classList.add("hidden");$("#logoutBtn").classList.add("hidden");authView();return;}
  $("#bottomNav").classList.remove("hidden");$("#logoutBtn").classList.remove("hidden");
  try{await loadProfile();if(userData){await updateAdminVisibility();shell("home");}}catch(e){toast(e.message);}
});
