/**
 * Haptic feedback manager for tactile mobile responses.
 */

class HapticManager {
  public vibrate(
    type: 'select' | 'escape' | 'combo' | 'win' | 'blocked',
    enabled: boolean
  ) {
    if (!enabled || typeof window === 'undefined' || !('vibrate' in navigator)) {
      return;
    }

    try {
      switch (type) {
        case 'select':
          navigator.vibrate(10);
          break;
        case 'escape':
          navigator.vibrate(20);
          break;
        case 'blocked':
          navigator.vibrate([15, 30, 15]);
          break;
        case 'combo':
          navigator.vibrate([20, 30, 35]);
          break;
        case 'win':
          navigator.vibrate([40, 40, 60, 40, 80]);
          break;
      }
    } catch (e) {
      // Haptics not allowed or unsupported
    }
  }
}

export const hapticManager = new HapticManager();
