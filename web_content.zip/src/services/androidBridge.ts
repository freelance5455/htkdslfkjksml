/**
 * Android Bridge & Future Voice Assistant Architecture Service
 * 
 * PHASE 2 & 3 ARCHITECTURAL SPECIFICATION:
 * 1. User-Initiated Voice Commands While Using Other Apps:
 *    - In native Android, floating companion trigger requires `SYSTEM_ALERT_WINDOW` permission,
 *      which can only be enabled by the user via `Settings.ACTION_MANAGE_OVERLAY_PERMISSION`.
 *    - Alternatively uses official Android `android.intent.action.ASSIST` or `VoiceInteractionSession`.
 * 
 * 2. Background Voice Interaction Policy:
 *    - Background listening MUST run inside an official Android `ForegroundService` with
 *      `ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE`.
 *    - Requires a non-dismissible persistent notification showing active listening state and
 *      an explicit user "Stop" action button.
 *    - No hidden or stealth recording; strictly complies with Google Play Developer Policy.
 * 
 * 3. Privacy Indicator Compliance:
 *    - Android 12+ (API 31+) hardware privacy indicator (green camera/mic dot in status bar)
 *      will automatically light up whenever audio record is active.
 *    - The in-app UI mirrors this with an active cyber audio wave and privacy status pill.
 * 
 * 4. Official App Launching via Android Intents:
 *    - Installed applications are resolved via `PackageManager.getLaunchIntentForPackage(pkgName)`.
 *    - Web destinations and deep links are launched via `Intent(Intent.ACTION_VIEW, Uri.parse(url))`.
 *    - Zero private API calls; only official Android Intent dispatching.
 * 
 * 5. Audio Sharing Consent:
 *    - Audio capture is user-controlled (push-to-talk or user-toggled continuous session).
 *    - Screen or system audio sharing requires explicit user confirmation via `MediaProjectionManager`.
 */

import { AndroidBridgeState, AndroidVoiceAssistantArchitecture } from '../types';

export interface NativeAndroidInterface {
  postMessage?(message: string): void;
  isAccessibilityEnabled?(): boolean;
  openAccessibilitySettings?(): void;
  openAppSettings?(): void; // Triggers official Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
  getAppVersion?(): string;
  // Future Android Assistant hooks
  isVoiceAssistantConfigured?(): boolean;
  triggerAppIntent?(packageName: string, actionUrl?: string): boolean;
  requestOverlayPermission?(): void;
}

declare global {
  interface Window {
    Android002Bridge?: NativeAndroidInterface;
  }
}

class AndroidBridgeManager {
  private static instance: AndroidBridgeManager;

  private constructor() {}

  public static getInstance(): AndroidBridgeManager {
    if (!AndroidBridgeManager.instance) {
      AndroidBridgeManager.instance = new AndroidBridgeManager();
    }
    return AndroidBridgeManager.instance;
  }

  /**
   * Detects if the web app is running inside the future Android native wrapper
   */
  public isNativeAndroid(): boolean {
    if (typeof window === 'undefined') return false;
    return typeof window.Android002Bridge !== 'undefined';
  }

  /**
   * Retrieves current bridge state
   */
  public getBridgeState(): AndroidBridgeState {
    const isAvailable = this.isNativeAndroid();
    let accessibilityConsentGranted = false;

    if (isAvailable && window.Android002Bridge?.isAccessibilityEnabled) {
      try {
        accessibilityConsentGranted = window.Android002Bridge.isAccessibilityEnabled();
      } catch (e) {
        console.warn('Failed to query native accessibility status:', e);
      }
    }

    return {
      isAvailable,
      isAndroidWebView: isAvailable,
      accessibilityConsentGranted,
      version: isAvailable && window.Android002Bridge?.getAppVersion 
        ? window.Android002Bridge.getAppVersion() 
        : 'Future Android Shell v1.2 (Architecture Prepared)',
    };
  }

  /**
   * Returns specifications for the planned native Android voice companion architecture
   */
  public getAssistantArchitectureSpecs(): AndroidVoiceAssistantArchitecture {
    const isNative = this.isNativeAndroid();
    return {
      voiceInteractionServiceReady: true,
      userInitiatedTriggerSupported: true,
      backgroundAudioCapturePermitted: false, // Strictly false in web preview; requires explicit native foreground service
      privacyIndicatorCompliant: true,
      installedAppIntentLauncherReady: true,
      explicitUserConsentActive: isNative && Boolean(window.Android002Bridge?.isAccessibilityEnabled?.()),
    };
  }

  /**
   * Directs user to the official Android Accessibility settings dialog.
   * STRICT COMPLIANCE:
   * Only triggers through official system intents initiated by an explicit user button press.
   */
  public requestAccessibilityConsentFlow(): { initiated: boolean; message: string } {
    if (!this.isNativeAndroid()) {
      return {
        initiated: false,
        message: 'Web Preview Mode: When deployed as an Android APK, this action triggers the official Android Settings.ACTION_ACCESSIBILITY_SETTINGS intent with explicit user consent.',
      };
    }

    try {
      if (window.Android002Bridge?.openAccessibilitySettings) {
        window.Android002Bridge.openAccessibilitySettings();
        return {
          initiated: true,
          message: 'Redirecting to Android Accessibility Settings for user approval...',
        };
      }
    } catch (e) {
      console.error('Error invoking native accessibility intent:', e);
    }

    return {
      initiated: false,
      message: 'Native bridge interface is available but intent invocation failed.',
    };
  }

  /**
   * Directs user to the official Android App Details Settings (ACTION_APPLICATION_DETAILS_SETTINGS).
   * In a native Android app, this lets the user manually grant or revoke permissions.
   * In standard web browsers, this accurately reports that direct native intent invocation
   * is blocked by browser security sandboxes.
   */
  public openAppPermissionSettings(): {
    supported: boolean;
    openedNative: boolean;
    message: string;
  } {
    if (!this.isNativeAndroid()) {
      return {
        supported: false,
        openedNative: false,
        message: 'Browser sandbox prevents web apps from directly triggering device settings intents.',
      };
    }

    try {
      if (window.Android002Bridge?.openAppSettings) {
        window.Android002Bridge.openAppSettings();
        return {
          supported: true,
          openedNative: true,
          message: 'Android system App Info settings opened via Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).',
        };
      }
    } catch (e) {
      console.error('Error invoking native openAppSettings:', e);
    }

    return {
      supported: false,
      openedNative: false,
      message: 'Native Android bridge is present, but openAppSettings method failed.',
    };
  }
}

export const androidBridge = AndroidBridgeManager.getInstance();
