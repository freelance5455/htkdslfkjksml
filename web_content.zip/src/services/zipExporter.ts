import JSZip from 'jszip';
import confetti from 'canvas-confetti';
import { ANDROID_PROJECT_FILES, ProjectFileEntry } from '../data/androidProjectFiles';
import { CustomAppIconData } from '../types/desktop';

/**
 * Converts a Base64 data URL to an ArrayBuffer
 */
function dataUrlToArrayBuffer(dataUrl: string): ArrayBuffer {
  const parts = dataUrl.split(',');
  const byteString = atob(parts[1] || parts[0]);
  const ab = new ArrayBuffer(byteString.length);
  const ia = new Uint8Array(ab);
  for (let i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i);
  }
  return ab;
}

export interface ExportResult {
  blob: Blob;
  fileName: string;
  fileSizeBytes: number;
  fileCount: number;
}

/**
 * Builds the complete, valid Android Gradle Project ZIP archive
 */
export async function generateAndroidProjectZip(
  customIcon?: CustomAppIconData | null,
  onProgress?: (percent: number, statusText: string) => void
): Promise<ExportResult> {
  const zip = new JSZip();
  const rootFolder = zip.folder('BirdPC') || zip;

  onProgress?.(10, 'Initializing Android project directory structure...');

  // Add all text files
  let count = 0;
  const total = ANDROID_PROJECT_FILES.length + 10;

  for (const file of ANDROID_PROJECT_FILES) {
    rootFolder.file(file.path, file.content);
    count++;
    const progress = Math.min(80, Math.round((count / total) * 80));
    onProgress?.(progress, `Packing ${file.name}...`);
  }

  // Include launcher icon drawables if custom icon is present
  if (customIcon && customIcon.densityDrawables) {
    onProgress?.(85, 'Injecting custom launcher mipmap drawables...');
    try {
      const densities = [
        { folder: 'mipmap-mdpi', data: customIcon.densityDrawables.mdpi },
        { folder: 'mipmap-hdpi', data: customIcon.densityDrawables.hdpi },
        { folder: 'mipmap-xhdpi', data: customIcon.densityDrawables.xhdpi },
        { folder: 'mipmap-xxhdpi', data: customIcon.densityDrawables.xxhdpi },
        { folder: 'mipmap-xxxhdpi', data: customIcon.densityDrawables.xxxhdpi },
      ];

      for (const d of densities) {
        if (d.data) {
          const buffer = dataUrlToArrayBuffer(d.data);
          rootFolder.file(`app/src/main/res/${d.folder}/ic_launcher.png`, buffer);
          rootFolder.file(`app/src/main/res/${d.folder}/ic_launcher_round.png`, buffer);
        }
      }
    } catch (e) {
      console.warn('Error packing custom icon drawables:', e);
    }
  }

  onProgress?.(90, 'Compressing ZIP archive (DEFLATE level 9)...');

  const content = await zip.generateAsync(
    {
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 9 }
    },
    (metadata) => {
      onProgress?.(90 + Math.round(metadata.percent * 0.1), `Compressing: ${Math.round(metadata.percent)}%`);
    }
  );

  const fileName = 'BirdPC-Android-Project.zip';
  const result: ExportResult = {
    blob: content,
    fileName,
    fileSizeBytes: content.size,
    fileCount: Object.keys(zip.files).length
  };

  onProgress?.(100, 'Complete!');
  return result;
}

/**
 * Downloads the generated project zip to the user's browser / Android device storage
 */
export async function downloadAndroidProjectZip(
  customIcon?: CustomAppIconData | null,
  onProgress?: (percent: number, statusText: string) => void
): Promise<ExportResult> {
  const result = await generateAndroidProjectZip(customIcon, onProgress);

  // Trigger browser download
  const url = URL.createObjectURL(result.blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = result.fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  // Trigger celebration
  try {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.7 }
    });
  } catch {
    // Ignore in unsupported environments
  }

  return result;
}
