import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from '../android_code/androidProjectData';

export async function exportAndroidProjectZip(): Promise<void> {
  const zip = new JSZip();
  const rootFolder = zip.folder('HindiVideoTranslator');

  if (!rootFolder) {
    throw new Error('Could not create root zip folder');
  }

  // Add each file to its designated path inside the zip
  for (const file of ANDROID_PROJECT_FILES) {
    rootFolder.file(file.path, file.content);
  }

  // Also include a helpful .gitignore for Android Studio
  const gitignoreContent = `*.iml
.gradle
/local.properties
/.idea/caches
/.idea/libraries
/.idea/modules.xml
/.idea/workspace.xml
/.idea/navEditor.xml
/.idea/assetWizardSettings.xml
.DS_Store
/build
/captures
.externalNativeBuild
.cxx
local.properties
`;
  rootFolder.file('.gitignore', gitignoreContent);

  // Generate ZIP blob and trigger download
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'HindiVideoTranslator_AndroidStudio.zip';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
