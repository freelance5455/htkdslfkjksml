/**
 * Jarvis AI - APK va Backend Manba Kodlarini ZIP Qilib Yuklash Servisi
 * Muallif / Dasturchi: Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)
 */

import JSZip from 'jszip';
import {
  SERVER_PY_CODE,
  REQUIREMENTS_TXT_CODE,
  PROCFILE_CODE,
  HTML_CODE,
  CSS_CODE,
  SCRIPT_JS_CODE,
  MANIFEST_JSON_CODE,
  ANDROID_MANIFEST_XML_CODE,
  README_MD_CODE,
} from '../data/exportTemplates';

export async function downloadJarvisFullZip(): Promise<boolean> {
  try {
    const zip = new JSZip();

    // 1. Backend fayllari (Render.com uchun)
    const backendFolder = zip.folder('backend_render');
    if (backendFolder) {
      backendFolder.file('server.py', SERVER_PY_CODE);
      backendFolder.file('requirements.txt', REQUIREMENTS_TXT_CODE);
      backendFolder.file('Procfile', PROCFILE_CODE);
    }

    // 2. Frontend fayllari (HTML-to-APK uchun)
    const frontendFolder = zip.folder('frontend_apk');
    if (frontendFolder) {
      frontendFolder.file('index.html', HTML_CODE);
      frontendFolder.file('style.css', CSS_CODE);
      frontendFolder.file('script.js', SCRIPT_JS_CODE);
      frontendFolder.file('manifest.json', MANIFEST_JSON_CODE);
      frontendFolder.file('AndroidManifest.xml', ANDROID_MANIFEST_XML_CODE);
    }

    // 3. Ildiz papkadagi umumiy fayllar
    zip.file('server.py', SERVER_PY_CODE);
    zip.file('requirements.txt', REQUIREMENTS_TXT_CODE);
    zip.file('index.html', HTML_CODE);
    zip.file('style.css', CSS_CODE);
    zip.file('script.js', SCRIPT_JS_CODE);
    zip.file('AndroidManifest.xml', ANDROID_MANIFEST_XML_CODE);
    zip.file('README.md', README_MD_CODE);

    // ZIP generatsiyasi
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'jarvis-ai-muhammadrizo-full-source.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    return true;
  } catch (error) {
    console.error("ZIP yaratishda xatolik:", error);
    return false;
  }
}
