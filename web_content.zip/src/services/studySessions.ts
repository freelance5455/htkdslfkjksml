import { KEYS, readKey, updateKey, withStorageLock } from './storage';

export interface StudySessionRecord {
  id: string;
  subjectId: string;
  elapsedSeconds: number;
  plannedSeconds: number;
  completed: boolean;
  at: number;
}

export function studySessions(): StudySessionRecord[] {
  return readKey<StudySessionRecord[]>(KEYS.studySessions, []);
}

export function recordStudySession(record: StudySessionRecord): Promise<void> {
  if (!record.id || record.elapsedSeconds < 60) return Promise.resolve();
  return withStorageLock('sessions', [KEYS.studySessions], () => {
    updateKey<StudySessionRecord[]>(
      KEYS.studySessions,
      (items) => items.some((item) => item.id === record.id) ? items : [record, ...items].slice(0, 500),
      [],
    );
  });
}
