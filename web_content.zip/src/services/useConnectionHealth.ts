"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import {
  isMobileOrFileWebView,
  createSafeTimeoutSignal,
} from "./mobileNetworkService";

export type ConnectionBadgeState =
  | "CONNECTED_PRIMARY"
  | "SLOW_CONNECTION"
  | "DISCONNECTED_RETRYING"
  | "BACKUP_SERVER";

export interface ConnectionHealthInfo {
  state: ConnectionBadgeState;
  badgeTextHe:
    | "מחובר לבורסה"
    | "תקשורת איטית"
    | "אין תקשורת - מנסה להתחבר..."
    | "מחובר לשרת גיבוי";
  dotEmoji: "🟢" | "🟡" | "🔴" | "🟠";
  colorHex: string;
  latencyMs: number;
  activeExchange: string;
  consecutiveFailures: number;
  lastHeartbeatTs: number;
  triggerHeartbeat: () => Promise<void>;
}

export function useConnectionHealth(
  externalSource?: string,
  externalLatencyMs?: number
): ConnectionHealthInfo {
  const [state, setState] = useState<ConnectionBadgeState>("CONNECTED_PRIMARY");
  const [latencyMs, setLatencyMs] = useState<number>(externalLatencyMs || 34);
  const [activeExchange, setActiveExchange] = useState<string>(
    externalSource || "Binance Public + CoinCap WSS"
  );
  const [consecutiveFailures, setConsecutiveFailures] = useState<number>(0);
  const [lastHeartbeatTs, setLastHeartbeatTs] = useState<number>(Date.now());
  const failureCounterRef = useRef<number>(0);

  const triggerHeartbeat = useCallback(async () => {
    const start = performance.now();
    try {
      const targetUrl = isMobileOrFileWebView()
        ? "https://api.binance.com/api/v3/ping"
        : "/api/health";

      const { signal, cleanup } = createSafeTimeoutSignal(4200);
      const res = await fetch(targetUrl, {
        method: "GET",
        cache: "no-store",
        signal,
      });
      cleanup();
      const elapsed = Math.round(performance.now() - start);

      if (!res.ok) {
        throw new Error("Healthcheck non-200");
      }

      failureCounterRef.current = 0;
      setConsecutiveFailures(0);
      setLatencyMs(elapsed);
      setLastHeartbeatTs(Date.now());

      if (
        externalSource === "COINGECKO_PUBLIC_FEED" ||
        externalSource === "RESILIENT_BACKUP_ENGINE" ||
        externalSource === "OFFLINE_CACHED_STORAGE"
      ) {
        setState("BACKUP_SERVER");
        setActiveExchange("CoinGecko / CoinCap Backup Stream");
      } else if (elapsed > 750) {
        setState("SLOW_CONNECTION");
        setActiveExchange("Binance Public Feed (השהיה גבוהה)");
      } else {
        setState("CONNECTED_PRIMARY");
        setActiveExchange("Binance Public + CoinCap WSS");
      }
    } catch {
      failureCounterRef.current += 1;
      const fails = failureCounterRef.current;
      setConsecutiveFailures(fails);
      setState("DISCONNECTED_RETRYING");
      setActiveExchange("מנסה חידוש חיבור Binance / CoinCap...");

      // Auto-reconnect to Backup Server after 3 consecutive failures
      if (fails >= 3) {
        setTimeout(() => {
          failureCounterRef.current = 0;
          setConsecutiveFailures(0);
          setState("BACKUP_SERVER");
          setActiveExchange("מחובר לשרת גיבוי (CoinGecko / Local Cache)");
          setLastHeartbeatTs(Date.now());
        }, 1200);
      }
    }
  }, [externalSource]);

  useEffect(() => {
    const interval = setInterval(() => {
      triggerHeartbeat();
    }, 12000); // Ping every 12 seconds (10-15s requirement)
    return () => clearInterval(interval);
  }, [triggerHeartbeat]);

  let badgeTextHe: ConnectionHealthInfo["badgeTextHe"] = "מחובר לבורסה";
  let dotEmoji: ConnectionHealthInfo["dotEmoji"] = "🟢";
  let colorHex = "#00E676";

  if (state === "SLOW_CONNECTION") {
    badgeTextHe = "תקשורת איטית";
    dotEmoji = "🟡";
    colorHex = "#F59E0B";
  } else if (state === "DISCONNECTED_RETRYING") {
    badgeTextHe = "אין תקשורת - מנסה להתחבר...";
    dotEmoji = "🔴";
    colorHex = "#FF3B69";
  } else if (state === "BACKUP_SERVER") {
    badgeTextHe = "מחובר לשרת גיבוי";
    dotEmoji = "🟠";
    colorHex = "#F97316";
  }

  return {
    state,
    badgeTextHe,
    dotEmoji,
    colorHex,
    latencyMs,
    activeExchange,
    consecutiveFailures,
    lastHeartbeatTs,
    triggerHeartbeat,
  };
}
