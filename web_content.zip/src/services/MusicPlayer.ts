/**
 * Web Audio Generative Synthesizer for Lo-Fi & Ambient vibes on voice command.
 */
export class MusicPlayer {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private timerId: number | null = null;
  private currentVibe: 'lofi' | 'ambient' | 'party' | 'alert' = 'lofi';

  private initCtx() {
    if (!this.ctx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtxClass();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playVibe(vibe: 'lofi' | 'ambient' | 'party' | 'alert' = 'lofi'): boolean {
    this.stop();
    this.initCtx();
    if (!this.ctx) return false;

    this.isPlaying = true;
    this.currentVibe = vibe;

    if (vibe === 'alert') {
      this.playAlertSound();
      return true;
    }

    const chords =
      vibe === 'party'
        ? [
            [261.63, 329.63, 392.0], // C
            [329.63, 415.3, 493.88], // E
            [220.0, 261.63, 329.63], // Am
            [349.23, 440.0, 523.25], // F
          ]
        : vibe === 'ambient'
        ? [
            [174.61, 261.63, 329.63], // Fmaj7
            [220.0, 261.63, 349.23], // Dm7
            [196.0, 246.94, 293.66], // G
            [261.63, 329.63, 392.0], // C
          ]
        : [
            // Lo-Fi mellow jazz chords
            [220.0, 261.63, 329.63, 392.0], // Am7
            [174.61, 220.0, 261.63, 329.63], // Fmaj7
            [196.0, 246.94, 293.66, 349.23], // G7
            [164.81, 207.65, 246.94, 293.66], // E7
          ];

    let chordIdx = 0;
    const intervalTime = vibe === 'party' ? 500 : 1800;

    const playChordStep = () => {
      if (!this.isPlaying || !this.ctx) return;
      const currentChord = chords[chordIdx % chords.length];
      chordIdx++;

      currentChord.forEach((freq, i) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const filter = this.ctx!.createBiquadFilter();

        osc.type = vibe === 'party' ? 'sawtooth' : 'sine';
        osc.frequency.setValueAtTime(freq, this.ctx!.currentTime);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(vibe === 'party' ? 1800 : 850, this.ctx!.currentTime);

        const now = this.ctx!.currentTime;
        const noteDuration = intervalTime / 1000;
        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.04 / (i + 1), now + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + noteDuration);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(now);
        osc.stop(now + noteDuration);
      });

      this.timerId = window.setTimeout(playChordStep, intervalTime);
    };

    playChordStep();
    return true;
  }

  playAlertSound() {
    this.initCtx();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.12);
      gain.gain.setValueAtTime(0.08, now + idx * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.25);
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(now + idx * 0.12);
      osc.stop(now + idx * 0.12 + 0.25);
    });
  }

  stop() {
    this.isPlaying = false;
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
  }

  getStatus() {
    return {
      isPlaying: this.isPlaying,
      vibe: this.currentVibe,
    };
  }
}

export const musicPlayer = new MusicPlayer();
