/**
 * المساعد الدراسي (Gemini API).
 * المفتاح يُقرأ من متغير البيئة VITE_GEMINI_API_KEY ولا يُكتب في الكود أبداً.
 * عند غيابه يعمل المساعد بوضع محلي محدود (توجيه من فصول الدرس) مع تنبيه واضح.
 */
import type { Lesson, Subject, Unit } from '../types';

const RAW_KEY = (import.meta.env.VITE_GEMINI_API_KEY as string | undefined) ?? '';
const MODEL = (import.meta.env.VITE_GEMINI_MODEL as string | undefined) ?? 'gemini-2.5-flash';

export const isAssistantConfigured = RAW_KEY.trim().length > 0;

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

const SYSTEM_INSTRUCTION = `أنت «مساعد منارة»، مدرّس مساعد لطلاب الشهادة الثانوية السورية – الفرع العلمي.
قواعد إلزامية:
1) أجب بالعربية الفصحى المبسّطة، وبأسلوب طالب في البكالوريا يفهمه بسهولة، دون حشو.
2) التزم بمنهاج البكالوريا العلمية السوري في المصطلحات والرموز وطريقة الحل المعتمدة (لا تستخدم مناهج أجنبية أو رموزاً غير مألوفة للطالب السوري).
3) في المسائل: اذكر القانون، ثم التعويض، ثم النتيجة مع الوحدة، ثم تحقّقاً سريعاً من المعقولية.
4) اكتب كل المعادلات بصيغة LaTeX بين $...$ للسطر الواحد و $$...$$ للسطر المستقل.
5) إن لم تكن متأكداً أو كان السؤال خارج المنهاج، قل ذلك صراحةً بدل التخمين، واقترح ما يمكن للطالب مراجعته.
6) لا تحلّ الامتحان بدل الطالب: اشرح، أرشد، واسأل سؤالاً مساعداً واحداً في النهاية عندما يكون مناسباً.
7) لا تذكر أنك نموذج ذكاء اصطناعي ولا تعتذر بإسهاب؛ كن مدرّساً واثقاً ومهذباً.
اجعل الإجابة في فقرات قصيرة أو خطوات مرقّمة، وبحد أقصى ٢٢٠ كلمة إلا إذا طلب الطالب تفصيلاً أكبر.`;

function lessonContext(lesson: Lesson, subject: Subject, unit: Unit): string {
  const chapters = lesson.chapters.map((c) => `- ${formatStamp(c.time)} — ${c.title}`).join('\n');
  const objectives = lesson.objectives.map((o) => `- ${o}`).join('\n');
  return `المادة: ${subject.name} (بكالوريا علمي – المنهاج السوري)
الوحدة: ${unit.title}
الدرس الحالي: ${lesson.title}
وصف الدرس: ${lesson.description}
أهداف الدرس:
${objectives}
فصول الدرس الزمنية:
${chapters}`;
}

function formatStamp(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${`${s}`.padStart(2, '0')}`;
}

export class AssistantError extends Error {}

/** نداء Gemini مع سياق الدرس */
export async function askAssistant(params: {
  lesson: Lesson;
  subject: Subject;
  unit: Unit;
  history: ChatMessage[];
  question: string;
}): Promise<string> {
  const { lesson, subject, unit, history, question } = params;

  if (!isAssistantConfigured) {
    return localFallback(lesson, question);
  }

  const contents = [
    ...history.map((m) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }],
    })),
    {
      role: 'user',
      parts: [{ text: `${lessonContext(lesson, subject, unit)}\n\nسؤال الطالب: ${question}` }],
    },
  ];

  const body = {
    system_instruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
    contents,
    generationConfig: {
      temperature: 0.4,
      topP: 0.9,
      maxOutputTokens: 1400,
    },
    safetySettings: [],
  };

  let response: Response;
  try {
    response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(RAW_KEY)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      },
    );
  } catch {
    throw new AssistantError('تعذّر الوصول إلى خدمة المساعد. تحقّق من اتصالك بالإنترنت ثم أعد المحاولة.');
  }

  if (!response.ok) {
    const text = await safeText(response);
    if (response.status === 401 || response.status === 403) {
      throw new AssistantError('مفتاح Gemini غير صالح أو غير مفعّل. راجع إعدادات المفتاح في متغيرات البيئة.');
    }
    if (response.status === 429) {
      throw new AssistantError('المساعد مشغول الآن (تجاوزنا حدّ الاستخدام). انتظر دقيقة ثم أعد السؤال.');
    }
    if (response.status === 400) {
      throw new AssistantError(`طلب غير صالح للمساعد: ${text.slice(0, 160)}`);
    }
    throw new AssistantError(`خطأ من خدمة المساعد (${response.status}). أعد المحاولة بعد قليل.`);
  }

  const data = (await response.json()) as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
  };
  const answer = data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? '').join('').trim();
  if (!answer) {
    throw new AssistantError('لم يصل ردّ من المساعد. أعد صياغة السؤال أو حاول مرة أخرى.');
  }
  return answer;
}

async function safeText(response: Response): Promise<string> {
  try {
    return await response.text();
  } catch {
    return '';
  }
}

/**
 * وضع بديل بلا مفتاح: توجيه مبني على فصول الدرس وأهدافه.
 * لا يدّعي الإجابة على أسئلة المحتوى، بل يعطي خريطة عمل صادقة.
 */
function localFallback(lesson: Lesson, question: string): string {
  const chapters = lesson.chapters
    .map((c) => `- **${formatStamp(c.time)}** — ${c.title}`)
    .join('\n');
  const activationHint = import.meta.env.MODE === 'standalone'
    ? 'نسخة HTML هذه لا تحتوي مفتاح Gemini، لذلك يعمل المساعد بوضع التوجيه المحلي فقط. للإجابات الذكية الكاملة استخدم نسخة ويب مهيأة بمفتاح خدمة محفوظ بأمان.'
    : 'لتفعيل الإجابات الذكية الكاملة: أضف المتغير `VITE_GEMINI_API_KEY` في إعدادات البيئة ثم أعد تشغيل التطبيق.';
  return `وضع المساعد المحلي (بدون مفتاح Gemini) — لكن يمكنني توجيهك داخل هذا الدرس:

**الدرس:** ${lesson.title}

**خريطة الدرس:**
${chapters}

**خطة عمل مقترحة لسؤالك «${question.slice(0, 80)}»:**
1. شاهد الفصل المتعلق بسؤالك أولاً (ابدأ من أقرب عنوان في القائمة أعلاه).
2. اكتب ما فهمته في سطر واحد، ثم قارنه بأهداف الدرس: ${lesson.objectives.join(' / ')}.
3. إن بقي غامضاً، أضف ملاحظة زمنية عند اللحظة نفسها من المشغّل وارجع إليها في المراجعة.

${activationHint}`;
}
