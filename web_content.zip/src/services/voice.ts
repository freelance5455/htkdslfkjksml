/**
 * HELENA - Voice Recognition & Natural pt-BR Speech Synthesis
 */

export interface VoiceCallbacks {
  onWakeWordDetected?: (wakeWord: string) => void;
  onListeningStart?: () => void;
  onListeningResult?: (transcript: string) => void;
  onSpeechStart?: () => void;
  onSpeechEnd?: () => void;
  onError?: (error: string) => void;
}

class HelenaVoiceService {
  private recognition: any = null;
  private isListeningActive = false;
  private wakeWord = 'helena';
  private speechRate = 1.0;
  private isMuted = false;
  private callbacks: VoiceCallbacks = {};
  private bestVoice: SpeechSynthesisVoice | null = null;
  private isCurrentlySpeaking = false;

  constructor() {
    this.initVoices();
  }

  private initVoices() {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    const pickVoice = () => {
      const voices = window.speechSynthesis.getVoices();
      // prioritize natural pt-BR voices
      const ptBrVoices = voices.filter(v => v.lang.startsWith('pt') || v.lang.includes('BR'));
      const natural = ptBrVoices.find(v => 
        v.name.toLowerCase().includes('google') || 
        v.name.toLowerCase().includes('natural') || 
        v.name.toLowerCase().includes('neural') ||
        v.name.toLowerCase().includes('maria') ||
        v.name.toLowerCase().includes('luciana')
      );
      this.bestVoice = natural || ptBrVoices[0] || voices[0] || null;
    };

    pickVoice();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = pickVoice;
    }
  }

  public updateConfig(wakeWord: string, rate: number, muted: boolean) {
    this.wakeWord = wakeWord.trim().toLowerCase();
    this.speechRate = Math.max(0.5, Math.min(2.0, rate));
    this.isMuted = muted;
  }

  public setCallbacks(callbacks: VoiceCallbacks) {
    this.callbacks = callbacks;
  }

  public speak(text: string, onDone?: () => void): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      onDone?.();
      return;
    }

    if (this.isMuted) {
      onDone?.();
      return;
    }

    // Cancel current speech if any
    window.speechSynthesis.cancel();

    // Clean markdown symbols (e.g. **, *, #, URLs) for natural pronunciation
    const cleanSpeech = text
      .replace(/\*\*(.*?)\*\*/g, '$1')
      .replace(/\*(.*?)\*/g, '$1')
      .replace(/#{1,6}\s+/g, '')
      .replace(/```[\s\S]*?```/g, 'código omitido na leitura')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/https?:\/\/\S+/g, 'link na tela')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    utterance.lang = 'pt-BR';
    utterance.rate = this.speechRate;
    utterance.pitch = 1.05;

    if (this.bestVoice) {
      utterance.voice = this.bestVoice;
    }

    this.isCurrentlySpeaking = true;
    this.callbacks.onSpeechStart?.();

    utterance.onend = () => {
      this.isCurrentlySpeaking = false;
      this.callbacks.onSpeechEnd?.();
      onDone?.();
    };

    utterance.onerror = (e) => {
      console.warn('Speech synthesis error:', e);
      this.isCurrentlySpeaking = false;
      this.callbacks.onSpeechEnd?.();
      onDone?.();
    };

    window.speechSynthesis.speak(utterance);
  }

  public stopSpeaking(): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.isCurrentlySpeaking = false;
      this.callbacks.onSpeechEnd?.();
    }
  }

  public isSpeaking(): boolean {
    return this.isCurrentlySpeaking;
  }

  public startListening(): boolean {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      this.callbacks.onError?.('Reconhecimento de voz não suportado neste navegador.');
      return false;
    }

    if (this.recognition) {
      try {
        this.recognition.abort();
      } catch {}
    }

    try {
      this.recognition = new SpeechRecognition();
      this.recognition.lang = 'pt-BR';
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 1;

      this.recognition.onstart = () => {
        this.isListeningActive = true;
      };

      this.recognition.onresult = (event: any) => {
        // If speaking, interrupt speech immediately
        if (this.isCurrentlySpeaking) {
          this.stopSpeaking();
        }

        let fullTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          fullTranscript += event.results[i][0].transcript;
        }

        const normalized = fullTranscript.toLowerCase().trim();

        // Check if wake word present
        if (normalized.includes(this.wakeWord)) {
          this.callbacks.onWakeWordDetected?.(this.wakeWord);
          this.callbacks.onListeningStart?.();
          
          // Is it a final result?
          const lastResult = event.results[event.results.length - 1];
          if (lastResult.isFinal) {
            // strip wake word for the actual command/query
            const cleanQuery = normalized
              .replace(new RegExp(`\\b${this.wakeWord}\\b`, 'gi'), '')
              .replace(/^[,\s.!?-]+/, '')
              .trim();
            this.callbacks.onListeningResult?.(cleanQuery || normalized);
          }
        }
      };

      this.recognition.onerror = (event: any) => {
        if (event.error === 'not-allowed') {
          this.callbacks.onError?.('Permissão de microfone negada.');
        } else if (event.error !== 'no-speech') {
          console.warn('SpeechRecognition error:', event.error);
        }
      };

      this.recognition.onend = () => {
        // Restart continuous listening if still active
        if (this.isListeningActive) {
          try {
            this.recognition.start();
          } catch {}
        }
      };

      this.recognition.start();
      return true;
    } catch (err: any) {
      console.warn('Failed to start speech recognition:', err);
      this.callbacks.onError?.(err?.message || 'Falha ao iniciar microfone.');
      return false;
    }
  }

  public stopListening(): void {
    this.isListeningActive = false;
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {}
    }
  }

  // Voice guidance for scan angles
  public speakScanAngleGuidance(photoIndex: number, totalNeeded: number): void {
    let guidance = '';
    switch (photoIndex) {
      case 0:
        guidance = 'Posicione o objeto no centro e tire uma foto frontal.';
        break;
      case 1:
        guidance = 'Muito bem. Agora dê um passo para a direita e tire uma foto da lateral.';
        break;
      case 2:
        guidance = 'Perfeito. Agora dê mais um passo e tire uma foto da parte traseira.';
        break;
      case 3:
        guidance = 'Ótimo. Agora tire uma foto do lado esquerdo para fechar a volta.';
        break;
      default:
        if (photoIndex < totalNeeded) {
          guidance = `Foto capturada. Faltam ${totalNeeded - photoIndex} fotos. Mantenha boa iluminação.`;
        } else {
          guidance = 'Mínimo de fotos atingido! Você pode adicionar mais detalhes ou tocar em Gerar.';
        }
    }
    this.speak(guidance);
  }
}

export const helenaVoice = new HelenaVoiceService();
