import type { CurriculumPracticeAttempt, CurriculumQuestion, WrittenAnswerRecord } from '../types';
import { KEYS, readKey, withStorageLock, writeKey } from './storage';

const MAX_PRACTICE_ATTEMPTS = 10_000;
const MAX_WRITTEN_ANSWERS = 5_000;

function createId(prefix: string): string {
  const random = globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return `${prefix}-${random}`;
}

export function getPracticeAttempts(): CurriculumPracticeAttempt[] {
  return readKey<CurriculumPracticeAttempt[]>(KEYS.practiceAttempts, []);
}

export function getWrittenAnswers(): WrittenAnswerRecord[] {
  return readKey<WrittenAnswerRecord[]>(KEYS.writtenAnswers, []);
}

export async function recordObjectiveAttempt(
  question: CurriculumQuestion,
  correct: boolean,
): Promise<CurriculumPracticeAttempt> {
  const record: CurriculumPracticeAttempt = {
    id: createId('practice'),
    questionId: question.id,
    subjectId: question.subjectId,
    unitId: question.unitId,
    topic: question.topic,
    kind: question.kind,
    correct,
    maxPoints: question.maxPoints,
    answeredCount: 1,
    at: Date.now(),
  };

  await withStorageLock('practice', [KEYS.practiceAttempts], () => {
    const previous = readKey<CurriculumPracticeAttempt[]>(KEYS.practiceAttempts, []);
    writeKey(KEYS.practiceAttempts, [...previous, record].slice(-MAX_PRACTICE_ATTEMPTS));
  });
  return record;
}

export async function recordWrittenAnswer(
  question: CurriculumQuestion,
  response: string,
  selfScore?: number,
): Promise<WrittenAnswerRecord> {
  const at = Date.now();
  const sourcePages = question.sourcePages ?? (question.sourcePage === undefined ? undefined : [question.sourcePage]);
  const answer: WrittenAnswerRecord = {
    id: createId('written'),
    questionId: question.id,
    subjectId: question.subjectId,
    unitId: question.unitId,
    topic: question.topic,
    response: response.trim().slice(0, 5_000),
    modelAnswer: question.modelAnswer ?? question.expectedAnswer ?? '',
    selfScore,
    maxPoints: question.maxPoints,
    sourceIds: [...question.sourceIds],
    sourcePage: question.sourcePage ?? sourcePages?.[0],
    sourcePages: sourcePages ? [...sourcePages] : undefined,
    at,
  };
  const attempt: CurriculumPracticeAttempt = {
    id: answer.id,
    questionId: question.id,
    subjectId: question.subjectId,
    unitId: question.unitId,
    topic: question.topic,
    kind: question.kind,
    correct: null,
    selfScore,
    maxPoints: question.maxPoints,
    answeredCount: 1,
    at,
  };

  await withStorageLock('practice', [KEYS.practiceAttempts, KEYS.writtenAnswers], () => {
    const previousAttempts = readKey<CurriculumPracticeAttempt[]>(KEYS.practiceAttempts, []);
    const previousAnswers = readKey<WrittenAnswerRecord[]>(KEYS.writtenAnswers, []);
    writeKey(KEYS.writtenAnswers, [...previousAnswers, answer].slice(-MAX_WRITTEN_ANSWERS));
    writeKey(KEYS.practiceAttempts, [...previousAttempts, attempt].slice(-MAX_PRACTICE_ATTEMPTS));
  });
  return answer;
}

export interface PracticeWeakness {
  subjectId: string;
  unitId: string;
  topic: string;
  missed: number;
  attempted: number;
  accuracy: number;
}

/** يجمع الأخطاء وإجابات الطالب التي قيّمها لنفسه بأقل من الدرجة الكاملة. */
export function getPracticeWeaknesses(): PracticeWeakness[] {
  const totals = new Map<string, PracticeWeakness>();
  for (const attempt of getPracticeAttempts()) {
    const failed = attempt.correct === false || (attempt.selfScore !== undefined && attempt.selfScore < attempt.maxPoints);
    const key = `${attempt.subjectId}:${attempt.unitId}:${attempt.topic}`;
    const current = totals.get(key) ?? {
      subjectId: attempt.subjectId,
      unitId: attempt.unitId,
      topic: attempt.topic,
      missed: 0,
      attempted: 0,
      accuracy: 0,
    };
    current.attempted += 1;
    if (failed) current.missed += 1;
    current.accuracy = Math.round(((current.attempted - current.missed) / current.attempted) * 100);
    totals.set(key, current);
  }
  return [...totals.values()].filter((entry) => entry.missed > 0).sort((a, b) => b.missed - a.missed || a.accuracy - b.accuracy);
}
