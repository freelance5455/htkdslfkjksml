/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ChatMessage, ServerStatusResponse } from '../types/assistant';

export interface AIChatResponse {
  success: boolean;
  text?: string;
  error?: string;
  isOffline?: boolean;
}

export interface ConnectionTestResult {
  ok: boolean;
  latencyMs: number;
  model: string;
  error?: string;
  code?: string;
}

export class AIService {
  /**
   * Fast status check for local server health and key presence
   */
  public static async checkStatus(): Promise<ServerStatusResponse> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);
      const res = await fetch('/api/status', { signal: controller.signal });
      clearTimeout(timeoutId);
      if (!res.ok) {
        return {
          ok: false,
          geminiConfigured: false,
          model: 'gemini-3.8-flash',
          serverTime: new Date().toISOString(),
        };
      }
      return await res.json();
    } catch {
      return {
        ok: false,
        geminiConfigured: false,
        model: 'gemini-3.8-flash',
        serverTime: new Date().toISOString(),
      };
    }
  }

  /**
   * Live round-trip connection test to Gemini API
   */
  public static async testConnection(): Promise<ConnectionTestResult> {
    const startTime = Date.now();
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12000);
      const res = await fetch('/api/test-connection', { signal: controller.signal });
      clearTimeout(timeoutId);

      const data = await res.json();
      return {
        ok: Boolean(data.ok),
        latencyMs: data.latencyMs ?? (Date.now() - startTime),
        model: data.model || 'gemini-3.8-flash',
        error: data.error,
        code: data.code,
      };
    } catch (err: unknown) {
      const latencyMs = Date.now() - startTime;
      if (err instanceof Error && err.name === 'AbortError') {
        return {
          ok: false,
          latencyMs,
          model: 'gemini-3.8-flash',
          error: 'Connection test timed out after 12 seconds.',
          code: 'TIMEOUT',
        };
      }
      return {
        ok: false,
        latencyMs,
        model: 'gemini-3.8-flash',
        error: err instanceof Error ? err.message : 'Failed to reach AI connection test endpoint.',
        code: 'NETWORK_ERROR',
      };
    }
  }

  /**
   * Sends prompt and history to server-side Gemini endpoint
   */
  public static async sendMessage(
    message: string,
    history: ChatMessage[],
    language: string
  ): Promise<AIChatResponse> {
    if (!navigator.onLine) {
      return {
        success: false,
        isOffline: true,
        error: 'Network offline. Please check your internet connectivity to converse with ELYSIA.',
      };
    }

    try {
      // Send up to 6 previous turns for compact context
      const formattedHistory = history
        .filter(m => m.role === 'user' || m.role === 'assistant')
        .slice(-6)
        .map(m => ({
          role: m.role,
          content: m.content,
        }));

      // 40-second timeout allows for network variance and thinking tokens
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 40000);

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message,
          history: formattedHistory,
          language,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      const data = await response.json().catch(() => null);

      if (!response.ok || !data || !data.success) {
        let msg = data?.error || `Server responded with status ${response.status}`;
        if (response.status === 503) {
          msg = 'Gemini API key is not configured in this environment. Please configure GEMINI_API_KEY in Settings > Secrets.';
        } else if (response.status === 401) {
          msg = 'Invalid Gemini API key. Please check your GEMINI_API_KEY in Settings > Secrets.';
        } else if (response.status === 429) {
          msg = 'Rate limit reached on Gemini neural core. Please wait a moment and try again.';
        }
        return {
          success: false,
          error: msg,
        };
      }

      return {
        success: true,
        text: data.text,
      };
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') {
        return {
          success: false,
          error: 'Neural network request timed out (40s limit reached). Please try again or verify your connection.',
        };
      }
      return {
        success: false,
        error: err instanceof Error ? err.message : 'Communication error with AI service.',
      };
    }
  }
}
