/** قائمة عبادات شخصية اختيارية؛ لا تدخل في وقت الدراسة أو مكافآت النقاط. */
import { localDateKey } from './dailyTasks';
import { KEYS, readKey, withStorageLock, writeKey } from './storage';

export type DailyRoutineId =
  | 'prayer-fajr'
  | 'prayer-dhuhr'
  | 'prayer-asr'
  | 'prayer-maghrib'
  | 'prayer-isha'
  | 'quran-wird'
  | 'adhkar-morning'
  | 'adhkar-evening';

export type DailyRoutineCategory = 'prayer' | 'quran' | 'adhkar';

export interface DailyRoutineItem {
  id: DailyRoutineId;
  title: string;
  category: DailyRoutineCategory;
}

export interface DailyRoutineDay {
  date: string;
  done: Record<DailyRoutineId, boolean>;
  updatedAt: number;
}

export interface DailyRoutineStore {
  days: Record<string, DailyRoutineDay>;
}

export const DAILY_ROUTINES: DailyRoutineItem[] = [
  { id: 'prayer-fajr', title: 'صلاة الفجر', category: 'prayer' },
  { id: 'prayer-dhuhr', title: 'صلاة الظهر', category: 'prayer' },
  { id: 'prayer-asr', title: 'صلاة العصر', category: 'prayer' },
  { id: 'prayer-maghrib', title: 'صلاة المغرب', category: 'prayer' },
  { id: 'prayer-isha', title: 'صلاة العشاء', category: 'prayer' },
  { id: 'quran-wird', title: 'ورد القرآن', category: 'quran' },
  { id: 'adhkar-morning', title: 'أذكار الصباح', category: 'adhkar' },
  { id: 'adhkar-evening', title: 'أذكار المساء', category: 'adhkar' },
];

export const EMPTY_DAILY_ROUTINES: DailyRoutineStore = { days: {} };

function emptyDay(date: string): DailyRoutineDay {
  const done = {} as Record<DailyRoutineId, boolean>;
  for (const item of DAILY_ROUTINES) done[item.id] = false;
  return { date, done, updatedAt: 0 };
}

function normalizeStore(value: Partial<DailyRoutineStore> | null | undefined): DailyRoutineStore {
  const sourceDays = value?.days && typeof value.days === 'object' ? value.days : {};
  const days: Record<string, DailyRoutineDay> = {};
  for (const [date, raw] of Object.entries(sourceDays)) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !raw || typeof raw !== 'object') continue;
    const done = {} as Record<DailyRoutineId, boolean>;
    for (const item of DAILY_ROUTINES) done[item.id] = raw.done?.[item.id] === true;
    days[date] = {
      date,
      done,
      updatedAt: Number.isFinite(raw.updatedAt) ? Math.max(0, raw.updatedAt) : 0,
    };
  }
  return { days };
}

export function getDailyRoutineStore(): DailyRoutineStore {
  return normalizeStore(readKey<DailyRoutineStore>(KEYS.dailyRoutines, EMPTY_DAILY_ROUTINES));
}

export function getDailyRoutineDay(date = new Date(), store = getDailyRoutineStore()): DailyRoutineDay {
  const key = localDateKey(date);
  const normalized = normalizeStore(store);
  return normalized.days[key] ?? emptyDay(key);
}

/** يحفظ اختيار الطالب محلياً ويستخدم قفل النسخة الاحتياطية المشترك؛ لا يمنح نقاطاً. */
export function setDailyRoutineDone(id: DailyRoutineId, done: boolean, date = new Date()): Promise<boolean> {
  if (!DAILY_ROUTINES.some((item) => item.id === id)) return Promise.resolve(false);
  const key = localDateKey(date);
  return withStorageLock('wallet', [KEYS.dailyRoutines], () => {
    const current = getDailyRoutineStore();
    const day = current.days[key] ?? emptyDay(key);
    if (day.done[id] === done) return true;
    const next: DailyRoutineStore = {
      days: {
        ...current.days,
        [key]: { ...day, done: { ...day.done, [id]: done }, updatedAt: Date.now() },
      },
    };
    return writeKey(KEYS.dailyRoutines, next);
  });
}
