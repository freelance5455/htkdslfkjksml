import { SubtitleCue } from '../types';

export const SAMPLE_VIDEOS = [
  {
    id: 'demo-sample-1',
    title: 'Technology & AI Demo (डेमो वीडियो 1)',
    description: 'High-definition video showcasing voice, video playback and subtitle synchronization.',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    duration: 15,
  },
  {
    id: 'demo-sample-2',
    title: 'Nature & Landscape (डेमो वीडियो 2)',
    description: 'Natural scenery clip ideal for testing local dubbing and audio ducking.',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    duration: 10,
  },
];

export const INITIAL_SUBTITLES: SubtitleCue[] = [
  {
    id: 1,
    startTime: 0.5,
    endTime: 4.0,
    hindiText: 'नमस्ते! हिंदी वीडियो अनुवादक में आपका स्वागत है।',
    originalText: 'Hello! Welcome to Hindi Video Translator.',
    romanizedHindi: 'Namaste! Hindi Video Anuvadak mein aapka swagat hai.',
  },
  {
    id: 2,
    startTime: 4.2,
    endTime: 8.5,
    hindiText: 'आप अपने फोन स्टोरेज से कोई भी स्थानीय वीडियो चुन सकते हैं।',
    originalText: 'You can select any local video file from your phone storage.',
    romanizedHindi: 'Aap apne phone storage se koi bhi sthaniya video chun sakte hain.',
  },
  {
    id: 3,
    startTime: 8.8,
    endTime: 13.0,
    hindiText: 'हम सटीक टाइमस्टैम्प के साथ समकालिक हिंदी उपशीर्षक दिखाते हैं।',
    originalText: 'We display synchronized Hindi subtitles with precise timestamps.',
    romanizedHindi: 'Hum sateek timestamp ke saath samkaalik Hindi upsheershak dikhate hain.',
  },
  {
    id: 4,
    startTime: 13.2,
    endTime: 18.0,
    hindiText: 'और एंड्रॉइड टेक्स्ट-टू-स्पीच के साथ रीयल-टाइम हिंदी डबिंग भी प्रदान करते हैं।',
    originalText: 'And provide real-time Hindi dubbing with Android Text-To-Speech.',
    romanizedHindi: 'Aur Android Text-To-Speech ke saath real-time Hindi dubbing bhi pradaan karte hain.',
  },
  {
    id: 5,
    startTime: 18.2,
    endTime: 23.5,
    hindiText: 'मूल ऑडियो, हिंदी उपशीर्षक और हिंदी डब ऑडियो के बीच तुरंत स्विच करें।',
    originalText: 'Instantly switch between Original Audio, Hindi Subtitles, and Hindi Dubbed Audio.',
    romanizedHindi: 'Mool audio, Hindi upsheershak aur Hindi dub audio ke beech turant switch karein.',
  },
  {
    id: 6,
    startTime: 23.8,
    endTime: 29.0,
    hindiText: 'यह प्रोजेक्ट पूरी तरह से कोटलिन और जेटपैक कंपोज़ में एंड्रॉइड स्टूडियो के लिए तैयार है।',
    originalText: 'This project is ready for Android Studio using Kotlin and Jetpack Compose.',
    romanizedHindi: 'Yeh project poori tarah se Kotlin aur Jetpack Compose mein Android Studio ke liye taiyar hai.',
  },
];

export const SAMPLE_TRANSLATION_PRESETS = [
  {
    label: 'टेक और उत्पाद परिचय (Tech Product Intro)',
    text: 'Welcome to this product review. Today we explore advanced video localization. The playback is seamless and subtitles are aligned with millisecond accuracy.',
  },
  {
    label: 'शैक्षिक ट्यूटोरियल (Educational Tutorial)',
    text: 'In this beginner tutorial, we will learn how Android applications work. We use ExoPlayer for media and Android TextToSpeech for Hindi voice synthesis.',
  },
  {
    label: 'यात्रा और व्लॉग (Travel & Vlog)',
    text: 'Good morning everyone! Today we are exploring the mountains and vibrant local culture. The experience is truly unforgettable and inspiring.',
  },
];
