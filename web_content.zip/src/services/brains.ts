/**
 * HELENA - 2 Cérebros (Google Gemini + Groq)
 * Cérebro 1: Google Gemini (gemini-3.1-flash-lite / gemini-3.8-flash)
 * Cérebro 2: Groq (llama-3.3-70b-versatile / openai/gpt-oss-120b)
 * 
 * Regra de Consenso:
 * - Conversa simples (saudações, bate-papo): usa apenas o Gemini.
 * - Perguntas de fatos: envia aos 2 cérebros.
 * - Se concordarem na afirmação principal: responde com a versão de consenso.
 * - Se divergirem: refaz 1 vez reformulando a pergunta internamente.
 * - Se continuarem divergindo: apresenta as duas respostas e explica claramente no que diferem.
 * - Se um dos dois falhar (erro 429, cota, rede): responde com o outro e avisa discretamente "1 cérebro".
 */

import { AppSettings, HistoryItem } from '../types';
import { addHistoryItem } from './storage';
import { normalizeAnatomicalQuery } from './anatomySearch';

export interface BrainsResult {
  hasConsensus: boolean;
  consensusText: string;
  agreedCount: number;
  totalActiveBrains: number;
  isSingleBrainFallback?: boolean;
  individualResponses: {
    gemini?: string;
    groq?: string;
  };
  sourceInfo?: {
    url: string;
    title: string;
    snippet?: string;
  };
}

// 1. Call Gemini Text
export async function callGemini(
  prompt: string, 
  key: string, 
  modelName: string
): Promise<string> {
  const model = modelName || 'gemini-3.1-flash-lite';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key.trim()}`;
  
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: `Responda de forma direta, factual e concisa em português do Brasil (1 a 2 frases):\n${prompt}` }] }],
      generationConfig: { temperature: 0.1, maxOutputTokens: 250 },
    }),
  });

  if (!response.ok) {
    // If gemini-3.1-flash-lite fails, fallback seamlessly to gemini-3.8-flash or gemini-2.5-flash
    if (model !== 'gemini-3.8-flash') {
      return callGemini(prompt, key, 'gemini-3.8-flash');
    }
    const errorData = await response.json().catch(() => ({}));
    throw new Error(`Gemini error (${response.status}): ${JSON.stringify(errorData)}`);
  }

  const data = await response.json();
  return data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || '';
}

// 2. Call Groq Text
export async function callGroq(
  prompt: string, 
  key: string, 
  modelName: string
): Promise<string> {
  const model = modelName || 'llama-3.3-70b-versatile';
  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${key.trim()}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: 'Você é a HELENA. Responda de forma direta, factual e objetiva em português do Brasil em 1 ou 2 frases curtas.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.1,
      max_tokens: 250,
    }),
  });

  if (!response.ok) {
    // If llama-3.3-70b-versatile has 404 on this tier, fallback to active model
    if (model !== 'openai/gpt-oss-120b') {
      return callGroq(prompt, key, 'openai/gpt-oss-120b');
    }
    const err = await response.json().catch(() => ({}));
    throw new Error(`Groq error (${response.status}): ${JSON.stringify(err)}`);
  }

  const data = await response.json();
  return data?.choices?.[0]?.message?.content?.trim() || '';
}

// Check if query is simple conversational chat / greeting
function isSimpleConversation(query: string): boolean {
  const q = query.toLowerCase().trim();
  const simplePatterns = [
    /^(olá|oi|ola|bom dia|boa tarde|boa noite|tudo bem|como vai|quem é você|qual seu nome)\b/,
    /^(obrigad[oa]|valeu|tchau|até mais|ate logo)\b/,
  ];
  return simplePatterns.some((p) => p.test(q)) && q.split(/\s+/).length <= 6;
}

// Evaluate consensus between Gemini and Groq using Gemini Judge
async function evaluateTwoBrainsConsensus(
  query: string,
  geminiResp: string,
  groqResp: string,
  geminiKey: string
): Promise<{
  agree: boolean;
  consensusAnswer: string;
  divergenceText: string;
  sourceTitle: string;
  sourceUrl: string;
}> {
  const judgePrompt = `Você é o Juiz de Consenso da HELENA.
Pergunta do usuário: "${query}"

Resposta Cérebro 1 (Gemini): "${geminiResp}"
Resposta Cérebro 2 (Groq): "${groqResp}"

Regras:
1. Verifique se ambos concordam no fato principal.
2. Se concordam:
   - "agree": true
   - "consensusAnswer": resposta consensual clara e curta em português (1 a 2 frases) para falar em voz alta.
   - "divergenceText": ""
3. Se discordam ou dão fatos divergentes:
   - "agree": false
   - "consensusAnswer": ""
   - "divergenceText": explicação em português dizendo claramente no que diferem (ex: "O Cérebro 1 indicou X, enquanto o Cérebro 2 indicou Y").
4. Indique a fonte/portal científico ou referência acadêmica/veterinária mais relevante diretamente relacionada ao que foi perguntado (exemplos: Manual Veterinário MSD / Merck Vet Manual, PubMed / NCBI, SciELO Brasil, CFMV, Embrapa Pecuária, etc.). NUNCA indique Google Notícias nem portais genéricos.

Retorne APENAS um JSON no formato:
{
  "agree": boolean,
  "consensusAnswer": string,
  "divergenceText": string,
  "sourceTitle": string,
  "sourceUrl": string
}`;

  try {
    const raw = await callGemini(judgePrompt, geminiKey, 'gemini-3.8-flash');
    const clean = raw.replace(/```json/gi, '').replace(/```/g, '').trim();
    const parsed = JSON.parse(clean);
    const fallbackSource = getAuthoritativeVeterinarySource(query);
    return {
      agree: Boolean(parsed.agree),
      consensusAnswer: parsed.consensusAnswer || geminiResp,
      divergenceText: parsed.divergenceText || `O Gemini respondeu: "${geminiResp}", enquanto o Groq respondeu: "${groqResp}".`,
      sourceTitle: parsed.sourceTitle && !parsed.sourceTitle.toLowerCase().includes('notícia') ? parsed.sourceTitle : fallbackSource.title,
      sourceUrl: parsed.sourceUrl && !parsed.sourceUrl.includes('news.google.com') ? parsed.sourceUrl : fallbackSource.url,
    };
  } catch {
    // Fallback comparison
    const tok = (s: string) => s.toLowerCase().split(/\s+/).filter(w => w.length > 3);
    const setA = new Set(tok(geminiResp));
    const overlap = tok(groqResp).filter(w => setA.has(w));
    const agree = overlap.length >= 2;
    const fallbackSource = getAuthoritativeVeterinarySource(query);
    return {
      agree,
      consensusAnswer: agree ? geminiResp : '',
      divergenceText: `O Gemini respondeu: "${geminiResp}", enquanto o Groq indicou: "${groqResp}".`,
      sourceTitle: fallbackSource.title,
      sourceUrl: fallbackSource.url,
    };
  }
}

/**
 * Returns an authoritative veterinary/scientific portal link relevant to the query
 */
export function getAuthoritativeVeterinarySource(query: string): { title: string; url: string } {
  const q = query.toLowerCase();
  if (q.includes('cão') || q.includes('canin') || q.includes('gato') || q.includes('felin') || q.includes('doen') || q.includes('medic') || q.includes('sintom') || q.includes('cirurg') || q.includes('vacina') || q.includes('tratament')) {
    return {
      title: 'Manual Veterinário MSD (Merck Veterinary Manual)',
      url: `https://www.merckvetmanual.com/search?query=${encodeURIComponent(query)}`,
    };
  }
  if (q.includes('cavalo') || q.includes('equin') || q.includes('bovin') || q.includes('boi') || q.includes('vaca') || q.includes('pecuaria') || q.includes('gado') || q.includes('pasto') || q.includes('ovino') || q.includes('suíno')) {
    return {
      title: 'Embrapa - Acervo de Publicações Técnico-Científicas',
      url: `https://www.embrapa.br/busca-de-publicacoes/-/busca/busca?q=${encodeURIComponent(query)}`,
    };
  }
  return {
    title: 'Google Acadêmico (Literatura e Artigos Veterinários)',
    url: `https://scholar.google.com.br/scholar?q=${encodeURIComponent(query + ' medicina veterinaria')}&hl=pt-BR`,
  };
}

/**
 * Ask the 2 brains with consensus rule
 */
export async function askBrainsWithConsensus(
  query: string,
  settings: AppSettings
): Promise<BrainsResult> {
  const cleanQuery = query.trim();

  // Simple conversational chat uses only Gemini
  if (isSimpleConversation(cleanQuery)) {
    if (settings.geminiKey) {
      try {
        const text = await callGemini(cleanQuery, settings.geminiKey, settings.geminiModel);
        return {
          hasConsensus: true,
          consensusText: text,
          agreedCount: 1,
          totalActiveBrains: 1,
          individualResponses: { gemini: text },
        };
      } catch (err) {
        console.warn('Gemini chat failed, fallback to Groq:', err);
      }
    }
  }

  // 1st Attempt: Send to both brains
  const [resGemini1, resGroq1] = await Promise.all([
    settings.geminiKey
      ? callGemini(cleanQuery, settings.geminiKey, settings.geminiModel).catch((e) => {
          console.warn('Gemini 1st try error:', e);
          return null;
        })
      : null,
    settings.groqKey
      ? callGroq(cleanQuery, settings.groqKey, settings.groqModel).catch((e) => {
          console.warn('Groq 1st try error:', e);
          return null;
        })
      : null,
  ]);

  // Handle single brain fallback if one failed
  if (resGemini1 && !resGroq1) {
    const spoken = `${resGemini1} (Aviso: 1 cérebro)`;
    recordHistory(cleanQuery, spoken, 1, 1, { gemini: resGemini1 });
    return {
      hasConsensus: true,
      consensusText: spoken,
      agreedCount: 1,
      totalActiveBrains: 1,
      isSingleBrainFallback: true,
      individualResponses: { gemini: resGemini1 },
      sourceInfo: getAuthoritativeVeterinarySource(cleanQuery),
    };
  }

  if (resGroq1 && !resGemini1) {
    const spoken = `${resGroq1} (Aviso: 1 cérebro)`;
    recordHistory(cleanQuery, spoken, 1, 1, { groq: resGroq1 });
    return {
      hasConsensus: true,
      consensusText: spoken,
      agreedCount: 1,
      totalActiveBrains: 1,
      isSingleBrainFallback: true,
      individualResponses: { groq: resGroq1 },
      sourceInfo: getAuthoritativeVeterinarySource(cleanQuery),
    };
  }

  if (!resGemini1 && !resGroq1) {
    const msg = 'Não foi possível consultar os cérebros configurados. Verifique as chaves e modelos na aba Admin.';
    return {
      hasConsensus: false,
      consensusText: msg,
      agreedCount: 0,
      totalActiveBrains: 0,
      individualResponses: {},
    };
  }

  // Evaluate 1st attempt consensus
  const judge1 = await evaluateTwoBrainsConsensus(
    cleanQuery,
    resGemini1!,
    resGroq1!,
    settings.geminiKey
  );

  if (judge1.agree) {
    recordHistory(cleanQuery, judge1.consensusAnswer, 2, 2, {
      gemini: resGemini1!,
      groq: resGroq1!,
    });
    return {
      hasConsensus: true,
      consensusText: judge1.consensusAnswer,
      agreedCount: 2,
      totalActiveBrains: 2,
      individualResponses: { gemini: resGemini1!, groq: resGroq1! },
      sourceInfo: {
        title: judge1.sourceTitle,
        url: judge1.sourceUrl,
      },
    };
  }

  // Diverged: 2nd Attempt by reformulating the question once
  const reformulatedPrompt = `Responda com o fato histórico ou científico comprovado para a dúvida: ${cleanQuery}. Seja estritamente objetivo.`;
  const [resGemini2, resGroq2] = await Promise.all([
    callGemini(reformulatedPrompt, settings.geminiKey, settings.geminiModel).catch(() => resGemini1),
    callGroq(reformulatedPrompt, settings.groqKey, settings.groqModel).catch(() => resGroq1),
  ]);

  const judge2 = await evaluateTwoBrainsConsensus(
    cleanQuery,
    resGemini2 || resGemini1!,
    resGroq2 || resGroq1!,
    settings.geminiKey
  );

  if (judge2.agree) {
    recordHistory(cleanQuery, judge2.consensusAnswer, 2, 2, {
      gemini: resGemini2 || resGemini1!,
      groq: resGroq2 || resGroq1!,
    });
    return {
      hasConsensus: true,
      consensusText: judge2.consensusAnswer,
      agreedCount: 2,
      totalActiveBrains: 2,
      individualResponses: { gemini: resGemini2 || resGemini1!, groq: resGroq2 || resGroq1! },
      sourceInfo: {
        title: judge2.sourceTitle,
        url: judge2.sourceUrl,
      },
    };
  }

  // Still diverging: present both answers and explain clearly where they differ
  const divergenceExplanation = `Os dois cérebros divergiram. ${judge2.divergenceText}`;
  recordHistory(cleanQuery, divergenceExplanation, 1, 2, {
    gemini: resGemini2 || resGemini1!,
    groq: resGroq2 || resGroq1!,
  });

  return {
    hasConsensus: false,
    consensusText: divergenceExplanation,
    agreedCount: 1,
    totalActiveBrains: 2,
    individualResponses: { gemini: resGemini2 || resGemini1!, groq: resGroq2 || resGroq1! },
    sourceInfo: judge2.sourceUrl && !judge2.sourceUrl.includes('news.google.com') 
      ? { title: judge2.sourceTitle, url: judge2.sourceUrl } 
      : getAuthoritativeVeterinarySource(cleanQuery),
  };
}

// Multi-modal Veterinary Field Photo Analysis
export async function analyzeVeterinaryFieldImages(
  imagesBase64: string[],
  clinicalContext: string,
  settings: AppSettings
): Promise<{
  reportText: string;
  geminiReport?: string;
  groqReport?: string;
  isSingleBrain: boolean;
}> {
  const promptStructured = `Você é a HELENA, assistente veterinária de campo.
Analise a(s) imagem(ns) clínica(s) anexada(s) fornecidas pelo médico-veterinário.
${clinicalContext ? `Contexto Clínico fornecido: "${clinicalContext}"` : 'Sem contexto clínico adicional.'}

Estruture sua resposta EXATAMENTE nestes 5 tópicos em português do Brasil:
1) O que se observa na imagem (descrição morfológica objetiva e alterações visíveis);
2) Diagnósticos diferenciais (do mais provável ao menos provável, com justificativa clínica sucinta);
3) O que verificar e examinar em campo e exames complementares recomendados;
4) Sinais de alerta e urgência;
5) Limitações (qualidade da foto, ângulo e o que não é possível avaliar visualmente).

Seja técnica, precisa e direta para apoiar o veterinário.`;

  // 1. Call Gemini with Images
  let geminiOutput = '';
  try {
    const model = settings.geminiModel || 'gemini-3.1-flash-lite';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${settings.geminiKey.trim()}`;

    const parts: any[] = [{ text: promptStructured }];
    for (const b64 of imagesBase64) {
      const match = b64.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (match) {
        parts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2],
          },
        });
      }
    }

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts }],
        generationConfig: { temperature: 0.2, maxOutputTokens: 900 },
      }),
    });

    if (res.ok) {
      const data = await res.json();
      geminiOutput = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || '';
    }
  } catch (e) {
    console.warn('Gemini vision error:', e);
  }

  // 2. Call Groq Vision (if available/configured)
  let groqOutput = '';
  if (settings.groqKey) {
    try {
      const visionModel = settings.groqVisionModel || 'llama-3.2-11b-vision-preview';
      const contentList: any[] = [{ type: 'text', text: promptStructured }];

      for (const b64 of imagesBase64) {
        contentList.push({
          type: 'image_url',
          image_url: { url: b64 },
        });
      }

      const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${settings.groqKey.trim()}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: visionModel,
          messages: [{ role: 'user', content: contentList }],
          max_tokens: 800,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        groqOutput = data?.choices?.[0]?.message?.content?.trim() || '';
      }
    } catch (e) {
      console.warn('Groq vision error:', e);
    }
  }

  // Combine reports
  if (geminiOutput && groqOutput) {
    const combined = `${geminiOutput}\n\n---\n**Segunda Opinião (Groq):**\n${groqOutput}`;
    return {
      reportText: combined,
      geminiReport: geminiOutput,
      groqReport: groqOutput,
      isSingleBrain: false,
    };
  }

  if (geminiOutput) {
    return {
      reportText: geminiOutput,
      geminiReport: geminiOutput,
      isSingleBrain: true,
    };
  }

  if (groqOutput) {
    return {
      reportText: groqOutput,
      groqReport: groqOutput,
      isSingleBrain: true,
    };
  }

  throw new Error('Não foi possível obter análise visual dos cérebros configurados.');
}

// 3D Online Search suggestions via Gemini (Etapa 1 da Busca)
export async function get3DModelSearchSuggestions(
  query: string,
  geminiKey: string
): Promise<{ titulo_pt: string; consulta_en: string; especie: string; estrutura: string }[]> {
  const prompt = `Você é o catálogo de anatomia veterinária da HELENA.
O veterinário solicitou: "${query}"

Gere em JSON estrito uma lista de 6 a 8 sugestões de modelos anatômicos 3D relevantes para buscar no Sketchfab.
A consulta_en deve ser em inglês técnico para máxima precisão anatômica (exemplo: "horse heart anatomy", "canine skull anatomy", "equine tarsus dissection").

Formato estrito JSON:
[
  {
    "titulo_pt": "Nome da estrutura em português",
    "consulta_en": "technical anatomy query in english",
    "especie": "cavalo|cão|gato|bovino|suíno|ave",
    "estrutura": "órgão ou osso"
  }
]`;

  try {
    const res = await callGemini(prompt, geminiKey, 'gemini-3.8-flash');
    const clean = res.replace(/```json/gi, '').replace(/```/g, '').trim();
    const parsed = JSON.parse(clean);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    const { suggestions } = normalizeAnatomicalQuery(query);
    return suggestions;
  } catch (err) {
    console.warn('Usando normalização anatômica científica local:', err);
    const { suggestions } = normalizeAnatomicalQuery(query);
    return suggestions;
  }
}

function recordHistory(
  query: string, 
  response: string, 
  consensusCount: number, 
  totalBrains: number, 
  details: { gemini?: string; groq?: string }
) {
  const historyItem: HistoryItem = {
    id: `hist_${Date.now()}`,
    timestamp: new Date().toISOString(),
    query,
    response,
    consensusCount,
    totalBrains,
    details,
  };
  addHistoryItem(historyItem);
}
