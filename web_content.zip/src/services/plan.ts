/** جدول الدراسة الأسبوعي: يُشتق من تاريخ الامتحان والساعات المتاحة وأوزان المواد */
import type { PlanSession, StudyPlan } from '../types';
import { subjects } from '../data/content';
import { subjectProgress } from './progress';
import { KEYS, readKey, writeKey } from './storage';

const emptyPlan: StudyPlan = { generatedAt: 0, hoursPerDay: 3, sessions: [] };

export const WEEK_DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export function getPlan(): StudyPlan {
  return readKey<StudyPlan>(KEYS.plan, emptyPlan);
}

export function savePlan(plan: StudyPlan): void {
  writeKey<StudyPlan>(KEYS.plan, plan);
}

/**
 * يولّد خطة أسبوعية:
 * - وزن كل مادة = وزنها في المنهاج × حاجة المادة (١٠٠ − التقدم الحالي)
 * - يوزّع حصصاً بمدة ٣٠/٤٥/٦٠ دقيقة على أيام الأسبوع حسب الساعات المتاحة يومياً
 */
export function generatePlan(hoursPerDay: number): StudyPlan {
  const dailyMinutes = Math.max(30, Math.round(hoursPerDay * 60));
  const weights = subjects.map((s) => {
    const need = 1 - subjectProgress(s) / 100;
    return { subject: s, score: s.weight * (0.35 + need) };
  });
  const totalWeight = weights.reduce((sum, w) => sum + w.score, 0) || 1;

  // عدد الحصص في اليوم: كل ٤٥ دقيقة حصة، بحد أقصى ٤ حصص
  const sessionsPerDay = Math.max(1, Math.min(4, Math.round(dailyMinutes / 45)));
  const sessionMinutes = Math.round(dailyMinutes / sessionsPerDay);
  const sessions: PlanSession[] = [];
  let cursor = 0;
  // توزيع عادل بترتيب دائري موزون
  const queue: { subjectId: string; label: string }[] = [];
  // نوزّع الحصص بالتناوب بين المواد (٢،٠،١،٢،٠،١…) بدل تكديس مادة واحدة
  const slots = weights.map((w) => ({
    subjectId: w.subject.id,
    label: w.subject.name,
    count: Math.max(1, Math.round((w.score / totalWeight) * sessionsPerDay * 7)),
  }));
  const maxCount = Math.max(...slots.map((s) => s.count));
  for (let round = 0; round < maxCount; round += 1) {
    for (const slot of slots) {
      if (round < slot.count) queue.push({ subjectId: slot.subjectId, label: slot.label });
    }
  }

  for (let day = 0; day < 7; day += 1) {
    for (let i = 0; i < sessionsPerDay; i += 1) {
      const item = queue[cursor % queue.length];
      cursor += 1;
      if (!item) continue;
      sessions.push({
        id: `ps-${day}-${i}-${item.subjectId}`,
        day: day as PlanSession['day'],
        subjectId: item.subjectId,
        minutes: sessionMinutes,
        label: item.label,
        done: false,
      });
    }
  }

  const plan: StudyPlan = { generatedAt: Date.now(), hoursPerDay, sessions };
  savePlan(plan);
  return plan;
}

export function toggleSession(sessionId: string): void {
  const plan = getPlan();
  savePlan({
    ...plan,
    sessions: plan.sessions.map((s) => (s.id === sessionId ? { ...s, done: !s.done } : s)),
  });
}

export function addSession(day: PlanSession['day'], subjectId: string, minutes: number): void {
  const plan = getPlan();
  const subject = subjects.find((s) => s.id === subjectId);
  savePlan({
    ...plan,
    sessions: [
      ...plan.sessions,
      {
        id: `ps-${Date.now()}`,
        day,
        subjectId,
        minutes,
        label: subject ? subject.name : subjectId,
        done: false,
      },
    ],
  });
}

export function removeSession(sessionId: string): void {
  const plan = getPlan();
  savePlan({ ...plan, sessions: plan.sessions.filter((s) => s.id !== sessionId) });
}

export function daysUntilExam(examDate: string): number {
  const target = new Date(examDate).getTime();
  if (Number.isNaN(target)) return 0;
  return Math.max(0, Math.ceil((target - Date.now()) / 86_400_000));
}

export function planSummary(): { total: number; done: number; minutes: number } {
  const plan = getPlan();
  return {
    total: plan.sessions.length,
    done: plan.sessions.filter((s) => s.done).length,
    minutes: plan.sessions.reduce((sum, s) => sum + s.minutes, 0),
  };
}
