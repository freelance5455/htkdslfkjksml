import { Book, ReadingSession } from '../types';

export interface CalculatedStats {
  totalBooks: number;
  completedBooks: number;
  readingBooks: number;
  toReadBooks: number;
  abandonedBooks: number;
  totalPagesRead: number;
  totalReadingMinutes: number;
  totalReadingHoursFormatted: string;
  totalSessions: number;
  currentStreakDays: number;
  longestStreakDays: number;
  readingVelocityPagesPerHour: number;
  avgPagesPerSession: number;
  avgMinutesPerSession: number;
  activeReadingDaysCount: number;
  topAuthors: { name: string; count: number; pages: number }[];
  topGenres: { name: string; count: number }[];
  monthlyBreakdown: { monthLabel: string; monthIndex: number; pages: number; minutes: number; booksCompleted: number }[];
}

export function calculateReadingStats(books: Book[], sessions: ReadingSession[], targetYear?: number): CalculatedStats {
  const currentYear = targetYear || new Date().getFullYear();

  // Filter sessions if specific year is requested
  const relevantSessions = targetYear
    ? sessions.filter((s) => new Date(s.date).getFullYear() === targetYear)
    : sessions;

  const totalBooks = books.length;
  const completedBooks = books.filter((b) => b.status === 'TERMINADO').length;
  const readingBooks = books.filter((b) => b.status === 'LEYENDO').length;
  const toReadBooks = books.filter((b) => b.status === 'POR LEER').length;
  const abandonedBooks = books.filter((b) => b.status === 'ABANDONADO').length;

  // Pages read from sessions if available, or fallback to sum of books pagesRead
  const totalPagesFromSessions = relevantSessions.reduce((acc, s) => acc + (s.pagesRead || 0), 0);
  const totalPagesFromBooks = books.reduce((acc, b) => acc + (b.pagesRead || 0), 0);
  const totalPagesRead = Math.max(totalPagesFromSessions, totalPagesFromBooks);

  // Minutes
  const totalMinutesFromSessions = relevantSessions.reduce((acc, s) => acc + (s.durationMinutes || 0), 0);
  const totalMinutesFromBooks = books.reduce((acc, b) => acc + (b.totalReadingMinutes || 0), 0);
  const totalReadingMinutes = Math.max(totalMinutesFromSessions, totalMinutesFromBooks);

  const hours = Math.floor(totalReadingMinutes / 60);
  const mins = totalReadingMinutes % 60;
  const totalReadingHoursFormatted = hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;

  const totalSessions = relevantSessions.length;
  const avgPagesPerSession = totalSessions > 0 ? Math.round(totalPagesRead / totalSessions) : 0;
  const avgMinutesPerSession = totalSessions > 0 ? Math.round(totalReadingMinutes / totalSessions) : 0;

  const readingHours = totalReadingMinutes / 60;
  const readingVelocityPagesPerHour = readingHours > 0 ? Math.round(totalPagesRead / readingHours) : 0;

  // Unique active days
  const activeDaysSet = new Set<string>();
  relevantSessions.forEach((s) => {
    if (s.date) activeDaysSet.add(s.date.slice(0, 10));
  });
  const activeReadingDaysCount = activeDaysSet.size;

  // Streaks calculation from all sessions sorted by date
  const allSortedDates = Array.from(new Set(sessions.map((s) => s.date.slice(0, 10)))).sort();
  const { currentStreak, longestStreak } = calculateStreaks(allSortedDates);

  // Top Authors
  const authorMap = new Map<string, { count: number; pages: number }>();
  books.forEach((b) => {
    if (!b.author) return;
    const existing = authorMap.get(b.author) || { count: 0, pages: 0 };
    existing.count += 1;
    existing.pages += b.pagesRead || 0;
    authorMap.set(b.author, existing);
  });
  const topAuthors = Array.from(authorMap.entries())
    .map(([name, data]) => ({ name, count: data.count, pages: data.pages }))
    .sort((a, b) => b.pages - a.pages)
    .slice(0, 5);

  // Top Genres
  const genreMap = new Map<string, number>();
  books.forEach((b) => {
    b.genres?.forEach((g) => {
      genreMap.set(g, (genreMap.get(g) || 0) + 1);
    });
  });
  const topGenres = Array.from(genreMap.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);

  // Monthly breakdown for targetYear
  const monthNames = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  const monthlyBreakdown = monthNames.map((monthLabel, idx) => {
    const monthSessions = sessions.filter((s) => {
      const d = new Date(s.date);
      return d.getFullYear() === currentYear && d.getMonth() === idx;
    });

    const pages = monthSessions.reduce((acc, s) => acc + (s.pagesRead || 0), 0);
    const minutes = monthSessions.reduce((acc, s) => acc + (s.durationMinutes || 0), 0);

    const booksCompleted = books.filter((b) => {
      if (b.status !== 'TERMINADO' || !b.dateFinished) return false;
      const d = new Date(b.dateFinished);
      return d.getFullYear() === currentYear && d.getMonth() === idx;
    }).length;

    return {
      monthLabel,
      monthIndex: idx,
      pages,
      minutes,
      booksCompleted,
    };
  });

  return {
    totalBooks,
    completedBooks,
    readingBooks,
    toReadBooks,
    abandonedBooks,
    totalPagesRead,
    totalReadingMinutes,
    totalReadingHoursFormatted,
    totalSessions,
    currentStreakDays: currentStreak,
    longestStreakDays: longestStreak,
    readingVelocityPagesPerHour,
    avgPagesPerSession,
    avgMinutesPerSession,
    activeReadingDaysCount,
    topAuthors,
    topGenres,
    monthlyBreakdown,
  };
}

function calculateStreaks(sortedDateStrings: string[]): { currentStreak: number; longestStreak: number } {
  if (sortedDateStrings.length === 0) return { currentStreak: 0, longestStreak: 0 };

  const dates = sortedDateStrings.map((d) => new Date(d + 'T00:00:00Z')).sort((a, b) => a.getTime() - b.getTime());

  let longest = 1;
  let currentRun = 1;

  for (let i = 1; i < dates.length; i++) {
    const prev = dates[i - 1];
    const curr = dates[i];
    const diffDays = Math.round((curr.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      currentRun++;
      if (currentRun > longest) longest = currentRun;
    } else if (diffDays > 1) {
      currentRun = 1;
    }
  }

  // Check if current streak extends to today or yesterday
  const now = new Date();
  const todayUtc = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
  const lastActiveDate = dates[dates.length - 1];
  const daysSinceLast = Math.round((todayUtc.getTime() - lastActiveDate.getTime()) / (1000 * 60 * 60 * 24));

  let currentStreak = 0;
  if (daysSinceLast <= 1) {
    // Current streak is active
    currentStreak = currentRun;
  }

  return {
    currentStreak,
    longestStreak: Math.max(longest, currentStreak),
  };
}
