export interface MultiplayerMessage {
  type: 'JOIN' | 'MOVE' | 'DRAW_OFFER' | 'DRAW_ACCEPT' | 'DRAW_DECLINE' | 'RESIGN' | 'PING' | 'PONG';
  roomId: string;
  senderId: string;
  senderName: string;
  payload?: any;
}

export type MultiplayerListener = (msg: MultiplayerMessage) => void;

class MultiplayerService {
  private channel: BroadcastChannel | null = null;
  private listeners: Set<MultiplayerListener> = new Set();
  private currentRoomId: string | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        this.channel = new BroadcastChannel('chess_3d_p2p_channel');
        this.channel.onmessage = (event) => {
          const msg = event.data as MultiplayerMessage;
          if (this.currentRoomId && msg.roomId === this.currentRoomId) {
            this.listeners.forEach((listener) => listener(msg));
          }
        };
      } catch (err) {
        console.warn('BroadcastChannel not supported in this environment', err);
      }
    }
  }

  public joinRoom(roomId: string, senderId: string, senderName: string): void {
    this.currentRoomId = roomId;
    this.broadcast({
      type: 'JOIN',
      roomId,
      senderId,
      senderName,
    });
  }

  public leaveRoom(): void {
    this.currentRoomId = null;
  }

  public subscribe(listener: MultiplayerListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public broadcast(msg: MultiplayerMessage): void {
    if (this.channel) {
      this.channel.postMessage(msg);
    }
  }

  public sendMove(roomId: string, senderId: string, senderName: string, move: { from: string; to: string; promotion?: string; san: string; fen: string }): void {
    this.broadcast({
      type: 'MOVE',
      roomId,
      senderId,
      senderName,
      payload: move,
    });
  }

  public sendDrawOffer(roomId: string, senderId: string, senderName: string): void {
    this.broadcast({
      type: 'DRAW_OFFER',
      roomId,
      senderId,
      senderName,
    });
  }

  public sendDrawAccept(roomId: string, senderId: string, senderName: string): void {
    this.broadcast({
      type: 'DRAW_ACCEPT',
      roomId,
      senderId,
      senderName,
    });
  }

  public sendDrawDecline(roomId: string, senderId: string, senderName: string): void {
    this.broadcast({
      type: 'DRAW_DECLINE',
      roomId,
      senderId,
      senderName,
    });
  }

  public sendResign(roomId: string, senderId: string, senderName: string): void {
    this.broadcast({
      type: 'RESIGN',
      roomId,
      senderId,
      senderName,
    });
  }
}

export const multiplayer = new MultiplayerService();

// Supabase client initialization for production persistence
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const getEnvVar = (key: string): string => {
  try {
    if (typeof import.meta !== 'undefined' && (import.meta as any).env?.[key]) {
      return (import.meta as any).env[key];
    }
  } catch {}
  try {
    if (typeof process !== 'undefined' && process.env?.[key]) {
      return process.env[key] as string;
    }
  } catch {}
  return '';
};

const supabaseUrl = getEnvVar('VITE_SUPABASE_URL');
const supabaseAnonKey = getEnvVar('VITE_SUPABASE_ANON_KEY');

export const isSupabaseConfigured = (): boolean => {
  return Boolean(
    supabaseUrl &&
    supabaseAnonKey &&
    (supabaseUrl.startsWith('http://') || supabaseUrl.startsWith('https://')) &&
    !supabaseUrl.includes('your-project-id')
  );
};

let client: SupabaseClient | null = null;
if (isSupabaseConfigured()) {
  try {
    client = createClient(supabaseUrl, supabaseAnonKey);
  } catch (err) {
    console.warn('Supabase initialization bypassed:', err);
    client = null;
  }
}

export const supabase: SupabaseClient | null = client;
