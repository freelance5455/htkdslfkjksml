import { SrsItem, SrsRating, WordData } from '../types';

// Standard Ebbinghaus Spaced Repetition interval stabilities in days:
// Stage 0: 0.5d (12h) -> Stage 1: 1d -> Stage 2: 3d -> Stage 3: 7d -> Stage 4: 16d -> Stage 5: 35d -> Stage 6: 90d (Permanent Consolidation)
export const EBBINGHAUS_STAGES: Record<number, { days: number; label: string; desc: string }> = {
  0: { days: 0.5, label: 'Initial Encoding', desc: '12-hour consolidation' },
  1: { days: 1, label: 'Stage 1 (1-Day)', desc: '24-hour first recall check' },
  2: { days: 3, label: 'Stage 2 (3-Day)', desc: 'Early semantic consolidation' },
  3: { days: 7, label: 'Stage 3 (7-Day)', desc: 'One-week curve stabilization' },
  4: { days: 16, label: 'Stage 4 (16-Day)', desc: 'Medium-term storage' },
  5: { days: 35, label: 'Stage 5 (35-Day)', desc: 'Long-term memory retention' },
  6: { days: 90, label: 'Stage 6 (Permanent)', desc: 'Crystalline long-term mastery' },
};

export class SrsEngine {
  /**
   * Calculates current memory retention R according to Ebbinghaus:
   * R = e^(-t / S)
   * where t = elapsed time in days, S = memory stability in days.
   */
  public static calculateRetention(item: SrsItem, nowMs: number = Date.now()): number {
    const lastRevMs = new Date(item.lastReviewedAt).getTime();
    if (isNaN(lastRevMs)) return 100;

    const elapsedDays = Math.max(0, (nowMs - lastRevMs) / (1000 * 60 * 60 * 24));
    const stabilityDays = Math.max(0.2, item.stability || 1);

    // Ebbinghaus exponential decay
    const r = Math.exp(-elapsedDays / stabilityDays);
    const score = Math.round(r * 100);

    return Math.max(0, Math.min(100, score));
  }

  /**
   * Determines if a word is due for revision:
   * - Retention dropped below 80% threshold, OR
   * - nextReviewAt timestamp is in the past or today.
   */
  public static isDue(item: SrsItem, nowMs: number = Date.now()): boolean {
    const retention = this.calculateRetention(item, nowMs);
    if (retention < 80) return true;

    const nextRevMs = new Date(item.nextReviewAt).getTime();
    return !isNaN(nextRevMs) && nowMs >= nextRevMs;
  }

  /**
   * Bootstraps an initial SRS record for a word.
   */
  public static createDefaultItem(
    word: string,
    initialStatus: 'mastered' | 'revise' | 'learn' | 'unassigned' = 'learn',
    now: Date = new Date()
  ): SrsItem {
    let stage = 0;
    let stability = 0.5;

    if (initialStatus === 'mastered') {
      stage = 3;
      stability = 7;
    } else if (initialStatus === 'revise') {
      stage = 1;
      stability = 1;
    } else if (initialStatus === 'learn') {
      stage = 0;
      stability = 0.5;
    }

    const nextDate = new Date(now.getTime() + stability * 24 * 60 * 60 * 1000);

    return {
      word,
      stage,
      stability,
      lastReviewedAt: now.toISOString(),
      nextReviewAt: nextDate.toISOString(),
      reviewsCount: initialStatus === 'mastered' ? 2 : 1,
      lapses: initialStatus === 'revise' ? 1 : 0,
      retentionScore: 100,
    };
  }

  /**
   * Computes the new SRS state after a user reviews the word with a given rating.
   */
  public static reviewWord(
    item: SrsItem,
    rating: SrsRating,
    now: Date = new Date()
  ): {
    updatedItem: SrsItem;
    retentionDelta: number;
    fluencyRecommendation: number;
  } {
    let newStage = item.stage;
    let newStability = item.stability;
    let newLapses = item.lapses;

    switch (rating) {
      case 'again':
        // Forgetting curve reset: drop back to stage 1, stability 1 day
        newStage = 1;
        newStability = 1.0;
        newLapses += 1;
        break;

      case 'hard':
        // Recalled with hesitation: minor bump in stability, stage unchanged
        newStage = Math.max(1, item.stage);
        newStability = Math.max(1.0, Number((item.stability * 1.3).toFixed(1)));
        break;

      case 'good':
        // Normal successful recall: advance stage along Ebbinghaus curve
        newStage = Math.min(6, item.stage + 1);
        const targetDays = EBBINGHAUS_STAGES[newStage]?.days || item.stability * 2.2;
        newStability = Number(Math.max(item.stability * 1.8, targetDays).toFixed(1));
        break;

      case 'easy':
        // Effortless recall: jump 2 stages ahead
        newStage = Math.min(6, item.stage + 2);
        const easyTarget = EBBINGHAUS_STAGES[newStage]?.days || item.stability * 3.0;
        newStability = Number(Math.max(item.stability * 2.5, easyTarget).toFixed(1));
        break;
    }

    const nextReviewMs = now.getTime() + newStability * 24 * 60 * 60 * 1000;
    const nextReviewAt = new Date(nextReviewMs).toISOString();

    const updatedItem: SrsItem = {
      word: item.word,
      stage: newStage,
      stability: newStability,
      lastReviewedAt: now.toISOString(),
      nextReviewAt,
      reviewsCount: item.reviewsCount + 1,
      lapses: newLapses,
      retentionScore: 100, // Just reviewed, 100% retention
    };

    // Calculate fluency recommendation (WordUp 0-100% mapping)
    let fluencyRecommendation = 25;
    if (newStage >= 5) fluencyRecommendation = 100;
    else if (newStage >= 4) fluencyRecommendation = 85;
    else if (newStage >= 3) fluencyRecommendation = 70;
    else if (newStage >= 2) fluencyRecommendation = 50;
    else if (newStage >= 1) fluencyRecommendation = 35;

    return {
      updatedItem,
      retentionDelta: 100 - (item.retentionScore || 50),
      fluencyRecommendation,
    };
  }

  /**
   * Aggregates and categorizes all vocabulary words for the daily schedule.
   */
  public static getSrsSchedule(
    words: WordData[],
    srsRecords: Record<string, SrsItem> = {},
    masteredList: string[] = [],
    reviseList: string[] = [],
    learnList: string[] = []
  ): {
    dueWords: (WordData & { srs: SrsItem })[];
    upcomingWords: (WordData & { srs: SrsItem })[];
    masteredConsolidatedWords: (WordData & { srs: SrsItem })[];
    stats: {
      totalTracked: number;
      dueCount: number;
      averageRetention: number;
      retentionDistribution: {
        critical: number; // < 50%
        fading: number; // 50 - 79%
        stable: number; // >= 80%
      };
    };
  } {
    const nowMs = Date.now();
    const allWithSrs: (WordData & { srs: SrsItem })[] = [];

    // Ensure all active words have an SRS record
    words.forEach(w => {
      let item = srsRecords[w.word];
      if (!item) {
        // Derive initial status
        let initialStatus: 'mastered' | 'revise' | 'learn' | 'unassigned' = 'unassigned';
        if (masteredList.includes(w.word)) initialStatus = 'mastered';
        else if (reviseList.includes(w.word)) initialStatus = 'revise';
        else if (learnList.includes(w.word)) initialStatus = 'learn';

        // If not in any list yet, give it default
        item = this.createDefaultItem(w.word, initialStatus);
      }

      // Compute current live retention
      const currentRetention = this.calculateRetention(item, nowMs);
      const liveItem: SrsItem = {
        ...item,
        retentionScore: currentRetention,
      };

      allWithSrs.push({
        ...w,
        srs: liveItem,
      });
    });

    const dueWords: (WordData & { srs: SrsItem })[] = [];
    const upcomingWords: (WordData & { srs: SrsItem })[] = [];
    const masteredConsolidatedWords: (WordData & { srs: SrsItem })[] = [];

    let totalRetention = 0;
    let criticalCount = 0;
    let fadingCount = 0;
    let stableCount = 0;

    allWithSrs.forEach(item => {
      totalRetention += item.srs.retentionScore;

      if (item.srs.retentionScore < 50) criticalCount++;
      else if (item.srs.retentionScore < 80) fadingCount++;
      else stableCount++;

      if (this.isDue(item.srs, nowMs)) {
        dueWords.push(item);
      } else if (item.srs.stage >= 5) {
        masteredConsolidatedWords.push(item);
      } else {
        upcomingWords.push(item);
      }
    });

    // Sort due words: lowest retention first (most urgent memory decay first!)
    dueWords.sort((a, b) => a.srs.retentionScore - b.srs.retentionScore);

    // Sort upcoming words: closest review date first
    upcomingWords.sort((a, b) => {
      return new Date(a.srs.nextReviewAt).getTime() - new Date(b.srs.nextReviewAt).getTime();
    });

    const averageRetention = allWithSrs.length > 0 ? Math.round(totalRetention / allWithSrs.length) : 100;

    return {
      dueWords,
      upcomingWords,
      masteredConsolidatedWords,
      stats: {
        totalTracked: allWithSrs.length,
        dueCount: dueWords.length,
        averageRetention,
        retentionDistribution: {
          critical: criticalCount,
          fading: fadingCount,
          stable: stableCount,
        },
      },
    };
  }

  /**
   * Helper to format human-friendly interval strings.
   */
  public static formatInterval(days: number): string {
    if (days < 1) {
      const hours = Math.round(days * 24);
      return `${hours} hr${hours !== 1 ? 's' : ''}`;
    }
    if (days < 7) {
      const d = Math.round(days);
      return `${d} day${d !== 1 ? 's' : ''}`;
    }
    if (days < 30) {
      const w = Math.round(days / 7);
      return `${w} week${w !== 1 ? 's' : ''}`;
    }
    const m = Math.round(days / 30);
    return `${m} mo${m !== 1 ? 's' : ''}`;
  }
}
