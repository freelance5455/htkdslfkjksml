import { supabase } from '../lib/supabase';
import { Profile } from '../types';

export interface StatusStory {
  id: string;
  user_id: string;
  media_type: 'image' | 'video' | 'text';
  content?: string | null;
  media_url?: string | null;
  background_color?: string | null;
  caption?: string | null;
  created_at: string;
  expires_at: string;
  privacy: 'friends' | 'selected' | 'nobody';
  selected_friends?: string[];
  user: Profile;
  views: {
    user_id: string;
    viewed_at: string;
    user: Profile;
  }[];
}

export async function getStatuses(): Promise<StatusStory[]> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) return [];

  try {
    const res = await fetch('/api/status', {
      headers: {
        Authorization: `Bearer ${session.access_token}`,
      },
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('Failed to fetch statuses:', err);
  }
  return [];
}

export async function createStatus(params: {
  mediaType: 'text' | 'image' | 'video';
  content?: string;
  mediaUrl?: string;
  backgroundColor?: string;
  caption?: string;
  privacy?: 'friends' | 'selected' | 'nobody';
  selectedFriends?: string[];
}): Promise<StatusStory | null> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) return null;

  const res = await fetch('/api/status', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${session.access_token}`,
    },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to create status');
  }

  const created = await res.json();

  // Broadcast realtime status notification
  try {
    const globalChannel = supabase.channel('nexa-global-chat');
    globalChannel.send({
      type: 'broadcast',
      event: 'status_updated',
      payload: { userId: session.user.id },
    });
  } catch {}

  return created;
}

export async function recordStatusView(statusId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) return;

  try {
    await fetch(`/api/status/${statusId}/view`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${session.access_token}`,
      },
    });
  } catch {}
}

export async function deleteStatus(statusId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) return;

  const res = await fetch(`/api/status/${statusId}`, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${session.access_token}`,
    },
  });

  if (!res.ok) {
    throw new Error('Failed to delete status');
  }

  // Broadcast realtime status notification
  try {
    const globalChannel = supabase.channel('nexa-global-chat');
    globalChannel.send({
      type: 'broadcast',
      event: 'status_updated',
      payload: { statusId },
    });
  } catch {}
}
