/**
 * GODEX v0.0.1 - Diff Engine
 * Computes line-by-line diffs, additions, deletions, and formatted patch structures.
 */

export interface DiffLine {
  type: 'added' | 'removed' | 'unchanged';
  oldLineNumber?: number;
  newLineNumber?: number;
  content: string;
}

export interface FileDiffResult {
  filePath: string;
  additions: number;
  deletions: number;
  lines: DiffLine[];
  hasChanges: boolean;
}

export function computeLineDiff(original: string, modified: string, filePath: string = 'workspace-file'): FileDiffResult {
  const oldLines = original.split('\n');
  const newLines = modified.split('\n');
  
  const lines: DiffLine[] = [];
  let additions = 0;
  let deletions = 0;

  // Simple and robust LCS-inspired diff algorithm
  let oldIdx = 0;
  let newIdx = 0;

  while (oldIdx < oldLines.length || newIdx < newLines.length) {
    if (oldIdx < oldLines.length && newIdx < newLines.length) {
      if (oldLines[oldIdx] === newLines[newIdx]) {
        lines.push({
          type: 'unchanged',
          oldLineNumber: oldIdx + 1,
          newLineNumber: newIdx + 1,
          content: oldLines[oldIdx]
        });
        oldIdx++;
        newIdx++;
      } else {
        // Look ahead in newLines to see if oldLines[oldIdx] appears later
        const foundInNew = newLines.slice(newIdx, newIdx + 5).indexOf(oldLines[oldIdx]);
        // Look ahead in oldLines to see if newLines[newIdx] appears later
        const foundInOld = oldLines.slice(oldIdx, oldIdx + 5).indexOf(newLines[newIdx]);

        if (foundInNew !== -1 && (foundInOld === -1 || foundInNew <= foundInOld)) {
          // New lines were inserted
          for (let i = 0; i < foundInNew; i++) {
            lines.push({
              type: 'added',
              newLineNumber: newIdx + 1,
              content: newLines[newIdx]
            });
            additions++;
            newIdx++;
          }
        } else if (foundInOld !== -1) {
          // Old lines were deleted
          for (let i = 0; i < foundInOld; i++) {
            lines.push({
              type: 'removed',
              oldLineNumber: oldIdx + 1,
              content: oldLines[oldIdx]
            });
            deletions++;
            oldIdx++;
          }
        } else {
          // One line replaced
          lines.push({
            type: 'removed',
            oldLineNumber: oldIdx + 1,
            content: oldLines[oldIdx]
          });
          deletions++;
          oldIdx++;

          lines.push({
            type: 'added',
            newLineNumber: newIdx + 1,
            content: newLines[newIdx]
          });
          additions++;
          newIdx++;
        }
      }
    } else if (oldIdx < oldLines.length) {
      lines.push({
        type: 'removed',
        oldLineNumber: oldIdx + 1,
        content: oldLines[oldIdx]
      });
      deletions++;
      oldIdx++;
    } else if (newIdx < newLines.length) {
      lines.push({
        type: 'added',
        newLineNumber: newIdx + 1,
        content: newLines[newIdx]
      });
      additions++;
      newIdx++;
    }
  }

  return {
    filePath,
    additions,
    deletions,
    lines,
    hasChanges: additions > 0 || deletions > 0
  };
}

export function formatUnifiedDiff(original: string, modified: string, filePath: string = 'workspace-file'): string {
  const diffResult = computeLineDiff(original, modified, filePath);
  if (!diffResult.hasChanges) return `--- a/${filePath}\n+++ b/${filePath}\n@@ No changes @@`;

  const header = `--- a/${filePath}\n+++ b/${filePath}\n@@ -1,${original.split('\n').length} +1,${modified.split('\n').length} @@\n`;
  const body = diffResult.lines.map(line => {
    if (line.type === 'added') return `+ ${line.content}`;
    if (line.type === 'removed') return `- ${line.content}`;
    return `  ${line.content}`;
  }).join('\n');

  return header + body;
}

export const DiffEngine = {
  computeLineDiff,
  computeDiff: computeLineDiff,
  formatUnifiedDiff
};
