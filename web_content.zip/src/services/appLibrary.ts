import { AppTaskItem } from '../types';

export const TOTAL_APP_CATALOG_COUNT = 100000;

export const APP_CATEGORIES = [
  'All',
  'Crypto & Web3',
  'AI & Productivity',
  'Gaming & Esports',
  'Social & Media',
  'Fintech & Pay',
  'Shopping & Deals'
];

export const BASE_APP_RESOURCES = [
  // --- CRYPTO & WEB3 ---
  {
    name: 'Binance: Web3 & Crypto Trading',
    developer: 'Binance Global Inc',
    category: 'Crypto & Web3',
    iconUrl: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 58,
    downloads: '100M+',
    baseReward: 250,
    description: 'World-leading crypto exchange and non-custodial Web3 wallet with instant P2P payments and zero-fee swaps.',
    surveyQuestions: [
      {
        question: 'How fast was your P2P payment settlement response time?',
        options: ['Under 2 minutes (Instant)', '3-5 minutes', 'Over 10 minutes']
      },
      {
        question: 'Which Web3 feature do you use most frequently?',
        options: ['Spot & Futures trading', 'DeFi Staking & Yield', 'P2P bank transfers', 'Cross-chain bridging']
      }
    ]
  },
  {
    name: 'Trust Wallet: Crypto & Bitcoin',
    developer: 'Trust Wallet Tech',
    category: 'Crypto & Web3',
    iconUrl: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 44,
    downloads: '70M+',
    baseReward: 220,
    description: 'Secure multi-chain decentralized crypto wallet supporting Solana, Ethereum, BSC, Bitcoin, and Polygon.',
    surveyQuestions: [
      {
        question: 'How clear did you find the multi-chain gas fee estimation?',
        options: ['Extremely clear and low fee', 'Average', 'Too high or confusing']
      },
      {
        question: 'Do you prefer biometric FaceID login for signing transactions?',
        options: ['Yes, always enabled', 'Prefer PIN password', 'Hardware token only']
      }
    ]
  },
  {
    name: 'MetaMask: DeFi & DApps Gateway',
    developer: 'Consensys Software',
    category: 'Crypto & Web3',
    iconUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=128&q=80',
    rating: 4.6,
    sizeMb: 36,
    downloads: '50M+',
    baseReward: 190,
    description: 'The premier self-custodial wallet and Web3 browser to connect with decentralized finance and NFT platforms.',
    surveyQuestions: [
      {
        question: 'How seamless was connecting to decentralized apps (DApps)?',
        options: ['One-click instant connection', 'Took multiple attempts', 'Connection failed']
      },
      {
        question: 'Which Layer 2 network do you use most often?',
        options: ['Arbitrum / Optimism', 'Polygon PoS', 'Base network', 'Ethereum Mainnet']
      }
    ]
  },
  {
    name: 'CoinDCX: Bitcoin Crypto App',
    developer: 'CoinDCX India',
    category: 'Crypto & Web3',
    iconUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 32,
    downloads: '15M+',
    baseReward: 180,
    description: 'Compliant Indian crypto exchange with instant INR deposits via UPI and automated crypto SIP investment.',
    surveyQuestions: [
      {
        question: 'How fast was INR deposit reflection via UPI?',
        options: ['Immediate (<30s)', '1-2 minutes', 'Delayed']
      },
      {
        question: 'Are you interested in automated daily crypto SIPs?',
        options: ['Yes, actively investing', 'Considering in future', 'No, only one-time buy']
      }
    ]
  },

  // --- AI & PRODUCTIVITY ---
  {
    name: 'ChatGPT Voice & Vision AI',
    developer: 'OpenAI Technologies',
    category: 'AI & Productivity',
    iconUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
    rating: 4.9,
    sizeMb: 48,
    downloads: '100M+',
    baseReward: 240,
    description: 'Real-time conversational voice assistant, instant photo analysis, creative coding, and smart problem solving.',
    surveyQuestions: [
      {
        question: 'How natural and responsive did the voice conversation feel?',
        options: ['Near human-like with zero delay', 'Good but minor pauses', 'Robotic or slow']
      },
      {
        question: 'What is your primary use case for ChatGPT?',
        options: ['Writing & content creation', 'Coding & debugging', 'Study & research', 'Daily task planning']
      }
    ]
  },
  {
    name: 'Perplexity: Conversational Search AI',
    developer: 'Perplexity AI Inc',
    category: 'AI & Productivity',
    iconUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=128&q=80',
    rating: 4.9,
    sizeMb: 35,
    downloads: '20M+',
    baseReward: 210,
    description: 'Where knowledge begins. Direct cited answers, academic research synthesis, and live web search grounding.',
    surveyQuestions: [
      {
        question: 'Did the source citations accurately back up the answer given?',
        options: ['100% verified citations', 'Mostly accurate', 'Could not verify sources']
      },
      {
        question: 'How does Perplexity compare to traditional Google search?',
        options: ['Much faster & saves time', 'About the same', 'Prefer standard search links']
      }
    ]
  },
  {
    name: 'Notion: Connected AI Workspace',
    developer: 'Notion Labs Inc',
    category: 'AI & Productivity',
    iconUrl: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 52,
    downloads: '50M+',
    baseReward: 195,
    description: 'Unified documents, roadmaps, task boards, and AI autofill for personal productivity and team projects.',
    surveyQuestions: [
      {
        question: 'Did Notion AI assist effectively in summarizing your notes?',
        options: ['Exceptional summarization', 'Satisfactory', 'Needs more detail']
      },
      {
        question: 'Which view format do you use most in your databases?',
        options: ['Kanban Board', 'Calendar / Timeline', 'Table spreadsheet', 'Gallery cards']
      }
    ]
  },
  {
    name: 'Canva: Design, AI Photo & Video',
    developer: 'Canva Pty Ltd',
    category: 'AI & Productivity',
    iconUrl: 'https://images.unsplash.com/photo-1542744094-3a31f272c490?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 62,
    downloads: '100M+',
    baseReward: 185,
    description: 'Generate stunning social media thumbnails, logos, presentations, and AI magic design in seconds.',
    surveyQuestions: [
      {
        question: 'How easy was it to remove image backgrounds with Magic Eraser?',
        options: ['Instant one-click perfection', 'Good with minor artifacts', 'Slow processing']
      },
      {
        question: 'What do you create most frequently with Canva?',
        options: ['YouTube thumbnails / Reels', 'Business presentations', 'Flyers & Posters', 'Resume / CV']
      }
    ]
  },

  // --- GAMING & ESPORTS ---
  {
    name: 'WinZO: Real Money Esports & Games',
    developer: 'WinZO Games Pvt Ltd',
    category: 'Gaming & Esports',
    iconUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 68,
    downloads: '100M+',
    baseReward: 260,
    description: 'Play 100+ popular games including Ludo, Rummy, Fruit Samurai, and World War with instant UPI withdrawals.',
    surveyQuestions: [
      {
        question: 'How fast was real-time player matchmaking in tournaments?',
        options: ['Instant (<3 seconds)', '5-10 seconds', 'Long matchmaking wait']
      },
      {
        question: 'Which game format gives you the highest winning confidence?',
        options: ['Ludo Supreme', 'Rummy / Card battles', 'Speed Fruit Chop', 'Esports Tournaments']
      }
    ]
  },
  {
    name: 'Battlegrounds Mobile India (BGMI)',
    developer: 'Krafton India',
    category: 'Gaming & Esports',
    iconUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=128&q=80',
    rating: 4.6,
    sizeMb: 95,
    downloads: '100M+',
    baseReward: 230,
    description: 'Premier mobile battle royale action with high-stakes 100-player drops, Erangel tactical maps, and esports leagues.',
    surveyQuestions: [
      {
        question: 'How stable was your ping / network latency during team firefights?',
        options: ['Ultra-low ping (<30ms)', 'Moderate (40-70ms)', 'High ping or stutter (>100ms)']
      },
      {
        question: 'Do you participate in ranked esports scrims or casual lobbies?',
        options: ['Ranked Conqueror push', 'Casual with friends', 'Esports scrim tournaments']
      }
    ]
  },
  {
    name: 'MPL Pro: Esports Cricket & Games',
    developer: 'Mobile Premier League',
    category: 'Gaming & Esports',
    iconUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=128&q=80',
    rating: 4.6,
    sizeMb: 72,
    downloads: '90M+',
    baseReward: 220,
    description: 'Compete in fantasy cricket leagues, 8-ball pool, carrom clash, and arcade games for daily cash prize pools.',
    surveyQuestions: [
      {
        question: 'How intuitive did you find the fantasy team selection screen?',
        options: ['Very intuitive & rich stats', 'Standard', 'Too cluttered']
      },
      {
        question: 'Which payout method do you prefer for gaming prize withdrawals?',
        options: ['Instant UPI (PhonePe / GPay)', 'Bank NEFT', 'Amazon Pay gift card']
      }
    ]
  },
  {
    name: 'Free Fire MAX: Battle Royale',
    developer: 'Garena International',
    category: 'Gaming & Esports',
    iconUrl: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=128&q=80',
    rating: 4.5,
    sizeMb: 88,
    downloads: '100M+',
    baseReward: 200,
    description: 'High-definition 50-player battle royale with ultra-smooth weapon mechanics and exclusive Bermuda maps.',
    surveyQuestions: [
      {
        question: 'How was the HD visual quality on your device display?',
        options: ['Crisp Ultra HD 60fps', 'Smooth standard quality', 'Stutters occasionally']
      },
      {
        question: 'What is your favorite weapon loadout combination?',
        options: ['AR + Shotgun rush', 'Sniper + SMG', 'Dual Pistols + Grenades']
      }
    ]
  },

  // --- SOCIAL & MEDIA ---
  {
    name: 'Telegram: Web3 & Channels',
    developer: 'Telegram FZ-LLC',
    category: 'Social & Media',
    iconUrl: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 42,
    downloads: '1B+',
    baseReward: 210,
    description: 'Fast, secure messaging with unlimited cloud storage, Web3 Mini App bots, TON wallet, and broadcast channels.',
    surveyQuestions: [
      {
        question: 'Do you use Telegram Mini App bots to earn crypto or rewards?',
        options: ['Yes, play daily bots', 'Occasionally', 'Never used mini apps']
      },
      {
        question: 'What do you appreciate most about Telegram?',
        options: ['Large files & cloud storage', 'Bot ecosystem & Web3', 'Group privacy controls', 'Voice & video rooms']
      }
    ]
  },
  {
    name: 'Discord: Communities & Voice Chat',
    developer: 'Discord Inc',
    category: 'Social & Media',
    iconUrl: 'https://images.unsplash.com/photo-1614680376593-902f749f7ffc?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 56,
    downloads: '500M+',
    baseReward: 190,
    description: 'Low-latency crystal-clear voice chat, custom community servers, screen sharing, and gamer hangout channels.',
    surveyQuestions: [
      {
        question: 'How was the audio quality during multiplayer voice calls?',
        options: ['Studio quality with noise cancel', 'Standard', 'Occasional robot voice']
      },
      {
        question: 'Are you a member of any earning or coding community servers?',
        options: ['Yes, multiple tech/earning servers', 'Only gaming servers', 'Private friend groups only']
      }
    ]
  },
  {
    name: 'X (Twitter): Live News & Creators',
    developer: 'X Corp',
    category: 'Social & Media',
    iconUrl: 'https://images.unsplash.com/photo-1611605698335-8b1569810432?auto=format&fit=crop&w=128&q=80',
    rating: 4.5,
    sizeMb: 38,
    downloads: '1B+',
    baseReward: 180,
    description: 'Real-time breaking world news, live audio Spaces, Grok AI integration, and creator ad-revenue sharing.',
    surveyQuestions: [
      {
        question: 'Do you find the algorithmic "For You" feed relevant to your interests?',
        options: ['Very relevant and up to date', 'Somewhat repetitive', 'Prefer chronological following']
      },
      {
        question: 'Have you attended or hosted audio Spaces discussions?',
        options: ['Regular listener', 'Hosted multiple spaces', 'Never joined spaces']
      }
    ]
  },
  {
    name: 'YouTube Studio: Creator Hub',
    developer: 'Google LLC',
    category: 'Social & Media',
    iconUrl: 'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 46,
    downloads: '500M+',
    baseReward: 200,
    description: 'Manage channel growth, track real-time audience analytics, respond to comments, and monitor monetization.',
    surveyQuestions: [
      {
        question: 'How useful are the real-time YouTube Shorts analytics insights?',
        options: ['Extremely useful for strategy', 'Helpful overview', 'Need deeper demographics']
      },
      {
        question: 'Do you actively publish content on YouTube Shorts?',
        options: ['Yes, post weekly Shorts', 'Planning to start soon', 'Viewer only']
      }
    ]
  },

  // --- FINTECH & PAY ---
  {
    name: 'BharatUPI FastPay 2.0',
    developer: 'Bharat Fintech Labs',
    category: 'Fintech & Pay',
    iconUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 24,
    downloads: '10M+',
    baseReward: 150,
    description: 'Ultra-fast UPI 2.0 payments, soundbox alerts, and zero-fee bank balance checks.',
    surveyQuestions: [
      {
        question: 'How fast was the QR code scanning response time?',
        options: ['Instant (<0.5s)', 'Moderate (1-2s)', 'Slow (>3s)']
      },
      {
        question: 'Which new feature would you like to see next?',
        options: ['Split bills with friends', 'Automated recurring SIPs', 'Crypto wallet link', 'Voice-guided payments']
      }
    ]
  },

  // --- SHOPPING & DEALS ---
  {
    name: 'LootBazaar Flash Deals',
    developer: 'Global E-Commerce Corp',
    category: 'Shopping & Deals',
    iconUrl: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 28,
    downloads: '12M+',
    baseReward: 140,
    description: 'Direct factory outlet shopping, 80% flash discounts, and cash-on-delivery tracking.',
    surveyQuestions: [
      {
        question: 'Did you easily find flash discount coupons during checkout?',
        options: ['Auto-applied successfully', 'Found manually', 'Could not find coupon code']
      },
      {
        question: 'What product category do you buy online most frequently?',
        options: ['Electronics & Gadgets', 'Fashion & Shoes', 'Groceries & Household', 'Fitness Gear']
      }
    ]
  }
];

export function getAppCatalog(
  page: number = 1,
  limit: number = 10,
  category: string = 'All',
  searchQuery: string = ''
): { apps: AppTaskItem[]; totalCount: number; hasMore: boolean } {
  const query = searchQuery.trim().toLowerCase();
  const allGenerated: AppTaskItem[] = [];

  const maxToGenerate = 400;

  for (let i = 0; i < maxToGenerate; i++) {
    const base = BASE_APP_RESOURCES[i % BASE_APP_RESOURCES.length];
    const versionNum = Math.floor(i / BASE_APP_RESOURCES.length) + 1;
    const cat = base.category;

    if (category !== 'All' && cat !== category) {
      continue;
    }

    const name = versionNum === 1 
      ? base.name 
      : `${base.name} Edition ${versionNum}`;

    if (query && !name.toLowerCase().includes(query) && !base.developer.toLowerCase().includes(query)) {
      continue;
    }

    const reward = Math.max(80, base.baseReward + ((i * 11) % 120));
    const rating = Math.min(5.0, Number((4.5 + ((i * 3) % 5) * 0.1).toFixed(1)));
    const size = Math.max(15, base.sizeMb + ((i * 5) % 40));

    allGenerated.push({
      id: `app-task-${i + 1}`,
      name,
      developer: base.developer,
      category: cat,
      iconUrl: base.iconUrl,
      rating,
      sizeMb: size,
      downloadsCount: base.downloads,
      rewardCoins: reward,
      description: base.description,
      surveyQuestions: base.surveyQuestions
    });
  }

  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + limit;
  const pagedApps = allGenerated.slice(startIndex, endIndex);

  return {
    apps: pagedApps,
    totalCount: TOTAL_APP_CATALOG_COUNT,
    hasMore: endIndex < allGenerated.length,
  };
}
