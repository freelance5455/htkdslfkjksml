import { Project, Clip, Keyframe } from '../types/editor';

// Helper to interpolate between two keyframes
function interpolateKeyframes(k1: Keyframe, k2: Keyframe, t: number): { x: number; y: number; scale: number; rotation: number; opacity: number } {
  const span = k2.time - k1.time;
  if (span <= 0) return { x: k1.x, y: k1.y, scale: k1.scale, rotation: k1.rotation, opacity: k1.opacity };
  const factor = Math.max(0, Math.min(1, (t - k1.time) / span));
  
  // Smooth ease-in-out
  const ease = factor < 0.5 ? 2 * factor * factor : -1 + (4 - 2 * factor) * factor;

  return {
    x: k1.x + (k2.x - k1.x) * ease,
    y: k1.y + (k2.y - k1.y) * ease,
    scale: k1.scale + (k2.scale - k1.scale) * ease,
    rotation: k1.rotation + (k2.rotation - k1.rotation) * ease,
    opacity: k1.opacity + (k2.opacity - k1.opacity) * ease,
  };
}

// Scale CSS filter parameters by intensity factor (0 - 100%)
export function parseAndScaleFilter(cssFilter: string, intensity: number = 85): string {
  if (!cssFilter || typeof cssFilter !== 'string') return '';
  const f = Math.max(0, Math.min(1, intensity / 100));
  if (f === 0) return '';

  return cssFilter.replace(/([a-zA-Z\-]+)\(([^)]+)\)/g, (match, name, value) => {
    const num = parseFloat(value);
    if (isNaN(num)) return match;

    if (name === 'contrast' || name === 'saturate' || name === 'brightness') {
      const delta = num - 100;
      const scaled = 100 + delta * f;
      return `${name}(${scaled.toFixed(1)}%)`;
    } else if (name === 'sepia' || name === 'grayscale' || name === 'invert') {
      const scaled = num * f;
      return `${name}(${scaled.toFixed(1)}%)`;
    } else if (name === 'hue-rotate') {
      const scaled = num * f;
      return `${name}(${scaled.toFixed(1)}deg)`;
    }
    return match;
  });
}

// Media cache to prevent duplicate element creation and safely manage buffering
export class MediaCache {
  private videoElements: Map<string, HTMLVideoElement> = new Map();
  private imageElements: Map<string, HTMLImageElement> = new Map();

  getVideo(url: string): HTMLVideoElement | null {
    if (!url || typeof url !== 'string' || url.trim() === '') return null;
    if (!this.videoElements.has(url)) {
      try {
        const vid = document.createElement('video');
        vid.crossOrigin = 'anonymous';
        vid.src = url;
        vid.muted = true;
        vid.preload = 'auto';
        vid.playsInline = true;
        this.videoElements.set(url, vid);
      } catch (e) {
        return null;
      }
    }
    return this.videoElements.get(url) || null;
  }

  getImage(url: string): HTMLImageElement | null {
    if (!url || typeof url !== 'string' || url.trim() === '') return null;
    if (!this.imageElements.has(url)) {
      try {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = url;
        this.imageElements.set(url, img);
      } catch (e) {
        return null;
      }
    }
    return this.imageElements.get(url) || null;
  }

  pauseAllVideos() {
    this.videoElements.forEach(v => {
      try {
        if (!v.paused) v.pause();
      } catch (e) {}
    });
  }

  pauseInactiveVideos(activeUrls: Set<string>) {
    this.videoElements.forEach((v, url) => {
      if (!activeUrls.has(url)) {
        try {
          if (!v.paused) v.pause();
        } catch (e) {}
      }
    });
  }

  cleanup() {
    this.videoElements.forEach(v => {
      try {
        v.pause();
        v.src = '';
      } catch (e) {}
    });
    this.videoElements.clear();
    this.imageElements.clear();
  }
}

export const mediaCache = new MediaCache();

export class VideoRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private tempCanvas: HTMLCanvasElement;
  private tempCtx: CanvasRenderingContext2D;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { willReadFrequently: true })!;
    this.tempCanvas = document.createElement('canvas');
    this.tempCtx = this.tempCanvas.getContext('2d', { willReadFrequently: true })!;
  }

  // Set resolution
  setSize(width: number, height: number) {
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
    }
    if (this.tempCanvas.width !== width || this.tempCanvas.height !== height) {
      this.tempCanvas.width = width;
      this.tempCanvas.height = height;
    }
  }

  // Main render pass at a specific time
  renderFrame(
    project: Project,
    currentTime: number,
    isPremium: boolean,
    scaleMultiplier: number = 1.0,
    isPlaying: boolean = false
  ) {
    const { width, height } = this.canvas;
    const ctx = this.ctx;

    ctx.save();
    ctx.clearRect(0, 0, width, height);

    // 1. Draw Background
    this.drawBackground(project, width, height);

    // 2. Identify visible tracks in order
    const visibleTracks = project.tracks.filter(t => t.visible);
    const activeVideoUrls = new Set<string>();

    for (const track of visibleTracks) {
      const activeClips = project.clips.filter(c => 
        c.trackId === track.id && 
        currentTime >= c.start && 
        currentTime < (c.start + c.duration)
      );

      for (const clip of activeClips) {
        if (clip.type === 'video' && clip.sourceUrl) {
          activeVideoUrls.add(clip.sourceUrl);
        }
        this.renderClip(clip, currentTime, width, height, project, isPlaying);
      }
    }

    // Pause any video elements not currently on screen
    mediaCache.pauseInactiveVideos(activeVideoUrls);

    // No watermark: 100% clean video export & preview
    ctx.restore();
  }

  private drawBackground(project: Project, width: number, height: number) {
    const ctx = this.ctx;
    const bg = project.background;

    if (bg.type === 'color') {
      ctx.fillStyle = bg.color || '#000000';
      ctx.fillRect(0, 0, width, height);
    } else if (bg.type === 'gradient' && bg.gradient) {
      const rad = (bg.gradient.angle || 0) * (Math.PI / 180);
      const x2 = Math.cos(rad) * width;
      const y2 = Math.sin(rad) * height;
      const grad = ctx.createLinearGradient(0, 0, x2, y2);
      grad.addColorStop(0, bg.gradient.start);
      grad.addColorStop(1, bg.gradient.end);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    } else {
      ctx.fillStyle = '#0a0a0c';
      ctx.fillRect(0, 0, width, height);
    }
  }

  private renderClip(
    clip: Clip,
    currentTime: number,
    width: number,
    height: number,
    project: Project,
    isPlaying: boolean = false
  ) {
    const ctx = this.ctx;
    const timeInClip = (currentTime - clip.start) * clip.speed;

    // Calculate transforms (keyframes interpolation or base transforms)
    let { x, y, scale, rotation, opacity } = clip;
    if (clip.keyframes && clip.keyframes.length > 0) {
      const sorted = [...clip.keyframes].sort((a, b) => a.time - b.time);
      if (timeInClip <= sorted[0].time) {
        x = sorted[0].x;
        y = sorted[0].y;
        scale = sorted[0].scale;
        rotation = sorted[0].rotation;
        opacity = sorted[0].opacity;
      } else if (timeInClip >= sorted[sorted.length - 1].time) {
        const last = sorted[sorted.length - 1];
        x = last.x;
        y = last.y;
        scale = last.scale;
        rotation = last.rotation;
        opacity = last.opacity;
      } else {
        for (let i = 0; i < sorted.length - 1; i++) {
          if (timeInClip >= sorted[i].time && timeInClip <= sorted[i + 1].time) {
            const interpolated = interpolateKeyframes(sorted[i], sorted[i + 1], timeInClip);
            x = interpolated.x;
            y = interpolated.y;
            scale = interpolated.scale;
            rotation = interpolated.rotation;
            opacity = interpolated.opacity;
            break;
          }
        }
      }
    }

    // Apply Fade In / Fade Out
    const clipProgress = currentTime - clip.start;
    const clipRemaining = (clip.start + clip.duration) - currentTime;
    if (clip.fadeIn > 0 && clipProgress < clip.fadeIn) {
      opacity *= Math.max(0, clipProgress / clip.fadeIn);
    }
    if (clip.fadeOut > 0 && clipRemaining < clip.fadeOut) {
      opacity *= Math.max(0, clipRemaining / clip.fadeOut);
    }

    ctx.save();
    ctx.globalAlpha = Math.max(0, Math.min(1, isFinite(opacity) ? opacity : 1));
    ctx.globalCompositeOperation = (clip.blendMode || 'normal') as GlobalCompositeOperation;

    // Center offset
    const safeX = isFinite(x) ? x : 0;
    const safeY = isFinite(y) ? y : 0;
    const centerX = (width / 2) + (safeX / 100) * width;
    const centerY = (height / 2) + (safeY / 100) * height;

    ctx.translate(centerX, centerY);
    ctx.rotate(((isFinite(rotation) ? rotation : 0) * Math.PI) / 180);
    const safeScale = isFinite(scale) && scale > 0 ? scale : 1;
    ctx.scale(safeScale * (clip.flipH ? -1 : 1), safeScale * (clip.flipV ? -1 : 1));

    // Handle different clip types
    if (clip.type === 'video' || clip.type === 'image') {
      this.drawMediaClip(clip, timeInClip, width, height, isPlaying);
    } else if (clip.type === 'text') {
      this.drawTextClip(clip, timeInClip, width, height);
    } else if (clip.type === 'sticker') {
      this.drawStickerClip(clip, timeInClip, width, height);
    }

    ctx.restore();
  }

  private drawMediaClip(
    clip: Clip,
    timeInClip: number,
    canvasWidth: number,
    canvasHeight: number,
    isPlaying: boolean = false
  ) {
    if (!clip.sourceUrl) return;
    const ctx = this.ctx;
    const sourceTime = clip.sourceStart + (isFinite(timeInClip) ? timeInClip : 0);

    let mediaElement: HTMLVideoElement | HTMLImageElement | null = null;
    let isVideoElement = false;

    if (clip.type === 'video') {
      const vid = mediaCache.getVideo(clip.sourceUrl);
      if (vid) {
        isVideoElement = true;
        if (isFinite(sourceTime) && vid.readyState >= 1) {
          const maxDur = isFinite(vid.duration) && vid.duration > 0 ? vid.duration : 999;
          const targetTime = Math.max(0, Math.min(maxDur, sourceTime));

          if (isPlaying) {
            // Silky-Smooth hardware-accelerated playback
            const desiredRate = clip.speed || 1.0;
            if (vid.playbackRate !== desiredRate) {
              vid.playbackRate = desiredRate;
            }
            if (vid.paused) {
              vid.play().catch(() => {});
            }
            // Only resync if video has drifted substantially (> 0.28s) to eliminate seeking stutter!
            if (Math.abs(vid.currentTime - targetTime) > 0.28) {
              try {
                vid.currentTime = targetTime;
              } catch (err) {}
            }
          } else {
            // Paused mode: pause video element and seek to exact current frame
            if (!vid.paused) {
              vid.pause();
            }
            if (Math.abs(vid.currentTime - targetTime) > 0.03) {
              try {
                vid.currentTime = targetTime;
              } catch (err) {}
            }
          }
        }
        mediaElement = vid;
      } else {
        mediaElement = mediaCache.getImage(clip.sourceUrl);
      }
    } else {
      mediaElement = mediaCache.getImage(clip.sourceUrl);
    }

    if (!mediaElement) return;

    let mediaWidth = 0;
    let mediaHeight = 0;

    if (isVideoElement && mediaElement instanceof HTMLVideoElement) {
      if (mediaElement.readyState >= 2 && mediaElement.videoWidth > 0 && mediaElement.videoHeight > 0) {
        mediaWidth = mediaElement.videoWidth;
        mediaHeight = mediaElement.videoHeight;
      } else {
        // Video frame is buffering: try image cache or render clean dark card
        const img = mediaCache.getImage(clip.sourceUrl);
        if (img && img.complete && img.naturalWidth > 0) {
          mediaElement = img;
          mediaWidth = img.naturalWidth;
          mediaHeight = img.naturalHeight;
          isVideoElement = false;
        } else {
          ctx.fillStyle = '#18181b';
          ctx.fillRect(-canvasWidth * 0.4, -canvasHeight * 0.4, canvasWidth * 0.8, canvasHeight * 0.8);
          return;
        }
      }
    } else if (mediaElement instanceof HTMLImageElement) {
      if (mediaElement.complete && mediaElement.naturalWidth > 0) {
        mediaWidth = mediaElement.naturalWidth;
        mediaHeight = mediaElement.naturalHeight;
      } else {
        return;
      }
    }

    if (!mediaWidth || !mediaHeight) {
      mediaWidth = canvasWidth;
      mediaHeight = canvasHeight;
    }

    // Calculate aspect fit
    const aspect = mediaWidth / mediaHeight;
    let targetW = canvasWidth;
    let targetH = canvasWidth / aspect;

    if (targetH > canvasHeight) {
      targetH = canvasHeight;
      targetW = canvasHeight * aspect;
    }

    // Build CSS Filter string combining adjustments and filter preset
    const filters: string[] = [];
    const adj = clip.adjustments;

    if (adj) {
      if (adj.brightness !== 0) filters.push(`brightness(${100 + adj.brightness}%)`);
      if (adj.contrast !== 0) filters.push(`contrast(${100 + adj.contrast}%)`);
      if (adj.saturation !== 0) filters.push(`saturate(${100 + adj.saturation}%)`);
      if (adj.hue !== 0) filters.push(`hue-rotate(${adj.hue}deg)`);
      if (adj.temperature > 0) filters.push(`sepia(${adj.temperature * 0.4}%)`);
    }

    if (clip.filter && clip.filter.cssFilter) {
      const scaled = parseAndScaleFilter(clip.filter.cssFilter, clip.filter.intensity ?? 85);
      if (scaled) {
        filters.push(scaled);
      }
    }

    const filterStr = filters.length > 0 ? filters.join(' ') : 'none';
    try {
      ctx.filter = filterStr;
    } catch (e) {
      ctx.filter = 'none';
    }

    // Chroma key handling
    try {
      if (clip.chromaKey && clip.chromaKey.enabled) {
        this.drawChromaKey(mediaElement, targetW, targetH, clip.chromaKey);
      } else {
        ctx.drawImage(mediaElement, -targetW / 2, -targetH / 2, targetW, targetH);
      }
    } catch (e) {
      // Gracefully ignore frame draw exception
    }

    ctx.filter = 'none';

    // Apply Visual Effects on top
    if (clip.effects && clip.effects.length > 0) {
      for (const eff of clip.effects) {
        this.applyEffect(eff, targetW, targetH, timeInClip);
      }
    }

    // Apply Vignette / Grain if set in adjustments
    if (adj && adj.vignette > 0) {
      this.drawVignette(targetW, targetH, adj.vignette);
    }
  }

  // Chroma Key Processing (Native Non-AI RGB Euclidean distance)
  private drawChromaKey(mediaElement: CanvasImageSource, width: number, height: number, chroma: { color: string; similarity: number; smoothness: number }) {
    try {
      this.tempCanvas.width = width;
      this.tempCanvas.height = height;
      const tCtx = this.tempCtx;
      tCtx.clearRect(0, 0, width, height);
      tCtx.drawImage(mediaElement, 0, 0, width, height);

      const imgData = tCtx.getImageData(0, 0, width, height);
      const data = imgData.data;

      // Parse hex color
      const hex = chroma.color.replace('#', '');
      const keyR = parseInt(hex.substring(0, 2), 16) || 0;
      const keyG = parseInt(hex.substring(2, 4), 16) || 255;
      const keyB = parseInt(hex.substring(4, 6), 16) || 0;

      const simThreshold = (chroma.similarity / 100) * 200;
      const smoothness = (chroma.smoothness / 100) * 100;

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];

        const diff = Math.sqrt((r - keyR) ** 2 + (g - keyG) ** 2 + (b - keyB) ** 2);

        if (diff < simThreshold) {
          data[i + 3] = 0; // transparent
        } else if (diff < simThreshold + smoothness) {
          const factor = (diff - simThreshold) / smoothness;
          data[i + 3] = Math.floor(data[i + 3] * factor);
        }
      }

      tCtx.putImageData(imgData, 0, 0);
      this.ctx.drawImage(this.tempCanvas, -width / 2, -height / 2, width, height);
    } catch (e) {
      // Graceful fallback
    }
  }

  private applyEffect(effect: { type: string; intensity: number; speed: number }, width: number, height: number, time: number) {
    const ctx = this.ctx;
    const intensity = (effect.intensity || 50) / 100;
    const t = (isFinite(time) ? time : 0) * ((effect.speed || 50) / 50);

    if (effect.type === 'shake') {
      const offsetX = Math.sin(t * 15) * 12 * intensity;
      const offsetY = Math.cos(t * 18) * 12 * intensity;
      ctx.translate(offsetX, offsetY);
    } else if (effect.type === 'vhs' || effect.type === 'scan_lines') {
      // Scan lines
      ctx.fillStyle = `rgba(0, 0, 0, ${0.25 * intensity})`;
      for (let y = -height / 2; y < height / 2; y += 4) {
        ctx.fillRect(-width / 2, y, width, 1.5);
      }
    } else if (effect.type === 'light_leak') {
      const grad = ctx.createRadialGradient(
        -width * 0.3 + Math.sin(t) * 50,
        -height * 0.3,
        10,
        -width * 0.2,
        -height * 0.2,
        width * 0.6
      );
      grad.addColorStop(0, `rgba(255, 180, 50, ${0.4 * intensity})`);
      grad.addColorStop(1, 'rgba(255, 100, 50, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(-width / 2, -height / 2, width, height);
    } else if (effect.type === 'grain') {
      // Random grain dots
      ctx.fillStyle = `rgba(255, 255, 255, ${0.1 * intensity})`;
      for (let i = 0; i < 200 * intensity; i++) {
        const gx = (Math.random() - 0.5) * width;
        const gy = (Math.random() - 0.5) * height;
        ctx.fillRect(gx, gy, 2, 2);
      }
    }
  }

  private drawVignette(width: number, height: number, vignetteAmt: number) {
    const ctx = this.ctx;
    const grad = ctx.createRadialGradient(0, 0, width * 0.25, 0, 0, width * 0.7);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, `rgba(0,0,0,${(vignetteAmt / 100) * 0.75})`);
    ctx.fillStyle = grad;
    ctx.fillRect(-width / 2, -height / 2, width, height);
  }

  private drawTextClip(clip: Clip, timeInClip: number, canvasWidth: number, canvasHeight: number) {
    const ctx = this.ctx;
    const textCfg = clip.textConfig;
    if (!textCfg || !textCfg.content) return;

    let textToDisplay = textCfg.content;
    if (textCfg.animation === 'typewriter') {
      const charsToShow = Math.floor((isFinite(timeInClip) ? timeInClip : 0) * 12);
      textToDisplay = textCfg.content.substring(0, Math.min(textCfg.content.length, charsToShow));
    }

    const fontSize = textCfg.fontSize * (canvasHeight / 720);
    const fontStyle = `${textCfg.italic ? 'italic ' : ''}${textCfg.bold ? 'bold ' : ''}${fontSize}px ${textCfg.fontFamily || 'sans-serif'}`;
    ctx.font = fontStyle;
    ctx.textAlign = textCfg.alignment || 'center';
    ctx.textBaseline = 'middle';

    const metrics = ctx.measureText(textToDisplay);
    const textW = metrics.width;
    const textH = fontSize * 1.2;

    // Draw background badge
    if (textCfg.background && textCfg.background.enabled) {
      const pad = textCfg.background.padding || 8;
      ctx.fillStyle = textCfg.background.color || '#000000';
      ctx.globalAlpha = textCfg.background.opacity || 0.6;
      ctx.beginPath();
      ctx.roundRect(-textW / 2 - pad, -textH / 2 - pad, textW + pad * 2, textH + pad * 2, textCfg.background.borderRadius || 6);
      ctx.fill();
      ctx.globalAlpha = 1.0;
    }

    // Shadow
    if (textCfg.shadow && textCfg.shadow.enabled) {
      ctx.shadowColor = textCfg.shadow.color;
      ctx.shadowBlur = textCfg.shadow.blur;
      ctx.shadowOffsetX = textCfg.shadow.offsetX;
      ctx.shadowOffsetY = textCfg.shadow.offsetY;
    }

    // Text Fill / Gradient
    if (textCfg.gradient && textCfg.gradient.enabled) {
      const grad = ctx.createLinearGradient(-textW / 2, 0, textW / 2, 0);
      grad.addColorStop(0, textCfg.gradient.start);
      grad.addColorStop(1, textCfg.gradient.end);
      ctx.fillStyle = grad;
    } else {
      ctx.fillStyle = textCfg.color || '#ffffff';
    }

    // Stroke
    if (textCfg.stroke && textCfg.stroke.enabled) {
      ctx.strokeStyle = textCfg.stroke.color;
      ctx.lineWidth = textCfg.stroke.width;
      ctx.strokeText(textToDisplay, 0, 0);
    }

    ctx.fillText(textToDisplay, 0, 0);
    ctx.shadowBlur = 0;
  }

  private drawStickerClip(clip: Clip, timeInClip: number, canvasWidth: number, canvasHeight: number) {
    const ctx = this.ctx;
    const cfg = clip.stickerConfig;
    if (!cfg) return;

    if (cfg.isCustomImage && cfg.emojiOrUrl) {
      const img = mediaCache.getImage(cfg.emojiOrUrl);
      if (img && img.complete && img.naturalWidth) {
        const size = canvasHeight * 0.2;
        try {
          ctx.drawImage(img, -size / 2, -size / 2, size, size);
        } catch (e) {}
      }
    } else {
      const size = canvasHeight * 0.15;
      ctx.font = `${size}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(cfg.emojiOrUrl || '⭐', 0, 0);
    }
  }
}
