/**
 * GODEX v0.0.2 - Capability Registry
 * Extensible manifest of supported languages, frameworks, runtimes,
 * testing systems, and execution environments.
 */

import { CapabilityDefinition } from '../types';

export const CAPABILITY_REGISTRY: CapabilityDefinition[] = [
  {
    id: 'react-typescript',
    name: 'React + TypeScript',
    category: 'frontend',
    supportLevel: 'native',
    description: 'Modern component-driven UI with TypeScript type safety, Hooks, and automatic JSX runtime.',
    supportedFileExtensions: ['.tsx', '.ts'],
    testRunner: 'vitest/jest'
  },
  {
    id: 'tailwind-css',
    name: 'Tailwind CSS',
    category: 'styling',
    supportLevel: 'native',
    description: 'Utility-first CSS styling framework with modern color palette and responsive breakpoint prefixes.',
    supportedFileExtensions: ['.css', '.tsx', '.jsx', '.html']
  },
  {
    id: 'lucide-icons',
    name: 'Lucide React Icons',
    category: 'styling',
    supportLevel: 'native',
    description: 'Clean and consistent icon pack dynamically rendered as pure scalable vector React components.',
    supportedFileExtensions: ['.tsx', '.jsx']
  },
  {
    id: 'javascript-esnext',
    name: 'JavaScript (ES2022+)',
    category: 'runtime',
    supportLevel: 'native',
    description: 'Modern JavaScript with async/await, optional chaining, nullish coalescing, and ES modules.',
    supportedFileExtensions: ['.js', '.mjs', '.jsx']
  },
  {
    id: 'html5-canvas',
    name: 'HTML5 Canvas & Web Audio API',
    category: 'frontend',
    supportLevel: 'native',
    description: 'Hardware-accelerated 2D graphics, physics simulations, particle visualizers, and synth audio.',
    supportedFileExtensions: ['.ts', '.tsx', '.js']
  },
  {
    id: 'node-express',
    name: 'Node.js Express Backend',
    category: 'backend',
    supportLevel: 'native',
    description: 'Server-side API routes, esbuild AST checks, Gemini function calling proxy, and sandbox endpoints.',
    supportedFileExtensions: ['.ts', '.js', '.json']
  },
  {
    id: 'termux-android',
    name: 'Termux Android Bridge',
    category: 'runtime',
    supportLevel: 'termux-executable',
    description: 'Local development environment on Android executing native Linux shell commands and packages.',
    supportedFileExtensions: ['.sh', '.py', '.js', '.ts']
  },
  {
    id: 'python-runtime',
    name: 'Python 3.x (via Termux/Sandbox)',
    category: 'runtime',
    supportLevel: 'termux-executable',
    description: 'Data processing scripts, CLI tools, and automated testing via Termux environment.',
    supportedFileExtensions: ['.py']
  }
];

export class CapabilityService {
  public static getAllCapabilities(): CapabilityDefinition[] {
    return CAPABILITY_REGISTRY;
  }

  public static getCapabilityById(id: string): CapabilityDefinition | undefined {
    return CAPABILITY_REGISTRY.find(c => c.id === id);
  }

  public static getCapabilitiesForFile(filePath: string): CapabilityDefinition[] {
    const ext = '.' + (filePath.split('.').pop() || '');
    return CAPABILITY_REGISTRY.filter(c => c.supportedFileExtensions.includes(ext));
  }

  public static isFileSupported(filePath: string): boolean {
    const ext = '.' + (filePath.split('.').pop() || '');
    return CAPABILITY_REGISTRY.some(c => c.supportedFileExtensions.includes(ext));
  }
}
