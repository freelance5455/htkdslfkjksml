import { AdminUser } from '../types';
import { APP_CONFIG } from '../config/appConfig';

/**
 * E SPORTS TOUR — Single Admin Architecture
 * Strictly exactly one authorized Super Admin (X SABBIR).
 * No Tournament Admin, Payment Admin, Support Admin, or additional administrator roles.
 */
export const SOLE_SUPER_ADMIN: AdminUser = {
  id: "admin_root_sabbir",
  name: "X SABBIR",
  email: "sksabbirh771@gmail.com",
  phone: APP_CONFIG.support.whatsappDisplay,
  role: "super_admin",
  status: "active",
  invitedBy: "System Genesis Bootstrapping (Sole App Owner)",
  invitedAt: "2026-08-01T00:00:00.000Z",
  lastLoginAt: new Date().toISOString(),
  mfaEnabled: true,
  isRootSuperAdmin: true // Strictly protects the sole owner X SABBIR
};

export const INITIAL_ADMIN_STAFF: AdminUser[] = [SOLE_SUPER_ADMIN];

/**
 * Server-Side Super Admin Genesis Initializer
 * Initializes the Super Admin securely on the server context without hardcoded credentials in the client.
 */
export const initializeServerSuperAdmin = (): {
  authorizedAdmin: AdminUser;
  sessionTokenHash: string;
  isGenesisComplete: boolean;
} => {
  // Ephemeral cryptographic session token hash generated dynamically
  const sessionTokenHash = `est_sec_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 9)}`;
  
  return {
    authorizedAdmin: SOLE_SUPER_ADMIN,
    sessionTokenHash,
    isGenesisComplete: true
  };
};

/**
 * Load admin staff ensuring strictly the single Super Admin exists.
 * Any legacy multi-admin accounts from previous versions are purged.
 */
export const loadAdminStaff = (): AdminUser[] => {
  // Enforce strictly exactly one Super Admin
  const singleAdminList = [SOLE_SUPER_ADMIN];
  localStorage.setItem('est_admin_staff_v3', JSON.stringify(singleAdminList));
  // Clean up legacy multi-admin key if present
  localStorage.removeItem('est_admin_staff_v2');
  return singleAdminList;
};
