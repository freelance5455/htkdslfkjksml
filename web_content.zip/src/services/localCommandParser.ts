/**
 * JARVIS Fast Response Pipeline: Local Command Parser
 * Instant millisecond execution for time (12-hour AM/PM), sunrise, sunset, date, weather,
 * battery, flashlight, app launcher, phone calls, WhatsApp, alarms, and blueprint scanner.
 */

import { Contact, BatteryStatus, WeatherData } from '../types';
import { timeService } from './timeService';

export interface LocalCommandResult {
  isLocal: boolean;
  reply: string;
  actionType?: 
    | 'time'
    | 'date'
    | 'sunrise'
    | 'sunset'
    | 'weather'
    | 'battery'
    | 'flashlight'
    | 'open_app'
    | 'call'
    | 'whatsapp'
    | 'set_alarm'
    | 'stop_alarm'
    | 'check_security'
    | 'open_blueprint_scanner'
    | 'stop_blueprint_scanner'
    | 'open_virtual_xray'
    | 'open_feature_builder'
    | 'open_auth'
    | 'trigger_emergency'
    | 'take_screenshot'
    | 'open_places'
    | 'open_device_recovery'
    | 'interrupt_task'
    | 'resume_task'
    | 'cancel_task'
    | 'wake'
    | 'stop_listening'
    | 'play_voice_sample'
    | 'save_memory'
    | 'delete_memory'
    | 'show_memory'
    | 'update_preference'
    | 'self_modify'
    | 'connect_device'
    | 'disconnect_device'
    | 'forget_device'
    | 'open_devices'
    | 'open_mission_control'
    | 'open_voice_settings';
  payload?: any;
}

// Convert "HH:mm" or ISO date to strictly 12-hour AM/PM format (e.g. 15:45 -> 3:45 PM, 06:32 -> 6:32 AM)
export function format12HourTime(input?: string | Date): string {
  if (!input) return '';
  if (input instanceof Date) {
    let hours = input.getHours();
    const minutes = input.getMinutes().toString().padStart(2, '0');
    const period = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${hours}:${minutes} ${period}`;
  }

  const str = String(input);
  if (str.includes('T')) {
    const timePart = str.split('T')[1];
    if (timePart) {
      const [h, m] = timePart.split(':');
      let hours = parseInt(h, 10);
      const period = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12 || 12;
      return `${hours}:${m.slice(0, 2)} ${period}`;
    }
  }

  if (/^\d{1,2}:\d{2}/.test(str)) {
    const [h, m] = str.split(':');
    let hours = parseInt(h, 10);
    const period = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${hours}:${m.slice(0, 2)} ${period}`;
  }

  return str;
}

export function parseLocalCommand(
  rawInput: string,
  context: {
    contacts: Contact[];
    battery: BatteryStatus;
    isFlashlightOn: boolean;
    activeAlarmRinging: boolean;
    weather?: WeatherData | null;
    userTimezone?: string;
    timezone?: string;
  }
): LocalCommandResult {
  const query = rawInput.trim().toLowerCase();

  // 1. ALARM STOP COMMANDS (Priority check - supports exact requested Hindi/Punjabi/English commands)
  const isAlarmStopPhrase = 
    query.includes('chup kar jao') ||
    query.includes('chup ho jao') ||
    query.includes('alarm band kar do') ||
    query.includes('alarm band karo') ||
    query.includes('stop alarm') ||
    query.includes('bas karo') ||
    query.includes('alarm band') ||
    query.includes('band karo alarm') ||
    query.includes('cancel alarm') ||
    (context.activeAlarmRinging && (query.includes('stop') || query.includes('band') || query.includes('off') || query.includes('shant')));

  if (isAlarmStopPhrase) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, अलार्म बंद कर दिया है।',
      actionType: 'stop_alarm',
    };
  }

  // 2. BLUEPRINT SCANNER STOP & START
  if (
    query.includes('stop scanning') ||
    query.includes('scan band') ||
    query.includes('blueprint band') ||
    query.includes('close scanner') ||
    query.includes('scanner band')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, स्कैनर बंद कर दिया गया है।',
      actionType: 'stop_blueprint_scanner',
    };
  }

  const blueprintTriggerKeywords = [
    'scan this object',
    'analyze this',
    'iska blueprint dikhao',
    'is engine ko analyze karo',
    'engine analyze',
    'blueprint dikhao',
    'blueprint scanner',
    'scan this',
    'scan karo',
    'object scan',
    'holographic scan',
    'vision scan',
    'optical scan',
  ];

  if (blueprintTriggerKeywords.some(kw => query.includes(kw))) {
    const isHindi = query.includes('dikhao') || query.includes('karo') || query.includes('iska') || query.includes('yeh');
    const isPunjabi = query.includes('dekho') || query.includes('dikhao') || query.includes('karo');
    const reply = isHindi
      ? 'जी Harman Sir, ब्लूप्रिंट स्कैनर शुरू कर दिया है। ऑब्जेक्ट को कैमरे के सामने रखें।'
      : isPunjabi
      ? 'ਹਾਂਜੀ Harman Sir, ਆਪਟੀਕਲ ਬਲੂਪ੍ਰਿੰਟ ਸਕੈਨਰ ਐਕਟੀਵੇਟ ਹੋ ਗਿਆ ਹੈ।'
      : 'Activating Iron Man Visual Blueprint Scanner, Harman Sir. Optical targeting online.';

    return {
      isLocal: true,
      reply,
      actionType: 'open_blueprint_scanner',
      payload: { query },
    };
  }

  // 3. EMERGENCY ASSISTANCE COMMANDS ("Jarvis, mujhe khatra hai", "Emergency SOS")
  if (
    query.includes('mujhe khatra hai') ||
    query.includes('khatra hai') ||
    query.includes('emergency') ||
    query.includes('sos') ||
    query.includes('help me jarvis') ||
    query.includes('bachao')
  ) {
    return {
      isLocal: true,
      reply: 'Harman Sir, बिल्कुल घबराइए मत। मैं आपके साथ हूँ, इमरजेंसी प्रोटोकॉल एक्टिवेट कर रहा हूँ।',
      actionType: 'trigger_emergency',
    };
  }

  // 4. VIRTUAL 3D X-RAY & COMPONENT ANALYSIS COMMANDS
  if (
    query.includes('3d model') ||
    query.includes('virtual x-ray') ||
    query.includes('x-ray') ||
    query.includes('xray') ||
    query.includes('exploded view') ||
    query.includes('component analysis') ||
    query.includes('3d blueprint')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, 3D CAD मॉडल लोड कर रहा हूँ।',
      actionType: 'open_virtual_xray',
    };
  }

  // 5. SELF-FEATURE BUILDER COMMANDS
  if (
    query.includes('feature builder') ||
    query.includes('naya feature') ||
    query.includes('build feature') ||
    query.includes('modular builder') ||
    query.includes('plugin builder')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, फीचर बिल्डर वर्कबेंच तैयार है।',
      actionType: 'open_feature_builder',
    };
  }

  // 6. BIOMETRIC & AUTHENTICATION COMMANDS
  if (
    query.includes('biometric') ||
    query.includes('authenticate me') ||
    query.includes('passkey') ||
    query.includes('voice profile') ||
    query.includes('verify identity') ||
    query.includes('family access')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, बायोमेट्रिक ऑथेंटिकेशन कंसोल खोल रहा हूँ।',
      actionType: 'open_auth',
    };
  }

  // 7. SCREENSHOT & SCREEN CAPTURE COMMANDS
  if (
    query.includes('screenshot') ||
    query.includes('screen capture') ||
    query.includes('capture screen') ||
    query.includes('screen lo')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, स्क्रीनशॉट ले लिया गया है।',
      actionType: 'take_screenshot',
    };
  }

  // 8. STOP LISTENING / STANDBY COMMANDS ("Jarvis, बंद हो जाओ", "Jarvis, Okay Bye")
  if (
    query === 'jarvis band ho jao' ||
    query === 'band ho jao' ||
    query === 'jarvis, band ho jao' ||
    query === 'jarvis okay bye' ||
    query === 'okay bye' ||
    query === 'jarvis bye' ||
    query === 'bye jarvis' ||
    query === 'jarvis stop' ||
    query === 'jarvis okay' ||
    query === 'stop listening' ||
    query === 'quiet' ||
    query === 'shant ho jao' ||
    query === 'सो जाओ' ||
    query === 'बंद हो जाओ'
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, स्टैंडबाय मोड एक्टिवेट हो गया है। जब भी जरूरत हो, आवाज़ दीजिए।',
      actionType: 'stop_listening',
    };
  }

  // 4. DISTINCT SUNRISE QUESTIONS ("Aaj sunrise kitne baje hua tha?")
  const sunriseKeywords = ['sunrise', 'sun rise', 'suraj kab nikla', 'suraj kab niklega', 'suraj ugne', 'suraj ugan'];
  if (sunriseKeywords.some(kw => query.includes(kw))) {
    const sunriseTime = context.weather?.sunrise12 || format12HourTime(context.weather?.sunrise) || '6:30 AM';
    const loc = context.weather?.location || 'आपकी लोकेशन';
    const isHindi = query.includes('suraj') || query.includes('kitne') || query.includes('kab') || query.includes('aaj');
    const reply = isHindi
      ? `Harman Sir, ${loc} पर आज सूर्योदय ${sunriseTime} पर हुआ था।`
      : `Harman Sir, today's sunrise at ${loc} was at ${sunriseTime}.`;

    return {
      isLocal: true,
      reply,
      actionType: 'sunrise',
      payload: { sunriseTime, location: loc },
    };
  }

  // 5. DISTINCT SUNSET QUESTIONS ("Sunset kitne baje hoga?")
  const sunsetKeywords = ['sunset', 'sun set', 'suraj kab doobega', 'suraj doobne', 'dhalne ka samay', 'suraj ast'];
  if (sunsetKeywords.some(kw => query.includes(kw))) {
    const sunsetTime = context.weather?.sunset12 || format12HourTime(context.weather?.sunset) || '5:45 PM';
    const loc = context.weather?.location || 'आपकी लोकेशन';
    const isHindi = query.includes('suraj') || query.includes('kitne') || query.includes('kab') || query.includes('aaj');
    const reply = isHindi
      ? `Harman Sir, ${loc} पर आज सूर्यास्त ${sunsetTime} पर होगा।`
      : `Harman Sir, today's sunset at ${loc} is at ${sunsetTime}.`;

    return {
      isLocal: true,
      reply,
      actionType: 'sunset',
      payload: { sunsetTime, location: loc },
    };
  }

  // 6. COMBINED TIME + WEATHER QUESTIONS ("Samay aur mausam kya hai?", "Time and weather")
  if (
    (query.includes('samay') && query.includes('mausam')) ||
    (query.includes('time') && query.includes('weather')) ||
    (query.includes('time') && query.includes('mausam'))
  ) {
    const isHindi = !query.includes('weather');
    const timeReply = timeService.getTimeBriefing(undefined, isHindi);
    let weatherSnippet = '';
    if (context.weather) {
      const temp = Math.round(context.weather.temperature);
      const cond = context.weather.condition;
      const loc = context.weather.location || 'आपकी लोकेशन';
      weatherSnippet = isHindi
        ? ` ${loc} में तापमान ${temp}°C है और मौसम ${cond} बना हुआ है।`
        : ` In ${loc}, the temperature is ${temp}°C with ${cond}.`;
    }

    return {
      isLocal: true,
      reply: `${timeReply}${weatherSnippet}`,
      actionType: 'time',
      payload: { time12: timeService.format12HourTimeShort() },
    };
  }

  // 7. TIME QUESTIONS (STRICT 12-HOUR FORMAT FROM DEVICE SYSTEM CLOCK, ASIA/KOLKATA)
  const isTimeInquiry =
    query === 'time' ||
    query === 'current time' ||
    query === 'samay' ||
    query === 'waqt' ||
    query.includes('time kya') ||
    query.includes('samay kya') ||
    query.includes('waqt kya') ||
    query.includes('kitne baje') ||
    query.includes('kitna baje') ||
    query.includes('kitne baj') ||
    query.includes('time batao') ||
    query.includes('samay batao') ||
    query.includes('tell me time') ||
    query.includes('what time is it') ||
    query.includes('what is the time') ||
    query.includes("what's the time") ||
    query.includes('kya time hai') ||
    query.includes('abhi time') ||
    query.includes('ghadi me') ||
    query.includes('ghadi mein') ||
    query.includes('ghadi dekho') ||
    (query.includes('time') && !query.includes('alarm') && !query.includes('set') && !query.includes('screen'));

  if (isTimeInquiry) {
    const isHindi = !query.includes('what') && !query.includes('tell me') && !query.includes('current time');
    const reply = timeService.getTimeBriefing(undefined, isHindi);

    return {
      isLocal: true,
      reply,
      actionType: 'time',
      payload: { 
        time12: timeService.format12HourTimeShort(),
        hindiSpeech: timeService.formatHindiTimeSpeech(),
      },
    };
  }

  // 8. DATE & DAY OF WEEK QUESTIONS (DYNAMICALLY FROM DEVICE SYSTEM CLOCK, ASIA/KOLKATA)
  const isDateOrDayInquiry =
    query === 'date' ||
    query === 'tareekh' ||
    query === 'din' ||
    query === 'day' ||
    query.includes('date kya') ||
    query.includes('tareekh kya') ||
    query.includes('aaj kya date') ||
    query.includes('aaj ki date') ||
    query.includes('what is the date') ||
    query.includes('what is today date') ||
    query.includes('today date') ||
    query.includes('aaj kaun sa din') ||
    query.includes('aaj kya din') ||
    query.includes('aaj kya vaar') ||
    query.includes('aaj kaun sa war') ||
    query.includes('which day') ||
    query.includes('what day is it') ||
    query.includes('what day is today') ||
    query.includes('day kya hai') ||
    query.includes('din kaun sa hai') ||
    query.includes('aaj ka din');

  if (isDateOrDayInquiry) {
    const isHindi = !query.includes('what day') && !query.includes('which day') && !query.includes('today date');
    const reply = timeService.getDateBriefing(undefined, isHindi);

    return {
      isLocal: true,
      reply,
      actionType: 'date',
      payload: { dateStr: timeService.formatFullDate() },
    };
  }

  // 8. DISTINCT WEATHER QUESTIONS
  const weatherKeywords = [
    'weather kaisa hai', 'mausam kaisa hai', 'temperature kitna hai', 'taapman kitna hai',
    'how is the weather', 'current weather', 'is it raining', 'weather report'
  ];
  if (weatherKeywords.some(kw => query.includes(kw)) && context.weather) {
    const w = context.weather;
    const temp = Math.round(w.temperature);
    const cond = w.condition;
    const loc = w.location || 'आपकी लोकेशन';
    const isHindi = query.includes('mausam') || query.includes('taapman') || query.includes('kaisa') || query.includes('hai');
    const reply = isHindi
      ? `Harman Sir, ${loc} में अभी तापमान ${temp}°C है और मौसम ${cond} बना हुआ है।`
      : `Harman Sir, in ${loc}, the current temperature is ${temp}°C with ${cond}.`;

    return {
      isLocal: true,
      reply,
      actionType: 'weather',
      payload: w,
    };
  }

  // 9. BATTERY STATUS COMMANDS (Conversational Intelligence Example from Prompt)
  const batteryKeywords = [
    'battery', 'charge', 'charging', 'battery kitni hai', 'battery status',
    'kitna charge hai', 'phone battery', 'charging ho rahi hai'
  ];
  if (batteryKeywords.some(kw => query.includes(kw))) {
    const { supported, level, charging } = context.battery;
    if (!supported) {
      return {
        isLocal: true,
        reply: 'Harman Sir, इस डिवाइस पर बैटरी टेलीमेट्री उपलब्ध नहीं है।',
        actionType: 'battery',
      };
    }

    let reply = '';
    if (charging) {
      if (context.battery.chargingTime && context.battery.chargingTime > 0 && context.battery.chargingTime < 86400) {
        const mins = Math.round(context.battery.chargingTime / 60);
        reply = `Harman Sir, बैटरी ${level}% है और चार्ज हो रही है। पूरा चार्ज होने में लगभग ${mins} मिनट लगेंगे।`;
      } else {
        reply = `Harman Sir, बैटरी ${level}% है और चार्ज हो रही है।`;
      }
    } else if (level <= 15) {
      // Exact prompt conversational example: "सर, बैटरी सिर्फ दस प्रतिशत बची है। चार्जर लगा लीजिए।"
      reply = `Harman Sir, बैटरी सिर्फ ${level} प्रतिशत बची है। चार्जर लगा लीजिए।`;
    } else {
      reply = `Harman Sir, बैटरी अभी ${level}% है। सब सामान्य चल रहा है।`;
    }

    return {
      isLocal: true,
      reply,
      actionType: 'battery',
    };
  }

  // 10. FLASHLIGHT / TORCH TOGGLE
  const torchKeywords = ['flashlight', 'torch', 'flash light', 'batti'];
  if (torchKeywords.some(kw => query.includes(kw))) {
    const turnOn = query.includes('on') || query.includes('jalao') || query.includes('chalao') || query.includes('enable');
    const turnOff = query.includes('off') || query.includes('band') || query.includes('bujhao') || query.includes('disable');

    const nextState = turnOn ? true : turnOff ? false : !context.isFlashlightOn;
    return {
      isLocal: true,
      reply: nextState ? 'जी Harman Sir, फ्लैशलाइट ऑन कर दी है।' : 'फ्लैशलाइट बंद कर दी है, Harman Sir.',
      actionType: 'flashlight',
      payload: { enable: nextState },
    };
  }

  // 11. ALARM SETTING COMMANDS
  const alarmMatch = query.match(/(?:alarm\s+(?:for\s+)?|laga\s+do\s+|lagao\s+)(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje)?/i) ||
                     query.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje)\s*(?:ka\s+)?alarm/i);

  if ((query.includes('alarm') && query.includes('laga')) || (query.includes('set') && query.includes('alarm'))) {
    if (alarmMatch) {
      let hours = parseInt(alarmMatch[1], 10);
      const minutes = alarmMatch[2] ? parseInt(alarmMatch[2], 10) : 0;
      const meridiem = (alarmMatch[3] || '').toLowerCase();

      if (meridiem === 'pm' && hours < 12) hours += 12;
      if (meridiem === 'am' && hours === 12) hours = 0;

      const formattedHours = hours.toString().padStart(2, '0');
      const formattedMins = minutes.toString().padStart(2, '0');
      const timeStr24 = `${formattedHours}:${formattedMins}`;
      const timeStr12 = format12HourTime(timeStr24);

      return {
        isLocal: true,
        reply: `Harman Sir, ${timeStr12} बजे का अलार्म सेट कर दिया है। आप आराम से सो सकते हैं।`,
        actionType: 'set_alarm',
        payload: { time: timeStr24, time12: timeStr12, label: 'Voice Alarm' },
      };
    }
  }

  // 12. PHONE CALL COMMANDS
  if (query.startsWith('call ') || query.includes('ko call') || query.includes('phone lagao') || query.includes('call karo')) {
    let target = query
      .replace(/^jarvis,?\s*/i, '')
      .replace(/^call\s+/i, '')
      .replace(/\s*ko\s*call\s*(?:karo|lagao)?/i, '')
      .replace(/\s*ko\s*phone\s*lagao/i, '')
      .replace(/phone\s*lagao\s*/i, '')
      .trim();

    if (query.includes('whatsapp')) {
      target = target.replace(/whatsapp\s*par\s*/i, '').replace(/on\s*whatsapp\s*/i, '').trim();
      const matchedContact = context.contacts.find(c => 
        c.name.toLowerCase() === target ||
        target.includes(c.name.toLowerCase()) ||
        c.relationship?.toLowerCase() === target
      );

      if (matchedContact) {
        return {
          isLocal: true,
          reply: `जी Harman Sir, ${matchedContact.name} के साथ WhatsApp चैट खोल रहा हूँ।`,
          actionType: 'whatsapp',
          payload: { name: matchedContact.name, phone: matchedContact.phone },
        };
      }

      const digits = target.replace(/[^\d+]/g, '');
      if (digits.length >= 7) {
        return {
          isLocal: true,
          reply: `जी Harman Sir, नंबर ${digits} पर WhatsApp कनेक्ट कर रहा हूँ।`,
          actionType: 'whatsapp',
          payload: { name: digits, phone: digits },
        };
      }

      return {
        isLocal: true,
        reply: `Harman Sir, "${target}" नाम का कोई सेव किया हुआ संपर्क नहीं मिला। क्या आप फ़ोन नंबर बताना चाहेंगे?`,
        actionType: 'whatsapp',
        payload: { name: target, phone: '' },
      };
    }

    const matchedContact = context.contacts.find(c => 
      c.name.toLowerCase() === target ||
      target.includes(c.name.toLowerCase()) ||
      c.relationship?.toLowerCase() === target
    );

    if (matchedContact) {
      return {
        isLocal: true,
        reply: `जी Harman Sir, ${matchedContact.name} को कॉल मिला रहा हूँ।`,
        actionType: 'call',
        payload: { name: matchedContact.name, phone: matchedContact.phone },
      };
    }

    const digits = target.replace(/[^\d+]/g, '');
    if (digits.length >= 7) {
      return {
        isLocal: true,
        reply: `जी Harman Sir, नंबर ${digits} पर कॉल मिला रहा हूँ।`,
        actionType: 'call',
        payload: { name: digits, phone: digits },
      };
    }

    return {
      isLocal: true,
      reply: `Harman Sir, "${target}" नाम का संपर्क आपकी डायरेक्टरी में नहीं मिला। क्या आप फ़ोन नंबर बताना चाहेंगे?`,
      actionType: 'call',
      payload: { name: target, phone: '' },
    };
  }

  // 13. APP LAUNCHER / SHORTCUTS
  const openAppMap: Record<string, { name: string; url: string; nativePackage?: string }> = {
    whatsapp: { name: 'WhatsApp', url: 'https://web.whatsapp.com', nativePackage: 'com.whatsapp' },
    youtube: { name: 'YouTube', url: 'https://www.youtube.com', nativePackage: 'com.google.android.youtube' },
    camera: { name: 'Camera', url: '#camera', nativePackage: 'com.android.camera' },
    settings: { name: 'Settings', url: '#settings', nativePackage: 'com.android.settings' },
    maps: { name: 'Google Maps', url: 'https://maps.google.com', nativePackage: 'com.google.android.apps.maps' },
    google: { name: 'Google', url: 'https://www.google.com', nativePackage: 'com.google.android.googlequicksearchbox' },
    calculator: { name: 'Calculator', url: 'https://www.google.com/search?q=calculator', nativePackage: 'com.google.android.calculator' },
  };

  for (const [key, app] of Object.entries(openAppMap)) {
    if (query.includes(`open ${key}`) || query.includes(`${key} open`) || query.includes(`${key} chalao`)) {
      return {
        isLocal: true,
        reply: `जी Harman Sir, ${app.name} खोल रहा हूँ।`,
        actionType: 'open_app',
        payload: app,
      };
    }
  }

  // 14. INTERRUPTION COMMANDS (Part 5 - "रुको", "एक सेकंड", "मेरी बात सुनो", "Wait, listen to me")
  if (
    query === 'ruko' ||
    query === 'रुको' ||
    query.includes('ek second') ||
    query.includes('ek sec') ||
    query.includes('एक सेकंड') ||
    query.includes('meri baat suno') ||
    query.includes('मेरी बात सुनो') ||
    query.includes('wait listen to me') ||
    query.includes('wait listen') ||
    query === 'wait' ||
    query.includes('wait wait')
  ) {
    return {
      isLocal: true,
      reply: 'हाँ Harman Sir, मैं समझ गया। मैं सुन रहा हूँ। पिछला काम रोक दिया गया है।',
      actionType: 'interrupt_task',
    };
  }

  // 15. TASK RESUMPTION / CANCELLATION (Part 5)
  if (query.includes('carry on') || query.includes('continue') || query.includes('pichla kaam') || query.includes('resume task')) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, पिछला काम जारी कर रहा हूँ।',
      actionType: 'resume_task',
    };
  }

  if (query.includes('cancel previous') || query.includes('wo chhod do') || query.includes('pichla cancel') || query.includes('cancel that')) {
    return {
      isLocal: true,
      reply: 'Previous task cleared from execution queue, Harman Sir.',
      actionType: 'cancel_task',
    };
  }

  // 16. NEARBY SHOPS, MECHANICS & ROUTES (Part 9)
  if (
    query.includes('nearby') ||
    query.includes('paas me') ||
    query.includes('pass me') ||
    query.includes('dukaan') ||
    query.includes('mechanic') ||
    query.includes('petrol pump') ||
    query.includes('fuel station') ||
    query.includes('hospital') ||
    query.includes('clinic') ||
    query.includes('rasta dikhao') ||
    query.includes('direction')
  ) {
    const cleanSubject = query
      .replace(/nearby|paas me|pass me|kahan hai|dikhao|batao|search|dhundo/gi, '')
      .trim() || 'services';

    return {
      isLocal: true,
      reply: `जी Harman Sir, आपके नजदीकी ${cleanSubject} और Google Maps का रूट सर्च कर रहा हूँ।`,
      actionType: 'open_places',
      payload: { query: cleanSubject },
    };
  }

  // 17. LOST OR STOLEN DEVICE RECOVERY (Part 10)
  if (
    query.includes('phone kho gaya') ||
    query.includes('lost phone') ||
    query.includes('find my phone') ||
    query.includes('find my device') ||
    query.includes('siren bajao') ||
    query.includes('ring siren') ||
    query.includes('phone chori')
  ) {
    return {
      isLocal: true,
      reply: 'Harman Sir, activating device recovery protocols and high-decibel audio locator siren.',
      actionType: 'open_device_recovery',
    };
  }

  // 18. WEBSITE SECURITY CHECK
  if (query.includes('website safe') || query.includes('check website') || query.includes('kya yeh website safe hai')) {
    const urlMatch = query.match(/(https?:\/\/[^\s]+|[a-zA-Z0-9-]+\.[a-zA-Z]{2,}[^\s]*)/i);
    const targetUrl = urlMatch ? urlMatch[0] : '';
    return {
      isLocal: true,
      reply: targetUrl ? `Analyzing security profile for ${targetUrl}, Harman Sir.` : 'Please specify the domain or URL you wish to inspect, Harman Sir.',
      actionType: 'check_security',
      payload: { url: targetUrl },
    };
  }

  // 19. PERMANENT VOICE REFERENCE & SAMPLE AUDIO (voice-preview (1).mp3)
  if (
    query.includes('voice sample') ||
    query.includes('sample voice') ||
    query.includes('sample sunao') ||
    query.includes('awaaz ka sample') ||
    query.includes('play sample') ||
    query.includes('play voice sample') ||
    query.includes('voice preview') ||
    query.includes('voice sunao') ||
    query.includes('reference voice') ||
    query.includes('voice reference') ||
    query.includes('original voice') ||
    query.includes('asli awaaz')
  ) {
    return {
      isLocal: true,
      reply: 'Harman Sir, voice-preview (1).mp3 audio reference sample प्ले कर रहा हूँ। मेरी स्थायी ब्रिटिश मेल आवाज़ इसी पर लॉक है।',
      actionType: 'play_voice_sample',
    };
  }

  // 20. VOICE SETTINGS & CALIBRATION MODAL
  if (
    query.includes('voice setting') ||
    query.includes('voice settings') ||
    query.includes('awaaz setting') ||
    query.includes('voice calibrate') ||
    query.includes('calibrate voice') ||
    query.includes('voice depth') ||
    query.includes('voice pitch') ||
    query.includes('voice speed')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, वॉइस कैलिब्रेशन कंसोल प्रस्तुत है। आप डेप्थ, स्पीड, और पिच सेमिटोन्स को अपनी पसंद अनुसार सेट कर सकते हैं।',
      actionType: 'open_voice_settings',
    };
  }

  // 20b. PERMANENT VOICE IDENTITY CONFIRMATION
  if (
    query.includes('change voice') ||
    query.includes('voice change') ||
    query.includes('voice select') ||
    query.includes('select voice') ||
    query.includes('choose voice') ||
    query.includes('lock voice') ||
    query.includes('voice badlo') ||
    query.includes('awaaz badlo') ||
    query.includes('voice lock') ||
    query.includes('awaaz change') ||
    query.includes('voice fix') ||
    query.includes('fix voice') ||
    query.includes('awaaz lock')
  ) {
    return {
      isLocal: true,
      reply: 'Harman Sir, मेरी यह आवाज़ आपकी सुरक्षा और पहचान के लिए हमेशा के लिए ElevenLabs George (British Male Baritone) पर स्थायी रूप से लॉक है। यह कभी दूसरी आवाज़ में नहीं बदलेगी।',
    };
  }

  // 20c. UNIVERSAL DEVICE CONNECTION SYSTEM & DEVICE MEMORY (Requirement 3)
  // "meri car se connect ho jao", "mere TV se connect ho jao", "mere Bluetooth headphones connect kar do",
  // "remember this device as my car", "forget my old TV"
  if (
    query.includes('car se connect') ||
    query.includes('connect to my car') ||
    query.includes('connect car') ||
    query.includes('car connect karo') ||
    query.includes('car se jud jao')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, आपकी कार के इंफोटेनमेंट सिस्टम से कनेक्ट कर रहा हूँ।',
      actionType: 'connect_device',
      payload: { target: 'car' },
    };
  }

  if (
    query.includes('tv se connect') ||
    query.includes('connect to my tv') ||
    query.includes('connect tv') ||
    query.includes('tv connect karo') ||
    query.includes('tv se jud jao')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, स्मार्ट टीवी कास्ट सिस्टम से कनेक्ट कर रहा हूँ।',
      actionType: 'connect_device',
      payload: { target: 'tv' },
    };
  }

  if (
    query.includes('headphones connect') ||
    query.includes('headphone connect') ||
    query.includes('earphones connect') ||
    query.includes('bluetooth headphones') ||
    query.includes('connect to my saved headphones') ||
    query.includes('connect headphones') ||
    query.includes('connect audio')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, आपके वायरलेस ब्लूटूथ हेडफोन्स से हाई-फिडेलिटी ऑडियो लिंक कनेक्ट कर रहा हूँ।',
      actionType: 'connect_device',
      payload: { target: 'audio' },
    };
  }

  if (
    query.includes('disconnect car') ||
    query.includes('car disconnect') ||
    query.includes('tv disconnect') ||
    query.includes('disconnect tv') ||
    query.includes('headphones disconnect') ||
    query.includes('device disconnect')
  ) {
    const target = query.includes('car') ? 'car' : query.includes('tv') ? 'tv' : 'audio';
    return {
      isLocal: true,
      reply: `जी Harman Sir, ${target} को डिस्कनेक्ट कर दिया गया है।`,
      actionType: 'disconnect_device',
      payload: { target },
    };
  }

  if (
    query.includes('forget my') ||
    query.includes('forget device') ||
    query.includes('device bhool jao') ||
    query.includes('ko bhool jao') ||
    query.includes('remove device')
  ) {
    const target = query.includes('car') ? 'car' : query.includes('tv') ? 'tv' : query.includes('headphone') ? 'audio' : 'other';
    return {
      isLocal: true,
      reply: `जी Harman Sir, ${target} को डिवाइस मेमोरी से हटा दिया गया है।`,
      actionType: 'forget_device',
      payload: { target },
    };
  }

  if (
    query.includes('device dikhao') ||
    query.includes('devices dikhao') ||
    query.includes('open devices') ||
    query.includes('show devices') ||
    query.includes('bluetooth scanner') ||
    query.includes('bluetooth scan')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, यूनिवर्सल डिवाइस रजिस्ट्री और ब्लूटूथ कंसोल खोल रहा हूँ।',
      actionType: 'open_devices',
    };
  }

  // 20d. MULTI-AGENT MISSION CONTROL SYSTEM (Requirement 4 / Ultra 3.0)
  if (
    query.includes('mission control') ||
    query.includes('show agents') ||
    query.includes('multi agent') ||
    query.includes('multi-agent') ||
    query.includes('agent telemetry') ||
    query.includes('sub agents') ||
    query.includes('sub-agents')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, जे.ए.आर.वी.आई.एस. मल्टी-एजेंट मिशन कंट्रोल और टास्क ऑकेस्ट्रेशन डैशबोर्ड प्रस्तुत है।',
      actionType: 'open_mission_control',
    };
  }

  // 21. PERMANENT PERSONAL MEMORY COMMANDS (Requirement 5)
  // "Jarvis, ye baat yaad rakhna", "Jarvis, meri ye preference change karo", "Jarvis, ye memory delete kar do", "Jarvis, apni memory dikhao"
  if (
    query.includes('yaad rakhna') ||
    query.includes('yaad rakho') ||
    query.includes('remember that') ||
    query.includes('remember this') ||
    query.includes('save to memory')
  ) {
    const fact = rawInput
      .replace(/jarvis/gi, '')
      .replace(/ye baat yaad rakhna/gi, '')
      .replace(/yaad rakhna/gi, '')
      .replace(/yaad rakho/gi, '')
      .replace(/remember that/gi, '')
      .replace(/remember this/gi, '')
      .replace(/ki/gi, '')
      .trim();

    return {
      isLocal: true,
      reply: `जी Harman Sir, मैंने यह हमेशा के लिए अपनी न्यूरल मेमोरी में सुरक्षित कर लिया है: "${fact}"`,
      actionType: 'save_memory',
      payload: { fact: fact || rawInput },
    };
  }

  if (
    query.includes('apni memory dikhao') ||
    query.includes('show memory') ||
    query.includes('kya yaad hai') ||
    query.includes('memory check') ||
    query.includes('open memory')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, आपकी न्यूरल मेमोरी और सुरक्षित वॉल्ट खोल रहा हूँ।',
      actionType: 'show_memory',
    };
  }

  if (
    query.includes('memory delete') ||
    query.includes('delete memory') ||
    query.includes('ye memory delete kar do') ||
    query.includes('bhool jao')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, न्यूरल मेमोरी वॉल्ट खोल रहा हूँ ताकि आप चुनिंदा मेमोरी हटा सकें।',
      actionType: 'delete_memory',
    };
  }

  if (
    query.includes('preference change karo') ||
    query.includes('change preference') ||
    query.includes('meri preference')
  ) {
    return {
      isLocal: true,
      reply: 'जी Harman Sir, आपकी प्रेफरेंस अपडेट करने के लिए सेटिंग्स वॉल्ट प्रस्तुत है।',
      actionType: 'update_preference',
    };
  }

  // 22. AUTONOMOUS SELF-MODIFICATION COMMANDS (Requirement 4)
  // "Jarvis, apne andar ek naya feature add karo", "Jarvis, ye feature permanently remove kar do",
  // "Jarvis, apna response time improve karo", "Jarvis, apne memory system ko upgrade karo"
  if (
    query.includes('apne andar') ||
    query.includes('naya feature') ||
    query.includes('add feature') ||
    query.includes('feature remove') ||
    query.includes('remove feature') ||
    query.includes('response time improve') ||
    query.includes('memory system ko upgrade') ||
    query.includes('memory system upgrade') ||
    query.includes('self modify') ||
    query.includes('self-modify') ||
    query.includes('modify code') ||
    query.includes('apna code')
  ) {
    return {
      isLocal: true,
      reply: 'Harman Sir, ऑटोनॉमस सेल्फ-मॉडिफिकेशन इंजन सक्रिय हो गया है। कोड एनालिसिस, चेकपॉइंट और सिंटैक्स वैलिडेशन तैयार है।',
      actionType: 'self_modify',
      payload: { instruction: rawInput },
    };
  }

  // Default: Complex reasoning, world knowledge, or external inquiry -> Hand to AI Brain
  return {
    isLocal: false,
    reply: '',
  };
}
