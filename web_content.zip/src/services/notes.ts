/** ملاحظات الدرس بختم زمني + إشارات مرجعية */
import type { Bookmark, VideoNote } from '../types';
import { KEYS, readKey, updateKey, writeKey } from './storage';

type NoteMap = Record<string, VideoNote[]>;
type BookmarkMap = Record<string, Bookmark[]>;

const emptyNotes: NoteMap = {};
const emptyBookmarks: BookmarkMap = {};

export function notesFor(lessonId: string): VideoNote[] {
  return readKey<NoteMap>(KEYS.notes, emptyNotes)[lessonId] ?? [];
}

export function addNote(lessonId: string, time: number, text: string): boolean {
  const clean = text.trim();
  if (!clean) return false;
  const note: VideoNote = {
    id: `n-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    lessonId,
    time: Math.max(0, Math.floor(time)),
    text: clean,
    createdAt: Date.now(),
  };
  const map = readKey<NoteMap>(KEYS.notes, emptyNotes);
  return writeKey(KEYS.notes, { ...map, [lessonId]: [...(map[lessonId] ?? []), note] });
}

export function updateNote(lessonId: string, noteId: string, text: string): boolean {
  const map = readKey<NoteMap>(KEYS.notes, emptyNotes);
  const notes = map[lessonId] ?? [];
  if (!notes.some((note) => note.id === noteId) || !text.trim()) return false;
  return writeKey(KEYS.notes, {
    ...map,
    [lessonId]: notes.map((note) => note.id === noteId ? { ...note, text: text.trim(), updatedAt: Date.now() } : note),
  });
}

export function deleteNote(lessonId: string, noteId: string): boolean {
  const map = readKey<NoteMap>(KEYS.notes, emptyNotes);
  const notes = map[lessonId] ?? [];
  if (!notes.some((note) => note.id === noteId)) return false;
  return writeKey(KEYS.notes, { ...map, [lessonId]: notes.filter((note) => note.id !== noteId) });
}

export function exportNotesText(lessonTitle: string, notes: VideoNote[]): void {
  const lines = [
    `ملاحظات: ${lessonTitle}`,
    `تاريخ التصدير: ${new Date().toLocaleString('ar-SY')}`,
    '—'.repeat(24),
    ...notes
      .slice()
      .sort((a, b) => a.time - b.time)
      .map((n) => `[${formatStamp(n.time)}] ${n.text}`),
  ];
  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `ملاحظات-${lessonTitle}.txt`;
  a.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function exportNotesBundle(
  entries: Array<{ subjectName: string; lessonTitle: string; note: VideoNote }>,
): void {
  const lines = [
    'ملاحظاتي — منارة البكالوريا',
    `تاريخ التصدير: ${new Date().toLocaleString('ar-SY')}`,
    '—'.repeat(28),
    ...entries
      .slice()
      .sort((a, b) => b.note.createdAt - a.note.createdAt)
      .flatMap(({ subjectName, lessonTitle, note }) => [
        `${subjectName} · ${lessonTitle} · ${formatStamp(note.time)}`,
        note.text,
        '',
      ]),
  ];
  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'ملاحظاتي-منارة.txt';
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function formatStamp(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const mm = `${m}`.padStart(2, '0');
  const ss = `${sec}`.padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

/* --------------------------- الإشارات المرجعية --------------------------- */

export function bookmarksFor(lessonId: string): Bookmark[] {
  return readKey<BookmarkMap>(KEYS.bookmarks, emptyBookmarks)[lessonId] ?? [];
}

export function toggleBookmark(lessonId: string, time: number, label: string): void {
  updateKey<BookmarkMap>(
    KEYS.bookmarks,
    (map) => {
      const list = map[lessonId] ?? [];
      const at = Math.floor(time);
      const existing = list.find((b) => Math.abs(b.time - at) <= 3);
      if (existing) {
        return { ...map, [lessonId]: list.filter((b) => b.id !== existing.id) };
      }
      const bookmark: Bookmark = {
        id: `b-${Date.now()}`,
        lessonId,
        time: at,
        label,
        createdAt: Date.now(),
      };
      return { ...map, [lessonId]: [...list, bookmark].sort((a, b) => a.time - b.time) };
    },
    emptyBookmarks,
  );
}

export function removeBookmark(lessonId: string, id: string): void {
  updateKey<BookmarkMap>(
    KEYS.bookmarks,
    (map) => ({ ...map, [lessonId]: (map[lessonId] ?? []).filter((b) => b.id !== id) }),
    emptyBookmarks,
  );
}
