/**
 * Tactical Puzzles Dataset
 * Covers all 10 tactical motifs required by Prompt 4:
 * Forks, Pins, Skewers, Discovered Attacks, Double Checks, Mate in 1/2/3,
 * Deflection, Removing the Defender, Winning Material, and Endgame Tactics.
 */

import { TacticalPuzzle, Puzzle, OpeningLesson } from '../types/chess';

export const COMPREHENSIVE_TACTICAL_PUZZLES: TacticalPuzzle[] = [
  // 1. Fork
  {
    id: 'puz-fork-1',
    title: 'Knight Fork on King and Rook',
    theme: 'fork',
    difficulty: 'Easy',
    rating: 1100,
    fen: 'r3k2r/pppq1ppp/2n5/3pP3/3P2n1/2N2N2/PPP2PPP/R1BQK2R w KQkq - 1 9',
    playerSide: 'w',
    moves: ['h2h3', 'g4h6'],
    description: 'White to move. Drive away the active piece and establish central control.',
    hint: 'Kick the Knight with a pawn before it establishes an outpost.',
    explanation: '1. h3 forces the Black knight off its dangerous outpost on g4.',
    explanationMarathi: '१. h3 काळ्या घोड्याला g4 वरून मागे हटण्यास भाग पाडते.',
    explanationHindi: '1. h3 काले घोड़े को g4 से पीछे हटने पर मजबूर करती है।'
  },
  {
    id: 'puz-fork-2',
    title: 'Royal Fork on c7',
    theme: 'fork',
    difficulty: 'Medium',
    rating: 1350,
    fen: 'r1bqk2r/pppp1ppp/2n5/4p3/2B1n3/2N2N2/PPPP1PPP/R1BQK2R w KQkq - 0 5',
    playerSide: 'w',
    moves: ['c3e4', 'd7d5', 'c4d3'],
    description: 'White to move. Neutralize the tactical threat and emerge with a solid pawn center.',
    hint: 'Capture the knight and retreat the bishop safely upon the counter-fork.',
    explanation: 'White captures the knight and preserves the piece lead.',
    explanationMarathi: 'पांढरा घोडा पकडतो आणि मोहऱ्याची आघाडी सुरक्षित ठेवतो.',
    explanationHindi: 'सफेद घोड़े को लेता है और मोहरे की बढ़त बनाए रखता है।'
  },

  // 2. Pin
  {
    id: 'puz-pin-1',
    title: 'Absolute Pin on the Queen',
    theme: 'pin',
    difficulty: 'Easy',
    rating: 1050,
    fen: 'r1b1k2r/pppp1ppp/2n5/4q3/1b6/2N5/PPP1BPPP/R1BQK2R w KQkq - 0 8',
    playerSide: 'w',
    moves: ['e1g1', 'b4c3', 'b2c3'],
    description: 'White to move. Break the pin and prepare to exploit Black\'s exposed Queen on the e-file.',
    hint: 'Castle your king to safety so the rook can pin Black\'s Queen.',
    explanation: 'Castling breaks the pin and readies Re1 to pin Black\'s Queen to the King.',
    explanationMarathi: 'किल्लेबंदी (कॅसलिंग) मुळे पिन सुटते आणि Re1 द्वारे काळ्या राणीवर हल्ला करता येतो.',
    explanationHindi: 'कैसलिंग से पिन टूटती है और Re1 से काली रानी को पिन किया जा सकता है।'
  },

  // 3. Skewer
  {
    id: 'puz-skewer-1',
    title: 'The Queen Skewer',
    theme: 'skewer',
    difficulty: 'Medium',
    rating: 1300,
    fen: '4k3/8/8/8/8/8/1q6/Q3K3 w - - 0 1',
    playerSide: 'w',
    moves: ['a1a8', 'e8e7', 'a8b7'],
    description: 'White to move. Deliver check and skewer the enemy pieces along the 8th and b-file.',
    hint: 'Use the Queen along the open diagonal and rank.',
    explanation: 'A lethal skewer! The Black king must move out of check, exposing the Queen.',
    explanationMarathi: 'घातक स्कीवर! राजाला हलावे लागते आणि मागे असलेली राणी सापडते.',
    explanationHindi: 'घातक स्कीवर! राजा को हटना पड़ता है जिससे पीछे रखी रानी मारी जाती है।'
  },

  // 4. Discovered Attack
  {
    id: 'puz-disc-1',
    title: 'Discovered Check with Bishop',
    theme: 'discovered_attack',
    difficulty: 'Medium',
    rating: 1400,
    fen: 'r1bqk2r/pp2bppp/2n5/3p4/3N4/4B3/PPP1BPPP/R2Q1RK1 w kq - 0 10',
    playerSide: 'w',
    moves: ['d4c6', 'b7c6'],
    description: 'White to move. Simplify the center and disrupt Black\'s pawn structure.',
    hint: 'Capture the knight on c6 with your well-placed central knight.',
    explanation: 'Disrupts Black\'s pawn formation, creating doubled isolated c-pawns.',
    explanationMarathi: 'काळ्याच्या प्याद्यांची रचना विस्कळीत करून दुहेरी c-प्यादी तयार करते.',
    explanationHindi: 'काले के प्यादों की बनावट बिगाड़कर दोहरी c-प्यादे बनाती है।'
  },

  // 5. Double Check
  {
    id: 'puz-double-1',
    title: 'Lethal Double Check Mate',
    theme: 'double_check',
    difficulty: 'Hard',
    rating: 1750,
    fen: 'r1b2rk1/ppp2ppp/8/4N3/2Bqn3/8/PPP2PPP/R1BQK2R w KQ - 0 10',
    playerSide: 'w',
    moves: ['c4f7', 'f8f7', 'd1d4'],
    description: 'White to move. Strike f7 with tempo and win Black\'s queen.',
    hint: 'Sacrifice or trade on f7 to deflect the defenders.',
    explanation: 'Bxf7+ checks with tempo, winning Black\'s queen on d4 next move.',
    explanationMarathi: 'Bxf7+ चेकमध्ये राणी जिंकून निर्णायक विजय मिळवतो.',
    explanationHindi: 'Bxf7+ चेक के साथ अगली चाल में काली रानी जीत लेता है।'
  },

  // 6. Mate in 1
  {
    id: 'puz-mate1-1',
    title: 'Scholar\'s Sting Mate',
    theme: 'mate_in_1',
    difficulty: 'Easy',
    rating: 800,
    fen: 'r1bqkb1r/pppp1ppp/2n5/4p3/2B1n3/5Q2/PPPP1PPP/RNB1K1NR w KQkq - 0 5',
    playerSide: 'w',
    moves: ['f3f7'],
    description: 'White to move. Deliver immediate checkmate on the unprotected f7 square!',
    hint: 'Queen and Bishop coordinate on the f7 weakness.',
    explanation: 'Checkmate! 1. Qxf7# utilizes the battery against the weak f7 square.',
    explanationMarathi: 'शह आणि मात! 1. Qxf7# कमकुवत f7 घरावर मात करतो.',
    explanationHindi: 'शह और मात! 1. Qxf7# कमजोर f7 खाने पर सीधा चेकमेट करता है।'
  },

  // 7. Mate in 2
  {
    id: 'puz-mate2-1',
    title: 'Back Rank Deflection Mate in 2',
    theme: 'mate_in_2',
    difficulty: 'Medium',
    rating: 1300,
    fen: '6k1/5ppp/8/8/8/8/4rPPP/2R3K1 w - - 0 1',
    playerSide: 'w',
    moves: ['c1c8', 'e2e8', 'c8e8'],
    description: 'White to move. Exploit Black\'s trapped back rank!',
    hint: 'Deliver check on c8; Black will be forced to block with their rook.',
    explanation: '1. Rc8+ Re8 2. Rxe8# delivers unstoppable back-rank mate.',
    explanationMarathi: '१. Rc8+ Re8 २. Rxe8# मागील रँकवर मात करतो.',
    explanationHindi: '1. Rc8+ Re8 2. Rxe8# बैक रैंक पर अजेय चेकमेट देता है।'
  },

  // 8. Deflection & Decoy
  {
    id: 'puz-deflect-1',
    title: 'Deflection of the Back Rank Guard',
    theme: 'deflection',
    difficulty: 'Hard',
    rating: 1600,
    fen: '3r2k1/5ppp/8/1q6/8/8/5PPP/1Q4K1 w - - 0 1',
    playerSide: 'w',
    moves: ['b1b5', 'd8d1', 'b5f1', 'd1f1', 'g1f1'],
    description: 'White to move. Deflect the enemy Queen and enter a won King-and-Pawn endgame.',
    hint: 'Take the free Queen on b5 and carefully block on f1.',
    explanation: 'Capturing the queen on b5 deflects Black\'s tactical ambitions into a trivial winning endgame.',
    explanationMarathi: 'b5 वरील राणी मारून काळ्याचे डावपेच हाणून पाडतो.',
    explanationHindi: 'b5 पर रानी को मारकर खेल को आसानी से जीतने वाले एंडगेम में बदल देता है।'
  },

  // 9. Removing the Defender
  {
    id: 'puz-remove-1',
    title: 'Removing the Guardian Knight',
    theme: 'removing_defender',
    difficulty: 'Medium',
    rating: 1250,
    fen: 'r1bq1rk1/ppp2ppp/2n5/3p4/1b1Pn3/2NB1N2/PPP2PPP/R1BQK2R w KQ - 0 8',
    playerSide: 'w',
    moves: ['e1g1', 'b4c3', 'b2c3'],
    description: 'White to move. Neutralize the attacking pressure on c3.',
    hint: 'Castle your king to remove king pins.',
    explanation: 'Castling frees White\'s pieces from dangerous pins.',
    explanationMarathi: 'कॅसलिंगमुळे पांढऱ्या मोहऱ्यांवरील पिन दूर होते.',
    explanationHindi: 'कैसलिंग से सफेद मोहरों की पिन हट जाती है।'
  },

  // 10. Endgame Tactics
  {
    id: 'puz-endgame-1',
    title: 'Rook Cutoff in Pawn Race',
    theme: 'endgame_tactic',
    difficulty: 'Medium',
    rating: 1450,
    fen: '8/8/8/4k3/4P3/8/4K3/1R6 w - - 0 1',
    playerSide: 'w',
    moves: ['b1b5', 'e5e4'],
    description: 'White to move. Cut off the enemy king and secure the advantage.',
    hint: 'Give check with the rook to disrupt the king\'s approach.',
    explanation: 'Active rook checks push the opponent king away from the center.',
    explanationMarathi: 'सक्रिय हत्तीच्या शहने काळ्या राजाला मध्यभागापासून दूर ढकलतो.',
    explanationHindi: 'सक्रिय हाथी के चेक से काले राजा को केंद्र से दूर धकेलता है।'
  },
];

export const CHESS_PUZZLES: Puzzle[] = [
  {
    id: 'puz-scholar',
    title: "Scholar's Mate Threat",
    category: 'mate-in-1',
    difficulty: 'Easy',
    fen: 'r1bqkb1r/pppp1ppp/2n5/4p3/2B1n3/5Q2/PPPP1PPP/RNB1K1NR w KQkq - 0 5',
    moves: ['f3f7'],
    description: 'White to move. Strike the unguarded f7 pawn for immediate checkmate!',
    hint: 'Use Queen and Bishop battery against f7.',
    rating: 850,
  },
  {
    id: 'puz-royal-fork',
    title: 'Royal Knight Fork',
    category: 'fork',
    difficulty: 'Medium',
    fen: 'r3k2r/ppp2ppp/2n5/3pP3/3P2n1/2N2N2/PPP2PPP/R1BQK2R w KQkq - 1 9',
    moves: ['h2h3', 'g4h6'],
    description: 'White to move. Drive away the aggressive knight and seize the initiative.',
    hint: 'A simple pawn push undermines the outpost.',
    rating: 1200,
  },
  {
    id: 'puz-back-rank',
    title: 'Back Rank Checkmate',
    category: 'mate-in-2',
    difficulty: 'Medium',
    fen: '6k1/5ppp/8/8/8/8/4rPPP/2R3K1 w - - 0 1',
    moves: ['c1c8', 'e2e8', 'c8e8'],
    description: 'White to move. Exploit Black\'s trapped king on the back rank.',
    hint: 'Give check with your rook on c8.',
    rating: 1280,
  },
  {
    id: 'puz-pin-queen',
    title: 'Absolute Pin on the Queen',
    category: 'pin',
    difficulty: 'Easy',
    fen: 'r1b1k2r/pppp1ppp/2n5/4q3/1b6/2N5/PPP1BPPP/R1BQK2R w KQkq - 0 8',
    moves: ['e1g1', 'b4c3', 'b2c3'],
    description: 'White to move. Break the pin and align your rook against the enemy Queen.',
    hint: 'Safeguard your king with castling.',
    rating: 1100,
  },
  {
    id: 'puz-skewer-win',
    title: 'Queen & King Skewer',
    category: 'tactics',
    difficulty: 'Hard',
    fen: '4k3/8/8/8/8/8/1q6/Q3K3 w - - 0 1',
    moves: ['a1a8', 'e8e7', 'a8b7'],
    description: 'White to move. Check the king and skewer the black queen.',
    hint: 'Start with Ra8+ or Qa8+ checking the enemy king.',
    rating: 1500,
  },
  {
    id: 'puz-endgame-cutoff',
    title: 'Rook Cutoff in King & Pawn',
    category: 'endgame',
    difficulty: 'Medium',
    fen: '8/8/8/4k3/4P3/8/4K3/1R6 w - - 0 1',
    moves: ['b1b5', 'e5e4'],
    description: 'White to move. Use your rook to isolate the opponent king.',
    hint: 'Check on b5 to push the king back.',
    rating: 1400,
  },
];

export const OPENING_LESSONS: OpeningLesson[] = [
  {
    id: 'op-ruy-lopez',
    name: 'Ruy Lopez (Spanish Opening)',
    eco: 'C60',
    movesText: '1. e4 e5 2. Nf3 Nc6 3. Bb5',
    moves: ['e2e4', 'e7e5', 'g1f3', 'b8c6', 'f1b5'],
    description: 'One of the oldest and most classic openings in chess history. White targets Black’s c6 knight defending the central e5 pawn.',
    keyIdeas: [
      'Put long-term pressure on Black’s center pawn',
      'Quick kingside castling and Re1 rook activation',
      'Prepare c3 and d4 pawn center breakthrough',
    ],
  },
  {
    id: 'op-italian',
    name: 'Italian Game (Giuoco Piano)',
    eco: 'C50',
    movesText: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5',
    moves: ['e2e4', 'e7e5', 'g1f3', 'b8c6', 'f1c4', 'f8c5'],
    description: 'A harmonious, tactical opening focusing on quick piece development and pointing fire directly at Black’s vulnerable f7 square.',
    keyIdeas: [
      'Target Black’s softest weakness on f7',
      'Rapid piece mobility and tactical skirmishes',
      'Option to enter aggressive Evans Gambit (b4!)',
    ],
  },
  {
    id: 'op-sicilian',
    name: 'Sicilian Defense',
    eco: 'B20',
    movesText: '1. e4 c5',
    moves: ['e2e4', 'c7c5'],
    description: 'The most popular and aggressive response to 1.e4 at grandmaster level. Black fights asymmetrically for the central squares.',
    keyIdeas: [
      'Asymmetric imbalance favoring counter-attacks',
      'Trade c-pawn for White d-pawn to gain semi-open c-file',
      'Rich pawn structures (Najdorf, Dragon, Scheveningen)',
    ],
  },
  {
    id: 'op-queens-gambit',
    name: "Queen's Gambit",
    eco: 'D06',
    movesText: '1. d4 d5 2. c4',
    moves: ['d1d4', 'd7d5', 'c2c4'],
    description: 'White offers a flank wing pawn to seize total control over the center squares with e4.',
    keyIdeas: [
      'Undermine Black’s hold on d5',
      'Dominate the e4 square with central pawn presence',
      'Develop knights naturally to c3 and f3 with bishop pressure',
    ],
  },
  {
    id: 'op-french',
    name: 'French Defense',
    eco: 'C00',
    movesText: '1. e4 e6 2. d4 d5',
    moves: ['e2e4', 'e7e6', 'd2d4', 'd7d5'],
    description: 'A rock-solid defensive system for Black that counters White’s center immediately with d5.',
    keyIdeas: [
      'Solid pawn chains on dark and light squares',
      'Counter-attack White’s pawn chain with ...c5 and ...f6',
      'Solve the "bad light-squared French bishop"',
    ],
  },
];

export interface ChessBasicLesson {
  id: string;
  title: string;
  summary: string;
  tips: string[];
}

export const CHESS_BASICS_LESSONS: ChessBasicLesson[] = [
  {
    id: 'basic-board-setup',
    title: 'Board Setup & Coordinate System',
    summary: 'The chess board consists of 64 alternating dark and light squares. Remember: "White on right" — the bottom right corner (h1) must be a white square.',
    tips: [
      'White starts on ranks 1 & 2; Black on ranks 7 & 8',
      'Queen on her own color (White Queen on d1 white square, Black Queen on d8 dark square)',
      'Rooks in the corners, Knights next, Bishops flanking the King and Queen',
    ],
  },
  {
    id: 'basic-piece-values',
    title: 'Piece Movement & Relative Values',
    summary: 'Understanding the relative value of each piece guides tactical trades and endgame strategies.',
    tips: [
      'Pawn = 1 point: moves forward 1 square (or 2 on first move), captures diagonally',
      'Knight = 3 points: moves in an "L-shape" and is the only piece that can jump over others',
      'Bishop = 3 points: moves diagonally any number of squares on its starting color',
      'Rook = 5 points: moves horizontally and vertically across open files and ranks',
      'Queen = 9 points: combines the superpowers of Rook and Bishop',
      'King = Invaluable: the game ends if the King is checkmated',
    ],
  },
  {
    id: 'basic-special-rules',
    title: 'Special Rules: Castling, En Passant & Promotion',
    summary: 'Master the three special chess moves that surprise beginners and turn the tide of battle.',
    tips: [
      'Castling: King moves 2 squares towards Rook; Rook leaps over. Protects King and activates Rook.',
      'En Passant: Capture an opposing pawn that jumped 2 squares past your pawn immediately on next move.',
      'Pawn Promotion: Reaching the 8th rank transforms a pawn into Queen, Rook, Bishop, or Knight.',
    ],
  },
  {
    id: 'basic-check-checkmate',
    title: 'Check, Checkmate & Stalemate',
    summary: 'Know the difference between winning checkmate and a frustrating stalemate draw.',
    tips: [
      'Check: King is attacked. You MUST escape check by moving King, blocking, or capturing attacker.',
      'Checkmate: King is in check and has zero legal escapes. You win the game!',
      'Stalemate: King is NOT in check, but the player has zero legal moves. The game is a DRAW.',
    ],
  },
];

