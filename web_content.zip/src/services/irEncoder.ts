/**
 * IrEncoder - Bit-accurate IR Protocol Timing Generator
 * Generates alternating [pulse, space, pulse, space, ...] microsecond arrays
 * compatible with Android's android.hardware.ConsumerIrManager.transmit(carrierFrequency, pattern)
 */

import { IrPatternResult, IrProtocol } from '../types/remote';

export class IrEncoder {
  /**
   * Encodes standard NEC (8-bit address, 8-bit command with inverted checks)
   */
  static encodeNec(address: number, command: number, isExtended = false): IrPatternResult {
    const frequencyHz = 38000;
    const pattern: number[] = [];

    // 1. Leader code: 9000µs pulse + 4500µs space
    pattern.push(9000);
    pattern.push(4500);

    let data32: number;
    if (isExtended) {
      // Extended NEC: 16-bit address (LSB first) + 8-bit command + 8-bit inverted command
      const addrLow = address & 0xff;
      const addrHigh = (address >> 8) & 0xff;
      const cmd = command & 0xff;
      const cmdInv = (~cmd) & 0xff;
      data32 = (addrLow) | (addrHigh << 8) | (cmd << 16) | (cmdInv << 24);
    } else {
      // Standard NEC: 8-bit address + 8-bit inverted address + 8-bit command + 8-bit inverted command
      const addr = address & 0xff;
      const addrInv = (~addr) & 0xff;
      const cmd = command & 0xff;
      const cmdInv = (~cmd) & 0xff;
      data32 = (addr) | (addrInv << 8) | (cmd << 16) | (cmdInv << 24);
    }

    // 2. Transmit 32 bits, LSB first
    for (let i = 0; i < 32; i++) {
      const bit = (data32 >> i) & 1;
      pattern.push(560); // Bit mark pulse: 560µs
      if (bit === 1) {
        pattern.push(1690); // Logical 1 space: 1690µs
      } else {
        pattern.push(560); // Logical 0 space: 560µs
      }
    }

    // 3. Stop bit
    pattern.push(560);

    const totalDurationMs = pattern.reduce((acc, val) => acc + val, 0) / 1000;
    const hexRep = `0x${((data32 >>> 0)).toString(16).toUpperCase().padStart(8, '0')}`;

    return {
      frequencyHz,
      patternMicros: pattern,
      hexRepresentation: hexRep,
      totalDurationMs: Math.round(totalDurationMs * 10) / 10,
      pulseCount: pattern.length,
    };
  }

  /**
   * Sunplus Receiver specialized encoder
   * Sunplus chipsets (1506G, 1506TV, 1507, 2507, etc.) use 38kHz NEC Extended
   * Commonly with customer code 0x00FF, 0xBF40, 0x807F or 0x708F
   */
  static encodeSunplus(customerCode: number, commandCode: number): IrPatternResult {
    const res = this.encodeNec(customerCode, commandCode, true);
    return {
      ...res,
      hexRepresentation: `SUNPLUS [Cust:0x${customerCode.toString(16).toUpperCase().padStart(4, '0')} Cmd:0x${commandCode.toString(16).toUpperCase().padStart(2, '0')}] => ${res.hexRepresentation}`,
    };
  }

  /**
   * Sony SIRC Protocol (12-bit, 15-bit, 20-bit, 40kHz carrier)
   */
  static encodeSonySirc(command: number, address: number, bits: 12 | 15 | 20 = 12): IrPatternResult {
    const frequencyHz = 40000;
    const pattern: number[] = [];

    // Leader: 2400µs pulse + 600µs space
    pattern.push(2400);
    pattern.push(600);

    // Sony transmits 7-bit command first, then address (5, 8, or 13 bits)
    const cmd7 = command & 0x7f;
    for (let i = 0; i < 7; i++) {
      const bit = (cmd7 >> i) & 1;
      pattern.push(bit === 1 ? 1200 : 600);
      pattern.push(600);
    }

    const addrBits = bits - 7;
    for (let i = 0; i < addrBits; i++) {
      const bit = (address >> i) & 1;
      pattern.push(bit === 1 ? 1200 : 600);
      pattern.push(600);
    }

    const totalDurationMs = pattern.reduce((acc, val) => acc + val, 0) / 1000;
    const combined = (command & 0x7f) | ((address & ((1 << addrBits) - 1)) << 7);

    return {
      frequencyHz,
      patternMicros: pattern,
      hexRepresentation: `SONY_${bits} [Cmd:0x${command.toString(16).toUpperCase()} Addr:0x${address.toString(16).toUpperCase()}] => 0x${combined.toString(16).toUpperCase()}`,
      totalDurationMs: Math.round(totalDurationMs * 10) / 10,
      pulseCount: pattern.length,
    };
  }

  /**
   * Philips RC-5 Protocol (36kHz carrier, Manchester bi-phase encoding)
   */
  static encodeRc5(address: number, command: number, toggleBit = false): IrPatternResult {
    const frequencyHz = 36000;
    const halfBitMicros = 889; // 1.778ms / 2

    // 14 bits in RC5: Start bit 1 (1), Start bit 2 (1), Toggle bit (T), Address (5 bits), Command (6 bits)
    const bits: number[] = [
      1,
      1,
      toggleBit ? 1 : 0,
      (address >> 4) & 1,
      (address >> 3) & 1,
      (address >> 2) & 1,
      (address >> 1) & 1,
      address & 1,
      (command >> 5) & 1,
      (command >> 4) & 1,
      (command >> 3) & 1,
      (command >> 2) & 1,
      (command >> 1) & 1,
      command & 1,
    ];

    // Manchester encoding:
    // Bit 1: Space for halfBit, Mark for halfBit
    // Bit 0: Mark for halfBit, Space for halfBit
    // We synthesize continuous alternating mark/space chunks
    const halfUnits: { isMark: boolean; duration: number }[] = [];
    for (const b of bits) {
      if (b === 1) {
        halfUnits.push({ isMark: false, duration: halfBitMicros });
        halfUnits.push({ isMark: true, duration: halfBitMicros });
      } else {
        halfUnits.push({ isMark: true, duration: halfBitMicros });
        halfUnits.push({ isMark: false, duration: halfBitMicros });
      }
    }

    // Combine consecutive identical states
    const merged: { isMark: boolean; duration: number }[] = [];
    for (const unit of halfUnits) {
      if (merged.length > 0 && merged[merged.length - 1].isMark === unit.isMark) {
        merged[merged.length - 1].duration += unit.duration;
      } else {
        merged.push({ ...unit });
      }
    }

    // Android ConsumerIrManager expects the first element to be MARK (pulse)
    // If the first unit is space, drop it or shift
    const pattern: number[] = [];
    let startIdx = 0;
    if (!merged[0].isMark) {
      startIdx = 1;
    }
    for (let i = startIdx; i < merged.length; i++) {
      pattern.push(merged[i].duration);
    }

    const totalDurationMs = pattern.reduce((acc, val) => acc + val, 0) / 1000;
    return {
      frequencyHz,
      patternMicros: pattern,
      hexRepresentation: `RC5 [Addr:0x${address.toString(16).toUpperCase()} Cmd:0x${command.toString(16).toUpperCase()}]`,
      totalDurationMs: Math.round(totalDurationMs * 10) / 10,
      pulseCount: pattern.length,
    };
  }

  /**
   * Samsung 32-bit protocol (38kHz)
   */
  static encodeSamsung32(address: number, command: number): IrPatternResult {
    const frequencyHz = 38000;
    const pattern: number[] = [];

    // Header: 4500µs pulse, 4500µs space
    pattern.push(4500);
    pattern.push(4500);

    // 32-bit: Address 8-bit + Address 8-bit + Command 8-bit + Inverted Command 8-bit
    const addr = address & 0xff;
    const cmd = command & 0xff;
    const cmdInv = (~cmd) & 0xff;
    const data32 = (addr) | (addr << 8) | (cmd << 16) | (cmdInv << 24);

    for (let i = 0; i < 32; i++) {
      const bit = (data32 >> i) & 1;
      pattern.push(560);
      pattern.push(bit === 1 ? 1690 : 560);
    }
    pattern.push(560); // Stop bit

    const totalDurationMs = pattern.reduce((acc, val) => acc + val, 0) / 1000;
    return {
      frequencyHz,
      patternMicros: pattern,
      hexRepresentation: `SAMSUNG32 [Addr:0x${addr.toString(16).toUpperCase()} Cmd:0x${cmd.toString(16).toUpperCase()}] => 0x${((data32 >>> 0)).toString(16).toUpperCase()}`,
      totalDurationMs: Math.round(totalDurationMs * 10) / 10,
      pulseCount: pattern.length,
    };
  }

  /**
   * Pronto Hex Parser: converts standard 4-digit hex sequence into Android ConsumerIrManager timings
   * Format: 0000 <freqWord> <oncePairCount> <repeatPairCount> <pairs...>
   */
  static parseProntoHex(prontoStr: string): IrPatternResult {
    const tokens = prontoStr.trim().split(/\s+/).filter(Boolean);
    if (tokens.length < 4) {
      throw new Error('رمز Pronto Hex قصير جداً أو غير صالح');
    }

    const hexVals = tokens.map((t) => parseInt(t, 16));
    const preamble = hexVals[0];
    if (preamble !== 0) {
      // 0000 = Raw learned code
    }

    const freqWord = hexVals[1];
    // Frequency calculation: Carrier frequency = 1000000 / (freqWord * 0.241246)
    const frequencyHz = Math.round(1000000 / (freqWord * 0.241246)) || 38000;
    const timeBaseUs = 1000000 / frequencyHz;

    const oncePairs = hexVals[2];
    const repeatPairs = hexVals[3];
    const totalPairs = oncePairs + repeatPairs;

    const pattern: number[] = [];
    const dataStart = 4;
    const dataEnd = Math.min(hexVals.length, dataStart + totalPairs * 2);

    for (let i = dataStart; i < dataEnd; i++) {
      const micros = Math.round(hexVals[i] * timeBaseUs);
      pattern.push(micros);
    }

    const totalDurationMs = pattern.reduce((acc, val) => acc + val, 0) / 1000;

    return {
      frequencyHz,
      patternMicros: pattern,
      hexRepresentation: `PRONTO [${tokens.slice(0, 8).join(' ')}...]`,
      totalDurationMs: Math.round(totalDurationMs * 10) / 10,
      pulseCount: pattern.length,
    };
  }

  /**
   * Universal encoder for any protocol
   */
  static encode(
    protocol: IrProtocol,
    address: number,
    command: number,
    rawPronto?: string
  ): IrPatternResult {
    switch (protocol) {
      case 'SUNPLUS':
        return this.encodeSunplus(address, command);
      case 'NEC':
        return this.encodeNec(address, command, false);
      case 'NEC_EXTENDED':
        return this.encodeNec(address, command, true);
      case 'SONY_SIRC_12':
        return this.encodeSonySirc(command, address, 12);
      case 'SONY_SIRC_15':
        return this.encodeSonySirc(command, address, 15);
      case 'SONY_SIRC_20':
        return this.encodeSonySirc(command, address, 20);
      case 'RC5':
      case 'RC6':
        return this.encodeRc5(address, command);
      case 'SAMSUNG32':
        return this.encodeSamsung32(address, command);
      case 'PRONTO_HEX':
        if (rawPronto) {
          return this.parseProntoHex(rawPronto);
        }
        return this.encodeNec(address, command);
      default:
        return this.encodeNec(address, command);
    }
  }
}
