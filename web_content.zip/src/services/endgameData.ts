/**
 * Endgame Lessons Dataset
 * Verified endgame training modules with starting positions, goals, solutions, and hints.
 */

import { EndgameLesson } from '../types/chess';

export const ENDGAME_LESSONS: EndgameLesson[] = [
  {
    id: 'endgame-1',
    title: 'The Concept of Opposition',
    category: 'king_pawn',
    difficulty: 'Beginner',
    initialFen: '8/8/8/4k3/8/8/4K3/8 w - - 0 1',
    playerSide: 'w',
    targetGoal: 'Seize the direct vertical opposition by stepping directly facing the enemy king.',
    solutionMoves: ['e2e3'],
    hints: [
      'Opposition occurs when kings face each other with one square between them.',
      'Step forward on the same file as the Black king.'
    ],
    explanation: 'By playing 1. Ke3, White seizes the opposition! The opponent is now forced to give way either to the left or right, allowing your king to penetrate.'
  },
  {
    id: 'endgame-2',
    title: 'King & Pawn Promotion (Key Squares)',
    category: 'king_pawn',
    difficulty: 'Intermediate',
    initialFen: '8/8/8/8/3P4/3K4/8/3k4 w - - 0 1',
    playerSide: 'w',
    targetGoal: 'Escort your passed d-pawn to the 8th rank to promote into a Queen.',
    solutionMoves: ['d3e4', 'd1e2', 'd4d5'],
    hints: [
      'The king must lead the pawn, not hide behind it.',
      'Occupy the key square in front of the pawn.'
    ],
    explanation: 'Placing the King in front of the passed pawn controls the promotion path and secures an irreversible Queen promotion.'
  },
  {
    id: 'endgame-3',
    title: 'Rook & King Checkmate Pattern',
    category: 'checkmate_technique',
    difficulty: 'Beginner',
    initialFen: 'k7/8/1K6/8/8/8/8/R7 w - - 0 1',
    playerSide: 'w',
    targetGoal: 'Trap the enemy king on the edge of the board and deliver checkmate.',
    solutionMoves: ['a1a7'],
    hints: [
      'The enemy King is on the back rank and trapped by your King.',
      'Use the Rook to strike the rank or file.'
    ],
    explanation: 'Checkmate! The enemy king on a8 has nowhere to flee because White\'s king on b6 guards the escape squares a7, b7, and b8.'
  },
  {
    id: 'endgame-4',
    title: 'Queen vs King Box Confinement',
    category: 'checkmate_technique',
    difficulty: 'Beginner',
    initialFen: '8/8/8/3k4/8/8/4K3/Q7 w - - 0 1',
    playerSide: 'w',
    targetGoal: 'Shrink the box around the enemy king using the Queen.',
    solutionMoves: ['a1c3'],
    hints: [
      'Keep the Queen a knight\'s move away from the enemy king.',
      'Cut off the d-file and 4th rank simultaneously.'
    ],
    explanation: '1. Qc3 shrinks the invisible confinement box, severely limiting the Black king to the back ranks.'
  },
  {
    id: 'endgame-5',
    title: 'Lucena Position (Building a Bridge)',
    category: 'rook',
    difficulty: 'Advanced',
    initialFen: '1K1k4/1P6/8/8/8/8/7r/4R3 w - - 0 1',
    playerSide: 'w',
    targetGoal: 'Build the legendary bridge to shield your king from checks and promote the pawn.',
    solutionMoves: ['e1e4'],
    hints: [
      'The 4th rank is the magic springboard for building the Lucena bridge.',
      'Place your rook on the 4th rank so it can later intercept vertical checks.'
    ],
    explanation: '1. Re4! is the famous Lucena maneuver. The rook prepares to swing to d4, shielding the White king from the Black rook\'s vertical checks.'
  },
  {
    id: 'endgame-6',
    title: 'Philidor Defense (3rd Rank Barrier)',
    category: 'defense_draw',
    difficulty: 'Intermediate',
    initialFen: '8/8/8/3k4/3P4/2r5/8/4K1R1 b - - 0 1',
    playerSide: 'b',
    targetGoal: 'Hold the 3rd rank with your rook to prevent the enemy king from advancing.',
    solutionMoves: ['c3c6'],
    hints: [
      'Keep the rook on the 6th rank (White\'s 3rd rank) until the pawn pushes.',
      'Deny the White king from stepping into your territory.'
    ],
    explanation: 'The Philidor defense ensures a guaranteed draw! As long as the pawn hasn\'t pushed, the rook cuts off the enemy king.'
  },
];
