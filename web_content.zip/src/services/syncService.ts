/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Book,
  ReadingSession,
  BookQuote,
  Collection,
  ReadingGoal,
  AppSettings,
  ReadingActivity,
  CustomSticker,
} from '../types';
import { storage } from './storage';

export interface SyncPayload {
  version: string;
  schemaVersion: number;
  accountEmail: string;
  deviceId: string;
  deviceName: string;
  timestamp: string;
  data: {
    books: Book[];
    sessions: ReadingSession[];
    quotes: BookQuote[];
    collections: Collection[];
    goals: ReadingGoal[];
    activities: ReadingActivity[];
    stickers: CustomSticker[];
    settings?: AppSettings;
  };
}

export interface SyncStatus {
  lastSyncTime: string | null;
  accountEmail: string;
  syncState: 'idle' | 'syncing' | 'synced' | 'error';
  pendingChanges: number;
  lastMessage?: string;
}

const SYNC_STORAGE_KEY = 'mb_cloud_sync_state';
const CLOUD_RELAY_PREFIX = 'mb_cloud_relay_';

class SyncService {
  private deviceId: string;

  constructor() {
    this.deviceId = this.getOrCreateDeviceId();
  }

  private getOrCreateDeviceId(): string {
    const key = 'mb_device_id';
    let id = localStorage.getItem(key);
    if (!id) {
      id = 'dev-' + Math.random().toString(36).substring(2, 9) + '-' + Date.now().toString(36);
      localStorage.setItem(key, id);
    }
    return id;
  }

  public getDeviceId(): string {
    return this.deviceId;
  }

  public getSyncStatus(): SyncStatus {
    const saved = localStorage.getItem(SYNC_STORAGE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return {
      lastSyncTime: null,
      accountEmail: 'abigailcanales117@gmail.com',
      syncState: 'idle',
      pendingChanges: 0,
      lastMessage: 'Preparado para sincronizar entre dispositivos',
    };
  }

  public saveSyncStatus(status: SyncStatus): void {
    localStorage.setItem(SYNC_STORAGE_KEY, JSON.stringify(status));
  }

  /**
   * Generates a complete structured payload for synchronization across devices.
   * Strips large binary attachments like EPUB/PDF blobs to stay lightweight while keeping all metadata,
   * positions, highlights, notes, stickers, tags and reading progress.
   */
  public async generateSyncPayload(accountEmail: string): Promise<SyncPayload> {
    const [books, sessions, quotes, collections, goals, activities, stickers, settings] =
      await Promise.all([
        storage.getBooks(),
        storage.getSessions(),
        storage.getQuotes(),
        storage.getCollections(),
        storage.getGoals(),
        storage.getActivities(),
        storage.getStickers(),
        storage.getSettings(),
      ]);

    // Sanitize books to avoid syncing heavy raw dataUrl files while preserving reading position
    const sanitizedBooks: Book[] = books.map((b) => {
      const copy = { ...b };
      if (copy.fileAttachment?.dataUrl) {
        copy.fileAttachment = {
          ...copy.fileAttachment,
          dataUrl: undefined, // Keep attachment metadata without heavy binary
        };
      }
      return copy;
    });

    return {
      version: '4.0.0',
      schemaVersion: 2,
      accountEmail,
      deviceId: this.deviceId,
      deviceName: navigator.userAgent.includes('Mobile') ? 'Dispositivo Móvil' : 'Navegador Web',
      timestamp: new Date().toISOString(),
      data: {
        books: sanitizedBooks,
        sessions,
        quotes,
        collections,
        goals,
        activities,
        stickers,
        settings,
      },
    };
  }

  /**
   * Non-destructively merges incoming remote data with local data.
   * NEVER deletes local items that are absent in the incoming packet.
   */
  public async mergeIncomingSyncData(incoming: SyncPayload['data']): Promise<{
    mergedBooksCount: number;
    mergedSessionsCount: number;
    mergedQuotesCount: number;
  }> {
    const [localBooks, localSessions, localQuotes, localCollections, localGoals, localActivities, localStickers] =
      await Promise.all([
        storage.getBooks(),
        storage.getSessions(),
        storage.getQuotes(),
        storage.getCollections(),
        storage.getGoals(),
        storage.getActivities(),
        storage.getStickers(),
      ]);

    // 1. Merge Books non-destructively
    const bookMap = new Map<string, Book>();
    localBooks.forEach((b) => bookMap.set(b.id, b));

    incoming.books.forEach((remoteBook) => {
      const localBook = bookMap.get(remoteBook.id);
      if (!localBook) {
        bookMap.set(remoteBook.id, remoteBook);
      } else {
        // Merge book annotations and progress: choose highest read page or latest activity
        const higherPage = Math.max(localBook.pagesRead || 0, remoteBook.pagesRead || 0);
        const higherProgress = Math.max(localBook.progress || 0, remoteBook.progress || 0);

        // Merge bookmarks
        const bookmarkMap = new Map();
        (localBook.bookmarks || []).forEach((bm) => bookmarkMap.set(bm.id, bm));
        (remoteBook.bookmarks || []).forEach((bm) => bookmarkMap.set(bm.id, bm));

        // Merge highlights
        const highlightMap = new Map();
        (localBook.highlights || []).forEach((hl) => highlightMap.set(hl.id, hl));
        (remoteBook.highlights || []).forEach((hl) => highlightMap.set(hl.id, hl));

        // Merge annotations
        const annotationMap = new Map();
        (localBook.annotations || []).forEach((an) => annotationMap.set(an.id, an));
        (remoteBook.annotations || []).forEach((an) => annotationMap.set(an.id, an));

        // Merge tags
        const combinedTags = Array.from(new Set([...(localBook.tags || []), ...(remoteBook.tags || [])]));

        // Merge genres
        const combinedGenres = Array.from(new Set([...(localBook.genres || []), ...(remoteBook.genres || [])]));

        bookMap.set(remoteBook.id, {
          ...localBook,
          pagesRead: higherPage,
          progress: higherProgress,
          status: higherProgress >= 100 ? 'TERMINADO' : (higherPage > 0 ? 'LEYENDO' : localBook.status),
          favorite: localBook.favorite || remoteBook.favorite,
          tags: combinedTags,
          genres: combinedGenres,
          bookmarks: Array.from(bookmarkMap.values()),
          highlights: Array.from(highlightMap.values()),
          annotations: Array.from(annotationMap.values()),
          // Keep local attached files if remote has stripped them
          fileAttachment: localBook.fileAttachment || remoteBook.fileAttachment,
        });
      }
    });

    // 2. Merge Sessions (deduplicate by id)
    const sessionMap = new Map<string, ReadingSession>();
    localSessions.forEach((s) => sessionMap.set(s.id, s));
    incoming.sessions.forEach((s) => {
      if (!sessionMap.has(s.id)) {
        sessionMap.set(s.id, s);
      }
    });

    // 3. Merge Quotes (deduplicate by id)
    const quoteMap = new Map<string, BookQuote>();
    localQuotes.forEach((q) => quoteMap.set(q.id, q));
    incoming.quotes.forEach((q) => {
      if (!quoteMap.has(q.id)) {
        quoteMap.set(q.id, q);
      } else {
        const local = quoteMap.get(q.id)!;
        quoteMap.set(q.id, {
          ...local,
          favorite: local.favorite || q.favorite,
          reaction: q.reaction || local.reaction,
          customStickerId: q.customStickerId || local.customStickerId,
          customStickerUrl: q.customStickerUrl || local.customStickerUrl,
        });
      }
    });

    // 4. Merge Collections
    const collectionMap = new Map<string, Collection>();
    localCollections.forEach((c) => collectionMap.set(c.id, c));
    incoming.collections.forEach((c) => {
      if (!collectionMap.has(c.id)) {
        collectionMap.set(c.id, c);
      }
    });

    // 5. Merge Stickers
    const stickerMap = new Map<string, CustomSticker>();
    localStickers.forEach((stk) => stickerMap.set(stk.id, stk));
    incoming.stickers.forEach((stk) => {
      if (!stickerMap.has(stk.id)) {
        stickerMap.set(stk.id, stk);
      }
    });

    // 6. Merge Goals
    const goalMap = new Map<string, ReadingGoal>();
    localGoals.forEach((g) => goalMap.set(g.id, g));
    incoming.goals.forEach((g) => {
      if (!goalMap.has(g.id)) {
        goalMap.set(g.id, g);
      }
    });

    // Save all merged data to local storage
    const mergedBooks = Array.from(bookMap.values());
    const mergedSessions = Array.from(sessionMap.values());
    const mergedQuotes = Array.from(quoteMap.values());
    const mergedCollections = Array.from(collectionMap.values());
    const mergedStickers = Array.from(stickerMap.values());
    const mergedGoals = Array.from(goalMap.values());

    for (const b of mergedBooks) await storage.saveBook(b);
    for (const s of mergedSessions) await storage.saveSession(s);
    for (const q of mergedQuotes) await storage.saveQuote(q);
    for (const c of mergedCollections) await storage.saveCollection(c);
    for (const st of mergedStickers) await storage.saveSticker(st);
    for (const g of mergedGoals) await storage.saveGoal(g);

    return {
      mergedBooksCount: mergedBooks.length,
      mergedSessionsCount: mergedSessions.length,
      mergedQuotesCount: mergedQuotes.length,
    };
  }

  /**
   * Executes a synchronization pass:
   * 1. Prepares local payload
   * 2. Checks relay / remote cache for the given account
   * 3. Merges remote updates non-destructively
   * 4. Updates relay with new merged state
   * 5. Returns sync summary
   */
  public async performSync(accountEmail: string): Promise<{
    success: boolean;
    message: string;
    syncedAt: string;
  }> {
    try {
      const email = accountEmail.trim().toLowerCase();
      const localPayload = await this.generateSyncPayload(email);

      // Check remote cloud relay simulated storage
      const relayKey = CLOUD_RELAY_PREFIX + encodeURIComponent(email);
      const rawRemote = localStorage.getItem(relayKey);

      if (rawRemote) {
        try {
          const remotePayload: SyncPayload = JSON.parse(rawRemote);
          if (remotePayload.data) {
            await this.mergeIncomingSyncData(remotePayload.data);
          }
        } catch (e) {
          console.warn('Failed to parse remote sync packet:', e);
        }
      }

      // Re-generate fresh consolidated payload to publish to cloud relay
      const updatedConsolidated = await this.generateSyncPayload(email);
      localStorage.setItem(relayKey, JSON.stringify(updatedConsolidated));

      const now = new Date().toISOString();
      const status: SyncStatus = {
        lastSyncTime: now,
        accountEmail: email,
        syncState: 'synced',
        pendingChanges: 0,
        lastMessage: 'Sincronizado con éxito. Todos tus datos están al día.',
      };
      this.saveSyncStatus(status);

      return {
        success: true,
        message: 'Biblioteca sincronizada con tu cuenta correctamente.',
        syncedAt: now,
      };
    } catch (err: any) {
      console.error('Error during synchronization:', err);
      const status: SyncStatus = {
        ...this.getSyncStatus(),
        syncState: 'error',
        lastMessage: 'Error de sincronización: ' + (err.message || 'Error desconocido'),
      };
      this.saveSyncStatus(status);
      return {
        success: false,
        message: 'No se pudo completar la sincronización.',
        syncedAt: new Date().toISOString(),
      };
    }
  }
}

export const syncService = new SyncService();
