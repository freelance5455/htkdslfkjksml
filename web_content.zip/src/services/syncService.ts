import { HebrewEvent, LocationPreset, SyncState, UserSettings } from '../types';
import { getUpcomingHebrewEventOccurrences, DEFAULT_SETTINGS } from './hebrewCalendarService';

const STORAGE_EVENTS_KEY = 'hebrew_calendar_user_events';
const STORAGE_SETTINGS_KEY = 'hebrew_calendar_user_settings';
const STORAGE_SYNC_KEY = 'hebrew_calendar_sync_state';

export function loadLocalSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(STORAGE_SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      location: { ...DEFAULT_SETTINGS.location, ...(parsed.location || {}) },
      zmanim: { ...DEFAULT_SETTINGS.zmanim, ...(parsed.zmanim || {}) },
      notifications: { ...DEFAULT_SETTINGS.notifications, ...(parsed.notifications || {}) },
      display: { ...DEFAULT_SETTINGS.display, ...(parsed.display || {}) },
    };
  } catch (err) {
    console.error('Failed to load local settings', err);
    return DEFAULT_SETTINGS;
  }
}

export function saveLocalSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(STORAGE_SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save local settings', err);
  }
}

export interface CalendarSyncPayload {
  events: HebrewEvent[];
  settings: Partial<UserSettings>;
  timestamp: number;
  deviceName: string;
}

export function loadLocalEvents(): HebrewEvent[] {
  try {
    const raw = localStorage.getItem(STORAGE_EVENTS_KEY);
    if (!raw) {
      // Seed default sample events for new users
      const sampleEvents: HebrewEvent[] = [
        {
          id: 'sample_birthday',
          title: 'Mom’s Hebrew Birthday',
          hebrewTitle: 'יוֹם הוּלֶּדֶת לְאִמָּא',
          type: 'birthday',
          hebrewDay: 15,
          hebrewMonth: 1, // Nisan
          hebrewMonthName: 'Nisan',
          hebrewYear: 5783,
          startHebrewYear: 5783,
          showCounter: true,
          counterStart: 1,
          recurrence: 'hebrew-annual',
          leapYearRule: 'adar2',
          notes: 'Prepare special family meal and blessing.',
          color: '#f59e0b',
          enableReminder: true,
          reminderDaysBefore: 1,
          createdAt: Date.now() - 1000000,
          updatedAt: Date.now(),
        },
        {
          id: 'sample_yahrzeit',
          title: 'Grandfather’s Yahrzeit (Saba David)',
          hebrewTitle: 'יוֹם הַזִּכָּרוֹן לְסַבָּא דָּוִד ז״ל',
          type: 'yahrzeit',
          hebrewDay: 7,
          hebrewMonth: 6, // Elul
          hebrewMonthName: 'Elul',
          hebrewYear: 5765,
          recurrence: 'hebrew-annual',
          leapYearRule: 'adar2',
          candleLighting: true,
          notes: 'Light 24-hour Yahrzeit memorial candle at sunset and recite Kaddish.',
          color: '#3b82f6',
          enableReminder: true,
          reminderDaysBefore: 1,
          createdAt: Date.now() - 500000,
          updatedAt: Date.now(),
        },
      ];
      saveLocalEvents(sampleEvents);
      return sampleEvents;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to load local events', err);
    return [];
  }
}

export function saveLocalEvents(events: HebrewEvent[]): void {
  try {
    localStorage.setItem(STORAGE_EVENTS_KEY, JSON.stringify(events));
  } catch (err) {
    console.error('Failed to save local events', err);
  }
}

export function loadLocalSyncState(): SyncState {
  try {
    const raw = localStorage.getItem(STORAGE_SYNC_KEY);
    if (!raw) {
      const defaultState: SyncState = {
        roomId: '',
        roomPin: '',
        isConnected: false,
        lastSyncedAt: null,
        deviceName: getDeviceDefaultName(),
        status: 'idle',
      };
      return defaultState;
    }
    return JSON.parse(raw);
  } catch {
    return {
      roomId: '',
      roomPin: '',
      isConnected: false,
      lastSyncedAt: null,
      deviceName: getDeviceDefaultName(),
      status: 'idle',
    };
  }
}

export function saveLocalSyncState(state: SyncState): void {
  try {
    localStorage.setItem(STORAGE_SYNC_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to save sync state', err);
  }
}

export function getDeviceDefaultName(): string {
  const ua = navigator.userAgent;
  if (/iPad|iPhone|iPod/.test(ua)) return 'iPhone / iPad';
  if (/Android/.test(ua)) return 'Android Device';
  if (/Macintosh/.test(ua)) return 'Mac Desktop';
  if (/Windows/.test(ua)) return 'Windows PC';
  if (/Linux/.test(ua)) return 'Linux Device';
  return 'Web Device';
}

/**
 * Generate 6-character random uppercase alphanumeric sync room ID
 */
export function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

/**
 * Push personal calendar events and settings to the multi-device sync backend
 */
export async function pushCalendarToCloud(
  roomId: string,
  roomPin: string,
  events: HebrewEvent[],
  settings: Partial<UserSettings>,
  deviceName: string
): Promise<{ success: boolean; error?: string; timestamp?: number }> {
  try {
    const payload: CalendarSyncPayload = {
      events,
      settings,
      timestamp: Date.now(),
      deviceName,
    };

    const res = await fetch(`/api/sync/room/${encodeURIComponent(roomId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pin: roomPin,
        data: payload,
      }),
    });

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      return {
        success: false,
        error: data.error || `Server responded with status ${res.status}`,
      };
    }

    const json = await res.json();
    return { success: true, timestamp: json.timestamp || Date.now() };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network connection failed' };
  }
}

/**
 * Pull calendar events and settings from multi-device sync backend
 */
export async function pullCalendarFromCloud(
  roomId: string,
  roomPin: string
): Promise<{ success: boolean; data?: CalendarSyncPayload; error?: string }> {
  try {
    const res = await fetch(
      `/api/sync/room/${encodeURIComponent(roomId)}?pin=${encodeURIComponent(roomPin)}`,
      {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      }
    );

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      return {
        success: false,
        error: data.error || `Server responded with status ${res.status}`,
      };
    }

    const json = await res.json();
    return { success: true, data: json.data };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network connection failed' };
  }
}

/**
 * Generate standard iCalendar (.ics) format file string for personal Hebrew events
 */
export function generateICalFile(events: HebrewEvent[], location: LocationPreset): string {
  const lines: string[] = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Hebrew Calendar App//Hebrew Recurring Events//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'X-WR-CALNAME:Hebrew Calendar Personal Events',
    'X-WR-TIMEZONE:' + location.timezone,
  ];

  const nowStr = formatICalDate(new Date());

  events.forEach((ev) => {
    // Generate next 5 years occurrences
    const occurrences = getUpcomingHebrewEventOccurrences(ev, 5);

    occurrences.forEach((occ, idx) => {
      const startD = occ.gregorianDate;
      const endD = new Date(startD);
      endD.setDate(endD.getDate() + 1);

      const uid = `hebrew_ev_${ev.id}_${occ.hebrewYear}_${idx}@hebrewcalendar.app`;
      const dateStart = formatICalDateOnly(startD);
      const dateEnd = formatICalDateOnly(endD);

      lines.push('BEGIN:VEVENT');
      lines.push(`UID:${uid}`);
      lines.push(`DTSTAMP:${nowStr}`);
      lines.push(`DTSTART;VALUE=DATE:${dateStart}`);
      lines.push(`DTEND;VALUE=DATE:${dateEnd}`);
      lines.push(`SUMMARY:${escapeICalText(ev.title)} (${escapeICalText(occ.hebrewDateStr)})`);

      let desc = `Hebrew Event: ${ev.title}\\nType: ${ev.type.toUpperCase()}\\nHebrew Date: ${occ.hebrewDateStr}`;
      if (ev.hebrewTitle) desc += `\\nIn Hebrew: ${ev.hebrewTitle}`;
      if (ev.notes) desc += `\\nNotes: ${ev.notes}`;
      if (ev.candleLighting) desc += `\\n* Light 24-hour memorial candle at sunset the evening prior.`;

      lines.push(`DESCRIPTION:${escapeICalText(desc)}`);

      if (ev.enableReminder) {
        lines.push('BEGIN:VALARM');
        lines.push('ACTION:DISPLAY');
        lines.push(`DESCRIPTION:Reminder: ${escapeICalText(ev.title)}`);
        lines.push(`TRIGGER:-P${ev.reminderDaysBefore || 0}DT9H0M0S`); // 9:00 AM on morning/day before
        lines.push('END:VALARM');
      }

      lines.push('END:VEVENT');
    });
  });

  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
}

function formatICalDate(date: Date): string {
  return date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
}

function formatICalDateOnly(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}${m}${d}`;
}

function escapeICalText(text: string): string {
  return text.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,');
}

/**
 * Trigger file download in browser
 */
export function downloadFile(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
