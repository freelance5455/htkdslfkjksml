import { DailyVerse } from '../types';

export const DAILY_VERSES_COLLECTION: DailyVerse[] = [
  {
    id: 'shema-1',
    source: 'Deuteronomy 6:4',
    sourceHe: 'דְּבָרִים ו׳:ד׳',
    category: 'torah',
    hebrew: 'שְׁמַע יִשְׂרָאֵל יְהוָה אֱלֹהֵינוּ יְהוָה אֶחָד:',
    transliteration: 'Shema Yisrael, Adonai Eloheinu, Adonai Echad.',
    english: 'Hear, O Israel: The LORD our God, the LORD is One.',
    theme: 'Core Unity & Faith',
    practicalTakeaway: 'Take a moment today to focus your intention on unity, gratitude, and divine presence in every detail of life.',
  },
  {
    id: 'tehillim-23-1',
    source: 'Psalms 23:1-2',
    sourceHe: 'תְּהִלִּים כ״ג:א׳-ב׳',
    category: 'psalms',
    hebrew: 'מִזְמוֹר לְדָוִד יְהוָה רֹעִי לֹא אֶחְסָר: בִּנְאוֹת דֶּשֶׁא יַרְבִּיצֵנִי עַל מֵי מְנֻחוֹת יְנַהֲלֵנִי:',
    transliteration: 'Mizmor leDavid: Adonai ro’i, lo echsar. Bin’ot deshe yarbitzeni, al mei menuchot yenahaleni.',
    english: 'A psalm of David: The LORD is my shepherd; I shall not lack. In green pastures He makes me lie down; He leads me beside still waters.',
    theme: 'Serenity & Trust (Bitachon)',
    practicalTakeaway: 'Release tension over outcomes beyond your control; trust that guidance and sustenance accompany you step by step.',
  },
  {
    id: 'avot-1-14',
    source: 'Pirkei Avot 1:14',
    sourceHe: 'פִּרְקֵי אָבוֹת א׳:י״ד',
    category: 'pirkei_avot',
    hebrew: 'הוּא הָיָה אוֹמֵר: אִם אֵין אֲנִי לִי, מִי לִי? וּכְשֶׁאֲנִי לְעַצְמִי, מָה אֲנִי? וְאִם לֹא עַכְשָׁיו, אֵימָתָי?',
    transliteration: 'Hu haya omer: Im ein ani li, mi li? U’keshe’ani l’atzmi, mah ani? V’im lo achshav, eimatai?',
    english: 'He used to say: If I am not for myself, who will be for me? But when I am only for myself, what am I? And if not now, when?',
    theme: 'Personal Responsibility & Action',
    practicalTakeaway: 'Find balance today between healthy self-care, selfless kindness to others, and taking positive action without procrastination.',
  },
  {
    id: 'tehillim-121-1',
    source: 'Psalms 121:1-2',
    sourceHe: 'תְּהִלִּים קכ״א:א׳-ב׳',
    category: 'psalms',
    hebrew: 'שִׁיר לַמַּעֲלוֹת: אֶשָּׂא עֵינַי אֶל הֶהָרִים מֵאַיִן יָבֹא עֶזְרִי: עֶזְרִי מֵעִם יְהוָה עֹשֵׂה שָׁמַיִם וָאָרֶץ:',
    transliteration: 'Shir lama’alot: Esa einai el heharim, me’ayin yavo ezri? Ezri me’im Adonai, oseh shamayim va’aretz.',
    english: 'A song of ascents: I lift up my eyes to the mountains—from where will my help come? My help comes from the LORD, Maker of heaven and earth.',
    theme: 'Divine Protection',
    practicalTakeaway: 'Whenever challenges seem overwhelming, lift your gaze above the immediate horizon and seek strength from above.',
  },
  {
    id: 'mishlei-3-5',
    source: 'Proverbs 3:5-6',
    sourceHe: 'מִשְׁלֵי ג׳:ה׳-ו׳',
    category: 'proverbs',
    hebrew: 'בְּטַח אֶל יְהוָה בְּכָל לִבֶּךָ וְאֶל בִּינָתְךָ אַל תִּשָּׁעֵן: בְּכָל דְּרָכֶיךָ דָעֵהוּ וְהוּא יְיַשֵּׁר אֹרְחֹתֶיךָ:',
    transliteration: 'Betach el Adonai bechol libecha, v’el binatecha al tisha’en. Bechol derachecha da’ehu, v’hu yeyasher orchotecha.',
    english: 'Trust in the LORD with all your heart, and do not rely on your own understanding. In all your ways acknowledge Him, and He will make your paths straight.',
    theme: 'Inner Guidance',
    practicalTakeaway: 'Infuse your everyday routines and career work with noble purpose and mindful integrity.',
  },
  {
    id: 'torah-love-neighbor',
    source: 'Leviticus 19:18',
    sourceHe: 'וַיִּקְרָא י״ט:י״ח',
    category: 'torah',
    hebrew: 'וְאָהַבְתָּ לְרֵעֲךָ כָּמוֹךָ אֲנִי יְהוָה:',
    transliteration: 'V’ahavta l’re’acha kamocha, Ani Adonai.',
    english: 'You shall love your neighbor as yourself: I am the LORD.',
    theme: 'Unconditional Compassion (Ahavat Yisrael)',
    practicalTakeaway: 'Perform an unexpected act of generosity, empathy, or warm encouragement for someone near you today.',
  },
  {
    id: 'avot-2-16',
    source: 'Pirkei Avot 2:16',
    sourceHe: 'פִּרְקֵי אָבוֹת ב׳:ט״ז',
    category: 'pirkei_avot',
    hebrew: 'לֹא עָלֶיךָ הַמְּלָאכָה לִגְמוֹר, וְלֹא אַתָּה בֶן חוֹרִין לִבָּטֵל מִמֶּנָּה:',
    transliteration: 'Lo alecha hamlacha ligmor, v’lo ata ven chorin l’hivatel mimena.',
    english: 'It is not your duty to finish the work, but neither are you free to desist from it.',
    theme: 'Perseverance & Meaningful Contribution',
    practicalTakeaway: 'Do not be discouraged by the magnitude of long-term goals. Every genuine small step advances the world.',
  },
  {
    id: 'tehillim-34-15',
    source: 'Psalms 34:15',
    sourceHe: 'תְּהִלִּים ל״ד:ט״ו',
    category: 'psalms',
    hebrew: 'סוּר מֵרָע וַעֲשֵׂה טוֹב בַּקֵּשׁ שָׁלוֹם וְרָדְפֵהוּ:',
    transliteration: 'Sur meira va’aseh tov, bakesh shalom v’rodfehu.',
    english: 'Depart from evil and do good; seek peace and pursue it.',
    theme: 'Pursuit of Peace (Shalom)',
    practicalTakeaway: 'Choose reconciliation over winning an argument. Actively cultivate tranquility at home and at work.',
  },
  {
    id: 'isaiah-40-31',
    source: 'Isaiah 40:31',
    sourceHe: 'יְשַׁעְיָהוּ מ׳:ל״א',
    category: 'prophets',
    hebrew: 'וְקוֹיֵ יְהוָה יַחֲלִיפוּ כֹחַ יַעֲלוּ אֵבֶר כַּנְּשָׁרִים יָרוּצוּ וְלֹא יִיגָעוּ יֵלְכוּ וְלֹא יִיעָפוּ:',
    transliteration: 'V’koyei Adonai yachalifu cho’ach, ya’alu ever kanesharim, yarutzu v’lo yiga’u, yelchu v’lo yi’afu.',
    english: 'Those who hope in the LORD will renew their strength. They will soar on wings like eagles; they will run and not grow weary, they will walk and not be faint.',
    theme: 'Spiritual Renewal',
    practicalTakeaway: 'Recharge your spiritual energy through quiet reflection, prayer, or connecting with nature.',
  },
  {
    id: 'tehillim-118-24',
    source: 'Psalms 118:24',
    sourceHe: 'תְּהִלִּים קי״ח:כ״ד',
    category: 'psalms',
    hebrew: 'זֶה הַיּוֹם עָשָׂה יְהוָה נָגִילָה וְנִשְׂמְחָה בוֹ:',
    transliteration: 'Zeh hayom asa Adonai, nagila v’nismecha vo.',
    english: 'This is the day the LORD has made; let us rejoice and be glad in it.',
    theme: 'Joy of the Present Moment',
    practicalTakeaway: 'Greet this day as a unique, non-repeatable gift. Find joy in simple daily blessings.',
  },
  {
    id: 'micah-6-8',
    source: 'Micah 6:8',
    sourceHe: 'מִיכָה ו׳:ח׳',
    category: 'prophets',
    hebrew: 'הִגִּיד לְךָ אָדָם מַה טּוֹב וּמָה יְהוָה דּוֹרֵשׁ מִמְּךָ כִּי אִם עֲשׂוֹת מִשְׁפָּט וְאַהֲבַת חֶסֶד וְהַצְנֵעַ לֶכֶת עִם אֱלֹהֶיךָ:',
    transliteration: 'Higid lecha adam mah tov, u’mah Adonai doresh mimcha: ki im asot mishpat v’ahavat chesed, v’hatzne’a lechet im Elohecha.',
    english: 'He has told you, O mortal, what is good and what the LORD requires of you: Only to do justice, to love loving-kindness, and to walk humbly with your God.',
    theme: 'Justice, Kindness & Humility',
    practicalTakeaway: 'Practice fairness, treat everyone with gentle warmth, and let humility guide your decisions today.',
  },
  {
    id: 'avot-4-1',
    source: 'Pirkei Avot 4:1',
    sourceHe: 'פִּרְקֵי אָבוֹת ד׳:א׳',
    category: 'pirkei_avot',
    hebrew: 'אֵיזֶהוּ חָכָם? הַלּוֹמֵד מִכָּל אָדָם. אֵיזֶהוּ גִּבּוֹר? הַכּוֹבֵשׁ אֶת יִצְרוֹ. אֵיזֶהוּ עָשִׁיר? הַשָּׂמֵחַ בְּחֶלְקוֹ.',
    transliteration: 'Eizehu chacham? Halomed mikol adam. Eizehu gibor? Hakovesh et yitzro. Eizehu ashir? Hasame’ach bechelko.',
    english: 'Who is wise? One who learns from every person. Who is strong? One who conquers his impulses. Who is rich? One who rejoices in their portion.',
    theme: 'True Wealth & Wisdom',
    practicalTakeaway: 'Listen attentively to someone with a different perspective today, and express sincere gratitude for what you currently have.',
  },
];

/**
 * Returns daily verse according to date key
 */
export function getDailyVerseForDate(date: Date = new Date()): DailyVerse {
  const startOfYear = new Date(date.getFullYear(), 0, 1);
  const diffDays = Math.floor((date.getTime() - startOfYear.getTime()) / (1000 * 60 * 60 * 24));
  const index = Math.abs(diffDays) % DAILY_VERSES_COLLECTION.length;
  return DAILY_VERSES_COLLECTION[index];
}

export function getRandomVerse(): DailyVerse {
  const index = Math.floor(Math.random() * DAILY_VERSES_COLLECTION.length);
  return DAILY_VERSES_COLLECTION[index];
}
