import { Project, ExportSettings, ExportedProjectRecord } from '../types/editor';
import { VideoRenderer } from './videoRenderer';
import { storageService } from './storage';

export interface ExportProgress {
  frame: number;
  totalFrames: number;
  percent: number;
  timeRemainingSec: number;
}

export class ExportEngine {
  private isCancelled = false;

  cancel() {
    this.isCancelled = true;
  }

  async exportProject(
    project: Project,
    settings: ExportSettings,
    isPremium: boolean,
    onProgress: (prog: ExportProgress) => void
  ): Promise<ExportedProjectRecord> {
    this.isCancelled = false;

    // Create rendering canvas
    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = settings.width;
    exportCanvas.height = settings.height;

    const renderer = new VideoRenderer(exportCanvas);
    renderer.setSize(settings.width, settings.height);

    const fps = settings.fps || 30;
    const duration = project.duration || 5;
    const totalFrames = Math.max(1, Math.floor(duration * fps));

    // Determine bitrate
    let bitsPerSecond = 5000000;
    if (settings.bitratePreset === 'low') bitsPerSecond = 2000000;
    else if (settings.bitratePreset === 'medium') bitsPerSecond = 5000000;
    else if (settings.bitratePreset === 'high') bitsPerSecond = 10000000;
    else if (settings.bitratePreset === 'very-high') bitsPerSecond = 25000000;
    else if (settings.customBitrateMbps) bitsPerSecond = settings.customBitrateMbps * 1000000;

    if (settings.resolution === '4k') bitsPerSecond = Math.max(bitsPerSecond, 30000000);
    if (settings.resolution === '8k') bitsPerSecond = Math.max(bitsPerSecond, 60000000);

    const stream = exportCanvas.captureStream(fps);

    // Audio mixing into export stream
    let combinedStream: MediaStream = stream;
    let audioCtx: AudioContext | null = null;

    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtx = new AudioCtx();
      const dest = audioCtx.createMediaStreamDestination();

      const audioClips = project.clips.filter(c => (c.type === 'audio' || (c.type === 'video' && !c.muted)) && (c.sourceUrl || c.blob));
      for (const clip of audioClips) {
        try {
          let arrayBuf: ArrayBuffer;
          if (clip.blob) {
            arrayBuf = await clip.blob.arrayBuffer();
          } else if (clip.sourceUrl && clip.sourceUrl.trim() !== '') {
            const res = await fetch(clip.sourceUrl);
            if (!res.ok) continue;
            arrayBuf = await res.arrayBuffer();
          } else {
            continue;
          }
          const decoded = await audioCtx.decodeAudioData(arrayBuf);
          const source = audioCtx.createBufferSource();
          source.buffer = decoded;
          const gain = audioCtx.createGain();
          gain.gain.value = clip.volume || 1.0;
          source.connect(gain);
          gain.connect(dest);
          const startTime = Math.max(0, audioCtx.currentTime + clip.start);
          const offset = Math.min(Math.max(0, clip.sourceStart || 0), decoded.duration - 0.05);
          source.start(startTime, offset, clip.duration);
        } catch (err) {
          // Continue if single clip audio fails
        }
      }

      if (dest.stream.getAudioTracks().length > 0) {
        const combinedTracks = [...stream.getVideoTracks(), ...dest.stream.getAudioTracks()];
        combinedStream = new MediaStream(combinedTracks);
      }
    } catch (e) {
      // Audio mixing fallback
    }

    // Determine supported mimeType safely
    const possibleMimeTypes = [
      'video/webm; codecs=vp9,opus',
      'video/webm; codecs=vp8,opus',
      'video/webm',
      'video/mp4; codecs=avc1,mp4a.40.2',
      'video/mp4',
    ];

    let chosenMimeType = '';
    if (typeof MediaRecorder.isTypeSupported === 'function') {
      for (const mime of possibleMimeTypes) {
        if (MediaRecorder.isTypeSupported(mime)) {
          chosenMimeType = mime;
          break;
        }
      }
    }

    const recorderOptions: MediaRecorderOptions = {
      videoBitsPerSecond: bitsPerSecond,
    };
    if (chosenMimeType) {
      recorderOptions.mimeType = chosenMimeType;
    }

    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(combinedStream, recorderOptions);
    } catch (e) {
      // Fallback without options
      recorder = new MediaRecorder(combinedStream);
    }

    const recordedChunks: Blob[] = [];
    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) recordedChunks.push(e.data);
    };

    return new Promise(async (resolve, reject) => {
      recorder.onstop = async () => {
        if (audioCtx) {
          audioCtx.close().catch(() => {});
        }
        if (this.isCancelled) {
          return reject(new Error('Export was cancelled by user.'));
        }

        const mime = recorder.mimeType || 'video/mp4';
        const finalBlob = new Blob(recordedChunks, { type: mime });
        const videoUrl = URL.createObjectURL(finalBlob);

        const record: ExportedProjectRecord = {
          id: `export_${Date.now()}`,
          projectId: project.id,
          projectName: project.name,
          videoUrl,
          timestamp: Date.now(),
          duration: project.duration,
          fileSize: finalBlob.size,
          resolution: `${settings.width}x${settings.height} (${settings.resolution.toUpperCase()})`,
          fps: settings.fps,
        };

        // Save to IndexedDB
        await storageService.saveExportRecord(record, finalBlob);
        resolve(record);
      };

      try {
        recorder.start();
      } catch (e) {
        reject(e);
        return;
      }

      const startTime = performance.now();

      // Render frame by frame
      for (let frame = 0; frame < totalFrames; frame++) {
        if (this.isCancelled) {
          try { recorder.stop(); } catch (e) {}
          return;
        }

        const currentTime = frame / fps;
        renderer.renderFrame(project, currentTime, isPremium || !settings.includeWatermark);

        // Progress calculation
        const percent = Math.floor(((frame + 1) / totalFrames) * 100);
        const elapsed = (performance.now() - startTime) / 1000;
        const framesPerSec = (frame + 1) / Math.max(0.001, elapsed);
        const remainingFrames = totalFrames - (frame + 1);
        const timeRemainingSec = framesPerSec > 0 ? Math.ceil(remainingFrames / framesPerSec) : 0;

        onProgress({
          frame: frame + 1,
          totalFrames,
          percent,
          timeRemainingSec,
        });

        await new Promise(r => setTimeout(r, Math.max(10, 1000 / fps)));
      }

      // Finish recording
      setTimeout(() => {
        try {
          if (recorder.state === 'recording') {
            recorder.stop();
          }
        } catch (e) {
          reject(e);
        }
      }, 250);
    });
  }
}

export const exportEngine = new ExportEngine();
