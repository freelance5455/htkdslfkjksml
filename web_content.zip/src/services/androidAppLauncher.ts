/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * 002 AI — PHASE 3: FUTURE ANDROID INTEGRATION ARCHITECTURE
 * Official Native Android App Launcher & Intent Bridge Architecture.
 * 
 * SECURITY & GOOGLE PLAY POLICY COMPLIANCE:
 * 1. This architecture prepares the modular interface for the future native Android APK.
 * 2. It strictly enforces standard Android Intent contracts:
 *    - Uses `PackageManager.getLaunchIntentForPackage(packageName)`
 *    - Uses explicit `Intent.ACTION_VIEW` with `Uri.parse(url)` for browser navigation
 * 3. Never attempts to launch native phone apps directly from the web client.
 * 4. Never bypasses Android OS runtime permission dialogs.
 * 5. Never executes hidden background actions or device takeovers.
 * 6. Complies fully with Google Play policies on Accessibility and App Visibility (Android 11+ QUERY_ALL_PACKAGES policy).
 */

export interface AndroidAppIntentSpec {
  id: string;
  displayName: string;
  packageName: string;
  category: 'media' | 'utility' | 'navigation' | 'communication' | 'productivity';
  fallbackWebUrl: string;
  intentAction?: string;
  flags?: string[];
  description: string;
}

export interface LaunchResult {
  success: boolean;
  channel: 'native-android-intent' | 'web-browser-fallback' | 'simulated-preview';
  message: string;
  timestamp: string;
}

/**
 * Standard registry of curated apps for official Android launch intents.
 */
export const OFFICIAL_APP_REGISTRY: AndroidAppIntentSpec[] = [
  {
    id: 'youtube',
    displayName: 'YouTube',
    packageName: 'com.google.android.youtube',
    category: 'media',
    fallbackWebUrl: 'https://www.youtube.com',
    intentAction: 'android.intent.action.MAIN',
    description: 'Launches YouTube video player via official package intent',
  },
  {
    id: 'spotify',
    displayName: 'Spotify Music',
    packageName: 'com.spotify.music',
    category: 'media',
    fallbackWebUrl: 'https://open.spotify.com',
    intentAction: 'android.intent.action.MAIN',
    description: 'Launches Spotify music player via official package intent',
  },
  {
    id: 'google-maps',
    displayName: 'Google Maps',
    packageName: 'com.google.android.apps.maps',
    category: 'navigation',
    fallbackWebUrl: 'https://maps.google.com',
    intentAction: 'android.intent.action.VIEW',
    description: 'Opens Google Maps navigation and location services',
  },
  {
    id: 'chrome-browser',
    displayName: 'Google Chrome / Browser',
    packageName: 'com.android.chrome',
    category: 'productivity',
    fallbackWebUrl: 'https://www.google.com',
    intentAction: 'android.intent.action.VIEW',
    description: 'Opens standard web browser via ACTION_VIEW intent',
  },
  {
    id: 'clock',
    displayName: 'Clock & Alarms',
    packageName: 'com.google.android.deskclock',
    category: 'utility',
    fallbackWebUrl: 'https://time.is',
    intentAction: 'android.intent.action.SHOW_ALARMS',
    description: 'Opens device clock and alarm dashboard',
  },
  {
    id: 'calculator',
    displayName: 'Calculator',
    packageName: 'com.google.android.calculator',
    category: 'utility',
    fallbackWebUrl: 'https://www.google.com/search?q=calculator',
    intentAction: 'android.intent.action.MAIN',
    description: 'Launches native Android calculator utility',
  },
];

/**
 * Kotlin / Android Native Interface Contract
 * This interface represents the `@JavascriptInterface` bridge exposed in the Android WebView.
 */
export interface AndroidNativeHostInterface {
  isNativeAndroidHost(): boolean;
  launchPackage(packageName: string): boolean;
  openBrowserUrl(url: string): boolean;
  canLaunchPackage(packageName: string): boolean;
  getAndroidApiLevel(): number;
}

declare global {
  interface Window {
    Android002Host?: AndroidNativeHostInterface;
  }
}

export class AndroidAppLauncherService {
  /**
   * Checks if the app is currently running inside the native Android companion shell.
   */
  isNativeAndroidEnvironment(): boolean {
    return typeof window !== 'undefined' && Boolean(window.Android002Host?.isNativeAndroidHost?.());
  }

  /**
   * Verifies if a given app package can be launched.
   */
  async canLaunchPackage(packageName: string): Promise<boolean> {
    if (this.isNativeAndroidEnvironment() && window.Android002Host) {
      return window.Android002Host.canLaunchPackage(packageName);
    }
    // In web preview, apps are handled via browser fallback
    return false;
  }

  /**
   * Dispatches app launch request.
   * If running in native Android shell, calls official package manager intent.
   * If running on web, routes safely to official web URL.
   */
  async launchAppOrUrl(appId: string): Promise<LaunchResult> {
    const app = OFFICIAL_APP_REGISTRY.find(a => a.id === appId);
    if (!app) {
      return {
        success: false,
        channel: 'web-browser-fallback',
        message: `Unknown application ID: ${appId}`,
        timestamp: new Date().toLocaleTimeString(),
      };
    }

    // 1. Native Android Execution Path
    if (this.isNativeAndroidEnvironment() && window.Android002Host) {
      const launched = window.Android002Host.launchPackage(app.packageName);
      if (launched) {
        return {
          success: true,
          channel: 'native-android-intent',
          message: `Dispatched native Android Intent for ${app.displayName} (${app.packageName})`,
          timestamp: new Date().toLocaleTimeString(),
        };
      }
    }

    // 2. Safe Web Fallback / Simulation Path
    // In web environment, we safely open the official web service in a new browser context.
    try {
      if (typeof window !== 'undefined') {
        window.open(app.fallbackWebUrl, '_blank', 'noopener,noreferrer');
      }
      return {
        success: true,
        channel: 'web-browser-fallback',
        message: `Opened ${app.displayName} via web fallback URL: ${app.fallbackWebUrl}`,
        timestamp: new Date().toLocaleTimeString(),
      };
    } catch (err: any) {
      return {
        success: false,
        channel: 'web-browser-fallback',
        message: `Could not open browser destination: ${err.message || 'Window popup blocked'}`,
        timestamp: new Date().toLocaleTimeString(),
      };
    }
  }

  /**
   * Opens standard web link via official ACTION_VIEW intent.
   */
  async openWebsite(url: string): Promise<LaunchResult> {
    if (this.isNativeAndroidEnvironment() && window.Android002Host) {
      const opened = window.Android002Host.openBrowserUrl(url);
      return {
        success: opened,
        channel: 'native-android-intent',
        message: `Dispatched Intent.ACTION_VIEW for URL: ${url}`,
        timestamp: new Date().toLocaleTimeString(),
      };
    }

    if (typeof window !== 'undefined') {
      window.open(url, '_blank', 'noopener,noreferrer');
    }

    return {
      success: true,
      channel: 'web-browser-fallback',
      message: `Navigated to ${url} via browser window`,
      timestamp: new Date().toLocaleTimeString(),
    };
  }

  /**
   * Reference native Android Kotlin implementation for integration into the future APK.
   */
  getNativeKotlinImplementationSnippet(): string {
    return `// Android Kotlin Reference: 002CompanionHostBridge.kt
package ai.darling002.companion

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface

class Android002Host(private val context: Context) {

    @JavascriptInterface
    fun isNativeAndroidHost(): Boolean = true

    @JavascriptInterface
    fun getAndroidApiLevel(): Int = android.os.Build.VERSION.SDK_INT

    @JavascriptInterface
    fun canLaunchPackage(packageName: String): Boolean {
        return context.packageManager.getLaunchIntentForPackage(packageName) != null
    }

    @JavascriptInterface
    fun launchPackage(packageName: String): Boolean {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return true
    }

    @JavascriptInterface
    fun openBrowserUrl(url: String): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }
}`;
  }
}

export const androidAppLauncher = new AndroidAppLauncherService();
