/**
 * Game Review Engine
 * Reconstructs games, evaluates positions with Stockfish UCI engine,
 * classifies move quality based on win probability loss (CAPS standard),
 * identifies turning points, and generates tactical explanations.
 */

import { Chess } from 'chess.js';
import {
  MoveRecord,
  ReviewedMove,
  GameReviewReport,
  MoveClassification,
} from '../types/chess';
import { stockfishEngine } from './stockfishEngine';
import { OPENING_BOOK } from './openingBook';

/**
 * Calculates win probability from centipawn evaluation using standard sigmoid formula
 */
export function winProbability(centipawns: number): number {
  return 1 / (1 + Math.pow(10, -centipawns / 400));
}

/**
 * Classifies a move based on centipawn loss and win probability change
 */
export function classifyMoveQuality(
  isBookMove: boolean,
  centipawnLoss: number,
  winProbLoss: number,
  isSacrifice: boolean,
  isTopEngineMove: boolean,
  evalBefore: number,
  evalAfter: number
): MoveClassification {
  if (isBookMove) return 'book';

  // Brilliant: Piece sacrifice that retains winning advantage
  if (isSacrifice && winProbLoss < 0.03 && evalAfter > 150) {
    return 'brilliant';
  }

  // Great move: Found the only winning move
  if (isTopEngineMove && evalBefore > 100 && centipawnLoss < 15) {
    return 'great';
  }

  // Best move: Top engine choice or minimal loss
  if (isTopEngineMove || centipawnLoss <= 15) {
    return 'best';
  }

  // Excellent
  if (centipawnLoss <= 35 || winProbLoss <= 0.03) {
    return 'excellent';
  }

  // Good
  if (centipawnLoss <= 70 || winProbLoss <= 0.07) {
    return 'good';
  }

  // Missed Win / Missed Opportunity
  if (evalBefore >= 200 && evalAfter < 50) {
    return 'missed_win';
  }

  // Inaccuracy
  if (centipawnLoss <= 140 || winProbLoss <= 0.15) {
    return 'inaccuracy';
  }

  // Mistake
  if (centipawnLoss <= 250 || winProbLoss <= 0.25) {
    return 'mistake';
  }

  // Blunder
  return 'blunder';
}

/**
 * Generates structured explanation of a move's tactical and positional consequences
 */
export function generateMoveExplanation(
  moveSan: string,
  classification: MoveClassification,
  bestMoveSan: string,
  lossCp: number
): { en: string; mr: string; hi: string } {
  let en = '';
  let mr = '';
  let hi = '';

  switch (classification) {
    case 'book':
      en = `${moveSan} is a standard opening book move, following classical grandmaster theory.`;
      mr = `${moveSan} ही प्रमाणित ओपनिंग चाल आहे, जी ग्रँडमास्टर सिद्धांतानुसार आहे.`;
      hi = `${moveSan} एक मानक ओपनिंग चाल है, जो क्लासिकल ग्रैंडमास्टर थ्योरी का पालन करती है।`;
      break;
    case 'brilliant':
      en = `Brilliant move! An intuitive tactical sacrifice that maintains full control and dynamic dominance.`;
      mr = `उत्कृष्ट चाल! एक सुंदर रणनीतिक बलिदान जे पूर्ण नियंत्रण आणि आक्रमकता राखते.`;
      hi = `शानदार चाल! एक सुंदर सामरिक बलिदान जो पूर्ण नियंत्रण और आक्रामकता बनाए रखता है।`;
      break;
    case 'best':
      en = `The best move. ${moveSan} optimizes piece activity and matches Stockfish's top recommendation.`;
      mr = `सर्वोत्तम चाल. ${moveSan} मोहऱ्यांची सक्रियता वाढवते आणि इंजिनच्या पसंतीशी जुळते.`;
      hi = `सर्वोत्तम चाल। ${moveSan} मोहरों की सक्रियता बढ़ाती है और इंजन की पसंद से मेल खाती है।`;
      break;
    case 'excellent':
      en = `An excellent move that preserves your position's strategic advantage.`;
      mr = `उत्कृष्ट चाल जी आपल्या स्थितीचा धोरणात्मक फायदा टिकवून ठेवते.`;
      hi = `एक उत्कृष्ट चाल जो आपकी स्थिति का रणनीतिक लाभ बनाए रखती है।`;
      break;
    case 'good':
      en = `A solid move, keeping the position balanced and safe.`;
      mr = `चांगली चाल, स्थिती संतुलित आणि सुरक्षित ठेवते.`;
      hi = `एक ठोस चाल, स्थिति को संतुलित और सुरक्षित रखती है।`;
      break;
    case 'inaccuracy':
      en = `An inaccuracy losing ~${Math.round(lossCp)} centipawns. ${bestMoveSan} was slightly more accurate.`;
      mr = `किरकोळ चूक (~${Math.round(lossCp)} गुण). ${bestMoveSan} ही अधिक अचूक चाल होती.`;
      hi = `मामूली चूक (~${Math.round(lossCp)} अंक)। ${bestMoveSan} अधिक सटीक चाल थी।`;
      break;
    case 'mistake':
      en = `A mistake that concedes the initiative. Better was ${bestMoveSan} to maintain pressure.`;
      mr = `मोठी चूक ज्यामुळे प्रतिस्पर्ध्याला फायदा झाला. ${bestMoveSan} खेळणे श्रेयस्कर होते.`;
      hi = `एक गलती जिससे प्रतिद्वंद्वी को बढ़त मिली। दबाव बनाए रखने के लिए ${bestMoveSan} बेहतर था।`;
      break;
    case 'blunder':
      en = `A serious blunder losing ~${Math.round(lossCp)} centipawns. The position swung significantly. Better was ${bestMoveSan}.`;
      mr = `गंभीर चूक (~${Math.round(lossCp)} गुणांचे नुकसान). स्थिती खूप बदलली. ${bestMoveSan} खेळणे गरजेचे होते.`;
      hi = `गंभीर ब्लंडर (~${Math.round(lossCp)} अंकों का नुकसान)। स्थिति बहुत बदल गई। ${bestMoveSan} बेहतर विकल्प था।`;
      break;
    case 'missed_win':
      en = `Missed tactical opportunity! ${bestMoveSan} would have clinched a decisive winning advantage.`;
      mr = `जिंकण्याची संधी हुकली! ${bestMoveSan} मुळे निर्णायक विजय मिळाला असता.`;
      hi = `जीत का मौका चूका! ${bestMoveSan} से निर्णायक बढ़त मिल जाती।`;
      break;
    default:
      en = `${moveSan} played.`;
      mr = `${moveSan} चाल खेळली गेली.`;
      hi = `${moveSan} चाल चली गई।`;
  }

  return { en, mr, hi };
}

/**
 * Analyzes an entire recorded chess match ply-by-ply
 */
export async function analyzeRecordedGame(
  moves: MoveRecord[],
  whitePlayer = 'White',
  blackPlayer = 'Black',
  onProgress?: (currentPly: number, totalPlies: number) => void
): Promise<GameReviewReport> {
  const simGame = new Chess();
  const reviewedMoves: ReviewedMove[] = [];
  const whiteCounts: Record<MoveClassification, number> = {
    brilliant: 0,
    great: 0,
    best: 0,
    excellent: 0,
    good: 0,
    inaccuracy: 0,
    mistake: 0,
    blunder: 0,
    missed_win: 0,
    book: 0,
  };
  const blackCounts: Record<MoveClassification, number> = {
    brilliant: 0,
    great: 0,
    best: 0,
    excellent: 0,
    good: 0,
    inaccuracy: 0,
    mistake: 0,
    blunder: 0,
    missed_win: 0,
    book: 0,
  };

  let whiteWinProbLossSum = 0;
  let whiteMoveCount = 0;
  let blackWinProbLossSum = 0;
  let blackMoveCount = 0;
  const turningPoints: { ply: number; description: string; evalSwing: number }[] = [];

  let currentEval = 20; // Starting equal position (+0.20 pawns)

  for (let i = 0; i < moves.length; i++) {
    const move = moves[i];
    const fenBefore = simGame.fen();
    const moveNumber = Math.floor(i / 2) + 1;
    const isWhite = move.color === 'w';

    // Check opening book
    const isBook = i < 8 && OPENING_BOOK.some((b) => b.moves.slice(0, i + 1).join(' ') === moves.slice(0, i + 1).map((m) => m.san).join(' '));

    // Analyze position with engine
    const analysisBefore = await stockfishEngine.evaluatePosition(fenBefore, { depth: 10, timeLimitMs: 400 });
    const bestMove = analysisBefore.bestMove;
    const bestMoveSan = analysisBefore.bestMoveSan;

    // Execute move
    simGame.move({ from: move.from, to: move.to, promotion: move.promotion });
    const fenAfter = simGame.fen();

    const analysisAfter = await stockfishEngine.evaluatePosition(fenAfter, { depth: 10, timeLimitMs: 400 });

    const evalBeforeWhite = analysisBefore.whiteScoreCp;
    const evalAfterWhite = analysisAfter.whiteScoreCp;

    // Centipawn change from perspective of mover
    const playerEvalBefore = isWhite ? evalBeforeWhite : -evalBeforeWhite;
    const playerEvalAfter = isWhite ? evalAfterWhite : -evalAfterWhite;
    const cpLoss = Math.max(0, playerEvalBefore - playerEvalAfter);

    const wpBefore = winProbability(playerEvalBefore);
    const wpAfter = winProbability(playerEvalAfter);
    const wpLoss = Math.max(0, wpBefore - wpAfter);

    // Track accuracy
    if (isWhite) {
      whiteWinProbLossSum += wpLoss;
      whiteMoveCount++;
    } else {
      blackWinProbLossSum += wpLoss;
      blackMoveCount++;
    }

    const isTopMove = (move.from + move.to) === bestMove;
    const isSacrifice = !!move.captured && ['q', 'r', 'b', 'n'].includes(move.piece);

    const classification = classifyMoveQuality(
      isBook,
      cpLoss,
      wpLoss,
      isSacrifice,
      isTopMove,
      playerEvalBefore,
      playerEvalAfter
    );

    if (isWhite) {
      whiteCounts[classification]++;
    } else {
      blackCounts[classification]++;
    }

    // Detect turning point
    const evalSwing = Math.abs(evalAfterWhite - evalBeforeWhite);
    if (evalSwing >= 180 && !isBook) {
      turningPoints.push({
        ply: i + 1,
        description: `Turn ${moveNumber}: ${move.san} shifted evaluation by ${(evalSwing / 100).toFixed(1)} pawns.`,
        evalSwing,
      });
    }

    const explanation = generateMoveExplanation(move.san, classification, bestMoveSan, cpLoss);

    reviewedMoves.push({
      ply: i + 1,
      moveNumber,
      san: move.san,
      uci: `${move.from}${move.to}`,
      color: move.color,
      fenBefore,
      fenAfter,
      evalBefore: evalBeforeWhite,
      evalAfter: evalAfterWhite,
      evalDiff: cpLoss,
      classification,
      bestMove,
      bestMoveSan,
      bestAlternativeLine: analysisBefore.lines[0]?.pvSan || [bestMoveSan],
      explanation: explanation.en,
      explanationMarathi: explanation.mr,
      explanationHindi: explanation.hi,
    });

    currentEval = evalAfterWhite;

    if (onProgress) {
      onProgress(i + 1, moves.length);
    }
  }

  // Calculate overall CAPS accuracy (0 - 100%)
  const whiteAccuracy = whiteMoveCount > 0
    ? Math.round(Math.max(10, Math.min(100, 100 - (whiteWinProbLossSum / whiteMoveCount) * 100 * 1.6)))
    : 85;

  const blackAccuracy = blackMoveCount > 0
    ? Math.round(Math.max(10, Math.min(100, 100 - (blackWinProbLossSum / blackMoveCount) * 100 * 1.6)))
    : 85;

  const winner = whiteAccuracy > blackAccuracy ? whitePlayer : blackAccuracy > whiteAccuracy ? blackPlayer : 'Both players';
  const summaryText = `Game completed with ${moves.length} plies. White played with ${whiteAccuracy}% accuracy, while Black achieved ${blackAccuracy}% accuracy. ${turningPoints.length} decisive turning point${turningPoints.length === 1 ? '' : 's'} identified.`;

  return {
    id: `review-${Date.now()}`,
    date: new Date().toLocaleDateString(),
    whitePlayer,
    blackPlayer,
    whiteAccuracy,
    blackAccuracy,
    whiteClassificationCounts: whiteCounts,
    blackClassificationCounts: blackCounts,
    moves: reviewedMoves,
    turningPoints,
    summaryText,
  };
}
