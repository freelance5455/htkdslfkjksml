/**
 * GODEX Phase 4 - Controlled Terminal Execution Service
 * Pipes user terminal commands and test executions through the controlled ExecutionEngine.
 */

import { TermuxBridgeService } from './termuxBridge';
import { WorkspaceService } from './workspaceService';
import { ExecutionEngine } from '../execution/executor';
import { ExecutionResult } from '../execution/executionTypes';

export type ExecutionEnvironment = 'sandbox' | 'termux';

export interface TerminalExecutionResult {
  command: string;
  exitCode: number;
  stdout: string;
  stderr: string;
  duration: number;
  success: boolean;
  processId?: string;
  executionResult?: ExecutionResult;
}

class TerminalServiceClass {
  private executionEnv: ExecutionEnvironment = 'sandbox';

  public setEnvironment(env: ExecutionEnvironment) {
    this.executionEnv = env;
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem('codex_execution_env', env);
    }
  }

  public getEnvironment(): ExecutionEnvironment {
    return this.executionEnv;
  }

  constructor() {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('codex_execution_env') as ExecutionEnvironment;
      if (saved === 'sandbox' || saved === 'termux') {
        this.executionEnv = saved;
      }
    }
  }

  /**
   * Executes a command against the controlled execution engine
   */
  public async executeCommand(command: string): Promise<TerminalExecutionResult> {
    const trimmed = command.trim();
    if (!trimmed) {
      return {
        command: '',
        exitCode: 0,
        stdout: '',
        stderr: '',
        duration: 0,
        success: true
      };
    }

    if (this.executionEnv === 'termux') {
      const result = await TermuxBridgeService.executeCommand(trimmed);
      return {
        command: trimmed,
        exitCode: result.exitCode,
        stdout: result.stdout,
        stderr: result.stderr,
        duration: result.duration,
        success: result.success
      };
    }

    // Controlled Execution via GODEX ExecutionEngine
    const files = await WorkspaceService.getAllFiles();
    const result = await ExecutionEngine.execute({
      id: `term-exec-${Date.now()}`,
      command: trimmed,
      workingDirectory: '/project',
      timeoutMs: 30000,
      requestedBy: 'USER',
      reason: 'User Terminal Command',
      createdAt: Date.now()
    }, files);

    return {
      command: result.command,
      exitCode: result.exitCode,
      stdout: result.stdout,
      stderr: result.stderr,
      duration: result.durationMs,
      success: result.status === 'COMPLETED',
      processId: result.id,
      executionResult: result
    };
  }
}

export const TerminalService = new TerminalServiceClass();

