export interface AssetPack{ id:string;name:string;version:string;sizeMB:number;description:string;installed:boolean; }
const KEY='nivex.assetpacks.v1';
const CATALOG:AssetPack[]=[
 {id:'neon-core',name:'Neon Core',version:'1.0',sizeMB:18,description:'Presets, glows e overlays originais NIVEX.',installed:false},
 {id:'impact-motion',name:'Impact Motion',version:'1.0',sizeMB:24,description:'Curvas, shakes e transições de impacto.',installed:false},
 {id:'cinema-lab',name:'Cinema Lab',version:'1.0',sizeMB:31,description:'Looks, grãos, vinheta e presets cinematográficos.',installed:false},
 {id:'smart-pack',name:'Smart Tools',version:'1.0',sizeMB:42,description:'Módulos preparados para recursos Smart/IA.',installed:false},
];
export function listAssetPacks(){const installed=JSON.parse(localStorage.getItem(KEY)||'[]') as string[];return CATALOG.map(p=>({...p,installed:installed.includes(p.id)}));}
export function installAssetPack(id:string){const installed=JSON.parse(localStorage.getItem(KEY)||'[]') as string[];if(!installed.includes(id))installed.push(id);localStorage.setItem(KEY,JSON.stringify(installed));}
