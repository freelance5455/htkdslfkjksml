import { CustomAppIconData } from '../types/desktop';

/**
 * Creates the default Bird PC mascot icon (Cowboy Penguin) via Canvas
 */
export function generateDefaultBirdIcon(): CustomAppIconData {
  const canvas = document.createElement('canvas');
  canvas.width = 192;
  canvas.height = 192;
  const ctx = canvas.getContext('2d')!;

  // Background circle
  ctx.fillStyle = '#0F172A';
  ctx.fillRect(0, 0, 192, 192);

  // Gradient background glow
  const grad = ctx.createRadialGradient(96, 96, 20, 96, 96, 96);
  grad.addColorStop(0, '#1E293B');
  grad.addColorStop(1, '#0F172A');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 192, 192);

  // Blue outer ring
  ctx.strokeStyle = '#38BDF8';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(96, 96, 90, 0, Math.PI * 2);
  ctx.stroke();

  // Penguin Body (Dark charcoal)
  ctx.fillStyle = '#111827';
  ctx.beginPath();
  ctx.ellipse(96, 115, 52, 60, 0, 0, Math.PI * 2);
  ctx.fill();

  // Penguin Head
  ctx.fillStyle = '#111827';
  ctx.beginPath();
  ctx.arc(96, 85, 42, 0, Math.PI * 2);
  ctx.fill();

  // White scarf around neck
  ctx.fillStyle = '#F8FAFC';
  ctx.beginPath();
  ctx.ellipse(96, 110, 48, 16, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#CBD5E1';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Black Cowboy Hat
  ctx.fillStyle = '#09090B';
  // Hat Brim (curved)
  ctx.beginPath();
  ctx.ellipse(96, 60, 68, 14, 0, 0, Math.PI * 2);
  ctx.fill();
  // Hat Crown
  ctx.beginPath();
  ctx.moveTo(60, 60);
  ctx.bezierCurveTo(62, 30, 75, 22, 96, 24);
  ctx.bezierCurveTo(117, 22, 130, 30, 132, 60);
  ctx.closePath();
  ctx.fill();

  // Hat Band
  ctx.fillStyle = '#38BDF8';
  ctx.fillRect(66, 52, 60, 6);

  // Big Eyes
  // Left eye
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(76, 80, 11, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.arc(76, 80, 5, 0, Math.PI * 2);
  ctx.fill();

  // Right eye
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(116, 80, 11, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.arc(116, 80, 5, 0, Math.PI * 2);
  ctx.fill();

  // Red/Orange Beak
  ctx.fillStyle = '#EF4444';
  ctx.beginPath();
  ctx.ellipse(96, 96, 16, 11, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#B91C1C';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Generate density variations
  const xxxhdpi = canvas.toDataURL('image/png');
  const xxhdpi = resizeCanvas(canvas, 144, 144);
  const xhdpi = resizeCanvas(canvas, 96, 96);
  const hdpi = resizeCanvas(canvas, 72, 72);
  const mdpi = resizeCanvas(canvas, 48, 48);
  const adaptiveRound = generateRoundVariant(canvas, 192);

  return {
    dataUrl: xxxhdpi,
    fileName: 'bird-pc-default-mascot.png',
    mimeType: 'image/png',
    sizeBytes: 24500,
    densityDrawables: {
      mdpi,
      hdpi,
      xhdpi,
      xxhdpi,
      xxxhdpi
    },
    adaptiveRoundDataUrl: adaptiveRound
  };
}

/**
 * Resizes source canvas to target dimensions and returns base64 PNG
 */
function resizeCanvas(sourceCanvas: HTMLCanvasElement, width: number, height: number): string {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(sourceCanvas, 0, 0, width, height);
  return canvas.toDataURL('image/png');
}

/**
 * Generates an adaptive circular masked variant
 */
function generateRoundVariant(sourceCanvas: HTMLCanvasElement, size: number): string {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.beginPath();
  ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();

  ctx.drawImage(sourceCanvas, 0, 0, size, size);
  return canvas.toDataURL('image/png');
}

/**
 * Processes a user uploaded image file and returns CustomAppIconData
 */
export async function processUploadedIconFile(file: File): Promise<CustomAppIconData> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      const img = new Image();
      img.onload = () => {
        // Create square cropped canvas
        const size = 192;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d')!;

        // Calculate center square crop
        const minDim = Math.min(img.width, img.height);
        const sx = (img.width - minDim) / 2;
        const sy = (img.height - minDim) / 2;

        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, size, size);

        const xxxhdpi = canvas.toDataURL('image/png');
        const xxhdpi = resizeCanvas(canvas, 144, 144);
        const xhdpi = resizeCanvas(canvas, 96, 96);
        const hdpi = resizeCanvas(canvas, 72, 72);
        const mdpi = resizeCanvas(canvas, 48, 48);
        const adaptiveRound = generateRoundVariant(canvas, 192);

        resolve({
          dataUrl: xxxhdpi,
          fileName: file.name,
          mimeType: file.type || 'image/png',
          sizeBytes: file.size,
          densityDrawables: {
            mdpi,
            hdpi,
            xhdpi,
            xxhdpi,
            xxxhdpi
          },
          adaptiveRoundDataUrl: adaptiveRound
        });
      };
      img.onerror = () => reject(new Error('Failed to load image file.'));
      img.src = dataUrl;
    };
    reader.onerror = () => reject(new Error('Failed to read file.'));
    reader.readAsDataURL(file);
  });
}
