/**
 * تكرار متباعد مبسّط (SM-2 Lite):
 * لكل بطاقة معامل سهولة (ease) وفاصل بالأيام وميعاد استحقاق.
 * التقييمات: 0 = لم أتذكر، 1 = صعب، 2 = جيد، 3 = سهل.
 */
import type { Flashcard, FlashcardState } from '../types';
import { flashcards } from '../data/content';
import { KEYS, readKey, updateKey } from './storage';

export type CardMap = Record<string, FlashcardState>;

const emptyCards: CardMap = {};

function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${`${d.getMonth() + 1}`.padStart(2, '0')}-${`${d.getDate()}`.padStart(2, '0')}`;
}

function addDays(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + Math.max(1, Math.round(days)));
  return `${d.getFullYear()}-${`${d.getMonth() + 1}`.padStart(2, '0')}-${`${d.getDate()}`.padStart(2, '0')}`;
}

export function getCardMap(): CardMap {
  return readKey<CardMap>(KEYS.cards, emptyCards);
}

export function cardState(cardId: string): FlashcardState {
  return (
    getCardMap()[cardId] ?? {
      id: cardId,
      ease: 2.5,
      intervalDays: 0,
      due: todayISO(),
      reps: 0,
      lapses: 0,
    }
  );
}

export function gradeCard(cardId: string, grade: 0 | 1 | 2 | 3): void {
  const state = cardState(cardId);
  let ease = state.ease;
  let interval = state.intervalDays;
  let lapses = state.lapses;

  if (grade === 0) {
    ease = Math.max(1.3, ease - 0.25);
    interval = 0; // تُعاد في الجلسة نفسها
    lapses += 1;
  } else if (grade === 1) {
    ease = Math.max(1.3, ease - 0.1);
    interval = interval === 0 ? 1 : Math.max(1, interval * 1.2);
  } else if (grade === 2) {
    interval = interval === 0 ? 2 : Math.max(2, interval * ease);
  } else {
    ease = Math.min(3.2, ease + 0.1);
    interval = interval === 0 ? 4 : Math.max(3, interval * ease * 1.15);
  }

  const next: FlashcardState = {
    id: cardId,
    ease,
    intervalDays: interval,
    due: interval === 0 ? todayISO() : addDays(interval),
    reps: state.reps + 1,
    lapses,
    reviewedAt: Date.now(),
  };
  updateKey<CardMap>(KEYS.cards, (map) => ({ ...map, [cardId]: next }), emptyCards);
}

export function dueCards(subjectId?: string): Flashcard[] {
  const today = todayISO();
  const map = getCardMap();
  return flashcards.filter((c) => {
    if (subjectId && c.subjectId !== subjectId) return false;
    const st = map[c.id];
    return !st || st.due <= today;
  });
}

export function deckProgress(subjectId?: string): { reviewed: number; total: number } {
  const map = getCardMap();
  const pool = subjectId ? flashcards.filter((c) => c.subjectId === subjectId) : flashcards;
  const reviewed = pool.filter((c) => (map[c.id]?.reps ?? 0) > 0).length;
  return { reviewed, total: pool.length };
}
