import { Project, TimelineClip, ExportSettings } from '../types/editor';

export interface RenderProgress {
  progress: number; // 0 to 100
  currentClipIndex: number;
  totalClips: number;
  statusText: string;
}

export class VideoExportEngine {
  private isCancelled = false;

  public cancel() {
    this.isCancelled = true;
  }

  public async exportProject(
    project: Project,
    settings: ExportSettings,
    onProgress: (info: RenderProgress) => void
  ): Promise<{ blob: Blob; url: string; duration: number }> {
    this.isCancelled = false;

    if (project.clips.length === 0) {
      throw new Error('No clips in timeline to export.');
    }

    // Determine target canvas dimensions based on resolution & aspect ratio
    let width = 1280;
    let height = 720;

    if (settings.resolution === '1080p') {
      width = 1920;
      height = 1080;
    }

    if (project.aspectRatio === '9:16') {
      const temp = width;
      width = height;
      height = temp;
    } else if (project.aspectRatio === '1:1') {
      const size = settings.resolution === '1080p' ? 1080 : 720;
      width = size;
      height = size;
    } else if (project.aspectRatio === '4:5') {
      if (settings.resolution === '1080p') {
        width = 1080;
        height = 1350;
      } else {
        width = 720;
        height = 900;
      }
    }

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d', { alpha: false })!;

    // Set up Web Audio destination for audio mixing
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const audioCtx = new AudioContextClass();
    const audioDest = audioCtx.createMediaStreamDestination();

    const fps = settings.fps || 30;
    const canvasStream = canvas.captureStream(fps);

    const combinedTracks = [
      ...canvasStream.getVideoTracks(),
      ...audioDest.stream.getAudioTracks(),
    ];
    const combinedStream = new MediaStream(combinedTracks);

    // Pick best supported MIME type
    const mimeTypes = [
      'video/mp4;codecs=avc1,mp4a.40.2',
      'video/mp4',
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm',
    ];

    let chosenMime = '';
    for (const m of mimeTypes) {
      if (MediaRecorder.isTypeSupported(m)) {
        chosenMime = m;
        break;
      }
    }

    const videoBitsPerSecond = settings.quality === 'high' ? 8_000_000 : 4_500_000;
    const recorder = new MediaRecorder(combinedStream, {
      mimeType: chosenMime || undefined,
      videoBitsPerSecond,
    });

    const recordedChunks: Blob[] = [];
    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        recordedChunks.push(e.data);
      }
    };

    recorder.start(100);

    // Calculate total effective duration across all clips
    let totalExportDuration = 0;
    const clipDurations = project.clips.map((clip) => {
      const dur = (clip.sourceOut - clip.sourceIn) / (clip.speed || 1.0);
      totalExportDuration += dur;
      return dur;
    });

    let cumulativeTime = 0;

    try {
      for (let i = 0; i < project.clips.length; i++) {
        if (this.isCancelled) {
          recorder.stop();
          audioCtx.close();
          throw new Error('Export was cancelled by user.');
        }

        const clip = project.clips[i];
        const media = project.mediaMap[clip.mediaId];
        if (!media) continue;

        onProgress({
          progress: Math.min(99, Math.round((cumulativeTime / totalExportDuration) * 100)),
          currentClipIndex: i + 1,
          totalClips: project.clips.length,
          statusText: `Processing clip ${i + 1} of ${project.clips.length}: "${media.name}"`,
        });

        await this.renderSingleClip({
          clip,
          mediaUrl: media.url,
          canvas,
          ctx,
          audioCtx,
          audioDest,
          width,
          height,
          onSubProgress: (subP) => {
            if (this.isCancelled) return;
            const overall = ((cumulativeTime + subP * clipDurations[i]) / totalExportDuration) * 100;
            onProgress({
              progress: Math.min(99, Math.round(overall)),
              currentClipIndex: i + 1,
              totalClips: project.clips.length,
              statusText: `Encoding clip ${i + 1}/${project.clips.length} (${Math.round(subP * 100)}%)`,
            });
          },
        });

        cumulativeTime += clipDurations[i];
      }

      onProgress({
        progress: 100,
        currentClipIndex: project.clips.length,
        totalClips: project.clips.length,
        statusText: 'Finalizing MP4 container & audio sync...',
      });

      // Stop recorder and finalize
      await new Promise((resolve) => setTimeout(resolve, 300));
      const completionPromise = new Promise<{ blob: Blob; url: string; duration: number }>((resolve) => {
        recorder.onstop = () => {
          audioCtx.close();
          const finalType = chosenMime.includes('mp4') ? 'video/mp4' : 'video/webm';
          const blob = new Blob(recordedChunks, { type: finalType });
          const url = URL.createObjectURL(blob);
          resolve({ blob, url, duration: totalExportDuration });
        };
      });

      recorder.stop();
      return await completionPromise;
    } catch (err) {
      if (recorder.state !== 'inactive') {
        recorder.stop();
      }
      audioCtx.close();
      throw err;
    }
  }

  private async renderSingleClip(params: {
    clip: TimelineClip;
    mediaUrl: string;
    canvas: HTMLCanvasElement;
    ctx: CanvasRenderingContext2D;
    audioCtx: AudioContext;
    audioDest: MediaStreamAudioDestinationNode;
    width: number;
    height: number;
    onSubProgress: (progress: number) => void;
  }): Promise<void> {
    const { clip, mediaUrl, ctx, width, height, audioCtx, audioDest, onSubProgress } = params;

    const video = document.createElement('video');
    video.src = mediaUrl;
    video.crossOrigin = 'anonymous';
    video.preload = 'auto';
    video.muted = false;
    video.volume = clip.volume ?? 1.0;
    video.playbackRate = clip.speed ?? 1.0;
    video.playsInline = true;

    await new Promise((res, rej) => {
      video.onloadedmetadata = res;
      video.onerror = rej;
    });

    // Wire audio if possible
    let sourceNode: MediaElementAudioSourceNode | null = null;
    try {
      sourceNode = audioCtx.createMediaElementSource(video);
      sourceNode.connect(audioDest);
    } catch {
      // Audio node already connected or not supported; proceed smoothly
    }

    const startSec = Math.max(0, clip.sourceIn);
    const endSec = Math.min(video.duration || clip.sourceOut, clip.sourceOut);
    const durationToPlay = (endSec - startSec) / (clip.speed || 1.0);

    video.currentTime = startSec;
    await new Promise((res) => {
      video.onseeked = res;
      setTimeout(res, 200);
    });

    return new Promise((resolve, reject) => {
      let isPlaying = false;

      const finish = () => {
        video.pause();
        if (sourceNode) {
          try {
            sourceNode.disconnect();
          } catch {}
        }
        resolve();
      };

      const drawFrame = () => {
        if (this.isCancelled) {
          video.pause();
          reject(new Error('Export cancelled.'));
          return;
        }

        if (video.currentTime >= endSec || video.ended) {
          finish();
          return;
        }

        // Draw video frame to canvas maintaining aspect ratio
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, width, height);

        const videoAspect = (video.videoWidth || 16) / (video.videoHeight || 9);
        const canvasAspect = width / height;

        let renderW = width;
        let renderH = height;
        let renderX = 0;
        let renderY = 0;

        if (videoAspect > canvasAspect) {
          renderH = width / videoAspect;
          renderY = (height - renderH) / 2;
        } else {
          renderW = height * videoAspect;
          renderX = (width - renderW) / 2;
        }

        ctx.drawImage(video, renderX, renderY, renderW, renderH);

        const playedSec = (video.currentTime - startSec) / (clip.speed || 1.0);
        const subP = Math.min(1.0, playedSec / Math.max(0.1, durationToPlay));
        onSubProgress(subP);

        if (isPlaying) {
          requestAnimationFrame(drawFrame);
        }
      };

      video.onplay = () => {
        isPlaying = true;
        requestAnimationFrame(drawFrame);
      };

      video.onended = () => {
        finish();
      };

      video.onerror = () => {
        finish();
      };

      video.play().catch(() => {
        // Fallback frame-by-frame stepper if autoplay blocked
        this.stepFramesFallback(video, startSec, endSec, ctx, width, height, onSubProgress)
          .then(resolve)
          .catch(reject);
      });
    });
  }

  private async stepFramesFallback(
    video: HTMLVideoElement,
    startSec: number,
    endSec: number,
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    onSubProgress: (progress: number) => void
  ): Promise<void> {
    const step = 1 / 30;
    const totalDuration = endSec - startSec;

    for (let t = startSec; t < endSec; t += step) {
      if (this.isCancelled) throw new Error('Export cancelled.');
      video.currentTime = t;
      await new Promise((res) => {
        video.onseeked = res;
        setTimeout(res, 30);
      });

      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);

      const videoAspect = (video.videoWidth || 16) / (video.videoHeight || 9);
      const canvasAspect = width / height;
      let renderW = width;
      let renderH = height;
      let renderX = 0;
      let renderY = 0;

      if (videoAspect > canvasAspect) {
        renderH = width / videoAspect;
        renderY = (height - renderH) / 2;
      } else {
        renderW = height * videoAspect;
        renderX = (width - renderW) / 2;
      }

      ctx.drawImage(video, renderX, renderY, renderW, renderH);
      onSubProgress((t - startSec) / totalDuration);
    }
  }
}

export const videoExportEngine = new VideoExportEngine();
