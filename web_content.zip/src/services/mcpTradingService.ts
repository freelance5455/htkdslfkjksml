"use client";

import {
  CoinTechnicalAnalysis,
  OHLCVCandle,
  runIntradayBacktest,
  formatPriceNumber,
} from "./technicalEngine";

export type McpProposalActionType =
  | "MARKET_ORDER"
  | "TRAILING_STOP_ORDER"
  | "PARTIAL_CLOSE_POSITION"
  | "SET_DAILY_CIRCUIT_BREAKER"
  | "RUN_INTRADAY_BACKTEST"
  | "MOMENTUM_BREAKOUT_SCAN";

export interface McpProposedOrderCard {
  proposalId: string;
  mcpToolName: string;
  actionType: McpProposalActionType;
  symbol: string;
  side: "LONG" | "SHORT";
  quantity: number;
  sizeUsdt: number;
  leverage: number;
  estimatedEntryPrice: number;
  stopLossPrice: number;
  takeProfitPrice: number;
  trailingStopPct?: number;
  closeFractionPct?: number;
  circuitBreakerPct?: number;
  accountRiskPct: number;
  status: "PENDING_USER_APPROVAL" | "APPROVED_EXECUTED" | "REJECTED_BY_USER";
  summaryTitleHe: string;
  aiExplanationHe: string;
  mcpJsonSchema: Record<string, unknown>;
}

export interface McpChatMessage {
  id: string;
  sender: "USER" | "MCP_AI_AGENT";
  textHe: string;
  timestamp: number;
  proposalCard?: McpProposedOrderCard;
}

export const PRESET_MCP_HEBREW_COMMANDS: string[] = [
  "קנה 0.5 BTC מרקט עם Stop-Loss ב-1.5% ו-Take-Profit ב-3%",
  "זהה פריצת מומנטום ב-SOL/USDT בגרף 5 דקות",
  "הגדר Trailing Stop של 1% על ETH",
  "סגור 50% מהפוזיציה ב-BTC ברווח הנוכחי",
  "עצור מסחר יומי אם ההפסד היומי מגיע ל-2.5% מתיק הניסיון",
  "הרץ Backtest על אסטרטגיית חציית ממוצעים 9/20 בגרף 5 דקות",
];

export function parseNaturalLanguageDayTradeCommand(
  commandText: string,
  coins: CoinTechnicalAnalysis[],
  candles: OHLCVCandle[],
  accountBalanceUsdt = 10000
): {
  replyTextHe: string;
  proposalCard: McpProposedOrderCard;
} {
  const raw = (commandText || "").trim();
  const upper = raw.toUpperCase();

  // Identify symbol from command
  let matchedCoin =
    coins.find(
      (c) =>
        upper.includes(c.baseAsset) ||
        upper.includes(c.symbol) ||
        (c.baseAsset === "BTC" && raw.includes("ביטקוין")) ||
        (c.baseAsset === "ETH" && raw.includes("את'ריום")) ||
        (c.baseAsset === "SOL" && raw.includes("סולאנה"))
    ) || coins[0];

  if (!matchedCoin) {
    matchedCoin = {
      symbol: "BTCUSDT",
      baseAsset: "BTC",
      currentPrice: 94280,
      change24hPct: 2.1,
      high24h: 95200,
      low24h: 92800,
      volume24hUsdt: 38000000000,
      vwap: 94110,
      orderFlowImbalancePct: 18.4,
      rsi14: 59.2,
      macd: {
        macdLine: 120,
        signalLine: 95,
        histogram: 25,
        isBullishCross: true,
        isBearishCross: false,
      },
      ema: {
        ema9: 94180,
        ema20: 93950,
        ema50: 93400,
        ema200: 91800,
        trendAlignmentHe: "מומנטום שורי",
      },
      atr14: 680,
      atrPct: 0.72,
      adx14: 28.5,
      volumeProfile: {
        pocPrice: 93900,
        valueAreaHigh: 94800,
        valueAreaLow: 93100,
        volumeSpikeRatio: 1.45,
        nodes: [],
      },
      recommendation: "LONG",
      recommendationLabelHe: "LONG / לונג",
      confluenceScore: 86,
      entryPrice: 94280,
      stopLoss: 92865,
      takeProfit1: 97108,
      takeProfit2: 98500,
      kellySizing: {
        recommendedLeverage: 4,
        positionPctOfBalance: 8.0,
        accountRiskPct: 1.0,
        marginSizeUsdt: 800,
        notionalSizeUsdt: 3200,
        kellyFractionRaw: 0.22,
        riskRewardRatio: 2.0,
        maxLossUsdt: 100,
        expectedProfitUsdt: 200,
        sizingExplanationHe: "סיכון 1% מהתיק",
      },
      reasonsHe: [],
      evaluatorWarningHe: null,
      lastUpdatedTs: Date.now(),
    };
  }

  const price = matchedCoin.currentPrice || 94280;

  // 1. Circuit Breaker Command ("עצור מסחר יומי אם ההפסד היומי מגיע ל-2.5%")
  if (raw.includes("עצור מסחר יומי") || raw.includes("הפסד היומי") || upper.includes("CIRCUIT")) {
    const pctMatch = raw.match(/(\d+(?:\.\d+)?)\s*%/);
    const cbPct = pctMatch ? Number(pctMatch[1]) : 2.5;

    const proposal: McpProposedOrderCard = {
      proposalId: `MCP-CB-${Date.now()}`,
      mcpToolName: "mcp.risk_engine.set_daily_loss_circuit_breaker",
      actionType: "SET_DAILY_CIRCUIT_BREAKER",
      symbol: "PORTFOLIO_ALL",
      side: "LONG",
      quantity: 1,
      sizeUsdt: Number(((accountBalanceUsdt * cbPct) / 100).toFixed(2)),
      leverage: 1,
      estimatedEntryPrice: price,
      stopLossPrice: 0,
      takeProfitPrice: 0,
      circuitBreakerPct: cbPct,
      accountRiskPct: cbPct,
      status: "PENDING_USER_APPROVAL",
      summaryTitleHe: `הפעלת מנגנון הגנת הפסד יומי מרבי (${cbPct}% מהתיק = $${(
        (accountBalanceUsdt * cbPct) /
        100
      ).toFixed(0)})`,
      aiExplanationHe: `סוכן ה-MCP הכין פקודת נעילת סיכון יומית (Daily Loss Circuit Breaker). ברגע שאישורך יתקבל, המערכת תחסום פתיחת פוזיציות חדשות אם ההפסד היומי המצטבר יגיע ל-${cbPct}% ($${(
        (accountBalanceUsdt * cbPct) /
        100
      ).toFixed(2)} USDT).`,
      mcpJsonSchema: {
        protocol: "MCP/1.0",
        tool: "set_daily_loss_circuit_breaker",
        arguments: {
          max_daily_drawdown_pct: cbPct,
          max_daily_loss_usdt: Number(((accountBalanceUsdt * cbPct) / 100).toFixed(2)),
          auto_flatten_open_positions: true,
        },
      },
    };

    return {
      replyTextHe: `ניתחתי את בקשת הגנת הסיכון היומית שלך. הכנתי כרטיס אישור להפעלת **Daily Loss Circuit Breaker** ברמה של **${cbPct}%** מתיק הדמו. אנא אשר או דחה למטה ("אתה מחליט, אתה מאשר, ה-AI מבצע"):`,
      proposalCard: proposal,
    };
  }

  // 2. Backtest Command ("הרץ Backtest על אסטרטגיית חציית ממוצעים 9/20 בגרף 5 דקות")
  if (upper.includes("BACKTEST") || raw.includes("בקטסט") || raw.includes("חציית ממוצעים")) {
    const btResult = runIntradayBacktest(
      candles,
      "EMA_9_20_CROSS",
      "5m",
      accountBalanceUsdt
    );

    const proposal: McpProposedOrderCard = {
      proposalId: `MCP-BT-${Date.now()}`,
      mcpToolName: "mcp.quant_engine.run_intraday_backtest_and_deploy",
      actionType: "RUN_INTRADAY_BACKTEST",
      symbol: matchedCoin.symbol,
      side: matchedCoin.recommendation === "SHORT" ? "SHORT" : "LONG",
      quantity: Number((600 / price).toPrecision(4)),
      sizeUsdt: 600,
      leverage: 3,
      estimatedEntryPrice: price,
      stopLossPrice: Number((price * 0.985).toPrecision(6)),
      takeProfitPrice: Number((price * 1.03).toPrecision(6)),
      accountRiskPct: 0.9,
      status: "PENDING_USER_APPROVAL",
      summaryTitleHe: `תוצאות Backtest EMA 9/20 (5m): אחוז הצלחה ${btResult.winRatePct}% | רווח נكي +$${btResult.netProfitUsdt} (+${btResult.netReturnPct}%)`,
      aiExplanationHe: `הרצתי סימולציית Backtest על 200 נרות היסטוריים עבור אסטרטגיית חציית EMA 9/20 + מסנן VWAP: ${btResult.totalTrades} עסקאות, ${btResult.winningTrades} עסקאות מנצחות (${btResult.winRatePct}%), מכפיל רווח ${btResult.profitFactor}x. לחץ על [בצע / Execute] כדי לשגר את איתות האסטרטגיה הנוכחי לדמו.`,
      mcpJsonSchema: {
        protocol: "MCP/1.0",
        tool: "run_intraday_backtest",
        results: {
          strategy: "EMA_9_20_VWAP_5M",
          win_rate_pct: btResult.winRatePct,
          profit_factor: btResult.profitFactor,
          net_profit_usdt: btResult.netProfitUsdt,
        },
      },
    };

    return {
      replyTextHe: `הרצתי Backtest מלא על **אסטרטגיית חציית ממוצעים EMA 9/20 בגרף 5 דקות** מול נתוני השוק. אחוז ההצלחה עומד על **${btResult.winRatePct}%** עם מכפיל רווח **${btResult.profitFactor}x**. תוכל לאשר שיגור עסקת דמו על בסיס האסטרטגיה:`,
      proposalCard: proposal,
    };
  }

  // 3. Partial Close Command ("סגור 50% מהפוזיציה ב-BTC ברווח הנוכחי")
  if (raw.includes("סגור") && (raw.includes("%") || raw.includes("פוזיציה"))) {
    const pctMatch = raw.match(/(\d+(?:\.\d+)?)\s*%/);
    const closePct = pctMatch ? Number(pctMatch[1]) : 50;

    const proposal: McpProposedOrderCard = {
      proposalId: `MCP-CLOSE-${Date.now()}`,
      mcpToolName: "mcp.execution.partial_close_position",
      actionType: "PARTIAL_CLOSE_POSITION",
      symbol: matchedCoin.symbol,
      side: "LONG",
      quantity: Number(((450 * (closePct / 100)) / price).toPrecision(4)),
      sizeUsdt: Number((450 * (closePct / 100)).toFixed(2)),
      leverage: 4,
      estimatedEntryPrice: price,
      stopLossPrice: matchedCoin.stopLoss,
      takeProfitPrice: matchedCoin.takeProfit1,
      closeFractionPct: closePct,
      accountRiskPct: 0,
      status: "PENDING_USER_APPROVAL",
      summaryTitleHe: `סגירת ${closePct}% מפוזיציית ${matchedCoin.symbol} במחיר שוק ($${formatPriceNumber(
        price
      )})`,
      aiExplanationHe: `הפקודה תממש ${closePct}% מהרווח הצף בפוזיציית ${matchedCoin.symbol} ותקדם את ה-Stop-Loss למחיר הכניסה (Break-Even) להגנה מלאה על יתרת הפוזיציה.`,
      mcpJsonSchema: {
        protocol: "MCP/1.0",
        tool: "partial_close_position",
        arguments: {
          symbol: matchedCoin.symbol,
          close_percentage: closePct,
          move_sl_to_breakeven: true,
        },
      },
    };

    return {
      replyTextHe: `הכנתי פקודת מימוש חלקי (**${closePct}%** מפוזיציית **${matchedCoin.symbol}**) במחיר השוק הנוכחי ($${formatPriceNumber(
        price
      )}). לא מתבצעת שום פעולה ללא לחיצתך על **[בצע / Execute]**:`,
      proposalCard: proposal,
    };
  }

  // 4. Trailing Stop Command ("הגדר Trailing Stop של 1% על ETH")
  if (upper.includes("TRAILING") || raw.includes("נגרר")) {
    const pctMatch = raw.match(/(\d+(?:\.\d+)?)\s*%/);
    const trailPct = pctMatch ? Number(pctMatch[1]) : 1.0;
    const stopPrice = Number((price * (1 - trailPct / 100)).toPrecision(6));

    const proposal: McpProposedOrderCard = {
      proposalId: `MCP-TRAIL-${Date.now()}`,
      mcpToolName: "mcp.execution.place_trailing_stop_order",
      actionType: "TRAILING_STOP_ORDER",
      symbol: matchedCoin.symbol,
      side: "LONG",
      quantity: Number((600 / price).toPrecision(4)),
      sizeUsdt: 600,
      leverage: 3,
      estimatedEntryPrice: price,
      stopLossPrice: stopPrice,
      takeProfitPrice: Number((price * 1.035).toPrecision(6)),
      trailingStopPct: trailPct,
      accountRiskPct: Number(((600 * (trailPct / 100) * 3) / accountBalanceUsdt * 100).toFixed(2)),
      status: "PENDING_USER_APPROVAL",
      summaryTitleHe: `הגדרת Trailing Stop דינמי של ${trailPct}% על ${matchedCoin.symbol} (סף הפעלה: $${formatPriceNumber(
        stopPrice
      )})`,
      aiExplanationHe: `פקודת Trailing Stop של ${trailPct}% תעקוב אוטומטית אחרי עליית המחיר של ${matchedCoin.symbol} ותנעל רווחים בכל שיא תוך-יומי חדש.`,
      mcpJsonSchema: {
        protocol: "MCP/1.0",
        tool: "place_trailing_stop",
        arguments: {
          symbol: matchedCoin.symbol,
          callback_rate_pct: trailPct,
          activation_price: price,
          initial_stop_price: stopPrice,
        },
      },
    };

    return {
      replyTextHe: `הגדרתי הצעת **Trailing Stop של ${trailPct}%** עבור **${matchedCoin.symbol}** סביב מחיר השוק $${formatPriceNumber(
        price
      )}. לחץ על **[בצע / Execute]** לאישור והפעלה:`,
      proposalCard: proposal,
    };
  }

  // 5. Momentum Breakout Scan Command ("זהה פריצת מומנטום ב-SOL/USDT בגרף 5 דקות")
  if (raw.includes("זהה פריצת מומנטום") || raw.includes("פריצת") || raw.includes("סקאלפינג")) {
    const proposal: McpProposedOrderCard = {
      proposalId: `MCP-MOM-${Date.now()}`,
      mcpToolName: "mcp.scanner.intraday_momentum_breakout",
      actionType: "MOMENTUM_BREAKOUT_SCAN",
      symbol: matchedCoin.symbol,
      side: matchedCoin.recommendation === "SHORT" ? "SHORT" : "LONG",
      quantity: Number(
        ((matchedCoin.kellySizing.marginSizeUsdt *
          matchedCoin.kellySizing.recommendedLeverage) /
          price).toPrecision(4)
      ),
      sizeUsdt: matchedCoin.kellySizing.marginSizeUsdt,
      leverage: matchedCoin.kellySizing.recommendedLeverage,
      estimatedEntryPrice: price,
      stopLossPrice: matchedCoin.stopLoss,
      takeProfitPrice: matchedCoin.takeProfit1,
      accountRiskPct: matchedCoin.kellySizing.accountRiskPct,
      status: "PENDING_USER_APPROVAL",
      summaryTitleHe: `איתות פריצת מומנטום 5m ב-${matchedCoin.symbol}: ${matchedCoin.recommendationLabelHe} (קונפלואנס ${matchedCoin.confluenceScore}%)`,
      aiExplanationHe: `מחיר ${matchedCoin.symbol} ($${formatPriceNumber(
        price
      )}) נסחר ביחס ל-VWAP ($${formatPriceNumber(
        matchedCoin.vwap
      )}) עם Order Flow של ${
        matchedCoin.orderFlowImbalancePct >= 0 ? "+" : ""
      }${matchedCoin.orderFlowImbalancePct}% ו-EMA9 ($${formatPriceNumber(
        matchedCoin.ema.ema9
      )}) מעל EMA20. מומלץ בטחונות $${matchedCoin.kellySizing.marginSizeUsdt} במינוף ${matchedCoin.kellySizing.recommendedLeverage}x.`,
      mcpJsonSchema: {
        protocol: "MCP/1.0",
        tool: "execute_breakout_scalp",
        arguments: {
          symbol: matchedCoin.symbol,
          timeframe: "5m",
          vwap: matchedCoin.vwap,
          ema9: matchedCoin.ema.ema9,
          ema20: matchedCoin.ema.ema20,
          entry_price: price,
          stop_loss: matchedCoin.stopLoss,
          take_profit: matchedCoin.takeProfit1,
        },
      },
    };

    return {
      replyTextHe: `זיהיתי מבנה מומנטום תוך-יומי בגרף 5 דקות ב-**${matchedCoin.symbol}** (VWAP: $${formatPriceNumber(
        matchedCoin.vwap
      )}, RSI: ${matchedCoin.rsi14}, קונפלואנס: **${matchedCoin.confluenceScore}%**). הנה הצעת הפקודה לאישורך:`,
      proposalCard: proposal,
    };
  }

  // 6. Standard Buy / Sell Market Order with Custom SL% and TP% ("קנה 0.5 BTC מרקט עם Stop-Loss ב-1.5% ו-Take-Profit ב-3%")
  const isShortCmd =
    raw.includes("מכור") ||
    raw.includes("שורט") ||
    upper.includes("SHORT") ||
    upper.includes("SELL");
  const side: "LONG" | "SHORT" = isShortCmd ? "SHORT" : "LONG";

  const slMatch = raw.match(/Stop-Loss\s*ב-?\s*(\d+(?:\.\d+)?)\s*%/i);
  const tpMatch = raw.match(/Take-Profit\s*ב-?\s*(\d+(?:\.\d+)?)\s*%/i);
  const slPct = slMatch ? Number(slMatch[1]) : 1.5;
  const tpPct = tpMatch ? Number(tpMatch[1]) : 3.0;

  const stopLossPrice =
    side === "LONG"
      ? Number((price * (1 - slPct / 100)).toPrecision(6))
      : Number((price * (1 + slPct / 100)).toPrecision(6));
  const takeProfitPrice =
    side === "LONG"
      ? Number((price * (1 + tpPct / 100)).toPrecision(6))
      : Number((price * (1 - tpPct / 100)).toPrecision(6));

  const marginSizeUsdt = matchedCoin.kellySizing.marginSizeUsdt || 650;
  const leverage = matchedCoin.kellySizing.recommendedLeverage || 3;
  const quantity = Number(((marginSizeUsdt * leverage) / price).toPrecision(4));
  const accountRiskPct = Number(
    (((marginSizeUsdt * leverage * (slPct / 100)) / accountBalanceUsdt) * 100).toFixed(2)
  );

  const proposal: McpProposedOrderCard = {
    proposalId: `MCP-ORD-${Date.now()}`,
    mcpToolName: "mcp.execution.create_intraday_market_order",
    actionType: "MARKET_ORDER",
    symbol: matchedCoin.symbol,
    side,
    quantity,
    sizeUsdt: marginSizeUsdt,
    leverage,
    estimatedEntryPrice: price,
    stopLossPrice,
    takeProfitPrice,
    accountRiskPct,
    status: "PENDING_USER_APPROVAL",
    summaryTitleHe: `${
      side === "LONG" ? "קניית לונג (LONG)" : "מכירת שורט (SHORT)"
    } מרקט על ${matchedCoin.symbol} | SL: -${slPct}% ($${formatPriceNumber(
      stopLossPrice
    )}) | TP: +${tpPct}% ($${formatPriceNumber(takeProfitPrice)})`,
    aiExplanationHe: `פקודת ${side} על ${matchedCoin.symbol} במחיר כניסה משוער $${formatPriceNumber(
      price
    )}, בטחונות מותאמי תיק דמו ($${marginSizeUsdt} במינוף ${leverage}x), קטיעת הפסד ב-$${formatPriceNumber(
      stopLossPrice
    )} ויעד רווח ב-$${formatPriceNumber(
      takeProfitPrice
    )}. סיכון כולל לתיק: ${accountRiskPct}%.`,
    mcpJsonSchema: {
      protocol: "MCP/1.0",
      tool: "create_intraday_market_order",
      arguments: {
        symbol: matchedCoin.symbol,
        side,
        order_type: "MARKET",
        margin_usdt: marginSizeUsdt,
        leverage,
        stop_loss_price: stopLossPrice,
        take_profit_price: takeProfitPrice,
        account_risk_pct: accountRiskPct,
      },
    },
  };

  return {
    replyTextHe: `פירקתי את פקודת המסחר היומית שלך באמצעות פרוטוקול **MCP**. הכנתי כרטיס ביצוע מדויק עבור **${matchedCoin.symbol}** עם הגנת SL ב-**${slPct}%** ויעד TP ב-**${tpPct}%**. אשר או דחה למטה:`,
    proposalCard: proposal,
  };
}
