import { Language } from '../types';

export interface Translations {
  // Main Menu
  coins: string;
  shop: string;
  settings: string;
  shortArrow: string;
  shortArrowSub: string;
  longArrow: string;
  longArrowSub: string;
  play: string;
  won: string;
  gameSubtitle: string;
  freeCoins: string;

  // HUD
  moves: string;
  movesLabel: string;
  timeLabel: string;
  arrowsLeft: string;
  reset: string;
  undo: string;
  hint: string;
  adBadge: string;
  soundOn: string;
  soundOff: string;
  tutorialLongArrow1: string;

  // Settings Modal
  settingsTitle: string;
  settingsSubtitle: string;
  soundEffects: string;
  soundEffectsSub: string;
  ambientMusic: string;
  ambientMusicSub: string;
  voiceReactions: string;
  voiceReactionsSub: string;
  hapticFeedback: string;
  hapticFeedbackSub: string;
  language: string;
  languageSub: string;
  resetProgress: string;
  resetConfirmTitle: string;
  yesReset: string;
  cancel: string;

  // Win Modal
  levelComplete: string;
  levelMastered: string;
  starsEarned: string;
  bestMoves: string;
  maxCombo: string;
  coinsEarned: string;
  nextLevel: string;
  replay: string;
  home: string;

  // Fail Modal
  noMovesTitle: string;
  noMovesDesc: string;
  useHintBtn: string;
  retryBtn: string;
  tryAgain: string;
  tryAgainSub: string;
  retryPuzzle: string;
  useHint: string;

  // Time's Up Modal
  timesUpTitle: string;
  timesUpDesc: string;
  watchAdContinue: string;
  timesUp: string;
  timesUpSub: string;
  continueWatchAd: string;

  // Collection Modal
  collectionTitle: string;
  collectionSubtitle: string;
  shopSubtitle: string;
  equip: string;
  equipped: string;
  owned: string;
  unlockFor: string;
  adCoinsBtn: string;

  // Daily Reward
  dailyRewardTitle: string;
  dailyRewardSubtitle: string;
  claimReward: string;
  dayStreak: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  en: {
    coins: 'Coins',
    shop: 'Shop',
    settings: 'Settings',
    shortArrow: 'SHORT ARROW',
    shortArrowSub: 'Pixel Designs',
    longArrow: 'LONG ARROW',
    longArrowSub: 'Interlocking Obstacles',
    play: 'Play',
    won: 'won',
    gameSubtitle: 'Arrow Direction Escape Puzzle',
    freeCoins: '+100',

    moves: 'Moves',
    movesLabel: 'Moves:',
    timeLabel: 'TIME:',
    arrowsLeft: 'left',
    reset: 'Reset',
    undo: 'Undo',
    hint: 'Hint',
    adBadge: 'Ad',
    soundOn: 'Sound On',
    soundOff: 'Sound Off',
    tutorialLongArrow1: 'Tap an arrowhead to guide it off along its track! Clear the outer arrows first.',

    settingsTitle: 'SETTINGS',
    settingsSubtitle: 'Audio, Haptics & Controls',
    soundEffects: 'Sound Effects',
    soundEffectsSub: 'Tactile escapes & hits',
    ambientMusic: 'Ambient Music',
    ambientMusicSub: 'Relaxing zen tones',
    voiceReactions: 'Voice Reactions',
    voiceReactionsSub: 'Combo praise & cheers',
    hapticFeedback: 'Haptic Feedback',
    hapticFeedbackSub: 'Subtle vibration',
    language: 'Language',
    languageSub: 'English • हिन्दी • বাংলা',
    resetProgress: 'Reset Game Progress',
    resetConfirmTitle: 'Reset all levels, stars, and coins?',
    yesReset: 'Yes, Reset',
    cancel: 'Cancel',

    levelComplete: 'LEVEL COMPLETE!',
    levelMastered: 'Level {0} Mastered',
    starsEarned: 'Stars',
    bestMoves: 'Best',
    maxCombo: 'Max Combo',
    coinsEarned: 'Coins',
    nextLevel: 'NEXT LEVEL',
    replay: 'Replay',
    home: 'Home',

    noMovesTitle: 'No Moves Available',
    noMovesDesc: 'All remaining arrows are blocked. Use a hint to reveal the way or reset!',
    useHintBtn: 'Use Hint',
    retryBtn: 'Retry Level',
    tryAgain: 'TRY AGAIN',
    tryAgainSub: 'Take a deep breath! Check arrow paths carefully or use a hint to guide your next step.',
    retryPuzzle: 'RETRY PUZZLE',
    useHint: 'USE HINT',

    timesUpTitle: "TIME'S UP!",
    timesUpDesc: 'The timer reached zero. Watch a short sponsor message for +30 seconds or retry!',
    watchAdContinue: '+30s & Continue',
    timesUp: "TIME'S UP!",
    timesUpSub: 'The countdown expired before clearing all arrows. Watch a quick ad to add +30 seconds and keep playing!',
    continueWatchAd: 'WATCH AD & CONTINUE (+30s)',

    collectionTitle: 'ARROW SKINS',
    collectionSubtitle: 'Customize your puzzle pieces',
    shopSubtitle: 'Cosmetic Styles & Colors',
    equip: 'Equip',
    equipped: 'Equipped',
    owned: 'Owned',
    unlockFor: 'Unlock for {0}',
    adCoinsBtn: '+50 Coins',

    dailyRewardTitle: 'DAILY REWARD',
    dailyRewardSubtitle: 'Keep your login streak alive!',
    claimReward: 'Claim Reward',
    dayStreak: 'Day {0}',
  },

  hi: {
    coins: 'सिक्के',
    shop: 'दुकान',
    settings: 'सेटिंग्स',
    shortArrow: 'छोटा तीर',
    shortArrowSub: 'पिक्सेल डिज़ाइन',
    longArrow: 'लंबा तीर',
    longArrowSub: 'इंटरलॉकिंग पहेली',
    play: 'खेलें',
    won: 'जीते',
    gameSubtitle: 'तीर दिशा एस्केप पहेली',
    freeCoins: '+100',

    moves: 'चालें',
    movesLabel: 'चालें:',
    timeLabel: 'समय:',
    arrowsLeft: 'शेष',
    reset: 'रीसेट',
    undo: 'पूर्ववत',
    hint: 'संकेत',
    adBadge: 'विज्ञापन',
    soundOn: 'ध्वनि चालू',
    soundOff: 'ध्वनि बंद',
    tutorialLongArrow1: 'तीर के सिरे पर टैप करके उसे बाहर निकालें! पहले बाहरी तीरों को हटाएं।',

    settingsTitle: 'सेटिंग्स',
    settingsSubtitle: 'ऑडियो, कंपन और नियंत्रण',
    soundEffects: 'ध्वनि प्रभाव',
    soundEffectsSub: 'एस्केप और हिट ध्वनियां',
    ambientMusic: 'शांत संगीत',
    ambientMusicSub: 'आरामदायक धुन',
    voiceReactions: 'आवाज़ प्रतिक्रियाएं',
    voiceReactionsSub: 'कॉम्बो प्रोत्साहन ध्वनियां',
    hapticFeedback: 'कंपन (हैप्टिक)',
    hapticFeedbackSub: 'हल्का सुखद कंपन',
    language: 'भाषा',
    languageSub: 'English • हिन्दी • বাংলা',
    resetProgress: 'गेम प्रगति रीसेट करें',
    resetConfirmTitle: 'क्या सभी स्तर, सितारे और सिक्के रीसेट करें?',
    yesReset: 'हां, रीसेट करें',
    cancel: 'रद्द करें',

    levelComplete: 'स्तर पूरा हुआ!',
    levelMastered: 'स्तर {0} में महारत हासिल',
    starsEarned: 'सितारे',
    bestMoves: 'सर्वश्रेष्ठ',
    maxCombo: 'अधिकतम कॉम्बो',
    coinsEarned: 'सिक्के',
    nextLevel: 'अगला स्तर',
    replay: 'दोबारा खेलें',
    home: 'होम',

    noMovesTitle: 'कोई चाल उपलब्ध नहीं',
    noMovesDesc: 'सभी शेष तीर अवरुद्ध हैं। रास्ता देखने के लिए संकेत लें या रीसेट करें!',
    useHintBtn: 'संकेत लें',
    retryBtn: 'पुनः प्रयास',
    tryAgain: 'पुनः प्रयास करें',
    tryAgainSub: 'गहरी सांस लें! तीर के रास्तों की सावधानी से जांच करें या संकेत का उपयोग करें।',
    retryPuzzle: 'पहेली पुनः प्रयास करें',
    useHint: 'संकेत लें',

    timesUpTitle: 'समय समाप्त!',
    timesUpDesc: 'उलटी गिनती पूरी हो गई। +30 सेकंड के लिए विज्ञापन देखें या पुनः प्रयास करें!',
    watchAdContinue: '+30 सेकंड जारी रखें',
    timesUp: 'समय समाप्त!',
    timesUpSub: 'उलटी गिनती पूरी हो गई। +30 सेकंड जोड़ने और खेलना जारी रखने के लिए एक छोटा विज्ञापन देखें!',
    continueWatchAd: 'विज्ञापन देखें और जारी रखें (+30s)',

    collectionTitle: 'तीर की खालें',
    collectionSubtitle: 'अपने तीरों को मनपसंद रंग दें',
    shopSubtitle: 'रंग और डिज़ाइन शैलियाँ',
    equip: 'लागू करें',
    equipped: 'लागू है',
    owned: 'प्राप्त है',
    unlockFor: '{0} सिक्के में अनलॉक करें',
    adCoinsBtn: '+50 सिक्के',

    dailyRewardTitle: 'दैनिक पुरस्कार',
    dailyRewardSubtitle: 'रोजाना लॉगिन करके पुरस्कार पाएं!',
    claimReward: 'पुरस्कार प्राप्त करें',
    dayStreak: 'दिन {0}',
  },

  bn: {
    coins: 'কয়েন',
    shop: 'শপ',
    settings: 'সেটিংস',
    shortArrow: 'শর্ট তীর',
    shortArrowSub: 'পিক্সেল ডিজাইন',
    longArrow: 'লং তীর',
    longArrowSub: 'ইন্টারলকিং ধাঁধা',
    play: 'খেলুন',
    won: 'জয়',
    gameSubtitle: 'তীর দিক এস্কেপ পাজল',
    freeCoins: '+১০০',

    moves: 'চাল',
    movesLabel: 'চাল:',
    timeLabel: 'সময়:',
    arrowsLeft: 'বাকি',
    reset: 'রিসেট',
    undo: 'পূর্বাবস্থা',
    hint: 'ইঙ্গিত',
    adBadge: 'বিজ্ঞাপন',
    soundOn: 'সাউন্ড চালু',
    soundOff: 'সাউন্ড বন্ধ',
    tutorialLongArrow1: 'তীরের মুখে ট্যাপ করে ট্র্যাকে বের করে দিন! আগে বাইরের তীরগুলো সরান।',

    settingsTitle: 'সেটিংস',
    settingsSubtitle: 'অডিও, হ্যাপটিক্স ও নিয়ন্ত্রণ',
    soundEffects: 'সাউন্ড এফেক্ট',
    soundEffectsSub: 'এস্কেপ ও হিটের অনুভূতি',
    ambientMusic: 'শান্ত মিউজিক',
    ambientMusicSub: 'আরামদায়ক সুর',
    voiceReactions: 'ভয়েস প্রতিক্রিয়া',
    voiceReactionsSub: 'কম্বো প্রশংসা ও উল্লাস',
    hapticFeedback: 'হ্যাপটিক ভাইব্রেশন',
    hapticFeedbackSub: 'মৃদু স্পর্শ অনুভূতি',
    language: 'ভাষা',
    languageSub: 'English • हिन्दी • বাংলা',
    resetProgress: 'গেম প্রগ্রেস রিসেট',
    resetConfirmTitle: 'সব লেভেল, স্টার ও কয়েন রিসেট করবেন?',
    yesReset: 'হ্যাঁ, রিসেট করুন',
    cancel: 'বাতিল',

    levelComplete: 'লেভেল সম্পূর্ণ!',
    levelMastered: 'লেভেল {0} সফলভাবে সম্পন্ন',
    starsEarned: 'স্টার',
    bestMoves: 'সেরা',
    maxCombo: 'সর্বোচ্চ কম্বো',
    coinsEarned: 'কয়েন',
    nextLevel: 'পরবর্তী লেভেল',
    replay: 'পুনরায় খেলুন',
    home: 'হোম',

    noMovesTitle: 'কোনো চাল বাকি নেই',
    noMovesDesc: 'সব তীর আটকে গেছে। সঠিক পথ দেখতে ইঙ্গিত ব্যবহার করুন বা রিসেট করুন!',
    useHintBtn: 'ইঙ্গিত ব্যবহার করুন',
    retryBtn: 'পুনরায় চেষ্টা',
    tryAgain: 'আবার চেষ্টা করুন',
    tryAgainSub: 'মনোযোগ দিয়ে তীরের পথ দেখুন অথবা পরবর্তী চাল জানতে ইঙ্গিত ব্যবহার করুন।',
    retryPuzzle: 'ধাঁধা পুনরায় চেষ্টা করুন',
    useHint: 'ইঙ্গিত ব্যবহার করুন',

    timesUpTitle: 'সময় শেষ!',
    timesUpDesc: 'কাউন্টডাউন শূন্যে পৌঁছেছে। +৩০ সেকেন্ড পেতে বিজ্ঞাপন দেখুন অথবা আবার খেলুন!',
    watchAdContinue: '+৩০ সেকেন্ড ও চালিয়ে যান',
    timesUp: 'সময় শেষ!',
    timesUpSub: 'কাউন্টডাউন শেষ হয়েছে। আরও ৩০ সেকেন্ড পেতে ও খেলা চালিয়ে যেতে একটি ছোট বিজ্ঞাপন দেখুন!',
    continueWatchAd: 'বিজ্ঞাপন দেখুন ও চালিয়ে যান (+৩০s)',

    collectionTitle: 'তীরের স্কিন',
    collectionSubtitle: 'তীরের নকশা কাস্টমাইজ করুন',
    shopSubtitle: 'রঙ ও চমৎকার স্টাইল',
    equip: 'ব্যবহার করুন',
    equipped: 'ব্যবহৃত',
    owned: 'কেনা আছে',
    unlockFor: '{0} কয়েনে আনলক',
    adCoinsBtn: '+৫০ কয়েন',

    dailyRewardTitle: 'দৈনিক পুরস্কার',
    dailyRewardSubtitle: 'প্রতিদিন লগইন করে পুরস্কার সংগ্রহ করুন!',
    claimReward: 'পুরস্কার গ্রহণ করুন',
    dayStreak: 'দিন {0}',
  },
};

export function getTranslations(lang: Language): Translations {
  return TRANSLATIONS[lang] || TRANSLATIONS.en;
}
