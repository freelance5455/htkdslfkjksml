export type Language = 'en' | 'he';

export interface Translations {
  // App brand & header
  appName: string;
  appSubtitle: string;
  hebrewCalendar: string;
  nextZman: string;
  selectLocation: string;
  setManualLocation: string;
  gps: string;
  
  // Views
  viewMonth: string;
  viewWeek: string;
  viewDay: string;
  viewAgenda: string;
  
  // Quick Actions & Tools
  dateConverter: string;
  eventsManager: string;
  homeWidget: string;
  notifications: string;
  syncDevices: string;
  settings: string;
  toggleTheme: string;
  switchLanguage: string;
  
  // Calendar Navigation
  today: string;
  previousMonth: string;
  nextMonth: string;
  previousWeek: string;
  nextWeek: string;
  previousDay: string;
  nextDay: string;
  jumpToDate: string;
  
  // Weekdays
  sun: string;
  mon: string;
  tue: string;
  wed: string;
  thu: string;
  fri: string;
  sat: string;
  
  // Calendar Content & Badges
  parashatHashavua: string;
  candleLighting: string;
  havdalah: string;
  roshChodesh: string;
  fastDay: string;
  yomTov: string;
  cholHamoed: string;
  omerCount: string;
  dafYomi: string;
  weeklyPortion: string;
  todayZmanim: string;
  halachicTimesSummary: string;
  dailyVerse: string;
  dailyVerseSubtitle: string;
  copyVerse: string;
  verseCopied: string;
  
  // Personal Events
  personalEvents: string;
  personalEventsTitle: string;
  personalEventsDesc: string;
  addEvent: string;
  createEvent: string;
  editEvent: string;
  deleteEvent: string;
  eventTitle: string;
  eventTitlePlaceholder: string;
  eventType: string;
  birthday: string;
  hebrewBirthday: string;
  yahrzeit: string;
  yahrzeitMemorial: string;
  anniversary: string;
  hebrewAnniversary: string;
  barmitzvah: string;
  batmitzvah: string;
  barBatMitzvah: string;
  memorial: string;
  customEvent: string;
  customHebrewEvent: string;
  hebrewDate: string;
  gregorianDate: string;
  repeatsAnnuallyHebrew: string;
  repeatsMonthlyHebrew: string;
  doesNotRepeat: string;
  repeatCount: string;
  repeatEnd: string;
  repeatForever: string;
  repeatCustomCount: string;
  times: string;
  repeatsTimes: string;
  participants: string;
  addParticipant: string;
  addParticipantPlaceholder: string;
  add: string;
  noParticipants: string;
  participantCount: string;
  participantSingular: string;
  hebrewTitleOptional: string;
  hebrewTitlePlaceholder: string;
  calendarEventColor: string;
  enableReminderNotification: string;
  onDayOfEvent: string;
  oneDayBefore: string;
  twoDaysBefore: string;
  threeDaysBefore: string;
  oneWeekBefore: string;
  candleLightingMemorial: string;
  addLocation: string;
  addNotesPlaceholder: string;
  advancedHebrewOptions: string;
  occurrenceCounter: string;
  showOccurrenceAgeCounter: string;
  occurrenceCounterDesc: string;
  startHebrewYear: string;
  startHebrewYearLabel: string;
  initialCount: string;
  initialCountLabel: string;
  adarLeapYearRule: string;
  observeAdar2: string;
  observeAdar1: string;
  observeBothAdars: string;
  overrideHebrewDateDirectly: string;
  month: string;
  day: string;
  upcomingGregorianOccurrences: string;
  days: string;
  daySingular: string;
  pleaseEnterTitle: string;
  notes: string;
  save: string;
  cancel: string;
  close: string;
  delete: string;
  importExport: string;
  noEvents: string;
  searchEvents: string;
  allTypes: string;
  exportICal: string;
  exportBackup: string;
  importBackup: string;
  
  // Settings Modal
  settingsTitle: string;
  settingsSubtitle: string;
  languageSection: string;
  languageDesc: string;
  english: string;
  hebrew: string;
  appearanceSection: string;
  theme: string;
  darkMode: string;
  lightMode: string;
  defaultView: string;
  displayPreferences: string;
  showDafYomi: string;
  showOmer: string;
  showParasha: string;
  showHebrewGematriya: string;
  showSecularDates: string;
  halachicOpinions: string;
  shabbatOffset: string;
  minutesBeforeSunset: string;
  havdalahOpinion: string;
  zmanimCalculation: string;
  graOpinion: string;
  mgaOpinion: string;
  elevationAdjustment: string;
  notificationSettings: string;
  enableAlerts: string;
  shabbatCandleAlerts: string;
  holidayAlerts: string;
  dailyVerseNotification: string;
  personalEventReminders: string;
  savedSuccessfully: string;
  resetDefaults: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appName: 'Luchot BH',
    appSubtitle: 'Hebrew Halachic Calendar with Zmanim & Sync',
    hebrewCalendar: 'Hebrew Calendar',
    nextZman: 'Next Zman',
    selectLocation: 'Select Location',
    setManualLocation: 'Set Location Manually...',
    gps: 'GPS',
    
    viewMonth: 'Month',
    viewWeek: 'Week',
    viewDay: 'Day',
    viewAgenda: 'List',
    
    dateConverter: 'Date Converter',
    eventsManager: 'Personal Events',
    homeWidget: 'Home Screen Widget',
    notifications: 'Notifications & Alerts',
    syncDevices: 'Sync Devices',
    settings: 'Settings',
    toggleTheme: 'Toggle Theme',
    switchLanguage: 'עברית (RTL)',
    
    today: 'Today',
    previousMonth: 'Previous Month',
    nextMonth: 'Next Month',
    previousWeek: 'Previous Week',
    nextWeek: 'Next Week',
    previousDay: 'Previous Day',
    nextDay: 'Next Day',
    jumpToDate: 'Jump to Date',
    
    sun: 'Sun',
    mon: 'Mon',
    tue: 'Tue',
    wed: 'Wed',
    thu: 'Thu',
    fri: 'Fri',
    sat: 'Shabbat',
    
    parashatHashavua: 'Parashat Hashavua',
    candleLighting: 'Candle Lighting',
    havdalah: 'Havdalah',
    roshChodesh: 'Rosh Chodesh',
    fastDay: 'Fast Day',
    yomTov: 'Yom Tov',
    cholHamoed: 'Chol HaMoed',
    omerCount: 'Omer Count',
    dafYomi: 'Daf Yomi',
    weeklyPortion: 'Weekly Torah Portion',
    todayZmanim: "Today's Zmanim",
    halachicTimesSummary: 'Halachic prayer and ritual times',
    dailyVerse: 'Daily Torah Thought',
    dailyVerseSubtitle: 'Inspirational wisdom for today',
    copyVerse: 'Copy Verse',
    verseCopied: 'Copied!',
    
    personalEvents: 'Personal Events & Reminders',
    personalEventsTitle: 'Personal Hebrew Events & Yahrzeits',
    personalEventsDesc: 'Manage Hebrew birthdays, memorial anniversaries, and calendar sync',
    addEvent: 'Add Event',
    createEvent: 'Create Event',
    editEvent: 'Edit Event',
    deleteEvent: 'Delete Event',
    eventTitle: 'Event Title',
    eventTitlePlaceholder: 'Add title',
    eventType: 'Event Type',
    birthday: 'Birthday',
    hebrewBirthday: 'Hebrew Birthday',
    yahrzeit: 'Yahrzeit / Memorial',
    yahrzeitMemorial: 'Yahrzeit / Memorial',
    anniversary: 'Anniversary',
    hebrewAnniversary: 'Hebrew Anniversary',
    barmitzvah: 'Bar Mitzvah',
    batmitzvah: 'Bat Mitzvah',
    barBatMitzvah: 'Bar / Bat Mitzvah',
    memorial: 'Memorial',
    customEvent: 'Custom Event',
    customHebrewEvent: 'Custom Hebrew Event',
    hebrewDate: 'Hebrew Date',
    gregorianDate: 'Gregorian Date',
    repeatsAnnuallyHebrew: 'Repeats annually (Hebrew Year)',
    repeatsMonthlyHebrew: 'Repeats monthly (Hebrew Month)',
    doesNotRepeat: 'Does not repeat (One-Time Only)',
    repeatCount: 'Number of Repeats',
    repeatEnd: 'Recurrence End',
    repeatForever: 'Repeat forever (no end)',
    repeatCustomCount: 'End after number of repeats',
    times: 'times',
    repeatsTimes: 'Repeats',
    participants: 'Guests',
    addParticipant: 'Add guests',
    addParticipantPlaceholder: 'Add guests (names or email addresses)',
    add: 'Add',
    noParticipants: 'No guests added yet',
    participantCount: 'guests',
    participantSingular: 'guest',
    hebrewTitleOptional: 'Hebrew Title / Translation (Optional)',
    hebrewTitlePlaceholder: "e.g. Dad's Hebrew Birthday",
    calendarEventColor: 'Calendar Event Color',
    enableReminderNotification: 'Enable Reminder Notification',
    onDayOfEvent: 'On the day of the event',
    oneDayBefore: '1 day before',
    twoDaysBefore: '2 days before',
    threeDaysBefore: '3 days before',
    oneWeekBefore: '1 week before',
    candleLightingMemorial: 'Show Candle Lighting Reminder / Hazkarat Neshamot',
    addLocation: 'Add location',
    addNotesPlaceholder: 'Add notes or description...',
    advancedHebrewOptions: 'Advanced Hebrew Options',
    occurrenceCounter: 'Show Occurrence / Age Counter near Title',
    showOccurrenceAgeCounter: 'Show Occurrence / Age Counter near Title',
    occurrenceCounterDesc: 'Appends the count (e.g., birthday age or anniversary year) to the title next to the event.',
    startHebrewYear: 'Start Hebrew Year (Birth / Origin Year)',
    startHebrewYearLabel: 'Start Hebrew Year (Birth / Origin Year)',
    initialCount: 'Initial Count (Default: 1)',
    initialCountLabel: 'Initial Count (Default: 1)',
    adarLeapYearRule: 'Adar Leap Year Rule',
    observeAdar2: 'Observe in Adar II (Standard Ashkenazi)',
    observeAdar1: 'Observe in Adar I (Sefardi)',
    observeBothAdars: 'Observe in Both Adars',
    overrideHebrewDateDirectly: 'Override Hebrew Date Directly',
    month: 'Month',
    day: 'Day',
    upcomingGregorianOccurrences: 'Upcoming occurrences on Gregorian Calendar:',
    days: 'days',
    daySingular: 'day',
    pleaseEnterTitle: 'Please enter an event title',
    notes: 'Notes',
    save: 'Save',
    cancel: 'Cancel',
    close: 'Close',
    delete: 'Delete',
    importExport: 'Import / Export',
    noEvents: 'No events saved yet.',
    searchEvents: 'Search events...',
    allTypes: 'All Types',
    exportICal: 'Export iCal (.ics)',
    exportBackup: 'Backup (JSON)',
    importBackup: 'Restore / Import',
    
    settingsTitle: 'Calendar Settings',
    settingsSubtitle: 'Customize language, Halachic opinions, display, and alerts',
    languageSection: 'Language & Orientation',
    languageDesc: 'Choose interface language and layout direction (RTL / LTR)',
    english: 'English (LTR)',
    hebrew: 'עברית (RTL)',
    appearanceSection: 'Appearance & Views',
    theme: 'Color Theme',
    darkMode: 'Dark Mode',
    lightMode: 'Light Mode',
    defaultView: 'Default View Mode',
    displayPreferences: 'Calendar Display Elements',
    showDafYomi: 'Show Daf Yomi',
    showOmer: 'Show Sefirat HaOmer',
    showParasha: 'Show Weekly Parasha',
    showHebrewGematriya: 'Show Hebrew Date in Gematriya',
    showSecularDates: 'Show Secular Gregorian Dates',
    halachicOpinions: 'Halachic Opinions & Zmanim',
    shabbatOffset: 'Shabbat Candle-Lighting Offset',
    minutesBeforeSunset: 'minutes before sunset',
    havdalahOpinion: 'Havdalah Opinion',
    zmanimCalculation: 'Zmanim Calculation Method',
    graOpinion: 'GRA (Vilna Gaon - Sunrise to Sunset)',
    mgaOpinion: 'Magen Avraham (Dawn to Nightfall)',
    elevationAdjustment: 'Account for Topographical Elevation',
    notificationSettings: 'Notifications & Alerts',
    enableAlerts: 'Enable Push Notifications',
    shabbatCandleAlerts: 'Candle Lighting & Shabbat Reminders',
    holidayAlerts: 'Jewish Holidays & Fast Days',
    dailyVerseNotification: 'Daily Verse / Thought of the Day',
    personalEventReminders: 'Hebrew Birthdays & Yahrzeits',
    savedSuccessfully: 'Settings saved successfully',
    resetDefaults: 'Reset to Defaults',
  },
  he: {
    appName: 'לוחות בה',
    appSubtitle: 'לוח שנה עברי, זמני היום לפי ההלכה וסנכרון רב-מכשירי',
    hebrewCalendar: 'לוח שנה עברי',
    nextZman: 'הזמן הבא',
    selectLocation: 'בחירת מיקום',
    setManualLocation: 'הגדרת מיקום ידני...',
    gps: 'GPS',
    
    viewMonth: 'חודש',
    viewWeek: 'שבוע',
    viewDay: 'יום',
    viewAgenda: 'רשימה',
    
    dateConverter: 'ממיר תאריכים',
    eventsManager: 'אירועים אישיים',
    homeWidget: 'וידג׳ט מסך בית',
    notifications: 'התראות ותזכורות',
    syncDevices: 'סנכרון מכשירים',
    settings: 'הגדרות',
    toggleTheme: 'החלפת ערכת נושא',
    switchLanguage: 'English (LTR)',
    
    today: 'היום',
    previousMonth: 'חודש קודם',
    nextMonth: 'חודש הבא',
    previousWeek: 'שבוע קודם',
    nextWeek: 'שבוע הבא',
    previousDay: 'יום קודם',
    nextDay: 'יום הבא',
    jumpToDate: 'קפוץ לתאריך',
    
    sun: 'ראשון',
    mon: 'שני',
    tue: 'שלישי',
    wed: 'רביעי',
    thu: 'חמישי',
    fri: 'שישי',
    sat: 'שבת',
    
    parashatHashavua: 'פרשת השבוע',
    candleLighting: 'הדלקת נרות',
    havdalah: 'צאת השבת / הבדלה',
    roshChodesh: 'ראש חודש',
    fastDay: 'יום צום',
    yomTov: 'יום טוב',
    cholHamoed: 'חול המועד',
    omerCount: 'ספירת העומר',
    dafYomi: 'דף היומי',
    weeklyPortion: 'קריאת התורה השבועית',
    todayZmanim: 'זמני היום לפי ההלכה',
    halachicTimesSummary: 'זמני תפילה, קריאת שמע ומצוות התלויות ביום',
    dailyVerse: 'רעיון / פסוק יומי',
    dailyVerseSubtitle: 'פנינה יומית מן המקורות',
    copyVerse: 'העתק פסוק',
    verseCopied: 'הועתק!',
    
    personalEvents: 'אירועים עבריים וימי זיכרון',
    personalEventsTitle: 'אירועים אישיים, ימי הולדת ואזכרות',
    personalEventsDesc: 'ניהול ימי הולדת עבריים, אזכרות, ימי נישואין וסנכרון לוחות',
    addEvent: 'הוספת אירוע',
    createEvent: 'יצירת אירוע',
    editEvent: 'עריכת אירוע',
    deleteEvent: 'מחיקת אירוע',
    eventTitle: 'שם האירוע',
    eventTitlePlaceholder: 'הוספת כותרת',
    eventType: 'סוג האירוע',
    birthday: 'יום הולדת',
    hebrewBirthday: 'יום הולדת עברי',
    yahrzeit: 'יארצייט / אזכרה',
    yahrzeitMemorial: 'יארצייט / אזכרה',
    anniversary: 'יום נישואין',
    hebrewAnniversary: 'יום נישואין עברי',
    barmitzvah: 'בר מצווה',
    batmitzvah: 'בת מצווה',
    barBatMitzvah: 'בר/בת מצווה',
    memorial: 'יום זיכרון',
    customEvent: 'אירוע מותאם',
    customHebrewEvent: 'אירוע עברי מותאם',
    hebrewDate: 'תאריך עברי',
    gregorianDate: 'תאריך לועזי',
    repeatsAnnuallyHebrew: 'חוזר מדי שנה (לפי השנה העברית)',
    repeatsMonthlyHebrew: 'חוזר מדי חודש (לפי החודש העברי)',
    doesNotRepeat: 'אינו חוזר (אירוע חד-פעמי)',
    repeatCount: 'מספר חזרות',
    repeatEnd: 'סיום חזרתיות',
    repeatForever: 'ללא הגבלה (לתמיד)',
    repeatCustomCount: 'הגבל למספר חזרות',
    times: 'פעמים',
    repeatsTimes: 'חזרות',
    participants: 'אורחים',
    addParticipant: 'הוספת אורחים',
    addParticipantPlaceholder: 'הוספת אורחים (שמות או כתובות אימייל)',
    add: 'הוסף',
    noParticipants: 'טרם נוספו אורחים',
    participantCount: 'אורחים',
    participantSingular: 'אורח',
    hebrewTitleOptional: 'כותרת עברית / תרגום (אופציונלי)',
    hebrewTitlePlaceholder: 'למשל: יום הולדת לאבא',
    calendarEventColor: 'צבע אירוע בלוח',
    enableReminderNotification: 'הפעל התראת תזכורת',
    onDayOfEvent: 'ביום האירוע',
    oneDayBefore: 'יום אחד לפני',
    twoDaysBefore: 'יומיים לפני',
    threeDaysBefore: '3 ימים לפני',
    oneWeekBefore: 'שבוע לפני',
    candleLightingMemorial: 'הצג תזכורת הדלקת נר נשמה / הזכרת נשמות',
    addLocation: 'הוספת מיקום',
    addNotesPlaceholder: 'הוספת הערות או תיאור...',
    advancedHebrewOptions: 'אפשרויות עבריות מתקדמות',
    occurrenceCounter: 'הצג מונה שנים / גיל ליד הכותרת',
    showOccurrenceAgeCounter: 'הצג מונה שנים / גיל ליד הכותרת',
    occurrenceCounterDesc: 'מציג את מניין השנים (למשל גיל יום הולדת או שנת נישואין) ליד כותרת האירוע.',
    startHebrewYear: 'שנת מקור עברית (שנת לידה / ייסוד)',
    startHebrewYearLabel: 'שנת מקור עברית (שנת לידה / ייסוד)',
    initialCount: 'מספר מונה התחלתי (ברירת מחדל: 1)',
    initialCountLabel: 'מספר מונה התחלתי (ברירת מחדל: 1)',
    adarLeapYearRule: 'הוראת שנה מעוברת (אדר)',
    observeAdar2: 'ציון באדר ב׳ (מנהג אשכנז המקובל)',
    observeAdar1: 'ציון באדר א׳ (מנהג ספרד)',
    observeBothAdars: 'ציון בשני האדרים (אדר א׳ וב׳)',
    overrideHebrewDateDirectly: 'קביעת תאריך עברי ידנית',
    month: 'חודש',
    day: 'יום',
    upcomingGregorianOccurrences: 'מועדים קרובים בלוח הלועזי:',
    days: 'ימים',
    daySingular: 'יום',
    pleaseEnterTitle: 'נא להזין כותרת לאירוע',
    notes: 'הערות נוספות',
    save: 'שמור',
    cancel: 'ביטול',
    close: 'סגור',
    delete: 'מחק',
    importExport: 'ייבוא / ייצוא',
    noEvents: 'עדיין לא נשמרו אירועים.',
    searchEvents: 'חיפוש אירועים...',
    allTypes: 'כל הסוגים',
    exportICal: 'ייצוא ליומן (iCal)',
    exportBackup: 'גיבוי (JSON)',
    importBackup: 'שחזור / ייבוא',
    
    settingsTitle: 'הגדרות לוח השנה',
    settingsSubtitle: 'התאמת שפה, שיטות חישוב זמני הלכה, תצוגה והתראות',
    languageSection: 'שפת ממשק וכיוון תצוגה',
    languageDesc: 'בחירת שפת הממשק וכיוון קריאה (עברית RTL או אנגלית LTR)',
    english: 'English (LTR)',
    hebrew: 'עברית (RTL)',
    appearanceSection: 'מראה ותצוגה',
    theme: 'ערכת צבעים',
    darkMode: 'מצב כהה (Dark)',
    lightMode: 'מצב בהיר (Light)',
    defaultView: 'תצוגת ברירת מחדל',
    displayPreferences: 'רכיבי לוח שנה',
    showDafYomi: 'הצג דף יומי',
    showOmer: 'הצג ספירת העומר',
    showParasha: 'הצג פרשת שבוע',
    showHebrewGematriya: 'הצג תאריך עברי באותיות (גימטריה)',
    showSecularDates: 'הצג תאריכים לועזיים',
    halachicOpinions: 'שיטות הלכתיות וזמני היום',
    shabbatOffset: 'הקדמת כניסת שבת (הדלקת נרות)',
    minutesBeforeSunset: 'דקות לפני השקיעה',
    havdalahOpinion: 'שיטת צאת השבת והבדלה',
    zmanimCalculation: 'שיטת חישוב שעות זמניות',
    graOpinion: 'הגר״א (הנץ עד השקיעה)',
    mgaOpinion: 'מגן אברהם (עלות השחר עד צאת הכוכבים)',
    elevationAdjustment: 'התחשבות בגובה פני הקרקע (טופוגרפיה)',
    notificationSettings: 'התראות ותזכורות',
    enableAlerts: 'הפעל התראות דפדפן',
    shabbatCandleAlerts: 'תזכורת כניסת שבת והדלקת נרות',
    holidayAlerts: 'מועדי ישראל וצומות',
    dailyVerseNotification: 'התראת רעיון תורני יומי',
    personalEventReminders: 'תזכורות ימי הולדת ואזכרות',
    savedSuccessfully: 'ההגדרות נשמרו בהצלחה',
    resetDefaults: 'איפוס לברירת מחדל',
  },
};

export function getTranslations(lang: Language = 'en'): Translations {
  return translations[lang] || translations.en;
}
