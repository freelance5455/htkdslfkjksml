/**
 * J.A.R.V.I.S. MARK VII — PERMANENT TIME & SPEECH FORMAT ENGINE
 * 
 * Strict architectural rules:
 * 1. Single source of truth: Device hardware system clock (new Date()).
 * 2. Strictly locked to Asia/Kolkata timezone (IST, UTC+05:30).
 * 3. Reads the complete time as one unified value (e.g. 19:15), never separately interpreting hours and minutes.
 * 4. Never converts minute value into a separate hour.
 * 5. Accurately distinguishes morning (सुबह: 04:00-11:59), afternoon (दोपहर: 12:00-15:59), evening (शाम: 16:00-19:59), and night (रात: 20:00-03:59).
 * 6. Converts complete time into natural, authentic Hindi speech words (e.g. "शाम सात बजकर पंद्रह मिनट", "रात के बारह बजे").
 * 7. Zero LLM guessing or hallucination.
 */

export const INDIA_TIMEZONE = 'Asia/Kolkata';

export interface DeviceClockValidation {
  isValid: boolean;
  warning?: string;
}

export interface ISTTimeComponents {
  hour24: number;          // 0 to 23 (e.g. 19)
  minute: number;          // 0 to 59 (e.g. 15)
  second: number;          // 0 to 59
  hour12: number;          // 1 to 12 (e.g. 7)
  period: 'AM' | 'PM';     // 'AM' or 'PM'
  time24: string;          // "19:15"
  time12: string;          // "7:15 PM"
  timeWithSeconds: string; // "7:15:32 PM"
  periodHindi: 'सुबह' | 'दोपहर' | 'शाम' | 'रात';
  hindiSpeech: string;     // e.g. "शाम सात बजकर पंद्रह मिनट" or "रात के बारह बजे"
}

// Authentic Hindi Words for 12-hour values (1 to 12)
export const HINDI_HOURS: Record<number, string> = {
  1: 'एक',
  2: 'दो',
  3: 'तीन',
  4: 'चार',
  5: 'पाँच',
  6: 'छह',
  7: 'सात',
  8: 'आठ',
  9: 'नौ',
  10: 'दस',
  11: 'ग्यारह',
  12: 'बारह',
};

// Authentic Hindi Words for all 60 minutes (0 to 59)
// Crucial: Minutes are strictly mapped to minute values and NEVER converted into hours!
export const HINDI_MINUTES: string[] = [
  'शून्य', 'एक', 'दो', 'तीन', 'चार', 'पाँच', 'छह', 'सात', 'आठ', 'नौ',
  'दस', 'ग्यारह', 'बारह', 'तेरह', 'चौदह', 'पंद्रह', 'सोलह', 'सत्रह', 'अठारह', 'उन्नीस',
  'बीस', 'इक्कीस', 'बाईस', 'तेईस', 'चौबीस', 'पच्चीस', 'छब्बीस', 'सत्ताईस', 'अट्ठाईस', 'उनतीस',
  'तीस', 'इकतीस', 'बत्तीस', 'तैंतीस', 'चौंतीस', 'पैंतीस', 'छत्तीस', 'सैंतीस', 'अड़तीस', 'उनतालीस',
  'चालीस', 'इकतालीस', 'बयालीस', 'तैंतालीस', 'चवालीस', 'पैंतालीस', 'छियालीस', 'सैंतालीस', 'अड़तालीस', 'उनचास',
  'पचास', 'इक्यावन', 'बावन', 'तिरेपन', 'चौवन', 'पचपन', 'छप्पन', 'सत्तावन', 'अट्ठावन', 'उनसठ',
];

/**
 * Accurately determines time period according to Indian cultural and astronomical conventions:
 * - 04:00 to 11:59: सुबह (Morning)
 * - 12:00 to 15:59: दोपहर (Afternoon)
 * - 16:00 to 19:59: शाम (Evening)
 * - 20:00 to 03:59: रात (Night)
 */
export function getTimePeriodHindi(hour24: number): 'सुबह' | 'दोपहर' | 'शाम' | 'रात' {
  const h = ((hour24 % 24) + 24) % 24;
  if (h >= 4 && h < 12) {
    return 'सुबह';
  } else if (h >= 12 && h < 16) {
    return 'दोपहर';
  } else if (h >= 16 && h < 20) {
    return 'शाम';
  } else {
    return 'रात';
  }
}

/**
 * Formats complete hour and minute into natural Hindi speech without numeric colons.
 * Examples:
 * - 07:15 AM (07, 15) -> "सुबह सात बजकर पंद्रह मिनट"
 * - 12:15 PM (12, 15) -> "दोपहर बारह बजकर पंद्रह मिनट"
 * - 03:15 PM (15, 15) -> "दोपहर तीन बजकर पंद्रह मिनट"
 * - 07:15 PM (19, 15) -> "शाम सात बजकर पंद्रह मिनट"
 * - 09:45 PM (21, 45) -> "रात नौ बजकर पैंतालीस मिनट"
 * - 12:00 AM (00, 00) -> "रात के बारह बजे"
 * - 12:00 PM (12, 00) -> "दोपहर के बारह बजे"
 */
export function formatTimeHindiSpeech(hour24: number, minute: number): string {
  const clampedHour = Math.max(0, Math.min(23, Math.floor(hour24)));
  const clampedMinute = Math.max(0, Math.min(59, Math.floor(minute)));

  const period = getTimePeriodHindi(clampedHour);
  const hour12 = clampedHour % 12 || 12;
  const hourWord = HINDI_HOURS[hour12];

  if (clampedMinute === 0) {
    return `${period} के ${hourWord} बजे`;
  }

  const minuteWord = HINDI_MINUTES[clampedMinute];
  return `${period} ${hourWord} बजकर ${minuteWord} मिनट`;
}

export class TimeService {
  /**
   * Always reads directly from device system hardware clock.
   */
  public getNow(): Date {
    return new Date();
  }

  /**
   * Validates device clock sanity.
   * If user phone clock is reset to 1970 or before 2024, flags an issue.
   */
  public validateDeviceClock(now = this.getNow()): DeviceClockValidation {
    const year = now.getFullYear();
    if (year < 2024 || isNaN(now.getTime())) {
      return {
        isValid: false,
        warning: 'Harman Sir, आपके फ़ोन की सिस्टम घड़ी गलत तारीख या समय दिखा रही है। कृपया फ़ोन सेटिंग्स में जाकर समय और तारीख सही कर लीजिए।',
      };
    }
    return { isValid: true };
  }

  /**
   * Atomically extracts complete IST time components in Asia/Kolkata timezone.
   * Reads hour, minute, and second in ONE unified pass.
   */
  public getISTComponents(now = this.getNow()): ISTTimeComponents {
    let hour24 = 0;
    let minute = 0;
    let second = 0;

    try {
      const formatter = new Intl.DateTimeFormat('en-GB', {
        timeZone: INDIA_TIMEZONE,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      });

      const parts = formatter.formatToParts(now);
      for (const part of parts) {
        if (part.type === 'hour') hour24 = parseInt(part.value, 10);
        if (part.type === 'minute') minute = parseInt(part.value, 10);
        if (part.type === 'second') second = parseInt(part.value, 10);
      }
    } catch {
      // Direct mathematical fallback to UTC+05:30
      const istDate = this.getISTDateObject(now);
      hour24 = istDate.getUTCHours();
      minute = istDate.getUTCMinutes();
      second = istDate.getUTCSeconds();
    }

    // Guard bounds
    hour24 = Math.max(0, Math.min(23, isNaN(hour24) ? 0 : hour24));
    minute = Math.max(0, Math.min(59, isNaN(minute) ? 0 : minute));
    second = Math.max(0, Math.min(59, isNaN(second) ? 0 : second));

    const period: 'AM' | 'PM' = hour24 >= 12 ? 'PM' : 'AM';
    const hour12 = hour24 % 12 || 12;

    const time24 = `${String(hour24).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    const time12 = `${hour12}:${String(minute).padStart(2, '0')} ${period}`;
    const timeWithSeconds = `${hour12}:${String(minute).padStart(2, '0')}:${String(second).padStart(2, '0')} ${period}`;

    const periodHindi = getTimePeriodHindi(hour24);
    const hindiSpeech = formatTimeHindiSpeech(hour24, minute);

    return {
      hour24,
      minute,
      second,
      hour12,
      period,
      time24,
      time12,
      timeWithSeconds,
      periodHindi,
      hindiSpeech,
    };
  }

  /**
   * Formats strict 12-hour time with seconds (e.g. "4:15:32 PM", "10:05:00 AM").
   */
  public format12HourTimeWithSeconds(now = this.getNow()): string {
    const comp = this.getISTComponents(now);
    return comp.timeWithSeconds;
  }

  /**
   * Short 12-hour time (e.g. "4:15 PM").
   */
  public format12HourTimeShort(now = this.getNow()): string {
    const comp = this.getISTComponents(now);
    return comp.time12;
  }

  /**
   * Natural Hindi speech string (e.g. "शाम सात बजकर पंद्रह मिनट", "रात के बारह बजे").
   */
  public formatHindiTimeSpeech(now = this.getNow()): string {
    const comp = this.getISTComponents(now);
    return comp.hindiSpeech;
  }

  /**
   * 24-hour HH:mm time strictly for matching scheduled alarms (e.g. "06:00", "18:30").
   */
  public format24HourAlarmTime(now = this.getNow()): string {
    const comp = this.getISTComponents(now);
    return comp.time24;
  }

  /**
   * Minute key (e.g. "2026-11-02 06:00") to prevent missed or duplicate alarm triggers across throttled ticks.
   */
  public getMinuteKey(now = this.getNow()): string {
    try {
      const formatter = new Intl.DateTimeFormat('en-CA', {
        timeZone: INDIA_TIMEZONE,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      });
      return formatter.format(now);
    } catch {
      return `${this.format24HourAlarmTime(now)}`;
    }
  }

  /**
   * Formats dynamic full date with weekday, day, month, and year.
   */
  public formatFullDate(now = this.getNow(), lang: 'hi' | 'en' | 'pa' = 'hi'): string {
    if (lang === 'hi') {
      const weekdays = ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'];
      const months = ['जनवरी', 'फरवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'];
      const ist = this.getISTDateObject(now);
      const dayName = weekdays[ist.getUTCDay()];
      const dayNum = ist.getUTCDate();
      const monthName = months[ist.getUTCMonth()];
      const year = ist.getUTCFullYear();
      return `${dayName}, ${dayNum} ${monthName} ${year}`;
    }

    if (lang === 'pa') {
      const weekdays = ['ਐਤਵਾਰ', 'ਸੋਮਵਾਰ', 'ਮੰਗਲਵਾਰ', 'ਬੁੱਧਵਾਰ', 'ਵੀਰਵਾਰ', 'ਸ਼ੁੱਕਰਵਾਰ', 'ਸ਼ਨੀਵਾਰ'];
      const months = ['ਜਨਵਰੀ', 'ਫ਼ਰਵਰੀ', 'ਮਾਰਚ', 'ਅਪ੍ਰੈਲ', 'ਮਈ', 'ਜੂਨ', 'ਜੁਲਾਈ', 'ਅਗਸਤ', 'ਸਤੰਬਰ', 'ਅਕਤੂਬਰ', 'ਨਵੰਬਰ', 'ਦਸੰਬਰ'];
      const ist = this.getISTDateObject(now);
      const dayName = weekdays[ist.getUTCDay()];
      const dayNum = ist.getUTCDate();
      const monthName = months[ist.getUTCMonth()];
      const year = ist.getUTCFullYear();
      return `${dayName}, ${dayNum} ${monthName} ${year}`;
    }

    // English
    try {
      const formatter = new Intl.DateTimeFormat('en-IN', {
        timeZone: INDIA_TIMEZONE,
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
      return formatter.format(now);
    } catch {
      return now.toDateString();
    }
  }

  /**
   * Returns current day of the week (e.g. "सोमवार" / "Monday").
   */
  public getDayOfWeek(now = this.getNow(), lang: 'hi' | 'en' | 'pa' = 'hi'): string {
    const ist = this.getISTDateObject(now);
    const dayIdx = ist.getUTCDay();

    if (lang === 'hi') {
      const days = ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'];
      return days[dayIdx];
    }
    if (lang === 'pa') {
      const days = ['ਐਤਵਾਰ', 'ਸੋਮਵਾਰ', 'ਮੰਗਲਵਾਰ', 'ਬੁੱਧਵਾਰ', 'ਵੀਰਵਾਰ', 'ਸ਼ੁੱਕਰਵਾਰ', 'ਸ਼ਨੀਵਾਰ'];
      return days[dayIdx];
    }
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[dayIdx];
  }

  /**
   * Generates a conversational, human time briefing addressing Harman Sir.
   * In Hindi: Speaks natural Hindi words: "Harman Sir, अभी समय शाम सात बजकर पंद्रह मिनट है।"
   * In English: "Harman Sir, the time is 7:15 PM."
   */
  public getTimeBriefing(now = this.getNow(), isHindi = true): string {
    const clockCheck = this.validateDeviceClock(now);
    if (!clockCheck.isValid) {
      return clockCheck.warning || 'Harman Sir, कृपया अपने फोन का समय सही कर लीजिए।';
    }

    const comp = this.getISTComponents(now);
    if (isHindi) {
      // Pure natural Hindi speech format + clean timestamp in parenthesis for visual UI
      return `Harman Sir, अभी समय ${comp.hindiSpeech} है। (${comp.time12})`;
    }
    return `Harman Sir, the time is ${comp.time12}.`;
  }

  /**
   * Pure speech string guaranteed without numeric colons for voice synthesizer.
   */
  public getTimeVoiceText(now = this.getNow(), isHindi = true): string {
    const comp = this.getISTComponents(now);
    if (isHindi) {
      return `Harman Sir, अभी समय ${comp.hindiSpeech} है।`;
    }
    return `Harman Sir, the time is ${comp.hour12} ${comp.minute === 0 ? "o'clock" : comp.minute} ${comp.period}.`;
  }

  /**
   * Generates full date briefing.
   */
  public getDateBriefing(now = this.getNow(), isHindi = true): string {
    const clockCheck = this.validateDeviceClock(now);
    if (!clockCheck.isValid) {
      return clockCheck.warning || 'Harman Sir, कृपया अपने फोन की तारीख सही कर लीजिए।';
    }

    const dateStr = this.formatFullDate(now, isHindi ? 'hi' : 'en');
    if (isHindi) {
      return `Harman Sir, आज ${dateStr} है।`;
    }
    return `Harman Sir, today is ${dateStr}.`;
  }

  /**
   * Combined time and weather briefing.
   */
  public getTimeAndDateBriefing(now = this.getNow(), isHindi = true): string {
    const clockCheck = this.validateDeviceClock(now);
    if (!clockCheck.isValid) {
      return clockCheck.warning || '';
    }

    const comp = this.getISTComponents(now);
    const dateStr = this.formatFullDate(now, isHindi ? 'hi' : 'en');
    if (isHindi) {
      return `Harman Sir, अभी समय ${comp.hindiSpeech} है और आज ${dateStr} है। (${comp.time12})`;
    }
    return `Harman Sir, it is ${comp.time12} on ${dateStr}.`;
  }

  /**
   * Helper: converts device timestamp into UTC Date shifted by IST offset (+5 hours 30 mins).
   */
  public getISTDateObject(date: Date): Date {
    const utcMs = date.getTime() + (date.getTimezoneOffset() * 60000);
    const istOffsetMs = (5 * 60 + 30) * 60000;
    return new Date(utcMs + istOffsetMs);
  }
}

export const timeService = new TimeService();
