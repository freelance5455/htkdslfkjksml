"use client";

import { create } from "zustand";
import {
  AppSettings, BotStatus, ClosedTrade, ExchangeId, FeedHealth, HeatmapCoin,
  LogEntry, MasterTrader, MtfSnapshot, OptimizerState, OrderBook, PendingOrder,
  Position, RegimeState, StrategyScore, SymbolId, TabId, Tick, TradeDiagnostics,
  TradeSide, TradeSource, SYMBOLS, SYMBOL_META,
} from "@/types";

const START_BALANCE = 10_000;
const FEE_RATE = 0.0006; // taker fee per side

// ─── Pure browser persistence (window.localStorage — no backend/DB) ─────────
const PERSIST_KEY = "ct_state_v1";

interface PersistedSlice {
  balance: number;
  startBalance: number;
  dailyPnl: number;
  riskHalted: boolean;
  positions: Position[];
  closedTrades: ClosedTrade[];
  pendingOrders: PendingOrder[];
  settings: AppSettings;
  optimizer: OptimizerState;
  logs: LogEntry[];
  masterTraders: MasterTrader[];
}

function loadPersisted(): Partial<PersistedSlice> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(PERSIST_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Partial<PersistedSlice>;
  } catch {
    return {};
  }
}

const persisted = loadPersisted();

let idSeq = 0;
export const uid = (p = "id") => `${p}_${Date.now()}_${idSeq++}`;

// trade-closed listeners (optimizer / strategy engine subscribe without circular deps)
type TradeClosedListener = (t: ClosedTrade) => void;
const tradeClosedListeners: TradeClosedListener[] = [];
export function onTradeClosed(fn: TradeClosedListener) {
  tradeClosedListeners.push(fn);
}

// trade-opened listeners (notifications)
type TradeOpenedListener = (p: Position) => void;
const tradeOpenedListeners: TradeOpenedListener[] = [];
export function onTradeOpened(fn: TradeOpenedListener) {
  tradeOpenedListeners.push(fn);
}

export interface OpenPositionInput {
  symbol: SymbolId;
  side: TradeSide;
  source: TradeSource;
  strategyId: string;
  strategyName: string;
  masterTrader?: string;
  entryPrice: number;
  qty: number;
  leverage: number;
  stopLoss: number;
  takeProfit: number;
  atrAtEntry: number;
  trailingStop?: boolean;
  diagnostics?: TradeDiagnostics;
}

interface TradingState {
  // market
  prices: Record<SymbolId, number>;
  priceDir: Record<SymbolId, 1 | -1 | 0>;
  change24h: Record<SymbolId, number>;
  feeds: FeedHealth[];
  bestFeed: ExchangeId;
  feedMode: "LIVE" | "SIM";
  tape: Tick[];
  orderBook: OrderBook;
  mtf: Partial<Record<SymbolId, MtfSnapshot>>;
  fearGreed: number;
  heatmap: HeatmapCoin[];

  // account
  balance: number;
  startBalance: number;
  positions: Position[];
  closedTrades: ClosedTrade[];
  pendingOrders: PendingOrder[];
  dailyPnl: number;

  // bot
  isAutoBotActive: boolean;
  botStatus: BotStatus;
  riskHalted: boolean;
  lastScanAt: number;

  // strategy
  strategies: StrategyScore[];
  activeStrategyId: string;
  regime: RegimeState;

  // copy
  masterTraders: MasterTrader[];

  // learning
  optimizer: OptimizerState;

  // ui
  activeTab: TabId;
  selectedSymbol: SymbolId;
  logs: LogEntry[];
  settings: AppSettings;
  locked: boolean;
  chartModal: { symbol: SymbolId } | null;

  // actions
  setActiveTab: (t: TabId) => void;
  setSelectedSymbol: (s: SymbolId) => void;
  setLocked: (v: boolean) => void;
  setChartModal: (v: { symbol: SymbolId } | null) => void;
  applyMarket: (p: Partial<TradingState>) => void;
  addTapeTicks: (ticks: Tick[]) => void;
  addLog: (kind: LogEntry["kind"], text: string) => void;
  setSettings: (p: Partial<AppSettings>) => void;

  openPosition: (input: OpenPositionInput) => Position | null;
  closePosition: (id: string, exitPrice: number, reason: string, fraction?: number) => void;
  updatePositionRisk: (id: string, sl: number, tp: number) => void;
  applyTickToPositions: (prices: Record<SymbolId, number>) => void;
  placePendingOrder: (o: Omit<PendingOrder, "id" | "createdAt">) => void;
  cancelPendingOrder: (id: string) => void;

  setBotActive: (v: boolean) => void;
  setBotStatus: (s: BotStatus) => void;
  emergencyStop: () => void;
  resetRiskHalt: () => void;
  resetDemoAccount: () => void;
  clearClosedTrades: () => void;

  setStrategies: (s: StrategyScore[], activeId: string) => void;
  setRegime: (r: RegimeState) => void;
  setMasterTraders: (m: MasterTrader[]) => void;
  toggleFollowTrader: (id: string) => void;
  setOptimizer: (o: Partial<OptimizerState>) => void;
  setMtf: (symbol: SymbolId, snap: MtfSnapshot) => void;
}

const initialPrices = Object.fromEntries(
  SYMBOLS.map((s) => [s, SYMBOL_META[s].base]),
) as Record<SymbolId, number>;

export const useTradingStore = create<TradingState>((set, get) => ({
  prices: initialPrices,
  priceDir: { BTCUSDT: 0, ETHUSDT: 0, SOLUSDT: 0, BNBUSDT: 0 },
  change24h: { BTCUSDT: 1.8, ETHUSDT: 2.4, SOLUSDT: -1.2, BNBUSDT: 0.7 },
  feeds: [],
  bestFeed: "Bybit",
  feedMode: "SIM",
  tape: [],
  orderBook: { bids: [], asks: [] },
  mtf: {},
  fearGreed: 54,
  heatmap: [],

  balance: persisted.balance ?? START_BALANCE,
  startBalance: persisted.startBalance ?? START_BALANCE,
  positions: persisted.positions ?? [],
  closedTrades: persisted.closedTrades ?? [],
  pendingOrders: persisted.pendingOrders ?? [],
  dailyPnl: persisted.dailyPnl ?? 0,

  isAutoBotActive: false,
  botStatus: "OFF",
  riskHalted: persisted.riskHalted ?? false,
  lastScanAt: 0,

  strategies: [],
  activeStrategyId: "trend",
  regime: { regime: "TRENDING", adx: 28, atrPct: 1.2, bbWidth: 3.2, confidence: 70, label: "מגמה חזקה" },

  masterTraders: Array.isArray(persisted.masterTraders) ? persisted.masterTraders : [],

  optimizer: persisted.optimizer ?? {
    targetWinRate: 75,
    currentWinRate: 0,
    tradesAnalyzed: 0,
    confluenceThreshold: 35,
    atrSlMult: 1.5,
    atrTpMult: 2.6,
    rsiOverbought: 70,
    rsiOversold: 30,
    calibrations: 0,
    lastAction: "ממתין לנתוני עסקאות ראשונים…",
  },

  activeTab: "ai",
  selectedSymbol: "BTCUSDT",
  logs: persisted.logs ?? [],
  settings: persisted.settings ?? {
    realTradingUnlocked: false,
    notificationsEnabled: false,
    soundEnabled: true,
    riskPct: 1.5,
    maxConcurrent: 4,
    dailyLossLimitPct: 5,
    copyTradingEnabled: true,
    preferredFeed: "AUTO",
    defaultLeverage: 10,
  },
  locked: true,
  chartModal: null,

  setActiveTab: (t) => set({ activeTab: t }),
  setSelectedSymbol: (s) => set({ selectedSymbol: s }),
  setLocked: (v) => set({ locked: v }),
  setChartModal: (v) => set({ chartModal: v }),
  applyMarket: (p) => set(p as Partial<TradingState>),

  addTapeTicks: (ticks) =>
    set((st) => ({ tape: [...ticks, ...st.tape].slice(0, 60) })),

  addLog: (kind, text) =>
    set((st) => ({
      logs: [{ id: uid("log"), ts: Date.now(), kind, text }, ...st.logs].slice(0, 120),
    })),

  setSettings: (p) => set((st) => ({ settings: { ...st.settings, ...p } })),

  openPosition: (input) => {
    const st = get();
    const notional = input.qty * input.entryPrice;
    const margin = notional / input.leverage;
    const fee = notional * FEE_RATE;
    if (margin + fee > st.balance) {
      get().addLog("warn", `⛔ אין מספיק יתרת דמו לפתיחת עסקה (${input.symbol})`);
      return null;
    }
    const dir = input.side === "LONG" ? 1 : -1;
    const dist = Math.abs(input.takeProfit - input.entryPrice);
    const pos: Position = {
      id: uid("pos"),
      symbol: input.symbol,
      side: input.side,
      source: input.source,
      strategyId: input.strategyId,
      strategyName: input.strategyName,
      masterTrader: input.masterTrader,
      qty: input.qty,
      leverage: input.leverage,
      entryPrice: input.entryPrice,
      markPrice: input.entryPrice,
      margin,
      stopLoss: input.stopLoss,
      takeProfit: input.takeProfit,
      tp1: input.entryPrice + dir * dist * 0.4,
      tp2: input.entryPrice + dir * dist * 0.7,
      tp1Hit: false,
      tp2Hit: false,
      trailingStop: input.trailingStop ?? true,
      atrAtEntry: input.atrAtEntry,
      pnl: -fee,
      pnlPct: 0,
      openedAt: Date.now(),
      diagnostics: input.diagnostics,
    };
    set({ balance: st.balance - margin - fee, positions: [pos, ...st.positions] });
    const srcLabel = input.source === "BOT" ? "🤖 בוט" : input.source === "COPY" ? "👥 Copy" : "✍️ ידני";
    get().addLog(
      "trade",
      `${srcLabel} פתח ${input.side === "LONG" ? "לונג" : "שורט"} ${input.symbol} @ $${input.entryPrice.toFixed(2)} | SL ${input.stopLoss.toFixed(2)} | TP ${input.takeProfit.toFixed(2)}`,
    );
    tradeOpenedListeners.forEach((fn) => fn(pos));
    return pos;
  },

  closePosition: (id, exitPrice, reason, fraction = 1) => {
    const st = get();
    const pos = st.positions.find((p) => p.id === id);
    if (!pos) return;
    const closeQty = pos.qty * Math.min(1, Math.max(0.01, fraction));
    const dir = pos.side === "LONG" ? 1 : -1;
    const gross = (exitPrice - pos.entryPrice) * closeQty * dir;
    const fees = closeQty * exitPrice * FEE_RATE;
    const pnl = gross - fees;
    const marginReleased = pos.margin * (closeQty / pos.qty);
    const pnlPct = (gross / (marginReleased || 1)) * 100;

    const closed: ClosedTrade = {
      id: uid("cls"),
      symbol: pos.symbol,
      side: pos.side,
      source: pos.source,
      strategyId: pos.strategyId,
      strategyName: pos.strategyName,
      masterTrader: pos.masterTrader,
      qty: closeQty,
      leverage: pos.leverage,
      entryPrice: pos.entryPrice,
      exitPrice,
      pnl,
      pnlPct,
      fees,
      closeReason: reason,
      openedAt: pos.openedAt,
      closedAt: Date.now(),
      diagnostics: pos.diagnostics,
    };

    let positions: Position[];
    if (fraction >= 0.999) {
      positions = st.positions.filter((p) => p.id !== id);
    } else {
      positions = st.positions.map((p) =>
        p.id === id
          ? { ...p, qty: p.qty - closeQty, margin: p.margin - marginReleased }
          : p,
      );
    }

    set({
      positions,
      balance: st.balance + marginReleased + pnl,
      closedTrades: [closed, ...st.closedTrades].slice(0, 400),
      dailyPnl: st.dailyPnl + pnl,
    });

    get().addLog(
      "trade",
      `${pnl >= 0 ? "🟢" : "🔴"} נסגרה עסקה ${pos.symbol} (${reason}) | P&L: ${pnl >= 0 ? "+" : ""}$${pnl.toFixed(2)}`,
    );

    tradeClosedListeners.forEach((fn) => fn(closed));
    // the closed-trades ledger is auto-persisted to localStorage (see below)

    // daily loss circuit breaker (5%)
    const stNow = get();
    const lossLimit = (stNow.settings.dailyLossLimitPct / 100) * stNow.startBalance;
    if (stNow.dailyPnl < -lossLimit && !stNow.riskHalted) {
      set({ riskHalted: true, botStatus: "HALTED" });
      get().addLog("warn", `🛑 מעצור סיכון יומי הופעל! הפסד יומי חצה ${stNow.settings.dailyLossLimitPct}% — הבוט הושהה`);
    }
  },

  updatePositionRisk: (id, sl, tp) =>
    set((st) => ({
      positions: st.positions.map((p) =>
        p.id === id ? { ...p, stopLoss: sl, takeProfit: tp } : p,
      ),
    })),

  applyTickToPositions: (prices) => {
    const st = get();
    if (st.positions.length === 0) return;
    const toClose: { id: string; price: number; reason: string; fraction: number }[] = [];
    const updated = st.positions.map((p) => {
      const mark = prices[p.symbol];
      if (!mark) return p;
      const dir = p.side === "LONG" ? 1 : -1;
      const gross = (mark - p.entryPrice) * p.qty * dir;
      const pnlPct = (gross / (p.margin || 1)) * 100;
      const np = { ...p, markPrice: mark, pnl: gross, pnlPct };

      // SL / TP triggers
      const hitSL = dir === 1 ? mark <= p.stopLoss : mark >= p.stopLoss;
      const hitTP = dir === 1 ? mark >= p.takeProfit : mark <= p.takeProfit;
      if (hitSL) {
        toClose.push({ id: p.id, price: mark, reason: "Stop-Loss", fraction: 1 });
        return np;
      }
      if (hitTP) {
        toClose.push({ id: p.id, price: mark, reason: "Take-Profit (TP3)", fraction: 1 });
        return np;
      }
      // Tiered TP1 (30%) + break-even move
      if (!p.tp1Hit && p.tp1 && (dir === 1 ? mark >= p.tp1 : mark <= p.tp1)) {
        toClose.push({ id: p.id, price: mark, reason: "TP1 (30%)", fraction: 0.3 });
        np.tp1Hit = true;
        np.stopLoss = p.entryPrice * (1 + dir * 0.002); // breakeven +0.2% fees
      }
      // TP2 (40%)
      else if (p.tp1Hit && !p.tp2Hit && p.tp2 && (dir === 1 ? mark >= p.tp2 : mark <= p.tp2)) {
        toClose.push({ id: p.id, price: mark, reason: "TP2 (40%)", fraction: 0.57 });
        np.tp2Hit = true;
      }
      // ATR trailing stop after TP1
      if (np.tp1Hit && p.trailingStop && p.atrAtEntry > 0) {
        const trail = mark - dir * p.atrAtEntry * 1.1;
        if (dir === 1 ? trail > np.stopLoss : trail < np.stopLoss) np.stopLoss = trail;
      }
      return np;
    });
    set({ positions: updated });
    toClose.forEach((c) => get().closePosition(c.id, c.price, c.reason, c.fraction));

    // pending orders fill check
    const pend = get().pendingOrders;
    if (pend.length) {
      pend.forEach((o) => {
        const mark = prices[o.symbol];
        if (!mark) return;
        const trig =
          o.type === "LIMIT"
            ? o.limitPrice !== undefined &&
              (o.side === "LONG" ? mark <= o.limitPrice : mark >= o.limitPrice)
            : o.type === "STOP_LIMIT"
              ? o.stopPrice !== undefined &&
                (o.side === "LONG" ? mark >= o.stopPrice : mark <= o.stopPrice)
              : false;
        if (trig) {
          get().cancelPendingOrder(o.id);
          const atr = mark * 0.008;
          get().openPosition({
            symbol: o.symbol, side: o.side, source: "MANUAL",
            strategyId: "manual", strategyName: `${o.type} Order`,
            entryPrice: mark, qty: o.qty, leverage: o.leverage,
            stopLoss: o.side === "LONG" ? mark - atr * 1.5 : mark + atr * 1.5,
            takeProfit: o.side === "LONG" ? mark + atr * 2.5 : mark - atr * 2.5,
            atrAtEntry: atr,
          });
        }
      });
    }
  },

  placePendingOrder: (o) =>
    set((st) => ({
      pendingOrders: [...st.pendingOrders, { ...o, id: uid("ord"), createdAt: Date.now() }],
    })),

  cancelPendingOrder: (id) =>
    set((st) => ({ pendingOrders: st.pendingOrders.filter((o) => o.id !== id) })),

  setBotActive: (v) => {
    set({ isAutoBotActive: v, botStatus: v ? "SCANNING" : "OFF" });
    get().addLog("info", v ? "🚀 הבוט האוטונומי הופעל — מצב דמו (יתרה וירטואלית)" : "⏸️ הבוט האוטונומי כובה");
  },
  setBotStatus: (s) => set({ botStatus: s }),

  emergencyStop: () => {
    const st = get();
    st.positions.forEach((p) => get().closePosition(p.id, p.markPrice, "עצירת חירום"));
    set({ isAutoBotActive: false, botStatus: "OFF", pendingOrders: [] });
    get().addLog("warn", "🚨 עצירת חירום לבוט — כל הפוזיציות נסגרו מיידית");
  },

  resetRiskHalt: () => {
    set({ riskHalted: false, dailyPnl: 0, botStatus: get().isAutoBotActive ? "SCANNING" : "OFF" });
    get().addLog("info", "♻️ מעצור הסיכון אופס — הבוט חוזר לסריקה");
  },

  resetDemoAccount: () => {
    const st = get();
    st.positions.forEach((p) => get().closePosition(p.id, p.markPrice, "איפוס חשבון"));
    set({
      balance: START_BALANCE, dailyPnl: 0, riskHalted: false,
      pendingOrders: [],
    });
    get().addLog("info", "💰 חשבון הדמו אופס ליתרה של $10,000 USDT");
  },

  clearClosedTrades: () => set({ closedTrades: [] }),

  setStrategies: (s, activeId) => set({ strategies: s, activeStrategyId: activeId }),
  setRegime: (r) => set({ regime: r }),
  setMasterTraders: (m) => set({ masterTraders: Array.isArray(m) ? m : [] }),
  toggleFollowTrader: (id) =>
    set((st) => ({
      masterTraders: st.masterTraders.map((t) =>
        t.id === id ? { ...t, followed: !t.followed } : t,
      ),
    })),
  setOptimizer: (o) => set((st) => ({ optimizer: { ...st.optimizer, ...o } })),
  setMtf: (symbol, snap) => set((st) => ({ mtf: { ...st.mtf, [symbol]: snap } })),
}));

export function getEquity(st: Pick<TradingState, "balance" | "positions">) {
  return st.balance + st.positions.reduce((a, p) => a + p.margin + p.pnl, 0);
}

// ─── Auto-persist to localStorage (throttled, pure client-side) ─────────────
if (typeof window !== "undefined") {
  let saveTimer: ReturnType<typeof setTimeout> | null = null;
  useTradingStore.subscribe((st) => {
    if (saveTimer) return;
    saveTimer = setTimeout(() => {
      saveTimer = null;
      const snap: PersistedSlice = {
        balance: st.balance,
        startBalance: st.startBalance,
        dailyPnl: st.dailyPnl,
        riskHalted: st.riskHalted,
        positions: st.positions,
        closedTrades: st.closedTrades,
        pendingOrders: st.pendingOrders,
        settings: st.settings,
        optimizer: st.optimizer,
        logs: st.logs.slice(0, 80),
        masterTraders: st.masterTraders,
      };
      try {
        window.localStorage.setItem(PERSIST_KEY, JSON.stringify(snap));
      } catch { /* storage full / private mode */ }
    }, 800);
  });
}
