import { SoundEffectType, AudioSettings, AppLanguage } from '../types/market';

// Singleton AudioContext with resume-on-first-gesture
let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * High-fidelity Web Audio API sound synthesizer for market alerts
 */
export function playChimeSound(type: SoundEffectType, volume = 0.85): Promise<void> {
  return new Promise((resolve) => {
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(Math.max(0.01, Math.min(volume, 1.0)), now);
      masterGain.connect(ctx.destination);

      switch (type) {
        case 'sonar': {
          // Futuristic radar sonar ping
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(880, now);
          osc.frequency.exponentialRampToValueAtTime(1760, now + 0.08);
          osc.frequency.exponentialRampToValueAtTime(1320, now + 0.35);

          gain.gain.setValueAtTime(0.7, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(now);
          osc.stop(now + 0.5);
          setTimeout(resolve, 500);
          break;
        }

        case 'bell': {
          // Wall Street trading floor bell with authentic acoustic partials
          const freqs = [587.33, 1174.66, 1621.0, 2489.0];
          const weights = [0.6, 0.4, 0.25, 0.15];
          freqs.forEach((freq, idx) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now);

            const decay = 0.8 + idx * 0.2;
            gain.gain.setValueAtTime(weights[idx], now);
            gain.gain.exponentialRampToValueAtTime(0.0001, now + decay);

            osc.connect(gain);
            gain.connect(masterGain);
            osc.start(now);
            osc.stop(now + decay);
          });
          setTimeout(resolve, 900);
          break;
        }

        case 'bullish': {
          // Joyful ascending breakout chord (C5 -> E5 -> G5 -> C6)
          const notes = [523.25, 659.25, 783.99, 1046.5];
          notes.forEach((freq, i) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, now + i * 0.08);

            const startT = now + i * 0.08;
            gain.gain.setValueAtTime(0.0001, startT);
            gain.gain.linearRampToValueAtTime(0.45, startT + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.001, startT + 0.45);

            osc.connect(gain);
            gain.connect(masterGain);
            osc.start(startT);
            osc.stop(startT + 0.45);
          });
          setTimeout(resolve, 800);
          break;
        }

        case 'bearish': {
          // Descending alert siren
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(440, now);
          osc.frequency.exponentialRampToValueAtTime(220, now + 0.35);
          osc.frequency.setValueAtTime(370, now + 0.4);
          osc.frequency.exponentialRampToValueAtTime(180, now + 0.75);

          // Low-pass filter to soften sawtooth harshness
          const filter = ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(1200, now);

          gain.gain.setValueAtTime(0.5, now);
          gain.gain.exponentialRampToValueAtTime(0.01, now + 0.8);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(masterGain);
          osc.start(now);
          osc.stop(now + 0.8);
          setTimeout(resolve, 800);
          break;
        }

        case 'alarm': {
          // Rapid dual-tone warning klaxon
          for (let pulse = 0; pulse < 3; pulse++) {
            const t = now + pulse * 0.18;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'square';
            osc.frequency.setValueAtTime(pulse % 2 === 0 ? 880 : 660, t);

            const filter = ctx.createBiquadFilter();
            filter.type = 'lowpass';
            filter.frequency.setValueAtTime(2000, t);

            gain.gain.setValueAtTime(0.35, t);
            gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

            osc.connect(filter);
            filter.connect(gain);
            gain.connect(masterGain);
            osc.start(t);
            osc.stop(t + 0.15);
          }
          setTimeout(resolve, 600);
          break;
        }

        case 'kaching': {
          // Cash register / coin drop sound
          const osc1 = ctx.createOscillator();
          const osc2 = ctx.createOscillator();
          const gain1 = ctx.createGain();
          const gain2 = ctx.createGain();

          osc1.type = 'sine';
          osc1.frequency.setValueAtTime(1567.98, now); // G6
          gain1.gain.setValueAtTime(0.6, now);
          gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

          osc2.type = 'sine';
          osc2.frequency.setValueAtTime(2093.0, now + 0.08); // C7
          gain2.gain.setValueAtTime(0.65, now + 0.08);
          gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

          osc1.connect(gain1);
          gain1.connect(masterGain);
          osc2.connect(gain2);
          gain2.connect(masterGain);

          osc1.start(now);
          osc1.stop(now + 0.4);
          osc2.start(now + 0.08);
          osc2.stop(now + 0.68);
          setTimeout(resolve, 700);
          break;
        }

        case 'laser': {
          // Sci-fi high tech laser alert
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(2400, now);
          osc.frequency.exponentialRampToValueAtTime(280, now + 0.25);

          gain.gain.setValueAtTime(0.6, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(now);
          osc.stop(now + 0.3);
          setTimeout(resolve, 350);
          break;
        }

        case 'pulsar': {
          // Deep sub-bass pulse
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(140, now);
          osc.frequency.exponentialRampToValueAtTime(55, now + 0.4);

          gain.gain.setValueAtTime(0.8, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(now);
          osc.stop(now + 0.5);
          setTimeout(resolve, 550);
          break;
        }

        default:
          resolve();
      }
    } catch (err) {
      console.warn('Audio synthesis warning:', err);
      resolve();
    }
  });
}

/**
 * Speech synthesis with persona voices & language support
 */
export function speakText(
  text: string,
  settings: AudioSettings,
  languageOverride?: AppLanguage
): Promise<void> {
  return new Promise((resolve) => {
    if (!('speechSynthesis' in window)) {
      console.warn('SpeechSynthesis is not supported on this browser.');
      resolve();
      return;
    }

    try {
      window.speechSynthesis.cancel(); // Stop any pending speech

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.volume = settings.volume;
      utterance.rate = settings.rate;
      utterance.pitch = settings.pitch;

      const voices = window.speechSynthesis.getVoices();
      
      // Determine language from override, persona or fallback
      let lang: AppLanguage = languageOverride || 'fr';
      if (!languageOverride) {
        if (settings.selectedPersona.startsWith('fr')) lang = 'fr';
        else if (settings.selectedPersona.startsWith('de')) lang = 'de';
        else if (settings.selectedPersona.startsWith('es')) lang = 'es';
        else if (settings.selectedPersona.startsWith('it')) lang = 'it';
        else if (settings.selectedPersona.startsWith('ar')) lang = 'ar';
        else lang = 'en';
      }

      switch (lang) {
        case 'ar': {
          utterance.lang = 'ar-SA';
          const arVoice = voices.find(
            (v) =>
              v.lang.startsWith('ar') &&
              (v.name.includes('Maged') ||
                v.name.includes('Tarik') ||
                v.name.includes('Arabic') ||
                v.name.includes('Google العربية') ||
                v.lang.includes('ar-SA') ||
                v.lang.includes('ar-EG'))
          ) || voices.find((v) => v.lang.startsWith('ar'));
          if (arVoice) utterance.voice = arVoice;
          break;
        }

        case 'de': {
          utterance.lang = 'de-DE';
          const deVoice = voices.find(
            (v) =>
              v.lang.startsWith('de') &&
              (v.name.includes('Stefan') ||
                v.name.includes('Katja') ||
                v.name.includes('German') ||
                v.name.includes('Google Deutsch'))
          ) || voices.find((v) => v.lang.startsWith('de'));
          if (deVoice) utterance.voice = deVoice;
          break;
        }

        case 'es': {
          utterance.lang = 'es-ES';
          const esVoice = voices.find(
            (v) =>
              v.lang.startsWith('es') &&
              (v.name.includes('Jorge') ||
                v.name.includes('Monica') ||
                v.name.includes('Spanish') ||
                v.name.includes('Google español'))
          ) || voices.find((v) => v.lang.startsWith('es'));
          if (esVoice) utterance.voice = esVoice;
          break;
        }

        case 'it': {
          utterance.lang = 'it-IT';
          const itVoice = voices.find(
            (v) =>
              v.lang.startsWith('it') &&
              (v.name.includes('Alice') ||
                v.name.includes('Luca') ||
                v.name.includes('Italian') ||
                v.name.includes('Google italiano'))
          ) || voices.find((v) => v.lang.startsWith('it'));
          if (itVoice) utterance.voice = itVoice;
          break;
        }

        case 'fr': {
          utterance.lang = 'fr-FR';
          const frVoice = voices.find(
            (v) =>
              v.lang.startsWith('fr') &&
              (v.name.includes('Thomas') ||
                v.name.includes('Audrey') ||
                v.name.includes('Amelie') ||
                v.name.includes('French') ||
                v.name.includes('Google français'))
          ) || voices.find((v) => v.lang.startsWith('fr'));
          if (frVoice) utterance.voice = frVoice;
          break;
        }

        case 'en':
        default: {
          utterance.lang = 'en-US';
          if (settings.selectedPersona === 'cyber') {
            utterance.pitch = 0.85;
            utterance.rate = 1.15;
          } else if (settings.selectedPersona === 'en-analyst') {
            utterance.lang = 'en-GB';
            const gbVoice = voices.find((v) => v.lang.startsWith('en-GB') || v.lang.includes('GB'));
            if (gbVoice) utterance.voice = gbVoice;
          } else {
            const enVoice = voices.find(
              (v) =>
                v.lang.startsWith('en') &&
                (v.name.includes('David') ||
                  v.name.includes('Guy') ||
                  v.name.includes('Natural') ||
                  v.name.includes('Google US'))
            ) || voices.find((v) => v.lang.startsWith('en'));
            if (enVoice) utterance.voice = enVoice;
          }
          break;
        }
      }

      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech error:', e);
      resolve();
    }
  });
}

/**
 * Full Alert Execution: Chime first, then spoken voice alert message
 */
export async function executeVoiceAlert(
  chime: SoundEffectType,
  message: string,
  settings: AudioSettings,
  languageOverride?: AppLanguage
): Promise<void> {
  if (!settings.masterSoundEnabled) return;

  // Android Native Haptic Vibration on alert trigger
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate([150, 80, 200]);
    } catch {
      // ignore
    }
  }

  if (settings.playChimeFirst) {
    await playChimeSound(chime, settings.volume);
    // Brief natural pause between chime and speech
    await new Promise((r) => setTimeout(r, 220));
  }

  await speakText(message, settings, languageOverride);
}
