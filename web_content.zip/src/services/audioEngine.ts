/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EQState, Track } from '../types';

export class AudioEngine {
  private ctx: AudioContext | null = null;
  public analyser: AnalyserNode | null = null;
  private masterGain: GainNode | null = null;
  
  // 3-band EQ
  private lowFilter: BiquadFilterNode | null = null;
  private midFilter: BiquadFilterNode | null = null;
  private highFilter: BiquadFilterNode | null = null;
  private djFilter: BiquadFilterNode | null = null;

  // Custom audio element
  private audioElement: HTMLAudioElement | null = null;
  private audioSourceNode: MediaElementAudioSourceNode | null = null;
  private micStream: MediaStream | null = null;
  private micSourceNode: MediaStreamAudioSourceNode | null = null;

  // Synthesizer sequencer for generative DJ tracks
  private isSequencerRunning: boolean = false;
  private stepIntervalId: number | null = null;
  private currentStep: number = 0;
  private currentTrack: Track | null = null;
  private playbackRate: number = 1.0;

  // Beat detection
  private beatCutoff: number = 0;
  private beatDecayRate: number = 0.96;
  public isBeat: boolean = false;
  public beatIntensity: number = 0;
  private onBeatCallbacks: Array<(intensity: number) => void> = [];

  // VU Levels
  public leftLevel: number = 0;
  public rightLevel: number = 0;

  constructor() {
    // Lazy init on first user action
  }

  public init() {
    if (this.ctx) return;
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    this.ctx = new AudioCtx();

    // Analyser Node
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 1024;
    this.analyser.smoothingTimeConstant = 0.82;
    this.analyser.minDecibels = -90;
    this.analyser.maxDecibels = -10;

    // Master Gain
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.9;

    // EQ Filters
    this.lowFilter = this.ctx.createBiquadFilter();
    this.lowFilter.type = 'lowshelf';
    this.lowFilter.frequency.value = 320;
    this.lowFilter.gain.value = 0;

    this.midFilter = this.ctx.createBiquadFilter();
    this.midFilter.type = 'peaking';
    this.midFilter.frequency.value = 1000;
    this.midFilter.Q.value = 0.8;
    this.midFilter.gain.value = 0;

    this.highFilter = this.ctx.createBiquadFilter();
    this.highFilter.type = 'highshelf';
    this.highFilter.frequency.value = 3500;
    this.highFilter.gain.value = 0;

    // DJ Resonance Filter (Low-pass / High-pass sweep)
    this.djFilter = this.ctx.createBiquadFilter();
    this.djFilter.type = 'allpass';
    this.djFilter.frequency.value = 20000;
    this.djFilter.Q.value = 3.0;

    // Chain: Input -> Low -> Mid -> High -> DJ Filter -> Analyser -> Master Gain -> Destination
    this.lowFilter.connect(this.midFilter);
    this.midFilter.connect(this.highFilter);
    this.highFilter.connect(this.djFilter);
    this.djFilter.connect(this.analyser);
    this.analyser.connect(this.masterGain);
    this.masterGain.connect(this.ctx.destination);
  }

  public ensureContext(): AudioContext {
    if (!this.ctx) {
      this.init();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx!;
  }

  public getContext(): AudioContext | null {
    return this.ctx;
  }

  public addBeatListener(cb: (intensity: number) => void) {
    this.onBeatCallbacks.push(cb);
  }

  public removeBeatListener(cb: (intensity: number) => void) {
    this.onBeatCallbacks = this.onBeatCallbacks.filter((c) => c !== cb);
  }

  // Update EQ parameters in real-time
  public setEQ(eq: EQState) {
    if (!this.lowFilter || !this.midFilter || !this.highFilter || !this.djFilter || !this.ctx) return;
    const now = this.ctx.currentTime;
    this.lowFilter.gain.setTargetAtTime(eq.low, now, 0.05);
    this.midFilter.gain.setTargetAtTime(eq.mid, now, 0.05);
    this.highFilter.gain.setTargetAtTime(eq.high, now, 0.05);

    // DJ Filter Knob: -100 to +100
    if (eq.filter < -5) {
      // Low-pass sweep (muffles highs, keeps bass)
      this.djFilter.type = 'lowpass';
      // Map -5 to -100 into 12000Hz down to 200Hz
      const ratio = (Math.abs(eq.filter) - 5) / 95;
      const freq = 12000 * Math.pow(200 / 12000, ratio);
      this.djFilter.frequency.setTargetAtTime(Math.max(120, freq), now, 0.05);
      this.djFilter.Q.setTargetAtTime(2.5, now, 0.05);
    } else if (eq.filter > 5) {
      // High-pass sweep (cuts bass, leaves crisp sizzle)
      this.djFilter.type = 'highpass';
      // Map 5 to 100 into 100Hz up to 6000Hz
      const ratio = (eq.filter - 5) / 95;
      const freq = 100 * Math.pow(6000 / 100, ratio);
      this.djFilter.frequency.setTargetAtTime(Math.min(10000, freq), now, 0.05);
      this.djFilter.Q.setTargetAtTime(2.5, now, 0.05);
    } else {
      // Neutral
      this.djFilter.type = 'allpass';
      this.djFilter.frequency.setTargetAtTime(20000, now, 0.05);
    }
  }

  public setVolume(vol: number) {
    if (!this.masterGain || !this.ctx) return;
    this.masterGain.gain.setTargetAtTime(Math.max(0, Math.min(1, vol)), this.ctx.currentTime, 0.05);
  }

  public setPlaybackRate(rate: number) {
    this.playbackRate = rate;
    if (this.audioElement) {
      this.audioElement.playbackRate = rate;
    }
    // If sequencer is running, update step interval
    if (this.isSequencerRunning && this.currentTrack) {
      this.restartSequencer();
    }
  }

  // --- Real-time Beat & Audio Metric Updates ---
  public updateMetrics() {
    if (!this.analyser) return;
    const bufferLength = this.analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    this.analyser.getByteFrequencyData(dataArray);

    // Compute bass energy (bins 1 to 8 ~ 40Hz - 160Hz)
    let bassSum = 0;
    const bassBins = Math.min(10, bufferLength);
    for (let i = 1; i <= bassBins; i++) {
      bassSum += dataArray[i];
    }
    const currentBass = bassSum / bassBins;

    // Dynamic threshold beat detector
    if (currentBass > this.beatCutoff && currentBass > 140) {
      this.isBeat = true;
      this.beatIntensity = (currentBass - this.beatCutoff) / 100;
      this.beatCutoff = currentBass * 1.15;
      for (const cb of this.onBeatCallbacks) {
        cb(this.beatIntensity);
      }
    } else {
      this.isBeat = false;
      this.beatCutoff *= this.beatDecayRate;
      this.beatCutoff = Math.max(this.beatCutoff, 110);
    }

    // VU meter calculation (simulated stereo)
    let leftSum = 0;
    let rightSum = 0;
    const half = Math.floor(bufferLength / 2);
    for (let i = 0; i < half; i++) {
      leftSum += dataArray[i];
    }
    for (let i = half; i < bufferLength; i++) {
      rightSum += dataArray[i];
    }
    this.leftLevel = Math.min(1, (leftSum / half / 255) * 1.4);
    this.rightLevel = Math.min(1, (rightSum / (bufferLength - half) / 255) * 1.5);
  }

  // --- Music Playback: Custom Audio vs Synthesized Tracks ---
  public async playTrack(track: Track, onTimeUpdate?: (current: number) => void, onEnded?: () => void) {
    this.ensureContext();
    this.currentTrack = track;

    if (track.audioUrl) {
      // Playing real audio file or uploaded file
      this.stopSequencer();
      this.setupAudioElement(track.audioUrl, onTimeUpdate, onEnded);
      try {
        await this.audioElement?.play();
      } catch (e) {
        console.warn('Audio play auto-play policy error:', e);
      }
    } else {
      // Playing generative synth DJ track
      if (this.audioElement) {
        this.audioElement.pause();
      }
      this.startSequencer(track, onTimeUpdate, onEnded);
    }
  }

  public pause() {
    if (this.audioElement) {
      this.audioElement.pause();
    }
    this.stopSequencer();
  }

  public resume() {
    this.ensureContext();
    if (this.currentTrack?.audioUrl && this.audioElement) {
      this.audioElement.play().catch(console.error);
    } else if (this.currentTrack) {
      this.startSequencer(this.currentTrack);
    }
  }

  public seek(seconds: number) {
    if (this.audioElement) {
      this.audioElement.currentTime = seconds;
    }
  }

  private setupAudioElement(url: string, onTimeUpdate?: (current: number) => void, onEnded?: () => void) {
    if (!this.ctx || !this.lowFilter) return;

    if (!this.audioElement) {
      this.audioElement = new Audio();
      this.audioElement.crossOrigin = 'anonymous';
      this.audioSourceNode = this.ctx.createMediaElementSource(this.audioElement);
      this.audioSourceNode.connect(this.lowFilter);
    }

    this.audioElement.src = url;
    this.audioElement.playbackRate = this.playbackRate;

    if (onTimeUpdate) {
      this.audioElement.ontimeupdate = () => {
        onTimeUpdate(this.audioElement?.currentTime || 0);
      };
    }
    if (onEnded) {
      this.audioElement.onended = () => {
        onEnded();
      };
    }
  }

  // --- Live Microphone Input Mode ---
  public async enableMicrophone(): Promise<boolean> {
    const ctx = this.ensureContext();
    try {
      this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (this.lowFilter) {
        this.micSourceNode = ctx.createMediaStreamSource(this.micStream);
        this.micSourceNode.connect(this.lowFilter);
      }
      return true;
    } catch (err) {
      console.error('Microphone access denied:', err);
      return false;
    }
  }

  public disableMicrophone() {
    if (this.micSourceNode) {
      this.micSourceNode.disconnect();
      this.micSourceNode = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }
  }

  // --- Generative Synthesizer DJ Engine ---
  private startSequencer(track: Track, onTimeUpdate?: (current: number) => void, onEnded?: () => void) {
    this.stopSequencer();
    this.isSequencerRunning = true;
    this.currentStep = 0;
    const bpm = (track.bpm || 128) * this.playbackRate;
    // 16th note interval in milliseconds
    const stepMs = (60 / bpm / 4) * 1000;

    let elapsedTime = 0;
    const trackDuration = track.duration || 180;

    this.stepIntervalId = window.setInterval(() => {
      if (!this.isSequencerRunning) return;

      this.playSynthStep(this.currentStep, track.synthPreset || 'edm_anthem');
      this.currentStep = (this.currentStep + 1) % 64; // 4-bar loop

      elapsedTime += stepMs / 1000;
      if (onTimeUpdate) {
        onTimeUpdate(elapsedTime % trackDuration);
      }

      if (elapsedTime >= trackDuration && onEnded) {
        onEnded();
      }
    }, stepMs);
  }

  private restartSequencer() {
    if (!this.currentTrack) return;
    const curTrack = this.currentTrack;
    this.stopSequencer();
    this.startSequencer(curTrack);
  }

  private stopSequencer() {
    this.isSequencerRunning = false;
    if (this.stepIntervalId !== null) {
      clearInterval(this.stepIntervalId);
      this.stepIntervalId = null;
    }
  }

  // Play a single 16th note step for the generative DJ synth
  private playSynthStep(step: number, preset: string) {
    if (!this.ctx || !this.lowFilter) return;

    const barStep = step % 16;
    const now = this.ctx.currentTime;

    // 1. Kick Drum (4-on-the-floor: beats 0, 4, 8, 12)
    if (barStep === 0 || barStep === 4 || barStep === 8 || barStep === 12) {
      this.triggerKick(now);
    }

    // 2. Snare / Clap on beats 4 and 12 (or offbeat build-up)
    if (barStep === 4 || barStep === 12) {
      this.triggerSnare(now);
    }
    // Buildup roll on bar 3 (steps 48-63)
    if (step >= 56 && step % 2 === 0) {
      this.triggerSnare(now, 0.4);
    }

    // 3. Hi-Hat on offbeats (2, 6, 10, 14) and 16ths
    if (barStep === 2 || barStep === 6 || barStep === 10 || barStep === 14) {
      this.triggerHiHat(now, true); // Open Hat
    } else if (barStep % 2 === 0) {
      this.triggerHiHat(now, false); // Closed Hat
    }

    // 4. Bassline & Melodic synths depending on preset
    this.triggerBasslineAndSynth(step, preset, now);
  }

  // Synthesize Club Kick
  private triggerKick(time: number) {
    if (!this.ctx || !this.lowFilter) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(145, time);
    osc.frequency.exponentialRampToValueAtTime(38, time + 0.12);

    gain.gain.setValueAtTime(1.0, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.28);

    osc.connect(gain);
    gain.connect(this.lowFilter);

    osc.start(time);
    osc.stop(time + 0.28);
  }

  // Synthesize Crisp Snare / Clap
  private triggerSnare(time: number, vol = 0.7) {
    if (!this.ctx || !this.lowFilter) return;
    // Noise buffer
    const bufferSize = this.ctx.sampleRate * 0.18;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 1000;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.16);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.lowFilter);

    noise.start(time);
    noise.stop(time + 0.18);
  }

  // Synthesize Hi-Hat
  private triggerHiHat(time: number, open: boolean) {
    if (!this.ctx || !this.lowFilter) return;
    const duration = open ? 0.14 : 0.04;
    const bufferSize = Math.floor(this.ctx.sampleRate * duration);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.5;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 6500;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(open ? 0.45 : 0.25, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.lowFilter);

    noise.start(time);
    noise.stop(time + duration);
  }

  // Bassline and synth chord arpeggiator
  private triggerBasslineAndSynth(step: number, preset: string, time: number) {
    if (!this.ctx || !this.lowFilter) return;

    // Musical progressions based on 4 bars (each bar 16 steps)
    const bar = Math.floor(step / 16);
    const barStep = step % 16;

    // Bass notes in Hz (A minor: A1 55Hz, F1 43.6Hz, C2 65.4Hz, G1 49Hz)
    const bassRootNotes = [55.0, 43.65, 65.41, 48.99];
    const rootHz = bassRootNotes[bar % 4];

    // Offbeat rolling bassline
    if (barStep % 4 === 2 || barStep % 4 === 3 || barStep === 7 || barStep === 15) {
      const osc = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();

      osc.type = preset === 'cyberpunk' ? 'sawtooth' : 'triangle';
      osc.frequency.setValueAtTime(rootHz, time);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, time);
      filter.frequency.exponentialRampToValueAtTime(110, time + 0.15);
      filter.Q.value = 4.0;

      gain.gain.setValueAtTime(0.65, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.18);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.lowFilter);

      osc.start(time);
      osc.stop(time + 0.18);
    }

    // Melodic Synth / Arp (on 16th notes with syncopation)
    if (barStep % 2 === 0 || barStep === 7 || barStep === 11) {
      // Scale offsets in semitones: Root, Minor 3rd (+3), 5th (+7), Octave (+12), Minor 7th (+10)
      const scale = [0, 3, 7, 10, 12, 15, 12, 7];
      const noteOffset = scale[(barStep / 2) % scale.length];
      const leadBase = rootHz * 4; // 2 octaves up
      const freq = leadBase * Math.pow(2, noteOffset / 12);

      const leadOsc = this.ctx.createOscillator();
      const leadGain = this.ctx.createGain();

      leadOsc.type = preset === 'synthwave' ? 'sawtooth' : 'square';
      leadOsc.frequency.setValueAtTime(freq, time);

      leadGain.gain.setValueAtTime(0.25, time);
      leadGain.gain.exponentialRampToValueAtTime(0.001, time + 0.12);

      leadOsc.connect(leadGain);
      leadGain.connect(this.lowFilter);

      leadOsc.start(time);
      leadOsc.stop(time + 0.12);
    }
  }

  // --- Vinyl Scratch Interaction Audio Effect ---
  public triggerScratch(direction: number = 1, speed: number = 1) {
    if (!this.ctx || !this.lowFilter) return;
    const now = this.ctx.currentTime;
    const dur = 0.09 * Math.max(0.4, 1.4 - speed);

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sawtooth';
    const startFreq = direction > 0 ? 300 * speed : 900 * speed;
    const endFreq = direction > 0 ? 950 * speed : 220 * speed;

    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(60, endFreq), now + dur);

    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1200, now);
    filter.Q.value = 5.0;

    gain.gain.setValueAtTime(0.45, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.lowFilter);

    osc.start(now);
    osc.stop(now + dur);
  }

  // --- DJ Soundboard Instant SFX Generators ---
  public playSFX(type: 'airhorn' | 'laser' | 'scratch' | 'drop808' | 'siren' | 'sunny_voice' | 'rewind' | 'cheer') {
    this.ensureContext();
    const now = this.ctx!.currentTime;

    switch (type) {
      case 'airhorn': {
        // Multi-tone reggae DJ airhorn blast
        const tones = [440, 554.37, 659.25]; // A major triad
        for (let blast = 0; blast < 3; blast++) {
          const blastStart = now + blast * 0.16;
          tones.forEach((freq) => {
            const osc = this.ctx!.createOscillator();
            const gain = this.ctx!.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(freq * 1.3, blastStart);
            osc.frequency.exponentialRampToValueAtTime(freq * 1.15, blastStart + 0.13);

            gain.gain.setValueAtTime(0.3, blastStart);
            gain.gain.exponentialRampToValueAtTime(0.001, blastStart + 0.13);

            osc.connect(gain);
            gain.connect(this.lowFilter!);
            osc.start(blastStart);
            osc.stop(blastStart + 0.14);
          });
        }
        break;
      }

      case 'laser': {
        // High-energy laser zap
        for (let i = 0; i < 2; i++) {
          const startTime = now + i * 0.08;
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(2600, startTime);
          osc.frequency.exponentialRampToValueAtTime(90, startTime + 0.07);

          gain.gain.setValueAtTime(0.5, startTime);
          gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.07);

          osc.connect(gain);
          gain.connect(this.lowFilter!);
          osc.start(startTime);
          osc.stop(startTime + 0.075);
        }
        break;
      }

      case 'drop808': {
        // Earth-shaking sub 808 drop
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(135, now);
        osc.frequency.exponentialRampToValueAtTime(32, now + 1.2);

        gain.gain.setValueAtTime(1.0, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.4);

        osc.connect(gain);
        gain.connect(this.lowFilter!);
        osc.start(now);
        osc.stop(now + 1.4);
        break;
      }

      case 'scratch': {
        this.triggerScratch(1, 1.5);
        setTimeout(() => this.triggerScratch(-1, 1.2), 90);
        setTimeout(() => this.triggerScratch(1, 1.8), 180);
        break;
      }

      case 'siren': {
        // Rave alarm siren
        const osc = this.ctx!.createOscillator();
        const lfo = this.ctx!.createOscillator();
        const lfoGain = this.ctx!.createGain();
        const gain = this.ctx!.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(650, now);

        lfo.type = 'sine';
        lfo.frequency.setValueAtTime(4, now); // 4Hz sweep
        lfoGain.gain.setValueAtTime(250, now);

        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);

        gain.gain.setValueAtTime(0.4, now);
        gain.gain.linearRampToValueAtTime(0.4, now + 1.0);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.4);

        osc.connect(gain);
        gain.connect(this.lowFilter!);

        lfo.start(now);
        osc.start(now);
        lfo.stop(now + 1.4);
        osc.stop(now + 1.4);
        break;
      }

      case 'sunny_voice': {
        // Synthetic vocoder vocal announcer
        if ('speechSynthesis' in window) {
          const utter = new SpeechSynthesisUtterance('DJ SUNNY! IN THE MIX!');
          utter.rate = 1.1;
          utter.pitch = 0.8;
          window.speechSynthesis.speak(utter);
        }
        // Accompanying robot chime
        [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + idx * 0.08);
          gain.gain.setValueAtTime(0.3, now + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.3);
          osc.connect(gain);
          gain.connect(this.lowFilter!);
          osc.start(now + idx * 0.08);
          osc.stop(now + idx * 0.08 + 0.32);
        });
        break;
      }

      case 'rewind': {
        // Turntable tape stop / backspin
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(1400, now);
        osc.frequency.exponentialRampToValueAtTime(40, now + 0.6);

        gain.gain.setValueAtTime(0.6, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);

        osc.connect(gain);
        gain.connect(this.lowFilter!);
        osc.start(now);
        osc.stop(now + 0.65);
        break;
      }

      case 'cheer': {
        // Crowd applause burst
        const bufferSize = this.ctx!.sampleRate * 1.5;
        const buffer = this.ctx!.createBuffer(1, bufferSize, this.ctx!.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = (Math.random() * 2 - 1) * Math.sin((i / bufferSize) * Math.PI);
        }
        const noise = this.ctx!.createBufferSource();
        noise.buffer = buffer;
        const filter = this.ctx!.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 2200;
        filter.Q.value = 1.2;

        const gain = this.ctx!.createGain();
        gain.gain.setValueAtTime(0.4, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.5);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.lowFilter!);
        noise.start(now);
        noise.stop(now + 1.5);
        break;
      }
    }
  }
}

export const audioEngine = new AudioEngine();
