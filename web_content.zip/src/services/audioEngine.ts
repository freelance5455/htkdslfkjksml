import { Track, DSPSettings, RhythmState, DynamicFxMode, ReverbRoomSize } from '../types/audio';

export const EQ_FREQUENCIES = [31, 63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

export const DEFAULT_DSP_SETTINGS: DSPSettings = {
  eqBands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  preAmp: 0,
  bassBoost: 30,
  bassFreq: 80,
  bassDrive: 20,
  surroundReverb: 25,
  reverbRoom: 'studio',
  stereoWidth: 120,
  dynamicRhythmFx: true,
  dynamicFxMode: 'pump',
  dynamicFxIntensity: 65,
  dynamicFxDivision: '1/4',
  dynamicFxSensitivity: 0.6,
  pitchShift: 0,
  preservePitchWithSpeed: false,
  toneTilt: 0,
  reactiveVisualFx: true,
  eqPreset: 'Flat',
};

export const EQ_PRESETS: Record<string, number[]> = {
  'Flat': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  'Bass Boost': [8, 7, 5, 2, 0, 0, 0, 1, 2, 3],
  'Audiophile Hi-Fi': [3, 2, 1, 0, -1, 1, 2, 3, 4, 3],
  'Vocal Pristine': [-3, -2, 0, 2, 5, 5, 4, 2, 0, -1],
  'Electronic Club': [7, 6, 4, 0, -1, 1, 3, 5, 6, 5],
  'Rock & Guitars': [5, 4, 2, -1, -2, 1, 4, 6, 5, 4],
  'Pop Dynamic': [3, 4, 2, 1, 2, 3, 4, 5, 4, 3],
  'Jazz Warmth': [4, 3, 1, 2, 1, 0, 2, 3, 3, 2],
  'Classical Acoustic': [4, 3, 2, 1, 0, 0, 1, 3, 4, 5],
  'Night Mellow': [2, 1, 0, -1, -2, -1, 0, -2, -4, -6],
};

class AudioEngine {
  private audioEl: HTMLAudioElement;
  private ctx: AudioContext | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;

  // Nodes
  private preAmpGain: GainNode | null = null;
  private eqFilters: BiquadFilterNode[] = [];
  private bassFilter: BiquadFilterNode | null = null;
  private bassSaturation: WaveShaperNode | null = null;
  private bassWetGain: GainNode | null = null;
  private bassDryGain: GainNode | null = null;

  // Tone Tilt Filter (Grave a Agudo)
  private toneTiltLow: BiquadFilterNode | null = null;
  private toneTiltHigh: BiquadFilterNode | null = null;

  // Dynamic Rhythm FX Nodes
  private dynamicGain: GainNode | null = null;
  private dynamicFilter: BiquadFilterNode | null = null;
  private dynamicPan: StereoPannerNode | null = null;
  private dynamicSubPunch: BiquadFilterNode | null = null;

  // Surround & Reverb
  private reverbConvolver: ConvolverNode | null = null;
  private reverbWetGain: GainNode | null = null;
  private reverbDryGain: GainNode | null = null;
  private stereoWidenerGain: GainNode | null = null;

  // Master & Visualizer
  private sleepFaderGain: GainNode | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;

  // Beat & Rhythm Analysis
  private freqData: Uint8Array = new Uint8Array(256);
  private timeData: Uint8Array = new Uint8Array(256);
  private energyHistory: number[] = [];
  private lastBeatTime: number = 0;
  private beatIntervals: number[] = [];
  private currentBpm: number = 120;
  private isBeatActive: boolean = false;
  private beatDecay: number = 0;
  private animFrameId: number | null = null;

  // Settings
  private settings: DSPSettings = { ...DEFAULT_DSP_SETTINGS };

  // Sleep Timer
  private sleepTimerDuration: number | null = null; // in seconds
  private sleepTimerRemaining: number | null = null;
  private sleepTimerInterval: number | null = null;
  private onSleepTimerTick?: (remaining: number | null) => void;
  private stopAtTrackEnd: boolean = false;

  // Track status listeners
  private onTrackEndCallback?: () => void;
  private onTimeUpdateCallback?: (currentTime: number, duration: number) => void;
  private onPlayStateChangeCallback?: (isPlaying: boolean) => void;

  constructor() {
    this.audioEl = new Audio();
    this.audioEl.crossOrigin = 'anonymous';
    this.audioEl.preload = 'auto';

    this.setupAudioListeners();
  }

  private initContextIfNeeded() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx({ latencyHint: 'interactive' });
      this.buildAudioPipeline();
      this.startRhythmAnalysisLoop();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private buildAudioPipeline() {
    if (!this.ctx) return;
    const ctx = this.ctx;

    // Source
    this.sourceNode = ctx.createMediaElementSource(this.audioEl);

    // Pre-Amp
    this.preAmpGain = ctx.createGain();

    // 10-Band EQ
    this.eqFilters = EQ_FREQUENCIES.map((freq, idx) => {
      const filter = ctx.createBiquadFilter();
      if (idx === 0) {
        filter.type = 'lowshelf';
      } else if (idx === EQ_FREQUENCIES.length - 1) {
        filter.type = 'highshelf';
      } else {
        filter.type = 'peaking';
        filter.Q.value = 1.4;
      }
      filter.frequency.value = freq;
      filter.gain.value = this.settings.eqBands[idx] || 0;
      return filter;
    });

    // Tone Tilt (Grave ↔ Agudo balance)
    this.toneTiltLow = ctx.createBiquadFilter();
    this.toneTiltLow.type = 'lowshelf';
    this.toneTiltLow.frequency.value = 250;
    this.toneTiltLow.gain.value = 0;

    this.toneTiltHigh = ctx.createBiquadFilter();
    this.toneTiltHigh.type = 'highshelf';
    this.toneTiltHigh.frequency.value = 3500;
    this.toneTiltHigh.gain.value = 0;

    // Bass Boost & Saturation
    this.bassFilter = ctx.createBiquadFilter();
    this.bassFilter.type = 'lowshelf';
    this.bassFilter.frequency.value = this.settings.bassFreq;
    this.bassFilter.gain.value = (this.settings.bassBoost / 100) * 15;

    this.bassSaturation = ctx.createWaveShaper();
    this.updateBassSaturationCurve();

    this.bassDryGain = ctx.createGain();
    this.bassWetGain = ctx.createGain();
    this.bassWetGain.gain.value = (this.settings.bassDrive / 100) * 0.4;
    this.bassDryGain.gain.value = 1.0;

    // Dynamic Rhythm FX Nodes
    this.dynamicGain = ctx.createGain();
    this.dynamicGain.gain.value = 1.0;

    this.dynamicFilter = ctx.createBiquadFilter();
    this.dynamicFilter.type = 'lowpass';
    this.dynamicFilter.frequency.value = 20000;
    this.dynamicFilter.Q.value = 2.0;

    this.dynamicPan = ctx.createStereoPanner();
    this.dynamicPan.pan.value = 0;

    this.dynamicSubPunch = ctx.createBiquadFilter();
    this.dynamicSubPunch.type = 'peaking';
    this.dynamicSubPunch.frequency.value = 60;
    this.dynamicSubPunch.gain.value = 0;
    this.dynamicSubPunch.Q.value = 2.0;

    // Reverb / Surround Network
    this.reverbConvolver = ctx.createConvolver();
    this.generateImpulseResponse(this.settings.reverbRoom);

    this.reverbDryGain = ctx.createGain();
    this.reverbWetGain = ctx.createGain();
    const wetRatio = this.settings.surroundReverb / 100;
    this.reverbWetGain.gain.value = wetRatio * 0.6;
    this.reverbDryGain.gain.value = 1 - wetRatio * 0.3;

    this.stereoWidenerGain = ctx.createGain();

    // Sleep timer smooth fader
    this.sleepFaderGain = ctx.createGain();
    this.sleepFaderGain.gain.value = 1.0;

    // Master Gain & Analyser
    this.masterGain = ctx.createGain();
    this.masterGain.gain.value = 1.0;

    this.analyser = ctx.createAnalyser();
    this.analyser.fftSize = 512;
    this.analyser.smoothingTimeConstant = 0.78;
    this.freqData = new Uint8Array(this.analyser.frequencyBinCount);
    this.timeData = new Uint8Array(this.analyser.frequencyBinCount);

    // Chain connections:
    // Source -> PreAmp -> EQ filters (0..9) -> ToneTiltLow -> ToneTiltHigh -> BassFilter
    let head: AudioNode = this.sourceNode;
    head.connect(this.preAmpGain);
    head = this.preAmpGain;

    for (const filter of this.eqFilters) {
      head.connect(filter);
      head = filter;
    }

    head.connect(this.toneTiltLow);
    this.toneTiltLow.connect(this.toneTiltHigh);
    head = this.toneTiltHigh;

    head.connect(this.bassFilter);
    head = this.bassFilter;

    // Bass Saturation Blend
    head.connect(this.bassDryGain);
    head.connect(this.bassSaturation);
    this.bassSaturation.connect(this.bassWetGain);

    const bassSum = ctx.createGain();
    this.bassDryGain.connect(bassSum);
    this.bassWetGain.connect(bassSum);
    head = bassSum;

    // Dynamic Rhythm FX chain
    head.connect(this.dynamicSubPunch);
    this.dynamicSubPunch.connect(this.dynamicFilter);
    this.dynamicFilter.connect(this.dynamicGain);
    this.dynamicGain.connect(this.dynamicPan);
    head = this.dynamicPan;

    // Surround Reverb Split
    head.connect(this.reverbDryGain);
    head.connect(this.reverbConvolver);
    this.reverbConvolver.connect(this.reverbWetGain);

    const reverbSum = ctx.createGain();
    this.reverbDryGain.connect(reverbSum);
    this.reverbWetGain.connect(reverbSum);
    head = reverbSum;

    // Sleep Fader -> Master -> Analyser -> Output
    head.connect(this.sleepFaderGain);
    this.sleepFaderGain.connect(this.masterGain);
    this.masterGain.connect(this.analyser);
    this.analyser.connect(ctx.destination);
  }

  private generateImpulseResponse(room: ReverbRoomSize) {
    if (!this.ctx || !this.reverbConvolver) return;
    const ctx = this.ctx;
    const rate = ctx.sampleRate;
    let decaySec = 1.2;
    if (room === 'small') decaySec = 0.6;
    if (room === 'studio') decaySec = 1.2;
    if (room === 'hall') decaySec = 2.4;
    if (room === 'cathedral') decaySec = 4.2;

    const length = Math.floor(rate * decaySec);
    const impulse = ctx.createBuffer(2, length, rate);
    const left = impulse.getChannelData(0);
    const right = impulse.getChannelData(1);

    for (let i = 0; i < length; i++) {
      const t = i / length;
      const env = Math.exp(-3 * t);
      left[i] = (Math.random() * 2 - 1) * env;
      right[i] = (Math.random() * 2 - 1) * env;
    }
    this.reverbConvolver.buffer = impulse;
  }

  private updateBassSaturationCurve() {
    if (!this.bassSaturation) return;
    const k = 2.5;
    const n_samples = 44100;
    const curve = new Float32Array(n_samples);
    const deg = Math.PI / 180;
    for (let i = 0; i < n_samples; ++i) {
      const x = (i * 2) / n_samples - 1;
      curve[i] = ((3 + k) * x * 20 * deg) / (Math.PI + k * Math.abs(x));
    }
    this.bassSaturation.curve = curve;
  }

  // Real-time Beat Detection and Rhythm-Synced Audio Modifications
  private startRhythmAnalysisLoop() {
    const loop = () => {
      this.animFrameId = requestAnimationFrame(loop);
      if (!this.analyser || !this.ctx || this.audioEl.paused) {
        this.isBeatActive = false;
        this.beatDecay = Math.max(0, this.beatDecay - 0.05);
        return;
      }

      this.analyser.getByteFrequencyData(this.freqData as any);
      this.analyser.getByteTimeDomainData(this.timeData as any);

      // Low frequency energy (bins 1 to 8: ~30Hz to ~180Hz kick/bass range)
      let lowEnergy = 0;
      for (let i = 1; i <= 8; i++) {
        lowEnergy += this.freqData[i];
      }
      lowEnergy /= 8; // 0 to 255

      // Mid-high energy (bins 10 to 30: snare/percussion range)
      let midEnergy = 0;
      for (let i = 10; i <= 30; i++) {
        midEnergy += this.freqData[i];
      }
      midEnergy /= 21;

      const combinedEnergy = lowEnergy * 0.75 + midEnergy * 0.25;

      // Track energy history for running average
      this.energyHistory.push(combinedEnergy);
      if (this.energyHistory.length > 45) {
        this.energyHistory.shift();
      }

      const avgEnergy = this.energyHistory.reduce((a, b) => a + b, 0) / this.energyHistory.length;
      const sensitivity = this.settings.dynamicFxSensitivity;
      const threshold = avgEnergy * (1.15 + (1 - sensitivity) * 0.4);

      const now = performance.now();
      const minInterval = 60000 / 220; // Max 220 BPM limit (~270ms)

      if (combinedEnergy > threshold && combinedEnergy > 38 && now - this.lastBeatTime > minInterval) {
        // Detected Beat
        const delta = now - this.lastBeatTime;
        if (this.lastBeatTime > 0 && delta < 1500 && delta > 280) {
          const estimatedBpm = Math.round(60000 / delta);
          this.beatIntervals.push(estimatedBpm);
          if (this.beatIntervals.length > 6) this.beatIntervals.shift();
          // Median / smooth BPM
          const sorted = [...this.beatIntervals].sort((a, b) => a - b);
          this.currentBpm = sorted[Math.floor(sorted.length / 2)];
        }
        this.lastBeatTime = now;
        this.isBeatActive = true;
        this.beatDecay = 1.0;

        // Apply Beat-Synced Audio DSP Modification
        this.applyBeatAudioModification();
      } else {
        this.isBeatActive = false;
        this.beatDecay = Math.max(0, this.beatDecay - 0.08);
      }

      // Continuous modulation (tempo LFO sweeps for autofilter and autopan)
      this.applyContinuousRhythmModulation(now);
    };

    this.animFrameId = requestAnimationFrame(loop);
  }

  // Triggered on exact rhythmic downbeats / kicks
  private applyBeatAudioModification() {
    if (!this.settings.dynamicRhythmFx || !this.ctx) return;
    const intensity = this.settings.dynamicFxIntensity / 100;
    const mode = this.settings.dynamicFxMode;
    const now = this.ctx.currentTime;
    const beatSec = 60 / this.currentBpm;

    if (mode === 'pump' && this.dynamicGain) {
      // Dynamic Sidechain ducking on downbeat, smoothly releasing back up
      const duckGain = 1.0 - intensity * 0.65;
      this.dynamicGain.gain.cancelScheduledValues(now);
      this.dynamicGain.gain.setValueAtTime(this.dynamicGain.gain.value, now);
      this.dynamicGain.gain.linearRampToValueAtTime(duckGain, now + 0.02);
      this.dynamicGain.gain.exponentialRampToValueAtTime(1.0, now + beatSec * 0.7);
    } else if (mode === 'subpunch' && this.dynamicSubPunch) {
      // Transient sub-bass burst (+6dB to +12dB on kick)
      const punchGain = intensity * 10;
      this.dynamicSubPunch.gain.cancelScheduledValues(now);
      this.dynamicSubPunch.gain.setValueAtTime(punchGain, now);
      this.dynamicSubPunch.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    } else if (mode === 'reverbbreath' && this.reverbWetGain) {
      // Reverb opens up on beat drop and returns
      const targetWet = (this.settings.surroundReverb / 100) * 0.6 + intensity * 0.4;
      this.reverbWetGain.gain.cancelScheduledValues(now);
      this.reverbWetGain.gain.setValueAtTime(targetWet, now);
      this.reverbWetGain.gain.exponentialRampToValueAtTime(
        (this.settings.surroundReverb / 100) * 0.6,
        now + beatSec * 0.85
      );
    }
  }

  // Continuously modulates parameters locked to the detected tempo phase
  private applyContinuousRhythmModulation(timestampMs: number) {
    if (!this.settings.dynamicRhythmFx || !this.ctx) {
      // Reset nodes to transparent defaults
      if (this.dynamicGain && this.settings.dynamicFxMode !== 'pump') this.dynamicGain.gain.value = 1.0;
      if (this.dynamicFilter) this.dynamicFilter.frequency.value = 20000;
      if (this.dynamicPan) this.dynamicPan.pan.value = 0;
      return;
    }

    const intensity = this.settings.dynamicFxIntensity / 100;
    const mode = this.settings.dynamicFxMode;
    const bpm = this.currentBpm || 120;
    const beatSec = 60 / bpm;

    let divMultiplier = 1;
    if (this.settings.dynamicFxDivision === '1/1') divMultiplier = 4;
    else if (this.settings.dynamicFxDivision === '1/2') divMultiplier = 2;
    else if (this.settings.dynamicFxDivision === '1/4') divMultiplier = 1;
    else if (this.settings.dynamicFxDivision === '1/8') divMultiplier = 0.5;

    const cycleSec = beatSec * divMultiplier;
    const phase = ((timestampMs / 1000) % cycleSec) / cycleSec; // 0 to 1

    if (mode === 'autofilter' && this.dynamicFilter) {
      // Rhythmic filter sweep synchronized with tempo
      const sinWave = (Math.sin(phase * Math.PI * 2) + 1) / 2; // 0 to 1
      const minFreq = 400 + (1 - intensity) * 1200;
      const maxFreq = 18000;
      const currentFreq = minFreq + sinWave * (maxFreq - minFreq);
      this.dynamicFilter.frequency.setTargetAtTime(currentFreq, this.ctx.currentTime, 0.02);
    } else if (mode === 'autopan' && this.dynamicPan) {
      // 3D stereo panner swinging rhythmically left to right
      const panVal = Math.sin(phase * Math.PI * 2) * intensity * 0.85;
      this.dynamicPan.pan.setTargetAtTime(panVal, this.ctx.currentTime, 0.03);
    } else if (mode === 'gater' && this.dynamicGain) {
      // Rhythmic tempo stutter/chop
      const gateOn = phase < 0.5;
      const targetGain = gateOn ? 1.0 : 1.0 - intensity * 0.9;
      this.dynamicGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 0.015);
    }
  }

  // Setup standard HTML5 audio listeners
  private setupAudioListeners() {
    this.audioEl.addEventListener('ended', () => {
      if (this.stopAtTrackEnd) {
        this.pause();
        this.clearSleepTimer();
      }
      if (this.onTrackEndCallback) {
        this.onTrackEndCallback();
      }
    });

    this.audioEl.addEventListener('timeupdate', () => {
      if (this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(this.audioEl.currentTime, this.audioEl.duration || 0);
      }
    });

    this.audioEl.addEventListener('play', () => {
      if (this.onPlayStateChangeCallback) this.onPlayStateChangeCallback(true);
    });

    this.audioEl.addEventListener('pause', () => {
      if (this.onPlayStateChangeCallback) this.onPlayStateChangeCallback(false);
    });
  }

  // Public Playback Controls
  public async loadTrack(track: Track, autoPlay: boolean = true) {
    this.initContextIfNeeded();
    this.audioEl.src = track.url;
    this.applyPitchAndSpeed();

    // Update Media Session API
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track.title,
        artist: track.artist,
        album: track.album,
        artwork: [
          { src: track.coverUrl, sizes: '512x512', type: 'image/jpeg' },
          { src: '/icon.svg', sizes: '512x512', type: 'image/svg+xml' },
        ],
      });
    }

    if (autoPlay) {
      try {
        await this.audioEl.play();
      } catch (err) {
        console.warn('AutoPlay prevented or audio load pending user interaction:', err);
      }
    }
  }

  public async play() {
    this.initContextIfNeeded();
    await this.audioEl.play();
  }

  public pause() {
    this.audioEl.pause();
  }

  public togglePlay() {
    if (this.audioEl.paused) {
      return this.play();
    } else {
      this.pause();
    }
  }

  public seek(seconds: number) {
    if (!isNaN(seconds)) {
      this.audioEl.currentTime = Math.max(0, Math.min(seconds, this.audioEl.duration || 0));
    }
  }

  public setVolume(vol: number) {
    // 0 to 1
    const clamped = Math.max(0, Math.min(1, vol));
    this.audioEl.volume = clamped;
  }

  public getVolume(): number {
    return this.audioEl.volume;
  }

  public isPlaying(): boolean {
    return !this.audioEl.paused && !this.audioEl.ended;
  }

  public getCurrentTime(): number {
    return this.audioEl.currentTime || 0;
  }

  public getDuration(): number {
    return this.audioEl.duration || 0;
  }

  // Pitch & Tone Controls (Grave a Agudo)
  public updateToneTilt(val: number) {
    // val is -100 (Ultra Grave/Oscuro) to +100 (Ultra Agudo/Cristalino)
    this.settings.toneTilt = val;
    if (!this.toneTiltLow || !this.toneTiltHigh || !this.ctx) return;

    if (val < 0) {
      // Leaning towards Grave (Boost lows up to +8dB, attenuate highs down to -12dB)
      const ratio = Math.abs(val) / 100;
      this.toneTiltLow.gain.setTargetAtTime(ratio * 8, this.ctx.currentTime, 0.05);
      this.toneTiltHigh.gain.setTargetAtTime(-ratio * 12, this.ctx.currentTime, 0.05);
    } else {
      // Leaning towards Agudo (Cut lows down to -12dB, boost high sparkle up to +9dB)
      const ratio = val / 100;
      this.toneTiltLow.gain.setTargetAtTime(-ratio * 12, this.ctx.currentTime, 0.05);
      this.toneTiltHigh.gain.setTargetAtTime(ratio * 9, this.ctx.currentTime, 0.05);
    }
  }

  public updatePitchShift(semitones: number, preservePitch: boolean = false) {
    this.settings.pitchShift = semitones;
    this.settings.preservePitchWithSpeed = preservePitch;
    this.applyPitchAndSpeed();
  }

  private applyPitchAndSpeed() {
    // Pitch shift formula: playbackRate = 2^(semitones / 12)
    const semitones = this.settings.pitchShift;
    const rate = Math.pow(2, semitones / 12);
    // Limit to safe audio playback rate [0.3 to 3.0]
    const clampedRate = Math.max(0.35, Math.min(2.8, rate));

    // preservesPitch controls whether pitch shifts with speed (false = vinyl pitch shift from grave to agudo)
    (this.audioEl as HTMLAudioElement & { preservesPitch?: boolean; mozPreservesPitch?: boolean; webkitPreservesPitch?: boolean }).preservesPitch = this.settings.preservePitchWithSpeed;
    this.audioEl.playbackRate = clampedRate;
  }

  // DSP & Equalizer updates
  public updateDSPSettings(newSettings: Partial<DSPSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    if (!this.ctx) return;
    const ctx = this.ctx;

    // PreAmp
    if (this.preAmpGain && newSettings.preAmp !== undefined) {
      const gainVal = Math.pow(10, newSettings.preAmp / 20);
      this.preAmpGain.gain.setTargetAtTime(gainVal, ctx.currentTime, 0.05);
    }

    // 10 EQ Bands
    if (newSettings.eqBands) {
      newSettings.eqBands.forEach((gain, idx) => {
        if (this.eqFilters[idx]) {
          this.eqFilters[idx].gain.setTargetAtTime(gain, ctx.currentTime, 0.05);
        }
      });
    }

    // Bass Boost
    if (this.bassFilter) {
      if (newSettings.bassBoost !== undefined) {
        const boostGain = (this.settings.bassBoost / 100) * 15;
        this.bassFilter.gain.setTargetAtTime(boostGain, ctx.currentTime, 0.05);
      }
      if (newSettings.bassFreq !== undefined) {
        this.bassFilter.frequency.setTargetAtTime(newSettings.bassFreq, ctx.currentTime, 0.05);
      }
    }

    if (this.bassWetGain && newSettings.bassDrive !== undefined) {
      const drive = (newSettings.bassDrive / 100) * 0.45;
      this.bassWetGain.gain.setTargetAtTime(drive, ctx.currentTime, 0.05);
    }

    // Surround Reverb
    if (this.reverbWetGain && this.reverbDryGain && newSettings.surroundReverb !== undefined) {
      const wet = newSettings.surroundReverb / 100;
      this.reverbWetGain.gain.setTargetAtTime(wet * 0.6, ctx.currentTime, 0.05);
      this.reverbDryGain.gain.setTargetAtTime(1 - wet * 0.3, ctx.currentTime, 0.05);
    }

    if (newSettings.reverbRoom) {
      this.generateImpulseResponse(newSettings.reverbRoom);
    }

    if (newSettings.toneTilt !== undefined) {
      this.updateToneTilt(newSettings.toneTilt);
    }

    if (newSettings.pitchShift !== undefined || newSettings.preservePitchWithSpeed !== undefined) {
      this.applyPitchAndSpeed();
    }
  }

  public getDSPSettings(): DSPSettings {
    return { ...this.settings };
  }

  public getRhythmState(): RhythmState {
    return {
      bpm: this.currentBpm,
      isBeat: this.isBeatActive,
      beatStrength: this.beatDecay,
      instantEnergy: this.energyHistory[this.energyHistory.length - 1] || 0,
      averageEnergy: this.energyHistory.reduce((a, b) => a + b, 0) / (this.energyHistory.length || 1),
      tempoConfidence: Math.min(1.0, this.beatIntervals.length / 5),
    };
  }

  public getVisualizerData(freqArray: Uint8Array, timeArray: Uint8Array) {
    if (this.analyser) {
      this.analyser.getByteFrequencyData(freqArray as any);
      this.analyser.getByteTimeDomainData(timeArray as any);
    }
  }

  // Sleep Timer with smooth audio fader
  public setSleepTimer(minutes: number | 'end-of-track', onTick?: (remaining: number | null) => void) {
    this.clearSleepTimer();
    this.onSleepTimerTick = onTick;

    if (minutes === 'end-of-track') {
      this.stopAtTrackEnd = true;
      if (this.onSleepTimerTick) this.onSleepTimerTick(null);
      return;
    }

    this.stopAtTrackEnd = false;
    this.sleepTimerDuration = minutes * 60;
    this.sleepTimerRemaining = this.sleepTimerDuration;

    if (this.onSleepTimerTick) {
      this.onSleepTimerTick(this.sleepTimerRemaining);
    }

    this.sleepTimerInterval = window.setInterval(() => {
      if (this.sleepTimerRemaining !== null && this.sleepTimerRemaining > 0) {
        this.sleepTimerRemaining -= 1;

        // Smooth fade-out in the last 15 seconds
        if (this.sleepTimerRemaining <= 15 && this.sleepFaderGain && this.ctx) {
          const fadeRatio = Math.max(0, this.sleepTimerRemaining / 15);
          this.sleepFaderGain.gain.setTargetAtTime(fadeRatio, this.ctx.currentTime, 0.5);
        }

        if (this.onSleepTimerTick) {
          this.onSleepTimerTick(this.sleepTimerRemaining);
        }

        if (this.sleepTimerRemaining <= 0) {
          this.pause();
          this.clearSleepTimer();
        }
      }
    }, 1000);
  }

  public clearSleepTimer() {
    if (this.sleepTimerInterval) {
      clearInterval(this.sleepTimerInterval);
      this.sleepTimerInterval = null;
    }
    this.sleepTimerDuration = null;
    this.sleepTimerRemaining = null;
    this.stopAtTrackEnd = false;

    // Reset fader
    if (this.sleepFaderGain && this.ctx) {
      this.sleepFaderGain.gain.setTargetAtTime(1.0, this.ctx.currentTime, 0.2);
    }

    if (this.onSleepTimerTick) {
      this.onSleepTimerTick(null);
    }
  }

  public getSleepTimerRemaining(): number | null {
    return this.sleepTimerRemaining;
  }

  // Callbacks
  public onTrackEnd(cb: () => void) {
    this.onTrackEndCallback = cb;
  }

  public onTimeUpdate(cb: (currentTime: number, duration: number) => void) {
    this.onTimeUpdateCallback = cb;
  }

  public onPlayStateChange(cb: (isPlaying: boolean) => void) {
    this.onPlayStateChangeCallback = cb;
  }

  public destroy() {
    if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
    this.clearSleepTimer();
    this.audioEl.pause();
    this.audioEl.src = '';
    if (this.ctx) {
      this.ctx.close();
    }
  }
}

export const audioEngine = new AudioEngine();
