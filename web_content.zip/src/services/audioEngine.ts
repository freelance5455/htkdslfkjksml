import { Project, Clip } from '../types/editor';
import { audioBufferToWavBlob } from './sampleMedia';

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private activeSources: Map<string, AudioBufferSourceNode> = new Map();
  private bufferCache: Map<string, AudioBuffer> = new Map();
  private isRecordingVoice = false;
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  // Load and decode an audio URL/blob into AudioBuffer
  async loadAudio(url: string, blob?: Blob): Promise<AudioBuffer | null> {
    if (!url && !blob) return null;

    if (url && this.bufferCache.has(url)) {
      return this.bufferCache.get(url)!;
    }

    try {
      const ctx = this.getContext();
      let arrayBuf: ArrayBuffer;
      if (blob) {
        arrayBuf = await blob.arrayBuffer();
      } else if (url && url.trim() !== '') {
        const resp = await fetch(url);
        if (!resp.ok) return null;
        arrayBuf = await resp.arrayBuffer();
      } else {
        return null;
      }
      const decoded = await ctx.decodeAudioData(arrayBuf);
      if (url) {
        this.bufferCache.set(url, decoded);
      }
      return decoded;
    } catch (e) {
      console.warn('Could not decode audio:', url, e);
      return null;
    }
  }

  // Synchronize playback of audio clips at currentTime
  syncPlayback(project: Project, currentTime: number, isPlaying: boolean) {
    if (!isPlaying) {
      this.stopAll();
      return;
    }

    const audioClips = project.clips.filter(c => 
      (c.type === 'audio' || (c.type === 'video' && !c.muted && c.volume > 0)) && (c.sourceUrl || c.blob)
    );

    for (const clip of audioClips) {
      const track = project.tracks.find(t => t.id === clip.trackId);
      if (track && (track.muted || !track.visible)) continue;
      if (clip.muted || clip.volume <= 0) continue;

      const clipEnd = clip.start + clip.duration;
      if (currentTime >= clip.start && currentTime < clipEnd) {
        if (!this.activeSources.has(clip.id)) {
          this.playClipAudio(clip, currentTime);
        }
      } else {
        if (this.activeSources.has(clip.id)) {
          this.stopClipAudio(clip.id);
        }
      }
    }
  }

  private async playClipAudio(clip: Clip, currentTime: number) {
    if (!clip.sourceUrl && !clip.blob) return;

    try {
      const ctx = this.getContext();
      const buffer = await this.loadAudio(clip.sourceUrl, clip.blob);
      if (!buffer) return;

      const source = ctx.createBufferSource();
      source.buffer = buffer;

      const gain = ctx.createGain();
      const vol = isFinite(clip.volume) ? clip.volume : 1.0;
      gain.gain.value = vol;

      // Safe time offset and duration calculation
      const timeOffset = Math.max(0, (currentTime - clip.start) * (clip.speed || 1.0));
      const durationLeft = Math.max(0.05, clip.duration - (currentTime - clip.start));
      const safeOffset = Math.min(Math.max(0, buffer.duration - 0.05), clip.sourceStart + timeOffset);

      source.connect(gain);
      gain.connect(ctx.destination);

      source.start(0, safeOffset, durationLeft);
      this.activeSources.set(clip.id, source);

      source.onended = () => {
        this.activeSources.delete(clip.id);
      };
    } catch (e) {
      // Audio playback caught safely
    }
  }

  stopClipAudio(clipId: string) {
    const src = this.activeSources.get(clipId);
    if (src) {
      try {
        src.stop();
        src.disconnect();
      } catch (e) {}
      this.activeSources.delete(clipId);
    }
  }

  stopAll() {
    this.activeSources.forEach(src => {
      try {
        src.stop();
        src.disconnect();
      } catch (e) {}
    });
    this.activeSources.clear();
  }

  // --- Live Voiceover Recording ---
  async startVoiceRecording(): Promise<MediaStream> {
    this.recordedChunks = [];
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.mediaRecorder = new MediaRecorder(stream);
    this.mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) this.recordedChunks.push(e.data);
    };
    this.mediaRecorder.start();
    this.isRecordingVoice = true;
    return stream;
  }

  stopVoiceRecording(): Promise<{ blob: Blob; url: string; duration: number }> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        return reject(new Error('No active recording'));
      }

      this.mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(this.recordedChunks, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        
        let duration = 3.0;
        try {
          const ctx = this.getContext();
          const arrayBuf = await audioBlob.arrayBuffer();
          const decoded = await ctx.decodeAudioData(arrayBuf);
          duration = decoded.duration;
        } catch (e) {
          console.warn('Could not decode audio duration, using estimated', e);
        }

        this.isRecordingVoice = false;
        resolve({ blob: audioBlob, url: audioUrl, duration });
      };

      try {
        this.mediaRecorder.stop();
        this.mediaRecorder.stream.getTracks().forEach(t => t.stop());
      } catch (e) {
        reject(e);
      }
    });
  }

  // Extract Audio from Video File
  async extractAudioFromVideo(videoBlob: Blob): Promise<{ blob: Blob; url: string; duration: number }> {
    const ctx = this.getContext();
    const arrayBuf = await videoBlob.arrayBuffer();
    const audioBuffer = await ctx.decodeAudioData(arrayBuf);
    const wavBlob = audioBufferToWavBlob(audioBuffer);
    const url = URL.createObjectURL(wavBlob);
    return { blob: wavBlob, url, duration: audioBuffer.duration };
  }
}

export const audioEngine = new AudioEngine();
