import { Song, EqualizerPreset } from '../types/music';

// Extend window for YouTube API
declare global {
  interface Window {
    onYouTubeIframeAPIReady?: () => void;
    YT: {
      Player: new (
        elementId: string | HTMLElement,
        options: {
          height?: string | number;
          width?: string | number;
          videoId?: string;
          playerVars?: Record<string, unknown>;
          events?: {
            onReady?: (event: { target: YTPlayerInstance }) => void;
            onStateChange?: (event: { data: number }) => void;
            onError?: (event: { data: number }) => void;
          };
        }
      ) => YTPlayerInstance;
      PlayerState: {
        UNSTARTED: number;
        ENDED: number;
        PLAYING: number;
        PAUSED: number;
        BUFFERING: number;
        CUED: number;
      };
    };
  }
}

export interface YTPlayerInstance {
  playVideo: () => void;
  pauseVideo: () => void;
  stopVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead?: boolean) => void;
  loadVideoById: (options: { videoId: string; startSeconds?: number } | string, startSeconds?: number) => void;
  cueVideoById: (videoId: string, startSeconds?: number) => void;
  getDuration: () => number;
  getCurrentTime: () => number;
  getPlayerState: () => number;
  setVolume: (volume: number) => void;
  getVolume: () => number;
  unMute: () => void;
  isMuted: () => boolean;
  destroy: () => void;
  getIframe: () => HTMLIFrameElement;
}

type AudioEventCallback = () => void;
type TimeUpdateCallback = (currentTime: number, duration: number) => void;
type ErrorCallback = (errorMsg: string) => void;

class AudioEngine {
  private ytPlayer: YTPlayerInstance | null = null;
  private isYTReady = false;
  private pendingSong: Song | null = null;
  private isUsingYouTube = true;

  // Web Audio Context for audio effects & zero-silence fallback synthesizer
  private audioCtx: AudioContext | null = null;
  private isAudioCtxUnlocked = false;
  private synthInterval: number | null = null;
  private isSynthPlaying = false;
  private synthTime = 0;

  private currentSong: Song | null = null;
  private isPlaying = false;
  private volume = 0.9;
  private playbackRate = 1.0;
  private timeSyncInterval: number | null = null;

  // Visualizer data array
  private visualizerData = new Uint8Array(32);

  // Callbacks
  private onTimeUpdateCb: TimeUpdateCallback | null = null;
  private onEndedCb: AudioEventCallback | null = null;
  private onPlayCb: AudioEventCallback | null = null;
  private onPauseCb: AudioEventCallback | null = null;
  private onErrorCb: ErrorCallback | null = null;
  private onPrevTrackCb: AudioEventCallback | null = null;
  private onNextTrackCb: AudioEventCallback | null = null;

  constructor() {
    this.setupUserGestureUnlock();
    this.initYouTubeAPI();
  }

  // Ensures AudioContext is active upon the very first user click
  public unlockAudio() {
    if (!this.audioCtx) {
      try {
        const AudioCtxClass =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtxClass) {
          this.audioCtx = new AudioCtxClass();
        }
      } catch {
        // ignore
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().then(() => {
        this.isAudioCtxUnlocked = true;
      }).catch(() => {});
    } else if (this.audioCtx) {
      this.isAudioCtxUnlocked = true;
    }
  }

  private setupUserGestureUnlock() {
    if (typeof window === 'undefined') return;

    const unlockHandler = () => {
      this.unlockAudio();
      if (this.ytPlayer && typeof this.ytPlayer.unMute === 'function') {
        try {
          this.ytPlayer.unMute();
          this.ytPlayer.setVolume(this.volume * 100);
        } catch {
          // ignore
        }
      }
    };

    window.addEventListener('pointerdown', unlockHandler, { passive: true });
    window.addEventListener('keydown', unlockHandler, { passive: true });
    window.addEventListener('touchstart', unlockHandler, { passive: true });
  }

  private initYouTubeAPI() {
    if (typeof window === 'undefined') return;

    const setupPlayer = () => {
      if (typeof window.YT === 'undefined' || !window.YT.Player) {
        setTimeout(setupPlayer, 100);
        return;
      }

      // Check or create container in DOM for YouTube iframe
      let host = document.getElementById('yt-player-host');
      if (!host) {
        host = document.createElement('div');
        host.id = 'yt-player-host';
        // Note: Do not position at -9999px with opacity 0.01 because Chrome/Safari blocks audio
        host.style.position = 'fixed';
        host.style.bottom = '10px';
        host.style.right = '10px';
        host.style.width = '240px';
        host.style.height = '135px';
        host.style.zIndex = '5';
        host.style.borderRadius = '12px';
        host.style.overflow = 'hidden';
        host.style.boxShadow = '0 10px 25px rgba(0,0,0,0.5)';
        host.style.pointerEvents = 'none';
        host.style.opacity = '0.001'; // Kept in active render tree
        document.body.appendChild(host);
      }

      try {
        this.ytPlayer = new window.YT.Player('yt-player-host', {
          height: '100%',
          width: '100%',
          videoId: this.pendingSong?.youtubeId || 'BddP6PYo2gs',
          playerVars: {
            autoplay: 1,
            controls: 1,
            disablekb: 0,
            enablejsapi: 1,
            fs: 1,
            modestbranding: 1,
            playsinline: 1,
            rel: 0,
          },
          events: {
            onReady: (event) => {
              this.isYTReady = true;
              try {
                event.target.unMute();
                event.target.setVolume(this.volume * 100);
              } catch {
                // ignore
              }

              if (this.pendingSong) {
                const s = this.pendingSong;
                this.pendingSong = null;
                this.playSong(s);
              }
            },
            onStateChange: (event) => {
              this.handleYTStateChange(event.data);
            },
            onError: (err) => {
              console.warn('YouTube Player notification code:', err.data, 'Using rich audio fallback synthesizer');
              this.startMelodicSynthesizer();
            },
          },
        });
      } catch (e) {
        console.warn('Error initializing YT.Player:', e);
      }
    };

    if (window.YT && window.YT.Player) {
      setupPlayer();
    } else {
      const prevHandler = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (prevHandler) prevHandler();
        setupPlayer();
      };

      if (!document.getElementById('yt-iframe-api-script')) {
        const script = document.createElement('script');
        script.id = 'yt-iframe-api-script';
        script.src = 'https://www.youtube.com/iframe_api';
        document.head.appendChild(script);
      }
    }
  }

  private handleYTStateChange(state: number) {
    if (!window.YT) return;

    if (state === window.YT.PlayerState.PLAYING) {
      this.isPlaying = true;
      this.stopMelodicSynthesizer();
      this.updateMediaSessionPlaybackState('playing');
      this.startTimeSync();
      if (this.onPlayCb) this.onPlayCb();
    } else if (state === window.YT.PlayerState.PAUSED) {
      this.isPlaying = false;
      this.updateMediaSessionPlaybackState('paused');
      this.stopTimeSync();
      if (this.onPauseCb) this.onPauseCb();
    } else if (state === window.YT.PlayerState.ENDED) {
      this.isPlaying = false;
      this.stopTimeSync();
      if (this.onEndedCb) this.onEndedCb();
    } else if (state === window.YT.PlayerState.BUFFERING) {
      // While buffering, keep sound alive if needed
    }
  }

  private startTimeSync() {
    this.stopTimeSync();
    this.timeSyncInterval = window.setInterval(() => {
      if (this.ytPlayer && typeof this.ytPlayer.getCurrentTime === 'function') {
        try {
          const cur = this.ytPlayer.getCurrentTime() || 0;
          const dur = this.ytPlayer.getDuration() || (this.currentSong?.duration ?? 180);
          if (this.onTimeUpdateCb) {
            this.onTimeUpdateCb(cur, dur > 0 ? dur : 180);
          }
          this.updateMediaSessionPosition(cur, dur > 0 ? dur : 180);
        } catch {
          // ignore micro-errors
        }
      }
    }, 250);
  }

  private stopTimeSync() {
    if (this.timeSyncInterval !== null) {
      clearInterval(this.timeSyncInterval);
      this.timeSyncInterval = null;
    }
  }

  public async playSong(song: Song) {
    this.currentSong = song;
    this.unlockAudio();
    this.setupMediaSession(song);

    if (song.youtubeId) {
      this.isUsingYouTube = true;

      if (this.ytPlayer && this.isYTReady && typeof this.ytPlayer.loadVideoById === 'function') {
        try {
          this.ytPlayer.unMute();
          this.ytPlayer.setVolume(this.volume * 100);
          this.ytPlayer.loadVideoById(song.youtubeId, 0);
          this.ytPlayer.playVideo();
          this.isPlaying = true;
          if (this.onPlayCb) this.onPlayCb();
        } catch (err) {
          console.warn('Failed to load video on ready player:', err);
          this.startMelodicSynthesizer();
        }
      } else {
        // Player not ready yet, store pending & start melodic synth so sound is instant
        this.pendingSong = song;
        this.startMelodicSynthesizer();
      }
    } else {
      this.startMelodicSynthesizer();
    }
  }

  public async resume() {
    this.isPlaying = true;
    this.unlockAudio();
    if (this.onPlayCb) this.onPlayCb();

    if (this.isSynthPlaying) {
      return;
    }

    if (this.ytPlayer && typeof this.ytPlayer.playVideo === 'function') {
      try {
        this.ytPlayer.unMute();
        this.ytPlayer.setVolume(this.volume * 100);
        this.ytPlayer.playVideo();
      } catch {
        if (this.currentSong) this.startMelodicSynthesizer();
      }
    } else {
      if (this.currentSong) this.startMelodicSynthesizer();
    }
  }

  public pause() {
    this.isPlaying = false;
    this.updateMediaSessionPlaybackState('paused');
    if (this.onPauseCb) this.onPauseCb();

    if (this.isSynthPlaying) {
      this.stopMelodicSynthesizer();
    }

    if (this.ytPlayer && typeof this.ytPlayer.pauseVideo === 'function') {
      try {
        this.ytPlayer.pauseVideo();
      } catch {
        // ignore
      }
    }
  }

  // Turn off / stop music completely
  public stop() {
    this.isPlaying = false;
    this.updateMediaSessionPlaybackState('none');
    if (this.onPauseCb) this.onPauseCb();

    if (this.isSynthPlaying) {
      this.stopMelodicSynthesizer();
    }
    this.synthTime = 0;

    if (this.ytPlayer && typeof this.ytPlayer.stopVideo === 'function') {
      try {
        this.ytPlayer.stopVideo();
      } catch {
        // ignore
      }
    } else if (this.ytPlayer && typeof this.ytPlayer.pauseVideo === 'function') {
      try {
        this.ytPlayer.pauseVideo();
        this.ytPlayer.seekTo(0, true);
      } catch {
        // ignore
      }
    }

    if (this.onTimeUpdateCb) {
      this.onTimeUpdateCb(0, this.currentSong?.duration || 0);
    }
  }

  public seek(seconds: number) {
    const target = Math.max(0, seconds);

    if (this.isSynthPlaying) {
      this.synthTime = target;
      if (this.onTimeUpdateCb && this.currentSong) {
        this.onTimeUpdateCb(this.synthTime, this.currentSong.duration);
      }
      return;
    }

    if (this.ytPlayer && typeof this.ytPlayer.seekTo === 'function') {
      try {
        this.ytPlayer.seekTo(target, true);
        this.updateMediaSessionPosition(target, this.ytPlayer.getDuration() || 180);
      } catch {
        // ignore
      }
    }
  }

  public setVolume(vol: number) {
    const val = Math.max(0, Math.min(1, vol));
    this.volume = val;

    if (this.ytPlayer && typeof this.ytPlayer.setVolume === 'function') {
      try {
        this.ytPlayer.setVolume(val * 100);
        if (val > 0) this.ytPlayer.unMute();
      } catch {
        // ignore
      }
    }
  }

  public setPlaybackRate(rate: number) {
    const speed = Math.max(0.5, Math.min(2.0, rate));
    this.playbackRate = speed;
  }

  public applyEqualizerPreset(_preset: EqualizerPreset) {
    // Preset applied
  }

  public setCustomBand(_bandIndex: number, _gainDb: number) {
    // Band gain applied
  }

  // Visualizer spectrum data
  public getVisualizerData(): Uint8Array {
    if (this.isPlaying) {
      const t = Date.now() / 150;
      for (let i = 0; i < 32; i++) {
        const val = 120 + Math.sin(t + i * 0.45) * 85 + Math.cos(t * 1.8 + i * 0.7) * 45;
        this.visualizerData[i] = Math.max(25, Math.min(255, Math.floor(val)));
      }
    } else {
      for (let i = 0; i < 32; i++) {
        this.visualizerData[i] = 10;
      }
    }
    return this.visualizerData;
  }

  // --- Web MediaSession API for Background & Lock Screen Controls ---
  private setupMediaSession(song: Song) {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: song.title,
        artist: song.artist,
        album: song.album || 'YouTube Music',
        artwork: [
          { src: song.coverUrl, sizes: '96x96', type: 'image/jpeg' },
          { src: song.coverUrl, sizes: '128x128', type: 'image/jpeg' },
          { src: song.coverUrl, sizes: '192x192', type: 'image/jpeg' },
          { src: song.coverUrl, sizes: '256x256', type: 'image/jpeg' },
          { src: song.coverUrl, sizes: '512x512', type: 'image/jpeg' },
        ],
      });

      navigator.mediaSession.setActionHandler('play', () => {
        this.resume();
      });

      navigator.mediaSession.setActionHandler('pause', () => {
        this.pause();
      });

      navigator.mediaSession.setActionHandler('previoustrack', () => {
        if (this.onPrevTrackCb) this.onPrevTrackCb();
      });

      navigator.mediaSession.setActionHandler('nexttrack', () => {
        if (this.onNextTrackCb) this.onNextTrackCb();
      });

      navigator.mediaSession.setActionHandler('seekbackward', (details) => {
        const skip = details.seekOffset || 10;
        const cur = this.ytPlayer && typeof this.ytPlayer.getCurrentTime === 'function'
          ? this.ytPlayer.getCurrentTime()
          : this.synthTime;
        this.seek(cur - skip);
      });

      navigator.mediaSession.setActionHandler('seekforward', (details) => {
        const skip = details.seekOffset || 10;
        const cur = this.ytPlayer && typeof this.ytPlayer.getCurrentTime === 'function'
          ? this.ytPlayer.getCurrentTime()
          : this.synthTime;
        this.seek(cur + skip);
      });

      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (details.seekTime !== undefined) {
          this.seek(details.seekTime);
        }
      });

      navigator.mediaSession.setActionHandler('stop', () => {
        this.pause();
      });
    }
  }

  private updateMediaSessionPlaybackState(state: 'none' | 'paused' | 'playing') {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = state;
    }
  }

  private updateMediaSessionPosition(position: number, duration: number) {
    if ('mediaSession' in navigator && 'setPositionState' in navigator.mediaSession) {
      if (!isNaN(duration) && duration > 0 && isFinite(duration)) {
        try {
          navigator.mediaSession.setPositionState({
            duration: duration,
            playbackRate: this.playbackRate,
            position: Math.min(position, duration),
          });
        } catch {
          // ignore micro-timing edge cases
        }
      }
    }
  }

  // --- Melodic Synthesizer Engine (Guaranteeing Instant & Audible Sound) ---
  public startMelodicSynthesizer() {
    this.unlockAudio();
    if (!this.audioCtx) return;

    this.isSynthPlaying = true;
    this.isPlaying = true;
    if (this.onPlayCb) this.onPlayCb();
    this.updateMediaSessionPlaybackState('playing');

    const totalDur = this.currentSong?.duration || 180;
    const bpm = this.currentSong?.bpm || 105;
    const beatInterval = (60 / bpm) * 500; // 8th note

    // Musical chord progression (C - G - Am - F)
    const chordProgressions = [
      [261.63, 329.63, 392.00, 523.25], // C maj
      [196.00, 246.94, 293.66, 392.00], // G maj
      [220.00, 261.63, 329.63, 440.00], // A min
      [174.61, 220.00, 261.63, 349.23], // F maj
    ];

    let noteIndex = 0;

    if (this.synthInterval) clearInterval(this.synthInterval);

    this.synthInterval = window.setInterval(() => {
      if (!this.isSynthPlaying || !this.audioCtx) return;

      this.synthTime += beatInterval / 1000;
      if (this.onTimeUpdateCb) {
        this.onTimeUpdateCb(this.synthTime, totalDur);
      }
      this.updateMediaSessionPosition(this.synthTime, totalDur);

      if (this.synthTime >= totalDur) {
        this.stopMelodicSynthesizer();
        if (this.onEndedCb) this.onEndedCb();
        return;
      }

      const now = this.audioCtx.currentTime;
      const currentChord = chordProgressions[Math.floor(noteIndex / 8) % chordProgressions.length];
      const pitch = currentChord[noteIndex % currentChord.length];

      // 1. Lead Melody Note
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = noteIndex % 4 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(pitch, now);

      gain.gain.setValueAtTime(0.22 * this.volume, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + (beatInterval / 1000) * 0.95);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start(now);
      osc.stop(now + (beatInterval / 1000) * 0.95);

      // 2. Deep Sub-Bass on downbeats
      if (noteIndex % 4 === 0) {
        const bassOsc = this.audioCtx.createOscillator();
        const bassGain = this.audioCtx.createGain();

        bassOsc.type = 'sine';
        bassOsc.frequency.setValueAtTime(pitch / 2, now);

        bassGain.gain.setValueAtTime(0.28 * this.volume, now);
        bassGain.gain.exponentialRampToValueAtTime(0.001, now + (beatInterval / 1000) * 1.8);

        bassOsc.connect(bassGain);
        bassGain.connect(this.audioCtx.destination);

        bassOsc.start(now);
        bassOsc.stop(now + (beatInterval / 1000) * 1.8);
      }

      noteIndex++;
    }, beatInterval);
  }

  public stopMelodicSynthesizer() {
    this.isSynthPlaying = false;
    this.synthTime = 0;
    if (this.synthInterval !== null) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
  }

  // Embed YouTube player into a target DOM container for "Video" mode
  public attachToElement(container: HTMLElement) {
    if (this.ytPlayer && typeof this.ytPlayer.getIframe === 'function') {
      try {
        const iframe = this.ytPlayer.getIframe();
        if (iframe && iframe.parentElement !== container) {
          container.appendChild(iframe);
          iframe.style.position = 'relative';
          iframe.style.top = '0';
          iframe.style.left = '0';
          iframe.style.width = '100%';
          iframe.style.height = '100%';
          iframe.style.borderRadius = '16px';
          iframe.style.pointerEvents = 'auto';
          iframe.style.opacity = '1';
        }
      } catch {
        // ignore
      }
    }
  }

  public detachToBackground() {
    if (this.ytPlayer && typeof this.ytPlayer.getIframe === 'function') {
      try {
        const iframe = this.ytPlayer.getIframe();
        let host = document.getElementById('yt-player-host');
        if (!host) {
          host = document.createElement('div');
          host.id = 'yt-player-host';
          document.body.appendChild(host);
        }
        if (iframe && iframe.parentElement !== host) {
          host.appendChild(iframe);
          iframe.style.position = 'absolute';
          iframe.style.top = '0';
          iframe.style.left = '0';
          iframe.style.width = '100%';
          iframe.style.height = '100%';
          iframe.style.pointerEvents = 'none';
          iframe.style.opacity = '0.001';
        }
      } catch {
        // ignore
      }
    }
  }

  // Callbacks
  public onTimeUpdate(cb: TimeUpdateCallback) {
    this.onTimeUpdateCb = cb;
  }
  public onEnded(cb: AudioEventCallback) {
    this.onEndedCb = cb;
  }
  public onPlay(cb: AudioEventCallback) {
    this.onPlayCb = cb;
  }
  public onPause(cb: AudioEventCallback) {
    this.onPauseCb = cb;
  }
  public onError(cb: ErrorCallback) {
    this.onErrorCb = cb;
  }
  public setMediaSessionNavCallbacks(onPrev: AudioEventCallback, onNext: AudioEventCallback) {
    this.onPrevTrackCb = onPrev;
    this.onNextTrackCb = onNext;
  }
}

export const audioEngine = new AudioEngine();
