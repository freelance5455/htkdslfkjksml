/**
 * Web Audio API procedural synthesis engine for Amazing Sect Cultivation
 * Multi-layered Xianxia orchestration featuring:
 *  - Expressive Pentatonic Guzheng lead + cascading waterfall glissando flourishes
 *  - Warm Bass Guqin accompaniment roots
 *  - Ethereal Xiao / Dizi Bamboo Flute counterpoint with natural breath & vibrato LFO
 *  - Atmospheric Daoist Mountain Drone Pad
 *  - Soft Celestial Bronze Chimes & Epic Taiko War-Drum swells (in Epic mode)
 *  - Crisp interactive SFX (Gong, Sword Clash, Thunder, Talisman, Alchemy, Lantern, Divination, Check-In)
 */

export type BgmThemeMode = 'epic' | 'serene' | 'bambooMist' | 'celestialCourt' | 'starlightAscent';

export const BGM_THEME_LABELS: Record<BgmThemeMode, { label: string; short: string; desc: string }> = {
  epic: { label: 'Epic Summit', short: 'Epic', desc: 'Heroic Guzheng & Taiko war-pulse' },
  serene: { label: 'Serene Lotus', short: 'Serene', desc: 'Quiet D-pentatonic flute meditation' },
  bambooMist: { label: 'Bamboo Mist', short: 'Mist', desc: 'Raindrop silk harp & A-minor forest flute' },
  celestialCourt: { label: 'Celestial Court', short: 'Court', desc: 'Warm G-pentatonic palace chimes & guqin' },
  starlightAscent: { label: 'Starlight Ascent', short: 'Starlight', desc: 'Dreamy E-pentatonic jade bells & air pads' }
};

class CultivationAudioEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private sfxEnabled: boolean = true;
  private bgmPlaying: boolean = false;
  private bgmTheme: BgmThemeMode = 'epic';
  private bgmTimeout: ReturnType<typeof setTimeout> | null = null;
  private subTimeouts: Set<ReturnType<typeof setTimeout>> = new Set();
  private droneOscs: OscillatorNode[] = [];
  private droneGain: GainNode | null = null;
  private masterMusicGain: GainNode | null = null;
  private volume: number = 0.5;

  constructor() {
    // Lazy AudioContext initialization on first user interaction
  }

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    if (this.ctx && !this.masterMusicGain) {
      this.masterMusicGain = this.ctx.createGain();
      this.masterMusicGain.gain.setValueAtTime(1.0, this.ctx.currentTime);
      this.masterMusicGain.connect(this.ctx.destination);
    }
  }

  private scheduleSubTimeout(fn: () => void, delayMs: number) {
    const id = setTimeout(() => {
      this.subTimeouts.delete(id);
      fn();
    }, delayMs);
    this.subTimeouts.add(id);
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted && this.bgmPlaying) {
      this.stopBGM();
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public setSfxEnabled(enabled: boolean) {
    this.sfxEnabled = enabled;
  }

  public getSfxEnabled(): boolean {
    return this.sfxEnabled;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.droneGain && this.ctx) {
      this.droneGain.gain.setTargetAtTime(0.028 * this.volume, this.ctx.currentTime, 0.08);
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public getBGMTheme(): BgmThemeMode {
    return this.bgmTheme;
  }

  public setBGMTheme(theme: BgmThemeMode) {
    this.bgmTheme = theme;
    if (this.bgmPlaying) {
      this.stopBGM();
      this.startBGM(theme);
    }
  }

  public cycleBGMTheme(): BgmThemeMode {
    const order: BgmThemeMode[] = ['epic', 'serene', 'bambooMist', 'celestialCourt', 'starlightAscent'];
    const idx = order.indexOf(this.bgmTheme);
    const next = order[(idx + 1) % order.length];
    this.setBGMTheme(next);
    return next;
  }

  /**
   * Procedural Guzheng Pluck Synthesis:
   * Dual-oscillator silk-string voice with resonant wooden soundbox lowpass filter.
   */
  public playGuzhengNote(freq: number, duration: number = 1.8, velocity: number = 0.08) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const targetGain = velocity * this.volume;
      const dest = this.masterMusicGain || this.ctx.destination;

      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const osc3 = this.ctx.createOscillator();
      const gain1 = this.ctx.createGain();
      const gain2 = this.ctx.createGain();
      const gain3 = this.ctx.createGain();

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.Q.setValueAtTime(2.2, now);
      filter.frequency.setValueAtTime(Math.min(7000, freq * 4.5), now);
      filter.frequency.exponentialRampToValueAtTime(Math.max(180, freq * 1.15), now + duration * 0.75);

      osc1.type = 'triangle';
      osc2.type = 'sine';
      osc3.type = 'sawtooth';

      osc1.frequency.setValueAtTime(freq, now);
      osc2.frequency.setValueAtTime(freq * 2.004, now);
      osc3.frequency.setValueAtTime(freq * 3.0, now);

      gain1.gain.setValueAtTime(0.0001, now);
      gain1.gain.linearRampToValueAtTime(targetGain, now + 0.006);
      gain1.gain.exponentialRampToValueAtTime(targetGain * 0.38, now + 0.28);
      gain1.gain.exponentialRampToValueAtTime(0.00001, now + duration);

      gain2.gain.setValueAtTime(0.0001, now);
      gain2.gain.linearRampToValueAtTime(targetGain * 0.35, now + 0.006);
      gain2.gain.exponentialRampToValueAtTime(0.00001, now + duration * 0.55);

      gain3.gain.setValueAtTime(0.0001, now);
      gain3.gain.linearRampToValueAtTime(targetGain * 0.12, now + 0.005);
      gain3.gain.exponentialRampToValueAtTime(0.00001, now + 0.22);

      osc1.connect(gain1);
      osc2.connect(gain2);
      osc3.connect(gain3);

      gain1.connect(filter);
      gain2.connect(filter);
      gain3.connect(filter);
      filter.connect(dest);

      osc1.start(now);
      osc2.start(now);
      osc3.start(now);
      osc1.stop(now + duration + 0.06);
      osc2.stop(now + duration + 0.06);
      osc3.stop(now + 0.28);
    } catch (e) {}
  }

  /**
   * Ethereal Xiao / Dizi Bamboo Flute Voice:
   * Gentle breathy attack with natural LFO vibrato and warm swell.
   */
  public playXiaoFlute(freq: number, duration: number = 2.4, velocity: number = 0.055) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const dest = this.masterMusicGain || this.ctx.destination;
      const targetGain = velocity * this.volume;

      const mainOsc = this.ctx.createOscillator();
      const overtoneOsc = this.ctx.createOscillator();
      const vibLfo = this.ctx.createOscillator();
      const vibGain = this.ctx.createGain();

      mainOsc.type = 'sine';
      overtoneOsc.type = 'triangle';
      mainOsc.frequency.setValueAtTime(freq * 0.985, now);
      mainOsc.frequency.exponentialRampToValueAtTime(freq, now + 0.16);
      overtoneOsc.frequency.setValueAtTime(freq * 2, now);

      // Gentle vibrato starting after initial breath attack
      vibLfo.type = 'sine';
      vibLfo.frequency.setValueAtTime(4.8, now);
      vibGain.gain.setValueAtTime(0.0, now);
      vibGain.gain.linearRampToValueAtTime(freq * 0.008, now + duration * 0.45);
      vibGain.gain.linearRampToValueAtTime(freq * 0.003, now + duration);

      vibLfo.connect(vibGain);
      vibGain.connect(mainOsc.frequency);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(freq * 2.8, now);

      const env = this.ctx.createGain();
      env.gain.setValueAtTime(0.0001, now);
      env.gain.linearRampToValueAtTime(targetGain, now + duration * 0.25);
      env.gain.setValueAtTime(targetGain * 0.85, now + duration * 0.65);
      env.gain.exponentialRampToValueAtTime(0.00001, now + duration);

      const overtoneGain = this.ctx.createGain();
      overtoneGain.gain.setValueAtTime(0.18, now);

      mainOsc.connect(filter);
      overtoneOsc.connect(overtoneGain);
      overtoneGain.connect(filter);
      filter.connect(env);
      env.connect(dest);

      mainOsc.start(now);
      overtoneOsc.start(now);
      vibLfo.start(now);

      mainOsc.stop(now + duration + 0.06);
      overtoneOsc.stop(now + duration + 0.06);
      vibLfo.stop(now + duration + 0.06);
    } catch (e) {}
  }

  /**
   * Deep Bass Guqin Anchor Note
   */
  public playBassGuqin(freq: number, duration: number = 3.0, velocity: number = 0.09) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const dest = this.masterMusicGain || this.ctx.destination;
      const osc = this.ctx.createOscillator();
      const subOsc = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      subOsc.type = 'sine';
      osc.frequency.setValueAtTime(freq * 1.015, now);
      osc.frequency.exponentialRampToValueAtTime(freq, now + 0.12);
      subOsc.frequency.setValueAtTime(freq * 0.5, now);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(freq * 3.2, now);
      filter.frequency.exponentialRampToValueAtTime(freq * 1.3, now + duration * 0.7);

      const target = velocity * this.volume;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(target, now + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.00001, now + duration);

      osc.connect(filter);
      subOsc.connect(filter);
      filter.connect(gain);
      gain.connect(dest);

      osc.start(now);
      subOsc.start(now);
      osc.stop(now + duration + 0.06);
      subOsc.stop(now + duration + 0.06);
    } catch (e) {}
  }

  /**
   * Soft Epic War-Drum / Taiko Swell
   */
  public playTaikoPulse(velocity: number = 0.11) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const dest = this.masterMusicGain || this.ctx.destination;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(92, now);
      osc.frequency.exponentialRampToValueAtTime(38, now + 0.35);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(velocity * this.volume, now + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.00001, now + 0.75);

      osc.connect(gain);
      gain.connect(dest);

      osc.start(now);
      osc.stop(now + 0.8);
    } catch (e) {}
  }

  /**
   * Warm Silk Harp / Konghou Pad Pluck — extra soft attack & lowpass warmth for non-fatiguing listening
   */
  public playSilkHarp(freq: number, duration: number = 2.8, velocity: number = 0.05) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const dest = this.masterMusicGain || this.ctx.destination;
      const osc = this.ctx.createOscillator();
      const harm = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      harm.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);
      harm.frequency.setValueAtTime(freq * 2, now);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(freq * 2.4, now);
      filter.frequency.exponentialRampToValueAtTime(Math.max(200, freq * 0.9), now + duration * 0.8);

      const harmGain = this.ctx.createGain();
      harmGain.gain.setValueAtTime(0.18, now);

      const target = velocity * this.volume;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(target, now + 0.035);
      gain.gain.exponentialRampToValueAtTime(target * 0.4, now + duration * 0.35);
      gain.gain.exponentialRampToValueAtTime(0.00001, now + duration);

      osc.connect(filter);
      harm.connect(harmGain);
      harmGain.connect(filter);
      filter.connect(gain);
      gain.connect(dest);

      osc.start(now);
      harm.start(now);
      osc.stop(now + duration + 0.06);
      harm.stop(now + duration + 0.06);
    } catch (e) {}
  }

  /**
   * Start warm Daoist mountain pad drone (tuned to active track root)
   */
  private startDronePad(rootFreq: number = 73.42) {
    if (!this.ctx || this.droneOscs.length > 0) return;
    try {
      const now = this.ctx.currentTime;
      const dest = this.masterMusicGain || this.ctx.destination;

      this.droneGain = this.ctx.createGain();
      this.droneGain.gain.setValueAtTime(0.0001, now);
      this.droneGain.gain.linearRampToValueAtTime(0.022 * this.volume, now + 2.2);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(240, now);

      const freqs = [rootFreq, rootFreq * 1.5, rootFreq * 2];
      freqs.forEach((f, i) => {
        const osc = this.ctx!.createOscillator();
        osc.type = i === 1 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(f, now);

        const g = this.ctx!.createGain();
        g.gain.setValueAtTime(i === 0 ? 0.5 : i === 1 ? 0.28 : 0.18, now);
        osc.connect(g);
        g.connect(filter);
        osc.start(now);
        this.droneOscs.push(osc);
      });

      filter.connect(this.droneGain);
      this.droneGain.connect(dest);
    } catch (e) {}
  }

  private stopDronePad() {
    this.droneOscs.forEach(osc => {
      try {
        osc.stop();
        osc.disconnect();
      } catch (e) {}
    });
    this.droneOscs = [];
    if (this.droneGain) {
      try {
        this.droneGain.disconnect();
      } catch (e) {}
      this.droneGain = null;
    }
  }

  public playTone(freq: number, type: OscillatorType = 'sine', duration: number = 0.3, gainLevel: number = 0.1) {
    if (this.isMuted || !this.sfxEnabled) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, now);

      const targetGain = gainLevel * this.volume;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(targetGain, now + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.00001, now + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + duration + 0.05);
    } catch (e) {}
  }

  public playClick() {
    if (!this.sfxEnabled) return;
    this.playTone(587.33, 'triangle', 0.08, 0.06); // D5 crisp click
  }

  public playTalisman() {
    if (!this.sfxEnabled) return;
    this.playGuzhengNote(659.25, 0.6, 0.07); // E5
    setTimeout(() => this.playGuzhengNote(880.0, 0.8, 0.06), 70); // A5
  }

  public playLanternLit() {
    if (!this.sfxEnabled) return;
    this.playGuzhengNote(440.0, 1.1, 0.07);
    setTimeout(() => this.playGuzhengNote(587.33, 1.3, 0.07), 90);
    setTimeout(() => this.playXiaoFlute(880.0, 1.5, 0.045), 160);
  }

  public playDivinationShake() {
    if (!this.sfxEnabled) return;
    // Wooden kau-cim rattle cadence followed by mystical chime
    this.playTone(290, 'triangle', 0.05, 0.07);
    setTimeout(() => this.playTone(340, 'triangle', 0.05, 0.06), 90);
    setTimeout(() => this.playTone(310, 'triangle', 0.05, 0.07), 180);
    setTimeout(() => this.playGuzhengNote(739.99, 1.2, 0.08), 300);
  }

  public playCheckInReward() {
    if (!this.sfxEnabled) return;
    const notes = [440, 587.33, 739.99, 880];
    notes.forEach((n, idx) => {
      setTimeout(() => this.playGuzhengNote(n, 0.9, 0.09), idx * 80);
    });
  }

  public playSwordSlash() {
    if (this.isMuted || !this.sfxEnabled) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(950, now);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.2);

      gain.gain.setValueAtTime(0.12 * this.volume, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.22);
    } catch (e) {}
  }

  public playThunder() {
    if (this.isMuted || !this.sfxEnabled) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const bufferSize = Math.floor(this.ctx.sampleRate * 1.1);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(900, now);
      filter.frequency.exponentialRampToValueAtTime(50, now + 0.95);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.3 * this.volume, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.05);

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      whiteNoise.start(now);
      whiteNoise.stop(now + 1.1);
    } catch (e) {}
  }

  public playGong() {
    if (this.isMuted || !this.sfxEnabled) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const freqs = [196, 392, 587.33, 784, 1174.66];
      freqs.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);

        const duration = 2.4 - idx * 0.3;
        gain.gain.setValueAtTime(0.18 * this.volume * (1 / (idx + 1)), now);
        gain.gain.exponentialRampToValueAtTime(0.00001, now + duration);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(now);
        osc.stop(now + duration + 0.05);
      });
    } catch (e) {}
  }

  public playCauldronBubble() {
    if (!this.sfxEnabled) return;
    this.playTone(329.63, 'sine', 0.12, 0.08);
    setTimeout(() => this.playTone(392.00, 'sine', 0.12, 0.08), 85);
    setTimeout(() => this.playTone(440.00, 'sine', 0.16, 0.08), 170);
  }

  public playFanfare() {
    if (!this.sfxEnabled) return;
    const notes = [293.66, 369.99, 440.00, 587.33, 880.00];
    notes.forEach((n, i) => {
      setTimeout(() => this.playGuzhengNote(n, 1.4, 0.12), i * 130);
    });
  }

  public playBreakthroughSuccess() {
    if (!this.sfxEnabled) return;
    this.playGong();
    const chord = [293.66, 440.00, 587.33, 739.99, 880.00, 1174.66];
    chord.forEach((n, i) => {
      setTimeout(() => this.playSilkHarp(n, 2.2, 0.08), i * 85);
    });
  }

  public playBreakthroughFail() {
    if (!this.sfxEnabled) return;
    this.playThunder();
    const fall = [349.23, 311.13, 261.63, 196.0];
    fall.forEach((n, i) => {
      setTimeout(() => this.playBassGuqin(n, 1.4, 0.09), i * 120);
    });
  }

  public toggleBGM(): boolean {
    if (this.bgmPlaying) {
      this.stopBGM();
      return false;
    } else {
      this.startBGM();
      return true;
    }
  }

  public isBGMActive(): boolean {
    return this.bgmPlaying;
  }

  /**
   * Orchestrated Xianxia BGM Engine (5 Distinct Non-Repetitive Smooth Soundtracks):
   * - epic: D Major Pentatonic heroic peak score
   * - serene: D Major Pentatonic tranquil meditation
   * - bambooMist: A Minor Pentatonic raindrop silk-harp & misty flute
   * - celestialCourt: G Major Pentatonic imperial jade chimes & warm guqin
   * - starlightAscent: E Minor Pentatonic nocturnal starlight harp & legato xiao
   */
  public startBGM(theme?: BgmThemeMode) {
    if (this.isMuted) return;
    if (theme) this.bgmTheme = theme;

    this.stopBGM();
    this.bgmPlaying = true;
    this.initContext();

    interface TrackConfig {
      droneRoot: number;
      bassScale: number[];
      scale: number[];
      movements: { bassIdx: number; notes: (number | null)[]; fluteAt: number[]; glissAt: number; stepMs: number }[];
      useTaiko: boolean;
      silkRatio: number;
      chimeNote: number;
    }

    const TRACKS: Record<BgmThemeMode, TrackConfig> = {
      epic: {
        droneRoot: 73.42, // D2
        bassScale: [146.83, 164.81, 185.00, 220.00, 246.94],
        scale: [293.66, 329.63, 369.99, 440.00, 493.88, 587.33, 659.25, 739.99, 880.00, 987.77],
        useTaiko: true,
        silkRatio: 0.3,
        chimeNote: 1174.66,
        movements: [
          { bassIdx: 0, notes: [0, 3, 5, 7, 8, 7, 5, 3], fluteAt: [0, 4], glissAt: 3, stepMs: 560 },
          { bassIdx: 4, notes: [4, 5, 6, 8, 9, 8, 6, 5], fluteAt: [2, 6], glissAt: 4, stepMs: 540 },
          { bassIdx: 3, notes: [3, 5, 7, null, 8, 7, 5, 2], fluteAt: [0, 5], glissAt: 6, stepMs: 580 },
          { bassIdx: 1, notes: [1, 3, 5, 6, 8, null, 5, 3], fluteAt: [1, 4], glissAt: -1, stepMs: 560 },
          { bassIdx: 0, notes: [5, 3, 2, 0, 2, 3, 5, 8], fluteAt: [0, 4], glissAt: 7, stepMs: 600 }
        ]
      },
      serene: {
        droneRoot: 73.42,
        bassScale: [146.83, 164.81, 185.00, 220.00, 246.94],
        scale: [293.66, 329.63, 369.99, 440.00, 493.88, 587.33, 659.25, 739.99, 880.00],
        useTaiko: false,
        silkRatio: 0.75,
        chimeNote: 880.00,
        movements: [
          { bassIdx: 0, notes: [0, 2, 3, null, 5, 3, 2, null], fluteAt: [0, 4], glissAt: -1, stepMs: 780 },
          { bassIdx: 3, notes: [3, 5, 6, 5, null, 3, 2, 0], fluteAt: [2], glissAt: 3, stepMs: 820 },
          { bassIdx: 4, notes: [4, 2, 0, 2, 3, null, 5, 3], fluteAt: [1, 5], glissAt: -1, stepMs: 800 },
          { bassIdx: 1, notes: [1, 3, null, 5, 4, 3, 2, 0], fluteAt: [3], glissAt: -1, stepMs: 860 }
        ]
      },
      bambooMist: {
        // A Minor Pentatonic: A3, C4, D4, E4, G4, A4, C5, D5, E5, G5
        droneRoot: 55.0, // A1
        bassScale: [110.0, 130.81, 146.83, 164.81, 196.0],
        scale: [220.0, 261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 587.33, 659.25, 783.99],
        useTaiko: false,
        silkRatio: 0.9,
        chimeNote: 1046.5,
        movements: [
          { bassIdx: 0, notes: [0, 2, 3, 5, null, 6, 5, 3], fluteAt: [0, 5], glissAt: -1, stepMs: 720 },
          { bassIdx: 1, notes: [1, 3, 4, 6, 7, null, 5, 4], fluteAt: [2], glissAt: 4, stepMs: 740 },
          { bassIdx: 2, notes: [2, 4, 5, null, 7, 8, 6, 5], fluteAt: [1, 4], glissAt: -1, stepMs: 760 },
          { bassIdx: 4, notes: [4, 3, 1, 2, 3, null, 2, 0], fluteAt: [0], glissAt: -1, stepMs: 800 },
          { bassIdx: 0, notes: [3, 5, 7, 8, 7, 5, 3, null], fluteAt: [2, 6], glissAt: 3, stepMs: 750 },
          { bassIdx: 3, notes: [3, 2, 1, null, 2, 3, 5, 3], fluteAt: [4], glissAt: -1, stepMs: 840 }
        ]
      },
      celestialCourt: {
        // G Major Pentatonic: G3, A3, B3, D4, E4, G4, A4, B4, D5, E5
        droneRoot: 98.0, // G2
        bassScale: [196.0, 220.0, 246.94, 146.83, 164.81],
        scale: [392.0, 440.0, 493.88, 587.33, 659.25, 783.99, 880.0, 987.77, 1174.66],
        useTaiko: false,
        silkRatio: 0.65,
        chimeNote: 1174.66,
        movements: [
          { bassIdx: 0, notes: [0, 1, 2, 3, 5, null, 3, 2], fluteAt: [0, 4], glissAt: 4, stepMs: 680 },
          { bassIdx: 3, notes: [3, 4, 5, 6, 5, 3, null, 1], fluteAt: [2], glissAt: -1, stepMs: 700 },
          { bassIdx: 4, notes: [4, 2, 1, 0, 1, 2, 3, 5], fluteAt: [0, 5], glissAt: 6, stepMs: 690 },
          { bassIdx: 1, notes: [1, 3, 4, null, 6, 5, 4, 3], fluteAt: [1], glissAt: -1, stepMs: 720 },
          { bassIdx: 0, notes: [2, 3, 5, 7, 6, 5, 3, null], fluteAt: [3], glissAt: -1, stepMs: 740 },
          { bassIdx: 2, notes: [2, 0, 1, 3, 2, 1, 0, null], fluteAt: [0, 4], glissAt: -1, stepMs: 780 }
        ]
      },
      starlightAscent: {
        // E Minor / Aeolian Pentatonic: E3, G3, A3, B3, D4, E4, G4, A4, B4, D5
        droneRoot: 82.41, // E2
        bassScale: [164.81, 196.0, 220.0, 246.94, 146.83],
        scale: [329.63, 392.0, 440.0, 493.88, 587.33, 659.25, 783.99, 880.0, 987.77],
        useTaiko: false,
        silkRatio: 0.95,
        chimeNote: 1318.51,
        movements: [
          { bassIdx: 0, notes: [0, 2, 4, 5, null, 7, 6, 4], fluteAt: [0, 5], glissAt: -1, stepMs: 780 },
          { bassIdx: 1, notes: [1, 3, 5, 6, null, 5, 3, 2], fluteAt: [2], glissAt: 3, stepMs: 800 },
          { bassIdx: 4, notes: [4, 5, 7, 8, 7, 5, 4, null], fluteAt: [1, 4], glissAt: -1, stepMs: 820 },
          { bassIdx: 2, notes: [2, 4, 5, 4, 2, 1, 0, null], fluteAt: [0], glissAt: -1, stepMs: 850 },
          { bassIdx: 3, notes: [3, 5, 6, 8, 6, 5, 3, 2], fluteAt: [3], glissAt: 5, stepMs: 790 },
          { bassIdx: 0, notes: [5, 4, 2, 0, 1, 2, 4, null], fluteAt: [0, 4], glissAt: -1, stepMs: 860 }
        ]
      }
    };

    const config = TRACKS[this.bgmTheme] || TRACKS.epic;
    this.startDronePad(config.droneRoot);

    let phraseIdx = 0;
    let stepIdx = 0;

    const tick = () => {
      if (!this.bgmPlaying || this.isMuted) return;

      const movement = config.movements[phraseIdx % config.movements.length];
      const scaleIdx = movement.notes[stepIdx % movement.notes.length];

      // 1. Anchor downbeat with warm Bass Guqin (never jarring)
      if (stepIdx === 0) {
        this.playBassGuqin(config.bassScale[movement.bassIdx % config.bassScale.length], 3.6, config.useTaiko ? 0.085 : 0.06);
        if (config.useTaiko) {
          this.playTaikoPulse(0.095);
        }
      } else if (config.useTaiko && stepIdx === 4) {
        this.playBassGuqin(config.bassScale[(movement.bassIdx + 3) % config.bassScale.length], 2.6, 0.068);
        this.playTaikoPulse(0.065);
      }

      if (scaleIdx !== null && scaleIdx !== undefined) {
        const noteFreq = config.scale[scaleIdx % config.scale.length];

        // 2. Soft glissando flourish or lyrical pluck
        if (stepIdx === movement.glissAt) {
          const flourishStart = Math.max(0, scaleIdx - 3);
          for (let k = 0; k < 4; k++) {
            const f = config.scale[Math.min(config.scale.length - 1, flourishStart + k)];
            this.scheduleSubTimeout(() => {
              if (this.bgmPlaying && !this.isMuted) {
                if (Math.random() < config.silkRatio) {
                  this.playSilkHarp(f, 1.9, 0.042);
                } else {
                  this.playGuzhengNote(f, 1.5, 0.048);
                }
              }
            }, k * 65);
          }
        } else {
          if (Math.random() < config.silkRatio) {
            this.playSilkHarp(noteFreq, 2.6, 0.052);
          } else {
            this.playGuzhengNote(noteFreq, config.useTaiko ? 2.0 : 2.4, config.useTaiko ? 0.06 : 0.048);
          }
        }

        // 3. Delicate harmonic shimmer on alternating beats
        if (stepIdx % 2 === 1 && Math.random() > 0.48) {
          const harmIdx = (scaleIdx + 2) % config.scale.length;
          this.scheduleSubTimeout(() => {
            if (this.bgmPlaying && !this.isMuted) {
              this.playSilkHarp(config.scale[harmIdx], 2.0, 0.032);
            }
          }, 190);
        }

        // 4. Breathy Xiao Flute phrase lead
        if (movement.fluteAt.includes(stepIdx)) {
          const fluteFreq = noteFreq >= 490 ? noteFreq : noteFreq * 2;
          this.playXiaoFlute(fluteFreq, 2.9, 0.038);
        }
      }

      // 5. Gentle jade bell whisper at phrase turn
      if (stepIdx === movement.notes.length - 1 && phraseIdx % 2 === 1) {
        this.scheduleSubTimeout(() => {
          if (this.bgmPlaying && !this.isMuted) {
            this.playSilkHarp(config.chimeNote, 2.6, 0.022);
          }
        }, 160);
      }

      stepIdx++;
      if (stepIdx >= movement.notes.length) {
        stepIdx = 0;
        // Advance naturally + subtle non-linear phrase rotation so phrases never feel robotic
        phraseIdx = (phraseIdx + (phraseIdx % 3 === 2 ? 2 : 1)) % config.movements.length;
      }

      const jitter = Math.random() * 160;
      this.bgmTimeout = setTimeout(tick, movement.stepMs + jitter);
    };

    tick();
  }

  public stopBGM() {
    this.bgmPlaying = false;
    if (this.bgmTimeout) {
      clearTimeout(this.bgmTimeout);
      this.bgmTimeout = null;
    }
    this.subTimeouts.forEach(id => clearTimeout(id));
    this.subTimeouts.clear();
    this.stopDronePad();
  }
}

export const soundEngine = new CultivationAudioEngine();
