import { Song } from '../types/music';

type AudioTimeCallback = (currentTime: number, duration: number) => void;
type AudioStateCallback = (isPlaying: boolean) => void;
type AudioEndedCallback = () => void;

class MusicAudioEngine {
  private audioCtx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private bassFilter: BiquadFilterNode | null = null;
  private midFilter: BiquadFilterNode | null = null;
  private trebleFilter: BiquadFilterNode | null = null;

  private isPlaying: boolean = false;
  private currentSong: Song | null = null;
  private playbackStartTime: number = 0;
  private pausedAtTime: number = 0;
  private loopInterval: number | null = null;

  // Callbacks
  private onTimeUpdateCallback: AudioTimeCallback | null = null;
  private onStateChangeCallback: AudioStateCallback | null = null;
  private onEndedCallback: AudioEndedCallback | null = null;

  // Sound generator nodes
  private activeVoices: OscillatorNode[] = [];
  private rhythmTimer: number | null = null;

  constructor() {
    // Lazy initialize AudioContext on user gesture
  }

  private initAudio() {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();

      // Master Gain
      this.masterGain = this.audioCtx.createGain();
      this.masterGain.gain.setValueAtTime(0.85, this.audioCtx.currentTime);

      // Analyser for real-time equalizer & waveform visualizer
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 64;
      this.analyser.smoothingTimeConstant = 0.8;

      // 3-band Equalizer
      this.bassFilter = this.audioCtx.createBiquadFilter();
      this.bassFilter.type = 'lowshelf';
      this.bassFilter.frequency.setValueAtTime(250, this.audioCtx.currentTime);

      this.midFilter = this.audioCtx.createBiquadFilter();
      this.midFilter.type = 'peaking';
      this.midFilter.frequency.setValueAtTime(1000, this.audioCtx.currentTime);
      this.midFilter.Q.setValueAtTime(1.0, this.audioCtx.currentTime);

      this.trebleFilter = this.audioCtx.createBiquadFilter();
      this.trebleFilter.type = 'highshelf';
      this.trebleFilter.frequency.setValueAtTime(4000, this.audioCtx.currentTime);

      // Connect graph: Bass -> Mid -> Treble -> MasterGain -> Analyser -> Destination
      this.bassFilter.connect(this.midFilter);
      this.midFilter.connect(this.trebleFilter);
      this.trebleFilter.connect(this.masterGain);
      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.audioCtx.destination);
    }

    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public setCallbacks(
    onTimeUpdate: AudioTimeCallback,
    onStateChange: AudioStateCallback,
    onEnded: AudioEndedCallback
  ) {
    this.onTimeUpdateCallback = onTimeUpdate;
    this.onStateChangeCallback = onStateChange;
    this.onEndedCallback = onEnded;
  }

  public loadAndPlay(song: Song, startFrom: number = 0) {
    this.initAudio();
    this.stopActiveAudio();

    this.currentSong = song;
    this.pausedAtTime = startFrom;
    this.playbackStartTime = (this.audioCtx?.currentTime || 0) - startFrom;
    this.isPlaying = true;

    this.startMusicalPattern(song);
    this.startTimeTracker();
    this.updateMediaSession(song);

    if (this.onStateChangeCallback) {
      this.onStateChangeCallback(true);
    }
  }

  public play() {
    if (!this.currentSong) return;
    this.initAudio();

    if (!this.isPlaying) {
      this.isPlaying = true;
      this.playbackStartTime = (this.audioCtx?.currentTime || 0) - this.pausedAtTime;
      this.startMusicalPattern(this.currentSong);
      this.startTimeTracker();

      if (this.onStateChangeCallback) {
        this.onStateChangeCallback(true);
      }
    }
  }

  public pause() {
    if (!this.isPlaying) return;
    this.isPlaying = false;
    this.pausedAtTime = this.getCurrentTime();

    this.stopActiveAudio();
    this.stopTimeTracker();

    if (this.onStateChangeCallback) {
      this.onStateChangeCallback(false);
    }
  }

  public seek(targetSeconds: number) {
    if (!this.currentSong) return;
    const clamped = Math.max(0, Math.min(targetSeconds, this.currentSong.durationSec));
    this.pausedAtTime = clamped;

    if (this.audioCtx) {
      this.playbackStartTime = this.audioCtx.currentTime - clamped;
    }

    if (this.isPlaying) {
      this.stopActiveAudio();
      this.startMusicalPattern(this.currentSong);
    }

    if (this.onTimeUpdateCallback) {
      this.onTimeUpdateCallback(clamped, this.currentSong.durationSec);
    }
  }

  public setVolume(val: number) {
    if (!this.masterGain || !this.audioCtx) return;
    const clamped = Math.max(0, Math.min(1, val));
    this.masterGain.gain.setValueAtTime(clamped, this.audioCtx.currentTime);
  }

  public setEqualizer(preset: string) {
    if (!this.bassFilter || !this.midFilter || !this.trebleFilter || !this.audioCtx) return;
    const now = this.audioCtx.currentTime;

    switch (preset) {
      case 'Bass Boost':
        this.bassFilter.gain.setValueAtTime(7.0, now);
        this.midFilter.gain.setValueAtTime(0.0, now);
        this.trebleFilter.gain.setValueAtTime(-1.0, now);
        break;
      case 'Vocal':
        this.bassFilter.gain.setValueAtTime(-2.0, now);
        this.midFilter.gain.setValueAtTime(6.0, now);
        this.trebleFilter.gain.setValueAtTime(2.0, now);
        break;
      case 'Electronic':
        this.bassFilter.gain.setValueAtTime(5.5, now);
        this.midFilter.gain.setValueAtTime(-1.5, now);
        this.trebleFilter.gain.setValueAtTime(5.0, now);
        break;
      case 'Rock':
        this.bassFilter.gain.setValueAtTime(4.0, now);
        this.midFilter.gain.setValueAtTime(3.0, now);
        this.trebleFilter.gain.setValueAtTime(3.5, now);
        break;
      case 'Acoustic':
        this.bassFilter.gain.setValueAtTime(2.0, now);
        this.midFilter.gain.setValueAtTime(1.5, now);
        this.trebleFilter.gain.setValueAtTime(4.5, now);
        break;
      case 'Flat':
      default:
        this.bassFilter.gain.setValueAtTime(0.0, now);
        this.midFilter.gain.setValueAtTime(0.0, now);
        this.trebleFilter.gain.setValueAtTime(0.0, now);
        break;
    }
  }

  public getFrequencyData(): Uint8Array {
    if (!this.analyser) {
      return new Uint8Array(32);
    }
    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);
    return dataArray;
  }

  public getCurrentTime(): number {
    if (!this.isPlaying || !this.audioCtx) {
      return this.pausedAtTime;
    }
    const elapsed = this.audioCtx.currentTime - this.playbackStartTime;
    return Math.max(0, elapsed);
  }

  private startTimeTracker() {
    this.stopTimeTracker();
    this.loopInterval = window.setInterval(() => {
      if (!this.currentSong || !this.isPlaying) return;
      const current = this.getCurrentTime();

      if (this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(current, this.currentSong.durationSec);
      }

      if (current >= this.currentSong.durationSec) {
        this.pause();
        if (this.onEndedCallback) {
          this.onEndedCallback();
        }
      }
    }, 200);
  }

  private stopTimeTracker() {
    if (this.loopInterval !== null) {
      clearInterval(this.loopInterval);
      this.loopInterval = null;
    }
  }

  private stopActiveAudio() {
    this.activeVoices.forEach((node) => {
      try {
        node.stop();
        node.disconnect();
      } catch {
        // Already stopped
      }
    });
    this.activeVoices = [];

    if (this.rhythmTimer !== null) {
      window.clearInterval(this.rhythmTimer);
      this.rhythmTimer = null;
    }
  }

  /**
   * Generates a procedural, pleasant harmonic musical track using Web Audio oscillators.
   * This gives the user rich, genuine sounding audio that never hits network 404s!
   */
  private startMusicalPattern(song: Song) {
    if (!this.audioCtx || !this.bassFilter) return;

    // Scale notes based on genre/preset
    let chordProgression: number[][] = [];
    const bpm = song.bpm || 100;
    const beatSec = 60 / bpm;

    switch (song.synthPreset) {
      case 'bengali':
      case 'acoustic':
        // D Major / Indian Raag Yaman inspired chords (D, F#, A, C#)
        chordProgression = [
          [146.83, 220.0, 293.66, 369.99], // D, A, D, F#
          [164.81, 246.94, 329.63, 392.0],  // E, B, E, G
          [196.0, 293.66, 392.0, 493.88],   // G, D, G, B
          [220.0, 329.63, 440.0, 554.37]    // A, E, A, C#
        ];
        break;
      case 'synthwave':
        // Synthwave Minor Progression (F#m, D, A, E)
        chordProgression = [
          [92.5, 185.0, 277.18, 369.99],  // F#
          [73.42, 146.83, 220.0, 293.66], // D
          [110.0, 220.0, 277.18, 329.63], // A
          [82.41, 164.81, 246.94, 329.63] // E
        ];
        break;
      case 'dance':
      case 'pop':
        // Pop 4-chord progression (Am, F, C, G)
        chordProgression = [
          [110.0, 220.0, 261.63, 329.63], // Am
          [87.31, 174.61, 220.0, 261.63], // F
          [130.81, 261.63, 329.63, 392.0], // C
          [98.0, 196.0, 246.94, 293.66]   // G
        ];
        break;
      case 'lofi':
        // Warm Jazz 7th chords (Dmaj7, C#m7, Bm7, A)
        chordProgression = [
          [146.83, 220.0, 277.18, 369.99],
          [138.59, 207.65, 277.18, 329.63],
          [123.47, 185.0, 246.94, 293.66],
          [110.0, 164.81, 220.0, 277.18]
        ];
        break;
      case 'ambient':
      default:
        // Deep meditative fifths & octaves (C, G, D, A)
        chordProgression = [
          [65.41, 130.81, 196.0, 261.63],
          [87.31, 174.61, 261.63, 349.23],
          [98.0, 196.0, 293.66, 392.0],
          [110.0, 220.0, 329.63, 440.0]
        ];
        break;
    }

    let step = 0;

    const playStep = () => {
      if (!this.isPlaying || !this.audioCtx || !this.bassFilter) return;

      const chordIdx = Math.floor(step / 4) % chordProgression.length;
      const chord = chordProgression[chordIdx];
      const now = this.audioCtx.currentTime;

      // Bass drone / kick pulse
      if (step % 2 === 0) {
        const bassOsc = this.audioCtx.createOscillator();
        const bassGain = this.audioCtx.createGain();

        bassOsc.type = song.synthPreset === 'synthwave' ? 'sawtooth' : 'sine';
        bassOsc.frequency.setValueAtTime(chord[0] * 0.5, now);

        bassGain.gain.setValueAtTime(0.28, now);
        bassGain.gain.exponentialRampToValueAtTime(0.01, now + beatSec * 1.8);

        bassOsc.connect(bassGain);
        bassGain.connect(this.bassFilter);

        bassOsc.start(now);
        bassOsc.stop(now + beatSec * 1.9);
      }

      // Melodic arpeggio note
      const arpIdx = step % chord.length;
      const noteFreq = chord[arpIdx];

      const arpOsc = this.audioCtx.createOscillator();
      const arpGain = this.audioCtx.createGain();

      if (song.synthPreset === 'synthwave') {
        arpOsc.type = 'sawtooth';
      } else if (song.synthPreset === 'lofi') {
        arpOsc.type = 'triangle';
      } else if (song.synthPreset === 'bengali' || song.synthPreset === 'acoustic') {
        arpOsc.type = 'sine';
      } else {
        arpOsc.type = 'triangle';
      }

      arpOsc.frequency.setValueAtTime(noteFreq, now);

      arpGain.gain.setValueAtTime(0.18, now);
      arpGain.gain.exponentialRampToValueAtTime(0.005, now + beatSec * 0.9);

      arpOsc.connect(arpGain);
      arpGain.connect(this.bassFilter);

      arpOsc.start(now);
      arpOsc.stop(now + beatSec * 0.95);

      step++;
    };

    // Trigger immediate first beat then interval
    playStep();
    this.rhythmTimer = window.setInterval(playStep, (beatSec * 1000) / 2);
  }

  private updateMediaSession(song: Song) {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: song.title,
        artist: song.artist,
        album: song.album,
        artwork: [
          { src: '/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: '/icon-512.png', sizes: '512x512', type: 'image/png' }
        ]
      });

      navigator.mediaSession.setActionHandler('play', () => this.play());
      navigator.mediaSession.setActionHandler('pause', () => this.pause());
      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (details.seekTime !== undefined) {
          this.seek(details.seekTime);
        }
      });
    }
  }

  public destroy() {
    this.stopActiveAudio();
    this.stopTimeTracker();
    if (this.audioCtx) {
      this.audioCtx.close();
      this.audioCtx = null;
    }
  }
}

export const audioEngine = new MusicAudioEngine();
