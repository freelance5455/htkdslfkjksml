/**
 * GODEX Mutation Firewall
 * Strict capability-permission layer governing all filesystem, checkpoint,
 * diff, and tool execution operations.
 */

export type CapabilityMode =
  | 'READ_ONLY'
  | 'ANALYZE'
  | 'PROPOSE'
  | 'MODIFY'
  | 'DELETE'
  | 'EXECUTE'
  | 'VERIFY';

export interface CapabilityDecision {
  mode: CapabilityMode;
  allowedTools: string[];
  deniedTools: string[];
  reason: string;
  confidence: number;
  evidence: string[];
  isMutationPermitted: boolean;
  blockedOperations: string[];
}

export interface PermissionCheckResult {
  allowed: boolean;
  reason: string;
  mode: CapabilityMode;
  isMutationBlocked?: boolean;
}

export class MutationFirewall {
  private static instance: MutationFirewall | null = null;
  private currentDecision: CapabilityDecision | null = null;

  public static readonly READ_ONLY_TOOLS = [
    'read_file',
    'list_directory',
    'search_symbols',
    'explain_code',
    'inspect_project',
    'get_project_health',
    'ast_query',
    'get_dependency_graph'
  ];

  public static readonly MUTATION_TOOLS = [
    'write_file',
    'patch_file',
    'delete_file',
    'apply_diff',
    'create_checkpoint',
    'restore_checkpoint',
    'execute_command',
    'auto_repair'
  ];

  public static getInstance(): MutationFirewall {
    if (!MutationFirewall.instance) {
      MutationFirewall.instance = new MutationFirewall();
    }
    return MutationFirewall.instance;
  }

  /**
   * Evaluates user request text, route classification, and constraints
   * to determine authoritative capability mode.
   */
  public evaluateRequest(userRequest: string, explicitRoute?: string): CapabilityDecision {
    const text = (userRequest || '').trim();
    const lower = text.toLowerCase();

    // 1. Explicit read-only negative guard triggers
    const hasNegativeMutationConstraint =
      /\b(?:do\s+not\s+(?:modify|change|edit|touch|write|mutate)|don't\s+(?:modify|change|edit|touch|write|mutate)|without\s+(?:modifying|changing|editing|writing|touching)|read-only|read\s+only|no\s+(?:changes|mutation|code\s+changes|edits))\b/i.test(lower);

    // 2. Inspection/query verbs
    const isPureInspectionVerb =
      /^(?:what|where|how|why|who|explain|show|list|find|search|audit|inspect|check|analyze|describe|locate|read|summarize)\b/i.test(lower);

    // 3. Mutation triggers
    const hasMutationVerb =
      /\b(?:refactor|fix|change|update|delete|remove|rewrite|modify|create|build|implement|patch|write|add|make|banao|likho|kardo)\b/i.test(lower);

    let mode: CapabilityMode = 'MODIFY';
    let reason = 'Standard development mutation requested.';
    let isMutationPermitted = true;
    const evidence: string[] = [];

    if (hasNegativeMutationConstraint) {
      mode = 'READ_ONLY';
      reason = 'User explicitly forbade workspace mutation ("do not modify" / "read-only").';
      isMutationPermitted = false;
      evidence.push('Matched explicit negative mutation guard pattern');
    } else if (explicitRoute === 'READ_ONLY_ENGINEERING_QUERY' || (isPureInspectionVerb && !hasMutationVerb)) {
      mode = 'READ_ONLY';
      reason = 'Read-only engineering query / code inspection intent classified.';
      isMutationPermitted = false;
      evidence.push('Pure inquiry/inspection intent with zero mutation commands');
    } else if (/\b(?:test|verify|benchmark|validate|matrix)\b/i.test(lower) && !hasMutationVerb) {
      mode = 'VERIFY';
      reason = 'Verification or test suite invocation.';
      isMutationPermitted = false;
      evidence.push('Test/verification command without file write directive');
    } else if (/\b(?:simulate|counterfactual|explore\s+options|compare\s+strategies)\b/i.test(lower)) {
      mode = 'ANALYZE';
      reason = 'Analytical simulation or counterfactual exploration.';
      isMutationPermitted = false;
      evidence.push('Counterfactual analysis mode');
    } else if (/\b(?:propose|plan|draft|preview\s+diff)\b/i.test(lower) && !/\b(?:apply|implement\s+now)\b/i.test(lower)) {
      mode = 'PROPOSE';
      reason = 'Proposal/plan generation without immediate disk write.';
      isMutationPermitted = false;
      evidence.push('Proposal intent classified');
    } else if (/\b(?:delete|remove\s+file|drop)\b/i.test(lower)) {
      mode = 'DELETE';
      reason = 'Explicit file deletion requested.';
      isMutationPermitted = true;
      evidence.push('File deletion command');
    }

    const allowedTools = isMutationPermitted
      ? [...MutationFirewall.READ_ONLY_TOOLS, ...MutationFirewall.MUTATION_TOOLS]
      : [...MutationFirewall.READ_ONLY_TOOLS];

    const deniedTools = isMutationPermitted
      ? []
      : [...MutationFirewall.MUTATION_TOOLS];

    const blockedOperations = isMutationPermitted
      ? []
      : ['writeFile', 'patchFile', 'deleteFile', 'applyDiff', 'createCheckpoint', 'restoreCheckpoint'];

    const decision: CapabilityDecision = {
      mode,
      allowedTools,
      deniedTools,
      reason,
      confidence: hasNegativeMutationConstraint ? 1.0 : 0.95,
      evidence,
      isMutationPermitted,
      blockedOperations
    };

    this.currentDecision = decision;
    return decision;
  }

  public getCurrentDecision(): CapabilityDecision | null {
    return this.currentDecision;
  }

  /**
   * Asserts whether a specific tool or mutation action is permitted under the active decision.
   */
  public assertPermission(toolOrActionName: string, decision?: CapabilityDecision): PermissionCheckResult {
    const active = decision || this.currentDecision || {
      mode: 'READ_ONLY',
      allowedTools: MutationFirewall.READ_ONLY_TOOLS,
      deniedTools: MutationFirewall.MUTATION_TOOLS,
      reason: 'No active decision; defaulted to secure READ_ONLY.',
      confidence: 1.0,
      evidence: ['Default fail-safe active'],
      isMutationPermitted: false,
      blockedOperations: ['writeFile', 'patchFile', 'deleteFile', 'applyDiff', 'createCheckpoint']
    };

    const isMutating = MutationFirewall.MUTATION_TOOLS.includes(toolOrActionName) ||
      active.blockedOperations.includes(toolOrActionName);

    if (isMutating && !active.isMutationPermitted) {
      return {
        allowed: false,
        reason: `Mutation blocked by Firewall: Tool "${toolOrActionName}" requires mutation capability, but active mode is ${active.mode}. Reason: ${active.reason}`,
        mode: active.mode,
        isMutationBlocked: true
      };
    }

    return {
      allowed: true,
      reason: `Tool "${toolOrActionName}" permitted under ${active.mode} mode.`,
      mode: active.mode,
      isMutationBlocked: false
    };
  }

  /**
   * Enforces a hard throw or error result if a write is attempted under read-only capability.
   */
  public guardWrite(targetPath: string, decision?: CapabilityDecision): void {
    const check = this.assertPermission('writeFile', decision);
    if (!check.allowed) {
      throw new Error(`MUTATION_FIREWALL_VIOLATION: Unauthorized write to "${targetPath}" prevented. ${check.reason}`);
    }
  }

  /**
   * Enforces a hard throw or error result if a checkpoint is attempted under read-only capability.
   */
  public guardCheckpoint(decision?: CapabilityDecision): void {
    const check = this.assertPermission('createCheckpoint', decision);
    if (!check.allowed) {
      throw new Error(`MUTATION_FIREWALL_VIOLATION: Checkpoint creation blocked. ${check.reason}`);
    }
  }
}
