import { KEYS, readKey, writeKey } from './storage';
import { chargeWallet, creditWallet, withWalletMutation } from './economy';
import {
  EMPTY_FARM,
  FARM_MATURITY_SECONDS,
  FARM_PLOT_COSTS,
  PLANT_CATALOG,
  normalizeFarm,
  plantForId,
  type FarmState,
  type PlantId,
} from './farmModel';

export type FarmFailure = 'invalid_plot' | 'locked' | 'already_unlocked' | 'occupied' | 'funds' | 'no_seed' | 'not_ready' | 'empty';
export type FarmResult = { ok: true } | { ok: false; reason: FarmFailure };

export function getFarm(): FarmState {
  return normalizeFarm(readKey<FarmState>(KEYS.farm, EMPTY_FARM));
}

export function unlockFarmPlot(plotId: number): Promise<FarmResult> {
  const price = FARM_PLOT_COSTS[plotId];
  if (!price) return Promise.resolve({ ok: false, reason: 'invalid_plot' });
  return withWalletMutation<FarmResult>([KEYS.farm], (wallet) => {
    const farm = getFarm();
    const plot = farm.plots.find((item) => item.id === plotId);
    if (!plot) return { wallet, result: { ok: false, reason: 'invalid_plot' } };
    if (plot.unlocked) return { wallet, result: { ok: false, reason: 'already_unlocked' } };
    if (wallet.balance < price) return { wallet, result: { ok: false, reason: 'funds' } };
    writeKey(KEYS.farm, {
      ...farm,
      plots: farm.plots.map((item) => item.id === plotId ? { ...item, unlocked: true } : item),
    });
    return {
      wallet: chargeWallet(wallet, price, `فتح قطعة المزرعة ${plotId}`),
      result: { ok: true },
    };
  });
}

export function buyPlantSeeds(plantId: PlantId, count = 1): Promise<FarmResult> {
  const plant = PLANT_CATALOG.find((item) => item.id === plantId);
  if (!plant || !Number.isInteger(count) || count < 1 || count > 10) {
    return Promise.resolve({ ok: false, reason: 'empty' });
  }
  const totalPrice = plant.seedPrice * count;
  return withWalletMutation<FarmResult>([KEYS.farm], (wallet) => {
    if (wallet.balance < totalPrice) return { wallet, result: { ok: false, reason: 'funds' } };
    const farm = getFarm();
    writeKey(KEYS.farm, {
      ...farm,
      seeds: { ...farm.seeds, [plantId]: (farm.seeds[plantId] ?? 0) + count },
    });
    return {
      wallet: chargeWallet(wallet, totalPrice, `شراء بذور ${plant.name} × ${count}`),
      result: { ok: true },
    };
  });
}

export function plantSeed(plotId: number, plantId: PlantId): Promise<FarmResult> {
  return withWalletMutation<FarmResult>([KEYS.farm], (wallet) => {
    const farm = getFarm();
    const plot = farm.plots.find((item) => item.id === plotId);
    if (!plot) return { wallet, result: { ok: false, reason: 'invalid_plot' } };
    if (!plot.unlocked) return { wallet, result: { ok: false, reason: 'locked' } };
    if (plot.plant) return { wallet, result: { ok: false, reason: 'occupied' } };
    if (!PLANT_CATALOG.some((item) => item.id === plantId)) return { wallet, result: { ok: false, reason: 'empty' } };
    const seedCount = farm.seeds[plantId] ?? 0;
    if (seedCount < 1) return { wallet, result: { ok: false, reason: 'no_seed' } };
    writeKey(KEYS.farm, {
      ...farm,
      seeds: { ...farm.seeds, [plantId]: seedCount - 1 },
      plots: farm.plots.map((item) => item.id === plotId
        ? { ...item, plant: { id: plantId, activeSeconds: 0, plantedAt: Date.now() } }
        : item),
    });
    return { wallet, result: { ok: true } };
  });
}

export function harvestPlant(plotId: number): Promise<FarmResult> {
  return withWalletMutation<FarmResult>([KEYS.farm], (wallet) => {
    const farm = getFarm();
    const plot = farm.plots.find((item) => item.id === plotId);
    if (!plot) return { wallet, result: { ok: false, reason: 'invalid_plot' } };
    if (!plot.plant) return { wallet, result: { ok: false, reason: 'empty' } };
    if (plot.plant.activeSeconds < FARM_MATURITY_SECONDS) return { wallet, result: { ok: false, reason: 'not_ready' } };
    const plant = plantForId(plot.plant.id);
    const harvestedAt = Date.now();
    const nextFarm: FarmState = {
      ...farm,
      totalHarvests: farm.totalHarvests + 1,
      harvestsByPlant: { ...farm.harvestsByPlant, [plant.id]: (farm.harvestsByPlant[plant.id] ?? 0) + 1 },
      harvestLog: [...farm.harvestLog, { plotId, plantId: plant.id, points: plant.harvestPoints, at: harvestedAt }].slice(-300),
      plots: farm.plots.map((item) => item.id === plotId ? { ...item, plant: undefined } : item),
    };
    writeKey(KEYS.farm, nextFarm);
    const transactionId = `farm-harvest:${plotId}:${harvestedAt}`;
    return {
      wallet: creditWallet(wallet, plant.harvestPoints, `بيع محصول ${plant.name}`, transactionId),
      result: { ok: true },
    };
  });
}

export function farmFailureText(reason: FarmFailure): string {
  switch (reason) {
    case 'invalid_plot': return 'هذه القطعة غير موجودة.';
    case 'locked': return 'افتح القطعة بالنقاط أولاً.';
    case 'already_unlocked': return 'هذه القطعة مفتوحة بالفعل.';
    case 'occupied': return 'احصد النبتة أو أزلها قبل زراعة غيرها.';
    case 'funds': return 'رصيدك لا يكفي لهذه العملية.';
    case 'no_seed': return 'لا تملك بذوراً من هذا النوع. اشترِ بذرة أولاً.';
    case 'not_ready': return 'تحتاج النبتة إلى مزيد من ساعات الدراسة النشطة.';
    case 'empty': return 'لا يوجد شيء قابل للحصاد هنا.';
    default: return 'تعذّرت العملية. حاول مرة أخرى.';
  }
}
