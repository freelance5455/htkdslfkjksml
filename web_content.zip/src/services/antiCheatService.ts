/**
 * Anti-Cheat, Fair Play & Moderation Service
 * Evaluates move legality, Average Centipawn Loss (ACPL), engine-similarity thresholds,
 * robotic move timing variance, and manages user incident reports and staff moderation actions.
 */

import { FairPlayAnalysis, UserReport, ModerationAction, ReportCategory } from '../types/chess';

const REPORTS_STORAGE_KEY = 'chess3d_user_reports_v5';
const MODERATION_STORAGE_KEY = 'chess3d_moderation_v5';
const FLAGS_STORAGE_KEY = 'chess3d_fairplay_flags_v5';

export const INITIAL_FAIR_PLAY_FLAGS: FairPlayAnalysis[] = [
  {
    id: 'fp-flag-101',
    gameId: 'G-ONLINE-9812',
    userId: 'u-suspect-1',
    userName: 'FastBot_99',
    acpl: 8.4,
    engineSimilarity: 98.2,
    blunderCount: 0,
    moveTimeVariance: 0.12, // robotic 1.2s per move invariant
    riskLevel: 'high',
    flagReasons: [
      'Engine top-1 choice correlation exceeding 98% across 38 moves',
      'Extremely low move-time standard deviation (0.12s) indicating programmatic input',
      'Zero blunders or inaccuracies across complex tactical transition',
    ],
    isReviewed: false,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: 'fp-flag-102',
    gameId: 'G-ONLINE-9744',
    userId: 'u-suspect-2',
    userName: 'RookMaster2000',
    acpl: 14.1,
    engineSimilarity: 88.5,
    blunderCount: 1,
    moveTimeVariance: 1.84,
    riskLevel: 'medium',
    flagReasons: ['Unusual tactical accuracy spike in 15+ ply endgame calculation'],
    isReviewed: false,
    createdAt: new Date(Date.now() - 7200000).toISOString(),
  },
];

export const INITIAL_USER_REPORTS: UserReport[] = [
  {
    id: 'rep-201',
    reporterId: 'user-cand-4',
    reporterName: 'Aria Chen',
    reportedId: 'u-suspect-1',
    reportedName: 'FastBot_99',
    gameId: 'G-ONLINE-9812',
    category: 'suspected_engine',
    notes: 'Opponent made instant grandmaster-level moves in complex middle game with identical 1.2s intervals.',
    status: 'pending',
    createdAt: new Date(Date.now() - 3400000).toISOString(),
  },
  {
    id: 'rep-202',
    reporterId: 'user-fm-3',
    reporterName: 'Marcus Thorne',
    reportedId: 'u-quitter-3',
    reportedName: 'GriefPlayer_X',
    gameId: 'G-ONLINE-9650',
    category: 'stalling',
    notes: 'Player stalled the clock for 9 minutes in a lost King and Pawn endgame rather than resigning.',
    status: 'investigating',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

class AntiCheatService {
  private flags: FairPlayAnalysis[] = [];
  private reports: UserReport[] = [];
  private actions: ModerationAction[] = [];

  constructor() {
    this.loadState();
  }

  private loadState(): void {
    try {
      const storedFlags = localStorage.getItem(FLAGS_STORAGE_KEY);
      this.flags = storedFlags ? JSON.parse(storedFlags) : [...INITIAL_FAIR_PLAY_FLAGS];

      const storedReports = localStorage.getItem(REPORTS_STORAGE_KEY);
      this.reports = storedReports ? JSON.parse(storedReports) : [...INITIAL_USER_REPORTS];

      const storedMod = localStorage.getItem(MODERATION_STORAGE_KEY);
      this.actions = storedMod ? JSON.parse(storedMod) : [];
    } catch {
      this.flags = [...INITIAL_FAIR_PLAY_FLAGS];
      this.reports = [...INITIAL_USER_REPORTS];
      this.actions = [];
    }
  }

  private saveState(): void {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(FLAGS_STORAGE_KEY, JSON.stringify(this.flags));
      localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(this.reports));
      localStorage.setItem(MODERATION_STORAGE_KEY, JSON.stringify(this.actions));
    } catch (e) {
      console.warn('Failed to save fair play state:', e);
    }
  }

  /**
   * Submit a fair play report against a player
   */
  public submitReport(params: {
    reporterId: string;
    reporterName: string;
    reportedId: string;
    reportedName: string;
    gameId?: string;
    category: ReportCategory;
    notes: string;
  }): { success: boolean; reportId: string } {
    const newReport: UserReport = {
      id: `rep-${Date.now()}`,
      reporterId: params.reporterId,
      reporterName: params.reporterName,
      reportedId: params.reportedId,
      reportedName: params.reportedName,
      gameId: params.gameId,
      category: params.category,
      notes: params.notes,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    this.reports.unshift(newReport);
    this.saveState();
    return { success: true, reportId: newReport.id };
  }

  public getReports(): UserReport[] {
    return [...this.reports];
  }

  public getFlags(): FairPlayAnalysis[] {
    return [...this.flags];
  }

  public getModerationActions(): ModerationAction[] {
    return [...this.actions];
  }

  /**
   * Apply an authorized moderation action (staff workflow)
   */
  public applyModerationAction(params: {
    targetUserId: string;
    targetUserName: string;
    actionType: 'warning' | 'temporary_ban' | 'permanent_ban' | 'rating_adjustment' | 'unban';
    reason: string;
    expiresInDays?: number;
    createdBy: string;
  }): ModerationAction {
    const action: ModerationAction = {
      id: `mod-${Date.now()}`,
      targetUserId: params.targetUserId,
      targetUserName: params.targetUserName,
      actionType: params.actionType,
      reason: params.reason,
      expiresAt: params.expiresInDays
        ? new Date(Date.now() + params.expiresInDays * 86400000).toISOString()
        : undefined,
      createdAt: new Date().toISOString(),
      createdBy: params.createdBy,
    };

    this.actions.unshift(action);

    // Update corresponding report status to resolved if matching
    this.reports.forEach((r) => {
      if (r.reportedId === params.targetUserId && r.status !== 'resolved') {
        r.status = 'resolved';
      }
    });

    this.saveState();
    return action;
  }

  /**
   * Run automated post-match ACPL & fair-play inspection
   */
  public inspectMatchMoves(
    gameId: string,
    userId: string,
    userName: string,
    moveTimes: number[],
    evalChanges: number[]
  ): FairPlayAnalysis | null {
    if (moveTimes.length < 10) return null; // Small sample size protection

    // 1. Calculate Average Centipawn Loss
    const totalLoss = evalChanges.reduce((acc, curr) => acc + Math.max(0, -curr), 0);
    const acpl = Number((totalLoss / moveTimes.length).toFixed(1));

    // 2. Calculate Move Time Variance (standard deviation)
    const avgTime = moveTimes.reduce((a, b) => a + b, 0) / moveTimes.length;
    const variance =
      moveTimes.reduce((acc, curr) => acc + Math.pow(curr - avgTime, 2), 0) / moveTimes.length;
    const stdDev = Number(Math.sqrt(variance).toFixed(2));

    // 3. Flag conditions: Very low ACPL + very low timing variance
    const isRoboticTiming = stdDev < 0.25;
    const isSuperGMPrecision = acpl < 12.0;

    if (isRoboticTiming || isSuperGMPrecision) {
      const reasons: string[] = [];
      if (isSuperGMPrecision) reasons.push(`Exceptional precision: ACPL of ${acpl} centipawns.`);
      if (isRoboticTiming) reasons.push(`Anomalously uniform move execution (StdDev: ${stdDev}s).`);

      const flag: FairPlayAnalysis = {
        id: `fp-${Date.now()}`,
        gameId,
        userId,
        userName,
        acpl,
        engineSimilarity: Math.min(99.5, Number((100 - acpl * 1.5).toFixed(1))),
        blunderCount: 0,
        moveTimeVariance: stdDev,
        riskLevel: isRoboticTiming && isSuperGMPrecision ? 'critical' : 'high',
        flagReasons: reasons,
        isReviewed: false,
        createdAt: new Date().toISOString(),
      };

      this.flags.unshift(flag);
      this.saveState();
      return flag;
    }

    return null;
  }
}

export const antiCheatService = new AntiCheatService();
