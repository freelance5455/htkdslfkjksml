import { authService } from './authService';

export interface AdminOverview {
  totalUsers: number;
  totalProviders: number;
  verifiedProviders: number;
  pendingVerifications: number;
  completedBookings: number;
  totalGrossRevenue: number;
  totalPlatformCommissionRevenue: number;
  timestamp: string;
}

export interface AdminUserRecord {
  id: string;
  name: string;
  username: string;
  email: string;
  phone: string;
  role: 'customer' | 'provider' | 'admin';
  city: string;
  area: string;
  is_active: number;
  created_at: string;
}

class AdminService {
  private getHeaders(): HeadersInit {
    const token = authService.getToken();
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token || ''}`,
    };
  }

  async getOverview(): Promise<AdminOverview> {
    const res = await fetch('/api/admin/overview', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load admin overview data.');
    return await res.json();
  }

  async getUsers(): Promise<AdminUserRecord[]> {
    const res = await fetch('/api/admin/users', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load users list.');
    const data = await res.json();
    return data.users || [];
  }

  async toggleUserStatus(userId: string, isActive: boolean): Promise<void> {
    const res = await fetch(`/api/admin/users/${userId}/status`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify({ is_active: isActive }),
    });
    if (!res.ok) throw new Error('Failed to update user status.');
  }

  async verifyProvider(providerId: string, status: 'verified' | 'rejected', reason?: string): Promise<void> {
    const res = await fetch(`/api/admin/providers/${providerId}/verify`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ status, reason }),
    });
    if (!res.ok) throw new Error('Failed to update provider verification.');
  }

  async updateSettings(commissionPercentage: number, emergencySurcharge: number, minVisitCharge: number): Promise<void> {
    const res = await fetch('/api/admin/settings', {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify({
        commission_percentage: commissionPercentage,
        emergency_surcharge: emergencySurcharge,
        min_visit_charge: minVisitCharge,
      }),
    });
    if (!res.ok) throw new Error('Failed to update platform settings.');
  }

  async addCategory(cat: any): Promise<void> {
    const res = await fetch('/api/admin/categories', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(cat),
    });
    if (!res.ok) throw new Error('Failed to save category.');
  }

  async updateReport(reportId: string, status: string, notes?: string): Promise<void> {
    const res = await fetch(`/api/admin/reports/${reportId}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify({ status, admin_notes: notes }),
    });
    if (!res.ok) throw new Error('Failed to update report.');
  }

  async setupAdminCredentials(payload: { username: string; email: string; password: string; setupKey?: string }): Promise<any> {
    const res = await fetch('/api/auth/admin/setup', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to configure admin account.');
    return data;
  }
}

export const adminService = new AdminService();
