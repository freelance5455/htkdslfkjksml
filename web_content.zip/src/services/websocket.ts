type EventCallback = (data: any) => void;

class WebSocketClient {
  private ws: WebSocket | null = null;
  private currentUserId: string | null = null;
  private listeners: Map<string, Set<EventCallback>> = new Map();
  private reconnectTimeout: any = null;
  public onlineUsers: Set<string> = new Set();

  public init(userId: string) {
    this.currentUserId = userId;
    this.connect();
  }

  private connect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('[WS] Conectado ao servidor Angola Connect em tempo real');
        if (this.currentUserId) {
          this.send({
            type: 'auth',
            userId: this.currentUserId
          });
        }
      };

      this.ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          this.handleIncoming(payload);
        } catch (err) {
          console.error('[WS] Mensagem inválida recebida:', err);
        }
      };

      this.ws.onclose = () => {
        console.log('[WS] Conexão terminada. Tentando reconectar em 3s...');
        this.scheduleReconnect();
      };

      this.ws.onerror = (err) => {
        console.warn('[WS] Erro no socket:', err);
      };
    } catch (err) {
      console.warn('[WS] Falha ao instanciar WebSocket:', err);
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect() {
    if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout);
    this.reconnectTimeout = setTimeout(() => {
      this.connect();
    }, 3000);
  }

  private handleIncoming(data: any) {
    if (data.type === 'presence:init' && Array.isArray(data.onlineUserIds)) {
      this.onlineUsers = new Set(data.onlineUserIds);
      this.emit('presence:change', { onlineUsers: Array.from(this.onlineUsers) });
    } else if (data.type === 'presence:update') {
      if (data.status === 'online') {
        this.onlineUsers.add(data.userId);
      } else {
        this.onlineUsers.delete(data.userId);
      }
      this.emit('presence:change', { onlineUsers: Array.from(this.onlineUsers), updatedUser: data });
    }

    // Forward to registered listeners
    this.emit(data.type, data);
  }

  public send(payload: object) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  public on(eventType: string, callback: EventCallback) {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, new Set());
    }
    this.listeners.get(eventType)!.add(callback);
    return () => this.off(eventType, callback);
  }

  public off(eventType: string, callback: EventCallback) {
    const set = this.listeners.get(eventType);
    if (set) {
      set.delete(callback);
    }
  }

  private emit(eventType: string, data: any) {
    const set = this.listeners.get(eventType);
    if (set) {
      for (const cb of set) {
        try {
          cb(data);
        } catch (err) {
          console.error(`[WS] Erro no listener do evento ${eventType}:`, err);
        }
      }
    }
  }

  // Messaging helpers
  public sendChatMessage(message: any, recipientIds: string[]) {
    this.send({
      type: 'message:send',
      message,
      recipientIds
    });
  }

  public sendTyping(conversationId: string, recipientIds: string[], isTyping: boolean) {
    this.send({
      type: 'typing',
      conversationId,
      recipientIds,
      isTyping
    });
  }

  // WebRTC Signaling helpers
  public initiateCall(toUserId: string, caller: any, callType: 'audio' | 'video', roomId: string) {
    this.send({
      type: 'call:initiate',
      toUserId,
      caller,
      callType,
      roomId
    });
  }

  public acceptCall(callerId: string, roomId: string) {
    this.send({
      type: 'call:accept',
      callerId,
      roomId
    });
  }

  public rejectCall(callerId: string, reason?: string) {
    this.send({
      type: 'call:reject',
      callerId,
      reason
    });
  }

  public sendCallSignal(toUserId: string, signal: any) {
    this.send({
      type: 'call:signal',
      toUserId,
      signal
    });
  }

  public endCall(toUserId: string, durationSeconds: number, callType: 'audio' | 'video') {
    this.send({
      type: 'call:end',
      toUserId,
      durationSeconds,
      callType
    });
  }

  public disconnect() {
    if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout);
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}

export const wsClient = new WebSocketClient();
