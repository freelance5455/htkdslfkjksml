import { User } from 'firebase/auth';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Unsubscribe,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { getDownloadURL, ref as storageRef, uploadBytesResumable } from 'firebase/storage';
import {
  CURRENT_ACADEMIC_SESSION,
  db,
  handleFirestoreError,
  OperationType,
  storage,
} from '../lib/firebase';
import {
  Announcement,
  AnnouncementCategory,
  AuthProviderType,
  ChapterNote,
  ChapterVideo,
  ClassChangeReport,
  ClassLevel,
  CustomLesson,
  CustomSubject,
  LanguageCode,
  NoteDownloadRecord,
  Quiz,
  QuizAttempt,
  QuizQuestion,
  RecentNoteRecord,
  ReportStatus,
  SavedNoteRecord,
  StudentProfile,
  Subject,
  VideoHistoryRecord,
} from '../types/edutoon';

function toMillis(ts: unknown): number {
  if (ts && typeof ts === 'object' && 'toMillis' in ts && typeof (ts as { toMillis: () => number }).toMillis === 'function') {
    return (ts as { toMillis: () => number }).toMillis();
  }
  return 0;
}

function sanitizeId(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128) || 'item';
}

/**
 * Strictly verifies admin authorization against Firebase Auth server-side Custom Claims
 * or the Firestore `/admins/{uid}` document read from the server (never localStorage or frontend email lists).
 */
export async function verifyServerAdminRole(user: User | null): Promise<boolean> {
  if (!user) return false;
  try {
    const tokenResult = await user.getIdTokenResult(true);
    if (tokenResult.claims.admin === true || tokenResult.claims.role === 'admin') {
      return true;
    }
  } catch {
    // Fall back to server Firestore admin registry lookup below
  }

  try {
    const snap = await getDocFromServer(doc(db, 'admins', user.uid));
    return snap.exists();
  } catch {
    return false;
  }
}

let pendingPreferredStudentName = '';

export function setPendingStudentName(name: string): void {
  pendingPreferredStudentName = name.trim().slice(0, 80);
}

export async function ensureStudentProfile(
  user: User,
  preferredName?: string
): Promise<StudentProfile> {
  const userPath = `users/${user.uid}`;
  const userRef = doc(db, 'users', user.uid);
  const privatePath = `users/${user.uid}/private/contact`;
  const privateRef = doc(db, 'users', user.uid, 'private', 'contact');

  const resolvedPreferred = (preferredName ?? pendingPreferredStudentName).trim().slice(0, 80);
  if (preferredName !== undefined || pendingPreferredStudentName) {
    pendingPreferredStudentName = '';
  }

  try {
    const [existingSnap, existingContactSnap] = await Promise.all([
      getDoc(userRef),
      getDoc(privateRef),
    ]);
    const provider: AuthProviderType = user.phoneNumber ? 'phone' : 'google';
    const nextEmail = (user.email || '').slice(0, 160);
    const nextPhone = (user.phoneNumber || '').slice(0, 32);
    const nextPhoto = (user.photoURL || '').slice(0, 500);

    // Sync isolated PII contact doc only if new or changed
    const currentContact = existingContactSnap.exists()
      ? (existingContactSnap.data() as { email?: string; phoneNumber?: string })
      : null;

    if (
      !currentContact ||
      (nextEmail && currentContact.email !== nextEmail) ||
      (nextPhone && currentContact.phoneNumber !== nextPhone)
    ) {
      const contactPayload = {
        uid: user.uid,
        email: nextEmail || currentContact?.email || '',
        phoneNumber: nextPhone || currentContact?.phoneNumber || '',
        updatedAt: serverTimestamp(),
      };
      await setDoc(privateRef, contactPayload, { merge: true }).catch((err) =>
        handleFirestoreError(err, OperationType.WRITE, privatePath)
      );
    }

    if (existingSnap.exists()) {
      const data = existingSnap.data() as StudentProfile;
      const patch: Record<string, unknown> = {};

      if (
        resolvedPreferred &&
        (!data.displayName || data.displayName === 'Student' || /^Student\s+\d{4}$/.test(data.displayName))
      ) {
        patch.displayName = resolvedPreferred;
      }

      if (nextPhoto && !data.photoURL) {
        patch.photoURL = nextPhoto;
      }

      if (Object.keys(patch).length > 0) {
        patch.updatedAt = serverTimestamp();
        await updateDoc(userRef, patch);
        return { ...data, ...(patch as Partial<StudentProfile>) };
      }

      return data;
    }

    const fallbackName =
      resolvedPreferred ||
      user.displayName?.trim() ||
      user.email?.split('@')[0]?.trim() ||
      'Student';

    const newProfile: StudentProfile = {
      uid: user.uid,
      displayName: fallbackName.slice(0, 80),
      selectedClass: 0,
      classLocked: false,
      academicSession: CURRENT_ACADEMIC_SESSION,
      language: '',
      authProvider: provider,
      photoURL: nextPhoto,
      completedNoteIds: [],
      completedVideoIds: [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    await setDoc(userRef, newProfile);
    const created = await getDoc(userRef);
    return created.data() as StudentProfile;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

export function subscribeStudentProfile(
  uid: string,
  onData: (profile: StudentProfile | null) => void
): Unsubscribe {
  const path = `users/${uid}`;
  return onSnapshot(
    doc(db, 'users', uid),
    (snap) => {
      onData(snap.exists() ? (snap.data() as StudentProfile) : null);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function updateStudentLanguage(uid: string, language: LanguageCode): Promise<void> {
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, 'users', uid), {
      language,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updateStudentDisplayName(uid: string, displayName: string): Promise<void> {
  const path = `users/${uid}`;
  const cleanName = displayName.trim().slice(0, 80);
  if (!cleanName) return;
  try {
    await updateDoc(doc(db, 'users', uid), {
      displayName: cleanName,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function lockInitialStudentClass(
  uid: string,
  selectedClass: ClassLevel
): Promise<void> {
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, 'users', uid), {
      selectedClass,
      classLocked: true,
      academicSession: CURRENT_ACADEMIC_SESSION,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function toggleCompletedNote(
  uid: string,
  noteId: string,
  currentIds: string[]
): Promise<void> {
  const path = `users/${uid}`;
  const exists = currentIds.includes(noteId);
  const nextIds = exists
    ? currentIds.filter((id) => id !== noteId)
    : [...currentIds, sanitizeId(noteId)].slice(0, 200);
  try {
    await updateDoc(doc(db, 'users', uid), {
      completedNoteIds: nextIds,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function toggleCompletedVideo(
  uid: string,
  videoId: string,
  currentIds: string[]
): Promise<void> {
  const path = `users/${uid}`;
  const exists = currentIds.includes(videoId);
  const nextIds = exists
    ? currentIds.filter((id) => id !== videoId)
    : [...currentIds, sanitizeId(videoId)].slice(0, 200);
  try {
    await updateDoc(doc(db, 'users', uid), {
      completedVideoIds: nextIds,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// Saved Notes
export function subscribeSavedNotes(
  uid: string,
  onData: (items: SavedNoteRecord[]) => void
): Unsubscribe {
  const path = `users/${uid}/savedNotes`;
  return onSnapshot(
    collection(db, 'users', uid, 'savedNotes'),
    (snap) => {
      const items = snap.docs.map((d) => d.data() as SavedNoteRecord);
      items.sort((a, b) => toMillis(b.savedAt) - toMillis(a.savedAt));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function saveNoteBookmark(uid: string, note: ChapterNote): Promise<void> {
  const safeNoteId = sanitizeId(note.id);
  const path = `users/${uid}/savedNotes/${safeNoteId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'savedNotes', safeNoteId), {
      uid,
      noteId: safeNoteId,
      subjectId: note.subjectId.slice(0, 64),
      classLevel: note.classLevel,
      language: note.language,
      title: note.title.slice(0, 160),
      chapterNumber: note.chapterNumber,
      savedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function removeSavedNote(uid: string, noteId: string): Promise<void> {
  const safeNoteId = sanitizeId(noteId);
  const path = `users/${uid}/savedNotes/${safeNoteId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'savedNotes', safeNoteId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Downloads
export function subscribeDownloads(
  uid: string,
  onData: (items: NoteDownloadRecord[]) => void
): Unsubscribe {
  const path = `users/${uid}/downloads`;
  return onSnapshot(
    collection(db, 'users', uid, 'downloads'),
    (snap) => {
      const items = snap.docs.map((d) => d.data() as NoteDownloadRecord);
      items.sort((a, b) => toMillis(b.downloadedAt) - toMillis(a.downloadedAt));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function recordNoteDownload(
  uid: string,
  note: ChapterNote,
  fileName: string
): Promise<void> {
  const safeNoteId = sanitizeId(note.id);
  const path = `users/${uid}/downloads/${safeNoteId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'downloads', safeNoteId), {
      uid,
      noteId: safeNoteId,
      subjectId: note.subjectId.slice(0, 64),
      classLevel: note.classLevel,
      language: note.language,
      title: note.title.slice(0, 160),
      chapterNumber: note.chapterNumber,
      fileName: fileName.slice(0, 160),
      downloadedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function removeDownloadRecord(uid: string, noteId: string): Promise<void> {
  const safeNoteId = sanitizeId(noteId);
  const path = `users/${uid}/downloads/${safeNoteId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'downloads', safeNoteId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Recent Notes
export function subscribeRecentNotes(
  uid: string,
  onData: (items: RecentNoteRecord[]) => void
): Unsubscribe {
  const path = `users/${uid}/recentNotes`;
  return onSnapshot(
    collection(db, 'users', uid, 'recentNotes'),
    (snap) => {
      const items = snap.docs.map((d) => d.data() as RecentNoteRecord);
      items.sort((a, b) => toMillis(b.openedAt) - toMillis(a.openedAt));
      onData(items.slice(0, 8));
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function recordRecentNote(uid: string, note: ChapterNote): Promise<void> {
  const safeNoteId = sanitizeId(note.id);
  const path = `users/${uid}/recentNotes/${safeNoteId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'recentNotes', safeNoteId), {
      uid,
      noteId: safeNoteId,
      subjectId: note.subjectId.slice(0, 64),
      classLevel: note.classLevel,
      language: note.language,
      title: note.title.slice(0, 160),
      chapterNumber: note.chapterNumber,
      openedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Video History & Progress
export function subscribeVideoHistory(
  uid: string,
  onData: (items: VideoHistoryRecord[]) => void
): Unsubscribe {
  const path = `users/${uid}/videoHistory`;
  return onSnapshot(
    collection(db, 'users', uid, 'videoHistory'),
    (snap) => {
      const items = snap.docs.map((d) => d.data() as VideoHistoryRecord);
      items.sort((a, b) => toMillis(b.updatedAt) - toMillis(a.updatedAt));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function upsertVideoProgress(
  uid: string,
  video: ChapterVideo,
  progressPercent: number,
  completed: boolean
): Promise<void> {
  const safeVideoId = sanitizeId(video.id);
  const path = `users/${uid}/videoHistory/${safeVideoId}`;
  const clamped = Math.max(0, Math.min(100, Math.round(progressPercent)));
  try {
    const ref = doc(db, 'users', uid, 'videoHistory', safeVideoId);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await updateDoc(ref, {
        progressPercent: clamped,
        completed,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        uid,
        videoId: safeVideoId,
        subjectId: video.subjectId.slice(0, 64),
        classLevel: video.classLevel,
        language: video.language,
        title: video.title.slice(0, 160),
        chapterNumber: video.chapterNumber,
        progressPercent: clamped,
        completed,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Class Change Reports
export function subscribeStudentClassReports(
  uid: string,
  onData: (reports: ClassChangeReport[]) => void
): Unsubscribe {
  const path = 'classChangeReports';
  const q = query(collection(db, 'classChangeReports'), where('studentId', '==', uid));
  return onSnapshot(
    q,
    (snap) => {
      const items = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<ClassChangeReport, 'id'>),
      }));
      items.sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export function subscribeAllClassReportsAdmin(
  onData: (reports: ClassChangeReport[]) => void
): Unsubscribe {
  const path = 'classChangeReports';
  return onSnapshot(
    collection(db, 'classChangeReports'),
    (snap) => {
      const items = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<ClassChangeReport, 'id'>),
      }));
      items.sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function submitClassChangeReport(params: {
  studentId: string;
  studentName: string;
  currentClass: number;
  requestedClass: number;
  reason: string;
}): Promise<void> {
  const path = 'classChangeReports';
  try {
    await addDoc(collection(db, 'classChangeReports'), {
      studentId: params.studentId,
      studentName: params.studentName.trim().slice(0, 80) || 'Student',
      currentClass: params.currentClass,
      requestedClass: params.requestedClass,
      reason: params.reason.trim().slice(0, 500),
      status: 'pending' as ReportStatus,
      adminNote: '',
      reviewedBy: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function reviewClassChangeReport(params: {
  report: ClassChangeReport;
  decision: 'approved' | 'rejected';
  adminNote: string;
  reviewerUid: string;
}): Promise<void> {
  const path = `classChangeReports/${params.report.id}`;
  try {
    const batch = writeBatch(db);
    const reportRef = doc(db, 'classChangeReports', params.report.id);
    batch.update(reportRef, {
      status: params.decision,
      adminNote: params.adminNote.trim().slice(0, 300),
      reviewedBy: params.reviewerUid.slice(0, 128),
      updatedAt: serverTimestamp(),
    });

    if (params.decision === 'approved') {
      const studentRef = doc(db, 'users', params.report.studentId);
      batch.update(studentRef, {
        selectedClass: params.report.requestedClass,
        classLocked: true,
        academicSession: CURRENT_ACADEMIC_SESSION,
        updatedAt: serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// Announcements
export function subscribeAnnouncements(
  classLevel: number,
  isAdminUser: boolean,
  onData: (items: Announcement[]) => void
): Unsubscribe {
  const path = 'announcements';
  const q = isAdminUser
    ? collection(db, 'announcements')
    : classLevel >= 1 && classLevel <= 10
      ? query(collection(db, 'announcements'), where('targetClass', 'in', [0, classLevel]))
      : query(collection(db, 'announcements'), where('targetClass', '==', 0));

  return onSnapshot(
    q,
    (snap) => {
      const items = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<Announcement, 'id'>),
      }));
      items.sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function createAnnouncement(params: {
  title: string;
  body: string;
  category: AnnouncementCategory;
  targetClass: number;
  authorId: string;
  authorName: string;
}): Promise<void> {
  const path = 'announcements';
  try {
    await addDoc(collection(db, 'announcements'), {
      title: params.title.trim().slice(0, 140),
      body: params.body.trim().slice(0, 1500),
      category: params.category,
      targetClass: params.targetClass,
      authorId: params.authorId,
      authorName: params.authorName.trim().slice(0, 80) || 'Admin',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteAnnouncement(id: string): Promise<void> {
  const path = `announcements/${id}`;
  try {
    await deleteDoc(doc(db, 'announcements', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Custom Lessons (Notes & Videos published by Admin)
export function subscribeCustomLessons(
  classLevel: number,
  isAdminUser: boolean,
  onData: (items: CustomLesson[]) => void
): Unsubscribe {
  const path = 'lessons';
  const q = isAdminUser
    ? collection(db, 'lessons')
    : classLevel >= 1 && classLevel <= 10
      ? query(collection(db, 'lessons'), where('classLevel', '==', classLevel))
      : query(collection(db, 'lessons'), where('classLevel', '==', 1));

  return onSnapshot(
    q,
    (snap) => {
      const items = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<CustomLesson, 'id'>),
      }));
      items.sort((a, b) => a.chapterNumber - b.chapterNumber);
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function createCustomLesson(params: {
  type: 'note' | 'video';
  classLevel: ClassLevel;
  language: LanguageCode;
  subjectId: string;
  chapterNumber: number;
  title: string;
  summary: string;
  content: string;
  durationLabel: string;
  mediaUrl: string;
  authorId: string;
}): Promise<void> {
  const path = 'lessons';
  try {
    await addDoc(collection(db, 'lessons'), {
      type: params.type,
      classLevel: params.classLevel,
      language: params.language,
      subjectId: params.subjectId.slice(0, 64),
      chapterNumber: Math.max(1, Math.min(50, params.chapterNumber)),
      title: params.title.trim().slice(0, 160),
      summary: params.summary.trim().slice(0, 400),
      content: params.content.trim().slice(0, 6000),
      durationLabel: params.durationLabel.trim().slice(0, 40),
      mediaUrl: params.mediaUrl.trim().slice(0, 500),
      authorId: params.authorId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteCustomLesson(id: string): Promise<void> {
  const path = `lessons/${id}`;
  try {
    await deleteDoc(doc(db, 'lessons', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Custom Subjects (Admin-managed)
export function subscribeCustomSubjects(
  classLevel: number,
  isAdminUser: boolean,
  onData: (items: CustomSubject[]) => void
): Unsubscribe {
  const path = 'subjects';
  const safeClass = classLevel >= 1 && classLevel <= 10 ? classLevel : 10;
  const q = isAdminUser
    ? collection(db, 'subjects')
    : query(
        collection(db, 'subjects'),
        where('minClass', '>=', 1),
        where('minClass', '<=', safeClass)
      );

  return onSnapshot(
    q,
    (snap) => {
      const items = snap.docs
        .map((d) => ({
          id: d.id,
          ...(d.data() as Omit<CustomSubject, 'id'>),
        }))
        .filter((s) => isAdminUser || (s.minClass <= safeClass && s.maxClass >= safeClass));
      items.sort((a, b) => a.titleEn.localeCompare(b.titleEn));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function createCustomSubject(params: {
  slug: string;
  titleEn: string;
  titleHi: string;
  descriptionEn: string;
  descriptionHi: string;
  minClass: number;
  maxClass: number;
  accentHex: string;
  iconKey: Subject['iconKey'];
  authorId: string;
}): Promise<void> {
  const path = 'subjects';
  const cleanSlug = params.slug
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '_')
    .slice(0, 64);
  const minCls = Math.max(1, Math.min(10, Math.round(params.minClass)));
  const maxCls = Math.max(minCls, Math.min(10, Math.round(params.maxClass)));
  try {
    await addDoc(collection(db, 'subjects'), {
      slug: cleanSlug || 'subject',
      titleEn: params.titleEn.trim().slice(0, 80),
      titleHi: params.titleHi.trim().slice(0, 80),
      descriptionEn: params.descriptionEn.trim().slice(0, 200),
      descriptionHi: params.descriptionHi.trim().slice(0, 200),
      minClass: minCls,
      maxClass: maxCls,
      accentHex: /^#[0-9A-Fa-f]{6}$/.test(params.accentHex) ? params.accentHex : '#0284C7',
      iconKey: params.iconKey,
      authorId: params.authorId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteCustomSubject(id: string): Promise<void> {
  const path = `subjects/${id}`;
  try {
    await deleteDoc(doc(db, 'subjects', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Admin students directory
export function subscribeAllStudentsAdmin(
  onData: (students: StudentProfile[]) => void
): Unsubscribe {
  const path = 'users';
  return onSnapshot(
    collection(db, 'users'),
    (snap) => {
      const items = snap.docs.map((d) => d.data() as StudentProfile);
      items.sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

// Firebase Storage real file upload for PDFs & Videos
export async function uploadEduToonFile(
  file: File,
  folder: 'notes' | 'videos',
  classLevel: ClassLevel,
  onProgress?: (percent: number) => void
): Promise<string> {
  const safeFileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80)}`;
  const targetRef = storageRef(storage, `edutoon/${folder}/class_${classLevel}/${safeFileName}`);

  return new Promise((resolve, reject) => {
    const uploadTask = uploadBytesResumable(targetRef, file, {
      contentType: file.type || (folder === 'notes' ? 'application/pdf' : 'video/mp4'),
    });

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        if (snapshot.totalBytes > 0 && onProgress) {
          onProgress(Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100));
        }
      },
      (error) => {
        reject(error);
      },
      async () => {
        try {
          const url = await getDownloadURL(uploadTask.snapshot.ref);
          resolve(url);
        } catch (err) {
          reject(err);
        }
      }
    );
  });
}

// Interactive Quizzes (Admin-created)
export function subscribeQuizzes(
  classLevel: number,
  isAdminUser: boolean,
  onData: (items: Quiz[]) => void
): Unsubscribe {
  const path = 'quizzes';
  const q = isAdminUser
    ? collection(db, 'quizzes')
    : classLevel >= 1 && classLevel <= 10
      ? query(collection(db, 'quizzes'), where('classLevel', '==', classLevel))
      : query(collection(db, 'quizzes'), where('classLevel', '==', 1));

  return onSnapshot(
    q,
    (snap) => {
      const items = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<Quiz, 'id'>),
      }));
      items.sort((a, b) => a.chapterNumber - b.chapterNumber);
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function createQuiz(params: {
  classLevel: ClassLevel;
  language: LanguageCode;
  subjectId: string;
  chapterNumber: number;
  title: string;
  description: string;
  timeLimitMinutes: number;
  questions: QuizQuestion[];
  authorId: string;
}): Promise<void> {
  const path = 'quizzes';
  const cleanQuestions = params.questions.slice(0, 20).map((q, idx) => ({
    id: sanitizeId(q.id || `q_${idx + 1}`),
    prompt: q.prompt.trim().slice(0, 300),
    options: [
      q.options[0].trim().slice(0, 160) || 'Option A',
      q.options[1].trim().slice(0, 160) || 'Option B',
      q.options[2].trim().slice(0, 160) || 'Option C',
      q.options[3].trim().slice(0, 160) || 'Option D',
    ] as [string, string, string, string],
    correctIndex: q.correctIndex,
    explanation: q.explanation.trim().slice(0, 400),
  }));

  try {
    await addDoc(collection(db, 'quizzes'), {
      classLevel: params.classLevel,
      language: params.language,
      subjectId: params.subjectId.slice(0, 64),
      chapterNumber: Math.max(1, Math.min(50, params.chapterNumber)),
      title: params.title.trim().slice(0, 160),
      description: params.description.trim().slice(0, 400),
      timeLimitMinutes: Math.max(1, Math.min(120, Math.round(params.timeLimitMinutes))),
      questions: cleanQuestions,
      authorId: params.authorId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteQuiz(id: string): Promise<void> {
  const path = `quizzes/${id}`;
  try {
    await deleteDoc(doc(db, 'quizzes', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Student Quiz Attempts
export function subscribeStudentQuizAttempts(
  uid: string,
  onData: (attempts: QuizAttempt[]) => void
): Unsubscribe {
  const path = 'quizAttempts';
  const q = query(collection(db, 'quizAttempts'), where('studentId', '==', uid));
  return onSnapshot(
    q,
    (snap) => {
      const items = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<QuizAttempt, 'id'>),
      }));
      items.sort((a, b) => toMillis(b.updatedAt) - toMillis(a.updatedAt));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export function subscribeAllQuizAttemptsAdmin(
  onData: (attempts: QuizAttempt[]) => void
): Unsubscribe {
  const path = 'quizAttempts';
  return onSnapshot(
    collection(db, 'quizAttempts'),
    (snap) => {
      const items = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<QuizAttempt, 'id'>),
      }));
      items.sort((a, b) => toMillis(b.updatedAt) - toMillis(a.updatedAt));
      onData(items);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, path)
  );
}

export async function saveQuizAttempt(params: {
  studentId: string;
  quiz: Quiz;
  score: number;
}): Promise<void> {
  const safeQuizId = sanitizeId(params.quiz.id);
  const safeAttemptId = sanitizeId(`${params.studentId}_${safeQuizId}`);
  const path = `quizAttempts/${safeAttemptId}`;
  const totalQuestions = Math.max(1, Math.min(20, params.quiz.questions.length));
  const clampedScore = Math.max(0, Math.min(totalQuestions, Math.round(params.score)));
  const percentage = Math.round((clampedScore / totalQuestions) * 100);

  try {
    const attemptRef = doc(db, 'quizAttempts', safeAttemptId);
    const snap = await getDoc(attemptRef);
    if (snap.exists()) {
      await updateDoc(attemptRef, {
        score: clampedScore,
        totalQuestions,
        percentage,
        quizTitle: params.quiz.title.slice(0, 160),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(attemptRef, {
        studentId: params.studentId,
        quizId: safeQuizId,
        quizTitle: params.quiz.title.slice(0, 160),
        subjectId: params.quiz.subjectId.slice(0, 64),
        classLevel: params.quiz.classLevel,
        score: clampedScore,
        totalQuestions,
        percentage,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}
