import JSZip from 'jszip';

/**
 * Service to generate and trigger the download of a self-contained, standalone offline HTML game
 * or a compressed ZIP package with index.html, save file, and user guide.
 */

export function downloadOfflineGameHtml(currentGameState: any) {
  const jsonState = JSON.stringify(currentGameState).replace(/</g, '\\u003c');

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Amazing Sect Cultivation - Offline Edition</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; user-select: none; -webkit-tap-highlight-color: transparent; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #0b261d;
      color: #e8f1eb;
      min-height: 100vh;
      overflow-x: hidden;
    }
    .header-bar {
      background: #09261d;
      border-bottom: 2px solid rgba(226, 176, 84, 0.3);
      padding: 10px 14px;
      position: sticky;
      top: 0;
      z-index: 50;
    }
    .res-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-top: 8px;
    }
    .res-card {
      background: #f9f5ea;
      color: #1a3026;
      border-radius: 12px;
      padding: 10px 12px;
      border: 1px solid #eedec4;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .res-title {
      font-size: 11px;
      font-weight: 700;
      color: #3b5247;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .res-val {
      font-size: 18px;
      font-weight: 800;
      margin-top: 2px;
      font-family: monospace;
      color: #0f2b20;
    }
    .res-bar {
      height: 4px;
      background: #dcd4c0;
      border-radius: 99px;
      margin-top: 6px;
      overflow: hidden;
    }
    .res-bar-fill {
      height: 100%;
      background: #1d7355;
      width: 70%;
    }
    .sub-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 8px;
      background: rgba(18, 61, 48, 0.7);
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 11px;
      color: #fce18b;
      border: 1px solid rgba(226, 176, 84, 0.2);
    }
    .nav-bar {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background: #071f17;
      border-top: 1px solid rgba(226, 176, 84, 0.3);
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      z-index: 50;
      padding: 6px 4px;
    }
    .nav-btn {
      background: none;
      border: none;
      color: #a4c2b5;
      font-size: 10px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 3px;
      cursor: pointer;
      padding: 6px 2px;
      border-radius: 8px;
    }
    .nav-btn.active {
      color: #fce18b;
      background: rgba(226, 176, 84, 0.15);
      font-weight: bold;
    }
    .content-area {
      padding: 14px;
      padding-bottom: 80px;
      max-width: 600px;
      margin: 0 auto;
    }
    .card {
      background: #f9f5ea;
      color: #183327;
      border-radius: 16px;
      padding: 14px;
      margin-bottom: 12px;
      border: 1px solid #e2b054;
      box-shadow: 0 4px 15px rgba(0,0,0,0.25);
    }
    .btn {
      background: #123d30;
      color: #fce18b;
      border: 1px solid #e2b054;
      padding: 8px 14px;
      border-radius: 10px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: all 0.15s ease;
    }
    .btn:active {
      transform: scale(0.97);
    }
    .btn-gold {
      background: #e2b054;
      color: #0b261d;
      border: none;
    }
    .action-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-top: 12px;
    }
    .disciple-card {
      background: rgba(18, 61, 48, 0.7);
      border: 1px solid rgba(226, 176, 84, 0.3);
      border-radius: 14px;
      padding: 12px;
      margin-bottom: 10px;
      color: #e8f1eb;
    }
    .tag {
      font-size: 9px;
      padding: 2px 6px;
      border-radius: 4px;
      background: rgba(226, 176, 84, 0.2);
      color: #fce18b;
      border: 1px solid rgba(226, 176, 84, 0.3);
    }
    .modal-overlay {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.75);
      backdrop-filter: blur(4px);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 100;
      padding: 16px;
    }
  </style>
</head>
<body>
  <div class="header-bar">
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <div style="font-weight: 800; color: #fce18b; font-size: 16px; display: flex; align-items: center; gap: 6px;">
        <span>☯</span> <span>Extreme World</span>
      </div>
      <div style="display: flex; gap: 6px; font-size: 11px;">
        <span style="color: #a4c2b5;" id="headerTime">Year 126 · Autumn</span>
        <button class="btn" style="padding: 3px 8px; font-size: 10px;" onclick="toggleAudio()">🎵 Sound</button>
      </div>
    </div>

    <div class="res-grid">
      <div class="res-card">
        <div class="res-title"><span>💎 Spirit Stones</span> <span style="color: #1d7355;" id="rateStones">+17/s</span></div>
        <div class="res-val" id="valStones">5.1B</div>
        <div class="res-bar"><div class="res-bar-fill" style="width: 80%;"></div></div>
      </div>
      <div class="res-card">
        <div class="res-title"><span>🟢 Qi</span> <span style="color: #1d7355;" id="rateQi">+23/s</span></div>
        <div class="res-val" id="valQi">6.2B</div>
        <div class="res-bar"><div class="res-bar-fill" style="width: 65%; background: #2f9e44;"></div></div>
      </div>
      <div class="res-card">
        <div class="res-title"><span>🧪 Pills</span> <span style="color: #1d7355;" id="ratePills">+3/s</span></div>
        <div class="res-val" id="valPills">3.0B</div>
        <div class="res-bar"><div class="res-bar-fill" style="width: 50%; background: #0ca678;"></div></div>
      </div>
      <div class="res-card">
        <div class="res-title"><span>📜 Merit</span> <span style="color: #8c733e;" id="rateMerit">+0/s</span></div>
        <div class="res-val" id="valMerit">40.2M</div>
        <div class="res-bar"><div class="res-bar-fill" style="width: 40%; background: #e2b054;"></div></div>
      </div>
    </div>

    <div class="sub-bar">
      <span>☯ Mystic Daoist Temple</span>
      <span style="color: #fce18b;">⭐ 413.1K Prestige</span>
      <span>☯ Steady</span>
      <span>⚖️ Neutral</span>
    </div>
  </div>

  <div class="content-area" id="mainContainer">
    <!-- Tab content populated via script -->
  </div>

  <div class="nav-bar">
    <button class="nav-btn active" onclick="switchTab('sect')" id="tabBtn-sect"><span>🏯</span><span>Sect</span></button>
    <button class="nav-btn" onclick="switchTab('overview')" id="tabBtn-overview"><span>📈</span><span>Overview</span></button>
    <button class="nav-btn" onclick="switchTab('buildings')" id="tabBtn-buildings"><span>🏛️</span><span>Buildings</span></button>
    <button class="nav-btn" onclick="switchTab('disciples')" id="tabBtn-disciples"><span>🧙</span><span>Disciples</span></button>
    <button class="nav-btn" onclick="switchTab('chronicle')" id="tabBtn-chronicle"><span>📜</span><span>Chronicle</span></button>
  </div>

  <div class="modal-overlay" id="modalOverlay" onclick="closeModal(event)">
    <div class="card" style="max-width: 450px; width: 100%; margin: 0 auto;" onclick="event.stopPropagation()">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
        <h3 id="modalTitle" style="color: #0f2b20;">Modal</h3>
        <button onclick="closeModal()" style="background: none; border: none; font-size: 16px; cursor: pointer;">✕</button>
      </div>
      <div id="modalBody" style="font-size: 12px; color: #2d4538; line-height: 1.5;"></div>
    </div>
  </div>

  <script>
    const INITIAL_STATE = ${jsonState};
    let state = JSON.parse(localStorage.getItem('amazing_cultivation_save') || JSON.stringify(INITIAL_STATE));

    function saveGame() {
      localStorage.setItem('amazing_cultivation_save', JSON.stringify(state));
    }

    function formatNumber(num) {
      if (num >= 1e9) return (num / 1e9).toFixed(1) + 'B';
      if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
      if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
      return Math.floor(num).toLocaleString();
    }

    function updateHUD() {
      document.getElementById('valStones').innerText = formatNumber(state.resources.spiritStones);
      document.getElementById('valQi').innerText = formatNumber(state.resources.qi);
      document.getElementById('valPills').innerText = formatNumber(state.resources.pills);
      document.getElementById('valMerit').innerText = formatNumber(state.resources.merit);
      document.getElementById('headerTime').innerText = 'Year ' + state.year + ' · ' + state.season;
    }

    let currentTab = 'sect';

    function switchTab(tab) {
      currentTab = tab;
      document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
      document.getElementById('tabBtn-' + tab).classList.add('active');
      renderTab();
    }

    function renderTab() {
      const container = document.getElementById('mainContainer');
      if (currentTab === 'sect') {
        container.innerHTML = \`
          <div class="card">
            <h3 style="color: #0b261d; margin-bottom: 4px;">Sect Sovereign Chambers</h3>
            <p style="font-size: 11px; color: #3d564b;">Manage disciples, dispatch expeditions, trade with traveling merchants, and lead the sect to immortality.</p>
            <div style="margin-top: 10px;">
              <button class="btn btn-gold" style="width: 100%;" onclick="openMerchant()">💼 Visit Traveling Merchant</button>
            </div>
          </div>

          <div class="card">
            <h4 style="color: #0b261d; margin-bottom: 8px;">Sect Actions</h4>
            <div class="action-grid">
              <button class="btn" onclick="actionRecruit()">🎓 Recruit Disciple</button>
              <button class="btn" onclick="actionTrainAll()">🥋 Train All Disciples</button>
              <button class="btn" onclick="actionMeditate()">🧘 Meditate (Gather Qi)</button>
              <button class="btn" onclick="actionExpedition()">⚔️ Expeditions</button>
              <button class="btn" onclick="actionDiplomacy()">🤝 Sect Diplomacy</button>
              <button class="btn" onclick="actionAdvanceSeason()">🌙 Advance Season</button>
            </div>
          </div>
        \`;
      } else if (currentTab === 'disciples') {
        let discHtml = state.disciples.map((d, idx) => \`
          <div class="disciple-card">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <strong style="color: #fce18b; font-size: 14px;">\${d.name}</strong>
                <span class="tag" style="margin-left: 6px;">\${d.rank}</span>
                <span class="tag">\${d.status}</span>
              </div>
              <span style="font-size: 11px; color: #a4c2b5;">Combat: \${formatNumber(d.combatPower)}</span>
            </div>
            <div style="font-size: 11px; margin-top: 6px; color: #cbe3d7;">
              <span>Root: \${d.spiritRoot} (\${d.spiritRootPurity})</span> ·
              <span>Physique: \${d.constitution}</span>
            </div>
            <div style="display: flex; gap: 6px; margin-top: 8px;">
              <button class="btn" style="padding: 4px 8px; font-size: 10px;" onclick="breakthroughDisciple(\${idx})">Breakthrough</button>
              <button class="btn" style="padding: 4px 8px; font-size: 10px;" onclick="deepenBond(\${idx})">Deepen Bond</button>
              <button class="btn" style="padding: 4px 8px; font-size: 10px;" onclick="promoteDisciple(\${idx})">Promote</button>
            </div>
          </div>
        \`).join('');

        container.innerHTML = \`
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <span style="font-weight: 700; color: #fce18b;">Disciples (\${state.disciples.length}/26)</span>
            <button class="btn btn-gold" style="font-size: 10px; padding: 4px 10px;" onclick="promoteAllDisciples()">Promote All</button>
          </div>
          \${discHtml}
        \`;
      } else if (currentTab === 'buildings') {
        let bldHtml = state.buildings.map((b, idx) => \`
          <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <strong style="color: #0b261d; font-size: 13px;">\${b.name} (Lv \${b.level})</strong>
              <button class="btn btn-gold" style="padding: 4px 10px; font-size: 10px;" onclick="upgradeBuilding(\${idx})">Upgrade</button>
            </div>
            <p style="font-size: 11px; color: #3a5247; margin-top: 4px;">\${b.effectDescription}</p>
          </div>
        \`).join('');
        container.innerHTML = bldHtml;
      } else if (currentTab === 'overview') {
        container.innerHTML = \`
          <div class="card">
            <h3 style="color: #0b261d;">Sect Analytics Breakdown</h3>
            <p style="font-size: 11px; color: #3d564b; margin-top: 4px;">Current Season: \${state.season}, Year \${state.year}</p>
            <div style="margin-top: 12px; font-size: 12px; line-height: 1.8;">
              <div>💎 Spirit Stone Output: +17/s</div>
              <div>🟢 Qi Convergence: +23/s</div>
              <div>🧪 Pill Yield: +3/s</div>
              <div>📜 Sect Merit: +0/s</div>
              <div>⭐ Total Sect Prestige: 413.1K</div>
              <div>☯ Heavenly Karma: Steady</div>
            </div>
          </div>
        \`;
      } else if (currentTab === 'chronicle') {
        let eventsHtml = state.chronicleEvents.map(e => \`
          <div style="background: rgba(18, 61, 48, 0.7); border-radius: 10px; padding: 8px 10px; margin-bottom: 8px; border: 1px solid rgba(226, 176, 84, 0.2);">
            <div style="color: #fce18b; font-size: 11px; font-weight: bold;">\${e.title}</div>
            <div style="color: #a4c2b5; font-size: 10px; margin-top: 2px;">\${e.details}</div>
          </div>
        \`).join('');
        container.innerHTML = \`
          <div class="card"><h3 style="color: #0b261d;">Sect Chronicles & History</h3></div>
          \${eventsHtml}
        \`;
      }
    }

    function openModal(title, bodyHtml) {
      document.getElementById('modalTitle').innerText = title;
      document.getElementById('modalBody').innerHTML = bodyHtml;
      document.getElementById('modalOverlay').style.display = 'flex';
    }

    function closeModal() {
      document.getElementById('modalOverlay').style.display = 'none';
    }

    function actionRecruit() {
      const names = ['Fang Yuan', 'Gu Yue', 'Lin Dong', 'Bai Xiaochun', 'Han Li', 'Meng Hao'];
      const newD = {
        name: names[Math.floor(Math.random() * names.length)],
        rank: 'Outer',
        status: 'Idle',
        spiritRoot: 'Fire',
        spiritRootPurity: 'True Root',
        constitution: 'Mortal Bone',
        combatPower: 850,
        relations: []
      };
      state.disciples.push(newD);
      state.resources.spiritStones = Math.max(0, state.resources.spiritStones - 50000);
      saveGame();
      updateHUD();
      renderTab();
      openModal("Disciple Recruited! 🎓", \`<strong>\${newD.name}</strong> has passed the Mountain Entrance Trial and entered the Sect as an Outer Disciple!\`);
    }

    function actionTrainAll() {
      state.resources.qi = Math.max(0, state.resources.qi - 500000);
      state.disciples.forEach(d => {
        d.combatPower += 150;
      });
      saveGame();
      updateHUD();
      renderTab();
      openModal("Sect Sermon Completed 🥋", "You conducted a Grand Dao Sermon! Disciples meditated upon the Heavenly Dao, consuming Qi and boosting combat power.");
    }

    function actionMeditate() {
      state.resources.qi += 250000;
      updateHUD();
      openModal("Breathed Heaven and Earth Qi 🧘", "The Sect Master communed with the spiritual leyline, infusing +250,000 Qi into the sect reservoir!");
    }

    function actionAdvanceSeason() {
      const seasons = ['Spring', 'Summer', 'Autumn', 'Winter'];
      let idx = seasons.indexOf(state.season);
      idx = (idx + 1) % 4;
      if (idx === 0) state.year++;
      state.season = seasons[idx];
      saveGame();
      updateHUD();
      renderTab();
      openModal("Season Advanced 🌙", \`The wheel of time turns. It is now <strong>\${state.season}, Year \${state.year}</strong>. Spirit veins surge with fresh vitality!\`);
    }

    function actionExpedition() {
      openModal("Secret Realm Expedition ⚔️", "Dispatched vanguard team into the Ancient Immortal Cave. Loot recovered: +85,000 Spirit Stones, +45 Pills, +120 Merit!");
      state.resources.spiritStones += 85000;
      state.resources.pills += 45;
      state.resources.merit += 120;
      saveGame();
      updateHUD();
    }

    function actionDiplomacy() {
      openModal("Sect Diplomacy 🤝", "Received emissaries from Heavenly Sword Sect and Myriad Pill Pavilion. Sect relations remain harmonious. +200 Merit received!");
      state.resources.merit += 200;
      saveGame();
      updateHUD();
    }

    function openMerchant() {
      openModal("Traveling Merchant Bao 💼", "Bao's Immortal Pavilion has arrived! Rare Dao pills, lightning warding talismans, and longevity fruits available.");
    }

    function breakthroughDisciple(idx) {
      const d = state.disciples[idx];
      d.combatPower += 800;
      saveGame();
      renderTab();
      openModal("Breakthrough Success! ⚡", \`<strong>\${d.name}</strong> shattered their bottleneck and stepped into a higher cultivation realm! (+800 Combat Power)\`);
    }

    function deepenBond(idx) {
      const d = state.disciples[idx];
      openModal("Deepened Dao Bond 🌸", \`You held a private Dao conversation with <strong>\${d.name}</strong>. Their loyalty and morale have ascended to the peak!\`);
    }

    function promoteDisciple(idx) {
      const d = state.disciples[idx];
      if (d.rank === 'Outer') d.rank = 'Inner';
      else if (d.rank === 'Inner') d.rank = 'Direct';
      else if (d.rank === 'Direct') d.rank = 'Elder';
      saveGame();
      renderTab();
      openModal("Disciple Promoted 🏯", \`<strong>\${d.name}</strong> has been elevated to <strong>\${d.rank}</strong>! Other disciples acknowledge their divine merit.\`);
    }

    function promoteAllDisciples() {
      state.disciples.forEach(d => {
        if (d.rank === 'Outer') d.rank = 'Inner';
      });
      saveGame();
      renderTab();
      openModal("Promote All 🏯", "Evaluated all Outer disciples with sufficient merit and elevated them to Inner disciples!");
    }

    function upgradeBuilding(idx) {
      const b = state.buildings[idx];
      b.level++;
      state.resources.spiritStones = Math.max(0, state.resources.spiritStones - 200000);
      saveGame();
      updateHUD();
      renderTab();
      openModal("Building Upgraded 🏛️", \`Upgraded <strong>\${b.name}</strong> to Level \${b.level}!\`);
    }

    // Audio synthesizer for offline single file
    let audioCtx = null;
    let audioActive = false;
    function toggleAudio() {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      audioActive = !audioActive;
      if (audioActive) {
        playTone(523.25);
        setTimeout(() => playTone(659.25), 150);
      }
    }
    function playTone(freq) {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.4);
    }

    // Passive game tick
    setInterval(() => {
      state.resources.spiritStones += 17;
      state.resources.qi += 23;
      state.resources.pills += 3;
      updateHUD();
    }, 1000);

    // Initial load
    updateHUD();
    renderTab();
  </script>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'Amazing-Sect-Cultivation-Offline.html';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

export async function downloadCompressedOfflinePackage(currentGameState: any) {
  const zip = new JSZip();

  const jsonState = JSON.stringify(currentGameState, null, 2);
  const escapedState = JSON.stringify(currentGameState).replace(/</g, '\\u003c');

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Amazing Sect Cultivation - Standalone Offline</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; user-select: none; -webkit-tap-highlight-color: transparent; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0b261d; color: #e8f1eb; min-height: 100vh; overflow-x: hidden; }
    .header-bar { background: #09261d; border-bottom: 2px solid rgba(226, 176, 84, 0.3); padding: 10px 14px; position: sticky; top: 0; z-index: 50; }
    .res-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 8px; }
    .res-card { background: #f9f5ea; color: #1a3026; border-radius: 12px; padding: 10px 12px; border: 1px solid #eedec4; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .res-title { font-size: 11px; font-weight: 700; color: #3b5247; display: flex; justify-content: space-between; align-items: center; }
    .res-val { font-size: 18px; font-weight: 800; margin-top: 2px; font-family: monospace; color: #0f2b20; }
    .nav-bar { position: fixed; bottom: 0; left: 0; right: 0; background: #071f17; border-top: 1px solid rgba(226, 176, 84, 0.3); display: grid; grid-template-columns: repeat(5, 1fr); z-index: 50; padding: 6px 4px; }
    .nav-btn { background: none; border: none; color: #a4c2b5; font-size: 10px; display: flex; flex-direction: column; align-items: center; gap: 3px; cursor: pointer; padding: 6px 2px; border-radius: 8px; }
    .nav-btn.active { color: #fce18b; background: rgba(226, 176, 84, 0.15); font-weight: bold; }
    .content-area { padding: 14px; padding-bottom: 80px; max-width: 600px; margin: 0 auto; }
    .card { background: #f9f5ea; color: #183327; border-radius: 16px; padding: 14px; margin-bottom: 12px; border: 1px solid #e2b054; box-shadow: 0 4px 15px rgba(0,0,0,0.25); }
    .btn { background: #123d30; color: #fce18b; border: 1px solid #e2b054; padding: 8px 14px; border-radius: 10px; font-size: 12px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px; }
    .btn-gold { background: #e2b054; color: #0b261d; border: none; }
    .action-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 12px; }
    .disciple-card { background: rgba(18, 61, 48, 0.7); border: 1px solid rgba(226, 176, 84, 0.3); border-radius: 14px; padding: 12px; margin-bottom: 10px; color: #e8f1eb; }
    .tag { font-size: 9px; padding: 2px 6px; border-radius: 4px; background: rgba(226, 176, 84, 0.2); color: #fce18b; border: 1px solid rgba(226, 176, 84, 0.3); }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.75); backdrop-filter: blur(4px); display: none; align-items: center; justify-content: center; z-index: 100; padding: 16px; }
  </style>
</head>
<body>
  <div class="header-bar">
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <div style="font-weight: 800; color: #fce18b; font-size: 16px; display: flex; align-items: center; gap: 6px;">
        <span>☯</span> <span>Extreme World</span>
      </div>
      <div style="display: flex; gap: 6px; font-size: 11px;">
        <span style="color: #a4c2b5;" id="headerTime">Year 126 · Autumn</span>
      </div>
    </div>
    <div class="res-grid">
      <div class="res-card"><div class="res-title"><span>💎 Spirit Stones</span> <span id="rateStones">+17/s</span></div><div class="res-val" id="valStones">5.1B</div></div>
      <div class="res-card"><div class="res-title"><span>🟢 Qi</span> <span id="rateQi">+23/s</span></div><div class="res-val" id="valQi">6.2B</div></div>
      <div class="res-card"><div class="res-title"><span>🧪 Pills</span> <span id="ratePills">+3/s</span></div><div class="res-val" id="valPills">3.0B</div></div>
      <div class="res-card"><div class="res-title"><span>📜 Merit</span> <span id="rateMerit">+0/s</span></div><div class="res-val" id="valMerit">40.2M</div></div>
    </div>
  </div>
  <div class="content-area" id="mainContainer"></div>
  <div class="nav-bar">
    <button class="nav-btn active" onclick="switchTab('sect')" id="tabBtn-sect"><span>🏯</span><span>Sect</span></button>
    <button class="nav-btn" onclick="switchTab('overview')" id="tabBtn-overview"><span>📈</span><span>Overview</span></button>
    <button class="nav-btn" onclick="switchTab('buildings')" id="tabBtn-buildings"><span>🏛️</span><span>Buildings</span></button>
    <button class="nav-btn" onclick="switchTab('disciples')" id="tabBtn-disciples"><span>🧙</span><span>Disciples</span></button>
    <button class="nav-btn" onclick="switchTab('chronicle')" id="tabBtn-chronicle"><span>📜</span><span>Chronicle</span></button>
  </div>
  <div class="modal-overlay" id="modalOverlay" onclick="closeModal(event)">
    <div class="card" style="max-width: 450px; width: 100%; margin: 0 auto;" onclick="event.stopPropagation()">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
        <h3 id="modalTitle" style="color: #0f2b20;">Modal</h3>
        <button onclick="closeModal()" style="background: none; border: none; font-size: 16px; cursor: pointer;">✕</button>
      </div>
      <div id="modalBody" style="font-size: 12px; color: #2d4538; line-height: 1.5;"></div>
    </div>
  </div>
  <script>
    const INITIAL_STATE = ${escapedState};
    let state = JSON.parse(localStorage.getItem('amazing_cultivation_save') || JSON.stringify(INITIAL_STATE));
    function saveGame() { localStorage.setItem('amazing_cultivation_save', JSON.stringify(state)); }
    function formatNumber(num) {
      if (num >= 1e9) return (num / 1e9).toFixed(1) + 'B';
      if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
      if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
      return Math.floor(num).toLocaleString();
    }
    function updateHUD() {
      document.getElementById('valStones').innerText = formatNumber(state.resources.spiritStones);
      document.getElementById('valQi').innerText = formatNumber(state.resources.qi);
      document.getElementById('valPills').innerText = formatNumber(state.resources.pills);
      document.getElementById('valMerit').innerText = formatNumber(state.resources.merit);
      document.getElementById('headerTime').innerText = 'Year ' + state.year + ' · ' + state.season;
    }
    let currentTab = 'sect';
    function switchTab(tab) {
      currentTab = tab;
      document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
      document.getElementById('tabBtn-' + tab).classList.add('active');
      renderTab();
    }
    function renderTab() {
      const container = document.getElementById('mainContainer');
      if (currentTab === 'sect') {
        container.innerHTML = \`
          <div class="card">
            <h3 style="color: #0b261d;">Sect Sovereign Chambers</h3>
            <p style="font-size: 11px; color: #3d564b;">Manage disciples, dispatch expeditions, trade with merchants, and lead the sect to immortality.</p>
          </div>
          <div class="card">
            <h4 style="color: #0b261d; margin-bottom: 8px;">Sect Actions</h4>
            <div class="action-grid">
              <button class="btn" onclick="actionRecruit()">🎓 Recruit Disciple</button>
              <button class="btn" onclick="actionTrainAll()">🥋 Train All Disciples</button>
              <button class="btn" onclick="actionMeditate()">🧘 Meditate (Gather Qi)</button>
              <button class="btn" onclick="actionAdvanceSeason()">🌙 Advance Season</button>
            </div>
          </div>
        \`;
      } else if (currentTab === 'disciples') {
        let discHtml = state.disciples.map((d, idx) => \`
          <div class="disciple-card">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div><strong style="color: #fce18b; font-size: 14px;">\${d.name}</strong><span class="tag" style="margin-left: 6px;">\${d.rank}</span></div>
              <span style="font-size: 11px; color: #a4c2b5;">Combat: \${formatNumber(d.combatPower)}</span>
            </div>
            <div style="font-size: 11px; margin-top: 6px; color: #cbe3d7;"><span>Root: \${d.spiritRoot}</span> · <span>Physique: \${d.constitution}</span></div>
          </div>
        \`).join('');
        container.innerHTML = \`<div style="font-weight: 700; color: #fce18b; margin-bottom: 8px;">Disciples (\${state.disciples.length})</div>\` + discHtml;
      } else if (currentTab === 'buildings') {
        let bldHtml = state.buildings.map(b => \`<div class="card"><strong style="color: #0b261d;">\${b.name} (Lv \${b.level})</strong><p style="font-size: 11px; color: #3a5247; margin-top: 4px;">\${b.effectDescription}</p></div>\`).join('');
        container.innerHTML = bldHtml;
      } else if (currentTab === 'overview') {
        container.innerHTML = \`<div class="card"><h3 style="color: #0b261d;">Sect Analytics</h3><p style="font-size: 12px; margin-top: 8px; line-height: 1.8;">Season: \${state.season}, Year \${state.year}<br>Karma: Steady<br>Prestige: \${formatNumber(state.prestige)}</p></div>\`;
      } else if (currentTab === 'chronicle') {
        let eventsHtml = (state.chronicleEvents || []).map(e => \`<div style="background: rgba(18, 61, 48, 0.7); border-radius: 10px; padding: 8px 10px; margin-bottom: 8px;"><div style="color: #fce18b; font-size: 11px; font-weight: bold;">\${e.title}</div><div style="color: #a4c2b5; font-size: 10px;">\${e.details}</div></div>\`).join('');
        container.innerHTML = \`<div class="card"><h3 style="color: #0b261d;">Sect Chronicles</h3></div>\` + eventsHtml;
      }
    }
    function openModal(title, bodyHtml) {
      document.getElementById('modalTitle').innerText = title;
      document.getElementById('modalBody').innerHTML = bodyHtml;
      document.getElementById('modalOverlay').style.display = 'flex';
    }
    function closeModal() { document.getElementById('modalOverlay').style.display = 'none'; }
    function actionRecruit() {
      const names = ['Fang Yuan', 'Gu Yue', 'Lin Dong', 'Bai Xiaochun', 'Han Li'];
      const newD = { name: names[Math.floor(Math.random() * names.length)], rank: 'Outer', status: 'Idle', spiritRoot: 'Fire', combatPower: 850, constitution: 'Mortal Bone', relations: [] };
      state.disciples.push(newD);
      saveGame(); updateHUD(); renderTab();
      openModal("Disciple Recruited! 🎓", \`<strong>\${newD.name}</strong> has passed the Mountain Entrance Trial!\`);
    }
    function actionTrainAll() {
      state.disciples.forEach(d => { d.combatPower += 150; });
      saveGame(); updateHUD(); renderTab();
      openModal("Sect Sermon 🥋", "You conducted a Grand Dao Sermon! Disciples meditated upon the Heavenly Dao.");
    }
    function actionMeditate() {
      state.resources.qi += 250000;
      updateHUD();
      openModal("Breathed Heaven and Earth Qi 🧘", "Communed with the leyline, gaining +250,000 Qi!");
    }
    function actionAdvanceSeason() {
      const seasons = ['Spring', 'Summer', 'Autumn', 'Winter'];
      let idx = seasons.indexOf(state.season);
      idx = (idx + 1) % 4;
      if (idx === 0) state.year++;
      state.season = seasons[idx];
      saveGame(); updateHUD(); renderTab();
      openModal("Season Advanced 🌙", \`It is now <strong>\${state.season}, Year \${state.year}</strong>.\`);
    }
    setInterval(() => {
      state.resources.spiritStones += 17;
      state.resources.qi += 23;
      state.resources.pills += 3;
      updateHUD();
    }, 1000);
    updateHUD();
    renderTab();
  </script>
</body>
</html>`;

  zip.file("index.html", htmlContent);
  zip.file("save_backup.json", jsonState);
  zip.file("README.txt", `Amazing Sect Cultivation - Offline Application Package
======================================================
1. Double click 'index.html' to open and play the full offline game in any web browser.
2. No internet connection or installation required.
3. Your sect progress is saved locally in browser storage.
4. 'save_backup.json' contains your complete save archive.`);

  const content = await zip.generateAsync({ type: "blob" });
  const url = URL.createObjectURL(content);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'Amazing-Sect-Cultivation-Offline-Package.zip';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
