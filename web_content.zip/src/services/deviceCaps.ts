import type { DeviceCaps } from '../core/types';
function webgl2Available(){ const c=document.createElement('canvas'); return Boolean(c.getContext('webgl2')); }
function maxTextureSize(){ const c=document.createElement('canvas'); const gl=c.getContext('webgl2') as WebGL2RenderingContext|null; return gl?Number(gl.getParameter(gl.MAX_TEXTURE_SIZE)):0; }
export function detectDeviceCaps():DeviceCaps{
  const nav=navigator as Navigator & {deviceMemory?:number};
  const memoryGB=nav.deviceMemory ?? null;
  const hardwareConcurrency=navigator.hardwareConcurrency||4;
  const supportsWebGL2=webgl2Available();
  const supportsWebGPU='gpu' in navigator;
  const supportsWebCodecs='VideoEncoder' in globalThis && 'VideoDecoder' in globalThis;
  const score=(memoryGB??4)*2+hardwareConcurrency+(supportsWebGL2?4:0)+(supportsWebGPU?4:0)+(supportsWebCodecs?3:0);
  const tier=score<12?'low':score<21?'balanced':'high';
  return {memoryGB,hardwareConcurrency,maxTextureSize:maxTextureSize(),supportsWebGL2,supportsWebGPU,supportsWebCodecs,tier};
}
export function supportedFps(caps:DeviceCaps){ const all=[20,24,25,30,40,50,60,90,120,144]; return caps.tier==='low'?all.filter(x=>x<=60):caps.tier==='balanced'?all.filter(x=>x<=120):all; }
export function supportedResolutions(caps:DeviceCaps){
  if(caps.tier==='low') return [{label:'720p',width:1280,height:720}];
  if(caps.tier==='balanced') return [{label:'720p',width:1280,height:720},{label:'1080p',width:1920,height:1080}];
  return [{label:'720p',width:1280,height:720},{label:'1080p',width:1920,height:1080},{label:'1440p',width:2560,height:1440}];
}
