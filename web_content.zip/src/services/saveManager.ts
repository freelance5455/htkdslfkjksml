import { GameSettings, PlayerStats } from '../types';

const STATS_STORAGE_KEY = 'arrowscape_player_stats_v1';
const SETTINGS_STORAGE_KEY = 'arrowscape_settings_v1';

export const DEFAULT_SETTINGS: GameSettings = {
  soundEnabled: true,
  musicEnabled: false,
  voiceEnabled: true,
  vibrationEnabled: true,
  language: 'en',
  hapticsSupported: typeof window !== 'undefined' && 'vibrate' in navigator,
};

export const DEFAULT_STATS: PlayerStats = {
  coins: 150, // Starting player reward
  hintsRemaining: 3,
  undosRemaining: 5,
  unlockedWorlds: [1], // World 1 unlocked by default
  highestShortArrowLevel: 1,
  highestLongArrowLevel: 1,
  completedShortLevels: {},
  completedLongLevels: {},
  highestUnlockedLevel: 1, // legacy alias
  completedLevels: {}, // legacy alias
  equippedArrowSkin: 'black',
  equippedBoardTheme: 'slate',
  equippedParticle: 'sparkles',
  unlockedSkins: ['black'],
  unlockedThemes: ['slate'],
  unlockedParticles: ['sparkles'],
  lastDailyRewardDate: null,
  dailyRewardStreak: 0,
};

class SaveManager {
  public loadSettings(): GameSettings {
    if (typeof window === 'undefined') return DEFAULT_SETTINGS;
    try {
      const data = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        const validLanguages = ['en', 'hi', 'bn'];
        const language = validLanguages.includes(parsed.language) ? parsed.language : 'en';
        return { ...DEFAULT_SETTINGS, ...parsed, language };
      }
    } catch (e) {
      console.warn('Failed to load settings:', e);
    }
    return DEFAULT_SETTINGS;
  }

  public saveSettings(settings: GameSettings) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch (e) {
      console.warn('Failed to save settings:', e);
    }
  }

  public loadStats(): PlayerStats {
    if (typeof window === 'undefined') return DEFAULT_STATS;
    try {
      const data = localStorage.getItem(STATS_STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        const completedKeys = Object.keys(parsed.completedLevels || {}).map(Number);
        const maxCompleted = completedKeys.length > 0 ? Math.max(...completedKeys) : 0;
        const highestUnlocked = parsed.highestUnlockedLevel || Math.max(1, maxCompleted + 1);

        const highestShort = parsed.highestShortArrowLevel || parsed.highestUnlockedLevel || 1;
        const highestLong = parsed.highestLongArrowLevel || 1;
        const completedShort = parsed.completedShortLevels || parsed.completedLevels || {};
        const completedLong = parsed.completedLongLevels || {};

        // Ensure black skin is always unlocked for all players
        const unlockedSkins: string[] = Array.isArray(parsed.unlockedSkins)
          ? [...parsed.unlockedSkins]
          : ['black'];
        if (!unlockedSkins.includes('black')) {
          unlockedSkins.unshift('black');
        }

        // Normalize default equipped skin: if previous version had 'classic' or 'cyan' or unset, default to 'black'
        let equippedArrowSkin = parsed.equippedArrowSkin;
        if (!equippedArrowSkin || equippedArrowSkin === 'classic' || equippedArrowSkin === 'cyan') {
          equippedArrowSkin = 'black';
        }

        return {
          ...DEFAULT_STATS,
          ...parsed,
          highestShortArrowLevel: highestShort,
          highestLongArrowLevel: highestLong,
          completedShortLevels: completedShort,
          completedLongLevels: completedLong,
          highestUnlockedLevel: highestShort,
          unlockedSkins,
          equippedArrowSkin,
        };
      }
    } catch (e) {
      console.warn('Failed to load stats:', e);
    }
    return DEFAULT_STATS;
  }

  public saveStats(stats: PlayerStats) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
    } catch (e) {
      console.warn('Failed to save stats:', e);
    }
  }

  public resetAllProgress(): { stats: PlayerStats; settings: GameSettings } {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STATS_STORAGE_KEY);
      localStorage.removeItem(SETTINGS_STORAGE_KEY);
    }
    return {
      stats: DEFAULT_STATS,
      settings: DEFAULT_SETTINGS,
    };
  }
}

export const saveManager = new SaveManager();
