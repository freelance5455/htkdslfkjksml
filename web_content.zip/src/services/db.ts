import {
  Category,
  FamilyMember,
  Transaction,
  Loan,
  BillReminder,
  SavingsGoal,
  BudgetConfig,
  AppSettings,
  AppDataBackup
} from '../types';

export const DEFAULT_CATEGORIES: Category[] = [
  // Expense categories
  { id: 'groceries', nameHi: 'राशन', nameEn: 'Groceries', icon: 'ShoppingBag', color: '#16a34a', type: 'expense', budgetLimit: 8000 },
  { id: 'veg_fruits', nameHi: 'सब्जी और फल', nameEn: 'Vegetables & Fruits', icon: 'Apple', color: '#22c55e', type: 'expense', budgetLimit: 3000 },
  { id: 'milk_dairy', nameHi: 'दूध और डेयरी', nameEn: 'Milk & Dairy', icon: 'Milk', color: '#0284c7', type: 'expense', budgetLimit: 2500 },
  { id: 'electricity', nameHi: 'बिजली बिल', nameEn: 'Electricity Bill', icon: 'Zap', color: '#eab308', type: 'expense', budgetLimit: 2000 },
  { id: 'water', nameHi: 'पानी बिल', nameEn: 'Water Bill', icon: 'Droplets', color: '#06b6d4', type: 'expense', budgetLimit: 500 },
  { id: 'gas', nameHi: 'गैस सिलेंडर', nameEn: 'Gas Cylinder', icon: 'Flame', color: '#ea580c', type: 'expense', budgetLimit: 1100 },
  { id: 'recharge', nameHi: 'मोबाइल रिचार्ज', nameEn: 'Mobile Recharge', icon: 'Smartphone', color: '#3b82f6', type: 'expense', budgetLimit: 800 },
  { id: 'internet', nameHi: 'इंटरनेट बिल', nameEn: 'Internet Bill', icon: 'Wifi', color: '#6366f1', type: 'expense', budgetLimit: 1000 },
  { id: 'school_fees', nameHi: 'बच्चों की स्कूल फीस', nameEn: 'School Fees', icon: 'GraduationCap', color: '#8b5cf6', type: 'expense', budgetLimit: 6000 },
  { id: 'education', nameHi: 'पढ़ाई और किताबें', nameEn: 'Education & Books', icon: 'BookOpen', color: '#a855f7', type: 'expense', budgetLimit: 1500 },
  { id: 'medical', nameHi: 'दवाई और मेडिकल', nameEn: 'Medical & Health', icon: 'HeartPulse', color: '#ef4444', type: 'expense', budgetLimit: 2000 },
  { id: 'clothing', nameHi: 'कपड़े', nameEn: 'Clothing', icon: 'Shirt', color: '#ec4899', type: 'expense', budgetLimit: 3000 },
  { id: 'house_rent', nameHi: 'घर का किराया', nameEn: 'House Rent', icon: 'Home', color: '#475569', type: 'expense', budgetLimit: 12000 },
  { id: 'fuel', nameHi: 'पेट्रोल और डीजल', nameEn: 'Fuel / Petrol', icon: 'Fuel', color: '#f97316', type: 'expense', budgetLimit: 3500 },
  { id: 'travel', nameHi: 'यात्रा', nameEn: 'Travel / Transport', icon: 'Bus', color: '#14b8a6', type: 'expense', budgetLimit: 2000 },
  { id: 'entertainment', nameHi: 'मनोरंजन', nameEn: 'Entertainment', icon: 'Tv', color: '#d946ef', type: 'expense', budgetLimit: 1500 },
  { id: 'events', nameHi: 'शादी और समारोह', nameEn: 'Events & Functions', icon: 'Sparkles', color: '#f43f5e', type: 'expense', budgetLimit: 5000 },
  { id: 'other_expense', nameHi: 'अन्य खर्च', nameEn: 'Other Expenses', icon: 'MoreHorizontal', color: '#64748b', type: 'expense', budgetLimit: 2000 },

  // Income categories
  { id: 'salary', nameHi: 'मासिक वेतन', nameEn: 'Monthly Salary', icon: 'Briefcase', color: '#10b981', type: 'income' },
  { id: 'business', nameHi: 'व्यापार आय', nameEn: 'Business Income', icon: 'Store', color: '#059669', type: 'income' },
  { id: 'freelance', nameHi: 'फ्रीलांसिंग', nameEn: 'Freelancing', icon: 'Laptop', color: '#047857', type: 'income' },
  { id: 'rent_income', nameHi: 'किराया आय', nameEn: 'Rent Income', icon: 'Key', color: '#0d9488', type: 'income' },
  { id: 'other_income', nameHi: 'अन्य आय', nameEn: 'Other Income', icon: 'Coins', color: '#14b8a6', type: 'income' },
];

export const DEFAULT_FAMILY_MEMBERS: FamilyMember[] = [
  { id: 'self', name: 'राम कुमार (Self)', relationHi: 'स्वयं', relationEn: 'Self', avatarColor: '#15803d', isDefault: true },
  { id: 'spouse', name: 'सुनीता (Spouse)', relationHi: 'जीवनसाथी', relationEn: 'Spouse', avatarColor: '#0284c7' },
  { id: 'parent', name: 'पिताजी (Father)', relationHi: 'पिताजी', relationEn: 'Father', avatarColor: '#d97706' },
  { id: 'child', name: 'आरव (Son)', relationHi: 'बेटा', relationEn: 'Son', avatarColor: '#7c3aed' },
];

export const DEFAULT_SAVINGS_GOALS: SavingsGoal[] = [
  {
    id: 'emergency_fund',
    titleHi: 'आपातकालीन फंड (Emergency Fund)',
    titleEn: 'Emergency Fund',
    targetAmount: 100000,
    currentAmount: 42000,
    deadline: '2026-12-31',
    icon: 'ShieldCheck',
    color: '#15803d',
    history: [
      { id: 'h1', date: '2026-10-01', amount: 30000, type: 'deposit', note: 'प्रारंभिक बचत' },
      { id: 'h2', date: '2026-11-01', amount: 12000, type: 'deposit', note: 'मासिक बचत योगदान' }
    ],
    createdAt: Date.now() - 30 * 86400000
  },
  {
    id: 'diwali_gold',
    titleHi: 'सोना / आभूषण बचत (Gold/Jewellery)',
    titleEn: 'Gold & Jewellery',
    targetAmount: 50000,
    currentAmount: 35000,
    deadline: '2026-11-15',
    icon: 'Gem',
    color: '#d97706',
    history: [
      { id: 'h3', date: '2026-10-15', amount: 35000, type: 'deposit', note: 'धनतेरस फंड' }
    ],
    createdAt: Date.now() - 20 * 86400000
  },
  {
    id: 'family_vacation',
    titleHi: 'परिवार यात्रा (Family Trip)',
    titleEn: 'Family Vacation',
    targetAmount: 25000,
    currentAmount: 15000,
    deadline: '2026-12-25',
    icon: 'Plane',
    color: '#0284c7',
    history: [
      { id: 'h4', date: '2026-10-20', amount: 15000, type: 'deposit', note: 'हॉलिडे फंड' }
    ],
    createdAt: Date.now() - 15 * 86400000
  }
];

export const DEFAULT_BILLS: BillReminder[] = [
  {
    id: 'bill_elec',
    titleHi: 'बिजली का बिल',
    titleEn: 'Electricity Bill',
    category: 'electricity',
    amount: 1450,
    dueDate: '2026-11-10',
    frequency: 'monthly',
    status: 'pending',
    createdAt: Date.now()
  },
  {
    id: 'bill_gas',
    titleHi: 'गैस सिलेंडर रीफिल',
    titleEn: 'Gas Cylinder Refill',
    category: 'gas',
    amount: 980,
    dueDate: '2026-11-12',
    frequency: 'monthly',
    status: 'pending',
    createdAt: Date.now()
  },
  {
    id: 'bill_wifi',
    titleHi: 'वाईफाई ब्रॉडबैंड बिल',
    titleEn: 'WiFi Broadband',
    category: 'internet',
    amount: 799,
    dueDate: '2026-11-15',
    frequency: 'monthly',
    status: 'pending',
    createdAt: Date.now()
  }
];

export const DEFAULT_LOANS: Loan[] = [
  {
    id: 'loan_1',
    personName: 'रमेश कुमार (पड़ोसी)',
    phone: '9876543210',
    type: 'lent', // I lent to Ramesh (मुझे लेना है)
    amount: 5000,
    date: '2026-10-20',
    dueDate: '2026-11-20',
    status: 'partial',
    notes: 'दुकान के काम के लिए दिया था',
    repayments: [
      { id: 'r1', date: '2026-10-28', amount: 2000, note: 'पहला हफ्ता दिया' }
    ],
    createdAt: Date.now() - 12 * 86400000,
    updatedAt: Date.now() - 4 * 86400000
  },
  {
    id: 'loan_2',
    personName: 'वर्मा जी (किराना वाले)',
    phone: '9123456780',
    type: 'borrowed', // I owe Verma ji (मुझे देना है)
    amount: 1200,
    date: '2026-10-25',
    dueDate: '2026-11-05',
    status: 'pending',
    notes: 'पिछले महीने का राशन बकाया',
    repayments: [],
    createdAt: Date.now() - 7 * 86400000,
    updatedAt: Date.now() - 7 * 86400000
  }
];

const getSampleTransactions = (): Transaction[] => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const todayStr = `${year}-${month}-${day}`;

  const pastDate = (daysAgo: number) => {
    const d = new Date(now.getTime() - daysAgo * 86400000);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  return [
    {
      id: 'tx_sal_1',
      type: 'income',
      amount: 65000,
      categoryId: 'salary',
      date: `${year}-${month}-01`,
      time: '09:30',
      description: 'मासिक वेतन (Monthly Salary)',
      familyMemberId: 'self',
      paymentMode: 'bank_transfer',
      createdAt: Date.now() - 2 * 86400000,
      updatedAt: Date.now() - 2 * 86400000
    },
    {
      id: 'tx_rent_in',
      type: 'income',
      amount: 12000,
      categoryId: 'rent_income',
      date: `${year}-${month}-02`,
      time: '11:00',
      description: 'ऊपर वाले फ्लैट का किराया',
      familyMemberId: 'self',
      paymentMode: 'upi',
      createdAt: Date.now() - 86400000,
      updatedAt: Date.now() - 86400000
    },
    {
      id: 'tx_groceries_1',
      type: 'expense',
      amount: 3850,
      categoryId: 'groceries',
      date: pastDate(1),
      time: '18:40',
      description: 'महीने का राशन (आटा, चावल, तेल, दाल)',
      familyMemberId: 'spouse',
      paymentMode: 'upi',
      createdAt: Date.now() - 86400000,
      updatedAt: Date.now() - 86400000
    },
    {
      id: 'tx_dairy_today',
      type: 'expense',
      amount: 140,
      categoryId: 'milk_dairy',
      date: todayStr,
      time: '07:15',
      description: 'अमूल ताजा दूध 2 पैकेट + दही',
      familyMemberId: 'self',
      paymentMode: 'upi',
      createdAt: Date.now() - 100000,
      updatedAt: Date.now() - 100000
    },
    {
      id: 'tx_veg_today',
      type: 'expense',
      amount: 260,
      categoryId: 'veg_fruits',
      date: todayStr,
      time: '08:30',
      description: 'सब्जी मंडी (आलू, टमाटर, प्याज, सेब)',
      familyMemberId: 'parent',
      paymentMode: 'cash',
      createdAt: Date.now() - 50000,
      updatedAt: Date.now() - 50000
    },
    {
      id: 'tx_fuel_1',
      type: 'expense',
      amount: 1200,
      categoryId: 'fuel',
      date: pastDate(2),
      time: '14:20',
      description: 'बाइक और कार में पेट्रोल',
      familyMemberId: 'self',
      paymentMode: 'card',
      createdAt: Date.now() - 2 * 86400000,
      updatedAt: Date.now() - 2 * 86400000
    },
    {
      id: 'tx_med_1',
      type: 'expense',
      amount: 680,
      categoryId: 'medical',
      date: pastDate(3),
      time: '20:10',
      description: 'पिताजी की बीपी और शुगर की दवाइयां',
      familyMemberId: 'self',
      paymentMode: 'upi',
      createdAt: Date.now() - 3 * 86400000,
      updatedAt: Date.now() - 3 * 86400000
    }
  ];
};

const DB_KEY_PREFIX = 'smarthomekhata_';

// Storage Helper: transparently uses localStorage with validation
export const storage = {
  get: <T>(key: string, defaultValue: T): T => {
    try {
      const data = localStorage.getItem(DB_KEY_PREFIX + key);
      return data ? JSON.parse(data) : defaultValue;
    } catch (e) {
      console.warn('Storage read failed for', key, e);
      return defaultValue;
    }
  },
  set: <T>(key: string, value: T): void => {
    try {
      localStorage.setItem(DB_KEY_PREFIX + key, JSON.stringify(value));
    } catch (e) {
      console.warn('Storage write failed for', key, e);
    }
  },
  remove: (key: string): void => {
    try {
      localStorage.removeItem(DB_KEY_PREFIX + key);
    } catch (e) {
      console.warn('Storage remove failed for', key, e);
    }
  }
};

export const initDatabase = () => {
  const initialized = storage.get<boolean>('initialized', false);
  if (!initialized) {
    const currentMonth = new Date().toISOString().slice(0, 7);
    storage.set<Category[]>('categories', DEFAULT_CATEGORIES);
    storage.set<FamilyMember[]>('family_members', DEFAULT_FAMILY_MEMBERS);
    storage.set<SavingsGoal[]>('savings_goals', DEFAULT_SAVINGS_GOALS);
    storage.set<BillReminder[]>('bills', DEFAULT_BILLS);
    storage.set<Loan[]>('loans', DEFAULT_LOANS);
    storage.set<Transaction[]>('transactions', getSampleTransactions());
    storage.set<BudgetConfig>('budget', {
      month: currentMonth,
      overallBudget: 45000,
      categoryLimits: {
        groceries: 8000,
        veg_fruits: 3000,
        milk_dairy: 2500,
        electricity: 2000,
        house_rent: 12000,
        fuel: 3500,
        medical: 2000,
        school_fees: 6000
      }
    });
    storage.set<AppSettings>('settings', {
      language: 'hi',
      currency: '₹',
      pinLockEnabled: false,
      biometricEnabled: false,
      hasSeenOnboarding: true
    });
    storage.set<boolean>('initialized', true);
  }
};
