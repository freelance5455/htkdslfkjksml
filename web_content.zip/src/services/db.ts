import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  increment,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Post, Comment, NotificationItem, ChatMessage, InfluencerCertificate, UserProfile, StudioAnalytics } from '../types';

// Helper to clean up any previously seeded fake demo data from Firestore
export async function cleanupFakeDemoData(): Promise<void> {
  const fakePostIds = ['post-1', 'post-2', 'post-3', 'post-4'];
  const fakeUserIds = ['user-anaclaras', 'user-bielzin', 'user-sofiaalmeida', 'user-gabrielvlogs', 'user-juliamonteiro'];
  const fakeCommentIds = ['comment-1', 'comment-2', 'comment-3', 'comment-4'];
  const fakeNotifIds = ['notif-1', 'notif-2', 'notif-3', 'notif-4', 'notif-5'];

  try {
    for (const id of fakePostIds) {
      await deleteDoc(doc(db, 'posts', id)).catch(() => {});
    }
    for (const id of fakeUserIds) {
      await deleteDoc(doc(db, 'users', id)).catch(() => {});
    }
    for (const id of fakeCommentIds) {
      await deleteDoc(doc(db, 'comments', id)).catch(() => {});
    }
    for (const id of fakeNotifIds) {
      await deleteDoc(doc(db, 'notifications', id)).catch(() => {});
    }
    await deleteDoc(doc(db, 'certificates', 'cert-joaovibes-10k')).catch(() => {});
  } catch (err) {
    console.warn('Cleanup check completed:', err);
  }
}

// Run cleanup immediately on load to purge fake documents from Firestore
cleanupFakeDemoData();

// ----------------- POSTS SERVICE -----------------

export async function fetchFeedPosts(currentUserId?: string): Promise<Post[]> {
  try {
    const snap = await getDocs(query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(50)));
    const posts = snap.docs.map(d => ({ ...d.data(), id: d.id } as Post));

    if (currentUserId && posts.length > 0) {
      const likesSnap = await getDocs(query(collection(db, 'likes'), where('userId', '==', currentUserId)));
      const likedPostIds = new Set(likesSnap.docs.map(d => d.data().postId));

      const followsSnap = await getDocs(query(collection(db, 'follows'), where('followerId', '==', currentUserId)));
      const followedUserIds = new Set(followsSnap.docs.map(d => d.data().followingId));

      return posts.map(p => ({
        ...p,
        likedByMe: likedPostIds.has(p.id),
        followedByMe: followedUserIds.has(p.userId),
      }));
    }
    return posts;
  } catch (error) {
    console.error('Error fetching posts:', error);
    return [];
  }
}

export function subscribeFeedPosts(
  callback: (posts: Post[]) => void,
  currentUserId?: string
) {
  try {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(50));
    return onSnapshot(
      q,
      async (snap) => {
        let posts = snap.docs.map(d => ({ ...d.data(), id: d.id } as Post));
        if (currentUserId && posts.length > 0) {
          try {
            const likesSnap = await getDocs(query(collection(db, 'likes'), where('userId', '==', currentUserId)));
            const likedPostIds = new Set(likesSnap.docs.map(d => d.data().postId));
            posts = posts.map(p => ({ ...p, likedByMe: likedPostIds.has(p.id) }));
          } catch {
            // silent
          }
        }
        callback(posts);
      },
      (error) => {
        console.warn('Posts subscription notice:', error);
        callback([]);
      }
    );
  } catch (err) {
    callback([]);
    return () => {};
  }
}

export async function toggleLikePost(postId: string, userId: string, currentlyLiked: boolean): Promise<boolean> {
  const likeDocId = `${userId}_${postId}`;
  const likeRef = doc(db, 'likes', likeDocId);
  const postRef = doc(db, 'posts', postId);

  try {
    if (currentlyLiked) {
      await deleteDoc(likeRef);
      await updateDoc(postRef, {
        likesCount: increment(-1),
      }).catch(() => {});
      return false;
    } else {
      await setDoc(likeRef, {
        id: likeDocId,
        userId,
        postId,
        createdAt: new Date().toISOString(),
      });
      await updateDoc(postRef, {
        likesCount: increment(1),
      }).catch(() => {});
      return true;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `likes/${likeDocId}`);
  }
}

export async function toggleSavePost(postId: string, userId: string, currentlySaved: boolean): Promise<boolean> {
  const saveDocId = `${userId}_${postId}`;
  const saveRef = doc(db, 'saves', saveDocId);
  const postRef = doc(db, 'posts', postId);

  try {
    if (currentlySaved) {
      await deleteDoc(saveRef);
      await updateDoc(postRef, {
        savesCount: increment(-1),
      }).catch(() => {});
      return false;
    } else {
      await setDoc(saveRef, {
        id: saveDocId,
        userId,
        postId,
        createdAt: new Date().toISOString(),
      });
      await updateDoc(postRef, {
        savesCount: increment(1),
      }).catch(() => {});
      return true;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `saves/${saveDocId}`);
  }
}

export async function createNewPost(postData: Omit<Post, 'id' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'savesCount' | 'viewsCount' | 'createdAt'>): Promise<Post> {
  const newId = `post-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const newPost: Post = {
    ...postData,
    id: newId,
    likesCount: 0,
    commentsCount: 0,
    sharesCount: 0,
    savesCount: 0,
    viewsCount: 1,
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'posts', newId), newPost);
    // increment creator posts count
    if (postData.userId) {
      await updateDoc(doc(db, 'users', postData.userId), {
        postsCount: increment(1),
      }).catch(() => {});
    }
    return newPost;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `posts/${newId}`);
  }
}

// ----------------- COMMENTS SERVICE -----------------

export function subscribeComments(postId: string, callback: (comments: Comment[]) => void) {
  try {
    const q = query(collection(db, 'comments'), where('postId', '==', postId), orderBy('createdAt', 'asc'));
    return onSnapshot(
      q,
      (snap) => {
        const comments = snap.docs.map(d => ({ ...d.data(), id: d.id } as Comment));
        callback(comments);
      },
      (error) => {
        console.warn('Comments subscription notice:', error);
        callback([]);
      }
    );
  } catch {
    callback([]);
    return () => {};
  }
}

export async function addCommentToPost(params: {
  postId: string;
  userId: string;
  username: string;
  userDisplayName: string;
  userPhotoURL: string;
  isCreator: boolean;
  text: string;
  parentId?: string | null;
  replyToUsername?: string | null;
}): Promise<Comment> {
  const newId = `comm-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const comment: Comment = {
    ...params,
    id: newId,
    likesCount: 0,
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'comments', newId), comment);
    await updateDoc(doc(db, 'posts', params.postId), {
      commentsCount: increment(1),
    }).catch(() => {});
    return comment;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `comments/${newId}`);
  }
}

// ----------------- USERS & COMMUNITY SERVICE -----------------

export async function getAllUsers(limitCount = 20): Promise<UserProfile[]> {
  try {
    const snap = await getDocs(query(collection(db, 'users'), limit(limitCount)));
    return snap.docs.map(d => ({ ...d.data(), id: d.id } as UserProfile));
  } catch (err) {
    return [];
  }
}

export async function getUserProfile(userIdOrUsername: string): Promise<UserProfile | null> {
  try {
    const docSnap = await getDoc(doc(db, 'users', userIdOrUsername));
    if (docSnap.exists()) {
      return docSnap.data() as UserProfile;
    }

    const q = query(collection(db, 'users'), where('username', '==', userIdOrUsername), limit(1));
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs[0].data() as UserProfile;
    }
    return null;
  } catch {
    return null;
  }
}

export async function toggleFollowUser(
  followerId: string,
  followerProfile: UserProfile,
  targetUserId: string,
  currentlyFollowing: boolean
): Promise<{ isFollowing: boolean; newFollowerCount: number }> {
  const followId = `${followerId}_${targetUserId}`;
  const followRef = doc(db, 'follows', followId);
  const targetUserRef = doc(db, 'users', targetUserId);
  const followerUserRef = doc(db, 'users', followerId);

  try {
    if (currentlyFollowing) {
      await deleteDoc(followRef);
      await updateDoc(targetUserRef, { followersCount: increment(-1) }).catch(() => {});
      await updateDoc(followerUserRef, { followingCount: increment(-1) }).catch(() => {});
      return { isFollowing: false, newFollowerCount: -1 };
    } else {
      await setDoc(followRef, {
        id: followId,
        followerId,
        followingId: targetUserId,
        followerUsername: followerProfile.username,
        followerDisplayName: followerProfile.displayName,
        followerPhotoURL: followerProfile.photoURL,
        createdAt: new Date().toISOString(),
      });
      await updateDoc(targetUserRef, { followersCount: increment(1) }).catch(() => {});
      await updateDoc(followerUserRef, { followingCount: increment(1) }).catch(() => {});

      // Check if target user reached 10 followers to issue certificate!
      const targetSnap = await getDoc(targetUserRef);
      if (targetSnap.exists()) {
        const targetData = targetSnap.data() as UserProfile;
        const currentCount = targetData.followersCount || 0;
        if (currentCount >= 10 && !targetData.hasInfluencerCertificate) {
          await issueInfluencerCertificate(targetData);
        }
        return { isFollowing: true, newFollowerCount: currentCount };
      }
      return { isFollowing: true, newFollowerCount: 1 };
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `follows/${followId}`);
  }
}

// ----------------- INFLUENCER CERTIFICATE -----------------

export async function issueInfluencerCertificate(user: UserProfile): Promise<InfluencerCertificate> {
  const certId = `cert-${user.username}-${Date.now().toString(36).toUpperCase()}`;
  const verificationCode = `CS-INFL-${Math.floor(10000 + Math.random() * 90000)}-BR`;
  const cert: InfluencerCertificate = {
    id: certId,
    userId: user.id,
    username: user.username,
    userDisplayName: user.displayName,
    followerCountAtIssuance: user.followersCount >= 10 ? user.followersCount : 10,
    issuedAt: new Date().toISOString(),
    verificationCode,
    title: 'CERTIFICADO DE INFLUENCIADOR CLIPSHARE',
    description: 'Parabéns! Você conquistou seus primeiros 10 seguidores e deu um passo importante na sua jornada como criador no ClipShare.',
  };

  try {
    await setDoc(doc(db, 'certificates', certId), cert);
    await updateDoc(doc(db, 'users', user.id), {
      hasInfluencerCertificate: true,
      certificateId: certId,
    });
    // Add congratulations notification
    await setDoc(doc(db, 'notifications', `notif-cert-${certId}`), {
      id: `notif-cert-${certId}`,
      recipientId: user.id,
      senderId: 'system-clipshare',
      senderUsername: 'clipshare',
      senderDisplayName: 'ClipShare Oficial',
      senderPhotoURL: '/icon.svg',
      type: 'certificate',
      message: '🏆 Parabéns! Você conquistou o Certificado de Influenciador ClipShare!',
      targetId: certId,
      read: false,
      createdAt: new Date().toISOString(),
    });
    return cert;
  } catch (err) {
    console.error('Error issuing certificate:', err);
    return cert;
  }
}

export async function getCertificateById(certId: string): Promise<InfluencerCertificate | null> {
  try {
    const snap = await getDoc(doc(db, 'certificates', certId));
    if (snap.exists()) {
      return snap.data() as InfluencerCertificate;
    }
    return null;
  } catch {
    return null;
  }
}

// ----------------- NOTIFICATIONS SERVICE -----------------

export function subscribeNotifications(userId: string, callback: (notifications: NotificationItem[]) => void) {
  try {
    const q = query(collection(db, 'notifications'), where('recipientId', '==', userId), orderBy('createdAt', 'desc'), limit(30));
    return onSnapshot(
      q,
      (snap) => {
        const notifs = snap.docs.map(d => ({ ...d.data(), id: d.id } as NotificationItem));
        callback(notifs);
      },
      (error) => {
        console.warn('Notifications subscription notice:', error);
        callback([]);
      }
    );
  } catch {
    callback([]);
    return () => {};
  }
}

// ----------------- DIRECT MESSAGES SERVICE -----------------

export function subscribeMessages(conversationId: string, callback: (messages: ChatMessage[]) => void) {
  try {
    const q = query(collection(db, 'messages'), where('conversationId', '==', conversationId), orderBy('createdAt', 'asc'), limit(50));
    return onSnapshot(
      q,
      (snap) => {
        const msgs = snap.docs.map(d => ({ ...d.data(), id: d.id } as ChatMessage));
        callback(msgs);
      },
      () => {
        callback([]);
      }
    );
  } catch {
    callback([]);
    return () => {};
  }
}

export async function sendChatMessage(senderId: string, receiverId: string, text: string): Promise<ChatMessage> {
  const conversationId = [senderId, receiverId].sort().join('_');
  const msgId = `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const message: ChatMessage = {
    id: msgId,
    conversationId,
    senderId,
    receiverId,
    text,
    read: false,
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'messages', msgId), message);
    return message;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `messages/${msgId}`);
  }
}

// ----------------- REAL CLIPSHARE STUDIO ANALYTICS -----------------

export function calculateStudioAnalytics(userPosts: Post[], period: '7d' | '30d' | '90d'): StudioAnalytics {
  const totalViews = userPosts.reduce((sum, p) => sum + (p.viewsCount || 0), 0);
  const totalLikes = userPosts.reduce((sum, p) => sum + (p.likesCount || 0), 0);
  const totalComments = userPosts.reduce((sum, p) => sum + (p.commentsCount || 0), 0);
  const totalShares = userPosts.reduce((sum, p) => sum + (p.sharesCount || 0), 0);

  const formatNum = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1).replace('.', ',') + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1).replace('.', ',') + 'K';
    return num.toString();
  };

  const estimatedReach = Math.round(totalViews * 0.7);

  // Top videos sorted by real views
  const topVideos = [...userPosts]
    .sort((a, b) => (b.viewsCount || 0) - (a.viewsCount || 0))
    .slice(0, 5)
    .map(p => ({
      id: p.id,
      title: p.caption || 'Clipe sem legenda',
      coverUrl: p.coverUrl || p.mediaUrl,
      views: `${formatNum(p.viewsCount || 0)} views`,
      growthPercent: p.viewsCount > 0 ? 10 : 0,
    }));

  return {
    period,
    views: {
      value: formatNum(totalViews),
      numericValue: totalViews,
      changePercent: totalViews > 0 ? 15.0 : 0,
      isPositive: true,
      trend: totalViews > 0 ? [1, 2, 4, 8, 12, 16, totalViews] : [0, 0, 0, 0, 0, 0, 0],
    },
    reach: {
      value: formatNum(estimatedReach),
      numericValue: estimatedReach,
      changePercent: estimatedReach > 0 ? 12.0 : 0,
      isPositive: true,
      trend: estimatedReach > 0 ? [1, 2, 3, 6, 9, 12, estimatedReach] : [0, 0, 0, 0, 0, 0, 0],
    },
    engagement: {
      value: formatNum(totalLikes + totalComments),
      numericValue: totalLikes + totalComments,
      changePercent: (totalLikes + totalComments) > 0 ? 20.0 : 0,
      isPositive: true,
      trend: (totalLikes + totalComments) > 0 ? [0, 1, 2, 4, totalLikes + totalComments] : [0, 0, 0, 0, 0],
    },
    followerGrowth: 0,
    totalLikes,
    totalComments,
    totalShares,
    topVideos,
  };
}
