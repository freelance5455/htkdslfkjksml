import type { ActionCardData, UtilityPanelId, WeatherData } from '../types';
import { loadNotes, saveNotes } from './storage';

export interface CommandOutcome {
  handled: boolean;
  replyText?: string;
  actionCard?: ActionCardData;
  triggerSearchQuery?: string;
  triggerNewChat?: boolean;
  triggerStopVoice?: boolean;
  openUtility?: UtilityPanelId;
}

interface BatteryManagerLike {
  level: number;
  charging: boolean;
  chargingTime?: number;
  dischargingTime?: number;
}

type NavigatorWithBattery = Navigator & {
  getBattery?: () => Promise<BatteryManagerLike>;
};

function normalizeCommandText(raw: string): string {
  return raw
    .trim()
    .toLowerCase()
    .replace(/^(hey\s+)?(jarvis|assistant)[,\s:!-]*/i, '')
    .trim();
}

export function triggerExternalLink(url: string): boolean {
  try {
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    return true;
  } catch {
    return false;
  }
}

export async function routeAssistantCommand(rawInput: string): Promise<CommandOutcome> {
  const cmd = normalizeCommandText(rawInput);

  if (!cmd) {
    return { handled: false };
  }

  // Stop listening / speaking
  if (
    /^(meri baat sunna band karo|sunna band karo|stop listening|chup ho jao|bolna band karo|stop speaking|be quiet|shant ho jao)\b/.test(
      cmd,
    )
  ) {
    return {
      handled: true,
      triggerStopVoice: true,
      replyText: 'Theek hai, maine sunna aur bolna rok diya hai.',
    };
  }

  // New chat
  if (/^(naya chat shuru karo|naya chat|new chat|start new chat|fresh chat)\b/.test(cmd)) {
    return {
      handled: true,
      triggerNewChat: true,
      replyText: 'Nayi conversation shuru kar di hai. Bataiye, kya madad karun?',
    };
  }

  // Search query extraction
  const searchPatterns = [
    /^(?:mujhe\s+)?search\s+karke\s+batao\s+(.+)$/i,
    /^(?:internet\s+(?:par|pe)\s+)?search\s+(?:karo|for)\s+(.+)$/i,
    /^google\s+(?:par|pe)\s+(?:search\s+karo|dekho|batao)\s+(.+)$/i,
    /^web\s+search\s+(.+)$/i,
  ];
  for (const pattern of searchPatterns) {
    const match = cmd.match(pattern);
    if (match?.[1]?.trim()) {
      return {
        handled: true,
        triggerSearchQuery: match[1].trim(),
      };
    }
  }

  // Time
  if (
    /^(time batao|abhi kitne baje|kitna time hua|what time is it|current time|time kya hai|samay batao)\b/.test(
      cmd,
    )
  ) {
    const now = new Date();
    const formatted = now.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });
    return {
      handled: true,
      replyText: `Abhi time ${formatted} ho raha hai.`,
      actionCard: {
        type: 'utility',
        label: 'Open Clock & Calendar',
        utilityId: 'clock',
        detail: formatted,
      },
    };
  }

  // Date
  if (
    /^(aaj ki date batao|aaj kya date hai|aaj ki tareekh|today'?s date|what is the date|date batao)\b/.test(
      cmd,
    )
  ) {
    const now = new Date();
    const formatted = now.toLocaleDateString('en-IN', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    return {
      handled: true,
      replyText: `Aaj ${formatted} hai.`,
      actionCard: {
        type: 'utility',
        label: 'Open Calendar',
        utilityId: 'clock',
        detail: formatted,
      },
    };
  }

  // Battery
  if (/^(meri battery kitni hai|battery kitni hai|battery status|check battery|battery check karo)\b/.test(cmd)) {
    const nav = navigator as NavigatorWithBattery;
    if (typeof nav.getBattery !== 'function') {
      return {
        handled: true,
        replyText:
          'Is browser mein Battery Status API available nahi hai, isliye main battery percentage read nahi kar sakta.',
        actionCard: {
          type: 'utility',
          label: 'Check Device Status',
          utilityId: 'device',
          detail: 'Battery API unsupported on this browser',
        },
      };
    }

    try {
      const battery = await nav.getBattery();
      const percent = Math.round(battery.level * 100);
      const statusText = battery.charging ? 'charge ho rahi hai' : 'battery par chal rahi hai';
      return {
        handled: true,
        replyText: `Aapki battery abhi ${percent}% hai aur device ${statusText}.`,
        actionCard: {
          type: 'utility',
          label: 'Device Diagnostics',
          utilityId: 'device',
          detail: `${percent}% · ${battery.charging ? 'Charging' : 'Discharging'}`,
        },
      };
    } catch {
      return {
        handled: true,
        replyText: 'Battery ki jaankari is browser session mein accessible nahi ho payi.',
      };
    }
  }

  // Weather
  if (/^(weather batao|mausam batao|aaj ka mausam|what'?s the weather|weather check karo)\b/.test(cmd)) {
    if (!navigator.onLine) {
      return {
        handled: true,
        replyText: 'Internet offline hai, isliye live weather fetch nahi ho sakta.',
        openUtility: 'weather',
      };
    }

    try {
      // Try default major city or user-saved weather only if geolocation already permitted, otherwise prompt via Weather utility
      let queryUrl = '/api/weather?city=New%20Delhi';
      let usingCityFallback = true;

      if ('permissions' in navigator) {
        try {
          const perm = await navigator.permissions.query({ name: 'geolocation' });
          if (perm.state === 'granted') {
            const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
              navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 4500 });
            });
            queryUrl = `/api/weather?lat=${pos.coords.latitude}&lon=${pos.coords.longitude}`;
            usingCityFallback = false;
          }
        } catch {
          // Fallback cleanly
        }
      }

      if (usingCityFallback) {
        return {
          handled: true,
          openUtility: 'weather',
          replyText:
            'Weather panel khol diya hai. Apne shehar ka naam search karein ya "Use My Location" tap karke exact local mausam dekhein.',
          actionCard: {
            type: 'utility',
            label: 'Open Weather Panel',
            utilityId: 'weather',
            detail: 'Tap to allow location or search city',
          },
        };
      }

      const resp = await fetch(queryUrl);
      if (!resp.ok) throw new Error('Weather fetch failed');
      const data = (await resp.json()) as WeatherData;
      return {
        handled: true,
        openUtility: 'weather',
        replyText: `Aapki current location par abhi ${data.temperatureC}°C hai (${data.condition}), humidity ${data.humidity}% aur hawa ${data.windKmh} km/h hai.`,
        actionCard: {
          type: 'utility',
          label: 'View 3-Day Forecast',
          utilityId: 'weather',
          detail: `${data.temperatureC}°C · ${data.condition}`,
        },
      };
    } catch {
      return {
        handled: true,
        openUtility: 'weather',
        replyText: 'Weather panel khol diya hai. Aap wahan se apne shehar ka live mausam dekh sakte hain.',
      };
    }
  }

  // Open YouTube
  if (/^(youtube kholo|open youtube|youtube open karo|youtube chalao)\b/.test(cmd)) {
    const url = 'https://www.youtube.com';
    const triggered = triggerExternalLink(url);
    return {
      handled: true,
      replyText: triggered
        ? 'YouTube kholne ka request bhej diya hai. Agar browser ne popup block kiya ho, to neeche diye button par tap karein.'
        : 'Automatic launch blocked hai. Neeche button par tap karke YouTube kholein.',
      actionCard: {
        type: 'url',
        label: 'Open YouTube',
        url,
        detail: 'youtube.com',
        openedAutomatically: triggered,
      },
    };
  }

  // Open Google
  if (/^(google kholo|open google|google open karo)\b/.test(cmd)) {
    const url = 'https://www.google.com';
    const triggered = triggerExternalLink(url);
    return {
      handled: true,
      replyText: triggered
        ? 'Google kholne ka link trigger kar diya hai. Zaroorat ho to neeche button tap karein.'
        : 'Neeche button par tap karke Google kholein.',
      actionCard: {
        type: 'url',
        label: 'Open Google',
        url,
        detail: 'google.com',
        openedAutomatically: triggered,
      },
    };
  }

  // Open Chrome
  if (/^(chrome kholo|open chrome|google chrome kholo)\b/.test(cmd)) {
    const isAndroid = /android/i.test(navigator.userAgent);
    return {
      handled: true,
      replyText: isAndroid
        ? 'Web app directly Chrome ko naye app ke roop mein force-launch nahi kar sakta jab tak aap link tap na karein. Agar aap abhi Chrome mein nahi hain, to Android Intent link neeche diya hai.'
        : 'Aap abhi web browser ke andar hi hain — security rules ki wajah se web page alag se Chrome application launch nahi kar sakta.',
      actionCard: isAndroid
        ? {
            type: 'url',
            label: 'Open in Chrome (Android)',
            url: 'intent://www.google.com#Intent;scheme=https;package=com.android.chrome;end',
            detail: 'Android Chrome Intent',
          }
        : {
            type: 'unsupported',
            label: 'Browser Restriction',
            detail: 'Desktop/non-Android browsers cannot launch external Chrome executable.',
          },
    };
  }

  // Open Maps
  if (/^(maps kholo|open maps|google maps kholo|map kholo)\b/.test(cmd)) {
    const url = 'https://maps.google.com';
    const triggered = triggerExternalLink(url);
    return {
      handled: true,
      replyText: triggered
        ? 'Google Maps kholne ka link launch kar diya hai. Agar naya tab na khule to neeche button tap karein.'
        : 'Neeche button tap karke Google Maps kholein.',
      actionCard: {
        type: 'url',
        label: 'Open Google Maps',
        url,
        detail: 'maps.google.com',
        openedAutomatically: triggered,
      },
    };
  }

  // Open Calculator (In-app functional calculator!)
  if (/^(calculator kholo|open calculator|calc kholo|hisab kitab)\b/.test(cmd)) {
    return {
      handled: true,
      openUtility: 'calculator',
      replyText: 'Calculator khol raha hoon.',
      actionCard: {
        type: 'utility',
        label: 'Calculator Ready',
        utilityId: 'calculator',
        detail: 'Built-in touch calculator',
      },
    };
  }

  // Open Camera (In-app Camera viewfinder with explicit permission)
  if (/^(camera kholo|open camera|camera on karo)\b/.test(cmd)) {
    return {
      handled: true,
      openUtility: 'camera',
      replyText:
        'Camera panel khol diya hai. Camera shuru karne ke liye permission prompt allow karein.',
      actionCard: {
        type: 'utility',
        label: 'Open Camera Viewfinder',
        utilityId: 'camera',
        detail: 'Requires camera permission',
      },
    };
  }

  // Timer / Stopwatch / Notes shortcuts
  if (/^(timer kholo|open timer|set timer)\b/.test(cmd)) {
    return {
      handled: true,
      openUtility: 'timer',
      replyText: 'Timer panel khol diya hai.',
    };
  }
  if (/^(stopwatch kholo|open stopwatch)\b/.test(cmd)) {
    return {
      handled: true,
      openUtility: 'stopwatch',
      replyText: 'Stopwatch panel khol diya hai.',
    };
  }
  if (/^(notes kholo|open notes|my notes)\b/.test(cmd)) {
    return {
      handled: true,
      openUtility: 'notes',
      replyText: 'Notes panel khol diya hai.',
    };
  }

  const quickNoteMatch = rawInput
    .trim()
    .match(/^(?:(?:hey\s+)?(?:jarvis|assistant)[,\s:!-]*)?(?:save\s+note|note\s+save\s+karo|note\s+likho|quick\s+note)\s+(.+)$/i);
  if (quickNoteMatch?.[1]?.trim()) {
    const content = quickNoteMatch[1].trim();
    const now = Date.now();
    const existing = loadNotes();
    const title = content.length > 36 ? `${content.slice(0, 36)}…` : content;
    saveNotes([
      {
        id: `note-${now}`,
        title,
        body: content,
        updatedAt: now,
      },
      ...existing,
    ]);
    return {
      handled: true,
      replyText: `Maine aapka note locally save kar liya hai: "${content}"`,
      actionCard: {
        type: 'utility',
        label: 'View Saved Notes',
        utilityId: 'notes',
        detail: 'Saved to device storage',
      },
    };
  }

  // Explicitly unsupported phone system actions (must never falsely claim success!)
  if (
    /\b(call\s+lagao|phone\s+karo|make\s+a\s+call|send\s+(?:an?\s+)?sms|message\s+bhejo|whatsapp\s+bhejo|wifi\s+(?:on|off)|bluetooth\s+(?:on|off)|hotspot\s+(?:on|off)|airplane\s+mode|brightness\s+(?:badhao|kam\s+karo)|system\s+settings\s+kholo)\b/i.test(
      cmd,
    )
  ) {
    return {
      handled: true,
      replyText:
        'Yeh action aapke phone ke current browser/PWA environment mein supported nahi hai. Browser security rules ki wajah se main calls, SMS, WhatsApp messages, ya system Wi-Fi/Bluetooth settings control nahi kar sakta.',
      actionCard: {
        type: 'unsupported',
        label: 'Restricted by Android Browser',
        detail: 'Calls, SMS, and system toggles are blocked for web apps.',
      },
    };
  }

  return { handled: false };
}
