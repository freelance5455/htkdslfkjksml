/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CommandResponse, ChatMessage } from '../types/assistant';
import { SafeCalculator } from './safeCalculator';
import { AIService } from './aiService';

export class CommandRouter {
  public static async execute(
    input: string,
    history: ChatMessage[],
    language: string
  ): Promise<CommandResponse> {
    const raw = input.trim();
    const lower = raw.toLowerCase();

    // 1. Time commands
    if (
      lower === 'what time is it' ||
      lower === 'what time is it?' ||
      lower === 'current time' ||
      lower === 'tell me the time' ||
      lower === 'time'
    ) {
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      return {
        spokenText: `The current time is ${timeStr}.`,
        displayText: `🕒 Current Time: **${timeStr}**`,
        action: { type: 'info' },
        state: 'SPEAKING',
      };
    }

    // 2. Date commands
    if (
      lower === "what is today's date" ||
      lower === "what is today's date?" ||
      lower === 'what is the date' ||
      lower === 'what is the date?' ||
      lower === 'what day is it' ||
      lower === 'what day is today' ||
      lower === 'today date' ||
      lower === 'date'
    ) {
      const now = new Date();
      const dateStr = now.toLocaleDateString(undefined, {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
      return {
        spokenText: `Today is ${dateStr}.`,
        displayText: `📅 Date: **${dateStr}**`,
        action: { type: 'info' },
        state: 'SPEAKING',
      };
    }

    // 3. Capabilities / Help commands
    if (
      lower === 'help' ||
      lower === 'help me' ||
      lower === 'what can you do' ||
      lower === 'what can you do?' ||
      lower === 'who are you' ||
      lower === 'who are you?' ||
      lower === 'capabilities'
    ) {
      const helpText =
        'I am ELYSIA — your personal AI assistant. Here is what I can do:\n\n' +
        '• **Reasoning & Knowledge**: Ask any conceptual, scientific, or educational question.\n' +
        '• **Calculations**: Say *"calculate 245 multiplied by 18"* or *"what is 15% of 850"*\n' +
        '• **Web Navigation**: Say *"open YouTube"*, *"open Google"*, or *"open Gmail"*\n' +
        '• **Web Search**: Say *"search Google for Android IDEs"* or *"find tutorials on Java"*\n' +
        '• **Message Drafting**: Say *"draft a WhatsApp message saying I will be late"*\n' +
        '• **Translation & Text**: Say *"translate Hello into Bengali"* or *"summarize this"*\n' +
        '• **Voice Interaction**: Tap the microphone to talk with speech recognition & audio synthesis.';

      return {
        spokenText: 'I am ELYSIA, your personal assistant. I can answer questions, calculate math, navigate the web, draft messages, translate languages, and help you build software.',
        displayText: helpText,
        action: { type: 'info' },
        state: 'SPEAKING',
      };
    }

    // 4. Mathematics & Safe Calculations
    const calcMatch = lower.match(/^(?:calculate|compute|solve|what is|how much is)\s+(.+)$/i);
    const mathCandidate = calcMatch ? calcMatch[1] : lower;

    // Check if expression looks mathematical (has numbers and math tokens or keywords)
    const hasMathIndicators = /[\d]/.test(mathCandidate) && (
      /[\+\-\*\/\^\%]/.test(mathCandidate) ||
      /\b(?:multiplied\s+by|times|divided\s+by|plus|minus|percent\s+of|%\s+of|square\s+root)\b/.test(mathCandidate)
    );

    if (hasMathIndicators) {
      // Clean query for math evaluator
      const cleanExpr = mathCandidate.replace(/\?+$/, '').trim();
      const evalResult = SafeCalculator.evaluate(cleanExpr);

      if (evalResult.success && evalResult.result !== undefined) {
        const resStr = String(evalResult.result);
        return {
          spokenText: `The result is ${resStr}.`,
          displayText: `🔢 Calculation:\n\`${cleanExpr}\` = **${resStr}**`,
          action: {
            type: 'calculation',
            expression: cleanExpr,
            calculationResult: resStr,
          },
          state: 'SPEAKING',
        };
      }
    }

    // 5. Web Navigation commands
    const navMatch = lower.match(/^open\s+([a-z0-9\s._-]+)$/i);
    if (navMatch) {
      const destination = navMatch[1].trim();
      let targetUrl = '';
      let serviceName = '';

      if (destination.includes('youtube')) {
        targetUrl = 'https://www.youtube.com';
        serviceName = 'YouTube';
      } else if (destination.includes('gmail')) {
        targetUrl = 'https://mail.google.com';
        serviceName = 'Gmail';
      } else if (destination.includes('maps') || destination.includes('google maps')) {
        targetUrl = 'https://maps.google.com';
        serviceName = 'Google Maps';
      } else if (destination.includes('whatsapp') || destination.includes('whatsapp web')) {
        targetUrl = 'https://web.whatsapp.com';
        serviceName = 'WhatsApp Web';
      } else if (destination.includes('google')) {
        targetUrl = 'https://www.google.com';
        serviceName = 'Google';
      } else if (destination.includes('github')) {
        targetUrl = 'https://github.com';
        serviceName = 'GitHub';
      } else if (destination.startsWith('http://') || destination.startsWith('https://')) {
        targetUrl = destination;
        serviceName = destination;
      } else if (destination.includes('.com') || destination.includes('.org') || destination.includes('.io')) {
        targetUrl = `https://${destination}`;
        serviceName = destination;
      }

      if (targetUrl) {
        return {
          spokenText: `Opening ${serviceName}.`,
          displayText: `🌐 Ready to navigate to **${serviceName}**.\n\nTap below to open in your browser or application.`,
          action: {
            type: 'navigation',
            targetUrl,
          },
          state: 'SPEAKING',
        };
      }
    }

    // 6. Search commands
    const searchMatch = lower.match(/^(?:search\s+(?:google\s+)?for|find\s+tutorials?\s+(?:about|on)|search\s+for|google|look\s+up)\s+(.+)$/i);
    if (searchMatch) {
      const query = searchMatch[1].trim();
      const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
      return {
        spokenText: `Searching for ${query}.`,
        displayText: `🔍 Search Query: **"${query}"**\n\nTap below to view Google search results.`,
        action: {
          type: 'search',
          query,
          targetUrl: searchUrl,
        },
        state: 'SPEAKING',
      };
    }

    // 7. Message Drafting (WhatsApp / SMS)
    const draftMatch = lower.match(/^draft\s+(?:a\s+)?(?:whatsapp\s+|sms\s+|text\s+)?message(?:\s+to\s+([^:]+?))?(?:\s+saying\s+|\s*:\s*|\s+that\s+)(.+)$/i);
    if (draftMatch) {
      const recipient = draftMatch[1] ? draftMatch[1].trim() : 'Contact';
      const draftBody = draftMatch[2].trim();
      const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(draftBody)}`;

      return {
        spokenText: `I have prepared a message draft for you. Review the text before sending.`,
        displayText: `📝 **Message Draft Prepared**\n\nRecipient: *${recipient}*\n> "${draftBody}"\n\n⚠️ *Note: As per security guidelines, messages are never sent automatically. You can copy the draft or open WhatsApp with it prefilled.*`,
        action: {
          type: 'draft',
          recipient,
          draftText: draftBody,
          targetUrl: whatsappUrl,
        },
        state: 'SPEAKING',
      };
    }

    // 8. General AI Intelligence via Gemini
    const aiResponse = await AIService.sendMessage(raw, history, language);

    if (aiResponse.success && aiResponse.text) {
      return {
        spokenText: aiResponse.text,
        displayText: aiResponse.text,
        action: { type: 'ai' },
        state: 'SPEAKING',
      };
    } else {
      const errorDetail = aiResponse.error || 'Neural link failed to respond.';
      return {
        spokenText: 'I encountered an issue processing your request through the neural network.',
        displayText: `⚠️ **ELYSIA Neural Link Notification**\n\n${errorDetail}\n\n*If running locally, ensure GEMINI_API_KEY is configured in your environment or Settings > Secrets.*`,
        action: { type: 'info' },
        state: 'ERROR',
      };
    }
  }
}
