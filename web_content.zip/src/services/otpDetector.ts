export interface OtpDetectionResult {
  code: string | null;
  url: string | null;
}

const HIGH_PRIORITY_PATTERNS = [
  // Explicit keyword preceding code
  /(?:verification\s*code|security\s*code|login\s*code|confirmation\s*code|passcode|one-time\s*(?:passcode|password)|auth\s*code|pin\s*code|otp\s*code|otp|pin|token)[:\s\-\–=is]{1,8}([0-9]{4,8})\b/i,
  // "Your [Service] code is 123456"
  /(?:your\s+(?:[a-z0-9_-]+\s+)?code\s+is\s+[:\s]*)([0-9]{4,8})\b/i,
  // "is your verification code" or "is your [Service] code"
  /\b([0-9]{4,8})\s+(?:is\s+your\s+(?:verification|security|confirmation|login|one-time)?\s*code)/i,
  // Formatted codes like G-123456, FB-12345, 123-456
  /\b([A-Z]{1,3}-[0-9]{4,8})\b/i,
  /\b([0-9]{3}-[0-9]{3})\b/,
  /\b([0-9]{3}\s+[0-9]{3})\b/,
  // HTML emphasized tags containing 4-8 digit codes (e.g. <span style="...">123456</span> or <b>123456</b>)
  /<(?:strong|b|h1|h2|h3|span|div)[^>]*>\s*([0-9]{4,8})\s*<\/(?:strong|b|h1|h2|h3|span|div)>/i,
  // "enter 123456 to verify"
  /(?:enter|use|with|code)\s+([0-9]{4,8})\s+(?:to\s+(?:verify|login|confirm|authenticate|continue|activate))/i,
  // Generic 6-digit standalone if surrounded by punctuation or whitespace
  /(?:^|[^0-9])([0-9]{6})(?:[^0-9]|$)/,
  // Generic 5-digit standalone (Telegram, etc.)
  /(?:^|[^0-9])([0-9]{5})(?:[^0-9]|$)/,
  // Generic 4-digit standalone (Uber, etc.)
  /(?:^|[^0-9])([0-9]{4})(?:[^0-9]|$)/,
];

const URL_PATTERNS = [
  /(https?:\/\/[^\s<>"']+(?:verify|confirm|activation|token|auth|validate|action)[^\s<>"']*)/i,
  /(https?:\/\/[^\s<>"']{12,})/i,
];

export function detectOtpAndLinks(text: string): OtpDetectionResult {
  if (!text) return { code: null, url: null };

  let code: string | null = null;
  for (const pattern of HIGH_PRIORITY_PATTERNS) {
    const match = text.match(pattern);
    if (match && match[1]) {
      const candidate = match[1].trim();
      // Ensure candidate isn't a common year like 2024, 2025, 2026 unless specifically preceded by code keyword
      if (['2024', '2025', '2026', '2027'].includes(candidate) && !/code|otp|pin/i.test(match[0])) {
        continue;
      }
      code = candidate;
      break;
    }
  }

  let url: string | null = null;
  for (const pattern of URL_PATTERNS) {
    const match = text.match(pattern);
    if (match && match[1]) {
      // Clean trailing punctuation
      url = match[1].replace(/[.,;:)\]>]+$/, '');
      break;
    }
  }

  return { code, url };
}
