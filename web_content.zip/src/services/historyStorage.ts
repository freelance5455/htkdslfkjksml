export interface HistoryItem {
  id: string;
  timestamp: number;
  type: 'standard' | 'scientific' | 'ai' | 'finance' | 'formula' | 'unit';
  title?: string;
  expression: string;
  result: string;
  details?: string;
  numericResult?: number;
}

const STORAGE_KEY = 'vip_calculator_history_v1';
const MAX_HISTORY = 100;

export const historyStorage = {
  getAll(): HistoryItem[] {
    if (typeof window === 'undefined') return [];
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  add(item: Omit<HistoryItem, 'id' | 'timestamp'>): HistoryItem {
    const newItem: HistoryItem = {
      ...item,
      id: 'vip_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      timestamp: Date.now(),
    };

    try {
      const current = this.getAll();
      const updated = [newItem, ...current].slice(0, MAX_HISTORY);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save to history', e);
    }

    return newItem;
  },

  delete(id: string) {
    try {
      const current = this.getAll();
      const updated = current.filter(item => item.id !== id);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to delete history item', e);
    }
  },

  clear() {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.warn('Failed to clear history', e);
    }
  },

  exportToText(): string {
    const list = this.getAll();
    if (list.length === 0) return 'VIP Calculator History Tape is empty.';

    const lines: string[] = [
      '========================================',
      'VIP CALCULATOR – HISTORY TAPE EXPORT',
      `Exported: ${new Date().toLocaleString()}`,
      '========================================\n',
    ];

    list.forEach((item, idx) => {
      const date = new Date(item.timestamp).toLocaleTimeString();
      lines.push(`[${idx + 1}] ${date} [${item.type.toUpperCase()}]`);
      if (item.title) lines.push(`Title: ${item.title}`);
      lines.push(`Expression: ${item.expression}`);
      lines.push(`Result:     ${item.result}`);
      if (item.details) lines.push(`Details:    ${item.details}`);
      lines.push('----------------------------------------');
    });

    return lines.join('\n');
  },
};
