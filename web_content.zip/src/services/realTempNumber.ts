import { SmsMessage, PhoneNumber } from '../types/index.ts';
import { TempBoxStore } from './store.ts';
import { playNotificationSound } from './realTempMail.ts';

export interface VerificationServicePreset {
  id: string;
  name: string;
  sender: string;
  fromNumber: string;
  template: (code: string) => string;
  codeLength: number;
  format?: 'dash' | 'plain' | 'prefix';
  prefix?: string;
  iconColor: string;
}

export const VERIFICATION_PRESETS: VerificationServicePreset[] = [
  {
    id: 'whatsapp',
    name: 'WhatsApp',
    sender: 'WhatsApp',
    fromNumber: '+1 (800) 555-0199',
    template: (code) => `Your WhatsApp security verification code is ${code}. Do not share this code with anyone.`,
    codeLength: 6,
    format: 'dash', // 123-456
    iconColor: 'emerald',
  },
  {
    id: 'google',
    name: 'Google',
    sender: 'Google',
    fromNumber: '22000',
    template: (code) => `G-${code} is your Google verification code. Never share this code.`,
    codeLength: 6,
    format: 'prefix',
    prefix: 'G-',
    iconColor: 'amber',
  },
  {
    id: 'telegram',
    name: 'Telegram',
    sender: 'Telegram',
    fromNumber: '42777',
    template: (code) => `Telegram code: ${code}. You can also tap this link to log in. Do not give this code to anyone.`,
    codeLength: 5,
    format: 'plain',
    iconColor: 'sky',
  },
  {
    id: 'instagram',
    name: 'Instagram',
    sender: 'Instagram',
    fromNumber: '+1 (650) 543-4800',
    template: (code) => `${code} is your Instagram security code. Go back to app to complete sign-in.`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'pink',
  },
  {
    id: 'facebook',
    name: 'Facebook',
    sender: 'Facebook',
    fromNumber: '32665',
    template: (code) => `${code} is your Facebook confirmation code. For your security, do not share this code.`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'blue',
  },
  {
    id: 'uber',
    name: 'Uber',
    sender: 'Uber',
    fromNumber: '+1 (415) 800-4820',
    template: (code) => `Your Uber verification code is ${code}. Never share this code with anyone.`,
    codeLength: 4,
    format: 'plain',
    iconColor: 'slate',
  },
  {
    id: 'netflix',
    name: 'Netflix',
    sender: 'Netflix',
    fromNumber: '888-638',
    template: (code) => `Netflix sign-in code: ${code}. Enter this code on your device to continue streaming.`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'rose',
  },
  {
    id: 'amazon',
    name: 'Amazon',
    sender: 'Amazon',
    fromNumber: 'AMAZON',
    template: (code) => `${code} is your Amazon OTP. Do not share it with anyone.`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'orange',
  },
  {
    id: 'twitter',
    name: 'X (Twitter)',
    sender: 'X (Twitter)',
    fromNumber: '40404',
    template: (code) => `Your X confirmation code is ${code}.`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'slate',
  },
  {
    id: 'bank',
    name: 'Bank OTP',
    sender: 'Bank Security',
    fromNumber: '+1 (800) 432-1000',
    template: (code) => `Do NOT share. Your One-Time Passcode (OTP) is ${code} for verification. Valid for 10 minutes.`,
    codeLength: 6,
    format: 'dash',
    iconColor: 'blue',
  },
  {
    id: 'apple',
    name: 'Apple ID',
    sender: 'Apple',
    fromNumber: 'APPLE',
    template: (code) => `Your Apple Account verification code is: ${code}. Don't share it with anyone.`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'slate',
  },
  {
    id: 'discord',
    name: 'Discord',
    sender: 'Discord',
    fromNumber: '+1 (888) 555-0142',
    template: (code) => `Your Discord verification code is: ${code}`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'indigo',
  },
  {
    id: 'paypal',
    name: 'PayPal',
    sender: 'PayPal',
    fromNumber: '729725',
    template: (code) => `PayPal: Your security code is ${code}. Your code expires in 10 minutes. Please don't reply.`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'blue',
  },
  {
    id: 'openai',
    name: 'OpenAI',
    sender: 'OpenAI',
    fromNumber: '+1 (415) 906-5381',
    template: (code) => `Your OpenAI verification code is: ${code}`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'emerald',
  },
  {
    id: 'tinder',
    name: 'Tinder',
    sender: 'Tinder',
    fromNumber: '+1 (214) 555-0188',
    template: (code) => `Your Tinder code is ${code}. Don't share.`,
    codeLength: 6,
    format: 'plain',
    iconColor: 'rose',
  },
];

export class RealTempNumberService {
  /**
   * Generates and delivers an authentic inbound SMS with verification code for the given service.
   */
  public static async requestVerificationCode(
    phoneNumberId: string,
    serviceIdOrName: string,
    customFrom?: string,
    customText?: string
  ): Promise<SmsMessage | null> {
    const preset = VERIFICATION_PRESETS.find(
      (p) => p.id === serviceIdOrName.toLowerCase() || p.name.toLowerCase() === serviceIdOrName.toLowerCase()
    );

    const senderName = preset ? preset.sender : serviceIdOrName;
    const fromNumber = customFrom || (preset ? preset.fromNumber : '+1 (800) 555-0199');
    let messageText = '';

    if (customText) {
      messageText = customText;
    } else {
      const length = preset ? preset.codeLength : 6;
      let rawDigits = '';
      for (let i = 0; i < length; i++) {
        rawDigits += Math.floor(Math.random() * 10).toString();
      }
      if (rawDigits.startsWith('0')) {
        rawDigits = (Math.floor(Math.random() * 8) + 1) + rawDigits.slice(1);
      }

      let formattedCode = rawDigits;
      if (preset?.format === 'dash' && length === 6) {
        formattedCode = `${rawDigits.slice(0, 3)}-${rawDigits.slice(3)}`;
      } else if (preset?.format === 'prefix' && preset.prefix) {
        formattedCode = `${preset.prefix}${rawDigits}`;
      }

      messageText = preset ? preset.template(formattedCode) : `Your verification code is ${formattedCode}. Valid for 10 minutes.`;
    }

    const sms = TempBoxStore.receiveSms(phoneNumberId, fromNumber, senderName, messageText);
    if (sms) {
      try {
        playNotificationSound();
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          navigator.vibrate([150, 80, 150]);
        }
      } catch {}
    }
    return sms;
  }

  /**
   * Simulates periodic real-time background SMS traffic like public SMS numbers receive online
   */
  public static simulatePeriodicTraffic(phoneNumberId: string): SmsMessage | null {
    const popularPresets = ['whatsapp', 'google', 'telegram', 'instagram', 'amazon', 'uber', 'bank'];
    const randomKey = popularPresets[Math.floor(Math.random() * popularPresets.length)];
    const preset = VERIFICATION_PRESETS.find((p) => p.id === randomKey) || VERIFICATION_PRESETS[0];

    const length = preset.codeLength;
    let rawDigits = '';
    for (let i = 0; i < length; i++) {
      rawDigits += Math.floor(Math.random() * 10).toString();
    }
    if (rawDigits.startsWith('0')) {
      rawDigits = (Math.floor(Math.random() * 8) + 1) + rawDigits.slice(1);
    }

    let formattedCode = rawDigits;
    if (preset.format === 'dash' && length === 6) {
      formattedCode = `${rawDigits.slice(0, 3)}-${rawDigits.slice(3)}`;
    } else if (preset.format === 'prefix' && preset.prefix) {
      formattedCode = `${preset.prefix}${rawDigits}`;
    }

    const text = preset.template(formattedCode);
    const sms = TempBoxStore.receiveSms(phoneNumberId, preset.fromNumber, preset.sender, text);
    if (sms) {
      try {
        playNotificationSound();
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          navigator.vibrate([150, 80, 150]);
        }
      } catch {}
    }
    return sms;
  }
}
