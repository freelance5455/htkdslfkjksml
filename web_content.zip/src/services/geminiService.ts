import { AIMode } from '../types';

export interface GeminiResponse<T> {
  data: T | null;
  error?: string;
  isFallback?: boolean;
}

export interface BackendHealthResponse {
  hasKey: boolean;
  hasServerKey?: boolean;
  hasCustomKey?: boolean;
  defaultModel: string;
  status: string;
  version?: string;
}

export interface TestKeyResult {
  success: boolean;
  model?: string;
  source?: 'custom' | 'server';
  error?: string;
}

export interface KeyValidationResult {
  isValid: boolean;
  error?: string;
  cleanedKey?: string;
}

const CUSTOM_KEY_STORAGE_KEY = 'gemini_custom_api_key';

/**
 * Validates the format of a Gemini API Key before saving or sending.
 * Standard Google Gemini API keys start with 'AIza' (typically 'AIzaSy')
 * and are exactly 39 characters long (alphanumeric, hyphens, underscores).
 */
export function validateGeminiApiKey(key: string | null | undefined): KeyValidationResult {
  if (!key || typeof key !== 'string') {
    return { isValid: false, error: 'API-nyckeln får inte vara tom.' };
  }

  const trimmed = key.trim();
  if (!trimmed) {
    return { isValid: false, error: 'API-nyckeln får inte vara tom.' };
  }

  // Reject internal spaces or linebreaks
  if (/\s/.test(trimmed)) {
    return {
      isValid: false,
      error: 'Ogiltigt format: API-nyckeln får inte innehålla mellanslag eller radbrytningar.',
    };
  }

  // Must begin with AIza
  if (!trimmed.startsWith('AIza')) {
    return {
      isValid: false,
      error: 'Ogiltigt prefix: En giltig Google Gemini API-nyckel ska börja med "AIza" (t.ex. "AIzaSy...").',
    };
  }

  // Check valid character set: alphanumeric, underscores, hyphens
  if (!/^AIza[0-9A-Za-z_-]+$/.test(trimmed)) {
    return {
      isValid: false,
      error: 'Ogiltiga tecken: Nyckeln får endast innehålla bokstäver, siffror, bindestreck och understreck.',
    };
  }

  // Standard length is 39 characters; allow 35-45 to accommodate Google format adjustments
  if (trimmed.length < 35 || trimmed.length > 45) {
    return {
      isValid: false,
      error: `Ogiltig längd (${trimmed.length} tecken): En standard Gemini API-nyckel är 39 tecken lång.`,
    };
  }

  return { isValid: true, cleanedKey: trimmed };
}

/**
 * Retrieves the custom Gemini API key from local storage (decoding from obfuscation).
 */
export function getCustomApiKey(): string | null {
  try {
    const raw = localStorage.getItem(CUSTOM_KEY_STORAGE_KEY);
    if (!raw) return null;
    return decodeURIComponent(atob(raw));
  } catch {
    return null;
  }
}

/**
 * Stores or clears the custom Gemini API key in local storage with basic obfuscation.
 * Validates format before saving to prevent invalid calls.
 */
export function setCustomApiKey(key: string | null): { success: boolean; error?: string } {
  try {
    if (!key || !key.trim()) {
      localStorage.removeItem(CUSTOM_KEY_STORAGE_KEY);
      return { success: true };
    }

    const validation = validateGeminiApiKey(key);
    if (!validation.isValid) {
      return { success: false, error: validation.error };
    }

    const validKey = validation.cleanedKey || key.trim();
    localStorage.setItem(CUSTOM_KEY_STORAGE_KEY, btoa(encodeURIComponent(validKey)));
    return { success: true };
  } catch (err) {
    console.error('Failed to save custom API key:', err);
    return { success: false, error: 'Kunde inte spara API-nyckeln i webbläsarens lagring.' };
  }
}

/**
 * Checks whether a custom API key is currently saved.
 */
export function hasCustomApiKey(): boolean {
  return Boolean(getCustomApiKey());
}

/**
 * Mask an API key for safe display in the UI (e.g. AIzaSy...4x8Q).
 */
export function maskApiKey(key: string): string {
  if (!key) return '';
  if (key.length <= 8) return '••••••••';
  return `${key.slice(0, 6)}••••••••${key.slice(-4)}`;
}

/**
 * Returns standard API request headers including custom API key if present.
 */
function getApiHeaders(overrideKey?: string): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  const key = overrideKey !== undefined ? overrideKey : getCustomApiKey();
  if (key && key.trim()) {
    headers['x-gemini-api-key'] = key.trim();
  }
  return headers;
}

export const geminiService = {
  validateGeminiApiKey,
  validateApiKey: validateGeminiApiKey,
  getCustomApiKey,
  setCustomApiKey,
  hasCustomApiKey,
  maskApiKey,

  // Check health & backend availability
  async checkBackend(overrideKey?: string): Promise<BackendHealthResponse> {
    try {
      const res = await fetch('/api/health', {
        headers: getApiHeaders(overrideKey),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch {
      return { hasKey: false, defaultModel: 'gemini-3.8-flash', status: 'offline' };
    }
  },

  // Test an API key explicitly against the server verification endpoint
  async testApiKey(keyToTest?: string): Promise<TestKeyResult> {
    try {
      const headers = getApiHeaders(keyToTest);
      const res = await fetch('/api/gemini/test-key', {
        method: 'POST',
        headers,
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || `HTTP ${res.status}: Kunde inte verifiera API-nyckeln`,
        };
      }
      return {
        success: true,
        model: data.model,
        source: data.source,
      };
    } catch (err) {
      return {
        success: false,
        error: err instanceof Error ? err.message : 'Nätverksfel vid test av nyckel',
      };
    }
  },

  // Generate / Freeform prompt
  async generate(prompt: string, model: string = 'gemini-3.8-flash', systemInstruction?: string): Promise<string> {
    const res = await fetch('/api/gemini/generate', {
      method: 'POST',
      headers: getApiHeaders(),
      body: JSON.stringify({ prompt, model, systemInstruction }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Nätverksfel vid kommunikation med Gemini backend' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    const data = await res.json();
    return data.result;
  },

  // Auto-builder expansion
  async autoBuild(idea: string, language: string = 'sv', model: string = 'gemini-3.8-flash'): Promise<any> {
    const res = await fetch('/api/gemini/auto-build', {
      method: 'POST',
      headers: getApiHeaders(),
      body: JSON.stringify({ idea, language, model }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Auto-build API fel' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    return await res.json();
  },

  // Prompt Enhancer Pro
  async enhance(prompt: string, mode: string, language: string = 'sv', model: string = 'gemini-3.8-flash'): Promise<any> {
    const res = await fetch('/api/gemini/enhance', {
      method: 'POST',
      headers: getApiHeaders(),
      body: JSON.stringify({ prompt, mode, language, model }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Enhance API fel' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    return await res.json();
  },

  // Interactive Interview
  async interview(idea: string, history: any[], action: 'next' | 'finalize' = 'next', language: string = 'sv', model: string = 'gemini-3.8-flash'): Promise<any> {
    const res = await fetch('/api/gemini/interview', {
      method: 'POST',
      headers: getApiHeaders(),
      body: JSON.stringify({ idea, history, action, language, model }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Interview API fel' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    return await res.json();
  },

  // Storyboard Creator
  async storyboard(concept: string, sceneCount: number = 6, style: string = 'Cinematic', language: string = 'sv', model: string = 'gemini-3.8-flash'): Promise<any> {
    const res = await fetch('/api/gemini/storyboard', {
      method: 'POST',
      headers: getApiHeaders(),
      body: JSON.stringify({ concept, sceneCount, style, language, model }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Storyboard API fel' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    const data = await res.json();
    return data.scenes;
  },

  // Continuous Video Creator
  async continuousVideo(params: {
    characterProfile: any;
    environmentRules: any;
    lockedElements: string[];
    previousScenes: any[];
    nextAction: string;
    language?: string;
    model?: string;
  }): Promise<any> {
    const res = await fetch('/api/gemini/continuous-video', {
      method: 'POST',
      headers: getApiHeaders(),
      body: JSON.stringify(params),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Continuous Video API fel' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    return await res.json();
  },

  // Multimodal Image Analysis
  async analyzeImage(imageBase64: string, mimeType: string = 'image/jpeg', language: string = 'sv', model: string = 'gemini-3.8-flash'): Promise<any> {
    const res = await fetch('/api/gemini/analyze-image', {
      method: 'POST',
      headers: getApiHeaders(),
      body: JSON.stringify({ imageBase64, mimeType, language, model }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Bildanalys API fel' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    return await res.json();
  },

  // Prompt Comparison Lab
  async comparePrompts(prompts: string[], language: string = 'sv', model: string = 'gemini-3.8-flash'): Promise<any> {
    const res = await fetch('/api/gemini/compare', {
      method: 'POST',
      headers: getApiHeaders(),
      body: JSON.stringify({ prompts, language, model }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Jämförelse API fel' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    return await res.json();
  },

  // Platform Optimizer
  async optimizePlatform(prompt: string, targetPlatform: string, mediaType: 'image' | 'video' = 'image', model: string = 'gemini-3.8-flash'): Promise<any> {
    const res = await fetch('/api/gemini/optimize-platform', {
      method: 'POST',
      headers: getApiHeaders(),
      body: JSON.stringify({ prompt, targetPlatform, mediaType, model }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Plattformsoptimeringsfel' }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    return await res.json();
  },
};
