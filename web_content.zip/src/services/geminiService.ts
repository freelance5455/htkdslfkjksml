/**
 * Gemini Service Client
 * Calls the secure backend proxy endpoint /api/chat.
 * API keys are never exposed in client-side code.
 */

import { ChatMessage } from '../types';

export interface SendMessageResponse {
  reply: string;
  mode: 'gemini-live' | 'companion-simulation' | 'standby-neural-core' | 'error-fallback';
  model?: string;
  geminiActive: boolean;
  timestamp: string;
  isQuota?: boolean;
  quotaNotice?: string;
  error?: string;
}

/**
 * Resolves the backend API base URL for both Web and Android APK WebView environments.
 * When packaged into an Android APK, local files (file://) cannot handle relative API paths,
 * so this routes to the configured Cloud server where server.ts is hosted securely.
 */
export function getApiBaseUrl(): string {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('002_backend_api_url');
    if (saved && saved.trim()) {
      return saved.trim().replace(/\/$/, '');
    }
  }

  // Check Vite build environment variable
  const envUrl = (import.meta as any).env?.VITE_API_URL;
  if (envUrl && typeof envUrl === 'string' && envUrl.trim()) {
    return envUrl.trim().replace(/\/$/, '');
  }

  // If running inside Android WebView on file://, default to the cloud instance URL
  if (typeof window !== 'undefined' && (window.location.protocol === 'file:' || window.location.origin === 'null')) {
    return 'https://ais-pre-6n6om27gitc523bvga6vzb-788403367159.asia-southeast1.run.app';
  }

  // Standard web server: relative path
  return '';
}

export function setApiBaseUrl(url: string): void {
  if (typeof window !== 'undefined') {
    if (!url || !url.trim()) {
      localStorage.removeItem('002_backend_api_url');
    } else {
      localStorage.setItem('002_backend_api_url', url.trim().replace(/\/$/, ''));
    }
  }
}

export async function sendChatMessage(
  message: string,
  history: ChatMessage[]
): Promise<SendMessageResponse> {
  try {
    const baseUrl = getApiBaseUrl();
    const response = await fetch(`${baseUrl}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        history: history.map(h => ({
          sender: h.sender,
          text: h.text,
        })),
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || `Server responded with ${response.status}`);
    }

    const data: SendMessageResponse = await response.json();
    return data;
  } catch (err: any) {
    console.warn('Network or server error during companion chat:', err);
    // Graceful client fallback if server endpoint is unreachable
    return {
      reply: "Darling! My neural link wavered for a moment, but I'm still right here beside you. Could you say that again?",
      mode: 'error-fallback',
      model: 'gemini-3.8-flash',
      geminiActive: false,
      timestamp: new Date().toISOString(),
      error: err?.message || 'Network failure',
    };
  }
}

export async function checkServerStatus(): Promise<{
  status: string;
  companion: string;
  model?: string;
  hasGeminiKey: boolean;
  isQuotaExhausted?: boolean;
}> {
  try {
    const baseUrl = getApiBaseUrl();
    const res = await fetch(`${baseUrl}/api/health`);
    if (!res.ok) throw new Error('Health check failed');
    return await res.json();
  } catch {
    return {
      status: 'offline-mode',
      companion: '002 AI',
      model: 'gemini-3.8-flash',
      hasGeminiKey: false,
      isQuotaExhausted: false,
    };
  }
}
