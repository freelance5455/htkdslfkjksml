import { TikTokVideoData } from '../types/tiktok';

const TIKWM_API = 'https://www.tikwm.com/api/';

// Helper to extract clean TikTok URL from text or pasted content
export function cleanTikTokUrl(input: string): string {
  const trimmed = input.trim();
  const match = trimmed.match(/https?:\/\/(?:[a-zA-Z0-9_-]+\.)?tiktok\.com\/[^\s]+/i);
  if (match) {
    return match[0].split('?')[0]; // Clean query parameters if any, or keep essential
  }
  return trimmed;
}

export function isValidTikTokUrl(url: string): boolean {
  if (!url) return false;
  const pattern = /(?:https?:\/\/)?(?:www\.|m\.|vm\.|vt\.|t\.)?tiktok\.com\//i;
  return pattern.test(url);
}

// Built-in working sample URLs for quick testing
export const SAMPLE_VIDEOS = [
  {
    label: 'Nature / Scenic 🌲',
    url: 'https://www.tiktok.com/@myrelatablepagee/video/7678522209228344608'
  },
  {
    label: 'Viral Trends ✨',
    url: 'https://www.tiktok.com/@tiktok/video/7106594312292453678'
  },
  {
    label: 'Short Link (vm.tiktok) 🔗',
    url: 'https://vm.tiktok.com/ZM8example/'
  }
];

export async function fetchTikTokVideo(url: string): Promise<TikTokVideoData> {
  const targetUrl = cleanTikTokUrl(url);

  if (!isValidTikTokUrl(targetUrl)) {
    throw new Error('Please enter a valid TikTok video URL (e.g. https://www.tiktok.com/@user/video/...)');
  }

  try {
    // Attempt 1: POST request to TikWM (most reliable)
    const formData = new URLSearchParams();
    formData.append('url', targetUrl);
    formData.append('hd', '1');

    const res = await fetch(TIKWM_API, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
      },
      body: formData
    });

    if (!res.ok) {
      throw new Error(`Server returned HTTP ${res.status}`);
    }

    const data = await res.json();

    if (data.code === 0 && data.data) {
      return data.data as TikTokVideoData;
    }

    // Attempt 2 fallback: GET request to TikWM with hd=1
    const fallbackRes = await fetch(`${TIKWM_API}?url=${encodeURIComponent(targetUrl)}&hd=1`, {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });

    if (fallbackRes.ok) {
      const fallbackData = await fallbackRes.json();
      if (fallbackData.code === 0 && fallbackData.data) {
        return fallbackData.data as TikTokVideoData;
      }
    }

    throw new Error(data.msg || 'Failed to parse video. The video might be private, deleted, or age-restricted.');
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Network error occurred while fetching video.';
    throw new Error(message);
  }
}

// Helper to trigger browser download directly
export async function downloadMediaFile(
  mediaUrl: string,
  filename: string,
  onProgress?: (percent: number) => void
): Promise<void> {
  try {
    onProgress?.(10);
    // Fetch media stream
    const response = await fetch(mediaUrl, { mode: 'cors' });
    if (!response.ok) throw new Error('Failed to fetch media data');

    onProgress?.(50);
    const blob = await response.blob();
    onProgress?.(90);

    const blobUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(blobUrl);
    onProgress?.(100);
  } catch {
    // Fallback: direct window open or download attribute
    const link = document.createElement('a');
    link.href = mediaUrl;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onProgress?.(100);
  }
}

export function formatNumber(num?: number): string {
  if (num === undefined || num === null) return '0';
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
}

export function formatDuration(seconds?: number): string {
  if (!seconds) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}
