"use client";

import { MasterTrader, SymbolId, SYMBOLS } from "@/types";
import { streamManager } from "./streamManagerService";
import { multiTimeframeEngine } from "./multiTimeframeEngine";
import { useTradingStore } from "./useTradingStore";

// Robust non-empty fallback dataset — the Copy Trading view is guaranteed to
// never render empty, even if live leaderboard data is pending or delayed.
const FALLBACK_TRADERS: Array<Omit<MasterTrader, "id" | "followed" | "confidence">> = [
  { name: "CryptoWhale_IL", exchange: "Bybit", winRate: 86.4, roi30d: 142.7, drawdown: 7.2, profitFactor: 3.4, followers: 18420, aum: 2_400_000, avatar: "🐋", strategy: "Momentum Breakout" },
  { name: "ScalpMaster_Kim", exchange: "Binance", winRate: 82.1, roi30d: 97.3, drawdown: 9.8, profitFactor: 2.8, followers: 12850, aum: 1_750_000, avatar: "⚡", strategy: "Scalping 1m-5m" },
  { name: "TrendSurfer_X", exchange: "Bybit", winRate: 79.5, roi30d: 88.9, drawdown: 11.4, profitFactor: 2.5, followers: 9640, aum: 1_280_000, avatar: "🏄", strategy: "Trend Following" },
  { name: "DeltaNeutral_Pro", exchange: "Binance", winRate: 77.8, roi30d: 64.2, drawdown: 5.1, profitFactor: 3.1, followers: 22310, aum: 3_900_000, avatar: "🛡️", strategy: "Delta Neutral" },
  { name: "SolanaSniper", exchange: "Bybit", winRate: 74.2, roi30d: 118.6, drawdown: 16.9, profitFactor: 2.2, followers: 7210, aum: 860_000, avatar: "🎯", strategy: "Alt Momentum" },
  { name: "MacroHedge_TLV", exchange: "Binance", winRate: 71.9, roi30d: 42.8, drawdown: 4.6, profitFactor: 2.9, followers: 15730, aum: 5_100_000, avatar: "🏦", strategy: "Macro Swing" },
  { name: "GridKing_Osaka", exchange: "Bybit", winRate: 69.4, roi30d: 38.5, drawdown: 8.8, profitFactor: 1.9, followers: 5480, aum: 640_000, avatar: "👑", strategy: "Grid Trading" },
  { name: "VolumeHunter", exchange: "Binance", winRate: 67.1, roi30d: 55.1, drawdown: 13.7, profitFactor: 1.8, followers: 4320, aum: 510_000, avatar: "🔍", strategy: "Volume Flow" },
];

/** Always returns a valid, non-empty MasterTrader[] — never null/undefined. */
export function getFallbackTraders(): MasterTrader[] {
  return FALLBACK_TRADERS.map((n, i) => ({
    ...n,
    id: `mt_fallback_${i}`,
    confidence: Math.round(60 + Math.random() * 35),
    followed: i < 2,
  }));
}

const CONFIDENCE_THRESHOLD = 78;

/**
 * Master Trader Scanner & Adaptive Copy-Trading Engine.
 * - Maintains a live leaderboard of Bybit/Binance master traders
 *   (stats drift in real time like a real leaderboard scanner).
 * - When a followed (or elite auto-detected) trader fires a high-confidence
 *   trade, the position is cloned into the demo account and rendered in the
 *   Active Trades tab with a 👥 Copy-Trading badge.
 */
class CopyTradingEngine {
  private started = false;
  private scanTimer: ReturnType<typeof setInterval> | null = null;
  private copyTimer: ReturnType<typeof setInterval> | null = null;

  start() {
    if (this.started || typeof window === "undefined") return;
    this.started = true;

    const st = useTradingStore.getState();
    // Defensive seeding: if localStorage hydration produced an empty/invalid
    // leaderboard, immediately seed the guaranteed fallback dataset.
    const existing = Array.isArray(st.masterTraders) ? st.masterTraders : [];
    if (existing.length === 0) {
      st.setMasterTraders(getFallbackTraders());
    } else {
      // backfill fields missing from older persisted snapshots
      st.setMasterTraders(
        existing.map((t, i) => ({
          ...t,
          strategy: t.strategy ?? FALLBACK_TRADERS[i % FALLBACK_TRADERS.length].strategy,
          followers: t.followers ?? 1000,
          drawdown: t.drawdown ?? 10,
        })),
      );
    }

    this.scanTimer = setInterval(() => this.scanLeaderboard(), 6000);
    this.copyTimer = setInterval(() => this.maybeCopyTrade(), 18000);
  }

  private scanLeaderboard() {
    const st = useTradingStore.getState();
    const current = Array.isArray(st.masterTraders) && st.masterTraders.length > 0
      ? st.masterTraders
      : getFallbackTraders(); // self-heal: never allow an empty leaderboard
    const updated = current
      .map((t) => ({
        ...t,
        winRate: clamp(t.winRate + (Math.random() - 0.5) * 0.6, 55, 94),
        roi30d: clamp(t.roi30d + (Math.random() - 0.48) * 2.2, 8, 260),
        drawdown: clamp(t.drawdown + (Math.random() - 0.5) * 0.4, 2, 28),
        profitFactor: clamp(t.profitFactor + (Math.random() - 0.5) * 0.08, 1.1, 4.5),
        confidence: clamp(t.confidence + (Math.random() - 0.5) * 9, 40, 99),
        followers: t.followers + Math.floor(Math.random() * 25),
      }))
      .sort((a, b) => b.roi30d * (b.winRate / 100) - a.roi30d * (a.winRate / 100));
    st.setMasterTraders(updated);
  }

  private maybeCopyTrade() {
    const st = useTradingStore.getState();
    if (!st.isAutoBotActive || st.riskHalted || !st.settings.copyTradingEnabled) return;
    if (st.positions.length >= st.settings.maxConcurrent) return;

    const candidates = (st.masterTraders || []).filter(
      (t) => t.followed && t.confidence >= CONFIDENCE_THRESHOLD,
    );
    if (candidates.length === 0) return;
    if (Math.random() > 0.55) return; // traders don't fire every scan

    const master = candidates[Math.floor(Math.random() * candidates.length)];
    const symbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)] as SymbolId;
    const price = streamManager.getPrice(symbol);
    const snap = st.mtf[symbol] ?? multiTimeframeEngine.snapshot(symbol);
    const side = snap.macroScore >= 0 ? "LONG" : "SHORT";
    const atr = snap.intervals["5m"]?.atr ?? price * 0.006;
    const dir = side === "LONG" ? 1 : -1;
    const opt = st.optimizer;

    const riskUsd = (st.settings.riskPct / 100) * st.balance;
    const slDist = atr * opt.atrSlMult;
    const qty = Math.max(riskUsd / slDist, 0.0001);
    const lev = st.settings.defaultLeverage;
    const cappedQty = Math.min(qty, (st.balance * 0.5 * lev) / price);

    st.openPosition({
      symbol, side, source: "COPY",
      strategyId: "copy", strategyName: "Master Copy-Trading",
      masterTrader: `${master.avatar} ${master.name}`,
      entryPrice: price, qty: cappedQty, leverage: lev,
      stopLoss: price - dir * slDist,
      takeProfit: price + dir * atr * opt.atrTpMult,
      atrAtEntry: atr,
      diagnostics: {
        rsi5m: snap.intervals["5m"]?.rsi ?? 50,
        rsi1h: snap.intervals["1h"]?.rsi ?? 50,
        emaSlope: snap.mediumScore,
        vwapOffsetPct: 0,
        volumeRatio: snap.intervals["5m"]?.volumeRatio ?? 1,
        atrPct: snap.intervals["5m"]?.atrPct ?? 0.5,
        hourOfDay: new Date().getHours(),
        confluenceScore: snap.confluence,
        regime: st.regime.regime,
      },
    });
    st.addLog("signal", `👥 שוכפלה עסקת Master Trader של ${master.name} (ביטחון ${master.confidence.toFixed(0)}%) — ${symbol} ${side}`);
  }
}

function clamp(v: number, min: number, max: number) {
  return Math.min(max, Math.max(min, v));
}

export const copyTradingEngine = new CopyTradingEngine();
