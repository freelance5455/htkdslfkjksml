/**
 * History & Activity Service
 * Manages user-specific health action logs, real-time activity recording,
 * cross-session persistence, and zero-fake-data integrity.
 */

import { ScreenType, HistoryItem } from '../types';

export interface HistoryRecord extends HistoryItem {
  userId?: string;
  featureKey: string;
}

const HISTORY_STORAGE_PREFIX = 'mediguide_user_history_v3_';
const HISTORY_CLEARED_PREFIX = 'mediguide_history_cleared_at_';
const HISTORY_DELETED_IDS_PREFIX = 'mediguide_history_deleted_ids_';
const HISTORY_BOOTSTRAPPED_PREFIX = 'mediguide_history_bootstrapped_v1_';
const LAST_ACTIONS_CACHE = new Map<string, number>();

/**
 * Gets the timestamp when the user last cleared their history (or 0 if never).
 */
export function getClearedAtTimestamp(userId: string): number {
  if (!userId || typeof window === 'undefined') return 0;
  try {
    const raw = localStorage.getItem(`${HISTORY_CLEARED_PREFIX}${userId}`);
    return raw ? parseInt(raw, 10) || 0 : 0;
  } catch {
    return 0;
  }
}

/**
 * Retrieves the set of IDs that have been explicitly deleted or cleared for this user.
 */
export function getDeletedIdsSet(userId: string): Set<string> {
  if (!userId || typeof window === 'undefined') return new Set();
  try {
    const raw = localStorage.getItem(`${HISTORY_DELETED_IDS_PREFIX}${userId}`);
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

/**
 * Persists the set of deleted IDs for a user.
 */
export function saveDeletedIdsSet(userId: string, ids: Set<string>): void {
  if (!userId || typeof window === 'undefined') return;
  try {
    const arr = Array.from(ids);
    localStorage.setItem(`${HISTORY_DELETED_IDS_PREFIX}${userId}`, JSON.stringify(arr));
  } catch (err) {
    console.warn('[HistoryService] Error saving deleted ids:', err);
  }
}

/**
 * Retrieves the currently active user ID from auth session or storage.
 */
export function getCurrentActiveUserId(): string {
  if (typeof window === 'undefined') return 'usr_default_01';
  try {
    const sessionRaw = localStorage.getItem('mediguide_session_v2');
    if (sessionRaw) {
      const session = JSON.parse(sessionRaw);
      if (session.email) {
        const usersRaw = localStorage.getItem('mediguide_users_v2');
        if (usersRaw) {
          const users = JSON.parse(usersRaw);
          const found = users.find(
            (u: { email?: string; id?: string }) =>
              u.email?.toLowerCase() === session.email?.toLowerCase()
          );
          if (found?.id) return found.id;
        }
        return session.email;
      }
    }
  } catch (err) {
    console.warn('[HistoryService] Failed to parse active user session:', err);
  }
  return 'usr_default_01';
}

/**
 * Formats a timestamp into human-readable Date (e.g., "Sep 5, 2026")
 */
export function formatHistoryDate(timestamp: number | string | Date): string {
  try {
    const d = new Date(timestamp);
    if (isNaN(d.getTime())) return 'Today';
    return d.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  } catch {
    return 'Today';
  }
}

/**
 * Formats a timestamp into human-readable Time (e.g., "04:15 PM")
 */
export function formatHistoryTime(timestamp: number | string | Date): string {
  try {
    const d = new Date(timestamp);
    if (isNaN(d.getTime())) return '';
    return d.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return '';
  }
}

/**
 * Authoritative mapping of in-app features to history activity metadata.
 */
export const FEATURE_INFO_MAP: Record<
  string,
  { name: string; title: string; type: string; summary: string; status: string; tags: string[] }
> = {
  'feature-report': {
    name: 'Medical Report Analyzer',
    title: 'Medical Report Analyzer',
    type: 'report',
    summary: 'Analyzed clinical lab test parameters, observations, and authoritative health condition education.',
    status: 'Completed',
    tags: ['Medical Report', 'Lab Analysis'],
  },
  'feature-medicine': {
    name: 'Medicine Scanner',
    title: 'Medicine Scanner',
    type: 'medicine',
    summary: 'Scanned medicine to identify pharmaceutical tablets, verify safety indicators, and check dosages.',
    status: 'Verified',
    tags: ['Medicine Scanner', 'Drug Verification'],
  },
  'feature-tracker': {
    name: 'Disease Progress Tracker',
    title: 'Disease Progress Tracker',
    type: 'tracker',
    summary: 'Monitored disease stages, symptoms, and vital health trajectory.',
    status: 'Logged',
    tags: ['Progress Tracker', 'Vitals'],
  },
  'feature-reminder': {
    name: 'Medicine Reminder',
    title: 'Medicine Reminder',
    type: 'reminder',
    summary: 'Managed medication schedules, daily reminders, and dosage adherence.',
    status: 'Active',
    tags: ['Medicine Reminder', 'Schedule'],
  },
  'feature-education': {
    name: 'Health Education',
    title: 'Health Education',
    type: 'education',
    summary: 'Engaged with verified health education modules, educational videos, and medical literacy guidance.',
    status: 'Completed',
    tags: ['Health Education', 'Medical Literacy'],
  },
  'feature-emergency': {
    name: 'Emergency Services',
    title: 'Emergency Services',
    type: 'emergency',
    summary: 'Accessed 24/7 emergency response contacts, trauma centers, and urgent ambulance hotlines.',
    status: 'Urgent',
    tags: ['Emergency Services', 'Ambulance'],
  },
  'feature-services': {
    name: 'Health Services',
    title: 'Health Services',
    type: 'services',
    summary: 'Checked nearby verified pharmacies, medicine stock, and local health services.',
    status: 'Completed',
    tags: ['Health Services', 'Pharmacy Stock'],
  },
};

/**
 * Records a real history entry when the user actually opens or uses an existing feature.
 */
export function recordFeatureAccess(screen: ScreenType): HistoryItem | null {
  const info = FEATURE_INFO_MAP[screen];
  if (!info) return null;

  const targetUser = getCurrentActiveUserId();
  if (!targetUser || typeof window === 'undefined') return null;

  return recordUserActivity(targetUser, {
    title: info.title,
    featureName: info.name,
    type: info.type,
    summary: info.summary,
    status: info.status,
    tags: info.tags,
    screen: screen,
  });
}

/**
 * Loads all persistent history records for a specific authenticated user.
 * Filters out any entries created prior to a confirmed clear action or explicitly deleted.
 */
export function getUserHistory(userId: string): HistoryItem[] {
  if (!userId || typeof window === 'undefined') return [];
  try {
    const key = `${HISTORY_STORAGE_PREFIX}${userId}`;
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const list: HistoryItem[] = JSON.parse(raw);
    if (!Array.isArray(list)) return [];

    const clearedAt = getClearedAtTimestamp(userId);
    const deletedSet = getDeletedIdsSet(userId);

    // Filter out any entries that were deleted or cleared
    const filtered = list.filter((item) => {
      if (!item) return false;
      if (item.id && deletedSet.has(item.id)) return false;
      if (clearedAt > 0 && item.timestamp && item.timestamp < clearedAt) return false;
      return true;
    });

    // If stale items were pruned, save clean state back to storage
    if (filtered.length !== list.length) {
      localStorage.setItem(key, JSON.stringify(filtered));
    }

    // Sort descending by timestamp or date
    return filtered.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
  } catch (err) {
    console.error('[HistoryService] Error loading user history:', err);
    return [];
  }
}

/**
 * Saves history records for a specific authenticated user.
 */
export function saveUserHistory(userId: string, records: HistoryItem[]): void {
  if (!userId || typeof window === 'undefined') return;
  try {
    const key = `${HISTORY_STORAGE_PREFIX}${userId}`;
    localStorage.setItem(key, JSON.stringify(records));
    // Dispatch event so any listening UI updates immediately
    window.dispatchEvent(
      new CustomEvent('mediguide_history_updated', {
        detail: { userId, count: records.length },
      })
    );
  } catch (err) {
    console.error('[HistoryService] Error saving user history:', err);
  }
}

/**
 * Adds a new verified history entry for a user, avoiding rapid duplicates.
 */
export function recordUserActivity(
  userId: string,
  entry: {
    id?: string;
    title: string;
    featureName: string;
    type?: string;
    summary: string;
    status: string;
    tags?: string[];
    screen?: ScreenType;
    timestamp?: number;
  }
): HistoryItem | null {
  const targetUser = userId || getCurrentActiveUserId();
  if (!targetUser || typeof window === 'undefined') return null;

  const now = entry.timestamp || Date.now();
  const clearedAt = getClearedAtTimestamp(targetUser);
  // Do not record retroactive events timestamped prior to clearing
  if (clearedAt > 0 && now < clearedAt) {
    return null;
  }

  // Prevent duplicate actions within 5 seconds with identical title & feature
  const dedupeKey = `${targetUser}_${entry.featureName}_${entry.title}_${entry.status}`;
  const lastTime = LAST_ACTIONS_CACHE.get(dedupeKey);
  if (lastTime && now - lastTime < 5000) {
    return null; // Suppress duplicate trigger
  }
  LAST_ACTIONS_CACHE.set(dedupeKey, now);

  const existing = getUserHistory(targetUser);

  // If specific ID is supplied, ensure it doesn't already exist or wasn't explicitly deleted
  const deletedSet = getDeletedIdsSet(targetUser);
  if (entry.id && (deletedSet.has(entry.id) || existing.some((item) => item.id === entry.id))) {
    return null;
  }

  const newRecord: HistoryItem = {
    id: entry.id || `act_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    title: entry.title,
    featureName: entry.featureName,
    type: entry.type || 'activity',
    date: formatHistoryDate(now),
    time: formatHistoryTime(now),
    timestamp: now,
    status: entry.status,
    summary: entry.summary,
    tags: entry.tags || [entry.featureName],
    screen: entry.screen,
  };

  const updated = [newRecord, ...existing];
  saveUserHistory(targetUser, updated);
  return newRecord;
}

/**
 * Permanently removes a single history record for this specific user.
 */
export function deleteHistoryItem(userId: string, itemId: string): void {
  const targetUser = userId || getCurrentActiveUserId();
  if (!targetUser || typeof window === 'undefined') return;

  // Add to deleted set so it can never be resurrected by any sync
  const deletedSet = getDeletedIdsSet(targetUser);
  deletedSet.add(itemId);
  saveDeletedIdsSet(targetUser, deletedSet);

  const existing = getUserHistory(targetUser);
  const updated = existing.filter((item) => item.id !== itemId);
  saveUserHistory(targetUser, updated);
}

/**
 * Permanently clears all history records for a specific user from storage.
 * Records the clear timestamp and ensures pre-existing activities are not resurrected.
 */
export function clearUserHistory(userId: string): void {
  const targetUser = userId || getCurrentActiveUserId();
  if (!targetUser || typeof window === 'undefined') return;

  const now = Date.now();

  // 1. Collect all existing item IDs and mark them as permanently deleted
  const existing = getUserHistory(targetUser);
  const deletedSet = getDeletedIdsSet(targetUser);
  existing.forEach((item) => {
    if (item.id) deletedSet.add(item.id);
  });
  saveDeletedIdsSet(targetUser, deletedSet);

  // 2. Persist clear timestamp for this user in storage (slightly backdated by 100ms so new immediate actions are accepted)
  localStorage.setItem(`${HISTORY_CLEARED_PREFIX}${targetUser}`, String(now - 100));

  // 3. Mark as bootstrapped so retrospective scraping does not run for pre-clear data
  localStorage.setItem(`${HISTORY_BOOTSTRAPPED_PREFIX}${targetUser}`, 'true');

  // 4. Permanently write empty array to user's history storage
  const storageKey = `${HISTORY_STORAGE_PREFIX}${targetUser}`;
  localStorage.setItem(storageKey, JSON.stringify([]));

  // 5. Invalidate in-memory action cache for this user
  for (const cacheKey of Array.from(LAST_ACTIONS_CACHE.keys())) {
    if (cacheKey.startsWith(targetUser)) {
      LAST_ACTIONS_CACHE.delete(cacheKey);
    }
  }

  // 6. Dispatch event so all open views immediately refresh
  window.dispatchEvent(
    new CustomEvent('mediguide_history_updated', {
      detail: { userId: targetUser, count: 0, cleared: true },
    })
  );
}

/**
 * Inspects existing real data stored in localStorage for the user
 * and imports them into history without duplicating.
 * strictly respects clear actions and ignores any cleared/deleted activities.
 */
export function syncUserExistingActivities(userId: string): void {
  if (typeof window === 'undefined') return;
  const targetUser = userId || getCurrentActiveUserId();
  if (!targetUser) return;

  const isBootstrapped = localStorage.getItem(`${HISTORY_BOOTSTRAPPED_PREFIX}${targetUser}`) === 'true';
  const clearedAt = getClearedAtTimestamp(targetUser);
  const deletedSet = getDeletedIdsSet(targetUser);

  // If already bootstrapped and user cleared history, do not retroactively scrape old keys
  if (isBootstrapped && clearedAt > 0) {
    return;
  }

  const currentHistory = getUserHistory(targetUser);
  const existingIds = new Set(currentHistory.map((h) => h.id));
  const newItems: HistoryItem[] = [];

  const shouldSkip = (id: string, ts: number) => {
    if (existingIds.has(id) || deletedSet.has(id)) return true;
    if (clearedAt > 0 && ts <= clearedAt) return true;
    return false;
  };

  // 1. Sync Disease Progress Tracker records from 'saved_disease_records'
  try {
    const rawDiseases = localStorage.getItem('saved_disease_records');
    if (rawDiseases) {
      const records = JSON.parse(rawDiseases);
      if (Array.isArray(records)) {
        for (const rec of records) {
          if (!rec || !rec.name) continue;
          const recId = `hist_disease_${rec.id || rec.name}_${rec.updatedAt || rec.createdAt || 'initial'}`;
          const timeVal = rec.updatedAt || rec.createdAt || Date.now();
          const ts = new Date(timeVal).getTime() || Date.now();

          if (!shouldSkip(recId, ts)) {
            const vitalsParts: string[] = [];
            if (rec.vitals?.bloodPressure) vitalsParts.push(`BP: ${rec.vitals.bloodPressure}`);
            if (rec.vitals?.bloodSugar) vitalsParts.push(`Sugar: ${rec.vitals.bloodSugar} mg/dL`);
            if (rec.vitals?.heartRate) vitalsParts.push(`HR: ${rec.vitals.heartRate} bpm`);
            if (rec.vitals?.oxygenSpo2) vitalsParts.push(`SpO2: ${rec.vitals.oxygenSpo2}%`);

            const vitalsSummary = vitalsParts.length > 0 ? `Vitals logged (${vitalsParts.join(', ')}). ` : '';
            const stageSummary = rec.stage ? `Stage: ${rec.stage}. ` : '';

            newItems.push({
              id: recId,
              title: `${rec.name} Health Record`,
              featureName: 'Disease Progress Tracker',
              type: 'tracker',
              date: formatHistoryDate(ts),
              time: formatHistoryTime(ts),
              timestamp: ts,
              status: 'Logged',
              summary: `${vitalsSummary}${stageSummary}Condition details updated in progress tracker.`.trim(),
              tags: ['Progress Tracker', 'Vitals', rec.name],
              screen: 'feature-tracker',
            });
            existingIds.add(recId);
          }
        }
      }
    }
  } catch (err) {
    console.warn('[HistoryService] Sync disease records error:', err);
  }

  // 2. Sync Medicine Reminder doses from 'swasthyaseva_doses_v2'
  try {
    const rawDoses = localStorage.getItem('swasthyaseva_doses_v2');
    if (rawDoses) {
      const doses = JSON.parse(rawDoses);
      if (Array.isArray(doses)) {
        for (const dose of doses) {
          if (!dose || dose.status === 'pending') continue; // Only log taken or skipped doses
          const doseId = `hist_dose_${dose.id}_${dose.scheduledDate}_${dose.status}`;
          const ts = dose.actionTime ? new Date(dose.actionTime).getTime() : Date.now();

          if (!shouldSkip(doseId, ts)) {
            newItems.push({
              id: doseId,
              title: `Dose ${dose.status === 'taken' ? 'Taken' : 'Logged'}: ${dose.medicineName}`,
              featureName: 'Medicine Reminder',
              type: 'reminder',
              date: formatHistoryDate(ts),
              time: dose.scheduledTime || formatHistoryTime(ts),
              timestamp: ts,
              status: dose.status === 'taken' ? 'Completed' : 'Logged',
              summary: `${dose.dosePerTime} ${dose.medicineType || 'dose'} of ${dose.medicineName} scheduled for ${dose.scheduledTime}. Status: ${dose.status}.`,
              tags: ['Medicine Reminder', dose.medicineName, dose.status],
              screen: 'feature-reminder',
            });
            existingIds.add(doseId);
          }
        }
      }
    }
  } catch (err) {
    console.warn('[HistoryService] Sync doses error:', err);
  }

  // 3. Sync Medicine Reminder added medicines from 'swasthyaseva_medicines_v2'
  try {
    const rawMeds = localStorage.getItem('swasthyaseva_medicines_v2');
    if (rawMeds) {
      const meds = JSON.parse(rawMeds);
      if (Array.isArray(meds)) {
        for (const med of meds) {
          if (!med || !med.name) continue;
          const medId = `hist_med_${med.id || med.name}`;
          const ts = med.createdAt ? new Date(med.createdAt).getTime() : Date.now();

          if (!shouldSkip(medId, ts)) {
            newItems.push({
              id: medId,
              title: `Scheduled Medication: ${med.name}`,
              featureName: 'Medicine Reminder',
              type: 'reminder',
              date: formatHistoryDate(ts),
              time: formatHistoryTime(ts),
              timestamp: ts,
              status: med.isActive ? 'Active' : 'Completed',
              summary: `Added ${med.name} (${med.strength || 'standard dose'}, ${med.frequency}) to scheduled medication plan.`,
              tags: ['Medicine Reminder', med.name],
              screen: 'feature-reminder',
            });
            existingIds.add(medId);
          }
        }
      }
    }
  } catch (err) {
    console.warn('[HistoryService] Sync medicines error:', err);
  }

  // 4. Sync Video viewing history from 'mediguide_video_history'
  try {
    const rawVideos = localStorage.getItem('mediguide_video_history');
    if (rawVideos) {
      const vIds = JSON.parse(rawVideos);
      if (Array.isArray(vIds) && vIds.length > 0) {
        for (let i = 0; i < vIds.length; i++) {
          const vId = vIds[i];
          const histId = `hist_vid_${vId}`;
          const ts = Date.now() - (vIds.length - 1 - i) * 60000;

          if (!shouldSkip(histId, ts)) {
            newItems.push({
              id: histId,
              title: 'Health Education Video Watched',
              featureName: 'Health Education',
              type: 'education',
              date: formatHistoryDate(ts),
              time: formatHistoryTime(ts),
              timestamp: ts,
              status: 'Completed',
              summary: 'Watched verified educational health video and medical guidance session.',
              tags: ['Health Education', 'Verified Video'],
              screen: 'feature-education',
            });
            existingIds.add(histId);
          }
        }
      }
    }
  } catch (err) {
    console.warn('[HistoryService] Sync video history error:', err);
  }

  // Mark bootstrap complete for this user so we don't repeat initial import
  localStorage.setItem(`${HISTORY_BOOTSTRAPPED_PREFIX}${targetUser}`, 'true');

  if (newItems.length > 0) {
    const combined = [...newItems, ...currentHistory];
    saveUserHistory(targetUser, combined);
  }
}

/**
 * Initializes global transparent listeners for in-app user activities.
 * Ensures that whenever the user performs an action across any feature,
 * it automatically logs to the current user's history without touching other files.
 */
export function initGlobalActivityObserver(): void {
  if (typeof window === 'undefined') return;
  if ((window as any).__mediguide_history_observer_installed) return;
  (window as any).__mediguide_history_observer_installed = true;

  // 1. Safe storage interception for storage-driven features
  try {
    const originalSetItem = Storage.prototype.setItem;
    Storage.prototype.setItem = function (key: string, value: string) {
      originalSetItem.apply(this, [key, value]);
      try {
        const activeUser = getCurrentActiveUserId();

        // Disease Progress Tracker
        if (key === 'saved_disease_records') {
          try {
            const parsed = JSON.parse(value);
            if (Array.isArray(parsed) && parsed.length > 0) {
              const latest = parsed[0];
              if (latest && latest.name) {
                const vitalsParts: string[] = [];
                if (latest.vitals?.bloodPressure) vitalsParts.push(`BP: ${latest.vitals.bloodPressure}`);
                if (latest.vitals?.bloodSugar) vitalsParts.push(`Sugar: ${latest.vitals.bloodSugar} mg/dL`);
                if (latest.vitals?.oxygenSpo2) vitalsParts.push(`SpO2: ${latest.vitals.oxygenSpo2}%`);

                recordUserActivity(activeUser, {
                  title: `${latest.name} Progress Log`,
                  featureName: 'Disease Progress Tracker',
                  type: 'tracker',
                  summary: `Logged vitals (${vitalsParts.join(', ') || 'Parameters logged'}${latest.stage ? ` | Stage: ${latest.stage}` : ''}).`,
                  status: 'Logged',
                  tags: ['Progress Tracker', 'Vitals', latest.name],
                  screen: 'feature-tracker',
                });
              }
            }
          } catch {}
        }

        // Medicine Reminder Doses
        if (key === 'swasthyaseva_doses_v2') {
          try {
            const parsed = JSON.parse(value);
            if (Array.isArray(parsed)) {
              const recentTaken = parsed.find((d: any) => d.status === 'taken');
              if (recentTaken) {
                recordUserActivity(activeUser, {
                  title: `Dose Taken: ${recentTaken.medicineName}`,
                  featureName: 'Medicine Reminder',
                  type: 'reminder',
                  summary: `Confirmed ${recentTaken.dosePerTime} ${recentTaken.medicineType || 'dose'} taken at scheduled time ${recentTaken.scheduledTime}.`,
                  status: 'Completed',
                  tags: ['Medicine Reminder', recentTaken.medicineName],
                  screen: 'feature-reminder',
                });
              }
            }
          } catch {}
        }

        // Pharmacy recent search
        if (key === 'med_recent_searches') {
          try {
            const parsed = JSON.parse(value);
            if (Array.isArray(parsed) && parsed.length > 0) {
              const term = parsed[0];
              if (term && typeof term === 'string' && term.trim()) {
                recordUserActivity(activeUser, {
                  title: `Pharmacy Stock Check: ${term}`,
                  featureName: 'Nearby Pharmacy Stock',
                  type: 'pharmacy',
                  summary: `Checked local pharmacy stock and price comparisons for ${term}.`,
                  status: 'Completed',
                  tags: ['Pharmacy Stock', term],
                  screen: 'feature-services',
                });
              }
            }
          } catch {}
        }

        // Health Quiz completed
        if (key === 'mediguide_quiz_progress_v1') {
          recordUserActivity(activeUser, {
            title: 'Health Knowledge Quiz Completed',
            featureName: 'Health Education',
            type: 'education',
            summary: 'Completed interactive health education and medical literacy module.',
            status: 'Completed',
            tags: ['Health Education', 'Quiz'],
            screen: 'feature-education',
          });
        }

        // Saved Tips / Myths
        if (key === 'mediguide_saved_tips_v1') {
          recordUserActivity(activeUser, {
            title: 'Saved Daily Health Tip',
            featureName: 'Health Education',
            type: 'education',
            summary: 'Bookmarked verified clinical health guidance and daily wellness recommendation.',
            status: 'Completed',
            tags: ['Health Education', 'Health Tips'],
            screen: 'feature-education',
          });
        }

        // Emergency Hospital Search Cache
        if (key === 'emergency_hospital_results') {
          recordUserActivity(activeUser, {
            title: 'Emergency Hospital Search',
            featureName: 'Health Services',
            type: 'services',
            summary: 'Searched nearby 24/7 verified emergency medical centers and trauma care facilities.',
            status: 'Completed',
            tags: ['Health Services', 'Emergency', 'Hospitals'],
            screen: 'feature-services',
          });
        }
      } catch (err) {
        console.warn('[HistoryService] Storage intercept error:', err);
      }
    };
  } catch (err) {
    console.warn('[HistoryService] Storage prototype could not be wrapped:', err);
  }

  // 2. Listen to clicks on feature cards and phone hotlines
  document.addEventListener(
    'click',
    (e) => {
      try {
        const target = e.target as HTMLElement | null;

        // Check if user clicked any feature card from Home screen
        const featureBtn = target?.closest('[id^="home-feature-"]') as HTMLElement | null;
        if (featureBtn && featureBtn.id) {
          const screenId = featureBtn.id.replace('home-feature-', '') as ScreenType;
          recordFeatureAccess(screenId);
        }

        const checkHealthBtn = target?.closest('#home-check-health-btn');
        if (checkHealthBtn) {
          recordFeatureAccess('feature-tracker');
        }

        // Check tel: link click
        const telLink = target?.closest('a[href^="tel:"]') as HTMLAnchorElement | null;
        if (telLink) {
          const phone = telLink.getAttribute('href')?.replace('tel:', '') || '';
          recordUserActivity(getCurrentActiveUserId(), {
            title: 'Helpline Contacted',
            featureName: 'Emergency Services',
            type: 'emergency',
            summary: `Initiated emergency helpline call (${phone || 'Helpline'}).`,
            status: 'Contacted',
            tags: ['Helpline', 'Call'],
            screen: 'feature-emergency',
          });
        }
      } catch {}
    },
    true
  );

  // 3. MutationObserver on document for verified Medicine Scanner and Medical Report Analyzer results
  const observer = new MutationObserver(() => {
    try {
      // A. Look for verified Medicine Scanner results
      const verifiedBadge = document.querySelector('.bg-emerald-50.text-emerald-700');
      if (verifiedBadge && verifiedBadge.textContent?.includes('Verified Medicine')) {
        const parentCard = verifiedBadge.closest('.bg-white');
        const heading = parentCard?.querySelector('h2');
        if (heading && heading.textContent) {
          const medName = heading.textContent.trim();
          recordUserActivity(getCurrentActiveUserId(), {
            title: `Medicine Verified: ${medName}`,
            featureName: 'Medicine Scanner',
            type: 'medicine',
            summary: `Scanned and verified ${medName}. Checked dosage, indications, warnings and safety guidelines.`,
            status: 'Identified',
            tags: ['Medicine Scanner', 'Verified Drug', medName],
            screen: 'feature-medicine',
          });
        }
      }

      // B. Look for Medical Report Analyzer results
      const reportBanner = document.querySelector('.from-teal-800');
      if (reportBanner) {
        // Find condition heading if present
        const conditionBadge = document.querySelector('.bg-emerald-100.text-emerald-800, .bg-teal-100.text-teal-800');
        const reportTitle = conditionBadge?.textContent?.trim() || 'Laboratory Biomarker Report';

        recordUserActivity(getCurrentActiveUserId(), {
          title: `Medical Report: ${reportTitle}`,
          featureName: 'Medical Report Analyzer',
          type: 'report',
          summary: 'Analyzed clinical lab test parameters, observations, and authoritative health condition education.',
          status: 'Completed',
          tags: ['Medical Report', 'Diagnostics', 'Lab Report'],
          screen: 'feature-report',
        });
      }
    } catch {}
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

// Automatically initiate listeners upon module loading
if (typeof window !== 'undefined') {
  initGlobalActivityObserver();
}
