/**
 * GODEX v0.0.1 - Real Preview Runtime & Health Verification Service
 * Manages explicit preview state machine, health probes, and runtime error tracking.
 */

import { PreviewState, PreviewHealthReport, PreviewBuildError } from '../types';
import { SelfHealingEngine } from '../debugger/selfHealingEngine';
import { ExecutionResult } from '../execution/executionTypes';
import { WorkspaceService } from './workspaceService';
import { GodexEventBus } from '../godex/godexEventBus';

export class PreviewService {
  private static currentState: PreviewState = 'STARTING';
  private static lastHealthReport: PreviewHealthReport = {
    running: false,
    mounted: false,
    elementsCount: 0,
    runtimeErrors: [],
    buildError: null,
    lastChecked: Date.now()
  };

  private static listeners: Set<(state: PreviewState, report: PreviewHealthReport) => void> = new Set();

  public static subscribe(listener: (state: PreviewState, report: PreviewHealthReport) => void): () => void {
    this.listeners.add(listener);
    listener(this.currentState, this.lastHealthReport);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public static getState(): PreviewState {
    return this.currentState;
  }

  public static setState(state: PreviewState, errors: string[] = [], buildError: PreviewBuildError | null = null) {
    this.currentState = state;
    this.lastHealthReport.running = state === 'RUNNING' || state === 'PREVIEW_RUNNING';
    this.lastHealthReport.runtimeErrors = errors;
    this.lastHealthReport.buildError = buildError;
    this.lastHealthReport.lastChecked = Date.now();
    this.notify();
  }

  public static recordBuilding() {
    this.currentState = 'BUILDING';
    this.lastHealthReport.running = false;
    this.lastHealthReport.mounted = false;
    this.lastHealthReport.buildError = null;
    this.lastHealthReport.lastChecked = Date.now();
    this.notify();
  }

  public static recordStale() {
    this.currentState = 'STALE';
    this.lastHealthReport.running = false;
    this.lastHealthReport.lastChecked = Date.now();
    this.notify();
  }

  public static recordBuildFailed(buildError: PreviewBuildError) {
    this.currentState = 'BUILD_FAILED';
    this.lastHealthReport.running = false;
    this.lastHealthReport.mounted = false;
    this.lastHealthReport.buildError = buildError;
    this.lastHealthReport.runtimeErrors = [buildError.message];
    this.lastHealthReport.lastChecked = Date.now();
    this.notify();

    // Trigger SelfHealingEngine for preview build failure
    try {
      const rawFiles = WorkspaceService.getAllFilesSync();
      const errorLocation = buildError.file ? `${buildError.file}:${buildError.line || 1}:${buildError.column || 1}` : 'src/App.tsx:1:1';
      const formattedStderr = `${errorLocation} - error TS: ${buildError.message}\n${buildError.rawError || ''}`;

      const execResult: ExecutionResult = {
        id: `build-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        command: 'npm run build',
        status: 'FAILED',
        exitCode: 1,
        stdout: '',
        stderr: formattedStderr,
        durationMs: 0,
        chunks: [],
        evidence: {
          executionId: `build-${Date.now()}`,
          command: 'npm run build',
          status: 'FAILED',
          exitCode: 1,
          durationMs: 0,
          startedAt: Date.now(),
          finishedAt: Date.now(),
          requestedBy: 'SYSTEM_VALIDATION',
          workingDirectory: '/',
          outputSummary: buildError.message,
          totalStdoutLines: 0,
          totalStderrLines: 1,
          failureClassification: 'BUILD_FAILURE',
          epistemic: {
            known: [buildError.message],
            likely: ['Build compilation or bundling failed in sandbox'],
            unknown: []
          },
          source: 'ast_esbuild_sandbox'
        },
        policy: {
          allowed: true,
          classification: 'SAFE',
          reasons: [],
          requiresApproval: false,
          normalizedWorkingDirectory: '/',
          sanitizedCommand: 'npm run build',
          matchedRules: []
        }
      };

      SelfHealingEngine.getInstance().handleExecutionFailure(
        execResult,
        rawFiles,
        (path, content) => {
          void WorkspaceService.writeFile(path, content);
        }
      ).catch(err => {
        console.warn('SelfHealingEngine preview build error handling warning:', err);
      });

      GodexEventBus.getInstance().emit({
        type: 'VALIDATION_COMPLETED',
        operationId: 'preview-build',
        subsystem: 'SELF_HEALING',
        severity: 'error',
        message: `Preview build error routed to Self-Healing Debugger: ${buildError.message.slice(0, 100)}`
      });
    } catch (e) {
      console.warn('Failed to route build error to SelfHealingEngine:', e);
    }
  }

  public static recordReady(elementsCount: number) {
    this.currentState = 'RUNNING';
    this.lastHealthReport = {
      running: true,
      mounted: true,
      elementsCount,
      runtimeErrors: [],
      buildError: null,
      lastChecked: Date.now()
    };
    this.notify();
  }

  public static recordError(errorMessage: string) {
    this.currentState = 'RUNTIME_ERROR';
    if (!this.lastHealthReport.runtimeErrors.includes(errorMessage)) {
      this.lastHealthReport.runtimeErrors.push(errorMessage);
    }
    this.lastHealthReport.running = false;
    this.lastHealthReport.mounted = false;
    this.lastHealthReport.lastChecked = Date.now();
    this.notify();

    // Trigger SelfHealingEngine for preview runtime exception
    try {
      if (errorMessage && errorMessage !== 'Script error.' && !errorMessage.includes('Script error')) {
        const rawFiles = WorkspaceService.getAllFilesSync();
        const execResult: ExecutionResult = {
          id: `exec-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          command: 'preview:runtime-execute',
          status: 'FAILED',
          exitCode: 1,
          stdout: '',
          stderr: errorMessage,
          durationMs: 0,
          chunks: [],
          evidence: {
            executionId: `exec-${Date.now()}`,
            command: 'preview:runtime-execute',
            status: 'FAILED',
            exitCode: 1,
            durationMs: 0,
            startedAt: Date.now(),
            finishedAt: Date.now(),
            requestedBy: 'SYSTEM_VALIDATION',
            workingDirectory: '/',
            outputSummary: errorMessage,
            totalStdoutLines: 0,
            totalStderrLines: 1,
            failureClassification: 'PROCESS_CRASH',
            epistemic: {
              known: [errorMessage],
              likely: ['Runtime exception caught by preview sandbox'],
              unknown: []
            },
            source: 'ast_esbuild_sandbox'
          },
          policy: {
            allowed: true,
            classification: 'SAFE',
            reasons: [],
            requiresApproval: false,
            normalizedWorkingDirectory: '/',
            sanitizedCommand: 'preview:runtime-execute',
            matchedRules: []
          }
        };

        SelfHealingEngine.getInstance().handleExecutionFailure(
          execResult,
          rawFiles,
          (path, content) => {
            void WorkspaceService.writeFile(path, content);
          }
        ).catch(err => {
          console.warn('SelfHealingEngine preview runtime error handling warning:', err);
        });

        GodexEventBus.getInstance().emit({
          type: 'VALIDATION_COMPLETED',
          operationId: 'preview-runtime',
          subsystem: 'SELF_HEALING',
          severity: 'error',
          message: `Preview runtime exception routed to Self-Healing Debugger: ${errorMessage.slice(0, 100)}`
        });
      }
    } catch (e) {
      console.warn('Failed to route runtime error to SelfHealingEngine:', e);
    }
  }

  private static notify() {
    this.listeners.forEach(fn => {
      try {
        fn(this.currentState, { ...this.lastHealthReport });
      } catch (err) {
        console.error('PreviewService listener error:', err);
      }
    });
  }

  /**
   * Authoritatively performs a health check on the active preview iframe
   */
  public static async healthCheckPreview(timeoutMs = 2500): Promise<PreviewHealthReport> {
    // If we already received SANDBOX_READY with mounted elements, return healthy state
    if (this.lastHealthReport.mounted && this.lastHealthReport.elementsCount > 0 && !this.lastHealthReport.buildError) {
      return { ...this.lastHealthReport };
    }

    const iframe = document.querySelector('iframe');
    if (!iframe || !iframe.contentWindow) {
      this.setState('BUILD_FAILED', ['Preview iframe element not present in DOM']);
      return { ...this.lastHealthReport };
    }

    return new Promise<PreviewHealthReport>((resolve) => {
      let resolved = false;

      const timer = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          window.removeEventListener('message', handleMessage);
          if (this.lastHealthReport.mounted && this.lastHealthReport.elementsCount > 0) {
            this.setState('RUNNING');
          } else {
            this.setState('RUNTIME_ERROR', ['Preview health check timed out - root component unresponsive']);
          }
          resolve({ ...this.lastHealthReport });
        }
      }, timeoutMs);

      const handleMessage = (event: MessageEvent) => {
        if (!event.data) return;

        if (event.data.type === 'SANDBOX_READY' || event.data.type === 'SANDBOX_HEALTH_PONG') {
          const payload = event.data.payload || {};
          const isMounted = payload.mounted || (payload.elementsCount && payload.elementsCount > 0);
          const count = payload.elementsCount || 1;

          if (isMounted) {
            if (!resolved) {
              resolved = true;
              clearTimeout(timer);
              window.removeEventListener('message', handleMessage);
              this.recordReady(count);
              resolve({ ...this.lastHealthReport });
            }
          }
        } else if (event.data.type === 'SANDBOX_ERROR' || event.data.type === 'SANDBOX_BUILD_ERROR') {
          if (!resolved) {
            resolved = true;
            clearTimeout(timer);
            window.removeEventListener('message', handleMessage);
            const errMsg = event.data.payload?.message || 'Preview Runtime Error';
            this.recordError(errMsg);
            resolve({ ...this.lastHealthReport });
          }
        }
      };

      window.addEventListener('message', handleMessage);

      try {
        iframe.contentWindow.postMessage({ type: 'PING_HEALTH' }, '*');
      } catch {
        // PostMessage fallback
      }
    });
  }
}
