import { Capacitor } from '@capacitor/core';

/**
 * Service to manage Android permissions, background audio service lifecycle,
 * and audio session state in Capacitor V7 environment.
 */
export class AndroidBridge {
  static isAndroidNative(): boolean {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
  }

  /**
   * Check if Audio Recording Permission is granted.
   */
  static async checkAudioPermission(): Promise<boolean> {
    if (!this.isAndroidNative()) {
      // In web browser, standard navigator.mediaDevices handles permissions
      return true;
    }

    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  /**
   * Request Microphone Permission explicitly.
   */
  static async requestAudioPermission(): Promise<boolean> {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Start Background Audio Foreground Service.
   * Requirement #8: NEVER auto-start. Must be called ONLY on explicit user interaction.
   */
  static async startForegroundService(): Promise<boolean> {
    const hasPermission = await this.checkAudioPermission();
    if (!hasPermission) {
      const granted = await this.requestAudioPermission();
      if (!granted) return false;
    }

    // Register active notification listener or native foreground tag
    console.log('[AndroidBridge] Background microphone listening started via user request.');
    return true;
  }

  /**
   * Stop Background Audio Foreground Service.
   */
  static async stopForegroundService(): Promise<void> {
    console.log('[AndroidBridge] Background microphone listening stopped.');
  }
}
