import { SocialTaskItem, SocialPlatform } from '../types';

export const TOTAL_SOCIAL_CATALOG_COUNT = 30600;

export const SOCIAL_PLATFORMS_LIST: { id: string; label: string; platform?: SocialPlatform }[] = [
  { id: 'All', label: 'All' },
  { id: 'telegram', label: 'Telegram', platform: 'telegram' },
  { id: 'instagram', label: 'Instagram', platform: 'instagram' },
  { id: 'youtube', label: 'YouTube', platform: 'youtube' },
  { id: 'twitter', label: 'Twitter / X', platform: 'twitter' },
  { id: 'discord', label: 'Discord', platform: 'discord' },
  { id: 'whatsapp', label: 'WhatsApp', platform: 'whatsapp' },
  { id: 'facebook', label: 'Facebook', platform: 'facebook' },
];

const BASE_SOCIAL_RESOURCES = [
  {
    title: 'Join TaskEarn Official Broadcast',
    handle: '@TaskEarnOfficial',
    platform: 'telegram' as SocialPlatform,
    actionType: 'join' as const,
    baseReward: 45,
    membersCount: '185K members',
    iconBg: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
    targetUrl: 'https://t.me/telegram',
    instructions: 'Join our official Telegram announcement broadcast to receive daily promo codes and payout alerts.'
  },
  {
    title: 'Follow TaskEarn Instagram & Like Post',
    handle: '@taskearn_pro',
    platform: 'instagram' as SocialPlatform,
    actionType: 'follow' as const,
    baseReward: 50,
    membersCount: '92K followers',
    iconBg: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
    targetUrl: 'https://instagram.com',
    instructions: 'Follow our official Instagram profile and like the pinned announcement reel.'
  },
  {
    title: 'Subscribe to Tech Innovators YouTube',
    handle: '@TechInnovatorsOfficial',
    platform: 'youtube' as SocialPlatform,
    actionType: 'subscribe' as const,
    baseReward: 65,
    membersCount: '450K subscribers',
    iconBg: 'bg-red-500/20 text-red-400 border-red-500/30',
    targetUrl: 'https://youtube.com',
    instructions: 'Subscribe to the YouTube channel and tap the notification bell.'
  },
  {
    title: 'Follow & Retweet on Twitter / X',
    handle: '@TaskEarn_HQ',
    platform: 'twitter' as SocialPlatform,
    actionType: 'retweet' as const,
    baseReward: 40,
    membersCount: '65K followers',
    iconBg: 'bg-slate-700/30 text-white border-slate-600',
    targetUrl: 'https://x.com',
    instructions: 'Follow @TaskEarn_HQ on X and repost our weekly rewards leaderboard.'
  },
  {
    title: 'Join Global Earners Discord Guild',
    handle: 'discord.gg/taskearn',
    platform: 'discord' as SocialPlatform,
    actionType: 'join' as const,
    baseReward: 75,
    membersCount: '42K members',
    iconBg: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
    targetUrl: 'https://discord.com',
    instructions: 'Join the community server and pass the automated emoji bot verification in #rules.'
  },
  {
    title: 'Follow Official WhatsApp Channel',
    handle: 'Task Earn Rewards',
    platform: 'whatsapp' as SocialPlatform,
    actionType: 'follow' as const,
    baseReward: 35,
    membersCount: '310K followers',
    iconBg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    targetUrl: 'https://whatsapp.com/channel',
    instructions: 'Follow the verified WhatsApp channel for instant notification of new tasks & VIP bonuses.'
  },
  {
    title: 'Like Facebook Announcement Post',
    handle: 'fb.com/TaskEarnPro/posts/101',
    platform: 'facebook' as SocialPlatform,
    actionType: 'like' as const,
    baseReward: 10,
    membersCount: '124K likes',
    iconBg: 'bg-blue-600/20 text-blue-400 border-blue-600/30',
    targetUrl: 'https://facebook.com',
    instructions: 'Open the Facebook post, tap Like or Heart button, and claim your 10 coins bonus.'
  },
  {
    title: 'Comment on Facebook Community Post',
    handle: 'fb.com/TaskEarnPro/posts/102',
    platform: 'facebook' as SocialPlatform,
    actionType: 'like' as const,
    baseReward: 10,
    membersCount: '89K comments',
    iconBg: 'bg-blue-600/20 text-blue-400 border-blue-600/30',
    targetUrl: 'https://facebook.com',
    instructions: 'Leave a helpful or positive comment on our official Facebook update to earn 10 coins.'
  },
  {
    title: 'Share Facebook Post to Feed / Groups',
    handle: 'fb.com/TaskEarnPro/posts/103',
    platform: 'facebook' as SocialPlatform,
    actionType: 'like' as const,
    baseReward: 10,
    membersCount: '45K shares',
    iconBg: 'bg-blue-600/20 text-blue-400 border-blue-600/30',
    targetUrl: 'https://facebook.com',
    instructions: 'Share our latest earning milestone post to your Facebook timeline or public group for 10 coins.'
  },
  {
    title: 'Follow & Like Facebook Official Page',
    handle: 'fb.com/TaskEarnPro',
    platform: 'facebook' as SocialPlatform,
    actionType: 'like' as const,
    baseReward: 10,
    membersCount: '78K likes',
    iconBg: 'bg-blue-600/20 text-blue-400 border-blue-600/30',
    targetUrl: 'https://facebook.com',
    instructions: 'Like our verified Facebook community page and leave a positive recommendation.'
  },
  {
    title: 'Join Alpha Crypto Signals Telegram',
    handle: '@AlphaCryptoVIP',
    platform: 'telegram' as SocialPlatform,
    actionType: 'join' as const,
    baseReward: 60,
    membersCount: '130K members',
    iconBg: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
    targetUrl: 'https://t.me/telegram',
    instructions: 'Join the partner crypto analysis group and stay active for daily market summaries.'
  },
  {
    title: 'Facebook & Instagram: Premium Post Like & Share',
    handle: 'fb.com/ig.com/viral-promos',
    platform: 'facebook' as SocialPlatform,
    actionType: 'like' as const,
    baseReward: 20,
    membersCount: '250K likes',
    iconBg: 'bg-purple-600/20 text-purple-400 border-purple-600/30',
    targetUrl: 'https://instagram.com',
    instructions: 'Open the post link, like on both Facebook & Instagram, share to story/feed, and claim 20 coins!'
  },
  {
    title: 'Facebook & Instagram: Hybrid Campaign Comment & Follow',
    handle: 'fb.com/ig.com/pay-milestones',
    platform: 'instagram' as SocialPlatform,
    actionType: 'like' as const,
    baseReward: 20,
    membersCount: '180K comments',
    iconBg: 'bg-indigo-600/20 text-indigo-400 border-indigo-600/30',
    targetUrl: 'https://facebook.com',
    instructions: 'Follow the page and leave a thoughtful comment on both Instagram and Facebook pinned posts to claim 20 coins.'
  }
];

export function getSocialCatalog(
  page: number = 1,
  limit: number = 10,
  platformFilter: string = 'All',
  searchQuery: string = ''
): { tasks: SocialTaskItem[]; totalCount: number; hasMore: boolean } {
  const query = searchQuery.trim().toLowerCase();
  const allGenerated: SocialTaskItem[] = [];

  const maxToGenerate = 280;

  for (let i = 0; i < maxToGenerate; i++) {
    const base = BASE_SOCIAL_RESOURCES[i % BASE_SOCIAL_RESOURCES.length];
    const taskNum = Math.floor(i / BASE_SOCIAL_RESOURCES.length) + 1;

    if (platformFilter !== 'All' && base.platform !== platformFilter) {
      continue;
    }

    const title = taskNum === 1 
      ? base.title 
      : `${base.title} #${taskNum}`;

    const handle = taskNum === 1 
      ? base.handle 
      : `${base.handle}_${taskNum}`;

    if (query && !title.toLowerCase().includes(query) && !handle.toLowerCase().includes(query)) {
      continue;
    }

    const reward = Math.max(30, base.baseReward + ((i * 5) % 45));

    allGenerated.push({
      id: `social-task-${i + 1}`,
      title,
      handle,
      platform: base.platform,
      actionType: base.actionType,
      rewardCoins: reward,
      membersCount: base.membersCount,
      iconBg: base.iconBg,
      targetUrl: base.targetUrl,
      instructions: base.instructions,
    });
  }

  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + limit;
  const paged = allGenerated.slice(startIndex, endIndex);

  return {
    tasks: paged,
    totalCount: TOTAL_SOCIAL_CATALOG_COUNT,
    hasMore: endIndex < allGenerated.length,
  };
}
