import JSZip from 'jszip';
import { ANDROID_FILES } from '../data/androidCodePackage';
import { createDriveFolder, uploadBlobToDrive, DriveFileItem } from './googleDrive';

export interface ExportResult {
  folderName: string;
  folderId: string;
  uploadedFiles: DriveFileItem[];
}

export const generateAppZipBlob = async (): Promise<Blob> => {
  const zip = new JSZip();

  // 1. AndroidManifest.xml
  const manifest = ANDROID_FILES.find(f => f.id === 'manifest');
  if (manifest) {
    zip.file('app/src/main/AndroidManifest.xml', manifest.content);
  }

  // 2. MainActivity.kt
  const mainActivity = ANDROID_FILES.find(f => f.id === 'mainactivity');
  if (mainActivity) {
    zip.file('app/src/main/java/com/patrik/meusarquivospat/MainActivity.kt', mainActivity.content);
  }

  // 3. OverlayService.kt
  const overlayService = ANDROID_FILES.find(f => f.id === 'overlayservice');
  if (overlayService) {
    zip.file('app/src/main/java/com/patrik/meusarquivospat/OverlayService.kt', overlayService.content);
  }

  // 4. AdbActivationReceiver.kt
  const adbReceiver = ANDROID_FILES.find(f => f.id === 'adbreceiver');
  if (adbReceiver) {
    zip.file('app/src/main/java/com/patrik/meusarquivospat/AdbActivationReceiver.kt', adbReceiver.content);
  }

  // 5. Scripts
  const batScript = ANDROID_FILES.find(f => f.id === 'activatebat');
  if (batScript) {
    zip.file('scripts/ativar_pat.bat', batScript.content);
  }

  const shScript = ANDROID_FILES.find(f => f.id === 'activatesh');
  if (shScript) {
    zip.file('scripts/ativar_pat.sh', shScript.content);
  }

  // 6. Instructions
  const instructions = `===================================================================
MEUS ARQUIVOS PAT - PROJETO ANDROID STUDIO COMPLETO (CORRIGIDO)
===================================================================

Este pacote contém o código-fonte corrigido para Android Studio:

COMO UTILIZAR:
1. Abra o seu projeto no Android Studio.
2. Copie os arquivos da pasta 'app/src/main' para o seu projeto:
   - AndroidManifest.xml -> app/src/main/AndroidManifest.xml
   - MainActivity.kt -> app/src/main/java/com/patrik/meusarquivospat/MainActivity.kt
   - OverlayService.kt -> app/src/main/java/com/patrik/meusarquivospat/OverlayService.kt
   - AdbActivationReceiver.kt -> app/src/main/java/com/patrik/meusarquivospat/AdbActivationReceiver.kt

3. ATIVAÇÃO VIA ADB SEM ROOT:
   - No Windows: Conecte o celular via cabo USB com Depuração USB ligada e execute 'scripts/ativar_pat.bat'.
   - No Mac/Linux/Termux: Execute 'scripts/ativar_pat.sh'.

Exportado com sucesso para o Google Drive em: ${new Date().toLocaleString('pt-BR')}
`;
  zip.file('LEIAME_INSTRUCOES.txt', instructions);

  return await zip.generateAsync({ type: 'blob' });
};

export const exportEntireAppToDrive = async (
  token: string,
  onProgress?: (step: string) => void
): Promise<ExportResult> => {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const folderTitle = `Meus_Arquivos_PAT_Export_${timestamp}`;

  onProgress?.(`Criando pasta "${folderTitle}" no Google Drive...`);
  const folder = await createDriveFolder(token, folderTitle, 'root');

  const uploadedFiles: DriveFileItem[] = [];

  // 1. Generate & Upload ZIP
  onProgress?.('Empacotando projeto completo em formato .ZIP...');
  const zipBlob = await generateAppZipBlob();

  onProgress?.('Enviando "Meus_Arquivos_PAT_Android_Project.zip" para o Drive...');
  const zipItem = await uploadBlobToDrive(
    token,
    zipBlob,
    'Meus_Arquivos_PAT_Android_Project.zip',
    folder.id
  );
  uploadedFiles.push(zipItem);

  // 2. Upload individual source files so they can be inspected in Drive
  for (const file of ANDROID_FILES) {
    onProgress?.(`Enviando ${file.filename} para a pasta no Drive...`);
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const uploaded = await uploadBlobToDrive(token, blob, file.filename, folder.id);
    uploadedFiles.push(uploaded);
  }

  onProgress?.('✓ Exportação concluída com sucesso!');

  return {
    folderName: folderTitle,
    folderId: folder.id,
    uploadedFiles
  };
};
