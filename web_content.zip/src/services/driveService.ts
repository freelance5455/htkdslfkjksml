/**
 * Google Drive API Service for Zeynep'in Günlüğü
 * Uses Google Drive v3 REST API with client-side bearer token
 */

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime: string;
  size?: string;
}

export const listDriveBackups = async (accessToken: string): Promise<DriveFileItem[]> => {
  const query = encodeURIComponent("name contains 'Zeynep_Gunlugu' and trashed = false");
  const url = `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,mimeType,modifiedTime,size)&orderBy=modifiedTime desc`;

  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Google Drive dosyaları listelenemedi: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  return data.files || [];
};

export const saveBackupToDrive = async (
  accessToken: string,
  backupPayload: Record<string, unknown>,
  customName?: string
): Promise<{ id: string; name: string }> => {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const fileName = customName || `Zeynep_Gunlugu_Yedek_${timestamp}.json`;
  const fileContent = JSON.stringify(backupPayload, null, 2);

  const metadata = {
    name: fileName,
    mimeType: 'application/json',
    description: "Zeynep'in Günlüğü öğrenci, ders ve cüzdan yedek dosyası",
  };

  const form = new FormData();
  form.append(
    'metadata',
    new Blob([JSON.stringify(metadata)], { type: 'application/json' })
  );
  form.append('file', new Blob([fileContent], { type: 'application/json' }));

  const response = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      body: form,
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Google Drive'a yedeklenemedi: ${response.status} - ${errorText}`);
  }

  return await response.json();
};

export const fetchBackupContent = async (
  accessToken: string,
  fileId: string
): Promise<any> => {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Google Drive dosyası indirilemedi: ${response.statusText}`);
  }

  return await response.json();
};

export const exportTextReportToDrive = async (
  accessToken: string,
  reportText: string,
  fileName: string
): Promise<{ id: string; name: string }> => {
  const metadata = {
    name: fileName,
    mimeType: 'text/plain',
    description: "Zeynep'in Günlüğü ders ve tahsilat özeti",
  };

  const form = new FormData();
  form.append(
    'metadata',
    new Blob([JSON.stringify(metadata)], { type: 'application/json' })
  );
  form.append('file', new Blob([reportText], { type: 'text/plain' }));

  const response = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      body: form,
    }
  );

  if (!response.ok) {
    throw new Error(`Rapor Drive'a yüklenemedi: ${response.statusText}`);
  }

  return await response.json();
};
