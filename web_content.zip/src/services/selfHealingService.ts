/**
 * JARVIS ULTIMATE 2.0 — AUTONOMOUS SELF-HEALING ENGINE
 * Detects, diagnoses, classifies, and automatically resolves recoverable runtime problems,
 * manages exponential backoff with randomized jitter for HTTP 503 / 429 errors,
 * avoids infinite loops, and maintains a persistent diagnostic recovery history.
 */

export type ErrorClassification = 'recoverable' | 'temporary' | 'configuration' | 'user_action_required';

export interface DiagnosticRecord {
  id: string;
  timestamp: number;
  source: string;
  error: string;
  classification: ErrorClassification;
  resolved: boolean;
  recoveryActionTaken?: string;
  retryCount: number;
}

export interface PendingOperation {
  id: string;
  name: string;
  execute: () => Promise<any>;
  retriesLeft: number;
  lastAttempt: number;
  payload?: any;
}

const DIAGNOSTIC_HISTORY_KEY = 'jarvis_self_healing_history';
const MAX_HISTORY_ITEMS = 60;
const MAX_AUTO_RETRIES = 3;

class SelfHealingEngine {
  private history: DiagnosticRecord[] = [];
  private pendingOperations: Map<string, PendingOperation> = new Map();
  private isProcessingPending = false;
  private listeners: Array<(history: DiagnosticRecord[]) => void> = [];

  constructor() {
    this.loadHistory();
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleNetworkRestored());
    }
  }

  private loadHistory(): void {
    try {
      if (typeof localStorage !== 'undefined') {
        const saved = localStorage.getItem(DIAGNOSTIC_HISTORY_KEY);
        if (saved) {
          this.history = JSON.parse(saved);
        }
      }
    } catch (e) {
      console.warn('Failed to load self-healing history:', e);
    }
  }

  private saveHistory(): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(DIAGNOSTIC_HISTORY_KEY, JSON.stringify(this.history.slice(0, MAX_HISTORY_ITEMS)));
      }
      this.notifyListeners();
    } catch (e) {
      console.warn('Failed to save self-healing history:', e);
    }
  }

  public subscribe(listener: (history: DiagnosticRecord[]) => void): () => void {
    this.listeners.push(listener);
    listener([...this.history]);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners(): void {
    const copy = [...this.history];
    this.listeners.forEach(l => l(copy));
  }

  /**
   * Classify any runtime or API error
   */
  public classifyError(err: any): ErrorClassification {
    const status = err?.status || (err?.message && err.message.includes('503') ? 503 : 0);
    const msg = String(err?.message || err || '').toLowerCase();

    if (
      status === 429 ||
      status === 503 ||
      msg.includes('rate limit') ||
      msg.includes('quota') ||
      msg.includes('resource_exhausted') ||
      msg.includes('service unavailable') ||
      msg.includes('failed to fetch') ||
      msg.includes('network') ||
      msg.includes('offline') ||
      msg.includes('timeout')
    ) {
      return 'recoverable';
    }

    if (
      msg.includes('api_key') ||
      msg.includes('unauthorized') ||
      msg.includes('forbidden') ||
      msg.includes('permission') ||
      msg.includes('key is not configured')
    ) {
      return 'configuration';
    }

    if (
      msg.includes('notallowederror') ||
      msg.includes('user cancelled') ||
      msg.includes('denied')
    ) {
      return 'user_action_required';
    }

    return 'temporary';
  }

  /**
   * Execute an async function with automated exponential backoff with jitter (max 3 retries).
   * Automatically heals transient network spikes and 503/429 rate limit pauses.
   */
  public async executeWithSelfHealing<T>(
    operationName: string,
    operation: () => Promise<T>,
    options: {
      maxRetries?: number;
      initialDelayMs?: number;
      onRetry?: (attempt: number, delayMs: number) => void;
    } = {}
  ): Promise<T> {
    const maxRetries = options.maxRetries ?? MAX_AUTO_RETRIES;
    let attempt = 0;
    let delayMs = options.initialDelayMs ?? 800;

    while (attempt <= maxRetries) {
      try {
        const result = await operation();
        // If it succeeded after previous failure, record recovery
        if (attempt > 0) {
          this.recordDiagnostic({
            source: operationName,
            error: `Resolved after ${attempt} retry attempt(s)`,
            classification: 'recoverable',
            resolved: true,
            recoveryActionTaken: `Exponential backoff retry succeeded on attempt ${attempt}.`,
            retryCount: attempt,
          });
        }
        return result;
      } catch (err: any) {
        attempt++;
        const classification = this.classifyError(err);
        const errMsg = err?.message || String(err);

        if (classification !== 'recoverable' || attempt > maxRetries) {
          this.recordDiagnostic({
            source: operationName,
            error: errMsg,
            classification,
            resolved: false,
            recoveryActionTaken: attempt > maxRetries ? 'Max retries exceeded; escalation required.' : 'Non-recoverable error classified.',
            retryCount: attempt,
          });
          throw err;
        }

        // Add randomized jitter to prevent thundering herd
        const jitter = Math.floor(Math.random() * 400);
        const sleepDuration = delayMs + jitter;
        options.onRetry?.(attempt, sleepDuration);

        await new Promise(resolve => setTimeout(resolve, sleepDuration));
        delayMs *= 2; // exponential factor
      }
    }

    throw new Error(`${operationName} failed after ${maxRetries} automatic self-healing retries.`);
  }

  /**
   * Log an incident and diagnose self-healing options
   */
  public recordDiagnostic(record: Omit<DiagnosticRecord, 'id' | 'timestamp'>): DiagnosticRecord {
    const item: DiagnosticRecord = {
      id: `diag-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: Date.now(),
      ...record,
    };

    this.history.unshift(item);
    this.saveHistory();
    return item;
  }

  /**
   * Automatic system self-check and recovery action
   */
  public async performSystemSelfHeal(): Promise<{ actionsTaken: string[]; healedCount: number }> {
    const actionsTaken: string[] = [];

    // 1. Check and unstuck Web Speech API if locked
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      if (window.speechSynthesis.speaking && !window.speechSynthesis.pending) {
        window.speechSynthesis.cancel();
        actionsTaken.push('Reset stuck speech synthesis audio queue');
      }
    }

    // 2. Check and clean oversized localStorage keys
    try {
      if (typeof localStorage !== 'undefined') {
        const chat = localStorage.getItem('jarvis_chat_history');
        if (chat && chat.length > 500000) {
          const parsed = JSON.parse(chat);
          localStorage.setItem('jarvis_chat_history', JSON.stringify(parsed.slice(-20)));
          actionsTaken.push('Compacted oversized chat memory buffer to prevent quota exhaustion');
        }
      }
    } catch {}

    // 3. Process pending network retry queue
    if (this.pendingOperations.size > 0 && !this.isProcessingPending) {
      const pendingCount = this.pendingOperations.size;
      this.isProcessingPending = true;
      for (const [id, op] of Array.from(this.pendingOperations.entries())) {
        try {
          await op.execute();
          this.pendingOperations.delete(id);
        } catch {
          op.retriesLeft -= 1;
          if (op.retriesLeft <= 0) {
            this.pendingOperations.delete(id);
          }
        }
      }
      this.isProcessingPending = false;
      actionsTaken.push(`Processed ${pendingCount} pending deferred operations`);
    }

    if (actionsTaken.length > 0) {
      this.recordDiagnostic({
        source: 'SelfHealingEngine',
        error: 'System Maintenance Check',
        classification: 'recoverable',
        resolved: true,
        recoveryActionTaken: actionsTaken.join('; '),
        retryCount: 0,
      });
    }

    return { actionsTaken, healedCount: actionsTaken.length };
  }

  private handleNetworkRestored(): void {
    this.recordDiagnostic({
      source: 'NetworkMonitor',
      error: 'Device was offline',
      classification: 'recoverable',
      resolved: true,
      recoveryActionTaken: 'Network connectivity re-established. Resuming pending operations.',
      retryCount: 0,
    });
    this.performSystemSelfHeal();
  }

  public getHistory(): DiagnosticRecord[] {
    return [...this.history];
  }

  public clearHistory(): void {
    this.history = [];
    this.saveHistory();
  }
}

export const selfHealingEngine = new SelfHealingEngine();
