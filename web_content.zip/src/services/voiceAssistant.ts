import { PreferredLanguage } from '../types';

export type TTSState = 'idle' | 'playing' | 'paused';
export type ReadingMode = 'page' | 'selection';

export interface TTSStatus {
  state: TTSState;
  sessionId: string | null;
  language: PreferredLanguage;
  progress: number; // 0 to 100
  readingMode: ReadingMode;
  selectedText?: string;
}

type StatusListener = (status: TTSStatus) => void;
type SelectionListener = (selectedText: string) => void;

class VoiceAssistantService {
  private currentSessionId: string | null = null;
  private currentLanguage: PreferredLanguage = 'English';
  private state: TTSState = 'idle';
  private readingMode: ReadingMode = 'page';
  private chunks: string[] = [];
  private currentChunkIndex: number = 0;
  private listeners: Set<StatusListener> = new Set();
  private voices: SpeechSynthesisVoice[] = [];
  private onSessionEndCallback: (() => void) | null = null;
  private activeUtterance: SpeechSynthesisUtterance | null = null;
  private heartbeatInterval: any = null;

  // Active text selection tracking
  private activeSelectedText: string = '';
  private lastSelectionTimestamp: number = 0;
  private selectionListeners: Set<SelectionListener> = new Set();

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.loadVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        this.loadVoices();
      };
    }
    this.setupSelectionListener();
  }

  private setupSelectionListener() {
    if (typeof document === 'undefined') return;

    const checkSelection = () => {
      try {
        const sel = window.getSelection();
        const rawText = sel ? sel.toString() : '';
        const trimmed = rawText.trim();

        if (trimmed && trimmed.length > 0) {
          this.activeSelectedText = trimmed;
          this.lastSelectionTimestamp = Date.now();
          this.notifySelectionListeners(trimmed);
        } else {
          // If selection was collapsed, only clear after a slight grace window (600ms)
          // so button click / touch on a read aloud control preserves the highlighted text
          setTimeout(() => {
            const currentSel = window.getSelection();
            const currentText = currentSel ? currentSel.toString().trim() : '';
            if (!currentText && Date.now() - this.lastSelectionTimestamp > 500) {
              if (this.activeSelectedText) {
                this.activeSelectedText = '';
                this.notifySelectionListeners('');
              }
            }
          }, 550);
        }
      } catch {
        // ignore
      }
    };

    document.addEventListener('selectionchange', checkSelection);
    document.addEventListener('mouseup', checkSelection);
    document.addEventListener('touchend', checkSelection);
    document.addEventListener('keyup', checkSelection);
  }

  private notifySelectionListeners(text: string) {
    this.selectionListeners.forEach((fn) => {
      try {
        fn(text);
      } catch (e) {
        console.error('[VoiceAssistant] Selection listener error:', e);
      }
    });
  }

  public subscribeToSelection(listener: SelectionListener): () => void {
    this.selectionListeners.add(listener);
    listener(this.activeSelectedText);
    return () => {
      this.selectionListeners.delete(listener);
    };
  }

  public getActiveSelection(): string {
    if (typeof window === 'undefined') return '';
    try {
      const currentLive = window.getSelection()?.toString().trim();
      if (currentLive && currentLive.length > 0) {
        this.activeSelectedText = currentLive;
        this.lastSelectionTimestamp = Date.now();
        return currentLive;
      }
      // If window.getSelection() was just collapsed due to a button click (within 1200ms), return cached selection
      if (this.activeSelectedText && Date.now() - this.lastSelectionTimestamp < 1200) {
        return this.activeSelectedText;
      }
    } catch {
      // ignore
    }
    return '';
  }

  public clearActiveSelection(): void {
    this.activeSelectedText = '';
    this.notifySelectionListeners('');
    if (typeof window !== 'undefined') {
      try {
        window.getSelection()?.removeAllRanges();
      } catch {
        // ignore
      }
    }
  }

  private loadVoices() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.voices = window.speechSynthesis.getVoices();
    }
  }

  private startHeartbeat() {
    this.stopHeartbeat();
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    this.heartbeatInterval = setInterval(() => {
      if (this.state === 'playing' && window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
        // Keeps Chromium TTS engine alive on long speech sequences
        window.speechSynthesis.pause();
        window.speechSynthesis.resume();
      }
    }, 7000);
  }

  private stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  private notify() {
    const total = this.chunks.length;
    const progress = total > 0 ? Math.min(100, Math.round(((this.currentChunkIndex + 1) / total) * 100)) : 0;
    const status: TTSStatus = {
      state: this.state,
      sessionId: this.currentSessionId,
      language: this.currentLanguage,
      progress: this.state === 'idle' ? 0 : progress,
      readingMode: this.readingMode,
      selectedText: this.activeSelectedText,
    };
    this.listeners.forEach((listener) => {
      try {
        listener(status);
      } catch (err) {
        console.error('[VoiceAssistant] Listener error:', err);
      }
    });
  }

  public subscribe(listener: StatusListener): () => void {
    this.listeners.add(listener);
    listener({
      state: this.state,
      sessionId: this.currentSessionId,
      language: this.currentLanguage,
      progress: 0,
      readingMode: this.readingMode,
      selectedText: this.activeSelectedText,
    });
    return () => {
      this.listeners.delete(listener);
    };
  }

  public getState(): TTSState {
    return this.state;
  }

  public getSessionId(): string | null {
    return this.currentSessionId;
  }

  /**
   * Cleans text to make it natural and readable for TTS:
   * Strips out markdown formatting symbols, bullet asterisks, redundant emojis, etc.
   */
  private prepareText(text: string): string {
    if (!text) return '';
    return text
      .replace(/[*#_~`>]/g, ' ')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Splits long text into natural sentence or phrase chunks (max ~160 chars)
   * without splitting decimal numbers like 9.8 or 12.5, ensuring continuous speech.
   */
  private splitIntoChunks(text: string): string[] {
    const prepared = this.prepareText(text);
    if (!prepared) return [];

    // Split on sentence boundaries: punctuation followed by space or newline, or Devanagari danda
    // Does NOT split on periods inside decimal numbers like 9.8 or 12.5
    const rawSegments = prepared
      .split(/(?<=[.!?।॥;\n])\s+/g)
      .map((s) => s.trim())
      .filter(Boolean);

    const chunks: string[] = [];
    let buffer = '';

    for (let i = 0; i < rawSegments.length; i++) {
      const segment = rawSegments[i];

      // If adding this segment keeps buffer under limit
      if (buffer.length + segment.length + 1 < 160) {
        buffer = buffer ? `${buffer} ${segment}` : segment;
      } else {
        if (buffer.trim()) {
          chunks.push(buffer.trim());
        }

        // If the individual segment itself is longer than 160 chars, split on clause boundaries
        if (segment.length >= 160) {
          const subparts = segment
            .split(/(?<=[,:\-–—])\s+/g)
            .map((sp) => sp.trim())
            .filter(Boolean);

          let subBuffer = '';
          for (const sub of subparts) {
            if (subBuffer.length + sub.length + 1 < 160) {
              subBuffer = subBuffer ? `${subBuffer} ${sub}` : sub;
            } else {
              if (subBuffer.trim()) chunks.push(subBuffer.trim());
              // If even a sub-part is huge, split by words
              if (sub.length >= 160) {
                const words = sub.split(/\s+/);
                let wordBuf = '';
                for (const w of words) {
                  if (wordBuf.length + w.length + 1 < 160) {
                    wordBuf = wordBuf ? `${wordBuf} ${w}` : w;
                  } else {
                    if (wordBuf.trim()) chunks.push(wordBuf.trim());
                    wordBuf = w;
                  }
                }
                subBuffer = wordBuf;
              } else {
                subBuffer = sub;
              }
            }
          }
          buffer = subBuffer;
        } else {
          buffer = segment;
        }
      }
    }

    if (buffer.trim()) {
      chunks.push(buffer.trim());
    }

    return chunks.length > 0 ? chunks : [prepared];
  }

  private findBestVoice(language: PreferredLanguage): SpeechSynthesisVoice | null {
    if (!this.voices.length) {
      this.loadVoices();
    }
    const voiceList = this.voices;

    if (language === 'Hindi') {
      const hindiVoice = voiceList.find(
        (v) =>
          v.lang.toLowerCase().startsWith('hi') ||
          v.lang.toLowerCase().includes('hi-in') ||
          v.name.toLowerCase().includes('hindi')
      );
      if (hindiVoice) return hindiVoice;
    }

    if (language === 'Marathi') {
      const marathiVoice = voiceList.find(
        (v) =>
          v.lang.toLowerCase().startsWith('mr') ||
          v.lang.toLowerCase().includes('mr-in') ||
          v.name.toLowerCase().includes('marathi')
      );
      if (marathiVoice) return marathiVoice;

      // Hindi voices accurately pronounce Devanagari script for Marathi
      const fallbackHindi = voiceList.find(
        (v) =>
          v.lang.toLowerCase().startsWith('hi') ||
          v.lang.toLowerCase().includes('hi-in') ||
          v.name.toLowerCase().includes('hindi')
      );
      if (fallbackHindi) return fallbackHindi;
    }

    // English (or fallback)
    const indianEnglish = voiceList.find(
      (v) => v.lang.toLowerCase().includes('en-in') || v.name.toLowerCase().includes('india')
    );
    if (indianEnglish) return indianEnglish;

    const anyEnglish = voiceList.find((v) => v.lang.toLowerCase().startsWith('en'));
    if (anyEnglish) return anyEnglish;

    return voiceList[0] || null;
  }

  public speak(
    text: string,
    language: PreferredLanguage = 'English',
    sessionId?: string,
    onEnd?: () => void,
    mode: ReadingMode = 'page'
  ): string {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      console.warn('[VoiceAssistant] Speech synthesis not supported in this environment.');
      return '';
    }

    // Always stop existing speech first so only ONE session plays at a time
    this.stop();

    const activeSessionId = sessionId || `session_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    this.currentSessionId = activeSessionId;
    this.currentLanguage = language;
    this.readingMode = mode;
    this.onSessionEndCallback = onEnd || null;

    const chunks = this.splitIntoChunks(text);
    if (chunks.length === 0) {
      this.state = 'idle';
      this.currentSessionId = null;
      this.readingMode = 'page';
      this.notify();
      return activeSessionId;
    }

    this.chunks = chunks;
    this.currentChunkIndex = 0;
    this.state = 'playing';
    this.startHeartbeat();
    this.notify();

    this.playChunk(activeSessionId);
    return activeSessionId;
  }

  private playChunk(sessionId: string) {
    if (sessionId !== this.currentSessionId || this.state === 'idle') {
      return;
    }

    if (this.currentChunkIndex >= this.chunks.length) {
      this.finishSession(sessionId);
      return;
    }

    const chunkText = this.chunks[this.currentChunkIndex];
    const utterance = new SpeechSynthesisUtterance(chunkText);
    this.activeUtterance = utterance;

    // Set voice language code
    if (this.currentLanguage === 'Hindi') {
      utterance.lang = 'hi-IN';
    } else if (this.currentLanguage === 'Marathi') {
      utterance.lang = 'mr-IN';
    } else {
      utterance.lang = 'en-IN';
    }

    const voice = this.findBestVoice(this.currentLanguage);
    if (voice) {
      utterance.voice = voice;
    }

    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    utterance.onend = () => {
      this.activeUtterance = null;
      if (sessionId !== this.currentSessionId) return;
      this.currentChunkIndex++;
      this.notify();
      this.playChunk(sessionId);
    };

    utterance.onerror = (e) => {
      this.activeUtterance = null;
      // If speech was canceled intentionally, ignore error
      if (e.error === 'canceled' || e.error === 'interrupted') {
        return;
      }
      console.warn('[VoiceAssistant] Utterance error:', e.error);
      // Attempt next chunk to guarantee full reading without stopping
      if (sessionId === this.currentSessionId) {
        this.currentChunkIndex++;
        this.notify();
        this.playChunk(sessionId);
      }
    };

    window.speechSynthesis.speak(utterance);
  }

  private finishSession(sessionId: string) {
    if (this.currentSessionId === sessionId) {
      this.stopHeartbeat();
      this.activeUtterance = null;
      this.state = 'idle';
      this.currentSessionId = null;
      this.readingMode = 'page';
      this.chunks = [];
      this.currentChunkIndex = 0;
      this.notify();
      if (this.onSessionEndCallback) {
        this.onSessionEndCallback();
        this.onSessionEndCallback = null;
      }
    }
  }

  public pause() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      if (this.state === 'playing') {
        this.stopHeartbeat();
        window.speechSynthesis.pause();
        this.state = 'paused';
        this.notify();
      }
    }
  }

  public resume() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      if (this.state === 'paused') {
        window.speechSynthesis.resume();
        this.state = 'playing';
        this.startHeartbeat();
        this.notify();
      }
    }
  }

  public stop(targetSessionId?: string) {
    if (targetSessionId && this.currentSessionId !== targetSessionId) {
      return;
    }

    this.stopHeartbeat();
    this.activeUtterance = null;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (err) {
        console.error('[VoiceAssistant] Cancel error:', err);
      }
    }

    this.state = 'idle';
    this.currentSessionId = null;
    this.readingMode = 'page';
    this.chunks = [];
    this.currentChunkIndex = 0;
    this.onSessionEndCallback = null;
    this.notify();
  }

  /**
   * Detects the currently open page/screen (or open modal/dialog),
   * traverses all meaningful visible DOM nodes from top to bottom,
   * excludes decorative icons, hidden elements, navigation and controls,
   * and returns the complete text ready for continuous reading.
   */
  public extractVisibleTextFromPage(originEl?: HTMLElement | null): string {
    if (typeof document === 'undefined') return '';

    // 1. Locate the container representing the active screen or open modal
    let targetContainer: HTMLElement | null = null;

    if (originEl) {
      // Check if within open modal/dialog first
      const modal = originEl.closest(
        '[role="dialog"], [role="alertdialog"], .fixed.inset-0, .absolute.inset-0'
      ) as HTMLElement | null;

      if (modal) {
        targetContainer = modal;
      } else {
        // Traverse upwards to find the active screen root
        let curr: HTMLElement | null = originEl;
        while (curr && curr.parentElement && curr.parentElement !== document.body) {
          const parent = curr.parentElement;
          if (
            parent.classList.contains('overflow-y-auto') &&
            !curr.classList.contains('overflow-y-auto') &&
            curr.tagName !== 'NAV' &&
            !curr.classList.contains('fixed')
          ) {
            targetContainer = curr;
            break;
          }
          curr = parent;
        }
      }
    }

    // Fallback: If no screen container found from originEl, look for top modal or screen in document
    if (!targetContainer) {
      const activeModal = document.querySelector(
        '[role="dialog"]:not([hidden]), [role="alertdialog"]:not([hidden]), .fixed.inset-0:not(.hidden)'
      ) as HTMLElement | null;

      if (activeModal) {
        targetContainer = activeModal;
      } else {
        // Find main scrollable content in DeviceFrame/AppContent
        const scrollContainers = document.querySelectorAll('.overflow-y-auto');
        const mainScroll = (scrollContainers[scrollContainers.length - 1] || scrollContainers[0]) as HTMLElement | null;
        if (mainScroll) {
          for (let i = 0; i < mainScroll.children.length; i++) {
            const child = mainScroll.children[i] as HTMLElement;
            if (
              child.tagName !== 'NAV' &&
              !child.classList.contains('fixed') &&
              !child.classList.contains('hidden') &&
              child.offsetHeight > 50
            ) {
              targetContainer = child;
              break;
            }
          }
          if (!targetContainer) {
            targetContainer = mainScroll;
          }
        }
      }
    }

    if (!targetContainer) {
      targetContainer = document.body;
    }

    const collectedSentences: string[] = [];
    let currentBlockBuffer: string[] = [];

    const flushBlock = () => {
      if (currentBlockBuffer.length === 0) return;
      const blockText = currentBlockBuffer.join(' ').replace(/\s+/g, ' ').trim();
      currentBlockBuffer = [];
      if (!blockText) return;

      // Ensure it ends with appropriate sentence punctuation
      if (/[.!?।॥;:]$/.test(blockText)) {
        collectedSentences.push(blockText);
      } else {
        collectedSentences.push(blockText + '.');
      }
    };

    const isExcluded = (el: HTMLElement): boolean => {
      const tag = el.tagName.toLowerCase();

      // Technical / non-visual tags
      if (
        tag === 'script' ||
        tag === 'style' ||
        tag === 'noscript' ||
        tag === 'template' ||
        tag === 'svg' ||
        tag === 'path' ||
        tag === 'circle' ||
        tag === 'line' ||
        tag === 'polyline' ||
        tag === 'polygon' ||
        tag === 'rect' ||
        tag === 'g' ||
        tag === 'use' ||
        tag === 'defs' ||
        tag === 'clippath'
      ) {
        return true;
      }

      // Hidden or file inputs
      if (tag === 'input') {
        const inputType = (el as HTMLInputElement).type?.toLowerCase();
        if (inputType === 'file' || inputType === 'hidden') {
          return true;
        }
      }

      // Read aloud button controls and soundwave indicators
      if (
        el.hasAttribute('data-read-aloud-control') ||
        el.getAttribute('id')?.startsWith('read-aloud-') ||
        el.classList.contains('read-aloud-control') ||
        el.closest('[data-read-aloud-control]') !== null ||
        el.closest('.read-aloud-control') !== null
      ) {
        return true;
      }

      // Navigation elements (BottomNav, desktop header bar, status bar)
      if (
        tag === 'nav' ||
        el.hasAttribute('data-bottom-nav') ||
        el.classList.contains('bottom-nav') ||
        el.closest('nav') !== null ||
        el.closest('[data-bottom-nav]') !== null ||
        el.closest('.bottom-nav') !== null ||
        el.closest('.fixed.bottom-0') !== null ||
        el.closest('header') !== null ||
        el.closest('[data-status-bar]') !== null
      ) {
        return true;
      }

      // Visibility / display checks
      if (el.hasAttribute('hidden') || el.classList.contains('hidden')) {
        return true;
      }
      if (el.getAttribute('aria-hidden') === 'true') {
        return true;
      }

      try {
        const style = window.getComputedStyle(el);
        if (
          style.display === 'none' ||
          style.visibility === 'hidden' ||
          style.opacity === '0' ||
          style.visibility === 'collapse'
        ) {
          return true;
        }
      } catch {
        // ignore
      }

      return false;
    };

    const isBlockTag = (tag: string): boolean => {
      return [
        'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'div', 'section', 'article', 'main', 'aside', 'header', 'footer',
        'li', 'ul', 'ol', 'tr', 'th', 'td', 'table',
        'blockquote', 'dt', 'dd', 'dl', 'fieldset', 'form', 'legend', 'label',
        'details', 'summary', 'figure', 'figcaption', 'caption', 'hr'
      ].includes(tag);
    };

    const walk = (node: Node) => {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const el = node as HTMLElement;
        if (isExcluded(el)) {
          return;
        }

        const tag = el.tagName.toLowerCase();
        const isBlock = isBlockTag(tag);

        if (isBlock) {
          flushBlock();
        }

        // Check for user-entered input or select values
        if (tag === 'input') {
          const val = (el as HTMLInputElement).value?.trim();
          if (val) {
            currentBlockBuffer.push(val);
          }
        } else if (tag === 'textarea') {
          const val = (el as HTMLTextAreaElement).value?.trim();
          if (val) {
            currentBlockBuffer.push(val);
          }
        } else if (tag === 'select') {
          const selectedOpt = (el as HTMLSelectElement).selectedOptions?.[0]?.textContent?.trim();
          if (selectedOpt) {
            currentBlockBuffer.push(selectedOpt);
          }
        } else {
          // Traverse child nodes in document order
          for (let i = 0; i < node.childNodes.length; i++) {
            walk(node.childNodes[i]);
          }
        }

        if (isBlock) {
          flushBlock();
        }
      } else if (node.nodeType === Node.TEXT_NODE) {
        const text = node.textContent?.trim();
        if (text) {
          // Exclude purely cosmetic symbols like •, |, —, etc.
          if (/^[-–—•·|/\\*#]+$/.test(text)) {
            return;
          }
          currentBlockBuffer.push(text);
        }
      }
    };

    walk(targetContainer);
    flushBlock();

    // Deduplicate identical consecutive sentences if any
    const finalSentences: string[] = [];
    for (const s of collectedSentences) {
      if (finalSentences.length === 0 || finalSentences[finalSentences.length - 1] !== s) {
        finalSentences.push(s);
      }
    }

    return finalSentences.join(' ').replace(/\s+/g, ' ').trim();
  }
}

export const voiceAssistant = new VoiceAssistantService();
