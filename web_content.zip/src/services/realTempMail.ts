import { EmailMessage } from '../types/index.ts';
import { detectOtpAndLinks } from './otpDetector.ts';

const GUERRILLA_PROXY = '/api/guerrilla/ajax.php';
const GUERRILLA_DIRECT = 'https://api.guerrillamail.com/ajax.php';
const MAILTM_PROXY = '/api/mailtm';
const MAILTM_DIRECT = 'https://api.mail.tm';

const STORAGE_SESSION_KEY = 'tempbox_real_session_v3';

export interface RealMailSession {
  engine: 'mailtm' | 'guerrilla';
  address: string;
  username: string;
  domain: string;
  sidToken?: string; // For Guerrilla Mail
  mailTmToken?: string; // For Mail.tm
  mailTmPassword?: string;
  createdAt: number;
}

export const LIVE_DOMAINS = [
  { domain: 'maxxspace.com', label: 'maxxspace.com (Recommended - Real Worldwide Inbound)', engine: 'mailtm' as const },
  { domain: 'guerrillamailblock.com', label: 'guerrillamailblock.com (Guerrilla Engine)', engine: 'guerrilla' as const },
  { domain: 'guerrillamail.com', label: 'guerrillamail.com (Classic)', engine: 'guerrilla' as const },
  { domain: 'sharklasers.com', label: 'sharklasers.com', engine: 'guerrilla' as const },
  { domain: 'grr.la', label: 'grr.la (Short alias)', engine: 'guerrilla' as const },
];

/**
 * Play an audible chime when an email or verification code arrives.
 */
export function playNotificationSound() {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.setValueAtTime(739.99, ctx.currentTime + 0.08); // F#5
    osc.frequency.setValueAtTime(880.00, ctx.currentTime + 0.16); // A5
    osc.frequency.setValueAtTime(1174.66, ctx.currentTime + 0.24); // D6

    gain.gain.setValueAtTime(0.35, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.55);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.55);

    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 200]);
    }
  } catch (e) {}
}

async function requestMailTm(endpoint: string, options: RequestInit = {}): Promise<Response> {
  // 1. Try proxy
  try {
    const res = await fetch(`${MAILTM_PROXY}${endpoint}`, options);
    if (res.ok || res.status === 422 || res.status === 401) {
      return res;
    }
  } catch (e) {}

  // 2. Direct fallback
  return await fetch(`${MAILTM_DIRECT}${endpoint}`, options);
}

async function fetchGuerrilla(params: Record<string, string>): Promise<any> {
  const query = new URLSearchParams(params).toString();
  try {
    const res = await fetch(`${GUERRILLA_PROXY}?${query}`);
    if (res.ok) return await res.json();
  } catch (e) {}

  const directRes = await fetch(`${GUERRILLA_DIRECT}?${query}`);
  return await directRes.json();
}

async function postGuerrilla(params: Record<string, string>): Promise<any> {
  const body = new URLSearchParams(params).toString();
  try {
    const res = await fetch(GUERRILLA_PROXY, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    });
    if (res.ok) return await res.json();
  } catch (e) {}

  const directRes = await fetch(GUERRILLA_DIRECT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  return await directRes.json();
}

export class RealTempMailService {
  /**
   * Retrieves saved session from localStorage
   */
  public static getStoredSession(): RealMailSession | null {
    try {
      // Clear old v2 session if present to upgrade
      localStorage.removeItem('tempbox_real_session_v2');
      const saved = localStorage.getItem(STORAGE_SESSION_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.address && !parsed.address.includes('tempbox.io')) {
          return parsed;
        }
      }
    } catch {}
    return null;
  }

  /**
   * Initializes or creates a new real temporary email session
   */
  public static async initOrCreateSession(
    customUser?: string,
    preferredDomain: string = 'maxxspace.com'
  ): Promise<RealMailSession> {
    const domainDef = LIVE_DOMAINS.find((d) => d.domain === preferredDomain) || LIVE_DOMAINS[0];

    if (domainDef.engine === 'mailtm') {
      // --- MAIL.TM ENGINE (High deliverability) ---
      let domainToUse = domainDef.domain;
      try {
        const domRes = await requestMailTm('/domains');
        if (domRes.ok) {
          const domData = await domRes.json();
          const activeMembers = domData['hydra:member'] || [];
          if (activeMembers.length > 0) {
            const found = activeMembers.find((d: any) => d.domain === preferredDomain);
            domainToUse = found ? found.domain : activeMembers[0].domain;
          }
        }
      } catch (e) {
        domainToUse = 'maxxspace.com';
      }

      let username = (customUser || 'box_' + Math.random().toString(36).substring(2, 8)).toLowerCase().replace(/[^a-z0-9._-]/g, '');
      if (username.length < 3) username += Math.random().toString(36).substring(2, 6);
      let address = `${username}@${domainToUse}`;
      const password = 'Tb!' + Math.random().toString(36).substring(2, 10) + '9X!';

      // Create account
      let accountCreated = false;
      let accRes = await requestMailTm('/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address, password }),
      });

      if (accRes.status === 201) {
        accountCreated = true;
      } else if (accRes.status === 422) {
        // Account exists, try with random suffix
        username = `${username}_${Math.floor(100 + Math.random() * 900)}`;
        address = `${username}@${domainToUse}`;
        accRes = await requestMailTm('/accounts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ address, password }),
        });
        if (accRes.status === 201) {
          accountCreated = true;
        }
      }

      // Obtain JWT token
      let token = '';
      const tokRes = await requestMailTm('/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address, password }),
      });

      if (tokRes.ok) {
        const tokData = await tokRes.json();
        token = tokData.token;
      } else {
        // Direct attempt
        const directTok = await fetch(`${MAILTM_DIRECT}/token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ address, password }),
        });
        if (directTok.ok) {
          const tokData = await directTok.json();
          token = tokData.token;
        }
      }

      const session: RealMailSession = {
        engine: 'mailtm',
        address,
        username,
        domain: domainToUse,
        mailTmToken: token,
        mailTmPassword: password,
        createdAt: Date.now(),
      };

      localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(session));
      return session;
    } else {
      // --- GUERRILLA MAIL ENGINE ---
      const initData = await fetchGuerrilla({ f: 'get_email_address' });
      const sidToken = initData.sid_token;
      let finalAddress = initData.email_addr;
      let user = initData.email_addr.split('@')[0];

      if (customUser) {
        const targetUser = customUser.replace(/[^a-zA-Z0-9._-]/g, '').toLowerCase();
        try {
          const setData = await postGuerrilla({
            f: 'set_email_user',
            email_user: targetUser,
            sid_token: sidToken,
          });
          user = setData.email_addr ? setData.email_addr.split('@')[0] : targetUser;
          finalAddress = `${user}@${preferredDomain}`;
        } catch (e) {
          finalAddress = `${targetUser}@${preferredDomain}`;
        }
      } else {
        finalAddress = `${user}@${preferredDomain}`;
      }

      const session: RealMailSession = {
        engine: 'guerrilla',
        address: finalAddress,
        username: user,
        domain: preferredDomain,
        sidToken,
        createdAt: Date.now(),
      };

      localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(session));
      return session;
    }
  }

  /**
   * Fetches real incoming messages from the active mail server
   */
  public static async fetchMessages(session: RealMailSession): Promise<EmailMessage[]> {
    if (!session) return [];

    if (session.engine === 'mailtm') {
      let token = session.mailTmToken;
      if (!token) return [];

      let res = await requestMailTm('/messages', {
        headers: { Authorization: `Bearer ${token}` },
      });

      // If token expired, auto-refresh token
      if (res.status === 401 && session.mailTmPassword) {
        const reauth = await requestMailTm('/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ address: session.address, password: session.mailTmPassword }),
        });
        if (reauth.ok) {
          const tokData = await reauth.json();
          token = tokData.token;
          session.mailTmToken = token;
          localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(session));
          res = await requestMailTm('/messages', {
            headers: { Authorization: `Bearer ${token}` },
          });
        }
      }

      if (!res.ok) return [];

      const data = await res.json();
      const members = data['hydra:member'] || [];
      const messages: EmailMessage[] = [];

      for (const m of members) {
        let fullHtml = '';
        let fullText = m.intro || '';
        try {
          const dRes = await requestMailTm(`/messages/${m.id}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (dRes.ok) {
            const detail = await dRes.json();
            fullHtml = detail.html?.[0] || detail.text || '';
            fullText = detail.text || m.intro || '';
          }
        } catch {}

        const rawForOtp = `${m.subject}\n${fullText}\n${fullHtml}`;
        const otpData = detectOtpAndLinks(rawForOtp);

        messages.push({
          id: `mtm_${m.id}`,
          mailboxId: 'real_inbox',
          fromAddress: m.from?.address || 'security@service.com',
          fromName: m.from?.name || m.from?.address?.split('@')[0] || 'Verification Service',
          toAddress: session.address,
          subject: m.subject || '(No Subject)',
          textPreview: m.intro || fullText.slice(0, 140),
          htmlBody: fullHtml || `<p style="font-family:sans-serif;color:#e2e8f0;padding:12px;">${fullText}</p>`,
          plainText: fullText,
          extractedOtp: otpData.code,
          verificationUrl: otpData.url,
          isRead: m.seen || false,
          isSpam: false,
          hasTrackers: fullHtml.includes('pixel') || fullHtml.includes('tracker'),
          sizeBytes: m.size || 1024,
          receivedAt: m.createdAt || new Date().toISOString(),
          attachments: (m.attachments || []).map((att: any, idx: number) => ({
            id: att.id || `att_${idx}`,
            filename: att.filename || 'attachment',
            contentType: att.contentType || 'application/octet-stream',
            sizeBytes: att.size || 0,
            downloadUrl: att.downloadUrl || '#',
          })),
        });
      }

      return messages;
    } else if (session.engine === 'guerrilla' && session.sidToken) {
      try {
        const checkData = await fetchGuerrilla({
          f: 'get_email_list',
          offset: '0',
          sid_token: session.sidToken,
        });

        const list = checkData.list || [];
        const messages: EmailMessage[] = [];

        for (const item of list) {
          // If there are incoming external emails, skip Guerrilla's welcome email (mail_id: 1)
          if (list.length > 1 && String(item.mail_id) === '1') {
            continue;
          }

          let bodyHtml = item.mail_excerpt || '';
          let bodyText = item.mail_excerpt || '';

          try {
            const detail = await fetchGuerrilla({
              f: 'fetch_email',
              email_id: String(item.mail_id),
              sid_token: session.sidToken,
            });
            if (detail.mail_body) {
              bodyHtml = detail.mail_body;
              bodyText = detail.mail_body.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
            }
          } catch (e) {}

          const rawForOtp = `${item.mail_subject}\n${bodyText}\n${bodyHtml}`;
          const otpData = detectOtpAndLinks(rawForOtp);

          messages.push({
            id: `guer_${item.mail_id}`,
            mailboxId: 'real_inbox',
            fromAddress: item.mail_from || 'security@service.com',
            fromName: item.mail_from?.split('<')[0]?.trim() || item.mail_from || 'Verification Service',
            toAddress: session.address,
            subject: item.mail_subject || '(No Subject)',
            textPreview: item.mail_excerpt || bodyText.slice(0, 140),
            htmlBody: bodyHtml,
            plainText: bodyText,
            extractedOtp: otpData.code,
            verificationUrl: otpData.url,
            isRead: item.mail_read === 1,
            isSpam: false,
            hasTrackers: bodyHtml.includes('pixel') || bodyHtml.includes('tracker'),
            sizeBytes: item.mail_size ? parseInt(item.mail_size) : 2048,
            receivedAt: item.mail_timestamp
              ? new Date(item.mail_timestamp * 1000).toISOString()
              : new Date().toISOString(),
            attachments: [],
          });
        }

        return messages;
      } catch (e) {
        console.warn('[RealTempMail] Guerrilla error:', e);
        return [];
      }
    }

    return [];
  }

  /**
   * Deletes a message
   */
  public static async deleteMessage(session: RealMailSession, messageId: string) {
    if (session.engine === 'mailtm' && session.mailTmToken) {
      const rawId = messageId.replace('mtm_', '');
      try {
        await requestMailTm(`/messages/${rawId}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${session.mailTmToken}` },
        });
      } catch (e) {}
    } else if (session.engine === 'guerrilla' && session.sidToken) {
      const rawId = messageId.replace('guer_', '');
      try {
        await postGuerrilla({
          f: 'del_email',
          'email_ids[]': rawId,
          sid_token: session.sidToken,
        });
      } catch (e) {}
    }
  }
}
