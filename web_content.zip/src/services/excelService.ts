import * as XLSX from 'xlsx';
import { Customer, ImportPreviewRow, ServiceType, CustomerStatus, Bill, Payment } from '../types';
import { storage } from './storage';

export class ExcelService {
  /**
   * Parse uploaded Excel or CSV file buffer
   */
  async parseCustomerFile(file: File): Promise<ImportPreviewRow[]> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const jsonData = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

          const existingCustomers = storage.getCustomers();
          const previewRows = this.mapJsonToPreviewRows(jsonData, existingCustomers);
          resolve(previewRows);
        } catch (err) {
          reject(new Error('Failed to parse Excel/CSV spreadsheet: ' + (err as Error).message));
        }
      };

      reader.onerror = () => reject(new Error('File reading failed'));
      reader.readAsArrayBuffer(file);
    });
  }

  private mapJsonToPreviewRows(rows: Record<string, any>[], existingCustomers: Customer[]): ImportPreviewRow[] {
    const preview: ImportPreviewRow[] = [];
    const existingPhones = new Set(existingCustomers.map(c => c.mobile.replace(/\D/g, '')));
    const existingCodes = new Set(existingCustomers.map(c => c.customerCode.trim().toUpperCase()));

    let nextCodeCounter = 1000 + existingCustomers.length;

    rows.forEach((row, index) => {
      const errors: string[] = [];
      const rowKeys = Object.keys(row);

      const findVal = (keywords: string[]): string => {
        for (const k of rowKeys) {
          const lowerK = k.toLowerCase().trim();
          if (keywords.some(kw => lowerK.includes(kw))) {
            return String(row[k] || '').trim();
          }
        }
        return '';
      };

      const name = findVal(['name', 'customer', 'grahak', 'client']) || `Customer ${index + 1}`;
      let mobile = findVal(['mobile', 'phone', 'contact', 'cell', 'tel']).replace(/\D/g, '');
      if (mobile.length > 10) mobile = mobile.slice(-10); // Standard Indian 10-digit
      if (!mobile) {
        errors.push('Mobile number missing');
      }

      let customerCode = findVal(['code', 'id', 'cust_id', 'cid']).toUpperCase();
      if (!customerCode) {
        customerCode = `CNC-${++nextCodeCounter}`;
      }

      const address = findVal(['address', 'street', 'house', 'plot', 'sahi', 'landmark']) || 'Champeswar';
      const area = findVal(['area', 'village', 'ward', 'location', 'colony']) || 'Champeswar Bazar';
      
      const rawService = findVal(['service', 'type', 'category', 'connection']).toUpperCase();
      let serviceType: ServiceType = 'CABLE';
      if (rawService.includes('BROADBAND') || rawService.includes('NET') || rawService.includes('FIBER') || rawService.includes('ISP')) {
        serviceType = 'BROADBAND';
      } else if (rawService.includes('COMBO') || rawService.includes('BOTH')) {
        serviceType = 'COMBO';
      }

      const planName = findVal(['plan', 'pack', 'package']) || (serviceType === 'CABLE' ? 'Cable Standard HD' : 'Fiber 50Mbps Unlimited');
      
      const rawAmount = findVal(['amount', 'monthly', 'price', 'fee', 'charge', 'rate']);
      const monthlyAmount = parseFloat(rawAmount) || (serviceType === 'CABLE' ? 280 : 499);

      const rawPrevDues = findVal(['due', 'previous', 'pending', 'balance', 'outstanding']);
      const previousDues = parseFloat(rawPrevDues) || 0;

      const rawStatus = findVal(['status', 'active', 'state']).toUpperCase();
      let status: CustomerStatus = 'ACTIVE';
      if (rawStatus.includes('INACT') || rawStatus.includes('DIS') || rawStatus.includes('OFF')) {
        status = 'INACTIVE';
      } else if (rawStatus.includes('SUSP')) {
        status = 'SUSPENDED';
      }

      // Duplicate detection
      let isDuplicate = false;
      let duplicateReason: string | undefined;

      if (mobile && existingPhones.has(mobile)) {
        isDuplicate = true;
        duplicateReason = `Mobile ${mobile} already registered`;
      } else if (existingCodes.has(customerCode)) {
        isDuplicate = true;
        duplicateReason = `Customer Code ${customerCode} already exists`;
      }

      preview.push({
        rowNumber: index + 2, // 1-indexed, +1 for header row
        customerCode,
        name,
        mobile,
        address,
        area,
        serviceType,
        planName,
        monthlyAmount,
        previousDues,
        status,
        isDuplicate,
        duplicateReason,
        isValid: errors.length === 0,
        errors,
      });
    });

    return preview;
  }

  /**
   * Commit preview rows to storage
   */
  importPreviewRows(rows: ImportPreviewRow[], handleDuplicates: 'skip' | 'overwrite'): { added: number; updated: number } {
    let added = 0;
    let updated = 0;
    const existingList = storage.getCustomers();

    rows.forEach(r => {
      if (!r.isValid) return;

      const existingIndex = existingList.findIndex(
        c => (c.mobile && c.mobile === r.mobile) || c.customerCode === r.customerCode
      );

      if (existingIndex >= 0) {
        if (handleDuplicates === 'skip') {
          return;
        }
        // Overwrite/update existing
        const existing = existingList[existingIndex];
        existing.name = r.name;
        existing.address = r.address;
        existing.area = r.area;
        existing.serviceType = r.serviceType;
        existing.planName = r.planName;
        existing.monthlyAmount = r.monthlyAmount;
        existing.previousDues = r.previousDues;
        existing.totalOutstanding = existing.previousDues + existing.currentDues;
        existing.status = r.status;
        existing.updatedAt = new Date().toISOString();
        storage.saveCustomer(existing);
        updated++;
      } else {
        // Add new customer
        const newCust: Customer = {
          id: `cust-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          customerCode: r.customerCode,
          name: r.name,
          mobile: r.mobile,
          address: r.address,
          area: r.area,
          serviceType: r.serviceType,
          planName: r.planName,
          monthlyAmount: r.monthlyAmount,
          status: r.status,
          connectionDate: new Date().toISOString().split('T')[0],
          previousDues: r.previousDues,
          currentDues: r.monthlyAmount,
          totalOutstanding: r.previousDues + r.monthlyAmount,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        storage.saveCustomer(newCust);
        added++;
      }
    });

    return { added, updated };
  }

  /**
   * Export all Customers to Excel (.xlsx)
   */
  exportCustomersExcel(): void {
    const customers = storage.getCustomers();
    const rows = customers.map(c => ({
      'Customer Code': c.customerCode,
      'Customer Name': c.name,
      'Mobile Number': c.mobile,
      'Area / Village': c.area,
      'Street Address': c.address,
      'Service Type': c.serviceType,
      'Plan Name': c.planName,
      'Monthly Plan (₹)': c.monthlyAmount,
      'Previous Dues (₹)': c.previousDues,
      'Current Dues (₹)': c.currentDues,
      'Total Outstanding (₹)': c.totalOutstanding,
      'Status': c.status,
      'Connection Date': c.connectionDate,
      'Set-Top Box / ONT': c.setupBoxNo || '-',
      'IP / MAC': c.ipOrMacAddress || '-',
      'Notes': c.notes || '',
    }));

    const worksheet = XLSX.utils.json_to_sheet(rows);
    // Auto-fit column widths
    const colWidths = [
      { wch: 15 }, // Code
      { wch: 25 }, // Name
      { wch: 15 }, // Mobile
      { wch: 20 }, // Area
      { wch: 25 }, // Address
      { wch: 14 }, // Service
      { wch: 28 }, // Plan
      { wch: 16 }, // Monthly
      { wch: 16 }, // Prev
      { wch: 16 }, // Curr
      { wch: 18 }, // Total
      { wch: 12 }, // Status
      { wch: 15 }, // Conn Date
      { wch: 18 }, // STB
      { wch: 22 }, // IP
      { wch: 25 }, // Notes
    ];
    worksheet['!cols'] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Customers Master');

    const fileName = `CCTV_Network_Champeswar_Customers_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(workbook, fileName);
  }

  /**
   * Export Monthly Billing & Collection Report
   */
  exportMonthlyCollectionExcel(billingMonth: string): void {
    const bills = storage.getBillsForMonth(billingMonth);
    const payments = storage.getPayments().filter(p => p.billingMonth === billingMonth);

    // Sheet 1: Monthly Bills & Status
    const billsData = bills.map(b => ({
      'Bill No': b.billNumber,
      'Customer Code': b.customerCode,
      'Customer Name': b.customerName,
      'Mobile': b.mobile,
      'Area': b.area,
      'Service': b.serviceType,
      'Plan Amount (₹)': b.planAmount,
      'Previous Dues (₹)': b.previousDues,
      'Total Payable (₹)': b.totalAmount,
      'Paid Amount (₹)': b.paidAmount,
      'Balance Due (₹)': b.balanceDue,
      'Payment Status': b.status,
      'Due Date': b.dueDate,
    }));

    // Sheet 2: Payments Ledger
    const paymentsData = payments.map(p => ({
      'Receipt No': p.receiptNo,
      'Customer Code': p.customerCode,
      'Customer Name': p.customerName,
      'Mobile': p.mobile,
      'Amount (₹)': p.amount,
      'Mode': p.paymentMethod,
      'UPI Ref / UTR': p.upiRefNo || '-',
      'Payment Date': p.paymentDate,
      'Collected By': p.collectedBy,
      'Remarks': p.notes || '',
    }));

    const workbook = XLSX.utils.book_new();

    const wsBills = XLSX.utils.json_to_sheet(billsData);
    wsBills['!cols'] = [{ wch: 18 }, { wch: 14 }, { wch: 25 }, { wch: 14 }, { wch: 18 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 14 }];
    XLSX.utils.book_append_sheet(workbook, wsBills, `Bills ${billingMonth}`);

    const wsPayments = XLSX.utils.json_to_sheet(paymentsData);
    wsPayments['!cols'] = [{ wch: 18 }, { wch: 14 }, { wch: 25 }, { wch: 14 }, { wch: 14 }, { wch: 10 }, { wch: 25 }, { wch: 14 }, { wch: 20 }, { wch: 25 }];
    XLSX.utils.book_append_sheet(workbook, wsPayments, `Collections ${billingMonth}`);

    const fileName = `CCTV_Champeswar_Billing_Report_${billingMonth}.xlsx`;
    XLSX.writeFile(workbook, fileName);
  }

  /**
   * Download a blank Google Sheets / Excel import template
   */
  downloadTemplateExcel(): void {
    const templateRows = [
      {
        'Customer ID': 'CNC-1011',
        'Customer Name': 'Pradeep Kumar Mohanty',
        'Mobile Number': '9437890123',
        'Area / Village': 'Mandir Sahi',
        'Address': 'Opposite Town Hall, Plot 88',
        'Service Type': 'COMBO',
        'Plan Name': 'Fiber 50Mbps + 350 Channels HD',
        'Monthly Amount': 699,
        'Previous Dues': 0,
        'Status': 'ACTIVE',
      },
      {
        'Customer ID': 'CNC-1012',
        'Customer Name': 'Santosh Kumar Swain',
        'Mobile Number': '9861445566',
        'Area / Village': 'Champeswar Bazar',
        'Address': 'Bazar Main Road, Near SBI ATM',
        'Service Type': 'CABLE',
        'Plan Name': 'Digital Cable Odia Super Pack',
        'Monthly Amount': 280,
        'Previous Dues': 280,
        'Status': 'ACTIVE',
      },
      {
        'Customer ID': 'CNC-1013',
        'Customer Name': 'Amiya Kumar Jena',
        'Mobile Number': '9938112233',
        'Area / Village': 'College Road',
        'Address': 'Near ITI College Gate',
        'Service Type': 'BROADBAND',
        'Plan Name': 'Fiber Super 100Mbps Unlimited',
        'Monthly Amount': 799,
        'Previous Dues': 0,
        'Status': 'ACTIVE',
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateRows);
    worksheet['!cols'] = [
      { wch: 14 }, { wch: 25 }, { wch: 15 }, { wch: 18 }, { wch: 30 },
      { wch: 14 }, { wch: 30 }, { wch: 15 }, { wch: 15 }, { wch: 12 },
    ];
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Customer_Import_Template');
    XLSX.writeFile(workbook, 'CCTV_Network_Champeswar_Import_Template.xlsx');
  }
}

export const excelService = new ExcelService();
