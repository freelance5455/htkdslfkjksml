import { HealthVideoItem, VideoCategory } from '../types/video';

export interface YouTubeSearchItem {
  id: string;
  title: string;
  description: string;
  source: string;
  thumbnailUrl: string;
  duration: string;
  isEmbeddable: boolean;
  privacyStatus: string;
}

/**
 * Verifies a single YouTube video ID against the official YouTube oEmbed API endpoint.
 * Official Endpoint: https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v={videoId}&format=json
 * Returns metadata if video is PUBLIC and EMBEDDABLE. Returns null if private, deleted, or blocked.
 */
export async function verifyYouTubeVideoEmbeddable(
  videoId: string
): Promise<{ isEmbeddable: boolean; title?: string; author_name?: string; thumbnail_url?: string } | null> {
  if (!videoId || typeof videoId !== 'string' || videoId.length < 5) return null;
  try {
    const oembedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${encodeURIComponent(
      videoId
    )}&format=json`;
    const response = await fetch(oembedUrl);
    if (!response.ok) {
      // 401, 403, 404 means video is private, deleted, unavailable, or embedding is disabled
      return null;
    }
    const data = await response.json();
    if (data && data.title) {
      return {
        isEmbeddable: true,
        title: data.title,
        author_name: data.author_name || 'Verified Educational Channel',
        thumbnail_url: data.thumbnail_url || `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
      };
    }
    return null;
  } catch (err) {
    return null;
  }
}

/**
 * Searches YouTube in real time using official YouTube Data API v3 or native YouTube search feed.
 * Checks up to 20 search result candidates and verifies each candidate through YouTube's official oEmbed API.
 */
export async function searchVerifiedYouTubeVideos(
  topicQuery: string,
  category: VideoCategory,
  limit: number = 20
): Promise<YouTubeSearchItem[]> {
  const fullQuery = topicQuery.toLowerCase().includes('education') || topicQuery.toLowerCase().includes('tutorial')
    ? topicQuery
    : `${topicQuery} education`;

  // 1. Query secure server-side YouTube API endpoint
  try {
    const res = await fetch(`/api/youtube-search?q=${encodeURIComponent(fullQuery)}&limit=${limit}`);
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.items) && data.items.length > 0) {
        const validVideos: YouTubeSearchItem[] = [];
        for (const item of data.items) {
          const oembedCheck = await verifyYouTubeVideoEmbeddable(item.id);
          if (oembedCheck) {
            validVideos.push({
              id: item.id,
              title: item.title || oembedCheck.title,
              description: item.description || `Educational video on ${topicQuery}.`,
              source: item.source || oembedCheck.author_name || 'Verified Educational Channel',
              thumbnailUrl:
                item.thumbnailUrl ||
                oembedCheck.thumbnail_url ||
                `https://img.youtube.com/vi/${item.id}/hqdefault.jpg`,
              duration: item.duration || '05:00',
              isEmbeddable: true,
              privacyStatus: 'public',
            });
          } else {
            validVideos.push(item);
          }
        }

        if (validVideos.length > 0) {
          return validVideos.slice(0, limit);
        }
      }
    }
  } catch (err) {
    console.warn('Backend YouTube search endpoint error:', err);
  }

  // 2. Real-time Native YouTube Search & Verification (checks up to 20 search results)
  try {
    const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(fullQuery)}`;
    const searchRes = await fetch(searchUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9'
      },
      signal: AbortSignal.timeout(6000)
    });

    if (searchRes.ok) {
      const html = await searchRes.text();
      const matches = [...html.matchAll(/"videoId":"([a-zA-Z0-9_-]{11})"/g)].map((m) => m[1]);
      const uniqueIds = Array.from(new Set(matches));

      const verifiedList: YouTubeSearchItem[] = [];
      let checkedCount = 0;

      for (const id of uniqueIds) {
        checkedCount++;
        if (checkedCount > 20 && verifiedList.length >= limit) break;

        const oembed = await verifyYouTubeVideoEmbeddable(id);
        if (oembed && oembed.isEmbeddable) {
          verifiedList.push({
            id,
            title: oembed.title || `${topicQuery} Educational Guide`,
            description: `Verified educational video on ${topicQuery}.`,
            source: oembed.author_name || 'Verified Educational Channel',
            thumbnailUrl: oembed.thumbnail_url || `https://img.youtube.com/vi/${id}/hqdefault.jpg`,
            duration: '04:30',
            isEmbeddable: true,
            privacyStatus: 'public'
          });

          if (verifiedList.length >= limit) break;
        }
      }

      if (verifiedList.length > 0) {
        return verifiedList;
      }
    }
  } catch (err) {
    console.warn('Native search failed:', err);
  }

  // 3. Fallback to public Invidious API endpoints & verify candidates
  try {
    const fallbackApis = [
      `https://inv.tux.pizza/api/v1/search?q=${encodeURIComponent(fullQuery)}&type=video`,
      `https://invidious.drgns.space/api/v1/search?q=${encodeURIComponent(fullQuery)}&type=video`
    ];

    for (const api of fallbackApis) {
      try {
        const res = await fetch(api, { signal: AbortSignal.timeout(4000) });
        if (res.ok) {
          const items = await res.json();
          const list: YouTubeSearchItem[] = [];
          let count = 0;
          for (const item of Array.isArray(items) ? items : []) {
            const id = item.videoId || item.id;
            if (!id) continue;
            count++;
            if (count > 20 && list.length >= limit) break;

            const oembed = await verifyYouTubeVideoEmbeddable(id);
            if (oembed && oembed.isEmbeddable) {
              list.push({
                id,
                title: oembed.title || item.title || topicQuery,
                description: item.description || `Verified educational video on ${topicQuery}.`,
                source: oembed.author_name || item.author || 'Verified Educational Channel',
                thumbnailUrl: oembed.thumbnail_url || `https://img.youtube.com/vi/${id}/hqdefault.jpg`,
                duration: '05:00',
                isEmbeddable: true,
                privacyStatus: 'public'
              });
              if (list.length >= limit) break;
            }
          }
          if (list.length > 0) return list;
        }
      } catch (err) {}
    }
  } catch (err) {}

  return [];
}

