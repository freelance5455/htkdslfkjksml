"use client";

export interface MobilePushAlert {
  id: string;
  category:
    | "HIGH_CONFLUENCE_SIGNAL"
    | "COPY_TRADE_EXECUTED"
    | "SL_TP_TRIGGERED"
    | "EVALUATOR_WARNING";
  titleHe: string;
  bodyHe: string;
  symbol?: string;
  confluenceScore?: number;
  timestamp: number;
  isRead: boolean;
}

class NotificationsService {
  private expoPushToken = "ExponentPushToken[ai-crypto-scanner-il-9942]";
  private fcmDeviceToken = "FCM_ANDROID_com.crypto.scanner_v24_ACTIVE";

  public getDeviceConfig() {
    return {
      expoPushToken: this.expoPushToken,
      fcmDeviceToken: this.fcmDeviceToken,
      packageName: "com.crypto.scanner",
      iconAsset: "./assets/images/crypto_app_icon.png",
    };
  }

  public async requestPermissions(): Promise<boolean> {
    if (typeof window !== "undefined" && "Notification" in window) {
      try {
        if (Notification.permission === "granted") return true;
        const perm = await Notification.requestPermission();
        return perm === "granted";
      } catch {
        return false;
      }
    }
    return true;
  }

  public dispatchPushAlert(
    alert: Omit<MobilePushAlert, "id" | "timestamp" | "isRead">
  ): MobilePushAlert {
    const fullAlert: MobilePushAlert = {
      ...alert,
      id: `PUSH-${Date.now()}-${Math.floor(Math.random() * 999)}`,
      timestamp: Date.now(),
      isRead: false,
    };

    // Fire native Web/Mobile Notification if granted
    if (
      typeof window !== "undefined" &&
      "Notification" in window &&
      Notification.permission === "granted"
    ) {
      try {
        new Notification(fullAlert.titleHe, {
          body: fullAlert.bodyHe,
          icon: "/assets/images/crypto_app_icon.png",
          dir: "rtl",
          lang: "he",
        });
      } catch {
        // Ignore in restricted sandbox iframe
      }
    }

    return fullAlert;
  }
}

export const notificationsService = new NotificationsService();
