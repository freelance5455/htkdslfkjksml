/**
 * Personalized Chess Training Plan Generator
 * Adapts training modules to the user's demonstrated weaknesses in puzzles and games.
 * Avoids unsupported claims with clear insufficient-data states.
 */

import {
  PersonalizedTrainingPlan,
  TrainingDay,
  TrainingModule,
  TacticalTheme,
  PuzzleAttempt,
} from '../types/chess';

const TRAINING_PLAN_KEY = 'chess_3d_training_plan';
const PUZZLE_ATTEMPTS_KEY = 'chess_3d_puzzle_attempts';

export interface TrainingStats {
  totalAttempts: number;
  totalSolved: number;
  accuracyRate: number; // 0 - 100%
  themeStats: Record<TacticalTheme, { attempts: number; solved: number; accuracy: number }>;
  weakestThemes: TacticalTheme[];
  strongestThemes: TacticalTheme[];
  hasSufficientData: boolean;
}

export function loadPuzzleAttempts(): PuzzleAttempt[] {
  try {
    const raw = localStorage.getItem(PUZZLE_ATTEMPTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function savePuzzleAttempt(attempt: PuzzleAttempt): void {
  try {
    const attempts = loadPuzzleAttempts();
    attempts.push(attempt);
    localStorage.setItem(PUZZLE_ATTEMPTS_KEY, JSON.stringify(attempts));
  } catch {
    // Ignore storage errors
  }
}

export function calculateTrainingStats(): TrainingStats {
  const attempts = loadPuzzleAttempts();
  const themeMap: Record<TacticalTheme, { attempts: number; solved: number; accuracy: number }> = {
    fork: { attempts: 0, solved: 0, accuracy: 0 },
    pin: { attempts: 0, solved: 0, accuracy: 0 },
    skewer: { attempts: 0, solved: 0, accuracy: 0 },
    discovered_attack: { attempts: 0, solved: 0, accuracy: 0 },
    double_check: { attempts: 0, solved: 0, accuracy: 0 },
    mate_in_1: { attempts: 0, solved: 0, accuracy: 0 },
    mate_in_2: { attempts: 0, solved: 0, accuracy: 0 },
    mate_in_3: { attempts: 0, solved: 0, accuracy: 0 },
    deflection: { attempts: 0, solved: 0, accuracy: 0 },
    removing_defender: { attempts: 0, solved: 0, accuracy: 0 },
    winning_material: { attempts: 0, solved: 0, accuracy: 0 },
    endgame_tactic: { attempts: 0, solved: 0, accuracy: 0 },
  };

  attempts.forEach((a) => {
    if (themeMap[a.theme]) {
      themeMap[a.theme].attempts++;
      if (a.success) themeMap[a.theme].solved++;
    }
  });

  let totalSolved = 0;
  Object.keys(themeMap).forEach((themeKey) => {
    const t = themeMap[themeKey as TacticalTheme];
    t.accuracy = t.attempts > 0 ? Math.round((t.solved / t.attempts) * 100) : 0;
    totalSolved += t.solved;
  });

  const hasSufficientData = attempts.length >= 3;
  const accuracyRate = attempts.length > 0 ? Math.round((totalSolved / attempts.length) * 100) : 0;

  // Identify weakest and strongest themes
  const testedThemes = Object.entries(themeMap)
    .filter(([_, stats]) => stats.attempts > 0)
    .sort((a, b) => a[1].accuracy - b[1].accuracy);

  const weakestThemes = testedThemes.slice(0, 3).map(([k]) => k as TacticalTheme);
  const strongestThemes = [...testedThemes].reverse().slice(0, 3).map(([k]) => k as TacticalTheme);

  return {
    totalAttempts: attempts.length,
    totalSolved,
    accuracyRate,
    themeStats: themeMap,
    weakestThemes,
    strongestThemes,
    hasSufficientData,
  };
}

/**
 * Generates an adaptive 7-day training plan based on user rating and weaknesses
 */
export function generateAdaptiveWeeklyPlan(
  userRating = 1200,
  dailyDurationMinutes = 30
): PersonalizedTrainingPlan {
  const stats = calculateTrainingStats();
  const weaknesses = stats.weakestThemes.length > 0
    ? stats.weakestThemes
    : (['fork', 'pin', 'endgame_tactic'] as TacticalTheme[]);

  const formatThemeName = (theme: string) => theme.replace(/_/g, ' ').toUpperCase();

  const daysOfWeek = [
    { name: 'Monday', short: 'Mon' },
    { name: 'Tuesday', short: 'Tue' },
    { name: 'Wednesday', short: 'Wed' },
    { name: 'Thursday', short: 'Thu' },
    { name: 'Friday', short: 'Fri' },
    { name: 'Saturday', short: 'Sat' },
    { name: 'Sunday', short: 'Sun' },
  ];

  const days: TrainingDay[] = daysOfWeek.map((day, idx) => {
    const isWeaknessDay = idx % 2 === 0;
    const targetWeakness = weaknesses[idx % weaknesses.length];

    const modules: TrainingModule[] = [
      {
        id: `mod-${day.short}-1`,
        title: 'Tactical Warm-up',
        category: 'tactics',
        durationMinutes: Math.round(dailyDurationMinutes * 0.3),
        completed: false,
        targetCount: 5,
        completedCount: 0,
        description: 'Solve 5 quick puzzles to sharpen pattern recognition.',
      },
      {
        id: `mod-${day.short}-2`,
        title: isWeaknessDay ? `Focus Weakness: ${formatThemeName(targetWeakness)}` : 'Opening Principles & Calculation',
        category: isWeaknessDay ? 'calculation' : 'openings',
        durationMinutes: Math.round(dailyDurationMinutes * 0.4),
        completed: false,
        targetCount: 3,
        completedCount: 0,
        description: isWeaknessDay
          ? `Targeted practice on your demonstrated weakness in ${formatThemeName(targetWeakness)}.`
          : 'Study key candidate moves and strategic continuations.',
      },
      {
        id: `mod-${day.short}-3`,
        title: idx % 3 === 0 ? 'Endgame Fundamentals' : 'Blunder Buster Review',
        category: idx % 3 === 0 ? 'endgames' : 'blunder_review',
        durationMinutes: Math.round(dailyDurationMinutes * 0.3),
        completed: false,
        targetCount: 1,
        completedCount: 0,
        description: idx % 3 === 0
          ? 'Practice essential King & Pawn and Rook endings.'
          : 'Replay your own past mistakes and find better alternative lines.',
      },
    ];

    return {
      dayName: day.name,
      dayShort: day.short,
      modules,
      completed: false,
    };
  });

  const plan: PersonalizedTrainingPlan = {
    id: `plan-${Date.now()}`,
    createdAt: new Date().toISOString(),
    targetRating: userRating + 150,
    weeklyGoalMinutes: dailyDurationMinutes * 7,
    focusWeaknesses: weaknesses.map(formatThemeName),
    days,
  };

  saveTrainingPlan(plan);
  return plan;
}

export function loadTrainingPlan(): PersonalizedTrainingPlan {
  try {
    const raw = localStorage.getItem(TRAINING_PLAN_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // Ignore error
  }
  return generateAdaptiveWeeklyPlan();
}

export function saveTrainingPlan(plan: PersonalizedTrainingPlan): void {
  try {
    localStorage.setItem(TRAINING_PLAN_KEY, JSON.stringify(plan));
  } catch {
    // Ignore error
  }
}
