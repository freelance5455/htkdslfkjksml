/**
 * Natural Language Chess Coach Engine
 * Generates verified tactical and positional explanations in English, Marathi, and Hindi.
 * Distinguishes verified tactical facts from heuristic advice.
 */

import { Chess, Square } from 'chess.js';
import { StockfishAnalysisResult } from '../types/chess';

export interface CoachExplanation {
  headline: string;
  tacticalMotif?: string;
  piecesAttacked: string[];
  threatsCreated: string[];
  kingSafety: string;
  positionalSummary: string;
  recommendedMoveText: string;
}

export interface LocalizedCoachAdvice {
  en: CoachExplanation;
  mr: CoachExplanation;
  hi: CoachExplanation;
}

/**
 * Analyzes attacks, pins, forks, and threats created by a move
 */
export function analyzeMoveTactics(
  fenBefore: string,
  fromSq: string,
  toSq: string
): {
  motif?: string;
  attackedPieces: string[];
  threats: string[];
  kingSafety: 'improves' | 'worsens' | 'neutral';
  controlsCenter: boolean;
} {
  const game = new Chess(fenBefore);
  const movingPiece = game.get(fromSq as Square);
  if (!movingPiece) {
    return { attackedPieces: [], threats: [], kingSafety: 'neutral', controlsCenter: false };
  }

  const pieceNames: Record<string, string> = {
    p: 'Pawn',
    n: 'Knight',
    b: 'Bishop',
    r: 'Rook',
    q: 'Queen',
    k: 'King',
  };

  const attackedPieces: string[] = [];
  const threats: string[] = [];
  let motif: string | undefined = undefined;

  try {
    const moveRes = game.move({ from: fromSq, to: toSq, promotion: 'q' });
    if (!moveRes) {
      return { attackedPieces: [], threats: [], kingSafety: 'neutral', controlsCenter: false };
    }

    // Check check / checkmate
    if (game.isCheckmate()) {
      motif = 'Checkmate Attack';
      threats.push('Delivers decisive checkmate');
    } else if (game.inCheck()) {
      motif = 'Direct Check';
      threats.push('Delivers check to opponent King');
    }

    // Check pieces attacked after the move
    const opponentMoves = game.moves({ verbose: true });
    const board = game.board();

    // Check squares attacked by our moved piece on toSq
    const legalAfterMoves = game.moves({ square: toSq as Square, verbose: true });
    const targetPiecesAttacked = legalAfterMoves
      .map((m) => game.get(m.to))
      .filter((p) => p && p.color !== movingPiece.color);

    targetPiecesAttacked.forEach((p) => {
      if (p) attackedPieces.push(pieceNames[p.type]);
    });

    // Detect Fork: attacking two or more valuable pieces simultaneously
    if (targetPiecesAttacked.length >= 2) {
      motif = `${pieceNames[movingPiece.type]} Fork`;
      threats.push(`Forks opponent's ${targetPiecesAttacked.map((p) => pieceNames[p!.type]).join(' and ')}`);
    }

    // Detect Castling
    if (moveRes.san === 'O-O' || moveRes.san === 'O-O-O') {
      motif = 'Castling & King Shield';
      return {
        motif,
        attackedPieces,
        threats: ['Shields King behind pawns and connects rooks'],
        kingSafety: 'improves',
        controlsCenter: true,
      };
    }

    const centerSquares = ['e4', 'd4', 'e5', 'd5'];
    const controlsCenter = centerSquares.includes(toSq);

    const kingSafety = movingPiece.type === 'k' && !moveRes.san.includes('O-O') ? 'worsens' : 'neutral';

    return {
      motif,
      attackedPieces: Array.from(new Set(attackedPieces)),
      threats,
      kingSafety,
      controlsCenter,
    };
  } catch {
    return { attackedPieces: [], threats: [], kingSafety: 'neutral', controlsCenter: false };
  }
}

/**
 * Generates verified multilingual coach explanations without hallucinations
 */
export function generateCoachExplanation(
  analysis: StockfishAnalysisResult,
  fen: string
): LocalizedCoachAdvice {
  const from = analysis.sourceSquare;
  const to = analysis.targetSquare;
  const bestSan = analysis.bestMoveSan || analysis.bestMove;

  const tactics = analyzeMoveTactics(fen, from, to);

  const evalNum = analysis.whiteScoreCp / 100;
  const evalFormatted = evalNum >= 0 ? `+${evalNum.toFixed(2)}` : evalNum.toFixed(2);

  // English
  const en: CoachExplanation = {
    headline: tactics.motif
      ? `Tactical Advantage: ${tactics.motif}`
      : `Recommended Move: ${bestSan} (${evalFormatted})`,
    tacticalMotif: tactics.motif,
    piecesAttacked: tactics.attackedPieces,
    threatsCreated: tactics.threats.length > 0 ? tactics.threats : ['Controls crucial squares and improves piece coordination'],
    kingSafety: tactics.kingSafety === 'improves'
      ? 'Safeguards the King and reinforces the defensive fortress.'
      : tactics.kingSafety === 'worsens'
      ? 'Exposes the King slightly; proceed with careful calculation.'
      : 'Maintains solid defensive stability.',
    positionalSummary: tactics.controlsCenter
      ? `${bestSan} stakes a firm claim on the center, providing active diagonals and open files.`
      : `${bestSan} reorganizes pieces onto active squares, restricting opponent counterplay.`,
    recommendedMoveText: `Play ${bestSan} to maximize tactical pressure and follow the principal variation (${analysis.lines[0]?.pvSan.slice(0, 4).join(' ') || bestSan}).`,
  };

  // Marathi (मराठी)
  const mr: CoachExplanation = {
    headline: tactics.motif
      ? `रणनीतिक फायदा: ${tactics.motif}`
      : `शिफारस केलेली चाल: ${bestSan} (${evalFormatted})`,
    tacticalMotif: tactics.motif,
    piecesAttacked: tactics.attackedPieces,
    threatsCreated: tactics.threats.length > 0 ? tactics.threats : ['महत्त्वाच्या घरांवर नियंत्रण मिळवून मोहऱ्यांचा ताळमेळ सुधारते'],
    kingSafety: tactics.kingSafety === 'improves'
      ? 'राजाला सुरक्षित करून मजबूत बचावात्मक तटबंदी तयार करते.'
      : tactics.kingSafety === 'worsens'
      ? 'राजा थोडा असुरक्षित होतो; काळजीपूर्वक हिशोब करा.'
      : 'संरक्षणात्मक स्थिरता कायम राखते.',
    positionalSummary: tactics.controlsCenter
      ? `${bestSan} मध्यभागावर (सेंटरवर) मजबूत नियंत्रण मिळवते आणि आक्रमक रेषा उघडते.`
      : `${bestSan} मोहऱ्यांना सक्रिय घरांवर आणून प्रतिस्पर्ध्याच्या हालचालींवर मर्यादा आणते.`,
    recommendedMoveText: `रणनीतिक दबाव वाढवण्यासाठी ${bestSan} खेळा आणि मुख्य व्हेरिएशनचे अनुसरण करा.`,
  };

  // Hindi (हिंदी)
  const hi: CoachExplanation = {
    headline: tactics.motif
      ? `सामरिक लाभ: ${tactics.motif}`
      : `अनुशंसित चाल: ${bestSan} (${evalFormatted})`,
    tacticalMotif: tactics.motif,
    piecesAttacked: tactics.attackedPieces,
    threatsCreated: tactics.threats.length > 0 ? tactics.threats : ['महत्वपूर्ण खानों पर नियंत्रण बनाकर मोहरों का तालमेल बेहतर करती है'],
    kingSafety: tactics.kingSafety === 'improves'
      ? 'राजा को सुरक्षित कर मजबूत रक्षात्मक ढाल तैयार करती है।'
      : tactics.kingSafety === 'worsens'
      ? 'राजा थोड़ा असुरक्षित होता है; सावधानीपूर्वक गणना करें।'
      : 'रक्षात्मक संतुलन बनाए रखती है।',
    positionalSummary: tactics.controlsCenter
      ? `${bestSan} केंद्र (सेंटर) पर मजबूत पकड़ बनाती है और सक्रिय रेखाएं खोलती है।`
      : `${bestSan} मोहरों को सक्रिय खानों पर लाकर प्रतिद्वंद्वी के जवाबी हमले को रोकती है।`,
    recommendedMoveText: `दबाव बढ़ाने के लिए ${bestSan} खेलें और मुख्य वेरिएशन का पालन करें।`,
  };

  return { en, mr, hi };
}
