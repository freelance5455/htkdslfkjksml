/**
 * JARVIS Autonomous Self-Modification Service
 * Communicates with the server-side evolution engine to analyze, create checkpoints,
 * apply targeted source code edits, run syntax verification, and rollback safely.
 */

export interface SelfModificationAnalysis {
  targetFiles: string[];
  plan: string;
  impact: string;
  riskLevel: 'low' | 'medium' | 'high';
  proposedModifications: Array<{ filePath: string; summary: string; diffHint: string }>;
  explanation: string;
}

export interface EvolutionHistoryItem {
  checkpointId: string;
  instruction: string;
  timestamp: number;
  modifiedFiles: string[];
  status: 'applied' | 'rolled_back';
}

class SelfModificationService {
  public async analyzeModification(instruction: string): Promise<{ success: boolean; analysis?: SelfModificationAnalysis; error?: string }> {
    try {
      const res = await fetch('/api/self-modify/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instruction }),
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  }

  public async executeModification(
    instruction: string,
    modifications: Array<{ filePath: string; newContent: string }>
  ): Promise<{ success: boolean; checkpointId?: string; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/self-modify/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instruction, modifications }),
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  }

  public async rollback(checkpointId?: string): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/self-modify/rollback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ checkpointId }),
      });
      return await res.json();
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  }

  public async getHistory(): Promise<EvolutionHistoryItem[]> {
    try {
      const res = await fetch('/api/self-modify/history');
      if (res.ok) {
        const data = await res.json();
        return data.history || [];
      }
    } catch {}
    return [];
  }
}

export const selfModificationService = new SelfModificationService();
