import {
  SymptomItem,
  SymptomAnalysisResult,
  UrgencyLevel,
  PossibleCondition,
  AuthoritativeSource,
  PreferredLanguage,
} from '../types';
import {
  COMMON_SYMPTOMS,
  AUTHORITATIVE_CONDITIONS,
  GENERAL_SELF_CARE_MEASURES_I18N,
  MANDATORY_DISCLAIMER_I18N,
} from '../data/symptomGuideData';

interface LocalizedString {
  English: string;
  Hindi: string;
  Marathi: string;
}

const URGENCY_REASONS: Record<string, LocalizedString> = {
  chest_and_shortness: {
    English:
      'The combination of chest discomfort and shortness of breath is a high-priority warning sign that requires emergency evaluation to rule out acute cardiac or pulmonary conditions.',
    Hindi:
      'छाती में तकलीफ और सांस लेने में कठिनाई का एक साथ होना एक उच्च-प्राथमिकता वाला चेतावनी संकेत है, जिसके लिए तत्काल आपातकालीन जांच जरूरी है ताकि हृदय या फेफड़ों की गंभीर स्थिति की पुष्टि की जा सके।',
    Marathi:
      'छातीतील अस्वस्थता आणि श्वास घेण्यास होणारा त्रास हे एकत्रितपणे गंभीर धोक्याची सूचना आहे. हृदय किंवा फुफ्फुसांच्या गंभीर आजारांची तपासणी करण्यासाठी त्वरित आपत्कालीन वैद्यकीय तपासणी आवश्यक आहे.',
  },
  chest_pain: {
    English:
      'Unexplained chest pain, pressure, or tightness warrants immediate clinical assessment to ensure it is not related to a serious cardiovascular condition.',
    Hindi:
      'छाती में अचानक दर्द, दबाव या भारीपन होने पर तत्काल चिकित्सकीय मूल्यांकन आवश्यक है ताकि हृदय संबंधी किसी गंभीर समस्या से बचा जा सके।',
    Marathi:
      'छातीमध्ये अस्पष्ट वेदना, दाब किंवा आखडणे जाणवल्यास त्वरित वैद्यकीय तपासणी करावी, जेणेकरून हृदयाशी संबंधित गंभीर कारणांचा शोध घेता येईल.',
  },
  confusion: {
    English:
      'Sudden confusion, altered mental state, or disorientation is an urgent warning sign indicating potential central nervous system or metabolic involvement.',
    Hindi:
      'अचानक मानसिक भ्रम, भटकाव या बेहोशी जैसी स्थिति एक गंभीर चेतावनी संकेत है जो तंत्रिका तंत्र या चयापचय में गंभीर समस्या का संकेत हो सकता है।',
    Marathi:
      'अचानक गोंधळलेली मानसिक स्थिती किंवा दिशाभूल होणे हे मज्जासंस्थेशी किंवा चयापचयाशी संबंधित गंभीर समस्येचे तातडीचे चेतावणी चिन्ह आहे.',
  },
  stiff_neck_and_fever: {
    English:
      'A stiff neck accompanied by fever is a recognized clinical red flag for serious meningeal or central nervous system infections requiring prompt emergency examination.',
    Hindi:
      'बुखार के साथ गर्दन में तेज अकड़न होना मेनिनजाइटिस या केंद्रीय तंत्रिका तंत्र के गंभीर संक्रमण का एक महत्वपूर्ण चिकित्सकीय लाल संकेत (Red Flag) है, जिसके लिए तत्काल आपातकालीन जांच आवश्यक है।',
    Marathi:
      'तापाबरोबर मान आखडणे हे मेंदूज्वर (Meningitis) किंवा मज्जासंस्थेच्या गंभीर संसर्गाचे ठळक धोक्याचे लक्षण असून तातडीने आपत्कालीन तपासणीची गरज आहे.',
  },
  fainting: {
    English:
      'Sudden loss of consciousness (syncope) or fainting should be evaluated urgently to investigate cardiovascular, neurological, or blood pressure causes.',
    Hindi:
      'अचानक बेहोशी या चक्कर खाकर गिरना हृदय, तंत्रिका तंत्र या रक्तचाप संबंधी कारणों की जांच के लिए तत्काल डॉक्टर को दिखाया जाना चाहिए।',
    Marathi:
      'अचानक शुद्ध हरपणे किंवा भोवळ येऊन पडणे यामागील हृदयविकार, मज्जासंस्था किंवा रक्तदाबाशी संबंधित कारणे शोधण्यासाठी तातडीने वैद्यकीय तपासणी करावी.',
  },
  shortness_of_breath: {
    English:
      'Significant or worsening shortness of breath requires prompt medical attention to evaluate lung and airway function.',
    Hindi:
      'सांस लेने में अत्यधिक या बढ़ती हुई कठिनाई फेफड़ों और श्वसन नलियों की कार्यप्रणाली की जांच के लिए तुरंत चिकित्सा सहायता मांगती है।',
    Marathi:
      'श्वास घेण्यास होणारा तीव्र किंवा वाढणारा त्रास फुफ्फुस आणि श्वासनलिकेची तपासणी करण्यासाठी त्वरित वैद्यकीय मदत आवश्यक करतो.',
  },
  fever_gastro: {
    English:
      'Gastrointestinal fluid loss accompanied by fever carries an elevated risk of dehydration and infection that should be evaluated by a healthcare professional.',
    Hindi:
      'बुखार के साथ उल्टी या दस्त से शरीर में पानी की कमी (डिहाइड्रेशन) और संक्रमण का खतरा बढ़ जाता है, जिसकी जांच डॉक्टर से कराई जानी चाहिए।',
    Marathi:
      'तापाबरोबर उलट्या किंवा जुलाब झाल्यामुळे शरीरातील पाण्याचे प्रमाण कमी होण्याचा (Dehydration) व संसर्गाचा धोका वाढतो, ज्यासाठी डॉक्टरांचा सल्ला घ्यावा.',
  },
  weakness_or_multiple: {
    English:
      'Experiencing multiple concurrent symptoms or noticeable bodily weakness suggests systemic involvement that benefits from a professional medical consultation.',
    Hindi:
      'एक साथ कई लक्षण या अत्यधिक शारीरिक कमजोरी पूरे शरीर में संक्रमण या प्रभाव का संकेत देते हैं, जिसके लिए डॉक्टर से परामर्श लेना उचित है।',
    Marathi:
      'एकाच वेळी अनेक लक्षणे किंवा शरीरात लक्षणीय अशक्तपणा जाणवणे हे संपूर्ण शरीरावर होणारा परिणाम दर्शवते, ज्यासाठी वैद्यकीय सल्ला घेणे फायदेशीर ठरेल.',
  },
  localized_infection: {
    English:
      'These symptoms may indicate an underlying localized infection or inflammatory process. A doctor can perform physical examination and testing to guide proper care.',
    Hindi:
      'ये लक्षण किसी आंतरिक संक्रमण या सूजन का संकेत हो सकते हैं। डॉक्टर शारीरिक परीक्षण और जांच के आधार पर सही उपचार का मार्गदर्शन कर सकते हैं।',
    Marathi:
      'ही लक्षणे शरीरातील संसर्ग किंवा दाहक प्रक्रियेचे संकेत असू शकतात. योग्य उपचारांसाठी डॉक्टरांकडून शारीरिक तपासणी करून घेणे आवश्यक आहे.',
  },
  low_urgency: {
    English:
      'Symptoms appear mild and may be addressed with safe home self-care while monitoring.',
    Hindi:
      'लक्षण हल्के प्रतीत होते हैं और स्थिति पर नजर रखते हुए सुरक्षित घरेलू देखभाल से राहत पाई जा सकती है।',
    Marathi:
      'लक्षणे सौम्य स्वरूपाची वाटतात आणि लक्ष ठेवून सुरक्षित घरगुती उपायांनी आराम मिळू शकतो.',
  },
};

const RED_FLAG_ITEMS: Record<string, LocalizedString> = {
  chest_radiating: {
    English:
      'Chest pain, pressure, or tightness radiating to the arm, shoulder, back, neck, or jaw.',
    Hindi:
      'छाती में दर्द, दबाव या जकड़न जो हाथ, कंधे, पीठ, गर्दन या जबड़े तक फैलती हो।',
    Marathi:
      'छातीत कळ, दाब किंवा आखडणे जे हात, खांदा, पाठ, मान किंवा जबड्यापर्यंत पसरत असेल.',
  },
  breathlessness_rest: {
    English:
      'Sudden or escalating difficulty catching breath or breathlessness at rest.',
    Hindi:
      'अचानक या तेजी से बढ़ती सांस फूलने की समस्या, विशेषकर आराम की स्थिति में।',
    Marathi:
      'अचानक किंवा वेगाने वाढणारा दम, विशेषतः विश्रांती घेत असतानाही धाप लागणे.',
  },
  chest_minutes: {
    English:
      'Sudden unexplained chest pain or pressure lasting more than a few minutes.',
    Hindi:
      'छाती में अचानक बिना किसी स्पष्ट कारण के कुछ मिनटों से अधिक समय तक रहने वाला दर्द या दबाव।',
    Marathi:
      'काही मिनिटांपेक्षा जास्त काळ छातीत अचानक तीव्र दुखणे किंवा दाब जाणवणे.',
  },
  confusion_speech: {
    English:
      'Sudden confusion, difficulty speaking, slurred speech, or profound disorientation.',
    Hindi:
      'अचानक भ्रम होना, बोलने में लड़खड़ाहट, आवाज का अस्पष्ट होना या दिशा-समय का भान न रहना।',
    Marathi:
      'अचानक गोंधळ उडणे, बोलताना अडखळणे, शब्द न फुटणे किंवा तीव्र दिशाभूल होणे.',
  },
  stiff_neck_headache: {
    English:
      'Inability to flex neck forward toward chest accompanied by fever or severe headache.',
    Hindi:
      'तेज बुखार या असहनीय सिरदर्द के साथ ठुड्डी को छाती की ओर मोड़ने में असमर्थता।',
    Marathi:
      'तीव्र ताप किंवा असह्य डोकेदुखीसोबत हनुवटी छातीकडे झुकवता न येणे.',
  },
  collapse_blackout: {
    English:
      'Sudden unexplained collapse, blackout, or prolonged loss of consciousness.',
    Hindi:
      'अचानक गिर पड़ना, आंखों के आगे अंधेरा छाना या लंबे समय तक बेहोश रहना।',
    Marathi:
      'अचानक चक्कर येऊन कोसळणे, डोळ्यांसमोर अंधारी येणे किंवा शुद्ध हरपणे.',
  },
  struggling_breathe: {
    English:
      'Struggling to breathe, lips or fingernails turning pale or bluish, or severe gasping.',
    Hindi:
      'सांस लेने के लिए अत्यधिक संघर्ष, होंठ या नाखूनों का नीला/फीका पड़ना, या हांफना।',
    Marathi:
      'श्वास घेण्यास खूप कष्ट पडणे, ओठ किंवा नखे निळसर किंवा फिकट पडणे, किंवा धाप लागणे.',
  },
  dehydration_signs: {
    English:
      'Inability to keep liquids down for more than 24 hours or signs of dehydration (sunken eyes, extreme thirst, dark urine).',
    Hindi:
      '24 घंटे से अधिक समय तक पानी या तरल पदार्थ न पचना अथवा निर्जलीकरण के लक्षण (धंसी हुई आंखें, अत्यधिक प्यास, गहरा पेशाब)।',
    Marathi:
      '२४ तासांहून अधिक काळ पाणी किंवा द्रवपदार्थ न पचणे किंवा डिहायड्रेशनची लक्षणे (डोळे खोल जाणे, अतिशय तहान, गडद लघवी).',
  },
  worsen_48_72: {
    English:
      'Symptoms that progressively worsen over 48 to 72 hours without signs of relief.',
    Hindi:
      '48 से 72 घंटों में बिना किसी सुधार के लक्षणों का लगातार अधिक गंभीर होते जाना।',
    Marathi:
      '४८ ते ७२ तासांत कोणतीही सुधारणा न होता लक्षणे अधिकाधिक गंभीर होत जाणे.',
  },
  persistent_high_fever: {
    English:
      'Persistent high fever that does not respond to ordinary comfort measures.',
    Hindi:
      'लगातार बना रहने वाला तेज बुखार जो सामान्य आराम और प्राथमिक उपायों से कम न हो।',
    Marathi:
      'सतत टिकून राहणारा उच्च ताप जो साध्या विश्रांतीने किंवा उपायांनी कमी होत नाही.',
  },
  sharp_abdominal_pain: {
    English:
      'Severe, sudden, or localized sharp abdominal pain that prevents movement.',
    Hindi:
      'पेट में अचानक अत्यधिक तेज या किसी एक स्थान पर असहनीय दर्द जिसके कारण हिलना-डुलना भी कठिन हो।',
    Marathi:
      'पोटात अचानक अतिशय तीव्र वेदना किंवा कळा येणे ज्यामुळे हालचाल करणेही कठीण होते.',
  },
  spreading_rash: {
    English:
      'Rapidly spreading skin rash or rash accompanied by blisters, peeling, or facial swelling.',
    Hindi:
      'तेजी से फैलता हुआ त्वचा पर दाना, फफोले, त्वचा का छिलना या चेहरे पर सूजन आना।',
    Marathi:
      'त्वचेवर वेगाने पसरणारे पुरळ, फोड येणे, त्वचा सोलवटणे किंवा चेहऱ्यावर सूज येणे.',
  },
  sudden_severe_worsening: {
    English:
      'Symptoms suddenly becoming severe, incapacitating, or worsening rapidly.',
    Hindi:
      'लक्षणों का अचानक अत्यधिक गंभीर, दुर्बल करने वाला या तेजी से बिगड़ जाना।',
    Marathi:
      'लक्षणे अचानक अतिशय तीव्र होणे, दैनंदिन कामे करणे अशक्य होणे किंवा बिघडणे.',
  },
  fever_vomiting_dizziness: {
    English:
      'Development of high fever, persistent vomiting, or extreme dizziness.',
    Hindi:
      'तेज बुखार चढ़ना, लगातार उल्टी होना, या अत्यधिक चक्कर आना।',
    Marathi:
      'तीव्र ताप भरणे, सतत उलट्या होणे किंवा प्रचंड भोवळ येणे.',
  },
};

/**
 * Evaluates the urgency level and reasons based on clinical warning guidelines
 * from WHO, CDC, and NHS triage protocols with multi-language output.
 */
function evaluateUrgency(
  selectedIds: string[],
  language: PreferredLanguage
): { level: UrgencyLevel; reason: string; redFlags: string[] } {
  const redFlagKeys: string[] = [];
  let level: UrgencyLevel = 'Low urgency';
  let reasonKey = 'low_urgency';

  const hasChestPain = selectedIds.includes('chest_pain');
  const hasShortnessOfBreath = selectedIds.includes('shortness_of_breath');
  const hasConfusion = selectedIds.includes('confusion');
  const hasStiffNeck = selectedIds.includes('stiff_neck');
  const hasFever = selectedIds.includes('fever');
  const hasFainting = selectedIds.includes('fainting');
  const hasWeakness = selectedIds.includes('weakness');
  const hasVomiting = selectedIds.includes('vomiting');
  const hasDiarrhea = selectedIds.includes('diarrhea');

  // CRITICAL EMERGENCY CRITERIA (Urgent Medical Attention)
  if (hasChestPain && hasShortnessOfBreath) {
    level = 'Urgent medical attention';
    reasonKey = 'chest_and_shortness';
    redFlagKeys.push('chest_radiating');
    redFlagKeys.push('breathlessness_rest');
  } else if (hasChestPain) {
    level = 'Urgent medical attention';
    reasonKey = 'chest_pain';
    redFlagKeys.push('chest_minutes');
  } else if (hasConfusion) {
    level = 'Urgent medical attention';
    reasonKey = 'confusion';
    redFlagKeys.push('confusion_speech');
  } else if (hasStiffNeck && hasFever) {
    level = 'Urgent medical attention';
    reasonKey = 'stiff_neck_and_fever';
    redFlagKeys.push('stiff_neck_headache');
  } else if (hasFainting) {
    level = 'Urgent medical attention';
    reasonKey = 'fainting';
    redFlagKeys.push('collapse_blackout');
  } else if (hasShortnessOfBreath) {
    level = 'Urgent medical attention';
    reasonKey = 'shortness_of_breath';
    redFlagKeys.push('struggling_breathe');
  }

  // MODERATE CONSULTATION CRITERIA (Medical consultation recommended)
  if (level !== 'Urgent medical attention') {
    if (hasFever && (hasVomiting || hasDiarrhea)) {
      level = 'Medical consultation recommended';
      reasonKey = 'fever_gastro';
      redFlagKeys.push('dehydration_signs');
    } else if (hasWeakness || selectedIds.length >= 3) {
      level = 'Medical consultation recommended';
      reasonKey = 'weakness_or_multiple';
      redFlagKeys.push('worsen_48_72');
      redFlagKeys.push('persistent_high_fever');
    } else if (
      hasFever ||
      selectedIds.includes('abdominal_pain') ||
      selectedIds.includes('skin_rash') ||
      selectedIds.includes('burning_urination')
    ) {
      level = 'Medical consultation recommended';
      reasonKey = 'localized_infection';
      redFlagKeys.push('sharp_abdominal_pain');
      redFlagKeys.push('spreading_rash');
    }
  }

  // Add general relevant red flags if empty
  if (redFlagKeys.length === 0) {
    redFlagKeys.push('sudden_severe_worsening');
    redFlagKeys.push('fever_vomiting_dizziness');
  }

  const reason =
    URGENCY_REASONS[reasonKey]?.[language] ||
    URGENCY_REASONS[reasonKey]?.English ||
    URGENCY_REASONS.low_urgency.English;

  const redFlags = redFlagKeys.map(
    (key) => RED_FLAG_ITEMS[key]?.[language] || RED_FLAG_ITEMS[key]?.English || key
  );

  return { level, reason, redFlags };
}

/**
 * Compiles matching conditions based on selected symptoms and authoritative guidelines.
 */
function findPossibleConditions(
  selectedIds: string[],
  language: PreferredLanguage
): PossibleCondition[] {
  const matches: PossibleCondition[] = [];

  for (const cond of AUTHORITATIVE_CONDITIONS) {
    const primaryMatches = cond.primarySymptoms.filter((s) => selectedIds.includes(s));
    const secondaryMatches = cond.secondarySymptoms.filter((s) => selectedIds.includes(s));
    const totalMatchCount = primaryMatches.length * 2 + secondaryMatches.length;

    if (primaryMatches.length > 0 || (secondaryMatches.length >= 2 && selectedIds.length >= 2)) {
      const allMatchedNames = [...primaryMatches, ...secondaryMatches].map((id) => {
        const item = COMMON_SYMPTOMS.find((s) => s.id === id);
        if (!item) return id;
        return item.nameTranslations?.[language] || item.name;
      });

      const localizedName = cond.nameTranslations?.[language] || cond.name;
      const localizedDescription = cond.descriptionTranslations?.[language] || cond.description;

      matches.push({
        id: cond.id,
        name: localizedName,
        description: localizedDescription,
        matchingSymptoms: allMatchedNames,
        totalMatchCount,
        sources: cond.sources,
        nameTranslations: cond.nameTranslations,
        descriptionTranslations: cond.descriptionTranslations,
      });
    }
  }

  // Sort by match relevance
  matches.sort((a, b) => b.totalMatchCount - a.totalMatchCount);

  return matches.slice(0, 4); // Top 4 most relevant conditions
}

/**
 * Compiles safe, educational self-care guidelines without prescribing medications.
 */
function compileSelfCare(selectedIds: string[], language: PreferredLanguage): string[] {
  const langSelfCare = GENERAL_SELF_CARE_MEASURES_I18N;
  const defaultList =
    langSelfCare.default?.[language] || langSelfCare.default?.English || [];
  const selfCareList: string[] = [...defaultList];

  const hasRespiratory = selectedIds.some((id) =>
    ['cough', 'cold', 'sore_throat', 'wheezing'].includes(id)
  );
  if (hasRespiratory) {
    const respList =
      langSelfCare.respiratory?.[language] || langSelfCare.respiratory?.English || [];
    selfCareList.push(...respList);
  }

  const hasDigestive = selectedIds.some((id) =>
    ['nausea', 'vomiting', 'diarrhea', 'abdominal_pain'].includes(id)
  );
  if (hasDigestive) {
    const digList =
      langSelfCare.digestive?.[language] || langSelfCare.digestive?.English || [];
    selfCareList.push(...digList);
  }

  const hasMusculoskeletal = selectedIds.some((id) =>
    ['back_pain', 'joint_pain', 'muscle_aches'].includes(id)
  );
  if (hasMusculoskeletal) {
    const muscList =
      langSelfCare.musculoskeletal?.[language] || langSelfCare.musculoskeletal?.English || [];
    selfCareList.push(...muscList);
  }

  // Deduplicate and limit to 6 clear bullet points
  return Array.from(new Set(selfCareList)).slice(0, 6);
}

/**
 * Compiles doctor visit criteria tailored to symptoms and language.
 */
function compileDoctorAdvice(
  selectedIds: string[],
  urgency: UrgencyLevel,
  language: PreferredLanguage
): string[] {
  const points: string[] = [];

  if (urgency === 'Urgent medical attention') {
    if (language === 'Hindi') {
      points.push(
        'तत्काल निकटतम आपातकालीन चिकित्सा केंद्र (ER) जाएं या आपातकालीन एम्बुलेंस (108) को कॉल करें।'
      );
      points.push(
        'यदि आपको चक्कर आ रहे हों, सांस लेने में तकलीफ हो या कमजोरी महसूस हो रही हो, तो स्वयं वाहन न चलाएं।'
      );
      points.push(
        'अस्पताल पहुंचते ही आपातकालीन कर्मचारियों को अपने सभी लक्षणों और उनके शुरू होने के समय की पूरी जानकारी दें।'
      );
    } else if (language === 'Marathi') {
      points.push(
        'त्वरित जवळच्या आपत्कालीन कक्षात (ER) जा किंवा आपत्कालीन रुग्णवाहिका (१०८) सेवा बोलवा.'
      );
      points.push(
        'जर तुम्हाला चक्कर, अशक्तपणा किंवा श्वास घेण्यास त्रास होत असेल तर स्वतः गाडी चालवू नका.'
      );
      points.push(
        'रुग्णालयात पोहोचताच डॉक्टरांना सर्व लक्षणे आणि ती कधीपासून सुरू झाली याची अचूक माहिती द्या.'
      );
    } else {
      points.push(
        'Immediately visit the nearest emergency room (ER) or call your local emergency medical response number.'
      );
      points.push(
        'Do not attempt to drive yourself if you are feeling dizzy, weak, short of breath, or disoriented.'
      );
      points.push(
        'Inform emergency staff of all symptoms and when they began as soon as you arrive.'
      );
    }
  } else if (urgency === 'Medical consultation recommended') {
    if (language === 'Hindi') {
      points.push(
        '24 से 48 घंटों के भीतर किसी प्रमाणित डॉक्टर या क्लिनिक से परामर्श अवश्य लें।'
      );
      points.push(
        'यदि लक्षण अचानक गंभीर हो जाएं या कोई नया चेतावनी संकेत दिखे, तो तुरंत आपातकालीन चिकित्सा प्राप्त करें।'
      );
      points.push(
        'डॉक्टर से चर्चा के लिए अपने लक्षणों के शुरू होने का समय और उनकी तीव्रता नोट करके रखें।'
      );
    } else if (language === 'Marathi') {
      points.push(
        '२४ ते ४८ तासांच्या आत एखाद्या मान्यताप्राप्त डॉक्टर किंवा तज्ज्ञांचा सल्ला घ्या.'
      );
      points.push(
        'लक्षणे अचानक वाढल्यास किंवा नवीन धोक्याचे लक्षण दिसल्यास त्वरित आपत्कालीन मदत घ्या.'
      );
      points.push(
        'लक्षणे कधी सुरू झाली आणि त्यांचा त्रास कसा होतो याची नोंद डॉक्टरांना दाखवण्यासाठी ठेवा.'
      );
    } else {
      points.push(
        'Schedule an in-person or telemedicine appointment with a licensed healthcare provider within 24–48 hours.'
      );
      points.push(
        'Seek immediate emergency care if your symptoms suddenly worsen or if new red flags appear.'
      );
      points.push(
        'Write down when your symptoms started, their frequency, and any patterns to discuss with your doctor.'
      );
    }
  } else {
    if (language === 'Hindi') {
      points.push(
        'यदि आपके लक्षण 7 से 10 दिनों से अधिक समय तक बने रहते हैं, तो डॉक्टर से जांच कराएं।'
      );
      points.push(
        'यदि सामान्य आराम के बावजूद स्थिति में सुधार न हो या लक्षण बढ़ने लगें, तो चिकित्सक से संपर्क करें।'
      );
      points.push(
        'यदि आपको पहले से मधुमेह (शुगर), हृदय रोग, अस्थमा या कमजोर प्रतिरोधक क्षमता जैसी पुरानी बीमारी है, तो शीघ्र डॉक्टर से मिलें।'
      );
    } else if (language === 'Marathi') {
      points.push(
        'जर तुमची लक्षणे ७ ते १० दिवसांपेक्षा जास्त काळ टिकून राहिली, तर डॉक्टरांकडून तपासणी करून घ्या.'
      );
      points.push(
        'विश्रांती घेऊनही आराम पडत नसेल किंवा त्रास वाढू लागला, तर त्वरित डॉक्टरांचा सल्ला घ्या.'
      );
      points.push(
        'जर तुम्हाला मधुमेह, हृदयरोग, दमा किंवा इतर जुनाट आजार असतील, तर तातडीने डॉक्टरांशी चर्चा करा.'
      );
    } else {
      points.push(
        'Seek professional medical evaluation if your symptoms persist beyond 7 to 10 days.'
      );
      points.push(
        'Consult a doctor if your symptoms begin to noticeably worsen or do not improve with basic rest.'
      );
      points.push(
        'Consult a physician promptly if you have underlying chronic conditions such as diabetes, cardiovascular disease, asthma, or an immunocompromised state.'
      );
    }
  }

  if (language === 'Hindi') {
    points.push(
      'अपनी अंतःप्रेरणा पर भरोसा रखें: यदि आप बहुत अस्वस्थ महसूस कर रहे हैं या स्थिति को लेकर चिंतित हैं, तो तुरंत डॉक्टर से मिलें।'
    );
  } else if (language === 'Marathi') {
    points.push(
      'स्वतःच्या शरीराच्या संकेतांवर विश्वास ठेवा: जर तुम्हाला खूप अस्वस्थ वाटत असेल तर ताबडतोब वैद्यकीय तपासणी करून घ्या.'
    );
  } else {
    points.push(
      'Always trust your instincts: if you feel very unwell or uncertain about your condition, seek qualified medical evaluation.'
    );
  }

  return points;
}

/**
 * Gathers authoritative source references from matched conditions and global agencies.
 */
function compileSources(conditions: PossibleCondition[]): AuthoritativeSource[] {
  const sourceMap = new Map<string, AuthoritativeSource>();

  // Always include primary medical bodies (intact and authentic)
  const defaultSources: AuthoritativeSource[] = [
    {
      organization: 'WHO',
      title: 'World Health Organization Clinical Guidelines & Fact Sheets',
      guidelineTopic: 'Global Health Standards and Disease Fact Sheets',
    },
    {
      organization: 'CDC',
      title: 'Centers for Disease Control and Prevention',
      guidelineTopic: 'Diseases and Conditions Clinical Guidance',
    },
    {
      organization: 'NIH / NIDDK',
      title: 'National Institutes of Health & MedlinePlus',
      guidelineTopic: 'Medical Encyclopedia and Consumer Health Information',
    },
    {
      organization: 'NHS UK',
      title: 'National Health Service (NHS UK)',
      guidelineTopic: 'NHS Health A-Z: Conditions and Symptoms',
    },
  ];

  for (const s of defaultSources) {
    sourceMap.set(s.organization, s);
  }

  for (const cond of conditions) {
    for (const src of cond.sources) {
      sourceMap.set(`${src.organization}-${src.title}`, src);
    }
  }

  return Array.from(sourceMap.values()).slice(0, 5);
}

/**
 * Main Analysis Engine: Evaluates selected symptoms against verified medical guidelines.
 */
export function analyzeSymptoms(
  selectedSymptoms: SymptomItem[],
  language: PreferredLanguage = 'English'
): SymptomAnalysisResult {
  if (!selectedSymptoms || selectedSymptoms.length === 0) {
    throw new Error('No symptoms provided for analysis.');
  }

  const selectedIds = selectedSymptoms.map((s) => s.id);
  const { level, reason, redFlags } = evaluateUrgency(selectedIds, language);
  const possibleConditions = findPossibleConditions(selectedIds, language);
  const generalSelfCare = compileSelfCare(selectedIds, language);
  const whenToSeeDoctor = compileDoctorAdvice(selectedIds, level, language);
  const sources = compileSources(possibleConditions);
  const disclaimer =
    MANDATORY_DISCLAIMER_I18N[language] || MANDATORY_DISCLAIMER_I18N.English;

  return {
    selectedSymptoms,
    urgencyLevel: level,
    urgencyReason: reason,
    possibleConditions,
    redFlags,
    generalSelfCare,
    whenToSeeDoctor,
    sources,
    disclaimer,
    language,
  };
}
