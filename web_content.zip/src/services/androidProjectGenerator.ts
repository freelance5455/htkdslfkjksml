import JSZip from 'jszip';

export interface AndroidFile {
  path: string;
  language: 'kotlin' | 'groovy' | 'xml' | 'markdown' | 'properties';
  content: string;
}

export const ANDROID_FILES: AndroidFile[] = [
  {
    path: 'app/src/main/java/com/cutpro/videoeditor/MainActivity.kt',
    language: 'kotlin',
    content: `package com.cutpro.videoeditor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.cutpro.videoeditor.ui.home.HomeScreen
import com.cutpro.videoeditor.ui.editor.EditorScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val cutProColorScheme = darkColorScheme(
                primary = Color(0xFF00E5FF),      // Cyan / Turquoise Accent
                secondary = Color(0xFFFF4A5A),    // Coral-Red Action
                background = Color(0xFF0B0E14),   // Black background
                surface = Color(0xFF161B22),      // Dark gray panels
                onPrimary = Color.Black,
                onSecondary = Color.White,
                onBackground = Color.White,
                onSurface = Color(0xFFF0F3F6)
            )

            MaterialTheme(colorScheme = cutProColorScheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var currentScreen by remember { mutableStateOf("home") }
                    var selectedProjectId by remember { mutableStateOf<String?>(null) }

                    if (currentScreen == "home") {
                        HomeScreen(
                            onNewProject = {
                                selectedProjectId = "proj_" + System.currentTimeMillis()
                                currentScreen = "editor"
                            },
                            onOpenProject = { id ->
                                selectedProjectId = id
                                currentScreen = "editor"
                            }
                        )
                    } else {
                        EditorScreen(
                            projectId = selectedProjectId ?: "proj_default",
                            onNavigateBack = { currentScreen = "home" }
                        )
                    }
                }
            }
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/cutpro/videoeditor/domain/model/CutProModels.kt',
    language: 'kotlin',
    content: `package com.cutpro.videoeditor.domain.model

import android.net.Uri

data class ProjectModel(
    val id: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val clips: List<TimelineClipModel> = emptyList(),
    val outputResolution: String = "1080p",
    val aspectRatio: String = "16:9"
)

data class TimelineClipModel(
    val id: String,
    val uri: Uri,
    val name: String,
    val sourceDurationMs: Long,
    val sourceInMs: Long = 0L,
    val sourceOutMs: Long = sourceDurationMs,
    val timelineStartMs: Long = 0L,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f
) {
    val durationMs: Long
        get() = ((sourceOutMs - sourceInMs) / speed).toLong()
}
`,
  },
  {
    path: 'app/src/main/java/com/cutpro/videoeditor/media/render/Media3TransformerEngine.kt',
    language: 'kotlin',
    content: `package com.cutpro.videoeditor.media.render

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.*
import com.cutpro.videoeditor.domain.model.TimelineClipModel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.io.File

class Media3TransformerEngine(private val context: Context) {

    sealed class ExportState {
        data class Progress(val percentage: Int) : ExportState()
        data class Success(val outputFile: File) : ExportState()
        data class Error(val exception: Throwable) : ExportState()
    }

    /**
     * Concatenates and trims video clips into a single MP4 file using AndroidX Media3 Transformer.
     */
    fun exportTimeline(
        clips: List<TimelineClipModel>,
        outputFile: File
    ): Flow<ExportState> = callbackFlow {
        if (clips.isEmpty()) {
            trySend(ExportState.Error(IllegalArgumentException("Timeline has no clips to merge.")))
            close()
            return@callbackFlow
        }

        val editedMediaItems = clips.map { clip ->
            val clippingConfiguration = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(clip.sourceInMs)
                .setEndPositionMs(clip.sourceOutMs)
                .build()

            val mediaItem = MediaItem.Builder()
                .setUri(clip.uri)
                .setClippingConfiguration(clippingConfiguration)
                .build()

            EditedMediaItem.Builder(mediaItem)
                .setRemoveAudio(clip.volume == 0f)
                .build()
        }

        val composition = Composition.Builder(
            EditedMediaItemSequence(editedMediaItems)
        ).build()

        val transformerListener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                trySend(ExportState.Progress(100))
                trySend(ExportState.Success(outputFile))
                close()
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                trySend(ExportState.Error(exportException))
                close()
            }
        }

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(transformerListener)
            .build()

        transformer.start(composition, outputFile.absolutePath)

        // Progress polling loop
        val progressHolder = ProgressHolder()
        val timer = java.util.Timer()
        timer.scheduleAtFixedRate(object : java.util.TimerTask() {
            override fun run() {
                val state = transformer.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    trySend(ExportState.Progress(progressHolder.progress))
                }
            }
        }, 200, 200)

        awaitClose {
            timer.cancel()
            transformer.cancel()
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/cutpro/videoeditor/media/playback/CutProPlayer.kt',
    language: 'kotlin',
    content: `package com.cutpro.videoeditor.media.playback

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.cutpro.videoeditor.domain.model.TimelineClipModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class CutProPlayer(private val context: Context) {
    private var exoPlayer: ExoPlayer? = null
    private val _playbackPositionMs = MutableStateFlow(0L)
    val playbackPositionMs = _playbackPositionMs.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    fun initialize() {
        if (exoPlayer == null) {
            exoPlayer = ExoPlayer.Builder(context).build().apply {
                addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(playing: Boolean) {
                        _isPlaying.value = playing
                    }
                })
            }
        }
    }

    fun loadClips(clips: List<TimelineClipModel>, initialPositionMs: Long = 0L) {
        val player = exoPlayer ?: return
        player.clearMediaItems()
        clips.forEach { clip ->
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(clip.sourceInMs)
                .setEndPositionMs(clip.sourceOutMs)
                .build()
            val mediaItem = MediaItem.Builder()
                .setUri(clip.uri)
                .setClippingConfiguration(clipping)
                .build()
            player.addMediaItem(mediaItem)
        }
        player.prepare()
        player.seekTo(initialPositionMs)
    }

    fun play() = exoPlayer?.play()
    fun pause() = exoPlayer?.pause()
    fun seekTo(positionMs: Long) = exoPlayer?.seekTo(positionMs)
    fun release() {
        exoPlayer?.release()
        exoPlayer = null
    }

    fun getPlayer(): ExoPlayer? = exoPlayer
}
`,
  },
  {
    path: 'app/src/main/java/com/cutpro/videoeditor/data/ProjectDatabase.kt',
    language: 'kotlin',
    content: `package com.cutpro.videoeditor.data

import androidx.room.*

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val clipsJson: String
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    suspend fun getAllProjects(): List<ProjectEntity>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProjectById(id: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)
}

@Database(entities = [ProjectEntity::class], version = 1, exportSchema = false)
abstract class ProjectDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
}
`,
  },
  {
    path: 'app/build.gradle.kts',
    language: 'groovy',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.cutpro.videoeditor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.cutpro.videoeditor"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
}

dependencies {
    // AndroidX Media3 ExoPlayer & Transformer
    val media3Version = "1.5.0"
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")
    implementation("androidx.media3:media3-transformer:$media3Version")
    implementation("androidx.media3:media3-effect:$media3Version")
    implementation("androidx.media3:media3-common:$media3Version")

    // Jetpack Compose
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.activity:activity-compose:1.9.3")

    // Room Database
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // Coroutines & Lifecycle
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
}
`,
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="CutPro"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.Material.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`,
  },
  {
    path: 'README.md',
    language: 'markdown',
    content: `# CutPro — Pro Video Editor & Slideshow Maker (Android Phase 1)

CutPro is a professional mobile video editing application built with Jetpack Compose, AndroidX Media3 ExoPlayer, and Media3 Transformer.

## Architecture Highlights
- **Jetpack Compose**: Modern reactive dark-themed UI system.
- **AndroidX Media3 ExoPlayer**: Smooth real-time timeline preview and multi-clip switching.
- **AndroidX Media3 Transformer**: Frame-accurate multi-clip concatenation, nondestructive start/end clipping, and hardware-accelerated MP4 export.
- **Room Database**: Nondestructive project state persistence.

## How to Build the APK
1. Open this folder in **Android Studio Hedgehog / Ladybug or newer**.
2. Wait for Gradle Sync to finish.
3. In terminal, run:
   \`\`\`bash
   ./gradlew assembleDebug
   \`\`\`
4. Locate the generated APK at:
   \`app/build/outputs/apk/debug/app-debug.apk\`
5. Install on connected Android device via ADB:
   \`\`\`bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   \`\`\`
`,
  },
];

export async function generateAndroidProjectZip(): Promise<Blob> {
  const zip = new JSZip();

  for (const file of ANDROID_FILES) {
    zip.file(file.path, file.content);
  }

  return await zip.generateAsync({ type: 'blob' });
}
