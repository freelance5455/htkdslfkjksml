import { CURRICULUM_UNITS } from '../data/curriculum/units';
import { KEYS, readKey, withStorageLock, writeKey } from './storage';
import type { CurriculumUnitInfo } from '../types';

export type CurriculumCompletionState = Record<string, boolean>;

export interface CurriculumChecklistItem {
  id: string;
  title: string;
  kind: 'lesson' | 'chapter';
  lessonIndex: number | null;
  questionCount: number;
}

export interface CurriculumProgressSummary {
  completed: number;
  total: number;
  percent: number;
}

/** معرّف ثابت يتبع ترتيب الدروس الرسمي المسجل في الوحدة. */
export function curriculumLessonId(unitId: string, index: number): string {
  return `${unitId}-lesson-${index + 1}`;
}

export function getCurriculumChecklistItems(unit: CurriculumUnitInfo): CurriculumChecklistItem[] {
  if (unit.lessonTitles.length === 0) {
    return [{
      id: `${unit.id}-chapter`,
      title: 'إتمام مراجعة هذا الفصل',
      kind: 'chapter',
      lessonIndex: null,
      questionCount: 0,
    }];
  }

  return unit.lessonTitles.map((title, index) => ({
    id: curriculumLessonId(unit.id, index),
    title,
    kind: 'lesson',
    lessonIndex: index,
    questionCount: unit.lessonQuestionCounts?.[index] ?? 0,
  }));
}

export function getCurriculumItemTitle(unit: CurriculumUnitInfo, itemId: string): string | undefined {
  return getCurriculumChecklistItems(unit).find((item) => item.id === itemId)?.title;
}

export function summarizeCurriculumItems(
  items: CurriculumChecklistItem[],
  state: CurriculumCompletionState,
): CurriculumProgressSummary {
  const completed = items.reduce((count, item) => count + (state[item.id] ? 1 : 0), 0);
  const total = items.length;
  return { completed, total, percent: total === 0 ? 0 : Math.round((completed / total) * 100) };
}

export function curriculumUnitProgress(
  unit: CurriculumUnitInfo,
  state: CurriculumCompletionState,
): CurriculumProgressSummary {
  return summarizeCurriculumItems(getCurriculumChecklistItems(unit), state);
}

export function curriculumSubjectProgress(
  subjectId: string,
  state: CurriculumCompletionState,
): CurriculumProgressSummary {
  return summarizeCurriculumItems(
    CURRICULUM_UNITS.filter((unit) => unit.subjectId === subjectId).flatMap(getCurriculumChecklistItems),
    state,
  );
}

export function overallCurriculumProgress(state: CurriculumCompletionState): CurriculumProgressSummary {
  return summarizeCurriculumItems(CURRICULUM_UNITS.flatMap(getCurriculumChecklistItems), state);
}

export async function setCurriculumItemCompleted(itemId: string, completed: boolean): Promise<void> {
  await withStorageLock('curriculum-progress', [KEYS.curriculumProgress], () => {
    const current = readKey<CurriculumCompletionState>(KEYS.curriculumProgress, {});
    writeKey(KEYS.curriculumProgress, { ...current, [itemId]: completed });
  });
}
