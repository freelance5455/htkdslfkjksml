import { Payment, Customer, Bill, BusinessProfile, Language } from '../types';

export type DuesTemplateType = 'STANDARD' | 'URGENT' | 'FRIENDLY';

export class ReceiptService {
  /**
   * Format Indian Rupee currency with standard Indian thousands separator
   */
  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount || 0);
  }

  /**
   * Format Date to standard DD-MMM-YYYY (e.g., 01-Nov-2026)
   */
  formatDate(dateStr: string): string {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  }

  /**
   * Clean and normalize phone number for WhatsApp wa.me links
   */
  formatWhatsAppPhone(phone: string): string {
    const clean = (phone || '').replace(/\D/g, '');
    if (clean.length === 10) return `91${clean}`;
    if (clean.startsWith('91') && clean.length === 12) return clean;
    return clean || '919437128945';
  }

  /**
   * Generate standard UPI QR Code link (using qrserver API or SVG inline generator)
   */
  getUpiQrCodeUrl(upiId: string, payeeName: string, amount: number, billOrReceiptNo: string): string {
    const cleanPayee = encodeURIComponent(payeeName || 'CCTV NETWORK CHAMPESWAR');
    const note = encodeURIComponent(`Bill ${billOrReceiptNo}`);
    const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${cleanPayee}&am=${amount}&cu=INR&tn=${note}`;
    return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiUri)}&margin=4`;
  }

  /**
   * Builds localized WhatsApp Payment Receipt Text
   */
  buildPaymentReceiptMessage(
    payment: Payment,
    customer: Customer,
    profile: BusinessProfile,
    lang: Language = 'en'
  ): string {
    const formattedAmount = this.formatCurrency(payment.amount);
    const remainingDues = this.formatCurrency(customer.totalOutstanding);
    const dateFormatted = this.formatDate(payment.paymentDate);

    if (lang === 'or') {
      return `*ସିସିଟିଭି ନେଟୱର୍କ ଚମ୍ପେଶ୍ୱର - ଟଙ୍କା ପୈଠ ରସିଦ୍* 🧾
---------------------------------------
ପ୍ରିୟ *${customer.name}*,
ଆପଣଙ୍କର ବିଲ୍ ବାବଦ ଟଙ୍କା ସଫଳତାର ସହ ଗ୍ରହଣ କରାଗଲା। ଧନ୍ୟବାଦ!

*ରସିଦ୍ ନମ୍ବର:* ${payment.receiptNo}
*ତାରିଖ:* ${dateFormatted}
*ଗ୍ରାହକ ଆଇଡି:* ${customer.customerCode}
*ସେବା:* ${customer.serviceType} (${customer.planName})
*ସାହି / ଅଞ୍ଚଳ:* ${customer.area}

*ଆଦାୟ ହୋଇଥିବା ଟଙ୍କା:* *${formattedAmount}*
*ପୈଠ ମାଧ୍ୟମ:* ${payment.paymentMethod}${payment.upiRefNo ? ` (UTR: ${payment.upiRefNo})` : ''}
*ଅବଶିଷ୍ଟ ବକେୟା (Dues):* *${remainingDues}*
---------------------------------------
କୌଣସି ଅଭିଯୋଗ ବା ସହାୟତା ପାଇଁ ଯୋଗାଯୋଗ କରନ୍ତୁ:
📞 *ହେଲ୍ପଲାଇନ୍:* ${profile.phone}
📍 *ଅଫିସ୍:* ${profile.address}, ${profile.village}, କଟକ

_CCTV NETWORK CHAMPESWAR - Digital Cable & High-Speed Broadband_`;
    }

    if (lang === 'hi') {
      return `*सीसीटीवी नेटवर्क चंपेश्वर - भुगतान रसीद* 🧾
---------------------------------------
प्रिय *${customer.name}*,
आपकी बिल राशि सफलतापूर्वक प्राप्त हो गई है। धन्यवाद!

*रसीद संख्या:* ${payment.receiptNo}
*दिनांक:* ${dateFormatted}
*ग्राहक आईडी:* ${customer.customerCode}
*सेवा प्रकार:* ${customer.serviceType} (${customer.planName})
*क्षेत्र / पता:* ${customer.area}

*प्राप्त राशि:* *${formattedAmount}*
*भुगतान माध्यम:* ${payment.paymentMethod}${payment.upiRefNo ? ` (UTR: ${payment.upiRefNo})` : ''}
*शेष बकाया (Dues):* *${remainingDues}*
---------------------------------------
किसी भी पूछताछ या शिकायत के लिए संपर्क करें:
📞 *हेल्पलाइन:* ${profile.phone}
📍 *कार्यालय:* ${profile.address}, ${profile.village}

_CCTV NETWORK CHAMPESWAR - Cable TV & High-Speed Internet_`;
    }

    // Default English
    return `*PAYMENT RECEIPT - ${profile.name}* 🧾
---------------------------------------
Dear *${customer.name}*,
Thank you for your payment! Your transaction details:

*Receipt No:* ${payment.receiptNo}
*Date:* ${dateFormatted}
*Billing Cycle:* ${payment.billingMonth}
*Customer ID:* ${customer.customerCode}
*Service:* ${customer.serviceType} (${customer.planName})
*Area:* ${customer.area}

*Amount Paid:* *${formattedAmount}*
*Payment Mode:* ${payment.paymentMethod}${payment.upiRefNo ? ` (Ref: ${payment.upiRefNo})` : ''}
*Remaining Balance Dues:* *${remainingDues}*
---------------------------------------
Thank you for choosing CCTV Network Champeswar!
📞 *Customer Care:* ${profile.phone}
📍 *Office:* ${profile.address}, ${profile.village}, Odisha`;
  }

  /**
   * Generate WhatsApp link to send instant Payment Receipt to customer
   */
  getWhatsAppReceiptUrl(
    payment: Payment,
    customer: Customer,
    profile: BusinessProfile,
    lang: Language = 'en',
    customMobile?: string
  ): string {
    const targetPhone = this.formatWhatsAppPhone(customMobile || customer.mobile);
    const message = this.buildPaymentReceiptMessage(payment, customer, profile, lang);
    return `https://wa.me/${targetPhone}?text=${encodeURIComponent(message)}`;
  }

  /**
   * Builds localized WhatsApp Outstanding Dues / Bill Notice Text
   */
  buildOutstandingDuesMessage(
    customer: Customer,
    profile: BusinessProfile,
    options: {
      bill?: Bill;
      templateType?: DuesTemplateType;
      lang?: Language;
      activeMonth?: string;
    } = {}
  ): string {
    const lang = options.lang || 'en';
    const template = options.templateType || 'STANDARD';
    const activeMonth = options.activeMonth || options.bill?.billingMonth || new Date().toISOString().slice(0, 7);
    const totalDue = options.bill ? options.bill.balanceDue : customer.totalOutstanding;
    const formattedDue = this.formatCurrency(totalDue);
    const formattedPlan = this.formatCurrency(customer.monthlyAmount);
    const formattedPrev = this.formatCurrency(customer.previousDues);
    const dueDate = options.bill ? this.formatDate(options.bill.dueDate) : '15th of this month';

    // Direct UPI link for 1-tap mobile payment in PhonePe / GPay
    const upiLink = `upi://pay?pa=${profile.upiId}&pn=${encodeURIComponent(profile.name)}&am=${totalDue}&cu=INR&tn=Bill-${customer.customerCode}`;

    if (lang === 'or') {
      if (template === 'URGENT') {
        return `*ଅତ୍ୟନ୍ତ ଜରୁରୀ - ବକେୟା ବିଲ୍ ପୈଠ ସୂଚନା* ⚠️
*ସିସିଟିଭି ନେଟୱର୍କ ଚମ୍ପେଶ୍ୱର*
---------------------------------------
ପ୍ରିୟ *${customer.name}* (ID: ${customer.customerCode}),
ଆପଣଙ୍କର କେବୁଲ୍ / ଇଣ୍ଟରନେଟ୍ ସଂଯୋଗର ବକେୟା ଟଙ୍କା ଏପର୍ଯ୍ୟନ୍ତ ପରିଶୋଧ ହୋଇନାହିଁ।

*ମୋଟ ବକେୟା ଟଙ୍କା (Total Due):* *${formattedDue}*
*ସେବା:* ${customer.serviceType} (${customer.planName})
*ସାହି / ଗ୍ରାମ:* ${customer.area}

ସେବା ବିଚ୍ଛିନ୍ନ (Disconnection) ଏଡ଼ାଇବା ପାଇଁ ଦୟାକରି ତୁରନ୍ତ ଟଙ୍କା ପରିଶୋଧ କରନ୍ତୁ।

*ଘରେ ବସି UPI ମାଧ୍ୟମରେ ପେମେଣ୍ଟ କରନ୍ତୁ:*
📲 *UPI ID:* \`${profile.upiId}\`
(Google Pay, PhonePe, Paytm କିମ୍ବା BHIM ରେ ପଠାନ୍ତୁ)

କିମ୍ବା ଆମ କଲେକ୍ସନ ଏଜେଣ୍ଟଙ୍କୁ ନଗଦ (Cash) ଦିଅନ୍ତୁ।
📞 *ସହାୟତା ନମ୍ବର:* ${profile.phone}`;
      }

      // Standard / Friendly Odia
      return `*ମାସିକ ବିଲ୍ ସୂଚନା - ସିସିଟିଭି ନେଟୱର୍କ ଚମ୍ପେଶ୍ୱର* 📡
---------------------------------------
ନମସ୍କାର *${customer.name}* ମହାଶୟ,
ଆପଣଙ୍କର *${activeMonth}* ମାସର କେବୁଲ୍ ଟିଭି / ଇଣ୍ଟରନେଟ୍ ବିଲ୍ ପ୍ରସ୍ତୁତ ହୋଇଛି।

*ଗ୍ରାହକ ଆଇଡି:* ${customer.customerCode}
*ସେବା ପ୍ଲାନ୍:* ${customer.planName}
*ମାସିକ ଶୁଳ୍କ:* ${formattedPlan}
${customer.previousDues > 0 ? `*ପୂର୍ବ ବକେୟା:* ${formattedPrev}\n` : ''}*ମୋଟ ଦେୟ ଟଙ୍କା:* *${formattedDue}*
*ଶେଷ ତାରିଖ (Due Date):* ${dueDate}
---------------------------------------
*ଦେୟ ପୈଠ ପଦ୍ଧତି:*
📲 *Google Pay / PhonePe UPI:* \`${profile.upiId}\`
💵 *କିମ୍ବା ଆମ ଫିଲ୍ଡ ଏଜେଣ୍ଟଙ୍କୁ ନଗଦ ପୈଠ କରନ୍ତୁ।*

ଧନ୍ୟବାଦ!
📞 *ହେଲ୍ପଲାଇନ୍:* ${profile.phone}
${profile.name}, ${profile.village}`;
    }

    if (lang === 'hi') {
      if (template === 'URGENT') {
        return `*अति महत्वपूर्ण - बकाया बिल भुगतान सूचना* ⚠️
*सीसीटीवी नेटवर्क चंपेश्वर*
---------------------------------------
प्रिय *${customer.name}* (ID: ${customer.customerCode}),
आपके केबल/इंटरनेट कनेक्शन का बकाया बिल अभी तक अप्राप्त है।

*कुल बकाया राशि (Total Due):* *${formattedDue}*
*सेवा प्रकार:* ${customer.serviceType} (${customer.planName})
*क्षेत्र:* ${customer.area}

कनेक्शन बंद होने से बचाने के लिए कृपया तुरंत भुगतान करें।

*घर बैठे UPI द्वारा भुगतान करें:*
📲 *UPI ID:* \`${profile.upiId}\`
(PhonePe, Google Pay, Paytm द्वारा भुगतान करें)

📞 *हेल्पलाइन:* ${profile.phone}
${profile.name}, चंपेश्वर`;
      }

      return `*मासिक बिल सूचना - सीसीटीवी नेटवर्क चंपेश्वर* 📡
---------------------------------------
प्रिय *${customer.name}*,
आपके कनेक्शन का माह *${activeMonth}* का बिल विवरण:

*ग्राहक आईडी:* ${customer.customerCode}
*प्लान:* ${customer.planName}
*मासिक शुल्क:* ${formattedPlan}
${customer.previousDues > 0 ? `*पिछला बकाया:* ${formattedPrev}\n` : ''}*कुल देय राशि:* *${formattedDue}*
*अंतिम तिथि:* ${dueDate}
---------------------------------------
*भुगतान कैसे करें:*
📲 *UPI ID:* \`${profile.upiId}\`
💵 *या हमारे संग्रहकर्ता को नकद दें।*

धन्यवाद!
📞 *हेल्पलाइन:* ${profile.phone}
${profile.name}, ${profile.village}`;
    }

    // Default English
    if (template === 'URGENT') {
      return `*URGENT: OVERDUE BILL NOTICE - ${profile.name}* ⚠️
---------------------------------------
Dear *${customer.name}* (ID: ${customer.customerCode}),
This is an urgent reminder that your cable / internet subscription has an overdue balance.

*TOTAL AMOUNT DUE:* *${formattedDue}*
*Service:* ${customer.serviceType} (${customer.planName})
*Area:* ${customer.area}

Please clear your pending balance immediately to avoid temporary service suspension.

*Pay Instantly via UPI (PhonePe / GPay / Paytm):*
📲 *UPI ID:* \`${profile.upiId}\`
Or pay in cash to our field collection agent.

📞 *Helpline / Support:* ${profile.phone}
📍 *Office:* ${profile.address}, ${profile.village}, Odisha`;
    }

    return `*MONTHLY BILL INVOICE - ${profile.name}* 📡
---------------------------------------
Dear *${customer.name}*,
Your monthly subscription bill for *${activeMonth}* is ready.

*Customer ID:* ${customer.customerCode}
*Area:* ${customer.area}
*Service Plan:* ${customer.planName}
*Monthly Plan Amount:* ${formattedPlan}
${customer.previousDues > 0 ? `*Previous Dues:* ${formattedPrev}\n` : ''}*TOTAL PAYABLE:* *${formattedDue}*
*Due Date:* ${dueDate}
---------------------------------------
*Easy Payment Methods:*
📲 *Pay via UPI (GPay/PhonePe/Paytm):* \`${profile.upiId}\`
💵 *Or pay cash to our visiting field executive.*

Thank you for being our valued subscriber!
📞 *Customer Support:* ${profile.phone}
${profile.address}, ${profile.village}`;
  }

  /**
   * Generate WhatsApp link to send Outstanding Dues notice
   */
  getWhatsAppOutstandingDuesUrl(
    customer: Customer,
    profile: BusinessProfile,
    options: {
      bill?: Bill;
      templateType?: DuesTemplateType;
      lang?: Language;
      activeMonth?: string;
      customMobile?: string;
    } = {}
  ): string {
    const targetPhone = this.formatWhatsAppPhone(options.customMobile || customer.mobile);
    const message = this.buildOutstandingDuesMessage(customer, profile, options);
    return `https://wa.me/${targetPhone}?text=${encodeURIComponent(message)}`;
  }
}

export const receiptService = new ReceiptService();
