/**
 * JARVIS Centralized Frontend API Client
 * Typed service layer for all backend communication with uniform error handling.
 */

import type {
  AgentInfo,
  AgentMessage,
  AuditLog,
  ChatMessage,
  ChatApiResponse,
  HealthApiResponse,
  MemoryEntry,
  MemoryStoreApiRequest,
  MemoryStoreApiResponse,
  ModelMetadata,
  PendingPermissionRequest,
  SkillDefinition,
  SystemStatus,
  TaskApproveApiResponse,
  TaskItem,
  TaskRejectApiResponse,
  ToolDefinition,
  ToolExecutionResult,
} from '../types.ts';

class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public details?: unknown
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (!headers.has('Accept')) {
    headers.set('Accept', 'application/json');
  }
  if (options.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const text = await response.text();
  let data: any;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }

  if (!response.ok) {
    throw new ApiError(
      response.status,
      data?.error || `HTTP ${response.status} from ${endpoint}`,
      data
    );
  }

  return data as T;
}

export const api = {
  // === System & Diagnostics ===
  async getStatus(): Promise<SystemStatus> {
    return request<SystemStatus>('/api/status');
  },

  async getHealth(): Promise<HealthApiResponse> {
    return request<HealthApiResponse>('/api/health');
  },

  async getConfig(): Promise<Record<string, unknown>> {
    return request<Record<string, unknown>>('/api/config');
  },

  async getDatabaseStatus(): Promise<Record<string, unknown>> {
    return request<Record<string, unknown>>('/api/database/status');
  },

  // === Conversation & Chat ===
  async getConversations(filter?: {
    projectId?: string;
    includeArchived?: boolean;
    includeTrash?: boolean;
    isTrashOnly?: boolean;
  }): Promise<{ conversations: import('../types.ts').ConversationItem[] }> {
    const params = new URLSearchParams();
    if (filter?.projectId) params.set('projectId', filter.projectId);
    if (filter?.includeArchived) params.set('includeArchived', 'true');
    if (filter?.includeTrash) params.set('includeTrash', 'true');
    if (filter?.isTrashOnly) params.set('isTrashOnly', 'true');
    const qs = params.toString();
    return request<{ conversations: import('../types.ts').ConversationItem[] }>(
      `/api/conversations${qs ? `?${qs}` : ''}`
    );
  },

  async searchConversations(
    query: string,
    options?: { projectId?: string; includeArchived?: boolean }
  ): Promise<import('../types.ts').ConversationSearchApiResponse> {
    const params = new URLSearchParams({ q: query });
    if (options?.projectId) params.set('projectId', options.projectId);
    if (options?.includeArchived) params.set('includeArchived', 'true');
    return request<import('../types.ts').ConversationSearchApiResponse>(
      `/api/conversations/search?${params.toString()}`
    );
  },

  async createConversation(
    title?: string,
    topic?: string,
    projectId?: string
  ): Promise<{ success: boolean; conversation: import('../types.ts').ConversationItem }> {
    return request<{ success: boolean; conversation: import('../types.ts').ConversationItem }>('/api/conversations', {
      method: 'POST',
      body: JSON.stringify({ title, topic, projectId }),
    });
  },

  async getConversation(id: string): Promise<{ conversation: import('../types.ts').ConversationItem; messages: ChatMessage[] }> {
    return request<{ conversation: import('../types.ts').ConversationItem; messages: ChatMessage[] }>(`/api/conversations/${encodeURIComponent(id)}`);
  },

  async updateConversation(
    id: string,
    updates: {
      title?: string;
      topic?: string;
      isArchived?: boolean;
      isTrash?: boolean;
      projectId?: string | null;
      hasCustomTitle?: boolean;
    }
  ): Promise<{ success: boolean; conversation: import('../types.ts').ConversationItem }> {
    return request<{ success: boolean; conversation: import('../types.ts').ConversationItem }>(`/api/conversations/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async restoreConversation(id: string): Promise<{ success: boolean; conversation: import('../types.ts').ConversationItem }> {
    return request<{ success: boolean; conversation: import('../types.ts').ConversationItem }>(`/api/conversations/${encodeURIComponent(id)}/restore`, {
      method: 'POST',
    });
  },

  async deleteConversation(id: string, permanent = false): Promise<{ success: boolean; deletedId: string; permanent?: boolean }> {
    return request<{ success: boolean; deletedId: string; permanent?: boolean }>(
      `/api/conversations/${encodeURIComponent(id)}${permanent ? '?permanent=true' : ''}`,
      {
        method: 'DELETE',
      }
    );
  },

  // === Projects Workspace ===
  async getProjects(filter?: {
    includeArchived?: boolean;
    includeTrash?: boolean;
    isTrashOnly?: boolean;
  }): Promise<import('../types.ts').ProjectsListApiResponse> {
    const params = new URLSearchParams();
    if (filter?.includeArchived) params.set('includeArchived', 'true');
    if (filter?.includeTrash) params.set('includeTrash', 'true');
    if (filter?.isTrashOnly) params.set('isTrashOnly', 'true');
    const qs = params.toString();
    return request<import('../types.ts').ProjectsListApiResponse>(`/api/projects${qs ? `?${qs}` : ''}`);
  },

  async getProject(id: string): Promise<import('../types.ts').ProjectDetailApiResponse> {
    return request<import('../types.ts').ProjectDetailApiResponse>(`/api/projects/${encodeURIComponent(id)}`);
  },

  async createProject(params: {
    name: string;
    description?: string;
    contextBrief?: string;
  }): Promise<{ success: boolean; project: import('../types.ts').ProjectItem }> {
    return request<{ success: boolean; project: import('../types.ts').ProjectItem }>('/api/projects', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async updateProject(
    id: string,
    updates: import('../types.ts').ProjectUpdateApiRequest
  ): Promise<{ success: boolean; project: import('../types.ts').ProjectItem }> {
    return request<{ success: boolean; project: import('../types.ts').ProjectItem }>(`/api/projects/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async restoreProject(id: string): Promise<{ success: boolean; project: import('../types.ts').ProjectItem }> {
    return request<{ success: boolean; project: import('../types.ts').ProjectItem }>(`/api/projects/${encodeURIComponent(id)}/restore`, {
      method: 'POST',
    });
  },

  async deleteProject(id: string, permanent = false): Promise<{ success: boolean; deletedId: string; permanent?: boolean }> {
    return request<{ success: boolean; deletedId: string; permanent?: boolean }>(
      `/api/projects/${encodeURIComponent(id)}${permanent ? '?permanent=true' : ''}`,
      {
        method: 'DELETE',
      }
    );
  },

  async getMessages(conversationId = 'conv_default'): Promise<{ messages: ChatMessage[] }> {
    return request<{ messages: ChatMessage[] }>(
      `/api/chat/messages?conversationId=${encodeURIComponent(conversationId)}`
    );
  },

  async sendChat(prompt: string, conversationId = 'conv_default'): Promise<ChatApiResponse> {
    return request<ChatApiResponse>('/api/chat', {
      method: 'POST',
      body: JSON.stringify({ prompt, conversationId }),
    });
  },

  // === Founder & Version & Discovery ===
  async getFounderProfile(): Promise<{ founder: import('../types.ts').FounderProfile }> {
    return request<{ founder: import('../types.ts').FounderProfile }>('/api/founder/profile');
  },

  async getVersionMetadata(): Promise<{ version: import('../types.ts').VersionMetadata }> {
    return request<{ version: import('../types.ts').VersionMetadata }>('/api/version/metadata');
  },

  async discoverFreeResources(query: import('../types.ts').FreeResourceQuery): Promise<import('../types.ts').FreeResourceResult> {
    return request<import('../types.ts').FreeResourceResult>('/api/discovery/free-resources', {
      method: 'POST',
      body: JSON.stringify(query),
    });
  },

  // === Tasks & Planner ===
  async getTasks(): Promise<{ tasks: TaskItem[] }> {
    return request<{ tasks: TaskItem[] }>('/api/tasks');
  },

  async getTask(id: string): Promise<{ task: TaskItem }> {
    return request<{ task: TaskItem }>(`/api/tasks/${encodeURIComponent(id)}`);
  },

  async createTask(goal: string): Promise<Record<string, unknown>> {
    return request<Record<string, unknown>>('/api/tasks', {
      method: 'POST',
      body: JSON.stringify({ goal }),
    });
  },

  async approveTask(taskId: string): Promise<TaskApproveApiResponse> {
    return request<TaskApproveApiResponse>(`/api/tasks/${encodeURIComponent(taskId)}/approve`, {
      method: 'POST',
    });
  },

  async rejectTask(taskId: string, reason = 'Operator denied'): Promise<TaskRejectApiResponse> {
    return request<TaskRejectApiResponse>(`/api/tasks/${encodeURIComponent(taskId)}/reject`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  },

  // === Memory System ===
  async getMemories(query?: { type?: string; text?: string }): Promise<{ memories: MemoryEntry[] }> {
    const params = new URLSearchParams();
    if (query?.type) params.set('type', query.type);
    if (query?.text) params.set('text', query.text);
    const queryString = params.toString() ? `?${params.toString()}` : '';
    return request<{ memories: MemoryEntry[] }>(`/api/memory${queryString}`);
  },

  async saveMemory(entry: MemoryStoreApiRequest): Promise<MemoryStoreApiResponse> {
    return request<MemoryStoreApiResponse>('/api/memory', {
      method: 'POST',
      body: JSON.stringify(entry),
    });
  },

  async deleteMemory(id: string): Promise<{ success: boolean }> {
    return request<{ success: boolean }>(`/api/memory/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
  },

  // === Tools & Skills ===
  async getTools(): Promise<{ tools: ToolDefinition[] }> {
    return request<{ tools: ToolDefinition[] }>('/api/tools');
  },

  async executeTool(toolName: string, parameters: Record<string, unknown>): Promise<ToolExecutionResult> {
    return request<ToolExecutionResult>('/api/tools/execute', {
      method: 'POST',
      body: JSON.stringify({ toolName, parameters }),
    });
  },

  async getSkills(): Promise<{ skills: SkillDefinition[] }> {
    return request<{ skills: SkillDefinition[] }>('/api/skills');
  },

  async getCapabilities(): Promise<{ success: boolean; capabilities: any[] }> {
    return request<{ success: boolean; capabilities: any[] }>('/api/capabilities');
  },

  // === Models & Agents ===
  async getModels(): Promise<{ models: ModelMetadata[] }> {
    return request<{ models: ModelMetadata[] }>('/api/models');
  },

  async getModelDecisions(limit = 20): Promise<{ decisions: any[] }> {
    return request<{ decisions: any[] }>(`/api/models/decisions?limit=${limit}`);
  },

  async testModelProbe(params: { prompt?: string; modelId?: string; category?: string }): Promise<{
    success: boolean;
    response?: any;
    decision?: any;
    error?: string;
  }> {
    return request<{ success: boolean; response?: any; decision?: any; error?: string }>('/api/models/test', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async getAgents(): Promise<{ agents: AgentInfo[]; recentMessages: AgentMessage[] }> {
    return request<{ agents: AgentInfo[]; recentMessages: AgentMessage[] }>('/api/agents');
  },

  // === Security & Audit ===
  async getSecurityAudit(): Promise<{
    auditLogs: AuditLog[];
    pendingRequests: PendingPermissionRequest[];
  }> {
    return request<{
      auditLogs: AuditLog[];
      pendingRequests: PendingPermissionRequest[];
    }>('/api/security/audit');
  },

  // === Files & Attachments ===
  async uploadFile(params: {
    originalName: string;
    mimeType: string;
    base64Data: string;
    conversationId?: string;
    projectId?: string;
  }): Promise<{ success: boolean; file: any }> {
    return request<{ success: boolean; file: any }>('/api/files/upload', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async getFiles(filter?: { conversationId?: string; projectId?: string }): Promise<{ success: boolean; files: any[] }> {
    const params = new URLSearchParams();
    if (filter?.conversationId) params.set('conversationId', filter.conversationId);
    if (filter?.projectId) params.set('projectId', filter.projectId);
    const query = params.toString() ? `?${params.toString()}` : '';
    return request<{ success: boolean; files: any[] }>(`/api/files${query}`);
  },

  async deleteFile(id: string): Promise<{ success: boolean; message: string }> {
    return request<{ success: boolean; message: string }>(`/api/files/${id}`, {
      method: 'DELETE',
    });
  },

  // === Document Generation ===
  async generateDocument(params: {
    title: string;
    format: 'pdf' | 'md' | 'txt' | 'json';
    content: string;
    conversationId?: string;
    projectId?: string;
  }): Promise<{ success: boolean; document: any }> {
    return request<{ success: boolean; document: any }>('/api/documents/generate', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async getDocuments(filter?: { conversationId?: string; projectId?: string }): Promise<{ success: boolean; documents: any[] }> {
    const params = new URLSearchParams();
    if (filter?.conversationId) params.set('conversationId', filter.conversationId);
    if (filter?.projectId) params.set('projectId', filter.projectId);
    const query = params.toString() ? `?${params.toString()}` : '';
    return request<{ success: boolean; documents: any[] }>(`/api/documents${query}`);
  },

  // === Universal Resource & Research ===
  async investigateResource(query: string): Promise<{ success: boolean; investigation: any }> {
    return request<{ success: boolean; investigation: any }>('/api/discovery/universal-investigate', {
      method: 'POST',
      body: JSON.stringify({ query }),
    });
  },

  async synthesizeResearch(params: {
    query: string;
    focusArea?: string;
    maxSources?: number;
  }): Promise<{ success: boolean; report: any }> {
    return request<{ success: boolean; report: any }>('/api/research/synthesize', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  // === OpenAPI Specification ===
  async getOpenApiSpec(): Promise<any> {
    return request<any>('/api/openapi.json');
  },

  getOpenApiDownloadUrl(): string {
    return '/api/docs/download';
  },

  // === Real-Time Events ===
  createEventSource(path = '/api/events'): EventSource {
    return new EventSource(path);
  },
};
