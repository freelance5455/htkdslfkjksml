import {
  User, Post, Story, StoriesGroup, Conversation, Message,
  GroupCommunity, PageProfile, MarketplaceItem, NotificationItem,
  TrendingHashtag, TrendingTopic, AdminStats
} from '../types';

export const ANGOLA_PROVINCES = [
  'Todas',
  'Luanda',
  'Benguela',
  'Huambo',
  'Huíla',
  'Cabinda',
  'Cuanza Sul',
  'Cuanza Norte',
  'Uíge',
  'Malanje',
  'Namibe',
  'Bié',
  'Zaire',
  'Cunene',
  'Cuando Cubango',
  'Lunda Norte',
  'Lunda Sul',
  'Moxico',
  'Bengo'
];

export const COUNTRY_CODES = [
  { code: '+244', name: 'Angola 🇦🇴', flag: '🇦🇴' },
  { code: '+351', name: 'Portugal 🇵🇹', flag: '🇵🇹' },
  { code: '+55', name: 'Brasil 🇧🇷', flag: '🇧🇷' },
  { code: '+238', name: 'Cabo Verde 🇨🇻', flag: '🇨🇻' },
  { code: '+258', name: 'Moçambique 🇲🇿', flag: '🇲🇿' },
  { code: '+239', name: 'São Tomé 🇸🇹', flag: '🇸🇹' },
  { code: '+27', name: 'África do Sul 🇿🇦', flag: '🇿🇦' },
  { code: '+1', name: 'EUA / Canadá 🇺🇸', flag: '🇺🇸' },
  { code: '+44', name: 'Reino Unido 🇬🇧', flag: '🇬🇧' },
  { code: '+33', name: 'França 🇫🇷', flag: '🇫🇷' },
];

function cacheSet(key: string, data: any) {
  try {
    localStorage.setItem(`pwa_offline_${key}`, JSON.stringify(data));
  } catch (e) {}
}

function cacheGet(key: string) {
  try {
    const raw = localStorage.getItem(`pwa_offline_${key}`);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

async function handleResponse(res: Response) {
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(json.error || `Erro na requisição (${res.status})`);
  }
  return json;
}

async function fetchWithOfflineCache(url: string, cacheKey: string) {
  try {
    const res = await fetch(url);
    const data = await handleResponse(res);
    cacheSet(cacheKey, data);
    return data;
  } catch (err) {
    console.warn(`[Offline Cache] Rede indisponível. Carregando dados locais de "${cacheKey}"...`);
    const cached = cacheGet(cacheKey);
    if (cached) return cached;
    throw err;
  }
}

export const api = {
  // Auth & Phone Verification
  async sendVerificationCode(phoneOrEmail: string, phoneCountryCode: string = '+244') {
    const res = await fetch('/api/auth/send-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneOrEmail, phoneCountryCode })
    });
    return handleResponse(res);
  },

  async verifyCode(phoneOrEmail: string, code: string) {
    const res = await fetch('/api/auth/verify-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneOrEmail, code })
    });
    return handleResponse(res);
  },

  async register(data: {
    name: string;
    username: string;
    email?: string;
    phone?: string;
    phoneCountryCode?: string;
    province?: string;
    bio?: string;
    avatar?: string;
    coverImage?: string;
  }) {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async login(identifier: string) {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier })
    });
    return handleResponse(res);
  },

  async updateProfile(id: string, data: Partial<User>) {
    const res = await fetch(`/api/auth/profile/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async recoverAccount(phoneOrEmail: string) {
    const res = await fetch('/api/auth/recover', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneOrEmail })
    });
    return handleResponse(res);
  },

  // Media Upload
  async uploadFile(dataBase64: string, filename?: string): Promise<{ success: boolean; url: string }> {
    const res = await fetch('/api/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dataBase64, filename })
    });
    return handleResponse(res);
  },

  // Posts
  async getPosts(params?: { hashtag?: string; province?: string; authorId?: string; savedByUserId?: string }): Promise<{ posts: Post[] }> {
    const q = new URLSearchParams();
    if (params?.hashtag) q.append('hashtag', params.hashtag);
    if (params?.province) q.append('province', params.province);
    if (params?.authorId) q.append('authorId', params.authorId);
    if (params?.savedByUserId) q.append('savedByUserId', params.savedByUserId);

    const queryString = q.toString();
    const url = `/api/posts${queryString ? `?${queryString}` : ''}`;
    return fetchWithOfflineCache(url, `posts_${queryString || 'all'}`);
  },

  async createPost(data: { authorId: string; content: string; mediaUrl?: string; mediaType?: 'image' | 'video' | 'none'; province?: string; pageId?: string }) {
    const res = await fetch('/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async reactPost(postId: string, userId: string, reaction: 'like' | 'love' | 'angola' | 'laugh' | 'fire' = 'like') {
    const res = await fetch(`/api/posts/${postId}/react`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, reaction })
    });
    return handleResponse(res);
  },

  async commentPost(postId: string, data: { authorId: string; text: string; parentCommentId?: string }) {
    const res = await fetch(`/api/posts/${postId}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async sharePost(postId: string, userId?: string) {
    const res = await fetch(`/api/posts/${postId}/share`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    });
    return handleResponse(res);
  },

  async savePost(postId: string, userId: string) {
    const res = await fetch(`/api/posts/${postId}/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    });
    return handleResponse(res);
  },

  async deletePost(postId: string, userId: string, isAdmin?: boolean) {
    const res = await fetch(`/api/posts/${postId}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, isAdmin })
    });
    return handleResponse(res);
  },

  async reportPost(postId: string, reporterId: string, reason: string) {
    const res = await fetch(`/api/posts/${postId}/report`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reporterId, reason })
    });
    return handleResponse(res);
  },

  // Stories
  async getStories(userId?: string): Promise<{ storiesGrouped: StoriesGroup[]; totalCount: number }> {
    const q = userId ? `?userId=${userId}` : '';
    return fetchWithOfflineCache(`/api/stories${q}`, `stories_${userId || 'all'}`);
  },

  async createStory(data: { authorId: string; mediaUrl?: string; mediaType?: 'image' | 'video' | 'text'; textContent?: string; backgroundGradient?: string; privacy?: 'public' | 'friends' | 'private' }) {
    const res = await fetch('/api/stories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async viewStory(storyId: string, userId: string) {
    const res = await fetch(`/api/stories/${storyId}/view`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    });
    return handleResponse(res);
  },

  async reactStory(storyId: string, userId: string, emoji: string) {
    const res = await fetch(`/api/stories/${storyId}/react`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, emoji })
    });
    return handleResponse(res);
  },

  async deleteStory(storyId: string, userId: string) {
    const res = await fetch(`/api/stories/${storyId}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    });
    return handleResponse(res);
  },

  // Messages
  async getConversations(userId: string): Promise<{ conversations: Conversation[] }> {
    return fetchWithOfflineCache(`/api/messages/conversations/${userId}`, `conversations_${userId}`);
  },

  async getOrCreateDirectConversation(user1Id: string, user2Id: string): Promise<{ conversation: Conversation }> {
    const res = await fetch('/api/messages/conversations/direct', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user1Id, user2Id })
    });
    return handleResponse(res);
  },

  async createGroupConversation(data: { name: string; avatar?: string; participantIds: string[]; creatorId: string }) {
    const res = await fetch('/api/messages/conversations/group', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async getMessages(conversationId: string, userId: string): Promise<{ messages: Message[] }> {
    return fetchWithOfflineCache(`/api/messages/${conversationId}?userId=${userId}`, `messages_${conversationId}`);
  },

  async sendMessage(data: Partial<Message>) {
    const res = await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async markMessagesAsRead(conversationId: string, userId: string) {
    const res = await fetch('/api/messages/read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conversationId, userId })
    });
    return handleResponse(res);
  },

  async reactMessage(messageId: string, userId: string, emoji: string) {
    const res = await fetch(`/api/messages/${messageId}/react`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, emoji })
    });
    return handleResponse(res);
  },

  async deleteMessage(messageId: string, userId: string, forEveryone: boolean) {
    const res = await fetch(`/api/messages/${messageId}/delete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, forEveryone })
    });
    return handleResponse(res);
  },

  async pinMessage(messageId: string) {
    const res = await fetch(`/api/messages/${messageId}/pin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    return handleResponse(res);
  },

  // Social
  async searchUsers(params?: { q?: string; province?: string; currentUserId?: string }): Promise<{ users: User[] }> {
    const q = new URLSearchParams();
    if (params?.q) q.append('q', params.q);
    if (params?.province) q.append('province', params.province);
    if (params?.currentUserId) q.append('currentUserId', params.currentUserId);

    const queryString = q.toString();
    return fetchWithOfflineCache(`/api/social/users${queryString ? `?${queryString}` : ''}`, `users_${queryString || 'all'}`);
  },

  async getUserProfile(identifier: string): Promise<{ user: User; stats: { postsCount: number; photosCount: number; videosCount: number } }> {
    return fetchWithOfflineCache(`/api/social/users/${identifier}`, `profile_${identifier}`);
  },

  async sendFriendRequest(fromUserId: string, toUserId: string) {
    const res = await fetch('/api/social/friends/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fromUserId, toUserId })
    });
    return handleResponse(res);
  },

  async respondFriendRequest(requestId: string, action: 'accept' | 'reject') {
    const res = await fetch('/api/social/friends/respond', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ requestId, action })
    });
    return handleResponse(res);
  },

  async removeFriend(userId: string, friendId: string) {
    const res = await fetch('/api/social/friends/remove', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, friendId })
    });
    return handleResponse(res);
  },

  async toggleFollow(followerId: string, targetUserId: string) {
    const res = await fetch('/api/social/follow', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ followerId, targetUserId })
    });
    return handleResponse(res);
  },

  async toggleBlock(blockerId: string, blockedId: string) {
    const res = await fetch('/api/social/block', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ blockerId, blockedId })
    });
    return handleResponse(res);
  },

  async getNotifications(userId: string): Promise<{ notifications: NotificationItem[] }> {
    return fetchWithOfflineCache(`/api/social/notifications/${userId}`, `notifications_${userId}`);
  },

  async markNotificationsAsRead(userId: string, notificationId?: string) {
    const res = await fetch('/api/social/notifications/read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, notificationId })
    });
    return handleResponse(res);
  },

  // Groups
  async getGroups(params?: { category?: string; userId?: string }): Promise<{ groups: GroupCommunity[] }> {
    const q = new URLSearchParams();
    if (params?.category) q.append('category', params.category);
    if (params?.userId) q.append('userId', params.userId);
    const queryString = q.toString();
    return fetchWithOfflineCache(`/api/groups${queryString ? `?${queryString}` : ''}`, `groups_${queryString || 'all'}`);
  },

  async createGroup(data: Partial<GroupCommunity>) {
    const res = await fetch('/api/groups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async toggleGroupJoin(groupId: string, userId: string) {
    const res = await fetch(`/api/groups/${groupId}/join-toggle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    });
    return handleResponse(res);
  },

  // Pages
  async getPages(params?: { category?: string; userId?: string }): Promise<{ pages: PageProfile[] }> {
    const q = new URLSearchParams();
    if (params?.category) q.append('category', params.category);
    if (params?.userId) q.append('userId', params.userId);
    const queryString = q.toString();
    return fetchWithOfflineCache(`/api/pages${queryString ? `?${queryString}` : ''}`, `pages_${queryString || 'all'}`);
  },

  async createPage(data: Partial<PageProfile>) {
    const res = await fetch('/api/pages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async togglePageFollow(pageId: string, userId: string) {
    const res = await fetch(`/api/pages/${pageId}/follow-toggle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    });
    return handleResponse(res);
  },

  // Marketplace
  async getMarketplace(params?: { category?: string; province?: string; q?: string; maxPrice?: number; sellerId?: string }): Promise<{ items: MarketplaceItem[] }> {
    const q = new URLSearchParams();
    if (params?.category) q.append('category', params.category);
    if (params?.province) q.append('province', params.province);
    if (params?.q) q.append('q', params.q);
    if (params?.maxPrice) q.append('maxPrice', params.maxPrice.toString());
    if (params?.sellerId) q.append('sellerId', params.sellerId);

    const queryString = q.toString();
    return fetchWithOfflineCache(`/api/marketplace${queryString ? `?${queryString}` : ''}`, `marketplace_${queryString || 'all'}`);
  },

  async createMarketplaceItem(data: Partial<MarketplaceItem>) {
    const res = await fetch('/api/marketplace', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  async toggleMarketplaceSold(id: string, sellerId: string) {
    const res = await fetch(`/api/marketplace/${id}/toggle-sold`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sellerId })
    });
    return handleResponse(res);
  },

  async deleteMarketplaceItem(id: string, sellerId: string, isAdmin?: boolean) {
    const res = await fetch(`/api/marketplace/${id}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sellerId, isAdmin })
    });
    return handleResponse(res);
  },

  // Trends & Angola Agora
  async getTrends(province?: string): Promise<{ trendingHashtags: TrendingHashtag[]; trendingTopics: TrendingTopic[]; provinces: string[] }> {
    const q = province ? `?province=${encodeURIComponent(province)}` : '';
    return fetchWithOfflineCache(`/api/trends${q}`, `trends_${province || 'all'}`);
  },

  // Admin
  async getAdminStats(adminId: string): Promise<{ stats: AdminStats }> {
    const res = await fetch(`/api/admin/stats?adminId=${adminId}`);
    return handleResponse(res);
  },

  async getAdminUsers(adminId: string): Promise<{ users: User[] }> {
    const res = await fetch(`/api/admin/users?adminId=${adminId}`);
    return handleResponse(res);
  },

  async adminUserAction(userId: string, action: 'toggle_verified' | 'toggle_suspend' | 'make_admin', adminId: string) {
    const res = await fetch(`/api/admin/users/${userId}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, adminId })
    });
    return handleResponse(res);
  },

  async getAdminReports(adminId: string) {
    const res = await fetch(`/api/admin/reports?adminId=${adminId}`);
    return handleResponse(res);
  },

  async resolveReport(reportId: string, action: 'dismiss' | 'remove_content' | 'resolve', adminId: string) {
    const res = await fetch(`/api/admin/reports/${reportId}/resolve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, adminId })
    });
    return handleResponse(res);
  }
};
