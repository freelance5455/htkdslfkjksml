import {
  ActionProposal,
  CryptoTicker,
  TechnicalIndicators,
  AIAnalysisResult,
  SupportedLanguage,
  UserMemory,
  DailySignal,
  CryptoNewsItem,
  FearGreedData,
} from '../types';

export async function sendMessageToDost(
  messages: { role: string; content: string }[],
  userLanguage: SupportedLanguage,
  userMemories: UserMemory[] = []
): Promise<{
  reply: string;
  action: ActionProposal | null;
  newMemory: string | null;
  appCode?: { title: string; code: string; type: string } | null;
  modelUsed?: string;
}> {
  try {
    const res = await fetch('/api/gemini/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, userLanguage, userMemories }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return {
        reply: 'Salam bhai! Network thora busy hai, lekin main hazir hoon. Hukum karein, main kya karoon?',
        action: null,
        newMemory: null,
        appCode: null,
      };
    }
    return res.json();
  } catch (err: any) {
    return {
      reply: 'Salam bhai! Internet connect ho raha hai. Main bilkul ready hoon, hukum karein!',
      action: null,
      newMemory: null,
      appCode: null,
    };
  }
}

export async function fetchCryptoTickers(): Promise<CryptoTicker[]> {
  const res = await fetch('/api/crypto/tickers');
  if (!res.ok) throw new Error('Failed to fetch crypto tickers');
  const data = await res.json();
  return data.tickers || [];
}

export async function fetchDailySignals(): Promise<{
  signals: DailySignal[];
  marketCondition: string;
  riskNotice: string;
}> {
  const res = await fetch('/api/crypto/signals');
  if (!res.ok) throw new Error('Failed to fetch crypto signals');
  return res.json();
}

export async function fetchCryptoNews(): Promise<{
  fearGreedIndex: FearGreedData;
  news: CryptoNewsItem[];
}> {
  const res = await fetch('/api/crypto/news');
  if (!res.ok) throw new Error('Failed to fetch crypto news');
  return res.json();
}

export async function fetchKlinesAndIndicators(
  symbol: string,
  interval: string
): Promise<{
  candles: Array<{ time: number; open: number; high: number; low: number; close: number; volume: number }>;
  indicators: TechnicalIndicators;
}> {
  const res = await fetch(`/api/crypto/klines?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}`);
  if (!res.ok) throw new Error('Failed to fetch technical indicators');
  return res.json();
}

export async function fetchAiCryptoAnalysis(
  symbol: string,
  interval: string,
  indicators: TechnicalIndicators,
  userLanguage: SupportedLanguage
): Promise<AIAnalysisResult> {
  const res = await fetch('/api/crypto/ai-analysis', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ symbol, interval, indicators, userLanguage }),
  });
  if (!res.ok) throw new Error('Failed to fetch AI crypto analysis');
  return res.json();
}
