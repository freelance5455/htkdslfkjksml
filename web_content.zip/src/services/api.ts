import { ApiStatus, ChatMessage } from '../types/chat';

/**
 * Service to handle secure server-side communications with Gemini API
 * No secret API keys are kept or exposed on the client side.
 */

export async function fetchServerStatus(): Promise<ApiStatus> {
  try {
    const res = await fetch('/api/status', {
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) throw new Error('فشل جلب حالة الخادم');
    return await res.json();
  } catch (error) {
    return {
      status: 'error',
      hasApiKey: false,
      model: 'gemini-3.1-flash-lite',
      appName: 'Mostafa AI',
      arabicSupport: true,
    };
  }
}

export async function sendChatMessage(
  messages: ChatMessage[],
  onChunk?: (token: string) => void
): Promise<string> {
  const payload = {
    messages: messages.map((m) => ({
      role: m.role,
      content: m.content,
      image: m.image,
    })),
  };

  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json().catch(() => ({}));

    if (data.error) {
      let friendlyError = data.error;
      // If error text contains raw JSON or ApiError, clean it up
      if (friendlyError.includes('ApiError') || friendlyError.includes('"code":')) {
        if (friendlyError.includes('503') || friendlyError.includes('UNAVAILABLE')) {
          friendlyError = 'الخوادم تشهد ضغطاً مؤقتاً في هذه اللحظة. يرجى المحاولة مرة أخرى بعد لحظات.';
        } else if (friendlyError.includes('429') || friendlyError.includes('Quota')) {
          friendlyError = 'تم بلوغ حد الاستخدام المؤقت للنموذج المجاني. يرجى المحاولة بعد قليل.';
        } else {
          friendlyError = 'تعذر استكمال الرد في الوقت الحالي، يرجى إعادة المحاولة.';
        }
      }
      throw new Error(friendlyError);
    }

    if (!data.reply) {
      throw new Error('لم يتم استلام رد صالح من خادم الذكاء الاصطناعي.');
    }

    const fullReply: string = data.reply;

    // Provide typing animation if callback is present
    if (onChunk) {
      const words = fullReply.split(' ');
      // If response is short or long, animate progressively
      const delay = Math.max(10, Math.min(25, Math.floor(1000 / (words.length || 1))));
      for (let i = 0; i < words.length; i++) {
        const token = (i === 0 ? '' : ' ') + words[i];
        onChunk(token);
        if (words.length > 5) {
          await new Promise((r) => setTimeout(r, delay));
        }
      }
    }

    return fullReply;
  } catch (err: any) {
    console.error('API send error:', err);
    let msg = err?.message || 'حدث خطأ غير متوقع أثناء معالجة رسالتك.';
    if (msg.includes('Failed to fetch')) {
      msg = 'تعذر الوصول إلى الخادم، يرجى التأكد من تشغيل الخادم وتوفر الاتصال بالإنترنت.';
    } else if (msg.includes('ApiError') || msg.includes('"code":')) {
      msg = 'الخوادم تشهد ضغطاً مؤقتاً في هذه اللحظة. يرجى إعادة المحاولة.';
    }
    throw new Error(msg);
  }
}
