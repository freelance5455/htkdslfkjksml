import type { User, Chat, Message, Report, AuditLog, BanRecord, StatusStory, AppSettings, AIAgentConfig } from '../types/index.ts';

type WsCallback = (data: any) => void;

class WebSocketClient {
  private ws: WebSocket | null = null;
  private listeners: Map<string, Set<WsCallback>> = new Map();
  private reconnectTimer: any = null;
  private currentUserId: string | null = null;
  private isConnecting = false;

  public connect(userId: string) {
    this.currentUserId = userId;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      if (this.ws.readyState === WebSocket.OPEN) {
        this.send({ type: 'auth:identify', userId });
      }
      return;
    }

    if (this.isConnecting) return;
    this.isConnecting = true;

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnecting = false;
        if (this.currentUserId) {
          this.send({ type: 'auth:identify', userId: this.currentUserId });
        }
        this.emit('connection:change', { online: true });
      };

      this.ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type) {
            this.emit(payload.type, payload);
          }
        } catch (e) {
          console.error('WS Parse error', e);
        }
      };

      this.ws.onclose = () => {
        this.isConnecting = false;
        this.emit('connection:change', { online: false });
        // Auto reconnect every 3s
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = setTimeout(() => {
          if (this.currentUserId) {
            this.connect(this.currentUserId);
          }
        }, 3000);
      };

      this.ws.onerror = () => {
        this.isConnecting = false;
      };
    } catch (err) {
      this.isConnecting = false;
      console.error('WS Connection error', err);
    }
  }

  public send(data: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    }
  }

  public on(event: string, callback: WsCallback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    return () => {
      this.listeners.get(event)?.delete(callback);
    };
  }

  public emit(event: string, data: any) {
    this.listeners.get(event)?.forEach(cb => {
      try {
        cb(data);
      } catch (e) {
        console.error('WS Listener error:', e);
      }
    });
  }

  public disconnect() {
    this.currentUserId = null;
    clearTimeout(this.reconnectTimer);
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}

export const wsClient = new WebSocketClient();

// REST API calls
export const api = {
  async login(username: string, password: string) {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    return res.json();
  },

  async changePassword(userId: string, currentPassword: string, newPassword: string) {
    const res = await fetch('/api/auth/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, currentPassword, newPassword }),
    });
    return res.json();
  },

  // Admin
  async verifyAdminKey(adminKey: string) {
    const res = await fetch('/api/admin/verify-key', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminKey }),
    });
    return res.json();
  },

  async changeAdminKey(currentKey: string, newKey: string) {
    const res = await fetch('/api/admin/change-key', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentKey, newKey }),
    });
    return res.json();
  },

  async getAdminStats() {
    const res = await fetch('/api/admin/stats');
    return res.json();
  },

  async getAdminSettings(): Promise<AppSettings> {
    const res = await fetch('/api/admin/settings');
    return res.json();
  },

  async updateAdminSettings(settings: Partial<AppSettings>) {
    const res = await fetch('/api/admin/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    return res.json();
  },

  async getAdminUsers(): Promise<User[]> {
    const res = await fetch('/api/admin/users');
    return res.json();
  },

  async createAdminUser(data: {
    fullName: string;
    username: string;
    temporaryPassword?: string;
    avatarUrl?: string;
    status?: 'active' | 'banned';
    bio?: string;
    verifiedBlueTick?: boolean;
  }) {
    const res = await fetch('/api/admin/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },

  async updateAdminUser(id: string, updates: Partial<User>) {
    const res = await fetch(`/api/admin/users/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    return res.json();
  },

  async resetUserPassword(userId: string, newPassword?: string) {
    const res = await fetch(`/api/admin/users/${userId}/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newPassword }),
    });
    return res.json();
  },

  async banUser(userId: string, options: { banType: 'temporary' | 'permanent'; durationDays?: number; reason: string }) {
    const res = await fetch(`/api/admin/users/${userId}/ban`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(options),
    });
    return res.json();
  },

  async unbanUser(userId: string) {
    const res = await fetch(`/api/admin/users/${userId}/unban`, {
      method: 'POST',
    });
    return res.json();
  },

  async deleteUser(userId: string) {
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: 'DELETE',
    });
    return res.json();
  },

  async toggleBlueTick(userId: string, granted: boolean, note?: string) {
    const res = await fetch(`/api/admin/users/${userId}/blue-tick`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ granted, note }),
    });
    return res.json();
  },

  async getAdminReports(): Promise<Report[]> {
    const res = await fetch('/api/admin/reports');
    return res.json();
  },

  async resolveReport(reportId: string, status: 'action_taken' | 'dismissed', note?: string) {
    const res = await fetch(`/api/admin/reports/${reportId}/resolve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, note }),
    });
    return res.json();
  },

  async getAuditLogs(): Promise<AuditLog[]> {
    const res = await fetch('/api/admin/audit-logs');
    return res.json();
  },

  async getBanRecords(): Promise<BanRecord[]> {
    const res = await fetch('/api/admin/ban-records');
    return res.json();
  },

  async deleteGroup(groupId: string) {
    const res = await fetch(`/api/admin/groups/${groupId}`, {
      method: 'DELETE',
    });
    return res.json();
  },

  async getAIAgentConfig(): Promise<AIAgentConfig> {
    const res = await fetch('/api/admin/ai-agent');
    return res.json();
  },

  async updateAIAgentConfig(config: Partial<AIAgentConfig>): Promise<{ success: boolean; config: AIAgentConfig }> {
    const res = await fetch('/api/admin/ai-agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    return res.json();
  },

  async testAIAgent(prompt: string, customPrompt?: string, customKnowledge?: string): Promise<{ success: boolean; reply: string; error?: string }> {
    const res = await fetch('/api/admin/ai-agent/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, customPrompt, customKnowledge }),
    });
    return res.json();
  },

  // Directory & Users
  async getUsers(): Promise<User[]> {
    const res = await fetch('/api/users');
    return res.json();
  },

  async getUserById(id: string): Promise<User> {
    const res = await fetch(`/api/users/${id}`);
    return res.json();
  },

  async updateUserProfile(userId: string, updates: Partial<User>) {
    const res = await fetch(`/api/users/${userId}/profile`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    return res.json();
  },

  // Chats & Messaging
  async getChats(userId: string): Promise<Chat[]> {
    const res = await fetch(`/api/chats?userId=${encodeURIComponent(userId)}`);
    return res.json();
  },

  async createDirectChat(userA: string, userB: string): Promise<Chat> {
    const res = await fetch('/api/chats/direct', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userA, userB }),
    });
    return res.json();
  },

  async createGroupChat(creatorId: string, name: string, participantIds: string[], avatar?: string, description?: string): Promise<Chat> {
    const res = await fetch('/api/chats/group', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ creatorId, name, participantIds, avatar, description }),
    });
    return res.json();
  },

  async getMessages(chatId: string, userId: string): Promise<Message[]> {
    const res = await fetch(`/api/chats/${chatId}/messages?userId=${encodeURIComponent(userId)}`);
    return res.json();
  },

  async sendMessage(chatId: string, payload: {
    senderId: string;
    text: string;
    mediaUrl?: string;
    mediaType?: 'image' | 'file' | 'apk';
    fileName?: string;
    fileSize?: string;
    replyTo?: { id: string; text: string; senderName: string };
  }) {
    const res = await fetch(`/api/chats/${chatId}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async markChatRead(chatId: string, userId: string) {
    const res = await fetch(`/api/chats/${chatId}/read`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId }),
    });
    return res.json();
  },

  async deleteMessage(messageId: string, userId: string, forEveryone: boolean) {
    const res = await fetch(`/api/messages/${messageId}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, forEveryone }),
    });
    return res.json();
  },

  // Reports
  async submitReport(payload: {
    reporterId: string;
    reportedUserId: string;
    messageId?: string;
    chatId?: string;
    reason: string;
    evidenceSnippet?: string;
  }) {
    const res = await fetch('/api/reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  // Status Stories
  async getStatuses(): Promise<StatusStory[]> {
    const res = await fetch('/api/status');
    return res.json();
  },

  async createStatus(userId: string, caption: string, mediaUrl?: string) {
    const res = await fetch('/api/status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, caption, mediaUrl }),
    });
    return res.json();
  },

  async markStatusViewed(statusId: string, userId: string) {
    const res = await fetch(`/api/status/${statusId}/view`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId }),
    });
    return res.json();
  },
};
