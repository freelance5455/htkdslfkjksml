const BASE_URL = '/api';

interface FetchOptions extends RequestInit {
  data?: any;
}

const TOKEN_KEY = 'ntix_auth_token';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null) {
  try {
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    // Ignore storage quota errors
  }
}

export async function apiRequest<T = any>(endpoint: string, options: FetchOptions = {}): Promise<T> {
  const { data, headers = {}, ...customConfig } = options;

  const authHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
  };

  const token = getStoredToken();
  if (token) {
    authHeaders['Authorization'] = `Bearer ${token}`;
  }

  const config: RequestInit = {
    method: data ? 'POST' : 'GET',
    credentials: 'include',
    headers: {
      ...authHeaders,
      ...headers,
    },
    ...customConfig,
  };

  if (data) {
    config.body = JSON.stringify(data);
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, config);
  const result = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = result.error || 'A network error occurred. Please try again.';
    throw new Error(errorMsg);
  }

  if (result && result.token) {
    setStoredToken(result.token);
  }

  return result as T;
}

export const api = {
  // Auth
  googleAuth: async (payload: { credential?: string; email?: string; name?: string; uid?: string; photoURL?: string }) => {
    const res = await apiRequest('/auth/google', { data: payload });
    if (res.token) setStoredToken(res.token);
    return res;
  },
  getMe: () => apiRequest('/auth/me'),
  logout: async () => {
    try {
      await apiRequest('/auth/logout', { method: 'POST' });
    } finally {
      setStoredToken(null);
    }
  },
  updateProfile: (data: { name?: string; phone?: string }) =>
    apiRequest('/user/profile', { method: 'PUT', data }),

  // Products
  getProducts: (params?: { category?: string; search?: string; sort?: string; minPrice?: number; maxPrice?: number }) => {
    const query = new URLSearchParams();
    if (params?.category) query.append('category', params.category);
    if (params?.search) query.append('search', params.search);
    if (params?.sort) query.append('sort', params.sort);
    if (params?.minPrice) query.append('minPrice', String(params.minPrice));
    if (params?.maxPrice) query.append('maxPrice', String(params.maxPrice));
    return apiRequest(`/products?${query.toString()}`);
  },
  getProductById: (id: string) => apiRequest(`/products/${id}`),
  submitReview: (productId: string, data: { rating: number; comment: string }) =>
    apiRequest(`/products/${productId}/reviews`, { data }),

  // Coupons
  validateCoupon: (code: string, cartSubtotal: number) =>
    apiRequest('/coupons/validate', { data: { code, cartSubtotal } }),

  // Orders - Cash on Delivery Only
  createOrder: (orderPayload: {
    items: { productId: string; quantity: number; selectedSize?: string; selectedColor?: string }[];
    shippingAddress: any;
    paymentMethod?: 'cod';
    couponCode?: string;
  }) => apiRequest('/orders', { data: { ...orderPayload, paymentMethod: 'cod' } }),
  getUserOrders: () => apiRequest('/orders'),
  getOrderById: (orderId: string) => apiRequest(`/orders/${orderId}`),
  cancelOrder: (orderId: string, reason?: string) =>
    apiRequest(`/orders/${orderId}/cancel`, { method: 'POST', data: { reason } }),
  getOrderTracking: (orderId: string) => apiRequest(`/orders/${orderId}/tracking`),
  trackShipmentPublic: (query: string) => apiRequest(`/shipping/track/${encodeURIComponent(query)}`),
  getOrderInvoice: (orderId: string) => apiRequest(`/orders/${orderId}/invoice`),

  // Returns & Exchanges
  requestReturnOrExchange: (
    orderId: string,
    data: {
      type: 'return' | 'exchange';
      reason: string;
      comments?: string;
      exchangeSize?: string;
      exchangeColor?: string;
      pickupAddress?: any;
    }
  ) => apiRequest(`/orders/${orderId}/return`, { data }),
  createReturnRequest: (data: { orderId: string; reason: string; comments?: string }) =>
    apiRequest('/returns', { data }),
  getUserReturns: () => apiRequest('/returns'),

  // Notifications
  getNotifications: () => apiRequest('/notifications'),
  markNotificationRead: (id: string) =>
    apiRequest(`/notifications/${id}/read`, { method: 'POST' }),
  markAllNotificationsRead: () =>
    apiRequest('/notifications/read-all', { method: 'POST' }),
  deleteNotification: (id: string) =>
    apiRequest(`/notifications/${id}`, { method: 'DELETE' }),
  clearAllNotifications: () =>
    apiRequest('/notifications', { method: 'DELETE' }),

  // Addresses
  getUserAddresses: () => apiRequest('/user/addresses'),
  addAddress: (addressData: any) => apiRequest('/user/addresses', { data: addressData }),
  updateAddress: (id: string, addressData: any) =>
    apiRequest(`/user/addresses/${id}`, { method: 'PUT', data: addressData }),
  setDefaultAddress: (id: string) =>
    apiRequest(`/user/addresses/${id}/default`, { method: 'PATCH' }),
  deleteAddress: (id: string) => apiRequest(`/user/addresses/${id}`, { method: 'DELETE' }),

  // Wishlist
  getWishlist: () => apiRequest('/user/wishlist'),
  toggleWishlist: (productId: string) =>
    apiRequest('/user/wishlist/toggle', { data: { productId } }),
  syncWishlist: (productIds: string[]) =>
    apiRequest('/user/wishlist/sync', { data: { productIds } }),

  // Cart
  getCart: () => apiRequest('/user/cart'),
  saveCart: (items: any[]) => apiRequest('/user/cart', { data: { items } }),

  // Contact
  submitContact: (data: { name: string; email: string; subject?: string; message: string }) =>
    apiRequest('/contact', { data }),
};
