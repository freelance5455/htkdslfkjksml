"use client";

import {
  ALL_INTERVALS, Candle, Interval, INTERVAL_MS, IntervalAnalysis, MtfSnapshot,
  SymbolId, SYMBOLS, SYMBOL_META, Tick, TradeSide,
} from "@/types";
import { streamManager } from "./streamManagerService";
import { useTradingStore } from "./useTradingStore";

const HISTORY = 120;

/**
 * Comprehensive ALL-interval scanner (1m → 1w).
 * Seeds candle history (Binance REST when reachable, deterministic synthetic
 * otherwise) and aggregates every live tick into all 13 interval series.
 * Produces a top-down confluence snapshot per symbol.
 */
class MultiTimeframeEngine {
  private candles = new Map<string, Candle[]>(); // `${symbol}_${interval}`
  private started = false;
  private analyzeTimer: ReturnType<typeof setInterval> | null = null;

  key(symbol: SymbolId, interval: Interval) {
    return `${symbol}_${interval}`;
  }

  getCandles(symbol: SymbolId, interval: Interval): Candle[] {
    return this.candles.get(this.key(symbol, interval)) ?? [];
  }

  start() {
    if (this.started || typeof window === "undefined") return;
    this.started = true;

    for (const s of SYMBOLS) {
      for (const iv of ALL_INTERVALS) {
        this.candles.set(this.key(s, iv), this.synthSeed(s, iv));
      }
      this.fetchReal(s, "1m");
      this.fetchReal(s, "5m");
      this.fetchReal(s, "15m");
      this.fetchReal(s, "1h");
      this.fetchReal(s, "4h");
      this.fetchReal(s, "1d");
    }

    streamManager.onTick((t) => this.onTick(t));
    this.analyzeTimer = setInterval(() => this.publishAll(), 4000);
    setTimeout(() => this.publishAll(), 1200);
  }

  private async fetchReal(symbol: SymbolId, interval: Interval) {
    try {
      const res = await fetch(
        `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${HISTORY}`,
        { signal: AbortSignal.timeout(5000) },
      );
      if (!res.ok) return;
      const raw: unknown[][] = await res.json();
      const candles: Candle[] = raw.map((k) => ({
        time: Number(k[0]),
        open: parseFloat(String(k[1])),
        high: parseFloat(String(k[2])),
        low: parseFloat(String(k[3])),
        close: parseFloat(String(k[4])),
        volume: parseFloat(String(k[5])),
      }));
      if (candles.length > 20) this.candles.set(this.key(symbol, interval), candles);
    } catch { /* offline sandbox — synthetic seed stays */ }
  }

  private synthSeed(symbol: SymbolId, interval: Interval): Candle[] {
    const ms = INTERVAL_MS[interval];
    const now = Date.now();
    const anchor = Math.floor(now / ms) * ms;
    const base = SYMBOL_META[symbol].base;
    const out: Candle[] = [];
    let price = base * (0.9 + this.seededRand(symbol.length * 7 + interval.length) * 0.08);
    for (let i = HISTORY - 1; i >= 0; i--) {
      const t = anchor - i * ms;
      const vol = base * 0.004 * Math.sqrt(ms / 60000) * 0.18;
      const drift = Math.sin(t / (ms * 30)) * vol * 0.6;
      const open = price;
      const close = Math.max(base * 0.3, open + drift + (this.seededRand(t / ms) - 0.5) * vol * 2);
      const high = Math.max(open, close) + this.seededRand(t / ms + 1) * vol * 0.7;
      const low = Math.min(open, close) - this.seededRand(t / ms + 2) * vol * 0.7;
      out.push({ time: t, open, high, low, close, volume: 50 + this.seededRand(t) * 400 });
      price = close;
    }
    // converge the final candle toward the live base price
    const last = out[out.length - 1];
    const ratio = base / last.close;
    out.forEach((c) => { c.open *= ratio; c.high *= ratio; c.low *= ratio; c.close *= ratio; });
    return out;
  }

  private seededRand(seed: number) {
    const x = Math.sin(seed * 12.9898) * 43758.5453;
    return x - Math.floor(x);
  }

  private onTick(t: Tick) {
    for (const iv of ALL_INTERVALS) {
      const ms = INTERVAL_MS[iv];
      const bucket = Math.floor(t.ts / ms) * ms;
      const arr = this.candles.get(this.key(t.symbol, iv));
      if (!arr || arr.length === 0) continue;
      const last = arr[arr.length - 1];
      if (bucket > last.time) {
        arr.push({ time: bucket, open: t.price, high: t.price, low: t.price, close: t.price, volume: t.qty });
        if (arr.length > HISTORY + 10) arr.splice(0, arr.length - HISTORY);
      } else {
        last.close = t.price;
        last.high = Math.max(last.high, t.price);
        last.low = Math.min(last.low, t.price);
        last.volume += t.qty;
      }
    }
  }

  // ─── Indicators ────────────────────────────────────────────────────────────

  private ema(values: number[], period: number): number {
    if (values.length === 0) return 0;
    const k = 2 / (period + 1);
    let e = values[0];
    for (let i = 1; i < values.length; i++) e = values[i] * k + e * (1 - k);
    return e;
  }

  private emaSeries(values: number[], period: number): number[] {
    const k = 2 / (period + 1);
    const out: number[] = [];
    let e = values[0] ?? 0;
    values.forEach((v, i) => { e = i === 0 ? v : v * k + e * (1 - k); out.push(e); });
    return out;
  }

  private rsi(closes: number[], period = 14): number {
    if (closes.length < period + 1) return 50;
    let gains = 0, losses = 0;
    for (let i = closes.length - period; i < closes.length; i++) {
      const d = closes[i] - closes[i - 1];
      if (d > 0) gains += d; else losses -= d;
    }
    if (losses === 0) return 100;
    const rs = gains / losses;
    return 100 - 100 / (1 + rs);
  }

  private atr(candles: Candle[], period = 14): number {
    if (candles.length < 2) return 0;
    const trs: number[] = [];
    for (let i = Math.max(1, candles.length - period); i < candles.length; i++) {
      const c = candles[i], p = candles[i - 1];
      trs.push(Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close)));
    }
    return trs.reduce((a, b) => a + b, 0) / (trs.length || 1);
  }

  private adx(candles: Candle[]): number {
    // simplified directional strength proxy
    if (candles.length < 20) return 20;
    const closes = candles.map((c) => c.close);
    const e9 = this.emaSeries(closes, 9);
    const e50 = this.emaSeries(closes, 50);
    const sep = Math.abs(e9[e9.length - 1] - e50[e50.length - 1]) / closes[closes.length - 1];
    const atrP = this.atr(candles) / closes[closes.length - 1];
    return Math.min(60, 10 + sep * 4200 + atrP * 900);
  }

  analyzeInterval(symbol: SymbolId, interval: Interval): IntervalAnalysis | null {
    const candles = this.getCandles(symbol, interval);
    if (candles.length < 30) return null;
    const closes = candles.map((c) => c.close);
    const last = closes[closes.length - 1];
    const ema9 = this.ema(closes.slice(-60), 9);
    const ema20 = this.ema(closes.slice(-80), 20);
    const ema50 = this.ema(closes, 50);
    const rsi = this.rsi(closes);
    const atr = this.atr(candles);
    const adx = this.adx(candles);

    // VWAP over window
    let pv = 0, vv = 0;
    candles.slice(-40).forEach((c) => {
      const tp = (c.high + c.low + c.close) / 3;
      pv += tp * c.volume; vv += c.volume;
    });
    const vwap = vv > 0 ? pv / vv : last;

    // Bollinger width
    const win = closes.slice(-20);
    const mean = win.reduce((a, b) => a + b, 0) / win.length;
    const sd = Math.sqrt(win.reduce((a, b) => a + (b - mean) ** 2, 0) / win.length);
    const bbWidth = (sd * 4 / mean) * 100;

    const vols = candles.slice(-20).map((c) => c.volume);
    const avgVol = vols.reduce((a, b) => a + b, 0) / vols.length;
    const volumeRatio = avgVol > 0 ? candles[candles.length - 1].volume / avgVol : 1;

    // composite score -1..1
    let score = 0;
    score += ema9 > ema20 ? 0.25 : -0.25;
    score += ema20 > ema50 ? 0.2 : -0.2;
    score += last > vwap ? 0.15 : -0.15;
    score += rsi > 55 ? 0.2 : rsi < 45 ? -0.2 : 0;
    score += last > ema50 ? 0.1 : -0.1;
    score += Math.max(-0.1, Math.min(0.1, ((last - closes[closes.length - 6]) / last) * 14));
    score = Math.max(-1, Math.min(1, score));

    return {
      interval, score, rsi, ema9, ema20, ema50, vwap,
      atr, atrPct: (atr / last) * 100, adx, bbWidth, volumeRatio, lastClose: last,
    };
  }

  snapshot(symbol: SymbolId): MtfSnapshot {
    const intervals: MtfSnapshot["intervals"] = {};
    for (const iv of ALL_INTERVALS) {
      const a = this.analyzeInterval(symbol, iv);
      if (a) intervals[iv] = a;
    }
    const avg = (ivs: Interval[]) => {
      const vals = ivs.map((i) => intervals[i]?.score ?? 0);
      return vals.reduce((a, b) => a + b, 0) / (vals.length || 1);
    };
    const microScore = avg(["1m", "3m", "5m", "15m"]);
    const mediumScore = avg(["30m", "1h", "2h"]);
    const macroScore = avg(["4h", "6h", "8h", "12h", "1d", "1w"]);
    const confluence = Math.round(((microScore * 0.35 + mediumScore * 0.3 + macroScore * 0.35) * 100));

    // Top-down gatekeeper: micro must align with macro direction
    const aligned =
      Math.sign(microScore) === Math.sign(macroScore) &&
      Math.abs(macroScore) > 0.12 && Math.abs(microScore) > 0.12 &&
      Math.sign(mediumScore) === Math.sign(macroScore);
    const direction: TradeSide | null = !aligned ? null : macroScore > 0 ? "LONG" : "SHORT";

    return { symbol, updatedAt: Date.now(), intervals, microScore, mediumScore, macroScore, confluence, aligned, direction };
  }

  private publishAll() {
    const st = useTradingStore.getState();
    for (const s of SYMBOLS) st.setMtf(s, this.snapshot(s));
  }
}

export const multiTimeframeEngine = new MultiTimeframeEngine();
