/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';
import { Book, BookChapter, BookFileAttachment } from '../types';

export interface ProcessedBookFile {
  title: string;
  author: string;
  totalPages: number;
  pagesRead: number;
  progress: number;
  sampleContent: string;
  chapters: BookChapter[];
  coverUrl?: string;
  description?: string;
  genres?: string[];
  tags?: string[];
  fileAttachment?: BookFileAttachment;
}

/**
 * Splits text into realistic reading pages (approx 1,200 - 1,500 characters per page).
 */
export function paginateContent(text: string, charsPerPage = 1400): string[] {
  const cleaned = text.replace(/\r\n/g, '\n').trim();
  if (!cleaned) return [];

  // Check if text already has explicit page delimiters
  if (cleaned.includes('---PAGE---')) {
    const pages = cleaned
      .split(/\n\s*---PAGE---\s*\n/)
      .map((p) => p.trim())
      .filter(Boolean);
    if (pages.length > 0) return pages;
  }

  const paragraphs = cleaned.split(/\n\n+/);
  const pages: string[] = [];
  let currentPage = '';

  for (const para of paragraphs) {
    const trimmedPara = para.trim();
    if (!trimmedPara) continue;

    if (currentPage.length + trimmedPara.length > charsPerPage && currentPage.length > 300) {
      pages.push(currentPage.trim());
      currentPage = trimmedPara;
    } else {
      currentPage = currentPage ? `${currentPage}\n\n${trimmedPara}` : trimmedPara;
    }
  }

  if (currentPage.trim()) {
    pages.push(currentPage.trim());
  }

  return pages.length > 0 ? pages : [cleaned];
}

/**
 * Process an EPUB file using JSZip to parse container.xml, .opf metadata, manifest, spine and chapters.
 */
export async function processEpubFile(file: File): Promise<ProcessedBookFile> {
  const zip = new JSZip();
  const zipData = await zip.loadAsync(file);

  const baseName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ').trim();
  let title = baseName;
  let author = 'Autor Desconocido';
  let description = '';
  let coverUrl: string | undefined = undefined;

  // 1. Locate rootfile from META-INF/container.xml
  let rootfilePath = '';
  const containerXml = await zipData.file('META-INF/container.xml')?.async('text');
  if (containerXml) {
    const match = containerXml.match(/full-path="([^"]+)"/i);
    if (match) rootfilePath = match[1];
  }

  // Fallback to searching for .opf file directly
  if (!rootfilePath) {
    const opfFiles = Object.keys(zipData.files).filter((p) => p.toLowerCase().endsWith('.opf'));
    if (opfFiles.length > 0) rootfilePath = opfFiles[0];
  }

  const chapters: BookChapter[] = [];
  const rawChapterTexts: { title: string; text: string }[] = [];

  if (rootfilePath) {
    const opfText = await zipData.file(rootfilePath)?.async('text');
    if (opfText) {
      const parser = new DOMParser();
      const opfDoc = parser.parseFromString(opfText, 'application/xml');

      // Metadata
      const titleEl = opfDoc.querySelector('title');
      if (titleEl?.textContent) title = titleEl.textContent.trim();

      const creatorEl = opfDoc.querySelector('creator');
      if (creatorEl?.textContent) author = creatorEl.textContent.trim();

      const descEl = opfDoc.querySelector('description');
      if (descEl?.textContent) description = descEl.textContent.trim();

      // Extract Cover Image if present
      const basePath = rootfilePath.includes('/')
        ? rootfilePath.substring(0, rootfilePath.lastIndexOf('/') + 1)
        : '';

      const items = Array.from(opfDoc.querySelectorAll('manifest > item'));
      const manifestMap = new Map<string, { href: string; mediaType: string }>();
      items.forEach((item) => {
        const id = item.getAttribute('id');
        const href = item.getAttribute('href');
        const mediaType = item.getAttribute('media-type') || '';
        if (id && href) manifestMap.set(id, { href, mediaType });
      });

      // Find cover item
      let coverHref = '';
      const coverItem = items.find(
        (it) =>
          it.getAttribute('properties')?.includes('cover-image') ||
          it.getAttribute('id')?.toLowerCase().includes('cover')
      );
      if (coverItem) {
        coverHref = coverItem.getAttribute('href') || '';
      }

      if (coverHref) {
        const fullCoverPath = basePath + coverHref;
        const coverZipFile = zipData.file(fullCoverPath) || zipData.file(coverHref);
        if (coverZipFile) {
          const base64 = await coverZipFile.async('base64');
          const ext = coverHref.toLowerCase().endsWith('.png') ? 'png' : 'jpeg';
          coverUrl = `data:image/${ext};base64,${base64}`;
        }
      }

      // Reading order from spine
      const spineItems = Array.from(opfDoc.querySelectorAll('spine > itemref'));
      for (let i = 0; i < spineItems.length; i++) {
        const idref = spineItems[i].getAttribute('idref');
        if (!idref) continue;
        const manifestEntry = manifestMap.get(idref);
        if (!manifestEntry) continue;

        const href = manifestEntry.href;
        const fullPath = basePath + href;
        const chapFile = zipData.file(fullPath) || zipData.file(href);

        if (chapFile) {
          const chapHtml = await chapFile.async('text');
          const chapDoc = parser.parseFromString(chapHtml, 'text/html');

          // Remove script and style tags
          chapDoc.querySelectorAll('script, style').forEach((el) => el.remove());

          // Extract Chapter Title
          const heading = chapDoc.querySelector('h1, h2, h3, h4, title')?.textContent?.trim();
          const chapTitle = heading || `Capítulo ${rawChapterTexts.length + 1}`;

          // Extract text content
          const text = chapDoc.body ? chapDoc.body.innerText || chapDoc.body.textContent || '' : '';
          const cleanedText = text.replace(/\s+/g, ' ').trim();

          if (cleanedText.length > 50) {
            rawChapterTexts.push({
              title: chapTitle,
              text: cleanedText,
            });
          }
        }
      }
    }
  }

  // If no chapters were extracted via spine, scan for html files directly
  if (rawChapterTexts.length === 0) {
    const htmlFiles = Object.keys(zipData.files).filter(
      (p) =>
        (p.toLowerCase().endsWith('.xhtml') || p.toLowerCase().endsWith('.html')) &&
        !p.toLowerCase().includes('toc') &&
        !p.toLowerCase().includes('nav')
    );

    for (let i = 0; i < htmlFiles.length; i++) {
      const fileData = await zipData.file(htmlFiles[i])?.async('text');
      if (fileData) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(fileData, 'text/html');
        doc.querySelectorAll('script, style').forEach((el) => el.remove());
        const heading = doc.querySelector('h1, h2, h3, title')?.textContent?.trim();
        const chapText = (doc.body?.innerText || doc.body?.textContent || '').replace(/\s+/g, ' ').trim();
        if (chapText.length > 50) {
          rawChapterTexts.push({
            title: heading || `Sección ${i + 1}`,
            text: chapText,
          });
        }
      }
    }
  }

  // Build paginated content and structured chapters
  const allPages: string[] = [];
  let runningPageCount = 1;

  if (rawChapterTexts.length > 0) {
    rawChapterTexts.forEach((c) => {
      const chapPages = paginateContent(c.text);
      chapters.push({
        id: 'chap-' + Math.random().toString(36).substring(2, 9),
        title: c.title,
        page: runningPageCount,
        pageStart: runningPageCount,
      });
      allPages.push(...chapPages);
      runningPageCount += chapPages.length;
    });
  } else {
    // Fallback template
    allPages.push(
      `Capítulo 1: Comienzo\n\nBienvenido a "${title}". El archivo EPUB ha sido procesado e integrado a tu biblioteca digital.\n\nPuedes comenzar tu sesión de lectura, navegar página por página tocando los extremos de la pantalla y guardar tus frases favoritas.`
    );
    chapters.push({
      id: 'chap-1',
      title: 'Capítulo 1',
      page: 1,
      pageStart: 1,
    });
  }

  const totalPages = Math.max(1, allPages.length);

  return {
    title,
    author,
    description: description || `Lectura completa importada desde archivo EPUB: ${file.name}.`,
    coverUrl,
    totalPages,
    pagesRead: 0,
    progress: 0, // CRITICAL: NEVER 100% by default!
    sampleContent: allPages.join('\n\n---PAGE---\n\n'),
    chapters,
    fileAttachment: {
      name: file.name,
      size: file.size,
      type: 'epub',
      uploadedAt: new Date().toISOString(),
    },
  };
}

/**
 * Process a PDF file by analyzing header, counting pages, extracting metadata and text.
 */
export async function processPdfFile(file: File): Promise<ProcessedBookFile> {
  const baseName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ').trim();
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);

  // Convert first ~64KB and last ~64KB to text to extract metadata and page count
  const headLength = Math.min(bytes.length, 65536);
  const tailOffset = Math.max(0, bytes.length - 65536);
  const decoder = new TextDecoder('latin1');
  const headStr = decoder.decode(bytes.slice(0, headLength));
  const tailStr = decoder.decode(bytes.slice(tailOffset));
  const fullStr = bytes.length < 5000000 ? decoder.decode(bytes) : headStr + '\n' + tailStr;

  // 1. Extract Real Page Count from PDF Catalog: /Type /Pages /Count N
  let totalPages = 0;
  const countMatches = fullStr.match(/\/Count\s+(\d+)/g);
  if (countMatches) {
    for (const m of countMatches) {
      const numMatch = m.match(/\d+/);
      if (numMatch) {
        const val = parseInt(numMatch[0], 10);
        if (val > totalPages && val < 5000) {
          totalPages = val;
        }
      }
    }
  }

  // Fallback: count individual /Type /Page objects
  if (totalPages === 0) {
    const pageObjMatches = fullStr.match(/\/Type\s*\/Page[^s]/g);
    if (pageObjMatches) {
      totalPages = pageObjMatches.length;
    }
  }

  // Default estimate based on file size if page markers were compressed
  if (totalPages === 0) {
    totalPages = Math.max(1, Math.round(file.size / (80 * 1024))); // ~80KB per PDF page
  }

  // 2. Extract Title and Author from PDF Metadata
  let title = baseName;
  let author = 'Autor Desconocido';

  const titleMatch = fullStr.match(/\/Title\s*\(([^)]+)\)/i);
  if (titleMatch && titleMatch[1].trim()) {
    title = titleMatch[1].trim();
  }

  const authorMatch = fullStr.match(/\/Author\s*\(([^)]+)\)/i);
  if (authorMatch && authorMatch[1].trim()) {
    author = authorMatch[1].trim();
  }

  // 3. Extract visible text fragments from PDF streams
  const textFragments: string[] = [];
  const textPattern = /\(([^)]{3,})\)\s*T[jJ]/g;
  let match: RegExpExecArray | null;
  while ((match = textPattern.exec(fullStr)) !== null && textFragments.length < 1000) {
    const fragment = match[1].replace(/\\([()\\])/g, '$1').trim();
    if (fragment.length > 10 && !fragment.includes('\x00')) {
      textFragments.push(fragment);
    }
  }

  // 4. Generate structured pages and chapters
  const pages: string[] = [];
  const chapters: BookChapter[] = [];
  const pagesCount = Math.max(1, totalPages);

  // Group fragments or create structured pages matching totalPages
  const fragmentsPerPage = Math.max(2, Math.ceil(textFragments.length / pagesCount));

  for (let i = 0; i < pagesCount; i++) {
    const pageNum = i + 1;
    const pageFragments = textFragments.slice(i * fragmentsPerPage, (i + 1) * fragmentsPerPage);

    let pageText = '';
    if (pageFragments.length > 0) {
      pageText = pageFragments.join('\n\n');
    } else {
      pageText = `Página ${pageNum}\n\nDocumento: "${title}"\nAutor: ${author}\n\nLectura procesada desde archivo PDF (${pagesCount} páginas totales).\n\nPuedes navegar tocando el lateral derecho para avanzar de página, o el izquierdo para retroceder. Al mantener presionado un fragmento de texto se desplegará el menú contextual para subrayar, añadir notas, stickers y registrar tus frases favoritas.`;
    }

    pages.push(pageText);

    // Create a chapter marker every ~20 pages or for page 1
    if (i === 0 || i % 20 === 0) {
      const chapNum = Math.floor(i / 20) + 1;
      chapters.push({
        id: `chap-${chapNum}`,
        title: i === 0 ? 'Inicio / Capítulo 1' : `Capítulo ${chapNum}`,
        page: pageNum,
        pageStart: pageNum,
      });
    }
  }

  return {
    title,
    author,
    description: `Documento PDF importado: "${file.name}" (${pagesCount} páginas detectadas).`,
    totalPages: pagesCount,
    pagesRead: 0,
    progress: 0, // CRITICAL: NEVER 100% by default!
    sampleContent: pages.join('\n\n---PAGE---\n\n'),
    chapters,
    fileAttachment: {
      name: file.name,
      size: file.size,
      type: 'pdf',
      uploadedAt: new Date().toISOString(),
    },
  };
}
