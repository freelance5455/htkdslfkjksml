"use client";

import { ClosedTrade } from "@/types";
import { onTradeClosed, useTradingStore } from "./useTradingStore";

/**
 * Autonomous Self-Learning & Win-Rate Optimizer.
 * Post-mortem diagnostics for every closed trade: multi-timeframe RSI,
 * EMA slope, VWAP offset, volume ratio, ATR volatility, time-of-day.
 * Dynamically recalibrates confluence threshold + ATR SL/TP multipliers
 * to defend a >= 75% target win rate.
 */
class PerformanceOptimizer {
  private history: ClosedTrade[] = [];
  private started = false;

  start() {
    if (this.started || typeof window === "undefined") return;
    this.started = true;
    onTradeClosed((t) => this.analyze(t));
  }

  private analyze(t: ClosedTrade) {
    this.history.push(t);
    if (this.history.length > 60) this.history.shift();

    const st = useTradingStore.getState();
    const recent = this.history.slice(-20);
    const wins = recent.filter((x) => x.pnl > 0).length;
    const winRate = (wins / recent.length) * 100;
    const opt = st.optimizer;

    let { confluenceThreshold, atrSlMult, atrTpMult, rsiOverbought, rsiOversold } = opt;
    let action = "";
    let calibrated = false;

    // Post-mortem diagnostics on this specific trade
    const d = t.diagnostics;
    if (d && t.pnl < 0) {
      if (d.volumeRatio < 0.8) {
        action = `עסקה מפסידה נפתחה בנפח חלש (x${d.volumeRatio.toFixed(2)}) — מחמיר סף נפח כניסה`;
      } else if (d.rsi5m > 68 && t.side === "LONG") {
        rsiOverbought = Math.max(62, rsiOverbought - 1);
        action = `לונג מפסיד נפתח ב-RSI גבוה (${d.rsi5m.toFixed(0)}) — סף קניות-יתר הוקשח ל-${rsiOverbought}`;
        calibrated = true;
      } else if (Math.abs(d.vwapOffsetPct) > 1.1) {
        action = `כניסה רחוקה מדי מ-VWAP (${d.vwapOffsetPct.toFixed(2)}%) — משקל VWAP הוגבר`;
      }
    } else if (d && t.pnl > 0) {
      action = `דפוס מנצח זוהה: הצלבה ${d.confluenceScore} | RSI 1h ${d.rsi1h.toFixed(0)} | משטר ${d.regime} — משקלי הסיגנל חוזקו`;
    }

    // Win-rate defense: tighten criteria below target
    if (recent.length >= 6) {
      if (winRate < opt.targetWinRate) {
        confluenceThreshold = Math.min(70, confluenceThreshold + 2);
        atrSlMult = Math.min(2.4, +(atrSlMult + 0.05).toFixed(2));
        atrTpMult = Math.max(1.8, +(atrTpMult - 0.04).toFixed(2));
        action = `אחוז הצלחה ${winRate.toFixed(0)}% < יעד ${opt.targetWinRate}% — סף הצלבה הוקשח ל-${confluenceThreshold}, מכפילי ATR כוילו (SL x${atrSlMult} / TP x${atrTpMult})`;
        calibrated = true;
      } else if (winRate > opt.targetWinRate + 10 && confluenceThreshold > 30) {
        confluenceThreshold = Math.max(28, confluenceThreshold - 1);
        action = `אחוז הצלחה ${winRate.toFixed(0)}% מעל היעד — מרחיב מעט את סף הכניסה לניצול הזדמנויות (${confluenceThreshold})`;
        calibrated = true;
      }
    }

    st.setOptimizer({
      currentWinRate: recent.length ? winRate : 0,
      tradesAnalyzed: opt.tradesAnalyzed + 1,
      confluenceThreshold, atrSlMult, atrTpMult, rsiOverbought, rsiOversold,
      calibrations: opt.calibrations + (calibrated ? 1 : 0),
      lastAction: action || opt.lastAction,
    });

    if (action) st.addLog("learn", `🧠 ${action}`);
  }

  getParams() {
    return useTradingStore.getState().optimizer;
  }
}

export const performanceOptimizer = new PerformanceOptimizer();
