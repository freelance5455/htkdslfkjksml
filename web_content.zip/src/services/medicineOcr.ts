/**
 * High-Accuracy Medicine OCR & Verification Engine
 * Enforces zero-guessing, super-resolution preprocessed multi-pass scanning,
 * strict >=95% fuzzy similarity thresholding, and verified database lookups.
 */

import { createWorker } from 'tesseract.js';
import { preprocessMedicineImage } from './medicinePreprocessor';
import { fetchVerifiedMedicineInfo, VerifiedMedicineInfo } from './medicineDatabase';

export interface IdentificationResult {
  success: boolean;
  medicine: VerifiedMedicineInfo | null;
  errorMessage?: string;
}

export type OCRProgressCallback = (progressPercent: number, statusText: string) => void;

/**
 * Calculates normalized Levenshtein Similarity Score between two strings (0.0 to 1.0).
 */
export function calculateSimilarityScore(str1: string, str2: string): number {
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();
  if (s1 === s2) return 1.0;
  const len1 = s1.length;
  const len2 = s2.length;
  if (len1 === 0 || len2 === 0) return 0.0;

  const matrix: number[][] = [];
  for (let i = 0; i <= len1; i++) matrix[i] = [i];
  for (let j = 0; j <= len2; j++) matrix[0][j] = j;

  for (let i = 1; i <= len1; i++) {
    for (let j = 1; j <= len2; j++) {
      const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }

  const distance = matrix[len1][len2];
  const maxLen = Math.max(len1, len2);
  return 1.0 - distance / maxLen;
}

const STRICT_CONFIDENCE_THRESHOLD = 0.95; // 95% similarity required

const UNIDENTIFIED_ERROR_MSG =
  'Medicine could not be identified with sufficient confidence.\nPlease capture a clearer image or scan the front side of the medicine.';

/**
 * Performs high-accuracy, zero-guessing medicine identification.
 */
export async function identifyMedicineFromImage(
  imageDataUrl: string,
  onProgress?: OCRProgressCallback
): Promise<IdentificationResult> {
  console.log('[Medicine OCR Engine] Initiating high-accuracy multi-pass recognition pipeline...');

  if (onProgress) onProgress(15, 'Enhancing image, super-resolving & sharpening text...');
  const preprocessRes = await preprocessMedicineImage(imageDataUrl);

  if (preprocessRes.isBlurry && preprocessRes.blurScore < 2) {
    return {
      success: false,
      medicine: null,
      errorMessage: UNIDENTIFIED_ERROR_MSG,
    };
  }

  if (onProgress) onProgress(35, 'Performing multi-pass OCR text extraction...');

  try {
    const worker = await createWorker('eng', 1, {
      logger: (m) => {
        if (m.status === 'recognizing text' && onProgress) {
          const pct = 35 + Math.round(m.progress * 45);
          onProgress(pct, 'Extracting visible package text...');
        }
      },
    });

    // Run OCR over the primary enhanced pass and secondary passes if needed
    let extractedTextCombined = '';

    for (let i = 0; i < preprocessRes.passes.length; i++) {
      const pass = preprocessRes.passes[i];
      if (i > 0 && extractedTextCombined.length > 50) {
        // Sufficient text acquired from primary pass
        break;
      }
      const ret = await worker.recognize(pass.dataUrl);
      if (ret.data && ret.data.text) {
        extractedTextCombined += ' ' + ret.data.text;
      }
    }

    await worker.terminate();

    const fullText = extractedTextCombined.trim();
    if (!fullText || fullText.length < 3) {
      console.warn('[Medicine OCR Engine] Extracted text length insufficient.');
      return {
        success: false,
        medicine: null,
        errorMessage: UNIDENTIFIED_ERROR_MSG,
      };
    }

    if (onProgress) onProgress(85, 'Verifying extracted text against database (>95% confidence threshold)...');

    const lowerFullText = fullText.toLowerCase();
    const cleanTokens = fullText
      .replace(/[^a-zA-Z0-9\s-]/g, ' ')
      .split(/\s+/)
      .map((t) => t.trim().toLowerCase())
      .filter((t) => t.length >= 3);

    // Common non-medicine generic words to filter out
    const IGNORED_WORDS = new Set([
      'tablet', 'tablets', 'capsule', 'capsules', 'mg', 'ml', 'mcg', 'gm', 'ip', 'bp', 'usp',
      'batch', 'exp', 'mfg', 'date', 'mrp', 'incl', 'taxes', 'manufactured', 'marketed',
      'store', 'dry', 'place', 'keep', 'reach', 'children', 'prescription', 'schedule', 'warning',
      'caution', 'dosage', 'directed', 'physician', 'pharma', 'pharmaceuticals', 'ltd', 'pvt'
    ]);

    // 1. Direct Exact Substring Match against Verified Database
    // Check brand names & active keys (e.g. "dolo 650", "dolo", "crocin", "combiflam", "pantocid", "azithral", "paracetamol")
    const knownKeys = [
      'dolo 650', 'dolo', 'crocin', 'combiflam', 'calpol', 'pantocid', 'pan 40', 'pan',
      'shelcal', 'telma', 'azithral', 'montair', 'asthalin', 'omez', 'allegra', 'becosules',
      'zincovit', 'rantac', 'eldoper', 'supradyn', 'limcee', 'ciplox', 'meftal', 'taxim',
      'clavam', 'vomistop', 'deriphyllin', 'disprin', 'digene', 'gelusil', 'glycomet', 'avil',
      'saridon', 'voveran', 'okacet', 'sinarest', 'liv 52', 'liv52', 'lipitor', 'atorvastatin',
      'amoxicillin', 'augmentin', 'paracetamol', 'tylenol', 'ibuprofen', 'advil', 'metformin',
      'omeprazole', 'lisinopril', 'amlodipine', 'cetirizine', 'zyrtec', 'azithromycin',
      'ciprofloxacin', 'pantoprazole', 'losartan', 'aspirin'
    ];

    for (const key of knownKeys) {
      if (lowerFullText.includes(key)) {
        const verified = await fetchVerifiedMedicineInfo(key);
        if (verified) {
          console.log(`[Medicine OCR Engine] Exact match verified: ${verified.medicineName} (Confidence: 100%)`);
          return {
            success: true,
            medicine: verified,
          };
        }
      }
    }

    // 2. Strict Levenshtein Fuzzy Similarity Match (Threshold >= 95%)
    let bestMatchKey: string | null = null;
    let highestSimilarity = 0;

    for (const token of cleanTokens) {
      if (IGNORED_WORDS.has(token)) continue;

      for (const key of knownKeys) {
        // Skip tiny key comparisons if lengths differ significantly
        if (Math.abs(token.length - key.length) > 3) continue;

        const score = calculateSimilarityScore(token, key);
        if (score >= STRICT_CONFIDENCE_THRESHOLD && score > highestSimilarity) {
          highestSimilarity = score;
          bestMatchKey = key;
        }
      }
    }

    if (bestMatchKey && highestSimilarity >= STRICT_CONFIDENCE_THRESHOLD) {
      const verified = await fetchVerifiedMedicineInfo(bestMatchKey);
      if (verified) {
        console.log(
          `[Medicine OCR Engine] High-confidence fuzzy match: ${verified.medicineName} (Similarity: ${(
            highestSimilarity * 100
          ).toFixed(1)}%)`
        );
        return {
          success: true,
          medicine: verified,
        };
      }
    }

    // Confidence below 95% -> DO NOT GUESS!
    console.warn(
      `[Medicine OCR Engine] Best similarity score (${(highestSimilarity * 100).toFixed(
        1
      )}%) is below strict 95% threshold. Refusing to guess.`
    );

    return {
      success: false,
      medicine: null,
      errorMessage: UNIDENTIFIED_ERROR_MSG,
    };
  } catch (err) {
    console.error('[Medicine OCR Engine] OCR processing error:', err);
    return {
      success: false,
      medicine: null,
      errorMessage: UNIDENTIFIED_ERROR_MSG,
    };
  }
}

