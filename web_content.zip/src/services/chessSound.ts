/**
 * Sound System Utility for Chess Events
 * Triggers specific audio effects for piece movement, capturing, check,
 * checkmate, castling, pawn promotion, and illegal moves using the existing sound service.
 */

import { Move } from 'chess.js';
import { sound } from './sound';
import { PieceType } from '../types/chess';

export type ChessAudioEventType =
  | 'move'
  | 'capture'
  | 'check'
  | 'checkmate'
  | 'stalemate'
  | 'castle'
  | 'promotion'
  | 'illegal'
  | 'select'
  | 'draw';

export interface ChessAudioEvent {
  type: ChessAudioEventType;
  timestamp: number;
  from?: string;
  to?: string;
  piece?: PieceType | string;
  captured?: PieceType | string;
  san?: string;
}

export interface MoveAudioOptions {
  inCheck?: boolean;
  isCheckmate?: boolean;
  isStalemate?: boolean;
  isDraw?: boolean;
  isCastle?: boolean;
  isPromotion?: boolean;
  captured?: boolean | string;
}

type AudioEventListener = (event: ChessAudioEvent) => void;

class ChessSoundSystem {
  private listeners: Set<AudioEventListener> = new Set();

  /**
   * Triggers the appropriate chess audio effect for a move.
   * Prioritizes high-impact events: Checkmate > Check > Castle / Promotion > Capture > Standard Move.
   *
   * @param move - The executed chess move (chess.js Move or MoveRecord)
   * @param options - Additional board context (e.g. game.inCheck(), game.isCheckmate())
   * @returns The resolved ChessAudioEventType triggered
   */
  public triggerMoveAudio(
    move: {
      san?: string;
      from?: string;
      to?: string;
      piece?: string;
      captured?: string | null;
      promotion?: string;
      flags?: string;
    } | null | undefined,
    options?: MoveAudioOptions
  ): ChessAudioEventType {
    const isCheckmate = options?.isCheckmate || move?.san?.includes('#');
    const inCheck = options?.inCheck || move?.san?.includes('+');
    const isCastle =
      options?.isCastle ||
      move?.san === 'O-O' ||
      move?.san === 'O-O-O' ||
      move?.flags?.includes('k') ||
      move?.flags?.includes('q');
    const isPromotion = Boolean(options?.isPromotion || move?.promotion || move?.san?.includes('='));
    const isCapture = Boolean(options?.captured || move?.captured || move?.san?.includes('x'));
    const isDraw = options?.isDraw || options?.isStalemate;

    let eventType: ChessAudioEventType = 'move';

    if (isCheckmate) {
      eventType = 'checkmate';
      sound.playVictory();
    } else if (inCheck) {
      eventType = 'check';
      sound.playCheck();
    } else if (isCastle) {
      eventType = 'castle';
      sound.playCastle();
    } else if (isPromotion) {
      eventType = 'promotion';
      sound.playPromotion();
    } else if (isCapture) {
      eventType = 'capture';
      sound.playCapture();
    } else if (isDraw) {
      eventType = 'stalemate';
      sound.playDraw();
    } else {
      eventType = 'move';
      sound.playMove();
    }

    this.notifyListeners({
      type: eventType,
      timestamp: Date.now(),
      from: move?.from,
      to: move?.to,
      piece: move?.piece,
      captured: move?.captured || undefined,
      san: move?.san,
    });

    return eventType;
  }

  /**
   * Triggers a specific audio event directly.
   */
  public trigger(eventType: ChessAudioEventType, eventData?: Partial<ChessAudioEvent>): void {
    switch (eventType) {
      case 'move':
        sound.playMove();
        break;
      case 'capture':
        sound.playCapture();
        break;
      case 'check':
        sound.playCheck();
        break;
      case 'checkmate':
        sound.playVictory();
        break;
      case 'stalemate':
      case 'draw':
        sound.playDraw();
        break;
      case 'castle':
        sound.playCastle();
        break;
      case 'promotion':
        sound.playPromotion();
        break;
      case 'illegal':
        sound.playIllegal();
        break;
      case 'select':
        sound.playClick();
        break;
    }

    this.notifyListeners({
      type: eventType,
      timestamp: Date.now(),
      ...eventData,
    });
  }

  /**
   * Specialized trigger for piece movement audio
   */
  public playPieceMove(isCastle = false): void {
    if (isCastle) {
      this.trigger('castle');
    } else {
      this.trigger('move');
    }
  }

  /**
   * Specialized trigger for piece capture audio
   */
  public playPieceCapture(capturedPiece?: string): void {
    this.trigger('capture', { captured: capturedPiece });
  }

  /**
   * Specialized trigger for check audio
   */
  public playCheck(): void {
    this.trigger('check');
  }

  /**
   * Specialized trigger for checkmate audio
   */
  public playCheckmate(): void {
    this.trigger('checkmate');
  }

  /**
   * Specialized trigger for illegal move warning buzzer
   */
  public playIllegalMove(): void {
    this.trigger('illegal');
  }

  /**
   * Specialized trigger for piece selection / square tap
   */
  public playPieceSelect(): void {
    this.trigger('select');
  }

  /**
   * Specialized trigger for draw / stalemate agreement
   */
  public playDraw(): void {
    this.trigger('draw');
  }

  /**
   * Toggle or set audio mute status
   */
  public setSoundEnabled(enabled: boolean): void {
    sound.setSoundEnabled(enabled);
  }

  public isSoundEnabled(): boolean {
    return sound.isSoundEnabled();
  }

  public setVolume(volume: number): void {
    sound.setSfxVolume(volume);
  }

  /**
   * Subscribe to chess audio events (useful for haptic feedback or visual audio meters)
   */
  public addEventListener(listener: AudioEventListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners(event: ChessAudioEvent): void {
    this.listeners.forEach((listener) => {
      try {
        listener(event);
      } catch (err) {
        console.warn('Chess sound event listener error:', err);
      }
    });
  }
}

export const chessSound = new ChessSoundSystem();

// Convenient standalone helper functions
export const triggerMoveAudio = (
  move: Move | { san?: string; from?: string; to?: string; captured?: string | null; promotion?: string } | null | undefined,
  options?: MoveAudioOptions
) => chessSound.triggerMoveAudio(move as any, options);

export const playPieceMoveSound = (isCastle = false) => chessSound.playPieceMove(isCastle);
export const playPieceCaptureSound = (capturedPiece?: string) => chessSound.playPieceCapture(capturedPiece);
export const playCheckSound = () => chessSound.playCheck();
export const playCheckmateSound = () => chessSound.playCheckmate();
export const playIllegalMoveSound = () => chessSound.playIllegalMove();
export const playPieceSelectSound = () => chessSound.playPieceSelect();
