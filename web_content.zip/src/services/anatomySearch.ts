/**
 * HELENA - Veterinary Anatomical Search & Auto Portuguese-to-English Sketchfab Translator
 * 
 * Flow:
 * 1. User writes in Portuguese (e.g., "esqueleto de vaca", "músculos da vaca", "coração bovino", "crânio de cachorro").
 * 2. Instant & AI translation converts the query to exact, high-yield English terms used by 3D creators on Sketchfab
 *    (e.g., "cow skeleton", "cow muscles", "cow heart", "canine skull", "horse heart").
 * 3. Fetches official Sketchfab API v3 results using the translated English terms.
 * 4. Filters out irrelevant non-biological models (cars, weapons, anime, buildings) and ranks
 *    biological veterinary models based on species, anatomical structure, and community trust.
 */

import { SketchfabSearchResult } from '../types';

export interface TranslationResult {
  englishQuery: string;
  originalQuery: string;
  detectedSpecies: string;
  detectedStructure: string;
  alternatives: string[];
}

export interface AnatomicalSearchSuggestion {
  titulo_pt: string;
  consulta_en: string;
  especie: string;
  estrutura: string;
}

export function normalizeAnatomicalQuery(query: string): {
  englishQuery: string;
  detectedSpecies: string;
  detectedStructure: string;
  suggestions: AnatomicalSearchSuggestion[];
} {
  const lower = query.toLowerCase();
  let enSpecies = 'animal';
  let ptSpecies = 'veterinária';
  let enStructure = 'anatomy';
  let ptStructure = 'estrutura';

  if (/vaca|boi|bovin|gado/i.test(lower)) { enSpecies = 'cow'; ptSpecies = 'bovino'; }
  else if (/cavalo|[eé]gua|equin/i.test(lower)) { enSpecies = 'horse'; ptSpecies = 'equino'; }
  else if (/c[aã]o|cachorro|canin/i.test(lower)) { enSpecies = 'dog'; ptSpecies = 'canino'; }
  else if (/gato|felin/i.test(lower)) { enSpecies = 'cat'; ptSpecies = 'felino'; }

  if (/esqueleto|osso/i.test(lower)) { enStructure = 'skeleton'; ptStructure = 'esqueleto'; }
  else if (/m[uú]sculo/i.test(lower)) { enStructure = 'muscles'; ptStructure = 'músculos'; }
  else if (/cora[cç][aã]o/i.test(lower)) { enStructure = 'heart'; ptStructure = 'coração'; }
  else if (/cr[aâ]nio/i.test(lower)) { enStructure = 'skull'; ptStructure = 'crânio'; }

  const q = `${enSpecies} ${enStructure}`;
  return {
    englishQuery: q,
    detectedSpecies: ptSpecies,
    detectedStructure: ptStructure,
    suggestions: [
      { titulo_pt: `${ptStructure} de ${ptSpecies}`, consulta_en: q, especie: ptSpecies, estrutura: ptStructure },
      { titulo_pt: `${ptSpecies} (${enSpecies} ${enStructure})`, consulta_en: `${enSpecies} ${enStructure}`, especie: ptSpecies, estrutura: ptStructure },
    ],
  };
}

// Banned keywords indicating vehicles, architecture, weapons, fantasy props
export const BANNED_KEYWORDS = [
  'car', 'cars', 'vehicle', 'automotive', 'automobile', 'truck', 'motorcycle', 'engine',
  'ford', 'mustang', 'chevrolet', 'chevy', 'dodge', 'toyota', 'honda', 'bmw', 'audi', 'porsche', 'ferrari', 'corvette',
  'house', 'building', 'room', 'architecture', 'interior', 'furniture', 'exterior', 'facade',
  'casa', 'predio', 'prédio', 'edificio', 'edifício', 'apartamento', 'sofa', 'sofá', 'chair', 
  'table', 'kitchen', 'roof', 'door', 'window', 'wall', 'fence', 'street', 'city', 'urban', 
  'chalet', 'cottage', 'cabin', 'garage', 'bedroom', 'living room', 'mansion', 'condo',
  'weapon', 'gun', 'sword', 'shield', 'armor', 'sci-fi', 'spacecraft', 'aircraft', 'airplane', 
  'robot', 'mech', 'character', 'superman', 'batman', 'anime', 'monster', 'alien', 'tree', 
  'plant', 'game asset', 'low poly game', 'building pack', 'race car', 'muscle car'
];

// Positive biological and anatomical terms
export const MANDATORY_ANATOMY_KEYWORDS = [
  'skull', 'cranium', 'cranio', 'crânio', 'bone', 'bones', 'skeleton', 'skeletal', 'osteology', 
  'heart', 'cardiac', 'stomach', 'rumen', 'organ', 'viscera', 'dissection', 'muscle', 'muscles', 
  'muscular', 'tendon', 'tarsus', 'hoof', 'limb', 'veterinary', 'anatomy', 'anatomical', 'specimen', 
  'canine', 'dog', 'feline', 'cat', 'equine', 'horse', 'bovine', 'cow', 'cattle', 'bull', 'ox', 
  'ruminant', 'femur', 'pelvis', 'mandible', 'teeth', 'tooth', 'jaw', 'vertebra', 'vertebrae', 
  'spine', 'spinal', 'rib', 'ribs', 'thorax', 'lung', 'lungs', 'kidney', 'liver', 'brain', 'biology'
];

// Species dictionary mapping Portuguese terms to primary English keywords
const SPECIES_MAP: Array<{ regex: RegExp; pt: string; en: string; altEn: string }> = [
  { regex: /\b(vaca|vacas|boi|bois|bovin[oa]s?|gado|touro|touros|novilha|bezerro|bezerros|r[uú]men|ruminante?s?)\b/i, pt: 'bovino (vaca/boi)', en: 'cow', altEn: 'bovine' },
  { regex: /\b(cavalo|cavalos|[eé]gua|[eé]guas|equin[oa]s?|potro|potros|garanh[aã]o)\b/i, pt: 'equino (cavalo)', en: 'horse', altEn: 'equine' },
  { regex: /\b(c[aã]o|c[aã]es|cachorro|cachorros|canin[oa]s?|cadela|cadelas)\b/i, pt: 'canino (cão)', en: 'dog', altEn: 'canine' },
  { regex: /\b(gato|gatos|felin[oa]s?|gata|gatas|bichano)\b/i, pt: 'felino (gato)', en: 'cat', altEn: 'feline' },
  { regex: /\b(porco|porcos|su[ií]n[oa]s?|leit[aã]o|leit[oõ]es|porca)\b/i, pt: 'suíno (porco)', en: 'pig', altEn: 'porcine' },
  { regex: /\b(ovelha|ovelhas|carneiro|carneiros|ovin[oa]s?|borrego)\b/i, pt: 'ovino (ovelha)', en: 'sheep', altEn: 'ovine' },
  { regex: /\b(cabra|cabras|bode|bodes|caprin[oa]s?)\b/i, pt: 'caprino (cabra)', en: 'goat', altEn: 'caprine' },
  { regex: /\b(ave|aves|galinha|galinhas|frango|galo|p[aá]ssaro|passaros)\b/i, pt: 'ave', en: 'bird', altEn: 'chicken' },
];

// Anatomical structure dictionary mapping Portuguese terms to primary English keywords
const STRUCTURE_MAP: Array<{ regex: RegExp; pt: string; en: string; altEn: string }> = [
  { regex: /\b(esqueleto|esqueletos|ossatura|ossos?|osteologia)\b/i, pt: 'esqueleto', en: 'skeleton', altEn: 'bones' },
  { regex: /\b(m[uú]sculos?|musculatura|miologia|carne)\b/i, pt: 'músculos', en: 'muscles', altEn: 'muscle' },
  { regex: /\b(cora[cç][aã]o|cora[cç][oõ]es|card[ií]aco|mioc[aá]rdio)\b/i, pt: 'coração', en: 'heart', altEn: 'cardiac' },
  { regex: /\b(cr[aâ]nio|cr[aâ]nios|cabe[cç]a|neurocr[aâ]nio)\b/i, pt: 'crânio', en: 'skull', altEn: 'cranium' },
  { regex: /\b(mand[ií]bula|mandibulas?|maxilar|maxila|queixo)\b/i, pt: 'mandíbula', en: 'jaw', altEn: 'mandible' },
  { regex: /\b(dentes?|denti[cç][aã]o|arcada\s+dent[aá]ria)\b/i, pt: 'dentes', en: 'teeth', altEn: 'dental' },
  { regex: /\b(est[oô]mago|r[uú]men|ret[ií]culo|omaso|abomaso|pan[cç]a|bucho)\b/i, pt: 'estômago / rúmen', en: 'stomach', altEn: 'rumen' },
  { regex: /\b(casco|cascos|estojo\s+c[oó]rneo|podologia|unha)\b/i, pt: 'casco', en: 'hoof', altEn: 'hoof anatomy' },
  { regex: /\b(tarso|patas?|membro[s]?|pernas?|p[eé][s]?)\b/i, pt: 'patas / membros', en: 'limb', altEn: 'tarsus' },
  { regex: /\b(coluna|v[eé]rtebras?|espinha|raque)\b/i, pt: 'coluna vertebral', en: 'spine', altEn: 'vertebrae' },
  { regex: /\b(costelas?|t[oó]rax|caixa\s+tor[aá]cica)\b/i, pt: 'costelas / tórax', en: 'ribs', altEn: 'thorax' },
  { regex: /\b(pulm[aã]o|pulm[oõ]es|respirat[oó]rio)\b/i, pt: 'pulmões', en: 'lungs', altEn: 'lung' },
  { regex: /\b(f[ií]gado|hep[aá]tico)\b/i, pt: 'fígado', en: 'liver', altEn: 'hepatic' },
  { regex: /\b(rim|rins|renal)\b/i, pt: 'rim', en: 'kidney', altEn: 'kidneys' },
  { regex: /\b(c[eé]rebro|enc[eé]falo|sistema\s+nervoso)\b/i, pt: 'cérebro', en: 'brain', altEn: 'encephalon' },
  { regex: /\b(olhos?|ocular|globo\s+ocular)\b/i, pt: 'olho', en: 'eye', altEn: 'eye anatomy' },
  { regex: /\b(orelhas?|ouvido|auricular)\b/i, pt: 'orelha', en: 'ear', altEn: 'ear' },
  { regex: /\b(pelve|p[eé]lvis|bacia)\b/i, pt: 'pelve', en: 'pelvis', altEn: 'pelvis bone' },
  { regex: /\b(f[eê]mur|femur|coxa)\b/i, pt: 'fêmur', en: 'femur', altEn: 'femur bone' },
  { regex: /\b(esc[aá]pula|escapula|ombro)\b/i, pt: 'escápula', en: 'scapula', altEn: 'scapula bone' },
  { regex: /\b(dissec[cç][aã]o|anatomia|viscera|v[ií]sceras?|[oó]rg[aã]os?)\b/i, pt: 'anatomia / órgãos', en: 'anatomy', altEn: 'organ' },
];

/**
 * Translates a user's Portuguese veterinary search into the most effective
 * concise English search term for Sketchfab (e.g., "esqueleto de vaca" -> "cow skeleton").
 */
export async function translatePtToEnForSketchfab(
  query: string,
  geminiKey?: string
): Promise<TranslationResult> {
  const trimmed = query.trim();
  const lower = trimmed.toLowerCase();

  // If already predominantly in English (e.g., "cow skeleton", "horse heart", "dog skull")
  const looksEnglish = /\b(cow|horse|dog|cat|skeleton|skull|muscles?|heart|bovine|equine|canine|feline)\b/i.test(lower) &&
                       !/\b(de|da|do|para|com|em|vaca|boi|cavalo|cachorro|cão|esqueleto|músculo|músculos|coração|crânio)\b/i.test(lower);

  if (looksEnglish) {
    return {
      englishQuery: trimmed,
      originalQuery: trimmed,
      detectedSpecies: 'Identificado em inglês',
      detectedStructure: 'Estrutura 3D',
      alternatives: [trimmed, `${trimmed} anatomy`],
    };
  }

  // 1. Detect species and structure via instant veterinary dictionary
  let matchedSpecies = SPECIES_MAP.find((s) => s.regex.test(lower));
  let matchedStructure = STRUCTURE_MAP.find((st) => st.regex.test(lower));

  if (matchedSpecies && matchedStructure) {
    // Exact targeted combination (e.g., "cow skeleton", "cow muscles", "cow heart")
    const primary = `${matchedSpecies.en} ${matchedStructure.en}`;
    const alt1 = `${matchedSpecies.en} - ${matchedStructure.en}`;
    const alt2 = `${matchedSpecies.altEn} ${matchedStructure.en}`;
    const alt3 = `${matchedSpecies.en} ${matchedStructure.altEn}`;
    const alt4 = `${matchedSpecies.en} anatomy`;

    const uniqueAlts = Array.from(new Set([primary, alt1, alt2, alt3, alt4])).slice(0, 4);

    return {
      englishQuery: primary,
      originalQuery: trimmed,
      detectedSpecies: matchedSpecies.pt,
      detectedStructure: matchedStructure.pt,
      alternatives: uniqueAlts,
    };
  }

  if (matchedSpecies && !matchedStructure) {
    const primary = `${matchedSpecies.en} anatomy`;
    const alt1 = `${matchedSpecies.en} skeleton`;
    const alt2 = `${matchedSpecies.altEn} anatomy`;
    return {
      englishQuery: primary,
      originalQuery: trimmed,
      detectedSpecies: matchedSpecies.pt,
      detectedStructure: 'anatomia geral',
      alternatives: [primary, alt1, alt2],
    };
  }

  if (!matchedSpecies && matchedStructure) {
    const primary = `veterinary ${matchedStructure.en}`;
    const alt1 = `animal ${matchedStructure.en}`;
    const alt2 = `${matchedStructure.en} anatomy`;
    return {
      englishQuery: primary,
      originalQuery: trimmed,
      detectedSpecies: 'veterinária geral',
      detectedStructure: matchedStructure.pt,
      alternatives: [primary, alt1, alt2],
    };
  }

  // 2. If no direct match in dictionary and Gemini Key is provided, use Gemini to translate accurately
  if (geminiKey) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=${geminiKey.trim()}`;
      const prompt = `Traduza a busca anatômica veterinária "${trimmed}" para o termo de pesquisa mais direto em inglês (máximo 2 a 3 palavras) como usado em títulos do Sketchfab 3D (exemplos: "Cow Skeleton", "Cow muscles", "Dog Skull", "Horse Heart", "Cat Spine"). Responda APENAS com o termo em inglês, sem pontuação extra.`;

      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 25 },
        }),
      });

      if (resp.ok) {
        const json = await resp.json();
        const translated = json?.candidates?.[0]?.content?.parts?.[0]?.text?.trim()?.replace(/["`]/g, '');
        if (translated && translated.length > 2 && translated.length < 50) {
          return {
            englishQuery: translated.toLowerCase(),
            originalQuery: trimmed,
            detectedSpecies: 'veterinária',
            detectedStructure: 'estrutura anatômica',
            alternatives: [translated.toLowerCase(), `${translated.toLowerCase()} anatomy`],
          };
        }
      }
    } catch (e) {
      console.warn('Gemini translation fallback error:', e);
    }
  }

  // 3. Fallback: clean words + anatomy suffix
  const sanitized = lower.replace(/[^\w\s]/gi, '').trim();
  return {
    englishQuery: `${sanitized} anatomy`,
    originalQuery: trimmed,
    detectedSpecies: 'veterinária',
    detectedStructure: 'anatomia',
    alternatives: [`${sanitized} anatomy`, `${sanitized} 3d`],
  };
}

/**
 * Validates and scores a Sketchfab search result for anatomical authenticity.
 * Completely rejects architectural, vehicle, and non-biological items.
 */
export function scoreSketchfabResult(
  model: any,
  targetAnimalEn: string = '',
  targetStructureEn: string = '',
  trustedAuthors: string[] = []
): { score: number; isValidAnatomy: boolean; reasons: string[] } {
  const name = (model.name || '').toLowerCase();
  const description = (model.description || '').toLowerCase();
  const tags = (model.tags || []).map((t: any) => (t.name || '').toLowerCase()).join(' ');
  const authorUser = (model.user?.username || '').toLowerCase();
  const authorName = (model.user?.displayName || '').toLowerCase();

  const fullText = `${name} ${description} ${tags}`;

  // 1. Strict rejection of banned architectural / vehicle / fantasy keywords
  const isBanned = BANNED_KEYWORDS.some((kw) => {
    const regex = new RegExp(`\\b${kw}\\b`, 'i');
    return regex.test(fullText);
  });

  if (isBanned) {
    return {
      score: 0,
      isValidAnatomy: false,
      reasons: ['Descartado: contém veículo, arma, jogo ou elemento não biológico'],
    };
  }

  // 2. Must contain at least one positive biological/anatomical keyword OR the target animal
  const hasAnatomyKeyword = MANDATORY_ANATOMY_KEYWORDS.some((kw) => fullText.includes(kw));
  const hasTargetAnimal = targetAnimalEn ? fullText.includes(targetAnimalEn.toLowerCase()) : false;

  if (!hasAnatomyKeyword && !hasTargetAnimal) {
    return {
      score: 5,
      isValidAnatomy: false,
      reasons: ['Não contém termos anatômicos biológicos suficientes'],
    };
  }

  let score = 50; // Base score for valid biological model
  const reasons: string[] = ['Modelo biológico veterinário validado'];

  // Check matching target animal (e.g. "cow", "horse", "dog")
  if (targetAnimalEn && fullText.includes(targetAnimalEn.toLowerCase())) {
    score += 25;
    reasons.push(`Espécie correspondente (${targetAnimalEn}) (+25)`);
  }

  // Check matching target structure (e.g. "skeleton", "muscles", "heart", "skull")
  if (targetStructureEn && fullText.includes(targetStructureEn.toLowerCase())) {
    score += 20;
    reasons.push(`Estrutura correspondente (${targetStructureEn}) (+20)`);
  }

  // Check exact name match prominence
  if (name.includes(targetAnimalEn.toLowerCase()) && name.includes(targetStructureEn.toLowerCase())) {
    score += 15;
    reasons.push('Correspondência direta no título oficial (+15)');
  }

  // Academic / University / Museum creator bonus
  const academicTerms = ['vet', 'veterinary', 'university', 'museum', 'faculdade', 'college', 'specimen', 'morphology', ...trustedAuthors];
  const isAcademic = academicTerms.some((term) => 
    authorUser.includes(term) || authorName.includes(term) || fullText.includes(term)
  );
  if (isAcademic) {
    score += 10;
    reasons.push('Criador acadêmico/institucional (+10)');
  }

  // Popularity bonus from views and likes
  if ((model.likeCount || 0) > 20) {
    score += 5;
  }

  const finalScore = Math.min(100, score);
  return {
    score: finalScore,
    isValidAnatomy: true,
    reasons,
  };
}
