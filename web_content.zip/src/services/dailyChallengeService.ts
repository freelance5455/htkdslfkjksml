/**
 * Daily Chess Challenge System
 * Verified chess puzzles, checkmate challenges, and endgame missions with daily calendar schedule,
 * multi-attempt limit, solution explanation, and daily streak rewards.
 */

import { DailyChallenge, ChallengeCompletion } from '../types/chess';

const CHALLENGE_COMPLETIONS_KEY = 'chess3d_challenge_completions_v5';

export const VERIFIED_DAILY_CHALLENGES: DailyChallenge[] = [
  {
    id: 'CHALLENGE-2026-10-18',
    challengeDate: '2026-10-18',
    title: 'Smothered Mate Sequence',
    category: 'mate_in_2',
    difficulty: 'Medium',
    fen: '6k1/5ppp/8/8/8/8/1q4PP/4R2K w - - 0 1',
    solutionMoves: ['e1e8'],
    explanation: 'A textbook back-rank mate: 1. Re8# takes advantage of the trapped enemy King behind its defensive pawn shield.',
    rewardXp: 75,
    rewardTitle: 'Daily Tactician',
    attemptsAllowed: 3,
    hints: ['Attack the vulnerable 8th rank with your active rook.'],
  },
  {
    id: 'CHALLENGE-2026-10-17',
    challengeDate: '2026-10-17',
    title: 'Greek Gift Sacrifice Follow-up',
    category: 'tactics',
    difficulty: 'Hard',
    fen: 'r1bq1rk1/ppp2ppp/2n5/3pP3/3P2n1/2N2N2/PPP2PPP/R1BQK2R w KQkq - 1 9',
    solutionMoves: ['h2h3', 'g4h6'],
    explanation: 'Driving the knight from its aggressive post halts all tactical Greek gift ambitions and secures White’s center.',
    rewardXp: 90,
    rewardTitle: 'Center Defender',
    attemptsAllowed: 3,
    hints: ['Kick the annoying knight before it lands on e3.'],
  },
  {
    id: 'CHALLENGE-2026-10-16',
    challengeDate: '2026-10-16',
    title: 'Endgame Lucena Bridge Building',
    category: 'endgame',
    difficulty: 'Medium',
    fen: '8/8/8/4k3/4P3/8/4K3/1R6 w - - 0 1',
    solutionMoves: ['b1b5', 'e5e4'],
    explanation: 'Rook checks separate the defending King from the passed pawn, creating the runway for promotion.',
    rewardXp: 80,
    rewardTitle: 'Endgame Virtuoso',
    attemptsAllowed: 3,
    hints: ['Check the King to force it backwards or away from the pawn.'],
  },
  {
    id: 'CHALLENGE-2026-10-15',
    challengeDate: '2026-10-15',
    title: 'Absolute Pin Extraction',
    category: 'find_defence',
    difficulty: 'Easy',
    fen: 'r1b1k2r/pppp1ppp/2n5/4q3/1b6/2N5/PPP1BPPP/R1BQK2R w KQkq - 0 8',
    solutionMoves: ['e1g1', 'b4c3', 'b2c3'],
    explanation: 'Castling breaks the pin against the king and immediately mobilizes the rook for counterplay along the central e-file.',
    rewardXp: 50,
    rewardTitle: 'Pin Breaker',
    attemptsAllowed: 3,
    hints: ['Castle your King to break all pins immediately.'],
  },
];

class DailyChallengeService {
  private completions: Map<string, ChallengeCompletion> = new Map();

  constructor() {
    this.loadCompletions();
  }

  private loadCompletions(): void {
    try {
      const stored = localStorage.getItem(CHALLENGE_COMPLETIONS_KEY);
      if (stored) {
        const parsed: ChallengeCompletion[] = JSON.parse(stored);
        parsed.forEach((c) => this.completions.set(c.challengeId, c));
      }
    } catch {
      // Fallback
    }
  }

  private saveCompletions(): void {
    if (typeof localStorage === 'undefined') return;
    try {
      const list = Array.from(this.completions.values());
      localStorage.setItem(CHALLENGE_COMPLETIONS_KEY, JSON.stringify(list));
    } catch (e) {
      console.warn('Failed to cache completions:', e);
    }
  }

  /**
   * Get the challenge for today based on current date
   */
  public getTodayChallenge(): DailyChallenge {
    const todayStr = new Date().toISOString().split('T')[0];
    const match = VERIFIED_DAILY_CHALLENGES.find((c) => c.challengeDate === todayStr);
    return match || VERIFIED_DAILY_CHALLENGES[0];
  }

  /**
   * Get all available daily challenges (today and historical archive)
   */
  public getAllChallenges(): DailyChallenge[] {
    return [...VERIFIED_DAILY_CHALLENGES];
  }

  public getCompletion(challengeId: string): ChallengeCompletion | undefined {
    return this.completions.get(challengeId);
  }

  /**
   * Record an attempt and reward XP if solved
   */
  public recordCompletion(
    challengeId: string,
    success: boolean,
    timeSeconds: number
  ): { success: boolean; xpAwarded: number; isFirstCompletion: boolean } {
    const challenge = VERIFIED_DAILY_CHALLENGES.find((c) => c.id === challengeId);
    if (!challenge) return { success: false, xpAwarded: 0, isFirstCompletion: false };

    const existing = this.completions.get(challengeId);
    if (existing && existing.completed) {
      // Already solved previously: prevent duplicate XP farming
      return { success: true, xpAwarded: 0, isFirstCompletion: false };
    }

    const xp = success ? challenge.rewardXp : 0;
    const record: ChallengeCompletion = {
      challengeId,
      completed: success,
      attemptsCount: (existing?.attemptsCount || 0) + 1,
      timeSeconds,
      xpAwarded: xp,
      completedAt: new Date().toISOString(),
    };

    this.completions.set(challengeId, record);
    this.saveCompletions();

    return { success: true, xpAwarded: xp, isFirstCompletion: success };
  }
}

export const dailyChallengeService = new DailyChallengeService();
