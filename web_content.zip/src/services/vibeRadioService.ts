import { Song, VibeMode } from '../types/music';
import { INITIAL_SONGS } from '../data/musicCatalog';
import { searchYouTubeMusic } from './youtubeSearchService';

// Vibe mapping: associate moods & genres with complementary musical waves
interface VibeCluster {
  name: string;
  genres: string[];
  moods: string[];
  bpmRange: [number, number];
  relatedQueries: string[];
}

const VIBE_CLUSTERS: Record<string, VibeCluster> = {
  bollywood_romance: {
    name: 'Bollywood Romance & Soul',
    genres: ['Bollywood', 'Acoustic', 'Sufi'],
    moods: ['Relax', 'Romance', 'Focus'],
    bpmRange: [75, 105],
    relatedQueries: [
      'Arijit Singh romantic hits',
      'Jasleen Royal Heeriye songs',
      'Sachin Jigar soul songs',
      'Pritam romantic melody',
      'Atif Aslam romantic songs',
      'Anuv Jain acoustic songs'
    ]
  },
  punjabi_energy: {
    name: 'Punjabi Bangers & Pop',
    genres: ['Punjabi', 'Hip-Hop', 'Pop'],
    moods: ['Energize', 'Party', 'Workout'],
    bpmRange: [98, 135],
    relatedQueries: [
      'Diljit Dosanjh energetic songs',
      'Karan Aujla hit songs',
      'AP Dhillon Punjabi pop',
      'Sidhu Moose Wala top songs',
      'Shubh Punjabi hits'
    ]
  },
  global_pop_synth: {
    name: 'Global Pop & Synthwave',
    genres: ['Pop', 'Synthwave', 'Electronic'],
    moods: ['Energize', 'Workout', 'Party'],
    bpmRange: [100, 135],
    relatedQueries: [
      'The Weeknd style songs',
      'Dua Lipa pop hits',
      'Post Malone synthwave pop',
      'Billie Eilish pop hits',
      'Harry Styles upbeat pop'
    ]
  },
  lofi_chill: {
    name: 'Lo-Fi Chill & Focus',
    genres: ['Lo-Fi', 'Acoustic', 'Chillhop'],
    moods: ['Focus', 'Relax', 'Sleep'],
    bpmRange: [65, 90],
    relatedQueries: [
      'Lofi chill beats study',
      'Acoustic hindi lofi',
      'ChilledCow beats to relax to',
      'Late night lofi vibes'
    ]
  },
  south_indian_hits: {
    name: 'South Indian & Modern Fusion',
    genres: ['Bollywood', 'South Indian', 'Fusion'],
    moods: ['Energize', 'Relax', 'Party'],
    bpmRange: [95, 130],
    relatedQueries: [
      'Anirudh Ravichander viral hits',
      'Sushin Shyam aavesham vibes',
      'AR Rahman modern hits',
      'Sid Sriram soulful songs'
    ]
  }
};

/**
 * Determine the closest vibe cluster for any given song
 */
export function detectSongVibeCluster(song: Song): VibeCluster {
  const g = (song.genre || '').toLowerCase();
  const m = (song.mood || '').toLowerCase();
  const t = (song.title || '').toLowerCase();
  const a = (song.artist || '').toLowerCase();

  if (g.includes('punjabi') || a.includes('diljit') || a.includes('aujla') || a.includes('dhillon')) {
    return VIBE_CLUSTERS.punjabi_energy;
  }
  if (g.includes('lo-fi') || g.includes('lofi') || m.includes('focus') || t.includes('lofi')) {
    return VIBE_CLUSTERS.lofi_chill;
  }
  if (t.includes('chuttamalle') || t.includes('illuminati') || a.includes('anirudh') || a.includes('sushin')) {
    return VIBE_CLUSTERS.south_indian_hits;
  }
  if (g.includes('pop') || g.includes('synth') || a.includes('weeknd') || a.includes('dua') || a.includes('carpenter')) {
    return VIBE_CLUSTERS.global_pop_synth;
  }
  // Default to Bollywood Romance / Soul
  return VIBE_CLUSTERS.bollywood_romance;
}

/**
 * Select the next track based on YouTube Music's "Same Vibe, Different Artists" algorithm:
 * - Keeps the musical wave constant (genre, mood, tempo).
 * - "Different artists" variety: balances fresh artists vs same type.
 * - Respects the user's active vibe tuner mode.
 */
export function getNextVibeTrack(
  currentSong: Song,
  vibeMode: VibeMode = 'same-wave',
  recentHistoryIds: string[] = [],
  availableCatalog: Song[] = INITIAL_SONGS
): Song {
  const cluster = detectSongVibeCluster(currentSong);
  const currentArtistMain = currentSong.artist.split(/[,&ft\.]/i)[0].trim().toLowerCase();

  // Candidates from catalog excluding currently playing song
  let candidates = availableCatalog.filter((s) => s.id !== currentSong.id);

  // Score each candidate based on Vibe criteria
  const scored = candidates.map((s) => {
    let score = 0;
    const songArtistMain = s.artist.split(/[,&ft\.]/i)[0].trim().toLowerCase();
    const isSameArtist = songArtistMain === currentArtistMain || s.artist.toLowerCase().includes(currentArtistMain);
    const wasRecentlyPlayed = recentHistoryIds.slice(0, 10).includes(s.id);

    // Penalty for recently played songs
    if (wasRecentlyPlayed) {
      score -= 50;
    }

    // Matching cluster genres / moods
    const matchesGenre = cluster.genres.some((g) => s.genre.toLowerCase() === g.toLowerCase());
    const matchesMood = cluster.moods.some((m) => s.mood.toLowerCase() === m.toLowerCase());

    if (matchesGenre) score += 40;
    if (matchesMood) score += 30;

    // Tempo / BPM proximity
    if (s.bpm && currentSong.bpm) {
      const bpmDiff = Math.abs(s.bpm - currentSong.bpm);
      if (bpmDiff <= 10) score += 20;
      else if (bpmDiff <= 25) score += 10;
    }

    // Apply Vibe Tuner Mode rules:
    switch (vibeMode) {
      case 'same-wave':
        // YouTube Music standard: SAME VIBE, but DIFFERENT ARTIST is preferred for fresh variety!
        if (!isSameArtist) {
          score += 35; // Bonus for different artist in the same vibe
        } else {
          score += 15; // Still possible to hear same artist, but diverse is preferred
        }
        break;

      case 'discover-different':
        // Strongly enforce DIFFERENT artist (fresh discovery)
        if (!isSameArtist) {
          score += 60;
        } else {
          score -= 40; // Discourage same artist
        }
        break;

      case 'same-artist':
        // Strictly prioritize songs by the same artist or exact genre
        if (isSameArtist) {
          score += 60;
        }
        break;

      case 'upbeat':
        // Prioritize higher BPM & energizing mood
        if (s.bpm >= 105) score += 40;
        if (s.mood === 'Energize' || s.mood === 'Party' || s.mood === 'Workout') score += 30;
        if (!isSameArtist) score += 15;
        break;

      case 'chill':
        // Prioritize acoustic / soft / relaxing
        if (s.bpm <= 100) score += 40;
        if (s.mood === 'Relax' || s.mood === 'Focus') score += 30;
        if (!isSameArtist) score += 15;
        break;

      case 'familiar':
        // Prioritize massive superhits (>400M plays)
        if (s.plays >= 400000000) score += 40;
        if (!isSameArtist) score += 15;
        break;
    }

    // Add small random jitter (0-15) so the queue feels lively and doesn't always repeat identical orders
    score += Math.random() * 15;

    return { song: s, score };
  });

  // Sort candidates by score descending
  scored.sort((a, b) => b.score - a.score);

  // Return the best candidate, or fallback to first
  if (scored.length > 0 && scored[0].score > 0) {
    return scored[0].song;
  }

  // Fallback: pick any song of different artist if possible
  const differentArtistSong = candidates.find(
    (s) => !s.artist.toLowerCase().includes(currentArtistMain)
  );

  return differentArtistSong || candidates[0] || currentSong;
}

/**
 * Generate an initial dynamic "YouTube Radio" queue of 12+ songs for any starting track,
 * with same vibe and rich artist variety.
 */
export function generateVibeRadioQueue(
  seedSong: Song,
  vibeMode: VibeMode = 'same-wave',
  catalog: Song[] = INITIAL_SONGS
): Song[] {
  const queue: Song[] = [seedSong];
  const recentIds: string[] = [seedSong.id];

  for (let i = 0; i < 15; i++) {
    const nextSong = getNextVibeTrack(queue[queue.length - 1], vibeMode, recentIds, catalog);
    if (!recentIds.includes(nextSong.id)) {
      queue.push(nextSong);
      recentIds.push(nextSong.id);
    }
  }

  return queue;
}

/**
 * Fetch fresh YouTube tracks for an ongoing radio session
 */
export async function fetchLiveVibeTracksFromYouTube(song: Song): Promise<Song[]> {
  const cluster = detectSongVibeCluster(song);
  const randomQuery =
    cluster.relatedQueries[Math.floor(Math.random() * cluster.relatedQueries.length)];

  try {
    const ytSongs = await searchYouTubeMusic(randomQuery);
    return ytSongs.filter((s) => s.id !== song.id && s.title.toLowerCase() !== song.title.toLowerCase());
  } catch (err) {
    return [];
  }
}
