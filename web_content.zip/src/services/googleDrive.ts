export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  modifiedTime: string;
  iconLink?: string;
  thumbnailLink?: string;
  webContentLink?: string;
  webViewLink?: string;
  isFolder: boolean;
}

export interface DriveStorageQuota {
  limit?: string;
  usage?: string;
  usageInDrive?: string;
  usageInDriveTrash?: string;
  user?: {
    displayName: string;
    emailAddress: string;
    photoLink?: string;
  };
}

export const listDriveFiles = async (
  token: string, 
  parentId: string = 'root',
  searchTerm: string = ''
): Promise<DriveFileItem[]> => {
  let query = `'${parentId}' in parents and trashed = false`;
  if (searchTerm.trim()) {
    query += ` and name contains '${searchTerm.replace(/'/g, "\\'")}'`;
  }

  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name,mimeType,size,modifiedTime,iconLink,thumbnailLink,webContentLink,webViewLink)&orderBy=folder,name&pageSize=100`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Erro ao listar arquivos do Drive (${res.status})`);
  }

  const data = await res.json();
  const rawFiles = data.files || [];

  return rawFiles.map((f: any) => {
    const isFolder = f.mimeType === 'application/vnd.google-apps.folder';
    return {
      id: f.id,
      name: f.name,
      mimeType: f.mimeType,
      size: f.size,
      modifiedTime: new Date(f.modifiedTime).toLocaleDateString('pt-BR'),
      iconLink: f.iconLink,
      thumbnailLink: f.thumbnailLink,
      webContentLink: f.webContentLink,
      webViewLink: f.webViewLink,
      isFolder
    };
  });
};

export const createDriveFolder = async (
  token: string,
  folderName: string,
  parentId: string = 'root'
): Promise<DriveFileItem> => {
  const metadata = {
    name: folderName,
    mimeType: 'application/vnd.google-apps.folder',
    parents: [parentId]
  };

  const res = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(metadata)
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Erro ao criar pasta no Drive (${res.status})`);
  }

  const data = await res.json();
  return {
    id: data.id,
    name: data.name,
    mimeType: data.mimeType,
    modifiedTime: new Date().toLocaleDateString('pt-BR'),
    isFolder: true
  };
};

export const uploadFileToDrive = async (
  token: string,
  file: File,
  parentId: string = 'root'
): Promise<DriveFileItem> => {
  const metadata = {
    name: file.name,
    parents: [parentId]
  };

  const form = new FormData();
  form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  form.append('file', file);

  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`
    },
    body: form
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Erro ao fazer upload no Drive (${res.status})`);
  }

  const data = await res.json();
  return {
    id: data.id,
    name: data.name,
    mimeType: data.mimeType || file.type,
    modifiedTime: new Date().toLocaleDateString('pt-BR'),
    isFolder: false
  };
};

export const uploadBlobToDrive = async (
  token: string,
  blob: Blob,
  fileName: string,
  parentId: string = 'root'
): Promise<DriveFileItem> => {
  const metadata = {
    name: fileName,
    parents: [parentId]
  };

  const form = new FormData();
  form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  form.append('file', blob, fileName);

  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`
    },
    body: form
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Erro ao fazer upload no Drive (${res.status})`);
  }

  const data = await res.json();
  return {
    id: data.id,
    name: data.name,
    mimeType: data.mimeType || blob.type,
    modifiedTime: new Date().toLocaleDateString('pt-BR'),
    isFolder: false
  };
};

export const deleteDriveFile = async (
  token: string,
  fileId: string
): Promise<void> => {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!res.ok && res.status !== 204) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Erro ao excluir arquivo do Drive (${res.status})`);
  }
};

export const downloadDriveFile = async (
  token: string,
  fileId: string,
  fileName: string
): Promise<void> => {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!res.ok) {
    throw new Error(`Erro ao baixar arquivo do Drive (${res.status})`);
  }

  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const getDriveAbout = async (token: string): Promise<DriveStorageQuota> => {
  const res = await fetch('https://www.googleapis.com/drive/v3/about?fields=storageQuota,user', {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!res.ok) {
    return {};
  }

  const data = await res.json();
  return {
    limit: data.storageQuota?.limit,
    usage: data.storageQuota?.usage,
    usageInDrive: data.storageQuota?.usageInDrive,
    user: data.user
  };
};
