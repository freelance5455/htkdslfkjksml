import confetti from 'canvas-confetti';

class SoundService {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
  }

  public playTone(freq: number, type: OscillatorType, duration: number, delay = 0) {
    if (!this.enabled) return;
    try {
      this.init();
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime + delay);
      gain.gain.setValueAtTime(0.12, this.ctx.currentTime + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + delay + duration);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(this.ctx.currentTime + delay);
      osc.stop(this.ctx.currentTime + delay + duration);
    } catch {
      // Audio might be unavailable or restricted by browser gesture policy
    }
  }

  public correct() {
    this.playTone(523.25, 'triangle', 0.15, 0.0);
    this.playTone(659.25, 'triangle', 0.15, 0.08);
    this.playTone(783.99, 'triangle', 0.35, 0.16);
  }

  public wrong() {
    this.playTone(220.0, 'sawtooth', 0.25, 0.0);
    this.playTone(180.0, 'sawtooth', 0.35, 0.1);
  }

  public flip() {
    this.playTone(420, 'sine', 0.08, 0.0);
  }

  public levelUp() {
    [440, 554.37, 659.25, 880].forEach((freq, idx) => {
      this.playTone(freq, 'triangle', 0.25, idx * 0.1);
    });
  }

  public triggerCelebration(spread = 60, particleCount = 50) {
    try {
      confetti({
        particleCount,
        spread,
        origin: { y: 0.7 }
      });
    } catch {
      // Confetti fallback
    }
  }

  public triggerFloatingXp(amount: number, targetElement?: HTMLElement | null) {
    this.correct();
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try { navigator.vibrate(35); } catch {}
    }

    if (typeof document === 'undefined') return;
    const el = targetElement || document.body;
    const rect = el.getBoundingClientRect();
    const badge = document.createElement('div');
    badge.textContent = `+${amount} XP`;
    badge.className = 'fixed z-50 pointer-events-none font-black text-sm text-amber-400 drop-shadow-md select-none transition-all duration-700 ease-out';
    badge.style.left = `${Math.max(10, rect.left + rect.width / 2 - 25)}px`;
    badge.style.top = `${Math.max(10, rect.top)}px`;
    badge.style.transform = 'translateY(0) scale(1)';
    badge.style.opacity = '1';
    document.body.appendChild(badge);

    requestAnimationFrame(() => {
      badge.style.transform = 'translateY(-45px) scale(1.25)';
      badge.style.opacity = '0';
    });

    setTimeout(() => badge.remove(), 750);
  }
}

export const sound = new SoundService();

export function speakWord(word: string, lang: 'en-US' | 'en-GB' = 'en-US') {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(word);
    utterance.lang = lang;
    utterance.rate = 0.88;
    window.speechSynthesis.speak(utterance);
  }
}
