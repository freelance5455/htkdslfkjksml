import { supabase } from '../lib/supabase';

function blobToDataUrl(blob: Blob | File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to convert file to data URL'));
      }
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

export async function uploadAvatar(userId: string, file: File): Promise<string> {
  const fileExt = file.name.split('.').pop() || 'jpg';
  const filePath = `${userId}/avatar_${Date.now()}.${fileExt}`;

  try {
    const { error: uploadError } = await supabase.storage
      .from('avatars')
      .upload(filePath, file, { upsert: true });

    if (!uploadError) {
      const { data } = supabase.storage.from('avatars').getPublicUrl(filePath);
      if (data?.publicUrl) return data.publicUrl;
    }
  } catch {}

  // Fallback to data URL
  return await blobToDataUrl(file);
}

export async function uploadChatMedia(
  conversationId: string,
  file: File | Blob,
  fileName: string
): Promise<{ mediaPath: string; signedUrl: string }> {
  const ext = fileName.split('.').pop() || 'bin';
  const timestamp = Date.now();
  const filePath = `${conversationId}/${timestamp}_${fileName.replace(/[^a-zA-Z0-9_.-]/g, '_')}`;

  try {
    const { error: uploadError } = await supabase.storage
      .from('chat-media')
      .upload(filePath, file, {
        upsert: true,
        contentType: file.type || 'application/octet-stream',
      });

    if (!uploadError) {
      // Generate signed URL for 24 hours
      const { data, error: signError } = await supabase.storage
        .from('chat-media')
        .createSignedUrl(filePath, 60 * 60 * 24);

      if (!signError && data?.signedUrl) {
        return {
          mediaPath: filePath,
          signedUrl: data.signedUrl,
        };
      }
    }
  } catch {}

  // Fallback to Data URL for instant rendering & playback
  const dataUrl = await blobToDataUrl(file);
  return {
    mediaPath: dataUrl,
    signedUrl: dataUrl,
  };
}

export async function getSecureMediaUrl(mediaPath: string): Promise<string> {
  if (!mediaPath) return '';
  if (mediaPath.startsWith('http') || mediaPath.startsWith('data:')) return mediaPath;

  try {
    const { data, error } = await supabase.storage
      .from('chat-media')
      .createSignedUrl(mediaPath, 60 * 60 * 24);

    if (!error && data?.signedUrl) {
      return data.signedUrl;
    }
  } catch {}

  return mediaPath;
}

export async function uploadStatusMedia(
  userId: string,
  file: File | Blob,
  fileName: string
): Promise<string> {
  const filePath = `status/${userId}/${Date.now()}_${fileName.replace(/[^a-zA-Z0-9_.-]/g, '_')}`;

  try {
    const { error: uploadError } = await supabase.storage
      .from('chat-media')
      .upload(filePath, file, {
        upsert: true,
        contentType: file.type || 'image/jpeg',
      });

    if (!uploadError) {
      const { data } = await supabase.storage
        .from('chat-media')
        .createSignedUrl(filePath, 60 * 60 * 24);
      if (data?.signedUrl) {
        return data.signedUrl;
      }
    }
  } catch {}

  return await blobToDataUrl(file);
}

