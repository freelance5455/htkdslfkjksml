import { StoredDocument } from '../types';

const STORAGE_KEY = 'docuforge_saved_documents_v1';
const FAVORITES_KEY = 'docuforge_favorites_v1';

// Seed initial example files so the user immediately sees a populated recent files list
const INITIAL_DEMO_DOCUMENTS: StoredDocument[] = [
  {
    id: 'demo-doc-1',
    name: 'Executive_Q4_Summary.docx',
    type: 'docx',
    sizeBytes: 42800,
    createdAt: Date.now() - 1000 * 60 * 35, // 35 mins ago
    updatedAt: Date.now() - 1000 * 60 * 35,
    pageCount: 3,
    isFavorite: true,
    tags: ['Business', 'Report'],
    sourceFeature: 'Text to Document'
  },
  {
    id: 'demo-doc-2',
    name: 'Academic_Research_Draft.pdf',
    type: 'pdf',
    sizeBytes: 184500,
    createdAt: Date.now() - 1000 * 60 * 180, // 3 hours ago
    updatedAt: Date.now() - 1000 * 60 * 180,
    pageCount: 5,
    isFavorite: false,
    tags: ['Academic', 'APA'],
    sourceFeature: 'OCR to Document'
  },
  {
    id: 'demo-doc-3',
    name: 'Product_Catalog_Scan.png',
    type: 'png',
    sizeBytes: 890200,
    createdAt: Date.now() - 1000 * 60 * 60 * 24, // 1 day ago
    updatedAt: Date.now() - 1000 * 60 * 60 * 24,
    pageCount: 1,
    isFavorite: true,
    tags: ['Image', 'Transparent'],
    sourceFeature: 'Remove Background'
  }
];

export function getStoredDocuments(): StoredDocument[] {
  if (typeof window === 'undefined') return INITIAL_DEMO_DOCUMENTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_DEMO_DOCUMENTS));
      return INITIAL_DEMO_DOCUMENTS;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load stored documents:', e);
    return INITIAL_DEMO_DOCUMENTS;
  }
}

export function saveStoredDocument(doc: StoredDocument): void {
  try {
    const current = getStoredDocuments();
    const existingIdx = current.findIndex(d => d.id === doc.id);
    if (existingIdx >= 0) {
      current[existingIdx] = doc;
    } else {
      current.unshift(doc);
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(current.slice(0, 50))); // Keep up to 50 recent
  } catch (e) {
    console.error('Failed to save document:', e);
  }
}

export function toggleDocumentFavorite(id: string): boolean {
  try {
    const current = getStoredDocuments();
    const doc = current.find(d => d.id === id);
    if (doc) {
      doc.isFavorite = !doc.isFavorite;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(current));
      return doc.isFavorite;
    }
  } catch (e) {
    console.error('Failed to toggle favorite:', e);
  }
  return false;
}

export function renameDocument(id: string, newName: string): boolean {
  try {
    const current = getStoredDocuments();
    const doc = current.find(d => d.id === id);
    if (doc) {
      doc.name = newName.trim();
      doc.updatedAt = Date.now();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(current));
      return true;
    }
  } catch (e) {
    console.error('Failed to rename document:', e);
  }
  return false;
}

export function deleteDocument(id: string): boolean {
  try {
    const current = getStoredDocuments();
    const filtered = current.filter(d => d.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
    return true;
  } catch (e) {
    console.error('Failed to delete document:', e);
  }
  return false;
}

export function clearAllDocumentHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error('Failed to clear document history:', e);
  }
}

// Download blob directly as a file
export function triggerFileDownload(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 200);
}

// Share file using Web Share API or download fallback
export async function shareFile(blob: Blob, fileName: string, title: string = 'DocuForge File'): Promise<boolean> {
  if (navigator.share && navigator.canShare) {
    try {
      const file = new File([blob], fileName, { type: blob.type });
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title,
          text: `Exported via DocuForge: ${fileName}`
        });
        return true;
      }
    } catch (e: any) {
      if (e?.name !== 'AbortError') {
        console.warn('Web Share failed, falling back to download:', e);
      }
    }
  }

  // Fallback to direct download
  triggerFileDownload(blob, fileName);
  return true;
}

// Format bytes into readable string (KB, MB)
export function formatFileSize(bytes: number): string {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// Format timestamp into relative or date string
export function formatFileTime(timestamp: number): string {
  const diffMs = Date.now() - timestamp;
  const diffMins = Math.floor(diffMs / (1000 * 60));
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return new Date(timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}
