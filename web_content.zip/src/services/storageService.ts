/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AppSettings, ChatMessage } from '../types/assistant';

const SETTINGS_KEY = 'elysia_settings_v1';
const HISTORY_KEY = 'elysia_history_v1';
const MAX_HISTORY_ITEMS = 30;

export const DEFAULT_SETTINGS: AppSettings = {
  voiceOutputEnabled: true,
  preferredLanguage: 'en-US',
  speechRate: 1.0,
  historyEnabled: true,
  soundEffectsEnabled: true,
};

export class StorageService {
  public static getSettings(): AppSettings {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (!raw) return { ...DEFAULT_SETTINGS };
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_SETTINGS,
        ...parsed,
      };
    } catch (e) {
      console.warn('Could not read settings from storage, resetting to default.', e);
      return { ...DEFAULT_SETTINGS };
    }
  }

  public static saveSettings(settings: AppSettings): void {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.warn('Could not save settings to localStorage:', e);
    }
  }

  public static getHistory(): ChatMessage[] {
    const settings = this.getSettings();
    if (!settings.historyEnabled) return [];

    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.slice(-MAX_HISTORY_ITEMS);
      }
      return [];
    } catch (e) {
      console.warn('Could not read conversation history from storage, clearing corrupt record.', e);
      this.clearHistory();
      return [];
    }
  }

  public static saveHistory(messages: ChatMessage[]): void {
    const settings = this.getSettings();
    if (!settings.historyEnabled) return;

    try {
      // Keep only up to MAX_HISTORY_ITEMS
      const trimmed = messages.slice(-MAX_HISTORY_ITEMS);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(trimmed));
    } catch (e) {
      console.warn('Could not save history to localStorage:', e);
    }
  }

  public static clearHistory(): void {
    try {
      localStorage.removeItem(HISTORY_KEY);
    } catch (e) {
      console.warn('Could not clear history:', e);
    }
  }
}
