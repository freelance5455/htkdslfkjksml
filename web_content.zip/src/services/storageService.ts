import { 
  Product, 
  SaleInvoice, 
  Expense, 
  PurchaseRecord, 
  StoreProfile, 
  UserRole,
  FirebaseSyncSettings,
  CustomerDueRecord
} from '../types';
import { 
  INITIAL_PRODUCTS, 
  INITIAL_INVOICES, 
  INITIAL_EXPENSES, 
  INITIAL_PURCHASES, 
  DEFAULT_STORE_PROFILE 
} from '../data/initialData';
import { firebaseService } from './firebaseService';

const STORAGE_KEYS = {
  PRODUCTS: 'mudir_dokan_products_v1',
  INVOICES: 'mudir_dokan_invoices_v1',
  EXPENSES: 'mudir_dokan_expenses_v1',
  PURCHASES: 'mudir_dokan_purchases_v1',
  PROFILE: 'mudir_dokan_profile_v1',
  ACTIVE_ROLE: 'mudir_dokan_role_v1',
  FIREBASE_SYNC: 'mudir_dokan_firebase_v1',
};

// Safe JSON get/set
function getStoredItem<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch (err) {
    console.error(`Failed to read ${key} from storage:`, err);
    return fallback;
  }
}

function setStoredItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Failed to write ${key} to storage:`, err);
  }
}

export const storageService = {
  // PRODUCTS
  getProducts(): Product[] {
    const stored = getStoredItem<Product[] | null>(STORAGE_KEYS.PRODUCTS, null);
    if (!stored || stored.length === 0) {
      setStoredItem(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
      return INITIAL_PRODUCTS;
    }
    return stored;
  },

  saveProducts(products: Product[]): void {
    setStoredItem(STORAGE_KEYS.PRODUCTS, products);
  },

  addProduct(product: Omit<Product, 'id'>): Product {
    const products = this.getProducts();
    const newProduct: Product = {
      ...product,
      id: 'prod-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
    };
    products.unshift(newProduct);
    this.saveProducts(products);
    // Background sync to Firebase Cloud
    firebaseService.syncProduct(newProduct).catch(() => {});
    return newProduct;
  },

  updateProduct(product: Product): void {
    const products = this.getProducts();
    const idx = products.findIndex(p => p.id === product.id);
    if (idx !== -1) {
      products[idx] = product;
      this.saveProducts(products);
      // Background sync to Firebase Cloud
      firebaseService.syncProduct(product).catch(() => {});
    }
  },

  deleteProduct(productId: string): void {
    const products = this.getProducts().filter(p => p.id !== productId);
    this.saveProducts(products);
    // Background sync to Firebase Cloud
    firebaseService.deleteProduct(productId).catch(() => {});
  },

  // Stock deduction upon sale
  deductStock(items: { productId: string; quantity: number }[]): void {
    const products = this.getProducts();
    let changed = false;
    items.forEach(item => {
      const prod = products.find(p => p.id === item.productId);
      if (prod) {
        prod.stock = Math.max(0, +(prod.stock - item.quantity).toFixed(2));
        changed = true;
        firebaseService.syncProduct(prod).catch(() => {});
      }
    });
    if (changed) {
      this.saveProducts(products);
    }
  },

  // Restock product / purchase record
  restockProduct(purchase: {
    productId: string;
    productName: string;
    quantity: number;
    unitCost: number;
    supplierName?: string;
    invoiceNo?: string;
  }): void {
    const products = this.getProducts();
    const prod = products.find(p => p.id === purchase.productId);
    if (prod) {
      prod.stock = +(prod.stock + purchase.quantity).toFixed(2);
      prod.purchasePrice = purchase.unitCost;
      this.saveProducts(products);
    }

    // Add purchase record for profit & loss tracking
    const purchases = this.getPurchases();
    const newPurchase: PurchaseRecord = {
      id: 'pur-' + Date.now(),
      date: new Date().toISOString(),
      productId: purchase.productId,
      productName: purchase.productName,
      supplierName: purchase.supplierName || 'আড়ত / সাধারণ সরবরাহকারী',
      quantity: purchase.quantity,
      unit: prod ? prod.unit : 'কেজি',
      unitCost: purchase.unitCost,
      totalCost: +(purchase.quantity * purchase.unitCost).toFixed(2),
      invoiceNo: purchase.invoiceNo || 'PUR-' + Math.floor(1000 + Math.random() * 9000),
    };
    purchases.unshift(newPurchase);
    setStoredItem(STORAGE_KEYS.PURCHASES, purchases);
  },

  // INVOICES
  getInvoices(): SaleInvoice[] {
    const stored = getStoredItem<SaleInvoice[] | null>(STORAGE_KEYS.INVOICES, null);
    if (!stored || stored.length === 0) {
      setStoredItem(STORAGE_KEYS.INVOICES, INITIAL_INVOICES);
      return INITIAL_INVOICES;
    }
    return stored;
  },

  saveInvoices(invoices: SaleInvoice[]): void {
    setStoredItem(STORAGE_KEYS.INVOICES, invoices);
  },

  addInvoice(invoice: Omit<SaleInvoice, 'id' | 'invoiceNo' | 'createdAt'>): SaleInvoice {
    const invoices = this.getInvoices();
    const date = new Date();
    const datePart = `${date.getFullYear().toString().slice(-2)}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`;
    const seq = String(invoices.length + 1).padStart(3, '0');
    const invoiceNo = `MEMO-${datePart}-${seq}`;

    const newInvoice: SaleInvoice = {
      ...invoice,
      id: 'inv-' + Date.now(),
      invoiceNo,
      createdAt: date.toISOString(),
    };

    invoices.unshift(newInvoice);
    this.saveInvoices(invoices);

    // Automatically update stock
    this.deductStock(invoice.items.map(i => ({ productId: i.productId, quantity: i.quantity })));

    // Background sync to Firebase Cloud
    firebaseService.syncInvoice(newInvoice).catch(() => {});

    return newInvoice;
  },

  updateInvoice(invoiceId: string, updatedFields: Partial<SaleInvoice>): SaleInvoice | null {
    const invoices = this.getInvoices();
    const index = invoices.findIndex(i => i.id === invoiceId);
    if (index === -1) return null;

    const oldInvoice = invoices[index];
    const updatedInvoice: SaleInvoice = {
      ...oldInvoice,
      ...updatedFields,
    };

    invoices[index] = updatedInvoice;
    this.saveInvoices(invoices);

    // Background sync to Firebase Cloud so all other devices update immediately
    firebaseService.syncInvoice(updatedInvoice).catch(() => {});

    return updatedInvoice;
  },

  updateDuePayment(invoiceId: string, paidMore: number, notes?: string): SaleInvoice | null {
    const invoices = this.getInvoices();
    const inv = invoices.find(i => i.id === invoiceId);
    if (!inv) return null;

    inv.paidAmount = +(inv.paidAmount + paidMore).toFixed(2);
    inv.dueAmount = Math.max(0, +(inv.dueAmount - paidMore).toFixed(2));
    if (inv.dueAmount === 0) {
      inv.status = 'PAID';
    } else {
      inv.status = 'PARTIAL';
    }
    if (notes) {
      inv.notes = (inv.notes ? inv.notes + ' | ' : '') + `পরিশোধ: ৳${paidMore} (${new Date().toLocaleDateString('bn-BD')})`;
    }
    this.saveInvoices(invoices);

    // Background sync to Firebase Cloud
    firebaseService.syncInvoice(inv).catch(() => {});

    return inv;
  },

  // EXPENSES
  getExpenses(): Expense[] {
    const stored = getStoredItem<Expense[] | null>(STORAGE_KEYS.EXPENSES, null);
    if (!stored || stored.length === 0) {
      setStoredItem(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
      return INITIAL_EXPENSES;
    }
    return stored;
  },

  addExpense(expense: Omit<Expense, 'id' | 'date'>): Expense {
    const expenses = this.getExpenses();
    const newExpense: Expense = {
      ...expense,
      id: 'exp-' + Date.now(),
      date: new Date().toISOString(),
    };
    expenses.unshift(newExpense);
    setStoredItem(STORAGE_KEYS.EXPENSES, expenses);
    // Background sync to Firebase Cloud
    firebaseService.syncExpense(newExpense).catch(() => {});
    return newExpense;
  },

  deleteExpense(id: string): void {
    const expenses = this.getExpenses().filter(e => e.id !== id);
    setStoredItem(STORAGE_KEYS.EXPENSES, expenses);
  },

  // PURCHASES
  getPurchases(): PurchaseRecord[] {
    const stored = getStoredItem<PurchaseRecord[] | null>(STORAGE_KEYS.PURCHASES, null);
    if (!stored || stored.length === 0) {
      setStoredItem(STORAGE_KEYS.PURCHASES, INITIAL_PURCHASES);
      return INITIAL_PURCHASES;
    }
    return stored;
  },

  addPurchase(purchase: Omit<PurchaseRecord, 'id' | 'date'>): PurchaseRecord {
    const purchases = this.getPurchases();
    const newPurchase: PurchaseRecord = {
      ...purchase,
      id: 'pur-' + Date.now(),
      date: new Date().toISOString(),
    };
    purchases.unshift(newPurchase);
    setStoredItem(STORAGE_KEYS.PURCHASES, purchases);

    // Increase product stock
    const products = this.getProducts();
    const prod = products.find(p => p.id === purchase.productId);
    if (prod) {
      prod.stock = +(prod.stock + purchase.quantity).toFixed(2);
      prod.purchasePrice = purchase.unitCost;
      this.saveProducts(products);
      firebaseService.syncProduct(prod).catch(() => {});
    }

    // Background sync to Firebase Cloud
    firebaseService.syncPurchase(newPurchase).catch(() => {});

    return newPurchase;
  },

  // CUSTOMER DUES (বাকির খাতা)
  getCustomerDues(): CustomerDueRecord[] {
    const invoices = this.getInvoices();
    const dueInvoices = invoices.filter(i => i.dueAmount > 0 && i.customerName);
    
    const customerMap: Record<string, CustomerDueRecord> = {};
    dueInvoices.forEach(inv => {
      const key = `${inv.customerName?.trim()}_${inv.customerPhone?.trim() || ''}`;
      if (!customerMap[key]) {
        customerMap[key] = {
          customerName: inv.customerName || 'বেনামী ক্রেতা',
          customerPhone: inv.customerPhone || 'প্রযোজ্য নয়',
          totalDue: 0,
          invoices: [],
          lastPaymentDate: inv.createdAt,
        };
      }
      customerMap[key].totalDue += inv.dueAmount;
      customerMap[key].invoices.push({
        invoiceId: inv.id,
        invoiceNo: inv.invoiceNo,
        date: inv.createdAt,
        dueAmount: inv.dueAmount,
        subtotal: inv.subtotal,
        paidAmount: inv.paidAmount,
        notes: inv.notes,
        items: inv.items || [],
      });
    });

    return Object.values(customerMap);
  },

  // PROFILE & SETTINGS
  getStoreProfile(): StoreProfile {
    const profile = getStoredItem<StoreProfile>(STORAGE_KEYS.PROFILE, DEFAULT_STORE_PROFILE);
    if (!profile || profile.name === 'তাজা মুদি বাজার ও জেনারেল স্টোর') {
      const updated: StoreProfile = {
        ...DEFAULT_STORE_PROFILE,
        name: 'ইউনিফোর ট্রেডিং এন্ড সাপ্লাই',
        phone: '০১৮৮৬১০০৮০২',
        address: 'চন্দ্রিমা হাউজিং, কোলাতলী, কক্সবাজার',
      };
      setStoredItem(STORAGE_KEYS.PROFILE, updated);
      return updated;
    }
    return profile;
  },

  saveStoreProfile(profile: StoreProfile): void {
    setStoredItem(STORAGE_KEYS.PROFILE, profile);
    // Background sync to Firebase Cloud
    firebaseService.syncProfile(profile).catch(() => {});
  },

  saveStoreProfileLocally(profile: StoreProfile): void {
    setStoredItem(STORAGE_KEYS.PROFILE, profile);
  },

  // ROLES
  getActiveRole(): UserRole {
    return getStoredItem<UserRole>(STORAGE_KEYS.ACTIVE_ROLE, 'OWNER');
  },

  setActiveRole(role: UserRole): void {
    setStoredItem(STORAGE_KEYS.ACTIVE_ROLE, role);
  },

  // FIREBASE CLOUD SYNC CONFIG
  getFirebaseSyncSettings(): FirebaseSyncSettings {
    return getStoredItem<FirebaseSyncSettings>(STORAGE_KEYS.FIREBASE_SYNC, {
      isConfigured: true,
      apiKey: 'AIzaSyBINvmGL4rSOaujmjeU6ieU3GTso5D7-Nw',
      projectId: 'unifour1211',
      autoSync: true,
    });
  },

  saveFirebaseSyncSettings(settings: FirebaseSyncSettings): void {
    setStoredItem(STORAGE_KEYS.FIREBASE_SYNC, settings);
  },

  // EXPORT / IMPORT BACKUP
  exportBackupData(): string {
    const data = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      storeProfile: this.getStoreProfile(),
      products: this.getProducts(),
      invoices: this.getInvoices(),
      expenses: this.getExpenses(),
      purchases: this.getPurchases(),
      firebaseSettings: this.getFirebaseSyncSettings(),
    };
    return JSON.stringify(data, null, 2);
  },

  importBackupData(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.products && Array.isArray(parsed.products)) {
        this.saveProducts(parsed.products);
      }
      if (parsed.invoices && Array.isArray(parsed.invoices)) {
        this.saveInvoices(parsed.invoices);
      }
      if (parsed.expenses && Array.isArray(parsed.expenses)) {
        setStoredItem(STORAGE_KEYS.EXPENSES, parsed.expenses);
      }
      if (parsed.purchases && Array.isArray(parsed.purchases)) {
        setStoredItem(STORAGE_KEYS.PURCHASES, parsed.purchases);
      }
      if (parsed.storeProfile) {
        this.saveStoreProfile(parsed.storeProfile);
      }
      if (parsed.firebaseSettings) {
        this.saveFirebaseSyncSettings(parsed.firebaseSettings);
      }
      return true;
    } catch (e) {
      console.error('Import failed:', e);
      return false;
    }
  },

  resetToDefault(): void {
    localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
    localStorage.removeItem(STORAGE_KEYS.INVOICES);
    localStorage.removeItem(STORAGE_KEYS.EXPENSES);
    localStorage.removeItem(STORAGE_KEYS.PURCHASES);
    localStorage.removeItem(STORAGE_KEYS.PROFILE);
    localStorage.removeItem(STORAGE_KEYS.FIREBASE_SYNC);
  }
};
