/**
 * Achievements & Player Progression Service
 * Tracks verified achievements, cosmetic unlocks (board materials & piece styles),
 * XP levels, titles, and streaks with idempotent reward unlocking.
 */

import { AchievementItem, PlayerProgression } from '../types/chess';

const ACHIEVEMENTS_STORAGE_KEY = 'chess3d_achievements_v5';
const PROGRESSION_STORAGE_KEY = 'chess3d_progression_v5';

export const ALL_ACHIEVEMENTS: AchievementItem[] = [
  {
    id: 'first_checkmate',
    name: 'First Checkmate',
    description: 'Deliver checkmate in any mode to claim your first decisive victory.',
    category: 'combat',
    icon: '👑',
    rewardXp: 50,
    rewardBadge: 'Mate Initiator',
    targetCount: 1,
    progress: 1,
    isUnlocked: true,
    unlockedAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'first_online_win',
    name: 'First Online Victory',
    description: 'Defeat a real player in online multiplayer.',
    category: 'combat',
    icon: '⚔️',
    rewardXp: 100,
    rewardBadge: 'Gladiator',
    targetCount: 1,
    progress: 1,
    isUnlocked: true,
    unlockedAt: new Date(Date.now() - 43200000).toISOString(),
  },
  {
    id: 'ten_rated_wins',
    name: 'Ten Rated Wins',
    description: 'Achieve 10 victorious rated matches across any time control.',
    category: 'combat',
    icon: '🔥',
    rewardXp: 200,
    rewardBadge: 'Tenacious Victor',
    targetCount: 10,
    progress: 6,
    isUnlocked: false,
  },
  {
    id: 'hundred_games',
    name: 'Century Club',
    description: 'Complete 100 chess matches on your journey.',
    category: 'combat',
    icon: '💯',
    rewardXp: 500,
    rewardBadge: 'Centurion',
    targetCount: 100,
    progress: 34,
    isUnlocked: false,
  },
  {
    id: 'puzzle_solver',
    name: 'Puzzle Solver',
    description: 'Solve 10 tactical puzzles correctly.',
    category: 'tactics',
    icon: '🧩',
    rewardXp: 150,
    rewardBadge: 'Tactical Mind',
    targetCount: 10,
    progress: 8,
    isUnlocked: false,
  },
  {
    id: 'tactical_specialist',
    name: 'Tactical Specialist',
    description: 'Successfully execute 5 forks, pins, or skewers in games.',
    category: 'tactics',
    icon: '⚡',
    rewardXp: 250,
    rewardBadge: 'Sharp Eye',
    targetCount: 5,
    progress: 3,
    isUnlocked: false,
  },
  {
    id: 'endgame_learner',
    name: 'Endgame Virtuoso',
    description: 'Complete 5 endgame drills with 100% precision.',
    category: 'mastery',
    icon: '♟️',
    rewardXp: 200,
    rewardBadge: 'Pawn Artist',
    targetCount: 5,
    progress: 2,
    isUnlocked: false,
  },
  {
    id: 'tournament_participant',
    name: 'Arena Contender',
    description: 'Enter and finish your first online tournament.',
    category: 'tournaments',
    icon: '🏟️',
    rewardXp: 200,
    rewardBadge: 'Tournament Pioneer',
    targetCount: 1,
    progress: 1,
    isUnlocked: true,
    unlockedAt: new Date().toISOString(),
  },
  {
    id: 'tournament_champion',
    name: 'Tournament Champion',
    description: 'Finish 1st place in any official tournament bracket or arena.',
    category: 'tournaments',
    icon: '🏆',
    rewardXp: 1000,
    rewardBadge: 'Grand Champion',
    targetCount: 1,
    progress: 0,
    isUnlocked: false,
  },
  {
    id: 'seven_day_streak',
    name: 'Weekly Devotion',
    description: 'Maintain a 7-day training and gameplay streak.',
    category: 'progression',
    icon: '🗓️',
    rewardXp: 300,
    rewardBadge: 'Unbroken Spirit',
    targetCount: 7,
    progress: 4,
    isUnlocked: false,
  },
  {
    id: 'thirty_day_streak',
    name: 'Grandmaster Discipline',
    description: 'Maintain a 30-day training streak.',
    category: 'progression',
    icon: '💎',
    rewardXp: 1500,
    rewardBadge: 'Legendary Dedication',
    targetCount: 30,
    progress: 4,
    isUnlocked: false,
  },
];

export const COSMETIC_REWARDS = [
  {
    id: 'wood_classic',
    name: 'Classic Walnut & Maple',
    type: 'board',
    levelReq: 1,
    unlocked: true,
    previewColor: '#8B5A2B',
  },
  {
    id: 'onyx_gold',
    name: 'Imperial Onyx & Gold',
    type: 'board',
    levelReq: 3,
    unlocked: true,
    previewColor: '#D4AF37',
  },
  {
    id: 'cyber_neon',
    name: 'Electric Cyberpunk Board',
    type: 'board',
    levelReq: 5,
    unlocked: false,
    previewColor: '#00F0FF',
  },
  {
    id: 'royal_marble',
    name: 'Carrara & Emerald Marble',
    type: 'board',
    levelReq: 8,
    unlocked: false,
    previewColor: '#10B981',
  },
  {
    id: 'pieces_classic',
    name: 'Staunton Tournament Edition',
    type: 'pieces',
    levelReq: 1,
    unlocked: true,
    previewColor: '#FFFFFF',
  },
  {
    id: 'pieces_cyber',
    name: 'Holographic Tron Pieces',
    type: 'pieces',
    levelReq: 6,
    unlocked: false,
    previewColor: '#38BDF8',
  },
];

class AchievementService {
  private achievements: AchievementItem[] = [];
  private progression: PlayerProgression = {
    xp: 420,
    level: 3,
    levelTitle: 'Rising Contender',
    xpToNextLevel: 500,
    currentLevelProgressPercent: 84,
    streakDays: 4,
    maxStreakDays: 12,
    unlockedThemes: ['wood_classic', 'onyx_gold'],
    unlockedPieceStyles: ['pieces_classic'],
  };

  constructor() {
    this.loadState();
  }

  private loadState(): void {
    try {
      const storedAch = localStorage.getItem(ACHIEVEMENTS_STORAGE_KEY);
      if (storedAch) {
        this.achievements = JSON.parse(storedAch);
      } else {
        this.achievements = [...ALL_ACHIEVEMENTS];
      }

      const storedProg = localStorage.getItem(PROGRESSION_STORAGE_KEY);
      if (storedProg) {
        this.progression = JSON.parse(storedProg);
      }
    } catch {
      this.achievements = [...ALL_ACHIEVEMENTS];
    }
  }

  private saveState(): void {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(ACHIEVEMENTS_STORAGE_KEY, JSON.stringify(this.achievements));
      localStorage.setItem(PROGRESSION_STORAGE_KEY, JSON.stringify(this.progression));
    } catch (e) {
      console.warn('Failed to cache achievement state:', e);
    }
  }

  public getAchievements(): AchievementItem[] {
    return [...this.achievements];
  }

  public getProgression(): PlayerProgression {
    return { ...this.progression };
  }

  /**
   * Award XP and calculate level progression
   */
  public addXp(amount: number): { levelUp: boolean; newLevel: number; newTitle: string } {
    this.progression.xp += amount;

    // Level curve: 150 * level
    const xpForLevel = (lvl: number) => lvl * 200;
    let currentLvl = this.progression.level;
    let leveledUp = false;

    while (this.progression.xp >= xpForLevel(currentLvl)) {
      currentLvl++;
      leveledUp = true;
    }

    this.progression.level = currentLvl;
    const titles = ['Novice', 'Apprentice', 'Rising Contender', 'Tactician', 'Club Fighter', 'Master Strategist', 'Grandmaster'];
    this.progression.levelTitle = titles[Math.min(currentLvl - 1, titles.length - 1)];

    const targetXp = xpForLevel(currentLvl);
    const prevXp = xpForLevel(currentLvl - 1);
    this.progression.xpToNextLevel = targetXp;
    this.progression.currentLevelProgressPercent = Math.min(
      100,
      Math.max(0, Math.round(((this.progression.xp - prevXp) / (targetXp - prevXp)) * 100))
    );

    // Auto unlock eligible cosmetics
    COSMETIC_REWARDS.forEach((cosmetic) => {
      if (currentLvl >= cosmetic.levelReq) {
        cosmetic.unlocked = true;
        if (cosmetic.type === 'board' && !this.progression.unlockedThemes.includes(cosmetic.id)) {
          this.progression.unlockedThemes.push(cosmetic.id);
        } else if (cosmetic.type === 'pieces' && !this.progression.unlockedPieceStyles.includes(cosmetic.id)) {
          this.progression.unlockedPieceStyles.push(cosmetic.id);
        }
      }
    });

    this.saveState();
    return { levelUp: leveledUp, newLevel: currentLvl, newTitle: this.progression.levelTitle };
  }

  /**
   * Unlock achievement by ID (Idempotent: unlocks only once)
   */
  public unlockAchievement(id: string): { unlocked: boolean; achievement?: AchievementItem } {
    const ach = this.achievements.find((a) => a.id === id);
    if (!ach || ach.isUnlocked) {
      return { unlocked: false };
    }

    ach.isUnlocked = true;
    ach.progress = ach.targetCount;
    ach.unlockedAt = new Date().toISOString();
    this.addXp(ach.rewardXp);

    this.saveState();
    return { unlocked: true, achievement: ach };
  }

  /**
   * Increment achievement progress toward target
   */
  public incrementProgress(id: string, delta = 1): { unlocked: boolean; achievement?: AchievementItem } {
    const ach = this.achievements.find((a) => a.id === id);
    if (!ach || ach.isUnlocked) return { unlocked: false };

    ach.progress = Math.min(ach.targetCount, ach.progress + delta);
    if (ach.progress >= ach.targetCount) {
      return this.unlockAchievement(id);
    }

    this.saveState();
    return { unlocked: false, achievement: ach };
  }
}

export const achievementService = new AchievementService();
