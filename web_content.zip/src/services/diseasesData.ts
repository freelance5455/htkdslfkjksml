/**
 * HELENA - Veterinary Pathology & Clinical Disease Library Data
 * Comprehensive clinical reference for small animals (canine, feline)
 * and large animals (equine, bovine).
 */

import { VeterinaryDiseaseItem } from '../types';

export const VETERINARY_DISEASES: VeterinaryDiseaseItem[] = [
  // -------------------------------------------------------------
  // CANINOS (CÃES)
  // -------------------------------------------------------------
  {
    id: 'cinomose_canina',
    nome: 'Cinomose Canina',
    nomeCientifico: 'Canine Distemper Virus (CDV - Morbillivirus)',
    especies: ['cão'],
    categoria: 'Infecciosa',
    gravidade: 'Urgência',
    causa: 'Vírus de RNA envelopado da família Paramyxoviridae, gênero Morbillivirus. Altamente contagioso por via aerógena (secreções respiratórias, aerossóis e fômites).',
    transmissao: 'Inalação de gotículas e aerossóis contendo o vírus, contato direto com secreções oculonasais de cães infectados ou fômites contaminados.',
    sinaisClinicos: [
      'Fase Catarral/Respiratória: febre bifásica, secreção oculonasal serosa a mucopurulenta, tosse, pneumonia secundária.',
      'Fase Digestória: vômito, diarreia aquosa a hemorrágica, desidratação, anorexia.',
      'Fase Cutânea: hiperqueratose dos coxins plantares e trufa nasal ("hard pad disease"), pústulas abdominais.',
      'Fase Neurológica: mioclonias musculares rítmicas características, ataxia, convulsões com mastigação de chiclete ("chewing-gum fits"), paresia ou paralisia.'
    ],
    diagnostico: 'Histórico clínico e vacinal, RT-PCR em sangue total, swab conjuntival ou líquor, sorologia (IgM), inclusões intracitoplasmáticas (corpúsculos de Lentz) em esfregaço de sangue ou raspado conjuntival.',
    tratamento: 'Não há antiviral específico curativo. Terapia de suporte intensiva: fluidoterapia balanceada (Ringer Lactato), antibióticos de amplo espectro para infecções secundárias (ampicilina, ceftriaxona), anticonvulsivantes e sedativos (fenobarbital, levetiracetam), neuroprotetores (vitaminas do complexo B, vitamina A, antioxidantes).',
    prevencao: 'Vacinação sistemática essencial de filhotes e reforço anual com vacinas polivalentes (V8 ou V10). Quarentena de animais doentes e desinfecção com hipoclorito de sódio a 1%.',
    notificacaoObrigatoria: false
  },
  {
    id: 'parvovirose_canina',
    nome: 'Parvovirose Canina',
    nomeCientifico: 'Canine Parvovirus Type 2 (CPV-2)',
    especies: ['cão'],
    categoria: 'Infecciosa',
    gravidade: 'Urgência',
    causa: 'Parvovírus canino tipo 2 (CPV-2a, 2b, 2c). Vírus de DNA não envelopado extremamente resistente no ambiente (persiste meses). Tropismo por células de rápida divisão (criptas intestinais e medula óssea).',
    transmissao: 'Via fecal-oral através da ingestão de fezes ou fômites contaminados (calçados, potes, gaiolas).',
    sinaisClinicos: [
      'Enterite hemorrágica profusa com odor fétido sui generis característico.',
      'Vômitos incoercíveis e refratários, desidratação hiperaguda grave e choque hipovolêmico.',
      'Febre ou hipotermia na sepse, letargia intensa e dor abdominal pronunciada.',
      'Panleucopenia severa (linfopenia e neutropenia profunda marcadas).'
    ],
    diagnostico: 'Teste rápido imunocromatográfico de antígeno fecal (ELISA/lateral flow), PCR fecal, hemograma completo demonstrando leucopenia severa (< 3.000 leucócitos/μL).',
    tratamento: 'Isolamento estrito. Terapia de emergência imediata: fluidoterapia intravenosa intensa para reposição de perdas e eletrólitos (KCl suplementado), antieméticos potentes (maropitant 1 mg/kg SID e ondansetrona), protetores gástricos, antibioticoterapia parenteral de amplo espectro (ampicilina + enrofloxacina ou metronidazol) para prevenir translocação bacteriana e sepse, nutrição enteral precoce por sonda assim que cessarem os vômitos.',
    prevencao: 'Protocolo rigoroso de imunização inicial de filhotes a partir das 6-8 semanas com reforços a cada 21-28 dias até as 16 semanas. Desinfecção ambiental com hipoclorito de sódio ou monopersulfato de potássio.',
    notificacaoObrigatoria: false
  },
  {
    id: 'leishmaniose_canina',
    nome: 'Leishmaniose Visceral Canina',
    nomeCientifico: 'Leishmania infantum (syn. L. chagasi)',
    especies: ['cão'],
    categoria: 'Parasitária',
    gravidade: 'Alta',
    causa: 'Protozoário parasita intracelular obrigatório do sistema fagocítico mononuclear. Zoonose grave de saúde pública transmitida por vetores flebotomíneos.',
    transmissao: 'Picada de fêmeas infectadas do inseto vetor flebótomo Lutzomyia longipalpis ("mosquito-palha" ou "birigui"). Transmissão venérea e transplacentária também descritas.',
    sinaisClinicos: [
      'Lesões dermatológicas: alopecia periocular ("óculos"), descamação seca furfurácea, úlceras em proeminências ósseas e pontas das orelhas.',
      'Onicogrifose (crescimento exacerbado e encurvado das unhas).',
      'Linfoadenomegalia generalizada, hepatoesplenomegalia e caquexia progressiva.',
      'Glomerulonefrite por imunocomplexos com proteinúria e insuficiência renal crônica.',
      'Ceratoconjuntivite seca, uveíte anterior e epistaxe unilateral ou bilateral.'
    ],
    diagnostico: 'Triagem sorológica por DPP (Dual Path Platform) e confirmação por ELISA quantitativo ou RIFI; citologia de linfonodo, medula óssea ou pele revelando formas amastigotas no interior de macrófagos; qPCR tecidual.',
    tratamento: 'No Brasil, regulamentado por protocolo oficial: Miltefosina oral (2 mg/kg SID por 28 dias), associada ao Alopurinol (10 mg/kg BID contínuo) para controle leishmanistático da carga parasitária, e Domperidona/imunomoduladores. Manejo de suporte das complicações renais e hepáticas. Não há cura parasitológica definitiva.',
    prevencao: 'Uso ininterrupto de coleiras impregnadas com inseticidas repelentes (deltametrina a 4%), vacinação com vacinas recombinantes registradas, controle do ambiente com recolhimento de matéria orgânica e telas finas nos canis.',
    notificacaoObrigatoria: true
  },
  {
    id: 'erliquiose_canina',
    nome: 'Erliquiose Canina (Doença do Carrapato)',
    nomeCientifico: 'Ehrlichia canis',
    especies: ['cão'],
    categoria: 'Infecciosa',
    gravidade: 'Moderada',
    causa: 'Bactéria intracelular obrigatória gram-negativa da família Anaplasmataceae com tropismo específico por monócitos e macrófagos.',
    transmissao: 'Transmissão biológica pela picada do carrapato-marrom-do-cão (Rhipicephalus sanguineus) infectado durante repasto sanguíneo.',
    sinaisClinicos: [
      'Fase Aguda: febre alta intermitente, apatia, trombocitopenia acentuada, petéquias e equimoses na pele e mucosas, uveíte, epistaxe espontânea.',
      'Fase Subclínica: assintomática por meses a anos, persistência de discreta trombocitopenia e hipergamaglobulinemia.',
      'Fase Crônica: pancitopenia severa por hipoplasia de medula óssea, hemorragias recorrentes, edema periférico, suscetibilidade a infecções oportunistas graves.'
    ],
    diagnostico: 'Visualização de mórulas de Ehrlichia no interior de monócitos em capa leucocitária ou esfregaço de ponta de orelha; sorologia (ELISA, IFI) e detecção por PCR em sangue periférico.',
    tratamento: 'Doxiciclina na dose de 10 mg/kg via oral a cada 24 horas (ou 5 mg/kg a cada 12h) durante 28 dias ininterruptos. Suporte hematológico com transfusão sanguínea em casos de anemia/trombocitopenia crítica, e protetores gástricos.',
    prevencao: 'Controle contínuo de ectoparasitas com moléculas de liberação prolongada (isoxazolinas orais como fluralaner, afoxolaner, sarolaner) e desinfecção ambiental das instalações.',
    notificacaoObrigatoria: false
  },
  {
    id: 'dirofilariose_canina',
    nome: 'Dirofilariose (Verme do Coração)',
    nomeCientifico: 'Dirofilaria immitis',
    especies: ['cão', 'gato'],
    categoria: 'Parasitária',
    gravidade: 'Alta',
    causa: 'Nematódeo filarídeo cujos vermes adultos habitam o tronco pulmonar, artérias lobares pulmonares e o ventrículo direito de carnívoros.',
    transmissao: 'Picada de mosquitos vetores dos gêneros Culex, Aedes e Anopheles inoculando larvas no estágio L3.',
    sinaisClinicos: [
      'Tosse crônica persistente e intolerância progressiva ao exercício físico.',
      'Hipertensão pulmonar, insuficiência cardíaca congestiva direita (ascite, ingurgitamento jugular, hepatomegalia).',
      'Síndrome da veia cava (caval syndrome): obstrução súbita da valva tricúspide por vermes adultos causando hemólise intravascular aguda, hemoglobinúria e choque cardiogênico.'
    ],
    diagnostico: 'Teste rápido de antígeno de fêmea adulta de Dirofilaria immitis, teste de Knott modificado para identificação de microfilárias circulantes, ecocardiograma e radiografia torácica (dilatação do arco aórtico/pulmonar).',
    tratamento: 'Protocolo multimodal rigoroso da American Heartworm Society: Doxiciclina por 30 dias (para eliminar a endossimbionte Wolbachia) + lactona macrocíclica mensal; seguido de injeções intramusculares profundas de Dicloridrato de Melarsomina na musculatura epaxial lombar; repouso físico absoluto obrigatório para evitar tromboembolismo pulmonar.',
    prevencao: 'Profilaxia mensal ininterrupta com lactonas macrocíclicas (ivermectina, milbemicina oxima, moxidectina) a partir de 6-8 semanas de vida em áreas endêmicas litorâneas e fluviais.',
    notificacaoObrigatoria: false
  },
  {
    id: 'displasia_coxofemoral',
    nome: 'Displasia Coxofemoral Canina',
    nomeCientifico: 'Canine Hip Dysplasia (CHD)',
    especies: ['cão'],
    categoria: 'Osteoarticular',
    gravidade: 'Crônica',
    causa: 'Doença ortopédica do desenvolvimento de origem multifatorial e poligênica, com forte influência da taxa de crescimento, nutrição hipercalórica e sobrecarga mecânica na infância.',
    transmissao: 'Hereditária poligênica (não infecciosa).',
    sinaisClinicos: [
      'Claudicação de membros pélvicos, rigidez articular ao levantar e marcha com "passo de coelho" (bunny hopping).',
      'Dor à extensão e abdução dos quadris, atrofia muscular glútea progressiva.',
      'Sinal de Ortolani positivo no exame físico ortopédico de filhotes e jovens.'
    ],
    diagnostico: 'Exame físico ortopédico e exame radiográfico ventrodorsal da pelve sob sedação profunda para avaliação do Índice de Distração (PennHIP) ou método de Norberg (ângulo de Norberg < 105° e incongruência articular).',
    tratamento: 'Conservador: controle rígido do peso corporal, fisioterapia e reabilitação aquática, condroprotetores (glicosamina, sulfato de condroitina, colágeno tipo II), analgésicos e AINEs (meloxicam, firocoxibe) ou anticorpos monoclonais anti-NGF (bedinvetmab). Cirúrgico: sinfisiodese púbica juvenil (filhotes), osteotomia pélvica dupla/tripla, colocefalectomia (excisão da cabeça e colo femorais) ou artroplastia total da articulação coxofemoral.',
    prevencao: 'Controle genealógico reprodutivo (seleção de reprodutores livres radiologicamente), controle nutricional rigoroso durante a fase de crescimento rápido em raças grandes e gigantes.',
    notificacaoObrigatoria: false
  },

  // -------------------------------------------------------------
  // FELINOS (GATOS)
  // -------------------------------------------------------------
  {
    id: 'pif_felina',
    nome: 'Peritonite Infecciosa Felina (PIF)',
    nomeCientifico: 'Feline Infectious Peritonitis (FCoV mutado)',
    especies: ['gato'],
    categoria: 'Infecciosa',
    gravidade: 'Urgência',
    causa: 'Mutação espontânea do Coronavírus Entérico Felino (FCoV) em cepa virulenta com capacidade de infectar e replicar massivamente dentro de macrófagos, desencadeando vasculite mediada por imunocomplexos.',
    transmissao: 'O coronavírus entérico é transmitido via fecal-oral (caixas de areia). A mutação para PIF ocorre individualmente no gato infectado sob estresse ou falha imunológica.',
    sinaisClinicos: [
      'Forma Efusiva (Úmida): ascite abdominal progressiva não dolorosa com fluido amarelo-palha viscoso, efusão pleural com dispneia e taquipneia, febre flutuante refratária a antibióticos.',
      'Forma Não-Efusiva (Seca): granulomas piogranulomatosos em órgãos abdominais (rins, linfonodos mesentéricos), uveíte anterior com precipitados ceráticos, alterações neurológicas (ataxia, convulsões, nistagmo).',
      'Emagrecimento progressivo, icterícia e hipoalbuminemia com hiperglobulinemia (relação A:G < 0,6).'
    ],
    diagnostico: 'Análise de efusão com Teste de Rivalta positivo e dosagem proteica elevada (> 3,5 g/dL); dosagem da relação Albumina:Globulina sérica; RT-qPCR para coronavírus mutado; histopatologia com imuno-histoquímica para confirmação definitiva.',
    tratamento: 'Antiviral análogo de nucleosídeo GS-441524 (ou Remdesivir) por via oral ou subcutânea diária durante 84 dias consecutivos com monitoramento de perfil renal e hepático. Suporte clínico com drenagem torácica descompressiva se houver efusão pleural, fluidoterapia e anti-inflamatórios.',
    prevencao: 'Redução de superlotação em gatis, higienização rigorosa e isolamento de bandejas sanitárias, controle do estresse ambiental.',
    notificacaoObrigatoria: false
  },
  {
    id: 'felv_felina',
    nome: 'FeLV (Vírus da Leucemia Felina)',
    nomeCientifico: 'Feline Leukemia Virus (Retroviridae, Gammaretrovirus)',
    especies: ['gato'],
    categoria: 'Infecciosa',
    gravidade: 'Alta',
    causa: 'Retrovírus envelopado oncogênico que infecta células precursoras hematopoiéticas e linfoides, integrando seu provírus ao genoma do hospedeiro.',
    transmissao: 'Chamado de "vírus dos amigos": transmitido pelo contato íntimo e prolongado através da saliva durante lambedura mútua (grooming), compartilhamento de bebedouros, mordeduras, amamentação e via transplacentária.',
    sinaisClinicos: [
      'Anemia severa arregenerativa ou regenerativa mediada por imunocomplexos.',
      'Linfoma mediastinal, tímico, renal ou multicêntrico e leucemias linfoides.',
      'Imunossupressão profunda com gengivite/estomatite crônica refratária e infecções bacterianas oportunistas recorrentes.',
      'Febre persistente, glomerulonefrite e abortamento.'
    ],
    diagnostico: 'Triagem sorológica por ELISA ou imunocromatografia rápida para detecção do antígeno p27 circulante; confirmação do status progressivo, regressivo ou abortivo por PCR de DNA proviral em sangue total.',
    tratamento: 'Não há cura virológica. Manejo imunomodulador com Interferon-ômega felino recombinante, controle de infecções secundárias com antibióticos de escolha, transfusões sanguíneas de suporte em anemias graves, quimioterapia (protocolo COP ou CHOP) para linfomas.',
    prevencao: 'Testagem prévia de todos os gatos antes da introdução no domicílio. Manutenção do felino estritamente domiciliado (indoor) sem acesso à rua. Vacinação com vacina recombinante contra FeLV para gatos com risco de exposição.',
    notificacaoObrigatoria: false
  },
  {
    id: 'lipidose_hepatica_felina',
    nome: 'Lipidose Hepática Felina',
    nomeCientifico: 'Hepatic Lipidosis (Feline Fatty Liver Syndrome)',
    especies: ['gato'],
    categoria: 'Metabólica',
    gravidade: 'Urgência',
    causa: 'Acúmulo excessivo e descompensado de triglicerídeos nos hepatócitos de gatos (tipicamente obesos) que passam por período de anorexia aguda de 2 a 7 dias, desencadeando mobilização maciça de ácidos graxos do tecido adiposo periférico que o fígado não consegue oxidar.',
    transmissao: 'Distúrbio metabólico nutricional adquirido (não infeccioso).',
    sinaisClinicos: [
      'Icterícia marcante nas mucosas, pele e esclera.',
      'Perda de peso aguda e desidratação em gato previamente com sobrepeso ou obeso.',
      'Vômitos, salivação espumosa, ptialismo, fraqueza cervical (ventroflexão do pescoço por hipocalemia).',
      'Encefalopatia hepática em estágios avançados.'
    ],
    diagnostico: 'Perfil bioquímico: aumento expressivo da Fosfatase Alcalina (FA) com GGT normal ou discretamente elevada (dissociação FA/GGT característica); hiperbilirrubinemia; ultrassonografia abdominal mostrando fígado difusamente hiperecogênico e hepatomegalia; citologia aspirativa por agulha fina (PAAF) revelando vacuolização lipídica em mais de 50% dos hepatócitos.',
    tratamento: 'Suporte nutricional enteral forçado e agressivo IMEDIATO via sonda esofagostômica (o gato NÃO pode permanecer em jejum sob hipótese alguma). Fluidoterapia balanceada intravenosa suplementada com Cloreto de Potássio (KCl) e Fosfato; reposição de Vitamina K1, Vitamina B12 e L-carnitina; antieméticos (maropitant) e protetores hepáticos (S-adenosilmetionina - SAMe).',
    prevencao: 'Prevenção da obesidade em gatos domésticos, transição alimentar gradual e intervenção clínica imediata frente a qualquer quadro de hiporexia ou anorexia que dure mais de 24 horas.',
    notificacaoObrigatoria: false
  },
  {
    id: 'obstrucao_uretral_felina',
    nome: 'Doença do Trato Urinário & Obstrução Uretral',
    nomeCientifico: 'Feline Lower Urinary Tract Disease (FLUTD / FIC)',
    especies: ['gato'],
    categoria: 'Gastrointestinal',
    gravidade: 'Urgência',
    causa: 'Obstrução física do lúmen uretral peniano de felinos machos por plugs uretrais (matriz proteica celular + cristais de estruvita ou oxalato de cálcio), urólitos ou espasmo funcional associado à Cistite Idiopática Felina (FIC).',
    transmissao: 'Patologia multifatorial obstrutiva e inflamatória.',
    sinaisClinicos: [
      'Estrangúria, disúria, periúria e vocalização dolorosa na caixa de areia.',
      'Bexiga palpável extremamente distendida, rígida e dolorosa ("bola de boliche").',
      'Vômitos, letargia, bradicardia severa decorrente de hipercalemia aguda e choque urêmico.'
    ],
    diagnostico: 'Palpação abdominal da vesícula urinária tensa e repleta; dosagem de ureia, creatinina e potássio sérico (hipercalemia ameaçadora à vida); urinálise e sedimentoscopia; radiografia e ultrassonografia para pesquisa de cálculos e espessamento de parede vesical.',
    tratamento: 'Emergência médica: desobstrução uretral cuidadosa com sonda uretral tomcat sob sedação apropriada, fluidoterapia IV para correção da uremia pós-renal e arritmias, analgesia profunda com opioides (buprenorfina), relaxantes musculares uretrais (prazosina ou fenoxibenzamina), lavagem vesical com soro estéril. Cirurgia de uretrostomia perineal em obstruções recorrentes.',
    prevencao: 'Estímulo intenso ao consumo de água (fontes de água corrente, alimento úmido em sachês/latas), manejo ambiental antiestresse (MEMO) e dietas urinárias para controle do pH urinário.',
    notificacaoObrigatoria: false
  },

  // -------------------------------------------------------------
  // EQUINOS (CAVALOS)
  // -------------------------------------------------------------
  {
    id: 'sindrome_colica_equina',
    nome: 'Síndrome Cólica Equina (Abdômen Agudo)',
    nomeCientifico: 'Acute Abdominal Syndrome in Equines',
    especies: ['cavalo'],
    categoria: 'Gastrointestinal',
    gravidade: 'Urgência',
    causa: 'Distúrbio funcional ou obstrutivo do trato gastrointestinal equino: cólica espasmódica, compactação do cólon maior/ceco, deslocamento de cólon, vólvulo intestinal, estrangulamento por lipoma pedunculado ou aprisionamento no forâmen epiploico.',
    transmissao: 'Distúrbio gastrointestinal primário não contagioso.',
    sinaisClinicos: [
      'Comportamento de dor: cavar o chão, escoicear o flanco, olhar para o abdômen, deitar e rolar repetidamente.',
      'Taquicardia progressiva (frequência cardíaca > 60 bpm é indicativo de gravidade).',
      'Hipomotilidade ou atonia intestinal à auscultação dos 4 quadrantes abdominais.',
      'Refluxo nasogástrico espontâneo com odor fermentativo (indicativo de obstrução proximal).'
    ],
    diagnostico: 'Exame físico completo, sondagem nasogástrica imediata (obrigatória para descompressão estomacal), palpação retal para identificar distensão gasosa ou compactação, abdominocentese com avaliação de cor, densidade e lactato do líquido peritoneal.',
    tratamento: 'Clínico: analgesia controlada com AINEs (Flunixin Meglumine 1,1 mg/kg IV) ou antiespasmódicos (dipirona com escopolamina), fluidoterapia enteral por sonda (água morna + sais) ou IV massiva em desidratações graves, laxantes osmóticos (sulfato de magnésio ou óleo mineral). Cirúrgico: indicação de laparotomia exploratória imediata se houver refluxo nasogástrico contínuo, dor intratável refratária e líquido peritoneal serossanguinolento.',
    prevencao: 'Fornecimento constante de água fresca e de boa qualidade, arraçoamento fracionado, transição lenta de volumosos e ração concentrada, vermifugação estratégica e odontologia profilática regular.',
    notificacaoObrigatoria: false
  },
  {
    id: 'laminite_equina',
    nome: 'Laminite Equina (Aguamento)',
    nomeCientifico: 'Equine Laminitis',
    especies: ['cavalo'],
    categoria: 'Osteoarticular',
    gravidade: 'Urgência',
    causa: 'Inflamação e isquemia das lâminas dérmicas e epidérmicas do casco decorrentes de sobrecarga de carboidratos solúveis (grãos/amido), sepse/endotoxemia (metrite, cólica), Síndrome Metabólica Equina (SME), Doença de Cushing (PPID) ou sobrecarga mecânica de membro contralateral.',
    transmissao: 'Patologia vascular/inflamatória sistêmica.',
    sinaisClinicos: [
      'Postura clássica em cavalete: membro anteriores estendidos à frente para aliviar o peso dos talões e pélvicos sob o corpo.',
      'Aumento marcante do pulso digital nas artérias digitais palmares/plantares e calor nas muralhas dos cascos.',
      'Relutância severa para se movimentar e dor intensa à pinça de casco na região da pinça.',
      'Afundamento ou rotação da terceira falange (falange distal) visível externamente por depressão na coroa do casco.'
    ],
    diagnostico: 'Sinais clínicos típicos, palpação com pinça de casco e exame radiográfico dos cascos com marcador radiopaco na muralha para mensuração exata do grau de rotação ou afundamento da falange distal em relação à muralha do casco.',
    tratamento: 'Crioterapia imediata nas fases iniciais (imersão dos cascos e canelas em botas de gelo contínuo por 48-72 horas para prevenir degradação enzimática das lâminas); anti-inflamatórios potentes (Flunixin Meglumine); vasodilatadores periféricos (acepromazina em microdoses); suporte de ranilha e casqueamento ortopédico corretivo; cama espessa e macia de areia ou maravalha.',
    prevencao: 'Controle alimentar rigoroso de rações concentradas, acesso restrito a pastagens exuberantes ricas em frutano para equinos propensos, e prevenção e tratamento rápido de cólicas e metrites sépticas.',
    notificacaoObrigatoria: false
  },
  {
    id: 'mormo_equino',
    nome: 'Mormo Equino',
    nomeCientifico: 'Burkholderia mallei',
    especies: ['cavalo'],
    categoria: 'Infecciosa',
    gravidade: 'Urgência',
    causa: 'Bactéria bacilar gram-negativa aeróbia intracelular facultativa. Zoonose letal de notificação internacional obrigatória que afeta equídeos e o ser humano.',
    transmissao: 'Ingestão de água ou alimentos contaminados com secreções de animais doentes, inalação de aerossóis ou penetração cutânea por feridas.',
    sinaisClinicos: [
      'Forma Nasal: febre alta, corrimento nasal unilateral ou bilateral inicialmente seroso que se torna mucopurulento espesso e amarelado, úlceras na mucosa do septo nasal que cicatrizam em forma de estrela.',
      'Forma Pulmonar: tosse crônica, dispneia progressiva e nódulos caseosos pulmonares.',
      'Forma Cutânea ("farcinose"): cordões linfáticos tumefeitos e endurecidos com nódulos que ulceram e drenam exsudato purulento viscoso amarelado nos membros e abdômen.'
    ],
    diagnostico: 'Fixação de Complemento e Western Blotting (testes sorológicos oficiais pelo Ministério da Agricultura e Pecuária - MAPA/PNSE); maleinização intrapalpebral; isolamento bacteriano em laboratórios credenciados de biossegurança nível 3.',
    tratamento: 'O tratamento de equinos é expressamente PROIBIDO pela legislação sanitária brasileira e internacional devido ao alto risco de transmissão zoonótica fatal ao ser humano e manutenção de portadores crônicos. Animais positivos confirmados devem ser submetidos à eutanásia sanitária imediata.',
    prevencao: 'Exigência obrigatória de exame negativo oficial com certificado de trânsito agropecuário (GTA) para trânsito e aglomerações, quarentena de novos animais e isolamento estrito de propriedades suspeitas.',
    notificacaoObrigatoria: true
  },
  {
    id: 'anemia_infecciosa_equina',
    nome: 'Anemia Infecciosa Equina (AIE)',
    nomeCientifico: 'Equine Infectious Anemia Virus (EIAV - Lentivirus)',
    especies: ['cavalo'],
    categoria: 'Infecciosa',
    gravidade: 'Alta',
    causa: 'Retrovírus do gênero Lentivirus com capacidade de mutação antigênica rápida de seus envelopes glicoproteicos durante episódios febris recorrentes.',
    transmissao: 'Transmissão mecânica por picada de dípteros hematófagos grandes (especialmente mutucas da família Tabanidae e moscas dos estábulos Stomoxys calcitrans); fômites contaminados com sangue (agulhas, seringas, esporas, freios).',
    sinaisClinicos: [
      'Fase Aguda: febre alta e súbita, trombocitopenia profunda, petéquias em mucosas, icterícia e fraqueza.',
      'Fase Crônica: episódios cíclicos de febre, anemia hemolítica progressiva, emagrecimento crônico, edema ventral no peito e abdômen.',
      'Portador Inaparente/Assintomático: sem sinais clínicos aparentes, porém atua como reservatório permanente de vírus pela vida inteira.'
    ],
    diagnostico: 'Teste oficial de Imunodifusão em Gel de Ágar (IDGA - Teste de Coggins) ou ensaio imunoenzimático (ELISA) realizado exclusivamente por laboratórios credenciados pelo MAPA.',
    tratamento: 'Não existe tratamento curativo nem vacina eficaz contra a AIE. Por determinação legal do Programa Nacional de Sanidade dos Equídeos (PNSE), o animal positivo confirmado deve ser sacrificado ou mantido em isolamento permanente com barreira física contra insetos.',
    prevencao: 'Exames periódicos de IDGA/ELISA, controle de insetos vetores, uso exclusivo e individual de agulhas e instrumentos descartáveis, e emissão de GTA com laudo negativo vigente.',
    notificacaoObrigatoria: true
  },

  // -------------------------------------------------------------
  // BOVINOS (RUMINANTES)
  // -------------------------------------------------------------
  {
    id: 'mastite_bovina',
    nome: 'Mastite Bovina (Clínica e Subclínica)',
    nomeCientifico: 'Bovine Mastitis (Infecciosa / Ambiental)',
    especies: ['bovino'],
    categoria: 'Infecciosa',
    gravidade: 'Moderada',
    causa: 'Infecção e processo inflamatório da glândula mamária. Patógenos contagiosos: Staphylococcus aureus, Streptococcus agalactiae. Patógenos ambientais: Escherichia coli, Klebsiella pneumoniae, Streptococcus uberis.',
    transmissao: 'Durante a ordenha através de teteiras contaminadas, mãos dos ordenhadores e panos comuns (contagiosa) ou por contato dos tetos com fezes, barro e cama contaminada no pré e pós-ordenha (ambiental).',
    sinaisClinicos: [
      'Mastite Clínica: grumos, pus ou aspecto aquoso/sanguinolento no leite visíveis no teste da caneca de fundo preto; quarto mamário edemaciado, quente, ruborizado e doloroso; febre e toxemia na mastite aguda por coliformes.',
      'Mastite Subclínica: sem alterações visíveis no leite ou na mama, porém com queda silenciosa da produção de leite e aumento expressivo na Contagem de Células Somáticas (CCS > 200.000 células/mL).'
    ],
    diagnostico: 'Teste da caneca de fundo escuro para identificação de mastite clínica na rotina de ordenha; California Mastitis Test (CMT) e contagem eletrônica de células somáticas (CCS) para mastite subclínica; cultura microbiológica e antibiograma do leite para eleição terapêutica.',
    tratamento: 'Infusão intramamária de antibióticos de amplo espectro pós-esgotamento completo do quarto mamário afetado; nos casos clínicos graves com toxemia: antibioticoterapia sistêmica parenteral (ceftiofur, florfenicol), anti-inflamatórios não-esteroidais (flunixin meglumine), fluidoterapia vigorosa e ordenhas frequentes para retirada de toxinas bacterianas.',
    prevencao: 'Linha de ordenha rigorosa (vacas sadias primeiro, suspeitas e infectadas por último), desinfecção de tetos antes (pré-dipping) e após (pós-dipping com iodo glicerinado) a ordenha, terapia da vaca seca com antibiótico de ação prolongada e selante de teto em todos os quartos no momento da secagem.',
    notificacaoObrigatoria: false
  },
  {
    id: 'timpanismo_bovino',
    nome: 'Timpanismo Ruminal (Meteorismo)',
    nomeCientifico: 'Ruminal Tympany (Bloat)',
    especies: ['bovino'],
    categoria: 'Gastrointestinal',
    gravidade: 'Urgência',
    causa: 'Acúmulo anormal de gás no retículo-rúmen. Timpanismo Gasoso (Livre): incapacidade de eructação por obstrução esofágica mecânica (engasgo com maçã, batata, corpo estranho) ou disfunção vagal. Timpanismo Espumoso (Pastagem/Grãos): formação de espuma estável no conteúdo ruminal devido à rápida fermentação de leguminosas jovens (alfafa, trevo) ricas em saponinas e proteínas solúveis ou dietas ricas em grãos finamente moídos.',
    transmissao: 'Distúrbio digestivo metabólico agudo decorrente de manejo nutricional.',
    sinaisClinicos: [
      'Distensão abdominal pronunciada e assimétrica com abaulamento evidente da fossa paralombar esquerda ("fossa do flanco esquerdo").',
      'Desconforto abdominal acentuado, gemidos, salivação profusa e distensão do pescoço.',
      'Dispneia grave e cianose de mucosas causada pela compressão do diafragma pelo rúmen distendido.',
      'Morte por asfixia e falência circulatória em menos de poucas horas se não aliviado.'
    ],
    diagnostico: 'Histórico alimentar recente e inspeção visual da fossa paralombar esquerda abaulada em cúpula; introdução de sonda orogástrica calibrosa (no timpanismo gasoso há liberação imediata de jato gasoso sob pressão; no espumoso a sonda não alivia o gás e drena espuma viscosa).',
    tratamento: 'No timpanismo gasoso: passagem de sonda esofágica calibrosa para descompressão. No timpanismo espumoso: administração intrarruminal de agentes tensoativos antiespumantes (Poloxaleno, óleo mineral 500-1000 mL ou docusato de sódio). Em casos de asfixia iminente com risco de morte em minutos: trocarização ou rumenotomia de emergência na fossa paralombar esquerda com cânula ou faca estéril para escape do conteúdo.',
    prevencao: 'Evitar o pastoreio em leguminosas orvalhadas ou jovens sem fornecimento prévio de feno fibroso; uso de agentes tensoativos ou ionóforos (monensina sódica) na dieta de confinamento para estabilizar a microbiota.',
    notificacaoObrigatoria: false
  },
  {
    id: 'tristeza_parasitaria_bovina',
    nome: 'Tristeza Parasitária Bovina (TPB)',
    nomeCientifico: 'Babesia bovis, Babesia bigemina & Anaplasma marginale',
    especies: ['bovino'],
    categoria: 'Parasitária',
    gravidade: 'Alta',
    causa: 'Complexo de doenças transmitido por artrópodes. Babesiose bovina causada pelos protozoários intraeritrocitários Babesia bovis e B. bigemina. Anaplasmose causada pela rickettsia Anaplasma marginale.',
    transmissao: 'Vetor biológico primário: carrapato-do-boi (Rhipicephalus microplus). Transmissão mecânica da Anaplasmose também por moscas hematófagas (tabanídeos) e fômites contaminados com sangue (agulhas de vacinação coletiva, descornadores).',
    sinaisClinicos: [
      'Febre elevada (40-41,5 °C), anorexia e queda abrupta da lactação.',
      'Anemia hemolítica intensa com palidez extrema seguida de icterícia pronunciada.',
      'Hemoglobinúria ("urina vermelha/cor de café") marcante na infecção por Babesia bigemina.',
      'Sintomas nervosos (incoordenação motora, agressividade, pedalagem) causados pela Babesia bovis por sequestro de eritrócitos infectados nos capilares cerebrais.',
      'Anaplasmose: anemia progressiva e icterícia intensa SEM hemoglobinúria (hemólise extravascular).'
    ],
    diagnostico: 'Esfregaço sanguíneo de sangue capilar periférico (ponta de orelha ou cauda) corado com Giemsa ou Panótico rápido para visualização direta de trofozoítos de Babesia aos pares dentro das hemácias ou corpúsculos de Anaplasma na margem das hemácias.',
    tratamento: 'Para Babesiose: Diaceturato de Diminazeno (3,5 mg/kg IM) ou Dipropionato de Imidocarb (1,2 a 2,1 mg/kg SC). Para Anaplasmose: Oxitetraciclina de longa ação (20 mg/kg IM profunda) ou Imidocarb (2,5 mg/kg SC). Terapia de suporte: transfusão sanguínea em animais com hematócrito abaixo de 12%, fluidoterapia com eletrólitos e vitaminas hematopoiéticas (B12 e ferro).',
    prevencao: 'Controle estratégico integrado do carrapato Rhipicephalus microplus; premunição ou vacinação de bezerros com cepas atenuadas em áreas de instabilidade enzoótica; uso de agulhas individuais descartáveis em vacinações coletivas.',
    notificacaoObrigatoria: false
  },
  {
    id: 'brucelose_bovina',
    nome: 'Brucelose Bovina',
    nomeCientifico: 'Brucella abortus',
    especies: ['bovino'],
    categoria: 'Infecciosa',
    gravidade: 'Alta',
    causa: 'Bactéria cocobacilar gram-negativa intracelular facultativa. Zoonose grave de alta relevância socioeconômica causadora da "Febre Ondulante" em seres humanos.',
    transmissao: 'Ingestão de pastagens, água ou alimentos contaminados com restos placentários, fluidos uterinos e fetos abortados de fêmeas infectadas; via venérea por sêmen infectado e aleitamento com leite cru.',
    sinaisClinicos: [
      'Fêmeas: abortamento espontâneo característico no terço final da gestação (6º ao 9º mês) e nascimento de bezerros fracos ou natimortos.',
      'Retenção de placenta frequente, metrite purulenta secundária e infertilidade temporária ou permanente.',
      'Machos: orquite unilateral ou bilateral, epididimite e atrofia testicular com queda na qualidade seminal.',
      'Bursite e higroma de carpo ("higroma brucélico") em animais crônicos.'
    ],
    diagnostico: 'Exames sorológicos padronizados pelo Programa Nacional de Controle e Erradicação da Brucelose e Tuberculose Animal (PNCEBT): Triagem pelo teste do Antígeno Acidificado Tamponado (AAT); confirmação por 2-Mercaptoetanol (2-ME) ou Fixação de Complemento.',
    tratamento: 'O tratamento de bovinos infectados é TERMINANTEMENTE PROIBIDO por lei sanitária nacional devido ao risco zoonótico de persistência do patógeno e contaminação do leite. Animais positivos confirmados devem ser marcados com fogo com a letra "P" na face esquerda e destinados ao abate sanitário sob inspeção oficial.',
    prevencao: 'Vacinação obrigatória de todas as bezerras fêmeas entre 3 e 8 meses de idade com a vacina viva atenuada B19 (marcação obrigatória com o dígito final do ano) ou vacina RB51 em fêmeas adultas não vacinadas; testes sorológicos periódicos de todo o rebanho e descarte sanitário de reagentes.',
    notificacaoObrigatoria: true
  }
];
