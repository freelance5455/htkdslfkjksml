import { AdhanVoice, AlarmTone } from '../types/prayer';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private currentStopCallback: (() => void) | null = null;
  private isUnlocked = false;

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public unlockAudio(): void {
    if (this.isUnlocked) return;
    try {
      const ctx = this.getContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      gain.gain.value = 0.001;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(0);
      osc.stop(ctx.currentTime + 0.05);
      this.isUnlocked = true;
    } catch (e) {
      console.warn('Audio unlock warning:', e);
    }
  }

  public stopCurrentSound(): void {
    if (this.currentStopCallback) {
      try {
        this.currentStopCallback();
      } catch (err) {
        console.warn('Error stopping sound:', err);
      }
      this.currentStopCallback = null;
    }
  }

  /**
   * Play Adhan melody with vocal formant filters and Maqam Bayati intervals.
   */
  public playAdhan(voice: AdhanVoice = 'makkah', volume = 80): { stop: () => void } {
    this.stopCurrentSound();
    const ctx = this.getContext();
    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    const gainVal = Math.max(0.01, (volume / 100) * 0.7);
    masterGain.gain.setValueAtTime(gainVal, now);
    masterGain.connect(ctx.destination);

    // Active nodes collector
    const activeNodes: { stop?: (t?: number) => void; disconnect?: () => void }[] = [];
    let isStopped = false;

    // Trigger subtle mobile vibration if supported
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate([400, 200, 400, 200, 600]);
      } catch {}
    }

    // Melodic notes for Takbeer / Adhan phrases in Maqam Bayati (D, Eb-half-flat, F, G, A)
    // Frequencies: D3=146.8, Eb~155, F3=174.6, G3=196, A3=220, Bb3=233, C4=261.6, D4=293.7
    type MelodyNote = { freq: number; start: number; dur: number; vibrato?: boolean };

    let phraseList: MelodyNote[] = [];

    if (voice === 'fajr_special') {
      // Fajr variation: "As-Salatu Khayrun Minan-Nawm" ascending motif
      phraseList = [
        { freq: 174.61, start: 0.1, dur: 1.8 }, // F3 - Al-lahu
        { freq: 220.00, start: 2.1, dur: 2.2, vibrato: true }, // A3 - Ak-bar
        { freq: 196.00, start: 4.5, dur: 1.6 }, // G3 - Al-lahu
        { freq: 174.61, start: 6.3, dur: 2.4, vibrato: true }, // F3 - Ak-bar
        { freq: 196.00, start: 9.0, dur: 1.5 }, // As-salatu
        { freq: 220.00, start: 10.7, dur: 2.0 }, // khayrum-
        { freq: 261.63, start: 13.0, dur: 2.8, vibrato: true }, // minan-nawm
        { freq: 220.00, start: 16.0, dur: 1.8 },
        { freq: 174.61, start: 18.0, dur: 3.0, vibrato: true },
      ];
    } else if (voice === 'madinah') {
      // Madinah: Serene, warm, meditative
      phraseList = [
        { freq: 196.00, start: 0.1, dur: 2.0 }, // G3
        { freq: 220.00, start: 2.3, dur: 2.2, vibrato: true }, // A3
        { freq: 196.00, start: 4.8, dur: 1.8 }, // G3
        { freq: 164.81, start: 6.8, dur: 2.5, vibrato: true }, // E3
        { freq: 196.00, start: 9.6, dur: 2.2 }, // G3
        { freq: 246.94, start: 12.0, dur: 2.6, vibrato: true }, // B3
        { freq: 220.00, start: 14.8, dur: 2.0 }, // A3
        { freq: 164.81, start: 17.0, dur: 3.5, vibrato: true }, // E3
      ];
    } else if (voice === 'alaqsa') {
      // Al-Aqsa: Reverent, deep resonance
      phraseList = [
        { freq: 146.83, start: 0.1, dur: 2.2 }, // D3
        { freq: 174.61, start: 2.5, dur: 2.4, vibrato: true }, // F3
        { freq: 196.00, start: 5.1, dur: 2.0 }, // G3
        { freq: 146.83, start: 7.3, dur: 2.8, vibrato: true }, // D3
        { freq: 174.61, start: 10.4, dur: 2.2 }, // F3
        { freq: 220.00, start: 12.8, dur: 2.8, vibrato: true }, // A3
        { freq: 196.00, start: 15.8, dur: 2.0 }, // G3
        { freq: 146.83, start: 18.0, dur: 3.8, vibrato: true }, // D3
      ];
    } else {
      // Makkah / Melodic Bayati / Standard
      phraseList = [
        { freq: 174.61, start: 0.1, dur: 1.9 }, // F3 - Allahu
        { freq: 220.00, start: 2.2, dur: 2.6, vibrato: true }, // A3 - Akbar
        { freq: 196.00, start: 5.0, dur: 1.8 }, // G3 - Allahu
        { freq: 174.61, start: 7.0, dur: 2.8, vibrato: true }, // F3 - Akbar
        { freq: 196.00, start: 10.1, dur: 2.2 }, // G3 - Ash-hadu
        { freq: 220.00, start: 12.5, dur: 2.8, vibrato: true }, // A3 - an la ilaha
        { freq: 261.63, start: 15.5, dur: 2.4, vibrato: true }, // C4 - illallah
        { freq: 220.00, start: 18.1, dur: 2.2 }, // A3
        { freq: 174.61, start: 20.5, dur: 3.5, vibrato: true }, // F3
      ];
    }

    // Play each note with rich acoustic formant shaping and warm envelope
    phraseList.forEach(note => {
      const noteStart = now + note.start;
      const noteDur = note.dur;

      // Primary tone
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(note.freq, noteStart);

      // Warm sub-harmonic tone
      const subOsc = ctx.createOscillator();
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(note.freq / 2, noteStart);

      // Upper harmonic for vocal sheen
      const shimmerOsc = ctx.createOscillator();
      shimmerOsc.type = 'triangle';
      shimmerOsc.frequency.setValueAtTime(note.freq * 2, noteStart);

      // Vibrato LFO if enabled
      if (note.vibrato) {
        const lfo = ctx.createOscillator();
        const lfoGain = ctx.createGain();
        lfo.frequency.setValueAtTime(4.8, noteStart); // 4.8 Hz natural human vibrato
        lfoGain.gain.setValueAtTime(note.freq * 0.015, noteStart);
        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);
        lfo.start(noteStart + 0.3);
        lfo.stop(noteStart + noteDur);
        activeNodes.push(lfo);
      }

      // Vocal Formant Bandpass Filters (F1 ~ 700Hz, F2 ~ 1200Hz - open 'Ah'/'Oh' vowel)
      const bpf = ctx.createBiquadFilter();
      bpf.type = 'bandpass';
      bpf.frequency.setValueAtTime(800, noteStart);
      bpf.Q.setValueAtTime(2.5, noteStart);

      // Lowpass smoothing filter
      const lpf = ctx.createBiquadFilter();
      lpf.type = 'lowpass';
      lpf.frequency.setValueAtTime(2200, noteStart);

      // Gain Envelope (Gentle swell, sustained breath, natural release)
      const noteGain = ctx.createGain();
      noteGain.gain.setValueAtTime(0.001, noteStart);
      noteGain.gain.exponentialRampToValueAtTime(0.7, noteStart + 0.4);
      noteGain.gain.setValueAtTime(0.65, noteStart + noteDur - 0.4);
      noteGain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

      // Wire nodes
      osc.connect(bpf);
      shimmerOsc.connect(bpf);
      bpf.connect(lpf);
      lpf.connect(noteGain);

      const subGain = ctx.createGain();
      subGain.gain.setValueAtTime(0.3, noteStart);
      subOsc.connect(subGain);
      subGain.connect(noteGain);

      noteGain.connect(masterGain);

      osc.start(noteStart);
      osc.stop(noteStart + noteDur);
      subOsc.start(noteStart);
      subOsc.stop(noteStart + noteDur);
      shimmerOsc.start(noteStart);
      shimmerOsc.stop(noteStart + noteDur);

      activeNodes.push(osc, subOsc, shimmerOsc);
    });

    const stop = () => {
      if (isStopped) return;
      isStopped = true;
      try {
        const stopTime = ctx.currentTime;
        masterGain.gain.cancelScheduledValues(stopTime);
        masterGain.gain.setValueAtTime(masterGain.gain.value, stopTime);
        masterGain.gain.exponentialRampToValueAtTime(0.0001, stopTime + 0.2);
        setTimeout(() => {
          activeNodes.forEach(node => {
            try {
              if (node.stop) node.stop();
              if (node.disconnect) node.disconnect();
            } catch {}
          });
          masterGain.disconnect();
        }, 250);
      } catch (e) {
        console.warn('Error during adhan stop:', e);
      }
    };

    this.currentStopCallback = stop;
    return { stop };
  }

  /**
   * Play separate Salah reminder alarm.
   */
  public playAlarm(tone: AlarmTone = 'sacred_bell', volume = 85): { stop: () => void } {
    this.stopCurrentSound();
    const ctx = this.getContext();
    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    const gainVal = Math.max(0.01, (volume / 100) * 0.8);
    masterGain.gain.setValueAtTime(gainVal, now);
    masterGain.connect(ctx.destination);

    const activeNodes: { stop?: (t?: number) => void; disconnect?: () => void }[] = [];
    let isStopped = false;

    // Vibration pattern for Salah alarm
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate([250, 100, 250, 100, 250]);
      } catch {}
    }

    if (tone === 'sacred_bell' || tone === 'radiant_gong') {
      // Tibetan / Islamic singing prayer bell with deep harmonics
      const baseFreq = tone === 'radiant_gong' ? 220 : 440;
      const harmonics = [1, 2.76, 5.4, 8.9];
      const strikeIntervals = [0, 2.5, 5.0, 7.5];

      strikeIntervals.forEach(delay => {
        const strikeTime = now + delay;
        harmonics.forEach((hRatio, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(baseFreq * hRatio, strikeTime);

          const decay = 2.2 / (idx + 1);
          gain.gain.setValueAtTime(0.001, strikeTime);
          gain.gain.exponentialRampToValueAtTime(0.4 / (idx + 1), strikeTime + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.0001, strikeTime + decay);

          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(strikeTime);
          osc.stop(strikeTime + decay);
          activeNodes.push(osc);
        });
      });
    } else if (tone === 'crystal_chime') {
      // Arpeggiated radiant chime: E5, G#5, B5, E6
      const arpeggio = [659.25, 830.61, 987.77, 1318.51];
      for (let cycle = 0; cycle < 3; cycle++) {
        const cycleStart = now + cycle * 3.0;
        arpeggio.forEach((freq, idx) => {
          const noteTime = cycleStart + idx * 0.25;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, noteTime);

          gain.gain.setValueAtTime(0.001, noteTime);
          gain.gain.exponentialRampToValueAtTime(0.4, noteTime + 0.015);
          gain.gain.exponentialRampToValueAtTime(0.0001, noteTime + 1.8);

          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(noteTime);
          osc.stop(noteTime + 1.8);
          activeNodes.push(osc);
        });
      }
    } else if (tone === 'dawn_alarm') {
      // Warm rising acoustic pulse
      const pulses = [0, 1.2, 2.4, 3.6, 4.8, 6.0];
      pulses.forEach(offset => {
        const pTime = now + offset;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, pTime); // C5
        osc.frequency.exponentialRampToValueAtTime(659.25, pTime + 0.4); // E5

        gain.gain.setValueAtTime(0.001, pTime);
        gain.gain.exponentialRampToValueAtTime(0.5, pTime + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, pTime + 0.8);

        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(pTime);
        osc.stop(pTime + 0.8);
        activeNodes.push(osc);
      });
    } else {
      // Gentle acoustic / vibrant chime
      const notes = [440, 554.37, 659.25, 880];
      for (let r = 0; r < 3; r++) {
        const rStart = now + r * 2.5;
        notes.forEach((freq, i) => {
          const t = rStart + i * 0.3;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, t);

          gain.gain.setValueAtTime(0.001, t);
          gain.gain.exponentialRampToValueAtTime(0.4, t + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.2);

          osc.connect(gain);
          gain.connect(masterGain);
          osc.start(t);
          osc.stop(t + 1.2);
          activeNodes.push(osc);
        });
      }
    }

    const stop = () => {
      if (isStopped) return;
      isStopped = true;
      try {
        const stopTime = ctx.currentTime;
        masterGain.gain.cancelScheduledValues(stopTime);
        masterGain.gain.setValueAtTime(masterGain.gain.value, stopTime);
        masterGain.gain.exponentialRampToValueAtTime(0.0001, stopTime + 0.15);
        setTimeout(() => {
          activeNodes.forEach(node => {
            try {
              if (node.stop) node.stop();
              if (node.disconnect) node.disconnect();
            } catch {}
          });
          masterGain.disconnect();
        }, 200);
      } catch (e) {
        console.warn('Error during alarm stop:', e);
      }
    };

    this.currentStopCallback = stop;
    return { stop };
  }
}

export const soundEngine = new SoundEngine();
