class SoundEngine {
  private ctx: AudioContext | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private masterGain: GainNode | null = null;

  private isSfxEnabled = true;
  private isMusicEnabled = true;
  private sfxVol = 0.8;
  private musicVol = 0.5;

  private isMusicPlaying = false;
  private musicTimer: number | null = null;
  private chordIndex = 0;
  private currentMusicNodes: OscillatorNode[] = [];

  constructor() {
    // AudioContext will be initialized on first user gesture
  }

  private initContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      this.ctx = new AudioContextClass();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 1.0;
      this.masterGain.connect(this.ctx.destination);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.isSfxEnabled ? this.sfxVol : 0;
      this.sfxGain.connect(this.masterGain);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.isMusicEnabled ? this.musicVol : 0;
      this.musicGain.connect(this.masterGain);
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setSfxEnabled(enabled: boolean) {
    this.isSfxEnabled = enabled;
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setTargetAtTime(enabled ? this.sfxVol : 0, this.ctx.currentTime, 0.05);
    }
  }

  public setMusicEnabled(enabled: boolean) {
    this.isMusicEnabled = enabled;
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(enabled ? this.musicVol : 0, this.ctx.currentTime, 0.1);
    }
    if (enabled && !this.isMusicPlaying) {
      this.startMusic();
    } else if (!enabled && this.isMusicPlaying) {
      this.stopMusic();
    }
  }

  public setSfxVolume(vol: number) {
    this.sfxVol = Math.max(0, Math.min(1, vol));
    if (this.sfxGain && this.ctx && this.isSfxEnabled) {
      this.sfxGain.gain.setTargetAtTime(this.sfxVol, this.ctx.currentTime, 0.05);
    }
  }

  public setMusicVolume(vol: number) {
    this.musicVol = Math.max(0, Math.min(1, vol));
    if (this.musicGain && this.ctx && this.isMusicEnabled) {
      this.musicGain.gain.setTargetAtTime(this.musicVol, this.ctx.currentTime, 0.05);
    }
  }

  // --- SOUND EFFECTS ---

  public playClick() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, t);
    osc.frequency.exponentialRampToValueAtTime(400, t + 0.04);

    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.045);
  }

  public playPickup() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.exponentialRampToValueAtTime(540, t + 0.07);

    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.07);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.08);
  }

  public playDrop() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const t = this.ctx.currentTime;

    // Body thud
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(220, t);
    osc1.frequency.exponentialRampToValueAtTime(65, t + 0.09);

    gain1.gain.setValueAtTime(0.4, t);
    gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.09);

    osc1.connect(gain1);
    gain1.connect(this.sfxGain);
    osc1.start(t);
    osc1.stop(t + 0.095);

    // High transient snap
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(800, t);
    osc2.frequency.exponentialRampToValueAtTime(250, t + 0.04);

    gain2.gain.setValueAtTime(0.25, t);
    gain2.gain.exponentialRampToValueAtTime(0.001, t + 0.04);

    osc2.connect(gain2);
    gain2.connect(this.sfxGain);
    osc2.start(t);
    osc2.stop(t + 0.045);
  }

  public playInvalid() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, t);
    osc.frequency.setValueAtTime(100, t + 0.06);

    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.13);
  }

  public playLineClear(linesCount: number = 1) {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const baseFreqs = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    const multiplier = Math.min(linesCount, 4);

    baseFreqs.slice(0, 2 + multiplier).forEach((freq, idx) => {
      const delay = idx * 0.04;
      const t = this.ctx!.currentTime + delay;

      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.02, t + 0.35);

      gain.gain.setValueAtTime(0.28, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.38);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(t);
      osc.stop(t + 0.4);
    });
  }

  public playCombo(comboCount: number) {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    // Pitch scales up based on combo count
    const pentatonic = [
      [523.25, 659.25, 783.99],          // C5
      [587.33, 739.99, 880.00],          // D5
      [659.25, 830.61, 987.77],          // E5
      [783.99, 987.77, 1174.66],         // G5
      [880.00, 1108.73, 1318.51],        // A5
      [1046.50, 1318.51, 1567.98, 2093]  // C6+ Ultra fanfare
    ];

    const chord = pentatonic[Math.min(comboCount - 1, pentatonic.length - 1)] || pentatonic[0];

    chord.forEach((freq, idx) => {
      const delay = idx * 0.05;
      const t = this.ctx!.currentTime + delay;

      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.03, t + 0.45);

      gain.gain.setValueAtTime(0.32, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(t);
      osc.stop(t + 0.48);
    });
  }

  public playHammer() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const t = this.ctx.currentTime;
    // Low punch
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'sawtooth';
    osc1.frequency.setValueAtTime(160, t);
    osc1.frequency.exponentialRampToValueAtTime(30, t + 0.2);

    gain1.gain.setValueAtTime(0.5, t);
    gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

    osc1.connect(gain1);
    gain1.connect(this.sfxGain);
    osc1.start(t);
    osc1.stop(t + 0.25);

    // Shatter noise burst
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(800, t);
    osc2.frequency.exponentialRampToValueAtTime(120, t + 0.15);

    gain2.gain.setValueAtTime(0.35, t);
    gain2.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

    osc2.connect(gain2);
    gain2.connect(this.sfxGain);
    osc2.start(t);
    osc2.stop(t + 0.18);
  }

  public playReroll() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(280, t);
    osc.frequency.exponentialRampToValueAtTime(980, t + 0.25);

    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.26);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.28);
  }

  public playBombTick() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(880, t);
    osc.frequency.setValueAtTime(440, t + 0.03);

    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.06);
  }

  public playBombDefused() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(300, t);
    osc.frequency.exponentialRampToValueAtTime(900, t + 0.3);

    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.36);
  }

  public playTimeLow() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(587.33, t); // D5
    osc.frequency.setValueAtTime(440, t + 0.08); // A4

    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.14);
  }

  public playPerfectClear() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    // Grand celestial arpeggio
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98, 2093.0];
    notes.forEach((freq, idx) => {
      const delay = idx * 0.07;
      const t = this.ctx!.currentTime + delay;

      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.35, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.6);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(t);
      osc.stop(t + 0.65);
    });
  }

  public triggerHaptic(pattern: number | number[] = 25) {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Ignore mobile browser restrictions
      }
    }
  }

  public playGameOver() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const notes = [440, 392, 349.23, 293.66, 220]; // A4, G4, F4, D4, A3
    notes.forEach((freq, idx) => {
      const delay = idx * 0.12;
      const t = this.ctx!.currentTime + delay;

      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.24, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(t);
      osc.stop(t + 0.38);
    });
  }

  public playHighScore() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || !this.isSfxEnabled) return;

    const fanfare = [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98];
    fanfare.forEach((freq, idx) => {
      const delay = idx * 0.08;
      const t = this.ctx!.currentTime + delay;

      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(t);
      osc.stop(t + 0.55);
    });
  }

  // --- PROCEDURAL RELAXING AMBIENT MUSIC ---
  public startMusic() {
    if (this.isMusicPlaying) return;
    this.initContext();
    this.isMusicPlaying = true;
    this.scheduleNextAmbientChord();
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicTimer) {
      window.clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
    this.currentMusicNodes.forEach(node => {
      try {
        node.stop();
        node.disconnect();
      } catch {
        // Already stopped
      }
    });
    this.currentMusicNodes = [];
  }

  private scheduleNextAmbientChord() {
    if (!this.isMusicPlaying || !this.ctx || !this.musicGain) return;

    // Atmospheric calm chords (Fmaj9, Em7, Dm9, Cmaj7)
    const chordProgressions = [
      [174.61, 220.00, 261.63, 329.63, 392.00], // F3, A3, C4, E4, G4
      [164.81, 196.00, 246.94, 293.66, 392.00], // E3, G3, B3, D4, G4
      [146.83, 174.61, 220.00, 261.63, 329.63], // D3, F3, A3, C4, E4
      [130.81, 164.81, 196.00, 246.94, 261.63], // C3, E3, G3, B3, C4
    ];

    const chord = chordProgressions[this.chordIndex % chordProgressions.length];
    this.chordIndex++;

    const now = this.ctx.currentTime;
    const duration = 4.2; // Each chord lasts ~4.2s

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(320, now);
    filter.frequency.exponentialRampToValueAtTime(540, now + 2.0);
    filter.frequency.exponentialRampToValueAtTime(300, now + duration);
    filter.connect(this.musicGain);

    const activeNodes: OscillatorNode[] = [];

    chord.forEach((freq, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = i === 0 ? 'sine' : 'triangle';
      // Subtle organic detuning
      osc.frequency.setValueAtTime(freq + (Math.random() * 0.8 - 0.4), now);

      // Smooth ambient swell envelope
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(0.045 / Math.sqrt(chord.length), now + 1.6);
      gain.gain.setValueAtTime(0.04 / Math.sqrt(chord.length), now + 2.8);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      gain.connect(filter);

      osc.start(now);
      osc.stop(now + duration + 0.1);
      activeNodes.push(osc);
    });

    // Random stardust chime
    if (Math.random() > 0.4) {
      const sparkleFreq = [1046.5, 1318.5, 1567.98, 1760][Math.floor(Math.random() * 4)];
      const sparkTime = now + 1.2 + Math.random() * 1.5;

      const sparkOsc = this.ctx.createOscillator();
      const sparkGain = this.ctx.createGain();

      sparkOsc.type = 'sine';
      sparkOsc.frequency.setValueAtTime(sparkleFreq, sparkTime);

      sparkGain.gain.setValueAtTime(0.0001, sparkTime);
      sparkGain.gain.linearRampToValueAtTime(0.02, sparkTime + 0.1);
      sparkGain.gain.exponentialRampToValueAtTime(0.0001, sparkTime + 1.2);

      sparkOsc.connect(sparkGain);
      sparkGain.connect(filter);

      sparkOsc.start(sparkTime);
      sparkOsc.stop(sparkTime + 1.3);
      activeNodes.push(sparkOsc);
    }

    this.currentMusicNodes = activeNodes;

    // Schedule next chord slightly before current chord ends for smooth crossfade
    this.musicTimer = window.setTimeout(() => {
      this.scheduleNextAmbientChord();
    }, 3800);
  }
}

export const soundEngine = new SoundEngine();
