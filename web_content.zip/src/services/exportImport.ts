/** تصدير واستيراد بيانات الطالب (JSON) + تصفير التقدم */
import { dumpAll, restoreAll, clearAll, type AtomicStorageResult } from './storage';

export interface BackupFile {
  app: 'manara-bac';
  version: 1;
  exportedAt: string;
  data: Record<string, unknown>;
}

export async function buildBackup(): Promise<BackupFile> {
  return {
    app: 'manara-bac',
    version: 1,
    exportedAt: new Date().toISOString(),
    data: await dumpAll(),
  };
}

export async function downloadBackup(): Promise<void> {
  const backup = await buildBackup();
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `منارة-البكالوريا-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export interface ImportResult {
  ok: boolean;
  message: string;
  keys?: number;
  partial?: boolean;
}

function restoreFailureMessage(result: AtomicStorageResult): string {
  if (result.reason === 'invalid-data') return 'النسخة لا تتوافق مع مفاتيح بيانات منارة المعروفة؛ لم تُطبّق أي تغييرات.';
  if (result.reason === 'snapshot-failed') return 'تعذّر أخذ لقطة آمنة للبيانات الحالية؛ لم يبدأ الاستيراد.';
  if (result.rollbackComplete) return 'لم تتسع مساحة الجهاز لحفظ النسخة؛ أُعيدت بياناتك السابقة بالكامل ولم يُستورد شيء. أفرغ مساحة ثم أعد المحاولة.';
  return 'تعذّر حفظ النسخة وتعذّر تأكيد استعادة جميع القيم السابقة؛ قد تكون بعض البيانات قد طُبّقت جزئياً. أبقِ التطبيق مفتوحاً وصدّر نسخة احتياطية فور توفر مساحة.';
}

export async function importBackupFile(file: File): Promise<ImportResult> {
  try {
    const text = await file.text();
    const parsed = JSON.parse(text) as Partial<BackupFile>;
    if (!parsed || typeof parsed !== 'object' || !parsed.data || typeof parsed.data !== 'object' || Array.isArray(parsed.data)) {
      return { ok: false, message: 'الملف لا يحتوي بيانات صالحة. تأكد أنه ملف نسخة احتياطية من منارة.' };
    }
    if (parsed.app && parsed.app !== 'manara-bac') {
      return { ok: false, message: 'هذا الملف لا ينتمي إلى منارة البكالوريا.' };
    }
    const restored = await restoreAll(parsed.data);
    if (!restored.ok) {
      return {
        ok: false,
        message: restoreFailureMessage(restored),
        partial: !restored.rollbackComplete,
      };
    }
    return { ok: true, message: 'تم استيراد بياناتك بنجاح.', keys: Object.keys(parsed.data).length };
  } catch {
    return { ok: false, message: 'تعذّر قراءة الملف. قد يكون تالفاً أو ليس بصيغة JSON.' };
  }
}

export async function resetEverything(): Promise<AtomicStorageResult> {
  return clearAll();
}
