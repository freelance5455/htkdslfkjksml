const encoder=new TextEncoder();
async function key(secret:string){const d=await crypto.subtle.digest('SHA-256',encoder.encode(secret));return crypto.subtle.importKey('raw',d,{name:'AES-GCM'},false,['encrypt','decrypt']);}
export async function encryptJson(value:unknown,secret:string){if(!crypto.subtle)throw new Error('Web Crypto indisponível.');const iv=crypto.getRandomValues(new Uint8Array(12));const k=await key(secret);const enc=await crypto.subtle.encrypt({name:'AES-GCM',iv},k,encoder.encode(JSON.stringify(value)));return JSON.stringify({iv:Array.from(iv),data:Array.from(new Uint8Array(enc))});}
export async function digestFile(file:File){const h=await crypto.subtle.digest('SHA-256',await file.arrayBuffer());return Array.from(new Uint8Array(h)).map(x=>x.toString(16).padStart(2,'0')).join('');}
export function safeFile(file:File){const max=800*1024*1024;const accepted=['video/','audio/','image/'];return file.size<=max&&accepted.some(p=>file.type.startsWith(p));}

export function mimeAllowed(type:string){return ['video/','audio/','image/'].some(p=>type.startsWith(p));}
export function isSecureContextReady(){return window.isSecureContext && !!crypto?.subtle;}
