/**
 * Notification Center Service
 * Dispatches real-time tournament alerts, pairings, friend challenges,
 * daily mission updates, and achievement unlocks with unread counters and preferences.
 */

import { NotificationItem, NotificationSettings, NotificationType } from '../types/chess';

const NOTIFICATIONS_STORAGE_KEY = 'chess3d_notifications_v5';
const NOTIF_SETTINGS_KEY = 'chess3d_notif_settings_v5';

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    userId: 'current-user',
    type: 'tournament_start',
    title: 'Winter Swiss Masters Live',
    message: 'Check-in is now open for Round 1 pairings.',
    isRead: false,
    createdAt: new Date(Date.now() - 1800000).toISOString(),
  },
  {
    id: 'notif-2',
    userId: 'current-user',
    type: 'daily_challenge',
    title: "Today's Tactical Mission Ready",
    message: 'Test your calculation in "Smothered Mate Sequence" (+75 XP).',
    isRead: false,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: 'notif-3',
    userId: 'current-user',
    type: 'achievement_unlocked',
    title: 'Achievement Unlocked: First Checkmate!',
    message: 'Congratulations on securing your first checkmate. You earned +50 XP.',
    isRead: true,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

class NotificationService {
  private notifications: NotificationItem[] = [];
  private settings: NotificationSettings = {
    tournamentAlerts: true,
    matchInvites: true,
    dailyReminder: true,
    achievementSounds: true,
    systemNotices: true,
  };

  constructor() {
    this.loadState();
  }

  private loadState(): void {
    try {
      const stored = localStorage.getItem(NOTIFICATIONS_STORAGE_KEY);
      this.notifications = stored ? JSON.parse(stored) : [...INITIAL_NOTIFICATIONS];

      const storedSet = localStorage.getItem(NOTIF_SETTINGS_KEY);
      if (storedSet) this.settings = JSON.parse(storedSet);
    } catch {
      this.notifications = [...INITIAL_NOTIFICATIONS];
    }
  }

  private saveState(): void {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(this.notifications));
      localStorage.setItem(NOTIF_SETTINGS_KEY, JSON.stringify(this.settings));
    } catch (e) {
      console.warn('Failed to save notifications:', e);
    }
  }

  public getNotifications(): NotificationItem[] {
    return [...this.notifications];
  }

  public getUnreadCount(): number {
    return this.notifications.filter((n) => !n.isRead).length;
  }

  public getSettings(): NotificationSettings {
    return { ...this.settings };
  }

  public updateSettings(newSettings: Partial<NotificationSettings>): void {
    this.settings = { ...this.settings, ...newSettings };
    this.saveState();
  }

  public markAsRead(id: string): void {
    const notif = this.notifications.find((n) => n.id === id);
    if (notif) {
      notif.isRead = true;
      this.saveState();
    }
  }

  public markAllAsRead(): void {
    this.notifications.forEach((n) => (n.isRead = true));
    this.saveState();
  }

  public sendNotification(
    type: NotificationType,
    title: string,
    message: string,
    data?: Record<string, any>
  ): NotificationItem {
    const item: NotificationItem = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      userId: 'current-user',
      type,
      title,
      message,
      data,
      isRead: false,
      createdAt: new Date().toISOString(),
    };

    this.notifications.unshift(item);
    this.saveState();
    return item;
  }
}

export const notificationService = new NotificationService();
