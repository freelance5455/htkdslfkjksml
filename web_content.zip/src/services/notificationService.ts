import { soundService } from './soundService.ts';

export interface InAppToast {
  id: string;
  title: string;
  body: string;
  avatar?: string;
  chatId?: string;
  type: 'message' | 'call' | 'system';
}

type ToastListener = (toast: InAppToast) => void;

class NotificationService {
  private toastListeners: Set<ToastListener> = new Set();

  public isSupported(): boolean {
    return typeof window !== 'undefined' && 'Notification' in window;
  }

  public getPermission(): NotificationPermission {
    if (!this.isSupported()) return 'denied';
    return Notification.permission;
  }

  public async requestPermission(): Promise<NotificationPermission> {
    if (!this.isSupported()) return 'denied';
    try {
      const perm = await Notification.requestPermission();
      return perm;
    } catch {
      return 'denied';
    }
  }

  public notifyMessage(options: {
    senderName: string;
    text: string;
    avatar?: string;
    chatId?: string;
    playSound?: boolean;
  }) {
    // 1. Play synthesized gaming chime
    if (options.playSound !== false) {
      soundService.playMessageSound();
    }

    // 2. Mobile haptic vibration if supported
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([120, 80, 120]);
      } catch {}
    }

    // 3. System / Browser Push Notification (for background tabs or lock screen)
    if (this.isSupported() && Notification.permission === 'granted') {
      try {
        new Notification(`Unknown Gamer: ${options.senderName}`, {
          body: options.text || 'Sent an attachment',
          icon: options.avatar || '/src/assets/images/unknown_gamer_logo_1793437689232.jpg',
          tag: options.chatId || 'ug_message',
        });
      } catch (err) {
        // Notification constructor restrictions in some contexts
      }
    }

    // 4. In-App Floating Toast
    this.emitToast({
      id: 'toast_' + Date.now(),
      title: options.senderName,
      body: options.text,
      avatar: options.avatar,
      chatId: options.chatId,
      type: 'message',
    });
  }

  public notifyCall(options: {
    callerName: string;
    callerAvatar?: string;
    isVideo?: boolean;
    chatId?: string;
  }) {
    soundService.startIncomingRingtone();

    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([500, 250, 500, 250, 500]);
      } catch {}
    }

    if (this.isSupported() && Notification.permission === 'granted') {
      try {
        new Notification(`Unknown Gamer Call: ${options.callerName}`, {
          body: `Incoming ${options.isVideo ? 'Video' : 'Voice'} Call from @${options.callerName}`,
          icon: options.callerAvatar || '/src/assets/images/unknown_gamer_logo_1793437689232.jpg',
          tag: 'ug_call',
        });
      } catch {}
    }
  }

  public subscribeToToasts(listener: ToastListener) {
    this.toastListeners.add(listener);
    return () => {
      this.toastListeners.delete(listener);
    };
  }

  private emitToast(toast: InAppToast) {
    this.toastListeners.forEach(listener => {
      try {
        listener(toast);
      } catch (e) {
        console.error(e);
      }
    });
  }
}

export const notificationService = new NotificationService();
