export class NotificationService {
  private static wakeLockSentinel: unknown = null;

  public static async requestPermission(): Promise<NotificationPermission> {
    if (!('Notification' in window)) {
      console.warn('Notifications not supported by this browser');
      return 'denied';
    }
    return await Notification.requestPermission();
  }

  public static getPermissionState(): NotificationPermission {
    if (!('Notification' in window)) return 'denied';
    return Notification.permission;
  }

  public static async showPrayerNotification(title: string, body: string, isAlarm = false): Promise<void> {
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;

    try {
      // If service worker is ready, use it for persistent notification
      if ('serviceWorker' in navigator) {
        const reg = await navigator.serviceWorker.getRegistration();
        if (reg && reg.showNotification) {
          await reg.showNotification(title, {
            body,
            icon: '/pwa-192x192.png',
            badge: '/favicon.png',
            vibrate: isAlarm ? [300, 100, 300, 100, 500] : [500, 250, 500],
            tag: isAlarm ? 'salat-salah-alarm' : 'salat-adhan-notification',
            renotify: true,
            requireInteraction: true,
            data: { url: '/' },
          } as unknown as NotificationOptions);
          return;
        }
      }

      // Fallback to standard Window notification
      const windowOptions: NotificationOptions = {
        body,
        icon: '/pwa-192x192.png',
        tag: isAlarm ? 'salat-alarm' : 'salat-adhan',
      };
      new Notification(title, windowOptions);
    } catch (e) {
      console.warn('Could not fire notification:', e);
    }
  }

  public static async acquireWakeLock(): Promise<void> {
    if ('wakeLock' in navigator && !this.wakeLockSentinel) {
      try {
        const nav = navigator as unknown as { wakeLock: { request: (type: string) => Promise<unknown> } };
        this.wakeLockSentinel = await nav.wakeLock.request('screen');
      } catch (err) {
        console.warn('WakeLock failed:', err);
      }
    }
  }

  public static releaseWakeLock(): void {
    if (this.wakeLockSentinel) {
      try {
        const sentinel = this.wakeLockSentinel as { release: () => Promise<void> };
        sentinel.release();
      } catch {}
      this.wakeLockSentinel = null;
    }
  }
}
