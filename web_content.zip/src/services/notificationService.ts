import { CalendarDay, HebrewEvent, LocationPreset, UserSettings } from '../types';
import { calculateZmanim, formatTime12, getCalendarDay } from './hebrewCalendarService';

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  category: 'shabbat' | 'holiday' | 'fast' | 'verse' | 'event' | 'zman';
  timestamp: number;
  read: boolean;
  actionUrl?: string;
}

const STORAGE_NOTIF_KEY = 'hebrew_calendar_notifications_log';

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) {
    console.warn('This browser does not support desktop notifications');
    return 'denied';
  }
  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (error) {
    console.error('Failed to request notification permission', error);
    return 'denied';
  }
}

export function getNotificationPermission(): NotificationPermission {
  if (!('Notification' in window)) {
    return 'denied';
  }
  return Notification.permission;
}

export function sendBrowserNotification(
  title: string,
  options: NotificationOptions = {}
): Notification | null {
  if (!('Notification' in window) || Notification.permission !== 'granted') {
    return null;
  }
  try {
    const notif = new Notification(title, {
      icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="%23d97706"/><text x="50" y="65" font-size="50" text-anchor="middle" fill="white">✡</text></svg>',
      badge: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text x="50" y="70" font-size="60" text-anchor="middle">🕯️</text></svg>',
      ...options,
    });
    return notif;
  } catch (err) {
    console.warn('Error sending notification', err);
    return null;
  }
}

export function logInAppNotification(notification: Omit<AppNotification, 'id' | 'timestamp' | 'read'>): AppNotification {
  const item: AppNotification = {
    ...notification,
    id: 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    timestamp: Date.now(),
    read: false,
  };

  try {
    const existing = getStoredNotifications();
    const updated = [item, ...existing].slice(0, 50); // Keep last 50
    localStorage.setItem(STORAGE_NOTIF_KEY, JSON.stringify(updated));
  } catch {
    // Ignore localStorage errors
  }

  return item;
}

export function getStoredNotifications(): AppNotification[] {
  try {
    const raw = localStorage.getItem(STORAGE_NOTIF_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function markNotificationAsRead(id: string): void {
  try {
    const existing = getStoredNotifications();
    const updated = existing.map((n) => (n.id === id ? { ...n, read: true } : n));
    localStorage.setItem(STORAGE_NOTIF_KEY, JSON.stringify(updated));
  } catch {
    //
  }
}

export function clearAllNotifications(): void {
  try {
    localStorage.removeItem(STORAGE_NOTIF_KEY);
  } catch {
    //
  }
}

/**
 * Checks today's schedule and delivers notifications if enabled
 */
export function checkAndTriggerScheduledNotifications(
  todayDay: CalendarDay,
  settings: UserSettings,
  location: LocationPreset,
  events: HebrewEvent[]
): void {
  if (!settings.notifications.enabled) return;

  const now = new Date();

  // 1. Shabbat / Yom Tov Candle Lighting notification
  if (settings.notifications.shabbatCandles && (todayDay.isErevShabbat || todayDay.isYomTov)) {
    const zmanim = calculateZmanim(now, location, {
      candleLightingOffset: settings.candleLightingOffset,
    });
    if (zmanim.candleLighting) {
      const minutesBefore = settings.notifications.shabbatMinutesBefore || 18;
      const targetAlertTime = new Date(
        zmanim.candleLighting.getTime() - minutesBefore * 60 * 1000
      );

      const diffMs = now.getTime() - targetAlertTime.getTime();
      // Check if within 5-minute trigger window
      if (diffMs >= 0 && diffMs < 5 * 60 * 1000) {
        const notifKey = `candle_alert_${todayDay.dateKey}`;
        if (!sessionStorage.getItem(notifKey)) {
          sessionStorage.setItem(notifKey, '1');
          const title = todayDay.isErevShabbat
            ? `🕯️ Shabbat Candle Lighting Reminder`
            : `🕯️ Yom Tov Candle Lighting Reminder`;
          const body = `Candles should be lit at ${formatTime12(zmanim.candleLighting)} (${location.name}). Shabbat Shalom!`;

          sendBrowserNotification(title, { body });
          logInAppNotification({
            title,
            body,
            category: 'shabbat',
          });
        }
      }
    }
  }

  // 2. Fast day alerts
  if (todayDay.isFastDay && settings.notifications.holidays) {
    const notifKey = `fast_alert_${todayDay.dateKey}`;
    if (!sessionStorage.getItem(notifKey)) {
      sessionStorage.setItem(notifKey, '1');
      const fastHoliday = todayDay.holidays.find((h) => h.category === 'fast');
      const title = `🕯️ ${fastHoliday?.name || 'Fast Day'} Alert`;
      const body = `Today is ${fastHoliday?.name || 'a fast day'}. Check Zmanim for precise start and end times in ${location.name}.`;

      sendBrowserNotification(title, { body });
      logInAppNotification({
        title,
        body,
        category: 'fast',
      });
    }
  }

  // 3. Personal Hebrew Events for today (Yahrzeit, Birthday, Anniversary)
  if (settings.notifications.personalEvents && todayDay.events.length > 0) {
    todayDay.events.forEach((ev) => {
      const notifKey = `event_alert_${ev.id}_${todayDay.dateKey}`;
      if (!sessionStorage.getItem(notifKey)) {
        sessionStorage.setItem(notifKey, '1');
        let icon = '🎉';
        if (ev.type === 'yahrzeit' || ev.type === 'memorial') icon = '🕯️';
        if (ev.type === 'anniversary') icon = '💍';

        const title = `${icon} Hebrew Calendar Event: ${ev.title}`;
        const body = `Today is ${todayDay.hebrewDateStrHe} (${todayDay.hebrewDateStr}): ${ev.title}. ${ev.notes ? ev.notes : ''}`;

        sendBrowserNotification(title, { body });
        logInAppNotification({
          title,
          body,
          category: 'event',
        });
      }
    });
  }
}

/**
 * Periodically checks for notification conditions (Candle lighting, daily verse, fasts)
 */
export function scheduleNotificationChecks(
  events: HebrewEvent[],
  location: LocationPreset,
  settings: UserSettings
): () => void {
  const check = () => {
    try {
      const todayDay = getCalendarDay(new Date(), location, events);
      checkAndTriggerScheduledNotifications(todayDay, settings, location, events);
    } catch {
      //
    }
  };

  // Run on start
  check();

  // Run every 60 seconds
  const interval = setInterval(check, 60000);
  return () => clearInterval(interval);
}

