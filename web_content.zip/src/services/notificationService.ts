import { AppNotification } from '../types';

type NotificationListener = (notif: AppNotification) => void;
const listeners: Set<NotificationListener> = new Set();

let lastKnownLatestId: string | null = null;
let pollTimer: any = null;

// Play gentle subtle notification audio chime
export function playNotificationSound() {
  try {
    if (typeof window === 'undefined') return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    
    // Play warm dual-tone chime (F#5 to A#5)
    const now = ctx.currentTime;
    
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(740, now); // F#5
    gain1.gain.setValueAtTime(0.08, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.35);

    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(932, now + 0.1); // A#5
    gain2.gain.setValueAtTime(0.1, now + 0.1);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.1);
    osc2.stop(now + 0.55);
  } catch (err) {
    // Audio context may be restricted before user interaction
  }
}

// Subscribe to in-app foreground notification events
export function subscribeToForegroundNotifications(callback: NotificationListener): () => void {
  listeners.add(callback);
  return () => {
    listeners.delete(callback);
  };
}

export function broadcastForegroundNotification(notif: AppNotification) {
  playNotificationSound();
  listeners.forEach(cb => {
    try {
      cb(notif);
    } catch (e) {}
  });
}

// Get or generate persistent client device token
export function getOrCreateDeviceToken(): string {
  let token = localStorage.getItem('edumind_fcm_device_token');
  if (!token) {
    token = `web-fcm-${Date.now()}-${Math.random().toString(36).substring(2, 12)}`;
    localStorage.setItem('edumind_fcm_device_token', token);
  }
  return token;
}

// Register device with server
export async function registerDeviceWithServer(params: {
  userId: string;
  examTarget?: string;
  language?: string;
}) {
  try {
    const fcmToken = getOrCreateDeviceToken();
    const response = await fetch('/api/device/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: params.userId || 'guest_user',
        fcmToken,
        deviceType: 'web',
        examTarget: params.examTarget,
        language: params.language
      })
    });
    return await response.json();
  } catch (err) {
    console.error('Failed to register device token:', err);
    return null;
  }
}

// Request Browser Push Notification Permission
export async function requestPushPermission(params: {
  userId: string;
  examTarget?: string;
  language?: string;
}): Promise<NotificationPermission | 'unsupported'> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }

  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      // Register service worker if available
      if ('serviceWorker' in navigator) {
        try {
          await navigator.serviceWorker.register('/firebase-messaging-sw.js');
        } catch (swErr) {
          console.warn('Service worker registration:', swErr);
        }
      }
      await registerDeviceWithServer(params);
    }
    return permission;
  } catch (err) {
    console.error('Error requesting notification permission:', err);
    return 'denied';
  }
}

// Check notification permission status
export function getPushPermissionStatus(): NotificationPermission | 'unsupported' {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission;
}

// Initialize background polling to check for new notifications while app is in foreground
export function initForegroundNotificationWatcher(params: {
  userId: string;
  userExam?: string;
  userLanguage?: string;
  onCountUpdate?: (count: number) => void;
}) {
  if (pollTimer) clearInterval(pollTimer);

  const checkNotifications = async () => {
    try {
      const { userId, userExam, userLanguage, onCountUpdate } = params;
      const query = new URLSearchParams({
        userId: userId || 'guest_user',
        ...(userExam && { userExam }),
        ...(userLanguage && { userLanguage }),
        limit: '5',
        page: '1'
      });

      const res = await fetch(`/api/notifications?${query.toString()}`);
      if (!res.ok) return;

      const data = await res.json();
      if (data.success) {
        if (typeof onCountUpdate === 'function') {
          onCountUpdate(data.unreadCount || 0);
        }

        // Check if there is a brand new unread notification we haven't broadcasted yet
        if (Array.isArray(data?.items) && data.items.length > 0 && data.items[0]) {
          const newest = data.items[0] as AppNotification;
          if (newest && lastKnownLatestId && newest.notificationId !== lastKnownLatestId && !newest.read) {
            broadcastForegroundNotification(newest);
          }
          if (newest?.notificationId) {
            lastKnownLatestId = newest.notificationId;
          }
        }
      }
    } catch (e) {
      // Background poll failure is silent
    }
  };

  // Initial check
  checkNotifications();

  // Poll every 25 seconds
  pollTimer = setInterval(checkNotifications, 25000);

  return () => {
    if (pollTimer) clearInterval(pollTimer);
  };
}
