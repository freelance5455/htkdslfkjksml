"use client";

import { Position, ClosedTrade, TabId } from "@/types";
import { onTradeClosed, onTradeOpened, useTradingStore } from "./useTradingStore";

/**
 * System-Level OS & Native Device Push Notification Engine.
 * Registers a dedicated service worker (public/sw.js) and delivers OS
 * system-tray notifications (lock screen banners, vibration, audio)
 * even when the tab is backgrounded. Deep-links open the relevant tab.
 */
class NotificationService {
  private reg: ServiceWorkerRegistration | null = null;
  private started = false;
  private audioCtx: AudioContext | null = null;

  async start() {
    if (this.started || typeof window === "undefined") return;
    this.started = true;

    if ("serviceWorker" in navigator) {
      try {
        this.reg = await navigator.serviceWorker.register("/sw.js");
        // deep-link messages from SW notification clicks
        navigator.serviceWorker.addEventListener("message", (ev) => {
          const tab = ev.data?.openTab as TabId | undefined;
          if (tab) useTradingStore.getState().setActiveTab(tab);
        });
      } catch { /* sw unavailable */ }
    }

    onTradeOpened((p) => this.notifyOpen(p));
    onTradeClosed((t) => this.notifyClose(t));
  }

  async requestPermission(): Promise<boolean> {
    if (typeof window === "undefined" || !("Notification" in window)) return false;
    try {
      const res = await Notification.requestPermission();
      const ok = res === "granted";
      useTradingStore.getState().setSettings({ notificationsEnabled: ok });
      if (ok) {
        this.push("🔔 התראות OS הופעלו", "תקבל התראות מערכת על עסקאות בוט, SL/TP וסיגנלים גם כשהאפליקציה ברקע", "ai");
      }
      return ok;
    } catch {
      return false;
    }
  }

  get permission(): NotificationPermission | "unsupported" {
    if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
    return Notification.permission;
  }

  push(title: string, body: string, tab: TabId = "active") {
    const st = useTradingStore.getState();
    if (st.settings.soundEnabled) this.beep();
    if (!st.settings.notificationsEnabled || this.permission !== "granted") return;
    const opts: NotificationOptions & { vibrate?: number[] } = {
      body,
      tag: `ct-${Date.now()}`,
      icon: "/icon.svg",
      badge: "/icon.svg",
      vibrate: [120, 60, 120],
      data: { openTab: tab },
    };
    if (this.reg) {
      this.reg.showNotification(title, opts).catch(() => this.fallback(title, opts));
    } else {
      this.fallback(title, opts);
    }
  }

  private fallback(title: string, opts: NotificationOptions) {
    try { new Notification(title, opts); } catch { /* ignore */ }
  }

  private beep() {
    try {
      type AudioWindow = Window & { webkitAudioContext?: typeof AudioContext };
      const w = window as AudioWindow;
      const Ctor = window.AudioContext ?? w.webkitAudioContext;
      if (!Ctor) return;
      this.audioCtx = this.audioCtx ?? new Ctor();
      const ctx = this.audioCtx;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);
      osc.connect(gain).connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    } catch { /* audio blocked */ }
  }

  private notifyOpen(p: Position) {
    const src = p.source === "BOT" ? "🤖 הבוט פתח עסקת דמו" : p.source === "COPY" ? "👥 עסקת Copy-Trading שוכפלה" : "✍️ עסקה ידנית נפתחה";
    this.push(
      `${src} — ${p.symbol}`,
      `${p.side === "LONG" ? "לונג 🟢" : "שורט 🔴"} @ $${p.entryPrice.toFixed(2)} | SL: $${p.stopLoss.toFixed(2)} | TP: $${p.takeProfit.toFixed(2)}`,
      "active",
    );
  }

  private notifyClose(t: ClosedTrade) {
    this.push(
      `${t.pnl >= 0 ? "🟢 רווח" : "🔴 הפסד"} ${t.pnl >= 0 ? "+" : ""}$${t.pnl.toFixed(2)} — ${t.symbol}`,
      `${t.closeReason} | כניסה $${t.entryPrice.toFixed(2)} → יציאה $${t.exitPrice.toFixed(2)} (${t.pnlPct >= 0 ? "+" : ""}${t.pnlPct.toFixed(2)}%)`,
      "tax",
    );
  }
}

export const notificationService = new NotificationService();
