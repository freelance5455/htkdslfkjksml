export interface LiveSessionOptions {
  backendUrl?: string;
  onStatusChange: (status: 'disconnected' | 'connecting' | 'connected' | 'error') => void;
  onTextReceived: (text: string, isUser: boolean) => void;
  onError: (error: string) => void;
}

export class LiveSession {
  private ws: WebSocket | null = null;
  private options: LiveSessionOptions;
  private mediaRecorder: MediaRecorder | null = null;
  private audioStream: MediaStream | null = null;
  private recordedChunks: Blob[] = [];
  private isRecording = false;

  constructor(options: LiveSessionOptions) {
    this.options = options;
  }

  private getWsEndpoint(): string {
    if (this.options.backendUrl && this.options.backendUrl.trim() !== '') {
      let url = this.options.backendUrl.trim();
      if (url.startsWith('http://')) {
        url = url.replace('http://', 'ws://');
      } else if (url.startsWith('https://')) {
        url = url.replace('https://', 'wss://');
      } else if (!url.startsWith('ws://') && !url.startsWith('wss://')) {
        url = `wss://${url}`;
      }
      return url.endsWith('/') ? `${url}ws/live` : `${url}/ws/live`;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${window.location.host}/ws/live`;
  }

  private getApiEndpoint(): string {
    if (this.options.backendUrl && this.options.backendUrl.trim() !== '') {
      let url = this.options.backendUrl.trim();
      if (url.startsWith('ws://')) {
        url = url.replace('ws://', 'http://');
      } else if (url.startsWith('wss://')) {
        url = url.replace('wss://', 'https://');
      } else if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = `https://${url}`;
      }
      return url.endsWith('/') ? `${url}api/chat` : `${url}/api/chat`;
    }

    return '/api/chat';
  }

  connect(): void {
    const wsUrl = this.getWsEndpoint();
    this.options.onStatusChange('connecting');

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.options.onStatusChange('connected');
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'text') {
            this.options.onTextReceived(data.content, false);
            if (data.audio) {
              this.playAudioResponse(data.audio);
            }
          } else if (data.type === 'error') {
            this.options.onError(data.message);
          }
        } catch {
          if (typeof event.data === 'string') {
            this.options.onTextReceived(event.data, false);
          }
        }
      };

      this.ws.onerror = (err) => {
        console.warn('[LiveSession] WebSocket live stream unavailable, using REST API fallback:', err);
        this.options.onStatusChange('error');
      };

      this.ws.onclose = () => {
        this.options.onStatusChange('disconnected');
      };
    } catch (e: any) {
      console.warn('[LiveSession] WebSocket connection error, using REST fallback:', e);
      this.options.onStatusChange('error');
    }
  }

  disconnect(): void {
    this.stopAudioRecording();
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.options.onStatusChange('disconnected');
  }

  async sendTextMessage(text: string): Promise<void> {
    this.options.onTextReceived(text, true);

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'text', content: text }));
      return;
    }

    // HTTP REST Fallback
    try {
      const response = await fetch(this.getApiEndpoint(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const data = await response.json();
      if (data.reply) {
        this.options.onTextReceived(data.reply, false);
      } else if (data.error) {
        this.options.onError(data.error);
      }
    } catch (err: any) {
      console.error('[LiveSession] REST API fallback failed:', err);
      this.options.onError('Unable to reach Hinata backend server.');
    }
  }

  async startAudioRecording(): Promise<boolean> {
    try {
      this.recordedChunks = [];
      this.audioStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true
        }
      });

      this.mediaRecorder = new MediaRecorder(this.audioStream, {
        mimeType: MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/ogg'
      });

      this.mediaRecorder.ondataavailable = async (event) => {
        if (event.data.size > 0) {
          this.recordedChunks.push(event.data);
          if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            const buffer = await event.data.arrayBuffer();
            const base64 = btoa(
              new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
            );
            this.ws.send(JSON.stringify({ type: 'audio', data: base64 }));
          }
        }
      };

      this.mediaRecorder.start(250);
      this.isRecording = true;
      return true;
    } catch (err: any) {
      console.error('[LiveSession] Error starting mic:', err);
      this.options.onError('Unable to access microphone: ' + (err.message || err));
      return false;
    }
  }

  async stopAudioRecording(): Promise<void> {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop();
      this.isRecording = false;
    }

    if (this.audioStream) {
      this.audioStream.getTracks().forEach((track) => track.stop());
      this.audioStream = null;
    }

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'audio_end' }));
    } else if (this.recordedChunks.length > 0) {
      // Send accumulated voice audio over HTTP REST
      try {
        const audioBlob = new Blob(this.recordedChunks, { type: 'audio/webm' });
        const buffer = await audioBlob.arrayBuffer();
        const base64 = btoa(
          new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
        );

        this.options.onTextReceived('🎙️ [Voice Audio Message]', true);

        const response = await fetch(this.getApiEndpoint(), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ audio: base64 })
        });

        if (response.ok) {
          const data = await response.json();
          if (data.reply) {
            this.options.onTextReceived(data.reply, false);
          }
        }
      } catch (e) {
        console.error('[LiveSession] Failed to send voice audio over REST:', e);
      }
    }
  }

  private playAudioResponse(base64Data: string): void {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const binaryString = atob(base64Data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      audioCtx.decodeAudioData(bytes.buffer, (buffer) => {
        const source = audioCtx.createBufferSource();
        source.buffer = buffer;
        source.connect(audioCtx.destination);
        source.start(0);
      });
    } catch (e) {
      console.error('[LiveSession] Audio playback error:', e);
    }
  }
}
