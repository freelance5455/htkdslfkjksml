import { AudioRecorder } from './AudioRecorder';
import { AudioStreamer } from './AudioStreamer';
import { musicPlayer } from './MusicPlayer';
import {
  SessionState,
  ServerMessage,
  ClientMessage,
  ToolCallData,
  MoodTheme,
  ExpressionType,
  ExecutedAction,
} from '../types';

export interface LiveSessionCallbacks {
  onStateChange: (state: SessionState) => void;
  onExpressionChange: (expression: ExpressionType, commentary?: string) => void;
  onThemeChange: (theme: MoodTheme, reason?: string) => void;
  onActionExecuted: (action: ExecutedAction) => void;
  onError: (errorMsg: string) => void;
  onVoiceChange?: (voice: string) => void;
  onTimerCreated?: (seconds: number, label: string) => void;
  onNoteCreated?: (text: string, category?: string) => void;
  onMusicVibe?: (vibe: 'lofi' | 'ambient' | 'party' | 'alert', action: 'play' | 'stop') => void;
  onMathResult?: (calculation: string, result: string) => void;
  onDownloadZip?: () => void;
}

export class LiveSession {
  private ws: WebSocket | null = null;
  private recorder: AudioRecorder | null = null;
  private streamer: AudioStreamer | null = null;
  private state: SessionState = 'disconnected';
  private selectedVoice = 'Aoede';
  private callbacks: LiveSessionCallbacks;
  private userBargeInThreshold = 0.35;
  private lastBargeInTime = 0;

  constructor(callbacks: LiveSessionCallbacks) {
    this.callbacks = callbacks;
  }

  getState(): SessionState {
    return this.state;
  }

  private setState(newState: SessionState) {
    if (this.state === newState) return;
    this.state = newState;
    this.callbacks.onStateChange(newState);
  }

  async connect(voiceName = 'Aoede'): Promise<void> {
    if (this.state === 'connecting' || this.state === 'listening' || this.state === 'speaking') {
      return;
    }

    this.selectedVoice = voiceName;
    this.setState('connecting');

    try {
      // 1. Initialize AudioStreamer
      this.streamer = new AudioStreamer((isSpeaking) => {
        if (isSpeaking) {
          this.setState('speaking');
        } else if (this.state === 'speaking') {
          this.setState('listening');
        }
      });
      await this.streamer.init();

      // 2. Initialize AudioRecorder
      this.recorder = new AudioRecorder(
        (base64Chunk) => {
          this.handleMicChunk(base64Chunk);
        },
        (err) => {
          console.error('Audio recorder error:', err);
          this.callbacks.onError(`Microphone error: ${err.message}`);
          this.disconnect();
        }
      );
      await this.recorder.start();

      // 3. Establish WebSocket connection
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host = window.location.host;
      const wsUrl = `${protocol}//${host}/api/live`;

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.sendMessage({
          type: 'config',
          voice: this.selectedVoice,
        });
        this.setState('listening');
      };

      this.ws.onmessage = (event) => {
        try {
          const msg: ServerMessage = JSON.parse(event.data);
          this.handleServerMessage(msg);
        } catch (err) {
          console.error('Failed to parse incoming WS message:', err);
        }
      };

      this.ws.onerror = (e) => {
        console.error('WebSocket connection error:', e);
        this.callbacks.onError('Neural link communication error with server.');
        this.setState('error');
      };

      this.ws.onclose = () => {
        if (this.state !== 'disconnected') {
          this.disconnect();
        }
      };
    } catch (err: any) {
      console.error('Failed to connect live session:', err);
      this.callbacks.onError(err?.message || 'Could not access microphone or server.');
      this.disconnect();
      this.setState('error');
    }
  }

  private handleMicChunk(base64Chunk: string) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    if (this.state === 'speaking' && this.recorder) {
      const micLevel = this.recorder.getMicLevel();
      const now = Date.now();
      if (micLevel > this.userBargeInThreshold && now - this.lastBargeInTime > 600) {
        this.lastBargeInTime = now;
        this.streamer?.interrupt();
        this.sendMessage({ type: 'interrupt' });
        this.setState('listening');
      }
    }

    this.sendMessage({
      type: 'audio',
      audio: base64Chunk,
    });
  }

  private handleServerMessage(msg: ServerMessage) {
    switch (msg.type) {
      case 'audio':
        if (msg.audio) {
          this.streamer?.playChunk(msg.audio);
        }
        break;

      case 'interrupted':
        this.streamer?.interrupt();
        this.setState('listening');
        break;

      case 'turnComplete':
        this.streamer?.setTurnComplete();
        break;

      case 'toolCall':
        if (msg.calls && msg.calls.length > 0) {
          this.executeToolCalls(msg.calls);
        }
        break;

      case 'error':
        this.callbacks.onError(msg.message || 'Gemini Live encountered an error.');
        break;
    }
  }

  private executeToolCalls(calls: ToolCallData[]) {
    for (const call of calls) {
      const { name, args, id } = call;

      if (name === 'openWebsite') {
        const url = args.url || 'https://google.com';
        const siteName = args.siteName || url;
        let blocked = false;

        try {
          const win = window.open(url, '_blank', 'noopener,noreferrer');
          if (!win || win.closed || typeof win.closed === 'undefined') {
            blocked = true;
          }
        } catch {
          blocked = true;
        }

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'openWebsite',
          timestamp: Date.now(),
          data: { url, siteName, comment: args.comment },
          status: blocked ? 'blocked' : 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: {
            success: true,
            opened: !blocked,
            message: blocked ? 'Popup was blocked by browser, card shown to user' : 'Website opened in new tab',
          },
        });
      } else if (name === 'searchWeb') {
        const query = args.query || '';
        const platform = args.platform || 'google';
        let searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
        if (platform === 'youtube') {
          searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
        } else if (platform === 'wikipedia') {
          searchUrl = `https://en.wikipedia.org/wiki/Special:Search?search=${encodeURIComponent(query)}`;
        }

        let blocked = false;
        try {
          const win = window.open(searchUrl, '_blank', 'noopener,noreferrer');
          if (!win || win.closed) blocked = true;
        } catch {
          blocked = true;
        }

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'searchWeb',
          timestamp: Date.now(),
          data: { query, platform, url: searchUrl },
          status: blocked ? 'blocked' : 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: { success: true, query, platform, opened: !blocked },
        });
      } else if (name === 'setTimer') {
        const seconds = Math.max(1, Number(args.seconds) || 60);
        const label = args.label || 'Timer';
        this.callbacks.onTimerCreated?.(seconds, label);

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'setTimer',
          timestamp: Date.now(),
          data: { seconds, label },
          status: 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: { success: true, seconds, label },
        });
      } else if (name === 'takeNote') {
        const text = args.text || '';
        const category = args.category || 'Note';
        this.callbacks.onNoteCreated?.(text, category);

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'takeNote',
          timestamp: Date.now(),
          data: { text, category },
          status: 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: { success: true, saved: true },
        });
      } else if (name === 'playMusicVibe') {
        const vibe = (args.vibe as any) || 'lofi';
        const actionType = (args.action as any) || 'play';

        if (actionType === 'stop') {
          musicPlayer.stop();
        } else {
          musicPlayer.playVibe(vibe);
        }

        this.callbacks.onMusicVibe?.(vibe, actionType);

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'playMusicVibe',
          timestamp: Date.now(),
          data: { vibe, action: actionType },
          status: 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: { success: true, vibe, action: actionType },
        });
      } else if (name === 'downloadZip') {
        // Trigger browser download of zip file
        const a = document.createElement('a');
        a.href = '/api/download-zip';
        a.download = 'roxy-voice-assistant.zip';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        this.callbacks.onDownloadZip?.();

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'downloadZip',
          timestamp: Date.now(),
          data: { file: 'roxy-voice-assistant.zip' },
          status: 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: { success: true, file: 'roxy-voice-assistant.zip', downloaded: true },
        });
      } else if (name === 'calculateMath') {
        const calculation = args.calculation || '';
        let result = '';
        try {
          // Safe math evaluator using Function without arbitrary variables
          const sanitized = calculation.replace(/[^0-9+\-*/().%^ ]/g, '');
          // eslint-disable-next-line no-eval
          result = String(eval(sanitized));
        } catch {
          result = 'Calculated';
        }

        this.callbacks.onMathResult?.(calculation, result);

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'calculateMath',
          timestamp: Date.now(),
          data: { calculation, result },
          status: 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: { success: true, calculation, result },
        });
      } else if (name === 'deviceControl') {
        const actionType = args.action || '';
        if (actionType === 'copy_clipboard' && args.text) {
          navigator.clipboard.writeText(args.text);
        } else if (actionType === 'toggle_fullscreen') {
          if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(() => {});
          } else {
            document.exitFullscreen().catch(() => {});
          }
        }

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'deviceControl',
          timestamp: Date.now(),
          data: { action: actionType, text: args.text },
          status: 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: { success: true, executed: actionType },
        });
      } else if (name === 'changeMoodTheme') {
        const theme = args.theme as MoodTheme;
        if (theme) {
          this.callbacks.onThemeChange(theme, args.reason);
        }

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'changeMoodTheme',
          timestamp: Date.now(),
          data: { theme, reason: args.reason },
          status: 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: { success: true, activeTheme: theme },
        });
      } else if (name === 'triggerExpression') {
        const expression = (args.expression as ExpressionType) || 'smirk';
        this.callbacks.onExpressionChange(expression, args.commentary);

        const action: ExecutedAction = {
          id: id || String(Date.now()),
          type: 'triggerExpression',
          timestamp: Date.now(),
          data: { expression, commentary: args.commentary },
          status: 'success',
        };
        this.callbacks.onActionExecuted(action);

        this.sendMessage({
          type: 'toolResponse',
          id,
          name,
          response: { success: true, expression },
        });
      }
    }
  }

  sendMessage(msg: ClientMessage) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
    }
  }

  setMute(muted: boolean) {
    this.recorder?.setMute(muted);
  }

  isMuted(): boolean {
    return this.recorder?.getMuted() ?? false;
  }

  switchVoice(voiceName: string) {
    this.selectedVoice = voiceName;
    this.callbacks.onVoiceChange?.(voiceName);
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.sendMessage({
        type: 'config',
        voice: voiceName,
      });
    }
  }

  getVoice(): string {
    return this.selectedVoice;
  }

  getMicLevel(): number {
    return this.recorder?.getMicLevel() ?? 0;
  }

  getSpeakerLevel(): number {
    return this.streamer?.getOutputLevel() ?? 0;
  }

  getMicFrequencies(targetArray: Uint8Array): void {
    this.recorder?.getFrequencyData(targetArray);
  }

  getSpeakerFrequencies(targetArray: Uint8Array): void {
    this.streamer?.getFrequencyData(targetArray);
  }

  disconnect() {
    this.setState('disconnected');

    if (this.ws) {
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }

    if (this.recorder) {
      this.recorder.stop();
      this.recorder = null;
    }

    if (this.streamer) {
      this.streamer.stop();
      this.streamer = null;
    }
  }
}
