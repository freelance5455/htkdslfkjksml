/**
 * Comprehensive Automated Test Suite for J.A.R.V.I.S. Time & Speech Engine
 * Tests all 24 hours (0-23) and all 60 minutes (0-59) -> 1,440 combinations!
 * 
 * Run with: npx tsx src/services/timeService.test.ts
 */

import { 
  timeService, 
  formatTimeHindiSpeech, 
  getTimePeriodHindi, 
  HINDI_HOURS, 
  HINDI_MINUTES 
} from './timeService';
import { voiceEngine } from './voiceService';

function runTimeTests() {
  console.log('=====================================================');
  console.log('JARVIS TIME ENGINE: RUNNING 1,440-COMBINATION TEST...');
  console.log('=====================================================');

  let passedCombinations = 0;
  let totalCombinations = 0;

  // Test 1: Verify all 24 hours and 60 minutes
  for (let h = 0; h < 24; h++) {
    for (let m = 0; m < 60; m++) {
      totalCombinations++;

      const speech = formatTimeHindiSpeech(h, m);
      const period = getTimePeriodHindi(h);
      const hour12 = h % 12 || 12;
      const expectedHourWord = HINDI_HOURS[hour12];

      if (!speech) {
        throw new Error(`Failed for ${h}:${m}: speech is empty`);
      }

      // Check period assignment
      if (h >= 4 && h < 12 && period !== 'सुबह') {
        throw new Error(`Invalid period for morning hour ${h}: got ${period}`);
      }
      if (h >= 12 && h < 16 && period !== 'दोपहर') {
        throw new Error(`Invalid period for afternoon hour ${h}: got ${period}`);
      }
      if (h >= 16 && h < 20 && period !== 'शाम') {
        throw new Error(`Invalid period for evening hour ${h}: got ${period}`);
      }
      if ((h >= 20 || h < 4) && period !== 'रात') {
        throw new Error(`Invalid period for night hour ${h}: got ${period}`);
      }

      // Check formatting structure
      if (m === 0) {
        const expected = `${period} के ${expectedHourWord} बजे`;
        if (speech !== expected) {
          throw new Error(`Mismatch at ${h}:00. Expected "${expected}", got "${speech}"`);
        }
      } else {
        const expectedMinuteWord = HINDI_MINUTES[m];
        const expected = `${period} ${expectedHourWord} बजकर ${expectedMinuteWord} मिनट`;
        if (speech !== expected) {
          throw new Error(`Mismatch at ${h}:${m}. Expected "${expected}", got "${speech}"`);
        }
      }

      // Ensure minutes are NEVER converted to hour (e.g. "3 PM" or "hour")
      if (m === 15 && speech.includes('तीन बजे') && hour12 !== 3) {
        throw new Error(`CRITICAL BUG: Minute 15 was converted to 3 PM at hour ${h}! Output: ${speech}`);
      }

      passedCombinations++;
    }
  }

  console.log(`✓ All 24 hours x 60 minutes (${passedCombinations}/${totalCombinations} combinations) passed perfectly!`);

  // Test 2: Verify Exact User-Requested Test Cases
  console.log('\n--- Verifying Exact User-Specified Test Cases ---');

  const testCases = [
    { h: 7, m: 15, expected: 'सुबह सात बजकर पंद्रह मिनट', label: '07:15 AM' },
    { h: 12, m: 15, expected: 'दोपहर बारह बजकर पंद्रह मिनट', label: '12:15 PM' },
    { h: 15, m: 15, expected: 'दोपहर तीन बजकर पंद्रह मिनट', label: '03:15 PM' },
    { h: 19, m: 15, expected: 'शाम सात बजकर पंद्रह मिनट', label: '07:15 PM' },
    { h: 21, m: 45, expected: 'रात नौ बजकर पैंतालीस मिनट', label: '09:45 PM' },
    { h: 0, m: 0, expected: 'रात के बारह बजे', label: '12:00 AM' },
    { h: 12, m: 0, expected: 'दोपहर के बारह बजे', label: '12:00 PM' },
    { h: 16, m: 0, expected: 'शाम के चार बजे', label: '04:00 PM' },
    { h: 20, m: 0, expected: 'रात के आठ बजे', label: '08:00 PM' },
    { h: 4, m: 0, expected: 'सुबह के चार बजे', label: '04:00 AM' },
  ];

  for (const tc of testCases) {
    const actual = formatTimeHindiSpeech(tc.h, tc.m);
    if (actual !== tc.expected) {
      throw new Error(`Test failed for ${tc.label}! Expected: "${tc.expected}", got: "${actual}"`);
    }
    console.log(`✓ ${tc.label} -> "${actual}"`);
  }

  // Test 3: Verify VoiceEngine Speech Sanitization
  console.log('\n--- Verifying Voice Engine Speech Cleaning ---');
  
  const textWithParentheses = 'Harman Sir, अभी समय शाम सात बजकर पंद्रह मिनट है। (7:15 PM)';
  const cleanedSpeech = voiceEngine.cleanSpeechText(textWithParentheses);
  console.log('Input Text:  ', textWithParentheses);
  console.log('Clean Speech:', cleanedSpeech);
  if (cleanedSpeech.includes('7:15') || cleanedSpeech.includes('PM')) {
    throw new Error('Voice cleanSpeechText failed to strip visual parenthesis timestamp!');
  }
  if (!cleanedSpeech.includes('शाम सात बजकर पंद्रह मिनट')) {
    throw new Error('Voice cleanSpeechText damaged natural Hindi speech!');
  }
  console.log('✓ Visual timestamp safely stripped from voice synthesis text!');

  // Test 4: Verify English and Raw Numeric Time Normalization
  const englishInput = 'Harman Sir, the time is 7:15 PM.';
  const cleanedEnglish = voiceEngine.cleanSpeechText(englishInput);
  console.log('English Input: ', englishInput);
  console.log('Clean English: ', cleanedEnglish);
  if (cleanedEnglish.includes(':')) {
    throw new Error('English colon was not sanitized, which could trigger TTS military hour bug!');
  }
  console.log('✓ English colon sanitized to avoid TTS minute-to-hour parsing!');

  console.log('\n=====================================================');
  console.log('ALL TIME & SPEECH AUTOMATED TESTS PASSED (100% SUCCESS)');
  console.log('=====================================================');
}

runTimeTests();
