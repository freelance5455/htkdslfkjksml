export interface GoogleMapPlace {
  id: string;
  name: string;
  nameBn: string;
  category: string;
  categoryBn: string;
  rating: number;
  totalReviews: number;
  address: string;
  addressBn: string;
  city: string;
  imageUrl: string;
  mapWebsiteUrl: string;
  rewardCoins: number; // 30 Coins as requested
  description: string;
  descriptionBn: string;
}

export const GOOGLE_MAP_PLACES: GoogleMapPlace[] = [
  {
    id: 'gmap-1',
    name: 'Royal Bengal Luxury Hotel & Banquets',
    nameBn: 'রয়্যাল বেঙ্গল লাক্সারি হোটেল অ্যান্ড ব্যানকুয়েট',
    category: 'Hotel & Hospitality',
    categoryBn: 'হোটেল ও হসপিটালিটি',
    rating: 4.8,
    totalReviews: 2450,
    address: 'Park Street, Kolkata, West Bengal 700016',
    addressBn: 'পার্ক স্ট্রিট, কলকাতা, পশ্চিমবঙ্গ ৭০০০১৬',
    city: 'Kolkata',
    imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=400&q=80',
    mapWebsiteUrl: 'https://www.google.com/maps/search/Royal+Bengal+Hotel+Park+Street+Kolkata',
    rewardCoins: 30,
    description: 'Premier 5-star heritage hotel and restaurant serving authentic Bengali cuisine and luxury stays.',
    descriptionBn: 'প্রিমিয়াম ৫-স্টার হোটেল ও অথেন্টিক বাঙালি খাবার ও থাকার বিশ্বমানের ব্যবস্থা।'
  },
  {
    id: 'gmap-2',
    name: 'TechZone Multi-Brand Gadget Store',
    nameBn: 'টেকজোন মাল্টি-ব্র্যান্ড গ্যাজেট স্টোর',
    category: 'Electronics & Mobile Care',
    categoryBn: 'ইলেকট্রনিক্স ও মোবাইল কেয়ার',
    rating: 4.9,
    totalReviews: 3120,
    address: 'Chandni Chowk Market, Central Kolkata 700072',
    addressBn: 'চাঁদনি চক মার্কেট, সেন্ট্রাল কলকাতা ৭০০০৭২',
    city: 'Kolkata',
    imageUrl: 'https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=400&q=80',
    mapWebsiteUrl: 'https://www.google.com/maps/search/TechZone+Electronics+Chandni+Chowk+Kolkata',
    rewardCoins: 30,
    description: 'Authorized service center and retail store for Apple, Samsung, OnePlus, laptops and smart gadgets.',
    descriptionBn: 'অ্যাপল, স্যামসাং, ওয়ানপ্লাস স্মার্টফোন ও ল্যাপটপের অনুমোদিত শোরুম ও কেয়ার সেন্টার।'
  },
  {
    id: 'gmap-3',
    name: 'Grand Gourmet Biryani & Kebabs',
    nameBn: 'গ্র্যান্ড গুরমে বিরিয়ানি ও কাবাব প্যালেস',
    category: 'Restaurant & Dining',
    categoryBn: 'রেস্তোরাঁ ও ডাইনিং',
    rating: 4.7,
    totalReviews: 4890,
    address: 'Salt Lake Sector 5, Kolkata 700091',
    addressBn: 'সল্টলেক সেক্টর ৫, কলকাতা ৭০০০৯১',
    city: 'Kolkata',
    imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=400&q=80',
    mapWebsiteUrl: 'https://www.google.com/maps/search/Grand+Gourmet+Biryani+Salt+Lake+Sector+5',
    rewardCoins: 30,
    description: 'Famed for aromatic Kolkata Awadhi biryani, Galouti kebabs, and quick executive lunch thalis.',
    descriptionBn: 'সুস্বাদু ঐতিহ্যবাহী কলকাতা বিরিয়ানি, স্পেশাল কাবাব এবং পারিবারিক ডাইনিং।'
  },
  {
    id: 'gmap-4',
    name: 'Apollo Care Multispecialty Diagnostic & Clinic',
    nameBn: 'অ্যাপোলো কেয়ার মাল্টিস্পেশালিটি ডায়াগনস্টিক',
    category: 'Healthcare & Pharmacy',
    categoryBn: 'স্বাস্থ্যসেবা ও ফার্মেসি',
    rating: 4.9,
    totalReviews: 1840,
    address: 'EM Bypass Road, Kolkata 700054',
    addressBn: 'ইএম বাইপাস রোড, কলকাতা ৭০০০৫৪',
    city: 'Kolkata',
    imageUrl: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=400&q=80',
    mapWebsiteUrl: 'https://www.google.com/maps/search/Apollo+Clinic+EM+Bypass+Kolkata',
    rewardCoins: 30,
    description: 'State-of-the-art pathology, 24/7 digital X-ray, ECG, senior doctor consultations, and medicine store.',
    descriptionBn: 'আধুনিক প্যাথলজি ল্যাব, ২৪/৭ ফার্মেসি এবং অভিজ্ঞ ডাক্তারদের চেম্বার।'
  },
  {
    id: 'gmap-5',
    name: 'Urban Fitness & Crossfit Gym Hub',
    nameBn: 'আরবান ফিটনেস অ্যান্ড ক্রসফিট জিম হাব',
    category: 'Fitness & Health',
    categoryBn: 'ফিটনেস ও জিম',
    rating: 4.8,
    totalReviews: 950,
    address: 'South City Mall Area, Prince Anwar Shah Rd 700068',
    addressBn: 'প্রিন্স আনোয়ার শাহ রোড, সাউথ সিটি এলাকা ৭০০০৬৮',
    city: 'Kolkata',
    imageUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=400&q=80',
    mapWebsiteUrl: 'https://www.google.com/maps/search/Urban+Fitness+Gym+Prince+Anwar+Shah+Road',
    rewardCoins: 30,
    description: 'Certified personal trainers, cardio arena, weightlifting zone, and steam bath facilities.',
    descriptionBn: 'আধুনিক জিম সরঞ্জাম, সার্টিফাইড ট্রেনার ও পার্সোনাল ফিটনেস গাইড।'
  },
  {
    id: 'gmap-6',
    name: 'City Pride Mega Supermarket & Grocery',
    nameBn: 'সিটি প্রাইড মেগা সুপারমার্কেট অ্যান্ড গ্রোসারি',
    category: 'Supermarket & Shopping',
    categoryBn: 'সুপারমার্কেট ও শপিং',
    rating: 4.6,
    totalReviews: 3400,
    address: 'Garia Main Road, South Kolkata 700084',
    addressBn: 'গড়িয়া মেইন রোড, দক্ষিণ কলকাতা ৭০০০৮৪',
    city: 'Kolkata',
    imageUrl: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=400&q=80',
    mapWebsiteUrl: 'https://www.google.com/maps/search/Mega+Supermarket+Garia+Kolkata',
    rewardCoins: 30,
    description: 'One-stop department supermarket with fresh organic vegetables, groceries, and home essentials.',
    descriptionBn: 'তাজা শাকসবজি, ফলমূল, মুদি সামগ্রী ও হোম আইটেমের বিশ্বস্ত সুপারমার্কেট।'
  },
  {
    id: 'gmap-7',
    name: 'Prime Coffee Roasters & Workspace Cafe',
    nameBn: 'প্রাইম কফি রোস্টার্স অ্যান্ড ক্যাফে ওয়ার্কস্পেস',
    category: 'Cafe & Co-working',
    categoryBn: 'ক্যাফে ও ওয়ার্কস্পেস',
    rating: 4.9,
    totalReviews: 1420,
    address: 'New Town Action Area 1, Kolkata 700156',
    addressBn: 'নিউ টাউন অ্যাকশন এরিয়া ১, কলকাতা ৭০০১৫৬',
    city: 'Kolkata',
    imageUrl: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=400&q=80',
    mapWebsiteUrl: 'https://www.google.com/maps/search/Prime+Coffee+Cafe+New+Town+Kolkata',
    rewardCoins: 30,
    description: 'Artisan espresso blends, quiet co-working seating, high-speed WiFi, and fresh baked pastries.',
    descriptionBn: 'আর্টিজান এসপ্রেসো কফি, নিরিবিলি ওয়ার্কস্পেস, ফ্রি ওয়াইফাই ও সুস্বাদু পেস্ট্রি।'
  },
  {
    id: 'gmap-8',
    name: 'Apex Car Spa & Detailing Studio',
    nameBn: 'অ্যাপেক্স কার স্পা অ্যান্ড ডিটেইলিং স্টুডিও',
    category: 'Automobile Care',
    categoryBn: 'অটোমোবাইল কেয়ার',
    rating: 4.8,
    totalReviews: 870,
    address: 'Rajarhat Expressway, Kolkata 700135',
    addressBn: 'রাজারহাট এক্সপ্রেসওয়ে, কলকাতা ৭০০১৩৫',
    city: 'Kolkata',
    imageUrl: 'https://images.unsplash.com/photo-1520340356584-f9917d1eea6f?auto=format&fit=crop&w=400&q=80',
    mapWebsiteUrl: 'https://www.google.com/maps/search/Apex+Car+Spa+Detailing+Rajarhat',
    rewardCoins: 30,
    description: 'Ceramic coating, PPF paint protection, foam wash, interior deep cleaning, and polishing.',
    descriptionBn: 'সিরামিক কোটিং, ফোম ওয়াশ ও সম্পূর্ণ গাড়ি ডিটেইলিং সার্ভিস।'
  }
];

export const MAP_REVIEW_SUGGESTIONS = [
  'Outstanding service and very polite staff! Highly recommend visiting this location.',
  'Great experience! Everything was clean, fast, and professionally handled. 5 stars!',
  'Best in the area! High quality products, reasonable prices, and friendly management.',
  'খুবই সুন্দর পরিবেশ এবং চমৎকার সেবা। সবার ব্যবহার অত্যন্ত ভালো, ৫ স্টার দিলাম!',
  'অসাধারণ অভিজ্ঞতা! পরিষ্কার-পরিচ্ছন্ন এবং সঠিক সময়ে সেবা পেয়েছি। অবশ্যই সুপারিশ করব।'
];
