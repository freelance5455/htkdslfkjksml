import { Square } from 'chess.js';

export const SQUARE_SIZE = 1.0;
export const BOARD_HALF = 3.5;

export const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'] as const;
export const RANKS = ['1', '2', '3', '4', '5', '6', '7', '8'] as const;

export type ChessFile = (typeof FILES)[number];
export type ChessRank = (typeof RANKS)[number];

/**
 * Standard chess square color:
 * a1 is Dark.
 * (fileIndex + rankIndex) % 2 === 0 is Dark.
 * (fileIndex + rankIndex) % 2 === 1 is Light.
 */
export function isLightSquare(square: Square): boolean {
  const file = square.charCodeAt(0) - 97; // 'a' -> 0, 'h' -> 7
  const rank = parseInt(square[1], 10) - 1; // '1' -> 0, '8' -> 7
  return (file + rank) % 2 === 1;
}

/**
 * Returns all 64 squares from a1 to h8
 */
export function getAllSquares(): Square[] {
  const squares: Square[] = [];
  for (let r = 0; r < 8; r++) {
    for (let f = 0; f < 8; f++) {
      squares.push(`${FILES[f]}${RANKS[r]}` as Square);
    }
  }
  return squares;
}

/**
 * Convert chess square ('e4') to 3D world coordinates.
 * Center of the board is (0, 0, 0).
 * White starts at +Z (facing -Z). Black starts at -Z.
 * 'a' file is at -X, 'h' file is at +X.
 * Rank 1 is at +Z, Rank 8 is at -Z.
 */
export function squareToWorld(square: Square): { x: number; z: number } {
  const file = square.charCodeAt(0) - 97; // 0..7
  const rank = parseInt(square[1], 10) - 1; // 0..7
  return {
    x: (file - BOARD_HALF) * SQUARE_SIZE,
    z: -(rank - BOARD_HALF) * SQUARE_SIZE,
  };
}

/**
 * Convert 3D world coordinates to chess square.
 * Returns null if outside the 8x8 boundaries.
 */
export function worldToSquare(x: number, z: number): Square | null {
  const file = Math.round(x / SQUARE_SIZE + BOARD_HALF);
  const rank = Math.round(-z / SQUARE_SIZE + BOARD_HALF);
  if (file < 0 || file > 7 || rank < 0 || rank > 7) return null;
  return `${FILES[file]}${RANKS[rank]}` as Square;
}

export interface GridSquare2D {
  square: Square;
  file: ChessFile;
  rank: ChessRank;
  fileIndex: number;
  rankIndex: number;
  isLight: boolean;
}

/**
 * Get 2D grid matrix (8 rows x 8 columns) respecting board perspective.
 * When perspective === 'w':
 *   Row 0 is Rank 8 (top), Row 7 is Rank 1 (bottom).
 *   Col 0 is File 'a' (left), Col 7 is File 'h' (right).
 * When perspective === 'b':
 *   Row 0 is Rank 1 (top), Row 7 is Rank 8 (bottom).
 *   Col 0 is File 'h' (left), Col 7 is File 'a' (right).
 */
export function get2DBoardGrid(perspective: 'w' | 'b'): GridSquare2D[][] {
  const grid: GridSquare2D[][] = [];
  const rankOrder = perspective === 'w' ? [7, 6, 5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5, 6, 7];
  const fileOrder = perspective === 'w' ? [0, 1, 2, 3, 4, 5, 6, 7] : [7, 6, 5, 4, 3, 2, 1, 0];

  for (let r = 0; r < 8; r++) {
    const row: GridSquare2D[] = [];
    const rankIdx = rankOrder[r];
    for (let c = 0; c < 8; c++) {
      const fileIdx = fileOrder[c];
      const square = `${FILES[fileIdx]}${RANKS[rankIdx]}` as Square;
      row.push({
        square,
        file: FILES[fileIdx],
        rank: RANKS[rankIdx],
        fileIndex: fileIdx,
        rankIndex: rankIdx,
        isLight: (fileIdx + rankIdx) % 2 === 1,
      });
    }
    grid.push(row);
  }

  return grid;
}

/**
 * Calculate Chebyshev distance between two squares (max(dx, dy))
 */
export function squareDistance(sq1: Square, sq2: Square): number {
  const f1 = sq1.charCodeAt(0) - 97;
  const r1 = parseInt(sq1[1], 10) - 1;
  const f2 = sq2.charCodeAt(0) - 97;
  const r2 = parseInt(sq2[1], 10) - 1;
  return Math.max(Math.abs(f1 - f2), Math.abs(r1 - r2));
}
