import { Chess, Square } from 'chess.js';
import { AiDifficulty } from '../types/chess';

// Piece material values (in centipawns)
const PIECE_VALUES: Record<string, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000,
};

// Piece-square tables for positional chess evaluation (White perspective)
// Flipped for Black
const PAWN_TABLE = [
  0,  0,  0,  0,  0,  0,  0,  0,
  50, 50, 50, 50, 50, 50, 50, 50,
  10, 10, 20, 30, 30, 20, 10, 10,
   5,  5, 10, 25, 25, 10,  5,  5,
   0,  0,  0, 20, 20,  0,  0,  0,
   5, -5,-10,  0,  0,-10, -5,  5,
   5, 10, 10,-20,-20, 10, 10,  5,
   0,  0,  0,  0,  0,  0,  0,  0
];

const KNIGHT_TABLE = [
  -50,-40,-30,-30,-30,-30,-40,-50,
  -40,-20,  0,  0,  0,  0,-20,-40,
  -30,  0, 10, 15, 15, 10,  0,-30,
  -30,  5, 15, 20, 20, 15,  5,-30,
  -30,  0, 15, 20, 20, 15,  0,-30,
  -30,  5, 10, 15, 15, 10,  5,-30,
  -40,-20,  0,  5,  5,  0,-20,-40,
  -50,-40,-30,-30,-30,-30,-40,-50,
];

const BISHOP_TABLE = [
  -20,-10,-10,-10,-10,-10,-10,-20,
  -10,  0,  0,  0,  0,  0,  0,-10,
  -10,  0,  5, 10, 10,  5,  0,-10,
  -10,  5,  5, 10, 10,  5,  5,-10,
  -10,  0, 10, 10, 10, 10,  0,-10,
  -10, 10, 10, 10, 10, 10, 10,-10,
  -10,  5,  0,  0,  0,  0,  5,-10,
  -20,-10,-10,-10,-10,-10,-10,-20,
];

const ROOK_TABLE = [
  0,  0,  0,  0,  0,  0,  0,  0,
  5, 10, 10, 10, 10, 10, 10,  5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
 -5,  0,  0,  0,  0,  0,  0, -5,
  0,  0,  0,  5,  5,  0,  0,  0
];

const QUEEN_TABLE = [
  -20,-10,-10, -5, -5,-10,-10,-20,
  -10,  0,  0,  0,  0,  0,  0,-10,
  -10,  0,  5,  5,  5,  5,  0,-10,
   -5,  0,  5,  5,  5,  5,  0, -5,
    0,  0,  5,  5,  5,  5,  0, -5,
  -10,  5,  5,  5,  5,  5,  0,-10,
  -10,  0,  5,  0,  0,  0,  0,-10,
  -20,-10,-10, -5, -5,-10,-10,-20
];

const KING_TABLE_MIDDLE = [
  -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30,
  -20,-30,-30,-40,-40,-30,-30,-20,
  -10,-20,-20,-20,-20,-20,-20,-10,
   20, 20,  0,  0,  0,  0, 20, 20,
   20, 30, 10,  0,  0, 10, 30, 20
];

function getSquareIndex(square: Square): number {
  const file = square.charCodeAt(0) - 97; // a-h -> 0-7
  const rank = 8 - parseInt(square[1], 10); // 8-1 -> 0-7
  return rank * 8 + file;
}

/**
 * Static evaluation function of the board in centipawns from White's perspective
 */
export function evaluateBoard(game: Chess): number {
  if (game.isCheckmate()) {
    return game.turn() === 'w' ? -99999 : 99999;
  }
  if (game.isDraw()) {
    return 0;
  }

  let score = 0;
  const board = game.board();

  for (let r = 0; r < 8; r++) {
    for (let f = 0; f < 8; f++) {
      const piece = board[r][f];
      if (!piece) continue;

      const sqIndex = r * 8 + f;
      const flippedIndex = (7 - r) * 8 + f;
      const pieceVal = PIECE_VALUES[piece.type] || 0;

      let posVal = 0;
      switch (piece.type) {
        case 'p':
          posVal = piece.color === 'w' ? PAWN_TABLE[sqIndex] : PAWN_TABLE[flippedIndex];
          break;
        case 'n':
          posVal = piece.color === 'w' ? KNIGHT_TABLE[sqIndex] : KNIGHT_TABLE[flippedIndex];
          break;
        case 'b':
          posVal = piece.color === 'w' ? BISHOP_TABLE[sqIndex] : BISHOP_TABLE[flippedIndex];
          break;
        case 'r':
          posVal = piece.color === 'w' ? ROOK_TABLE[sqIndex] : ROOK_TABLE[flippedIndex];
          break;
        case 'q':
          posVal = piece.color === 'w' ? QUEEN_TABLE[sqIndex] : QUEEN_TABLE[flippedIndex];
          break;
        case 'k':
          posVal = piece.color === 'w' ? KING_TABLE_MIDDLE[sqIndex] : KING_TABLE_MIDDLE[flippedIndex];
          break;
      }

      const totalVal = pieceVal + posVal;
      if (piece.color === 'w') {
        score += totalVal;
      } else {
        score -= totalVal;
      }
    }
  }

  return score;
}

/**
 * Quiescence search to avoid the horizon effect on tactical captures
 */
function quiescence(game: Chess, alpha: number, beta: number, isMaximizing: boolean, depth = 0): number {
  const standPat = evaluateBoard(game);
  if (depth >= 3) return standPat;

  if (isMaximizing) {
    if (standPat >= beta) return beta;
    if (standPat > alpha) alpha = standPat;

    // Only search captures
    const captureMoves = game.moves({ verbose: true }).filter(m => m.captured);
    for (const move of captureMoves) {
      game.move(move);
      const score = quiescence(game, alpha, beta, false, depth + 1);
      game.undo();
      if (score >= beta) return beta;
      if (score > alpha) alpha = score;
    }
    return alpha;
  } else {
    if (standPat <= alpha) return alpha;
    if (standPat < beta) beta = standPat;

    const captureMoves = game.moves({ verbose: true }).filter(m => m.captured);
    for (const move of captureMoves) {
      game.move(move);
      const score = quiescence(game, alpha, beta, true, depth + 1);
      game.undo();
      if (score <= alpha) return alpha;
      if (score < beta) beta = score;
    }
    return beta;
  }
}

/**
 * Minimax with Alpha-Beta Pruning
 */
function minimax(
  game: Chess,
  depth: number,
  alpha: number,
  beta: number,
  isMaximizing: boolean
): { score: number; bestMove?: string } {
  if (depth === 0 || game.isGameOver()) {
    return { score: quiescence(game, alpha, beta, isMaximizing) };
  }

  const moves = game.moves({ verbose: true });
  if (moves.length === 0) {
    return { score: evaluateBoard(game) };
  }

  // Move ordering: prioritize captures and checks for faster alpha-beta cutoffs
  moves.sort((a, b) => {
    const valA = (a.captured ? PIECE_VALUES[a.captured] * 10 : 0) + (a.san.includes('+') ? 50 : 0);
    const valB = (b.captured ? PIECE_VALUES[b.captured] * 10 : 0) + (b.san.includes('+') ? 50 : 0);
    return valB - valA;
  });

  let bestMoveSan = moves[0].san;

  if (isMaximizing) {
    let maxEval = -Infinity;
    for (const move of moves) {
      game.move(move);
      const evaluation = minimax(game, depth - 1, alpha, beta, false).score;
      game.undo();

      if (evaluation > maxEval) {
        maxEval = evaluation;
        bestMoveSan = move.san;
      }
      alpha = Math.max(alpha, evaluation);
      if (beta <= alpha) break;
    }
    return { score: maxEval, bestMove: bestMoveSan };
  } else {
    let minEval = Infinity;
    for (const move of moves) {
      game.move(move);
      const evaluation = minimax(game, depth - 1, alpha, beta, true).score;
      game.undo();

      if (evaluation < minEval) {
        minEval = evaluation;
        bestMoveSan = move.san;
      }
      beta = Math.min(beta, evaluation);
      if (beta <= alpha) break;
    }
    return { score: minEval, bestMove: bestMoveSan };
  }
}

/**
 * Calculates the best move for a given AI difficulty level
 */
export async function getAiMove(
  game: Chess,
  difficulty: AiDifficulty,
  aiSpeed: 'fast' | 'normal' | 'realistic' = 'normal'
): Promise<{ san: string; from: string; to: string } | null> {
  const legalMoves = game.moves({ verbose: true });
  if (legalMoves.length === 0) return null;

  // Realistic thinking delay
  let baseDelay = 500;
  if (aiSpeed === 'fast') {
    baseDelay = 150;
  } else if (aiSpeed === 'realistic') {
    baseDelay = difficulty === 'beginner' ? 400 : difficulty === 'easy' ? 700 : difficulty === 'medium' ? 1200 : difficulty === 'hard' ? 1600 : 2000;
  } else {
    // normal
    baseDelay = difficulty === 'beginner' ? 300 : difficulty === 'easy' ? 500 : difficulty === 'medium' ? 700 : difficulty === 'hard' ? 900 : 1200;
  }

  // Yield to event loop to keep UI 60fps
  await new Promise((r) => setTimeout(r, baseDelay));

  // Clone game instance to guarantee minimax never mutates the active game state
  const searchGame = new Chess(game.fen());
  const isWhite = searchGame.turn() === 'w';

  // 1. Beginner (~600-800 Elo): 50% random blunder rate, depth 1
  if (difficulty === 'beginner') {
    if (Math.random() < 0.5) {
      const nonCaptures = legalMoves.filter(m => !m.captured);
      const pool = nonCaptures.length > 0 ? nonCaptures : legalMoves;
      const pick = pool[Math.floor(Math.random() * pool.length)];
      return { san: pick.san, from: pick.from, to: pick.to };
    }
    const result = minimax(searchGame, 1, -Infinity, Infinity, isWhite);
    const chosen = legalMoves.find(m => m.san === result.bestMove) || legalMoves[0];
    return { san: chosen.san, from: chosen.from, to: chosen.to };
  }

  // 2. Easy (~1000 Elo): 25% random blunder, depth 2 with basic material greed
  if (difficulty === 'easy') {
    if (Math.random() < 0.25) {
      const randomMove = legalMoves[Math.floor(Math.random() * legalMoves.length)];
      return { san: randomMove.san, from: randomMove.from, to: randomMove.to };
    }
    const result = minimax(searchGame, 2, -Infinity, Infinity, isWhite);
    const chosen = legalMoves.find(m => m.san === result.bestMove) || legalMoves[0];
    return { san: chosen.san, from: chosen.from, to: chosen.to };
  }

  // 3. Medium (~1400 Elo): Depth 3, piece-square evaluations, picks from top moves
  if (difficulty === 'medium') {
    const scoredMoves = legalMoves.map(m => {
      searchGame.move(m);
      const res = minimax(searchGame, 2, -Infinity, Infinity, !isWhite);
      searchGame.undo();
      return { move: m, score: res.score };
    });

    scoredMoves.sort((a, b) => isWhite ? b.score - a.score : a.score - b.score);
    // 85% choose best, 15% choose 2nd best
    const pickIndex = (Math.random() < 0.85 || scoredMoves.length < 2) ? 0 : 1;
    const chosen = scoredMoves[pickIndex].move;
    return { san: chosen.san, from: chosen.from, to: chosen.to };
  }

  // 4. Hard (~1800 Elo): Depth 4 with alpha-beta, quiescence, and positional PST
  if (difficulty === 'hard') {
    const result = minimax(searchGame, 3, -Infinity, Infinity, isWhite);
    const chosen = legalMoves.find(m => m.san === result.bestMove) || legalMoves[0];
    return { san: chosen.san, from: chosen.from, to: chosen.to };
  }

  // 5. Expert (~2200-2400 Elo): Depth 4-5 with deep quiescence and move ordering
  const result = minimax(searchGame, 4, -Infinity, Infinity, isWhite);
  const chosen = legalMoves.find(m => m.san === result.bestMove) || legalMoves[0];
  return { san: chosen.san, from: chosen.from, to: chosen.to };
}

export interface HintAnalysis {
  san: string;
  from: string;
  to: string;
  evalCentipawns: number;
  evalText: string;
  winProbability: number;
  explanation: string;
}

/**
 * Evaluates the current board and provides tactical explanation for the best move
 */
export function getBestMoveHint(game: Chess): HintAnalysis | null {
  const legalMoves = game.moves({ verbose: true });
  if (legalMoves.length === 0) return null;

  const isWhite = game.turn() === 'w';
  const result = minimax(game, 3, -Infinity, Infinity, isWhite);
  const bestMove = legalMoves.find(m => m.san === result.bestMove) || legalMoves[0];

  const evalCp = result.score;
  const evalPawns = (evalCp / 100).toFixed(1);
  const evalText = evalCp > 0 ? `+${evalPawns}` : `${evalPawns}`;

  // Calculate approximate winning probability using sigmoid
  const winProb = Math.round(1 / (1 + Math.pow(10, -(evalCp / 400))) * 100);

  // Generate tactical reasoning
  let explanation = '';
  if (bestMove.san.includes('#')) {
    explanation = 'Delivers checkmate to win the game!';
  } else if (bestMove.captured) {
    const capturedName = bestMove.captured === 'q' ? 'Queen' : bestMove.captured === 'r' ? 'Rook' : bestMove.captured === 'b' ? 'Bishop' : bestMove.captured === 'n' ? 'Knight' : 'Pawn';
    explanation = `Captures opponent's ${capturedName} and wins material advantage.`;
  } else if (bestMove.san.includes('+')) {
    explanation = 'Delivers check, forcing the opponent to respond defensively.';
  } else if (bestMove.san === 'O-O' || bestMove.san === 'O-O-O') {
    explanation = 'Castles the King to safety and activates the Rook for the open files.';
  } else if (bestMove.piece === 'n') {
    explanation = 'Develops the Knight towards the center, controlling key outpost squares.';
  } else if (bestMove.piece === 'b') {
    explanation = 'Fianchettos or positions the Bishop onto a dominant diagonal.';
  } else if (bestMove.piece === 'p' && (bestMove.to[1] === '4' || bestMove.to[1] === '5')) {
    explanation = 'Claims central space and opens lines for piece development.';
  } else {
    explanation = 'Strengthens piece coordination and optimizes overall board harmony.';
  }

  return {
    san: bestMove.san,
    from: bestMove.from,
    to: bestMove.to,
    evalCentipawns: evalCp,
    evalText,
    winProbability: isWhite ? winProb : 100 - winProb,
    explanation,
  };
}
