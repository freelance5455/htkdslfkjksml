"use client";

import { SymbolId, SYMBOLS, TradeSide } from "@/types";
import { streamManager } from "./streamManagerService";
import { multiTimeframeEngine } from "./multiTimeframeEngine";
import { dynamicStrategyEngine, STRATEGY_LIBRARY } from "./dynamicStrategyEngine";
import { useTradingStore } from "./useTradingStore";

/**
 * Autonomous Demo-First Trading Bot.
 * SAFETY: executes strictly in PAPER/DEMO mode against the $10,000 virtual
 * balance. Real execution stays locked unless explicitly unlocked in Settings
 * (and even then this build only simulates fills at real live prices).
 *
 * - Instant feedback: first demo trade fires within 3s of activation.
 * - Continuous evaluation loop every 12s + WebSocket-tick SL/TP engine
 *   (tick exits live inside useTradingStore.applyTickToPositions).
 * - Risk guardrails: fixed risk %, ATR SL/TP, max concurrent, 5% daily
 *   circuit breaker, kill-switch.
 */
class AutoTradingEngine {
  private started = false;
  private loopTimer: ReturnType<typeof setInterval> | null = null;
  private kickoffTimer: ReturnType<typeof setTimeout> | null = null;
  private wasActive = false;

  start() {
    if (this.started || typeof window === "undefined") return;
    this.started = true;

    useTradingStore.subscribe((st) => {
      if (st.isAutoBotActive && !this.wasActive) {
        this.wasActive = true;
        this.activate();
      } else if (!st.isAutoBotActive && this.wasActive) {
        this.wasActive = false;
        this.deactivate();
      }
    });
  }

  private activate() {
    const st = useTradingStore.getState();
    st.addLog("info", "🔎 סריקה ראשונית של השוק — עסקת דמו ראשונה תוך 3 שניות…");

    // instant first demo trade (≤3s) so the user gets immediate feedback
    this.kickoffTimer = setTimeout(() => this.evaluate(true), 2500);
    // continuous evaluation loop (10–15s window → 12s)
    this.loopTimer = setInterval(() => this.evaluate(false), 12000);
  }

  private deactivate() {
    if (this.loopTimer) clearInterval(this.loopTimer);
    if (this.kickoffTimer) clearTimeout(this.kickoffTimer);
    this.loopTimer = null;
    this.kickoffTimer = null;
    const st = useTradingStore.getState();
    if (!st.riskHalted) st.setBotStatus("OFF");
  }

  /** main market scan + execution decision */
  private evaluate(forceEntry: boolean) {
    const st = useTradingStore.getState();
    if (!st.isAutoBotActive) return;
    st.applyMarket({ lastScanAt: Date.now() });

    if (st.riskHalted) {
      st.setBotStatus("HALTED");
      return;
    }
    if (st.positions.length >= st.settings.maxConcurrent) {
      st.setBotStatus("ACTIVE");
      return;
    }

    // rank symbols by absolute confluence
    const ranked = SYMBOLS
      .map((s) => ({ s, snap: st.mtf[s] ?? multiTimeframeEngine.snapshot(s) }))
      .sort((a, b) => Math.abs(b.snap.confluence) - Math.abs(a.snap.confluence));

    const opt = st.optimizer;
    let pick = ranked.find(
      (r) =>
        r.snap.aligned &&
        Math.abs(r.snap.confluence) >= opt.confluenceThreshold &&
        !st.positions.some((p) => p.symbol === r.s),
    );

    // forced kickoff trade: take the best momentum candidate even without
    // full gatekeeper alignment, with tighter ATR stops (demo feedback trade)
    if (!pick && forceEntry) {
      pick = ranked.find((r) => !st.positions.some((p) => p.symbol === r.s)) ?? ranked[0];
    }

    if (!pick) {
      st.setBotStatus(st.positions.length > 0 ? "ACTIVE" : "SCANNING");
      return;
    }

    const symbol = pick.s as SymbolId;
    const snap = pick.snap;
    const side: TradeSide =
      snap.direction ?? (snap.confluence >= 0 ? "LONG" : "SHORT");
    const price = streamManager.getPrice(symbol);
    const iv5 = snap.intervals["5m"];
    const iv1h = snap.intervals["1h"];
    const atr = iv5?.atr ?? price * 0.006;
    const dir = side === "LONG" ? 1 : -1;

    // RSI sanity filter (learned thresholds)
    const rsi5 = iv5?.rsi ?? 50;
    if (!forceEntry) {
      if (side === "LONG" && rsi5 > opt.rsiOverbought) return this.skip(st, symbol, "RSI בקניות-יתר");
      if (side === "SHORT" && rsi5 < opt.rsiOversold) return this.skip(st, symbol, "RSI במכירות-יתר");
    }

    // fixed-risk position sizing with ATR stop distance
    const riskUsd = (st.settings.riskPct / 100) * st.balance;
    const slDist = Math.max(atr * opt.atrSlMult, price * 0.0025);
    const qty = Math.max(riskUsd / slDist, 0.0001);
    const lev = st.settings.defaultLeverage;
    const cappedQty = Math.min(qty, (st.balance * 0.45 * lev) / price);

    const active = dynamicStrategyEngine.getActiveStrategy();
    const strat = active.id === "copy" ? STRATEGY_LIBRARY[0] : active;

    const pos = st.openPosition({
      symbol, side, source: "BOT",
      strategyId: strat.id, strategyName: strat.name,
      entryPrice: price, qty: cappedQty, leverage: lev,
      stopLoss: price - dir * slDist,
      takeProfit: price + dir * atr * opt.atrTpMult,
      atrAtEntry: atr, trailingStop: true,
      diagnostics: {
        rsi5m: rsi5,
        rsi1h: iv1h?.rsi ?? 50,
        emaSlope: snap.mediumScore,
        vwapOffsetPct: iv5 ? ((price - iv5.vwap) / iv5.vwap) * 100 : 0,
        volumeRatio: iv5?.volumeRatio ?? 1,
        atrPct: iv5?.atrPct ?? 0.5,
        hourOfDay: new Date().getHours(),
        confluenceScore: snap.confluence,
        regime: st.regime.regime,
      },
    });

    if (pos) {
      st.setBotStatus("ACTIVE");
      st.addLog(
        "signal",
        `🤖 ${forceEntry ? "עסקת פתיחה מיידית" : "הצלבת אינדיקטורים אושרה"}: ${symbol} ${side === "LONG" ? "לונג" : "שורט"} | הצלבה ${snap.confluence} | אסטרטגיה: ${strat.nameHe}`,
      );
    }
  }

  private skip(st: ReturnType<typeof useTradingStore.getState>, symbol: SymbolId, reason: string) {
    st.setBotStatus(st.positions.length > 0 ? "ACTIVE" : "SCANNING");
    st.addLog("info", `⏭️ דילוג על ${symbol} — ${reason}`);
  }
}

export const autoTradingEngine = new AutoTradingEngine();
