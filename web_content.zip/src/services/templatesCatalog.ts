import { Project, Clip, Track, AspectRatioType } from '../types/editor';
import { generateSampleVideoCanvas, generateSyntheticMusicTrack, BUILTIN_FILTERS } from './sampleMedia';
import { Language } from '../i18n/translations';

export interface VideoTemplateDef {
  id: string;
  titleHi: string;
  titleEn: string;
  ratio: AspectRatioType;
  duration: number; // seconds
  category: 'Cinematic' | 'Reels & Shorts' | 'Travel & Nature' | 'Lifestyle & Fashion' | 'Vlog & Tech' | 'Aesthetic & Vintage' | 'Sports & Gaming';
  descHi: string;
  descEn: string;
  gradient: string;
  badge: string;
  theme: 'nature' | 'urban' | 'abstract' | 'cinema' | 'sunset' | 'cyberpunk' | 'vintage' | 'minimal' | 'luxury' | 'noir';
  filterIndex: number;
  musicTitle: string;
  headlineHi: string;
  headlineEn: string;
}

export const VIDEO_TEMPLATES: VideoTemplateDef[] = [
  // 1. Hollywood Blockbuster
  {
    id: 'template_hollywood_blockbuster',
    titleHi: 'हॉलीवुड 4K सिनेमैटिक ट्रेलर',
    titleEn: 'Hollywood 4K Blockbuster Trailer',
    ratio: '16:9',
    duration: 8,
    category: 'Cinematic',
    descHi: 'अनामोर्फिक 2.39:1 लेटरबॉक्स, मूडी ब्लॉकबस्टर ग्रेड, एपिक आर्केस्ट्रा एवं स्लो ड्रामैटिक ज़ूम',
    descEn: 'Anamorphic 2.39:1 wide frame, moody blockbuster color grade, epic orchestra & slow cinematic keyframe zoom',
    gradient: 'from-amber-600 via-stone-800 to-black',
    badge: '4K CINEMA',
    theme: 'cinema',
    filterIndex: 1, // blockbuster_moody
    musicTitle: 'Cinematic Epic Score',
    headlineHi: 'THE FINAL CHAPTER',
    headlineEn: 'THE FINAL CHAPTER',
  },
  // 2. Teal & Orange Travel
  {
    id: 'template_teal_orange_travel',
    titleHi: 'टील & ऑरेंज ट्रैवल व्लॉग',
    titleEn: 'Teal & Orange Travel Wanderlust',
    ratio: '9:16',
    duration: 7,
    category: 'Travel & Nature',
    descHi: 'ग्लोबल ट्रैवलर्स का पसंदीदा टील & ऑरेंज लुक, स्मूथ क्रॉस-डिज़ॉल्व, लोकेशन बैज व एम्बिएंट साउंड',
    descEn: 'Iconic Teal & Orange film look, smooth dissolve transitions, location pill badge & breezy ambient travel chords',
    gradient: 'from-teal-600 via-cyan-800 to-amber-700',
    badge: 'TRAVEL REELS',
    theme: 'nature',
    filterIndex: 0, // teal_orange
    musicTitle: 'Upbeat Wanderlust Groove',
    headlineHi: 'WANDERLUST • BALI 2026',
    headlineEn: 'WANDERLUST • BALI 2026',
  },
  // 3. Reels Velocity Beat Drop
  {
    id: 'template_reels_velocity_drop',
    titleHi: 'रील्स वेलोसिटी बीट-ड्रॉप',
    titleEn: 'Instagram Reels Velocity Beat-Drop',
    ratio: '9:16',
    duration: 6,
    category: 'Reels & Shorts',
    descHi: 'फास्ट कट्स, स्पीड रैंप 1.6x, पंच ज़ूम कीफ़्रेम, वाइब्रेंट पॉप ग्रेड और बाउंसिंग टाइटल',
    descEn: 'High-energy beat sync, punch zoom keyframe motion, vibrant pop saturation & bouncing animated text',
    gradient: 'from-pink-600 via-rose-600 to-purple-800',
    badge: 'VIRAL REEL',
    theme: 'urban',
    filterIndex: 11, // vibrant_pop
    musicTitle: 'Upbeat EDM Drop',
    headlineHi: 'NEVER SLOW DOWN ⚡',
    headlineEn: 'NEVER SLOW DOWN ⚡',
  },
  // 4. Cyberpunk Neon Tokyo
  {
    id: 'template_cyberpunk_neon',
    titleHi: 'साइबरपंक नियॉन नाइट स्ट्रीट',
    titleEn: 'Cyberpunk Neon Tokyo Night',
    ratio: '9:16',
    duration: 7,
    category: 'Reels & Shorts',
    descHi: 'नियॉन पिंक & सायन ग्रेडिंग, ग्लिच इफेक्ट, डार्क सिंथवेव इलेक्ट्रो बीट एवं ग्लोइंग टेक्स्ट',
    descEn: 'Futuristic neon pink & cyan palette, glitch shake effect, dark synthwave electro bass & glowing neon typography',
    gradient: 'from-purple-900 via-fuchsia-700 to-cyan-500',
    badge: 'NEON CYBER',
    theme: 'cyberpunk',
    filterIndex: 7, // cyberpunk_neon
    musicTitle: 'Synthwave Night Beat',
    headlineHi: 'NEO TOKYO 2077',
    headlineEn: 'NEO TOKYO 2077',
  },
  // 5. Golden Hour Sunset Vibes
  {
    id: 'template_golden_hour_vibes',
    titleHi: 'गोल्डन ऑवर सनसेट वाइब्स',
    titleEn: 'Golden Hour Sunset Aesthetic',
    ratio: '9:16',
    duration: 7,
    category: 'Aesthetic & Vintage',
    descHi: 'वार्म सनसेट ग्लो, सॉफ्ट रोमांटिक सेपिया टोन, स्लो मोशन ज़ूम एवं जेंटल लो-फाई रिदम',
    descEn: 'Warm sunset glow, soft romantic film tone, slow dreamy motion & gentle acoustic chords',
    gradient: 'from-amber-500 via-orange-600 to-rose-700',
    badge: 'GOLDEN VIBES',
    theme: 'sunset',
    filterIndex: 2, // golden_hour
    musicTitle: 'Sunset Lofi Chills',
    headlineHi: 'GOLDEN HOUR MAGIC ✨',
    headlineEn: 'GOLDEN HOUR MAGIC ✨',
  },
  // 6. Vintage 1980s Retro VHS
  {
    id: 'template_vintage_vhs_tape',
    titleHi: 'विंटेज 1980s रेट्रो वीएचएस',
    titleEn: 'Vintage 1980s Retro VHS Tape',
    ratio: '4:3',
    duration: 6,
    category: 'Aesthetic & Vintage',
    descHi: 'क्लासिक 4:3 टीवी स्क्रीन, स्कैनलाइन्स, वीएचएस टेप ग्रेन, रेट्रो सेपिया व 80s सिंथ पैड',
    descEn: 'Classic 4:3 CRT TV aspect ratio, analog scanlines, tape grain, warm sepia grade & retro analog synth pad',
    gradient: 'from-yellow-800 via-amber-900 to-stone-900',
    badge: 'VHS RETRO',
    theme: 'vintage',
    filterIndex: 5, // vintage_80s
    musicTitle: 'Retro Tape Groove',
    headlineHi: 'PLAY ► REC 1986',
    headlineEn: 'PLAY ► REC 1986',
  },
  // 7. Film Noir 1940s Classic B&W
  {
    id: 'template_film_noir_classic',
    titleHi: 'फ़िल्म नोयर 1940s ब्लैक & व्हाइट',
    titleEn: 'Film Noir 1940s Classic B&W',
    ratio: '16:9',
    duration: 8,
    category: 'Cinematic',
    descHi: 'सिल्वर मोनोलिथ मोनोक्रोम, डीप विगनेट, नाटकीय परछाइयां एवं विंटेज नोयर जैज़ बास',
    descEn: 'Silver monolith monochrome black & white grade, deep dramatic vignette & atmospheric noir jazz double-bass',
    gradient: 'from-neutral-900 via-neutral-700 to-black',
    badge: 'NOIR B&W',
    theme: 'noir',
    filterIndex: 3, // film_noir
    musicTitle: 'Noir Detective Bass',
    headlineHi: 'THE SHADOWS REMEMBER',
    headlineEn: 'THE SHADOWS REMEMBER',
  },
  // 8. YouTube Tech Studio
  {
    id: 'template_youtube_tech_studio',
    titleHi: 'यूट्यूब टेक रिव्यू और अनबॉक्सिंग',
    titleEn: 'YouTube Tech Studio & Unboxing',
    ratio: '16:9',
    duration: 8,
    category: 'Vlog & Tech',
    descHi: 'क्रिसप 4K स्टूडियो ग्रेड, लोअर थर्ड स्पेक बैज, मिनिमल मॉडर्न टाइपोग्राफी व इलेक्ट्रॉनिका',
    descEn: 'Ultra-crisp studio lighting grade, modern lower-third specification badge & clean modern electronica track',
    gradient: 'from-blue-700 via-indigo-900 to-black',
    badge: 'TECH REVIEW',
    theme: 'urban',
    filterIndex: 1, // blockbuster_moody
    musicTitle: 'Upbeat Tech Electronica',
    headlineHi: 'FLAGSHIP UNBOXING & REVIEW',
    headlineEn: 'FLAGSHIP UNBOXING & REVIEW',
  },
  // 9. Luxury Fashion & Runway Lookbook
  {
    id: 'template_luxury_fashion_runway',
    titleHi: 'लक्ज़री फैशन और रनवे लुकबुक',
    titleEn: 'Luxury Fashion & Runway Lookbook',
    ratio: '9:16',
    duration: 7,
    category: 'Lifestyle & Fashion',
    descHi: 'सॉफ्ट पीच रेडियंट ग्रेड, 0.8x स्मूथ मोशन, एडिटोरियल सेरिफ फॉन्ट व एलिगेंट लक्ज़री स्टाइल',
    descEn: 'Soft radiant peach film grade, smooth 0.8x slow motion, editorial serif typography & runway elegance',
    gradient: 'from-rose-500 via-pink-700 to-stone-900',
    badge: 'HAUTE COUTURE',
    theme: 'luxury',
    filterIndex: 8, // radiant_peach
    musicTitle: 'Chic Runway Lounge',
    headlineHi: 'PARIS COUTURE • FALL 2026',
    headlineEn: 'PARIS COUTURE • FALL 2026',
  },
  // 10. Dark Moody Crime Thriller
  {
    id: 'template_dark_cinematic_thriller',
    titleHi: 'डार्क सिनेमैटिक क्राइम थ्रिलर',
    titleEn: 'Dark Moody Crime Thriller',
    ratio: '16:9',
    duration: 8,
    category: 'Cinematic',
    descHi: 'डीसैचुरेटेड कोल्ड टोन, विगनेट फ्रेमिंग, सस्पेंस एम्बिएंट ड्रोन एवं बोल्ड हेवी टाइटल्स',
    descEn: 'Cold desaturated cinematic tones, heavy vignette framing, suspenseful atmospheric drone & bold gritty titles',
    gradient: 'from-slate-900 via-zinc-800 to-black',
    badge: 'THRILLER',
    theme: 'cinema',
    filterIndex: 1, // blockbuster_moody
    musicTitle: 'Suspense Ambient Drone',
    headlineHi: 'TRUST NO ONE',
    headlineEn: 'TRUST NO ONE',
  },
  // 11. National Geographic Wildlife Doc
  {
    id: 'template_natgeo_wildlife',
    titleHi: 'नेचर & वाइल्डलाइफ डॉक्यूमेंट्री',
    titleEn: 'National Geographic Wildlife Doc',
    ratio: '16:9',
    duration: 8,
    category: 'Travel & Nature',
    descHi: 'एमराल्ड ग्रीन विविड ग्रेड, पैनोरमिक स्मूथ ग्लाइड, नेचर एम्बिएंस व एकॉस्टिक आर्केस्ट्रा',
    descEn: 'Emerald green nature grade, panoramic smooth glide keyframes, wildlife atmosphere & acoustic orchestral strings',
    gradient: 'from-emerald-700 via-teal-900 to-stone-950',
    badge: 'NATURE 4K',
    theme: 'nature',
    filterIndex: 10, // emerald_forest
    musicTitle: 'Majestic Earth Score',
    headlineHi: 'WILD KINGDOM • AFRICA',
    headlineEn: 'WILD KINGDOM • AFRICA',
  },
  // 12. Gym Beast Mode Motivation
  {
    id: 'template_gym_beast_motivation',
    titleHi: 'जिम & फिटनेस बीस्ट मोड मोटिवेशन',
    titleEn: 'Gym Beast Mode Motivation',
    ratio: '9:16',
    duration: 6,
    category: 'Sports & Gaming',
    descHi: 'इंटेंस हाई कंट्रास्ट पंच, डार्क वार्म वाइब, पावरफुल डबस्टेप बीट एवं हेवी वर्कआउट कोट्स',
    descEn: 'High contrast punchy grading, intense dark shadows, heavy electronic bass drop & inspiring fitness quote',
    gradient: 'from-red-700 via-orange-900 to-black',
    badge: 'BEAST MODE',
    theme: 'urban',
    filterIndex: 11, // vibrant_pop
    musicTitle: 'Upbeat Heavy Bass Workout',
    headlineHi: 'PAIN IS TEMPORARY 💥',
    headlineEn: 'PAIN IS TEMPORARY 💥',
  },
  // 13. Podcast Studio Highlight
  {
    id: 'template_podcast_studio_talk',
    titleHi: 'पॉडकास्ट और इंटरव्यू हाईलाइट',
    titleEn: 'Podcast Studio Talk Show Clip',
    ratio: '16:9',
    duration: 8,
    category: 'Vlog & Tech',
    descHi: 'स्टूडियो लाइटिंग बैलेंस, स्पीकर नेम लोअर थर्ड, ऑडियो वेव बैज व वार्म वोकल प्रोफाइल',
    descEn: 'Broadcast studio lighting balance, speaker name lower-third card, live sound badge & warm acoustic backing',
    gradient: 'from-purple-800 via-slate-900 to-neutral-950',
    badge: 'PODCAST TALK',
    theme: 'urban',
    filterIndex: 1, // blockbuster_moody
    musicTitle: 'Podcast Lo-Fi Chill',
    headlineHi: 'THE BILLION DOLLAR MINDSET',
    headlineEn: 'THE BILLION DOLLAR MINDSET',
  },
  // 14. Aesthetic Lofi Chill Story
  {
    id: 'template_aesthetic_lofi_story',
    titleHi: 'एस्थेटिक लो-फाई स्टोरी और कोट्स',
    titleEn: 'Aesthetic Lofi Chill Story',
    ratio: '1:1',
    duration: 7,
    category: 'Aesthetic & Vintage',
    descHi: 'सॉफ्ट पेस्टल एस्थेटिक्स, टाइपराइटर लिरिकल सबटाइटल, विनाइल क्रैकेल एवं जेंटल लो-फाई बीट्स',
    descEn: 'Soft pastel aesthetics, typewriter lyrical subtitles, gentle piano chords & warm vinyl lofi drum beats',
    gradient: 'from-pink-400 via-purple-500 to-indigo-600',
    badge: 'LOFI CHILL',
    theme: 'minimal',
    filterIndex: 12, // pastel_aesthetic
    musicTitle: 'Late Night Lofi Study',
    headlineHi: 'quiet moments in a loud world ✨',
    headlineEn: 'quiet moments in a loud world ✨',
  },
  // 15. Romantic Wedding Love Story
  {
    id: 'template_romantic_wedding',
    titleHi: 'वेडिंग और प्री-वेडिंग लव स्टोरी',
    titleEn: 'Dreamy Wedding & Love Story',
    ratio: '16:9',
    duration: 8,
    category: 'Lifestyle & Fashion',
    descHi: 'सॉफ्ट ड्रीम पोर्ट्रेट ग्लो, गोल्डन हाइलाइट्स, इमोशनल पियानो-वायलिन मेलोडी व एलिगेंट फॉन्ट्स',
    descEn: 'Dreamy soft portrait glow, warm golden highlights, emotional piano-violin melody & elegant romantic typography',
    gradient: 'from-rose-400 via-amber-200 to-rose-600',
    badge: 'WEDDING CINEMA',
    theme: 'luxury',
    filterIndex: 9, // soft_glow
    musicTitle: 'Acoustic Wedding Piano',
    headlineHi: 'FOREVER BEGINS TODAY 💍',
    headlineEn: 'FOREVER BEGINS TODAY 💍',
  },
  // 16. Gourmet Food & Cafe Tour
  {
    id: 'template_food_vlog_cafe',
    titleHi: 'फूड व्लॉगिंग और कैफे टूर',
    titleEn: 'Gourmet Food & Cafe Tour',
    ratio: '9:16',
    duration: 7,
    category: 'Vlog & Tech',
    descHi: 'विविड वार्म फूड सैचुरेशन, "CHEF SPECIAL" पॉप स्टिकर एवं चीयरफुल एकॉस्टिक कैफे जैज़',
    descEn: 'Vibrant delicious saturation boost, chef recommendation badge & cheerful acoustic jazz guitar rhythm',
    gradient: 'from-orange-500 via-amber-600 to-red-700',
    badge: 'FOODIE REELS',
    theme: 'sunset',
    filterIndex: 13, // warm_sunset
    musicTitle: 'Upbeat Cafe Jazz',
    headlineHi: 'THE BEST CROISSANT IN TOWN 🥐',
    headlineEn: 'THE BEST CROISSANT IN TOWN 🥐',
  },
  // 17. Automotive Supercar Sizzle
  {
    id: 'template_supercar_sizzle',
    titleHi: 'सुपरकार और ऑटोमोटिव सिज़ल रील',
    titleEn: 'Automotive Hyper Sizzle Reel',
    ratio: '16:9',
    duration: 7,
    category: 'Sports & Gaming',
    descHi: 'स्पीड रैंप, लाइट लीक इफेक्ट्स, डीप टर्बो इंजन एग्जॉस्ट बास एवं अल्ट्रा-वाइड सिनेमैटिक शॉट्स',
    descEn: 'Dynamic speed ramp keyframes, anamorphic light leak effects, heavy engine bass rumble & aggressive cuts',
    gradient: 'from-neutral-900 via-red-900 to-black',
    badge: 'HYPER CAR',
    theme: 'cinema',
    filterIndex: 0, // teal_orange
    musicTitle: 'Upbeat Dubstep Drive',
    headlineHi: '0 TO 100 IN 2.4 SECONDS 🏎️',
    headlineEn: '0 TO 100 IN 2.4 SECONDS 🏎️',
  },
  // 18. Luxury Real Estate Villa Tour
  {
    id: 'template_luxury_real_estate',
    titleHi: 'लक्ज़री विला & रियल एस्टेट टूर',
    titleEn: 'Luxury Villa & Real Estate Tour',
    ratio: '16:9',
    duration: 8,
    category: 'Lifestyle & Fashion',
    descHi: 'वाइड-एंगल स्मूथ सिनेमैटिक ग्लाइड, मॉडर्न आर्किटेक्चर लोअर थर्ड एवं एम्बिएंट लक्ज़री चिल',
    descEn: 'Wide-angle architectural glide keyframes, property detail lower thirds & sophisticated corporate lounge music',
    gradient: 'from-stone-800 via-neutral-700 to-stone-900',
    badge: 'LUXURY LIVING',
    theme: 'luxury',
    filterIndex: 1, // blockbuster_moody
    musicTitle: 'Luxury Lounge Ambient',
    headlineHi: 'BEVERLY HILLS MANSION • $18M',
    headlineEn: 'BEVERLY HILLS MANSION • $18M',
  },
  // 19. Esports & Gaming Clutch Montage
  {
    id: 'template_esports_clutch',
    titleHi: 'ई-स्पोर्ट्स और गेमिंग क्लच मोंटाज',
    titleEn: 'Esports & Gaming Clutch Montage',
    ratio: '16:9',
    duration: 7,
    category: 'Sports & Gaming',
    descHi: 'नियॉन स्ट्रोब कट्स, क्रॉसहेयर और विक्टरी स्टिकर बैज, हाई-एनर्जी डबस्टेप बीट ड्रॉप',
    descEn: 'High-octane strobe flash transitions, crosshair victory badges & aggressive gaming dubstep beats',
    gradient: 'from-cyan-600 via-violet-800 to-black',
    badge: 'ESPORTS CLUTCH',
    theme: 'cyberpunk',
    filterIndex: 7, // cyberpunk_neon
    musicTitle: 'Upbeat Gaming Dubstep',
    headlineHi: '1 VS 5 IMPOSSIBLE CLUTCH 🎮',
    headlineEn: '1 VS 5 IMPOSSIBLE CLUTCH 🎮',
  },
  // 20. Corporate Startup Vision & Pitch
  {
    id: 'template_startup_corporate_promo',
    titleHi: 'बिजनेस और स्टार्टअप प्रोमो',
    titleEn: 'Corporate Startup Vision & Pitch',
    ratio: '16:9',
    duration: 8,
    category: 'Vlog & Tech',
    descHi: 'क्लीन मॉडर्न ग्रेडिएंट्स, मेट्रिक कॉलआउट बैज, फ्यूचरिस्टिक विज़न व इंस्पायरिंग कॉर्पोरेट म्यूजिक',
    descEn: 'Clean modern corporate look, metric callout badge, sleek financial pitch typography & inspiring strings',
    gradient: 'from-blue-600 via-slate-800 to-indigo-950',
    badge: 'STARTUP PITCH',
    theme: 'urban',
    filterIndex: 14, // arctic_cool
    musicTitle: 'Inspiring Corporate Vision',
    headlineHi: 'BUILDING THE FUTURE OF AI 🚀',
    headlineEn: 'BUILDING THE FUTURE OF AI 🚀',
  },
];

// Instantiates a fully functional Clipora Project based on any chosen template
export async function buildProjectFromTemplate(templateId: string, language: Language): Promise<Project> {
  const tpl = VIDEO_TEMPLATES.find(t => t.id === templateId) || VIDEO_TEMPLATES[0];

  const isVertical = tpl.ratio === '9:16';
  const isSquare = tpl.ratio === '1:1';
  const is43 = tpl.ratio === '4:3';

  const w = isVertical ? 360 : isSquare ? 480 : is43 ? 480 : 640;
  const h = isVertical ? 640 : isSquare ? 480 : is43 ? 360 : 360;

  // Generate customized thematic canvas video
  const vidBlob = await generateSampleVideoCanvas(w, h, tpl.theme, tpl.duration);
  const vidUrl = URL.createObjectURL(vidBlob);

  // Generate matching synthesized soundtrack
  const musicBlob = generateSyntheticMusicTrack(tpl.musicTitle, tpl.duration);
  const musicUrl = URL.createObjectURL(musicBlob);

  const selectedFilter = BUILTIN_FILTERS[tpl.filterIndex % BUILTIN_FILTERS.length];

  const project: Project = {
    id: `project_tpl_${Date.now()}`,
    name: language === 'hi' ? tpl.titleHi : tpl.titleEn,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    aspectRatio: tpl.ratio,
    duration: tpl.duration,
    fps: 30,
    background: { type: 'color', color: '#000000' },
    tracks: [
      { id: 'track_main_video', name: 'Main Video', type: 'video', locked: false, visible: true, muted: false, volume: 1.0 },
      { id: 'track_overlay_pip', name: 'PIP Overlay', type: 'overlay', locked: false, visible: true, muted: false, volume: 1.0 },
      { id: 'track_text_1', name: 'Titles & Text', type: 'text', locked: false, visible: true, muted: false, volume: 1.0 },
      { id: 'track_stickers_1', name: 'Badges & Callouts', type: 'sticker', locked: false, visible: true, muted: false, volume: 1.0 },
      { id: 'track_audio_bgm', name: 'Music & Audio', type: 'audio', locked: false, visible: true, muted: false, volume: 1.0 },
    ],
    clips: [
      // 1. Primary Video Clip
      {
        id: `clip_${Date.now()}_main_vid`,
        trackId: 'track_main_video',
        trackType: 'video',
        name: `${tpl.titleEn} (Master)`,
        type: 'video',
        sourceUrl: vidUrl,
        blob: vidBlob,
        start: 0,
        duration: tpl.duration,
        sourceStart: 0,
        sourceDuration: tpl.duration,
        speed: 1.0,
        reverse: false,
        x: 0,
        y: 0,
        scale: 1.0,
        rotation: 0,
        opacity: 1.0,
        flipH: false,
        flipV: false,
        blendMode: 'normal',
        volume: 1.0,
        muted: false,
        fadeIn: 0.6,
        fadeOut: 0.6,
        adjustments: {
          brightness: 5,
          contrast: 15,
          saturation: 20,
          exposure: 0,
          highlights: 5,
          shadows: -5,
          temperature: tpl.category === 'Cinematic' || tpl.theme === 'sunset' ? 15 : 0,
          tint: 0,
          sharpness: 30,
          vignette: tpl.category === 'Cinematic' ? 25 : 10,
          grain: tpl.id === 'template_vintage_vhs_tape' ? 35 : 5,
          hue: 0,
        },
        filter: selectedFilter,
        effects: tpl.id === 'template_vintage_vhs_tape' ? [{ id: 'eff_vhs', type: 'vhs', name: 'VHS Scanlines', intensity: 65, speed: 50 }] :
                 tpl.id === 'template_reels_velocity_drop' ? [{ id: 'eff_shake', type: 'shake', name: 'Beat Shake', intensity: 35, speed: 80 }] : [],
        mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
        chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
        keyframes: [
          { id: 'k1', time: 0, x: 0, y: 0, scale: 1.0, rotation: 0, opacity: 1 },
          { id: 'k2', time: tpl.duration, x: 0, y: 0, scale: 1.12, rotation: 0, opacity: 1 },
        ],
      },
      // 2. Cinematic Headline Text
      {
        id: `clip_${Date.now()}_txt_headline`,
        trackId: 'track_text_1',
        trackType: 'text',
        name: 'Cinematic Title',
        type: 'text',
        sourceUrl: '',
        start: 0.6,
        duration: tpl.duration - 1.2,
        sourceStart: 0,
        sourceDuration: tpl.duration - 1.2,
        speed: 1.0,
        reverse: false,
        x: 0,
        y: isVertical ? 5 : is43 ? -10 : -15,
        scale: 1.0,
        rotation: 0,
        opacity: 1.0,
        flipH: false,
        flipV: false,
        blendMode: 'normal',
        volume: 1.0,
        muted: false,
        fadeIn: 0.4,
        fadeOut: 0.4,
        adjustments: {
          brightness: 0, contrast: 0, saturation: 0, exposure: 0, highlights: 0,
          shadows: 0, temperature: 0, tint: 0, sharpness: 0, vignette: 0, grain: 0, hue: 0,
        },
        effects: [],
        mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
        chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
        keyframes: [],
        textConfig: {
          content: language === 'hi' ? tpl.headlineHi : tpl.headlineEn,
          fontFamily: "'Plus Jakarta Sans', sans-serif",
          fontSize: isVertical ? 38 : 44,
          color: '#ffffff',
          gradient: {
            enabled: true,
            start: tpl.category === 'Cinematic' ? '#fbbf24' : '#f43f5e',
            end: tpl.category === 'Cinematic' ? '#d97706' : '#a855f7',
            angle: 45,
          },
          bold: true,
          italic: false,
          alignment: 'center',
          letterSpacing: 2,
          stroke: { enabled: true, color: '#000000', width: 2.5 },
          shadow: { enabled: true, color: 'rgba(0,0,0,0.85)', blur: 14, offsetX: 0, offsetY: 4 },
          background: { enabled: false, color: '#000000', opacity: 0.5, borderRadius: 8, padding: 8 },
          animation: 'fade',
        },
      },
      // 3. Category Badge / Sticker Pill
      {
        id: `clip_${Date.now()}_badge`,
        trackId: 'track_stickers_1',
        trackType: 'sticker',
        name: 'Badge Pill',
        type: 'sticker',
        sourceUrl: '',
        start: 0.4,
        duration: tpl.duration - 0.8,
        sourceStart: 0,
        sourceDuration: tpl.duration - 0.8,
        speed: 1.0,
        reverse: false,
        x: isVertical ? 0 : 35,
        y: isVertical ? -38 : 38,
        scale: 1.0,
        rotation: 0,
        opacity: 1.0,
        flipH: false,
        flipV: false,
        blendMode: 'normal',
        volume: 1.0,
        muted: false,
        fadeIn: 0.3,
        fadeOut: 0.3,
        adjustments: {
          brightness: 0, contrast: 0, saturation: 0, exposure: 0, highlights: 0,
          shadows: 0, temperature: 0, tint: 0, sharpness: 0, vignette: 0, grain: 0, hue: 0,
        },
        effects: [],
        mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
        chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
        keyframes: [],
        stickerConfig: {
          emojiOrUrl: tpl.badge.includes('4K') ? '🎬' : tpl.badge.includes('VIRAL') ? '🔥' : tpl.badge.includes('NEON') ? '⚡' : '✨',
          isCustomImage: false,
          category: 'badges',
        },
      },
      // 4. Synthesized Soundtrack Track
      {
        id: `clip_${Date.now()}_bgm`,
        trackId: 'track_audio_bgm',
        trackType: 'audio',
        name: tpl.musicTitle,
        type: 'audio',
        sourceUrl: musicUrl,
        blob: musicBlob,
        start: 0,
        duration: tpl.duration,
        sourceStart: 0,
        sourceDuration: tpl.duration,
        speed: 1.0,
        reverse: false,
        x: 0,
        y: 0,
        scale: 1.0,
        rotation: 0,
        opacity: 1.0,
        flipH: false,
        flipV: false,
        blendMode: 'normal',
        volume: 0.9,
        muted: false,
        fadeIn: 0.8,
        fadeOut: 1.0,
        adjustments: {
          brightness: 0, contrast: 0, saturation: 0, exposure: 0, highlights: 0,
          shadows: 0, temperature: 0, tint: 0, sharpness: 0, vignette: 0, grain: 0, hue: 0,
        },
        effects: [],
        mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
        chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
        keyframes: [],
      },
    ],
  };

  return project;
}
