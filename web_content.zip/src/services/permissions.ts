export async function requestCameraAndMic(){
  if(!navigator.mediaDevices?.getUserMedia) throw new Error('Camera/microfone indisponíveis neste ambiente.');
  const stream=await navigator.mediaDevices.getUserMedia({video:true,audio:true});
  stream.getTracks().forEach(t=>t.stop());
  return true;
}
export async function requestMicrophone(){
  if(!navigator.mediaDevices?.getUserMedia) throw new Error('Microfone indisponível neste ambiente.');
  const stream=await navigator.mediaDevices.getUserMedia({audio:true});
  stream.getTracks().forEach(t=>t.stop());
  return true;
}
