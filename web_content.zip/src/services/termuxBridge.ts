/**
 * GODEX v0.0.1 - Termux Bridge Service
 * Handles communication with optional local Termux development environment on Android.
 */

export interface TermuxBridgeStatus {
  connected: boolean;
  endpoint: string;
  version?: string;
  os?: string;
  projectRoot?: string;
  latencyMs?: number;
  error?: string;
}

export interface TermuxCommandResult {
  command: string;
  exitCode: number;
  stdout: string;
  stderr: string;
  duration: number;
  success: boolean;
}

class TermuxBridgeClass {
  private endpoint: string = 'http://127.0.0.1:8080';
  private authToken: string = '';
  private isConnected: boolean = false;
  private lastCheckTime: number = 0;

  constructor() {
    if (typeof window !== 'undefined' && window.localStorage) {
      const savedEndpoint = localStorage.getItem('codex_termux_endpoint');
      if (savedEndpoint) this.endpoint = savedEndpoint;
      const savedToken = localStorage.getItem('codex_termux_token');
      if (savedToken) this.authToken = savedToken;
    }
  }

  public setConfig(endpoint: string, token?: string) {
    this.endpoint = endpoint.trim().replace(/\/+$/, '');
    if (token !== undefined) this.authToken = token.trim();

    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem('codex_termux_endpoint', this.endpoint);
      if (token !== undefined) localStorage.setItem('codex_termux_token', this.authToken);
    }
  }

  public getConfig() {
    return {
      endpoint: this.endpoint,
      authToken: this.authToken
    };
  }

  /**
   * Pings the local Termux bridge daemon
   */
  public async checkHealth(): Promise<TermuxBridgeStatus> {
    const start = Date.now();
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 1500);

      const res = await fetch(`${this.endpoint}/api/termux/health`, {
        method: 'GET',
        headers: {
          'Authorization': this.authToken ? `Bearer ${this.authToken}` : '',
          'Content-Type': 'application/json'
        },
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();
        this.isConnected = true;
        this.lastCheckTime = Date.now();
        return {
          connected: true,
          endpoint: this.endpoint,
          version: data.version || '1.0.0',
          os: data.os || 'Android Termux Linux',
          projectRoot: data.projectRoot || '~/projects/codex-app',
          latencyMs: Date.now() - start
        };
      } else {
        this.isConnected = false;
        return {
          connected: false,
          endpoint: this.endpoint,
          error: `HTTP ${res.status}: ${res.statusText}`,
          latencyMs: Date.now() - start
        };
      }
    } catch (err: any) {
      this.isConnected = false;
      return {
        connected: false,
        endpoint: this.endpoint,
        error: err.name === 'AbortError' ? 'Connection timeout' : 'Daemon unreachable (Is Termux bridge running on port 8080?)',
        latencyMs: Date.now() - start
      };
    }
  }

  /**
   * Executes a command on the Termux instance
   */
  public async executeCommand(command: string, cwd?: string): Promise<TermuxCommandResult> {
    const start = Date.now();
    if (!this.isConnected) {
      const health = await this.checkHealth();
      if (!health.connected) {
        return {
          command,
          exitCode: 127,
          stdout: '',
          stderr: 'Termux Bridge not connected. Please verify termux-daemon is running on ' + this.endpoint,
          duration: Date.now() - start,
          success: false
        };
      }
    }

    try {
      const res = await fetch(`${this.endpoint}/api/termux/exec`, {
        method: 'POST',
        headers: {
          'Authorization': this.authToken ? `Bearer ${this.authToken}` : '',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ command, cwd })
      });

      const data = await res.json();
      return {
        command,
        exitCode: data.exitCode ?? 0,
        stdout: data.stdout || '',
        stderr: data.stderr || '',
        duration: Date.now() - start,
        success: data.exitCode === 0
      };
    } catch (err: any) {
      return {
        command,
        exitCode: 1,
        stdout: '',
        stderr: `Termux Bridge execution error: ${err.message}`,
        duration: Date.now() - start,
        success: false
      };
    }
  }
}

export const TermuxBridgeService = new TermuxBridgeClass();
