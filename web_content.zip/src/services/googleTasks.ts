import { getAccessToken } from './firebaseAuth';
import { GoogleTaskItem, GoogleTaskList } from '../types';

const TASKS_BASE_URL = 'https://tasks.googleapis.com/tasks/v1';

export async function fetchGoogleTaskLists(): Promise<GoogleTaskList[]> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Google access token is not available. Please sign in with Google.');
  }

  const res = await fetch(`${TASKS_BASE_URL}/users/@me/lists`, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Failed to fetch task lists (${res.status})`);
  }

  const data = await res.json();
  return data.items || [];
}

export async function fetchGoogleTasks(taskListId: string = '@default'): Promise<GoogleTaskItem[]> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Google access token is not available. Please sign in with Google.');
  }

  const res = await fetch(`${TASKS_BASE_URL}/lists/${encodeURIComponent(taskListId)}/tasks?showCompleted=true&showHidden=true`, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Failed to fetch tasks (${res.status})`);
  }

  const data = await res.json();
  return (data.items || []).map((t: any) => ({
    id: t.id,
    title: t.title || '(Untitled Task)',
    notes: t.notes,
    status: t.status,
    due: t.due,
    updated: t.updated,
  }));
}

export async function completeGoogleTask(taskListId: string, taskId: string): Promise<GoogleTaskItem> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Google access token is not available.');
  }

  const res = await fetch(`${TASKS_BASE_URL}/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      status: 'completed',
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Failed to complete Google Task');
  }

  return await res.json();
}

export async function createGoogleTask(taskListId: string, title: string, notes?: string): Promise<GoogleTaskItem> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Google access token is not available.');
  }

  const res = await fetch(`${TASKS_BASE_URL}/lists/${encodeURIComponent(taskListId)}/tasks`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      title,
      notes,
      status: 'needsAction',
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Failed to create Google Task');
  }

  return await res.json();
}
