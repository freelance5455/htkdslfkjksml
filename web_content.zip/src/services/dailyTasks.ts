import { creditWallet, withWalletMutation, type WalletState } from './economy';
import { KEYS, readKey, withStorageLock, writeKey } from './storage';

export interface DailyTaskItem {
  id: string;
  title: string;
  done: boolean;
}

export interface DailyTaskDay {
  date: string;
  tasks: DailyTaskItem[];
  rewardClaimedAt?: number;
  updatedAt: number;
}

export interface DailyTaskTemplate {
  id: string;
  title: string;
}

export interface DailyTaskStore {
  templates: DailyTaskTemplate[];
  days: Record<string, DailyTaskDay>;
}

export type DailyTaskClaimResult = 'claimed' | 'already-claimed' | 'incomplete';

const DEFAULT_TEMPLATES: DailyTaskTemplate[] = [
  { id: 'daily-1', title: 'أنهِ درساً أو جزءاً محدداً منه' },
  { id: 'daily-2', title: 'حلّ مجموعة أسئلة من وحدة اليوم' },
  { id: 'daily-3', title: 'راجع ملخصاً أو بطاقة دراسية' },
  { id: 'daily-4', title: 'اكتب ملاحظة عن فكرة صعبة' },
  { id: 'daily-5', title: 'حضّر مواد الغد وخطتك' },
];

export const EMPTY_DAILY_TASKS: DailyTaskStore = {
  templates: DEFAULT_TEMPLATES,
  days: {},
};

export function localDateKey(date = new Date()): string {
  return `${date.getFullYear()}-${`${date.getMonth() + 1}`.padStart(2, '0')}-${`${date.getDate()}`.padStart(2, '0')}`;
}

function normalizeStore(value: DailyTaskStore | undefined): DailyTaskStore {
  const templates = Array.isArray(value?.templates)
    ? value.templates.filter((item) => item && typeof item.id === 'string' && typeof item.title === 'string')
    : [];
  return {
    templates: templates.length >= 3 && templates.length <= 15 ? templates : DEFAULT_TEMPLATES.map((item) => ({ ...item })),
    days: value?.days && typeof value.days === 'object' ? value.days : {},
  };
}

export function getDailyTaskStore(): DailyTaskStore {
  return normalizeStore(readKey<DailyTaskStore>(KEYS.dailyTasks, EMPTY_DAILY_TASKS));
}

export function previewDailyTaskDay(date = new Date(), store = getDailyTaskStore()): DailyTaskDay {
  const dateKey = localDateKey(date);
  return store.days[dateKey] ?? {
    date: dateKey,
    tasks: store.templates.map((template) => ({ id: `${dateKey}:${template.id}`, title: template.title, done: false })),
    updatedAt: 0,
  };
}

export async function ensureDailyTaskDay(date = new Date()): Promise<DailyTaskDay> {
  const dateKey = localDateKey(date);
  return withStorageLock('wallet', [KEYS.dailyTasks], () => {
    const current = getDailyTaskStore();
    const existing = current.days[dateKey];
    if (existing) return existing;
    const day: DailyTaskDay = {
      date: dateKey,
      tasks: current.templates.map((template) => ({ id: `${dateKey}:${template.id}`, title: template.title, done: false })),
      updatedAt: Date.now(),
    };
    writeKey(KEYS.dailyTasks, { ...current, days: { ...current.days, [dateKey]: day } });
    return day;
  });
}

async function mutateToday(
  date: Date,
  update: (store: DailyTaskStore, day: DailyTaskDay) => { store: DailyTaskStore; day: DailyTaskDay; changed: boolean },
): Promise<DailyTaskDay> {
  const dateKey = localDateKey(date);
  return withStorageLock('wallet', [KEYS.dailyTasks], () => {
    const current = getDailyTaskStore();
    const day = current.days[dateKey] ?? previewDailyTaskDay(date, current);
    const result = update(current, day);
    if (result.changed) {
      writeKey(KEYS.dailyTasks, {
        ...result.store,
        days: { ...result.store.days, [dateKey]: { ...result.day, updatedAt: Date.now() } },
      });
    }
    return result.day;
  });
}

export async function setDailyTaskDone(taskId: string, done: boolean, date = new Date()): Promise<DailyTaskDay> {
  return mutateToday(date, (store, day) => {
    const tasks = day.tasks.map((task) => task.id === taskId ? { ...task, done } : task);
    const changed = tasks.some((task, index) => task.done !== day.tasks[index]?.done);
    return { store, day: { ...day, tasks }, changed };
  });
}

export async function renameDailyTask(taskId: string, title: string, date = new Date()): Promise<DailyTaskDay> {
  const clean = title.trim().slice(0, 80);
  if (!clean) return previewDailyTaskDay(date);
  return mutateToday(date, (store, day) => {
    const currentTask = day.tasks.find((task) => task.id === taskId);
    if (!currentTask || currentTask.title === clean) return { store, day, changed: false };
    const templateId = taskId.slice(taskId.indexOf(':') + 1);
    const templates = store.templates.map((item) => item.id === templateId ? { ...item, title: clean } : item);
    return {
      store: { ...store, templates },
      day: { ...day, tasks: day.tasks.map((task) => task.id === taskId ? { ...task, title: clean } : task) },
      changed: true,
    };
  });
}

export async function addDailyTask(date = new Date()): Promise<DailyTaskDay> {
  return mutateToday(date, (store, day) => {
    if (day.tasks.length >= 15) return { store, day, changed: false };
    const id = `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const title = 'مهمة جديدة';
    const template = { id, title };
    return {
      store: { ...store, templates: [...store.templates, template] },
      day: { ...day, tasks: [...day.tasks, { id: `${day.date}:${id}`, title, done: false }] },
      changed: true,
    };
  });
}

export async function removeDailyTask(taskId: string, date = new Date()): Promise<DailyTaskDay> {
  return mutateToday(date, (store, day) => {
    if (day.tasks.length <= 3) return { store, day, changed: false };
    const templateId = taskId.slice(taskId.indexOf(':') + 1);
    return {
      store: { ...store, templates: store.templates.filter((item) => item.id !== templateId) },
      day: { ...day, tasks: day.tasks.filter((task) => task.id !== taskId) },
      changed: true,
    };
  });
}

/** تُحدّث المحفظة وسجل اليوم تحت القفل نفسه؛ المعرف الثابت يمنع المطالبة المكررة عبر التبويبات. */
export function claimDailyTaskReward(date = new Date()): Promise<DailyTaskClaimResult> {
  const dateKey = localDateKey(date);
  const claimId = `daily-task:${dateKey}`;
  return withWalletMutation([KEYS.dailyTasks], (wallet: WalletState) => {
    const store = getDailyTaskStore();
    const day = store.days[dateKey] ?? previewDailyTaskDay(date, store);
    if (day.tasks.length < 3 || !day.tasks.every((task) => task.done)) {
      return { wallet, result: 'incomplete' as const };
    }
    if (wallet.claimedRewardIds.includes(claimId) || day.rewardClaimedAt) {
      return { wallet, result: 'already-claimed' as const };
    }

    const at = Date.now();
    const credited = creditWallet(wallet, 10, 'مكافأة إتمام المهام اليومية', claimId, 'daily-task');
    const nextWallet: WalletState = {
      ...credited,
      claimedRewardIds: [...wallet.claimedRewardIds, claimId],
      claimedRewardAt: { ...wallet.claimedRewardAt, [claimId]: at },
    };
    writeKey(KEYS.dailyTasks, {
      ...store,
      days: { ...store.days, [dateKey]: { ...day, rewardClaimedAt: at, updatedAt: at } },
    });
    return { wallet: nextWallet, result: 'claimed' as const };
  });
}
