import { setDoc, doc, getDoc } from "firebase/firestore";
import { db } from "../firebase-config";
import type { ClientModuleData, RadioChannelItem } from "../types/dataconnect";

// 🟢 CANALES PÚBLICOS FIJOS (TODOS LOS VEN)
export const CANALES_PUBLICOS: RadioChannelItem[] = [
  { id: 1, freq: "433.100", nombre: "GENERAL DEMO", acceso: "libre" },
  { id: 2, freq: "433.200", nombre: "AYUDA Y SOPORTE", acceso: "libre" },
  { id: 3, freq: "433.300", nombre: "AVISOS DEL SISTEMA", acceso: "libre" }
];

// 🧩 BASE PARA MÓDULO EXCLUSIVO (CANALES 4 AL 10)
export const BASE_CANALES_MODULO = [
  { id: 4, nombre: "SU EQUIPO (DEMO)" },
  { id: 5, nombre: "SU PRIVADO (DEMO)" },
  { id: 6, nombre: "SUS PRUEBAS TÉCNICAS" },
  { id: 7, nombre: "SU MÚSICA / AMBIENTE" },
  { id: 8, nombre: "SU ADMINISTRACIÓN (VISTA)" },
  { id: 9, nombre: "LLAMADAS DIRECTAS (PRUEBA)" },
  { id: 10, nombre: "RESERVA / FUTURO" }
];

const STORAGE_KEY = "sono_radio_client_module";

// 🎯 FUNCIÓN PRINCIPAL: CREAR USUARIO / MÓDULO NUEVO
export async function crearModuloCliente(
  nombreUsuario: string = "OPERADOR_DEMO",
  esDemo: boolean = true,
  customId?: string
): Promise<ClientModuleData> {
  // 1. GENERAR ID ÚNICO
  const numeroId = customId 
    ? parseInt(customId.replace(/\D/g, '').slice(0, 4)) || Math.floor(1000 + Math.random() * 9000)
    : Math.floor(1000 + Math.random() * 9000);
  const prefijo = esDemo ? "SONO-DEMO-" : "SONO-MOD-";
  const clienteId = customId || (prefijo + numeroId);

  // 2. ASIGNAR FRECUENCIAS ÚNICAS (SIN CHOQUES)
  // Desplazamiento mínimo basado en el ID para evitar cruces
  const offsetId = (numeroId % 50) * 0.002; 
  const baseFreq = esDemo ? (433.500 + offsetId) : (434.000 + (numeroId / 10000));
  
  const moduloExclusivo: RadioChannelItem[] = BASE_CANALES_MODULO.map((canal, i) => ({
    id: canal.id,
    nombre: esDemo ? canal.nombre : canal.nombre.replace(" (DEMO)", "").replace(" (VISTA)", "").replace(" (PRUEBA)", ""),
    freq: (baseFreq + (i * 0.100)).toFixed(3),
    acceso: esDemo ? "demo_limitado" : "privado_modulo"
  }));

  // 3. FECHA DE VENCIMIENTO (7 DÍAS EN DEMO)
  const fechaVencimiento = esDemo 
    ? new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    : null;

  // 4. OBJETO COMPLETO DEL CLIENTE
  const datosCliente: ClientModuleData = {
    tipo: esDemo ? "demo_prueba" : "premium",
    cliente_id: clienteId,
    nombre: nombreUsuario,
    estado: "activo",
    creado_en: new Date().toISOString(),
    vencimiento_demo: fechaVencimiento,
    frecuencia_base: baseFreq.toFixed(3),
    canales_publicos: CANALES_PUBLICOS,
    modulo_privado: moduloExclusivo,
    limite_usuarios: esDemo ? 5 : 50
  };

  // 5. GUARDAR LOCALMENTE
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(datosCliente));
    } catch (e) {
      console.warn("Storage local no accesible:", e);
    }
  }

  // 6. GUARDAR EN FIREBASE FIRESTORE
  try {
    if (db) {
      await setDoc(doc(db, "usuarios_radio", clienteId), datosCliente);
      console.log(`✅ MÓDULO CREADO EN FIRESTORE: ${clienteId}`);
    }
  } catch (err) {
    console.warn("Sincronización Firestore diferida para módulo cliente:", err);
  }

  console.log(`📡 Módulo listo: ${clienteId} | Frecuencia Base: ${baseFreq.toFixed(3)} MHz`);
  return datosCliente;
}

// 🔄 RECUPERAR O INICIALIZAR AUTOMÁTICAMENTE EL MÓDULO
export function obtenerModuloGuardado(): ClientModuleData | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw) as ClientModuleData;
    }
  } catch (e) {
    console.warn("Error leyendo módulo guardado:", e);
  }
  return null;
}

// ⏱️ CALCULAR DÍAS RESTANTES DE DEMO
export function calcularDiasRestantesDemo(vencimientoIso?: string | null): number {
  if (!vencimientoIso) return 7;
  const fin = new Date(vencimientoIso).getTime();
  const ahora = Date.now();
  const diffMs = fin - ahora;
  if (diffMs <= 0) return 0;
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}
