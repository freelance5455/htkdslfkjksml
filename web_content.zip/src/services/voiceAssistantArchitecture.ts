/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * 002 AI — PHASE 2: VOICE ASSISTANT ARCHITECTURE
 * Modular architecture for real-time Voice-to-Voice AI integration,
 * Speech Recognition (STT), Neural Text-to-Speech (TTS), and 3D Viseme Lip Synchronization.
 */

import * as THREE from 'three';

// ============================================================================
// 1. Core Types & Viseme Standards
// ============================================================================

export type VisemeName = 
  | 'viseme_sil' 
  | 'viseme_aa' 
  | 'viseme_oh' 
  | 'viseme_ee' 
  | 'viseme_fv' 
  | 'viseme_mouthOpen' 
  | 'viseme_smile';

export type VoicePersona = 'devoted-002' | 'combat-002' | 'playful-002' | 'analytical-002';

export interface VisemeFrame {
  timestamp: number;
  weights: Record<VisemeName, number>;
  amplitude: number;
}

export interface VoiceStreamSessionConfig {
  sampleRate: number;
  channels: number;
  vadThreshold: number; // 0.0 to 1.0 energy threshold
  silenceTimeoutMs: number;
  persona: VoicePersona;
  enableLipSync: boolean;
}

export type VoiceAssistantState = 
  | 'uninitialized'
  | 'ready'
  | 'listening'
  | 'processing'
  | 'speaking'
  | 'error';

// ============================================================================
// 2. Speech-to-Text (STT) Module Interface
// ============================================================================

export interface ISpeechRecognitionService {
  isSupported(): boolean;
  start(config?: Partial<VoiceStreamSessionConfig>): Promise<void>;
  stop(): Promise<void>;
  onTranscript(callback: (transcript: string, isFinal: boolean) => void): () => void;
  onError(callback: (error: Error) => void): () => void;
}

/**
 * Concrete Web Speech API adapter with clean fallbacks for mobile browsers.
 */
export class BrowserSpeechRecognitionAdapter implements ISpeechRecognitionService {
  private recognition: any = null;
  private listeners: ((transcript: string, isFinal: boolean) => void)[] = [];
  private errorListeners: ((error: Error) => void)[] = [];

  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = 
        (window as any).SpeechRecognition || 
        (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US';

        this.recognition.onresult = (event: any) => {
          let interim = '';
          let final = '';

          for (let i = event.resultIndex; i < event.results.length; ++i) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              final += transcript;
            } else {
              interim += transcript;
            }
          }

          const output = final || interim;
          const isFinal = Boolean(final);
          this.listeners.forEach(cb => cb(output, isFinal));
        };

        this.recognition.onerror = (event: any) => {
          const err = new Error(event.error || 'Speech recognition failed');
          this.errorListeners.forEach(cb => cb(err));
        };
      }
    }
  }

  isSupported(): boolean {
    return this.recognition !== null;
  }

  async start(): Promise<void> {
    if (!this.recognition) throw new Error('Speech recognition not supported on this browser.');
    try {
      this.recognition.start();
    } catch {
      // Already running
    }
  }

  async stop(): Promise<void> {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {
        // Ignored
      }
    }
  }

  onTranscript(callback: (transcript: string, isFinal: boolean) => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(cb => cb !== callback);
    };
  }

  onError(callback: (error: Error) => void): () => void {
    this.errorListeners.push(callback);
    return () => {
      this.errorListeners = this.errorListeners.filter(cb => cb !== callback);
    };
  }
}

// ============================================================================
// 3. Neural Text-to-Speech (TTS) Module Interface
// ============================================================================

export interface INeuralTtsService {
  synthesize(text: string, persona: VoicePersona): Promise<ArrayBuffer>;
  speak(text: string, onAudioChunk?: (chunk: Float32Array) => void): Promise<void>;
  stop(): void;
}

/**
 * Standard Web Audio synthesizer reference implementation.
 * Designed to seamlessly swap with server-side Gemini Live/Neural audio stream.
 */
export class ClientTtsEngine implements INeuralTtsService {
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  async synthesize(_text: string, _persona: VoicePersona): Promise<ArrayBuffer> {
    // Architectural placeholder for binary PCM stream from Gemini Live API
    return new ArrayBuffer(0);
  }

  speak(text: string, onAudioChunk?: (chunk: Float32Array) => void): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined' || !window.speechSynthesis) {
        resolve();
        return;
      }

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      this.currentUtterance = utterance;

      utterance.pitch = 1.25; // Anime vocal pitch
      utterance.rate = 1.05;

      // Simulated audio energy frames for lip-sync during TTS playback
      let interval: any = null;
      utterance.onstart = () => {
        if (onAudioChunk) {
          interval = setInterval(() => {
            const dummyFrame = new Float32Array(256);
            for (let i = 0; i < dummyFrame.length; i++) {
              dummyFrame[i] = (Math.random() - 0.5) * 0.8;
            }
            onAudioChunk(dummyFrame);
          }, 33);
        }
      };

      utterance.onend = () => {
        if (interval) clearInterval(interval);
        resolve();
      };

      utterance.onerror = () => {
        if (interval) clearInterval(interval);
        resolve();
      };

      window.speechSynthesis.speak(utterance);
    });
  }

  stop(): void {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  }
}

// ============================================================================
// 4. 3D Lip-Sync & Viseme Controller for Three.js
// ============================================================================

export interface ILipSyncController {
  attachMesh(mesh: THREE.Mesh): void;
  updateFromAudioData(audioData: Float32Array): VisemeFrame;
  applyVisemeFrame(frame: VisemeFrame): void;
  resetMouth(): void;
}

export class LipSyncController implements ILipSyncController {
  private targetMesh: THREE.Mesh | null = null;
  private morphMap: Record<VisemeName, number | null> = {
    viseme_sil: null,
    viseme_aa: null,
    viseme_oh: null,
    viseme_ee: null,
    viseme_fv: null,
    viseme_mouthOpen: null,
    viseme_smile: null,
  };

  attachMesh(mesh: THREE.Mesh): void {
    this.targetMesh = mesh;
    if (!mesh.morphTargetDictionary) return;

    const dict = mesh.morphTargetDictionary;
    // Inspect common VRM / glTF phoneme morph targets
    const findIndex = (patterns: RegExp[]): number | null => {
      for (const [name, index] of Object.entries(dict)) {
        if (patterns.some(p => p.test(name))) {
          return index;
        }
      }
      return null;
    };

    this.morphMap.viseme_aa = findIndex([/viseme_aa/i, /fcl_mth_a/i, /mouth_a/i, /mouthopen/i]);
    this.morphMap.viseme_oh = findIndex([/viseme_o/i, /fcl_mth_o/i, /mouth_o/i]);
    this.morphMap.viseme_ee = findIndex([/viseme_i/i, /fcl_mth_i/i, /mouth_i/i]);
    this.morphMap.viseme_mouthOpen = findIndex([/mouthopen/i, /open/i, /jawopen/i]);
    this.morphMap.viseme_smile = findIndex([/smile/i, /happy/i]);
  }

  updateFromAudioData(audioData: Float32Array): VisemeFrame {
    // RMS (Root Mean Square) energy extraction
    let sum = 0;
    for (let i = 0; i < audioData.length; i++) {
      sum += audioData[i] * audioData[i];
    }
    const rms = Math.sqrt(sum / audioData.length);
    const clampedAmp = Math.min(Math.max((rms - 0.02) * 5.0, 0), 1.0);

    // Natural viseme distribution based on audio amplitude
    const frame: VisemeFrame = {
      timestamp: performance.now(),
      amplitude: clampedAmp,
      weights: {
        viseme_sil: 1 - clampedAmp,
        viseme_aa: clampedAmp * 0.7,
        viseme_oh: clampedAmp * 0.4,
        viseme_ee: clampedAmp * 0.3,
        viseme_fv: clampedAmp * 0.1,
        viseme_mouthOpen: clampedAmp * 0.85,
        viseme_smile: 0.1,
      },
    };

    this.applyVisemeFrame(frame);
    return frame;
  }

  applyVisemeFrame(frame: VisemeFrame): void {
    if (!this.targetMesh || !this.targetMesh.morphTargetInfluences) return;
    const influences = this.targetMesh.morphTargetInfluences;

    // Apply morph target weights
    if (this.morphMap.viseme_aa !== null) {
      influences[this.morphMap.viseme_aa] = frame.weights.viseme_aa;
    }
    if (this.morphMap.viseme_mouthOpen !== null) {
      influences[this.morphMap.viseme_mouthOpen] = frame.weights.viseme_mouthOpen;
    }
    if (this.morphMap.viseme_oh !== null) {
      influences[this.morphMap.viseme_oh] = frame.weights.viseme_oh;
    }
  }

  resetMouth(): void {
    if (!this.targetMesh || !this.targetMesh.morphTargetInfluences) return;
    const influences = this.targetMesh.morphTargetInfluences;
    Object.values(this.morphMap).forEach(idx => {
      if (idx !== null && influences[idx] !== undefined) {
        influences[idx] = 0;
      }
    });
  }
}

// ============================================================================
// 5. Voice-to-Voice Full Pipeline Orchestrator
// ============================================================================

export class VoiceAssistantPipeline {
  private stt: ISpeechRecognitionService;
  private tts: INeuralTtsService;
  public lipSync: ILipSyncController;
  private state: VoiceAssistantState = 'ready';

  constructor() {
    this.stt = new BrowserSpeechRecognitionAdapter();
    this.tts = new ClientTtsEngine();
    this.lipSync = new LipSyncController();
  }

  getState(): VoiceAssistantState {
    return this.state;
  }

  async startListening(onTranscript: (text: string) => void): Promise<void> {
    if (!this.stt.isSupported()) {
      throw new Error('STT is not supported on this browser.');
    }
    this.state = 'listening';
    this.stt.onTranscript((text, isFinal) => {
      if (isFinal && text.trim().length > 0) {
        this.state = 'processing';
        onTranscript(text.trim());
      }
    });
    await this.stt.start();
  }

  async speakResponse(text: string): Promise<void> {
    this.state = 'speaking';
    await this.tts.speak(text, (audioChunk) => {
      this.lipSync.updateFromAudioData(audioChunk);
    });
    this.lipSync.resetMouth();
    this.state = 'ready';
  }

  stopAll(): void {
    this.stt.stop();
    this.tts.stop();
    this.lipSync.resetMouth();
    this.state = 'ready';
  }
}

export const voiceAssistantPipeline = new VoiceAssistantPipeline();
