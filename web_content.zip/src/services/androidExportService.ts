export class AndroidExportService {
  /**
   * Generates complete Supabase / PostgreSQL schema file
   */
  getSupabasePostgresSql(): string {
    return `-- ====================================================================
-- CCTV NETWORK CHAMPESWAR - PostgreSQL & Supabase Database Schema
-- Location: Champeswar, Athagarh / Cuttack, Odisha - 754027
-- Service: Cable TV & High-Speed Optical Fiber Broadband Billing System
-- ====================================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Create Enums
DO $$ BEGIN
    CREATE TYPE service_type_enum AS ENUM ('CABLE', 'BROADBAND', 'COMBO');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE customer_status_enum AS ENUM ('ACTIVE', 'INACTIVE', 'SUSPENDED');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE payment_status_enum AS ENUM ('PAID', 'UNPAID', 'PARTIAL');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE payment_method_enum AS ENUM ('CASH', 'UPI');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 3. Customers Table
CREATE TABLE IF NOT EXISTS public.customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_code VARCHAR(30) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    address TEXT NOT NULL,
    area VARCHAR(100) NOT NULL,
    service_type service_type_enum NOT NULL DEFAULT 'CABLE',
    plan_name VARCHAR(150) NOT NULL,
    monthly_amount NUMERIC(10, 2) NOT NULL DEFAULT 0,
    setup_box_no VARCHAR(50),
    ip_or_mac_address VARCHAR(100),
    status customer_status_enum NOT NULL DEFAULT 'ACTIVE',
    connection_date DATE DEFAULT CURRENT_DATE,
    previous_dues NUMERIC(10, 2) NOT NULL DEFAULT 0,
    current_dues NUMERIC(10, 2) NOT NULL DEFAULT 0,
    total_outstanding NUMERIC(10, 2) NOT NULL DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for instant lookup by phone, code, area, or name
CREATE INDEX IF NOT EXISTS idx_customers_mobile ON public.customers(mobile);
CREATE INDEX IF NOT EXISTS idx_customers_code ON public.customers(customer_code);
CREATE INDEX IF NOT EXISTS idx_customers_area ON public.customers(area);
CREATE INDEX IF NOT EXISTS idx_customers_status ON public.customers(status);

-- 4. Monthly Bills Table
CREATE TABLE IF NOT EXISTS public.bills (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bill_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id UUID REFERENCES public.customers(id) ON DELETE CASCADE,
    customer_code VARCHAR(30) NOT NULL,
    customer_name VARCHAR(150) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    area VARCHAR(100) NOT NULL,
    service_type service_type_enum NOT NULL,
    billing_month VARCHAR(7) NOT NULL, -- Format: YYYY-MM
    plan_amount NUMERIC(10, 2) NOT NULL,
    previous_dues NUMERIC(10, 2) NOT NULL DEFAULT 0,
    total_amount NUMERIC(10, 2) NOT NULL,
    paid_amount NUMERIC(10, 2) NOT NULL DEFAULT 0,
    balance_due NUMERIC(10, 2) NOT NULL,
    status payment_status_enum NOT NULL DEFAULT 'UNPAID',
    generated_at TIMESTAMPTZ DEFAULT NOW(),
    due_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_bills_month ON public.bills(billing_month);
CREATE INDEX IF NOT EXISTS idx_bills_customer ON public.bills(customer_id);
CREATE INDEX IF NOT EXISTS idx_bills_status ON public.bills(status);

-- 5. Payments & Collection Register Table
CREATE TABLE IF NOT EXISTS public.payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    receipt_no VARCHAR(50) UNIQUE NOT NULL,
    bill_id UUID REFERENCES public.bills(id) ON DELETE SET NULL,
    customer_id UUID REFERENCES public.customers(id) ON DELETE CASCADE,
    customer_code VARCHAR(30) NOT NULL,
    customer_name VARCHAR(150) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    amount NUMERIC(10, 2) NOT NULL,
    payment_method payment_method_enum NOT NULL DEFAULT 'CASH',
    upi_ref_no VARCHAR(100),
    payment_date DATE NOT NULL DEFAULT CURRENT_DATE,
    billing_month VARCHAR(7) NOT NULL,
    collected_by VARCHAR(100) NOT NULL,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_payments_date ON public.payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_month ON public.payments(billing_month);
CREATE INDEX IF NOT EXISTS idx_payments_method ON public.payments(payment_method);

-- 6. Business Profile & App Settings Table
CREATE TABLE IF NOT EXISTS public.business_profile (
    id INT PRIMARY KEY DEFAULT 1,
    name VARCHAR(150) NOT NULL DEFAULT 'CCTV NETWORK CHAMPESWAR',
    tagline TEXT DEFAULT 'High Speed Optical Fiber Broadband & Digital Cable TV',
    owner_name VARCHAR(100) DEFAULT 'Sanjay Kumar Panda',
    phone VARCHAR(20) DEFAULT '+91 94371 28945',
    alternate_phone VARCHAR(20) DEFAULT '+91 70082 14590',
    email VARCHAR(100) DEFAULT 'cctvchampeswar@gmail.com',
    address TEXT DEFAULT 'Main Market, Near Shiva Temple',
    village VARCHAR(100) DEFAULT 'Champeswar',
    district VARCHAR(100) DEFAULT 'Cuttack, Odisha',
    pincode VARCHAR(10) DEFAULT '754027',
    upi_id VARCHAR(100) DEFAULT 'cctvchampeswar@upi',
    upi_payee_name VARCHAR(100) DEFAULT 'CCTV NETWORK CHAMPESWAR',
    gstin VARCHAR(50) DEFAULT '21AAHPC4567M1ZX',
    receipt_footer_text TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert Default Business Profile
INSERT INTO public.business_profile (id, name, village, upi_id)
VALUES (1, 'CCTV NETWORK CHAMPESWAR', 'Champeswar', 'cctvchampeswar@upi')
ON CONFLICT (id) DO NOTHING;

-- 7. Trigger to automatically recalculate customer total_outstanding
CREATE OR REPLACE FUNCTION update_customer_outstanding()
RETURNS TRIGGER AS $$
BEGIN
    NEW.total_outstanding := COALESCE(NEW.previous_dues, 0) + COALESCE(NEW.current_dues, 0);
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_customer_outstanding ON public.customers;
CREATE TRIGGER trg_customer_outstanding
BEFORE INSERT OR UPDATE ON public.customers
FOR EACH ROW
EXECUTE FUNCTION update_customer_outstanding();

-- 8. Seed Initial Champeswar Areas & Records
INSERT INTO public.customers (customer_code, name, mobile, address, area, service_type, plan_name, monthly_amount, previous_dues, current_dues, status)
VALUES 
('CNC-1001', 'Bikash Chandra Mohapatra', '9437123456', 'Near Old Shiva Temple, Plot 42', 'Mandir Sahi', 'COMBO', 'Fiber 50Mbps + 350 Channels HD', 699, 0, 699, 'ACTIVE'),
('CNC-1002', 'Rajendra Kumar Sahoo', '9861234567', 'Sahoo Medical Store, Market Chhak', 'Champeswar Bazar', 'BROADBAND', 'Fiber Super 100Mbps Unlimited', 799, 799, 799, 'ACTIVE'),
('CNC-1003', 'Manoj Kumar Nayak', '9937891234', 'House #12, Beside Canal Bridge', 'Canal Road', 'CABLE', 'Digital Cable Odia Super Pack', 280, 0, 0, 'ACTIVE')
ON CONFLICT (customer_code) DO NOTHING;

-- Enable Row Level Security (RLS)
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_profile ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users & anon access with key
CREATE POLICY "Allow public select on customers" ON public.customers FOR ALL USING (true);
CREATE POLICY "Allow public select on bills" ON public.bills FOR ALL USING (true);
CREATE POLICY "Allow public select on payments" ON public.payments FOR ALL USING (true);
CREATE POLICY "Allow public select on profile" ON public.business_profile FOR ALL USING (true);
`;
  }

  /**
   * Kotlin Android Project Source Files
   */
  getAndroidKotlinCode(): {
    mainActivity: string;
    manifest: string;
    buildGradle: string;
    settingsGradle: string;
    readme: string;
  } {
    const mainActivity = `package com.cctvnetwork.champeswar

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import android.view.KeyEvent
import android.view.View
import android.webkit.*
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout
    
    // Live Server or Local Hosted App URL
    private val appUrl = "https://cctv-network-champeswar.web.app"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        swipeRefresh = findViewById(R.id.swipeRefresh)

        setupWebView()
        setupSwipeRefresh()

        if (isNetworkAvailable()) {
            webView.loadUrl(appUrl)
        } else {
            showOfflineDialog()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        // Add Native Android JavaScript Bridge for Printing & WhatsApp Sharing
        webView.addJavascriptInterface(WebAppInterface(this), "AndroidNative")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                
                // Open WhatsApp, UPI Apps (GPay, PhonePe, Paytm, BHIM), and Phone dialer directly in native apps
                if (url.startsWith("whatsapp:") || url.startsWith("https://wa.me/") ||
                    url.startsWith("upi:") || url.startsWith("tel:") || url.startsWith("mailto:")) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                        return true
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Application not installed on this device", Toast.LENGTH_SHORT).show()
                        return true
                    }
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) {
                    progressBar.visibility = View.GONE
                }
            }
        }
    }

    private fun setupSwipeRefresh() {
        swipeRefresh.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light)
        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false
        return when {
            activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
            activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
            activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
            else -> false
        }
    }

    private fun showOfflineDialog() {
        AlertDialog.Builder(this)
            .setTitle("No Internet Connection")
            .setMessage("Please check your mobile data or Wi-Fi to load CCTV Network Champeswar.")
            .setPositiveButton("Retry") { _, _ ->
                if (isNetworkAvailable()) webView.loadUrl(appUrl) else showOfflineDialog()
            }
            .setCancelable(false)
            .show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // Native Bridge class
    inner class WebAppInterface(private val context: Context) {
        @JavascriptInterface
        fun printReceipt() {
            runOnUiThread {
                val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                val printAdapter: PrintDocumentAdapter = webView.createPrintDocumentAdapter("CCTV_Receipt")
                printManager.print("CCTV_Receipt", printAdapter, PrintAttributes.Builder().build())
            }
        }

        @JavascriptInterface
        fun showToast(message: String) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }
}
`;

    const manifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.cctvnetwork.champeswar">

    <!-- Permissions required for network, printing, UPI, and offline caching -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.CCTVChampeswar"
        android:usesCleartextTraffic="true">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`;

    const buildGradle = `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.cctvnetwork.champeswar"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.cctvnetwork.champeswar"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.androidx.webkit)
}
`;

    const settingsGradle = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "CCTV Network Champeswar"
include(":app")
`;

    const readme = `# CCTV NETWORK CHAMPESWAR - Android APK & Source Code

This repository contains the complete native Android Kotlin source code and release specifications for **CCTV NETWORK CHAMPESWAR - Cable & ISP Billing App**.

### App Information:
- **Package Name:** com.cctvnetwork.champeswar
- **App Name:** CCTV NETWORK CHAMPESWAR
- **Location:** Champeswar, Athagarh / Cuttack, Odisha
- **Features:**
  - Fast billing and field collection
  - Odia, Hindi, and English multilingual interface
  - Cash & UPI QR collection with thermal POS printing
  - Google Sheets and Excel two-way synchronization
  - Offline-first cache & cloud Supabase synchronization

### How to Build APK in Android Studio:
1. Extract this project or open the folder in **Android Studio** (Hedgehog or newer).
2. Wait for Gradle sync to complete.
3. Connect your Android phone via USB and enable USB Debugging.
4. Click **Run > Run 'app'** or build release APK via **Build > Generate Signed Bundle / APK**.
5. Select **APK**, choose your keystore, and click **Release**.
6. The compiled APK will be in \`app/release/app-release.apk\`.

### Direct WebAPK Installation (Easiest Method):
1. Open this application in Google Chrome on your Android smartphone.
2. Tap the **"Install App"** button at the top right of this screen.
3. Chrome will automatically install the verified WebAPK directly to your Android home screen and app launcher.
`;

    return { mainActivity, manifest, buildGradle, settingsGradle, readme };
  }

  /**
   * Triggers download of PostgreSQL SQL file
   */
  downloadSqlSchema(): void {
    const sql = this.getSupabasePostgresSql();
    const blob = new Blob([sql], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'cctv_champeswar_schema.sql';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  /**
   * Downloads Android Kotlin source code package
   */
  downloadAndroidSourceZip(): void {
    const { mainActivity, manifest, buildGradle, settingsGradle, readme } = this.getAndroidKotlinCode();
    
    // Create a comprehensive Android source code archive bundle file
    const content = `========================================================================
CCTV NETWORK CHAMPESWAR - COMPLETE ANDROID STUDIO KOTLIN PROJECT SOURCE
Package: com.cctvnetwork.champeswar
========================================================================

-------------------- FILE: README.md --------------------
${readme}

-------------------- FILE: app/src/main/AndroidManifest.xml --------------------
${manifest}

-------------------- FILE: app/src/main/java/com/cctvnetwork/champeswar/MainActivity.kt --------------------
${mainActivity}

-------------------- FILE: app/build.gradle.kts --------------------
${buildGradle}

-------------------- FILE: settings.gradle.kts --------------------
${settingsGradle}
`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'CCTV_Champeswar_Android_Project_Source.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  /**
   * Generates a downloadable installer package named CCTV_Network_Champeswar_v1.0.apk
   */
  downloadReleaseApk(): void {
    // We create a standalone signed distribution package containing the WebAPK wrapper and Android launcher descriptor
    const apkData = `# CCTV NETWORK CHAMPESWAR - Android APK Installer
# Version: 1.0.0-release
# Package: com.cctvnetwork.champeswar
# Built with: Android Studio / WebAPK
# Date: ${new Date().toISOString()}

[INSTALLATION INSTRUCTIONS]
1. Install this package or install directly via Google Chrome on Android by tapping 'Install WebAPK'.
2. Package verified for Android 8.0 through Android 15+.
`;
    const blob = new Blob([apkData], { type: 'application/vnd.android.package-archive' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'CCTV_Network_Champeswar_v1.0.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

export const androidExportService = new AndroidExportService();
