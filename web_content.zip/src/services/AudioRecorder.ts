/**
 * AudioRecorder - Captures microphone input, resamples to 16kHz PCM mono 16-bit LE,
 * and provides real-time audio analysis for visual feedback.
 */
export class AudioRecorder {
  private audioCtx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private isRecording = false;
  private isMuted = false;

  private onAudioChunk: (base64Data: string) => void;
  private onError?: (err: Error) => void;

  constructor(
    onAudioChunk: (base64Data: string) => void,
    onError?: (err: Error) => void
  ) {
    this.onAudioChunk = onAudioChunk;
    this.onError = onError;
  }

  async start(): Promise<void> {
    if (this.isRecording) return;

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      // Request 16000 if supported by browser, else will adaptively downsample
      try {
        this.audioCtx = new AudioCtxClass({ sampleRate: 16000 });
      } catch {
        this.audioCtx = new AudioCtxClass();
      }

      if (this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }

      this.sourceNode = this.audioCtx.createMediaStreamSource(this.stream);
      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 128;
      this.analyserNode.smoothingTimeConstant = 0.5;

      // ScriptProcessor with bufferSize = 2048 or 4096 (low latency)
      this.processorNode = this.audioCtx.createScriptProcessor(2048, 1, 1);

      this.sourceNode.connect(this.analyserNode);
      this.analyserNode.connect(this.processorNode);
      // ScriptProcessor must be connected to destination for onaudioprocess to fire
      this.processorNode.connect(this.audioCtx.destination);

      const actualSampleRate = this.audioCtx.sampleRate;

      this.processorNode.onaudioprocess = (e) => {
        if (!this.isRecording || this.isMuted) return;

        const inputChannelData = e.inputBuffer.getChannelData(0);
        // Resample from actualSampleRate to 16000
        const pcm16Buffer = this.downsampleTo16kPCM(inputChannelData, actualSampleRate);
        const base64 = this.arrayBufferToBase64(pcm16Buffer);
        this.onAudioChunk(base64);
      };

      this.isRecording = true;
    } catch (err) {
      this.onError?.(err instanceof Error ? err : new Error(String(err)));
      this.stop();
      throw err;
    }
  }

  setMute(muted: boolean) {
    this.isMuted = muted;
  }

  getMuted(): boolean {
    return this.isMuted;
  }

  getMicLevel(): number {
    if (!this.analyserNode || !this.isRecording || this.isMuted) return 0;
    const dataArray = new Uint8Array(this.analyserNode.frequencyBinCount);
    this.analyserNode.getByteFrequencyData(dataArray);
    let sum = 0;
    for (let i = 0; i < dataArray.length; i++) {
      sum += dataArray[i];
    }
    const avg = sum / dataArray.length;
    return Math.min(1, avg / 128); // 0.0 to 1.0
  }

  getFrequencyData(outputArray: Uint8Array): void {
    if (!this.analyserNode || !this.isRecording || this.isMuted) {
      outputArray.fill(0);
      return;
    }
    this.analyserNode.getByteFrequencyData(outputArray as any);
  }

  stop() {
    this.isRecording = false;

    if (this.processorNode) {
      try {
        this.processorNode.disconnect();
        this.processorNode.onaudioprocess = null;
      } catch {}
      this.processorNode = null;
    }

    if (this.analyserNode) {
      try {
        this.analyserNode.disconnect();
      } catch {}
      this.analyserNode = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {}
      this.sourceNode = null;
    }

    if (this.stream) {
      this.stream.getTracks().forEach((t) => t.stop());
      this.stream = null;
    }

    if (this.audioCtx) {
      try {
        this.audioCtx.close();
      } catch {}
      this.audioCtx = null;
    }
  }

  private downsampleTo16kPCM(input: Float32Array, inputRate: number): ArrayBuffer {
    const targetRate = 16000;
    if (inputRate === targetRate) {
      const buffer = new ArrayBuffer(input.length * 2);
      const view = new DataView(buffer);
      for (let i = 0; i < input.length; i++) {
        const s = Math.max(-1, Math.min(1, input[i]));
        view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true); // Little endian
      }
      return buffer;
    }

    const ratio = inputRate / targetRate;
    const newLength = Math.round(input.length / ratio);
    const buffer = new ArrayBuffer(newLength * 2);
    const view = new DataView(buffer);

    for (let i = 0; i < newLength; i++) {
      const originalIndex = i * ratio;
      const index1 = Math.floor(originalIndex);
      const index2 = Math.min(index1 + 1, input.length - 1);
      const frac = originalIndex - index1;
      const sample = input[index1] * (1 - frac) + input[index2] * frac;
      const clamped = Math.max(-1, Math.min(1, sample));
      view.setInt16(i * 2, clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff, true);
    }

    return buffer;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }
}
