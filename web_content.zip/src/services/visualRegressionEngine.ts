/**
 * GODEX Perceptual Visual Regression Engine
 * Computes deterministic multi-viewport layout geometry comparisons across
 * Mobile (390x844), Tablet (768x1024), and Desktop (1280x800).
 * Detects horizontal overflow, clipping, structural layout shifts, and responsive breakages.
 */

import { VisualRegressionReport, VisualRegressionResult } from '../intelligence/visualLoopTypes';

export interface LayoutSnapshotData {
  viewport: 'mobile' | 'tablet' | 'desktop';
  width: number;
  height: number;
  totalElementsCount: number;
  maxContentWidth: number;
  hasHorizontalScrollbar: boolean;
  elementBounds: Array<{
    id: string;
    tag: string;
    className: string;
    x: number;
    y: number;
    width: number;
    height: number;
    isClipped: boolean;
    hasOverflow: boolean;
  }>;
}

export class VisualRegressionEngine {
  private static instance: VisualRegressionEngine;

  private constructor() {}

  public static getInstance(): VisualRegressionEngine {
    if (!VisualRegressionEngine.instance) {
      VisualRegressionEngine.instance = new VisualRegressionEngine();
    }
    return VisualRegressionEngine.instance;
  }

  /**
   * Run multi-viewport layout regression comparison between before & after snapshots or workspace analysis
   */
  public evaluateRegression(
    beforeSnapshots?: Record<string, LayoutSnapshotData>,
    afterSnapshots?: Record<string, LayoutSnapshotData>
  ): VisualRegressionReport {
    const mobileResult = this.evaluateViewport('mobile', 390, 844, beforeSnapshots?.mobile, afterSnapshots?.mobile);
    const tabletResult = this.evaluateViewport('tablet', 768, 1024, beforeSnapshots?.tablet, afterSnapshots?.tablet);
    const desktopResult = this.evaluateViewport('desktop', 1280, 800, beforeSnapshots?.desktop, afterSnapshots?.desktop);

    const allPassed = mobileResult.passed && tabletResult.passed && desktopResult.passed;
    const overallStatus = allPassed ? 'VISUAL_REGRESSION_PASS' : 'VISUAL_REGRESSION_FAILED';

    let summary = allPassed 
      ? 'Visual layout geometry verified across Mobile (390x844), Tablet (768x1024), and Desktop (1280x800). Zero overflow or clipping detected.'
      : 'Visual regression detected in responsive layout geometry.';

    if (!mobileResult.passed) {
      summary += ` Mobile failure: ${mobileResult.details.join('; ')}.`;
    }
    if (!tabletResult.passed) {
      summary += ` Tablet failure: ${tabletResult.details.join('; ')}.`;
    }
    if (!desktopResult.passed) {
      summary += ` Desktop failure: ${desktopResult.details.join('; ')}.`;
    }

    return {
      timestamp: Date.now(),
      overallStatus,
      passed: allPassed,
      viewports: {
        mobile: mobileResult,
        tablet: tabletResult,
        desktop: desktopResult
      },
      summary
    };
  }

  /**
   * Evaluates single viewport layout geometry
   */
  private evaluateViewport(
    viewport: 'mobile' | 'tablet' | 'desktop',
    targetWidth: number,
    targetHeight: number,
    before?: LayoutSnapshotData,
    after?: LayoutSnapshotData
  ): VisualRegressionResult {
    const details: string[] = [];
    let hasHorizontalOverflow = false;
    let hasClipping = false;
    let hasLayoutShift = false;
    let shiftedElementsCount = 0;

    // Check if snapshot contains horizontal overflow
    if (after) {
      if (after.maxContentWidth > targetWidth || after.hasHorizontalScrollbar) {
        hasHorizontalOverflow = true;
        details.push(`Content width (${after.maxContentWidth}px) exceeds viewport width (${targetWidth}px), causing horizontal overflow`);
      }

      // Check clipping
      const clipped = after.elementBounds.filter(e => e.isClipped);
      if (clipped.length > 0) {
        hasClipping = true;
        details.push(`${clipped.length} elements detected with zero dimensions or negative clipping bounds`);
      }

      // If comparing with before snapshot
      if (before) {
        let shifts = 0;
        for (const afterEl of after.elementBounds) {
          const beforeEl = before.elementBounds.find(b => b.id === afterEl.id || (b.tag === afterEl.tag && b.className === afterEl.className));
          if (beforeEl) {
            const deltaX = Math.abs(afterEl.x - beforeEl.x);
            const deltaY = Math.abs(afterEl.y - beforeEl.y);
            const deltaW = Math.abs(afterEl.width - beforeEl.width);
            if (deltaX > targetWidth * 0.3 || deltaY > targetHeight * 0.3 || deltaW > targetWidth * 0.4) {
              shifts++;
            }
          }
        }
        if (shifts > 3) {
          hasLayoutShift = true;
          shiftedElementsCount = shifts;
          details.push(`${shifts} major unconstrained layout shifts detected (>30% viewport delta)`);
        }
      }
    }

    const passed = !hasHorizontalOverflow && !hasClipping && !hasLayoutShift;

    return {
      viewport,
      dimensions: { width: targetWidth, height: targetHeight },
      passed,
      status: passed ? 'VISUAL_REGRESSION_PASS' : 'VISUAL_REGRESSION_FAILED',
      hasHorizontalOverflow,
      hasClipping,
      hasLayoutShift,
      shiftedElementsCount,
      details: details.length > 0 ? details : ['Layout dimensions, bounding boxes, and overflow bounds within tolerance']
    };
  }

  /**
   * Helper to generate script to capture DOM layout metrics from preview iframe
   */
  public static getCaptureScript(): string {
    return `
      (function() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        const allElements = Array.from(document.querySelectorAll('*'));
        let maxContentWidth = document.documentElement.scrollWidth || width;
        const hasHorizontalScrollbar = maxContentWidth > width;

        const bounds = [];
        for (let i = 0; i < Math.min(allElements.length, 100); i++) {
          const el = allElements[i];
          const rect = el.getBoundingClientRect();
          const isClipped = rect.width <= 0 && rect.height <= 0 && el.children.length > 0;
          const hasOverflow = rect.right > width + 2;

          bounds.push({
            id: el.id || ('el_' + i),
            tag: el.tagName.toLowerCase(),
            className: typeof el.className === 'string' ? el.className.substring(0, 50) : '',
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height,
            isClipped,
            hasOverflow
          });
        }

        return {
          width,
          height,
          totalElementsCount: allElements.length,
          maxContentWidth,
          hasHorizontalScrollbar,
          elementBounds: bounds
        };
      })();
    `;
  }
}
