/**
 * Groq API & AI Multi-Engine Service
 * Server-side CORS-free proksi, 5 ta kalit rotatsiyasi va Gemini zaxira tizimi bilan.
 */
import { GROQ_API_KEYS, GROQ_MODEL, SYSTEM_PROMPT, RENDER_PRODUCTION_URL } from '../data/config';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  keyIndexUsed?: number;
  durationMs?: number;
  engineUsed?: string;
  actionTriggered?: string;
}

export interface ChatResponse {
  content: string;
  keyIndexUsed: number;
  durationMs: number;
  engine: string;
  source: 'proxy_server' | 'render_backend' | 'groq_direct';
}

class GroqService {
  private currentKeyIndex = 0;
  private backendUrl = RENDER_PRODUCTION_URL;
  private useRenderBackend = false;
  private customApiKey = '';

  public setCustomApiKey(key: string) {
    this.customApiKey = key.trim();
  }

  public getCustomApiKey(): string {
    return this.customApiKey;
  }

  public setBackendMode(useRender: boolean, customUrl?: string) {
    this.useRenderBackend = useRender;
    if (customUrl) {
      this.backendUrl = customUrl;
    }
  }

  public getBackendMode() {
    return {
      useRenderBackend: this.useRenderBackend,
      backendUrl: this.backendUrl,
      currentKeyIndex: this.currentKeyIndex,
      totalKeys: GROQ_API_KEYS.length,
      hasCustomKey: !!this.customApiKey,
    };
  }

  /**
   * Xabar yuborish va javob olish
   */
  public async sendMessage(
    prompt: string,
    history: { role: 'user' | 'assistant'; content: string }[] = []
  ): Promise<ChatResponse> {
    const startTime = performance.now();

    // 1. Agar foydalanuvchi Render backendini tanlagan bo'lsa
    if (this.useRenderBackend) {
      try {
        const renderRes = await fetch(`${this.backendUrl}/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt, history }),
        });

        if (renderRes.ok) {
          const data = await renderRes.json();
          const durationMs = Math.round(performance.now() - startTime);
          return {
            content: data.response || data.reply || "Buyruq qabul qilindi, Sir.",
            keyIndexUsed: data.key_index ?? 1,
            durationMs,
            engine: 'Render FastAPI',
            source: 'render_backend',
          };
        }
      } catch (err) {
        console.warn("Render serveriga ulanishda muammo, lokal proksiga o'tilmoqda...", err);
      }
    }

    // 2. Birinchi navbatda `/api/chat` (Server-side proxy - CORS cheklovisiz 5 ta kalit + Gemini fallback!)
    try {
      const serverRes = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          history,
          customApiKey: this.customApiKey || undefined,
        }),
      });

      if (serverRes.ok) {
        const data = await serverRes.json();
        const durationMs = Math.round(performance.now() - startTime);
        return {
          content: data.response,
          keyIndexUsed: data.keyIndexUsed ?? 1,
          durationMs,
          engine: data.engine || `Groq (${GROQ_MODEL})`,
          source: 'proxy_server',
        };
      }
    } catch (err) {
      console.warn("/api/chat ga ulanib bo'lmadi, bevosita brauzer so'roviga o'tilmoqda...", err);
    }

    // 3. Bevosita Groq API (Fallback)
    const keysToTry = this.customApiKey ? [this.customApiKey, ...GROQ_API_KEYS] : GROQ_API_KEYS;
    let attempts = 0;
    const maxAttempts = keysToTry.length;
    let lastError: any = null;

    const formattedMessages = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...history.slice(-4).map((msg) => ({
        role: msg.role === 'user' ? 'user' : 'assistant',
        content: msg.content,
      })),
      { role: 'user', content: prompt },
    ];

    while (attempts < maxAttempts) {
      const activeIndex = this.currentKeyIndex % keysToTry.length;
      const apiKey = keysToTry[activeIndex];

      try {
        const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model: GROQ_MODEL,
            messages: formattedMessages,
            temperature: 0.65,
            max_tokens: 1024,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          const content = data.choices?.[0]?.message?.content || "Buyruq bajarildi, Sir.";
          const durationMs = Math.round(performance.now() - startTime);

          this.currentKeyIndex = (this.currentKeyIndex + 1) % keysToTry.length;

          return {
            content,
            keyIndexUsed: activeIndex + 1,
            durationMs,
            engine: `Groq (${GROQ_MODEL})`,
            source: 'groq_direct',
          };
        }

        this.currentKeyIndex = (this.currentKeyIndex + 1) % keysToTry.length;
        attempts++;
      } catch (err) {
        lastError = err;
        this.currentKeyIndex = (this.currentKeyIndex + 1) % keysToTry.length;
        attempts++;
      }
    }

    throw new Error(
      lastError?.message ||
        "AI serverlaridan javob olinmadi, Sir. Sozlamalardan yangi kalit kiritishingiz yoki Render serverini tanlashingiz mumkin."
    );
  }
}

export const groqService = new GroqService();
