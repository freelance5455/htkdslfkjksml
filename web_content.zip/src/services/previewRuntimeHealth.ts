/**
 * GODEX P4.1 — PreviewRuntimeHealth System
 * 
 * Verifies live browser runtime health, DOM element presence, viewport geometry,
 * and tracks unhandled exceptions to ensure the Google AI Studio Preview is never blank.
 */

export interface RuntimeHealthMetric {
  rootMounted: boolean;
  activeView: string;
  viewportWidth: number;
  viewportHeight: number;
  domElementCount: number;
  canvasAvailable: boolean;
  webGlAvailable: boolean;
  webGpuAvailable: boolean;
  mountedTimestamp: number;
  lastHeartbeat: number;
  errorCount: number;
  lastErrors: string[];
  status: 'HEALTHY' | 'DEGRADED' | 'FAILED';
}

export class PreviewRuntimeHealth {
  private static instance: PreviewRuntimeHealth | null = null;
  private currentMetric: RuntimeHealthMetric;
  private listeners: Set<(m: RuntimeHealthMetric) => void> = new Set();
  private heartbeatTimer: any = null;

  private constructor() {
    const isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';
    this.currentMetric = {
      rootMounted: isBrowser && !!document.getElementById('root'),
      activeView: 'creative-studio',
      viewportWidth: isBrowser ? window.innerWidth : 1280,
      viewportHeight: isBrowser ? window.innerHeight : 800,
      domElementCount: isBrowser ? document.querySelectorAll('*').length : 0,
      canvasAvailable: isBrowser && !!document.createElement('canvas').getContext('2d'),
      webGlAvailable: false,
      webGpuAvailable: false,
      mountedTimestamp: Date.now(),
      lastHeartbeat: Date.now(),
      errorCount: 0,
      lastErrors: [],
      status: 'HEALTHY'
    };

    if (isBrowser) {
      this.initHealthProbing();
    }
  }

  public static getInstance(): PreviewRuntimeHealth {
    if (!PreviewRuntimeHealth.instance) {
      PreviewRuntimeHealth.instance = new PreviewRuntimeHealth();
    }
    return PreviewRuntimeHealth.instance;
  }

  private initHealthProbing(): void {
    if (typeof window === 'undefined') return;

    // Check WebGL
    try {
      const c = document.createElement('canvas');
      const gl = c.getContext('webgl2') || c.getContext('webgl');
      this.currentMetric.webGlAvailable = !!gl;
    } catch {
      this.currentMetric.webGlAvailable = false;
    }

    // Check WebGPU safely
    if ('gpu' in navigator && (navigator as any).gpu) {
      this.currentMetric.webGpuAvailable = true;
    }

    // Window Resize tracking
    window.addEventListener('resize', () => {
      this.currentMetric.viewportWidth = window.innerWidth;
      this.currentMetric.viewportHeight = window.innerHeight;
      this.notify();
    });

    // Periodic Heartbeat
    this.heartbeatTimer = setInterval(() => {
      this.probeHealth();
    }, 2000);

    // Initial probe
    setTimeout(() => this.probeHealth(), 100);
  }

  public probeHealth(): RuntimeHealthMetric {
    if (typeof document !== 'undefined') {
      const root = document.getElementById('root');
      this.currentMetric.rootMounted = !!root && (root.children.length > 0);
      this.currentMetric.domElementCount = document.querySelectorAll('*').length;
      this.currentMetric.viewportWidth = window.innerWidth;
      this.currentMetric.viewportHeight = window.innerHeight;
      this.currentMetric.lastHeartbeat = Date.now();
      
      if (!this.currentMetric.rootMounted || this.currentMetric.domElementCount < 5) {
        this.currentMetric.status = this.currentMetric.errorCount > 0 ? 'FAILED' : 'DEGRADED';
      } else if (this.currentMetric.errorCount > 0) {
        this.currentMetric.status = 'DEGRADED';
      } else {
        this.currentMetric.status = 'HEALTHY';
      }
    }
    this.notify();
    return this.currentMetric;
  }

  public recordError(errorMsg: string): void {
    this.currentMetric.errorCount++;
    this.currentMetric.lastErrors = [errorMsg, ...this.currentMetric.lastErrors].slice(0, 10);
    this.currentMetric.status = 'DEGRADED';
    this.notify();
  }

  public setActiveView(view: string): void {
    this.currentMetric.activeView = view;
    this.notify();
  }

  public getHealth(): RuntimeHealthMetric {
    return { ...this.currentMetric };
  }

  public subscribe(cb: (m: RuntimeHealthMetric) => void): () => void {
    this.listeners.add(cb);
    cb(this.currentMetric);
    return () => {
      this.listeners.delete(cb);
    };
  }

  private notify(): void {
    for (const cb of this.listeners) {
      try {
        cb(this.currentMetric);
      } catch (err) {
        console.error('Error in health listener:', err);
      }
    }
  }
}
