import { SavedBookRecord, ReadingProgressRecord, EpubHighlight } from '../types/epub';

const DB_NAME = 'PruebaEpubStorage_v1';
const DB_VERSION = 1;

const STORES = {
  BOOKS: 'epub_books',
  PROGRESS: 'reading_progress',
  HIGHLIGHTS: 'epub_highlights',
};

class EpubIndexedDBService {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private openDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        reject(new Error('IndexedDB no está disponible en este entorno.'));
        return;
      }

      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Books Store
        if (!db.objectStoreNames.contains(STORES.BOOKS)) {
          db.createObjectStore(STORES.BOOKS, { keyPath: 'id' });
        }

        // Progress Store
        if (!db.objectStoreNames.contains(STORES.PROGRESS)) {
          db.createObjectStore(STORES.PROGRESS, { keyPath: 'bookId' });
        }

        // Highlights Store
        if (!db.objectStoreNames.contains(STORES.HIGHLIGHTS)) {
          const hlStore = db.createObjectStore(STORES.HIGHLIGHTS, { keyPath: 'id' });
          hlStore.createIndex('bookId', 'bookId', { unique: false });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        reject(request.error || new Error('Error al abrir base de datos IndexedDB'));
      };
    });

    return this.dbPromise;
  }

  // --- Books ---
  async saveBook(book: SavedBookRecord): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BOOKS, 'readwrite');
      const store = tx.objectStore(STORES.BOOKS);
      const req = store.put(book);
      req.onsuccess = () => {
        // Also save active book id in localStorage for instant retrieval on startup
        try {
          localStorage.setItem('prueba_epub_active_book_id', book.id);
        } catch {
          // ignore quota issues
        }
        resolve();
      };
      req.onerror = () => reject(req.error);
    });
  }

  async getBook(id: string): Promise<SavedBookRecord | null> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BOOKS, 'readonly');
      const store = tx.objectStore(STORES.BOOKS);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getActiveBook(): Promise<SavedBookRecord | null> {
    try {
      const activeId = localStorage.getItem('prueba_epub_active_book_id');
      if (activeId) {
        const book = await this.getBook(activeId);
        if (book) return book;
      }
    } catch {
      // fallback
    }

    // Otherwise get the first available book in store
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BOOKS, 'readonly');
      const store = tx.objectStore(STORES.BOOKS);
      const req = store.openCursor();
      req.onsuccess = (e) => {
        const cursor = (e.target as IDBRequest<IDBCursorWithValue>).result;
        if (cursor) {
          resolve(cursor.value);
        } else {
          resolve(null);
        }
      };
      req.onerror = () => reject(req.error);
    });
  }

  async deleteBook(id: string): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction([STORES.BOOKS, STORES.PROGRESS, STORES.HIGHLIGHTS], 'readwrite');
      tx.objectStore(STORES.BOOKS).delete(id);
      tx.objectStore(STORES.PROGRESS).delete(id);

      // delete highlights of this book
      const hlStore = tx.objectStore(STORES.HIGHLIGHTS);
      const index = hlStore.index('bookId');
      const req = index.openCursor(IDBKeyRange.only(id));
      req.onsuccess = (e) => {
        const cursor = (e.target as IDBRequest<IDBCursorWithValue>).result;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        }
      };

      tx.oncomplete = () => {
        try {
          if (localStorage.getItem('prueba_epub_active_book_id') === id) {
            localStorage.removeItem('prueba_epub_active_book_id');
          }
        } catch {}
        resolve();
      };
      tx.onerror = () => reject(tx.error);
    });
  }

  // --- Reading Progress ---
  async saveProgress(progress: ReadingProgressRecord): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.PROGRESS, 'readwrite');
      const store = tx.objectStore(STORES.PROGRESS);
      const req = store.put(progress);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getProgress(bookId: string): Promise<ReadingProgressRecord | null> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.PROGRESS, 'readonly');
      const store = tx.objectStore(STORES.PROGRESS);
      const req = store.get(bookId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  // --- Highlights ---
  async saveHighlight(highlight: EpubHighlight): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.HIGHLIGHTS, 'readwrite');
      const store = tx.objectStore(STORES.HIGHLIGHTS);
      const req = store.put(highlight);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getHighlights(bookId: string): Promise<EpubHighlight[]> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.HIGHLIGHTS, 'readonly');
      const store = tx.objectStore(STORES.HIGHLIGHTS);
      const index = store.index('bookId');
      const req = index.getAll(IDBKeyRange.only(bookId));
      req.onsuccess = () => {
        const results = req.result || [];
        results.sort((a, b) => a.createdAt - b.createdAt);
        resolve(results);
      };
      req.onerror = () => reject(req.error);
    });
  }

  async deleteHighlight(id: string): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.HIGHLIGHTS, 'readwrite');
      const store = tx.objectStore(STORES.HIGHLIGHTS);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }
}

export const epubStorage = new EpubIndexedDBService();
