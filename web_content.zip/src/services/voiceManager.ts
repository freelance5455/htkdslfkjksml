/**
 * Spoken English Voice Reaction System.
 * Uses Web Speech Synthesis with natural inflection, strict cooldowns, random phrasing,
 * and no audio overlap.
 */

export type VoiceEvent =
  | 'good_move'
  | 'combo'
  | 'achievement'
  | 'three_stars'
  | 'level_complete'
  | 'failure';

class VoiceManager {
  private lastSpokenTime: number = 0;
  private readonly cooldownMs: number = 3200; // Minimum interval between speech reactions
  private isSpeaking: boolean = false;
  private lastPhrase: string = '';

  private readonly phrases: Record<VoiceEvent, string[]> = {
    good_move: ['Nice!', 'Good move!', 'Great!'],
    combo: ['Nice combo!', 'Great combo!', 'Awesome combo!'],
    achievement: ['Amazing!', 'Incredible!', 'Fantastic!'],
    three_stars: ['Perfect clear!', 'Awesome!'],
    level_complete: ['Level complete!', 'Well done!'],
    failure: ['Try again!', 'Almost!'],
  };

  public speak(event: VoiceEvent, enabled: boolean) {
    if (!enabled) return;
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    const now = Date.now();
    // Do not speak if cooldown hasn't expired or already speaking
    if (now - this.lastSpokenTime < this.cooldownMs || this.isSpeaking) {
      return;
    }

    try {
      const candidates = this.phrases[event];
      if (!candidates || candidates.length === 0) return;

      // Pick random different phrase
      let available = candidates.filter((p) => p !== this.lastPhrase);
      if (available.length === 0) available = candidates;
      const phrase = available[Math.floor(Math.random() * available.length)];

      window.speechSynthesis.cancel(); // Cancel any existing speech

      const utterance = new SpeechSynthesisUtterance(phrase);
      utterance.rate = 1.15; // Slightly upbeat, energetic
      utterance.pitch = 1.2; // Friendly, warm tone
      utterance.lang = 'en-US';

      this.isSpeaking = true;
      this.lastSpokenTime = now;
      this.lastPhrase = phrase;

      utterance.onend = () => {
        this.isSpeaking = false;
      };
      utterance.onerror = () => {
        this.isSpeaking = false;
      };

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      this.isSpeaking = false;
    }
  }
}

export const voiceManager = new VoiceManager();
