/**
 * Real Text-To-Speech engine utilizing the Web Speech API (speechSynthesis)
 * with dedicated support for Hindi (hi-IN) voices and video ducking.
 */

export interface TtsVoiceInfo {
  name: string;
  lang: string;
  default: boolean;
  isHindi: boolean;
}

class HindiTtsService {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSupported: boolean = false;
  private onStateChangeCallback?: (isSpeaking: boolean, text: string) => void;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.isSupported = true;
    }
  }

  public checkSupport(): boolean {
    return this.isSupported;
  }

  public getAvailableVoices(): Promise<TtsVoiceInfo[]> {
    return new Promise((resolve) => {
      if (!this.synth) {
        resolve([]);
        return;
      }

      const fetchVoices = () => {
        const voices = this.synth!.getVoices();
        const formatted: TtsVoiceInfo[] = voices.map((v) => {
          const isHindi = v.lang.toLowerCase().startsWith('hi') || v.name.toLowerCase().includes('hindi');
          return {
            name: v.name,
            lang: v.lang,
            default: v.default,
            isHindi,
          };
        });

        // Sort so Hindi voices come first
        formatted.sort((a, b) => {
          if (a.isHindi && !b.isHindi) return -1;
          if (!a.isHindi && b.isHindi) return 1;
          return a.name.localeCompare(b.name);
        });

        resolve(formatted);
      };

      const initialVoices = this.synth.getVoices();
      if (initialVoices.length > 0) {
        fetchVoices();
      } else {
        this.synth.onvoiceschanged = () => {
          fetchVoices();
        };
        // fallback timer if voiceschanged does not fire
        setTimeout(fetchVoices, 500);
      }
    });
  }

  public setOnStateChange(cb: (isSpeaking: boolean, text: string) => void) {
    this.onStateChangeCallback = cb;
  }

  public speakHindiText(
    text: string,
    options: {
      rate?: number;
      pitch?: number;
      voiceName?: string;
      onEnd?: () => void;
      onError?: (err: any) => void;
    } = {}
  ): void {
    if (!this.synth) {
      options.onError?.(new Error('SpeechSynthesis not supported on this browser/device'));
      return;
    }

    // Cancel any previous speech
    this.stop();

    if (!text || text.trim().length === 0) {
      options.onEnd?.();
      return;
    }

    try {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'hi-IN';
      utterance.rate = options.rate ?? 1.0;
      utterance.pitch = options.pitch ?? 1.0;

      // Find selected voice or best available Hindi voice
      const voices = this.synth.getVoices();
      if (options.voiceName) {
        const matching = voices.find((v) => v.name === options.voiceName);
        if (matching) utterance.voice = matching;
      }

      if (!utterance.voice) {
        // Look for any Hindi voice
        const hindiVoice = voices.find(
          (v) => v.lang.toLowerCase().startsWith('hi') || v.name.toLowerCase().includes('hindi')
        );
        if (hindiVoice) {
          utterance.voice = hindiVoice;
        }
      }

      utterance.onstart = () => {
        this.onStateChangeCallback?.(true, text);
      };

      utterance.onend = () => {
        this.currentUtterance = null;
        this.onStateChangeCallback?.(false, '');
        options.onEnd?.();
      };

      utterance.onerror = (e) => {
        this.currentUtterance = null;
        this.onStateChangeCallback?.(false, '');
        // Ignore "interrupted" or "canceled" errors
        if (e.error !== 'interrupted' && e.error !== 'canceled') {
          options.onError?.(e);
        }
      };

      this.currentUtterance = utterance;
      this.synth.speak(utterance);
    } catch (err) {
      console.error('Speech synthesis execution failed:', err);
      this.onStateChangeCallback?.(false, '');
      options.onError?.(err);
    }
  }

  public stop(): void {
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch (e) {
        // ignore
      }
      this.currentUtterance = null;
      this.onStateChangeCallback?.(false, '');
    }
  }

  public pause(): void {
    if (this.synth && this.synth.speaking) {
      this.synth.pause();
    }
  }

  public resume(): void {
    if (this.synth && this.synth.paused) {
      this.synth.resume();
    }
  }
}

export const hindiTtsService = new HindiTtsService();
