/**
 * AdMob-Ready Advertising Architecture.
 * Encapsulates App Open, Interstitial, Rewarded Video, and Banner ad workflows
 * with strict user-friendly frequency caps, cooldowns, and standard Google AdMob test IDs.
 *
 * NOTE: Replace test IDs with your production AdMob Unit IDs before store release.
 */

export interface AdReward {
  type: 'coins' | 'hint' | 'undo' | 'time_extension';
  amount: number;
}

export type AdType = 'app_open' | 'interstitial' | 'rewarded';
export type AdCallback = (rewardGranted: boolean, reward?: AdReward) => void;

class AdManager {
  // Production AdMob Unit ID slots (defaults to official Google test unit IDs)
  public readonly config = {
    appOpenUnitId: 'ca-app-pub-3940256099942544/9257395921',      // Google test App Open
    interstitialUnitId: 'ca-app-pub-3940256099942544/1033173712', // Google test Interstitial
    rewardedUnitId: 'ca-app-pub-3940256099942544/5224354917',     // Google test Rewarded Video
    bannerUnitId: 'ca-app-pub-3940256099942544/6300978111',       // Google test Banner (320x50 standard)
    
    interstitialCooldownSeconds: 35, // Minimum 35 seconds cooldown between interstitials
    interstitialLevelInterval: 2,   // Show interstitial at most once every 2 levels
    tutorialExemptLevels: 2,        // No interstitials during tutorial levels 1-2
  };

  private lastInterstitialTimestamp: number = 0;
  private levelsCompletedSinceLastAd: number = 0;
  private isAdShowing: boolean = false;
  private pendingReward: AdReward | null = null;
  private currentCallback: AdCallback | null = null;
  private onAdStateChangeListeners: ((isShowing: boolean, adType: AdType | null) => void)[] = [];
  private hasShownInitialAppOpen: boolean = false;

  public subscribe(listener: (isShowing: boolean, adType: AdType | null) => void) {
    this.onAdStateChangeListeners.push(listener);
    return () => {
      this.onAdStateChangeListeners = this.onAdStateChangeListeners.filter((l) => l !== listener);
    };
  }

  private notify(isShowing: boolean, adType: AdType | null) {
    this.isAdShowing = isShowing;
    this.onAdStateChangeListeners.forEach((l) => l(isShowing, adType));
  }

  /**
   * App Open Ad: Shown when app is first opened or resumed appropriately.
   * If ad is not ready, it continues immediately without waiting.
   */
  public showAppOpenAd(onDismiss?: () => void) {
    // If already showing an ad, ignore
    if (this.isAdShowing) {
      if (onDismiss) onDismiss();
      return;
    }

    this.hasShownInitialAppOpen = true;
    this.currentCallback = () => {
      if (onDismiss) onDismiss();
    };
    this.notify(true, 'app_open');
  }

  public hasAppOpenShown(): boolean {
    return this.hasShownInitialAppOpen;
  }

  /**
   * Level Complete Interstitial: Evaluates whether an interstitial ad should trigger
   * after completing a level with cooldown & interval rules.
   * Does NOT interrupt actual gameplay.
   */
  public onLevelCompleted(levelNumber: number, onFinished: () => void) {
    // Exempt first tutorial levels
    if (levelNumber <= this.config.tutorialExemptLevels) {
      onFinished();
      return;
    }

    this.levelsCompletedSinceLastAd++;
    const now = Date.now();
    const elapsedSeconds = (now - this.lastInterstitialTimestamp) / 1000;

    const cooldownMet = elapsedSeconds >= this.config.interstitialCooldownSeconds;
    const intervalMet = this.levelsCompletedSinceLastAd >= this.config.interstitialLevelInterval;

    if (cooldownMet && intervalMet && !this.isAdShowing) {
      this.levelsCompletedSinceLastAd = 0;
      this.lastInterstitialTimestamp = now;
      this.showInterstitial(() => {
        onFinished();
      });
    } else {
      onFinished();
    }
  }

  /**
   * Directly triggers an interstitial ad presentation.
   */
  public showInterstitial(onDismiss: () => void) {
    if (this.isAdShowing) {
      onDismiss();
      return;
    }

    this.currentCallback = () => {
      onDismiss();
    };
    this.notify(true, 'interstitial');
  }

  /**
   * Presents an optional Rewarded Video ad for Coins, Extra Hint, Extra Undo, or Time Extension.
   * Reward is granted ONLY after the video completes successfully.
   */
  public showRewardedAd(reward: AdReward, callback: AdCallback) {
    if (this.isAdShowing) {
      callback(false);
      return;
    }

    this.pendingReward = reward;
    this.currentCallback = callback;
    this.notify(true, 'rewarded');
  }

  /**
   * Called by the Ad Modal view when the ad finishes or is dismissed.
   */
  public completeAd(success: boolean) {
    const reward = this.pendingReward;
    const cb = this.currentCallback;
    
    this.pendingReward = null;
    this.currentCallback = null;
    this.notify(false, null);

    if (cb) {
      cb(success, success && reward ? reward : undefined);
    }
  }

  public completeRewardedAd(success: boolean) {
    this.completeAd(success);
  }

  public isBusy(): boolean {
    return this.isAdShowing;
  }

  public getPendingReward(): AdReward | null {
    return this.pendingReward;
  }
}

export const adManager = new AdManager();
