// 📡 SERVICIO DE AUDIO Y NOTIFICACIONES EN SEGUNDO PLANO (SONÓ RADIO)
// Permite que las transmisiones de voz se escuchen y notifiquen incluso con la pantalla apagada o fuera del navegador.

class BackgroundAudioService {
  private audioCtx: AudioContext | null = null;
  private isKeepAliveRunning: boolean = false;
  private silentAudioElement: HTMLAudioElement | null = null;
  private wakeLock: any = null;
  private backgroundEnabled: boolean = true;
  private voiceAnnounceEnabled: boolean = true;

  constructor() {
    if (typeof window !== 'undefined') {
      const savedBg = localStorage.getItem('sono_bg_audio_enabled');
      if (savedBg !== null) {
        this.backgroundEnabled = savedBg !== 'false';
      }
      const savedVoice = localStorage.getItem('sono_voice_announce_enabled');
      if (savedVoice !== null) {
        this.voiceAnnounceEnabled = savedVoice !== 'false';
      }
    }
  }

  // 🔓 Inicializar y desbloquear el contexto de audio mediante interacción del usuario
  public async initAndUnlockAudio(): Promise<AudioContext | null> {
    if (typeof window === 'undefined') return null;

    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!this.audioCtx && AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }

      if (this.audioCtx && this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }

      // Iniciar el loop de audio silencioso en segundo plano para evitar suspensión del navegador
      if (this.backgroundEnabled && !this.isKeepAliveRunning) {
        this.startSilentKeepAlive();
      }

      // Activar WakeLock si está disponible
      this.requestWakeLock();

      return this.audioCtx;
    } catch (err) {
      console.warn("Aviso al inicializar AudioContext:", err);
      return null;
    }
  }

  // 🔊 Bucle silencioso que previene que Android / iOS / Chrome suspendan el socket y el audio
  public startSilentKeepAlive() {
    if (this.isKeepAliveRunning || typeof window === 'undefined') return;

    try {
      // 1. Crear un micro buffer silencioso continuo con AudioContext
      if (this.audioCtx && this.audioCtx.state === 'running') {
        const buffer = this.audioCtx.createBuffer(1, this.audioCtx.sampleRate * 2, this.audioCtx.sampleRate);
        const source = this.audioCtx.createBufferSource();
        source.buffer = buffer;
        source.loop = true;
        
        const gain = this.audioCtx.createGain();
        gain.gain.value = 0.00001; // Prácticamente inaudible pero mantiene el hilo de audio abierto
        source.connect(gain);
        gain.connect(this.audioCtx.destination);
        source.start(0);
      }

      // 2. Elemento HTMLAudio con data URI silenciosa para navegadores móviles
      if (!this.silentAudioElement) {
        const silentWavDataUri = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA";
        const audio = new Audio(silentWavDataUri);
        audio.loop = true;
        audio.volume = 0.01;
        audio.play().catch(() => {
          // Si el autoplay directo falla, se reintentará en el siguiente toque
        });
        this.silentAudioElement = audio;
      }

      this.isKeepAliveRunning = true;
      console.log("🔊 Modo transmisión en segundo plano activado con éxito.");
    } catch (e) {
      console.warn("Keep-alive audio warning:", e);
    }
  }

  // 💤 Solicitar WakeLock para evitar que la pantalla o el dispositivo se duerma
  private async requestWakeLock() {
    if (typeof navigator !== 'undefined' && 'wakeLock' in navigator && (navigator as any).wakeLock) {
      try {
        this.wakeLock = await (navigator as any).wakeLock.request('screen');
        this.wakeLock.addEventListener('release', () => {
          this.wakeLock = null;
        });
      } catch (err) {
        // Puede fallar si la pestaña no está visible en ese momento
      }
    }
  }

  // 🔔 Emitir Notificación del Sistema (escritorio y móvil vía ServiceWorker)
  public async sendBackgroundNotification(title: string, body: string, speakerName?: string) {
    if (typeof window === 'undefined') return;

    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        // Si hay Service Worker activo, usar showNotification (más confiable con pantalla apagada)
        if ('serviceWorker' in navigator) {
          const reg = await navigator.serviceWorker.ready;
          if (reg && reg.showNotification) {
            reg.showNotification(title, {
              body: body,
              icon: '/favicon.ico',
              badge: '/favicon.ico',
              tag: 'sono-rx-' + Date.now(),
              vibrate: [250, 100, 250, 100, 300],
              requireInteraction: true,
              data: { speakerName, timestamp: Date.now() },
              actions: [
                { action: 'open', title: '📻 Abrir Radio Walkie-Talkie' }
              ]
            } as any);
            return;
          }
        }

        // Fallback a Notification API estándar
        new Notification(title, {
          body: body,
          icon: '/favicon.ico',
          vibrate: [200, 100, 200]
        } as any);
      } catch (err) {
        console.warn("Error mostrando notificación de sistema:", err);
      }
    }
  }

  // 🗣️ Síntesis de voz (Leer el mensaje en voz alta si el usuario está fuera de la web)
  public speakVoiceMessage(speaker: string, transcript?: string) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (!this.voiceAnnounceEnabled) return;

    try {
      window.speechSynthesis.cancel(); // Detener cualquier mensaje previo
      const cleanTranscript = (transcript || '').trim();
      const textToSpeak = cleanTranscript && !cleanTranscript.includes('(Audio')
        ? `Transmisión de ${speaker}: ${cleanTranscript}`
        : `Mensaje de voz de ${speaker}`;

      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.lang = 'es-MX';
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;

      // Buscar voz en español si está disponible
      const voices = window.speechSynthesis.getVoices();
      const spanishVoice = voices.find(v => v.lang.startsWith('es'));
      if (spanishVoice) {
        utterance.voice = spanishVoice;
      }

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("Speech synthesis error:", e);
    }
  }

  // 📻 REPRODUCCIÓN PRINCIPAL: Toca el audio recibido garantizando sonido en segundo plano
  public async playIncomingAudio(
    audioBlob: Blob,
    speaker: string,
    transcript: string = '',
    channelName: string = 'Canal'
  ): Promise<void> {
    const isTabHidden = typeof document !== 'undefined' && document.hidden;
    console.log(`[BackgroundAudio] Nueva transmisión de ${speaker}. Pestaña oculta: ${isTabHidden}`);

    // 1. Notificación al sistema con vibración
    const notificationTitle = `🎙️ ${speaker} · ${channelName}`;
    const notificationBody = transcript && !transcript.includes('(Audio') 
      ? transcript 
      : 'Transmitiendo mensaje de voz en vivo...';

    if (isTabHidden) {
      this.sendBackgroundNotification(notificationTitle, notificationBody, speaker);
    }

    // 2. Reproducir el audio directamente
    try {
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      audio.volume = 1.0;

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        await playPromise.catch(async (playErr) => {
          console.warn("Audio element play error, intentando vía WebAudio:", playErr);
          // Intentar decodificar con AudioContext si el elemento <audio> fue bloqueado
          if (this.audioCtx) {
            try {
              if (this.audioCtx.state === 'suspended') {
                await this.audioCtx.resume();
              }
              const arrayBuffer = await audioBlob.arrayBuffer();
              const audioBuffer = await this.audioCtx.decodeAudioData(arrayBuffer);
              const source = this.audioCtx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(this.audioCtx.destination);
              source.start(0);
            } catch (ctxErr) {
              console.warn("WebAudio fallback falló:", ctxErr);
            }
          }
        });
      }

      // 3. Si la pestaña está oculta y tiene transcripción, sintetizar voz de respaldo
      if (isTabHidden && this.voiceAnnounceEnabled && transcript && !transcript.includes('(Audio')) {
        setTimeout(() => {
          this.speakVoiceMessage(speaker, transcript);
        }, 1500);
      }

    } catch (err) {
      console.error("Error reproduciendo audio recibido:", err);
      if (isTabHidden) {
        this.speakVoiceMessage(speaker, transcript);
      }
    }
  }

  // Getters & Setters de configuración
  public isBackgroundEnabled(): boolean {
    return this.backgroundEnabled;
  }

  public setBackgroundEnabled(enabled: boolean) {
    this.backgroundEnabled = enabled;
    if (typeof window !== 'undefined') {
      localStorage.setItem('sono_bg_audio_enabled', enabled ? 'true' : 'false');
    }
    if (enabled) {
      this.startSilentKeepAlive();
    }
  }

  public isVoiceAnnounceEnabled(): boolean {
    return this.voiceAnnounceEnabled;
  }

  public setVoiceAnnounceEnabled(enabled: boolean) {
    this.voiceAnnounceEnabled = enabled;
    if (typeof window !== 'undefined') {
      localStorage.setItem('sono_voice_announce_enabled', enabled ? 'true' : 'false');
    }
  }
}

export const backgroundAudioService = new BackgroundAudioService();
