import { Mailbox, EmailMessage, PhoneNumber, SmsMessage, CreditTransaction, AbuseReport, UserAccount, UserSessionLog } from '../types/index.ts';
import { detectOtpAndLinks } from './otpDetector.ts';

const STORAGE_KEY = 'tempbox_state_v2';

export const INITIAL_DEMO_USERS: UserSessionLog[] = [
  {
    id: 'sess_live_1',
    deviceId: 'dev_8f29c1',
    userName: 'User #8821',
    country: 'India',
    flag: '🇮🇳',
    ip: '103.212.14.88 (Mumbai)',
    currentTab: 'numbers',
    activeNumber: '+91 98765 43210',
    status: 'ONLINE',
    joinedAt: new Date(Date.now() - 4 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 10 * 1000).toISOString(),
    durationMinutes: 4,
  },
  {
    id: 'sess_live_2',
    deviceId: 'dev_3a91b4',
    userName: 'User #3109',
    country: 'United States',
    flag: '🇺🇸',
    ip: '67.180.22.10 (California)',
    currentTab: 'email',
    activeMailbox: 'alex.dev@maxxspace.com',
    status: 'ONLINE',
    joinedAt: new Date(Date.now() - 12 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 25 * 1000).toISOString(),
    durationMinutes: 12,
  },
  {
    id: 'sess_live_3',
    deviceId: 'dev_e7104a',
    userName: 'User #9204',
    country: 'United Kingdom',
    flag: '🇬🇧',
    ip: '82.165.197.1 (London)',
    currentTab: 'numbers',
    activeNumber: '+44 7911 123456',
    status: 'ONLINE',
    joinedAt: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 5 * 1000).toISOString(),
    durationMinutes: 2,
  },
  {
    id: 'sess_live_4',
    deviceId: 'dev_bc8231',
    userName: 'User #4412',
    country: 'Germany',
    flag: '🇩🇪',
    ip: '178.63.49.20 (Frankfurt)',
    currentTab: 'email',
    activeMailbox: 'tech.test@sharklasers.com',
    status: 'ONLINE',
    joinedAt: new Date(Date.now() - 18 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 40 * 1000).toISOString(),
    durationMinutes: 18,
  },
  {
    id: 'sess_idle_1',
    deviceId: 'dev_77d102',
    userName: 'User #1190',
    country: 'Canada',
    flag: '🇨🇦',
    ip: '142.250.80.46 (Toronto)',
    currentTab: 'email',
    activeMailbox: 'quick.temp@grr.la',
    status: 'IDLE',
    joinedAt: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 8 * 60 * 1000).toISOString(),
    durationMinutes: 35,
  },
  {
    id: 'sess_idle_2',
    deviceId: 'dev_90aa21',
    userName: 'User #6021',
    country: 'France',
    flag: '🇫🇷',
    ip: '51.15.22.9 (Paris)',
    currentTab: 'numbers',
    activeNumber: '+33 6 12 34 56 78',
    status: 'IDLE',
    joinedAt: new Date(Date.now() - 42 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    durationMinutes: 42,
  },
  {
    id: 'sess_departed_1',
    deviceId: 'dev_110a39',
    userName: 'User #2019',
    country: 'India',
    flag: '🇮🇳',
    ip: '49.36.120.14 (Delhi)',
    currentTab: 'numbers',
    activeNumber: '+91 94451 28903',
    status: 'DEPARTED',
    joinedAt: new Date(Date.now() - 50 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 22 * 60 * 1000).toISOString(),
    departedAt: new Date(Date.now() - 20 * 60 * 1000).toISOString(),
    durationMinutes: 30,
    exitReason: 'WhatsApp OTP code received & verified successfully',
  },
  {
    id: 'sess_departed_2',
    deviceId: 'dev_68f001',
    userName: 'User #5812',
    country: 'United States',
    flag: '🇺🇸',
    ip: '104.28.19.40 (New York)',
    currentTab: 'email',
    activeMailbox: 'signup.trial@guerrillamail.com',
    status: 'DEPARTED',
    joinedAt: new Date(Date.now() - 75 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
    departedAt: new Date(Date.now() - 44 * 60 * 1000).toISOString(),
    durationMinutes: 31,
    exitReason: 'Email activation link clicked, closed tab',
  },
  {
    id: 'sess_departed_3',
    deviceId: 'dev_99c312',
    userName: 'User #7701',
    country: 'Australia',
    flag: '🇦🇺',
    ip: '139.130.4.5 (Sydney)',
    currentTab: 'numbers',
    activeNumber: '+61 412 345 678',
    status: 'DEPARTED',
    joinedAt: new Date(Date.now() - 110 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 85 * 60 * 1000).toISOString(),
    departedAt: new Date(Date.now() - 84 * 60 * 1000).toISOString(),
    durationMinutes: 26,
    exitReason: 'Google G-code copied, task completed',
  },
  {
    id: 'sess_departed_4',
    deviceId: 'dev_41b988',
    userName: 'User #4329',
    country: 'Brazil',
    flag: '🇧🇷',
    ip: '177.18.200.12 (São Paulo)',
    currentTab: 'email',
    status: 'DEPARTED',
    joinedAt: new Date(Date.now() - 160 * 60 * 1000).toISOString(),
    lastPingAt: new Date(Date.now() - 150 * 60 * 1000).toISOString(),
    departedAt: new Date(Date.now() - 149 * 60 * 1000).toISOString(),
    durationMinutes: 11,
    exitReason: 'User bounced after browsing domains',
  },
];

export const DOMAINS = ['maxxspace.com', 'guerrillamailblock.com', 'guerrillamail.com', 'sharklasers.com', 'grr.la'];

export const AVAILABLE_PHONE_CATALOG = [
  { number: '+1 (415) 802-3921', countryCode: 'US', countryName: 'United States', flag: '🇺🇸', cost: 10, friendlyLocation: 'San Francisco, CA', carrier: 'T-Mobile 5G' },
  { number: '+1 (646) 558-9014', countryCode: 'US', countryName: 'United States', flag: '🇺🇸', cost: 10, friendlyLocation: 'New York, NY', carrier: 'Verizon LTE' },
  { number: '+1 (312) 994-1182', countryCode: 'US', countryName: 'United States', flag: '🇺🇸', cost: 10, friendlyLocation: 'Chicago, IL', carrier: 'AT&T Mobility' },
  { number: '+1 (206) 745-9201', countryCode: 'US', countryName: 'United States', flag: '🇺🇸', cost: 10, friendlyLocation: 'Seattle, WA', carrier: 'T-Mobile 5G' },
  { number: '+44 7911 123456', countryCode: 'GB', countryName: 'United Kingdom', flag: '🇬🇧', cost: 15, friendlyLocation: 'London, UK Mobile', carrier: 'Vodafone UK' },
  { number: '+44 7700 900582', countryCode: 'GB', countryName: 'United Kingdom', flag: '🇬🇧', cost: 15, friendlyLocation: 'Manchester, UK', carrier: 'EE Mobile' },
  { number: '+44 7890 321456', countryCode: 'GB', countryName: 'United Kingdom', flag: '🇬🇧', cost: 15, friendlyLocation: 'Birmingham, UK', carrier: 'O2 Mobile' },
  { number: '+1 (416) 779-4321', countryCode: 'CA', countryName: 'Canada', flag: '🇨🇦', cost: 12, friendlyLocation: 'Toronto, ON', carrier: 'Rogers Wireless' },
  { number: '+1 (604) 829-1055', countryCode: 'CA', countryName: 'Canada', flag: '🇨🇦', cost: 12, friendlyLocation: 'Vancouver, BC', carrier: 'Telus Mobility' },
  { number: '+49 151 23456789', countryCode: 'DE', countryName: 'Germany', flag: '🇩🇪', cost: 18, friendlyLocation: 'Berlin Mobile', carrier: 'Telekom DE' },
  { number: '+49 176 89214300', countryCode: 'DE', countryName: 'Germany', flag: '🇩🇪', cost: 18, friendlyLocation: 'Munich Mobile', carrier: 'O2 DE' },
  { number: '+33 6 12 34 56 78', countryCode: 'FR', countryName: 'France', flag: '🇫🇷', cost: 18, friendlyLocation: 'Paris Mobile', carrier: 'Orange France' },
  { number: '+33 7 50 89 21 04', countryCode: 'FR', countryName: 'France', flag: '🇫🇷', cost: 18, friendlyLocation: 'Lyon Mobile', carrier: 'SFR' },
  { number: '+91 98765 43210', countryCode: 'IN', countryName: 'India', flag: '🇮🇳', cost: 15, friendlyLocation: 'Mumbai Telecom', carrier: 'Jio 5G' },
  { number: '+91 94451 28903', countryCode: 'IN', countryName: 'India', flag: '🇮🇳', cost: 15, friendlyLocation: 'Delhi NCR', carrier: 'Airtel 5G' },
  { number: '+91 88204 91238', countryCode: 'IN', countryName: 'India', flag: '🇮🇳', cost: 15, friendlyLocation: 'Bengaluru Tech Hub', carrier: 'Jio 5G' },
  { number: '+61 412 345 678', countryCode: 'AU', countryName: 'Australia', flag: '🇦🇺', cost: 15, friendlyLocation: 'Sydney Mobile', carrier: 'Telstra' },
  { number: '+61 488 920 145', countryCode: 'AU', countryName: 'Australia', flag: '🇦🇺', cost: 15, friendlyLocation: 'Melbourne Mobile', carrier: 'Optus' },
];

function getInitialState() {
  try {
    localStorage.removeItem('tempbox_state_v1');
  } catch {}

  const deviceId = 'dev_' + Math.random().toString(36).substring(2, 10);
  const initialUser: UserAccount = {
    id: 'user_1',
    email: null,
    role: 'USER',
    isGuest: true,
    credits: 1000,
    isBanned: false,
    deviceId,
  };

  const initialMailboxId = 'mb_primary';
  const initialMailbox: Mailbox = {
    id: initialMailboxId,
    address: 'loading@maxxspace.com',
    username: 'loading',
    domain: 'maxxspace.com',
    lifetimeTier: '24h',
    expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date().toISOString(),
    isCustom: false,
    unreadCount: 0,
  };

  const initialNumber: PhoneNumber = {
    id: 'num_1',
    number: '+1 (415) 802-3921',
    countryCode: 'US',
    countryName: 'United States',
    flag: '🇺🇸',
    provider: 'mock',
    status: 'ACTIVE',
    rentedAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    creditsCost: 0,
    receivedSmsQty: 1,
    refundIssued: false,
  };

  const initialSms: SmsMessage = {
    id: 'sms_welcome_1',
    phoneNumberId: 'num_1',
    fromNumber: '+1 (800) 555-0199',
    senderName: 'WhatsApp',
    text: 'Your WhatsApp security code is 749-102. Do not share this code with anyone.',
    extractedOtp: '749-102',
    receivedAt: new Date(Date.now() - 30 * 1000).toISOString(),
  };

  const initialTransactions: CreditTransaction[] = [
    {
      id: 'tx_bonus',
      amount: 1000,
      type: 'BONUS',
      description: 'Welcome bonus: Free Temp Email & SMS verification codes',
      createdAt: new Date().toISOString(),
    },
  ];

  return {
    user: initialUser,
    mailboxes: [initialMailbox],
    activeMailboxId: initialMailboxId,
    messages: [] as EmailMessage[],
    phoneNumbers: [initialNumber],
    smsMessages: [initialSms],
    transactions: initialTransactions,
    abuseReports: [] as AbuseReport[],
    sessionLogs: INITIAL_DEMO_USERS,
    totalVisitorsCount: 1542,
  };
}

export class TempBoxStore {
  private static loadState() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.user || typeof parsed.user.credits !== 'number' || parsed.user.credits < 50) {
          parsed.user = { ...(parsed.user || {}), credits: 1000 };
        }
        if (!parsed.sessionLogs || parsed.sessionLogs.length === 0) {
          parsed.sessionLogs = [...INITIAL_DEMO_USERS];
        }
        if (!parsed.totalVisitorsCount) {
          parsed.totalVisitorsCount = 1542;
        }
        if (!parsed.phoneNumbers || parsed.phoneNumbers.length === 0) {
          const defaultNum: PhoneNumber = {
            id: 'num_active_1',
            number: '+1 (415) 802-3921',
            countryCode: 'US',
            countryName: 'United States',
            flag: '🇺🇸',
            provider: 'mock',
            status: 'ACTIVE',
            rentedAt: new Date().toISOString(),
            expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
            creditsCost: 0,
            receivedSmsQty: 1,
            refundIssued: false,
          };
          parsed.phoneNumbers = [defaultNum];
        }
        // Self-heal: ensure active numbers are not expired
        parsed.phoneNumbers.forEach((p: PhoneNumber) => {
          if (new Date(p.expiresAt).getTime() <= Date.now()) {
            p.expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
            p.status = 'ACTIVE';
          }
        });
        if (!parsed.smsMessages || parsed.smsMessages.length === 0) {
          parsed.smsMessages = [
            {
              id: 'sms_welcome_1',
              phoneNumberId: parsed.phoneNumbers[0].id,
              fromNumber: '+1 (800) 555-0199',
              senderName: 'WhatsApp',
              text: 'Your WhatsApp security code is 749-102. Do not share this code with anyone.',
              extractedOtp: '749-102',
              receivedAt: new Date(Date.now() - 30 * 1000).toISOString(),
            }
          ];
        }
        return parsed;
      }
    } catch {}
    return getInitialState();
  }

  private static saveState(state: any) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {}
  }

  public static getState() {
    return this.loadState();
  }

  public static updateState(updater: (state: any) => any) {
    const current = this.loadState();
    const updated = updater(current);
    this.saveState(updated);
    return updated;
  }

  // Mailbox Operations
  public static createMailbox(username?: string, domain?: string, duration: '10m' | '1h' | '24h' | '7d' = '24h'): Mailbox {
    const cleanDomain = domain || DOMAINS[0];
    const cleanUser = (username || Math.random().toString(36).substring(2, 8)).toLowerCase().trim();
    const address = `${cleanUser}@${cleanDomain}`;

    let durationMs = 24 * 60 * 60 * 1000;
    if (duration === '10m') durationMs = 10 * 60 * 1000;
    if (duration === '1h') durationMs = 60 * 60 * 1000;
    if (duration === '7d') durationMs = 7 * 24 * 60 * 60 * 1000;

    const newMb: Mailbox = {
      id: 'mb_' + Math.random().toString(36).substring(2, 9),
      address,
      username: cleanUser,
      domain: cleanDomain,
      lifetimeTier: duration,
      expiresAt: new Date(Date.now() + durationMs).toISOString(),
      createdAt: new Date().toISOString(),
      isCustom: !!username,
      unreadCount: 0,
    };

    this.updateState((state) => {
      state.mailboxes.unshift(newMb);
      state.activeMailboxId = newMb.id;
      return state;
    });

    return newMb;
  }

  public static extendMailbox(mailboxId: string): string {
    let newExpiresAt = '';
    this.updateState((state) => {
      const mb = state.mailboxes.find((m: Mailbox) => m.id === mailboxId);
      if (mb) {
        const base = new Date(mb.expiresAt).getTime() > Date.now() ? new Date(mb.expiresAt).getTime() : Date.now();
        newExpiresAt = new Date(base + 24 * 60 * 60 * 1000).toISOString();
        mb.expiresAt = newExpiresAt;
      }
      return state;
    });
    return newExpiresAt;
  }

  public static deleteMailbox(mailboxId: string) {
    this.updateState((state) => {
      state.mailboxes = state.mailboxes.filter((m: Mailbox) => m.id !== mailboxId);
      state.messages = state.messages.filter((msg: EmailMessage) => msg.mailboxId !== mailboxId);
      if (state.activeMailboxId === mailboxId) {
        state.activeMailboxId = state.mailboxes[0]?.id || null;
      }
      return state;
    });
  }

  // Inbound Email Simulation / Webhook
  public static receiveEmail(params: {
    toAddress: string;
    fromAddress: string;
    fromName: string;
    subject: string;
    htmlBody: string;
    plainText: string;
    attachments?: any[];
  }): EmailMessage | null {
    const state = this.loadState();
    const mailbox = state.mailboxes.find((m: Mailbox) => m.address.toLowerCase() === params.toAddress.toLowerCase());
    if (!mailbox) return null;

    const otpData = detectOtpAndLinks(`${params.subject}\n${params.plainText}`);
    const hasTrackers = params.htmlBody.includes('pixel') || params.htmlBody.includes('tracker');

    const msg: EmailMessage = {
      id: 'msg_' + Math.random().toString(36).substring(2, 9),
      mailboxId: mailbox.id,
      fromAddress: params.fromAddress,
      fromName: params.fromName,
      toAddress: params.toAddress,
      subject: params.subject,
      textPreview: params.plainText.slice(0, 120),
      htmlBody: params.htmlBody,
      plainText: params.plainText,
      extractedOtp: otpData.code,
      verificationUrl: otpData.url,
      isRead: false,
      isSpam: false,
      hasTrackers,
      sizeBytes: Buffer.byteLength(params.htmlBody || params.plainText, 'utf8'),
      receivedAt: new Date().toISOString(),
      attachments: params.attachments || [],
    };

    this.updateState((s) => {
      s.messages.unshift(msg);
      const targetMb = s.mailboxes.find((m: Mailbox) => m.id === mailbox.id);
      if (targetMb) targetMb.unreadCount += 1;
      return s;
    });

    return msg;
  }

  // Number Operations
  public static rentNumber(item: typeof AVAILABLE_PHONE_CATALOG[0], duration: '20m' | '24h' | '7d' | '30d' = '20m'): { success: boolean; error?: string; number?: PhoneNumber } {
    let cost = item.cost;
    let durationMs = 20 * 60 * 1000;
    if (duration === '24h') {
      cost = 25;
      durationMs = 24 * 60 * 60 * 1000;
    } else if (duration === '7d') {
      cost = 70;
      durationMs = 7 * 24 * 60 * 60 * 1000;
    } else if (duration === '30d') {
      cost = 180;
      durationMs = 30 * 24 * 60 * 60 * 1000;
    }

    const state = this.loadState();
    if (state.user.credits < cost) {
      return { success: false, error: `Insufficient credits. You need ${cost} credits, but have ${state.user.credits}.` };
    }

    const newNumber: PhoneNumber = {
      id: 'num_' + Math.random().toString(36).substring(2, 9),
      number: item.number,
      countryCode: item.countryCode,
      countryName: item.countryName,
      flag: item.flag,
      provider: 'mock',
      status: 'ACTIVE',
      rentedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + durationMs).toISOString(),
      creditsCost: cost,
      receivedSmsQty: 0,
      refundIssued: false,
    };

    const newTx: CreditTransaction = {
      id: 'tx_' + Math.random().toString(36).substring(2, 9),
      amount: -cost,
      type: 'RENT_NUMBER',
      description: `Rented ${item.number} (${duration})`,
      createdAt: new Date().toISOString(),
    };

    this.updateState((s) => {
      s.user.credits -= cost;
      s.phoneNumbers.unshift(newNumber);
      s.transactions.unshift(newTx);
      return s;
    });

    return { success: true, number: newNumber };
  }

  public static generateOrSwitchNumber(countryCode: string = 'US', currentNumber?: string): PhoneNumber {
    const list = AVAILABLE_PHONE_CATALOG.filter((c) => !countryCode || c.countryCode === countryCode);
    const pool = list.length > 0 ? list : AVAILABLE_PHONE_CATALOG;
    const candidates = pool.filter((c) => c.number !== currentNumber);
    const item = (candidates.length > 0 ? candidates : pool)[Math.floor(Math.random() * (candidates.length > 0 ? candidates.length : pool.length))];

    const newNumber: PhoneNumber = {
      id: 'num_' + Math.random().toString(36).substring(2, 9),
      number: item.number,
      countryCode: item.countryCode,
      countryName: item.countryName,
      flag: item.flag,
      provider: 'mock',
      status: 'ACTIVE',
      rentedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      creditsCost: 0,
      receivedSmsQty: 0,
      refundIssued: false,
    };

    this.updateState((s) => {
      s.phoneNumbers = [newNumber, ...s.phoneNumbers.filter((p: PhoneNumber) => p.number !== newNumber.number)];
      return s;
    });

    return newNumber;
  }

  public static clearSms(phoneNumberId?: string) {
    this.updateState((s) => {
      if (phoneNumberId) {
        s.smsMessages = s.smsMessages.filter((m: SmsMessage) => m.phoneNumberId !== phoneNumberId);
        const p = s.phoneNumbers.find((n: PhoneNumber) => n.id === phoneNumberId);
        if (p) p.receivedSmsQty = 0;
      } else {
        s.smsMessages = [];
        s.phoneNumbers.forEach((p: PhoneNumber) => { p.receivedSmsQty = 0; });
      }
      return s;
    });
  }

  public static deleteSms(smsId: string) {
    this.updateState((s) => {
      s.smsMessages = s.smsMessages.filter((m: SmsMessage) => m.id !== smsId);
      return s;
    });
  }

  public static receiveSms(phoneNumberId: string, fromNumber: string, senderName: string, text: string): SmsMessage | null {
    const state = this.loadState();
    let phone = state.phoneNumbers.find((n: PhoneNumber) => n.id === phoneNumberId);
    if (!phone && state.phoneNumbers.length > 0) {
      phone = state.phoneNumbers[0];
    }
    if (!phone) {
      phone = this.generateOrSwitchNumber('US');
    }

    const otpData = detectOtpAndLinks(text);

    const sms: SmsMessage = {
      id: 'sms_' + Math.random().toString(36).substring(2, 9),
      phoneNumberId: phone.id,
      fromNumber,
      senderName,
      text,
      extractedOtp: otpData.code,
      receivedAt: new Date().toISOString(),
    };

    this.updateState((s) => {
      s.smsMessages.unshift(sms);
      const targetPhone = s.phoneNumbers.find((n: PhoneNumber) => n.id === phone!.id);
      if (targetPhone) {
        targetPhone.receivedSmsQty += 1;
      }
      return s;
    });

    return sms;
  }

  public static renewNumber(phoneNumberId: string): { success: boolean; error?: string } {
    const cost = 15;
    const state = this.loadState();
    if (state.user.credits < cost) {
      return { success: false, error: `Insufficient credits to renew. Needs ${cost} credits.` };
    }

    this.updateState((s) => {
      s.user.credits -= cost;
      const phone = s.phoneNumbers.find((n: PhoneNumber) => n.id === phoneNumberId);
      if (phone) {
        const base = new Date(phone.expiresAt).getTime() > Date.now() ? new Date(phone.expiresAt).getTime() : Date.now();
        phone.expiresAt = new Date(base + 24 * 60 * 60 * 1000).toISOString();
        phone.status = 'ACTIVE';
      }
      s.transactions.unshift({
        id: 'tx_' + Math.random().toString(36).substring(2, 9),
        amount: -cost,
        type: 'EXTEND_NUMBER',
        description: `Extended number rental (+24h)`,
        createdAt: new Date().toISOString(),
      });
      return s;
    });

    return { success: true };
  }

  public static releaseNumber(phoneNumberId: string) {
    this.updateState((s) => {
      const phone = s.phoneNumbers.find((n: PhoneNumber) => n.id === phoneNumberId);
      if (phone) {
        phone.status = 'RELEASED';
        // Auto-refund if no SMS was ever received during this rental
        if (phone.receivedSmsQty === 0 && !phone.refundIssued) {
          phone.refundIssued = true;
          s.user.credits += phone.creditsCost;
          s.transactions.unshift({
            id: 'tx_' + Math.random().toString(36).substring(2, 9),
            amount: phone.creditsCost,
            type: 'AUTO_REFUND',
            description: `Auto-refund for unused number ${phone.number}`,
            createdAt: new Date().toISOString(),
          });
        }
      }
      return s;
    });
  }

  public static addCredits(amount: number, description: string) {
    this.updateState((s) => {
      s.user.credits += amount;
      s.transactions.unshift({
        id: 'tx_' + Math.random().toString(36).substring(2, 9),
        amount,
        type: 'PURCHASE',
        description,
        createdAt: new Date().toISOString(),
      });
      return s;
    });
  }

  public static reportMessageSpam(messageId: string) {
    this.updateState((s) => {
      const msg = s.messages.find((m: EmailMessage) => m.id === messageId);
      if (msg) {
        msg.isSpam = true;
        s.abuseReports.unshift({
          id: 'rep_' + Math.random().toString(36).substring(2, 9),
          userId: s.user.id,
          userEmail: s.user.email || 'Guest',
          itemType: 'MESSAGE',
          itemId: messageId,
          reason: 'SPAM_REPORT',
          details: `From: ${msg.fromAddress}, Subject: ${msg.subject}`,
          resolved: false,
          createdAt: new Date().toISOString(),
        });
      }
      return s;
    });
  }

  // Live User Session & Analytics for Admin Panel
  public static updateUserHeartbeat(params: {
    deviceId: string;
    tab: 'email' | 'numbers' | 'settings';
    activeMailbox?: string;
    activeNumber?: string;
  }) {
    this.updateState((s) => {
      if (!s.sessionLogs) s.sessionLogs = [...INITIAL_DEMO_USERS];
      let userSess = s.sessionLogs.find((l: UserSessionLog) => l.deviceId === params.deviceId);
      if (!userSess) {
        userSess = {
          id: 'sess_' + Math.random().toString(36).substring(2, 9),
          deviceId: params.deviceId,
          userName: `Active User (${params.deviceId.slice(0, 6)})`,
          country: 'Current Device',
          flag: '⚡',
          ip: 'Live User Session',
          currentTab: params.tab,
          activeMailbox: params.activeMailbox,
          activeNumber: params.activeNumber,
          status: 'ONLINE',
          joinedAt: new Date().toISOString(),
          lastPingAt: new Date().toISOString(),
          durationMinutes: 1,
        };
        s.sessionLogs.unshift(userSess);
        s.totalVisitorsCount = (s.totalVisitorsCount || 1542) + 1;
      } else {
        userSess.currentTab = params.tab;
        userSess.activeMailbox = params.activeMailbox;
        userSess.activeNumber = params.activeNumber;
        userSess.status = 'ONLINE';
        userSess.lastPingAt = new Date().toISOString();
        const start = new Date(userSess.joinedAt).getTime();
        userSess.durationMinutes = Math.max(1, Math.round((Date.now() - start) / 60000));
      }
      return s;
    });
  }

  public static simulateVisitorActivity() {
    this.updateState((s) => {
      if (!s.sessionLogs) s.sessionLogs = [...INITIAL_DEMO_USERS];
      const onlineUsers = s.sessionLogs.filter((u: UserSessionLog) => u.status === 'ONLINE' && !u.userName.startsWith('Active User'));
      if (onlineUsers.length > 3 && Math.random() > 0.65) {
        const toDepart = onlineUsers[Math.floor(Math.random() * onlineUsers.length)];
        toDepart.status = 'DEPARTED';
        toDepart.departedAt = new Date().toISOString();
        toDepart.exitReason = 'Verification code received & session completed';
      } else if (Math.random() > 0.7) {
        const randomCountries = [
          { name: 'India', flag: '🇮🇳', ip: '103.41.28.19 (Delhi)' },
          { name: 'United States', flag: '🇺🇸', ip: '72.14.201.88 (Texas)' },
          { name: 'United Kingdom', flag: '🇬🇧', ip: '51.140.8.22 (London)' },
          { name: 'Canada', flag: '🇨🇦', ip: '198.51.100.4 (Montreal)' },
          { name: 'Germany', flag: '🇩🇪', ip: '194.25.0.12 (Berlin)' },
          { name: 'France', flag: '🇫🇷', ip: '51.15.40.88 (Paris)' },
        ];
        const rc = randomCountries[Math.floor(Math.random() * randomCountries.length)];
        const newVisitor: UserSessionLog = {
          id: 'sess_' + Math.random().toString(36).substring(2, 9),
          deviceId: 'dev_' + Math.random().toString(36).substring(2, 8),
          userName: `User #${Math.floor(1000 + Math.random() * 9000)}`,
          country: rc.name,
          flag: rc.flag,
          ip: rc.ip,
          currentTab: Math.random() > 0.5 ? 'numbers' : 'email',
          status: 'ONLINE',
          joinedAt: new Date().toISOString(),
          lastPingAt: new Date().toISOString(),
          durationMinutes: 1,
        };
        s.sessionLogs.unshift(newVisitor);
        s.totalVisitorsCount = (s.totalVisitorsCount || 1542) + 1;
      }
      return s;
    });
  }

  public static resetEntireAccount() {
    localStorage.removeItem(STORAGE_KEY);
    return getInitialState();
  }
}
