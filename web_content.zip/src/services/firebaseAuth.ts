import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  User as FirebaseUser,
  signOut,
  setPersistence,
  browserLocalPersistence,
  inMemoryPersistence
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc, 
  setDoc, 
  getDocFromServer 
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId || '(default)');

// Test Firestore connection on boot as required by Firebase skill
export async function testFirestoreConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Please check your Firebase configuration.");
    }
  }
}
testFirestoreConnection().catch(() => {});

// Helper to save/merge user profile in Firestore
export async function syncUserToFirestore(userData: any) {
  if (!userData?.id) return;
  try {
    const userRef = doc(db, 'users', userData.id);
    await setDoc(userRef, {
      ...userData,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (e) {
    console.warn('Firestore user sync notice:', e);
  }
}

// Helper to fetch user profile from Firestore
export async function fetchUserFromFirestore(userId: string) {
  try {
    const userRef = doc(db, 'users', userId);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      return snap.data();
    }
  } catch (e) {
    console.warn('Firestore user fetch notice:', e);
  }
  return null;
}

// Configure safe persistence that works without third-party cookies
try {
  setPersistence(auth, browserLocalPersistence).catch(() => {
    setPersistence(auth, inMemoryPersistence).catch((e) => {
      console.warn('Firebase persistence setup warning:', e);
    });
  });
} catch (e) {
  console.warn('Firebase auth persistence warning:', e);
}

// Provider for Standard Google Authentication (Login & Registration)
// Uses ONLY standard non-sensitive scopes (openid, email, profile).
// This guarantees Google NEVER blocks users with:
// "Access blocked: gen-lang-client-0064398482.firebaseapp.com has not completed the Google verification process" / Error 403: access_denied
const basicGoogleProvider = new GoogleAuthProvider();
basicGoogleProvider.addScope('openid');
basicGoogleProvider.addScope('email');
basicGoogleProvider.addScope('profile');
basicGoogleProvider.setCustomParameters({ prompt: 'select_account' });

// Provider for Google Tasks Integration (Sensitive Scope)
// Only requested when specifically synchronizing real Google Tasks
const tasksGoogleProvider = new GoogleAuthProvider();
tasksGoogleProvider.addScope('https://www.googleapis.com/auth/tasks');
tasksGoogleProvider.addScope('openid');
tasksGoogleProvider.addScope('email');
tasksGoogleProvider.addScope('profile');
tasksGoogleProvider.setCustomParameters({ prompt: 'select_account' });

// Flag to indicate if in the middle of sign-in flow
let isSigningIn = false;
// Cache access token strictly in memory
let cachedAccessToken: string | null = null;

export const initAuth = (
  onAuthSuccess?: (user: FirebaseUser, token: string | null) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: FirebaseUser | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        // Token might have expired or page refreshed
        if (onAuthSuccess) onAuthSuccess(user, null);
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

/**
 * Standard Google Sign-In for User Login & Registration.
 * Uses standard profile & email scopes so unverified OAuth consent screens do not block users with 403 access_denied.
 */
export const googleSignIn = async (
  requestTasksScope: boolean = false
): Promise<{ user: FirebaseUser; accessToken: string | null }> => {
  try {
    isSigningIn = true;
    const provider = requestTasksScope ? tasksGoogleProvider : basicGoogleProvider;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    cachedAccessToken = credential?.accessToken || null;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign-In Error:', error);
    
    // If tasks scope was requested and triggered an unverified app / 403 access_denied error,
    // automatically fall back to basic Google Sign-In so the user's account is still signed in!
    if (requestTasksScope && (
      error?.code === 'auth/access-denied' || 
      String(error?.message || '').toLowerCase().includes('access_denied') ||
      String(error?.message || '').includes('403')
    )) {
      console.warn('Google Tasks scope blocked by verification. Retrying with basic Google Sign-In...');
      try {
        const fallbackResult = await signInWithPopup(auth, basicGoogleProvider);
        return { user: fallbackResult.user, accessToken: null };
      } catch (fallbackError) {
        throw fallbackError;
      }
    }

    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Specifically initiates Google Tasks OAuth authorization.
 */
export const googleTasksSignIn = async (): Promise<{ user: FirebaseUser; accessToken: string | null }> => {
  return googleSignIn(true);
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const setCachedAccessToken = (token: string | null) => {
  cachedAccessToken = token;
};

export const firebaseLogout = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};
