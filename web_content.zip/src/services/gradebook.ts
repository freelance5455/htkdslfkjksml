import { subjects } from '../data/content';
import { KEYS, readKey, withStorageLock, writeKey } from './storage';

export type GradeKind = 'اختبار يومي' | 'اختبار شهري' | 'امتحان' | 'أخرى';

export interface GradeImage {
  name: string;
  dataUrl: string;
  sizeBytes: number;
}

export interface GradeRecord {
  id: string;
  subjectId: string;
  title: string;
  kind: GradeKind;
  date: string;
  score: number;
  maxScore: number;
  note?: string;
  attachment?: GradeImage;
  createdAt: number;
  updatedAt: number;
}

export type GradeInput = Omit<GradeRecord, 'id' | 'createdAt' | 'updatedAt'>;
export type GradeSaveResult =
  | { ok: true; record: GradeRecord }
  | { ok: false; reason: 'invalid' | 'too-many' | 'too-large' | 'storage' };

const MAX_RECORDS = 500;
const MAX_ATTACHMENT_DATA_URL_CHARS = 140_000;
const MAX_GRADEBOOK_JSON_CHARS = 1_400_000;
const emptyGrades: GradeRecord[] = [];

export function getGradeRecords(): GradeRecord[] {
  const value = readKey<GradeRecord[]>(KEYS.gradebook, emptyGrades);
  return Array.isArray(value) ? value.filter((item) => item && typeof item.id === 'string') : [];
}

function validDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

function validInput(input: GradeInput): boolean {
  return subjects.some((subject) => subject.id === input.subjectId)
    && input.title.trim().length >= 2
    && input.title.trim().length <= 120
    && ['اختبار يومي', 'اختبار شهري', 'امتحان', 'أخرى'].includes(input.kind)
    && validDate(input.date)
    && Number.isFinite(input.score)
    && Number.isFinite(input.maxScore)
    && input.score >= 0
    && input.maxScore > 0
    && input.score <= input.maxScore
    && (!input.note || input.note.length <= 2_000)
    && (!input.attachment || (input.attachment.dataUrl.length <= MAX_ATTACHMENT_DATA_URL_CHARS && input.attachment.dataUrl.startsWith('data:image/jpeg;base64,')));
}

export async function saveGradeRecord(input: GradeInput, id?: string): Promise<GradeSaveResult> {
  if (!validInput(input)) return { ok: false, reason: 'invalid' };
  return withStorageLock('wallet', [KEYS.gradebook], () => {
    const previous = getGradeRecords();
    if (!id && previous.length >= MAX_RECORDS) return { ok: false, reason: 'too-many' };
    const now = Date.now();
    const existing = id ? previous.find((record) => record.id === id) : undefined;
    const record: GradeRecord = {
      ...input,
      title: input.title.trim(),
      note: input.note?.trim() || undefined,
      id: existing?.id ?? id ?? `grade-${now}-${Math.random().toString(36).slice(2, 8)}`,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    };
    const next = existing
      ? previous.map((item) => item.id === existing.id ? record : item)
      : [record, ...previous];
    if (JSON.stringify(next).length > MAX_GRADEBOOK_JSON_CHARS) return { ok: false, reason: 'too-large' };
    if (!writeKey(KEYS.gradebook, next)) return { ok: false, reason: 'storage' };
    return { ok: true, record };
  });
}

export async function deleteGradeRecord(id: string): Promise<boolean> {
  return withStorageLock('wallet', [KEYS.gradebook], () => {
    const current = getGradeRecords();
    const next = current.filter((record) => record.id !== id);
    if (next.length === current.length) return false;
    return writeKey(KEYS.gradebook, next);
  });
}

export function weightedGradeAverage(records: GradeRecord[]): { score: number; total: number; percent: number; count: number } {
  const score = records.reduce((sum, record) => sum + record.score, 0);
  const total = records.reduce((sum, record) => sum + record.maxScore, 0);
  return { score, total, percent: total ? Math.round((score / total) * 1000) / 10 : 0, count: records.length };
}

/** يعيد ترميز صورة الورقة كـ JPEG محلي صغير؛ لا يتصل بأي خدمة ولا يرفع الملف. */
export async function compressGradeImage(file: File): Promise<GradeImage> {
  if (!file.type.startsWith('image/') || file.type === 'image/svg+xml') {
    throw new Error('اختر صورة نقطية مثل JPG أو PNG؛ لا تُقبل ملفات SVG.');
  }
  if (file.size > 15 * 1024 * 1024) throw new Error('حجم الصورة الأصلية يتجاوز ١٥ ميغابايت.');

  const objectUrl = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const element = new Image();
      element.onload = () => resolve(element);
      element.onerror = () => reject(new Error('تعذّر قراءة الصورة على هذا الجهاز.'));
      element.src = objectUrl;
    });
    const largestSide = Math.max(image.naturalWidth, image.naturalHeight);
    if (!largestSide) throw new Error('ملف الصورة غير صالح.');

    let scale = Math.min(1, 1400 / largestSide);
    let quality = 0.78;
    for (let attempt = 0; attempt < 7; attempt += 1) {
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
      const context = canvas.getContext('2d');
      if (!context) throw new Error('تعذّر تجهيز الصورة في المتصفح.');
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/jpeg', quality));
      if (!blob) throw new Error('تعذّر ضغط الصورة.');
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => typeof reader.result === 'string' ? resolve(reader.result) : reject(new Error('تعذّر تحويل الصورة.'));
        reader.onerror = () => reject(new Error('تعذّر قراءة الصورة المضغوطة.'));
        reader.readAsDataURL(blob);
      });
      if (dataUrl.length <= MAX_ATTACHMENT_DATA_URL_CHARS) {
        return { name: file.name.slice(0, 120), dataUrl, sizeBytes: blob.size };
      }
      scale *= 0.82;
      quality = Math.max(0.42, quality - 0.06);
    }
    throw new Error('الصورة بقيت كبيرة بعد الضغط؛ اختر صورة أصغر أو قصّها أولاً.');
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}
