import { Language, SolvedOpportunity, BusinessOption, BudgetLineItem, DayAction } from '../types';

export function synthesizeOpportunity(
  problem: string,
  category: string,
  language: Language
): Omit<SolvedOpportunity, 'id' | 'createdAt'> {
  const p = problem.toLowerCase();
  const isAm = language === 'am';

  const isAgri =
    p.includes('farm') ||
    p.includes('tomato') ||
    p.includes('crop') ||
    p.includes('food') ||
    p.includes('fruit') ||
    p.includes('cold') ||
    p.includes('vegetable') ||
    p.includes('milk') ||
    p.includes('ገበሬ') ||
    p.includes('ግብርና') ||
    p.includes('ቲማቲም') ||
    p.includes('ምርት');

  const isPlastic =
    p.includes('plastic') ||
    p.includes('waste') ||
    p.includes('recycle') ||
    p.includes('bottle') ||
    p.includes('trash') ||
    p.includes('clean') ||
    p.includes('ቆሻሻ') ||
    p.includes('ፕላስቲክ') ||
    p.includes('ፅዳት');

  if (isAgri) {
    if (isAm) {
      return {
        originalProblem: problem,
        category: category || 'Agriculture & Food',
        language,
        opportunityTitle: 'አግሪቺል የጋራ የቀዝቃዛ ማከማቻ ማዕከል (AgriChill Hubs)',
        tagline: 'የአርሶ አደሩን የአትክልትና ፍራፍሬ ብክነት ወደ ከፍተኛ ወቅታዊ ትርፍ መቀየር።',
        problemAnalysis: {
          exactProblemBreakdown:
            'በኢትዮጵያ ገጠር እና በከተማ ዳርቻ አምራቾች ዘንድ የኤሌክትሪክ ኃይል እና የማቀዝቀዣ ቴክኖሎጂ ባለመኖሩ ምክንያት እስከ 40% የሚደርስ የቲማቲም፣ የቃሪያ እና የፍራፍሬ ምርት ገበያ ሳይደርስ ይበላሻል። አርሶ አደሩ ምርቱ እንዳይበላሽበት በምርት ወቅት በዝቅተኛ ዋጋ ለመሸጥ ይገደዳል፤ ይህም ዓመታዊ ገቢያቸውን በከፍተኛ ሁኔታ ይጎዳል።',
          rootCauses: [
            'በአርሶ አደር ማህበራት እና በመሰብሰቢያ ጣቢያዎች አካባቢ የተማከለ ቀዝቃዛ መጋዘን አለመኖር',
            'ከመጠን በላይ ሙቀት ባለባቸው የትራንስፖርት መንገዶች ላይ ተገቢ ያልሆነ የማሸጊያ ሳጥን (የእንጨት ሳጥን) መጠቀም',
            'የገበያ መረጃ እና የጅምላ ገዢዎች ትስስር እጥረት',
          ],
          currentCostOfInaction:
            'አንድ አነስተኛ አርሶ አደር በየወቅቱ ከ15,000 እስከ 35,000 የኢትዮጵያ ብር የሚገመት ምርት በብክነት ያጣል፤ ሸማቹ ደግሞ በከተማ ውድ ዋጋ ይከፍላል።',
        },
        affectedAndCustomers: {
          affectedDemographics:
            'በኦሮሚያ፣ በሲዳማ፣ በአማራ እና በደቡብ ክልሎች የሚገኙ አነስተኛ አትክልትና ፍራፍሬ አምራች ገበሬዎች እና የከተማ ሸማቾች።',
          payingCustomers: [
            'ምርታቸውን ለጥቂት ቀናት አቆይተው በውድ ዋጋ ለመሸጥ የሚፈልጉ አርሶ አደሮች',
            'ጥራቱ ያልተበላሸ ትኩስ አትክልት በቋሚነት የሚፈልጉ የከተማ ሆቴሎች፣ ሬስቶራንቶች እና ሱፐርማርኬቶች',
            'በአዲስ አበባ እና በክልል ከተሞች ያሉ የጅምላ አትክልት ነጋዴዎች',
          ],
          whyTheyWillPay:
            'በቀን በሳጥን 25-35 ብር በመክፈል በአንድ ሳጥን ላይ ከ150 እስከ 300 ብር የሚደርስ ተጨማሪ የገበያ ትርፍ ስለሚያገኙ።',
        },
        candidateSolutions: [
          {
            id: 'sol_1',
            title: 'በፀሐይ ኃይል የሚሰራ ተንቀሳቃሽ ቀዝቃዛ ክፍል (Solar Cold Room Rental)',
            modelSummary: 'በገበያ ቦታ አጠገብ በሶላር የሚሰራ ማቀዝቀዣ ክፍል ገንብቶ በቀን የሳጥን ኪራይ ማስከፈል።',
            pros: ['አስተማማኝ ገቢ ያስገኛል', 'የኤሌክትሪክ መቆራረጥ አያሰጋውም', 'ለገበሬዎች ተደራሽ ነው'],
            cons: ['የመጀመሪያ የሶላር እቃዎች ግዢ ካፒታል ይጠይቃል'],
            operationalComplexity: 'Medium',
          },
          {
            id: 'sol_2',
            title: 'የቀዘቀዘ የትራንስፖርት እና የደላላነት አገልግሎት (Cold Logistics Brokerage)',
            modelSummary: 'ከተለያዩ ገበሬዎች ምርት ሰብስቦ በተከራዩ አይሱዙ መኪኖች በቀጥታ ለከተማ ገዢዎች ማድረስ።',
            pros: ['የማቀዝቀዣ ግንባታ ካፒታል አይጠይቅም', 'ወዲያውኑ መጀመር ይቻላል'],
            cons: ['የመኪና ኪራይ ዋጋ ንረት', 'የመንገድ መዘጋጋት ስጋት'],
            operationalComplexity: 'Low',
          },
          {
            id: 'sol_3',
            title: 'አትክልትን ወደ ደረቅ ፓውደር/ሶስ የመቀየር ማቀነባበሪያ (Micro-Processing Plant)',
            modelSummary: 'የተረፈውን ቲማቲም በማድረቅ ወይም ወደ ፓስታ ሶስ በመቀየር ማሸግ።',
            pros: ['የመበላሸት እድልን ሙሉ በሙሉ ያስቀራል', 'ከፍተኛ እሴት ይፈጥራል'],
            cons: ['የምግብና መድኃኒት ባለስልጣን ፍቃድ እና የፋብሪካ ማሽነሪዎች ይፈልጋል'],
            operationalComplexity: 'High',
          },
        ],
        recommendedSolution: {
          solutionTitle: 'በፀሐይ ኃይል የሚሰራ ተንቀሳቃሽ ቀዝቃዛ ክፍል (Pay-per-Crate Solar Cold Room)',
          selectionRationale:
            'ይህ መፍትሄ በአነስተኛ መነሻ ካፒታል በሳንድዊች ፓነል ሊገነባ የሚችል፣ በቴሌብር ክፍያ የሚሰበስብ እና የገበሬውን የባለቤትነት ፍላጎት ሳይነካ ቀጥተኛ የቀን ገቢ የሚያስገኝ በጣም ተግባራዊ አማራጭ ነው።',
          howItWorksInPractice:
            'በገበሬዎች ማህበር ግቢ ውስጥ 15 ካሬ ሜትር ክፍል በመከራየት የሶላር ዲሲ ማቀዝቀዣ ይገጠማል። ገበሬው ምርቱን ሲያስገባ በቴሌብር ደረሰኝ ተቆርጦለት በሳጥን ይቀመጣል። ምርቱ ሲሸጥ ክፍያውን ያጠናቅቃል።',
        },
        startupBudget: {
          totalEstimatedETB: '48,000 - 85,000 ETB',
          lineItems: [
            { item: 'የሙቀት መከላከያ ሳንድዊች ፓነል እና የክፍል እድሳት', costETB: '22,000 ETB', essential: true },
            { item: 'የሁለተኛ እጅ ዲሲ ማቀዝቀዣ ኮምፕረሰር እና 2 የሶላር ፓነሎች', costETB: '28,000 ETB', essential: true },
            { item: '50 ሊደረደሩ የሚችሉ ጠንካራ የፕላስቲክ ሳጥኖች (Crates)', costETB: '12,500 ETB', essential: true },
            { item: 'የወረዳ ንግድ ፈቃድና የቴሌብር ነጋዴ አካውንት ምዝገባ', costETB: '2,500 ETB', essential: true },
            { item: 'የማስተዋወቂያ በራሪ ወረቀቶች እና የመጀመሪያ ወር የቦታ ኪራይ', costETB: '6,000 ETB', essential: false },
          ],
          lowCapitalTip: 'መጀመሪያ ላይ የሶላር ሲስተም ከመግዛት ይልቅ በአካባቢው ካለ የፍርጅ ጥገና ባለሙያ ጋር በሽርክና በመስራት ወጪን በግማሽ መቀነስ ይቻላል።',
          zeroBudgetOption: {
            howToLaunchWithZeroBirr:
              'ሙሉ ለሙሉ በ0 ብር ለመጀመር፦ የማቀዝቀዣ ክፍል ሳያስፈልግ፣ የገበሬዎችን ትኩስ ቲማቲም ከእርሻ ላይ ፎቶ በማንሳት ለከተማ ሆቴሎችና ሱፐርማርኬቶች በቴሌግራም/ስልክ በማስተዋወቅ በቀጥታ 5% የደላላነት ኮሚሽን በማግኘት መጀመር ይቻላል።',
            tradeOffs:
              'የማቀዝቀዣ ክፍል ባለመኖርዎ ምክንያት ምርት ማቆየት አይችሉም፤ በየቀኑ በስልክና በአካል አድካሚ የትራንስፖርት ቅንጅት ማድረግ ይጠይቅዎታል።',
          },
        },
        incomeModel: {
          revenueStreams: [
            'የቀን ሳጥን ማከማቻ ኪራይ (በቀን 25 የኢትዮጵያ ብር በሳጥን)',
            'ምርቱን ለከተማ ጅምላ ገዢዎች በማገናኘት የሚገኝ 5% የደላላነት ኮሚሽን',
            'የአየር ማስገቢያ ያላቸው የፕላስቲክ ሳጥኖች ኪራይ (በሳጥን 10 ብር/ጉዞ)',
          ],
          pricingStrategyETB: 'በቀን 25 ብር በሳጥን (100 ሳጥኖች ሲሞሉ በቀን 2,500 ብር ገቢ)',
          paymentMethods: ['Telebirr (ቴሌብር)', 'CBE Birr (የኢትዮጵያ ንግድ ባንክ)', 'ጥሬ ገንዘብ (Cash)'],
        },
        financialEstimates: {
          estimatedMonthlyRevenueETB: '45,000 - 65,000 ETB (ግምታዊ)',
          estimatedMonthlyExpensesETB: '14,000 - 20,000 ETB (ግምታዊ)',
          estimatedMonthlyNetETB: '28,000 - 45,000 ETB (ግምታዊ)',
          expenseBreakdown: [
            'የቦታ ኪራይ፦ 5,000 ETB',
            'የአንድ ረዳት የቀን ሰራተኛ ደመወዝ፦ 6,000 ETB',
            'የጥገና እና የጽዳት ወጪ፦ 3,000 ETB',
          ],
          disclaimer:
            'ማሳሰቢያ፦ ይህ የገንዘብ ግምት የተመሰረተው 60% የመጋዘን የመያዝ አቅም ላይ ሲሆን እንደ ምርት ወቅትና እንደ ገበያው ሁኔታ ሊለወጥ ይችላል።',
          revenueFormula: {
            estimatedSalesCount: 120,
            averageTransactionValueETB: 850,
            commissionRatePercent: 5,
            listingFeeETB: 25,
            listingFeeCount: 600,
            calculationExplanation:
              '(120 ሳጥኖች ትስስር × 850 ETB ዋጋ × 5% ኮሚሽን = 5,100 ETB) + (600 የሳጥን ማከማቻ ቀናት × 25 ETB = 15,000 ETB) + የሳጥን ኪራይ = በወር ከ22,000 እስከ 35,000 ETB የመነሻ ወርሃዊ ገቢ።',
          },
          factsConfirmed: [
            'በኢትዮጵያ ገጠር የአትክልት ብክነት እስከ 40% የሚደርስ የተረጋገጠ ችግር መሆኑ።',
            'የቴሌብር ነጋዴ አካውንት በኢትዮጵያ ንግድ ባንክና ቴሌኮም ተቀባይነት ያለው አስተማማኝ የክፍያ መንገድ መሆኑ።',
          ],
          assumptionsAndEstimates: [
            'አማካይ የማከማቻ ክፍሉ 60% የመያዝ አቅም (Occupancy) ይኖረዋል ተብሎ ይገመታል።',
            'አንድ ሳጥን በአማካይ ለ3-5 ቀናት በማቀዝቀዣው ውስጥ ይቆያል የሚል ግምት።',
          ],
        },
        sevenDayActionPlan: [
          {
            dayNumber: 1,
            dayTitle: 'ቀን 1፦ የመስክ ምልከታና የገበሬዎች ቃለ-መጠይቅ',
            specificActions: [
              'በአቅራቢያ ወደሚገኝ የአትክልት ገበያ መሄድ',
              'ቢያንስ 10 የቲማቲም አምራቾችን አነጋግሮ በቀን ምን ያህል ሳጥን እንደሚበላሽባቸው መመዝገብ',
            ],
            milestoneGoal: 'የ10 ገበሬዎች የኪሳራ መጠንና የኪራይ ፍላጎት መረጃ ማግኘት።',
          },
          {
            dayNumber: 2,
            dayTitle: 'ቀን 2፦ የከተማ ገዢዎችን ፍላጎት ማረጋገጥ',
            specificActions: [
              'በከተማ ያሉ 5 ሬስቶራንቶችን ወይም ሆቴሎችን ማነጋገር',
              'ጥራቱ የተጠበቀ ትኩስ ቲማቲም በሳምንት 3 ቀን ቢቀርብላቸው ለመግዛት መስማማታቸውን ማረጋገጥ',
            ],
            milestoneGoal: 'ቢያንስ 2 የሆቴል ባለቤቶች የፍላጎት ማረጋገጫ (Verbal agreement) መስጠታቸው።',
          },
          {
            dayNumber: 3,
            dayTitle: 'ቀን 3፦ የማቀዝቀዣ ክፍል ቦታ መምረጥና ማነጋገር',
            specificActions: [
              'ከገበሬዎች ማህበር ወይም ከቀበሌ ግቢ 15 ካሬ ሜትር ቦታ መፈለግ',
              'የቦታ ኪራይ ዋጋን ከማህበሩ አመራሮች ጋር መደራደር',
            ],
            milestoneGoal: 'ተመጣጣኝ የቦታ ስምምነት ላይ መድረስ።',
          },
          {
            dayNumber: 4,
            dayTitle: 'ቀን 4፦ የቴክኒክ እቃዎች ዋጋ ማጣራት',
            specificActions: [
              'ከአካባቢው የኤሌክትሪክ እና የፍሪጅ ባለሙያ ጋር መገናኘት',
              'የሳንድዊች ፓነል እና የሶላር ኮምፕረሰር ትክክለኛ ዋጋ ማወቅ',
            ],
            milestoneGoal: 'የእቃዎች ዝርዝር ዋጋ ሰነድ (Quotation) ማጠናቀቅ።',
          },
          {
            dayNumber: 5,
            dayTitle: 'ቀን 5፦ የሙከራ ሳጥኖች ምዝገባ (Pre-Booking Test)',
            specificActions: [
              'ወደ ገበሬዎቹ ተመልሶ የመጀመሪያዎቹን 30 ሳጥኖች በቅናሽ ዋጋ (በቀን 20 ብር) መመዝገብ',
              'የቴሌብር ነጋዴ አካውንት መክፈት',
            ],
            milestoneGoal: 'ገንዘብ ሳያወጡ ቢያንስ 15 ሳጥኖች በቅድመ-ትዕዛዝ መመዝገብ።',
          },
          {
            dayNumber: 6,
            dayTitle: 'ቀን 6፦ የክፍል ዝግጅትና የሙከራ ሳጥኖች ማስገባት',
            specificActions: [
              'ቀለል ያለውን የማቀዝቀዣ ክፍል ማጠናቀቅና ማጽዳት',
              'የመጀመሪያዎቹን የሙከራ የቲማቲም ሳጥኖች አስገብቶ የሙቀት መጠን መለካት',
            ],
            milestoneGoal: 'ማቀዝቀዣው 10-12 ዲግሪ ሴንቲግሬድ መያዙን ማረጋገጥ።',
          },
          {
            dayNumber: 7,
            dayTitle: 'ቀን 7፦ የሙከራ ናሙና ለገዢዎች ማሳየትና የጥራት ግምገማ',
            specificActions: [
              'የተቀመጡትን ሳጥኖች ናሙና ለተስማሙት ሆቴሎች አሳይቶ የጥራት ደረጃ ማረጋገጥ',
              'የቀጣይ ሳምንት ቋሚ የአቅርቦት ስምምነት መርሃ-ግብር ማዘጋጀት',
            ],
            milestoneGoal: 'የጥራት ተቀባይነት ማረጋገጫ ማግኘትና የሳምንት 2 እቅድ ማውጣት።',
          },
        ],
        safetyAndVerification: {
          buyerVerificationSteps: [
            'የሆቴል ወይም ሬስቶራንት የግዢ ኃላፊ ህጋዊ የንግድ ፈቃድ እና አድራሻ ማረጋገጥ።',
            'ክፍያ በቴሌብር ወይም በባንክ በ24 ሰዓት ውስጥ ለመፈጸም የተፈረመ የትዕዛዝ ደረሰኝ መያዝ።',
          ],
          sellerVerificationSteps: [
            'የአርሶ አደሩን የአባልነት መታወቂያ እና የመሬት ይዞታ ማረጋገጥ።',
            'የምርቱን ጥራት ደረጃ (Grade A, B) በሳጥን መመዝገብና የመረከቢያ ደረሰኝ መስጠት።',
          ],
          fraudPreventionGuidelines: [
            'የምርት ርክክብ በይፋዊ የመሰብሰቢያ ጣቢያ ብቻ ማከናወን።',
            'ገዢዎች ምርቱን ሳይመረምሩ እና የጥራት ደረጃውን ሳያረጋግጡ ክፍያ እንዳይፈጽሙ ማድረግ።',
          ],
          legalPaymentCompliance:
            'ህጋዊ የክፍያ ደንብ፦ የማከማቻ ማዕከሉ የገዢዎችን ወይም የገበሬዎችን ገንዘብ በራሱ አካውንት አያቆይም። ገዢው በቀጥታ ለገበሬው በቴሌብር/ሲቢኢ ብር ይከፍላል፤ የማከማቻ ማዕከሉ የሳጥን ኪራይ ክፍያውን በቀጥታ ደረሰኝ ቆርጦ ይሰበስባል።',
        },
        skillsAndResources: {
          requiredSkills: [
            'የአትክልትና ፍራፍሬ አያያዝ እና የሙቀት ቁጥጥር',
            'ከገበሬዎች ጋር ተግባቢ የመሆን እና የማሳመን ክህሎት',
            'መሰረታዊ የቴሌብር እና የሞባይል ፋይናንስ አጠቃቀም',
            'የአካባቢው የገበያ ዋጋ መረጃ ክትትል',
          ],
          physicalEquipment: [
            '15 ካሬ ሜትር ሙቀት መከላከያ ክፍል',
            'የሶላር ፓነሎችና የዲሲ ማቀዝቀዣ',
            '50 የፕላስቲክ ሳጥኖች',
            'ቴርሞሜትር (የሙቀት መለኪያ)',
          ],
          digitalTools: [
            'የቴሌብር ነጋዴ መተግበሪያ (Telebirr Merchant App)',
            'የቴሌግራም ግሩፕ ለገበያ መረጃ ማስተላለፊያ',
            'ቀለል ያለ የስልክ ማስታወሻ ደብተር',
          ],
        },
        risksAndMitigations: [
          {
            risk: 'የምርት ወቅት ማብቃት እና የማከማቻ ክፍሉ ባዶ መሆን',
            mitigation: 'በሌሎች ወቅቶች እንደ ሽንኩርት፣ ቃሪያ፣ ዝንጅብል እና ወተት ያሉ ምርቶችን ማከማቸት።',
          },
          {
            risk: 'ገበሬዎች ምርታቸውን ባልተለመደ ሰው እጅ ለማስቀመጥ መፍራት',
            mitigation: 'ከአካባቢው የገበሬዎች ማህበር ጋር በይፋ በመፈራረም እና ወዲያውኑ የታተመ ደረሰኝ በመስጠት አመኔታ መገንባት።',
          },
          {
            risk: 'የሶላር ባትሪ ብልሽት ወይም ተከታታይ የዝናብ ቀናት',
            mitigation: 'በቂ የሙቀት መከላከያ ሳንድዊች ፓነል በመጠቀም ክፍሉ ያለ ኃይል ለ24 ሰዓት ቀዝቃዛ ሆኖ እንዲቆይ ማድረግ።',
          },
        ],
        marketDemandTests: [
          {
            testMethod: 'የቅድመ-ቦታ ማስያዝ ሙከራ (Pre-Booking Test)',
            howToConduct: 'ገንዘብ ሳያወጡ ገበሬዎችን "በቀን 20 ብር ሳጥንዎን የሚያቀዘቅዝ ክፍል እያዘጋጀን ነው፣ ስምዎን እናስመዝግብ?" ብሎ መጠየቅ።',
            successSignal: 'ቢያንስ 15 አርሶ አደሮች ስልካቸውን ሰጥተው ለመመዝገብ ፈቃደኛ ሲሆኑ።',
          },
          {
            testMethod: 'የሆቴሎች ፍላጎት ማረጋገጫ (Off-take Letter of Intent)',
            howToConduct: 'ለ3 የከተማ ሆቴሎች ጥራቱ ያልተበላሸ ቲማቲም በቋሚነት የመግዛት ፍላጎታቸውን በጽሑፍ መጠየቅ።',
            successSignal: 'ቢያንስ 2 ሆቴሎች የዋጋ ተመን ተስማምተው ለመግዛት ፈቃደኝነታቸውን ሲያረጋግጡ።',
          },
        ],
        validationStatus: {
          isHypothesis: true,
          evidenceStatement:
            'ማስጠንቀቂያ፦ ይህ የንግድ ሃሳብ በገበያ ላይ የተመሰረተ መላ-ምት (Hypothesis) ነው። በ7ቱ ቀናት ውስጥ የተዘረዘሩትን የገበሬዎች እና የሆቴሎች ማረጋገጫ ሳያገኙ ምንም አይነት ገንዘብ በግንባታ ላይ እንዳያውሉ!',
        },
        marketOpportunity: 'በቀን በሳጥን 25-35 ብር በመክፈል ገበሬው ምርቱን ከብክነት አድኖ በውድ ዋጋ ይሸጣል።',
        proposedSolution: 'በፀሐይ ኃይል የሚሰራ ተንቀሳቃሽ ቀዝቃዛ ክፍል (Pay-per-Crate Solar Cold Room)',
        monetizationModel: ['የቀን ሳጥን ኪራይ (25 ብር/ቀን)', 'የ5% የደላላነት ኮሚሽን'],
        stepByStepPlan: [
          { phase: 'ምዕራፍ 1፦ የገበያ ማረጋገጫ', duration: 'ቀን 1-2', actions: ['10 ገበሬዎችን ማነጋገር', '2 ሆቴሎችን ማረጋገጥ'] },
          { phase: 'ምዕራፍ 2፦ ክፍል ዝግጅት', duration: 'ቀን 3-5', actions: ['የቦታ ስምምነት', 'የሳጥን ግዢ'] },
          { phase: 'ምዕራፍ 3፦ አገልግሎት ማስጀመር', duration: 'ቀን 6-7', actions: ['የሙከራ ሳጥን ማስገባት', 'ክፍያ በቴሌብር መሰብሰብ'] },
        ],
        requiredSkills: ['የአትክልት አያያዝ', 'የማህበረሰብ ግንኙነት', 'የቴሌብር አጠቃቀም'],
        estimatedStartupBudget: '48,000 - 85,000 ETB',
        keyRisksAndMitigations: [{ risk: 'የምርት ወቅት ማብቃት', mitigation: 'ሌሎች ምርቶችን ማከማቸት' }],
        immediateNext24Hours: 'ወደ ገበያ በመሄድ 5 ገበሬዎችን የመበላሸት መጠናቸውን ጠይቀው ይመዝግቡ።',
      };
    } else {
      return {
        originalProblem: problem,
        category: category || 'Agriculture & Food',
        language,
        opportunityTitle: 'AgriChill Pay-per-Crate Solar Storage Hubs',
        tagline: 'Decentralized solar cooling turning rural post-harvest produce loss into timed market profits.',
        problemAnalysis: {
          exactProblemBreakdown:
            'In Ethiopian agricultural zones, smallholder tomato, chili, and cabbage farmers suffer catastrophic 30-45% post-harvest spoilage because rural markets lack grid electrification and cold chain infrastructure. Farmers face immediate distress-selling at midday for rock-bottom prices just to avoid total loss.',
          rootCauses: [
            'Absence of affordable, shared cooling facilities at local rural aggregation nodes',
            'Reliance on destructive rough wooden crates during transport that crush bottom layers',
            'Lack of direct pre-negotiated off-take links with urban supermarkets, hotels, and processors in Addis Ababa and regional hubs',
          ],
          currentCostOfInaction:
            'An average smallholder loses between 18,000 and 40,000 ETB per harvest season in discarded produce, while urban consumers suffer erratic retail price spikes.',
        },
        affectedAndCustomers: {
          affectedDemographics:
            'Smallholder produce growers, farm families, cooperative members, and urban consumer households across Ethiopia.',
          payingCustomers: [
            'Smallholder farmers who need 3 to 14 days of shelf-life extension to wait for non-glut market days',
            'Urban restaurants, hotels, and supermarket managers in Addis Ababa seeking reliable grade-A produce without daily market trips',
            'Wholesale produce aggregators operating out of central markets like Atkilt Tera or regional depot unions',
          ],
          whyTheyWillPay:
            'Paying 25-35 ETB per crate per day preserves 200-400 ETB of produce value that would otherwise rot into worthless organic waste.',
        },
        candidateSolutions: [
          {
            id: 'sol_1',
            title: 'Pay-per-Crate Solar Cold Room Hub (Micro-Cold Storage)',
            modelSummary: 'A 15-20 sqm modular insulated room powered by solar DC refrigeration installed at the market gate, charging micro-fees.',
            pros: ['Predictable daily recurring revenue', 'Zero grid dependence', 'Immediate value visible to farmers'],
            cons: ['Requires upfront hardware sourcing for solar compressor'],
            operationalComplexity: 'Medium',
          },
          {
            id: 'sol_2',
            title: 'Aggregated Cold-Logistics Brokerage',
            modelSummary: 'Chartering scheduled refrigerated or night-time ventilated Isuzu trucks to move collective crates straight to Addis Ababa buyers.',
            pros: ['Zero fixed facility construction cost', 'Very fast launch'],
            cons: ['Fuel and truck rental volatility', 'Logistics coordination friction'],
            operationalComplexity: 'Low',
          },
          {
            id: 'sol_3',
            title: 'Solar Dehydration & Tomato Powder Micro-Facility',
            modelSummary: 'Using hygienic solar drying tunnels to slice and convert surplus unsold tomatoes into shelf-stable culinary powder.',
            pros: ['Completely eliminates shelf-life limits', 'High value-density per kilogram'],
            cons: ['Requires food-handling safety certifications and specialized packaging equipment'],
            operationalComplexity: 'High',
          },
        ],
        recommendedSolution: {
          solutionTitle: 'Pay-per-Crate Solar Cold Room Hub (Micro-Cold Storage)',
          selectionRationale:
            'This solution directly addresses the urgent shelf-life crisis without forcing farmers to change their customary selling habits. It generates immediate daily cash flow via Telebirr with low operational overhead.',
          howItWorksInPractice:
            'You secure a 15sqm footprint beside a cooperative depot. You install insulated sandwich panels and a solar DC cooling unit set at 10-12°C. Farmers check in aerated plastic crates, receive an instant Telebirr/paper ticket, and pay upon checkout when selling to buyers.',
        },
        startupBudget: {
          totalEstimatedETB: '48,000 - 85,000 ETB',
          lineItems: [
            { item: 'Insulated sandwich panels & room door fitting', costETB: '22,000 ETB', essential: true },
            { item: 'Refurbished DC compressor & 2x 350W solar panels', costETB: '28,000 ETB', essential: true },
            { item: '50 stackable aerated plastic crates', costETB: '12,500 ETB', essential: true },
            { item: 'Woreda micro-license registration & Telebirr Merchant setup', costETB: '2,500 ETB', essential: true },
            { item: 'Signage, flyers, and initial 1-month ground lease buffer', costETB: '6,000 ETB', essential: false },
          ],
          lowCapitalTip: 'Instead of purchasing brand-new solar systems, partner with a local refrigeration technician on a revenue-share model to slash initial hardware outlays.',
          zeroBudgetOption: {
            howToLaunchWithZeroBirr:
              'Bootstrapping with 0 ETB: Rather than building cooling infrastructure immediately, act as an agile field broker. Photograph farmers’ fresh harvest at the farm gate, aggregate bulk orders on Telegram/phone, and deliver directly to urban hotel chefs and restaurants with an agreed 5% commission on payout.',
            tradeOffs:
              'Without a cold room, you have no buffer for unsold goods; you must invest rigorous daily legwork coordinating fast transport and immediate same-day deliveries.',
          },
        },
        incomeModel: {
          revenueStreams: [
            'Daily crate storage rental (25 ETB/crate/day)',
            'Wholesale linkage commission (4-6% on bulk deals brokered directly with city buyers)',
            'Durable plastic crate rental fee (10 ETB/crate/journey)',
          ],
          pricingStrategyETB: '25 ETB per crate per day (100 crates stored = 2,500 ETB gross daily revenue)',
          paymentMethods: ['Telebirr Merchant', 'CBE Birr', 'Cash on withdrawal'],
        },
        financialEstimates: {
          estimatedMonthlyRevenueETB: '45,000 - 65,000 ETB (Estimated)',
          estimatedMonthlyExpensesETB: '14,000 - 20,000 ETB (Estimated)',
          estimatedMonthlyNetETB: '28,000 - 45,000 ETB (Estimated)',
          expenseBreakdown: [
            'Footprint ground lease: 5,000 ETB/mo',
            'Part-time depot attendant: 6,000 ETB/mo',
            'Maintenance & disinfectant supplies: 3,000 ETB/mo',
          ],
          disclaimer:
            'NOTE: These financial figures are preliminary model projections based on a 60% average capacity factor. Actual performance depends on local harvest cycles and field execution.',
          revenueFormula: {
            estimatedSalesCount: 120,
            averageTransactionValueETB: 850,
            commissionRatePercent: 5,
            listingFeeETB: 25,
            listingFeeCount: 600,
            calculationExplanation:
              '(120 brokered wholesale transactions × 850 ETB avg crate price × 5% commission = 5,100 ETB) + (600 crate-days stored × 25 ETB fee = 15,000 ETB) + crate rentals = ~22,000 - 25,000 ETB baseline month 1 gross.',
          },
          factsConfirmed: [
            'Post-harvest perishability loss in rural Ethiopian horticulture reaches 30-45% as documented by agricultural extension offices.',
            'Telebirr and CBE Birr are standard digital mobile payment methods adopted by rural traders and cooperatives.',
          ],
          assumptionsAndEstimates: [
            'Assumed 60% average daily capacity factor across standard harvest periods.',
            'Assumed average storage turnaround duration of 3 to 5 days per crate.',
          ],
        },
        sevenDayActionPlan: [
          {
            dayNumber: 1,
            dayTitle: 'Day 1: Ground Spoilage Survey & Farmer Interviews',
            specificActions: [
              'Visit your local aggregation market during afternoon trading',
              'Interview 10 tomato growers; record exact daily crate loss and willing storage fee',
            ],
            milestoneGoal: 'Collect documented data on 10 farmers willing to use shared cooling.',
          },
          {
            dayNumber: 2,
            dayTitle: 'Day 2: City Buyer Demand Mapping',
            specificActions: [
              'Visit 5 hotel kitchens or supermarket produce buyers in the nearest urban center',
              'Confirm willing purchase price for grade-A tomatoes delivered fresh 3 days a week',
            ],
            milestoneGoal: 'Secure 2 verbal off-take commitments.',
          },
          {
            dayNumber: 3,
            dayTitle: 'Day 3: Site Selection & Cooperative Lease Negotiation',
            specificActions: [
              'Identify a shaded 15sqm spot near the market union depot',
              'Negotiate monthly lease terms with cooperative leadership',
            ],
            milestoneGoal: 'Obtain cooperative endorsement and footprint agreement.',
          },
          {
            dayNumber: 4,
            dayTitle: 'Day 4: Hardware & Technician Cost Benchmarking',
            specificActions: [
              'Meet with a refrigeration technician in town to inspect refurbished compressor parts',
              'Finalize component price list in ETB',
            ],
            milestoneGoal: 'Complete hardware sourcing budget sheet.',
          },
          {
            dayNumber: 5,
            dayTitle: 'Day 5: Pre-Booking Demand Smoke Test',
            specificActions: [
              'Return to farmers with a physical booking sheet offering opening discounts (20 ETB/day)',
              'Activate Telebirr merchant code on your phone',
            ],
            milestoneGoal: 'Secure at least 15 advance crate reservations before spending capital.',
          },
          {
            dayNumber: 6,
            dayTitle: 'Day 6: Assembly & Trial Storage Run',
            specificActions: [
              'Set up the insulated room and conduct a 6-hour thermal stability test',
              'Check in first 20 trial crates from anchor farmers',
            ],
            milestoneGoal: 'Confirm room holds 10-12°C temperature reliably.',
          },
          {
            dayNumber: 7,
            dayTitle: 'Day 7: Inspection of Preserved Test Batch & Off-take Review',
            specificActions: [
              'Inspect the test batch with buyer representatives to verify freshness standards',
              'Finalize weekly off-take delivery schedule without guaranteeing upfront sales closures',
            ],
            milestoneGoal: 'Obtain buyer quality sign-off and schedule week 2 deliveries.',
          },
        ],
        safetyAndVerification: {
          buyerVerificationSteps: [
            'Verify commercial trade license and physical address of commercial restaurants or grocers.',
            'Issue formal consignment receipt before dispatching high-value crates.',
          ],
          sellerVerificationSteps: [
            'Register farmer Kebele ID and cooperative membership number.',
            'Grade produce (Grade A/B) at entry and issue a tamper-evident physical ticket.',
          ],
          fraudPreventionGuidelines: [
            'All crate check-ins and check-outs must occur inside the official depot gate with attendant signatures.',
            'Never release stored produce without verification of ticket and matching farmer contact.',
          ],
          legalPaymentCompliance:
            'LEGAL PAYMENT MANDATE: The cooling hub charges standard storage fees and does not pool or custody buyer funds. Buyers settle produce payments directly with farmers or union accounts via Telebirr/CBE Birr; storage fees are collected separately with printed tickets.',
        },
        skillsAndResources: {
          requiredSkills: [
            'Produce Quality Grading & Cold Storage Management',
            'Farmer Relationship Building & Local Community Negotiation',
            'Telebirr Mobile Payment & Basic Bookkeeping',
            'Basic Electrical & Solar Maintenance Literacy',
          ],
          physicalEquipment: [
            '15sqm Insulated Sandwich Panel Structure',
            'Solar PV Array (approx. 700W) & DC Cooling Compressor',
            '50 Aerated Stackable Plastic Crates',
            'Digital Temperature & Humidity Sensor',
          ],
          digitalTools: [
            'Telebirr Merchant Account',
            'Telegram Channel for Wholesale Market Alerts',
            'Digital Spreadsheet / Ledger on Mobile',
          ],
        },
        risksAndMitigations: [
          {
            risk: 'Harvest seasonality causing low occupancy during off-peak months',
            mitigation: 'Diversify into peppers, onions, carrots, and local dairy during non-tomato harvest months.',
          },
          {
            risk: 'Farmer skepticism leaving produce in a third-party hub',
            mitigation: 'Provide immediate SMS/printed deposit slips and partner directly with respected cooperative elders.',
          },
          {
            risk: 'Prolonged overcast weather reducing solar performance',
            mitigation: 'Use high-density thermal insulation panels that preserve room temperature for up to 24 hours without active power.',
          },
        ],
        marketDemandTests: [
          {
            testMethod: 'Pre-Booking Reservation Test',
            howToConduct: 'Before purchasing cooling equipment, survey 20 farmers with a mock deposit ledger: "We are installing 50 cold slots at 20 ETB/day—can we reserve 5 slots for you?"',
            successSignal: 'At least 15 farmers provide phone numbers and confirm reserving slots.',
          },
          {
            testMethod: 'Buyer Letter of Intent (LOI)',
            howToConduct: 'Present sample grade-A tomatoes to 3 urban restaurants and ask for a written quote request for 10 crates/week.',
            successSignal: 'At least 2 restaurant managers commit to buying if delivery standards are met.',
          },
        ],
        validationStatus: {
          isHypothesis: true,
          evidenceStatement:
            'EVIDENCE NOTICE: Market demand in this blueprint is currently an informed hypothesis based on observed supply-chain bottlenecks. DO NOT invest capital until you complete the Day 1-5 customer pre-booking tests.',
        },
        marketOpportunity: 'Preserving produce value allows farmers to sell at peak prices instead of distress rates.',
        proposedSolution: 'Pay-per-Crate Solar Cold Room Hub (Micro-Cold Storage)',
        monetizationModel: ['Daily crate storage fees (25 ETB/day)', 'Wholesale linkage commission (5%)'],
        stepByStepPlan: [
          { phase: 'Phase 1: Validation', duration: 'Day 1-2', actions: ['Survey farmers', 'Engage buyers'] },
          { phase: 'Phase 2: Setup', duration: 'Day 3-5', actions: ['Secure site', 'Pre-book slots'] },
          { phase: 'Phase 3: Launch', duration: 'Day 6-7', actions: ['Trial run', 'Collect fees'] },
        ],
        requiredSkills: ['Produce Handling', 'Farmer Relations', 'Telebirr Operations'],
        estimatedStartupBudget: '48,000 - 85,000 ETB',
        keyRisksAndMitigations: [{ risk: 'Seasonality', mitigation: 'Store diverse perishables' }],
        immediateNext24Hours: 'Visit your nearest wholesale market today, survey 5 farmers on daily crate spoilage.',
      };
    }
  }

  const isMarketplace =
    p.includes('ዕቃ') ||
    p.includes('መሸጥ') ||
    p.includes('ገዢ') ||
    p.includes('ገበያ') ||
    p.includes('ንግድ') ||
    p.includes('ሱቅ') ||
    p.includes('አዲስ አበባ') ||
    p.includes('sell') ||
    p.includes('buy') ||
    p.includes('market') ||
    p.includes('goods') ||
    p.includes('item') ||
    p.includes('second') ||
    p.includes('resale') ||
    p.includes('broker');

  if (isMarketplace) {
    if (isAm) {
      return {
        originalProblem: problem,
        category: category || 'Services & Marketplace',
        language,
        opportunityTitle: 'የአዲስ አበባ ፈጣን የዕቃ ሽያጭና አማላጅነት ማዕከል (Addis Direct Exchange)',
        tagline: 'በአዲስ አበባ የተከማቹ ያገለገሉ እና አዳዲስ ዕቃዎችን በታማኝነት ከገዢዎች ጋር በማገናኘት ፈጣን ገቢ መፍጠር።',
        problemAnalysis: {
          exactProblemBreakdown:
            'በአዲስ አበባ ከተማ ውስጥ ነዋሪዎች እና አነስተኛ ነጋዴዎች ያገለገሉ ወይም አዳዲስ ዕቃዎቻቸውን (የቤት እቃዎች፣ ኤሌክትሮኒክስ፣ አልባሳት፣ ቢሮ እቃዎች) ለመሸጥ ሲፈልጉ የታመነ ገዢ ማግኘት፣ ትክክለኛ የገበያ ዋጋ መወሰን እና ደህንነቱ የተጠበቀ ክፍያና ርክክብ ማድረግ ትልቅ ፈተና ሆኖባቸዋል።',
          rootCauses: [
            'በገዢና በሻጭ መካከል የታመነ መድረክ እና የቴሌብር ኤስክሮው (Escrow) ክፍያ አለመኖር',
            'ዕቃዎችን በጥራት ፎቶ አንስቶ፣ መርምሮና ዋጋ ተምኖ ለብዙ ሺህ የከተማ ነዋሪዎች የሚያደርስ ቀልጣፋ የዲጂታል አማላጅ ማጣት',
            'ሻጮች በየግል ማስታወቂያ ለመለጠፍ ጊዜና ክህሎት ማጣት፤ ገዢዎችም በመጭበርበር ፍራቻ ወደ ግለሰቦች መሄድ አለመፈለጋቸው',
          ],
          currentCostOfInaction:
            'በየቤቱ እና በየመጋዘኑ በአስር ሺዎች ብር የሚገመቱ ዕቃዎች ዋጋቸውን እያጡ ይቀመጣሉ፤ ሻጭ ገንዘብ ሲያጣ ገዢ ደግሞ በሱቅ እጥፍ ዋጋ ይገዛል።',
        },
        affectedAndCustomers: {
          affectedDemographics:
            'በአዲስ አበባ የሚኖሩ የኮንዶሚኒየም እና የመኖሪያ መንደር ነዋሪዎች፣ ተማሪዎች፣ ተዘዋዋሪ ሰራተኞች እና አነስተኛ የንግድ መደብሮች።',
          payingCustomers: [
            'ቤታቸውን ሲቀይሩ ወይም ገንዘብ ሲፈልጉ ዕቃዎቻቸውን በ24-48 ሰዓት ውስጥ መሸጥ የሚፈልጉ ሻጮች',
            'የተረጋገጡ የቤት እቃዎችን፣ ላፕቶፖችንና ስልኮችን በቅናሽ ዋጋ በሰፈር ደረጃ መግዛት የሚፈልጉ ሸማቾች',
            'የቢሮ እቃዎችን የሚፈልጉ አዳዲስ ጀማሪ ድርጅቶች',
          ],
          whyTheyWillPay:
            'ሻጩ ደላላ ሳይዞርበትና ሳይጭበረበር በቴሌብር ገንዘቡን ስለሚያገኝ 10-15% ኮሚሽን ለመክፈል ደስተኛ ነው። ገዢውም ጥራቱ የተረጋገጠ እቃ ከቤት ሳይወጣ ስለሚያገኝ ይከፍላል።',
        },
        candidateSolutions: [
          {
            id: 'sol_1',
            title: 'ቴሌግራም ላይ የተመሰረተ የታመነ የዕቃ አማላጅነት እና የፎቶ ካታሎግ (Telegram Verified Brokerage)',
            modelSummary: 'የሚሸጡ ዕቃዎችን በቦታው ሄዶ ፎቶ በማንሳት በቴሌግራም ቻናልና ግሩፖች ማስተዋወቅና በቴሌብር ኮሚሽን መሰብሰብ።',
            pros: ['ዝቅተኛ መነሻ ካፒታል', 'በ2 ቀናት ውስጥ መጀመር መቻሉ', 'ቀጥተኛ የቴሌብር ክፍያ'],
            cons: ['እቃዎችን ፎቶ ለማንሳት መዘዋወር ይጠይቃል'],
            operationalComplexity: 'Low',
          },
          {
            id: 'sol_2',
            title: 'የኮንዶሚኒየም እና የሰፈር የሳምንት መጨረሻ ክፍት ባዛር (Weekend Pop-up Community Bazaar)',
            modelSummary: 'በኮንዶሚኒየም ወይም በመኖሪያ መንደር ግቢ ውስጥ የቅዳሜ እና የእሁድ የዕቃ መሸጫ ክፍት መድረክ ማዘጋጀት።',
            pros: ['ቀጥተኛ የፊት-ለፊት ግብይት', 'ብዙ እቃ በአንድ ቀን መሸጥ መቻሉ'],
            cons: ['የአካባቢ አስተዳደር ፈቃድ እና የቦታ ኪራይ ይጠይቃል'],
            operationalComplexity: 'Medium',
          },
          {
            id: 'sol_3',
            title: 'እቃዎችን ወዲያውኑ በጥሬ ገንዘብ ገዝቶ በትርፍ የመሸጥ ማዕከል (Instant Buyout & Resale Hub)',
            modelSummary: 'የሚሸጡ እቃዎችን በቅናሽ ዋጋ ወዲያውኑ በጥሬ ገንዘብ ገዝቶ በማደስና አፅድቶ በትርፍ መሸጥ።',
            pros: ['ከፍተኛ የትርፍ ህዳግ (Margin)', 'ሙሉ የዋጋ ቁጥጥር'],
            cons: ['ትልቅ የመነሻ ካፒታል እና የማከማቻ ቦታ ይፈልጋል'],
            operationalComplexity: 'High',
          },
        ],
        recommendedSolution: {
          solutionTitle: 'ቴሌግራም ላይ የተመሰረተ የታመነ የዕቃ አማላጅነት እና የፎቶ ካታሎግ (Telegram Verified Brokerage)',
          selectionRationale:
            'ይህ መፍትሄ የቦታ ኪራይ ወይም የዕቃ ግዢ ካፒታል ሳይጠይቅ፣ በስማርትፎን ፎቶግራፍ እና በቴሌብር አማካኝነት በአዲስ አበባ ፈጣን የገንዘብ ዝውውር መፍጠር የሚያስችል እጅግ ተግባራዊ መንገድ ነው።',
          howItWorksInPractice:
            'ሻጩ ስልክ ይደውላል፤ የዕቃውን ፎቶ፣ ዝርዝር እና የሚፈልገውን ዋጋ ያጋራል፤ እርስዎ ጥራቱን አረጋግጠው በቻናልዎ ላይ ይለጥፋሉ፤ ገዢ ሲገኝ ርክክቡ ተፈጽሞ 10% ኮሚሽን በቴሌብር ይቀበላሉ።',
        },
        startupBudget: {
          totalEstimatedETB: '12,000 - 24,000 ETB',
          lineItems: [
            { item: 'ጥራት ያለው የስማርትፎን ካሜራ እና የኢንተርኔት ፓኬጅ', costETB: '8,000 ETB', essential: true },
            { item: 'የቴሌግራም ቻናል ማስተዋወቂያ እና በራሪ ወረቀቶች', costETB: '3,000 ETB', essential: true },
            { item: 'የቴሌብር ነጋዴ አካውንት እና የወረዳ ንግድ ምዝገባ', costETB: '2,500 ETB', essential: true },
            { item: 'ለአካባቢ ትራንስፖርት እና ታክሲ መነሻ ወጪ', costETB: '3,500 ETB', essential: true },
            { item: 'የአስቸኳይ ጊዜ መጠባበቂያ (Contingency Buffer)', costETB: '3,000 ETB', essential: false },
          ],
          lowCapitalTip: 'መጀመሪያ ላይ ሻጮች ራሳቸው ፎቶ እንዲያነሱ በማድረግ የትራንስፖርት ወጪን ዜሮ ማድረግ ይቻላል።',
          zeroBudgetOption: {
            howToLaunchWithZeroBirr:
              'ሙሉ ለሙሉ በ0 ብር ለመጀመር፦ ያለዎትን ስማርትፎን ተጠቅመው ነጻ የቴሌግራም ቻናል ይክፈቱ፤ ሻጮች እቃቸውን በደማቅ ብርሃን ፎቶ እና ቪዲዮ አንስተው እንዲልኩላችሁ ያድርጉ፤ ማስታወቂያውን በአካባቢዎ ባሉ ነጻ የኮንዶሚኒየም እና የሰፈር ቴሌግራም/ፌስቡክ ግሩፖች ላይ ያጋሩ።',
            tradeOffs:
              'ገንዘብ ባለማውጣትዎ ምክንያት የሚከፈልበት ፈጣን ማስታወቂያ ወይም የካታሎግ ህትመት መጠቀም አይችሉም፤ በምትኩ ከፍተኛ የግል ጊዜና ትጋት በማውጣት ሰዎችን በኦርጋኒክ መንገድ ማነጋገር ይጠይቅዎታል።',
          },
        },
        incomeModel: {
          revenueStreams: [
            'ከተፈጸመ ሽያጭ የሚገኝ 10% - 12% የደላላነት ኮሚሽን',
            'እቃው በፈጣን ሰሌዳ እንዲለጠፍ የሚከፈል 50 ETB የልዩ ማስታወቂያ ክፍያ',
            'የአካባቢ ርክክብ እና የማጓጓዝ ማስተባበሪያ ክፍያ (100 - 150 ETB)',
          ],
          pricingStrategyETB: 'አማካይ የእቃ ዋጋ፦ 4,500 ETB፤ 10% ኮሚሽን = 450 ETB በአንድ እቃ ሽያጭ',
          paymentMethods: ['Telebirr (ቴሌብር)', 'CBE Birr (የኢትዮጵያ ንግድ ባንክ)', 'ጥሬ ገንዘብ (በርክክብ ወቅት)'],
        },
        financialEstimates: {
          estimatedMonthlyRevenueETB: '28,000 - 48,000 ETB (ግምታዊ)',
          estimatedMonthlyExpensesETB: '7,000 - 12,000 ETB (ግምታዊ)',
          estimatedMonthlyNetETB: '21,000 - 36,000 ETB (ግምታዊ)',
          expenseBreakdown: [
            'የትራንስፖርት እና የታክሲ ወጪ፦ 4,500 ETB/ወር',
            'የስልክ እና የኢንተርኔት ካርድ፦ 2,000 ETB/ወር',
            'የማስተዋወቂያ ህትመት እና ዲጂታል ማስታወቂያ፦ 2,500 ETB/ወር',
          ],
          disclaimer:
            'ማሳሰቢያ፦ ይህ የፋይናንስ ስሌት በሞዴል ግምት ላይ የተመሰረተ ትንበያ እንጂ የተረጋገጠ የገቢ ዋስትና አይደለም። ትክክለኛው ገቢ በሻጮች ታማኝነት፣ በእቃዎች ጥራት እና በገዢዎች የመግዛት አቅም ይወሰናል።',
          revenueFormula: {
            estimatedSalesCount: 25,
            averageTransactionValueETB: 4500,
            commissionRatePercent: 10,
            listingFeeETB: 50,
            listingFeeCount: 30,
            calculationExplanation:
              '(25 ሽያጮች × 4,500 ETB አማካይ ዋጋ × 10% ኮሚሽን = 11,250 ETB) + (30 ልዩ ማስታወቂያዎች × 50 ETB = 1,500 ETB) + የርክክብ ማስተባበሪያ = በወር ወደ 13,000 - 15,000 ETB መነሻ ገቢ። ስራው ሲያድግ ወደ 45 ሽያጮች ሲደርስ ገቢው ወደ 35,000+ ETB ያድጋል።',
          },
          factsConfirmed: [
            'ቴሌብር እና ሲቢኢ ብር (CBE Birr) በአዲስ አበባ ከተማ ውስጥ በአብዛኛው ነዋሪ ዘንድ ተቀባይነት ያላቸው ህጋዊና ፈጣን የክፍያ መንገዶች መሆናቸው።',
            'በአዲስ አበባ ኮንዶሚኒየሞች ውስጥ ያገለገሉ እቃዎች (ሶፋ፣ ፍሪጅ፣ ላፕቶፕ) ከፍተኛ ፍላጎት ያላቸው መሆኑ።',
            'የኢትዮጵያ ቴሌኮም የኢንተርኔት እና የስልክ ታሪፍ ተመኖች የተረጋገጡ ወጪዎች መሆናቸው።',
          ],
          assumptionsAndEstimates: [
            'ከተለጠፉት 10 እቃዎች ውስጥ ቢያንስ 3ቱ በ15 ቀናት ውስጥ ተፈላጊ ገዢ ያገኛሉ ተብሎ ይገመታል።',
            'አማካይ የአንድ እቃ ዋጋ 4,500 የኢትዮጵያ ብር ይሆናል የሚል ግምት።',
            'ሻጮች እና ገዢዎች የተስማሙበትን የ10% የአገልግሎት ኮሚሽን በወቅቱ ይከፍላሉ የሚል ግምት።',
          ],
        },
        sevenDayActionPlan: [
          {
            dayNumber: 1,
            dayTitle: 'ቀን 1፦ 10 የሚሸጡ እቃዎች ያላቸውን ሰዎች ማነጋገርና የዋጋ ዳሰሳ',
            specificActions: [
              'በኮንዶሚኒየም ወይም በሰፈር የሚሸጥ እቃ ያላቸውን 10 ጓደኞች እና ጎረቤቶች ማግኘት',
              'የሚሸጡትን እቃዎች አይነት፣ ትክክለኛ ሁኔታ እና የሚፈልጉትን ዋጋ በደብተር መመዝገብ',
            ],
            milestoneGoal: 'የ10 ሰዎችን ትክክለኛ የዕቃ ዝርዝር እና የሚጠበቅ ዋጋ ማሰባሰብ (ምንም አይነት ሽያጭ ሳይጠበቅ)።',
          },
          {
            dayNumber: 2,
            dayTitle: 'ቀን 2፦ የቴሌግራም ቻናልና የቴሌብር አካውንት ማዘጋጀት',
            specificActions: [
              'Addis Direct Exchange በሚል ስም ማራኪ የቴሌግራም ቻናል መክፈት',
              'የቴሌብር አካውንት ለኮሚሽን መቀበያ ማዘጋጀትና የአሰራር መመሪያዎችን ማዘጋጀት',
            ],
            milestoneGoal: 'መድረኩን እና የክፍያ መቀበያውን ሙሉ ለሙሉ ዝግጁ ማድረግ።',
          },
          {
            dayNumber: 3,
            dayTitle: 'ቀን 3፦ ጥራት ያላቸው ፎቶዎችን ማንሳት እና መረጃ ማረጋገጥ',
            specificActions: [
              'በተመረጡት 5 እቃዎች ቦታ ድረስ በመሄድ በደማቅ ብርሃን ጥራት ያላቸው ፎቶዎችን ማንሳት',
              'የእቃውን ትክክለኛ ጉድለት እና የጥራት ደረጃ በግልጽ አስፍሮ ቻናሉ ላይ መለጠፍ',
            ],
            milestoneGoal: 'የመጀመሪያዎቹን 5 የተረጋገጡ እቃዎች በካታሎግ ማቅረብ።',
          },
          {
            dayNumber: 4,
            dayTitle: 'ቀን 4፦ ቻናሉን ለከተማ ነዋሪዎችና ለግሩፖች ማስተዋወቅ',
            specificActions: [
              'የቻናሉን ሊንክ በአካባቢው የኮንዶሚኒየም ቴሌግራም እና ፌስቡክ ግሩፖች ማጋራት',
              'የመጀመሪያዎቹን 5 እቃዎች ዜሮ የደላላነት ክፍያ ማስተዋወቂያ ማድረግ',
            ],
            milestoneGoal: 'ቻናሉን ቢያንስ 150 እውነተኛ የሰፈር ተከታዮች እንዲያገኝ ማድረግ።',
          },
          {
            dayNumber: 5,
            dayTitle: 'ቀን 5፦ የገዢዎች ጥያቄዎችን ማስተናገድና የደህንነት ማጣራት',
            specificActions: [
              'የደወሉ ገዢዎችን ማንነት እና ስልክ ቁጥር ማረጋገጥ',
              'የእቃውን ዝርዝር መረጃ ሰጥቶ ተስማሚ የፍተሻ ቀጠሮ ማመቻቸት',
            ],
            milestoneGoal: 'ቢያንስ 3 አስተማማኝ የገዢና ሻጭ የእቃ መመልከቻ ቀጠሮዎችን መያዝ።',
          },
          {
            dayNumber: 6,
            dayTitle: 'ቀን 6፦ የቦታው ላይ እቃ ፍተሻና የሁኔታዎች ማረጋገጫ (Inspection)',
            specificActions: [
              'በቀጠሮው መሰረት በደህንነቱ በተጠበቀ የህዝብ ቦታ ወይም በሻጩ ቤት ተገኝቶ እቃውን ለገዢው ማሳየት',
              'ገዢው እቃውን ፈትሾ ዋጋ እንዲደራደር ማገዝ (ማሳሰቢያ፦ ሽያጩ ወዲያውኑ ይጠናቀቃል ተብሎ አይጠበቅም)',
            ],
            milestoneGoal: 'የመጀመሪያዎቹን የፊት-ለፊት የእቃ ፍተሻዎች በተሳካ ሁኔታ ማስተባበር።',
          },
          {
            dayNumber: 7,
            dayTitle: 'ቀን 7፦ የሳምንቱ ግምገማ፣ የደንበኞች አስተያየትና የቀጣይ ሳምንት ዝግጅት',
            specificActions: [
              'ከሻጮች እና ከገዢዎች የተሰጡ አስተያየቶችን መገምገም እና የዋጋ ማስተካከያ ማድረግ',
              'ቀጣይ የሚሸጡ 10 አዳዲስ እቃዎችን ከጎረቤቶች መመዝገብ',
            ],
            milestoneGoal: 'የ7 ቀን የስራ ሂደቱን መገምገም እና ለሳምንት 2 የሽያጭ መስመር ማዘጋጀት።',
          },
        ],
        safetyAndVerification: {
          buyerVerificationSteps: [
            'የገዢውን ትክክለኛ ስም፣ ንቁ የሞባይል ስልክ ቁጥር እና የመኖሪያ አካባቢ ቀድሞ መመዝገብ።',
            'ትላልቅ የኤሌክትሮኒክስ ወይም የቤት እቃዎችን ለመመልከት ሲመጡ የኢትዮጵያ ዲጂታል መታወቂያ (Fayda ID) ወይም የቀበሌ መታወቂያ እንዲያሳዩ ማድረግ።',
            'በስልክ ደውለው በእርግጥ እቃውን የመግዛት ፍላጎት ያላቸው መሆኑን አስቀድሞ ማረጋገጥ።',
          ],
          sellerVerificationSteps: [
            'የእቃውን የባለቤትነት ማረጋገጫ መጠየቅ፦ ለስልኮችና ላፕቶፖች ዋና ደረሰኝ (Receipt) ወይም የኦሪጅናል እቃ ሳጥን መመልከት፤ ለቤት እቃዎች የገዙበትን ታሪክ ማጣራት።',
            'የመሳሪያውን ተከታታይ ቁጥር (Serial Number / IMEI) መመዝገብና የተሰረቀ አለመሆኑን ማረጋገጥ።',
            'የእቃውን እውነተኛ ሁኔታ (ጉድለቶች፣ ብልሽቶች፣ የቀለም መላጥ) በግልጽ በካሜራ መቅረጽ።',
          ],
          fraudPreventionGuidelines: [
            'የእቃ ርክክብ ሁልጊዜ በደማቅ የቀን ብርሃን፣ ሰዎች በሚበዙባቸው የታወቁ ህዝባዊ ቦታዎች (እንደ ባንክ ግቢ፣ የኢትዮ ቴሌኮም አገልግሎት መስጫ፣ ታዋቂ ካፌዎች) ብቻ መፈጸም አለበት።',
            'ገዢው እቃውን በአካል አይቶና ፈትሾ ሳያረጋግጥ በቅድሚያ ምንም አይነት ገንዘብ ወደ ሻጭ ወይም ወደ አማላጅ እንዳይልኩ በጥብቅ ማስጠንቀቅ።',
            'ሀሰተኛ የባንክ ወይም የቴሌብር SMS ማረጋገጫ መልእክቶችን መጠንቀቅ፤ ክፍያው በራስዎ መተግበሪያ ሂሳብ ውስጥ ገቢ መሆኑን ሳያረጋግጡ እቃውን አለመልቀቅ።',
          ],
          legalPaymentCompliance:
            'ህጋዊ የክፍያ ደንብ ማሳሰቢያ፦ አማላጁ የደንበኞችን ገንዘብ በእጁ ወይም በግል ባንክ/ቴሌብር አካውንቱ "ኤስክሮው (Escrow)" በሚል ሰበብ መያዝ በኢትዮጵያ የፋይናንስ ህግ ያልተፈቀደና አደገኛ አሰራር ነው። ገዢው እቃውን በአካል ተመልክቶ ሲያረጋግጥ ክፍያውን በቀጥታ በቴሌብር ወይም በንግድ ባንክ (CBE Birr) ለሻጩ መለያ ያስተላልፋል፤ ሻጩም የደላላውን የተስማማበትን 10% ኮሚሽን ወዲያውኑ በቴሌብር ለአማላጁ ይከፍላል።',
        },
        skillsAndResources: {
          requiredSkills: [
            'የስማርትፎን ፎቶግራፍ እና የማስታወቂያ አጻጻፍ',
            'የሽያጭ ድርድር እና ደንበኛ አያያዝ',
            'የቴሌግራም ግብይት እና የቴሌብር ክፍያ አያያዝ',
          ],
          physicalEquipment: ['ጥራት ያለው ስማርትፎን', 'የመለኪያ ሜትር (ለቤት እቃዎች)', 'የደረሰኝ ደብተር'],
          digitalTools: ['የቴሌግራም ቻናልና ቦት', 'Telebirr (ቴሌብር)', 'CBE Birr'],
        },
        risksAndMitigations: [
          {
            risk: 'ሻጩ እቃው ከተሸጠ በኋላ ኮሚሽን አለመክፈል ወይም ማዘግየት',
            mitigation: 'በርክክቡ ወቅት በቦታው ተገኝቶ ገዢው ክፍያውን ለሻጩ ሲፈጽም ወዲያውኑ የኮሚሽን ክፍያን በቴሌብር መቀበል።',
          },
          {
            risk: 'እቃው ብልሽት እያለበት ገዢው መመለስ መፈለጉ',
            mitigation: 'እቃው ከመለጠፉ በፊት በቦታው ተገኝቶ መፈተሽ እና ጉድለት ካለበት በግልጽ አስቀድሞ መግለፅ።',
          },
          {
            risk: 'ተፎካካሪ ቻናሎች መብዛት',
            mitigation: 'በፈጣን የቤት አቅርቦት፣ በታማኝነት እና በሰፈር ደረጃ ፈጣን ምላሽ በመስጠት የበላይነት መያዝ።',
          },
        ],
        marketDemandTests: [
          {
            testMethod: 'የ5 እቃዎች የሙከራ ማስታወቂያ (Pilot Listing Test)',
            howToConduct:
              'ምንም ገንዘብ ሳያወጡ የጓደኞችዎን 5 የሚሸጡ እቃዎች ፎቶ አንስተው በቴሌግራም ግሩፕ ላይ ይለጥፉ እና በ24 ሰዓት ውስጥ የሚደውሉ ሰዎችን ይቁጠሩ።',
            successSignal: 'በ24 ሰዓት ውስጥ ቢያንስ 4 ገዢዎች ደውለው ዋጋና አድራሻ ሲጠይቁ።',
          },
          {
            testMethod: 'የቅድመ-ቀጠሮ ፍላጎት ሙከራ (Pre-Viewing Commitment Test)',
            howToConduct:
              'ለደወለው ገዢ "እቃውን ነገ ከሰዓት 10 ሰዓት በአካል ለማየት መምጣት ይችላሉ?" ብለው ይጠይቁ።',
            successSignal: 'ቢያንስ 2 ገዢዎች የቀጠሮ ሰዓት እና ቦታ አረጋግጠው ሲስማሙ።',
          },
        ],
        validationStatus: {
          isHypothesis: true,
          evidenceStatement:
            'ማሳሰቢያ፦ ይህ የንግድ መፍትሄ በመላ-ምት ላይ የተመሰረተ ነው። በ7ቱ ቀናት የተግባር እቅድ ውስጥ የተዘረዘሩትን የገበያ ፍላጎት ማረጋገጫዎች ሳያደርጉ ምንም አይነት ገንዘብ በግዢ ላይ እንዳያውሉ!',
        },
        marketOpportunity: 'በአዲስ አበባ የተከማቹ ያገለገሉ እቃዎችን ወደ ፈጣን ጥሬ ገንዘብ የመቀየር ትልቅ የገበያ ፍላጎት አለ።',
        proposedSolution: 'ቴሌግራም ላይ የተመሰረተ የታመነ የዕቃ አማላጅነት እና የፎቶ ካታሎግ (Telegram Verified Brokerage)',
        monetizationModel: ['ከተፈጸመ ሽያጭ የሚገኝ 10% ኮሚሽን', 'የልዩ ማስታወቂያ ክፍያ (50 ETB)'],
        stepByStepPlan: [
          { phase: 'ምዕራፍ 1፦ እቃዎችን ማሰባሰብ', duration: 'ቀን 1-2', actions: ['10 ሻጮችን ማነጋገር', 'ቻናል መክፈት'] },
          { phase: 'ምዕራፍ 2፦ ማስተዋወቅና ማገናኘት', duration: 'ቀን 3-5', actions: ['ፎቶ መለጠፍ', 'ገዢዎችን መያዝ'] },
          { phase: 'ምዕራፍ 3፦ ርክክብና ትርፍ', duration: 'ቀን 6-7', actions: ['እቃዎችን ማሳየት', 'ሳምንቱን መገምገም'] },
        ],
        requiredSkills: ['ፎቶግራፍ', 'የሽያጭ ድርድር', 'ቴሌብር'],
        estimatedStartupBudget: '12,000 - 24,000 ETB',
        keyRisksAndMitigations: [{ risk: 'የኮሚሽን አለመክፈል', mitigation: 'በርክክብ ወቅት ወዲያውኑ በቴሌብር መቀበል' }],
        immediateNext24Hours: 'ዛሬውኑ የሚሸጥ እቃ ያላቸውን 3 ጎረቤቶች ወይም ጓደኞች አነጋግረው ፎቶ አንሱ።',
      };
    } else {
      return {
        originalProblem: problem,
        category: category || 'Services & Marketplace',
        language,
        opportunityTitle: 'Addis Direct Goods Resale & Brokerage Hub',
        tagline: 'Connecting secondhand household and office goods sellers with verified buyers across Addis Ababa.',
        problemAnalysis: {
          exactProblemBreakdown:
            'Residents and small businesses across Addis Ababa struggle to find reliable buyers for used furniture, electronics, and surplus inventory. Existing channels are fragmented and plagued by safety and trust concerns.',
          rootCauses: [
            'Absence of verified hyperlocal brokerage that inspects goods and handles secure payments',
            'High transaction friction and transport expenses across city zones',
            'Seller hesitation with unvetted strangers and scam fears',
          ],
          currentCostOfInaction:
            'Millions of ETB in functional assets depreciate unused in residences and storerooms, depriving sellers of immediate liquidity.',
        },
        affectedAndCustomers: {
          affectedDemographics:
            'Apartment dwellers, relocating expats, university graduates, and small office founders in Addis Ababa.',
          payingCustomers: [
            'Relocating residents needing to liquidate household items in 48 hours',
            'Budget-conscious families and students seeking inspected quality furniture/appliances',
            'Emerging startups purchasing refurbished office equipment',
          ],
          whyTheyWillPay:
            'Sellers gladly pay 10-15% commission for hassle-free liquidation and verified Telebirr payment. Buyers pay for verified quality without endless market searches.',
        },
        candidateSolutions: [
          {
            id: 'sol_1',
            title: 'Telegram Verified Brokerage & Photo Catalog',
            modelSummary: 'Photographing seller items on-site, broadcasting to targeted Addis Telegram channels, taking 10% commission on deal close.',
            pros: ['Zero warehouse lease cost', 'Immediate 2-day launch', 'Cashflow positive from day 1'],
            cons: ['Requires daily city travel for inspections'],
            operationalComplexity: 'Low',
          },
          {
            id: 'sol_2',
            title: 'Condominium Weekend Pop-Up Bazaars',
            modelSummary: 'Organizing weekend yard markets inside gated residential condominium compounds.',
            pros: ['Direct in-person cash transactions', 'High volume per event'],
            cons: ['Compound committee permits and space agreements needed'],
            operationalComplexity: 'Medium',
          },
          {
            id: 'sol_3',
            title: 'Instant Cash Buyout & Refurbishment Center',
            modelSummary: 'Purchasing items at 50% discount for instant cash, cleaning them, and reselling at market rates.',
            pros: ['Highest profit margin per item', 'Total pricing control'],
            cons: ['Requires substantial working capital and storage depot'],
            operationalComplexity: 'High',
          },
        ],
        recommendedSolution: {
          solutionTitle: 'Telegram Verified Brokerage & Photo Catalog',
          selectionRationale:
            'Requires zero inventory investment and zero warehouse overhead. Generates immediate cashflow on closing with digital Telebirr settlement.',
          howItWorksInPractice:
            'Sellers contact you via Telegram or phone. You verify and photograph their items, publish with price and location, collect buyer inquiries, coordinate safe public inspection, and receive a 10% commission via Telebirr upon completed exchange.',
        },
        startupBudget: {
          totalEstimatedETB: '12,000 - 24,000 ETB',
          lineItems: [
            { item: 'Smartphone camera and mobile data package', costETB: '8,000 ETB', essential: true },
            { item: 'Telegram channel branding and local promo', costETB: '3,000 ETB', essential: true },
            { item: 'Telebirr merchant integration and municipal registration', costETB: '2,500 ETB', essential: true },
            { item: 'Local ride/taxi transport budget', costETB: '3,500 ETB', essential: true },
            { item: 'Contingency emergency buffer', costETB: '3,000 ETB', essential: false },
          ],
          lowCapitalTip: 'Have sellers take well-lit standard photos to eliminate initial travel costs.',
          zeroBudgetOption: {
            howToLaunchWithZeroBirr:
              'Bootstrapping with 0 ETB: Launch a free Telegram channel using your existing smartphone. Require sellers to send standardized daylight photos and videos with receipts. Distribute verified listings across free local condominium and neighborhood Facebook and Telegram community groups without paid ads.',
            tradeOffs:
              'Zero capital means you cannot run sponsored ads or print physical cards; you must substitute financial investment with intense manual outreach, high-touch personal networking, and diligent direct messaging.',
          },
        },
        incomeModel: {
          revenueStreams: [
            '10% - 12% brokerage commission on closed deals',
            '50 ETB premium spotlight fee for urgent broadcast',
            'In-person handover and inspection coordination fee (100 - 150 ETB)',
          ],
          pricingStrategyETB: 'Average item price: 4,500 ETB; 10% commission = 450 ETB per completed deal',
          paymentMethods: ['Telebirr Merchant', 'CBE Birr', 'Cash on Handover'],
        },
        financialEstimates: {
          estimatedMonthlyRevenueETB: '28,000 - 48,000 ETB (Estimated)',
          estimatedMonthlyExpensesETB: '7,000 - 12,000 ETB (Estimated)',
          estimatedMonthlyNetETB: '21,000 - 36,000 ETB (Estimated)',
          expenseBreakdown: [
            'Local transport / taxi allowance: 4,500 ETB/mo',
            'Mobile 4G data & phone cards: 2,000 ETB/mo',
            'Promotional flyers & digital graphics: 2,500 ETB/mo',
          ],
          disclaimer:
            'FINANCIAL NOTICE: These revenue figures are model projections, not guaranteed cash flow. Actual revenue is contingent on seller responsiveness, item quality, and buyer purchasing power.',
          revenueFormula: {
            estimatedSalesCount: 25,
            averageTransactionValueETB: 4500,
            commissionRatePercent: 10,
            listingFeeETB: 50,
            listingFeeCount: 30,
            calculationExplanation:
              '(25 sales transactions × 4,500 ETB average value × 10% commission = 11,250 ETB) + (30 featured listings × 50 ETB = 1,500 ETB) + coordination fees = ~13,500 ETB month 1 baseline. As inventory volume scales to 45 deals/month, revenue expands to 35,000+ ETB.',
          },
          factsConfirmed: [
            'Telebirr and CBE Birr are ubiquitous, legally recognized, near-instant payment rails across Addis Ababa.',
            'High resale demand exists in Addis Ababa condominiums (e.g. Ayat, Jomo, Bole Arabsa) for used furniture, refrigerators, and laptops.',
            'Ethio Telecom data and voice call tariff packages are documented fixed costs.',
          ],
          assumptionsAndEstimates: [
            'Assumed conversion rate: 3 out of every 10 listed items find an interested buyer within 14-21 days.',
            'Assumed average ticket size of 4,500 ETB per transaction.',
            'Assumed buyers and sellers honor the agreed 10% brokerage commission without dispute.',
          ],
        },
        sevenDayActionPlan: [
          {
            dayNumber: 1,
            dayTitle: 'Day 1: Survey 10 Sellers & Price Mapping',
            specificActions: [
              'Interview 10 acquaintances and neighbors with unused household or office goods',
              'Record exact descriptions, condition notes, and reserve pricing in a master spreadsheet',
            ],
            milestoneGoal: 'Document 10 genuine available items without promising immediate sales.',
          },
          {
            dayNumber: 2,
            dayTitle: 'Day 2: Telegram Channel & Telebirr Setup',
            specificActions: [
              'Launch a branded Telegram channel with verification guidelines',
              'Configure Telebirr merchant/personal recipient account and publish transaction rules',
            ],
            milestoneGoal: 'Digital storefront and payment infrastructure operational.',
          },
          {
            dayNumber: 3,
            dayTitle: 'Day 3: Photo Verification & Detailed Cataloging',
            specificActions: [
              'Photograph 5 vetted items under clear daylight or verify seller video submissions',
              'Publish catalog posts with explicit condition ratings, serial checks, and neighborhood zones',
            ],
            milestoneGoal: 'Publish 5 verified listings to the catalog.',
          },
          {
            dayNumber: 4,
            dayTitle: 'Day 4: Hyperlocal Community Distribution',
            specificActions: [
              'Share channel links in neighborhood WhatsApp/Telegram groups with zero-commission intro offer',
              'Engage condominium residents seeking furnished items',
            ],
            milestoneGoal: 'Acquire at least 150 local community members.',
          },
          {
            dayNumber: 5,
            dayTitle: 'Day 5: Buyer Inquiries & Safety Screening',
            specificActions: [
              'Screen interested buyers by phone to verify intent and identity',
              'Schedule daylight viewing appointments in secure public locations',
            ],
            milestoneGoal: 'Confirm 3 scheduled physical inspection appointments.',
          },
          {
            dayNumber: 6,
            dayTitle: 'Day 6: On-Site Inspection & Trial Negotiations',
            specificActions: [
              'Attend inspection with buyer and seller at agreed daylight meeting point',
              'Guide functional testing of the item without promising instant payment closure',
            ],
            milestoneGoal: 'Complete 2 structured buyer-seller physical inspection sessions.',
          },
          {
            dayNumber: 7,
            dayTitle: 'Day 7: Pipeline Review & Week 2 Growth Strategy',
            specificActions: [
              'Analyze buyer feedback from inspections and adjust seller reserve prices if necessary',
              'Onboard 10 more seller items to maintain active deal pipeline',
            ],
            milestoneGoal: 'Establish a rolling pipeline of 5 qualified deals for week 2 closing.',
          },
        ],
        safetyAndVerification: {
          buyerVerificationSteps: [
            'Screen buyers via verified active mobile phone numbers before sharing seller contact or coordinating viewings.',
            'Request government ID (Ethiopian Digital Fayda ID or Kebele ID) before high-value electronics or vehicle transactions.',
            'Confirm purchase intent and financing readiness before scheduling in-person meetings.',
          ],
          sellerVerificationSteps: [
            'Require proof of ownership (original retail purchase receipt, warranty card, or retail packaging for electronics).',
            'Record and verify serial numbers / IMEI numbers to ensure goods are not reported stolen.',
            'Perform a comprehensive physical condition checklist, documenting scratches, dents, or operational defects before publishing.',
          ],
          fraudPreventionGuidelines: [
            'Always conduct physical viewings and item handovers during daylight hours in well-lit public facilities (e.g. CBE bank branch lobbies, Ethio Telecom centers, or staffed cafes).',
            'STRICT RULE: Buyers must NEVER transfer advance deposits before physically inspecting and testing the item in person.',
            'Guard against fake SMS bank alerts: Always verify transaction credit inside your authentic Telebirr or CBE Birr mobile app before concluding the handover.',
          ],
          legalPaymentCompliance:
            'LEGAL PAYMENT MANDATE: Intermediaries MUST NOT collect, pool, or hold customer purchase funds in personal bank or Telebirr accounts under the guise of an informal "escrow". Doing so violates National Bank of Ethiopia financial regulations. Buyers must settle payment directly to the verified seller via Telebirr or CBE Birr upon successful physical inspection and handover. The founder receives their agreed 10% brokerage commission directly from the seller upon deal completion, or points parties to a licensed financial institution.',
        },
        skillsAndResources: {
          requiredSkills: ['Product Photography', 'Deal Negotiation', 'Telebirr Operations'],
          physicalEquipment: ['Smartphone with good camera', 'Measuring tape', 'Receipt booklet'],
          digitalTools: ['Telegram Channel', 'Telebirr', 'Google Maps'],
        },
        risksAndMitigations: [
          { risk: 'Seller bypassing commission after deal close', mitigation: 'Attend the handover meeting in person and collect the 10% commission via Telebirr upon the buyer transferring settlement.' },
          { risk: 'Hidden item defects upon handover', mitigation: 'Personally inspect functional items before listing or require video proof.' },
          { risk: 'Competitor replication', mitigation: 'Build defensibility through prompt customer service, verified reputation tags, and transparent fee structures.' },
        ],
        marketDemandTests: [
          { testMethod: '5-Item Pilot Test', howToConduct: 'Post 5 friend items for free in local groups and track buyer response within 24 hours.', successSignal: 'At least 4 prospective buyers contact you.' },
          { testMethod: 'Inspection Appointment Test', howToConduct: 'Ask prospective buyer: "Can you attend a physical inspection tomorrow at 4 PM at the local bank lobby?"', successSignal: 'At least 2 buyers confirm specific attendance times.' },
        ],
        validationStatus: {
          isHypothesis: true,
          evidenceStatement:
            'NOTICE: Market demand in this blueprint is an unproven hypothesis. Complete the 5-item pilot test and inspection validation before spending money on marketing or transit.',
        },
        marketOpportunity: 'High turnover of residential assets across Addis Ababa provides continuous daily transaction volume.',
        proposedSolution: 'Telegram Verified Brokerage & Photo Catalog',
        monetizationModel: ['10-15% closed sale commission', '50-100 ETB urgent listing fee'],
        stepByStepPlan: [
          { phase: 'Phase 1: Catalog', duration: 'Day 1-2', actions: ['Survey sellers', 'Open channel'] },
          { phase: 'Phase 2: Distribution', duration: 'Day 3-5', actions: ['Post listings', 'Promote'] },
          { phase: 'Phase 3: Close', duration: 'Day 6-7', actions: ['Facilitate handover', 'Collect commission'] },
        ],
        requiredSkills: ['Sales', 'Photography', 'Telebirr'],
        estimatedStartupBudget: '12,000 - 24,000 ETB',
        keyRisksAndMitigations: [{ risk: 'Commission evasion', mitigation: 'Telebirr escrow' }],
        immediateNext24Hours: 'Contact 3 friends today who have unused goods and take photos of items to sell.',
      };
    }
  }

  // Universal Problem-to-Opportunity Engine (Specific, Non-Generic, Ethiopian Context)
  const categoryLabel = category || 'Community Enterprise';

  if (isAm) {
    return {
      originalProblem: problem,
      category: categoryLabel,
      language,
      opportunityTitle: `የ${categoryLabel} ተግባራዊ የንግድ መፍትሄ`,
      tagline: 'ያስተዋሉትን የአካባቢውን ችግር ወደ አስተማማኝ የቀን ገቢ እና የስራ ዕድል መቀየር።',
      problemAnalysis: {
        exactProblemBreakdown: `ያቀረቡት ችግር፦ "${problem.trim()}"። ይህ ችግር በህብረተሰቡ የዕለት ተዕለት እንቅስቃሴ ውስጥ ከፍተኛ ጊዜ፣ ጉልበትና ገንዘብ እንዲባክን የሚያደርግ ትልቅ የአሰራር እና የአቅርቦት ክፍተት ነው። አብዛኛው ሰው ችግሩ ቢኖርበትም አማራጭ የተደራጀ መፍትሄ በማጣቱ ያለውን ችግር ተቀብሎ ለመኖር ይገደዳል።`,
        rootCauses: [
          'በአካባቢው ህብረተሰብ እና በአገልግሎት ሰጪዎች መካከል ቀጥተኛና የታመነ የመረጃ ትስስር አለመኖር',
          'አሁን ያሉት አማራጮች በጣም ውድ፣ የዘገዩ ወይም ጥራታቸው ያልተረጋገጠ መሆን',
          'ዘመናዊ አሰራርን (እንደ ቴሌብር እና ስልክ) በመጠቀም ችግሩን በቅልጥፍና የሚፈታ አካል አለመኖር',
        ],
        currentCostOfInaction:
          'ሰዎች ችግሩን በራሳቸው ለመፍታት በየወሩ ከፍተኛ ሰዓታትን እና አላስፈላጊ ተጨማሪ ክፍያዎችን በከንቱ ያባክናሉ።',
      },
      affectedAndCustomers: {
        affectedDemographics:
          'በአዲስ አበባ እና በዋና ዋና ከተሞች የሚኖሩ ነዋሪዎች፣ የኮንዶሚኒየም ማህበረሰቦች እና አነስተኛ የንግድ ተቋማት።',
        payingCustomers: [
          'ጊዜ ቆጣቢ እና አስተማማኝ መፍትሄ የሚፈልጉ የከተማ ነዋሪዎች እና ቤተሰቦች',
          'ተጨማሪ ገቢ የሚያስፈልጋቸው የእጅ ባለሙያዎች ወይም ወጣቶች',
          'የስራ ቅልጥፍናቸውን ማሳደግ የሚፈልጉ አነስተኛ ድርጅቶች',
        ],
        whyTheyWillPay:
          'ችግሩን በራሳቸው ከመፍታት ይልቅ በተመጣጣኝ ክፍያ በአስተማማኝ ሁኔታ ማከናወን ስለሚያስችላቸው።',
      },
      candidateSolutions: [
        {
          id: 'sol_1',
          title: 'በቀጥታ የሚሰጥ የአካባቢ አገልግሎት (Hyperlocal Service Hub)',
          modelSummary: 'በቴሌግራም ወይም በስልክ ጥሪ አማካኝነት ችግሩን በሰፈር ደረጃ ፈጣን አገልግሎት በመስጠት መፍታት።',
          pros: ['ዝቅተኛ መነሻ ወጪ', 'በአንድ ሳምንት ውስጥ መጀመር መቻሉ', 'ቀጥተኛ የደንበኛ ግንኙነት'],
          cons: ['በመጀመሪያው ወቅት በእጅ የሚሰራ ስራ መብዛቱ'],
          operationalComplexity: 'Low',
        },
        {
          id: 'sol_2',
          title: 'የአጋሮችና ባለሙያዎች አገናኝ መድረክ (Commission-Based Marketplace)',
          modelSummary: 'ችግሩን መፍታት የሚችሉ ባለሙያዎችን መዝግቦ ጥራታቸውን በማረጋገጥ ለደንበኞች በኮሚሽን ማገናኘት።',
          pros: ['የእቃ ግዢ ካፒታል አይጠይቅም', 'ቀላል የማስፋፊያ ዕድል አለው'],
          cons: ['የባለሙያዎችን ታማኝነት በየጊዜው መቆጣጠር ይጠይቃል'],
          operationalComplexity: 'Medium',
        },
        {
          id: 'sol_3',
          title: 'የተሟላ የደንበኝነት አገልግሎት (Monthly Retainer / Package)',
          modelSummary: 'ለኮንዶሚኒየም ወይም ለንግድ ቤቶች ወርሃዊ ቋሚ ክፍያ በመቀበል ችግሩን በዘላቂነት ማስተናገድ።',
          pros: ['ቋሚና አስተማማኝ ወርሃዊ ገቢ ያስገኛል', 'የደንበኛ ታማኝነት ይፈጥራል'],
          cons: ['የተሟላ ቡድን እና ቋሚ ሰራተኛ ይፈልጋል'],
          operationalComplexity: 'High',
        },
      ],
      recommendedSolution: {
        solutionTitle: 'በቀጥታ የሚሰጥ የአካባቢ አገልግሎት (Hyperlocal Service Hub)',
        selectionRationale:
          'በኢትዮጵያ ነባራዊ ሁኔታ ትላልቅ መተግበሪያዎችን ከመገንባት ይልቅ በቴሌግራም ቦት፣ በስልክ ጥሪ እና በቴሌብር ክፍያ የሚሰራ ቀላል አሰራር መዘርጋት ወዲያውኑ ገቢ ማስገኘት የሚያስችል በጣም ተግባራዊ አማራጭ ነው።',
        howItWorksInPractice:
          'ደንበኞች አገልግሎቱን በስልክ ወይም በቴሌግራም ይጠይቃሉ፤ ክፍያው በቴሌብር ይፈጸማል፤ ስራው ወዲያውኑ ተጠናቆ ደረሰኝ ይሰጣቸዋል።',
      },
      startupBudget: {
        totalEstimatedETB: '15,000 - 32,000 ETB',
        lineItems: [
          { item: 'የመጀመሪያ ደረጃ መሳሪያዎች ወይም ግብአቶች', costETB: '8,000 ETB', essential: true },
          { item: 'የማስተዋወቂያ በራሪ ወረቀቶች እና የቴሌግራም ማስታወቂያ', costETB: '2,500 ETB', essential: true },
          { item: 'የቴሌብር ነጋዴ አካውንት እና የወረዳ ንግድ ፍቃድ', costETB: '2,500 ETB', essential: true },
          { item: 'የትራንስፖርት እና የኮሚኒኬሽን መነሻ በጀት', costETB: '2,000 ETB', essential: true },
          { item: 'የአስቸኳይ ጊዜ መጠባበቂያ (Contingency Buffer)', costETB: '3,000 ETB', essential: false },
        ],
        lowCapitalTip: 'መጀመሪያ ላይ የቢሮ ኪራይ ውስጥ ሳያስፈልግ ከቤት ወይም በሞባይል በመስራት ወጪን በትንሹ መያዝ ይቻላል።',
      },
      incomeModel: {
        revenueStreams: [
          'የቀጥታ የአገልግሎት ክፍያ (እንደ ስራው ስፋት ከ150 እስከ 500 ብር)',
          'ወርሃዊ የቋሚ ደንበኞች ቅናሽ ጥቅል (Monthly Retainer)',
          'ልዩ የፈጣን አገልግሎት ተጨማሪ ክፍያ (Express Service Surcharge)',
        ],
        pricingStrategyETB: 'አማካይ የአገልግሎት ዋጋ፦ 250 ETB በአንድ ትዕዛዝ (በቀን 4 ትዕዛዞች = 1,000 ETB)',
        paymentMethods: ['Telebirr (ቴሌብር)', 'CBE Birr', 'ጥሬ ገንዘብ (Cash)'],
      },
      financialEstimates: {
        estimatedMonthlyRevenueETB: '25,000 - 45,000 ETB (ግምታዊ)',
        estimatedMonthlyExpensesETB: '7,000 - 12,000 ETB (ግምታዊ)',
        estimatedMonthlyNetETB: '18,000 - 33,000 ETB (ግምታዊ)',
        expenseBreakdown: [
          'የትራንስፖርት እና የታክሲ ወጪ፦ 4,000 ETB/ወር',
          'የስልክ እና የኢንተርኔት ካርድ፦ 1,500 ETB/ወር',
          'ግብአቶች እና የህትመት ወጪ፦ 2,500 ETB/ወር',
        ],
        disclaimer:
          'ማሳሰቢያ፦ ይህ የገንዘብ ግምት የተመሰረተው በቀን 3-5 ደንበኞችን በማገልገል ላይ ሲሆን በገበያ ፍላጎትና በትጋት መጠን ሊለያይ ይችላል።',
      },
      sevenDayActionPlan: [
        {
          dayNumber: 1,
          dayTitle: 'ቀን 1፦ ችግሩ ያለባቸውን 10 ሰዎች ማነጋገር',
          specificActions: [
            'በሰፈር ወይም በስራ ቦታ ይህ ችግር የሚያጋጥማቸውን 10 ሰዎች ማግኘት',
            'ችግሩን ለመፍታት ምን ያህል ገንዘብ ለመክፈል እንደሚችሉ በትክክል መመዝገብ',
          ],
          milestoneGoal: 'የ10 ሰዎችን ግልጽ ፍላጎትና የዋጋ ተመን መረዳት።',
        },
        {
          dayNumber: 2,
          dayTitle: 'ቀን 2፦ አሁን ያሉ አማራጮችን መገምገም',
          specificActions: [
            'ሌሎች ሰዎች ይህንን ችግር እንዴት እንደሚፈቱት ማየት',
            'የእነሱን ድክመትና ጉድለት መለየት',
          ],
          milestoneGoal: 'የእርስዎን ልዩ የመፍትሄ መንገድ መወሰን።',
        },
        {
          dayNumber: 3,
          dayTitle: 'ቀን 3፦ ባለ 1-ገጽ የአገልግሎት ማስታወሻ ማዘጋጀት',
          specificActions: [
            'ቀለል ያለ የማስተዋወቂያ ጽሑፍ በስልክ ወይም በወረቀት ማዘጋጀት',
            'የዋጋ ዝርዝርና የስልክ ቁጥር ማስቀመጥ',
          ],
          milestoneGoal: 'ማስተዋወቂያውን ማጠናቀቅ።',
        },
        {
          dayNumber: 4,
          dayTitle: 'ቀን 4፦ የቅድመ-ትዕዛዝ ፍላጎት ሙከራ (Smoke Test)',
          specificActions: [
            'ማስታወቂያውን ለ20 ሰዎች ወይም በሰፈር ቴሌግራም ግሩፕ ማጋራት',
            'የመጀመሪያዎቹን አገልግሎቶች በቅናሽ ዋጋ ማቅረብ',
          ],
          milestoneGoal: 'ቢያንስ 3 የቅድመ-አገልግሎት ፍላጎት ማረጋገጫ ማግኘት።',
        },
        {
          dayNumber: 5,
          dayTitle: 'ቀን 5፦ አስፈላጊ እቃዎችንና ቴሌብርን ማዘጋጀት',
          specificActions: [
            'አስፈላጊ የሆኑትን አነስተኛ መሳሪያዎች መግዛት ወይም መዋስ',
            'የቴሌብር አካውንት ለክፍያ መቀበያ ዝግጁ ማድረግ',
          ],
          milestoneGoal: 'ስራ ለመጀመር ሙሉ ዝግጅት ማጠናቀቅ።',
        },
        {
          dayNumber: 6,
          dayTitle: 'ቀን 6፦ የመጀመሪያውን የሙከራ ስራ ማከናወን',
          specificActions: [
            'ለተመዘገቡት 2 ደንበኞች ስራውን በከፍተኛ ጥራት ሰርቶ ማጠናቀቅ',
            'አስተያየትና ምስክርነት (Feedback) መመዝገብ',
          ],
          milestoneGoal: 'የመጀመሪያውን ስራ በተሳካ ሁኔታ ማስረከብ።',
        },
        {
          dayNumber: 7,
          dayTitle: 'ቀን 7፦ ክፍያ መቀበልና ስራውን ማሳደግ',
          specificActions: [
            'የመጀመሪያ ክፍያዎችን መቀበል',
            'የረኩ ደንበኞች ለሌሎች 2 ጓደኞቻቸው እንዲመሰክሩ ማድረግ',
          ],
          milestoneGoal: 'የመጀመሪያውን ትርፍ ማስላትና ቀጣይ እቅድ ማውጣት።',
        },
      ],
      skillsAndResources: {
        requiredSkills: [
          'የችግር መፍታት እና ፈጣን የመግባባት ክህሎት',
          'የሽያጭና የሰው-ለሰው ግንኙነት',
          'መሰረታዊ የቴሌብር እና የሂሳብ አያያዝ',
          'የስራ ጥራት እና የሰዓት አክባሪነት',
        ],
        physicalEquipment: [
          'ስማርትፎን (ጥሪና ቴሌግራም)',
          'እንደ ስራው አይነት የሚፈለጉ አነስተኛ የእጅ መሳሪያዎች',
          'የደረሰኝ እና የመዝገብ ደብተር',
        ],
        digitalTools: [
          'Telebirr (ቴሌብር)',
          'የቴሌግራም ቻናል ወይም ግሩፕ',
          'Google Maps / የአካባቢ አድራሻ መፈለጊያ',
        ],
      },
      risksAndMitigations: [
        {
          risk: 'የመጀመሪያ ደንበኞችን በፍጥነት አለማግኘት',
          mitigation: 'የመጀመሪያዎቹን 5 አገልግሎቶች በቅናሽ ዋጋ በማቅረብ ደንበኞች እንዲሞክሩት ማበረታታት።',
        },
        {
          risk: 'የክፍያ መዘግየት ወይም ያለመክፈል ስጋት',
          mitigation: 'ስራው ከመጀመሩ በፊት 50% ቅድመ-ክፍያ በቴሌብር መቀበል።',
        },
        {
          risk: 'ተፎካካሪዎች አሰራሩን መኮረጅ',
          mitigation: 'በፈጣን ምላሽ፣ በታማኝነት እና በልዩ የደንበኛ አያያዝ የደንበኛ ፍቅር መገንባት።',
        },
      ],
      marketDemandTests: [
        {
          testMethod: 'የቅድመ-ምዝገባ ሙከራ (Pre-Order Test)',
          howToConduct: 'ገንዘብ ሳያወጡ ለ10 ሰዎች "ይህንን ችግር የሚፈታ አገልግሎት ጀምረናል፣ ማክሰኞ ልንጀምርልዎ?" ብሎ መጠየቅ።',
          successSignal: 'ቢያንስ 3 ሰዎች የቀጠሮ ቀን ሲይዙ።',
        },
        {
          testMethod: 'የቴሌግራም የማስታወቂያ ሙከራ (Flyer Smoke Test)',
          howToConduct: 'በሰፈር የቴሌግራም ግሩፕ ላይ ማስታወቂያ ለጥፎ የሚደውሉትን ወይም መልእክት የሚልኩትን መቁጠር።',
          successSignal: 'በ24 ሰዓት ውስጥ ቢያንስ 5 ሰዎች ዋጋ ሲጠይቁ።',
        },
      ],
      validationStatus: {
        isHypothesis: true,
        evidenceStatement:
          'ማስጠንቀቂያ፦ ይህ የንግድ መፍትሄ በመላ-ምት ላይ የተመሰረተ ነው፤ በ7ቱ ቀናት ውስጥ የተዘረዘሩትን የገበያ ሙከራዎች ሳያደርጉ ምንም አይነት ገንዘብ በግዢ ላይ እንዳያውሉ!',
      },
      marketOpportunity: 'በአካባቢው ህብረተሰብ ውስጥ ያለውን ክፍተት ፈጥኖ በመሙላት አስተማማኝ የቀን ገቢ ማግኘት።',
      proposedSolution: 'በቀጥታ የሚሰጥ የአካባቢ አገልግሎት (Hyperlocal Service Hub)',
      monetizationModel: ['የቀጥታ የአገልግሎት ክፍያ', 'የወርሃዊ ደንበኝነት ክፍያ'],
      stepByStepPlan: [
        { phase: 'ምዕራፍ 1፦ ፍላጎት ማረጋገጫ', duration: 'ቀን 1-2', actions: ['10 ሰዎችን ማነጋገር'] },
        { phase: 'ምዕራፍ 2፦ የሙከራ ጅማሮ', duration: 'ቀን 3-5', actions: ['በራሪ ወረቀት ማጋራት', 'ቴሌብር ማዘጋጀት'] },
        { phase: 'ምዕራፍ 3፦ አገልግሎት መስጠት', duration: 'ቀን 6-7', actions: ['የመጀመሪያ ስራ ማከናወን', 'ክፍያ መቀበል'] },
      ],
      requiredSkills: ['የችግር መፍታት', 'የደንበኛ አያያዝ', 'ቴሌብር'],
      estimatedStartupBudget: '15,000 - 32,000 ETB',
      keyRisksAndMitigations: [{ risk: 'የደንበኛ መዘግየት', mitigation: 'የማስተዋወቂያ ቅናሽ መስጠት' }],
      immediateNext24Hours: 'ዛሬውኑ ይህ ችግር የሚያጋጥማቸውን 3 ሰዎችን አግኝተው የታሰበውን መፍትሄ ያብራሩላቸው።',
    };
  }

  return {
    originalProblem: problem,
    category: categoryLabel,
    language,
    opportunityTitle: `${categoryLabel} Practical Venture Solution`,
    tagline: 'Directly converting observed friction into high-demand local service revenue.',
    problemAnalysis: {
      exactProblemBreakdown: `Specific Challenge: "${problem.trim()}". This issue causes recurring loss of productive hours and disposable income for local consumers or businesses in urban and peri-urban Ethiopia. Because prevailing workarounds are informal, disorganized, or overpriced, people endure frustration daily.`,
      rootCauses: [
        'Lack of transparent, verified providers offering predictable turnaround times',
        'Friction in coordinating appointments and negotiating fair prices without being overcharged',
        'Absence of streamlined mobile payment workflows (like Telebirr / CBE Birr) tailored to this specific pain point',
      ],
      currentCostOfInaction:
        'Affected individuals waste hours each week attempting ad-hoc solutions, leading to stress, sub-standard outcomes, and preventable financial leaks.',
    },
    affectedAndCustomers: {
      affectedDemographics:
        'Residents of urban residential hubs (condominiums like Jomo, Ayat, Bole Arabsa in Addis Ababa), families, and local micro-businesses.',
      payingCustomers: [
        'Busy households seeking dependable, vetted solutions with transparent pricing',
        'Local commercial establishments needing fast operational problem resolution',
        'Property and building managers seeking ongoing maintenance partnerships',
      ],
      whyTheyWillPay:
        'They willingly pay a fair flat rate because it eliminates uncertainty, saves hours of phone haggling, and guarantees accountability.',
    },
    candidateSolutions: [
      {
        id: 'sol_1',
        title: 'Hyperlocal Rapid-Response Service (On-Demand Dispatch)',
        modelSummary: 'A phone and Telegram-dispatched service handling orders within a 3-kilometer radius within 90 minutes.',
        pros: ['Extremely low startup friction', 'Can launch in 48 hours', 'Instant word-of-mouth visibility'],
        cons: ['Requires manual scheduling during initial days'],
        operationalComplexity: 'Low',
      },
      {
        id: 'sol_2',
        title: 'Commission-Based Verified Provider Network',
        modelSummary: 'Vetting local artisans or freelancers, establishing uniform pricing cards, and taking a 15-20% broker fee.',
        pros: ['Zero inventory or tool investment required', 'Highly scalable across sub-cities'],
        cons: ['Demands strict quality control over third-party service providers'],
        operationalComplexity: 'Medium',
      },
      {
        id: 'sol_3',
        title: 'Monthly Subscription / Retainer Maintenance Package',
        modelSummary: 'Signing condominium homeowner associations or small clinics on monthly recurring preventative packages.',
        pros: ['Stable recurring monthly cash flow', 'High customer lifetime value'],
        cons: ['Longer sales conversion cycle'],
        operationalComplexity: 'High',
      },
    ],
    recommendedSolution: {
      solutionTitle: 'Hyperlocal Rapid-Response Service (On-Demand Dispatch)',
      selectionRationale:
        'In the Ethiopian context, launching with a tight neighborhood focus using phone and Telegram with Telebirr payments enables you to validate pricing and deliver immediate delight with virtually zero overhead before investing in platforms.',
      howItWorksInPractice:
        'Clients contact you via phone or Telegram bot; you dispatch the solution within a standardized timeframe; clients settle payment immediately via Telebirr merchant QR code, and you log the transaction in your mobile register.',
    },
    startupBudget: {
      totalEstimatedETB: '15,000 - 32,000 ETB',
      lineItems: [
        { item: 'Essential starter tools / initial inventory supplies', costETB: '8,000 ETB', essential: true },
        { item: 'Promotional flyers & neighborhood Telegram channel promotions', costETB: '2,500 ETB', essential: true },
        { item: 'Telebirr merchant activation & local trade registration', costETB: '2,500 ETB', essential: true },
        { item: 'Initial transport & phone communication budget', costETB: '2,000 ETB', essential: true },
        { item: 'Emergency contingency cash buffer', costETB: '3,000 ETB', essential: false },
      ],
      lowCapitalTip: 'Avoid renting a physical storefront initially; operate out of home or mobile backpack setup to preserve capital.',
    },
    incomeModel: {
      revenueStreams: [
        'Direct service fulfillment fee (150 - 450 ETB depending on complexity)',
        'Monthly recurring retainer for repeat apartment clients (700 - 1,200 ETB/mo)',
        'Expedited express dispatch surcharge (100 ETB extra for under-45-minute arrival)',
      ],
      pricingStrategyETB: 'Average transaction fee: 250 ETB (4 completed jobs per day = 1,000 ETB daily gross)',
      paymentMethods: ['Telebirr Merchant', 'CBE Birr', 'Cash on completion'],
    },
    financialEstimates: {
      estimatedMonthlyRevenueETB: '25,000 - 45,000 ETB (Estimated)',
      estimatedMonthlyExpensesETB: '7,000 - 12,000 ETB (Estimated)',
      estimatedMonthlyNetETB: '18,000 - 33,000 ETB (Estimated)',
      expenseBreakdown: [
        'Local transit / fuel / taxi allowance: 4,000 ETB/mo',
        'Mobile airtime & 4G data: 1,500 ETB/mo',
        'Consumables, parts, and promotional prints: 2,500 ETB/mo',
      ],
      disclaimer:
        'NOTE: These financial projections are preliminary estimates based on serving 3-5 clients daily. Real earnings vary depending on market execution and client acquisition velocity.',
    },
    sevenDayActionPlan: [
      {
        dayNumber: 1,
        dayTitle: 'Day 1: Problem Observation & Customer Interviews',
        specificActions: [
          'Interview 10 residents or shopkeepers in your target neighborhood who encounter this problem',
          'Document the highest price they have previously paid and their biggest complaint',
        ],
        milestoneGoal: 'Gather actionable feedback from 10 prospective paying customers.',
      },
      {
        dayNumber: 2,
        dayTitle: 'Day 2: Existing Competitor & Pricing Audit',
        specificActions: [
          'Investigate how the problem is currently addressed by informal operators',
          'Determine where they overcharge or underdeliver',
        ],
        milestoneGoal: 'Establish your unique pricing card and service guarantee.',
      },
      {
        dayNumber: 3,
        dayTitle: 'Day 3: 1-Page Service Menu & Telegram Setup',
        specificActions: [
          'Design a concise, mobile-friendly service flyer with transparent pricing in ETB',
          'Set up a dedicated Telegram contact handle and bio',
        ],
        milestoneGoal: 'Complete professional marketing collateral.',
      },
      {
        dayNumber: 4,
        dayTitle: 'Day 4: Pre-Launch Smoke Test in Local Channels',
        specificActions: [
          'Share the service card with 25 neighbors and post in local neighborhood groups',
          'Offer an introductory 25% discount for the first 5 clients',
        ],
        milestoneGoal: 'Receive at least 3 genuine inquiries or pre-orders.',
      },
      {
        dayNumber: 5,
        dayTitle: 'Day 5: Sourcing Supplies & Payment Setup',
        specificActions: [
          'Purchase essential tool inputs and test Telebirr merchant code reception',
          'Pack a clean operational toolkit',
        ],
        milestoneGoal: '100% operational readiness to service orders.',
      },
      {
        dayNumber: 6,
        dayTitle: 'Day 6: Deliver to First 2 Beta Clients',
        specificActions: [
          'Execute the service for the first 2 booking clients with impeccable quality',
          'Solicit written or voice note reviews immediately upon completion',
        ],
        milestoneGoal: 'Complete first 2 paid transactions with zero defects.',
      },
      {
        dayNumber: 7,
        dayTitle: 'Day 7: Review Feedback & Referral Engine',
        specificActions: [
          'Ask the 2 satisfied clients to recommend you to 2 neighbors for a discount',
          'Calculate Day 6-7 net margins and plan week 2 client acquisition',
        ],
        milestoneGoal: 'Turn first earnings into positive cash flow and 3 referral leads.',
      },
    ],
    skillsAndResources: {
      requiredSkills: [
        'Hands-on problem resolution & customer empathy',
        'Direct local sales and neighborhood relationship management',
        'Telebirr payment tracking and basic ledger bookkeeping',
        'Punctuality and transparent communication',
      ],
      physicalEquipment: [
        'Smartphone with active mobile data',
        'Basic toolkit specific to the domain',
        'Notebook / Receipt book for manual logging',
      ],
      digitalTools: [
        'Telebirr Merchant App',
        'Telegram Channel / Group for Customer Broadcasts',
        'Google Maps or Local Landmark Routing',
      ],
    },
    risksAndMitigations: [
      {
        risk: 'Slow customer adoption in the first 2 weeks',
        mitigation: 'Offer introductory promotional rates and incentivize satisfied clients with referral discounts.',
      },
      {
        risk: 'Non-payment or dispute over scope',
        mitigation: 'Collect a 50% commitment deposit via Telebirr prior to initiating work.',
      },
      {
        risk: 'Price inflation of raw supplies',
        mitigation: 'Source inputs directly from wholesale hubs (such as Merkato in Addis Ababa) rather than retail kiosks.',
      },
    ],
    marketDemandTests: [
      {
        testMethod: 'Pre-Order / Advance Reservation Test',
        howToConduct: 'Before buying equipment, ask 10 target clients: "We are launching this service next Tuesday for 250 ETB—can we book you for a test slot?"',
        successSignal: 'At least 3 clients confirm specific dates or times.',
      },
      {
        testMethod: 'Flyer Smoke Test in Local Groups',
        howToConduct: 'Post your pricing flyer in 2 active neighborhood Telegram groups and track direct inquiries within 24 hours.',
        successSignal: 'At least 5 genuine price inquiries received within 24 hours.',
      },
    ],
    validationStatus: {
      isHypothesis: true,
      evidenceStatement:
        'EVIDENCE NOTICE: Market demand in this blueprint is currently an informed hypothesis based on observed community friction. DO NOT invest money in inventory or equipment until you complete the Day 1-4 validation tests.',
    },
    marketOpportunity: 'Solving persistent daily friction captures immediate local market loyalty.',
    proposedSolution: 'Hyperlocal Rapid-Response Service (On-Demand Dispatch)',
    monetizationModel: ['Direct service fulfillment fees (150-450 ETB)', 'Monthly recurring retainers'],
    stepByStepPlan: [
      { phase: 'Phase 1: Validation', duration: 'Day 1-2', actions: ['Interview 10 residents'] },
      { phase: 'Phase 2: Setup', duration: 'Day 3-5', actions: ['Create flyer', 'Test Telebirr'] },
      { phase: 'Phase 3: Launch', duration: 'Day 6-7', actions: ['Execute first orders', 'Collect payment'] },
    ],
    requiredSkills: ['Problem Solving', 'Customer Care', 'Telebirr Operations'],
    estimatedStartupBudget: '15,000 - 32,000 ETB',
    keyRisksAndMitigations: [{ risk: 'Slow adoption', mitigation: 'Offer introductory discounts' }],
    immediateNext24Hours: 'Talk to 3 people experiencing this issue today and note their feedback.',
  };
}

export function synthesizeBusinessPlan(title: string, description: string, language: Language) {
  const isAm = language === 'am';

  if (isAm) {
    return {
      executiveSummary: `${title} በአካባቢው ገበያ ውስጥ ያለውን ትልቅ ክፍተት በመጠቀም ከፍተኛ ጥራት ያለው ምርትና አገልግሎት በተመጣጣኝ ዋጋ ለደንበኞች የሚያቀርብ አዲስ የንግድ ተነሳሽነት ነው።`,
      uniqueValueProposition: 'ፈጣን፣ አስተማማኝ እና ወጪ ቆጣቢ አሰራርን በመጠቀም የደንበኞችን ችግር በዘላቂነት መፍታት።',
      targetCustomerSegments: [
        'አነስተኛ እና መካከለኛ የንግድ ተቋማት',
        'የአካባቢው ነዋሪዎች እና ቤተሰቦች',
        'ወጪ ቆጣቢ መፍትሄዎችን የሚሹ ተቋማት',
      ],
      channels: [
        'የቴሌግራም እና የማህበራዊ ሚዲያ ገጾች',
        'የቀጥታ የሰው-ለሰው ግንኙነት እና የሰፈር ማስተዋወቂያዎች',
        'ከአካባቢው የንግድ ማህበራት ጋር የሚደረግ ትስስር',
      ],
      revenueStreams: [
        'የቀጥታ ሽያጭ እና የአገልግሎት ክፍያዎች',
        'የተደጋጋሚ ደንበኞች ወርሃዊ ክፍያ',
        'ልዩ እና ፈጣን አገልግሎት ተጨማሪ ክፍያ',
      ],
      costStructure: [
        'የጥሬ እቃ እና የማምረቻ/አገልግሎት ግብአቶች',
        'የትራንስፖርት እና የማጓጓዣ ወጪዎች',
        'የማስተዋወቂያ እና የኮሚኒኬሽን ወጪዎች',
      ],
      keyMetrics: [
        'በየሳምንቱ የሚያገለግሏቸው አዳዲስ ደንበኞች ብዛት',
        'የተደጋጋሚ ደንበኞች ምጣኔ (Retention rate)',
        'የተጣራ ወርሃዊ የትርፍ መጠን',
      ],
      firstMonthMilestones: [
        'የመጀመሪያዎቹን 20 ደንበኞች በስኬት ማስተናገድ',
        'የጥራት እና የዋጋ አሰጣጥ ስርዓቱን ማስተካከል',
        'የመጀመሪያውን ወር ትርፍና ወጪ በማስላት ለቀጣዩ ወር እቅድ ማውጣት',
      ],
    };
  }

  return {
    executiveSummary: `${title} is an innovative enterprise established to eliminate persistent market friction through affordable, dependable, and community-centered service delivery.`,
    uniqueValueProposition: 'Delivering practical, high-impact problem resolution faster and at lower total cost than legacy providers.',
    targetCustomerSegments: [
      'Local households and community members seeking reliable services',
      'Smallholder businesses requiring flexible support',
      'Cost-conscious institutional and commercial buyers',
    ],
    channels: [
      'Direct field outreach and local merchant networks',
      'Community social channels (Telegram, local message boards)',
      'Customer referral incentive programs',
    ],
    revenueStreams: [
      'Transactional service and product margin fees',
      'Recurring monthly maintenance or retainer agreements',
      'Value-added express fulfillment surcharges',
    ],
    costStructure: [
      'Tools, equipment, and raw material inputs',
      'Transportation and local logistics',
      'Marketing collateral and customer acquisition',
    ],
    keyMetrics: [
      'Number of active weekly paying customers',
      'Customer satisfaction and repeat referral rate (>85%)',
      'Gross profit margin per completed transaction',
    ],
    firstMonthMilestones: [
      'Validate standard service pricing with the first 15 paid orders',
      'Document operational playbooks and customer care scripts',
      'Achieve positive operational cash flow by week 4',
    ],
  };
}

export function synthesizeApplicationPitch(jobTitle: string, company: string, language: Language) {
  const isAm = language === 'am';

  if (isAm) {
    return {
      elevatorPitch: `ሰላም! ችግሮችን ወደ መልካም የንግድ እና የስራ ዕድል የመቀየር ከፍተኛ ፍላጎት እና ተግባራዊ ልምድ ያለኝ ባለሙያ ነኝ። ለ${company} የ${jobTitle} መደብ ከፍተኛ ተነሳሽነት ይዤ መጥቻለሁ።`,
      coverLetter: `ለ${company} የሰው ሃብት አስተዳደር ክፍል፦\n\nበPROJECT ZERO በኩል ያወጣችሁትን የ${jobTitle} የስራ ማስታወቂያ በከፍተኛ ፍላጎት ተመልክቼዋለሁ። ድርጅታችሁ በማህበረሰቡ እና በገበያው ውስጥ ያሉ ውስብስብ ችግሮችን ለመፍታት የሚያደርገውን ጥረት አደንቃለሁ።\n\nያለኝ የተግባር ተነሳሽነት፣ የማህበረሰብ ግንኙነት ችሎታ እና ችግሮችን በፈጠራ የመፍታት አቅም ለቡድናችሁ ፈጣን ውጤት እንደሚያስገኝ ሙሉ እምነት አለኝ። ቃለ-መጠይቅ አድርገን በዝርዝር እንድንነጋገር በአክብሮት እጠይቃለሁ።`,
      recommendedKeywords: ['ችግር ፈቺነት', 'ተነሳሽነት', 'የቡድን ስራ', 'ውጤት ተኮር'],
      interviewTip: 'በቃለ መጠይቁ ወቅት ከዚህ በፊት በተግባር የፈቷቸውን ማህበረሰባዊ ወይም የስራ ችግሮች በምሳሌ አስደግፈው ያስረዱ።',
    };
  }

  return {
    elevatorPitch: `I am an energetic problem solver trained with PROJECT ZERO to turn challenges into measurable business and operational opportunities. I am eager to apply my grit and capabilities to the ${jobTitle} role at ${company}.`,
    coverLetter: `Dear Hiring Team at ${company},\n\nI am writing to express my enthusiasm for the ${jobTitle} opportunity listed on Project Zero. I have built my background around identifying bottlenecks and engineering practical, collaborative solutions that create tangible value.\n\nMy problem-solving mindset, fast learning ability, and dedication to measurable results align closely with your objectives. I welcome the opportunity to discuss how I can contribute immediately to your team's success.`,
    recommendedKeywords: ['Problem Solving', 'Adaptability', 'Initiative', 'Collaboration', 'Execution'],
    interviewTip: 'Highlight a concrete challenge you observed and the specific proactive steps you took to resolve it.',
  };
}
