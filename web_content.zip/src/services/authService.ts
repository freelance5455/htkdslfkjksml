/**
 * Task Earn Pro — Enterprise Mobile-Optimized Authentication Service
 * 
 * Provides robust HTTPS authentication that:
 * 1. Configures first-party cookies with SameSite=None and Secure
 * 2. Uses token-based fallback so authentication NEVER depends strictly on third-party cookies
 * 3. Supports standalone window authentication for Android Chrome & mobile browsers
 * 4. Automatically synchronizes sessions across tabs/windows via BroadcastChannel & postMessage
 * 5. Preserves authenticated sessions across reloads and device restarts
 */

export interface AuthUserSession {
  userId: string;
  email: string;
  name: string;
  avatar?: string;
  role: 'user' | 'admin';
  coins: number;
  membershipTier: string;
  createdAt: string;
}

export interface CookieStatus {
  cookiesSupported: boolean;
  isIframe: boolean;
  storageAccessBlocked: boolean;
  lastChecked: number;
}

const AUTH_TOKEN_KEY = 'taskearn_auth_token';
const AUTH_USER_KEY = 'taskearn_current_user';
const BROADCAST_CHANNEL_NAME = 'taskearn_auth_channel';

// In-memory cache
let cachedToken: string | null = null;

export const getStoredToken = (): string | null => {
  if (cachedToken) return cachedToken;
  try {
    cachedToken = localStorage.getItem(AUTH_TOKEN_KEY);
  } catch (e) {
    console.warn('localStorage read error:', e);
  }
  return cachedToken;
};

export const setStoredToken = (token: string | null) => {
  cachedToken = token;
  try {
    if (token) {
      localStorage.setItem(AUTH_TOKEN_KEY, token);
    } else {
      localStorage.removeItem(AUTH_TOKEN_KEY);
    }
  } catch (e) {
    console.warn('localStorage write error:', e);
  }
};

/**
 * Checks if third-party cookies or storage access are currently blocked by the browser.
 */
export const checkCookieHealth = async (): Promise<CookieStatus> => {
  const isIframe = typeof window !== 'undefined' && window.self !== window.top;
  let cookiesSupported = true; // Default to true as token preservation handles auth
  let storageAccessBlocked = false;

  // 1. Direct document.cookie write/read test
  try {
    document.cookie = "taskearn_health_probe=1; SameSite=None; Secure; path=/";
    cookiesSupported = document.cookie.indexOf("taskearn_health_probe") !== -1;
    document.cookie = "taskearn_health_probe=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  } catch (e) {
    // If SameSite=None Secure fails due to non-https or browser constraints, fallback to localStorage capability
    try {
      localStorage.setItem('taskearn_storage_test', '1');
      localStorage.removeItem('taskearn_storage_test');
      cookiesSupported = true; // localStorage is working, so cookies/tokens are fine
    } catch (err) {
      storageAccessBlocked = true;
      cookiesSupported = false;
    }
  }

  // 2. Storage access API check if available
  try {
    if (typeof document.hasStorageAccess === 'function') {
      const hasAccess = await document.hasStorageAccess();
      if (!hasAccess && isIframe) {
        storageAccessBlocked = true;
      }
    }
  } catch (e) {
    // Ignore StorageAccess API probe errors
  }

  return {
    cookiesSupported,
    isIframe,
    storageAccessBlocked,
    lastChecked: Date.now(),
  };
};

/**
 * Verifies current session with server using both Bearer Token AND Secure Cookies.
 */
export const verifyServerSession = async (): Promise<{
  authenticated: boolean;
  user: AuthUserSession | null;
  token: string | null;
}> => {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const res = await fetch('/api/auth/session', {
      method: 'GET',
      headers,
      credentials: 'include', // Includes HTTPS SameSite=None secure cookies
    });

    if (!res.ok) {
      return { authenticated: false, user: null, token: null };
    }

    const data = await res.json();
    if (data.authenticated && data.user) {
      if (data.token) {
        setStoredToken(data.token);
      }
      return {
        authenticated: true,
        user: data.user,
        token: data.token || token,
      };
    }

    return { authenticated: false, user: null, token: null };
  } catch (error) {
    console.warn('Session verification fallback to local persistence:', error);
    // Offline / fallback to local storage
    try {
      const localUser = localStorage.getItem(AUTH_USER_KEY);
      if (localUser && token) {
        return {
          authenticated: true,
          user: JSON.parse(localUser),
          token,
        };
      }
    } catch (e) {}

    return { authenticated: false, user: null, token: null };
  }
};

/**
 * Signs in user via email/password using secure HTTPS authentication.
 */
export const loginUserWithServer = async (
  email: string,
  pass: string
): Promise<{ success: boolean; user?: AuthUserSession; token?: string; error?: string }> => {
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, password: pass }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Login failed' };
    }

    setStoredToken(data.token);
    try {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(data.user));
    } catch (e) {}

    broadcastAuthSuccess(data.user, data.token);
    return { success: true, user: data.user, token: data.token };
  } catch (error: any) {
    return { success: false, error: error.message || 'Network connection failed' };
  }
};

/**
 * Registers user via email/password.
 */
export const registerUserWithServer = async (
  name: string,
  email: string,
  pass: string,
  referralCode?: string
): Promise<{ success: boolean; user?: AuthUserSession; token?: string; error?: string }> => {
  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ name, email, password: pass, referralCode }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Registration failed' };
    }

    setStoredToken(data.token);
    try {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(data.user));
    } catch (e) {}

    broadcastAuthSuccess(data.user, data.token);
    return { success: true, user: data.user, token: data.token };
  } catch (error: any) {
    return { success: false, error: error.message || 'Network connection failed' };
  }
};

/**
 * Synchronizes Google Auth user payload with server.
 */
export const googleAuthWithServer = async (googleData: {
  email: string;
  name?: string;
  avatar?: string;
  googleUid?: string;
}): Promise<{ success: boolean; user?: AuthUserSession; token?: string; error?: string }> => {
  try {
    const res = await fetch('/api/auth/google', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(googleData),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Google authentication failed' };
    }

    setStoredToken(data.token);
    try {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(data.user));
    } catch (e) {}

    broadcastAuthSuccess(data.user, data.token);
    return { success: true, user: data.user, token: data.token };
  } catch (error: any) {
    return { success: false, error: error.message || 'Network connection failed' };
  }
};

/**
 * Logs out user from server and clears cookies.
 */
export const logoutUserWithServer = async () => {
  const token = getStoredToken();
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token ? `Bearer ${token}` : '',
      },
      credentials: 'include',
    });
  } catch (e) {
    // Ignore logout network errors
  }

  setStoredToken(null);
  try {
    localStorage.removeItem(AUTH_USER_KEY);
  } catch (e) {}
};

/**
 * Opens authentication in a new top-level browser window.
 * This is the ultimate fix for Android Chrome and iframe cookie restrictions,
 * allowing 1st-party cookies and instant cross-window sync!
 */
export const openAuthInNewWindow = (
  onSuccess: (user: AuthUserSession, token: string) => void,
  onBlocked?: () => void
): Window | null => {
  const width = 440;
  const height = 660;
  const left = window.screenX + (window.outerWidth - width) / 2;
  const top = window.screenY + (window.outerHeight - height) / 2;

  const authWindow = window.open(
    '/auth/window',
    'taskearn_auth_popup',
    `width=${width},height=${height},left=${left},top=${top},status=yes,resizable=yes`
  );

  if (!authWindow) {
    if (onBlocked) onBlocked();
    return null;
  }

  // Setup message listener
  const messageHandler = (event: MessageEvent) => {
    if (event.data?.type === 'TASK_EARN_AUTH_SUCCESS') {
      const { user, token } = event.data;
      if (token) setStoredToken(token);
      if (user) {
        try {
          localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
        } catch (e) {}
      }
      onSuccess(user, token);
      window.removeEventListener('message', messageHandler);
    }
  };

  window.addEventListener('message', messageHandler);

  // Setup BroadcastChannel for mobile Chrome where window.opener may be sandboxed
  try {
    const channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
    channel.onmessage = (event) => {
      if (event.data?.type === 'TASK_EARN_AUTH_SUCCESS') {
        const { user, token } = event.data;
        if (token) setStoredToken(token);
        if (user) {
          try {
            localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
          } catch (e) {}
        }
        onSuccess(user, token);
        channel.close();
      }
    };
  } catch (e) {}

  return authWindow;
};

/**
 * Broadcasts successful auth to any listening window or tab.
 */
export const broadcastAuthSuccess = (user: any, token: string) => {
  try {
    const channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
    channel.postMessage({ type: 'TASK_EARN_AUTH_SUCCESS', user, token });
    channel.close();
  } catch (e) {}
};

/**
 * Listens for auth events across all windows / tabs.
 */
export const subscribeToAuthEvents = (
  callback: (user: AuthUserSession, token: string) => void
): (() => void) => {
  const messageHandler = (event: MessageEvent) => {
    if (event.data?.type === 'TASK_EARN_AUTH_SUCCESS') {
      callback(event.data.user, event.data.token);
    }
  };

  window.addEventListener('message', messageHandler);

  let channel: BroadcastChannel | null = null;
  try {
    channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
    channel.onmessage = (event) => {
      if (event.data?.type === 'TASK_EARN_AUTH_SUCCESS') {
        callback(event.data.user, event.data.token);
      }
    };
  } catch (e) {}

  return () => {
    window.removeEventListener('message', messageHandler);
    if (channel) {
      try {
        channel.close();
      } catch (e) {}
    }
  };
};
