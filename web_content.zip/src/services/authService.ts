import { User, UserRole } from '../types';

export interface AuthResponse {
  token: string;
  user: User;
  message?: string;
}

export interface RegisterPayload {
  name: string;
  phone: string;
  email?: string;
  password: string;
  role: 'customer' | 'provider';
  city?: string;
  area?: string;
  providerDetails?: {
    businessName: string;
    category: string;
    subServices: string[];
    visitCharge: number;
    cnicMasked: string;
    serviceAreas: string[];
  };
}

class AuthService {
  private tokenKey = 'mohalla_auth_token';

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  setToken(token: string) {
    localStorage.setItem(this.tokenKey, token);
  }

  clearToken() {
    localStorage.removeItem(this.tokenKey);
  }

  private getHeaders(): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };
    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }

  async login(identifier: string, password: string, expectedRole?: UserRole): Promise<AuthResponse> {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, password, expectedRole }),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Login failed. Please check your credentials.');
    }

    if (data.token) {
      this.setToken(data.token);
    }
    return data;
  }

  async adminLogin(identifier: string, password: string): Promise<AuthResponse> {
    const response = await fetch('/api/auth/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, username: identifier, email: identifier, password }),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Admin authentication failed. Access denied.');
    }

    if (data.token) {
      this.setToken(data.token);
    }
    return data;
  }

  async register(payload: RegisterPayload): Promise<AuthResponse> {
    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Registration failed.');
    }

    if (data.token) {
      this.setToken(data.token);
    }
    return data;
  }

  async getCurrentUser(): Promise<{ user: User; role: UserRole } | null> {
    const token = this.getToken();
    if (!token) return null;

    try {
      const response = await fetch('/api/auth/me', {
        headers: this.getHeaders(),
      });

      if (!response.ok) {
        this.clearToken();
        return null;
      }

      return await response.json();
    } catch {
      return null;
    }
  }

  async logout(): Promise<void> {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: this.getHeaders(),
      });
    } catch {
      // Ignore network errors on logout
    } finally {
      this.clearToken();
    }
  }

  async requestPasswordReset(identifier: string): Promise<{ message: string; testOtp?: string }> {
    const response = await fetch('/api/auth/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier }),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to request password reset code.');
    }
    return data;
  }

  async resetPassword(identifier: string, code: string, newPassword: string): Promise<{ message: string }> {
    const response = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, code, newPassword }),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to reset password.');
    }
    return data;
  }
}

export const authService = new AuthService();
