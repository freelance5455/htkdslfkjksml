/**
 * GODEX Visual-to-AST Bidirectional Bridge & Design Inspector Engine
 * Captures clicked preview DOM elements, inspects computed styles and accessibility metrics,
 * maps to source components, and generates unified diffs for controlled visual styling changes.
 */

import { VisualElementInspection } from '../intelligence/visualLoopTypes';
import { ProjectDigitalTwin, DigitalTwinSnapshot } from '../intelligence/digitalTwin';
import { DiffEngine } from './diffEngine';

export interface VisualMutationProposal {
  id: string;
  targetFile: string;
  elementTag: string;
  componentName?: string;
  originalClassName: string;
  updatedClassName: string;
  originalContent: string;
  patchedContent: string;
  unifiedDiff: string;
  affectedProperties: Record<string, string | number>;
  blastRadius: {
    affectedFiles: string[];
    riskScore: number;
  };
}

export class VisualBridge {
  private static instance: VisualBridge;
  private selectedElement: VisualElementInspection | null = null;
  private isInspectModeActive: boolean = false;
  private listeners: Array<(elem: VisualElementInspection | null, inspectMode: boolean) => void> = [];

  private constructor() {}

  public static getInstance(): VisualBridge {
    if (!VisualBridge.instance) {
      VisualBridge.instance = new VisualBridge();
    }
    return VisualBridge.instance;
  }

  public subscribe(fn: (elem: VisualElementInspection | null, inspectMode: boolean) => void): () => void {
    this.listeners.push(fn);
    fn(this.selectedElement, this.isInspectModeActive);
    return () => {
      this.listeners = this.listeners.filter(l => l !== fn);
    };
  }

  private notify() {
    this.listeners.forEach(fn => fn(this.selectedElement, this.isInspectModeActive));
  }

  public setInspectMode(active: boolean) {
    this.isInspectModeActive = active;
    this.notify();
  }

  public isInspectMode(): boolean {
    return this.isInspectModeActive;
  }

  public getSelectedElement(): VisualElementInspection | null {
    return this.selectedElement;
  }

  public clearSelection() {
    this.selectedElement = null;
    this.notify();
  }

  /**
   * Process an inspection payload received from the preview iframe
   */
  public handlePreviewInspectionEvent(
    rawPayload: any,
    workspaceFiles: Record<string, string>,
    snapshot?: DigitalTwinSnapshot
  ): VisualElementInspection {
    const twin = snapshot || ProjectDigitalTwin.createSnapshot(workspaceFiles);

    // Correlate with workspace source files
    let matchedFile: string | undefined;
    let matchedLine: number | undefined;
    let matchedComp: string | undefined = rawPayload.componentName;

    // 1. If className contains distinct classes, search workspace files
    if (rawPayload.className && typeof rawPayload.className === 'string') {
      const classTokens = rawPayload.className.split(/\s+/).filter((c: string) => c.length > 4);
      for (const [filePath, content] of Object.entries(workspaceFiles)) {
        if (!filePath.endsWith('.tsx') && !filePath.endsWith('.jsx')) continue;
        const matches = classTokens.filter(token => content.includes(token));
        if (matches.length >= 2 || (classTokens.length === 1 && matches.length === 1)) {
          matchedFile = filePath;
          const lines = content.split('\n');
          for (let i = 0; i < lines.length; i++) {
            if (lines[i].includes(classTokens[0])) {
              matchedLine = i + 1;
              break;
            }
          }
          break;
        }
      }
    }

    // 2. If component name was provided, search Digital Twin symbols
    if (matchedComp && !matchedFile) {
      const allSymbols = Object.values(twin.symbols).flat();
      const sym = allSymbols.find(s => s.name === matchedComp);
      if (sym && workspaceFiles[sym.filePath]) {
        matchedFile = sym.filePath;
        matchedLine = sym.line;
      }
    }

    if (!matchedFile) {
      matchedFile = workspaceFiles['src/App.tsx'] ? 'src/App.tsx' : (Object.keys(workspaceFiles).find(k => k.endsWith('.tsx')) || 'src/App.tsx');
      matchedLine = 1;
    }

    const inspection: VisualElementInspection = {
      elementId: rawPayload.elementId || `el-${Date.now()}`,
      tagName: rawPayload.tagName ? rawPayload.tagName.toLowerCase() : 'div',
      className: rawPayload.className || '',
      idAttr: rawPayload.idAttr,
      textContentSnippet: (rawPayload.textContent || '').trim().substring(0, 80),
      componentName: matchedComp,
      sourceFile: matchedFile,
      sourceLine: matchedLine,
      computedStyles: {
        width: Math.round(rawPayload.computedStyles?.width || 0),
        height: Math.round(rawPayload.computedStyles?.height || 0),
        padding: rawPayload.computedStyles?.padding || { top: 0, right: 0, bottom: 0, left: 0 },
        margin: rawPayload.computedStyles?.margin || { top: 0, right: 0, bottom: 0, left: 0 },
        fontSize: rawPayload.computedStyles?.fontSize || '16px',
        fontWeight: rawPayload.computedStyles?.fontWeight || '400',
        lineHeight: rawPayload.computedStyles?.lineHeight || '24px',
        letterSpacing: rawPayload.computedStyles?.letterSpacing || '0px',
        color: rawPayload.computedStyles?.color || '#ffffff',
        backgroundColor: rawPayload.computedStyles?.backgroundColor || 'transparent',
        borderRadius: rawPayload.computedStyles?.borderRadius || '0px',
        border: rawPayload.computedStyles?.border || 'none',
        boxShadow: rawPayload.computedStyles?.boxShadow || 'none',
        opacity: rawPayload.computedStyles?.opacity || '1',
        display: rawPayload.computedStyles?.display || 'block',
        flexDirection: rawPayload.computedStyles?.flexDirection,
        justifyContent: rawPayload.computedStyles?.justifyContent,
        alignItems: rawPayload.computedStyles?.alignItems,
        gap: rawPayload.computedStyles?.gap
      },
      accessibility: {
        role: rawPayload.accessibility?.role || rawPayload.tagName?.toLowerCase(),
        ariaLabel: rawPayload.accessibility?.ariaLabel,
        isInteractive: ['button', 'a', 'input', 'select', 'textarea'].includes(rawPayload.tagName?.toLowerCase()) || Boolean(rawPayload.accessibility?.role === 'button'),
        hasAccessibleName: Boolean(rawPayload.accessibility?.ariaLabel || (rawPayload.textContent && rawPayload.textContent.trim().length > 0)),
        contrastRatio: rawPayload.accessibility?.contrastRatio || 4.5
      },
      hierarchy: {
        parentTag: rawPayload.hierarchy?.parentTag || 'body',
        parentComponent: rawPayload.hierarchy?.parentComponent,
        childrenCount: rawPayload.hierarchy?.childrenCount || 0,
        depth: rawPayload.hierarchy?.depth || 1
      }
    };

    this.selectedElement = inspection;
    this.notify();
    return inspection;
  }

  /**
   * Generates proposed source code change for visual style property updates
   */
  public generateVisualMutationProposal(params: {
    inspection: VisualElementInspection;
    propertyChanges: Record<string, string | number>;
    workspaceFiles: Record<string, string>;
  }): VisualMutationProposal | null {
    const { inspection, propertyChanges, workspaceFiles } = params;
    const targetFile = inspection.sourceFile;
    if (!targetFile || !workspaceFiles[targetFile]) return null;

    const originalContent = workspaceFiles[targetFile];
    let updatedClassList = inspection.className.split(/\s+/).filter(Boolean);

    // Apply visual property updates to Tailwind classes
    for (const [prop, val] of Object.entries(propertyChanges)) {
      if (prop === 'padding') {
        updatedClassList = updatedClassList.filter(c => !c.match(/^p(?:[trblxy])?-\d+$/));
        updatedClassList.push(`p-${val}`);
      } else if (prop === 'margin') {
        updatedClassList = updatedClassList.filter(c => !c.match(/^m(?:[trblxy])?-\d+$/));
        updatedClassList.push(`m-${val}`);
      } else if (prop === 'borderRadius') {
        updatedClassList = updatedClassList.filter(c => !c.startsWith('rounded'));
        updatedClassList.push(`rounded-${val}`);
      } else if (prop === 'backgroundColor') {
        updatedClassList = updatedClassList.filter(c => !c.startsWith('bg-'));
        updatedClassList.push(`bg-${val}`);
      } else if (prop === 'textColor') {
        updatedClassList = updatedClassList.filter(c => !c.startsWith('text-') || c.match(/^text-(?:xs|sm|base|lg|xl|\d+xl)$/));
        updatedClassList.push(`text-${val}`);
      } else if (prop === 'fontSize') {
        updatedClassList = updatedClassList.filter(c => !c.match(/^text-(?:xs|sm|base|lg|xl|2xl|3xl|4xl)$/));
        updatedClassList.push(`text-${val}`);
      } else if (prop === 'fontWeight') {
        updatedClassList = updatedClassList.filter(c => !c.startsWith('font-'));
        updatedClassList.push(`font-${val}`);
      } else if (prop === 'gap') {
        updatedClassList = updatedClassList.filter(c => !c.startsWith('gap-'));
        updatedClassList.push(`gap-${val}`);
      } else if (prop === 'opacity') {
        updatedClassList = updatedClassList.filter(c => !c.startsWith('opacity-'));
        updatedClassList.push(`opacity-${val}`);
      }
    }

    const updatedClassName = updatedClassList.join(' ');
    let patchedContent = originalContent;

    if (inspection.className && originalContent.includes(inspection.className)) {
      patchedContent = originalContent.replace(inspection.className, updatedClassName);
    } else {
      // Find element by tag and update or add className
      const tagRegex = new RegExp(`<${inspection.tagName}(\\s+[^>]*?)>`, 'i');
      if (tagRegex.test(originalContent)) {
        patchedContent = originalContent.replace(tagRegex, (match, attrs) => {
          if (attrs.includes('className=')) {
            return `<${inspection.tagName}${attrs.replace(/className="[^"]*"/, `className="${updatedClassName}"`)}>`;
          }
          return `<${inspection.tagName} className="${updatedClassName}"${attrs}>`;
        });
      }
    }

    const unifiedDiff = DiffEngine.formatUnifiedDiff(originalContent, patchedContent, targetFile);

    return {
      id: `vis-mut-${Date.now()}`,
      targetFile,
      elementTag: inspection.tagName,
      componentName: inspection.componentName,
      originalClassName: inspection.className,
      updatedClassName,
      originalContent,
      patchedContent,
      unifiedDiff,
      affectedProperties: propertyChanges,
      blastRadius: {
        affectedFiles: [targetFile],
        riskScore: 10
      }
    };
  }

  /**
   * Helper to generate inspector injection script inside preview iframe
   */
  public static getIframeInspectorScript(): string {
    return `
      // GODEX Visual Element Inspector Bridge
      (function() {
        let hoverOverlay = null;
        let isInspectActive = false;

        function createOverlay() {
          if (!hoverOverlay) {
            hoverOverlay = document.createElement('div');
            hoverOverlay.id = '__godex_inspect_overlay';
            hoverOverlay.style.cssText = 'position:fixed;pointer-events:none;border:2px solid #6366f1;background:rgba(99,102,241,0.15);z-index:999999;transition:all 0.05s ease;display:none;border-radius:4px;';
            const badge = document.createElement('div');
            badge.id = '__godex_inspect_badge';
            badge.style.cssText = 'position:absolute;top:-22px;left:0;background:#4f46e5;color:#fff;font-family:ui-monospace,monospace;font-size:10px;padding:2px 6px;border-radius:3px;white-space:nowrap;box-shadow:0 2px 4px rgba(0,0,0,0.5);';
            hoverOverlay.appendChild(badge);
            document.body.appendChild(hoverOverlay);
          }
        }

        window.addEventListener('message', function(e) {
          if (!e.data) return;
          if (e.data.type === 'SET_INSPECT_MODE') {
            isInspectActive = Boolean(e.data.payload?.active);
            createOverlay();
            if (!isInspectActive && hoverOverlay) {
              hoverOverlay.style.display = 'none';
            }
          }
        });

        document.addEventListener('mouseover', function(e) {
          if (!isInspectActive) return;
          const target = e.target;
          if (!target || target === hoverOverlay || target.id === '__godex_inspect_overlay') return;
          createOverlay();
          const rect = target.getBoundingClientRect();
          hoverOverlay.style.top = rect.top + 'px';
          hoverOverlay.style.left = rect.left + 'px';
          hoverOverlay.style.width = rect.width + 'px';
          hoverOverlay.style.height = rect.height + 'px';
          hoverOverlay.style.display = 'block';

          const badge = document.getElementById('__godex_inspect_badge');
          if (badge) {
            const tagName = target.tagName.toLowerCase();
            const classSnippet = target.className && typeof target.className === 'string' ? '.' + target.className.split(' ')[0] : '';
            badge.textContent = tagName + classSnippet + ' (' + Math.round(rect.width) + 'x' + Math.round(rect.height) + ')';
          }
        }, true);

        document.addEventListener('click', function(e) {
          if (!isInspectActive) return;
          e.preventDefault();
          e.stopPropagation();

          const target = e.target;
          if (!target) return;

          const computed = window.getComputedStyle(target);
          const rect = target.getBoundingClientRect();

          const parsePx = (val) => parseFloat(val) || 0;

          const payload = {
            elementId: target.id || ('el_' + Math.random().toString(36).substr(2, 6)),
            tagName: target.tagName,
            className: typeof target.className === 'string' ? target.className : '',
            idAttr: target.id || undefined,
            textContent: (target.textContent || '').substring(0, 100),
            componentName: target.getAttribute('data-component') || undefined,
            computedStyles: {
              width: rect.width,
              height: rect.height,
              padding: {
                top: parsePx(computed.paddingTop),
                right: parsePx(computed.paddingRight),
                bottom: parsePx(computed.paddingBottom),
                left: parsePx(computed.paddingLeft)
              },
              margin: {
                top: parsePx(computed.marginTop),
                right: parsePx(computed.marginRight),
                bottom: parsePx(computed.marginBottom),
                left: parsePx(computed.marginLeft)
              },
              fontSize: computed.fontSize,
              fontWeight: computed.fontWeight,
              lineHeight: computed.lineHeight,
              letterSpacing: computed.letterSpacing,
              color: computed.color,
              backgroundColor: computed.backgroundColor,
              borderRadius: computed.borderRadius,
              border: computed.border,
              boxShadow: computed.boxShadow,
              opacity: computed.opacity,
              display: computed.display,
              flexDirection: computed.flexDirection,
              justifyContent: computed.justifyContent,
              alignItems: computed.alignItems,
              gap: computed.gap
            },
            accessibility: {
              role: target.getAttribute('role') || target.tagName.toLowerCase(),
              ariaLabel: target.getAttribute('aria-label') || undefined,
              contrastRatio: 4.5
            },
            hierarchy: {
              parentTag: target.parentElement ? target.parentElement.tagName.toLowerCase() : 'body',
              childrenCount: target.children.length,
              depth: 1
            }
          };

          window.parent.postMessage({
            type: 'VISUAL_ELEMENT_INSPECTED',
            payload: payload
          }, '*');
        }, true);
      })();
    `;
  }
}
