import { getUserId } from "../utils/auth";

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  images?: string[];
  isThinking?: boolean;
  emotion?: 'SAD' | 'HAPPY' | 'NEUTRAL';
}

export interface ChatChunk {
  text?: string;
  image?: string;
  error?: string;
  isComplete?: boolean;
  candidates?: any[];
}

export const detectEmotion = (text: string): 'SAD' | 'HAPPY' | 'NEUTRAL' => {
  const sadWords = ["sad", "dukh", "rona", "akela", "upset", "pareshan", "alone", "udaas", "kharab", "mood off"];
  const happyWords = ["happy", "khush", "mazza", "hasi", "smile", "good", "achha", "badhiya", "great"];
  
  const lower = text.toLowerCase();
  if (sadWords.some(word => lower.includes(word))) return 'SAD';
  if (happyWords.some(word => lower.includes(word))) return 'HAPPY';
  return 'NEUTRAL';
};

export async function generateImage(prompt: string, referenceImages?: string[]): Promise<string | null> {
  try {
    const response = await fetch('/api/generate-image', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': getUserId(),
      },
      body: JSON.stringify({
        prompt,
        referenceImages,
      }),
    });

    if (!response.ok) {
      let errorMsg = 'Failed to generate image.';
      try {
        const text = await response.text();
        try {
          const data = JSON.parse(text);
          errorMsg = data.error || data.message || errorMsg;
        } catch (e) {
          if (text.includes('<html')) {
            errorMsg = response.status === 413 ? "Image payload too large." : "Request blocked by server firewall.";
          } else {
            errorMsg = text.substring(0, 150);
          }
        }
      } catch (e) {}
      const error: any = new Error(errorMsg);
      error.status = response.status;
      throw error;
    }

    const data = await response.json();
    return data.imageUrl || null;
  } catch (error) {
    console.error("Error generating image:", error);
    throw error;
  }
}

export async function* streamChatResponse(
  history: ChatMessage[],
  message: string,
  images?: string[],
  modelName: string = 'gemini-3.1-flash-lite',
  persona: 'Male' | 'Female' = 'Female',
  userName?: string,
  language?: string
): AsyncGenerator<ChatChunk, void, unknown> {
  const userId = localStorage.getItem('india_ai_user_id') || '';
  
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-id': getUserId() || userId
    },
    body: JSON.stringify({
      history,
      message,
      images,
      model: modelName,
      persona,
      userName,
      language,
    }),
  });

  if (!response.ok) {
    let errorMsg = `Server returned status ${response.status}`;
    try {
      const text = await response.text();
      try {
        const data = JSON.parse(text);
        errorMsg = data.error || data.message || errorMsg;
      } catch (e) {
        // If it's HTML from WAF/Nginx, show a snippet
        if (text.includes('<html')) {
          if (response.status === 413 || text.includes('Too Large')) {
            errorMsg = "Image is too large. Please try a smaller image.";
          } else if (response.status === 403) {
            errorMsg = "Request blocked by server firewall. Try a smaller image or different text.";
          }
        } else {
          errorMsg = text.substring(0, 150);
        }
      }
    } catch (e) {}
    yield { text: "", error: errorMsg, isComplete: true } as ChatChunk;
    return;
  }

  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error('ReadableStream not supported by browser');
  }

  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith('data: ')) continue;
      const dataStr = trimmed.slice(6);
      if (dataStr === '[DONE]') {
        return;
      }
      try {
        const parsed = JSON.parse(dataStr);
        if (parsed.error) {
          yield { text: "", error: parsed.error, isComplete: true } as ChatChunk;
          return;
        }
        yield parsed as ChatChunk;
      } catch (err: any) {
        if (err.message && !err.message.includes('JSON')) {
          yield { text: "", error: err.message, isComplete: true } as ChatChunk;
          return;
        }
      }
    }
  }
}
