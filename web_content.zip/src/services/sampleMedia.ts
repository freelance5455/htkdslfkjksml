import { ClipFilter, VisualEffect, Project, Track, Clip } from '../types/editor';

// --- Built-in Filters Collection (Non-AI, 100% CSS/Canvas matrix & color math) ---
export const BUILTIN_FILTERS: ClipFilter[] = [
  {
    id: 'teal_orange',
    name: 'Teal & Orange',
    category: 'Cinematic',
    intensity: 85,
    cssFilter: 'contrast(120%) saturate(130%) hue-rotate(-15deg) sepia(20%)',
  },
  {
    id: 'blockbuster_moody',
    name: 'Moody Blockbuster',
    category: 'Cinematic',
    intensity: 80,
    cssFilter: 'contrast(135%) brightness(92%) saturate(90%) hue-rotate(10deg)',
  },
  {
    id: 'golden_hour',
    name: 'Golden Hour',
    category: 'Cinematic',
    intensity: 90,
    cssFilter: 'sepia(35%) saturate(140%) brightness(105%) contrast(110%)',
  },
  {
    id: 'film_noir',
    name: 'Film Noir 1940',
    category: 'Black & White',
    intensity: 100,
    cssFilter: 'grayscale(100%) contrast(160%) brightness(90%)',
  },
  {
    id: 'silver_bw',
    name: 'Silver Monolith',
    category: 'Black & White',
    intensity: 100,
    cssFilter: 'grayscale(100%) contrast(115%) brightness(108%)',
  },
  {
    id: 'vintage_80s',
    name: '1980s Retro Tape',
    category: 'Vintage',
    intensity: 85,
    cssFilter: 'sepia(25%) saturate(125%) contrast(90%) hue-rotate(-20deg)',
  },
  {
    id: 'kodachrome',
    name: 'Kodachrome 64',
    category: 'Film',
    intensity: 80,
    cssFilter: 'contrast(125%) saturate(145%) brightness(98%)',
  },
  {
    id: 'cyberpunk_neon',
    name: 'Cyberpunk Neon',
    category: 'Moody',
    intensity: 95,
    cssFilter: 'contrast(140%) saturate(180%) hue-rotate(90deg) brightness(110%)',
  },
  {
    id: 'radiant_peach',
    name: 'Radiant Peach',
    category: 'Portrait',
    intensity: 75,
    cssFilter: 'brightness(108%) contrast(105%) saturate(115%) sepia(15%)',
  },
  {
    id: 'soft_glow',
    name: 'Soft Dream Portrait',
    category: 'Portrait',
    intensity: 70,
    cssFilter: 'brightness(112%) contrast(95%) saturate(105%)',
  },
  {
    id: 'emerald_forest',
    name: 'Emerald Green',
    category: 'Travel',
    intensity: 80,
    cssFilter: 'hue-rotate(30deg) saturate(130%) contrast(110%)',
  },
  {
    id: 'vibrant_pop',
    name: 'Vibrant Pop',
    category: 'Social',
    intensity: 90,
    cssFilter: 'saturate(170%) contrast(115%) brightness(102%)',
  },
  {
    id: 'pastel_aesthetic',
    name: 'Pastel Aesthetic',
    category: 'Social',
    intensity: 70,
    cssFilter: 'brightness(115%) contrast(90%) saturate(95%) sepia(10%)',
  },
  {
    id: 'warm_sunset',
    name: 'Warm Sunset',
    category: 'Warm',
    intensity: 85,
    cssFilter: 'sepia(40%) saturate(150%) hue-rotate(-10deg)',
  },
  {
    id: 'arctic_cool',
    name: 'Arctic Glacier',
    category: 'Cool',
    intensity: 80,
    cssFilter: 'hue-rotate(180deg) saturate(110%) contrast(105%)',
  },
  {
    id: 'food_delight',
    name: 'Foodie Warmth',
    category: 'Food',
    intensity: 85,
    cssFilter: 'saturate(140%) brightness(106%) contrast(112%)',
  },
];

// --- Built-in Visual Effects Collection ---
export const BUILTIN_EFFECTS: { id: string; name: string; type: string; defaultIntensity: number; defaultSpeed: number }[] = [
  { id: 'vhs', name: 'VHS Tape & Noise', type: 'vhs', defaultIntensity: 60, defaultSpeed: 50 },
  { id: 'glitch', name: 'Digital Glitch', type: 'glitch', defaultIntensity: 70, defaultSpeed: 60 },
  { id: 'rgb_split', name: 'RGB Split / Chromatic', type: 'rgb_split', defaultIntensity: 65, defaultSpeed: 40 },
  { id: 'shake', name: 'Camera Shake', type: 'shake', defaultIntensity: 50, defaultSpeed: 70 },
  { id: 'film_grain', name: '35mm Film Grain', type: 'grain', defaultIntensity: 55, defaultSpeed: 80 },
  { id: 'light_leak', name: 'Cinematic Light Leak', type: 'light_leak', defaultIntensity: 70, defaultSpeed: 30 },
  { id: 'blur_motion', name: 'Motion Blur', type: 'motion_blur', defaultIntensity: 50, defaultSpeed: 50 },
  { id: 'zoom_pulse', name: 'Zoom Pulse', type: 'zoom_pulse', defaultIntensity: 45, defaultSpeed: 50 },
  { id: 'scan_lines', name: 'CRT Scanlines', type: 'scan_lines', defaultIntensity: 60, defaultSpeed: 20 },
  { id: 'pixelate', name: '8-Bit Pixelate', type: 'pixelate', defaultIntensity: 50, defaultSpeed: 0 },
  { id: 'ripple_wave', name: 'Water Ripple', type: 'ripple', defaultIntensity: 60, defaultSpeed: 50 },
  { id: 'kaleidoscope', name: 'Kaleidoscope', type: 'kaleidoscope', defaultIntensity: 70, defaultSpeed: 30 },
  { id: 'mirror_h', name: 'Horizontal Mirror', type: 'mirror', defaultIntensity: 100, defaultSpeed: 0 },
  { id: 'neon_glow', name: 'Neon Edge Glow', type: 'neon', defaultIntensity: 80, defaultSpeed: 40 },
];

// --- Built-in Royalty Free Sound Effects (Generated via Web Audio Synth) ---
export interface SoundEffectItem {
  id: string;
  name: string;
  category: string;
  duration: number; // in seconds
  generator: (ctx: AudioContext) => AudioBuffer;
}

export function createSoundEffects(audioCtx: AudioContext): SoundEffectItem[] {
  return [
    {
      id: 'sfx_whoosh',
      name: 'Dynamic Whoosh',
      category: 'Transitions',
      duration: 0.6,
      generator: (ctx) => {
        const sampleRate = ctx.sampleRate;
        const length = Math.floor(sampleRate * 0.6);
        const buffer = ctx.createBuffer(1, length, sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < length; i++) {
          const t = i / length;
          const noise = (Math.random() * 2 - 1) * Math.sin(t * Math.PI);
          data[i] = noise * (1 - t * 0.5);
        }
        return buffer;
      },
    },
    {
      id: 'sfx_pop',
      name: 'Soft Pop',
      category: 'UI / Motion',
      duration: 0.25,
      generator: (ctx) => {
        const sampleRate = ctx.sampleRate;
        const length = Math.floor(sampleRate * 0.25);
        const buffer = ctx.createBuffer(1, length, sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < length; i++) {
          const t = i / length;
          const freq = 600 - t * 450;
          data[i] = Math.sin(2 * Math.PI * freq * (i / sampleRate)) * Math.exp(-t * 12);
        }
        return buffer;
      },
    },
    {
      id: 'sfx_ding',
      name: 'Bright Bell / Ding',
      category: 'Highlights',
      duration: 0.8,
      generator: (ctx) => {
        const sampleRate = ctx.sampleRate;
        const length = Math.floor(sampleRate * 0.8);
        const buffer = ctx.createBuffer(1, length, sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < length; i++) {
          const t = i / length;
          const tone = Math.sin(2 * Math.PI * 1320 * (i / sampleRate)) + 0.4 * Math.sin(2 * Math.PI * 2640 * (i / sampleRate));
          data[i] = tone * Math.exp(-t * 6);
        }
        return buffer;
      },
    },
    {
      id: 'sfx_shutter',
      name: 'Camera Shutter Click',
      category: 'Moments',
      duration: 0.35,
      generator: (ctx) => {
        const sampleRate = ctx.sampleRate;
        const length = Math.floor(sampleRate * 0.35);
        const buffer = ctx.createBuffer(1, length, sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < length; i++) {
          const t = i / length;
          const click1 = (t < 0.1) ? (Math.random() * 2 - 1) * (1 - t / 0.1) : 0;
          const click2 = (t > 0.12 && t < 0.22) ? (Math.random() * 2 - 1) * (1 - (t - 0.12) / 0.1) : 0;
          data[i] = (click1 + click2 * 1.2) * 0.8;
        }
        return buffer;
      },
    },
    {
      id: 'sfx_swish',
      name: 'High Swish',
      category: 'Transitions',
      duration: 0.45,
      generator: (ctx) => {
        const sampleRate = ctx.sampleRate;
        const length = Math.floor(sampleRate * 0.45);
        const buffer = ctx.createBuffer(1, length, sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < length; i++) {
          const t = i / length;
          const noise = (Math.random() * 2 - 1) * Math.sin(t * Math.PI);
          const tone = Math.sin(2 * Math.PI * (800 + t * 400) * (i / sampleRate)) * 0.3;
          data[i] = (noise + tone) * (1 - t * 0.3);
        }
        return buffer;
      },
    },
  ];
}

// Convert AudioBuffer to WAV Blob so it can be played as a regular audio track
export function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;

  const dataLength = buffer.length * blockAlign;
  const bufferSize = 44 + dataLength;
  const arrayBuffer = new ArrayBuffer(bufferSize);
  const view = new DataView(arrayBuffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataLength, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, format, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeString(36, 'data');
  view.setUint32(40, dataLength, true);

  let offset = 44;
  for (let i = 0; i < buffer.length; i++) {
    for (let ch = 0; ch < numChannels; ch++) {
      const sample = Math.max(-1, Math.min(1, buffer.getChannelData(ch)[i]));
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }

  return new Blob([view], { type: 'audio/wav' });
}

// Generate royalty-free synthesized music tracks (Lofi Beat, Ambient Chill, Upbeat Rhythm)
export function generateSyntheticMusicTrack(title: string, durationSec: number = 8): Blob {
  const sampleRate = 44100;
  const length = Math.floor(sampleRate * durationSec);
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const audioCtx = new AudioCtx();
    const buffer = audioCtx.createBuffer(2, length, sampleRate);
    const chL = buffer.getChannelData(0);
    const chR = buffer.getChannelData(1);

    const bpm = title.includes('Upbeat') ? 120 : 85;
    const beatDuration = 60 / bpm;
    const chords = [
      [261.63, 329.63, 392.00], // C maj
      [220.00, 261.63, 329.63], // A min
      [174.61, 220.00, 261.63], // F maj
      [196.00, 246.94, 293.66], // G maj
    ];

    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      const chordIndex = Math.floor((t / (beatDuration * 4)) % chords.length);
      const chord = chords[chordIndex];

      // Warm pad synthesizer
      let pad = 0;
      chord.forEach((freq, idx) => {
        pad += Math.sin(2 * Math.PI * freq * t) * (0.12 / (idx + 1));
      });

      // Kick drum on each beat
      const beatPhase = (t % beatDuration) / beatDuration;
      const kick = Math.sin(2 * Math.PI * (120 * Math.exp(-beatPhase * 25)) * beatPhase) * Math.exp(-beatPhase * 10) * 0.4;

      // Hi-hat
      const hatPhase = ((t + beatDuration / 2) % beatDuration) / beatDuration;
      const hat = (Math.random() * 2 - 1) * Math.exp(-hatPhase * 40) * 0.08;

      const left = pad * 0.8 + kick + hat * 0.8;
      const right = pad * 0.8 + kick + hat * 1.2;

      chL[i] = Math.max(-1, Math.min(1, left));
      chR[i] = Math.max(-1, Math.min(1, right));
    }

    const wav = audioBufferToWavBlob(buffer);
    audioCtx.close().catch(() => {});
    return wav;
  } catch (e) {
    // Fallback: produce a silent 1s WAV
    const fallbackBuffer = new ArrayBuffer(44);
    return new Blob([fallbackBuffer], { type: 'audio/wav' });
  }
}

// Generate animated test canvas video/image blob quickly without blocking UI
export function generateSampleVideoCanvas(
  width: number,
  height: number,
  type: 'nature' | 'urban' | 'abstract' | 'cinema' | 'sunset' | 'cyberpunk' | 'vintage' | 'minimal' | 'luxury' | 'noir' = 'nature',
  durationSec = 4
): Promise<Blob> {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d')!;

    const drawFrame = (t: number) => {
      if (type === 'nature') {
        const grad = ctx.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, '#064e3b');
        grad.addColorStop(0.5, '#059669');
        grad.addColorStop(1, '#10b981');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        const sunX = width * 0.7;
        const sunY = height * 0.25;
        const sunGrad = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, width * 0.4);
        sunGrad.addColorStop(0, 'rgba(254, 240, 138, 0.9)');
        sunGrad.addColorStop(0.5, 'rgba(251, 191, 36, 0.3)');
        sunGrad.addColorStop(1, 'rgba(251, 191, 36, 0)');
        ctx.fillStyle = sunGrad;
        ctx.fillRect(0, 0, width, height);
      } else if (type === 'cinema' || type === 'noir') {
        const grad = ctx.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, type === 'noir' ? '#0a0a0a' : '#030712');
        grad.addColorStop(0.5, type === 'noir' ? '#262626' : '#111827');
        grad.addColorStop(1, type === 'noir' ? '#171717' : '#0f172a');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        // Anamorphic spotlight
        const lightGrad = ctx.createRadialGradient(width / 2, height / 2, 20, width / 2, height / 2, width * 0.5);
        lightGrad.addColorStop(0, type === 'noir' ? 'rgba(255,255,255,0.2)' : 'rgba(245, 158, 11, 0.25)');
        lightGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = lightGrad;
        ctx.fillRect(0, 0, width, height);
      } else if (type === 'cyberpunk') {
        const grad = ctx.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, '#090014');
        grad.addColorStop(0.5, '#2e0854');
        grad.addColorStop(1, '#020b24');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        // Neon grid lines
        ctx.strokeStyle = 'rgba(236, 72, 153, 0.4)';
        ctx.lineWidth = 2;
        for (let y = height * 0.4; y < height; y += 25) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
          ctx.stroke();
        }
      } else if (type === 'sunset') {
        const grad = ctx.createLinearGradient(0, 0, 0, height);
        grad.addColorStop(0, '#4c0519');
        grad.addColorStop(0.3, '#9d174d');
        grad.addColorStop(0.7, '#ea580c');
        grad.addColorStop(1, '#fde047');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);
      } else if (type === 'vintage') {
        const grad = ctx.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, '#3f2e18');
        grad.addColorStop(0.5, '#574127');
        grad.addColorStop(1, '#2c1e0e');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);
      } else if (type === 'luxury') {
        const grad = ctx.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, '#1c1917');
        grad.addColorStop(0.5, '#292524');
        grad.addColorStop(1, '#0c0a09');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        // Golden dust aura
        const goldAura = ctx.createRadialGradient(width * 0.5, height * 0.4, 10, width * 0.5, height * 0.4, width * 0.6);
        goldAura.addColorStop(0, 'rgba(234, 179, 8, 0.25)');
        goldAura.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = goldAura;
        ctx.fillRect(0, 0, width, height);
      } else if (type === 'urban') {
        const grad = ctx.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(0.5, '#1e1b4b');
        grad.addColorStop(1, '#312e81');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        for (let i = 0; i < 5; i++) {
          const x = (width / 6) * (i + 1);
          ctx.fillStyle = i % 2 === 0 ? 'rgba(236, 72, 153, 0.7)' : 'rgba(56, 189, 248, 0.7)';
          ctx.fillRect(x - 10, height * 0.3, 20, height * 0.7);
        }
      } else {
        const grad = ctx.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, '#701a75');
        grad.addColorStop(0.5, '#831843');
        grad.addColorStop(1, '#4c0519');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);
      }

      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.floor(height * 0.055)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.shadowColor = 'rgba(0,0,0,0.8)';
      ctx.shadowBlur = 6;
      ctx.fillText(
        type === 'nature' ? '🌿 Mountain Vista • Clipora 4K' :
        type === 'cinema' ? '🎬 Hollywood Blockbuster • Cinematic' :
        type === 'cyberpunk' ? '⚡ Cyberpunk Neon Night' :
        type === 'sunset' ? '🌅 Golden Hour Sunset Vibe' :
        type === 'vintage' ? '📼 Retro 80s Tape • Clipora' :
        type === 'luxury' ? '✨ Luxury High-End Studio' :
        type === 'noir' ? '🎞️ Film Noir Classic 1940' :
        type === 'urban' ? '🌆 Cyber City Horizon' : '✨ Kinetic Glow Showcase',
        width / 2,
        height * 0.88
      );
      ctx.shadowBlur = 0;
    };

    // Draw initial frame
    drawFrame(0);

    const hasCapture = typeof canvas.captureStream === 'function';
    const hasMediaRecorder = typeof window.MediaRecorder !== 'undefined';

    if (hasCapture && hasMediaRecorder) {
      try {
        const stream = canvas.captureStream(20);
        let mimeType = 'video/webm; codecs=vp8';
        if (MediaRecorder.isTypeSupported('video/webm; codecs=vp9')) {
          mimeType = 'video/webm; codecs=vp9';
        } else if (!MediaRecorder.isTypeSupported(mimeType)) {
          mimeType = 'video/webm';
        }

        const recorder = new MediaRecorder(stream, { mimeType });
        const chunks: Blob[] = [];

        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.push(e.data);
        };

        recorder.onstop = () => {
          if (chunks.length > 0) {
            resolve(new Blob(chunks, { type: 'video/webm' }));
          } else {
            canvas.toBlob((blob) => resolve(blob || new Blob([])), 'image/jpeg', 0.9);
          }
        };

        recorder.start();

        // Rapidly record 15 frames (~200ms)
        let frameCount = 0;
        const total = 15;
        const interval = setInterval(() => {
          frameCount++;
          drawFrame(frameCount / 10);
          if (frameCount >= total) {
            clearInterval(interval);
            setTimeout(() => {
              try {
                if (recorder.state === 'recording') recorder.stop();
              } catch (e) {
                canvas.toBlob((blob) => resolve(blob || new Blob([])), 'image/jpeg', 0.9);
              }
            }, 50);
          }
        }, 15);

        return;
      } catch (err) {
        // Fall through to fast image blob fallback
      }
    }

    // Instant fallback if MediaRecorder is not available or threw an error
    canvas.toBlob((blob) => {
      resolve(blob || new Blob([], { type: 'image/jpeg' }));
    }, 'image/jpeg', 0.92);
  });
}

// Generate sample initial template project for instant hands-on editing
export async function createSampleProject(): Promise<Project> {
  const vid1Blob = await generateSampleVideoCanvas(640, 360, 'nature', 4);
  const vid1Url = URL.createObjectURL(vid1Blob);

  const vid2Blob = await generateSampleVideoCanvas(640, 360, 'urban', 4);
  const vid2Url = URL.createObjectURL(vid2Blob);

  const audioBlob = generateSyntheticMusicTrack('Lofi Beat', 8);
  const audioUrl = URL.createObjectURL(audioBlob);

  const tracks: Track[] = [
    { id: 'track_main_video', name: 'Main Video', type: 'video', locked: false, visible: true, muted: false, volume: 1.0 },
    { id: 'track_overlay_pip', name: 'PIP Overlay', type: 'overlay', locked: false, visible: true, muted: false, volume: 1.0 },
    { id: 'track_text_1', name: 'Text & Titles', type: 'text', locked: false, visible: true, muted: false, volume: 1.0 },
    { id: 'track_stickers_1', name: 'Stickers & Badges', type: 'sticker', locked: false, visible: true, muted: false, volume: 1.0 },
    { id: 'track_audio_bgm', name: 'Music & Audio', type: 'audio', locked: false, visible: true, muted: false, volume: 1.0 },
  ];

  const defaultAdjustments = {
    brightness: 0,
    contrast: 0,
    saturation: 10,
    exposure: 0,
    highlights: 0,
    shadows: 0,
    temperature: 5,
    tint: 0,
    sharpness: 20,
    vignette: 15,
    grain: 10,
    hue: 0,
  };

  const clips: Clip[] = [
    {
      id: 'clip_nature_1',
      trackId: 'track_main_video',
      trackType: 'video',
      name: 'Mountain Aura',
      type: 'video',
      sourceUrl: vid1Url,
      blob: vid1Blob,
      start: 0,
      duration: 4,
      sourceStart: 0,
      sourceDuration: 4,
      speed: 1.0,
      reverse: false,
      x: 0,
      y: 0,
      scale: 1.0,
      rotation: 0,
      opacity: 1.0,
      flipH: false,
      flipV: false,
      blendMode: 'normal',
      volume: 1.0,
      muted: false,
      fadeIn: 0.5,
      fadeOut: 0.5,
      adjustments: { ...defaultAdjustments },
      filter: BUILTIN_FILTERS[0], // Teal & Orange
      effects: [],
      transition: { type: 'dissolve', duration: 0.6 },
      mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
      chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
      keyframes: [],
    },
    {
      id: 'clip_urban_2',
      trackId: 'track_main_video',
      trackType: 'video',
      name: 'Cyber City',
      type: 'video',
      sourceUrl: vid2Url,
      blob: vid2Blob,
      start: 4,
      duration: 4,
      sourceStart: 0,
      sourceDuration: 4,
      speed: 1.0,
      reverse: false,
      x: 0,
      y: 0,
      scale: 1.0,
      rotation: 0,
      opacity: 1.0,
      flipH: false,
      flipV: false,
      blendMode: 'normal',
      volume: 1.0,
      muted: false,
      fadeIn: 0.3,
      fadeOut: 0.8,
      adjustments: { ...defaultAdjustments, contrast: 15, saturation: 20 },
      filter: BUILTIN_FILTERS[7], // Cyberpunk
      effects: [],
      mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
      chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
      keyframes: [],
    },
    {
      id: 'clip_title_text',
      trackId: 'track_text_1',
      trackType: 'text',
      name: 'Title: CLIPORA',
      type: 'text',
      sourceUrl: '',
      start: 0.5,
      duration: 3.5,
      sourceStart: 0,
      sourceDuration: 3.5,
      speed: 1.0,
      reverse: false,
      x: 0,
      y: -25,
      scale: 1.0,
      rotation: 0,
      opacity: 1.0,
      flipH: false,
      flipV: false,
      blendMode: 'normal',
      volume: 1.0,
      muted: false,
      fadeIn: 0.3,
      fadeOut: 0.3,
      adjustments: { ...defaultAdjustments },
      effects: [],
      mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
      chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
      keyframes: [
        { id: 'kf_1', time: 0, x: 0, y: -25, scale: 0.8, rotation: 0, opacity: 0 },
        { id: 'kf_2', time: 0.6, x: 0, y: -25, scale: 1.0, rotation: 0, opacity: 1 },
      ],
      textConfig: {
        content: 'CLIPORA',
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontSize: 48,
        color: '#ffffff',
        gradient: {
          enabled: true,
          start: '#fbbf24',
          end: '#f43f5e',
          angle: 90,
        },
        bold: true,
        italic: false,
        alignment: 'center',
        letterSpacing: 4,
        stroke: {
          enabled: true,
          color: '#000000',
          width: 3,
        },
        shadow: {
          enabled: true,
          color: 'rgba(0,0,0,0.8)',
          blur: 10,
          offsetX: 0,
          offsetY: 4,
        },
        background: {
          enabled: false,
          color: '#000000',
          opacity: 0.6,
          borderRadius: 8,
          padding: 8,
        },
        animation: 'bounce',
      },
    },
    {
      id: 'clip_sticker_badge',
      trackId: 'track_stickers_1',
      trackType: 'sticker',
      name: 'Fire Badge',
      type: 'sticker',
      sourceUrl: '',
      start: 1.0,
      duration: 3.0,
      sourceStart: 0,
      sourceDuration: 3.0,
      speed: 1.0,
      reverse: false,
      x: 35,
      y: 30,
      scale: 1.2,
      rotation: 12,
      opacity: 0.95,
      flipH: false,
      flipV: false,
      blendMode: 'normal',
      volume: 1.0,
      muted: false,
      fadeIn: 0.2,
      fadeOut: 0.2,
      adjustments: { ...defaultAdjustments },
      effects: [],
      mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
      chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
      keyframes: [],
      stickerConfig: {
        emojiOrUrl: '🔥',
        isCustomImage: false,
        category: 'Emoji',
      },
    },
    {
      id: 'clip_music_bgm',
      trackId: 'track_audio_bgm',
      trackType: 'audio',
      name: 'Lofi Chill Vibes',
      type: 'audio',
      sourceUrl: audioUrl,
      blob: audioBlob,
      start: 0,
      duration: 8,
      sourceStart: 0,
      sourceDuration: 8,
      speed: 1.0,
      reverse: false,
      x: 0,
      y: 0,
      scale: 1.0,
      rotation: 0,
      opacity: 1.0,
      flipH: false,
      flipV: false,
      blendMode: 'normal',
      volume: 0.8,
      muted: false,
      fadeIn: 1.0,
      fadeOut: 1.5,
      adjustments: { ...defaultAdjustments },
      effects: [],
      mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
      chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
      keyframes: [],
    },
  ];

  return {
    id: `project_${Date.now()}`,
    name: 'Clipora Showcase Demo',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    aspectRatio: '16:9',
    duration: 8.0,
    fps: 30,
    background: {
      type: 'color',
      color: '#000000',
    },
    tracks,
    clips,
  };
}
