/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { selfHealingEngine } from './selfHealingService';

export class ApiError extends Error {
  status: number;
  details?: any;

  constructor(message: string, status = 500, details?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
  }
}

/**
 * Robust fetch wrapper that guarantees:
 * 1. Autonomous Self-Healing execution with exponential backoff & jitter for 503/429/network drops
 * 2. Never attempts to JSON.parse() an HTML document (preventing SyntaxError: Unexpected token '<'...)
 * 3. Provides descriptive error diagnostics if the server returns non-JSON or HTML
 * 4. Gracefully unwraps server error messages from JSON payloads
 */
export async function safeFetchJson<T = any>(
  input: RequestInfo | URL,
  init?: RequestInit
): Promise<T> {
  const urlStr = typeof input === 'string' ? input : (input as any)?.url || 'api_call';

  return selfHealingEngine.executeWithSelfHealing(
    urlStr,
    async () => {
      const response = await fetch(input, init);
      const contentType = response.headers.get('content-type') || '';

      // Check if response is actually JSON before parsing
      if (!contentType.includes('application/json')) {
        const rawText = await response.text();
        const isHtml = rawText.trim().startsWith('<');

        if (isHtml) {
          throw new ApiError(
            `Backend service returned HTML (${response.status} ${response.statusText}). The API server route may be initializing or misrouted.`,
            response.status,
            rawText.slice(0, 200)
          );
        }

        throw new ApiError(
          `Received non-JSON response from server (${response.status}): ${rawText.slice(0, 150)}`,
          response.status,
          rawText
        );
      }

      let data: any;
      try {
        data = await response.json();
      } catch (parseErr: any) {
        throw new ApiError(
          `Failed to parse server JSON response: ${parseErr.message}`,
          response.status
        );
      }

      if (!response.ok) {
        const errorMsg = data?.error || data?.details || data?.message || `Request failed with status ${response.status}`;
        throw new ApiError(errorMsg, response.status, data);
      }

      return data as T;
    },
    { maxRetries: 3, initialDelayMs: 800 }
  );
}
