import {
  FriendUser,
  FriendRequest,
  ReadingRoom,
  RoomActivity,
  RoomChatMessage,
  RoomSharedItem,
  Book,
} from '../types';

const STORAGE_KEY_FRIENDS = 'mb_community_friends_v1';
const STORAGE_KEY_REQUESTS = 'mb_community_requests_v1';
const STORAGE_KEY_ROOMS = 'mb_community_rooms_v1';
const STORAGE_KEY_ACTIVITIES = 'mb_community_activities_v1';

const INITIAL_FRIENDS: FriendUser[] = [
  {
    id: 'friend-ana',
    name: 'Ana Gómez',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=256',
    bio: 'Devorando clásicos y ciencia ficción oscura. Siempre con un café.',
    statusText: 'Leyendo Frankenstein',
    isReadingNow: true,
    currentBookTitle: 'Frankenstein',
    sharedProfile: {
      favoriteBookTitle: 'Frankenstein',
      favoriteBookAuthor: 'Mary Shelley',
      favoriteBookCover: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=800',
      currentBookTitle: 'Frankenstein',
      currentBookAuthor: 'Mary Shelley',
      currentBookCover: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=800',
      favoriteAuthor: 'Mary Shelley',
      favoriteGenre: 'Gótico / Terror',
      theme: {
        primaryColor: '#8b5cf6',
        accentColor: '#ec4899',
        avatarFrameColor: '#a855f7',
        avatarFrameShape: 'glow',
        bannerType: 'preset',
        bannerValue: 'linear-gradient(135deg, #4c1d95 0%, #1e1b4b 100%)',
        bannerBlur: 16,
      },
      privacy: {
        showBooks: true,
        showFavoriteBook: true,
        showCurrentBook: true,
        showFavoriteAuthor: true,
        showFavoriteGenre: true,
        showStats: true,
        showActivity: true,
        showCollections: true,
        showQuotes: true,
      },
    },
  },
  {
    id: 'friend-luis',
    name: 'Luis Navarro',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=256',
    bio: 'Fanático del Worldbuilding espacial y la fantasía épica.',
    statusText: 'Avanzando a paso firme',
    isReadingNow: false,
    currentBookTitle: 'Dune',
    sharedProfile: {
      favoriteBookTitle: 'Dune',
      favoriteBookAuthor: 'Frank Herbert',
      favoriteBookCover: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=800',
      currentBookTitle: 'Frankenstein',
      currentBookAuthor: 'Mary Shelley',
      favoriteAuthor: 'Frank Herbert',
      favoriteGenre: 'Space Opera',
      theme: {
        primaryColor: '#0ea5e9',
        accentColor: '#10b981',
        avatarFrameColor: '#0284c7',
        avatarFrameShape: 'rounded',
        bannerType: 'preset',
        bannerValue: 'linear-gradient(135deg, #0c4a6e 0%, #064e3b 100%)',
        bannerBlur: 20,
      },
      privacy: {
        showBooks: true,
        showFavoriteBook: true,
        showCurrentBook: true,
        showFavoriteAuthor: true,
        showFavoriteGenre: true,
        showStats: true,
        showActivity: true,
        showCollections: false,
        showQuotes: true,
      },
    },
  },
  {
    id: 'friend-carlos',
    name: 'Carlos Mendoza',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=256',
    bio: 'Buscando el significado de la existencia entre páginas.',
    statusText: 'En pausa activa',
    isReadingNow: false,
    currentBookTitle: 'Solaris',
    sharedProfile: {
      favoriteBookTitle: 'Solaris',
      favoriteBookAuthor: 'Stanisław Lem',
      favoriteAuthor: 'Stanisław Lem',
      favoriteGenre: 'Filosofía / Sci-Fi',
      theme: {
        primaryColor: '#f59e0b',
        accentColor: '#ef4444',
        avatarFrameColor: '#d97706',
        avatarFrameShape: 'circle',
        bannerType: 'preset',
        bannerValue: 'linear-gradient(135deg, #78350f 0%, #450a0a 100%)',
        bannerBlur: 14,
      },
      privacy: {
        showBooks: true,
        showFavoriteBook: true,
        showCurrentBook: false,
        showFavoriteAuthor: true,
        showFavoriteGenre: true,
        showStats: true,
        showActivity: true,
        showCollections: true,
        showQuotes: true,
      },
    },
  },
  {
    id: 'friend-maria',
    name: 'María Torres',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=256',
    bio: 'Lectora voraz. Reseñas sinceras sin spoilers.',
    statusText: 'Terminando Fundación',
    isReadingNow: false,
    currentBookTitle: 'Fundación',
    sharedProfile: {
      favoriteBookTitle: 'Fundación',
      favoriteBookAuthor: 'Isaac Asimov',
      favoriteAuthor: 'Isaac Asimov',
      favoriteGenre: 'Ciencia Ficción',
      theme: {
        primaryColor: '#10b981',
        accentColor: '#6366f1',
        avatarFrameColor: '#059669',
        avatarFrameShape: 'hexagon',
        bannerType: 'preset',
        bannerValue: 'linear-gradient(135deg, #064e3b 0%, #312e81 100%)',
        bannerBlur: 18,
      },
      privacy: {
        showBooks: true,
        showFavoriteBook: true,
        showCurrentBook: true,
        showFavoriteAuthor: true,
        showFavoriteGenre: true,
        showStats: true,
        showActivity: true,
        showCollections: true,
        showQuotes: true,
      },
    },
  },
];

const INITIAL_REQUESTS: FriendRequest[] = [
  {
    id: 'req-sofia',
    senderId: 'user-sofia',
    senderName: 'Sofía Valdés',
    senderAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=256',
    timestamp: '2026-10-04T18:20:00Z',
    status: 'pending',
  },
];

const INITIAL_ROOMS: ReadingRoom[] = [
  {
    id: 'room-frankenstein',
    bookId: 'book-frankenstein',
    bookTitle: 'Frankenstein',
    bookAuthor: 'Mary Shelley',
    bookCover: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=800',
    createdAt: '2026-10-01T10:00:00Z',
    createdBy: 'me',
    participants: [
      {
        userId: 'me',
        name: 'Tú (Yo)',
        avatar: '',
        progress: 47,
        currentPage: 132,
        isReadingNow: false,
        lastActive: 'Hace 30 min',
      },
      {
        userId: 'friend-ana',
        name: 'Ana',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=256',
        progress: 32,
        currentPage: 90,
        isReadingNow: true,
        lastActive: 'Leyendo ahora',
      },
      {
        userId: 'friend-luis',
        name: 'Luis',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=256',
        progress: 61,
        currentPage: 171,
        isReadingNow: false,
        lastActive: 'Hace 2 h',
      },
    ],
    sharedItems: [
      {
        id: 'item-1',
        roomId: 'room-frankenstein',
        bookId: 'book-frankenstein',
        userId: 'friend-ana',
        userName: 'Ana',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=256',
        type: 'quote',
        page: 24,
        text: 'No hay nada más doloroso para el espíritu humano que un gran y repentino cambio.',
        color: '#ec4899',
        note: 'Esta reflexión me golpeó directo al pecho.',
        reaction: '💔 Muy emotivo',
        createdAt: '2026-10-04T19:30:00Z',
      },
      {
        id: 'item-2',
        roomId: 'room-frankenstein',
        bookId: 'book-frankenstein',
        userId: 'friend-luis',
        userName: 'Luis',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=256',
        type: 'note',
        page: 24,
        text: 'La ambición de Victor sobrepasa todo límite ético.',
        color: '#3b82f6',
        note: 'Fijaos en cómo Mary Shelley previó el dilema de la biotecnología moderna hace más de 200 años.',
        reaction: '💡 Buena idea',
        createdAt: '2026-10-04T20:10:00Z',
      },
      {
        id: 'item-3',
        roomId: 'room-frankenstein',
        bookId: 'book-frankenstein',
        userId: 'friend-ana',
        userName: 'Ana',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=256',
        type: 'highlight',
        page: 85,
        text: 'Aprendí que la posesión de una alta cuna y de riquezas era muy estimada.',
        color: '#a855f7',
        reaction: '🤔 Me hizo pensar',
        createdAt: '2026-10-04T21:15:00Z',
      },
    ],
    messages: [
      {
        id: 'msg-1',
        roomId: 'room-frankenstein',
        userId: 'friend-luis',
        userName: 'Luis',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=256',
        text: '¡Bienvenidos a la sala! Cada uno va a su ritmo, nada de carreras ni spoilers.',
        createdAt: '2026-10-01T10:15:00Z',
        reactions: { '👏': ['Ana', 'Tú (Yo)'] },
      },
      {
        id: 'msg-2',
        roomId: 'room-frankenstein',
        userId: 'friend-ana',
        userName: 'Ana',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=256',
        text: 'Estoy enamorada de la prosa de Mary Shelley en esta edición. El capítulo 4 es sobrecogedor.',
        createdAt: '2026-10-03T16:40:00Z',
        reactions: { '❤️': ['Luis'] },
      },
      {
        id: 'msg-3',
        roomId: 'room-frankenstein',
        userId: 'friend-carlos',
        userName: 'Carlos',
        userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=256',
        text: 'Acabo de ver la frase que compartió Ana en la página 24, ¡qué gran momento!',
        createdAt: '2026-10-04T21:20:00Z',
        reactions: { '🔥': ['Ana'] },
      },
    ],
    recentActivities: [
      {
        id: 'act-r1',
        roomId: 'room-frankenstein',
        bookTitle: 'Frankenstein',
        userId: 'friend-ana',
        userName: 'Ana',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=256',
        type: 'shared_quote',
        text: 'Ana compartió una frase de Frankenstein.',
        timestamp: 'Hace 15 min',
      },
      {
        id: 'act-r2',
        roomId: 'room-frankenstein',
        bookTitle: 'Frankenstein',
        userId: 'friend-luis',
        userName: 'Luis',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=256',
        type: 'progress',
        text: 'Luis avanzó al 48%.',
        timestamp: 'Hace 45 min',
      },
      {
        id: 'act-r3',
        roomId: 'room-frankenstein',
        bookTitle: 'Frankenstein',
        userId: 'friend-ana',
        userName: 'Ana',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=256',
        type: 'shared_note',
        text: 'Ana agregó una anotación.',
        timestamp: 'Hace 1 h',
      },
      {
        id: 'act-r4',
        roomId: 'room-frankenstein',
        bookTitle: 'Frankenstein',
        userId: 'friend-carlos',
        userName: 'Carlos',
        userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=256',
        type: 'reaction',
        text: 'Carlos reaccionó a una frase.',
        timestamp: 'Hace 2 h',
      },
      {
        id: 'act-r5',
        roomId: 'room-frankenstein',
        bookTitle: 'Frankenstein',
        userId: 'friend-maria',
        userName: 'María',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=256',
        type: 'comment',
        text: 'María comentó en la sala.',
        timestamp: 'Hace 3 h',
      },
    ],
  },
];

class CommunityService {
  private getStorage<T>(key: string, fallback: T): T {
    try {
      const saved = localStorage.getItem(key);
      if (!saved) {
        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
      }
      return JSON.parse(saved);
    } catch {
      return fallback;
    }
  }

  private setStorage<T>(key: string, data: T) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.warn('Could not save to localStorage:', key, e);
    }
  }

  getFriends(): FriendUser[] {
    return this.getStorage<FriendUser[]>(STORAGE_KEY_FRIENDS, INITIAL_FRIENDS);
  }

  saveFriends(friends: FriendUser[]) {
    this.setStorage(STORAGE_KEY_FRIENDS, friends);
  }

  addFriend(newFriend: FriendUser): FriendUser[] {
    const current = this.getFriends();
    if (current.some((f) => f.id === newFriend.id)) return current;
    const updated = [newFriend, ...current];
    this.saveFriends(updated);
    return updated;
  }

  getFriendRequests(): FriendRequest[] {
    return this.getStorage<FriendRequest[]>(STORAGE_KEY_REQUESTS, INITIAL_REQUESTS);
  }

  respondFriendRequest(requestId: string, accept: boolean): { requests: FriendRequest[]; friends: FriendUser[] } {
    const requests = this.getFriendRequests();
    const req = requests.find((r) => r.id === requestId);
    const updatedRequests = requests.filter((r) => r.id !== requestId);
    this.setStorage(STORAGE_KEY_REQUESTS, updatedRequests);

    let updatedFriends = this.getFriends();
    if (accept && req) {
      const newFriend: FriendUser = {
        id: req.senderId,
        name: req.senderName,
        avatar: req.senderAvatar,
        bio: 'Nuevo amigo en Mi Biblioteca',
        statusText: '¡Conectados!',
        isReadingNow: false,
      };
      updatedFriends = this.addFriend(newFriend);
    }
    return { requests: updatedRequests, friends: updatedFriends };
  }

  getRooms(): ReadingRoom[] {
    return this.getStorage<ReadingRoom[]>(STORAGE_KEY_ROOMS, INITIAL_ROOMS);
  }

  saveRooms(rooms: ReadingRoom[]) {
    this.setStorage(STORAGE_KEY_ROOMS, rooms);
  }

  getRoomById(roomId: string): ReadingRoom | undefined {
    return this.getRooms().find((r) => r.id === roomId);
  }

  getRoomForBook(bookId: string): ReadingRoom | undefined {
    return this.getRooms().find((r) => r.bookId === bookId);
  }

  createRoom(
    book: Book,
    invitedFriendIds: string[],
    myProgress: number,
    myPage: number
  ): ReadingRoom {
    const allFriends = this.getFriends();
    const invitedFriends = allFriends.filter((f) => invitedFriendIds.includes(f.id));

    const participants = [
      {
        userId: 'me',
        name: 'Tú (Yo)',
        avatar: '',
        progress: myProgress,
        currentPage: myPage,
        isReadingNow: false,
        lastActive: 'Ahora',
      },
      ...invitedFriends.map((f) => ({
        userId: f.id,
        name: f.name.split(' ')[0],
        avatar: f.avatar,
        progress: Math.floor(Math.random() * 30) + 10,
        currentPage: Math.floor((book.totalPages || 300) * 0.2),
        isReadingNow: Boolean(f.isReadingNow),
        lastActive: f.isReadingNow ? 'Leyendo ahora' : 'Hace un momento',
      })),
    ];

    const initialActivity: RoomActivity = {
      id: 'act-' + Date.now(),
      roomId: 'room-' + Date.now(),
      bookTitle: book.title,
      userId: 'me',
      userName: 'Tú (Yo)',
      userAvatar: '',
      type: 'comment',
      text: `Se creó la sala de lectura para "${book.title}".`,
      timestamp: 'Ahora mismo',
    };

    const newRoom: ReadingRoom = {
      id: 'room-' + Date.now(),
      bookId: book.id,
      bookTitle: book.title,
      bookAuthor: book.author,
      bookCover: book.coverUrl,
      createdAt: new Date().toISOString(),
      createdBy: 'me',
      participants,
      sharedItems: [],
      messages: [
        {
          id: 'msg-' + Date.now(),
          roomId: 'room-' + Date.now(),
          userId: 'me',
          userName: 'Tú (Yo)',
          userAvatar: '',
          text: `¡Bienvenidos a la sala de "${book.title}"! Cada uno lee a su ritmo.`,
          createdAt: new Date().toISOString(),
        },
      ],
      recentActivities: [initialActivity],
    };

    const rooms = this.getRooms();
    const updated = [newRoom, ...rooms];
    this.saveRooms(updated);
    return newRoom;
  }

  addMessage(roomId: string, messageText: string, replyToId?: string): ReadingRoom | undefined {
    const rooms = this.getRooms();
    const roomIndex = rooms.findIndex((r) => r.id === roomId);
    if (roomIndex === -1) return undefined;

    const room = rooms[roomIndex];
    const replyTarget = replyToId ? room.messages.find((m) => m.id === replyToId) : undefined;

    const newMsg: RoomChatMessage = {
      id: 'msg-' + Date.now(),
      roomId,
      userId: 'me',
      userName: 'Tú (Yo)',
      userAvatar: '',
      text: messageText,
      createdAt: new Date().toISOString(),
      replyToId,
      replyToText: replyTarget?.text,
    };

    const activity: RoomActivity = {
      id: 'act-' + Date.now(),
      roomId,
      bookTitle: room.bookTitle,
      userId: 'me',
      userName: 'Tú (Yo)',
      userAvatar: '',
      type: 'comment',
      text: `Comentó en la sala de "${room.bookTitle}".`,
      timestamp: 'Ahora mismo',
    };

    const updatedRoom: ReadingRoom = {
      ...room,
      messages: [...room.messages, newMsg],
      recentActivities: [activity, ...room.recentActivities.slice(0, 15)],
    };

    rooms[roomIndex] = updatedRoom;
    this.saveRooms(rooms);
    return updatedRoom;
  }

  addReactionToMessage(roomId: string, messageId: string, emoji: string): ReadingRoom | undefined {
    const rooms = this.getRooms();
    const roomIndex = rooms.findIndex((r) => r.id === roomId);
    if (roomIndex === -1) return undefined;

    const room = rooms[roomIndex];
    const updatedMessages = room.messages.map((m) => {
      if (m.id !== messageId) return m;
      const reactions = { ...(m.reactions || {}) };
      const users = reactions[emoji] ? [...reactions[emoji]] : [];
      if (users.includes('Tú (Yo)')) {
        reactions[emoji] = users.filter((u) => u !== 'Tú (Yo)');
        if (reactions[emoji].length === 0) delete reactions[emoji];
      } else {
        reactions[emoji] = [...users, 'Tú (Yo)'];
      }
      return { ...m, reactions };
    });

    const updatedRoom = { ...room, messages: updatedMessages };
    rooms[roomIndex] = updatedRoom;
    this.saveRooms(rooms);
    return updatedRoom;
  }

  addSharedItem(
    roomId: string,
    item: Omit<RoomSharedItem, 'id' | 'createdAt' | 'roomId'>
  ): ReadingRoom | undefined {
    const rooms = this.getRooms();
    const roomIndex = rooms.findIndex((r) => r.id === roomId);
    if (roomIndex === -1) return undefined;

    const room = rooms[roomIndex];
    const newItem: RoomSharedItem = {
      ...item,
      id: 'item-' + Date.now(),
      roomId,
      createdAt: new Date().toISOString(),
    };

    let actType: RoomActivity['type'] = 'shared_quote';
    let actText = `Compartió una frase en la página ${item.page}.`;
    if (item.type === 'highlight') {
      actType = 'shared_highlight';
      actText = `Compartió un subrayado en la página ${item.page}.`;
    } else if (item.type === 'note') {
      actType = 'shared_note';
      actText = `Agregó una anotación en la página ${item.page}.`;
    } else if (item.type === 'reaction') {
      actType = 'reaction';
      actText = `Reaccionó con ${item.reaction || 'emoji'} en la página ${item.page}.`;
    }

    const activity: RoomActivity = {
      id: 'act-' + Date.now(),
      roomId,
      bookTitle: room.bookTitle,
      userId: item.userId,
      userName: item.userName,
      userAvatar: item.userAvatar,
      type: actType,
      text: actText,
      timestamp: 'Ahora mismo',
    };

    const updatedRoom: ReadingRoom = {
      ...room,
      sharedItems: [newItem, ...room.sharedItems],
      recentActivities: [activity, ...room.recentActivities.slice(0, 15)],
    };

    rooms[roomIndex] = updatedRoom;
    this.saveRooms(rooms);
    return updatedRoom;
  }

  updateMyProgressInRoom(roomId: string, progress: number, page: number): ReadingRoom | undefined {
    const rooms = this.getRooms();
    const roomIndex = rooms.findIndex((r) => r.id === roomId);
    if (roomIndex === -1) return undefined;

    const room = rooms[roomIndex];
    const updatedParticipants = room.participants.map((p) => {
      if (p.userId === 'me') {
        return {
          ...p,
          progress,
          currentPage: page,
          lastActive: 'Leyendo ahora',
        };
      }
      return p;
    });

    const activity: RoomActivity = {
      id: 'act-' + Date.now(),
      roomId,
      bookTitle: room.bookTitle,
      userId: 'me',
      userName: 'Tú (Yo)',
      userAvatar: '',
      type: 'progress',
      text: `Avanzaste al ${progress}%.`,
      timestamp: 'Ahora mismo',
    };

    const updatedRoom: ReadingRoom = {
      ...room,
      participants: updatedParticipants,
      recentActivities: [activity, ...room.recentActivities.slice(0, 15)],
    };

    rooms[roomIndex] = updatedRoom;
    this.saveRooms(rooms);
    return updatedRoom;
  }

  getAllRecentActivities(): RoomActivity[] {
    const rooms = this.getRooms();
    const acts: RoomActivity[] = [];
    rooms.forEach((r) => {
      if (r.recentActivities) acts.push(...r.recentActivities);
    });
    return acts.slice(0, 10);
  }
}

export const communityService = new CommunityService();
