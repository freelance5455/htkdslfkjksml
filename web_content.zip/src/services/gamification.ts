/** تحديات دورية وإنجازات بمكافآت لمرة واحدة لكل فترة/إنجاز. */
import { completedCount, getProgressMap, getStats, overallProgress, studyStreak, subjectProgress } from './progress';
import { attempts } from './quiz';
import { getCardMap } from './flashcards';
import { getWallet, grantRewardOnce, recordAchievementUnlocks } from './economy';
import { allLessons, subjects } from '../data/content';
import { KEYS, readKey } from './storage';
import { getFarm } from './farm';
import { studySessions } from './studySessions';

export type ChallengeFrequency = 'daily' | 'weekly';
export interface ChallengeDefinition {
  id: string;
  title: string;
  description: string;
  frequency: ChallengeFrequency;
  metric: 'studyMinutes' | 'lessons' | 'quizzes' | 'cards' | 'subjects' | 'sessions' | 'writtenAnswers' | 'harvests';
  goal: number;
  reward: number;
  progressLabel: string;
}
export interface ChallengeView extends ChallengeDefinition {
  periodKey: string;
  progress: number;
  completed: boolean;
  claimed: boolean;
}
export interface AchievementView {
  id: string;
  title: string;
  description: string;
  reward: number;
  progress: number;
  goal: number;
  unlocked: boolean;
  claimed: boolean;
  unlockedAt?: number;
  claimedAt?: number;
  category: string;
}

export const CHALLENGES: ChallengeDefinition[] = [
  { id: 'daily-30m', title: 'نصف ساعة تركيز', description: 'اجمع ٣٠ دقيقة دراسة نشطة اليوم.', frequency: 'daily', metric: 'studyMinutes', goal: 30, reward: 5, progressLabel: 'دقائق الدراسة النشطة اليوم.' },
  { id: 'daily-lesson', title: 'خطوة في المنهاج', description: 'أكمل درساً واحداً اليوم.', frequency: 'daily', metric: 'lessons', goal: 1, reward: 4, progressLabel: 'دروس أُكملت اليوم.' },
  { id: 'daily-quiz', title: 'اختبر فهمك', description: 'أكمل اختباراً واحداً اليوم.', frequency: 'daily', metric: 'quizzes', goal: 1, reward: 4, progressLabel: 'اختبارات أُكملت اليوم.' },
  { id: 'daily-cards', title: 'ذاكرة نشطة', description: 'راجع ٥ بطاقات اليوم.', frequency: 'daily', metric: 'cards', goal: 5, reward: 3, progressLabel: 'بطاقات راجعتها اليوم.' },
  { id: 'daily-45m', title: 'جلسة عميقة', description: 'اجمع ٤٥ دقيقة دراسة نشطة اليوم.', frequency: 'daily', metric: 'studyMinutes', goal: 45, reward: 8, progressLabel: 'دقائق الدراسة النشطة اليوم.' },
  { id: 'daily-2lessons', title: 'درسان للأمام', description: 'أكمل درسين اليوم.', frequency: 'daily', metric: 'lessons', goal: 2, reward: 8, progressLabel: 'دروس أُكملت اليوم.' },
  { id: 'daily-2quizzes', title: 'تدرّب مرتين', description: 'أكمل اختبارين اليوم.', frequency: 'daily', metric: 'quizzes', goal: 2, reward: 7, progressLabel: 'اختبارات أُكملت اليوم.' },
  { id: 'daily-10cards', title: 'مراجعة مركّزة', description: 'راجع ١٠ بطاقات اليوم.', frequency: 'daily', metric: 'cards', goal: 10, reward: 6, progressLabel: 'بطاقات راجعتها اليوم.' },
  { id: 'daily-subjects', title: 'نوّع مذاكرتك', description: 'ادرس مادتين مختلفتين اليوم.', frequency: 'daily', metric: 'subjects', goal: 2, reward: 5, progressLabel: 'مواد درستها اليوم.' },
  { id: 'daily-session', title: 'جلسة مكتملة', description: 'أكمل جلسة تركيز ٢٥ أو ٥٠ دقيقة.', frequency: 'daily', metric: 'sessions', goal: 1, reward: 6, progressLabel: 'جلسات تركيز مكتملة اليوم.' },
  { id: 'daily-write', title: 'اكتب لتتذكر', description: 'أجب عن سؤال تحريري واحد اليوم.', frequency: 'daily', metric: 'writtenAnswers', goal: 1, reward: 5, progressLabel: 'إجابات تحريرية أرسلتها اليوم.' },
  { id: 'daily-harvest', title: 'وقت الحصاد', description: 'احصد محصولاً نضج مع دراستك.', frequency: 'daily', metric: 'harvests', goal: 1, reward: 7, progressLabel: 'محاصيل بعتها اليوم.' },
  { id: 'weekly-300m', title: 'خمس ساعات هذا الأسبوع', description: 'اجمع ٣٠٠ دقيقة دراسة نشطة هذا الأسبوع.', frequency: 'weekly', metric: 'studyMinutes', goal: 300, reward: 25, progressLabel: 'دقائق الدراسة النشطة هذا الأسبوع.' },
  { id: 'weekly-lessons', title: 'تقدّم ثابت', description: 'أكمل ٥ دروس هذا الأسبوع.', frequency: 'weekly', metric: 'lessons', goal: 5, reward: 18, progressLabel: 'دروس أُكملت هذا الأسبوع.' },
  { id: 'weekly-quizzes', title: 'أسبوع الاختبارات', description: 'أكمل ٣ اختبارات هذا الأسبوع.', frequency: 'weekly', metric: 'quizzes', goal: 3, reward: 15, progressLabel: 'اختبارات أُكملت هذا الأسبوع.' },
  { id: 'weekly-cards', title: 'مراجعة متراكمة', description: 'راجع ٢٠ بطاقة هذا الأسبوع.', frequency: 'weekly', metric: 'cards', goal: 20, reward: 15, progressLabel: 'بطاقات راجعتها هذا الأسبوع.' },
  { id: 'weekly-subjects', title: 'تنويع ذكي', description: 'ادرس ٤ مواد مختلفة هذا الأسبوع.', frequency: 'weekly', metric: 'subjects', goal: 4, reward: 20, progressLabel: 'مواد درستها هذا الأسبوع.' },
];

type AchievementMetric = 'studyMinutes' | 'streak' | 'lessons' | 'quizzes' | 'perfect' | 'cards' | 'subjects' | 'overall' | 'points' | 'challengeClaims' | 'farmHarvests' | 'plantSpecies' | 'masteredSubjects' | 'questionAttempts' | 'writtenAnswers';

interface AchievementDefinition {
  id: string;
  title: string;
  description: string;
  category: string;
  metric: AchievementMetric;
  goal: number;
  reward: number;
}

const BASE_ACHIEVEMENTS: AchievementDefinition[] = [
  { id: 'study-1m', title: 'أول خطوة', description: 'سجّل دقيقة دراسة نشطة.', category: 'الدراسة', metric: 'studyMinutes', goal: 1, reward: 2 },
  { id: 'study-5h', title: 'خمس ساعات تركيز', description: 'اجمع ٥ ساعات دراسة نشطة.', category: 'الدراسة', metric: 'studyMinutes', goal: 300, reward: 8 },
  { id: 'study-25h', title: 'رفيق الدراسة', description: 'اجمع ٢٥ ساعة دراسة نشطة.', category: 'الدراسة', metric: 'studyMinutes', goal: 1500, reward: 20 },
  { id: 'study-100h', title: 'مئة ساعة إنجاز', description: 'اجمع ١٠٠ ساعة دراسة نشطة.', category: 'الدراسة', metric: 'studyMinutes', goal: 6000, reward: 60 },
  { id: 'streak-3', title: 'ثلاثة أيام', description: 'حافظ على سلسلة دراسة لثلاثة أيام.', category: 'الاستمرارية', metric: 'streak', goal: 3, reward: 5 },
  { id: 'streak-7', title: 'أسبوع منضبط', description: 'حافظ على سلسلة دراسة لسبعة أيام.', category: 'الاستمرارية', metric: 'streak', goal: 7, reward: 12 },
  { id: 'streak-30', title: 'شهر من العزم', description: 'حافظ على سلسلة دراسة لثلاثين يوماً.', category: 'الاستمرارية', metric: 'streak', goal: 30, reward: 40 },
  { id: 'streak-100', title: 'مئة يوم متتالٍ', description: 'حافظ على سلسلة دراسة لمئة يوم.', category: 'الاستمرارية', metric: 'streak', goal: 100, reward: 100 },
  { id: 'lesson-1', title: 'أول درس', description: 'أكمل أول درس في المنهاج.', category: 'الدروس', metric: 'lessons', goal: 1, reward: 3 },
  { id: 'lesson-10', title: 'عشرة دروس', description: 'أكمل ١٠ دروس.', category: 'الدروس', metric: 'lessons', goal: 10, reward: 10 },
  { id: 'lesson-25', title: 'ربع الطريق', description: 'أكمل ٢٥ درساً.', category: 'الدروس', metric: 'lessons', goal: 25, reward: 20 },
  { id: 'lesson-50', title: 'خمسون درساً', description: 'أكمل ٥٠ درساً.', category: 'الدروس', metric: 'lessons', goal: 50, reward: 40 },
  { id: 'quiz-1', title: 'أول اختبار', description: 'أكمل أول اختبار.', category: 'الاختبارات', metric: 'quizzes', goal: 1, reward: 3 },
  { id: 'quiz-10', title: 'عشرة اختبارات', description: 'أكمل ١٠ اختبارات.', category: 'الاختبارات', metric: 'quizzes', goal: 10, reward: 12 },
  { id: 'quiz-25', title: 'متدرّب متمرس', description: 'أكمل ٢٥ اختباراً.', category: 'الاختبارات', metric: 'quizzes', goal: 25, reward: 25 },
  { id: 'perfect-1', title: 'إجابة كاملة', description: 'احصل على الدرجة الكاملة في اختبار.', category: 'الاختبارات', metric: 'perfect', goal: 1, reward: 8 },
  { id: 'perfect-5', title: 'دقّة عالية', description: 'احصل على الدرجة الكاملة في ٥ اختبارات.', category: 'الاختبارات', metric: 'perfect', goal: 5, reward: 25 },
  { id: 'cards-1', title: 'أول بطاقة', description: 'راجع بطاقة تعليمية.', category: 'المراجعة', metric: 'cards', goal: 1, reward: 2 },
  { id: 'cards-20', title: 'عشرون مراجعة', description: 'أكمل ٢٠ تقييماً لبطاقات المراجعة.', category: 'المراجعة', metric: 'cards', goal: 20, reward: 8 },
  { id: 'cards-50', title: 'ذاكرة قوية', description: 'أكمل ٥٠ تقييماً لبطاقات المراجعة.', category: 'المراجعة', metric: 'cards', goal: 50, reward: 18 },
  { id: 'cards-100', title: 'مئة مراجعة', description: 'أكمل ١٠٠ تقييم لبطاقات المراجعة.', category: 'المراجعة', metric: 'cards', goal: 100, reward: 35 },
  { id: 'subjects-4', title: 'متعدد المواد', description: 'ادرس أربع مواد مختلفة على الأقل.', category: 'المواد', metric: 'subjects', goal: 4, reward: 10 },
  { id: 'subjects-all', title: 'منارة لكل مادة', description: 'ادرس المواد الثماني كلها.', category: 'المواد', metric: 'subjects', goal: 8, reward: 35 },
  { id: 'overall-50', title: 'نصف المنهاج', description: 'أكمل نصف دروس المنهاج المتاحة.', category: 'التقدم', metric: 'overall', goal: 50, reward: 20 },
  { id: 'points-100', title: 'رصيد المئة', description: 'اكسب ١٠٠ نقطة من الدراسة والمكافآت.', category: 'النقاط', metric: 'points', goal: 100, reward: 12 },
  { id: 'points-500', title: 'جامع النقاط', description: 'اكسب ٥٠٠ نقطة من الدراسة والمكافآت.', category: 'النقاط', metric: 'points', goal: 500, reward: 40 },
];

function achievementDescription(metric: AchievementMetric, goal: number): string {
  const value = new Intl.NumberFormat('ar-SY').format(goal);
  switch (metric) {
    case 'studyMinutes': return `اجمع ${value} دقيقة دراسة نشطة.`;
    case 'streak': return `حافظ على سلسلة دراسة ${value} يوماً.`;
    case 'lessons': return `أكمل ${value} درساً.`;
    case 'quizzes': return `أكمل ${value} اختبارات.`;
    case 'perfect': return `احصل على العلامة الكاملة في ${value} اختبارات.`;
    case 'cards': return `أكمل ${value} مراجعة لبطاقات التكرار المتباعد.`;
    case 'subjects': return `ادرس ${value} مواد مختلفة.`;
    case 'overall': return `بلغ التقدم الإجمالي في المنهاج ${value}%.`;
    case 'points': return `اكسب ${value} نقطة من الدراسة والإنجازات.`;
    case 'challengeClaims': return `استلم مكافآت ${value} تحديات.`;
    case 'farmHarvests': return `احصد وبِع ${value} محاصيل.`;
    case 'plantSpecies': return `احصد ${value} أنواع نباتات مختلفة.`;
    case 'masteredSubjects': return `أكمل كل الدروس المتاحة في ${value} مواد.`;
    case 'questionAttempts': return `أجب عن ${value} سؤالاً تدريبياً.`;
    case 'writtenAnswers': return `اكتب إجابات عن ${value} أسئلة تحريرية.`;
  }
}

function extraAchievement(
  id: string,
  title: string,
  category: string,
  metric: AchievementMetric,
  goal: number,
  reward: number,
): AchievementDefinition {
  return { id, title, description: achievementDescription(metric, goal), category, metric, goal, reward };
}

const EXTRA_ACHIEVEMENTS: AchievementDefinition[] = [
  extraAchievement('study-10h', 'عشر ساعات للهدف', 'الدراسة', 'studyMinutes', 600, 18),
  extraAchievement('study-30h', 'ثلاثون ساعة مثابرة', 'الدراسة', 'studyMinutes', 1800, 32),
  extraAchievement('study-50h', 'خمسون ساعة إنجاز', 'الدراسة', 'studyMinutes', 3000, 48),
  extraAchievement('study-200h', 'مئتا ساعة تركيز', 'الدراسة', 'studyMinutes', 12000, 120),
  extraAchievement('study-500h', 'خمسمئة ساعة تميّز', 'الدراسة', 'studyMinutes', 30000, 250),
  extraAchievement('streak-5', 'خمسة أيام متتالية', 'الاستمرارية', 'streak', 5, 7),
  extraAchievement('streak-10', 'عشرة أيام من العزم', 'الاستمرارية', 'streak', 10, 15),
  extraAchievement('streak-14', 'أسبوعان من الانضباط', 'الاستمرارية', 'streak', 14, 22),
  extraAchievement('streak-21', 'ثلاثة أسابيع ثابتة', 'الاستمرارية', 'streak', 21, 30),
  extraAchievement('streak-50', 'خمسون يوماً من الالتزام', 'الاستمرارية', 'streak', 50, 65),
  extraAchievement('streak-150', 'مئة وخمسون يوماً متتالياً', 'الاستمرارية', 'streak', 150, 180),
  extraAchievement('lesson-75', 'خمسة وسبعون درساً', 'الدروس', 'lessons', 75, 55),
  extraAchievement('lesson-100', 'مئة درس مكتمل', 'الدروس', 'lessons', 100, 70),
  extraAchievement('lesson-150', 'مئة وخمسون خطوة', 'الدروس', 'lessons', 150, 100),
  extraAchievement('lesson-250', 'ربع ألف درس', 'الدروس', 'lessons', 250, 160),
  extraAchievement('lesson-400', 'أربعمئة درس منجز', 'الدروس', 'lessons', 400, 240),
  extraAchievement('quiz-50', 'خمسون اختباراً تدريبياً', 'الاختبارات', 'quizzes', 50, 45),
  extraAchievement('quiz-100', 'مئة اختبار', 'الاختبارات', 'quizzes', 100, 80),
  extraAchievement('quiz-250', 'مئتان وخمسون اختباراً', 'الاختبارات', 'quizzes', 250, 140),
  extraAchievement('quiz-500', 'خمسمئة محاولة واعية', 'الاختبارات', 'quizzes', 500, 220),
  extraAchievement('perfect-10', 'عشر علامات كاملة', 'الاختبارات', 'perfect', 10, 40),
  extraAchievement('perfect-25', 'خمسة وعشرون إتقاناً', 'الاختبارات', 'perfect', 25, 75),
  extraAchievement('perfect-50', 'خمسون اختباراً متقناً', 'الاختبارات', 'perfect', 50, 130),
  extraAchievement('cards-150', 'مئة وخمسون مراجعة', 'المراجعة', 'cards', 150, 45),
  extraAchievement('cards-250', 'ذاكرة لا تنسى', 'المراجعة', 'cards', 250, 70),
  extraAchievement('cards-500', 'خمسمئة بطاقة ثابتة', 'المراجعة', 'cards', 500, 125),
  extraAchievement('cards-1000', 'ألف مراجعة ذكية', 'المراجعة', 'cards', 1000, 220),
  extraAchievement('mastery-4', 'أربع مواد متقنة', 'المواد', 'masteredSubjects', 4, 65),
  extraAchievement('mastery-8', 'إتقان المواد الثماني', 'المواد', 'masteredSubjects', 8, 180),
  extraAchievement('overall-60', 'تجاوزت ثلاثة أخماس الطريق', 'التقدم', 'overall', 60, 30),
  extraAchievement('overall-75', 'ثلاثة أرباع المنهاج', 'التقدم', 'overall', 75, 45),
  extraAchievement('overall-90', 'اقتربت من خط النهاية', 'التقدم', 'overall', 90, 70),
  extraAchievement('overall-100', 'أكملت ما هو متاح', 'التقدم', 'overall', 100, 120),
  extraAchievement('points-1000', 'ألف نقطة مكتسبة', 'النقاط', 'points', 1000, 55),
  extraAchievement('points-2500', 'رصيد مثابر', 'النقاط', 'points', 2500, 85),
  extraAchievement('points-5000', 'خمسة آلاف نقطة', 'النقاط', 'points', 5000, 150),
  extraAchievement('challenges-10', 'عشرة تحديات مستلمة', 'التحديات', 'challengeClaims', 10, 20),
  extraAchievement('challenges-50', 'خمسون تحدياً مكتمل المكافأة', 'التحديات', 'challengeClaims', 50, 70),
  extraAchievement('challenges-150', 'مئة وخمسون تحدياً', 'التحديات', 'challengeClaims', 150, 160),
  extraAchievement('farm-1', 'أول حصاد', 'المزرعة', 'farmHarvests', 1, 8),
  extraAchievement('farm-10', 'عشرة محاصيل', 'المزرعة', 'farmHarvests', 10, 35),
  extraAchievement('farm-50', 'بستان مثمر', 'المزرعة', 'farmHarvests', 50, 100),
  extraAchievement('farm-species-4', 'تنوع أخضر', 'المزرعة', 'plantSpecies', 4, 28),
  extraAchievement('farm-species-8', 'حديقة من ثمانية أنواع', 'المزرعة', 'plantSpecies', 8, 65),
  extraAchievement('written-10', 'عشر إجابات تحريرية', 'الإجابات التحريرية', 'writtenAnswers', 10, 18),
  extraAchievement('written-50', 'خمسون حلاً مكتوباً', 'الإجابات التحريرية', 'writtenAnswers', 50, 55),
  extraAchievement('written-100', 'مئة إجابة بخط يدك', 'الإجابات التحريرية', 'writtenAnswers', 100, 100),
  extraAchievement('questions-100', 'مئة سؤال محلول', 'الأسئلة التدريبية', 'questionAttempts', 100, 18),
  extraAchievement('questions-500', 'خمسمئة سؤال محلول', 'الأسئلة التدريبية', 'questionAttempts', 500, 55),
  extraAchievement('questions-1000', 'ألف سؤال للتفوق', 'الأسئلة التدريبية', 'questionAttempts', 1000, 100),
];

if (EXTRA_ACHIEVEMENTS.length !== 50) throw new Error('يجب أن تحتوي الإضافة على ٥٠ إنجازاً بالضبط.');
const FINAL_ACHIEVEMENTS: AchievementDefinition[] = [
  extraAchievement('study-750h', 'سبعمئة وخمسون ساعة', 'الدراسة', 'studyMinutes', 45_000, 420),
  extraAchievement('study-1000h', 'ألف ساعة من الاجتهاد', 'الدراسة', 'studyMinutes', 60_000, 600),
  extraAchievement('streak-200', 'مئتا يوم من الثبات', 'الاستمرارية', 'streak', 200, 260),
  extraAchievement('streak-365', 'عام كامل من الالتزام', 'الاستمرارية', 'streak', 365, 500),
  extraAchievement('lesson-300', 'ثلاثمئة درس مكتمل', 'الدروس', 'lessons', 300, 190),
  extraAchievement('quiz-750', 'سبعمئة وخمسون اختباراً', 'الاختبارات', 'quizzes', 750, 300),
  extraAchievement('quiz-1000', 'ألف محاولة تدريبية', 'الاختبارات', 'quizzes', 1_000, 400),
  extraAchievement('perfect-100', 'مئة نتيجة كاملة', 'الاختبارات', 'perfect', 100, 260),
  extraAchievement('perfect-200', 'مئتا اختبار متقن', 'الاختبارات', 'perfect', 200, 420),
  extraAchievement('cards-1500', 'ألف وخمسمئة مراجعة', 'المراجعة', 'cards', 1_500, 300),
  extraAchievement('cards-2500', 'ذاكرة راسخة', 'المراجعة', 'cards', 2_500, 450),
  extraAchievement('overall-25', 'ربع المنهاج وراءك', 'التقدم', 'overall', 25, 18),
  extraAchievement('overall-80', 'ثمانون بالمئة من الطريق', 'التقدم', 'overall', 80, 60),
  extraAchievement('points-10000', 'عشرة آلاف نقطة مكتسبة', 'النقاط', 'points', 10_000, 300),
  extraAchievement('points-25000', 'رصيد العزيمة', 'النقاط', 'points', 25_000, 550),
  extraAchievement('challenges-300', 'ثلاثمئة مكافأة تحدٍ', 'التحديات', 'challengeClaims', 300, 280),
  extraAchievement('challenges-500', 'خمسمئة تحدٍ مستحق', 'التحديات', 'challengeClaims', 500, 450),
  extraAchievement('farm-100', 'مئة حصاد مع الدراسة', 'المزرعة', 'farmHarvests', 100, 220),
  extraAchievement('farm-250', 'مئتان وخمسون حصاداً', 'المزرعة', 'farmHarvests', 250, 420),
  extraAchievement('farm-species-5', 'خمسة ألوان في الحديقة', 'المزرعة', 'plantSpecies', 5, 45),
  extraAchievement('farm-species-6', 'ستة أنواع مزروعة', 'المزرعة', 'plantSpecies', 6, 60),
  extraAchievement('questions-2500', 'ألفان وخمسمئة سؤال', 'الأسئلة التدريبية', 'questionAttempts', 2_500, 220),
  extraAchievement('questions-5000', 'خمسة آلاف سؤال محلول', 'الأسئلة التدريبية', 'questionAttempts', 5_000, 420),
  extraAchievement('written-250', 'مئتان وخمسون إجابة تحريرية', 'الإجابات التحريرية', 'writtenAnswers', 250, 260),
];

if (FINAL_ACHIEVEMENTS.length !== 24) throw new Error('يجب أن تحتوي الدفعة النهائية على ٢٤ إنجازاً بالضبط.');
const ACHIEVEMENTS: AchievementDefinition[] = [...BASE_ACHIEVEMENTS, ...EXTRA_ACHIEVEMENTS, ...FINAL_ACHIEVEMENTS];
if (ACHIEVEMENTS.length !== 100 || new Set(ACHIEVEMENTS.map((item) => item.id)).size !== 100) {
  throw new Error('يجب أن يحتوي سجل الإنجازات على ١٠٠ معرّف فريد بالضبط.');
}

function dateKey(date: Date): string {
  return `${date.getFullYear()}-${`${date.getMonth() + 1}`.padStart(2, '0')}-${`${date.getDate()}`.padStart(2, '0')}`;
}

function startOfWeek(date: Date): Date {
  const start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const mondayOffset = (start.getDay() + 6) % 7;
  start.setDate(start.getDate() - mondayOffset);
  return start;
}

function currentPeriod(frequency: ChallengeFrequency): { key: string; start: Date; end: Date } {
  const now = new Date();
  const start = frequency === 'daily' ? new Date(now.getFullYear(), now.getMonth(), now.getDate()) : startOfWeek(now);
  const end = new Date(start);
  end.setDate(end.getDate() + (frequency === 'daily' ? 1 : 7));
  return { key: dateKey(start), start, end };
}

function timestampInRange(timestamp: number, start: Date, end: Date): boolean {
  return timestamp >= start.getTime() && timestamp < end.getTime();
}

function periodValues(start: Date, end: Date) {
  const stats = getStats();
  let studySeconds = 0;
  const subjectsStudied = new Set<string>();
  for (const [key, day] of Object.entries(stats.days ?? {})) {
    const date = new Date(`${key}T00:00:00`);
    if (date >= start && date < end) {
      studySeconds += day.seconds ?? 0;
      for (const [subjectId, seconds] of Object.entries(day.bySubject ?? {})) {
        if (seconds > 0) subjectsStudied.add(subjectId);
      }
    }
  }
  const progress = Object.values(getProgressMap());
  const lessons = progress.filter((item) => item.completed && item.completedAt && timestampInRange(item.completedAt, start, end)).length;
  const quizCount = attempts().filter((attempt) => timestampInRange(attempt.at, start, end)).length;
  const cardCount = Object.values(getCardMap()).filter((card) => card.reviewedAt && timestampInRange(card.reviewedAt, start, end)).length;
  const sessions = studySessions().filter((item) => item.completed && timestampInRange(item.at, start, end)).length;
  const writtenAnswers = readKey<Array<{ at: number }>>(KEYS.writtenAnswers, []).filter((item) => timestampInRange(item.at, start, end)).length;
  const harvests = getFarm().harvestLog.filter((item) => timestampInRange(item.at, start, end)).length;
  return { studyMinutes: Math.floor(studySeconds / 60), lessons, quizzes: quizCount, cards: cardCount, subjects: subjectsStudied.size, sessions, writtenAnswers, harvests };
}

function selectedDailyChallenges(): ChallengeDefinition[] {
  const daily = CHALLENGES.filter((challenge) => challenge.frequency === 'daily');
  if (daily.length <= 5) return daily;
  const date = currentPeriod('daily').key;
  const seed = [...date].reduce((value, char) => (value * 31 + char.charCodeAt(0)) >>> 0, 7);
  const start = seed % daily.length;
  return Array.from({ length: 5 }, (_, index) => daily[(start + index) % daily.length]!);
}

export function getChallenges(): ChallengeView[] {
  const visibleChallenges = [...selectedDailyChallenges(), ...CHALLENGES.filter((challenge) => challenge.frequency === 'weekly')];
  return visibleChallenges.map((challenge) => {
    const period = currentPeriod(challenge.frequency);
    const value = periodValues(period.start, period.end)[challenge.metric];
    return {
      ...challenge,
      periodKey: period.key,
      progress: Math.min(challenge.goal, value),
      completed: value >= challenge.goal,
      claimed: getWallet().claimedRewardIds.includes(`challenge:${challenge.id}:${period.key}`),
    };
  });
}

export async function claimChallenge(challengeId: string): Promise<boolean> {
  const challenge = CHALLENGES.find((item) => item.id === challengeId);
  if (!challenge) return false;
  const view = getChallenges().find((item) => item.id === challengeId);
  if (!view?.completed || view.claimed) return false;
  return grantRewardOnce(
    `challenge:${challenge.id}:${view.periodKey}`,
    challenge.reward,
    `مكافأة التحدي: ${challenge.title}`,
    'challenge',
  );
}

function longestRecordedStreak(): number {
  const dates = new Set(
    Object.entries(getStats().days ?? {}).filter(([, day]) => day.seconds >= 60).map(([key]) => key),
  );
  for (const date of getWallet().streakFreezeDates) dates.add(date);
  const ordered = [...dates].sort();
  let longest = 0;
  let current = 0;
  let previousTime: number | undefined;
  for (const key of ordered) {
    const time = new Date(`${key}T00:00:00`).getTime();
    if (!Number.isFinite(time)) continue;
    current = previousTime !== undefined && Math.round((time - previousTime) / 86_400_000) === 1 ? current + 1 : 1;
    longest = Math.max(longest, current);
    previousTime = time;
  }
  return longest;
}

function lifetimeValues() {
  const allAttempts = attempts();
  const wallet = getWallet();
  const reviewed = Object.values(getCardMap()).reduce((total, card) => total + card.reps, 0);
  const subjectsWithTime = new Set<string>();
  for (const day of Object.values(getStats().days ?? {})) {
    for (const [subjectId, seconds] of Object.entries(day.bySubject ?? {})) {
      if (seconds > 0) subjectsWithTime.add(subjectId);
    }
  }
  const totalStudySeconds = wallet.studySeconds;
  const farm = getFarm();
  const practiceAttempts = readKey<Array<{ answeredCount?: number }>>(KEYS.practiceAttempts, []);
  const writtenAnswers = readKey<Array<{ at: number }>>(KEYS.writtenAnswers, []);
  return {
    studyMinutes: Math.floor(totalStudySeconds / 60),
    streak: Math.max(studyStreak(), longestRecordedStreak()),
    lessons: completedCount(),
    quizzes: allAttempts.length,
    perfect: allAttempts.filter((a) => a.total > 0 && a.score === a.total).length,
    cards: reviewed,
    subjects: subjectsWithTime.size,
    overall: overallProgress(),
    points: wallet.totalEarned,
    challengeClaims: wallet.claimedRewardIds.filter((id) => id.startsWith('challenge:')).length,
    farmHarvests: farm.totalHarvests,
    plantSpecies: Object.values(farm.harvestsByPlant).filter((count) => (count ?? 0) > 0).length,
    masteredSubjects: subjects.filter((subject) => subjectProgress(subject) >= 100).length,
    questionAttempts: practiceAttempts.reduce((total, item) => total + Math.max(0, Number(item.answeredCount) || 0), 0),
    writtenAnswers: writtenAnswers.length,
  };
}

export function getAchievements(): AchievementView[] {
  const values = lifetimeValues();
  const wallet = getWallet();
  return ACHIEVEMENTS.map((achievement) => {
    const current = values[achievement.metric];
    const claimId = `achievement:${achievement.id}`;
    const claimed = wallet.claimedRewardIds.includes(claimId);
    const unlocked = current >= achievement.goal || Boolean(wallet.achievementUnlockedAt[achievement.id]) || claimed;
    return {
      id: achievement.id,
      title: achievement.title,
      description: achievement.description,
      reward: achievement.reward,
      progress: unlocked ? achievement.goal : Math.min(achievement.goal, current),
      goal: achievement.goal,
      unlocked,
      claimed,
      unlockedAt: wallet.achievementUnlockedAt[achievement.id],
      claimedAt: wallet.claimedRewardAt[claimId] ?? wallet.ledger.find((entry) => entry.id === claimId)?.at,
      category: achievement.category,
    };
  });
}

/** يُستدعى مع تغيّر سجلات الدراسة ليُحفظ الاستحقاق قبل انكسار السلسلة. */
export async function syncAchievementUnlocks(): Promise<void> {
  const values = lifetimeValues();
  const wallet = getWallet();
  const eligible = ACHIEVEMENTS.filter((item) => {
    const wasClaimed = wallet.claimedRewardIds.includes(`achievement:${item.id}`);
    return (values[item.metric] >= item.goal || wasClaimed) && !wallet.achievementUnlockedAt[item.id];
  });
  const ids = eligible.map((item) => item.id);
  const dates: Record<string, number> = {};
  for (const item of eligible) {
    const claimId = `achievement:${item.id}`;
    const oldClaimDate = wallet.claimedRewardAt[claimId] ?? wallet.ledger.find((entry) => entry.id === claimId)?.at;
    if (oldClaimDate) dates[item.id] = oldClaimDate;
  }
  await recordAchievementUnlocks(ids, dates);
}

export async function claimAchievement(achievementId: string): Promise<boolean> {
  const achievement = ACHIEVEMENTS.find((item) => item.id === achievementId);
  if (!achievement) return false;
  const view = getAchievements().find((item) => item.id === achievementId);
  if (!view?.unlocked || view.claimed) return false;
  return grantRewardOnce(
    `achievement:${achievement.id}`,
    achievement.reward,
    `مكافأة الإنجاز: ${achievement.title}`,
    'achievement',
  );
}

export function challengeSummary(): { completed: number; claimed: number; total: number } {
  const items = getChallenges();
  return {
    completed: items.filter((item) => item.completed).length,
    claimed: items.filter((item) => item.claimed).length,
    total: items.length,
  };
}

export function achievementSummary(): { unlocked: number; claimed: number; total: number } {
  const items = getAchievements();
  return {
    unlocked: items.filter((item) => item.unlocked).length,
    claimed: items.filter((item) => item.claimed).length,
    total: items.length,
  };
}

export function subjectLabel(subjectId: string): string {
  return subjects.find((subject) => subject.id === subjectId)?.shortName ?? subjectId;
}

export function lessonCompletionTotal(): number {
  return allLessons.length;
}
