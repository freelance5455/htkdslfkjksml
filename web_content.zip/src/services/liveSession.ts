import { CameraState, LiveMessage, SessionState } from '../types';
import { AudioStreamer } from './audioStreamer';

export interface LiveSessionCallbacks {
  onStateChange: (state: SessionState) => void;
  onTranscript: (text: string, isModel: boolean) => void;
  onError: (message: string) => void;
  onInterrupted: () => void;
  onStatusMessage?: (msg: string) => void;
}

export class LiveSession {
  private ws: WebSocket | null = null;
  private audioStreamer: AudioStreamer;
  private state: SessionState = 'DISCONNECTED';
  private cameraState: CameraState = 'CAMERA_OFF';
  private callbacks: LiveSessionCallbacks;
  private userApiKey: string = '';
  private isConnecting: boolean = false;
  private lastFrameSentTime: number = 0;
  private frameSendIntervalMs: number = 700; // Responsive frame stream (~1.4 FPS)

  constructor(callbacks: LiveSessionCallbacks) {
    this.callbacks = callbacks;
    this.audioStreamer = new AudioStreamer();
  }

  public setApiKey(key: string): void {
    this.userApiKey = key;
  }

  public getState(): SessionState {
    return this.state;
  }

  public getAudioStreamer(): AudioStreamer {
    return this.audioStreamer;
  }

  public setCameraState(state: CameraState): void {
    this.cameraState = state;
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'camera_state',
          state: this.cameraState,
        })
      );
    }
  }

  /**
   * Connect to Gemini Live over WebSocket
   */
  public async connect(): Promise<void> {
    if (
      this.isConnecting ||
      (this.ws && (this.ws.readyState === WebSocket.CONNECTING || this.ws.readyState === WebSocket.OPEN))
    ) {
      return;
    }

    this.isConnecting = true;
    this.updateState('CONNECTING');

    try {
      // Initialize audio playback context early on user gesture
      this.audioStreamer.initPlayback();

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host = window.location.host;
      const keyParam = this.userApiKey ? `?key=${encodeURIComponent(this.userApiKey)}` : '';
      const wsUrl = `${protocol}//${host}/ws/live${keyParam}`;

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = async () => {
        this.isConnecting = false;
        this.updateState('LISTENING');

        // Inform backend of current camera state immediately
        this.ws?.send(
          JSON.stringify({
            type: 'camera_state',
            state: this.cameraState,
          })
        );

        // Start mic streaming immediately
        try {
          await this.audioStreamer.startRecording((base64Pcm16) => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
              this.ws.send(
                JSON.stringify({
                  type: 'audio',
                  data: base64Pcm16,
                })
              );
            }
          });
        } catch (micErr: unknown) {
          console.error('Microphone access failed:', micErr);
          this.callbacks.onError('Microphone permission denied. Please allow microphone access.');
          this.disconnect();
        }
      };

      this.ws.onmessage = (event) => {
        try {
          const msg: LiveMessage = JSON.parse(event.data);
          this.handleServerMessage(msg);
        } catch (e) {
          console.error('Failed to parse WebSocket message:', e);
        }
      };

      this.ws.onerror = (e) => {
        console.error('WebSocket error:', e);
        this.callbacks.onError('Connection to AI.P failed. Check your API key and connection.');
        this.updateState('ERROR');
      };

      this.ws.onclose = () => {
        this.isConnecting = false;
        if (this.state !== 'ERROR') {
          this.updateState('DISCONNECTED');
        }
        this.audioStreamer.stopRecording();
      };
    } catch (err: unknown) {
      this.isConnecting = false;
      this.updateState('ERROR');
      const errMessage = err instanceof Error ? err.message : 'Unknown connection error';
      this.callbacks.onError(errMessage);
    }
  }

  /**
   * Send live camera frame to Gemini Live API
   * Responsive frame stream with low-latency dispatch
   */
  public sendVideoFrame(base64Jpeg: string, force: boolean = false): boolean {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      return false;
    }

    if (this.cameraState !== 'CAMERA_ACTIVE') {
      return false;
    }

    // Skip periodic background frames while AI is already speaking to prioritize audio bandwidth
    if (this.state === 'SPEAKING' && !force) {
      return false;
    }

    const now = Date.now();
    if (!force && now - this.lastFrameSentTime < this.frameSendIntervalMs) {
      return false;
    }

    this.lastFrameSentTime = now;

    this.ws.send(
      JSON.stringify({
        type: 'video_frame',
        data: base64Jpeg,
        timestamp: now,
      })
    );

    return true;
  }

  /**
   * Send text prompt / instruction
   */
  public sendText(text: string): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'text',
          text,
        })
      );
    }
  }

  /**
   * Reset session context (used by CLEAN)
   */
  public cleanSession(): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'clean',
        })
      );
    }
    this.audioStreamer.interrupt();
    this.updateState('LISTENING');
  }

  public disconnect(): void {
    this.isConnecting = false;
    this.audioStreamer.stopAll();
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
    }
    this.updateState('DISCONNECTED');
  }

  private handleServerMessage(msg: LiveMessage): void {
    switch (msg.type) {
      case 'audio':
        if (msg.data) {
          this.updateState('SPEAKING');
          this.audioStreamer.playChunk(msg.data);
        }
        break;

      case 'interrupted':
        this.audioStreamer.interrupt();
        this.updateState('LISTENING');
        this.callbacks.onInterrupted();
        break;

      case 'turn_complete':
        this.updateState('LISTENING');
        break;

      case 'text':
        if (msg.text) {
          this.callbacks.onTranscript(msg.text, true);
        }
        break;

      case 'status':
        if (msg.status) {
          this.updateState(msg.status);
        }
        if (msg.message && this.callbacks.onStatusMessage) {
          this.callbacks.onStatusMessage(msg.message);
        }
        break;

      case 'error':
        this.updateState('ERROR');
        this.callbacks.onError(msg.message || 'An error occurred during live session.');
        break;
    }
  }

  private updateState(newState: SessionState): void {
    if (this.state !== newState) {
      this.state = newState;
      this.callbacks.onStateChange(newState);
    }
  }
}
