import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  addDoc,
  query,
  where,
  deleteDoc
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Team,
  TeamMember,
  TeamMemberRole,
  TeamInvitation,
  UserProfile,
  AssignedMember
} from '../types';

/**
 * Generate a deterministic and unique Manhwa Hart ID (e.g. MH-842910)
 */
export function generateUniqueUserId(seed?: string): string {
  if (seed && seed.trim().length > 0) {
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      hash = (hash << 5) - hash + seed.charCodeAt(i);
      hash |= 0;
    }
    const abs = Math.abs(hash);
    const code = (abs % 900000 + 100000).toString();
    return `MH-${code}`;
  }
  const randomNum = Math.floor(100000 + Math.random() * 900000);
  return `MH-${randomNum}`;
}

export const hartTeamService = {
  /**
   * Search for a registered user by their Unique ID (e.g. MH-123456) or Email or UserTag
   */
  async searchUser(searchTerm: string): Promise<UserProfile | null> {
    const term = searchTerm.trim();
    if (!term) return null;

    try {
      const usersRef = collection(db, 'users');

      // 1. Try search by Unique ID (exact uppercase)
      const upperTerm = term.toUpperCase();
      const qUnique = query(usersRef, where('uniqueId', '==', upperTerm));
      const snapUnique = await getDocs(qUnique);
      if (!snapUnique.empty) {
        return { uid: snapUnique.docs[0].id, ...(snapUnique.docs[0].data() as Omit<UserProfile, 'uid'>) };
      }

      // 2. Try search by Email (lowercase)
      const lowerTerm = term.toLowerCase();
      const qEmail = query(usersRef, where('email', '==', lowerTerm));
      const snapEmail = await getDocs(qEmail);
      if (!snapEmail.empty) {
        return { uid: snapEmail.docs[0].id, ...(snapEmail.docs[0].data() as Omit<UserProfile, 'uid'>) };
      }

      // 3. Try search by UserTag (e.g. @username or username)
      const cleanTag = term.replace(/^@/, '').toLowerCase();
      const qTag = query(usersRef, where('userTag', '==', cleanTag));
      const snapTag = await getDocs(qTag);
      if (!snapTag.empty) {
        return { uid: snapTag.docs[0].id, ...(snapTag.docs[0].data() as Omit<UserProfile, 'uid'>) };
      }

      // 4. Try exact document ID
      const directDoc = await getDoc(doc(db, 'users', term));
      if (directDoc.exists()) {
        return { uid: directDoc.id, ...(directDoc.data() as Omit<UserProfile, 'uid'>) };
      }

      return null;
    } catch (err) {
      console.error('Error searching user:', err);
      return null;
    }
  },

  /**
   * Send an official invitation to a user to join a team
   */
  async sendTeamInvitation(params: {
    team: Team;
    sender: UserProfile;
    targetUser: UserProfile;
    role: TeamMemberRole;
  }): Promise<string> {
    const { team, sender, targetUser, role } = params;

    // Check if user is already in the team
    const alreadyMember = team.members.some((m) => m.uid === targetUser.uid);
    if (alreadyMember) {
      throw new Error(`المستخدم "${targetUser.displayName}" عضو بالفعل في فريق ${team.name}`);
    }

    // Check if there is an active pending invitation
    const invCol = collection(db, 'team_invitations');
    const existingQ = query(
      invCol,
      where('teamId', '==', team.id),
      where('receiverId', '==', targetUser.uid),
      where('status', '==', 'pending')
    );
    const existingSnap = await getDocs(existingQ);
    if (!existingSnap.empty) {
      throw new Error('توجد دعوة انضمام معلقة بالفعل لهذا المستخدم في هذا الفريق.');
    }

    const invitationData: Omit<TeamInvitation, 'id'> = {
      teamId: team.id,
      teamName: team.name,
      teamLogo: team.logoUrl,
      senderId: sender.uid,
      senderName: sender.displayName,
      receiverId: targetUser.uid,
      receiverUniqueId: targetUser.uniqueId || generateUniqueUserId(targetUser.uid),
      receiverEmail: targetUser.email,
      receiverName: targetUser.displayName,
      receiverPhotoUrl: targetUser.photoUrl || '',
      role,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    try {
      const docRef = await addDoc(invCol, invitationData);
      return docRef.id;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'team_invitations');
    }
  },

  /**
   * Accept or decline a team invitation
   */
  async respondToInvitation(params: {
    invitation: TeamInvitation;
    accept: boolean;
    currentUser: UserProfile;
  }): Promise<void> {
    const { invitation, accept, currentUser } = params;
    const invRef = doc(db, 'team_invitations', invitation.id);

    try {
      if (accept) {
        // 1. Fetch current team data
        const teamRef = doc(db, 'teams', invitation.teamId);
        const teamSnap = await getDoc(teamRef);

        if (!teamSnap.exists()) {
          throw new Error('فريق الترجمة لم يعد متاحاً أو تم حذفه.');
        }

        const teamData = teamSnap.data() as Team;
        const currentMembers = teamData.members || [];

        // Check if not already added
        if (!currentMembers.some((m) => m.uid === currentUser.uid)) {
          const newMember: TeamMember = {
            uid: currentUser.uid,
            uniqueId: currentUser.uniqueId || generateUniqueUserId(currentUser.uid),
            email: currentUser.email,
            displayName: currentUser.displayName,
            photoUrl: currentUser.photoUrl || '',
            role: invitation.role,
            joinedAt: new Date().toISOString()
          };

          const updatedMembers = [...currentMembers, newMember];
          await updateDoc(teamRef, {
            members: updatedMembers,
            updatedAt: new Date().toISOString()
          });
        }

        // 2. Mark invitation accepted
        await updateDoc(invRef, {
          status: 'accepted',
          updatedAt: new Date().toISOString()
        });

        // 3. Update user profile teamId if needed
        const userRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userRef, {
          teamId: invitation.teamId
        });
      } else {
        // Decline invitation
        await updateDoc(invRef, {
          status: 'declined',
          updatedAt: new Date().toISOString()
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `team_invitations/${invitation.id}`);
    }
  },

  /**
   * Cancel a pending invitation (by sender / team manager)
   */
  async cancelInvitation(invitationId: string): Promise<void> {
    try {
      const invRef = doc(db, 'team_invitations', invitationId);
      await updateDoc(invRef, {
        status: 'cancelled',
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `team_invitations/${invitationId}`);
    }
  },

  /**
   * Update Team general settings (Owner or Manager)
   */
  async updateTeamSettings(teamId: string, updates: Partial<Team>): Promise<void> {
    try {
      const teamRef = doc(db, 'teams', teamId);
      await updateDoc(teamRef, {
        ...updates,
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `teams/${teamId}`);
    }
  },

  /**
   * Change a team member's role (Owner or Manager only)
   */
  async updateMemberRole(params: {
    team: Team;
    targetUid: string;
    newRole: TeamMemberRole;
    currentUid: string;
    isPlatformOwner: boolean;
  }): Promise<TeamMember[]> {
    const { team, targetUid, newRole, currentUid, isPlatformOwner } = params;

    const isLeader = team.leaderId === currentUid || isPlatformOwner;
    const isManager = team.members.find((m) => m.uid === currentUid)?.role === 'manager';

    if (!isLeader && !isManager) {
      throw new Error('غير مصرح لك بتغيير أدوار الأعضاء. الصلاحية لقائد ومدير الفريق فقط.');
    }

    if (targetUid === team.leaderId && newRole !== 'leader') {
      throw new Error('لا يمكن تغيير دور قائد الفريق من هنا، يرجى استخدام ميزة نقل الملكية.');
    }

    const updatedMembers = team.members.map((m) => {
      if (m.uid === targetUid) {
        return { ...m, role: newRole };
      }
      return m;
    });

    const teamRef = doc(db, 'teams', team.id);
    await updateDoc(teamRef, {
      members: updatedMembers,
      updatedAt: new Date().toISOString()
    });

    return updatedMembers;
  },

  /**
   * Remove a member from the team
   */
  async removeMember(params: {
    team: Team;
    targetUid: string;
    currentUid: string;
    isPlatformOwner: boolean;
  }): Promise<TeamMember[]> {
    const { team, targetUid, currentUid, isPlatformOwner } = params;

    const isLeader = team.leaderId === currentUid || isPlatformOwner;
    const isManager = team.members.find((m) => m.uid === currentUid)?.role === 'manager';

    if (!isLeader && !isManager && currentUid !== targetUid) {
      throw new Error('غير مصرح لك بإزالة هذا العضو.');
    }

    if (targetUid === team.leaderId) {
      throw new Error('لا يمكن إزالة مالك وقائد الفريق!');
    }

    const updatedMembers = team.members.filter((m) => m.uid !== targetUid);

    const teamRef = doc(db, 'teams', team.id);
    await updateDoc(teamRef, {
      members: updatedMembers,
      updatedAt: new Date().toISOString()
    });

    return updatedMembers;
  },

  /**
   * Safely transfer team ownership to another member
   */
  async transferOwnership(params: {
    team: Team;
    newLeaderUid: string;
    currentUid: string;
    isPlatformOwner: boolean;
  }): Promise<void> {
    const { team, newLeaderUid, currentUid, isPlatformOwner } = params;

    if (team.leaderId !== currentUid && !isPlatformOwner) {
      throw new Error('فقط قائد الفريق المالك يستطيع نقل ملكية الفريق.');
    }

    const newLeader = team.members.find((m) => m.uid === newLeaderUid);
    if (!newLeader) {
      throw new Error('العضو المحدد غير موجود في الفريق.');
    }

    // Update members roles: new leader becomes 'leader', old leader becomes 'manager'
    const updatedMembers = team.members.map((m) => {
      if (m.uid === newLeaderUid) {
        return { ...m, role: 'leader' as TeamMemberRole };
      }
      if (m.uid === team.leaderId) {
        return { ...m, role: 'manager' as TeamMemberRole };
      }
      return m;
    });

    const teamRef = doc(db, 'teams', team.id);
    await updateDoc(teamRef, {
      leaderId: newLeader.uid,
      leaderName: newLeader.displayName,
      members: updatedMembers,
      updatedAt: new Date().toISOString()
    });
  },

  /**
   * Assign specific team members or roles to a Manhwa/Novel/Manga work
   */
  async assignWorkMembers(params: {
    manhwaId: string;
    assignedMembers: AssignedMember[];
    allowedEditors?: string[];
  }): Promise<void> {
    const { manhwaId, assignedMembers, allowedEditors } = params;
    try {
      const manhwaRef = doc(db, 'manhwas', manhwaId);
      await updateDoc(manhwaRef, {
        assignedMembers,
        allowedEditors: allowedEditors || assignedMembers.map((m) => m.uid),
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `manhwas/${manhwaId}`);
    }
  }
};
