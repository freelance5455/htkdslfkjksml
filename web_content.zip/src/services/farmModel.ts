export type PlantId = 'wheat' | 'tomato' | 'mint' | 'rose' | 'lavender' | 'olive' | 'grape' | 'pomegranate' | 'sunflower' | 'jasmine' | 'basil' | 'date-palm';

export interface PlantDefinition {
  id: PlantId;
  name: string;
  seedPrice: number;
  harvestPoints: number;
  color: string;
  icon: 'wheat' | 'tomato' | 'mint' | 'rose' | 'lavender' | 'olive' | 'grape' | 'pomegranate';
  description: string;
}

export interface FarmPlot {
  id: number;
  unlocked: boolean;
  plant?: {
    id: PlantId;
    activeSeconds: number;
    plantedAt: number;
  };
}

export interface FarmState {
  plots: FarmPlot[];
  seeds: Partial<Record<PlantId, number>>;
  totalHarvests: number;
  harvestsByPlant: Partial<Record<PlantId, number>>;
  harvestLog: Array<{ plotId: number; plantId: PlantId; points: number; at: number }>;
}

export const FARM_MATURITY_SECONDS = 5 * 60 * 60;
export const FARM_PLOT_COSTS: Record<number, number> = {
  2: 80,
  3: 140,
  4: 230,
  5: 350,
  6: 500,
};

export const PLANT_CATALOG: PlantDefinition[] = [
  { id: 'wheat', name: 'سنابل القمح', seedPrice: 10, harvestPoints: 18, color: '#d3a43b', icon: 'wheat', description: 'بداية هادئة لمزرعتك.' },
  { id: 'tomato', name: 'طماطم', seedPrice: 12, harvestPoints: 21, color: '#df6955', icon: 'tomato', description: 'ثمر أحمر يزهر مع صبرك.' },
  { id: 'mint', name: 'نعناع', seedPrice: 14, harvestPoints: 24, color: '#5aab7a', icon: 'mint', description: 'نبتة خضراء منعشة.' },
  { id: 'rose', name: 'ورد جوري', seedPrice: 18, harvestPoints: 30, color: '#d56b88', icon: 'rose', description: 'وردة تتفتح على مهل.' },
  { id: 'lavender', name: 'خزامى', seedPrice: 18, harvestPoints: 30, color: '#9077c7', icon: 'lavender', description: 'لون هادئ لركن المزرعة.' },
  { id: 'olive', name: 'زيتون', seedPrice: 20, harvestPoints: 34, color: '#73924f', icon: 'olive', description: 'شجرة صغيرة تنمو بثبات.' },
  { id: 'grape', name: 'عنب', seedPrice: 22, harvestPoints: 36, color: '#805cae', icon: 'grape', description: 'عناقيد تنتظر اكتمالها.' },
  { id: 'pomegranate', name: 'رمان', seedPrice: 25, harvestPoints: 40, color: '#b94c5f', icon: 'pomegranate', description: 'ثمرة نادرة لمزارع مثابر.' },
  { id: 'sunflower', name: 'عبّاد الشمس', seedPrice: 21, harvestPoints: 35, color: '#e0ad37', icon: 'wheat', description: 'زهرة ذهبية تكبر مع ساعات تركيزك.' },
  { id: 'jasmine', name: 'ياسمين', seedPrice: 19, harvestPoints: 32, color: '#c68bad', icon: 'rose', description: 'زهرة عطرة افتراضية لحديقتك.' },
  { id: 'basil', name: 'ريحان', seedPrice: 16, harvestPoints: 27, color: '#5e9b68', icon: 'mint', description: 'نبتة منزلية خضراء تنمو مع الدراسة.' },
  { id: 'date-palm', name: 'نخلة تمر', seedPrice: 27, harvestPoints: 43, color: '#8b9c49', icon: 'olive', description: 'نخلة رقمية تحتاج إلى صبر ومثابرة.' },
];

export const EMPTY_FARM: FarmState = {
  plots: [
    { id: 1, unlocked: true },
    { id: 2, unlocked: false },
    { id: 3, unlocked: false },
    { id: 4, unlocked: false },
    { id: 5, unlocked: false },
    { id: 6, unlocked: false },
  ],
  // هدية بذرة أولى كي يبدأ الطالب تجربة المزرعة في القطعة المجانية.
  seeds: { wheat: 1 },
  totalHarvests: 0,
  harvestsByPlant: {},
  harvestLog: [],
};

export function normalizeFarm(value: Partial<FarmState> | null | undefined): FarmState {
  const incomingPlots = Array.isArray(value?.plots) ? value.plots : [];
  const plots = EMPTY_FARM.plots.map((base) => {
    const incoming = incomingPlots.find((plot) => plot?.id === base.id);
    return incoming
      ? {
          ...base,
          ...incoming,
          plant: incoming.plant && PLANT_CATALOG.some((plant) => plant.id === incoming.plant?.id)
            ? { ...incoming.plant, activeSeconds: Math.max(0, Math.min(FARM_MATURITY_SECONDS, incoming.plant.activeSeconds || 0)) }
            : undefined,
        }
      : { ...base };
  });
  plots[0] = { ...plots[0]!, unlocked: true };
  return {
    plots,
    seeds: { ...EMPTY_FARM.seeds, ...(value?.seeds ?? {}) },
    totalHarvests: Math.max(0, value?.totalHarvests ?? 0),
    harvestsByPlant: { ...(value?.harvestsByPlant ?? {}) },
    harvestLog: Array.isArray(value?.harvestLog) ? value.harvestLog.slice(-300) : [],
  };
}

/** يضيف الزمن النشط المسجل فقط؛ لا يعتمد على وقت الحائط أو بقاء التطبيق مفتوحاً. */
export function growFarmWithStudySeconds(value: FarmState, seconds: number): FarmState {
  if (!Number.isFinite(seconds) || seconds <= 0) return value;
  let changed = false;
  const plots = value.plots.map((plot) => {
    if (!plot.plant || plot.plant.activeSeconds >= FARM_MATURITY_SECONDS) return plot;
    const activeSeconds = Math.min(FARM_MATURITY_SECONDS, plot.plant.activeSeconds + Math.floor(seconds));
    if (activeSeconds === plot.plant.activeSeconds) return plot;
    changed = true;
    return { ...plot, plant: { ...plot.plant, activeSeconds } };
  });
  return changed ? { ...value, plots } : value;
}

export function plantForId(id: PlantId): PlantDefinition {
  return PLANT_CATALOG.find((plant) => plant.id === id) ?? PLANT_CATALOG[0]!;
}
