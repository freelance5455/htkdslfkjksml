import { AdminRole, UserRole, Permission, AdminUser } from '../types';

/**
 * E SPORTS TOUR — Single Admin Role & Permission System
 * Exactly one authorized Super Admin role with full control over all modules.
 * Secondary administrator roles (Tournament Admin, Payment Admin, Support Admin) are disallowed.
 */
export const ROLE_PERMISSIONS: Record<AdminRole, Permission[]> = {
  super_admin: [
    'manage_tournaments',
    'manage_rooms',
    'manage_payments',
    'manage_results',
    'manage_support',
    'view_audit_logs',
    'run_security_tests'
  ]
};

export const hasPermission = (role: UserRole, permission: Permission): boolean => {
  if (role !== 'super_admin') return false;
  const perms = ROLE_PERMISSIONS['super_admin'];
  return perms ? perms.includes(permission) : false;
};

export interface SecurityCheckResult {
  allowed: boolean;
  code: '200_OK' | '403_FORBIDDEN' | '401_UNAUTHORIZED' | '400_BAD_REQUEST' | '403_ROOT_IMMUTABLE' | '403_SINGLE_ADMIN_RESTRICTION';
  message: string;
}

/**
 * Backend Security Verification Layer
 * Enforces role checks, single Super Admin exclusivity, and privilege escalation guards.
 */
export const verifyAdminAction = (
  actorRole: UserRole,
  actorId: string,
  requiredPermission: Permission,
  targetAdmin?: AdminUser
): SecurityCheckResult => {
  // 1. Strict Role Clearance: Must be the authenticated Super Admin
  if (actorRole !== 'super_admin') {
    return {
      allowed: false,
      code: '403_FORBIDDEN',
      message: `Access Denied: Role '${actorRole}' is not authorized. Only the Super Admin (X SABBIR) has full app management clearance.`
    };
  }

  // 2. Check permission mapping
  const allowed = hasPermission(actorRole, requiredPermission);
  if (!allowed) {
    return {
      allowed: false,
      code: '403_FORBIDDEN',
      message: `Privilege Blocked: Super Admin missing required permission '${requiredPermission}'.`
    };
  }

  // 3. Strict Root Super Admin Immutability Protection
  if (targetAdmin && targetAdmin.isRootSuperAdmin && targetAdmin.id !== actorId) {
    return {
      allowed: false,
      code: '403_ROOT_IMMUTABLE',
      message: 'Security Violation: Root Super Admin (X SABBIR) cannot be removed, disabled, or demoted.'
    };
  }

  return {
    allowed: true,
    code: '200_OK',
    message: 'Authorized: Super Admin clearance granted.'
  };
};

/**
 * Enforce Single Admin Architecture:
 * Reject any attempt to invite, add, or create additional administrator roles.
 */
export const verifyCanAddAdmin = (): SecurityCheckResult => {
  return {
    allowed: false,
    code: '403_SINGLE_ADMIN_RESTRICTION',
    message: 'Architecture Restriction: E SPORTS TOUR operates on a strict Single Super Admin model (X SABBIR). No secondary administrator roles (Tournament Admin, Payment Admin, Support Admin) may be created.'
  };
};

/**
 * Validate that public self-service registration CANNOT escalate to admin.
 * Public users must never be able to create or promote themselves to admin.
 */
export const sanitizeRegistrationRole = (requestedRole?: string): UserRole => {
  if (requestedRole === 'super_admin' || requestedRole !== 'user') {
    return 'user';
  }
  return 'user';
};
