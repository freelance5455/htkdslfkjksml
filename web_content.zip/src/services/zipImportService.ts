/**
 * GODEX Safe Project Import & ZIP Workspace Integration Service
 * 
 * Strict Security & Extraction Engine:
 * - Rejects path traversal (e.g. '../', '..\\', absolute drive paths)
 * - Normalizes extracted paths and prevents out-of-workspace writes
 * - Binary & text file format preservation (Base64 data URLs for binary)
 * - Automatic common root directory unwrapping (e.g. GitHub ZIPs: repo-main/src -> src)
 * - Deep project structure & framework detection via ProjectDetector
 * - Non-destructive conflict analysis (replace, merge_overwrite, merge_keep, subfolder)
 * - Zero automatic script execution
 */

import JSZip from 'jszip';
import { ProjectDetector } from '../intelligence/projectDetector';
import { ProjectMetadata } from '../intelligence/types';
import { WorkspaceService } from './workspaceService';

export type ConflictStrategy = 'replace' | 'merge_overwrite' | 'merge_keep' | 'subfolder';

export interface ZipValidationResult {
  valid: boolean;
  error?: string;
  totalEntries: number;
  extractedFiles: Record<string, string>;
  rejectedPaths: Array<{ path: string; reason: string }>;
  conflicts: Array<{ path: string; existsInWorkspace: boolean }>;
  metadata: ProjectMetadata;
  suggestedStrategy: ConflictStrategy;
  commonPrefix?: string;
}

export interface ZipImportResult {
  success: boolean;
  importedFilesCount: number;
  strategy: ConflictStrategy;
  files: Record<string, string>;
  metadata: ProjectMetadata;
  error?: string;
  timestamp: number;
}

const TEXT_EXTENSIONS = new Set([
  'tsx', 'ts', 'jsx', 'js', 'mjs', 'cjs',
  'json', 'html', 'htm', 'css', 'scss', 'sass', 'less',
  'svg', 'md', 'markdown', 'txt', 'yaml', 'yml', 'toml', 'xml',
  'env', 'example', 'sh', 'bash', 'zsh', 'gitignore', 'npmignore',
  'prettierrc', 'eslintrc', 'editorconfig', 'conf', 'ini', 'py', 'rs', 'go', 'java', 'c', 'cpp', 'h'
]);

const BINARY_MIME_TYPES: Record<string, string> = {
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  gif: 'image/gif',
  webp: 'image/webp',
  ico: 'image/x-icon',
  svg: 'image/svg+xml',
  woff: 'font/woff',
  woff2: 'font/woff2',
  ttf: 'font/ttf',
  eot: 'application/vnd.ms-fontobject',
  mp3: 'audio/mpeg',
  wav: 'audio/wav',
  pdf: 'application/pdf',
  zip: 'application/zip'
};

export class ZipImportService {
  /**
   * Sanitizes and validates a ZIP entry path for path traversal vulnerabilities.
   */
  public static validateEntryPath(rawPath: string): { valid: boolean; normalized: string; reason?: string } {
    if (!rawPath || typeof rawPath !== 'string') {
      return { valid: false, normalized: '', reason: 'Empty or invalid path string' };
    }

    // 1. Path normalization
    const normalized = rawPath
      .replace(/\\/g, '/')
      .replace(/^\/+/, '')
      .replace(/^\.\//, '')
      .trim();

    // 2. Reject absolute paths (Windows drive letters or root slashes)
    if (/^[a-zA-Z]:/.test(rawPath) || rawPath.startsWith('/') || rawPath.startsWith('\\')) {
      return { valid: false, normalized, reason: 'Absolute path is forbidden' };
    }

    // 3. Reject directory traversal attacks (../, ..\, /../, etc.)
    const segments = normalized.split('/');
    if (segments.some(seg => seg === '..' || seg === '')) {
      // Check if it's a trailing slash from directory
      const cleanSegments = segments.filter(s => s.length > 0);
      if (cleanSegments.some(s => s === '..')) {
        return { valid: false, normalized, reason: 'Path traversal sequence (..) detected' };
      }
    }

    if (!normalized || normalized === '.') {
      return { valid: false, normalized, reason: 'Invalid or empty target path' };
    }

    return { valid: true, normalized };
  }

  /**
   * Determines if a file should be read as text or binary.
   */
  public static isTextFile(filename: string): boolean {
    const clean = filename.toLowerCase();
    const basename = clean.split('/').pop() || '';
    
    // Dotfiles without standard extensions
    if (basename.startsWith('.') || basename === 'dockerfile' || basename === 'makefile' || basename === 'license') {
      return true;
    }

    const ext = clean.split('.').pop() || '';
    return TEXT_EXTENSIONS.has(ext);
  }

  /**
   * Determines mime type for binary assets
   */
  public static getMimeType(filename: string): string {
    const ext = filename.toLowerCase().split('.').pop() || '';
    return BINARY_MIME_TYPES[ext] || 'application/octet-stream';
  }

  /**
   * Reads, validates, sanitizes, and inspects a ZIP file without mutating the workspace.
   */
  public static async inspectZip(
    data: Blob | ArrayBuffer | Uint8Array | string
  ): Promise<ZipValidationResult> {
    try {
      const zip = new JSZip();
      let loadedZip: JSZip;

      try {
        loadedZip = await zip.loadAsync(data);
      } catch (err: any) {
        return {
          valid: false,
          error: `Invalid or corrupted ZIP archive: ${err.message || 'Unable to decompress'}`,
          totalEntries: 0,
          extractedFiles: {},
          rejectedPaths: [],
          conflicts: [],
          metadata: ProjectDetector.analyzeProjectMetadata({}),
          suggestedStrategy: 'replace'
        };
      }

      const fileEntries: Array<{ originalPath: string; cleanPath: string; zipEntry: JSZip.JSZipObject }> = [];
      const rejectedPaths: Array<{ path: string; reason: string }> = [];

      // Pass 1: Filter and validate all paths
      loadedZip.forEach((relativePath, zipEntry) => {
        // Skip directory markers
        if (zipEntry.dir || relativePath.endsWith('/')) {
          return;
        }

        // Skip macOS/OS metadata files
        if (
          relativePath.includes('__MACOSX/') ||
          relativePath.endsWith('.DS_Store') ||
          relativePath.endsWith('Thumbs.db')
        ) {
          return;
        }

        const pathCheck = this.validateEntryPath(relativePath);
        if (!pathCheck.valid) {
          rejectedPaths.push({ path: relativePath, reason: pathCheck.reason || 'Invalid path' });
          return;
        }

        fileEntries.push({
          originalPath: relativePath,
          cleanPath: pathCheck.normalized,
          zipEntry
        });
      });

      if (fileEntries.length === 0) {
        return {
          valid: false,
          error: rejectedPaths.length > 0
            ? `ZIP rejected: all entries contained prohibited paths (e.g. ${rejectedPaths[0].reason})`
            : 'ZIP archive is empty (contains no files)',
          totalEntries: 0,
          extractedFiles: {},
          rejectedPaths,
          conflicts: [],
          metadata: ProjectDetector.analyzeProjectMetadata({}),
          suggestedStrategy: 'replace'
        };
      }

      // Pass 2: Detect common root directory prefix if all files are nested inside single folder (e.g. 'repo-main/...')
      const allPaths = fileEntries.map(e => e.cleanPath);
      let commonPrefix = '';
      const firstSlashIdx = allPaths[0].indexOf('/');
      if (firstSlashIdx > 0) {
        const candidatePrefix = allPaths[0].substring(0, firstSlashIdx + 1);
        const allSharePrefix = allPaths.every(p => p.startsWith(candidatePrefix));
        // Only strip if the candidate prefix is not a standard top-level project folder like 'src/' or 'public/'
        const folderName = candidatePrefix.replace(/\/$/, '');
        if (allSharePrefix && folderName !== 'src' && folderName !== 'public' && folderName !== 'app' && folderName !== 'components') {
          commonPrefix = candidatePrefix;
        }
      }

      // Pass 3: Extract file contents safely
      const extractedFiles: Record<string, string> = {};
      for (const entry of fileEntries) {
        let finalPath = entry.cleanPath;
        if (commonPrefix && finalPath.startsWith(commonPrefix)) {
          finalPath = finalPath.substring(commonPrefix.length);
        }
        if (!finalPath) continue;

        if (this.isTextFile(finalPath)) {
          const content = await entry.zipEntry.async('string');
          extractedFiles[finalPath] = content;
        } else {
          const base64 = await entry.zipEntry.async('base64');
          const mime = this.getMimeType(finalPath);
          extractedFiles[finalPath] = `data:${mime};base64,${base64}`;
        }
      }

      // Pass 4: Project characteristic detection
      const metadata = ProjectDetector.analyzeProjectMetadata(extractedFiles);

      // Pass 5: Conflict detection with current workspace
      const currentWorkspaceFiles = WorkspaceService.getAllFilesSync();
      const currentKeys = new Set(Object.keys(currentWorkspaceFiles));
      const conflicts: Array<{ path: string; existsInWorkspace: boolean }> = [];

      for (const path of Object.keys(extractedFiles)) {
        if (currentKeys.has(path)) {
          conflicts.push({ path, existsInWorkspace: true });
        }
      }

      const hasExistingFiles = currentKeys.size > 0;
      const suggestedStrategy: ConflictStrategy = hasExistingFiles && conflicts.length > 0
        ? 'replace'
        : 'replace';

      return {
        valid: true,
        totalEntries: Object.keys(extractedFiles).length,
        extractedFiles,
        rejectedPaths,
        conflicts,
        metadata,
        suggestedStrategy,
        commonPrefix: commonPrefix || undefined
      };
    } catch (err: any) {
      return {
        valid: false,
        error: `Failed to inspect ZIP archive: ${err.message || 'Unknown extraction error'}`,
        totalEntries: 0,
        extractedFiles: {},
        rejectedPaths: [],
        conflicts: [],
        metadata: ProjectDetector.analyzeProjectMetadata({}),
        suggestedStrategy: 'replace'
      };
    }
  }

  /**
   * Safely imports extracted files into the GODEX Workspace under the specified conflict strategy.
   */
  public static async importToWorkspace(
    extractedFiles: Record<string, string>,
    strategy: ConflictStrategy = 'replace',
    subfolderName?: string
  ): Promise<ZipImportResult> {
    const currentWorkspaceFiles = WorkspaceService.getAllFilesSync();
    let targetFiles: Record<string, string> = {};

    switch (strategy) {
      case 'replace': {
        targetFiles = { ...extractedFiles };
        break;
      }
      case 'merge_overwrite': {
        targetFiles = {
          ...currentWorkspaceFiles,
          ...extractedFiles
        };
        break;
      }
      case 'merge_keep': {
        targetFiles = {
          ...extractedFiles,
          ...currentWorkspaceFiles // Current workspace files take precedence
        };
        break;
      }
      case 'subfolder': {
        const folder = (subfolderName || 'imported-project').replace(/^\/+|\/+$/g, '').trim();
        const prefixedFiles: Record<string, string> = {};
        for (const [p, content] of Object.entries(extractedFiles)) {
          prefixedFiles[`${folder}/${p}`] = content;
        }
        targetFiles = {
          ...currentWorkspaceFiles,
          ...prefixedFiles
        };
        break;
      }
    }

    // Authoritatively write to WorkspaceService
    await WorkspaceService.setAllFiles(targetFiles);

    const metadata = ProjectDetector.analyzeProjectMetadata(targetFiles);

    return {
      success: true,
      importedFilesCount: Object.keys(extractedFiles).length,
      strategy,
      files: targetFiles,
      metadata,
      timestamp: Date.now()
    };
  }
}
