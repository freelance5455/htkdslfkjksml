import { PaintingReport, MaintenanceReport, ProcedureReport } from '../types/domain';
import {
  INITIAL_PAINTING_REPORTS,
  INITIAL_MAINTENANCE_REPORTS,
  INITIAL_PROCEDURE_REPORTS
} from '../data/industryData';

const DB_NAME = 'SfillerCoatingDB';
const DB_VERSION = 3;
const PAINTING_STORE = 'painting_reports';
const MAINTENANCE_STORE = 'maintenance_reports';
const PROCEDURE_STORE = 'procedure_reports';

const PAINTING_STORAGE_KEY = 'operareport_painting_v2';
const MAINTENANCE_STORAGE_KEY = 'operareport_maintenance_v2';
const PROCEDURE_STORAGE_KEY = 'operareport_procedure_v1';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const req = window.indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(PAINTING_STORE)) {
        db.createObjectStore(PAINTING_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(MAINTENANCE_STORE)) {
        db.createObjectStore(MAINTENANCE_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(PROCEDURE_STORE)) {
        db.createObjectStore(PROCEDURE_STORE, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// ----------------- PAINTING REPORTS -----------------
export async function loadPaintingReports(): Promise<PaintingReport[]> {
  try {
    const db = await openDB();
    const list = await new Promise<PaintingReport[]>((resolve, reject) => {
      const tx = db.transaction(PAINTING_STORE, 'readonly');
      const store = tx.objectStore(PAINTING_STORE);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    if (list && list.length > 0) return list;
  } catch (e) {
    console.warn('IDB fallback to localStorage:', e);
  }

  try {
    const raw = localStorage.getItem(PAINTING_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    // Ignore
  }

  // Seed default
  await savePaintingReports(INITIAL_PAINTING_REPORTS);
  return INITIAL_PAINTING_REPORTS;
}

export async function savePaintingReports(reports: PaintingReport[]): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(PAINTING_STORE, 'readwrite');
      const store = tx.objectStore(PAINTING_STORE);
      store.clear();
      reports.forEach((item) => store.put(item));
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.error('Errore salvataggio IDB painting:', e);
  }

  try {
    localStorage.setItem(PAINTING_STORAGE_KEY, JSON.stringify(reports));
  } catch (e) {
    // quota exceeded with photos, IDB has the full data
  }
}

// ----------------- MAINTENANCE REPORTS -----------------
export async function loadMaintenanceReports(): Promise<MaintenanceReport[]> {
  try {
    const db = await openDB();
    const list = await new Promise<MaintenanceReport[]>((resolve, reject) => {
      const tx = db.transaction(MAINTENANCE_STORE, 'readonly');
      const store = tx.objectStore(MAINTENANCE_STORE);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    if (list && list.length > 0) return list;
  } catch (e) {
    console.warn('IDB fallback to localStorage:', e);
  }

  try {
    const raw = localStorage.getItem(MAINTENANCE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    // Ignore
  }

  // Seed default
  await saveMaintenanceReports(INITIAL_MAINTENANCE_REPORTS);
  return INITIAL_MAINTENANCE_REPORTS;
}

export async function saveMaintenanceReports(reports: MaintenanceReport[]): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(MAINTENANCE_STORE, 'readwrite');
      const store = tx.objectStore(MAINTENANCE_STORE);
      store.clear();
      reports.forEach((item) => store.put(item));
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.error('Errore salvataggio IDB maintenance:', e);
  }

  try {
    localStorage.setItem(MAINTENANCE_STORAGE_KEY, JSON.stringify(reports));
  } catch (e) {
    // quota exceeded with photos, IDB has the full data
  }
}

// ----------------- EXPORT TO CSV -----------------
export function exportMaintenanceCsv(reports: MaintenanceReport[]): void {
  const headers = [
    'Protocollo',
    'Data',
    'Ora',
    'Nome Impianto',
    'Attrezzatura Revisionata',
    'Tipo Intervento',
    'Esito Intervento',
    'Tempo Impiegato',
    'Operatore',
    'Supervisore',
    'Descrizione',
    'Elenco Ricambi Utilizzati',
    'N. Foto Allegate'
  ];

  const rows = reports.map((r) => {
    const sparePartsStr = (r.spareParts || [])
      .map((sp) => `${sp.code} (${sp.description}) x ${sp.quantity} ${sp.unit}`)
      .join(' | ');

    return [
      r.protocolNumber,
      r.date,
      r.time || '',
      r.plantName.replace(/"/g, '""'),
      (r.equipmentServiced || '').replace(/"/g, '""'),
      r.interventionType,
      r.outcome,
      `${r.timeSpentHours}h ${r.timeSpentMinutes}m`,
      r.operatorName,
      r.supervisorName || '',
      r.description.replace(/"/g, '""').replace(/\n/g, ' '),
      sparePartsStr.replace(/"/g, '""'),
      r.images.length
    ];
  });

  const bom = '\uFEFF';
  const csvContent =
    bom +
    [
      headers.map((h) => `"${h}"`).join(';'),
      ...rows.map((row) => row.map((cell) => `"${cell}"`).join(';'))
    ].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `registro_manutenzioni_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportPaintingCsv(reports: PaintingReport[]): void {
  const headers = [
    'Rapporto N.',
    'Data',
    'Cliente',
    'Commessa / Matricola',
    'Denominazione Item',
    'Specifica Verniciatura',
    'Ciclo',
    'Prep. Superficiale',
    'Abrasivo',
    'Pulizia',
    'Rugosità',
    'N. Strati Applicati',
    'Collaudo Sfiller',
    'Controllo Qualità',
    'N. Foto'
  ];

  const rows = reports.map((p) => [
    p.reportNumber,
    p.date,
    p.client.replace(/"/g, '""'),
    p.jobSerialNumber.replace(/"/g, '""'),
    p.itemName.replace(/"/g, '""'),
    p.paintingSpecification.replace(/"/g, '""'),
    p.paintSystem.replace(/"/g, '""'),
    p.surfacePreparationStd,
    p.abrasiveTypeMesh,
    p.blastCleaningGrade,
    p.incisionProfile,
    p.layers.length,
    p.signoffs.companyInspection.signed ? 'Firmato' : 'In attesa',
    p.signoffs.qualityControl.signed ? 'Firmato' : 'In attesa',
    p.images.length
  ]);

  const bom = '\uFEFF';
  const csvContent =
    bom +
    [
      headers.map((h) => `"${h}"`).join(';'),
      ...rows.map((row) => row.map((cell) => `"${cell}"`).join(';'))
    ].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `painting_reports_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ----------------- PROCEDURE & REPORT AND RUN REPORTS -----------------
export async function loadProcedureReports(): Promise<ProcedureReport[]> {
  try {
    const db = await openDB();
    const list = await new Promise<ProcedureReport[]>((resolve, reject) => {
      const tx = db.transaction(PROCEDURE_STORE, 'readonly');
      const store = tx.objectStore(PROCEDURE_STORE);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    if (list && list.length > 0) return list;
  } catch (e) {
    console.warn('IDB fallback for procedures:', e);
  }

  try {
    const raw = localStorage.getItem(PROCEDURE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    // Ignore
  }

  // Seed default
  await saveProcedureReports(INITIAL_PROCEDURE_REPORTS);
  return INITIAL_PROCEDURE_REPORTS;
}

export async function saveProcedureReports(reports: ProcedureReport[]): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(PROCEDURE_STORE, 'readwrite');
      const store = tx.objectStore(PROCEDURE_STORE);
      store.clear();
      reports.forEach((item) => store.put(item));
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.error('Errore salvataggio IDB procedure:', e);
  }

  try {
    localStorage.setItem(PROCEDURE_STORAGE_KEY, JSON.stringify(reports));
  } catch (e) {
    // quota exceeded with photos, IDB stores it safely
  }
}

export function exportProceduresCsv(reports: ProcedureReport[]): void {
  const headers = [
    'Codice Procedura',
    'Titolo Specifica / Istruzione',
    'Categoria',
    'Impianto / Linea',
    'Cliente',
    'Commessa',
    'Data',
    'Revisione',
    'Stato',
    'Redatto Da',
    'Approvato Da',
    'Formato Video Preferito',
    'Numero Step Operativi',
    'Numero Foto Allegate'
  ];

  const rows = reports.map((p) => {
    let totalPhotos = 0;
    if (p.blocks && p.blocks.length > 0) {
      totalPhotos = p.blocks.filter((b) => b.type === 'photo').length;
    } else if (p.steps) {
      totalPhotos = p.steps.reduce((acc, s) => acc + (s.images ? s.images.length : 0), 0);
    }
    const blocksOrStepsCount = (p.blocks ? p.blocks.length : p.steps ? p.steps.length : 0);

    return [
      p.code,
      p.title.replace(/"/g, '""'),
      p.category,
      p.plantLine || '',
      (p.client || '').replace(/"/g, '""'),
      (p.jobOrder || '').replace(/"/g, '""'),
      p.date,
      p.revision,
      p.status,
      p.author.replace(/"/g, '""'),
      (p.approver || '').replace(/"/g, '""'),
      p.preferredLayout || 'standard',
      blocksOrStepsCount,
      totalPhotos
    ];
  });

  const bom = '\uFEFF';
  const csvContent =
    bom +
    [
      headers.map((h) => `"${h}"`).join(';'),
      ...rows.map((row) => row.map((cell) => `"${cell}"`).join(';'))
    ].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `specifiche_procedure_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function generateProcedureExcelBlob(report: ProcedureReport): Blob {
  const sanitize = (str: any) =>
    String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

  const hasBlocks = report.blocks && report.blocks.length > 0;

  let bodyContent = '';

  if (hasBlocks) {
    const blocksHtml = (report.blocks || []).map((b, idx) => {
      if (b.type === 'title') {
        return `
          <tr>
            <th colspan="4" style="background-color: #1f2937; color: #ffffff; font-size: 11pt; text-align: left; padding: 8px 10px;">
              ${idx + 1}. ${sanitize(b.titleText || 'Titolo')}
              ${b.subtitleText ? `<br/><span style="font-size: 9pt; font-weight: normal; color: #9ca3af;">${sanitize(b.subtitleText)}</span>` : ''}
            </th>
          </tr>
        `;
      } else if (b.type === 'text') {
        return `
          <tr>
            <td class="lbl" style="vertical-align: top; width: 140px;">Testo / Didascalia:</td>
            <td colspan="3" style="font-size: 10pt; line-height: 1.5; color: #1f2937;">
              ${sanitize(b.bodyText || '').replace(/\n/g, '<br/>')}
            </td>
          </tr>
        `;
      } else if (b.type === 'photo') {
        return `
          <tr>
            <td class="lbl" style="vertical-align: top; width: 140px;">Foto / Evidenza:</td>
            <td style="font-weight: bold; color: #0369a1;">[Immagine Fotografica Allegata]</td>
            <td class="lbl" style="width: 120px;">Didascalia:</td>
            <td style="font-size: 9.5pt; color: #374151;">
              ${sanitize(b.photoCaption || 'Nessuna didascalia')}
              ${b.photoTag ? ` <span style="color: #6b7280; font-style: italic;">(${sanitize(b.photoTag)})</span>` : ''}
            </td>
          </tr>
        `;
      } else if (b.type === 'signature') {
        return `
          <tr style="background-color: #f8fafc;">
            <td class="lbl" style="vertical-align: top; width: 140px;">Firma con il Dito:</td>
            <td colspan="3" style="font-size: 10pt; color: #0f172a;">
              <strong>[Firma Digitale Acquisita]</strong> · Firmatario: <strong>${sanitize(b.signerName || 'Operatore')}</strong> 
              (${sanitize(b.signerRole || 'Compilatore')}) · Data: <u>${sanitize(b.signedAt || report.date)}</u>
            </td>
          </tr>
        `;
      }
      return '';
    }).join('');

    bodyContent = `
      <table>
        <thead>
          <tr style="background-color: #374151; color: #ffffff;">
            <th colspan="4" style="text-align: left; padding: 6px 10px;">Composizione Scheda / Report (Blocchi Personalizzati nell'ordine prescelto)</th>
          </tr>
        </thead>
        <tbody>
          ${blocksHtml}
        </tbody>
      </table>
    `;
  } else {
    const totalPhotos = (report.steps || []).reduce((acc, s) => acc + (s.images ? s.images.length : 0), 0);
    const stepsRows = (report.steps || [])
      .map((s) => {
        const photosInfo = (s.images || [])
          .map((img) => `[Foto ${img.photoNumber}] ${img.caption} (${img.tag || 'Foto'})`)
          .join('<br/>');

        return `
          <tr>
            <td style="font-weight: bold; text-align: center; vertical-align: top; background-color: #f3f4f6; font-size: 11pt;">
              ${s.stepNumber}
            </td>
            <td style="vertical-align: top; font-weight: bold; font-size: 10pt;">
              ${sanitize(s.title)}
              <br/>
              <span style="font-weight: normal; color: #374151; font-size: 9.5pt; display: block; margin-top: 4px;">
                ${sanitize(s.description).replace(/\n/g, '<br/>')}
              </span>
            </td>
            <td style="vertical-align: top; font-size: 9pt; color: #1f2937; background-color: #fbfbfb;">
              ${sanitize(s.checkpoints || 'Secondo specifica')}
            </td>
            <td style="vertical-align: top; text-align: center; font-weight: bold; font-size: 9.5pt; color: ${
              s.compliance === 'conforme'
                ? '#15803d'
                : s.compliance === 'non_conforme'
                ? '#b91c1c'
                : '#b45309'
            };">
              ${
                s.compliance === 'conforme'
                  ? 'CONFORME'
                  : s.compliance === 'non_conforme'
                  ? 'NON CONFORME'
                  : 'IN CORSO'
              }
            </td>
            <td style="vertical-align: top; font-size: 8.5pt; color: #4b5563;">
              ${photosInfo || 'Nessuna foto allegata'}
            </td>
          </tr>
        `;
      })
      .join('');

    bodyContent = `
      <table>
        <thead>
          <tr style="background-color: #374151; color: #ffffff;">
            <th style="width: 50px;">Passo</th>
            <th style="width: 320px;">Fase &amp; Istruzioni Operative</th>
            <th style="width: 220px;">Parametri Tecnici &amp; Criteri</th>
            <th style="width: 110px;">Esito / Conformità</th>
            <th>Evidenze Fotografiche &amp; Didascalie Numeriche</th>
          </tr>
        </thead>
        <tbody>
          ${stepsRows}
        </tbody>
      </table>
    `;
  }

  const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <style>
        body { font-family: Arial, sans-serif; font-size: 10pt; color: #000; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 16px; }
        th, td { border: 1px solid #000000; padding: 6px 8px; }
        .hdr-main { background-color: #111827; color: #ffffff; font-size: 13pt; font-weight: bold; }
        .hdr-sub { background-color: #e5e7eb; font-size: 10pt; font-weight: bold; text-transform: uppercase; }
        .lbl { background-color: #f9fafb; font-weight: bold; width: 160px; }
      </style>
    </head>
    <body>
      <table>
        <tr>
          <td colspan="3" class="hdr-main">
            SFILLER - SCHEDA TECNICA &amp; PROCEDURA LIBERA
            <br/><span style="font-size: 9pt; font-weight: normal; color: #d1d5db;">Rapporto Operativo Personalizzato</span>
          </td>
          <td style="background-color: #f3f4f6; text-align: right; font-weight: bold; font-size: 11pt;">
            Codice: <u>${sanitize(report.code)}</u> (${sanitize(report.revision || 'Rev. 00')})
            <br/><span style="font-size: 9.5pt; font-weight: normal;">Data: ${sanitize(report.date)}</span>
          </td>
        </tr>
      </table>

      <table>
        <tr><th colspan="4" class="hdr-sub">Dati Intestazione Documento</th></tr>
        <tr>
          <td class="lbl">Titolo Scheda / Procedura:</td>
          <td colspan="3" style="font-size: 11pt; font-weight: bold;">${sanitize(report.title)}</td>
        </tr>
        <tr>
          <td class="lbl">Tipologia / Categoria:</td>
          <td>${sanitize(report.category || 'Procedura Operativa')}</td>
          <td class="lbl" style="width: 140px;">Impianto / Linea:</td>
          <td><strong>${sanitize(report.plantLine || 'Generale')}</strong></td>
        </tr>
        <tr>
          <td class="lbl">Cliente / Commessa:</td>
          <td>${sanitize(report.client || report.jobOrder || 'N.D.')}</td>
          <td class="lbl">Redatto Da:</td>
          <td>${sanitize(report.author || 'Operatore')}</td>
        </tr>
      </table>

      ${bodyContent}

      <table>
        <tr>
          <td style="font-size: 8.5pt; color: #6b7280; text-align: center;">
            Documento generato dall'Applicazione Sfiller · Data esportazione: ${new Date().toLocaleDateString('it-IT')}
          </td>
        </tr>
      </table>
    </body>
    </html>
  `;

  const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8' });
  return blob;
}

export function exportProcedureToExcel(report: ProcedureReport): void {
  const blob = generateProcedureExcelBlob(report);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  const safeName = `Specifica_${report.code.replace(/[^a-zA-Z0-9_-]/g, '_')}_${report.revision.replace(/\s+/g, '')}.xls`;
  link.setAttribute('download', safeName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function generateMaintenanceExcelBlob(report: MaintenanceReport): Blob {
  const sanitize = (str: any) =>
    String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

  const partsRows = (report.spareParts || [])
    .map(
      (sp) => `
      <tr>
        <td style="font-family: monospace;">${sanitize(sp.code)}</td>
        <td>${sanitize(sp.description)}</td>
        <td style="text-align: center;">${sp.quantity} ${sanitize(sp.unit)}</td>
        <td>${sanitize(sp.notes || '')}</td>
      </tr>
    `
    )
    .join('');

  const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <style>
        body { font-family: Arial, sans-serif; font-size: 10pt; color: #000; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 14px; }
        th, td { border: 1px solid #000; padding: 6px 8px; }
        .hdr { background-color: #111827; color: #ffffff; font-size: 13pt; font-weight: bold; }
        .sec { background-color: #e5e7eb; font-weight: bold; }
        .lbl { background-color: #f9fafb; font-weight: bold; width: 180px; }
      </style>
    </head>
    <body>
      <table>
        <tr>
          <td colspan="2" class="hdr">
            SFILLER SABBIATURA &amp; VERNICIATURA - VERBALE DI MANUTENZIONE
          </td>
          <td colspan="2" style="text-align: right; background-color: #f3f4f6; font-weight: bold;">
            N. Protocollo: <u>${sanitize(report.protocolNumber)}</u>
            <br/>Data: ${sanitize(report.date)} ${sanitize(report.time || '')}
          </td>
        </tr>
      </table>

      <table>
        <tr><th colspan="4" class="sec">Dati Impianto &amp; Intervento</th></tr>
        <tr>
          <td class="lbl">Impianto / Linea:</td>
          <td><strong>${sanitize(report.plantName)}</strong></td>
          <td class="lbl">Attrezzatura Revisionata:</td>
          <td><strong>${sanitize(report.equipmentServiced || 'N.D.')}</strong></td>
        </tr>
        <tr>
          <td class="lbl">Tipo Intervento:</td>
          <td>${sanitize(report.interventionType)}</td>
          <td class="lbl">Esito:</td>
          <td style="font-weight: bold; color: ${report.outcome === 'positivo' ? '#15803d' : '#b91c1c'};">
            ${report.outcome.toUpperCase()}
          </td>
        </tr>
        <tr>
          <td class="lbl">Tempo Impiegato:</td>
          <td>${report.timeSpentHours}h ${report.timeSpentMinutes}m</td>
          <td class="lbl">Operatore:</td>
          <td>${sanitize(report.operatorName)} ${report.supervisorName ? `(Sup: ${sanitize(report.supervisorName)})` : ''}</td>
        </tr>
        <tr>
          <td class="lbl">Descrizione Lavori:</td>
          <td colspan="3">${sanitize(report.description)}</td>
        </tr>
      </table>

      <table>
        <thead>
          <tr style="background-color: #374151; color: #ffffff;">
            <th>Codice Ricambio</th>
            <th>Descrizione Ricambio</th>
            <th>Q.tà</th>
            <th>Note</th>
          </tr>
        </thead>
        <tbody>
          ${partsRows || '<tr><td colspan="4" style="text-align: center; color: #6b7280;">Nessun ricambio sostituito</td></tr>'}
        </tbody>
      </table>
    </body>
    </html>
  `;

  return new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8' });
}

