/**
 * High-Precision Mathematical Evaluation Engine for VIP Calculator.
 * Supports standard arithmetic, scientific functions, DEG/RAD modes,
 * memory operations, and formatted auto-scaling output.
 */

export type AngleMode = 'DEG' | 'RAD';

export interface EvalResult {
  success: boolean;
  result: number | null;
  display: string;
  error?: string;
}

export class MathEngine {
  private angleMode: AngleMode = 'DEG';
  private memoryValue: number = 0;
  private lastAnswer: number = 0;

  public setAngleMode(mode: AngleMode) {
    this.angleMode = mode;
  }

  public getAngleMode(): AngleMode {
    return this.angleMode;
  }

  public getMemory(): number {
    return this.memoryValue;
  }

  public hasMemory(): boolean {
    return this.memoryValue !== 0;
  }

  public memoryAdd(val: number) {
    this.memoryValue += val;
  }

  public memorySubtract(val: number) {
    this.memoryValue -= val;
  }

  public memoryClear() {
    this.memoryValue = 0;
  }

  public setLastAnswer(val: number) {
    this.lastAnswer = val;
  }

  public getLastAnswer(): number {
    return this.lastAnswer;
  }

  // Factorial calculation
  public factorial(n: number): number {
    if (n < 0 || !Number.isInteger(n)) return NaN;
    if (n > 170) return Infinity; // JS Number overflow limit
    if (n === 0 || n === 1) return 1;
    let res = 1;
    for (let i = 2; i <= n; i++) {
      res *= i;
    }
    return res;
  }

  /**
   * Safe mathematical expression tokenizer and parser.
   * Replaces human symbols with JS Math equivalents.
   */
  public evaluate(rawExpr: string): EvalResult {
    if (!rawExpr || rawExpr.trim() === '') {
      return { success: true, result: 0, display: '0' };
    }

    try {
      let expr = rawExpr
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/−/g, '-')
        .replace(/π/g, `${Math.PI}`)
        .replace(/Ans/g, `${this.lastAnswer}`)
        .replace(/\bdeg\b/g, '')
        .replace(/\brad\b/g, '');

      // Handle factorial like 5! -> MathEngine.factorial(5)
      expr = expr.replace(/(\d+(\.\d+)?)!/g, 'fact($1)');

      // Handle percentages: a + b% -> a + (a * b / 100), or simple x% -> (x / 100)
      expr = expr.replace(/(\d+(\.\d+)?)%/g, '($1/100)');

      // Convert power operator ^ to **
      expr = expr.replace(/\^/g, '**');

      // Create a sandbox execution environment with custom mathematical helper scope
      const isDeg = this.angleMode === 'DEG';
      const toRad = (angle: number) => (isDeg ? (angle * Math.PI) / 180 : angle);
      const fromRad = (rad: number) => (isDeg ? (rad * 180) / Math.PI : rad);

      const mathScope = {
        sin: (x: number) => {
          // Normalize precision around 180/360 degrees
          if (isDeg && (Math.abs(x % 180) < 1e-12)) return 0;
          const val = Math.sin(toRad(x));
          return Math.abs(val) < 1e-14 ? 0 : val;
        },
        cos: (x: number) => {
          if (isDeg && (Math.abs((x - 90) % 180) < 1e-12 || Math.abs((x + 90) % 180) < 1e-12)) return 0;
          const val = Math.cos(toRad(x));
          return Math.abs(val) < 1e-14 ? 0 : val;
        },
        tan: (x: number) => {
          if (isDeg && Math.abs((x - 90) % 180) < 1e-12) return NaN;
          const val = Math.tan(toRad(x));
          return Math.abs(val) < 1e-14 ? 0 : val;
        },
        asin: (x: number) => fromRad(Math.asin(x)),
        acos: (x: number) => fromRad(Math.acos(x)),
        atan: (x: number) => fromRad(Math.atan(x)),
        ln: (x: number) => Math.log(x),
        log: (x: number) => Math.log10(x),
        log10: (x: number) => Math.log10(x),
        log2: (x: number) => Math.log2(x),
        sqrt: (x: number) => Math.sqrt(x),
        cbrt: (x: number) => Math.cbrt(x),
        abs: (x: number) => Math.abs(x),
        exp: (x: number) => Math.exp(x),
        fact: (x: number) => this.factorial(x),
        e: Math.E,
        PI: Math.PI,
      };

      // Sanitize expression: allow only numbers, math operators, valid function names, parentheses
      const allowedChars = /^[0-9+\-*/().eE*,\s\w]+$/;
      if (!allowedChars.test(expr)) {
        return { success: false, result: null, display: 'Error', error: 'Invalid characters in expression' };
      }

      // Execute safely with injected Math scope
      const scopeKeys = Object.keys(mathScope);
      const scopeVals = Object.values(mathScope);
      const func = new Function(...scopeKeys, `"use strict"; return (${expr});`);
      const val = func(...scopeVals);

      if (typeof val !== 'number' || isNaN(val)) {
        return { success: false, result: null, display: 'NaN', error: 'Invalid calculation' };
      }

      if (!isFinite(val)) {
        return { success: false, result: val, display: val > 0 ? 'Infinity' : '-Infinity' };
      }

      // Format nicely to prevent JS floating point precision issues (0.1 + 0.2 = 0.3)
      const formatted = this.formatNumber(val);
      this.lastAnswer = val;

      return {
        success: true,
        result: val,
        display: formatted,
      };
    } catch (err: any) {
      return {
        success: false,
        result: null,
        display: 'Error',
        error: err.message || 'Syntax Error',
      };
    }
  }

  public formatNumber(val: number): string {
    if (isNaN(val)) return 'NaN';
    if (!isFinite(val)) return val > 0 ? 'Infinity' : '-Infinity';

    // Check if integer
    if (Number.isInteger(val) && Math.abs(val) < 1e14) {
      return val.toLocaleString('en-US');
    }

    // High precision round to 10 decimals to eliminate 0.30000000000000004
    const rounded = Number(Math.round(Number(val + 'e11')) + 'e-11');
    
    // Very large or very small -> scientific notation
    if (Math.abs(val) >= 1e13 || (Math.abs(val) > 0 && Math.abs(val) < 1e-6)) {
      return val.toExponential(6).replace(/\.?0+e/, 'e');
    }

    // Format with commas on whole part, preserving decimal digits up to 8 places
    const parts = rounded.toString().split('.');
    const whole = parseInt(parts[0], 10).toLocaleString('en-US');
    if (parts.length > 1) {
      return `${whole}.${parts[1].slice(0, 8)}`;
    }
    return whole;
  }
}

export const mathEngine = new MathEngine();
