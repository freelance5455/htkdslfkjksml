import { VoiceAlertPreset, SoundEffectType } from '../types/market';

export const SOUND_EFFECT_PRESETS: Array<{
  id: SoundEffectType;
  name: string;
  category: 'chime' | 'siren' | 'retro' | 'synth';
  description: string;
  iconName: string;
}> = [
  {
    id: 'sonar',
    name: 'Sonar Radar Ping',
    category: 'synth',
    description: 'High-tech resonant radar sweep for technical breakouts',
    iconName: 'Radar',
  },
  {
    id: 'bell',
    name: 'Wall Street Trading Bell',
    category: 'chime',
    description: 'Crisp brass acoustic bell reminiscent of NYSE opening',
    iconName: 'Bell',
  },
  {
    id: 'bullish',
    name: 'Ascending Bullish Triad',
    category: 'chime',
    description: 'Uplifting C-major harmonic chord for target hits and pumps',
    iconName: 'TrendingUp',
  },
  {
    id: 'bearish',
    name: 'Warning Siren Down',
    category: 'siren',
    description: 'Rapid low-frequency sweep warning of drops and support loss',
    iconName: 'TrendingDown',
  },
  {
    id: 'alarm',
    name: 'High Urgency Klaxon',
    category: 'siren',
    description: 'Triple pulse warning klaxon for flash liquidation risks',
    iconName: 'AlertTriangle',
  },
  {
    id: 'kaching',
    name: 'Cash Register "Ka-ching"',
    category: 'retro',
    description: 'Classic double coin ring for realized profits and milestones',
    iconName: 'Coins',
  },
  {
    id: 'laser',
    name: 'Cyber Laser Ping',
    category: 'synth',
    description: 'Sharp focused laser pulse for micro-second volatility',
    iconName: 'Zap',
  },
  {
    id: 'pulsar',
    name: 'Deep Sub-Bass Thump',
    category: 'synth',
    description: 'Heavy atmospheric low-frequency pulse for whale movements',
    iconName: 'Activity',
  },
];

export const VOICE_ALERT_LIBRARY: VoiceAlertPreset[] = [
  // --- FRENCH PRESETS (Bourse & Crypto en Français) ---
  {
    id: 'fr-breakout-1',
    title: 'Cassure Haussière Majeure',
    category: 'breakout',
    language: 'fr',
    script: 'Alerte franchissement ! {asset} vient de briser la résistance clé avec un fort volume acheteur.',
    defaultChime: 'bullish',
    description: 'Annonce puissante dès le dépassement d’une résistance technique.',
    tag: 'Haussier',
  },
  {
    id: 'fr-take-profit-1',
    title: 'Objectif de Profit Atteint',
    category: 'profit',
    language: 'fr',
    script: 'Cible de cours atteinte sur {asset}. Pensez à sécuriser vos gains ou remonter votre stop.',
    defaultChime: 'kaching',
    description: 'Rappel vocal idéal pour sécuriser un trade gagnant.',
    tag: 'Take-Profit',
  },
  {
    id: 'fr-flash-dump-1',
    title: 'Alerte Stop-Loss / Chute Brutale',
    category: 'dump',
    language: 'fr',
    script: 'Attention danger immédiat ! Chute brutale détectée sur {asset}, seuil de stop atteint.',
    defaultChime: 'bearish',
    description: 'Alerte sonore urgente pour couper une perte rapidement.',
    tag: 'Urgence',
  },
  {
    id: 'fr-whale-1',
    title: 'Mouvement de Baleine Détecté',
    category: 'whale',
    language: 'fr',
    script: 'Alerte baleine ! Gros carnet d\'ordres exécuté sur {asset}. Pression anormale.',
    defaultChime: 'pulsar',
    description: 'Signale les ordres institutionnels et pics anormaux.',
    tag: 'Institutionnel',
  },
  {
    id: 'fr-support-test-1',
    title: 'Test du Support Critique',
    category: 'support',
    language: 'fr',
    script: '{asset} teste son support majeur. Surveillez le rebond ou la rupture imminente.',
    defaultChime: 'sonar',
    description: 'Pour anticiper les points d\'entrée sur rebond de support.',
    tag: 'Technique',
  },
  {
    id: 'fr-volatility-1',
    title: 'Pic de Volatilité Immédiat',
    category: 'volatility',
    language: 'fr',
    script: 'Forte turbulence sur {asset} ! Écart de prix violent en cours.',
    defaultChime: 'laser',
    description: 'Annonce les expansions brutales de bandes de Bollinger.',
    tag: 'Volatilité',
  },
  {
    id: 'fr-golden-cross',
    title: 'Signal Achat Confirmation',
    category: 'breakout',
    language: 'fr',
    script: 'Confirmation haussière sur {asset}. Les indicateurs passent au vert vif.',
    defaultChime: 'bell',
    description: 'Validation de croisement de moyennes mobiles ou RSI.',
    tag: 'Confirmation',
  },

  // --- ENGLISH PRESETS (Wall Street & Global Markets) ---
  {
    id: 'en-breakout-1',
    title: 'Massive Resistance Breakout',
    category: 'breakout',
    language: 'en',
    script: 'Breakout confirmed! {asset} has smashed through resistance with heavy volume momentum.',
    defaultChime: 'bullish',
    description: 'Dynamic call when an asset triggers a new local high.',
    tag: 'Breakout',
  },
  {
    id: 'en-take-profit-1',
    title: 'Target Price Reached - Lock Gains',
    category: 'profit',
    language: 'en',
    script: 'Profit target triggered on {asset}. Consider locking in gains or adjusting trailing stops.',
    defaultChime: 'kaching',
    description: 'Clear take-profit announcement for systematic discipline.',
    tag: 'Target Hit',
  },
  {
    id: 'en-flash-crash-1',
    title: 'Critical Support Breached / Dump Alert',
    category: 'dump',
    language: 'en',
    script: 'Warning! Flash liquidation alert. {asset} dropped below crucial support level.',
    defaultChime: 'alarm',
    description: 'Emergency voice notification for risk-off defense.',
    tag: 'Emergency',
  },
  {
    id: 'en-whale-1',
    title: 'Institutional Whale Order',
    category: 'whale',
    language: 'en',
    script: 'Whale alert on {asset}! Major institutional order detected in market depth.',
    defaultChime: 'pulsar',
    description: 'Identifies deep order-book shifts and high-volume blocks.',
    tag: 'Whale Alert',
  },
  {
    id: 'en-rebound-1',
    title: 'Oversold Support Reversal',
    category: 'support',
    language: 'en',
    script: '{asset} is bouncing strongly off key support. Buyers stepping in with volume.',
    defaultChime: 'bell',
    description: 'Ideal for bottom-fishing and reversal scalps.',
    tag: 'Reversal',
  },
  {
    id: 'en-volatility-1',
    title: 'High Volatility Squeeze',
    category: 'volatility',
    language: 'en',
    script: 'High volatility alert! Rapid price swings detected on {asset}. Stay alert.',
    defaultChime: 'laser',
    description: 'Alerts when ATR or spread expands rapidly.',
    tag: 'Volatility',
  },

  // --- GERMAN PRESETS (Deutsch) ---
  {
    id: 'de-breakout-1',
    title: 'Wichtiger Kursausbruch',
    category: 'breakout',
    language: 'de',
    script: 'Ausbruchsalarm! {asset} hat soeben den Schlüsselwiderstand mit hohem Volumen durchbrochen.',
    defaultChime: 'bullish',
    description: 'Prägnante Sprachansage bei technischem Durchbruch.',
    tag: 'Ausbruch',
  },
  {
    id: 'de-take-profit-1',
    title: 'Kursziel Erreicht (Gewinnmitnahme)',
    category: 'profit',
    language: 'de',
    script: 'Kursziel erreicht bei {asset}. Zeit für Gewinnsicherung oder Nachziehen des Stop-Loss.',
    defaultChime: 'kaching',
    description: 'Erinnert diszipliniert an die Gewinnmitnahme.',
    tag: 'Take-Profit',
  },
  {
    id: 'de-dump-1',
    title: 'Notfall Stop-Loss / Starker Kurssturz',
    category: 'dump',
    language: 'de',
    script: 'Achtung Warnung! Starker Kursrückgang bei {asset}. Stop-Loss-Schwelle erreicht.',
    defaultChime: 'bearish',
    description: 'Dringlicher Alarm zur Begrenzung von Verlusten.',
    tag: 'Notfall',
  },
  {
    id: 'de-whale-1',
    title: 'Großauftrag Institutioneller Wal',
    category: 'whale',
    language: 'de',
    script: 'Wal-Alarm bei {asset}! Großer institutioneller Kaufauftrag im Orderbuch erfasst.',
    defaultChime: 'pulsar',
    description: 'Erkennt massive Liquiditätsverschiebungen.',
    tag: 'Wal-Alarm',
  },

  // --- SPANISH PRESETS (Español) ---
  {
    id: 'es-breakout-1',
    title: 'Ruptura Alcista Clave',
    category: 'breakout',
    language: 'es',
    script: '¡Alerta de ruptura! {asset} acaba de superar la resistencia clave con fuerte volumen comprador.',
    defaultChime: 'bullish',
    description: 'Aviso de voz inmediato ante ruptura técnica superior.',
    tag: 'Ruptura',
  },
  {
    id: 'es-take-profit-1',
    title: 'Objetivo de Ganancias Alcanzado',
    category: 'profit',
    language: 'es',
    script: 'Objetivo de precio alcanzado en {asset}. Considere asegurar ganancias o subir su stop.',
    defaultChime: 'kaching',
    description: 'Locución para proteger beneficios de manera disciplinada.',
    tag: 'Take-Profit',
  },
  {
    id: 'es-dump-1',
    title: 'Alerta Stop-Loss / Caída Brusca',
    category: 'dump',
    language: 'es',
    script: '¡Atención peligro! Fuerte caída detectada en {asset}, nivel de stop alcanzado.',
    defaultChime: 'bearish',
    description: 'Aviso prioritario para cortar pérdidas rápidamente.',
    tag: 'Urgencia',
  },
  {
    id: 'es-whale-1',
    title: 'Movimiento de Ballena Institucional',
    category: 'whale',
    language: 'es',
    script: '¡Alerta ballena en {asset}! Orden institucional masiva detectada en el libro.',
    defaultChime: 'pulsar',
    description: 'Monitoreo de grandes bloques y liquidez profunda.',
    tag: 'Ballena',
  },

  // --- ITALIAN PRESETS (Italiano) ---
  {
    id: 'it-breakout-1',
    title: 'Rottura Rialzista Maggiore',
    category: 'breakout',
    language: 'it',
    script: 'Allerta breakout! {asset} ha appena rotto la resistenza chiave con forti volumi di acquisto.',
    defaultChime: 'bullish',
    description: 'Notifica vocale per rotture tecniche rialziste.',
    tag: 'Breakout',
  },
  {
    id: 'it-take-profit-1',
    title: 'Target di Profitto Raggiunto',
    category: 'profit',
    language: 'it',
    script: 'Target di prezzo raggiunto su {asset}. Valuta di prendere profitto o alzare lo stop.',
    defaultChime: 'kaching',
    description: 'Promemoria vocale per monetizzare i trade vincenti.',
    tag: 'Take-Profit',
  },
  {
    id: 'it-dump-1',
    title: 'Allerta Stop-Loss / Crollo Rapido',
    category: 'dump',
    language: 'it',
    script: 'Attenzione pericolo! Forte calo rilevato su {asset}, soglia di stop superata.',
    defaultChime: 'alarm',
    description: 'Allarme sonoro urgente per chiudere la posizione.',
    tag: 'Urgenza',
  },

  // --- ARABIC PRESETS (العربية) ---
  {
    id: 'ar-breakout-1',
    title: 'اختراق صعودي رئيسي للمقاومة',
    category: 'breakout',
    language: 'ar',
    script: 'تنبيه اختراق! اخترق {asset} مستوى المقاومة الرئيسي للتو مع تدفق سيولة شرائية قوية.',
    defaultChime: 'bullish',
    description: 'نطق صوتي فوري عند اختراق مستويات المقاومة الفنية.',
    tag: 'اختراق صعودي',
  },
  {
    id: 'ar-take-profit-1',
    title: 'تحقيق الهدف السعري وجني الأرباح',
    category: 'profit',
    language: 'ar',
    script: 'تم تحقيق الهدف السعري على {asset}. يُنصح بحجز الأرباح أو رفع وقف الخسارة.',
    defaultChime: 'kaching',
    description: 'تنبيه صوتي لحماية الأرباح والانضباط الاستثماري.',
    tag: 'جني الأرباح',
  },
  {
    id: 'ar-dump-1',
    title: 'تنبيه طارئ / كسر وقف الخسارة',
    category: 'dump',
    language: 'ar',
    script: 'انتباه خطر! هبوط مفاجئ على {asset}، تم كسر مستوى الدعم وتفعيل وقف الخسارة.',
    defaultChime: 'bearish',
    description: 'تنبيه صوتي عاجل للحد من الخسائر.',
    tag: 'طوارئ هبوط',
  },
  {
    id: 'ar-whale-1',
    title: 'أمر حوت مؤسسي كبير',
    category: 'whale',
    language: 'ar',
    script: 'تنبيه حوت على {asset}! رصد أمر مؤسسي ضخم في عمق دفتر الأوامر.',
    defaultChime: 'pulsar',
    description: 'كشف تحركات الصناديق وكبار المتداولين.',
    tag: 'تنبيه حوت',
  },
];

/**
 * Format dynamic alert script with actual asset values
 */
export function formatAlertScript(
  scriptTemplate: string,
  assetSymbol: string,
  targetValue?: number,
  currentPrice?: number
): string {
  let text = scriptTemplate.replace(/\{asset\}/g, assetSymbol);
  if (targetValue !== undefined) {
    text = text.replace(/\{target\}/g, targetValue.toLocaleString());
  }
  if (currentPrice !== undefined) {
    text = text.replace(/\{price\}/g, currentPrice.toLocaleString());
  }
  return text;
}
