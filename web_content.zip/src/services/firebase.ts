/**
 * HELENA - Firebase Firestore & Real-Time Sync Service
 * Connects to the provisioned Firestore database for PC <-> Celular transfer
 * and remote backup of models/settings.
 */

import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  limit, 
  serverTimestamp 
} from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { AppSettings } from '../types';

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, (firebaseConfig as any).firestoreDatabaseId);
export const auth = getAuth(app);

export interface PairedDevice {
  id: string;
  name: string;
  lastSeen: any;
  isOnline: boolean;
  userAgent?: string;
}

export interface RealtimeTransfer {
  id: string;
  name: string;
  type: 'model3d' | 'image' | 'file';
  sizeBytes: number;
  senderDevice: string;
  targetDevice?: string;
  createdAt: any;
  status: 'pending' | 'completed' | 'cancelled';
  payloadData?: string; // base64 or JSON
  modelProperties?: any;
}

// Generate a stable device ID per browser/session
export function getLocalDeviceId(): string {
  let id = localStorage.getItem('helena_device_id');
  if (!id) {
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    const prefix = isMobile ? 'Celular' : 'PC';
    id = `${prefix}_${Math.random().toString(36).substring(2, 7)}`;
    localStorage.setItem('helena_device_id', id);
  }
  return id;
}

export function getLocalDeviceName(): string {
  let name = localStorage.getItem('helena_device_name');
  if (!name) {
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    name = isMobile ? 'Celular' : 'Computador';
    localStorage.setItem('helena_device_name', name);
  }
  return name;
}

export function setLocalDeviceName(name: string): void {
  localStorage.setItem('helena_device_name', name);
}

/**
 * Registers device heartbeat in Firestore
 */
export async function registerDeviceHeartbeat(name: string): Promise<string> {
  const deviceId = getLocalDeviceId();
  try {
    const deviceRef = doc(db, 'devices', deviceId);
    await setDoc(deviceRef, {
      id: deviceId,
      name,
      lastSeen: new Date().toISOString(),
      isOnline: true,
      userAgent: navigator.userAgent.slice(0, 100),
    }, { merge: true });
    return deviceId;
  } catch (err) {
    console.warn('Failed to register device heartbeat:', err);
    return deviceId;
  }
}

/**
 * Listens for online devices in real time
 */
export function listenOnlineDevices(
  currentDeviceId: string,
  callback: (devices: PairedDevice[]) => void
): () => void {
  try {
    const devicesCol = collection(db, 'devices');
    return onSnapshot(devicesCol, (snapshot) => {
      const list: PairedDevice[] = [];
      const now = Date.now();
      snapshot.forEach((docSnap: any) => {
        const data = docSnap.data() as PairedDevice;
        if (data.id !== currentDeviceId) {
          // Consider online if seen within last 15 minutes
          const seenTime = data.lastSeen ? new Date(data.lastSeen).getTime() : 0;
          const isRecentlyActive = (now - seenTime) < 15 * 60 * 1000;
          if (isRecentlyActive) {
            list.push(data);
          }
        }
      });
      callback(list);
    }, (err) => {
      console.warn('Error listening to devices:', err);
      callback([]);
    });
  } catch (e) {
    console.warn('Could not subscribe to devices:', e);
    return () => {};
  }
}

/**
 * Sends a real-time transfer item to Firestore
 */
export async function sendTransferItem(item: {
  name: string;
  type: 'model3d' | 'image' | 'file';
  sizeBytes: number;
  senderDevice: string;
  targetDevice?: string;
  payloadData?: string;
  modelProperties?: any;
}): Promise<string> {
  const transferId = `trans_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const transferRef = doc(db, 'transfers', transferId);

  await setDoc(transferRef, {
    id: transferId,
    name: item.name,
    type: item.type,
    sizeBytes: item.sizeBytes,
    senderDevice: item.senderDevice,
    targetDevice: item.targetDevice || 'Todos',
    createdAt: new Date().toISOString(),
    status: 'pending',
    payloadData: item.payloadData || '',
    modelProperties: item.modelProperties || null,
  });

  return transferId;
}

/**
 * Listens for incoming transfers
 */
export function listenIncomingTransfers(
  myDeviceId: string,
  callback: (transfers: RealtimeTransfer[]) => void
): () => void {
  try {
    const transfersCol = collection(db, 'transfers');
    const q = query(transfersCol, orderBy('createdAt', 'desc'), limit(15));

    return onSnapshot(q, (snapshot) => {
      const list: RealtimeTransfer[] = [];
      snapshot.forEach((docSnap: any) => {
        const item = docSnap.data() as RealtimeTransfer;
        if (item.senderDevice !== myDeviceId) {
          list.push(item);
        }
      });
      callback(list);
    }, (err) => {
      console.warn('Error listening transfers:', err);
      callback([]);
    });
  } catch (e) {
    console.warn('Could not subscribe to transfers:', e);
    return () => {};
  }
}

/**
 * Marks transfer as completed
 */
export async function completeTransfer(transferId: string): Promise<void> {
  try {
    const transferRef = doc(db, 'transfers', transferId);
    await updateDoc(transferRef, { status: 'completed' });
  } catch (err) {
    console.warn('Error completing transfer:', err);
  }
}

/**
 * Saves owner settings to Firestore
 */
export async function saveOwnerSettingsToFirestore(settings: AppSettings): Promise<void> {
  try {
    const docRef = doc(db, 'user_settings', settings.ownerEmail);
    await setDoc(docRef, {
      ownerEmail: settings.ownerEmail,
      updatedAt: new Date().toISOString(),
      geminiKey: settings.geminiKey,
      geminiModel: settings.geminiModel,
      groqKey: settings.groqKey,
      groqModel: settings.groqModel,
      groqVisionModel: settings.groqVisionModel,
      trustedAuthors: settings.trustedAuthors,
      wakeWord: settings.wakeWord,
      speechRate: settings.speechRate,
      speechMuted: settings.speechMuted,
    }, { merge: true });
  } catch (err) {
    console.warn('Failed to save settings to Firestore:', err);
  }
}

