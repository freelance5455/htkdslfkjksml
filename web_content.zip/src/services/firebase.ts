import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  type User,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  deleteDoc,
  getDocs,
  getDocFromServer,
  onSnapshot,
  query,
  where,
  serverTimestamp,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import type {
  AppDatabase,
  MedicineItem,
  PurchaseItem,
  SaleItem,
  ExpenseItem,
  DebtPayment,
  ActivityLogItem,
  ActivityActionType,
} from '../types/pharmacy.ts';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export const WORKSPACE_ID = 'meshmesh_main';
const DEVICE_UID_KEY = 'meshmesh_device_uid_v1';
let memoryDeviceUid: string | null = null;

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
      displayName?: string | null;
      photoURL?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoURL: provider.photoURL,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Validate connection on boot as required by skill
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
testConnection();

// Sanitize ID to match ^[a-zA-Z0-9_\-]+$ (1..128 chars)
export function sanitizeId(rawId: string): string {
  const cleaned = rawId.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120);
  return cleaned.length > 0 ? cleaned : `id_${Date.now()}`;
}

// Persistent Actor UID that works on iOS WebClip, Android APK, and Web without requiring Google Popup
export function getEffectiveActorUid(): string {
  if (auth.currentUser?.uid) {
    return sanitizeId(auth.currentUser.uid);
  }
  if (memoryDeviceUid) {
    return memoryDeviceUid;
  }
  try {
    const existing = localStorage.getItem(DEVICE_UID_KEY);
    if (existing) {
      memoryDeviceUid = sanitizeId(existing);
      return memoryDeviceUid;
    }
    const created = sanitizeId(
      `dev_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
    );
    localStorage.setItem(DEVICE_UID_KEY, created);
    memoryDeviceUid = created;
    return created;
  } catch {
    memoryDeviceUid = sanitizeId(
      `dev_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
    );
    return memoryDeviceUid;
  }
}

export function clampStr(val: string | undefined, max: number, fallback = ''): string {
  const str = (val ?? fallback).trim();
  if (!str && fallback) return fallback.slice(0, max);
  return str.slice(0, max);
}

// Auth helpers
export async function signInWithGoogle() {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  return signInWithPopup(auth, provider);
}

export async function signOutFromCloud() {
  return signOut(auth);
}

export { onAuthStateChanged, type User };

// Cloud Activity Logger
export async function logCloudActivity(params: {
  actionType: ActivityActionType;
  title: string;
  details: string;
  amount: number;
  actorUid?: string;
  actorName: string;
}) {
  const uid = getEffectiveActorUid();
  const logId = sanitizeId(`log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`);
  const path = `activityLogs/${logId}`;
  try {
    await setDoc(doc(db, 'activityLogs', logId), {
      id: logId,
      workspaceId: WORKSPACE_ID,
      actionType: params.actionType,
      title: clampStr(params.title, 250, 'عملية جديدة'),
      details: clampStr(params.details, 500, ''),
      amount: Math.max(0, Number(params.amount) || 0),
      actorUid: uid,
      actorName: clampStr(params.actorName, 100, 'عضو الفريق'),
      createdAtMs: Date.now(),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function saveMedicineToCloud(
  med: MedicineItem,
  actorName: string,
  isUpdate = false,
  existingCreatedAt?: unknown
) {
  const uid = getEffectiveActorUid();
  const medId = sanitizeId(med.id || `med_${med.barcode}`);
  const path = `medicines/${medId}`;
  try {
    const payload: Record<string, unknown> = {
      id: medId,
      workspaceId: WORKSPACE_ID,
      barcode: clampStr(med.barcode, 64, '0000'),
      name: clampStr(med.name, 200, 'دواء'),
      unit: clampStr(med.unit, 50, 'باكيت'),
      minStockAlert: Math.min(1000000, Math.max(0, Number(med.minStockAlert) || 0)),
      addedByUid: uid,
      addedByName: clampStr(actorName, 100, 'عضو الفريق'),
      createdAt: isUpdate && existingCreatedAt ? existingCreatedAt : serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    if (med.scientificName && med.scientificName.trim()) {
      payload.scientificName = clampStr(med.scientificName, 200);
    }
    await setDoc(doc(db, 'medicines', medId), payload);
  } catch (error) {
    handleFirestoreError(error, isUpdate ? OperationType.UPDATE : OperationType.CREATE, path);
  }
}

export async function savePurchaseToCloud(purchase: PurchaseItem, actorName: string) {
  const uid = getEffectiveActorUid();
  const pId = sanitizeId(purchase.id);
  const path = `purchases/${pId}`;
  try {
    const payload: Record<string, unknown> = {
      id: pId,
      workspaceId: WORKSPACE_ID,
      date: clampStr(purchase.date, 20, new Date().toISOString().split('T')[0]),
      supplier: clampStr(purchase.supplier, 200, 'مذخر'),
      barcode: clampStr(purchase.barcode, 64, '0000'),
      medicineName: clampStr(purchase.medicineName, 200, 'دواء'),
      qty: Math.min(1000000, Math.max(1, Number(purchase.qty) || 1)),
      unitPrice: Math.max(0, Number(purchase.unitPrice) || 0),
      totalAmount: Math.max(0, Number(purchase.totalAmount) || 0),
      expiryDate: clampStr(purchase.expiryDate, 20, '2027-01-01'),
      amountPaid: Math.max(0, Number(purchase.amountPaid) || 0),
      remainingUnpaid: Math.max(0, Number(purchase.remainingUnpaid) || 0),
      addedByUid: uid,
      addedByName: clampStr(purchase.addedByName || actorName, 100, 'عضو الفريق'),
      createdAtMs: Number(purchase.createdAt) || Date.now(),
      createdAt: serverTimestamp(),
    };
    if (purchase.notes && purchase.notes.trim()) {
      payload.notes = clampStr(purchase.notes, 500);
    }
    await setDoc(doc(db, 'purchases', pId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deletePurchaseFromCloud(id: string) {
  const pId = sanitizeId(id);
  const path = `purchases/${pId}`;
  try {
    await deleteDoc(doc(db, 'purchases', pId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function saveSaleToCloud(sale: SaleItem, actorName: string) {
  const uid = getEffectiveActorUid();
  const sId = sanitizeId(sale.id);
  const path = `sales/${sId}`;
  try {
    const payload: Record<string, unknown> = {
      id: sId,
      workspaceId: WORKSPACE_ID,
      date: clampStr(sale.date, 20, new Date().toISOString().split('T')[0]),
      buyer: clampStr(sale.buyer, 200, 'صيدلية'),
      barcode: clampStr(sale.barcode, 64, '0000'),
      medicineName: clampStr(sale.medicineName, 200, 'دواء'),
      qty: Math.min(1000000, Math.max(1, Number(sale.qty) || 1)),
      unitPrice: Math.max(0, Number(sale.unitPrice) || 0),
      totalAmount: Math.max(0, Number(sale.totalAmount) || 0),
      avgCostAtSale: Math.max(0, Number(sale.avgCostAtSale) || 0),
      amountPaid: Math.max(0, Number(sale.amountPaid) || 0),
      remainingUnpaid: Math.max(0, Number(sale.remainingUnpaid) || 0),
      addedByUid: uid,
      addedByName: clampStr(sale.addedByName || actorName, 100, 'عضو الفريق'),
      createdAtMs: Number(sale.createdAt) || Date.now(),
      createdAt: serverTimestamp(),
    };
    if (sale.nearestExpiryBatch && sale.nearestExpiryBatch.trim()) {
      payload.nearestExpiryBatch = clampStr(sale.nearestExpiryBatch, 20);
    }
    if (sale.notes && sale.notes.trim()) {
      payload.notes = clampStr(sale.notes, 500);
    }
    await setDoc(doc(db, 'sales', sId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteSaleFromCloud(id: string) {
  const sId = sanitizeId(id);
  const path = `sales/${sId}`;
  try {
    await deleteDoc(doc(db, 'sales', sId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function saveExpenseToCloud(expense: ExpenseItem, actorName: string) {
  const uid = getEffectiveActorUid();
  const eId = sanitizeId(expense.id);
  const path = `expenses/${eId}`;
  try {
    const payload = {
      id: eId,
      workspaceId: WORKSPACE_ID,
      date: clampStr(expense.date, 20, new Date().toISOString().split('T')[0]),
      type: clampStr(expense.type, 60, 'أخرى'),
      amount: Math.max(1, Number(expense.amount) || 1),
      note: clampStr(expense.note, 500, ''),
      addedByUid: uid,
      addedByName: clampStr(expense.addedByName || actorName, 100, 'عضو الفريق'),
      createdAtMs: Number(expense.createdAt) || Date.now(),
      createdAt: serverTimestamp(),
    };
    await setDoc(doc(db, 'expenses', eId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteExpenseFromCloud(id: string) {
  const eId = sanitizeId(id);
  const path = `expenses/${eId}`;
  try {
    await deleteDoc(doc(db, 'expenses', eId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function savePaymentToCloud(payment: DebtPayment, actorName: string) {
  const uid = getEffectiveActorUid();
  const payId = sanitizeId(payment.id);
  const path = `payments/${payId}`;
  try {
    const payload: Record<string, unknown> = {
      id: payId,
      workspaceId: WORKSPACE_ID,
      partyType: payment.partyType === 'supplier' ? 'supplier' : 'buyer',
      partyName: clampStr(payment.partyName, 200, 'عميل'),
      date: clampStr(payment.date, 20, new Date().toISOString().split('T')[0]),
      amount: Math.max(1, Number(payment.amount) || 1),
      type: payment.type === 'payment' ? 'payment' : 'receipt',
      addedByUid: uid,
      addedByName: clampStr(payment.addedByName || actorName, 100, 'عضو الفريق'),
      createdAtMs: Number(payment.createdAt) || Date.now(),
      createdAt: serverTimestamp(),
    };
    if (payment.note && payment.note.trim()) {
      payload.note = clampStr(payment.note, 500);
    }
    await setDoc(doc(db, 'payments', payId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// Bulk upload local database to cloud workspace
export async function seedLocalDatabaseToCloud(localDb: AppDatabase, actorName: string) {
  const uid = getEffectiveActorUid();
  const safeActor = clampStr(actorName, 100, 'عضو الفريق');
  const batch = writeBatch(db);

  for (const med of localDb.medicines) {
    const medId = sanitizeId(med.id || `med_${med.barcode}`);
    const payload: Record<string, unknown> = {
      id: medId,
      workspaceId: WORKSPACE_ID,
      barcode: clampStr(med.barcode, 64, '0000'),
      name: clampStr(med.name, 200, 'دواء'),
      unit: clampStr(med.unit, 50, 'باكيت'),
      minStockAlert: Math.min(1000000, Math.max(0, Number(med.minStockAlert) || 0)),
      addedByUid: uid,
      addedByName: clampStr(med.addedByName || safeActor, 100, safeActor),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    if (med.scientificName && med.scientificName.trim()) {
      payload.scientificName = clampStr(med.scientificName, 200);
    }
    batch.set(doc(db, 'medicines', medId), payload);
  }

  for (const p of localDb.purchases) {
    const pId = sanitizeId(p.id);
    const payload: Record<string, unknown> = {
      id: pId,
      workspaceId: WORKSPACE_ID,
      date: clampStr(p.date, 20, new Date().toISOString().split('T')[0]),
      supplier: clampStr(p.supplier, 200, 'مذخر'),
      barcode: clampStr(p.barcode, 64, '0000'),
      medicineName: clampStr(p.medicineName, 200, 'دواء'),
      qty: Math.min(1000000, Math.max(1, Number(p.qty) || 1)),
      unitPrice: Math.max(0, Number(p.unitPrice) || 0),
      totalAmount: Math.max(0, Number(p.totalAmount) || 0),
      expiryDate: clampStr(p.expiryDate, 20, '2027-01-01'),
      amountPaid: Math.max(0, Number(p.amountPaid) || 0),
      remainingUnpaid: Math.max(0, Number(p.remainingUnpaid) || 0),
      addedByUid: uid,
      addedByName: clampStr(p.addedByName || safeActor, 100, safeActor),
      createdAtMs: Number(p.createdAt) || Date.now(),
      createdAt: serverTimestamp(),
    };
    if (p.notes && p.notes.trim()) {
      payload.notes = clampStr(p.notes, 500);
    }
    batch.set(doc(db, 'purchases', pId), payload);
  }

  for (const s of localDb.sales) {
    const sId = sanitizeId(s.id);
    const payload: Record<string, unknown> = {
      id: sId,
      workspaceId: WORKSPACE_ID,
      date: clampStr(s.date, 20, new Date().toISOString().split('T')[0]),
      buyer: clampStr(s.buyer, 200, 'صيدلية'),
      barcode: clampStr(s.barcode, 64, '0000'),
      medicineName: clampStr(s.medicineName, 200, 'دواء'),
      qty: Math.min(1000000, Math.max(1, Number(s.qty) || 1)),
      unitPrice: Math.max(0, Number(s.unitPrice) || 0),
      totalAmount: Math.max(0, Number(s.totalAmount) || 0),
      avgCostAtSale: Math.max(0, Number(s.avgCostAtSale) || 0),
      amountPaid: Math.max(0, Number(s.amountPaid) || 0),
      remainingUnpaid: Math.max(0, Number(s.remainingUnpaid) || 0),
      addedByUid: uid,
      addedByName: clampStr(s.addedByName || safeActor, 100, safeActor),
      createdAtMs: Number(s.createdAt) || Date.now(),
      createdAt: serverTimestamp(),
    };
    if (s.nearestExpiryBatch && s.nearestExpiryBatch.trim()) {
      payload.nearestExpiryBatch = clampStr(s.nearestExpiryBatch, 20);
    }
    if (s.notes && s.notes.trim()) {
      payload.notes = clampStr(s.notes, 500);
    }
    batch.set(doc(db, 'sales', sId), payload);
  }

  for (const e of localDb.expenses) {
    const eId = sanitizeId(e.id);
    batch.set(doc(db, 'expenses', eId), {
      id: eId,
      workspaceId: WORKSPACE_ID,
      date: clampStr(e.date, 20, new Date().toISOString().split('T')[0]),
      type: clampStr(e.type, 60, 'أخرى'),
      amount: Math.max(1, Number(e.amount) || 1),
      note: clampStr(e.note, 500, ''),
      addedByUid: uid,
      addedByName: clampStr(e.addedByName || safeActor, 100, safeActor),
      createdAtMs: Number(e.createdAt) || Date.now(),
      createdAt: serverTimestamp(),
    });
  }

  for (const pay of localDb.payments) {
    const payId = sanitizeId(pay.id);
    const payload: Record<string, unknown> = {
      id: payId,
      workspaceId: WORKSPACE_ID,
      partyType: pay.partyType === 'supplier' ? 'supplier' : 'buyer',
      partyName: clampStr(pay.partyName, 200, 'عميل'),
      date: clampStr(pay.date, 20, new Date().toISOString().split('T')[0]),
      amount: Math.max(1, Number(pay.amount) || 1),
      type: pay.type === 'payment' ? 'payment' : 'receipt',
      addedByUid: uid,
      addedByName: clampStr(pay.addedByName || safeActor, 100, safeActor),
      createdAtMs: Number(pay.createdAt) || Date.now(),
      createdAt: serverTimestamp(),
    };
    if (pay.note && pay.note.trim()) {
      payload.note = clampStr(pay.note, 500);
    }
    batch.set(doc(db, 'payments', payId), payload);
  }

  try {
    await batch.commit();
    await logCloudActivity({
      actionType: 'sync_seed',
      title: 'رفع ومزامنة البيانات المحلية للسحابة',
      details: `تم رفع ${localDb.medicines.length} دواء و ${localDb.purchases.length} قائمة شراء و ${localDb.sales.length} قائمة بيع`,
      amount: 0,
      actorUid: uid,
      actorName: safeActor,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'batch_seed');
  }
}

export type CloudCollectionName =
  | 'medicines'
  | 'purchases'
  | 'sales'
  | 'expenses'
  | 'payments'
  | 'activityLogs';

// Delete all workspace documents from a specific cloud collection
export async function clearCloudCollection(
  colName: CloudCollectionName,
  actorName?: string,
  logWipe = false
): Promise<number> {
  try {
    const q = query(collection(db, colName), where('workspaceId', '==', WORKSPACE_ID));
    const snap = await getDocs(q);
    if (snap.empty) return 0;

    const docs = snap.docs;
    const chunkSize = 400;
    for (let i = 0; i < docs.length; i += chunkSize) {
      const batch = writeBatch(db);
      for (const d of docs.slice(i, i + chunkSize)) {
        batch.delete(d.ref);
      }
      await batch.commit();
    }

    if (logWipe && colName !== 'activityLogs') {
      const labels: Record<CloudCollectionName, string> = {
        medicines: 'قائمة الأدوية المعرفة',
        purchases: 'فواتير وقوائم المشتريات',
        sales: 'فواتير وقوائم المبيعات',
        expenses: 'سجل المصاريف',
        payments: 'تسديدات الديون',
        activityLogs: 'سجل نشاط الفريق',
      };
      await logCloudActivity({
        actionType: 'delete_record',
        title: `مسح سحابي لقسم: ${labels[colName]}`,
        details: `تم حذف ${docs.length} سجل من السحابة وتصفيره على جميع الأجهزة`,
        amount: 0,
        actorName: actorName || 'المدير',
      });
    }

    return docs.length;
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, colName);
  }
}

// Wipe ALL cloud data across all collections for all connected devices
export async function clearAllCloudData(): Promise<number> {
  const collections: CloudCollectionName[] = [
    'medicines',
    'purchases',
    'sales',
    'expenses',
    'payments',
    'activityLogs',
  ];
  let totalDeleted = 0;
  for (const col of collections) {
    totalDeleted += await clearCloudCollection(col, undefined, false);
  }
  return totalDeleted;
}

// Replace cloud workspace completely with a given local database
export async function replaceCloudWithLocalDatabase(
  localDb: AppDatabase,
  actorName: string
): Promise<void> {
  await clearAllCloudData();
  const hasAnyRecords =
    localDb.medicines.length > 0 ||
    localDb.purchases.length > 0 ||
    localDb.sales.length > 0 ||
    localDb.expenses.length > 0 ||
    localDb.payments.length > 0;
  if (hasAnyRecords) {
    await seedLocalDatabaseToCloud(localDb, actorName);
  }
}

export interface CloudWorkspaceSnapshot {
  medicines: MedicineItem[];
  purchases: PurchaseItem[];
  sales: SaleItem[];
  expenses: ExpenseItem[];
  payments: DebtPayment[];
  activityLogs: ActivityLogItem[];
}

export function subscribeToCloudWorkspace(
  onUpdate: (partial: Partial<CloudWorkspaceSnapshot>) => void,
  onConnectionStatus?: (connected: boolean) => void
): () => void {
  const unsubs: Array<() => void> = [];
  let notifiedConnected = false;

  const markConnected = () => {
    if (!notifiedConnected) {
      notifiedConnected = true;
      onConnectionStatus?.(true);
    }
  };

  // 1. Medicines
  const qMeds = query(collection(db, 'medicines'), where('workspaceId', '==', WORKSPACE_ID));
  unsubs.push(
    onSnapshot(
      qMeds,
      (snap) => {
        markConnected();
        const medicines: MedicineItem[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: String(data.id || d.id),
            barcode: String(data.barcode || ''),
            name: String(data.name || ''),
            scientificName: data.scientificName ? String(data.scientificName) : undefined,
            unit: String(data.unit || 'باكيت'),
            minStockAlert: Number(data.minStockAlert ?? 10),
            addedByUid: data.addedByUid ? String(data.addedByUid) : undefined,
            addedByName: data.addedByName ? String(data.addedByName) : undefined,
          };
        });
        onUpdate({ medicines });
      },
      (err) => {
        onConnectionStatus?.(false);
        handleFirestoreError(err, OperationType.LIST, 'medicines');
      }
    )
  );

  // 2. Purchases
  const qPurchases = query(collection(db, 'purchases'), where('workspaceId', '==', WORKSPACE_ID));
  unsubs.push(
    onSnapshot(
      qPurchases,
      (snap) => {
        markConnected();
        const purchases: PurchaseItem[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: String(data.id || d.id),
              date: String(data.date || ''),
              supplier: String(data.supplier || ''),
              barcode: String(data.barcode || ''),
              medicineName: String(data.medicineName || ''),
              qty: Number(data.qty || 0),
              unitPrice: Number(data.unitPrice || 0),
              totalAmount: Number(data.totalAmount || 0),
              expiryDate: String(data.expiryDate || ''),
              amountPaid: Number(data.amountPaid || 0),
              remainingUnpaid: Number(data.remainingUnpaid || 0),
              notes: data.notes ? String(data.notes) : undefined,
              createdAt: Number(data.createdAtMs || Date.now()),
              addedByUid: data.addedByUid ? String(data.addedByUid) : undefined,
              addedByName: data.addedByName ? String(data.addedByName) : undefined,
            };
          })
          .sort((a, b) => b.createdAt - a.createdAt);
        onUpdate({ purchases });
      },
      (err) => {
        onConnectionStatus?.(false);
        handleFirestoreError(err, OperationType.LIST, 'purchases');
      }
    )
  );

  // 3. Sales
  const qSales = query(collection(db, 'sales'), where('workspaceId', '==', WORKSPACE_ID));
  unsubs.push(
    onSnapshot(
      qSales,
      (snap) => {
        markConnected();
        const sales: SaleItem[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: String(data.id || d.id),
              date: String(data.date || ''),
              buyer: String(data.buyer || ''),
              barcode: String(data.barcode || ''),
              medicineName: String(data.medicineName || ''),
              qty: Number(data.qty || 0),
              unitPrice: Number(data.unitPrice || 0),
              totalAmount: Number(data.totalAmount || 0),
              avgCostAtSale: Number(data.avgCostAtSale || 0),
              amountPaid: Number(data.amountPaid || 0),
              remainingUnpaid: Number(data.remainingUnpaid || 0),
              nearestExpiryBatch: data.nearestExpiryBatch
                ? String(data.nearestExpiryBatch)
                : undefined,
              notes: data.notes ? String(data.notes) : undefined,
              createdAt: Number(data.createdAtMs || Date.now()),
              addedByUid: data.addedByUid ? String(data.addedByUid) : undefined,
              addedByName: data.addedByName ? String(data.addedByName) : undefined,
            };
          })
          .sort((a, b) => b.createdAt - a.createdAt);
        onUpdate({ sales });
      },
      (err) => {
        onConnectionStatus?.(false);
        handleFirestoreError(err, OperationType.LIST, 'sales');
      }
    )
  );

  // 4. Expenses
  const qExpenses = query(collection(db, 'expenses'), where('workspaceId', '==', WORKSPACE_ID));
  unsubs.push(
    onSnapshot(
      qExpenses,
      (snap) => {
        markConnected();
        const expenses: ExpenseItem[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: String(data.id || d.id),
              date: String(data.date || ''),
              type: (data.type as ExpenseItem['type']) || 'أخرى',
              amount: Number(data.amount || 0),
              note: String(data.note || ''),
              createdAt: Number(data.createdAtMs || Date.now()),
              addedByUid: data.addedByUid ? String(data.addedByUid) : undefined,
              addedByName: data.addedByName ? String(data.addedByName) : undefined,
            };
          })
          .sort((a, b) => b.createdAt - a.createdAt);
        onUpdate({ expenses });
      },
      (err) => {
        onConnectionStatus?.(false);
        handleFirestoreError(err, OperationType.LIST, 'expenses');
      }
    )
  );

  // 5. Payments
  const qPayments = query(collection(db, 'payments'), where('workspaceId', '==', WORKSPACE_ID));
  unsubs.push(
    onSnapshot(
      qPayments,
      (snap) => {
        markConnected();
        const payments: DebtPayment[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: String(data.id || d.id),
              partyType:
                data.partyType === 'supplier' ? ('supplier' as const) : ('buyer' as const),
              partyName: String(data.partyName || ''),
              date: String(data.date || ''),
              amount: Number(data.amount || 0),
              type: data.type === 'payment' ? ('payment' as const) : ('receipt' as const),
              note: data.note ? String(data.note) : undefined,
              createdAt: Number(data.createdAtMs || Date.now()),
              addedByUid: data.addedByUid ? String(data.addedByUid) : undefined,
              addedByName: data.addedByName ? String(data.addedByName) : undefined,
            };
          })
          .sort((a, b) => b.createdAt - a.createdAt);
        onUpdate({ payments });
      },
      (err) => {
        onConnectionStatus?.(false);
        handleFirestoreError(err, OperationType.LIST, 'payments');
      }
    )
  );

  // 6. Activity Logs
  const qLogs = query(collection(db, 'activityLogs'), where('workspaceId', '==', WORKSPACE_ID));
  unsubs.push(
    onSnapshot(
      qLogs,
      (snap) => {
        markConnected();
        const activityLogs: ActivityLogItem[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: String(data.id || d.id),
              actionType: (data.actionType as ActivityActionType) || 'add_sale',
              title: String(data.title || ''),
              details: String(data.details || ''),
              amount: Number(data.amount || 0),
              actorUid: String(data.actorUid || ''),
              actorName: String(data.actorName || 'عضو الفريق'),
              createdAtMs: Number(data.createdAtMs || Date.now()),
            };
          })
          .sort((a, b) => b.createdAtMs - a.createdAtMs);
        onUpdate({ activityLogs });
      },
      (err) => {
        onConnectionStatus?.(false);
        handleFirestoreError(err, OperationType.LIST, 'activityLogs');
      }
    )
  );

  return () => {
    unsubs.forEach((u) => u());
  };
}
