import JSZip from 'jszip';

export const MAIN_ACTIVITY_JAVA = `package com.hitech.sfx.eventmanager;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    DB helper;
    LinearLayout root, form, list;
    EditText customer, type, venue, phone, amount, notes, search;
    TextView dateText, summary;
    Spinner status;
    Button saveButton;
    long editingId = -1;
    String selectedDate = "";
    final String[] statuses = {"Booked", "Advance Pending", "Confirmed", "Completed", "Cancelled"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        helper = new DB(this);
        buildUI();
        refreshList("");
    }

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(30, 41, 59));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    EditText field(String hint, int inputType) {
        EditText e = new EditText(this); e.setSingleLine(inputType != 0);
        e.setHint(hint); e.setTextSize(15); e.setInputType(inputType);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(148,163,184)));
        return e;
    }
    LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(10), dp(16), dp(10)); return l;
    }
    void addField(LinearLayout parent, String label, View v) {
        parent.addView(text(label, 13, true));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(8); parent.addView(v, p);
    }
    Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); return b;
    }

    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = vertical(); root.setBackgroundColor(Color.rgb(245,247,251));
        scroll.addView(root); setContentView(scroll);
        TextView title = text("HI-TECH SFX", 25, true);
        title.setTextColor(Color.rgb(15, 76, 129)); root.addView(title);
        root.addView(text("Event Date & Data Manager", 17, true));
        root.addView(text("Offline event records • Stored on this phone", 12, false));
        root.addView(space(8));

        form = vertical(); form.setBackgroundColor(Color.WHITE);
        root.addView(form);
        form.addView(text("Add / Edit Event", 18, true));
        customer = field("Customer / company name", 1);
        type = field("Event type (wedding, corporate, etc.)", 1);
        venue = field("Venue / address", 1);
        phone = field("Contact number", 3);
        amount = field("Total amount (₹)", 8194);
        notes = field("Notes, equipment, crew or payment details", 0);
        notes.setMinLines(2); notes.setGravity(Gravity.TOP);
        dateText = text("Choose event date  ▾", 16, true);
        dateText.setPadding(dp(12), dp(14), dp(12), dp(14));
        dateText.setBackgroundColor(Color.rgb(232,240,250));
        dateText.setOnClickListener(v -> chooseDate());
        status = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, statuses);
        status.setAdapter(adapter);
        addField(form, "Customer", customer);
        addField(form, "Event type", type);
        addField(form, "Event date", dateText);
        addField(form, "Venue", venue);
        addField(form, "Phone", phone);
        addField(form, "Amount", amount);
        addField(form, "Status", status);
        addField(form, "Notes", notes);
        saveButton = button("Save Event");
        saveButton.setTextColor(Color.WHITE); saveButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(15,76,129)));
        form.addView(saveButton);
        Button clear = button("Clear Form");
        form.addView(clear);
        saveButton.setOnClickListener(v -> saveEvent());
        clear.setOnClickListener(v -> clearForm());

        root.addView(space(12));
        summary = text("Events", 18, true); root.addView(summary);
        search = field("Search customer, event, venue, phone...", 1);
        root.addView(search);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ refreshList(s.toString()); }
            public void afterTextChanged(Editable e){}
        });
        list = vertical(); root.addView(list);
        root.addView(text("Tip: tap an event to edit it. Long-press an event to delete it.", 12, false));
    }
    View space(int h) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return v; }

    void chooseDate() {
        Calendar c = Calendar.getInstance();
        if (!selectedDate.isEmpty()) {
            try { c.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(selectedDate)); } catch(Exception ignored){}
        }
        new DatePickerDialog(this, (view,y,m,d) -> {
            selectedDate = String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d);
            dateText.setText("Event date: " + selectedDate);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }
    void saveEvent() {
        String name = customer.getText().toString().trim();
        if (name.isEmpty()) { customer.setError("Customer name is required"); return; }
        if (selectedDate.isEmpty()) { Toast.makeText(this,"Please choose an event date",Toast.LENGTH_SHORT).show(); return; }
        ContentValues v = new ContentValues();
        v.put("customer", name); v.put("type", type.getText().toString().trim());
        v.put("event_date", selectedDate); v.put("venue", venue.getText().toString().trim());
        v.put("phone", phone.getText().toString().trim()); v.put("amount", amount.getText().toString().trim());
        v.put("status", statuses[status.getSelectedItemPosition()]); v.put("notes", notes.getText().toString().trim());
        SQLiteDatabase db = helper.getWritableDatabase();
        if (editingId == -1) db.insert("events", null, v); else db.update("events", v, "_id=?", new String[]{String.valueOf(editingId)});
        Toast.makeText(this, editingId == -1 ? "Event saved" : "Event updated", Toast.LENGTH_SHORT).show();
        clearForm(); refreshList(search == null ? "" : search.getText().toString());
    }
    void clearForm() {
        editingId = -1; customer.setText(""); type.setText(""); venue.setText(""); phone.setText("");
        amount.setText(""); notes.setText(""); status.setSelection(0); selectedDate = "";
        dateText.setText("Choose event date  ▾"); saveButton.setText("Save Event");
    }
    void refreshList(String query) {
        if (list == null || helper == null) return;
        list.removeAllViews();
        SQLiteDatabase db = helper.getReadableDatabase();
        String q = "%" + query + "%";
        Cursor c = db.rawQuery("SELECT _id,customer,type,event_date,venue,phone,amount,status,notes FROM events WHERE customer LIKE ? OR type LIKE ? OR venue LIKE ? OR phone LIKE ? OR event_date LIKE ? ORDER BY event_date ASC",
                new String[]{q,q,q,q,q});
        int count = c.getCount();
        summary.setText("Events (" + count + ")");
        if (count == 0) list.addView(text("No events yet. Add your first event above.", 14, false));
        while (c.moveToNext()) {
            long id=c.getLong(0);
            String name=c.getString(1), evType=c.getString(2), date=c.getString(3), loc=c.getString(4), ph=c.getString(5), amt=c.getString(6), st=c.getString(7), nt=c.getString(8);
            LinearLayout card = vertical(); card.setBackgroundColor(Color.WHITE);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(8); list.addView(card,cp);
            TextView heading=text(name,17,true); heading.setTextColor(Color.rgb(15,76,129)); card.addView(heading);
            card.addView(text(date + "   •   " + (evType.isEmpty()?"Event":evType),14,true));
            if (!loc.isEmpty()) card.addView(text("Venue: "+loc,13,false));
            if (!ph.isEmpty()) card.addView(text("Phone: "+ph,13,false));
            if (!amt.isEmpty()) card.addView(text("Amount: ₹"+amt,13,false));
            card.addView(text("Status: "+st,13,true));
            if (!nt.isEmpty()) card.addView(text("Notes: "+nt,13,false));
            card.setOnClickListener(view -> {
                editingId=id; customer.setText(name); type.setText(evType); selectedDate=date;
                dateText.setText("Event date: "+date); venue.setText(loc); phone.setText(ph); amount.setText(amt); notes.setText(nt);
                int ix=0; for(int i=0;i<statuses.length;i++) if(statuses[i].equals(st)) ix=i; status.setSelection(ix);
                saveButton.setText("Update Event");
                Toast.makeText(this,"Event loaded for editing",Toast.LENGTH_SHORT).show();
            });
            card.setOnLongClickListener(view -> {
                new AlertDialog.Builder(this).setTitle("Delete event?")
                    .setMessage("Delete event for "+name+" on "+date+"? This cannot be undone.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{
                        helper.getWritableDatabase().delete("events","_id=?",new String[]{String.valueOf(id)});
                        refreshList(search.getText().toString());
                    }).show(); return true;
            });
        }
        c.close();
    }

    static class DB extends SQLiteOpenHelper {
        DB(Activity a) { super(a,"hitech_events.db",null,1); }
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE events (_id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT NOT NULL, type TEXT, event_date TEXT NOT NULL, venue TEXT, phone TEXT, amount TEXT, status TEXT, notes TEXT)");
            db.execSQL("CREATE INDEX idx_events_date ON events(event_date)");
        }
        public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {}
    }
}
`;

export const ANDROID_MANIFEST_XML = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.hitech.sfx.eventmanager">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.HiTechSFX">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`;

export const APP_BUILD_GRADLE = `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.hitech.sfx.eventmanager'
    compileSdk 34

    defaultConfig {
        applicationId "com.hitech.sfx.eventmanager"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
}
`;

export const ROOT_BUILD_GRADLE = `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id 'com.android.application' version '8.2.2' apply false
}

tasks.register('clean', Delete) {
    delete rootProject.buildDir
}
`;

export const SETTINGS_GRADLE = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "HiTechSFXEventManager"
include ':app'
`;

export const STRINGS_XML = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">HI-TECH SFX</string>
</resources>
`;

export const COLORS_XML = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary">#0F4C81</color>
    <color name="primary_dark">#0A3459</color>
    <color name="accent">#38BDF8</color>
    <color name="bg_light">#F5F7FB</color>
</resources>
`;

export const STYLES_XML = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.HiTechSFX" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:colorPrimary">@color/primary</item>
        <item name="android:colorPrimaryDark">@color/primary_dark</item>
        <item name="android:colorAccent">@color/accent</item>
        <item name="android:windowBackground">@color/bg_light</item>
    </style>
</resources>
`;

export const GRADLE_PROPERTIES = `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
`;

export const GITHUB_ACTIONS_WORKFLOW = `name: Build Android APK

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - name: Checkout Repository
      uses: actions/checkout@v4

    - name: Set up JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'
        cache: gradle

    - name: Grant Execute Permission to Gradlew
      run: chmod +x gradlew || true

    - name: Build Debug APK
      run: |
        if [ -f "./gradlew" ]; then
          ./gradlew assembleDebug --stacktrace
        else
          gradle assembleDebug --stacktrace
        fi

    - name: Upload Debug APK Artifact
      uses: actions/upload-artifact@v4
      with:
        name: HiTechSFX-Event-Manager-Debug-APK
        path: app/build/outputs/apk/debug/*.apk
        retention-days: 30
`;

export const README_MD = `# HI-TECH SFX - Event Date & Data Manager (Android APK)

An offline Android event date & data manager for **HI-TECH SFX**, built with pure Android native SDK and SQLite database.

Package name: \`com.hitech.sfx.eventmanager\`  
Activity: \`com.hitech.sfx.eventmanager.MainActivity\`  
Database: \`hitech_events.db\` (SQLite)

---

## ⚡ 3 Ways to Get Your APK

### Method 1: Instant 2-Minute Cloud APK Build (Free via GitHub Actions)
No Android Studio or powerful computer required!
1. Create a new repository on [GitHub](https://github.com/new).
2. Upload this extracted folder to your repository.
3. GitHub will automatically detect \`.github/workflows/build-apk.yml\` and compile the APK!
4. Go to the **Actions** tab in your GitHub repository, click on the completed run, and download **\`HiTechSFX-Event-Manager-Debug-APK\`**!
5. Transfer the \`.apk\` to your Android phone and tap to install!

---

### Method 2: Android Studio (Recommended for Developers)
1. Download and install [Android Studio](https://developer.android.com/studio).
2. Open Android Studio and choose **Open an Existing Project**.
3. Select this extracted directory.
4. Let Gradle sync for 1-2 minutes.
5. In top menu, click:  
   **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
6. Android Studio will show a notification: *"APK(s) generated successfully: locate"*.
7. Copy \`app-debug.apk\` to your Android phone and install!

---

### Method 3: Command Line (Linux / Mac / Windows with Android SDK)
\`\`\`bash
chmod +x gradlew
./gradlew assembleDebug
\`\`\`
The APK will be generated at:
\`app/build/outputs/apk/debug/app-debug.apk\`

---

## Features
- **Offline SQLite Database**: All records stay locally on the phone in \`hitech_events.db\`.
- **Customer & Event Details**: Name, event type, date picker, venue, phone, amount (₹), status, notes.
- **Statuses**: Booked, Advance Pending, Confirmed, Completed, Cancelled.
- **Search**: Real-time filtering by customer, venue, phone, date, or event type.
- **Edit & Delete**: Tap an event to load & update; long-press to delete with confirmation.
`;

export async function generateAndroidProjectZip(): Promise<Blob> {
  const zip = new JSZip();

  // Root configuration files
  zip.file('build.gradle', ROOT_BUILD_GRADLE);
  zip.file('settings.gradle', SETTINGS_GRADLE);
  zip.file('gradle.properties', GRADLE_PROPERTIES);
  zip.file('README.md', README_MD);

  // GitHub Actions Workflow for automated cloud APK building
  const githubWorkflows = zip.folder('.github')?.folder('workflows');
  if (githubWorkflows) {
    githubWorkflows.file('build-apk.yml', GITHUB_ACTIONS_WORKFLOW);
  }

  // App module
  const appFolder = zip.folder('app');
  if (appFolder) {
    appFolder.file('build.gradle', APP_BUILD_GRADLE);
    appFolder.file('proguard-rules.pro', '# Add project specific ProGuard rules here.\n');

    // Source main
    const srcMain = appFolder.folder('src')?.folder('main');
    if (srcMain) {
      srcMain.file('AndroidManifest.xml', ANDROID_MANIFEST_XML);

      // Java package directory
      const javaPkg = srcMain.folder('java')?.folder('com')?.folder('hitech')?.folder('sfx')?.folder('eventmanager');
      if (javaPkg) {
        javaPkg.file('MainActivity.java', MAIN_ACTIVITY_JAVA);
      }

      // Resources
      const resValues = srcMain.folder('res')?.folder('values');
      if (resValues) {
        resValues.file('strings.xml', STRINGS_XML);
        resValues.file('colors.xml', COLORS_XML);
        resValues.file('styles.xml', STYLES_XML);
      }
    }
  }

  return await zip.generateAsync({ type: 'blob' });
}
