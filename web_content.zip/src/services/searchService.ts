import { Product } from '../types';

export interface ParsedSearchIntent {
  originalQuery: string;
  normalizedQuery: string;
  cleanKeywords: string[];
  category?: string;
  subcategory?: string;
  brand?: string;
  color?: string;
  size?: string;
  gender?: 'Men' | 'Women' | 'Kids' | 'Unisex';
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  hasDiscount?: boolean;
  isCodRequested?: boolean;
}

export interface SearchResult {
  exactMatches: Product[];
  alternativeMatches: Product[];
  appliedIntent: ParsedSearchIntent;
  message?: string;
  totalFound: number;
}

const DEVANAGARI_DIGITS: Record<string, string> = {
  '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
  '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
};

const HINDI_NUMBER_WORDS: Record<string, number> = {
  'ek': 1, 'do': 2, 'teen': 3, 'char': 4, 'chaar': 4, 'paanch': 5, 'panch': 5,
  'chhah': 6, 'che': 6, 'saat': 7, 'aath': 8, 'nau': 9, 'das': 10, 'dus': 10,
  'sau': 100, 'so': 100,
  'dedh hazar': 1500, 'dedh hazaar': 1500, 'डेढ़ हज़ार': 1500,
  'pandrah sau': 1500, '15 sau': 1500, 'पंद्रह सौ': 1500,
  'dhai hazar': 2500, 'dhai hazaar': 2500, 'ढाई हज़ार': 2500,
  'hazar': 1000, 'hazaar': 1000, 'hazar tak': 1000, 'हज़ार': 1000,
};

const SYNONYMS: Record<string, string[]> = {
  'running': ['sports', 'jogging', 'athletic', 'sneakers', 'trainer', 'training'],
  'jogging': ['running', 'sports', 'sneakers'],
  'shoes': ['footwear', 'sneakers', 'kicks', 'boots', 'slides', 'sandals', 'joota', 'joote', 'chappals', 'slippers'],
  'sneakers': ['shoes', 'running', 'casual'],
  'watch': ['watches', 'smartwatch', 'chronograph', 'timepiece', 'ghadi'],
  'smartwatch': ['watch', 'smart watch', 'pulse', 'fitness band'],
  'bag': ['backpack', 'handbag', 'tote', 'basta', 'luggage', 'travel'],
  'backpack': ['bag', 'laptop bag', 'daypack'],
  'handbag': ['bag', 'purse', 'tote', 'shoulder bag'],
  'sunglasses': ['shades', 'goggles', 'glasses', 'eyewear', 'chashma'],
  'headphones': ['earphones', 'earbuds', 'headset', 'audio'],
  'shirt': ['tshirt', 't-shirt', 'clothing', 'apparel', 'top'],
  'sandals': ['chappal', 'slippers', 'slides', 'footwear'],
  'chappals': ['sandals', 'slippers', 'slides', 'chappal', 'footwear'],
  'slippers': ['chappal', 'slides', 'sandals', 'footwear'],
};

export function normalizeSearchQuery(rawQuery: string): string {
  if (!rawQuery) return '';
  let query = rawQuery.toLowerCase();
  query = query.replace(/[०-९]/g, (digit) => DEVANAGARI_DIGITS[digit] || digit);
  query = query.replace(/,/g, ' ').replace(/\s+/g, ' ');
  return query.trim();
}

export function extractPriceRange(text: string): { minPrice?: number; maxPrice?: number; cleanText: string } {
  let processed = text;
  let minPrice: number | undefined;
  let maxPrice: number | undefined;

  for (const [phrase, value] of Object.entries(HINDI_NUMBER_WORDS)) {
    if (phrase.includes(' ')) {
      const regex = new RegExp(`\\b${phrase}\\b`, 'gi');
      processed = processed.replace(regex, value.toString());
    }
  }

  processed = processed.replace(/(\d+)\s*(?:hazar|hazaar|हज़ार|k)\b/gi, (_, n) => (parseInt(n, 10) * 1000).toString());
  processed = processed.replace(/\b(ek|एक)\s*(?:hazar|hazaar|हज़ार)\b/gi, '1000');
  processed = processed.replace(/\b(do|दो)\s*(?:hazar|hazaar|हज़ार)\b/gi, '2000');
  processed = processed.replace(/\b(teen|तीन)\s*(?:hazar|hazaar|हज़ार)\b/gi, '3000');
  processed = processed.replace(/\b(char|chaar|चार)\s*(?:hazar|hazaar|हज़ार)\b/gi, '4000');
  processed = processed.replace(/\b(paanch|panch|पांच)\s*(?:hazar|hazaar|हज़ार)\b/gi, '5000');
  processed = processed.replace(/\b(das|dus|दस)\s*(?:hazar|hazaar|हज़ार)\b/gi, '10000');
  processed = processed.replace(/(\d+)\s*(?:sau|so|सौ)\b/gi, (_, n) => (parseInt(n, 10) * 100).toString());
  processed = processed.replace(/\b(paanch|panch|पांच)\s*(?:sau|so|सौ)\b/gi, '500');

  const rangeRegex = /(?:between\s+)?₹?\s*(\d+)\s*(?:se|to|-|and)\s*₹?\s*(\d+)\s*(?:ke\s*beech|tak|rupaye)?/i;
  const rangeMatch = processed.match(rangeRegex);
  if (rangeMatch) {
    minPrice = parseInt(rangeMatch[1], 10);
    maxPrice = parseInt(rangeMatch[2], 10);
    processed = processed.replace(rangeMatch[0], ' ');
  }

  if (maxPrice === undefined) {
    const underRegex1 = /(?:under|below|less\s*than|upto|maximum|max)\s*₹?\s*(\d+)/i;
    const underMatch1 = processed.match(underRegex1);
    if (underMatch1) {
      maxPrice = parseInt(underMatch1[1], 10);
      processed = processed.replace(underMatch1[0], ' ');
    } else {
      const underRegex2 = /₹?\s*(\d+)\s*(?:rupaye|rs|inr)?\s*(?:ke\s*andar|tak|se\s*kam|se\s*neeche|ke\s*under)/i;
      const underMatch2 = processed.match(underRegex2);
      if (underMatch2) {
        maxPrice = parseInt(underMatch2[1], 10);
        processed = processed.replace(underMatch2[0], ' ');
      }
    }
  }

  if (minPrice === undefined) {
    const aboveRegex1 = /(?:above|more\s*than|greater\s*than|minimum|min)\s*₹?\s*(\d+)/i;
    const aboveMatch1 = processed.match(aboveRegex1);
    if (aboveMatch1) {
      minPrice = parseInt(aboveMatch1[1], 10);
      processed = processed.replace(aboveMatch1[0], ' ');
    } else {
      const aboveRegex2 = /₹?\s*(\d+)\s*(?:rupaye|rs|inr)?\s*(?:se\s*upar|se\s*jyada)/i;
      const aboveMatch2 = processed.match(aboveRegex2);
      if (aboveMatch2) {
        minPrice = parseInt(aboveMatch2[1], 10);
        processed = processed.replace(aboveMatch2[0], ' ');
      }
    }
  }

  return { minPrice, maxPrice, cleanText: processed };
}

export function extractGender(text: string): { gender?: 'Men' | 'Women' | 'Kids'; cleanText: string } {
  let cleanText = text;
  if (/\b(women|womens|women's|ladies|female|girl|girls|ladki|ladkiyon|ladkiyan|mahila|aurat)\b|महिला|लड़की/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(women|womens|women's|ladies|female|girl|girls|ladki|ladkiyon|ladkiyan|mahila|aurat)\b|महिला|लड़की/gi, ' ');
    return { gender: 'Women', cleanText };
  }
  if (/\b(men|mens|men's|gents|male|boy|boys|ladke|ladko|ladkon|ladka|purush|mard)\b|पुरुष|लड़का/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(men|mens|men's|gents|male|boy|boys|ladke|ladko|ladkon|ladka|purush|mard)\b|पुरुष|लड़का/gi, ' ');
    return { gender: 'Men', cleanText };
  }
  if (/\b(kids|kid|child|children|baby|bachon|bache|bacha|junior)\b|बच्चे|बच्चों/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(kids|kid|child|children|baby|bachon|bache|bacha|junior)\b|बच्चे|बच्चों/gi, ' ');
    return { gender: 'Kids', cleanText };
  }
  return { cleanText };
}

export function extractColor(text: string): { color?: string; cleanText: string } {
  const COLOR_MAP: Record<string, string> = {
    'black': 'Black', 'kaala': 'Black', 'kaali': 'Black', 'kale': 'Black', 'काला': 'Black', 'काली': 'Black', 'काले': 'Black',
    'white': 'White', 'safed': 'White', 'chitta': 'White', 'सफेद': 'White',
    'red': 'Red', 'laal': 'Red', 'lal': 'Red', 'लाल': 'Red',
    'blue': 'Blue', 'neela': 'Blue', 'neeli': 'Blue', 'नीला': 'Blue',
    'green': 'Green', 'hara': 'Green', 'hari': 'Green', 'हरा': 'Green',
    'yellow': 'Yellow', 'peela': 'Yellow', 'peeli': 'Yellow', 'पीला': 'Yellow',
    'pink': 'Pink', 'gulabi': 'Pink', 'गुलाबी': 'Pink',
    'dusty rose': 'Dusty Rose', 'rose': 'Dusty Rose', 'mauve': 'Dusty Rose', 'muted mauve': 'Dusty Rose',
    'grey': 'Grey', 'gray': 'Grey', 'slaty': 'Grey',
    'brown': 'Brown', 'bhoora': 'Brown', 'भूरा': 'Brown',
  };

  let cleanText = text;
  for (const [word, canonical] of Object.entries(COLOR_MAP)) {
    const regex = new RegExp(`\\b${word}\\b`, 'i');
    if (regex.test(cleanText)) {
      cleanText = cleanText.replace(regex, ' ');
      cleanText = cleanText.replace(/\b(color|colour|rang|ka|ke|ki)\b/gi, ' ');
      return { color: canonical, cleanText };
    }
  }
  return { cleanText };
}

export function extractSize(text: string): { size?: string; cleanText: string } {
  let cleanText = text;
  const sizeMatch = cleanText.match(/\b(?:size|no|number)\s*(?:uk\s*)?(\d+)\b/i) ||
                    cleanText.match(/\b(\d+)\s*(?:size|number|no)\b/i) ||
                    cleanText.match(/\b(?:uk\s*)(\d+)\b/i);
  if (sizeMatch) {
    const num = sizeMatch[1];
    cleanText = cleanText.replace(sizeMatch[0], ' ');
    return { size: `UK ${num}`, cleanText };
  }
  return { cleanText };
}

export function extractBrand(text: string): { brand?: string; cleanText: string } {
  const KNOWN_BRANDS = ['Nike', 'Adidas', 'Puma', 'OMAZIFY', 'Titan', 'Fastrack', 'Noise', 'Boat', 'Wildcraft'];
  let cleanText = text;
  for (const brand of KNOWN_BRANDS) {
    const regex = new RegExp(`\\b${brand}\\b`, 'i');
    if (regex.test(cleanText)) {
      cleanText = cleanText.replace(regex, ' ');
      return { brand, cleanText };
    }
  }
  return { cleanText };
}

export function extractCategory(text: string): { category?: string; subcategory?: string; cleanText: string } {
  let cleanText = text;
  if (/\b(smart\s*watch|smartwatch|fitness\s*band)\b|स्मार्टवॉच/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(smart\s*watch|smartwatch|fitness\s*band)\b|स्मार्टवॉच/gi, ' ');
    return { category: 'Accessories', subcategory: 'Smart Accessories', cleanText };
  }
  if (/\b(watch|watches|analog\s*watch|chronograph|ghadi|ghadiyan)\b|घड़ी/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(watch|watches|analog\s*watch|chronograph|ghadi|ghadiyan)\b|घड़ी/gi, ' ');
    return { category: 'Watches', cleanText };
  }
  if (/\b(running\s*shoes|sports\s*shoes|athletic\s*shoes|jogging\s*shoes)\b|जूते/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(running\s*shoes|sports\s*shoes|athletic\s*shoes|jogging\s*shoes)\b|जूते/gi, ' ');
    return { category: 'Men', subcategory: 'Athletic Footwear', cleanText };
  }
  if (/\b(sneakers|sneaker)\b|स्नीकर्स/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(sneakers|sneaker)\b|स्नीकर्स/gi, ' ');
    return { subcategory: 'Lifestyle Footwear', cleanText };
  }
  if (/\b(shoes|footwear|joota|joote|kicks)\b|जूता/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(shoes|footwear|joota|joote|kicks)\b|जूता/gi, ' ');
    return { subcategory: 'Footwear', cleanText };
  }
  if (/\b(slides|sandals|chappal|chappals|slippers)\b|चप्पल|सैंडल/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(slides|sandals|chappal|chappals|slippers)\b|चप्पल|सैंडल/gi, ' ');
    return { subcategory: 'Comfort Footwear', cleanText };
  }
  if (/\b(laptop\s*backpack|backpack|laptop\s*bag)\b|बैग/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(laptop\s*backpack|backpack|laptop\s*bag)\b|बैग/gi, ' ');
    return { category: 'Bags', subcategory: 'Travel & Work', cleanText };
  }
  if (/\b(handbag|purse|tote|shoulder\s*bag)\b|हैंडबैग/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(handbag|purse|tote|shoulder\s*bag)\b|हैंडबैग/gi, ' ');
    return { category: 'Bags', subcategory: 'Luxury Handbags', cleanText };
  }
  if (/\b(bag|bags|basta|travel\s*bag)\b|बस्ता/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(bag|bags|basta|travel\s*bag)\b|बस्ता/gi, ' ');
    return { category: 'Bags', cleanText };
  }
  if (/\b(sunglasses|sunglass|shades|goggles|chashma)\b|चश्मा/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(sunglasses|sunglass|shades|goggles|chashma)\b|चश्मा/gi, ' ');
    return { category: 'Accessories', cleanText };
  }
  if (/\b(headphones|headphone|earphones|earbuds|airpods)\b|हेडफ़ोन/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(headphones|headphone|earphones|earbuds|airpods)\b|हेडफ़ोन/gi, ' ');
    return { category: 'Accessories', cleanText };
  }
  if (/\b(shirt|shirts|tshirt|t-shirt)\b|शर्ट/i.test(cleanText)) {
    cleanText = cleanText.replace(/\b(shirt|shirts|tshirt|t-shirt)\b|शर्ट/gi, ' ');
    return { subcategory: 'Apparel', cleanText };
  }
  return { cleanText };
}

export function cleanFillerWords(text: string): string[] {
  const FILLERS = new Set([
    'dikhao', 'dikhaye', 'dikhaiye', 'chahiye', 'batao', 'dhundo', 'lao',
    'mujhe', 'mere', 'liye', 'humko', 'bhai', 'please', 'kripya',
    'ka', 'ki', 'ke', 'ko', 'se', 'mein', 'me', 'par', 'pe',
    'wala', 'wale', 'wali', 'hai', 'hain', 'bhi', 'toh', 'aur',
    'kuch', 'accha', 'achha', 'badhiya', 'sasta', 'saste',
    'दिखाओ', 'दिखाइए', 'चाहिए', 'बताओ', 'ढूंढो', 'लाओ', 'मुझे',
    'मेरे', 'लिए', 'हमको', 'कृपया', 'का', 'की', 'के', 'को',
    'से', 'में', 'पर', 'वाला', 'वाले', 'वाली', 'है', 'हैं',
    'भी', 'तो', 'और', 'कुछ', 'अच्छा', 'बढ़िया', 'सस्ता',
    'show', 'me', 'display', 'find', 'search', 'for', 'i', 'want',
    'looking', 'give', 'the', 'a', 'an', 'in', 'on', 'at', 'to', 'of',
    'with', 'and', 'or', 'best', 'good', 'top', 'buy', 'shop', 'online'
  ]);
  const tokens = text
    .toLowerCase()
    .replace(/[^\w\s\u0900-\u097F]/g, ' ')
    .split(/\s+/)
    .filter((tok) => tok.length > 1 && !FILLERS.has(tok));
  return tokens;
}

export function parseSearchIntent(rawQuery: string): ParsedSearchIntent {
  const normalized = normalizeSearchQuery(rawQuery);
  let workingText = normalized;

  let minRating: number | undefined;
  const ratingMatch = workingText.match(/(\d(?:\.\d)?)\s*(?:star|stars|\*)\s*(?:se\s*upar|above|\+)?/i);
  if (ratingMatch) {
    minRating = parseFloat(ratingMatch[1]);
    workingText = workingText.replace(ratingMatch[0], ' ');
  }

  let hasDiscount = false;
  if (/\b(discount|offer|sale|saste)\b/i.test(workingText)) {
    hasDiscount = true;
    workingText = workingText.replace(/\b(discount|offer|sale|saste)\b/gi, ' ');
  }

  let isCodRequested = false;
  if (/\b(cod|cash\s*on\s*delivery)\b/i.test(workingText)) {
    isCodRequested = true;
    workingText = workingText.replace(/\b(cod|cash\s*on\s*delivery)\b/gi, ' ');
  }

  const { minPrice, maxPrice, cleanText: textAfterPrice } = extractPriceRange(workingText);
  workingText = textAfterPrice;

  const { gender, cleanText: textAfterGender } = extractGender(workingText);
  workingText = textAfterGender;

  const { color, cleanText: textAfterColor } = extractColor(workingText);
  workingText = textAfterColor;

  const { size, cleanText: textAfterSize } = extractSize(workingText);
  workingText = textAfterSize;

  const { brand, cleanText: textAfterBrand } = extractBrand(workingText);
  workingText = textAfterBrand;

  const { category, subcategory, cleanText: textAfterCat } = extractCategory(workingText);
  workingText = textAfterCat;

  const cleanKeywords = cleanFillerWords(workingText);

  return {
    originalQuery: rawQuery,
    normalizedQuery: normalized,
    cleanKeywords,
    category,
    subcategory,
    brand,
    color,
    size,
    gender,
    minPrice,
    maxPrice,
    minRating,
    hasDiscount,
    isCodRequested,
  };
}

export function searchProducts(
  catalog: Product[],
  rawQuery: string,
  categoryFilter: string = 'All'
): SearchResult {
  const intent = parseSearchIntent(rawQuery);

  if (!rawQuery.trim()) {
    const defaultList = categoryFilter === 'All'
      ? catalog
      : catalog.filter((p) => p.category.toLowerCase() === categoryFilter.toLowerCase());
    return {
      exactMatches: defaultList,
      alternativeMatches: [],
      appliedIntent: intent,
      totalFound: defaultList.length,
    };
  }

  interface ScoredProduct {
    product: Product;
    score: number;
    pricePasses: boolean;
    genderPasses: boolean;
  }

  const scoredList: ScoredProduct[] = catalog.map((p) => {
    let score = 0;
    const nameLower = p.name.toLowerCase();
    const brandLower = p.brand.toLowerCase();
    const catLower = p.category.toLowerCase();
    const subcatLower = p.subcategory.toLowerCase();
    const descLower = p.description.toLowerCase();
    const keywords = (p.keywords || []).map((k) => k.toLowerCase());

    if (nameLower === intent.normalizedQuery) {
      score += 120;
    } else if (nameLower.includes(intent.normalizedQuery)) {
      score += 80;
    }

    for (const kw of intent.cleanKeywords) {
      if (nameLower.includes(kw)) score += 45;
      if (brandLower.includes(kw)) score += 40;
      if (subcatLower.includes(kw)) score += 35;
      if (catLower.includes(kw)) score += 30;
      if (keywords.includes(kw)) score += 25;
      if (descLower.includes(kw)) score += 15;

      const synonymsList = SYNONYMS[kw] || [];
      for (const syn of synonymsList) {
        if (nameLower.includes(syn) || subcatLower.includes(syn) || keywords.includes(syn)) {
          score += 20;
        }
      }
    }

    if (intent.category) {
      if (catLower === intent.category.toLowerCase()) score += 50;
      else if (nameLower.includes(intent.category.toLowerCase())) score += 30;
    }

    if (intent.subcategory) {
      if (subcatLower === intent.subcategory.toLowerCase()) score += 40;
      else if (nameLower.includes(intent.subcategory.toLowerCase())) score += 25;
    }

    if (intent.brand) {
      if (brandLower === intent.brand.toLowerCase()) score += 60;
      else if (nameLower.includes(intent.brand.toLowerCase())) score += 40;
    }

    if (intent.color) {
      const hasColor = p.colors?.some((c) =>
        c.name.toLowerCase().includes(intent.color!.toLowerCase())
      );
      if (hasColor || nameLower.includes(intent.color.toLowerCase())) {
        score += 50;
      }
    }

    if (intent.size) {
      const hasSize = p.sizes?.some((s) =>
        s.toLowerCase().includes(intent.size!.toLowerCase())
      );
      if (hasSize) score += 45;
    }

    let genderPasses = true;
    if (intent.gender) {
      const pGender = p.gender || (p.category === 'Men' ? 'Men' : p.category === 'Women' ? 'Women' : p.category === 'Kids' ? 'Kids' : 'Unisex');
      if (pGender === intent.gender || pGender === 'Unisex') {
        score += 45;
      } else {
        genderPasses = false;
        score -= 50;
      }
    }

    let pricePasses = true;
    if (intent.maxPrice !== undefined && p.price > intent.maxPrice) {
      pricePasses = false;
    }
    if (intent.minPrice !== undefined && p.price < intent.minPrice) {
      pricePasses = false;
    }

    if (intent.minRating !== undefined) {
      if (p.rating >= intent.minRating) score += 20;
      else score -= 30;
    }

    if (intent.hasDiscount && p.discount > 0) {
      score += 20;
    }

    score += (p.rating || 4) * 2;
    if (p.isBestseller) score += 5;

    return { product: p, score, pricePasses, genderPasses };
  });

  const threshold = 15;
  const exactCandidates = scoredList
    .filter((it) => it.score >= threshold && it.pricePasses && it.genderPasses)
    .sort((a, b) => b.score - a.score)
    .map((it) => it.product);

  const isOffersFilter =
    categoryFilter.toLowerCase() === 'offers' ||
    categoryFilter.toLowerCase() === 'deals';

  const filteredExact = categoryFilter === 'All'
    ? exactCandidates
    : isOffersFilter
    ? exactCandidates
        .filter((p) => (p.discount && p.discount > 0) || p.originalPrice > p.price)
        .sort((a, b) => (b.discount || 0) - (a.discount || 0))
    : exactCandidates.filter((p) => p.category.toLowerCase() === categoryFilter.toLowerCase());

  let alternativeMatches: Product[] = [];
  let message: string | undefined;

  if (filteredExact.length === 0 && intent.maxPrice !== undefined) {
    const relaxedMax = Math.round(intent.maxPrice * 1.35);
    alternativeMatches = scoredList
      .filter((it) => it.score >= threshold && it.genderPasses && it.product.price <= relaxedMax)
      .sort((a, b) => b.score - a.score)
      .map((it) => it.product);

    if (alternativeMatches.length > 0) {
      message = `No products found under ₹${intent.maxPrice.toLocaleString()}. Showing similar products up to ₹${relaxedMax.toLocaleString()}.`;
    }
  } else if (filteredExact.length === 0) {
    alternativeMatches = scoredList
      .filter((it) => it.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 4)
      .map((it) => it.product);
  }

  return {
    exactMatches: filteredExact,
    alternativeMatches,
    appliedIntent: intent,
    message,
    totalFound: filteredExact.length,
  };
}

export function getSearchSuggestions(catalog: Product[], partialQuery: string): string[] {
  if (!partialQuery.trim()) return [];
  const normalized = partialQuery.trim().toLowerCase();
  const suggestionsSet = new Set<string>();

  catalog.forEach((p) => {
    if (p.name.toLowerCase().includes(normalized)) {
      suggestionsSet.add(p.name);
    }
    if (p.brand.toLowerCase().includes(normalized)) {
      suggestionsSet.add(p.brand);
    }
  });

  const commonCategories = [
    'Running Shoes', 'Sports Shoes', 'Men Sneakers', "Women's Sneakers",
    'Smart Watches', 'Leather Bags', 'Laptop Backpack', 'Handbag',
    'Kids Footwear', 'UV Sunglasses', 'Wireless Headphones', 'Cotton Shirt',
    'Chappals', 'Sandals', 'Slippers'
  ];

  commonCategories.forEach((cat) => {
    if (cat.toLowerCase().includes(normalized)) {
      suggestionsSet.add(cat);
    }
  });

  return Array.from(suggestionsSet).slice(0, 6);
}
