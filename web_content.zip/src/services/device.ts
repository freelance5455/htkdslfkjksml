import { Device } from "@capacitor/device";

export interface DeviceStats { ramUsedPct: number; batteryPct: number; charging: boolean; model: string; cores: number }

/** Reads real device information via the Capacitor Device plugin. */
export async function readStats(): Promise<DeviceStats> {
  const [info, battery] = await Promise.all([Device.getInfo(), Device.getBatteryInfo()]);
  const total = (info as { realDiskTotal?: number }).realDiskTotal ?? 0;
  const used = info.memUsed ?? 0;
  return {
    ramUsedPct: total ? Math.round((used / total) * 100) : 0,
    batteryPct: Math.round((battery.batteryLevel ?? 0) * 100),
    charging: !!battery.isCharging,
    model: info.model,
    cores: navigator.hardwareConcurrency || 0,
  };
}
