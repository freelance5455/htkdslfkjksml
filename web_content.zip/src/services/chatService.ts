import { supabase } from '../lib/supabase';
import { AutoDeleteChatDuration, ConversationWithDetails, DisappearingDuration, Message, MessageReaction, MessageType, Profile } from '../types';

interface LocalConvSetting {
  isPinned?: boolean;
  isMuted?: boolean;
  isDeleted?: boolean;
  clearedAt?: string | null;
  disappearingDuration?: DisappearingDuration;
  autoDeleteChatDuration?: AutoDeleteChatDuration;
  autoDeleteChatStartedAt?: string | null;
  wallpaper?: string | null;
}

function getLocalConvSettings(userId: string): Record<string, LocalConvSetting> {
  try {
    const raw = localStorage.getItem(`nexa_conv_settings_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function updateLocalConvSetting(userId: string, convId: string, updates: Partial<LocalConvSetting>) {
  try {
    const settings = getLocalConvSettings(userId);
    settings[convId] = { ...(settings[convId] || {}), ...updates };
    localStorage.setItem(`nexa_conv_settings_${userId}`, JSON.stringify(settings));
  } catch {}
}

export function mapDbMessageToClient(m: any): Message {
  const isDeletedEveryone = Boolean(m.deleted_at || m.is_deleted_everyone);
  return {
    id: m.id,
    conversation_id: m.conversation_id,
    sender_id: m.sender_id,
    content: isDeletedEveryone ? 'This message was deleted' : (m.content || ''),
    type: (m.message_type || m.type || 'text') as MessageType,
    file_name: m.file_name || null,
    file_size: m.file_size || null,
    mime_type: m.mime_type || null,
    media_path: m.media_url || m.media_path || null,
    reply_to_id: m.reply_to_id || null,
    is_view_once: Boolean(m.is_view_once),
    viewed_at: m.viewed_at || null,
    is_edited: Boolean(m.is_edited || m.edited_at),
    is_deleted_everyone: isDeletedEveryone,
    expires_at: m.expires_at || null,
    created_at: m.created_at,
    updated_at: m.updated_at,
    sender: m.sender,
    delivered_at: m.delivered_at || null,
    read_at: m.read_at || null,
    reactions: Array.isArray(m.reactions) ? m.reactions : [],
    is_saved: false,
  };
}

/**
 * 1. Open or create direct conversation between authenticated user and accepted friend
 */
export async function getOrCreateDirectConversation(otherUserId: string): Promise<string> {
  const { data: { session } } = await supabase.auth.getSession();

  // Try backend endpoint first
  if (session?.access_token) {
    try {
      const res = await fetch('/api/chat/conversation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ otherUserId }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.conversationId) {
          return data.conversationId;
        }
      }
    } catch (err) {
      console.warn('Backend conversation endpoint failed, trying DB fallback:', err);
    }
  }

  // 2. Try RPC if available
  try {
    const { data, error } = await supabase.rpc('create_or_get_direct_conversation', {
      other_user_id: otherUserId,
    });
    if (!error && data) {
      return data;
    }
  } catch {}

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  // 3. Fallback: check mutual conversation_members
  const { data: myMemberships } = await supabase
    .from('conversation_members')
    .select('conversation_id')
    .eq('user_id', user.id);

  const myConvIds = (myMemberships || []).map((m) => m.conversation_id);

  if (myConvIds.length > 0) {
    const { data: existing } = await supabase
      .from('conversation_members')
      .select('conversation_id')
      .in('conversation_id', myConvIds)
      .eq('user_id', otherUserId)
      .limit(1);

    if (existing && existing.length > 0) {
      const convId = existing[0].conversation_id;
      updateLocalConvSetting(user.id, convId, { isDeleted: false });
      return convId;
    }
  }

  // 4. Create new conversation
  const { data: newConv, error: convErr } = await supabase
    .from('conversations')
    .insert({})
    .select('id')
    .single();

  if (convErr || !newConv) {
    throw convErr || new Error('Failed to create conversation');
  }

  await supabase.from('conversation_members').insert([
    { conversation_id: newConv.id, user_id: user.id },
    { conversation_id: newConv.id, user_id: otherUserId },
  ]);

  return newConv.id;
}

/**
 * Create a new group conversation
 */
export async function createGroupConversation(params: {
  name: string;
  memberIds: string[];
  photoUrl?: string;
}): Promise<string> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) throw new Error('Not authenticated');

  // Try backend API
  try {
    const res = await fetch('/api/chat/group', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify(params),
    });

    if (res.ok) {
      const data = await res.json();
      return data.id;
    }
  } catch (err) {
    console.warn('Backend group create failed, trying DB fallback:', err);
  }

  // Fallback direct DB
  const { data: newConv, error } = await supabase
    .from('conversations')
    .insert({ type: 'group', name: params.name })
    .select('id')
    .single();

  if (error || !newConv) throw error || new Error('Failed to create group');

  const allMembers = Array.from(new Set([session.user.id, ...params.memberIds]));
  await supabase.from('conversation_members').insert(
    allMembers.map((uid) => ({ conversation_id: newConv.id, user_id: uid }))
  );

  return newConv.id;
}

/**
 * 2. Get conversations list for current user
 */
export async function getConversations(currentUserId: string): Promise<ConversationWithDetails[]> {
  const { data: { session } } = await supabase.auth.getSession();

  // Try backend endpoint
  if (session?.access_token) {
    try {
      const res = await fetch('/api/chat/conversations', {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          const localSettings = getLocalConvSettings(currentUserId);
          const list = data
            .map((c: any) => {
              const s = localSettings[c.id] || {};
              const effectiveClearedAt = s.clearedAt || c.clearedAt || null;
              return {
                id: c.id,
                type: c.type || 'direct',
                name: c.name || null,
                photo_url: c.photo_url || null,
                creator_id: c.creator_id || null,
                admin_ids: c.admin_ids || [],
                members: c.members,
                otherUser: c.otherUser,
                lastMessage: c.lastMessage ? mapDbMessageToClient(c.lastMessage) : null,
                unreadCount: c.unreadCount || 0,
                isPinned: Boolean(s.isPinned ?? c.isPinned),
                isMuted: Boolean(s.isMuted ?? c.isMuted),
                clearedAt: effectiveClearedAt,
                disappearingDuration: s.disappearingDuration || c.disappearingDuration || 'off',
                wallpaper: c.wallpaper || null,
              };
            })
            .filter((c: any) => !localSettings[c.id]?.isDeleted);

          list.sort((a: any, b: any) => {
            if (a.isPinned && !b.isPinned) return -1;
            if (!a.isPinned && b.isPinned) return 1;
            const timeA = a.lastMessage?.created_at ? new Date(a.lastMessage.created_at).getTime() : 0;
            const timeB = b.lastMessage?.created_at ? new Date(b.lastMessage.created_at).getTime() : 0;
            return timeB - timeA;
          });

          return list;
        }
      }
    } catch (err) {
      console.warn('Backend conversations fetch error, falling back to DB:', err);
    }
  }

  // DB Fallback
  const { data: memberships, error: memErr } = await supabase
    .from('conversation_members')
    .select('conversation_id')
    .eq('user_id', currentUserId);

  if (memErr || !memberships || memberships.length === 0) {
    return [];
  }

  const convIds = memberships.map((m) => m.conversation_id);
  const localSettings = getLocalConvSettings(currentUserId);
  const activeConvIds = convIds.filter((id) => !localSettings[id]?.isDeleted);

  if (activeConvIds.length === 0) return [];

  const { data: allMembers } = await supabase
    .from('conversation_members')
    .select('conversation_id, user_id, user:profiles!user_id(*)')
    .in('conversation_id', activeConvIds);

  const membersByConv: Record<string, any[]> = {};
  (allMembers || []).forEach((m) => {
    if (!membersByConv[m.conversation_id]) membersByConv[m.conversation_id] = [];
    membersByConv[m.conversation_id].push(m);
  });

  // Query latest messages for fallback
  const { data: latestMsgs } = await supabase
    .from('messages')
    .select('*, sender:profiles!sender_id(*)')
    .in('conversation_id', activeConvIds)
    .order('created_at', { ascending: false });

  const latestMsgByConv: Record<string, Message> = {};
  const unreadByConv: Record<string, number> = {};

  (latestMsgs || []).forEach((raw) => {
    const msg = mapDbMessageToClient(raw);
    const convId = msg.conversation_id;
    const s = localSettings[convId] || {};
    const clearTime = s.clearedAt ? new Date(s.clearedAt).getTime() : 0;
    const msgTime = new Date(msg.created_at).getTime();

    if (clearTime > 0 && msgTime <= clearTime) return;

    if (!latestMsgByConv[convId]) {
      latestMsgByConv[convId] = msg;
    }
    if (msg.sender_id !== currentUserId && !msg.read_at) {
      unreadByConv[convId] = (unreadByConv[convId] || 0) + 1;
    }
  });

  const result: ConversationWithDetails[] = [];

  for (const convId of activeConvIds) {
    const s = localSettings[convId] || {};
    const members = membersByConv[convId] || [];
    const otherMemberObj = members.find((m) => m.user_id !== currentUserId);
    const otherUser = otherMemberObj?.user || {
      id: 'unknown',
      username: 'User',
      display_name: 'User',
    };

    result.push({
      id: convId,
      otherUser,
      lastMessage: latestMsgByConv[convId] || null,
      unreadCount: unreadByConv[convId] || 0,
      isPinned: Boolean(s.isPinned),
      isMuted: Boolean(s.isMuted),
      clearedAt: s.clearedAt || null,
      disappearingDuration: s.disappearingDuration || 'off',
    });
  }

  // Sort by pinned first, then last message created_at descending
  result.sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    const timeA = a.lastMessage?.created_at ? new Date(a.lastMessage.created_at).getTime() : 0;
    const timeB = b.lastMessage?.created_at ? new Date(b.lastMessage.created_at).getTime() : 0;
    return timeB - timeA;
  });

  return result;
}

/**
 * 3. Load messages for a conversation
 */
export async function getMessages(
  conversationId: string,
  currentUserId: string,
  clearedAt?: string | null
): Promise<Message[]> {
  const localSettings = getLocalConvSettings(currentUserId);
  const localClearedAt = localSettings[conversationId]?.clearedAt;
  const effectiveClearedAt = localClearedAt || clearedAt || null;
  const clearTime = effectiveClearedAt ? new Date(effectiveClearedAt).getTime() : 0;

  // Deleted for me message IDs
  let deletedMsgIds: string[] = [];
  try {
    const raw = localStorage.getItem(`nexa_deleted_msgs_${currentUserId}`);
    if (raw) deletedMsgIds = JSON.parse(raw);
  } catch {}
  const deletedSet = new Set(deletedMsgIds);

  const filterMessages = (msgs: Message[]) => {
    return msgs.filter((m) => {
      if (deletedSet.has(m.id)) return false;
      if (clearTime > 0 && new Date(m.created_at).getTime() <= clearTime) return false;
      return true;
    });
  };

  const { data: { session } } = await supabase.auth.getSession();

  // Try backend endpoint
  if (session?.access_token) {
    try {
      const res = await fetch(`/api/chat/messages?conversationId=${encodeURIComponent(conversationId)}`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          const msgs = data.map(mapDbMessageToClient);
          return filterMessages(msgs);
        }
      }
    } catch (err) {
      console.warn('Backend messages fetch failed, trying DB:', err);
    }
  }

  // Database fallback
  let query = supabase
    .from('messages')
    .select('*, sender:profiles!sender_id(*)')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true });

  if (effectiveClearedAt) {
    query = query.gt('created_at', effectiveClearedAt);
  }

  const { data, error } = await query;
  if (error) {
    console.error('Failed to get messages from DB:', error);
    return [];
  }

  return filterMessages((data || []).map(mapDbMessageToClient));
}

/**
 * 4. Send a message
 */
export async function sendMessage(params: {
  conversationId: string;
  senderId: string;
  content: string;
  type?: MessageType;
  fileName?: string;
  fileSize?: number;
  mimeType?: string;
  mediaPath?: string;
  replyToId?: string;
  isViewOnce?: boolean;
  disappearingDuration?: DisappearingDuration;
}): Promise<Message> {
  const { data: { session } } = await supabase.auth.getSession();
  let createdMessage: Message | null = null;

  // Try backend API first
  if (session?.access_token) {
    try {
      const res = await fetch('/api/chat/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          conversationId: params.conversationId,
          content: params.content,
          messageType: params.type || 'text',
          mediaUrl: params.mediaPath,
          replyToId: params.replyToId,
          isViewOnce: params.isViewOnce,
          fileName: params.fileName,
          fileSize: params.fileSize,
          mimeType: params.mimeType,
          disappearingDuration: params.disappearingDuration,
        }),
      });
      if (res.ok) {
        const raw = await res.json();
        createdMessage = mapDbMessageToClient(raw);
      }
    } catch (err) {
      console.warn('Backend send endpoint failed, using DB:', err);
    }
  }

  // Fallback direct DB insert if backend was unavailable
  if (!createdMessage) {
    let expiresAt: string | null = null;
    if (params.disappearingDuration && params.disappearingDuration !== 'off') {
      const now = Date.now();
      if (params.disappearingDuration === '5m') expiresAt = new Date(now + 5 * 60 * 1000).toISOString();
      else if (params.disappearingDuration === '1h') expiresAt = new Date(now + 60 * 60 * 1000).toISOString();
      else if (params.disappearingDuration === '24h') expiresAt = new Date(now + 24 * 3600 * 1000).toISOString();
      else if (params.disappearingDuration === '7d') expiresAt = new Date(now + 7 * 24 * 3600 * 1000).toISOString();
      else if (params.disappearingDuration === '30d') expiresAt = new Date(now + 30 * 24 * 3600 * 1000).toISOString();
      else if (params.disappearingDuration === '90d') expiresAt = new Date(now + 90 * 24 * 3600 * 1000).toISOString();
    }

    const payload: any = {
      conversation_id: params.conversationId,
      sender_id: params.senderId,
      content: params.content || (params.fileName ? `[File: ${params.fileName}]` : ''),
      message_type: params.type || 'text',
      media_url: params.mediaPath || null,
      expires_at: expiresAt,
    };

    const { data, error } = await supabase
      .from('messages')
      .insert(payload)
      .select('*, sender:profiles!sender_id(*)')
      .single();

    if (error) {
      console.error('Failed to insert message into DB:', error);
      throw error;
    }
    createdMessage = mapDbMessageToClient(data);
  }

  // Broadcast the new message in real time to the conversation channel!
  try {
    const roomChannel = supabase.channel(`chat-room-${params.conversationId}`);
    roomChannel.send({
      type: 'broadcast',
      event: 'new_message',
      payload: createdMessage,
    });

    // Also broadcast globally so recipient's chat list & notifications update instantly
    const globalChannel = supabase.channel('nexa-global-chat');
    globalChannel.send({
      type: 'broadcast',
      event: 'global_new_message',
      payload: {
        conversationId: params.conversationId,
        message: createdMessage,
      },
    });
  } catch (err) {
    console.warn('Broadcast new message error:', err);
  }

  return createdMessage;
}

/**
 * Mark a message delivered on recipient device
 */
export async function markMessageDelivered(messageId: string, conversationId: string, recipientUserId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch('/api/chat/mark-delivered', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ messageId, conversationId }),
      });
    } catch {}
  }

  const now = new Date().toISOString();
  try {
    await supabase
      .from('messages')
      .update({ delivered_at: now })
      .eq('id', messageId)
      .is('delivered_at', null);
  } catch {}

  try {
    const roomChannel = supabase.channel(`chat-room-${conversationId}`);
    roomChannel.send({
      type: 'broadcast',
      event: 'message_delivered',
      payload: { messageId, conversationId, deliveredAt: now },
    });
  } catch {}
}

/**
 * 5. Edit message
 */
export async function editMessage(messageId: string, currentUserId: string, newContent: string, conversationId?: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();

  if (session?.access_token) {
    try {
      await fetch(`/api/chat/message/${messageId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ action: 'edit', content: newContent }),
      });
    } catch {}
  }

  try {
    await supabase
      .from('messages')
      .update({
        content: newContent,
        edited_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('id', messageId)
      .eq('sender_id', currentUserId);
  } catch {}

  if (conversationId) {
    try {
      const roomChannel = supabase.channel(`chat-room-${conversationId}`);
      roomChannel.send({
        type: 'broadcast',
        event: 'chat_updated',
        payload: { messageId, content: newContent, isEdited: true },
      });
    } catch {}
  }
}

/**
 * 6. Delete message for me
 */
export async function deleteMessageForMe(messageId: string, currentUserId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch(`/api/chat/message/${messageId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ action: 'delete_for_me' }),
      });
    } catch {}
  }

  const key = `nexa_deleted_msgs_${currentUserId}`;
  try {
    const existing = JSON.parse(localStorage.getItem(key) || '[]');
    if (!existing.includes(messageId)) {
      existing.push(messageId);
      localStorage.setItem(key, JSON.stringify(existing));
    }
  } catch {}
}

/**
 * 7. Delete message for everyone
 */
export async function deleteMessageForEveryone(messageId: string, currentUserId?: string, conversationId?: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch(`/api/chat/message/${messageId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ action: 'delete_for_everyone' }),
      });
    } catch {}
  }

  try {
    let query = supabase
      .from('messages')
      .update({
        content: 'This message was deleted',
        deleted_at: new Date().toISOString(),
        media_url: null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', messageId);

    if (currentUserId) query = query.eq('sender_id', currentUserId);
    await query;
  } catch {}

  if (conversationId) {
    try {
      const roomChannel = supabase.channel(`chat-room-${conversationId}`);
      roomChannel.send({
        type: 'broadcast',
        event: 'chat_updated',
        payload: { messageId, deleted: true },
      });
    } catch {}
  }
}

/**
 * 8. Add reaction
 */
export async function addReaction(messageId: string, currentUserId: string, emoji: string, conversationId?: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch(`/api/chat/message/${messageId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ action: 'add_reaction', reaction: emoji }),
      });
    } catch {}
  }

  try {
    await supabase.from('message_reactions').upsert(
      {
        message_id: messageId,
        user_id: currentUserId,
        reaction: emoji,
        created_at: new Date().toISOString(),
      },
      { onConflict: 'message_id,user_id' }
    );
  } catch {}

  if (conversationId) {
    try {
      const roomChannel = supabase.channel(`chat-room-${conversationId}`);
      roomChannel.send({
        type: 'broadcast',
        event: 'reaction_updated',
        payload: { messageId, userId: currentUserId, reaction: emoji },
      });
    } catch {}
  }
}

/**
 * 9. Remove reaction
 */
export async function removeReaction(messageId: string, currentUserId: string, conversationId?: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch(`/api/chat/message/${messageId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ action: 'remove_reaction' }),
      });
    } catch {}
  }

  try {
    await supabase
      .from('message_reactions')
      .delete()
      .eq('message_id', messageId)
      .eq('user_id', currentUserId);
  } catch {}

  if (conversationId) {
    try {
      const roomChannel = supabase.channel(`chat-room-${conversationId}`);
      roomChannel.send({
        type: 'broadcast',
        event: 'reaction_updated',
        payload: { messageId, userId: currentUserId, removed: true },
      });
    } catch {}
  }
}

/**
 * 10. Mark messages as read
 */
export async function markMessagesRead(conversationId: string, currentUserId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch('/api/chat/message/all', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ action: 'mark_read', conversationId }),
      });
    } catch {}
  }

  const now = new Date().toISOString();
  try {
    await supabase
      .from('messages')
      .update({ read_at: now, delivered_at: now })
      .eq('conversation_id', conversationId)
      .neq('sender_id', currentUserId)
      .is('read_at', null);
  } catch {}

  try {
    const roomChannel = supabase.channel(`chat-room-${conversationId}`);
    roomChannel.send({
      type: 'broadcast',
      event: 'messages_read',
      payload: { conversationId, readerId: currentUserId },
    });
  } catch {}
}

export async function clearChatForMe(conversationId: string, currentUserId: string): Promise<void> {
  const now = new Date().toISOString();
  updateLocalConvSetting(currentUserId, conversationId, {
    clearedAt: now,
  });

  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch('/api/chat/clear-for-me', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ conversationId }),
      });
    } catch {}
  }
}

export async function deleteChatForMe(conversationId: string, currentUserId: string): Promise<void> {
  const now = new Date().toISOString();
  updateLocalConvSetting(currentUserId, conversationId, {
    isDeleted: true,
    clearedAt: now,
  });

  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch('/api/chat/delete-chat-for-me', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ conversationId }),
      });
    } catch {}
  }
}

export async function setDisappearingDuration(
  conversationId: string,
  currentUserId: string,
  duration: DisappearingDuration
): Promise<void> {
  updateLocalConvSetting(currentUserId, conversationId, {
    disappearingDuration: duration,
  });

  try {
    const roomChannel = supabase.channel(`chat-room-${conversationId}`);
    roomChannel.send({
      type: 'broadcast',
      event: 'disappearing_duration_updated',
      payload: { conversationId, duration },
    });
  } catch {}
}

export async function clearChatForAll(conversationId: string, currentUserId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch('/api/chat/clear-all', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ conversationId }),
      });
    } catch {}
  }

  try {
    await supabase.from('messages').delete().eq('conversation_id', conversationId);
  } catch {}

  try {
    const roomChannel = supabase.channel(`chat-room-${conversationId}`);
    roomChannel.send({
      type: 'broadcast',
      event: 'chat_cleared_all',
      payload: { conversationId, clearedBy: currentUserId },
    });
  } catch {}
}

export async function setAutoDeleteChatDuration(
  conversationId: string,
  currentUserId: string,
  duration: AutoDeleteChatDuration
): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch('/api/chat/auto-delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ conversationId, duration }),
      });
    } catch {}
  }

  updateLocalConvSetting(currentUserId, conversationId, {
    autoDeleteChatDuration: duration,
    autoDeleteChatStartedAt: duration === '5m' ? new Date().toISOString() : null,
  });

  try {
    const roomChannel = supabase.channel(`chat-room-${conversationId}`);
    roomChannel.send({
      type: 'broadcast',
      event: 'auto_delete_chat_updated',
      payload: { conversationId, duration },
    });
  } catch {}
}

export async function setChatWallpaper(
  conversationId: string,
  currentUserId: string,
  wallpaper: string
): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.access_token) {
    try {
      await fetch('/api/chat/wallpaper', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ conversationId, wallpaper }),
      });
    } catch {}
  }

  updateLocalConvSetting(currentUserId, conversationId, {
    wallpaper,
  });
}

export async function createGroup(
  name: string,
  photoUrl: string | null,
  memberIds: string[]
): Promise<ConversationWithDetails> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) {
    throw new Error('Authentication required');
  }

  const res = await fetch('/api/chat/group', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session.access_token}`,
    },
    body: JSON.stringify({ name, photoUrl, memberIds }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to create group');
  }

  const groupData = await res.json();
  return {
    id: groupData.id,
    type: 'group',
    name: groupData.name,
    photo_url: groupData.photo_url,
    creator_id: groupData.creator_id,
    admin_ids: groupData.admin_ids || [],
    otherUser: {
      id: groupData.id,
      username: 'group',
      display_name: groupData.name,
      avatar_url: groupData.photo_url,
      created_at: new Date().toISOString(),
    },
    lastMessage: null,
    unreadCount: 0,
    isPinned: false,
    isMuted: false,
    disappearingDuration: 'off',
  };
}

export async function addGroupMember(groupId: string, userId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) return;

  await fetch(`/api/chat/group/${groupId}/members`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session.access_token}`,
    },
    body: JSON.stringify({ action: 'add', userId }),
  });
}

export async function removeGroupMember(groupId: string, userId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) return;

  await fetch(`/api/chat/group/${groupId}/members`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session.access_token}`,
    },
    body: JSON.stringify({ action: 'remove', userId }),
  });
}

export async function leaveGroup(groupId: string, userId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) return;

  await fetch(`/api/chat/group/${groupId}/members`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session.access_token}`,
    },
    body: JSON.stringify({ action: 'leave', userId }),
  });
}

export async function toggleChatMute(conversationId: string, currentUserId: string, isMuted: boolean): Promise<void> {
  updateLocalConvSetting(currentUserId, conversationId, {
    isMuted,
  });
}

export async function toggleChatPin(conversationId: string, currentUserId: string, isPinned: boolean): Promise<void> {
  updateLocalConvSetting(currentUserId, conversationId, {
    isPinned,
  });
}

export async function toggleStarMessage(messageId: string, currentUserId: string, isSaved: boolean): Promise<void> {
  const key = `nexa_starred_msgs_${currentUserId}`;
  try {
    let list: string[] = JSON.parse(localStorage.getItem(key) || '[]');
    if (isSaved) {
      list = list.filter((id) => id !== messageId);
    } else {
      if (!list.includes(messageId)) list.push(messageId);
    }
    localStorage.setItem(key, JSON.stringify(list));
  } catch {}
}

export async function getStarredMessages(currentUserId: string): Promise<Message[]> {
  const key = `nexa_starred_msgs_${currentUserId}`;
  try {
    const list: string[] = JSON.parse(localStorage.getItem(key) || '[]');
    if (list.length === 0) return [];

    const { data: rawMsgs } = await supabase
      .from('messages')
      .select('*, sender:profiles!sender_id(*)')
      .in('id', list);

    return (rawMsgs || []).map((m) => {
      const msg = mapDbMessageToClient(m);
      msg.is_saved = true;
      return msg;
    });
  } catch {
    return [];
  }
}

export async function markViewOnceViewed(messageId: string): Promise<void> {
  try {
    await supabase
      .from('messages')
      .update({ viewed_at: new Date().toISOString() })
      .eq('id', messageId)
      .is('viewed_at', null);
  } catch {}
}

export async function reportUserOrMessage(params: {
  reporterId: string;
  reportedUserId: string;
  messageId?: string;
  reason: string;
}): Promise<void> {
  try {
    await supabase.from('reports').insert({
      reporter_id: params.reporterId,
      reported_user_id: params.reportedUserId,
      message_id: params.messageId || null,
      reason: params.reason,
    });
  } catch {}
}
