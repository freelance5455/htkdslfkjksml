import { APP_CONFIG } from '../core/config';
export interface CreatorInfo { product:string; version:string; creator:string; apiVersion:string; buildMode:'local'|'production'; }
export async function getCreatorInfo():Promise<CreatorInfo>{
  try{const r=await fetch('/api/creator.json',{cache:'no-store'});if(r.ok){const j=await r.json();return {...j,buildMode:import.meta.env.PROD?'production':'local'};}}
  catch{/* local/offline fallback */}
  return {product:APP_CONFIG.product,version:APP_CONFIG.version,creator:APP_CONFIG.creator,apiVersion:APP_CONFIG.apiVersion,buildMode:import.meta.env.PROD?'production':'local'};
}
