export interface DeviceCapability {
  maxTextureSize: number;
  maxRenderbufferSize: number;
  hardwareConcurrency: number;
  deviceMemoryGb?: number;
  supports4K: boolean;
  supports8K: boolean;
  recommendedMaxResolution: '720p' | '1080p' | '1440p' | '4k' | '8k';
  gpuRenderer: string;
  notes: {
    en: string;
    hi: string;
  };
}

let cachedCapability: DeviceCapability | null = null;

export function inspectDeviceHardware(): DeviceCapability {
  if (cachedCapability) return cachedCapability;

  let maxTexture = 4096;
  let maxRender = 4096;
  let renderer = 'Standard Mobile/Browser GPU';

  try {
    const canvas = document.createElement('canvas');
    const gl = (canvas.getContext('webgl2') || canvas.getContext('webgl')) as WebGLRenderingContext | null;
    if (gl) {
      maxTexture = gl.getParameter(gl.MAX_TEXTURE_SIZE) || 4096;
      maxRender = gl.getParameter(gl.MAX_RENDERBUFFER_SIZE) || 4096;
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || renderer;
      }
    }
  } catch (e) {
    console.warn('WebGL capability probe error:', e);
  }

  const memory = (navigator as unknown as { deviceMemory?: number }).deviceMemory;
  const cores = navigator.hardwareConcurrency || 4;

  // 8K requires at least 8192px texture/renderbuffer support and adequate memory/cores
  // 7680 x 4320 = ~33 million pixels
  const canPhysicallyHandle8K = maxTexture >= 8192 && maxRender >= 8192 && (memory ? memory >= 6 : true);
  const canPhysicallyHandle4K = maxTexture >= 4096 && maxRender >= 4096;

  let recommended: '720p' | '1080p' | '1440p' | '4k' | '8k' = '1080p';
  if (canPhysicallyHandle8K && (memory ? memory >= 8 : true) && cores >= 8) {
    recommended = '4k'; // 4K is recommended standard for high-end; 8K available
  } else if (canPhysicallyHandle4K) {
    recommended = '1080p';
  } else {
    recommended = '720p';
  }

  let notes = {
    en: `Device GPU supports up to ${maxTexture}px texture canvas. 1080p and 4K ready.`,
    hi: `डिवाइस GPU अधिकतम ${maxTexture}px टेक्सचर को सपोर्ट करता है। 1080p और 4K सक्षम है।`
  };

  if (!canPhysicallyHandle8K) {
    notes = {
      en: `Hardware limit (${maxTexture}px buffer): Native 8K (7680x4320) is disabled to prevent browser crashes. 1080p/4K is optimized.`,
      hi: `हार्डवेयर सीमा (${maxTexture}px): क्रैश से बचने के लिए वास्तविक 8K अक्षम है। 1080p/4K सुचारू रूप से कार्य करेगा।`
    };
  }

  cachedCapability = {
    maxTextureSize: maxTexture,
    maxRenderbufferSize: maxRender,
    hardwareConcurrency: cores,
    deviceMemoryGb: memory,
    supports4K: canPhysicallyHandle4K,
    supports8K: canPhysicallyHandle8K,
    recommendedMaxResolution: recommended,
    gpuRenderer: renderer,
    notes,
  };

  return cachedCapability;
}

export function isResolutionSupported(res: string): { supported: boolean; warning?: string } {
  const cap = inspectDeviceHardware();
  if (res === '8k') {
    if (!cap.supports8K) {
      return {
        supported: false,
        warning: 'This device hardware does not support 8K (requires 8192px GPU buffers and 6GB+ RAM). Recommended: 1080p or 4K.'
      };
    }
    return {
      supported: true,
      warning: '8K export will consume significant RAM and processing time. Ensure device is plugged in.'
    };
  }
  if (res === '4k') {
    if (!cap.supports4K) {
      return {
        supported: false,
        warning: 'Device GPU limits prevent native 4K canvas rendering. Please use 1080p.'
      };
    }
  }
  return { supported: true };
}
