// Speech Recognition and Text-To-Speech Service

export interface SpeechRecognitionHandlers {
  onStart?: () => void;
  onEnd?: () => void;
  onResult?: (transcript: string) => void;
  onError?: (error: string) => void;
  onVolume?: (rms: number) => void;
}

class SpeechService {
  private recognition: any = null;
  private isListening: boolean = false;
  private audioStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private volumeInterval: any = null;

  public isSpeaking: boolean = false;
  public autoSpeak: boolean = true;
  public speechRate: number = 0.95;
  public speechPitch: number = 1.05;

  // Check support
  hasRecognition(): boolean {
    if (typeof window === 'undefined') return false;
    return Boolean(
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    );
  }

  hasSynthesis(): boolean {
    if (typeof window === 'undefined') return false;
    return 'speechSynthesis' in window;
  }

  // Start Voice Listening
  async startListening(
    language: 'bn' | 'en',
    handlers: SpeechRecognitionHandlers
  ): Promise<boolean> {
    if (!this.hasRecognition()) {
      handlers.onError?.('Speech recognition is not supported in this browser. Please use Chrome/Edge or an Android browser.');
      return false;
    }

    this.stopListening();
    this.stopSpeaking();

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    this.recognition = new SpeechRec();
    this.recognition.continuous = false;
    this.recognition.interimResults = false;
    this.recognition.maxAlternatives = 1;
    this.recognition.lang = language === 'bn' ? 'bn-BD' : 'en-US';

    this.recognition.onstart = () => {
      this.isListening = true;
      handlers.onStart?.();
    };

    this.recognition.onresult = (event: any) => {
      if (event.results && event.results.length > 0) {
        const transcript = event.results[0][0]?.transcript || '';
        if (transcript.trim()) {
          handlers.onResult?.(transcript);
        }
      }
    };

    this.recognition.onerror = (event: any) => {
      this.isListening = false;
      this.stopVolumeMonitoring();
      let errorMsg = 'Microphone listening paused.';
      if (event.error === 'not-allowed') {
        errorMsg = 'Microphone access denied. Please allow microphone permission in browser settings.';
      } else if (event.error === 'no-speech') {
        errorMsg = 'No speech detected. Please speak closer to microphone.';
      } else if (event.error === 'network') {
        errorMsg = 'Speech recognition network error.';
      }
      handlers.onError?.(errorMsg);
    };

    this.recognition.onend = () => {
      this.isListening = false;
      this.stopVolumeMonitoring();
      handlers.onEnd?.();
    };

    try {
      // Start microphone stream for live RMS waveform visualization
      if (navigator.mediaDevices?.getUserMedia) {
        try {
          this.audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
          this.audioContext = new AudioCtx();
          const source = this.audioContext.createMediaStreamSource(this.audioStream);
          this.analyser = this.audioContext.createAnalyser();
          this.analyser.fftSize = 64;
          source.connect(this.analyser);

          const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
          this.volumeInterval = setInterval(() => {
            if (this.analyser && this.isListening) {
              this.analyser.getByteFrequencyData(dataArray);
              let sum = 0;
              for (let i = 0; i < dataArray.length; i++) {
                sum += dataArray[i];
              }
              const average = sum / dataArray.length;
              const rms = Math.min(1, Math.max(0, average / 128));
              handlers.onVolume?.(rms);
            }
          }, 80);
        } catch {
          // Fallback if media stream fails
        }
      }

      this.recognition.start();
      return true;
    } catch (err: any) {
      handlers.onError?.(err?.message || 'Failed to start microphone');
      return false;
    }
  }

  stopListening() {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {
        // ignore
      }
      this.recognition = null;
    }
    this.isListening = false;
    this.stopVolumeMonitoring();
  }

  private stopVolumeMonitoring() {
    if (this.volumeInterval) {
      clearInterval(this.volumeInterval);
      this.volumeInterval = null;
    }
    if (this.audioStream) {
      this.audioStream.getTracks().forEach((track) => track.stop());
      this.audioStream = null;
    }
    if (this.audioContext) {
      try {
        this.audioContext.close();
      } catch {
        // ignore
      }
      this.audioContext = null;
    }
  }

  // Text To Speech
  speak(
    text: string,
    onStart?: () => void,
    onEnd?: () => void
  ) {
    if (!this.hasSynthesis()) return;
    this.stopSpeaking();

    // Clean markdown symbols for natural speech pronunciation
    const cleanText = text
      .replace(/[*#_`~>]/g, '')
      .replace(/\[.*?\]\(.*?\)/g, '')
      .replace(/\(.*?\)/g, '')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    const isBengali = /[\u0980-\u09FF]/.test(cleanText);

    // Pick suitable voice
    const voices = window.speechSynthesis.getVoices();
    if (isBengali) {
      utterance.lang = 'bn-BD';
      const bnVoice = voices.find(
        (v) => v.lang.startsWith('bn') || v.name.toLowerCase().includes('bangla') || v.name.toLowerCase().includes('bengali')
      );
      if (bnVoice) utterance.voice = bnVoice;
    } else {
      utterance.lang = 'en-US';
      const enVoice = voices.find(
        (v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha'))
      );
      if (enVoice) utterance.voice = enVoice;
    }

    utterance.rate = this.speechRate;
    utterance.pitch = this.speechPitch;

    utterance.onstart = () => {
      this.isSpeaking = true;
      onStart?.();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      onEnd?.();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      onEnd?.();
    };

    try {
      window.speechSynthesis.speak(utterance);
    } catch {
      this.isSpeaking = false;
      onEnd?.();
    }
  }

  stopSpeaking() {
    if (this.hasSynthesis()) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking = false;
  }
}

export const speechService = new SpeechService();
