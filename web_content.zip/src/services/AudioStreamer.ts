/**
 * AudioStreamer - Handles gapless playback of 24kHz 16-bit PCM audio chunks
 * streamed from Gemini Live API, with instant interruption and frequency analysis.
 */
export class AudioStreamer {
  private audioCtx: AudioContext | null = null;
  private analyserNode: AnalyserNode | null = null;
  private nextStartTime = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private isTurnComplete = false;
  private onSpeakingStateChange?: (isSpeaking: boolean) => void;

  constructor(onSpeakingStateChange?: (isSpeaking: boolean) => void) {
    this.onSpeakingStateChange = onSpeakingStateChange;
  }

  async init(): Promise<void> {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      try {
        this.audioCtx = new AudioCtxClass({ sampleRate: 24000 });
      } catch {
        this.audioCtx = new AudioCtxClass();
      }

      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 128;
      this.analyserNode.smoothingTimeConstant = 0.6;
      this.analyserNode.connect(this.audioCtx.destination);
    }

    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }
  }

  /**
   * Enqueue a 24kHz 16-bit PCM chunk (base64)
   */
  async playChunk(base64Data: string): Promise<void> {
    await this.init();
    if (!this.audioCtx || !this.analyserNode) return;

    try {
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert bytes to Int16Array
      const int16Array = new Int16Array(bytes.buffer, bytes.byteOffset, bytes.byteLength / 2);
      if (int16Array.length === 0) return;

      // Convert to Float32
      const float32Array = new Float32Array(int16Array.length);
      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 32768;
      }

      // Create audio buffer at 24000 Hz
      const audioBuffer = this.audioCtx.createBuffer(1, float32Array.length, 24000);
      audioBuffer.getChannelData(0).set(float32Array);

      const source = this.audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.analyserNode);

      const currentTime = this.audioCtx.currentTime;
      // If nextStartTime has fallen behind or is not started, schedule just slightly in the future (30ms)
      if (this.nextStartTime < currentTime) {
        this.nextStartTime = currentTime + 0.03;
      }

      source.start(this.nextStartTime);
      this.nextStartTime += audioBuffer.duration;

      this.activeSources.push(source);
      this.onSpeakingStateChange?.(true);

      source.onended = () => {
        const idx = this.activeSources.indexOf(source);
        if (idx !== -1) {
          this.activeSources.splice(idx, 1);
        }

        if (this.activeSources.length === 0) {
          this.onSpeakingStateChange?.(false);
        }
      };
    } catch (err) {
      console.error('Failed to decode or play audio chunk:', err);
    }
  }

  setTurnComplete() {
    this.isTurnComplete = true;
  }

  /**
   * Immediately stops all playing and queued audio
   */
  interrupt() {
    for (const source of this.activeSources) {
      try {
        source.stop();
        source.disconnect();
      } catch {}
    }
    this.activeSources = [];
    this.nextStartTime = 0;
    this.isTurnComplete = false;
    this.onSpeakingStateChange?.(false);
  }

  getOutputLevel(): number {
    if (!this.analyserNode || this.activeSources.length === 0) return 0;
    const dataArray = new Uint8Array(this.analyserNode.frequencyBinCount);
    this.analyserNode.getByteFrequencyData(dataArray);
    let sum = 0;
    for (let i = 0; i < dataArray.length; i++) {
      sum += dataArray[i];
    }
    const avg = sum / dataArray.length;
    return Math.min(1, avg / 128);
  }

  getFrequencyData(outputArray: Uint8Array): void {
    if (!this.analyserNode || this.activeSources.length === 0) {
      outputArray.fill(0);
      return;
    }
    this.analyserNode.getByteFrequencyData(outputArray as any);
  }

  isSpeaking(): boolean {
    return this.activeSources.length > 0;
  }

  stop() {
    this.interrupt();
    if (this.audioCtx) {
      try {
        this.audioCtx.close();
      } catch {}
      this.audioCtx = null;
      this.analyserNode = null;
    }
  }
}
