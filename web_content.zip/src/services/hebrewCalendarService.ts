import {
  HDate,
  HebrewCalendar,
  Location,
  Zmanim,
  flags,
  Sedra,
  months,
} from '@hebcal/core';
import {
  CalendarDay,
  HebrewEvent,
  HolidayItem,
  LocationPreset,
  UserSettings,
  ZmanItem,
} from '../types';

export const LOCATION_PRESETS: LocationPreset[] = [
  {
    id: 'jerusalem',
    name: 'Jerusalem',
    nameHe: 'ירושלים',
    country: 'Israel',
    lat: 31.7683,
    long: 35.2137,
    elevation: 800,
    timezone: 'Asia/Jerusalem',
    isIsrael: true,
    candleLightingOffset: 40, // Jerusalem custom (40 mins)
  },
  {
    id: 'tel-aviv',
    name: 'Tel Aviv',
    nameHe: 'תל אביב',
    country: 'Israel',
    lat: 32.0853,
    long: 34.7818,
    elevation: 20,
    timezone: 'Asia/Jerusalem',
    isIsrael: true,
    candleLightingOffset: 20,
  },
  {
    id: 'safed',
    name: 'Tzfat (Safed)',
    nameHe: 'צפת',
    country: 'Israel',
    lat: 32.9646,
    long: 35.496,
    elevation: 840,
    timezone: 'Asia/Jerusalem',
    isIsrael: true,
    candleLightingOffset: 30,
  },
  {
    id: 'new-york',
    name: 'New York (Brooklyn / Manhattan)',
    nameHe: 'ניו יורק',
    country: 'USA',
    lat: 40.7128,
    long: -74.006,
    elevation: 10,
    timezone: 'America/New_York',
    isIsrael: false,
    candleLightingOffset: 18,
  },
  {
    id: 'lakewood',
    name: 'Lakewood, NJ',
    nameHe: 'לייקווד',
    country: 'USA',
    lat: 40.0979,
    long: -74.2177,
    elevation: 15,
    timezone: 'America/New_York',
    isIsrael: false,
    candleLightingOffset: 18,
  },
  {
    id: 'los-angeles',
    name: 'Los Angeles, CA',
    nameHe: 'לוס אנג׳לס',
    country: 'USA',
    lat: 34.0522,
    long: -118.2437,
    elevation: 70,
    timezone: 'America/Los_Angeles',
    isIsrael: false,
    candleLightingOffset: 18,
  },
  {
    id: 'miami',
    name: 'Miami, FL',
    nameHe: 'מיאמי',
    country: 'USA',
    lat: 25.7617,
    long: -80.1918,
    elevation: 2,
    timezone: 'America/New_York',
    isIsrael: false,
    candleLightingOffset: 18,
  },
  {
    id: 'chicago',
    name: 'Chicago, IL',
    nameHe: 'שיקגו',
    country: 'USA',
    lat: 41.8781,
    long: -87.6298,
    elevation: 180,
    timezone: 'America/Chicago',
    isIsrael: false,
    candleLightingOffset: 18,
  },
  {
    id: 'london',
    name: 'London',
    nameHe: 'לונדון',
    country: 'UK',
    lat: 51.5074,
    long: -0.1278,
    elevation: 15,
    timezone: 'Europe/London',
    isIsrael: false,
    candleLightingOffset: 18,
  },
  {
    id: 'paris',
    name: 'Paris',
    nameHe: 'פריז',
    country: 'France',
    lat: 48.8566,
    long: 2.3522,
    elevation: 35,
    timezone: 'Europe/Paris',
    isIsrael: false,
    candleLightingOffset: 18,
  },
  {
    id: 'toronto',
    name: 'Toronto',
    nameHe: 'טורונטו',
    country: 'Canada',
    lat: 43.6532,
    long: -79.3832,
    elevation: 75,
    timezone: 'America/Toronto',
    isIsrael: false,
    candleLightingOffset: 18,
  },
];

export const HEBREW_MONTH_NAMES_LIST = [
  { num: months.NISAN, name: 'Nisan', nameHe: 'נִיסָן' },
  { num: months.IYYAR, name: 'Iyyar', nameHe: 'אִיָּר' },
  { num: months.SIVAN, name: 'Sivan', nameHe: 'סִיוָן' },
  { num: months.TAMUZ, name: 'Tammuz', nameHe: 'תַּמּוּז' },
  { num: months.AV, name: 'Av', nameHe: 'אָב' },
  { num: months.ELUL, name: 'Elul', nameHe: 'אֱלוּל' },
  { num: months.TISHREI, name: 'Tishrei', nameHe: 'תִּשְׁרֵי' },
  { num: months.CHESHVAN, name: 'Cheshvan', nameHe: 'חֶשְׁוָן' },
  { num: months.KISLEV, name: 'Kislev', nameHe: 'כִּסְלֵו' },
  { num: months.TEVET, name: 'Tevet', nameHe: 'טֵבֵת' },
  { num: months.SHVAT, name: 'Shevat', nameHe: 'שְׁבָט' },
  { num: months.ADAR_I, name: 'Adar I', nameHe: 'אֲדָר א׳' },
  { num: months.ADAR_II, name: 'Adar II (or Adar)', nameHe: 'אֲדָר ב׳ / אֲדָר' },
];

export function getHebcalLocation(loc: LocationPreset): Location {
  return new Location(
    loc.lat,
    loc.long,
    loc.isIsrael,
    loc.timezone,
    loc.name,
    loc.country === 'Israel' ? 'IL' : 'US',
    loc.elevation
  );
}

export function formatTime24(date: Date | null | undefined): string {
  if (!date || isNaN(date.getTime())) return '--:--';
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
}

export function formatTime12(date: Date | null | undefined): string {
  if (!date || isNaN(date.getTime())) return '--:--';
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true });
}

/**
 * Convert Hebrew number to Gematriya letters
 */
export function getHebrewNumberGematriya(n: number): string {
  const letters: [number, string][] = [
    [400, 'ת'],
    [300, 'ש'],
    [200, 'ר'],
    [100, 'ק'],
    [90, 'צ'],
    [80, 'פ'],
    [70, 'ע'],
    [60, 'ס'],
    [50, 'נ'],
    [40, 'מ'],
    [30, 'ל'],
    [20, 'כ'],
    [10, 'י'],
    [9, 'ט'],
    [8, 'ח'],
    [7, 'ז'],
    [6, 'ו'],
    [5, 'ה'],
    [4, 'ד'],
    [3, 'ג'],
    [2, 'ב'],
    [1, 'א'],
  ];

  let num = n;
  let str = '';

  // Special cases for 15 and 16 to avoid God's name
  if (num === 15) return 'ט״ו';
  if (num === 16) return 'ט״ז';

  for (const [val, letter] of letters) {
    while (num >= val) {
      str += letter;
      num -= val;
    }
  }

  // Format with Gershayim or Geresh
  if (str.length === 1) {
    return str + '׳';
  } else if (str.length > 1) {
    return str.slice(0, -1) + '״' + str.slice(-1);
  }
  return str;
}

export function getHebrewYearGematriya(year: number): string {
  const shortYear = year % 1000; // e.g. 5786 -> 786
  return getHebrewNumberGematriya(shortYear);
}

export function safeDate(val: any): Date | null {
  if (!val) return null;
  if (val instanceof Date) {
    return isNaN(val.getTime()) ? null : val;
  }
  if (typeof val.epochMilliseconds === 'number') {
    const d = new Date(val.epochMilliseconds);
    return isNaN(d.getTime()) ? null : d;
  }
  if (typeof val.toInstant === 'function') {
    try {
      const d = new Date(val.toInstant().epochMilliseconds);
      return isNaN(d.getTime()) ? null : d;
    } catch {
      // ignore
    }
  }
  if (typeof val.getTime === 'function') {
    try {
      const d = new Date(val.getTime());
      return isNaN(d.getTime()) ? null : d;
    } catch {
      return null;
    }
  }
  try {
    const d = new Date(val);
    return isNaN(d.getTime()) ? null : d;
  } catch {
    return null;
  }
}

/**
 * Calculates accurate Zmanim for a specific day and location
 */
export function calculateZmanim(
  date: Date,
  location: LocationPreset,
  options: {
    candleLightingOffset?: number;
    havdalahOpinion?: '8.5' | '42' | '50' | '72';
  } = {}
): {
  items: ZmanItem[];
  nextZman: ZmanItem | null;
  candleLighting: Date | null;
  havdalah: Date | null;
  sunrise: Date | null;
  sunset: Date | null;
  solarProgress: number; // 0 to 100 percentage of sun transit between sunrise and sunset
} {
  const hebLoc = getHebcalLocation(location);
  const zmanim = new Zmanim(hebLoc, date, true);

  const candleOffset = options.candleLightingOffset ?? location.candleLightingOffset ?? 18;
  const havdalahChoice = options.havdalahOpinion ?? '8.5';

  const alot = safeDate(zmanim.alotHaShachar());
  const misheyakir = safeDate(zmanim.misheyakir());
  const sunrise = safeDate(zmanim.sunrise());
  const seaLevelSunrise = safeDate(zmanim.seaLevelSunrise());
  const shmaGra = safeDate(zmanim.sofZmanShma());
  const shmaMga = safeDate(zmanim.sofZmanShmaMGA());
  const tfillaGra = safeDate(zmanim.sofZmanTfilla());
  const tfillaMga = safeDate(zmanim.sofZmanTfillaMGA());
  const chatzot = safeDate(zmanim.chatzot());
  const minchaGedola = safeDate(zmanim.minchaGedola());
  const minchaKetana = safeDate(zmanim.minchaKetana());
  const plagHaMincha = safeDate(zmanim.plagHaMincha());
  const sunset = safeDate(zmanim.sunset());
  const seaLevelSunset = safeDate(zmanim.seaLevelSunset());
  const tzeit = safeDate(zmanim.tzeit()); // 8.5 degrees
  const tzeit72 = safeDate(zmanim.tzeit72()) || (sunset ? new Date(sunset.getTime() + 72 * 60 * 1000) : null);
  const chatzotNight = safeDate(zmanim.chatzotNight());

  // Havdalah calculation
  let havdalah: Date | null = null;
  if (havdalahChoice === '8.5') {
    havdalah = tzeit;
  } else if (havdalahChoice === '42' && sunset) {
    havdalah = new Date(sunset.getTime() + 42 * 60 * 1000);
  } else if (havdalahChoice === '50' && sunset) {
    havdalah = new Date(sunset.getTime() + 50 * 60 * 1000);
  } else if (havdalahChoice === '72' && sunset) {
    havdalah = new Date(sunset.getTime() + 72 * 60 * 1000);
  } else {
    havdalah = tzeit;
  }

  // Candle lighting is typically offset minutes before sunset
  let candleLighting: Date | null = null;
  if (sunset) {
    candleLighting = new Date(sunset.getTime() - candleOffset * 60 * 1000);
  }

  const now = new Date();
  const isSameDay =
    now.getFullYear() === date.getFullYear() &&
    now.getMonth() === date.getMonth() &&
    now.getDate() === date.getDate();

  const zmanimList: Array<{
    id: string;
    title: string;
    hebrewTitle: string;
    description: string;
    time: Date | null;
    category: 'dawn' | 'morning' | 'noon' | 'afternoon' | 'evening' | 'night';
    highlight?: boolean;
  }> = [
    {
      id: 'alot',
      title: 'Alot HaShachar (Dawn - 16.1°)',
      hebrewTitle: 'עֲלוֹת הַשַּׁחַר',
      description: 'First rays of dawn appear; start of Halachic fasts',
      time: alot,
      category: 'dawn',
    },
    {
      id: 'misheyakir',
      title: 'Misheyakir (Earliest Tallit & Tefillin)',
      hebrewTitle: 'מִשֶּׁיַּכִּיר',
      description: 'When one can recognize a companion at 4 cubits',
      time: misheyakir,
      category: 'dawn',
    },
    {
      id: 'sunrise',
      title: 'Netz HaChama (Sunrise)',
      hebrewTitle: 'נֵץ הַחַמָּה',
      description: 'Sun emerges above horizon; ideal time for Vatikin Shacharit',
      time: sunrise,
      category: 'morning',
      highlight: true,
    },
    {
      id: 'shma_mga',
      title: 'Sof Zman Kriat Shema (MGA)',
      hebrewTitle: 'סוֹף זְמַן קְרִיאַת שְׁמַע (מג״א)',
      description: 'Latest time for Morning Shema according to Magen Avraham',
      time: shmaMga,
      category: 'morning',
    },
    {
      id: 'shma_gra',
      title: 'Sof Zman Kriat Shema (GRA / Baal HaTanya)',
      hebrewTitle: 'סוֹף זְמַן קְרִיאַת שְׁמַע (גר״א)',
      description: 'Latest time for Morning Shema according to the Vilna Gaon',
      time: shmaGra,
      category: 'morning',
      highlight: true,
    },
    {
      id: 'tfilla_mga',
      title: 'Sof Zman Tefillah (MGA)',
      hebrewTitle: 'סוֹף זְמַן תְּפִלָּה (מג״א)',
      description: 'Latest time for Shacharit Amidah according to MGA',
      time: tfillaMga,
      category: 'morning',
    },
    {
      id: 'tfilla_gra',
      title: 'Sof Zman Tefillah (GRA)',
      hebrewTitle: 'סוֹף זְמַן תְּפִלָּה (גר״א)',
      description: 'Latest time for Shacharit Amidah according to the GRA',
      time: tfillaGra,
      category: 'morning',
    },
    {
      id: 'chatzot',
      title: 'Chatzot HaYom (Midday)',
      hebrewTitle: 'חֲצוֹת הַיּוֹם',
      description: 'Astronomical noon; midpoint of daytime hours',
      time: chatzot,
      category: 'noon',
      highlight: true,
    },
    {
      id: 'mincha_gedola',
      title: 'Mincha Gedola (Earliest Mincha)',
      hebrewTitle: 'מִנְחָה גְּדוֹלָה',
      description: 'Earliest time to recite Mincha afternoon prayer (Chatzot + 0.5hr)',
      time: minchaGedola,
      category: 'afternoon',
    },
    {
      id: 'mincha_ketana',
      title: 'Mincha Ketana',
      hebrewTitle: 'מִנְחָה קְטַנָּה',
      description: 'Preferred window to pray Mincha (2.5 seasonal hours before sunset)',
      time: minchaKetana,
      category: 'afternoon',
    },
    {
      id: 'plag',
      title: 'Plag HaMincha',
      hebrewTitle: 'פְּלַג הַמִּנְחָה',
      description: '1.25 seasonal hours before sunset; earliest time for early Shabbat Kabbalat Shabbat',
      time: plagHaMincha,
      category: 'afternoon',
    },
    {
      id: 'sunset',
      title: 'Shkiah (Sunset)',
      hebrewTitle: 'שְׁקִיעַת הַחַמָּה',
      description: 'Sun sets below horizon; end of Hebrew daytime, start of Bein HaShmashot',
      time: sunset,
      category: 'evening',
      highlight: true,
    },
    {
      id: 'tzeit',
      title: 'Tzeit HaKochavim (Nightfall - 8.5°)',
      hebrewTitle: 'צֵאת הַכּוֹכָבִים (3 כוכבים)',
      description: 'Three medium stars appear; definitive start of the new Hebrew calendar day and evening prayers',
      time: tzeit,
      category: 'night',
      highlight: true,
    },
    {
      id: 'tzeit72',
      title: 'Tzeit HaKochavim (Rabbeinu Tam - 72 min)',
      hebrewTitle: 'צֵאת הַכּוֹכָבִים (רבנו תם)',
      description: 'Nightfall according to Rabbeinu Tam (72 minutes after sunset)',
      time: tzeit72,
      category: 'night',
    },
    {
      id: 'chatzot_night',
      title: 'Chatzot HaLayla (Midnight)',
      hebrewTitle: 'חֲצוֹת הַלַּיְלָה',
      description: 'Astronomical midnight; ideal for Tikkun Chatzot and Afikoman deadline',
      time: chatzotNight,
      category: 'night',
    },
  ];

  let nextZman: ZmanItem | null = null;
  let foundNext = false;

  const items: ZmanItem[] = zmanimList.map((z) => {
    const isPassed = isSameDay && z.time ? z.time.getTime() < now.getTime() : false;
    let isNext = false;
    let timeRemaining: string | undefined;

    if (isSameDay && z.time && !foundNext && z.time.getTime() >= now.getTime()) {
      isNext = true;
      foundNext = true;
      const diffMs = z.time.getTime() - now.getTime();
      const diffMins = Math.floor(diffMs / 60000);
      const hours = Math.floor(diffMins / 60);
      const mins = diffMins % 60;
      if (hours > 0) {
        timeRemaining = `in ${hours}h ${mins}m`;
      } else {
        timeRemaining = `in ${mins}m`;
      }
    }

    const item: ZmanItem = {
      ...z,
      formattedTime: formatTime12(z.time),
      isPassed,
      isNext,
      timeRemaining,
    };

    if (isNext) {
      nextZman = item;
    }

    return item;
  });

  // Calculate Solar Progress for UI arc visualization
  let solarProgress = 0;
  if (sunrise && sunset) {
    const totalDayMs = sunset.getTime() - sunrise.getTime();
    if (now.getTime() < sunrise.getTime()) {
      solarProgress = 0;
    } else if (now.getTime() > sunset.getTime()) {
      solarProgress = 100;
    } else {
      const elapsedMs = now.getTime() - sunrise.getTime();
      solarProgress = Math.min(100, Math.max(0, Math.round((elapsedMs / totalDayMs) * 100)));
    }
  }

  return {
    items,
    nextZman,
    candleLighting,
    havdalah,
    sunrise,
    sunset,
    solarProgress,
  };
}

/**
 * Returns complete CalendarDay representation with Hebrew date, holidays, Torah portion, Daf Yomi, and recurring events
 */
export function getCalendarDay(
  date: Date,
  location: LocationPreset,
  events: HebrewEvent[] = []
): CalendarDay {
  const hdate = new HDate(date);
  const now = new Date();
  const isToday =
    now.getFullYear() === date.getFullYear() &&
    now.getMonth() === date.getMonth() &&
    now.getDate() === date.getDate();

  const hebDayNum = hdate.getDate();
  const hebMonthNum = hdate.getMonth();
  const hebYearNum = hdate.getFullYear();
  const hebMonthName = hdate.getMonthName();

  // Hebrew names
  const hebDayLetters = getHebrewNumberGematriya(hebDayNum);
  const hebYearLetters = getHebrewYearGematriya(hebYearNum);
  const hebMonthObj = HEBREW_MONTH_NAMES_LIST.find((m) => m.num === hebMonthNum);
  const hebMonthNameHe = hebMonthObj ? hebMonthObj.nameHe : hebMonthName;

  const hebrewDateStr = `${hebDayNum} ${hebMonthName} ${hebYearNum}`;
  const hebrewDateStrHe = `${hebDayLetters} בְּ${hebMonthNameHe} ${hebYearLetters}`;

  // Check holidays from Hebcal
  const hebcalEvents = HebrewCalendar.getHolidaysOnDate(hdate, location.isIsrael) || [];
  const holidays: HolidayItem[] = [];

  let isRoshChodesh = false;
  let roshChodeshName: string | undefined;
  let isFastDay = false;
  let isYomTov = false;
  let isCholHamoed = false;
  let isMajorHoliday = false;
  let isMinorHoliday = false;

  for (const ev of hebcalEvents) {
    const desc = ev.render('en');
    const descHe = ev.render('he');
    const evFlags = ev.getFlags();

    let category: HolidayItem['category'] = 'minor';
    let emoji = '✡️';

    if (evFlags & flags.MAJOR_FAST || evFlags & flags.MINOR_FAST) {
      category = 'fast';
      isFastDay = true;
      emoji = '🕯️';
    } else if (evFlags & flags.ROSH_CHODESH) {
      category = 'roshchodesh';
      isRoshChodesh = true;
      roshChodeshName = desc;
      emoji = '🌙';
    } else if (evFlags & flags.CHAG) {
      category = 'major';
      isMajorHoliday = true;
      isYomTov = true;
      emoji = '🍷';
    } else if (evFlags & flags.CHOL_HAMOED) {
      category = 'major';
      isCholHamoed = true;
      emoji = '🌿';
    } else if (evFlags & flags.SPECIAL_SHABBAT) {
      category = 'special_shabbat';
      emoji = '✨';
    } else if (evFlags & flags.MODERN_HOLIDAY) {
      category = 'modern';
      emoji = '🇮🇱';
    } else {
      isMinorHoliday = true;
    }

    holidays.push({
      name: desc,
      hebrewName: descHe,
      category,
      emoji,
      description: ev.memo,
    });
  }

  // Parasha (Weekly Torah Reading)
  let parasha: CalendarDay['parasha'] = undefined;
  try {
    const sedra = new Sedra(hebYearNum, location.isIsrael);
    const lookupResult = sedra.lookup(hdate);
    if (lookupResult && lookupResult.parsha && lookupResult.parsha.length > 0) {
      const parshaEn = lookupResult.parsha.join(' - ');
      parasha = {
        name: `Parashat ${parshaEn}`,
        hebrewName: `פָּרָשַׁת ${parshaEn}`,
      };
    }
  } catch {
    // Sedra lookup exception fallback
  }

  // Omer count if applicable (16 Nisan through 5 Sivan)
  let omer: CalendarDay['omer'] = undefined;
  let omerDay = 0;
  if (hebMonthNum === 1 && hebDayNum >= 16) {
    omerDay = hebDayNum - 15; // 1 to 15 in Nisan
  } else if (hebMonthNum === 2) {
    omerDay = 15 + hebDayNum; // 16 to 44 in Iyyar
  } else if (hebMonthNum === 3 && hebDayNum <= 5) {
    omerDay = 44 + hebDayNum; // 45 to 49 in Sivan
  }

  if (omerDay > 0 && omerDay <= 49) {
    const weeks = Math.floor(omerDay / 7);
    const days = omerDay % 7;
    omer = {
      count: omerDay,
      weeks,
      days,
      textHe: `הַיּוֹם ${getHebrewNumberGematriya(omerDay)} יָמִים לָעוֹמֶר`,
    };
  }

  // Candle lighting & Havdalah for Friday / Saturday
  const dayOfWeek = date.getDay(); // 0=Sun, 5=Fri, 6=Sat
  const isErevShabbat = dayOfWeek === 5;
  const isShabbat = dayOfWeek === 6;

  const zmanimData = calculateZmanim(date, location);
  let candleLighting: string | undefined;
  let havdalah: string | undefined;

  if (isErevShabbat || isMajorHoliday) {
    candleLighting = formatTime12(zmanimData.candleLighting);
  }
  if (isShabbat) {
    havdalah = formatTime12(zmanimData.havdalah);
  }

  // Filter matching personal recurring Hebrew events for this day!
  const rawMatchingEvents = getMatchingHebrewEvents(hdate, events);
  const matchingEvents = rawMatchingEvents.map((ev) => ({
    ...ev,
    displayTitle: getEventDisplayTitle(ev, hebYearNum),
    displayHebrewTitle: getEventDisplayHebrewTitle(ev, hebYearNum),
  }));

  const dateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(
    date.getDate()
  ).padStart(2, '0')}`;

  return {
    gregorianDate: date,
    dateKey,
    hebrewDateStr,
    hebrewDateStrHe,
    hebrewDay: hebDayNum,
    hebrewDayLetters: hebDayLetters,
    hebrewMonth: hebMonthNum,
    hebrewMonthName: hebMonthName,
    hebrewMonthNameHe: hebMonthNameHe,
    hebrewYear: hebYearNum,
    hebrewYearLetters: hebYearLetters,
    isShabbat,
    isErevShabbat,
    isRoshChodesh,
    roshChodeshName,
    isFastDay,
    isYomTov,
    isCholHamoed,
    isMajorHoliday,
    isMinorHoliday,
    holidays,
    parasha,
    omer,
    candleLighting,
    havdalah,
    events: matchingEvents,
    isToday,
    isSelected: false,
  };
}

/**
 * Returns formatted event title with occurrence/age counter if enabled
 * e.g., "Avi's Birthday (3)" or "Dad's Yahrzeit (5)"
 */
export function getEventDisplayTitle(event: HebrewEvent, currentHebrewYear?: number): string {
  if (!event.showCounter) return event.title;

  let count: number | undefined;
  if (event.startHebrewYear && currentHebrewYear) {
    const diff = currentHebrewYear - event.startHebrewYear;
    count = (event.counterStart !== undefined ? event.counterStart - 1 : 0) + diff;
    if (count < 0) count = 0;
  } else if (event.hebrewYear && currentHebrewYear) {
    const diff = currentHebrewYear - event.hebrewYear;
    count = (event.counterStart !== undefined ? event.counterStart - 1 : 0) + diff;
    if (count < 0) count = 0;
  } else if (event.counterStart !== undefined) {
    count = event.counterStart;
  }

  if (count !== undefined && count >= 0) {
    return `${event.title} (${count})`;
  }
  return event.title;
}

/**
 * Returns formatted Hebrew event title with occurrence counter if enabled
 */
export function getEventDisplayHebrewTitle(event: HebrewEvent, currentHebrewYear?: number): string | undefined {
  if (!event.hebrewTitle) return undefined;
  if (!event.showCounter) return event.hebrewTitle;

  let count: number | undefined;
  if (event.startHebrewYear && currentHebrewYear) {
    const diff = currentHebrewYear - event.startHebrewYear;
    count = (event.counterStart !== undefined ? event.counterStart - 1 : 0) + diff;
    if (count < 0) count = 0;
  } else if (event.hebrewYear && currentHebrewYear) {
    const diff = currentHebrewYear - event.hebrewYear;
    count = (event.counterStart !== undefined ? event.counterStart - 1 : 0) + diff;
    if (count < 0) count = 0;
  } else if (event.counterStart !== undefined) {
    count = event.counterStart;
  }

  if (count !== undefined && count >= 0) {
    return `${event.hebrewTitle} (${count})`;
  }
  return event.hebrewTitle;
}

/**
 * Checks if personal Hebrew event matches this specific Hebrew date
 */
export function getMatchingHebrewEvents(hdate: HDate, events: HebrewEvent[]): HebrewEvent[] {
  const currentDay = hdate.getDate();
  const currentMonth = hdate.getMonth();
  const isLeap = hdate.isLeapYear();

  return events.filter((ev) => {
    if (ev.recurrence === 'hebrew-monthly') {
      return ev.hebrewDay === currentDay;
    }

    if (ev.recurrence === 'hebrew-annual') {
      // Check repetition limit if specified
      if (ev.repeatCount && ev.repeatCount > 0) {
        const originYear = ev.startHebrewYear || ev.hebrewYear;
        if (originYear && (hdate.getFullYear() - originYear >= ev.repeatCount)) {
          return false;
        }
      }

      // Direct month and day match
      if (ev.hebrewDay === currentDay && ev.hebrewMonth === currentMonth) {
        return true;
      }

      // Handle Adar rules in Leap vs Non-Leap years
      // In a regular year: ADAR_I is months.ADAR_I (month 12)
      // In a leap year: ADAR_I is 12, ADAR_II is 13
      if (isLeap) {
        // Event was created in regular year (ADAR_I = 12)
        if (ev.hebrewMonth === months.ADAR_I) {
          if (ev.leapYearRule === 'adar2' && currentMonth === months.ADAR_II && ev.hebrewDay === currentDay) {
            return true;
          }
          if (ev.leapYearRule === 'adar1' && currentMonth === months.ADAR_I && ev.hebrewDay === currentDay) {
            return true;
          }
          if (ev.leapYearRule === 'both' && (currentMonth === months.ADAR_I || currentMonth === months.ADAR_II) && ev.hebrewDay === currentDay) {
            return true;
          }
        }
      } else {
        // In non-leap year, if event was set for Adar II, observe in single Adar
        if (ev.hebrewMonth === months.ADAR_II && currentMonth === months.ADAR_I && ev.hebrewDay === currentDay) {
          return true;
        }
      }

      // Handle 30 Cheshvan / 30 Kislev in short years (when month only has 29 days)
      if (ev.hebrewDay === 30) {
        if (ev.hebrewMonth === months.CHESHVAN && currentMonth === months.CHESHVAN && hdate.daysInMonth() === 29 && currentDay === 29) {
          return true;
        }
        if (ev.hebrewMonth === months.KISLEV && currentMonth === months.KISLEV && hdate.daysInMonth() === 29 && currentDay === 29) {
          return true;
        }
      }
    }

    if (ev.recurrence === 'once') {
      return (
        ev.hebrewDay === currentDay &&
        ev.hebrewMonth === currentMonth &&
        ev.hebrewYear === hdate.getFullYear()
      );
    }

    return false;
  });
}

export interface UpcomingHolidayCountdown {
  name: string;
  nameHe: string;
  holidayKey: string;
  gregorianDate: Date;
  daysRemaining: number;
}

export function getHolidayKey(nameEn: string = '', nameHe: string = ''): string {
  const en = nameEn.toLowerCase();
  const he = nameHe;

  if (en.includes('rosh hashana') || he.includes('ראש השנה')) return 'rosh_hashana';
  if (en.includes('kippur') || he.includes('כפור') || he.includes('כיפור')) return 'yom_kippur';
  if (
    en.includes('sukkot') ||
    en.includes('succot') ||
    en.includes('hoshana raba') ||
    en.includes('shemini atzeret') ||
    en.includes('simchat torah') ||
    he.includes('סוכות') ||
    he.includes('הושענא רבה') ||
    he.includes('שמיני עצרת') ||
    he.includes('שמחת תורה')
  ) {
    return 'sukkot';
  }
  if (en.includes('chanukah') || en.includes('hanukkah') || he.includes('חנוכה')) return 'chanukah';
  if (en.includes('purim') || he.includes('פורים')) return 'purim';
  if (en.includes('pesach') || en.includes('passover') || he.includes('פסח')) return 'pesach';
  if (en.includes('shavuot') || en.includes('shavuos') || he.includes('שבועות')) return 'shavuot';
  if (en.includes('gedaliah') || he.includes('גדליה')) return 'fast_gedaliah';
  if (en.includes('tevet') || he.includes('טבת')) return 'asara_btevet';
  if (en.includes('esther') || he.includes('אסתר')) return 'taanit_esther';
  if (en.includes('tammuz') || he.includes('תמוז')) return 'tammuz';
  if (en.includes('tish\'a b\'av') || en.includes('tisha b\'av') || he.includes('תשעה באב')) return 'tisha_bav';
  if (en.includes('shvat') || he.includes('שבט')) return 'tu_bishvat';
  if (en.includes('baomer') || he.includes('בעומר')) return 'lag_baomer';

  return en.replace(/[^a-z0-9]/g, '_');
}

export function isDayAssociatedWithUpcomingHoliday(
  day: CalendarDay,
  upcomingHoliday: UpcomingHolidayCountdown | null
): boolean {
  if (!upcomingHoliday) return false;

  const isSameDate =
    day.gregorianDate.getFullYear() === upcomingHoliday.gregorianDate.getFullYear() &&
    day.gregorianDate.getMonth() === upcomingHoliday.gregorianDate.getMonth() &&
    day.gregorianDate.getDate() === upcomingHoliday.gregorianDate.getDate();
  if (isSameDate) return true;

  if (upcomingHoliday.holidayKey && day.holidays && day.holidays.length > 0) {
    return day.holidays.some((h) => {
      const hKey = getHolidayKey(h.name, h.hebrewName);
      return hKey === upcomingHoliday.holidayKey;
    });
  }

  return false;
}

export function getNextHebrewHolidayCountdown(startDate: Date, isIsrael: boolean = true): UpcomingHolidayCountdown | null {
  const current = new Date(startDate);
  current.setHours(0, 0, 0, 0);

  // Scan up to 370 days forward
  for (let i = 0; i < 370; i++) {
    const scanDate = new Date(current);
    scanDate.setDate(current.getDate() + i);

    const hdate = new HDate(scanDate);
    const events = HebrewCalendar.getHolidaysOnDate(hdate, isIsrael) || [];

    for (const ev of events) {
      const flags_val = ev.getFlags();
      // Look for Chag (major holiday) or major/minor fast, Rosh Hashanah, Yom Kippur, Pesach, Sukkot, Shavuot, Hanukkah, Purim
      const isChag = (flags_val & flags.CHAG) !== 0;
      const isFast = (flags_val & flags.MAJOR_FAST) !== 0 || (flags_val & flags.MINOR_FAST) !== 0;
      const desc = ev.render('en');
      const isHanukkahOrPurim = desc.toLowerCase().includes('chanukah') || desc.toLowerCase().includes('purim') || desc.toLowerCase().includes('hanukkah');

      if (isChag || isFast || isHanukkahOrPurim) {
        // Prevent including candle lighting event names, just the holiday itself
        if (desc.toLowerCase().includes('candle lighting') || desc.toLowerCase().includes('erev')) {
          continue;
        }
        const name = ev.render('en');
        const nameHe = ev.render('he');
        const holidayKey = getHolidayKey(name, nameHe);
        return {
          name,
          nameHe,
          holidayKey,
          gregorianDate: scanDate,
          daysRemaining: i,
        };
      }
    }
  }
  return null;
}

/**
 * Calculates upcoming Gregorian occurrences of a Hebrew Event for the next N years
 */
export function getUpcomingHebrewEventOccurrences(
  event: HebrewEvent,
  yearsCount: number = 6
): Array<{
  hebrewYear: number;
  hebrewDateStr: string;
  gregorianDate: Date;
  daysUntil: number;
}> {
  const currentHDate = new HDate();
  const currentHebrewYear = currentHDate.getFullYear();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const results: Array<{
    hebrewYear: number;
    hebrewDateStr: string;
    gregorianDate: Date;
    daysUntil: number;
  }> = [];

  for (let i = 0; i < yearsCount; i++) {
    const targetHebYear = currentHebrewYear + i;

    // If event has a repeat limit and start year, check if exceeded
    if (event.repeatCount && event.repeatCount > 0) {
      const originYear = event.startHebrewYear || event.hebrewYear;
      if (originYear && (targetHebYear - originYear >= event.repeatCount)) {
        continue;
      }
    }

    const isLeap = new HDate(1, months.TISHREI, targetHebYear).isLeapYear();

    let targetMonth = event.hebrewMonth;
    if (isLeap) {
      if (event.hebrewMonth === months.ADAR_I && event.leapYearRule === 'adar2') {
        targetMonth = months.ADAR_II;
      }
    } else {
      if (event.hebrewMonth === months.ADAR_II) {
        targetMonth = months.ADAR_I;
      }
    }

    let targetDay = event.hebrewDay;
    const daysInTargetMonth = new HDate(1, targetMonth, targetHebYear).daysInMonth();
    if (targetDay > daysInTargetMonth) {
      targetDay = daysInTargetMonth;
    }

    try {
      const occurrenceHDate = new HDate(targetDay, targetMonth, targetHebYear);
      const greg = occurrenceHDate.greg();
      greg.setHours(0, 0, 0, 0);

      const diffMs = greg.getTime() - today.getTime();
      const daysUntil = Math.round(diffMs / (1000 * 60 * 60 * 24));

      if (daysUntil >= 0) {
        results.push({
          hebrewYear: targetHebYear,
          hebrewDateStr: occurrenceHDate.render('en'),
          gregorianDate: greg,
          daysUntil,
        });
      }
    } catch {
      // Ignore conversion errors
    }
  }

  return results;
}

/**
 * Generate full Gregorian Month calendar matrix (with leading and trailing days from previous/next months)
 */
export function getMonthDays(
  year: number,
  month: number, // 0 = Jan, 11 = Dec
  location: LocationPreset,
  events: HebrewEvent[] = []
): CalendarDay[] {
  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);

  const startDayOfWeek = firstDayOfMonth.getDay(); // 0 = Sunday
  const daysInMonth = lastDayOfMonth.getDate();

  const days: CalendarDay[] = [];

  // Previous month padding days
  for (let i = startDayOfWeek - 1; i >= 0; i--) {
    const prevDate = new Date(year, month, -i);
    days.push(getCalendarDay(prevDate, location, events));
  }

  // Current month days
  for (let day = 1; day <= daysInMonth; day++) {
    const currDate = new Date(year, month, day);
    days.push(getCalendarDay(currDate, location, events));
  }

  // Next month padding days to complete 35 or 42 grid slots
  const remaining = (7 - (days.length % 7)) % 7;
  for (let i = 1; i <= remaining; i++) {
    const nextDate = new Date(year, month + 1, i);
    days.push(getCalendarDay(nextDate, location, events));
  }

  return days;
}

/**
 * Generate 7 days of the week containing the specified date
 */
export function getWeekDays(
  date: Date,
  location: LocationPreset,
  events: HebrewEvent[] = []
): CalendarDay[] {
  const dayOfWeek = date.getDay(); // 0 = Sunday
  const startOfWeek = new Date(date);
  startOfWeek.setDate(date.getDate() - dayOfWeek);

  const days: CalendarDay[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(startOfWeek);
    d.setDate(startOfWeek.getDate() + i);
    days.push(getCalendarDay(d, location, events));
  }
  return days;
}

/**
 * Two-way conversion utilities
 */
export function convertGregorianToHebrew(date: Date) {
  const hdate = new HDate(date);
  return {
    hdate,
    day: hdate.getDate(),
    month: hdate.getMonth(),
    monthName: hdate.getMonthName(),
    year: hdate.getFullYear(),
    renderedEn: hdate.render('en'),
    renderedHe: hdate.render('he'),
    gematriyaDay: getHebrewNumberGematriya(hdate.getDate()),
    gematriyaYear: getHebrewYearGematriya(hdate.getFullYear()),
  };
}

export function convertHebrewToGregorian(day: number, month: number, year: number): Date {
  const hdate = new HDate(day, month, year);
  return hdate.greg();
}

export const DEFAULT_SETTINGS: UserSettings = {
  language: 'en',
  location: LOCATION_PRESETS[0], // Jerusalem
  useGps: false,
  theme: 'dark',
  darkMode: true,
  viewMode: 'month',
  candleLightingOffset: 40,
  havdalahOpinion: '42',
  notifications: {
    enabled: true,
    shabbatCandles: true,
    shabbatMinutesBefore: 18,
    holidays: true,
    dailyVerse: true,
    dailyVerseTime: '08:00',
    zmanimAlerts: false,
    personalEvents: true,
  },
  homeWidget: {
    style: 'compact',
    showNextZman: true,
    showDailyVerse: true,
    floatingPinned: false,
  },
  display: {
    showDafYomi: true,
    showOmer: true,
    showParasha: true,
    showHebrewGematriya: true,
    showSecularDates: true,
  },
  zmanim: {
    shabbatOffset: 40,
    havdalahOpinion: '42',
    useElevation: true,
    opinion: 'gra',
  },
};

export const getCalendarMonthDays = getMonthDays;
export const getCalendarWeekDays = getWeekDays;

export const DEFAULT_SAMPLE_EVENTS: HebrewEvent[] = [];

