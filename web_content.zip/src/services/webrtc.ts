import { sound } from './sound';
import { Username } from '../types';

export interface WebRTCEventHandlers {
  onLocalStream?: (stream: MediaStream) => void;
  onRemoteStream?: (stream: MediaStream) => void;
  onCallStateChange?: (state: 'idle' | 'calling' | 'ringing' | 'connected' | 'ended') => void;
  onError?: (err: string) => void;
}

export class WebRTCService {
  private peerConnection: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private remoteStream: MediaStream | null = null;
  private socketSend: ((data: any) => void) | null = null;
  private handlers: WebRTCEventHandlers = {};

  private currentCallType: 'voice' | 'video' = 'voice';
  private facingMode: 'user' | 'environment' = 'user';
  private isMuted: boolean = false;
  private isCameraOff: boolean = false;

  private rtcConfig: RTCConfiguration = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
    ],
  };

  setSocketSender(sendFn: (data: any) => void) {
    this.socketSend = sendFn;
  }

  setHandlers(handlers: WebRTCEventHandlers) {
    this.handlers = handlers;
  }

  getLocalStream(): MediaStream | null {
    return this.localStream;
  }

  getRemoteStream(): MediaStream | null {
    return this.remoteStream;
  }

  private sendSignal(type: string, payload: any) {
    if (this.socketSend) {
      this.socketSend({
        type: 'webrtc_signal',
        payload: { signalType: type, ...payload },
      });
    }
  }

  private initPeerConnection() {
    if (this.peerConnection) {
      this.peerConnection.close();
    }

    this.peerConnection = new RTCPeerConnection(this.rtcConfig);

    this.peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        this.sendSignal('ice_candidate', { candidate: event.candidate });
      }
    };

    this.peerConnection.ontrack = (event) => {
      if (!this.remoteStream) {
        this.remoteStream = new MediaStream();
      }
      event.streams[0]?.getTracks().forEach((track) => {
        this.remoteStream?.addTrack(track);
      });
      if (this.handlers.onRemoteStream && this.remoteStream) {
        this.handlers.onRemoteStream(this.remoteStream);
      }
    };

    this.peerConnection.onconnectionstatechange = () => {
      const state = this.peerConnection?.connectionState;
      if (state === 'connected') {
        sound.stopRingtone();
        sound.playCallConnected();
        this.handlers.onCallStateChange?.('connected');
      } else if (state === 'disconnected' || state === 'failed' || state === 'closed') {
        this.endCall(false);
      }
    };
  }

  async startCall(type: 'voice' | 'video', peer: Username): Promise<void> {
    this.currentCallType = type;
    this.isMuted = false;
    this.isCameraOff = false;
    this.facingMode = 'user';

    try {
      this.initPeerConnection();

      // Acquire media
      const constraints: MediaStreamConstraints = {
        audio: true,
        video: type === 'video' ? { facingMode: 'user' } : false,
      };

      this.localStream = await navigator.mediaDevices.getUserMedia(constraints);
      this.handlers.onLocalStream?.(this.localStream);

      // Add tracks to PeerConnection
      this.localStream.getTracks().forEach((track) => {
        this.peerConnection?.addTrack(track, this.localStream!);
      });

      // Create SDP Offer
      const offer = await this.peerConnection!.createOffer();
      await this.peerConnection!.setLocalDescription(offer);

      sound.playOutgoingRing();
      this.handlers.onCallStateChange?.('calling');

      // Send call offer signal
      this.sendSignal('call_request', {
        callType: type,
        offer,
      });
    } catch (err: any) {
      sound.stopRingtone();
      this.handlers.onError?.(err?.message || 'Mikrofon veya kamera izni alınamadı.');
      this.endCall(false);
    }
  }

  async handleIncomingCall(signal: any) {
    this.currentCallType = signal.callType;
    sound.playIncomingRing();
    this.handlers.onCallStateChange?.('ringing');
  }

  async acceptCall(offer: RTCSessionDescriptionInit): Promise<void> {
    sound.stopRingtone();
    try {
      this.initPeerConnection();

      const constraints: MediaStreamConstraints = {
        audio: true,
        video: this.currentCallType === 'video' ? { facingMode: 'user' } : false,
      };

      this.localStream = await navigator.mediaDevices.getUserMedia(constraints);
      this.handlers.onLocalStream?.(this.localStream);

      this.localStream.getTracks().forEach((track) => {
        this.peerConnection?.addTrack(track, this.localStream!);
      });

      await this.peerConnection!.setRemoteDescription(new RTCSessionDescription(offer));
      const answer = await this.peerConnection!.createAnswer();
      await this.peerConnection!.setLocalDescription(answer);

      this.sendSignal('call_answer', { answer });
      this.handlers.onCallStateChange?.('connected');
    } catch (err: any) {
      this.handlers.onError?.(err?.message || 'Arama kabul edilirken hata oluştu.');
      this.endCall(true);
    }
  }

  async handleAnswer(answer: RTCSessionDescriptionInit) {
    if (this.peerConnection) {
      await this.peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
    }
  }

  async handleIceCandidate(candidate: RTCIceCandidateInit) {
    if (this.peerConnection && candidate) {
      try {
        await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (err) {
        console.warn('Error adding ICE candidate:', err);
      }
    }
  }

  toggleMute(): boolean {
    if (this.localStream) {
      const audioTrack = this.localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        this.isMuted = !audioTrack.enabled;
        return this.isMuted;
      }
    }
    return false;
  }

  toggleCamera(): boolean {
    if (this.localStream) {
      const videoTrack = this.localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        this.isCameraOff = !videoTrack.enabled;
        return this.isCameraOff;
      }
    }
    return false;
  }

  async flipCamera(): Promise<'user' | 'environment'> {
    if (!this.localStream || this.currentCallType !== 'video') return this.facingMode;

    const newFacing = this.facingMode === 'user' ? 'environment' : 'user';
    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: newFacing },
      });
      const newVideoTrack = newStream.getVideoTracks()[0];

      const sender = this.peerConnection
        ?.getSenders()
        .find((s) => s.track && s.track.kind === 'video');

      if (sender && newVideoTrack) {
        await sender.replaceTrack(newVideoTrack);
      }

      // Replace old local stream track
      const oldVideoTrack = this.localStream.getVideoTracks()[0];
      if (oldVideoTrack) {
        oldVideoTrack.stop();
        this.localStream.removeTrack(oldVideoTrack);
      }
      this.localStream.addTrack(newVideoTrack);
      this.facingMode = newFacing;
      this.handlers.onLocalStream?.(this.localStream);
    } catch (e) {
      console.warn('Camera flip failed:', e);
    }
    return this.facingMode;
  }

  endCall(notifyPeer = true) {
    sound.stopRingtone();
    sound.playCallEnded();

    if (notifyPeer) {
      this.sendSignal('call_hangup', {});
    }

    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => track.stop());
      this.localStream = null;
    }

    if (this.peerConnection) {
      this.peerConnection.close();
      this.peerConnection = null;
    }

    this.remoteStream = null;
    this.handlers.onCallStateChange?.('ended');
  }
}

export const webrtc = new WebRTCService();
