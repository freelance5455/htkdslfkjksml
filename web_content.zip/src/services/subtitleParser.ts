import { SubtitleCue } from '../types';

export function formatTime(seconds: number, includeMillis: boolean = false): string {
  if (isNaN(seconds) || seconds < 0) seconds = 0;
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const millis = Math.floor((seconds % 1) * 1000);

  const pad = (num: number, size: number = 2) => String(num).padStart(size, '0');

  if (includeMillis) {
    return `${pad(mins)}:${pad(secs)}.${pad(millis, 3)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

export function formatSrtTimestamp(seconds: number): string {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const millis = Math.floor((seconds % 1) * 1000);

  const pad = (num: number, size: number = 2) => String(num).padStart(size, '0');
  return `${pad(hrs)}:${pad(mins)}:${pad(secs)},${pad(millis, 3)}`;
}

export function parseSrtTimestamp(timeStr: string): number {
  // 00:01:23,456 or 00:01:23.456
  const clean = timeStr.trim().replace(',', '.');
  const parts = clean.split(':');
  if (parts.length === 3) {
    const hours = parseFloat(parts[0]);
    const minutes = parseFloat(parts[1]);
    const seconds = parseFloat(parts[2]);
    return hours * 3600 + minutes * 60 + seconds;
  }
  if (parts.length === 2) {
    const minutes = parseFloat(parts[0]);
    const seconds = parseFloat(parts[1]);
    return minutes * 60 + seconds;
  }
  return parseFloat(clean) || 0;
}

export function parseSrt(srtContent: string): SubtitleCue[] {
  const cues: SubtitleCue[] = [];
  const normalized = srtContent.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const blocks = normalized.split(/\n\s*\n/);

  let idCounter = 1;

  for (const block of blocks) {
    const lines = block.trim().split('\n');
    if (lines.length < 2) continue;

    let timeLineIdx = 0;
    if (!lines[0].includes('-->')) {
      timeLineIdx = 1;
    }

    if (!lines[timeLineIdx] || !lines[timeLineIdx].includes('-->')) continue;

    const [startStr, endStr] = lines[timeLineIdx].split('-->');
    const startTime = parseSrtTimestamp(startStr);
    const endTime = parseSrtTimestamp(endStr);

    const textLines = lines.slice(timeLineIdx + 1).join('\n').trim();
    if (!textLines) continue;

    // Check if line contains Hindi + English format or just one
    // e.g. "नमस्ते दोस्तों\nHello friends"
    const splitTexts = textLines.split('\n');
    let hindiText = textLines;
    let originalText = textLines;

    if (splitTexts.length > 1) {
      hindiText = splitTexts[0].trim();
      originalText = splitTexts.slice(1).join(' ').trim();
    }

    cues.push({
      id: idCounter++,
      startTime,
      endTime,
      hindiText,
      originalText,
    });
  }

  return cues;
}

export function exportToSrt(cues: SubtitleCue[]): string {
  return cues
    .map((cue, index) => {
      const idx = index + 1;
      const start = formatSrtTimestamp(cue.startTime);
      const end = formatSrtTimestamp(cue.endTime);
      return `${idx}\n${start} --> ${end}\n${cue.hindiText}\n${cue.originalText ? cue.originalText + '\n' : ''}`;
    })
    .join('\n');
}

export function exportToVtt(cues: SubtitleCue[]): string {
  const body = cues
    .map((cue, index) => {
      const idx = index + 1;
      const start = formatTime(cue.startTime, true);
      const end = formatTime(cue.endTime, true);
      return `${idx}\n${start} --> ${end}\n${cue.hindiText}\n`;
    })
    .join('\n');

  return `WEBVTT\n\n${body}`;
}
