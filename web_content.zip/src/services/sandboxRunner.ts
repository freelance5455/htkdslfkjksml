/**
 * GODEX v0.0.1 - Real Virtual Sandbox & Multi-File Module Runtime
 * Compiles and mounts virtual workspace files in an isolated iframe
 * with bi-directional postMessage telemetry, standalone Tailwind JIT engine,
 * automation bridge, and computed style health diagnostics.
 */

export interface SandboxMessage {
  type: 'log' | 'error' | 'ready' | 'assertion_result' | 'dom_snapshot' | 'style_diagnostics';
  payload: any;
}

// Complete Standard Tailwind Color Palette
const TW_COLORS: Record<string, Record<string, string>> = {
  slate: {
    50: '#f8fafc', 100: '#f1f5f9', 200: '#e2e8f0', 300: '#cbd5e1', 400: '#94a3b8',
    500: '#64748b', 600: '#475569', 700: '#334155', 800: '#1e293b', 900: '#0f172a', 950: '#020617'
  },
  gray: {
    50: '#f9fafb', 100: '#f3f4f6', 200: '#e5e7eb', 300: '#d1d5db', 400: '#9ca3af',
    500: '#6b7280', 600: '#4b5563', 700: '#374151', 800: '#1f2937', 900: '#111827', 950: '#030712'
  },
  zinc: {
    50: '#fafafa', 100: '#f4f4f5', 200: '#e4e4e7', 300: '#d4d4d8', 400: '#a1a1aa',
    500: '#71717a', 600: '#52525b', 700: '#3f3f46', 800: '#27272a', 900: '#18181b', 950: '#09090b'
  },
  neutral: {
    50: '#fafafa', 100: '#f5f5f5', 200: '#e5e5e5', 300: '#d4d4d4', 400: '#a3a3a3',
    500: '#737373', 600: '#525252', 700: '#404040', 800: '#262626', 900: '#171717', 950: '#0a0a0a'
  },
  stone: {
    50: '#fafaf9', 100: '#f5f5f4', 200: '#e7e5e4', 300: '#d6d3d1', 400: '#a8a29e',
    500: '#78716c', 600: '#57534e', 700: '#44403c', 800: '#292524', 900: '#1c1917', 950: '#0c0a09'
  },
  red: {
    50: '#fef2f2', 100: '#fee2e2', 200: '#fecaca', 300: '#fca5a5', 400: '#f87171',
    500: '#ef4444', 600: '#dc2626', 700: '#b91c1c', 800: '#991b1b', 900: '#7f1d1d', 950: '#450a0a'
  },
  orange: {
    50: '#fff7ed', 100: '#ffedd5', 200: '#fed7aa', 300: '#fdba74', 400: '#fb923c',
    500: '#f97316', 600: '#ea580c', 700: '#c2410c', 800: '#9a3412', 900: '#7c2d12', 950: '#431407'
  },
  amber: {
    50: '#fffbeb', 100: '#fef3c7', 200: '#fde68a', 300: '#fcd34d', 400: '#fbbf24',
    500: '#f59e0b', 600: '#d97706', 700: '#b45309', 800: '#92400e', 900: '#78350f', 950: '#451a03'
  },
  yellow: {
    50: '#fefce8', 100: '#fef9c3', 200: '#fef08a', 300: '#fde047', 400: '#facc15',
    500: '#eab308', 600: '#ca8a04', 700: '#a16207', 800: '#854d0e', 900: '#713f12', 950: '#422006'
  },
  lime: {
    50: '#f7fee7', 100: '#ecfccb', 200: '#d9f99d', 300: '#bef264', 400: '#a3e635',
    500: '#84cc16', 600: '#65a30d', 700: '#4d7c0f', 800: '#3f6212', 900: '#365314', 950: '#1a2e05'
  },
  green: {
    50: '#f0fdf4', 100: '#dcfce7', 200: '#bbf7d0', 300: '#86efac', 400: '#4ade80',
    500: '#22c55e', 600: '#16a34a', 700: '#15803d', 800: '#166534', 900: '#14532d', 950: '#052e16'
  },
  emerald: {
    50: '#ecfdf5', 100: '#d1fae5', 200: '#a7f3d0', 300: '#6ee7b7', 400: '#34d399',
    500: '#10b981', 600: '#059669', 700: '#047857', 800: '#065f46', 900: '#064e3b', 950: '#022c22'
  },
  teal: {
    50: '#f0fdfa', 100: '#ccfbf1', 200: '#99f6e4', 300: '#5eead4', 400: '#2dd4bf',
    500: '#14b8a6', 600: '#0d9488', 700: '#0f766e', 800: '#115e59', 900: '#134e4a', 950: '#042f2e'
  },
  cyan: {
    50: '#ecfeff', 100: '#cffafe', 200: '#a5f3fc', 300: '#67e8f9', 400: '#22d3ee',
    500: '#06b6d4', 600: '#0891b2', 700: '#0e7490', 800: '#155e75', 900: '#164e63', 950: '#083344'
  },
  sky: {
    50: '#f0f9ff', 100: '#e0f2fe', 200: '#bae6fd', 300: '#7dd3fc', 400: '#38bdf8',
    500: '#0ea5e9', 600: '#0284c7', 700: '#0369a1', 800: '#075985', 900: '#0c4a6e', 950: '#082f49'
  },
  blue: {
    50: '#eff6ff', 100: '#dbeafe', 200: '#bfdbfe', 300: '#93c5fd', 400: '#60a5fa',
    500: '#3b82f6', 600: '#2563eb', 700: '#1d4ed8', 800: '#1e40af', 900: '#1e3a8a', 950: '#172554'
  },
  indigo: {
    50: '#eef2ff', 100: '#e0e7ff', 200: '#c7d2fe', 300: '#a5b4fc', 400: '#818cf8',
    500: '#6366f1', 600: '#4f46e5', 700: '#4338ca', 800: '#3730a3', 900: '#312e81', 950: '#1e1b4b'
  },
  violet: {
    50: '#f5f3ff', 100: '#ede9fe', 200: '#ddd6fe', 300: '#c4b5fd', 400: '#a78bfa',
    500: '#8b5cf6', 600: '#7c3aed', 700: '#6d28d9', 800: '#5b21b6', 900: '#4c1d95', 950: '#2e1065'
  },
  purple: {
    50: '#faf5ff', 100: '#f3e8ff', 200: '#e9d5ff', 300: '#d8b4fe', 400: '#c084fc',
    500: '#a855f7', 600: '#9333ea', 700: '#7e22ce', 800: '#6b21a8', 900: '#581c87', 950: '#3b0764'
  },
  fuchsia: {
    50: '#fdf4ff', 100: '#fae8ff', 200: '#f5d0fe', 300: '#f0abfc', 400: '#e879f9',
    500: '#d946ef', 600: '#c026d3', 700: '#a21caf', 800: '#86198f', 900: '#701a75', 950: '#4a044e'
  },
  pink: {
    50: '#fdf2f8', 100: '#fce7f3', 200: '#fbcfe8', 300: '#f472b6', 400: '#f472b6',
    500: '#ec4899', 600: '#db2777', 700: '#be185d', 800: '#9d174d', 900: '#831843', 950: '#500724'
  },
  rose: {
    50: '#fff1f2', 100: '#ffe4e6', 200: '#fecdd3', 300: '#fda4af', 400: '#fb7185',
    500: '#f43f5e', 600: '#e11d48', 700: '#be123c', 800: '#9f1239', 900: '#881337', 950: '#4c0519'
  },
  brand: {
    50: '#f0f9ff', 100: '#e0f2fe', 200: '#bae6fd', 300: '#7dd3fc', 400: '#38bdf8',
    500: '#0ea5e9', 600: '#0284c7', 700: '#0369a1', 800: '#075985', 900: '#0c4a6e', 950: '#082f49'
  }
};

const BASE_COLORS: Record<string, string> = {
  black: '#000000',
  white: '#ffffff',
  transparent: 'transparent',
  current: 'currentColor',
  inherit: 'inherit'
};

function hexToRgba(hex: string, alpha: number): string {
  if (!hex.startsWith('#')) return hex;
  let c = hex.slice(1);
  if (c.length === 3) {
    c = c.split('').map(x => x + x).join('');
  }
  const r = parseInt(c.substring(0, 2), 16);
  const g = parseInt(c.substring(2, 4), 16);
  const b = parseInt(c.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function resolveColorValue(colorStr: string): string | null {
  // Format: color-scale or color-scale/opacity or black/opacity or [#hex]
  let opacity: number | null = null;
  let base = colorStr;

  if (colorStr.includes('/')) {
    const parts = colorStr.split('/');
    base = parts[0];
    const opVal = parseFloat(parts[1]);
    if (!isNaN(opVal)) {
      opacity = opVal > 1 ? opVal / 100 : opVal;
    }
  }

  // Arbitrary hex [#08090D]
  if (base.startsWith('[#') && base.endsWith(']')) {
    const hex = base.slice(1, -1);
    return opacity !== null ? hexToRgba(hex, opacity) : hex;
  }

  // Arbitrary rgb/hsl [rgb(0,0,0)]
  if (base.startsWith('[') && base.endsWith(']')) {
    return base.slice(1, -1);
  }

  // Named base colors (black, white, transparent, current, inherit)
  if (BASE_COLORS[base]) {
    const hex = BASE_COLORS[base];
    if (hex.startsWith('#') && opacity !== null) {
      return hexToRgba(hex, opacity);
    }
    return hex;
  }

  // Standard palette (e.g. neutral-900, amber-500)
  const lastDash = base.lastIndexOf('-');
  if (lastDash > 0) {
    const group = base.substring(0, lastDash);
    const shade = base.substring(lastDash + 1);
    if (TW_COLORS[group] && TW_COLORS[group][shade]) {
      const hex = TW_COLORS[group][shade];
      return opacity !== null ? hexToRgba(hex, opacity) : hex;
    }
  }

  return null;
}

export class SandboxRunner {
  /**
   * Generates a self-contained HTML bundle containing all project files
   * with multi-file module resolution and bi-directional message bridge.
   */
  public static generateSandboxHtml(files: Record<string, string>): string {
    // Collect all CSS files in workspace
    const cssFileEntries = Object.entries(files).filter(([p]) => p.endsWith('.css'));
    const combinedCustomCss = cssFileEntries.map(([p, c]) => `/* ${p} */\n${c}`).join('\n\n');
    const cleanStandardCss = combinedCustomCss
      .replace(/@import\s+['"][^'"]*tailwindcss[^'"]*['"];?/g, '')
      .replace(/@tailwind\s+[^;]+;?/g, '');

    // Prepare JSON map of all files in workspace for multi-file virtual imports
    const virtualFilesJson = JSON.stringify(files);

    const bundleHtml = `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>GODEX Sandbox Preview</title>

  <!-- Early Global Error Guard & PostMessage Telemetry Bridge -->
  <script>
    (function() {
      function sendToParent(type, payload) {
        try {
          window.parent.postMessage({ type: 'SANDBOX_' + type, payload: payload }, '*');
        } catch (e) {}
      }

      window.onerror = function(message, source, lineno, colno, error) {
        const msgStr = String(message || '');
        if (!message || msgStr === 'Script error.' || msgStr.includes('Script error')) {
          return true; // Suppress cross-origin noise
        }

        sendToParent('ERROR', {
          level: 'runtime_error',
          message: msgStr,
          source: String(source || ''),
          lineno: lineno || 0,
          colno: colno || 0,
          stack: error ? error.stack : undefined
        });
        return true;
      };

      window.addEventListener('error', function(event) {
        const msg = String(event.message || '');
        if (msg === 'Script error.' || msg.includes('Script error')) {
          event.preventDefault();
          event.stopPropagation();
          return false;
        }
      }, true);

      window.addEventListener('unhandledrejection', function(event) {
        const msg = event.reason ? (event.reason.message || String(event.reason)) : 'Unhandled Promise Rejection';
        if (!msg || msg === 'Script error.' || String(msg).includes('Script error')) {
          if (event && event.preventDefault) event.preventDefault();
          return;
        }
        sendToParent('ERROR', {
          level: 'unhandled_rejection',
          message: msg
        });
        if (event && event.preventDefault) event.preventDefault();
      }, true);

      const originalLog = console.log;
      const originalError = console.error;
      const originalWarn = console.warn;

      console.log = function(...args) {
        try { originalLog.apply(console, args); } catch (e) {}
        sendToParent('LOG', { level: 'log', message: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') });
      };

      console.warn = function(...args) {
        try { originalWarn.apply(console, args); } catch (e) {}
        sendToParent('LOG', { level: 'warn', message: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') });
      };

      console.error = function(...args) {
        const msg = args.map(a => typeof a === 'object' ? (a.message || JSON.stringify(a)) : String(a)).join(' ');
        if (!msg || msg === 'Script error.' || msg.includes('Script error')) {
          return;
        }
        try { originalError.apply(console, args); } catch (e) {}
        sendToParent('ERROR', { level: 'error', message: msg });
      };
    })();
  </script>
  
  <!-- Standalone Preflight Base Styles -->
  <style id="__tailwind_preflight__">
    *, ::before, ::after {
      box-sizing: border-box;
      border-width: 0;
      border-style: solid;
      border-color: #27272a;
    }
    html {
      line-height: 1.5;
      -webkit-text-size-adjust: 100%;
      tab-size: 4;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }
    body {
      margin: 0;
      line-height: inherit;
      background-color: #0a0a0a;
      color: #f4f4f5;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      overflow-x: hidden;
      overflow-y: auto;
      min-height: 100vh;
    }
    #root {
      width: 100%;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    hr { height: 0; color: inherit; border-top-width: 1px; }
    h1, h2, h3, h4, h5, h6 { font-size: inherit; font-weight: inherit; margin: 0; }
    a { color: inherit; text-decoration: inherit; }
    b, strong { font-weight: bolder; }
    code, kbd, samp, pre {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      font-size: 1em;
    }
    small { font-size: 80%; }
    table { text-indent: 0; border-color: inherit; border-collapse: collapse; }
    button, input, optgroup, select, textarea {
      font-family: inherit;
      font-size: 100%;
      font-weight: inherit;
      line-height: inherit;
      color: inherit;
      margin: 0;
      padding: 0;
    }
    button, select { text-transform: none; }
    button, [type='button'], [type='reset'], [type='submit'] {
      -webkit-appearance: button;
      background-color: transparent;
      background-image: none;
      cursor: pointer;
    }
    blockquote, dl, dd, h1, h2, h3, h4, h5, h6, hr, figure, p, pre { margin: 0; }
    ol, ul, menu { list-style: none; margin: 0; padding: 0; }
    textarea { resize: vertical; }
    input::placeholder, textarea::placeholder { opacity: 1; color: #71717a; }
    button, [role="button"] { cursor: pointer; }
    :disabled { cursor: default; }
    img, svg, video, canvas, audio, iframe, embed, object { display: block; vertical-align: middle; }
    img, video { max-width: 100%; height: auto; }
    
    /* Workspace Custom CSS */
    ${cleanStandardCss}
  </style>

  <!-- Dynamic Tailwind JIT Generated Stylesheet -->
  <style id="__tailwind_jit_styles__"></style>

  <!-- Tailwind CSS Configuration (Companion) -->
  <script>
    window.tailwind = window.tailwind || {};
    window.tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            brand: {
              50: '#f0f9ff', 100: '#e0f2fe', 500: '#0ea5e9', 600: '#0284c7', 700: '#0369a1', 900: '#0c4a6e'
            }
          }
        }
      }
    };
  </script>

  <!-- Tailwind CSS CDN Runtime (High Availability) -->
  <script crossorigin="anonymous" src="https://cdn.tailwindcss.com"></script>
  
  <!-- React 18 & ReactDOM UMD -->
  <script crossorigin="anonymous" src="https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js"></script>
  <script crossorigin="anonymous" src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js"></script>
  
  <!-- Lucide Icons UMD Bundle -->
  <script crossorigin="anonymous" src="https://cdnjs.cloudflare.com/ajax/libs/lucide/0.469.0/umd/lucide.min.js"></script>

  <!-- Babel Standalone for Multi-File JSX/TSX/CommonJS Compilation -->
  <script crossorigin="anonymous" src="https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/7.26.4/babel.min.js"></script>

  <!-- Standalone High-Precision Tailwind JIT Engine -->
  <script>
    (function() {
      const TW_COLORS = ${JSON.stringify(TW_COLORS)};
      const BASE_COLORS = ${JSON.stringify(BASE_COLORS)};

      function hexToRgba(hex, alpha) {
        if (!hex.startsWith('#')) return hex;
        let c = hex.slice(1);
        if (c.length === 3) c = c.split('').map(x => x + x).join('');
        const r = parseInt(c.substring(0, 2), 16);
        const g = parseInt(c.substring(2, 4), 16);
        const b = parseInt(c.substring(4, 6), 16);
        return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + alpha + ')';
      }

      function resolveColor(str) {
        if (!str) return null;
        let opacity = null;
        let base = str;
        if (str.includes('/')) {
          const parts = str.split('/');
          base = parts[0];
          const op = parseFloat(parts[1]);
          if (!isNaN(op)) opacity = op > 1 ? op / 100 : op;
        }

        if (base.startsWith('[#') && base.endsWith(']')) {
          const hex = base.slice(1, -1);
          return opacity !== null ? hexToRgba(hex, opacity) : hex;
        }
        if (base.startsWith('[') && base.endsWith(']')) {
          return base.slice(1, -1);
        }
        if (BASE_COLORS[base]) {
          const hex = BASE_COLORS[base];
          if (hex.startsWith('#') && opacity !== null) {
            return hexToRgba(hex, opacity);
          }
          return hex;
        }
        const lastDash = base.lastIndexOf('-');
        if (lastDash > 0) {
          const grp = base.substring(0, lastDash);
          const shd = base.substring(lastDash + 1);
          if (TW_COLORS[grp] && TW_COLORS[grp][shd]) {
            const hex = TW_COLORS[grp][shd];
            return opacity !== null ? hexToRgba(hex, opacity) : hex;
          }
        }
        return null;
      }

      function escapeSelector(cls) {
        return cls
          .replace(/\\//g, '\\\\/')
          .replace(/\\:/g, '\\\\:')
          .replace(/\\[/g, '\\\\[')
          .replace(/\\]/g, '\\\\]')
          .replace(/\\#/g, '\\\\#')
          .replace(/\\(/g, '\\\\(')
          .replace(/\\)/g, '\\\\)')
          .replace(/\\%/g, '\\\\%')
          .replace(/\\./g, '\\\\.')
          .replace(/\\,/g, '\\\\,');
      }

      const generatedRules = new Set();
      const cssRulesList = [];

      function parseClass(rawClass) {
        if (!rawClass || generatedRules.has(rawClass)) return null;

        let cls = rawClass;
        let prefix = '';
        let mediaQuery = null;
        let pseudo = '';
        let isDark = false;
        let isGroupHover = false;

        // Parse responsive / state variants
        const parts = cls.split(':');
        if (parts.length > 1) {
          cls = parts[parts.length - 1];
          for (let i = 0; i < parts.length - 1; i++) {
            const v = parts[i];
            if (v === 'sm') mediaQuery = '(min-width: 640px)';
            else if (v === 'md') mediaQuery = '(min-width: 768px)';
            else if (v === 'lg') mediaQuery = '(min-width: 1024px)';
            else if (v === 'xl') mediaQuery = '(min-width: 1280px)';
            else if (v === '2xl') mediaQuery = '(min-width: 1536px)';
            else if (v === 'xs') mediaQuery = '(min-width: 480px)';
            else if (v === 'hover') pseudo = ':hover';
            else if (v === 'focus') pseudo = ':focus';
            else if (v === 'active') pseudo = ':active';
            else if (v === 'disabled') pseudo = ':disabled';
            else if (v === 'dark') isDark = true;
            else if (v === 'group-hover') isGroupHover = true;
          }
        }

        let decl = '';

        // Display & Layout
        if (cls === 'flex') decl = 'display: flex;';
        else if (cls === 'inline-flex') decl = 'display: inline-flex;';
        else if (cls === 'grid') decl = 'display: grid;';
        else if (cls === 'inline-grid') decl = 'display: inline-grid;';
        else if (cls === 'block') decl = 'display: block;';
        else if (cls === 'inline-block') decl = 'display: inline-block;';
        else if (cls === 'inline') decl = 'display: inline;';
        else if (cls === 'hidden') decl = 'display: none;';
        
        // Flexbox Properties
        else if (cls === 'flex-row') decl = 'flex-direction: row;';
        else if (cls === 'flex-col') decl = 'flex-direction: column;';
        else if (cls === 'flex-row-reverse') decl = 'flex-direction: row-reverse;';
        else if (cls === 'flex-col-reverse') decl = 'flex-direction: column-reverse;';
        else if (cls === 'flex-wrap') decl = 'flex-wrap: wrap;';
        else if (cls === 'flex-nowrap') decl = 'flex-wrap: nowrap;';
        else if (cls === 'items-start') decl = 'align-items: flex-start;';
        else if (cls === 'items-center') decl = 'align-items: center;';
        else if (cls === 'items-end') decl = 'align-items: flex-end;';
        else if (cls === 'items-baseline') decl = 'align-items: baseline;';
        else if (cls === 'items-stretch') decl = 'align-items: stretch;';
        else if (cls === 'justify-start') decl = 'justify-content: flex-start;';
        else if (cls === 'justify-center') decl = 'justify-content: center;';
        else if (cls === 'justify-end') decl = 'justify-content: flex-end;';
        else if (cls === 'justify-between') decl = 'justify-content: space-between;';
        else if (cls === 'justify-around') decl = 'justify-content: space-around;';
        else if (cls === 'justify-evenly') decl = 'justify-content: space-evenly;';
        else if (cls === 'flex-1') decl = 'flex: 1 1 0%;';
        else if (cls === 'flex-auto') decl = 'flex: 1 1 auto;';
        else if (cls === 'flex-initial') decl = 'flex: 0 1 auto;';
        else if (cls === 'flex-none') decl = 'flex: none;';
        else if (cls === 'shrink-0') decl = 'flex-shrink: 0;';
        else if (cls === 'shrink') decl = 'flex-shrink: 1;';
        else if (cls === 'grow') decl = 'flex-grow: 1;';
        else if (cls === 'grow-0') decl = 'flex-grow: 0;';

        // Grid Properties
        else if (cls.startsWith('grid-cols-')) {
          const num = cls.replace('grid-cols-', '');
          decl = 'grid-template-columns: repeat(' + num + ', minmax(0, 1fr));';
        }
        else if (cls.startsWith('col-span-')) {
          const num = cls.replace('col-span-', '');
          decl = num === 'full' ? 'grid-column: 1 / -1;' : 'grid-column: span ' + num + ' / span ' + num + ';';
        }

        // Gap & Space
        else if (cls.startsWith('gap-')) {
          const val = cls.replace('gap-', '');
          const px = parseSpacing(val);
          if (px) decl = 'gap: ' + px + ';';
        }
        else if (cls.startsWith('gap-x-')) {
          const val = cls.replace('gap-x-', '');
          const px = parseSpacing(val);
          if (px) decl = 'column-gap: ' + px + ';';
        }
        else if (cls.startsWith('gap-y-')) {
          const val = cls.replace('gap-y-', '');
          const px = parseSpacing(val);
          if (px) decl = 'row-gap: ' + px + ';';
        }

        // Colors: Background, Text, Border, Ring, Fill, Stroke
        else if (cls.startsWith('bg-')) {
          const colorName = cls.replace('bg-', '');
          if (colorName.startsWith('gradient-to-')) {
            const dir = colorName.replace('gradient-to-', '');
            const dirMap = {
              't': 'to top', 'tr': 'to top right', 'r': 'to right', 'br': 'to bottom right',
              'b': 'to bottom', 'bl': 'to bottom left', 'l': 'to left', 'tl': 'to top left'
            };
            decl = 'background-image: linear-gradient(' + (dirMap[dir] || 'to right') + ', var(--tw-gradient-stops, transparent, transparent));';
          } else {
            const c = resolveColor(colorName);
            if (c) decl = 'background-color: ' + c + ';';
          }
        }
        else if (cls.startsWith('text-')) {
          const val = cls.replace('text-', '');
          // Font size or color?
          const fontSizes = {
            'xs': 'font-size: 0.75rem; line-height: 1rem;',
            'sm': 'font-size: 0.875rem; line-height: 1.25rem;',
            'base': 'font-size: 1rem; line-height: 1.5rem;',
            'lg': 'font-size: 1.125rem; line-height: 1.75rem;',
            'xl': 'font-size: 1.25rem; line-height: 1.75rem;',
            '2xl': 'font-size: 1.5rem; line-height: 2rem;',
            '3xl': 'font-size: 1.875rem; line-height: 2.25rem;',
            '4xl': 'font-size: 2.25rem; line-height: 2.5rem;',
            '5xl': 'font-size: 3rem; line-height: 1;',
            '[10px]': 'font-size: 10px; line-height: 14px;',
            '[11px]': 'font-size: 11px; line-height: 15px;',
            '[9px]': 'font-size: 9px; line-height: 12px;',
            '[13px]': 'font-size: 13px; line-height: 18px;',
            'left': 'text-align: left;',
            'center': 'text-align: center;',
            'right': 'text-align: right;',
            'justify': 'text-align: justify;'
          };
          if (fontSizes[val]) {
            decl = fontSizes[val];
          } else {
            const c = resolveColor(val);
            if (c) decl = 'color: ' + c + ';';
          }
        }
        else if (cls.startsWith('border-')) {
          const val = cls.replace('border-', '');
          if (val === '0') decl = 'border-width: 0px;';
          else if (val === '2') decl = 'border-width: 2px;';
          else if (val === '4') decl = 'border-width: 4px;';
          else if (val === '8') decl = 'border-width: 8px;';
          else if (val === 't') decl = 'border-top-width: 1px;';
          else if (val === 'b') decl = 'border-bottom-width: 1px;';
          else if (val === 'l') decl = 'border-left-width: 1px;';
          else if (val === 'r') decl = 'border-right-width: 1px;';
          else if (val === 't-0') decl = 'border-top-width: 0px;';
          else if (val === 'b-0') decl = 'border-bottom-width: 0px;';
          else if (val === 'l-0') decl = 'border-left-width: 0px;';
          else if (val === 'r-0') decl = 'border-right-width: 0px;';
          else if (val === 't-2') decl = 'border-top-width: 2px;';
          else if (val === 'b-2') decl = 'border-bottom-width: 2px;';
          else if (val === 'solid') decl = 'border-style: solid;';
          else if (val === 'dashed') decl = 'border-style: dashed;';
          else if (val === 'dotted') decl = 'border-style: dotted;';
          else if (val === 'none') decl = 'border-style: none;';
          else {
            const c = resolveColor(val);
            if (c) decl = 'border-color: ' + c + ';';
          }
        }
        else if (cls === 'border') {
          decl = 'border-width: 1px; border-style: solid;';
        }

        // Rounded (Border Radius)
        else if (cls.startsWith('rounded')) {
          const radii = {
            'rounded-none': '0px',
            'rounded-sm': '0.125rem',
            'rounded': '0.25rem',
            'rounded-md': '0.375rem',
            'rounded-lg': '0.5rem',
            'rounded-xl': '0.75rem',
            'rounded-2xl': '1rem',
            'rounded-3xl': '1.5rem',
            'rounded-full': '9999px'
          };
          if (radii[cls]) {
            decl = 'border-radius: ' + radii[cls] + ';';
          } else if (cls.startsWith('rounded-t-')) {
            const r = radii['rounded-' + cls.replace('rounded-t-', '')] || '0.5rem';
            decl = 'border-top-left-radius: ' + r + '; border-top-right-radius: ' + r + ';';
          } else if (cls.startsWith('rounded-b-')) {
            const r = radii['rounded-' + cls.replace('rounded-b-', '')] || '0.5rem';
            decl = 'border-bottom-left-radius: ' + r + '; border-bottom-right-radius: ' + r + ';';
          }
        }

        // Sizing (Width & Height)
        else if (cls.startsWith('w-')) {
          const val = cls.replace('w-', '');
          if (val === 'full') decl = 'width: 100%;';
          else if (val === 'screen') decl = 'width: 100vw;';
          else if (val === 'auto') decl = 'width: auto;';
          else if (val === 'min') decl = 'width: min-content;';
          else if (val === 'max') decl = 'width: max-content;';
          else if (val === 'fit') decl = 'width: fit-content;';
          else if (val.startsWith('[') && val.endsWith(']')) decl = 'width: ' + val.slice(1, -1) + ';';
          else {
            const px = parseSpacing(val);
            if (px) decl = 'width: ' + px + ';';
          }
        }
        else if (cls.startsWith('max-w-')) {
          const val = cls.replace('max-w-', '');
          const maxMap = {
            'none': 'none', 'xs': '20rem', 'sm': '24rem', 'md': '28rem', 'lg': '32rem',
            'xl': '36rem', '2xl': '42rem', '3xl': '48rem', '4xl': '56rem', '5xl': '64rem',
            '6xl': '72rem', '7xl': '80rem', 'full': '100%', 'min': 'min-content', 'max': 'max-content'
          };
          if (maxMap[val]) decl = 'max-width: ' + maxMap[val] + ';';
          else if (val.startsWith('[') && val.endsWith(']')) decl = 'max-width: ' + val.slice(1, -1) + ';';
        }
        else if (cls.startsWith('min-w-')) {
          const val = cls.replace('min-w-', '');
          if (val === '0') decl = 'min-width: 0px;';
          else if (val === 'full') decl = 'min-width: 100%;';
          else if (val.startsWith('[') && val.endsWith(']')) decl = 'min-width: ' + val.slice(1, -1) + ';';
        }
        else if (cls.startsWith('h-')) {
          const val = cls.replace('h-', '');
          if (val === 'full') decl = 'height: 100%;';
          else if (val === 'screen') decl = 'height: 100vh;';
          else if (val === 'auto') decl = 'height: auto;';
          else if (val === 'fit') decl = 'height: fit-content;';
          else if (val.startsWith('[') && val.endsWith(']')) decl = 'height: ' + val.slice(1, -1) + ';';
          else {
            const px = parseSpacing(val);
            if (px) decl = 'height: ' + px + ';';
          }
        }
        else if (cls.startsWith('min-h-')) {
          const val = cls.replace('min-h-', '');
          if (val === '0') decl = 'min-height: 0px;';
          else if (val === 'full') decl = 'min-height: 100%;';
          else if (val === 'screen') decl = 'min-height: 100vh;';
          else if (val.startsWith('[') && val.endsWith(']')) decl = 'min-height: ' + val.slice(1, -1) + ';';
        }
        else if (cls.startsWith('max-h-')) {
          const val = cls.replace('max-h-', '');
          if (val === 'full') decl = 'max-height: 100%;';
          else if (val === 'screen') decl = 'max-height: 100vh;';
          else if (val.startsWith('[') && val.endsWith(']')) decl = 'max-height: ' + val.slice(1, -1) + ';';
        }

        // Padding
        else if (cls.startsWith('p-')) {
          const p = parseSpacing(cls.replace('p-', ''));
          if (p) decl = 'padding: ' + p + ';';
        }
        else if (cls.startsWith('px-')) {
          const p = parseSpacing(cls.replace('px-', ''));
          if (p) decl = 'padding-left: ' + p + '; padding-right: ' + p + ';';
        }
        else if (cls.startsWith('py-')) {
          const p = parseSpacing(cls.replace('py-', ''));
          if (p) decl = 'padding-top: ' + p + '; padding-bottom: ' + p + ';';
        }
        else if (cls.startsWith('pt-')) {
          const p = parseSpacing(cls.replace('pt-', ''));
          if (p) decl = 'padding-top: ' + p + ';';
        }
        else if (cls.startsWith('pb-')) {
          const p = parseSpacing(cls.replace('pb-', ''));
          if (p) decl = 'padding-bottom: ' + p + ';';
        }
        else if (cls.startsWith('pl-')) {
          const p = parseSpacing(cls.replace('pl-', ''));
          if (p) decl = 'padding-left: ' + p + ';';
        }
        else if (cls.startsWith('pr-')) {
          const p = parseSpacing(cls.replace('pr-', ''));
          if (p) decl = 'padding-right: ' + p + ';';
        }

        // Margin
        else if (cls.startsWith('m-')) {
          const m = parseSpacing(cls.replace('m-', ''));
          if (m) decl = 'margin: ' + m + ';';
        }
        else if (cls.startsWith('mx-')) {
          const val = cls.replace('mx-', '');
          decl = val === 'auto' ? 'margin-left: auto; margin-right: auto;' : 'margin-left: ' + parseSpacing(val) + '; margin-right: ' + parseSpacing(val) + ';';
        }
        else if (cls.startsWith('my-')) {
          const val = cls.replace('my-', '');
          decl = val === 'auto' ? 'margin-top: auto; margin-bottom: auto;' : 'margin-top: ' + parseSpacing(val) + '; margin-bottom: ' + parseSpacing(val) + ';';
        }
        else if (cls.startsWith('mt-')) {
          const m = parseSpacing(cls.replace('mt-', ''));
          if (m) decl = 'margin-top: ' + m + ';';
        }
        else if (cls.startsWith('mb-')) {
          const m = parseSpacing(cls.replace('mb-', ''));
          if (m) decl = 'margin-bottom: ' + m + ';';
        }
        else if (cls.startsWith('ml-')) {
          const m = parseSpacing(cls.replace('ml-', ''));
          if (m) decl = 'margin-left: ' + m + ';';
        }
        else if (cls.startsWith('mr-')) {
          const m = parseSpacing(cls.replace('mr-', ''));
          if (m) decl = 'margin-right: ' + m + ';';
        }

        // Font Weight & Family & Style
        else if (cls === 'font-thin') decl = 'font-weight: 100;';
        else if (cls === 'font-extralight') decl = 'font-weight: 200;';
        else if (cls === 'font-light') decl = 'font-weight: 300;';
        else if (cls === 'font-normal') decl = 'font-weight: 400;';
        else if (cls === 'font-medium') decl = 'font-weight: 500;';
        else if (cls === 'font-semibold') decl = 'font-weight: 600;';
        else if (cls === 'font-bold') decl = 'font-weight: 700;';
        else if (cls === 'font-extrabold') decl = 'font-weight: 800;';
        else if (cls === 'font-black') decl = 'font-weight: 900;';
        else if (cls === 'font-sans') decl = 'font-family: system-ui, -apple-system, sans-serif;';
        else if (cls === 'font-mono') decl = 'font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;';
        else if (cls === 'italic') decl = 'font-style: italic;';
        else if (cls === 'not-italic') decl = 'font-style: normal;';
        else if (cls === 'uppercase') decl = 'text-transform: uppercase;';
        else if (cls === 'lowercase') decl = 'text-transform: lowercase;';
        else if (cls === 'capitalize') decl = 'text-transform: capitalize;';
        else if (cls === 'truncate') decl = 'overflow: hidden; text-overflow: ellipsis; white-space: nowrap;';
        else if (cls === 'tracking-tight') decl = 'letter-spacing: -0.025em;';
        else if (cls === 'tracking-normal') decl = 'letter-spacing: 0em;';
        else if (cls === 'tracking-wide') decl = 'letter-spacing: 0.025em;';
        else if (cls === 'tracking-wider') decl = 'letter-spacing: 0.05em;';
        else if (cls === 'tracking-widest') decl = 'letter-spacing: 0.1em;';
        else if (cls === 'leading-none') decl = 'line-height: 1;';
        else if (cls === 'leading-tight') decl = 'line-height: 1.25;';
        else if (cls === 'leading-snug') decl = 'line-height: 1.375;';
        else if (cls === 'leading-normal') decl = 'line-height: 1.5;';
        else if (cls === 'leading-relaxed') decl = 'line-height: 1.625;';
        else if (cls === 'leading-loose') decl = 'line-height: 2;';

        // Positioning
        else if (cls === 'relative') decl = 'position: relative;';
        else if (cls === 'absolute') decl = 'position: absolute;';
        else if (cls === 'fixed') decl = 'position: fixed;';
        else if (cls === 'sticky') decl = 'position: sticky;';
        else if (cls === 'inset-0') decl = 'top: 0px; right: 0px; bottom: 0px; left: 0px;';
        else if (cls === 'top-0') decl = 'top: 0px;';
        else if (cls === 'bottom-0') decl = 'bottom: 0px;';
        else if (cls === 'left-0') decl = 'left: 0px;';
        else if (cls === 'right-0') decl = 'right: 0px;';
        else if (cls.startsWith('top-')) decl = 'top: ' + parseSpacing(cls.replace('top-', '')) + ';';
        else if (cls.startsWith('bottom-')) decl = 'bottom: ' + parseSpacing(cls.replace('bottom-', '')) + ';';
        else if (cls.startsWith('left-')) decl = 'left: ' + parseSpacing(cls.replace('left-', '')) + ';';
        else if (cls.startsWith('right-')) decl = 'right: ' + parseSpacing(cls.replace('right-', '')) + ';';
        else if (cls.startsWith('z-')) decl = 'z-index: ' + cls.replace('z-', '') + ';';

        // Overflow & Interactivity
        else if (cls === 'overflow-hidden') decl = 'overflow: hidden;';
        else if (cls === 'overflow-auto') decl = 'overflow: auto;';
        else if (cls === 'overflow-x-auto') decl = 'overflow-x: auto;';
        else if (cls === 'overflow-y-auto') decl = 'overflow-y: auto;';
        else if (cls === 'overflow-x-hidden') decl = 'overflow-x: hidden;';
        else if (cls === 'overflow-y-hidden') decl = 'overflow-y: hidden;';
        else if (cls === 'select-none') decl = 'user-select: none;';
        else if (cls === 'select-text') decl = 'user-select: text;';
        else if (cls === 'select-all') decl = 'user-select: all;';
        else if (cls === 'cursor-pointer') decl = 'cursor: pointer;';
        else if (cls === 'cursor-not-allowed') decl = 'cursor: not-allowed;';
        else if (cls === 'cursor-crosshair') decl = 'cursor: crosshair;';
        else if (cls === 'pointer-events-none') decl = 'pointer-events: none;';
        else if (cls === 'pointer-events-auto') decl = 'pointer-events: auto;';

        // Shadows & Opacity & Effects
        else if (cls === 'shadow-sm') decl = 'box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);';
        else if (cls === 'shadow') decl = 'box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1);';
        else if (cls === 'shadow-md') decl = 'box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1);';
        else if (cls === 'shadow-lg') decl = 'box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);';
        else if (cls === 'shadow-xl') decl = 'box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);';
        else if (cls === 'shadow-2xl') decl = 'box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);';
        else if (cls === 'shadow-none') decl = 'box-shadow: none;';
        else if (cls.startsWith('opacity-')) decl = 'opacity: ' + (parseFloat(cls.replace('opacity-', '')) / 100) + ';';
        else if (cls === 'backdrop-blur-sm') decl = 'backdrop-filter: blur(4px);';
        else if (cls === 'backdrop-blur') decl = 'backdrop-filter: blur(8px);';
        else if (cls === 'backdrop-blur-md') decl = 'backdrop-filter: blur(12px);';
        else if (cls === 'backdrop-blur-lg') decl = 'backdrop-filter: blur(16px);';
        else if (cls === 'animate-pulse') decl = 'animation: twPulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;';
        else if (cls === 'animate-spin') decl = 'animation: twSpin 1s linear infinite;';
        else if (cls === 'animate-bounce') decl = 'animation: twBounce 1s infinite;';
        else if (cls === 'transition-all') decl = 'transition-property: all; transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1); transition-duration: 150ms;';
        else if (cls === 'transition-colors') decl = 'transition-property: color, background-color, border-color, text-decoration-color, fill, stroke; transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1); transition-duration: 150ms;';
        else if (cls === 'transition') decl = 'transition-property: color, background-color, border-color, opacity, box-shadow, transform; transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1); transition-duration: 150ms;';

        // Gradient Colors (from-*, via-*, to-*)
        else if (cls.startsWith('from-')) {
          const c = resolveColor(cls.replace('from-', ''));
          if (c) decl = '--tw-gradient-from: ' + c + '; --tw-gradient-to: ' + c + '; --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);';
        }
        else if (cls.startsWith('via-')) {
          const c = resolveColor(cls.replace('via-', ''));
          if (c) decl = '--tw-gradient-to: ' + c + '; --tw-gradient-stops: var(--tw-gradient-from), ' + c + ', var(--tw-gradient-to);';
        }
        else if (cls.startsWith('to-')) {
          const c = resolveColor(cls.replace('to-', ''));
          if (c) decl = '--tw-gradient-to: ' + c + ';';
        }

        // SVG Styling
        else if (cls === 'fill-current') decl = 'fill: currentColor;';
        else if (cls === 'fill-none') decl = 'fill: none;';
        else if (cls === 'stroke-current') decl = 'stroke: currentColor;';

        if (!decl) return null;

        const escaped = escapeSelector(rawClass);
        let selector = '.' + escaped + pseudo;
        if (isDark) {
          selector = '.dark .' + escaped + pseudo + ', html.dark .' + escaped + pseudo;
        } else if (isGroupHover) {
          selector = '.group:hover .' + escaped + pseudo;
        }

        let fullRule = selector + ' { ' + decl + ' }';
        if (mediaQuery) {
          fullRule = '@media ' + mediaQuery + ' { ' + fullRule + ' }';
        }

        generatedRules.add(rawClass);
        return fullRule;
      }

      function parseSpacing(v) {
        if (!v) return null;
        if (v === '0') return '0px';
        if (v === 'px') return '1px';
        if (v === '0.5') return '0.125rem';
        if (v === '1') return '0.25rem';
        if (v === '1.5') return '0.375rem';
        if (v === '2') return '0.5rem';
        if (v === '2.5') return '0.625rem';
        if (v === '3') return '0.75rem';
        if (v === '3.5') return '0.875rem';
        if (v === '4') return '1rem';
        if (v === '5') return '1.25rem';
        if (v === '6') return '1.5rem';
        if (v === '7') return '1.75rem';
        if (v === '8') return '2rem';
        if (v === '9') return '2.25rem';
        if (v === '10') return '2.5rem';
        if (v === '11') return '2.75rem';
        if (v === '12') return '3rem';
        if (v === '14') return '3.5rem';
        if (v === '16') return '4rem';
        if (v === '20') return '5rem';
        if (v === '24') return '6rem';
        if (v === '28') return '7rem';
        if (v === '32') return '8rem';
        if (v === '36') return '9rem';
        if (v === '40') return '10rem';
        if (v === '44') return '11rem';
        if (v === '48') return '12rem';
        if (v === '52') return '13rem';
        if (v === '56') return '14rem';
        if (v === '60') return '15rem';
        if (v === '64') return '16rem';
        if (v === '72') return '18rem';
        if (v === '80') return '20rem';
        if (v === '96') return '24rem';
        if (v === '1/2') return '50%';
        if (v === '1/3') return '33.333333%';
        if (v === '2/3') return '66.666667%';
        if (v === '1/4') return '25%';
        if (v === '2/4') return '50%';
        if (v === '3/4') return '75%';
        if (v.startsWith('[') && v.endsWith(']')) return v.slice(1, -1);
        const num = parseFloat(v);
        if (!isNaN(num)) return (num * 0.25) + 'rem';
        return null;
      }

      function injectKeyframes() {
        return '@keyframes twSpin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }\\n' +
               '@keyframes twPulse { 50% { opacity: .5; } }\\n' +
               '@keyframes twBounce { 0%, 100% { transform: translateY(-25%); animation-timing-function: cubic-bezier(0.8,0,1,1); } 50% { transform: none; animation-timing-function: cubic-bezier(0,0,0.2,1); } }\\n';
      }

      function processTailwindClasses(rootNode) {
        const styleEl = document.getElementById('__tailwind_jit_styles__');
        if (!styleEl) return;

        const newRules = [];
        if (generatedRules.size === 0) {
          newRules.push(injectKeyframes());
        }

        // Scan all DOM elements
        const elements = (rootNode || document).querySelectorAll('*');
        for (let i = 0; i < elements.length; i++) {
          const el = elements[i];
          const className = el.className;
          if (typeof className === 'string' && className) {
            const classes = className.split(/\\s+/);
            for (let j = 0; j < classes.length; j++) {
              const c = classes[j];
              if (c && !generatedRules.has(c)) {
                const rule = parseClass(c);
                if (rule) newRules.push(rule);
              }
            }
          }
        }

        if (newRules.length > 0) {
          styleEl.textContent += '\\n' + newRules.join('\\n');
        }
      }

      window.__twEngine = {
        process: processTailwindClasses,
        parseClass: parseClass
      };

      // Observe DOM mutations to immediately compile styles for newly mounted React components
      const observer = new MutationObserver(function(mutations) {
        processTailwindClasses(document.body);
      });

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
          processTailwindClasses(document.body);
          if (document.body) {
            observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'className'] });
          }
        });
      } else {
        processTailwindClasses(document.body);
        if (document.body) {
          observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'className'] });
        }
      }
    })();
  </script>

  <script>
    (function() {
      // Diagnostic helper to read computed styles on a test element
      function getStyleDiagnostics() {
        const styleTags = document.head.querySelectorAll('style');
        const linkTags = document.head.querySelectorAll('link[rel="stylesheet"]');
        const jitEl = document.getElementById('__tailwind_jit_styles__');
        
        // Find or create test element with bg-black text-white flex rounded-xl
        let probeEl = document.getElementById('__style_probe__');
        if (!probeEl) {
          probeEl = document.createElement('div');
          probeEl.id = '__style_probe__';
          probeEl.className = 'bg-black text-white flex rounded-xl border border-neutral-800 p-4';
          probeEl.style.position = 'fixed';
          probeEl.style.bottom = '-9999px';
          probeEl.style.left = '-9999px';
          probeEl.style.pointerEvents = 'none';
          document.body.appendChild(probeEl);
          if (window.__twEngine) window.__twEngine.process(document.body);
        }

        const cs = window.getComputedStyle(probeEl);
        return {
          styleTagsCount: styleTags.length,
          linkTagsCount: linkTags.length,
          tailwindCssExists: !!(jitEl && jitEl.textContent.length > 0) || (styleTags.length > 0),
          elementsCount: document.querySelectorAll('*').length,
          computedStyles: {
            backgroundColor: cs.backgroundColor,
            color: cs.color,
            display: cs.display,
            borderRadius: cs.borderRadius,
            padding: cs.padding
          }
        };
      }

      // Listen for browser automation & verification actions
      window.addEventListener('message', function(event) {
        if (!event.data) return;

        if (event.data.type === 'PING_HEALTH') {
          const rootEl = document.getElementById('root');
          const isMounted = rootEl && rootEl.children && rootEl.children.length > 0;
          const count = document.querySelectorAll('*').length;
          const diagnostics = getStyleDiagnostics();

          sendToParent('HEALTH_PONG', {
            running: true,
            mounted: !!isMounted,
            elementsCount: count,
            diagnostics: diagnostics,
            timestamp: Date.now()
          });
          return;
        }

        if (event.data.type === 'GET_STYLE_DIAGNOSTICS') {
          const diag = getStyleDiagnostics();
          sendToParent('STYLE_DIAGNOSTICS', diag);
          return;
        }

        const { id, action, selector, value } = event.data;
        if (!action) return;

        try {
          if (action === 'click') {
            const el = document.querySelector(selector);
            if (el) {
              el.click();
              sendToParent('AUTOMATION_RESULT', { id, success: true, message: 'Clicked ' + selector });
            } else {
              sendToParent('AUTOMATION_RESULT', { id, success: false, message: 'Element not found for click: ' + selector });
            }
          } else if (action === 'type') {
            const el = document.querySelector(selector);
            if (el) {
              el.value = value || '';
              el.dispatchEvent(new Event('input', { bubbles: true }));
              el.dispatchEvent(new Event('change', { bubbles: true }));
              sendToParent('AUTOMATION_RESULT', { id, success: true, message: 'Typed into ' + selector });
            } else {
              sendToParent('AUTOMATION_RESULT', { id, success: false, message: 'Element not found for typing: ' + selector });
            }
          } else if (action === 'assert_element') {
            const el = document.querySelector(selector);
            if (el) {
              sendToParent('AUTOMATION_RESULT', { id, success: true, message: 'Element mounted: ' + selector });
            } else {
              sendToParent('AUTOMATION_RESULT', { id, success: false, message: 'Element assertion missing: ' + selector });
            }
          } else if (action === 'get_dom_snapshot') {
            sendToParent('DOM_SNAPSHOT', {
              title: document.title,
              bodyHtml: document.body.innerHTML.slice(0, 2500),
              elementsCount: document.querySelectorAll('*').length
            });
          }
        } catch (err) {
          sendToParent('AUTOMATION_RESULT', { id, success: false, message: 'Execution error: ' + err.message });
        }
      });
    })();
  </script>
</head>
<body>
  <div id="root"></div>

  <!-- Multi-File Virtual Module Loader & Execution Sandbox -->
  <script id="__godex_files__" type="application/json">
${virtualFilesJson.replace(/</g, '\\u003c')}
  </script>

  <script>
    try {
      var filesDataEl = document.getElementById('__godex_files__');
      window.__allFiles = filesDataEl ? JSON.parse(filesDataEl.textContent || '{}') : {};
    } catch (e) {
      window.__allFiles = {};
    }

    window.__initCodexPreview = function() {
      try {
        const React = window.React;
        const ReactDOM = window.ReactDOM;
        if (!React || !ReactDOM) {
          throw new Error('React or ReactDOM not loaded in sandbox preview');
        }

        // Dynamic Lucide React Icon Generator
        function createLucideIcon(iconName) {
          const IconComp = function(props) {
            props = props || {};
            const size = props.size || props.width || 16;
            const strokeWidth = props.strokeWidth || 2;
            const color = props.color || 'currentColor';
            const className = props.className || '';
            const style = props.style || {};

            // Check if lucide icons library is available on window
            if (window.lucide && window.lucide.icons) {
              const kebabName = iconName.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
              const iconDef = window.lucide.icons[iconName] || window.lucide.icons[kebabName] || window.lucide.icons[iconName.toLowerCase()];
              if (iconDef && Array.isArray(iconDef)) {
                const children = iconDef.filter(Boolean).map(function(item, idx) {
                  if (!item) return null;
                  const tag = Array.isArray(item) ? (item[0] || 'path') : (item.tag || 'path');
                  const attrs = Array.isArray(item) ? (item[1] || {}) : (item.attrs || {});
                  return React.createElement(tag, Object.assign({ key: idx }, attrs));
                }).filter(Boolean);
                return React.createElement('svg', Object.assign({
                  xmlns: 'http://www.w3.org/2000/svg',
                  width: size,
                  height: size,
                  viewBox: '0 0 24 24',
                  fill: 'none',
                  stroke: color,
                  strokeWidth: strokeWidth,
                  strokeLinecap: 'round',
                  strokeLinejoin: 'round',
                  className: className,
                  style: style
                }, props), children);
              }
            }

            // Fallback clean geometric icon
            return React.createElement('svg', Object.assign({
              xmlns: 'http://www.w3.org/2000/svg',
              width: size,
              height: size,
              viewBox: '0 0 24 24',
              fill: 'none',
              stroke: color,
              strokeWidth: strokeWidth,
              strokeLinecap: 'round',
              strokeLinejoin: 'round',
              className: className,
              style: style
            }, props),
              React.createElement('circle', { cx: 12, cy: 12, r: 8 }),
              React.createElement('path', { d: 'M12 8v8M8 12h8' })
            );
          };
          IconComp.displayName = iconName;
          return IconComp;
        }

        const iconCache = {};
        const IconProxy = new Proxy({}, {
          get: function(target, prop) {
            if (typeof prop !== 'string') return undefined;
            if (prop === '__esModule') return true;
            if (prop === 'default') return IconProxy;
            if (!iconCache[prop]) {
              iconCache[prop] = createLucideIcon(prop);
            }
            return iconCache[prop];
          }
        });

        // Virtual Module Cache
        const motionProxy = new Proxy({}, {
          get: function(target, prop) {
            if (prop === '__esModule') return true;
            if (prop === 'default') return motionProxy;
            if (prop === 'AnimatePresence') return function(p) { return p ? p.children : null; };
            return function(props) {
              props = props || {};
              const tag = typeof prop === 'string' && prop !== 'motion' ? prop : 'div';
              const cleanProps = Object.assign({}, props);
              delete cleanProps.initial;
              delete cleanProps.animate;
              delete cleanProps.exit;
              delete cleanProps.transition;
              delete cleanProps.whileHover;
              delete cleanProps.whileTap;
              return React.createElement(tag, cleanProps, props.children);
            };
          }
        });

        const rechartsProxy = new Proxy({}, {
          get: function(target, prop) {
            if (prop === '__esModule') return true;
            if (prop === 'default') return rechartsProxy;
            return function(props) {
              props = props || {};
              return React.createElement('div', {
                className: 'recharts-wrapper relative w-full h-full min-h-[140px] ' + (props.className || ''),
                style: props.style || {}
              }, props.children);
            };
          }
        });

        const moduleCache = {
          'react': { default: React, ...React },
          'react-dom': { default: ReactDOM, ...ReactDOM, createRoot: ReactDOM.createRoot },
          'react-dom/client': { default: ReactDOM, ...ReactDOM, createRoot: ReactDOM.createRoot },
          'lucide-react': IconProxy,
          'recharts': rechartsProxy,
          'clsx': { default: function(...args) { return args.flat().filter(Boolean).join(' '); }, clsx: function(...args) { return args.flat().filter(Boolean).join(' '); } },
          'tailwind-merge': { twMerge: function(...args) { return args.flat().filter(Boolean).join(' '); } },
          'canvas-confetti': { default: function() {}, confetti: function() {} },
          'framer-motion': {
            motion: motionProxy,
            AnimatePresence: function(p) { return p ? p.children : null; },
            useReducedMotion: function() { return false; },
            useAnimation: function() { return { start: function() { return Promise.resolve(); }, stop: function() {} }; },
            useMotionValue: function(v) { return { get: function() { return v; }, set: function() {}, onChange: function() { return function() {}; } }; },
            useSpring: function(v) { return { get: function() { return v; }, set: function() {} }; },
            useTransform: function(v, fn) { return { get: function() { return typeof fn === 'function' ? fn(typeof v === 'object' && v && v.get ? v.get() : v) : v; } }; },
            useInView: function() { return true; },
            useScroll: function() { return { scrollY: { get: function() { return 0; } }, scrollYProgress: { get: function() { return 0; } } }; },
            default: { motion: motionProxy }
          },
          'motion/react': {
            motion: motionProxy,
            AnimatePresence: function(p) { return p ? p.children : null; },
            useReducedMotion: function() { return false; },
            useAnimation: function() { return { start: function() { return Promise.resolve(); }, stop: function() {} }; },
            useMotionValue: function(v) { return { get: function() { return v; }, set: function() {}, onChange: function() { return function() {}; } }; },
            useSpring: function(v) { return { get: function() { return v; }, set: function() {} }; },
            useTransform: function(v, fn) { return { get: function() { return typeof fn === 'function' ? fn(typeof v === 'object' && v && v.get ? v.get() : v) : v; } }; },
            useInView: function() { return true; },
            useScroll: function() { return { scrollY: { get: function() { return 0; } }, scrollYProgress: { get: function() { return 0; } } }; },
            default: { motion: motionProxy }
          },
          'motion': {
            motion: motionProxy,
            AnimatePresence: function(p) { return p ? p.children : null; },
            useReducedMotion: function() { return false; },
            useAnimation: function() { return { start: function() { return Promise.resolve(); }, stop: function() {} }; },
            useMotionValue: function(v) { return { get: function() { return v; }, set: function() {}, onChange: function() { return function() {}; } }; },
            useSpring: function(v) { return { get: function() { return v; }, set: function() {} }; },
            useTransform: function(v, fn) { return { get: function() { return typeof fn === 'function' ? fn(typeof v === 'object' && v && v.get ? v.get() : v) : v; } }; },
            useInView: function() { return true; },
            useScroll: function() { return { scrollY: { get: function() { return 0; } }, scrollYProgress: { get: function() { return 0; } } }; },
            default: { motion: motionProxy }
          }
        };

        function findFileContent(reqPath, currentDir) {
          const files = window.__allFiles || {};
          let target = reqPath.startsWith('./') ? reqPath.slice(2) : reqPath;
          
          if (currentDir && reqPath.startsWith('./')) {
            target = currentDir + '/' + reqPath.slice(2);
          } else if (currentDir && reqPath.startsWith('../')) {
            const parts = currentDir.split('/');
            parts.pop();
            target = (parts.length > 0 ? parts.join('/') + '/' : '') + reqPath.slice(3);
          }

          const cleanTarget = target.replace(/^\\/+/, '');

          const candidates = [
            cleanTarget,
            'src/' + cleanTarget,
            cleanTarget + '.tsx',
            cleanTarget + '.ts',
            cleanTarget + '.jsx',
            cleanTarget + '.js',
            'src/' + cleanTarget + '.tsx',
            'src/' + cleanTarget + '.ts',
            'src/' + cleanTarget + '.jsx',
            'src/' + cleanTarget + '.js',
            cleanTarget + '/index.tsx',
            cleanTarget + '/index.ts',
            'src/' + cleanTarget + '/index.tsx'
          ];

          for (const c of candidates) {
            if (typeof files[c] === 'string') {
              return { path: c, content: files[c] };
            }
          }
          return null;
        }

        function virtualRequire(reqPath, currentDir) {
          if (moduleCache[reqPath]) {
            return moduleCache[reqPath];
          }

          if (reqPath === 'react') return moduleCache['react'];
          if (reqPath === 'react-dom' || reqPath === 'react-dom/client') return moduleCache['react-dom'];
          if (reqPath === 'lucide-react') return moduleCache['lucide-react'];
          if (reqPath === 'canvas-confetti') return moduleCache['canvas-confetti'];

          // Strip CSS imports
          if (reqPath.endsWith('.css')) return {};

          const found = findFileContent(reqPath, currentDir);
          if (!found) {
            console.warn('[VirtualModuleLoader] Module not found in virtual filesystem:', reqPath);
            return {};
          }

          if (moduleCache[found.path]) {
            return moduleCache[found.path];
          }

          // Transpile with Babel using env preset
          let transpiled = '';
          try {
            if (window.Babel) {
              transpiled = window.Babel.transform(found.content, {
                presets: ['env', 'react', 'typescript'],
                filename: found.path
              }).code;
            } else {
              throw new Error('Babel compiler not available');
            }
          } catch (babelErr) {
            const errStr = String(babelErr && babelErr.message ? babelErr.message : babelErr);
            const lineMatch = errStr.match(/\\((\\d+):(\\d+)\\)/);
            const line = lineMatch ? parseInt(lineMatch[1], 10) : (babelErr.loc ? babelErr.loc.line : 1);
            const column = lineMatch ? parseInt(lineMatch[2], 10) : (babelErr.loc ? babelErr.loc.column : 1);
            const fileLines = (found.content || '').split(/\\r?\\n/);
            const codeSnippet = babelErr.codeFrame || fileLines.slice(Math.max(0, line - 3), line + 2).join(String.fromCharCode(10));

            window.parent.postMessage({
              type: 'SANDBOX_BUILD_ERROR',
              payload: {
                file: found.path,
                line: line,
                column: column,
                message: errStr.replace(/:\\s*\\(\\d+:\\d+\\)/, ''),
                codeSnippet: codeSnippet,
                rawError: errStr
              }
            }, '*');
            throw babelErr;
          }

          const moduleObj = { exports: {} };
          const fileDir = found.path.includes('/') ? found.path.substring(0, found.path.lastIndexOf('/')) : '';

          const localRequire = function(p) {
            return virtualRequire(p, fileDir);
          };

          const fn = new Function('exports', 'require', 'module', 'React', 'ReactDOM', 'IconProxy', transpiled);
          fn(moduleObj.exports, localRequire, moduleObj, React, ReactDOM, IconProxy);

          const finalExport = moduleObj.exports;
          moduleCache[found.path] = finalExport;
          return finalExport;
        }

        // Determine Entry Component
        const files = window.__allFiles || {};
        const entryPath = files['src/App.tsx'] ? 'src/App.tsx' : (files['src/App.jsx'] ? 'src/App.jsx' : (files['App.tsx'] ? 'App.tsx' : null));

        if (!entryPath) {
          const firstKey = Object.keys(files).find(k => k.endsWith('.tsx') || k.endsWith('.jsx'));
          if (!firstKey) {
            throw new Error('No .tsx or .jsx entry point found in project workspace');
          }
        }

        const actualEntry = entryPath || Object.keys(files).find(k => k.endsWith('.tsx') || k.endsWith('.jsx'));
        const entryExports = virtualRequire(actualEntry, 'src');

        let AppComp = (entryExports && entryExports.default) ? entryExports.default : (entryExports && entryExports.App ? entryExports.App : entryExports);

        // Fallback: If AppComp is an object with a default key or only one function export
        if (AppComp && typeof AppComp === 'object' && typeof AppComp.default === 'function') {
          AppComp = AppComp.default;
        } else if (AppComp && typeof AppComp === 'object') {
          const functionKey = Object.keys(AppComp).find(k => typeof AppComp[k] === 'function');
          if (functionKey) AppComp = AppComp[functionKey];
        }

        // Custom Error Boundary Component
        class SandboxErrorBoundary extends React.Component {
          constructor(props) {
            super(props);
            this.state = { hasError: false, error: null };
          }
          static getDerivedStateFromError(error) {
            return { hasError: true, error: error };
          }
          componentDidCatch(error, errorInfo) {
            console.error('React Component Error:', error, errorInfo);
            window.parent.postMessage({
              type: 'SANDBOX_ERROR',
              payload: {
                level: 'react_runtime_error',
                message: error ? (error.message || String(error)) : 'React Runtime Error',
                stack: error ? error.stack : undefined,
                componentStack: errorInfo ? errorInfo.componentStack : undefined,
                domSnippet: document.body ? document.body.innerHTML.substring(0, 300) : ''
              }
            }, '*');
          }
          render() {
            if (this.state.hasError) {
              return React.createElement('div', {
                className: 'p-6 text-rose-400 font-mono text-xs bg-rose-950/50 border border-rose-800 rounded-lg m-4 shadow-xl'
              },
                React.createElement('div', { className: 'font-bold text-sm text-rose-300 mb-2' }, '⚠️ Runtime Error in Component Tree'),
                React.createElement('div', { className: 'whitespace-pre-wrap' }, this.state.error ? (this.state.error.message || String(this.state.error)) : 'Unknown component failure'),
                React.createElement('div', { className: 'mt-3 text-[10px] text-neutral-400' }, 'Check source files in Code Editor or use Self-Healing Debugger.')
              );
            }
            return this.props.children;
          }
        }

        const rootEl = document.getElementById('root');
        if (rootEl) {
          const root = ReactDOM.createRoot(rootEl);
          if (typeof AppComp === 'function' || (typeof AppComp === 'object' && AppComp !== null && React.isValidElement(React.createElement(AppComp)))) {
            root.render(
              React.createElement(SandboxErrorBoundary, null, React.createElement(AppComp))
            );
            window.__isMounted = true;
            setTimeout(() => {
              if (window.__twEngine) {
                window.__twEngine.process(document.body);
              }
              const nodeCount = document.querySelectorAll('*').length;
              window.parent.postMessage({
                type: 'SANDBOX_READY',
                payload: {
                  mounted: true,
                  elementsCount: nodeCount,
                  entry: actualEntry
                }
              }, '*');
            }, 60);
          } else {
            root.render(React.createElement('div', { className: 'p-6 text-rose-400 font-mono text-sm' },
              'No valid React default export found in ' + actualEntry + '. Please ensure "export default function App()" is present.'
            ));
          }
        }
      } catch (err) {
        console.error('Render Fatal Error:', err);
        const rootEl = document.getElementById('root');
        if (rootEl) {
          rootEl.innerHTML = '<div class="p-6 text-rose-400 font-mono text-xs bg-rose-950/40 border border-rose-800/80 rounded m-4"><b>Runtime / Compilation Error:</b><br/>' + (err.message || String(err)) + '</div>';
        }
        window.parent.postMessage({
          type: 'SANDBOX_ERROR',
          payload: { level: 'error', message: err.message || 'Render Fatal Error' }
        }, '*');
      }
    };

    var initAttempts = 0;
    function checkAndInitPreview() {
      if (window.React && window.ReactDOM && window.Babel) {
        window.__initCodexPreview();
      } else if (initAttempts < 30) {
        initAttempts++;
        setTimeout(checkAndInitPreview, 40);
      } else {
        window.__initCodexPreview();
      }
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function() {
        setTimeout(checkAndInitPreview, 20);
      });
    } else {
      setTimeout(checkAndInitPreview, 20);
    }
  </script>
  <script>
    // GODEX Visual Element Inspector Bridge
    (function() {
      let hoverOverlay = null;
      let isInspectActive = false;

      function createOverlay() {
        if (!hoverOverlay) {
          hoverOverlay = document.createElement('div');
          hoverOverlay.id = '__godex_inspect_overlay';
          hoverOverlay.style.cssText = 'position:fixed;pointer-events:none;border:2px solid #6366f1;background:rgba(99,102,241,0.15);z-index:999999;transition:all 0.05s ease;display:none;border-radius:4px;';
          var badge = document.createElement('div');
          badge.id = '__godex_inspect_badge';
          badge.style.cssText = 'position:absolute;top:-22px;left:0;background:#4f46e5;color:#fff;font-family:ui-monospace,monospace;font-size:10px;padding:2px 6px;border-radius:3px;white-space:nowrap;box-shadow:0 2px 4px rgba(0,0,0,0.5);';
          hoverOverlay.appendChild(badge);
          document.body.appendChild(hoverOverlay);
        }
      }

      window.addEventListener('message', function(e) {
        if (!e.data) return;
        if (e.data.type === 'SET_INSPECT_MODE') {
          isInspectActive = Boolean(e.data.payload && e.data.payload.active);
          createOverlay();
          if (!isInspectActive && hoverOverlay) {
            hoverOverlay.style.display = 'none';
          }
        }
      });

      document.addEventListener('mouseover', function(e) {
        if (!isInspectActive) return;
        var target = e.target;
        if (!target || target === hoverOverlay || target.id === '__godex_inspect_overlay') return;
        createOverlay();
        var rect = target.getBoundingClientRect();
        hoverOverlay.style.top = rect.top + 'px';
        hoverOverlay.style.left = rect.left + 'px';
        hoverOverlay.style.width = rect.width + 'px';
        hoverOverlay.style.height = rect.height + 'px';
        hoverOverlay.style.display = 'block';

        var badge = document.getElementById('__godex_inspect_badge');
        if (badge) {
          var tagName = target.tagName.toLowerCase();
          var classSnippet = target.className && typeof target.className === 'string' ? '.' + target.className.split(' ')[0] : '';
          badge.textContent = tagName + classSnippet + ' (' + Math.round(rect.width) + 'x' + Math.round(rect.height) + ')';
        }
      }, true);

      document.addEventListener('click', function(e) {
        if (!isInspectActive) return;
        e.preventDefault();
        e.stopPropagation();

        var target = e.target;
        if (!target) return;

        var computed = window.getComputedStyle(target);
        var rect = target.getBoundingClientRect();
        var parsePx = function(val) { return parseFloat(val) || 0; };

        var payload = {
          elementId: target.id || ('el_' + Math.random().toString(36).substr(2, 6)),
          tagName: target.tagName,
          className: typeof target.className === 'string' ? target.className : '',
          idAttr: target.id || undefined,
          textContent: (target.textContent || '').substring(0, 100),
          componentName: target.getAttribute('data-component') || undefined,
          computedStyles: {
            width: rect.width,
            height: rect.height,
            padding: {
              top: parsePx(computed.paddingTop),
              right: parsePx(computed.paddingRight),
              bottom: parsePx(computed.paddingBottom),
              left: parsePx(computed.paddingLeft)
            },
            margin: {
              top: parsePx(computed.marginTop),
              right: parsePx(computed.marginRight),
              bottom: parsePx(computed.marginBottom),
              left: parsePx(computed.marginLeft)
            },
            fontSize: computed.fontSize,
            fontWeight: computed.fontWeight,
            lineHeight: computed.lineHeight,
            letterSpacing: computed.letterSpacing,
            color: computed.color,
            backgroundColor: computed.backgroundColor,
            borderRadius: computed.borderRadius,
            border: computed.border,
            boxShadow: computed.boxShadow,
            opacity: computed.opacity,
            display: computed.display,
            flexDirection: computed.flexDirection,
            justifyContent: computed.justifyContent,
            alignItems: computed.alignItems,
            gap: computed.gap
          },
          accessibility: {
            role: target.getAttribute('role') || target.tagName.toLowerCase(),
            ariaLabel: target.getAttribute('aria-label') || undefined,
            contrastRatio: 4.5
          },
          hierarchy: {
            parentTag: target.parentElement ? target.parentElement.tagName.toLowerCase() : 'body',
            childrenCount: target.children.length,
            depth: 1
          }
        };

        window.parent.postMessage({
          type: 'VISUAL_ELEMENT_INSPECTED',
          payload: payload
        }, '*');
      }, true);
    })();
  </script>
</body>
</html>`;

    return bundleHtml;
  }
}
