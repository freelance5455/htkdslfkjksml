import { 
  AssetData, 
  ActiveVoiceAlert, 
  TriggeredAlertEvent, 
  GeminiMarketBriefing, 
  GeminiAssetAnalysis,
  GeminiSignal,
  PortfolioPosition,
  ThemeMode,
  AudioSettings
} from '../types/market';

export const DEFAULT_AUDIO_SETTINGS: AudioSettings = {
  volume: 0.9,
  rate: 1.05,
  pitch: 1.0,
  playChimeFirst: true,
  masterSoundEnabled: true,
  selectedPersona: 'fr-trader',
  systemNotificationsEnabled: false,
};

export function sendBrowserNotification(title: string, body: string) {
  if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: 'https://cdn-icons-png.flaticon.com/512/2953/2953363.png',
        tag: 'marketpulse-alert-' + Date.now(),
      });
    } catch (e) {
      console.warn('System notification dispatch notice:', e);
    }
  }
}

const STORAGE_KEYS = {
  ALERTS: 'marketpulse_active_alerts_v1',
  HISTORY: 'marketpulse_alert_history_v1',
  SETTINGS: 'marketpulse_audio_settings_v1',
  PORTFOLIO: 'marketpulse_portfolio_v1',
  WATCHLIST: 'marketpulse_watchlist_v1',
  THEME: 'marketpulse_theme_v1',
};

export async function fetchLiveMarketPrices(): Promise<AssetData[]> {
  const res = await fetch('/api/prices');
  if (!res.ok) {
    throw new Error(`Failed to fetch prices: ${res.statusText}`);
  }
  const data = await res.json();
  return data.assets || [];
}

export async function fetchGeminiBriefing(language: 'fr' | 'en' = 'fr'): Promise<GeminiMarketBriefing> {
  const res = await fetch('/api/gemini/briefing', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ language }),
  });
  if (!res.ok) {
    throw new Error('Failed to generate Gemini briefing');
  }
  const data = await res.json();
  return data.briefing;
}

export async function fetchGeminiAssetAnalysis(
  assetId: string, 
  language: 'fr' | 'en' = 'fr'
): Promise<GeminiAssetAnalysis> {
  const res = await fetch('/api/gemini/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ assetId, language }),
  });
  if (!res.ok) {
    throw new Error('Failed to analyze asset with Gemini');
  }
  const data = await res.json();
  return data.analysis;
}

export async function fetchGeminiSignals(language: 'fr' | 'en' = 'fr'): Promise<GeminiSignal[]> {
  const res = await fetch('/api/gemini/signals', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ language }),
  });
  if (!res.ok) {
    throw new Error('Failed to fetch Gemini signals');
  }
  const data = await res.json();
  return data.signals || [];
}

export async function fetchGeminiVoiceSuggestions(
  assetSymbol: string,
  targetPrice: number,
  condition: string,
  customIntent: string,
  language: 'fr' | 'en' = 'fr'
) {
  const res = await fetch('/api/gemini/voice-script', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ assetSymbol, targetPrice, condition, customIntent, language }),
  });
  if (!res.ok) {
    throw new Error('Failed to fetch voice suggestions');
  }
  const data = await res.json();
  return data.suggestions || [];
}

// LocalStorage helpers
export function loadSavedAlerts(): ActiveVoiceAlert[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ALERTS);
    if (!raw) return getDefaultStarterAlerts();
    return JSON.parse(raw);
  } catch {
    return getDefaultStarterAlerts();
  }
}

export function saveAlerts(alerts: ActiveVoiceAlert[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(alerts));
  } catch (e) {
    console.error('Failed to save alerts to localStorage', e);
  }
}

export function loadAlertHistory(): TriggeredAlertEvent[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.HISTORY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveAlertHistory(history: TriggeredAlertEvent[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history.slice(0, 50)));
  } catch (e) {
    console.error('Failed to save history', e);
  }
}

export function loadAudioSettings(): AudioSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return raw ? { ...DEFAULT_AUDIO_SETTINGS, ...JSON.parse(raw) } : DEFAULT_AUDIO_SETTINGS;
  } catch {
    return DEFAULT_AUDIO_SETTINGS;
  }
}

export function saveAudioSettings(settings: AudioSettings) {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save audio settings', e);
  }
}

export function loadThemeMode(): ThemeMode {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.THEME);
    return raw === 'light' ? 'light' : 'dark';
  } catch {
    return 'dark';
  }
}

export function saveThemeMode(theme: ThemeMode) {
  try {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  } catch (e) {
    console.error('Failed to save theme', e);
  }
}

export function loadWatchlist(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WATCHLIST);
    return raw ? JSON.parse(raw) : ['bitcoin', 'ethereum', 'solana', 'gold', 'nvda'];
  } catch {
    return ['bitcoin', 'ethereum', 'solana', 'gold', 'nvda'];
  }
}

export function saveWatchlist(watchlist: string[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.WATCHLIST, JSON.stringify(watchlist));
  } catch (e) {
    console.error('Failed to save watchlist', e);
  }
}

export function loadPortfolio(): PortfolioPosition[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PORTFOLIO);
    return raw ? JSON.parse(raw) : getDefaultPortfolio();
  } catch {
    return getDefaultPortfolio();
  }
}

export function savePortfolio(portfolio: PortfolioPosition[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.PORTFOLIO, JSON.stringify(portfolio));
  } catch (e) {
    console.error('Failed to save portfolio', e);
  }
}

function getDefaultPortfolio(): PortfolioPosition[] {
  return [
    {
      id: 'pos-1',
      assetId: 'bitcoin',
      symbol: 'BTC',
      name: 'Bitcoin',
      category: 'crypto',
      amount: 0.45,
      buyPrice: 88500,
      createdAt: Date.now() - 86400000 * 5,
    },
    {
      id: 'pos-2',
      assetId: 'ethereum',
      symbol: 'ETH',
      name: 'Ethereum',
      category: 'crypto',
      amount: 4.2,
      buyPrice: 3150,
      createdAt: Date.now() - 86400000 * 8,
    },
    {
      id: 'pos-3',
      assetId: 'solana',
      symbol: 'SOL',
      name: 'Solana',
      category: 'crypto',
      amount: 35.0,
      buyPrice: 172.5,
      createdAt: Date.now() - 86400000 * 3,
    },
    {
      id: 'pos-4',
      assetId: 'gold',
      symbol: 'XAU/USD',
      name: 'Gold (Oz)',
      category: 'commodity',
      amount: 2.5,
      buyPrice: 2680,
      createdAt: Date.now() - 86400000 * 14,
    },
    {
      id: 'pos-5',
      assetId: 'nvda',
      symbol: 'NVDA',
      name: 'NVIDIA Corp.',
      category: 'stock',
      amount: 25.0,
      buyPrice: 128.0,
      createdAt: Date.now() - 86400000 * 12,
    },
  ];
}

function getDefaultStarterAlerts(): ActiveVoiceAlert[] {
  return [
    {
      id: 'default-btc-high',
      assetId: 'bitcoin',
      assetSymbol: 'BTC',
      assetName: 'Bitcoin',
      condition: 'above',
      targetValue: 95500,
      baselinePrice: 94520,
      voiceScript: 'Cassure majeure sur Bitcoin ! Le cap des 95 500 dollars vient d\'être franchi.',
      soundChime: 'bullish',
      voicePersona: 'fr-trader',
      enabled: true,
      repeatMode: 'repeat',
      repeatIntervalMinutes: 5,
      repeatLimit: 3,
      screenAlertEffect: 'flash_strobe',
      sendSystemNotification: true,
      createdAt: Date.now() - 3600000,
      triggerCount: 0,
    },
    {
      id: 'default-eth-target',
      assetId: 'ethereum',
      assetSymbol: 'ETH',
      assetName: 'Ethereum',
      condition: 'above',
      targetValue: 3400,
      baselinePrice: 3320.5,
      voiceScript: 'Target reached on Ethereum. 3,400 dollars breached with high volume.',
      soundChime: 'kaching',
      voicePersona: 'en-trader',
      enabled: true,
      repeatMode: 'repeat',
      repeatIntervalMinutes: 5,
      repeatLimit: 5,
      screenAlertEffect: 'flash_strobe',
      sendSystemNotification: true,
      createdAt: Date.now() - 7200000,
      triggerCount: 0,
    },
    {
      id: 'default-gold-support',
      assetId: 'gold',
      assetSymbol: 'XAU/USD',
      assetName: 'Gold (Oz)',
      condition: 'below',
      targetValue: 2730,
      baselinePrice: 2742.6,
      voiceScript: 'Alerte support sur l\'Or. Repli sous les 2730 dollars l\'once.',
      soundChime: 'bearish',
      voicePersona: 'fr-trader',
      enabled: true,
      repeatMode: 'repeat',
      repeatIntervalMinutes: 1,
      repeatLimit: 3,
      screenAlertEffect: 'radar_ping',
      sendSystemNotification: true,
      createdAt: Date.now() - 10800000,
      triggerCount: 0,
    },
  ];
}
