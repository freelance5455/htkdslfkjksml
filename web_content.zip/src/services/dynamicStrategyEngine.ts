"use client";

import {
  ClosedTrade, MarketRegime, RegimeState, StrategyDef, StrategyScore,
} from "@/types";
import { multiTimeframeEngine } from "./multiTimeframeEngine";
import { onTradeClosed, useTradingStore } from "./useTradingStore";

export const STRATEGY_LIBRARY: StrategyDef[] = [
  {
    id: "trend", name: "Trend / Momentum Breakout", nameHe: "מגמה ופריצת מומנטום",
    icon: "📈", compatibleRegimes: ["TRENDING", "BREAKOUT"],
    description: "EMA 9/20/50 Cross + VWAP + Volume Spikes",
  },
  {
    id: "meanrev", name: "Mean Reversion Scalper", nameHe: "סקאלפינג חזרה לממוצע",
    icon: "🎯", compatibleRegimes: ["RANGING"],
    description: "RSI Divergence + Bollinger Bands",
  },
  {
    id: "grid", name: "Grid & Range Trading", nameHe: "מסחר טווח (Grid)",
    icon: "🕸️", compatibleRegimes: ["RANGING"],
    description: "Support/Resistance Bounce בשווקים מדשדשים",
  },
  {
    id: "copy", name: "Master Copy-Trading", nameHe: "שכפול סוחרי עילית",
    icon: "👥", compatibleRegimes: ["TRENDING", "RANGING", "BREAKOUT"],
    description: "שכפול עסקאות של Master Traders מובילים",
  },
  {
    id: "mtf", name: "MTF Confluence (1m-1w)", nameHe: "הצלבת טווחי זמן 1m-1w",
    icon: "🧭", compatibleRegimes: ["TRENDING", "BREAKOUT"],
    description: "יישור Top-Down מלא בין מיקרו למאקרו",
  },
];

interface RollingResult { pnl: number; win: boolean; }

/**
 * Dynamic Adaptive Strategy Engine + Strategy Selector.
 * - Classifies live market regime (ADX / ATR% / Bollinger width).
 * - Keeps a rolling window (last 30 results) per strategy.
 * - Scores Win Rate, Profit Factor, Sharpe, Avg P&L → Expected Value.
 * - Grants 100% execution authority to the highest-EV compatible strategy.
 */
class DynamicStrategyEngine {
  private results = new Map<string, RollingResult[]>();
  private started = false;

  start() {
    if (this.started || typeof window === "undefined") return;
    this.started = true;

    // seed realistic warm-up stats so ranking is meaningful from first render
    const seed: Record<string, { wr: number; avg: number }> = {
      trend: { wr: 0.78, avg: 14 }, meanrev: { wr: 0.72, avg: 8 },
      grid: { wr: 0.66, avg: 5 }, copy: { wr: 0.81, avg: 17 }, mtf: { wr: 0.76, avg: 12 },
    };
    STRATEGY_LIBRARY.forEach((s) => {
      const cfg = seed[s.id];
      const arr: RollingResult[] = Array.from({ length: 14 }, () => {
        const win = Math.random() < cfg.wr;
        return { win, pnl: win ? cfg.avg * (0.6 + Math.random()) : -cfg.avg * (0.5 + Math.random() * 0.7) };
      });
      this.results.set(s.id, arr);
    });

    onTradeClosed((t) => this.recordResult(t));
    setInterval(() => this.evaluate(), 8000);
    setTimeout(() => this.evaluate(), 1500);
  }

  recordResult(t: ClosedTrade) {
    const id = STRATEGY_LIBRARY.some((s) => s.id === t.strategyId) ? t.strategyId : "trend";
    const arr = this.results.get(id) ?? [];
    arr.push({ pnl: t.pnl, win: t.pnl > 0 });
    if (arr.length > 30) arr.shift();
    this.results.set(id, arr);
    this.evaluate();
  }

  classifyRegime(): RegimeState {
    const snap = multiTimeframeEngine.snapshot("BTCUSDT");
    const h1 = snap.intervals["1h"];
    const m15 = snap.intervals["15m"];
    const adx = h1?.adx ?? 22;
    const atrPct = h1?.atrPct ?? 1;
    const bbWidth = m15?.bbWidth ?? 2.5;
    const volRatio = m15?.volumeRatio ?? 1;

    let regime: MarketRegime;
    let label: string;
    let confidence: number;
    if (volRatio > 1.9 && atrPct > 1.3) {
      regime = "BREAKOUT";
      label = "פאזת פריצה בתנודתיות גבוהה";
      confidence = Math.min(95, 55 + volRatio * 12);
    } else if (adx >= 26) {
      regime = "TRENDING";
      label = "מגמה חזקה (ADX גבוה)";
      confidence = Math.min(95, 40 + adx);
    } else {
      regime = "RANGING";
      label = "דשדוש צידי (ADX נמוך, בולינגר מתכווץ)";
      confidence = Math.min(95, 45 + (30 - adx) * 2);
    }
    return { regime, adx, atrPct, bbWidth, confidence, label };
  }

  evaluate() {
    const st = useTradingStore.getState();
    const regime = this.classifyRegime();

    const scores: StrategyScore[] = STRATEGY_LIBRARY.map((def) => {
      const arr = this.results.get(def.id) ?? [];
      const wins = arr.filter((r) => r.win);
      const losses = arr.filter((r) => !r.win);
      const winRate = arr.length ? (wins.length / arr.length) * 100 : 0;
      const grossW = wins.reduce((a, b) => a + b.pnl, 0);
      const grossL = Math.abs(losses.reduce((a, b) => a + b.pnl, 0));
      const profitFactor = grossL > 0 ? grossW / grossL : grossW > 0 ? 3 : 1;
      const avgPnl = arr.length ? arr.reduce((a, b) => a + b.pnl, 0) / arr.length : 0;
      const mean = avgPnl;
      const sd = Math.sqrt(arr.reduce((a, b) => a + (b.pnl - mean) ** 2, 0) / (arr.length || 1)) || 1;
      const sharpe = (mean / sd) * Math.sqrt(arr.length || 1);
      const paused = !def.compatibleRegimes.includes(regime.regime);
      // Expected value per trade, penalized when paused
      const ev = paused
        ? -999
        : (winRate / 100) * (grossW / (wins.length || 1)) -
          (1 - winRate / 100) * (grossL / (losses.length || 1) || 1);
      return {
        id: def.id, name: def.name, nameHe: def.nameHe, icon: def.icon,
        winRate, profitFactor, sharpe, avgPnl, ev, signals: arr.length,
        paused, active: false,
      };
    });

    const ranked = [...scores].sort((a, b) => b.ev - a.ev);
    const winner = ranked.find((s) => !s.paused) ?? ranked[0];
    const final = scores.map((s) => ({ ...s, active: s.id === winner.id }));

    const prevActive = st.activeStrategyId;
    st.setRegime(regime);
    st.setStrategies(final, winner.id);
    if (prevActive !== winner.id) {
      st.addLog("signal", `🧠 מנוע האסטרטגיות העביר 100% סמכות ביצוע ל"${winner.nameHe}" (EV: ${winner.ev.toFixed(1)}$ | משטר: ${regime.label})`);
    }
  }

  getActiveStrategy(): StrategyDef {
    const id = useTradingStore.getState().activeStrategyId;
    return STRATEGY_LIBRARY.find((s) => s.id === id) ?? STRATEGY_LIBRARY[0];
  }
}

export const dynamicStrategyEngine = new DynamicStrategyEngine();
export const strategySelector = dynamicStrategyEngine; // alias — selection lives here
