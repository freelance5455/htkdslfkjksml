export interface RandomLinkItem {
  id: string;
  title: string;
  category: string;
  url: string;
  domain: string;
  minCoins: number;
  maxCoins: number;
  iconBg: string;
  description: string;
}

export const TOTAL_LINKS_CATALOG_COUNT = 100000;
export const WATCH_TIME_5_MINUTES_SECONDS = 300; // 5 minutes as requested

export const RANDOM_LINKS_CATALOG: RandomLinkItem[] = [
  {
    id: 'link-1',
    title: 'TechCrunch AI & Startup News',
    category: 'Technology',
    url: 'https://techcrunch.com',
    domain: 'techcrunch.com',
    minCoins: 25,
    maxCoins: 75,
    iconBg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    description: 'Explore trending venture capital news, AI startup launches, and gadget reviews.'
  },
  {
    id: 'link-2',
    title: 'Product Hunt Daily Discoveries',
    category: 'Productivity',
    url: 'https://producthunt.com',
    domain: 'producthunt.com',
    minCoins: 30,
    maxCoins: 90,
    iconBg: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    description: 'Discover best new software, productivity tools, and browser extensions.'
  },
  {
    id: 'link-3',
    title: 'GitHub Trending Repositories',
    category: 'Coding & Dev',
    url: 'https://github.com/trending',
    domain: 'github.com',
    minCoins: 35,
    maxCoins: 100,
    iconBg: 'bg-slate-700/30 text-white border-slate-600',
    description: 'Check out today’s most popular open-source repositories and AI code libraries.'
  },
  {
    id: 'link-4',
    title: 'Hacker News Tech Frontpage',
    category: 'Tech & Community',
    url: 'https://news.ycombinator.com',
    domain: 'news.ycombinator.com',
    minCoins: 20,
    maxCoins: 65,
    iconBg: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    description: 'Community discussions on software architecture, science, and engineering.'
  },
  {
    id: 'link-5',
    title: 'Dev.to Software Engineering Articles',
    category: 'Coding',
    url: 'https://dev.to',
    domain: 'dev.to',
    minCoins: 25,
    maxCoins: 80,
    iconBg: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
    description: 'Read insightful tutorials and career advice written by software developers worldwide.'
  },
  {
    id: 'link-6',
    title: 'ArXiv AI & Machine Learning Papers',
    category: 'Science',
    url: 'https://arxiv.org/list/cs.AI/recent',
    domain: 'arxiv.org',
    minCoins: 40,
    maxCoins: 110,
    iconBg: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    description: 'Browse the latest pre-print research on deep learning, neural networks, and LLMs.'
  },
  {
    id: 'link-7',
    title: 'Unsplash Free High-Resolution Wallpapers',
    category: 'Design & Media',
    url: 'https://unsplash.com',
    domain: 'unsplash.com',
    minCoins: 20,
    maxCoins: 70,
    iconBg: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
    description: 'Browse creative photography, 4K nature backgrounds, and designer assets.'
  },
  {
    id: 'link-8',
    title: 'CoinMarketCap Crypto Price Indexes',
    category: 'Finance',
    url: 'https://coinmarketcap.com',
    domain: 'coinmarketcap.com',
    minCoins: 30,
    maxCoins: 85,
    iconBg: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    description: 'Track live Bitcoin, Ethereum, and crypto market capitalization rankings.'
  }
];

export function getRandomLink(): RandomLinkItem {
  const index = Math.floor(Math.random() * RANDOM_LINKS_CATALOG.length);
  return RANDOM_LINKS_CATALOG[index];
}

export function rollRandomReward(min: number = 20, max: number = 85): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
