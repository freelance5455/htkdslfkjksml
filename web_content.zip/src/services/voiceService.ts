/**
 * Voice Service (Speech Synthesis & Recognition)
 * 
 * Features:
 * - Real browser microphone permission check via navigator.mediaDevices.getUserMedia
 * - Multilingual SpeechRecognition (Hindi 'hi-IN', Hinglish 'en-IN', English 'en-US')
 * - Full state lifecycle (idle, requesting_permission, listening, processing, permission_denied, unsupported, error)
 * - Interim + Final recognition results for real-time speech preview
 * - Audio synthesis (TTS) for companion voice responses
 */

import { SpeechLanguageCode, SpeechRecognitionState } from '../types';

export interface VoiceCapabilities {
  synthesisSupported: boolean;
  recognitionSupported: boolean;
  status: string;
}

export interface SpeechRecognitionOptions {
  lang?: SpeechLanguageCode;
  continuous?: boolean;
  onStateChange?: (state: SpeechRecognitionState, errorDetail?: string) => void;
  onInterimTranscript?: (interim: string) => void;
  onFinalTranscript?: (finalText: string) => void;
  onError?: (state: SpeechRecognitionState, errorMessage: string) => void;
  onEnd?: () => void;
}

class VoiceManager {
  private static instance: VoiceManager;
  private synth: SpeechSynthesis | null = null;
  private activeRecognition: any = null;
  private isSpeaking = false;
  private isListeningActive = false;
  private onSpeakingChangeCallbacks: Array<(speaking: boolean) => void> = [];

  private constructor() {
    if (typeof window !== 'undefined') {
      if ('speechSynthesis' in window) {
        this.synth = window.speechSynthesis;
      }
    }
  }

  public static getInstance(): VoiceManager {
    if (!VoiceManager.instance) {
      VoiceManager.instance = new VoiceManager();
    }
    return VoiceManager.instance;
  }

  /**
   * Check if the browser supports Speech Recognition
   */
  public isRecognitionSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return Boolean(
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition
    );
  }

  /**
   * Check if speech synthesis is supported
   */
  public isSynthesisSupported(): boolean {
    return Boolean(this.synth);
  }

  public getCapabilities(): VoiceCapabilities {
    const recSupported = this.isRecognitionSupported();
    const synthSupported = this.isSynthesisSupported();

    return {
      synthesisSupported: synthSupported,
      recognitionSupported: recSupported,
      status: recSupported
        ? (synthSupported ? 'Full Voice I/O (Web Speech API)' : 'Voice Input Only')
        : (synthSupported ? 'Voice Output Only' : 'Web Speech APIs not supported in this browser'),
    };
  }

  /**
   * Explicitly requests real browser microphone permission via getUserMedia
   */
  public async requestMicrophonePermission(): Promise<'granted' | 'denied' | 'unsupported'> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      // Some browsers might support webkitSpeechRecognition even if getUserMedia is restricted
      return this.isRecognitionSupported() ? 'granted' : 'unsupported';
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Stop media tracks immediately so the microphone is freed for SpeechRecognition
      stream.getTracks().forEach((track) => track.stop());
      return 'granted';
    } catch (err: any) {
      console.warn('[002 Voice] Microphone permission error:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        return 'denied';
      }
      return 'denied';
    }
  }

  /**
   * Queries real browser permission status via navigator.permissions.query
   */
  public async queryMicrophonePermissionStatus(): Promise<{
    state: 'granted' | 'denied' | 'prompt' | 'unsupported';
    hasPermissionsApi: boolean;
  }> {
    if (typeof navigator === 'undefined') {
      return { state: 'unsupported', hasPermissionsApi: false };
    }

    if (navigator.permissions && navigator.permissions.query) {
      try {
        const permissionStatus = await navigator.permissions.query({
          name: 'microphone' as PermissionName,
        });
        return {
          state: permissionStatus.state as 'granted' | 'denied' | 'prompt',
          hasPermissionsApi: true,
        };
      } catch (e) {
        // Some browsers don't support { name: 'microphone' } in query()
        console.warn('[002 Voice] navigator.permissions.query error:', e);
      }
    }

    if (!navigator.mediaDevices?.getUserMedia && !this.isRecognitionSupported()) {
      return { state: 'unsupported', hasPermissionsApi: false };
    }

    return { state: 'prompt', hasPermissionsApi: false };
  }

  /**
   * Determines if browser supports opening permission settings directly.
   * Standard web pages are sandboxed and cannot navigate to chrome://settings or system intents.
   * Native Android wrappers can invoke ACTION_APPLICATION_DETAILS_SETTINGS.
   */
  public checkCanDirectlyOpenSettings(): {
    canDirectlyOpen: boolean;
    isNativeAndroid: boolean;
    reason: string;
  } {
    if (typeof window !== 'undefined' && window.Android002Bridge?.openAppSettings) {
      return {
        canDirectlyOpen: true,
        isNativeAndroid: true,
        reason: 'Native Android bridge detected: can trigger ACTION_APPLICATION_DETAILS_SETTINGS.',
      };
    }

    return {
      canDirectlyOpen: false,
      isNativeAndroid: false,
      reason: 'Web Browser Sandbox: Browsers intentionally block web apps from launching browser settings or device intents.',
    };
  }

  /**
   * Starts speech recognition with multilingual support and interim updates
   */
  public async startListening(options: SpeechRecognitionOptions): Promise<boolean> {
    const {
      lang = 'en-IN',
      continuous = false,
      onStateChange,
      onInterimTranscript,
      onFinalTranscript,
      onError,
      onEnd,
    } = options;

    if (!this.isRecognitionSupported()) {
      onStateChange?.('unsupported', 'Speech recognition is not supported in this browser engine.');
      onError?.('unsupported', 'Your browser does not support Web Speech Recognition. Please try Chrome, Edge, or Safari.');
      return false;
    }

    // Stop any existing session
    this.stopListening();

    // Notify requesting permission
    onStateChange?.('requesting_permission');

    // Verify microphone hardware permission
    const permResult = await this.requestMicrophonePermission();
    if (permResult === 'denied') {
      onStateChange?.('permission_denied', 'Microphone permission denied by browser.');
      onError?.('permission_denied', 'Microphone access was denied. Please allow microphone permissions in your browser URL bar.');
      return false;
    }

    try {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      const recognition = new SpeechRecognition();
      this.activeRecognition = recognition;

      recognition.continuous = continuous;
      recognition.interimResults = true;
      recognition.lang = lang;
      recognition.maxAlternatives = 1;

      let accumulatedFinal = '';

      recognition.onstart = () => {
        this.isListeningActive = true;
        onStateChange?.('listening');
      };

      recognition.onresult = (event: any) => {
        let interimText = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const result = event.results[i];
          const transcript = result[0]?.transcript || '';

          if (result.isFinal) {
            accumulatedFinal += (accumulatedFinal ? ' ' : '') + transcript.trim();
          } else {
            interimText += transcript;
          }
        }

        if (interimText) {
          onInterimTranscript?.(interimText);
        }

        if (accumulatedFinal) {
          onFinalTranscript?.(accumulatedFinal);
        }
      };

      recognition.onerror = (event: any) => {
        const errorType = event.error || 'unknown';
        console.warn('[002 Voice] Speech recognition error event:', errorType);

        if (errorType === 'not-allowed' || errorType === 'service-not-allowed') {
          onStateChange?.('permission_denied', 'Microphone permission denied.');
          onError?.('permission_denied', 'Microphone permission was blocked. Please enable it in browser settings.');
        } else if (errorType === 'no-speech') {
          onStateChange?.('error', 'No speech was detected.');
          onError?.('error', 'No speech detected. Please speak closer to your microphone.');
        } else if (errorType === 'audio-capture') {
          onStateChange?.('error', 'No microphone detected.');
          onError?.('error', 'No microphone found or audio capture device failed.');
        } else if (errorType === 'network') {
          onStateChange?.('error', 'Network error during recognition.');
          onError?.('error', 'Network error occurred during speech-to-text processing.');
        } else if (errorType !== 'aborted') {
          onStateChange?.('error', `Speech error: ${errorType}`);
          onError?.('error', `Speech recognition error: ${errorType}`);
        }
      };

      recognition.onend = () => {
        this.isListeningActive = false;
        this.activeRecognition = null;
        onEnd?.();
      };

      recognition.start();
      return true;
    } catch (err: any) {
      console.warn('[002 Voice] Failed to start SpeechRecognition:', err);
      onStateChange?.('error', err?.message || 'Failed to start microphone.');
      onError?.('error', err?.message || 'Could not start microphone session.');
      this.isListeningActive = false;
      this.activeRecognition = null;
      return false;
    }
  }

  /**
   * Halts active speech recognition session
   */
  public stopListening(): void {
    if (this.activeRecognition) {
      try {
        this.activeRecognition.stop();
      } catch (e) {
        try {
          this.activeRecognition.abort();
        } catch {}
      }
      this.activeRecognition = null;
      this.isListeningActive = false;
    }
  }

  public isListening(): boolean {
    return this.isListeningActive;
  }

  /**
   * Speaks text using speech synthesis
   */
  public speak(text: string, onEnd?: () => void): boolean {
    if (!this.synth) return false;

    try {
      this.synth.cancel();
      const cleanText = text.replace(/[*_#`~]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanText);

      const voices = this.synth.getVoices();
      const preferredVoice = voices.find(
        (v) =>
          (v.name.includes('Samantha') ||
            v.name.includes('Google UK English Female') ||
            v.name.includes('Zira') ||
            v.name.includes('Female')) &&
          v.lang.startsWith('en')
      );
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      utterance.pitch = 1.15;
      utterance.rate = 1.05;

      utterance.onstart = () => {
        this.setSpeaking(true);
      };

      utterance.onend = () => {
        this.setSpeaking(false);
        onEnd?.();
      };

      utterance.onerror = () => {
        this.setSpeaking(false);
      };

      this.synth.speak(utterance);
      return true;
    } catch (e) {
      console.warn('[002 Voice] Speak error:', e);
      this.setSpeaking(false);
      return false;
    }
  }

  public stopSpeaking(): void {
    if (this.synth) {
      this.synth.cancel();
      this.setSpeaking(false);
    }
  }

  public onSpeakingChange(cb: (speaking: boolean) => void): () => void {
    this.onSpeakingChangeCallbacks.push(cb);
    return () => {
      this.onSpeakingChangeCallbacks = this.onSpeakingChangeCallbacks.filter((c) => c !== cb);
    };
  }

  private setSpeaking(speaking: boolean) {
    this.isSpeaking = speaking;
    this.onSpeakingChangeCallbacks.forEach((cb) => cb(speaking));
  }
}

export const voiceService = VoiceManager.getInstance();
