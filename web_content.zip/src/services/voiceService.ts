/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LanguageCode, VoiceModeState } from '../types/assistant';

interface IWindow extends Window {
  webkitSpeechRecognition?: any;
  SpeechRecognition?: any;
  webkitAudioContext?: typeof AudioContext;
}

export type VoiceStateChangeCallback = (state: VoiceModeState, errorMsg?: string) => void;
export type TranscriptCallback = (transcript: string, isFinal: boolean) => void;

export class VoiceService {
  private recognition: any = null;
  private synthesis: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  // Audio Context & Analyser for real-time waveform visualization
  private audioCtx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private analyser: AnalyserNode | null = null;
  private dataArray: Uint8Array | null = null;

  // Continuous Voice State Management
  private isContinuousMode = false;
  private voiceState: VoiceModeState = 'OFF';
  private currentSessionId = 0;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectTimer: number | null = null;

  // Callbacks
  private onStateChangeCallback: VoiceStateChangeCallback | null = null;
  private onTranscriptCallback: TranscriptCallback | null = null;
  private activeLanguage: LanguageCode = 'en-US';

  constructor() {
    if (typeof window !== 'undefined') {
      const win = window as unknown as IWindow;
      const SpeechRecognitionClass = win.SpeechRecognition || win.webkitSpeechRecognition;
      if (SpeechRecognitionClass) {
        this.recognition = new SpeechRecognitionClass();
        this.recognition.continuous = false; // We manage restarts explicitly to prevent browser stall
        this.recognition.interimResults = true;
        this.recognition.maxAlternatives = 1;
      }
      if ('speechSynthesis' in window) {
        this.synthesis = window.speechSynthesis;
      }
    }
  }

  public isSpeechRecognitionSupported(): boolean {
    return this.recognition !== null;
  }

  public isSpeechSynthesisSupported(): boolean {
    return this.synthesis !== null;
  }

  public getVoiceState(): VoiceModeState {
    return this.voiceState;
  }

  public isContinuousActive(): boolean {
    return this.isContinuousMode;
  }

  private setVoiceState(newState: VoiceModeState, errorMsg?: string) {
    this.voiceState = newState;
    if (this.onStateChangeCallback) {
      this.onStateChangeCallback(newState, errorMsg);
    }
  }

  /**
   * Procedural UI chimes using Web Audio API (zero external assets).
   */
  public playProceduralChime(type: 'activate' | 'done' | 'alert' | 'listening'): void {
    try {
      if (!this.audioCtx) {
        const AudioContextClass = window.AudioContext || (window as unknown as IWindow).webkitAudioContext;
        if (AudioContextClass) {
          this.audioCtx = new AudioContextClass();
        }
      }
      if (!this.audioCtx) return;
      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }

      const now = this.audioCtx.currentTime;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      if (type === 'activate') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      } else if (type === 'listening') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(880, now + 0.08); // A5
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'done') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now);
        osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.1);
        osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.2);
        gain.gain.setValueAtTime(0.07, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'alert') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(240, now + 0.2);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      }
    } catch {
      // Audio context may be restricted before user gesture
    }
  }

  /**
   * Initializes microphone stream and analyser node for real visual waveforms.
   */
  private async initAudioAnalyser(): Promise<boolean> {
    try {
      if (!this.audioCtx) {
        const AudioContextClass = window.AudioContext || (window as unknown as IWindow).webkitAudioContext;
        if (AudioContextClass) {
          this.audioCtx = new AudioContextClass();
        }
      }
      if (this.audioCtx && this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }

      if (!this.micStream && navigator.mediaDevices?.getUserMedia) {
        this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        if (this.audioCtx) {
          const source = this.audioCtx.createMediaStreamSource(this.micStream);
          this.analyser = this.audioCtx.createAnalyser();
          this.analyser.fftSize = 64;
          source.connect(this.analyser);
          this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
        }
      }
      return true;
    } catch (err) {
      console.warn('Microphone stream access not granted or not available for analyser:', err);
      return false;
    }
  }

  /**
   * Returns normalized audio level (0.0 to 1.0) from the microphone or synthesis.
   */
  public getLiveAudioLevel(): number {
    if (this.voiceState === 'SPEAKING') {
      // Natural speech modulation simulation during voice synthesis
      return 0.35 + Math.sin(Date.now() * 0.015) * 0.3 + Math.random() * 0.25;
    }

    if (this.voiceState === 'LISTENING' && this.analyser && this.dataArray) {
      this.analyser.getByteFrequencyData(this.dataArray as any);
      let sum = 0;
      for (let i = 0; i < this.dataArray.length; i++) {
        sum += this.dataArray[i];
      }
      const avg = sum / this.dataArray.length;
      return Math.min(avg / 128, 1.0);
    }

    return 0.05; // Resting ambient hum
  }

  /**
   * Starts Continuous Voice Conversation Mode.
   */
  public async startContinuousVoice(
    lang: LanguageCode,
    onStateChange: VoiceStateChangeCallback,
    onTranscript: TranscriptCallback
  ): Promise<boolean> {
    if (!this.isSpeechRecognitionSupported()) {
      onStateChange('ERROR', 'Speech recognition is not supported in this browser. Please use Chrome or Android WebView.');
      return false;
    }

    this.currentSessionId++;
    const thisSessionId = this.currentSessionId;
    this.isContinuousMode = true;
    this.activeLanguage = lang;
    this.onStateChangeCallback = onStateChange;
    this.onTranscriptCallback = onTranscript;
    this.reconnectAttempts = 0;

    this.setVoiceState('REQUESTING_PERMISSION');
    this.playProceduralChime('activate');

    // Request mic stream permission
    const hasMic = await this.initAudioAnalyser();
    if (!this.isContinuousMode || thisSessionId !== this.currentSessionId) {
      return false;
    }

    if (!hasMic) {
      this.setVoiceState('ERROR', 'Microphone permission denied. Please allow microphone access.');
      this.isContinuousMode = false;
      return false;
    }

    this.startListeningSession(thisSessionId);
    return true;
  }

  /**
   * Runs an individual listening cycle within the continuous session.
   */
  private startListeningSession(sessionId: number): void {
    if (!this.isContinuousMode || sessionId !== this.currentSessionId) {
      return;
    }

    if (!this.recognition) {
      this.setVoiceState('ERROR', 'Speech recognition unavailable.');
      return;
    }

    // Stop speaking before listening to prevent self-transcription loop
    this.stopSpeaking();

    try {
      this.recognition.lang = this.activeLanguage;

      this.recognition.onstart = () => {
        if (sessionId !== this.currentSessionId || !this.isContinuousMode) return;
        this.reconnectAttempts = 0;
        this.setVoiceState('LISTENING');
      };

      this.recognition.onresult = (event: any) => {
        if (sessionId !== this.currentSessionId || !this.isContinuousMode) return;

        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        const text = (finalTranscript || interimTranscript).trim();
        const isFinal = Boolean(finalTranscript);

        if (text) {
          // Check for local voice command to stop speaking or disable voice mode
          const lower = text.toLowerCase();
          if (lower === 'stop speaking' || lower === 'be quiet' || lower === 'shut up') {
            this.stopSpeaking();
            this.setVoiceState('LISTENING');
            return;
          }
          if (lower === 'turn voice mode off' || lower === 'turn off voice mode' || lower === 'disable voice mode' || lower === 'exit voice mode') {
            this.stopContinuousVoice();
            return;
          }

          if (isFinal) {
            this.setVoiceState('PROCESSING');
            // Stop recognition while processing and speaking to avoid feedback loop
            try {
              this.recognition.stop();
            } catch {
              // Ignore already stopping
            }
          }

          if (this.onTranscriptCallback) {
            this.onTranscriptCallback(text, isFinal);
          }
        }
      };

      this.recognition.onerror = (event: any) => {
        if (sessionId !== this.currentSessionId || !this.isContinuousMode) return;

        console.warn('Speech recognition event error:', event.error);

        if (event.error === 'not-allowed') {
          this.setVoiceState('ERROR', 'Microphone permission was denied.');
          this.stopContinuousVoice();
          return;
        }

        // For harmless 'no-speech' or 'network' glitch in continuous mode, schedule a reconnect
        if (event.error === 'no-speech' || event.error === 'aborted') {
          this.scheduleReconnect(sessionId);
        } else {
          this.scheduleReconnect(sessionId);
        }
      };

      this.recognition.onend = () => {
        if (sessionId !== this.currentSessionId || !this.isContinuousMode) return;

        // If recognition ended naturally and we are not currently speaking or processing, reconnect
        if (this.voiceState === 'LISTENING') {
          this.scheduleReconnect(sessionId);
        }
      };

      this.recognition.start();
    } catch (err: unknown) {
      console.warn('Recognition start caught error:', err);
      this.scheduleReconnect(sessionId);
    }
  }

  /**
   * Graceful, bounded reconnection to prevent rapid-fire browser loops.
   */
  private scheduleReconnect(sessionId: number): void {
    if (!this.isContinuousMode || sessionId !== this.currentSessionId) return;

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      this.setVoiceState('ERROR', 'Voice connection paused after multiple idle timeouts. Tap the mic to resume.');
      this.stopContinuousVoice();
      return;
    }

    this.reconnectAttempts++;
    this.setVoiceState('RECONNECTING');

    const delay = Math.min(300 * this.reconnectAttempts, 2000);
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = null;
      if (this.isContinuousMode && sessionId === this.currentSessionId) {
        this.startListeningSession(sessionId);
      }
    }, delay);
  }

  /**
   * Speaks the assistant's reply and automatically returns to LISTENING when finished.
   */
  public speakContinuousReply(
    text: string,
    lang: LanguageCode,
    rate: number = 1.0,
    onSpeechComplete?: () => void
  ): void {
    if (!this.synthesis) {
      onSpeechComplete?.();
      if (this.isContinuousMode) {
        this.resumeContinuousListening();
      }
      return;
    }

    const sessionId = this.currentSessionId;

    // Immediately stop speech and recognition before speaking
    this.stopSpeaking();
    try {
      this.recognition?.stop();
    } catch {
      // Ignore
    }

    this.setVoiceState('SPEAKING');

    // Clean text for speech
    const cleanText = text
      .replace(/\[.*?\]\(.*?\)/g, '')
      .replace(/[*#_`~>]/g, '')
      .replace(/https?:\/\/\S+/g, 'link')
      .trim();

    if (!cleanText) {
      onSpeechComplete?.();
      if (this.isContinuousMode) {
        this.resumeContinuousListening();
      }
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = lang;
    utterance.rate = Math.min(Math.max(rate, 0.75), 1.5);
    utterance.pitch = 1.05;

    const voices = this.synthesis.getVoices();
    if (voices && voices.length > 0) {
      const langPrefix = lang.split('-')[0];
      const match = voices.find(v => v.lang === lang) || voices.find(v => v.lang.startsWith(langPrefix));
      if (match) {
        utterance.voice = match;
      }
    }

    utterance.onend = () => {
      this.currentUtterance = null;
      onSpeechComplete?.();
      // Resume listening loop automatically if Continuous Voice Mode remains active!
      if (this.isContinuousMode && sessionId === this.currentSessionId) {
        this.resumeContinuousListening();
      } else {
        this.setVoiceState('OFF');
      }
    };

    utterance.onerror = (e) => {
      this.currentUtterance = null;
      onSpeechComplete?.();
      if (e.error !== 'canceled' && this.isContinuousMode && sessionId === this.currentSessionId) {
        this.resumeContinuousListening();
      } else if (!this.isContinuousMode) {
        this.setVoiceState('OFF');
      }
    };

    this.currentUtterance = utterance;
    this.synthesis.speak(utterance);
  }

  /**
   * Resumes continuous listening after a brief pause so user can speak the next question.
   */
  public resumeContinuousListening(): void {
    if (!this.isContinuousMode) return;
    const sessionId = this.currentSessionId;

    setTimeout(() => {
      if (this.isContinuousMode && sessionId === this.currentSessionId) {
        this.startListeningSession(sessionId);
      }
    }, 250);
  }

  /**
   * Stops Continuous Voice Mode completely and releases resources.
   */
  public stopContinuousVoice(): void {
    this.isContinuousMode = false;
    this.currentSessionId++; // Invalidate pending callbacks

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    try {
      this.recognition?.stop();
    } catch {
      // Ignore
    }

    this.stopSpeaking();

    // Release microphone tracks
    if (this.micStream) {
      this.micStream.getTracks().forEach(track => track.stop());
      this.micStream = null;
    }

    this.setVoiceState('OFF');
  }

  public stopSpeaking(): void {
    if (this.synthesis) {
      try {
        this.synthesis.cancel();
      } catch (e) {
        console.warn('Error cancelling speech synthesis:', e);
      }
    }
    this.currentUtterance = null;
  }
}

export const voiceService = new VoiceService();
