/**
 * J.A.R.V.I.S. MARK VII — NEW MASTER MALE VOICE & AUDIO ENGINE (V2 REPLACEMENT)
 * 
 * Replaces the old Jarvis voice with the new permanent deep, powerful, masculine,
 * confident human male voice identity.
 * 
 * DIRECTIVES:
 * 1. Old voice completely replaced as active default.
 * 2. New Voice Profile: "JARVIS Master Voice Prime" (Pitch: 0.76, Rate: 0.94, deep resonant baritone).
 * 3. ZERO automatic voice switching. Never switches to female or generic browser fallback voices.
 * 4. Supports custom audio samples (prerecorded audio files or base64) for custom voice greetings/alarms.
 * 5. If the new voice is unavailable, reports the issue explicitly and displays text instead of silently switching voices.
 * 6. Centralized Master Voice Manager across chat, alarms, battery, errors, wake words, and phone features.
 */

export const AUDIO_ASSETS = {
  voiceReference: '/assets/aistudio/voice-preview__1__38c11f87.mp3',
  unlock: '/assets/aistudio/jarvis_unlock_1084a9fc.mp3',
  welcomeBack: '/assets/aistudio/welcome_back_jarvis_b713fb4d.mp3',
  alarm: '/assets/aistudio/jarvis_alarm_4c3bf205.mp3',
};

export const ELEVENLABS_VOICE_ID = 'JBFqnCBsd6RMkjVDRZzb'; // George - Deep British Male Baritone
export const ELEVENLABS_MODEL_ID = 'eleven_multilingual_v2';

import { formatTimeHindiSpeech } from './timeService';

export const NEW_MASTER_VOICE_STORAGE_KEY = 'jarvis_master_voice_profile_v2';

export interface JarvisMasterVoiceProfile {
  voiceId: string;
  voiceName: string;
  provider: 'elevenlabs' | 'webspeech_calibrated';
  elevenLabsVoiceId: string;
  elevenLabsModel: string;
  gender: 'male';
  pitch: number;
  rate: number;
  volume: number;
  // Dynamic Calibration Controls
  depth: number;          // 0 to 100%, default 85% (chest resonance)
  speed: number;          // 0.75x to 1.50x, default 0.90x (conversational pacing)
  pitchSemitones: number; // -6 to +6 semitones, default -2 (masculine baritone offset)
  customAudioSampleUrl?: string;
  customAudioBase64?: string;
  voiceReferenceFile?: string;
  lastUpdated: number;
  isLocked: boolean;
}

export function calculateEffectivePitch(depth = 85, semitones = -2): number {
  // Convert semitones to frequency ratio: 2^(semitones / 12)
  const semiFactor = Math.pow(2, semitones / 12);
  // Chest resonance depth dampens high pitch frequencies
  const depthFactor = 1 - ((depth - 50) * 0.0028);
  const calculated = semiFactor * depthFactor;
  return Math.max(0.5, Math.min(1.25, Number(calculated.toFixed(2))));
}

export function calculateEffectiveRate(speed = 0.90): number {
  return Math.max(0.7, Math.min(1.5, Number(speed.toFixed(2))));
}

// Permanent Voice Configuration Locked to ElevenLabs George (JBFqnCBsd6RMkjVDRZzb) British Male Baritone
export const NEW_JARVIS_MASTER_VOICE_CONFIG: JarvisMasterVoiceProfile = {
  voiceId: 'JBFqnCBsd6RMkjVDRZzb',
  voiceName: 'ElevenLabs George (JARVIS British Male Baritone)',
  provider: 'elevenlabs',
  elevenLabsVoiceId: 'JBFqnCBsd6RMkjVDRZzb',
  elevenLabsModel: 'eleven_multilingual_v2',
  gender: 'male',
  depth: 85,           // 85% deep chest resonance
  speed: 0.90,         // 0.90x steady, calm conversational pacing
  pitchSemitones: -2,  // -2 semitones baritone pitch
  pitch: calculateEffectivePitch(85, -2), // ~0.80
  rate: calculateEffectiveRate(0.90),    // 0.90
  volume: 1.0,
  customAudioSampleUrl: '/assets/aistudio/voice-preview__1__38c11f87.mp3',
  voiceReferenceFile: 'voice-preview__1__38c11f87.mp3',
  lastUpdated: Date.now(),
  isLocked: true,
};

export interface VoicePlaybackOptions {
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: any) => void;
  pitch?: number;
  rate?: number;
  useLocalFallbackOnly?: boolean;
}

class JarvisVoiceManager {
  private synth: SpeechSynthesis | null = null;
  private primaryVoice: SpeechSynthesisVoice | null = null;
  private isSpeaking = false;
  private audioContext: AudioContext | null = null;
  private currentAudioElement: HTMLAudioElement | null = null;
  private speechQueueToken = 0;
  private profile: JarvisMasterVoiceProfile = { ...NEW_JARVIS_MASTER_VOICE_CONFIG };
  private voiceUnavailableNoticeGiven = false;

  constructor() {
    this.loadPersistedVoiceProfile();

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.bindNewMasterVoice();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.bindNewMasterVoice();
      }
    }
  }

  /**
   * Load persisted voice profile, replacing old configurations.
   */
  private loadPersistedVoiceProfile(): void {
    try {
      const saved = localStorage.getItem(NEW_MASTER_VOICE_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        const depth = parsed.depth ?? 85;
        const speed = parsed.speed ?? 0.90;
        const pitchSemitones = parsed.pitchSemitones ?? -2;
        this.profile = {
          ...NEW_JARVIS_MASTER_VOICE_CONFIG,
          ...parsed,
          depth,
          speed,
          pitchSemitones,
          pitch: calculateEffectivePitch(depth, pitchSemitones),
          rate: calculateEffectiveRate(speed),
          gender: 'male',
          isLocked: true,
        };
        return;
      }
    } catch {}

    // Save default new master voice
    try {
      localStorage.setItem(NEW_MASTER_VOICE_STORAGE_KEY, JSON.stringify(this.profile));
    } catch {}
  }

  /**
   * Strict anti-female filter.
   * Explicitly rejects all female names, tokens, and voice models.
   */
  public isVerifiedMaleVoice(v: SpeechSynthesisVoice): boolean {
    const name = v.name.toLowerCase();
    const uri = (v.voiceURI || '').toLowerCase();

    // 1. Explicit female tokens rejection
    const femaleTokens = [
      'female', 'woman', 'zira', 'samantha', 'victoria', 'karen', 'serena',
      'moira', 'fiona', 'veena', 'tessa', 'eva', 'anna', 'susan', 'hazel',
      'allison', 'ava', 'jenny', 'aria', 'f-', '#female', 'cxx', 'sfg', 'girl',
      'lucia', 'yuna', 'kyoko', 'sin-ji', 'mei-jia', 'catherine', 'helena',
      'marta', 'paulina', 'monica', 'alice', 'sara', 'laura', 'amelie', 'clara',
      'sangeeta', 'priya', 'kalpana', 'ananya', 'pooja', 'neha', 'sheetal'
    ];

    if (femaleTokens.some(token => name.includes(token) || uri.includes(token))) {
      return false;
    }

    // 2. Positive male tokens
    const maleTokens = [
      'male', 'guy', 'george', 'ryan', 'daniel', 'david', 'arthur', 'oliver',
      'mark', 'james', 'thomas', 'en-gb', 'uk english male', 'india male',
      'hindi male', 'google uk english male', '#male', 'm-', 'rishi', 'amit', 'rajesh'
    ];

    if (maleTokens.some(token => name.includes(token) || uri.includes(token))) {
      return true;
    }

    // 3. If English or Hindi voice without any female markers
    return v.lang.startsWith('en') || v.lang.startsWith('hi');
  }

  /**
   * Binds to the new master male voice on the device.
   * Completely ignores old voice identifiers.
   */
  private bindNewMasterVoice(): void {
    if (!this.synth) return;
    const voices = this.synth.getVoices();
    if (!voices || voices.length === 0) return;

    // Filter strictly for verified male voices
    const maleCandidates = voices.filter(v => this.isVerifiedMaleVoice(v));

    if (maleCandidates.length > 0) {
      // Prioritize British male baritones matching voice-preview (1).mp3 (Google UK English Male / George / Daniel / Oliver / Arthur / en-GB)
      const preferred = maleCandidates.find(v => {
        const n = v.name.toLowerCase();
        const lang = (v.lang || '').toLowerCase();
        return n.includes('google uk english male') ||
          (lang.startsWith('en-gb') && this.isVerifiedMaleVoice(v)) ||
          n.includes('george') ||
          n.includes('daniel') ||
          n.includes('oliver') ||
          n.includes('arthur') ||
          n.includes('en-gb');
      }) || maleCandidates.find(v => {
        const n = v.name.toLowerCase();
        return n.includes('ryan') || n.includes('en-in') || n.includes('hindi');
      }) || maleCandidates[0];

      this.primaryVoice = preferred;
      this.profile.voiceName = preferred.name;
    } else {
      // Find any voice strictly without female markers
      const nonFemale = voices.filter(v => {
        const n = v.name.toLowerCase();
        return !n.includes('female') && !n.includes('woman') && !n.includes('zira');
      });
      if (nonFemale.length > 0) {
        this.primaryVoice = nonFemale[0];
        this.profile.voiceName = nonFemale[0].name;
      } else {
        this.primaryVoice = null;
      }
    }
  }

  /**
   * Set new voice configuration or custom audio sample.
   * Call this when the user supplies a new voice sample or configuration.
   */
  public setNewVoiceConfig(customConfig: Partial<JarvisMasterVoiceProfile>): void {
    this.profile = {
      ...this.profile,
      ...customConfig,
      gender: 'male',
      isLocked: true,
      lastUpdated: Date.now(),
    };

    try {
      localStorage.setItem(NEW_MASTER_VOICE_STORAGE_KEY, JSON.stringify(this.profile));
    } catch {}

    // Re-bind to apply immediately
    this.bindNewMasterVoice();
  }

  /**
   * Stores a new custom voice audio sample (URL or Base64 data).
   */
  public setNewCustomVoiceSample(audioUrlOrBase64: string): void {
    if (audioUrlOrBase64.startsWith('data:audio') || audioUrlOrBase64.length > 500) {
      this.profile.customAudioBase64 = audioUrlOrBase64;
    } else {
      this.profile.customAudioSampleUrl = audioUrlOrBase64;
    }
    this.profile.lastUpdated = Date.now();
    try {
      localStorage.setItem(NEW_MASTER_VOICE_STORAGE_KEY, JSON.stringify(this.profile));
    } catch {}
  }

  public getVoiceConfig(): JarvisMasterVoiceProfile {
    return { ...this.profile };
  }

  public getSelectedVoiceName(): string {
    return this.primaryVoice ? `${this.primaryVoice.name} (New Master Baritone)` : this.profile.voiceName;
  }

  public getElevenLabsApiKey(): string {
    if (typeof localStorage === 'undefined') return '';
    return localStorage.getItem('jarvis_elevenlabs_api_key') || '';
  }

  public setElevenLabsApiKey(key: string): void {
    if (typeof localStorage === 'undefined') return;
    if (key.trim()) {
      localStorage.setItem('jarvis_elevenlabs_api_key', key.trim());
    } else {
      localStorage.removeItem('jarvis_elevenlabs_api_key');
    }
  }

  /**
   * Update live voice calibration parameters (Depth, Speed, Pitch Semitones)
   * Automatically re-calculates effective pitch & rate and persists to storage.
   */
  public updateVoiceSettings(settings: {
    depth?: number;
    speed?: number;
    pitchSemitones?: number;
    elevenLabsVoiceId?: string;
  }): JarvisMasterVoiceProfile {
    const depth = settings.depth !== undefined ? Math.max(0, Math.min(100, settings.depth)) : (this.profile.depth ?? 85);
    const speed = settings.speed !== undefined ? Math.max(0.75, Math.min(1.50, settings.speed)) : (this.profile.speed ?? 0.90);
    const pitchSemitones = settings.pitchSemitones !== undefined ? Math.max(-6, Math.min(6, settings.pitchSemitones)) : (this.profile.pitchSemitones ?? -2);

    this.profile = {
      ...this.profile,
      depth,
      speed,
      pitchSemitones,
      pitch: calculateEffectivePitch(depth, pitchSemitones),
      rate: calculateEffectiveRate(speed),
      elevenLabsVoiceId: settings.elevenLabsVoiceId || this.profile.elevenLabsVoiceId,
      gender: 'male',
      isLocked: true,
      lastUpdated: Date.now(),
    };

    try {
      localStorage.setItem(NEW_MASTER_VOICE_STORAGE_KEY, JSON.stringify(this.profile));
    } catch {}

    return { ...this.profile };
  }

  /**
   * Reset voice settings to default calibrated British male baritone (85% depth, 0.90x speed, -2 semitones)
   */
  public resetVoiceSettings(): JarvisMasterVoiceProfile {
    this.profile = {
      ...NEW_JARVIS_MASTER_VOICE_CONFIG,
      depth: 85,
      speed: 0.90,
      pitchSemitones: -2,
      pitch: calculateEffectivePitch(85, -2),
      rate: calculateEffectiveRate(0.90),
      lastUpdated: Date.now(),
      isLocked: true,
    };

    try {
      localStorage.setItem(NEW_MASTER_VOICE_STORAGE_KEY, JSON.stringify(this.profile));
    } catch {}

    return { ...this.profile };
  }

  /**
   * Preview current voice configuration with dynamic sample text
   */
  public async previewVoice(
    sampleText = 'All systems operational, Harman Sir. Voice depth and baritone resonance calibrated to your exact specifications.',
    options?: VoicePlaybackOptions
  ): Promise<void> {
    return this.speak(sampleText, options);
  }

  /**
   * Returns current voice engine status.
   */
  public getVoiceStatus(): { isReady: boolean; voiceName: string; hasCustomSample: boolean; elevenLabsConfigured: boolean } {
    const hasKey = Boolean(this.getElevenLabsApiKey());
    return {
      isReady: Boolean(this.primaryVoice || hasKey),
      voiceName: `ElevenLabs George (${this.profile.elevenLabsVoiceId})`,
      hasCustomSample: Boolean(this.profile.customAudioSampleUrl || this.profile.customAudioBase64),
      elevenLabsConfigured: hasKey,
    };
  }

  /**
   * Clean and normalize text for speech synthesis.
   * Eliminates the colon-splitting bug where "7:15 PM" was misread as "7 PM followed by 3 PM"
   * by normalizing time expressions into natural Hindi speech words or safe English speech tokens.
   */
  public cleanSpeechText(text: string): string {
    let cleaned = text
      .replace(/[*#_`~]/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/https?:\/\/\S+/g, 'link');

    // 1. If text already has natural Hindi time words (बजकर or बजे), strip redundant visual timestamp in parentheses e.g. "(7:15 PM)"
    if (/बजकर|बजे/.test(cleaned)) {
      cleaned = cleaned.replace(/\s*\(\s*\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM|am|pm)?\s*\)/gi, '');
    }

    // 2. Pre-process any remaining numeric timestamps (e.g. 7:15 PM) to prevent TTS colon-splitting / 24-hr military time misinterpretation
    cleaned = cleaned.replace(/\b(\d{1,2}):(\d{2})\s*(AM|PM|am|pm)?\b/gi, (match, hStr, mStr, periodStr) => {
      const h = parseInt(hStr, 10);
      const m = parseInt(mStr, 10);
      const p = (periodStr || '').toUpperCase();

      // If surrounding text is Hindi / Devanagari, convert to authentic Hindi speech
      if (/[\u0900-\u097F]/.test(cleaned)) {
        let h24 = h;
        if (p === 'PM' && h < 12) h24 = h + 12;
        if (p === 'AM' && h === 12) h24 = 0;
        return formatTimeHindiSpeech(h24, m);
      }

      // In English, expand to space-separated words so TTS never evaluates colon or converts minute to 24-hr hour
      return `${h} ${m === 0 ? "o'clock" : m} ${p}`.trim();
    });

    return cleaned
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Natural human conversational pauses and clause segmentation.
   */
  private segmentIntoHumanClauses(text: string): Array<{ text: string; pauseAfterMs: number; isQuestion: boolean }> {
    const rawClauses = text.split(/([.!?,;:\u0964\u0965\n]+|[—–]|--)/g).filter(Boolean);
    const clauses: Array<{ text: string; pauseAfterMs: number; isQuestion: boolean }> = [];

    let currentText = '';
    for (let i = 0; i < rawClauses.length; i++) {
      const part = rawClauses[i];
      if (/^[.!?,;:\u0964\u0965\n—–-]+$/.test(part)) {
        currentText += part;
        const isQuestion = part.includes('?');
        const isSentenceEnd = part.includes('.') || part.includes('!') || part.includes('?') || part.includes('\u0964') || part.includes('\n');
        const pauseAfterMs = isSentenceEnd ? 260 : 130;
        if (currentText.trim()) {
          clauses.push({
            text: currentText.trim(),
            pauseAfterMs,
            isQuestion,
          });
        }
        currentText = '';
      } else {
        currentText += (currentText ? ' ' : '') + part;
      }
    }

    if (currentText.trim()) {
      clauses.push({
        text: currentText.trim(),
        pauseAfterMs: 200,
        isQuestion: currentText.includes('?'),
      });
    }

    return clauses.filter(c => c.text.length > 0);
  }

  /**
   * Centralized Speech Delivery Method.
   * 
   * STRICT DIRECTIVE:
   * 1. Uses ONLY the new master male voice profile.
   * 2. NEVER switches to a female or generic browser fallback voice.
   * 3. If the voice is unavailable on the device, reports the issue clearly and displays text.
   */
  public async speak(text: string, options: VoicePlaybackOptions = {}): Promise<void> {
    this.stopSpeaking();

    const cleanText = this.cleanSpeechText(text);
    if (!cleanText) {
      options.onEnd?.();
      return;
    }

    // Attempt ElevenLabs cloud generation if not explicitly restricted
    if (!options.useLocalFallbackOnly) {
      try {
        const storedKey = typeof localStorage !== 'undefined' ? localStorage.getItem('jarvis_elevenlabs_api_key') || '' : '';
        const ttsRes = await fetch('/api/elevenlabs/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: cleanText,
            voiceId: this.profile.elevenLabsVoiceId || 'JBFqnCBsd6RMkjVDRZzb',
            customApiKey: storedKey || undefined,
          }),
        });

        if (ttsRes.ok) {
          const ttsData = await ttsRes.json();
          if (ttsData.success && ttsData.audioBase64) {
            this.isSpeaking = true;
            options.onStart?.();
            const audioSrc = `data:audio/mpeg;base64,${ttsData.audioBase64}`;
            this.playAudioFile(audioSrc, () => {
              this.isSpeaking = false;
              options.onEnd?.();
            });
            return;
          }
        }
      } catch (e) {
        console.warn('ElevenLabs API request failed, utilizing calibrated British male local engine:', e);
      }
    }

    if (!this.synth) {
      console.warn('SpeechSynthesis is unavailable in this environment.');
      options.onEnd?.();
      return;
    }

    if (!this.primaryVoice) {
      this.bindNewMasterVoice();
    }

    // STRICT CHECK: If no verified male voice is available, DO NOT speak with generic browser voice!
    // As instructed: "If the new voice is unavailable, clearly report the issue instead of silently switching to another voice."
    if (!this.primaryVoice || !this.isVerifiedMaleVoice(this.primaryVoice)) {
      if (!this.voiceUnavailableNoticeGiven) {
        console.warn('New Master Male Voice is currently initializing or unavailable on this device. Displaying response as text only.');
        this.voiceUnavailableNoticeGiven = true;
      }
      options.onError?.(new Error('Selected male voice is currently unavailable on system.'));
      options.onEnd?.();
      return;
    }

    const clauses = this.segmentIntoHumanClauses(cleanText);
    if (clauses.length === 0) {
      options.onEnd?.();
      return;
    }

    const currentToken = ++this.speechQueueToken;
    this.isSpeaking = true;
    options.onStart?.();

    let clauseIndex = 0;

    const playNextClause = () => {
      if (this.speechQueueToken !== currentToken) return;

      if (clauseIndex >= clauses.length) {
        this.isSpeaking = false;
        options.onEnd?.();
        return;
      }

      const clause = clauses[clauseIndex];
      clauseIndex++;

      const utterance = new SpeechSynthesisUtterance(clause.text);
      utterance.voice = this.primaryVoice;

      // New Master Male Acoustic Settings:
      // Pitch: 0.76 (deep resonant baritone), with +0.03 subtle lift on question endings
      utterance.pitch = clause.isQuestion ? this.profile.pitch + 0.03 : this.profile.pitch;
      utterance.rate = this.profile.rate;
      utterance.volume = this.profile.volume;

      utterance.onend = () => {
        if (this.speechQueueToken !== currentToken) return;
        setTimeout(() => {
          playNextClause();
        }, clause.pauseAfterMs);
      };

      utterance.onerror = (e) => {
        // DO NOT switch to a different voice on error
        console.warn('SpeechSynthesis error on clause:', e);
        if (this.speechQueueToken !== currentToken) return;
        this.isSpeaking = false;
        options.onError?.(e);
        options.onEnd?.();
      };

      try {
        this.synth!.speak(utterance);
      } catch (err) {
        console.warn('SpeechSynthesis speak failed:', err);
        this.isSpeaking = false;
        options.onError?.(err);
        options.onEnd?.();
      }
    };

    playNextClause();
  }

  /**
   * Stop active speech.
   */
  public stopSpeaking(): void {
    this.speechQueueToken++;
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {}
    }
    this.isSpeaking = false;
  }

  /**
   * Synthesize modern sci-fi HUD chime using Web Audio.
   */
  public playHudBeep(type: 'wake' | 'ack' | 'stop' = 'wake'): void {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      if (!this.audioContext || this.audioContext.state === 'suspended') {
        this.audioContext = new AudioCtx();
      }

      const ctx = this.audioContext;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;
      if (type === 'wake') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      } else if (type === 'ack') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(783.99, now);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        osc.start(now);
        osc.stop(now + 0.18);
      } else {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.exponentialRampToValueAtTime(330, now + 0.2);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        osc.start(now);
        osc.stop(now + 0.22);
      }
    } catch (e) {
      console.warn('Audio chime error:', e);
    }
  }

  /**
   * Wake-word verbal acknowledgement in natural conversational Hindi/English.
   */
  public speakWakeResponse(onComplete?: () => void): void {
    this.playHudBeep('wake');
    const responses = [
      'जी Harman Sir, बताइए।',
      'Yes Harman Sir, at your command.',
      'ਹਾਂਜੀ Harman Sir, ਹੁਕਮ ਕਰੋ।',
    ];
    const phrase = responses[Math.floor(Math.random() * responses.length)];
    this.speak(phrase, {
      onEnd: onComplete,
      onError: onComplete,
    });
  }

  /**
   * Play stored audio clips.
   */
  public playAudioFile(src: string, onEnded?: () => void, loop = false): HTMLAudioElement {
    if (this.currentAudioElement) {
      try {
        this.currentAudioElement.pause();
        this.currentAudioElement.currentTime = 0;
      } catch {}
    }

    const audio = new Audio(src);
    audio.loop = loop;
    this.currentAudioElement = audio;

    audio.onended = () => { onEnded?.(); };
    audio.onerror = () => { onEnded?.(); };
    audio.play().catch(() => { onEnded?.(); });

    return audio;
  }

  public stopAudio(): void {
    if (this.currentAudioElement) {
      try {
        this.currentAudioElement.pause();
        this.currentAudioElement.currentTime = 0;
      } catch {}
      this.currentAudioElement = null;
    }
  }

  /**
   * Play the permanent reference audio sample (voice-preview (1).mp3) provided by Harman Sir.
   */
  public playVoiceReferenceSample(onEnded?: () => void): HTMLAudioElement {
    return this.playAudioFile(AUDIO_ASSETS.voiceReference, onEnded, false);
  }

  /**
   * Daily welcome greeting logic based on user assets:
   * 1. First open of each day -> Play "Jarvis unlock.mp3" (AUDIO_ASSETS.unlock)
   * 2. Subsequent opens on the same day -> Play "welcome back Jarvis.mp3" (AUDIO_ASSETS.welcomeBack)
   * Persists daily state in localStorage so it survives tab closes, reloads, and APK lifecycle.
   */
  public triggerDailyWelcome(onComplete?: () => void): HTMLAudioElement {
    const today = new Date().toISOString().slice(0, 10);
    const lastDate = localStorage.getItem('jarvis_last_open_date');
    const isFirstToday = lastDate !== today;
    const targetAsset = isFirstToday ? AUDIO_ASSETS.unlock : AUDIO_ASSETS.welcomeBack;

    const audio = this.playAudioFile(targetAsset, () => {
      onComplete?.();
    });

    audio.addEventListener('play', () => {
      if (isFirstToday) {
        try {
          localStorage.setItem('jarvis_last_open_date', today);
        } catch {}
      }
    }, { once: true });

    return audio;
  }

  /**
   * Play user's actual Jarvis unlock audio ("Jarvis unlock.mp3")
   */
  public playUnlockAudio(onComplete?: () => void): HTMLAudioElement {
    return this.playAudioFile(AUDIO_ASSETS.unlock, onComplete, false);
  }

  /**
   * Play user's actual welcome back audio ("welcome back Jarvis.mp3")
   */
  public playWelcomeBackAudio(onComplete?: () => void): HTMLAudioElement {
    return this.playAudioFile(AUDIO_ASSETS.welcomeBack, onComplete, false);
  }

  /**
   * Play user's actual Jarvis alarm audio ("Jarvis alarm.mp3")
   */
  public playAlarmAudio(onComplete?: () => void): HTMLAudioElement {
    return this.playAudioFile(AUDIO_ASSETS.alarm, onComplete, false);
  }
}

// Single Authoritative Master Voice Manager Export
export const voiceEngine = new JarvisVoiceManager();
export const JarvisVoiceManagerInstance = voiceEngine;
export const PRIMARY_JARVIS_VOICE_CONFIG = NEW_JARVIS_MASTER_VOICE_CONFIG;
