import {
  doc,
  getDoc,
  setDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  limit,
  deleteDoc,
  getDocFromServer,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { ChatMessage, UserProfile } from '../types';

// Connection validation test as instructed in skill
export async function validateFirestoreConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firestore is currently running offline.');
    }
  }
}

// Load user profile from Firestore
export async function getUserProfileFromFirestore(
  userId: string
): Promise<UserProfile | null> {
  const path = `users/${userId}`;
  try {
    const docRef = doc(db, 'users', userId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      const data = snap.data();
      return {
        name: data.name || 'دوست',
        gender: data.gender || 'Male',
        characterName: data.characterName || (data.gender === 'Female' ? 'عائشہ (Ayesha)' : 'حمزہ (Hamza)'),
        persona: data.persona || 'friend',
        speechRate: data.speechRate || 1.0,
        speechPitch: data.speechPitch || 1.0,
        language: data.language || 'Urdu',
      };
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

// Save user profile to Firestore
export async function saveUserProfileToFirestore(
  userId: string,
  profile: UserProfile,
  email?: string | null
): Promise<void> {
  const path = `users/${userId}`;
  try {
    const docRef = doc(db, 'users', userId);
    await setDoc(
      docRef,
      {
        userId,
        name: profile.name,
        email: email || '',
        gender: profile.gender,
        characterName: profile.characterName,
        persona: profile.persona,
        speechRate: profile.speechRate,
        speechPitch: profile.speechPitch,
        language: profile.language || 'Urdu',
        updatedAt: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

// Save single message to user conversation history
export async function saveMessageToFirestore(
  userId: string,
  message: ChatMessage
): Promise<void> {
  const path = `users/${userId}/messages/${message.id}`;
  try {
    const docRef = doc(db, 'users', userId, 'messages', message.id);
    await setDoc(docRef, {
      userId,
      role: message.role,
      text: message.text,
      timestamp: message.timestamp,
      createdAt: new Date().toISOString(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

// Delete single message from Firestore
export async function deleteMessageFromFirestore(
  userId: string,
  messageId: string
): Promise<void> {
  const path = `users/${userId}/messages/${messageId}`;
  try {
    const docRef = doc(db, 'users', userId, 'messages', messageId);
    await deleteDoc(docRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// Subscribe to conversation messages
export function subscribeUserMessages(
  userId: string,
  onUpdate: (messages: ChatMessage[]) => void
) {
  const path = `users/${userId}/messages`;
  const q = query(collection(db, 'users', userId, 'messages'), orderBy('timestamp', 'asc'), limit(150));

  return onSnapshot(
    q,
    (snapshot) => {
      const msgs: ChatMessage[] = [];
      snapshot.forEach((d) => {
        const item = d.data();
        msgs.push({
          id: d.id,
          role: item.role,
          text: item.text,
          timestamp: item.timestamp,
        });
      });
      onUpdate(msgs);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
}
