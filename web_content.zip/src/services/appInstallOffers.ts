import { AppInstallOffer, AppFeedbackSubmission } from '../types';

export const TOTAL_INSTALL_POOL_COINS = 85000;
export const TOTAL_APP_INSTALL_CATALOG_COUNT = 200000;

export const INSTALL_OFFER_CATEGORIES = [
  'All',
  'Crypto & Web3',
  'AI & Productivity',
  'Gaming & Esports',
  'Social & Media',
  'Fintech & Pay'
];

export const MEGA_APP_INSTALL_OFFERS: AppInstallOffer[] = [
  // --- CRYPTO & WEB3 OFFERS ---
  {
    id: 'install-binance-crypto',
    name: 'Binance: Web3 & Crypto Trading',
    nameBn: 'বাইনান্স: ওয়েব৩ ও ক্রিপ্টো ট্রেডিং',
    developer: 'Binance Global Inc',
    category: 'Crypto & Web3',
    iconUrl: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 58,
    downloadsCount: '100M+',
    rewardCoins: 3500,
    rewardRupees: 3500,
    payoutBadge: 'Crypto ₹3,500',
    instructions: [
      'Click "Install App" to download Binance from verified official store.',
      'Complete fast sign-up and link your email address.',
      'Open Web3 Wallet tab and complete wallet activation.',
      'Receive verification confirmation and return to Task Earn Pro.',
      'Claim 3,500 Coins (₹3,500) directly into your cash balance!'
    ],
    instructionsBn: [
      'বাইনান্স অ্যাপটি ডাউনলোড ও ইন্সটল করুন।',
      'ফ্রি অ্যাকাউন্ট খুলে ওয়েব৩ ওয়ালেট সক্রিয় করুন।',
      'সাথে সাথে ৩,৫০০ কয়েন নিজের ব্যালেন্সে ক্লেইম করুন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.binance.dev',
    status: 'available'
  },
  {
    id: 'install-trust-wallet',
    name: 'Trust Wallet: Crypto & Bitcoin',
    nameBn: 'ট্রাস্ট ওয়ালেট: ক্রিপ্টো ও বিটকয়েন',
    developer: 'Trust Wallet Tech',
    category: 'Crypto & Web3',
    iconUrl: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 44,
    downloadsCount: '70M+',
    rewardCoins: 2800,
    rewardRupees: 2800,
    payoutBadge: 'Web3 ₹2,800',
    instructions: [
      'Download Trust Wallet on your mobile phone.',
      'Create a free multi-coin wallet and secure your recovery seed.',
      'Switch between Bitcoin and Solana network to complete initialization.',
      'Return to Task Earn Pro to confirm task verification.',
      'Earn 2,800 Coins instantly credited to your wallet.'
    ],
    instructionsBn: [
      'ট্রাস্ট ওয়ালেট ডাউনলোড করে নতুন মাল্টি-কয়েন ওয়ালেট তৈরি করুন।',
      '২,৮০০ কয়েন সরাসরি ওয়ালেটে জমা করে নিন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp',
    status: 'available'
  },
  {
    id: 'install-coindcx-inr',
    name: 'CoinDCX: Bitcoin Crypto App',
    nameBn: 'কয়েনডিসিএক্স: ক্রিপ্টো ইনভেস্টমেন্ট অ্যাপ',
    developer: 'CoinDCX India',
    category: 'Crypto & Web3',
    iconUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 32,
    downloadsCount: '15M+',
    rewardCoins: 2400,
    rewardRupees: 2400,
    payoutBadge: 'Instant ₹2,400',
    instructions: [
      'Install CoinDCX from the verified partner link.',
      'Register with your phone number and verify OTP.',
      'Check live Bitcoin / Ethereum price charts for 60 seconds.',
      'Return to claim 2,400 Coins immediately!'
    ],
    instructionsBn: [
      'কয়েনডিসিএক্স অ্যাপ ইন্সটল করে রেজিস্টার করুন।',
      '২,৪০০ কয়েন পুরস্কার ক্লেইম করুন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.coindcx',
    status: 'available'
  },

  // --- AI & PRODUCTIVITY OFFERS ---
  {
    id: 'install-chatgpt-ai',
    name: 'ChatGPT: Voice & Vision AI Assistant',
    nameBn: 'চ্যাটজিপিটি: ভয়েস ও এআই অ্যাসিস্ট্যান্ট',
    developer: 'OpenAI Technologies',
    category: 'AI & Productivity',
    iconUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
    rating: 4.9,
    sizeMb: 48,
    downloadsCount: '100M+',
    rewardCoins: 2600,
    rewardRupees: 2600,
    payoutBadge: 'AI Pro ₹2,600',
    instructions: [
      'Install official ChatGPT app onto your smartphone.',
      'Sign in with Google or create an OpenAI account.',
      'Ask 1 question or try Voice mode for 30 seconds.',
      'Verify completed activation to earn 2,600 Coins.'
    ],
    instructionsBn: [
      'চ্যাটজিপিটি অ্যাপ ইন্সটল করে যেকোনো ১টি প্রশ্ন জিজ্ঞাসা করুন।',
      '২,৬০০ কয়েন ইনস্ট্যান্ট আর্ন করুন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.openai.chatgpt',
    status: 'available'
  },
  {
    id: 'install-perplexity-ai',
    name: 'Perplexity: Conversational Search AI',
    nameBn: 'পারপ্লেক্সিটি: এআই সার্চ ও রিসার্চ',
    developer: 'Perplexity AI Inc',
    category: 'AI & Productivity',
    iconUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=128&q=80',
    rating: 4.9,
    sizeMb: 35,
    downloadsCount: '20M+',
    rewardCoins: 2200,
    rewardRupees: 2200,
    payoutBadge: 'Smart AI ₹2,200',
    instructions: [
      'Download Perplexity AI and open the app.',
      'Search for any topic or trending news to see real citations.',
      'Bookmark 1 source or query.',
      'Claim 2,200 Coins added to your Task Earn Pro balance.'
    ],
    instructionsBn: [
      'পারপ্লেক্সিটি এআই অ্যাপ ডাউনলোড করে যেকোনো খবর সার্চ করুন।',
      '২,২০০ কয়েন সরাসরি নিজের ব্যালেন্সে নিন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=ai.perplexity.app',
    status: 'available'
  },
  {
    id: 'install-notion-ai',
    name: 'Notion: Connected AI Workspace',
    nameBn: 'নোশন: কানেক্টেড এআই ওয়ার্কস্পেস',
    developer: 'Notion Labs Inc',
    category: 'AI & Productivity',
    iconUrl: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 52,
    downloadsCount: '50M+',
    rewardCoins: 1900,
    rewardRupees: 1900,
    payoutBadge: 'Quick ₹1,900',
    instructions: [
      'Download and launch Notion on your device.',
      'Set up a quick personal notes or tasks page.',
      'Verify installation to claim 1,900 Coins reward.'
    ],
    instructionsBn: [
      'নোশন অ্যাপ ডাউনলোড করে ১,৯০০ কয়েন জিতে নিন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=notion.id',
    status: 'available'
  },

  // --- GAMING & ESPORTS OFFERS ---
  {
    id: 'install-winzo-games',
    name: 'WinZO: Real Money Esports & Games',
    nameBn: 'উইনজো: রিয়েল ক্যাশ এস্পোর্টস ও গেমস',
    developer: 'WinZO Games Pvt Ltd',
    category: 'Gaming & Esports',
    iconUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 68,
    downloadsCount: '100M+',
    rewardCoins: 3000,
    rewardRupees: 3000,
    payoutBadge: 'Esports ₹3,000',
    instructions: [
      'Install WinZO application and launch the gaming hub.',
      'Register with phone number to claim free welcome bonus tokens.',
      'Play 1 practice match of Ludo or Fruit Samurai.',
      'Return to Task Earn Pro and claim 3,000 Coins (₹3,000) instantly!'
    ],
    instructionsBn: [
      'উইনজো অ্যাপ ডাউনলোড করে যেকোনো ১টি প্র্যাকটিস ম্যাচ খেলুন।',
      '৩,০০০ কয়েন ক্যাশ রিওয়ার্ড ক্লেইম করুন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.winzo.gold',
    status: 'available'
  },
  {
    id: 'install-bgmi-esports',
    name: 'Battlegrounds Mobile India (BGMI)',
    nameBn: 'বিজিএমআই: ব্যাটেলগ্রাউন্ডস মোবাইল ইন্ডিয়া',
    developer: 'Krafton India',
    category: 'Gaming & Esports',
    iconUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=128&q=80',
    rating: 4.6,
    sizeMb: 95,
    downloadsCount: '100M+',
    rewardCoins: 2500,
    rewardRupees: 2500,
    payoutBadge: 'Gamer ₹2,500',
    instructions: [
      'Install BGMI from the official Play Store link.',
      'Create your in-game character profile.',
      'Complete the quick basic training ground.',
      'Receive 2,500 Coins credited to your lifetime earnings!'
    ],
    instructionsBn: [
      'বিজিএমআই ইন্সটল করে চরিত্র তৈরি করুন ও ২,৫০০ কয়েন পান।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.pubg.imobile',
    status: 'available'
  },
  {
    id: 'install-mpl-pro',
    name: 'MPL Pro: Esports Cricket & Games',
    nameBn: 'এমপিএল প্রো: এস্পোর্টস ক্রিকেট ও গেমস',
    developer: 'Mobile Premier League',
    category: 'Gaming & Esports',
    iconUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=128&q=80',
    rating: 4.6,
    sizeMb: 72,
    downloadsCount: '90M+',
    rewardCoins: 2700,
    rewardRupees: 2700,
    payoutBadge: 'High Win ₹2,700',
    instructions: [
      'Download MPL Pro application on your device.',
      'Sign in and view live cricket tournament rooms.',
      'Complete quick account verification.',
      'Claim 2,700 Coins added to your balance.'
    ],
    instructionsBn: [
      'এমপিএল প্রো অ্যাপ ইন্সটল করে ২,৭০০ কয়েন পান।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.mpl.androidapp',
    status: 'available'
  },

  // --- SOCIAL & MEDIA OFFERS ---
  {
    id: 'install-telegram-web3',
    name: 'Telegram: Web3 & Channels',
    nameBn: 'টেলিগ্রাম: ওয়েব৩ ও আর্নিং চ্যানেল',
    developer: 'Telegram FZ-LLC',
    category: 'Social & Media',
    iconUrl: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 42,
    downloadsCount: '1B+',
    rewardCoins: 2500,
    rewardRupees: 2500,
    payoutBadge: 'Social ₹2,500',
    instructions: [
      'Install official Telegram app and activate your account.',
      'Join our official Task Earn Pro updates announcement channel.',
      'Try launching any Web3 Mini App bot.',
      'Claim 2,500 Coins directly to your Task Earn Pro wallet.'
    ],
    instructionsBn: [
      'টেলিগ্রাম অ্যাপ ইন্সটল করে অফিশিয়াল চ্যানেলে যোগ দিন।',
      '২,৫০০ কয়েন পুরস্কার সংগ্রহ করুন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=org.telegram.messenger',
    status: 'available'
  },
  {
    id: 'install-discord-gaming',
    name: 'Discord: Communities & Voice Chat',
    nameBn: 'ডিসকর্ড: কমিউনিটি ও ভয়েস চ্যাট',
    developer: 'Discord Inc',
    category: 'Social & Media',
    iconUrl: 'https://images.unsplash.com/photo-1614680376593-902f749f7ffc?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 56,
    downloadsCount: '500M+',
    rewardCoins: 1800,
    rewardRupees: 1800,
    payoutBadge: 'Voice ₹1,800',
    instructions: [
      'Download Discord and register your username.',
      'Join any public gaming or tech earning community.',
      'Claim 1,800 Coins immediately.'
    ],
    instructionsBn: [
      'ডিসকর্ড অ্যাপ ইন্সটল করে ১,৮০০ কয়েন আর্ন করুন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.discord',
    status: 'available'
  },
  {
    id: 'install-x-creators',
    name: 'X (Twitter): Live News & Creators',
    nameBn: 'এক্স (টুইটার): লাইভ নিউজ ও ক্রিয়েটরস',
    developer: 'X Corp',
    category: 'Social & Media',
    iconUrl: 'https://images.unsplash.com/photo-1611605698335-8b1569810432?auto=format&fit=crop&w=128&q=80',
    rating: 4.5,
    sizeMb: 38,
    downloadsCount: '1B+',
    rewardCoins: 2200,
    rewardRupees: 2200,
    payoutBadge: 'Media ₹2,200',
    instructions: [
      'Install X app and sign in to your profile.',
      'Follow 2 verified finance or tech creators.',
      'Browse trending topics for 2 minutes to confirm.',
      'Claim 2,200 Coins added to your wallet.'
    ],
    instructionsBn: [
      'এক্স অ্যাপ ইন্সটল করে ২,২০০ কয়েন জিতে নিন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.twitter.android',
    status: 'available'
  },

  // --- FINTECH & PAY OFFERS ---
  {
    id: 'install-navi-upi',
    name: 'Navi: UPI, Loans & Investments',
    nameBn: 'নাভি: ইউপিআই, লোন ও ইনভেস্টমেন্ট',
    developer: 'Navi Technologies Ltd',
    category: 'Fintech & Pay',
    iconUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=128&q=80',
    rating: 4.8,
    sizeMb: 28,
    downloadsCount: '50M+',
    rewardCoins: 2580,
    rewardRupees: 2580,
    payoutBadge: 'High Payout ₹2,580',
    instructions: [
      'Click "Install App" to open the official verified installation portal.',
      'Install the application on your device and launch it.',
      'Register with your active mobile number and link bank account for UPI.',
      'Complete a simple ₹1 test transfer or wallet activation to unlock payout.',
      'Return to Task Earn Pro and claim your 2,580 Coins instantly!'
    ],
    instructionsBn: [
      'অ্যাপটি ইনস্টল করতে "Install App" এ ক্লিক করুন।',
      'আপনার ডিভাইসে অ্যাপটি ওপেন করুন ও মোবাইল নম্বর দিয়ে রেজিস্টার করুন।',
      'ইউপিআই সেটআপ সম্পন্ন করে যেকোনো ১ টাকার লেনদেন সম্পন্ন করুন।',
      'ফিরে এসে সাথে সাথে ২,৫৮০ কয়েন ক্লেম করুন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.navi.mutualfunds',
    status: 'available'
  },
  {
    id: 'install-angel-one',
    name: 'Angel One SuperApp: Free Demat & Stocks',
    nameBn: 'অ্যাঞ্জেল ওয়ান: ফ্রি ডিম্যাট ও ট্রেডিং অ্যাকাউন্ট',
    developer: 'Angel One Limited',
    category: 'Fintech & Pay',
    iconUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=128&q=80',
    rating: 4.7,
    sizeMb: 42,
    downloadsCount: '50M+',
    rewardCoins: 3200,
    rewardRupees: 3200,
    payoutBadge: 'Mega Payout ₹3,200',
    instructions: [
      'Click "Install App" and download the official Angel One app.',
      'Initiate account registration with zero paperwork fees.',
      'Verify mobile OTP and enter your basic details to activate profile.',
      'Confirm registration completion and receive instant verification.',
      'Claim your 3,200 Coins (₹3,200) directly into your Task Earn Pro balance.'
    ],
    instructionsBn: [
      'অ্যাপটি ডাউনলোড করে ফ্রি রেজিস্ট্রেশন শুরু করুন।',
      'মোবাইল ওটিপি যাচাই করে অ্যাকাউন্ট প্রোফাইল তৈরি করুন।',
      'রেজিস্ট্রেশন সম্পন্ন করে ৩,২০০ কয়েন সরাসরি নিজের ওয়ালেটে নিন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.msf.angelmobile',
    status: 'available'
  },
  {
    id: 'install-phonepe-upi',
    name: 'PhonePe: Payments, Recharge & UPI',
    nameBn: 'ফোনপে: পেমেন্ট, রিচার্জ ও ইউপিআই',
    developer: 'PhonePe India',
    category: 'Fintech & Pay',
    iconUrl: 'https://images.unsplash.com/photo-1556742049-0a67c5574f73?auto=format&fit=crop&w=128&q=80',
    rating: 4.9,
    sizeMb: 35,
    downloadsCount: '100M+',
    rewardCoins: 2500,
    rewardRupees: 2500,
    payoutBadge: 'Instant ₹2,500',
    instructions: [
      'Download and install PhonePe from the secured partner link.',
      'Link your bank account using phone verification.',
      'Check account balance or execute your first transaction.',
      'Verification takes less than 60 seconds.',
      'Get rewarded with 2,500 Coins added to your lifetime earnings!'
    ],
    instructionsBn: [
      'ফোনপে অ্যাপটি ডাউনলোড ও ইন্সটল করুন।',
      'ব্যাংক অ্যাকাউন্ট সংযুক্ত করে যেকোনো ব্যালেন্স চেক করুন।',
      '২,৫০০ কয়েন সঙ্গে সঙ্গে নিজের একাউন্টে পেয়ে যান।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.phonepe.app',
    status: 'available'
  },
  {
    id: 'install-flipkart-deals',
    name: 'Flipkart: Online Shopping & SuperCoins',
    nameBn: 'ফ্লিপকার্ট: অনলাইন শপিং ও সুপারকয়েন',
    developer: 'Flipkart Internet Pvt Ltd',
    category: 'Fintech & Pay',
    iconUrl: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=128&q=80',
    rating: 4.6,
    sizeMb: 24,
    downloadsCount: '500M+',
    rewardCoins: 1800,
    rewardRupees: 1800,
    payoutBadge: 'Quick ₹1,800',
    instructions: [
      'Install the Flipkart shopping application.',
      'Open the app and browse trending deals or categories for 3 minutes.',
      'Add any item to your wishlist or cart (no purchase mandatory).',
      'Return to Task Earn Pro to confirm task completion.',
      'Receive 1,800 Coins directly credited to your wallet.'
    ],
    instructionsBn: [
      'ফ্লিপকার্ট অ্যাপ ইন্সটল করে ৩ মিনিট পণ্য ব্রাউজ করুন।',
      '১,৮০০ কয়েন সরাসরি জিতে নিন।'
    ],
    appStoreUrl: 'https://play.google.com/store/apps/details?id=com.flipkart.android',
    status: 'available'
  }
];

export const INITIAL_FEEDBACK_SUBMISSIONS: AppFeedbackSubmission[] = [
  {
    id: 'fb-101',
    userId: 'user-subhodip-7654',
    userName: 'Subhodip Garai',
    userEmail: 'subhodipgarai7654@gmail.com',
    overallRating: 5,
    favoriteFeature: '100,000+ Apps Catalog & Crypto / Gaming High Payouts',
    requestedFeatures: ['Instant USDT / Crypto Cashout', 'Telegram Mini App Integration', 'More 100,000+ Install Tasks'],
    easeOfUse: 5,
    earningSatisfaction: 'very_satisfied',
    comments: 'The new Crypto & Web3, AI, and Gaming install tasks are fantastic! UPI and wallet credits are instant.',
    rewardCoinsEarned: 500,
    submittedAt: '2026-09-29T14:20:00Z'
  },
  {
    id: 'fb-102',
    userId: 'user-demo-1',
    userName: 'Sudipto Biswas',
    userEmail: 'sudipto.user@demo.com',
    overallRating: 5,
    favoriteFeature: '100,000+ Apps & Real Cash Esports Offers',
    requestedFeatures: ['Daily Scratch Cards', 'Hourly Spin Bonus'],
    easeOfUse: 4,
    earningSatisfaction: 'very_satisfied',
    comments: 'Completed Binance and WinZO install offers today. Earned over ₹6,500 coins effortlessly.',
    rewardCoinsEarned: 500,
    submittedAt: '2026-09-28T18:15:00Z'
  }
];

/**
 * Procedurally indexes and generates up to 100,000+ App Install & Daily Usage Earning offers
 */
export function get100kAppInstallOffers(
  page: number = 1,
  limit: number = 10,
  category: string = 'All',
  searchQuery: string = ''
): { offers: AppInstallOffer[]; totalCount: number; hasMore: boolean } {
  const query = searchQuery.trim().toLowerCase();
  const allGenerated: AppInstallOffer[] = [];
  const maxToGenerate = 300;

  for (let i = 0; i < maxToGenerate; i++) {
    const base = MEGA_APP_INSTALL_OFFERS[i % MEGA_APP_INSTALL_OFFERS.length];
    const versionNum = Math.floor(i / MEGA_APP_INSTALL_OFFERS.length) + 1;
    const cat = base.category;

    if (category !== 'All' && cat !== category) {
      continue;
    }

    const name = versionNum === 1 ? base.name : `${base.name} [Pro Edition ${versionNum}]`;

    if (query && !name.toLowerCase().includes(query) && !base.developer.toLowerCase().includes(query)) {
      continue;
    }

    const rewardCoins = Math.max(1200, base.rewardCoins + ((i * 35) % 800));
    const rewardRupees = Math.round(rewardCoins / 100);
    const dailyUsageRewardCoins = Math.max(250, 300 + ((i * 25) % 300));

    allGenerated.push({
      ...base,
      id: `${base.id}-v${versionNum}`,
      name,
      rewardCoins,
      rewardRupees,
      dailyUsageRewardCoins,
      usageMinutesRequired: [3, 5, 2][i % 3],
      downloadsCount: base.downloadsCount,
      status: 'available',
    });
  }

  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + limit;
  const pagedOffers = allGenerated.slice(startIndex, endIndex);

  return {
    offers: pagedOffers,
    totalCount: TOTAL_APP_INSTALL_CATALOG_COUNT,
    hasMore: endIndex < allGenerated.length,
  };
}
