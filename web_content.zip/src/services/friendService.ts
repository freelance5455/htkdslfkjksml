import { supabase } from '../lib/supabase';
import { Profile, FriendRequest, BlockedUser } from '../types';

export async function searchUsers(query: string, currentUserId: string): Promise<Profile[]> {
  const clean = query.trim().toLowerCase().replace(/^@+/, '');
  if (!clean) return [];

  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .neq('id', currentUserId)
    .ilike('username', `%${clean}%`)
    .limit(20);

  if (error) throw error;
  return data || [];
}

export async function getProfileById(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) return null;
  return data;
}

export async function getFriends(userId: string): Promise<Profile[]> {
  const friendsMap = new Map<string, Profile>();

  // 1. Try querying friendships table if exists
  try {
    const { data: list1, error: err1 } = await supabase
      .from('friendships')
      .select('friend:profiles!friend_id(*)')
      .eq('user_id', userId);

    const { data: list2, error: err2 } = await supabase
      .from('friendships')
      .select('friend:profiles!user_id(*)')
      .eq('friend_id', userId);

    if (!err1 && list1) {
      list1.forEach((item: any) => {
        if (item.friend && item.friend.id !== userId) {
          friendsMap.set(item.friend.id, item.friend);
        }
      });
    }
    if (!err2 && list2) {
      list2.forEach((item: any) => {
        if (item.friend && item.friend.id !== userId) {
          friendsMap.set(item.friend.id, item.friend);
        }
      });
    }
  } catch {
    // Ignore if friendships table is not yet migrated
  }

  // 2. Also check accepted friend requests (which always exist in friend_requests table)
  try {
    const { data: acceptedRequests } = await supabase
      .from('friend_requests')
      .select('sender_id, receiver_id, sender:profiles!sender_id(*), receiver:profiles!receiver_id(*)')
      .eq('status', 'accepted')
      .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`);

    if (acceptedRequests) {
      acceptedRequests.forEach((req: any) => {
        if (req.sender_id === userId && req.receiver && req.receiver.id !== userId) {
          friendsMap.set(req.receiver.id, req.receiver);
        } else if (req.receiver_id === userId && req.sender && req.sender.id !== userId) {
          friendsMap.set(req.sender.id, req.sender);
        }
      });
    }
  } catch {}

  return Array.from(friendsMap.values());
}

export async function getFriendRequests(userId: string): Promise<{
  incoming: FriendRequest[];
  outgoing: FriendRequest[];
}> {
  const { data, error } = await supabase
    .from('friend_requests')
    .select('*, sender:profiles!sender_id(*), receiver:profiles!receiver_id(*)')
    .eq('status', 'pending')
    .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`);

  if (error) throw error;

  const incoming: FriendRequest[] = [];
  const outgoing: FriendRequest[] = [];

  (data || []).forEach((req) => {
    if (req.receiver_id === userId) {
      incoming.push(req as FriendRequest);
    } else if (req.sender_id === userId) {
      outgoing.push(req as FriendRequest);
    }
  });

  return { incoming, outgoing };
}

export async function sendFriendRequest(senderId: string, receiverId: string): Promise<void> {
  if (senderId === receiverId) {
    throw new Error('Cannot send friend request to yourself');
  }

  // Check if blocked
  const isBlocked = await isUserBlocked(senderId, receiverId);
  if (isBlocked) {
    throw new Error('Cannot send request to this user');
  }

  const { error } = await supabase.from('friend_requests').insert({
    sender_id: senderId,
    receiver_id: receiverId,
    status: 'pending',
  });

  if (error) {
    if (error.code === '23505') {
      throw new Error('Friend request already sent or exists');
    }
    throw error;
  }
}

export async function cancelFriendRequest(requestId: string): Promise<void> {
  const { error } = await supabase.from('friend_requests').delete().eq('id', requestId);
  if (error) throw error;
}

export async function acceptFriendRequest(requestId: string, senderId: string, receiverId: string): Promise<void> {
  // Update request status in friend_requests table
  const { error: reqError } = await supabase
    .from('friend_requests')
    .update({ status: 'accepted', updated_at: new Date().toISOString() })
    .eq('id', requestId);

  if (reqError) throw reqError;

  // Attempt to insert into friendships table if it exists
  try {
    await supabase.from('friendships').insert([
      { user_id: senderId, friend_id: receiverId },
    ]);
  } catch {
    // Gracefully ignore if friendships table does not exist
  }
}

export async function rejectFriendRequest(requestId: string): Promise<void> {
  const { error } = await supabase
    .from('friend_requests')
    .update({ status: 'rejected', updated_at: new Date().toISOString() })
    .eq('id', requestId);

  if (error) throw error;
}

export async function removeFriend(userId: string, friendId: string): Promise<void> {
  // Try deleting from friendships table if it exists
  try {
    await supabase
      .from('friendships')
      .delete()
      .or(`and(user_id.eq.${userId},friend_id.eq.${friendId}),and(user_id.eq.${friendId},friend_id.eq.${userId})`);
  } catch {}

  // Clean up the accepted request from friend_requests
  const { error } = await supabase
    .from('friend_requests')
    .delete()
    .or(`and(sender_id.eq.${userId},receiver_id.eq.${friendId}),and(sender_id.eq.${friendId},receiver_id.eq.${userId})`);

  if (error) throw error;
}

export async function blockUser(blockerId: string, blockedId: string): Promise<void> {
  if (blockerId === blockedId) return;

  // Remove friendship if exists
  await removeFriend(blockerId, blockedId).catch(() => {});

  const { error } = await supabase.from('blocked_users').insert({
    blocker_id: blockerId,
    blocked_id: blockedId,
  });

  if (error && error.code !== '23505') {
    throw error;
  }
}

export async function unblockUser(blockerId: string, blockedId: string): Promise<void> {
  const { error } = await supabase
    .from('blocked_users')
    .delete()
    .eq('blocker_id', blockerId)
    .eq('blocked_id', blockedId);

  if (error) throw error;
}

export async function getBlockedUsers(blockerId: string): Promise<BlockedUser[]> {
  const { data, error } = await supabase
    .from('blocked_users')
    .select('blocker_id, blocked_id, created_at, blocked_profile:profiles!blocked_id(*)')
    .eq('blocker_id', blockerId);

  if (error) throw error;
  return (data || []).map((b: any) => ({
    ...b,
    id: `${b.blocker_id}_${b.blocked_id}`,
  })) as BlockedUser[];
}

export async function isUserBlocked(userA: string, userB: string): Promise<boolean> {
  const { data } = await supabase
    .from('blocked_users')
    .select('blocker_id, blocked_id')
    .or(`and(blocker_id.eq.${userA},blocked_id.eq.${userB}),and(blocker_id.eq.${userB},blocked_id.eq.${userA})`)
    .limit(1);

  return Boolean(data && data.length > 0);
}
