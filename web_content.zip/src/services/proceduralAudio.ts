import { Track } from '../types/audio';

// Fast 16-bit PCM WAV encoder
function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  const length = buffer.length * blockAlign;
  const bufferArray = new ArrayBuffer(44 + length);
  const view = new DataView(bufferArray);

  function writeString(offset: number, str: string) {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  }

  /* RIFF chunk */
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + length, true);
  writeString(8, 'WAVE');

  /* fmt sub-chunk */
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true); // SubChunk1Size
  view.setUint16(20, format, true); // AudioFormat
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true); // ByteRate
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);

  /* data sub-chunk */
  writeString(36, 'data');
  view.setUint32(40, length, true);

  // Write interleaved PCM samples
  let offset = 44;
  const channels: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channels.push(buffer.getChannelData(c));
  }

  for (let i = 0; i < buffer.length; i++) {
    for (let c = 0; c < numChannels; c++) {
      let sample = Math.max(-1, Math.min(1, channels[c][i]));
      // 16-bit integer conversion with soft saturation
      sample = sample < 0 ? sample * 32768 : sample * 32767;
      view.setInt16(offset, sample, true);
      offset += 2;
    }
  }

  return new Blob([bufferArray], { type: 'audio/wav' });
}

/**
 * Procedurally synthesize rich musical audio buffers for demo tracks.
 * Generates rhythmic kick, snare, sub-bass, chords, and leads with distinct tempos.
 */
export async function generateDemoTrackBlob(
  genre: 'synthwave' | 'ambient' | 'lofi' | 'audiophile',
  durationSec: number = 32
): Promise<Blob> {
  const sampleRate = 48000;
  const ctx = new OfflineAudioContext(2, sampleRate * durationSec, sampleRate);

  if (genre === 'synthwave') {
    // 120 BPM Synthwave Cyberpunk: 4-on-the-floor kick, 16th bass, lead arpeggio
    const bpm = 120;
    const beatSec = 60 / bpm;
    const totalBeats = Math.floor(durationSec / beatSec);

    // Master bus
    const master = ctx.createGain();
    master.gain.value = 0.85;
    master.connect(ctx.destination);

    // Kicks (punchy sub transient)
    for (let b = 0; b < totalBeats; b++) {
      const time = b * beatSec;
      const osc = ctx.createOscillator();
      const kickGain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(140, time);
      osc.frequency.exponentialRampToValueAtTime(38, time + 0.12);
      kickGain.gain.setValueAtTime(1.0, time);
      kickGain.gain.exponentialRampToValueAtTime(0.001, time + 0.35);
      osc.connect(kickGain);
      kickGain.connect(master);
      osc.start(time);
      osc.stop(time + 0.36);

      // Snare on beats 2 and 4 (indices 1 and 3 in each 4-beat measure)
      if (b % 2 === 1) {
        // Noise snare
        const bufferSize = sampleRate * 0.2;
        const noiseBuffer = ctx.createBuffer(1, bufferSize, sampleRate);
        const output = noiseBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = Math.random() * 2 - 1;
        }
        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        const snareFilter = ctx.createBiquadFilter();
        snareFilter.type = 'highpass';
        snareFilter.frequency.value = 1000;
        const snareGain = ctx.createGain();
        snareGain.gain.setValueAtTime(0.45, time);
        snareGain.gain.exponentialRampToValueAtTime(0.01, time + 0.22);
        whiteNoise.connect(snareFilter);
        snareFilter.connect(snareGain);
        snareGain.connect(master);
        whiteNoise.start(time);
        whiteNoise.stop(time + 0.23);
      }
    }

    // Rolling 16th Synth Bassline (Sawtooth + Lowpass)
    const total16ths = totalBeats * 4;
    const sixteenthSec = beatSec / 4;
    const bassNotes = [55, 55, 55, 58, 62, 58, 55, 53, 50, 50, 50, 53, 55, 58, 62, 65]; // Frequencies around A1 (55Hz)
    for (let s = 0; s < total16ths; s++) {
      const time = s * sixteenthSec;
      const freq = bassNotes[s % bassNotes.length];
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.value = freq;
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, time);
      filter.frequency.exponentialRampToValueAtTime(160, time + sixteenthSec * 0.8);
      filter.Q.value = 4.0;
      gain.gain.setValueAtTime(0.35, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + sixteenthSec * 0.9);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(master);
      osc.start(time);
      osc.stop(time + sixteenthSec);
    }

    // Melodic Synth Chords (Retro Polysynth)
    const chordBeats = 4;
    const chords = [
      [220, 261.63, 329.63, 392], // Am7
      [174.61, 220, 261.63, 329.63], // Fmaj7
      [196, 246.94, 293.66, 392], // G
      [164.81, 207.65, 246.94, 329.63], // Em
    ];
    for (let c = 0; c < Math.floor(totalBeats / chordBeats); c++) {
      const time = c * chordBeats * beatSec;
      const currentChord = chords[c % chords.length];
      currentChord.forEach((noteFreq) => {
        const osc = ctx.createOscillator();
        const chordGain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.value = noteFreq;
        chordGain.gain.setValueAtTime(0.01, time);
        chordGain.gain.linearRampToValueAtTime(0.08, time + 0.3);
        chordGain.gain.exponentialRampToValueAtTime(0.01, time + chordBeats * beatSec - 0.1);
        osc.connect(chordGain);
        chordGain.connect(master);
        osc.start(time);
        osc.stop(time + chordBeats * beatSec);
      });
    }

  } else if (genre === 'ambient') {
    // 85 BPM Ambient Ethereal: Soft deep sub pulse, warm evolving fifths, sparkling pentatonic chimes
    const bpm = 85;
    const beatSec = 60 / bpm;
    const totalBeats = Math.floor(durationSec / beatSec);

    const master = ctx.createGain();
    master.gain.value = 0.8;
    master.connect(ctx.destination);

    // Gentle sub bass pulse every 2 beats
    for (let b = 0; b < totalBeats; b += 2) {
      const time = b * beatSec;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(65.41, time); // C2
      gain.gain.setValueAtTime(0.001, time);
      gain.gain.linearRampToValueAtTime(0.4, time + 0.5);
      gain.gain.exponentialRampToValueAtTime(0.01, time + beatSec * 2 - 0.1);
      osc.connect(gain);
      gain.connect(master);
      osc.start(time);
      osc.stop(time + beatSec * 2);
    }

    // Warm Ambient Pad Waves (C, G, D, A)
    const padFrequencies = [130.81, 196.0, 293.66, 392.0, 523.25];
    padFrequencies.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const pan = ctx.createStereoPanner();
      osc.type = 'sine';
      osc.frequency.value = freq;
      pan.pan.value = (idx % 2 === 0 ? 0.4 : -0.4);
      gain.gain.setValueAtTime(0.02, 0);
      gain.gain.linearRampToValueAtTime(0.12, 4);
      gain.gain.linearRampToValueAtTime(0.08, durationSec / 2);
      gain.gain.linearRampToValueAtTime(0.01, durationSec - 1);
      osc.connect(pan);
      pan.connect(gain);
      gain.connect(master);
      osc.start(0);
      osc.stop(durationSec);
    });

    // Gentle random high bell pings
    const chimePitches = [659.25, 783.99, 987.77, 1046.5, 1318.51, 1567.98];
    for (let i = 0; i < 24; i++) {
      const time = Math.random() * (durationSec - 3) + 1;
      const pitch = chimePitches[Math.floor(Math.random() * chimePitches.length)];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const pan = ctx.createStereoPanner();
      osc.type = 'sine';
      osc.frequency.value = pitch;
      pan.pan.value = Math.random() * 1.6 - 0.8;
      gain.gain.setValueAtTime(0.07, time);
      gain.gain.exponentialRampToValueAtTime(0.0001, time + 1.8);
      osc.connect(pan);
      pan.connect(gain);
      gain.connect(master);
      osc.start(time);
      osc.stop(time + 1.9);
    }

  } else if (genre === 'lofi') {
    // 76 BPM Lofi Chill: Dusty mellow electric keys, syncopated boom-bap kick & warm snare
    const bpm = 76;
    const beatSec = 60 / bpm;
    const totalBeats = Math.floor(durationSec / beatSec);

    const master = ctx.createGain();
    master.gain.value = 0.82;
    master.connect(ctx.destination);

    // Lofi Kick (Soft filtered punch)
    for (let b = 0; b < totalBeats; b += 2) {
      const time = b * beatSec;
      const osc = ctx.createOscillator();
      const kickGain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(100, time);
      osc.frequency.exponentialRampToValueAtTime(45, time + 0.15);
      kickGain.gain.setValueAtTime(0.8, time);
      kickGain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
      osc.connect(kickGain);
      kickGain.connect(master);
      osc.start(time);
      osc.stop(time + 0.32);

      // Syncopated kick on beat 1.75
      if (b % 4 === 0) {
        const syncTime = time + beatSec * 1.75;
        const syncOsc = ctx.createOscillator();
        const syncGain = ctx.createGain();
        syncOsc.type = 'triangle';
        syncOsc.frequency.setValueAtTime(90, syncTime);
        syncOsc.frequency.exponentialRampToValueAtTime(45, syncTime + 0.12);
        syncGain.gain.setValueAtTime(0.65, syncTime);
        syncGain.gain.exponentialRampToValueAtTime(0.01, syncTime + 0.25);
        syncOsc.connect(syncGain);
        syncGain.connect(master);
        syncOsc.start(syncTime);
        syncOsc.stop(syncTime + 0.26);
      }
    }

    // Lofi Snare / Rimshot on beat 2 of each 2-beat group
    for (let b = 1; b < totalBeats; b += 2) {
      const time = b * beatSec;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(220, time);
      gain.gain.setValueAtTime(0.3, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.12);
      osc.connect(gain);
      gain.connect(master);
      osc.start(time);
      osc.stop(time + 0.13);
    }

    // Jazzy Rhodes chords (Fm9 - Bbm7 - Eb7 - Abmaj7)
    const lofiChords = [
      [174.61, 261.63, 311.13, 392.0], // Fm9
      [233.08, 277.18, 349.23, 415.3], // Bbm7
      [155.56, 233.08, 293.66, 369.99], // Eb7
      [207.65, 261.63, 311.13, 392.0], // Abmaj7
    ];
    for (let c = 0; c < Math.floor(totalBeats / 4); c++) {
      const time = c * 4 * beatSec;
      const currentChord = lofiChords[c % lofiChords.length];
      currentChord.forEach((f) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();
        osc.type = 'sine';
        osc.frequency.value = f;
        filter.type = 'lowpass';
        filter.frequency.value = 1400; // Warm roll-off
        gain.gain.setValueAtTime(0.12, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 3.8 * beatSec);
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(master);
        osc.start(time);
        osc.stop(time + 3.9 * beatSec);
      });
    }

  } else {
    // 128 BPM Audiophile Hi-Res Lossless Bass & Dynamic Transient Test
    // Deep sub-sweeps (35Hz-80Hz), punchy kicks, crisp stereo percussion, dynamic wide panning
    const bpm = 128;
    const beatSec = 60 / bpm;
    const totalBeats = Math.floor(durationSec / beatSec);

    const master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(ctx.destination);

    // Sub-Bass Heavy Kick (Specifically tests Bass Boost & 31Hz/63Hz bands)
    for (let b = 0; b < totalBeats; b++) {
      const time = b * beatSec;
      const osc = ctx.createOscillator();
      const kickGain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(160, time);
      osc.frequency.exponentialRampToValueAtTime(35, time + 0.16); // Down to 35Hz deep sub!
      kickGain.gain.setValueAtTime(1.0, time);
      kickGain.gain.exponentialRampToValueAtTime(0.001, time + 0.42);
      osc.connect(kickGain);
      kickGain.connect(master);
      osc.start(time);
      osc.stop(time + 0.43);

      // Claps and hi-hats for high frequencies (8kHz and 16kHz testing)
      if (b % 2 === 1) {
        const clapOsc = ctx.createOscillator();
        const clapGain = ctx.createGain();
        clapOsc.type = 'triangle';
        clapOsc.frequency.setValueAtTime(1200, time);
        clapGain.gain.setValueAtTime(0.35, time);
        clapGain.gain.exponentialRampToValueAtTime(0.01, time + 0.15);
        clapOsc.connect(clapGain);
        clapGain.connect(master);
        clapOsc.start(time);
        clapOsc.stop(time + 0.16);
      }
    }

    // Dynamic Stereo Spatial Arpeggiator (Swings Left to Right every 16th note)
    const arpNotes = [110, 146.83, 164.81, 220, 293.66, 329.63, 440, 587.33];
    const total16ths = totalBeats * 4;
    const sixteenthSec = beatSec / 4;
    for (let s = 0; s < total16ths; s++) {
      const time = s * sixteenthSec;
      const note = arpNotes[s % arpNotes.length];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const pan = ctx.createStereoPanner();
      osc.type = 'sawtooth';
      osc.frequency.value = note;
      // Oscillate pan from -0.8 to +0.8
      pan.pan.value = Math.sin((s / 8) * Math.PI) * 0.85;
      gain.gain.setValueAtTime(0.18, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + sixteenthSec * 0.85);
      osc.connect(pan);
      pan.connect(gain);
      gain.connect(master);
      osc.start(time);
      osc.stop(time + sixteenthSec);
    }
  }

  const renderedBuffer = await ctx.startRendering();
  return audioBufferToWavBlob(renderedBuffer);
}

/**
 * Initializes the default high-fidelity tracks with generated audio and album art.
 */
export async function createDefaultTracks(): Promise<Track[]> {
  const defaultTrackMeta = [
    {
      id: 'demo-1-synthwave',
      title: 'Echoes of the Grid',
      artist: 'Kavinsky Resonance',
      album: 'Synthwave Odyssey',
      genre: 'synthwave' as const,
      coverUrl: '/src/assets/images/cover_neon_synth_1792874211896.jpg',
      format: 'wav' as const,
      sampleRate: 48000,
      bitDepth: 24,
      folderPath: 'Música/Synthwave',
      duration: 32,
    },
    {
      id: 'demo-2-ambient',
      title: 'Aurora Drift',
      artist: 'Celestial Echoes',
      album: 'Ambient Horizons',
      genre: 'ambient' as const,
      coverUrl: '/src/assets/images/cover_ambient_dawn_1792874212515.jpg',
      format: 'flac' as const,
      sampleRate: 96000,
      bitDepth: 24,
      folderPath: 'Música/Ambiental',
      duration: 32,
    },
    {
      id: 'demo-3-lofi',
      title: 'Distant Lights',
      artist: 'Tokyo Midnight Collective',
      album: 'Nocturnal Coffee',
      genre: 'lofi' as const,
      coverUrl: '/src/assets/images/cover_lofi_midnight_1792874213440.jpg',
      format: 'mp3' as const,
      sampleRate: 44100,
      bitDepth: 16,
      folderPath: 'Música/Lo-Fi',
      duration: 32,
    },
    {
      id: 'demo-4-bass',
      title: 'Synthesis (Fluid Currents)',
      artist: 'Audiophile Lab',
      album: 'Hi-Res Sub Acoustic',
      genre: 'audiophile' as const,
      coverUrl: '/src/assets/images/cover_deep_bass_1792874213578.jpg',
      format: 'wav' as const,
      sampleRate: 48000,
      bitDepth: 32,
      folderPath: 'Música/Hi-Res Master',
      duration: 32,
    },
  ];

  const tracks: Track[] = [];

  for (const meta of defaultTrackMeta) {
    try {
      const blob = await generateDemoTrackBlob(meta.genre, meta.duration);
      const url = URL.createObjectURL(blob);
      tracks.push({
        id: meta.id,
        title: meta.title,
        artist: meta.artist,
        album: meta.album,
        duration: meta.duration,
        url: url,
        blob: blob,
        coverUrl: meta.coverUrl,
        format: meta.format,
        sampleRate: meta.sampleRate,
        bitDepth: meta.bitDepth,
        fileSize: blob.size,
        folderPath: meta.folderPath,
        dateAdded: Date.now() - 1000 * 60 * 60 * 24 * (tracks.length + 1),
        isFavorite: meta.genre === 'synthwave' || meta.genre === 'audiophile',
        isBuiltIn: true,
      });
    } catch (e) {
      console.error('Error generating procedural audio track:', e);
    }
  }

  return tracks;
}
