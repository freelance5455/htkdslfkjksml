import { formatLocalFallbackText } from '../utils/formatting';

export function hasHttpApiOrigin(): boolean {
  if (typeof window === 'undefined') return false;
  const { protocol, host } = window.location;
  return (protocol === 'http:' || protocol === 'https:') && Boolean(host);
}

async function safeParseJsonResponse<T>(response: Response): Promise<T> {
  const rawText = await response.text();
  const trimmed = rawText.trim();
  if (!trimmed) {
    if (!response.ok) {
      throw new Error(`Server returned empty response (status ${response.status}).`);
    }
    return {} as T;
  }

  if (trimmed.startsWith('<')) {
    throw new Error(
      `API endpoint unavailable in standalone preview (status ${response.status}).`
    );
  }

  try {
    return JSON.parse(trimmed) as T;
  } catch {
    throw new Error(`Invalid JSON response from server (status ${response.status}).`);
  }
}

export async function transcribeLiveChunk(payload: {
  audioBase64: string;
  mimeType: string;
  speakingLangName: string;
  speakingLangCode: string;
  outputLangName: string;
  outputLangCode: string;
}): Promise<{ transcript: string; translation: string }> {
  if (!hasHttpApiOrigin()) {
    return { transcript: '', translation: '' };
  }
  try {
    const response = await fetch('/api/transcribe-chunk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!response.ok) return { transcript: '', translation: '' };
    const data = await safeParseJsonResponse<{
      transcript?: string;
      translation?: string;
    }>(response);
    return {
      transcript: data.transcript ?? '',
      translation: data.translation ?? '',
    };
  } catch {
    return { transcript: '', translation: '' };
  }
}

export async function finalizeSegment(payload: {
  rawText: string;
  speakingLangName: string;
  speakingLangCode: string;
  outputLangName: string;
  outputLangCode: string;
}): Promise<string> {
  const effectiveLangCode =
    payload.outputLangCode === 'same'
      ? payload.speakingLangCode
      : payload.outputLangCode;

  if (!hasHttpApiOrigin()) {
    return formatLocalFallbackText(payload.rawText, effectiveLangCode);
  }

  try {
    const response = await fetch('/api/finalize-segment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await safeParseJsonResponse<{ finalText?: string; error?: string }>(
      response
    );
    if (!response.ok) {
      return (
        data.finalText || formatLocalFallbackText(payload.rawText, effectiveLangCode)
      );
    }
    return (
      data.finalText ?? formatLocalFallbackText(payload.rawText, effectiveLangCode)
    ).trim();
  } catch {
    return formatLocalFallbackText(payload.rawText, effectiveLangCode);
  }
}

export async function translateWrittenText(payload: {
  text: string;
  targetLangName: string;
  targetLangCode: string;
}): Promise<string> {
  if (!hasHttpApiOrigin()) {
    throw new Error('Automatic translation requires an online server connection.');
  }

  const response = await fetch('/api/translate-text', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await safeParseJsonResponse<{
    translatedText?: string;
    error?: string;
  }>(response);
  if (!response.ok) {
    throw new Error(data.error || `Translation failed (status ${response.status})`);
  }
  return (data.translatedText ?? payload.text).trim();
}

export async function enhanceWrittenText(payload: {
  text: string;
  languageName: string;
  languageCode: string;
}): Promise<string> {
  if (!hasHttpApiOrigin()) {
    return formatLocalFallbackText(payload.text, payload.languageCode);
  }

  try {
    const response = await fetch('/api/enhance-text', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await safeParseJsonResponse<{
      enhancedText?: string;
      error?: string;
    }>(response);
    if (!response.ok) {
      throw new Error(data.error || `AI Enhance failed (status ${response.status})`);
    }
    return (data.enhancedText ?? payload.text).trim();
  } catch (err) {
    // Graceful local formatting fallback when running inside a static ZIP preview without Express backend
    if (
      err instanceof Error &&
      err.message.includes('API endpoint unavailable in standalone preview')
    ) {
      return formatLocalFallbackText(payload.text, payload.languageCode);
    }
    throw err;
  }
}
