/**
 * AudioStreamer handles:
 * 1. 16kHz PCM16 microphone recording for Gemini Live API input
 * 2. 24kHz PCM16 audio playback for Gemini Live API output
 * 3. Gapless scheduling & Instant Barge-in (interruption)
 */

export class AudioStreamer {
  // Input (Microphone) properties
  private inputAudioCtx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private inputSourceNode: MediaStreamAudioSourceNode | null = null;
  private onAudioInputCallback: ((base64Pcm16: string) => void) | null = null;
  private inputAnalyser: AnalyserNode | null = null;

  // Output (Playback) properties
  private outputAudioCtx: AudioContext | null = null;
  private outputAnalyser: AnalyserNode | null = null;
  private nextStartTime: number = 0;
  private activeSourceNodes: AudioBufferSourceNode[] = [];
  private isMuted: boolean = false;

  constructor() {}

  // ----------------------------------------------------
  // MICROPHONE RECORDING (16kHz PCM16)
  // ----------------------------------------------------
  public async startRecording(onAudioChunk: (base64Pcm16: string) => void): Promise<void> {
    this.stopRecording();
    this.onAudioInputCallback = onAudioChunk;

    try {
      // Request mic with echo cancellation, noise suppression
      this.micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      // Browser AudioContext at 16000Hz with interactive latency hint
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.inputAudioCtx = new AudioCtxClass({
        sampleRate: 16000,
        latencyHint: 'interactive',
      });
      if (this.inputAudioCtx.state === 'suspended') {
        await this.inputAudioCtx.resume();
      }

      this.inputSourceNode = this.inputAudioCtx.createMediaStreamSource(this.micStream);

      // Create analyser for user speech visualization
      this.inputAnalyser = this.inputAudioCtx.createAnalyser();
      this.inputAnalyser.fftSize = 64;
      this.inputSourceNode.connect(this.inputAnalyser);

      // ScriptProcessor with 1024 buffer (~64ms at 16kHz for ultra-low latency streaming)
      this.processorNode = this.inputAudioCtx.createScriptProcessor(1024, 1, 1);

      this.processorNode.onaudioprocess = (e: AudioProcessingEvent) => {
        if (!this.onAudioInputCallback) return;
        const inputChannelData = e.inputBuffer.getChannelData(0);
        const base64Chunk = this.float32ToPcm16Base64(inputChannelData);
        if (base64Chunk) {
          this.onAudioInputCallback(base64Chunk);
        }
      };

      this.inputSourceNode.connect(this.processorNode);
      this.processorNode.connect(this.inputAudioCtx.destination);
    } catch (err) {
      this.stopRecording();
      throw err;
    }
  }

  public stopRecording(): void {
    if (this.processorNode) {
      this.processorNode.disconnect();
      this.processorNode.onaudioprocess = null;
      this.processorNode = null;
    }
    if (this.inputSourceNode) {
      this.inputSourceNode.disconnect();
      this.inputSourceNode = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }
    if (this.inputAudioCtx) {
      this.inputAudioCtx.close().catch(() => {});
      this.inputAudioCtx = null;
    }
    this.onAudioInputCallback = null;
    this.inputAnalyser = null;
  }

  // ----------------------------------------------------
  // AUDIO PLAYBACK (24kHz PCM16)
  // ----------------------------------------------------
  public initPlayback(): void {
    if (!this.outputAudioCtx || this.outputAudioCtx.state === 'closed') {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.outputAudioCtx = new AudioCtxClass({
        sampleRate: 24000,
        latencyHint: 'interactive',
      });
      this.outputAnalyser = this.outputAudioCtx.createAnalyser();
      this.outputAnalyser.fftSize = 64;
      this.outputAnalyser.connect(this.outputAudioCtx.destination);
      this.nextStartTime = this.outputAudioCtx.currentTime;
    }

    if (this.outputAudioCtx.state === 'suspended') {
      this.outputAudioCtx.resume().catch(() => {});
    }
  }

  public playChunk(base64Pcm24k: string): void {
    if (this.isMuted) return;
    this.initPlayback();
    if (!this.outputAudioCtx || !this.outputAnalyser) return;

    try {
      const float32Array = this.base64Pcm16ToFloat32(base64Pcm24k);
      if (float32Array.length === 0) return;

      const audioBuffer = this.outputAudioCtx.createBuffer(1, float32Array.length, 24000);
      audioBuffer.getChannelData(0).set(float32Array);

      const sourceNode = this.outputAudioCtx.createBufferSource();
      sourceNode.buffer = audioBuffer;
      sourceNode.connect(this.outputAnalyser);

      const currentTime = this.outputAudioCtx.currentTime;
      // Schedule gapless
      if (this.nextStartTime < currentTime) {
        this.nextStartTime = currentTime;
      }

      sourceNode.start(this.nextStartTime);
      this.nextStartTime += audioBuffer.duration;

      this.activeSourceNodes.push(sourceNode);

      sourceNode.onended = () => {
        const index = this.activeSourceNodes.indexOf(sourceNode);
        if (index !== -1) {
          this.activeSourceNodes.splice(index, 1);
        }
      };
    } catch (e) {
      console.error('Error playing audio chunk:', e);
    }
  }

  /**
   * Barge-in interruption: immediately silence current playback
   */
  public interrupt(): void {
    for (const source of this.activeSourceNodes) {
      try {
        source.stop();
        source.disconnect();
      } catch {
        // already stopped
      }
    }
    this.activeSourceNodes = [];
    if (this.outputAudioCtx) {
      this.nextStartTime = this.outputAudioCtx.currentTime;
    }
  }

  public stopAll(): void {
    this.interrupt();
    this.stopRecording();
    if (this.outputAudioCtx) {
      this.outputAudioCtx.close().catch(() => {});
      this.outputAudioCtx = null;
    }
  }

  // ----------------------------------------------------
  // WAVEFORM / VOLUME RETRIEVAL
  // ----------------------------------------------------
  public getOutputVolume(): number {
    if (!this.outputAnalyser) return 0;
    const buffer = new Uint8Array(this.outputAnalyser.frequencyBinCount);
    this.outputAnalyser.getByteFrequencyData(buffer);
    let sum = 0;
    for (let i = 0; i < buffer.length; i++) {
      sum += buffer[i];
    }
    return sum / (buffer.length * 255);
  }

  public getInputVolume(): number {
    if (!this.inputAnalyser) return 0;
    const buffer = new Uint8Array(this.inputAnalyser.frequencyBinCount);
    this.inputAnalyser.getByteFrequencyData(buffer);
    let sum = 0;
    for (let i = 0; i < buffer.length; i++) {
      sum += buffer[i];
    }
    return sum / (buffer.length * 255);
  }

  // ----------------------------------------------------
  // PCM UTILITIES
  // ----------------------------------------------------
  private float32ToPcm16Base64(input: Float32Array): string {
    const pcm16 = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    const bytes = new Uint8Array(pcm16.buffer);
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private base64Pcm16ToFloat32(base64: string): Float32Array {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }
    return float32Array;
  }
}
