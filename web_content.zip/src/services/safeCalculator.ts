/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Safe mathematical calculation engine.
 * Never uses `eval()` or `Function()` constructors.
 * Uses recursive descent parsing with lexical tokenization.
 */

type TokenType = 'NUMBER' | 'OP' | 'LPAREN' | 'RPAREN' | 'FUNC';

interface Token {
  type: TokenType;
  value: string | number;
}

export class SafeCalculator {
  /**
   * Evaluates natural language percentage phrases such as "20% of 150" or "15 percent of 800"
   */
  private static preprocessNaturalLanguage(input: string): string {
    let clean = input.toLowerCase().trim();

    // Handle "X% of Y" or "X percent of Y"
    const percentOfRegex = /([\d.]+)\s*(?:%|percent)\s+of\s+([\d.]+)/gi;
    clean = clean.replace(percentOfRegex, '($1 / 100 * $2)');

    // Handle "multiplied by", "times", "x"
    clean = clean.replace(/\bmultiplied\s+by\b/g, '*');
    clean = clean.replace(/\btimes\b/g, '*');
    clean = clean.replace(/\bdivided\s+by\b/g, '/');
    clean = clean.replace(/\bplus\b/g, '+');
    clean = clean.replace(/\bminus\b/g, '-');

    // Replace words like 'square root of X' or 'sqrt(X)'
    clean = clean.replace(/\bsquare\s+root\s+of\s+([\d.]+)/g, 'sqrt($1)');

    return clean;
  }

  private static tokenize(expression: string): Token[] {
    const tokens: Token[] = [];
    let i = 0;
    const len = expression.length;

    while (i < len) {
      const char = expression[i];

      if (/\s/.test(char)) {
        i++;
        continue;
      }

      if (/[\d.]/.test(char)) {
        let numStr = '';
        while (i < len && /[\d.]/.test(expression[i])) {
          numStr += expression[i];
          i++;
        }
        const num = parseFloat(numStr);
        if (isNaN(num)) throw new Error(`Invalid number: ${numStr}`);
        tokens.push({ type: 'NUMBER', value: num });
        continue;
      }

      if (char === '(') {
        tokens.push({ type: 'LPAREN', value: '(' });
        i++;
        continue;
      }

      if (char === ')') {
        tokens.push({ type: 'RPAREN', value: ')' });
        i++;
        continue;
      }

      if (['+', '-', '*', '/', '^', '%'].includes(char)) {
        tokens.push({ type: 'OP', value: char });
        i++;
        continue;
      }

      // Check alphabetic functions (sqrt, sin, cos, tan, abs, pi, e)
      if (/[a-z]/i.test(char)) {
        let word = '';
        while (i < len && /[a-z]/i.test(expression[i])) {
          word += expression[i].toLowerCase();
          i++;
        }
        if (word === 'pi') {
          tokens.push({ type: 'NUMBER', value: Math.PI });
        } else if (word === 'e') {
          tokens.push({ type: 'NUMBER', value: Math.E });
        } else if (['sqrt', 'abs', 'round', 'floor', 'ceil', 'sin', 'cos', 'tan'].includes(word)) {
          tokens.push({ type: 'FUNC', value: word });
        } else {
          throw new Error(`Unsupported mathematical function or variable: '${word}'`);
        }
        continue;
      }

      throw new Error(`Unsupported character in calculation: '${char}'`);
    }

    return tokens;
  }

  public static evaluate(rawExpression: string): { success: boolean; result?: number; error?: string } {
    try {
      const preprocessed = this.preprocessNaturalLanguage(rawExpression);
      const tokens = this.tokenize(preprocessed);

      if (tokens.length === 0) {
        return { success: false, error: 'Empty expression.' };
      }

      let cursor = 0;

      const peek = (): Token | undefined => tokens[cursor];
      const consume = (): Token => tokens[cursor++];

      // Grammar:
      // Expr    ::= Term (('+' | '-') Term)*
      // Term    ::= Power (('*' | '/' | '%') Power)*
      // Power   ::= Factor ('^' Factor)*
      // Factor  ::= ('+' | '-')? (NUMBER | FUNC '(' Expr ')' | '(' Expr ')')

      function parseExpression(): number {
        let val = parseTerm();
        while (cursor < tokens.length) {
          const tok = peek();
          if (tok && tok.type === 'OP' && (tok.value === '+' || tok.value === '-')) {
            consume();
            const right = parseTerm();
            if (tok.value === '+') val += right;
            else val -= right;
          } else {
            break;
          }
        }
        return val;
      }

      function parseTerm(): number {
        let val = parsePower();
        while (cursor < tokens.length) {
          const tok = peek();
          if (tok && tok.type === 'OP' && (tok.value === '*' || tok.value === '/' || tok.value === '%')) {
            consume();
            const right = parsePower();
            if (tok.value === '*') val *= right;
            else if (tok.value === '/') {
              if (right === 0) throw new Error('Division by zero');
              val /= right;
            } else if (tok.value === '%') {
              val = val % right;
            }
          } else {
            break;
          }
        }
        return val;
      }

      function parsePower(): number {
        let val = parseFactor();
        while (cursor < tokens.length) {
          const tok = peek();
          if (tok && tok.type === 'OP' && tok.value === '^') {
            consume();
            const right = parseFactor();
            val = Math.pow(val, right);
          } else {
            break;
          }
        }
        return val;
      }

      function parseFactor(): number {
        const tok = peek();
        if (!tok) throw new Error('Unexpected end of expression');

        // Unary plus/minus
        if (tok.type === 'OP' && (tok.value === '+' || tok.value === '-')) {
          consume();
          const factor = parseFactor();
          return tok.value === '-' ? -factor : factor;
        }

        if (tok.type === 'NUMBER') {
          consume();
          return tok.value as number;
        }

        if (tok.type === 'FUNC') {
          const funcName = consume().value as string;
          const next = peek();
          if (!next || next.type !== 'LPAREN') {
            throw new Error(`Expected '(' after function ${funcName}`);
          }
          consume(); // consume '('
          const arg = parseExpression();
          const closeParen = peek();
          if (!closeParen || closeParen.type !== 'RPAREN') {
            throw new Error(`Expected ')' to close function ${funcName}`);
          }
          consume(); // consume ')'

          switch (funcName) {
            case 'sqrt':
              if (arg < 0) throw new Error('Square root of negative number');
              return Math.sqrt(arg);
            case 'abs':
              return Math.abs(arg);
            case 'round':
              return Math.round(arg);
            case 'floor':
              return Math.floor(arg);
            case 'ceil':
              return Math.ceil(arg);
            case 'sin':
              return Math.sin(arg);
            case 'cos':
              return Math.cos(arg);
            case 'tan':
              return Math.tan(arg);
            default:
              throw new Error(`Unknown function: ${funcName}`);
          }
        }

        if (tok.type === 'LPAREN') {
          consume(); // '('
          const val = parseExpression();
          const closeParen = peek();
          if (!closeParen || closeParen.type !== 'RPAREN') {
            throw new Error('Mismatched parentheses: expected closing \')\'');
          }
          consume(); // ')'
          return val;
        }

        throw new Error(`Unexpected token: ${String(tok.value)}`);
      }

      const result = parseExpression();

      if (cursor < tokens.length) {
        throw new Error(`Unexpected trailing tokens at position ${cursor}`);
      }

      // Check for finite result
      if (!isFinite(result) || isNaN(result)) {
        return { success: false, error: 'Calculation resulted in an undefined or infinite number.' };
      }

      // Round to reasonable precision to avoid IEEE floating point quirks (e.g. 0.1 + 0.2 = 0.30000000000000004)
      const cleanResult = Math.round((result + Number.EPSILON) * 1e10) / 1e10;
      return { success: true, result: cleanResult };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Invalid mathematical expression';
      return { success: false, error: message };
    }
  }
}
