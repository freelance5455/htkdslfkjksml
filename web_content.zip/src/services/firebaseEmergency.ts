import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
} from 'firebase/firestore';
import { EmergencyContact } from '../types';

// Standard Firebase config initialized safely
const metaEnv = (import.meta as unknown as { env?: Record<string, string> }).env || {};

const firebaseConfig = {
  apiKey: metaEnv.VITE_FIREBASE_API_KEY || 'AIzaSyDemoMediguideKeyForEmergency',
  authDomain: metaEnv.VITE_FIREBASE_AUTH_DOMAIN || 'mediguide-ai.firebaseapp.com',
  projectId: metaEnv.VITE_FIREBASE_PROJECT_ID || 'mediguide-ai',
  storageBucket: metaEnv.VITE_FIREBASE_STORAGE_BUCKET || 'mediguide-ai.appspot.com',
  messagingSenderId: metaEnv.VITE_FIREBASE_MESSAGING_SENDER_ID || '123456789',
  appId: metaEnv.VITE_FIREBASE_APP_ID || '1:123456789:web:abcdef123456',
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const db = getFirestore(app);

const LOCAL_STORAGE_KEY = 'mediguide_emergency_contacts_v3';

function getLocalContacts(userId: string): EmergencyContact[] {
  try {
    const raw = localStorage.getItem(`${LOCAL_STORAGE_KEY}_${userId}`);
    if (raw) {
      const parsed: EmergencyContact[] = JSON.parse(raw);
      // Filter out any legacy seed contacts if present
      const clean = parsed.filter((c) => !c.id.startsWith('contact_seed_'));
      return clean;
    }
    return [];
  } catch (err) {
    console.warn('[EmergencyService] Local storage read error:', err);
    return [];
  }
}

function saveLocalContacts(userId: string, contacts: EmergencyContact[]) {
  try {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_${userId}`, JSON.stringify(contacts));
  } catch (err) {
    console.warn('[EmergencyService] Local storage write error:', err);
  }
}

/**
 * Get emergency contacts from Firebase Firestore with seamless fallback
 */
export async function fetchEmergencyContacts(userId: string = 'guest_user'): Promise<EmergencyContact[]> {
  try {
    const contactsRef = collection(db, 'users', userId, 'emergency_contacts');
    const snapshot = await getDocs(query(contactsRef));

    if (!snapshot.empty) {
      const remoteContacts: EmergencyContact[] = snapshot.docs
        .map((d) => ({
          id: d.id,
          ...(d.data() as Omit<EmergencyContact, 'id'>),
        }))
        .filter((c) => !c.id.startsWith('contact_seed_'));

      // Sync local
      saveLocalContacts(userId, remoteContacts);
      return remoteContacts;
    } else {
      // Empty Firestore collection -> clear local storage for this user as well
      saveLocalContacts(userId, []);
      return [];
    }
  } catch (err) {
    console.warn('[EmergencyService] Firestore fetch error, using local fallback:', err);
  }

  return getLocalContacts(userId);
}

/**
 * Add a new emergency contact (max 5 contacts limit enforced)
 */
export async function addEmergencyContact(
  userId: string = 'guest_user',
  contactData: { fullName: string; relationship: string; mobileNumber: string }
): Promise<{ success: boolean; contact?: EmergencyContact; error?: string }> {
  const currentContacts = await fetchEmergencyContacts(userId);

  if (currentContacts.length >= 5) {
    return {
      success: false,
      error: 'Emergency contacts limit reached. You can save a maximum of 5 emergency contacts.',
    };
  }

  const newId = `emc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const newContact: EmergencyContact = {
    id: newId,
    fullName: contactData.fullName.trim(),
    relationship: contactData.relationship.trim(),
    mobileNumber: contactData.mobileNumber.trim(),
    createdAt: new Date().toISOString(),
  };

  // Try writing to Firestore
  try {
    const docRef = doc(db, 'users', userId, 'emergency_contacts', newId);
    await setDoc(docRef, {
      fullName: newContact.fullName,
      relationship: newContact.relationship,
      mobileNumber: newContact.mobileNumber,
      createdAt: newContact.createdAt,
    });
  } catch (err) {
    console.warn('[EmergencyService] Firestore write failed, persisting to local storage:', err);
  }

  // Update local storage
  const updated = [newContact, ...currentContacts];
  saveLocalContacts(userId, updated);

  return { success: true, contact: newContact };
}

/**
 * Edit an existing emergency contact
 */
export async function updateEmergencyContact(
  userId: string = 'guest_user',
  contact: EmergencyContact
): Promise<{ success: boolean; error?: string }> {
  try {
    const docRef = doc(db, 'users', userId, 'emergency_contacts', contact.id);
    await setDoc(docRef, {
      fullName: contact.fullName,
      relationship: contact.relationship,
      mobileNumber: contact.mobileNumber,
      createdAt: contact.createdAt || new Date().toISOString(),
    });
  } catch (err) {
    console.warn('[EmergencyService] Firestore update failed, writing local:', err);
  }

  const current = getLocalContacts(userId);
  const index = current.findIndex((c) => c.id === contact.id);
  if (index !== -1) {
    current[index] = contact;
    saveLocalContacts(userId, current);
  }

  return { success: true };
}

/**
 * Delete an emergency contact permanently
 */
export async function deleteEmergencyContact(
  userId: string = 'guest_user',
  contactId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const docRef = doc(db, 'users', userId, 'emergency_contacts', contactId);
    await deleteDoc(docRef);
  } catch (err) {
    console.warn('[EmergencyService] Firestore delete failed, deleting locally:', err);
  }

  const current = getLocalContacts(userId);
  const filtered = current.filter((c) => c.id !== contactId);
  saveLocalContacts(userId, filtered);

  return { success: true };
}
