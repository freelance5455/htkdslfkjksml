import { AlarmSoundId } from '../types/clock';

class SoundService {
  private ctx: AudioContext | null = null;
  private activeLoopInterval: number | null = null;
  private isAlarmPlaying = false;

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  /**
   * Play a single preview iteration of any alarm sound
   */
  public playSound(soundId: AlarmSoundId, volume = 0.8) {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    switch (soundId) {
      case 'chime':
        this.playChimeTone(ctx, volume);
        break;
      case 'digital':
        this.playDigitalTone(ctx, volume);
        break;
      case 'marimba':
        this.playMarimbaTone(ctx, volume);
        break;
      case 'radar':
        this.playRadarTone(ctx, volume);
        break;
      case 'zen':
        this.playZenTone(ctx, volume);
        break;
      case 'energetic':
        this.playEnergeticTone(ctx, volume);
        break;
      default:
        this.playDigitalTone(ctx, volume);
    }
  }

  /**
   * Start a looping alarm ring
   */
  public startAlarmLoop(soundId: AlarmSoundId, volume = 0.8) {
    this.stopAlarm();
    this.isAlarmPlaying = true;

    // Play immediately
    this.playSound(soundId, volume);

    // Set repeat interval depending on tone duration
    const intervalMap: Record<AlarmSoundId, number> = {
      digital: 1200,
      chime: 2200,
      marimba: 2400,
      radar: 1600,
      zen: 3000,
      energetic: 2000,
    };

    const intervalTime = intervalMap[soundId] || 1500;

    this.activeLoopInterval = window.setInterval(() => {
      if (this.isAlarmPlaying) {
        this.playSound(soundId, volume);
      }
    }, intervalTime);
  }

  /**
   * Stop any active alarm ringing
   */
  public stopAlarm() {
    this.isAlarmPlaying = false;
    if (this.activeLoopInterval !== null) {
      clearInterval(this.activeLoopInterval);
      this.activeLoopInterval = null;
    }
  }

  public getIsPlaying(): boolean {
    return this.isAlarmPlaying;
  }

  /**
   * Hourly chime: soft pleasant 2-tone chime
   */
  public playHourlyChime(volume = 0.5) {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now); // A5

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1320, now + 0.18); // E6

    gainNode.gain.setValueAtTime(0, now);
    gainNode.gain.linearRampToValueAtTime(volume * 0.4, now + 0.05);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc1.start(now);
    osc1.stop(now + 0.3);
    osc2.start(now + 0.18);
    osc2.stop(now + 0.8);
  }

  // --- Sound Synthesizers ---

  private playChimeTone(ctx: AudioContext, masterVolume: number) {
    const now = ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6 chord

    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.12);

      // Bell harmonics overtone
      const overtone = ctx.createOscillator();
      const overtoneGain = ctx.createGain();
      overtone.type = 'sine';
      overtone.frequency.setValueAtTime(freq * 2.76, now + i * 0.12);

      const noteStart = now + i * 0.12;
      const noteEnd = noteStart + 1.6;

      gain.gain.setValueAtTime(0, noteStart);
      gain.gain.linearRampToValueAtTime((masterVolume * 0.25) / (i + 1), noteStart + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, noteEnd);

      overtoneGain.gain.setValueAtTime(0, noteStart);
      overtoneGain.gain.linearRampToValueAtTime(masterVolume * 0.05, noteStart + 0.02);
      overtoneGain.gain.exponentialRampToValueAtTime(0.0001, noteEnd);

      osc.connect(gain);
      overtone.connect(overtoneGain);
      gain.connect(ctx.destination);
      overtoneGain.connect(ctx.destination);

      osc.start(noteStart);
      osc.stop(noteEnd);
      overtone.start(noteStart);
      overtone.stop(noteEnd);
    });
  }

  private playDigitalTone(ctx: AudioContext, masterVolume: number) {
    const now = ctx.currentTime;
    // Classic rapid double beep: beep-beep, beep-beep
    const bursts = [0, 0.12, 0.35, 0.47];
    const freq = 1200; // Crisp classic quartz digital buzzer frequency

    bursts.forEach((offset) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(freq, now + offset);

      const burstStart = now + offset;
      const burstEnd = burstStart + 0.08;

      gain.gain.setValueAtTime(0, burstStart);
      gain.gain.linearRampToValueAtTime(masterVolume * 0.22, burstStart + 0.005);
      gain.gain.linearRampToValueAtTime(0, burstEnd);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(burstStart);
      osc.stop(burstEnd);
    });
  }

  private playMarimbaTone(ctx: AudioContext, masterVolume: number) {
    const now = ctx.currentTime;
    const melody = [
      { freq: 440, delay: 0 },    // A4
      { freq: 554.37, delay: 0.15 }, // C#5
      { freq: 659.25, delay: 0.30 }, // E5
      { freq: 880, delay: 0.45 },    // A5
      { freq: 1108.73, delay: 0.65 } // C#6
    ];

    melody.forEach((note) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(note.freq, now + note.delay);

      const tStart = now + note.delay;
      const tEnd = tStart + 0.5;

      gain.gain.setValueAtTime(0, tStart);
      gain.gain.linearRampToValueAtTime(masterVolume * 0.3, tStart + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, tEnd);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(tStart);
      osc.stop(tEnd);
    });
  }

  private playRadarTone(ctx: AudioContext, masterVolume: number) {
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(900, now);
    osc.frequency.exponentialRampToValueAtTime(300, now + 0.8);

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(masterVolume * 0.35, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.95);
  }

  private playZenTone(ctx: AudioContext, masterVolume: number) {
    const now = ctx.currentTime;
    const baseFreq = 220; // A3 deep gong / singing bowl

    const harmonics = [1, 1.5, 2.76, 4.1];
    harmonics.forEach((mult, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq * mult, now);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime((masterVolume * 0.3) / (index + 1), now + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 2.5);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 2.5);
    });
  }

  private playEnergeticTone(ctx: AudioContext, masterVolume: number) {
    const now = ctx.currentTime;
    const notes = [587.33, 739.99, 880, 1174.66, 1479.98]; // D5, F#5, A5, D6, F#6

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now + idx * 0.09);

      const noteStart = now + idx * 0.09;
      const noteEnd = noteStart + 0.25;

      gain.gain.setValueAtTime(0, noteStart);
      gain.gain.linearRampToValueAtTime(masterVolume * 0.16, noteStart + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, noteEnd);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(noteStart);
      osc.stop(noteEnd);
    });
  }
}

export const soundService = new SoundService();
