/**
 * GODEX v0.0.1 - Project Memory & Secret Safety Vault
 */

import { ProjectMemoryItem } from '../types';

export class ProjectMemoryService {
  private static STORAGE_KEY = 'codex_studio_project_memory';

  private static memoryCache: ProjectMemoryItem[] | null = null;

  public static getMemoryItems(): ProjectMemoryItem[] {
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        const raw = localStorage.getItem(this.STORAGE_KEY);
        if (raw) return JSON.parse(raw);
      } catch {
        // Fallback
      }
    } else if (this.memoryCache) {
      return this.memoryCache;
    }

    const defaultItems: ProjectMemoryItem[] = [
      {
        id: 'mem-1',
        category: 'architecture',
        title: 'Component Separation & Modular State',
        content: 'Keep single-responsibility components with clean React hooks and Tailwind CSS styling.',
        updatedAt: Date.now() - 3600000
      },
      {
        id: 'mem-2',
        category: 'conventions',
        title: 'Lucide React Icons & Strict Types',
        content: 'Use lucide-react standard icon sets without custom SVGs. Keep all TypeScript interfaces declared.',
        updatedAt: Date.now() - 1800000
      },
      {
        id: 'mem-3',
        category: 'test_expectations',
        title: 'Browser Automation Assertions',
        content: 'Ensure all primary user action buttons (export, play, submit) have targetable IDs and render valid DOM states.',
        updatedAt: Date.now() - 900000
      }
    ];

    this.memoryCache = defaultItems;
    return defaultItems;
  }

  public static saveMemoryItem(item: Omit<ProjectMemoryItem, 'id' | 'updatedAt'>): ProjectMemoryItem {
    const items = this.getMemoryItems();
    const newItem: ProjectMemoryItem = {
      ...item,
      id: 'mem-' + Date.now(),
      updatedAt: Date.now()
    };
    items.unshift(newItem);
    this.memoryCache = items;
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(items));
      } catch {
        // ignore
      }
    }
    return newItem;
  }

  public static deleteMemoryItem(id: string): void {
    const items = this.getMemoryItems().filter(i => i.id !== id);
    this.memoryCache = items;
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(items));
      } catch {
        // ignore
      }
    }
  }

  /**
   * Secret Safety Vault: Redacts sensitive keys, tokens, and credentials
   */
  public static redactSecrets(text: string): string {
    if (!text) return '';
    return text
      // Redact Gemini API keys (AIza...)
      .replace(/AIza[0-9A-Za-z-_]{35}/g, '[REDACTED_GEMINI_KEY]')
      // Redact Bearer tokens
      .replace(/Bearer\s+[A-Za-z0-9\-_.]+/gi, 'Bearer [REDACTED_TOKEN]')
      // Redact password assignments
      .replace(/(password|secret|api_key|token)\s*[:=]\s*["'][^"']+["']/gi, '$1="[REDACTED_SECRET]"')
      // Redact env declarations with keys
      .replace(/GEMINI_API_KEY=["'][^"']+["']/gi, 'GEMINI_API_KEY="[REDACTED_KEY]"');
  }
}
