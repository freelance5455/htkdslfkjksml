import { Haptics } from "@capacitor/haptics";

/**
 * A legitimate boost session. Android does not let third-party apps kill other
 * apps or change CPU clocks, so we only clear our own caches and guide the user.
 */
export async function runBoost(log: (line: string) => void) {
  log("Clearing Kisu cache…");
  if ("caches" in window) for (const k of await caches.keys()) await caches.delete(k);
  log("Tip: enable Do Not Disturb and close unused apps from Recents.");
  await Haptics.vibrate({ duration: 60 });
  log("Focus mode ready.");
}
