import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  addDoc,
  query,
  where,
  deleteDoc,
  orderBy
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Manhwa,
  Chapter,
  Team,
  UserProfile,
  PublicationStatus,
  SupportTicket,
  SupportMessage,
  SupportCategory,
  AuditLog
} from '../types';

export const hartPublishingService = {
  /**
   * Log an administrative or publishing action in audit_logs
   */
  async logAudit(params: {
    actor: UserProfile;
    action: string;
    targetType: 'manhwa' | 'chapter' | 'team' | 'user' | 'support';
    targetId: string;
    targetName: string;
    details?: string;
  }): Promise<void> {
    try {
      const { actor, action, targetType, targetId, targetName, details } = params;
      const logData: Omit<AuditLog, 'id'> = {
        actorId: actor.uid,
        actorName: actor.displayName || 'مستخدم',
        actorEmail: actor.email,
        action,
        targetType,
        targetId,
        targetName,
        details: details || '',
        createdAt: new Date().toISOString()
      };
      await addDoc(collection(db, 'audit_logs'), logData);
    } catch (err) {
      console.warn('Audit log write notice:', err);
    }
  },

  /**
   * Immediately publish a work to the public catalog
   */
  async publishWork(manhwaId: string, actor: UserProfile, targetTitle?: string): Promise<void> {
    try {
      const docRef = doc(db, 'manhwas', manhwaId);
      const now = new Date().toISOString();
      await updateDoc(docRef, {
        publicationStatus: 'published',
        publishedAt: now,
        isDeleted: false,
        updatedAt: now
      });

      await this.logAudit({
        actor,
        action: 'publish_work',
        targetType: 'manhwa',
        targetId: manhwaId,
        targetName: targetTitle || 'عمل',
        details: 'تم نشر العمل وجعله متاحاً للجمهور في الموقع العام وصفحة الفريق'
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `manhwas/${manhwaId}`);
    }
  },

  /**
   * Unpublish (withdraw) a work from the public catalog back to unpublished/draft
   */
  async unpublishWork(manhwaId: string, actor: UserProfile, targetTitle?: string): Promise<void> {
    try {
      const docRef = doc(db, 'manhwas', manhwaId);
      const now = new Date().toISOString();
      await updateDoc(docRef, {
        publicationStatus: 'unpublished',
        updatedAt: now
      });

      await this.logAudit({
        actor,
        action: 'unpublish_work',
        targetType: 'manhwa',
        targetId: manhwaId,
        targetName: targetTitle || 'عمل',
        details: 'تم سحب العمل وإلغاء نشره من الموقع العام'
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `manhwas/${manhwaId}`);
    }
  },

  /**
   * Submit work for review
   */
  async submitForReview(manhwaId: string, actor: UserProfile, targetTitle?: string): Promise<void> {
    try {
      const docRef = doc(db, 'manhwas', manhwaId);
      const now = new Date().toISOString();
      await updateDoc(docRef, {
        publicationStatus: 'pending_review',
        updatedAt: now
      });

      await this.logAudit({
        actor,
        action: 'submit_for_review',
        targetType: 'manhwa',
        targetId: manhwaId,
        targetName: targetTitle || 'عمل',
        details: 'تم إرسال العمل للمراجعة من قبل الإدارة'
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `manhwas/${manhwaId}`);
    }
  },

  /**
   * Super Owner reviews content: Approve & Publish, or Reject with reason
   */
  async reviewWork(params: {
    manhwaId: string;
    approve: boolean;
    reason?: string;
    actor: UserProfile;
    targetTitle?: string;
  }): Promise<void> {
    const { manhwaId, approve, reason, actor, targetTitle } = params;
    try {
      const docRef = doc(db, 'manhwas', manhwaId);
      const now = new Date().toISOString();
      if (approve) {
        await updateDoc(docRef, {
          publicationStatus: 'published',
          publishedAt: now,
          rejectionReason: '',
          updatedAt: now
        });
      } else {
        await updateDoc(docRef, {
          publicationStatus: 'rejected',
          rejectionReason: reason || 'مخالف للشروط',
          updatedAt: now
        });
      }

      await this.logAudit({
        actor,
        action: approve ? 'review_approved' : 'review_rejected',
        targetType: 'manhwa',
        targetId: manhwaId,
        targetName: targetTitle || 'عمل',
        details: approve ? 'تمت الموافقة ونشر العمل' : `تم رفض العمل بسبب: ${reason || ''}`
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `manhwas/${manhwaId}`);
    }
  },

  /**
   * Soft delete or restore a work
   */
  async toggleDeleteWork(manhwaId: string, isDeleted: boolean, actor: UserProfile, targetTitle?: string): Promise<void> {
    try {
      const docRef = doc(db, 'manhwas', manhwaId);
      const now = new Date().toISOString();
      await updateDoc(docRef, {
        isDeleted,
        deletedAt: isDeleted ? now : null,
        updatedAt: now
      });

      await this.logAudit({
        actor,
        action: isDeleted ? 'soft_delete_work' : 'restore_work',
        targetType: 'manhwa',
        targetId: manhwaId,
        targetName: targetTitle || 'عمل',
        details: isDeleted ? 'تم نقل العمل لسلة المحذوفات' : 'تمت استعادة العمل المحذوف'
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `manhwas/${manhwaId}`);
    }
  },

  /**
   * Soft delete or restore a team (Super Owner control)
   */
  async toggleDeleteTeam(teamId: string, isDeleted: boolean, actor: UserProfile, teamName?: string): Promise<void> {
    try {
      const docRef = doc(db, 'teams', teamId);
      const now = new Date().toISOString();
      await updateDoc(docRef, {
        isDeleted,
        deletedAt: isDeleted ? now : null,
        updatedAt: now
      });

      await this.logAudit({
        actor,
        action: isDeleted ? 'soft_delete_team' : 'restore_team',
        targetType: 'team',
        targetId: teamId,
        targetName: teamName || 'فريق',
        details: isDeleted ? 'تم إخفاء/حذف الفريق من قبل الإدارة' : 'تمت استعادة الفريق'
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `teams/${teamId}`);
    }
  },

  /**
   * Ban or unban a user (Super Owner only)
   */
  async toggleBanUser(params: {
    targetUid: string;
    targetEmail: string;
    targetName: string;
    isBanned: boolean;
    banReason?: string;
    actor: UserProfile;
  }): Promise<void> {
    const { targetUid, targetEmail, targetName, isBanned, banReason, actor } = params;

    // Strict protection: Owner account can NEVER be banned
    if (targetEmail?.toLowerCase() === '17noranimations17@gmail.com') {
      throw new Error('حساب المالك الأعلى محمي بنظام أمني صارم ولا يمكن حظره إطلاقاً.');
    }

    try {
      const userRef = doc(db, 'users', targetUid);
      await updateDoc(userRef, {
        isBanned,
        banReason: isBanned ? (banReason || 'مخالفة سياسات المنصة') : ''
      });

      await this.logAudit({
        actor,
        action: isBanned ? 'ban_user' : 'unban_user',
        targetType: 'user',
        targetId: targetUid,
        targetName: targetName,
        details: isBanned ? `تم حظر المستخدم للسبب: ${banReason || ''}` : 'تم رفع الحظر عن المستخدم'
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${targetUid}`);
    }
  },

  /**
   * Create a new support ticket (User or Team messaging site management)
   */
  async createSupportTicket(params: {
    user: UserProfile;
    subject: string;
    category: SupportCategory;
    initialMessage: string;
  }): Promise<string> {
    const { user, subject, category, initialMessage } = params;
    const now = new Date().toISOString();

    const firstMsg: SupportMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      senderId: user.uid,
      senderName: user.displayName,
      senderAvatar: user.photoUrl || '',
      isAdmin: false,
      content: initialMessage.trim(),
      createdAt: now
    };

    const ticketData: Omit<SupportTicket, 'id'> = {
      userId: user.uid,
      userName: user.displayName,
      userEmail: user.email,
      userUniqueId: user.uniqueId,
      userAvatar: user.photoUrl || '',
      subject: subject.trim(),
      category,
      status: 'open',
      messages: [firstMsg],
      lastMessageAt: now,
      createdAt: now,
      updatedAt: now
    };

    try {
      const docRef = await addDoc(collection(db, 'support_tickets'), ticketData);
      return docRef.id;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'support_tickets');
    }
  },

  /**
   * Add a message to an existing support ticket thread
   */
  async replySupportTicket(params: {
    ticket: SupportTicket;
    sender: UserProfile;
    isAdmin: boolean;
    content: string;
  }): Promise<void> {
    const { ticket, sender, isAdmin, content } = params;
    const now = new Date().toISOString();

    // Owner replies anonymously as "إدارة الموقع" to preserve privacy
    const displayName = isAdmin ? 'إدارة الموقع' : (sender.displayName || 'مستخدم');

    const newMsg: SupportMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      senderId: sender.uid,
      senderName: displayName,
      senderAvatar: isAdmin ? '' : (sender.photoUrl || ''),
      isAdmin,
      content: content.trim(),
      createdAt: now
    };

    const updatedMessages = [...ticket.messages, newMsg];
    const ticketRef = doc(db, 'support_tickets', ticket.id);

    try {
      await updateDoc(ticketRef, {
        messages: updatedMessages,
        status: isAdmin ? 'in_progress' : ticket.status,
        lastMessageAt: now,
        updatedAt: now
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `support_tickets/${ticket.id}`);
    }
  },

  /**
   * Update support ticket status (Open, In Progress, Resolved, Closed)
   */
  async updateTicketStatus(ticketId: string, status: 'open' | 'in_progress' | 'resolved' | 'closed'): Promise<void> {
    try {
      const ticketRef = doc(db, 'support_tickets', ticketId);
      await updateDoc(ticketRef, {
        status,
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `support_tickets/${ticketId}`);
    }
  }
};
