import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  deleteDoc,
  updateDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import {
  UserProfile,
  EventItem,
  PurchasedTicket,
  AppNotification,
  HostWithdrawal,
} from '../types';
import { MOCK_EVENTS } from '../data/mockEvents';

// Device identifier for conflict resolution and provenance tracking
export const getDeviceId = (): string => {
  let devId = localStorage.getItem('eventra_device_id');
  if (!devId) {
    devId = `dev_${Math.random().toString(36).substring(2, 10)}_${Date.now()}`;
    localStorage.setItem('eventra_device_id', devId);
  }
  return devId;
};

// Cross-tab broadcast channel for instantaneous zero-latency local tab sync
export const syncChannel = typeof window !== 'undefined' && 'BroadcastChannel' in window
  ? new BroadcastChannel('eventra_device_sync_channel')
  : null;

export const firebaseService = {
  // ==========================================
  // USER PROFILES & SETTINGS
  // ==========================================
  async saveUserProfile(profile: UserProfile): Promise<void> {
    const targetUid = profile.id || auth.currentUser?.uid;
    if (!targetUid) return;

    const payload = {
      ...profile,
      updatedAt: new Date().toISOString(),
      updatedAtMs: Date.now(),
      lastDeviceId: getDeviceId(),
    };

    try {
      await setDoc(doc(db, 'users', targetUid), payload, { merge: true });
      syncChannel?.postMessage({ type: 'USER_PROFILE_UPDATED', payload });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${targetUid}`);
    }
  },

  async getUserProfile(uid: string): Promise<UserProfile | null> {
    try {
      const snap = await getDoc(doc(db, 'users', uid));
      if (snap.exists()) {
        return snap.data() as UserProfile;
      }
      return null;
    } catch (err: any) {
      handleFirestoreError(err, OperationType.GET, `users/${uid}`);
      // Fallback to local storage cached user profile if operating offline
      const cached = localStorage.getItem('aura_auth_user');
      if (cached) {
        try {
          const parsed = JSON.parse(cached);
          if (parsed && (parsed.id === uid || parsed.email === auth.currentUser?.email)) {
            return parsed as UserProfile;
          }
        } catch {}
      }
      return null;
    }
  },

  async terminateAccountWorldwide(uid: string): Promise<void> {
    try {
      await setDoc(
        doc(db, 'users', uid),
        {
          isDeleted: true,
          sessionTerminatedAt: Date.now(),
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
      syncChannel?.postMessage({ type: 'ACCOUNT_DELETED', userId: uid });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
    }
  },

  listenToUserProfile(uid: string, callback: (profile: UserProfile | null) => void) {
    return onSnapshot(
      doc(db, 'users', uid),
      (snap) => {
        if (snap.exists()) {
          const data = snap.data() as UserProfile;
          callback(data);
        } else {
          callback(null);
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, `users/${uid}`);
      }
    );
  },

  // ==========================================
  // GLOBAL EVENTS CATALOG (CROSS-ACCOUNT SYNC)
  // ==========================================
  async saveEvent(event: EventItem): Promise<void> {
    const payload = {
      ...event,
      updatedAt: new Date().toISOString(),
      updatedAtMs: Date.now(),
      lastDeviceId: getDeviceId(),
    };

    try {
      await setDoc(doc(db, 'events', event.id), payload, { merge: true });
      syncChannel?.postMessage({ type: 'EVENT_SAVED', payload });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `events/${event.id}`);
    }
  },

  async updateEvent(eventId: string, updates: Partial<EventItem>): Promise<boolean> {
    const payload = {
      ...updates,
      updatedAt: new Date().toISOString(),
      updatedAtMs: Date.now(),
      lastDeviceId: getDeviceId(),
    };
    try {
      await updateDoc(doc(db, 'events', eventId), payload);
      syncChannel?.postMessage({ type: 'EVENT_UPDATED', eventId, payload });
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `events/${eventId}`);
      return false;
    }
  },

  async deleteEvent(eventId: string): Promise<boolean> {
    try {
      await deleteDoc(doc(db, 'events', eventId));
      syncChannel?.postMessage({ type: 'EVENT_DELETED', eventId });
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `events/${eventId}`);
      return false;
    }
  },

  // Automated transactional workflow: Event cancellation + instant full buyer refunds
  async cancelEventWithAutomatedRefunds(
    eventId: string,
    eventTitle: string,
    hostName: string
  ): Promise<{ refundedTicketsCount: number; totalRefundedAmount: number; refundedTickets: PurchasedTicket[] }> {
    try {
      // 1. Query all tickets associated with this event
      const q = query(collection(db, 'tickets'), where('eventId', '==', eventId));
      const snap = await getDocs(q);

      let totalRefundedAmount = 0;
      let refundedTicketsCount = 0;
      const refundedTickets: PurchasedTicket[] = [];

      for (const ticketDoc of snap.docs) {
        const ticket = ticketDoc.data() as PurchasedTicket;
        if (ticket.status !== 'refunded') {
          const refundAmount = ticket.totalPaid;
          const refundRef = `RFD-${Math.floor(100000 + Math.random() * 900000)}-${(ticket.paymentMethod || 'mpesa').toUpperCase()}`;
          const refundedAt = new Date().toISOString();

          totalRefundedAmount += refundAmount;
          refundedTicketsCount++;

          const updatedTicket: PurchasedTicket = {
            ...ticket,
            status: 'refunded',
            refundAmount,
            refundRef,
            refundedAt,
            updatedAt: refundedAt,
            updatedAtMs: Date.now(),
          };
          refundedTickets.push(updatedTicket);

          // 2. Mark ticket as refunded in Firestore
          await updateDoc(ticketDoc.ref, {
            status: 'refunded',
            refundAmount,
            refundRef,
            refundedAt,
            updatedAt: refundedAt,
            updatedAtMs: Date.now(),
          });

          // 3. Dispatch automated notification to the buyer's account
          const targetUserId = ticket.userId || auth.currentUser?.uid;
          if (targetUserId) {
            const notif: AppNotification = {
              id: `notif_rfd_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
              userId: targetUserId,
              ticketId: ticket.ticketId,
              eventId,
              title: `Event Canceled · Full Refund of KSh ${refundAmount.toLocaleString()}`,
              message: `The host canceled "${eventTitle}". A full refund of KSh ${refundAmount.toLocaleString()} has been processed back to your ${(ticket.paymentMethod || 'M-Pesa').toUpperCase()} account (Ref: ${refundRef}).`,
              date: new Date().toLocaleDateString(),
              isRead: false,
              timestamp: 'Just now',
              createdAt: refundedAt,
              type: 'refund',
              refundAmount,
            };
            await this.saveNotification(notif, targetUserId);
          }
        }
      }

      // 4. Remove event from Cloud Firestore
      await deleteDoc(doc(db, 'events', eventId));
      syncChannel?.postMessage({
        type: 'EVENT_CANCELED_REFUNDED',
        eventId,
        refundedTicketsCount,
        totalRefundedAmount,
      });

      return { refundedTicketsCount, totalRefundedAmount, refundedTickets };
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `events/${eventId}`);
      return { refundedTicketsCount: 0, totalRefundedAmount: 0, refundedTickets: [] };
    }
  },

  listenToEvents(callback: (events: EventItem[]) => void) {
    // Events is publicly readable worldwide
    return onSnapshot(
      collection(db, 'events'),
      async (snap) => {
        if (snap.empty) {
          // Database is fresh — seed initial curated live events into Firestore once
          callback(MOCK_EVENTS);
          try {
            for (const mockEvent of MOCK_EVENTS) {
              await setDoc(doc(db, 'events', mockEvent.id), {
                ...mockEvent,
                updatedAt: new Date().toISOString(),
                updatedAtMs: Date.now(),
                isCuratedDefault: true,
              });
            }
          } catch (e) {
            // Seed error can be ignored if permissions restrict or already exists
          }
          return;
        }

        const list: EventItem[] = [];
        snap.forEach((d) => list.push(d.data() as EventItem));
        // Sort events chronologically or by updated timestamp
        list.sort((a, b) => (b.updatedAtMs || 0) - (a.updatedAtMs || 0));
        callback(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'events');
      }
    );
  },

  // ==========================================
  // TICKETS & DIGITAL PASSES (MANUAL VERIFICATION)
  // ==========================================
  async saveTicket(ticket: PurchasedTicket): Promise<void> {
    const payload = {
      ...ticket,
      updatedAt: new Date().toISOString(),
      updatedAtMs: Date.now(),
      lastDeviceId: getDeviceId(),
    };

    try {
      await setDoc(doc(db, 'tickets', ticket.ticketId), payload, { merge: true });
      syncChannel?.postMessage({ type: 'TICKET_SAVED', payload });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `tickets/${ticket.ticketId}`);
    }
  },

  async deleteTicket(ticketId: string): Promise<boolean> {
    try {
      await deleteDoc(doc(db, 'tickets', ticketId));
      syncChannel?.postMessage({ type: 'TICKET_DELETED', ticketId });
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `tickets/${ticketId}`);
      return false;
    }
  },

  async checkInTicket(ticketId: string, stewardName: string): Promise<boolean> {
    const now = new Date();
    const timeFormatted = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    try {
      await updateDoc(doc(db, 'tickets', ticketId), {
        status: 'used',
        checkedInAt: timeFormatted,
        admittedBy: stewardName,
        updatedAt: now.toISOString(),
        updatedAtMs: Date.now(),
        lastDeviceId: getDeviceId(),
      });
      syncChannel?.postMessage({
        type: 'TICKET_CHECKED_IN',
        ticketId,
        stewardName,
        checkedInAt: timeFormatted,
      });
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `tickets/${ticketId}`);
      return false;
    }
  },

  async getTicket(ticketId: string): Promise<PurchasedTicket | null> {
    try {
      const snap = await getDoc(doc(db, 'tickets', ticketId));
      if (snap.exists()) {
        return snap.data() as PurchasedTicket;
      }
      return null;
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `tickets/${ticketId}`);
      return null;
    }
  },

  // Manual code or order reference lookup worldwide
  async findTicketByCodeOrRef(code: string, eventId?: string): Promise<PurchasedTicket | null> {
    const normalized = code.trim().toUpperCase();
    try {
      // 1. Direct match on ticketId
      const directSnap = await getDoc(doc(db, 'tickets', code.trim()));
      if (directSnap.exists()) {
        const t = directSnap.data() as PurchasedTicket;
        if (!eventId || t.eventId === eventId) return t;
      }

      // 2. Query by distinct ticketCode (case-insensitive query)
      const qCode = query(collection(db, 'tickets'), where('ticketCode', '==', normalized));
      const snapCode = await getDocs(qCode);
      if (!snapCode.empty) {
        for (const docSnap of snapCode.docs) {
          const t = docSnap.data() as PurchasedTicket;
          if (!eventId || t.eventId === eventId) return t;
        }
      }

      // 3. Query by orderNumber
      const qOrder = query(collection(db, 'tickets'), where('orderNumber', '==', normalized));
      const snapOrder = await getDocs(qOrder);
      if (!snapOrder.empty) {
        for (const docSnap of snapOrder.docs) {
          const t = docSnap.data() as PurchasedTicket;
          if (!eventId || t.eventId === eventId) return t;
        }
      }

      // 4. Query by transactionRef
      const qRef = query(collection(db, 'tickets'), where('transactionRef', '==', normalized));
      const snapRef = await getDocs(qRef);
      if (!snapRef.empty) {
        for (const docSnap of snapRef.docs) {
          const t = docSnap.data() as PurchasedTicket;
          if (!eventId || t.eventId === eventId) return t;
        }
      }

      return null;
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'tickets');
      return null;
    }
  },

  listenToUserTickets(userId: string, callback: (tickets: PurchasedTicket[]) => void) {
    const q = query(collection(db, 'tickets'), where('userId', '==', userId));
    return onSnapshot(
      q,
      (snap) => {
        const list: PurchasedTicket[] = [];
        snap.forEach((d) => list.push(d.data() as PurchasedTicket));
        list.sort((a, b) => (b.updatedAtMs || 0) - (a.updatedAtMs || 0));
        callback(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'tickets');
      }
    );
  },

  listenToEventTickets(eventId: string, callback: (tickets: PurchasedTicket[]) => void) {
    const q = query(collection(db, 'tickets'), where('eventId', '==', eventId));
    return onSnapshot(
      q,
      (snap) => {
        const list: PurchasedTicket[] = [];
        snap.forEach((d) => list.push(d.data() as PurchasedTicket));
        callback(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'tickets');
      }
    );
  },

  listenToAllTickets(callback: (tickets: PurchasedTicket[]) => void) {
    return onSnapshot(
      collection(db, 'tickets'),
      (snap) => {
        const list: PurchasedTicket[] = [];
        snap.forEach((d) => list.push(d.data() as PurchasedTicket));
        list.sort((a, b) => {
          const timeA = b.updatedAtMs || (b.purchasedAt ? new Date(b.purchasedAt).getTime() : 0);
          const timeB = a.updatedAtMs || (a.purchasedAt ? new Date(a.purchasedAt).getTime() : 0);
          return timeA - timeB;
        });
        callback(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'tickets');
      }
    );
  },

  // ==========================================
  // NOTIFICATIONS (REAL-TIME BIDIRECTIONAL SYNC)
  // ==========================================
  async saveNotification(notif: AppNotification, userId: string): Promise<void> {
    const payload = {
      ...notif,
      userId,
      createdAt: notif.createdAt || new Date().toISOString(),
      updatedAtMs: Date.now(),
      lastDeviceId: getDeviceId(),
    };

    try {
      await setDoc(doc(db, 'notifications', notif.id), payload, { merge: true });
      syncChannel?.postMessage({ type: 'NOTIFICATION_SAVED', payload });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `notifications/${notif.id}`);
    }
  },

  async markNotificationRead(id: string): Promise<void> {
    try {
      await updateDoc(doc(db, 'notifications', id), {
        isRead: true,
        updatedAtMs: Date.now(),
      });
      syncChannel?.postMessage({ type: 'NOTIFICATION_READ', id });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `notifications/${id}`);
    }
  },

  async markAllNotificationsRead(userId: string): Promise<void> {
    try {
      const q = query(collection(db, 'notifications'), where('userId', '==', userId));
      const snap = await getDocs(q);
      const updates = snap.docs.map((d) =>
        updateDoc(d.ref, { isRead: true, updatedAtMs: Date.now() })
      );
      await Promise.all(updates);
      syncChannel?.postMessage({ type: 'NOTIFICATIONS_ALL_READ', userId });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'notifications');
    }
  },

  async deleteNotification(id: string): Promise<void> {
    try {
      await deleteDoc(doc(db, 'notifications', id));
      syncChannel?.postMessage({ type: 'NOTIFICATION_DELETED', id });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `notifications/${id}`);
    }
  },

  async clearAllUserNotifications(userId: string): Promise<void> {
    try {
      const q = query(collection(db, 'notifications'), where('userId', '==', userId));
      const snap = await getDocs(q);
      const deletions = snap.docs.map((d) => deleteDoc(d.ref));
      await Promise.all(deletions);
      syncChannel?.postMessage({ type: 'NOTIFICATIONS_CLEARED', userId });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'notifications');
    }
  },

  listenToNotifications(userId: string, callback: (notifs: AppNotification[]) => void) {
    const q = query(collection(db, 'notifications'), where('userId', '==', userId));
    return onSnapshot(
      q,
      (snap) => {
        const list: AppNotification[] = [];
        snap.forEach((d) => {
          list.push(d.data() as AppNotification);
        });
        // Sort newest first
        list.sort((a, b) => (b.updatedAtMs || 0) - (a.updatedAtMs || 0));
        callback(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'notifications');
      }
    );
  },

  // ==========================================
  // HOST WITHDRAWALS
  // ==========================================
  async saveWithdrawal(w: HostWithdrawal, userId: string): Promise<void> {
    const payload = {
      ...w,
      userId,
      createdAt: new Date().toISOString(),
      updatedAtMs: Date.now(),
      lastDeviceId: getDeviceId(),
    };

    try {
      await setDoc(doc(db, 'withdrawals', w.id), payload);
      syncChannel?.postMessage({ type: 'WITHDRAWAL_SAVED', payload });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `withdrawals/${w.id}`);
    }
  },

  listenToWithdrawals(userId: string, callback: (withdrawals: HostWithdrawal[]) => void) {
    const q = query(collection(db, 'withdrawals'), where('userId', '==', userId));
    return onSnapshot(
      q,
      (snap) => {
        const list: HostWithdrawal[] = [];
        snap.forEach((d) => {
          list.push(d.data() as HostWithdrawal);
        });
        list.sort((a, b) => (b.updatedAtMs || 0) - (a.updatedAtMs || 0));
        callback(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'withdrawals');
      }
    );
  },
};
