import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  getDocs, 
  getDoc,
  onSnapshot, 
  Firestore,
  writeBatch,
  Unsubscribe
} from 'firebase/firestore';
import { Product, SaleInvoice, Expense, PurchaseRecord, StoreProfile } from '../types';

export const USER_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBINvmGL4rSOaujmjeU6ieU3GTso5D7-Nw",
  authDomain: "unifour1211.firebaseapp.com",
  projectId: "unifour1211",
  storageBucket: "unifour1211.firebasestorage.app",
  messagingSenderId: "803174150903",
  appId: "1:803174150903:web:a5aa745dd12c3835f819f2",
  measurementId: "G-XVN4YS5YBZ"
};

let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let isInitialized = false;

export function initFirebase(customConfig = USER_FIREBASE_CONFIG): { success: boolean; error?: string } {
  try {
    if (!customConfig.apiKey || !customConfig.projectId) {
      return { success: false, error: 'Firebase Project ID বা API Key পাওয়া যায়নি' };
    }

    if (getApps().length === 0) {
      app = initializeApp(customConfig);
    } else {
      app = getApp();
    }
    db = getFirestore(app);
    isInitialized = true;
    return { success: true };
  } catch (err: any) {
    console.warn('Firebase initialization notice:', err);
    return { success: false, error: err?.message || 'Firebase চালু হতে পারেনি' };
  }
}

// Auto-initialize with user's provided credentials
initFirebase();

export const firebaseService = {
  isReady(): boolean {
    return isInitialized && db !== null;
  },

  getDb(): Firestore | null {
    if (!db) initFirebase();
    return db;
  },

  // Real-time synchronization listeners for Multi-User live updates
  subscribeToProducts(onData: (products: Product[]) => void): Unsubscribe | null {
    const firestore = this.getDb();
    if (!firestore) return null;
    try {
      const colRef = collection(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'products');
      return onSnapshot(colRef, (snapshot) => {
        if (!snapshot.empty) {
          const prods: Product[] = [];
          snapshot.forEach((d) => prods.push(d.data() as Product));
          onData(prods);
        }
      }, (err) => {
        console.warn('Firestore Products sync listener notice:', err.message);
      });
    } catch (e) {
      console.warn('Failed to subscribe to products:', e);
      return null;
    }
  },

  subscribeToInvoices(onData: (invoices: SaleInvoice[]) => void): Unsubscribe | null {
    const firestore = this.getDb();
    if (!firestore) return null;
    try {
      const colRef = collection(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'invoices');
      return onSnapshot(colRef, (snapshot) => {
        if (!snapshot.empty) {
          const invs: SaleInvoice[] = [];
          snapshot.forEach((d) => invs.push(d.data() as SaleInvoice));
          // Sort by creation date descending
          invs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          onData(invs);
        }
      }, (err) => {
        console.warn('Firestore Invoices sync listener notice:', err.message);
      });
    } catch (e) {
      console.warn('Failed to subscribe to invoices:', e);
      return null;
    }
  },

  // Real-time synchronization listener for Store Profile (দোকানের পরিচিতি)
  subscribeToProfile(onData: (profile: StoreProfile) => void): Unsubscribe | null {
    const firestore = this.getDb();
    if (!firestore) return null;
    try {
      const docRef = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'profile', 'main');
      return onSnapshot(docRef, (snapshot) => {
        if (snapshot.exists()) {
          const profileData = snapshot.data() as StoreProfile;
          if (profileData && profileData.name) {
            onData(profileData);
          }
        }
      }, (err) => {
        console.warn('Firestore Profile sync listener notice:', err.message);
      });
    } catch (e) {
      console.warn('Failed to subscribe to profile:', e);
      return null;
    }
  },

  // Save / Update a single product in Firebase Cloud
  async syncProduct(product: Product): Promise<boolean> {
    const firestore = this.getDb();
    if (!firestore) return false;
    try {
      const ref = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'products', product.id);
      await setDoc(ref, product, { merge: true });
      return true;
    } catch (e) {
      console.warn('Could not sync product to Firebase:', e);
      return false;
    }
  },

  // Delete a product in Firebase Cloud
  async deleteProduct(productId: string): Promise<boolean> {
    const firestore = this.getDb();
    if (!firestore) return false;
    try {
      const ref = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'products', productId);
      await deleteDoc(ref);
      return true;
    } catch (e) {
      console.warn('Could not delete product from Firebase:', e);
      return false;
    }
  },

  // Save a new sales invoice in Firebase Cloud
  async syncInvoice(invoice: SaleInvoice): Promise<boolean> {
    const firestore = this.getDb();
    if (!firestore) return false;
    try {
      const ref = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'invoices', invoice.id);
      await setDoc(ref, invoice, { merge: true });
      return true;
    } catch (e) {
      console.warn('Could not sync invoice to Firebase:', e);
      return false;
    }
  },

  // Save an expense in Firebase Cloud
  async syncExpense(expense: Expense): Promise<boolean> {
    const firestore = this.getDb();
    if (!firestore) return false;
    try {
      const ref = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'expenses', expense.id);
      await setDoc(ref, expense, { merge: true });
      return true;
    } catch (e) {
      console.warn('Could not sync expense to Firebase:', e);
      return false;
    }
  },

  // Save purchase record in Firebase Cloud
  async syncPurchase(purchase: PurchaseRecord): Promise<boolean> {
    const firestore = this.getDb();
    if (!firestore) return false;
    try {
      const ref = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'purchases', purchase.id);
      await setDoc(ref, purchase, { merge: true });
      return true;
    } catch (e) {
      console.warn('Could not sync purchase to Firebase:', e);
      return false;
    }
  },

  // Save store profile in Firebase Cloud
  async syncProfile(profile: StoreProfile): Promise<boolean> {
    const firestore = this.getDb();
    if (!firestore) return false;
    try {
      const ref = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'profile', 'main');
      await setDoc(ref, profile, { merge: true });
      return true;
    } catch (e) {
      console.warn('Could not sync profile to Firebase:', e);
      return false;
    }
  },

  // Full manual cloud backup upload
  async uploadAllToCloud(data: {
    products: Product[];
    invoices: SaleInvoice[];
    expenses: Expense[];
    purchases: PurchaseRecord[];
    storeProfile: StoreProfile;
  }): Promise<{ success: boolean; message: string }> {
    const firestore = this.getDb();
    if (!firestore) {
      return { success: false, message: 'Firebase সংযোগ প্রস্তুত নয়' };
    }

    try {
      const batch = writeBatch(firestore);

      // Profile
      const profRef = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'profile', 'main');
      batch.set(profRef, data.storeProfile);

      // Products (limit to 500 max batch size)
      for (const prod of data.products.slice(0, 200)) {
        const pRef = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'products', prod.id);
        batch.set(pRef, prod);
      }

      // Invoices
      for (const inv of data.invoices.slice(0, 200)) {
        const iRef = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'invoices', inv.id);
        batch.set(iRef, inv);
      }

      await batch.commit();
      return { 
        success: true, 
        message: 'সকল পণ্য, বিক্রয় মেমো ও প্রোফাইল সফলভাবে Firebase Cloud-এ আপলোড ও ব্যাকআপ হয়েছে!' 
      };
    } catch (err: any) {
      console.error('Firebase Batch Upload Error:', err);
      return { 
        success: false, 
        message: err?.message?.includes('permission-denied') 
          ? 'Firebase Permission Denied! দয়া করে Firebase Console-এ গিয়ে Firestore Rules-এ লিখুন: allow read, write: if true;' 
          : (err?.message || 'Firebase ক্লাউডে আপলোড করতে সমস্যা হয়েছে')
      };
    }
  },

  // Pull all data from Firebase Cloud
  async downloadAllFromCloud(): Promise<{
    success: boolean;
    data?: {
      products?: Product[];
      invoices?: SaleInvoice[];
      profile?: StoreProfile;
    };
    message: string;
  }> {
    const firestore = this.getDb();
    if (!firestore) {
      return { success: false, message: 'Firebase সংযোগ প্রস্তুত নয়' };
    }

    try {
      const prodsRef = collection(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'products');
      const invsRef = collection(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'invoices');
      const profRef = doc(firestore, 'stores', USER_FIREBASE_CONFIG.projectId, 'profile', 'main');

      const [prodsSnap, invsSnap, profSnap] = await Promise.all([
        getDocs(prodsRef),
        getDocs(invsRef),
        getDoc(profRef)
      ]);

      const products: Product[] = [];
      prodsSnap.forEach(d => products.push(d.data() as Product));

      const invoices: SaleInvoice[] = [];
      invsSnap.forEach(d => invoices.push(d.data() as SaleInvoice));

      let profile: StoreProfile | undefined;
      if (profSnap.exists()) {
        profile = profSnap.data() as StoreProfile;
      }

      return {
        success: true,
        data: { products, invoices, profile },
        message: `Firebase থেকে ${products.length} টি পণ্য, ${invoices.length} টি মেমো এবং দোকানের পরিচিতি সফলভাবে ডাউনলোড হয়েছে!`
      };
    } catch (err: any) {
      console.error('Firebase Download Error:', err);
      return { 
        success: false, 
        message: err?.message?.includes('permission-denied') 
          ? 'Firebase Permission Denied! Firestore Rules-এ রিড পারমিশন চালু করুন।' 
          : (err?.message || 'Firebase থেকে ডাটা আনতে সমস্যা হয়েছে')
      };
    }
  }
};
