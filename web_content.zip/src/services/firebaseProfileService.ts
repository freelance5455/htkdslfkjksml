import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  onSnapshot,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile, WatchProgress } from '../types/video';

const DEFAULT_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80', // Salman / Classic
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80', // Family / Modern
  'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=200&auto=format&fit=crop&q=80', // Kids / Friendly
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80', // Sci-Fi / Tech
  'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80', // Gamer / Cinema
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80', // Pop / Neon
];

export const AVATAR_PRESETS = DEFAULT_AVATARS;

export const INITIAL_PROFILES: UserProfile[] = [
  {
    id: 'profile-salman',
    name: 'Salman',
    avatar: DEFAULT_AVATARS[0],
    isKids: false,
  },
  {
    id: 'profile-family',
    name: 'Family',
    avatar: DEFAULT_AVATARS[1],
    isKids: false,
  },
  {
    id: 'profile-kids',
    name: 'Kids',
    avatar: DEFAULT_AVATARS[2],
    isKids: true,
  },
];

// Fetch all profiles from Firestore; seeds default profiles if empty
export async function getProfilesFromDb(): Promise<UserProfile[]> {
  const profilesCol = 'profiles';
  try {
    const snap = await getDocs(collection(db, profilesCol));
    if (snap.empty) {
      // Seed initial profiles into Firestore
      for (const p of INITIAL_PROFILES) {
        await setDoc(doc(db, profilesCol, p.id), {
          ...p,
          createdAt: new Date().toISOString(),
        });
      }
      return INITIAL_PROFILES;
    }
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        id: d.id,
        name: data.name,
        avatar: data.avatar,
        isKids: Boolean(data.isKids),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, profilesCol);
  }
}

// Add or update profile in Firestore
export async function saveProfileToDb(profile: UserProfile): Promise<void> {
  const path = `profiles/${profile.id}`;
  try {
    await setDoc(
      doc(db, 'profiles', profile.id),
      {
        id: profile.id,
        name: profile.name,
        avatar: profile.avatar,
        isKids: profile.isKids,
        createdAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Delete profile and its subcollection items
export async function deleteProfileFromDb(profileId: string): Promise<void> {
  const path = `profiles/${profileId}`;
  try {
    await deleteDoc(doc(db, 'profiles', profileId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Subscribe to real-time My List for a specific profile
export function subscribeToProfileWatchlist(
  profileId: string,
  onUpdate: (videoIds: string[]) => void
): () => void {
  const path = `profiles/${profileId}/watchlist`;
  return onSnapshot(
    collection(db, 'profiles', profileId, 'watchlist'),
    (snap) => {
      const ids = snap.docs.map((d) => d.id);
      onUpdate(ids);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
}

// Toggle a video in profile's My List
export async function toggleProfileWatchlistInDb(
  profileId: string,
  videoId: string
): Promise<boolean> {
  const path = `profiles/${profileId}/watchlist/${videoId}`;
  try {
    const ref = doc(db, 'profiles', profileId, 'watchlist', videoId);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      await deleteDoc(ref);
      return false; // Removed
    } else {
      await setDoc(ref, {
        videoId,
        addedAt: new Date().toISOString(),
      });
      return true; // Added
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Subscribe to real-time Watch History for a specific profile
export function subscribeToProfileWatchHistory(
  profileId: string,
  onUpdate: (history: WatchProgress[]) => void
): () => void {
  const path = `profiles/${profileId}/watchHistory`;
  return onSnapshot(
    collection(db, 'profiles', profileId, 'watchHistory'),
    (snap) => {
      const historyList: WatchProgress[] = snap.docs.map((d) => {
        const data = d.data();
        return {
          videoId: data.videoId || d.id,
          currentTime: Number(data.currentTime || 0),
          duration: Number(data.duration || 0),
          updatedAt: data.updatedAt || new Date().toISOString(),
        };
      });
      // Sort newest updated first
      historyList.sort(
        (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      );
      onUpdate(historyList);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
}

// Save watch progress for a specific profile
export async function saveProfileWatchProgressToDb(
  profileId: string,
  videoId: string,
  currentTime: number,
  duration: number
): Promise<void> {
  const path = `profiles/${profileId}/watchHistory/${videoId}`;
  try {
    const ref = doc(db, 'profiles', profileId, 'watchHistory', videoId);
    await setDoc(ref, {
      videoId,
      currentTime: Math.floor(currentTime),
      duration: Math.floor(duration),
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}
