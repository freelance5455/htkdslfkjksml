/**
 * Local storage database service for "دفتر الجرد والأرباح"
 * Local-only, secure, offline-first with sample data generator and JSON backup/restore.
 */

import type { AppDatabase, MedicineItem, PurchaseItem, SaleItem, ExpenseItem, DebtPayment } from '../types/pharmacy.ts';

const DB_KEY = 'daftari_pharmacy_db_v1';
const DB_VERSION = 1;

/**
 * Generate rich, realistic initial sample data for an Iraqi pharmacy wholesaler
 */
export function getInitialSampleData(): AppDatabase {
  // Use dates relative to now so alerts work dynamically
  const today = new Date();
  const formatDate = (offsetDays: number) => {
    const d = new Date(today);
    d.setDate(d.getDate() + offsetDays);
    return d.toISOString().split('T')[0];
  };

  const medicines: MedicineItem[] = [
    {
      id: 'm1',
      barcode: '6291100123456',
      name: 'Panadol Extra 500mg (24 Tab)',
      scientificName: 'Paracetamol + Caffeine',
      unit: 'باكيت',
      minStockAlert: 20,
    },
    {
      id: 'm2',
      barcode: '5000158068942',
      name: 'Augmentin 1g (14 Tab)',
      scientificName: 'Amoxicillin + Clavulanic Acid',
      unit: 'باكيت',
      minStockAlert: 15,
    },
    {
      id: 'm3',
      barcode: '6214000100124',
      name: 'Profen 400mg (30 Tab) سامراء',
      scientificName: 'Ibuprofen',
      unit: 'باكيت',
      minStockAlert: 25,
    },
    {
      id: 'm4',
      barcode: '6251001928374',
      name: 'Amoxicillin 500mg (20 Cap) حكمة',
      scientificName: 'Amoxicillin Trihydrate',
      unit: 'باكيت',
      minStockAlert: 15,
    },
    {
      id: 'm5',
      barcode: '6291011029384',
      name: 'Omeprazole 20mg (28 Cap) جلفار',
      scientificName: 'Omeprazole',
      unit: 'باكيت',
      minStockAlert: 10,
    },
    {
      id: 'm6',
      barcode: '4022536001283',
      name: 'Concor 5mg (30 Tab) ميرك',
      scientificName: 'Bisoprolol Fumarate',
      unit: 'باكيت',
      minStockAlert: 10,
    },
    {
      id: 'm7',
      barcode: '3582910023412',
      name: 'Flagyl 500mg (20 Tab) سانوفي',
      scientificName: 'Metronidazole',
      unit: 'باكيت',
      minStockAlert: 12,
    },
    {
      id: 'm8',
      barcode: '7611002938120',
      name: 'Voltaren 50mg (20 Tab) نوفارتس',
      scientificName: 'Diclofenac Sodium',
      unit: 'باكيت',
      minStockAlert: 15,
    },
  ];

  const purchases: PurchaseItem[] = [
    {
      id: 'p-1',
      date: formatDate(-35),
      supplier: 'مذخر الرشيد للأدوية - السعدون',
      barcode: '6291100123456',
      medicineName: 'Panadol Extra 500mg (24 Tab)',
      qty: 150,
      unitPrice: 2250,
      totalAmount: 337500,
      expiryDate: formatDate(45), // Near expiry alert! (within 45 days)
      amountPaid: 300000,
      remainingUnpaid: 37500,
      notes: 'وجبة سريعة التوزيع',
      createdAt: Date.now() - 35 * 86400000,
    },
    {
      id: 'p-2',
      date: formatDate(-18),
      supplier: 'مذخر الرشيد للأدوية - السعدون',
      barcode: '6291100123456',
      medicineName: 'Panadol Extra 500mg (24 Tab)',
      qty: 100,
      unitPrice: 2300,
      totalAmount: 230000,
      expiryDate: formatDate(360),
      amountPaid: 230000,
      remainingUnpaid: 0,
      notes: 'وجبة جديدة تاريخ حديث',
      createdAt: Date.now() - 18 * 86400000,
    },
    {
      id: 'p-3',
      date: formatDate(-25),
      supplier: 'مذخر باب المعظم المركزي',
      barcode: '5000158068942',
      medicineName: 'Augmentin 1g (14 Tab)',
      qty: 80,
      unitPrice: 8500,
      totalAmount: 680000,
      expiryDate: formatDate(280),
      amountPaid: 500000,
      remainingUnpaid: 180000,
      notes: 'واصل مع شهادة الفحص والمنشأ',
      createdAt: Date.now() - 25 * 86400000,
    },
    {
      id: 'p-4',
      date: formatDate(-20),
      supplier: 'مذخر المنصور الحديث',
      barcode: '6214000100124',
      medicineName: 'Profen 400mg (30 Tab) سامراء',
      qty: 200,
      unitPrice: 1350,
      totalAmount: 270000,
      expiryDate: formatDate(70), // Near expiry (within 70 days)
      amountPaid: 270000,
      remainingUnpaid: 0,
      notes: 'إنتاج سامراء الوطني',
      createdAt: Date.now() - 20 * 86400000,
    },
    {
      id: 'p-5',
      date: formatDate(-14),
      supplier: 'مذخر الحارثية التخصصي',
      barcode: '6291011029384',
      medicineName: 'Omeprazole 20mg (28 Cap) جلفار',
      qty: 60,
      unitPrice: 4200,
      totalAmount: 252000,
      expiryDate: formatDate(400),
      amountPaid: 200000,
      remainingUnpaid: 52000,
      notes: '',
      createdAt: Date.now() - 14 * 86400000,
    },
    {
      id: 'p-6',
      date: formatDate(-10),
      supplier: 'مذخر باب المعظم المركزي',
      barcode: '4022536001283',
      medicineName: 'Concor 5mg (30 Tab) ميرك',
      qty: 40,
      unitPrice: 6200,
      totalAmount: 248000,
      expiryDate: formatDate(500),
      amountPaid: 248000,
      remainingUnpaid: 0,
      notes: '',
      createdAt: Date.now() - 10 * 86400000,
    },
    {
      id: 'p-7',
      date: formatDate(-8),
      supplier: 'مذخر الرشيد للأدوية - السعدون',
      barcode: '3582910023412',
      medicineName: 'Flagyl 500mg (20 Tab) سانوفي',
      qty: 50,
      unitPrice: 2100,
      totalAmount: 105000,
      expiryDate: formatDate(250),
      amountPaid: 105000,
      remainingUnpaid: 0,
      notes: '',
      createdAt: Date.now() - 8 * 86400000,
    },
    {
      id: 'p-8',
      date: formatDate(-5),
      supplier: 'مذخر الحارثية التخصصي',
      barcode: '7611002938120',
      medicineName: 'Voltaren 50mg (20 Tab) نوفارتس',
      qty: 70,
      unitPrice: 4800,
      totalAmount: 336000,
      expiryDate: formatDate(420),
      amountPaid: 250000,
      remainingUnpaid: 86000,
      notes: '',
      createdAt: Date.now() - 5 * 86400000,
    },
    {
      id: 'p-9',
      date: formatDate(-3),
      supplier: 'مذخر المنصور الحديث',
      barcode: '6251001928374',
      medicineName: 'Amoxicillin 500mg (20 Cap) حكمة',
      qty: 25, // Low stock quantity!
      unitPrice: 2800,
      totalAmount: 70000,
      expiryDate: formatDate(300),
      amountPaid: 70000,
      remainingUnpaid: 0,
      notes: 'كمية محدودة متوفرة بالمذخر',
      createdAt: Date.now() - 3 * 86400000,
    },
  ];

  const sales: SaleItem[] = [
    {
      id: 's-1',
      date: formatDate(-15),
      buyer: 'صيدلية الشفاء - الكرادة',
      barcode: '6291100123456',
      medicineName: 'Panadol Extra 500mg (24 Tab)',
      qty: 60,
      unitPrice: 3250,
      totalAmount: 195000,
      avgCostAtSale: 2270,
      amountPaid: 150000,
      remainingUnpaid: 45000, // Debt on customer
      nearestExpiryBatch: formatDate(45),
      notes: 'فاتورة جملة رقم 101',
      createdAt: Date.now() - 15 * 86400000,
    },
    {
      id: 's-2',
      date: formatDate(-12),
      buyer: 'صيدلية النور والرحمة - الأعظمية',
      barcode: '5000158068942',
      medicineName: 'Augmentin 1g (14 Tab)',
      qty: 35,
      unitPrice: 11500,
      totalAmount: 402500,
      avgCostAtSale: 8500,
      amountPaid: 300000,
      remainingUnpaid: 102500,
      nearestExpiryBatch: formatDate(280),
      notes: 'دفعة صك والباقي كاش',
      createdAt: Date.now() - 12 * 86400000,
    },
    {
      id: 's-3',
      date: formatDate(-9),
      buyer: 'صيدلية الأمل المركزية - اليرموك',
      barcode: '6214000100124',
      medicineName: 'Profen 400mg (30 Tab) سامراء',
      qty: 120,
      unitPrice: 2200,
      totalAmount: 264000,
      avgCostAtSale: 1350,
      amountPaid: 264000,
      remainingUnpaid: 0,
      nearestExpiryBatch: formatDate(70),
      notes: 'تسديد فوري كاش',
      createdAt: Date.now() - 9 * 86400000,
    },
    {
      id: 's-4',
      date: formatDate(-6),
      buyer: 'صيدلية دجلة الخير - المنصور',
      barcode: '6291011029384',
      medicineName: 'Omeprazole 20mg (28 Cap) جلفار',
      qty: 30,
      unitPrice: 6000,
      totalAmount: 180000,
      avgCostAtSale: 4200,
      amountPaid: 120000,
      remainingUnpaid: 60000,
      nearestExpiryBatch: formatDate(400),
      notes: '',
      createdAt: Date.now() - 6 * 86400000,
    },
    {
      id: 's-5',
      date: formatDate(-4),
      buyer: 'صيدلية السلام الأهلية - الحرية',
      barcode: '4022536001283',
      medicineName: 'Concor 5mg (30 Tab) ميرك',
      qty: 25,
      unitPrice: 8750,
      totalAmount: 218750,
      avgCostAtSale: 6200,
      amountPaid: 218750,
      remainingUnpaid: 0,
      nearestExpiryBatch: formatDate(500),
      notes: '',
      createdAt: Date.now() - 4 * 86400000,
    },
    {
      id: 's-6',
      date: formatDate(-2),
      buyer: 'صيدلية الشفاء - الكرادة',
      barcode: '7611002938120',
      medicineName: 'Voltaren 50mg (20 Tab) نوفارتس',
      qty: 40,
      unitPrice: 6900,
      totalAmount: 276000,
      avgCostAtSale: 4800,
      amountPaid: 200000,
      remainingUnpaid: 76000,
      nearestExpiryBatch: formatDate(420),
      notes: 'أمر تجهيز مستعجل',
      createdAt: Date.now() - 2 * 86400000,
    },
    {
      id: 's-7',
      date: formatDate(-1),
      buyer: 'صيدلية الأمل المركزية - اليرموك',
      barcode: '6251001928374',
      medicineName: 'Amoxicillin 500mg (20 Cap) حكمة',
      qty: 18, // Sold 18 out of 25 -> remaining 7 < minStock 15 (Trigger low stock alert!)
      unitPrice: 4200,
      totalAmount: 75600,
      avgCostAtSale: 2800,
      amountPaid: 75600,
      remainingUnpaid: 0,
      nearestExpiryBatch: formatDate(300),
      notes: '',
      createdAt: Date.now() - 1 * 86400000,
    },
  ];

  const expenses: ExpenseItem[] = [
    {
      id: 'e-1',
      date: formatDate(-28),
      type: 'إيجار المذخر',
      amount: 450000,
      note: 'إيجار مخزن الجملة لشهر تشرين',
      createdAt: Date.now() - 28 * 86400000,
    },
    {
      id: 'e-2',
      date: formatDate(-20),
      type: 'نقل وشحن',
      amount: 45000,
      note: 'أجور توصيل طلبيات للصيدليات (دليفري)',
      createdAt: Date.now() - 20 * 86400000,
    },
    {
      id: 'e-3',
      date: formatDate(-15),
      type: 'كهرباء ومولد',
      amount: 85000,
      note: 'اشتراك المولد الشهري للمخزن والمكيفات',
      createdAt: Date.now() - 15 * 86400000,
    },
    {
      id: 'e-4',
      date: formatDate(-8),
      type: 'رواتب موظفين',
      amount: 350000,
      note: 'دفعة راتب مسؤول التجهيز والتخزين',
      createdAt: Date.now() - 8 * 86400000,
    },
    {
      id: 'e-5',
      date: formatDate(-3),
      type: 'ضيافة ونثريات',
      amount: 25000,
      note: 'أكياس تعبئة وطباعة فواتير وقرطاسية',
      createdAt: Date.now() - 3 * 86400000,
    },
  ];

  const payments: DebtPayment[] = [
    {
      id: 'pay-1',
      partyType: 'buyer',
      partyName: 'صيدلية النور والرحمة - الأعظمية',
      date: formatDate(-5),
      amount: 50000,
      type: 'receipt',
      note: 'دفعة نقدية مسددة في المذخر',
      createdAt: Date.now() - 5 * 86400000,
    },
    {
      id: 'pay-2',
      partyType: 'supplier',
      partyName: 'مذخر باب المعظم المركزي',
      date: formatDate(-4),
      amount: 80000,
      type: 'payment',
      note: 'تسديد دفعة عن فاتورة الأوجمنتين',
      createdAt: Date.now() - 4 * 86400000,
    },
  ];

  const minStockOverrides: Record<string, number> = {
    '6291100123456': 20,
    '5000158068942': 15,
    '6214000100124': 25,
    '6251001928374': 15,
    '6291011029384': 10,
    '4022536001283': 10,
    '3582910023412': 12,
    '7611002938120': 15,
  };

  const teamMembers = ['د. علي (المدير)', 'أحمد (المبيعات)', 'سجاد (المخزن)'];
  const enrichedPurchases = purchases.map((p, idx) => ({
    ...p,
    addedByName: p.addedByName || teamMembers[idx % teamMembers.length],
  }));
  const enrichedSales = sales.map((s, idx) => ({
    ...s,
    addedByName: s.addedByName || teamMembers[(idx + 1) % teamMembers.length],
  }));
  const enrichedExpenses = expenses.map((e, idx) => ({
    ...e,
    addedByName: e.addedByName || teamMembers[idx % teamMembers.length],
  }));
  const enrichedPayments = payments.map((pay, idx) => ({
    ...pay,
    addedByName: pay.addedByName || teamMembers[idx % teamMembers.length],
  }));

  const activityLogs = [
    {
      id: 'log-1',
      actionType: 'add_sale' as const,
      title: 'إضافة قائمة بيع: Panadol Extra 500mg',
      details: 'صيدلية الشفاء - المنصور (35 باكيت)',
      amount: 105000,
      actorUid: 'local_1',
      actorName: 'أحمد (المبيعات)',
      createdAtMs: Date.now() - 2 * 3600000,
    },
    {
      id: 'log-2',
      actionType: 'add_purchase' as const,
      title: 'إضافة قائمة شراء: Augmentin 1g',
      details: 'مذخر باب المعظم المركزي (60 باكيت)',
      amount: 408000,
      actorUid: 'local_2',
      actorName: 'سجاد (المخزن)',
      createdAtMs: Date.now() - 5 * 3600000,
    },
    {
      id: 'log-3',
      actionType: 'add_payment' as const,
      title: 'تسديد دفعة: صيدلية الشفاء - المنصور',
      details: 'قبض دفعة نقدية من الحساب',
      amount: 120000,
      actorUid: 'local_0',
      actorName: 'د. علي (المدير)',
      createdAtMs: Date.now() - 12 * 3600000,
    },
  ];

  return {
    version: DB_VERSION,
    updatedAt: new Date().toISOString(),
    currency: 'IQD',
    medicines,
    purchases: enrichedPurchases,
    sales: enrichedSales,
    expenses: enrichedExpenses,
    payments: enrichedPayments,
    minStockOverrides,
    activityLogs,
  };
}

/**
 * Load database from localStorage or seed initial data
 */
export function loadDatabase(): AppDatabase {
  if (typeof window === 'undefined') {
    return getInitialSampleData();
  }

  try {
    const raw = localStorage.getItem(DB_KEY);
    if (!raw) {
      const initial = getInitialSampleData();
      saveDatabase(initial);
      return initial;
    }
    const parsed = JSON.parse(raw) as AppDatabase;
    // Basic schema check
    if (!parsed.purchases || !parsed.sales || !parsed.expenses) {
      const initial = getInitialSampleData();
      saveDatabase(initial);
      return initial;
    }
    return parsed;
  } catch (err) {
    console.error('Failed to load database from localStorage:', err);
    return getInitialSampleData();
  }
}

/**
 * Persist database to localStorage
 */
export function saveDatabase(db: AppDatabase): boolean {
  if (typeof window === 'undefined') return false;
  try {
    db.updatedAt = new Date().toISOString();
    localStorage.setItem(DB_KEY, JSON.stringify(db));
    return true;
  } catch (err) {
    console.error('Failed to save database to localStorage:', err);
    return false;
  }
}

/**
 * Reset database to default sample data
 */
export function resetToSampleData(): AppDatabase {
  const sample = getInitialSampleData();
  saveDatabase(sample);
  return sample;
}

/**
 * Clear all records (fresh empty ledger)
 */
export function clearAllData(): AppDatabase {
  const emptyDb: AppDatabase = {
    version: DB_VERSION,
    updatedAt: new Date().toISOString(),
    currency: 'IQD',
    medicines: [],
    purchases: [],
    sales: [],
    expenses: [],
    payments: [],
    minStockOverrides: {},
  };
  saveDatabase(emptyDb);
  return emptyDb;
}

/**
 * Export database as formatted JSON string
 */
export function exportDatabaseJson(db: AppDatabase): string {
  return JSON.stringify(db, null, 2);
}

/**
 * Validate and import JSON string into database
 */
export function importDatabaseJson(jsonStr: string): { success: boolean; data?: AppDatabase; error?: string } {
  try {
    const parsed = JSON.parse(jsonStr);
    if (!parsed || typeof parsed !== 'object') {
      return { success: false, error: 'الملف المدخل ليس كائن JSON صالح.' };
    }

    if (!Array.isArray(parsed.purchases) || !Array.isArray(parsed.sales) || !Array.isArray(parsed.expenses)) {
      return { success: false, error: 'تنسيق البيانات غير متوافق: يفتقر إلى جداول المشتريات أو المبيعات أو المصاريف.' };
    }

    const cleanDb: AppDatabase = {
      version: parsed.version || DB_VERSION,
      updatedAt: new Date().toISOString(),
      currency: parsed.currency || 'IQD',
      medicines: Array.isArray(parsed.medicines) ? parsed.medicines : [],
      purchases: parsed.purchases,
      sales: parsed.sales,
      expenses: parsed.expenses,
      payments: Array.isArray(parsed.payments) ? parsed.payments : [],
      minStockOverrides: parsed.minStockOverrides || {},
    };

    saveDatabase(cleanDb);
    return { success: true, data: cleanDb };
  } catch (err) {
    return { success: false, error: 'خطأ في معالجة ملف JSON: ' + (err instanceof Error ? err.message : String(err)) };
  }
}
