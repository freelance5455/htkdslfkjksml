import { SolvedOpportunity, JobApplication, UserProfileData, Language } from '../types';
import { INITIAL_USER_PROFILE } from '../data/mockData';

const KEYS = {
  USER_PROFILE: 'project_zero_user_profile',
  SOLVED_PROBLEMS: 'project_zero_solved_problems',
  APPLICATIONS: 'project_zero_applications',
  LANGUAGE: 'project_zero_lang',
  SAVED_BLUEPRINTS: 'project_zero_saved_blueprints',
};

export const StorageService = {
  getLanguage(): Language {
    try {
      const stored = localStorage.getItem(KEYS.LANGUAGE);
      if (stored === 'am' || stored === 'en') return stored;
    } catch {}
    return 'en';
  },

  setLanguage(lang: Language) {
    try {
      localStorage.setItem(KEYS.LANGUAGE, lang);
    } catch {}
  },

  getUserProfile(): UserProfileData {
    try {
      const stored = localStorage.getItem(KEYS.USER_PROFILE);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {}
    return INITIAL_USER_PROFILE;
  },

  saveUserProfile(profile: UserProfileData) {
    try {
      localStorage.setItem(KEYS.USER_PROFILE, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to save profile locally', e);
    }
  },

  getSolvedProblems(): SolvedOpportunity[] {
    try {
      const stored = localStorage.getItem(KEYS.SOLVED_PROBLEMS);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {}
    return [];
  },

  saveSolvedProblem(problem: SolvedOpportunity): SolvedOpportunity[] {
    const list = this.getSolvedProblems();
    const updated = [problem, ...list.filter((item) => item.id !== problem.id)];
    try {
      localStorage.setItem(KEYS.SOLVED_PROBLEMS, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save solved problem', e);
    }
    return updated;
  },

  deleteSolvedProblem(id: string): SolvedOpportunity[] {
    const list = this.getSolvedProblems().filter((p) => p.id !== id);
    try {
      localStorage.setItem(KEYS.SOLVED_PROBLEMS, JSON.stringify(list));
    } catch {}
    return list;
  },

  getApplications(): JobApplication[] {
    try {
      const stored = localStorage.getItem(KEYS.APPLICATIONS);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {}
    return [];
  },

  saveApplication(app: JobApplication): JobApplication[] {
    const current = this.getApplications();
    const updated = [app, ...current.filter((a) => a.id !== app.id)];
    try {
      localStorage.setItem(KEYS.APPLICATIONS, JSON.stringify(updated));
    } catch {}
    return updated;
  },

  getSavedBlueprints(): string[] {
    try {
      const stored = localStorage.getItem(KEYS.SAVED_BLUEPRINTS);
      if (stored) return JSON.parse(stored);
    } catch {}
    return ['biz_01']; // default 1 saved
  },

  toggleSaveBlueprint(blueprintId: string): string[] {
    const list = this.getSavedBlueprints();
    const exists = list.includes(blueprintId);
    const updated = exists ? list.filter((id) => id !== blueprintId) : [...list, blueprintId];
    try {
      localStorage.setItem(KEYS.SAVED_BLUEPRINTS, JSON.stringify(updated));
    } catch {}
    return updated;
  },
};
