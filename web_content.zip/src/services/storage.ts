import {
  Book,
  ReadingSession,
  BookQuote,
  Collection,
  ReadingGoal,
  AppSettings,
  ReadingActivity,
  BackupData,
  CustomSticker,
} from '../types';
import {
  SAMPLE_BOOKS,
  SAMPLE_SESSIONS,
  SAMPLE_QUOTES,
  INITIAL_COLLECTIONS,
  INITIAL_GOALS,
  INITIAL_SETTINGS,
  SAMPLE_ACTIVITIES,
} from './seedData';

const DB_NAME = 'MiBibliotecaDB';
const DB_VERSION = 2; // Incremented for stickers support

class StorageService {
  private dbPromise: Promise<IDBDatabase | null> | null = null;
  private hasIndexedDB = typeof window !== 'undefined' && 'indexedDB' in window;

  private async openDB(): Promise<IDBDatabase | null> {
    if (!this.hasIndexedDB) return null;
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve) => {
      try {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          const stores = ['books', 'sessions', 'quotes', 'collections', 'goals', 'activities', 'settings', 'stickers'];
          stores.forEach((storeName) => {
            if (!db.objectStoreNames.contains(storeName)) {
              db.createObjectStore(storeName, { keyPath: 'id' });
            }
          });
        };

        request.onsuccess = () => {
          resolve(request.result);
        };

        request.onerror = () => {
          console.warn('IndexedDB failed to open, falling back to localStorage');
          resolve(null);
        };
      } catch (err) {
        console.warn('IndexedDB exception, falling back to localStorage', err);
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  // Generic store reader
  private async getAllFromStore<T>(storeName: string, storageKey: string, fallbackDefault: T[]): Promise<T[]> {
    const db = await this.openDB();
    if (!db) {
      const saved = localStorage.getItem(storageKey);
      if (!saved) {
        localStorage.setItem(storageKey, JSON.stringify(fallbackDefault));
        return fallbackDefault;
      }
      try {
        return JSON.parse(saved);
      } catch {
        return fallbackDefault;
      }
    }

    return new Promise((resolve) => {
      try {
        const tx = db.transaction(storeName, 'readonly');
        const store = tx.objectStore(storeName);
        const req = store.getAll();

        req.onsuccess = () => {
          const items = req.result as T[];
          if (!items || items.length === 0) {
            // First time initialization: populate store
            this.putBatch(storeName, fallbackDefault as any[]);
            resolve(fallbackDefault);
          } else {
            resolve(items);
          }
        };

        req.onerror = () => {
          resolve(fallbackDefault);
        };
      } catch {
        resolve(fallbackDefault);
      }
    });
  }

  private async putItem<T extends { id: string }>(storeName: string, storageKey: string, item: T): Promise<void> {
    const db = await this.openDB();
    if (!db) {
      const items = (await this.getAllFromStore<T>(storeName, storageKey, [])) || [];
      const idx = items.findIndex((i) => i.id === item.id);
      if (idx >= 0) items[idx] = item;
      else items.unshift(item);
      localStorage.setItem(storageKey, JSON.stringify(items));
      return;
    }

    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        const req = store.put(item);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }

  private async putBatch(storeName: string, items: any[]): Promise<void> {
    const db = await this.openDB();
    if (!db || items.length === 0) return;

    try {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      items.forEach((item) => store.put(item));
    } catch (e) {
      console.error(`Error putting batch in ${storeName}`, e);
    }
  }

  private async deleteFromStore(storeName: string, storageKey: string, id: string): Promise<void> {
    const db = await this.openDB();
    if (!db) {
      const items = (await this.getAllFromStore<{ id: string }>(storeName, storageKey, [])) || [];
      const filtered = items.filter((i) => i.id !== id);
      localStorage.setItem(storageKey, JSON.stringify(filtered));
      return;
    }

    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        const req = store.delete(id);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }

  // --- Books CRUD ---
  async getBooks(): Promise<Book[]> {
    return this.getAllFromStore<Book>('books', 'mb_books', SAMPLE_BOOKS);
  }

  async saveBook(book: Book): Promise<void> {
    await this.putItem('books', 'mb_books', book);
  }

  async deleteBook(id: string): Promise<void> {
    await this.deleteFromStore('books', 'mb_books', id);
  }

  // --- Sessions CRUD ---
  async getSessions(): Promise<ReadingSession[]> {
    return this.getAllFromStore<ReadingSession>('sessions', 'mb_sessions', SAMPLE_SESSIONS);
  }

  async saveSession(session: ReadingSession): Promise<void> {
    await this.putItem('sessions', 'mb_sessions', session);
  }

  async deleteSession(id: string): Promise<void> {
    await this.deleteFromStore('sessions', 'mb_sessions', id);
  }

  // --- Quotes CRUD ---
  async getQuotes(): Promise<BookQuote[]> {
    return this.getAllFromStore<BookQuote>('quotes', 'mb_quotes', SAMPLE_QUOTES);
  }

  async saveQuote(quote: BookQuote): Promise<void> {
    await this.putItem('quotes', 'mb_quotes', quote);
  }

  async deleteQuote(id: string): Promise<void> {
    await this.deleteFromStore('quotes', 'mb_quotes', id);
  }

  // --- Custom Stickers CRUD ---
  async getStickers(): Promise<CustomSticker[]> {
    return this.getAllFromStore<CustomSticker>('stickers', 'mb_stickers', []);
  }

  async saveSticker(sticker: CustomSticker): Promise<void> {
    await this.putItem('stickers', 'mb_stickers', sticker);
  }

  async deleteSticker(id: string): Promise<void> {
    await this.deleteFromStore('stickers', 'mb_stickers', id);
  }

  // --- Collections CRUD ---
  async getCollections(): Promise<Collection[]> {
    return this.getAllFromStore<Collection>('collections', 'mb_collections', INITIAL_COLLECTIONS);
  }

  async saveCollection(col: Collection): Promise<void> {
    await this.putItem('collections', 'mb_collections', col);
  }

  async deleteCollection(id: string): Promise<void> {
    await this.deleteFromStore('collections', 'mb_collections', id);
  }

  // --- Goals CRUD ---
  async getGoals(): Promise<ReadingGoal[]> {
    return this.getAllFromStore<ReadingGoal>('goals', 'mb_goals', INITIAL_GOALS);
  }

  async saveGoal(goal: ReadingGoal): Promise<void> {
    await this.putItem('goals', 'mb_goals', goal);
  }

  async deleteGoal(id: string): Promise<void> {
    await this.deleteFromStore('goals', 'mb_goals', id);
  }

  // --- Activities ---
  async getActivities(): Promise<ReadingActivity[]> {
    return this.getAllFromStore<ReadingActivity>('activities', 'mb_activities', SAMPLE_ACTIVITIES);
  }

  async addActivity(activity: ReadingActivity): Promise<void> {
    await this.putItem('activities', 'mb_activities', activity);
  }

  // --- Settings ---
  async getSettings(): Promise<AppSettings> {
    const db = await this.openDB();
    if (!db) {
      const saved = localStorage.getItem('mb_settings');
      if (saved) {
        try {
          return { ...INITIAL_SETTINGS, ...JSON.parse(saved) };
        } catch {
          return INITIAL_SETTINGS;
        }
      }
      return INITIAL_SETTINGS;
    }

    return new Promise((resolve) => {
      try {
        const tx = db.transaction('settings', 'readonly');
        const store = tx.objectStore('settings');
        const req = store.get('app_settings');
        req.onsuccess = () => {
          if (req.result && req.result.data) {
            resolve({ ...INITIAL_SETTINGS, ...req.result.data });
          } else {
            this.saveSettings(INITIAL_SETTINGS);
            resolve(INITIAL_SETTINGS);
          }
        };
        req.onerror = () => resolve(INITIAL_SETTINGS);
      } catch {
        resolve(INITIAL_SETTINGS);
      }
    });
  }

  async saveSettings(settings: AppSettings): Promise<void> {
    const db = await this.openDB();
    localStorage.setItem('mb_settings', JSON.stringify(settings));

    if (!db) return;
    try {
      const tx = db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');
      store.put({ id: 'app_settings', data: settings });
    } catch (e) {
      console.error('Failed to save settings to IndexedDB', e);
    }
  }

  // --- Backup & Restore (JSON) ---
  async exportBackup(): Promise<string> {
    const [books, sessions, quotes, collections, goals, settings, activities, stickers] = await Promise.all([
      this.getBooks(),
      this.getSessions(),
      this.getQuotes(),
      this.getCollections(),
      this.getGoals(),
      this.getSettings(),
      this.getActivities(),
      this.getStickers(),
    ]);

    const backup: BackupData = {
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      books,
      sessions,
      quotes,
      collections,
      goals,
      settings,
      activities,
      stickers,
    };

    return JSON.stringify(backup, null, 2);
  }

  async importBackup(jsonString: string, mode: 'merge' | 'replace' = 'replace'): Promise<boolean> {
    try {
      const data: BackupData = JSON.parse(jsonString);
      if (!data.books || !Array.isArray(data.books)) {
        throw new Error('Formato de copia de seguridad no válido');
      }

      if (mode === 'replace') {
        await this.clearAllData();

        const db = await this.openDB();
        if (db) {
          await Promise.all([
            this.putBatch('books', data.books || []),
            this.putBatch('sessions', data.sessions || []),
            this.putBatch('quotes', data.quotes || []),
            this.putBatch('collections', data.collections || []),
            this.putBatch('goals', data.goals || []),
            this.putBatch('activities', data.activities || []),
            this.putBatch('stickers', data.stickers || []),
          ]);
          if (data.settings) {
            await this.saveSettings(data.settings);
          }
        } else {
          localStorage.setItem('mb_books', JSON.stringify(data.books || []));
          localStorage.setItem('mb_sessions', JSON.stringify(data.sessions || []));
          localStorage.setItem('mb_quotes', JSON.stringify(data.quotes || []));
          localStorage.setItem('mb_collections', JSON.stringify(data.collections || []));
          localStorage.setItem('mb_goals', JSON.stringify(data.goals || []));
          localStorage.setItem('mb_activities', JSON.stringify(data.activities || []));
          localStorage.setItem('mb_stickers', JSON.stringify(data.stickers || []));
          if (data.settings) localStorage.setItem('mb_settings', JSON.stringify(data.settings));
        }
      } else {
        // MERGE MODE: Non-destructively merge without deleting local records
        const [currentBooks, currentSessions, currentQuotes, currentCollections, currentGoals, currentStickers] =
          await Promise.all([
            this.getBooks(),
            this.getSessions(),
            this.getQuotes(),
            this.getCollections(),
            this.getGoals(),
            this.getStickers(),
          ]);

        // Merge books
        const bookMap = new Map<string, Book>();
        currentBooks.forEach((b) => bookMap.set(b.id, b));
        (data.books || []).forEach((incomingBook) => {
          const existing = bookMap.get(incomingBook.id);
          if (!existing) {
            bookMap.set(incomingBook.id, incomingBook);
          } else {
            bookMap.set(incomingBook.id, {
              ...existing,
              ...incomingBook,
              pagesRead: Math.max(existing.pagesRead || 0, incomingBook.pagesRead || 0),
              progress: Math.max(existing.progress || 0, incomingBook.progress || 0),
              fileAttachment: existing.fileAttachment || incomingBook.fileAttachment,
            });
          }
        });

        // Merge sessions
        const sessionMap = new Map<string, ReadingSession>();
        currentSessions.forEach((s) => sessionMap.set(s.id, s));
        (data.sessions || []).forEach((s) => {
          if (!sessionMap.has(s.id)) sessionMap.set(s.id, s);
        });

        // Merge quotes
        const quoteMap = new Map<string, BookQuote>();
        currentQuotes.forEach((q) => quoteMap.set(q.id, q));
        (data.quotes || []).forEach((q) => {
          if (!quoteMap.has(q.id)) quoteMap.set(q.id, q);
        });

        // Merge collections
        const colMap = new Map<string, Collection>();
        currentCollections.forEach((c) => colMap.set(c.id, c));
        (data.collections || []).forEach((c) => {
          if (!colMap.has(c.id)) colMap.set(c.id, c);
        });

        // Merge stickers
        const stkMap = new Map<string, CustomSticker>();
        currentStickers.forEach((st) => stkMap.set(st.id, st));
        (data.stickers || []).forEach((st) => {
          if (!stkMap.has(st.id)) stkMap.set(st.id, st);
        });

        // Save merged
        for (const b of Array.from(bookMap.values())) await this.saveBook(b);
        for (const s of Array.from(sessionMap.values())) await this.saveSession(s);
        for (const q of Array.from(quoteMap.values())) await this.saveQuote(q);
        for (const c of Array.from(colMap.values())) await this.saveCollection(c);
        for (const st of Array.from(stkMap.values())) await this.saveSticker(st);
      }

      return true;
    } catch (err) {
      console.error('Error importing backup:', err);
      return false;
    }
  }

  async clearAllData(): Promise<void> {
    const db = await this.openDB();
    const stores = ['books', 'sessions', 'quotes', 'collections', 'goals', 'activities', 'settings', 'stickers'];

    if (db) {
      await Promise.all(
        stores.map(
          (storeName) =>
            new Promise<void>((resolve) => {
              try {
                const tx = db.transaction(storeName, 'readwrite');
                tx.objectStore(storeName).clear();
                tx.oncomplete = () => resolve();
                tx.onerror = () => resolve();
              } catch {
                resolve();
              }
            })
        )
      );
    }

    localStorage.removeItem('mb_books');
    localStorage.removeItem('mb_sessions');
    localStorage.removeItem('mb_quotes');
    localStorage.removeItem('mb_collections');
    localStorage.removeItem('mb_goals');
    localStorage.removeItem('mb_activities');
    localStorage.removeItem('mb_settings');
    localStorage.removeItem('mb_stickers');
  }

  async removeSampleData(): Promise<void> {
    const books = await this.getBooks();
    const nonSampleBooks = books.filter((b) => !b.isSample);

    const db = await this.openDB();
    if (db) {
      const tx = db.transaction('books', 'readwrite');
      tx.objectStore('books').clear();
      tx.oncomplete = () => {
        this.putBatch('books', nonSampleBooks);
      };
    }
    localStorage.setItem('mb_books', JSON.stringify(nonSampleBooks));
  }

  async restoreSampleData(): Promise<void> {
    await this.clearAllData();
    const db = await this.openDB();
    if (db) {
      await Promise.all([
        this.putBatch('books', SAMPLE_BOOKS),
        this.putBatch('sessions', SAMPLE_SESSIONS),
        this.putBatch('quotes', SAMPLE_QUOTES),
        this.putBatch('collections', INITIAL_COLLECTIONS),
        this.putBatch('goals', INITIAL_GOALS),
        this.putBatch('activities', SAMPLE_ACTIVITIES),
        this.putBatch('stickers', []),
      ]);
      await this.saveSettings(INITIAL_SETTINGS);
    } else {
      localStorage.setItem('mb_books', JSON.stringify(SAMPLE_BOOKS));
      localStorage.setItem('mb_sessions', JSON.stringify(SAMPLE_SESSIONS));
      localStorage.setItem('mb_quotes', JSON.stringify(SAMPLE_QUOTES));
      localStorage.setItem('mb_collections', JSON.stringify(INITIAL_COLLECTIONS));
      localStorage.setItem('mb_goals', JSON.stringify(INITIAL_GOALS));
      localStorage.setItem('mb_activities', JSON.stringify(SAMPLE_ACTIVITIES));
      localStorage.setItem('mb_stickers', JSON.stringify([]));
      localStorage.setItem('mb_settings', JSON.stringify(INITIAL_SETTINGS));
    }
  }
}

export const storage = new StorageService();
