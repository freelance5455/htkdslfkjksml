import { Project, TimelineClip, SourceMedia } from '../types/editor';

const STORAGE_KEY = 'cutpro_projects_v1';
const ACTIVE_PROJECT_KEY = 'cutpro_active_project_id';

export function loadProjects(): Project[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load projects from localStorage', e);
    return [];
  }
}

export function saveProjects(projects: Project[]): void {
  try {
    // Avoid serializing huge files or blobs into localStorage; store references
    const cleanProjects = projects.map((p) => ({
      ...p,
      mediaMap: Object.fromEntries(
        Object.entries(p.mediaMap).map(([id, m]) => [
          id,
          {
            ...m,
            file: undefined, // Don't serialize File object
          },
        ])
      ),
    }));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cleanProjects));
  } catch (e) {
    console.error('Failed to save projects to localStorage', e);
  }
}

export function getProjectById(id: string): Project | null {
  const projects = loadProjects();
  return projects.find((p) => p.id === id) || null;
}

export function saveProject(project: Project): void {
  const projects = loadProjects();
  const existingIdx = projects.findIndex((p) => p.id === project.id);
  const updated = { ...project, updatedAt: Date.now() };

  if (existingIdx >= 0) {
    projects[existingIdx] = updated;
  } else {
    projects.unshift(updated);
  }

  saveProjects(projects);
  localStorage.setItem(ACTIVE_PROJECT_KEY, project.id);
}

export function deleteProject(id: string): void {
  const projects = loadProjects().filter((p) => p.id !== id);
  saveProjects(projects);
}

export function createNewProject(name: string = 'Untitled Project'): Project {
  return {
    id: `cutpro_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    name,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    aspectRatio: '16:9',
    resolution: '1080p',
    clips: [],
    mediaMap: {},
  };
}
