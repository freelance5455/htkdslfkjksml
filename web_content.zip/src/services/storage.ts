/**
 * HELENA - Local & Firestore Config Store
 * Manages API keys (Gemini, Groq), models, auth state, and settings.
 * All keys stored masked in UI, only readable by authenticated owner.
 */

import { AppSettings, HistoryItem } from '../types';

const SETTINGS_KEY = 'helena_settings_v2';
const HISTORY_KEY = 'helena_history_v1';
const AUTH_KEY = 'helena_auth_session';

export const DEFAULT_SETTINGS: AppSettings = {
  geminiKey: 'AQ.Ab8RN6I7pWvDFwZCYhYPCbznUL2FuBxb_w5ThYmsuv8G2lPNNQ',
  geminiModel: 'gemini-3.1-flash-lite',
  groqKey: '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',
  groqModel: 'llama-3.3-70b-versatile',
  groqVisionModel: 'llama-3.2-11b-vision-preview',
  trustedAuthors: ['vet3d', 'university', 'veterinary', 'anatomy', 'faculdade', 'usp', 'ufmg'],
  wakeWord: 'Helena',
  speechRate: 1.0,
  speechMuted: false,
  ownerEmail: 'snafring777@gmail.com',
  isPasswordChanged: false,
};

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) {
      // Check if v1 settings exist to migrate user keys
      const oldRaw = localStorage.getItem('helena_settings_v1');
      if (oldRaw) {
        try {
          const old = JSON.parse(oldRaw);
          const migrated: AppSettings = {
            ...DEFAULT_SETTINGS,
            geminiKey: old.geminiKey || DEFAULT_SETTINGS.geminiKey,
            groqKey: old.groqKey || DEFAULT_SETTINGS.groqKey,
          };
          saveSettings(migrated);
          return migrated;
        } catch {}
      }
      saveSettings(DEFAULT_SETTINGS);
      return DEFAULT_SETTINGS;
    }
    const parsed = JSON.parse(raw);

    const merged: AppSettings = {
      ...DEFAULT_SETTINGS,
      ...parsed,
      geminiKey: parsed.geminiKey || DEFAULT_SETTINGS.geminiKey,
      groqKey: parsed.groqKey || DEFAULT_SETTINGS.groqKey,
      geminiModel: parsed.geminiModel || DEFAULT_SETTINGS.geminiModel,
      groqModel: parsed.groqModel || DEFAULT_SETTINGS.groqModel,
      groqVisionModel: parsed.groqVisionModel || DEFAULT_SETTINGS.groqVisionModel,
      trustedAuthors: Array.isArray(parsed.trustedAuthors) && parsed.trustedAuthors.length > 0 
        ? parsed.trustedAuthors 
        : DEFAULT_SETTINGS.trustedAuthors,
    };

    saveSettings(merged);
    return merged;
  } catch {
    saveSettings(DEFAULT_SETTINGS);
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings:', err);
  }
}

export function maskKey(key: string): string {
  if (!key) return '';
  if (key.length <= 6) return '••••••';
  return '••••••••' + key.slice(-4);
}

// Session Authentication
export function getStoredPasswordHash(): string {
  return localStorage.getItem('helena_pwd_hash') || '';
}

export function setStoredPasswordHash(hash: string): void {
  localStorage.setItem('helena_pwd_hash', hash);
}

export function isUserAuthenticated(): boolean {
  return localStorage.getItem(AUTH_KEY) === 'true';
}

export function setAuthenticated(isAuth: boolean): void {
  if (isAuth) {
    localStorage.setItem(AUTH_KEY, 'true');
  } else {
    localStorage.removeItem(AUTH_KEY);
  }
}

// History
export function loadHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function addHistoryItem(item: HistoryItem): void {
  try {
    const list = loadHistory();
    list.unshift(item);
    if (list.length > 50) list.pop();
    localStorage.setItem(HISTORY_KEY, JSON.stringify(list));
  } catch (err) {
    console.error('Failed to add history item:', err);
  }
}

export function clearHistory(): void {
  try {
    localStorage.removeItem(HISTORY_KEY);
  } catch (err) {
    console.error('Failed to clear history:', err);
  }
}

