import { SFXEvent } from '../types';

const STORAGE_KEY = 'hitech_sfx_events_db';

const INITIAL_EVENTS: SFXEvent[] = [
  {
    id: 1,
    customer: 'Rajesh & Priya Wedding',
    type: 'Wedding Entry & Varmala',
    event_date: '2026-11-05',
    venue: 'Grand Imperial Palace, Ballroom A',
    phone: '+91 98765 43210',
    amount: '45000',
    status: 'Confirmed',
    notes: '4 Cold Pyro guns + Low Fog Dry Ice for couple entrance. Team of 3 technicians required.',
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    customer: 'TechSummit 2026 Keynote',
    type: 'Corporate Stage FX',
    event_date: '2026-11-12',
    venue: 'Convention Centre, Main Auditorium',
    phone: '+91 98111 22334',
    amount: '60000',
    status: 'Booked',
    notes: 'CO2 Jets (4 units) + Dual Confetti Blasters at CEO entrance and award announcement.',
    created_at: new Date().toISOString(),
  },
  {
    id: 3,
    customer: 'Amit Sangeet Ceremony',
    type: 'Sangeet & DJ Night',
    event_date: '2026-11-20',
    venue: 'Royal Palms Lawn, Sector 62',
    phone: '+91 99223 34455',
    amount: '35000',
    status: 'Advance Pending',
    notes: '₹10,000 advance received via UPI. Balance on sound check. 8 Sparkulars setup.',
    created_at: new Date().toISOString(),
  },
  {
    id: 4,
    customer: 'Sunburn Arena Pre-Party',
    type: 'EDM Concert FX',
    event_date: '2026-12-01',
    venue: 'Skyline Arena Ground',
    phone: '+91 97654 32190',
    amount: '120000',
    status: 'Confirmed',
    notes: 'Laser light show (40W RGB) + Flame projectors + Nitrogen cannons. Full crew safety clearance done.',
    created_at: new Date().toISOString(),
  },
  {
    id: 5,
    customer: 'Gupta Silver Jubilee',
    type: 'Anniversary Party',
    event_date: '2026-10-18',
    venue: 'Hotel Radisson Blu, Ruby Hall',
    phone: '+91 98450 12345',
    amount: '22000',
    status: 'Completed',
    notes: 'Stage backdrop pyro and gold paper blast during cake cutting. Payment settled in full.',
    created_at: new Date().toISOString(),
  },
];

export function getEventsFromStorage(): SFXEvent[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_EVENTS));
      return INITIAL_EVENTS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed.sort((a, b) => (a.event_date || '').localeCompare(b.event_date || ''));
    }
    return INITIAL_EVENTS;
  } catch (e) {
    console.error('Failed to load events from storage', e);
    return INITIAL_EVENTS;
  }
}

export function saveEventsToStorage(events: SFXEvent[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(events));
  } catch (e) {
    console.error('Failed to save events to storage', e);
  }
}

export function addOrUpdateEvent(data: Omit<SFXEvent, 'id'>, editId?: number): SFXEvent {
  const current = getEventsFromStorage();
  let updatedEvent: SFXEvent;

  if (editId && editId !== -1) {
    const index = current.findIndex(e => e.id === editId);
    if (index !== -1) {
      updatedEvent = {
        ...current[index],
        ...data,
        id: editId,
      };
      current[index] = updatedEvent;
    } else {
      updatedEvent = {
        ...data,
        id: editId,
        created_at: new Date().toISOString(),
      };
      current.push(updatedEvent);
    }
  } else {
    const nextId = current.length > 0 ? Math.max(...current.map(e => e.id)) + 1 : 1;
    updatedEvent = {
      ...data,
      id: nextId,
      created_at: new Date().toISOString(),
    };
    current.push(updatedEvent);
  }

  saveEventsToStorage(current);
  return updatedEvent;
}

export function deleteEventFromStorage(id: number): void {
  const current = getEventsFromStorage();
  const filtered = current.filter(e => e.id !== id);
  saveEventsToStorage(filtered);
}

export function searchEvents(query: string): SFXEvent[] {
  const events = getEventsFromStorage();
  if (!query || !query.trim()) {
    return events;
  }
  const q = query.toLowerCase().trim();
  return events.filter(e =>
    (e.customer && e.customer.toLowerCase().includes(q)) ||
    (e.type && e.type.toLowerCase().includes(q)) ||
    (e.venue && e.venue.toLowerCase().includes(q)) ||
    (e.phone && e.phone.toLowerCase().includes(q)) ||
    (e.event_date && e.event_date.toLowerCase().includes(q)) ||
    (e.notes && e.notes.toLowerCase().includes(q))
  );
}

export function resetToDemoData(): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_EVENTS));
}
