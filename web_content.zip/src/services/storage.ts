import { UserProfile, GameSettings, MatchResult, OnlineLobbyPlayer, TimeControlConfig } from '../types/chess';

const PROFILE_KEY = 'chess_3d_user_profile';
const SETTINGS_KEY = 'chess_3d_settings';
const SAVED_GAME_KEY = 'chess_3d_saved_game';

export const TIME_CONTROL_PRESETS: TimeControlConfig[] = [
  { id: 'bullet_1_0', name: '1+0', category: 'bullet', initialSeconds: 60, incrementSeconds: 0 },
  { id: 'bullet_2_1', name: '2+1', category: 'bullet', initialSeconds: 120, incrementSeconds: 1 },
  { id: 'blitz_3_0', name: '3+0', category: 'blitz', initialSeconds: 180, incrementSeconds: 0 },
  { id: 'blitz_5_3', name: '5+3', category: 'blitz', initialSeconds: 300, incrementSeconds: 3 },
  { id: 'rapid_10_0', name: '10+0', category: 'rapid', initialSeconds: 600, incrementSeconds: 0 },
  { id: 'rapid_15_10', name: '15+10', category: 'rapid', initialSeconds: 900, incrementSeconds: 10 },
  { id: 'untimed', name: 'Untimed', category: 'untimed', initialSeconds: 0, incrementSeconds: 0 },
];

export const DEFAULT_SETTINGS: GameSettings = {
  boardStyle: 'classic',
  pieceStyle: 'classic',
  theme: 'dark',
  soundEnabled: true,
  musicEnabled: false,
  showLegalMoves: true,
  autoQueen: true,
  cameraAutoRotate: false,
  perspective: 'white',
  timeControlSeconds: 600,
  incrementSeconds: 0,
  aiSpeed: 'normal',
};

const DEFAULT_PROFILE: UserProfile = {
  id: 'user-kartik-1',
  name: 'Kartik Jadhav',
  avatar: '👑',
  rating: 1200,
  title: 'Beginner',
  totalGames: 48,
  wins: 28,
  losses: 16,
  draws: 4,
  ratingHistory: [
    { date: '10/01', rating: 1000 },
    { date: '10/04', rating: 1050 },
    { date: '10/07', rating: 1120 },
    { date: '10/10', rating: 1090 },
    { date: '10/12', rating: 1180 },
    { date: '10/14', rating: 1150 },
    { date: '10/17', rating: 1200 },
  ],
  completedPuzzles: ['puz-1'],
  achievements: [
    {
      id: 'first-win',
      title: 'First Blood',
      description: 'Win your first chess game.',
      icon: '⚔️',
      unlocked: true,
      unlockedAt: '2026-10-01',
    },
    {
      id: 'scholar-mate',
      title: 'Tactical Striker',
      description: 'Win a game in under 20 moves.',
      icon: '⚡',
      unlocked: true,
      unlockedAt: '2026-10-05',
    },
    {
      id: 'ai-master',
      title: 'Master Mind',
      description: 'Defeat the Expert AI difficulty.',
      icon: '🤖',
      unlocked: false,
    },
    {
      id: 'puzzle-pro',
      title: 'Puzzle Grandmaster',
      description: 'Solve 5 tactical chess puzzles.',
      icon: '🧩',
      unlocked: false,
      progress: 1,
      maxProgress: 5,
    },
    {
      id: 'flawless-victory',
      title: 'Flawless Victory',
      description: 'Win without losing your Queen.',
      icon: '👑',
      unlocked: true,
      unlockedAt: '2026-10-12',
    },
    {
      id: 'online-glory',
      title: 'Arena Gladiator',
      description: 'Win 10 online multiplayer games.',
      icon: '🏆',
      unlocked: false,
      progress: 6,
      maxProgress: 10,
    },
  ],
};

export const ONLINE_LOBBY_PLAYERS: OnlineLobbyPlayer[] = [
  { id: 'p-1', name: 'Rohit_Chess', avatar: '👨‍💼', rating: 1240, status: 'online', country: 'IN' },
  { id: 'p-2', name: 'ChessMaster99', avatar: '🧙‍♂️', rating: 1365, status: 'online', country: 'US' },
  { id: 'p-3', name: 'KingSlayer', avatar: '🦁', rating: 1189, status: 'online', country: 'GB' },
  { id: 'p-4', name: 'QueenGambit', avatar: '👸', rating: 1320, status: 'online', country: 'CA' },
  { id: 'p-5', name: 'BlitzPlayer', avatar: '⚡', rating: 1023, status: 'online', country: 'DE' },
  { id: 'p-6', name: 'GrandPatzer', avatar: '🦉', rating: 1450, status: 'online', country: 'FR' },
];

export function loadProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) return DEFAULT_PROFILE;
    return { ...DEFAULT_PROFILE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function saveProfile(profile: UserProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch (err) {
    console.error('Failed to save profile', err);
  }
}

export function recordMatchOutcome(
  result: MatchResult,
  playerColor: 'w' | 'b',
  opponentName: string,
  opponentRating: number
): UserProfile {
  const profile = loadProfile();
  profile.totalGames += 1;

  const isWin = result.winner === playerColor;
  const isLoss = result.winner !== 'draw' && !isWin;
  const isDraw = result.winner === 'draw';

  let ratingDelta = 0;
  if (isWin) {
    profile.wins += 1;
    ratingDelta = Math.max(12, Math.round(18 + (opponentRating - profile.rating) * 0.05));
  } else if (isLoss) {
    profile.losses += 1;
    ratingDelta = -Math.max(10, Math.round(16 - (opponentRating - profile.rating) * 0.04));
  } else if (isDraw) {
    profile.draws += 1;
    ratingDelta = Math.round((opponentRating - profile.rating) * 0.03);
  }

  profile.rating = Math.max(600, profile.rating + ratingDelta);

  // Update title based on rating
  if (profile.rating >= 2000) profile.title = 'Grandmaster';
  else if (profile.rating >= 1800) profile.title = 'Master';
  else if (profile.rating >= 1500) profile.title = 'Intermediate';
  else profile.title = 'Beginner';

  const todayStr = new Date().toLocaleDateString('en-US', { month: '2-digit', day: '2-digit' });
  profile.ratingHistory.push({ date: todayStr, rating: profile.rating });
  if (profile.ratingHistory.length > 10) {
    profile.ratingHistory.shift();
  }

  saveProfile(profile);
  return profile;
}

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings', err);
  }
}

export interface SavedGame {
  fen: string;
  pgn: string;
  gameMode: string;
  difficulty?: string;
  playerColor: 'w' | 'b';
  whiteTime: number;
  blackTime: number;
  timeControlSeconds: number;
  incrementSeconds: number;
  date: string;
}

export function saveGameInProgress(data: SavedGame): void {
  try {
    localStorage.setItem(SAVED_GAME_KEY, JSON.stringify(data));
  } catch {
    // Ignore storage errors
  }
}

export function loadSavedGame(): SavedGame | null {
  try {
    const raw = localStorage.getItem(SAVED_GAME_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function clearSavedGame(): void {
  localStorage.removeItem(SAVED_GAME_KEY);
}
