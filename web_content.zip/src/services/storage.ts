import { Customer, Bill, Payment, BusinessProfile, SupabaseConfig } from '../types';

const STORAGE_KEYS = {
  CUSTOMERS: 'cnc_customers_v1',
  BILLS: 'cnc_bills_v1',
  PAYMENTS: 'cnc_payments_v1',
  PROFILE: 'cnc_profile_v1',
  SUPABASE: 'cnc_supabase_v1',
  ACTIVE_MONTH: 'cnc_active_month_v1',
  ADMIN_PIN: 'cnc_admin_pin_v1',
  LANGUAGE: 'cnc_language_v1',
};

export const DEFAULT_AREAS = [
  'Champeswar Bazar',
  'Mandir Sahi',
  'Nua Sahi',
  'Canal Road',
  'Hospital Road',
  'College Road',
  'Station Chhak',
  'Nuapatna Link',
  'Badamba Road',
  'Brahmapur Sahi',
];

export const DEFAULT_PROFILE: BusinessProfile = {
  name: 'CCTV NETWORK CHAMPESWAR',
  tagline: 'High Speed Optical Fiber Broadband & Digital Cable TV',
  ownerName: 'Sanjay Kumar Panda',
  phone: '+91 94371 28945',
  alternatePhone: '+91 70082 14590',
  email: 'cctvchampeswar@gmail.com',
  address: 'Main Market, Near Shiva Temple',
  village: 'Champeswar',
  district: 'Cuttack, Odisha',
  pincode: '754027',
  upiId: 'cctvchampeswar@upi',
  upiPayeeName: 'CCTV NETWORK CHAMPESWAR',
  gstin: '21AAHPC4567M1ZX',
  receiptFooterText: 'Thank you for choosing CCTV Network Champeswar. For complaints & support call: 9437128945',
};

const SAMPLE_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    customerCode: 'CNC-1001',
    name: 'Bikash Chandra Mohapatra',
    mobile: '9437123456',
    address: 'Near Old Shiva Temple, Plot 42',
    area: 'Mandir Sahi',
    serviceType: 'COMBO',
    planName: 'Fiber 50Mbps + 350 Channels HD',
    monthlyAmount: 699,
    setupBoxNo: 'STB-774921',
    ipOrMacAddress: '192.168.10.45 / F4:B8:5E:21:A4:01',
    status: 'ACTIVE',
    connectionDate: '2025-03-15',
    previousDues: 0,
    currentDues: 699,
    totalOutstanding: 699,
    notes: 'Long-time subscriber, fiber wire on pole #14',
    createdAt: '2025-03-15T10:00:00Z',
    updatedAt: '2026-10-01T10:00:00Z',
  },
  {
    id: 'cust-2',
    customerCode: 'CNC-1002',
    name: 'Rajendra Kumar Sahoo',
    mobile: '9861234567',
    address: 'Sahoo Medical Store, Market Chhak',
    area: 'Champeswar Bazar',
    serviceType: 'BROADBAND',
    planName: 'Fiber Super 100Mbps Unlimited',
    monthlyAmount: 799,
    setupBoxNo: '',
    ipOrMacAddress: '192.168.10.88 / 40:8D:5C:12:88:FF',
    status: 'ACTIVE',
    connectionDate: '2025-04-10',
    previousDues: 799,
    currentDues: 799,
    totalOutstanding: 1598,
    notes: 'Commercial connection for medical store billing',
    createdAt: '2025-04-10T10:00:00Z',
    updatedAt: '2026-10-01T10:00:00Z',
  },
  {
    id: 'cust-3',
    customerCode: 'CNC-1003',
    name: 'Manoj Kumar Nayak',
    mobile: '9937891234',
    address: 'House #12, Beside Canal Bridge',
    area: 'Canal Road',
    serviceType: 'CABLE',
    planName: 'Digital Cable Odia Super Pack',
    monthlyAmount: 280,
    setupBoxNo: 'STB-883201',
    ipOrMacAddress: '',
    status: 'ACTIVE',
    connectionDate: '2024-11-20',
    previousDues: 0,
    currentDues: 0,
    totalOutstanding: 0,
    notes: 'Regular on-time payer',
    createdAt: '2024-11-20T10:00:00Z',
    updatedAt: '2026-10-25T10:00:00Z',
  },
  {
    id: 'cust-4',
    customerCode: 'CNC-1004',
    name: 'Prasant Behera',
    mobile: '9777123980',
    address: 'Near Upper Primary School',
    area: 'Nua Sahi',
    serviceType: 'COMBO',
    planName: 'Fiber 40Mbps + Cable Starter',
    monthlyAmount: 550,
    setupBoxNo: 'STB-902144',
    ipOrMacAddress: '192.168.10.104',
    status: 'ACTIVE',
    connectionDate: '2025-01-05',
    previousDues: 250,
    currentDues: 550,
    totalOutstanding: 800,
    notes: 'Partial payment pending from previous cycle',
    createdAt: '2025-01-05T10:00:00Z',
    updatedAt: '2026-10-01T10:00:00Z',
  },
  {
    id: 'cust-5',
    customerCode: 'CNC-1005',
    name: 'Debashis Rout',
    mobile: '9438012345',
    address: 'Quarter #4, Near PHC Hospital',
    area: 'Hospital Road',
    serviceType: 'BROADBAND',
    planName: 'Fiber 60Mbps Home Work',
    monthlyAmount: 499,
    setupBoxNo: '',
    ipOrMacAddress: '192.168.10.142',
    status: 'ACTIVE',
    connectionDate: '2025-06-01',
    previousDues: 0,
    currentDues: 499,
    totalOutstanding: 499,
    notes: 'Doctor clinic connection',
    createdAt: '2025-06-01T10:00:00Z',
    updatedAt: '2026-10-01T10:00:00Z',
  },
  {
    id: 'cust-6',
    customerCode: 'CNC-1006',
    name: 'Susanta Kumar Jena',
    mobile: '9861998877',
    address: 'Opposite Champeswar Degree College',
    area: 'College Road',
    serviceType: 'COMBO',
    planName: 'Fiber 100Mbps + 4K HD Cable',
    monthlyAmount: 899,
    setupBoxNo: 'STB-662309',
    ipOrMacAddress: '192.168.10.198',
    status: 'ACTIVE',
    connectionDate: '2025-02-14',
    previousDues: 0,
    currentDues: 0,
    totalOutstanding: 0,
    notes: 'Paid in advance for 3 months',
    createdAt: '2025-02-14T10:00:00Z',
    updatedAt: '2026-10-18T10:00:00Z',
  },
  {
    id: 'cust-7',
    customerCode: 'CNC-1007',
    name: 'Ramesh Chandra Barik',
    mobile: '9124567890',
    address: 'Barik Sahi, Station Road',
    area: 'Station Chhak',
    serviceType: 'CABLE',
    planName: 'Standard Cable Value Pack',
    monthlyAmount: 250,
    setupBoxNo: 'STB-551102',
    ipOrMacAddress: '',
    status: 'ACTIVE',
    connectionDate: '2024-08-10',
    previousDues: 250,
    currentDues: 250,
    totalOutstanding: 500,
    notes: 'Requested technician to check loose cable connector',
    createdAt: '2024-08-10T10:00:00Z',
    updatedAt: '2026-10-01T10:00:00Z',
  },
  {
    id: 'cust-8',
    customerCode: 'CNC-1008',
    name: 'Pabitra Mohan Das',
    mobile: '9439112233',
    address: 'Weaver Colony, Nuapatna Link',
    area: 'Nuapatna Link',
    serviceType: 'BROADBAND',
    planName: 'Fiber 50Mbps Weavers Special',
    monthlyAmount: 499,
    setupBoxNo: '',
    ipOrMacAddress: '192.168.10.220',
    status: 'ACTIVE',
    connectionDate: '2025-07-20',
    previousDues: 0,
    currentDues: 499,
    totalOutstanding: 499,
    notes: 'Silk handloom online store',
    createdAt: '2025-07-20T10:00:00Z',
    updatedAt: '2026-10-01T10:00:00Z',
  },
  {
    id: 'cust-9',
    customerCode: 'CNC-1009',
    name: 'Gajendra Swain',
    mobile: '9337001122',
    address: 'Near Petrol Pump, Badamba Highway',
    area: 'Badamba Road',
    serviceType: 'CABLE',
    planName: 'Digital Cable Odia Super Pack',
    monthlyAmount: 280,
    setupBoxNo: 'STB-332901',
    ipOrMacAddress: '',
    status: 'INACTIVE',
    connectionDate: '2024-05-12',
    previousDues: 560,
    currentDues: 0,
    totalOutstanding: 560,
    notes: 'Connection temporarily disconnected due to home renovation',
    createdAt: '2024-05-12T10:00:00Z',
    updatedAt: '2026-10-01T10:00:00Z',
  },
  {
    id: 'cust-10',
    customerCode: 'CNC-1010',
    name: 'Subrat Kumar Tripathy',
    mobile: '9853112244',
    address: 'Near Jagannath Temple, Brahmapur Sahi',
    area: 'Brahmapur Sahi',
    serviceType: 'COMBO',
    planName: 'Fiber 75Mbps + All Channels HD',
    monthlyAmount: 799,
    setupBoxNo: 'STB-998124',
    ipOrMacAddress: '192.168.10.74',
    status: 'ACTIVE',
    connectionDate: '2025-03-01',
    previousDues: 0,
    currentDues: 799,
    totalOutstanding: 799,
    notes: 'Family connection, prompt payer',
    createdAt: '2025-03-01T10:00:00Z',
    updatedAt: '2026-10-01T10:00:00Z',
  },
];

const SAMPLE_BILLS: Bill[] = [
  {
    id: 'bill-1',
    billNumber: 'BILL-202611-1001',
    customerId: 'cust-1',
    customerCode: 'CNC-1001',
    customerName: 'Bikash Chandra Mohapatra',
    mobile: '9437123456',
    area: 'Mandir Sahi',
    serviceType: 'COMBO',
    billingMonth: '2026-11',
    planAmount: 699,
    previousDues: 0,
    totalAmount: 699,
    paidAmount: 0,
    balanceDue: 699,
    status: 'UNPAID',
    generatedAt: '2026-11-01T08:00:00Z',
    dueDate: '2026-11-15',
  },
  {
    id: 'bill-2',
    billNumber: 'BILL-202611-1002',
    customerId: 'cust-2',
    customerCode: 'CNC-1002',
    customerName: 'Rajendra Kumar Sahoo',
    mobile: '9861234567',
    area: 'Champeswar Bazar',
    serviceType: 'BROADBAND',
    billingMonth: '2026-11',
    planAmount: 799,
    previousDues: 799,
    totalAmount: 1598,
    paidAmount: 0,
    balanceDue: 1598,
    status: 'UNPAID',
    generatedAt: '2026-11-01T08:00:00Z',
    dueDate: '2026-11-15',
  },
  {
    id: 'bill-3',
    billNumber: 'BILL-202611-1003',
    customerId: 'cust-3',
    customerCode: 'CNC-1003',
    customerName: 'Manoj Kumar Nayak',
    mobile: '9937891234',
    area: 'Canal Road',
    serviceType: 'CABLE',
    billingMonth: '2026-11',
    planAmount: 280,
    previousDues: 0,
    totalAmount: 280,
    paidAmount: 280,
    balanceDue: 0,
    status: 'PAID',
    generatedAt: '2026-11-01T08:00:00Z',
    dueDate: '2026-11-15',
  },
  {
    id: 'bill-4',
    billNumber: 'BILL-202611-1004',
    customerId: 'cust-4',
    customerCode: 'CNC-1004',
    customerName: 'Prasant Behera',
    mobile: '9777123980',
    area: 'Nua Sahi',
    serviceType: 'COMBO',
    billingMonth: '2026-11',
    planAmount: 550,
    previousDues: 250,
    totalAmount: 800,
    paidAmount: 0,
    balanceDue: 800,
    status: 'UNPAID',
    generatedAt: '2026-11-01T08:00:00Z',
    dueDate: '2026-11-15',
  },
  {
    id: 'bill-6',
    billNumber: 'BILL-202611-1006',
    customerId: 'cust-6',
    customerCode: 'CNC-1006',
    customerName: 'Susanta Kumar Jena',
    mobile: '9861998877',
    area: 'College Road',
    serviceType: 'COMBO',
    billingMonth: '2026-11',
    planAmount: 899,
    previousDues: 0,
    totalAmount: 899,
    paidAmount: 899,
    balanceDue: 0,
    status: 'PAID',
    generatedAt: '2026-11-01T08:00:00Z',
    dueDate: '2026-11-15',
  },
];

const SAMPLE_PAYMENTS: Payment[] = [
  {
    id: 'pay-1',
    receiptNo: 'RCP-2026-1001',
    billId: 'bill-3',
    customerId: 'cust-3',
    customerCode: 'CNC-1003',
    customerName: 'Manoj Kumar Nayak',
    mobile: '9937891234',
    amount: 280,
    paymentMethod: 'CASH',
    paymentDate: '2026-11-01',
    billingMonth: '2026-11',
    collectedBy: 'Sanjay Panda (Owner)',
    notes: 'Cash collected during field visit at Canal Road',
    createdAt: '2026-11-01T11:30:00Z',
  },
  {
    id: 'pay-2',
    receiptNo: 'RCP-2026-1002',
    billId: 'bill-6',
    customerId: 'cust-6',
    customerCode: 'CNC-1006',
    customerName: 'Susanta Kumar Jena',
    mobile: '9861998877',
    amount: 899,
    paymentMethod: 'UPI',
    upiRefNo: 'UPI/430198273641/PhonePe',
    paymentDate: '2026-11-01',
    billingMonth: '2026-11',
    collectedBy: 'Auto QR System',
    notes: 'Paid via PhonePe QR scanner',
    createdAt: '2026-11-01T14:15:00Z',
  },
];

class StorageService {
  private getStorageItem<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      if (!data) return defaultValue;
      return JSON.parse(data) as T;
    } catch (err) {
      console.warn(`Failed reading ${key} from storage:`, err);
      return defaultValue;
    }
  }

  private setStorageItem<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (err) {
      console.error(`Failed saving ${key} to storage:`, err);
    }
  }

  // Customers
  getCustomers(): Customer[] {
    const data = this.getStorageItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, []);
    if (data.length === 0) {
      this.setStorageItem(STORAGE_KEYS.CUSTOMERS, SAMPLE_CUSTOMERS);
      return SAMPLE_CUSTOMERS;
    }
    return data;
  }

  saveCustomer(customer: Customer): Customer {
    const list = this.getCustomers();
    const existingIndex = list.findIndex(c => c.id === customer.id || c.customerCode === customer.customerCode);
    
    // Auto recalculate balance
    customer.totalOutstanding = Number(customer.previousDues || 0) + Number(customer.currentDues || 0);
    customer.updatedAt = new Date().toISOString();

    if (existingIndex >= 0) {
      list[existingIndex] = customer;
    } else {
      list.unshift(customer);
    }
    this.setStorageItem(STORAGE_KEYS.CUSTOMERS, list);
    return customer;
  }

  deleteCustomer(customerId: string): boolean {
    const list = this.getCustomers();
    const filtered = list.filter(c => c.id !== customerId);
    this.setStorageItem(STORAGE_KEYS.CUSTOMERS, filtered);
    return true;
  }

  getNextCustomerCode(): string {
    const list = this.getCustomers();
    let maxNum = 1000;
    list.forEach(c => {
      const match = c.customerCode.match(/CNC-(\d+)/i);
      if (match && match[1]) {
        const num = parseInt(match[1], 10);
        if (num > maxNum) maxNum = num;
      }
    });
    return `CNC-${maxNum + 1}`;
  }

  // Bills
  getBills(): Bill[] {
    const data = this.getStorageItem<Bill[]>(STORAGE_KEYS.BILLS, []);
    if (data.length === 0) {
      this.setStorageItem(STORAGE_KEYS.BILLS, SAMPLE_BILLS);
      return SAMPLE_BILLS;
    }
    return data;
  }

  getBillsForMonth(billingMonth: string): Bill[] {
    return this.getBills().filter(b => b.billingMonth === billingMonth);
  }

  saveBill(bill: Bill): Bill {
    const list = this.getBills();
    const index = list.findIndex(b => b.id === bill.id);
    if (index >= 0) {
      list[index] = bill;
    } else {
      list.unshift(bill);
    }
    this.setStorageItem(STORAGE_KEYS.BILLS, list);
    return bill;
  }

  // Automatic monthly bill generator
  generateMonthlyBills(billingMonth: string): { generatedCount: number; updatedCount: number } {
    const customers = this.getCustomers().filter(c => c.status === 'ACTIVE');
    const existingBills = this.getBills();
    let generatedCount = 0;
    let updatedCount = 0;

    customers.forEach(cust => {
      const existing = existingBills.find(b => b.customerId === cust.id && b.billingMonth === billingMonth);
      if (existing) {
        // already exists
        updatedCount++;
      } else {
        const prevDues = cust.totalOutstanding > 0 ? cust.totalOutstanding : cust.previousDues;
        const total = prevDues + cust.monthlyAmount;
        const billNumber = `BILL-${billingMonth.replace('-', '')}-${cust.customerCode.replace(/[^0-9]/g, '')}`;
        
        const newBill: Bill = {
          id: `bill-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          billNumber,
          customerId: cust.id,
          customerCode: cust.customerCode,
          customerName: cust.name,
          mobile: cust.mobile,
          area: cust.area,
          serviceType: cust.serviceType,
          billingMonth,
          planAmount: cust.monthlyAmount,
          previousDues: prevDues,
          totalAmount: total,
          paidAmount: 0,
          balanceDue: total,
          status: 'UNPAID',
          generatedAt: new Date().toISOString(),
          dueDate: `${billingMonth}-15`,
        };
        existingBills.unshift(newBill);
        generatedCount++;

        // Update customer current balance
        cust.currentDues = cust.monthlyAmount;
        cust.totalOutstanding = cust.previousDues + cust.currentDues;
        this.saveCustomer(cust);
      }
    });

    this.setStorageItem(STORAGE_KEYS.BILLS, existingBills);
    return { generatedCount, updatedCount };
  }

  // Payments
  getPayments(): Payment[] {
    const data = this.getStorageItem<Payment[]>(STORAGE_KEYS.PAYMENTS, []);
    if (data.length === 0) {
      this.setStorageItem(STORAGE_KEYS.PAYMENTS, SAMPLE_PAYMENTS);
      return SAMPLE_PAYMENTS;
    }
    return data;
  }

  getNextReceiptNo(): string {
    const currentYear = new Date().getFullYear();
    const payments = this.getPayments();
    let max = 1000;
    payments.forEach(p => {
      const match = p.receiptNo.match(/RCP-\d+-(\d+)/i);
      if (match && match[1]) {
        const num = parseInt(match[1], 10);
        if (num > max) max = num;
      }
    });
    return `RCP-${currentYear}-${max + 1}`;
  }

  recordPayment(params: {
    customerId: string;
    billId?: string;
    amount: number;
    paymentMethod: 'CASH' | 'UPI';
    upiRefNo?: string;
    billingMonth: string;
    collectedBy: string;
    notes?: string;
    paymentDate?: string;
  }): { payment: Payment; updatedBill?: Bill; updatedCustomer: Customer } {
    const customers = this.getCustomers();
    const customer = customers.find(c => c.id === params.customerId);
    if (!customer) throw new Error('Customer not found');

    const receiptNo = this.getNextReceiptNo();
    const paymentDate = params.paymentDate || new Date().toISOString().split('T')[0];

    const payment: Payment = {
      id: `pay-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      receiptNo,
      billId: params.billId,
      customerId: customer.id,
      customerCode: customer.customerCode,
      customerName: customer.name,
      mobile: customer.mobile,
      amount: Number(params.amount),
      paymentMethod: params.paymentMethod,
      upiRefNo: params.upiRefNo,
      paymentDate,
      billingMonth: params.billingMonth,
      collectedBy: params.collectedBy,
      notes: params.notes,
      createdAt: new Date().toISOString(),
    };

    // Save payment
    const payments = this.getPayments();
    payments.unshift(payment);
    this.setStorageItem(STORAGE_KEYS.PAYMENTS, payments);

    // Update Bill if linked
    let updatedBill: Bill | undefined;
    if (params.billId) {
      const bills = this.getBills();
      const billIndex = bills.findIndex(b => b.id === params.billId);
      if (billIndex >= 0) {
        const bill = bills[billIndex];
        const newPaid = Number(bill.paidAmount || 0) + Number(params.amount);
        bill.paidAmount = newPaid;
        bill.balanceDue = Math.max(0, bill.totalAmount - newPaid);
        if (bill.balanceDue <= 0) {
          bill.status = 'PAID';
        } else if (newPaid > 0) {
          bill.status = 'PARTIAL';
        }
        bills[billIndex] = bill;
        updatedBill = bill;
        this.setStorageItem(STORAGE_KEYS.BILLS, bills);
      }
    }

    // Update Customer outstanding balance
    const currentOutstanding = customer.totalOutstanding;
    const newOutstanding = Math.max(0, currentOutstanding - Number(params.amount));
    customer.totalOutstanding = newOutstanding;
    if (customer.totalOutstanding === 0) {
      customer.previousDues = 0;
      customer.currentDues = 0;
    } else {
      customer.currentDues = Math.min(customer.currentDues, newOutstanding);
      customer.previousDues = Math.max(0, newOutstanding - customer.currentDues);
    }
    this.saveCustomer(customer);

    return { payment, updatedBill, updatedCustomer: customer };
  }

  // Business Profile
  getProfile(): BusinessProfile {
    return this.getStorageItem<BusinessProfile>(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE);
  }

  saveProfile(profile: BusinessProfile): void {
    this.setStorageItem(STORAGE_KEYS.PROFILE, profile);
  }

  // Supabase Configuration
  getSupabaseConfig(): SupabaseConfig {
    return this.getStorageItem<SupabaseConfig>(STORAGE_KEYS.SUPABASE, {
      url: '',
      anonKey: '',
      isConnected: false,
      autoSync: false,
    });
  }

  saveSupabaseConfig(cfg: SupabaseConfig): void {
    this.setStorageItem(STORAGE_KEYS.SUPABASE, cfg);
  }

  // Active Billing Month
  getActiveMonth(): string {
    const now = new Date();
    const def = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    return this.getStorageItem<string>(STORAGE_KEYS.ACTIVE_MONTH, def);
  }

  setActiveMonth(month: string): void {
    this.setStorageItem(STORAGE_KEYS.ACTIVE_MONTH, month);
  }

  // Admin PIN (Default: 1234)
  getAdminPin(): string {
    return this.getStorageItem<string>(STORAGE_KEYS.ADMIN_PIN, '1234');
  }

  setAdminPin(newPin: string): void {
    this.setStorageItem(STORAGE_KEYS.ADMIN_PIN, newPin);
  }

  // Language
  getLanguage(): 'en' | 'or' | 'hi' {
    return this.getStorageItem<'en' | 'or' | 'hi'>(STORAGE_KEYS.LANGUAGE, 'en');
  }

  setLanguage(lang: 'en' | 'or' | 'hi'): void {
    this.setStorageItem(STORAGE_KEYS.LANGUAGE, lang);
  }

  // Full Database Backup & Restore
  exportAllDataJson(): string {
    const payload = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      appName: 'CCTV NETWORK CHAMPESWAR',
      customers: this.getCustomers(),
      bills: this.getBills(),
      payments: this.getPayments(),
      profile: this.getProfile(),
    };
    return JSON.stringify(payload, null, 2);
  }

  restoreAllDataJson(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (Array.isArray(data.customers)) {
        this.setStorageItem(STORAGE_KEYS.CUSTOMERS, data.customers);
      }
      if (Array.isArray(data.bills)) {
        this.setStorageItem(STORAGE_KEYS.BILLS, data.bills);
      }
      if (Array.isArray(data.payments)) {
        this.setStorageItem(STORAGE_KEYS.PAYMENTS, data.payments);
      }
      if (data.profile) {
        this.setStorageItem(STORAGE_KEYS.PROFILE, data.profile);
      }
      return true;
    } catch (e) {
      console.error('Failed to restore data:', e);
      return false;
    }
  }

  resetToDefaultSample(): void {
    this.setStorageItem(STORAGE_KEYS.CUSTOMERS, SAMPLE_CUSTOMERS);
    this.setStorageItem(STORAGE_KEYS.BILLS, SAMPLE_BILLS);
    this.setStorageItem(STORAGE_KEYS.PAYMENTS, SAMPLE_PAYMENTS);
    this.setStorageItem(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE);
  }
}

export const storage = new StorageService();
