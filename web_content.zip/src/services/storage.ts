import {
  User,
  WorkArea,
  TaskTemplate,
  TaskRecord,
  ShortageItem,
  ShiftHandover,
  ActivityLogEntry,
} from '../types';

const STORAGE_KEYS = {
  AREAS: 'resto_areas_v1',
  USERS: 'resto_users_v1',
  TASK_TEMPLATES: 'resto_task_templates_v1',
  TASK_RECORDS: 'resto_task_records_v1',
  SHORTAGES: 'resto_shortages_v1',
  HANDOVERS: 'resto_handovers_v1',
  ACTIVITY_LOGS: 'resto_logs_v1',
};

// Helper date/time formatting in Spanish local format
export function getFormattedDate(d = new Date()): string {
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}/${month}/${year}`;
}

export function getFormattedTime(d = new Date()): string {
  return d.toLocaleTimeString('es-MX', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
}

// Initial Seed Data
const DEFAULT_AREAS: WorkArea[] = [
  { id: 'cocina', name: 'Cocina', iconName: 'Utensils', color: 'orange' },
  { id: 'mesa_fria', name: 'Mesa fría', iconName: 'Salad', color: 'emerald' },
  { id: 'meseros', name: 'Meseros', iconName: 'Users', color: 'blue' },
  { id: 'barra', name: 'Barra', iconName: 'Wine', color: 'purple' },
  { id: 'lavaloza', name: 'Lavaloza', iconName: 'Sparkles', color: 'cyan' },
  { id: 'caja', name: 'Caja', iconName: 'Receipt', color: 'amber' },
  { id: 'almacen', name: 'Almacén', iconName: 'Boxes', color: 'slate' },
];

const DEFAULT_USERS: User[] = [
  {
    id: 'admin-1',
    name: 'Administrador (Gerencia)',
    username: 'admin',
    password: 'admin123',
    role: 'ADMIN',
    areaId: 'todas',
    areaName: 'Todas las áreas',
    shift: 'General',
    active: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'emp-carlos',
    name: 'Carlos Méndez',
    username: 'carlos',
    password: '123',
    role: 'EMPLEADO',
    areaId: 'cocina',
    areaName: 'Cocina',
    shift: 'Turno 1',
    active: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'emp-lucia',
    name: 'Lucía Pérez',
    username: 'lucia',
    password: '123',
    role: 'EMPLEADO',
    areaId: 'cocina',
    areaName: 'Cocina',
    shift: 'Turno 2',
    active: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'emp-sofia',
    name: 'Sofía Castro',
    username: 'sofia',
    password: '123',
    role: 'EMPLEADO',
    areaId: 'meseros',
    areaName: 'Meseros',
    shift: 'Turno 1',
    active: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'emp-miguel',
    name: 'Miguel Ángel',
    username: 'miguel',
    password: '123',
    role: 'EMPLEADO',
    areaId: 'barra',
    areaName: 'Barra',
    shift: 'Turno 1',
    active: true,
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_TEMPLATES: TaskTemplate[] = [
  // Cocina
  {
    id: 't-cocina-1',
    areaId: 'cocina',
    title: 'Preparar arroz',
    description: 'Cocinar 2 ollas de arroz para el servicio de comida',
    shiftTarget: 'Todos',
    priority: 'Alta',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-cocina-2',
    areaId: 'cocina',
    title: 'Preparar salsa roja y verde',
    description: 'Dejar listas 3 salseras llenas en línea de ensamble',
    shiftTarget: 'Todos',
    priority: 'Alta',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-cocina-3',
    areaId: 'cocina',
    title: 'Revisar refrigeradores y temperaturas',
    description: 'Anotar temperatura de cámaras de conservación (< 4°C)',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-cocina-4',
    areaId: 'cocina',
    title: 'Limpiar y sanitizar área de preparación',
    description: 'Mesas de acero inoxidable y tablas desinfectadas',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-cocina-5',
    areaId: 'cocina',
    title: 'Revisar existencia de camarón',
    description: 'Verificar gramaje descongelado y lote fresco en cámara',
    shiftTarget: 'Todos',
    priority: 'Urgente',
    createdAt: new Date().toISOString(),
  },

  // Mesa fría
  {
    id: 't-fria-1',
    areaId: 'mesa_fria',
    title: 'Revisar temperatura de mesa fría',
    description: 'Mantener entre 2°C y 5°C con termómetro testigo',
    shiftTarget: 'Todos',
    priority: 'Alta',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-fria-2',
    areaId: 'mesa_fria',
    title: 'Picar verdura para mise en place',
    description: 'Cebolla morada, pepino, cilantro y aguacate fresco',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-fria-3',
    areaId: 'mesa_fria',
    title: 'Rotular insumos preparados con fecha de lote',
    description: 'Etiquetas con día, hora y nombre de preparador',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },

  // Meseros
  {
    id: 't-meseros-1',
    areaId: 'meseros',
    title: 'Montar mesas y checar servilleteros',
    description: 'Comprobar saleros, pimenteros y servilletas llenas',
    shiftTarget: 'Todos',
    priority: 'Alta',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-meseros-2',
    areaId: 'meseros',
    title: 'Revisar cartas y menús limpios',
    description: 'Desinfectar cubiertas de menús y códigos QR',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-meseros-3',
    areaId: 'meseros',
    title: 'Rellenar estaciones de cubiertos y condimentos',
    description: 'Tener listos 50 juegos de tenedor y cuchillo fajados',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },

  // Barra
  {
    id: 't-barra-1',
    areaId: 'barra',
    title: 'Inventario de botellas abiertas y licores',
    description: 'Cotejar niveles de botellas de velocidad',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-barra-2',
    areaId: 'barra',
    title: 'Preparar jarabes e insumos cítricos frescos',
    description: 'Jugo de limón natural y jarabe natural',
    shiftTarget: 'Todos',
    priority: 'Alta',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-barra-3',
    areaId: 'barra',
    title: 'Limpiar y desinfectar cristalería',
    description: 'Copas pulidas sin marcas de agua',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },

  // Lavaloza
  {
    id: 't-lavaloza-1',
    areaId: 'lavaloza',
    title: 'Revisar nivel de químicos en máquina lavalozas',
    description: 'Detergente, abrillantador y sanitizante',
    shiftTarget: 'Todos',
    priority: 'Alta',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-lavaloza-2',
    areaId: 'lavaloza',
    title: 'Limpiar trampa de grasa al final del turno',
    description: 'Retirar sólidos y desengrasar con agua caliente',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },

  // Caja
  {
    id: 't-caja-1',
    areaId: 'caja',
    title: 'Arqueo de fondo inicial de caja',
    description: 'Comprobar cambio en billetes pequeños y monedas',
    shiftTarget: 'Todos',
    priority: 'Alta',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-caja-2',
    areaId: 'caja',
    title: 'Verificar rollos de terminal bancaria e impresora',
    description: 'Tener al menos 2 rollos de repuesto',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },

  // Almacén
  {
    id: 't-almacen-1',
    areaId: 'almacen',
    title: 'Recepción de proveedores y cotejo de facturas',
    description: 'Pesar producto fresco y verificar sellos',
    shiftTarget: 'Todos',
    priority: 'Alta',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't-almacen-2',
    areaId: 'almacen',
    title: 'Revisar caducidades en anaqueles secos',
    description: 'Aplicar sistema PEPS (Primeras entradas, primeras salidas)',
    shiftTarget: 'Todos',
    priority: 'Normal',
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_SHORTAGES: ShortageItem[] = [
  {
    id: 'shortage-1',
    product: 'Camarón 21/25',
    quantity: '3 kg',
    comment: 'Se terminó durante el turno matutino por alta demanda de ceviches.',
    reportedByUserId: 'emp-carlos',
    reportedByName: 'Carlos Méndez',
    areaId: 'cocina',
    areaName: 'Cocina',
    shift: 'Turno 1',
    date: getFormattedDate(),
    time: '01:45 PM',
    status: 'Pendiente',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
  },
  {
    id: 'shortage-2',
    product: 'Servilletas de mesa',
    quantity: '5 paquetes',
    comment: 'Stock bajo en piso y bodega de meseros.',
    reportedByUserId: 'emp-sofia',
    reportedByName: 'Sofía Castro',
    areaId: 'meseros',
    areaName: 'Meseros',
    shift: 'Turno 1',
    date: getFormattedDate(),
    time: '02:15 PM',
    status: 'Pendiente',
    createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
  },
];

const DEFAULT_RECORDS: TaskRecord[] = [
  {
    id: 'rec-1',
    templateId: 't-cocina-1',
    title: 'Preparar arroz',
    areaId: 'cocina',
    areaName: 'Cocina',
    status: 'realizada',
    shift: 'Turno 1',
    date: getFormattedDate(),
    time: '02:35 PM',
    completedByUserId: 'emp-carlos',
    completedByName: 'Carlos Méndez',
    completedAt: new Date(Date.now() - 1000 * 60 * 70).toISOString(),
  },
  {
    id: 'rec-2',
    templateId: 't-cocina-2',
    title: 'Preparar salsa roja y verde',
    areaId: 'cocina',
    areaName: 'Cocina',
    status: 'pendiente',
    shift: 'Turno 1',
    date: getFormattedDate(),
    time: '02:45 PM',
    pendingReason: 'No se alcanzó a realizar durante el turno por afluencia pico.',
    pendingReportedByUserId: 'emp-carlos',
    pendingReportedByName: 'Carlos Méndez',
  },
];

const DEFAULT_HANDOVERS: ShiftHandover[] = [
  {
    id: 'handover-1',
    areaId: 'cocina',
    areaName: 'Cocina',
    fromShift: 'Turno 1',
    employeeId: 'emp-carlos',
    employeeName: 'Carlos Méndez',
    date: getFormattedDate(),
    time: '03:00 PM',
    completedTasksSummary: ['Preparar arroz', 'Revisar refrigeradores'],
    pendingTasksSummary: [
      {
        title: 'Preparar salsa roja y verde',
        reason: 'No se alcanzó a realizar durante el turno por afluencia pico.',
      },
    ],
    shortagesSummary: [
      {
        product: 'Camarón 21/25',
        quantity: '3 kg',
      },
    ],
    observations: 'Revisar la cámara 2 porque el termostato bajó un poco lento. Dejé cebollas ya peladas.',
    createdAt: new Date(Date.now() - 1000 * 60 * 50).toISOString(),
  },
];

const DEFAULT_LOGS: ActivityLogEntry[] = [
  {
    id: 'log-1',
    type: 'TAREA_REALIZADA',
    employeeName: 'Carlos Méndez',
    area: 'Cocina',
    shift: 'Turno 1',
    task: 'Preparar arroz',
    status: 'Realizada',
    details: 'Marcada como completada con éxito',
    date: getFormattedDate(),
    time: '02:35 PM',
    timestamp: Date.now() - 1000 * 60 * 70,
  },
  {
    id: 'log-2',
    type: 'TAREA_PENDIENTE',
    employeeName: 'Carlos Méndez',
    area: 'Cocina',
    shift: 'Turno 1',
    task: 'Preparar salsa roja y verde',
    status: 'Pendiente',
    details: 'Motivo: No se alcanzó a realizar durante el turno por afluencia pico.',
    date: getFormattedDate(),
    time: '02:45 PM',
    timestamp: Date.now() - 1000 * 60 * 60,
  },
  {
    id: 'log-3',
    type: 'FALTANTE_REPORTADO',
    employeeName: 'Carlos Méndez',
    area: 'Cocina',
    shift: 'Turno 1',
    task: 'Faltante de insumo',
    status: 'Pendiente',
    details: 'Producto: Camarón 21/25 (3 kg) - Se terminó durante el turno matutino',
    date: getFormattedDate(),
    time: '01:45 PM',
    timestamp: Date.now() - 1000 * 60 * 120,
  },
  {
    id: 'log-4',
    type: 'FALTANTE_REPORTADO',
    employeeName: 'Sofía Castro',
    area: 'Meseros',
    shift: 'Turno 1',
    task: 'Faltante de insumo',
    status: 'Pendiente',
    details: 'Producto: Servilletas de mesa (5 paquetes) - Stock bajo en piso',
    date: getFormattedDate(),
    time: '02:15 PM',
    timestamp: Date.now() - 1000 * 60 * 90,
  },
  {
    id: 'log-5',
    type: 'CAMBIO_TURNO',
    employeeName: 'Carlos Méndez',
    area: 'Cocina',
    shift: 'Turno 1',
    task: 'Entrega de turno',
    status: 'Entregado',
    details: 'Turno 1 entregado con 1 tarea pendiente y 1 faltante reportado',
    date: getFormattedDate(),
    time: '03:00 PM',
    timestamp: Date.now() - 1000 * 60 * 50,
  },
];

// Reactive broadcaster
const EVENT_NAME = 'resto_data_mutation';
function notifyChange() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(EVENT_NAME));
  }
}

export function subscribeToData(callback: () => void) {
  if (typeof window === 'undefined') return () => {};
  window.addEventListener(EVENT_NAME, callback);
  return () => {
    window.removeEventListener(EVENT_NAME, callback);
  };
}

// LocalStorage helpers with type safety
function getStored<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) {
      localStorage.setItem(key, JSON.stringify(fallback));
      return fallback;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Error reading ${key} from storage:`, err);
    return fallback;
  }
}

function setStored<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
    notifyChange();
  } catch (err) {
    console.error(`Error saving ${key} to storage:`, err);
  }
}

// Data Service
export const storageService = {
  // Areas
  getAreas(): WorkArea[] {
    return getStored<WorkArea[]>(STORAGE_KEYS.AREAS, DEFAULT_AREAS);
  },

  addArea(name: string): WorkArea {
    const areas = this.getAreas();
    const id = name.toLowerCase().trim().replace(/[^a-z0-9]/g, '_') + '_' + Date.now();
    const newArea: WorkArea = {
      id,
      name: name.trim(),
      color: 'orange',
    };
    const updated = [...areas, newArea];
    setStored(STORAGE_KEYS.AREAS, updated);
    return newArea;
  },

  deleteArea(areaId: string): void {
    const areas = this.getAreas().filter((a) => a.id !== areaId);
    setStored(STORAGE_KEYS.AREAS, areas);
  },

  // Users
  getUsers(): User[] {
    return getStored<User[]>(STORAGE_KEYS.USERS, DEFAULT_USERS);
  },

  getUserById(id: string): User | undefined {
    return this.getUsers().find((u) => u.id === id);
  },

  addUser(userData: Omit<User, 'id' | 'createdAt'>): User {
    const users = this.getUsers();
    const newUser: User = {
      ...userData,
      id: 'usr_' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setStored(STORAGE_KEYS.USERS, [...users, newUser]);

    this.addLog({
      type: 'EMPLEADO_CREADO',
      employeeName: userData.name,
      area: userData.areaName || 'General',
      shift: userData.shift,
      status: 'Registrado',
      details: `Empleado creado con usuario "${userData.username}" en ${userData.areaName || 'Área general'} (${userData.shift})`,
    });

    return newUser;
  },

  updateUser(id: string, updates: Partial<User>): User | null {
    const users = this.getUsers();
    const index = users.findIndex((u) => u.id === id);
    if (index === -1) return null;
    users[index] = { ...users[index], ...updates };
    setStored(STORAGE_KEYS.USERS, users);
    return users[index];
  },

  deleteUser(id: string): void {
    const users = this.getUsers().filter((u) => u.id !== id);
    setStored(STORAGE_KEYS.USERS, users);
  },

  authenticate(username: string, pass: string): User | null {
    const users = this.getUsers();
    const user = users.find(
      (u) =>
        u.username.trim().toLowerCase() === username.trim().toLowerCase() &&
        u.password === pass &&
        u.active
    );
    return user || null;
  },

  // Task Templates (Only Admin)
  getTaskTemplates(): TaskTemplate[] {
    return getStored<TaskTemplate[]>(STORAGE_KEYS.TASK_TEMPLATES, DEFAULT_TEMPLATES);
  },

  addTaskTemplate(template: Omit<TaskTemplate, 'id' | 'createdAt'>, adminUser: User): TaskTemplate {
    const templates = this.getTaskTemplates();
    const areas = this.getAreas();
    const area = areas.find((a) => a.id === template.areaId);

    const newTemplate: TaskTemplate = {
      ...template,
      id: 'tmpl_' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setStored(STORAGE_KEYS.TASK_TEMPLATES, [...templates, newTemplate]);

    this.addLog({
      type: 'TAREA_CREADA',
      employeeName: adminUser.name,
      area: area?.name || template.areaId,
      shift: template.shiftTarget || 'Todos',
      task: template.title,
      status: 'Creada',
      details: `Nueva tarea asignada al área ${area?.name || template.areaId}: "${template.title}"`,
    });

    return newTemplate;
  },

  updateTaskTemplate(id: string, updates: Partial<TaskTemplate>): TaskTemplate | null {
    const templates = this.getTaskTemplates();
    const idx = templates.findIndex((t) => t.id === id);
    if (idx === -1) return null;
    templates[idx] = { ...templates[idx], ...updates };
    setStored(STORAGE_KEYS.TASK_TEMPLATES, templates);
    return templates[idx];
  },

  deleteTaskTemplate(id: string): void {
    const templates = this.getTaskTemplates().filter((t) => t.id !== id);
    setStored(STORAGE_KEYS.TASK_TEMPLATES, templates);
  },

  // Task Records (Executions)
  getTaskRecords(): TaskRecord[] {
    return getStored<TaskRecord[]>(STORAGE_KEYS.TASK_RECORDS, DEFAULT_RECORDS);
  },

  // Mark task as done
  markTaskDone(template: TaskTemplate, user: User): TaskRecord {
    const records = this.getTaskRecords();
    const date = getFormattedDate();
    const time = getFormattedTime();

    // Check if record already exists for this template on this date and shift
    const existingIndex = records.findIndex(
      (r) => r.templateId === template.id && r.date === date && r.shift === user.shift
    );

    let updatedRecord: TaskRecord;

    if (existingIndex >= 0) {
      updatedRecord = {
        ...records[existingIndex],
        status: 'realizada',
        completedByUserId: user.id,
        completedByName: user.name,
        completedAt: new Date().toISOString(),
        time,
      };
      records[existingIndex] = updatedRecord;
    } else {
      updatedRecord = {
        id: 'rec_' + Date.now(),
        templateId: template.id,
        title: template.title,
        areaId: user.areaId,
        areaName: user.areaName || 'Área',
        status: 'realizada',
        shift: user.shift,
        date,
        time,
        completedByUserId: user.id,
        completedByName: user.name,
        completedAt: new Date().toISOString(),
      };
      records.push(updatedRecord);
    }

    setStored(STORAGE_KEYS.TASK_RECORDS, records);

    this.addLog({
      type: 'TAREA_REALIZADA',
      employeeName: user.name,
      employeeId: user.id,
      area: user.areaName || 'Área',
      shift: user.shift,
      task: template.title,
      status: 'Realizada',
      details: `Completada por ${user.name} a las ${time}`,
      date,
      time,
    });

    return updatedRecord;
  },

  // Mark task as pending with required reason
  markTaskPending(template: TaskTemplate, user: User, reason: string): TaskRecord {
    const records = this.getTaskRecords();
    const date = getFormattedDate();
    const time = getFormattedTime();

    const existingIndex = records.findIndex(
      (r) => r.templateId === template.id && r.date === date && r.shift === user.shift
    );

    let updatedRecord: TaskRecord;

    if (existingIndex >= 0) {
      updatedRecord = {
        ...records[existingIndex],
        status: 'pendiente',
        pendingReason: reason,
        pendingReportedByUserId: user.id,
        pendingReportedByName: user.name,
        time,
      };
      records[existingIndex] = updatedRecord;
    } else {
      updatedRecord = {
        id: 'rec_' + Date.now(),
        templateId: template.id,
        title: template.title,
        areaId: user.areaId,
        areaName: user.areaName || 'Área',
        status: 'pendiente',
        shift: user.shift,
        date,
        time,
        pendingReason: reason,
        pendingReportedByUserId: user.id,
        pendingReportedByName: user.name,
      };
      records.push(updatedRecord);
    }

    setStored(STORAGE_KEYS.TASK_RECORDS, records);

    this.addLog({
      type: 'TAREA_PENDIENTE',
      employeeName: user.name,
      employeeId: user.id,
      area: user.areaName || 'Área',
      shift: user.shift,
      task: template.title,
      status: 'Pendiente',
      details: `Motivo: ${reason}`,
      date,
      time,
    });

    return updatedRecord;
  },

  // Complete a pending task left from a previous shift
  resolvePreviousShiftPending(recordId: string, user: User): TaskRecord | null {
    const records = this.getTaskRecords();
    const idx = records.findIndex((r) => r.id === recordId);
    if (idx === -1) return null;

    const date = getFormattedDate();
    const time = getFormattedTime();

    records[idx] = {
      ...records[idx],
      status: 'realizada',
      resolvedInNextShift: true,
      resolvedByUserId: user.id,
      resolvedByName: user.name,
      resolvedShift: user.shift,
      resolvedDate: date,
      resolvedTime: time,
      resolvedAt: new Date().toISOString(),
    };

    setStored(STORAGE_KEYS.TASK_RECORDS, records);

    this.addLog({
      type: 'PENDIENTE_RESUELTO',
      employeeName: user.name,
      employeeId: user.id,
      area: user.areaName || records[idx].areaName,
      shift: user.shift,
      task: records[idx].title,
      status: 'Resuelta en Siguiente Turno',
      details: `Pendiente dejado por ${records[idx].pendingReportedByName || records[idx].shift} resuelto por ${user.name} (${user.shift}) a las ${time}`,
      date,
      time,
    });

    return records[idx];
  },

  // Shortages (Faltantes)
  getShortages(): ShortageItem[] {
    return getStored<ShortageItem[]>(STORAGE_KEYS.SHORTAGES, DEFAULT_SHORTAGES);
  },

  reportShortage(
    data: { product: string; quantity: string; comment: string },
    user: User
  ): ShortageItem {
    const shortages = this.getShortages();
    const date = getFormattedDate();
    const time = getFormattedTime();

    const newShortage: ShortageItem = {
      id: 'shortage_' + Date.now(),
      product: data.product.trim(),
      quantity: data.quantity.trim(),
      comment: data.comment.trim(),
      reportedByUserId: user.id,
      reportedByName: user.name,
      areaId: user.areaId,
      areaName: user.areaName || 'Área',
      shift: user.shift,
      date,
      time,
      status: 'Pendiente',
      createdAt: new Date().toISOString(),
    };

    setStored(STORAGE_KEYS.SHORTAGES, [newShortage, ...shortages]);

    this.addLog({
      type: 'FALTANTE_REPORTADO',
      employeeName: user.name,
      employeeId: user.id,
      area: user.areaName || 'Área',
      shift: user.shift,
      task: 'Faltante reportado',
      status: 'Pendiente',
      details: `Producto: ${newShortage.product} (${newShortage.quantity}) - ${newShortage.comment || 'Sin comentarios'}`,
      date,
      time,
    });

    return newShortage;
  },

  // Only Admin can mark shortage as purchased / pending
  updateShortageStatus(
    id: string,
    status: 'Pendiente' | 'Comprado',
    adminUser: User
  ): ShortageItem | null {
    const shortages = this.getShortages();
    const idx = shortages.findIndex((s) => s.id === id);
    if (idx === -1) return null;

    shortages[idx] = {
      ...shortages[idx],
      status,
      purchasedAt: status === 'Comprado' ? new Date().toISOString() : undefined,
      purchasedByName: status === 'Comprado' ? adminUser.name : undefined,
    };

    setStored(STORAGE_KEYS.SHORTAGES, shortages);

    if (status === 'Comprado') {
      this.addLog({
        type: 'COMPRA_REALIZADA',
        employeeName: adminUser.name,
        area: shortages[idx].areaName,
        shift: 'Administración',
        task: 'Compra de faltante',
        status: 'Comprado',
        details: `Producto marcado como comprado: ${shortages[idx].product} (${shortages[idx].quantity})`,
      });
    }

    return shortages[idx];
  },

  // Shift Handovers
  getShiftHandovers(): ShiftHandover[] {
    return getStored<ShiftHandover[]>(STORAGE_KEYS.HANDOVERS, DEFAULT_HANDOVERS);
  },

  saveShiftHandover(
    data: {
      observations: string;
      completedTasksSummary: string[];
      pendingTasksSummary: { title: string; reason: string }[];
      shortagesSummary: { product: string; quantity: string }[];
    },
    user: User
  ): ShiftHandover {
    const handovers = this.getShiftHandovers();
    const date = getFormattedDate();
    const time = getFormattedTime();

    const newHandover: ShiftHandover = {
      id: 'handover_' + Date.now(),
      areaId: user.areaId,
      areaName: user.areaName || 'Área',
      fromShift: user.shift,
      employeeId: user.id,
      employeeName: user.name,
      date,
      time,
      completedTasksSummary: data.completedTasksSummary,
      pendingTasksSummary: data.pendingTasksSummary,
      shortagesSummary: data.shortagesSummary,
      observations: data.observations.trim(),
      createdAt: new Date().toISOString(),
    };

    setStored(STORAGE_KEYS.HANDOVERS, [newHandover, ...handovers]);

    this.addLog({
      type: 'CAMBIO_TURNO',
      employeeName: user.name,
      employeeId: user.id,
      area: user.areaName || 'Área',
      shift: user.shift,
      task: 'Entrega de Turno',
      status: 'Entregado',
      details: `${user.name} entregó su turno. ${data.completedTasksSummary.length} tareas realizadas, ${data.pendingTasksSummary.length} pendientes. Nota: "${data.observations || 'Sin observaciones'}"`,
      date,
      time,
    });

    return newHandover;
  },

  // Activity Logs
  getActivityLogs(): ActivityLogEntry[] {
    return getStored<ActivityLogEntry[]>(STORAGE_KEYS.ACTIVITY_LOGS, DEFAULT_LOGS);
  },

  addLog(
    log: Omit<ActivityLogEntry, 'id' | 'timestamp' | 'date' | 'time'> & {
      date?: string;
      time?: string;
    }
  ): void {
    const logs = this.getActivityLogs();
    const newLog: ActivityLogEntry = {
      ...log,
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      date: log.date || getFormattedDate(),
      time: log.time || getFormattedTime(),
      timestamp: Date.now(),
    };
    // Keep last 300 logs
    setStored(STORAGE_KEYS.ACTIVITY_LOGS, [newLog, ...logs].slice(0, 300));
  },

  // Utility to reset or export/import
  resetToDemoData(): void {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(STORAGE_KEYS.AREAS);
    localStorage.removeItem(STORAGE_KEYS.USERS);
    localStorage.removeItem(STORAGE_KEYS.TASK_TEMPLATES);
    localStorage.removeItem(STORAGE_KEYS.TASK_RECORDS);
    localStorage.removeItem(STORAGE_KEYS.SHORTAGES);
    localStorage.removeItem(STORAGE_KEYS.HANDOVERS);
    localStorage.removeItem(STORAGE_KEYS.ACTIVITY_LOGS);
    notifyChange();
  },

  exportAllDataAsJSON(): string {
    return JSON.stringify(
      {
        areas: this.getAreas(),
        users: this.getUsers(),
        taskTemplates: this.getTaskTemplates(),
        taskRecords: this.getTaskRecords(),
        shortages: this.getShortages(),
        handovers: this.getShiftHandovers(),
        logs: this.getActivityLogs(),
        exportedAt: new Date().toISOString(),
      },
      null,
      2
    );
  },

  importAllDataFromJSON(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.areas) localStorage.setItem(STORAGE_KEYS.AREAS, JSON.stringify(data.areas));
      if (data.users) localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(data.users));
      if (data.taskTemplates)
        localStorage.setItem(STORAGE_KEYS.TASK_TEMPLATES, JSON.stringify(data.taskTemplates));
      if (data.taskRecords)
        localStorage.setItem(STORAGE_KEYS.TASK_RECORDS, JSON.stringify(data.taskRecords));
      if (data.shortages)
        localStorage.setItem(STORAGE_KEYS.SHORTAGES, JSON.stringify(data.shortages));
      if (data.handovers)
        localStorage.setItem(STORAGE_KEYS.HANDOVERS, JSON.stringify(data.handovers));
      if (data.logs) localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify(data.logs));
      notifyChange();
      return true;
    } catch (err) {
      console.error('Failed to parse import JSON:', err);
      return false;
    }
  },
};
