import {
  CalculationHistoryItem,
  SavedCalculationItem,
  AppSettings
} from '../types';

const STORAGE_FAVORITES = 'formulax_favorites_list';
const STORAGE_HISTORY = 'formulax_history_log';
const STORAGE_SAVED = 'formulax_saved_calcs';
const STORAGE_RECENTS = 'formulax_recent_formulas';
const STORAGE_SETTINGS = 'formulax_app_settings';
const STORAGE_PRACTICE = 'formulax_practice_stats';

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  language: 'en',
  learningMode: 'student',
  soundEnabled: true,
  hapticEnabled: true,
  showStepByStep: true,
  autoSaveHistory: true,
  scientificNotation: false
};

// ==================== FAVORITES ====================

export function getLocalFavorites(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_FAVORITES);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function toggleLocalFavorite(formulaId: string): boolean {
  const current = getLocalFavorites();
  const exists = current.includes(formulaId);
  const updated = exists
    ? current.filter((id) => id !== formulaId)
    : [...current, formulaId];
  localStorage.setItem(STORAGE_FAVORITES, JSON.stringify(updated));
  return !exists;
}

export function isLocalFavorite(formulaId: string): boolean {
  return getLocalFavorites().includes(formulaId);
}

export function clearLocalFavorites(): void {
  localStorage.removeItem(STORAGE_FAVORITES);
}

// ==================== RECENT FORMULAS ====================

export function getRecentFormulaIds(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_RECENTS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function trackRecentFormula(formulaId: string): void {
  const current = getRecentFormulaIds().filter((id) => id !== formulaId);
  const updated = [formulaId, ...current].slice(0, 15);
  localStorage.setItem(STORAGE_RECENTS, JSON.stringify(updated));
}

// ==================== HISTORY ====================

export function getLocalHistory(): CalculationHistoryItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_HISTORY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addLocalHistory(item: Omit<CalculationHistoryItem, 'id' | 'timestamp'>): CalculationHistoryItem {
  const fullItem: CalculationHistoryItem = {
    ...item,
    id: `hist_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    timestamp: Date.now()
  };
  const list = [fullItem, ...getLocalHistory()].slice(0, 50);
  localStorage.setItem(STORAGE_HISTORY, JSON.stringify(list));
  return fullItem;
}

export function deleteLocalHistoryItem(id: string): void {
  const list = getLocalHistory().filter((i) => i.id !== id);
  localStorage.setItem(STORAGE_HISTORY, JSON.stringify(list));
}

export function clearLocalHistory(): void {
  localStorage.removeItem(STORAGE_HISTORY);
}

// ==================== SAVED CALCULATIONS ====================

export function getLocalSavedCalculations(): SavedCalculationItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_SAVED);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveCalculationItem(
  item: Omit<SavedCalculationItem, 'id' | 'timestamp'>
): SavedCalculationItem {
  const fullItem: SavedCalculationItem = {
    ...item,
    id: `save_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    timestamp: Date.now()
  };
  const list = [fullItem, ...getLocalSavedCalculations()];
  localStorage.setItem(STORAGE_SAVED, JSON.stringify(list));
  return fullItem;
}

export function renameSavedCalculation(id: string, newName: string): void {
  const list = getLocalSavedCalculations().map((i) =>
    i.id === id ? { ...i, name: newName } : i
  );
  localStorage.setItem(STORAGE_SAVED, JSON.stringify(list));
}

export function deleteSavedCalculation(id: string): void {
  const list = getLocalSavedCalculations().filter((i) => i.id !== id);
  localStorage.setItem(STORAGE_SAVED, JSON.stringify(list));
}

export function clearSavedCalculations(): void {
  localStorage.removeItem(STORAGE_SAVED);
}

// ==================== PRACTICE STATS ====================

export interface PracticeStats {
  correct: number;
  incorrect: number;
  bestScore: number;
}

export function getPracticeStats(): PracticeStats {
  try {
    const raw = localStorage.getItem(STORAGE_PRACTICE);
    return raw ? JSON.parse(raw) : { correct: 0, incorrect: 0, bestScore: 0 };
  } catch {
    return { correct: 0, incorrect: 0, bestScore: 0 };
  }
}

export function recordPracticeAttempt(isCorrect: boolean): PracticeStats {
  const stats = getPracticeStats();
  if (isCorrect) {
    stats.correct += 1;
    stats.bestScore = Math.max(stats.bestScore, stats.correct);
  } else {
    stats.incorrect += 1;
  }
  localStorage.setItem(STORAGE_PRACTICE, JSON.stringify(stats));
  return stats;
}

// ==================== SETTINGS ====================

export function getLocalSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(STORAGE_SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function updateLocalSettings(partial: Partial<AppSettings>): AppSettings {
  const updated = { ...getLocalSettings(), ...partial };
  localStorage.setItem(STORAGE_SETTINGS, JSON.stringify(updated));
  return updated;
}

export function resetAllAppData(): void {
  localStorage.removeItem(STORAGE_FAVORITES);
  localStorage.removeItem(STORAGE_HISTORY);
  localStorage.removeItem(STORAGE_SAVED);
  localStorage.removeItem(STORAGE_RECENTS);
  localStorage.removeItem(STORAGE_PRACTICE);
  localStorage.removeItem(STORAGE_SETTINGS);
}
