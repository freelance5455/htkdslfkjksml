import { OperationalReport, Sector } from '../types/report';
import { DEFAULT_SECTORS, INITIAL_REPORTS } from '../data/initialData';

const SECTORS_STORAGE_KEY = 'operareport_sectors_v1';
const REPORTS_STORAGE_KEY = 'operareport_reports_v1';
const DB_NAME = 'OperaReportDB';
const DB_VERSION = 1;
const STORE_NAME = 'reports';

// Open IndexedDB instance
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export function loadSectors(): Sector[] {
  try {
    const raw = localStorage.getItem(SECTORS_STORAGE_KEY);
    if (!raw) return DEFAULT_SECTORS;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_SECTORS;
  } catch (err) {
    console.warn('Errore lettura settori da localStorage, uso default:', err);
    return DEFAULT_SECTORS;
  }
}

export function saveSectors(sectors: Sector[]): void {
  try {
    localStorage.setItem(SECTORS_STORAGE_KEY, JSON.stringify(sectors));
  } catch (err) {
    console.error('Errore salvataggio settori:', err);
  }
}

export async function loadReports(): Promise<OperationalReport[]> {
  // Try IndexedDB first
  try {
    const db = await openDB();
    const reports = await new Promise<OperationalReport[]>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });

    if (reports && reports.length > 0) {
      return reports;
    }
  } catch (err) {
    console.warn('Fallback IndexedDB -> localStorage per lettura report:', err);
  }

  // Fallback to localStorage
  try {
    const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Also seed IndexedDB in the background
        saveReportsToIDB(parsed).catch(() => {});
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Errore lettura localStorage:', e);
  }

  // First time initialization: seed initial reports
  await saveReportsToIDB(INITIAL_REPORTS).catch(() => {});
  try {
    localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(INITIAL_REPORTS));
  } catch (e) {
    // LocalStorage quota might be exceeded if images are big, ignore
  }
  return INITIAL_REPORTS;
}

async function saveReportsToIDB(reports: OperationalReport[]): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.clear();
    reports.forEach((rep) => store.put(rep));
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function saveReports(reports: OperationalReport[]): Promise<void> {
  // 1. Save to IndexedDB (no quota limit issue for high-res images)
  try {
    await saveReportsToIDB(reports);
  } catch (err) {
    console.error('Errore salvataggio IndexedDB:', err);
  }

  // 2. Try saving to localStorage (without heavy images if quota exceeded)
  try {
    localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(reports));
  } catch (quotaErr) {
    console.warn('Quota localStorage superata (immagini grandi), salvato in IndexedDB:', quotaErr);
    try {
      // Save lightweight metadata in localStorage without massive dataURLs
      const lightReports = reports.map((r) => ({
        ...r,
        images: r.images.map((img) => ({
          ...img,
          url: img.url.startsWith('data:') ? '[stored-in-indexeddb]' : img.url
        }))
      }));
      localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(lightReports));
    } catch (e) {
      // Ignore
    }
  }
}

/**
 * Image compression utility for camera photos & file uploads
 */
export function compressImage(
  file: File,
  maxWidth = 1600,
  maxHeight = 1600,
  quality = 0.85
): Promise<{ dataUrl: string; sizeBytes: number; originalName: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            maxHeight = height;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context not available'));
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        // Estimate size in bytes
        const sizeBytes = Math.round((dataUrl.length * 3) / 4);
        resolve({
          dataUrl,
          sizeBytes,
          originalName: file.name
        });
      };
      img.onerror = () => reject(new Error('Caricamento immagine non riuscito'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Lettura file fallita'));
    reader.readAsDataURL(file);
  });
}

/**
 * Export data to Italian Excel-friendly CSV with BOM
 */
export function exportToCsv(reports: OperationalReport[], sectors: Sector[]): void {
  const sectorMap = new Map(sectors.map((s) => [s.id, s.name]));

  const headers = [
    'Protocollo',
    'Data e Ora',
    'Settore',
    'Titolo Report',
    'Stato Operativo',
    'Priorità',
    'Turno',
    'Operatore',
    'Ruolo',
    'Ubicazione / Impianto',
    'Descrizione',
    'Azioni Correttive',
    'N. Immagini Allegate',
    'Supervisore Firma',
    'Metriche Specifiche'
  ];

  const rows = reports.map((rep) => {
    const metricsStr = Object.entries(rep.metrics || {})
      .map(([k, v]) => `${k}: ${v}`)
      .join(' | ');

    return [
      rep.protocolNumber,
      new Date(rep.timestamp).toLocaleString('it-IT'),
      sectorMap.get(rep.sectorId) || rep.sectorId,
      rep.title.replace(/"/g, '""'),
      rep.status,
      rep.priority,
      rep.shift,
      rep.operatorName,
      rep.operatorRole,
      rep.location.replace(/"/g, '""'),
      rep.description.replace(/"/g, '""').replace(/\n/g, ' '),
      (rep.correctiveActions || '').replace(/"/g, '""').replace(/\n/g, ' '),
      rep.images.length,
      rep.supervisorSignoff?.signed ? `Firmato: ${rep.supervisorSignoff.supervisorName}` : 'Non firmato',
      metricsStr.replace(/"/g, '""')
    ];
  });

  // UTF-8 BOM for Microsoft Excel compatibility with Italian accented characters (è, é, à, ò, ù)
  const bom = '\uFEFF';
  const csvContent =
    bom +
    [
      headers.map((h) => `"${h}"`).join(';'),
      ...rows.map((row) => row.map((cell) => `"${cell}"`).join(';'))
    ].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `report_operativi_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Export complete system backup as JSON
 */
export function exportBackupJson(reports: OperationalReport[], sectors: Sector[]): void {
  const payload = {
    version: '1.0',
    exportDate: new Date().toISOString(),
    appName: 'OperaReport',
    totalReports: reports.length,
    sectors,
    reports
  };

  const jsonStr = JSON.stringify(payload, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `backup_operareport_${new Date().toISOString().slice(0, 10)}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Import and restore backup
 */
export async function importBackupJson(
  file: File
): Promise<{ reports: OperationalReport[]; sectors: Sector[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const parsed = JSON.parse(e.target?.result as string);
        if (!parsed.reports || !Array.isArray(parsed.reports)) {
          throw new Error('Formato backup non valido: array "reports" mancante');
        }
        const sectors = Array.isArray(parsed.sectors) && parsed.sectors.length > 0 ? parsed.sectors : DEFAULT_SECTORS;
        const reports = parsed.reports as OperationalReport[];

        await saveReports(reports);
        saveSectors(sectors);

        resolve({ reports, sectors });
      } catch (err: any) {
        reject(new Error(err?.message || 'Errore nella lettura del file di backup'));
      }
    };
    reader.onerror = () => reject(new Error('Errore nel caricamento del file'));
    reader.readAsText(file);
  });
}
