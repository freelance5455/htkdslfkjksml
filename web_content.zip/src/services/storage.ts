import type { ChatSession, NoteItem, ShortcutItem, UserSettings } from '../types';

const STORAGE_KEYS = {
  SETTINGS: 'jarvis_mobile_settings_v1',
  SESSIONS: 'jarvis_mobile_sessions_v1',
  ACTIVE_SESSION_ID: 'jarvis_mobile_active_session_v1',
  NOTES: 'jarvis_mobile_notes_v1',
  SHORTCUTS: 'jarvis_mobile_shortcuts_v1',
} as const;

export const DEFAULT_SETTINGS: UserSettings = {
  assistantName: 'JARVIS',
  userNickname: '',
  preferredLanguage: 'auto',
  speechLanguage: 'en-IN',
  voiceEnabled: true,
  handsFreeMode: true,
  lowPowerMode: false,
  speechSpeed: 1.0,
  responseLength: 'concise',
  themeBrightness: 'standard',
};

export const DEFAULT_SHORTCUTS: ShortcutItem[] = [
  { id: 'yt', label: 'YouTube', url: 'https://www.youtube.com' },
  { id: 'google', label: 'Google', url: 'https://www.google.com' },
  { id: 'maps', label: 'Maps', url: 'https://maps.google.com' },
  { id: 'wiki', label: 'Wikipedia', url: 'https://en.wikipedia.org' },
  { id: 'gmail', label: 'Gmail', url: 'https://mail.google.com' },
  { id: 'news', label: 'News', url: 'https://news.google.com' },
];

function safeRead<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function safeWrite<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore storage quota errors cleanly
  }
}

export function loadSettings(): UserSettings {
  const saved = safeRead<Partial<UserSettings>>(STORAGE_KEYS.SETTINGS, {});
  return {
    ...DEFAULT_SETTINGS,
    ...saved,
    assistantName:
      typeof saved.assistantName === 'string' && saved.assistantName.trim()
        ? saved.assistantName.trim().slice(0, 24)
        : DEFAULT_SETTINGS.assistantName,
    handsFreeMode:
      typeof saved.handsFreeMode === 'boolean'
        ? saved.handsFreeMode
        : DEFAULT_SETTINGS.handsFreeMode,
    lowPowerMode:
      typeof saved.lowPowerMode === 'boolean'
        ? saved.lowPowerMode
        : DEFAULT_SETTINGS.lowPowerMode,
    speechSpeed:
      typeof saved.speechSpeed === 'number' && saved.speechSpeed >= 0.6 && saved.speechSpeed <= 1.8
        ? saved.speechSpeed
        : DEFAULT_SETTINGS.speechSpeed,
  };
}

export function saveSettings(settings: UserSettings): void {
  safeWrite(STORAGE_KEYS.SETTINGS, settings);
}

export function resetAllSettings(): UserSettings {
  safeWrite(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
  return DEFAULT_SETTINGS;
}

export function loadSessions(): ChatSession[] {
  const sessions = safeRead<ChatSession[]>(STORAGE_KEYS.SESSIONS, []);
  return Array.isArray(sessions) ? sessions : [];
}

export function saveSessions(sessions: ChatSession[]): void {
  safeWrite(STORAGE_KEYS.SESSIONS, sessions.slice(0, 25));
}

export function loadActiveSessionId(): string | null {
  try {
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_SESSION_ID);
  } catch {
    return null;
  }
}

export function saveActiveSessionId(id: string): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_SESSION_ID, id);
  } catch {
    // Ignore
  }
}

export function clearAllChatSessions(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.SESSIONS);
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_SESSION_ID);
  } catch {
    // Ignore
  }
}

export function loadNotes(): NoteItem[] {
  const notes = safeRead<NoteItem[]>(STORAGE_KEYS.NOTES, []);
  return Array.isArray(notes) ? notes : [];
}

export function saveNotes(notes: NoteItem[]): void {
  safeWrite(STORAGE_KEYS.NOTES, notes);
}

export function loadShortcuts(): ShortcutItem[] {
  const shortcuts = safeRead<ShortcutItem[]>(STORAGE_KEYS.SHORTCUTS, DEFAULT_SHORTCUTS);
  return Array.isArray(shortcuts) && shortcuts.length > 0 ? shortcuts : DEFAULT_SHORTCUTS;
}

export function saveShortcuts(shortcuts: ShortcutItem[]): void {
  safeWrite(STORAGE_KEYS.SHORTCUTS, shortcuts);
}
