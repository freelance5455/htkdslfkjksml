import { UserProfile, Workout, WeeklyPlanDay, RecoveryCheckIn, ChatMessage } from '../types';

const STORAGE_KEYS = {
  PROFILE: 'jaat_user_profile',
  WORKOUTS: 'jaat_workouts',
  WEEKLY_PLAN: 'jaat_weekly_plan',
  RECOVERY: 'jaat_recovery_logs',
  CHAT: 'jaat_chat_history',
  GPS_CONSENT: 'jaat_gps_consent',
};

export const DEFAULT_PROFILE: UserProfile = {
  name: 'Runner',
  age: 23,
  heightCm: 175,
  weightKg: 68,
  experience: 'Intermediate',
  currentPb1600m: '5:30',
  target1600m: '4:50',
  weeklyVolumeKm: 25,
  trainingDaysPerWeek: 5,
  currentInjuries: 'None',
  medicalLimitations: 'None',
  preferredLanguage: 'Hinglish',
  preferredTime: 'Morning',
  hasCompletedOnboarding: false,
  isBaselineVerified: false,
};

export const DEFAULT_WEEKLY_PLAN: WeeklyPlanDay[] = [
  {
    id: 'mon',
    dayName: 'MONDAY',
    title: 'Speed & Running Technique',
    workoutType: 'track_reps',
    targetDurationMin: 45,
    targetDistanceKm: 4.5,
    intensity: 'high',
    warmUp: '10–15 min easy jog, dynamic mobility (high knees, butt kicks, A-skips, ankle rolls).',
    mainWorkout: '6 × 200m at controlled, fast but relaxed effort. Focus on hip extension and upright posture.',
    recoveryGuidance: 'Walk or jog 200m full recovery between repetitions. Do not rush into the next repetition while heart rate is elevated.',
    cooldown: '10 min easy cooldown jog followed by gentle calf and hip mobility stretches.',
    completed: false,
  },
  {
    id: 'tue',
    dayName: 'TUESDAY',
    title: 'Easy Aerobic Base Run',
    workoutType: 'easy',
    targetDurationMin: 30,
    targetDistanceKm: 5.0,
    intensity: 'low',
    warmUp: '5 min brisk walking and hip openers.',
    mainWorkout: '25–35 minutes continuous running at conversational effort. You should be able to speak full sentences without gasping.',
    recoveryGuidance: 'Relaxed breathing (3-3 pattern), light footstrike, relaxed shoulders.',
    cooldown: '5 min walking cooldown and gentle hamstring/quad stretches.',
    completed: false,
  },
  {
    id: 'wed',
    dayName: 'WEDNESDAY',
    title: '1600m-Specific Intervals',
    workoutType: 'intervals',
    targetDurationMin: 40,
    targetDistanceKm: 4.0,
    intensity: 'high',
    warmUp: '10–15 minutes easy warm-up jog plus dynamic strides.',
    mainWorkout: '4 × 400m at pace appropriate to current ability (~1:22 for 5:30 baseline, working towards 1:12.5). Do not force 1:12.5 if form breaks down!',
    recoveryGuidance: '2–3 minutes standing or walking recovery between reps. Sip water.',
    cooldown: '800m slow jog and post-interval mobility.',
    completed: false,
  },
  {
    id: 'thu',
    dayName: 'THURSDAY',
    title: 'Active Recovery & Mobility',
    workoutType: 'recovery',
    targetDurationMin: 25,
    targetDistanceKm: 3.0,
    intensity: 'low',
    warmUp: 'Gentle arm and torso twists.',
    mainWorkout: 'Full rest OR 20–30 minutes very easy jog/walk. No hard intervals permitted under any circumstances.',
    recoveryGuidance: 'Foam roll calves, IT band, and quads. Hydrate with lemon-salt water.',
    cooldown: '15 min dedicated flexibility and yoga mobility.',
    completed: false,
  },
  {
    id: 'fri',
    dayName: 'FRIDAY',
    title: 'Tempo & Lactate Endurance',
    workoutType: 'tempo',
    targetDurationMin: 35,
    targetDistanceKm: 5.5,
    intensity: 'moderate',
    warmUp: '10 min easy jog.',
    mainWorkout: '10–15 minutes comfortably hard, controlled tempo running (~4:45-5:00 min/km). Sustainable rhythm, not all-out racing.',
    recoveryGuidance: 'Focus on 2:2 breathing rhythm. Keep jaw slack and hands unclenched.',
    cooldown: '10 min easy jog and calf stretches.',
    completed: false,
  },
  {
    id: 'sat',
    dayName: 'SATURDAY',
    title: 'Easy Run & Strides',
    workoutType: 'easy',
    targetDurationMin: 30,
    targetDistanceKm: 4.5,
    intensity: 'low',
    warmUp: '5 min dynamic leg swings.',
    mainWorkout: '20–30 minutes easy running followed by optional 4 × 80m relaxed strides with full walking recovery (only if feeling fresh).',
    recoveryGuidance: 'Strides are for neuromuscular coordination, NOT all-out sprints.',
    cooldown: '5 min walk and cool shower.',
    completed: false,
  },
  {
    id: 'sun',
    dayName: 'SUNDAY',
    title: 'Rest & Weekly Review',
    workoutType: 'walk_cross',
    targetDurationMin: 20,
    intensity: 'low',
    warmUp: 'None needed.',
    mainWorkout: 'Full rest or relaxed recovery walk in the park. Review weekly distance, pace consistency, and muscle soreness.',
    recoveryGuidance: 'Consult Coach Jaat for the weekly AI analysis report and plan next week.',
    cooldown: 'Relaxation and deep sleep.',
    completed: false,
  },
];

// Helper demo workouts to showcase charts and splits (clearly flagged isDemo: true)
export const DEMO_WORKOUTS: Workout[] = [
  {
    id: 'demo-1',
    date: '2026-10-25',
    startTime: '06:15',
    workoutType: 'easy',
    title: 'Morning Base Builder',
    distanceKm: 5.2,
    distanceMeters: 5200,
    durationSeconds: 1612,
    durationFormatted: '26:52',
    avgPace: '5:10',
    avgSpeedKmh: 11.6,
    rpe: 5,
    sleepHours: 7.5,
    energyLevel: 4,
    sorenessScore: 2,
    splits: [
      { lapNumber: 1, distanceMeters: 1000, durationSeconds: 315, pace: '5:15', speedKmh: 11.4 },
      { lapNumber: 2, distanceMeters: 1000, durationSeconds: 310, pace: '5:10', speedKmh: 11.6 },
      { lapNumber: 3, distanceMeters: 1000, durationSeconds: 308, pace: '5:08', speedKmh: 11.7 },
      { lapNumber: 4, distanceMeters: 1000, durationSeconds: 305, pace: '5:05', speedKmh: 11.8 },
      { lapNumber: 5, distanceMeters: 1000, durationSeconds: 312, pace: '5:12', speedKmh: 11.5 },
    ],
    routeCoordinates: [],
    notes: 'Controlled easy effort. Weather was cool, breathing was very relaxed.',
    coachAnalysis: 'Solid aerobic conditioning. Pacing stayed consistent within a 10s variance across 5km.',
    isDemo: true,
  },
  {
    id: 'demo-2',
    date: '2026-10-27',
    startTime: '06:30',
    workoutType: 'intervals',
    title: '4 × 400m Track Intervals',
    distanceKm: 3.8,
    distanceMeters: 3800,
    durationSeconds: 1240,
    durationFormatted: '20:40',
    avgPace: '4:25',
    avgSpeedKmh: 13.5,
    rpe: 8,
    sleepHours: 8.0,
    energyLevel: 5,
    sorenessScore: 3,
    splits: [
      { lapNumber: 1, distanceMeters: 400, durationSeconds: 81, pace: '3:22', speedKmh: 17.7 },
      { lapNumber: 2, distanceMeters: 400, durationSeconds: 83, pace: '3:27', speedKmh: 17.3 },
      { lapNumber: 3, distanceMeters: 400, durationSeconds: 82, pace: '3:25', speedKmh: 17.5 },
      { lapNumber: 4, distanceMeters: 400, durationSeconds: 80, pace: '3:20', speedKmh: 18.0 },
    ],
    routeCoordinates: [],
    notes: 'Hit ~1:21-1:23 per 400m repetition with 2.5 min recovery. Target for 4:50 is 1:12.5.',
    coachAnalysis: 'Strong repetition discipline. Rep 4 was the fastest (negative split). Target 1:12.5 requires 8-10 more seconds of speed endurance progression.',
    isDemo: true,
  },
];

export const StorageService = {
  getProfile(): UserProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  },

  saveProfile(profile: UserProfile): void {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  },

  getWorkouts(): Workout[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.WORKOUTS);
      if (data) {
        return JSON.parse(data);
      }
      // Seed with demo workouts so user has initial context
      localStorage.setItem(STORAGE_KEYS.WORKOUTS, JSON.stringify(DEMO_WORKOUTS));
      return DEMO_WORKOUTS;
    } catch {
      return DEMO_WORKOUTS;
    }
  },

  saveWorkout(workout: Workout): Workout[] {
    const workouts = this.getWorkouts();
    const updated = [workout, ...workouts];
    localStorage.setItem(STORAGE_KEYS.WORKOUTS, JSON.stringify(updated));
    return updated;
  },

  deleteWorkout(id: string): Workout[] {
    const workouts = this.getWorkouts().filter(w => w.id !== id);
    localStorage.setItem(STORAGE_KEYS.WORKOUTS, JSON.stringify(workouts));
    return workouts;
  },

  clearDemoWorkouts(): Workout[] {
    const workouts = this.getWorkouts().filter(w => !w.isDemo);
    localStorage.setItem(STORAGE_KEYS.WORKOUTS, JSON.stringify(workouts));
    return workouts;
  },

  getWeeklyPlan(): WeeklyPlanDay[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.WEEKLY_PLAN);
      return data ? JSON.parse(data) : DEFAULT_WEEKLY_PLAN;
    } catch {
      return DEFAULT_WEEKLY_PLAN;
    }
  },

  saveWeeklyPlan(plan: WeeklyPlanDay[]): void {
    localStorage.setItem(STORAGE_KEYS.WEEKLY_PLAN, JSON.stringify(plan));
  },

  toggleDayCompletion(dayId: string, completedWorkoutId?: string): WeeklyPlanDay[] {
    const plan = this.getWeeklyPlan().map(day => {
      if (day.id === dayId) {
        return {
          ...day,
          completed: !day.completed,
          completedWorkoutId: !day.completed ? completedWorkoutId : undefined,
        };
      }
      return day;
    });
    this.saveWeeklyPlan(plan);
    return plan;
  },

  getRecoveryLogs(): RecoveryCheckIn[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.RECOVERY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveRecoveryLog(log: RecoveryCheckIn): RecoveryCheckIn[] {
    const logs = this.getRecoveryLogs();
    const updated = [log, ...logs];
    localStorage.setItem(STORAGE_KEYS.RECOVERY, JSON.stringify(updated));
    return updated;
  },

  getChatHistory(): ChatMessage[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHAT);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveChatHistory(history: ChatMessage[]): void {
    localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(history));
  },

  getGPSConsent(): boolean {
    return localStorage.getItem(STORAGE_KEYS.GPS_CONSENT) === 'true';
  },

  setGPSConsent(consent: boolean): void {
    localStorage.setItem(STORAGE_KEYS.GPS_CONSENT, consent ? 'true' : 'false');
  },

  exportAllData(): string {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      profile: this.getProfile(),
      workouts: this.getWorkouts(),
      weeklyPlan: this.getWeeklyPlan(),
      recoveryLogs: this.getRecoveryLogs(),
    };
    return JSON.stringify(backup, null, 2);
  },

  importAllData(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.profile) this.saveProfile(data.profile);
      if (data.workouts) localStorage.setItem(STORAGE_KEYS.WORKOUTS, JSON.stringify(data.workouts));
      if (data.weeklyPlan) this.saveWeeklyPlan(data.weeklyPlan);
      if (data.recoveryLogs) localStorage.setItem(STORAGE_KEYS.RECOVERY, JSON.stringify(data.recoveryLogs));
      return true;
    } catch (e) {
      console.error('Import failed', e);
      return false;
    }
  },

  resetAllData(): void {
    localStorage.removeItem(STORAGE_KEYS.PROFILE);
    localStorage.removeItem(STORAGE_KEYS.WORKOUTS);
    localStorage.removeItem(STORAGE_KEYS.WEEKLY_PLAN);
    localStorage.removeItem(STORAGE_KEYS.RECOVERY);
    localStorage.removeItem(STORAGE_KEYS.CHAT);
    localStorage.removeItem(STORAGE_KEYS.GPS_CONSENT);
  },
};
