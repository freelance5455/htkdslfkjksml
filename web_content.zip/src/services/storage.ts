import { GameSettings, LevelProgress, UserProgress } from '../types/game';

const STORAGE_KEY = 'arrow_escape_progress_v1';

export const DEFAULT_SETTINGS: GameSettings = {
  soundEnabled: true,
  hapticsEnabled: true,
  animationSpeed: 'normal',
  contrastTheme: 'paper_light',
};

export const DEFAULT_PROGRESS: UserProgress = {
  currentLevel: 1,
  completedLevels: {},
  totalStars: 0,
  totalScore: 0,
  settings: DEFAULT_SETTINGS,
  lastUpdated: new Date().toISOString(),
  pendingSync: false,
};

export function loadLocalProgress(): UserProgress {
  if (typeof window === 'undefined') return DEFAULT_PROGRESS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw) as UserProgress;
    return {
      ...DEFAULT_PROGRESS,
      ...parsed,
      settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) },
      completedLevels: parsed.completedLevels || {},
    };
  } catch (e) {
    console.error('Failed to load local progress:', e);
    return DEFAULT_PROGRESS;
  }
}

export function saveLocalProgress(progress: UserProgress): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    console.error('Failed to save local progress:', e);
  }
}

/**
 * Merges two user progress states (e.g. guest local progress + cloud progress on login).
 * Conflict resolution rules:
 * - Highest unlocked current level wins.
 * - Completed levels union: keep highest star rating, best time, and best moves.
 * - Total stars & scores recalculated from best results.
 * - Settings from the more recently updated timestamp wins.
 */
export function mergeProgress(local: UserProgress, remote: UserProgress): UserProgress {
  const mergedCompleted: Record<number, LevelProgress> = {
    ...local.completedLevels,
  };

  for (const [lvlStr, remoteLvl] of Object.entries(remote.completedLevels || {})) {
    const lvlId = Number(lvlStr);
    const localLvl = mergedCompleted[lvlId];

    if (!localLvl) {
      mergedCompleted[lvlId] = remoteLvl;
    } else {
      mergedCompleted[lvlId] = {
        stars: Math.max(localLvl.stars, remoteLvl.stars),
        bestTimeSec:
          localLvl.bestTimeSec > 0 && remoteLvl.bestTimeSec > 0
            ? Math.min(localLvl.bestTimeSec, remoteLvl.bestTimeSec)
            : Math.max(localLvl.bestTimeSec, remoteLvl.bestTimeSec),
        bestMoves:
          localLvl.bestMoves > 0 && remoteLvl.bestMoves > 0
            ? Math.min(localLvl.bestMoves, remoteLvl.bestMoves)
            : Math.max(localLvl.bestMoves, remoteLvl.bestMoves),
        completedAt:
          new Date(localLvl.completedAt).getTime() > new Date(remoteLvl.completedAt).getTime()
            ? localLvl.completedAt
            : remoteLvl.completedAt,
      };
    }
  }

  let totalStars = 0;
  for (const lvl of Object.values(mergedCompleted)) {
    totalStars += lvl.stars;
  }

  const currentLevel = Math.max(local.currentLevel, remote.currentLevel);

  const localTime = new Date(local.lastUpdated || 0).getTime();
  const remoteTime = new Date(remote.lastUpdated || 0).getTime();
  const settings = localTime >= remoteTime ? local.settings : remote.settings;

  return {
    currentLevel,
    completedLevels: mergedCompleted,
    totalStars,
    totalScore: Math.max(local.totalScore || 0, remote.totalScore || 0, totalStars * 100),
    settings: settings || DEFAULT_SETTINGS,
    lastUpdated: new Date().toISOString(),
    pendingSync: true,
  };
}
