/**
 * طبقة التخزين الوحيدة في التطبيق.
 * كل المكونات تتعامل مع هذه الطبقة ولا تلمس localStorage مباشرة،
 * ما يسهّل لاحقاً استبدالها بـ Firebase أو أي API (يكفي تغيير هذا الملف).
 */
import { useSyncExternalStore } from 'react';

const NS = 'manara.v1.';
const cache = new Map<string, unknown>();
const memoryOnly = new Set<string>();
const listeners = new Map<string, Set<() => void>>();

function fullKey(key: string): string {
  return NS + key;
}

function safeParse<T>(raw: string | null, fallback: T): T {
  if (raw === null) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function readKey<T>(key: string, fallback: T): T {
  if (cache.has(key)) return cache.get(key) as T;
  let value: T;
  try {
    value = safeParse<T>(localStorage.getItem(fullKey(key)), fallback);
  } catch {
    value = fallback;
  }
  cache.set(key, value);
  return value;
}

function emit(key: string): void {
  const set = listeners.get(key);
  if (!set) return;
  for (const cb of set) {
    try {
      cb();
    } catch {
      // لا نجعل خطأ واجهة مشتركة يغيّر نتيجة معاملة التخزين.
    }
  }
}

function refreshCachedKey(key: string): void {
  if (memoryOnly.has(key)) return;
  try {
    const raw = localStorage.getItem(fullKey(key));
    const previous = cache.get(key);
    const previousJson = cache.has(key) ? JSON.stringify(previous) : undefined;
    const next = safeParse<unknown>(raw, undefined);
    const nextJson = raw === null ? undefined : JSON.stringify(next);
    if (raw === null) cache.delete(key);
    else cache.set(key, next);
    if (previousJson !== nextJson) emit(key);
  } catch {
    // يبقى التخزين في الذاكرة عند تعذّر localStorage.
  }
}

export function writeKey<T>(key: string, value: T): boolean {
  cache.set(key, value);
  try {
    localStorage.setItem(fullKey(key), JSON.stringify(value));
    memoryOnly.delete(key);
    emit(key);
    return true;
  } catch {
    // مساحة ممتلئة أو وضع خاص: نُبقي القيمة في الذاكرة حتى لا تتعطّل الواجهة
    memoryOnly.add(key);
    emit(key);
    return false;
  }
}

export function updateKey<T>(key: string, updater: (current: T) => T, fallback: T): T {
  const next = updater(readKey<T>(key, fallback));
  writeKey(key, next);
  return next;
}

/** يقفل تحديثات المحفظة بين التبويبات ويعيد قراءة الحالة المشتركة قبل تنفيذها. */
export async function withStorageLock<T>(
  name: string,
  keys: readonly string[],
  operation: () => T | Promise<T>,
): Promise<T> {
  const run = async (): Promise<T> => {
    for (const key of keys) refreshCachedKey(key);
    return operation();
  };
  if (typeof navigator !== 'undefined' && navigator.locks) {
    return navigator.locks.request(`manara:${name}`, { mode: 'exclusive' }, run);
  }
  // متصفحات لا تملك Web Locks تبقى قابلة للاستخدام، مع مزامنة أحداث التخزين أدناه.
  return run();
}

export function subscribeKey(key: string, cb: () => void): () => void {
  let set = listeners.get(key);
  if (!set) {
    set = new Set();
    listeners.set(key, set);
  }
  set.add(cb);
  return () => {
    set.delete(cb);
  };
}

/** حدّث المخبأ وردّ الفعل في التبويبات الأخرى عند تغيّر localStorage. */
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (event) => {
    if (!event.key?.startsWith(NS)) return;
    const key = event.key.slice(NS.length);
    if (event.newValue === null) cache.delete(key);
    else cache.set(key, safeParse<unknown>(event.newValue, undefined));
    emit(key);
  });
}

/** خطّاف React يقرأ مفتاحاً واحداً ويتحدّث تلقائياً عند أي كتابة عليه */
export function useStored<T>(key: string, fallback: T): T {
  return useSyncExternalStore(
    (cb) => subscribeKey(key, cb),
    () => readKey<T>(key, fallback),
    () => readKey<T>(key, fallback),
  );
}

/** عناوين المفاتيح المستخدمة في التطبيق (مركزية لتسهيل التصدير والتصفير) */
export const KEYS = {
  profile: 'profile',
  settings: 'settings',
  progress: 'progress',
  curriculumProgress: 'curriculumProgress',
  notes: 'notes',
  bookmarks: 'bookmarks',
  stats: 'stats',
  quizzes: 'quizzes',
  cards: 'cards',
  plan: 'plan',
  badges: 'badges',
  wallet: 'wallet',
  farm: 'farm',
  studySessions: 'studySessions',
  practiceAttempts: 'practiceAttempts',
  writtenAnswers: 'writtenAnswers',
  dailyTasks: 'dailyTasks',
  gradebook: 'gradebook',
  dailyRoutines: 'dailyRoutines',
} as const;

export const STORAGE_PREFIX = NS;

const BACKUP_SHARED_KEYS = [KEYS.wallet, KEYS.dailyTasks, KEYS.gradebook, KEYS.dailyRoutines] as const;
const KNOWN_KEYS = new Set<string>(Object.values(KEYS));

/** يبيّن أن آخر قيمة لهذا المفتاح لا تزال مؤقتة في الذاكرة بسبب فشل localStorage. */
export function isKeyMemoryOnly(key: string): boolean {
  return memoryOnly.has(key);
}

export function listAppKeys(): string[] {
  const out: string[] = [];
  try {
    for (let i = 0; i < localStorage.length; i += 1) {
      const k = localStorage.key(i);
      if (k && k.startsWith(NS)) out.push(k);
    }
  } catch {
    /* تجاهل */
  }
  return out;
}

function dumpAllUnlocked(): Record<string, unknown> {
  const dump: Record<string, unknown> = {};
  const keys = new Set(listAppKeys().map((full) => full.slice(NS.length)));
  for (const key of memoryOnly) keys.add(key);
  for (const short of keys) {
    if (memoryOnly.has(short) && cache.has(short)) {
      dump[short] = cache.get(short);
      continue;
    }
    try {
      dump[short] = safeParse<unknown>(localStorage.getItem(fullKey(short)), null);
    } catch {
      if (cache.has(short)) dump[short] = cache.get(short);
    }
  }
  return dump;
}

/** يأخذ لقطة متناسقة مع معاملات المحفظة والمهام والعلامات العابرة للتبويبات. */
export async function dumpAll(): Promise<Record<string, unknown>> {
  return withStorageLock('wallet', BACKUP_SHARED_KEYS, dumpAllUnlocked);
}

interface StoredSnapshot {
  key: string;
  raw: string | null;
  hadCache: boolean;
  cachedValue: unknown;
  wasMemoryOnly: boolean;
}

export interface AtomicStorageResult {
  ok: boolean;
  rollbackComplete: boolean;
  reason?: 'invalid-data' | 'snapshot-failed' | 'write-failed';
}

function captureState(keys: readonly string[]): StoredSnapshot[] {
  return keys.map((key) => ({
    key,
    raw: localStorage.getItem(fullKey(key)),
    hadCache: cache.has(key),
    cachedValue: cache.get(key),
    wasMemoryOnly: memoryOnly.has(key),
  }));
}

/** يعيد القيم السابقة بعد فشل استيراد أو تصفير، ثم يتحقق من التخزين الدائم فعلياً. */
function rollbackState(snapshot: readonly StoredSnapshot[]): boolean {
  for (const entry of snapshot) {
    try {
      localStorage.removeItem(fullKey(entry.key));
    } catch {
      // سنحاول استعادة بقية المفاتيح ونتحقق من النتيجة أدناه.
    }
  }
  for (const entry of snapshot) {
    if (entry.raw === null) continue;
    try {
      localStorage.setItem(fullKey(entry.key), entry.raw);
    } catch {
      // يُكتشف فشل الاستعادة في مرحلة التحقق.
    }
  }

  let complete = true;
  for (const entry of snapshot) {
    try {
      if (localStorage.getItem(fullKey(entry.key)) !== entry.raw) complete = false;
    } catch {
      complete = false;
    }
    if (entry.hadCache) cache.set(entry.key, entry.cachedValue);
    else cache.delete(entry.key);
    if (entry.wasMemoryOnly) memoryOnly.add(entry.key);
    else memoryOnly.delete(entry.key);
    emit(entry.key);
  }
  return complete;
}

export async function restoreAll(data: Record<string, unknown>): Promise<AtomicStorageResult> {
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    return { ok: false, rollbackComplete: true, reason: 'invalid-data' };
  }
  const keys = Object.keys(data);
  if (keys.some((key) => !KNOWN_KEYS.has(key))) {
    return { ok: false, rollbackComplete: true, reason: 'invalid-data' };
  }
  const serialized = new Map<string, string>();
  try {
    for (const key of keys) {
      const value = JSON.stringify(data[key]);
      if (value === undefined) return { ok: false, rollbackComplete: true, reason: 'invalid-data' };
      serialized.set(key, value);
    }
  } catch {
    return { ok: false, rollbackComplete: true, reason: 'invalid-data' };
  }

  const guardedKeys = [...new Set([...BACKUP_SHARED_KEYS, ...keys])];
  return withStorageLock('wallet', guardedKeys, () => {
    let snapshot: StoredSnapshot[];
    try {
      for (const key of keys) refreshCachedKey(key);
      snapshot = captureState(keys);
    } catch {
      return { ok: false, rollbackComplete: true, reason: 'snapshot-failed' };
    }

    try {
      for (const key of keys) {
        localStorage.setItem(fullKey(key), serialized.get(key)!);
        cache.set(key, data[key]);
        memoryOnly.delete(key);
      }
      for (const key of keys) emit(key);
      return { ok: true, rollbackComplete: true };
    } catch {
      return { ok: false, rollbackComplete: rollbackState(snapshot), reason: 'write-failed' };
    }
  });
}

/** يصفر بيانات التطبيق داخل القفل نفسه، مع استعادة الحالة السابقة إذا تعذر إكمال الحذف. */
export async function clearAll(): Promise<AtomicStorageResult> {
  const guardedKeys = [...new Set([...BACKUP_SHARED_KEYS, ...Object.values(KEYS)])];
  return withStorageLock('wallet', guardedKeys, () => {
    const keys = [...new Set([
      ...listAppKeys().map((full) => full.slice(NS.length)),
      ...cache.keys(),
      ...memoryOnly,
    ])];
    let snapshot: StoredSnapshot[];
    try {
      snapshot = captureState(keys);
    } catch {
      return { ok: false, rollbackComplete: true, reason: 'snapshot-failed' };
    }

    let failed = false;
    for (const key of keys) {
      try {
        localStorage.removeItem(fullKey(key));
      } catch {
        failed = true;
      }
    }
    if (failed) {
      return { ok: false, rollbackComplete: rollbackState(snapshot), reason: 'write-failed' };
    }

    for (const key of keys) {
      cache.delete(key);
      memoryOnly.delete(key);
    }
    for (const key of keys) emit(key);
    return { ok: true, rollbackComplete: true };
  });
}
