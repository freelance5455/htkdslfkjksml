import { UserAccount, UserProfile, UserProgressData, MistakeItem, ActivityLogItem, WordData, SrsItem, SrsRating } from '../types';
import { SrsEngine } from './srs';

const STORAGE_ACCOUNTS_KEY = 'vocabmuse_accounts_v1';
const CURRENT_USER_ID_KEY = 'vocabmuse_active_user_id';

const DEFAULT_PROFILE: UserProfile = {
  id: 'default_aspirant',
  name: 'Aspirant User',
  email: 'aspirant@vocabmuse.app',
  pin: '',
  targetExam: 'Bangladesh Civil Service (BCS)',
  dailyGoal: 15,
  streak: 1,
  streakFreezes: 2,
  xp: 150,
  lastActiveDate: new Date().toISOString().slice(0, 10),
  theme: 'light',
  voiceLang: 'en-US',
  createdAt: new Date().toISOString()
};

const INITIAL_DAILY_QUESTS = [
  {
    id: 'quest_sprint',
    title: 'Sprint Champion',
    description: 'Review 10 words today',
    target: 10,
    current: 1,
    xpReward: 50,
    completed: false,
    claimed: false,
  },
  {
    id: 'quest_quiz',
    title: 'Arena Scholar',
    description: 'Score 80%+ on Diagnostic Quiz Drill',
    target: 1,
    current: 0,
    xpReward: 75,
    completed: false,
    claimed: false,
  },
  {
    id: 'quest_blitz',
    title: 'Speed Blitz Master',
    description: 'Complete a Word Blitz Match Challenge',
    target: 1,
    current: 0,
    xpReward: 60,
    completed: false,
    claimed: false,
  },
  {
    id: 'quest_vault',
    title: 'Weakness Eraser',
    description: 'Resolve 1 weak mistake from the Vault',
    target: 1,
    current: 0,
    xpReward: 40,
    completed: false,
    claimed: false,
  },
];

const DEFAULT_PROGRESS: UserProgressData = {
  mastered: ['Callous'],
  revise: ['Abash'],
  learn: ['Abate'],
  saved: ['Callous', 'Abate'],
  todayLearned: ['Callous'],
  fluencyScores: {
    Callous: 100,
    Abash: 50,
    Abate: 25,
  },
  mistakesVault: [],
  dailyQuests: INITIAL_DAILY_QUESTS,
  customEnrichedDossiers: {},
  srsRecords: {
    Callous: {
      word: 'Callous',
      stage: 3,
      stability: 7,
      lastReviewedAt: new Date(Date.now() - 3.5 * 24 * 60 * 60 * 1000).toISOString(),
      nextReviewAt: new Date(Date.now() + 3.5 * 24 * 60 * 60 * 1000).toISOString(),
      reviewsCount: 3,
      lapses: 0,
      retentionScore: 61,
    },
    Abash: {
      word: 'Abash',
      stage: 1,
      stability: 1,
      lastReviewedAt: new Date(Date.now() - 1.2 * 24 * 60 * 60 * 1000).toISOString(),
      nextReviewAt: new Date(Date.now() - 0.2 * 24 * 60 * 60 * 1000).toISOString(),
      reviewsCount: 1,
      lapses: 1,
      retentionScore: 30,
    },
    Abate: {
      word: 'Abate',
      stage: 0,
      stability: 0.5,
      lastReviewedAt: new Date(Date.now() - 18 * 60 * 60 * 1000).toISOString(),
      nextReviewAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      reviewsCount: 1,
      lapses: 0,
      retentionScore: 22,
    },
  },
  activityLog: [
    {
      id: 'log_init',
      type: 'Account',
      text: 'Profile initiated and ready for competitive exam prep',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      date: new Date().toISOString().slice(0, 10)
    }
  ]
};

export class StorageService {
  private accounts: Record<string, UserAccount> = {};
  private activeUserId: string = DEFAULT_PROFILE.id;

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    if (typeof window === 'undefined') return;
    try {
      const storedAccounts = localStorage.getItem(STORAGE_ACCOUNTS_KEY);
      if (storedAccounts) {
        this.accounts = JSON.parse(storedAccounts);
      }

      // If no accounts exist yet, create default
      if (Object.keys(this.accounts).length === 0) {
        this.accounts[DEFAULT_PROFILE.id] = {
          profile: { ...DEFAULT_PROFILE },
          progress: { ...DEFAULT_PROGRESS }
        };
      }

      const activeId = localStorage.getItem(CURRENT_USER_ID_KEY);
      if (activeId && this.accounts[activeId]) {
        this.activeUserId = activeId;
      } else {
        this.activeUserId = Object.keys(this.accounts)[0] || DEFAULT_PROFILE.id;
      }

      this.checkAndIncrementStreak();
    } catch (e) {
      console.error('Failed to load accounts from storage:', e);
      this.accounts[DEFAULT_PROFILE.id] = {
        profile: { ...DEFAULT_PROFILE },
        progress: { ...DEFAULT_PROGRESS }
      };
      this.activeUserId = DEFAULT_PROFILE.id;
    }
  }

  private saveToStorage() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_ACCOUNTS_KEY, JSON.stringify(this.accounts));
      localStorage.setItem(CURRENT_USER_ID_KEY, this.activeUserId);
    } catch (e) {
      console.error('Failed to save to storage:', e);
    }
  }

  public getActiveAccount(): UserAccount {
    if (!this.accounts[this.activeUserId]) {
      this.activeUserId = Object.keys(this.accounts)[0] || DEFAULT_PROFILE.id;
      if (!this.accounts[this.activeUserId]) {
        this.accounts[this.activeUserId] = {
          profile: { ...DEFAULT_PROFILE },
          progress: { ...DEFAULT_PROGRESS }
        };
      }
    }
    return this.accounts[this.activeUserId];
  }

  public getAllAccounts(): UserProfile[] {
    return Object.values(this.accounts).map(acc => acc.profile);
  }

  public createAccount(name: string, email?: string, pin?: string, targetExam = 'Bangladesh Civil Service (BCS)', dailyGoal = 15): UserAccount {
    const id = 'user_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const newProfile: UserProfile = {
      id,
      name: name.trim() || 'Aspirant',
      email: email?.trim(),
      pin: pin?.trim(),
      targetExam,
      dailyGoal,
      streak: 1,
      streakFreezes: 2,
      xp: 100,
      lastActiveDate: new Date().toISOString().slice(0, 10),
      theme: 'light',
      voiceLang: 'en-US',
      createdAt: new Date().toISOString()
    };

    const newProgress: UserProgressData = {
      mastered: [],
      revise: [],
      learn: [],
      saved: [],
      todayLearned: [],
      fluencyScores: {},
      dailyQuests: [...INITIAL_DAILY_QUESTS],
      customEnrichedDossiers: {},
      srsRecords: {},
      mistakesVault: [],
      activityLog: [
        {
          id: 'log_' + Date.now(),
          type: 'Account',
          text: `Account created for ${newProfile.name}`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          date: new Date().toISOString().slice(0, 10)
        }
      ]
    };

    this.accounts[id] = { profile: newProfile, progress: newProgress };
    this.activeUserId = id;
    this.saveToStorage();
    return this.accounts[id];
  }

  public switchAccount(userId: string, enteredPin?: string): { success: boolean; message?: string } {
    const acc = this.accounts[userId];
    if (!acc) return { success: false, message: 'Account not found.' };

    if (acc.profile.pin && acc.profile.pin.trim() !== '') {
      if (acc.profile.pin !== enteredPin?.trim()) {
        return { success: false, message: 'Incorrect 4-digit PIN.' };
      }
    }

    this.activeUserId = userId;
    this.logActivity('Login', `Logged in as ${acc.profile.name}`);
    this.checkAndIncrementStreak();
    this.saveToStorage();
    return { success: true };
  }

  public deleteAccount(userId: string): boolean {
    if (Object.keys(this.accounts).length <= 1) {
      return false; // Can't delete the only account
    }
    delete this.accounts[userId];
    if (this.activeUserId === userId) {
      this.activeUserId = Object.keys(this.accounts)[0];
    }
    this.saveToStorage();
    return true;
  }

  public updateProfile(updates: Partial<UserProfile>): UserProfile {
    const acc = this.getActiveAccount();
    acc.profile = { ...acc.profile, ...updates };
    this.saveToStorage();
    return acc.profile;
  }

  public checkAndAdvanceStreak(): {
    isFirstOpenToday: boolean;
    streakExtended: boolean;
    streakProtectedByFreeze: boolean;
    streakBroken: boolean;
    currentStreak: number;
    freezesLeft: number;
    yesterdayStreak: number;
  } {
    const acc = this.getActiveAccount();
    const today = new Date().toISOString().slice(0, 10);
    const lastActive = acc.profile.lastActiveDate;
    const currentStreak = acc.profile.streak || 1;
    let yesterdayStreak = currentStreak;

    // Default result if already opened today
    if (lastActive === today) {
      return {
        isFirstOpenToday: false,
        streakExtended: false,
        streakProtectedByFreeze: false,
        streakBroken: false,
        currentStreak: acc.profile.streak,
        freezesLeft: acc.profile.streakFreezes ?? 2,
        yesterdayStreak: Math.max(1, acc.profile.streak - 1),
      };
    }

    // Calculate calendar day difference
    const todayMs = new Date(today + 'T00:00:00Z').getTime();
    const lastMs = new Date((lastActive || today) + 'T00:00:00Z').getTime();
    const diffDays = Math.round((todayMs - lastMs) / 86400000);

    let streakExtended = false;
    let streakProtectedByFreeze = false;
    let streakBroken = false;

    if (diffDays === 1) {
      // Consecutive day!
      yesterdayStreak = acc.profile.streak;
      acc.profile.streak = (acc.profile.streak || 0) + 1;
      streakExtended = true;
      this.logActivity('Streak', `Daily streak extended to ${acc.profile.streak} days!`);
    } else if (diffDays === 2 && (acc.profile.streakFreezes ?? 0) > 0) {
      // Missed 1 day, but streak freeze shields the streak!
      yesterdayStreak = acc.profile.streak;
      acc.profile.streakFreezes = (acc.profile.streakFreezes ?? 2) - 1;
      acc.profile.streak = (acc.profile.streak || 1) + 1;
      streakProtectedByFreeze = true;
      this.logActivity('Streak', `Streak Freeze activated! Streak protected at ${acc.profile.streak} days.`);
    } else if (diffDays > 1) {
      // Streak lapsed
      yesterdayStreak = acc.profile.streak;
      acc.profile.streak = 1;
      streakBroken = true;
      this.logActivity('Streak', `Streak reset to 1 day. Let's build a new record!`);
    }

    acc.profile.lastActiveDate = today;
    acc.progress.todayLearned = []; // reset daily learned list for new day
    this.saveToStorage();

    return {
      isFirstOpenToday: true,
      streakExtended,
      streakProtectedByFreeze,
      streakBroken,
      currentStreak: acc.profile.streak,
      freezesLeft: acc.profile.streakFreezes ?? 2,
      yesterdayStreak,
    };
  }

  public checkAndIncrementStreak() {
    this.checkAndAdvanceStreak();
  }

  public buyStreakFreeze(costXp = 100): { success: boolean; message: string } {
    const acc = this.getActiveAccount();
    if ((acc.profile.streakFreezes ?? 0) >= 3) {
      return { success: false, message: 'Maximum 3 streak freezes reached!' };
    }
    if ((acc.profile.xp ?? 0) < costXp) {
      return { success: false, message: `Need ${costXp} XP to equip a freeze. Current XP: ${acc.profile.xp}` };
    }
    acc.profile.xp -= costXp;
    acc.profile.streakFreezes = (acc.profile.streakFreezes ?? 0) + 1;
    this.logActivity('Reward', `Purchased 1 Streak Freeze for ${costXp} XP`);
    this.saveToStorage();
    return { success: true, message: 'Streak Freeze equipped successfully!' };
  }

  public addXp(amount: number) {
    const acc = this.getActiveAccount();
    acc.profile.xp += amount;
    this.saveToStorage();
  }

  public toggleSavedWord(word: string): boolean {
    const acc = this.getActiveAccount();
    const isSaved = acc.progress.saved.includes(word);
    if (isSaved) {
      acc.progress.saved = acc.progress.saved.filter(w => w !== word);
      this.logActivity('Saved', `Removed '${word}' from bookmarks`);
    } else {
      acc.progress.saved.push(word);
      this.logActivity('Saved', `Saved '${word}' to bookmarks`);
    }
    this.saveToStorage();
    return !isSaved;
  }

  public setWordStatus(word: string, status: 'mastered' | 'revise' | 'learn') {
    const acc = this.getActiveAccount();
    acc.progress.mastered = acc.progress.mastered.filter(w => w !== word);
    acc.progress.revise = acc.progress.revise.filter(w => w !== word);
    acc.progress.learn = acc.progress.learn.filter(w => w !== word);

    if (status === 'mastered') {
      acc.progress.mastered.push(word);
      this.addXp(15);
      this.logActivity('Status', `Marked '${word}' as Group A (Known)`);
    } else if (status === 'revise') {
      acc.progress.revise.push(word);
      this.addXp(5);
      this.logActivity('Status', `Moved '${word}' to Group B (Revise)`);
    } else if (status === 'learn') {
      acc.progress.learn.push(word);
      this.logActivity('Status', `Added '${word}' to Group C (Learn)`);
    }

    if (!acc.progress.todayLearned.includes(word)) {
      acc.progress.todayLearned.push(word);
    }

    this.saveToStorage();
  }

  public recordWordView(word: string) {
    const acc = this.getActiveAccount();
    if (!acc.progress.todayLearned.includes(word)) {
      acc.progress.todayLearned.push(word);
      this.addXp(10);
      this.saveToStorage();
    }
  }

  public addMistake(word: string, wrongAns: string, correctAns: string, question: string, category = 'Synonym Nuance Trap') {
    const acc = this.getActiveAccount();
    acc.progress.mistakesVault = acc.progress.mistakesVault.filter(m => m.word !== word);
    acc.progress.mistakesVault.unshift({
      word,
      wrongAns,
      correctAns,
      question,
      category,
      timestamp: new Date().toLocaleDateString('en-GB')
    });

    // Automatically mark as 'learn'
    if (!acc.progress.learn.includes(word)) {
      acc.progress.mastered = acc.progress.mastered.filter(w => w !== word);
      acc.progress.revise = acc.progress.revise.filter(w => w !== word);
      acc.progress.learn.push(word);
    }

    this.logActivity('Mistake', `Added '${word}' to Mistakes Vault`);
    this.saveToStorage();
  }

  public dismissMistake(word: string) {
    const acc = this.getActiveAccount();
    acc.progress.mistakesVault = acc.progress.mistakesVault.filter(m => m.word !== word);
    this.setWordStatus(word, 'mastered');
    this.logActivity('Mistake', `Resolved weak word '${word}'`);
    this.saveToStorage();
  }

  public clearMistakes() {
    const acc = this.getActiveAccount();
    acc.progress.mistakesVault = [];
    this.saveToStorage();
  }

  public logActivity(type: string, text: string) {
    const acc = this.getActiveAccount();
    const item: ActivityLogItem = {
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5),
      type,
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      date: new Date().toISOString().slice(0, 10)
    };
    acc.progress.activityLog.unshift(item);
    if (acc.progress.activityLog.length > 60) {
      acc.progress.activityLog.pop();
    }
    this.saveToStorage();
  }

  public saveEnrichedDossier(dossier: WordData) {
    const acc = this.getActiveAccount();
    if (!acc.progress.customEnrichedDossiers) acc.progress.customEnrichedDossiers = {};
    acc.progress.customEnrichedDossiers[dossier.word.toLowerCase()] = dossier;
    this.logActivity('AI Dossier', `Enriched bespoke dossier for '${dossier.word}'`);
    this.saveToStorage();
  }

  public getEnrichedDossier(word: string): WordData | undefined {
    const acc = this.getActiveAccount();
    return acc.progress.customEnrichedDossiers?.[word.toLowerCase()];
  }

  public getFluency(word: string): number {
    const acc = this.getActiveAccount();
    if (acc.progress.fluencyScores?.[word] !== undefined) {
      return acc.progress.fluencyScores[word];
    }
    if (acc.progress.mastered.includes(word)) return 100;
    if (acc.progress.revise.includes(word)) return 50;
    if (acc.progress.learn.includes(word)) return 25;
    return 0;
  }

  public setFluency(word: string, score: number) {
    const acc = this.getActiveAccount();
    if (!acc.progress.fluencyScores) acc.progress.fluencyScores = {};
    const clamped = Math.max(0, Math.min(100, Math.round(score)));
    acc.progress.fluencyScores[word] = clamped;
    this.saveToStorage();
  }

  public updateQuestProgress(questId: string, delta = 1) {
    const acc = this.getActiveAccount();
    if (!acc.progress.dailyQuests) acc.progress.dailyQuests = [...INITIAL_DAILY_QUESTS];
    const quest = acc.progress.dailyQuests.find(q => q.id === questId);
    if (quest && !quest.completed) {
      quest.current = Math.min(quest.target, quest.current + delta);
      if (quest.current >= quest.target) {
        quest.completed = true;
        this.logActivity('Quest', `Completed daily mission: ${quest.title}!`);
      }
      this.saveToStorage();
    }
  }

  public claimQuestReward(questId: string): number {
    const acc = this.getActiveAccount();
    if (!acc.progress.dailyQuests) return 0;
    const quest = acc.progress.dailyQuests.find(q => q.id === questId);
    if (quest && quest.completed && !quest.claimed) {
      quest.claimed = true;
      this.addXp(quest.xpReward);
      this.logActivity('Reward', `Claimed +${quest.xpReward} XP for ${quest.title}`);
      this.saveToStorage();
      return quest.xpReward;
    }
    return 0;
  }

  public getSrsItem(word: string): SrsItem {
    const acc = this.getActiveAccount();
    if (!acc.progress.srsRecords) acc.progress.srsRecords = {};
    if (acc.progress.srsRecords[word]) {
      return acc.progress.srsRecords[word];
    }
    let status: 'mastered' | 'revise' | 'learn' | 'unassigned' = 'unassigned';
    if (acc.progress.mastered.includes(word)) status = 'mastered';
    else if (acc.progress.revise.includes(word)) status = 'revise';
    else if (acc.progress.learn.includes(word)) status = 'learn';

    const created = SrsEngine.createDefaultItem(word, status);
    acc.progress.srsRecords[word] = created;
    this.saveToStorage();
    return created;
  }

  public recordSrsReview(word: string, rating: SrsRating): { updatedItem: SrsItem; xpAwarded: number } {
    const acc = this.getActiveAccount();
    if (!acc.progress.srsRecords) acc.progress.srsRecords = {};
    const currentItem = this.getSrsItem(word);

    const { updatedItem, fluencyRecommendation } = SrsEngine.reviewWord(currentItem, rating);
    acc.progress.srsRecords[word] = updatedItem;

    // Sync fluency score
    if (!acc.progress.fluencyScores) acc.progress.fluencyScores = {};
    acc.progress.fluencyScores[word] = fluencyRecommendation;

    // Update cognitive category grouping if advanced or lapsed
    if (rating === 'again') {
      acc.progress.mastered = acc.progress.mastered.filter(w => w !== word);
      if (!acc.progress.revise.includes(word)) acc.progress.revise.push(word);
      acc.progress.learn = acc.progress.learn.filter(w => w !== word);
    } else if (updatedItem.stage >= 4) {
      if (!acc.progress.mastered.includes(word)) acc.progress.mastered.push(word);
      acc.progress.revise = acc.progress.revise.filter(w => w !== word);
      acc.progress.learn = acc.progress.learn.filter(w => w !== word);
    }

    // Award XP based on rating
    let xp = 15;
    if (rating === 'easy') xp = 25;
    else if (rating === 'good') xp = 15;
    else if (rating === 'hard') xp = 10;
    else if (rating === 'again') xp = 5;

    this.addXp(xp);

    if (!acc.progress.todayLearned.includes(word)) {
      acc.progress.todayLearned.push(word);
    }

    this.updateQuestProgress('quest_sprint', 1);
    this.logActivity('SRS Review', `Ebbinghaus review for '${word}': rated ${rating.toUpperCase()} (Stage ${updatedItem.stage})`);
    this.saveToStorage();

    return { updatedItem, xpAwarded: xp };
  }

  public exportBackupJson(): string {
    return JSON.stringify(this.accounts, null, 2);
  }

  public importBackupJson(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (typeof parsed === 'object' && parsed !== null) {
        this.accounts = parsed;
        this.activeUserId = Object.keys(this.accounts)[0] || DEFAULT_PROFILE.id;
        this.saveToStorage();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }
}

export const storage = new StorageService();
