import { Achievement, AudioSettings, GameMode, GameStats, GridCell, PlacedPieceItem, PowerUpState } from '../types/game';

const STORAGE_KEYS = {
  HIGH_SCORE: 'astrablock_high_score',
  STATS: 'astrablock_stats',
  SETTINGS: 'astrablock_settings',
  SAVED_GAME_PREFIX: 'astrablock_saved_game_',
  POWER_UPS: 'astrablock_powerups',
};

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_blast',
    title: 'First Ignition',
    description: 'Blast your first full row or column',
    icon: 'Sparkles',
    unlocked: false,
  },
  {
    id: 'multi_blast',
    title: 'Double Trouble',
    description: 'Clear 2 lines in a single drop',
    icon: 'Zap',
    unlocked: false,
  },
  {
    id: 'supernova',
    title: 'Supernova Blast',
    description: 'Clear 3 or more lines simultaneously',
    icon: 'Sun',
    unlocked: false,
  },
  {
    id: 'combo_flame',
    title: 'Combo Striker',
    description: 'Reach a 3x Combo streak',
    icon: 'Flame',
    unlocked: false,
  },
  {
    id: 'combo_titan',
    title: 'Combo Titan',
    description: 'Achieve a 5x or higher Combo streak',
    icon: 'Crown',
    unlocked: false,
  },
  {
    id: 'century_scorer',
    title: 'Starlight Novice',
    description: 'Score 1,000 points in any mode',
    icon: 'Star',
    unlocked: false,
  },
  {
    id: 'master_scorer',
    title: 'Cosmic Overlord',
    description: 'Score 3,500 points in any mode',
    icon: 'Trophy',
    unlocked: false,
  },
  {
    id: 'bomb_defuser',
    title: 'Bomb Squad',
    description: 'Defuse 5 cosmic bombs in Solar Bomb mode',
    icon: 'Shield',
    unlocked: false,
  },
  {
    id: 'clean_slate',
    title: 'Perfect Clear',
    description: 'Completely empty the entire 10x10 board',
    icon: 'Award',
    unlocked: false,
  },
  {
    id: 'block_builder',
    title: 'Master Mason',
    description: 'Place 200 blocks across games',
    icon: 'Grid',
    unlocked: false,
  },
];

const DEFAULT_SETTINGS: AudioSettings = {
  sfxVolume: 0.8,
  sfxEnabled: true,
  musicVolume: 0.45,
  musicEnabled: true,
  touchOffsetEnabled: true,
  hapticsEnabled: true,
  activeTheme: 'cosmic',
  activeBlockStyle: 'crystalline',
};

const DEFAULT_STATS: GameStats = {
  highScore: 0,
  rushHighScore: 0,
  bombHighScore: 0,
  gamesPlayed: 0,
  totalLinesCleared: 0,
  highestCombo: 0,
  totalBlocksPlaced: 0,
  bombsDefused: 0,
  perfectClears: 0,
  achievements: INITIAL_ACHIEVEMENTS,
};

export const DEFAULT_POWER_UPS: PowerUpState = {
  hammerCount: 2,
  rerollCount: 2,
  bombBlastCount: 1,
  activePowerUp: null,
};

export interface SavedGameState {
  mode: GameMode;
  grid: GridCell[][];
  pieces: PlacedPieceItem[];
  score: number;
  comboStreak: number;
  timeLeft?: number;
  timestamp: number;
}

export function loadSettings(): AudioSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AudioSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadPowerUps(): PowerUpState {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.POWER_UPS);
    if (!raw) return DEFAULT_POWER_UPS;
    return { ...DEFAULT_POWER_UPS, ...JSON.parse(raw), activePowerUp: null };
  } catch {
    return DEFAULT_POWER_UPS;
  }
}

export function savePowerUps(powerUps: PowerUpState): void {
  try {
    localStorage.setItem(STORAGE_KEYS.POWER_UPS, JSON.stringify(powerUps));
  } catch {
    // Ignore
  }
}

export function loadStats(): GameStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.STATS);
    const legacyHighScore = Number(localStorage.getItem(STORAGE_KEYS.HIGH_SCORE) || 0);
    if (!raw) {
      return { ...DEFAULT_STATS, highScore: legacyHighScore };
    }
    const parsed = JSON.parse(raw);
    
    // Merge existing achievements with any new ones added to the schema
    const mergedAchievements = INITIAL_ACHIEVEMENTS.map(initial => {
      const existing = (parsed.achievements || []).find((a: Achievement) => a.id === initial.id);
      return existing ? { ...initial, ...existing } : initial;
    });

    return {
      ...DEFAULT_STATS,
      ...parsed,
      highScore: Math.max(parsed.highScore || 0, legacyHighScore),
      achievements: mergedAchievements,
    };
  } catch {
    return DEFAULT_STATS;
  }
}

export function saveStats(stats: GameStats): void {
  try {
    localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(stats));
    localStorage.setItem(STORAGE_KEYS.HIGH_SCORE, stats.highScore.toString());
  } catch {
    // Ignore
  }
}

export function evaluateAchievements(
  stats: GameStats,
  currentScore: number,
  linesClearedThisMove: number,
  currentCombo: number,
  isPerfectClear: boolean
): { updatedStats: GameStats; newlyUnlocked: Achievement[] } {
  const newlyUnlocked: Achievement[] = [];
  const updatedAchievements = stats.achievements.map((ach) => {
    if (ach.unlocked) return ach;

    let shouldUnlock = false;

    if (ach.id === 'first_blast' && linesClearedThisMove >= 1) shouldUnlock = true;
    if (ach.id === 'multi_blast' && linesClearedThisMove >= 2) shouldUnlock = true;
    if (ach.id === 'supernova' && linesClearedThisMove >= 3) shouldUnlock = true;
    if (ach.id === 'combo_flame' && currentCombo >= 3) shouldUnlock = true;
    if (ach.id === 'combo_titan' && currentCombo >= 5) shouldUnlock = true;
    if (ach.id === 'century_scorer' && currentScore >= 1000) shouldUnlock = true;
    if (ach.id === 'master_scorer' && currentScore >= 3500) shouldUnlock = true;
    if (ach.id === 'clean_slate' && isPerfectClear) shouldUnlock = true;
    if (ach.id === 'bomb_defuser' && stats.bombsDefused >= 5) shouldUnlock = true;
    if (ach.id === 'block_builder' && stats.totalBlocksPlaced >= 200) shouldUnlock = true;

    if (shouldUnlock) {
      const unlockedAch = { ...ach, unlocked: true, unlockedAt: Date.now() };
      newlyUnlocked.push(unlockedAch);
      return unlockedAch;
    }

    return ach;
  });

  const updatedStats = { ...stats, achievements: updatedAchievements };
  if (newlyUnlocked.length > 0) {
    saveStats(updatedStats);
  }
  return { updatedStats, newlyUnlocked };
}

export function updateEndGameStats(
  mode: GameMode,
  finalScore: number,
  linesClearedThisGame: number,
  maxComboThisGame: number,
  blocksPlacedThisGame: number,
  bombsDefusedThisGame: number = 0,
  perfectClearsThisGame: number = 0
): { stats: GameStats; isNewHighScore: boolean } {
  const currentStats = loadStats();
  
  let isNewHighScore = false;
  let newClassicHigh = currentStats.highScore;
  let newRushHigh = currentStats.rushHighScore;
  let newBombHigh = currentStats.bombHighScore;

  if (mode === 'CLASSIC') {
    isNewHighScore = finalScore > currentStats.highScore;
    newClassicHigh = Math.max(currentStats.highScore, finalScore);
  } else if (mode === 'RUSH') {
    isNewHighScore = finalScore > currentStats.rushHighScore;
    newRushHigh = Math.max(currentStats.rushHighScore, finalScore);
  } else if (mode === 'BOMB') {
    isNewHighScore = finalScore > currentStats.bombHighScore;
    newBombHigh = Math.max(currentStats.bombHighScore, finalScore);
  }

  const newStats: GameStats = {
    ...currentStats,
    highScore: newClassicHigh,
    rushHighScore: newRushHigh,
    bombHighScore: newBombHigh,
    gamesPlayed: currentStats.gamesPlayed + 1,
    totalLinesCleared: currentStats.totalLinesCleared + linesClearedThisGame,
    highestCombo: Math.max(currentStats.highestCombo, maxComboThisGame),
    totalBlocksPlaced: currentStats.totalBlocksPlaced + blocksPlacedThisGame,
    bombsDefused: currentStats.bombsDefused + bombsDefusedThisGame,
    perfectClears: currentStats.perfectClears + perfectClearsThisGame,
  };

  saveStats(newStats);
  return { stats: newStats, isNewHighScore };
}

export function saveActiveGame(mode: GameMode, gameState: SavedGameState | null): void {
  try {
    const key = `${STORAGE_KEYS.SAVED_GAME_PREFIX}${mode}`;
    if (!gameState) {
      localStorage.removeItem(key);
    } else {
      localStorage.setItem(key, JSON.stringify(gameState));
    }
  } catch {
    // Ignore
  }
}

export function loadActiveGame(mode: GameMode): SavedGameState | null {
  try {
    const key = `${STORAGE_KEYS.SAVED_GAME_PREFIX}${mode}`;
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SavedGameState;
    if (Date.now() - parsed.timestamp > 7 * 24 * 60 * 60 * 1000) {
      localStorage.removeItem(key);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function hasAnySavedGame(): boolean {
  return !!(
    loadActiveGame('CLASSIC') ||
    loadActiveGame('RUSH') ||
    loadActiveGame('BOMB')
  );
}

export function clearAllStats(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.STATS);
    localStorage.removeItem(STORAGE_KEYS.HIGH_SCORE);
    localStorage.removeItem(STORAGE_KEYS.POWER_UPS);
    localStorage.removeItem(`${STORAGE_KEYS.SAVED_GAME_PREFIX}CLASSIC`);
    localStorage.removeItem(`${STORAGE_KEYS.SAVED_GAME_PREFIX}RUSH`);
    localStorage.removeItem(`${STORAGE_KEYS.SAVED_GAME_PREFIX}BOMB`);
  } catch {
    // Ignore
  }
}
