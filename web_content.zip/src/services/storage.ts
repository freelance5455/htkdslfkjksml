import { Project, ExportedProjectRecord, UserSubscription } from '../types/editor';

const DB_NAME = 'clipora_db';
const DB_VERSION = 2;

export interface StorageStats {
  projectCount: number;
  exportCount: number;
  estimatedBytesUsed: number;
}

class StorageService {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private initDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('projects')) {
          const projectStore = db.createObjectStore('projects', { keyPath: 'id' });
          projectStore.createIndex('updatedAt', 'updatedAt', { unique: false });
        }
        if (!db.objectStoreNames.contains('exports')) {
          const exportStore = db.createObjectStore('exports', { keyPath: 'id' });
          exportStore.createIndex('timestamp', 'timestamp', { unique: false });
        }
        if (!db.objectStoreNames.contains('blobs')) {
          db.createObjectStore('blobs', { keyPath: 'key' });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });

    return this.dbPromise;
  }

  // --- Projects ---
  async saveProject(project: Project): Promise<void> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('projects', 'readwrite');
      const store = tx.objectStore('projects');
      const updated = { ...project, updatedAt: Date.now() };
      const req = store.put(updated);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getProject(id: string): Promise<Project | null> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('projects', 'readonly');
      const store = tx.objectStore('projects');
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getAllProjects(): Promise<Project[]> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('projects', 'readonly');
      const store = tx.objectStore('projects');
      const index = store.index('updatedAt');
      const req = index.getAll();
      req.onsuccess = () => {
        const list = (req.result as Project[]) || [];
        resolve(list.reverse()); // most recently updated first
      };
      req.onerror = () => reject(req.error);
    });
  }

  async deleteProject(id: string): Promise<void> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('projects', 'readwrite');
      const store = tx.objectStore('projects');
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // --- Exported Videos History ---
  async saveExportRecord(record: ExportedProjectRecord, videoBlob?: Blob): Promise<void> {
    const db = await this.initDB();
    if (videoBlob) {
      await this.saveBlob(`export_${record.id}`, videoBlob);
    }
    return new Promise((resolve, reject) => {
      const tx = db.transaction('exports', 'readwrite');
      const store = tx.objectStore('exports');
      const req = store.put(record);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getAllExportRecords(): Promise<ExportedProjectRecord[]> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('exports', 'readonly');
      const store = tx.objectStore('exports');
      const index = store.index('timestamp');
      const req = index.getAll();
      req.onsuccess = () => {
        const list = (req.result as ExportedProjectRecord[]) || [];
        resolve(list.reverse());
      };
      req.onerror = () => reject(req.error);
    });
  }

  async deleteExportRecord(id: string): Promise<void> {
    const db = await this.initDB();
    await this.deleteBlob(`export_${id}`);
    return new Promise((resolve, reject) => {
      const tx = db.transaction('exports', 'readwrite');
      const store = tx.objectStore('exports');
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // --- Blob Storage for Offline Media ---
  async saveBlob(key: string, blob: Blob): Promise<void> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('blobs', 'readwrite');
      const store = tx.objectStore('blobs');
      const req = store.put({ key, blob });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getBlob(key: string): Promise<Blob | null> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('blobs', 'readonly');
      const store = tx.objectStore('blobs');
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ? req.result.blob : null);
      req.onerror = () => reject(req.error);
    });
  }

  async deleteBlob(key: string): Promise<void> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('blobs', 'readwrite');
      const store = tx.objectStore('blobs');
      const req = store.delete(key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // --- Subscription Entitlement ---
  getSubscription(): UserSubscription {
    return {
      isPremium: true,
      plan: 'pro_free_forever',
    };
  }

  saveSubscription(sub: UserSubscription): void {
    localStorage.setItem('clipora_subscription', JSON.stringify(sub));
  }

  // --- Storage Stats & Cache Clearing ---
  async getStorageStats(): Promise<StorageStats> {
    const projects = await this.getAllProjects();
    const exports = await this.getAllExportRecords();
    let estimatedBytes = 0;
    if (navigator.storage && navigator.storage.estimate) {
      const estimate = await navigator.storage.estimate();
      estimatedBytes = estimate.usage || 0;
    }
    return {
      projectCount: projects.length,
      exportCount: exports.length,
      estimatedBytesUsed: estimatedBytes,
    };
  }

  async clearCache(): Promise<void> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(['blobs'], 'readwrite');
      const store = tx.objectStore('blobs');
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }
}

export const storageService = new StorageService();
