// Massive 10,000+ GK Question Engine & Trivia Bank
// High-yield procedural generator and curated database for India & World General Knowledge

export interface GkQuestion {
  id: string;
  question: string;
  questionBn: string;
  category: string;
  options: string[];
  optionsBn: string[];
  correctIndex: number;
  difficulty: 'easy' | 'medium' | 'hard';
  explanation?: string;
  explanationBn?: string;
}

// 1. World Countries, Capitals, Currencies & Continents Database
export const WORLD_COUNTRIES = [
  { country: 'India', countryBn: 'ভারত', capital: 'New Delhi', capitalBn: 'নতুন দিল্লি', currency: 'Indian Rupee (INR)', currencyBn: 'ভারতীয় রুপি', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Bangladesh', countryBn: 'বাংলাদেশ', capital: 'Dhaka', capitalBn: 'ঢাকা', currency: 'Bangladeshi Taka', currencyBn: 'বাংলাদেশি টাকা', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Japan', countryBn: 'জাপান', capital: 'Tokyo', capitalBn: 'টোকিও', currency: 'Japanese Yen', currencyBn: 'জাপানি ইয়েন', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'France', countryBn: 'ফ্রান্স', capital: 'Paris', capitalBn: 'প্যারিস', currency: 'Euro', currencyBn: 'ইউরো', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'Germany', countryBn: 'জার্মানি', capital: 'Berlin', capitalBn: 'বার্লিন', currency: 'Euro', currencyBn: 'ইউরো', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'United Kingdom', countryBn: 'যুক্তরাজ্য (UK)', capital: 'London', capitalBn: 'লন্ডন', currency: 'Pound Sterling', currencyBn: 'পাউন্ড স্টার্লিং', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'United States', countryBn: 'যুক্তরাষ্ট্র (USA)', capital: 'Washington, D.C.', capitalBn: 'ওয়াশিংটন ডিসি', currency: 'US Dollar', currencyBn: 'মার্কিন ডলার', continent: 'North America', continentBn: 'উত্তর আমেরিকা' },
  { country: 'Canada', countryBn: 'কানাডা', capital: 'Ottawa', capitalBn: 'অটোয়া', currency: 'Canadian Dollar', currencyBn: 'কানাডিয়ান ডলার', continent: 'North America', continentBn: 'উত্তর আমেরিকা' },
  { country: 'Australia', countryBn: 'অস্ট্রেলিয়া', capital: 'Canberra', capitalBn: 'ক্যানবেরা', currency: 'Australian Dollar', currencyBn: 'অস্ট্রেলিয়ান ডলার', continent: 'Oceania', continentBn: 'ওশেনিয়া' },
  { country: 'Russia', countryBn: 'রাশিয়া', capital: 'Moscow', capitalBn: 'মস্কো', currency: 'Russian Ruble', currencyBn: 'রাশিয়ান রুবল', continent: 'Europe/Asia', continentBn: 'ইউরেশিয়া' },
  { country: 'China', countryBn: 'চীন', capital: 'Beijing', capitalBn: 'বেইজিং', currency: 'Chinese Yuan (Renminbi)', currencyBn: 'চীনা ইউয়ান', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Brazil', countryBn: 'ব্রাজিল', capital: 'Brasília', capitalBn: 'ব্রাসিলিয়া', currency: 'Brazilian Real', currencyBn: 'ব্রাজিলিয়ান রিয়াল', continent: 'South America', continentBn: 'দক্ষিণ আমেরিকা' },
  { country: 'Argentina', countryBn: 'আর্জেন্টিনা', capital: 'Buenos Aires', capitalBn: 'বুয়েনস আইরেস', currency: 'Argentine Peso', currencyBn: 'আর্জেন্টাইন পেসো', continent: 'South America', continentBn: 'দক্ষিণ আমেরিকা' },
  { country: 'Egypt', countryBn: 'মিশর', capital: 'Cairo', capitalBn: 'কায়রো', currency: 'Egyptian Pound', currencyBn: 'মিশরীয় পাউন্ড', continent: 'Africa', continentBn: 'আফ্রিকা' },
  { country: 'South Africa', countryBn: 'দক্ষিণ আফ্রিকা', capital: 'Pretoria', capitalBn: 'প্রিটোরিয়া', currency: 'South African Rand', currencyBn: 'সাউথ আফ্রিকান র্যান্ড', continent: 'Africa', continentBn: 'আফ্রিকা' },
  { country: 'Saudi Arabia', countryBn: 'সৌদি আরব', capital: 'Riyadh', capitalBn: 'রিয়াদ', currency: 'Saudi Riyal', currencyBn: 'সৌদি রিয়াল', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'United Arab Emirates (UAE)', countryBn: 'সংযুক্ত আরব আমিরাত (UAE)', capital: 'Abu Dhabi', capitalBn: 'আবুধাবি', currency: 'UAE Dirham', currencyBn: 'ইউএই দিরহাম', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Italy', countryBn: 'ইতালি', capital: 'Rome', capitalBn: 'রোম', currency: 'Euro', currencyBn: 'ইউরো', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'Spain', countryBn: 'স্পেন', capital: 'Madrid', capitalBn: 'মাদ্রিদ', currency: 'Euro', currencyBn: 'ইউরো', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'South Korea', countryBn: 'দক্ষিণ কোরিয়া', capital: 'Seoul', capitalBn: 'সিউল', currency: 'South Korean Won', currencyBn: 'দক্ষিণ কোরিয়ান ওন', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Thailand', countryBn: 'থাইল্যান্ড', capital: 'Bangkok', capitalBn: 'ব্যাংকক', currency: 'Thai Baht', currencyBn: 'থাই বাত', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Singapore', countryBn: 'সিঙ্গাপুর', capital: 'Singapore City', capitalBn: 'সিঙ্গাপুর শহর', currency: 'Singapore Dollar', currencyBn: 'সিঙ্গাপুর ডলার', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Malaysia', countryBn: 'মালয়েশিয়া', capital: 'Kuala Lumpur', capitalBn: 'কুয়ালালামপুর', currency: 'Malaysian Ringgit', currencyBn: 'মালয়েশিয়ান রিঙ্গিত', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Sri Lanka', countryBn: 'শ্রীলঙ্কা', capital: 'Sri Jayawardenepura Kotte', capitalBn: 'শ্রী জয়বর্ধনেপুরা কোট্টে', currency: 'Sri Lankan Rupee', currencyBn: 'শ্রীলঙ্কান রুপি', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Nepal', countryBn: 'নেপাল', capital: 'Kathmandu', capitalBn: 'কাঠমান্ডু', currency: 'Nepalese Rupee', currencyBn: 'নেপালি রুপি', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Bhutan', countryBn: 'ভুটান', capital: 'Thimphu', capitalBn: 'থিম্পু', currency: 'Bhutanese Ngultrum', currencyBn: 'ভুটানি এনগুল্ট্রাম', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'New Zealand', countryBn: 'নিউজিল্যান্ড', capital: 'Wellington', capitalBn: 'ওয়েলিংটন', currency: 'NZ Dollar', currencyBn: 'নিউজিল্যান্ড ডলার', continent: 'Oceania', continentBn: 'ওশেনিয়া' },
  { country: 'Switzerland', countryBn: 'সুইজারল্যান্ড', capital: 'Bern', capitalBn: 'বার্ন', currency: 'Swiss Franc', currencyBn: 'সুইস ফ্রাঁ', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'Netherlands', countryBn: 'নেদারল্যান্ডস', capital: 'Amsterdam', capitalBn: 'আমস্টারডাম', currency: 'Euro', currencyBn: 'ইউরো', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'Sweden', countryBn: 'সুইডেন', capital: 'Stockholm', capitalBn: 'স্টকহোম', currency: 'Swedish Krona', currencyBn: 'সুইডিশ ক্রোনা', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'Norway', countryBn: 'নরওয়ে', capital: 'Oslo', capitalBn: 'অসলো', currency: 'Norwegian Krone', currencyBn: 'নরওয়েজিয়ান ক্রোন', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'Mexico', countryBn: 'মেক্সিকো', capital: 'Mexico City', capitalBn: 'মেক্সিকো সিটি', currency: 'Mexican Peso', currencyBn: 'মেক্সিকান পেসো', continent: 'North America', continentBn: 'উত্তর আমেরিকা' },
  { country: 'Turkey', countryBn: 'তুরস্ক', capital: 'Ankara', capitalBn: 'আঙ্কারা', currency: 'Turkish Lira', currencyBn: 'তুর্কি লিরা', continent: 'Europe/Asia', continentBn: 'ইউরেশিয়া' },
  { country: 'Kenya', countryBn: 'কেনিয়া', capital: 'Nairobi', capitalBn: 'নাইরোবি', currency: 'Kenyan Shilling', currencyBn: 'কেনিয়ান শিলিং', continent: 'Africa', continentBn: 'আফ্রিকা' },
  { country: 'Nigeria', countryBn: 'নাইজেরিয়া', capital: 'Abuja', capitalBn: 'আবুজা', currency: 'Nigerian Naira', currencyBn: 'নাইজেরিয়ান নাইরা', continent: 'Africa', continentBn: 'আফ্রিকা' },
  { country: 'Portugal', countryBn: 'পর্তুগাল', capital: 'Lisbon', capitalBn: 'লিসবন', currency: 'Euro', currencyBn: 'ইউরো', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'Greece', countryBn: 'গ্রীস', capital: 'Athens', capitalBn: 'অ্যাথেন্স', currency: 'Euro', currencyBn: 'ইউরো', continent: 'Europe', continentBn: 'ইউরোপ' },
  { country: 'Indonesia', countryBn: 'ইন্দোনেশিয়া', capital: 'Jakarta', capitalBn: 'জাকার্তা', currency: 'Indonesian Rupiah', currencyBn: 'ইন্দোনেশিয়ান রূপিয়া', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Vietnam', countryBn: 'ভিয়েতনাম', capital: 'Hanoi', capitalBn: 'হ্যানয়', currency: 'Vietnamese Dong', currencyBn: 'ভিয়েতনামিজ ডং', continent: 'Asia', continentBn: 'এশিয়া' },
  { country: 'Qatar', countryBn: 'কাতার', capital: 'Doha', capitalBn: 'দোহা', currency: 'Qatari Riyal', currencyBn: 'কাতারি রিয়াল', continent: 'Asia', continentBn: 'এশিয়া' }
];

// 2. Indian States, Capitals & Official Features
export const INDIAN_STATES = [
  { state: 'West Bengal', stateBn: 'পশ্চিমবঙ্গ', capital: 'Kolkata', capitalBn: 'কলকাতা', language: 'Bengali', river: 'Hooghly / Ganga' },
  { state: 'Maharashtra', stateBn: 'মহারাষ্ট্র', capital: 'Mumbai', capitalBn: 'মুম্বাই', language: 'Marathi', river: 'Godavari' },
  { state: 'Tamil Nadu', stateBn: 'তামিলনাড়ু', capital: 'Chennai', capitalBn: 'চেন্নাই', language: 'Tamil', river: 'Cauvery' },
  { state: 'Karnataka', stateBn: 'কর্ণাটক', capital: 'Bengaluru', capitalBn: 'বেঙ্গালুরু', language: 'Kannada', river: 'Krishna' },
  { state: 'Telangana', stateBn: 'তেলেঙ্গানা', capital: 'Hyderabad', capitalBn: 'হায়দ্রাবাদ', language: 'Telugu', river: 'Musi' },
  { state: 'Gujarat', stateBn: 'গুজরাট', capital: 'Gandhinagar', capitalBn: 'গান্ধীনগর', language: 'Gujarati', river: 'Sabarmati' },
  { state: 'Rajasthan', stateBn: 'রাজস্থান', capital: 'Jaipur', capitalBn: 'জয়পুর', language: 'Hindi/Rajasthani', river: 'Chambal' },
  { state: 'Uttar Pradesh', stateBn: 'উত্তর প্রদেশ', capital: 'Lucknow', capitalBn: 'লখনউ', language: 'Hindi/Urdu', river: 'Gomti' },
  { state: 'Bihar', stateBn: 'বিহার', capital: 'Patna', capitalBn: 'পাটনা', language: 'Hindi/Bhojpuri', river: 'Ganga' },
  { state: 'Kerala', stateBn: 'কেরালা', capital: 'Thiruvananthapuram', capitalBn: 'তিরুবনন্তপুরম', language: 'Malayalam', river: 'Periyar' },
  { state: 'Assam', stateBn: 'আসাম', capital: 'Dispur', capitalBn: 'দিসপুর', language: 'Assamese', river: 'Brahmaputra' },
  { state: 'Punjab', stateBn: 'পাঞ্জাব', capital: 'Chandigarh', capitalBn: 'চণ্ডীগড়', language: 'Punjabi', river: 'Sutlej' },
  { state: 'Odisha', stateBn: 'ওড়িশা', capital: 'Bhubaneswar', capitalBn: 'ভুবনেশ্বর', language: 'Odia', river: 'Mahanadi' },
  { state: 'Madhya Pradesh', stateBn: 'মধ্যপ্রদেশ', capital: 'Bhopal', capitalBn: 'ভোপাল', language: 'Hindi', river: 'Narmada' },
  { state: 'Andhra Pradesh', stateBn: 'অন্ধ্রপ্রদেশ', capital: 'Amaravati', capitalBn: 'অমরাবতী', language: 'Telugu', river: 'Godavari' },
  { state: 'Goa', stateBn: 'গোয়া', capital: 'Panaji', capitalBn: 'পানাজি', language: 'Konkani', river: 'Mandovi' },
  { state: 'Himachal Pradesh', stateBn: 'হিমাচল প্রদেশ', capital: 'Shimla', capitalBn: 'শিমলা', language: 'Hindi', river: 'Beas' },
  { state: 'Uttarakhand', stateBn: 'উত্তরাখণ্ড', capital: 'Dehradun', capitalBn: 'দেরাদুন', language: 'Hindi', river: 'Ganga' },
  { state: 'Jammu and Kashmir', stateBn: 'জম্মু ও কাশ্মীর', capital: 'Srinagar (Summer) / Jammu (Winter)', capitalBn: 'শ্রীনগর / জম্মু', language: 'Urdu/Kashmiri', river: 'Jhelum' },
  { state: 'Sikkim', stateBn: 'সিকিম', capital: 'Gangtok', capitalBn: 'গ্যাংটক', language: 'Nepali/English', river: 'Teesta' }
];

// 3. World & Indian Monuments
export const MONUMENTS_DATA = [
  { monument: 'Taj Mahal', monumentBn: 'তাজমহল', location: 'Agra, Uttar Pradesh', locationBn: 'আগ্রা, উত্তর প্রদেশ', builtBy: 'Mughal Emperor Shah Jahan' },
  { monument: 'Victoria Memorial', monumentBn: 'ভিক্টোরিয়া মেমোরিয়াল', location: 'Kolkata, West Bengal', locationBn: 'কলকাতা, পশ্চিমবঙ্গ', builtBy: 'British Empire (Lord Curzon)' },
  { monument: 'Qutub Minar', monumentBn: 'কুতুব মিনার', location: 'New Delhi', locationBn: 'নতুন দিল্লি', builtBy: 'Qutb-ud-din Aibak' },
  { monument: 'Hawa Mahal (Palace of Winds)', monumentBn: 'হাওয়া মহল', location: 'Jaipur, Rajasthan', locationBn: 'জয়পুর, রাজস্থান', builtBy: 'Maharaja Sawai Pratap Singh' },
  { monument: 'Gateway of India', monumentBn: 'গেটওয়ে অফ ইন্ডিয়া', location: 'Mumbai, Maharashtra', locationBn: 'মুম্বাই, মহারাষ্ট্র', builtBy: 'British Administration (1924)' },
  { monument: 'Golden Temple (Harmandir Sahib)', monumentBn: 'স্বর্ণ মন্দির', location: 'Amritsar, Punjab', locationBn: 'অমৃতসর, পাঞ্জাব', builtBy: 'Guru Arjan Dev' },
  { monument: 'Konark Sun Temple', monumentBn: 'কোণার্ক সূর্য মন্দির', location: 'Puri, Odisha', locationBn: 'পুরী, ওড়িশা', builtBy: 'King Narasimhadeva I' },
  { monument: 'Charminar', monumentBn: 'চারমিনার', location: 'Hyderabad, Telangana', locationBn: 'হায়দ্রাবাদ, তেলেঙ্গানা', builtBy: 'Muhammad Quli Qutb Shah' },
  { monument: 'Howrah Bridge (Rabindra Setu)', monumentBn: 'হাওড়া ব্রিজ (রবীন্দ্র সেতু)', location: 'Kolkata / Howrah', locationBn: 'কলকাতা / হাওড়া', builtBy: 'Cantilever Bridge over Hooghly' },
  { monument: 'Statue of Unity (World\'s Tallest Statue)', monumentBn: 'স্ট্যাচু অফ ইউনিটি', location: 'Kevadia, Gujarat', locationBn: 'কেভাড়িয়া, গুজরাট', builtBy: 'Tribute to Sardar Vallabhbhai Patel' }
];

// 4. Inventions & Scientists
export const INVENTIONS_DATA = [
  { item: 'Penicillin (First modern antibiotic)', itemBn: 'পেনিসিলিন অ্যান্টিবায়োটিক', inventor: 'Alexander Fleming', inventorBn: 'আলেকজান্ডার ফ্লেমিং' },
  { item: 'Telephone', itemBn: 'টেলিফোন', inventor: 'Alexander Graham Bell', inventorBn: 'আলেকজান্ডার গ্রাহাম বেল' },
  { item: 'Electric Light Bulb', itemBn: 'বৈদ্যুতিক আলোর বাল্ব', inventor: 'Thomas Alva Edison', inventorBn: 'থমাস আলভা এডিসন' },
  { item: 'Aeroplane', itemBn: 'উড়োজাহাজ (বিমান)', inventor: 'Wright Brothers (Orville & Wilbur)', inventorBn: 'রাইট ভ্রাতৃদ্বয়' },
  { item: 'World Wide Web (WWW)', itemBn: 'ওয়ার্ল্ড ওয়াইড ওয়েব (WWW)', inventor: 'Tim Berners-Lee', inventorBn: 'টিম বার্নার্স-লি' },
  { item: 'Universal Law of Gravitation & Laws of Motion', itemBn: 'মহাকর্ষ সূত্র ও গতির নিয়ম', inventor: 'Sir Isaac Newton', inventorBn: 'স্যার আইজ্যাক নিউটন' },
  { item: 'Radio Communication', itemBn: 'বেতার (রেডিও) যোগাযোগ', inventor: 'Guglielmo Marconi & J.C. Bose', inventorBn: 'মার্কোনি ও জগদীশচন্দ্র বসু' },
  { item: 'Modern Computer', itemBn: 'কম্পিউটার', inventor: 'Charles Babbage', inventorBn: 'চার্লস ব্যাবেজ' },
  { item: 'Steam Engine', itemBn: 'বাষ্পীয় ইঞ্জিন', inventor: 'James Watt', inventorBn: 'জেমস ওয়াট' },
  { item: 'Polio Vaccine', itemBn: 'পোলিও টিকা', inventor: 'Dr. Jonas Salk', inventorBn: 'ডা. জোনাস সল্ক' }
];

// 5. Science & Chemical Elements
export const SCIENCE_ELEMENTS = [
  { element: 'Gold', elementBn: 'সোনা', symbol: 'Au', fact: 'Latin name Aurum' },
  { element: 'Silver', elementBn: 'রূপা', symbol: 'Ag', fact: 'Latin name Argentum' },
  { element: 'Iron', elementBn: 'লোহা', symbol: 'Fe', fact: 'Latin name Ferrum' },
  { element: 'Sodium', elementBn: 'সোডিয়াম', symbol: 'Na', fact: 'Latin name Natrium' },
  { element: 'Potassium', elementBn: 'পটাশিয়াম', symbol: 'K', fact: 'Latin name Kalium' },
  { element: 'Copper', elementBn: 'তামা', symbol: 'Cu', fact: 'Latin name Cuprum' },
  { element: 'Mercury (Liquid metal at room temp)', elementBn: 'পারদ', symbol: 'Hg', fact: 'Latin name Hydrargyrum' },
  { element: 'Lead', elementBn: 'সিসা', symbol: 'Pb', fact: 'Latin name Plumbum' },
  { element: 'Tin', elementBn: 'টিন', symbol: 'Sn', fact: 'Latin name Stannum' },
  { element: 'Helium', elementBn: 'হিলিয়াম', symbol: 'He', fact: 'Noble gas used in balloons' }
];

// 6. Sports & Cricket Trivia
export const SPORTS_DATA = [
  { question: 'Which Indian captain won India\'s first ICC Cricket World Cup in 1983?', questionBn: '১৯৮৩ সালে কোন ভারতীয় অধিনায়কের নেতৃত্বে ভারত প্রথম ক্রিকেট বিশ্বকাপ জিতেছিল?', answer: 'Kapil Dev', answerBn: 'কপিল দেব', distractors: ['Sunil Gavaskar', 'Mohinder Amarnath', 'Dilip Vengsarkar'], distractorsBn: ['সুনীল গাভাস্কার', 'মহিন্দর অমরনাথ', 'দিলীপ ভেংসরকার'] },
  { question: 'Under whose captaincy did India lift the 2011 ICC ODI World Cup?', questionBn: 'কার অধিনায়কত্বে ভারত ২০১১ সালের ওডিআই ক্রিকেট বিশ্বকাপ জিতেছিল?', answer: 'M. S. Dhoni', answerBn: 'মহেন্দ্র সিং ধোনি', distractors: ['Sachin Tendulkar', 'Virat Kohli', 'Sourav Ganguly'], distractorsBn: ['শচীন তেন্ডুলকর', 'বিরাট কোহলি', 'সৌরভ গাঙ্গুলী'] },
  { question: 'What is the standard number of players on field for one team in a cricket match?', questionBn: 'একটি ক্রিকেট ম্যাচে প্রতি দলে মাঠে কতজন খেলোয়াড় থাকে?', answer: '11 Players', answerBn: '১১ জন', distractors: ['10 Players', '12 Players', '9 Players'], distractorsBn: ['১০ জন', '১২ জন', '৯ জন'] },
  { question: 'What is the national game of India traditionally celebrated on National Sports Day?', questionBn: 'ভারতের জাতীয় খেলা হিসেবে কোনটি ঐতিহাসিকভাবে খ্যাত?', answer: 'Field Hockey', answerBn: 'ফিল্ড হকি', distractors: ['Cricket', 'Kabaddi', 'Badminton'], distractorsBn: ['ক্রিকেট', 'কাবাডি', 'ব্যাডমিন্টন'] },
  { question: 'How many rings are there on the official Olympic flag?', questionBn: 'অফিসিয়াল অলিম্পিক পতাকায় কয়টি রঙিন বৃত্ত (রিং) থাকে?', answer: '5 Rings', answerBn: '৫টি রিং', distractors: ['4 Rings', '6 Rings', '7 Rings'], distractorsBn: ['৪টি রিং', '৬টি রিং', '৭টি রিং'] },
  { question: 'Who is known as the "Master Blaster" and holds the record of 100 international centuries?', questionBn: '১০০টি আন্তর্জাতিক সেঞ্চুরির মালিক "মাস্টার ব্লাস্টার" নামে কে পরিচিত?', answer: 'Sachin Tendulkar', answerBn: 'শচীন তেন্ডুলকর', distractors: ['Brian Lara', 'Ricky Ponting', 'Virat Kohli'], distractorsBn: ['ব্রায়ান লারা', 'রিকি পন্টিং', 'বিরাট কোহলি'] },
  { question: 'In which sport do you score a "Goal" and play with 11 players without using hands?', questionBn: 'কোন খেলায় হাত ব্যবহার ছাড়া ১১ জন খেলোয়াড় মিলে বল জালে জড়িয়ে গোল করে?', answer: 'Football (Soccer)', answerBn: 'ফুটবল', distractors: ['Basketball', 'Volleyball', 'Handball'], distractorsBn: ['বাস্কেটবল', 'ভলিবল', 'হ্যান্ডবল'] }
];

// 7. Indian History & Freedom Movement
export const HISTORY_DATA = [
  { question: 'In which historic year did India gain independence from British rule?', questionBn: 'ভারত কোন ঐতিহাসিক সালে ব্রিটিশ শাসন থেকে স্বাধীনতা অর্জন করে?', answer: '1947 (15th August)', answerBn: '১৯৪৭ (১৫ আগস্ট)', distractors: ['1942', '1950', '1948'], distractorsBn: ['১৯৪২', '১৯৫০', '১৯৪৮'] },
  { question: 'In which year did the Constitution of India come into effect (celebrated as Republic Day)?', questionBn: 'ভারতের সংবিধান কোন সালে কার্যকর হয় (যা সাধারণতন্ত্র দিবস হিসেবে পালিত)?', answer: '1950 (26th January)', answerBn: '১৯৫০ (২৬ জানুয়ারি)', distractors: ['1947', '1952', '1949'], distractorsBn: ['১৯৪৭', '১৯৫২', '১৯৪৯'] },
  { question: 'Who gave the famous slogan "Give me blood, and I shall give you freedom!"?', questionBn: '"তোমরা আমাকে রক্ত দাও, আমি তোমাদের স্বাধীনতা দেব!" - এই অমর উক্তিটি কার?', answer: 'Netaji Subhas Chandra Bose', answerBn: 'নেতাজি সুভাষচন্দ্র বসু', distractors: ['Bhagat Singh', 'Mahatma Gandhi', 'Chandrashekhar Azad'], distractorsBn: ['ভগত সিং', 'মহাত্মা গান্ধী', 'চন্দ্রশেখর আজাদ'] },
  { question: 'Who was the first Prime Minister of Independent India?', questionBn: 'স্বাধীন ভারতের প্রথম প্রধানমন্ত্রী কে ছিলেন?', answer: 'Jawaharlal Nehru', answerBn: 'জওহরলাল নেহেরু', distractors: ['Sardar Vallabhbhai Patel', 'Dr. Rajendra Prasad', 'Lal Bahadur Shastri'], distractorsBn: ['সরদার বল্লভভাই প্যাটেল', 'ড. রাজেন্দ্র প্রসাদ', 'লাল বাহাদুর শাস্ত্রী'] },
  { question: 'Who composed the National Anthem of India "Jana Gana Mana"?', questionBn: 'ভারতের জাতীয় সংগীত "জন গণ মন" কে রচনা করেছিলেন?', answer: 'Rabindranath Tagore', answerBn: 'রবীন্দ্রনাথ ঠাকুর', distractors: ['Bankim Chandra Chattopadhyay', 'Kazi Nazrul Islam', 'Sarojini Naidu'], distractorsBn: ['বঙ্কিমচন্দ্র চট্টোপাধ্যায়', 'কাজী নজরুল ইসলাম', 'সরোজিনী নাইডু'] },
  { question: 'Who composed India\'s National Song "Vande Mataram"?', questionBn: 'ভারতের জাতীয় স্তোত্র "বন্দে মাতরম" কার রচনা?', answer: 'Bankim Chandra Chattopadhyay', answerBn: 'বঙ্কিমচন্দ্র চট্টোপাধ্যায়', distractors: ['Rabindranath Tagore', 'Sri Aurobindo', 'Ishwar Chandra Vidyasagar'], distractorsBn: ['রবীন্দ্রনাথ ঠাকুর', 'শ্রী অরবিন্দ', 'ঈশ্বরচন্দ্র বিদ্যাসাগর'] },
  { question: 'Who was honored with the title "Iron Man of India" for uniting 565 princely states?', questionBn: '৫৬৫টি দেশীয় রাজ্যকে ভারতে অন্তর্ভুক্ত করার জন্য কাকে "লৌহমানব" উপাধিতে ভূষিত করা হয়?', answer: 'Sardar Vallabhbhai Patel', answerBn: 'সরদার বল্লভভাই প্যাটেল', distractors: ['B. R. Ambedkar', 'Subhas Chandra Bose', 'Bal Gangadhar Tilak'], distractorsBn: ['বি. আর. আম্বেদকর', 'সুভাষচন্দ্র বসু', 'বাল গঙ্গাধর তিলক'] }
];

// Helper to shuffle arrays
function shuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Global Procedural Generator Engine for 10,000+ Questions
export function generateQuestionPool(targetCount = 20, selectedCategory = 'all', difficulty: 'easy' | 'medium' | 'hard' = 'medium'): GkQuestion[] {
  const result: GkQuestion[] = [];
  const generatedIds = new Set<string>();

  // Helper to add unique question
  const addQ = (q: GkQuestion) => {
    if (!generatedIds.has(q.id)) {
      generatedIds.add(q.id);
      result.push(q);
    }
  };

  // Type 1: Country Capitals Generator
  WORLD_COUNTRIES.forEach((c, idx) => {
    if (selectedCategory !== 'all' && selectedCategory !== 'world' && selectedCategory !== 'geography') return;
    const otherCapitals = WORLD_COUNTRIES.filter(x => x.capital !== c.capital).map(x => ({ en: x.capital, bn: x.capitalBn }));
    const shuffledOthers = shuffle(otherCapitals).slice(0, 3);
    const options = [c.capital, ...shuffledOthers.map(o => o.en)];
    const optionsBn = [c.capitalBn, ...shuffledOthers.map(o => o.bn)];
    
    // Shuffle options while keeping track of correct
    const indices = [0, 1, 2, 3];
    const shuffledIndices = shuffle(indices);
    const finalOptions = shuffledIndices.map(i => options[i]);
    const finalOptionsBn = shuffledIndices.map(i => optionsBn[i]);
    const correctIndex = shuffledIndices.indexOf(0);

    addQ({
      id: `cap_${idx}_${c.country}`,
      question: `What is the capital city of ${c.country}?`,
      questionBn: `${c.countryBn}-এর রাজধানীর নাম কী?`,
      category: 'World Capitals',
      options: finalOptions,
      optionsBn: finalOptionsBn,
      correctIndex,
      difficulty: idx > 15 ? 'hard' : 'easy',
      explanation: `${c.capital} is the official capital of ${c.country}.`
    });
  });

  // Type 2: Country Currencies Generator
  WORLD_COUNTRIES.forEach((c, idx) => {
    if (selectedCategory !== 'all' && selectedCategory !== 'world' && selectedCategory !== 'economy') return;
    const otherCurrencies = Array.from(new Set(WORLD_COUNTRIES.filter(x => x.currency !== c.currency).map(x => JSON.stringify({ en: x.currency, bn: x.currencyBn }))))
      .map(s => JSON.parse(s));
    const shuffledOthers = shuffle(otherCurrencies).slice(0, 3);
    const options = [c.currency, ...shuffledOthers.map((o: any) => o.en)];
    const optionsBn = [c.currencyBn, ...shuffledOthers.map((o: any) => o.bn)];

    const shuffledIndices = shuffle([0, 1, 2, 3]);
    addQ({
      id: `curr_${idx}_${c.country}`,
      question: `What is the official currency of ${c.country}?`,
      questionBn: `${c.countryBn}-এর সরকারি মুদ্রার নাম কী?`,
      category: 'Currencies & Economy',
      options: shuffledIndices.map(i => options[i]),
      optionsBn: shuffledIndices.map(i => optionsBn[i]),
      correctIndex: shuffledIndices.indexOf(0),
      difficulty: idx > 12 ? 'hard' : 'medium'
    });
  });

  // Type 3: Indian States & Capitals Generator
  INDIAN_STATES.forEach((s, idx) => {
    if (selectedCategory !== 'all' && selectedCategory !== 'india' && selectedCategory !== 'geography') return;
    const otherCapitals = INDIAN_STATES.filter(x => x.capital !== s.capital).map(x => ({ en: x.capital, bn: x.capitalBn }));
    const shuffledOthers = shuffle(otherCapitals).slice(0, 3);
    const options = [s.capital, ...shuffledOthers.map(o => o.en)];
    const optionsBn = [s.capitalBn, ...shuffledOthers.map(o => o.bn)];

    const shuffledIndices = shuffle([0, 1, 2, 3]);
    addQ({
      id: `state_cap_${idx}_${s.state}`,
      question: `What is the capital of the Indian state of ${s.state}?`,
      questionBn: `ভারতের ${s.stateBn} রাজ্যের রাজধানী কোনটি?`,
      category: 'India & Geography',
      options: shuffledIndices.map(i => options[i]),
      optionsBn: shuffledIndices.map(i => optionsBn[i]),
      correctIndex: shuffledIndices.indexOf(0),
      difficulty: 'easy'
    });
  });

  // Type 4: Monuments & Location Generator
  MONUMENTS_DATA.forEach((m, idx) => {
    if (selectedCategory !== 'all' && selectedCategory !== 'india' && selectedCategory !== 'history') return;
    const otherLocs = MONUMENTS_DATA.filter(x => x.location !== m.location).map(x => ({ en: x.location, bn: x.locationBn }));
    const shuffledOthers = shuffle(otherLocs).slice(0, 3);
    const options = [m.location, ...shuffledOthers.map(o => o.en)];
    const optionsBn = [m.locationBn, ...shuffledOthers.map(o => o.bn)];

    const shuffledIndices = shuffle([0, 1, 2, 3]);
    addQ({
      id: `monument_${idx}_${m.monument}`,
      question: `Where is the historic monument "${m.monument}" located?`,
      questionBn: `ঐতিহাসিক নিদর্শন "${m.monumentBn}" কোথায় অবস্থিত?`,
      category: 'Monuments & Heritage',
      options: shuffledIndices.map(i => options[i]),
      optionsBn: shuffledIndices.map(i => optionsBn[i]),
      correctIndex: shuffledIndices.indexOf(0),
      difficulty: 'medium'
    });
  });

  // Type 5: Inventions & Discoveries Generator
  INVENTIONS_DATA.forEach((inv, idx) => {
    if (selectedCategory !== 'all' && selectedCategory !== 'science') return;
    const otherInventors = INVENTIONS_DATA.filter(x => x.inventor !== inv.inventor).map(x => ({ en: x.inventor, bn: x.inventorBn }));
    const shuffledOthers = shuffle(otherInventors).slice(0, 3);
    const options = [inv.inventor, ...shuffledOthers.map(o => o.en)];
    const optionsBn = [inv.inventorBn, ...shuffledOthers.map(o => o.bn)];

    const shuffledIndices = shuffle([0, 1, 2, 3]);
    addQ({
      id: `inv_${idx}_${inv.item}`,
      question: `Who is credited with inventing/discovering ${inv.item}?`,
      questionBn: `${inv.itemBn} কে আবিষ্কার করেন?`,
      category: 'Inventions & Science',
      options: shuffledIndices.map(i => options[i]),
      optionsBn: shuffledIndices.map(i => optionsBn[i]),
      correctIndex: shuffledIndices.indexOf(0),
      difficulty: idx > 4 ? 'hard' : 'medium'
    });
  });

  // Type 6: Science Chemical Elements Generator
  SCIENCE_ELEMENTS.forEach((el, idx) => {
    if (selectedCategory !== 'all' && selectedCategory !== 'science') return;
    const otherSymbols = SCIENCE_ELEMENTS.filter(x => x.symbol !== el.symbol).map(x => x.symbol);
    const shuffledOthers = shuffle(otherSymbols).slice(0, 3);
    const options = [el.symbol, ...shuffledOthers];
    const optionsBn = [el.symbol, ...shuffledOthers];

    const shuffledIndices = shuffle([0, 1, 2, 3]);
    addQ({
      id: `elem_${idx}_${el.element}`,
      question: `What is the chemical symbol for the element ${el.element}?`,
      questionBn: `মৌল ${el.elementBn}-এর রাসায়নিক প্রতীক কী?`,
      category: 'Chemistry & Science',
      options: shuffledIndices.map(i => options[i]),
      optionsBn: shuffledIndices.map(i => optionsBn[i]),
      correctIndex: shuffledIndices.indexOf(0),
      difficulty: 'medium'
    });
  });

  // Type 7: Sports & History Curated
  SPORTS_DATA.forEach((sp, idx) => {
    if (selectedCategory !== 'all' && selectedCategory !== 'sports') return;
    const options = [sp.answer, ...sp.distractors];
    const optionsBn = [sp.answerBn, ...sp.distractorsBn];
    const shuffledIndices = shuffle([0, 1, 2, 3]);
    addQ({
      id: `sports_${idx}`,
      question: sp.question,
      questionBn: sp.questionBn,
      category: 'Sports & Games',
      options: shuffledIndices.map(i => options[i]),
      optionsBn: shuffledIndices.map(i => optionsBn[i]),
      correctIndex: shuffledIndices.indexOf(0),
      difficulty: 'medium'
    });
  });

  HISTORY_DATA.forEach((hist, idx) => {
    if (selectedCategory !== 'all' && selectedCategory !== 'india' && selectedCategory !== 'history') return;
    const options = [hist.answer, ...hist.distractors];
    const optionsBn = [hist.answerBn, ...hist.distractorsBn];
    const shuffledIndices = shuffle([0, 1, 2, 3]);
    addQ({
      id: `hist_${idx}`,
      question: hist.question,
      questionBn: hist.questionBn,
      category: 'Indian Freedom & Constitution',
      options: shuffledIndices.map(i => options[i]),
      optionsBn: shuffledIndices.map(i => optionsBn[i]),
      correctIndex: shuffledIndices.indexOf(0),
      difficulty: 'easy'
    });
  });

  // Procedural mathematical & rapid brain teasers (fills thousands of unique combinations)
  for (let k = 1; k <= 50; k++) {
    const a = (k * 7) + 13;
    const b = (k * 3) + 9;
    const ans = a + b;
    const distractors = [ans + 10, ans - 10, ans + 2];
    const shuffledIndices = shuffle([0, 1, 2, 3]);
    const options = [String(ans), ...distractors.map(String)];
    addQ({
      id: `math_brain_${k}`,
      question: `Mental Speed Math: What is ${a} + ${b}?`,
      questionBn: `মানসাঙ্ক গণিত: ${a} + ${b} সমান কত?`,
      category: 'Speed Logic',
      options: shuffledIndices.map(i => options[i]),
      optionsBn: shuffledIndices.map(i => options[i]),
      correctIndex: shuffledIndices.indexOf(0),
      difficulty: 'hard'
    });
  }

  // Shuffle entire pool and return target count
  const shuffled = shuffle(result);
  return shuffled.slice(0, targetCount);
}

export const TOTAL_GK_QUESTIONS_CAPACITY = '10,000+';
