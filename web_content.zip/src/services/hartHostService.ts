import JSZip from 'jszip';

export type UploadCategory = 'avatars' | 'teams' | 'covers' | 'chapters' | 'misc';

/**
 * Hart Host Engine: High-performance background media pipeline
 * Powers seamless image optimization, permanent shared server storage, and ZIP extraction
 */
export const hartHost = {
  /**
   * Compresses images from phone camera / gallery into lightweight WebP format
   */
  async optimizeImage(file: File | Blob, maxWidth = 1200, quality = 0.85): Promise<Blob> {
    return new Promise((resolve) => {
      // If SVG or GIF, preserve directly to avoid breaking vector or animations
      if (file instanceof File && (file.type === 'image/svg+xml' || file.type === 'image/gif')) {
        resolve(file);
        return;
      }

      const img = new Image();
      const objectUrl = URL.createObjectURL(file);

      img.onload = () => {
        URL.revokeObjectURL(objectUrl);
        let { width, height } = img;

        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(file instanceof Blob ? file : new Blob([file]));
          return;
        }

        // Enable high-quality image smoothing
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              resolve(file instanceof Blob ? file : new Blob([file]));
            }
          },
          'image/webp',
          quality
        );
      };

      img.onerror = () => {
        URL.revokeObjectURL(objectUrl);
        // If canvas decoding fails, return original blob safely
        resolve(file instanceof Blob ? file : new Blob([file]));
      };

      img.src = objectUrl;
    });
  },

  /**
   * Convert file/blob to Base64
   */
  blobToDataUrl(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  },

  /**
   * Upload single media (cover, avatar, team logo, or page) to permanent shared storage
   */
  async uploadMedia(
    fileOrBlob: File | Blob,
    category: UploadCategory = 'misc',
    customName = 'file',
    onProgress?: (progress: number) => void
  ): Promise<string> {
    if (onProgress) onProgress(20);

    try {
      const formData = new FormData();
      // ALWAYS append category first so body parsers get it before stream
      formData.append('category', category);
      
      const fileName = fileOrBlob instanceof File 
        ? fileOrBlob.name 
        : `${customName.replace(/[^a-zA-Z0-9_\u0600-\u06FF-]/g, '_')}.webp`;
      formData.append('file', fileOrBlob, fileName);

      if (onProgress) onProgress(50);

      // Pass category in URL query param AND in custom header for rock-solid routing
      const response = await fetch(`/api/upload?category=${encodeURIComponent(category)}`, {
        method: 'POST',
        headers: {
          'x-upload-category': category
        },
        body: formData
      });

      if (onProgress) onProgress(85);

      if (!response.ok) {
        throw new Error(`Upload failed with status: ${response.status}`);
      }

      const data = await response.json();
      if (data.success && data.url) {
        if (onProgress) onProgress(100);
        return data.url;
      }
      throw new Error(data.message || 'فشل رفع الملف إلى الخادم');
    } catch (networkError) {
      console.warn('Direct upload failed, switching to base64 pipeline:', networkError);

      // Fallback: send as Base64 to server endpoint to write permanent file
      try {
        const dataUrl = await this.blobToDataUrl(fileOrBlob);
        const res = await fetch('/api/upload-base64', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'x-upload-category': category
          },
          body: JSON.stringify({ dataUrl, category, name: customName })
        });
        const json = await res.json();
        if (json.success && json.url) {
          if (onProgress) onProgress(100);
          return json.url;
        }
        return dataUrl;
      } catch (err) {
        console.error('All upload pathways failed:', err);
        const fallbackUrl = await this.blobToDataUrl(fileOrBlob);
        if (onProgress) onProgress(100);
        return fallbackUrl;
      }
    }
  },

  /**
   * Batch upload multiple chapter pages efficiently with live status
   */
  async uploadChapterPages(
    pages: { filename: string; blob: Blob }[],
    chapterNumber: number | string,
    onProgress?: (percent: number, current: number, total: number) => void
  ): Promise<string[]> {
    const total = pages.length;
    const uploadedUrls: string[] = [];

    // Process in batches of 3 to optimize speed without overloading connection
    const BATCH_SIZE = 3;
    for (let i = 0; i < total; i += BATCH_SIZE) {
      const batch = pages.slice(i, i + BATCH_SIZE);
      const batchPromises = batch.map(async (page, batchIdx) => {
        const pageIndex = i + batchIdx + 1;
        const optimized = await this.optimizeImage(page.blob, 1400, 0.85);
        const url = await this.uploadMedia(
          optimized,
          'chapters',
          `ch_${chapterNumber}_p${pageIndex}_${page.filename}`
        );
        return { index: pageIndex - 1, url };
      });

      const results = await Promise.all(batchPromises);
      results.forEach((r) => {
        uploadedUrls[r.index] = r.url;
      });

      if (onProgress) {
        const currentDone = Math.min(i + BATCH_SIZE, total);
        const percent = Math.round((currentDone / total) * 100);
        onProgress(percent, currentDone, total);
      }
    }

    return uploadedUrls;
  },

  /**
   * Extract chapter pages from a ZIP file and sort them numerically
   */
  async extractZipArchive(
    zipFile: File,
    onProgress?: (percent: number, current: number, total: number) => void
  ): Promise<{ filename: string; blob: Blob }[]> {
    const zip = new JSZip();
    const contents = await zip.loadAsync(zipFile);

    const validExtensions = ['.jpg', '.jpeg', '.png', '.webp', '.avif', '.gif'];
    const imageFiles: { name: string; zipObject: JSZip.JSZipObject }[] = [];

    contents.forEach((relativePath, zipEntry) => {
      if (zipEntry.dir) return;
      if (relativePath.includes('__MACOSX') || relativePath.startsWith('.')) return;

      const lower = relativePath.toLowerCase();
      if (validExtensions.some((ext) => lower.endsWith(ext))) {
        imageFiles.push({ name: relativePath, zipObject: zipEntry });
      }
    });

    // Natural numerical sort: 1.jpg, 2.jpg, 10.jpg
    imageFiles.sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' })
    );

    const total = imageFiles.length;
    const extracted: { filename: string; blob: Blob }[] = [];

    for (let i = 0; i < total; i++) {
      const item = imageFiles[i];
      const blob = await item.zipObject.async('blob');
      extracted.push({ filename: item.name, blob });
      if (onProgress) {
        const percent = Math.round(((i + 1) / total) * 100);
        onProgress(percent, i + 1, total);
      }
    }

    return extracted;
  }
};
