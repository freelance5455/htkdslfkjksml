/**
 * Safe storage utility with in-memory fallback.
 * Prevents fatal SecurityError / DOMException in Android WebViews
 * when domStorageEnabled is false or cookies/storage are restricted.
 */
class SafeStorage {
  private memoryFallback = new Map<string, string>();

  getItem(key: string): string | null {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.getItem(key);
      }
    } catch {
      // Ignored: WebView access denied for localStorage
    }
    return this.memoryFallback.get(key) ?? null;
  }

  setItem(key: string, value: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(key, value);
        return;
      }
    } catch {
      // Ignored: WebView access denied for localStorage
    }
    this.memoryFallback.set(key, value);
  }

  removeItem(key: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(key);
        return;
      }
    } catch {
      // Ignored: WebView access denied for localStorage
    }
    this.memoryFallback.delete(key);
  }

  clear(): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.clear();
      }
    } catch {
      // Ignored
    }
    this.memoryFallback.clear();
  }
}

export const safeStorage = new SafeStorage();
