export interface SurveyQuestion {
  id: string;
  question: string;
  questionBn: string;
  type: 'single' | 'multiple' | 'rating' | 'text';
  options?: string[];
  optionsBn?: string[];
}

export interface SurveyItem {
  id: string;
  title: string;
  titleBn: string;
  category: string;
  categoryBn: string;
  estimatedMinutes: number;
  rewardCoins: number;
  rewardRupees: number;
  sponsorName: string;
  responsesTarget: string;
  rating: number;
  badge: string;
  questions: SurveyQuestion[];
}

export const TOTAL_SURVEYS_CATALOG_COUNT = 100000;

export const SURVEY_CATEGORIES = [
  'All',
  'Tech & AI',
  'Shopping & E-Commerce',
  'Finance & Banking',
  'Gaming & Media',
  'Lifestyle & Health',
  'Education & Jobs'
];

export const MEGA_SURVEYS_DATA: SurveyItem[] = [
  {
    id: 'survey-mobile-ai-habits',
    title: 'Smartphone & AI Assistant Daily Usage Survey',
    titleBn: 'দৈনন্দিন স্মার্টফোন ও এআই অ্যাসিস্ট্যান্ট ব্যবহারের সার্ভে',
    category: 'Tech & AI',
    categoryBn: 'টেকনোলজি ও এআই',
    estimatedMinutes: 3,
    rewardCoins: 250,
    rewardRupees: 2.5,
    sponsorName: 'Global AI Research Lab',
    responsesTarget: '100,000+ Active',
    rating: 4.9,
    badge: '🔥 Hot +250 Coins',
    questions: [
      {
        id: 'q1',
        question: 'Which mobile operating system do you primarily use on your daily phone?',
        questionBn: 'আপনার প্রধান মোবাইল ফোনে আপনি কোন অপারেটিং সিস্টেম ব্যবহার করেন?',
        type: 'single',
        options: ['Android (Samsung, Xiaomi, Realme, etc.)', 'iOS (Apple iPhone)', 'Both Android & iOS'],
        optionsBn: ['অ্যান্ড্রয়েড (স্যামসাং, শাওমি ইত্যাদি)', 'আইওএস (অ্যাপল আইফোন)', 'দুটোই ব্যবহার করি']
      },
      {
        id: 'q2',
        question: 'How frequently do you interact with AI tools (like ChatGPT, Gemini, Copilot)?',
        questionBn: 'আপনি কত ঘন ঘন এআই টুলস (যেমন ChatGPT, Gemini) ব্যবহার করেন?',
        type: 'single',
        options: ['Multiple times daily', '2-3 times a week', 'Rarely / Just started', 'Never used yet'],
        optionsBn: ['দিনে একাধিকবার', 'সপ্তাহে ২-৩ বার', 'খুব কম / সবে শুরু করেছি', 'এখনো ব্যবহার করিনি']
      },
      {
        id: 'q3',
        question: 'What is your primary use case for smartphone productivity apps?',
        questionBn: 'মোবাইল প্রোডাক্টিভিটি অ্যাপের প্রধান উদ্দেশ্য আপনার কাছে কী?',
        type: 'single',
        options: ['Online earning & micro-tasks', 'Social media & communication', 'Study & education', 'Gaming & entertainment'],
        optionsBn: ['অনলাইন আর্নিং ও মাইক্রো-টাস্ক', 'সোশ্যাল মিডিয়া ও যোগাযোগ', 'পড়াশোনা ও শিক্ষা', 'গেমিং ও বিনোদন']
      },
      {
        id: 'q4',
        question: 'How satisfied are you with online task earning apps on a scale of 1 to 5?',
        questionBn: 'অনলাইন টাস্ক আর্নিং অ্যাপ নিয়ে আপনার সন্তুষ্টি কেমন (১ থেকে ৫)?',
        type: 'rating'
      }
    ]
  },
  {
    id: 'survey-upi-digital-payments',
    title: 'UPI, Digital Wallets & Online Money Survey',
    titleBn: 'ইউপিআই, ডিজিটাল ওয়ালেট ও অনলাইন পেমেন্ট ব্যবহার সার্ভে',
    category: 'Finance & Banking',
    categoryBn: 'ফিন্যান্স ও ব্যাংকিং',
    estimatedMinutes: 4,
    rewardCoins: 350,
    rewardRupees: 3.5,
    sponsorName: 'Fintech Analytics India',
    responsesTarget: '75,000+ Active',
    rating: 4.8,
    badge: '💎 High Pay +350 Coins',
    questions: [
      {
        id: 'q1',
        question: 'Which digital payment app do you use most frequently for everyday expenses?',
        questionBn: 'প্রতিদিনের কেনাকাটায় আপনি কোন পেমেন্ট অ্যাপ সবচেয়ে বেশি ব্যবহার করেন?',
        type: 'single',
        options: ['PhonePe', 'Google Pay', 'Paytm', 'Amazon Pay', 'Direct Bank UPI / bKash'],
        optionsBn: ['ফোনপে (PhonePe)', 'গুগল পে (Google Pay)', 'পেটিএম (Paytm)', 'অ্যামাজন পে', 'অন্যান্য ব্যাংক ইউপিআই']
      },
      {
        id: 'q2',
        question: 'Have you ever bought digital gold or silver through micro-investing apps?',
        questionBn: 'আপনি কি কখনো মাইক্রো-ইনভেস্টিং অ্যাপের মাধ্যমে ডিজিটাল গোল্ড বা রূপা কিনেছেন?',
        type: 'single',
        options: ['Yes, actively investing', 'Tried once or twice', 'Interested to start soon', 'Never heard of it'],
        optionsBn: ['হ্যাঁ, নিয়মিত বিনিয়োগ করি', '১-২ বার চেষ্টা করেছি', 'শিগগিরই শুরু করার ইচ্ছে আছে', 'আগে শুনিনি']
      },
      {
        id: 'q3',
        question: 'What is your preferred method for withdrawing task earnings?',
        questionBn: 'টাস্কের আয় তোলার জন্য আপনার পছন্দের মাধ্যম কোনটি?',
        type: 'single',
        options: ['Instant UPI Transfer (Fastest)', 'Bank Account NEFT/IMPS', 'Paytm Wallet', 'Amazon Gift Card'],
        optionsBn: ['ইনস্ট্যান্ট ইউপিআই ট্রান্সফার', 'ব্যাংক অ্যাকাউন্ট ট্রান্সফার', 'পেটিএম ওয়ালেট', 'গিফট ভাউচার']
      }
    ]
  },
  {
    id: 'survey-ecommerce-shopping',
    title: 'Online Shopping, Festival Deals & Delivery Experience',
    titleBn: 'অনলাইন শপিং, অফার ও ডেলিভারি অভিজ্ঞতা সার্ভে',
    category: 'Shopping & E-Commerce',
    categoryBn: 'শপিং ও ই-কমার্স',
    estimatedMinutes: 3,
    rewardCoins: 280,
    rewardRupees: 2.8,
    sponsorName: 'Retail Pulse Insights',
    responsesTarget: '120,000+ Active',
    rating: 4.7,
    badge: '🛍️ Popular +280 Coins',
    questions: [
      {
        id: 'q1',
        question: 'Where do you shop most often for clothing, gadgets, and household goods?',
        questionBn: 'পোশাক, গ্যাজেট বা ঘরের জিনিস কেনার জন্য কোথায় সবচেয়ে বেশি শপিং করেন?',
        type: 'single',
        options: ['Amazon', 'Flipkart', 'Meesho', 'Myntra / Ajio', 'Local offline stores'],
        optionsBn: ['অ্যামাজন', 'ফ্লিপকার্ট', 'মিশো', 'মিন্ত্রা / আজিউ', 'স্থানীয় অফলাইন দোকান']
      },
      {
        id: 'q2',
        question: 'How much do online product reviews influence your purchase decisions?',
        questionBn: 'অনলাইন রিভিউ দেখে পণ্য কেনার ক্ষেত্রে আপনার সিদ্ধান্ত কতটা প্রভাবিত হয়?',
        type: 'single',
        options: ['Extremely important (Always check)', 'Moderate (Check for expensive items)', 'Rarely look at reviews'],
        optionsBn: ['খুবই গুরুত্বপূর্ণ (সবসময় দেখি)', 'মোটামুটি (দামি জিনিসে দেখি)', 'খুব একটা দেখি না']
      }
    ]
  },
  {
    id: 'survey-mobile-gaming-esports',
    title: 'Mobile Gaming, Arcade Challenges & Rewards Survey',
    titleBn: 'মোবাইল গেমিং, আর্কেড ও গেমিং রিওয়ার্ডস সমীক্ষা',
    category: 'Gaming & Media',
    categoryBn: 'গেমিং ও মিডিয়া',
    estimatedMinutes: 2,
    rewardCoins: 200,
    rewardRupees: 2.0,
    sponsorName: 'GameHub Interactive',
    responsesTarget: '50,000+ Active',
    rating: 4.9,
    badge: '🎮 Fast +200 Coins',
    questions: [
      {
        id: 'q1',
        question: 'Which type of casual mobile games do you enjoy most in free time?',
        questionBn: 'অবসর সময়ে আপনার কোন ধরনের গেম খেলতে সবচেয়ে ভালো লাগে?',
        type: 'single',
        options: ['Ludo & Board Games', 'Brain Puzzles & Math Quizzes', 'Action & Knife/Shooter games', 'Arcade & Racing'],
        optionsBn: ['লুডো ও বোর্ড গেম', 'ব্রেইন পাজল ও কুইজ', 'অ্যাকশন ও শুটিং গেম', 'আর্কেড ও রেসিং']
      },
      {
        id: 'q2',
        question: 'Would you rather play for coin rewards or pure leisure?',
        questionBn: 'আপনি কি কয়েন পুরস্কারের জন্য খেলতে চান নাকি শুধুমাত্র অবসরের জন্য?',
        type: 'single',
        options: ['Play-to-earn real coins & money', 'Pure fun & relaxation', 'Equal balance of both'],
        optionsBn: ['আসল কয়েন ও টাকা উপার্জনের জন্য', 'শুধুমাত্র আনন্দ ও বিশ্রামের জন্য', 'দুটোই সমানভাবে পছন্দ']
      }
    ]
  },
  {
    id: 'survey-video-watch-habits',
    title: 'Video Streaming & Sponsored Ad Attention Survey',
    titleBn: 'ভিডিও স্ট্রিমিং ও স্পনসরড বিজ্ঞাপন মনোযোগ সমীক্ষা',
    category: 'Gaming & Media',
    categoryBn: 'ভিডিও ও মিডিয়া',
    estimatedMinutes: 3,
    rewardCoins: 300,
    rewardRupees: 3.0,
    sponsorName: 'AdMetrics Global',
    responsesTarget: '90,000+ Active',
    rating: 4.8,
    badge: '🎬 Media +300 Coins',
    questions: [
      {
        id: 'q1',
        question: 'How long do you typically spend watching online videos daily?',
        questionBn: 'প্রতিদিন আপনি গড়ে কতক্ষণ অনলাইন ভিডিও দেখেন?',
        type: 'single',
        options: ['Less than 30 minutes', '30 minutes to 1 hour', '1 to 2 hours', 'More than 2 hours'],
        optionsBn: ['৩০ মিনিটের কম', '৩০ মিনিট থেকে ১ ঘণ্টা', '১ থেকে ২ ঘণ্টা', '২ ঘণ্টার বেশি']
      },
      {
        id: 'q2',
        question: 'Are you willing to watch sponsored video ads if you receive guaranteed cash/coins?',
        questionBn: 'গ্যারান্টিযুক্ত কয়েন বা টাকা পেলে কি আপনি স্পনসরড ভিডিও দেখতে ইচ্ছুক?',
        type: 'single',
        options: ['Yes, definitely! Great way to earn', 'Occasionally if payout is good', 'Not sure'],
        optionsBn: ['হ্যাঁ অবশ্যই! আয়ের জন্য দারুণ উপায়', 'মাঝে মাঝে যদি পেআউট ভালো হয়', 'নিশ্চিত নই']
      }
    ]
  }
];

export function getSurveysList(category: string = 'All', search: string = ''): SurveyItem[] {
  return MEGA_SURVEYS_DATA.filter(survey => {
    const matchesCategory = category === 'All' || survey.category === category;
    const matchesSearch = !search || 
      survey.title.toLowerCase().includes(search.toLowerCase()) ||
      survey.titleBn.toLowerCase().includes(search.toLowerCase()) ||
      survey.sponsorName.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });
}
