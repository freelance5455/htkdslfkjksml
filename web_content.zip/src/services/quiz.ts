/** نتائج الاختبارات وإحصاءات نقاط الضعف */
import type { QuizAttempt } from '../types';
import { allQuizzes } from '../data/content';
import { KEYS, readKey, updateKey } from './storage';

export function attempts(): QuizAttempt[] {
  return readKey<QuizAttempt[]>(KEYS.quizzes, []);
}

export function saveAttempt(attempt: Omit<QuizAttempt, 'id' | 'at'>): QuizAttempt {
  const record: QuizAttempt = {
    ...attempt,
    id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    at: Date.now(),
  };
  updateKey<QuizAttempt[]>(KEYS.quizzes, (list) => [record, ...list].slice(0, 200), []);
  return record;
}

export function attemptFor(quizId: string): QuizAttempt | undefined {
  return attempts().find((a) => a.quizId === quizId);
}

export function bestScoreForSubject(subjectId: string): number | undefined {
  const list = attempts().filter((a) => a.subjectId === subjectId);
  if (list.length === 0) return undefined;
  const best = Math.max(...list.map((a) => (a.total > 0 ? (a.score / a.total) * 100 : 0)));
  return Math.round(best);
}

export interface WeakPoint {
  label: string;
  count: number;
  subjectId: string;
}

/** أكثر المفاهيم التي يخطئ فيها الطالب — تُغذّي لوحة التقدم والمراجعة */
export function weakPoints(limit = 6): WeakPoint[] {
  const counts = new Map<string, WeakPoint>();
  for (const attempt of attempts()) {
    for (const tag of attempt.weakTags) {
      const key = `${attempt.subjectId}:${tag}`;
      const prev = counts.get(key);
      if (prev) prev.count += 1;
      else counts.set(key, { label: tag, count: 1, subjectId: attempt.subjectId });
    }
  }
  return [...counts.values()].sort((a, b) => b.count - a.count).slice(0, limit);
}

/** نسبة الإجابات الصحيحة الكلية */
export function overallAccuracy(): number {
  const list = attempts();
  if (list.length === 0) return 0;
  const score = list.reduce((s, a) => s + a.score, 0);
  const total = list.reduce((s, a) => s + a.total, 0);
  return total === 0 ? 0 : Math.round((score / total) * 100);
}

/** اسم الدرس لاختبار معيّن (للعرض في السجل) */
export function lessonTitleForQuiz(quizId: string): string | undefined {
  return allQuizzes().find((entry) => entry.quiz.id === quizId)?.lessonTitle;
}

export function clearAttempts(): void {
  updateKey<QuizAttempt[]>(KEYS.quizzes, () => [], []);
}
