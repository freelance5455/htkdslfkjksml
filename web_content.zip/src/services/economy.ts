/** محفظة نقاط محلية، متجر مكافآت، وسجل معاملات قابل للتصدير ضمن نسخة الطالب الاحتياطية. */
import { KEYS, readKey, updateKey, withStorageLock, writeKey } from './storage';
import { EMPTY_FARM, growFarmWithStudySeconds, normalizeFarm, type FarmState } from './farmModel';

export type RewardSlot = 'accent' | 'frame' | 'banner' | 'vehicle' | 'player-card' | 'device' | 'furniture' | 'decoration' | 'companion';
export type RewardCategory = RewardSlot | 'consumable';

export interface RewardItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: RewardCategory;
  slot?: RewardSlot;
  value: string;
  color: string;
  emoji?: string;
}

export interface WalletTransaction {
  id: string;
  amount: number;
  balanceAfter: number;
  label: string;
  source: 'study' | 'challenge' | 'achievement' | 'daily-task' | 'purchase' | 'consumable' | 'farm';
  at: number;
}

export interface WalletState {
  balance: number;
  totalEarned: number;
  totalSpent: number;
  studySeconds: number;
  remainderSeconds: number;
  lastCreditAt: number;
  owned: Record<string, number>;
  equipped: Partial<Record<RewardSlot, string>>;
  streakFreezeDates: string[];
  claimedRewardIds: string[];
  claimedRewardAt: Record<string, number>;
  achievementUnlockedAt: Record<string, number>;
  ledger: WalletTransaction[];
}

export const EMPTY_WALLET: WalletState = {
  balance: 0,
  totalEarned: 0,
  totalSpent: 0,
  studySeconds: 0,
  remainderSeconds: 0,
  lastCreditAt: 0,
  owned: {},
  equipped: {},
  streakFreezeDates: [],
  claimedRewardIds: [],
  claimedRewardAt: {},
  achievementUnlockedAt: {},
  ledger: [],
};

/** ٦١ مكافأة رقمية بعد إضافة مركبات وبطاقات لاعبين وأدوات دراسة افتراضية. */
export const REWARD_CATALOG: RewardItem[] = [
  { id: 'accent-jade', name: 'لمعة الزمرد', description: 'لون فيروزي هادئ لعناصر التقدم والتفاعل.', price: 45, category: 'accent', slot: 'accent', value: 'jade', color: '#12a88a' },
  { id: 'accent-violet', name: 'ضوء البنفسج', description: 'لمسة بنفسجية مميزة في واجهتك.', price: 55, category: 'accent', slot: 'accent', value: 'violet', color: '#9463df' },
  { id: 'accent-coral', name: 'وهج المرجان', description: 'لون دافئ يبرز الأزرار والإنجازات.', price: 55, category: 'accent', slot: 'accent', value: 'coral', color: '#ec6c58' },
  { id: 'accent-sky', name: 'سماء الفجر', description: 'أزرق سماوي هادئ للمذاكرة اليومية.', price: 65, category: 'accent', slot: 'accent', value: 'sky', color: '#3c8ed4' },
  { id: 'frame-gold', name: 'إطار المنارة', description: 'إطار ذهبي حول صورتك الرمزية.', price: 35, category: 'frame', slot: 'frame', value: 'gold', color: '#e6a52e' },
  { id: 'frame-ocean', name: 'إطار الأعماق', description: 'إطار أزرق لامع حول صورتك الرمزية.', price: 45, category: 'frame', slot: 'frame', value: 'ocean', color: '#26a6cc' },
  { id: 'frame-amethyst', name: 'إطار البلّور', description: 'إطار بنفسجي حول صورتك الرمزية.', price: 55, category: 'frame', slot: 'frame', value: 'amethyst', color: '#a66be0' },
  { id: 'banner-dawn', name: 'لافتة أول الضوء', description: 'خلفية احتفالية لبطاقة ملفك.', price: 50, category: 'banner', slot: 'banner', value: 'dawn', color: '#edbd6b' },
  { id: 'banner-sea', name: 'لافتة الموج', description: 'خلفية بحرية هادئة لبطاقة ملفك.', price: 60, category: 'banner', slot: 'banner', value: 'sea', color: '#3d9fbc' },
  { id: 'banner-orbit', name: 'لافتة المدار', description: 'خلفية بنفسجية مستوحاة من مسارات النجوم.', price: 70, category: 'banner', slot: 'banner', value: 'orbit', color: '#8c6ed2' },
  { id: 'streak-shield', name: 'حماية السلسلة', description: 'احمِ يومك الحالي مرة واحدة إذا فاتتك جلسة الدراسة.', price: 100, category: 'consumable', value: 'one-day', color: '#e6a52e' },
  { id: 'streak-shield-plus', name: 'حماية السلسلة بلس', description: 'رصيد حماية ليوم واحد؛ يمكن تكديس أكثر من واحدة.', price: 160, category: 'consumable', value: 'one-day', color: '#e6a52e' },
  { id: 'vehicle-bicycle', name: 'دراجة البداية', description: 'مركبة افتراضية خفيفة لمجموعة إنجازاتك.', price: 75, category: 'vehicle', slot: 'vehicle', value: 'bicycle', color: '#39a77a', emoji: '🚲' },
  { id: 'vehicle-city', name: 'سيارة المدينة', description: 'سيارة رقمية صغيرة تزيّن مرآبك الدراسي.', price: 140, category: 'vehicle', slot: 'vehicle', value: 'city', color: '#4d91cf', emoji: '🚙' },
  { id: 'vehicle-electric', name: 'سيارة الشحن الذكي', description: 'سيارة كهربائية افتراضية لمجموعة المقتنيات.', price: 260, category: 'vehicle', slot: 'vehicle', value: 'electric', color: '#4cb6a6', emoji: '🚗' },
  { id: 'vehicle-stargazer', name: 'مركبة مستكشف النجوم', description: 'مركبة خيالية رقمية مستوحاة من سماء الليل.', price: 390, category: 'vehicle', slot: 'vehicle', value: 'stargazer', color: '#8970cf', emoji: '🚀' },
  { id: 'device-phone-sky', name: 'هاتف السماء', description: 'هاتف افتراضي بتصميم سماوي لمجموعة الأجهزة.', price: 85, category: 'device', slot: 'device', value: 'phone-sky', color: '#5598d4', emoji: '📱' },
  { id: 'device-phone-emerald', name: 'هاتف الزمرد', description: 'هاتف رقمي أنيق يضاف إلى مقتنياتك.', price: 145, category: 'device', slot: 'device', value: 'phone-emerald', color: '#29a883', emoji: '📱' },
  { id: 'device-tablet', name: 'لوح الملاحظات', description: 'جهاز لوحي افتراضي لعشاق تنظيم المراجعة.', price: 210, category: 'device', slot: 'device', value: 'tablet', color: '#7c75cb', emoji: '📲' },
  { id: 'device-headphones', name: 'سماعات التركيز', description: 'سماعات افتراضية لمجموعة أدوات الطالب.', price: 120, category: 'device', slot: 'device', value: 'headphones', color: '#de8b4f', emoji: '🎧' },
  { id: 'furniture-desk', name: 'مكتب المنارة', description: 'مكتب دراسة رقمي لتخصيص زاوية التعلم.', price: 115, category: 'furniture', slot: 'furniture', value: 'desk', color: '#a97b4d', emoji: '🪑' },
  { id: 'furniture-chair', name: 'كرسي الراحة', description: 'قطعة أثاث افتراضية لمجموعة مكتبك.', price: 95, category: 'furniture', slot: 'furniture', value: 'chair', color: '#658b9b', emoji: '💺' },
  { id: 'furniture-lamp', name: 'مصباح المذاكرة', description: 'مصباح رقمي يضيف دفئاً إلى ركنك الدراسي.', price: 65, category: 'furniture', slot: 'furniture', value: 'lamp', color: '#dfb341', emoji: '🛋️' },
  { id: 'furniture-bookshelf', name: 'رف الكتب', description: 'رف افتراضي تحتفظ عليه بإنجازاتك التعليمية.', price: 160, category: 'furniture', slot: 'furniture', value: 'bookshelf', color: '#a36c47', emoji: '📚' },
  { id: 'decor-syria-map', name: 'خريطة المعرفة', description: 'لوحة رقمية مستوحاة من خريطة سورية.', price: 90, category: 'decoration', slot: 'decoration', value: 'syria-map', color: '#2f9a7a', emoji: '🗺️' },
  { id: 'decor-star-chart', name: 'خارطة النجوم', description: 'زينة افتراضية لسماء ركن الدراسة.', price: 110, category: 'decoration', slot: 'decoration', value: 'star-chart', color: '#7662b5', emoji: '🌌' },
  { id: 'decor-clock', name: 'ساعة الإنجاز', description: 'ساعة رقمية تذكّرك بتقسيم وقت المذاكرة.', price: 70, category: 'decoration', slot: 'decoration', value: 'clock', color: '#d39d39', emoji: '⏰' },
  { id: 'decor-lantern', name: 'فانوس المنارة', description: 'زينة مضيئة افتراضية لمجموعتك.', price: 125, category: 'decoration', slot: 'decoration', value: 'lantern', color: '#de8a43', emoji: '🏮' },
  { id: 'companion-owl', name: 'رفيق البومة', description: 'رفيق افتراضي يزيّن ملفك الدراسي.', price: 100, category: 'companion', slot: 'companion', value: 'owl', color: '#9871b6', emoji: '🦉' },
  { id: 'companion-cat', name: 'قطّ المذاكرة', description: 'رفيق افتراضي لطيف لمجموعة الطالب.', price: 135, category: 'companion', slot: 'companion', value: 'cat', color: '#db9a62', emoji: '🐈' },
  { id: 'companion-turtle', name: 'سلحفاة المثابرة', description: 'رفيق رقمي يحتفي بالتقدم الهادئ والثابت.', price: 150, category: 'companion', slot: 'companion', value: 'turtle', color: '#4c9b69', emoji: '🐢' },
  { id: 'companion-bird', name: 'عصفور الفجر', description: 'رفيق افتراضي لمجموعة إنجازاتك اليومية.', price: 95, category: 'companion', slot: 'companion', value: 'bird', color: '#4eaab9', emoji: '🐦' },
  { id: 'vehicle-rally', name: 'سيارة الرالي', description: 'سيارة سباق رقمية عامة لمجموعة مرآبك؛ بلا علامة تجارية حقيقية.', price: 220, category: 'vehicle', slot: 'vehicle', value: 'rally', color: '#d45c46', emoji: '🏁' },
  { id: 'vehicle-night', name: 'كوبيه منتصف الليل', description: 'مركبة افتراضية بتصميم ليلي خيالي.', price: 260, category: 'vehicle', slot: 'vehicle', value: 'night-coupe', color: '#5362a6', emoji: '🚘' },
  { id: 'vehicle-classic', name: 'كلاسيكية المنارة', description: 'سيارة كلاسيكية رقمية بتصميم عام غير مرتبط بمصنّع.', price: 285, category: 'vehicle', slot: 'vehicle', value: 'classic', color: '#ba8450', emoji: '🚗' },
  { id: 'vehicle-race', name: 'سيارة الحلبة', description: 'سيارة حلبة خيالية لمقتنيات السباق الرقمية.', price: 320, category: 'vehicle', slot: 'vehicle', value: 'race', color: '#dc6d36', emoji: '🏎️' },
  { id: 'vehicle-offroad', name: 'مستكشفة الطرق', description: 'مركبة دفع رباعي افتراضية بتصميم غير تجاري.', price: 340, category: 'vehicle', slot: 'vehicle', value: 'offroad', color: '#5b8d68', emoji: '🚙' },
  { id: 'vehicle-sprint', name: 'سيارة البرق', description: 'مركبة رياضية رقمية مستوحاة من السرعة والتركيز.', price: 375, category: 'vehicle', slot: 'vehicle', value: 'sprint', color: '#45a5b6', emoji: '⚡' },
  { id: 'player-card-messi', name: 'بطاقة ليونيل ميسي', description: 'بطاقة اسمية رقمية للمجموعة فقط؛ لا تمثل رعاية أو تأييداً من اللاعب.', price: 280, category: 'player-card', slot: 'player-card', value: 'messi', color: '#59a7d9', emoji: '⚽' },
  { id: 'player-card-ronaldo', name: 'بطاقة كريستيانو رونالدو', description: 'بطاقة اسمية رقمية للمجموعة فقط؛ لا تمثل رعاية أو تأييداً من اللاعب.', price: 280, category: 'player-card', slot: 'player-card', value: 'ronaldo', color: '#56a879', emoji: '⚽' },
  { id: 'player-card-salah', name: 'بطاقة محمد صلاح', description: 'بطاقة اسمية رقمية للمجموعة فقط؛ لا تمثل رعاية أو تأييداً من اللاعب.', price: 245, category: 'player-card', slot: 'player-card', value: 'salah', color: '#56a879', emoji: '⚽' },
  { id: 'player-card-mbappe', name: 'بطاقة كيليان مبابي', description: 'بطاقة اسمية رقمية للمجموعة فقط؛ لا تمثل رعاية أو تأييداً من اللاعب.', price: 250, category: 'player-card', slot: 'player-card', value: 'mbappe', color: '#6376cf', emoji: '⚽' },
  { id: 'player-card-neymar', name: 'بطاقة نيمار جونيور', description: 'بطاقة اسمية رقمية للمجموعة فقط؛ لا تمثل رعاية أو تأييداً من اللاعب.', price: 225, category: 'player-card', slot: 'player-card', value: 'neymar', color: '#df8050', emoji: '⚽' },
  { id: 'player-card-modric', name: 'بطاقة لوكا مودريتش', description: 'بطاقة اسمية رقمية للمجموعة فقط؛ لا تمثل رعاية أو تأييداً من اللاعب.', price: 220, category: 'player-card', slot: 'player-card', value: 'modric', color: '#dfbc51', emoji: '⚽' },
  { id: 'player-card-son', name: 'بطاقة سون هيونغ مين', description: 'بطاقة اسمية رقمية للمجموعة فقط؛ لا تمثل رعاية أو تأييداً من اللاعب.', price: 215, category: 'player-card', slot: 'player-card', value: 'son', color: '#57a88c', emoji: '⚽' },
  { id: 'device-watch', name: 'ساعة التركيز', description: 'ساعة رقمية افتراضية تزيّن مجموعة أدوات الطالب.', price: 165, category: 'device', slot: 'device', value: 'focus-watch', color: '#bc8156', emoji: '⌚' },
  { id: 'device-laptop', name: 'حاسوب المعرفة', description: 'حاسوب افتراضي للعرض ضمن مقتنياتك الرقمية.', price: 310, category: 'device', slot: 'device', value: 'study-laptop', color: '#687ca8', emoji: '💻' },
  { id: 'device-mic', name: 'ميكروفون المراجعة', description: 'أداة صوتية افتراضية لركن الدراسة الرقمي.', price: 190, category: 'device', slot: 'device', value: 'review-mic', color: '#9874b4', emoji: '🎙️' },
  { id: 'furniture-cushion', name: 'وسادة الاستراحة', description: 'قطعة افتراضية مريحة لمجموعة ركن الدراسة.', price: 135, category: 'furniture', slot: 'furniture', value: 'cushion', color: '#68a1a5', emoji: '🛋️' },
  { id: 'decor-trophy', name: 'كأس المثابرة', description: 'كأس ديجيتالي للزينة؛ لا يمنح نقاطاً أو إنجازاً إضافياً.', price: 205, category: 'decoration', slot: 'decoration', value: 'trophy', color: '#d5a53f', emoji: '🏆' },
  { id: 'decor-globe', name: 'كرة المعرفة', description: 'مجسم أرضي رقمي لرف مقتنياتك التعليمية.', price: 175, category: 'decoration', slot: 'decoration', value: 'knowledge-globe', color: '#4c9fc1', emoji: '🌐' },
  { id: 'companion-fox', name: 'ثعلب الفضول', description: 'رفيق خيالي رقمي يذكّرك بفضول التعلّم.', price: 185, category: 'companion', slot: 'companion', value: 'fox', color: '#d9804e', emoji: '🦊' },
  { id: 'companion-panda', name: 'باندا الهدوء', description: 'رفيق خيالي رقمي لمجموعة إنجازاتك.', price: 195, category: 'companion', slot: 'companion', value: 'panda', color: '#7b8a91', emoji: '🐼' },
  { id: 'vehicle-sunrise', name: 'سيارة الشروق', description: 'سيارة رقمية عامة بتدرج ذهبي؛ لا ترتبط بمصنّع حقيقي.', price: 410, category: 'vehicle', slot: 'vehicle', value: 'sunrise', color: '#e3a44d', emoji: '🚗' },
  { id: 'vehicle-grand-tour', name: 'سيارة الرحّالة', description: 'مركبة افتراضية أنيقة لمجموعة المرآب الرقمي.', price: 435, category: 'vehicle', slot: 'vehicle', value: 'grand-tour', color: '#5971ae', emoji: '🚘' },
  { id: 'player-card-haaland', name: 'بطاقة إيرلينغ هالاند', description: 'بطاقة اسمية رقمية للمجموعة فقط؛ لا تمثل رعاية أو تأييداً من اللاعب.', price: 270, category: 'player-card', slot: 'player-card', value: 'haaland', color: '#5f83a8', emoji: '⚽' },
  { id: 'player-card-bellingham', name: 'بطاقة جود بيلينغهام', description: 'بطاقة اسمية رقمية للمجموعة فقط؛ لا تمثل رعاية أو تأييداً من اللاعب.', price: 260, category: 'player-card', slot: 'player-card', value: 'bellingham', color: '#bc784e', emoji: '⚽' },
  { id: 'device-ereader', name: 'قارئ الكتب الرقمي', description: 'جهاز افتراضي لمجموعة أدوات القراءة والمراجعة.', price: 180, category: 'device', slot: 'device', value: 'ereader', color: '#648c9a', emoji: '📖' },
  { id: 'device-powerbank', name: 'بطارية النشاط', description: 'بطارية رقمية للزينة ضمن مجموعة أجهزتك.', price: 155, category: 'device', slot: 'device', value: 'powerbank', color: '#61a477', emoji: '🔋' },
  { id: 'furniture-side-table', name: 'طاولة المراجعة', description: 'قطعة أثاث افتراضية تكمّل ركن الدراسة الرقمي.', price: 125, category: 'furniture', slot: 'furniture', value: 'side-table', color: '#a47a59', emoji: '🪵' },
  { id: 'decor-plant-shelf', name: 'رفّ الحديقة', description: 'زينة رقمية صغيرة تجمع نباتاتك ومقتنياتك.', price: 145, category: 'decoration', slot: 'decoration', value: 'plant-shelf', color: '#5d9c75', emoji: '🪴' },
];

const byId = new Map(REWARD_CATALOG.map((item) => [item.id, item]));

function normalizeWallet(value: WalletState): WalletState {
  return {
    ...EMPTY_WALLET,
    ...value,
    owned: value?.owned ?? {},
    equipped: value?.equipped ?? {},
    streakFreezeDates: value?.streakFreezeDates ?? [],
    claimedRewardIds: value?.claimedRewardIds ?? [],
    claimedRewardAt: value?.claimedRewardAt ?? {},
    achievementUnlockedAt: value?.achievementUnlockedAt ?? {},
    ledger: value?.ledger ?? [],
    remainderSeconds: Math.max(0, Math.min(359, value?.remainderSeconds ?? 0)),
    lastCreditAt: value?.lastCreditAt ?? 0,
  };
}

export function getWallet(): WalletState {
  return normalizeWallet(readKey<WalletState>(KEYS.wallet, EMPTY_WALLET));
}

function localDateKey(date = new Date()): string {
  return `${date.getFullYear()}-${`${date.getMonth() + 1}`.padStart(2, '0')}-${`${date.getDate()}`.padStart(2, '0')}`;
}

function addTransaction(
  wallet: WalletState,
  amount: number,
  label: string,
  source: WalletTransaction['source'],
  transactionId?: string,
): WalletTransaction {
  return {
    id: transactionId ?? `tx-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    amount,
    balanceAfter: wallet.balance + amount,
    label,
    source,
    at: Date.now(),
  };
}

/** عملية محفظة متسلسلة مع مفاتيح بيانات إضافية كي تبقى مشتريات المزرعة ذرّية. */
export function withWalletMutation<T>(
  additionalKeys: readonly string[],
  mutation: (wallet: WalletState) => { wallet: WalletState; result: T },
): Promise<T> {
  return withStorageLock('wallet', [KEYS.wallet, ...additionalKeys], () => {
    const current = getWallet();
    const outcome = mutation(current);
    if (outcome.wallet !== current) writeKey(KEYS.wallet, outcome.wallet);
    return outcome.result;
  });
}

export function chargeWallet(wallet: WalletState, points: number, label: string): WalletState {
  const amount = Math.max(0, Math.floor(points));
  if (amount === 0 || wallet.balance < amount) return wallet;
  const transaction = addTransaction(wallet, -amount, label, 'purchase');
  return {
    ...wallet,
    balance: wallet.balance - amount,
    totalSpent: wallet.totalSpent + amount,
    ledger: [transaction, ...wallet.ledger].slice(0, 300),
  };
}

export function creditWallet(
  wallet: WalletState,
  points: number,
  label: string,
  id?: string,
  source: WalletTransaction['source'] = 'farm',
): WalletState {
  const amount = Math.max(0, Math.floor(points));
  if (amount === 0) return wallet;
  const transaction = addTransaction(wallet, amount, label, source, id);
  return {
    ...wallet,
    balance: wallet.balance + amount,
    totalEarned: wallet.totalEarned + amount,
    ledger: [transaction, ...wallet.ledger].slice(0, 300),
  };
}

/** تسجّل زمناً مرئياً ونشطاً؛ كل ٣٦٠ ثانية تمنح نقطة (١٠ نقاط/ساعة). */
export function recordStudySeconds(subjectId: string, seconds: number): Promise<number> {
  const safeSeconds = Math.max(0, Math.min(30, Math.floor(seconds)));
  if (safeSeconds === 0) return Promise.resolve(0);

  return withStorageLock('wallet', [KEYS.wallet, KEYS.stats, KEYS.farm], () => {
    let pointsGranted = 0;
    let acceptedSeconds = 0;
    const now = Date.now();
    const previousCreditAt = getWallet().lastCreditAt;
    if (previousCreditAt > 0 && Math.floor((now - previousCreditAt) / 1000) === 0) return 0;
    updateKey<WalletState>(
      KEYS.wallet,
      (raw) => {
        const wallet = normalizeWallet(raw);
        // يدمج عدّادي الفيديو والاختبار دون عدّ الثواني المتداخلة مرتين.
        const elapsedSinceCredit = wallet.lastCreditAt > 0 ? Math.floor((now - wallet.lastCreditAt) / 1000) : safeSeconds;
        acceptedSeconds = Math.max(0, Math.min(safeSeconds, elapsedSinceCredit));
        if (acceptedSeconds === 0) return wallet;
        const combined = wallet.remainderSeconds + acceptedSeconds;
        pointsGranted = Math.floor(combined / 360);
        const remainderSeconds = combined % 360;
        const next: WalletState = {
          ...wallet,
          balance: wallet.balance + pointsGranted,
          totalEarned: wallet.totalEarned + pointsGranted,
          studySeconds: wallet.studySeconds + acceptedSeconds,
          remainderSeconds,
          lastCreditAt: now,
        };
        if (pointsGranted > 0) {
          next.ledger = [
            addTransaction(wallet, pointsGranted, 'مكافأة وقت دراسة نشط', 'study'),
            ...wallet.ledger,
          ].slice(0, 300);
        }
        return next;
      },
      EMPTY_WALLET,
    );

    if (acceptedSeconds > 0) {
      const today = localDateKey();
      updateKey<{ days: Record<string, { seconds: number; bySubject: Record<string, number> }> }>(
        KEYS.stats,
        (state) => {
          const day = state.days?.[today] ?? { seconds: 0, bySubject: {} };
          return {
            days: {
              ...state.days,
              [today]: {
                seconds: day.seconds + acceptedSeconds,
                bySubject: {
                  ...day.bySubject,
                  [subjectId]: (day.bySubject[subjectId] ?? 0) + acceptedSeconds,
                },
              },
            },
          };
        },
        { days: {} },
      );
      const currentFarm = normalizeFarm(readKey<FarmState>(KEYS.farm, EMPTY_FARM));
      const grownFarm = growFarmWithStudySeconds(currentFarm, acceptedSeconds);
      if (grownFarm !== currentFarm) writeKey(KEYS.farm, grownFarm);
    }
    return pointsGranted;
  });
}

/** مكافأة لمرة واحدة بمفتاح idempotency لمنع المطالبة المكررة. */
export function grantRewardOnce(
  claimId: string,
  points: number,
  label: string,
  source: 'challenge' | 'achievement',
): Promise<boolean> {
  if (!claimId || points <= 0) return Promise.resolve(false);
  return withStorageLock('wallet', [KEYS.wallet], () => {
    let granted = false;
    updateKey<WalletState>(
      KEYS.wallet,
      (raw) => {
        const wallet = normalizeWallet(raw);
        if (wallet.claimedRewardIds.includes(claimId)) return wallet;
        granted = true;
        const transaction = addTransaction(wallet, points, label, source, claimId);
        const achievementId = source === 'achievement' ? claimId.slice('achievement:'.length) : undefined;
        const next: WalletState = {
          ...wallet,
          balance: wallet.balance + points,
          totalEarned: wallet.totalEarned + points,
          claimedRewardIds: [...wallet.claimedRewardIds, claimId],
          claimedRewardAt: { ...wallet.claimedRewardAt, [claimId]: transaction.at },
          achievementUnlockedAt: achievementId
            ? { ...wallet.achievementUnlockedAt, [achievementId]: wallet.achievementUnlockedAt[achievementId] ?? transaction.at }
            : wallet.achievementUnlockedAt,
        };
        return { ...next, ledger: [transaction, ...wallet.ledger].slice(0, 300) };
      },
      EMPTY_WALLET,
    );
    return granted;
  });
}

/** يحفظ أول تاريخ رُصد فيه استحقاق الإنجاز، دون إنشاء معاملة مالية. */
export function recordAchievementUnlocks(ids: string[], dates: Record<string, number> = {}): Promise<void> {
  if (ids.length === 0) return Promise.resolve();
  return withStorageLock('wallet', [KEYS.wallet], () => {
    const at = Date.now();
    updateKey<WalletState>(
      KEYS.wallet,
      (raw) => {
        const wallet = normalizeWallet(raw);
        const next = { ...wallet.achievementUnlockedAt };
        let changed = false;
        for (const id of ids) {
          if (!next[id]) {
            next[id] = dates[id] ?? at;
            changed = true;
          }
        }
        return changed ? { ...wallet, achievementUnlockedAt: next } : wallet;
      },
      EMPTY_WALLET,
    );
  });
}

export type ShopFailure = 'missing' | 'funds' | 'owned' | 'not_owned' | 'consumable' | 'slot' | 'protected' | 'empty';
export type ShopResult = { ok: true; wallet: WalletState } | { ok: false; reason: ShopFailure };

export function buyReward(itemId: string): Promise<ShopResult> {
  const item = byId.get(itemId);
  if (!item) return Promise.resolve({ ok: false, reason: 'missing' });
  return withStorageLock('wallet', [KEYS.wallet], () => {
    const result = { reason: 'funds' as ShopFailure };
    const wallet = updateKey<WalletState>(
      KEYS.wallet,
      (raw) => {
        const current = normalizeWallet(raw);
        if (current.balance < item.price) {
          result.reason = 'funds';
          return current;
        }
        if (item.category !== 'consumable' && (current.owned[item.id] ?? 0) > 0) {
          result.reason = 'owned';
          return current;
        }
        const next: WalletState = {
          ...current,
          balance: current.balance - item.price,
          totalSpent: current.totalSpent + item.price,
          owned: { ...current.owned, [item.id]: (current.owned[item.id] ?? 0) + 1 },
        };
        result.reason = 'missing';
        return {
          ...next,
          ledger: [addTransaction(current, -item.price, `شراء: ${item.name}`, 'purchase'), ...current.ledger].slice(0, 300),
        };
      },
      EMPTY_WALLET,
    );
    return result.reason === 'missing' ? { ok: true, wallet } : { ok: false, reason: result.reason };
  });
}

export function equipReward(itemId: string): Promise<ShopResult> {
  const item = byId.get(itemId);
  if (!item) return Promise.resolve({ ok: false, reason: 'missing' });
  if (!item.slot) return Promise.resolve({ ok: false, reason: 'consumable' });
  return withStorageLock('wallet', [KEYS.wallet], () => {
    const result = { reason: 'not_owned' as 'not_owned' | 'slot' | 'missing' };
    const wallet = updateKey<WalletState>(
      KEYS.wallet,
      (raw) => {
        const current = normalizeWallet(raw);
        if ((current.owned[itemId] ?? 0) < 1) return current;
        if (!item.slot) {
          result.reason = 'slot';
          return current;
        }
        result.reason = 'missing';
        return { ...current, equipped: { ...current.equipped, [item.slot]: itemId } };
      },
      EMPTY_WALLET,
    );
    return result.reason === 'missing' ? { ok: true, wallet } : { ok: false, reason: result.reason };
  });
}

export function unequipReward(slot: RewardSlot): Promise<WalletState> {
  return withStorageLock('wallet', [KEYS.wallet], () => updateKey<WalletState>(
    KEYS.wallet,
    (raw) => {
      const current = normalizeWallet(raw);
      const equipped = { ...current.equipped };
      delete equipped[slot];
      return { ...current, equipped };
    },
    EMPTY_WALLET,
  ));
}

/** تفعيل الحماية لليوم الحالي؛ تُستهلك مرة وتُستخدم عند حساب السلسلة في اليوم التالي. */
export function useStreakShield(itemId = 'streak-shield'): Promise<ShopResult> {
  const item = byId.get(itemId);
  if (!item || item.category !== 'consumable') return Promise.resolve({ ok: false, reason: 'missing' });
  return withStorageLock('wallet', [KEYS.wallet], () => {
    const today = localDateKey();
    const result = { reason: 'empty' as 'empty' | 'protected' | 'missing' };
    const wallet = updateKey<WalletState>(
      KEYS.wallet,
      (raw) => {
        const current = normalizeWallet(raw);
        const quantity = current.owned[itemId] ?? 0;
        if (quantity < 1) return current;
        if (current.streakFreezeDates.includes(today)) {
          result.reason = 'protected';
          return current;
        }
        result.reason = 'missing';
        const next: WalletState = {
          ...current,
          owned: { ...current.owned, [itemId]: quantity - 1 },
          streakFreezeDates: [...current.streakFreezeDates, today],
        };
        return {
          ...next,
          ledger: [addTransaction(current, 0, `تفعيل حماية السلسلة ليوم ${today}`, 'consumable'), ...current.ledger].slice(0, 300),
        };
      },
      EMPTY_WALLET,
    );
    return result.reason === 'missing' ? { ok: true, wallet } : { ok: false, reason: result.reason };
  });
}

export function rewardForId(itemId?: string): RewardItem | undefined {
  return itemId ? byId.get(itemId) : undefined;
}

export function nextPointProgress(): number {
  return Math.round((getWallet().remainderSeconds / 360) * 100);
}

export function categoryLabel(category: RewardCategory): string {
  return ({
    accent: 'ألوان الواجهة',
    frame: 'إطارات الملف',
    banner: 'لافتات الملف',
    consumable: 'أدوات استهلاكية',
    vehicle: 'مركبات افتراضية',
    'player-card': 'بطاقات لاعبين رقمية',
    device: 'أجهزة رقمية',
    furniture: 'أثاث الدراسة',
    decoration: 'ديكور المجموعة',
    companion: 'رفاق الدراسة',
  })[category];
}
