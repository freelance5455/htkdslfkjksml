import JSZip from 'jszip';

export interface DownloadFile {
  path: string;
  content: string;
}

export const ALL_ANDROID_FILES: DownloadFile[] = [
  // Root Gradle & Configuration
  {
    path: 'ArrowEscape/settings.gradle.kts',
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "ArrowEscape"
include(":app")
`,
  },
  {
    path: 'ArrowEscape/build.gradle.kts',
    content: `plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.google.services) apply false
    alias(libs.plugins.ksp) apply false
}
`,
  },
  {
    path: 'ArrowEscape/gradle.properties',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
`,
  },
  {
    path: 'ArrowEscape/gradle/libs.versions.toml',
    content: `[versions]
agp = "8.7.2"
kotlin = "2.0.21"
ksp = "2.0.21-1.0.28"
coreKtx = "1.15.0"
junit = "4.13.2"
androidxTestExt = "1.2.1"
espressoCore = "3.6.1"
lifecycleRuntimeKtx = "2.8.7"
activityCompose = "1.9.3"
composeBom = "2024.10.01"
navigationCompose = "2.8.3"
room = "2.6.1"
datastore = "1.1.1"
coroutines = "1.9.0"
firebaseBom = "33.5.1"
googleServices = "4.4.2"
credentialManager = "1.3.0"
googleId = "1.1.1"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntimeKtx" }
androidx-lifecycle-viewmodel-compose = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-compose", version.ref = "lifecycleRuntimeKtx" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-ui-tooling = { group = "androidx.compose.ui", name = "ui-tooling" }
androidx-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-material-icons-extended = { group = "androidx.compose.material", name = "material-icons-extended" }
androidx-navigation-compose = { group = "androidx.navigation", name = "navigation-compose", version.ref = "navigationCompose" }
androidx-room-runtime = { group = "androidx.room", name = "room-runtime", version.ref = "room" }
androidx-room-ktx = { group = "androidx.room", name = "room-ktx", version.ref = "room" }
androidx-room-compiler = { group = "androidx.room", name = "room-compiler", version.ref = "room" }
androidx-datastore-preferences = { group = "androidx.datastore", name = "datastore-preferences", version.ref = "datastore" }
kotlinx-coroutines-android = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-android", version.ref = "coroutines" }
kotlinx-coroutines-play-services = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-play-services", version.ref = "coroutines" }
firebase-bom = { group = "com.google.firebase", name = "firebase-bom", version.ref = "firebaseBom" }
firebase-auth-ktx = { group = "com.google.firebase", name = "firebase-auth-ktx" }
firebase-firestore-ktx = { group = "com.google.firebase", name = "firebase-firestore-ktx" }
androidx-credentials = { group = "androidx.credentials", name = "credentials", version.ref = "credentialManager" }
androidx-credentials-play-services-auth = { group = "androidx.credentials", name = "credentials-play-services-auth", version.ref = "credentialManager" }
google-id = { group = "com.google.android.libraries.identity.googleid", name = "googleid", version.ref = "googleId" }
junit = { group = "junit", name = "junit", version.ref = "junit" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
google-services = { id = "com.google.gms.google-services", version.ref = "googleServices" }
ksp = { id = "com.google.devtools.ksp", version.ref = "ksp" }
`,
  },
  // App Gradle build file
  {
    path: 'ArrowEscape/app/build.gradle.kts',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
    alias(libs.plugins.google.services)
}

android {
    namespace = "com.arrowescape.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.arrowescape.game"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.play-services)
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.auth.ktx)
    implementation(libs.firebase.firestore.ktx)
    implementation(libs.androidx.credentials)
    implementation(libs.androidx.credentials.play-services-auth)
    implementation(libs.google.id)
    testImplementation(libs.junit)
}
`,
  },
  // Manifest
  {
    path: 'ArrowEscape/app/src/main/AndroidManifest.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.ArrowEscape">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:theme="@style/Theme.ArrowEscape">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`,
  },
  // Resources
  {
    path: 'ArrowEscape/app/src/main/res/values/strings.xml',
    content: `<resources>
    <string name="app_name">Arrow Escape</string>
    <string name="default_web_client_id">YOUR_WEB_CLIENT_ID.apps.googleusercontent.com</string>
</resources>
`,
  },
  {
    path: 'ArrowEscape/app/src/main/res/values/colors.xml',
    content: `<resources>
    <color name="black">#000000</color>
    <color name="white">#FFFFFF</color>
    <color name="dark_gray">#121212</color>
</resources>
`,
  },
  {
    path: 'ArrowEscape/app/src/main/res/values/themes.xml',
    content: `<resources>
    <style name="Theme.ArrowEscape" parent="android:Theme.Material.NoActionBar">
        <item name="android:statusBarColor">@color/black</item>
        <item name="android:navigationBarColor">@color/black</item>
        <item name="android:windowBackground">@color/black</item>
    </style>
</resources>
`,
  },
  // Models
  {
    path: 'ArrowEscape/app/src/main/java/com/arrowescape/game/model/Direction.kt',
    content: `package com.arrowescape.game.model

enum class Direction {
    UP, DOWN, LEFT, RIGHT
}
`,
  },
  {
    path: 'ArrowEscape/app/src/main/java/com/arrowescape/game/model/Arrow.kt',
    content: `package com.arrowescape.game.model

data class Point(val x: Int, val y: Int)

data class Arrow(
    val id: String,
    val points: List<Point>,
    val row: Int,
    val col: Int,
    val direction: Direction,
    val isEscaping: Boolean = false,
    val isHinted: Boolean = false,
    val isInvalid: Boolean = false
)
`,
  },
  {
    path: 'ArrowEscape/app/src/main/java/com/arrowescape/game/model/Level.kt',
    content: `package com.arrowescape.game.model

enum class Difficulty {
    BEGINNER, INTERMEDIATE, ADVANCED, MASTER, ULTIMATE
}

data class Level(
    val id: Int,
    val gridRows: Int,
    val gridCols: Int,
    val arrows: List<Arrow>,
    val difficulty: Difficulty,
    val optimalMoves: Int,
    val parTimeSec: Int
)
`,
  },
  {
    path: 'ArrowEscape/app/src/main/java/com/arrowescape/game/model/UserProgress.kt',
    content: `package com.arrowescape.game.model

data class LevelProgress(
    val stars: Int = 0,
    val bestTimeSec: Int = 0,
    val bestMoves: Int = 0,
    val completedAt: String = ""
)

data class GameSettings(
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val animationSpeed: String = "normal",
    val contrastTheme: String = "paper_light"
)

data class UserProgress(
    val currentLevel: Int = 1,
    val completedLevels: Map<Int, LevelProgress> = emptyMap(),
    val totalStars: Int = 0,
    val totalScore: Int = 0,
    val settings: GameSettings = GameSettings(),
    val lastUpdated: String = "",
    val pendingSync: Boolean = false
)

data class AuthUser(
    val uid: String,
    val displayName: String?,
    val email: String?,
    val photoUrl: String?,
    val isGuest: Boolean
)
`,
  },
  // Solver
  {
    path: 'ArrowEscape/app/src/main/java/com/arrowescape/game/solver/ArrowSolver.kt',
    content: `package com.arrowescape.game.solver

import com.arrowescape.game.model.Arrow
import com.arrowescape.game.model.Direction
import com.arrowescape.game.model.Point
import kotlin.math.sign

object ArrowSolver {

    fun getArrowOccupiedPoints(arrow: Arrow): Set<String> {
        val occupied = mutableSetOf<String>()
        val pts = arrow.points
        if (pts.isEmpty()) {
            occupied.add("\${arrow.col},\${arrow.row}")
            return occupied
        }

        for (i in pts.indices) {
            occupied.add("\${pts[i].x},\${pts[i].y}")
            if (i < pts.size - 1) {
                val dx = (pts[i+1].x - pts[i].x).sign
                val dy = (pts[i+1].y - pts[i].y).sign
                var cx = pts[i].x + dx
                var cy = pts[i].y + dy
                while (cx != pts[i+1].x || cy != pts[i+1].y) {
                    occupied.add("$cx,$cy")
                    cx += dx
                    cy += dy
                }
            }
        }
        return occupied
    }

    fun isArrowPathClear(
        arrow: Arrow,
        allArrows: List<Arrow>,
        gridRows: Int,
        gridCols: Int
    ): Boolean {
        val occupied = mutableSetOf<String>()
        for (other in allArrows) {
            if (other.id != arrow.id && !other.isEscaping) {
                occupied.addAll(getArrowOccupiedPoints(other))
            }
        }

        val head = if (arrow.points.isNotEmpty()) arrow.points.last() else Point(arrow.col, arrow.row)
        var x = head.x
        var y = head.y

        return when (arrow.direction) {
            Direction.UP -> {
                while (y > 0) {
                    y -= 1
                    if (occupied.contains("$x,$y")) return false
                }
                true
            }
            Direction.DOWN -> {
                while (y < gridRows - 1) {
                    y += 1
                    if (occupied.contains("$x,$y")) return false
                }
                true
            }
            Direction.LEFT -> {
                while (x > 0) {
                    x -= 1
                    if (occupied.contains("$x,$y")) return false
                }
                true
            }
            Direction.RIGHT -> {
                while (x < gridCols - 1) {
                    x += 1
                    if (occupied.contains("$x,$y")) return false
                }
                true
            }
        }
    }

    fun getEscapableArrows(
        arrows: List<Arrow>,
        gridRows: Int,
        gridCols: Int
    ): List<Arrow> {
        val active = arrows.filter { !it.isEscaping }
        return active.filter { isArrowPathClear(it, active, gridRows, gridCols) }
    }

    fun solveLevel(
        initialArrows: List<Arrow>,
        gridRows: Int,
        gridCols: Int
    ): List<String>? {
        var current = initialArrows.toList()
        val solution = mutableListOf<String>()

        while (current.isNotEmpty()) {
            val escapable = getEscapableArrows(current, gridRows, gridCols)
            if (escapable.isEmpty()) return null
            val chosen = escapable.first()
            solution.add(chosen.id)
            current = current.filter { it.id != chosen.id }
        }

        return solution
    }

    fun getHintArrow(
        arrows: List<Arrow>,
        gridRows: Int,
        gridCols: Int
    ): Arrow? {
        val escapable = getEscapableArrows(arrows, gridRows, gridCols)
        if (escapable.isEmpty()) return null

        for (candidate in escapable) {
            val remaining = arrows.filter { !it.isEscaping && it.id != candidate.id }
            if (solveLevel(remaining, gridRows, gridCols) != null) {
                return candidate
            }
        }
        return escapable.firstOrNull()
    }
}
`,
  },
  // Generator with 10 to 200 Arrows Scaling
  {
    path: 'ArrowEscape/app/src/main/java/com/arrowescape/game/generator/DeterministicLevelGenerator.kt',
    content: `package com.arrowescape.game.generator

import com.arrowescape.game.model.*
import com.arrowescape.game.solver.ArrowSolver

class Mulberry32Rng(seed: Long) {
    private var state: Long = seed and 0xFFFFFFFFL
    fun next(): Float {
        state = (state + 0x6D2B79F5L) and 0xFFFFFFFFL
        var t = state xor (state ushr 15)
        t = (t * (1L or state)) and 0xFFFFFFFFL
        t = (t xor (t + ((t xor (t ushr 7)) * 61L))) and 0xFFFFFFFFL
        val res = (t xor (t ushr 14)) and 0xFFFFFFFFL
        return (res.toDouble() / 4294967296.0).toFloat()
    }
}

object DeterministicLevelGenerator {

    fun getDifficultyForLevel(levelId: Int): Difficulty = when {
        levelId <= 10 -> Difficulty.BEGINNER
        levelId <= 100 -> Difficulty.INTERMEDIATE
        levelId <= 500 -> Difficulty.ADVANCED
        levelId <= 800 -> Difficulty.MASTER
        else -> Difficulty.ULTIMATE
    }

    private val DIRECTIONS = listOf(Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT)

    private fun getDirVector(dir: Direction): Pair<Int, Int> = when (dir) {
        Direction.UP -> Pair(0, -1)
        Direction.DOWN -> Pair(0, 1)
        Direction.LEFT -> Pair(-1, 0)
        Direction.RIGHT -> Pair(1, 0)
    }

    private fun getOppositeDir(dir: Direction): Direction = when (dir) {
        Direction.UP -> Direction.DOWN
        Direction.DOWN -> Direction.UP
        Direction.LEFT -> Direction.RIGHT
        Direction.RIGHT -> Direction.LEFT
    }

    private fun getPerpendicularDirs(dir: Direction): List<Direction> = when (dir) {
        Direction.UP, Direction.DOWN -> listOf(Direction.LEFT, Direction.RIGHT)
        Direction.LEFT, Direction.RIGHT -> listOf(Direction.UP, Direction.DOWN)
    }

    fun generateLevel(levelId: Int): Level {
        val clampedId = levelId.coerceIn(1, 1000)
        val difficulty = getDifficultyForLevel(clampedId)

        var gridCols = 10
        var gridRows = 12
        var targetArrows = 16
        var parTimeSec = 120

        if (clampedId == 1) {
            targetArrows = 16
            gridCols = 10
            gridRows = 12
            parTimeSec = 120
        } else if (clampedId <= 10) {
            val ratio = (clampedId - 2) / 8.0
            targetArrows = (20 + ratio * 20).toInt()
            gridCols = (11 + ratio * 3).toInt()
            gridRows = (13 + ratio * 3).toInt()
            parTimeSec = 150
        } else if (clampedId <= 50) {
            val ratio = (clampedId - 11) / 39.0
            targetArrows = (30 + ratio * 30).toInt()
            gridCols = (14 + ratio * 4).toInt()
            gridRows = (16 + ratio * 5).toInt()
            parTimeSec = 180
        } else if (clampedId <= 100) {
            val ratio = (clampedId - 51) / 49.0
            targetArrows = (50 + ratio * 30).toInt()
            gridCols = (18 + ratio * 4).toInt()
            gridRows = (21 + ratio * 5).toInt()
            parTimeSec = 210
        } else if (clampedId <= 500) {
            val ratio = (clampedId - 101) / 399.0
            targetArrows = (70 + ratio * 50).toInt()
            gridCols = (22 + ratio * 5).toInt()
            gridRows = (26 + ratio * 6).toInt()
            parTimeSec = 260
        } else {
            val ratio = (clampedId - 501) / 499.0
            targetArrows = (100 + ratio * 100).toInt()
            gridCols = (27 + ratio * 6).toInt()
            gridRows = (32 + ratio * 8).toInt()
            parTimeSec = 300
        }

        val rng = Mulberry32Rng((clampedId.toLong() * 10007L + 42L) and 0xFFFFFFFFL)
        val arrows = buildReverseWindingMaze(gridRows, gridCols, targetArrows, rng)
        val solution = ArrowSolver.solveLevel(arrows, gridRows, gridCols)

        return Level(
            id = clampedId,
            gridRows = gridRows,
            gridCols = gridCols,
            arrows = arrows,
            difficulty = difficulty,
            optimalMoves = solution?.size ?: arrows.size,
            parTimeSec = parTimeSec
        )
    }

    private fun buildReverseWindingMaze(
        rows: Int,
        cols: Int,
        targetCount: Int,
        rng: Mulberry32Rng
    ): List<Arrow> {
        val arrows = mutableListOf<Arrow>()
        val occupied = Array(rows) { BooleanArray(cols) { false } }
        var arrowId = 1
        var failures = 0

        while (arrows.size < targetCount && failures < targetCount * 3) {
            val emptyCells = mutableListOf<Pair<Int, Int>>()
            for (y in 0 until rows) {
                for (x in 0 until cols) {
                    if (!occupied[y][x]) emptyCells.add(Pair(x, y))
                }
            }
            if (emptyCells.isEmpty()) break

            val idx = (rng.next() * emptyCells.size).toInt().coerceIn(0, emptyCells.size - 1)
            val (hx, hy) = emptyCells[idx]

            val validDirs = DIRECTIONS.filter { dir ->
                val (dx, dy) = getDirVector(dir)
                var x = hx + dx
                var y = hy + dy
                var clear = true
                while (x in 0 until cols && y in 0 until rows) {
                    if (occupied[y][x]) { clear = false; break }
                    x += dx; y += dy
                }
                clear
            }

            if (validDirs.isEmpty()) {
                failures++
                continue
            }

            val chosenDir = validDirs[(rng.next() * validDirs.size).toInt().coerceIn(0, validDirs.size - 1)]
            val body = mutableListOf(Point(hx, hy))
            var currX = hx
            var currY = hy
            var currentBackDir = getOppositeDir(chosenDir)
            val maxBends = if (rng.next() < 0.35f) 1 else if (rng.next() < 0.75f) 2 else 3
            var bends = 0

            while (bends < maxBends) {
                val segLength = 1 + (rng.next() * 3).toInt()
                val (dx, dy) = getDirVector(currentBackDir)
                var steps = 0
                for (s in 0 until segLength) {
                    val nx = currX + dx
                    val ny = currY + dy
                    if (nx in 0 until cols && ny in 0 until rows && !occupied[ny][nx] && body.none { it.x == nx && it.y == ny }) {
                        currX = nx; currY = ny
                        body.add(Point(currX, currY))
                        steps++
                    } else break
                }
                if (steps == 0) break
                val turns = getPerpendicularDirs(currentBackDir)
                currentBackDir = turns[(rng.next() * turns.size).toInt().coerceIn(0, turns.size - 1)]
                bends++
            }

            if (body.size >= 2) {
                val points = body.reversed()
                val head = points.last()
                for (p in points) occupied[p.y][p.x] = true
                arrows.add(Arrow("arrow_\${arrowId++}", points, head.y, head.x, chosenDir))
                failures = 0
            } else {
                failures++
            }
        }
        return arrows
    }
}
`,
  },
  // MainActivity
  {
    path: 'ArrowEscape/app/src/main/java/com/arrowescape/game/MainActivity.kt',
    content: `package com.arrowescape.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.arrowescape.game.data.GameRepository
import com.arrowescape.game.data.local.GameDatabase
import com.arrowescape.game.data.local.UserPreferencesRepository
import com.arrowescape.game.data.remote.AuthManager
import com.arrowescape.game.ui.screens.*
import com.arrowescape.game.ui.theme.ArrowEscapeTheme
import com.arrowescape.game.ui.theme.PureBlack
import kotlinx.coroutines.launch

enum class Screen { TITLE, GAME, LEVEL_SELECT, SETTINGS }

class MainActivity : ComponentActivity() {
    private lateinit var repository: GameRepository
    private lateinit var authManager: AuthManager
    private lateinit var preferencesRepo: UserPreferencesRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = GameDatabase.getDatabase(this)
        repository = GameRepository(db.progressDao())
        authManager = AuthManager(this)
        preferencesRepo = UserPreferencesRepository(this)

        setContent {
            ArrowEscapeTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = PureBlack) {
                    AppNavigation(repository, authManager, preferencesRepo)
                }
            }
        }
    }
}

@Composable
fun AppNavigation(
    repository: GameRepository,
    authManager: AuthManager,
    preferencesRepo: UserPreferencesRepository
) {
    var currentScreen by remember { mutableStateOf(Screen.TITLE) }
    var selectedLevelId by remember { mutableIntStateOf(1) }

    val userProgress by repository.userProgressFlow.collectAsState(initial = com.arrowescape.game.model.UserProgress())
    val authUser by authManager.currentUser.collectAsState()
    val settings by preferencesRepo.settingsFlow.collectAsState(initial = com.arrowescape.game.model.GameSettings())
    val scope = rememberCoroutineScope()

    when (currentScreen) {
        Screen.TITLE -> {
            TitleScreen(
                currentLevel = userProgress.currentLevel,
                totalStars = userProgress.totalStars,
                authUser = authUser,
                onPlay = {
                    selectedLevelId = userProgress.currentLevel
                    currentScreen = Screen.GAME
                },
                onLevelSelect = { currentScreen = Screen.LEVEL_SELECT },
                onSettings = { currentScreen = Screen.SETTINGS },
                onGoogleSignIn = { scope.launch { authManager.signInWithGoogle("WEB_CLIENT_ID") } },
                onSignOut = { authManager.signOut() }
            )
        }
        Screen.GAME -> {
            GamePlayScreen(
                levelId = selectedLevelId,
                onBackToTitle = { currentScreen = Screen.TITLE },
                onNextLevel = { nextId -> selectedLevelId = nextId },
                onLevelCompleted = { lvlId, stars, time, moves ->
                    scope.launch {
                        repository.saveLevelCompletion(lvlId, stars, time, moves, authUser?.uid)
                    }
                }
            )
        }
        Screen.LEVEL_SELECT -> {
            LevelSelectScreen(
                currentUnlockedLevel = userProgress.currentLevel,
                completedLevels = userProgress.completedLevels,
                onSelectLevel = { lvlId ->
                    selectedLevelId = lvlId
                    currentScreen = Screen.GAME
                },
                onBack = { currentScreen = Screen.TITLE }
            )
        }
        Screen.SETTINGS -> {
            SettingsScreen(
                settings = settings,
                authUser = authUser,
                onToggleSound = { scope.launch { preferencesRepo.updateSound(it) } },
                onToggleHaptics = { scope.launch { preferencesRepo.updateHaptics(it) } },
                onGoogleSignIn = { scope.launch { authManager.signInWithGoogle("WEB_CLIENT_ID") } },
                onSignOut = { authManager.signOut() },
                onBack = { currentScreen = Screen.TITLE }
            )
        }
    }
}
`,
  },
  // Security rules & documentation
  {
    path: 'ArrowEscape/firestore.rules',
    content: `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/progress/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
`,
  },
  {
    path: 'ArrowEscape/README.md',
    content: `# Arrow Escape — Native Android Game Project

## Build & Run Instructions
1. Open Android Studio (Ladybug / Koala / Hedgehog).
2. Choose **Open an Existing Project** and select this unzipped \`ArrowEscape\` folder.
3. Allow Gradle to synchronize dependencies.
4. Add your \`google-services.json\` downloaded from Firebase Console to \`app/google-services.json\`.
5. Connect an Android device or launch an emulator (API 26+).
6. Click **Run > Run 'app'** or run in terminal:
   \`\`\`bash
   ./gradlew installDebug
   \`\`\`
7. To run the automated solvability tests:
   \`\`\`bash
   ./gradlew test
   \`\`\`
8. To build signed release APK:
   \`\`\`bash
   ./gradlew assembleRelease
   \`\`\`
`,
  },
];

/**
 * Packs all native Android files and triggers immediate browser download.
 */
export async function downloadAndroidProjectZip(onProgress?: (msg: string) => void): Promise<void> {
  onProgress?.('Preparing Android Studio project files...');
  const zip = new JSZip();

  for (const file of ALL_ANDROID_FILES) {
    zip.file(file.path, file.content);
  }

  onProgress?.('Compressing project archive...');
  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  onProgress?.('Starting download...');
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'ArrowEscape-Android-Project.zip';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
