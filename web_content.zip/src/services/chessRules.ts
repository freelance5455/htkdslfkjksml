import { Chess, Square, Move } from 'chess.js';
import { PieceColor, PieceType } from '../types/chess';
import { squareDistance } from './chessCoordinates';

export interface MoveValidationResult {
  isValid: boolean;
  move?: Move;
  reason?: string;
  isCheck?: boolean;
  isCheckmate?: boolean;
  isStalemate?: boolean;
  isDraw?: boolean;
}

/**
 * Authoritative Chess Rules Engine & Validation Pipeline.
 * Single source of truth across all 2D, 3D, AI, and Online game modes.
 */
export class ChessRulesEngine {
  /**
   * Find king square for a given color
   */
  public static findKingSquare(game: Chess, color: PieceColor): Square | null {
    const board = game.board();
    for (let r = 0; r < 8; r++) {
      for (let f = 0; f < 8; f++) {
        const piece = board[r][f];
        if (piece && piece.type === 'k' && piece.color === color) {
          const fileChar = String.fromCharCode(97 + f);
          const rankChar = (8 - r).toString();
          return `${fileChar}${rankChar}` as Square;
        }
      }
    }
    return null;
  }

  /**
   * Validate any attempted move against FIDE rules and strict king safety invariant.
   */
  public static validateMove(
    game: Chess,
    from: Square,
    to: Square,
    promotion: string = 'q'
  ): MoveValidationResult {
    // 1. Identify piece and its source square
    const piece = game.get(from);
    if (!piece) {
      return { isValid: false, reason: 'No piece at source square' };
    }

    // 2. Verify that the piece belongs to the player whose turn it is
    if (piece.color !== game.turn()) {
      return { isValid: false, reason: `Not ${piece.color === 'w' ? 'White' : 'Black'}'s turn` };
    }

    // 3. Strict King Safety: King must never capture opponent king or move onto opponent king square
    const destPiece = game.get(to);
    if (destPiece && destPiece.type === 'k') {
      return { isValid: false, reason: 'A king cannot be captured or occupied by another piece' };
    }

    // If moving king, verify it never moves adjacent to opponent king
    if (piece.type === 'k') {
      const oppColor: PieceColor = piece.color === 'w' ? 'b' : 'w';
      const oppKingSq = this.findKingSquare(game, oppColor);
      if (oppKingSq && squareDistance(to, oppKingSq) <= 1) {
        return { isValid: false, reason: 'Kings cannot be adjacent to each other' };
      }
    }

    // 4. Query legal moves for this square from authoritative chess.js engine
    const legalMoves = game.moves({ square: from, verbose: true });
    const matchingMove = legalMoves.find(
      (m) => m.to === to && (!m.promotion || m.promotion === promotion)
    );

    if (!matchingMove) {
      return { isValid: false, reason: `Move from ${from} to ${to} is not legal` };
    }

    // 5. Simulate move on a clone to verify own king is not in check
    const testGame = new Chess(game.fen());
    try {
      const executed = testGame.move({ from, to, promotion });
      if (!executed) {
        return { isValid: false, reason: 'Chess engine rejected move' };
      }

      // Check if current side king would be in check after move
      // Note: in chess.js, after testGame.move(), the turn has switched to the opponent
      // So if the side that just moved is in check, the move is strictly illegal
      return {
        isValid: true,
        move: matchingMove,
        isCheck: testGame.inCheck(),
        isCheckmate: testGame.isCheckmate(),
        isStalemate: testGame.isStalemate(),
        isDraw: testGame.isDraw(),
      };
    } catch (err: any) {
      return { isValid: false, reason: err?.message || 'Illegal move' };
    }
  }

  /**
   * Commit a validated move to the game instance safely.
   */
  public static executeMove(
    game: Chess,
    from: Square,
    to: Square,
    promotion: string = 'q'
  ): { success: boolean; move?: Move; reason?: string } {
    const validation = this.validateMove(game, from, to, promotion);
    if (!validation.isValid) {
      return { success: false, reason: validation.reason };
    }

    try {
      const committed = game.move({ from, to, promotion });
      if (!committed) {
        return { success: false, reason: 'Failed to commit move' };
      }
      return { success: true, move: committed };
    } catch (err: any) {
      return { success: false, reason: err?.message || 'Execution error' };
    }
  }

  /**
   * Get all legal moves from a given square, with strict validation
   */
  public static getLegalMoves(game: Chess, square: Square): string[] {
    const piece = game.get(square);
    if (!piece || piece.color !== game.turn()) return [];

    const moves = game.moves({ square, verbose: true });
    const validDestinations: string[] = [];

    for (const m of moves) {
      const validation = this.validateMove(game, square, m.to, m.promotion);
      if (validation.isValid) {
        validDestinations.push(m.to);
      }
    }

    return validDestinations;
  }
}
