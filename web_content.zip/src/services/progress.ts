/** خدمة التقدم: مواضع المشاهدة، الإنجاز، إحصاءات الدراسة، والسلسلة اليومية */
import type { DayStat, Lesson, LessonProgress, Subject } from '../types';
import { allLessons, subjectLessons } from '../data/content';
import { KEYS, readKey, updateKey, writeKey } from './storage';

export type ProgressMap = Record<string, LessonProgress>;

const emptyProgress: ProgressMap = {};

export function getProgressMap(): ProgressMap {
  return readKey<ProgressMap>(KEYS.progress, emptyProgress);
}

export function getLessonProgress(lessonId: string): LessonProgress | undefined {
  return getProgressMap()[lessonId];
}

/** يُستدعى لحفظ موضع التشغيل فقط؛ رصيد وقت الدراسة يُحدّثه useActiveStudy منفصلاً. */
export function savePlayback(lesson: Lesson, position: number, duration: number): void {
  if (!Number.isFinite(position) || position < 0) return;
  const total = duration > 1 ? duration : lesson.duration;
  const ratio = total > 0 ? position / total : 0;
  const prev = getLessonProgress(lesson.id);
  const maxWatched = Math.max(prev?.maxWatched ?? 0, position);
  const completed = Boolean(prev?.completed) || ratio >= 0.9;
  const completedAt = prev?.completedAt ?? (prev?.completed ? prev.updatedAt : ratio >= 0.9 ? Date.now() : undefined);
  updateKey<ProgressMap>(
    KEYS.progress,
    (map) => ({
      ...map,
      [lesson.id]: {
        lessonId: lesson.id,
        position: Math.min(position, total),
        maxWatched,
        duration: total,
        completed,
        updatedAt: Date.now(),
        completedAt,
      },
    }),
    emptyProgress,
  );
}

export function markCompleted(lesson: Lesson): void {
  const prev = getLessonProgress(lesson.id);
  updateKey<ProgressMap>(
    KEYS.progress,
    (map) => ({
      ...map,
      [lesson.id]: {
        lessonId: lesson.id,
        position: prev?.position ?? lesson.duration,
        maxWatched: Math.max(prev?.maxWatched ?? 0, lesson.duration),
        duration: lesson.duration,
        completed: true,
        updatedAt: Date.now(),
        completedAt: prev?.completedAt ?? Date.now(),
      },
    }),
    emptyProgress,
  );
}

export function resetLesson(lessonId: string): void {
  updateKey<ProgressMap>(
    KEYS.progress,
    (map) => {
      const next = { ...map };
      delete next[lessonId];
      return next;
    },
    emptyProgress,
  );
}

/* ------------------------- إحصاءات المشاهدة ------------------------- */

export interface StatsState {
  days: Record<string, { seconds: number; bySubject: Record<string, number> }>;
}

const emptyStats: StatsState = { days: {} };

export function todayKey(d = new Date()): string {
  const y = d.getFullYear();
  const m = `${d.getMonth() + 1}`.padStart(2, '0');
  const day = `${d.getDate()}`.padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function addWatchSeconds(subjectId: string, seconds: number): void {
  if (seconds <= 0) return;
  const key = todayKey();
  updateKey<StatsState>(
    KEYS.stats,
    (state) => {
      const day = state.days[key] ?? { seconds: 0, bySubject: {} };
      return {
        days: {
          ...state.days,
          [key]: {
            seconds: day.seconds + seconds,
            bySubject: { ...day.bySubject, [subjectId]: (day.bySubject[subjectId] ?? 0) + seconds },
          },
        },
      };
    },
    emptyStats,
  );
}

export function getStats(): StatsState {
  return readKey<StatsState>(KEYS.stats, emptyStats);
}

export function totalStudyMinutes(): number {
  const stats = getStats();
  return Math.round(Object.values(stats.days).reduce((sum, d) => sum + d.seconds, 0) / 60);
}

export function minutesOn(dateKey: string): number {
  const day = getStats().days[dateKey];
  return day ? Math.round(day.seconds / 60) : 0;
}

export function last7Days(): DayStat[] {
  const stats = getStats();
  const out: DayStat[] = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const k = todayKey(d);
    out.push({ date: k, seconds: stats.days[k]?.seconds ?? 0 });
  }
  return out;
}

export interface StudyTimeSummary {
  todaySeconds: number;
  weekSeconds: number;
  monthSeconds: number;
  totalSeconds: number;
  weekStart: string;
}

/** يجمع سجل الثواني النشطة حسب التقويم المحلي؛ يبدأ الأسبوع يوم الأحد. */
export function studyTimeSummary(now = new Date()): StudyTimeSummary {
  const stats = getStats();
  const today = todayKey(now);
  const weekStartDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay());
  const weekStart = todayKey(weekStartDate);
  const monthStart = todayKey(new Date(now.getFullYear(), now.getMonth(), 1));
  let todaySeconds = 0;
  let weekSeconds = 0;
  let monthSeconds = 0;
  let totalSeconds = 0;

  for (const [date, entry] of Object.entries(stats.days ?? {})) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > today) continue;
    const rawSeconds = Number(entry?.seconds);
    if (!Number.isFinite(rawSeconds) || rawSeconds <= 0) continue;
    const seconds = Math.floor(rawSeconds);
    totalSeconds += seconds;
    if (date === today) todaySeconds += seconds;
    if (date >= weekStart) weekSeconds += seconds;
    if (date >= monthStart) monthSeconds += seconds;
  }

  return { todaySeconds, weekSeconds, monthSeconds, totalSeconds, weekStart };
}

/** سلسلة الأيام المتتالية التي درس فيها الطالب (≥ دقيقة واحدة) */
export function studyStreak(): number {
  const stats = getStats();
  const freezes = new Set(readKey<{ streakFreezeDates?: string[] }>(KEYS.wallet, { streakFreezeDates: [] }).streakFreezeDates ?? []);
  let streak = 0;
  for (let i = 0; i < 400; i += 1) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const k = todayKey(d);
    const seconds = stats.days[k]?.seconds ?? 0;
    if (seconds >= 60 || freezes.has(k)) {
      streak += 1;
    } else if (i === 0) {
      // اليوم الحالي قد لا يكون قد بدأ بعد، لا يكسر السلسلة
      continue;
    } else {
      break;
    }
  }
  return streak;
}

/* --------------------------- حسابات التقدم --------------------------- */

export function subjectProgress(subject: Subject): number {
  const map = getProgressMap();
  const lessons = subjectLessons(subject);
  if (lessons.length === 0) return 0;
  const done = lessons.filter((l) => map[l.id]?.completed).length;
  return Math.round((done / lessons.length) * 100);
}

export function unitProgress(lessons: Lesson[]): number {
  if (lessons.length === 0) return 0;
  const map = getProgressMap();
  const done = lessons.filter((l) => map[l.id]?.completed).length;
  return Math.round((done / lessons.length) * 100);
}

export function overallProgress(): number {
  const map = getProgressMap();
  const done = allLessons.filter((l) => map[l.id]?.completed).length;
  return allLessons.length === 0 ? 0 : Math.round((done / allLessons.length) * 100);
}

export function completedCount(): number {
  const map = getProgressMap();
  return allLessons.filter((l) => map[l.id]?.completed).length;
}

/** آخر درس شوهد (للبطاقة «تابع من حيث توقفت») */
export function lastWatchedLesson(): { lesson: Lesson; progress: LessonProgress } | undefined {
  const map = getProgressMap();
  const entries = Object.values(map)
    .filter((p) => p.position > 3 && !p.completed)
    .sort((a, b) => b.updatedAt - a.updatedAt);
  for (const p of entries) {
    const lesson = allLessons.find((l) => l.id === p.lessonId);
    if (lesson) return { lesson, progress: p };
  }
  return undefined;
}

export function nextLessonInUnit(lessonId: string): Lesson | undefined {
  const idx = allLessons.findIndex((l) => l.id === lessonId);
  if (idx < 0) return undefined;
  const current = allLessons[idx];
  if (!current) return undefined;
  const unitLessons = allLessons.filter((l) => l.unitId === current.unitId);
  const pos = unitLessons.findIndex((l) => l.id === lessonId);
  return unitLessons[pos + 1];
}

export function previousLessonInUnit(lessonId: string): Lesson | undefined {
  const current = allLessons.find((l) => l.id === lessonId);
  if (!current) return undefined;
  const unitLessons = allLessons.filter((l) => l.unitId === current.unitId);
  const pos = unitLessons.findIndex((l) => l.id === lessonId);
  return pos > 0 ? unitLessons[pos - 1] : undefined;
}

export function clearProgress(): void {
  writeKey<ProgressMap>(KEYS.progress, {});
}
