/**
 * QURILMA VA TELEFONNI 100% BOSHQARISH SERVISI (Full Device Control Engine)
 * Mikrofon, Kamera (Old/Orqa), Chiroq, Vibratsiya, GPS, WakeLock, Batareya, Qo'ng'iroq.
 * Muallif: Мухаммадризо (GitHub: olimovm158-dot)
 */

export type DeviceActionType =
  | 'open_camera'
  | 'take_photo'
  | 'turn_on_torch'
  | 'turn_off_torch'
  | 'vibrate_device'
  | 'get_gps_location'
  | 'make_call'
  | 'open_settings'
  | 'open_code_viewer'
  | 'download_zip'
  | 'system_status'
  | 'wake_lock'
  | 'start_continuous'
  | 'stop_continuous'
  | 'none';

export interface BatteryInfo {
  level: number;
  charging: boolean;
}

export interface DeviceHardwareInfo {
  ramGB?: number;
  cpuCores?: number;
  online: boolean;
  screenResolution: string;
  userAgent: string;
  platform: string;
}

class DeviceService {
  private recognition: any = null;
  private isListening = false;
  private speechSynthesis: SpeechSynthesis | null = null;
  private cameraStream: MediaStream | null = null;
  private torchTrack: MediaStreamTrack | null = null;
  private isTorchOn = false;
  private isScreenTorchActive = false;
  private currentFacingMode: 'environment' | 'user' = 'environment';
  private wakeLockSentinel: any = null;
  private audioStream: MediaStream | null = null;
  // Jarvis Ovoz Sozlamalari (Tezlik, Balandlik, Tembr)
  private speechRate: number = 1.0;
  private speechVolume: number = 1.0;
  private speechPitch: number = 1.0;

  // Doimiy tinglash holati (Continuous Hands-Free Mode)
  private isContinuousListening: boolean = false;
  private isSpeakingNow: boolean = false;
  private restartTimer: any = null;
  private activeOnResult: ((text: string, isFinal: boolean) => void) | null = null;
  private activeOnError: ((error: string) => void) | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.speechSynthesis = window.speechSynthesis || null;
      // LocalStorage dan avvalgi sozlamalarni yuklab olish
      try {
        const savedRate = localStorage.getItem('jarvis_voice_rate');
        const savedVol = localStorage.getItem('jarvis_voice_volume');
        const savedPitch = localStorage.getItem('jarvis_voice_pitch');
        if (savedRate) this.speechRate = parseFloat(savedRate);
        if (savedVol) this.speechVolume = parseFloat(savedVol);
        if (savedPitch) this.speechPitch = parseFloat(savedPitch);
      } catch (e) {}
    }
  }

  public setVoiceSettings(settings: { rate?: number; volume?: number; pitch?: number }) {
    if (settings.rate !== undefined) {
      this.speechRate = Math.max(0.5, Math.min(2.0, settings.rate));
      try { localStorage.setItem('jarvis_voice_rate', this.speechRate.toString()); } catch (e) {}
    }
    if (settings.volume !== undefined) {
      this.speechVolume = Math.max(0.1, Math.min(1.0, settings.volume));
      try { localStorage.setItem('jarvis_voice_volume', this.speechVolume.toString()); } catch (e) {}
    }
    if (settings.pitch !== undefined) {
      this.speechPitch = Math.max(0.5, Math.min(1.5, settings.pitch));
      try { localStorage.setItem('jarvis_voice_pitch', this.speechPitch.toString()); } catch (e) {}
    }
  }

  public getVoiceSettings() {
    return {
      rate: this.speechRate,
      volume: this.speechVolume,
      pitch: this.speechPitch,
    };
  }

  /**
   * BARCHA RUXSATLARNI BIR YO'LA SO'RASH (Mikrofon, Kamera, GPS)
   * Ushbu funksiya telefonda / brauzerda haqiqiy ruxsat berish oynalarini ochadi!
   */
  public async requestAllPermissions(): Promise<{
    mic: boolean;
    camera: boolean;
    gps: boolean;
  }> {
    const result = { mic: false, camera: false, gps: false };

    // 1. Mikrofon va Kamera ruxsati
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: { facingMode: 'environment' },
        });
        result.mic = true;
        result.camera = true;
        // darhol to'xtatamiz, shunchaki ruxsat olingani tasdiqlandi
        stream.getTracks().forEach((t) => t.stop());
      }
    } catch (err: any) {
      console.warn("Mikrofon yoki Kamera ruxsati rad etildi:", err);
      // Alohida audio so'rab ko'ramiz
      try {
        const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        result.mic = true;
        audioStream.getTracks().forEach((t) => t.stop());
      } catch (aErr) {
        result.mic = false;
      }
    }

    // 2. GPS / Joylashuv ruxsati
    try {
      if ('geolocation' in navigator) {
        await new Promise((resolve) => {
          navigator.geolocation.getCurrentPosition(
            () => {
              result.gps = true;
              resolve(true);
            },
            () => {
              result.gps = false;
              resolve(false);
            },
            { timeout: 5000 }
          );
        });
      }
    } catch (e) {
      result.gps = false;
    }

    // Vibratsiya orqali ruxsatlar olinganini tasdiqlash
    this.vibrate([150, 80, 150]);

    return result;
  }

  /**
   * Telefonni tebratish (Haptic Feedback / Vibration)
   */
  public vibrate(pattern: number | number[] = 200): boolean {
    try {
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        return navigator.vibrate(pattern);
      }
    } catch (e) {
      // ignore
    }
    return false;
  }

  /**
   * Ovozli yozib olish (Speech-to-Text)
   * Avval aniq mikrofon oqimini ochib, ruxsatni faollashtiradi!
   */
  public async startListening(
    onResult: (text: string, isFinal: boolean) => void,
    onError: (error: string) => void,
    onEnd: () => void
  ) {
    // 1. Mikrofon ruxsatini kafolatlash
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        this.audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      }
    } catch (permErr: any) {
      console.error("Mikrofon ruxsati xatosi:", permErr);
      onError("Mikrofonga ruxsat berilmadi, Sir. Iltimos brauzerda mikrofonni yoqing.");
      onEnd();
      return;
    }

    // 2. Web Speech API
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      onError("Ushbu brauzerda Web Speech API qo'llab-quvvatlanmaydi, Sir. Iltimos matnli kiritishdan foydalaning.");
      onEnd();
      return;
    }

    try {
      if (this.recognition) {
        try { this.recognition.abort(); } catch (e) {}
      }

      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.lang = 'uz-UZ';

      this.recognition.onstart = () => {
        this.isListening = true;
        this.vibrate(80); // Yozish boshlanganda titrash
      };

      this.recognition.onresult = (event: any) => {
        let transcript = '';
        let isFinal = false;
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            isFinal = true;
          }
        }
        if (transcript.trim()) {
          onResult(transcript.trim(), isFinal);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn("Nutq tanishda xatolik:", event.error);
        if (event.error === 'not-allowed') {
          onError("Mikrofondan foydalanishga ruxsat yo'q, Sir.");
        } else if (event.error !== 'no-speech') {
          onError(`Ovoz yozishda xatolik: ${event.error}`);
        }
        this.isListening = false;
      };

      this.recognition.onend = () => {
        this.isListening = false;
        if (this.audioStream) {
          this.audioStream.getTracks().forEach((t) => t.stop());
          this.audioStream = null;
        }
        onEnd();
      };

      this.recognition.start();
    } catch (e: any) {
      console.error("Speech start xatosi:", e);
      this.isListening = false;
      onError("Ovoz qabul qilish tizimi ishga tushmadi, Sir.");
      onEnd();
    }
  }

  /**
   * DOIMIY TINGLASH REJIMI (Continuous / Hands-Free Listening Mode)
   * Mikrofon to'xtovsiz ishlaydi va foydalanuvchining har bir gapirgan gapini avtomatik Jarvisga jo'natadi.
   */
  public async startContinuousListening(
    onResult: (text: string, isFinal: boolean) => void,
    onError: (error: string) => void
  ) {
    this.isContinuousListening = true;
    this.activeOnResult = onResult;
    this.activeOnError = onError;

    // Mikrofon ruxsatini kafolatlash
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia && !this.audioStream) {
        this.audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      }
    } catch (permErr: any) {
      console.error("Doimiy tinglashda mikrofon ruxsati xatosi:", permErr);
      onError("Mikrofonga ruxsat berilmadi, Sir.");
      this.isContinuousListening = false;
      return;
    }

    this.vibrate([100, 50, 100]);
    this.initContinuousRecognition();
  }

  private initContinuousRecognition() {
    if (!this.isContinuousListening || this.isSpeakingNow) {
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      this.activeOnError?.("Ushbu brauzerda Web Speech API qo'llab-quvvatlanmaydi, Sir.");
      this.isContinuousListening = false;
      return;
    }

    try {
      if (this.recognition) {
        try { this.recognition.abort(); } catch (e) {}
      }

      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'uz-UZ';

      this.recognition.onstart = () => {
        this.isListening = true;
      };

      this.recognition.onresult = (event: any) => {
        let transcript = '';
        let isFinal = false;
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            isFinal = true;
          }
        }
        if (transcript.trim() && this.activeOnResult) {
          this.activeOnResult(transcript.trim(), isFinal);
        }
      };

      this.recognition.onerror = (event: any) => {
        if (event.error === 'not-allowed') {
          this.activeOnError?.("Mikrofondan foydalanishga ruxsat yo'q, Sir.");
          this.isContinuousListening = false;
          this.isListening = false;
          return;
        }
        // no-speech yoki boshqa vaqtinchalik xatolarda qayta ulanish davom etadi
        this.isListening = false;
      };

      this.recognition.onend = () => {
        this.isListening = false;
        // Agar doimiy tinglash faol bo'lsa va Jarvis gapirmayotgan bo'lsa, avtomatik qayta ishga tushirish
        if (this.isContinuousListening && !this.isSpeakingNow) {
          if (this.restartTimer) clearTimeout(this.restartTimer);
          this.restartTimer = setTimeout(() => {
            if (this.isContinuousListening && !this.isSpeakingNow) {
              this.initContinuousRecognition();
            }
          }, 300);
        }
      };

      this.recognition.start();
    } catch (e: any) {
      console.warn("Doimiy tinglashni boshlashda ogohlantirish:", e);
      if (this.isContinuousListening && !this.isSpeakingNow) {
        if (this.restartTimer) clearTimeout(this.restartTimer);
        this.restartTimer = setTimeout(() => {
          if (this.isContinuousListening && !this.isSpeakingNow) {
            this.initContinuousRecognition();
          }
        }, 1000);
      }
    }
  }

  public stopContinuousListening() {
    this.isContinuousListening = false;
    if (this.restartTimer) {
      clearTimeout(this.restartTimer);
      this.restartTimer = null;
    }
    if (this.recognition) {
      try { this.recognition.abort(); } catch (e) {}
      this.recognition = null;
    }
    this.isListening = false;
    if (this.audioStream) {
      this.audioStream.getTracks().forEach((t) => t.stop());
      this.audioStream = null;
    }
    this.vibrate(60);
  }

  public getIsContinuousListening(): boolean {
    return this.isContinuousListening;
  }

  public stopListening() {
    if (this.isContinuousListening) {
      this.stopContinuousListening();
      return;
    }
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (e) {}
      this.isListening = false;
    }
    if (this.audioStream) {
      this.audioStream.getTracks().forEach((t) => t.stop());
      this.audioStream = null;
    }
  }

  public getIsListening(): boolean {
    return this.isListening;
  }

  /**
   * Ovoz chiqarib o'qish (TTS)
   * Doimiy tinglash faol bo'lsa, Jarvis o'z ovozini eshitib qolmasligi uchun
   * gapirish paytida mikrofonni to'xtatadi va gapirib bo'lgach yana yoqadi!
   */
  public speak(text: string, onEnd?: () => void) {
    if (!this.speechSynthesis) {
      if (onEnd) onEnd();
      return;
    }

    try {
      this.isSpeakingNow = true;

      // Agar doimiy tinglash faol bo'lsa, echo bo'lmasligi uchun vaqtincha to'xtatib turamiz
      if (this.recognition) {
        try { this.recognition.abort(); } catch (e) {}
      }

      this.speechSynthesis.cancel();

      const cleanText = text
        .replace(/[*_#`~>]/g, '')
        .replace(/https?:\/\/\S+/g, 'havola')
        .slice(0, 450);

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = this.speechRate;
      utterance.volume = this.speechVolume;
      utterance.pitch = this.speechPitch;

      const voices = this.speechSynthesis.getVoices();
      const uzVoice = voices.find(
        (v) => v.lang.includes('uz') || v.lang.includes('tr') || v.lang.includes('ru')
      );
      if (uzVoice) {
        utterance.voice = uzVoice;
      }

      const handleSpeechDone = () => {
        this.isSpeakingNow = false;
        // Agar doimiy tinglash faol bo'lsa, nutq tugagach avtomatik mikrofonni qayta yoqish
        if (this.isContinuousListening) {
          if (this.restartTimer) clearTimeout(this.restartTimer);
          this.restartTimer = setTimeout(() => {
            if (this.isContinuousListening && !this.isSpeakingNow) {
              this.initContinuousRecognition();
            }
          }, 400);
        }
        onEnd?.();
      };

      utterance.onend = handleSpeechDone;
      utterance.onerror = handleSpeechDone;

      this.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("TTS ijrosida ogohlantirish:", e);
      this.isSpeakingNow = false;
      onEnd?.();
    }
  }

  public stopSpeaking() {
    this.isSpeakingNow = false;
    if (this.speechSynthesis) {
      this.speechSynthesis.cancel();
    }
    if (this.isContinuousListening) {
      if (this.restartTimer) clearTimeout(this.restartTimer);
      this.restartTimer = setTimeout(() => {
        if (this.isContinuousListening && !this.isSpeakingNow) {
          this.initContinuousRecognition();
        }
      }, 300);
    }
  }

  /**
   * Kamerani ochish (Old yoki Orqa)
   */
  public async openCamera(
    videoElement: HTMLVideoElement,
    facing: 'environment' | 'user' = 'environment'
  ): Promise<MediaStream> {
    if (this.cameraStream) {
      this.closeCamera();
    }

    this.currentFacingMode = facing;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facing },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });

      this.cameraStream = stream;
      videoElement.srcObject = stream;
      await videoElement.play();
      this.vibrate(80);
      return stream;
    } catch (err: any) {
      console.error("Kamera xatosi:", err);
      throw new Error("Kameraga ulanish rad etildi. Iltimos ruxsat bering, Sir.");
    }
  }

  public async switchCamera(videoElement: HTMLVideoElement): Promise<'environment' | 'user'> {
    const nextFacing = this.currentFacingMode === 'environment' ? 'user' : 'environment';
    await this.openCamera(videoElement, nextFacing);
    return nextFacing;
  }

  public capturePhoto(videoElement: HTMLVideoElement): string {
    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth || 1280;
    canvas.height = videoElement.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error("Canvas yaratilmadi");
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    this.vibrate([100, 50, 100]); // Suratga olinganda titrash
    return canvas.toDataURL('image/jpeg', 0.95);
  }

  public closeCamera() {
    if (this.cameraStream) {
      this.cameraStream.getTracks().forEach((track) => track.stop());
      this.cameraStream = null;
    }
  }

  /**
   * Chiroq (Torch) boshqaruvi
   */
  public async toggleTorch(targetState?: boolean): Promise<{ success: boolean; isHardware: boolean; newState: boolean }> {
    const desiredState = targetState !== undefined ? targetState : !this.isTorchOn;

    if (desiredState) {
      this.vibrate(100);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        const track = stream.getVideoTracks()[0];
        const capabilities = (track.getCapabilities && (track.getCapabilities() as any)) || {};

        if (capabilities.torch) {
          await (track as any).applyConstraints({
            advanced: [{ torch: true }],
          });
          this.torchTrack = track;
          this.isTorchOn = true;
          this.isScreenTorchActive = false;
          return { success: true, isHardware: true, newState: true };
        } else {
          // Apparatda torch yo'q, ekran chirog'i
          track.stop();
          this.isScreenTorchActive = true;
          this.isTorchOn = true;
          return { success: true, isHardware: false, newState: true };
        }
      } catch (err) {
        // Ruxsat berilmasa yoki qo'llamasa, ekran chirog'i
        this.isScreenTorchActive = true;
        this.isTorchOn = true;
        return { success: true, isHardware: false, newState: true };
      }
    } else {
      this.vibrate(60);
      if (this.torchTrack) {
        try {
          await (this.torchTrack as any).applyConstraints({ advanced: [{ torch: false }] });
          this.torchTrack.stop();
        } catch (e) {}
        this.torchTrack = null;
      }
      this.isScreenTorchActive = false;
      this.isTorchOn = false;
      return { success: true, isHardware: true, newState: false };
    }
  }

  /**
   * GPS Joylashuvni olish
   */
  public async getGeolocation(): Promise<{ latitude: number; longitude: number; accuracy: number; text: string }> {
    return new Promise((resolve, reject) => {
      if (!('geolocation' in navigator)) {
        reject(new Error("Qurilmangizda GPS / Geolocation mavjud emas, Sir."));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          this.vibrate(70);
          resolve({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: Math.round(pos.coords.accuracy),
            text: `Kenglik: ${pos.coords.latitude.toFixed(5)}, Uzunlik: ${pos.coords.longitude.toFixed(5)} (Aniqlik: ${Math.round(pos.coords.accuracy)}m)`,
          });
        },
        (err) => {
          reject(new Error(`Joylashuvni aniqlab bo'lmadi: ${err.message}`));
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    });
  }

  /**
   * Ekranni doimo uyg'oq (o'chmaydigan) saqlash (Screen Wake Lock API)
   */
  public async setWakeLock(active: boolean): Promise<boolean> {
    try {
      if ('wakeLock' in navigator) {
        if (active && !this.wakeLockSentinel) {
          this.wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
          return true;
        } else if (!active && this.wakeLockSentinel) {
          await this.wakeLockSentinel.release();
          this.wakeLockSentinel = null;
          return false;
        }
      }
    } catch (e) {
      console.warn("WakeLock qo'llab-quvvatlanmadi:", e);
    }
    return false;
  }

  /**
   * Telefon qo'ng'irog'i qilish (Dialer)
   */
  public makePhoneCall(phone: string) {
    this.vibrate(100);
    window.location.href = `tel:${phone}`;
  }

  /**
   * SMS yuborish ilovasini ochish
   */
  public sendSMS(phone: string = '', body: string = '') {
    this.vibrate(100);
    window.location.href = `sms:${phone}${body ? `?body=${encodeURIComponent(body)}` : ''}`;
  }

  /**
   * Batareya holati
   */
  public async getBatteryInfo(): Promise<BatteryInfo | null> {
    try {
      if (typeof navigator !== 'undefined' && (navigator as any).getBattery) {
        const battery = await (navigator as any).getBattery();
        return {
          level: Math.round(battery.level * 100),
          charging: battery.charging,
        };
      }
    } catch (e) {}
    return null;
  }

  /**
   * Qurilma texnik ma'lumotlari
   */
  public getHardwareInfo(): DeviceHardwareInfo {
    const nav: any = typeof navigator !== 'undefined' ? navigator : {};
    return {
      ramGB: nav.deviceMemory || undefined,
      cpuCores: nav.hardwareConcurrency || undefined,
      online: typeof navigator !== 'undefined' ? navigator.onLine : true,
      screenResolution: typeof window !== 'undefined' ? `${window.screen.width}x${window.screen.height}` : '1080x2400',
      userAgent: nav.userAgent || '',
      platform: nav.platform || 'Android / Linux',
    };
  }

  /**
   * Ovozli yoki matnli buyruqni tahlil qilish
   */
  public parseDeviceCommand(text: string): { action: DeviceActionType; confirmationText: string; extraData?: any } {
    const t = text.toLowerCase();

    // 1. Kamera
    if (t.includes('kamera') || t.includes('rasmga ol') || t.includes('suratga ol') || t.includes('foto')) {
      return { action: 'open_camera', confirmationText: "Optik kamera datchigi ochildi, Sir. Rasmga olishingiz mumkin." };
    }

    // 2. Chiroq (Torch)
    if (t.includes('chiroqni yoq') || t.includes('fonarni yoq') || t.includes('svyetni yoq') || t.includes('chiroq yoq')) {
      return { action: 'turn_on_torch', confirmationText: "Chiroq yoqildi, Sir." };
    }
    if (t.includes('chiroqni o\'chir') || t.includes('chiroqni ochir') || t.includes('fonarni o\'chir') || t.includes('fonarni ochir')) {
      return { action: 'turn_off_torch', confirmationText: "Chiroq o'chirildi, Sir." };
    }

    // 3. Vibratsiya
    if (t.includes('titra') || t.includes('vibratsiya') || t.includes('tebrat')) {
      return { action: 'vibrate_device', confirmationText: "Qurilma haptik tebranishi sinab ko'rildi, Sir." };
    }

    // 4. GPS / Joylashuv
    if (t.includes('qayerdaman') || t.includes('joylashuv') || t.includes('lokatsiya') || t.includes('gps') || t.includes('koordinata')) {
      return { action: 'get_gps_location', confirmationText: "GPS sun'iy yo'ldoshlari orqali koordinatalaringiz aniqlanmoqda, Sir." };
    }

    // 5. Ekran doimo yoniq
    if (t.includes('ekranni o\'chirma') || t.includes('uyg\'oq tur') || t.includes('ekran yonib tursin')) {
      return { action: 'wake_lock', confirmationText: "Ekran uyg'oq turish rejimi (WakeLock) faollashtirildi, Sir." };
    }

    // 6. Sozlamalar
    if (t.includes('sozlama') || t.includes('nastroyka')) {
      return { action: 'open_settings', confirmationText: "Tizim sozlamalari ochildi, Sir." };
    }

    // 7. Kodlar
    if (t.includes('server kodi') || t.includes('kodlarni') || t.includes('fastapi')) {
      return { action: 'open_code_viewer', confirmationText: "Manba kodlari paneli ochildi, Sir." };
    }

    // 8. ZIP / APK
    if (t.includes('zip yukla') || t.includes('apk yukla') || t.includes('fayllarni yukla')) {
      return { action: 'download_zip', confirmationText: "APK va Backend uchun ZIP to'plami yuklanmoqda, Sir." };
    }

    // 9. Tizim holati
    if (t.includes('tizim holati') || t.includes('batareya') || t.includes('quvvat')) {
      return { action: 'system_status', confirmationText: "Qurilma va protsessor holati tahlil qilindi, Sir." };
    }

    // 10. Doimiy Tinglash Rejimi (Hands-Free / Continuous Listening)
    if (t.includes('doimiy tinglashni to\'xtat') || t.includes('doimiy rejimni o\'chir') || t.includes('doimiy to\'xtat') || t.includes('tinglashni to\'xtat') || t.includes('doimiy rejimdan chiq')) {
      return { 
        action: 'stop_continuous', 
        confirmationText: "Doimiy tinglash rejimi to'xtatildi, Sir. Mikrofon odatiy boshqaruv holatiga o'tkazildi." 
      };
    }
    if (t.includes('doimiy tingla') || t.includes('doimiy rejim') || t.includes('doimiy ovoz') || t.includes('hands free') || t.includes('uzluksiz tingla') || t.includes('uzluksiz eshit')) {
      return { 
        action: 'start_continuous', 
        confirmationText: "Doimiy tinglash rejimi faollashtirildi, Sir! Mikrofon uzluksiz ishlaydi va har bir buyrug'ingizni avtomatik qabul qilaman." 
      };
    }

    // 11. Telefon qilish va Qo'ng'iroq
    if (t.includes('qo\'ng\'iroq') || t.includes('qongiroq') || t.includes('telefon qil')) {
      const match = text.match(/[\d+]{7,15}/);
      const phoneNum = match ? match[0] : '';
      return { 
        action: 'make_call', 
        confirmationText: phoneNum ? `${phoneNum} raqamiga qo'ng'iroq ochilmoqda, Sir.` : "Telefon terish oynasi ochildi, Sir.",
        extraData: phoneNum 
      };
    }

    return { action: 'none', confirmationText: '' };
  }
}

export const deviceService = new DeviceService();
