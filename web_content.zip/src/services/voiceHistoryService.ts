/**
 * Ovozli Buyruqlar Tarixi Servisi (Local Storage History Engine)
 * Foydalanuvchining so'nggi 10 ta ovozli buyrug'ini lokal xotirada saqlaydi.
 */

export interface VoiceCommandItem {
  id: string;
  command: string;
  timestamp: number;
  formattedTime: string;
  actionName?: string;
}

const STORAGE_KEY = 'jarvis_voice_commands_history';
const MAX_HISTORY_ITEMS = 10;

class VoiceHistoryService {
  /**
   * So'nggi 10 ta ovozli buyruqni olish
   */
  public getHistory(): VoiceCommandItem[] {
    if (typeof window === 'undefined') return [];
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.warn("Ovozli buyruqlar tarixini o'qishda xatolik:", e);
    }
    return [];
  }

  /**
   * Yangi ovozli buyruqni saqlash (Maksimal 10 ta saqlanadi)
   */
  public addCommand(command: string, actionName?: string): VoiceCommandItem[] {
    if (!command.trim() || typeof window === 'undefined') return this.getHistory();

    try {
      const currentHistory = this.getHistory();
      const now = new Date();
      const newItem: VoiceCommandItem = {
        id: `cmd-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        command: command.trim(),
        timestamp: Date.now(),
        formattedTime: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        actionName,
      };

      // Boshiga qo'shamiz va faqat so'nggi 10 tasini qoldiramiz
      const updated = [newItem, ...currentHistory.filter((item) => item.command !== newItem.command)].slice(0, MAX_HISTORY_ITEMS);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    } catch (e) {
      console.warn("Ovozli buyruqni saqlashda xatolik:", e);
      return this.getHistory();
    }
  }

  /**
   * Tarixni tozalash
   */
  public clearHistory(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.warn("Tarixni tozalashda xatolik:", e);
    }
  }
}

export const voiceHistoryService = new VoiceHistoryService();
