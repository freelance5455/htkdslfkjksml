// Generates a 100% self-contained standalone index.html file that works independently in any browser!
export function getStandaloneIndexHtml(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SL TIK TOK Video - Developed by Saleem Zakhme</title>
  <meta name="description" content="SL TIK TOK Video: Download TikTok videos without watermark in HD MP4 & MP3 for free. Developed by Saleem Zakhme.">
  <!-- Google AdSense & AdMob Web Integration -->
  <meta name="google-adsense-account" content="ca-pub-9247061906860945">
  <meta name="google-admob-app-id" content="ca-app-pub-9247061906860945~7115667053">
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-app-pub-9247061906860945" crossorigin="anonymous"></script>
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: {
              50: '#ecfeff',
              400: '#22d3ee',
              500: '#06b6d4',
              600: '#0891b2',
              900: '#164e63',
              dark: '#070d1e',
              card: '#0f172a',
              input: '#1e293b'
            }
          }
        }
      }
    }
  </script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: #070d1e;
      color: #f1f5f9;
    }
    .glow-cyan {
      box-shadow: 0 0 25px rgba(6, 182, 212, 0.25);
    }
    .glow-button {
      box-shadow: 0 4px 20px rgba(6, 182, 212, 0.4);
    }
    .custom-scrollbar::-webkit-scrollbar {
      width: 6px;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background: #334155;
      border-radius: 4px;
    }
  </style>
</head>
<body class="min-h-screen flex flex-col selection:bg-cyan-500 selection:text-white">

  <!-- NAVBAR -->
  <header class="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur sticky top-0 z-50">
    <div class="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <a href="#" class="flex items-center gap-2.5 group">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform font-black text-white text-sm">
            SL
          </div>
          <div>
            <span class="text-xl sm:text-2xl font-black tracking-tight text-white">SL TIK TOK <span class="text-cyan-400">Video</span></span>
            <p class="text-[10px] text-cyan-300 font-medium">This app developer Saleem Zakhme</p>
          </div>
        </a>
      </div>

      <nav class="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
        <a href="#features" class="hover:text-cyan-400 transition-colors">Features</a>
        <a href="#faq" class="hover:text-cyan-400 transition-colors">FAQ</a>
        <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">No Watermark</span>
      </nav>
    </div>
  </header>

  <!-- HERO SECTION -->
  <main class="flex-1">
    <section class="relative pt-12 pb-16 px-4 overflow-hidden">
      <!-- Glow background circles -->
      <div class="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-cyan-600/15 rounded-full blur-[120px] pointer-events-none"></div>

      <div class="max-w-4xl mx-auto text-center relative z-10">
        <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs sm:text-sm font-bold mb-6 shadow-xl shadow-cyan-950/60 backdrop-blur-md">
          <span class="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping"></span>
          <span class="text-white">This app developer: <strong class="text-cyan-400 font-extrabold">Saleem Zakhme</strong></span>
        </div>
        
        <h1 class="text-3xl sm:text-5xl md:text-6xl font-black text-white tracking-tight leading-tight mb-4">
          SL Tik Tok Videos <br class="hidden sm:inline" />
          <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">without watermark</span>
        </h1>
        <p class="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto mb-8">
          Download TikTok videos in High Quality HD MP4 & MP3 &bull; Developed by <strong class="text-cyan-400 font-semibold">Saleem Zakhme</strong>
        </p>

        <!-- INPUT BOX - Highlighted & Glowing -->
        <div class="bg-slate-900/95 border-2 border-cyan-400/80 rounded-2xl p-2.5 sm:p-3 shadow-[0_0_35px_rgba(6,182,212,0.35)] ring-4 ring-cyan-500/20 max-w-2xl mx-auto">
          <form id="downloadForm" class="flex flex-col sm:flex-row gap-2.5">
            <div class="relative flex-1 flex items-center">
              <svg class="w-5 h-5 text-cyan-400 absolute left-3.5 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path>
              </svg>
              <input 
                type="text" 
                id="urlInput"
                placeholder="Past link hear" 
                class="w-full bg-slate-800/90 border-2 border-cyan-500/50 hover:border-cyan-400 focus:border-cyan-400 rounded-xl pl-11 pr-24 py-3.5 sm:py-4 text-sm sm:text-base text-white placeholder-slate-300 shadow-inner focus:outline-none focus:ring-2 focus:ring-cyan-400/30 transition"
                required
              />
              <button 
                type="button" 
                id="pasteBtn"
                class="absolute right-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-cyan-400 border border-slate-700 transition flex items-center gap-1.5"
                title="Paste from clipboard"
              >
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                </svg>
                Paste
              </button>
            </div>

            <button 
              type="submit" 
              id="submitBtn"
              class="px-7 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-base flex items-center justify-center gap-2 glow-button transition-all duration-200 active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <span id="btnText">Download</span>
              <svg id="btnSpinner" class="w-5 h-5 animate-spin hidden" viewBox="0 0 24 24" fill="none">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            </button>
          </form>
        </div>

        <!-- Google AdSense Unit 1: 3882999054 -->
        <div class="my-5 max-w-2xl mx-auto text-center">
          <div class="text-[10px] uppercase font-semibold text-slate-500 tracking-wider mb-1">Sponsored Advertisement</div>
          <div class="bg-slate-900/70 border border-slate-800 rounded-2xl p-2 min-h-[90px] flex items-center justify-center">
            <ins class="adsbygoogle"
                 style="display:block;min-height:90px"
                 data-ad-client="ca-app-pub-9247061906860945"
                 data-ad-slot="3882999054"
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>
          </div>
        </div>

        <!-- Error Alert -->
        <div id="errorAlert" class="mt-6 max-w-xl mx-auto p-4 rounded-xl bg-red-950/70 border border-red-500/40 text-red-200 text-sm hidden flex items-center gap-3 text-left">
          <svg class="w-5 h-5 text-red-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
          </svg>
          <span id="errorMessage">An error occurred while fetching video.</span>
        </div>

        <!-- RESULT CARD -->
        <div id="resultCard" class="mt-10 max-w-3xl mx-auto text-left hidden">
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-2xl backdrop-blur">
            <div class="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
              <div class="flex items-center gap-3">
                <img id="authorAvatar" src="" alt="Author" class="w-12 h-12 rounded-full border-2 border-cyan-500 object-cover" />
                <div>
                  <h3 id="authorName" class="font-bold text-white text-base">Creator</h3>
                  <p id="authorUsername" class="text-xs text-cyan-400">@username</p>
                </div>
              </div>
              <button id="resetBtn" class="text-xs px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition">
                Search Another
              </button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
              <!-- Video / Preview -->
              <div class="rounded-xl overflow-hidden bg-black aspect-[9/16] max-h-[420px] mx-auto w-full relative flex items-center justify-center border border-slate-800">
                <video id="videoPlayer" controls class="w-full h-full object-contain" playsinline preload="metadata">
                  Your browser does not support the video tag.
                </video>
              </div>

              <!-- Details & Downloads -->
              <div class="flex flex-col justify-between h-full">
                <div>
                  <h4 class="text-xs uppercase font-bold tracking-wider text-slate-400 mb-2">Video Caption</h4>
                  <p id="videoTitle" class="text-sm text-slate-200 line-clamp-3 mb-4 bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
                    Video description goes here...
                  </p>

                  <!-- Video Statistics -->
                  <div class="grid grid-cols-3 gap-2 mb-6 text-center">
                    <div class="bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/60">
                      <div class="text-xs text-slate-400">Likes</div>
                      <div id="statLikes" class="text-sm font-bold text-white">0</div>
                    </div>
                    <div class="bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/60">
                      <div class="text-xs text-slate-400">Comments</div>
                      <div id="statComments" class="text-sm font-bold text-white">0</div>
                    </div>
                    <div class="bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/60">
                      <div class="text-xs text-slate-400">Shares</div>
                      <div id="statShares" class="text-sm font-bold text-white">0</div>
                    </div>
                  </div>
                </div>

                <!-- Google AdSense Unit 2: 1065264026 -->
                <div class="my-3 text-center">
                  <div class="text-[10px] uppercase font-semibold text-slate-500 tracking-wider mb-1">Advertisement</div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-2 min-h-[90px] flex items-center justify-center">
                    <ins class="adsbygoogle"
                         style="display:block;min-height:90px"
                         data-ad-client="ca-app-pub-9247061906860945"
                         data-ad-slot="1065264026"
                         data-ad-format="auto"
                         data-full-width-responsive="true"></ins>
                  </div>
                </div>

                <!-- Download Action Buttons -->
                <div class="space-y-2.5">
                  <a id="downloadNoWatermarkBtn" href="#" target="_blank" class="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                    </svg>
                    Download Without Watermark (Server 1)
                  </a>

                  <a id="downloadHdBtn" href="#" target="_blank" class="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-cyan-500/30 text-cyan-300 font-semibold text-sm flex items-center justify-center gap-2 transition">
                    <svg class="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                    </svg>
                    Download HD (No Watermark)
                  </a>

                  <a id="downloadMp3Btn" href="#" target="_blank" class="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold text-sm flex items-center justify-center gap-2 transition">
                    <svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/>
                    </svg>
                    Download MP3 (Audio Only)
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>

    <!-- HOW TO DOWNLOAD SECTION -->
    <section id="how-to" class="py-16 px-4 bg-slate-950/50 border-t border-slate-800">
      <div class="max-w-5xl mx-auto">
        <div class="text-center mb-12">
          <h2 class="text-2xl sm:text-3xl font-black text-white">How to Download TikTok Videos Without Watermark</h2>
          <p class="text-slate-400 text-sm mt-2">Follow these 3 simple steps to save any TikTok video to your device</p>
        </div>

        <div class="hidden grid-cols-1 md:grid-cols-3 gap-6">
          <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl relative">
            <div class="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-black text-lg flex items-center justify-center mb-4">1</div>
            <h3 class="font-bold text-white text-base mb-2">Find the TikTok Video</h3>
            <p class="text-slate-400 text-sm">Open the TikTok app or website, find the video you want, tap "Share", and choose "Copy Link".</p>
          </div>

          <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl relative">
            <div class="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-black text-lg flex items-center justify-center mb-4">2</div>
            <h3 class="font-bold text-white text-base mb-2">Paste Link on SSSTik</h3>
            <p class="text-slate-400 text-sm">Paste the copied URL into the input field at the top of this page and click the "Download" button.</p>
          </div>

          <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl relative">
            <div class="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-black text-lg flex items-center justify-center mb-4">3</div>
            <h3 class="font-bold text-white text-base mb-2">Save Without Watermark</h3>
            <p class="text-slate-400 text-sm">Select "Download Without Watermark" or "Download MP3" to save the file directly to your phone or computer.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- FEATURES SECTION -->
    <section id="features" class="py-16 px-4">
      <div class="max-w-5xl mx-auto">
        <div class="text-center mb-12">
          <h2 class="text-2xl sm:text-3xl font-black text-white">Why Use SSSTik?</h2>
          <p class="text-slate-400 text-sm mt-2">The fastest and cleanest online TikTok video downloader</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          <div class="p-5 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div class="text-2xl mb-2">🚫</div>
            <h4 class="font-bold text-white mb-1">No Watermark</h4>
            <p class="text-slate-400 text-xs">Remove the bouncing TikTok logo and username overlay from any video.</p>
          </div>
          <div class="p-5 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div class="text-2xl mb-2">⚡</div>
            <h4 class="font-bold text-white mb-1">Ultra Fast</h4>
            <p class="text-slate-400 text-xs">Lightning quick processing and high-speed direct downloads with zero wait time.</p>
          </div>
          <div class="p-5 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div class="text-2xl mb-2">💎</div>
            <h4 class="font-bold text-white mb-1">High Definition</h4>
            <p class="text-slate-400 text-xs">Download in original crisp Full HD quality without compression artifacts.</p>
          </div>
          <div class="p-5 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div class="text-2xl mb-2">🎵</div>
            <h4 class="font-bold text-white mb-1">Extract MP3 Audio</h4>
            <p class="text-slate-400 text-xs">Convert any TikTok sound or music into an audio MP3 track with 1 click.</p>
          </div>
          <div class="p-5 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div class="text-2xl mb-2">📱</div>
            <h4 class="font-bold text-white mb-1">Works on Any Device</h4>
            <p class="text-slate-400 text-xs">Compatible with iPhone, iPad, Android, Windows, Mac, and Linux browsers.</p>
          </div>
          <div class="p-5 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div class="text-2xl mb-2">🔒</div>
            <h4 class="font-bold text-white mb-1">100% Free & Safe</h4>
            <p class="text-slate-400 text-xs">No registration, no software installation, and no hidden fees ever.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- FAQ SECTION -->
    <section id="faq" class="py-16 px-4 bg-slate-950/50 border-t border-slate-800">
      <div class="max-w-3xl mx-auto">
        <div class="text-center mb-10">
          <h2 class="text-2xl sm:text-3xl font-black text-white">Frequently Asked Questions</h2>
        </div>

        <div class="space-y-3">
          <details class="group bg-slate-900 border border-slate-800 rounded-xl p-4 [&_summary::-webkit-details-marker]:hidden cursor-pointer">
            <summary class="flex justify-between items-center font-semibold text-white text-sm sm:text-base">
              <span>Do I need to pay to download TikTok videos without watermark?</span>
              <span class="transition group-open:rotate-180 text-cyan-400">▼</span>
            </summary>
            <p class="text-slate-400 text-sm mt-3 pt-3 border-t border-slate-800">
              No, SSSTik is completely free to use. You can download as many videos as you want without any restrictions or charges.
            </p>
          </details>

          <details class="group bg-slate-900 border border-slate-800 rounded-xl p-4 [&_summary::-webkit-details-marker]:hidden cursor-pointer">
            <summary class="flex justify-between items-center font-semibold text-white text-sm sm:text-base">
              <span>Where are TikTok videos saved after downloading?</span>
              <span class="transition group-open:rotate-180 text-cyan-400">▼</span>
            </summary>
            <p class="text-slate-400 text-sm mt-3 pt-3 border-t border-slate-800">
              Videos are usually saved in your browser's default "Downloads" folder. On mobile devices, they appear in your Gallery, Files app, or Photos.
            </p>
          </details>

          <details class="group bg-slate-900 border border-slate-800 rounded-xl p-4 [&_summary::-webkit-details-marker]:hidden cursor-pointer">
            <summary class="flex justify-between items-center font-semibold text-white text-sm sm:text-base">
              <span>How do I download videos on iPhone (iOS)?</span>
              <span class="transition group-open:rotate-180 text-cyan-400">▼</span>
            </summary>
            <p class="text-slate-400 text-sm mt-3 pt-3 border-t border-slate-800">
              On iOS 13 and newer, you can download directly via Safari. Just paste the link, tap Download, and tap the download icon in Safari's address bar.
            </p>
          </details>
        </div>
      </div>
    </section>
  </main>

  <!-- FOOTER -->
  <footer class="border-t border-slate-800 bg-slate-950 py-8 px-4 text-center text-xs text-slate-500">
    <div class="max-w-4xl mx-auto space-y-3">
      <p class="font-bold text-white text-sm">SL TIK TOK Video - Free Online TikTok Video Downloader</p>
      <p class="text-cyan-400 font-semibold">This app developer Saleem Zakhme</p>
      <p>Disclaimer: SL TIK TOK Video is not affiliated, associated, authorized, endorsed by, or in any way officially connected with TikTok or ByteDance.</p>
      <p>&copy; 2026 SL TIK TOK Video. Developed by <strong class="text-cyan-400">Saleem Zakhme</strong>. All rights reserved.</p>
    </div>
  </footer>

  <!-- JAVASCRIPT LOGIC -->
  <script>
    const form = document.getElementById('downloadForm');
    const urlInput = document.getElementById('urlInput');
    const pasteBtn = document.getElementById('pasteBtn');
    const submitBtn = document.getElementById('submitBtn');
    const btnText = document.getElementById('btnText');
    const btnSpinner = document.getElementById('btnSpinner');
    const errorAlert = document.getElementById('errorAlert');
    const errorMessage = document.getElementById('errorMessage');
    const resultCard = document.getElementById('resultCard');
    const resetBtn = document.getElementById('resetBtn');

    // Result elements
    const authorAvatar = document.getElementById('authorAvatar');
    const authorName = document.getElementById('authorName');
    const authorUsername = document.getElementById('authorUsername');
    const videoTitle = document.getElementById('videoTitle');
    const videoPlayer = document.getElementById('videoPlayer');
    const statLikes = document.getElementById('statLikes');
    const statComments = document.getElementById('statComments');
    const statShares = document.getElementById('statShares');
    const downloadNoWatermarkBtn = document.getElementById('downloadNoWatermarkBtn');
    const downloadHdBtn = document.getElementById('downloadHdBtn');
    const downloadMp3Btn = document.getElementById('downloadMp3Btn');

    // Clipboard Paste
    pasteBtn.addEventListener('click', async () => {
      try {
        const text = await navigator.clipboard.readText();
        if (text && text.trim().length > 0) {
          urlInput.value = text.trim();
          urlInput.focus();
          errorAlert.classList.add('hidden');
        } else {
          errorMessage.textContent = 'link not copy for this app Please Again Copy link And then past hear';
          errorAlert.classList.remove('hidden');
        }
      } catch (err) {
        errorMessage.textContent = 'link not copy for this app Please Again Copy link And then past hear';
        errorAlert.classList.remove('hidden');
      }
    });

    // Reset button
    resetBtn.addEventListener('click', () => {
      resultCard.classList.add('hidden');
      urlInput.value = '';
      urlInput.focus();
    });

    // Form Submit
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const rawUrl = urlInput.value.trim();
      if (!rawUrl) return;

      // Reset states
      errorAlert.classList.add('hidden');
      resultCard.classList.add('hidden');
      submitBtn.disabled = true;
      btnText.textContent = 'Processing...';
      btnSpinner.classList.remove('hidden');

      try {
        // Call TikWM API
        const formData = new URLSearchParams();
        formData.append('url', rawUrl);
        formData.append('hd', '1');

        let res = await fetch('https://www.tikwm.com/api/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json'
          },
          body: formData
        });

        if (!res.ok) {
          // Fallback GET
          res = await fetch('https://www.tikwm.com/api/?url=' + encodeURIComponent(rawUrl) + '&hd=1');
        }

        const data = await res.json();

        if (data.code !== 0 || !data.data) {
          throw new Error(data.msg || 'Unable to download this video. Please check the link and try again.');
        }

        const v = data.data;

        // Populate card
        authorAvatar.src = v.author?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100';
        authorName.textContent = v.author?.nickname || 'TikTok User';
        authorUsername.textContent = '@' + (v.author?.unique_id || 'user');
        videoTitle.textContent = v.title || '(No caption provided)';
        
        statLikes.textContent = formatNum(v.digg_count);
        statComments.textContent = formatNum(v.comment_count);
        statShares.textContent = formatNum(v.share_count);

        const playUrl = v.play || v.hdplay || '';
        videoPlayer.src = playUrl;

        // Set download URLs
        downloadNoWatermarkBtn.href = v.play || '#';
        downloadNoWatermarkBtn.download = 'tiktok_' + (v.author?.unique_id || 'video') + '_nowatermark.mp4';

        if (v.hdplay) {
          downloadHdBtn.href = v.hdplay;
          downloadHdBtn.classList.remove('hidden');
        } else {
          downloadHdBtn.classList.add('hidden');
        }

        if (v.music) {
          downloadMp3Btn.href = v.music;
          downloadMp3Btn.classList.remove('hidden');
        } else {
          downloadMp3Btn.classList.add('hidden');
        }

        resultCard.classList.remove('hidden');
        resultCard.scrollIntoView({ behavior: 'smooth' });

      } catch (err) {
        errorMessage.textContent = err.message || 'Failed to fetch video. Please ensure the TikTok link is public and active.';
        errorAlert.classList.remove('hidden');
      } finally {
        submitBtn.disabled = false;
        btnText.textContent = 'Download';
        btnSpinner.classList.add('hidden');
      }
    });

    function formatNum(n) {
      if (!n) return '0';
      if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
      if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
      return n.toString();
    }
  </script>
</body>
</html>`;
}
