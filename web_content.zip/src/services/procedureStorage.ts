import { WorkProcedureReport } from '../types/procedure';
import { INITIAL_PROCEDURES } from '../data/procedureData';

const DB_NAME = 'SfillerCoatingDB';
const DB_VERSION = 3; // increment version to add store
const PROCEDURE_STORE = 'procedure_reports';
const PROCEDURE_STORAGE_KEY = 'operareport_procedures_v1';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const req = window.indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('painting_reports')) {
        db.createObjectStore('painting_reports', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('maintenance_reports')) {
        db.createObjectStore('maintenance_reports', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(PROCEDURE_STORE)) {
        db.createObjectStore(PROCEDURE_STORE, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function loadProcedures(): Promise<WorkProcedureReport[]> {
  try {
    const db = await openDB();
    const list = await new Promise<WorkProcedureReport[]>((resolve, reject) => {
      const tx = db.transaction(PROCEDURE_STORE, 'readonly');
      const store = tx.objectStore(PROCEDURE_STORE);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    if (list && list.length > 0) return list;
  } catch (e) {
    console.warn('IDB fallback to localStorage for procedures:', e);
  }

  try {
    const raw = localStorage.getItem(PROCEDURE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    // Ignore
  }

  // Seed default
  await saveProcedures(INITIAL_PROCEDURES);
  return INITIAL_PROCEDURES;
}

export async function saveProcedures(procedures: WorkProcedureReport[]): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(PROCEDURE_STORE, 'readwrite');
      const store = tx.objectStore(PROCEDURE_STORE);
      store.clear();
      procedures.forEach((item) => store.put(item));
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.error('Errore salvataggio IDB procedures:', e);
  }

  try {
    localStorage.setItem(PROCEDURE_STORAGE_KEY, JSON.stringify(procedures));
  } catch (e) {
    // quota exceeded with photos, IDB stores it safely
  }
}

/**
 * Esporta la procedura in Excel con tutte le fasi numerate
 */
export function exportProcedureToExcel(proc: WorkProcedureReport): void {
  const sanitize = (str: any) =>
    String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

  const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <style>
        body { font-family: Arial, sans-serif; font-size: 11pt; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
        th, td { border: 1px solid #000000; padding: 6px 8px; vertical-align: top; }
        .header-box { background-color: #1a1a1a; color: #ffffff; font-weight: bold; font-size: 13pt; }
        .step-num { font-weight: bold; font-size: 14pt; background-color: #f2f2f2; text-align: center; width: 50px; }
        .section-title { background-color: #e6e6e6; font-weight: bold; font-size: 11pt; text-transform: uppercase; }
      </style>
    </head>
    <body>
      <table>
        <tr>
          <td colspan="4" class="header-box">
            SFILLER SABBIATURA &amp; VERNICIATURA - PROCEDURA OPERATIVA / SPECIFICA DI LAVORO
            <br/><span style="font-size: 10pt; font-weight: normal; color: #ccc;">Documento di Controllo Cantiere &amp; Istruzioni Step-by-Step</span>
          </td>
        </tr>
        <tr>
          <td style="font-weight: bold; width: 15%;">Codice Procedura:</td>
          <td style="width: 35%;"><strong>${sanitize(proc.code)} (${sanitize(proc.revision)})</strong></td>
          <td style="font-weight: bold; width: 15%;">Data &amp; Redattore:</td>
          <td style="width: 35%;">${sanitize(proc.date)} - ${sanitize(proc.author)}</td>
        </tr>
        <tr>
          <td style="font-weight: bold;">Titolo Specifica:</td>
          <td colspan="3"><strong>${sanitize(proc.title)}</strong></td>
        </tr>
        <tr>
          <td style="font-weight: bold;">Reparto / Settore:</td>
          <td>${sanitize(proc.department)}</td>
          <td style="font-weight: bold;">Stato Documento:</td>
          <td><strong>${sanitize(proc.status.toUpperCase())}</strong></td>
        </tr>
        <tr>
          <td style="font-weight: bold;">Campo di Applicazione:</td>
          <td colspan="3">${sanitize(proc.scope)}</td>
        </tr>
        <tr>
          <td style="font-weight: bold;">Attrezzature &amp; DPI:</td>
          <td colspan="3">${sanitize(proc.equipmentAndPpe)}</td>
        </tr>
      </table>

      <table>
        <thead>
          <tr class="section-title">
            <th style="width: 8%;">Step N.</th>
            <th style="width: 25%;">Titolo Fase di Lavoro</th>
            <th style="width: 47%;">Descrizione Procedura &amp; Istruzioni Operative</th>
            <th style="width: 20%;">Didascalia Fotografia &amp; Tag</th>
          </tr>
        </thead>
        <tbody>
          ${proc.steps
            .map(
              (s) => `
            <tr>
              <td class="step-num">#${s.stepNumber}</td>
              <td><strong>${sanitize(s.title)}</strong>${s.safetyNotice ? `<br/><span style="color: #c00000; font-size: 9pt;"><strong>Avvertenza:</strong> ${sanitize(s.safetyNotice)}</span>` : ''}</td>
              <td style="white-space: pre-wrap;">${sanitize(s.instruction)}</td>
              <td>${s.photoCaption ? `<em>${sanitize(s.photoCaption)}</em>` : '-'}${s.photoTag ? `<br/><span style="font-size: 8pt; color: #555;">[${sanitize(s.photoTag)}]</span>` : ''}</td>
            </tr>
          `
            )
            .join('')}
        </tbody>
      </table>
    </body>
    </html>
  `;

  const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `Procedura_${proc.code.replace(/[^a-zA-Z0-9_-]/g, '_')}.xls`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
