import { supabase } from '../lib/supabase';
import { CallHistoryItem, CallStatus, CallType } from '../types';

export async function logCall(params: {
  callerId: string;
  receiverId: string;
  callType: CallType;
  status: CallStatus;
  startedAt?: Date;
  endedAt?: Date;
  durationSeconds?: number;
}): Promise<string> {
  const { data: { session } } = await supabase.auth.getSession();

  // Try backend endpoint first
  if (session?.access_token) {
    try {
      const res = await fetch('/api/calls/log', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          receiverId: params.receiverId,
          callType: params.callType,
          status: params.status,
          startedAt: (params.startedAt || new Date()).toISOString(),
          durationSeconds: params.durationSeconds || 0,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.id) return data.id;
      }
    } catch {}
  }

  // Database fallback
  const { data, error } = await supabase
    .from('call_history')
    .insert({
      caller_id: params.callerId,
      receiver_id: params.receiverId,
      call_type: params.callType,
      status: params.status,
      started_at: (params.startedAt || new Date()).toISOString(),
      ended_at: params.endedAt ? params.endedAt.toISOString() : null,
      duration_seconds: params.durationSeconds || 0,
    })
    .select('id')
    .single();

  if (error) {
    console.warn('DB logCall failed:', error);
    return `local_${Date.now()}`;
  }
  return data.id;
}

export async function updateCallRecord(
  callId: string,
  updates: {
    status?: CallStatus;
    endedAt?: Date;
    durationSeconds?: number;
  }
): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();

  // Try backend endpoint first
  if (session?.access_token) {
    try {
      await fetch(`/api/calls/${callId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          status: updates.status,
          endedAt: updates.endedAt ? updates.endedAt.toISOString() : new Date().toISOString(),
          durationSeconds: updates.durationSeconds,
        }),
      });
      return;
    } catch {}
  }

  const payload: any = {};
  if (updates.status) payload.status = updates.status;
  if (updates.endedAt) payload.ended_at = updates.endedAt.toISOString();
  if (typeof updates.durationSeconds === 'number') payload.duration_seconds = updates.durationSeconds;

  await supabase.from('call_history').update(payload).eq('id', callId);
}

export async function getCallHistory(currentUserId: string): Promise<CallHistoryItem[]> {
  const { data: { session } } = await supabase.auth.getSession();

  // Try backend endpoint first
  if (session?.access_token) {
    try {
      const res = await fetch('/api/calls/history', {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          return data;
        }
      }
    } catch {}
  }

  // Database query fallback
  const { data: rawCalls, error } = await supabase
    .from('call_history')
    .select('*, caller:profiles!caller_id(*), receiver:profiles!receiver_id(*)')
    .or(`caller_id.eq.${currentUserId},receiver_id.eq.${currentUserId}`)
    .order('created_at', { ascending: false });

  if (error || !rawCalls) return [];

  // Filter out deleted-for-me
  const callIds = rawCalls.map((c) => c.id);
  const deletedSet = new Set<string>();

  try {
    const { data: deletions } = await supabase
      .from('call_history_deletions_for_me')
      .select('call_id')
      .eq('user_id', currentUserId)
      .in('call_id', callIds);
    (deletions || []).forEach((d) => deletedSet.add(d.call_id));
  } catch {}

  try {
    const localDeleted = JSON.parse(localStorage.getItem(`nexa_deleted_calls_${currentUserId}`) || '[]');
    (localDeleted || []).forEach((id: string) => deletedSet.add(id));
  } catch {}

  return rawCalls.filter((c) => !deletedSet.has(c.id)) as CallHistoryItem[];
}

export async function deleteCallRecordForMe(callId: string, currentUserId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();

  if (session?.access_token) {
    try {
      await fetch(`/api/calls/${callId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });
      return;
    } catch {}
  }

  const key = `nexa_deleted_calls_${currentUserId}`;
  try {
    const existing = JSON.parse(localStorage.getItem(key) || '[]');
    if (!existing.includes(callId)) {
      existing.push(callId);
      localStorage.setItem(key, JSON.stringify(existing));
    }
  } catch {}
}

export async function deleteMultipleCallsForMe(callIds: string[], currentUserId: string): Promise<void> {
  for (const id of callIds) {
    await deleteCallRecordForMe(id, currentUserId);
  }
}

export async function clearAllCallHistoryForMe(currentUserId: string): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();

  if (session?.access_token) {
    try {
      await fetch('/api/calls/all', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
        },
      });
      return;
    } catch {}
  }

  const key = `nexa_deleted_calls_${currentUserId}`;
  try {
    const calls = await getCallHistory(currentUserId);
    const existing = JSON.parse(localStorage.getItem(key) || '[]');
    calls.forEach((c) => {
      if (!existing.includes(c.id)) existing.push(c.id);
    });
    localStorage.setItem(key, JSON.stringify(existing));
  } catch {}
}
