export interface OHLCVCandle {
  time: number; // Unix timestamp (ms)
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface VolumeProfileNode {
  priceLevel: number;
  volume: number;
  buyVolume: number;
  sellVolume: number;
  isPOC: boolean;
}

export interface KellySizingResult {
  recommendedLeverage: number; // 2x - 5x
  positionPctOfBalance: number; // e.g., 6.5%
  marginSizeUsdt: number; // e.g., $650 USDT
  notionalSizeUsdt: number; // e.g., $1950 USDT
  kellyFractionRaw: number;
  riskRewardRatio: number;
  maxLossUsdt: number;
  expectedProfitUsdt: number;
  sizingExplanationHe: string;
}

export interface CoinTechnicalAnalysis {
  symbol: string;
  baseAsset: string;
  currentPrice: number;
  change24hPct: number;
  high24h: number;
  low24h: number;
  volume24hUsdt: number;
  rsi14: number;
  macd: {
    macdLine: number;
    signalLine: number;
    histogram: number;
    isBullishCross: boolean;
    isBearishCross: boolean;
  };
  ema: {
    ema20: number;
    ema50: number;
    ema200: number;
    trendAlignmentHe: string;
  };
  atr14: number;
  atrPct: number;
  adx14: number;
  volumeProfile: {
    pocPrice: number;
    valueAreaHigh: number;
    valueAreaLow: number;
    volumeSpikeRatio: number;
    nodes: VolumeProfileNode[];
  };
  recommendation: "LONG" | "SHORT" | "WAIT";
  recommendationLabelHe: "LONG / לונג" | "SHORT / שורט" | "WAIT / להמתין";
  confluenceScore: number; // 0 - 100
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  kellySizing: KellySizingResult;
  reasonsHe: string[];
  evaluatorWarningHe: string | null;
  lastUpdatedTs: number;
}

/**
 * Compute Exponential Moving Average (EMA) over an array of closing prices.
 */
export function calculateEMA(closes: number[], period: number): number[] {
  if (!Array.isArray(closes) || closes.length === 0) return [];
  const k = 2 / (period + 1);
  const emaArray: number[] = new Array(closes.length);
  let sum = 0;
  const initLen = Math.min(period, closes.length);
  for (let i = 0; i < initLen; i++) {
    sum += closes[i];
  }
  let prevEma = sum / initLen;
  for (let i = 0; i < closes.length; i++) {
    if (i < initLen - 1) {
      emaArray[i] = closes[i];
    } else if (i === initLen - 1) {
      emaArray[i] = prevEma;
    } else {
      prevEma = closes[i] * k + prevEma * (1 - k);
      emaArray[i] = prevEma;
    }
  }
  return emaArray;
}

/**
 * Compute Wilder's Relative Strength Index (RSI-14).
 */
export function calculateRSI(closes: number[], period = 14): number {
  if (!Array.isArray(closes) || closes.length <= period) return 50;
  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    const currentGain = diff > 0 ? diff : 0;
    const currentLoss = diff < 0 ? -diff : 0;
    avgGain = (avgGain * (period - 1) + currentGain) / period;
    avgLoss = (avgLoss * (period - 1) + currentLoss) / period;
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  const rsi = 100 - 100 / (1 + rs);
  return Number(Math.max(1, Math.min(99, rsi)).toFixed(2));
}

/**
 * Compute MACD (12, 26, 9) with MACD Line, Signal Line, and Histogram.
 */
export function calculateMACD(
  closes: number[],
  fastPeriod = 12,
  slowPeriod = 26,
  signalPeriod = 9
) {
  if (!Array.isArray(closes) || closes.length < slowPeriod + signalPeriod) {
    return {
      macdLine: 0,
      signalLine: 0,
      histogram: 0,
      isBullishCross: false,
      isBearishCross: false,
    };
  }

  const emaFast = calculateEMA(closes, fastPeriod);
  const emaSlow = calculateEMA(closes, slowPeriod);
  const macdSeries = closes.map((_, idx) => emaFast[idx] - emaSlow[idx]);
  const signalSeries = calculateEMA(macdSeries, signalPeriod);

  const lastIdx = closes.length - 1;
  const prevIdx = Math.max(0, lastIdx - 1);

  const macdLine = macdSeries[lastIdx];
  const signalLine = signalSeries[lastIdx];
  const histogram = macdLine - signalLine;

  const prevHist = macdSeries[prevIdx] - signalSeries[prevIdx];
  const isBullishCross = histogram > 0 && prevHist <= 0;
  const isBearishCross = histogram < 0 && prevHist >= 0;

  return {
    macdLine: Number(macdLine.toPrecision(4)),
    signalLine: Number(signalLine.toPrecision(4)),
    histogram: Number(histogram.toPrecision(4)),
    isBullishCross,
    isBearishCross,
  };
}

/**
 * Compute Average True Range (ATR-14).
 */
export function calculateATR(candles: OHLCVCandle[], period = 14): number {
  if (!Array.isArray(candles) || candles.length < 2) return 0;
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const h = candles[i].high;
    const l = candles[i].low;
    const prevC = candles[i - 1].close;
    const tr = Math.max(h - l, Math.abs(h - prevC), Math.abs(l - prevC));
    trs.push(tr);
  }
  if (trs.length === 0) return 0;
  const initLen = Math.min(period, trs.length);
  let atr = trs.slice(0, initLen).reduce((a, b) => a + b, 0) / initLen;
  for (let i = initLen; i < trs.length; i++) {
    atr = (atr * (period - 1) + trs[i]) / period;
  }
  return atr;
}

/**
 * Compute Average Directional Index (ADX-14) to measure trend strength vs choppiness.
 */
export function calculateADX(candles: OHLCVCandle[], period = 14): number {
  if (!Array.isArray(candles) || candles.length <= period * 2) return 24;
  const trList: number[] = [];
  const plusDMList: number[] = [];
  const minusDMList: number[] = [];

  for (let i = 1; i < candles.length; i++) {
    const upMove = candles[i].high - candles[i - 1].high;
    const downMove = candles[i - 1].low - candles[i].low;
    const plusDM = upMove > downMove && upMove > 0 ? upMove : 0;
    const minusDM = downMove > upMove && downMove > 0 ? downMove : 0;
    const tr = Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i - 1].close),
      Math.abs(candles[i].low - candles[i - 1].close)
    );
    trList.push(tr);
    plusDMList.push(plusDM);
    minusDMList.push(minusDM);
  }

  let smoothTR = trList.slice(0, period).reduce((a, b) => a + b, 0);
  let smoothPlusDM = plusDMList.slice(0, period).reduce((a, b) => a + b, 0);
  let smoothMinusDM = minusDMList.slice(0, period).reduce((a, b) => a + b, 0);

  const dxValues: number[] = [];
  for (let i = period; i < trList.length; i++) {
    smoothTR = smoothTR - smoothTR / period + trList[i];
    smoothPlusDM = smoothPlusDM - smoothPlusDM / period + plusDMList[i];
    smoothMinusDM = smoothMinusDM - smoothMinusDM / period + minusDMList[i];

    const plusDI = smoothTR > 0 ? (smoothPlusDM / smoothTR) * 100 : 0;
    const minusDI = smoothTR > 0 ? (smoothMinusDM / smoothTR) * 100 : 0;
    const diSum = plusDI + minusDI;
    const dx = diSum > 0 ? (Math.abs(plusDI - minusDI) / diSum) * 100 : 0;
    dxValues.push(dx);
  }

  if (dxValues.length === 0) return 22;
  const adx =
    dxValues.slice(-period).reduce((a, b) => a + b, 0) /
    Math.min(period, dxValues.length);
  return Number(Math.max(8, Math.min(68, adx)).toFixed(1));
}

/**
 * Compute Volume Profile across the 200 candles (POC, Value Area High, Value Area Low, Volume Spike).
 */
export function calculateVolumeProfile(candles: OHLCVCandle[], buckets = 16) {
  if (!Array.isArray(candles) || candles.length === 0) {
    return {
      pocPrice: 0,
      valueAreaHigh: 0,
      valueAreaLow: 0,
      volumeSpikeRatio: 1,
      nodes: [] as VolumeProfileNode[],
    };
  }

  let minLow = Infinity;
  let maxHigh = -Infinity;
  let totalVolume = 0;

  for (const c of candles) {
    if (c.low < minLow) minLow = c.low;
    if (c.high > maxHigh) maxHigh = c.high;
    totalVolume += c.volume;
  }

  const range = Math.max(maxHigh - minLow, minLow * 0.005);
  const step = range / buckets;

  const nodes: VolumeProfileNode[] = Array.from({ length: buckets }, (_, idx) => ({
    priceLevel: minLow + step * (idx + 0.5),
    volume: 0,
    buyVolume: 0,
    sellVolume: 0,
    isPOC: false,
  }));

  for (const c of candles) {
    const typicalPrice = (c.high + c.low + c.close) / 3;
    const idx = Math.min(
      buckets - 1,
      Math.max(0, Math.floor((typicalPrice - minLow) / step))
    );
    const isBull = c.close >= c.open;
    nodes[idx].volume += c.volume;
    if (isBull) nodes[idx].buyVolume += c.volume;
    else nodes[idx].sellVolume += c.volume;
  }

  let maxVolIdx = 0;
  for (let i = 1; i < nodes.length; i++) {
    if (nodes[i].volume > nodes[maxVolIdx].volume) {
      maxVolIdx = i;
    }
  }
  nodes[maxVolIdx].isPOC = true;

  const pocPrice = nodes[maxVolIdx].priceLevel;
  const valueAreaLow = nodes[Math.max(0, maxVolIdx - 3)].priceLevel;
  const valueAreaHigh = nodes[Math.min(buckets - 1, maxVolIdx + 3)].priceLevel;

  // Calculate recent volume spike ratio (last 3 candles vs 30-candle mean)
  const recentSlice = candles.slice(-3);
  const avgRecentVol =
    recentSlice.reduce((s, c) => s + c.volume, 0) / Math.max(1, recentSlice.length);
  const baseSlice = candles.slice(-35, -3);
  const avgBaseVol =
    baseSlice.length > 0
      ? baseSlice.reduce((s, c) => s + c.volume, 0) / baseSlice.length
      : totalVolume / candles.length;

  const volumeSpikeRatio =
    avgBaseVol > 0 ? Number((avgRecentVol / avgBaseVol).toFixed(2)) : 1.0;

  return {
    pocPrice,
    valueAreaHigh,
    valueAreaLow,
    volumeSpikeRatio,
    nodes,
  };
}

/**
 * Compute Kelly Criterion Position Sizing & Recommended Leverage (2x - 5x).
 */
export function calculateKellyPositionSizing(
  confluenceScore: number,
  rewardRiskRatio: number,
  atrPct: number,
  accountBalanceUsdt = 10000,
  strictMode = false
): KellySizingResult {
  const winProb = Math.min(0.84, Math.max(0.45, confluenceScore / 100));
  const lossProb = 1 - winProb;
  const b = Math.max(1.2, rewardRiskRatio);

  // Full Kelly = (b * p - q) / b; we apply Fractional Half-Kelly (0.35x) for institutional crypto risk control
  const rawKelly = Math.max(0.03, (b * winProb - lossProb) / b);
  const fractionalKelly = rawKelly * (strictMode ? 0.28 : 0.36);

  // Volatility adjustment based on ATR%
  let recommendedLeverage = 3;
  if (atrPct < 1.3 && confluenceScore >= 82) {
    recommendedLeverage = 5;
  } else if (atrPct < 2.2 && confluenceScore >= 75) {
    recommendedLeverage = 4;
  } else if (atrPct > 3.5 || strictMode) {
    recommendedLeverage = 2;
  } else {
    recommendedLeverage = 3;
  }

  const positionPctOfBalance = Number(
    Math.min(14.5, Math.max(3.0, fractionalKelly * 100)).toFixed(1)
  );
  const marginSizeUsdt = Number(
    ((accountBalanceUsdt * positionPctOfBalance) / 100).toFixed(2)
  );
  const notionalSizeUsdt = Number((marginSizeUsdt * recommendedLeverage).toFixed(2));
  const maxLossUsdt = Number(
    (notionalSizeUsdt * Math.max(0.008, (atrPct * 1.5) / 100)).toFixed(2)
  );
  const expectedProfitUsdt = Number((maxLossUsdt * rewardRiskRatio).toFixed(2));

  const sizingExplanationHe = `נוסחת קלי שמרנית (${positionPctOfBalance}% מהתיק = $${marginSizeUsdt} בטחונות) במינוף ${recommendedLeverage}x מותאם לתנודתיות ATR של ${atrPct.toFixed(2)}% ויחס סיכוי/סיכון 1:${rewardRiskRatio.toFixed(1)}.`;

  return {
    recommendedLeverage,
    positionPctOfBalance,
    marginSizeUsdt,
    notionalSizeUsdt,
    kellyFractionRaw: Number(rawKelly.toFixed(3)),
    riskRewardRatio: Number(rewardRiskRatio.toFixed(2)),
    maxLossUsdt,
    expectedProfitUsdt,
    sizingExplanationHe,
  };
}

/**
 * Full Dynamic Coin Technical Analysis from 200 OHLCV candles.
 */
export function analyzeCoinCandles(
  symbol: string,
  candles: OHLCVCandle[],
  accountBalanceUsdt = 10000,
  strictMode = false,
  minConfluenceThreshold = 74
): CoinTechnicalAnalysis {
  const safeCandles = Array.isArray(candles) && candles.length > 0 ? candles : [];
  const baseAsset = symbol.replace("USDT", "");

  if (safeCandles.length === 0) {
    return {
      symbol,
      baseAsset,
      currentPrice: 0,
      change24hPct: 0,
      high24h: 0,
      low24h: 0,
      volume24hUsdt: 0,
      rsi14: 50,
      macd: {
        macdLine: 0,
        signalLine: 0,
        histogram: 0,
        isBullishCross: false,
        isBearishCross: false,
      },
      ema: {
        ema20: 0,
        ema50: 0,
        ema200: 0,
        trendAlignmentHe: "ממתין לנתונים",
      },
      atr14: 0,
      atrPct: 0,
      adx14: 20,
      volumeProfile: {
        pocPrice: 0,
        valueAreaHigh: 0,
        valueAreaLow: 0,
        volumeSpikeRatio: 1,
        nodes: [],
      },
      recommendation: "WAIT",
      recommendationLabelHe: "WAIT / להמתין",
      confluenceScore: 50,
      entryPrice: 0,
      stopLoss: 0,
      takeProfit1: 0,
      takeProfit2: 0,
      kellySizing: calculateKellyPositionSizing(55, 2.0, 1.5, accountBalanceUsdt, strictMode),
      reasonsHe: ["טוען היסטוריית נרות מהבורסה..."],
      evaluatorWarningHe: null,
      lastUpdatedTs: Date.now(),
    };
  }

  const closes = safeCandles.map((c) => c.close);
  const currentPrice = closes[closes.length - 1];
  const open24hIdx = Math.max(0, safeCandles.length - 48);
  const open24hPrice = safeCandles[open24hIdx]?.open || currentPrice;
  const change24hPct =
    open24hPrice > 0
      ? Number((((currentPrice - open24hPrice) / open24hPrice) * 100).toFixed(2))
      : 0;

  const recent48 = safeCandles.slice(-48);
  const high24h = Math.max(...recent48.map((c) => c.high));
  const low24h = Math.min(...recent48.map((c) => c.low));
  const volume24hUsdt = recent48.reduce((acc, c) => acc + c.volume * c.close, 0);

  const rsi14 = calculateRSI(closes, 14);
  const macd = calculateMACD(closes, 12, 26, 9);
  const ema20Arr = calculateEMA(closes, 20);
  const ema50Arr = calculateEMA(closes, 50);
  const ema200Arr = calculateEMA(closes, 200);

  const ema20 = ema20Arr[ema20Arr.length - 1] || currentPrice;
  const ema50 = ema50Arr[ema50Arr.length - 1] || currentPrice;
  const ema200 = ema200Arr[ema200Arr.length - 1] || currentPrice;

  const atr14 = calculateATR(safeCandles, 14) || currentPrice * 0.014;
  const atrPct = currentPrice > 0 ? Number(((atr14 / currentPrice) * 100).toFixed(2)) : 1.4;
  const adx14 = calculateADX(safeCandles, 14);
  const volumeProfile = calculateVolumeProfile(safeCandles, 16);

  // Determine Bullish vs Bearish Confluence Score & Reasons
  let bullPoints = 0;
  let bearPoints = 0;
  const reasonsHe: string[] = [];

  // 1. EMA Ribbon Structure
  if (currentPrice > ema20 && ema20 > ema50 && ema50 >= ema200 * 0.995) {
    bullPoints += 28;
    reasonsHe.push(`מבנה ממוצעים שורי מלא: מחיר מעל EMA20, EMA50 ו-EMA200.`);
  } else if (currentPrice < ema20 && ema20 < ema50 && ema50 <= ema200 * 1.005) {
    bearPoints += 28;
    reasonsHe.push(`מבנה ממוצעים דובי מובהק: מחיר נסחר מתחת ל-EMA20, EMA50 ו-EMA200.`);
  } else if (currentPrice > ema50) {
    bullPoints += 16;
    reasonsHe.push(`המחיר נתמך מעל ממוצע נע EMA50 המוסדי.`);
  } else {
    bearPoints += 16;
    reasonsHe.push(`המחיר בלחץ מוכרים מתחת לממוצע נע EMA50.`);
  }

  // 2. MACD Momentum
  if (macd.histogram > 0 && macd.macdLine > macd.signalLine) {
    bullPoints += 22;
    reasonsHe.push(
      macd.isBullishCross
        ? `חציית MACD שורית טרייה עם התרחבות היסטוגרמה חיובית.`
        : `מומנטום MACD חיובי (${macd.histogram > 0 ? "+" : ""}${macd.histogram}).`
    );
  } else if (macd.histogram < 0 && macd.macdLine < macd.signalLine) {
    bearPoints += 22;
    reasonsHe.push(
      macd.isBearishCross
        ? `חציית MACD דובית חדשה המאותתת על יציאת כספים.`
        : `מומנטום MACD שלילי מתמשך מתחת לקו האיתות.`
    );
  }

  // 3. RSI-14 Regime
  if (rsi14 >= 52 && rsi14 <= 69) {
    bullPoints += 20;
    reasonsHe.push(`מדד RSI(14) ברמה ${rsi14} – אזור עוצמה שורי ללא קניית-יתר קיצונית.`);
  } else if (rsi14 < 34) {
    bullPoints += 24;
    reasonsHe.push(`מדד RSI(14) במצב מכירת-יתר (${rsi14}) – פוטנציאל היפוך לונג חד.`);
  } else if (rsi14 <= 48 && rsi14 >= 34) {
    bearPoints += 20;
    reasonsHe.push(`מדד RSI(14) ברמה ${rsi14} – חולשת קונים ושליטת מוכרים.`);
  } else if (rsi14 > 71) {
    bearPoints += 24;
    reasonsHe.push(`מדד RSI(14) בקניית-יתר (${rsi14}) – סכנת מימוש רווחים ופתיחת שורט.`);
  }

  // 4. Volume Profile POC & Volume Spike
  if (currentPrice >= volumeProfile.pocPrice) {
    bullPoints += 16;
    reasonsHe.push(
      `המחיר נסחר מעל נקודת השליטה בנפח (POC: $${formatPriceNumber(volumeProfile.pocPrice)}) עם יחס נפח ${volumeProfile.volumeSpikeRatio}x.`
    );
  } else {
    bearPoints += 16;
    reasonsHe.push(
      `המחיר נבלם מתחת לאזור הערך המרכזי (POC: $${formatPriceNumber(volumeProfile.pocPrice)}).`
    );
  }

  // 5. ADX Trend Filter
  if (adx14 >= 22) {
    if (bullPoints >= bearPoints) bullPoints += 14;
    else bearPoints += 14;
    reasonsHe.push(`עוצמת מגמה מאומתת: ADX(14) ברמה ${adx14} (מעל סף דשדוש 20).`);
  }

  let evaluatorWarningHe: string | null = null;
  if (adx14 < 20) {
    evaluatorWarningHe = `אזהרת סוכן מבקר (Evaluator): שוק מדשדש (ADX=${adx14} < 20) – סיכון מוגבר לפריצת שווא.`;
  } else if (volumeProfile.volumeSpikeRatio < 0.75) {
    evaluatorWarningHe = `אזהרת סוכן מבקר (Evaluator): נפח מסחר נמוך מהממוצע (${volumeProfile.volumeSpikeRatio}x) – נדרש אימות נזילות.`;
  }

  const dominantPoints = Math.max(bullPoints, bearPoints);
  const rawDiff = Math.abs(bullPoints - bearPoints);
  let confluenceScore = Math.min(
    96,
    Math.max(48, Math.round(dominantPoints * 0.85 + rawDiff * 0.22))
  );

  if (adx14 < 19) {
    confluenceScore = Math.max(52, confluenceScore - 10);
  }

  const effectiveThreshold = strictMode ? Math.max(79, minConfluenceThreshold) : minConfluenceThreshold;

  let recommendation: "LONG" | "SHORT" | "WAIT" = "WAIT";
  let recommendationLabelHe: "LONG / לונג" | "SHORT / שורט" | "WAIT / להמתין" = "WAIT / להמתין";

  if (confluenceScore >= effectiveThreshold && bullPoints > bearPoints + 12) {
    recommendation = "LONG";
    recommendationLabelHe = "LONG / לונג";
  } else if (confluenceScore >= effectiveThreshold && bearPoints > bullPoints + 12) {
    recommendation = "SHORT";
    recommendationLabelHe = "SHORT / שורט";
  } else {
    recommendation = "WAIT";
    recommendationLabelHe = "WAIT / להמתין";
  }

  const isShort = recommendation === "SHORT" || (recommendation === "WAIT" && bearPoints > bullPoints);
  const slDistance = Math.max(atr14 * 1.5, currentPrice * 0.011);
  const tp1Distance = slDistance * 2.15;
  const tp2Distance = slDistance * 3.4;

  const entryPrice = currentPrice;
  const stopLoss = isShort
    ? Number((entryPrice + slDistance).toPrecision(6))
    : Number(Math.max(0.0001, entryPrice - slDistance).toPrecision(6));
  const takeProfit1 = isShort
    ? Number(Math.max(0.0001, entryPrice - tp1Distance).toPrecision(6))
    : Number((entryPrice + tp1Distance).toPrecision(6));
  const takeProfit2 = isShort
    ? Number(Math.max(0.0001, entryPrice - tp2Distance).toPrecision(6))
    : Number((entryPrice + tp2Distance).toPrecision(6));

  const rewardRiskRatio = Number((tp1Distance / slDistance).toFixed(2));
  const kellySizing = calculateKellyPositionSizing(
    confluenceScore,
    rewardRiskRatio,
    atrPct,
    accountBalanceUsdt,
    strictMode
  );

  const trendAlignmentHe =
    currentPrice > ema20 && ema20 > ema50
      ? "מגמה ראשית שורית (EMA20 > EMA50)"
      : currentPrice < ema20 && ema20 < ema50
      ? "מגמה ראשית דובית (EMA20 < EMA50)"
      : "אזור התכנסות / ניטרלי";

  return {
    symbol,
    baseAsset,
    currentPrice,
    change24hPct,
    high24h,
    low24h,
    volume24hUsdt,
    rsi14,
    macd,
    ema: {
      ema20: Number(ema20.toPrecision(6)),
      ema50: Number(ema50.toPrecision(6)),
      ema200: Number(ema200.toPrecision(6)),
      trendAlignmentHe,
    },
    atr14: Number(atr14.toPrecision(5)),
    atrPct,
    adx14,
    volumeProfile,
    recommendation,
    recommendationLabelHe,
    confluenceScore,
    entryPrice,
    stopLoss,
    takeProfit1,
    takeProfit2,
    kellySizing,
    reasonsHe,
    evaluatorWarningHe,
    lastUpdatedTs: Date.now(),
  };
}

export function formatPriceNumber(price: number): string {
  if (!Number.isFinite(price) || price === 0) return "0.00";
  if (price >= 1000) return price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (price >= 1) return price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 4 });
  return price.toLocaleString("en-US", { minimumFractionDigits: 4, maximumFractionDigits: 6 });
}
