import { LEGACY_GALAXIES } from './legacy-catalog.js';

export const KIT_MOTIFS = Object.freeze([
  'uni','bandes-verticales','bandes-horizontales','diagonales','chevrons','demi-corps','quartiers','rayons','vagues','damier',
  'foudre','etoiles','anneaux','pointille','losanges','degrade','colonne-centrale','epaules','manches-contraste','double-chevron',
  'spirale','constellation','fracture','hexagones','vitesse'
]);
export const EMBLEM_MOTIFS = Object.freeze([
  'bouclier-classique','bouclier-franc','rond','ovale','losange','ecu-anglais','ecu-espagnol','ecusson-rond','etoile','couronne',
  'aile','comete','planete','anneaux','soleil','lune','diamant','hexagone','aigle','lion',
  'dragon','flamme','eclair','constellation','monogramme'
]);
export const FLAG_MOTIFS = Object.freeze([
  'tricolore-horizontal','tricolore-vertical','bicolore-horizontal','bicolore-vertical','diagonale','croix-centrale','croix-scandinave','etoile-centrale','soleil-levant','rayons',
  'chevron','triangle-mat','quartiers','bande-centrale','bande-canton','ondes','damier','losanges','anneau','constellation',
  'degrade','double-diagonale','etoiles-en-cercle','vagues','spirale'
]);
export const IDENTITY_PALETTE = Object.freeze([
  ['#102a56','#f2f4f8','#d5a63c'],['#8d1725','#f4f0e8','#182d4d'],['#087f78','#f7d66b','#102b49'],['#45206f','#f3f0ff','#d9a441'],
  ['#e36b24','#172a4a','#f4e6c8'],['#1471b8','#f8f8f2','#1e2740'],['#192b32','#d9a63b','#f4f1e8'],['#5a183e','#f2d6e4','#d6a84b'],
  ['#42713c','#f4f0dc','#1c3354'],['#c7a52a','#172b50','#f7f0d4'],['#166b91','#d8edf4','#b83a46'],['#5b2c83','#e8dff1','#e4a93d'],
  ['#a62c2c','#f3e7d0','#263c5c'],['#23634f','#f3e7bd','#d08c32'],['#263b78','#e9eaf4','#d84c3d'],['#7c3b20','#f5e7c7','#1e344b'],
  ['#0b5e69','#f5f0dc','#a73b4a'],['#603c86','#f0edf7','#64a6a1'],['#28333d','#f4f0e7','#c64d37'],['#a17b23','#1f3655','#f5ead0'],
  ['#155e9a','#f2f2e8','#e06c35'],['#792f51','#f5e9dd','#274e70'],['#356b86','#e9f3f5','#d2a12d'],['#4c4b24','#f3ecd8','#8c2735'],
  ['#293c91','#e8e7f4','#3b9b86'],['#a84d21','#f7e7cf','#254b67'],['#3a6e65','#f1efe4','#8f3150'],['#573d2d','#f0dfc1','#b33a32'],
  ['#2c315e','#e5e7f3','#d7a43b'],['#8b2635','#f4e8d5','#246b63']
]);

function hash(value){let h=2166136261;for(const ch of String(value)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function makeIdentity(key,index,kind){
  const seed=hash(`${kind}:${key}`)+index*2654435761>>>0;
  const colors=IDENTITY_PALETTE[index%IDENTITY_PALETTE.length];
  return {
    kit:{motif:KIT_MOTIFS[index%KIT_MOTIFS.length],primary:colors[0],secondary:colors[1],accent:colors[2],number:String((seed%99)+1).padStart(2,'0')},
    emblem:{motif:EMBLEM_MOTIFS[(index*7+3)%EMBLEM_MOTIFS.length],primary:colors[0],secondary:colors[1],accent:colors[2],symbol:['✦','★','☼','♛','⚡','◈','✧','⬟','☾','♜'][seed%10]},
    flag:{motif:FLAG_MOTIFS[(index*11+5)%FLAG_MOTIFS.length],primary:colors[0],secondary:colors[1],accent:colors[2]}
  };
}
export function ensureVisualIdentities(state){
  const clubs=state.divisions.flatMap(d=>d.clubs);
  const galaxies=state.world?.galaxies||LEGACY_GALAXIES;
  for(const [galaxyIndex,galaxy] of galaxies.entries())galaxy.id??=`galaxy-${String(galaxyIndex+1).padStart(2,'0')}`;
  const all=[...clubs,...galaxies];
  const hasExistingIdentity=all.some(entity=>Boolean(entity.visualIdentity));
  let nextIndex=hasExistingIdentity?all.length:0;
  for(const entity of all){
    if(!entity.visualIdentity)entity.visualIdentity=makeIdentity(entity.id||entity.name,nextIndex++,entity.divisionId?'club':'galaxy');
  }
  return state;
}
export function getIdentityEntity(state,type,id){
  if(type==='club')return state.divisions.flatMap(d=>d.clubs).find(c=>c.id===id)||null;
  if(type==='galaxy')return (state.world?.galaxies||[]).find(g=>g.id===id)||null;
  return null;
}
export function updateVisualIdentity(state,type,id,patch){
  const entity=getIdentityEntity(state,type,id);if(!entity)throw new Error('Club ou galaxie introuvable.');
  const current=entity.visualIdentity;if(!current)throw new Error('Identité visuelle non initialisée.');
  const before=JSON.parse(JSON.stringify(current));
  try{
    for(const part of ['kit','emblem','flag']){
      if(!patch[part])continue;
      const catalog=part==='kit'?KIT_MOTIFS:part==='emblem'?EMBLEM_MOTIFS:FLAG_MOTIFS;
      const next=patch[part];
      if(next.motif&&!catalog.includes(next.motif))throw new Error(`Motif ${part} non reconnu.`);
      for(const color of ['primary','secondary','accent'])if(next[color]&&!/^#[0-9a-f]{6}$/i.test(next[color]))throw new Error('Code couleur invalide.');
      current[part]={...current[part],...next};
    }
    validateVisualIdentities(state);
    return entity.visualIdentity;
  }catch(error){entity.visualIdentity=before;throw error;}
}
export function validateVisualIdentities(state){
  const clubs=state.divisions.flatMap(d=>d.clubs),galaxies=state.world?.galaxies||[];
  const all=[...clubs,...galaxies];
  if(all.some(x=>!x.visualIdentity?.kit||!x.visualIdentity?.emblem||!x.visualIdentity?.flag))throw new Error('Identité visuelle manquante.');
  for(const [part,catalog] of [['kit',KIT_MOTIFS],['emblem',EMBLEM_MOTIFS],['flag',FLAG_MOTIFS]]){
    if(catalog.length<20)throw new Error(`Le catalogue ${part} doit contenir au moins 20 motifs.`);
    for(const entity of all){const design=entity.visualIdentity[part];if(!catalog.includes(design.motif))throw new Error(`Motif ${part} invalide pour ${entity.id||entity.name}.`);}
  }
  const fingerprint=(x,p)=>{const d=x.visualIdentity[p];return [d.motif,d.primary,d.secondary,d.accent,d.symbol||'',d.number||''].join('|');};
  for(const part of ['kit','emblem','flag'])if(new Set(all.map(x=>fingerprint(x,part))).size!==all.length)throw new Error(`Deux identités ${part} sont identiques.`);
  return {clubs:clubs.length,galaxies:galaxies.length,total:all.length,motifs:{kit:KIT_MOTIFS.length,emblem:EMBLEM_MOTIFS.length,flag:FLAG_MOTIFS.length}};
}
