export type SpeciesKey = "deer" | "elk" | "boar" | "fox" | "hare" | "pheasant";

export interface Species {
  key: SpeciesKey;
  name: string;
  latin: string;
  points: number;
  difficulty: 1 | 2 | 3;
  habitat: string;
  weight: string;
  range: string;
  note: string;
  status: string;
}

export const SPECIES: Species[] = [
  {
    key: "deer",
    name: "Mule Deer",
    latin: "Odocoileus hemionus",
    points: 140,
    difficulty: 2,
    habitat: "Sage breaks & open aspen",
    weight: "68–110 kg",
    range: "Golden Ridge, north basin",
    note: "The heartbeat of the ridge. Moves at first light, pauses often, and trusts its ears more than its eyes.",
    status: "Plentiful",
  },
  {
    key: "elk",
    name: "Rocky Mountain Elk",
    latin: "Cervus canadensis",
    points: 320,
    difficulty: 3,
    habitat: "High meadow & timberline",
    weight: "240–320 kg",
    range: "Upper ridge, above the lake",
    note: "A once-in-a-season tag. Heavy, wary, and rarely alone. Wind is everything when the herd is close.",
    status: "Rare",
  },
  {
    key: "boar",
    name: "Wild Boar",
    latin: "Sus scrofa",
    points: 200,
    difficulty: 2,
    habitat: "Scrub thickets & creek bottoms",
    weight: "80–150 kg",
    range: "Southern brush, near water",
    note: "Tough and quick to turn. Wait for the quartering shot and never follow a wounded boar into cover.",
    status: "Established",
  },
  {
    key: "fox",
    name: "Red Fox",
    latin: "Vulpes vulpes",
    points: 90,
    difficulty: 2,
    habitat: "Ridge edges & meadow margins",
    weight: "5–9 kg",
    range: "Widespread across the unit",
    note: "A small, clever target with a talent for vanishing. Take your time — a rushed shot at a fox is a wasted morning.",
    status: "Uncommon",
  },
  {
    key: "hare",
    name: "Mountain Hare",
    latin: "Lepus timidus",
    points: 60,
    difficulty: 1,
    habitat: "Alpine grass & talus fields",
    weight: "2–4 kg",
    range: "Near camp, all elevations",
    note: "Fast, low, and easy to miss. Best taken with a short hold, a calm breath, and respect for the small things.",
    status: "Plentiful",
  },
  {
    key: "pheasant",
    name: "Ring-necked Pheasant",
    latin: "Phasianus colchicus",
    points: 50,
    difficulty: 1,
    habitat: "Grassland & field edge",
    weight: "1–2 kg",
    range: "Meadow floor, dawn & dusk",
    note: "Grounded until startled. A beautiful bird, and a reminder that the wild is not a shooting gallery.",
    status: "Limited quota",
  },
];

export const speciesByKey = Object.fromEntries(SPECIES.map((s) => [s.key, s])) as Record<SpeciesKey, Species>;

export interface Loadout {
  id: "carbine" | "timberwolf" | "scout";
  name: string;
  calibre: string;
  role: string;
  magazine: number;
  reserve: number;
  zoomFov: number;
  range: string;
  stability: number;
  weight: string;
  description: string;
}

export const LOADOUTS: Loadout[] = [
  {
    id: "carbine",
    name: "Ridgeline",
    calibre: ".308 Win",
    role: "The all-rounder",
    magazine: 5,
    reserve: 15,
    zoomFov: 19,
    range: "600 m",
    stability: 4,
    weight: "3.6 kg",
    description: "Walnut stock, balanced barrel, and a crisp two-stage trigger. Patient enough for the ridge, quick enough for the timber.",
  },
  {
    id: "timberwolf",
    name: "Timberwolf",
    calibre: ".300 Win Mag",
    role: "The long-reach",
    magazine: 3,
    reserve: 12,
    zoomFov: 13,
    range: "900 m",
    stability: 3,
    weight: "4.4 kg",
    description: "A heavy magnum built for open country. Reach out across the basin — but mind the recoil and choose your shots.",
  },
  {
    id: "scout",
    name: "Cedar Scout",
    calibre: ".223 Rem",
    role: "The brush gun",
    magazine: 8,
    reserve: 24,
    zoomFov: 25,
    range: "350 m",
    stability: 5,
    weight: "3.1 kg",
    description: "Light, fast-handling, and forgiving. Ideal for hare, fox, and pheasant at close quarters in the willows.",
  },
];

export const DEFAULT_LOADOUT: Loadout = LOADOUTS[0];

export interface Wave {
  id: string;
  name: string;
  subtitle: string;
  quota: number;
  duration: number;
  population: number;
  bonus: number;
}

export const WAVES: Wave[] = [
  { id: "wave-1", name: "First light", subtitle: "The basin approach", quota: 2, duration: 55, population: 14, bonus: 150 },
  { id: "wave-2", name: "The timber line", subtitle: "Golden aspen draw", quota: 2, duration: 55, population: 18, bonus: 200 },
  { id: "wave-3", name: "Open ridge", subtitle: "Above the north lake", quota: 3, duration: 50, population: 22, bonus: 250 },
  { id: "wave-4", name: "High meadow", subtitle: "The elk grounds", quota: 3, duration: 50, population: 26, bonus: 300 },
  { id: "wave-5", name: "Last light", subtitle: "The whole-ridge drive", quota: 4, duration: 45, population: 30, bonus: 400 },
];

export const TOTAL_QUOTA = WAVES.reduce((sum, wave) => sum + wave.quota, 0);

export const MISSION = {
  name: "The Golden Ridge",
  code: "ASSIGNMENT 04",
  goal: 8,
  time: 300,
  blurb: "Five driven waves of game sweep the ridge before last light. Read the herd, keep your rifle fed, and make every round matter.",
  objectives: [
    { id: "drives", label: "Clear three of five drives", target: 3 },
    { id: "distance", label: "Make a shot beyond 150 m", target: 1 },
    { id: "accuracy", label: "Finish with accuracy above 50%", target: 1 },
  ],
};

/* ------------------------------ android controls ----------------------------- */

export type TouchLayout = "A" | "B";
export type MapId = "golden" | "pine" | "frost" | "ember";

export interface HuntingMap {
  id: MapId;
  name: string;
  subtitle: string;
  region: string;
  conditions: string;
  temperature: string;
  wind: string;
  description: string;
  swatch: [string, string, string];
  terrain: { low: string; high: string; shore: string; rock: string };
  pines: string[];
  aspens: string[];
  grass: string[];
  mountains: [string, string, string];
  sky: { zenith: string; mid: string; horizon: string; sun: string };
  fog: { color: string; near: number; far: number };
  sun: { color: string; intensity: number; position: [number, number, number]; exposure: number };
  hemi: { sky: string; ground: string; intensity: number };
  water: { color: string; opacity: number; metalness: number };
  snow: boolean;
}

export const MAPS: HuntingMap[] = [
  {
    id: "golden",
    name: "Golden Ridge",
    subtitle: "Autumn sunrise",
    region: "Northern Range · Unit 12",
    conditions: "Clear · first light",
    temperature: "4°C",
    wind: "NW 7 kts",
    description: "The club's home basin. Golden aspens, open sage breaks and a lake that holds the first light.",
    swatch: ["#d9b477", "#5f7757", "#8a6743"],
    terrain: { low: "#6b7c4b", high: "#8a8c5e", shore: "#a49975", rock: "#73756b" },
    pines: ["#2f4a36", "#36553c", "#3d5b40", "#2a412f", "#496445"],
    aspens: ["#bf9a55", "#c9a45e", "#a98743", "#d0ae6c", "#8f8a4c"],
    grass: ["#9d9b62", "#b0a56c", "#87884f", "#c0ac75"],
    mountains: ["#8b9497", "#77817f", "#66715f"],
    sky: { zenith: "#6c8b9a", mid: "#c9b99c", horizon: "#f0d3a3", sun: "#ffe3ad" },
    fog: { color: "#cbb18e", near: 75, far: 335 },
    sun: { color: "#ffdcae", intensity: 2.35, position: [75, 95, -55], exposure: 1.06 },
    hemi: { sky: "#dfe8ea", ground: "#4c4631", intensity: 1.25 },
    water: { color: "#748f8b", opacity: 0.9, metalness: 0.55 },
    snow: false,
  },
  {
    id: "pine",
    name: "Pine Hollow",
    subtitle: "Deep valley noon",
    region: "Cedar Valley · Unit 07",
    conditions: "High cloud · flat light",
    temperature: "9°C",
    wind: "W 11 kts",
    description: "A tight green hollow where the timber closes in. Close, quick shots and a lot of cover for the herd.",
    swatch: ["#a9c4b4", "#2b4d38", "#6f8458"],
    terrain: { low: "#4c6b4a", high: "#6f8458", shore: "#8d8a6b", rock: "#687069" },
    pines: ["#234232", "#2b4d38", "#1d3a2b", "#35553b", "#3f6142"],
    aspens: ["#8fa85d", "#a4b66b", "#7c9954", "#b3c07a"],
    grass: ["#7f9a5f", "#93a86b", "#6c8a52", "#a8b878"],
    mountains: ["#7e928f", "#6a8079", "#5a6f60"],
    sky: { zenith: "#4f7f9e", mid: "#9fc0c4", horizon: "#dbe7d2", sun: "#fff4d0" },
    fog: { color: "#a9c4b4", near: 60, far: 300 },
    sun: { color: "#fff0c9", intensity: 2.5, position: [-60, 110, -40], exposure: 1.02 },
    hemi: { sky: "#d8eee8", ground: "#3b4a35", intensity: 1.35 },
    water: { color: "#5d8c8b", opacity: 0.94, metalness: 0.5 },
    snow: false,
  },
  {
    id: "frost",
    name: "Frost Basin",
    subtitle: "Alpine overcast",
    region: "High Divide · Unit 21",
    conditions: "Snow flurries · low cloud",
    temperature: "−6°C",
    wind: "N 14 kts",
    description: "Thin air, white ground and long sight lines. The hardest tracking of the season, and the prettiest.",
    swatch: ["#dfeaf0", "#3a564b", "#aab6a3"],
    terrain: { low: "#c3cbc4", high: "#e6ece9", shore: "#b6b1a3", rock: "#8d928f" },
    pines: ["#3a564b", "#44645a", "#314b41", "#4d6a5c"],
    aspens: ["#c7cdb4", "#d6dcc6", "#b1b99f", "#e1e5d6"],
    grass: ["#aab6a3", "#c2c9b6", "#8f9f93", "#d2d8c8"],
    mountains: ["#aebcc4", "#95a6ab", "#7d8e8f"],
    sky: { zenith: "#6a8aa8", mid: "#b9cbd5", horizon: "#eef1ef", sun: "#fff7e0" },
    fog: { color: "#c8d7dc", near: 85, far: 360 },
    sun: { color: "#f2f7ff", intensity: 1.9, position: [40, 120, -30], exposure: 1.05 },
    hemi: { sky: "#dfeef5", ground: "#6a7169", intensity: 1.4 },
    water: { color: "#7d99a4", opacity: 0.96, metalness: 0.35 },
    snow: true,
  },
  {
    id: "ember",
    name: "Ember Draw",
    subtitle: "Red-rock dusk",
    region: "Southern Breaks · Unit 33",
    conditions: "Dust haze · golden dusk",
    temperature: "18°C",
    wind: "SW 5 kts",
    description: "Dry arroyos and red stone. The last of the light stretches long shadows across the draw.",
    swatch: ["#f0b57f", "#3d3b2b", "#c47a45"],
    terrain: { low: "#8a5d3b", high: "#a9794c", shore: "#b18a5e", rock: "#7c5140" },
    pines: ["#3d3b2b", "#4a4631", "#33301f", "#555240"],
    aspens: ["#b06a3c", "#c47a45", "#8f5634", "#d18a50"],
    grass: ["#a58553", "#b8985f", "#8a6e45", "#c4a66c"],
    mountains: ["#8f7a80", "#7c666a", "#6b5754"],
    sky: { zenith: "#4d5a78", mid: "#c98a63", horizon: "#f0b57f", sun: "#ffb47a" },
    fog: { color: "#c69a7d", near: 65, far: 320 },
    sun: { color: "#ffb085", intensity: 2.1, position: [110, 70, 30], exposure: 1 },
    hemi: { sky: "#e8c6b2", ground: "#4a3527", intensity: 1.2 },
    water: { color: "#6f7f86", opacity: 0.92, metalness: 0.6 },
    snow: false,
  },
];

export const DEFAULT_MAP: MapId = "golden";

export function mapById(id: MapId): HuntingMap {
  return MAPS.find((map) => map.id === id) ?? MAPS[0];
}

export interface ControlSettings {
  layout: TouchLayout;
  sensitivity: number;
  map: MapId;
  infiniteAmmo: boolean;
}

export const DEFAULT_CONTROLS: ControlSettings = {
  layout: "A",
  sensitivity: 1,
  map: "golden",
  infiniteAmmo: true,
};

const CONTROLS_KEY = "ridgeline.controls.v2";
const LEGACY_CONTROLS_KEY = "ridgeline.controls.v1";

export function readControls(): ControlSettings {
  try {
    const raw = localStorage.getItem(CONTROLS_KEY) ?? localStorage.getItem(LEGACY_CONTROLS_KEY);
    if (!raw) return DEFAULT_CONTROLS;
    const parsed = JSON.parse(raw) as Partial<ControlSettings>;
    const map = MAPS.some((item) => item.id === parsed.map) ? (parsed.map as MapId) : DEFAULT_MAP;
    return {
      layout: parsed.layout === "B" ? "B" : "A",
      sensitivity: typeof parsed.sensitivity === "number" ? parsed.sensitivity : 1,
      map,
      infiniteAmmo: typeof parsed.infiniteAmmo === "boolean" ? parsed.infiniteAmmo : true,
    };
  } catch {
    return DEFAULT_CONTROLS;
  }
}

export function writeControls(settings: ControlSettings): void {
  try {
    localStorage.setItem(CONTROLS_KEY, JSON.stringify(settings));
  } catch {
    /* private mode */
  }
}

export interface HuntRecord {
  id: string;
  date: string;
  score: number;
  harvested: number;
  shots: number;
  hits: number;
  accuracy: number;
  bestDistance: number;
  loadout: string;
  completed: boolean;
}

const RECORDS_KEY = "ridgeline.records.v1";

export function readRecords(): HuntRecord[] {
  try {
    const raw = localStorage.getItem(RECORDS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as HuntRecord[]).slice(0, 20) : [];
  } catch {
    return [];
  }
}

export function writeRecord(record: HuntRecord): HuntRecord[] {
  const next = [record, ...readRecords()].slice(0, 20);
  try {
    localStorage.setItem(RECORDS_KEY, JSON.stringify(next));
  } catch {
    /* storage can be unavailable in private mode */
  }
  return next;
}

export function formatTime(total: number): string {
  const safe = Math.max(0, Math.round(total));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}
