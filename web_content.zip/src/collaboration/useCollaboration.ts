/**
 * Real-Time Collaboration Hook for xvBOARD
 * Handles WebSocket connection, presence tracking, cursor broadcasting, and state reconciliation.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { CanvasElement } from '../canvas/types';
import { PeerInfo, CollabConnectionStatus, CollabMessage } from './types';
import { generateAnonymousPeer } from './names';

interface UseCollaborationOptions {
  onSyncElements: (elements: CanvasElement[], title?: string) => void;
  onRemoteElementUpsert: (element: CanvasElement) => void;
  onRemoteElementDelete: (elementId: string) => void;
}

export function useCollaboration({
  onSyncElements,
  onRemoteElementUpsert,
  onRemoteElementDelete,
}: UseCollaborationOptions) {
  const [status, setStatus] = useState<CollabConnectionStatus>('disconnected');
  const [roomId, setRoomId] = useState<string | null>(null);
  const [peers, setPeers] = useState<PeerInfo[]>([]);
  const [localPeer, setLocalPeer] = useState<PeerInfo>(() => generateAnonymousPeer());
  const [liveStrokes, setLiveStrokes] = useState<
    Map<string, { peerId: string; color: string; strokeWidth: number; points: { x: number; y: number }[] }>
  >(new Map());

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const activeRoomIdRef = useRef<string | null>(null);
  const isManuallyDisconnectedRef = useRef<boolean>(false);
  const initialBoardPayloadRef = useRef<any>(null);

  // Throttled cursor position buffer
  const lastCursorEmitRef = useRef<number>(0);

  // Stable references for callbacks to avoid re-binding socket listeners
  const onSyncRef = useRef(onSyncElements);
  const onUpsertRef = useRef(onRemoteElementUpsert);
  const onDeleteRef = useRef(onRemoteElementDelete);

  useEffect(() => {
    onSyncRef.current = onSyncElements;
    onUpsertRef.current = onRemoteElementUpsert;
    onDeleteRef.current = onRemoteElementDelete;
  }, [onSyncElements, onRemoteElementUpsert, onRemoteElementDelete]);

  const connectToRoom = useCallback(
    (targetRoomId: string, initialBoard?: any) => {
      if (wsRef.current) {
        wsRef.current.close();
      }

      isManuallyDisconnectedRef.current = false;
      activeRoomIdRef.current = targetRoomId;
      setRoomId(targetRoomId);
      setStatus('connecting');

      if (initialBoard) {
        initialBoardPayloadRef.current = initialBoard;
      }

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;

      try {
        const socket = new WebSocket(wsUrl);
        wsRef.current = socket;

        socket.onopen = () => {
          setStatus('connected');
          // Send join message
          const joinMsg: CollabMessage = {
            type: 'join',
            roomId: targetRoomId,
            peer: {
              id: localPeer.id,
              name: localPeer.name,
              color: localPeer.color,
            },
            initialBoard: initialBoardPayloadRef.current,
          };
          socket.send(JSON.stringify(joinMsg));
        };

        socket.onmessage = (event) => {
          try {
            const data: CollabMessage = JSON.parse(event.data);

            if (data.type === 'sync') {
              setPeers(data.peers.filter((p) => p.id !== localPeer.id));
              onSyncRef.current(data.elements, data.boardTitle);
            } else if (data.type === 'peer-joined') {
              if (data.peer.id !== localPeer.id) {
                setPeers((prev) => {
                  const filtered = prev.filter((p) => p.id !== data.peer.id);
                  return [...filtered, data.peer];
                });
              }
            } else if (data.type === 'peer-left') {
              setPeers((prev) => prev.filter((p) => p.id !== data.peerId));
              // Also clear any in-progress live stroke by this peer
              setLiveStrokes((prev) => {
                const next = new Map(prev);
                for (const [sId, s] of next.entries()) {
                  if (s.peerId === data.peerId) next.delete(sId);
                }
                return next;
              });
            } else if (data.type === 'cursor-moved') {
              setPeers((prev) =>
                prev.map((p) => {
                  if (p.id === data.peerId) {
                    return {
                      ...p,
                      cursor: { x: data.x, y: data.y, lastActive: Date.now() },
                    };
                  }
                  return p;
                })
              );
            } else if (data.type === 'element-upserted') {
              onUpsertRef.current(data.element);
            } else if (data.type === 'element-deleted') {
              onDeleteRef.current(data.elementId);
            } else if (data.type === 'stroke-live-received') {
              setLiveStrokes((prev) => {
                const next = new Map(prev);
                if (data.isEnd) {
                  next.delete(data.strokeId);
                } else {
                  const existing = next.get(data.strokeId);
                  if (existing) {
                    existing.points.push(data.point);
                    next.set(data.strokeId, { ...existing });
                  } else {
                    next.set(data.strokeId, {
                      peerId: data.peerId,
                      color: data.color,
                      strokeWidth: data.strokeWidth,
                      points: [data.point],
                    });
                  }
                }
                return next;
              });
            }
          } catch (err) {
            console.error('Error decoding collaboration message:', err);
          }
        };

        socket.onclose = () => {
          if (!isManuallyDisconnectedRef.current && activeRoomIdRef.current) {
            setStatus('reconnecting');
            reconnectTimeoutRef.current = setTimeout(() => {
              if (activeRoomIdRef.current) {
                connectToRoom(activeRoomIdRef.current);
              }
            }, 2500);
          } else {
            setStatus('disconnected');
            setPeers([]);
          }
        };

        socket.onerror = (err) => {
          console.error('WebSocket error:', err);
        };
      } catch (err) {
        console.error('Failed to initiate WebSocket:', err);
        setStatus('disconnected');
      }
    },
    [localPeer]
  );

  const leaveRoom = useCallback(() => {
    isManuallyDisconnectedRef.current = true;
    activeRoomIdRef.current = null;
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setRoomId(null);
    setPeers([]);
    setStatus('disconnected');
    setLiveStrokes(new Map());
  }, []);

  const sendCursor = useCallback((x: number, y: number) => {
    const now = Date.now();
    // Throttle to 30ms (~33 updates/sec) for optimal responsiveness and bandwidth
    if (now - lastCursorEmitRef.current < 30) return;
    lastCursorEmitRef.current = now;

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'cursor', x, y }));
    }
  }, []);

  const sendElementUpsert = useCallback((element: CanvasElement) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'element-upsert',
          element,
          timestamp: Date.now(),
        })
      );
    }
  }, []);

  const sendElementDelete = useCallback((elementId: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'element-delete',
          elementId,
          timestamp: Date.now(),
        })
      );
    }
  }, []);

  const sendLiveStrokePoint = useCallback(
    (strokeId: string, point: { x: number; y: number; pressure?: number }, color: string, strokeWidth: number, isEnd = false) => {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: 'stroke-live',
            strokeId,
            point,
            color,
            strokeWidth,
            isEnd,
          })
        );
      }
    },
    []
  );

  const updateLocalPeer = useCallback((name: string, color: string) => {
    setLocalPeer((prev) => ({ ...prev, name, color }));
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  return {
    status,
    roomId,
    peers,
    localPeer,
    liveStrokes,
    isCollaborating: status === 'connected' || status === 'connecting' || status === 'reconnecting',
    connectToRoom,
    leaveRoom,
    sendCursor,
    sendElementUpsert,
    sendElementDelete,
    sendLiveStrokePoint,
    updateLocalPeer,
  };
}
