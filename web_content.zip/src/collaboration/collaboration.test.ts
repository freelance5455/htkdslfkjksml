import test from 'node:test';
import assert from 'node:assert/strict';
import { generateAnonymousPeer } from './names';
import { CollabMessage } from './types';

test('generateAnonymousPeer creates unique anonymous identities with valid colors', () => {
  const p1 = generateAnonymousPeer();
  const p2 = generateAnonymousPeer();

  assert.ok(p1.id.startsWith('peer-'));
  assert.ok(p2.id.startsWith('peer-'));
  assert.notEqual(p1.id, p2.id);
  assert.ok(p1.name.length > 3);
  assert.ok(p1.color.startsWith('#'));
});

test('generateAnonymousPeer respects custom overrides if provided', () => {
  const custom = generateAnonymousPeer('user-123', 'Custom Architect', '#10b981');
  assert.equal(custom.id, 'user-123');
  assert.equal(custom.name, 'Custom Architect');
  assert.equal(custom.color, '#10b981');
});

test('LWW Conflict Resolution properly selects newest element revision', () => {
  // Simulate two concurrent edits on the same canvas element
  const baseElement: {
    id: string;
    type: 'rect';
    x: number;
    y: number;
    width: number;
    height: number;
    zIndex: number;
    updatedAt: number;
    updatedBy?: string;
  } = {
    id: 'rect-shared-1',
    type: 'rect' as const,
    x: 100,
    y: 100,
    width: 200,
    height: 100,
    zIndex: 1,
    updatedAt: 1000,
  };

  const clientAEdit = {
    ...baseElement,
    x: 150,
    updatedAt: 1050,
    updatedBy: 'peer-A',
  };

  const clientBEdit = {
    ...baseElement,
    x: 200,
    updatedAt: 1020, // Stale edit
    updatedBy: 'peer-B',
  };

  // Function mimicking the server LWW resolution
  function resolveLWW(current: typeof baseElement, incoming: typeof baseElement) {
    if (!current || incoming.updatedAt >= current.updatedAt) {
      return incoming;
    }
    return current;
  }

  // Client A edit is applied first
  let resolved = resolveLWW(baseElement, clientAEdit);
  assert.equal(resolved.x, 150);
  assert.equal(resolved.updatedBy, 'peer-A');

  // Client B edit arrives later but with older timestamp -> rejected in favor of Client A
  resolved = resolveLWW(resolved, clientBEdit);
  assert.equal(resolved.x, 150);
  assert.equal(resolved.updatedBy, 'peer-A');
});

test('CollabMessage cursor payload encodes world coordinates accurately', () => {
  const msg: CollabMessage = {
    type: 'cursor-moved',
    peerId: 'peer-test-1',
    x: 450.5,
    y: 820.25,
  };

  const encoded = JSON.stringify(msg);
  const decoded = JSON.parse(encoded) as CollabMessage;

  assert.equal(decoded.type, 'cursor-moved');
  if (decoded.type === 'cursor-moved') {
    assert.equal(decoded.peerId, 'peer-test-1');
    assert.equal(decoded.x, 450.5);
    assert.equal(decoded.y, 820.25);
  }
});
