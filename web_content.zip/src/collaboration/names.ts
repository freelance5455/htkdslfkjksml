/**
 * Anonymous User Identity Generator for Collaborative Sessions
 * Generates Material You-themed anonymous names and accessible vibrant colors.
 */

const ADJECTIVES = [
  'Sky',
  'Ocean',
  'Amber',
  'Emerald',
  'Rose',
  'Lavender',
  'Solar',
  'Cosmic',
  'Mint',
  'Coral',
  'Azure',
  'Golden',
  'Indigo',
  'Sunset',
  'Frost',
  'Neon',
];

const ANIMALS = [
  'Falcon',
  'Otter',
  'Fox',
  'Heron',
  'Finch',
  'Lynx',
  'Panda',
  'Badger',
  'Dolphin',
  'Robin',
  'Tiger',
  'Cheetah',
  'Hawk',
  'Koala',
  'Wolf',
  'Owl',
];

const AVATAR_COLORS = [
  '#0284c7', // Sky Blue
  '#2563eb', // Royal Blue
  '#7c3aed', // Violet
  '#c026d3', // Fuchsia
  '#db2777', // Pink
  '#e11d48', // Rose
  '#ea580c', // Orange
  '#d97706', // Amber
  '#059669', // Emerald
  '#0d9488', // Teal
  '#4f46e5', // Indigo
];

export function generateAnonymousPeer(existingId?: string, existingName?: string, existingColor?: string) {
  const id = existingId || `peer-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
  
  const randomAdj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
  const randomAnimal = ANIMALS[Math.floor(Math.random() * ANIMALS.length)];
  const name = existingName || `${randomAdj} ${randomAnimal}`;
  
  const color = existingColor || AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

  return { id, name, color };
}
