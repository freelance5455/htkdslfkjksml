/**
 * Real-Time Collaboration Types & Protocols
 */

import { CanvasElement } from '../canvas/types';

export interface PeerInfo {
  id: string;
  name: string;
  color: string;
  cursor?: {
    x: number;
    y: number;
    lastActive: number;
  };
  isDrawing?: boolean;
}

export type CollabConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'reconnecting';

export type CollabMessage =
  | {
      type: 'join';
      roomId: string;
      peer: { id: string; name: string; color: string };
      initialBoard?: {
        title: string;
        elements: CanvasElement[];
        bgType?: string;
        bgColor?: string;
      };
    }
  | {
      type: 'sync';
      roomId: string;
      elements: CanvasElement[];
      peers: PeerInfo[];
      boardTitle?: string;
    }
  | {
      type: 'peer-joined';
      peer: PeerInfo;
    }
  | {
      type: 'peer-left';
      peerId: string;
    }
  | {
      type: 'cursor';
      x: number;
      y: number;
    }
  | {
      type: 'cursor-moved';
      peerId: string;
      x: number;
      y: number;
    }
  | {
      type: 'element-upsert';
      element: CanvasElement;
      timestamp: number;
    }
  | {
      type: 'element-upserted';
      peerId: string;
      element: CanvasElement;
      timestamp: number;
    }
  | {
      type: 'element-delete';
      elementId: string;
      timestamp: number;
    }
  | {
      type: 'element-deleted';
      peerId: string;
      elementId: string;
      timestamp: number;
    }
  | {
      type: 'stroke-live';
      strokeId: string;
      point: { x: number; y: number; pressure?: number };
      color: string;
      strokeWidth: number;
      isEnd?: boolean;
    }
  | {
      type: 'stroke-live-received';
      peerId: string;
      strokeId: string;
      point: { x: number; y: number; pressure?: number };
      color: string;
      strokeWidth: number;
      isEnd?: boolean;
    };
