// High-quality illustrations and dish photos for breakfast, lunch, dinner and snacks.

export const BREAKFAST_SVG = `data:image/svg+xml;base64,${btoa(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice">
<defs>
<linearGradient id="bg0" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FCE7D6"/><stop offset="1" stop-color="#F3CBB3"/></linearGradient>
<radialGradient id="pl0" cx=".4" cy=".35" r=".8"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#EDE7DE"/></radialGradient>
<filter id="sh0" x="-20%" y="-20%" width="150%" height="150%"><feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#000" flood-opacity=".18"/></filter>
</defs>
<rect width="400" height="140" fill="url(#bg0)"/>
<g filter="url(#sh0)">
<circle cx="140" cy="70" r="54" fill="url(#pl0)"/>
<circle cx="140" cy="70" r="46" fill="none" stroke="#E2DACF" stroke-width="1.5"/>
</g>
<rect x="106" y="44" width="36" height="34" rx="6" fill="#D49E58" transform="rotate(-10 124 61)"/>
<rect x="110" y="48" width="28" height="26" rx="4" fill="#F4D396" transform="rotate(-10 124 61)"/>
<path d="M136 60 c-8 0 -14 7 -12 15 2 7 9 13 17 12 7 -1 13 -7 11 -15 -2 -8 -8 -12 -16 -12z" fill="#FFFFFF"/>
<circle cx="143" cy="73" r="8" fill="#FF9D14"/>
<circle cx="141" cy="70" r="2.5" fill="#FFE27A"/>
<path d="M118 84 q12 8 24 2" stroke="#487834" stroke-width="4" stroke-linecap="round" fill="none"/>
<path d="M120 90 q10 7 20 2" stroke="#719C45" stroke-width="3.5" stroke-linecap="round" fill="none"/>
<circle cx="162" cy="54" r="5" fill="#3B3A68"/><circle cx="170" cy="62" r="4.5" fill="#2E2D56"/><circle cx="166" cy="70" r="4" fill="#4B4B82"/>
<g filter="url(#sh0)">
<circle cx="280" cy="70" r="28" fill="#F8F6F2"/>
<circle cx="280" cy="70" r="22" fill="#52321D"/>
<circle cx="280" cy="70" r="18" fill="#3D2111"/>
<ellipse cx="276" cy="66" rx="6" ry="3" fill="#6A462B" transform="rotate(-20 276 66)"/>
<path d="M308 64 c6 0 10 4 10 10 c0 6 -4 10 -10 10" stroke="#F8F6F2" stroke-width="4" fill="none"/>
</g>
</svg>`)}`;

export const LUNCH_SVG = `data:image/svg+xml;base64,${btoa(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice">
<defs>
<linearGradient id="bg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#E2F0D9"/><stop offset="1" stop-color="#C5DFB8"/></linearGradient>
<radialGradient id="pl1" cx=".4" cy=".35" r=".8"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#EDE7DE"/></radialGradient>
<filter id="sh1" x="-20%" y="-20%" width="150%" height="150%"><feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#000" flood-opacity=".18"/></filter>
</defs>
<rect width="400" height="140" fill="url(#bg1)"/>
<g filter="url(#sh1)">
<circle cx="140" cy="70" r="54" fill="url(#pl1)"/>
<circle cx="140" cy="70" r="46" fill="none" stroke="#E2DACF" stroke-width="1.5"/>
</g>
<circle cx="120" cy="64" r="14" fill="#549E37"/>
<circle cx="132" cy="54" r="12" fill="#6CB84B"/>
<circle cx="114" cy="76" r="11" fill="#42822B"/>
<circle cx="116" cy="62" r="5.5" fill="#E83D2C"/><circle cx="114" cy="60" r="1.5" fill="#FFA59E"/>
<circle cx="132" cy="74" r="5" fill="#E83D2C"/>
<rect x="136" y="52" width="34" height="12" rx="5" fill="#C98B48" transform="rotate(18 153 58)"/>
<line x1="140" y1="54" x2="148" y2="60" stroke="#7E4A1C" stroke-width="2"/>
<line x1="150" y1="57" x2="158" y2="63" stroke="#7E4A1C" stroke-width="2"/>
<rect x="132" y="72" width="36" height="12" rx="5" fill="#DDA05C" transform="rotate(-8 150 78)"/>
<line x1="138" y1="77" x2="146" y2="76" stroke="#7E4A1C" stroke-width="2"/>
<line x1="150" y1="76" x2="158" y2="75" stroke="#7E4A1C" stroke-width="2"/>
<ellipse cx="142" cy="94" rx="16" ry="8" fill="#F4E8D2"/>
<g filter="url(#sh1)">
<circle cx="280" cy="70" r="26" fill="#E8F4F8"/>
<circle cx="280" cy="70" r="20" fill="#9DD7E8"/>
<ellipse cx="275" cy="64" rx="6" ry="3" fill="#FFFFFF" fill-opacity=".6" transform="rotate(-30 275 64)"/>
<line x1="285" y1="46" x2="305" y2="28" stroke="#48B4D4" stroke-width="3" stroke-linecap="round"/>
</g>
</svg>`)}`;

export const DINNER_SVG = `data:image/svg+xml;base64,${btoa(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice">
<defs>
<linearGradient id="bg2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4A342B"/><stop offset="1" stop-color="#2D1D16"/></linearGradient>
<radialGradient id="pl2" cx=".4" cy=".35" r=".8"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#E2DBD0"/></radialGradient>
<filter id="sh2" x="-20%" y="-20%" width="150%" height="150%"><feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#000" flood-opacity=".35"/></filter>
</defs>
<rect width="400" height="140" fill="url(#bg2)"/>
<g filter="url(#sh2)">
<circle cx="140" cy="70" r="54" fill="url(#pl2)"/>
<circle cx="140" cy="70" r="46" fill="none" stroke="#D3C9BC" stroke-width="1.5"/>
</g>
<g transform="rotate(-12 140 68)">
<rect x="110" y="50" width="46" height="26" rx="8" fill="#EE6B4D"/>
<line x1="118" y1="50" x2="114" y2="76" stroke="#C94426" stroke-width="2"/>
<line x1="126" y1="50" x2="122" y2="76" stroke="#C94426" stroke-width="2"/>
<line x1="134" y1="50" x2="130" y2="76" stroke="#C94426" stroke-width="2"/>
<line x1="142" y1="50" x2="138" y2="76" stroke="#C94426" stroke-width="2"/>
<line x1="112" y1="56" x2="152" y2="56" stroke="#FF9C82" stroke-width="1.5"/>
<line x1="112" y1="64" x2="152" y2="64" stroke="#FF9C82" stroke-width="1.5"/>
</g>
<circle cx="166" cy="56" r="10" fill="#F4CF38"/>
<circle cx="166" cy="56" r="7.5" fill="#FFF385"/>
<rect x="105" y="82" width="46" height="4.5" rx="2" fill="#588B35" transform="rotate(8 128 84)"/>
<rect x="108" y="88" width="44" height="4.5" rx="2" fill="#477328" transform="rotate(6 130 90)"/>
<rect x="112" y="94" width="40" height="4" rx="2" fill="#669E40" transform="rotate(4 132 96)"/>
<rect x="156" y="74" width="8" height="8" rx="2" fill="#E87C24"/>
<rect x="166" y="80" width="8" height="8" rx="2" fill="#D46A14"/>
<rect x="158" y="86" width="7" height="7" rx="2" fill="#E87C24"/>
<g filter="url(#sh2)">
<circle cx="280" cy="70" r="26" fill="#F4EDE6" fill-opacity=".3"/>
<circle cx="280" cy="70" r="20" fill="#751A2B"/>
<ellipse cx="274" cy="65" rx="5" ry="2.5" fill="#FFFFFF" fill-opacity=".4" transform="rotate(-25 274 65)"/>
</g>
</svg>`)}`;

export const SNACKS_SVG = `data:image/svg+xml;base64,${btoa(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 140" preserveAspectRatio="xMidYMid slice">
<defs>
<linearGradient id="bg3" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FCEEE6"/><stop offset="1" stop-color="#EED3C5"/></linearGradient>
<radialGradient id="pl3" cx=".4" cy=".35" r=".8"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#EDE7DE"/></radialGradient>
<filter id="sh3" x="-20%" y="-20%" width="150%" height="150%"><feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#000" flood-opacity=".18"/></filter>
</defs>
<rect width="400" height="140" fill="url(#bg3)"/>
<g filter="url(#sh3)">
<circle cx="140" cy="70" r="54" fill="url(#pl3)"/>
<circle cx="140" cy="70" r="46" fill="none" stroke="#E2DACF" stroke-width="1.5"/>
</g>
<g transform="rotate(-15 120 62)">
<path d="M106 50 q16 -6 24 10 q-10 16 -24 6 z" fill="#D9383A"/>
<path d="M109 52 q12 -4 18 8 q-8 12 -18 4 z" fill="#FFF8E7"/>
</g>
<g transform="rotate(25 152 64)">
<path d="M142 52 q16 -6 24 10 q-10 16 -24 6 z" fill="#E54749"/>
<path d="M145 54 q12 -4 18 8 q-8 12 -18 4 z" fill="#FFF8E7"/>
</g>
<ellipse cx="120" cy="84" rx="7" ry="4" fill="#9B6235" transform="rotate(30 120 84)"/>
<ellipse cx="134" cy="88" rx="7" ry="4" fill="#87532B" transform="rotate(-20 134 88)"/>
<ellipse cx="148" cy="84" rx="7" ry="4" fill="#9B6235" transform="rotate(15 148 84)"/>
<g filter="url(#sh3)">
<circle cx="280" cy="70" r="28" fill="#FFFFFF"/>
<circle cx="280" cy="70" r="23" fill="#FFF9F2"/>
<circle cx="274" cy="66" r="4.5" fill="#433F78"/>
<circle cx="284" cy="64" r="4" fill="#C92D4B"/>
<circle cx="280" cy="74" r="4" fill="#433F78"/>
<path d="M272 72 q8 8 16 0" stroke="#E5A629" stroke-width="2" fill="none"/>
</g>
</svg>`)}`;

export const MEAL_ART = [
  BREAKFAST_SVG,
  LUNCH_SVG,
  DINNER_SVG,
  SNACKS_SVG,
];

// Curated high-resolution appetizing food plate images
export const MEAL_DISHES = [
  // 0: Breakfast dishes (Eggs & avocado toast, Berry oatmeal, Fresh coffee)
  [
    'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=160&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517673132405-a56a62b18caf?w=160&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=160&auto=format&fit=crop&q=80',
  ],
  // 1: Lunch dishes (Grilled chicken bowl, Quinoa salad, Steamed vegetables)
  [
    'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=160&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=160&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=160&auto=format&fit=crop&q=80',
  ],
  // 2: Dinner dishes (Salmon fillet, Roasted sweet potatoes, Grilled asparagus)
  [
    'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=160&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=160&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1506084868230-bb9d95c24759?w=160&auto=format&fit=crop&q=80',
  ],
  // 3: Snacks dishes (Greek yogurt berries, Almonds nuts, Crisp apple)
  [
    'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=160&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1508746829417-e6f548d8d6ed?w=160&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=160&auto=format&fit=crop&q=80',
  ],
];
