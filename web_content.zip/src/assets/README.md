Place icon.png (512x512) and splash.png here. Run `npx @capacitor/assets generate` to create Android resources.
