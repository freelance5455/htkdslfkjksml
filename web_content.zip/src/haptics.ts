/**
 * Mobile Haptics Vibration Engine
 * Uses navigator.vibrate when available on Android and mobile devices.
 */

class HapticsEngine {
  private isEnabled: boolean = true;

  constructor() {
    try {
      const saved = localStorage.getItem('color_rush_haptics_enabled');
      if (saved !== null) {
        this.isEnabled = JSON.parse(saved);
      }
    } catch {
      this.isEnabled = true;
    }
  }

  public getEnabled(): boolean {
    return this.isEnabled;
  }

  public setEnabled(enabled: boolean): void {
    this.isEnabled = enabled;
    try {
      localStorage.setItem('color_rush_haptics_enabled', JSON.stringify(enabled));
    } catch {
      // ignore
    }
  }

  public toggle(): boolean {
    this.setEnabled(!this.isEnabled);
    return this.isEnabled;
  }

  private canVibrate(): boolean {
    return this.isEnabled && typeof navigator !== 'undefined' && 'vibrate' in navigator;
  }

  /**
   * Crisp micro-tap for correct answers
   */
  public tap(): void {
    if (!this.canVibrate()) return;
    try {
      navigator.vibrate(15);
    } catch {
      // ignore
    }
  }

  /**
   * Sparkling rhythmic vibration for Golden Bonus
   */
  public golden(): void {
    if (!this.canVibrate()) return;
    try {
      navigator.vibrate([20, 25, 35, 20, 45]);
    } catch {
      // ignore
    }
  }

  /**
   * High energy pulse for Fever Mode activation
   */
  public fever(): void {
    if (!this.canVibrate()) return;
    try {
      navigator.vibrate([35, 25, 35, 25, 50]);
    } catch {
      // ignore
    }
  }

  /**
   * Milestone combo reached
   */
  public combo(): void {
    if (!this.canVibrate()) return;
    try {
      navigator.vibrate([25, 20, 30]);
    } catch {
      // ignore
    }
  }

  /**
   * Coin collection tap
   */
  public coin(): void {
    if (!this.canVibrate()) return;
    try {
      navigator.vibrate(18);
    } catch {
      // ignore
    }
  }

  /**
   * Strong alert pattern for Game Over / Wrong Tap
   */
  public error(): void {
    if (!this.canVibrate()) return;
    try {
      navigator.vibrate([90, 40, 120]);
    } catch {
      // ignore
    }
  }

  /**
   * Catastrophic Bomb Detonation vibration
   */
  public bomb(): void {
    if (!this.canVibrate()) return;
    try {
      navigator.vibrate([140, 40, 180]);
    } catch {
      // ignore
    }
  }
}

export const hapticsManager = new HapticsEngine();
