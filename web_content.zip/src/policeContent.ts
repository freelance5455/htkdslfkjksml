export type Tone = 'info' | 'warning' | 'danger' | 'success';

export type ContentBlock =
  | { type: 'paragraph'; text: string }
  | { type: 'callout'; tone: Tone; title: string; text: string }
  | { type: 'quote'; title?: string; text: string }
  | { type: 'bullets'; items: string[] }
  | { type: 'steps'; items: Array<{ title: string; text: string }> }
  | { type: 'table'; headers: string[]; rows: string[][] }
  | { type: 'decision'; items: Array<{ if: string; then: string; otherwise?: string }> }
  | { type: 'roleplay'; lines: string[] };

export interface DocumentSection {
  title: string;
  blocks: ContentBlock[];
}

export interface PolicePage {
  id: string;
  title: string;
  category: string;
  summary: string;
  jurisdiction?: string;
  sections: DocumentSection[];
}

export interface MenuSection {
  title: string;
  icon: string;
  items: Array<{ id: string; label: string }>;
}

export const menuSections: MenuSection[] = [
  {
    title: 'Start Here',
    icon: 'guide',
    items: [
      { id: 'beginner-guide', label: 'New Officer Guide' },
      { id: 'jurisdictions', label: 'UK Legal Jurisdictions' },
      { id: 'force-directory', label: 'UK Police Force Directory' },
      { id: 'ranks-and-roles', label: 'Ranks, Roles & Units' },
      { id: 'start-duty', label: 'Start of Duty' },
      { id: 'radio-control', label: 'Radio & Control Room' },
      { id: 'roleplay-actions', label: 'Roleplay Action Text' },
      { id: 'quick-reference', label: 'Printable Quick Reference' },
    ],
  },
  {
    title: 'Codes & Communications',
    icon: 'radio',
    items: [
      { id: 'state-codes', label: 'State Codes (0-16)' },
      { id: 'call-grades', label: 'Call Grades (I/S/E/R)' },
      { id: 'warning-markers', label: 'PNC Warning Markers' },
      { id: 'ic-codes', label: 'IC Identity Codes' },
      { id: 'common-phrases', label: 'Common Phrases & Scripts' },
    ],
  },
  {
    title: 'Law & Police Powers',
    icon: 'scales',
    items: [
      { id: 'pace-caution', label: 'PACE Caution (Not Miranda)' },
      { id: 'arrest-procedure', label: 'Arrest Procedure' },
      { id: 'stop-search', label: 'Stop & Search' },
      { id: 'entry-search', label: 'Entry & Premises Search' },
      { id: 'use-of-force', label: 'Use of Force' },
      { id: 'public-order', label: 'Public Order Powers' },
      { id: 'road-traffic-powers', label: 'Road Traffic Powers' },
    ],
  },
  {
    title: 'Core Procedures',
    icon: 'clipboard',
    items: [
      { id: 'incident-response', label: 'Incident Response' },
      { id: 'scene-management', label: 'Crime Scene Management' },
      { id: 'evidence-statements', label: 'Evidence & Statements' },
      { id: 'custody-booking', label: 'Custody & Booking In' },
      { id: 'victim-witness', label: 'Victims & Witnesses' },
      { id: 'intelligence', label: 'Intelligence Reports' },
    ],
  },
  {
    title: 'Operational Scenarios',
    icon: 'response',
    items: [
      { id: 'missing-person', label: 'Missing Person' },
      { id: 'domestic-abuse', label: 'Domestic Abuse' },
      { id: 'mental-health', label: 'Mental Health Incident' },
      { id: 'safeguarding', label: 'Safeguarding' },
      { id: 'sudden-death', label: 'Sudden Death' },
      { id: 'road-collision', label: 'Road Traffic Collision' },
      { id: 'burglary', label: 'Burglary in Progress' },
      { id: 'assault', label: 'Assault & Public Place Violence' },
      { id: 'shoplifting', label: 'Shoplifting' },
      { id: 'suspicious-vehicle', label: 'Suspicious Vehicle' },
    ],
  },
  {
    title: 'Equipment',
    icon: 'equipment',
    items: [
      { id: 'bwv', label: 'Body-Worn Video' },
      { id: 'personal-equipment', label: 'Personal Protective Equipment' },
      { id: 'restraints', label: 'Handcuffs & Restraints' },
      { id: 'defensive-equipment', label: 'Defensive Equipment' },
      { id: 'communications', label: 'Radio, MDT & Mobile Devices' },
      { id: 'traffic-evidence-kit', label: 'Traffic & Evidence Kit' },
    ],
  },
  {
    title: 'Policy & Standards',
    icon: 'policy',
    items: [
      { id: 'ethics-standards', label: 'Code of Ethics & Standards' },
      { id: 'information-management', label: 'Information Management' },
      { id: 'pursuits', label: 'Vehicle Pursuits' },
      { id: 'complaints-force', label: 'Complaints & Force Recording' },
      { id: 'equality-human-rights', label: 'Equality & Human Rights' },
    ],
  },
];

export const policePages: Record<string, PolicePage> = {
  'beginner-guide': {
    id: 'beginner-guide',
    title: 'New Officer Guide',
    category: 'Start Here',
    summary: 'A practical introduction to UK policing for new roleplay officers.',
    jurisdiction: 'UK overview; powers vary by jurisdiction',
    sections: [
      {
        title: 'Your First Priorities',
        blocks: [
          { type: 'paragraph', text: 'Your role is to **protect life, prevent crime, preserve evidence, investigate fairly and treat every person with dignity**. Do not begin with enforcement when communication, safeguarding or referral is more appropriate.' },
          { type: 'callout', tone: 'warning', title: 'Roleplay and training notice', text: 'This site is a roleplay and learning reference, not an operational authority. Real officers must follow current legislation, College of Policing guidance, authorised professional practice and local force policy.' },
          { type: 'bullets', items: ['Know which UK legal jurisdiction you are roleplaying in.', 'State your grounds and legal power clearly.', 'Use the National Decision Model before and during action.', 'Record decisions, force, searches, seizures and safeguarding concerns.', 'Request a supervisor when authority, risk or proportionality is unclear.'] },
        ],
      },
      {
        title: 'The Basic Incident Cycle',
        blocks: [
          { type: 'steps', items: [
            { title: 'Receive and acknowledge', text: 'Read the CAD log, identify grading, location, warnings, persons, vehicles and requested outcome.' },
            { title: 'Plan the approach', text: 'Consider threat, harm, risk, vulnerability, powers, PPE, backup and safe parking.' },
            { title: 'Arrive and update', text: 'Transmit arrival, activate BWV where appropriate and give an initial situation report.' },
            { title: 'Protect life and control risk', text: 'Separate parties, provide first aid, secure weapons, identify suspects and preserve exits.' },
            { title: 'Establish facts', text: 'Identify victims, witnesses and suspects; obtain first accounts; check systems and available footage.' },
            { title: 'Choose a lawful outcome', text: 'Arrest, voluntary attendance, report, warning, safeguarding referral, civil resolution or no further action.' },
            { title: 'Record and hand over', text: 'Complete notebook, crime report, use-of-force, search, seizure, safeguarding and custody records.' },
          ] },
        ],
      },
      {
        title: 'What If Decision Guide',
        blocks: [
          { type: 'decision', items: [
            { if: 'There is an immediate threat to life', then: 'Prioritise life-saving action, request emergency assistance, identify the threat and use only necessary and proportionate force.', otherwise: 'Slow the incident down, gather information and consider less intrusive options.' },
            { if: 'You suspect an offence but do not have enough facts', then: 'Separate accounts, preserve evidence, check systems and use investigative powers lawfully.', otherwise: 'Do not invent grounds or arrest merely to investigate.' },
            { if: 'A person is vulnerable', then: 'Adapt communication, consider an appropriate adult, interpreter, medical support and safeguarding referral.', otherwise: 'Continue to monitor for hidden vulnerability.' },
          ] },
          { type: 'roleplay', lines: ['- checks the incident log and notes the warning markers -', '- confirms the legal jurisdiction and available powers -', '- activates body-worn video before approaching -', '- identifies self and explains the reason for attendance -', '- records the decision and rationale in the electronic notebook -'] },
        ],
      },
    ],
  },

  jurisdictions: {
    id: 'jurisdictions',
    title: 'UK Legal Jurisdictions',
    category: 'Start Here',
    summary: 'The UK does not operate one single set of police powers.',
    jurisdiction: 'United Kingdom',
    sections: [
      {
        title: 'Four Nations, Three Main Systems',
        blocks: [
          { type: 'table', headers: ['Area', 'Main framework', 'Key point'], rows: [
            ['England and Wales', 'PACE 1984, Criminal Law Act 1967, common law and offence-specific statutes', 'PACE Codes A-G structure stop/search, detention, interviews and arrest necessity.'],
            ['Scotland', 'Criminal Justice (Scotland) Act 2016, common law and Scottish statutes', 'Different arrest, caution, detention and court terminology. PACE does not generally apply.'],
            ['Northern Ireland', 'PACE (Northern Ireland) Order 1989 and NI legislation', 'Similar concepts to England and Wales but use NI law, codes and local policy.'],
          ] },
          { type: 'callout', tone: 'danger', title: 'Do not mix powers', text: 'Do not quote PACE section 24 for a Police Scotland arrest, and do not give a US Miranda warning anywhere in UK policing.' },
        ],
      },
      {
        title: 'Common Terminology Differences',
        blocks: [
          { type: 'table', headers: ['Topic', 'England and Wales', 'Scotland'], rows: [
            ['Arrest basis', 'Reasonable grounds plus Code G necessity under PACE s24', 'Reasonable grounds to suspect an offence under the 2016 Act, subject to Scottish procedure'],
            ['Caution', 'PACE standard or restricted caution', 'Scottish caution; wording and solicitor rights differ'],
            ['Prosecution body', 'Crown Prosecution Service', 'Crown Office and Procurator Fiscal Service'],
            ['Custody lead', 'Custody officer', 'Custody sergeant / local Scottish procedure'],
          ] },
        ],
      },
    ],
  },

  'ranks-and-roles': {
    id: 'ranks-and-roles',
    title: 'Ranks, Roles and Specialist Units',
    category: 'Start Here',
    summary: 'Who does what in a UK police force.',
    sections: [
      {
        title: 'Police Ranks',
        blocks: [
          { type: 'table', headers: ['Rank', 'Typical responsibility'], rows: [
            ['Police Constable (PC)', 'Frontline response, neighbourhood, investigation and specialist roles.'],
            ['Sergeant (Sgt)', 'First-line supervision, briefing, incident oversight and staff welfare.'],
            ['Inspector (Insp)', 'Operational command, critical incidents, policy and performance.'],
            ['Chief Inspector (Ch Insp)', 'Area or department leadership and tactical command.'],
            ['Superintendent (Supt)', 'Senior operational leadership; often Silver command.'],
            ['Chief Superintendent', 'Basic command unit or major portfolio leadership.'],
            ['Chief officer ranks', 'Assistant Chief Constable/Commissioner and above; strategic command.'],
          ] },
        ],
      },
      {
        title: 'Common Units',
        blocks: [
          { type: 'table', headers: ['Unit', 'Function', 'Typical deployment'], rows: [
            ['Response policing', 'Immediate and priority calls, arrests, initial investigation', 'Mobile patrol and demand-led deployment'],
            ['Neighbourhood policing', 'Problem solving, community engagement and local intelligence', 'Dedicated ward or beat'],
            ['CID', 'Serious and complex investigations', 'Case-led; not routine patrol'],
            ['Roads policing', 'Fatal/serious collisions, pursuit, traffic enforcement and vehicle crime', 'Strategic roads and force-wide tasking'],
            ['Dog unit', 'Search, tracking, public order and suspect detention', 'Force-wide support'],
            ['Firearms unit', 'Armed response to firearms and high-threat incidents', 'Armed response vehicle patrol/standby'],
            ['Public order unit', 'Protests, disorder, events and method-of-entry support', 'Pre-planned or spontaneous deployment'],
            ['Safeguarding unit', 'Domestic abuse, child protection and vulnerable adults', 'Case-led specialist investigation'],
          ] },
        ],
      },
    ],
  },

  'start-duty': {
    id: 'start-duty',
    title: 'Start of Duty',
    category: 'Start Here',
    summary: 'A practical briefing, equipment and patrol checklist.',
    sections: [
      {
        title: 'Book On and Brief',
        blocks: [
          { type: 'steps', items: [
            { title: 'Report and book on', text: 'Attend in correct uniform, update duty status and confirm crewing.' },
            { title: 'Read briefing', text: 'Review wanted persons, missing people, vehicles, crime patterns, threat updates and operational orders.' },
            { title: 'Inspect PPE', text: 'Check radio, BWV, handcuffs, baton, incapacitant spray, first aid kit, torch, notebook and issued devices.' },
            { title: 'Check vehicle', text: 'Inspect damage, tyres, lights, emergency equipment, fuel, mileage, radio, MDT and vehicle inventory.' },
            { title: 'Confirm tasking', text: 'Know your call sign, talkgroup, patrol area, supervisor and priority task.' },
          ] },
          { type: 'callout', tone: 'warning', title: 'Equipment accountability', text: 'Record defects immediately. Do not carry defective, unsealed or out-of-date equipment. Follow local force armoury and issue procedures.' },
          { type: 'roleplay', lines: ['- books on duty and checks the force briefing -', '- signs out the vehicle keys and records the starting mileage -', '- checks the BWV battery and confirms the correct date and time -', '- performs a radio check with control -', '- updates the unit status to available for tasking -'] },
        ],
      },
    ],
  },

  'radio-control': {
    id: 'radio-control',
    title: 'Radio and Control Room Procedure',
    category: 'Start Here',
    summary: 'Clear radio messages, status updates and urgent assistance.',
    sections: [
      {
        title: 'Message Structure',
        blocks: [
          { type: 'quote', title: 'Routine format', text: 'Control, [call sign], [location/status], [message or request], over.' },
          { type: 'bullets', items: ['Listen before transmitting.', 'Use plain English and approved phonetics.', 'Do not broadcast unnecessary personal data.', 'Repeat addresses, registrations and safety-critical information.', 'Use the emergency button only for an immediate threat or urgent assistance under local policy.'] },
        ],
      },
      {
        title: 'Common Transmissions',
        blocks: [
          { type: 'roleplay', lines: ['"Control, Sierra Two One, mobile to the immediate at High Street, two officers, over."', '"Control, Sierra Two One, on scene. One male detained; no further units required at present, over."', '"Control, Sierra Two One, urgent assistance. Male armed with a knife, junction of King Street and Market Road. Officers withdrawing to cover, over."', '"Control, Sierra Two One, one under arrest for assault. Conveying to Central Custody, over."'] },
          { type: 'callout', tone: 'danger', title: 'Urgent assistance', text: 'Give your identity, exact location, threat, suspect description, weapons and direction of travel. Do not fill the channel with a long narrative.' },
        ],
      },
    ],
  },

  'roleplay-actions': {
    id: 'roleplay-actions',
    title: 'Roleplay Action Text',
    category: 'Start Here',
    summary: 'Short, realistic action text for UK police roleplay.',
    sections: [
      {
        title: 'Format and Principles',
        blocks: [
          { type: 'paragraph', text: 'Use **short, observable actions**. Do not decide another character\'s reaction, guarantee that a search succeeds or make force automatically effective.' },
          { type: 'roleplay', lines: ['- switches on the body-worn camera and announces recording -', '- places the high-visibility jacket over the body armour -', '- checks the address against the incident log -', '- approaches from a safe angle with hands visible -', '- identifies self and explains the reason for speaking -'] },
        ],
      },
      {
        title: 'Stop, Search and Arrest',
        blocks: [
          { type: 'roleplay', lines: ['- keeps a safe reactionary gap and requests the person\'s hands remain visible -', '- explains the search grounds and legal power using GOWISELY -', '- asks the person whether they have any sharp objects before beginning -', '- conducts a systematic outer-clothing search -', '- places the recovered item into a clean evidence bag -', '- informs the suspect that they are under arrest and gives the reason -', '- delivers the PACE caution clearly and checks understanding -', '- applies handcuffs using only the force considered necessary -', '- double-locks the cuffs and checks circulation -'] },
        ],
      },
      {
        title: 'Evidence and Custody',
        blocks: [
          { type: 'roleplay', lines: ['- marks the exhibit bag with time, date, location and exhibit reference -', '- records the significant statement in the electronic notebook -', '- presents the detainee to the custody officer -', '- explains the grounds, necessity, force used and risks -', '- transfers property and exhibits according to custody procedure -'] },
        ],
      },
    ],
  },

  'state-codes': {
    id: 'state-codes',
    title: 'State Codes (0-16)',
    category: 'Codes & Communications',
    summary: 'Unit status codes transmitted by radio, MDT or CAD to keep control informed of officer availability and location.',
    sections: [
      {
        title: 'When and How to Use State Codes',
        blocks: [
          { type: 'paragraph', text: 'State codes tell the control room exactly what your unit is doing. Update your state **every time your status changes**, and always give your state alongside your call sign. Control manages resourcing, coverage and officer safety using these updates, so an inaccurate state puts you and other units at risk.' },
          { type: 'callout', tone: 'danger', title: 'State 0 - Emergency', text: 'State 0 (Panic / Emergency Assistance) suspends routine channel traffic and triggers an urgent-assistance response. Only activate for a genuine, immediate threat to officer or public safety. Accidental activation must be cancelled immediately and confirmed by voice message.' },
          { type: 'roleplay', lines: ['"Control, Sierra One Two, State 2 mobile, beginning patrol of the town centre, over."', '"Control, Sierra One Two, State 5 responding to the Immediate at High Street, over."', '"Control, Sierra One Two, State 6 at scene, over."', '- presses the emergency button on the radio handset and gives their location -'] },
        ],
      },
      {
        title: 'Full State Code Reference',
        blocks: [
          { type: 'table', headers: ['State', 'Name', 'Meaning and rules'], rows: [
            ['0', 'Panic / Emergency Assistance', 'Officer requires urgent assistance. Routine traffic stops, control confirms location and dispatches nearest units. Only for immediate threat to safety.'],
            ['1', 'On Duty', 'Officer is on duty and ready for deployment after briefing and equipment checks.'],
            ['2', 'On Patrol', 'Unit is mobile or on foot patrol and available for deployment.'],
            ['3', 'At Station (Available)', 'At the station and available for immediate tasking.'],
            ['4', 'On Break', 'Unit is on a refreshment break. May be interrupted for genuine emergencies under local policy.'],
            ['5', 'En Route to Incident', 'Assigned and travelling to an incident. Combined with the call grade to determine response style.'],
            ['6', 'At Scene', 'Unit has arrived. Control starts scene-duration monitoring.'],
            ['7', 'Committed - Deployable', 'Committed to a task but can be re-deployed if a higher-priority incident emerges.'],
            ['8', 'Committed - Not Deployable', 'Committed to a task and cannot be diverted. Control must not reassign this unit.'],
            ['9', 'Prisoner Escort Needed', 'A detainee is awaiting transport. Control dispatches a Prisoner Transport Vehicle (PTV).'],
            ['10', 'At Court', 'Officer is engaged at court and temporarily unavailable.'],
            ['11', 'Off Duty', 'End of shift. Officer has stood down and is no longer deployable.'],
            ['12', 'Confidential Message', 'Unit requires a private or sensitive channel; control contacts the officer directly.'],
            ['13', 'Non-Urgent Call Back', 'Unit requests control return the call when time allows; no immediate incident priority.'],
            ['14', 'Urgent Call Back', 'Unit requires control to contact it urgently; does not meet State 0 criteria but is time-critical.'],
            ['15', 'Received', 'Message received and understood; used as an acknowledgement.'],
            ['16', 'Repeat', 'Request for the last transmission to be repeated.'],
          ] },
        ],
      },
      {
        title: 'Decision Guide',
        blocks: [
          { type: 'decision', items: [
            { if: 'You or a member of the public faces an immediate threat', then: 'Activate State 0, give your exact location, threat and suspect direction, and wait for the response.', otherwise: 'Use the correct routine state and keep the channel clear.' },
            { if: 'You are dealing with a task but could still be diverted', then: 'Use State 7 so control knows you remain deployable.', otherwise: 'Use State 8 when the task genuinely prevents redeployment, such as escorting a detainee.' },
            { if: 'You have made an arrest and need transport', then: 'Update to State 9 and control will task a PTV.', otherwise: 'Continue with the lawful next step in custody planning.' },
            { if: 'Control\'s last message was unclear', then: 'Transmit State 16 (Repeat) rather than guessing.', otherwise: 'Acknowledge with State 15 (Received).' },
          ] },
        ],
      },
    ],
  },

  'call-grades': {
    id: 'call-grades',
    title: 'Call Grades (I / S / E / R)',
    category: 'Codes & Communications',
    summary: 'Incident grading determines the response style, response time and use of emergency equipment.',
    sections: [
      {
        title: 'The Four Grades',
        blocks: [
          { type: 'paragraph', text: 'Grading is applied by the call taker or dispatcher and drives the response time. Officers still apply the **National Decision Model** on arrival; a grade is not permission to take unnecessary risks.' },
          { type: 'table', headers: ['Grade', 'Name', 'Standard', 'Response time', 'Response style'], rows: [
            ['I', 'Immediate', 'Immediate police presence will have a significant impact on the outcome: danger to life, serious threat of violence, serious injury or serious damage to property', '15 minutes', 'Sirens and emergency lighting system (ELS); response-trained drivers only'],
            ['S', 'Significant', 'A degree of importance or urgency in the initial police action, but an emergency response is not required', '60 minutes', 'Emergency lighting only where authorised; no sirens as routine'],
            ['E', 'Extended', 'Police attendance is required but an emergency response is not justified', '48 hours', 'Normal road driving; no ELS or sirens'],
            ['R', 'Referred', 'Police attendance is not required; the caller is resolved or signposted by the call handler', 'Not applicable', 'Telephone or desk-based resolution'],
          ] },
          { type: 'callout', tone: 'info', title: 'Arriving late on a grade', text: 'If traffic, terrain or resource pressure delays arrival beyond the target, inform control and update the log; do not increase risk to compensate.' },
        ],
      },
      {
        title: 'Decision Guide',
        blocks: [
          { type: 'decision', items: [
            { if: 'The incident is graded Immediate (I)', then: 'Acknowledge, confirm State 5, activate authorised warning equipment and drive to the standard of your training.', otherwise: 'Drive normally and prioritise arrival risk over speed.' },
            { if: 'Circumstances change en route and the threat ends', then: 'Request re-grading and stand down warning equipment when safe.' },
            { if: 'On arrival you find the incident has escalated', then: 'Update the log, request re-grade and additional or specialist units, and state the exact risk supporting the request.', otherwise: 'Continue and record your reason for retaining the grade.' },
          ] },
          { type: 'roleplay', lines: ['"Control, Sierra One Two, State 5 responding to the I-grade at Victoria Road, over."', '"Control, Sierra One Two, arriving at the S-grade. Incident has stabilised. Recommend downgrade to E, over."', '- checks the call grade and reads the dispatcher notes before setting off -'] },
        ],
      },
    ],
  },

  'warning-markers': {
    id: 'warning-markers',
    title: 'PNC Warning Markers',
    category: 'Codes & Communications',
    summary: 'Police National Computer markers that flag likely risk before officers engage a person or address.',
    sections: [
      {
        title: 'What Warning Markers Do',
        blocks: [
          { type: 'paragraph', text: 'Warning markers are short codes attached to person, address and vehicle records. They **assist threat assessment**; they are not proof, and they never justify action alone. Approach every encounter professionally and reassess against what you can see in front of you.' },
          { type: 'table', headers: ['Marker', 'Name', 'Indicates'], rows: [
            ['FI', 'Firearms', 'May possess or have access to firearms'],
            ['WE', 'Weapons', 'May possess weapons'],
            ['VI', 'Violent', 'May resort to violent behaviour'],
            ['CO', 'Contagious', 'May present a contamination risk as a carrier of disease, for example COVID-19'],
            ['ES', 'Escaper', 'May attempt to escape from custody'],
            ['AG', 'Alleges', 'May make false allegations against police'],
            ['AT', 'Ailment', 'May suffer a medical condition or require medication'],
            ['MN', 'Mental', 'Is suffering from a mental disorder'],
            ['IM', 'M/Impers', 'May impersonate or present as male'],
            ['IF', 'F/Impers', 'May impersonate or present as female'],
          ] },
          { type: 'callout', tone: 'warning', title: 'Community-specific markers', text: 'Certain additional markers are excluded here because of their nature and your roleplay community\'s rules. Apply the marker system only as your community\'s command and platform rules allow.' },
        ],
      },
      {
        title: 'How to Apply Markers in Practice',
        blocks: [
          { type: 'decision', items: [
            { if: 'FI or WE is present on an address or person', then: 'Confirm the marker context, keep a safe position, request support and consider whether armed units are proportionate before contact.', otherwise: 'Complete standard threat assessment and proceed with normal precautions.' },
            { if: 'ES is present', then: 'Control exits, use lawful detention promptly where grounds exist and inform custody of the risk.', otherwise: 'Continue supervision proportional to the person\'s behaviour.' },
            { if: 'AT or MN is present', then: 'Plan for medication, healthcare and communication adjustments, and treat welfare as a priority.', otherwise: 'Still screen every encounter for hidden vulnerability.' },
            { if: 'FI/WE/VI is on a property and entry is planned', then: 'Brief the team, select PPE, plan entry method and verify the record is current before forcing entry.', otherwise: 'Proceed with a structured knock/announce and containment plan.' },
          ] },
          { type: 'roleplay', lines: ['- runs the address history and notes the FI and VI markers -', '- updates control with the markers present and requests a second unit -', '- confirms the warning markers with the custody officer on booking in -'] },
        ],
      },
    ],
  },

  'ic-codes': {
    id: 'ic-codes',
    title: 'IC Identity Codes',
    category: 'Codes & Communications',
    summary: 'Historical identity codes used on radio to give a concise, objective description of a person\'s perceived ethnicity.',
    sections: [
      {
        title: 'Code Reference',
        blocks: [
          { type: 'paragraph', text: 'IC (Identity Code) codes are spoken with other descriptive detail such as approximate age, height, build, clothing and direction of travel. They describe **what was observed**, not assumed nationality. Use the code only where identification of a person is operationally necessary.' },
          { type: 'table', headers: ['Code', 'Description', 'Examples'], rows: [
            ['IC1', 'White-skinned European', 'English, Scottish, Welsh, French, German, Swedish, Norwegian, Polish, Russian'],
            ['IC2', 'Dark-skinned European', 'Greek, Cypriot, Turkish, Sicilian, Sardinian, Spanish, Italian'],
            ['IC3', 'African-Caribbean', 'West Indian, Guyanese, Black African, including those with a light complexion'],
            ['IC4', 'South Asian', 'Indian, Pakistani, Bangladeshi or Sri Lankan'],
            ['IC5', 'South-East / East Asian', 'Malaysian, Burmese, Filipino, Mongolian'],
            ['IC6', 'Arabian / North African', 'Algerian, Tunisian, Moroccan and North African'],
            ['IC0 / IC7 / IC9', 'Unknown', 'Used where ethnicity cannot be confidently assessed at the time'],
          ] },
          { type: 'callout', tone: 'warning', title: 'Fair use only', text: 'Modern policing increasingly records self-defined and officer-defined ethnicity separately (18+1 categories). IC codes remain in informal and roleplay use for radio descriptions, but must never be used to stereotype, justify suspicion or select a person for action.' },
        ],
      },
      {
        title: 'Building a Complete Description',
        blocks: [
          { type: 'bullets', items: ['Clothing, distinguishing marks, tattoos, footwear and headgear', 'Direction and manner of travel, on foot or vehicle description', 'Associated persons, vehicles and last known actions', 'Time since lost sight'] },
          { type: 'roleplay', lines: ['"Control, Sierra One Two, suspect is a male, IC4, approximately 25, medium build, black hooded top, heading south on King Street, over."', '- records the descriptive code alongside clothing and direction of travel -'] },
        ],
      },
    ],
  },

  'common-phrases': {
    id: 'common-phrases',
    title: 'Common Phrases and Scripts',
    category: 'Codes & Communications',
    summary: 'Standard, professional wording for introductions, stops, arrests, searches and custody handovers.',
    sections: [
      {
        title: 'Professional Introduction',
        blocks: [
          { type: 'quote', title: 'Introduction', text: 'Hello. I am [rank] [surname] with the Metropolitan Police Service, based at New Scotland Yard. My collar number is [number].' },
          { type: 'bullets', items: ['Introduce rank, name, force and station before asking questions.', 'Address people formally where appropriate and explain the reason for contact in plain language.', 'Never rely on force identity alone; your conduct establishes credibility.'] },
        ],
      },
      {
        title: 'Standard Stop and Arrest Scripts',
        blocks: [
          { type: 'quote', title: 'Vehicle stop', text: 'Hello, I have stopped you because [reason]. May I see your driving licence and confirm who owns the vehicle?' },
          { type: 'quote', title: 'Stop and search', text: 'You are being detained for the purpose of a search. My grounds are [grounds]. I am searching for [object]. My name is [name], I am stationed at [station]. The legal power I am using is [power]. You are entitled to a copy of the search record.' },
          { type: 'quote', title: 'Arrest', text: 'You are under arrest for [offence]. My grounds are [facts]. Your arrest is necessary for [Code G reason].' },
          { type: 'quote', title: 'PACE caution', text: 'You do not have to say anything. But it may harm your defence if you do not mention when questioned something which you later rely on in court. Anything you do say may be given in evidence.' },
          { type: 'quote', title: 'Search after arrest', text: 'You will now be searched under PACE: Section 32. Would you like a different officer to search you?' },
          { type: 'quote', title: 'Transport warning', text: 'This vehicle has been searched prior to your arrest. Anything found in it afterwards will be deemed as yours. This vehicle is also fitted with audio and video recording, so anything you do or say may be captured and used in evidence.' },
          { type: 'callout', tone: 'info', title: 'Explain next steps', text: 'After every decision, tell the person what will happen next and estimate a timescale. Clear explanation reduces escalation and complaints.' },
        ],
      },
    ],
  },

  'pace-caution': {
    id: 'pace-caution',
    title: 'PACE Caution: The UK Position',
    category: 'Law & Police Powers',
    summary: 'The correct caution in England and Wales, and why it is not Miranda rights.',
    jurisdiction: 'England and Wales unless stated',
    sections: [
      {
        title: 'Standard Caution',
        blocks: [
          { type: 'callout', tone: 'danger', title: 'Not Miranda rights', text: '"Miranda rights" are a United States concept. In England and Wales, use the PACE caution. Scotland and Northern Ireland have their own legal frameworks and approved wording.' },
          { type: 'quote', title: 'Standard England and Wales caution', text: 'You do not have to say anything. But it may harm your defence if you do not mention when questioned something which you later rely on in court. Anything you do say may be given in evidence.' },
          { type: 'paragraph', text: 'Caution a person when there are grounds to suspect an offence and you intend to ask questions about it, or on arrest. Record the exact time, place, persons present and any reply.' },
        ],
      },
      {
        title: 'Restricted Caution',
        blocks: [
          { type: 'quote', title: 'After charge or when a decision to prosecute has been made', text: 'You do not have to say anything, but anything you do say may be given in evidence.' },
          { type: 'decision', items: [
            { if: 'The person does not appear to understand', then: 'Repeat in simple language, check understanding and consider vulnerability, interpreter or appropriate adult requirements.', otherwise: 'Continue and record that the caution was understood.' },
            { if: 'The person makes a significant statement', then: 'Record the words as accurately as possible and invite them to read/sign or otherwise confirm the record.', otherwise: 'Continue the lawful procedure without prompting an account unnecessarily.' },
          ] },
        ],
      },
      {
        title: 'Other UK Jurisdictions',
        blocks: [
          { type: 'table', headers: ['Jurisdiction', 'Position'], rows: [
            ['Scotland', 'Use the approved Scottish caution and Criminal Justice (Scotland) Act procedure. A commonly used form begins: "You are not obliged to say anything..." Confirm current Police Scotland wording and solicitor-rights process.'],
            ['Northern Ireland', 'Use PACE (Northern Ireland) Order procedure and current PSNI wording/policy. Do not assume every England and Wales Code applies unchanged.'],
          ] },
          { type: 'roleplay', lines: ['- informs the suspect they are under arrest and states the offence -', '- gives the PACE caution slowly and clearly -', '- asks the suspect to confirm that they understand -', '- records the caution and reply in the electronic notebook -'] },
        ],
      },
    ],
  },

  'arrest-procedure': {
    id: 'arrest-procedure',
    title: 'Arrest Procedure',
    category: 'Law & Police Powers',
    summary: 'Grounds, necessity, caution, search, transport and custody handover.',
    jurisdiction: 'PACE section 24 and Code G: England and Wales',
    sections: [
      {
        title: 'The Two-Part Test',
        blocks: [
          { type: 'paragraph', text: 'A lawful section 24 arrest requires **reasonable grounds to suspect involvement in an offence** and **reasonable grounds to believe arrest is necessary**. Suspicion alone is not enough if voluntary attendance or another practical option meets the need.' },
          { type: 'table', headers: ['Code G necessity', 'Example'], rows: [
            ['Ascertain name', 'The person refuses details or details appear false.'],
            ['Ascertain address', 'No reliable address can be established.'],
            ['Prevent physical injury', 'Continuing violence or credible immediate risk.'],
            ['Prevent loss or damage to property', 'Risk of further damage or disposal.'],
            ['Prevent offence against public decency', 'Members of public cannot reasonably avoid the conduct.'],
            ['Protect child or vulnerable person', 'Immediate safeguarding need.'],
            ['Prompt and effective investigation', 'Interview, evidence recovery, prevent collusion or secure forensic evidence.'],
            ['Prevent disappearance', 'Real risk the suspect will evade prosecution.'],
          ] },
        ],
      },
      {
        title: 'Arrest Sequence',
        blocks: [
          { type: 'steps', items: [
            { title: 'Control immediate risk', text: 'Position safely, request support, identify weapons and use lawful force only if needed.' },
            { title: 'State the arrest', text: 'Tell the person they are under arrest.' },
            { title: 'State the offence and grounds', text: 'Use plain language: what offence and the essential facts creating suspicion.' },
            { title: 'State necessity', text: 'Explain the specific Code G reason, not a generic phrase.' },
            { title: 'Caution', text: 'Give the standard caution and check understanding.' },
            { title: 'Record significant words', text: 'Note unsolicited comments and the reply to caution.' },
            { title: 'Search if lawful', text: 'Consider PACE section 32 and explain the power; seize relevant items lawfully.' },
            { title: 'Transport without unnecessary delay', text: 'Monitor welfare and communicate risk to control and custody.' },
            { title: 'Present to custody', text: 'Give grounds, necessity, circumstances, force, risks, medical needs, property and exhibits.' },
          ] },
          { type: 'decision', items: [
            { if: 'Arrest is necessary and proportionate', then: 'Arrest, caution, search where lawful and convey to a designated police station.', otherwise: 'Consider voluntary attendance, summons/report, community resolution or further investigation.' },
            { if: 'The person becomes medically unwell', then: 'Prioritise medical assessment and request ambulance support; tell custody/control.', otherwise: 'Continue welfare observations during transport.' },
          ] },
          { type: 'roleplay', lines: ['"You are under arrest on suspicion of assault. The grounds are the victim\'s account and the CCTV I have viewed. Your arrest is necessary to allow a prompt and effective investigation and to prevent further injury."', '- gives the PACE caution and checks understanding -', '- applies handcuffs, double-locks them and checks fit -', '- conducts a section 32 search and records all property -'] },
        ],
      },
      {
        title: 'Step 1: Cause',
        blocks: [
          { type: 'paragraph', text: 'When placing the person in handcuffs, state the arrest immediately. **Do not apply restraints silently** - the person must know they are deprived of their liberty and why.' },
          { type: 'quote', title: 'Arrest declaration', text: 'You are under arrest for [offence].' },
          { type: 'paragraph', text: 'Log the arrest in your community\'s incident logging or action record as soon as practicable, noting time, offence, grounds and necessity.' },
          { type: 'roleplay', lines: ['"You are under arrest for theft by shoplifting."', '- logs the arrest as an action in the duty system -'] },
        ],
      },
      {
        title: 'Step 2: Police Caution',
        blocks: [
          { type: 'quote', title: 'Standard caution', text: 'You do not have to say anything. But it may harm your defence if you do not mention when questioned something which you later rely on in court. Anything you do say may be given in evidence.' },
          { type: 'paragraph', text: 'Give the caution once, slowly, and check that the detainee understands. **Record anything said in reply**, exactly as spoken, as this may become a significant statement.' },
        ],
      },
      {
        title: 'Step 3: Search After Arrest (PACE Section 32)',
        blocks: [
          { type: 'quote', title: 'Section 32 search', text: 'You will now be searched under PACE: Section 32. Would you like a different officer to search you?' },
          { type: 'callout', tone: 'info', title: 'Different officer requests', text: 'If the detainee requests a different officer - most commonly for privacy reasons - transmit the request to control specifying the type of officer required, keep the suspect detained until they arrive, and if nobody is available explain that to the suspect before continuing the search.' },
          { type: 'steps', items: [
            { title: 'Wear the correct equipment', text: 'Gloves at minimum; eye protection and mask where a CO marker or risk exists.' },
            { title: 'Ask the safety question', text: '"Is there anything that may stick, stab or poke me in my search? If so, please identify them for me."' },
            { title: 'If they identify hazards', text: 'Locate and remove those items first with caution and place them directly into evidence bags.' },
            { title: 'Conduct the search', text: 'Remove anything that could assist escape or cause harm and place each item in its own labelled evidence bag.' },
            { title: 'Firearms', text: 'Identify the firearm without sweeping your colleagues, remove it from the person, request an armed officer if necessary and place it in a secure case as evidence.' },
            { title: 'Secure property', text: 'Place all confiscated bagged items securely in your vehicle.' },
            { title: 'Record everything', text: 'Document time, power, items seized and the detainee\'s replies.' },
          ] },
        ],
      },
      {
        title: 'Section 4: Transport',
        blocks: [
          { type: 'paragraph', text: 'Once the search is complete, **call control for a Prisoner Transport Vehicle (PTV)** over the radio and update to State 9. Keep the detainee controlled and observed while waiting.' },
          { type: 'decision', items: [
            { if: 'A PTV arrives', then: 'Hand the suspect over to the PTV officer with the full circumstances, property list, marker warnings and search outcome.', otherwise: 'Transport the detainee yourself.' },
            { if: 'You are transporting yourself', then: 'Deliver the transport warning before travelling and drive directly to the custody facility.', otherwise: 'Update control with the PTV\'s estimated transport time.' },
          ] },
          { type: 'quote', title: 'PTV / patrol transport warning', text: 'This vehicle has been searched prior to your arrest. Anything found in it afterwards will be deemed as yours. This vehicle is also fitted with audio and video recording, so anything you do or say may be used against you and will be captured.' },
          { type: 'roleplay', lines: ['"Control, Sierra One Two, State 9, prisoner escort required at [location], over."', '- sits the detainee securely in the rear of the vehicle and explains the recording -', '- drives directly to the custody facility, observing the detainee in the mirror -'] },
        ],
      },
      {
        title: 'Section 5: Custody',
        blocks: [
          { type: 'steps', items: [
            { title: 'Park in the custody area', text: 'Use the designated bay and approach the custody desk with the detainee under control.' },
            { title: 'Hand over to the custody sergeant', text: 'Give offence, grounds, necessity, circumstances, markers, force used, search results, risk and medical concerns, then complete all necessary custody forms.' },
            { title: 'If no custody sergeant is present', text: 'Follow your community\'s procedure to place the detainee into a holding cell using the platform\'s booking action, then submit the full custody record as required.' },
            { title: 'Close the loop', text: 'Update control, clear the log, restock and return to State 2.' },
          ] },
          { type: 'callout', tone: 'warning', title: 'Handover never skips risk', text: 'Tell the custody officer every warning marker, use of force, injury, medication, mental health concern and escape attempt - even if the detainee appears settled.' },
          { type: 'roleplay', lines: ['- presents the detainee to the custody desk and recounts the arrest circumstances -', '- hands over the evidence bags and confirm items are booked into the property register -', '- completes the custody forms and updates control to State 2 for the next deployment -'] },
        ],
      },
    ],
  },

  'stop-search': {
    id: 'stop-search',
    title: 'Stop and Search',
    category: 'Law & Police Powers',
    summary: 'Reasonable grounds, GOWISELY, conduct and recording.',
    jurisdiction: 'England and Wales focus',
    sections: [
      {
        title: 'Grounds and Powers',
        blocks: [
          { type: 'paragraph', text: 'A search must be based on a valid legal power. Common powers include **PACE section 1** for stolen or prohibited articles and certain bladed or offensive articles, **Misuse of Drugs Act section 23** for controlled drugs, and specific powers for firearms or designated areas.' },
          { type: 'callout', tone: 'warning', title: 'Objective grounds', text: 'A hunch, protected characteristic, previous conviction or presence in a high-crime area is not enough by itself. Grounds must be based on current facts, information and/or behaviour.' },
        ],
      },
      {
        title: 'GOWISELY',
        blocks: [
          { type: 'table', headers: ['Letter', 'Requirement'], rows: [
            ['G', 'Grounds for the search'], ['O', 'Object being searched for'], ['W', 'Warrant card if not in uniform'], ['I', 'Identity of officer'], ['S', 'Station to which officer is attached'], ['E', 'Entitlement to a copy of the search record'], ['L', 'Legal power used'], ['Y', 'You are detained for the purpose of the search'],
          ] },
          { type: 'steps', items: [
            { title: 'Engage safely', text: 'Identify yourself, explain the encounter and maintain a professional tone.' },
            { title: 'State GOWISELY', text: 'Give the information before searching, unless urgent circumstances genuinely prevent it.' },
            { title: 'Ask about hazards', text: 'Ask whether the person has sharp objects or anything that could injure them or you.' },
            { title: 'Search systematically', text: 'Search only to the extent permitted and with respect for dignity.' },
            { title: 'Seize and explain', text: 'If an item is found, state the seizure power and preserve it as evidence.' },
            { title: 'Record and conclude', text: 'Provide the record or receipt information and explain the outcome.' },
          ] },
          { type: 'decision', items: [
            { if: 'The item is found and creates reasonable suspicion of an offence', then: 'Seize it, consider arrest necessity and continue investigation.', otherwise: 'End the detention promptly and provide search-record information.' },
            { if: 'A more intimate search is proposed', then: 'Stop and apply the specific legal authority, rank, location and safeguards required.', otherwise: 'Do not exceed the scope of the original power.' },
          ] },
          { type: 'roleplay', lines: ['- activates BWV and explains the encounter -', '- gives GOWISELY in full -', '- asks about needles or sharp objects -', '- searches the outer clothing systematically -', '- provides the search reference and explains the outcome -'] },
        ],
      },
    ],
  },

  'entry-search': {
    id: 'entry-search',
    title: 'Entry and Premises Search',
    category: 'Law & Police Powers',
    summary: 'Warrants, PACE entry powers, search after arrest and scene records.',
    jurisdiction: 'England and Wales focus',
    sections: [
      {
        title: 'Common Authorities',
        blocks: [
          { type: 'table', headers: ['Power', 'Purpose'], rows: [
            ['PACE s17', 'Entry without warrant for specified purposes, including arrest for indictable offences, recapturing unlawfully at large persons and saving life or limb/preventing serious property damage.'],
            ['PACE s18', 'Search premises occupied or controlled by a person arrested for an indictable offence; normally inspector authority, with defined exceptions.'],
            ['PACE s32', 'Search premises where a person was when arrested or immediately before, for evidence relating to the offence, when statutory conditions are met.'],
            ['PACE s8 warrant', 'Magistrate-authorised entry and search for material meeting statutory tests.'],
          ] },
          { type: 'callout', tone: 'danger', title: 'Check the exact power', text: 'A welfare concern does not create a general power to enter. Section 17 life-or-limb entry requires a genuine basis for believing entry is necessary to save life or prevent serious damage.' },
        ],
      },
      {
        title: 'Search Management',
        blocks: [
          { type: 'steps', items: [
            { title: 'Confirm authority and objective', text: 'Read warrant conditions or state the exact statutory power and target.' },
            { title: 'Brief the team', text: 'Allocate search areas, safety roles, exhibit officer and scene log.' },
            { title: 'Enter proportionately', text: 'Knock/announce unless lawful operational reasons justify otherwise; use proportionate force.' },
            { title: 'Control occupants', text: 'Explain the power, manage risk and protect privileged/private material.' },
            { title: 'Search systematically', text: 'Search only places where the object could reasonably be found.' },
            { title: 'Record and restore', text: 'Document entry, damage, persons, search areas, seizures and property security.' },
          ] },
        ],
      },
    ],
  },

  'use-of-force': {
    id: 'use-of-force',
    title: 'Use of Force',
    category: 'Law & Police Powers',
    summary: 'Legal basis, National Decision Model, proportionality and aftercare.',
    sections: [
      {
        title: 'Legal Framework',
        blocks: [
          { type: 'bullets', items: ['Common law: reasonable force in self-defence, defence of another and prevention of crime.', 'Criminal Law Act 1967 s3: reasonable force in prevention of crime or effecting/assisting lawful arrest.', 'PACE s117: reasonable force where a PACE power is exercised and force is not otherwise excluded.', 'Human Rights Act: force must be lawful, necessary, proportionate and accountable.', 'Local policy and training govern tactics and equipment.'] },
          { type: 'callout', tone: 'warning', title: 'No automatic force level', text: 'There is no fixed force continuum. The officer must justify the option selected against the threat, subject behaviour, impact factors and available alternatives.' },
        ],
      },
      {
        title: 'National Decision Model',
        blocks: [
          { type: 'steps', items: [
            { title: 'Information and intelligence', text: 'What is known, unknown and changing?' },
            { title: 'Threat and risk assessment', text: 'Assess threat, harm, risk, vulnerability and working strategy.' },
            { title: 'Powers and policy', text: 'Identify lawful authority and relevant guidance.' },
            { title: 'Options and contingencies', text: 'Communication, containment, withdrawal, support, arrest and tactical options.' },
            { title: 'Action and review', text: 'Act, reassess continuously and stop force when the need ends.' },
          ] },
          { type: 'decision', items: [
            { if: 'Immediate force is necessary to prevent harm', then: 'Use the least intrusive effective option reasonably available, reassess and provide aftercare.', otherwise: 'Communicate, create time/distance, request support and avoid unnecessary escalation.' },
            { if: 'Force causes injury or there is a medical complaint', then: 'Provide first aid, request clinical assessment, inform custody/supervisor and record it.', otherwise: 'Still check welfare and document force used.' },
          ] },
          { type: 'roleplay', lines: ['- gives clear verbal directions and allows time to comply -', '- adopts a protected stance and requests another unit -', '- uses approved force to prevent the assault -', '- stops applying force once control is achieved -', '- checks the detainee for injury and explains what will happen next -', '- completes a use-of-force record before the end of duty -'] },
        ],
      },
    ],
  },

  'public-order': {
    id: 'public-order',
    title: 'Public Order Powers',
    category: 'Law & Police Powers',
    summary: 'Core offences, lawful assembly, escalation and evidence.',
    jurisdiction: 'England and Wales focus',
    sections: [
      {
        title: 'Offence Overview',
        blocks: [
          { type: 'table', headers: ['Offence', 'Practical description'], rows: [
            ['Affray - Public Order Act s3', 'A person uses or threatens unlawful violence such that a person of reasonable firmness would fear for personal safety.'],
            ['Fear/provocation of violence - s4', 'Threatening, abusive or insulting words/behaviour with intent to cause belief that immediate violence will be used or provoke it.'],
            ['Intentional harassment/alarm/distress - s4A', 'Threatening, abusive or insulting conduct intended to cause harassment, alarm or distress and does so.'],
            ['Harassment/alarm/distress - s5', 'Threatening or abusive words/behaviour or disorderly behaviour within hearing/sight of a person likely to be caused harassment, alarm or distress.'],
          ] },
          { type: 'callout', tone: 'info', title: 'Protest rights', text: 'Articles 10 and 11 protect expression and assembly. Police action must distinguish peaceful participation from criminal conduct and remain lawful, necessary and proportionate.' },
        ],
      },
      {
        title: 'Operational Response',
        blocks: [
          { type: 'decision', items: [
            { if: 'There is active violence or an immediate threat', then: 'Protect life, request sufficient resources, separate groups, identify offenders and preserve BWV/CCTV evidence.', otherwise: 'Engage, monitor, communicate conditions and facilitate lawful activity.' },
            { if: 'A dispersal or condition power is considered', then: 'Confirm authorisation, scope, time, location, communication and recording requirements.', otherwise: 'Do not imply a power that has not been authorised.' },
          ] },
        ],
      },
    ],
  },

  'road-traffic-powers': {
    id: 'road-traffic-powers',
    title: 'Road Traffic Powers',
    category: 'Law & Police Powers',
    summary: 'Stopping vehicles, documents, impairment and seizure.',
    jurisdiction: 'Great Britain overview; local law differs in Northern Ireland',
    sections: [
      {
        title: 'Core Powers',
        blocks: [
          { type: 'table', headers: ['Power', 'Purpose'], rows: [
            ['Road Traffic Act 1988 s163', 'Uniformed constable may require a driver to stop.'],
            ['RTA s164/s165', 'Require driving licence and specified driver/vehicle information or documents.'],
            ['RTA s6', 'Preliminary breath, drug or impairment testing when statutory conditions are met.'],
            ['RTA s4/s5/s5A', 'Offences concerning unfitness, alcohol limits and specified controlled drugs.'],
            ['Road Traffic Regulation Act 1984 s99 / Road Traffic Act 1988 s165A', 'Removal or seizure in defined circumstances, including certain uninsured/unlicensed driving.'],
          ] },
        ],
      },
      {
        title: 'Vehicle Stop Procedure',
        blocks: [
          { type: 'steps', items: [
            { title: 'Plan and notify', text: 'Check vehicle markers, location, occupants and safe stopping point; inform control.' },
            { title: 'Signal to stop', text: 'Use approved lights/signals and avoid creating unnecessary risk.' },
            { title: 'Position safely', text: 'Use vehicle position, lighting and PPE appropriate to the road.' },
            { title: 'Engage and explain', text: 'Identify yourself and state the reason for the stop.' },
            { title: 'Check driver and vehicle', text: 'Confirm identity, documents, insurance, licence, impairment and vehicle condition.' },
            { title: 'Choose outcome', text: 'Advice, defect process, report, seizure, arrest or further investigation.' },
          ] },
          { type: 'decision', items: [
            { if: 'Driver fails a preliminary breath test or refuses without reasonable excuse', then: 'Follow arrest/evidential procedure and local policy.', otherwise: 'Consider other impairment, medical causes or offences.' },
            { if: 'Vehicle is believed uninsured and statutory checks are complete', then: 'Consider s165A seizure and provide required notice.', otherwise: 'Do not seize on an unresolved database discrepancy alone.' },
          ] },
        ],
      },
    ],
  },

  'incident-response': {
    id: 'incident-response',
    title: 'Incident Response',
    category: 'Core Procedures',
    summary: 'From CAD dispatch to closure and handover.',
    sections: [
      {
        title: 'THRIVE and Initial Plan',
        blocks: [
          { type: 'table', headers: ['THRIVE', 'Question'], rows: [
            ['Threat', 'What threat exists now or may develop?'], ['Harm', 'What harm has occurred or could occur?'], ['Risk', 'How likely and serious is the risk?'], ['Investigation', 'What evidence, offences and immediate enquiries exist?'], ['Vulnerability', 'Who is vulnerable and why?'], ['Engagement', 'Who must be updated, reassured or involved?'],
          ] },
          { type: 'steps', items: [
            { title: 'Acknowledge and read', text: 'Do not drive before understanding location, grading and hazards.' },
            { title: 'Select response', text: 'Use the response level authorised by control and driving policy.' },
            { title: 'Give arrival update', text: 'Confirm on scene and supply an early situation report.' },
            { title: 'Stabilise', text: 'Protect life, prevent escalation, detain where lawful and call specialists.' },
            { title: 'Investigate', text: 'Secure accounts, CCTV, exhibits, digital evidence and suspect details.' },
            { title: 'Resolve and record', text: 'Record rationale, safeguarding, crime outcome and outstanding actions.' },
          ] },
        ],
      },
    ],
  },

  'scene-management': {
    id: 'scene-management',
    title: 'Crime Scene Management',
    category: 'Core Procedures',
    summary: 'Preserve life, protect evidence and maintain an auditable scene.',
    sections: [
      {
        title: 'First Officer Actions',
        blocks: [
          { type: 'steps', items: [
            { title: 'Save life', text: 'Medical care takes priority; record unavoidable disturbance.' },
            { title: 'Remove threats and detain suspects', text: 'Do not allow evidence preservation to prevent essential safety action.' },
            { title: 'Set cordons', text: 'Start wide; establish inner and outer cordons where appropriate.' },
            { title: 'Start a scene log', text: 'Record every person entering/leaving, time, purpose and protective clothing.' },
            { title: 'Protect fragile evidence', text: 'Cover or guard evidence without contaminating it; consider weather and crowds.' },
            { title: 'Identify witnesses', text: 'Separate them and obtain contact details and brief first accounts.' },
            { title: 'Brief supervision/CID/CSI', text: 'Provide a concise handover of actions, changes and outstanding risks.' },
          ] },
          { type: 'callout', tone: 'warning', title: 'Contamination control', text: 'Use gloves and appropriate PPE, avoid common approach paths, do not share pens/packaging between exhibits and never place wet biological material in plastic for long-term storage.' },
          { type: 'roleplay', lines: ['- extends scene tape to include the likely approach and exit route -', '- starts a written scene log at the cordon point -', '- records that paramedics moved an item while providing life-saving care -', '- prevents unnecessary personnel from entering the inner cordon -'] },
        ],
      },
    ],
  },

  'evidence-statements': {
    id: 'evidence-statements',
    title: 'Evidence and Statements',
    category: 'Core Procedures',
    summary: 'Exhibits, continuity, first accounts and witness statements.',
    sections: [
      {
        title: 'Exhibit Handling',
        blocks: [
          { type: 'bullets', items: ['Photograph in situ when appropriate before moving.', 'Use clean gloves and change them between contamination-sensitive exhibits.', 'Use suitable packaging: paper for dry biological items, rigid sharps container for sharps, approved digital packaging for devices.', 'Give each exhibit a unique reference and record who seized it, where, when and why.', 'Seal, sign and maintain continuity through every transfer.'] },
        ],
      },
      {
        title: 'Statements and Significant Material',
        blocks: [
          { type: 'steps', items: [
            { title: 'Establish fitness and needs', text: 'Consider interpreter, appropriate adult, communication aid and trauma.' },
            { title: 'Obtain a free account', text: 'Use open questions before clarifying detail.' },
            { title: 'Cover points to prove', text: 'Who, what, when, where, how, identification, loss, injury and impact.' },
            { title: 'Record accurately', text: 'Use the witness\'s words; distinguish observation from assumption.' },
            { title: 'Review and endorse', text: 'Allow correction and obtain the proper declaration/signature or digital confirmation.' },
          ] },
          { type: 'callout', tone: 'info', title: 'First accounts', text: 'Record a brief first account early, but avoid repeated detailed questioning of vulnerable or traumatised witnesses where specialist interviewing may be required.' },
        ],
      },
    ],
  },

  'custody-booking': {
    id: 'custody-booking',
    title: 'Custody and Booking In',
    category: 'Core Procedures',
    summary: 'Presenting a detainee, risk, property, rights and handover.',
    sections: [
      {
        title: 'Custody Presentation',
        blocks: [
          { type: 'steps', items: [
            { title: 'State arrest details', text: 'Offence, grounds, necessity, arrest time/place and caution.' },
            { title: 'Describe circumstances', text: 'Brief facts, victim/witness position, evidence and outstanding enquiries.' },
            { title: 'Declare risk', text: 'Violence, escape, self-harm, substance use, concealed items, mental health and medical concerns.' },
            { title: 'Explain force and restraint', text: 'Tactics, duration, reason, injury and aftercare.' },
            { title: 'Transfer property/exhibits', text: 'Separate detainee property from evidential exhibits and maintain continuity.' },
            { title: 'Record authorisation decision', text: 'Custody officer independently decides whether detention is authorised.' },
          ] },
          { type: 'callout', tone: 'danger', title: 'Medical risk', text: 'Intoxication can mask head injury, hypoglycaemia, overdose or sepsis. Request healthcare assessment where indicated and do not assume sleepiness is simply alcohol.' },
        ],
      },
      {
        title: 'Rights and Safeguards',
        blocks: [
          { type: 'bullets', items: ['Right to have someone informed of the arrest, subject to lawful delay provisions.', 'Right to independent legal advice.', 'Right to consult relevant Codes of Practice.', 'Interpreter and communication assistance where required.', 'Appropriate adult for children and vulnerable adults.', 'Regular reviews of detention and welfare observations.'] },
        ],
      },
    ],
  },

  'victim-witness': {
    id: 'victim-witness',
    title: 'Victims and Witnesses',
    category: 'Core Procedures',
    summary: 'Needs assessment, updates, special measures and procedural fairness.',
    sections: [
      {
        title: 'Initial Contact',
        blocks: [
          { type: 'bullets', items: ['Address immediate safety and medical needs.', 'Explain your role, what will happen next and realistic timescales.', 'Assess vulnerability, intimidation, language and communication needs.', 'Record preferred contact method and safe times to contact.', 'Consider special measures and referral to support services.', 'Provide a crime/reference number and update plan.'] },
          { type: 'decision', items: [
            { if: 'The witness is a child or vulnerable adult', then: 'Consider specialist interview strategy, appropriate support and safeguarding; avoid unnecessary repeated accounts.', otherwise: 'Obtain and record an early account proportionately.' },
            { if: 'There is fear of retaliation', then: 'Create a safety plan, record the threat and consider protective measures and supervisor/CID input.', otherwise: 'Still explain how to report further contact or intimidation.' },
          ] },
        ],
      },
    ],
  },

  intelligence: {
    id: 'intelligence',
    title: 'Intelligence Reports',
    category: 'Core Procedures',
    summary: 'Recording actionable information lawfully and objectively.',
    sections: [
      {
        title: 'What Good Intelligence Contains',
        blocks: [
          { type: 'bullets', items: ['Who or what is involved, with identifiers.', 'What is happening or expected to happen.', 'When and where it occurred or may occur.', 'How the source knows and whether information is first-hand.', 'Risk, urgency and immediate safeguarding implications.', 'Clear separation of fact, opinion and inference.'] },
          { type: 'callout', tone: 'warning', title: 'Information handling', text: 'Submit through approved force systems. Do not copy police information into personal notes, messaging apps or roleplay channels that are not authorised.' },
        ],
      },
    ],
  },

  'missing-person': {
    id: 'missing-person',
    title: 'Missing Person',
    category: 'Operational Scenarios',
    summary: 'Risk assessment, immediate actions, search and return interview.',
    sections: [
      {
        title: 'What Is Happening?',
        blocks: [
          { type: 'paragraph', text: 'A missing person is anyone whose whereabouts cannot be established where the circumstances are out of character or the context suggests the person may be subject to crime or at risk of harm. The response is driven by **risk**, not by waiting a fixed period.' },
          { type: 'table', headers: ['Risk level', 'Meaning'], rows: [
            ['High', 'Risk is likely to be immediate and there are substantial grounds for believing the person is in danger.'],
            ['Medium', 'Risk is likely to place the person or public in danger or subject them to a substantial threat of harm.'],
            ['Low', 'Risk of harm is possible but minimal; proportionate enquiries remain required.'],
          ] },
        ],
      },
      {
        title: 'Officer Actions',
        blocks: [
          { type: 'steps', items: [
            { title: 'Confirm basic facts', text: 'Identity, photograph, last seen time/place, clothing, phone, vehicle, associates and likely destinations.' },
            { title: 'Identify vulnerability', text: 'Age, mental/physical health, medication, suicide risk, exploitation, weather and access to transport.' },
            { title: 'Search the home and immediate area', text: 'Do not assume it was already searched; check hazards, concealment and evidence.' },
            { title: 'Preserve digital opportunities', text: 'Phone/social accounts, transport cards, banking and CCTV through lawful processes.' },
            { title: 'Create a search strategy', text: 'Last known point, routes, places of significance and specialist search assets.' },
            { title: 'Update risk continuously', text: 'Escalate new information immediately and record decisions.' },
          ] },
          { type: 'decision', items: [
            { if: 'There is immediate suicide, exploitation or abduction risk', then: 'Treat as high risk, deploy urgent resources, circulate promptly and involve supervision/specialists.', otherwise: 'Complete proportionate enquiries and set review times.' },
            { if: 'The person is found', then: 'Confirm identity, assess welfare, address offences/medical needs, cancel circulations and arrange prevention interview.', otherwise: 'Continue and document the search strategy and reviews.' },
          ] },
          { type: 'roleplay', lines: ['- obtains a recent photograph and full clothing description -', '- searches each room and checks places of concealment -', '- records the exact last known location on the incident log -', '- requests CCTV preservation from the nearby station -', '- updates the inspector with the revised risk assessment -'] },
        ],
      },
    ],
  },

  'domestic-abuse': {
    id: 'domestic-abuse',
    title: 'Domestic Abuse',
    category: 'Operational Scenarios',
    summary: 'Victim safety, evidence-led investigation, DASH and safeguarding.',
    sections: [
      {
        title: 'Initial Response',
        blocks: [
          { type: 'callout', tone: 'danger', title: 'High-risk context', text: 'Separation, stalking, strangulation, threats to kill, pregnancy, weapons, coercive control and escalating frequency are serious risk indicators.' },
          { type: 'steps', items: [
            { title: 'Separate parties', text: 'Prevent intimidation and obtain independent accounts.' },
            { title: 'Protect life and provide medical care', text: 'Check injuries, especially non-fatal strangulation symptoms, and request clinicians.' },
            { title: 'Identify offences and evidence', text: 'Record scene, injuries, body-worn video, 999 call, messages, damaged property, witnesses and children present.' },
            { title: 'Complete risk assessment', text: 'Use the approved DASH or local domestic abuse risk process.' },
            { title: 'Consider arrest', text: 'Apply lawful grounds and Code G necessity; protect the victim and integrity of investigation.' },
            { title: 'Safeguard and refer', text: 'Safety plan, refuge/IDVA, child/adult safeguarding and high-risk MARAC referral where applicable.' },
          ] },
          { type: 'decision', items: [
            { if: 'The victim does not support prosecution', then: 'Continue an evidence-led investigation, assess coercion and risk, and record the reasons and safeguarding plan.', otherwise: 'Take a full account and explain special measures and updates.' },
            { if: 'Children are present or normally live there', then: 'Record their presence, demeanour and disclosures; submit safeguarding referral.', otherwise: 'Check whether children are linked elsewhere.' },
          ] },
          { type: 'roleplay', lines: ['- separates both parties into different rooms -', '- activates BWV and records the condition of the scene -', '- asks the victim about strangulation, threats, weapons and escalating behaviour -', '- photographs visible injuries with consent and evidential procedure -', '- completes the domestic abuse risk assessment and safety plan -'] },
        ],
      },
    ],
  },

  'mental-health': {
    id: 'mental-health',
    title: 'Mental Health Incident',
    category: 'Operational Scenarios',
    summary: 'Safety, communication, Mental Health Act powers and least-restrictive action.',
    sections: [
      {
        title: 'Communication and Risk',
        blocks: [
          { type: 'bullets', items: ['Reduce noise, crowding and confrontational posture.', 'Use one calm communicator and allow processing time.', 'Ask directly about suicide, self-harm, weapons, substances and medication.', 'Do not treat unusual behaviour as an offence without considering health and capacity.', 'Request ambulance or mental health support where clinical assessment is required.'] },
          { type: 'callout', tone: 'warning', title: 'Section 136', text: 'In England and Wales, section 136 applies when a person appears to have a mental disorder and is in immediate need of care or control, and the officer considers removal necessary in the interests of that person or protection of others. It is not a general power inside a private dwelling.' },
        ],
      },
      {
        title: 'Decision Guide',
        blocks: [
          { type: 'decision', items: [
            { if: 'There is an immediate medical emergency or serious injury', then: 'Request ambulance and provide first aid; use the least restrictive lawful means to preserve life.', otherwise: 'Seek mental health triage and consider voluntary support.' },
            { if: 'Section 136 criteria are met in a qualifying place', then: 'Consult healthcare where practicable, explain the power, search/transport lawfully and use an appropriate place of safety.', otherwise: 'Do not use section 136; consider other lawful powers or voluntary pathways.' },
            { if: 'A criminal offence also requires action', then: 'Balance investigation, health needs and necessity; communicate with custody and healthcare.', otherwise: 'Prioritise care and safeguarding.' },
          ] },
          { type: 'roleplay', lines: ['- lowers voice and asks other responders to give the person space -', '- removes immediate hazards from reach -', '- asks directly whether the person intends to harm themselves or anyone else -', '- requests mental health triage through control -', '- explains the proposed place of safety and what will happen next -'] },
        ],
      },
    ],
  },

  safeguarding: {
    id: 'safeguarding',
    title: 'Safeguarding Children and Adults',
    category: 'Operational Scenarios',
    summary: 'Recognise abuse, protect immediately and refer correctly.',
    sections: [
      {
        title: 'Indicators and Action',
        blocks: [
          { type: 'table', headers: ['Concern', 'Examples'], rows: [
            ['Physical abuse', 'Unexplained injuries, inconsistent history, delay seeking care.'],
            ['Neglect', 'Unsafe home, lack of food/medication, poor supervision.'],
            ['Sexual abuse/exploitation', 'Disclosure, concerning contact, unexplained gifts, trafficking indicators.'],
            ['Emotional/coercive abuse', 'Fear, isolation, humiliation, control of money or contact.'],
            ['Financial abuse', 'Unexplained withdrawals, pressure, misuse of benefits/property.'],
          ] },
          { type: 'steps', items: [
            { title: 'Address immediate danger', text: 'Remove the threat lawfully and obtain medical assistance.' },
            { title: 'Listen and record', text: 'Use the person\'s words; do not ask leading or repeated questions.' },
            { title: 'Preserve evidence', text: 'Record scene, injuries, digital material and spontaneous comments.' },
            { title: 'Share lawfully', text: 'Pass necessary information to safeguarding partners under approved process.' },
            { title: 'Submit referral', text: 'Complete child/adult safeguarding referral before end of duty unless transferred formally.' },
          ] },
        ],
      },
    ],
  },

  'sudden-death': {
    id: 'sudden-death',
    title: 'Sudden Death',
    category: 'Operational Scenarios',
    summary: 'Scene safety, medical confirmation, preservation and coroner/procurator fiscal process.',
    sections: [
      {
        title: 'First Response',
        blocks: [
          { type: 'steps', items: [
            { title: 'Confirm safety and life-saving needs', text: 'Do not assume death; request ambulance unless death is unequivocal or already verified.' },
            { title: 'Treat as unexplained initially', text: 'Limit access and avoid moving the body or objects unnecessarily.' },
            { title: 'Identify and separate witnesses', text: 'Obtain brief first accounts and record who entered the scene.' },
            { title: 'Look for suspicious indicators', text: 'Injury, disturbance, forced entry, missing property, drugs, weapons or inconsistent accounts.' },
            { title: 'Notify supervision/CID', text: 'Escalate according to suspicious or unexplained death policy.' },
            { title: 'Support relatives', text: 'Communicate sensitively; do not speculate on cause of death.' },
          ] },
          { type: 'decision', items: [
            { if: 'Circumstances are suspicious or unclear', then: 'Establish a crime scene, preserve the body and scene, request detectives/forensics and maintain a log.', otherwise: 'Follow expected/non-suspicious death procedure and coroner or Procurator Fiscal requirements.' },
            { if: 'Resuscitation occurred', then: 'Record who moved what and retain relevant medical equipment/evidence as directed.', otherwise: 'Do not disturb the scene.' },
          ] },
          { type: 'roleplay', lines: ['- restricts access to the room and starts a scene log -', '- records the position of the body without touching it -', '- separates witnesses and obtains brief first accounts -', '- updates the duty sergeant and requests CID attendance -'] },
        ],
      },
    ],
  },

  'road-collision': {
    id: 'road-collision',
    title: 'Road Traffic Collision',
    category: 'Operational Scenarios',
    summary: 'Scene safety, casualties, road management, investigation and recovery.',
    sections: [
      {
        title: 'Approach and Priorities',
        blocks: [
          { type: 'steps', items: [
            { title: 'Protect the scene', text: 'Position vehicle to provide protection, use warning equipment and high-visibility PPE.' },
            { title: 'Assess casualties', text: 'Request ambulance/fire, give first aid and identify entrapment or hazardous materials.' },
            { title: 'Prevent secondary collisions', text: 'Close lanes/roads where necessary and request highways support.' },
            { title: 'Identify drivers and witnesses', text: 'Separate accounts, obtain details and preserve dashcam/CCTV.' },
            { title: 'Consider offences', text: 'Impairment, dangerous/careless driving, insurance, licence, mobile phone and vehicle defects.' },
            { title: 'Preserve serious collision scene', text: 'For fatal/serious injury, request roads policing/collision investigation and avoid moving vehicles unless essential.' },
          ] },
          { type: 'decision', items: [
            { if: 'There is serious injury or death', then: 'Treat as a potential crime scene, close the road, request specialist investigators and preserve evidence.', otherwise: 'Complete proportionate reporting, exchange details and arrange recovery.' },
            { if: 'A driver appears impaired', then: 'Use lawful preliminary testing and arrest/evidential procedure as applicable.', otherwise: 'Still record observations and check documents.' },
          ] },
          { type: 'roleplay', lines: ['- parks in a protective position and activates rear warning lights -', '- puts on a high-visibility jacket before entering the carriageway -', '- requests ambulance and fire service with exact casualty numbers -', '- marks the location of debris and preserves nearby dashcam footage -'] },
        ],
      },
    ],
  },

  burglary: {
    id: 'burglary',
    title: 'Burglary in Progress',
    category: 'Operational Scenarios',
    summary: 'Containment, search, arrest and forensic preservation.',
    sections: [
      {
        title: 'Dynamic Response',
        blocks: [
          { type: 'decision', items: [
            { if: 'Suspect is believed still inside', then: 'Request support, contain exits, gather description and consider dog/firearms support based on threat.', otherwise: 'Preserve the scene, identify loss and conduct local searches.' },
            { if: 'A suspect is located', then: 'Give clear directions, control hands, arrest where grounds and necessity exist, and conduct lawful searches.', otherwise: 'Broadcast description/direction and protect forensic opportunities.' },
          ] },
          { type: 'steps', items: [
            { title: 'Approach quietly and safely', text: 'Avoid advertising arrival if containment is possible.' },
            { title: 'Confirm informant and layout', text: 'Occupants, entry points, suspect count, weapons and keys.' },
            { title: 'Contain and challenge', text: 'Use clear roles, safe arcs and lawful entry powers.' },
            { title: 'Preserve entry point', text: 'Do not touch doors/windows unnecessarily; protect toolmarks and fingerprints.' },
            { title: 'Record property and CCTV', text: 'Obtain serials, photos, smart-doorbell and neighbour footage.' },
          ] },
          { type: 'roleplay', lines: ['- switches off the vehicle siren before the final approach -', '- takes cover and watches the rear exit -', '- challenges the suspect with clear verbal directions -', '- preserves the broken window for forensic examination -'] },
        ],
      },
    ],
  },

  assault: {
    id: 'assault',
    title: 'Assault and Public Place Violence',
    category: 'Operational Scenarios',
    summary: 'Stop violence, identify roles, secure evidence and safeguard victims.',
    sections: [
      {
        title: 'Officer Response',
        blocks: [
          { type: 'steps', items: [
            { title: 'Stop ongoing violence', text: 'Use communication, separation and lawful force proportionate to the threat.' },
            { title: 'Call medical help', text: 'Treat life-threatening bleeding and head injuries as priority.' },
            { title: 'Separate suspects, victims and witnesses', text: 'Prevent collusion and contamination of accounts.' },
            { title: 'Identify evidence', text: 'BWV, CCTV, weapons, clothing, injuries, 999 audio and spontaneous comments.' },
            { title: 'Apply arrest necessity', text: 'Consider preventing injury, prompt/effective investigation and disappearance.' },
            { title: 'Record injury and impact', text: 'Photographs, medical consent, victim statement and safeguarding.' },
          ] },
          { type: 'decision', items: [
            { if: 'A weapon is reported or seen', then: 'Create distance, use cover, request appropriate support and communicate description/location.', otherwise: 'Continue proportionate control and evidence gathering.' },
            { if: 'Accounts conflict', then: 'Do not decide solely on who called first; preserve independent evidence and investigate impartially.', otherwise: 'Record corroboration and inconsistencies.' },
          ] },
        ],
      },
    ],
  },

  shoplifting: {
    id: 'shoplifting',
    title: 'Shoplifting',
    category: 'Operational Scenarios',
    summary: 'A proportionate theft investigation from detention to disposal.',
    sections: [
      {
        title: 'Investigation Checklist',
        blocks: [
          { type: 'bullets', items: ['Confirm the store witness saw selection, concealment, non-payment and continuous observation.', 'Secure CCTV before it is overwritten.', 'Identify goods, value, ownership and condition.', 'Record suspect comments and explanation.', 'Check identity, offending history only where lawfully relevant, vulnerability and safeguarding.', 'Apply arrest necessity; do not arrest automatically because security detained someone.', 'Consider force policy for community resolution, out-of-court disposal, report or arrest.'] },
          { type: 'decision', items: [
            { if: 'Identity/address cannot be confirmed or prompt evidence recovery/interview requires arrest', then: 'Consider arrest and state the specific necessity.', otherwise: 'Use a proportionate non-custodial disposal if policy and evidence permit.' },
          ] },
        ],
      },
    ],
  },

  'suspicious-vehicle': {
    id: 'suspicious-vehicle',
    title: 'Suspicious Vehicle',
    category: 'Operational Scenarios',
    summary: 'Safe checks, intelligence, lawful stop and proportionate investigation.',
    sections: [
      {
        title: 'Assessment and Stop',
        blocks: [
          { type: 'steps', items: [
            { title: 'Check information', text: 'Registration, make/model, keeper, insurance, markers, linked crime and reason for suspicion.' },
            { title: 'Plan the stop', text: 'Location, traffic, occupants, support and tactical options.' },
            { title: 'Stop lawfully', text: 'Use RTA s163 in uniform and approved stop signals.' },
            { title: 'Explain and observe', text: 'State reason, watch hands and note behaviour without treating nervousness as guilt.' },
            { title: 'Use further powers only with grounds', text: 'Document checks, searches, seizures or arrest grounds.' },
          ] },
          { type: 'decision', items: [
            { if: 'The vehicle fails to stop', then: 'Update control, conduct a dynamic risk assessment and follow pursuit policy; only trained/authorised officers continue as permitted.', otherwise: 'Position safely and conduct checks.' },
            { if: 'Crime-related items are visible or grounds develop', then: 'Use the correct search/seizure power and preserve evidence.', otherwise: 'Conclude the stop without extending it unnecessarily.' },
          ] },
        ],
      },
    ],
  },

  bwv: {
    id: 'bwv',
    title: 'Body-Worn Video',
    category: 'Equipment',
    summary: 'When to record, announcements, privacy, evidence and retention.',
    sections: [
      {
        title: 'Purpose and Use',
        blocks: [
          { type: 'paragraph', text: 'Body-worn video (BWV) provides an independent visual and audio record, supports transparency and captures evidence. It does not replace a notebook, statement, risk assessment or professional explanation.' },
          { type: 'table', headers: ['Use', 'Guidance'], rows: [
            ['Activate', 'At the earliest reasonable opportunity for incidents, enforcement, searches, use of force, domestic abuse and evidential encounters, subject to force policy.'],
            ['Announce', 'Where practicable, state that video and audio are being recorded.'],
            ['Keep recording', 'Record a complete event rather than selective clips; state the reason before stopping where possible.'],
            ['Privacy', 'Use heightened care in homes, medical settings, intimate searches, victims of sexual offences and children.'],
            ['Evidential handling', 'Mark footage correctly, add incident/exhibit details and apply retention category. Never edit or delete footage yourself.'],
          ] },
        ],
      },
      {
        title: 'Operational Checklist',
        blocks: [
          { type: 'steps', items: [
            { title: 'Start of duty', text: 'Check battery, lens, mount, date/time, recording indicator and upload status.' },
            { title: 'Activate', text: 'Press record before contact where possible and confirm the device is recording.' },
            { title: 'Announce', text: 'Say: "My body-worn camera is recording video and audio."' },
            { title: 'Narrate essential context', text: 'Briefly capture grounds or items that the camera may not show.' },
            { title: 'Conclude', text: 'State the reason recording is ending, then stop when the policing purpose ends.' },
            { title: 'Dock and categorise', text: 'Upload, label, link and retain according to policy.' },
          ] },
          { type: 'decision', items: [
            { if: 'Recording would capture highly sensitive/private material', then: 'Balance necessity and evidential value, use privacy controls and follow force policy; do not switch off merely to avoid scrutiny.', otherwise: 'Continue a complete recording.' },
            { if: 'The device fails', then: 'Tell control/colleague, record the failure and use other evidence/notes.', otherwise: 'Confirm successful upload after duty.' },
          ] },
          { type: 'roleplay', lines: ['- checks the BWV battery and lens before patrol -', '- presses record and confirms the red recording indicator -', '"For clarity, my body-worn camera is recording video and audio."', '- bookmarks the relevant moment and notes the incident number -', '- docks the camera and categorises the footage as evidential -'] },
        ],
      },
    ],
  },

  'personal-equipment': {
    id: 'personal-equipment',
    title: 'Personal Protective Equipment',
    category: 'Equipment',
    summary: 'Uniform, body armour, high-visibility clothing and basic safety kit.',
    sections: [
      {
        title: 'Standard Personal Issue',
        blocks: [
          { type: 'table', headers: ['Item', 'Purpose', 'Typical users'], rows: [
            ['Body armour', 'Reduces injury from specified ballistic/stab threats; not total protection', 'Operational officers according to risk/policy'],
            ['High-visibility jacket/vest', 'Makes officers visible at roads, scenes and public order deployments', 'All operational officers'],
            ['Protective gloves', 'Reduces contamination and sharps exposure', 'All operational officers'],
            ['Safety footwear', 'Grip, ankle support and impact protection', 'Uniformed operational officers'],
            ['Eye/face protection', 'Protection from fluids, debris and specified hazards', 'Issued/role-specific'],
            ['First aid pouch', 'Immediate trauma care until clinicians arrive', 'Operational officers; contents vary'],
            ['Torch', 'Search, scene safety and signalling', 'All frontline officers'],
            ['Warrant card', 'Proof of office/identity where required', 'Constables and authorised staff'],
            ['Notebook/ePNB', 'Contemporaneous notes and decision record', 'All officers/staff as issued'],
          ] },
          { type: 'callout', tone: 'warning', title: 'High-visibility clothing', text: 'Wear it when visibility outweighs tactical concealment, especially on roads. It does not make a live carriageway safe; use vehicles, closures, warning equipment and a safe system of work.' },
          { type: 'roleplay', lines: ['- fastens the body armour and checks the front and rear panels -', '- places the high-visibility jacket over the armour before entering the road -', '- puts on nitrile gloves before handling the blood-stained item -', '- checks the first aid pouch seal and expiry dates -'] },
        ],
      },
    ],
  },

  restraints: {
    id: 'restraints',
    title: 'Handcuffs and Restraints',
    category: 'Equipment',
    summary: 'Purpose, legal justification, monitoring and aftercare.',
    sections: [
      {
        title: 'Restraint Principles',
        blocks: [
          { type: 'bullets', items: ['Handcuffs are a use of force and require individual justification.', 'Consider demeanour, offence, information, escape risk, violence risk, weapons and environment.', 'Double-lock cuffs, check fit and monitor circulation.', 'Avoid prolonged prone restraint and monitor breathing continuously.', 'Never use force as punishment or for compliance when no lawful objective remains.', 'Record the reason, type, duration, position, checks, injury and aftercare.'] },
          { type: 'decision', items: [
            { if: 'There is a reasonable risk of violence, escape or evidence disposal', then: 'Consider approved restraints, explain where practicable and monitor continuously.', otherwise: 'Do not handcuff automatically because a person is arrested.' },
            { if: 'The detainee reports pain, breathing difficulty or becomes unresponsive', then: 'Reassess restraints immediately, provide first aid and request urgent medical help.', otherwise: 'Continue documented welfare checks.' },
          ] },
          { type: 'roleplay', lines: ['- explains that handcuffs are being used because of the identified escape risk -', '- applies the cuffs using an approved technique -', '- double-locks both cuffs and checks spacing -', '- seats the detainee upright and monitors breathing -', '- records the justification and duration of restraint -'] },
        ],
      },
    ],
  },

  'defensive-equipment': {
    id: 'defensive-equipment',
    title: 'Defensive Equipment',
    category: 'Equipment',
    summary: 'Baton, incapacitant spray, Taser and specialist equipment.',
    sections: [
      {
        title: 'Equipment Overview',
        blocks: [
          { type: 'table', headers: ['Equipment', 'Purpose', 'Who carries/uses'], rows: [
            ['Baton', 'Approved defensive impact option where lawful, necessary and proportionate', 'Trained operational officers as issued'],
            ['PAVA/CS spray', 'Irritant intended to assist control of a violent or threatening person', 'Trained operational officers as issued'],
            ['Taser', 'Conducted energy device; several tactical options including drawing, aiming, red-dot and discharge', 'Specially Trained Officers and firearms officers under policy'],
            ['Shields/helmets/public order PPE', 'Protection during disorder and high-risk operations', 'Public order trained units'],
            ['Spit/bite guard', 'Reduces spitting/biting risk where approved and justified', 'Trained officers under force policy'],
          ] },
          { type: 'callout', tone: 'danger', title: 'Training controls use', text: 'This page describes purpose, not tactical instruction. Officers may only use equipment they are trained, authorised and currently competent to use, in accordance with law and local policy.' },
          { type: 'decision', items: [
            { if: 'A lower-risk option can safely achieve the lawful objective', then: 'Use or consider that option and continue communication.', otherwise: 'Select an authorised option proportionate to the threat and reassess immediately.' },
            { if: 'Spray, baton or Taser is used', then: 'Control the person, provide appropriate aftercare/medical assessment, notify supervision and complete required records.', otherwise: 'Document other force as required.' },
          ] },
        ],
      },
    ],
  },

  communications: {
    id: 'communications',
    title: 'Radio, MDT and Mobile Devices',
    category: 'Equipment',
    summary: 'What each device does and how frontline units use it.',
    sections: [
      {
        title: 'Device Guide',
        blocks: [
          { type: 'table', headers: ['Device', 'Function', 'Used by'], rows: [
            ['Airwave radio', 'Encrypted voice communication, emergency button, talkgroups and status updates', 'Frontline officers, control and specialists'],
            ['Mobile data terminal (MDT)', 'CAD incidents, mapping, status, vehicle/person checks and messaging', 'Response vehicles and specialist vehicles'],
            ['Force mobile phone/tablet', 'Statements, crime reports, photos, ePNB and approved applications', 'Officers and staff as issued'],
            ['Body-worn video', 'Audio/video evidence and transparency', 'Frontline and designated roles'],
            ['ANPR terminal', 'Vehicle reads and markers', 'Roads policing and equipped patrol vehicles'],
          ] },
          { type: 'callout', tone: 'warning', title: 'Operational security', text: 'Use approved systems only. Lock devices, verify recipients, avoid unnecessary personal data over open channels and report loss or compromise immediately.' },
        ],
      },
    ],
  },

  'traffic-evidence-kit': {
    id: 'traffic-evidence-kit',
    title: 'Traffic and Evidence Kit',
    category: 'Equipment',
    summary: 'Common roadside, scene and evidence equipment.',
    sections: [
      {
        title: 'Equipment Guide',
        blocks: [
          { type: 'table', headers: ['Item', 'Use'], rows: [
            ['Breath test device', 'Preliminary roadside alcohol test; evidential procedure normally follows at station or approved device.'],
            ['Drug wipe', 'Preliminary test for specified drugs where statutory conditions are met.'],
            ['Traffic cones/signs/flares or lamps', 'Scene warning and traffic management under trained safe systems.'],
            ['Evidence bags and seals', 'Package and preserve exhibits with continuity.'],
            ['Sharps tube', 'Safe seizure of needles/blades; never use soft packaging.'],
            ['Scene tape', 'Mark cordons; it is a visual boundary, not physical protection.'],
            ['Camera/scale markers', 'Record injuries, damage and exhibit position under policy.'],
            ['Fingerprint/forensic kits', 'Used by trained personnel to recover marks or samples.'],
          ] },
          { type: 'callout', tone: 'info', title: 'Before using a device', text: 'Check calibration/self-test, expiry, seal, serial number and your authority/training. Record the result and device details.' },
        ],
      },
    ],
  },

  'ethics-standards': {
    id: 'ethics-standards',
    title: 'Code of Ethics and Standards of Professional Behaviour',
    category: 'Policy & Standards',
    summary: 'Public service, integrity, fairness and accountability.',
    sections: [
      {
        title: 'Professional Expectations',
        blocks: [
          { type: 'bullets', items: ['Act with honesty and integrity.', 'Use authority, respect and courtesy fairly.', 'Do not discriminate and challenge improper conduct.', 'Keep information secure and use it only for policing purposes.', 'Report conflicts of interest, gifts, associations and misconduct.', 'Use force only when lawful, necessary and proportionate.', 'Remain fit for duty and maintain professional competence.', 'Be accountable for decisions and correct mistakes openly.'] },
          { type: 'decision', items: [
            { if: 'A colleague acts unlawfully or unethically', then: 'Intervene where safe, preserve evidence and report through supervision/professional standards or protected reporting routes.', otherwise: 'Continue to model and reinforce professional behaviour.' },
          ] },
        ],
      },
    ],
  },

  'information-management': {
    id: 'information-management',
    title: 'Information Management',
    category: 'Policy & Standards',
    summary: 'Data protection, lawful sharing, social media and operational security.',
    sections: [
      {
        title: 'Core Rules',
        blocks: [
          { type: 'bullets', items: ['Access police systems only for a legitimate policing purpose.', 'Record information accurately, objectively and with source/context.', 'Share only what is necessary, proportionate and lawful.', 'Use approved email, storage and messaging systems.', 'Do not discuss incidents or post images on personal social media.', 'Report misdirected data, lost devices and unauthorised access immediately.', 'Follow retention, review and deletion rules.'] },
          { type: 'callout', tone: 'danger', title: 'System misuse', text: 'Looking up friends, family, celebrities or vehicles without a policing purpose may be gross misconduct and a criminal/data protection offence.' },
        ],
      },
    ],
  },

  pursuits: {
    id: 'pursuits',
    title: 'Vehicle Pursuits',
    category: 'Policy & Standards',
    summary: 'Authorisation, dynamic risk and termination principles.',
    sections: [
      {
        title: 'Policy Principles',
        blocks: [
          { type: 'callout', tone: 'danger', title: 'Authorised drivers only', text: 'A vehicle failing to stop does not authorise every officer to pursue. Only trained and authorised drivers may initiate or continue as policy permits.' },
          { type: 'bullets', items: ['Immediately notify control and provide location, direction, vehicle, reason, speed, traffic, weather and risk.', 'Pursuit command and tactical oversight must follow force policy.', 'Continuously balance necessity against risk to public, officers and subject.', 'Consider air support, containment, tactical pursuit and containment options, intelligence-led arrest later and termination.', 'Terminate when risk is disproportionate or authorisation/communication is lost.', 'Record decisions and submit required pursuit documentation.'] },
          { type: 'decision', items: [
            { if: 'You are not appropriately trained/authorised', then: 'Do not pursue; update direction and observations and follow control instructions.', otherwise: 'Conduct the dynamic risk assessment and seek/maintain authorisation.' },
            { if: 'Public risk exceeds the necessity to continue', then: 'Terminate and confirm termination clearly to control.', otherwise: 'Continue only within training, law and policy while reassessing.' },
          ] },
        ],
      },
    ],
  },

  'complaints-force': {
    id: 'complaints-force',
    title: 'Complaints and Use-of-Force Recording',
    category: 'Policy & Standards',
    summary: 'Receiving complaints, preserving evidence and transparent records.',
    sections: [
      {
        title: 'Officer Responsibilities',
        blocks: [
          { type: 'bullets', items: ['Treat complaints seriously and do not discourage the person.', 'Record or route the complaint through approved force procedure.', 'Preserve BWV, CCTV, notes, radio logs and relevant documents.', 'Notify a supervisor promptly for serious injury, discrimination, corruption or serious conduct allegation.', 'Complete individual use-of-force records accurately and before end of duty where required.', 'Include legal power, threat assessment, tactics, duration, injury, aftercare and witnesses.'] },
          { type: 'callout', tone: 'info', title: 'Transparency', text: 'A complaint does not automatically mean force was unlawful. Accurate contemporaneous records allow the decision to be assessed fairly.' },
        ],
      },
    ],
  },

  'equality-human-rights': {
    id: 'equality-human-rights',
    title: 'Equality and Human Rights',
    category: 'Policy & Standards',
    summary: 'Fair policing, protected rights and proportionate interference.',
    sections: [
      {
        title: 'Operational Application',
        blocks: [
          { type: 'bullets', items: ['Make decisions on evidence and risk, not stereotypes.', 'Provide reasonable adjustments for disability and communication needs.', 'Use interpreters rather than family members for important legal communication where practicable.', 'Respect private and family life; any interference must have lawful authority and be necessary/proportionate.', 'Protect freedom of expression and assembly while addressing specific unlawful conduct.', 'Record equality-related hostility and consider hate crime policy.'] },
          { type: 'decision', items: [
            { if: 'A policing action affects a protected right', then: 'Identify the legal basis, legitimate aim, necessity and proportionality; consider a less intrusive option.', otherwise: 'Continue fair, respectful engagement and document relevant needs.' },
          ] },
        ],
      },
    ],
  },
};

export const allSearchablePages = [
  ...Object.values(policePages),
  { id: 'force-directory', title: 'UK Police Force Directory', category: 'Start Here', summary: 'All territorial and special police forces in the United Kingdom.', sections: [] },
  { id: 'quick-reference', title: 'Printable Quick Reference', category: 'Start Here', summary: 'A4 reference for caution, GOWISELY, arrest, NDM and radio.', sections: [] },
];

const collectBlockText = (block: ContentBlock): string => {
  if (block.type === 'paragraph' || block.type === 'quote' || block.type === 'callout') return `${'title' in block && block.title ? block.title : ''} ${block.text}`;
  if (block.type === 'bullets') return block.items.join(' ');
  if (block.type === 'steps') return block.items.map((item) => `${item.title} ${item.text}`).join(' ');
  if (block.type === 'table') return `${block.headers.join(' ')} ${block.rows.flat().join(' ')}`;
  if (block.type === 'decision') return block.items.map((item) => `${item.if} ${item.then} ${item.otherwise ?? ''}`).join(' ');
  return block.lines.join(' ');
};

export const getPageSearchText = (page: PolicePage): string =>
  [page.title, page.category, page.summary, page.jurisdiction ?? '', ...page.sections.flatMap((section) => [section.title, ...section.blocks.map(collectBlockText)])]
    .join(' ')
    .toLowerCase();
