export interface ParticleEmitterConfig {
  id: string;
  name: string;
  rate: number; // particles per second
  speed: number;
  lifetime: number; // seconds
  size: number;
  colorStart: string;
  colorEnd: string;
  gravity: number;
  spread: number;
  enabled: boolean;
}

export const PARTICLE_PRESETS: ParticleEmitterConfig[] = [
  {
    id: 'emit_sparks',
    name: 'Electric Sparks',
    rate: 80,
    speed: 4.5,
    lifetime: 1.2,
    size: 0.15,
    colorStart: '#06b6d4',
    colorEnd: '#3b82f6',
    gravity: -2.0,
    spread: 0.8,
    enabled: true,
  },
  {
    id: 'emit_campfire',
    name: 'Lantern Embers',
    rate: 45,
    speed: 2.0,
    lifetime: 2.0,
    size: 0.25,
    colorStart: '#f59e0b',
    colorEnd: '#ef4444',
    gravity: 0.8,
    spread: 0.4,
    enabled: true,
  },
  {
    id: 'emit_magic',
    name: 'Arcane Dust',
    rate: 60,
    speed: 1.5,
    lifetime: 2.5,
    size: 0.2,
    colorStart: '#a855f7',
    colorEnd: '#ec4899',
    gravity: 0.1,
    spread: 1.2,
    enabled: true,
  },
  {
    id: 'emit_smoke',
    name: 'Engine Exhaust Smoke',
    rate: 35,
    speed: 2.5,
    lifetime: 2.2,
    size: 0.4,
    colorStart: '#94a3b8',
    colorEnd: '#334155',
    gravity: 0.5,
    spread: 0.5,
    enabled: true,
  },
];
