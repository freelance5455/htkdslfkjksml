import { GiftItem, UserGiftRecord, UserProfile } from './types';
import { sendGiftFn, walletErrorMessage } from './wallet';

export const AVAILABLE_GIFTS: GiftItem[] = [
  {
    id: 'snowglobe_tree',
    name: 'كرة الثلج الكريستالية',
    icon: '🔮',
    cost: 999,
    costCoins: 9999,
    color: 'from-cyan-400 via-blue-500 to-indigo-600',
    category: 'royal',
    description: 'تحفة كروية كريستالية مع شجرة عيد ميلاد مضيئة وأضواء ساحرة'
  },
  {
    id: 'rose',
    name: 'وردة جورية متألقة',
    icon: '🌹',
    cost: 10,
    costCoins: 50,
    color: 'from-rose-500 to-pink-600',
    category: 'flowers',
    description: 'وردة جورية فاخرة متألقة تنبض بالمودة'
  },
  {
    id: 'lollipop',
    name: 'مصاصة السعادة الوردية',
    icon: '🍭',
    cost: 30,
    costCoins: 150,
    color: 'from-pink-400 via-rose-500 to-purple-500',
    category: 'special',
    description: 'مصاصة سكرية ملونة ومبهجة ترسم الابتسامة'
  },
  {
    id: 'rocket',
    name: 'صاروخ الفضاء المتألق',
    icon: '🚀',
    cost: 150,
    costCoins: 750,
    color: 'from-purple-600 via-indigo-600 to-cyan-500',
    category: 'luxury',
    description: 'صاروخ فضي فائق السرعة يخترق الأجواء'
  },
  {
    id: 'finger_heart',
    name: 'قلب الأصابع الكوري',
    icon: '🫰',
    cost: 45,
    costCoins: 225,
    color: 'from-pink-500 to-rose-400',
    category: 'special',
    description: 'لفتة لطيفة تعبر عن الحب والتقدير اللطيف'
  },
  {
    id: 'glowing_star',
    name: 'نجمة السعادة الساطعة',
    icon: '🌟',
    cost: 80,
    costCoins: 400,
    color: 'from-amber-300 via-yellow-400 to-amber-500',
    category: 'special',
    description: 'نجمة ذهبية متألقة تضيء سماء الغرفة'
  },
  {
    id: 'magic_mic',
    name: 'ميكروفون الغناء الذهبي',
    icon: '🎤',
    cost: 200,
    costCoins: 1000,
    color: 'from-rose-400 via-pink-500 to-purple-600',
    category: 'luxury',
    description: 'ميكروفون مرصع لأجمل الأداءات الصوتية في الغرف'
  },
  {
    id: 'planet_heart',
    name: 'كوكب القلوب الفضائي',
    icon: '🪐',
    cost: 500,
    costCoins: 2500,
    color: 'from-fuchsia-500 via-pink-500 to-cyan-400',
    category: 'royal',
    description: 'كوكب سحري تحيط به حلقات من القلوب المتوهجة'
  },
  {
    id: 'kisses',
    name: 'قبلات المحبة والود',
    icon: '💋',
    cost: 25,
    costCoins: 125,
    color: 'from-red-500 to-rose-600',
    category: 'special',
    description: 'قبلات دافئة ورقيقة تعبر عن المحبة والتقدير'
  },
  {
    id: 'love_letter',
    name: 'رسالة حب ذهبية',
    icon: '💌',
    cost: 40,
    costCoins: 200,
    color: 'from-pink-400 to-amber-500',
    category: 'special',
    description: 'رسالة ود مغلفة بنقاء ومحبة لا تنتهي'
  },
  {
    id: 'crown',
    name: 'تاج زهرة الملكي',
    icon: '👑',
    cost: 250,
    costCoins: 1250,
    color: 'from-yellow-400 to-amber-600',
    category: 'royal',
    description: 'تاج الملوك لأصحاب الحضور الراقي'
  },
  {
    id: 'diamond',
    name: 'زهرة الألماس البراقة',
    icon: '💎',
    cost: 500,
    costCoins: 2500,
    color: 'from-cyan-400 to-blue-600',
    category: 'royal',
    description: 'ألماسة نقية تعبر عن التقدير الخالص'
  }
];

/**
 * Buy a gift for your own bag, or send it to another user's profile.
 * The server checks the price and balance and moves the money; this only reports the result.
 */
export async function purchaseGift({
  currentUser,
  gift,
  currency,
  quantity = 1,
  targetRecipient
}: {
  currentUser: UserProfile;
  gift: GiftItem;
  currency: 'coins' | 'flowers';
  quantity?: number;
  targetRecipient?: { userId: string; displayName: string; photoURL?: string };
}): Promise<{ success: boolean; newCoins: number; newFlowers: number; error?: string }> {
  try {
    const res = await sendGiftFn({
      giftId: gift.id,
      currency,
      quantity,
      context: targetRecipient ? { type: 'profile', targetUserId: targetRecipient.userId } : { type: 'bag' }
    });
    return { success: true, newCoins: res.coins, newFlowers: res.flowersCount };
  } catch (err) {
    return {
      success: false,
      newCoins: currentUser.coins || 0,
      newFlowers: currentUser.flowersCount || 0,
      error: walletErrorMessage(err)
    };
  }
}
