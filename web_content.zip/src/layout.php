<?php require_once __DIR__.'/bootstrap.php'; ?>
<!doctype html><html lang="ps" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e(envv('APP_NAME','Ahmadi WiFi'))?></title><link rel="stylesheet" href="assets/style.css"></head><body>
<header><div class="brand">◉ احمدي وای فای <small>ISP MANAGER</small></div><nav><a href="index.php">ډشبورډ</a><a href="customers.php">مشتریان</a><a href="packages.php">پکیجونه</a><a href="billing.php">بیلونه</a><a href="mikrotik.php">MikroTik</a><a href="logout.php">وتل</a></nav></header><main>
