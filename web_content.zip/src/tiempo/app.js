/* ================= TiempoHoy — app principal ================= */
/* Script clásico cargado dentro del documento del tiempo: usa globals (L de Leaflet,
   moonPhase de astro.js) que el linter no puede resolver. */
/* eslint-disable no-undef */

const $ = id => document.getElementById(id);
const state = {
  lat: 37.4098, lon: -4.4889, name: 'Lucena',
  forecast: null, air: null, radarMeta: null,
  radarFrames: [], satFrames: [], frameIdx: 0,
  playing: false, timer: null, radarLayer: null, map: null,
  radarOpacity: 0.88, radarScheme: '4', radarSmooth: true, speed: 700,
};

const WEATHER = {
  0: ['Despejado', '☀️'], 1: ['Mayormente despejado', '🌤️'], 2: ['Parcialmente nublado', '⛅'],
  3: ['Nublado', '☁️'], 45: ['Niebla', '🌫️'], 48: ['Niebla con escarcha', '🌫️'],
  51: ['Llovizna débil', '🌦️'], 53: ['Llovizna', '🌦️'], 55: ['Llovizna intensa', '🌦️'],
  56: ['Llovizna helada', '🌧️'], 57: ['Llovizna helada intensa', '🌧️'],
  61: ['Lluvia débil', '🌧️'], 63: ['Lluvia', '🌧️'], 65: ['Lluvia fuerte', '🌧️'],
  66: ['Lluvia helada', '🌧️'], 67: ['Lluvia helada fuerte', '🌧️'],
  71: ['Nieve débil', '🌨️'], 73: ['Nieve', '🌨️'], 75: ['Nieve intensa', '❄️'], 77: ['Granos de nieve', '❄️'],
  80: ['Chubascos débiles', '🌦️'], 81: ['Chubascos', '🌦️'], 82: ['Chubascos violentos', '⛈️'],
  85: ['Chubascos de nieve', '🌨️'], 86: ['Chubascos de nieve fuertes', '❄️'],
  95: ['Tormenta', '⛈️'], 96: ['Tormenta con granizo', '⛈️'], 99: ['Tormenta fuerte con granizo', '⛈️'],
};
const wx = c => WEATHER[c] || ['—', '🌡️'];

const fmtH = iso => new Date(iso).getHours().toString().padStart(2, '0') + ':00';
const fmtHm = ts => new Date(ts * 1000).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });

/* ================= ARRANQUE ================= */
(function init() {
  // Limpiar cualquier service worker viejo que pudiera quedar cacheado
  navigator.serviceWorker?.getRegistrations?.().then(rs => rs.forEach(r => r.unregister())).catch(() => {});
  generateCompassTicks();
  bindSearch();
  $('btnLocate').addEventListener('click', useMyLocation);
  $('radarLocate').addEventListener('click', () => state.map && state.map.setView([state.lat, state.lon], 9));
  $('btnTop').addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  // Intentar geolocalización; si falla o tarda, Lucena por defecto
  let settled = false;
  const fallback = () => { if (!settled) { settled = true; loadAll(); } };
  const t = setTimeout(fallback, 5000);
  navigator.geolocation?.getCurrentPosition(
    pos => {
      clearTimeout(t);
      if (settled) { state.lat = pos.coords.latitude; state.lon = pos.coords.longitude; loadAll(); }
      else { settled = true; state.lat = pos.coords.latitude; state.lon = pos.coords.longitude; loadAll(); }
    },
    fallback,
    { timeout: 4500 }
  );
})();

function useMyLocation() {
  if (!navigator.geolocation) return;
  $('heroCity').textContent = 'Buscando…';
  navigator.geolocation.getCurrentPosition(
    pos => { state.lat = pos.coords.latitude; state.lon = pos.coords.longitude; loadAll(); },
    () => { $('heroDesc').textContent = 'No he podido obtener tu ubicación (revisa los permisos del navegador).'; },
    { timeout: 8000 }
  );
}

/* ================= CARGA DE DATOS ================= */
async function loadAll() {
  $('heroCity').textContent = state.name || 'Cargando…';
  const lat = state.lat.toFixed(4), lon = state.lon.toFixed(4);
  const fUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}`
    + `&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m`
    + `&minutely_15=precipitation,precipitation_probability&forecast_minutely_15=8`
    + `&hourly=temperature_2m,precipitation_probability,precipitation,weather_code,pressure_msl,cloud_cover,visibility,wind_speed_10m,wind_gusts_10m,uv_index,dew_point_2m`
    + `&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,daylight_duration,uv_index_max,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max`
    + `&past_days=1&forecast_days=7&timezone=auto`;
  const aUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}`
    + `&current=european_aqi,pm2_5,pm10,ozone,nitrogen_dioxide&timezone=auto`;

  try {
    const [fRes, aRes, rRes] = await Promise.all([
      fetch(fUrl), fetch(aUrl), fetch('https://api.rainviewer.com/public/weather-maps.json')
    ]);
    state.forecast = await fRes.json();
    state.air = await aRes.json();
    state.radarMeta = await rRes.json();
    state.radarFrames = [...(state.radarMeta.radar?.past || []), ...(state.radarMeta.radar?.nowcast || [])];
    state.satFrames = state.radarMeta.satellite?.infrared || [];
    state.frameIdx = Math.max(0, state.radarFrames.length - 4);

    // Región del usuario (para filtrar avisos oficiales por cercanía)
    try {
      const g = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=es`).then(r => r.json());
      if (!state.name || state.name === 'Cargando…') state.name = g.city || g.locality || g.principalSubdivision || 'Tu ubicación';
      state.regionNames = (g.localityInfo?.administrative || [])
        .map(a => a.adminName).filter(n => n && n.length > 3);
    } catch { if (!state.name || state.name === 'Cargando…') state.name = 'Tu ubicación'; }
    renderAll();
    if (!state.map) initRadar(); else updateRadarCenter();
    loadOfficialAvisos();
  } catch (e) {
    $('heroDesc').textContent = 'Error cargando datos. Comprueba tu conexión y recarga.';
    console.error(e);
  }
}

/* ================= RENDER GENERAL ================= */
function renderAll() {
  const f = state.forecast;
  const cur = f.current;
  const daily = f.daily, hourly = f.hourly;
  const todayIdx = 1; // past_days=1 → [0]=ayer
  const now = new Date();
  const ymd = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  // índice de la hora actual en hourly
  let hi = hourly.time.findIndex(t => t.slice(11, 13) == String(now.getHours()).padStart(2, '0') && t.slice(0, 10) === ymd);
  if (hi < 0) hi = 24;

  /* --- HERO --- */
  $('heroCity').textContent = state.name;
  $('heroTemp').textContent = Math.round(cur.temperature_2m);
  $('heroEmoji').textContent = !cur.is_day && cur.weather_code <= 2 ? '🌙' : wx(cur.weather_code)[1];
  $('heroDesc').textContent = wx(cur.weather_code)[0] + (cur.is_day ? ' · día' : ' · noche');
  $('chipFeels').textContent = `Sensación ${Math.round(cur.apparent_temperature)}°`;
  $('chipMinMax').textContent = `Máx ${Math.round(daily.temperature_2m_max[todayIdx])}° · Mín ${Math.round(daily.temperature_2m_min[todayIdx])}°`;
  $('msWind').textContent = `${Math.round(cur.wind_speed_10m)} km/h`;
  $('msHum').textContent = `${cur.relative_humidity_2m}%`;
  $('msPres').textContent = `${Math.round(cur.pressure_msl)} hPa`;
  $('msCloud').textContent = `${cur.cloud_cover}%`;

  /* vs ayer */
  const dMax = daily.temperature_2m_max[todayIdx] - daily.temperature_2m_max[0];
  const chip = $('chipYesterday');
  chip.hidden = false;
  if (Math.abs(dMax) < 1.5) chip.textContent = '≈ como ayer';
  else if (dMax > 0) chip.textContent = `▲ +${Math.round(dMax)}° vs ayer`;
  else chip.textContent = `▼ ${Math.round(dMax)}° vs ayer`;

  /* --- ALERTA DE LLUVIA --- */
  renderRainAlert(cur, hourly, hi);

  /* --- AVISOS (derivados) --- */
  renderDerivedAvisos(daily, todayIdx);

  /* --- VIENTO --- */
  const wd = cur.wind_direction_10m;
  $('compassNeedle').setAttribute('transform', `rotate(${wd} 100 100)`);
  $('windDir').textContent = `${Math.round(wd)}°`;
  $('windCardinal').textContent = cardinal(wd);
  $('windGusts').textContent = `Rachas ${Math.round(cur.wind_gusts_10m)} km/h`;
  $('windSpeed').textContent = `${Math.round(cur.wind_speed_10m)} km/h`;

  /* --- HUMEDAD --- */
  $('humVal').textContent = `${cur.relative_humidity_2m}%`;
  $('dewVal').textContent = `Rocío ${Math.round(hourly.dew_point_2m[hi])}°`;
  $('dropClipRect').setAttribute('y', 80 - 80 * cur.relative_humidity_2m / 100);

  /* --- PRESIÓN --- */
  const pres = cur.pressure_msl;
  $('pressVal').textContent = `${Math.round(pres)} hPa`;
  const frac = Math.min(1, Math.max(0, (pres - 960) / 90));
  $('pressArc').setAttribute('stroke-dashoffset', 267 * (1 - frac));
  const presBefore = hourly.pressure_msl[Math.max(0, hi - 3)];
  const dp = pres - presBefore;
  $('pressTrend').textContent = dp > 1 ? '↗ subiendo (mejora)' : dp < -1 ? '↘ bajando (inestable)' : '→ estable';

  /* --- VISIBILIDAD --- */
  const visKm = (hourly.visibility[hi] / 1000);
  $('visVal').textContent = visKm >= 10 ? '10+ km' : `${visKm.toFixed(1)} km`;
  $('visDesc').textContent = visKm >= 20 ? 'Excelente' : visKm >= 10 ? 'Buena' : visKm >= 4 ? 'Moderada' : visKm >= 1 ? 'Baja' : 'Muy baja';

  /* --- GRÁFICOS --- */
  renderTempChart(hourly, hi);
  renderUV(hourly, hi);

  /* --- CALIDAD DEL AIRE --- */
  renderAQI();

  /* --- SOL --- */
  renderSunClock(daily, todayIdx);

  /* --- LUNA --- */
  renderMoon();

  /* --- QUÉ LLEVAR --- */
  renderCarry(cur, daily, todayIdx);

  /* --- RESUMEN --- */
  renderSummary(state.name, daily, todayIdx);

  /* --- HOURLY / DAILY --- */
  renderHourly(hourly, hi);
  renderDaily(daily, todayIdx);
}

function cardinal(deg) {
  const dirs = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSO', 'SO', 'OSO', 'O', 'ONO', 'NO', 'NNO'];
  return dirs[Math.round(deg / 22.5) % 16];
}

/* ================= ALERTA DE LLUVIA ================= */
function renderRainAlert(cur, hourly, hi) {
  const box = $('rainAlert');
  const mins = state.forecast.minutely_15 || { time: [], precipitation: [] };
  const now = Date.now();
  let nextRainMin = null;
  for (let i = 0; i < mins.time.length; i++) {
    const t = new Date(mins.time[i]).getTime();
    if (t < now - 15 * 60000) continue;
    if ((mins.precipitation[i] || 0) > 0.05) { nextRainMin = Math.round((t - now) / 60000); break; }
  }
  // lluvia por horas (probabilidad)
  let probHour = null;
  for (let i = hi; i < Math.min(hi + 14, hourly.time.length); i++) {
    if ((hourly.precipitation_probability[i] || 0) >= 55 && (hourly.precipitation[i] || 0) > 0.1) {
      probHour = { t: hourly.time[i], p: hourly.precipitation_probability[i] };
      break;
    }
  }
  box.classList.remove('no-rain');
  if (nextRainMin !== null) {
    $('rainAlertIcon').textContent = '🌧️';
    $('rainAlertTitle').textContent = nextRainMin <= 5 ? 'Está empezando a llover' : `Va a llover en ~${nextRainMin} min`;
    $('rainAlertText').textContent = 'Según el radar de alta resolución, lluvia acercándose a tu zona.';
  } else if (probHour) {
    $('rainAlertIcon').textContent = '🌂';
    $('rainAlertTitle').textContent = `Lluvia probable a las ${fmtH(probHour.t)}`;
    $('rainAlertText').textContent = `Probabilidad del ${probHour.p}% en las próximas horas. Lleva paraguas.`;
  } else {
    box.classList.add('no-rain');
    $('rainAlertIcon').textContent = '🌤️';
    $('rainAlertTitle').textContent = 'Sin lluvia en las próximas horas';
    $('rainAlertText').textContent = 'No se espera precipitación cerca de ti en las próximas 12 horas.';
  }
  // Intensidad actual (mm de la hora actual → mm/h aprox)
  const intensity = cur.precipitation || 0;
  const segs = [...document.querySelectorAll('.ri-seg')];
  let acc = 0;
  segs.forEach(s => {
    s.classList.toggle('on', intensity > acc);
    acc = +s.dataset.max;
  });
}

/* ================= AVISOS ================= */
function renderDerivedAvisos(daily, todayIdx) {
  state.derived = [];
  const rain = daily.precipitation_sum[todayIdx];
  const gusts = daily.wind_gusts_10m_max[todayIdx];
  const tmax = daily.temperature_2m_max[todayIdx];
  const tmin = daily.temperature_2m_min[todayIdx];
  const uv = daily.uv_index_max[todayIdx];
  const code = daily.weather_code[todayIdx];
  const add = (level, emoji, text, zone) => state.derived.push({ level, emoji, text, zone });
  if (rain >= 40) add('orange', '🌧️', `Lluvias muy fuertes: ${rain.toFixed(0)} l/m² previstos hoy`, 'Previsión Open-Meteo');
  else if (rain >= 20) add('yellow', '🌧️', `Lluvias fuertes: ${rain.toFixed(0)} l/m² previstos hoy`, 'Previsión Open-Meteo');
  else if (rain >= 10) add('yellow', '🌦️', `Lluvias moderadas: ${rain.toFixed(0)} l/m² hoy`, 'Previsión Open-Meteo');
  if (gusts >= 100) add('orange', '💨', `Rachas de viento muy fuertes: ${Math.round(gusts)} km/h`, 'Previsión Open-Meteo');
  else if (gusts >= 70) add('yellow', '💨', `Rachas de viento fuertes: ${Math.round(gusts)} km/h`, 'Previsión Open-Meteo');
  if (tmax >= 40) add('orange', '🔥', `Calor extremo: máximo de ${Math.round(tmax)}° hoy`, 'Previsión Open-Meteo');
  else if (tmax >= 36) add('yellow', '🥵', `Calor muy intenso: máximo de ${Math.round(tmax)}°`, 'Previsión Open-Meteo');
  if (tmin <= -2) add('yellow', '🧊', `Heladas: mínimo de ${Math.round(tmin)}°`, 'Previsión Open-Meteo');
  if (uv >= 11) add('yellow', '☀️', `Radiación UV extrema: índice ${Math.round(uv)}`, 'Previsión Open-Meteo');
  else if (uv >= 8) add('yellow', '🧴', `UV muy alto: índice ${Math.round(uv)}, usa protección`, 'Previsión Open-Meteo');
  if ([95, 96, 99].includes(code)) add('yellow', '⛈️', 'Tormentas previstas hoy', 'Previsión Open-Meteo');
  if (!state.derived.length) state.derived.push({ level: 'green', emoji: '🛡️', text: 'Sin fenómenos adversos previstos hoy en tu zona', zone: 'Previsión Open-Meteo' });
  renderAvisos();
}

const normTxt = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

function distKm(lat1, lon1, lat2, lon2) {
  const p = Math.PI / 180, R = 6371;
  const a = Math.sin((lat2 - lat1) * p / 2) ** 2 + Math.cos(lat1 * p) * Math.cos(lat2 * p) * Math.sin((lon2 - lon1) * p / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

async function geocodeZone(name) {
  try {
    const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1&language=es&format=json`);
    const data = await res.json();
    if (data.results?.length) return { lat: data.results[0].latitude, lon: data.results[0].longitude };
  } catch { /* sin resultado */ }
  return null;
}

async function loadOfficialAvisos() {
  const feed = 'https://feeds.meteoalarm.org/feeds/meteoalarm-legacy-atom-spain';
  const proxies = [
    u => 'https://api.allorigins.win/raw?url=' + encodeURIComponent(u),
    u => 'https://api.codetabs.com/v1/proxy?quest=' + encodeURIComponent(u),
    u => 'https://proxy.corsfix.com/?' + u,
    u => u,
  ];
  let xml = null;
  for (const p of proxies) {
    try {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), 3500);
      const res = await fetch(p(feed), { signal: ctrl.signal });
      clearTimeout(to);
      if (res.ok) { xml = await res.text(); if (xml.includes('<entry')) break; xml = null; }
    } catch { /* siguiente */ }
  }
  if (!xml) { $('avisosNote').textContent = 'Calculados con la previsión (fuente oficial no disponible)'; renderAvisos(); return; }
  try {
    const doc = new DOMParser().parseFromString(xml, 'text/xml');
    const entries = [...doc.querySelectorAll('entry')];
    const parsed = entries.map(e => {
      const title = e.querySelector('title')?.textContent || '';
      const m = title.match(/^(Yellow|Orange|Red)\s+(.+?)\s+Warning.*?-\s+(.+)$/);
      if (!m) return null;
      const types = { Rain: 'Lluvia', Thunderstorm: 'Tormenta', Wind: 'Viento', Snow: 'Nieve', 'Coastalevent': 'Fenómeno costero', Fog: 'Niebla', Ice: 'Hielo', 'High temperature': 'Calor', 'Low temperature': 'Frío' };
      const levels = { Yellow: 'yellow', Orange: 'orange', Red: 'red' };
      return { level: levels[m[1]], emoji: { Lluvia: '🌧️', Tormenta: '⛈️', Viento: '💨', Nieve: '❄️', 'Fenómeno costero': '🌊', Niebla: '🌫️', Hielo: '🧊', Calor: '🥵', Frío: '🥶' }[types[m[2]]] || '⚠️',
        text: `Aviso ${levels[m[1]] === 'red' ? 'rojo' : levels[m[1]] === 'orange' ? 'naranja' : 'amarillo'} de ${types[m[2]]?.toLowerCase() || m[2].toLowerCase()}`, zone: m[3] };
    }).filter(Boolean);
    // Filtrar: solo avisos de la región del usuario o a menos de 100 km
    const near = [];
    for (const a of parsed) {
      const zoneN = normTxt(a.zone);
      const inRegion = (state.regionNames || []).some(r => zoneN.includes(normTxt(r)));
      if (inRegion) { near.push(a); continue; }
      const geo = await geocodeZone(a.zone);
      if (geo && distKm(state.lat, state.lon, geo.lat, geo.lon) <= 100) near.push(a);
    }
    state.official = near.slice(0, 4);
    $('avisosNote').textContent = state.official.length
      ? 'Avisos oficiales AEMET · cerca de tu ubicación'
      : 'Sin avisos oficiales AEMET en tu zona';
  } catch { $('avisosNote').textContent = 'Calculados con la previsión'; }
  renderAvisos();
}

function renderAvisos() {
  const list = $('avisosList');
  const items = [...(state.official || []), ...(state.derived || [])].slice(0, 8);
  if (!items.length) { list.innerHTML = '<div class="aviso-empty">Sin avisos.</div>'; return; }
  list.innerHTML = items.map(a => `
    <div class="aviso level-${a.level}">
      <span class="aviso-emoji">${a.emoji}</span>
      <span class="aviso-text"><b>${a.text}</b><span class="aviso-zone">${a.zone}</span></span>
    </div>`).join('');
}

/* ================= BRÚJULA ================= */
function generateCompassTicks() {
  const g = $('compassTicks');
  let html = '';
  for (let a = 0; a < 360; a += 30) {
    const long = a % 90 === 0;
    const r1 = long ? 78 : 84, r2 = 92;
    html += `<line class="tick" x1="${100 + r1 * Math.sin(a * Math.PI / 180)}" y1="${100 - r1 * Math.cos(a * Math.PI / 180)}" x2="${100 + r2 * Math.sin(a * Math.PI / 180)}" y2="${100 - r2 * Math.cos(a * Math.PI / 180)}" ${long ? 'stroke-width="2"' : ''}/>`;
  }
  g.innerHTML = html;
}

/* ================= GRÁFICO TEMPERATURA ================= */
function renderTempChart(hourly, hi) {
  const start = Math.max(0, hi - 24), end = Math.min(hourly.time.length, hi + 25);
  const temps = hourly.temperature_2m.slice(start, end);
  const times = hourly.time.slice(start, end);
  const min = Math.floor(Math.min(...temps) - 1), max = Math.ceil(Math.max(...temps) + 1);
  const W = 720, H = 190, PADL = 34, PADR = 10, PADT = 14, PADB = 26;
  const x = i => PADL + (W - PADL - PADR) * i / (temps.length - 1);
  const y = t => PADT + (H - PADT - PADB) * (1 - (t - min) / (max - min));
  let path = '', area = '';
  temps.forEach((t, i) => { const X = x(i), Y = y(t); path += (i ? 'L' : 'M') + X.toFixed(1) + ' ' + Y.toFixed(1); });
  area = path + `L${x(temps.length - 1).toFixed(1)} ${H - PADB} L${PADL} ${H - PADB} Z`;
  const nowX = x(24);
  const grid = [min, Math.round((min + max) / 2), max];
  let labels = '';
  times.forEach((t, i) => {
    if (i % 6 === 0 && x(i) < W - 45) labels += `<text x="${x(i)}" y="${H - 8}" class="ax">${t.slice(11, 16)}</text>`;
  });
  const tempMinIdx = temps.indexOf(Math.min(...temps)), tempMaxIdx = temps.indexOf(Math.max(...temps));
  $('tempChartWrap').innerHTML = `
  <svg viewBox="0 0 ${W} ${H}">
    <defs><linearGradient id="tg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5ec5ff" stop-opacity=".35"/><stop offset="1" stop-color="#5ec5ff" stop-opacity="0"/></linearGradient></defs>
    ${grid.map(g => `<line x1="${PADL}" y1="${y(g)}" x2="${W - PADR}" y2="${y(g)}" stroke="rgba(255,255,255,.07)"/><text x="4" y="${y(g) + 4}" class="ax">${g}°</text>`).join('')}
    ${labels}
    <line x1="${nowX}" y1="${PADT}" x2="${nowX}" y2="${H - PADB}" stroke="#ffb454" stroke-dasharray="3 4"/>
    <text x="${nowX + 4}" y="${PADT + 10}" class="ax" fill="#ffb454">ahora</text>
    <path d="${area}" fill="url(#tg)"/>
    <path d="${path}" fill="none" stroke="#5ec5ff" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
    <circle cx="${x(tempMaxIdx)}" cy="${y(temps[tempMaxIdx])}" r="3" fill="#ffb454"/>
    <text x="${x(tempMaxIdx)}" y="${y(temps[tempMaxIdx]) - 9}" class="ax hl">${Math.round(temps[tempMaxIdx])}°</text>
    <circle cx="${x(tempMinIdx)}" cy="${y(temps[tempMinIdx])}" r="3" fill="#5ec5ff"/>
    <text x="${x(tempMinIdx)}" y="${y(temps[tempMinIdx]) + 16}" class="ax hl">${Math.round(temps[tempMinIdx])}°</text>
  </svg>
  <style>.ax{font:10px 'Geist Mono',monospace;fill:#8b98b8}.hl{fill:#eef2fb;font-weight:600}</style>`;
}

/* ================= UV ================= */
function renderUV(hourly, hi) {
  const start = hi, end = Math.min(hourly.time.length, hi + 24);
  const uvs = hourly.uv_index.slice(start, end);
  const times = hourly.time.slice(start, end);
  const maxUv = Math.max(2, ...uvs);
  const uvColor = v => v < 3 ? '#6daa45' : v < 6 ? '#e8d53c' : v < 8 ? '#e8963c' : v < 11 ? '#e83c3c' : '#8f2e8f';
  const uvLabel = v => v < 3 ? 'bajo' : v < 6 ? 'moderado' : v < 8 ? 'alto' : v < 11 ? 'muy alto' : 'extremo';
  const cur = uvs[0] || 0;
  $('uvNow').textContent = `Ahora: ${cur.toFixed(1)} (${uvLabel(cur)})`;
  $('uvAdvice').textContent = cur < 3 ? 'Sin protección necesaria.' : cur < 6 ? 'Usa crema solar si estás al sol más de 30 min.' : cur < 8 ? 'Protección alta: sombra, crema y gorra.' : cur < 11 ? 'Evita el sol directo al mediodía (12–16 h).' : 'Radiación extrema: evita salir al sol.';
  const W = 720, H = 135, PADB = 22, PADT = 12;
  const bw = (W - 20) / uvs.length;
  let bars = '', labels = '';
  uvs.forEach((v, i) => {
    const h = (H - PADB - PADT) * v / maxUv;
    bars += `<rect x="${10 + i * bw + 1}" y="${H - PADB - h}" width="${bw - 2}" height="${h}" rx="2" fill="${uvColor(v)}" opacity="${i === 0 ? 1 : .75}"/>`;
    if (i % 3 === 0) labels += `<text x="${10 + i * bw + bw / 2}" y="${H - 8}" text-anchor="middle" class="ax">${times[i].slice(11, 16)}</text>`;
  });
  $('uvChartWrap').innerHTML = `<svg viewBox="0 0 ${W} ${H}">${bars}${labels}</svg><style>.ax{font:10px 'Geist Mono',monospace;fill:#8b98b8}</style>`;
}

/* ================= CALIDAD DEL AIRE ================= */
function renderAQI() {
  const a = state.air?.current;
  if (!a) return;
  const aqi = a.european_aqi;
  const cat = v => v <= 20 ? ['Excelente', '#50f0e6'] : v <= 40 ? ['Buena', '#50ccaa'] : v <= 60 ? ['Moderada', '#f0e641'] : v <= 80 ? ['Mala', '#ff5050'] : v <= 100 ? ['Muy mala', '#960032'] : ['Extrema', '#7d2181'];
  const [cname, ccolor] = cat(aqi);
  $('aqiNum').textContent = Math.round(aqi);
  $('aqiCat').textContent = cname;
  $('aqiCat').setAttribute('fill', ccolor);
  $('aqiArc').setAttribute('stroke', ccolor);
  $('aqiArc').setAttribute('stroke-dashoffset', 440 * (1 - Math.min(aqi, 120) / 120));
  const badge = $('aqiBadge');
  badge.textContent = `EAQI ${Math.round(aqi)} · ${cname}`;
  badge.style.background = ccolor + '33';
  badge.style.border = `1px solid ${ccolor}66`;
  const poll = [
    { n: 'PM2.5', v: a.pm2_5, max: 50, color: '#e8963c' },
    { n: 'PM10', v: a.pm10, max: 80, color: '#e8d53c' },
    { n: 'O3', v: a.ozone, max: 180, color: '#5ec5ff' },
    { n: 'NO2', v: a.nitrogen_dioxide, max: 150, color: '#8f7bff' },
  ];
  $('aqiBars').innerHTML = poll.map(p => `
    <div class="aqi-bar-row">
      <span class="aqi-bar-label">${p.n}</span>
      <div class="aqi-bar-track"><div class="aqi-bar-fill" style="width:${Math.min(100, p.v / p.max * 100)}%;background:${p.color}"></div></div>
      <span class="aqi-bar-val">${Math.round(p.v)} µg/m³</span>
    </div>`).join('');
}

/* ================= RELOJ SOLAR ================= */
function renderSunClock(daily, todayIdx) {
  const sr = new Date(daily.sunrise[todayIdx]), ss = new Date(daily.sunset[todayIdx]);
  $('sunriseVal').textContent = sr.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
  $('sunsetVal').textContent = ss.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
  const dur = daily.daylight_duration[todayIdx] / 3600;
  $('dayLenVal').textContent = `${Math.floor(dur)} h ${Math.round((dur % 1) * 60)} min`;
  const now = new Date();
  const f = (now - sr) / (ss - sr);
  const sun = $('sunPos');
  if (f >= 0 && f <= 1) {
    const a = Math.PI * (1 - f);
    // arco circular de radio 170, centro (160,220): ángulos 2.4981 (amanecer) a 0.6435 (atardecer)
    const th = 2.4981 - f * 1.8546;
    sun.setAttribute('transform', `translate(${(160 + 170 * Math.cos(th)).toFixed(1)},${(220 - 170 * Math.sin(th)).toFixed(1)})`);
    sun.style.opacity = 1;
  } else {
    sun.style.opacity = 0.25;
    sun.setAttribute('transform', `translate(${f < 0 ? 24 : 296},118)`);
  }
  // hora dorada (atardecer -1h a -20min) y hora azul (atardecer +25min aprox)
  const g = new Date(ss - 55 * 60000);
  $('goldenVal').textContent = `${g.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} – ${ss.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`;
  const b = new Date(ss.getTime() + 25 * 60000);
  $('blueVal').textContent = `≈ ${b.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`;
}

/* ================= FASE LUNAR ================= */
function renderMoon() {
  const d = (Date.now() / 86400000) - 10956.0;
  const ph = moonPhase(d);
  $('moonName').textContent = ph.name;
  $('moonIllum').textContent = `${Math.round(ph.illum * 100)}% iluminada`;
  const k = ph.illum;
  const rx = Math.abs(1 - 2 * k) * 46;
  let path;
  if (ph.waxing) {
    path = k < 0.5
      ? `M 80 34 A ${rx} 46 0 0 1 80 126 A 46 46 0 0 0 80 34 Z`
      : `M 80 34 A 46 46 0 0 1 80 126 A ${rx} 46 0 0 1 80 34 Z`;
  } else {
    path = k < 0.5
      ? `M 80 34 A ${rx} 46 0 0 0 80 126 A 46 46 0 0 1 80 34 Z`
      : `M 80 34 A 46 46 0 0 0 80 126 A ${rx} 46 0 0 0 80 34 Z`;
  }
  $('moonPhasePath').setAttribute('d', path);
}

/* ================= QUÉ LLEVAR ================= */
function renderCarry(cur, daily, todayIdx) {
  const items = [];
  const t = cur.temperature_2m;
  const rainProb = daily.precipitation_probability_max[todayIdx];
  const rainSum = daily.precipitation_sum[todayIdx];
  const gusts = daily.wind_gusts_10m_max[todayIdx];
  const uv = daily.uv_index_max[todayIdx];
  if (rainProb >= 45 || rainSum >= 3) items.push(['🌂', 'Paraguas o chubasquero']);
  if (rainSum >= 10) items.push(['🥾', 'Calzado impermeable']);
  if (t <= 2) { items.push(['🧥', 'Abrigo']); items.push(['🧤', 'Gorro y guantes']); }
  else if (t <= 10) items.push(['🧥', 'Abrigo']);
  else if (t <= 17) items.push(['🧥', 'Chaqueta o sudadera']);
  else if (t >= 30) items.push(['👕', 'Ropa ligera y clara']);
  if (gusts >= 60) items.push(['💨', 'Cortavientos']);
  if (uv >= 3 && cur.is_day) items.push(['🧴', `Protector solar (UV ${Math.round(uv)})`]);
  if (cur.cloud_cover < 55 && cur.is_day) items.push(['🕶️', 'Gafas de sol']);
  if (cur.relative_humidity_2m <= 35) items.push(['💧', 'Botella de agua']);
  if (!items.length) items.push(['👌', 'No necesitas nada especial']);
  $('carryList').innerHTML = items.map(([e, t]) => `<li class="carry-item"><span>${e}</span><span>${t}</span></li>`).join('');
}

/* ================= RESUMEN ================= */
function renderSummary(place, daily, todayIdx) {
  const code = daily.weather_code[todayIdx];
  const tmax = Math.round(daily.temperature_2m_max[todayIdx]);
  const tmin = Math.round(daily.temperature_2m_min[todayIdx]);
  const rainP = daily.precipitation_probability_max[todayIdx];
  const rain = daily.precipitation_sum[todayIdx];
  const gusts = Math.round(daily.wind_gusts_10m_max[todayIdx]);
  let p1 = `Hoy en ${place} el cielo estará ${code <= 1 ? 'despejado o poco nuboso' : code === 2 ? 'con nubes dispersas' : code === 3 ? 'nublado' : 'con niebla'}.`;
  if ([51,53,55,61,63,65,80,81,82].includes(code)) p1 = `Hoy en ${place} habrá ${code >= 80 ? 'chubascos' : 'lluvia'}${code >= 63 ? ' que pueden ser intensos' : ' débil'}.`;
  if ([95,96,99].includes(code)) p1 = `Hoy en ${place} hay riesgo de tormenta.`;
  const p2 = ` Las temperaturas irán de ${tmin}° a ${tmax}°${tmax - tmin >= 12 ? ', con bastante contraste entre día y noche' : ''}.`;
  const p3 = rain > 0.2 ? ` Se esperan unos ${rain.toFixed(1)} l/m² (probabilidad máxima del ${rainP}%).` : ` La probabilidad de lluvia es del ${rainP}%.`;
  const p4 = gusts >= 50 ? ` El viento soplará con rachas de hasta ${gusts} km/h.` : '';
  $('daySummary').textContent = p1 + p2 + p3 + p4;
  const dMax = Math.round(daily.temperature_2m_max[todayIdx] - daily.temperature_2m_max[0]);
  $('vsYesterday').innerHTML = dMax === 0 || Math.abs(dMax) < 1.5
    ? 'Hoy hará una temperatura similar a la de ayer.'
    : dMax > 0 ? `Hoy hará <span class="up">${dMax}° más</span> que ayer.`
    : `Hoy hará <span class="down">${Math.abs(dMax)}° menos</span> que ayer.`;
}

/* ================= HOURLY ================= */
function renderHourly(hourly, hi) {
  let html = '';
  for (let i = hi; i < Math.min(hi + 25, hourly.time.length); i++) {
    const nowMark = i === hi ? ' now' : '';
    const p = hourly.precipitation_probability[i] || 0;
    const r = p >= 30 ? p + '%' : '—';
    html += `<div class="hour-cell${nowMark}">
      <span class="hour-time">${i === hi ? 'Ahora' : fmtH(hourly.time[i])}</span>
      <span class="hour-emoji">${wx(hourly.weather_code[i])[1]}</span>
      <span class="hour-temp">${Math.round(hourly.temperature_2m[i])}°</span>
      <span class="hour-rain ${p < 30 ? 'dry' : ''}">💧 ${r}</span>
    </div>`;
  }
  $('hourlyScroll').innerHTML = html;
}

/* ================= DAILY ================= */
function renderDaily(daily, todayIdx) {
  const days = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
  const allMin = Math.min(...daily.temperature_2m_min.slice(todayIdx, todayIdx + 7));
  const allMax = Math.max(...daily.temperature_2m_max.slice(todayIdx, todayIdx + 7));
  let html = '';
  for (let i = todayIdx; i < todayIdx + 7; i++) {
    const d = new Date(daily.time[i]);
    const tmin = daily.temperature_2m_min[i], tmax = daily.temperature_2m_max[i];
    const left = (tmin - allMin) / (allMax - allMin) * 100;
    const width = (tmax - tmin) / (allMax - allMin) * 100;
    const p = daily.precipitation_probability_max[i] || 0;
    html += `<div class="day-row">
      <span class="day-name">${i === todayIdx ? 'Hoy' : days[d.getDay()]}<small>${daily.time[i].slice(5).split('-').reverse().join('/')}</small></span>
      <span class="day-emoji">${wx(daily.weather_code[i])[1]}</span>
      <div class="day-bar-wrap"><div class="day-bar"><div class="day-bar-fill" style="left:${left}%;width:${Math.max(8, width)}%"></div></div></div>
      <span class="day-temps">${Math.round(tmax)}° / ${Math.round(tmin)}°</span>
      <span class="day-rain ${p < 30 ? 'dry' : ''}">💧 ${p}%</span>
    </div>`;
  }
  $('dailyList').innerHTML = html;
}

/* ================= RADAR ================= */
function initRadar() {
  const map = L.map('radarMap', {
    center: [state.lat, state.lon], zoom: 7, zoomControl: false, minZoom: 3, maxZoom: 12,
    attributionControl: false,
  });
  state.map = map;
  const base = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 16,
  }).addTo(map);
  // Oscurecer el mapa base para que el radar destaque
  base.getContainer().style.filter = 'brightness(0.55) saturate(0.5)';
  // Marcador de posición
  L.circleMarker([state.lat, state.lon], { radius: 7, color: '#5ec5ff', fillColor: '#5ec5ff', fillOpacity: .9, weight: 2 })
    .addTo(map).bindTooltip(state.name, { direction: 'top' });

  map.createPane('labels');
  map.getPane('labels').style.zIndex = 450;
  const labels = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', { maxZoom: 16, pane: 'labels' });
  labels.addTo(map);

  const timeline = $('radarTimeline');
  timeline.max = state.radarFrames.length - 1;
  timeline.value = state.frameIdx;

  timeline.addEventListener('input', () => { pauseRadar(); showFrame(+timeline.value); });

  $('radarPlay').addEventListener('click', () => state.playing ? pauseRadar() : playRadar());
  $('zoomIn').addEventListener('click', () => map.zoomIn());
  $('zoomOut').addEventListener('click', () => map.zoomOut());
  map.on('zoomend', () => { $('zoomLevel').textContent = map.getZoom(); });
  $('zoomLevel').textContent = map.getZoom();

  $('radarScheme').addEventListener('change', e => { state.radarScheme = e.target.value; showFrame(state.frameIdx); });
  $('radarSmooth').addEventListener('change', e => { state.radarSmooth = e.target.checked; showFrame(state.frameIdx); });
  $('radarOpacity').addEventListener('input', e => {
    state.radarOpacity = e.target.value / 100;
    if (state.radarLayer) state.radarLayer.setOpacity(state.radarOpacity);
  });
  $('radarSpeed').addEventListener('change', e => {
    state.speed = +e.target.value;
    if (state.playing) { pauseRadar(); playRadar(); }
  });

  showFrame(state.frameIdx);
  setTimeout(() => { $('radarLoading').classList.add('hidden'); }, 600);
}

function frameTilesUrl(frame) {
  const host = state.radarMeta.host;
  return `${host}${frame.path}/256/{z}/{x}/{y}/${state.radarScheme}/${state.radarSmooth ? 1 : 0}_1.png`;
}

function showFrame(idx) {
  const frames = state.radarFrames;
  if (!frames.length) return;
  idx = Math.min(idx, frames.length - 1);
  state.frameIdx = idx;
  $('radarTimeline').max = frames.length - 1;
  const frame = frames[idx];
  const url = frameTilesUrl(frame);
  if (state.radarLayer) state.map.removeLayer(state.radarLayer);
  state.radarLayer = L.tileLayer(url, { opacity: state.radarOpacity, tileSize: 256, zIndex: 400, maxNativeZoom: 7, maxZoom: 12 });
  state.radarLayer.addTo(state.map);
  // reloj
  const now = Date.now() / 1000;
  const diff = Math.round((frame.time - now) / 60);
  const cls = diff > 2 ? 'Previsión' : diff < -2 ? 'Hace ' + Math.abs(diff) + ' min' : 'Ahora';
  $('radarClock').innerHTML = `${fmtHm(frame.time)}<span class="rc-sub">${cls}</span>`;
}

function playRadar() {
  state.playing = true;
  $('iconPlay').style.display = 'none';
  $('iconPause').style.display = 'block';
  state.timer = setInterval(() => {
    const frames = state.radarFrames;
    state.frameIdx = (state.frameIdx + 1) % frames.length;
    $('radarTimeline').value = state.frameIdx;
    showFrame(state.frameIdx);
  }, state.speed);
}
function pauseRadar() {
  state.playing = false;
  $('iconPlay').style.display = 'block';
  $('iconPause').style.display = 'none';
  clearInterval(state.timer);
}

function updateRadarCenter() {
  if (!state.map) return;
  state.map.setView([state.lat, state.lon], state.map.getZoom());
}

/* Auto-refresh del radar cada 5 min */
setInterval(async () => {
  try {
    const res = await fetch('https://api.rainviewer.com/public/weather-maps.json');
    const meta = await res.json();
    state.radarMeta = meta;
    state.radarFrames = [...(meta.radar?.past || []), ...(meta.radar?.nowcast || [])];
    state.satFrames = meta.satellite?.infrared || [];
    if (!state.playing) showFrame(state.frameIdx);
  } catch { /* silencio */ }
}, 300000);

/* ================= BÚSQUEDA ================= */
function bindSearch() {
  const panel = $('searchPanel'), input = $('searchInput'), results = $('searchResults');
  $('btnSearch').addEventListener('click', () => {
    panel.hidden = !panel.hidden;
    if (!panel.hidden) input.focus();
  });
  $('searchClose').addEventListener('click', () => { panel.hidden = true; results.innerHTML = ''; });
  let t;
  input.addEventListener('input', () => {
    clearTimeout(t);
    const q = input.value.trim();
    if (q.length < 2) { results.innerHTML = ''; return; }
    t = setTimeout(async () => {
      try {
        const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=8&language=es&format=json`);
        const data = await res.json();
        if (!data.results?.length) { results.innerHTML = '<li><span class="sr-sub">Sin resultados</span></li>'; return; }
        results.innerHTML = data.results.map(r =>
          `<li data-lat="${r.latitude}" data-lon="${r.longitude}" data-name="${r.name}">
            <div class="sr-name">${r.name}</div>
            <div class="sr-sub">${[r.admin1, r.country].filter(Boolean).join(', ')}</div>
          </li>`).join('');
        results.querySelectorAll('li[data-lat]').forEach(li => {
          li.addEventListener('click', () => {
            state.lat = +li.dataset.lat;
            state.lon = +li.dataset.lon;
            state.name = li.dataset.name;
            panel.hidden = true;
            results.innerHTML = '';
            input.value = '';
            loadAll();
          });
        });
      } catch { results.innerHTML = '<li><span class="sr-sub">Error buscando</span></li>'; }
    }, 350);
  });
}