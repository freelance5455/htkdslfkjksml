/* ============ Astronomía ============
   Algoritmos basados en Paul Schlyter ( HOW TO COMPUTE PLANET POSITIONS ).
   Precisión ~1 arcmin para planetas, ~0.2° para la Luna: suficiente para un mapa del cielo. */

const RAD = Math.PI / 180;
const rev = x => ((x % 360) + 360) % 360;
const sin = d => Math.sin(d * RAD);
const cos = d => Math.cos(d * RAD);

/* Días desde J2000 (2000-01-01 12:00 UTC) */
function daysSinceJ2000(date) {
  return date.getTime() / 86400000 - 10956.0;
}

/* ---- Sol: longitud eclíptica geocéntrica y distancia ---- */
function sunPosition(d) {
  const w = 282.9404 + 4.70935e-5 * d;
  const e = 0.016709 - 1.151e-9 * d;
  const M = rev(356.0470 + 0.9856002585 * d);
  const E = M + (e / RAD) * sin(M) * (1 + e * cos(M));
  const x = cos(E) - e;
  const y = sin(E) * Math.sqrt(1 - e * e);
  const r = Math.sqrt(x * x + y * y);
  const v = Math.atan2(y, x) / RAD;
  const lon = rev(v + w);
  return { lon, r }; // r en UA
}

/* ---- Kepler: resuelve ecuación de Kepler en grados ---- */
function kepler(M, e) {
  let E0 = M + (e / RAD) * sin(M) * (1 + e * cos(M));
  let E1 = 0, delta = 1;
  while (Math.abs(delta) > 1e-6) {
    const dM = M - (E0 - (e / RAD) * sin(E0));
    E1 = E0 + dM / (1 - e * cos(E0));
    delta = E1 - E0;
    E0 = E1;
  }
  return E0;
}

/* ---- Elementos orbitales de planetas (época d=0, Schlyter) ---- */
const PLANET_ELEMENTS = {
  mercurio: { N: 48.3313, i: 7.0047, w: 29.1241, a: 0.387098, e: 0.205635, M: 168.6562, rateN: 3.24587e-5, ratei: 1.05e-8, ratew: 7.74e-6, rateM: 4.0923344368 },
  venus:    { N: 76.6799, i: 3.3946, w: 54.8910, a: 0.723330, e: 0.006773, M: 48.0052,  rateN: 3.89894e-5, ratei: 3.45e-8,  ratew: 8.87e-6,  rateM: 1.6021302244 },
  marte:    { N: 49.5574, i: 1.8497, w: 286.5016, a: 1.523688, e: 0.093405, M: 18.6021, rateN: 7.79e-6,  ratei: 1.58e-8,  ratew: 1.7769e-5, rateM: 0.5240207766 },
  jupiter:  { N: 100.4542, i: 1.3030, w: 273.8777, a: 5.20256, e: 0.048498, M: 19.8950, rateN: 2.2289e-4, ratei: -1.518e-7, ratew: 1.6439e-5, rateM: 8.437694e-3 },
  saturno:  { N: 113.6634, i: 2.4886, w: 339.3939, a: 9.55475, e: 0.055546, M: 316.9670, rateN: 2.391e-4, ratei: -1.919e-7, ratew: 2.2275e-5, rateM: 3.385766e-3 },
};

/* Posición heliocéntrica eclíptica rectangular de un planeta */
function heliocentric(planet, d) {
  const p = PLANET_ELEMENTS[planet];
  const N = rev(p.N + p.rateN * d);
  const i = p.i + p.ratei * d;
  const w = rev(p.w + p.ratew * d);
  const a = p.a;
  const e = p.e;
  const M = rev(p.M + p.rateM * d);
  const E = kepler(M, e);
  const xv = a * (cos(E) - e);
  const yv = a * Math.sqrt(1 - e * e) * sin(E);
  const v = Math.atan2(yv, xv) / RAD;
  const r = Math.sqrt(xv * xv + yv * yv);
  const xh = r * (cos(N) * cos(v + w) - sin(N) * sin(v + w) * cos(i));
  const yh = r * (sin(N) * cos(v + w) + cos(N) * sin(v + w) * cos(i));
  const zh = r * sin(v + w) * sin(i);
  return { x: xh, y: yh, z: zh, r };
}

/* Eclíptica → RA/Dec (grados) */
function eclToRaDec(lon, lat, d) {
  const ecl = 23.4393 - 3.563e-7 * d;
  const x = cos(lon) * cos(lat);
  const y = sin(lon) * cos(lat);
  const z = sin(lat);
  const xr = x;
  const yr = y * cos(ecl) - z * sin(ecl);
  const zr = y * sin(ecl) + z * cos(ecl);
  const ra = Math.atan2(yr, xr) / RAD;
  const dec = Math.atan2(zr, Math.sqrt(xr * xr + yr * yr)) / RAD;
  return { ra: rev(ra), dec };
}

/* ---- Luna: longitud/latitud geocéntricas con perturbaciones ---- */
function moonPosition(d) {
  const N = rev(125.1228 - 0.0529538083 * d);
  const i = 5.1454;
  const w = rev(318.0634 + 0.1643573223 * d);
  const a = 60.2666; // radios terrestres
  const e = 0.054900;
  const M = rev(115.3654 + 13.0649929509 * d);
  const E = kepler(M, e);
  const xv = a * (cos(E) - e);
  const yv = a * Math.sqrt(1 - e * e) * sin(E);
  const v = Math.atan2(yv, xv) / RAD;
  const r = Math.sqrt(xv * xv + yv * yv);
  let xh = r * (cos(N) * cos(v + w) - sin(N) * sin(v + w) * cos(i));
  let yh = r * (sin(N) * cos(v + w) + cos(N) * sin(v + w) * cos(i));
  let zh = r * sin(v + w) * sin(i);

  let lon = Math.atan2(yh, xh) / RAD;
  let lat = Math.atan2(zh, Math.sqrt(xh * xh + yh * yh)) / RAD;

  // Perturbaciones principales (Schlyter)
  const Ms = rev(356.0470 + 0.9856002585 * d);  // anomalía media del Sol
  const ws = 282.9404 + 4.70935e-5 * d;
  const Ls = rev(Ms + ws);                      // longitud media del Sol
  const Lm = rev(M + w + N);                    // longitud media de la Luna
  const Mm = M;
  const D = rev(Lm - Ls);                       // elongación media Luna-Sol
  const Farg = rev(Lm - N);                      // argumento de latitud de la Luna

  lon += -1.274 * sin(Mm - 2 * D)
       + 0.658 * sin(2 * D)
       - 0.186 * sin(Ms)
       - 0.059 * sin(2 * Mm - 2 * D)
       - 0.057 * sin(Mm - 2 * D + Ms)
       + 0.053 * sin(Mm + 2 * D)
       + 0.046 * sin(2 * D - Ms)
       + 0.041 * sin(Mm - Ms)
       - 0.035 * sin(D)
       - 0.031 * sin(Mm + Ms);
  lat += -0.173 * sin(Farg - 2 * D)
       - 0.055 * sin(Mm - Farg - 2 * D)
       - 0.046 * sin(Mm + Farg - 2 * D)
       + 0.033 * sin(Farg + 2 * D)
       + 0.017 * sin(2 * Mm + Farg);
  return { lon: rev(lon), lat: rev(lat), r };
}

/* ---- Fase lunar ---- */
function moonPhase(d) {
  const sun = sunPosition(d);
  const moon = moonPosition(d);
  const elong = rev(moon.lon - sun.lon);
  const illum = (1 - cos(elong)) / 2;
  const names = [
    'Luna nueva', 'Luna creciente', 'Cuarto creciente', 'Gibosa creciente',
    'Luna llena', 'Gibosa menguante', 'Cuarto menguante', 'Luna menguante'
  ];
  const idx = Math.floor(elong / 45) % 8;
  const waxing = elong < 180;
  return { elong, illum, name: names[idx], waxing, moon, sun };
}

/* ---- Tiempo sidéreo local (grados) ---- */
function localSiderealTime(date, lonEast) {
  const d = daysSinceJ2000(date);
  const sun = sunPosition(d);
  const Ms = rev(356.0470 + 0.9856002585 * d);
  const w = 282.9404 + 4.70935e-5 * d;
  const GMST0 = rev(Ms + w + 180); // ecuador ascendente del Sol
  const ut = (date.getTime() / 3600000) % 24; // horas UTC fraccionales
  const lst = rev(GMST0 + ut * 15 + lonEast);
  return lst;
}

/* ---- RA/Dec → alt/az ---- */
function raDecToAltAz(raDeg, decDeg, date, latDeg, lonEastDeg) {
  const lst = localSiderealTime(date, lonEastDeg);
  const H = rev(lst - raDeg);
  const lat = latDeg;
  const sinAlt = sin(lat) * sin(decDeg) + cos(lat) * cos(decDeg) * cos(H);
  const alt = Math.asin(sinAlt) / RAD;
  const az = Math.atan2(-cos(decDeg) * sin(H), sin(decDeg) * cos(lat) - cos(decDeg) * sin(lat) * cos(H)) / RAD;
  return { alt, az: rev(az) };
}

/* ---- Planetas: posición geocéntrica RA/Dec y fase visual ---- */
function planetRaDec(planet, d) {
  const sun = sunPosition(d);
  // Sol geocéntrico rectangular (UA)
  const xs = sun.r * cos(sun.lon);
  const ys = sun.r * sin(sun.lon);
  const zs = 0;
  const h = heliocentric(planet, d);
  const xg = h.x + xs;
  const yg = h.y + ys;
  const zg = h.z + zs;
  const lon = rev(Math.atan2(yg, xg) / RAD);
  const lat = Math.atan2(zg, Math.sqrt(xg * xg + yg * yg)) / RAD;
  return eclToRaDec(lon, lat, d);
}