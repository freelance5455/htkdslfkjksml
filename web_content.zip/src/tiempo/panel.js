/* ================= Panel del propietario (secreto) =================
   Se abre pulsando 5 veces seguidas en "Privacidad" e introduciendo la contraseña.
   Los datos llegan del registro de visitantes de la app (puente en window.parent.__tuTiempo). */
/* Script clásico dentro del documento del tiempo: L (Leaflet) es un global del documento. */
/* eslint-disable no-undef */

(function () {
  const CSS = `
  .pp-hidden { display: none !important; }
  .pp-overlay, .pp-modal-back {
    font-family: 'Space Grotesk', system-ui, sans-serif;
    --pp-bg: hsl(222 40% 6%);
    --pp-card: hsl(222 36% 9%);
    --pp-fg: hsl(213 25% 95%);
    --pp-border: hsl(221 27% 15%);
    --pp-border-soft: hsl(221 26% 13%);
    --pp-muted: hsl(217 14% 64%);
    --pp-primary: hsl(190 90% 55%);
    --pp-destructive: hsl(0 78% 58%);
    --pp-mono: 'Geist Mono', ui-monospace, monospace;
  }
  .pp-overlay {
    position: fixed; inset: 0; z-index: 9000;
    background: var(--pp-bg); color: var(--pp-fg);
    overflow-y: auto; -webkit-overflow-scrolling: touch;
  }
  .pp-header {
    position: sticky; top: 0; z-index: 20;
    border-bottom: 1px solid var(--pp-border);
    background: color-mix(in srgb, var(--pp-bg) 90%, transparent);
    backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
  }
  .pp-header-in {
    max-width: 1440px; margin: 0 auto; padding: 12px 16px;
    display: flex; align-items: center; justify-content: space-between; gap: 16px;
  }
  .pp-hleft { display: flex; align-items: center; gap: 10px; min-width: 0; }
  .pp-hleft svg { width: 20px; height: 20px; color: var(--pp-primary); flex-shrink: 0; }
  .pp-title { font-size: 0.875rem; font-weight: 600; margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .pp-sub { font-family: var(--pp-mono); font-size: 0.75rem; color: var(--pp-muted); margin: 0; }
  .pp-hright { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
  .pp-btn {
    display: inline-flex; align-items: center; gap: 6px;
    height: 32px; padding: 0 12px; border-radius: 8px;
    border: 1px solid var(--pp-border); background: transparent;
    color: var(--pp-fg); font-size: 0.8rem; font-weight: 600;
    transition: background .15s, border-color .15s;
  }
  .pp-btn:hover { background: hsl(221 28% 16%); }
  .pp-btn svg { width: 16px; height: 16px; }
  .pp-btn.pp-active { background: var(--pp-primary); border-color: var(--pp-primary); color: hsl(222 45% 7%); }
  .pp-btn.pp-active svg { fill: currentColor; }
  .pp-main { max-width: 1440px; margin: 0 auto; padding: 20px 16px 32px; }
  .pp-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px; }
  .pp-card {
    background: var(--pp-card); border: 1px solid var(--pp-border-soft);
    border-radius: 10px;
  }
  .pp-stat { padding: 16px; }
  .pp-stat-label { display: flex; align-items: center; gap: 8px; font-size: 0.75rem; color: var(--pp-muted); }
  .pp-stat-label svg { width: 14px; height: 14px; }
  .pp-stat-val { margin-top: 4px; font-family: var(--pp-mono); font-size: 1.5rem; font-weight: 600; font-variant-numeric: tabular-nums; }
  .pp-grid { display: grid; grid-template-columns: 1fr; gap: 16px; }
  @media (min-width: 1024px) { .pp-grid { grid-template-columns: 1.6fr 1fr; } }
  .pp-map-card { height: 60vh; min-height: 380px; overflow: hidden; padding: 0; }
  @media (min-width: 1024px) { .pp-map-card { height: 70vh; min-height: 420px; } }
  .pp-map { width: 100%; height: 100%; z-index: 0; background: #090d15; }
  .pp-map .leaflet-tile-pane { filter: grayscale(1) invert(1) hue-rotate(185deg) saturate(.4) brightness(.92) contrast(.85); }
  .pp-map .leaflet-container { background: #090d15; font-family: 'Space Grotesk', sans-serif; }
  .pp-map .leaflet-popup-content-wrapper, .pp-map .leaflet-popup-tip {
    background: #101623; color: #eff2f5; border: 1px solid hsl(221 26% 18%);
  }
  .pp-map .leaflet-popup-content { font-family: 'Geist Mono', monospace; font-size: 12px; line-height: 1.55; margin: 10px 14px; }
  .pp-map .leaflet-control-attribution { background: rgba(9,13,21,.7); color: #8b98b8; font-size: 9px; }
  .pp-map .leaflet-control-attribution a { color: #aeb9d6; }
  .gps-marker, .gps-red-marker { position: relative; }
  .gps-pulse, .gps-red-pulse { position: absolute; inset: 0; border-radius: 9999px; animation: pp-pulse 2s ease-out infinite; }
  .gps-pulse { background: #38bdf859; }
  .gps-red-pulse { background: #ef444459; }
  .gps-core, .gps-red-core {
    position: absolute; top: 4px; left: 4px; width: 10px; height: 10px;
    border-radius: 9999px; border: 2px solid #ffffff;
  }
  .gps-core { background: #38bdf8; box-shadow: 0 0 10px #38bdf8e6; }
  .gps-red-core { background: #ef4444; box-shadow: 0 0 10px #ef4444e6; }
  @keyframes pp-pulse { 0% { transform: scale(.35); opacity: 1; } 70% { transform: scale(1); opacity: 0; } 100% { transform: scale(.35); opacity: 0; } }
  .pp-list-card { display: flex; flex-direction: column; height: 60vh; min-height: 380px; overflow: hidden; padding: 0; }
  @media (min-width: 1024px) { .pp-list-card { height: 70vh; min-height: 420px; } }
  .pp-list-head {
    display: flex; align-items: center; justify-content: space-between;
    padding: 12px 16px; border-bottom: 1px solid var(--pp-border-soft);
  }
  .pp-list-head p { margin: 0; font-size: 0.875rem; font-weight: 600; }
  .pp-list-head small { margin-left: 8px; font-size: 0.75rem; font-weight: 400; color: var(--pp-muted); }
  .pp-badge {
    font-family: var(--pp-mono); font-size: 0.75rem; padding: 2px 8px;
    border-radius: 6px; background: hsl(221 26% 15%); color: var(--pp-fg);
  }
  .pp-list-scroll { flex: 1; overflow-y: auto; }
  .pp-list { list-style: none; margin: 0; padding: 0; }
  .pp-list > li {
    padding: 12px 16px; cursor: pointer; border-bottom: 1px solid hsl(221 26% 13% / .6);
    transition: background .15s;
  }
  .pp-list > li:hover { background: hsl(221 28% 16% / .5); }
  .pp-list > li.pp-selected { background: hsl(190 90% 55% / .1); }
  .pp-row-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
  .pp-ip {
    font-family: var(--pp-mono); font-size: 0.8rem; font-weight: 500;
    color: var(--pp-primary); background: none; border: none; padding: 0; text-align: left;
    text-underline-offset: 2px;
  }
  .pp-ip:hover { text-decoration: underline; }
  .pp-row-actions { display: flex; align-items: center; gap: 6px; }
  .pp-icon-btn { background: none; border: none; padding: 4px; border-radius: 4px; color: var(--pp-muted); display: flex; }
  .pp-icon-btn:hover { color: #facc15; }
  .pp-icon-btn.pp-del { opacity: 0; transition: opacity .15s, color .15s; }
  .pp-icon-btn.pp-del:hover { color: var(--pp-destructive); }
  .pp-list > li:hover .pp-icon-btn.pp-del { opacity: 1; }
  @media (hover: none), (max-width: 640px) {
    .pp-icon-btn.pp-del { opacity: 1; }
    .pp-icon-btn.pp-del:active { color: var(--pp-destructive); }
  }
  .pp-icon-btn svg { width: 14px; height: 14px; }
  .pp-star-on { color: #facc15; fill: #facc15; }
  .pp-gps-tag {
    display: inline-flex; align-items: center; gap: 4px;
    border: 1px solid hsl(190 90% 55% / .4); color: var(--pp-primary);
    border-radius: 6px; padding: 0 6px; font-family: var(--pp-mono); font-size: 0.7rem;
  }
  .pp-gps-tag svg { width: 11px; height: 11px; }
  .pp-row-line { margin: 4px 0 0; font-size: 0.75rem; color: var(--pp-muted); display: flex; align-items: center; gap: 6px; }
  .pp-row-line svg { width: 12px; height: 12px; flex-shrink: 0; }
  .pp-row-line span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .pp-row-mono { font-family: var(--pp-mono); font-size: 0.72rem; color: hsl(217 14% 64% / .8); margin: 2px 0 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .pp-row-gps { font-family: var(--pp-mono); font-size: 0.72rem; color: var(--pp-primary); margin: 4px 0 0; }
  .pp-empty { padding: 32px 16px; text-align: center; font-size: 0.85rem; color: var(--pp-muted); }
  .pp-note { margin: 16px 0 0; font-size: 0.75rem; line-height: 1.6; color: var(--pp-muted); }
  .pp-note b { font-weight: 600; }
  .pp-note .azul { color: #38bdf8; }
  .pp-note .rojo { color: #ef4444; }
  /* modales */
  .pp-modal-back {
    position: fixed; inset: 0; z-index: 9500;
    background: rgba(3, 7, 16, .72);
    display: flex; align-items: center; justify-content: center; padding: 16px;
  }
  .pp-modal {
    width: 100%; max-width: 420px;
    background: hsl(222 38% 8%); color: var(--pp-fg);
    border: 1px solid var(--pp-border); border-radius: 12px;
    padding: 20px; box-shadow: 0 24px 60px rgba(0,0,0,.55);
  }
  .pp-modal.pp-narrow { max-width: 384px; }
  .pp-modal-head { display: flex; align-items: center; gap: 8px; font-size: 1.05rem; font-weight: 700; }
  .pp-modal-head svg { width: 16px; height: 16px; color: var(--pp-primary); }
  .pp-modal-desc { margin: 6px 0 0; font-size: 0.85rem; color: var(--pp-muted); }
  .pp-modal-body { margin-top: 14px; display: flex; flex-direction: column; gap: 10px; font-size: 0.85rem; line-height: 1.6; color: hsl(213 25% 88%); }
  .pp-modal-body p { margin: 0; }
  .pp-close {
    position: absolute; top: 14px; right: 14px;
    background: none; border: none; color: var(--pp-muted); font-size: 1rem;
  }
  .pp-form { margin-top: 14px; display: flex; flex-direction: column; gap: 10px; }
  .pp-input {
    width: 100%; height: 40px; padding: 0 12px; border-radius: 8px;
    background: hsl(222 36% 11%); border: 1px solid hsl(221 22% 24%);
    color: var(--pp-fg); font-size: 0.9rem; font-family: 'Space Grotesk', sans-serif;
  }
  .pp-input:focus { outline: 2px solid var(--pp-primary); outline-offset: 1px; }
  .pp-input.pp-bad { border-color: var(--pp-destructive); }
  .pp-err { display: flex; align-items: center; gap: 6px; margin: 0; font-size: 0.75rem; color: var(--pp-destructive); }
  .pp-err svg { width: 14px; height: 14px; }
  .pp-submit {
    width: 100%; height: 40px; border-radius: 8px; border: none;
    background: var(--pp-primary); color: hsl(222 45% 7%);
    font-size: 0.875rem; font-weight: 700;
    display: inline-flex; align-items: center; justify-content: center; gap: 8px;
  }
  .pp-submit:disabled { opacity: .6; }
  .pp-spin { width: 14px; height: 14px; border: 2px solid hsl(222 45% 7% / .35); border-top-color: hsl(222 45% 7%); border-radius: 50%; animation: pp-rot .7s linear infinite; }
  @keyframes pp-rot { to { transform: rotate(360deg); } }
  @media (max-width: 640px) {
    .pp-main { padding: 14px 12px 24px; }
    .pp-stat { padding: 12px; }
    .pp-stat-val { font-size: 1.2rem; }
    .pp-stats { gap: 8px; }
    .pp-btn span { display: none; }
    .pp-btn { padding: 0 9px; }
  }
  `;

  const SVG = {
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/></svg>',
    users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20Z"/></svg>',
    pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>',
    star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2Z"/></svg>',
    refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>',
    device: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>',
    link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>',
    alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v5M12 16h.01"/></svg>'
  };

  const PASS_LEN = 5;
  const api = () => {
    try { return window.parent && window.parent.__tuTiempo; } catch { return null; }
  };

  let clicks = 0, clickTimer = null;
  let password = '', unlocked = false, favoritesOnly = false;
  let visits = [], selectedId = null, timer = null, map = null, layer = null;

  /* ---------- estilos ---------- */
  function injectStyles() {
    const s = document.createElement('style');
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  /* ---------- modales ---------- */
  function modal(html, narrow) {
    const back = document.createElement('div');
    back.className = 'pp-modal-back';
    back.innerHTML = `<div class="pp-modal${narrow ? ' pp-narrow' : ''}" role="dialog" aria-modal="true">${html}</div>`;
    document.body.appendChild(back);
    back.addEventListener('mousedown', e => { if (e.target === back) back.remove(); });
    const close = back.querySelector('.pp-close');
    if (close) close.addEventListener('click', () => back.remove());
    return back;
  }

  function openPrivacy() {
    modal(`
      <button class="pp-close" aria-label="Cerrar">✕</button>
      <div class="pp-modal-head">Política de Privacidad</div>
      <p class="pp-modal-desc">Resumen de cómo tratamos los datos en TiempoHoy.</p>
      <div class="pp-modal-body">
        <p>TiempoHoy no crea cuentas de usuario ni te pide datos personales como nombre o email.</p>
        <p>Como la mayoría de sitios web, podemos registrar datos técnicos de conexión (dirección IP, tipo de dispositivo y navegador) con fines estadísticos y de seguridad.</p>
        <p>La información de ubicación solo se utiliza si la aceptas expresamente, para mostrar el tiempo de donde estás. Puedes rechazarla en cualquier momento sin que afecte al resto de la web.</p>
      </div>`);
  }

  function openPassword() {
    const back = modal(`
      <div class="pp-modal-head">${SVG.lock}Panel del propietario</div>
      <p class="pp-modal-desc">Introduce la contraseña para ver el registro de visitantes.</p>
      <form class="pp-form">
        <input class="pp-input" type="password" inputmode="numeric" autocomplete="off" placeholder="Contraseña" aria-label="Contraseña">
        <p class="pp-err pp-hidden">${SVG.alert}Contraseña incorrecta</p>
        <button class="pp-submit" type="submit">Desbloquear</button>
      </form>`, true);
    const input = back.querySelector('.pp-input');
    const err = back.querySelector('.pp-err');
    const submit = back.querySelector('.pp-submit');
    input.focus();
    back.querySelector('form').addEventListener('submit', async e => {
      e.preventDefault();
      const value = input.value.trim();
      if (!value) return;
      err.classList.add('pp-hidden');
      input.classList.remove('pp-bad');
      submit.disabled = true;
      submit.innerHTML = '<span class="pp-spin"></span>Desbloquear';
      const bridge = api();
      const res = bridge ? await bridge.list(value) : { ok: false };
      submit.disabled = false;
      submit.textContent = 'Desbloquear';
      if (res && res.ok) {
        password = value;
        visits = res.visits || [];
        back.remove();
        openPanel();
      } else {
        err.classList.remove('pp-hidden');
        input.classList.add('pp-bad');
        input.select();
      }
    });
  }

  /* ---------- panel ---------- */
  function openPanel() {
    unlocked = true;
    const overlay = document.createElement('div');
    overlay.className = 'pp-overlay';
    overlay.id = 'ppOverlay';
    overlay.innerHTML = `
      <header class="pp-header">
        <div class="pp-header-in">
          <div class="pp-hleft">
            ${SVG.shield}
            <div>
              <p class="pp-title">Registro de visitantes</p>
              <p class="pp-sub"><span id="ppCount">0</span> entradas · actualización automática</p>
            </div>
          </div>
          <div class="pp-hright">
            <button class="pp-btn" id="ppFavBtn">${SVG.star}<span>Favoritos</span></button>
            <button class="pp-btn" id="ppRefreshBtn">${SVG.refresh}<span>Actualizar</span></button>
            <button class="pp-btn" id="ppLockBtn">${SVG.lock}<span>Bloquear</span></button>
          </div>
        </div>
      </header>
      <main class="pp-main">
        <div class="pp-stats">
          <div class="pp-card pp-stat">
            <div class="pp-stat-label">${SVG.users}Visitas</div>
            <p class="pp-stat-val" id="ppStatVisits">0</p>
          </div>
          <div class="pp-card pp-stat">
            <div class="pp-stat-label">${SVG.globe}IPs únicas</div>
            <p class="pp-stat-val" id="ppStatIps">0</p>
          </div>
          <div class="pp-card pp-stat">
            <div class="pp-stat-label">${SVG.pin}Con GPS exacto</div>
            <p class="pp-stat-val" id="ppStatGps">0</p>
          </div>
        </div>
        <div class="pp-grid">
          <div class="pp-card pp-map-card"><div class="pp-map" id="ppMap"></div></div>
          <div class="pp-card pp-list-card">
            <div class="pp-list-head">
              <p>Visitantes<span id="ppFavNote" class="pp-hidden"><small>favoritas</small></span></p>
              <span class="pp-badge" id="ppListCount">0</span>
            </div>
            <div class="pp-list-scroll"><ul class="pp-list" id="ppList"></ul></div>
          </div>
        </div>
        <p class="pp-note">
          En el mapa solo se muestran los puntos de la última persona que ha entrado (o de la que selecciones en la lista). El punto
          <span class="azul">azul</span> es la zona aproximada del router (geolocalización por IP); el punto
          <span class="rojo">rojo</span> es el GPS exacto del dispositivo. Si la visita solo tiene IP, verás únicamente el punto azul.
          Pulsa la estrella para guardar una visita en favoritas y la papelera para borrar cualquier registro.
        </p>
      </main>`;
    document.body.appendChild(overlay);
    document.documentElement.style.overflow = 'hidden';

    overlay.querySelector('#ppLockBtn').addEventListener('click', lock);
    overlay.querySelector('#ppRefreshBtn').addEventListener('click', () => load(true));
    overlay.querySelector('#ppFavBtn').addEventListener('click', e => {
      favoritesOnly = !favoritesOnly;
      e.currentTarget.classList.toggle('pp-active', favoritesOnly);
      renderList();
    });

    initMap();
    renderAll();
    load(false);
    timer = setInterval(() => load(false), 10000);
  }

  function lock() {
    unlocked = false;
    password = '';
    clearInterval(timer);
    timer = null;
    const overlay = document.getElementById('ppOverlay');
    if (overlay) overlay.remove();
    document.documentElement.style.overflow = '';
    if (map) { map.remove(); map = null; layer = null; }
  }

  async function load(force) {
    const bridge = api();
    if (!bridge) return;
    const res = await bridge.list(password);
    if (res && res.ok) {
      visits = res.visits || [];
      renderAll();
    } else if (force) {
      renderAll();
    }
  }

  function fmtDate(value) {
    try {
      return new Intl.DateTimeFormat('es-ES', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date(value));
    } catch { return value; }
  }

  function renderAll() {
    if (!unlocked) return;
    const ips = new Set(visits.map(v => v.ip)).size;
    const gps = visits.filter(v => v.gpsLat != null).length;
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set('ppCount', visits.length);
    set('ppStatVisits', visits.length);
    set('ppStatIps', ips);
    set('ppStatGps', gps);
    renderList();
    renderMap();
  }

  function placeOf(v) {
    return [v.ciudad, v.region, v.pais].filter(Boolean).join(', ') || 'Ubicación no disponible';
  }

  function renderList() {
    const list = document.getElementById('ppList');
    if (!list) return;
    const items = favoritesOnly ? visits.filter(v => v.favorito) : visits;
    const count = document.getElementById('ppListCount');
    if (count) count.textContent = items.length;
    const note = document.getElementById('ppFavNote');
    if (note) note.classList.toggle('pp-hidden', !favoritesOnly);

    if (!items.length) {
      list.innerHTML = `<p class="pp-empty">${favoritesOnly ? 'Todavía no has marcado ninguna visita como favorita: pulsa la estrella de una visita.' : 'Todavía no hay visitas registradas.'}</p>`;
      return;
    }
    list.innerHTML = items.map(v => {
      const gpsLine = v.gpsLat != null && v.gpsLon != null
        ? `<p class="pp-row-gps">GPS: ${Number(v.gpsLat).toFixed(5)}, ${Number(v.gpsLon).toFixed(5)}${v.gpsPrecision ? ` (±${Math.round(v.gpsPrecision)} m)` : ''}</p>` : '';
      const device = [v.dispositivo, v.sistema, v.navegador].filter(Boolean).join(' · ');
      return `<li data-id="${v.id}" class="${selectedId === v.id ? 'pp-selected' : ''}">
        <div class="pp-row-top">
          <button class="pp-ip" data-ip="${v.id}">${v.ip || '—'}</button>
          <div class="pp-row-actions">
            <button class="pp-icon-btn" data-fav="${v.id}" aria-label="${v.favorito ? 'Quitar de favoritas' : 'Marcar como favorita'}">
              <span class="${v.favorito ? 'pp-star-on' : ''}" style="display:flex">${SVG.star}</span>
            </button>
            ${v.gpsLat != null ? `<span class="pp-gps-tag">${SVG.pin}GPS</span>` : ''}
            <button class="pp-icon-btn pp-del" data-del="${v.id}" aria-label="Eliminar registro">${SVG.trash}</button>
          </div>
        </div>
        <p class="pp-row-line">${SVG.pin}<span>${placeOf(v)}</span></p>
        <p class="pp-row-mono">${fmtDate(v.createdAt)}${v.isp ? ' · ' + v.isp : ''}</p>
        ${device ? `<p class="pp-row-line">${SVG.device}<span>${device}</span></p>` : ''}
        ${v.origen ? `<p class="pp-row-line">${SVG.link}<span>Entró desde ${v.origen}</span></p>` : ''}
        ${gpsLine}
      </li>`;
    }).join('');

    list.querySelectorAll('li[data-id]').forEach(li => {
      li.addEventListener('click', () => { selectedId = li.dataset.id; renderList(); renderMap(); });
    });
    list.querySelectorAll('[data-fav]').forEach(b => {
      b.addEventListener('click', async e => {
        e.stopPropagation();
        const id = b.dataset.fav;
        const v = visits.find(x => x.id === id);
        if (!v) return;
        const next = !v.favorito;
        v.favorito = next;
        renderList();
        const bridge = api();
        if (bridge) await bridge.favorite(password, id, next);
      });
    });
    list.querySelectorAll('[data-del]').forEach(b => {
      b.addEventListener('click', async e => {
        e.stopPropagation();
        const id = b.dataset.del;
        visits = visits.filter(x => x.id !== id);
        if (selectedId === id) selectedId = null;
        renderAll();
        const bridge = api();
        if (bridge) await bridge.remove(password, id);
      });
    });
  }

  /* ---------- mapa ---------- */
  function initMap() {
    const el = document.getElementById('ppMap');
    if (!el || typeof L === 'undefined') return;
    map = L.map(el, { zoomControl: true, worldCopyJump: true }).setView([40.4168, -3.7038], 5);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19
    }).addTo(map);
    layer = L.layerGroup().addTo(map);
    setTimeout(() => map && map.invalidateSize(), 200);
  }

  const iconIp = () => L.divIcon({ className: 'gps-marker', html: '<div class="gps-pulse"></div><div class="gps-core"></div>', iconSize: [18, 18], iconAnchor: [9, 9] });
  const iconGps = () => L.divIcon({ className: 'gps-red-marker', html: '<div class="gps-red-pulse"></div><div class="gps-red-core"></div>', iconSize: [18, 18], iconAnchor: [9, 9] });

  function renderMap() {
    if (!map || !layer) return;
    layer.clearLayers();
    const target = selectedId ? visits.find(v => v.id === selectedId) : visits[0];
    if (!target) return;
    const v = target;
    if (v.lat != null && v.lon != null) {
      L.marker([v.lat, v.lon], { icon: iconIp() }).addTo(layer).bindPopup(
        `<strong>Zona de la IP</strong><br/>IP ${v.ip}<br/>${placeOf(v)} — IP ${v.ip}<br/><span style="opacity:.7">Zona aproximada del router (por IP)</span>`
      ).on('click', () => { selectedId = v.id; renderList(); });
    }
    if (v.gpsLat != null && v.gpsLon != null) {
      L.marker([v.gpsLat, v.gpsLon], { icon: iconGps() }).addTo(layer).bindPopup(
        `<strong>GPS exacto del dispositivo</strong><br/>IP ${v.ip}<br/>${Number(v.gpsLat).toFixed(5)}, ${Number(v.gpsLon).toFixed(5)}${v.gpsPrecision ? ` (±${Math.round(v.gpsPrecision)} m)` : ''}`
      ).on('click', () => { selectedId = v.id; renderList(); });
      if (v.gpsPrecision && v.gpsPrecision > 30) {
        L.circle([v.gpsLat, v.gpsLon], { radius: Math.min(v.gpsPrecision, 2000), color: '#ef4444', weight: 1, fillOpacity: .08 }).addTo(layer);
      }
    }
    const center = v.gpsLat != null && v.gpsLon != null ? [v.gpsLat, v.gpsLon] : (v.lat != null && v.lon != null ? [v.lat, v.lon] : null);
    if (center) {
      map.flyTo(center, v.gpsLat != null ? 16 : 11, { duration: .8 });
      setTimeout(() => { layer.eachLayer(l => { if (l.openPopup) l.openPopup(); }); }, 850);
    }
  }

  /* ---------- arranque del disparador ---------- */
  function bindTrigger() {
    const btn = document.getElementById('btnPrivacidad');
    if (!btn) return;
    btn.addEventListener('click', () => {
      clicks += 1;
      if (clickTimer) clearTimeout(clickTimer);
      if (clicks >= PASS_LEN) {
        clicks = 0;
        openPassword();
        return;
      }
      clickTimer = setTimeout(() => {
        clicks = 0;
        openPrivacy();
      }, 450);
    });
  }

  injectStyles();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bindTrigger);
  else bindTrigger();
})();