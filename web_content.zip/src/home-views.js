// Étape 6.6 — Accueil : sous-onglets Actualités, Classement et Divisions (écran 06, disposition FM27). Lecture seule.
const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const allClubs = state => (state?.divisions || []).flatMap(division => division.clubs || []);
const ranked = clubs => [...clubs].sort((a, b) => (b.points || 0) - (a.points || 0) || ((b.gf || 0) - (b.ga || 0)) - ((a.gf || 0) - (a.ga || 0)) || String(a.name).localeCompare(String(b.name)));

export function buildStandings(state) {
  const division = (state?.divisions || []).find(item => (item.clubs || []).some(club => club.id === state.userClubId)) || null;
  const rows = ranked(division?.clubs || []).map((club, index) => ({ pos: index + 1, name: club.name, played: club.played || 0, won: club.won || 0, drawn: club.drawn || 0, lost: club.lost || 0, diff: (club.gf || 0) - (club.ga || 0), points: club.points || 0, me: club.id === state.userClubId }));
  return { divisionName: division?.name || null, rows };
}

export function buildDivisions(state) {
  const own = allClubs(state).find(club => club.id === state?.userClubId);
  return (state?.divisions || []).map(division => {
    const leader = ranked(division.clubs || [])[0];
    return { name: division.name, status: division.status, clubs: (division.clubs || []).length, leader: leader?.name || '—', points: leader?.points || 0, mine: (division.clubs || []).some(club => club.id === own?.id) };
  });
}

export function buildNews(state) {
  const names = new Map(allClubs(state).map(club => [club.id, club.name]));
  const nameOf = id => names.get(id) || String(id);
  const messages = (state?.management?.inbox || []).slice(0, 6).map(item => ({ kind: 'Message', title: item.title || item.subject || String(item.text || '').slice(0, 60) || 'Message', open: item.status !== 'answered' }));
  const results = (state?.calendar?.fixtures || []).filter(f => f.status === 'played' && (f.home === state.userClubId || f.away === state.userClubId)).slice(-4).reverse()
    .map(f => ({ kind: 'Résultat', title: `${nameOf(f.home)} ${f.score?.[0] ?? '?'}–${f.score?.[1] ?? '?'} ${nameOf(f.away)}`, open: false }));
  return [...results, ...messages];
}

const wrap = inner => `<div class="fm-tbl-wrap">${inner}</div>`;
export function renderStandingsHtml(data) {
  if (!data.divisionName) return '<p class="fm-empty">Aucun club : prends un poste pour voir le classement.</p>';
  return wrap(`<table class="fm-tbl"><tr><th>#</th><th>Club</th><th>J</th><th>V</th><th>N</th><th>D</th><th>Diff.</th><th>Pts</th></tr>${data.rows.map(r => `<tr${r.me ? ' class="me"' : ''}><td>${r.pos}</td><td><b>${esc(r.name)}</b></td><td>${r.played}</td><td>${r.won}</td><td>${r.drawn}</td><td>${r.lost}</td><td>${r.diff}</td><td><b>${r.points}</b></td></tr>`).join('')}</table>`);
}
export function renderDivisionsHtml(list) {
  if (!list.length) return '<p class="fm-empty">Aucune division.</p>';
  return wrap(`<table class="fm-tbl"><tr><th>Division</th><th>Statut</th><th>Clubs</th><th>Leader</th><th>Pts</th></tr>${list.map(d => `<tr${d.mine ? ' class="me"' : ''}><td><b>${esc(d.name)}</b></td><td>${esc(d.status === 'active' ? 'Active' : d.status === 'announced' ? 'Annoncée' : 'En attente')}</td><td>${d.clubs}</td><td>${esc(d.leader)}</td><td>${d.points}</td></tr>`).join('')}</table>`);
}
export function renderNewsHtml(items) {
  if (!items.length) return '<p class="fm-empty">Aucune actualité pour le moment.</p>';
  return `<div class="fm-news">${items.map(i => `<div class="fm-new${i.open ? ' open' : ''}"><small>${esc(i.kind)}</small><b>${esc(i.title)}</b>${i.open ? '<span class="rq">Réponse requise</span>' : ''}</div>`).join('')}</div>`;
}
