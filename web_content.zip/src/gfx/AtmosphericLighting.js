import * as THREE from 'three';

export class AtmosphericLighting {
  constructor(scene) {
    this.scene = scene;
    this.rainParticles = null;
    this.flickerLights = [];

    this.setupFogAndAmbient();
    this.setupMoonlight();
    this.setupRainSystem();
  }

  setupFogAndAmbient() {
    // Classic RE2 pitch black horror fog
    this.scene.background = new THREE.Color(0x020305);
    this.scene.fog = new THREE.FogExp2(0x020305, 0.08);

    // Dim eerie ambient light
    const ambientLight = new THREE.AmbientLight(0x1a2230, 0.6);
    this.scene.add(ambientLight);
  }

  setupMoonlight() {
    // Night sky moonlight shadow caster
    const moonLight = new THREE.DirectionalLight(0x3a5580, 0.8);
    moonLight.position.set(20, 40, -10);
    moonLight.castShadow = true;
    moonLight.shadow.mapSize.width = 2048;
    moonLight.shadow.mapSize.height = 2048;
    moonLight.shadow.camera.near = 0.5;
    moonLight.shadow.camera.far = 100;
    const d = 30;
    moonLight.shadow.camera.left = -d;
    moonLight.shadow.camera.right = d;
    moonLight.shadow.camera.top = d;
    moonLight.shadow.camera.bottom = -d;
    this.scene.add(moonLight);
  }

  setupRainSystem() {
    const particleCount = 2000;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 60;
      positions[i + 1] = Math.random() * 30;
      positions[i + 2] = (Math.random() - 0.5) * 60;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const material = new THREE.PointsMaterial({
      color: 0x88aacc,
      size: 0.15,
      transparent: true,
      opacity: 0.6
    });

    this.rainParticles = new THREE.Points(geometry, material);
    this.scene.add(this.rainParticles);
  }

  addFlickeringLight(position, color = 0xff3300, intensity = 2.0, distance = 10) {
    const light = new THREE.PointLight(color, intensity, distance);
    light.position.copy(position);
    light.castShadow = true;
    this.scene.add(light);
    this.flickerLights.push({ light, baseIntensity: intensity });
    return light;
  }

  update(delta) {
    // Update Rain Particles falling
    if (this.rainParticles) {
      const positions = this.rainParticles.geometry.attributes.position.array;
      for (let i = 1; i < positions.length; i += 3) {
        positions[i] -= 25 * delta;
        if (positions[i] < 0) {
          positions[i] = 30;
        }
      }
      this.rainParticles.geometry.attributes.position.needsUpdate = true;
    }

    // Flicker horror streetlights and emergency alarms
    for (const item of this.flickerLights) {
      if (Math.random() < 0.1) {
        item.light.intensity = item.baseIntensity * (0.2 + Math.random() * 0.8);
      }
    }
  }
}
