import * as THREE from 'three';

export class MeshBuilder {
  // Materials Cache
  static materials = {
    leonUniform: new THREE.MeshStandardMaterial({ color: 0x1b2838, roughness: 0.6 }),
    leonVest: new THREE.MeshStandardMaterial({ color: 0x0c121c, roughness: 0.4 }),
    skin: new THREE.MeshStandardMaterial({ color: 0xd9a078, roughness: 0.7 }),
    hairBrown: new THREE.MeshStandardMaterial({ color: 0x3d2817, roughness: 0.8 }),
    claireJacket: new THREE.MeshStandardMaterial({ color: 0x801515, roughness: 0.5 }),
    claireJeans: new THREE.MeshStandardMaterial({ color: 0x1c2b42, roughness: 0.7 }),
    zombieSkin: new THREE.MeshStandardMaterial({ color: 0x4a5d4e, roughness: 0.9 }),
    zombieBlood: new THREE.MeshStandardMaterial({ color: 0x3a0000, roughness: 0.3 }),
    zombieEye: new THREE.MeshBasicMaterial({ color: 0xff3300 }),
    lickerMuscle: new THREE.MeshStandardMaterial({ color: 0x8a1c1c, roughness: 0.3 }),
    mrxCoat: new THREE.MeshStandardMaterial({ color: 0x111115, roughness: 0.3 }),
    mrxSkin: new THREE.MeshStandardMaterial({ color: 0x737982, roughness: 0.8 }),
    birkinEye: new THREE.MeshStandardMaterial({ color: 0xff4400, emissive: 0xaa2200, roughness: 0.2 }),
    metalDark: new THREE.MeshStandardMaterial({ color: 0x222225, metalness: 0.8, roughness: 0.3 }),
    metalGold: new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.9, roughness: 0.2 }),
    metalSilver: new THREE.MeshStandardMaterial({ color: 0xc0c0c0, metalness: 0.9, roughness: 0.2 }),
    woodDark: new THREE.MeshStandardMaterial({ color: 0x3d2314, roughness: 0.8 }),
    herbGreen: new THREE.MeshStandardMaterial({ color: 0x2e8b57, roughness: 0.5 }),
    herbRed: new THREE.MeshStandardMaterial({ color: 0xb22222, roughness: 0.5 }),
    plasticWhite: new THREE.MeshStandardMaterial({ color: 0xeeeeee, roughness: 0.4 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0x88ccff, transparent: true, opacity: 0.4, roughness: 0.1, transmission: 0.8 }),
    redLight: new THREE.MeshBasicMaterial({ color: 0xff0000 }),
    greenLight: new THREE.MeshBasicMaterial({ color: 0x00ff44 }),
    concrete: new THREE.MeshStandardMaterial({ color: 0x3a3d40, roughness: 0.9 }),
    brick: new THREE.MeshStandardMaterial({ color: 0x4a2a22, roughness: 0.95 }),
    marble: new THREE.MeshStandardMaterial({ color: 0x888a8c, roughness: 0.4 })
  };

  // --- CHARACTER MESHES ---

  static createLeonMesh() {
    const group = new THREE.Group();
    group.name = 'LeonPlayer';

    // Body / Torso (Police Vest & Badge)
    const torsoGeo = new THREE.BoxGeometry(0.5, 0.6, 0.3);
    const torso = new THREE.Mesh(torsoGeo, this.materials.leonVest);
    torso.position.y = 0.9;
    torso.castShadow = true;
    group.add(torso);

    // RPD Emblem Badge on chest
    const badgeGeo = new THREE.BoxGeometry(0.1, 0.12, 0.02);
    const badge = new THREE.Mesh(badgeGeo, this.materials.metalGold);
    badge.position.set(0.12, 1.05, 0.16);
    group.add(badge);

    // Head
    const headGeo = new THREE.SphereGeometry(0.18, 16, 16);
    const head = new THREE.Mesh(headGeo, this.materials.skin);
    head.position.y = 1.35;
    head.castShadow = true;
    group.add(head);

    // Leon Hair
    const hairGeo = new THREE.BoxGeometry(0.38, 0.15, 0.4);
    const hair = new THREE.Mesh(hairGeo, this.materials.hairBrown);
    hair.position.set(0, 1.45, 0.02);
    group.add(hair);

    // Arms
    const armGeo = new THREE.CylinderGeometry(0.08, 0.07, 0.55);
    const leftArm = new THREE.Mesh(armGeo, this.materials.leonUniform);
    leftArm.position.set(-0.32, 0.88, 0);
    leftArm.castShadow = true;
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, this.materials.leonUniform);
    rightArm.position.set(0.32, 0.88, 0);
    rightArm.castShadow = true;
    group.add(rightArm);

    // Legs
    const legGeo = new THREE.CylinderGeometry(0.1, 0.08, 0.65);
    const leftLeg = new THREE.Mesh(legGeo, this.materials.leonUniform);
    leftLeg.position.set(-0.15, 0.33, 0);
    leftLeg.castShadow = true;
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, this.materials.leonUniform);
    rightLeg.position.set(0.15, 0.33, 0);
    rightLeg.castShadow = true;
    group.add(rightLeg);

    // Boots
    const bootGeo = new THREE.BoxGeometry(0.12, 0.15, 0.22);
    const leftBoot = new THREE.Mesh(bootGeo, this.materials.metalDark);
    leftBoot.position.set(-0.15, 0.07, 0.03);
    group.add(leftBoot);

    const rightBoot = new THREE.Mesh(bootGeo, this.materials.metalDark);
    rightBoot.position.set(0.15, 0.07, 0.03);
    group.add(rightBoot);

    return group;
  }

  static createZombieMesh() {
    const group = new THREE.Group();
    group.name = 'ZombieEnemy';

    // Tattered Torso
    const torsoGeo = new THREE.BoxGeometry(0.5, 0.6, 0.28);
    const torso = new THREE.Mesh(torsoGeo, this.materials.zombieSkin);
    torso.position.y = 0.9;
    torso.rotation.x = 0.15; // Slouching
    torso.castShadow = true;
    group.add(torso);

    // Head
    const headGeo = new THREE.SphereGeometry(0.18, 12, 12);
    const head = new THREE.Mesh(headGeo, this.materials.zombieSkin);
    head.position.set(0, 1.32, 0.08);
    head.castShadow = true;
    group.add(head);

    // Glowing Red Eyes
    const eyeGeo = new THREE.SphereGeometry(0.03, 8, 8);
    const leftEye = new THREE.Mesh(eyeGeo, this.materials.zombieEye);
    leftEye.position.set(-0.06, 1.35, 0.22);
    group.add(leftEye);

    const rightEye = new THREE.Mesh(eyeGeo, this.materials.zombieEye);
    rightEye.position.set(0.06, 1.35, 0.22);
    group.add(rightEye);

    // Arms extended forward (Zombie stance)
    const armGeo = new THREE.CylinderGeometry(0.07, 0.06, 0.55);
    const leftArm = new THREE.Mesh(armGeo, this.materials.zombieSkin);
    leftArm.position.set(-0.3, 0.95, 0.25);
    leftArm.rotation.x = -1.2; // Reaching out
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, this.materials.zombieSkin);
    rightArm.position.set(0.3, 0.95, 0.25);
    rightArm.rotation.x = -1.2;
    group.add(rightArm);

    // Legs
    const legGeo = new THREE.CylinderGeometry(0.09, 0.08, 0.65);
    const leftLeg = new THREE.Mesh(legGeo, this.materials.zombieSkin);
    leftLeg.position.set(-0.14, 0.33, 0);
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, this.materials.zombieSkin);
    rightLeg.position.set(0.14, 0.33, 0);
    group.add(rightLeg);

    return group;
  }

  static createLickerMesh() {
    const group = new THREE.Group();
    group.name = 'LickerEnemy';

    // Crawling Muscle Body
    const bodyGeo = new THREE.BoxGeometry(0.6, 0.35, 0.9);
    const body = new THREE.Mesh(bodyGeo, this.materials.lickerMuscle);
    body.position.y = 0.35;
    body.castShadow = true;
    group.add(body);

    // Exposed Brain Head
    const brainGeo = new THREE.SphereGeometry(0.22, 12, 12);
    const head = new THREE.Mesh(brainGeo, this.materials.lickerMuscle);
    head.position.set(0, 0.45, 0.55);
    group.add(head);

    // Long Whip Tongue
    const tongueGeo = new THREE.CylinderGeometry(0.02, 0.01, 0.7);
    const tongue = new THREE.Mesh(tongueGeo, this.materials.herbRed);
    tongue.position.set(0, 0.38, 0.9);
    tongue.rotation.x = 1.3;
    group.add(tongue);

    // Razor Claws
    const clawGeo = new THREE.BoxGeometry(0.12, 0.35, 0.12);
    const flClaw = new THREE.Mesh(clawGeo, this.materials.metalDark);
    flClaw.position.set(-0.35, 0.2, 0.4);
    group.add(flClaw);

    const frClaw = new THREE.Mesh(clawGeo, this.materials.metalDark);
    frClaw.position.set(0.35, 0.2, 0.4);
    group.add(frClaw);

    return group;
  }

  static createMrXMesh() {
    const group = new THREE.Group();
    group.name = 'MrXStalker';

    // Imposing Coat Body
    const coatGeo = new THREE.BoxGeometry(0.85, 1.2, 0.5);
    const coat = new THREE.Mesh(coatGeo, this.materials.mrxCoat);
    coat.position.y = 1.3;
    coat.castShadow = true;
    group.add(coat);

    // Gray Pale Head
    const headGeo = new THREE.SphereGeometry(0.24, 16, 16);
    const head = new THREE.Mesh(headGeo, this.materials.mrxSkin);
    head.position.y = 2.05;
    head.castShadow = true;
    group.add(head);

    // Fedora Hat
    const hatBrimGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.03, 16);
    const brim = new THREE.Mesh(hatBrimGeo, this.materials.mrxCoat);
    brim.position.y = 2.22;
    group.add(brim);

    const hatTopGeo = new THREE.CylinderGeometry(0.22, 0.24, 0.2, 16);
    const top = new THREE.Mesh(hatTopGeo, this.materials.mrxCoat);
    top.position.y = 2.33;
    group.add(top);

    // Heavy Arms
    const armGeo = new THREE.BoxGeometry(0.25, 0.95, 0.25);
    const leftArm = new THREE.Mesh(armGeo, this.materials.mrxCoat);
    leftArm.position.set(-0.52, 1.25, 0);
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, this.materials.mrxCoat);
    rightArm.position.set(0.52, 1.25, 0);
    group.add(rightArm);

    // Massive Boots & Legs
    const legGeo = new THREE.BoxGeometry(0.28, 0.8, 0.28);
    const leftLeg = new THREE.Mesh(legGeo, this.materials.mrxCoat);
    leftLeg.position.set(-0.22, 0.4, 0);
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, this.materials.mrxCoat);
    rightLeg.position.set(0.22, 0.4, 0);
    group.add(rightLeg);

    return group;
  }

  static createBirkinBossMesh() {
    const group = new THREE.Group();
    group.name = 'BirkinBoss';

    // Mutated Torso
    const torsoGeo = new THREE.BoxGeometry(0.9, 1.0, 0.6);
    const torso = new THREE.Mesh(torsoGeo, this.materials.lickerMuscle);
    torso.position.y = 1.2;
    torso.castShadow = true;
    group.add(torso);

    // Massive Giant Eye on Right Shoulder
    const eyeGeo = new THREE.SphereGeometry(0.3, 16, 16);
    const eye = new THREE.Mesh(eyeGeo, this.materials.birkinEye);
    eye.position.set(0.48, 1.5, 0.15);
    group.add(eye);

    // Giant Steel Pipe Claw Weapon
    const pipeGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.2);
    const pipe = new THREE.Mesh(pipeGeo, this.materials.metalDark);
    pipe.position.set(0.7, 1.1, 0.4);
    pipe.rotation.x = 0.5;
    group.add(pipe);

    // Legs
    const legGeo = new THREE.BoxGeometry(0.3, 0.8, 0.3);
    const leftLeg = new THREE.Mesh(legGeo, this.materials.zombieSkin);
    leftLeg.position.set(-0.25, 0.4, 0);
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, this.materials.zombieSkin);
    rightLeg.position.set(0.25, 0.4, 0);
    group.add(rightLeg);

    return group;
  }

  // --- WEAPON MESHES ---

  static createHandgunMesh() {
    const group = new THREE.Group();
    const slideGeo = new THREE.BoxGeometry(0.06, 0.08, 0.28);
    const slide = new THREE.Mesh(slideGeo, this.materials.metalDark);
    slide.position.set(0, 0.05, 0);
    group.add(slide);

    const gripGeo = new THREE.BoxGeometry(0.05, 0.16, 0.08);
    const grip = new THREE.Mesh(gripGeo, this.materials.woodDark);
    grip.position.set(0, -0.05, -0.08);
    grip.rotation.x = -0.2;
    group.add(grip);

    return group;
  }

  static createShotgunMesh() {
    const group = new THREE.Group();
    const barrelGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.75);
    const barrel = new THREE.Mesh(barrelGeo, this.materials.metalDark);
    barrel.rotation.x = Math.PI / 2;
    group.add(barrel);

    const stockGeo = new THREE.BoxGeometry(0.06, 0.1, 0.3);
    const stock = new THREE.Mesh(stockGeo, this.materials.woodDark);
    stock.position.set(0, -0.03, -0.35);
    group.add(stock);

    return group;
  }

  static createMagnumMesh() {
    const group = new THREE.Group();
    const barrelGeo = new THREE.BoxGeometry(0.07, 0.1, 0.4);
    const barrel = new THREE.Mesh(barrelGeo, this.materials.metalSilver);
    barrel.position.set(0, 0.04, 0.1);
    group.add(barrel);

    const cylGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.12, 8);
    const cyl = new THREE.Mesh(cylGeo, this.materials.metalSilver);
    cyl.rotation.x = Math.PI / 2;
    cyl.position.set(0, 0.02, -0.08);
    group.add(cyl);

    const gripGeo = new THREE.BoxGeometry(0.06, 0.18, 0.09);
    const grip = new THREE.Mesh(gripGeo, this.materials.woodDark);
    grip.position.set(0, -0.08, -0.12);
    grip.rotation.x = -0.3;
    group.add(grip);

    return group;
  }

  // --- ITEM MESHES ---

  static createKeyMesh(type = 'spade') {
    const group = new THREE.Group();
    const stemGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.3);
    const stem = new THREE.Mesh(stemGeo, this.materials.metalGold);
    stem.rotation.x = Math.PI / 2;
    group.add(stem);

    // Key Head emblem
    let emblemColor = 0x3366cc; // Spade = blue
    if (type === 'diamond') emblemColor = 0xcc3333; // Red
    if (type === 'heart') emblemColor = 0xcc33aa; // Pink
    if (type === 'club') emblemColor = 0x33cc66; // Green

    const emblemMat = new THREE.MeshStandardMaterial({ color: emblemColor, metalness: 0.7, roughness: 0.3 });
    const headGeo = new THREE.BoxGeometry(0.1, 0.1, 0.02);
    const head = new THREE.Mesh(headGeo, emblemMat);
    head.position.z = -0.15;
    group.add(head);

    return group;
  }

  static createHerbMesh(colorType = 'green') {
    const group = new THREE.Group();
    const potGeo = new THREE.CylinderGeometry(0.12, 0.08, 0.18, 12);
    const pot = new THREE.Mesh(potGeo, this.materials.woodDark);
    group.add(pot);

    const mat = colorType === 'red' ? this.materials.herbRed : this.materials.herbGreen;
    const leafGeo = new THREE.ConeGeometry(0.15, 0.3, 8);
    const plant = new THREE.Mesh(leafGeo, mat);
    plant.position.y = 0.2;
    group.add(plant);

    return group;
  }

  static createMedallionMesh(symbol = 'lion') {
    const group = new THREE.Group();
    const coinGeo = new THREE.CylinderGeometry(0.25, 0.25, 0.05, 24);
    const coin = new THREE.Mesh(coinGeo, this.materials.metalGold);
    coin.rotation.x = Math.PI / 2;
    group.add(coin);

    return group;
  }

  static createItemBoxMesh() {
    const group = new THREE.Group();
    const boxGeo = new THREE.BoxGeometry(1.2, 0.8, 0.8);
    const box = new THREE.Mesh(boxGeo, this.materials.woodDark);
    box.position.y = 0.4;
    box.castShadow = true;
    box.receiveShadow = true;
    group.add(box);

    const trimGeo = new THREE.BoxGeometry(1.24, 0.1, 0.84);
    const trim = new THREE.Mesh(trimGeo, this.materials.metalDark);
    trim.position.y = 0.4;
    group.add(trim);

    return group;
  }

  static createTypewriterMesh() {
    const group = new THREE.Group();
    const baseGeo = new THREE.BoxGeometry(0.6, 0.15, 0.5);
    const base = new THREE.Mesh(baseGeo, this.materials.metalDark);
    base.position.y = 0.075;
    group.add(base);

    const keysGeo = new THREE.BoxGeometry(0.5, 0.08, 0.2);
    const keys = new THREE.Mesh(keysGeo, this.materials.plasticWhite);
    keys.position.set(0, 0.12, 0.1);
    group.add(keys);

    return group;
  }
}
