const VERTEX = `
attribute vec3 aPosition; attribute vec3 aNormal; attribute vec3 aColor;
uniform mat4 uMvp; uniform mat4 uModel;
varying vec3 vNormal; varying vec3 vColor; varying vec3 vWorld;
void main(){ vec4 world=uModel*vec4(aPosition,1.0); vWorld=world.xyz; vNormal=normalize(mat3(uModel)*aNormal); vColor=aColor; gl_Position=uMvp*vec4(aPosition,1.0); }`;
const FRAGMENT = `
precision mediump float; varying vec3 vNormal; varying vec3 vColor; varying vec3 vWorld; uniform vec3 uLight; uniform vec3 uCamera; uniform float uTime;
void main(){
 vec3 n=normalize(vNormal), l=normalize(uLight), v=normalize(uCamera-vWorld), h=normalize(l+v);
 float diffuse=max(dot(n,l),0.0), specular=pow(max(dot(n,h),0.0),24.0)*0.22;
 float fill=max(dot(n,normalize(vec3(0.65,0.25,-0.55))),0.0)*0.13;
 float rim=pow(1.0-max(dot(n,v),0.0),2.0)*0.12;
 float pulse=0.97+0.03*sin(uTime*1.7+vWorld.x*0.18+vWorld.z*0.13);
 vec3 lit=vColor*(0.30+diffuse*0.70+fill)*pulse+vec3(1.0,0.82,0.56)*specular+vec3(0.22,0.48,0.72)*rim;
 float fog=clamp((length(uCamera-vWorld)-17.0)/22.0,0.0,0.48);
 vec3 fogColor=vec3(0.025,0.045,0.085);
 gl_FragColor=vec4(mix(lit,fogColor,fog),1.0);
}`;
const mat4={
 perspective(fovy,aspect,near,far){const f=1/Math.tan(fovy/2),nf=1/(near-far),o=new Float32Array(16);o[0]=f/aspect;o[5]=f;o[10]=(far+near)*nf;o[11]=-1;o[14]=2*far*near*nf;return o;},
 lookAt(eye,center,up){let zx=eye[0]-center[0],zy=eye[1]-center[1],zz=eye[2]-center[2],l=Math.hypot(zx,zy,zz)||1;zx/=l;zy/=l;zz/=l;let xx=up[1]*zz-up[2]*zy,xy=up[2]*zx-up[0]*zz,xz=up[0]*zy-up[1]*zx;l=Math.hypot(xx,xy,xz)||1;xx/=l;xy/=l;xz/=l;const yx=zy*xz-zz*xy,yy=zz*xx-zx*xz,yz=zx*xy-zy*xx;return new Float32Array([xx,yx,zx,0,xy,yy,zy,0,xz,yz,zz,0,-(xx*eye[0]+xy*eye[1]+xz*eye[2]),-(yx*eye[0]+yy*eye[1]+yz*eye[2]),-(zx*eye[0]+zy*eye[1]+zz*eye[2]),1]);},
 multiply(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o;}
};
function addQuad(out,corners,color,normal=[0,1,0]){const[a,b,c,d]=corners;for(const p of[a,b,c,a,c,d])out.push(...p,...normal,...color);}
function addBoxTop(out,x,z,w,d,y,color){addQuad(out,[[x,y,z],[x+w,y,z],[x+w,y,z+d],[x,y,z+d]],color,[0,1,0]);const side=color.map(v=>v*.55);addQuad(out,[[x,y,z],[x+w,y,z],[x+w,y-.12,z],[x,y-.12,z]],side,[0,0,-1]);addQuad(out,[[x+w,y,z],[x+w,y,z+d],[x+w,y-.12,z+d],[x+w,y-.12,z]],side,[1,0,0]);addQuad(out,[[x+w,y,z+d],[x,y,z+d],[x,y-.12,z+d],[x+w,y-.12,z+d]],side,[0,0,1]);addQuad(out,[[x,y,z+d],[x,y,z],[x,y-.12,z],[x,y-.12,z+d]],side,[-1,0,0]);}
function addBox(out,x,y,z,w,h,d,color){const x1=x+w,y1=y+h,z1=z+d;addQuad(out,[[x,y1,z],[x1,y1,z],[x1,y1,z1],[x,y1,z1]],color,[0,1,0]);addQuad(out,[[x,y,z1],[x1,y,z1],[x1,y,z],[x,y,z]],color.map(v=>v*.55),[0,-1,0]);addQuad(out,[[x,y,z],[x1,y,z],[x1,y1,z],[x,y1,z]],color.map(v=>v*.72),[0,0,-1]);addQuad(out,[[x1,y,z1],[x,y,z1],[x,y1,z1],[x1,y1,z1]],color.map(v=>v*.72),[0,0,1]);addQuad(out,[[x,y,z1],[x,y,z],[x,y1,z],[x,y1,z1]],color.map(v=>v*.62),[-1,0,0]);addQuad(out,[[x1,y,z],[x1,y,z1],[x1,y1,z1],[x1,y1,z]],color.map(v=>v*.62),[1,0,0]);}
function addCylinder(out,cx,cz,r,y0,y1,color,segments=16){for(let i=0;i<segments;i++){const a=i/segments*Math.PI*2,b=(i+1)/segments*Math.PI*2,p0=[cx+Math.cos(a)*r,y0,cz+Math.sin(a)*r],p1=[cx+Math.cos(b)*r,y0,cz+Math.sin(b)*r],p2=[cx+Math.cos(b)*r,y1,cz+Math.sin(b)*r],p3=[cx+Math.cos(a)*r,y1,cz+Math.sin(a)*r],n0=[Math.cos(a),0,Math.sin(a)],n1=[Math.cos(b),0,Math.sin(b)];out.push(...p0,...n0,...color,...p1,...n1,...color,...p2,...n1,...color,...p0,...n0,...color,...p2,...n1,...color,...p3,...n0,...color);out.push(cx,y1,cz,0,1,0,...color,...p3,0,1,0,...color,...p2,0,1,0,...color);}}
function addSphere(out,cx,cy,cz,r,color,lat=8,lon=12){for(let i=0;i<lat;i++){const p0=-Math.PI/2+i*Math.PI/lat,p1=-Math.PI/2+(i+1)*Math.PI/lat;for(let j=0;j<lon;j++){const a0=j*2*Math.PI/lon,a1=(j+1)*2*Math.PI/lon;const point=(p,a)=>[cx+r*Math.cos(p)*Math.cos(a),cy+r*Math.sin(p),cz+r*Math.cos(p)*Math.sin(a)];const a=point(p0,a0),b=point(p0,a1),c=point(p1,a1),d=point(p1,a0);for(const q of[a,b,c,a,c,d]){const n=[(q[0]-cx)/r,(q[1]-cy)/r,(q[2]-cz)/r];out.push(...q,...n,...color);}}}}
function addLimb(out,a,b,r,color,segments=8){const axis=[b[0]-a[0],b[1]-a[1],b[2]-a[2]],len=Math.hypot(...axis)||1;for(let i=0;i<3;i++)axis[i]/=len;const helper=Math.abs(axis[1])>.92?[1,0,0]:[0,1,0];let u=[axis[1]*helper[2]-axis[2]*helper[1],axis[2]*helper[0]-axis[0]*helper[2],axis[0]*helper[1]-axis[1]*helper[0]],ul=Math.hypot(...u)||1;u=u.map(q=>q/ul);const v=[axis[1]*u[2]-axis[2]*u[1],axis[2]*u[0]-axis[0]*u[2],axis[0]*u[1]-axis[1]*u[0]];for(let i=0;i<segments;i++){const t0=i*2*Math.PI/segments,t1=(i+1)*2*Math.PI/segments;const ring=(p,t)=>[p[0]+r*(u[0]*Math.cos(t)+v[0]*Math.sin(t)),p[1]+r*(u[1]*Math.cos(t)+v[1]*Math.sin(t)),p[2]+r*(u[2]*Math.cos(t)+v[2]*Math.sin(t))];const p0=ring(a,t0),p1=ring(a,t1),p2=ring(b,t1),p3=ring(b,t0),n0=u.map((q,k)=>q*Math.cos(t0)+v[k]*Math.sin(t0)),n1=u.map((q,k)=>q*Math.cos(t1)+v[k]*Math.sin(t1));for(const [p,n] of[[p0,n0],[p1,n1],[p2,n1],[p0,n0],[p2,n1],[p3,n0]])out.push(...p,...n,...color);}}
function addPiece(out,x,z,piece,pose=null){
 const red=piece>0,king=Math.abs(piece)===2,lift=pose?.lift||0,lean=pose?.lean||0,action=pose?.action||'idle',intensity=pose?.intensity??1;
 const base=red?[.68,.12,.16]:[.10,.36,.68],edge=red?[.28,.035,.05]:[.025,.12,.29],robe=red?[.82,.20,.23]:[.13,.43,.78],highlight=red?[1,.53,.48]:[.52,.82,1];
 addCylinder(out,x,z,.35,.055,.15,edge);addCylinder(out,x,z,.32,.15,.22,base);
 // Corps humain en volumes superposés : chaussures, jambes, genoux, tunique et épaules.
 const gait=pose?.gait||0,sway=pose?.sway||0;
 const headTilt=action==='defeat'?.16*intensity:action==='celebrate'?-.08*intensity:action==='thinking'?.10*intensity:0;
 const eyeScale=action==='thinking'?.82:action==='celebrate'?1.12:1;
 // Expressions faciales : inclinaison, ouverture du regard et tension de la bouche.
 const mouthColor=action==='defeat'?[.18,.045,.045]:action==='celebrate'?[.32,.07,.055]:[.20,.075,.065];
 const hipY=.20+lift,kneeY=.125+lift,footY=.055+lift;
 for(const side of[-1,1]){
  const phase=gait*side,hip=[x+side*.075+lean,hipY,z],knee=[x+side*.09+lean+phase*.025,kneeY+Math.abs(phase)*.018,z+sway*.025],foot=[x+side*.085+lean+phase*.045,footY,z+phase*.045];
  addLimb(out,hip,knee,.047,edge,8);addSphere(out,knee[0],knee[1],knee[2],.047,base,6,8);addLimb(out,knee,foot,.041,base,8);
  addBox(out,foot[0]-.065,foot[1]-.02,foot[2]-.025,.13,.055,.19,[.045,.055,.075]);
 }
 addBox(out,x-.15,.035+lift,z+.015,.13,.065,.19,[.045,.055,.075]);
 addBox(out,x+.02,.035+lift,z+.015,.13,.065,.19,[.045,.055,.075]);
 addLimb(out,[x+lean,.19+lift,z],[x+lean,.62+lift,z],.145,robe,12);
 addCylinder(out,x+lean,z,.09,.60+lift,.68+lift,[.72,.52,.39],10);
 addCylinder(out,x+lean,z,.148,.25+lift,.285+lift,edge,12);
 addLimb(out,[x+lean-.075,.55+lift,z+.11],[x+lean+.075,.55+lift,z+.11],.018,highlight,7);
 addSphere(out,x+lean+.065,.48+lift,z+.137,.035,[.94,.78,.35],7,9);
 const headDrop=action==='defeat'?.09*intensity:0,skin=[.62,.42,.31],hair=[.075,.052,.04],headY=.72+lift-headDrop;
 addSphere(out,x+lean,.72+lift-headDrop,z,.125,skin,12,16);
 addSphere(out,x+lean,headY+.075+headTilt*.12,z-.035,.095,hair,8,12);
 // Yeux, nez et bouche : expressions faciales intégrées au maillage.
 // Repère facial ex-.018 pour contrôler le décalage des yeux.
 for(const eyeX of[-.043,.043]){
  addSphere(out,x+lean+eyeX,headY+.025,z+.108,.018*eyeScale,[.96,.94,.86],6,8);
  addSphere(out,x+lean+eyeX,headY+.025,z+.124,.009*eyeScale,[.035,.028,.025],5,6);
  const browY=headY+.055+(action==='defeat'?-.012:action==='thinking'?.012:0);
  addLimb(out,[x+lean+eyeX-.022,browY,z+.11],[x+lean+eyeX+.022,browY+.006,z+.11],.008,hair,5);
 }
 addSphere(out,x+lean,headY-.005,z+.13,.014,skin,5,6);
 addLimb(out,[x+lean-.025,headY-.035,z+.116],[x+lean+.025,headY-.035,z+.116],.006,mouthColor,6);
 // Bras articulés en trois points : épaule, coude, main.
 let left=[x-.20+lean,.43+lift,z],right=[x+.20+lean,.43+lift,z];
 if(action==='thinking'){left=[x-.10+lean,.78+lift,z];}
 if(action==='capture'){left=[x-.30+lean,.54+lift,z-.13*intensity];right=[x+.30+lean,.54+lift,z-.13*intensity];}
 if(action==='celebrate'){left=[x-.27+lean,.98+lift,z];right=[x+.27+lean,.98+lift,z];}
 if(action==='defeat'){left=[x-.23+lean,.27+lift,z];right=[x+.23+lean,.27+lift,z];}
 if(action==='presentation'){left=[x-.34+lean,.70+lift,z];right=[x+.34+lean,.70+lift,z];}
 const leftShoulder=[x+lean-.09,.59+lift,z],rightShoulder=[x+lean+.09,.59+lift,z];
 const leftElbow=[(leftShoulder[0]+left[0])*.5-.035,(leftShoulder[1]+left[1])*.5+.045,z+.025];
 const rightElbow=[(rightShoulder[0]+right[0])*.5+.035,(rightShoulder[1]+right[1])*.5+.045,z+.025];
 addLimb(out,leftShoulder,leftElbow,.047,base);addSphere(out,leftElbow[0],leftElbow[1],leftElbow[2],.043,edge,6,8);addLimb(out,leftElbow,left,.042,base);
 addLimb(out,rightShoulder,rightElbow,.047,base);addSphere(out,rightElbow[0],rightElbow[1],rightElbow[2],.043,edge,6,8);addLimb(out,rightElbow,right,.042,base);
 addSphere(out,left[0],left[1],left[2],.052,skin,7,9);addSphere(out,right[0],right[1],right[2],.052,skin,7,9);
 if(king){addCylinder(out,x+lean,z,.145,.835+lift-headDrop,.875+lift-headDrop,[.88,.70,.24],12);addSphere(out,x+lean,.89+lift-headDrop,z,.075,[1,.88,.48],7,10);for(let k=0;k<5;k++){const a=k*Math.PI*2/5;addLimb(out,[x+lean+Math.cos(a)*.11,.85+lift-headDrop,z+Math.sin(a)*.11],[x+lean+Math.cos(a)*.14,.98+lift-headDrop,z+Math.sin(a)*.14],.025,[.96,.79,.31],6);}}
}
let arenaReaction='idle';
function addArena(out,time=0){
 // Socle monumental, gradins en quatre tribunes et couronne lumineuse.
 addBox(out,-8.2,-.72,-8.2,16.4,.45,16.4,[.055,.085,.14]);
 const tiers=[{y:-.12,h:.48,r:6.0,c:[.12,.17,.27]},{y:.36,h:.52,r:6.65,c:[.16,.22,.34]},{y:.88,h:.52,r:7.3,c:[.20,.25,.36]},{y:1.40,h:.42,r:7.95,c:[.11,.15,.24]}];
 for(const t of tiers){const s=t.r*2;addBox(out,-t.r,t.y,-t.r,s,t.h,.48,t.c);addBox(out,-t.r,t.y,t.r-.48,s,t.h,.48,t.c);addBox(out,-t.r,t.y,-t.r+.48,.48,t.h,s-.96,t.c);addBox(out,t.r-.48,t.y,-t.r+.48,.48,t.h,s-.96,t.c);}
 // Public stylisé : gradins de silhouettes colorées, réparties sur les quatre tribunes.
 const palette=[[.78,.24,.19],[.92,.68,.24],[.18,.58,.72],[.40,.72,.48],[.75,.78,.88],[.43,.31,.72]];
 for(let row=0;row<4;row++){const y=.46+row*.52,offset=6.15+row*.58;for(let i=0;i<22;i+=2){const along=-5.35+i*.51,col=palette[(i*3+row*5)%palette.length],wave=.045+.075*Math.sin(time*2.1+i*.63+row*.9)+(arenaReaction==='celebrate'?.10*Math.abs(Math.sin(time*5+i)):arenaReaction==='defeat'?.035*Math.sin(time*1.4+i):0);
  for(const [sx,sz,fan] of[[along,-offset,0],[along,offset,1],[-offset,along,2],[offset,along,3]]){const tone=palette[(i+row*2+fan)%palette.length];addCylinder(out,sx,sz,.082,y,y+.17,tone,8);addSphere(out,sx,y+.235,sz,.068,[.66,.47,.34],5,6);const shoulder=[sx,y+.145,sz],hand=[sx+(fan<2?wave:0),y+.30+wave,sz+(fan>=2?wave:0)];addLimb(out,shoulder,hand,.018,tone,5);}
 }}
 // Pylônes d'éclairage et projecteurs aux angles.
 for(const x of[-7.55,7.55])for(const z of[-7.55,7.55]){addCylinder(out,x,z,.13,-.25,3.15,[.38,.48,.62],12);addBox(out,x-.42,3.12,z-.20,.84,.20,.40,[.72,.82,.96]);for(let n=0;n<3;n++)addCylinder(out,x-.25+n*.25,z,.07,3.2,3.28,[1,.88,.56],10);}
 // Bandeau périphérique.
 addBox(out,-5.85,.02,-5.92,11.7,.18,.20,[.72,.48,.16]);addBox(out,-5.85,.02,5.72,11.7,.18,.20,[.72,.48,.16]);addBox(out,-5.92,.02,-5.72,.20,.18,11.44,[.72,.48,.16]);addBox(out,5.72,.02,-5.72,.20,.18,11.44,[.72,.48,.16]);
}
function buildScene(board,selected,targets,animation=null,pose=null,time=0){const out=[];arenaReaction=pose?.action||'idle';if(animation?.action)arenaReaction=animation.action;addArena(out,time);addBoxTop(out,-5.25,-5.25,10.5,10.5,-.10,[.20,.13,.07]);for(let r=0;r<10;r++)for(let c=0;c<10;c++){const x=c-5,z=r-5,isDark=(r+c)%2===1;let color=isDark?[.16,.23,.35]:[.78,.73,.62];if(selected&&selected[0]===r&&selected[1]===c)color=[.78,.52,.12];else if(targets?.has(`${r},${c}`))color=[.12,.52,.43];addQuad(out,[[x,.015,z],[x+1,.015,z],[x+1,.015,z+1],[x,.015,z+1]],color);addQuad(out,[[x,.014,z],[x+1,.014,z],[x+1,.014,z+.025],[x,.014,z+.025]],[.92,.83,.62]);const piece=board[r][c];if(piece&&!(animation&&animation.to[0]===r&&animation.to[1]===c)){const posed=pose&&pose.r===r&&pose.c===c?pose:null;addPiece(out,c-4.5,r-4.5,piece,posed);}}
 if(animation){const{x,z,piece}=animation;addPiece(out,x,z,piece,{lift:animation.lift||0,lean:animation.lean||0,action:animation.action||'idle',intensity:animation.intensity??1});}return new Float32Array(out);}
export function create3DScene(host){
 const canvas=document.createElement('canvas');canvas.className='cgd-3d-canvas';canvas.setAttribute('aria-hidden','true');host.appendChild(canvas);const gl=canvas.getContext('webgl',{antialias:true,alpha:false})||canvas.getContext('experimental-webgl');if(!gl){canvas.remove();return{available:false,draw(){},animateMove(){},destroy(){}};}
 const compile=(type,source)=>{const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s)||'Erreur shader');return s;};const program=gl.createProgram();gl.attachShader(program,compile(gl.VERTEX_SHADER,VERTEX));gl.attachShader(program,compile(gl.FRAGMENT_SHADER,FRAGMENT));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program)||'Liaison WebGL impossible');
 gl.useProgram(program);const buffer=gl.createBuffer(),pos=gl.getAttribLocation(program,'aPosition'),norm=gl.getAttribLocation(program,'aNormal'),col=gl.getAttribLocation(program,'aColor'),mvpLoc=gl.getUniformLocation(program,'uMvp'),modelLoc=gl.getUniformLocation(program,'uModel'),cameraLoc=gl.getUniformLocation(program,'uCamera'),timeLoc=gl.getUniformLocation(program,'uTime');gl.uniform3f(gl.getUniformLocation(program,'uLight'),-.45,1,.65);const model=new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);let last=null,yaw=.22,zoom=1,tilt=0.0,drag=null,suppressClick=false,animationFrame=0,poseFrame=0;
 function draw(board,selected,targets,cinematic=true,animation=null,pose=null){const rect=host.getBoundingClientRect(),dpr=Math.min(window.devicePixelRatio||1,1.6),w=Math.max(1,Math.round(rect.width*dpr)),h=Math.max(1,Math.round(rect.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}gl.viewport(0,0,w,h);gl.enable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.clearColor(.025,.045,.085,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);const time=performance.now()/1000, radius=(cinematic?20.4:23.5)/zoom, drift=drag?0:Math.sin(time*.22)*.018,angle=tilt+.62+(!drag&&cinematic?Math.sin(time*.17)*.008:0),eye=[Math.sin(yaw+drift)*radius,Math.sin(angle)*radius,Math.cos(yaw+drift)*radius];const projection=mat4.perspective(Math.PI/4,w/h,.1,70),view=mat4.lookAt(eye,[0,.35,0],[0,1,0]),vp=mat4.multiply(projection,view);gl.uniformMatrix4fv(mvpLoc,false,vp);gl.uniformMatrix4fv(modelLoc,false,model);gl.uniform3f(cameraLoc,eye[0],eye[1],eye[2]);gl.uniform1f(timeLoc,time);const data=buildScene(board,selected,targets,animation,pose,time);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,data,gl.DYNAMIC_DRAW);const stride=9*4;gl.enableVertexAttribArray(pos);gl.vertexAttribPointer(pos,3,gl.FLOAT,false,stride,0);gl.enableVertexAttribArray(norm);gl.vertexAttribPointer(norm,3,gl.FLOAT,false,stride,3*4);gl.enableVertexAttribArray(col);gl.vertexAttribPointer(col,3,gl.FLOAT,false,stride,6*4);gl.drawArrays(gl.TRIANGLES,0,data.length/9);last={board,selected,targets,cinematic,animation,pose};}
 function redraw(){if(last)draw(last.board,last.selected,last.targets,last.cinematic,last.animation,last.pose);}
 function onDown(e){drag={x:e.clientX,y:e.clientY,yaw,tilt,moved:false};}
 function onMove(e){if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)+Math.abs(dy)>5)drag.moved=true;if(drag.moved){yaw=drag.yaw+dx*.008;tilt=Math.max(-.10,Math.min(.42,drag.tilt-dy*.004));redraw();}}
 function onUp(){if(drag?.moved){suppressClick=true;setTimeout(()=>{suppressClick=false;},0);}drag=null;redraw();}
 function onClickCapture(e){if(suppressClick){e.stopPropagation();e.preventDefault();}}
 function onWheel(e){e.preventDefault();zoom=Math.max(.78,Math.min(1.32,zoom+(e.deltaY>0?-.06:.06)));redraw();}
 host.addEventListener('pointerdown',onDown);host.addEventListener('pointermove',onMove);host.addEventListener('pointerup',onUp);host.addEventListener('pointercancel',onUp);host.addEventListener('click',onClickCapture,true);host.addEventListener('wheel',onWheel,{passive:false});const onResize=redraw;window.addEventListener('resize',onResize);
 function playPose(board,side,action='thinking',duration=900){if(!last)return;cancelAnimationFrame(animationFrame);cancelAnimationFrame(poseFrame);let anchor=null;for(let r=0;r<10&&!anchor;r++)for(let c=0;c<10;c++)if(board[r][c]&&Math.sign(board[r][c])===Math.sign(side)){anchor={r,c};break;}if(!anchor)return;const start=performance.now();const tick=now=>{const t=Math.min(1,(now-start)/duration),pulse=action==='thinking'?.35+.65*Math.sin(t*Math.PI):Math.sin(t*Math.PI);draw(board,last.selected,last.targets,true,null,{...anchor,action,intensity:pulse,lean:action==='defeat'?.12*pulse:0,lift:action==='celebrate'?.08*pulse:0});if(t<1)poseFrame=requestAnimationFrame(tick);else draw(board,last.selected,last.targets,true);};poseFrame=requestAnimationFrame(tick);}
 function animateMove(board,move,piece,selected,targets){if(!last)return;cancelAnimationFrame(animationFrame);cancelAnimationFrame(poseFrame);const steps=move.path||[];let segment=0;const segmentStart=()=>{const from=segment===0?steps[0].from:steps[segment-1].to,to=steps[segment].to;const start=performance.now(),duration=170;const tick=now=>{const t=Math.min(1,(now-start)/duration),ease=t*t*(3-2*t),x=(from[1]-4.5)+((to[1]-4.5)-(from[1]-4.5))*ease,z=(from[0]-4.5)+((to[0]-4.5)-(from[0]-4.5))*ease;draw(board,selected,targets,true,{x,z,piece,to,lift:Math.sin(t*Math.PI)*.28,lean:Math.sin(t*Math.PI)*.035,gait:Math.sin(t*Math.PI*2),sway:Math.cos(t*Math.PI*2),side:Math.sign(to[1]-from[1]||1),phase:Math.sin(t*Math.PI*2)*Math.sign(to[1]-from[1]||1)});if(t<1)animationFrame=requestAnimationFrame(tick);else if(++segment<steps.length)segmentStart();else draw(board,selected,targets,true);};animationFrame=requestAnimationFrame(tick);};if(!steps.length)return;const begin=()=>segmentStart();if(move.captures?.length){const from=steps[0].from,started=performance.now(),duration=220;const gesture=now=>{const t=Math.min(1,(now-started)/duration);draw(board,selected,targets,true,{x:from[1]-4.5,z:from[0]-4.5,piece,to:steps.at(-1).to,action:'capture',intensity:Math.sin(t*Math.PI)});if(t<1)animationFrame=requestAnimationFrame(gesture);else begin();};animationFrame=requestAnimationFrame(gesture);}else begin();}
 return{available:true,canvas,draw,animateMove,playPose,destroy(){cancelAnimationFrame(animationFrame);cancelAnimationFrame(poseFrame);host.removeEventListener('pointerdown',onDown);host.removeEventListener('pointermove',onMove);host.removeEventListener('pointerup',onUp);host.removeEventListener('pointercancel',onUp);host.removeEventListener('click',onClickCapture,true);host.removeEventListener('wheel',onWheel);window.removeEventListener('resize',onResize);canvas.remove();gl.deleteBuffer(buffer);gl.deleteProgram(program);}};
}
