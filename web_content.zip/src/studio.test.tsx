import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from './App';
import ShuttleStudio from './components/ShuttleStudio';
import BatteryStudio, { readoutValue } from './components/BatteryStudio';
import { beforeEach, describe, expect, it } from 'vitest';
import '@testing-library/jest-dom/vitest';
import { initialBatteries } from './data/mockData';

describe('V8 engineering command center', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('shows an operating mode switch with REAL disabled and a reason', () => {
    render(<App />);
    expect(screen.getByRole('button', { name: /SIMULATION/i })).toBeInTheDocument();
    const real = screen.getByRole('button', { name: /REAL/i });
    expect(real).toBeDisabled();
    expect(real.getAttribute('title')).toMatch(/no verified plc/i);
  });

  it('persists the simulation mode across a reload', async () => {
    const user = userEvent.setup();
    const first = render(<App />);
    await user.click(screen.getByRole('button', { name: /^SIMULATION$/i }));
    first.unmount();
    render(<App />);
    expect(screen.getByRole('button', { name: /^SIMULATION$/i })).toHaveClass('mode-active');
  });

  it('renders the shuttle studio with a caption even without WebGL', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(screen.getByRole('button', { name: /Engineering Visualization/i }));
    expect(screen.getAllByText(/ISOMETRIC ASSEMBLY/i).length).toBeGreaterThan(0);
    expect(screen.getByText(/3D viewing is not available|Preparing model/i)).toBeInTheDocument();
  });

  it('lets every studio component be selected for inspection', () => {
    render(<ShuttleStudio manufacturer="Cassioli" unitId="SC-01" view="iso" exploded={false} animated={false} mode="OFFLINE" status="Unknown" language="en" />);
    const part = screen.getByRole('button', { name: /Battery compartment/i });
    expect(part).toBeInTheDocument();
  });

  it('shows UNKNOWN for unverified battery values, never invented telemetry', () => {
    render(<BatteryStudio battery={initialBatteries[0]} language="en" mode="OFFLINE" animated={false} />);
    expect(screen.getAllByText(/BATTERY ASSEMBLY|3D viewing is not available/i).length).toBeGreaterThan(0);
    expect(screen.queryByText(/serial|firmware/i)).not.toBeInTheDocument();
    // Reported-but-unverified values must never present as telemetry.
    expect(readoutValue(false, 0, '%')).toBeNull();
    expect(readoutValue(false, 82, '%')).toBeNull();
    expect(readoutValue(true, 82, '%')).toBe('82%');
    expect(readoutValue(true, null, '%')).toBeNull();
  });

  it('marks simulated battery motion as SIMULATION', async () => {
    const user = userEvent.setup();
    render(<App />);
    await user.click(screen.getByRole('button', { name: /Battery Management/i }));
    await user.click(screen.getByRole('button', { name: /^SIMULATION$/i }));
    expect(screen.getAllByText(/SIMULATION/i).length).toBeGreaterThan(0);
  });
});
