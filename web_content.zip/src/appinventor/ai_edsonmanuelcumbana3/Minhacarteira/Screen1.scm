#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"237","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"32","AboutScreen":"Minhacarteita","ActionBar":"True","AlignHorizontal":"3","AppName":"Minhacarteira","BackgroundColor":"&HFF00FFFF","BigDefaultText":"True","HighContrast":"True","Scrollable":"True","Theme":"AppTheme","Title":"Screen1","Uuid":"0"}}
|#