// Catalogue galactique intégré depuis galactique_data_complete.zip.
// Les origines des managers de clubs sont dérivées de l'origine du premier damiste
// de leur club : le fichier source ne précisait pas cette donnée.
export const UNIVERSE_CATALOG = Object.freeze({
  "clubs": [
    {
      "division": "Super League",
      "name": "Cosmos United",
      "damistes": [
        {
          "name": "Kaël Orion",
          "gender": "M",
          "originGalaxyId": "GAL-001",
          "originGalaxy": "Terra Unie"
        },
        {
          "name": "Amara Solène",
          "gender": "F",
          "originGalaxyId": "GAL-002",
          "originGalaxy": "Mars Fédérale"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-01"
    },
    {
      "division": "Super League",
      "name": "Royal Dames FC",
      "damistes": [
        {
          "name": "Malik Ares",
          "gender": "M",
          "originGalaxyId": "GAL-003",
          "originGalaxy": "Vénus Impériale"
        },
        {
          "name": "Inaya Marsel",
          "gender": "F",
          "originGalaxyId": "GAL-004",
          "originGalaxy": "Mercure Solaire"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-02"
    },
    {
      "division": "Super League",
      "name": "Galactic Titans",
      "damistes": [
        {
          "name": "Célian Vénor",
          "gender": "M",
          "originGalaxyId": "GAL-005",
          "originGalaxy": "Jupiter Majeure"
        },
        {
          "name": "Naïra Vénusis",
          "gender": "F",
          "originGalaxyId": "GAL-006",
          "originGalaxy": "Saturne des Anneaux"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-03"
    },
    {
      "division": "Super League",
      "name": "Étoile Noire",
      "damistes": [
        {
          "name": "Elio Mercan",
          "gender": "M",
          "originGalaxyId": "GAL-007",
          "originGalaxy": "Neptune Abyssale"
        },
        {
          "name": "Maëlys Solara",
          "gender": "F",
          "originGalaxyId": "GAL-008",
          "originGalaxy": "Uranus Glaciale"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-04"
    },
    {
      "division": "Super League",
      "name": "Dream Team",
      "damistes": [
        {
          "name": "Darius Jovian",
          "gender": "M",
          "originGalaxyId": "GAL-009",
          "originGalaxy": "Pluton Lointaine"
        },
        {
          "name": "Aïcha Jupiter",
          "gender": "F",
          "originGalaxyId": "GAL-010",
          "originGalaxy": "Lune Argentée"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-05"
    },
    {
      "division": "Super League",
      "name": "FC Galaxy Stars",
      "damistes": [
        {
          "name": "Soren Saturne",
          "gender": "M",
          "originGalaxyId": "GAL-011",
          "originGalaxy": "Andromède Unie"
        },
        {
          "name": "Lyana Astréa",
          "gender": "F",
          "originGalaxyId": "GAL-012",
          "originGalaxy": "Orion Suprême"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-06"
    },
    {
      "division": "Super League",
      "name": "Nova Prime",
      "damistes": [
        {
          "name": "Néo Abyss",
          "gender": "M",
          "originGalaxyId": "GAL-013",
          "originGalaxy": "Sirius Doré"
        },
        {
          "name": "Océane Néris",
          "gender": "F",
          "originGalaxyId": "GAL-014",
          "originGalaxy": "Proxima Libre"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-07"
    },
    {
      "division": "Super League",
      "name": "Orion Stellaris",
      "damistes": [
        {
          "name": "Kylian Frost",
          "gender": "M",
          "originGalaxyId": "GAL-015",
          "originGalaxy": "Kepler Républicaine"
        },
        {
          "name": "Éina Glaciel",
          "gender": "F",
          "originGalaxyId": "GAL-016",
          "originGalaxy": "Nébuleuse du Crabe"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-08"
    },
    {
      "division": "Super League",
      "name": "Comètes Solaires",
      "damistes": [
        {
          "name": "Zayden Plutar",
          "gender": "M",
          "originGalaxyId": "GAL-017",
          "originGalaxy": "Cassiopée Royale"
        },
        {
          "name": "Nyssa Plutoni",
          "gender": "F",
          "originGalaxyId": "GAL-018",
          "originGalaxy": "Pégase Céleste"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-09"
    },
    {
      "division": "Super League",
      "name": "Astres Vagabonds",
      "damistes": [
        {
          "name": "Aylan Lunor",
          "gender": "M",
          "originGalaxyId": "GAL-019",
          "originGalaxy": "Centaure Alpha"
        },
        {
          "name": "Selma Lunéa",
          "gender": "F",
          "originGalaxyId": "GAL-020",
          "originGalaxy": "Lyra Harmonieuse"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-10"
    },
    {
      "division": "Super League",
      "name": "Pulsar Impérial",
      "damistes": [
        {
          "name": "Naël Andros",
          "gender": "M",
          "originGalaxyId": "GAL-021",
          "originGalaxy": "Vega Éternelle"
        },
        {
          "name": "Amaya Andror",
          "gender": "F",
          "originGalaxyId": "GAL-022",
          "originGalaxy": "Solarys Impériale"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-11"
    },
    {
      "division": "Super League",
      "name": "Aurore Cosmique",
      "damistes": [
        {
          "name": "Orion Kaïros",
          "gender": "M",
          "originGalaxyId": "GAL-023",
          "originGalaxy": "Éclipse Noire"
        },
        {
          "name": "Sélène Orialis",
          "gender": "F",
          "originGalaxyId": "GAL-024",
          "originGalaxy": "Astra Nova"
        }
      ],
      "divisionId": "super-league",
      "id": "super-league-12"
    },
    {
      "division": "Ligue A",
      "name": "Titans Stellaires",
      "damistes": [
        {
          "name": "Idriss Sirius",
          "gender": "M",
          "originGalaxyId": "GAL-001",
          "originGalaxy": "Terra Unie"
        },
        {
          "name": "Aïna Dorélia",
          "gender": "F",
          "originGalaxyId": "GAL-002",
          "originGalaxy": "Mars Fédérale"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-01"
    },
    {
      "division": "Ligue A",
      "name": "Éclipse Rouge",
      "damistes": [
        {
          "name": "Maël Proxim",
          "gender": "M",
          "originGalaxyId": "GAL-003",
          "originGalaxy": "Vénus Impériale"
        },
        {
          "name": "Kiara Nova",
          "gender": "F",
          "originGalaxyId": "GAL-004",
          "originGalaxy": "Mercure Solaire"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-02"
    },
    {
      "division": "Ligue A",
      "name": "Phénix Cosmique",
      "damistes": [
        {
          "name": "Ethan Kepler",
          "gender": "M",
          "originGalaxyId": "GAL-005",
          "originGalaxy": "Jupiter Majeure"
        },
        {
          "name": "Sofia Kepler",
          "gender": "F",
          "originGalaxyId": "GAL-006",
          "originGalaxy": "Saturne des Anneaux"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-03"
    },
    {
      "division": "Ligue A",
      "name": "Soleil Noir",
      "damistes": [
        {
          "name": "Nohan Crabel",
          "gender": "M",
          "originGalaxyId": "GAL-007",
          "originGalaxy": "Neptune Abyssale"
        },
        {
          "name": "Yasmir Nébula",
          "gender": "F",
          "originGalaxyId": "GAL-008",
          "originGalaxy": "Uranus Glaciale"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-04"
    },
    {
      "division": "Ligue A",
      "name": "Vortex Quantique",
      "damistes": [
        {
          "name": "Lior Cassian",
          "gender": "M",
          "originGalaxyId": "GAL-009",
          "originGalaxy": "Pluton Lointaine"
        },
        {
          "name": "Mélina Cassior",
          "gender": "F",
          "originGalaxyId": "GAL-010",
          "originGalaxy": "Lune Argentée"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-05"
    },
    {
      "division": "Ligue A",
      "name": "Mirage Stellaire",
      "damistes": [
        {
          "name": "Ayden Pégas",
          "gender": "M",
          "originGalaxyId": "GAL-011",
          "originGalaxy": "Andromède Unie"
        },
        {
          "name": "Naomie Célestie",
          "gender": "F",
          "originGalaxyId": "GAL-012",
          "originGalaxy": "Orion Suprême"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-06"
    },
    {
      "division": "Ligue A",
      "name": "Atlas Orbital",
      "damistes": [
        {
          "name": "Kévin Centor",
          "gender": "M",
          "originGalaxyId": "GAL-013",
          "originGalaxy": "Sirius Doré"
        },
        {
          "name": "Amina Alphéa",
          "gender": "F",
          "originGalaxyId": "GAL-014",
          "originGalaxy": "Proxima Libre"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-07"
    },
    {
      "division": "Ligue A",
      "name": "Saphir Galactique",
      "damistes": [
        {
          "name": "Rayan Lyros",
          "gender": "M",
          "originGalaxyId": "GAL-015",
          "originGalaxy": "Kepler Républicaine"
        },
        {
          "name": "Élora Harmo",
          "gender": "F",
          "originGalaxyId": "GAL-016",
          "originGalaxy": "Nébuleuse du Crabe"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-08"
    },
    {
      "division": "Ligue A",
      "name": "Lions du Zénith",
      "damistes": [
        {
          "name": "Samir Vegar",
          "gender": "M",
          "originGalaxyId": "GAL-017",
          "originGalaxy": "Cassiopée Royale"
        },
        {
          "name": "Maya Éternel",
          "gender": "F",
          "originGalaxyId": "GAL-018",
          "originGalaxy": "Pégase Céleste"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-09"
    },
    {
      "division": "Ligue A",
      "name": "Zénith Lunaire",
      "damistes": [
        {
          "name": "Amine Solarys",
          "gender": "M",
          "originGalaxyId": "GAL-019",
          "originGalaxy": "Centaure Alpha"
        },
        {
          "name": "Dalia Solaria",
          "gender": "F",
          "originGalaxyId": "GAL-020",
          "originGalaxy": "Lyra Harmonieuse"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-10"
    },
    {
      "division": "Ligue A",
      "name": "Comètes Écarlates",
      "damistes": [
        {
          "name": "Nizar Écliptor",
          "gender": "M",
          "originGalaxyId": "GAL-021",
          "originGalaxy": "Vega Éternelle"
        },
        {
          "name": "Soraya Nyx",
          "gender": "F",
          "originGalaxyId": "GAL-022",
          "originGalaxy": "Solarys Impériale"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-11"
    },
    {
      "division": "Ligue A",
      "name": "Orbite Infinie",
      "damistes": [
        {
          "name": "Kaïs Astran",
          "gender": "M",
          "originGalaxyId": "GAL-023",
          "originGalaxy": "Éclipse Noire"
        },
        {
          "name": "Lilia Novara",
          "gender": "F",
          "originGalaxyId": "GAL-024",
          "originGalaxy": "Astra Nova"
        }
      ],
      "divisionId": "ligue-a",
      "id": "ligue-a-12"
    },
    {
      "division": "Ligue B",
      "name": "Astéroïdes Sauvages",
      "damistes": [
        {
          "name": "Ilyes Terran",
          "gender": "M",
          "originGalaxyId": "GAL-001",
          "originGalaxy": "Terra Unie"
        },
        {
          "name": "Mariam Terrana",
          "gender": "F",
          "originGalaxyId": "GAL-002",
          "originGalaxy": "Mars Fédérale"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-01"
    },
    {
      "division": "Ligue B",
      "name": "Pionniers du Cosmos",
      "damistes": [
        {
          "name": "Yacine Martel",
          "gender": "M",
          "originGalaxyId": "GAL-003",
          "originGalaxy": "Vénus Impériale"
        },
        {
          "name": "Safia Rougéa",
          "gender": "F",
          "originGalaxyId": "GAL-004",
          "originGalaxy": "Mercure Solaire"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-02"
    },
    {
      "division": "Ligue B",
      "name": "Étoiles Filantes",
      "damistes": [
        {
          "name": "Noam Vénéris",
          "gender": "M",
          "originGalaxyId": "GAL-005",
          "originGalaxy": "Jupiter Majeure"
        },
        {
          "name": "Lina Vénora",
          "gender": "F",
          "originGalaxyId": "GAL-006",
          "originGalaxy": "Saturne des Anneaux"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-03"
    },
    {
      "division": "Ligue B",
      "name": "Pégase Argenté",
      "damistes": [
        {
          "name": "Yanis Mercure",
          "gender": "M",
          "originGalaxyId": "GAL-007",
          "originGalaxy": "Neptune Abyssale"
        },
        {
          "name": "Élodie Mercul",
          "gender": "F",
          "originGalaxyId": "GAL-008",
          "originGalaxy": "Uranus Glaciale"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-04"
    },
    {
      "division": "Ligue B",
      "name": "Satellites Vagabonds",
      "damistes": [
        {
          "name": "Ismaël Jupitor",
          "gender": "M",
          "originGalaxyId": "GAL-009",
          "originGalaxy": "Pluton Lointaine"
        },
        {
          "name": "Naya Jovelle",
          "gender": "F",
          "originGalaxyId": "GAL-010",
          "originGalaxy": "Lune Argentée"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-05"
    },
    {
      "division": "Ligue B",
      "name": "Aurores Spectrales",
      "damistes": [
        {
          "name": "Adam Saturnel",
          "gender": "M",
          "originGalaxyId": "GAL-011",
          "originGalaxy": "Andromède Unie"
        },
        {
          "name": "Soraya Saturni",
          "gender": "F",
          "originGalaxyId": "GAL-012",
          "originGalaxy": "Orion Suprême"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-06"
    },
    {
      "division": "Ligue B",
      "name": "Centaures Célestes",
      "damistes": [
        {
          "name": "Karim Neptor",
          "gender": "M",
          "originGalaxyId": "GAL-013",
          "originGalaxy": "Sirius Doré"
        },
        {
          "name": "Inès Abyssia",
          "gender": "F",
          "originGalaxyId": "GAL-014",
          "originGalaxy": "Proxima Libre"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-07"
    },
    {
      "division": "Ligue B",
      "name": "Mistral Solaire",
      "damistes": [
        {
          "name": "Moussa Uranis",
          "gender": "M",
          "originGalaxyId": "GAL-015",
          "originGalaxy": "Kepler Républicaine"
        },
        {
          "name": "Aïssaté Glaciel",
          "gender": "F",
          "originGalaxyId": "GAL-016",
          "originGalaxy": "Nébuleuse du Crabe"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-08"
    },
    {
      "division": "Ligue B",
      "name": "Pléiades Dorées",
      "damistes": [
        {
          "name": "Gabriel Pluton",
          "gender": "M",
          "originGalaxyId": "GAL-017",
          "originGalaxy": "Cassiopée Royale"
        },
        {
          "name": "Nora Plutéa",
          "gender": "F",
          "originGalaxyId": "GAL-018",
          "originGalaxy": "Pégase Céleste"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-09"
    },
    {
      "division": "Ligue B",
      "name": "Légion d'Andromède",
      "damistes": [
        {
          "name": "Ismaël Lunaris",
          "gender": "M",
          "originGalaxyId": "GAL-019",
          "originGalaxy": "Centaure Alpha"
        },
        {
          "name": "Hawa Lunaria",
          "gender": "F",
          "originGalaxyId": "GAL-020",
          "originGalaxy": "Lyra Harmonieuse"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-10"
    },
    {
      "division": "Ligue B",
      "name": "Météorites Ardentes",
      "damistes": [
        {
          "name": "Sofiane Andromar",
          "gender": "M",
          "originGalaxyId": "GAL-021",
          "originGalaxy": "Vega Éternelle"
        },
        {
          "name": "Amina Andror",
          "gender": "F",
          "originGalaxyId": "GAL-022",
          "originGalaxy": "Solarys Impériale"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-11"
    },
    {
      "division": "Ligue B",
      "name": "Constellation Zéro",
      "damistes": [
        {
          "name": "Nabil Orionis",
          "gender": "M",
          "originGalaxyId": "GAL-023",
          "originGalaxy": "Éclipse Noire"
        },
        {
          "name": "Leïla Oriona",
          "gender": "F",
          "originGalaxyId": "GAL-024",
          "originGalaxy": "Astra Nova"
        }
      ],
      "divisionId": "ligue-b",
      "id": "ligue-b-12"
    },
    {
      "division": "Ligue C",
      "name": "Dragons de Véga",
      "damistes": [
        {
          "name": "Ilyan Végan",
          "gender": "M",
          "originGalaxyId": "GAL-001",
          "originGalaxy": "Terra Unie"
        },
        {
          "name": "Naïma Véga",
          "gender": "F",
          "originGalaxyId": "GAL-002",
          "originGalaxy": "Mars Fédérale"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-01"
    },
    {
      "division": "Ligue C",
      "name": "Royal Cosmos",
      "damistes": [
        {
          "name": "Amadou Cosmar",
          "gender": "M",
          "originGalaxyId": "GAL-003",
          "originGalaxy": "Vénus Impériale"
        },
        {
          "name": "Élise Cosmai",
          "gender": "F",
          "originGalaxyId": "GAL-004",
          "originGalaxy": "Mercure Solaire"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-02"
    },
    {
      "division": "Ligue C",
      "name": "Aigles d'Andromède",
      "damistes": [
        {
          "name": "Nassim Andros",
          "gender": "M",
          "originGalaxyId": "GAL-005",
          "originGalaxy": "Jupiter Majeure"
        },
        {
          "name": "Meryel Andria",
          "gender": "F",
          "originGalaxyId": "GAL-006",
          "originGalaxy": "Saturne des Anneaux"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-03"
    },
    {
      "division": "Ligue C",
      "name": "Phoenix Stellaire",
      "damistes": [
        {
          "name": "Yohan Phénix",
          "gender": "M",
          "originGalaxyId": "GAL-007",
          "originGalaxy": "Neptune Abyssale"
        },
        {
          "name": "Aïcha Phénici",
          "gender": "F",
          "originGalaxyId": "GAL-008",
          "originGalaxy": "Uranus Glaciale"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-04"
    },
    {
      "division": "Ligue C",
      "name": "Guerriers de Mars",
      "damistes": [
        {
          "name": "Ismaël Martian",
          "gender": "M",
          "originGalaxyId": "GAL-009",
          "originGalaxy": "Pluton Lointaine"
        },
        {
          "name": "Soraya Martia",
          "gender": "F",
          "originGalaxyId": "GAL-010",
          "originGalaxy": "Lune Argentée"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-05"
    },
    {
      "division": "Ligue C",
      "name": "Étoiles de Proxima",
      "damistes": [
        {
          "name": "Rayan Proximus",
          "gender": "M",
          "originGalaxyId": "GAL-011",
          "originGalaxy": "Andromède Unie"
        },
        {
          "name": "Lina Proxim",
          "gender": "F",
          "originGalaxyId": "GAL-012",
          "originGalaxy": "Orion Suprême"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-06"
    },
    {
      "division": "Ligue C",
      "name": "Dynastie de Jupiter",
      "damistes": [
        {
          "name": "Kévin Jovaris",
          "gender": "M",
          "originGalaxyId": "GAL-013",
          "originGalaxy": "Sirius Doré"
        },
        {
          "name": "Amira Jovelle",
          "gender": "F",
          "originGalaxyId": "GAL-014",
          "originGalaxy": "Proxima Libre"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-07"
    },
    {
      "division": "Ligue C",
      "name": "Faucons de Sirius",
      "damistes": [
        {
          "name": "Zakaria Sirian",
          "gender": "M",
          "originGalaxyId": "GAL-015",
          "originGalaxy": "Kepler Républicaine"
        },
        {
          "name": "Maya Sirielle",
          "gender": "F",
          "originGalaxyId": "GAL-016",
          "originGalaxy": "Nébuleuse du Crabe"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-08"
    },
    {
      "division": "Ligue C",
      "name": "Empereurs de Saturne",
      "damistes": [
        {
          "name": "Nassor Saturnis",
          "gender": "M",
          "originGalaxyId": "GAL-017",
          "originGalaxy": "Cassiopée Royale"
        },
        {
          "name": "Dalia Saturne",
          "gender": "F",
          "originGalaxyId": "GAL-018",
          "originGalaxy": "Pégase Céleste"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-09"
    },
    {
      "division": "Ligue C",
      "name": "Aurores de Neptune",
      "damistes": [
        {
          "name": "Bilal Neptor",
          "gender": "M",
          "originGalaxyId": "GAL-019",
          "originGalaxy": "Centaure Alpha"
        },
        {
          "name": "Inaya Neptun",
          "gender": "F",
          "originGalaxyId": "GAL-020",
          "originGalaxy": "Lyra Harmonieuse"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-10"
    },
    {
      "division": "Ligue C",
      "name": "Tigres de Kepler",
      "damistes": [
        {
          "name": "Sékou Keplar",
          "gender": "M",
          "originGalaxyId": "GAL-021",
          "originGalaxy": "Vega Éternelle"
        },
        {
          "name": "Mariam Kepler",
          "gender": "F",
          "originGalaxyId": "GAL-022",
          "originGalaxy": "Solarys Impériale"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-11"
    },
    {
      "division": "Ligue C",
      "name": "Légendes d'Astra",
      "damistes": [
        {
          "name": "Naël Astrion",
          "gender": "M",
          "originGalaxyId": "GAL-023",
          "originGalaxy": "Éclipse Noire"
        },
        {
          "name": "Yasmir Astréa",
          "gender": "F",
          "originGalaxyId": "GAL-024",
          "originGalaxy": "Astra Nova"
        }
      ],
      "divisionId": "ligue-c",
      "id": "ligue-c-12"
    },
    {
      "division": "Ligue D",
      "name": "Comètes de Terra",
      "damistes": [
        {
          "name": "Oumar Terran",
          "gender": "M",
          "originGalaxyId": "GAL-001",
          "originGalaxy": "Terra Unie"
        },
        {
          "name": "Aïssaté Terria",
          "gender": "F",
          "originGalaxyId": "GAL-002",
          "originGalaxy": "Mars Fédérale"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-01"
    },
    {
      "division": "Ligue D",
      "name": "Éclairs de Mercure",
      "damistes": [
        {
          "name": "Kader Mercur",
          "gender": "M",
          "originGalaxyId": "GAL-003",
          "originGalaxy": "Vénus Impériale"
        },
        {
          "name": "Noura Mercul",
          "gender": "F",
          "originGalaxyId": "GAL-004",
          "originGalaxy": "Mercure Solaire"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-02"
    },
    {
      "division": "Ligue D",
      "name": "Lions de Pluton",
      "damistes": [
        {
          "name": "Ibrahim Plutar",
          "gender": "M",
          "originGalaxyId": "GAL-005",
          "originGalaxy": "Jupiter Majeure"
        },
        {
          "name": "Salma Plutoni",
          "gender": "F",
          "originGalaxyId": "GAL-006",
          "originGalaxy": "Saturne des Anneaux"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-03"
    },
    {
      "division": "Ligue D",
      "name": "Panthères de la Lune",
      "damistes": [
        {
          "name": "Youssouf Lunaris",
          "gender": "M",
          "originGalaxyId": "GAL-007",
          "originGalaxy": "Neptune Abyssale"
        },
        {
          "name": "Fatou Lunéa",
          "gender": "F",
          "originGalaxyId": "GAL-008",
          "originGalaxy": "Uranus Glaciale"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-04"
    },
    {
      "division": "Ligue D",
      "name": "Cavaliers de Pégase",
      "damistes": [
        {
          "name": "Mathis Pégason",
          "gender": "M",
          "originGalaxyId": "GAL-009",
          "originGalaxy": "Pluton Lointaine"
        },
        {
          "name": "Alia Pégasi",
          "gender": "F",
          "originGalaxyId": "GAL-010",
          "originGalaxy": "Lune Argentée"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-05"
    },
    {
      "division": "Ligue D",
      "name": "Sentinelles d'Uranus",
      "damistes": [
        {
          "name": "Souleymane Uranis",
          "gender": "M",
          "originGalaxyId": "GAL-011",
          "originGalaxy": "Andromède Unie"
        },
        {
          "name": "Nawal Urania",
          "gender": "F",
          "originGalaxyId": "GAL-012",
          "originGalaxy": "Orion Suprême"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-06"
    },
    {
      "division": "Ligue D",
      "name": "Titans de Cassiopée",
      "damistes": [
        {
          "name": "Ismaël Cassian",
          "gender": "M",
          "originGalaxyId": "GAL-013",
          "originGalaxy": "Sirius Doré"
        },
        {
          "name": "Amina Cassior",
          "gender": "F",
          "originGalaxyId": "GAL-014",
          "originGalaxy": "Proxima Libre"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-07"
    },
    {
      "division": "Ligue D",
      "name": "Étoiles de Lyra",
      "damistes": [
        {
          "name": "David Lyron",
          "gender": "M",
          "originGalaxyId": "GAL-015",
          "originGalaxy": "Kepler Républicaine"
        },
        {
          "name": "Safia Lyriane",
          "gender": "F",
          "originGalaxyId": "GAL-016",
          "originGalaxy": "Nébuleuse du Crabe"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-08"
    },
    {
      "division": "Ligue D",
      "name": "Foudre de Solarys",
      "damistes": [
        {
          "name": "Karim Solarys",
          "gender": "M",
          "originGalaxyId": "GAL-017",
          "originGalaxy": "Cassiopée Royale"
        },
        {
          "name": "Inès Solaria",
          "gender": "F",
          "originGalaxyId": "GAL-018",
          "originGalaxy": "Pégase Céleste"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-09"
    },
    {
      "division": "Ligue D",
      "name": "Orbital Sporting",
      "damistes": [
        {
          "name": "Moussa Orbital",
          "gender": "M",
          "originGalaxyId": "GAL-019",
          "originGalaxy": "Centaure Alpha"
        },
        {
          "name": "Hélène Orbita",
          "gender": "F",
          "originGalaxyId": "GAL-020",
          "originGalaxy": "Lyra Harmonieuse"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-10"
    },
    {
      "division": "Ligue D",
      "name": "Conquérants de l'Éclipse",
      "damistes": [
        {
          "name": "Yanis Écliptor",
          "gender": "M",
          "originGalaxyId": "GAL-021",
          "originGalaxy": "Vega Éternelle"
        },
        {
          "name": "Rokia Éclipsi",
          "gender": "F",
          "originGalaxyId": "GAL-022",
          "originGalaxy": "Solarys Impériale"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-11"
    },
    {
      "division": "Ligue D",
      "name": "Nova Galactic",
      "damistes": [
        {
          "name": "Idriss Novar",
          "gender": "M",
          "originGalaxyId": "GAL-023",
          "originGalaxy": "Éclipse Noire"
        },
        {
          "name": "Mariam Novari",
          "gender": "F",
          "originGalaxyId": "GAL-024",
          "originGalaxy": "Astra Nova"
        }
      ],
      "divisionId": "ligue-d",
      "id": "ligue-d-12"
    }
  ],
  "clubManagers": [
    {
      "id": "MGR-C001",
      "clubId": "super-league-01",
      "club": "Cosmos United",
      "divisionId": "super-league",
      "name": "Xorvanys Khaël",
      "originGalaxyId": "GAL-001",
      "originGalaxy": "Terra Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Cosmos United"
    },
    {
      "id": "MGR-C002",
      "clubId": "super-league-02",
      "club": "Royal Dames FC",
      "divisionId": "super-league",
      "name": "Aelythra Vorn",
      "originGalaxyId": "GAL-003",
      "originGalaxy": "Vénus Impériale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Royal Dames FC"
    },
    {
      "id": "MGR-C003",
      "clubId": "super-league-03",
      "club": "Galactic Titans",
      "divisionId": "super-league",
      "name": "Dravéxor Keln",
      "originGalaxyId": "GAL-005",
      "originGalaxy": "Jupiter Majeure",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Galactic Titans"
    },
    {
      "id": "MGR-C004",
      "clubId": "super-league-04",
      "club": "Étoile Noire",
      "divisionId": "super-league",
      "name": "Nyxolar Thal",
      "originGalaxyId": "GAL-007",
      "originGalaxy": "Neptune Abyssale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Étoile Noire"
    },
    {
      "id": "MGR-C005",
      "clubId": "super-league-05",
      "club": "Dream Team",
      "divisionId": "super-league",
      "name": "Qavéryn Sol",
      "originGalaxyId": "GAL-009",
      "originGalaxy": "Pluton Lointaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Dream Team"
    },
    {
      "id": "MGR-C006",
      "clubId": "super-league-06",
      "club": "FC Galaxy Stars",
      "divisionId": "super-league",
      "name": "Voryndel Keth",
      "originGalaxyId": "GAL-011",
      "originGalaxy": "Andromède Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "FC Galaxy Stars"
    },
    {
      "id": "MGR-C007",
      "clubId": "super-league-07",
      "club": "Nova Prime",
      "divisionId": "super-league",
      "name": "Zélyrax Dhel",
      "originGalaxyId": "GAL-013",
      "originGalaxy": "Sirius Doré",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Nova Prime"
    },
    {
      "id": "MGR-C008",
      "clubId": "super-league-08",
      "club": "Orion Stellaris",
      "divisionId": "super-league",
      "name": "Thaxérian Vaal",
      "originGalaxyId": "GAL-015",
      "originGalaxy": "Kepler Républicaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Orion Stellaris"
    },
    {
      "id": "MGR-C009",
      "clubId": "super-league-09",
      "club": "Comètes Solaires",
      "divisionId": "super-league",
      "name": "Krythéa Nox",
      "originGalaxyId": "GAL-017",
      "originGalaxy": "Cassiopée Royale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Comètes Solaires"
    },
    {
      "id": "MGR-C010",
      "clubId": "super-league-10",
      "club": "Astres Vagabonds",
      "divisionId": "super-league",
      "name": "Oryxen Vorn",
      "originGalaxyId": "GAL-019",
      "originGalaxy": "Centaure Alpha",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Astres Vagabonds"
    },
    {
      "id": "MGR-C011",
      "clubId": "super-league-11",
      "club": "Pulsar Impérial",
      "divisionId": "super-league",
      "name": "Xélydran Korl",
      "originGalaxyId": "GAL-021",
      "originGalaxy": "Vega Éternelle",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Pulsar Impérial"
    },
    {
      "id": "MGR-C012",
      "clubId": "super-league-12",
      "club": "Aurore Cosmique",
      "divisionId": "super-league",
      "name": "Vaxéthra Qen",
      "originGalaxyId": "GAL-023",
      "originGalaxy": "Éclipse Noire",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Aurore Cosmique"
    },
    {
      "id": "MGR-C013",
      "clubId": "ligue-a-01",
      "club": "Titans Stellaires",
      "divisionId": "ligue-a",
      "name": "Qorvexan Thyr",
      "originGalaxyId": "GAL-001",
      "originGalaxy": "Terra Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Titans Stellaires"
    },
    {
      "id": "MGR-C014",
      "clubId": "ligue-a-02",
      "club": "Éclipse Rouge",
      "divisionId": "ligue-a",
      "name": "Nyzérian Kald",
      "originGalaxyId": "GAL-003",
      "originGalaxy": "Vénus Impériale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Éclipse Rouge"
    },
    {
      "id": "MGR-C015",
      "clubId": "ligue-a-03",
      "club": "Phénix Cosmique",
      "divisionId": "ligue-a",
      "name": "Axyvoryn Zeth",
      "originGalaxyId": "GAL-005",
      "originGalaxy": "Jupiter Majeure",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Phénix Cosmique"
    },
    {
      "id": "MGR-C016",
      "clubId": "ligue-a-04",
      "club": "Soleil Noir",
      "divisionId": "ligue-a",
      "name": "Thoryxal Venn",
      "originGalaxyId": "GAL-007",
      "originGalaxy": "Neptune Abyssale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Soleil Noir"
    },
    {
      "id": "MGR-C017",
      "clubId": "ligue-a-05",
      "club": "Vortex Quantique",
      "divisionId": "ligue-a",
      "name": "Zorélyx Kha",
      "originGalaxyId": "GAL-009",
      "originGalaxy": "Pluton Lointaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Vortex Quantique"
    },
    {
      "id": "MGR-C018",
      "clubId": "ligue-a-06",
      "club": "Mirage Stellaire",
      "divisionId": "ligue-a",
      "name": "Vélyssia Drax",
      "originGalaxyId": "GAL-011",
      "originGalaxy": "Andromède Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Mirage Stellaire"
    },
    {
      "id": "MGR-C019",
      "clubId": "ligue-a-07",
      "club": "Atlas Orbital",
      "divisionId": "ligue-a",
      "name": "Kryndor Vaas",
      "originGalaxyId": "GAL-013",
      "originGalaxy": "Sirius Doré",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Atlas Orbital"
    },
    {
      "id": "MGR-C020",
      "clubId": "ligue-a-08",
      "club": "Saphir Galactique",
      "divisionId": "ligue-a",
      "name": "Xavorya Neld",
      "originGalaxyId": "GAL-015",
      "originGalaxy": "Kepler Républicaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Saphir Galactique"
    },
    {
      "id": "MGR-C021",
      "clubId": "ligue-a-09",
      "club": "Lions du Zénith",
      "divisionId": "ligue-a",
      "name": "Draxélyn Oryn",
      "originGalaxyId": "GAL-017",
      "originGalaxy": "Cassiopée Royale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Lions du Zénith"
    },
    {
      "id": "MGR-C022",
      "clubId": "ligue-a-10",
      "club": "Zénith Lunaire",
      "divisionId": "ligue-a",
      "name": "Qélyvorn Thal",
      "originGalaxyId": "GAL-019",
      "originGalaxy": "Centaure Alpha",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Zénith Lunaire"
    },
    {
      "id": "MGR-C023",
      "clubId": "ligue-a-11",
      "club": "Comètes Écarlates",
      "divisionId": "ligue-a",
      "name": "Ozyndra Keth",
      "originGalaxyId": "GAL-021",
      "originGalaxy": "Vega Éternelle",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Comètes Écarlates"
    },
    {
      "id": "MGR-C024",
      "clubId": "ligue-a-12",
      "club": "Orbite Infinie",
      "divisionId": "ligue-a",
      "name": "Vaxoryn Seln",
      "originGalaxyId": "GAL-023",
      "originGalaxy": "Éclipse Noire",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Orbite Infinie"
    },
    {
      "id": "MGR-C025",
      "clubId": "ligue-b-01",
      "club": "Astéroïdes Sauvages",
      "divisionId": "ligue-b",
      "name": "Thaloryx Venn",
      "originGalaxyId": "GAL-001",
      "originGalaxy": "Terra Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Astéroïdes Sauvages"
    },
    {
      "id": "MGR-C026",
      "clubId": "ligue-b-02",
      "club": "Pionniers du Cosmos",
      "divisionId": "ligue-b",
      "name": "Zynévon Kha",
      "originGalaxyId": "GAL-003",
      "originGalaxy": "Vénus Impériale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Pionniers du Cosmos"
    },
    {
      "id": "MGR-C027",
      "clubId": "ligue-b-03",
      "club": "Étoiles Filantes",
      "divisionId": "ligue-b",
      "name": "Aeloryn Drax",
      "originGalaxyId": "GAL-005",
      "originGalaxy": "Jupiter Majeure",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Étoiles Filantes"
    },
    {
      "id": "MGR-C028",
      "clubId": "ligue-b-04",
      "club": "Pégase Argenté",
      "divisionId": "ligue-b",
      "name": "Xorathyn Keld",
      "originGalaxyId": "GAL-007",
      "originGalaxy": "Neptune Abyssale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Pégase Argenté"
    },
    {
      "id": "MGR-C029",
      "clubId": "ligue-b-05",
      "club": "Satellites Vagabonds",
      "divisionId": "ligue-b",
      "name": "Qavorya Threx",
      "originGalaxyId": "GAL-009",
      "originGalaxy": "Pluton Lointaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Satellites Vagabonds"
    },
    {
      "id": "MGR-C030",
      "clubId": "ligue-b-06",
      "club": "Aurores Spectrales",
      "divisionId": "ligue-b",
      "name": "Nyxélyn Vaal",
      "originGalaxyId": "GAL-011",
      "originGalaxy": "Andromède Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Aurores Spectrales"
    },
    {
      "id": "MGR-C031",
      "clubId": "ligue-b-07",
      "club": "Centaures Célestes",
      "divisionId": "ligue-b",
      "name": "Voryxal Korl",
      "originGalaxyId": "GAL-013",
      "originGalaxy": "Sirius Doré",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Centaures Célestes"
    },
    {
      "id": "MGR-C032",
      "clubId": "ligue-b-08",
      "club": "Mistral Solaire",
      "divisionId": "ligue-b",
      "name": "Dravoryn Zeth",
      "originGalaxyId": "GAL-015",
      "originGalaxy": "Kepler Républicaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Mistral Solaire"
    },
    {
      "id": "MGR-C033",
      "clubId": "ligue-b-09",
      "club": "Pléiades Dorées",
      "divisionId": "ligue-b",
      "name": "Kryssorya Vorn",
      "originGalaxyId": "GAL-017",
      "originGalaxy": "Cassiopée Royale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Pléiades Dorées"
    },
    {
      "id": "MGR-C034",
      "clubId": "ligue-b-10",
      "club": "Légion d'Andromède",
      "divisionId": "ligue-b",
      "name": "Xélyvex Thenn",
      "originGalaxyId": "GAL-019",
      "originGalaxy": "Centaure Alpha",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Légion d'Andromède"
    },
    {
      "id": "MGR-C035",
      "clubId": "ligue-b-11",
      "club": "Météorites Ardentes",
      "divisionId": "ligue-b",
      "name": "Qoréthyn Kald",
      "originGalaxyId": "GAL-021",
      "originGalaxy": "Vega Éternelle",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Météorites Ardentes"
    },
    {
      "id": "MGR-C036",
      "clubId": "ligue-b-12",
      "club": "Constellation Zéro",
      "divisionId": "ligue-b",
      "name": "Zalthoryn Dhel",
      "originGalaxyId": "GAL-023",
      "originGalaxy": "Éclipse Noire",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Constellation Zéro"
    },
    {
      "id": "MGR-C037",
      "clubId": "ligue-c-01",
      "club": "Dragons de Véga",
      "divisionId": "ligue-c",
      "name": "Vexalyn Kha",
      "originGalaxyId": "GAL-001",
      "originGalaxy": "Terra Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Xénorath Dynamo"
    },
    {
      "id": "MGR-C038",
      "clubId": "ligue-c-02",
      "club": "Royal Cosmos",
      "divisionId": "ligue-c",
      "name": "Orythéon Vaas",
      "originGalaxyId": "GAL-003",
      "originGalaxy": "Vénus Impériale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Krysalith Orbital"
    },
    {
      "id": "MGR-C039",
      "clubId": "ligue-c-03",
      "club": "Aigles d'Andromède",
      "divisionId": "ligue-c",
      "name": "Xandorya Keth",
      "originGalaxyId": "GAL-005",
      "originGalaxy": "Jupiter Majeure",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Valtoryx Prime"
    },
    {
      "id": "MGR-C040",
      "clubId": "ligue-c-04",
      "club": "Phoenix Stellaire",
      "divisionId": "ligue-c",
      "name": "Nyvalex Thyr",
      "originGalaxyId": "GAL-007",
      "originGalaxy": "Neptune Abyssale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Zéphyrion Nexus"
    },
    {
      "id": "MGR-C041",
      "clubId": "ligue-c-05",
      "club": "Guerriers de Mars",
      "divisionId": "ligue-c",
      "name": "Qorvélia Nox",
      "originGalaxyId": "GAL-009",
      "originGalaxy": "Pluton Lointaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Astralyth Forge"
    },
    {
      "id": "MGR-C042",
      "clubId": "ligue-c-06",
      "club": "Étoiles de Proxima",
      "divisionId": "ligue-c",
      "name": "Drakoryn Sorn",
      "originGalaxyId": "GAL-011",
      "originGalaxy": "Andromède Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Nébulyx Vanguard"
    },
    {
      "id": "MGR-C043",
      "clubId": "ligue-c-07",
      "club": "Dynastie de Jupiter",
      "divisionId": "ligue-c",
      "name": "Axythéon Venn",
      "originGalaxyId": "GAL-013",
      "originGalaxy": "Sirius Doré",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Khaoryn Stellar"
    },
    {
      "id": "MGR-C044",
      "clubId": "ligue-c-08",
      "club": "Faucons de Sirius",
      "divisionId": "ligue-c",
      "name": "Zynoryx Kald",
      "originGalaxyId": "GAL-015",
      "originGalaxy": "Kepler Républicaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Dravexion Pulse"
    },
    {
      "id": "MGR-C045",
      "clubId": "ligue-c-09",
      "club": "Empereurs de Saturne",
      "divisionId": "ligue-c",
      "name": "Thalvorya Qen",
      "originGalaxyId": "GAL-017",
      "originGalaxy": "Cassiopée Royale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Oryndrax Nova"
    },
    {
      "id": "MGR-C046",
      "clubId": "ligue-c-10",
      "club": "Aurores de Neptune",
      "divisionId": "ligue-c",
      "name": "Kryzélyn Drax",
      "originGalaxyId": "GAL-019",
      "originGalaxy": "Centaure Alpha",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Thaloryx Eclipse"
    },
    {
      "id": "MGR-C047",
      "clubId": "ligue-c-11",
      "club": "Tigres de Kepler",
      "divisionId": "ligue-c",
      "name": "Voryssan Keth",
      "originGalaxyId": "GAL-021",
      "originGalaxy": "Vega Éternelle",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Zyphora Quantum"
    },
    {
      "id": "MGR-C048",
      "clubId": "ligue-c-12",
      "club": "Légendes d'Astra",
      "divisionId": "ligue-c",
      "name": "Xélarion Thal",
      "originGalaxyId": "GAL-023",
      "originGalaxy": "Éclipse Noire",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Vorynthia Core"
    },
    {
      "id": "MGR-C049",
      "clubId": "ligue-d-01",
      "club": "Comètes de Terra",
      "divisionId": "ligue-d",
      "name": "Qylaréx Vorn",
      "originGalaxyId": "GAL-001",
      "originGalaxy": "Terra Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Xaltherion Flux"
    },
    {
      "id": "MGR-C050",
      "clubId": "ligue-d-02",
      "club": "Éclairs de Mercure",
      "divisionId": "ligue-d",
      "name": "Zorvanyx Kha",
      "originGalaxyId": "GAL-003",
      "originGalaxy": "Vénus Impériale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Kryonex Atlas"
    },
    {
      "id": "MGR-C051",
      "clubId": "ligue-d-03",
      "club": "Lions de Pluton",
      "divisionId": "ligue-d",
      "name": "Aelthoryn Dhel",
      "originGalaxyId": "GAL-005",
      "originGalaxy": "Jupiter Majeure",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Vexalyra Storm"
    },
    {
      "id": "MGR-C052",
      "clubId": "ligue-d-04",
      "club": "Panthères de la Lune",
      "divisionId": "ligue-d",
      "name": "Xyrelia Vaas",
      "originGalaxyId": "GAL-007",
      "originGalaxy": "Neptune Abyssale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Zorvanyx Orbit"
    },
    {
      "id": "MGR-C053",
      "clubId": "ligue-d-05",
      "club": "Cavaliers de Pégase",
      "divisionId": "ligue-d",
      "name": "Draxévon Keln",
      "originGalaxyId": "GAL-009",
      "originGalaxy": "Pluton Lointaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Aethoryn Blaze"
    },
    {
      "id": "MGR-C054",
      "clubId": "ligue-d-06",
      "club": "Sentinelles d'Uranus",
      "divisionId": "ligue-d",
      "name": "Qélyrax Thenn",
      "originGalaxyId": "GAL-011",
      "originGalaxy": "Andromède Unie",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Nyxalith Comet"
    },
    {
      "id": "MGR-C055",
      "clubId": "ligue-d-07",
      "club": "Titans de Cassiopée",
      "divisionId": "ligue-d",
      "name": "Vaxélyn Sorn",
      "originGalaxyId": "GAL-013",
      "originGalaxy": "Sirius Doré",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Qorvexis Titan"
    },
    {
      "id": "MGR-C056",
      "clubId": "ligue-d-08",
      "club": "Étoiles de Lyra",
      "divisionId": "ligue-d",
      "name": "Nyxoryn Keth",
      "originGalaxyId": "GAL-015",
      "originGalaxy": "Kepler Républicaine",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Sylthoryx Wave"
    },
    {
      "id": "MGR-C057",
      "clubId": "ligue-d-09",
      "club": "Foudre de Solarys",
      "divisionId": "ligue-d",
      "name": "Kryvalia Nox",
      "originGalaxyId": "GAL-017",
      "originGalaxy": "Cassiopée Royale",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Ozymetra Void"
    },
    {
      "id": "MGR-C058",
      "clubId": "ligue-d-10",
      "club": "Orbital Sporting",
      "divisionId": "ligue-d",
      "name": "Thoryvex Kald",
      "originGalaxyId": "GAL-019",
      "originGalaxy": "Centaure Alpha",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Draxelyon Star"
    },
    {
      "id": "MGR-C059",
      "clubId": "ligue-d-11",
      "club": "Conquérants de l'Éclipse",
      "divisionId": "ligue-d",
      "name": "Xavérian Zeth",
      "originGalaxyId": "GAL-021",
      "originGalaxy": "Vega Éternelle",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Velhoryn Sphere"
    },
    {
      "id": "MGR-C060",
      "clubId": "ligue-d-12",
      "club": "Nova Galactic",
      "divisionId": "ligue-d",
      "name": "Oryndrax Venn",
      "originGalaxyId": "GAL-023",
      "originGalaxy": "Éclipse Noire",
      "originAssignment": "origine attribuée selon l'origine du premier damiste du club ; non précisée dans la source",
      "sourceClubName": "Xyrathis Zenith"
    }
  ],
  "selectionManagers": [
    {
      "id": "MGR-S001",
      "selection": "Terra Unie",
      "name": "Vaeloryn Kess",
      "originGalaxyId": "GAL-001",
      "originGalaxy": "Terra Unie"
    },
    {
      "id": "MGR-S002",
      "selection": "Mars Fédérale",
      "name": "Xandérix Vorn",
      "originGalaxyId": "GAL-002",
      "originGalaxy": "Mars Fédérale"
    },
    {
      "id": "MGR-S003",
      "selection": "Vénus Impériale",
      "name": "Aelysora Thenn",
      "originGalaxyId": "GAL-003",
      "originGalaxy": "Vénus Impériale"
    },
    {
      "id": "MGR-S004",
      "selection": "Mercure Solaire",
      "name": "Qorvanyx Drel",
      "originGalaxyId": "GAL-004",
      "originGalaxy": "Mercure Solaire"
    },
    {
      "id": "MGR-S005",
      "selection": "Jupiter Majeure",
      "name": "Thaléon Vex",
      "originGalaxyId": "GAL-005",
      "originGalaxy": "Jupiter Majeure"
    },
    {
      "id": "MGR-S006",
      "selection": "Saturne des Anneaux",
      "name": "Zylaria Khor",
      "originGalaxyId": "GAL-006",
      "originGalaxy": "Saturne des Anneaux"
    },
    {
      "id": "MGR-S007",
      "selection": "Neptune Abyssale",
      "name": "Oryndex Vaël",
      "originGalaxyId": "GAL-007",
      "originGalaxy": "Neptune Abyssale"
    },
    {
      "id": "MGR-S008",
      "selection": "Uranus Glaciale",
      "name": "Krysséa Nox",
      "originGalaxyId": "GAL-008",
      "originGalaxy": "Uranus Glaciale"
    },
    {
      "id": "MGR-S009",
      "selection": "Pluton Lointaine",
      "name": "Vaxoryn Zeth",
      "originGalaxyId": "GAL-009",
      "originGalaxy": "Pluton Lointaine"
    },
    {
      "id": "MGR-S010",
      "selection": "Lune Argentée",
      "name": "Nytheria Kald",
      "originGalaxyId": "GAL-010",
      "originGalaxy": "Lune Argentée"
    },
    {
      "id": "MGR-S011",
      "selection": "Andromède Unie",
      "name": "Draxélyn Qor",
      "originGalaxyId": "GAL-011",
      "originGalaxy": "Andromède Unie"
    },
    {
      "id": "MGR-S012",
      "selection": "Orion Suprême",
      "name": "Xélyor Vann",
      "originGalaxyId": "GAL-012",
      "originGalaxy": "Orion Suprême"
    },
    {
      "id": "MGR-S013",
      "selection": "Sirius Doré",
      "name": "Khaédrin Sol",
      "originGalaxyId": "GAL-013",
      "originGalaxy": "Sirius Doré"
    },
    {
      "id": "MGR-S014",
      "selection": "Proxima Libre",
      "name": "Voryssan Threx",
      "originGalaxyId": "GAL-014",
      "originGalaxy": "Proxima Libre"
    },
    {
      "id": "MGR-S015",
      "selection": "Kepler Républicaine",
      "name": "Qélyndra Vaal",
      "originGalaxyId": "GAL-015",
      "originGalaxy": "Kepler Républicaine"
    },
    {
      "id": "MGR-S016",
      "selection": "Nébuleuse du Crabe",
      "name": "Zorathyn Kess",
      "originGalaxyId": "GAL-016",
      "originGalaxy": "Nébuleuse du Crabe"
    },
    {
      "id": "MGR-S017",
      "selection": "Cassiopée Royale",
      "name": "Axyrel Vorn",
      "originGalaxyId": "GAL-017",
      "originGalaxy": "Cassiopée Royale"
    },
    {
      "id": "MGR-S018",
      "selection": "Pégase Céleste",
      "name": "Thoryssia Dhel",
      "originGalaxyId": "GAL-018",
      "originGalaxy": "Pégase Céleste"
    },
    {
      "id": "MGR-S019",
      "selection": "Centaure Alpha",
      "name": "Kryovex Neld",
      "originGalaxyId": "GAL-019",
      "originGalaxy": "Centaure Alpha"
    },
    {
      "id": "MGR-S020",
      "selection": "Lyra Harmonieuse",
      "name": "Xavéthra Sorn",
      "originGalaxyId": "GAL-020",
      "originGalaxy": "Lyra Harmonieuse"
    },
    {
      "id": "MGR-S021",
      "selection": "Vega Éternelle",
      "name": "Ozyrion Kha",
      "originGalaxyId": "GAL-021",
      "originGalaxy": "Vega Éternelle"
    },
    {
      "id": "MGR-S022",
      "selection": "Solarys Impériale",
      "name": "Nyxerian Vex",
      "originGalaxyId": "GAL-022",
      "originGalaxy": "Solarys Impériale"
    },
    {
      "id": "MGR-S023",
      "selection": "Éclipse Noire",
      "name": "Qoralyth Thenn",
      "originGalaxyId": "GAL-023",
      "originGalaxy": "Éclipse Noire"
    },
    {
      "id": "MGR-S024",
      "selection": "Astra Nova",
      "name": "Vélyndor Keth",
      "originGalaxyId": "GAL-024",
      "originGalaxy": "Astra Nova"
    }
  ],
  "galaxies": [
    {
      "id": "GAL-001",
      "nom": "Terra Unie",
      "damistes_range": "DAM-0001 à DAM-0005",
      "representant_h": "Kaël Orion",
      "representant_f": "Amara Solène"
    },
    {
      "id": "GAL-002",
      "nom": "Mars Fédérale",
      "damistes_range": "DAM-0006 à DAM-0010",
      "representant_h": "Malik Ares",
      "representant_f": "Inaya Marsel"
    },
    {
      "id": "GAL-003",
      "nom": "Vénus Impériale",
      "damistes_range": "DAM-0011 à DAM-0015",
      "representant_h": "Célian Vénor",
      "representant_f": "Naïra Vénusis"
    },
    {
      "id": "GAL-004",
      "nom": "Mercure Solaire",
      "damistes_range": "DAM-0016 à DAM-0020",
      "representant_h": "Elio Mercan",
      "representant_f": "Maëlys Solara"
    },
    {
      "id": "GAL-005",
      "nom": "Jupiter Majeure",
      "damistes_range": "DAM-0021 à DAM-0025",
      "representant_h": "Darius Jovian",
      "representant_f": "Aïcha Jupiter"
    },
    {
      "id": "GAL-006",
      "nom": "Saturne des Anneaux",
      "damistes_range": "DAM-0026 à DAM-0030",
      "representant_h": "Soren Saturne",
      "representant_f": "Lyana Astréa"
    },
    {
      "id": "GAL-007",
      "nom": "Neptune Abyssale",
      "damistes_range": "DAM-0031 à DAM-0035",
      "representant_h": "Néo Abyss",
      "representant_f": "Océane Néris"
    },
    {
      "id": "GAL-008",
      "nom": "Uranus Glaciale",
      "damistes_range": "DAM-0036 à DAM-0040",
      "representant_h": "Kylian Frost",
      "representant_f": "Éina Glaciel"
    },
    {
      "id": "GAL-009",
      "nom": "Pluton Lointaine",
      "damistes_range": "DAM-0041 à DAM-0045",
      "representant_h": "Zayden Plutar",
      "representant_f": "Nyssa Plutoni"
    },
    {
      "id": "GAL-010",
      "nom": "Lune Argentée",
      "damistes_range": "DAM-0046 à DAM-0050",
      "representant_h": "Aylan Lunor",
      "representant_f": "Selma Lunéa"
    },
    {
      "id": "GAL-011",
      "nom": "Andromède Unie",
      "damistes_range": "DAM-0051 à DAM-0055",
      "representant_h": "Naël Andros",
      "representant_f": "Amaya Andror"
    },
    {
      "id": "GAL-012",
      "nom": "Orion Suprême",
      "damistes_range": "DAM-0056 à DAM-0060",
      "representant_h": "Orion Kaïros",
      "representant_f": "Sélène Orialis"
    },
    {
      "id": "GAL-013",
      "nom": "Sirius Doré",
      "damistes_range": "DAM-0061 à DAM-0065",
      "representant_h": "Idriss Sirius",
      "representant_f": "Aïna Dorélia"
    },
    {
      "id": "GAL-014",
      "nom": "Proxima Libre",
      "damistes_range": "DAM-0066 à DAM-0070",
      "representant_h": "Maël Proxim",
      "representant_f": "Kiara Nova"
    },
    {
      "id": "GAL-015",
      "nom": "Kepler Républicaine",
      "damistes_range": "DAM-0071 à DAM-0075",
      "representant_h": "Ethan Kepler",
      "representant_f": "Sofia Kepler"
    },
    {
      "id": "GAL-016",
      "nom": "Nébuleuse du Crabe",
      "damistes_range": "DAM-0076 à DAM-0080",
      "representant_h": "Nohan Crabel",
      "representant_f": "Yasmir Nébula"
    },
    {
      "id": "GAL-017",
      "nom": "Cassiopée Royale",
      "damistes_range": "DAM-0081 à DAM-0085",
      "representant_h": "Lior Cassian",
      "representant_f": "Mélina Cassior"
    },
    {
      "id": "GAL-018",
      "nom": "Pégase Céleste",
      "damistes_range": "DAM-0086 à DAM-0090",
      "representant_h": "Ayden Pégas",
      "representant_f": "Naomie Célestie"
    },
    {
      "id": "GAL-019",
      "nom": "Centaure Alpha",
      "damistes_range": "DAM-0091 à DAM-0095",
      "representant_h": "Kévin Centor",
      "representant_f": "Amina Alphéa"
    },
    {
      "id": "GAL-020",
      "nom": "Lyra Harmonieuse",
      "damistes_range": "DAM-0096 à DAM-0100",
      "representant_h": "Rayan Lyros",
      "representant_f": "Élora Harmo"
    },
    {
      "id": "GAL-021",
      "nom": "Vega Éternelle",
      "damistes_range": "DAM-0101 à DAM-0105",
      "representant_h": "Samir Vegar",
      "representant_f": "Maya Éternel"
    },
    {
      "id": "GAL-022",
      "nom": "Solarys Impériale",
      "damistes_range": "DAM-0106 à DAM-0110",
      "representant_h": "Amine Solarys",
      "representant_f": "Dalia Solaria"
    },
    {
      "id": "GAL-023",
      "nom": "Éclipse Noire",
      "damistes_range": "DAM-0111 à DAM-0115",
      "representant_h": "Nizar Écliptor",
      "representant_f": "Soraya Nyx"
    },
    {
      "id": "GAL-024",
      "nom": "Astra Nova",
      "damistes_range": "DAM-0116 à DAM-0120",
      "representant_h": "Kaïs Astran",
      "representant_f": "Lilia Novara"
    }
  ]
});
