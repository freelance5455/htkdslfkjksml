import { ensureManagementState } from './relations.js';

const integer = (value, min, max, label) => {
  const n = Number(value);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${label} invalide`);
  return n;
};
const clubsOf = state => state.divisions.flatMap(d => d.clubs);
function findPlayer(state, id) {
  for (const club of clubsOf(state)) {
    const player = (club.damistes || []).find(p => p.id === id);
    if (player) return { club, player };
  }
  return null;
}
function payroll(club) {
  return (club.damistes || []).reduce((sum, p) => sum + (p.contract?.status === 'active' ? Number(p.contract.wage || 0) : 0), 0);
}

/** Le marché CGD utilise un échange joueur contre joueur afin de préserver les deux damistes par club. */
export function proposePlayerExchange(state, { incomingPlayerId, outgoingPlayerId, fee = 0 }) {
  const management = ensureManagementState(state);
  const incoming = findPlayer(state, incomingPlayerId);
  const outgoing = findPlayer(state, outgoingPlayerId);
  if (!incoming || !outgoing) throw new Error('Damiste entrant ou sortant introuvable');
  if (incoming.club.id === state.userClubId || outgoing.club.id !== state.userClubId) throw new Error('L’offre doit échanger un damiste du club dirigé contre un damiste d’un autre club');
  if (incoming.club.id === outgoing.club.id) throw new Error('Les deux damistes doivent appartenir à des clubs différents');
  const amount = integer(fee, 0, 1_000_000_000, 'Indemnité');
  const buyer = outgoing.club, seller = incoming.club;
  if (amount > Number(buyer.budget || 0)) throw new Error('Le budget du club ne permet pas cette indemnité');
  const outgoingClause = outgoing.player.contract?.clauses || {};
  const incomingClause = incoming.player.contract?.clauses || {};
  if (outgoingClause.noTransfer && (!Number(outgoingClause.releaseClause || 0) || amount < Number(outgoingClause.releaseClause || 0))) throw new Error('Le contrat du damiste sortant interdit son transfert sans atteindre sa clause libératoire');
  if (incomingClause.noTransfer && (!Number(incomingClause.releaseClause || 0) || amount < Number(incomingClause.releaseClause || 0))) throw new Error('Le contrat du damiste ciblé interdit son transfert sans atteindre sa clause libératoire');
  const id = `exchange:${state.season}:${incomingPlayerId}:${outgoingPlayerId}:${management.transferOffers.length + 1}`;
  if (management.transferOffers.some(x => x.id === id)) throw new Error('Cette offre de transfert existe déjà');
  const levelGap = Number(outgoing.player.level || 0) - Number(incoming.player.level || 0);
  const minimumFee = Math.max(0, -levelGap) * 1000;
  const releaseClause = Number(incomingClause.releaseClause || 0);
  const accepted = (releaseClause > 0 && amount >= releaseClause) || levelGap >= 0 || amount >= minimumFee;
  const offer = {
    id, season: state.season, buyerClubId: buyer.id, sellerClubId: seller.id,
    incomingPlayerId, incomingPlayerName: incoming.player.name,
    outgoingPlayerId, outgoingPlayerName: outgoing.player.name,
    fee: amount, minimumFee, status: accepted ? 'accepted-by-selling-club' : 'rejected-by-selling-club',
    sellerReason: accepted ? 'Le club vendeur juge l’échange et l’indemnité acceptables.' : 'Le club vendeur estime la compensation insuffisante.',
    createdAt: new Date().toISOString()
  };
  management.transferOffers.unshift(offer);
  return structuredClone(offer);
}

export function completePlayerExchange(state, offerId) {
  const management = ensureManagementState(state);
  const offer = management.transferOffers.find(x => x.id === offerId);
  if (!offer) throw new Error('Offre de transfert introuvable');
  const previous = management.transferHistory.find(x => x.offerId === offerId);
  if (previous) return structuredClone(previous);
  if (offer.status !== 'accepted-by-selling-club') throw new Error('Le club vendeur n’a pas accepté les conditions');
  const incoming = findPlayer(state, offer.incomingPlayerId);
  const outgoing = findPlayer(state, offer.outgoingPlayerId);
  if (!incoming || !outgoing || incoming.club.id !== offer.sellerClubId || outgoing.club.id !== offer.buyerClubId) throw new Error('Les effectifs ont changé depuis la proposition');
  const buyer = outgoing.club, seller = incoming.club;
  if (Number(buyer.budget || 0) < offer.fee) throw new Error('Budget insuffisant au moment de finaliser le transfert');
  const incomingIndex = seller.damistes.findIndex(p => p.id === incoming.player.id);
  const outgoingIndex = buyer.damistes.findIndex(p => p.id === outgoing.player.id);
  seller.damistes[incomingIndex] = outgoing.player;
  buyer.damistes[outgoingIndex] = incoming.player;
  buyer.budget = Number(buyer.budget || 0) - offer.fee;
  seller.budget = Number(seller.budget || 0) + offer.fee;
  buyer.payrollCommitment = payroll(buyer);
  seller.payrollCommitment = payroll(seller);
  const relations = management.relations;
  relations.playerMorale[incoming.player.id] = Math.min(100, Number(relations.playerMorale[incoming.player.id] ?? 50) + 4);
  relations.playerMorale[outgoing.player.id] = Math.min(100, Number(relations.playerMorale[outgoing.player.id] ?? 50) + 2);
  relations.boardConfidence = Math.min(100, Number(relations.boardConfidence ?? 50) + 1);
  const record = {
    id: `transfer:${offer.id}`, offerId, season: state.season,
    buyerClubId: buyer.id, sellerClubId: seller.id,
    incomingPlayerId: incoming.player.id, outgoingPlayerId: outgoing.player.id,
    fee: offer.fee, completedAt: new Date().toISOString()
  };
  management.transferHistory.unshift(record);
  management.careerLog.unshift({ id: `decision:${record.id}`, type: 'player-exchange', season: state.season, clubId: buyer.id, counterpartyClubId: seller.id, incomingPlayerId: incoming.player.id, outgoingPlayerId: outgoing.player.id, impact: `Échange finalisé avec une indemnité de ${offer.fee} Gold.`, at: record.completedAt });
  offer.status = 'completed';
  offer.completedAt = record.completedAt;
  return structuredClone(record);
}

export function validateTransfers(state) {
  const m = ensureManagementState(state);
  const ids = m.transferOffers.map(x => x.id);
  if (new Set(ids).size !== ids.length) throw new Error('Offres de transfert dupliquées');
  for (const club of clubsOf(state)) if (club.damistes?.length !== 2) throw new Error(`Le club ${club.id} doit conserver exactement deux damistes`);
  for (const offer of m.transferOffers) if (!findPlayer(state, offer.incomingPlayerId) && offer.status !== 'completed') throw new Error(`Damiste ciblé absent de l’offre ${offer.id}`);
  return true;
}
