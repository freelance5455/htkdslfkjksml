#!/bin/sh
# JUHNKRIX MUSIKA AppRun Execution Script
# Sets up PulseAudio/ALSA hardware HAL and launches embedded browser runtime
HERE="$(dirname "$(readlink -f "${0}")")"
export PATH="${HERE}/usr/bin:${PATH}"
export LD_LIBRARY_PATH="${HERE}/usr/lib:${LD_LIBRARY_PATH}"
export JUHNKRIX_OFFLINE_PORT=3000
exec "${HERE}/usr/bin/juhnkrix-musika" "$@"
