import { STAGES_DATABASE } from "../data/sampleStages";
import { normalizeArabicString } from "../engine/normalization";

export interface AuditResult {
  term: string;
  isDuplicateAnswer: boolean;
  duplicateDetails: string[];
  mentionedInClues: string[];
}

export function auditWord(term: string): AuditResult {
  const normTerm = normalizeArabicString(term).replace(/[\s_\-]/g, "");
  // also without 'ال'
  const normTermNoAl = normTerm.startsWith("ال") ? normTerm.slice(2) : normTerm;

  const result: AuditResult = {
    term,
    isDuplicateAnswer: false,
    duplicateDetails: [],
    mentionedInClues: [],
  };

  for (const stage of STAGES_DATABASE) {
    for (const q of stage.questions) {
      const normAns = normalizeArabicString(q.answer).replace(/[\s_\-]/g, "");
      const normAnsNoAl = normAns.startsWith("ال") ? normAns.slice(2) : normAns;

      // Check duplicate answer (exact or root match)
      if (normAns === normTerm || (normTermNoAl.length > 3 && normAnsNoAl === normTermNoAl)) {
        result.isDuplicateAnswer = true;
        result.duplicateDetails.push(`المرحلة ${stage.id} سؤال #${q.number} [${q.direction}] الإجابة: "${q.answer}"`);
      } else if (normAns.includes(normTerm) || (normTerm.length > 4 && normTerm.includes(normAns))) {
        // partial containment
        result.duplicateDetails.push(`[تطابق جزئي] المرحلة ${stage.id} سؤال #${q.number}: "${q.answer}"`);
      }

      // Check occurrence in clues
      const normClue = normalizeArabicString(q.clue);
      if (normClue.includes(normalizeArabicString(term)) || (normTermNoAl.length > 4 && normClue.includes(normTermNoAl))) {
        result.mentionedInClues.push(`المرحلة ${stage.id} سؤال #${q.number} (${q.answer}): "${q.clue.slice(0, 60)}..."`);
      }
    }
  }

  return result;
}

// Run audit if called directly
const args = process.argv.slice(2);
if (args.length > 0) {
  for (const w of args) {
    const res = auditWord(w);
    console.log(`\n========================================`);
    console.log(`فحص الكلمة: [${res.term}]`);
    if (res.isDuplicateAnswer) {
      console.log(`❌ مكررة في الإجابات:`);
      res.duplicateDetails.forEach(d => console.log(`   - ${d}`));
    } else if (res.duplicateDetails.length > 0) {
      console.log(`⚠️ شبهة تطابق جزئي:`);
      res.duplicateDetails.forEach(d => console.log(`   - ${d}`));
    } else {
      console.log(`✅ نظيفة 100% - لم ترد كإجابة في أي مرحلة.`);
    }

    if (res.mentionedInClues.length > 0) {
      console.log(`ℹ️ ذُكرت في نصوص الأسئلة:`);
      res.mentionedInClues.forEach(c => console.log(`   - ${c}`));
    }
  }
}
