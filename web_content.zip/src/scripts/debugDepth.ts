import { CrosswordDesigner } from '../engine/CrosswordDesigner';
import { STAGE_01_QUESTIONS } from '../data/stage01Questions';

const designer = new CrosswordDesigner();
// Let's modify designer to print best depth state
try {
  designer.generateLayout(STAGE_01_QUESTIONS);
} catch (e: any) {
  console.log('Error output:', e.message);
}
