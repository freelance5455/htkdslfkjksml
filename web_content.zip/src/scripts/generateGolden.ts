import fs from 'fs';
import path from 'path';
import { CrosswordDesigner } from '../engine/CrosswordDesigner';
import { STAGE_01_QUESTIONS } from '../data/stage01Questions';
import { validateCrosswordLayout } from '../engine/CrosswordValidator';

async function run() {
  console.log('--- STARTING CROSSWORD DESIGNER GENERATION ---');
  console.log(`Input questions count: ${STAGE_01_QUESTIONS.length}`);

  const designer = new CrosswordDesigner();

  try {
    const { layout, validation } = designer.generateLayout(STAGE_01_QUESTIONS);

    console.log('\n--- GENERATION SUCCESS! ---');
    console.log(`Status: ${validation.statusMessage}`);
    console.log(`Grid Size: ${validation.stats.gridSize}`);
    console.log(`Placed Words: ${validation.stats.placedCount} / ${validation.stats.wordsCount}`);
    console.log(`Intersections: ${validation.stats.intersectionsCount}`);
    console.log(`Black Cells: ${validation.stats.blackCellsCount}`);
    console.log(`Connected: ${validation.stats.isConnected}`);
    console.log(`Unintended Words: ${validation.stats.unintendedWordsCount}`);

    for (const item of validation.items) {
      console.log(`[${item.passed ? 'X' : ' '}] ${item.label}: ${item.message}`);
    }

    const outputPath = path.join(process.cwd(), 'src', 'data', 'golden_stage_01.json');
    fs.writeFileSync(outputPath, JSON.stringify(layout, null, 2), 'utf8');
    console.log(`\nSaved layout to: ${outputPath}`);

    // Re-load file and run Validator again
    const rawSaved = fs.readFileSync(outputPath, 'utf8');
    const reloadedLayout = JSON.parse(rawSaved);
    const reloadedValidation = validateCrosswordLayout(reloadedLayout);

    console.log(`Reload Status: ${reloadedValidation.statusMessage}`);
  } catch (err: any) {
    console.error('\nGENERATION FAILED WITH ERROR:', err?.message || err);
    process.exit(1);
  }
}

run();
