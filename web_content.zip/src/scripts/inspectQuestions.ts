import fs from 'fs';
import path from 'path';
import { CrosswordDesigner } from '../engine/CrosswordDesigner';
import { STAGE_01_QUESTIONS } from '../data/stage01Questions';
import { normalizeArabicString } from '../engine/normalization';

console.log('--- INSPECTING STAGE 01 QUESTIONS & CHARACTER OVERLAPS ---');
for (const q of STAGE_01_QUESTIONS) {
  const norm = normalizeArabicString(q.answer);
  console.log(`${q.id}: ${q.answer} => norm: "${norm}" (len: ${norm.length})`);
}
