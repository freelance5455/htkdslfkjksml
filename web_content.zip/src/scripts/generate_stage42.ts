import fs from "fs";
import { generateCrosswordLayout } from "../engine/generator";
import { normalizeArabicString } from "../engine/normalization";
import { STAGES_DATABASE } from "../data/sampleStages";

interface InputWord {
  id: string;
  answer: string;
  clue: string;
}

const inputWords: InputWord[] = [
  {
    id: "42-1",
    answer: "سجاح التميمية",
    clue: "من المرأة العربية من بني تميم التي ادعت النبوة في الجزيرة العربية خلال حروب الردة وتزوجت من مسيلمة الكذاب؟"
  },
  {
    id: "42-2",
    answer: "الأكروفوبيا",
    clue: "في الطب النفسي واضطرابات القلق، ماذا يسمى الخوف المرضي الشديد وغير العقلاني من الأماكن المرتفعة والشواهق؟"
  },
  {
    id: "42-3",
    answer: "إيجة",
    clue: "ما البحر المتفرع من البحر الأبيض المتوسط والواقع بين شبه الجزيرة اليونانية والأناضول ويضم مئات الجزر؟"
  },
  {
    id: "42-4",
    answer: "أغسطس قيصر",
    clue: "من أول إمبراطور للإمبراطورية الرومانية ومؤسس السلالة اليوليوكلاودية وكان يُعرف سابقاً باسم أوكتافيوس؟"
  },
  {
    id: "42-5",
    answer: "ليونيل ميسي",
    clue: "من أسطورة كرة القدم الأرجنتينية وقائد منتخب التانغو المتوج بكأس العالم 2022 والحائز على الكرة الذهبية 8 مرات؟"
  },
  {
    id: "42-6",
    answer: "فيلادلفيا",
    clue: "ما المدينة التاريخية العريقة في ولاية بنسيلفانيا الأمريكية التي شهدت إعلان الاستقلال وصياغة الدستور وتشتهر بجرس الحرية؟"
  },
  {
    id: "42-7",
    answer: "دهوك",
    clue: "ما المدينة العراقية الجبلية العريقة الواقعة في أقصى شمال إقليم كردستان العراق وتشتهر بسدها التاريخي وبساتينها الخلابة؟"
  },
  {
    id: "42-8",
    answer: "ناظم الغزالي",
    clue: "من رائد وسفير المقام العراقي وأحد أشهر مطربي القرن العشرين وصاحب الروائع التراثية «طالعة من بيت أبوها» و«فوق النخل»؟"
  },
  {
    id: "42-9",
    answer: "سيدة الوركاء",
    clue: "ما القناع الرخامي الأثري السومري الشهير الذي يعود لأكثر من 3100 ق.م واكتُشف في مدينة أوروك ويمثل وجهاً أنثوياً بديعاً؟"
  },
  {
    id: "42-10",
    answer: "شفروليه",
    clue: "ما العلامة الأمريكية الشهيرة في صناعة السيارات التابعة لمجموعة جنرال موتورز وتتخذ من الصليب الذهبي شعاراً لها؟"
  },
  {
    id: "42-11",
    answer: "التوليب الأصفر",
    clue: "ما الزهرة البصلية الربيعية التي ترمز قديماً لدفء أشعة الشمس وابتسامتها، وشهدت هولندا في القرن السابع عشر حمى اقتصادية تاريخية للمضاربة على أبصالها النادرة؟"
  },
  {
    id: "42-12",
    answer: "لويس الرابع عشر",
    clue: "من ملك فرنسا الشهير الملقب بـ «الملك الشمس» وصاحب أطول فترة حكم مسجلة لملك في تاريخ أوروبا وباني قصر فرساي الأسطوري؟"
  },
  {
    id: "42-13",
    answer: "الخيمياء",
    clue: "في تاريخ العلوم، ماذا تسمى الممارسة الفلسفية والتجريبية القديمة التي سعت لتحويل المعادن البخسة إلى ذهب واكتشاف إكسير الحياة؟"
  },
  {
    id: "42-14",
    answer: "مرج دابق",
    clue: "ما المعركة التاريخية الفاصلة عام 1516م شمال حلب التي انتصر فيها السلطان العثماني سليم الأول على المماليك بقيادة قنصوه الغوري؟"
  },
  {
    id: "42-15",
    answer: "الزرقالي",
    clue: "من الفلكي والرياضي الأندلسي العبقري في طليطلة صاحب كتاب «جداول طليطلة» ومخترع نوع متطور وشامل من الإسطرلاب عُرف بالصفيحة؟"
  },
  {
    id: "42-16",
    answer: "روزاليند فرانكلين",
    clue: "من عالمة الكيمياء والبلورات البريطانية التي التقطت «الصورة 51» بالأشعة السينية وكانت الأساس الحاسم لكشف بنية الحمض النووي (DNA)؟"
  },
  {
    id: "42-17",
    answer: "طشقند",
    clue: "ما عاصمة جمهورية أوزبكستان وأكبر مدن آسيا الوسطى وإحدى المحطات التاريخية الشهيرة على طريق الحرير؟"
  },
  {
    id: "42-18",
    answer: "القرمز",
    clue: "ما الصبغة الطبيعية الحمراء الداكنة الشهيرة التي كانت تُستخرج قديماً من حشرات مجففة وتُصبغ بها المنسوجات وثياب الملوك؟"
  },
  {
    id: "42-19",
    answer: "السبابة",
    clue: "في تشريح كف اليد، ماذا تسمى الإصبع الواقعة بين الإبهام والوسطى وتُستخدم للإشارة والتنبيه وتعرف أيضاً بالمسبحة؟"
  },
  {
    id: "42-20",
    answer: "الأحقاف",
    clue: "ما السورة القرآنية الكريمة التي سُميت باسم ديار ومساكن قوم عاد الرملية الواقعة في جنوب شبه الجزيرة العربية؟"
  },
  {
    id: "42-21",
    answer: "الكولاجين",
    clue: "في الكيمياء الحيوية، ما البروتين الهيكلي الأكثر وفرة في جسم الإنسان والذي يشكل المكون الرئيسي للأنسجة الضامة والأوتار والجلد؟"
  },
  {
    id: "42-22",
    answer: "الكركند",
    clue: "ما الحيوان المفصلي القشري البحري الضخم ذو الكلابتين القويتين ويعيش في القيعان الصخرية ويُعرف في بعض البلدان بالاستاكوزا؟"
  },
  {
    id: "42-23",
    answer: "المجاز المرسل",
    clue: "في البلاغة العربية، ما اللفظ المستخدم في غير معناه الحقيقي لعلاقة غير المشابهة مع قرينة تمنع من إرادته كعلاقة الجزئية والكلية؟"
  },
  {
    id: "42-24",
    answer: "الترمس",
    clue: "ما النبات البقولي الزراعي ذو الحبوب الصفراء المعروفة بمرارتها والتي تُنقع وتُسلق بالملح كغذاء وتسلية شعبية شهيرة؟"
  },
  {
    id: "42-25",
    answer: "إيغواسو",
    clue: "ما الشلالات الطبيعية العملاقة المذهلة الواقعة على الحدود بين البرازيل والأرجنتين وتتكون من منظومة تضم أكثر من 270 شلالاً؟"
  }
];

async function run() {
  console.log("Generating 25x25 grid for Stage 42 with 25 words...");
  
  const wordsForGen = inputWords.map((w, index) => ({
    id: w.id,
    word: w.answer,
    clue: w.clue,
    number: index + 1
  }));

  let bestResult = null;
  let attempts = 0;
  const maxAttempts = 100;

  while (attempts < maxAttempts) {
    attempts++;
    // Shuffle slightly to find best connectivity
    const shuffled = [...wordsForGen];
    if (attempts > 1) {
      // Keep longer words early
      shuffled.sort((a, b) => b.word.length - a.word.length + (Math.random() * 2 - 1));
    } else {
      shuffled.sort((a, b) => b.word.length - a.word.length);
    }

    const result = generateCrosswordLayout(shuffled, 25, 25);
    if (result && result.placedWords.length === 25) {
      console.log(`Success! All 25 words placed on attempt #${attempts}`);
      bestResult = result;
      break;
    }
  }

  if (!bestResult || bestResult.placedWords.length !== 25) {
    console.error(`Failed to place all 25 words. Placed: ${bestResult?.placedWords.length || 0}`);
    process.exit(1);
  }

  // Convert to Golden Stage structure
  const goldenStage = {
    id: 42,
    gridSize: 25,
    words: bestResult.placedWords.map((pw, i) => {
      const orig = inputWords.find(w => w.id === pw.id)!;
      return {
        id: orig.id,
        number: i + 1,
        direction: pw.direction === "across" ? "horizontal" : "vertical",
        clue: orig.clue,
        answer: orig.answer,
        startPos: {
          row: pw.row,
          col: pw.col
        },
        length: pw.length,
        reversed: false
      };
    })
  };

  fs.writeFileSync("./src/data/golden_stage_42.json", JSON.stringify(goldenStage, null, 2), "utf-8");
  console.log("Saved ./src/data/golden_stage_42.json successfully!");
}

run();
