# Filmland — Persian movie/series app

SPA (RTL): auth (Gmail-only register + optional Google OAuth), home/vitrine, search+filters, details+player, collections, favs, news, support (live chat via comments-plugin + server tickets + WhatsApp/Telegram), account, plans/subscription, admin panel.

## Data
- Real catalog in src/catalog.js (12 public-domain classics from archive.org, free & legal). Admin replaces/extends with own links in panel (video + optional Google Drive link per title), then publishes to the shared server with «انتشار کاتالوگ».
- Two stores: local device (kv-plugin `kv.app` key `db`, localStorage fallback) for session/favs/offline, and shared server state (server-plugin `Uint8Array`, versioned layout, currently v8) for accounts, subs, payments, codes, tickets, comments, published catalog, config.
- Server state layout: R_USERS records are 192 bytes (email 64 + name 48 + **sha256-hex 64** + subUntil u64 + google flag). Hash field was widened from 32→64 in v3 (v2 and earlier truncated the hash, which broke login). Version bump wipes old state cleanly via `state.fill(0)`.
- Fresh installs auto-seed owner config (v4+): subRequired=on, card `6219861485623739`, telegram `B2F_WBC`, 4 plans (یک‌ماهه ۳۰ روزه ۵۵ هزار تومان / سه‌ماهه ۱۶۰ / شش‌ماهه ۳۰۰ / یک‌ساله ۵۹۰). Current state version: v8.
- Instant payment: client `payBox` calls new `payInstant` RPC (grants sub immediately, records pending receipt for later admin review). `adminPayNo` now also zeroes the user's sub. Trust-first model: fake receipts get revoked/banned by admin.

## Subscription model (manual gateway)
- Admin > settings: subRequired toggle, plans, card number, optional online-pay link, contact numbers, Google Client ID.
- User pays -> submits receipt ref -> admin approves in payments tab (or redeem activation codes from codes tab).
- A fully automatic bank gateway needs a merchant account + server-side verify; the payLink field is the hook for it.

## Admin
- Server admin password: `FLM-AC874C-D6480F-01D09F` (only its SHA-256 hash `09bfa2a8…` is stored in the server script; never put the password itself in code). After any disconnect, admin must log in again (server keeps auth per-connection).
- Publish flow is chunked (adminPubBegin / adminPubMovie × N / adminPubCommit) to stay under emulator/production RPC time limits.
- Server scans that touch big regions (commentsList, redeem, movieIdx, adminPayments/Tickets/Codes) use byte-compare pre-checks and skip empty records to avoid timeout warnings.

## Files
- main.pjs (kv + commentsPlugin + createServerSocket imports, $meta with icon), index.html (server script MUST stay the first element + shell/styles + module loader), src/app.js (SPA), src/net.js (socket manager: no retry on 4403, 120s pause on 4429, rpc timeout), src/catalog.js (demo data).
