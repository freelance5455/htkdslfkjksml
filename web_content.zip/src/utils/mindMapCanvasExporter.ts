import { MindMapData, MindMapNode } from "../types";

// Renders the entire Mind Map into a single, high-resolution colorful graphic image with boxes, circles, connected lines, and embedded micro-images
export async function generateSingleMindMapImage(mindMap: MindMapData): Promise<string> {
  const width = 1600;
  const height = 1050;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");

  if (!ctx) {
    throw new Error("Could not create canvas context");
  }

  // 1. Dark Futuristic Gradient Canvas Background
  const bgGradient = ctx.createLinearGradient(0, 0, width, height);
  bgGradient.addColorStop(0, "#090d16");
  bgGradient.addColorStop(0.5, "#0f172a");
  bgGradient.addColorStop(1, "#090d16");
  ctx.fillStyle = bgGradient;
  ctx.fillRect(0, 0, width, height);

  // Decorative Background Grid Dots
  ctx.fillStyle = "rgba(255, 255, 255, 0.04)";
  for (let x = 20; x < width; x += 30) {
    for (let y = 20; y < height; y += 30) {
      ctx.beginPath();
      ctx.arc(x, y, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Header Title Banner Card
  const headerGrad = ctx.createLinearGradient(100, 30, width - 100, 30);
  headerGrad.addColorStop(0, "rgba(99, 102, 241, 0.15)");
  headerGrad.addColorStop(0.5, "rgba(168, 85, 247, 0.2)");
  headerGrad.addColorStop(1, "rgba(236, 72, 153, 0.15)");
  
  ctx.fillStyle = headerGrad;
  ctx.beginPath();
  ctx.roundRect(100, 30, width - 200, 90, 16);
  ctx.fill();
  ctx.strokeStyle = "rgba(168, 85, 247, 0.4)";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Header Text
  ctx.textAlign = "center";
  ctx.fillStyle = "#a855f7";
  ctx.font = "bold 13px sans-serif";
  ctx.fillText("AI SCIENTIFIC CONSOLIDATED MIND MAP DIAGRAM", width / 2, 55);

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 26px sans-serif";
  ctx.fillText(mindMap.topicTitle.toUpperCase(), width / 2, 88);

  // Separate root node & subnodes
  const rootNode = mindMap.nodes.find((n) => n.isMainRoot) || mindMap.nodes[0];
  const subNodes = mindMap.nodes.filter((n) => n.id !== rootNode?.id);

  // Root Node Dimensions & Position
  const rootX = width / 2;
  const rootY = 240;
  const rootW = 640;
  const rootH = 140;

  // Subnode Themes Palette
  const nodeThemes = [
    { main: "#10b981", bg: "#064e3b", border: "#34d399", line: "#10b981", title: "#6ee7b7" }, // Emerald
    { main: "#06b6d4", bg: "#164e63", border: "#22d3ee", line: "#06b6d4", title: "#67e8f9" }, // Cyan
    { main: "#ec4899", bg: "#831843", border: "#f472b6", line: "#ec4899", title: "#fbcfe8" }, // Pink
    { main: "#a855f7", bg: "#581c87", border: "#c084fc", line: "#a855f7", title: "#e9d5ff" }, // Purple
    { main: "#f59e0b", bg: "#78350f", border: "#fbbf24", line: "#f59e0b", title: "#fde68a" }, // Amber
  ];

  // Calculate Subnode Positions (Horizontal spread across bottom)
  const count = subNodes.length;
  const subY = 620;
  const cardW = 320;
  const cardH = 220;
  const totalW = count * cardW + (count - 1) * 35;
  const startX = (width - totalW) / 2 + cardW / 2;

  const subPositions: Array<{ x: number; y: number; node: MindMapNode; theme: typeof nodeThemes[0] }> = [];
  subNodes.forEach((node, idx) => {
    const x = startX + idx * (cardW + 35);
    const theme = nodeThemes[idx % nodeThemes.length];
    subPositions.push({ x, y: subY, node, theme });
  });

  // 2. Draw Connected Colorful Lines & Circles between Root and Subnodes
  subPositions.forEach(({ x, y, theme }) => {
    const startXPt = rootX;
    const startYPt = rootY + rootH / 2;
    const endXPt = x;
    const endYPt = y - cardH / 2;

    // Curved Bezier Path
    ctx.beginPath();
    ctx.moveTo(startXPt, startYPt);
    const controlY = startYPt + (endYPt - startYPt) / 2;
    ctx.bezierCurveTo(startXPt, controlY, endXPt, controlY, endXPt, endYPt);
    
    ctx.strokeStyle = theme.line;
    ctx.lineWidth = 4;
    ctx.setLineDash([8, 6]);
    ctx.stroke();
    ctx.setLineDash([]);

    // Glowing Joint Circle
    ctx.fillStyle = theme.main;
    ctx.beginPath();
    ctx.arc(endXPt, endYPt, 7, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2;
    ctx.stroke();
  });

  // 3. Draw Central Root Node Box
  if (rootNode) {
    const rx = rootX - rootW / 2;
    const ry = rootY - rootH / 2;

    // Outer Glow Shadow
    ctx.shadowColor = "#6366f1";
    ctx.shadowBlur = 25;

    // Fill Box
    const rootBoxGrad = ctx.createLinearGradient(rx, ry, rx + rootW, ry + rootH);
    rootBoxGrad.addColorStop(0, "#1e1b4b");
    rootBoxGrad.addColorStop(1, "#31104b");
    ctx.fillStyle = rootBoxGrad;
    ctx.beginPath();
    ctx.roundRect(rx, ry, rootW, rootH, 20);
    ctx.fill();

    ctx.shadowBlur = 0; // reset glow

    // Border
    ctx.strokeStyle = "#818cf8";
    ctx.lineWidth = 3;
    ctx.stroke();

    // Central Circle Icon Badge
    ctx.fillStyle = "#6366f1";
    ctx.beginPath();
    ctx.arc(rx + 45, ry + 40, 20, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 16px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("⚛", rx + 45, ry + 46);

    // Category Badge
    ctx.fillStyle = "#4f46e5";
    ctx.beginPath();
    ctx.roundRect(rx + 75, ry + 25, 120, 24, 12);
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 11px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("CENTRAL TOPIC", rx + 135, ry + 41);

    // Root Title & Text
    ctx.textAlign = "left";
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 22px sans-serif";
    ctx.fillText(rootNode.title, rx + 25, ry + 85);

    ctx.fillStyle = "#cbd5e1";
    ctx.font = "12px sans-serif";
    
    // Wrap summary text inside root node
    const words = rootNode.summary.split(" ");
    let line = "";
    let lineY = ry + 110;
    const maxTextW = rootW - 50;

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + " ";
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxTextW && n > 0) {
        ctx.fillText(line, rx + 25, lineY);
        line = words[n] + " ";
        lineY += 18;
        if (lineY > ry + rootH - 12) break;
      } else {
        line = testLine;
      }
    }
    if (lineY <= ry + rootH - 12) {
      ctx.fillText(line, rx + 25, lineY);
    }
  }

  // 4. Draw Subtopic Nodes (Clean Text & Concept Boxes with Circles & Colors)
  subPositions.forEach(({ x, y, node, theme }) => {
    const cx = x - cardW / 2;
    const cy = y - cardH / 2;

    // Node Outer Glow Shadow
    ctx.shadowColor = theme.main;
    ctx.shadowBlur = 18;

    // Card Fill
    const cardGrad = ctx.createLinearGradient(cx, cy, cx, cy + cardH);
    cardGrad.addColorStop(0, "#0f172a");
    cardGrad.addColorStop(1, theme.bg);
    ctx.fillStyle = cardGrad;
    ctx.beginPath();
    ctx.roundRect(cx, cy, cardW, cardH, 18);
    ctx.fill();

    ctx.shadowBlur = 0; // reset

    // Card Border
    ctx.strokeStyle = theme.border;
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Top Category Circle Badge
    ctx.fillStyle = theme.main;
    ctx.beginPath();
    ctx.arc(cx + 25, cy + 25, 12, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#000000";
    ctx.font = "bold 11px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("●", cx + 25, cy + 29);

    ctx.fillStyle = theme.title;
    ctx.font = "bold 11px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText((node.category || "SUBTOPIC").toUpperCase(), cx + 45, cy + 29);

    // Node Title
    ctx.textAlign = "left";
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 15px sans-serif";
    ctx.fillText(node.title, cx + 20, cy + 62);

    // Divider Line
    ctx.strokeStyle = "rgba(255, 255, 255, 0.15)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx + 20, cy + 74);
    ctx.lineTo(cx + cardW - 20, cy + 74);
    ctx.stroke();

    // Node Summary Text
    ctx.fillStyle = "#cbd5e1";
    ctx.font = "12px sans-serif";

    const words = node.summary.split(" ");
    let line = "";
    let lineY = cy + 98;
    const maxTextW = cardW - 40;

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + " ";
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxTextW && n > 0) {
        ctx.fillText(line, cx + 20, lineY);
        line = words[n] + " ";
        lineY += 18;
        if (lineY > cy + cardH - 14) break;
      } else {
        line = testLine;
      }
    }
    if (lineY <= cy + cardH - 14) {
      ctx.fillText(line, cx + 20, lineY);
    }
  });

  // Footer Tagline
  ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
  ctx.font = "11px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("AI Studio Scientific Concept Mind Map Diagram", width / 2, height - 25);

  return canvas.toDataURL("image/png");
}
