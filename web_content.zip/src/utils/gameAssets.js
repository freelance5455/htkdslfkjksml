import { useEffect, useState } from 'react';
const decodedImageCache = new Map();
const objectUrlCache = new Map();
const inflightLoads = new Map();
const assetListeners = new Map();
// Tier 1: Critical UI, gameplay, and Game Over assets loaded immediately
export const CRITICAL_GAME_IMAGES = [
    'assets/flapora/FLAPORA_background.webp',
    'assets/flapora/FLAPORA_logo.webp',
    'assets/flapora/FLAPORA_play.webp',
    'assets/flapora/FLAPORA_replay.webp',
    'assets/flapora/FLAPORA_home.webp',
    'assets/flapora/FLAPORA_trophy.webp',
    'assets/flapora/FLAPORA_trophy_bronze.webp',
    'assets/flapora/FLAPORA_trophy_silver.webp',
    'assets/flapora/FLAPORA_trophy_royal.webp',
    'assets/flapora/bird_sheet.webp',
    'assets/flapora/FLAPORA_pipe.webp',
    'assets/flapora/FLAPORA_music.webp',
    'assets/flapora/FLAPORA_picture.webp',
    'assets/flapora/FLAPORA_seeting.webp',
    'assets/flapora/FLAPORA_store.webp',
];
// Tier 2: Secondary store skins & background worlds warmed in the background
export const SECONDARY_GAME_IMAGES = [
    'assets/flapora/bird2_sheet.webp',
    'assets/flapora/FLAPORA_bird_blue.webp',
    'assets/flapora/FLAPORA_bird_pink.webp',
    'assets/flapora/FLAPORA_bg_sunset.webp',
    'assets/flapora/FLAPORA_bg_night.webp',
    'assets/flapora/FLAPORA_bg_sakura.webp',
    'assets/flapora/FLAPORA_pipe_gold.webp',
    'assets/flapora/FLAPORA_pipe_ice.webp',
    'assets/flapora/FLAPORA_pipe_lava.webp',
    'assets/flapora/FLAPORA_pipe_sakura.webp',
    'assets/flapora/FLAPORA_pipe_amethyst.webp',
    'assets/flapora/FLAPORA_pipe_candy.webp',
    'assets/flapora/FLAPORA_pipe_neon.webp',
    'assets/flapora/FLAPORA_pipe_stone.webp',
    'assets/flapora/FLAPORA_pipe_rainbow.webp',
];
export const GAME_CORE_IMAGES = [
    ...CRITICAL_GAME_IMAGES,
    ...SECONDARY_GAME_IMAGES,
];
function notifyAssetReady(src) {
    const listeners = assetListeners.get(src);
    if (!listeners)
        return;
    listeners.forEach((cb) => cb());
}
export function getCachedImage(src) {
    return decodedImageCache.get(src) ?? null;
}
export function getAssetSrc(src) {
    return objectUrlCache.get(src) ?? src;
}
export function useAssetSrc(src) {
    const [resolved, setResolved] = useState(() => getAssetSrc(src));
    useEffect(() => {
        setResolved(getAssetSrc(src));
        if (!src || objectUrlCache.has(src))
            return;
        let listeners = assetListeners.get(src);
        if (!listeners) {
            listeners = new Set();
            assetListeners.set(src, listeners);
        }
        const onReady = () => {
            setResolved(getAssetSrc(src));
        };
        listeners.add(onReady);
        void preloadGameImage(src);
        return () => {
            listeners?.delete(onReady);
        };
    }, [src]);
    return resolved;
}
function decodeImageElement(loadSrc) {
    return new Promise((resolve) => {
        const img = new Image();
        img.decoding = 'async';
        const finish = () => {
            resolve(img);
        };
        img.onload = () => {
            if (typeof img.decode === 'function') {
                img.decode().then(finish, finish);
            }
            else {
                finish();
            }
        };
        img.onerror = () => {
            resolve(null);
        };
        img.src = loadSrc;
    });
}
export function preloadGameImage(src) {
    if (typeof window === 'undefined' || !src)
        return Promise.resolve(null);
    const cached = decodedImageCache.get(src);
    if (cached && cached.complete && cached.naturalWidth > 0) {
        return Promise.resolve(cached);
    }
    const existing = inflightLoads.get(src);
    if (existing)
        return existing;
    const isInlineUrl = src.startsWith('data:') || src.startsWith('blob:');
    const promise = (async () => {
        let loadUrl = src;
        // Fetch once into an in-memory Blob URL so subsequent <img> mounts render instantaneously from RAM
        if (!isInlineUrl) {
            try {
                const res = await fetch(src, { cache: 'force-cache' });
                if (res.ok) {
                    const blob = await res.blob();
                    const blobUrl = URL.createObjectURL(blob);
                    objectUrlCache.set(src, blobUrl);
                    loadUrl = blobUrl;
                }
            }
            catch {
                // Fall back to direct URL loading
            }
        }
        const img = await decodeImageElement(loadUrl);
        inflightLoads.delete(src);
        if (img) {
            decodedImageCache.set(src, img);
            notifyAssetReady(src);
            return img;
        }
        // If blob decode failed for any reason, retry once with original src
        if (loadUrl !== src) {
            const revoked = objectUrlCache.get(src);
            if (revoked) {
                URL.revokeObjectURL(revoked);
                objectUrlCache.delete(src);
            }
            const fallbackImg = await decodeImageElement(src);
            if (fallbackImg) {
                decodedImageCache.set(src, fallbackImg);
                notifyAssetReady(src);
                return fallbackImg;
            }
        }
        return null;
    })();
    inflightLoads.set(src, promise);
    return promise;
}
let secondaryWarmed = false;
export function preloadCoreGameAssets(extraSources) {
    const tier1 = new Set(CRITICAL_GAME_IMAGES);
    extraSources.forEach((src) => {
        if (src)
            tier1.add(src);
    });
    const tier1Promises = Array.from(tier1).map((src) => preloadGameImage(src));
    if (!secondaryWarmed) {
        secondaryWarmed = true;
        void Promise.allSettled(tier1Promises).then(() => {
            SECONDARY_GAME_IMAGES.forEach((src) => {
                void preloadGameImage(src);
            });
        });
    }
}
