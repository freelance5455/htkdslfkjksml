import test from 'node:test';
import assert from 'node:assert/strict';
import { convertFromDZD, convertToDZD, formatPrice } from './currency';

test('convertFromDZD converts accurately to EUR and USD', () => {
  // 240,000 DZD at 240 = 1000 EUR
  assert.equal(convertFromDZD(240000, 'EUR'), 1000);
  // 220,000 DZD at 220 = 1000 USD
  assert.equal(convertFromDZD(220000, 'USD'), 1000);
  // DZD to DZD is 1:1
  assert.equal(convertFromDZD(50000, 'DZD'), 50000);
});

test('convertToDZD converts accurately from foreign currencies', () => {
  assert.equal(convertToDZD(100, 'EUR'), 24000);
  assert.equal(convertToDZD(100, 'USD'), 22000);
  assert.equal(convertToDZD(500, 'DZD'), 500);
});

test('formatPrice provides clean currency strings', () => {
  const arabicDZD = formatPrice(120000, 'DZD', 'ar');
  assert.match(arabicDZD, /دج/);

  const euroPrice = formatPrice(24000, 'EUR', 'en');
  assert.equal(euroPrice, '€100.00');
});
