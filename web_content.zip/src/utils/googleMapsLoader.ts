// Google Maps Loader & Configuration Utility
export const GOOGLE_MAPS_API_KEY: string =
  (import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string) || 'AIzaSyCXRfyDAO7GWUkChP8AAf5pio-1OckxKBU';

let loadPromise: Promise<void> | null = null;

/**
 * Dynamically loads the official Google Maps JavaScript API script.
 */
export function loadGoogleMapsScript(): Promise<void> {
  if (typeof window !== 'undefined' && (window as any).google?.maps) {
    return Promise.resolve();
  }

  if (loadPromise) {
    return loadPromise;
  }

  loadPromise = new Promise<void>((resolve, reject) => {
    const existingScript = document.getElementById('google-maps-js-sdk');
    if (existingScript) {
      existingScript.addEventListener('load', () => resolve());
      existingScript.addEventListener('error', (e) => reject(e));
      return;
    }

    const script = document.createElement('script');
    script.id = 'google-maps-js-sdk';
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(GOOGLE_MAPS_API_KEY)}&libraries=places,marker&v=weekly&loading=async`;
    script.async = true;
    script.defer = true;

    script.onload = () => {
      resolve();
    };

    script.onerror = (err) => {
      console.warn('Failed to load Google Maps script from Google CDN:', err);
      reject(err);
    };

    document.head.appendChild(script);
  });

  return loadPromise;
}

/**
 * Google Maps Road, Satellite, and Terrain tile layer configurations.
 */
export const GOOGLE_MAPS_TILE_PROVIDERS = {
  roadmap: {
    name: 'Google Maps Roadmap',
    url: 'https://mt{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}&key=' + GOOGLE_MAPS_API_KEY,
    subdomains: ['0', '1', '2', '3'],
    maxZoom: 20,
    attribution: '&copy; Google Maps',
  },
  satellite: {
    name: 'Google Maps Satellite',
    url: 'https://mt{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}&key=' + GOOGLE_MAPS_API_KEY,
    subdomains: ['0', '1', '2', '3'],
    maxZoom: 20,
    attribution: '&copy; Google Maps',
  },
  terrain: {
    name: 'Google Maps Terrain',
    url: 'https://mt{s}.google.com/vt/lyrs=p&x={x}&y={y}&z={z}&key=' + GOOGLE_MAPS_API_KEY,
    subdomains: ['0', '1', '2', '3'],
    maxZoom: 20,
    attribution: '&copy; Google Maps',
  },
};
