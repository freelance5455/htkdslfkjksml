/**
 * High-reliability client-side APK and Full Project ZIP downloader.
 * Guarantees direct file download to phone storage.
 * Real APK Size: 7.10 MB (BrandMorph_Julli_v1.0.apk)
 * Real ZIP Size: 3.08 MB (BrandMorph_Project.zip)
 */

export function getFullApkDownloadUrl(): string {
  if (typeof window !== 'undefined' && window.location && window.location.origin) {
    return `${window.location.origin}/BrandMorph_Julli_v1.0.apk`;
  }
  return '/BrandMorph_Julli_v1.0.apk';
}

export function getFullZipDownloadUrl(): string {
  if (typeof window !== 'undefined' && window.location && window.location.origin) {
    return `${window.location.origin}/BrandMorph_Project.zip`;
  }
  return '/BrandMorph_Project.zip';
}

/**
 * Downloads the real 7.10 MB APK directly into the device's downloads folder.
 * Uses in-memory Blob to completely avoid opening any external browser redirects.
 */
export async function downloadApkBlob(
  onProgress?: (status: string) => void
): Promise<{ success: boolean; error?: string; bytesDownloaded?: number }> {
  try {
    if (onProgress) onProgress('Connecting to APK download server...');

    let response = await fetch('/BrandMorph_Julli_v1.0.apk');
    if (!response.ok) {
      response = await fetch('/api/download-apk');
    }
    if (!response.ok) {
      const fullUrl = getFullApkDownloadUrl();
      response = await fetch(fullUrl);
    }

    if (!response.ok) {
      throw new Error(`Server returned HTTP ${response.status}: ${response.statusText}`);
    }

    if (onProgress) onProgress('Downloading 7.10 MB verified APK binary...');
    const blob = await response.blob();

    // Strict package size check: real APK must be ~7.10 MB (at least 5 MB)
    if (blob.size < 5000000) {
      throw new Error(
        `Corrupt/small package detected: ${(blob.size / 1024).toFixed(1)} KB (expected 7.10 MB)`
      );
    }

    if (onProgress) onProgress(`Saving BrandMorph_Julli_v1.0.apk (${(blob.size / (1024 * 1024)).toFixed(2)} MB)...`);

    const apkBlob = new Blob([blob], {
      type: 'application/vnd.android.package-archive',
    });
    const blobUrl = window.URL.createObjectURL(apkBlob);

    // Direct anchor click without target="_blank" so no webview tab is spawned
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = blobUrl;
    a.download = 'BrandMorph_Julli_v1.0.apk';
    document.body.appendChild(a);
    a.click();

    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
      window.URL.revokeObjectURL(blobUrl);
    }, 4000);

    return {
      success: true,
      bytesDownloaded: blob.size,
    };
  } catch (err: any) {
    console.error('APK download error:', err);
    return {
      success: false,
      error: err?.message || 'Download failed',
    };
  }
}

/**
 * Downloads the full 3.0 MB Project ZIP directly into device storage without webview.
 */
export async function downloadZipBlob(
  onProgress?: (status: string) => void
): Promise<{ success: boolean; error?: string; bytesDownloaded?: number }> {
  try {
    if (onProgress) onProgress('Connecting to Project ZIP server...');

    let response = await fetch('/BrandMorph_Project.zip');
    if (!response.ok) {
      response = await fetch('/api/download-zip');
    }
    if (!response.ok) {
      const fullUrl = getFullZipDownloadUrl();
      response = await fetch(fullUrl);
    }

    if (!response.ok) {
      throw new Error(`Server returned HTTP ${response.status}: ${response.statusText}`);
    }

    if (onProgress) onProgress('Downloading Full Project ZIP (3.0 MB)...');
    const blob = await response.blob();

    if (blob.size < 100000) {
      throw new Error(`Incomplete zip detected: ${(blob.size / 1024).toFixed(1)} KB`);
    }

    const zipBlob = new Blob([blob], {
      type: 'application/zip',
    });
    const blobUrl = window.URL.createObjectURL(zipBlob);

    // Direct anchor click without target="_blank"
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = blobUrl;
    a.download = 'BrandMorph_Project.zip';
    document.body.appendChild(a);
    a.click();

    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
      window.URL.revokeObjectURL(blobUrl);
    }, 4000);

    return {
      success: true,
      bytesDownloaded: blob.size,
    };
  } catch (err: any) {
    console.error('ZIP download error:', err);
    return {
      success: false,
      error: err?.message || 'ZIP Download failed',
    };
  }
}

export function triggerDirectBrowserDownload(): void {
  downloadApkBlob();
}

export function triggerDirectZipDownload(): void {
  downloadZipBlob();
}
