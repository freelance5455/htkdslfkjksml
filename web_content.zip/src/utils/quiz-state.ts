export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  hint?: string;
  topic?: string;
}

export interface QuizResultSummary {
  total: number;
  correct: number;
  percentage: number;
  feedbackTier: 'mastery' | 'proficient' | 'review_needed' | 'beginning';
  feedbackMessage: string;
}

export function evaluateQuizScore(answers: Record<string, number>, questions: QuizQuestion[]): QuizResultSummary {
  const total = questions.length;
  if (total === 0) {
    return {
      total: 0,
      correct: 0,
      percentage: 0,
      feedbackTier: 'beginning',
      feedbackMessage: 'No questions answered yet.',
    };
  }

  let correct = 0;
  for (const q of questions) {
    if (answers[q.id] === q.correctOptionIndex) {
      correct++;
    }
  }

  const percentage = Math.round((correct / total) * 100);

  let feedbackTier: QuizResultSummary['feedbackTier'] = 'beginning';
  let feedbackMessage = '';

  if (percentage >= 90) {
    feedbackTier = 'mastery';
    feedbackMessage = 'Outstanding mastery! You have a solid grasp of this topic.';
  } else if (percentage >= 70) {
    feedbackTier = 'proficient';
    feedbackMessage = 'Great job! You understand the key concepts with just a few minor gaps.';
  } else if (percentage >= 50) {
    feedbackTier = 'review_needed';
    feedbackMessage = 'Good effort! Review the explanations for the ones you missed and try again.';
  } else {
    feedbackTier = 'beginning';
    feedbackMessage = 'Keep going! Ask the tutor to break down the tricky parts step-by-step.';
  }

  return {
    total,
    correct,
    percentage,
    feedbackTier,
    feedbackMessage,
  };
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  category?: string;
  difficulty?: 'easy' | 'medium' | 'hard';
}

export function filterFlashcards(cards: Flashcard[], query: string): Flashcard[] {
  const clean = query.trim().toLowerCase();
  if (!clean) return cards;
  return cards.filter(
    (c) =>
      c.front.toLowerCase().includes(clean) ||
      c.back.toLowerCase().includes(clean) ||
      c.category?.toLowerCase().includes(clean)
  );
}
