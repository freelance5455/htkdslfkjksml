import { Currency, Language } from '../types';

export interface ParsedTravelRequest {
  rawInput: string;
  destination: string;
  destinationCountry: string;
  destinationKey: string;
  durationDays: number;
  datesText: string;
  travelersCount: number;
  travelersLabel: string;
  budgetEstimatedDZD: number;
  budgetTier: 'economy' | 'moderate' | 'luxury' | 'vip';
  budgetSpecified: boolean;
  confidenceScore: number; // 0 - 100
  matchedKeywords: string[];
}

export interface AITripSuggestion {
  id: string;
  title: string;
  subtitle: string;
  destination: string;
  destinationCountry: string;
  durationDays: number;
  travelersCount: number;
  totalCostDZD: number;
  costPerPersonDZD: number;
  budgetTier: 'economy' | 'moderate' | 'luxury' | 'vip';
  tripStyle: string;
  flight: {
    airline: string;
    flightNumber: string;
    route: string;
    cabin: string;
    priceDZD: number;
    duration: string;
    direct: boolean;
  };
  hotel: {
    name: string;
    stars: number;
    roomType: string;
    pricePerNightDZD: number;
    totalHotelDZD: number;
    location: string;
    amenities: string[];
  };
  timelineHighlights: Array<{
    day: number;
    title: string;
    description: string;
    icon: string;
  }>;
  includedServices: string[];
  smartTip: string;
  visaRequirementsSummary: string;
}

// Known travel destinations database for intelligent entity extraction
interface DestinationInfo {
  key: string;
  nameAr: string;
  nameFr: string;
  nameEn: string;
  countryAr: string;
  countryFr: string;
  countryEn: string;
  keywords: string[];
  defaultFlightPriceDZD: number;
  defaultHotelPerNightDZD: number;
  typicalDurationDays: number;
  defaultAirline: string;
  defaultHotel: string;
  highlights: Array<{ titleAr: string; titleEn: string; descAr: string; descEn: string; icon: string }>;
  visaSummaryAr: string;
  visaSummaryEn: string;
}

const DESTINATIONS: DestinationInfo[] = [
  {
    key: 'istanbul',
    nameAr: 'إسطنبول (Istanbul)',
    nameFr: 'Istanbul',
    nameEn: 'Istanbul',
    countryAr: 'تركيا',
    countryFr: 'Turquie',
    countryEn: 'Turkey',
    keywords: ['إسطنبول', 'اسطنبول', 'تركيا', 'istanbul', 'turkey', 'turquie', 'bosphore', 'بوسفور'],
    defaultFlightPriceDZD: 68500,
    defaultHotelPerNightDZD: 28000,
    typicalDurationDays: 7,
    defaultAirline: 'Turkish Airlines (مباشر ALG - IST)',
    defaultHotel: 'Swissôtel The Bosphorus (5 نجوم)',
    highlights: [
      { titleAr: 'جولة البوسفور البحرية', titleEn: 'Bosphorus Yacht Cruise', descAr: 'إبحار خاص لمشاهدة قصور السلاطين وجسر البوسفور', descEn: 'Private cruise viewing Ottoman palaces and Bosphorus bridge', icon: '⛵' },
      { titleAr: 'سحر آيا صوفيا والسلطان أحمد', titleEn: 'Hagia Sophia & Sultanahmet', descAr: 'استكشاف العمارة العثمانية والبيزنطية مع مرشد خاص', descEn: 'Explore historic Ottoman and Byzantine architecture', icon: '🏛️' },
      { titleAr: 'التسوق في البازار الكبير وزورلو', titleEn: 'Grand Bazaar & Zorlu Center', descAr: 'شراء الحرف التركية والماركات العالمية الفاخرة', descEn: 'Authentic Turkish craftsmanship and luxury shopping', icon: '🛍️' },
      { titleAr: 'جزر الأميرات الساحرة', titleEn: 'Princes Islands Retreat', descAr: 'يوم استجمام نقي في جزيرة بيوك أضا مع جولة العربات', descEn: 'Serene island day trip with electric carriage tour', icon: '🌿' },
    ],
    visaSummaryAr: 'تأشيرة إلكترونية B1/C1 فورية عبر TAKI-GO خلال 15 دقيقة لمن يملكون شنغن أو تحت سن 18 وفوق 35.',
    visaSummaryEn: 'Instant eVisa via TAKI-GO in 15 minutes for Schengen holders or aged under 18 & over 35.',
  },
  {
    key: 'umrah',
    nameAr: 'مكة المكرمة والمدينة المنورة (عمرة)',
    nameFr: 'Mecque & Médine (Omra)',
    nameEn: 'Mecca & Medina (Umrah)',
    countryAr: 'المملكة العربية السعودية',
    countryFr: 'Arabie Saoudite',
    countryEn: 'Saudi Arabia',
    keywords: ['عمرة', 'مكة', 'مكه', 'المدينة', 'السعودية', 'حج', 'omra', 'umrah', 'mecca', 'medina', 'saudi'],
    defaultFlightPriceDZD: 125000,
    defaultHotelPerNightDZD: 38000,
    typicalDurationDays: 14,
    defaultAirline: 'Saudia Airlines (مباشر ALG - JED)',
    defaultHotel: 'فندق بولمان زمزم مكة + أوبروي المدينة',
    highlights: [
      { titleAr: 'أداء مناسك العمرة المباركة', titleEn: 'Perform Umrah Rituals', descAr: 'طواف وسعي بإشراف مرشد ديني مرافق مع ماء زمزم مبارك', descEn: 'Tawaf and Saee guided rituals with blessed Zamzam water', icon: '🕋' },
      { titleAr: 'زيارة الروضة الشريفة ومسجد قباء', titleEn: 'Rawdah Sharif & Quba Mosque', descAr: 'حجز مؤكد لتصريح الروضة عبر منصة نسك وزيارة مقبرة البقيع', descEn: 'Confirmed permit for Rawdah visit and historic Ziyarat', icon: '🕌' },
      { titleAr: 'مزارات مكة (غار حراء وثور)', titleEn: 'Historic Mecca Landmarks', descAr: 'جولة إيمانية وتاريخية لتوثيق سيرة المصطفى صلى الله عليه وسلم', descEn: 'Spiritual tour of Mount Noor, Hira cave and historic sites', icon: '✨' },
    ],
    visaSummaryAr: 'تأشيرة عمرة وسياحة سعودية صادرة مباشرة مع منصة نسك الرسمية مع تأمين صحي شامل.',
    visaSummaryEn: 'Official Umrah & Tourist visa issued directly via Nusuk with comprehensive health insurance.',
  },
  {
    key: 'paris',
    nameAr: 'باريس (Paris)',
    nameFr: 'Paris',
    nameEn: 'Paris',
    countryAr: 'فرنسا',
    countryFr: 'France',
    countryEn: 'France',
    keywords: ['باريس', 'فرنسا', 'paris', 'france', 'champs', 'إيفل', 'eiffel'],
    defaultFlightPriceDZD: 54000,
    defaultHotelPerNightDZD: 42000,
    typicalDurationDays: 6,
    defaultAirline: 'Air Algérie / Air France (ALG - CDG)',
    defaultHotel: 'Hôtel Plaza Athénée / Pullman Paris Tour Eiffel',
    highlights: [
      { titleAr: 'برج إيفل ونهر السين', titleEn: 'Eiffel Tower & Seine Cruise', descAr: 'صعود القمة مع عشاء رومانسي فاخر على متن قارب السين', descEn: 'Summit access and romantic dinner cruise on River Seine', icon: '🗼' },
      { titleAr: 'متحف اللوفر وقصر فرساي', titleEn: 'Louvre & Versailles Palace', descAr: 'تذاكر VIP بدون انتظار للتحف الفنية وحدائق فرساي الملكية', descEn: 'Skip-the-line VIP tickets to Louvre masterpieces and Versailles', icon: '🎨' },
      { titleAr: 'شارع الشانزليزيه ومونمارتر', titleEn: 'Champs-Élysées & Montmartre', descAr: 'تسوق فاخر واكتشاف أزقة الفنانين وكنيسة الساكري كور', descEn: 'Haute couture shopping and artistic Montmartre streets', icon: '🥐' },
    ],
    visaSummaryAr: 'تأشيرة شنغن السياحية (VFS Global) مع ملف متكامل وحجز طيران وفندق مؤكدين من Tourism By Taki.',
    visaSummaryEn: 'Schengen tourist visa file preparation and appointment support via Tourism By Taki.',
  },
  {
    key: 'dubai',
    nameAr: 'دبي (Dubai)',
    nameFr: 'Dubaï',
    nameEn: 'Dubai',
    countryAr: 'الإمارات العربية المتحدة',
    countryFr: 'Émirats Arabes Unis',
    countryEn: 'United Arab Emirates',
    keywords: ['دبي', 'الإمارات', 'الامارات', 'dubai', 'uae', 'emirates', 'burj'],
    defaultFlightPriceDZD: 115000,
    defaultHotelPerNightDZD: 45000,
    typicalDurationDays: 6,
    defaultAirline: 'Emirates (طيران الإمارات مباشر ALG - DXB)',
    defaultHotel: 'Atlantis The Palm / Address Downtown',
    highlights: [
      { titleAr: 'قمة برج خليفة ونافورة دبي', titleEn: 'Burj Khalifa & Dubai Fountain', descAr: 'إطلالة من الطابق 148 وعرض النوافير الراقصة الفاتن', descEn: '148th floor sky observatory and evening dancing fountains', icon: '🏙️' },
      { titleAr: 'سفاري الصحراء VIP والتخييم الفاخر', titleEn: 'VIP Desert Safari', descAr: 'ركوب الكثبان بالدفع الرباعي وعشاء مشاوي تحت النجوم', descEn: 'Dune bashing, camel ride and premium BBQ under the stars', icon: '🐪' },
      { titleAr: 'حديقة الملاهي المائية أتلانتس', titleEn: 'Aquaventure & Palm Jumeirah', descAr: 'يوم مغامرات مائية ممتعة وتجربة حوض الأسماك الضخم', descEn: 'Thrill waterpark and Lost Chambers aquarium experience', icon: '🌊' },
    ],
    visaSummaryAr: 'تأشيرة إلكترونية سياحية لدولة الإمارات لمدة 30 أو 60 يوماً تصدر في غضون 24-48 ساعة.',
    visaSummaryEn: 'UAE 30/60-day tourist eVisa processed smoothly within 24-48 hours.',
  },
  {
    key: 'maldives',
    nameAr: 'المالديف (Maldives)',
    nameFr: 'Maldives',
    nameEn: 'Maldives',
    countryAr: 'جزر المالديف',
    countryFr: 'Maldives',
    countryEn: 'Maldives',
    keywords: ['مالديف', 'المالديف', 'maldives', 'overwater', 'جزيرة', 'شاطئ'],
    defaultFlightPriceDZD: 145000,
    defaultHotelPerNightDZD: 85000,
    typicalDurationDays: 6,
    defaultAirline: 'Qatar Airways (ALG - DOH - MLE)',
    defaultHotel: 'Anantara Dhigu Maldives Resort (فيلا فوق الماء)',
    highlights: [
      { titleAr: 'فيلا عائمة فوق المحيط الفيروزي', titleEn: 'Overwater Villa Living', descAr: 'إقامة فاخرة مع مسبح خاص ودرج مباشر للمياه الفيروزية', descEn: 'Private plunge pool with direct crystal lagoon access', icon: '🏖️' },
      { titleAr: 'غوص ورؤية السلاحف وشعب المرجان', titleEn: 'Snorkeling with Sea Turtles', descAr: 'رحلة بحرية خاصة لمشاهدة الدلافين وسلاحف البحر المرجانية', descEn: 'Boat excursion observing wild dolphins and coral reefs', icon: '🤿' },
      { titleAr: 'عشاء شاطئي على ضوء الشموع', titleEn: 'Candlelit Sandbank Dining', descAr: 'تجربة طعام حصرية لشخصين على لسان رملي منعزل في المحيط', descEn: 'Intimate sandbank private dinner under constellations', icon: '🕯️' },
    ],
    visaSummaryAr: 'تأشيرة مجانية تلقائية عند الوصول لمدة 30 يوماً للمواطنين الجزائريين مع حجز فندقي مؤكد.',
    visaSummaryEn: 'Free 30-day visa on arrival granted for Algerian passport holders with confirmed booking.',
  },
  {
    key: 'rome',
    nameAr: 'روما (Rome)',
    nameFr: 'Rome',
    nameEn: 'Rome',
    countryAr: 'إيطاليا',
    countryFr: 'Italie',
    countryEn: 'Italy',
    keywords: ['روما', 'إيطاليا', 'ايطاليا', 'rome', 'italy', 'florence', 'colosseum'],
    defaultFlightPriceDZD: 58000,
    defaultHotelPerNightDZD: 34000,
    typicalDurationDays: 5,
    defaultAirline: 'ITA Airways / Air Algérie (ALG - FCO)',
    defaultHotel: 'Hotel Splendide Royal Roma',
    highlights: [
      { titleAr: 'الكولوسيوم والمنتدى الروماني', titleEn: 'Colosseum & Roman Forum', descAr: 'جولة أثرية استثنائية لميدان المصارعين القديم', descEn: 'Gladiator arena and ancient empire landmarks tour', icon: '🏛️' },
      { titleAr: 'نافورة تريفي والفاتيكان', titleEn: 'Trevi Fountain & Vatican', descAr: 'إلقاء عملة الحظ وزيارة كنيسة القديس بطرس ومتاحف الفاتيكان', descEn: 'Coin toss tradition and Sistine Chapel masterpieces', icon: '⛲' },
    ],
    visaSummaryAr: 'تأشيرة شنغن إيطاليا عبر VFS Global مع ملف متكامل ودعم الموعد.',
    visaSummaryEn: 'Italian Schengen visa processing with complete file preparation.',
  },
  {
    key: 'kuala_lumpur',
    nameAr: 'كوالالمبور وجزيرة بينانج (ماليزيا)',
    nameFr: 'Kuala Lumpur & Penang (Malaisie)',
    nameEn: 'Kuala Lumpur & Penang (Malaysia)',
    countryAr: 'ماليزيا',
    countryFr: 'Malaisie',
    countryEn: 'Malaysia',
    keywords: ['ماليزيا', 'كوالالمبور', 'بينانج', 'لنكاوي', 'malaysia', 'kuala lumpur', 'penang'],
    defaultFlightPriceDZD: 135000,
    defaultHotelPerNightDZD: 22000,
    typicalDurationDays: 10,
    defaultAirline: 'Qatar Airways / Emirates (ALG - KUL)',
    defaultHotel: 'Mandarin Oriental Kuala Lumpur + Resort',
    highlights: [
      { titleAr: 'برجا بتروناس التوأم ومغارة باتو', titleEn: 'Petronas Towers & Batu Caves', descAr: 'إطلالة من الجسر المعلق وزيارة المعابد المنحوتة في الصخر', descEn: 'Skybridge observatory and iconic rainbow staircase caves', icon: '🏙️' },
      { titleAr: 'استجمام شواطئ جزيرة لنكاوي', titleEn: 'Langkawi Island Paradise', descAr: 'التلفريك البانورامي وجولات القوارب بين غابات المانغروف', descEn: 'Cable car skybridge and mangrove boat eco-safari', icon: '🌴' },
    ],
    visaSummaryAr: 'دخول بدون تأشيرة (إعفاء كامل لمدة 90 يوماً) لحاملي جواز السفر الجزائري.',
    visaSummaryEn: 'Visa-free entry for up to 90 days for Algerian citizens.',
  },
];

/**
 * Intelligent parser extracting destination, duration/dates, traveler count, and budget
 * from natural language text in Arabic, French, or English.
 */
export function parseTravelRequest(input: string, preferredLang: Language = 'ar'): ParsedTravelRequest {
  const cleanInput = (input || '').trim();
  const lower = cleanInput.toLowerCase();
  const matchedKeywords: string[] = [];

  // 1. Destination Extraction
  let matchedDestination = DESTINATIONS[0]; // fallback Istanbul
  let destConfidence = 40;

  for (const dest of DESTINATIONS) {
    for (const kw of dest.keywords) {
      if (lower.includes(kw.toLowerCase())) {
        matchedDestination = dest;
        destConfidence = 95;
        matchedKeywords.push(kw);
        break;
      }
    }
    if (destConfidence >= 90) break;
  }

  // 2. Duration / Dates Extraction
  let durationDays = matchedDestination.typicalDurationDays;
  let datesText = preferredLang === 'ar' ? `${durationDays} أيام` : `${durationDays} days`;

  // Explicit number of days pattern: "7 أيام", "10 days", "5 jours", "لمدة أسبوع", "أسبوعين"
  const daysRegex = /(\d+)\s*(أيام|يوم|ايام|days|day|jours|jour)/i;
  const daysMatch = lower.match(daysRegex);

  if (daysMatch) {
    const parsedDays = parseInt(daysMatch[1], 10);
    if (!isNaN(parsedDays) && parsedDays > 0 && parsedDays <= 60) {
      durationDays = parsedDays;
      datesText = preferredLang === 'ar' ? `${parsedDays} أيام` : `${parsedDays} days`;
      matchedKeywords.push(daysMatch[0]);
    }
  } else if (lower.includes('عطلة نهاية الأسبوع') || lower.includes('weekend') || lower.includes('ويكند')) {
    durationDays = 3;
    datesText = preferredLang === 'ar' ? '3 أيام (عطلة نهاية الأسبوع)' : '3 days (Weekend getaway)';
    matchedKeywords.push('weekend');
  } else if (lower.includes('أسبوعين') || lower.includes('اسبوعين') || lower.includes('2 weeks') || lower.includes('2 semaines')) {
    durationDays = 14;
    datesText = preferredLang === 'ar' ? '14 يوماً (أسبوعين)' : '14 days (2 weeks)';
    matchedKeywords.push('2 weeks');
  } else if (lower.includes('أسبوع') || lower.includes('اسبوع') || /\bweeks?\b/i.test(lower) || lower.includes('semaine')) {
    durationDays = 7;
    datesText = preferredLang === 'ar' ? '7 أيام (أسبوع)' : '7 days (1 week)';
    matchedKeywords.push('1 week');
  } else if (lower.includes('شهر') || /\bmonths?\b/i.test(lower) || lower.includes('mois')) {
    durationDays = 30;
    datesText = preferredLang === 'ar' ? '30 يوماً (شهر كامل)' : '30 days (1 month)';
    matchedKeywords.push('month');
  }

  // 3. Travelers Extraction
  let travelersCount = 2; // Default realistic standard
  let travelersLabel = preferredLang === 'ar' ? 'شخصين (مسافران)' : '2 Travelers (Couple/Duo)';

  const travelersRegex = /(\d+)\s*(أشخاص|اشخاص|مسافرين|مسافر|أفراد|افراد|شخص|travelers|traveler|persons|person|adults|adult|personnes)/i;
  const travelersMatch = lower.match(travelersRegex);

  if (travelersMatch) {
    const parsedCount = parseInt(travelersMatch[1], 10);
    if (!isNaN(parsedCount) && parsedCount > 0 && parsedCount <= 20) {
      travelersCount = parsedCount;
      travelersLabel = preferredLang === 'ar' ? `${parsedCount} مسافرين` : `${parsedCount} Travelers`;
      matchedKeywords.push(travelersMatch[0]);
    }
  } else if (lower.includes('شخصين') || lower.includes('زوجين') || lower.includes('couple') || lower.includes('two')) {
    travelersCount = 2;
    travelersLabel = preferredLang === 'ar' ? 'شخصين (زوجين)' : '2 Travelers (Couple)';
    matchedKeywords.push('couple');
  } else if (lower.includes('شخص واحد') || lower.includes('لوحدي') || lower.includes('بمفردي') || lower.includes('solo') || lower.includes('seul')) {
    travelersCount = 1;
    travelersLabel = preferredLang === 'ar' ? 'مسافر فردي (شخص واحد)' : 'Solo Traveler (1 person)';
    matchedKeywords.push('solo');
  } else if (lower.includes('عائلة 4') || lower.includes('أنا وزوجتي وطفلين') || lower.includes('family of 4')) {
    travelersCount = 4;
    travelersLabel = preferredLang === 'ar' ? 'عائلة (4 أشخاص)' : 'Family (4 members)';
    matchedKeywords.push('family 4');
  } else if (lower.includes('عائلة') || lower.includes('family') || lower.includes('famille')) {
    travelersCount = 4;
    travelersLabel = preferredLang === 'ar' ? 'رحلة عائلية (4 مسافرين)' : 'Family Trip (4 travelers)';
    matchedKeywords.push('family');
  }

  // 4. Budget Extraction
  let budgetSpecified = false;
  let budgetTier: 'economy' | 'moderate' | 'luxury' | 'vip' = 'luxury';

  // Check currency figures: "250000", "250,000", "30 مليون", "1500 EUR", "$2000"
  let budgetEstimatedDZD = 0;

  // Millions DZD colloquial ("30 مليون", "50 مليون")
  const millionMatch = cleanInput.match(/(\d+)\s*(مليون|ملايين)/);
  if (millionMatch) {
    const millions = parseFloat(millionMatch[1]);
    if (!isNaN(millions)) {
      budgetEstimatedDZD = millions * 10000; // in Algerian centimes to DZD (1 million centimes = 10,000 DZD)
      budgetSpecified = true;
      matchedKeywords.push(millionMatch[0]);
    }
  }

  // Direct number with DZD or DA or دج
  if (!budgetSpecified) {
    const dzdMatch = cleanInput.match(/([\d,\.\s]+)\s*(dzd|da|دج|دينار)/i);
    if (dzdMatch) {
      const numStr = dzdMatch[1].replace(/[\s,]/g, '');
      const parsed = parseFloat(numStr);
      if (!isNaN(parsed) && parsed >= 10000) {
        budgetEstimatedDZD = parsed;
        budgetSpecified = true;
        matchedKeywords.push(dzdMatch[0]);
      }
    }
  }

  // EUR or USD figures
  if (!budgetSpecified) {
    const euroMatch = cleanInput.match(/([\d,\.\s]+)\s*(eur|euro|euros|€)/i);
    const usdMatch = cleanInput.match(/([\d,\.\s]+)\s*(usd|dollar|dollars|\$)/i);
    if (euroMatch) {
      const parsed = parseFloat(euroMatch[1].replace(/[\s,]/g, ''));
      if (!isNaN(parsed) && parsed > 0) {
        budgetEstimatedDZD = Math.round(parsed * 242); // standard rate
        budgetSpecified = true;
        matchedKeywords.push(euroMatch[0]);
      }
    } else if (usdMatch) {
      const parsed = parseFloat(usdMatch[1].replace(/[\s,]/g, ''));
      if (!isNaN(parsed) && parsed > 0) {
        budgetEstimatedDZD = Math.round(parsed * 228);
        budgetSpecified = true;
        matchedKeywords.push(usdMatch[0]);
      }
    }
  }

  // Raw large digits without currency label
  if (!budgetSpecified) {
    const rawNumberMatch = cleanInput.match(/\b(\d{5,7})\b/);
    if (rawNumberMatch) {
      const parsed = parseInt(rawNumberMatch[1], 10);
      if (parsed >= 30000 && parsed <= 5000000) {
        budgetEstimatedDZD = parsed;
        budgetSpecified = true;
        matchedKeywords.push(rawNumberMatch[0]);
      }
    }
  }

  // Budget Tier Keywords
  if (lower.includes('اقتصادي') || lower.includes('رخيص') || lower.includes('محدود') || lower.includes('economy') || lower.includes('budget') || lower.includes('économique')) {
    budgetTier = 'economy';
    matchedKeywords.push('economy');
  } else if (lower.includes('vip') || lower.includes('ملكي') || lower.includes('فاخر جدا') || lower.includes('luxury') || lower.includes('palace')) {
    budgetTier = 'vip';
    matchedKeywords.push('vip');
  } else if (lower.includes('متوسط') || lower.includes('moderate') || lower.includes('standard')) {
    budgetTier = 'moderate';
    matchedKeywords.push('moderate');
  } else {
    budgetTier = 'luxury';
  }

  // If budget wasn't explicitly extracted, compute realistic estimate based on destination & travelers
  if (!budgetSpecified || budgetEstimatedDZD <= 0) {
    const tierMultiplier = budgetTier === 'economy' ? 0.75 : budgetTier === 'moderate' ? 0.95 : budgetTier === 'vip' ? 1.45 : 1.15;
    const flightsTotal = matchedDestination.defaultFlightPriceDZD * travelersCount;
    const hotelRooms = Math.ceil(travelersCount / 2);
    const hotelTotal = matchedDestination.defaultHotelPerNightDZD * durationDays * hotelRooms;
    const servicesAndTransfers = 45000 * travelersCount;

    budgetEstimatedDZD = Math.round((flightsTotal + hotelTotal + servicesAndTransfers) * tierMultiplier);
  }

  // Confidence Calculation
  let confidenceScore = 65;
  if (destConfidence >= 90) confidenceScore += 15;
  if (daysMatch || lower.includes('أسبوع') || lower.includes('week')) confidenceScore += 10;
  if (travelersMatch || lower.includes('شخصين') || lower.includes('couple')) confidenceScore += 5;
  if (budgetSpecified) confidenceScore += 5;
  confidenceScore = Math.min(98, confidenceScore);

  return {
    rawInput: cleanInput,
    destination: matchedDestination.nameAr,
    destinationCountry: matchedDestination.countryAr,
    destinationKey: matchedDestination.key,
    durationDays,
    datesText,
    travelersCount,
    travelersLabel,
    budgetEstimatedDZD,
    budgetTier,
    budgetSpecified,
    confidenceScore,
    matchedKeywords,
  };
}

/**
 * Generates an interactive, structured trip recommendation package based on the parsed request.
 */
export function generateTripSuggestion(parsed: ParsedTravelRequest, lang: Language = 'ar'): AITripSuggestion {
  const destInfo = DESTINATIONS.find(d => d.key === parsed.destinationKey) || DESTINATIONS[0];

  const hotelRooms = Math.ceil(parsed.travelersCount / 2);
  const tierMultiplier = parsed.budgetTier === 'economy' ? 0.8 : parsed.budgetTier === 'vip' ? 1.5 : 1.1;

  const flightPricePerPerson = Math.round(destInfo.defaultFlightPriceDZD * (parsed.budgetTier === 'vip' ? 1.8 : 1.0));
  const hotelPerNight = Math.round(destInfo.defaultHotelPerNightDZD * tierMultiplier);
  const totalHotelDZD = hotelPerNight * parsed.durationDays * hotelRooms;
  const totalFlightsDZD = flightPricePerPerson * parsed.travelersCount;
  const transferAndAssistanceDZD = 35000 * parsed.travelersCount;

  const totalCostDZD = parsed.budgetSpecified && parsed.budgetEstimatedDZD > 0
    ? parsed.budgetEstimatedDZD
    : totalFlightsDZD + totalHotelDZD + transferAndAssistanceDZD;

  const costPerPersonDZD = Math.round(totalCostDZD / Math.max(1, parsed.travelersCount));

  // Determine Title & Style
  const title = lang === 'ar'
    ? `باقة ${destInfo.nameAr} الحصرية (${parsed.durationDays} أيام)`
    : `${destInfo.nameEn} Exclusive Package (${parsed.durationDays} Days)`;

  const subtitle = lang === 'ar'
    ? `مخصصة لـ ${parsed.travelersLabel} — تشمل الطيران، الفندق الفاخر، والتنقلات المرافقة`
    : `Tailored for ${parsed.travelersLabel} — Flights, luxury hotel & VIP concierge included`;

  const tripStyle = parsed.budgetTier === 'vip'
    ? (lang === 'ar' ? 'فخامة ملكية لكبار الشخصيات (VIP Luxury)' : 'Royal VIP Luxury')
    : parsed.budgetTier === 'economy'
    ? (lang === 'ar' ? 'اقتصادي مميز ذكي (Smart Saver)' : 'Smart Saver Value')
    : (lang === 'ar' ? 'استجمام وسياحة متكاملة (Balanced Explorer)' : 'Balanced Explorer');

  const timelineHighlights = destInfo.highlights.slice(0, Math.min(parsed.durationDays, 4)).map((h, idx) => ({
    day: idx + 1,
    title: lang === 'ar' ? h.titleAr : h.titleEn,
    description: lang === 'ar' ? h.descAr : h.descEn,
    icon: h.icon,
  }));

  const includedServices = lang === 'ar'
    ? [
        `تذاكر طيران ذهاب وعودة مؤكدة (${destInfo.defaultAirline}) مع وزن أمتعة 30 كغ`,
        `إقامة ${parsed.durationDays} ليالٍ في ${destInfo.defaultHotel} مع إفطار بوفيه يومي`,
        'استقبال وتوديع VIP من وإلى المطار بسيارة مجهزة خاصة',
        'شريحة اتصال وإنترنت سياحية 5G مجاناً فور الوصول',
        'تأمين سفر صحي دولي سارٍ طوال فترة الرحلة',
        'دعم وإرشاد مستمر 24/7 من فريق وكالة Tourism By Taki',
      ]
    : [
        `Round-trip flights with ${destInfo.defaultAirline} (30kg checked luggage)`,
        `${parsed.durationDays} nights stay at ${destInfo.defaultHotel} with daily breakfast`,
        'Private VIP airport transfer in Mercedes luxury van',
        'Free local 5G traveler eSIM activated upon arrival',
        'Comprehensive international travel & health insurance',
        '24/7 dedicated travel concierge assistance from Tourism By Taki',
      ];

  const smartTip = lang === 'ar'
    ? `نصيحة TAKI-Bot: السفر لـ ${destInfo.countryAr} خلال هذا الموسم يمنحك طقساً معتدلاً وأسعار طيران ممتازة إذا قمت بتأكيد الحجز مبكراً.`
    : `TAKI-Bot Tip: Visiting ${destInfo.countryEn} this period offers pleasant weather and great flight rates with early booking confirmation.`;

  return {
    id: `plan-${destInfo.key}-${Date.now().toString(36)}`,
    title,
    subtitle,
    destination: destInfo.nameAr,
    destinationCountry: destInfo.countryAr,
    durationDays: parsed.durationDays,
    travelersCount: parsed.travelersCount,
    totalCostDZD,
    costPerPersonDZD,
    budgetTier: parsed.budgetTier,
    tripStyle,
    flight: {
      airline: destInfo.defaultAirline,
      flightNumber: 'TK 652',
      route: 'ALG ✈️ ' + destInfo.key.toUpperCase(),
      cabin: parsed.budgetTier === 'vip' ? 'Business Class' : 'Economy Comfort',
      priceDZD: flightPricePerPerson,
      duration: '4h 15m',
      direct: true,
    },
    hotel: {
      name: destInfo.defaultHotel,
      stars: 5,
      roomType: 'Deluxe Room with City / Sea View',
      pricePerNightDZD: hotelPerNight,
      totalHotelDZD,
      location: destInfo.nameAr,
      amenities: ['Free High-Speed Wi-Fi', 'Luxury Spa & Turkish Bath', 'Gourmet Breakfast', 'Infinity Pool'],
    },
    timelineHighlights,
    includedServices,
    smartTip,
    visaRequirementsSummary: lang === 'ar' ? destInfo.visaSummaryAr : destInfo.visaSummaryEn,
  };
}

/**
 * Pre-defined prompt ideas for quick user exploration.
 */
export function getSamplePrompts(lang: Language = 'ar'): string[] {
  if (lang === 'ar') {
    return [
      'أريد رحلة إلى إسطنبول لمدة أسبوع لشخصين بميزانية 250,000 دج',
      'عمرة لشخصين في شهر رمضان المبارك مع فندق قريب من الحرم',
      'عطلة فاخرة في دبي لمدة 6 أيام لعائلة من 4 أفراد بميزانية ممتازة',
      'رحلة شهر عسل في المالديف 6 ليالٍ في فيلا فوق الماء لشخصين',
      'جولة استكشافية في باريس 5 أيام مع تذاكر اللوفر وبرج إيفل',
    ];
  } else if (lang === 'fr') {
    return [
      'Voyage à Istanbul pour 7 jours, 2 personnes avec un budget de 250 000 DZD',
      'Séjour Omra pour 2 personnes avec hôtel proche du Haram',
      'Vacances VIP à Dubaï pendant 6 jours pour une famille de 4 personnes',
      'Lune de miel aux Maldives 6 nuits en villa sur pilotis pour 2 personnes',
      'Circuit découverte à Paris 5 jours avec visite de la Tour Eiffel',
    ];
  } else {
    return [
      'Trip to Istanbul for 7 days, 2 persons, budget around 250,000 DZD',
      'Umrah pilgrimage for 2 persons with 5-star hotel near Haram',
      'Luxury family vacation in Dubai for 6 days (4 travelers)',
      'Honeymoon in Maldives 6 nights overwater villa for couple',
      'Explore Paris 5 days package including Louvre and Eiffel Tower',
    ];
  }
}
