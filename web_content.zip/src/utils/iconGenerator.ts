import { AppIconConfig } from '../types/apk';

export interface MipmapResult {
  density: string;
  size: number;
  dataUrl: string;
  blob: Blob;
  uint8Array: Uint8Array;
}

const ANDROID_DENSITIES = [
  { name: 'mipmap-mdpi', size: 48 },
  { name: 'mipmap-hdpi', size: 72 },
  { name: 'mipmap-xhdpi', size: 96 },
  { name: 'mipmap-xxhdpi', size: 144 },
  { name: 'mipmap-xxxhdpi', size: 192 },
  { name: 'playstore-icon', size: 512 },
];

/**
 * Draw the configured icon onto a canvas of arbitrary size.
 */
export async function renderIconToCanvas(
  config: AppIconConfig,
  targetSize: number = 512
): Promise<HTMLCanvasElement> {
  const canvas = document.createElement('canvas');
  canvas.width = targetSize;
  canvas.height = targetSize;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context not supported');

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // Apply shape clipping
  ctx.save();
  drawShapePath(ctx, config.shape, targetSize);
  ctx.clip();

  if (config.type === 'upload' && config.uploadedImage) {
    // Render uploaded image
    await new Promise<void>((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        // Center crop / cover image
        const scale = Math.max(targetSize / img.width, targetSize / img.height);
        const x = (targetSize - img.width * scale) / 2;
        const y = (targetSize - img.height * scale) / 2;
        ctx.drawImage(img, x, y, img.width * scale, img.height * scale);
        resolve();
      };
      img.onerror = () => {
        drawFallbackGeneratedIcon(ctx, config, targetSize);
        resolve();
      };
      img.src = config.uploadedImage!;
    });
  } else {
    drawFallbackGeneratedIcon(ctx, config, targetSize);
  }

  // Draw optional badge in bottom corner
  if (config.badgeText && config.badgeText.trim() !== '') {
    ctx.restore();
    ctx.save();
    const badgeSize = targetSize * 0.32;
    const badgeX = targetSize - badgeSize - targetSize * 0.04;
    const badgeY = targetSize - badgeSize - targetSize * 0.04;

    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(badgeX + badgeSize / 2, badgeY + badgeSize / 2, badgeSize / 2, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = Math.max(2, targetSize * 0.03);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${Math.round(badgeSize * 0.55)}px -apple-system, system-ui, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(config.badgeText.slice(0, 3).toUpperCase(), badgeX + badgeSize / 2, badgeY + badgeSize / 2 + 1);
  }

  ctx.restore();
  return canvas;
}

function drawShapePath(ctx: CanvasRenderingContext2D, shape: AppIconConfig['shape'], size: number) {
  ctx.beginPath();
  const radius = size * 0.22; // Squircle / rounded radius

  if (shape === 'circle') {
    ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
  } else if (shape === 'squircle' || shape === 'rounded') {
    const r = shape === 'squircle' ? size * 0.25 : size * 0.18;
    ctx.roundRect(0, 0, size, size, r);
  } else {
    // Square
    ctx.rect(0, 0, size, size);
  }
}

function drawFallbackGeneratedIcon(
  ctx: CanvasRenderingContext2D,
  config: AppIconConfig,
  size: number
) {
  // Background fill or gradient
  if (config.bgGradient && config.bgGradient !== 'none') {
    const grad = ctx.createLinearGradient(0, 0, size, size);
    if (config.bgGradient === 'ocean') {
      grad.addColorStop(0, '#0284c7');
      grad.addColorStop(1, '#0f172a');
    } else if (config.bgGradient === 'sunset') {
      grad.addColorStop(0, '#f97316');
      grad.addColorStop(1, '#db2777');
    } else if (config.bgGradient === 'emerald') {
      grad.addColorStop(0, '#10b981');
      grad.addColorStop(1, '#064e3b');
    } else if (config.bgGradient === 'violet') {
      grad.addColorStop(0, '#8b5cf6');
      grad.addColorStop(1, '#3b0764');
    } else if (config.bgGradient === 'cyber') {
      grad.addColorStop(0, '#06b6d4');
      grad.addColorStop(1, '#3b82f6');
    } else {
      grad.addColorStop(0, config.bgColor || '#2563eb');
      grad.addColorStop(1, '#1e293b');
    }
    ctx.fillStyle = grad;
  } else {
    ctx.fillStyle = config.bgColor || '#2563eb';
  }
  ctx.fillRect(0, 0, size, size);

  // Subtle interior ambient lighting
  const innerGlow = ctx.createRadialGradient(size * 0.5, size * 0.2, 0, size * 0.5, size * 0.5, size * 0.8);
  innerGlow.addColorStop(0, 'rgba(255, 255, 255, 0.18)');
  innerGlow.addColorStop(1, 'rgba(0, 0, 0, 0.2)');
  ctx.fillStyle = innerGlow;
  ctx.fillRect(0, 0, size, size);

  // Symbol or monogram
  const symbol = config.symbol || 'A';
  ctx.fillStyle = config.symbolColor || '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  const fontSize = Math.round((size * (config.fontSize || 50)) / 100);
  ctx.font = `800 ${fontSize}px "Plus Jakarta Sans", system-ui, -apple-system, sans-serif`;

  // Draw drop shadow for crisp readability
  ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
  ctx.shadowBlur = Math.round(size * 0.05);
  ctx.shadowOffsetY = Math.round(size * 0.03);

  ctx.fillText(symbol.slice(0, 3).toUpperCase(), size / 2, size / 2 + size * 0.03);

  // Clear shadow
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;
}

/**
 * Generate all Android mipmap images.
 */
export async function generateAllMipmaps(config: AppIconConfig): Promise<MipmapResult[]> {
  const results: MipmapResult[] = [];

  for (const item of ANDROID_DENSITIES) {
    const canvas = await renderIconToCanvas(config, item.size);
    const dataUrl = canvas.toDataURL('image/png');
    
    // Convert to Blob and Uint8Array
    const blob = await new Promise<Blob>((resolve) => {
      canvas.toBlob((b) => resolve(b || new Blob()), 'image/png');
    });

    const arrayBuffer = await blob.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);

    results.push({
      density: item.name,
      size: item.size,
      dataUrl,
      blob,
      uint8Array,
    });
  }

  return results;
}
