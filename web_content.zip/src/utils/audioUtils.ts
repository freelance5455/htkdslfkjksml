/**
 * Audio helpers for Gemini Live API:
 * - Downsample browser microphone Float32 samples (e.g. 44.1kHz / 48kHz) -> exact 16kHz PCM16 LE base64
 * - Compute mic input RMS level for visual feedback
 * - Decode base64 PCM16 LE (24kHz) -> AudioBuffer for gapless playback
 */

export function downsampleTo16kPcm16Base64(
  float32: Float32Array,
  sourceSampleRate: number
): string {
  const targetRate = 16000;
  let samples = float32;

  if (sourceSampleRate && sourceSampleRate !== targetRate) {
    const ratio = sourceSampleRate / targetRate;
    const outLength = Math.max(1, Math.floor(float32.length / ratio));
    const resampled = new Float32Array(outLength);
    for (let i = 0; i < outLength; i++) {
      const srcIndex = i * ratio;
      const lower = Math.floor(srcIndex);
      const upper = Math.min(float32.length - 1, lower + 1);
      const weight = srcIndex - lower;
      resampled[i] = float32[lower] * (1 - weight) + float32[upper] * weight;
    }
    samples = resampled;
  }

  const pcm16 = new Int16Array(samples.length);
  for (let i = 0; i < samples.length; i++) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    pcm16[i] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff;
  }

  const bytes = new Uint8Array(pcm16.buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

export function computeRmsLevel(float32: Float32Array): number {
  let sum = 0;
  for (let i = 0; i < float32.length; i++) {
    sum += float32[i] * float32[i];
  }
  return Math.min(1, Math.sqrt(sum / Math.max(1, float32.length)) * 5);
}

export function pcm16Base64ToAudioBuffer(
  ctx: AudioContext,
  base64: string,
  sampleRate = 24000
): AudioBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const view = new DataView(bytes.buffer);
  const frameCount = Math.floor(bytes.byteLength / 2);
  const audioBuffer = ctx.createBuffer(1, frameCount, sampleRate);
  const channel = audioBuffer.getChannelData(0);

  for (let i = 0; i < frameCount; i++) {
    const sample = view.getInt16(i * 2, true);
    channel[i] = sample < 0 ? sample / 0x8000 : sample / 0x7fff;
  }
  return audioBuffer;
}
