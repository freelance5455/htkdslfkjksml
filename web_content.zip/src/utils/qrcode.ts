import QRCode from 'qrcode';

export interface QRCodeOptions {
  width?: number;
  margin?: number;
  color?: {
    dark?: string;
    light?: string;
  };
  errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
}

// In-memory cache for generated QR code data URLs (ensures zero recomputation & instant offline availability)
const qrCodeCache = new Map<string, string>();

/**
 * Generates a PNG Data URL representing the scannable QR code for the given text data.
 */
export async function generateQRCodeDataURL(
  data: string,
  options: QRCodeOptions = {}
): Promise<string> {
  if (!data || !data.trim()) {
    throw new Error('QR Code data must not be empty');
  }

  const {
    width = 300,
    margin = 2,
    color = { dark: '#000000', light: '#ffffff' },
    errorCorrectionLevel = 'M',
  } = options;

  const cacheKey = `${data}_${width}_${margin}_${color.dark}_${color.light}_${errorCorrectionLevel}`;
  const cached = qrCodeCache.get(cacheKey);
  if (cached) {
    return cached;
  }

  try {
    const dataUrl = await QRCode.toDataURL(data, {
      width,
      margin,
      color: {
        dark: color.dark || '#000000',
        light: color.light || '#ffffff',
      },
      errorCorrectionLevel,
    });

    qrCodeCache.set(cacheKey, dataUrl);
    return dataUrl;
  } catch (error) {
    console.error('Failed to generate QR code data URL:', error);
    throw error;
  }
}

/**
 * Generates an SVG string representation of the QR code.
 */
export async function generateQRCodeSVG(
  data: string,
  options: QRCodeOptions = {}
): Promise<string> {
  if (!data || !data.trim()) {
    throw new Error('QR Code data must not be empty');
  }

  const {
    width = 300,
    margin = 2,
    color = { dark: '#000000', light: '#ffffff' },
    errorCorrectionLevel = 'M',
  } = options;

  try {
    return await QRCode.toString(data, {
      type: 'svg',
      width,
      margin,
      color: {
        dark: color.dark || '#000000',
        light: color.light || '#ffffff',
      },
      errorCorrectionLevel,
    });
  } catch (error) {
    console.error('Failed to generate QR code SVG:', error);
    throw error;
  }
}

/**
 * Validates if the string has sufficient content for a travel wallet QR code.
 */
export function isValidQRCodeData(data: string | undefined | null): boolean {
  if (!data) return false;
  return data.trim().length > 3;
}

/**
 * Clears the QR code cache (useful for testing or memory release).
 */
export function clearQRCodeCache(): void {
  qrCodeCache.clear();
}
