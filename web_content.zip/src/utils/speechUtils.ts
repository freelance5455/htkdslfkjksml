// Speech synthesis and recognition utilities for AB Voice Bot

export interface SpeechRecognitionHandlers {
  onStart?: () => void;
  onInterimResult?: (transcript: string) => void;
  onFinalResult?: (transcript: string) => void;
  onError?: (error: string) => void;
  onEnd?: () => void;
}

export class SpeechManager {
  private recognition: any = null;
  private isListening = false;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  constructor() {
    this.initRecognition();
  }

  private initRecognition() {
    if (typeof window === 'undefined') return;
    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognitionClass) {
      try {
        this.recognition = new SpeechRecognitionClass();
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.maxAlternatives = 1;
        this.recognition.lang = 'ur-PK';
      } catch (err) {
        console.warn('SpeechRecognition init error:', err);
      }
    }
  }

  public isRecognitionSupported(): boolean {
    return Boolean(
      typeof window !== 'undefined' &&
        ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)
    );
  }

  public isTTSSupported(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }

  public startListening(
    handlers: SpeechRecognitionHandlers,
    lang: string = 'ur-PK'
  ): boolean {
    if (!this.recognition) {
      this.initRecognition();
    }

    if (!this.recognition) {
      handlers.onError?.('براؤزر میں مائیکروفون اسپیچ ریکگنیشن سپورٹ نہیں ہے۔');
      return false;
    }

    if (this.isListening) {
      try {
        this.recognition.abort();
      } catch (e) {}
    }

    this.stopSpeaking();

    try {
      this.recognition.lang = lang;

      this.recognition.onstart = () => {
        this.isListening = true;
        handlers.onStart?.();
      };

      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const item = event.results[i];
          if (item.isFinal) {
            finalTranscript += item[0].transcript;
          } else {
            interimTranscript += item[0].transcript;
          }
        }

        if (interimTranscript && handlers.onInterimResult) {
          handlers.onInterimResult(interimTranscript);
        }

        if (finalTranscript && handlers.onFinalResult) {
          handlers.onFinalResult(finalTranscript.trim());
        }
      };

      this.recognition.onerror = (event: any) => {
        this.isListening = false;
        let errMsg = 'مائیکروفون ایرر';
        if (event.error === 'not-allowed') {
          errMsg = 'مائیکروفون کی اجازت درکار ہے (Permission Denied)';
        } else if (event.error === 'no-speech') {
          errMsg = 'کوئی آواز نہیں سنی گئی۔ دوبارہ بولیں';
        } else if (event.error === 'network') {
          errMsg = 'نیٹ ورک کا مسئلہ ہے۔';
        }
        handlers.onError?.(errMsg);
      };

      this.recognition.onend = () => {
        this.isListening = false;
        handlers.onEnd?.();
      };

      this.recognition.start();
      return true;
    } catch (err: any) {
      this.isListening = false;
      handlers.onError?.(err?.message || 'مائیک اسٹارٹ نہ ہو سکا');
      return false;
    }
  }

  public stopListening() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (e) {}
      this.isListening = false;
    }
  }

  public speak(
    text: string,
    options: {
      rate?: number;
      pitch?: number;
      gender?: 'Male' | 'Female';
      language?: 'Urdu' | 'English';
      onStart?: () => void;
      onEnd?: () => void;
      onError?: (err: any) => void;
    } = {}
  ) {
    if (!this.isTTSSupported()) {
      options.onError?.('Text-to-speech not supported');
      return;
    }

    this.stopSpeaking();

    try {
      const utterance = new SpeechSynthesisUtterance(text);
      this.currentUtterance = utterance;

      utterance.rate = options.rate ?? 1.0;
      
      // Default pitch tuning according to gender
      if (options.pitch) {
        utterance.pitch = options.pitch;
      } else {
        utterance.pitch = options.gender === 'Female' ? 1.2 : 0.95;
      }

      const isEnglish = options.language === 'English';
      const voices = window.speechSynthesis.getVoices();
      let selectedVoice: SpeechSynthesisVoice | undefined;

      if (isEnglish) {
        // Preferred English voices
        if (options.gender === 'Female') {
          selectedVoice = voices.find(
            (v) =>
              v.lang.toLowerCase().startsWith('en') &&
              (v.name.toLowerCase().includes('female') ||
                v.name.toLowerCase().includes('zira') ||
                v.name.toLowerCase().includes('samantha') ||
                v.name.toLowerCase().includes('karen') ||
                v.name.toLowerCase().includes('victoria'))
          );
        } else {
          selectedVoice = voices.find(
            (v) =>
              v.lang.toLowerCase().startsWith('en') &&
              (v.name.toLowerCase().includes('male') ||
                v.name.toLowerCase().includes('david') ||
                v.name.toLowerCase().includes('george') ||
                v.name.toLowerCase().includes('daniel') ||
                v.name.toLowerCase().includes('alex'))
          );
        }
        if (!selectedVoice) {
          selectedVoice = voices.find((v) => v.lang.toLowerCase().startsWith('en'));
        }
      } else {
        // Preferred Urdu / South Asian voices
        selectedVoice = voices.find(
          (v) =>
            v.lang.toLowerCase().startsWith('ur') ||
            v.name.toLowerCase().includes('urdu')
        );

        if (!selectedVoice) {
          selectedVoice = voices.find((v) => v.lang.toLowerCase().startsWith('hi'));
        }

        if (!selectedVoice) {
          if (options.gender === 'Female') {
            selectedVoice = voices.find((v) =>
              v.name.toLowerCase().includes('female') ||
              v.name.toLowerCase().includes('zira') ||
              v.name.toLowerCase().includes('samantha')
            );
          } else {
            selectedVoice = voices.find((v) =>
              v.name.toLowerCase().includes('male') ||
              v.name.toLowerCase().includes('david') ||
              v.name.toLowerCase().includes('george')
            );
          }
        }
      }

      if (selectedVoice) {
        utterance.voice = selectedVoice;
        utterance.lang = selectedVoice.lang;
      } else {
        utterance.lang = isEnglish ? 'en-US' : 'ur-PK';
      }

      utterance.onstart = () => {
        options.onStart?.();
      };

      utterance.onend = () => {
        this.currentUtterance = null;
        options.onEnd?.();
      };

      utterance.onerror = (e) => {
        this.currentUtterance = null;
        options.onError?.(e);
      };

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.error('Speech synthesis error:', e);
      options.onError?.(e);
    }
  }

  public stopSpeaking() {
    if (this.isTTSSupported()) {
      window.speechSynthesis.cancel();
      this.currentUtterance = null;
    }
  }
}

export const speechManager = new SpeechManager();
