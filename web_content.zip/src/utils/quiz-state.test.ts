import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateQuizScore, filterFlashcards } from './quiz-state.ts';
import type { QuizQuestion, Flashcard } from './quiz-state.ts';

test('evaluateQuizScore calculates correct percentage and mastery tier', () => {
  const questions: QuizQuestion[] = [
    {
      id: 'q1',
      question: 'What is 2+2?',
      options: ['3', '4', '5'],
      correctOptionIndex: 1,
      explanation: '2+2 is 4',
    },
    {
      id: 'q2',
      question: 'Capital of France?',
      options: ['Paris', 'Rome', 'Berlin'],
      correctOptionIndex: 0,
      explanation: 'Paris is the capital of France',
    },
  ];

  const answers = { q1: 1, q2: 0 };
  const res = evaluateQuizScore(answers, questions);
  assert.equal(res.total, 2);
  assert.equal(res.correct, 2);
  assert.equal(res.percentage, 100);
  assert.equal(res.feedbackTier, 'mastery');
});

test('evaluateQuizScore handles partial scores and empty questions', () => {
  const questions: QuizQuestion[] = [
    {
      id: 'q1',
      question: 'Q1',
      options: ['A', 'B'],
      correctOptionIndex: 0,
      explanation: 'Explanation',
    },
    {
      id: 'q2',
      question: 'Q2',
      options: ['A', 'B'],
      correctOptionIndex: 0,
      explanation: 'Explanation',
    },
  ];

  const partialAnswers = { q1: 0, q2: 1 };
  const partialRes = evaluateQuizScore(partialAnswers, questions);
  assert.equal(partialRes.correct, 1);
  assert.equal(partialRes.percentage, 50);
  assert.equal(partialRes.feedbackTier, 'review_needed');

  const emptyRes = evaluateQuizScore({}, []);
  assert.equal(emptyRes.total, 0);
  assert.equal(emptyRes.correct, 0);
  assert.equal(emptyRes.feedbackTier, 'beginning');
});

test('filterFlashcards correctly filters by front, back, or category', () => {
  const cards: Flashcard[] = [
    { id: '1', front: 'Photosynthesis', back: 'Process of plants converting light to energy', category: 'Biology' },
    { id: '2', front: 'Derivative', back: 'Rate of change of a function', category: 'Calculus' },
    { id: '3', front: 'Mitochondria', back: 'Powerhouse of the cell', category: 'Biology' },
  ];

  assert.equal(filterFlashcards(cards, '').length, 3);
  assert.equal(filterFlashcards(cards, 'calculus').length, 1);
  assert.equal(filterFlashcards(cards, 'biology').length, 2);
  assert.equal(filterFlashcards(cards, 'powerhouse').length, 1);
  assert.equal(filterFlashcards(cards, 'nonexistent').length, 0);
});
