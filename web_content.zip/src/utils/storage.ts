import type { PersistedSettings } from '../types';

export const STORE_KEY = 'vocab_cefr_android_v3';
const IDB_NAME = 'VocabCefrCustomDB';
const IDB_STORE = 'csvStore';
const MEDIA_DB_NAME = 'VocabCefrMediaDB';

export function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export const DEFAULT_UNSPLASH_ACCESS_KEY: string =
  ((import.meta as unknown as { env?: Record<string, string> }).env?.VITE_UNSPLASH_ACCESS_KEY ||
    'ofbUnj5e3vSjfGor04gqVKKkVBTUet-PqtFnRNqWPzI');

export function getDefaultSettings(): PersistedSettings {
  return {
    levelSize: 20,
    dailyGoal: 20,
    todayDate: todayStr(),
    todayCount: 0,
    theme: 'dark',
    uiLang: 'ar',
    sfx: true,
    autoSpeak: false,
    ttsRate: 0.92,
    mcqDir: 'en2ar',
    lastGame: 'missing',
    lastBand: 'A0',
    lastSubLevel: 0,
    xp: 0,
    streak: 0,
    bestStreak: 0,
    completed: {},
    mistakes: [],
    favorites: [],
    mastered: [],
    favoriteSentences: [],
    practicedSentences: [],
    srsCards: {},
    placementResult: null,
    listeningProgress: undefined,
    completedGrammarIds: [],
    savedWordNotes: [],
    wordMastery: {},
    onboardingCompleted: false,
    learningGoal: 'daily_chat',
    dailyPaceMinutes: 10,
    dailyPlanDate: todayStr(),
    dailyPlanSteps: {},
    dailySentencesCount: 0,
    studyHistory: {},
    streakFreezes: 1,
    lastFreezeWeek: '',
    lastActiveDate: '',
    wordleDailyDate: '',
    wordleDailyStatus: undefined,
    wordleDailyGuesses: undefined,
    bestBlitzScore: 0,
    bestMemoryMoves: 0,
    bestWordRainScore: 0,
    bestRocketStreak: 0,
    bestSentenceBlitzScore: 0,
    pixabayKey: '',
    unsplashKey: DEFAULT_UNSPLASH_ACCESS_KEY,
    backendUrl: '',
    usingCustom: false,
    customSourceName: '',
  };
}

export function loadPersistedSettings(): PersistedSettings {
  const defaults = getDefaultSettings();
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<PersistedSettings>;
    const td = todayStr();
    const isSamePlanDay = parsed.dailyPlanDate === td;
    const hasExistingProgress =
      (parsed.xp || 0) > 0 ||
      (Array.isArray(parsed.mastered) && parsed.mastered.length > 0) ||
      (parsed.completed && Object.keys(parsed.completed).length > 0);
    return {
      ...defaults,
      ...parsed,
      unsplashKey:
        typeof parsed.unsplashKey === 'string' && parsed.unsplashKey.trim().length > 0
          ? parsed.unsplashKey
          : defaults.unsplashKey,
      todayDate: td,
      todayCount: parsed.todayDate === td ? parsed.todayCount || 0 : 0,
      completed: parsed.completed && typeof parsed.completed === 'object' ? parsed.completed : {},
      mistakes: Array.isArray(parsed.mistakes) ? parsed.mistakes : [],
      favorites: Array.isArray(parsed.favorites) ? parsed.favorites : [],
      mastered: Array.isArray(parsed.mastered) ? parsed.mastered : [],
      favoriteSentences: Array.isArray(parsed.favoriteSentences) ? parsed.favoriteSentences : [],
      practicedSentences: Array.isArray(parsed.practicedSentences) ? parsed.practicedSentences : [],
      srsCards:
        parsed.srsCards && typeof parsed.srsCards === 'object' ? parsed.srsCards : {},
      listeningProgress:
        parsed.listeningProgress && typeof parsed.listeningProgress === 'object'
          ? parsed.listeningProgress
          : undefined,
      completedGrammarIds: Array.isArray(parsed.completedGrammarIds)
        ? parsed.completedGrammarIds.filter((x): x is string => typeof x === 'string')
        : [],
      savedWordNotes: Array.isArray(parsed.savedWordNotes) ? parsed.savedWordNotes : [],
      wordMastery:
        parsed.wordMastery && typeof parsed.wordMastery === 'object' ? parsed.wordMastery : {},
      onboardingCompleted:
        typeof parsed.onboardingCompleted === 'boolean'
          ? parsed.onboardingCompleted
          : hasExistingProgress,
      learningGoal:
        parsed.learningGoal === 'daily_chat' ||
        parsed.learningGoal === 'work_interviews' ||
        parsed.learningGoal === 'travel' ||
        parsed.learningGoal === 'study_exams'
          ? parsed.learningGoal
          : defaults.learningGoal,
      dailyPaceMinutes:
        parsed.dailyPaceMinutes === 5 ||
        parsed.dailyPaceMinutes === 10 ||
        parsed.dailyPaceMinutes === 20
          ? parsed.dailyPaceMinutes
          : defaults.dailyPaceMinutes,
      dailyPlanDate: td,
      dailyPlanSteps:
        isSamePlanDay && parsed.dailyPlanSteps && typeof parsed.dailyPlanSteps === 'object'
          ? parsed.dailyPlanSteps
          : {},
      dailySentencesCount: isSamePlanDay ? parsed.dailySentencesCount || 0 : 0,
      studyHistory:
        parsed.studyHistory && typeof parsed.studyHistory === 'object' ? parsed.studyHistory : {},
      streakFreezes:
        typeof parsed.streakFreezes === 'number' && Number.isFinite(parsed.streakFreezes)
          ? Math.max(0, Math.min(3, Math.trunc(parsed.streakFreezes)))
          : 1,
      lastFreezeWeek: typeof parsed.lastFreezeWeek === 'string' ? parsed.lastFreezeWeek : '',
      lastActiveDate: typeof parsed.lastActiveDate === 'string' ? parsed.lastActiveDate : '',
      wordleDailyDate: typeof parsed.wordleDailyDate === 'string' ? parsed.wordleDailyDate : '',
      wordleDailyStatus:
        parsed.wordleDailyStatus === 'won' || parsed.wordleDailyStatus === 'lost'
          ? parsed.wordleDailyStatus
          : undefined,
      wordleDailyGuesses:
        typeof parsed.wordleDailyGuesses === 'number' && Number.isFinite(parsed.wordleDailyGuesses)
          ? Math.max(1, Math.min(6, Math.trunc(parsed.wordleDailyGuesses)))
          : undefined,
      bestBlitzScore:
        typeof parsed.bestBlitzScore === 'number' && Number.isFinite(parsed.bestBlitzScore)
          ? Math.max(0, Math.trunc(parsed.bestBlitzScore))
          : 0,
      bestMemoryMoves:
        typeof parsed.bestMemoryMoves === 'number' && Number.isFinite(parsed.bestMemoryMoves)
          ? Math.max(0, Math.trunc(parsed.bestMemoryMoves))
          : 0,
      bestWordRainScore:
        typeof parsed.bestWordRainScore === 'number' && Number.isFinite(parsed.bestWordRainScore)
          ? Math.max(0, Math.trunc(parsed.bestWordRainScore))
          : 0,
      bestRocketStreak:
        typeof parsed.bestRocketStreak === 'number' && Number.isFinite(parsed.bestRocketStreak)
          ? Math.max(0, Math.trunc(parsed.bestRocketStreak))
          : 0,
      bestSentenceBlitzScore:
        typeof parsed.bestSentenceBlitzScore === 'number' &&
        Number.isFinite(parsed.bestSentenceBlitzScore)
          ? Math.max(0, Math.trunc(parsed.bestSentenceBlitzScore))
          : 0,
      uiLang:
        typeof parsed.uiLang === 'string' &&
        ['ar', 'hi', 'zh', 'ru', 'de', 'fr', 'es', 'it', 'pt', 'sv'].includes(parsed.uiLang)
          ? parsed.uiLang
          : defaults.uiLang,
      placementResult:
        parsed.placementResult && typeof parsed.placementResult === 'object'
          ? parsed.placementResult
          : null,
    };
  } catch {
    return defaults;
  }
}

export function savePersistedSettings(settings: PersistedSettings): void {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage quota errors
  }
}

export function idbSaveCustomTSV(tsv: string): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(IDB_STORE)) {
          req.result.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => {
        const tx = req.result.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).put(tsv, 'custom_tsv');
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      };
      req.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

export function idbLoadCustomTSV(): Promise<string | null> {
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(IDB_STORE)) {
          req.result.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => {
        const tx = req.result.transaction(IDB_STORE, 'readonly');
        const g = tx.objectStore(IDB_STORE).get('custom_tsv');
        g.onsuccess = () => resolve((g.result as string) || null);
        g.onerror = () => resolve(null);
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export function idbClearCustomTSV(): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(IDB_STORE)) {
          req.result.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => {
        const tx = req.result.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).delete('custom_tsv');
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      };
      req.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

export type MediaStoreName =
  | 'images'
  | 'wordInfo'
  | 'videos'
  | 'sentencesAr'
  | 'wordHub'
  | 'datasets'
  | 'listening';

const ALL_MEDIA_STORES: MediaStoreName[] = [
  'images',
  'wordInfo',
  'videos',
  'sentencesAr',
  'wordHub',
  'datasets',
  'listening',
];

let mediaDbPromise: Promise<IDBDatabase> | null = null;
let persistentStorageRequested = false;

export function requestPersistentStorage(): void {
  if (persistentStorageRequested || typeof navigator === 'undefined') return;
  persistentStorageRequested = true;
  try {
    const storageApi = navigator.storage as
      | { persist?: () => Promise<boolean>; persisted?: () => Promise<boolean> }
      | undefined;
    if (storageApi && typeof storageApi.persist === 'function') {
      void storageApi.persist().catch(() => {});
    }
  } catch {
    // Ignore unsupported browsers
  }
}

function openMediaDB(): Promise<IDBDatabase> {
  if (mediaDbPromise) return mediaDbPromise;
  mediaDbPromise = new Promise<IDBDatabase>((resolve, reject) => {
    try {
      const req = indexedDB.open(MEDIA_DB_NAME, 5);
      req.onupgradeneeded = () => {
        ALL_MEDIA_STORES.forEach((s) => {
          if (!req.result.objectStoreNames.contains(s)) {
            req.result.createObjectStore(s);
          }
        });
      };
      req.onsuccess = () => {
        const db = req.result;
        db.onversionchange = () => {
          db.close();
          mediaDbPromise = null;
        };
        db.onclose = () => {
          mediaDbPromise = null;
        };
        resolve(db);
      };
      req.onerror = () => {
        mediaDbPromise = null;
        reject(req.error);
      };
    } catch (e) {
      mediaDbPromise = null;
      reject(e);
    }
  });
  return mediaDbPromise;
}

// ============================================================================
// Synchronous Size-Capped localStorage Hot Cache (0ms hydration with LRU)
// ============================================================================
const HOT_CACHE_PREFIX = 'tmn_hot_v1::';
const HOT_CACHE_INDEX_KEY = 'tmn_hot_v1_index';
const HOT_CACHE_MAX_BYTES = 1_600_000; // ~1.6 MB cap to leave plenty of room for settings/SRS
const HOT_CACHE_MAX_ITEMS = 220;

interface HotIndexEntry {
  k: string;
  sz: number;
  ts: number;
  exp: number;
}

interface HotEnvelope<T> {
  d: T;
  e: number;
}

let hotIndexMem: HotIndexEntry[] | null = null;

function loadHotIndex(): HotIndexEntry[] {
  if (hotIndexMem) return hotIndexMem;
  try {
    const raw = localStorage.getItem(HOT_CACHE_INDEX_KEY);
    if (!raw) {
      hotIndexMem = [];
      return hotIndexMem;
    }
    const parsed = JSON.parse(raw);
    hotIndexMem = Array.isArray(parsed) ? parsed : [];
    return hotIndexMem;
  } catch {
    hotIndexMem = [];
    return hotIndexMem;
  }
}

function saveHotIndex(entries: HotIndexEntry[]): void {
  hotIndexMem = entries;
  try {
    localStorage.setItem(HOT_CACHE_INDEX_KEY, JSON.stringify(entries));
  } catch {
    // Ignore index save errors
  }
}

function hotStorageKey(ns: string, key: string): string {
  return `${HOT_CACHE_PREFIX}${ns}::${key}`;
}

export function hotCacheGet<T>(ns: string, key: string): T | null {
  if (typeof window === 'undefined' || typeof localStorage === 'undefined') return null;
  try {
    const fullKey = hotStorageKey(ns, key);
    const raw = localStorage.getItem(fullKey);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as HotEnvelope<T>;
    if (!parsed || (parsed.e && parsed.e <= Date.now())) {
      localStorage.removeItem(fullKey);
      const idx = loadHotIndex().filter((x) => x.k !== fullKey);
      saveHotIndex(idx);
      return null;
    }
    // Touch LRU timestamp in memory
    const idx = loadHotIndex();
    const found = idx.find((x) => x.k === fullKey);
    if (found) found.ts = Date.now();
    return parsed.d;
  } catch {
    return null;
  }
}

export function hotCacheSet<T>(
  ns: string,
  key: string,
  data: T,
  ttlMs = 14 * 24 * 60 * 60 * 1000
): boolean {
  if (typeof window === 'undefined' || typeof localStorage === 'undefined') return false;
  try {
    const fullKey = hotStorageKey(ns, key);
    const exp = Date.now() + ttlMs;
    const serialized = JSON.stringify({ d: data, e: exp } as HotEnvelope<T>);
    // Avoid huge single entries monopolizing localStorage
    if (serialized.length > 90_000) return false;

    const now = Date.now();
    let idx = loadHotIndex().filter((x) => x.k !== fullKey && (!x.exp || x.exp > now));
    let totalBytes = idx.reduce((sum, x) => sum + x.sz, 0);

    // Sort oldest-first for LRU eviction when over budget
    if (totalBytes + serialized.length > HOT_CACHE_MAX_BYTES || idx.length >= HOT_CACHE_MAX_ITEMS) {
      idx.sort((a, b) => a.ts - b.ts);
      while (
        idx.length > 0 &&
        (totalBytes + serialized.length > HOT_CACHE_MAX_BYTES || idx.length >= HOT_CACHE_MAX_ITEMS)
      ) {
        const victim = idx.shift()!;
        totalBytes -= victim.sz;
        try {
          localStorage.removeItem(victim.k);
        } catch {
          // ignore
        }
      }
    }

    try {
      localStorage.setItem(fullKey, serialized);
    } catch {
      // Quota exceeded: evict oldest 25% and retry once
      idx.sort((a, b) => a.ts - b.ts);
      const dropCount = Math.max(4, Math.ceil(idx.length * 0.25));
      for (let i = 0; i < dropCount && idx.length > 0; i++) {
        const victim = idx.shift()!;
        try {
          localStorage.removeItem(victim.k);
        } catch {
          // ignore
        }
      }
      try {
        localStorage.setItem(fullKey, serialized);
      } catch {
        saveHotIndex(idx);
        return false;
      }
    }

    idx.push({ k: fullKey, sz: serialized.length, ts: now, exp });
    saveHotIndex(idx);
    return true;
  } catch {
    return false;
  }
}

export function hotCacheClear(): void {
  if (typeof window === 'undefined' || typeof localStorage === 'undefined') return;
  try {
    const idx = loadHotIndex();
    for (const entry of idx) {
      try {
        localStorage.removeItem(entry.k);
      } catch {
        // ignore
      }
    }
    // Sweep any orphaned keys with prefix
    const toRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(HOT_CACHE_PREFIX)) toRemove.push(k);
    }
    toRemove.forEach((k) => {
      try {
        localStorage.removeItem(k);
      } catch {
        // ignore
      }
    });
    localStorage.removeItem(HOT_CACHE_INDEX_KEY);
    hotIndexMem = [];
  } catch {
    // ignore
  }
}

export async function idbMediaGet<T>(
  storeName: MediaStoreName,
  key: string
): Promise<T | null> {
  try {
    const db = await openMediaDB();
    return await new Promise((resolve) => {
      const tx = db.transaction(storeName, 'readonly');
      const g = tx.objectStore(storeName).get(key);
      g.onsuccess = () => {
        const entry = g.result as { data: T; expiresAt?: number } | undefined;
        if (!entry || (entry.expiresAt && entry.expiresAt <= Date.now())) {
          resolve(null);
        } else {
          resolve(entry.data);
        }
      };
      g.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function idbMediaSet<T>(
  storeName: MediaStoreName,
  key: string,
  data: T,
  ttlMs: number
): Promise<boolean> {
  try {
    const db = await openMediaDB();
    return await new Promise((resolve) => {
      const tx = db.transaction(storeName, 'readwrite');
      tx.objectStore(storeName).put({ data, expiresAt: Date.now() + ttlMs }, key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch {
    return false;
  }
}

export async function idbGetDataset(key: string): Promise<string | null> {
  return idbMediaGet<string>('datasets', key);
}

export async function idbSetDataset(
  key: string,
  text: string,
  ttlMs = 30 * 24 * 60 * 60 * 1000
): Promise<boolean> {
  return idbMediaSet<string>('datasets', key, text, ttlMs);
}

export async function idbGetSentenceTranslations(
  keys: string[]
): Promise<Record<string, string>> {
  const result: Record<string, string> = {};
  if (!keys.length) return result;
  // First check synchronous hot cache
  const missing: string[] = [];
  for (const k of keys) {
    const hot = hotCacheGet<string>('sent', k);
    if (hot) {
      result[k] = hot;
    } else {
      missing.push(k);
    }
  }
  if (!missing.length) return result;

  try {
    const db = await openMediaDB();
    await new Promise<void>((resolve) => {
      const tx = db.transaction('sentencesAr', 'readonly');
      const store = tx.objectStore('sentencesAr');
      for (const key of missing) {
        const req = store.get(key);
        req.onsuccess = () => {
          const entry = req.result as { data: string; expiresAt?: number } | undefined;
          if (entry && typeof entry.data === 'string' && (!entry.expiresAt || entry.expiresAt > Date.now())) {
            result[key] = entry.data;
            hotCacheSet('sent', key, entry.data, 30 * 24 * 60 * 60 * 1000);
          }
        };
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    // Ignore IDB errors
  }
  return result;
}

export async function idbSetSentenceTranslations(
  entries: Record<string, string>
): Promise<boolean> {
  const pairs = Object.entries(entries);
  if (!pairs.length) return true;
  for (const [k, v] of pairs) {
    if (v && v.trim()) {
      hotCacheSet('sent', k, v.trim(), 30 * 24 * 60 * 60 * 1000);
    }
  }
  try {
    const db = await openMediaDB();
    const ttl = Date.now() + 90 * 24 * 60 * 60 * 1000; // 90 days
    return await new Promise((resolve) => {
      const tx = db.transaction('sentencesAr', 'readwrite');
      const store = tx.objectStore('sentencesAr');
      for (const [k, v] of pairs) {
        if (v && v.trim()) {
          store.put({ data: v.trim(), expiresAt: ttl }, k);
        }
      }
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch {
    return false;
  }
}

export async function clearAllMediaCache(): Promise<boolean> {
  hotCacheClear();
  try {
    const db = await openMediaDB();
    const stores = ALL_MEDIA_STORES.filter((s) => db.objectStoreNames.contains(s));
    if (!stores.length) return true;
    return await new Promise((resolve) => {
      const tx = db.transaction(stores, 'readwrite');
      stores.forEach((s) => tx.objectStore(s).clear());
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch {
    return false;
  }
}
