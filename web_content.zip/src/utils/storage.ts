import { Product, Customer, Invoice, StoreSettings, CodeFile } from '../types';
import { initialProducts, initialCustomers, initialInvoices, initialStoreSettings, initialCodeFiles, initialCategories } from '../data/initialData';

export const STORAGE_KEYS = {
  PRODUCTS: 'winsales_products_v1',
  CUSTOMERS: 'winsales_customers_v1',
  INVOICES: 'winsales_invoices_v1',
  SETTINGS: 'winsales_settings_v1',
  CODE_FILES: 'winsales_code_files_v1',
  CATEGORIES: 'winsales_categories_v1',
};

export function loadStoredData<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (err) {
    console.warn(`Failed to parse ${key} from localStorage:`, err);
    return fallback;
  }
}

export function saveStoredData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.error(`Failed to save ${key} to localStorage:`, err);
  }
}

export function getStoredProducts(): Product[] {
  return loadStoredData<Product[]>(STORAGE_KEYS.PRODUCTS, initialProducts);
}

export function saveProducts(products: Product[]): void {
  saveStoredData(STORAGE_KEYS.PRODUCTS, products);
}

export function getStoredCustomers(): Customer[] {
  return loadStoredData<Customer[]>(STORAGE_KEYS.CUSTOMERS, initialCustomers);
}

export function saveCustomers(customers: Customer[]): void {
  saveStoredData(STORAGE_KEYS.CUSTOMERS, customers);
}

export function getStoredInvoices(): Invoice[] {
  return loadStoredData<Invoice[]>(STORAGE_KEYS.INVOICES, initialInvoices);
}

export function saveInvoices(invoices: Invoice[]): void {
  saveStoredData(STORAGE_KEYS.INVOICES, invoices);
}

export function getStoredSettings(): StoreSettings {
  return loadStoredData<StoreSettings>(STORAGE_KEYS.SETTINGS, initialStoreSettings);
}

export function saveSettings(settings: StoreSettings): void {
  saveStoredData(STORAGE_KEYS.SETTINGS, settings);
}

export function getStoredCodeFiles(): CodeFile[] {
  return loadStoredData<CodeFile[]>(STORAGE_KEYS.CODE_FILES, initialCodeFiles);
}

export function saveCodeFiles(files: CodeFile[]): void {
  saveStoredData(STORAGE_KEYS.CODE_FILES, files);
}

export function getStoredCategories(): string[] {
  return loadStoredData<string[]>(STORAGE_KEYS.CATEGORIES, initialCategories);
}

export function saveCategories(categories: string[]): void {
  saveStoredData(STORAGE_KEYS.CATEGORIES, categories);
}

export function exportAllDataBackup(): void {
  try {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      products: getStoredProducts(),
      customers: getStoredCustomers(),
      invoices: getStoredInvoices(),
      settings: getStoredSettings(),
      codeFiles: getStoredCodeFiles(),
      categories: getStoredCategories(),
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `winsales_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (e) {
    console.error('Failed to export backup:', e);
  }
}

export const exportFullBackup = exportAllDataBackup;

export function importAllDataBackup(file: File): Promise<boolean> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const data = JSON.parse(text);
        if (data.products && Array.isArray(data.products)) {
          saveProducts(data.products);
        }
        if (data.customers && Array.isArray(data.customers)) {
          saveCustomers(data.customers);
        }
        if (data.invoices && Array.isArray(data.invoices)) {
          saveInvoices(data.invoices);
        }
        if (data.settings) {
          saveSettings(data.settings);
        }
        if (data.codeFiles && Array.isArray(data.codeFiles)) {
          saveCodeFiles(data.codeFiles);
        }
        if (data.categories && Array.isArray(data.categories)) {
          saveCategories(data.categories);
        }
        resolve(true);
      } catch (err) {
        console.error('Failed to import backup JSON:', err);
        resolve(false);
      }
    };
    reader.onerror = () => resolve(false);
    reader.readAsText(file);
  });
}

export function resetToDefaultData(): void {
  saveProducts(initialProducts);
  saveCustomers(initialCustomers);
  saveInvoices(initialInvoices);
  saveSettings(initialStoreSettings);
  saveCodeFiles(initialCodeFiles);
  saveCategories(initialCategories);
}
