import { ChatSession, ChatSettings, StorageStats, ChatMessage } from '../types/index.ts';
import { PERSONA_PRESETS } from './presets.ts';

const SETTINGS_KEY = 'nexusai_user_settings_v1';
const SESSIONS_KEY = 'nexusai_chat_sessions_v1';

export const DEFAULT_SETTINGS: ChatSettings = {
  model: 'gemini-3.1-flash-lite',
  systemInstruction: PERSONA_PRESETS[0].systemInstruction,
  temperature: 0.7,
  topP: 0.95,
  topK: 40,
  maxOutputTokens: 4096,
  thinkingLevel: '',
  contextWindow: 12, // sends last 12 messages for context (0 = all)
  streamResponse: true,
  botName: 'Nexus AI',
  botAvatar: '🤖',
  userName: 'Saya',
  userAvatar: '',
  userPersona: '',
  fontSize: 'md',
  autoScroll: true,
  soundFeedback: false,
  theme: 'dark',
  safetyFilterEnabled: false, // Default: Sensor dimatikan agar pengguna punya kontrol bebas tanpa sensor
  safetyThreshold: 'BLOCK_NONE',
  antiRefusalBypassEnabled: true, // Otomatis bypass penolakan model saat sensor mati
  provider: 'gemini',
  openRouterApiKey: '',
  openRouterModel: 'google/gemini-2.0-flash-exp:free',
  backgroundEnabled: false,
  backgroundType: 'none',
  backgroundImageUrl: '',
  backgroundOpacity: 0.25,
  backgroundBlur: 2,
  bubbleOpacity: 0.85,
  bubbleBlur: 0,
  fullScreenMode: true,
  chatWidth: 'full',
  enterKeyAction: 'newline',
};

// Helper to compress uploaded avatar images to small lightweight data URLs (~15-25KB)
export function compressAvatarImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_DIM = 256;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > MAX_DIM) {
            height = Math.round((height * MAX_DIM) / width);
            width = MAX_DIM;
          }
        } else {
          if (height > MAX_DIM) {
            width = Math.round((width * MAX_DIM) / height);
            height = MAX_DIM;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => resolve(e.target?.result as string);
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Safe LocalStorage helpers
export function loadSettings(): ChatSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch (err) {
    console.warn('Gagal memuat pengaturan lokal, menggunakan default:', err);
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(settings: ChatSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Gagal menyimpan pengaturan lokal:', err);
  }
}

export function loadSessions(): ChatSession[] {
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return [];
  } catch (err) {
    console.warn('Gagal memuat sesi chat lokal:', err);
    return [];
  }
}

export function saveSessions(sessions: ChatSession[]): void {
  try {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  } catch (err) {
    console.error('Gagal menyimpan riwayat sesi lokal (kuota mungkin penuh):', err);
  }
}

export function createNewSession(title = 'Percakapan Baru'): ChatSession {
  const now = Date.now();
  return {
    id: `sess_${now}_${Math.random().toString(36).substring(2, 9)}`,
    title,
    createdAt: now,
    updatedAt: now,
    messages: [],
    pinned: false,
  };
}

export function getStorageStats(): StorageStats {
  try {
    const rawSessions = localStorage.getItem(SESSIONS_KEY) || '[]';
    const rawSettings = localStorage.getItem(SETTINGS_KEY) || '{}';
    
    // Estimate bytes
    const totalBytes = new Blob([rawSessions, rawSettings]).size;
    const sessions: ChatSession[] = JSON.parse(rawSessions);
    
    let messageCount = 0;
    if (Array.isArray(sessions)) {
      for (const s of sessions) {
        if (s.messages && Array.isArray(s.messages)) {
          messageCount += s.messages.length;
        }
      }
    }

    const storageQuotaBytes = 5 * 1024 * 1024; // Standard 5MB LocalStorage quota
    const usagePercentage = Math.min(100, Number(((totalBytes / storageQuotaBytes) * 100).toFixed(2)));

    return {
      sessionCount: Array.isArray(sessions) ? sessions.length : 0,
      messageCount,
      totalBytes,
      storageQuotaBytes,
      usagePercentage,
    };
  } catch (err) {
    return {
      sessionCount: 0,
      messageCount: 0,
      totalBytes: 0,
      storageQuotaBytes: 5 * 1024 * 1024,
      usagePercentage: 0,
    };
  }
}

export function exportAllDataAsJSON(): string {
  const settings = loadSettings();
  const sessions = loadSessions();
  const exportPayload = {
    version: '1.0.0',
    exportedAt: new Date().toISOString(),
    appName: 'NexusAI',
    storageType: 'Pure Local Browser Storage',
    settings,
    sessions,
  };
  return JSON.stringify(exportPayload, null, 2);
}

export function importDataFromJSON(
  jsonString: string,
  mode: 'merge' | 'overwrite' = 'merge'
): { success: boolean; message: string; sessionCount: number } {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== 'object') {
      return { success: false, message: 'Format data JSON tidak valid.', sessionCount: 0 };
    }

    if (parsed.settings && typeof parsed.settings === 'object') {
      saveSettings({ ...DEFAULT_SETTINGS, ...parsed.settings });
    }

    const importedSessions: ChatSession[] = Array.isArray(parsed.sessions) ? parsed.sessions : [];
    
    if (mode === 'overwrite') {
      saveSessions(importedSessions);
      return {
        success: true,
        message: `Berhasil menimpa data dengan ${importedSessions.length} sesi percakapan.`,
        sessionCount: importedSessions.length,
      };
    } else {
      const currentSessions = loadSessions();
      const existingIds = new Set(currentSessions.map((s) => s.id));
      const newSessions = [...currentSessions];

      let addedCount = 0;
      for (const s of importedSessions) {
        if (!existingIds.has(s.id)) {
          newSessions.unshift(s);
          existingIds.add(s.id);
          addedCount++;
        }
      }

      saveSessions(newSessions);
      return {
        success: true,
        message: `Berhasil menggabungkan ${addedCount} sesi percakapan baru.`,
        sessionCount: addedCount,
      };
    }
  } catch (err: any) {
    return {
      success: false,
      message: `Gagal membaca file: ${err.message || 'JSON korup'}`,
      sessionCount: 0,
    };
  }
}

export function exportSessionAsMarkdown(session: ChatSession, botName = 'Nexus AI'): string {
  const dateStr = new Date(session.createdAt).toLocaleString('id-ID');
  let md = `# Percakapan: ${session.title}\n`;
  md += `*Dibuat pada: ${dateStr}*\n`;
  md += `*Total Pesan: ${session.messages.length}*\n\n---\n\n`;

  for (const m of session.messages) {
    const speaker = m.role === 'user' ? '👤 Pengguna' : `🤖 ${botName}`;
    const time = new Date(m.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    md += `### ${speaker} (${time})\n\n`;
    
    if (m.images && m.images.length > 0) {
      md += `*[Lampiran Gambar: ${m.images.length} file]*\n\n`;
    }
    
    md += `${m.content}\n\n---\n\n`;
  }

  return md;
}

export function downloadFile(content: string, fileName: string, contentType: string): void {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
