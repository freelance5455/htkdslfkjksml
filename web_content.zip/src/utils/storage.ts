import { HighScoreEntry, TrackId } from '../types.ts';

const HIGH_SCORES_KEY = 'chamsou_race_highscores';
const CRT_KEY = 'chamsou_race_crt';

const DEFAULT_SCORES: HighScoreEntry[] = [
  { id: '1', name: 'CHAMSOU (عمرو)', score: 4850, carName: 'RENAULT R5', trackId: 'sahara', distanceKm: 24.2, date: '2026-11-01' },
  { id: '2', name: 'AMROU PC (المدير)', score: 3920, carName: 'PEUGEOT 205', trackId: 'corniche', distanceKm: 19.6, date: '2026-11-02' },
  { id: '3', name: 'DAHMANE', score: 2780, carName: 'CITROËN 2CV', trackId: 'sahara', distanceKm: 13.9, date: '2026-11-04' },
  { id: '4', name: 'SLIMANE 504', score: 2150, carName: 'PEUGEOT 204', trackId: 'atlas', distanceKm: 10.7, date: '2026-11-05' },
  { id: '5', name: 'YASMINA DZ', score: 1640, carName: 'RENAULT MEGANE', trackId: 'corniche', distanceKm: 8.2, date: '2026-11-07' }
];

export function getHighScores(): HighScoreEntry[] {
  try {
    const raw = localStorage.getItem(HIGH_SCORES_KEY);
    if (!raw) {
      localStorage.setItem(HIGH_SCORES_KEY, JSON.stringify(DEFAULT_SCORES));
      return DEFAULT_SCORES;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_SCORES;
  }
}

export function saveHighScore(name: string, score: number, carName: string, trackId: TrackId, distanceKm: number): HighScoreEntry[] {
  const current = getHighScores();
  const newEntry: HighScoreEntry = {
    id: Date.now().toString(),
    name: (name.trim() || 'CHAMSOU').toUpperCase(),
    score,
    carName,
    trackId,
    distanceKm: parseFloat(distanceKm.toFixed(1)),
    date: new Date().toISOString().split('T')[0]
  };

  const updated = [...current, newEntry]
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);

  try {
    localStorage.setItem(HIGH_SCORES_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }

  return updated;
}

export function getCrtPreference(): boolean {
  try {
    const val = localStorage.getItem(CRT_KEY);
    return val !== null ? val === 'true' : true; // default CRT on for retro vibe!
  } catch {
    return true;
  }
}

export function setCrtPreference(enabled: boolean) {
  try {
    localStorage.setItem(CRT_KEY, String(enabled));
  } catch {
    // ignore
  }
}
