import { BoosterInventory, PlayerStats, SaveData } from '../types/game';

const STORAGE_KEY = 'chroma_rush_v1_save_data';

const DEFAULT_STATS: PlayerStats = {
  levelsCompleted: 0,
  perfectLevels: 0,
  starsCollected: 0,
  totalCoins: 120, // Starting bonus for new players
  totalMovesMade: 0,
  totalPathsCompleted: 0,
  highestCombo: 0,
  timeChallengeHighScore: 0,
  endlessHighScore: 0,
  dailyStreak: 0,
  lastDailyDate: ''
};

const DEFAULT_BOOSTERS: BoosterInventory = {
  hint: 3,
  extraMoves: 2,
  colorClear: 1,
  shuffle: 2,
  undo: 5
};

const DEFAULT_SAVE_DATA: SaveData = {
  stats: DEFAULT_STATS,
  levelProgress: {},
  dailyCompletions: {},
  unlockedThemes: ['cyber_neon'],
  activeThemeId: 'cyber_neon',
  unlockedSkins: ['neon_orb'],
  activeSkinId: 'neon_orb',
  boosters: DEFAULT_BOOSTERS,
  achievements: {},
  settings: {
    sound: true,
    music: true,
    colorblindMode: false,
    reducedMotion: false,
    haptics: true
  }
};

export function loadSaveData(): SaveData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SAVE_DATA;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_SAVE_DATA,
      ...parsed,
      stats: { ...DEFAULT_STATS, ...parsed.stats },
      boosters: { ...DEFAULT_BOOSTERS, ...parsed.boosters },
      settings: { ...DEFAULT_SAVE_DATA.settings, ...parsed.settings }
    };
  } catch (err) {
    console.error('Failed to parse save data from localStorage', err);
    return DEFAULT_SAVE_DATA;
  }
}

export function writeSaveData(data: SaveData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error('Failed to save to localStorage', err);
  }
}

export function resetSaveData(): SaveData {
  localStorage.removeItem(STORAGE_KEY);
  return DEFAULT_SAVE_DATA;
}
