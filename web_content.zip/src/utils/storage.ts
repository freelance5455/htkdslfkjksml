import { Product, SaleTransaction, StoreSettings } from '../types';

export const DEFAULT_SETTINGS: StoreSettings = {
  storeName: 'TALLY STORE',
  tagline: 'Sales & Inventory Register',
  address: '108 Commercial Avenue, Metro Plaza',
  phone: '+63 (02) 8123-4567',
  email: 'support@tallystore.com',
  tin: 'TIN: 123-456-789-000',
  receiptHeaderNote: 'Official Sales Invoice • Customer Copy',
  currency: '₱',
  taxRate: 0,
  enableSound: true,
  promptQuantityOnScan: true,
  receiptFooter: 'Thank you for your business! Please come again.'
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    code: '1001',
    name: 'Bottled Mineral Water (500ml)',
    category: 'Beverages',
    price: 20.00,
    costPrice: 12.00,
    stock: 48,
    minStock: 10,
    unit: 'bottle',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-2',
    code: '1002',
    name: 'Espresso Roast Coffee (250g)',
    category: 'Beverages',
    price: 85.00,
    costPrice: 48.00,
    stock: 15,
    minStock: 5,
    unit: 'pack',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-3',
    code: '1003',
    name: 'Wireless Optical Mouse',
    category: 'Electronics',
    price: 350.00,
    costPrice: 210.00,
    stock: 4,
    minStock: 5,
    unit: 'pcs',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-4',
    code: '1004',
    name: 'Cotton Crew T-Shirt (Black - L)',
    category: 'Apparel',
    price: 250.00,
    costPrice: 130.00,
    stock: 22,
    minStock: 8,
    unit: 'pcs',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-5',
    code: '1005',
    name: 'Organic Whole Milk (1 Liter)',
    category: 'Dairy',
    price: 95.00,
    costPrice: 65.00,
    stock: 12,
    minStock: 4,
    unit: 'carton',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-6',
    code: '1006',
    name: 'Artisan Sourdough Loaf',
    category: 'Bakery',
    price: 110.00,
    costPrice: 60.00,
    stock: 8,
    minStock: 3,
    unit: 'loaf',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-7',
    code: '1007',
    name: 'USB-C Fast Charging Cable (1.5m)',
    category: 'Electronics',
    price: 180.00,
    costPrice: 75.00,
    stock: 19,
    minStock: 6,
    unit: 'pcs',
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-8',
    code: '1008',
    name: 'Dark Chocolate Bar 70% (80g)',
    category: 'Snacks',
    price: 65.00,
    costPrice: 38.00,
    stock: 2,
    minStock: 6,
    unit: 'bar',
    createdAt: new Date().toISOString()
  }
];

const STORAGE_KEYS = {
  INVENTORY: 'tally_inventory',
  SALES: 'tally_sales',
  SETTINGS: 'tally_settings'
};

export function getStoredInventory(): Product[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.INVENTORY);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(INITIAL_PRODUCTS));
      return INITIAL_PRODUCTS;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_PRODUCTS;
  }
}

export function saveStoredInventory(items: Product[]): void {
  localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(items));
}

export function getStoredSales(): SaleTransaction[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SALES);
    if (!data) return [];
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function saveStoredSales(sales: SaleTransaction[]): void {
  localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
}

export function getStoredSettings(): StoreSettings {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
      return DEFAULT_SETTINGS;
    }
    return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveStoredSettings(settings: StoreSettings): void {
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
}
