import { CNICRecord, SendingEntry, ReplyEntry, SIMSlot, TelecomOperator } from '../types';
import { generatePTA668Reply } from './cnic';

const STORAGE_KEYS = {
  RECORDS: 'aks_records_v1',
  SENDING: 'aks_sending_v1',
  REPLIES: 'aks_replies_v1',
  SIM_SLOT: 'aks_sim_slot_v1',
  SIM_CONFIGS: 'aks_sim_configs_v1',
  LANGUAGE: 'aks_lang_v1',
  SOUND_ENABLED: 'aks_sound_v1',
  ANIMATION_ENABLED: 'aks_anim_v1',
};

export function loadSavedState() {
  try {
    const rawRecords = localStorage.getItem(STORAGE_KEYS.RECORDS);
    const rawSending = localStorage.getItem(STORAGE_KEYS.SENDING);
    const rawReplies = localStorage.getItem(STORAGE_KEYS.REPLIES);
    const rawSlot = localStorage.getItem(STORAGE_KEYS.SIM_SLOT) as SIMSlot | null;
    const rawLang = localStorage.getItem(STORAGE_KEYS.LANGUAGE) as 'ur' | 'en' | null;
    const rawSound = localStorage.getItem(STORAGE_KEYS.SOUND_ENABLED);
    const rawAnim = localStorage.getItem(STORAGE_KEYS.ANIMATION_ENABLED);

    let records: CNICRecord[] = rawRecords ? JSON.parse(rawRecords) : [];
    let sending: SendingEntry[] = rawSending ? JSON.parse(rawSending) : [];
    let replies: ReplyEntry[] = rawReplies ? JSON.parse(rawReplies) : [];

    // Provide default initial demo records if completely empty so user has immediate preview
    if (!rawRecords && records.length === 0) {
      records = [
        {
          id: 'seed-1',
          cnic: '3520112345671',
          sim: 'SIM 1 (Jazz 4G)',
          time: new Date().toLocaleTimeString(),
          status: 'Added',
          province: 'Punjab',
          gender: 'Male',
        },
        {
          id: 'seed-2',
          cnic: '4210198765432',
          sim: 'SIM 2 (Zong 4G)',
          time: new Date().toLocaleTimeString(),
          status: 'Demo',
          province: 'Sindh',
          gender: 'Female',
        },
      ];

      const seedReply = generatePTA668Reply('4210198765432');
      sending = [
        {
          id: 'send-seed-1',
          cnic: '4210198765432',
          sim: 'SIM 2 (Zong 4G)',
          destination: '668',
          time: new Date().toLocaleTimeString(),
          status: 'Demo only',
          rawTime: Date.now() - 3600000,
        },
      ];

      replies = [
        {
          id: 'reply-seed-1',
          cnic: '4210198765432',
          time: new Date().toLocaleTimeString(),
          sim: 'SIM 2 (Zong 4G)',
          rawText: seedReply.rawText,
          parsedBreakdown: seedReply.breakdown,
        },
      ];
    }

    return {
      records,
      sending,
      replies,
      selectedSim: rawSlot || 'SIM 1',
      language: rawLang || 'ur',
      soundEnabled: rawSound !== 'false',
      animationEnabled: rawAnim !== 'false',
    };
  } catch {
    return {
      records: [],
      sending: [],
      replies: [],
      selectedSim: 'SIM 1' as SIMSlot,
      language: 'ur' as const,
      soundEnabled: true,
      animationEnabled: true,
    };
  }
}

export function saveState(data: {
  records?: CNICRecord[];
  sending?: SendingEntry[];
  replies?: ReplyEntry[];
  selectedSim?: SIMSlot;
  language?: 'ur' | 'en';
  soundEnabled?: boolean;
  animationEnabled?: boolean;
}) {
  try {
    if (data.records !== undefined) {
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(data.records));
    }
    if (data.sending !== undefined) {
      localStorage.setItem(STORAGE_KEYS.SENDING, JSON.stringify(data.sending));
    }
    if (data.replies !== undefined) {
      localStorage.setItem(STORAGE_KEYS.REPLIES, JSON.stringify(data.replies));
    }
    if (data.selectedSim !== undefined) {
      localStorage.setItem(STORAGE_KEYS.SIM_SLOT, data.selectedSim);
    }
    if (data.language !== undefined) {
      localStorage.setItem(STORAGE_KEYS.LANGUAGE, data.language);
    }
    if (data.soundEnabled !== undefined) {
      localStorage.setItem(STORAGE_KEYS.SOUND_ENABLED, String(data.soundEnabled));
    }
    if (data.animationEnabled !== undefined) {
      localStorage.setItem(STORAGE_KEYS.ANIMATION_ENABLED, String(data.animationEnabled));
    }
  } catch {
    // LocalStorage quota error suppressed
  }
}

export function clearAllStorage() {
  try {
    localStorage.removeItem(STORAGE_KEYS.RECORDS);
    localStorage.removeItem(STORAGE_KEYS.SENDING);
    localStorage.removeItem(STORAGE_KEYS.REPLIES);
  } catch {
    // Suppressed
  }
}
