import { Project, EditorSettings } from '../types';
import { DEFAULT_PROJECTS } from './defaultProjects';

const STORAGE_KEY_PROJECTS = 'codeverse_projects_v1';
const STORAGE_KEY_ACTIVE_ID = 'codeverse_active_proj_id_v1';
const STORAGE_KEY_SETTINGS = 'codeverse_settings_v1';
const STORAGE_KEY_HISTORY = 'codeverse_proj_history_v1';

export const DEFAULT_SETTINGS: EditorSettings = {
  fontSize: 14,
  tabSize: 2,
  fontFamily: 'Fira Code',
  lineNumbers: true,
  wordWrap: true,
  autoRunOnChange: true,
  theme: 'cyberpunk',
};

export function loadProjects(): Project[] {
  if (typeof window === 'undefined') return DEFAULT_PROJECTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PROJECTS);
    if (!raw) {
      saveProjects(DEFAULT_PROJECTS);
      return DEFAULT_PROJECTS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_PROJECTS;
  } catch (e) {
    console.error('Failed to load projects from localStorage:', e);
    return DEFAULT_PROJECTS;
  }
}

export function saveProjects(projects: Project[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_PROJECTS, JSON.stringify(projects));
  } catch (e) {
    console.error('Failed to save projects to localStorage:', e);
  }
}

export function loadActiveProjectId(projects: Project[]): string {
  if (typeof window === 'undefined') return projects[0]?.id || '';
  try {
    const id = localStorage.getItem(STORAGE_KEY_ACTIVE_ID);
    if (id && projects.some(p => p.id === id)) return id;
    return projects[0]?.id || '';
  } catch (e) {
    return projects[0]?.id || '';
  }
}

export function saveActiveProjectId(id: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_ACTIVE_ID, id);
  } catch (e) {}
}

export function loadSettings(): EditorSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: EditorSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  } catch (e) {}
}

export interface ProjectSnapshot {
  id: string;
  projectId: string;
  timestamp: number;
  label: string;
  files: { id: string; name: string; content: string }[];
}

export function recordProjectRevision(project: Project, label: string = 'Snapshot'): void {
  if (typeof window === 'undefined') return;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_HISTORY);
    const history: ProjectSnapshot[] = raw ? JSON.parse(raw) : [];
    const snapshot: ProjectSnapshot = {
      id: 'rev_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      projectId: project.id,
      timestamp: Date.now(),
      label,
      files: project.files.map(f => ({ id: f.id, name: f.name, content: f.content })),
    };
    // Keep max 20 snapshots per project
    const filtered = history.filter(h => h.projectId === project.id);
    if (filtered.length >= 20) {
      filtered.shift();
    }
    const otherProjectsHistory = history.filter(h => h.projectId !== project.id);
    localStorage.setItem(
      STORAGE_KEY_HISTORY,
      JSON.stringify([...otherProjectsHistory, ...filtered, snapshot])
    );
  } catch (e) {}
}

export function getProjectRevisions(projectId: string): ProjectSnapshot[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY_HISTORY);
    if (!raw) return [];
    const history: ProjectSnapshot[] = JSON.parse(raw);
    return history.filter(h => h.projectId === projectId).sort((a, b) => b.timestamp - a.timestamp);
  } catch (e) {
    return [];
  }
}
