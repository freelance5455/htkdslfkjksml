import { AppSettings, LogoItem, MemoryItem, VideoItem, CalculationHistoryItem } from '../types';

const STORAGE_KEYS = {
  LOGOS: 'bm_logos_v1',
  VIDEOS: 'bm_videos_v1',
  MEMORIES: 'bm_memories_v1',
  CALCULATIONS: 'bm_calc_history_v1',
  SETTINGS: 'bm_settings_v1',
};

export const defaultSettings: AppSettings = {
  offlineMode: false,
  julliEnabled: true,
  julliWakeWordEnabled: true,
  julliVoiceFeedback: true,
  julliAutoSleepSeconds: 10,
  julliListenTimeoutSeconds: 8,
  pollinationsEnabled: true,
  pollinationsApiKey: 'sk_QiH5IPtAvEwXzZCzMsI31AWBt2MSffal',
  pollinationsEndpoint1: 'https://gen.pollinations.ai/image/',
  pollinationsEndpoint2: 'https://image.pollinations.ai/prompt/',
  geminiModel: 'gemini-3-pro-image-preview',
  geminiApiKey: '',
  geminiBaseUrl: '',
  groqModel: 'llama-3.3-70b-versatile',
  groqApiKey: '',
  groqBaseUrl: 'https://api.groq.com/openai/v1',
  activeProvider: 'pollinations',
  vaultPasswordHash: '',
  isVaultLocked: false,
};

export async function hashPassword(password: string): Promise<string> {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(password + '_julli_salt_2026');
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } catch {
    // Basic fallback for environments without subtle crypto
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
      hash = (hash << 5) - hash + password.charCodeAt(i);
      hash |= 0;
    }
    return String(hash);
  }
}

export function loadSettings(): AppSettings {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!data) return defaultSettings;
    const parsed = JSON.parse(data);
    return {
      ...defaultSettings,
      ...parsed,
      // If a password exists, default the vault to locked on session load
      isVaultLocked: !!parsed.vaultPasswordHash,
    };
  } catch {
    return defaultSettings;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Error saving settings:', e);
  }
}

export function loadLogos(): LogoItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.LOGOS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveLogo(logo: LogoItem): void {
  try {
    const current = loadLogos();
    const updated = [logo, ...current.filter(l => l.id !== logo.id)].slice(0, 50);
    localStorage.setItem(STORAGE_KEYS.LOGOS, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving logo:', e);
  }
}

export function loadVideos(): VideoItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.VIDEOS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveVideo(video: VideoItem): void {
  try {
    const current = loadVideos();
    const updated = [video, ...current.filter(v => v.id !== video.id)].slice(0, 30);
    localStorage.setItem(STORAGE_KEYS.VIDEOS, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving video:', e);
  }
}

export function loadMemories(): MemoryItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.MEMORIES);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveMemory(memory: MemoryItem): void {
  try {
    const current = loadMemories();
    const updated = [memory, ...current.filter(m => m.id !== memory.id)];
    localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving memory:', e);
  }
}

export function deleteMemory(id: string): void {
  try {
    const current = loadMemories();
    const updated = current.filter(m => m.id !== id);
    localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(updated));
  } catch (e) {
    console.error('Error deleting memory:', e);
  }
}

export function loadCalculations(): CalculationHistoryItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CALCULATIONS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveCalculation(item: CalculationHistoryItem): void {
  try {
    const current = loadCalculations();
    const updated = [item, ...current].slice(0, 40);
    localStorage.setItem(STORAGE_KEYS.CALCULATIONS, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving calculation:', e);
  }
}
