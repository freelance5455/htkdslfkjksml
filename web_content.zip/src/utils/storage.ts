import { Alarm, AppSettings } from '../types/alarm';
import { PRESET_MEDIA_ITEMS } from './mediaStore';

const ALARMS_STORAGE_KEY = 'wakeup_alarms_v1';
const SETTINGS_STORAGE_KEY = 'wakeup_settings_v1';

export const DEFAULT_SETTINGS: AppSettings = {
  defaultVolume: 85,
  defaultSnoozeDuration: 5,
  gradualVolume: true,
  vibration: true,
  darkMode: false,
  timeFormat: '12h',
  soundInSilentMode: true,
};

// Generate default initial alarms for new users
export function getDefaultAlarms(): Alarm[] {
  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();

  // Create an alarm scheduled 3 minutes from now for quick testing
  const quickTestTime = new Date(now.getTime() + 3 * 60 * 1000);

  return [
    {
      id: 'alarm-default-1',
      hour: quickTestTime.getHours(),
      minute: quickTestTime.getMinutes(),
      alarmLabel: 'Sunrise Workout',
      mediaUri: PRESET_MEDIA_ITEMS[0].id,
      mediaName: PRESET_MEDIA_ITEMS[0].name,
      mediaType: 'video',
      mediaThumbnail: PRESET_MEDIA_ITEMS[0].thumbnail,
      repeatDays: [1, 2, 3, 4, 5], // Mon - Fri
      isEnabled: true,
      volume: 85,
      gradualVolumeEnabled: true,
      vibrationEnabled: true,
      snoozeDuration: 5,
      createdAt: Date.now() - 86400000,
    },
    {
      id: 'alarm-default-2',
      hour: 8,
      minute: 30,
      alarmLabel: 'Weekend Chill & Music',
      mediaUri: PRESET_MEDIA_ITEMS[3].id,
      mediaName: PRESET_MEDIA_ITEMS[3].name,
      mediaType: 'audio',
      mediaThumbnail: PRESET_MEDIA_ITEMS[3].thumbnail,
      repeatDays: [0, 6], // Sat, Sun
      isEnabled: true,
      volume: 80,
      gradualVolumeEnabled: false,
      vibrationEnabled: true,
      snoozeDuration: 10,
      createdAt: Date.now() - 43200000,
    },
    {
      id: 'alarm-default-3',
      hour: (currentHour + 1) % 24,
      minute: currentMinute,
      alarmLabel: 'Power Afternoon Boost',
      mediaUri: PRESET_MEDIA_ITEMS[1].id,
      mediaName: PRESET_MEDIA_ITEMS[1].name,
      mediaType: 'video',
      mediaThumbnail: PRESET_MEDIA_ITEMS[1].thumbnail,
      repeatDays: [], // One-time alarm
      isEnabled: false,
      volume: 90,
      gradualVolumeEnabled: true,
      vibrationEnabled: true,
      snoozeDuration: 5,
      createdAt: Date.now() - 200000,
    }
  ];
}

export function loadStoredAlarms(): Alarm[] {
  try {
    const raw = localStorage.getItem(ALARMS_STORAGE_KEY);
    if (!raw) {
      const initial = getDefaultAlarms();
      saveStoredAlarms(initial);
      return initial;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : getDefaultAlarms();
  } catch (err) {
    console.error('Failed loading saved alarms:', err);
    return getDefaultAlarms();
  }
}

export function saveStoredAlarms(alarms: Alarm[]): void {
  try {
    localStorage.setItem(ALARMS_STORAGE_KEY, JSON.stringify(alarms));
  } catch (err) {
    console.error('Failed saving alarms:', err);
  }
}

export function loadStoredSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (err) {
    return DEFAULT_SETTINGS;
  }
}

export function saveStoredSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed saving settings:', err);
  }
}
