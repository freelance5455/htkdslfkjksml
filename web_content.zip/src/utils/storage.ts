import {
  Transaction,
  Category,
  MonthlyBudget,
  ShoppingItem,
  SecuritySettings,
  AppSettings,
  BackupSyncConfig,
  Account,
  UserProfile,
  AuditHistoryLog,
  FinancialGoal,
} from '../types';
import {
  DEFAULT_CATEGORIES,
  INITIAL_TRANSACTIONS,
  INITIAL_SHOPPING_ITEMS,
  getInitialBudget,
  DEFAULT_ACCOUNTS,
  DEFAULT_USER_PROFILE,
  INITIAL_GOALS,
} from './constants';
import { encryptData, decryptData, verifyPin } from './crypto';

export { DEFAULT_ACCOUNTS, DEFAULT_USER_PROFILE };

const memoryStore = new Map<string, string>();

export const safeStorage = {
  getItem(key: string): string | null {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.getItem(key);
      }
    } catch {
      // Fallback if localStorage is blocked in iframe sandbox
    }
    return memoryStore.get(key) ?? null;
  },
  setItem(key: string, value: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(key, value);
      }
    } catch {
      // Fallback if localStorage quota is exceeded or blocked
    }
    memoryStore.set(key, value);
  },
  removeItem(key: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(key);
      }
    } catch {
      // Fallback if localStorage is blocked
    }
    memoryStore.delete(key);
  },
};

const STORAGE_KEYS = {
  TRANSACTIONS: 'tt_transactions_v1',
  CATEGORIES: 'tt_categories_v1',
  BUDGETS: 'tt_budgets_v1',
  GOALS: 'tt_goals_v1',
  SHOPPING: 'tt_shopping_v1',
  SECURITY: 'tt_security_v1',
  SETTINGS: 'tt_settings_v1',
  AUTO_BACKUPS: 'tt_autobackups_v1',
  ACCOUNTS: 'tt_accounts_v1',
  USER_PROFILE: 'tt_user_profile_v1',
  AUDIT_LOGS: 'tt_audit_logs_v1',
};

export interface ExportDataEnvelope {
  appName: string;
  version: string;
  exportedAt: string;
  transactions: Transaction[];
  categories: Category[];
  budgets: MonthlyBudget[];
  goals?: FinancialGoal[];
  shoppingItems: ShoppingItem[];
  settings: AppSettings;
  accounts?: Account[];
  userProfile?: UserProfile;
  auditLogs?: AuditHistoryLog[];
}

// Default Security settings
export const DEFAULT_SECURITY_SETTINGS: SecuritySettings = {
  isPinEnabled: false,
  pinHash: '',
  isPatternEnabled: false,
  patternHash: '',
  activeLockType: 'pin',
  is2FAEnabled: false,
  autoLockMinutes: 5,
  isDataEncrypted: true,
};

// Default Backup & Sync settings
export const DEFAULT_BACKUP_SYNC_CONFIG: BackupSyncConfig = {
  connected: false,
  provider: 'google_drive',
  accountEmail: '',
  folderName: 'TakaTracker_Backups',
  syncInterval: '1h',
  isAutoSyncActive: true,
  lastSyncStatus: 'idle',
  syncedItemsCount: 0,
  wifiOnly: false,
};

// Default App settings
export const DEFAULT_APP_SETTINGS: AppSettings = {
  language: 'en',
  useBanglaDigits: false,
  currencySymbol: '৳',
  themeMode: 'light',
  themeAccent: 'green',
  secondaryAccent: 'cyan',
  accentPercentage: 50,
  themeShade: 50,
  fontFamily: 'system',
  fontSize: 'medium',
  fontWeight: 'medium',
  googleDriveConnected: false,
  autoBackupIntervalDays: 1,
  backupSyncConfig: DEFAULT_BACKUP_SYNC_CONFIG,
};

export const storage = {
  // Transactions
  getTransactions(): Transaction[] {
    const raw = safeStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (!raw) {
      this.saveTransactions(INITIAL_TRANSACTIONS);
      return INITIAL_TRANSACTIONS;
    }
    const decrypted = decryptData<Transaction[]>(raw);
    if (!decrypted || !Array.isArray(decrypted)) {
      return INITIAL_TRANSACTIONS;
    }

    // Deduplicate by ID to guarantee unique keys
    const seenIds = new Set<string>();
    const uniqueTxs: Transaction[] = [];
    let hadDuplicates = false;

    for (const tx of decrypted) {
      if (tx && tx.id) {
        if (!seenIds.has(tx.id)) {
          seenIds.add(tx.id);
          uniqueTxs.push(tx);
        } else {
          hadDuplicates = true;
        }
      }
    }

    // Check if receivable or payable transactions exist; if not, merge default samples
    const hasReceivableOrPayable = uniqueTxs.some(
      (tx) =>
        tx.accountId === 'acc_receivable' ||
        tx.accountId === 'acc_payable' ||
        tx.fromAccountId === 'acc_receivable' ||
        tx.fromAccountId === 'acc_payable' ||
        tx.toAccountId === 'acc_receivable' ||
        tx.toAccountId === 'acc_payable' ||
        (tx.note && (tx.note.includes('Receivable') || tx.note.includes('Payable') || tx.note.includes('দেনাদার') || tx.note.includes('পাওনাদার')))
    );

    let finalTxs = uniqueTxs;
    if (!hasReceivableOrPayable) {
      const extraTxs = INITIAL_TRANSACTIONS.filter((tx) => !seenIds.has(tx.id) && (tx.id === 'tx_rec_1' || tx.id === 'tx_pay_1'));
      if (extraTxs.length > 0) {
        finalTxs = [...uniqueTxs, ...extraTxs];
        hadDuplicates = true;
      }
    }

    if (hadDuplicates) {
      this.saveTransactions(finalTxs);
    }

    return finalTxs;
  },

  saveTransactions(transactions: Transaction[]): void {
    const encrypted = encryptData(transactions);
    safeStorage.setItem(STORAGE_KEYS.TRANSACTIONS, encrypted);
    this.createAutoBackupSnapshot();
  },

  // Categories
  getCategories(): Category[] {
    const raw = safeStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!raw) {
      this.saveCategories(DEFAULT_CATEGORIES);
      return DEFAULT_CATEGORIES;
    }
    const decrypted = decryptData<Category[]>(raw);
    if (!decrypted || !Array.isArray(decrypted) || decrypted.length === 0) {
      return DEFAULT_CATEGORIES;
    }
    return decrypted;
  },

  saveCategories(categories: Category[]): void {
    const encrypted = encryptData(categories);
    safeStorage.setItem(STORAGE_KEYS.CATEGORIES, encrypted);
  },

  // Budgets
  getBudgets(): MonthlyBudget[] {
    const raw = safeStorage.getItem(STORAGE_KEYS.BUDGETS);
    if (!raw) {
      const initBudget = getInitialBudget();
      this.saveBudgets([initBudget]);
      return [initBudget];
    }
    const decrypted = decryptData<MonthlyBudget[]>(raw);
    if (!decrypted || !Array.isArray(decrypted) || decrypted.length === 0) {
      return [getInitialBudget()];
    }
    return decrypted;
  },

  saveBudgets(budgets: MonthlyBudget[]): void {
    const encrypted = encryptData(budgets);
    safeStorage.setItem(STORAGE_KEYS.BUDGETS, encrypted);
  },

  // Financial Goals
  getGoals(): FinancialGoal[] {
    const raw = safeStorage.getItem(STORAGE_KEYS.GOALS);
    if (!raw) {
      this.saveGoals(INITIAL_GOALS);
      return INITIAL_GOALS;
    }
    const decrypted = decryptData<FinancialGoal[]>(raw);
    if (!decrypted || !Array.isArray(decrypted) || decrypted.length === 0) {
      return INITIAL_GOALS;
    }
    return decrypted;
  },

  saveGoals(goals: FinancialGoal[]): void {
    const encrypted = encryptData(goals);
    safeStorage.setItem(STORAGE_KEYS.GOALS, encrypted);
  },

  // Shopping Items
  getShoppingItems(): ShoppingItem[] {
    const raw = safeStorage.getItem(STORAGE_KEYS.SHOPPING);
    if (!raw) {
      this.saveShoppingItems(INITIAL_SHOPPING_ITEMS);
      return INITIAL_SHOPPING_ITEMS;
    }
    const decrypted = decryptData<ShoppingItem[]>(raw);
    if (!decrypted || !Array.isArray(decrypted)) {
      return INITIAL_SHOPPING_ITEMS;
    }
    return decrypted;
  },

  saveShoppingItems(items: ShoppingItem[]): void {
    const encrypted = encryptData(items);
    safeStorage.setItem(STORAGE_KEYS.SHOPPING, encrypted);
  },

  // Security Settings
  getSecuritySettings(): SecuritySettings {
    const raw = safeStorage.getItem(STORAGE_KEYS.SECURITY);
    if (!raw) return DEFAULT_SECURITY_SETTINGS;
    const decrypted = decryptData<SecuritySettings>(raw);
    if (decrypted) {
      if (
        decrypted.pinHash &&
        (verifyPin('1234', decrypted.pinHash) || verifyPin('১২৩৪', decrypted.pinHash))
      ) {
        decrypted.isPinEnabled = false;
        decrypted.pinHash = '';
        this.saveSecuritySettings(decrypted);
      }
    }
    return decrypted || DEFAULT_SECURITY_SETTINGS;
  },

  saveSecuritySettings(settings: SecuritySettings): void {
    const encrypted = encryptData(settings);
    safeStorage.setItem(STORAGE_KEYS.SECURITY, encrypted);
  },

  // App Settings
  getAppSettings(): AppSettings {
    const raw = safeStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return DEFAULT_APP_SETTINGS;
    const decrypted = decryptData<AppSettings>(raw);
    return decrypted || DEFAULT_APP_SETTINGS;
  },

  saveAppSettings(settings: AppSettings): void {
    const encrypted = encryptData(settings);
    safeStorage.setItem(STORAGE_KEYS.SETTINGS, encrypted);
  },

  // Accounts & Double Entry
  getAccounts(): Account[] {
    const raw = safeStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    if (!raw) {
      this.saveAccounts(DEFAULT_ACCOUNTS);
      return DEFAULT_ACCOUNTS;
    }
    const decrypted = decryptData<Account[]>(raw);
    if (!decrypted || !Array.isArray(decrypted) || decrypted.length === 0) {
      return DEFAULT_ACCOUNTS;
    }
    let updated = false;
    const sanitized = decrypted.map((acc) => {
      let changed = false;
      let newAcc = { ...acc };

      if (newAcc.id === 'acc_cash' && (newAcc.nameEnglish === 'Cash in Hand' || !newAcc.nameEnglish)) {
        newAcc.nameEnglish = 'Cash';
        changed = true;
      } else if (newAcc.nameEnglish === 'Cash in Hand') {
        newAcc.nameEnglish = 'Cash';
        changed = true;
      }

      if (
        newAcc.id === 'acc_bkash' &&
        (newAcc.nameEnglish === 'bKash Wallet' ||
          newAcc.nameEnglish === 'bKash wallet' ||
          newAcc.nameEnglish === 'bkash wallet' ||
          !newAcc.nameEnglish)
      ) {
        newAcc.nameEnglish = 'bkash';
        changed = true;
      } else if (
        newAcc.nameEnglish === 'bKash Wallet' ||
        newAcc.nameEnglish === 'bKash wallet' ||
        newAcc.nameEnglish === 'bkash wallet'
      ) {
        newAcc.nameEnglish = 'bkash';
        changed = true;
      }

      if (
        newAcc.id === 'acc_nagad' &&
        (newAcc.nameEnglish === 'Nagad Wallet' ||
          newAcc.nameEnglish === 'Nagad wallet' ||
          newAcc.nameEnglish === 'nagad wallet' ||
          !newAcc.nameEnglish)
      ) {
        newAcc.nameEnglish = 'Nagad';
        changed = true;
      } else if (
        newAcc.nameEnglish === 'Nagad Wallet' ||
        newAcc.nameEnglish === 'Nagad wallet' ||
        newAcc.nameEnglish === 'nagad wallet'
      ) {
        newAcc.nameEnglish = 'Nagad';
        changed = true;
      }

      if (
        newAcc.id === 'acc_receivable' &&
        (newAcc.nameEnglish === 'Loans Given (Receivables)' ||
          newAcc.nameEnglish === 'Receivable' ||
          !newAcc.nameEnglish ||
          newAcc.openingBalance === 5000)
      ) {
        newAcc.nameEnglish = 'Receivables';
        if (newAcc.openingBalance === 5000) {
          newAcc.openingBalance = 0;
        }
        changed = true;
      } else if (
        newAcc.nameEnglish === 'Receivable' ||
        newAcc.nameEnglish === 'Loans Given (Receivables)'
      ) {
        newAcc.nameEnglish = 'Receivables';
        changed = true;
      }

      if (
        newAcc.id === 'acc_payable' &&
        (newAcc.nameEnglish === 'Loans Taken (Payables / Debt)' ||
          newAcc.nameEnglish === 'Payable' ||
          !newAcc.nameEnglish ||
          newAcc.openingBalance === 3000)
      ) {
        newAcc.nameEnglish = 'Payables';
        if (newAcc.openingBalance === 3000) {
          newAcc.openingBalance = 0;
        }
        changed = true;
      } else if (
        newAcc.nameEnglish === 'Payable' ||
        newAcc.nameEnglish === 'Loans Taken (Payables / Debt)'
      ) {
        newAcc.nameEnglish = 'Payables';
        changed = true;
      }

      if (changed) {
        updated = true;
      }
      return newAcc;
    });
    if (updated) {
      this.saveAccounts(sanitized);
    }
    return sanitized;
  },

  saveAccounts(accounts: Account[]): void {
    const encrypted = encryptData(accounts);
    safeStorage.setItem(STORAGE_KEYS.ACCOUNTS, encrypted);
  },

  // User Profile
  getUserProfile(): UserProfile {
    const raw = safeStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (!raw) {
      return DEFAULT_USER_PROFILE;
    }
    const decrypted = decryptData<UserProfile>(raw);
    if (decrypted && (decrypted.profilePassword === '1234' || decrypted.profilePassword === '১২৩৪')) {
      decrypted.profilePassword = '';
      this.saveUserProfile(decrypted);
    }
    return decrypted || DEFAULT_USER_PROFILE;
  },

  saveUserProfile(profile: UserProfile): void {
    const encrypted = encryptData(profile);
    safeStorage.setItem(STORAGE_KEYS.USER_PROFILE, encrypted);
  },

  // Audit Logs (History of modified & deleted transactions)
  getAuditLogs(): AuditHistoryLog[] {
    const raw = safeStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
    if (!raw) return [];
    const decrypted = decryptData<AuditHistoryLog[]>(raw);
    if (!decrypted || !Array.isArray(decrypted)) return [];
    return decrypted;
  },

  saveAuditLogs(logs: AuditHistoryLog[]): void {
    const encrypted = encryptData(logs);
    safeStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, encrypted);
  },

  clearAuditLogs(): void {
    safeStorage.removeItem(STORAGE_KEYS.AUDIT_LOGS);
  },

  addAuditLog(entry: Omit<AuditHistoryLog, 'id' | 'timestamp' | 'dateTimeFormatted'>): void {
    const logs = this.getAuditLogs();
    const newLog: AuditHistoryLog = {
      ...entry,
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      dateTimeFormatted: new Date().toLocaleString('bn-BD', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }),
    };
    const updated = [newLog, ...logs].slice(0, 200); // keep last 200 logs
    this.saveAuditLogs(updated);
  },

  // Calculate current balances for all accounts based on opening balances & double-entry transactions
  calculateAccountBalances(accounts: Account[], transactions: Transaction[]): Account[] {
    const safeAccounts = Array.isArray(accounts) ? accounts : [];
    const safeTransactions = Array.isArray(transactions) ? transactions : [];
    return safeAccounts.map((account) => {
      let balance = Number(account.openingBalance) || 0;

      for (const tx of safeTransactions) {
        const txAmount = Number(tx.amount) || 0;

        // Income into this account
        if (tx.type === 'income' && tx.accountId === account.id) {
          if (account.type === 'payable') {
            // Borrowed money or increased debt liability (+)
            balance += txAmount;
          } else if (account.type === 'receivable') {
            // Repayment received directly into receivable account -> reduces what debtor owes (-)
            balance -= txAmount;
          } else {
            // Standard wallet / cash / bank income (+)
            balance += txAmount;
          }
        }

        // Expense from this account
        if (tx.type === 'expense' && tx.accountId === account.id) {
          if (account.type === 'payable') {
            // CRITICAL FIX: Credit Purchase (ধারে পণ্য কেনা / বাকি খরচ)
            // When an expense is charged to a payable account (creditor/supplier/payables),
            // goods were bought on credit, so the debt liability INCREASES (+)!
            balance += txAmount;
          } else if (account.type === 'receivable') {
            // Credit sale or loan given to debtor -> receivable balance INCREASES (+)
            balance += txAmount;
          } else {
            // Standard wallet / cash / bank expense -> money spent (-)
            balance -= txAmount;
          }
        }

        // Transfer: from account
        if (tx.type === 'transfer' && tx.fromAccountId === account.id) {
          if (account.type === 'payable') {
            balance += txAmount;
          } else {
            balance -= txAmount;
          }
        }

        // Transfer: to account
        if (tx.type === 'transfer' && tx.toAccountId === account.id) {
          if (account.type === 'payable') {
            balance -= txAmount;
          } else {
            balance += txAmount;
          }
        }

        // Non-transfer transaction linked to this ledger account
        if (tx.type !== 'transfer' && tx.ledgerAccountId === account.id && tx.accountId !== account.id) {
          if (account.type === 'receivable') {
            if (tx.type === 'expense') {
              // Loan/advance given to debtor -> receivable balance increases
              balance += txAmount;
            } else if (tx.type === 'income') {
              // Repayment received from debtor -> receivable balance decreases
              balance -= txAmount;
            }
          } else if (account.type === 'payable') {
            if (tx.type === 'income') {
              // Borrowed money from creditor -> payable balance increases
              balance += txAmount;
            } else if (tx.type === 'expense') {
              // Debt repaid to creditor -> payable balance decreases
              balance -= txAmount;
            }
          }
        }
      }

      return {
        ...account,
        currentBalance: balance,
      };
    });
  },

  // Export full JSON file
  exportBackupFile(): ExportDataEnvelope {
    return {
      appName: 'Onu Finance',
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      transactions: this.getTransactions(),
      categories: this.getCategories(),
      budgets: this.getBudgets(),
      shoppingItems: this.getShoppingItems(),
      settings: this.getAppSettings(),
      accounts: this.getAccounts(),
      userProfile: this.getUserProfile(),
      auditLogs: this.getAuditLogs(),
    };
  },

  // Import full JSON file
  importBackupFile(data: ExportDataEnvelope): boolean {
    if (!data || !Array.isArray(data.transactions) || !Array.isArray(data.categories)) {
      return false;
    }
    this.saveTransactions(data.transactions);
    this.saveCategories(data.categories);
    if (Array.isArray(data.budgets)) this.saveBudgets(data.budgets);
    if (Array.isArray(data.shoppingItems)) this.saveShoppingItems(data.shoppingItems);
    if (Array.isArray(data.accounts)) this.saveAccounts(data.accounts);
    if (data.userProfile) this.saveUserProfile(data.userProfile);
    if (Array.isArray(data.auditLogs)) this.saveAuditLogs(data.auditLogs);
    if (data.settings) this.saveAppSettings({ ...this.getAppSettings(), ...data.settings });
    return true;
  },

  // Local Snapshot Auto-backup
  createAutoBackupSnapshot(): void {
    try {
      const snapshot = this.exportBackupFile();
      const rawBackups = safeStorage.getItem(STORAGE_KEYS.AUTO_BACKUPS);
      let backupsList: { timestamp: number; dateStr: string; data: ExportDataEnvelope }[] = [];
      if (rawBackups) {
        backupsList = JSON.parse(rawBackups);
      }
      // Keep last 5 snapshots
      backupsList.unshift({
        timestamp: Date.now(),
        dateStr: new Date().toLocaleString('bn-BD'),
        data: snapshot,
      });
      backupsList = backupsList.slice(0, 5);
      safeStorage.setItem(STORAGE_KEYS.AUTO_BACKUPS, JSON.stringify(backupsList));
    } catch (err) {
      console.warn('Auto backup snapshot failed:', err);
    }
  },

  getAutoBackupSnapshots() {
    const raw = safeStorage.getItem(STORAGE_KEYS.AUTO_BACKUPS);
    if (!raw) return [];
    try {
      return JSON.parse(raw) as { timestamp: number; dateStr: string; data: ExportDataEnvelope }[];
    } catch {
      return [];
    }
  },
};
