import { CalculatedProduct, Product, StoreData, Transaction, WidgetItem, PeriodSummary } from '../types';
import { getTodayIso } from './formatters';

export const DEFAULT_WIDGETS: WidgetItem[] = [
  { id: 'items', title: 'Total Products', on: true },
  { id: 'units', title: 'Units in Stock', on: true },
  { id: 'value', title: 'Inventory Valuation', on: true },
  { id: 'buy', title: 'Total Purchases', on: true },
  { id: 'rev', title: 'Total Revenue', on: true },
  { id: 'cost', title: 'Cost of Goods Sold', on: true },
  { id: 'profit', title: 'Net Profit', on: true },
  { id: 'low', title: 'Low Stock Alerts', on: true },
  { id: 'today', title: "Today's Profit", on: true },
  { id: 'month', title: "This Month's Profit", on: true },
];

export const DEFAULT_UNITS = ['Pcs', 'Kg', 'Box', 'Bag', 'Ltr', 'Dozen', 'Pack', 'Meter'];

export const DEFAULT_CATEGORIES = ['Grocery', 'Stationery', 'Electrical', 'Electronics', 'Household', 'Apparel'];

export function createSeedData(): StoreData {
  const products: Product[] = [
    { id: 'p1', name: 'Basmati Rice Royal 5kg', sku: '890103001', cat: 'Grocery', unit: 'Bag', open: 80, cost: 260, price: 340, min: 25 },
    { id: 'p2', name: 'Refined Sugar 1kg', sku: '890103002', cat: 'Grocery', unit: 'Kg', open: 120, cost: 38, price: 48, min: 30 },
    { id: 'p3', name: 'Hardcover Notebook A4', sku: '890103003', cat: 'Stationery', unit: 'Pcs', open: 65, cost: 32, price: 55, min: 20 },
    { id: 'p4', name: 'Ballpoint Pen Box (20s)', sku: '890103004', cat: 'Stationery', unit: 'Box', open: 40, cost: 65, price: 95, min: 15 },
    { id: 'p5', name: 'Philips LED Bulb 9W Cool', sku: '890103005', cat: 'Electrical', unit: 'Pcs', open: 90, cost: 72, price: 120, min: 25 },
    { id: 'p6', name: 'Fast USB-C Nylon Cable', sku: '890103006', cat: 'Electronics', unit: 'Pcs', open: 45, cost: 95, price: 180, min: 15 },
    { id: 'p7', name: 'Wireless Bluetooth Earphones', sku: '890103007', cat: 'Electronics', unit: 'Pcs', open: 22, cost: 220, price: 399, min: 10 },
    { id: 'p8', name: 'Aroma Detergent Powder 1kg', sku: '890103008', cat: 'Household', unit: 'Pcs', open: 55, cost: 88, price: 130, min: 20 },
    { id: 'p9', name: 'Extra Virgin Olive Oil 500ml', sku: '890103009', cat: 'Grocery', unit: 'Ltr', open: 18, cost: 310, price: 440, min: 8 },
  ];

  const txns: Transaction[] = [];
  let txnId = 1;
  const now = new Date();

  // Pseudo-random deterministic generator for consistent rich demo
  let seed = 42;
  const rnd = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };

  const sampleCustomers = ['Ramesh Sharma', 'Priya Patel', 'Amit Verma', 'Sunita Rao', 'Quick Mart', 'Metro Corner', 'Walk-in Customer'];
  const sampleSuppliers = ['National Wholesale Dist.', 'Apex Supplies Ltd', 'Global Goods Hub', 'City Super Distributors'];

  for (let d = 120; d >= 0; d--) {
    const dt = new Date(now);
    dt.setDate(dt.getDate() - d);
    const dateStr = dt.toISOString().slice(0, 10);
    const timeStr = `${String(9 + Math.floor(rnd() * 11)).padStart(2, '0')}:${String(Math.floor(rnd() * 60)).padStart(2, '0')}`;

    products.forEach((p) => {
      // Occasional restock
      if (rnd() < 0.05) {
        const qty = Math.round(15 + rnd() * 35);
        const rate = Math.round(p.cost * (0.95 + rnd() * 0.08));
        txns.push({
          id: `t_${txnId++}`,
          date: dateStr,
          time: timeStr,
          pid: p.id,
          type: 'P',
          qty,
          rate,
          cust: sampleSuppliers[Math.floor(rnd() * sampleSuppliers.length)],
          paymentMethod: rnd() < 0.6 ? 'upi' : 'credit',
        });
      }

      // Frequent daily sales
      if (rnd() < 0.38) {
        const qty = Math.round(1 + rnd() * 5);
        const rate = Math.round(p.price * (0.98 + rnd() * 0.05));
        txns.push({
          id: `t_${txnId++}`,
          date: dateStr,
          time: timeStr,
          pid: p.id,
          type: 'S',
          qty,
          rate,
          cust: sampleCustomers[Math.floor(rnd() * sampleCustomers.length)],
          paymentMethod: rnd() < 0.5 ? 'cash' : rnd() < 0.85 ? 'upi' : 'card',
        });
      }
    });
  }

  return {
    co: 'Apex Retail & Trading Co.',
    tagline: 'Wholesale & Retail Inventory',
    phone: '+91 98765 43210',
    address: 'Shop 12, Market Square, Commercial Hub',
    cur: '₹',
    units: DEFAULT_UNITS,
    cats: DEFAULT_CATEGORIES,
    widgets: DEFAULT_WIDGETS,
    products,
    txns,
    theme: 'light',
    soundEnabled: true,
    hapticsEnabled: true,
  };
}

const STORAGE_KEY = 'stockmgr_android_v3';

export function normalizeStoreData(data: Partial<StoreData>): StoreData {
  const seed = createSeedData();
  const cur = data.cur || seed.cur;
  const products = Array.isArray(data.products) ? data.products : seed.products;
  const txns = Array.isArray(data.txns) ? data.txns : seed.txns;

  const cats = Array.isArray(data.cats) && data.cats.length
    ? Array.from(new Set([...data.cats, ...products.map((p) => p.cat).filter(Boolean)]))
    : Array.from(new Set([...DEFAULT_CATEGORIES, ...products.map((p) => p.cat).filter(Boolean)]));

  const units = Array.isArray(data.units) && data.units.length
    ? Array.from(new Set([...data.units, ...products.map((p) => p.unit).filter(Boolean)]))
    : Array.from(new Set([...DEFAULT_UNITS, ...products.map((p) => p.unit).filter(Boolean)]));

  const widgets = (data.widgets && Array.isArray(data.widgets))
    ? data.widgets
    : DEFAULT_WIDGETS;

  return {
    co: data.co || seed.co,
    tagline: data.tagline ?? seed.tagline,
    phone: data.phone ?? seed.phone,
    address: data.address ?? seed.address,
    cur,
    units: units.length ? units : DEFAULT_UNITS,
    cats: cats.length ? cats : DEFAULT_CATEGORIES,
    widgets,
    products,
    txns,
    theme: data.theme || 'light',
    soundEnabled: data.soundEnabled !== false,
    hapticsEnabled: data.hapticsEnabled !== false,
  };
}

export function loadStoreData(): StoreData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return normalizeStoreData(parsed);
    }
    // Check legacy storage
    const legacy = localStorage.getItem('stockmgr2') || localStorage.getItem('stockmgr1');
    if (legacy) {
      const parsed = JSON.parse(legacy);
      return normalizeStoreData(parsed);
    }
  } catch (err) {
    console.error('Failed to load store data from localStorage', err);
  }
  return createSeedData();
}

export function saveStoreData(data: StoreData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error('Failed to save store data to localStorage', err);
  }
}

export function clearStorageData(keepSettings: boolean = true): StoreData {
  const current = loadStoreData();
  const cleared: StoreData = {
    ...current,
    products: [],
    txns: [],
    cats: keepSettings && current.cats.length ? current.cats : DEFAULT_CATEGORIES,
    units: keepSettings && current.units.length ? current.units : DEFAULT_UNITS,
  };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cleared));
    // Remove old keys so they don't resurrect old data
    localStorage.removeItem('stockmgr2');
    localStorage.removeItem('stockmgr1');
  } catch (err) {
    console.error('Failed to clear storage data', err);
  }
  return cleared;
}

// Calculate individual product stock metrics & profits
export function calculateInventory(store: StoreData): Record<string, CalculatedProduct> {
  const map: Record<string, CalculatedProduct> = {};

  store.products.forEach((p) => {
    map[p.id] = {
      p,
      qty: Number(p.open || 0),
      inq: 0,
      sold: 0,
      rev: 0,
      cogs: 0,
      buy: 0,
      stockValue: 0,
      profit: 0,
      isLowStock: false,
    };
  });

  store.txns.forEach((t) => {
    const item = map[t.pid];
    if (!item) return;

    const qty = Number(t.qty || 0);
    const rate = Number(t.rate || 0);

    if (t.type === 'P') {
      item.qty += qty;
      item.inq += qty;
      item.buy += qty * rate;
    } else {
      item.qty -= qty;
      item.sold += qty;
      item.rev += qty * rate;
      item.cogs += qty * item.p.cost;
    }
  });

  Object.values(map).forEach((item) => {
    item.stockValue = item.qty * item.p.cost;
    item.profit = item.rev - item.cogs;
    item.isLowStock = item.qty <= item.p.min;
  });

  return map;
}

// Group transactions by date periods
export function aggregatePeriod(
  store: StoreData,
  period: 'day' | 'month' | 'year'
): Array<{ key: string; buy: number; rev: number; cogs: number; pr: number; margin: number }> {
  const calc = calculateInventory(store);
  const groups: Record<string, { buy: number; rev: number; cogs: number }> = {};

  store.txns.forEach((t) => {
    const item = calc[t.pid];
    if (!item) return;

    let key = t.date;
    if (period === 'month') {
      key = t.date.slice(0, 7); // YYYY-MM
    } else if (period === 'year') {
      key = t.date.slice(0, 4); // YYYY
    }

    if (!groups[key]) {
      groups[key] = { buy: 0, rev: 0, cogs: 0 };
    }

    const qty = Number(t.qty || 0);
    const rate = Number(t.rate || 0);

    if (t.type === 'P') {
      groups[key].buy += qty * rate;
    } else {
      groups[key].rev += qty * rate;
      groups[key].cogs += qty * item.p.cost;
    }
  });

  return Object.keys(groups)
    .sort()
    .map((k) => {
      const g = groups[k];
      const pr = g.rev - g.cogs;
      const margin = g.rev > 0 ? (pr / g.rev) * 100 : 0;
      return {
        key: k,
        buy: g.buy,
        rev: g.rev,
        cogs: g.cogs,
        pr,
        margin,
      };
    });
}

// Get aggregate metrics for a specific date prefix (e.g. today 'YYYY-MM-DD' or month 'YYYY-MM')
export function getPrefixMetrics(store: StoreData, prefix: string): PeriodSummary {
  const calc = calculateInventory(store);
  let rev = 0;
  let cogs = 0;
  let buy = 0;

  store.txns.forEach((t) => {
    if (!t.date.startsWith(prefix)) return;
    const item = calc[t.pid];
    if (!item) return;

    const qty = Number(t.qty || 0);
    const rate = Number(t.rate || 0);

    if (t.type === 'P') {
      buy += qty * rate;
    } else {
      rev += qty * rate;
      cogs += qty * item.p.cost;
    }
  });

  return { rev, cogs, buy, pr: rev - cogs };
}

// Export CSV string for Products
export function exportProductsCsv(store: StoreData): string {
  const calc = calculateInventory(store);
  const headers = ['ID', 'Name', 'Barcode/SKU', 'Category', 'Unit', 'Opening Stock', 'Current Stock', 'Cost Price', 'Selling Price', 'Reorder Level', 'Inventory Value'];
  const rows = store.products.map((p) => {
    const c = calc[p.id];
    return [
      `"${p.id}"`,
      `"${p.name.replace(/"/g, '""')}"`,
      `"${(p.sku || '').replace(/"/g, '""')}"`,
      `"${p.cat.replace(/"/g, '""')}"`,
      `"${p.unit}"`,
      p.open,
      c ? c.qty : p.open,
      p.cost,
      p.price,
      p.min,
      c ? c.stockValue : p.open * p.cost,
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}

// Export CSV string for Transactions
export function exportTransactionsCsv(store: StoreData): string {
  const productMap = Object.fromEntries(store.products.map((p) => [p.id, p]));
  const headers = ['ID', 'Date', 'Time', 'Type', 'Item Name', 'Category', 'Customer/Supplier', 'Payment Method', 'Quantity', 'Rate', 'Total Amount'];
  const rows = store.txns.map((t) => {
    const p = productMap[t.pid];
    return [
      `"${t.id}"`,
      `"${t.date}"`,
      `"${t.time || ''}"`,
      `"${t.type === 'P' ? 'Stock In (Purchase)' : 'Stock Out (Sale)'}"`,
      `"${(p ? p.name : 'Unknown').replace(/"/g, '""')}"`,
      `"${(p ? p.cat : '').replace(/"/g, '""')}"`,
      `"${(t.cust || '').replace(/"/g, '""')}"`,
      `"${t.paymentMethod || 'cash'}"`,
      t.qty,
      t.rate,
      t.qty * t.rate,
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}
