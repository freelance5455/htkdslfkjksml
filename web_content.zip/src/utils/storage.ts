import type { AppDataState, ExpenseCategory } from '../types';
import { getLeaveYearForDate } from './calculations';

export const STORAGE_KEY = 'saif_ullah_ppm_data_v1';
export const SAFETY_BACKUP_KEY = 'saif_ullah_ppm_safety_backup_v1';
export const CURRENT_SCHEMA_VERSION = 1;

export function generateId(prefix = 'rec'): string {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}_${Date.now().toString(36)}_${rand}`;
}

export function getTodayIso(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export const DEFAULT_EXPENSE_CATEGORIES: ExpenseCategory[] = [
  'Grocery',
  'Electricity',
  'Gas',
  'Water',
  'Rent',
  'Medical',
  'Transport',
  'Education',
  'Mobile',
  'Shopping',
  'Other',
].map((name, idx) => ({
  id: `cat_${idx + 1}`,
  name,
  active: true,
  order: idx + 1,
}));

export function createInitialState(): AppDataState {
  const today = getTodayIso();
  const currentLeaveYear = getLeaveYearForDate(today);

  return {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    settings: {
      appName: 'Saif Ullah',
      appSubtitle: 'Personal & Professional Manager',
      viewMode: 'desktop',
      theme: 'navy-emerald',
      language: 'en',
      dateFormat: 'DD-MMM-YYYY',
      currencyLabel: 'PKR',
      maundToKg: 40,
      allowNegativePurchase: false,
      defaultCL: 10,
      defaultSL: 8,
      cplExpiryDays: 40,
      allowNegativeLeaveOverride: false,
      activeLeaveYear: currentLeaveYear,
      confirmBeforeDelete: true,
      defaultEmployeeName: 'Saif Ullah',
      dashboardCards: [
        {
          id: 'card_1',
          title: 'Home Expenses',
          primaryMetric: 'home_expenses',
          secondaryMetric: 'purchase_total_maund',
        },
        {
          id: 'card_2',
          title: 'Factory Leave Balance',
          primaryMetric: 'factory_leave_total',
          secondaryMetric: 'factory_cpl_avail',
        },
        {
          id: 'card_3',
          title: 'Personal Loan & Committee',
          primaryMetric: 'personal_loan_payable',
          secondaryMetric: 'committee_balance',
        },
        {
          id: 'card_4',
          title: 'Total Records',
          primaryMetric: 'total_records',
          secondaryMetric: 'office_tasks_open',
        },
      ],
      quickOverviewItems: [
        {
          id: 'qo_1',
          label: 'Atta / Purchase',
          targetSection: 'home',
          targetTab: 'purchases',
          metricKey: 'purchase_total_maund',
          visible: true,
        },
        {
          id: 'qo_2',
          label: 'Household Expenses',
          targetSection: 'home',
          targetTab: 'expenses',
          metricKey: 'home_expenses',
          visible: true,
        },
        {
          id: 'qo_3',
          label: 'Factory Leave',
          targetSection: 'factory',
          targetTab: 'leave',
          metricKey: 'factory_leave_total',
          visible: true,
        },
        {
          id: 'qo_4',
          label: 'Loan Payable',
          targetSection: 'personal',
          targetTab: 'loan',
          metricKey: 'personal_loan_payable',
          visible: true,
        },
        {
          id: 'qo_5',
          label: 'Committee',
          targetSection: 'personal',
          targetTab: 'committee',
          metricKey: 'committee_balance',
          visible: true,
        },
      ],
      builtInModuleVisibility: {
        home: true,
        factory: true,
        personal: true,
      },
    },
    purchases: [],
    expenseCategories: DEFAULT_EXPENSE_CATEGORIES,
    expenses: [],
    leaves: [],
    leaveYearOpenings: [
      {
        leaveYear: currentLeaveYear,
        clEntitlement: 10,
        slEntitlement: 8,
        clOpening: 0,
        slOpening: 0,
        cplOpening: 0,
      },
    ],
    tasks: [],
    loanPersons: [],
    loanTransactions: [],
    committees: [],
    committeeTransactions: [],
    customModules: [],
    customRecords: [],
    customReports: [],
    recycleBin: [],
    auditLog: [],
  };
}

export function migrateState(raw: unknown): AppDataState {
  const base = createInitialState();
  if (!raw || typeof raw !== 'object') return base;
  const obj = raw as Partial<AppDataState>;

  return {
    ...base,
    ...obj,
    schemaVersion: CURRENT_SCHEMA_VERSION,
    settings: {
      ...base.settings,
      ...(obj.settings || {}),
      builtInModuleVisibility: {
        ...base.settings.builtInModuleVisibility,
        ...(obj.settings?.builtInModuleVisibility || {}),
      },
      dashboardCards:
        Array.isArray(obj.settings?.dashboardCards) && obj.settings.dashboardCards.length > 0
          ? obj.settings.dashboardCards
          : base.settings.dashboardCards,
      quickOverviewItems:
        Array.isArray(obj.settings?.quickOverviewItems) && obj.settings.quickOverviewItems.length > 0
          ? obj.settings.quickOverviewItems
          : base.settings.quickOverviewItems,
    },
    purchases: Array.isArray(obj.purchases) ? obj.purchases : [],
    expenseCategories:
      Array.isArray(obj.expenseCategories) && obj.expenseCategories.length > 0
        ? obj.expenseCategories
        : base.expenseCategories,
    expenses: Array.isArray(obj.expenses) ? obj.expenses : [],
    leaves: Array.isArray(obj.leaves) ? obj.leaves : [],
    leaveYearOpenings:
      Array.isArray(obj.leaveYearOpenings) && obj.leaveYearOpenings.length > 0
        ? obj.leaveYearOpenings
        : base.leaveYearOpenings,
    tasks: Array.isArray(obj.tasks) ? obj.tasks : [],
    loanPersons: Array.isArray(obj.loanPersons) ? obj.loanPersons : [],
    loanTransactions: Array.isArray(obj.loanTransactions) ? obj.loanTransactions : [],
    committees: Array.isArray(obj.committees) ? obj.committees : [],
    committeeTransactions: Array.isArray(obj.committeeTransactions)
      ? obj.committeeTransactions
      : [],
    customModules: Array.isArray(obj.customModules) ? obj.customModules : [],
    customRecords: Array.isArray(obj.customRecords) ? obj.customRecords : [],
    customReports: Array.isArray(obj.customReports) ? obj.customReports : [],
    recycleBin: Array.isArray(obj.recycleBin) ? obj.recycleBin : [],
    auditLog: Array.isArray(obj.auditLog) ? obj.auditLog : [],
  };
}

export function loadAppState(): AppDataState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialState();
    const parsed = JSON.parse(raw);
    return migrateState(parsed);
  } catch {
    return createInitialState();
  }
}

export function saveAppState(state: AppDataState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to persist app state:', err);
  }
}

export function saveSafetyBackup(state: AppDataState): void {
  try {
    localStorage.setItem(
      SAFETY_BACKUP_KEY,
      JSON.stringify({
        savedAt: new Date().toISOString(),
        data: state,
      })
    );
  } catch {
    // ignore storage quota errors on secondary backup
  }
}

export function loadSafetyBackup(): { savedAt: string; data: AppDataState } | null {
  try {
    const raw = localStorage.getItem(SAFETY_BACKUP_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed?.data) return null;
    return {
      savedAt: parsed.savedAt || '',
      data: migrateState(parsed.data),
    };
  } catch {
    return null;
  }
}

export function validateBackupPayload(raw: unknown): {
  valid: boolean;
  error?: string;
  state?: AppDataState;
  counts?: {
    purchases: number;
    expenses: number;
    leaves: number;
    tasks: number;
    loans: number;
    committees: number;
    customRecords: number;
  };
} {
  if (!raw || typeof raw !== 'object') {
    return { valid: false, error: 'Invalid JSON file: expected an object.' };
  }
  const obj = raw as Record<string, unknown>;
  const hasKnownKey =
    'settings' in obj ||
    'purchases' in obj ||
    'expenses' in obj ||
    'leaves' in obj ||
    'loanTransactions' in obj ||
    'committees' in obj;

  if (!hasKnownKey) {
    return {
      valid: false,
      error: 'This JSON file does not match the Saif Ullah Manager backup structure.',
    };
  }

  const migrated = migrateState(obj);
  return {
    valid: true,
    state: migrated,
    counts: {
      purchases: migrated.purchases.length,
      expenses: migrated.expenses.length,
      leaves: migrated.leaves.length,
      tasks: migrated.tasks.length,
      loans: migrated.loanTransactions.length,
      committees: migrated.committeeTransactions.length,
      customRecords: migrated.customRecords.length,
    },
  };
}

export function downloadTextFile(filename: string, content: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function exportToCsv(filename: string, headers: string[], rows: (string | number)[][]): void {
  const escapeCell = (val: string | number) => {
    const str = String(val ?? '');
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const csv = [
    headers.map(escapeCell).join(','),
    ...rows.map((r) => r.map(escapeCell).join(',')),
  ].join('\n');
  downloadTextFile(filename, '\uFEFF' + csv, 'text/csv;charset=utf-8;');
}
