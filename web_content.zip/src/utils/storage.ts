// Utility for robust client-side storage with IndexedDB and safe LocalStorage fallback
// Solves DOMException: QuotaExceededError when storing large images or videos in localStorage.

const DB_NAME = 'shopforge_offline_db';
const DB_VERSION = 1;
const STORE_NAME = 'key_value_store';

let dbPromise: Promise<IDBDatabase> | null = null;

function getDB(): Promise<IDBDatabase> {
  if (typeof window === 'undefined' || !window.indexedDB) {
    return Promise.reject(new Error('IndexedDB not supported'));
  }

  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME);
          }
        };

        request.onsuccess = () => {
          resolve(request.result);
        };

        request.onerror = () => {
          console.warn('[Storage] IndexedDB open error, falling back to memory/local storage', request.error);
          reject(request.error);
        };
      } catch (err) {
        reject(err);
      }
    });
  }

  return dbPromise;
}

/**
 * Save an item to IndexedDB (supports large strings, blobs, and full objects with no 5MB quota)
 */
export async function saveToIndexedDB(key: string, value: unknown): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(value, key);

      req.onsuccess = () => resolve();
      req.onerror = () => {
        console.warn(`[Storage] Failed to save key '${key}' to IndexedDB`, req.error);
        reject(req.error);
      };
    });
  } catch {
    // Graceful fallback if IndexedDB is disabled in restricted iframe
  }
}

/**
 * Load an item from IndexedDB
 */
export async function loadFromIndexedDB<T>(key: string): Promise<T | null> {
  try {
    const db = await getDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(key);

      req.onsuccess = () => {
        resolve((req.result as T) ?? null);
      };
      req.onerror = () => {
        resolve(null);
      };
    });
  } catch {
    return null;
  }
}

/**
 * Strips huge base64 strings (like raw video files or massive images) from products
 * so they easily fit inside localStorage's tiny 5MB quota without throwing QuotaExceededError.
 */
function createLightweightProducts(products: unknown): unknown {
  if (!Array.isArray(products)) return products;

  return products.map((item) => {
    if (!item || typeof item !== 'object') return item;
    const prod = { ...item } as Record<string, unknown>;

    // If videoUrl is a huge data URL (> 20KB), replace with a safe marker so localStorage doesn't overflow
    if (typeof prod.videoUrl === 'string' && prod.videoUrl.startsWith('data:') && prod.videoUrl.length > 20000) {
      prod.videoUrl = ''; // Full video remains safely stored in IndexedDB
      prod._videoInIndexedDB = true;
    }

    // If image is a huge data URL (> 200KB), truncate or keep placeholder in localStorage
    if (typeof prod.image === 'string' && prod.image.startsWith('data:') && prod.image.length > 200000) {
      prod.image = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80';
      prod._imageInIndexedDB = true;
    }

    return prod;
  });
}

/**
 * Safely saves data to localStorage, catching and mitigating QuotaExceededError automatically.
 */
export function saveSafeLocalStorage(key: string, data: unknown): void {
  if (typeof window === 'undefined' || !window.localStorage) return;

  try {
    const serialized = JSON.stringify(data);
    localStorage.setItem(key, serialized);
  } catch (err: unknown) {
    const isQuotaError = 
      err instanceof DOMException &&
      (err.code === 22 ||
        err.code === 1014 ||
        err.name === 'QuotaExceededError' ||
        err.name === 'NS_ERROR_DOM_QUOTA_REACHED');

    if (isQuotaError || (err as Error)?.message?.includes('quota')) {
      console.warn(`[Storage] LocalStorage quota reached for '${key}'. Mitigating with lightweight compression.`);

      try {
        if (key === 'shopforge_products') {
          const lightweight = createLightweightProducts(data);
          localStorage.setItem(key, JSON.stringify(lightweight));
        } else {
          // Clear any non-critical cache keys to free up space
          try {
            localStorage.removeItem('shopforge_temp_cache');
          } catch {
            // ignore
          }
        }
      } catch {
        // If even lightweight fails, do not throw or let app crash
        console.warn(`[Storage] Stored in IndexedDB; localStorage skipped for '${key}'.`);
      }
    } else {
      console.warn(`[Storage] Error setting '${key}' in localStorage`, err);
    }
  }
}

/**
 * Compresses an image file from user device using HTML5 Canvas
 * Reduces 10MB camera photos to ~100KB-180KB crisp WebP/JPEG, making uploads instant.
 */
export async function compressImageFile(
  file: File,
  maxWidth = 1200,
  maxHeight = 1200,
  quality = 0.82
): Promise<{ dataUrl: string; sizeString: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        // Calculate aspect ratio
        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          // Fallback to original data URL if canvas context unavailable
          const originalData = e.target?.result as string;
          resolve({ dataUrl: originalData, sizeString: `${Math.round(file.size / 1024)} KB` });
          return;
        }

        // Draw image smoothed
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        // Export as WebP if supported, fallback to JPEG
        let dataUrl = '';
        try {
          dataUrl = canvas.toDataURL('image/webp', quality);
          if (!dataUrl.startsWith('data:image/webp')) {
            dataUrl = canvas.toDataURL('image/jpeg', quality);
          }
        } catch {
          dataUrl = canvas.toDataURL('image/jpeg', quality);
        }

        const estimatedBytes = Math.round((dataUrl.length * 3) / 4);
        const sizeString = estimatedBytes > 1024 * 1024
          ? `${(estimatedBytes / (1024 * 1024)).toFixed(1)} MB`
          : `${Math.round(estimatedBytes / 1024)} KB`;

        resolve({ dataUrl, sizeString });
      };

      img.onerror = () => {
        reject(new Error('Failed to load image for compression'));
      };

      img.src = e.target?.result as string;
    };

    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
