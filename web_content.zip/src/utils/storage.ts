import { UserSaveData } from '../types/game';

const STORAGE_KEY = 'liquid_sort_save_v1';

export const DEFAULT_SAVE_DATA: UserSaveData = {
  coins: 250, // Starting coin bonus so player can experiment with hints/undo/shop
  currentUnlockedLevel: 1,
  levelProgress: {},
  equippedLocation: 'snow_aurora',
  equippedTube: 'classic',
  equippedLiquid: 'classic',
  unlockedLocations: ['snow_aurora'],
  unlockedTubes: ['classic'],
  unlockedLiquids: ['classic'],
  hintsCount: 3,
  undosCount: 5,
  extraTubesCount: 2,
  spinsCount: 1,
  lastDailyClaimDate: '',
  lastDailySpinDate: '',
  dailyStreak: 0,
  dailyChallengeCompletedDate: '',
  extraDailyChallengeAttempts: 0,
  dailyChallengeBonusIndex: 0,
  settings: {
    sound: true,
    music: true,
    haptics: true,
    colorblind: false,
    soundVolume: 1.0,
    musicVolume: 0.9,
  },
};

export function loadUserData(): UserSaveData {
  if (typeof window === 'undefined') return DEFAULT_SAVE_DATA;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SAVE_DATA;
    const parsed = JSON.parse(raw);
    const unlockedLocs = Array.isArray(parsed.unlockedLocations)
      ? Array.from(new Set(['snow_aurora', ...parsed.unlockedLocations]))
      : ['snow_aurora'];

    // Sanitize currentUnlockedLevel to ensure it follows contiguous completed levels
    let continuousUnlocked = 1;
    if (parsed.levelProgress && typeof parsed.levelProgress === 'object') {
      while (parsed.levelProgress[continuousUnlocked]?.completed) {
        continuousUnlocked++;
      }
    }

    // If parsed.currentUnlockedLevel was jumped due to the Daily Challenge bug, restore continuous progress
    const safeUnlockedLevel = Math.max(1, continuousUnlocked);

    return {
      ...DEFAULT_SAVE_DATA,
      ...parsed,
      currentUnlockedLevel: safeUnlockedLevel,
      unlockedLocations: unlockedLocs,
      equippedLocation: parsed.equippedLocation || 'snow_aurora',
      settings: {
        ...DEFAULT_SAVE_DATA.settings,
        ...(parsed.settings || {}),
      },
      levelProgress: parsed.levelProgress || {},
    };
  } catch (err) {
    console.warn('Failed to load user data from storage, using defaults:', err);
    return DEFAULT_SAVE_DATA;
  }
}

export function saveUserData(data: UserSaveData): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.warn('Failed to save user data to storage:', err);
  }
}

export function resetAllData(): UserSaveData {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(STORAGE_KEY);
  }
  return DEFAULT_SAVE_DATA;
}
