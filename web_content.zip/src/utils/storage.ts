import type { AppSettings, ChatSession, ImageAttachment, UserProfile } from "../types/chat";

const CHATS_KEY = "mih_ai_chats_v1";
const SETTINGS_KEY = "mih_ai_settings_v1";
const ONBOARDED_KEY = "mih_ai_onboarded_v1";
const USER_KEY = "mih_ai_user_v1";

export const ALLOWED_IMAGE_TYPES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
];

export const MAX_IMAGE_UPLOAD_BYTES = 10 * 1024 * 1024; // 10 MB raw file cap before gentle optimization
export const TARGET_IMAGE_BYTES = 4.5 * 1024 * 1024; // 4.5 MB safe encoded cap

export const DEFAULT_SETTINGS: AppSettings = {
  theme: "system",
  language: "auto",
};

export const DEMO_USER: UserProfile = {
  id: "local-demo",
  name: "Local Demo User",
  email: "Stored locally on this device",
  mode: "demo",
};

export function loadChats(): ChatSession[] {
  try {
    const raw = localStorage.getItem(CHATS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((c) => c && typeof c.id === "string" && Array.isArray(c.messages))
      .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  } catch {
    return [];
  }
}

export function saveChats(chats: ChatSession[]): void {
  try {
    localStorage.setItem(CHATS_KEY, JSON.stringify(chats));
  } catch {
    // If localStorage quota is exceeded due to many large photos, strip older image payloads beyond the newest 5 chats
    try {
      const compacted = chats.map((chat, idx) =>
        idx < 5
          ? chat
          : {
              ...chat,
              messages: chat.messages.map((m) =>
                m.image ? { ...m, image: undefined } : m
              ),
            }
      );
      localStorage.setItem(CHATS_KEY, JSON.stringify(compacted));
    } catch {
      // Ignore secondary storage failure
    }
  }
}

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return {
      theme:
        parsed.theme === "light" || parsed.theme === "dark" || parsed.theme === "system"
          ? parsed.theme
          : "system",
      language:
        parsed.language === "auto" ||
        parsed.language === "en" ||
        parsed.language === "bn" ||
        parsed.language === "hi"
          ? parsed.language
          : "auto",
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage error
  }
}

export function hasCompletedOnboarding(): boolean {
  try {
    return localStorage.getItem(ONBOARDED_KEY) === "true";
  } catch {
    return false;
  }
}

export function markOnboardingCompleted(): void {
  try {
    localStorage.setItem(ONBOARDED_KEY, "true");
  } catch {
    // Ignore storage error
  }
}

export function loadUser(): UserProfile {
  try {
    const raw = localStorage.getItem(USER_KEY);
    if (!raw) return DEMO_USER;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.mode === "google" && typeof parsed.id === "string") {
      return parsed as UserProfile;
    }
    return DEMO_USER;
  } catch {
    return DEMO_USER;
  }
}

export function saveUser(user: UserProfile): void {
  try {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  } catch {
    // Ignore storage error
  }
}

export function generateId(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

export function deriveChatTitle(text: string, hasImage: boolean): string {
  const cleaned = text.replace(/\s+/g, " ").trim();
  if (!cleaned) {
    return hasImage ? "Photo Question" : "New Conversation";
  }
  return cleaned.length > 44 ? `${cleaned.slice(0, 44).trimEnd()}…` : cleaned;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function inferImageMimeType(file: File): string {
  const rawType = (file.type || "").toLowerCase().trim();
  if (rawType) {
    return rawType === "image/jpg" ? "image/jpeg" : rawType;
  }
  const name = (file.name || "").toLowerCase();
  if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
  if (name.endsWith(".png")) return "image/png";
  if (name.endsWith(".webp")) return "image/webp";
  return "";
}

export async function processImageFile(file: File): Promise<ImageAttachment> {
  const mimeType = inferImageMimeType(file);
  if (!ALLOWED_IMAGE_TYPES.includes(mimeType)) {
    throw new Error(
      "Unsupported image format. Please choose a JPG, JPEG, PNG, or WEBP photo."
    );
  }

  if (file.size > MAX_IMAGE_UPLOAD_BYTES) {
    throw new Error(
      `Image file is too large (${formatBytes(file.size)}). Please select an image under 10 MB.`
    );
  }

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Could not read the selected image file."));
    reader.readAsDataURL(file);
  });

  // Load into an Image to check dimensions and gently downscale giant mobile camera photos (> 2048px)
  // so uploads remain fast on mobile networks while keeping handwritten text crisp.
  const processedDataUrl = await new Promise<string>((resolve) => {
    const img = new Image();
    img.onload = () => {
      const maxDim = 2048;
      const needsResize = img.width > maxDim || img.height > maxDim || file.size > TARGET_IMAGE_BYTES;
      if (!needsResize) {
        resolve(dataUrl);
        return;
      }

      const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
      const targetW = Math.max(1, Math.round(img.width * scale));
      const targetH = Math.max(1, Math.round(img.height * scale));

      const canvas = document.createElement("canvas");
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        resolve(dataUrl);
        return;
      }
      ctx.drawImage(img, 0, 0, targetW, targetH);

      const outMime = mimeType === "image/png" ? "image/png" : "image/jpeg";
      const outUrl = canvas.toDataURL(outMime, 0.88);
      resolve(outUrl);
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });

  const commaIdx = processedDataUrl.indexOf(",");
  if (commaIdx === -1) {
    throw new Error("Could not process image data.");
  }

  const header = processedDataUrl.slice(0, commaIdx);
  const base64Data = processedDataUrl.slice(commaIdx + 1);
  const detectedMimeMatch = header.match(/data:([^;]+);base64/i);
  const finalMime = detectedMimeMatch ? detectedMimeMatch[1].toLowerCase() : mimeType;

  const approxBytes = Math.round((base64Data.length * 3) / 4);
  if (approxBytes > 5.5 * 1024 * 1024) {
    throw new Error("Processed image exceeds the 5 MB upload limit. Please try a smaller photo.");
  }

  return {
    mimeType: finalMime === "image/jpg" ? "image/jpeg" : finalMime,
    data: base64Data,
    previewUrl: processedDataUrl,
    name: file.name || "photo.jpg",
    sizeBytes: approxBytes,
  };
}
