import { HunterProfile, HunterRank } from '../types';

const STORAGE_KEY = 'SHADOW_RADIOLOGY_PROFILE_DZ_V1';

export const INITIAL_ACHIEVEMENTS = [
  { id: 'ach-first-step', titleAr: 'يقظة الصياد', titleFr: 'Éveil du Chasseur', descAr: 'إكمال أول درس في الفيزياء الإشعاعية', icon: 'Sparkles', unlocked: false },
  { id: 'ach-dict-master', titleAr: 'حارس المعجم', titleFr: 'Maître du Lexique', descAr: 'استكشاف وحفظ 10 مصطلحات في المفضلة', icon: 'BookMarked', unlocked: false },
  { id: 'ach-flash-memory', titleAr: 'بصيرة الصقر الخارقة', titleFr: 'Vision Éclair 5s', descAr: 'إتقان تحدي الذاكرة الشعاعية السريعة في 5 ثوانٍ', icon: 'Eye', unlocked: false },
  { id: 'ach-3d-explorer', titleAr: 'بصيرة الأشعة 3D', titleFr: 'Vision 3D', descAr: 'فحص الهيكل العظمي والأعضاء في المجسم ثلاثي الأبعاد', icon: 'Eye', unlocked: false },
  { id: 'ach-alara-shield', titleAr: 'درع ألارا الحامي', titleFr: 'Bouclier ALARA', descAr: 'اجتياز اختبار الحماية من الإشعاع بنسبة 100%', icon: 'ShieldCheck', unlocked: false },
  { id: 'ach-streak-3', titleAr: 'شعلة الاستمرار', titleFr: 'Flamme Ardente', descAr: 'الحفاظ على شعلة الدراسة لـ 3 أيام متتالية', icon: 'Flame', unlocked: false },
  { id: 'ach-rank-s', titleAr: 'سيد الظلال S-Rank', titleFr: 'Monarque des Ombres', descAr: 'الوصول إلى الرتبة الأسطورية S', icon: 'Crown', unlocked: false },
];

export const INITIAL_PROFILE: HunterProfile = {
  name: 'صياد الأشعة',
  title: 'متدرب باراميديكال مبتدئ',
  level: 1,
  currentXp: 0,
  nextLevelXp: 100,
  rank: 'E',
  hearts: 5,
  maxHearts: 5,
  lastHeartRefill: Date.now(),
  streak: 1,
  lastActiveDate: new Date().toISOString().split('T')[0],
  coins: 50,
  completedLessonIds: [],
  masteredTermIds: [],
  favoriteTermIds: [],
  difficultTermIds: [],
  mistakeQuestionIds: [],
  achievements: INITIAL_ACHIEVEMENTS,
  settings: {
    language: 'ar',
    soundEnabled: true,
    voiceSpeed: 0.95,
    showAura: true,
  }
};

export function getRankDetails(rank: HunterRank) {
  switch (rank) {
    case 'E':
      return { nameAr: 'رتبة مبتدئ E-Rank', nameFr: 'Rang E (Novice)', color: 'border-slate-500 text-slate-300', bg: 'bg-slate-900/80', aura: 'rgba(148, 163, 184, 0.2)' };
    case 'D':
      return { nameAr: 'رتبة متدرب D-Rank', nameFr: 'Rang D (Apprenti)', color: 'border-blue-500 text-blue-400', bg: 'bg-blue-950/80', aura: 'rgba(59, 130, 246, 0.3)' };
    case 'C':
      return { nameAr: 'رتبة محترف C-Rank', nameFr: 'Rang C (Spécialiste)', color: 'border-emerald-500 text-emerald-400', bg: 'bg-emerald-950/80', aura: 'rgba(16, 185, 129, 0.3)' };
    case 'B':
      return { nameAr: 'رتبة نخبة B-Rank', nameFr: 'Rang B (Élite)', color: 'border-purple-500 text-purple-400', bg: 'bg-purple-950/80', aura: 'rgba(168, 85, 247, 0.4)' };
    case 'A':
      return { nameAr: 'رتبة أستاذ A-Rank', nameFr: 'Rang A (Maître)', color: 'border-rose-500 text-rose-400', bg: 'bg-rose-950/80', aura: 'rgba(244, 63, 94, 0.5)' };
    case 'S':
      return { nameAr: 'رتبة سيد الظلال S-Rank', nameFr: 'Rang S (Monarque)', color: 'border-amber-400 text-amber-300', bg: 'bg-gradient-to-r from-purple-950 via-slate-950 to-amber-950', aura: 'rgba(245, 158, 11, 0.6)' };
  }
}

export function loadProfile(): HunterProfile {
  if (typeof window === 'undefined') return INITIAL_PROFILE;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return INITIAL_PROFILE;
    const data = JSON.parse(raw) as HunterProfile;

    // Refresh hearts based on elapsed time (1 heart every 15 mins)
    const now = Date.now();
    const elapsedMinutes = (now - (data.lastHeartRefill || now)) / (1000 * 60);
    const heartsToAdd = Math.floor(elapsedMinutes / 15);
    if (heartsToAdd > 0 && data.hearts < data.maxHearts) {
      data.hearts = Math.min(data.maxHearts, data.hearts + heartsToAdd);
      data.lastHeartRefill = now;
    }

    // Refresh streak
    const today = new Date().toISOString().split('T')[0];
    const lastDate = data.lastActiveDate;
    if (lastDate !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      if (lastDate === yesterday) {
        data.streak += 1;
      } else {
        data.streak = 1;
      }
      data.lastActiveDate = today;
    }

    return { ...INITIAL_PROFILE, ...data };
  } catch (err) {
    console.warn('Failed to load profile, using defaults:', err);
    return INITIAL_PROFILE;
  }
}

export function saveProfile(profile: HunterProfile) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  } catch (err) {
    console.warn('Failed to save profile:', err);
  }
}

export function addXpToProfile(
  profile: HunterProfile,
  amount: number
): { profile: HunterProfile; leveledUp: boolean; rankedUp: boolean } {
  let { level, currentXp, nextLevelXp, rank, coins } = profile;
  currentXp += amount;
  coins += Math.floor(amount / 5);

  let leveledUp = false;
  let rankedUp = false;

  while (currentXp >= nextLevelXp) {
    currentXp -= nextLevelXp;
    level += 1;
    nextLevelXp = Math.floor(nextLevelXp * 1.35);
    leveledUp = true;
  }

  // Rank thresholds
  let newRank: HunterRank = rank;
  if (level >= 30) newRank = 'S';
  else if (level >= 20) newRank = 'A';
  else if (level >= 12) newRank = 'B';
  else if (level >= 7) newRank = 'C';
  else if (level >= 3) newRank = 'D';
  else newRank = 'E';

  if (newRank !== rank) {
    rankedUp = true;
    rank = newRank;
  }

  const updated: HunterProfile = {
    ...profile,
    level,
    currentXp,
    nextLevelXp,
    rank,
    coins,
  };

  saveProfile(updated);
  return { profile: updated, leveledUp, rankedUp };
}
