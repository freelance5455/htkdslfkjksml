import { Product, Order, StoreSettings, CartItem } from '../types';
import { DEFAULT_PRODUCTS, DEFAULT_STORE_SETTINGS } from '../data/defaultCatalog';

const PRODUCTS_KEY = 'ob_store_products_v1';
const ORDERS_KEY = 'ob_store_orders_v1';
const SETTINGS_KEY = 'ob_store_settings_v1';
const CART_KEY = 'ob_store_cart_v1';
const LANG_KEY = 'ob_store_lang_v1';

// Products Storage
export function getStoredProducts(): Product[] {
  try {
    const raw = localStorage.getItem(PRODUCTS_KEY);
    if (!raw) {
      localStorage.setItem(PRODUCTS_KEY, JSON.stringify(DEFAULT_PRODUCTS));
      return DEFAULT_PRODUCTS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_PRODUCTS;
  } catch (e) {
    console.error('Error loading products from storage', e);
    return DEFAULT_PRODUCTS;
  }
}

export function saveProducts(products: Product[]): void {
  try {
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
  } catch (e) {
    console.error('Error saving products', e);
  }
}

// Orders Storage
export function getStoredOrders(): Order[] {
  try {
    const raw = localStorage.getItem(ORDERS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading orders', e);
    return [];
  }
}

export function saveOrder(order: Order): void {
  try {
    const orders = getStoredOrders();
    const updated = [order, ...orders];
    localStorage.setItem(ORDERS_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving order', e);
  }
}

export function updateOrderStatus(orderId: string, status: Order['status']): Order[] {
  try {
    const orders = getStoredOrders();
    const updated = orders.map(o => o.id === orderId ? { ...o, status } : o);
    localStorage.setItem(ORDERS_KEY, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Error updating order status', e);
    return getStoredOrders();
  }
}

export function deleteOrder(orderId: string): Order[] {
  try {
    const orders = getStoredOrders();
    const updated = orders.filter(o => o.id !== orderId);
    localStorage.setItem(ORDERS_KEY, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Error deleting order', e);
    return getStoredOrders();
  }
}

// Store Settings
export function getStoredSettings(): StoreSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(DEFAULT_STORE_SETTINGS));
      return DEFAULT_STORE_SETTINGS;
    }
    return { ...DEFAULT_STORE_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    console.error('Error loading settings', e);
    return DEFAULT_STORE_SETTINGS;
  }
}

export function saveSettings(settings: StoreSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Error saving settings', e);
  }
}

// Cart Storage
export function getStoredCart(): CartItem[] {
  try {
    const raw = localStorage.getItem(CART_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveCart(cart: CartItem[]): void {
  try {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  } catch (e) {
    console.error('Error saving cart', e);
  }
}

// Language
export function getStoredLanguage(): 'ur' | 'en' {
  try {
    return (localStorage.getItem(LANG_KEY) as 'ur' | 'en') || 'ur';
  } catch (e) {
    return 'ur';
  }
}

export function saveLanguage(lang: 'ur' | 'en'): void {
  try {
    localStorage.setItem(LANG_KEY, lang);
  } catch (e) {
    console.error('Error saving language', e);
  }
}

// Pakistani Currency Formatter
export function formatPKR(amount: number, isUrdu = false): string {
  const formatted = new Intl.NumberFormat('en-PK').format(amount);
  return isUrdu ? `${formatted} روپے` : `Rs. ${formatted}`;
}

// Clean phone for WhatsApp (Pakistani format conversion)
export function sanitizePakistaniPhone(phone: string): string {
  let cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '92' + cleaned.substring(1);
  } else if (!cleaned.startsWith('92') && cleaned.length === 10) {
    cleaned = '92' + cleaned;
  }
  return cleaned;
}

// Compress image from Android Mobile Gallery or Camera to clean base64 data URL
export function compressImageFile(file: File, maxWidth = 700, maxHeight = 700, quality = 0.75): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(event.target?.result as string);
          return;
        }

        // Draw with white background for transparency safety
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
}

// WhatsApp Order Message Formatter
export function generateWhatsAppOrderUrl(order: Order, whatsappNumber: string): string {
  const cleanPhone = sanitizePakistaniPhone(whatsappNumber || '03017144300');
  
  const itemsText = order.items
    .map((item, idx) => `${idx + 1}. *${item.urduName || item.name}* (${item.unit})\n   مقدار: ${item.quantity} × Rs. ${item.price} = *Rs. ${item.total}*`)
    .join('\n\n');

  const text = 
`*🛒 نیا آن لائن آرڈر - اویس بلال سٹور*
--------------------------------
*آرڈر نمبر:* #${order.id}
*تاریخ:* ${new Date(order.createdAt).toLocaleDateString('ur-PK', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}

*👤 گاہک کا نام:* ${order.customerName}
*📱 موبائل نمبر:* ${order.customerPhone}
*🏡 گاؤں / چک:* ${order.villageName}
*📍 گلی / نشانی:* ${order.streetAddress}
${order.notes ? `*📝 اضافی سامان / ہدایات:* ${order.notes}\n` : ''}
--------------------------------
*📦 سامان کی تفصیل:*
${itemsText}

--------------------------------
*سامان کی کل رقم:* Rs. ${order.subtotal}
*ڈیلیوری چارجز:* ${order.deliveryFee === 0 ? 'مفت (Free)' : `Rs. ${order.deliveryFee}`}
*💰 کل ادا رقم:* *Rs. ${order.total}*
*طریقہ ادائیگی:* ${order.paymentMethod === 'cod' ? 'کیش آن ڈیلیوری (Cash on Delivery)' : 'جاز کیش / ایزی پیسہ (JazzCash / EasyPaisa)'}
--------------------------------
_محمد اویس بلال 03017144300 کے پاس رجسٹرڈ آرڈر_`;

  const encodedText = encodeURIComponent(text);
  return `https://wa.me/${cleanPhone}?text=${encodedText}`;
}

// Export / Backup data as downloadable JSON file
export function exportStoreData(): void {
  const data = {
    products: getStoredProducts(),
    orders: getStoredOrders(),
    settings: getStoredSettings(),
    exportedAt: new Date().toISOString()
  };
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `owais-bilal-store-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// Import store data from JSON file
export function importStoreData(jsonString: string): boolean {
  try {
    const data = JSON.parse(jsonString);
    if (data.products && Array.isArray(data.products)) {
      saveProducts(data.products);
    }
    if (data.orders && Array.isArray(data.orders)) {
      localStorage.setItem(ORDERS_KEY, JSON.stringify(data.orders));
    }
    if (data.settings) {
      saveSettings(data.settings);
    }
    return true;
  } catch (e) {
    console.error('Import failed', e);
    return false;
  }
}
