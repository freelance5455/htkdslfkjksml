import { BackupPayload, StartedChaptersStore, StatusStore, StreakData, SubItemStore, TestStore } from '../types';
import { SEED_TEST_RESULTS } from '../data/batchData';
import { migrateChapterData, mergeTrackerData, TrackerDataSnapshot } from './trackerLogic';

export { mergeTrackerData };
export type { TrackerDataSnapshot };

const KEY_STATUS = 'nv3';
const KEY_SUB_ITEMS = 'nsb';
const KEY_STARTED = 'nst';
const KEY_STREAK = 'nstrk';
const KEY_TESTS = 'ntt';
const KEY_TARGET_DATE = 'neet_target_date';

export function loadItem<T>(key: string, defaultValue: T): T {
  if (typeof window === 'undefined') return defaultValue;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch (e) {
    console.error(`Error loading ${key} from storage:`, e);
    return defaultValue;
  }
}

export function saveItem<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error saving ${key} to storage:`, e);
  }
}

export function loadAllData(): TrackerDataSnapshot {
  const rawStatus = loadItem<StatusStore>(KEY_STATUS, {});
  const rawSubItems = loadItem<SubItemStore>(KEY_SUB_ITEMS, {});
  const rawStarted = loadItem<StartedChaptersStore>(KEY_STARTED, {});
  const streak = loadItem<StreakData | null>(KEY_STREAK, null);
  const testStore = loadItem<TestStore>(KEY_TESTS, SEED_TEST_RESULTS);
  const targetDate = loadItem<string>(KEY_TARGET_DATE, '2027-05-04');

  // Automatic migration for existing chapter names
  const migrated = migrateChapterData(rawStatus, rawSubItems, rawStarted);

  return {
    statusStore: migrated.statusStore,
    subItemStore: migrated.subItemStore,
    startedStore: migrated.startedStore,
    streak,
    testStore,
    targetDate,
  };
}

export function saveAllData(
  statusStore: StatusStore,
  subItemStore: SubItemStore,
  startedStore: StartedChaptersStore,
  streak: StreakData | null,
  testStore: TestStore,
  targetDate: string
): void {
  saveItem(KEY_STATUS, statusStore);
  saveItem(KEY_SUB_ITEMS, subItemStore);
  saveItem(KEY_STARTED, startedStore);
  if (streak) {
    saveItem(KEY_STREAK, streak);
  } else if (typeof window !== 'undefined') {
    try {
      localStorage.removeItem(KEY_STREAK);
    } catch {
      // ignore storage errors
    }
  }
  saveItem(KEY_TESTS, testStore);
  saveItem(KEY_TARGET_DATE, targetDate);
}

export function generateBackupJson(
  statusStore: StatusStore,
  subItemStore: SubItemStore,
  startedStore: StartedChaptersStore,
  streak: StreakData | null,
  testStore: TestStore,
  targetDate: string
): string {
  const payload: BackupPayload = {
    nv3: statusStore,
    nsb: subItemStore,
    nst: startedStore,
    nstrk: streak || undefined,
    ntt: testStore,
    neetDate: targetDate,
  };
  return JSON.stringify(payload, null, 2);
}

export function restoreBackupJson(
  jsonString: string
): {
  success: boolean;
  message: string;
  data?: TrackerDataSnapshot;
} {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== 'object') {
      return { success: false, message: 'Invalid JSON backup format' };
    }

    const rawStatus: StatusStore = parsed.nv3 || {};
    const rawSubItems: SubItemStore = parsed.nsb || {};
    const rawStarted: StartedChaptersStore = parsed.nst || {};
    const streak: StreakData | null = parsed.nstrk || null;
    const testStore: TestStore = parsed.ntt || SEED_TEST_RESULTS;
    const targetDate: string = parsed.neetDate || '2027-05-04';

    const migrated = migrateChapterData(rawStatus, rawSubItems, rawStarted);

    saveAllData(
      migrated.statusStore,
      migrated.subItemStore,
      migrated.startedStore,
      streak,
      testStore,
      targetDate
    );

    return {
      success: true,
      message: 'Backup successfully restored!',
      data: {
        statusStore: migrated.statusStore,
        subItemStore: migrated.subItemStore,
        startedStore: migrated.startedStore,
        streak,
        testStore,
        targetDate,
      },
    };
  } catch (err) {
    return {
      success: false,
      message: err instanceof Error ? err.message : 'Failed to parse JSON backup',
    };
  }
}
