import {
  Note,
  TrashItem,
  Flashcard,
  VaultMetadata,
  ImageClip,
  ThemeAccent,
  ViewLayout,
  SectionItem,
  UserProfile,
  SyncedNoteRecord,
  ElementSnippet,
  ActiveTab,
  UIThemeStyle,
} from "../types";
import {
  idbSaveNotes,
  idbGetNotes,
  idbSaveTrash,
  idbGetTrash,
  idbSaveClips,
  idbGetClips
} from "./idbStorage";

export const STORAGE_KEYS = {
  NOTES: "noteflow_notes_v2",
  TRASH: "noteflow_trash_v2",
  SETTINGS: "noteflow_settings_v2",
  VAULT: "noteflow_vault_v2",
  FLASHCARDS: "noteflow_flashcards_v2",
  CLIPS: "noteflow_clips_v2",
  SECTIONS: "noteflow_sections_v2",
  PROFILE: "noteflow_profile_v2",
  SYNC_LOGS: "noteflow_sync_logs_v2",
};

// In-memory runtime caches to guarantee instant access and zero quota loss
let _cachedNotes: Note[] | null = null;
let _cachedTrash: TrashItem[] | null = null;
let _cachedClips: ImageClip[] | null = null;

/**
 * Strips heavy base64 strings (>15KB) before storing into localStorage.
 * Full binary payloads remain safely stored in IndexedDB and in-memory cache.
 */
export function sanitizeNotesForLocalStorage(notes: Note[]): Note[] {
  return notes.map((note) => {
    let modified = false;
    let safeAttachments = note.attachments;
    let safeAudio = note.audioNotes;
    let safeHtml = note.htmlContent;

    if (safeAttachments && safeAttachments.length > 0) {
      safeAttachments = safeAttachments.map((att) => {
        if (att.data && att.data.length > 15000) {
          modified = true;
          return { ...att, data: "" };
        }
        return att;
      });
    }

    if (safeAudio && safeAudio.length > 0) {
      safeAudio = safeAudio.map((a) => {
        if (a.data && a.data.length > 15000) {
          modified = true;
          return { ...a, data: "" };
        }
        return a;
      });
    }

    if (safeHtml && safeHtml.length > 25000) {
      modified = true;
      safeHtml = safeHtml.slice(0, 25000);
    }

    if (!modified) return note;

    return {
      ...note,
      attachments: safeAttachments,
      audioNotes: safeAudio,
      htmlContent: safeHtml,
    };
  });
}

/**
 * Compact trash items for localStorage to avoid consuming quota
 */
export function sanitizeTrashForLocalStorage(trash: TrashItem[]): TrashItem[] {
  const recent = trash.slice(0, 15);
  return recent.map((item) => ({
    ...item,
    attachments: (item.attachments || []).map((att) => ({ ...att, data: "" })),
    audioNotes: (item.audioNotes || []).map((a) => ({ ...a, data: "" })),
    htmlContent: item.htmlContent ? item.htmlContent.slice(0, 10000) : undefined,
  }));
}

/**
 * Safe local storage setter with automatic quota recovery and eviction
 */
export function safeSetItem(key: string, value: string): boolean {
  try {
    localStorage.setItem(key, value);
    return true;
  } catch (err: any) {
    const isQuotaError =
      err &&
      (err.name === "QuotaExceededError" ||
        err.name === "NS_ERROR_DOM_QUOTA_REACHED" ||
        err.code === 22 ||
        err.code === 1014 ||
        (err.message && err.message.toLowerCase().includes("quota")));

    if (isQuotaError) {
      // 1. Evict duplicate or heavy non-critical caches
      try {
        localStorage.removeItem(STORAGE_KEYS.CLIPS);
        localStorage.removeItem("noteflow_clips_v2");
        const rawLogs = localStorage.getItem(STORAGE_KEYS.SYNC_LOGS);
        if (rawLogs) {
          const logs = JSON.parse(rawLogs);
          if (Array.isArray(logs) && logs.length > 10) {
            localStorage.setItem(STORAGE_KEYS.SYNC_LOGS, JSON.stringify(logs.slice(0, 10)));
          }
        }
      } catch {}

      // 2. Try setting again
      try {
        localStorage.setItem(key, value);
        return true;
      } catch {
        console.warn(`[Storage] LocalStorage quota reached for "${key}". Data is safely retained in IndexedDB and memory.`);
        return false;
      }
    } else {
      console.warn(`[Storage] Storage write error for "${key}":`, err);
      return false;
    }
  }
}

/**
 * Compresses an image file (e.g. from camera/gallery) using HTML5 Canvas.
 * Prevents memory issues and localStorage quota crashes by scaling down mega-pixel
 * phone camera shots to a crisp, optimized web resolution (~1400px max, ~100-300KB).
 */
export async function compressImageFile(
  file: File,
  maxDimension = 1400,
  quality = 0.82
): Promise<{ dataUrl: string; size: number; name: string; mime: string }> {
  const fileExt = file.name.split(".").pop()?.toLowerCase() || "";
  const isImage = file.type.startsWith("image/") || ["png", "jpg", "jpeg", "webp", "bmp", "gif"].includes(fileExt);

  if (!isImage || fileExt === "svg") {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        resolve({
          dataUrl,
          size: file.size,
          name: file.name,
          mime: file.type || "application/octet-stream",
        });
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });
  }

  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        try {
          let { width, height } = img;
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = Math.round((height * maxDimension) / width);
              width = maxDimension;
            } else {
              width = Math.round((width * maxDimension) / height);
              height = maxDimension;
            }
          }

          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");

          if (!ctx) {
            const rawUrl = e.target?.result as string;
            resolve({ dataUrl: rawUrl, size: file.size, name: file.name, mime: file.type || "image/jpeg" });
            return;
          }

          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = "high";
          ctx.drawImage(img, 0, 0, width, height);

          const outputMime = file.type === "image/png" && file.size < 400 * 1024 ? "image/png" : "image/jpeg";
          const dataUrl = canvas.toDataURL(outputMime, quality);
          const estimatedBytes = Math.round((dataUrl.length * 3) / 4);

          resolve({
            dataUrl,
            size: estimatedBytes,
            name: file.name,
            mime: outputMime,
          });
        } catch {
          const rawUrl = e.target?.result as string;
          resolve({ dataUrl: rawUrl, size: file.size, name: file.name, mime: file.type || "image/jpeg" });
        }
      };
      img.onerror = () => {
        const rawUrl = e.target?.result as string;
        resolve({ dataUrl: rawUrl, size: file.size, name: file.name, mime: file.type || "image/jpeg" });
      };
      img.src = e.target?.result as string;
    };
    reader.onerror = () => {
      resolve({ dataUrl: "", size: 0, name: file.name, mime: file.type || "image/jpeg" });
    };
    reader.readAsDataURL(file);
  });
}

export const DEFAULT_CATEGORIES = ["Tümü", "Kişisel", "İş", "Projeler", "Fikirler", "Eğitim"];

export const DEFAULT_SECTIONS: SectionItem[] = [
  { id: "sec-personal", name: "Kişisel", icon: "User", color: "rose", description: "Günlük düşünceler, hedefler ve özel notlar", isDefault: true },
  { id: "sec-work", name: "İş", icon: "Briefcase", color: "blue", description: "Toplantı notları, iş planları ve şirket görevleri", isDefault: true },
  { id: "sec-ideas", name: "Fikirler", icon: "Lightbulb", color: "amber", description: "Yeni buluşlar, vizyonlar ve ilham verici düşünceler", isDefault: true },
  { id: "sec-projects", name: "Projeler", icon: "FolderKanban", color: "purple", description: "Aktif yol haritaları ve proje sprintleri", isDefault: true },
  { id: "sec-education", name: "Eğitim", icon: "GraduationCap", color: "emerald", description: "Dersler, özetler, kitaplar ve araştırma notları", isDefault: true },
];

export const DEFAULT_PROFILE: UserProfile = {
  name: "Enes Erdem",
  email: "enes02erdm@gmail.com",
  title: "Not Yöneticisi & Tasarımcı",
  isLoggedIn: true,
  authProvider: "google",
  aiModeEnabled: true,
  autoSync: true,
  syncFrequency: "instant",
  googleDriveBackup: true,
  socialShareEnabled: true,
  xHandle: "@eneserdm",
  lastBackupDate: new Date().toISOString(),
  joinedDate: "2025-01-15T10:00:00.000Z",
  aiQuestionsCount: 14,
};

// Initial seed notes so the app is immediately alive and useful
const SEED_NOTES: Note[] = [
  {
    id: "seed-1",
    title: "NoteFlow'a Hoş Geldiniz! 🚀",
    content: `NoteFlow, günlük düşüncelerinizi, işlerinizi ve öğrenme hedeflerinizi organize eden yeni nesil akıllı not asistanınızdır.

Öne Çıkan Başlıca Özellikler:
• 🤖 **Yapay Zeka Asistanı**: Notlarınızı anında özetleyin, aksiyon maddelerini çıkarın ve çalışma kartları üretin.
• 🔒 **Şifreli Kasa**: Gizli ve özel notlarınızı AES-256 PBKDF2 ile PIN koduyla kilitleyin.
• 🎙️ **Sesli Yazma & Ses Kaydı**: Konuşarak not alın veya doğrudan dahili ses kaydedici ile sesli notlar oluşturun.
• 🗂️ **Çalışma Kartları (Flashcards)**: Notlarınızdan interaktif çalışma ve ezber kartları oluşturup kendinizi test edin.
• 📎 **Medya & YouTube**: Fotoğraf, doküman ekleyin ve YouTube linklerini doğrudan not içinde izleyin!`,
    category: "Fikirler",
    tags: ["#hoşgeldiniz", "#noteflow", "#akıllınot"],
    pinned: true,
    favorite: true,
    color: "teal",
    tasks: [
      { id: "t1", text: "İlk yeni notunuzu ＋ butonuna basarak oluşturun", completed: true },
      { id: "t2", text: "Güvenli Kasa sekmesini ziyaret edip PIN kodunuzu belirleyin", completed: false },
      { id: "t3", text: "Yapay zeka araçları ile bu notu özetlemeyi deneyin", completed: false },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "seed-2",
    title: "Yapay Zeka ve Makine Öğrenimi Notları 🧠",
    content: `Derin öğrenme modelleri ve dil modelleri (LLM) üzerine temel kavramlar:

1. **Transformer Mimarisi**: Dikkat mekanizması (Self-Attention) sayesinde metinlerdeki uzun mesafeli bağları kurar.
2. **Fine-Tuning vs RAG**: Var olan modelleri özel veriyle ince ayar yapmak ya da harici bilgi tabanından geri getirme (Retrieval Augmented Generation) ile desteklemek.
3. **Prompt Mühendisliği**: Modellerden en doğru ve yapılandırılmış çıktıyı almak için verilen sistem talimatları ve bağlam tasarımı.`,
    category: "Eğitim",
    tags: ["#yapayzeka", "#makineöğrenimi", "#eğitim"],
    pinned: false,
    favorite: true,
    color: "blue",
    createdAt: new Date(Date.now() - 3600000).toISOString(),
    updatedAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: "seed-3",
    title: "Haftalık Proje ve Toplantı Planı 💼",
    content: `Bu haftaki öncelikli teslimler ve ekip koordinasyonu:
- Çarşamba 14:00 Tasarım değerlendirme toplantısı
- Cuma 17:00 Sprint kapanışı ve demo sunumu

Not: Müşteri geri bildirimleri doğrultusunda mobil arayüz sadeliği korunmalıdır.`,
    category: "İş",
    tags: ["#toplantı", "#planlama", "#sprint"],
    pinned: false,
    favorite: false,
    color: "amber",
    tasks: [
      { id: "t21", text: "Sprint görevlerini gözden geçir", completed: true },
      { id: "t22", text: "Demo sunum slaytlarını hazırla", completed: false },
      { id: "t23", text: "Yeni test sürümlerini kontrol et", completed: false },
    ],
    createdAt: new Date(Date.now() - 7200000).toISOString(),
    updatedAt: new Date(Date.now() - 7200000).toISOString(),
  },
];

const SEED_FLASHCARDS: Flashcard[] = [
  {
    id: "fc-1",
    question: "Transformer mimarisinin temel yapı taşı nedir?",
    answer: "Öz-dikkat (Self-Attention) mekanizmasıdır; kelimeler arasındaki ilişkileri pozisyondan bağımsız ağırlıklandırır.",
    mastered: false,
  },
  {
    id: "fc-2",
    question: "AES-GCM şifreleme algoritmasının avantajı nedir?",
    answer: "Hem veri gizliliğini (şifreleme) hem de veri bütünlüğünü (kimlik doğrulama - authentication) aynı anda sağlar.",
    mastered: true,
  },
  {
    id: "fc-3",
    question: "RAG (Retrieval Augmented Generation) ne işe yarar?",
    answer: "Büyük dil modellerinin harici, güncel veya özel bilgi kaynaklarından veri çekerek daha doğru yanıt vermesini sağlar.",
    mastered: false,
  },
];

export function getStoredNotes(): Note[] {
  if (_cachedNotes && _cachedNotes.length > 0) {
    return _cachedNotes;
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTES);
    if (!raw) {
      _cachedNotes = SEED_NOTES;
      saveNotes(SEED_NOTES);
      return SEED_NOTES;
    }
    const parsed = JSON.parse(raw);
    const loaded = Array.isArray(parsed) && parsed.length > 0 ? parsed : SEED_NOTES;
    _cachedNotes = loaded;
    return loaded;
  } catch {
    _cachedNotes = SEED_NOTES;
    return SEED_NOTES;
  }
}

/**
 * Save notes with dual-layer architecture:
 * 1. Full data (with all binary attachments and audio) into IndexedDB
 * 2. LocalStorage with automatic quota detection & sanitization
 */
export function saveNotes(notes: Note[]): void {
  _cachedNotes = notes;

  // 1. Asynchronously persist full data (including attachments & audio) to IndexedDB
  idbSaveNotes(notes).catch((err) => {
    console.warn("IndexedDB notes save fallback:", err);
  });

  // 2. Persist to localStorage with auto-sanitization to prevent quota overflow
  try {
    const jsonStr = JSON.stringify(notes);
    // If JSON string is larger than 1MB, proactively sanitize heavy binary fields to avoid quota issues
    if (jsonStr.length > 1024 * 1024) {
      const sanitized = sanitizeNotesForLocalStorage(notes);
      safeSetItem(STORAGE_KEYS.NOTES, JSON.stringify(sanitized));
    } else {
      const success = safeSetItem(STORAGE_KEYS.NOTES, jsonStr);
      if (!success) {
        // LocalStorage was near capacity; retry with sanitized notes
        const sanitized = sanitizeNotesForLocalStorage(notes);
        safeSetItem(STORAGE_KEYS.NOTES, JSON.stringify(sanitized));
      }
    }
  } catch {
    const sanitized = sanitizeNotesForLocalStorage(notes);
    safeSetItem(STORAGE_KEYS.NOTES, JSON.stringify(sanitized));
  }
}

/**
 * Hydrates state from IndexedDB in the background on app start.
 * Restores full attachment and audio binary data if it was stripped in localStorage.
 */
export async function hydrateNotesFromIndexedDB(): Promise<Note[] | null> {
  try {
    const idbNotes = await idbGetNotes();
    if (!idbNotes || idbNotes.length === 0) {
      return null;
    }
    _cachedNotes = idbNotes;
    return idbNotes;
  } catch (err) {
    console.warn("hydrateNotesFromIndexedDB warning:", err);
    return null;
  }
}

export function getStoredTrash(): TrashItem[] {
  if (_cachedTrash && _cachedTrash.length > 0) {
    return _cachedTrash;
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TRASH);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    // Clean up items older than 30 days
    const limit = Date.now() - 30 * 24 * 60 * 60 * 1000;
    const filtered = parsed.filter(item => new Date(item.deletedAt).getTime() > limit);
    _cachedTrash = filtered;
    return filtered;
  } catch {
    return [];
  }
}

export function saveTrash(trash: TrashItem[]): void {
  _cachedTrash = trash;
  idbSaveTrash(trash).catch(() => {});
  try {
    const sanitized = sanitizeTrashForLocalStorage(trash);
    safeSetItem(STORAGE_KEYS.TRASH, JSON.stringify(sanitized));
  } catch (err) {
    console.warn("Failed to save trash:", err);
  }
}

export function getStoredFlashcards(): Flashcard[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FLASHCARDS);
    if (!raw) {
      saveFlashcards(SEED_FLASHCARDS);
      return SEED_FLASHCARDS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : SEED_FLASHCARDS;
  } catch {
    return SEED_FLASHCARDS;
  }
}

export function saveFlashcards(cards: Flashcard[]): void {
  safeSetItem(STORAGE_KEYS.FLASHCARDS, JSON.stringify(cards));
}

export function getStoredVaultRecord(): VaultMetadata | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.VAULT);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function saveVaultRecord(record: VaultMetadata | null): void {
  try {
    if (record) {
      safeSetItem(STORAGE_KEYS.VAULT, JSON.stringify(record));
    } else {
      localStorage.removeItem(STORAGE_KEYS.VAULT);
    }
  } catch (err) {
    console.warn("Failed to save vault record:", err);
  }
}

export function getThemePreference(): boolean {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (typeof parsed.dark === "boolean") return parsed.dark;
    }
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  } catch {
    return false;
  }
}

export function saveThemePreference(dark: boolean): void {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    const parsed = raw ? JSON.parse(raw) : {};
    parsed.dark = dark;
    safeSetItem(STORAGE_KEYS.SETTINGS, JSON.stringify(parsed));
  } catch (err) {
    console.warn("Failed to save theme setting:", err);
  }
}

export function getStoredClips(): ImageClip[] {
  if (_cachedClips && _cachedClips.length > 0) {
    return _cachedClips;
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CLIPS);
    const parsed = raw ? JSON.parse(raw) : [];
    _cachedClips = Array.isArray(parsed) ? parsed : [];
    return _cachedClips;
  } catch {
    return [];
  }
}

export function saveClips(clips: ImageClip[]): void {
  _cachedClips = clips;
  idbSaveClips(clips).catch(() => {});
  try {
    // Exclude built-in SVG presets (id starts with "sticker-") to save megabytes of localStorage
    const userClips = clips.filter((c) => !c.id.startsWith("sticker-"));
    safeSetItem(STORAGE_KEYS.CLIPS, JSON.stringify(userClips.slice(0, 30)));
  } catch (err) {
    console.warn("Failed to save clips:", err);
  }
}

export function getThemeAccentPreference(): ThemeAccent {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.accent) return parsed.accent;
    }
    return "teal";
  } catch {
    return "teal";
  }
}

export function saveThemeAccentPreference(accent: ThemeAccent): void {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    const parsed = raw ? JSON.parse(raw) : {};
    parsed.accent = accent;
    safeSetItem(STORAGE_KEYS.SETTINGS, JSON.stringify(parsed));
  } catch (err) {
    console.warn("Failed to save accent setting:", err);
  }
}

export function getViewLayoutPreference(): ViewLayout {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.layout) return parsed.layout;
    }
    return "grid";
  } catch {
    return "grid";
  }
}

export function saveViewLayoutPreference(layout: ViewLayout): void {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    const parsed = raw ? JSON.parse(raw) : {};
    parsed.layout = layout;
    safeSetItem(STORAGE_KEYS.SETTINGS, JSON.stringify(parsed));
  } catch (err) {
    console.warn("Failed to save layout setting:", err);
  }
}

// Download file utility
export function downloadFile(filename: string, content: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// Export Notes as CSV
export function exportNotesAsCSV(notes: Note[]): string {
  const headers = ["ID", "Başlık", "Kategori", "Etiketler", "Oluşturulma", "Güncellenme", "İçerik", "Görevler"];
  const rows = notes.map((n) => {
    const tasksStr = (n.tasks || []).map((t) => `[${t.completed ? "x" : " "}] ${t.text}`).join("; ");
    const tagsStr = (n.tags || []).join(", ");
    const safeContent = (n.content || "").replace(/"/g, '""');
    const safeTitle = (n.title || "").replace(/"/g, '""');
    return `"${n.id}","${safeTitle}","${n.category}","${tagsStr}","${n.createdAt}","${n.updatedAt}","${safeContent}","${tasksStr}"`;
  });
  return [headers.join(","), ...rows].join("\n");
}

// Export Notes as standalone styled HTML
export function exportNotesAsHTML(notes: Note[]): string {
  const notesHtml = notes
    .map(
      (n) => `
    <article style="border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 24px; background: #ffffff;">
      <h2 style="margin-top: 0; color: #0f172a; font-size: 20px;">${n.title || "Başlıksız Not"}</h2>
      <div style="font-size: 12px; color: #64748b; margin-bottom: 12px;">
        <span style="background: #e2e8f0; padding: 2px 8px; border-radius: 6px; font-weight: bold;">${n.category}</span>
        <span style="margin-left: 8px;">Tarih: ${new Date(n.updatedAt).toLocaleString("tr-TR")}</span>
        ${n.tags?.length ? `<span style="margin-left: 8px; color: #0d9488;">${n.tags.join(" ")}</span>` : ""}
      </div>
      <div style="font-size: 14px; line-height: 1.6; color: #334155; white-space: pre-wrap;">${n.htmlContent || n.content}</div>
      ${
        n.tasks?.length
          ? `
        <div style="margin-top: 16px; padding-top: 12px; border-top: 1px dashed #cbd5e1;">
          <h4 style="margin: 0 0 8px 0; font-size: 13px; color: #475569;">Yapılacak Görevler</h4>
          <ul style="padding-left: 20px; margin: 0; font-size: 13px;">
            ${n.tasks.map((t) => `<li style="${t.completed ? "text-decoration: line-through; color: #94a3b8;" : ""}">${t.text}</li>`).join("")}
          </ul>
        </div>`
          : ""
      }
    </article>
  `
    )
    .join("");

  return `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>NoteFlow Notlar Arşivi</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f8fafc; color: #0f172a; max-width: 800px; margin: 0 auto; padding: 40px 20px; }
    header { text-align: center; margin-bottom: 40px; }
    h1 { color: #0d9488; margin-bottom: 8px; }
    @media print { body { background: white; padding: 0; } article { page-break-inside: avoid; } }
  </style>
</head>
<body>
  <header>
    <h1>NoteFlow Not Arşivi</h1>
    <p style="color: #64748b; font-size: 13px;">Dışa Aktarılma Tarihi: ${new Date().toLocaleString("tr-TR")} | Toplam: ${notes.length} Not</p>
  </header>
  <main>${notesHtml}</main>
</body>
</html>`;
}

// Export Notes as Plain Text
export function exportNotesAsTXT(notes: Note[]): string {
  let txt = `NOTEFLOW NOTLAR ARŞİVİ\nOluşturulma: ${new Date().toLocaleString("tr-TR")}\nToplam Not Sayısı: ${notes.length}\n`;
  txt += "=".repeat(60) + "\n\n";

  notes.forEach((n, idx) => {
    txt += `[${idx + 1}] ${n.title.toUpperCase() || "BAŞLIKSIZ NOT"}\n`;
    txt += `Kategori: ${n.category} | Tarih: ${new Date(n.updatedAt).toLocaleString("tr-TR")}\n`;
    if (n.tags?.length) txt += `Etiketler: ${n.tags.join(" ")}\n`;
    txt += "-".repeat(40) + "\n";
    txt += `${n.content}\n`;
    if (n.tasks?.length) {
      txt += `\nGörevler:\n`;
      n.tasks.forEach((t) => {
        txt += `  [${t.completed ? "X" : " "}] ${t.text}\n`;
      });
    }
    txt += "\n" + "=".repeat(60) + "\n\n";
  });
  return txt;
}

// Section Storage Management
export function getStoredSections(): SectionItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SECTIONS);
    if (!raw) {
      saveSections(DEFAULT_SECTIONS);
      return DEFAULT_SECTIONS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_SECTIONS;
  } catch {
    return DEFAULT_SECTIONS;
  }
}

export function saveSections(sections: SectionItem[]): void {
  safeSetItem(STORAGE_KEYS.SECTIONS, JSON.stringify(sections));
}

export const saveStoredSections = saveSections;

// User Profile Storage Management
export function getStoredProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PROFILE);
    if (!raw) {
      saveProfile(DEFAULT_PROFILE);
      return DEFAULT_PROFILE;
    }
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_PROFILE, ...parsed };
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function saveProfile(profile: UserProfile): void {
  safeSetItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
}

export const getStoredUserProfile = getStoredProfile;
export const saveUserProfile = saveProfile;

// Synced Notes Log Storage Management
export function getStoredSyncLogs(): SyncedNoteRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SYNC_LOGS);
    if (!raw) {
      const initialLogs: SyncedNoteRecord[] = [
        {
          id: "sync-init-1",
          noteId: "seed-1",
          noteTitle: "NoteFlow'a Hoş Geldiniz! 🚀",
          destination: "Gmail (enes02erdm@gmail.com)",
          channelType: "email",
          status: "success",
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          details: "Otomatik bulut ve e-posta senkronizasyonu tamamlandı.",
        },
        {
          id: "sync-init-2",
          noteId: "seed-2",
          noteTitle: "Yapay Zeka ve Makine Öğrenimi Notları 🧠",
          destination: "Google Drive (Bulut Yedek)",
          channelType: "gdrive",
          status: "success",
          timestamp: new Date(Date.now() - 7200000).toISOString(),
          details: "NoteFlow Notlarım klasörüne yedeklendi.",
        },
      ];
      saveSyncLogs(initialLogs);
      return initialLogs;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveSyncLogs(logs: SyncedNoteRecord[]): void {
  safeSetItem(STORAGE_KEYS.SYNC_LOGS, JSON.stringify(logs.slice(0, 30)));
}

export function addSyncLog(record: Omit<SyncedNoteRecord, "id">): SyncedNoteRecord {
  const newLog: SyncedNoteRecord = {
    ...record,
    id: `sync-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
  };
  const current = getStoredSyncLogs();
  const updated = [newLog, ...current];
  saveSyncLogs(updated);
  return newLog;
}

// =========================================================================
// CUSTOMIZABLE MENU SECTIONS & 4 UI THEME STYLES PREFERENCES
// =========================================================================
export const DEFAULT_MENU_ORDER: ActiveTab[] = [
  "home",
  "docs",
  "plus_action",
  "vault",
  "study",
  "profile",
  "tips",
  "settings",
];

export interface PlusButtonConfig {
  action: "create_menu" | "quick_note" | "voice_record" | "mindmap" | "vault" | "radial_menu";
  size: "compact" | "normal" | "large";
  effect: "glow" | "minimal" | "double_ring";
  labelVisible: boolean;
}

export const DEFAULT_PLUS_BUTTON_CONFIG: PlusButtonConfig = {
  action: "create_menu",
  size: "normal",
  effect: "glow",
  labelVisible: false,
};

export function getStoredPlusButtonConfig(): PlusButtonConfig {
  try {
    const raw = localStorage.getItem("noteflow_plus_btn_config_v1");
    if (raw) {
      return { ...DEFAULT_PLUS_BUTTON_CONFIG, ...JSON.parse(raw) };
    }
  } catch (err) {
    console.warn("Failed to read plus button config:", err);
  }
  return DEFAULT_PLUS_BUTTON_CONFIG;
}

export function saveStoredPlusButtonConfig(cfg: PlusButtonConfig): void {
  try {
    localStorage.setItem("noteflow_plus_btn_config_v1", JSON.stringify(cfg));
  } catch (err) {
    console.warn("Failed to save plus button config:", err);
  }
}

export function getStoredMenuOrder(): ActiveTab[] {
  try {
    const raw = localStorage.getItem("noteflow_menu_order_v2");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure all valid ActiveTabs are included without duplicates
        const validTabs: ActiveTab[] = [
          "home",
          "docs",
          "mindmap",
          "plus_action",
          "vault",
          "study",
          "profile",
          "tips",
          "settings",
          "ai_chat",
          "quick_search",
          "voice_memo",
        ];
        const filtered = parsed.filter((t: any) => validTabs.includes(t)) as ActiveTab[];
        if (filtered.length > 0) {
          // If plus_action is missing from existing stored list, insert it seamlessly in the middle
          if (!filtered.includes("plus_action")) {
            const mid = Math.floor(filtered.length / 2);
            filtered.splice(mid, 0, "plus_action");
          }
          return filtered;
        }
      }
    }
  } catch (err) {
    console.warn("Failed to read menu order preference:", err);
  }
  return DEFAULT_MENU_ORDER;
}

export function saveStoredMenuOrder(order: ActiveTab[]): void {
  try {
    localStorage.setItem("noteflow_menu_order_v2", JSON.stringify(order));
  } catch (err) {
    console.warn("Failed to save menu order preference:", err);
  }
}

export function getStoredUIThemeStyle(): UIThemeStyle {
  try {
    const raw = localStorage.getItem("noteflow_ui_theme_style_v2");
    if (raw && ["minimalist", "circadian_pkm", "enterprise_pkm", "terminal", "cyberpunk", "mental_canvas"].includes(raw)) {
      return raw as UIThemeStyle;
    }
  } catch (err) {
    console.warn("Failed to read UI theme style preference:", err);
  }
  return "circadian_pkm";
}

export function saveStoredUIThemeStyle(style: UIThemeStyle): void {
  try {
    localStorage.setItem("noteflow_ui_theme_style_v2", style);
  } catch (err) {
    console.warn("Failed to save UI theme style preference:", err);
  }
}

