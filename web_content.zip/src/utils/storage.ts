/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AppData, ToDoGroup, WorkGroup } from '../types.ts';
import { getTodayDateString } from './dateUtils.ts';

const STORAGE_KEY = 'routine_tracker_bengali_app_v1';

export const MAX_GROUP_LIMIT = 100;

export function getInitialDemoData(): AppData {
  const today = getTodayDateString();

  const workGroups: WorkGroup[] = [
    {
      id: 'wg-1',
      title: 'ঘর',
      order: 0,
      tasks: [
        {
          id: 'wt-1',
          groupId: 'wg-1',
          title: 'ঘর গুছানো',
          details: 'বিছানা ও পড়ার টেবিল ঠিক করা',
          completed: false,
          order: 0,
        },
        {
          id: 'wt-2',
          groupId: 'wg-1',
          title: 'চাদর ধোয়া',
          details: 'বিকেলের মধ্যে বারান্দায় শুকানো',
          completed: false,
          order: 1,
        },
      ],
    },
    {
      id: 'wg-2',
      title: 'শরীরচর্চা',
      order: 1,
      tasks: [
        {
          id: 'wt-3',
          groupId: 'wg-2',
          title: 'সকালের হাঁটা',
          details: '৩০ মিনিট পার্কে দ্রুত হাঁটা',
          completed: false,
          order: 0,
        },
        {
          id: 'wt-4',
          groupId: 'wg-2',
          title: 'পুশ-আপ ও স্ট্রেচিং',
          details: '৩ সেট করে',
          completed: false,
          order: 1,
        },
      ],
    },
  ];

  const todoGroups: ToDoGroup[] = [
    {
      id: 'tg-1',
      name: 'বিজ্ঞান ও পড়াশোনা',
      details: 'প্রতিদিনের নিয়মিত পাঠ্যসূচি',
      order: 0,
      tasks: [
        {
          id: 'tt-1',
          groupId: 'tg-1',
          name: 'বিজ্ঞান',
          details: 'অধ্যায় ৩ রিভিশন ও নোট',
          repeat: { type: 'daily' },
          createdAt: today,
          order: 0,
          reports: {},
        },
        {
          id: 'tt-2',
          groupId: 'tg-1',
          name: 'সমাজ',
          details: 'অনুশীলনীর প্রশ্নোত্তর পড়া',
          repeat: { type: 'weekly', daysOfWeek: [0, 1, 2, 3, 4, 5, 6] },
          createdAt: today,
          order: 1,
          reports: {},
        },
      ],
    },
    {
      id: 'tg-2',
      name: 'ধর্ম ও আত্মউন্নয়ন',
      details: 'বই পড়া ও চিন্তাভাবনা',
      order: 1,
      tasks: [
        {
          id: 'tt-3',
          groupId: 'tg-2',
          name: 'ধর্মীয় বই পড়া',
          details: 'কমপক্ষে ৫ পৃষ্ঠা মনোযোগ দিয়ে পাঠ',
          repeat: { type: 'daily' },
          createdAt: today,
          order: 0,
          reports: {},
        },
      ],
    },
  ];

  return {
    workGroups,
    todoGroups,
    todayCustomOrder: ['tt-1', 'tt-2', 'tt-3'],
  };
}

export function loadAppData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial = getInitialDemoData();
      saveAppData(initial);
      return initial;
    }
    const parsed = JSON.parse(raw) as AppData;
    if (!parsed.workGroups || !parsed.todoGroups) {
      const initial = getInitialDemoData();
      saveAppData(initial);
      return initial;
    }
    return parsed;
  } catch (e) {
    console.error('Error loading app data from localStorage', e);
    return getInitialDemoData();
  }
}

export function saveAppData(data: AppData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Error saving app data to localStorage', e);
  }
}
