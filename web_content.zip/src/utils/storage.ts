import { Customer, Folder } from '../types';
import { toInputDateFormat } from './dateUtils';

const STORAGE_KEY_FOLDERS = 'gas_app_folders_v1';
const STORAGE_KEY_CUSTOMERS = 'gas_app_customers_v1';

// Calculate dynamic deal dates relative to current date for realistic seed data
function getRelativeDateStr(daysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return toInputDateFormat(d);
}

export const INITIAL_FOLDERS: Folder[] = [
  { id: 'f_ward1', name: 'वार्ड 1 (मुख्य बाजार)', color: '#ea580c', createdAt: new Date().toISOString() },
  { id: 'f_shanti', name: 'शांति नगर कॉलोनी', color: '#0284c7', createdAt: new Date().toISOString() },
  { id: 'f_railway', name: 'रेलवे रोड व स्टेशन', color: '#16a34a', createdAt: new Date().toISOString() },
  { id: 'f_rampur', name: 'रामपुर ग्रामीण क्षेत्र', color: '#9333ea', createdAt: new Date().toISOString() },
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'c_1',
    name: 'रमेश कुमार गुप्ता',
    phone: '9876543210',
    address: 'दुकान नं. 14, मेन चौक, मुख्य बाजार',
    folderId: 'f_ward1',
    dealDate: getRelativeDateStr(25), // Exactly 25 days ago => 26th day is TODAY!
    notes: '14.2 किग्रा घरेलू सिलेंडर',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'c_2',
    name: 'श्रीमती सुनीता शर्मा',
    phone: '9823456781',
    address: 'मकान नं. 204, गली नं. 3, शांति नगर',
    folderId: 'f_shanti',
    dealDate: getRelativeDateStr(28), // 28 days ago => 3 days OVERDUE!
    notes: 'उपभोक्ता सं. 84920',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'c_3',
    name: 'सोनू वर्मा',
    phone: '9712345678',
    address: 'प्लॉट 45, रेलवे फाटक के पास',
    folderId: 'f_railway',
    dealDate: getRelativeDateStr(12), // 12 days ago => 13 days remaining
    notes: 'नियमित ग्राहक',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'c_4',
    name: 'सुरेश पाल (प्रधान जी)',
    phone: '9934567890',
    address: 'बड़ा घर, पुराना शिव मंदिर, रामपुर',
    folderId: 'f_rampur',
    dealDate: getRelativeDateStr(25), // 25 days ago => 26th day is TODAY!
    notes: 'दो सिलेंडर कनेक्शन',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'c_5',
    name: 'राजेश तिवारी',
    phone: '9654321098',
    address: 'मकान नं. 56, शांति नगर ब्लॉक B',
    folderId: 'f_shanti',
    dealDate: getRelativeDateStr(4), // 4 days ago => 21 days remaining
    notes: 'नया कनेक्शन',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export function loadFolders(): Folder[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_FOLDERS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Error reading folders from localStorage:', err);
  }
  // Initialize default
  saveFolders(INITIAL_FOLDERS);
  return INITIAL_FOLDERS;
}

const STORAGE_KEY_LAST_SAVED = 'gas_app_last_saved_time_v1';

export function getLastSavedTime(): Date | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_LAST_SAVED);
    if (raw) {
      const d = new Date(raw);
      if (!isNaN(d.getTime())) return d;
    }
  } catch (err) {
    console.warn('Error reading last saved time:', err);
  }
  return null;
}

export function updateLastSavedTime(date = new Date()): void {
  try {
    localStorage.setItem(STORAGE_KEY_LAST_SAVED, date.toISOString());
  } catch (err) {
    console.warn('Error saving last saved time:', err);
  }
}

export function saveFolders(folders: Folder[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_FOLDERS, JSON.stringify(folders));
    updateLastSavedTime();
  } catch (err) {
    console.error('Failed to save folders to localStorage:', err);
  }
}

export function loadCustomers(): Customer[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CUSTOMERS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Error reading customers from localStorage:', err);
  }
  // Initialize default
  saveCustomers(INITIAL_CUSTOMERS);
  return INITIAL_CUSTOMERS;
}

export function saveCustomers(customers: Customer[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_CUSTOMERS, JSON.stringify(customers));
    updateLastSavedTime();
  } catch (err) {
    console.error('Failed to save customers to localStorage:', err);
  }
}

/**
 * Creates backup JSON string
 */
export function createBackupData(): string {
  const folders = loadFolders();
  const customers = loadCustomers();
  const backup = {
    appName: 'गैस ग्राहक रिकॉर्ड ऐप',
    exportDate: new Date().toISOString(),
    folders,
    customers,
  };
  return JSON.stringify(backup, null, 2);
}

/**
 * Exports data to CSV with UTF-8 BOM so Hindi renders properly in Excel
 */
export function exportToCSV(): string {
  const customers = loadCustomers();
  const folders = loadFolders();
  const folderMap = new Map(folders.map((f) => [f.id, f.name]));

  const headers = ['नाम', 'मोबाइल नंबर', 'इलाका / फोल्डर', 'डील तारीख (YYYY-MM-DD)', 'पूरा पता', 'टिप्पणी'];
  const rows = customers.map((c) => [
    `"${(c.name || '').replace(/"/g, '""')}"`,
    `"${(c.phone || '').replace(/"/g, '""')}"`,
    `"${(folderMap.get(c.folderId) || 'अन्य').replace(/"/g, '""')}"`,
    `"${c.dealDate}"`,
    `"${(c.address || '').replace(/"/g, '""')}"`,
    `"${(c.notes || '').replace(/"/g, '""')}"`,
  ]);

  // \uFEFF is UTF-8 Byte Order Mark for Microsoft Excel
  return '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
}

/**
 * Restores backup from JSON string
 */
export function restoreBackupData(jsonString: string): { success: boolean; message: string; customerCount?: number } {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || (!parsed.customers && !parsed.folders)) {
      return { success: false, message: 'अमान्य बैकअप फ़ाइल स्वरूप।' };
    }

    const folders = Array.isArray(parsed.folders) ? parsed.folders : [];
    const customers = Array.isArray(parsed.customers) ? parsed.customers : [];

    if (folders.length > 0) {
      saveFolders(folders);
    }
    if (customers.length > 0) {
      saveCustomers(customers);
    }

    return {
      success: true,
      message: `बैकअप सफलतापूर्वक रीस्टोर हुआ! (${customers.length} ग्राहक, ${folders.length} फोल्डर)`,
      customerCount: customers.length,
    };
  } catch (err) {
    return { success: false, message: 'फ़ाइल पढ़ने में त्रुटि: ' + (err instanceof Error ? err.message : 'Unknown') };
  }
}
