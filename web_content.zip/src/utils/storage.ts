import type { ChatSession, ReplyLanguage } from '../types/chat';

const SESSIONS_STORAGE_KEY = 'dawitai_sessions_v1';
const ACTIVE_SESSION_KEY = 'dawitai_active_session_v1';
const REPLY_LANG_KEY = 'dawitai_reply_lang_v1';

export function loadSessions(): ChatSession[] {
  try {
    const raw = localStorage.getItem(SESSIONS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is ChatSession =>
        item &&
        typeof item.id === 'string' &&
        typeof item.title === 'string' &&
        Array.isArray(item.messages)
    );
  } catch {
    return [];
  }
}

export function saveSessions(sessions: ChatSession[]): void {
  try {
    localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(sessions));
  } catch {
    // Ignore storage quota errors cleanly
  }
}

export function loadActiveSessionId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_SESSION_KEY);
  } catch {
    return null;
  }
}

export function saveActiveSessionId(id: string | null): void {
  try {
    if (id) {
      localStorage.setItem(ACTIVE_SESSION_KEY, id);
    } else {
      localStorage.removeItem(ACTIVE_SESSION_KEY);
    }
  } catch {
    // Ignore storage errors
  }
}

export function loadReplyLanguage(): ReplyLanguage {
  try {
    const stored = localStorage.getItem(REPLY_LANG_KEY);
    return stored === 'english' ? 'english' : 'amharic';
  } catch {
    return 'amharic';
  }
}

export function saveReplyLanguage(lang: ReplyLanguage): void {
  try {
    localStorage.setItem(REPLY_LANG_KEY, lang);
  } catch {
    // Ignore storage errors
  }
}

export function createSessionTitle(firstQuestion: string): string {
  const cleaned = firstQuestion.trim().replace(/\s+/g, ' ');
  if (cleaned.length <= 44) return cleaned;
  return `${cleaned.slice(0, 44).trim()}…`;
}
