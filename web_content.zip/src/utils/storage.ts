import { ChatMessage, Attachment, ChatSession, UserProfile } from '../types';

const STORAGE_KEY = 'nova_chat_history';
const SESSIONS_STORAGE_KEY = 'nova_chat_sessions';
const ACTIVE_SESSION_ID_KEY = 'nova_active_session_id';
const USER_PROFILE_KEY = 'nova_user_profile';

/**
 * Compresses an image file on an HTML5 canvas before adding to state.
 * Reduces 10MB phone camera pictures down to ~80-150KB without perceptual quality loss!
 */
export async function compressImageFile(
  file: File,
  maxDimension = 1280,
  quality = 0.82
): Promise<{ base64: string; previewUrl: string; size: number }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          return resolve({
            base64: reader.result as string,
            previewUrl: reader.result as string,
            size: file.size,
          });
        }

        ctx.drawImage(img, 0, 0, width, height);
        const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
        resolve({
          base64: compressedBase64,
          previewUrl: compressedBase64,
          size: Math.round((compressedBase64.length * 3) / 4),
        });
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Creates an ultra-lightweight thumbnail for long-term storage in localStorage
 */
function createStorageAttachment(att: Attachment): Attachment {
  if (att.base64 && att.base64.length > 50000) {
    return {
      ...att,
      base64: undefined,
      previewUrl: att.previewUrl && att.previewUrl.length < 50000 ? att.previewUrl : undefined,
    };
  }
  return att;
}

/**
 * Safely saves messages for the legacy single thread or active thread
 */
export function saveChatHistorySafely(messages: ChatMessage[]): void {
  try {
    const leanMessages = messages.map((msg) => ({
      ...msg,
      attachments: msg.attachments?.map(createStorageAttachment),
    }));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(leanMessages));
  } catch (err) {
    console.warn('LocalStorage save warning, trimming older history:', err);
    try {
      const trimmed = messages.slice(-25).map((msg) => ({
        ...msg,
        attachments: msg.attachments?.map(createStorageAttachment),
      }));
      localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
    } catch {}
  }
}

export function loadChatHistorySafely(): ChatMessage[] | null {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return null;
    return JSON.parse(saved) as ChatMessage[];
  } catch {
    return null;
  }
}

/**
 * Multi-session Chat History Storage
 */
export function loadSessionsSafely(): ChatSession[] {
  try {
    const saved = localStorage.getItem(SESSIONS_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as ChatSession[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }

    // Migration from single chat history if available
    const legacyMessages = loadChatHistorySafely();
    const defaultSession: ChatSession = {
      id: 'session-default',
      title: legacyMessages && legacyMessages.length > 1
        ? (legacyMessages.find(m => m.role === 'user')?.content.slice(0, 30) || 'Main Conversation')
        : 'Welcome to Nova',
      createdAt: Date.now() - 3600000,
      updatedAt: Date.now(),
      messages: legacyMessages || [],
    };
    saveSessionsSafely([defaultSession]);
    return [defaultSession];
  } catch {
    return [];
  }
}

export function saveSessionsSafely(sessions: ChatSession[]): void {
  try {
    const leanSessions = sessions.map((sess) => ({
      ...sess,
      messages: sess.messages.slice(-35).map((msg) => ({
        ...msg,
        attachments: msg.attachments?.map(createStorageAttachment),
      })),
    }));
    localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(leanSessions));
  } catch (err) {
    console.warn('Sessions storage warning, trimming older sessions:', err);
    try {
      // Keep most recent 5 sessions with lean messages
      const trimmed = sessions.slice(0, 5).map((sess) => ({
        ...sess,
        messages: sess.messages.slice(-20).map((msg) => ({
          ...msg,
          attachments: msg.attachments?.map(createStorageAttachment),
        })),
      }));
      localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(trimmed));
    } catch {}
  }
}

export function loadActiveSessionId(): string {
  try {
    return localStorage.getItem(ACTIVE_SESSION_ID_KEY) || 'session-default';
  } catch {
    return 'session-default';
  }
}

export function saveActiveSessionId(id: string): void {
  try {
    localStorage.setItem(ACTIVE_SESSION_ID_KEY, id);
  } catch {}
}

/**
 * User Profile Storage
 */
const DEFAULT_USER_PROFILE: UserProfile = {
  id: 'user-default',
  name: 'Nova User',
  email: 'user@novamast.ai',
  avatar: '⚡',
  isLoggedIn: false,
  joinedAt: Date.now(),
  preferredLanguage: 'hinglish',
};

export function loadUserProfile(): UserProfile {
  try {
    const saved = localStorage.getItem(USER_PROFILE_KEY);
    if (!saved) return DEFAULT_USER_PROFILE;
    return { ...DEFAULT_USER_PROFILE, ...JSON.parse(saved) };
  } catch {
    return DEFAULT_USER_PROFILE;
  }
}

export function saveUserProfile(profile: UserProfile): void {
  try {
    localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(profile));
  } catch {}
}

/**
 * Measures actual storage consumed by Nova in the browser
 */
export function getStorageUsage(): {
  bytesUsed: number;
  formattedUsed: string;
  percentageOfQuota: number;
  messageCount: number;
  sessionsCount: number;
} {
  try {
    let totalBytes = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('nova_') || key === STORAGE_KEY)) {
        const val = localStorage.getItem(key) || '';
        totalBytes += (key.length + val.length) * 2;
      }
    }

    const kb = totalBytes / 1024;
    const mb = kb / 1024;
    const formattedUsed = mb >= 1 ? `${mb.toFixed(2)} MB` : `${kb.toFixed(1)} KB`;
    const percentageOfQuota = Math.min(100, (totalBytes / (5 * 1024 * 1024)) * 100);

    const sessions = loadSessionsSafely();
    const sessionsCount = sessions.length;
    let messageCount = 0;
    sessions.forEach(s => { messageCount += s.messages.length; });

    return {
      bytesUsed: totalBytes,
      formattedUsed,
      percentageOfQuota,
      messageCount,
      sessionsCount,
    };
  } catch {
    return {
      bytesUsed: 0,
      formattedUsed: '0 KB',
      percentageOfQuota: 0,
      messageCount: 0,
      sessionsCount: 0,
    };
  }
}
