import { UserMemory, GeneratedImageItem } from "../types";

const MEMORY_KEY = "ranabir_ai_memory_v1";
const IMAGES_KEY = "ranabir_ai_images_v1";

const DEFAULT_MEMORY: UserMemory = {
  addressingMode: "tumi",
  profession: "Student / Developer / Creator",
  interests: "Coding, AI Tools, Bengali Literature, Technology",
  language: "bn",
  facts: [
    "পছন্দের ভাষা: বাংলা ও ইংরেজি",
    "পছন্দের সম্বোধন: 'তুমি' বা 'আপনি' (কখনো নাম ধরে ডাকা যাবে না)",
    "পছন্দের বিষয়: Artificial Intelligence এবং Flutter",
    "লক্ষ্য: সহজে প্রযুক্তির সাহায্য নিয়ে নিত্যদিনের কাজ সমাধান করা",
  ],
  lastUpdated: new Date().toISOString(),
};

// Simple reversible obfuscation simulating local vault encryption
function encryptData(data: any): string {
  try {
    const str = JSON.stringify(data);
    return btoa(encodeURIComponent(str));
  } catch (e) {
    return "";
  }
}

function decryptData<T>(cipher: string, fallback: T): T {
  try {
    if (!cipher) return fallback;
    const str = decodeURIComponent(atob(cipher));
    return JSON.parse(str) as T;
  } catch (e) {
    return fallback;
  }
}

export function loadUserMemory(): UserMemory {
  try {
    const raw = localStorage.getItem(MEMORY_KEY);
    if (!raw) return DEFAULT_MEMORY;
    return decryptData<UserMemory>(raw, DEFAULT_MEMORY);
  } catch (e) {
    return DEFAULT_MEMORY;
  }
}

export function saveUserMemory(memory: UserMemory): void {
  try {
    const encrypted = encryptData(memory);
    localStorage.setItem(MEMORY_KEY, encrypted);
  } catch (e) {
    console.error("Failed to save memory to local encrypted vault:", e);
  }
}

export function loadSavedImages(): GeneratedImageItem[] {
  try {
    const raw = localStorage.getItem(IMAGES_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveImages(images: GeneratedImageItem[]): void {
  try {
    localStorage.setItem(IMAGES_KEY, JSON.stringify(images.slice(0, 20)));
  } catch (e) {
    console.error("Failed to save images:", e);
  }
}

export function purgeAllData(): void {
  localStorage.removeItem(MEMORY_KEY);
  localStorage.removeItem(IMAGES_KEY);
  localStorage.removeItem("ranabir_chat_history");
}
