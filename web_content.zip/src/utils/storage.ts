import { Activity, AppState, DayRecord, PhotoRecord, UserProfile, WeightRecord } from '../types';
import { formatDate } from './tracker';

const STORAGE_KEY = 'glowup90_app_state_v1';

export const DEFAULT_ACTIVITIES: Activity[] = [
  // A. Gym & Workout
  {
    id: 'workout_pushups',
    name: 'Push-ups',
    category: 'workout',
    workoutCategory: 'Upper Body',
    sets: 3,
    reps: 8,
    restSeconds: 60,
    scheduledTime: '16:00',
    scheduleType: 'daily',
    selectedDays: [1, 2, 3, 4, 5, 6],
    reminderEnabled: true,
    description: 'Chest, triceps & core strength. Keep torso rigid and elbows at 45 degrees.'
  },
  {
    id: 'workout_squats',
    name: 'Bodyweight Squats',
    category: 'workout',
    workoutCategory: 'Lower Body',
    sets: 3,
    reps: 15,
    restSeconds: 60,
    scheduledTime: '16:10',
    scheduleType: 'daily',
    selectedDays: [1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Quadriceps and glute hypertrophy. Full depth below parallel.'
  },
  {
    id: 'workout_backpack_rows',
    name: 'Backpack Rows',
    category: 'workout',
    workoutCategory: 'Upper Body',
    sets: 3,
    reps: 12,
    restSeconds: 60,
    scheduledTime: '16:20',
    scheduleType: 'daily',
    selectedDays: [1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Upper back and posture sculpt. Squeeze scapulae at the peak of each rep.'
  },
  {
    id: 'workout_plank',
    name: 'Core Plank',
    category: 'workout',
    workoutCategory: 'Core',
    sets: 3,
    durationSeconds: 30,
    restSeconds: 45,
    scheduledTime: '16:30',
    scheduleType: 'daily',
    selectedDays: [1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Transverse abdominis engagement for a flat, vacuum-tight waist.'
  },
  {
    id: 'workout_lunges',
    name: 'Walking Lunges',
    category: 'workout',
    workoutCategory: 'Lower Body',
    sets: 2,
    reps: 10,
    restSeconds: 60,
    scheduledTime: '16:40',
    scheduleType: 'daily',
    selectedDays: [1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Unilateral leg balance and hip stability. 10 reps each leg.'
  },

  // B. Skincare - Morning Routine
  {
    id: 'skincare_am_wash',
    name: 'Morning Gentle Face Wash',
    category: 'skincare',
    routineType: 'morning',
    scheduledTime: '08:00',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: true,
    description: 'Lukewarm water with low-pH foaming cleanser to clear overnight sebum.'
  },
  {
    id: 'skincare_am_niacinamide',
    name: 'Niacinamide 10% Serum',
    category: 'skincare',
    routineType: 'morning',
    isOptional: true,
    scheduledTime: '08:05',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Minimizes pore appearance, evens skin tone & controls excess oil.'
  },
  {
    id: 'skincare_am_moisturizer',
    name: 'Hydrating Ceramide Moisturizer',
    category: 'skincare',
    routineType: 'morning',
    scheduledTime: '08:10',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Locks in hydration and protects skin moisture barrier.'
  },
  {
    id: 'skincare_am_sunscreen',
    name: 'Broad-Spectrum Sunscreen SPF 50+ PA++++',
    category: 'skincare',
    routineType: 'morning',
    scheduledTime: '08:15',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: true,
    description: 'Non-negotiable UV protection against photo-aging, hyperpigmentation and wrinkles.'
  },

  // B. Skincare - Night Routine
  {
    id: 'skincare_pm_wash',
    name: 'Night Double Cleanse / Face Wash',
    category: 'skincare',
    routineType: 'night',
    scheduledTime: '21:45',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: true,
    description: 'Dissolve sunscreen and airborne particulates from the day.'
  },
  {
    id: 'skincare_pm_moisturizer',
    name: 'Night Barrier Repair Moisturizer',
    category: 'skincare',
    routineType: 'night',
    scheduledTime: '21:50',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Deep cellular hydration with hyaluronic acid and centella asiatica.'
  },
  {
    id: 'skincare_pm_lip_balm',
    name: 'Intense Hydrating Lip Balm',
    category: 'skincare',
    routineType: 'night',
    scheduledTime: '21:55',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Prevent cracked lips and overnight moisture loss.'
  },

  // C. Diet & Nutrition
  {
    id: 'diet_breakfast',
    name: 'High Protein Breakfast',
    category: 'nutrition',
    mealType: 'breakfast',
    calories: 520,
    protein: 38,
    quantity: '3 eggs, 2 slice wholewheat, 1 avocado',
    scheduledTime: '08:30',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: true,
    description: 'Fuel muscle repair and sustained mental energy.'
  },
  {
    id: 'diet_morning_snack',
    name: 'Morning Protein Shake / Snack',
    category: 'nutrition',
    mealType: 'morning_snack',
    calories: 220,
    protein: 25,
    quantity: '1 scoop whey with almond milk & blueberries',
    scheduledTime: '11:00',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Antioxidants and steady amino acid release.'
  },
  {
    id: 'diet_lunch',
    name: 'Lean Clean Lunch',
    category: 'nutrition',
    mealType: 'lunch',
    calories: 680,
    protein: 45,
    quantity: '200g chicken breast, jasmine rice & steamed broccoli',
    scheduledTime: '13:30',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'High micronutrient density with healthy fats and fiber.'
  },
  {
    id: 'diet_evening_snack',
    name: 'Pre-Workout / Evening Snack',
    category: 'nutrition',
    mealType: 'evening_snack',
    calories: 190,
    protein: 14,
    quantity: 'Greek yogurt with raw almonds and honey',
    scheduledTime: '15:30',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Quick glycogen replenishment before training.'
  },
  {
    id: 'diet_dinner',
    name: 'Nutrient-Dense Dinner',
    category: 'nutrition',
    mealType: 'dinner',
    calories: 620,
    protein: 42,
    quantity: 'Wild salmon or lean steak with sweet potato & greens',
    scheduledTime: '19:45',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Omega-3 fatty acids for skin elasticity and anti-inflammation.'
  },

  // E. Hair & Grooming
  {
    id: 'grooming_dental_am',
    name: 'Morning Dental Hygiene & Tongue Scraping',
    category: 'grooming',
    groomingFrequency: 'daily',
    scheduledTime: '07:30',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Electric brushing, copper tongue scraping & antiseptic rinse.'
  },
  {
    id: 'grooming_hair_styling',
    name: 'Hair Styling & Scalp Tonic',
    category: 'grooming',
    groomingFrequency: 'daily',
    scheduledTime: '08:20',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Scalp stimulation and matte lightweight styling cream.'
  },
  {
    id: 'grooming_hair_wash',
    name: 'Sulfate-Free Shampoo & Conditioning',
    category: 'grooming',
    groomingFrequency: 'weekly',
    scheduledTime: '18:00',
    scheduleType: 'custom_days',
    selectedDays: [1, 3, 5], // Mon, Wed, Fri
    reminderEnabled: false,
    description: 'Gentle wash without stripping natural scalp sebum.'
  },
  {
    id: 'grooming_hair_oil',
    name: 'Rosemary & Jojoba Scalp Oil Massage',
    category: 'grooming',
    groomingFrequency: 'weekly',
    scheduledTime: '20:30',
    scheduleType: 'custom_days',
    selectedDays: [0, 4], // Sun, Thu
    reminderEnabled: false,
    description: 'Stimulate follicle blood flow and hair thickness.'
  },
  {
    id: 'grooming_eyebrows',
    name: 'Eyebrow Shaping & Facial Grooming',
    category: 'grooming',
    groomingFrequency: 'weekly',
    scheduledTime: '11:00',
    scheduleType: 'custom_days',
    selectedDays: [6], // Saturday
    reminderEnabled: false,
    description: 'Pluck stray hairs and clean up brow arch lines.'
  },
  {
    id: 'grooming_dental_pm',
    name: 'Night Dental Hygiene & Flossing',
    category: 'grooming',
    groomingFrequency: 'daily',
    scheduledTime: '22:15',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Thorough interdental flossing and fluoride remineralization.'
  },

  // F. Posture & Fitness
  {
    id: 'posture_chin_tucks',
    name: 'Chin Tucks & Deep Cervical Flexion',
    category: 'posture',
    postureDurationMinutes: 5,
    scheduledTime: '10:00',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Fixes forward-head posture and sharpens jawline-to-neck angle.'
  },
  {
    id: 'posture_shoulder_stretches',
    name: 'Doorway & Shoulder Retraction Stretches',
    category: 'posture',
    postureDurationMinutes: 5,
    scheduledTime: '14:00',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Opens tight pecs and pulls rounded shoulders back.'
  },
  {
    id: 'posture_wall_exercise',
    name: 'Wall Posture Alignment Angels',
    category: 'posture',
    postureDurationMinutes: 5,
    scheduledTime: '16:50',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Heels, buttocks, upper back & head flat against wall. Slide arms up.'
  },
  {
    id: 'posture_daily_walk',
    name: 'Brisk 8,000 Step Posture Walk',
    category: 'posture',
    postureDurationMinutes: 35,
    scheduledTime: '18:30',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Upright gait with chest proud. Lymphatic drainage and calorie burn.'
  },
  {
    id: 'posture_night_stretching',
    name: 'Spinal Decompression & Hip Flexor Stretch',
    category: 'posture',
    postureDurationMinutes: 10,
    scheduledTime: '21:30',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: false,
    description: 'Releases tension from sitting and promotes restorative circulation.'
  },

  // G. Sleep Tracker
  {
    id: 'sleep_wind_down',
    name: 'Blue Light Cutoff & Wind Down',
    category: 'sleep',
    scheduledTime: '22:30',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: true,
    description: 'Put devices away. Lower room temperature to 19°C for melatonin production.'
  },
  {
    id: 'sleep_bedtime',
    name: 'In Bed for 8-Hour Restorative Sleep',
    category: 'sleep',
    scheduledTime: '23:00',
    scheduleType: 'daily',
    selectedDays: [0, 1, 2, 3, 4, 5, 6],
    reminderEnabled: true,
    description: 'Target wake-up at 07:00 AM (480 min sleep duration).'
  }
];

export function getInitialUserProfile(): UserProfile {
  // Let start date be 13 days ago so today is Day 14 of 90!
  const today = new Date();
  const start = new Date(today);
  start.setDate(today.getDate() - 13);

  return {
    name: 'Alex',
    tagline: '90-Day Aesthetic & Physique Re-engineering',
    startDate: formatDate(start),
    targetWeightKg: 72.0,
    startWeightKg: 78.5,
    currentWeightKg: 75.8,
    waterGoalMl: 3000,
    calorieGoal: 2200,
    proteinGoalG: 145,
    sleepGoalHours: 8,
    darkMode: false,
    notificationsEnabled: false,
  };
}

/**
 * Generate rich, realistic seed history for previous 13 days
 */
export function generateSeedHistory(startDateStr: string, todayStr: string): Record<string, DayRecord> {
  const history: Record<string, DayRecord> = {};
  const today = new Date();

  // Create 13 previous days
  for (let i = 13; i >= 1; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const dStr = formatDate(d);

    const tasks: Record<string, { activityId: string; completed: boolean; completedAt: string }> = {};
    // Give each previous day 80% to 100% completion
    DEFAULT_ACTIVITIES.forEach((act, actIdx) => {
      // Keep most completed for good streak
      const isCompleted = (i + actIdx) % 7 !== 0;
      tasks[act.id] = {
        activityId: act.id,
        completed: isCompleted,
        completedAt: `${act.scheduledTime}:00`
      };
    });

    history[dStr] = {
      date: dStr,
      tasks,
      waterConsumedMl: 2750 + ((i * 50) % 500),
      waterGoalMl: 3000,
      sleepBedtime: '23:15',
      sleepWakeTime: '07:00',
      sleepDurationMinutes: 465,
      notes: i === 13 ? 'Day 1 completed! Solid start to the 90-day glowup.' : undefined
    };
  }

  // Today (Day 14) - Partially completed (e.g. morning routine done, rest pending)
  const todayTasks: Record<string, { activityId: string; completed: boolean; completedAt?: string }> = {};
  DEFAULT_ACTIVITIES.forEach((act) => {
    // Complete early morning items by default so user starts with a realistic ~50%
    const hour = parseInt(act.scheduledTime.split(':')[0], 10);
    const completed = hour <= 12;
    todayTasks[act.id] = {
      activityId: act.id,
      completed,
      completedAt: completed ? `${act.scheduledTime}:00` : undefined
    };
  });

  history[todayStr] = {
    date: todayStr,
    tasks: todayTasks,
    waterConsumedMl: 1750,
    waterGoalMl: 3000,
    sleepBedtime: '23:00',
    sleepWakeTime: '07:00',
    sleepDurationMinutes: 480
  };

  return history;
}

export function generateSeedWeights(todayStr: string): WeightRecord[] {
  const weights: WeightRecord[] = [];
  const today = new Date();

  const values = [78.5, 78.3, 78.0, 77.8, 77.5, 77.3, 77.1, 76.8, 76.6, 76.4, 76.2, 76.0, 75.9, 75.8];
  values.forEach((w, idx) => {
    const d = new Date(today);
    d.setDate(today.getDate() - (13 - idx));
    const dStr = formatDate(d);
    weights.push({
      id: `weight_${idx}`,
      date: dStr,
      weightKg: w,
      bodyFatPercentage: Math.max(12, Number((18.5 - (idx * 0.25)).toFixed(1))),
      notes: idx === 0 ? 'Baseline measurement. Day 1.' : idx === 13 ? 'Day 14 check-in. Noticeable waist tightening.' : undefined
    });
  });

  return weights;
}

export function generateSeedPhotos(): PhotoRecord[] {
  // Pre-seed sample before and progress entries with clean placeholder cards
  return [
    {
      id: 'photo_day1_face',
      date: 'Day 1',
      dayNumber: 1,
      type: 'before',
      angle: 'jawline',
      imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
      weightKg: 78.5,
      notes: 'Day 1 baseline: Facial puffiness, slight water retention.'
    },
    {
      id: 'photo_day14_face',
      date: 'Day 14',
      dayNumber: 14,
      type: 'progress',
      angle: 'jawline',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
      weightKg: 75.8,
      notes: 'Day 14 progress: Sharper jawline contour and noticeable reduction in cheek bloat.'
    }
  ];
}

/**
 * Load entire App State from local storage or initialize with defaults
 */
export function loadAppState(): AppState {
  const todayStr = formatDate(new Date());

  try {
    const serialized = localStorage.getItem(STORAGE_KEY);
    if (serialized) {
      const parsed: AppState = JSON.parse(serialized);
      // Ensure today's day record exists
      if (!parsed.history[todayStr]) {
        parsed.history[todayStr] = {
          date: todayStr,
          tasks: {},
          waterConsumedMl: 0,
          waterGoalMl: parsed.profile.waterGoalMl || 3000,
        };
      }
      parsed.activeDate = todayStr;
      return parsed;
    }
  } catch (err) {
    console.error('Failed to parse localStorage data:', err);
  }

  // Create fresh state
  const profile = getInitialUserProfile();
  const activities = [...DEFAULT_ACTIVITIES];
  const history = generateSeedHistory(profile.startDate, todayStr);
  const weightHistory = generateSeedWeights(todayStr);
  const photos = generateSeedPhotos();

  const state: AppState = {
    profile,
    activities,
    history,
    weightHistory,
    photos,
    activeDate: todayStr,
  };

  saveAppState(state);
  return state;
}

/**
 * Save entire App State to local storage
 */
export function saveAppState(state: AppState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to save state to localStorage:', err);
  }
}

/**
 * Export state as JSON string for backup
 */
export function exportDataAsJson(state: AppState): string {
  return JSON.stringify(state, null, 2);
}

/**
 * Import state from backup JSON
 */
export function importDataFromJson(jsonStr: string): AppState {
  const parsed = JSON.parse(jsonStr);
  if (!parsed.profile || !parsed.activities || !parsed.history) {
    throw new Error('Invalid backup file structure.');
  }
  saveAppState(parsed);
  return parsed;
}

/**
 * Reset local storage back to fresh initial seed
 */
export function resetAppStateToDefaults(): AppState {
  localStorage.removeItem(STORAGE_KEY);
  return loadAppState();
}
