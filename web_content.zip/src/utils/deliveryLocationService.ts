import { Store, StoreLocation, ShippingSettings } from '../types';

export interface BDDistrict {
  name: string;
  nameBn: string;
}

export interface BDDivision {
  name: string;
  nameBn: string;
  districts: BDDistrict[];
}

export const BD_DIVISIONS: BDDivision[] = [
  {
    name: 'Sylhet',
    nameBn: 'সিলেট',
    districts: [
      { name: 'Sylhet', nameBn: 'সিলেট' },
      { name: 'Moulvibazar', nameBn: 'মৌলভীবাজার' },
      { name: 'Habiganj', nameBn: 'হবিগঞ্জ' },
      { name: 'Sunamganj', nameBn: 'সুনামগঞ্জ' }
    ]
  },
  {
    name: 'Dhaka',
    nameBn: 'ঢাকা',
    districts: [
      { name: 'Dhaka', nameBn: 'ঢাকা' },
      { name: 'Gazipur', nameBn: 'গাজীপুর' },
      { name: 'Narayanganj', nameBn: 'নারায়ণগঞ্জ' },
      { name: 'Tangail', nameBn: 'টাঙ্গাইল' },
      { name: 'Narsingdi', nameBn: 'নরসিংদী' },
      { name: 'Manikganj', nameBn: 'মানিকগঞ্জ' },
      { name: 'Munshiganj', nameBn: 'মুন্সীগঞ্জ' },
      { name: 'Faridpur', nameBn: 'ফরিদপুর' },
      { name: 'Gopalganj', nameBn: 'গোপালগঞ্জ' },
      { name: 'Madaripur', nameBn: 'মাদারীপুর' },
      { name: 'Rajbari', nameBn: 'রাজবাড়ী' },
      { name: 'Shariatpur', nameBn: 'শরীয়তপুর' },
      { name: 'Kishoreganj', nameBn: 'কিশোরগঞ্জ' }
    ]
  },
  {
    name: 'Chattogram',
    nameBn: 'চট্টগ্রাম',
    districts: [
      { name: 'Chattogram', nameBn: 'চট্টগ্রাম' },
      { name: 'Cox\'s Bazar', nameBn: 'কক্সবাজার' },
      { name: 'Cumilla', nameBn: 'কুমিল্লা' },
      { name: 'Feni', nameBn: 'ফেনী' },
      { name: 'Brahmanbaria', nameBn: 'ব্রাহ্মণবাড়িয়া' },
      { name: 'Noakhali', nameBn: 'নোয়াখালী' },
      { name: 'Chandpur', nameBn: 'চাঁদপুর' },
      { name: 'Lakshmipur', nameBn: 'লক্ষ্মীপুর' },
      { name: 'Rangamati', nameBn: 'রাঙ্গামাটি' },
      { name: 'Khagrachhari', nameBn: 'খাগড়াছড়ি' },
      { name: 'Bandarban', nameBn: 'বান্দরবান' }
    ]
  },
  {
    name: 'Rajshahi',
    nameBn: 'রাজশাহী',
    districts: [
      { name: 'Rajshahi', nameBn: 'রাজশাহী' },
      { name: 'Bogura', nameBn: 'বগুড়া' },
      { name: 'Pabna', nameBn: 'পাবনা' },
      { name: 'Sirajganj', nameBn: 'সিরাজগঞ্জ' },
      { name: 'Naogaon', nameBn: 'নওগাঁ' },
      { name: 'Natore', nameBn: 'নাটোর' },
      { name: 'Joypurhat', nameBn: 'জয়পুরহাট' },
      { name: 'Chapainawabganj', nameBn: 'চাঁপাইনবাবগঞ্জ' }
    ]
  },
  {
    name: 'Khulna',
    nameBn: 'খুলনা',
    districts: [
      { name: 'Khulna', nameBn: 'খুলনা' },
      { name: 'Jashore', nameBn: 'যশোর' },
      { name: 'Kushtia', nameBn: 'কুষ্টিয়া' },
      { name: 'Satkhira', nameBn: 'সাতক্ষীরা' },
      { name: 'Bagerhat', nameBn: 'বাগেরহাট' },
      { name: 'Jhenaidah', nameBn: 'ঝিনাইদহ' },
      { name: 'Chuadanga', nameBn: 'চুয়াডাঙ্গা' },
      { name: 'Meherpur', nameBn: 'মেহেরপুর' },
      { name: 'Narail', nameBn: 'নড়াইল' },
      { name: 'Magura', nameBn: 'মাগুরা' }
    ]
  },
  {
    name: 'Barishal',
    nameBn: 'বরিশাল',
    districts: [
      { name: 'Barishal', nameBn: 'বরিশাল' },
      { name: 'Patuakhali', nameBn: 'পটুয়াখালী' },
      { name: 'Bhola', nameBn: 'ভোলা' },
      { name: 'Pirojpur', nameBn: 'পিরোজপুর' },
      { name: 'Barguna', nameBn: 'বরগুনা' },
      { name: 'Jhalokathi', nameBn: 'ঝালকাঠি' }
    ]
  },
  {
    name: 'Rangpur',
    nameBn: 'রংপুর',
    districts: [
      { name: 'Rangpur', nameBn: 'রংপুর' },
      { name: 'Dinajpur', nameBn: 'দিনাজপুর' },
      { name: 'Gaibandha', nameBn: 'গাইবান্ধা' },
      { name: 'Kurigram', nameBn: 'কুড়িগ্রাম' },
      { name: 'Lalmonirhat', nameBn: 'লালমনিরহাট' },
      { name: 'Nilphamari', nameBn: 'নীলফামারী' },
      { name: 'Panchagarh', nameBn: 'পঞ্চগড়' },
      { name: 'Thakurgaon', nameBn: 'ঠাকুরগাঁও' }
    ]
  },
  {
    name: 'Mymensingh',
    nameBn: 'ময়মনসিংহ',
    districts: [
      { name: 'Mymensingh', nameBn: 'ময়মনসিংহ' },
      { name: 'Jamalpur', nameBn: 'জামালপুর' },
      { name: 'Netrokona', nameBn: 'নেত্রকোণা' },
      { name: 'Sherpur', nameBn: 'শেরপুর' }
    ]
  }
];

export const ALL_BD_DISTRICTS: BDDistrict[] = BD_DIVISIONS.flatMap(div => div.districts);
export const BD_DISTRICTS_FLAT: BDDistrict[] = ALL_BD_DISTRICTS;

/**
 * Normalizes location names to handle variations in spelling, Bengali/English terms,
 * suffixes like "City", "Metro", "Sadar", "Zila", etc.
 */
export function normalizeLocationName(input?: string): string {
  if (!input || typeof input !== 'string') return '';
  let str = input.toLowerCase().trim();

  // Normalize Bengali variations
  const bnToEnMap: Record<string, string> = {
    'সিলেট': 'sylhet',
    'ঢাকা': 'dhaka',
    'চট্টগ্রাম': 'chattogram',
    'চট্টগ্রাম মেট্রো': 'chattogram',
    'রাজশাহী': 'rajshahi',
    'খুলনা': 'khulna',
    'বরিশাল': 'barishal',
    'রংপুর': 'rangpur',
    'ময়মনসিংহ': 'mymensingh',
    'বগুড়া': 'bogura',
    'কুমিল্লা': 'cumilla',
    'যশোর': 'jashore',
    'মৌলভীবাজার': 'moulvibazar',
    'হবিগঞ্জ': 'habiganj',
    'সুনামগঞ্জ': 'sunamganj',
    'কক্সবাজার': 'coxsbazar',
    'গাজীপুর': 'gazipur',
    'নারায়ণগঞ্জ': 'narayanganj'
  };

  for (const [bn, en] of Object.entries(bnToEnMap)) {
    if (str.includes(bn)) {
      return en;
    }
  }

  // Remove common suffixes and prefixes
  str = str
    .replace(/['’]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // Common alternate English spellings
  if (str.includes('chittagong') || str.includes('ctg') || str.includes('chattogram')) return 'chattogram';
  if (str.includes('comilla') || str.includes('cumilla')) return 'cumilla';
  if (str.includes('jessore') || str.includes('jashore')) return 'jashore';
  if (str.includes('bogra') || str.includes('bogura')) return 'bogura';
  if (str.includes('barisal') || str.includes('barishal')) return 'barishal';
  if (str.includes('cox') && str.includes('bazar')) return 'coxsbazar';
  if (str.includes('brahmanbaria') || str.includes('b baria')) return 'brahmanbaria';
  if (str.includes('moulvi') || str.includes('moulvibazar') || str.includes('maulvi')) return 'moulvibazar';
  if (str.includes('habiganj') || str.includes('hobiganj')) return 'habiganj';
  if (str.includes('sunamganj')) return 'sunamganj';
  if (str.includes('sylhet')) return 'sylhet';
  if (str.includes('dhaka')) return 'dhaka';
  if (str.includes('gazipur')) return 'gazipur';
  if (str.includes('narayanganj')) return 'narayanganj';
  if (str.includes('rajshahi')) return 'rajshahi';
  if (str.includes('khulna')) return 'khulna';
  if (str.includes('rangpur')) return 'rangpur';
  if (str.includes('mymensingh')) return 'mymensingh';

  // Strip noise words
  const cleanTokens = str
    .split(' ')
    .filter(t => !['city', 'metro', 'district', 'zila', 'sadar', 'division', 'north', 'south', 'east', 'west'].includes(t));

  return cleanTokens.join(' ').trim() || str;
}

/**
 * Resolves the primary district or city of a store
 */
export function getStoreLocationDistrict(store?: Partial<Store> | null): string {
  if (!store) return 'Sylhet';
  
  if (store.storeLocation?.district) return store.storeLocation.district;
  if (store.storeLocation?.city) return store.storeLocation.city;
  if (store.city) return store.city;
  
  // Extract from address string if available
  if (store.address) {
    const normAddr = store.address.toLowerCase();
    for (const dist of ALL_BD_DISTRICTS) {
      if (normAddr.includes(dist.name.toLowerCase())) {
        return dist.name;
      }
    }
  }

  return 'Sylhet';
}

/**
 * Resolves the primary district or city of a customer
 */
export function getCustomerLocationDistrict(customerLoc?: string | { city?: string; district?: string; division?: string } | null): string {
  if (!customerLoc) return '';
  if (typeof customerLoc === 'string') {
    const norm = normalizeLocationName(customerLoc);
    for (const dist of ALL_BD_DISTRICTS) {
      if (normalizeLocationName(dist.name) === norm) return dist.name;
    }
    return customerLoc.trim();
  }

  if (customerLoc.district) return customerLoc.district;
  if (customerLoc.city) return customerLoc.city;
  if (customerLoc.division) return customerLoc.division;
  return '';
}

export interface DeliveryZoneResult {
  isLocal: boolean;
  deliveryZone: 'local' | 'outside';
  charge: number;
  baseCharge: number;
  isFreeShipping: boolean;
  storeLocationSummary: string;
  customerLocationSummary: string;
  zoneDescription: string;
  zoneDescriptionBn: string;
}

/**
 * Core dynamic delivery calculation:
 * IF customerCity === storeCity (normalized) -> localDeliveryCharge (default ৳60)
 * ELSE -> outsideDeliveryCharge (default ৳120)
 * Evaluated relative to EACH STORE'S OWN CONFIGURED LOCATION.
 */
export function calculateDeliveryCharge(
  customerLocation: { city?: string; district?: string; division?: string } | string | undefined | null,
  storeLocation: StoreLocation | Partial<Store> | string | undefined | null,
  settings?: Partial<ShippingSettings> | null,
  orderSubtotal: number = 0
): DeliveryZoneResult {
  // Resolve Store Location District / City
  let storeDistrict = 'Sylhet';
  if (typeof storeLocation === 'string') {
    storeDistrict = storeLocation;
  } else if (storeLocation && typeof storeLocation === 'object') {
    if ('storeLocation' in storeLocation && storeLocation.storeLocation?.district) {
      storeDistrict = storeLocation.storeLocation.district;
    } else if ('district' in storeLocation && storeLocation.district) {
      storeDistrict = storeLocation.district;
    } else if ('city' in storeLocation && storeLocation.city) {
      storeDistrict = storeLocation.city;
    } else if ('address' in storeLocation && storeLocation.address) {
      storeDistrict = getStoreLocationDistrict(storeLocation as Partial<Store>);
    }
  }

  // Resolve Customer Location District / City
  const customerDistrict = getCustomerLocationDistrict(customerLocation);

  const normStore = normalizeLocationName(storeDistrict);
  const normCustomer = normalizeLocationName(customerDistrict);

  // If customer hasn't selected a location yet, default to false (outside/prompt)
  const isMatch = Boolean(normStore && normCustomer && (normStore === normCustomer || normCustomer.includes(normStore) || normStore.includes(normCustomer)));

  const localRate = settings?.localDeliveryCharge 
    ?? (typeof storeLocation === 'object' && storeLocation && 'deliverySettings' in storeLocation ? (storeLocation as any).deliverySettings?.localDeliveryCharge : undefined)
    ?? settings?.insideCityCharge 
    ?? 60;
  const outsideRate = settings?.outsideDeliveryCharge 
    ?? (typeof storeLocation === 'object' && storeLocation && 'deliverySettings' in storeLocation ? (storeLocation as any).deliverySettings?.outsideDeliveryCharge : undefined)
    ?? settings?.outsideCityCharge 
    ?? 120;
  const freeThreshold = settings?.freeShippingThreshold ?? 2500;

  const baseCharge = isMatch ? localRate : outsideRate;
  const isFreeShipping = freeThreshold > 0 && orderSubtotal >= freeThreshold;
  const finalCharge = isFreeShipping ? 0 : baseCharge;

  return {
    isLocal: isMatch,
    deliveryZone: isMatch ? 'local' : 'outside',
    charge: finalCharge,
    baseCharge,
    isFreeShipping,
    storeLocationSummary: storeDistrict || 'Store Location',
    customerLocationSummary: customerDistrict || 'Customer Location',
    zoneDescription: isMatch 
      ? `Local Delivery Rate (${storeDistrict})`
      : `Outside Store Location (Outside ${storeDistrict})`,
    zoneDescriptionBn: isMatch
      ? `স্থানীয় ডেলিভারি (${storeDistrict})`
      : `স্টোরের বাইরের এলাকা (${storeDistrict}-এর বাইরে)`
  };
}
