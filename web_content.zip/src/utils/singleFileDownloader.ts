import { AppState } from '../types';

export function downloadStandaloneTajrobiHTML(state: AppState) {
  const jsonState = JSON.stringify(state).replace(/</g, '\\u003c');

  const htmlContent = `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>همیار مطالعه تجربی — نسخه تک‌فایلی آفلاین</title>
  <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" type="text/css" />
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Vazirmatn', system-ui, sans-serif; }
    body { background: #f8fafc; color: #0f172a; padding-bottom: 60px; line-height: 1.6; }
    .container { max-width: 1100px; margin: 0 auto; padding: 16px; }
    header { background: #fff; border-bottom: 1px solid #e2e8f0; padding: 14px 16px; margin-bottom: 20px; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 10px; }
    .brand { font-size: 1.2rem; font-weight: 800; color: #0f766e; }
    .tabs { display: flex; gap: 8px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 4px; }
    .tab-btn { padding: 10px 16px; border-radius: 12px; border: 1px solid #cbd5e1; background: #fff; cursor: pointer; font-weight: 700; font-size: 0.85rem; white-space: nowrap; }
    .tab-btn.active { background: #0f766e; color: #fff; border-color: #0f766e; }
    .card { background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; padding: 20px; margin-bottom: 16px; }
    .btn { padding: 10px 16px; border-radius: 12px; border: none; font-weight: 700; cursor: pointer; font-size: 0.85rem; }
    .btn-teal { background: #0f766e; color: #fff; }
    .btn-amber { background: #f59e0b; color: #fff; }
    .btn-rose { background: #ef4444; color: #fff; }
    .tabular { font-variant-numeric: tabular-nums; }
    .timer-val { font-size: 3.5rem; font-weight: 900; color: #0f766e; text-align: center; margin: 15px 0; }
    .block-row { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; padding: 12px; border: 1px solid #e2e8f0; border-radius: 12px; margin-bottom: 8px; }
    .block-wasted { border-color: #fca5a5; background: #fff1f2; }
    .block-study { border-color: #a7f3d0; background: #f0fdf4; }
  </style>
</head>
<body>
  <header>
    <div class="brand">🧬 همیار مطالعه تجربی (نسخه تک‌فایلی)</div>
    <div style="font-size: 0.85rem; color: #64748b;">تایمر معکوس + کارنامه مباحث و کتاب‌ها + روزشمار کنکور</div>
  </header>

  <div class="container">
    <div class="tabs">
      <button class="tab-btn active" onclick="switchView('timer', this)">⏱ تایمر معکوس</button>
      <button class="tab-btn" onclick="switchView('blocks', this)">🗓 جدول ۱۶ بلوک روزانه</button>
      <button class="tab-btn" onclick="switchView('comp', this)">⚡ ایستگاه جبرانی‌ها</button>
      <button class="tab-btn" onclick="switchView('history', this)">📚 کارنامه مباحث و کتاب‌ها</button>
      <button class="tab-btn" onclick="switchView('exams', this)">⏳ روزشمار معکوس کنکور</button>
      <button class="tab-btn" onclick="switchView('chart', this)">📊 تحلیل تایم پرتی</button>
    </div>

    <!-- Timer View -->
    <div id="view-timer">
      <div class="card" style="text-align: center;">
        <h3 id="timer-subj-topic">زیست‌شناسی تجربی (کتاب خیلی سبز جامع)</h3>
        <div class="timer-val tabular" id="timer-digits">۹۰:۰۰</div>
        <div style="display: flex; justify-content: center; gap: 8px; flex-wrap: wrap;">
          <button class="btn btn-teal" onclick="startTimer()">▶️ شروع مطالعه معکوس</button>
          <button class="btn btn-amber" onclick="pauseTimer()">⏸ توقف موقت</button>
          <button class="btn btn-rose" onclick="incompleteToComp()">⚠️ نصفه موند (ارسال به جبرانی)</button>
        </div>
      </div>
    </div>

    <!-- Blocks View -->
    <div id="view-blocks" style="display: none;">
      <div class="card">
        <h3>جدول ۱۶ بلوک ۱.۵ ساعته روزانه</h3>
        <p style="font-size:0.8rem;color:#64748b;margin-bottom:12px;">۲۴ ساعت شبانه‌روز تقسیم بر ۱.۵ ساعت</p>
        <div id="blocks-container"></div>
      </div>
    </div>

    <!-- Compensation View -->
    <div id="view-comp" style="display: none;">
      <div class="card">
        <h3>ایستگاه جبرانی‌ها (پارت‌های نصفه‌مانده)</h3>
        <div id="comp-container" style="margin-top: 12px;"></div>
      </div>
    </div>

    <!-- History View -->
    <div id="view-history" style="display: none;">
      <div class="card">
        <h3>کارنامه و تاریخچه مباحث، کتاب‌ها و درصد تست</h3>
        <div id="history-container" style="margin-top: 12px;"></div>
      </div>
    </div>

    <!-- Exams View -->
    <div id="view-exams" style="display: none;">
      <div class="card">
        <h3>روزشمار معکوس کنکور و امتحانات</h3>
        <div id="exams-container" style="margin-top: 12px;"></div>
      </div>
    </div>

    <!-- Chart View -->
    <div id="view-chart" style="display: none;">
      <div class="card">
        <h3>تحلیل تایم پرتی و مطالعه</h3>
        <div id="chart-summary" style="margin-top: 12px; font-size: 0.9rem;"></div>
      </div>
    </div>
  </div>

  <script>
    let state = ${jsonState};
    let secondsLeft = 90 * 60;
    let timerRunning = false;
    let interval = null;

    function toFa(num) {
      return String(num).replace(/\\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
    }

    function switchView(tab, btn) {
      ['timer', 'blocks', 'comp', 'history', 'exams', 'chart'].forEach(t => {
        const el = document.getElementById('view-' + t);
        if (el) el.style.display = 'none';
      });
      const target = document.getElementById('view-' + tab);
      if (target) target.style.display = 'block';
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      if (btn) btn.classList.add('active');
      render();
    }

    function startTimer() {
      if (timerRunning) return;
      timerRunning = true;
      interval = setInterval(() => {
        if (secondsLeft <= 0) {
          clearInterval(interval);
          timerRunning = false;
          alert('آفرین! تایم مطالعه معکوس کامل شد.');
          return;
        }
        secondsLeft--;
        updateTimerDisplay();
      }, 1000);
    }

    function pauseTimer() {
      clearInterval(interval);
      timerRunning = false;
    }

    function updateTimerDisplay() {
      let m = Math.floor(secondsLeft / 60);
      let s = secondsLeft % 60;
      document.getElementById('timer-digits').textContent =
        toFa(String(m).padStart(2, '0')) + ':' + toFa(String(s).padStart(2, '0'));
    }

    function incompleteToComp() {
      pauseTimer();
      let remaining = Math.max(5, Math.floor(secondsLeft / 60));
      state.compensations.unshift({
        id: 'comp-' + Date.now(),
        subject: 'زیست‌شناسی',
        topic: 'پارت نصفه‌مانده معکوس',
        bookSource: 'خیلی سبز جامع',
        plannedMinutes: 90,
        completedMinutes: 90 - remaining,
        remainingMinutes: remaining,
        resolved: false,
        date: 'امروز'
      });
      secondsLeft = 90 * 60;
      updateTimerDisplay();
      alert('کسری ' + toFa(remaining) + ' دقیقه با موفقیت به ایستگاه جبرانی‌ها منتقل شد!');
      render();
    }

    function render() {
      // Render blocks
      let bHtml = '';
      let wastedCount = 0;
      let studyCount = 0;
      state.blocks.forEach(b => {
        if (b.activityType === 'wasted') wastedCount++;
        if (b.activityType === 'study') studyCount++;
        let cls = b.activityType === 'wasted' ? 'block-wasted' : b.activityType === 'study' ? 'block-study' : '';
        bHtml += '<div class="block-row ' + cls + '"><div><strong>' + toFa(b.timeRange) + '</strong> (' + (b.subject || b.activityType) + ')</div><div>' + (b.topic || '') + '</div></div>';
      });
      document.getElementById('blocks-container').innerHTML = bHtml;

      // Render compensations
      let cHtml = '';
      state.compensations.filter(c => !c.resolved).forEach(c => {
        cHtml += '<div class="block-row" style="border-color:#f59e0b;background:#fffbeb;"><div><strong>' + c.subject + '</strong>: ' + c.topic + ' (' + (c.bookSource || '') + ')</div><div style="font-weight:bold;color:#b45309;">کسری: ' + toFa(c.remainingMinutes) + ' دقیقه باقی‌مانده</div></div>';
      });
      document.getElementById('comp-container').innerHTML = cHtml || '<p>هیچ پارت جبرانی فعالی وجود ندارد.</p>';

      // Render history
      let hHtml = '';
      (state.studyLogs || []).forEach(l => {
        hHtml += '<div class="block-row"><div><strong>' + l.subject + ' (' + (l.monthLabel || 'ماه') + ')</strong>: ' + l.topic + ' <span style="color:#0f766e;">[کتاب: ' + l.bookSource + ']</span></div><div>' + toFa(l.totalTests) + ' تست (' + toFa(l.correctTests) + ' درست) - <strong>' + toFa(l.accuracyPercentage) + '٪</strong></div></div>';
      });
      document.getElementById('history-container').innerHTML = hHtml || '<p>هنوز گزارشی ثبت نشده است.</p>';

      // Render exams
      let eHtml = '';
      (state.exams || []).forEach(e => {
        let diff = Math.max(0, Math.ceil((new Date(e.targetDate) - new Date()) / (1000 * 60 * 60 * 24)));
        eHtml += '<div class="block-row"><div><strong>' + e.title + '</strong> (' + e.targetJalali + ')</div><div style="font-weight:bold;color:#0f766e;font-size:1.1rem;">⏳ ' + toFa(diff) + ' روز مانده</div></div>';
      });
      document.getElementById('exams-container').innerHTML = eHtml;

      // Render chart summary
      document.getElementById('chart-summary').innerHTML =
        '<p>🔥 مطالعه تجربی: <strong>' + toFa(studyCount * 1.5) + ' ساعت</strong></p>' +
        '<p style="color:#e11d48;margin-top:6px;">⚠️ تایم پرتی و هدررفت: <strong>' + toFa(wastedCount * 1.5) + ' ساعت</strong></p>';
    }

    render();
    updateTimerDisplay();
  </script>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'tajrobi-study-planner.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
