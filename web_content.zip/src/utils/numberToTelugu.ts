/**
 * Utility to convert numbers and numerical patterns into natural Telugu words
 */

const ONES: { [key: number]: string } = {
  0: 'సున్నా',
  1: 'ఒకటి',
  2: 'రెండు',
  3: 'మూడు',
  4: 'నాలుగు',
  5: 'ఐదు',
  6: 'ఆరు',
  7: 'ఏడు',
  8: 'ఎనిమిది',
  9: 'తొమ్మిది',
  10: 'పది',
  11: 'పదకొండు',
  12: 'పన్నెండు',
  13: 'పదమూడు',
  14: 'పద్నాలుగు',
  15: 'పదిహేను',
  16: 'పదహారు',
  17: 'పదిహేడు',
  18: 'పద్దెనిమిది',
  19: 'పందొమ్మిది',
};

const TENS: { [key: number]: string } = {
  20: 'ఇరవై',
  30: 'ముప్పై',
  40: 'నలభై',
  50: 'యాభై',
  60: 'అరవై',
  70: 'డెబ్బై',
  80: 'ఎనభై',
  90: 'తొంభై',
};

export function convertNumberToTelugu(num: number): string {
  if (num < 0) return `మైనస్ ${convertNumberToTelugu(Math.abs(num))}`;
  if (num in ONES) return ONES[num];

  if (num < 100) {
    const ten = Math.floor(num / 10) * 10;
    const remainder = num % 10;
    if (remainder === 0) return TENS[ten] || '';
    return `${TENS[ten]} ${ONES[remainder]}`;
  }

  if (num < 1000) {
    const hundreds = Math.floor(num / 100);
    const remainder = num % 100;
    const hPrefix = hundreds === 1 ? 'వంద' : `${ONES[hundreds]} వందల`;
    if (remainder === 0) return hPrefix;
    return `${hPrefix} ${convertNumberToTelugu(remainder)}`;
  }

  if (num < 100000) {
    const thousands = Math.floor(num / 1000);
    const remainder = num % 1000;
    const tPrefix = thousands === 1 ? 'వెయ్యి' : `${convertNumberToTelugu(thousands)} వేల`;
    if (remainder === 0) return tPrefix;
    return `${tPrefix} ${convertNumberToTelugu(remainder)}`;
  }

  if (num < 10000000) {
    const lakhs = Math.floor(num / 100000);
    const remainder = num % 100000;
    const lPrefix = lakhs === 1 ? 'ఒక లక్ష' : `${convertNumberToTelugu(lakhs)} లక్షల`;
    if (remainder === 0) return lPrefix;
    return `${lPrefix} ${convertNumberToTelugu(remainder)}`;
  }

  const crores = Math.floor(num / 10000000);
  const remainder = num % 10000000;
  const cPrefix = crores === 1 ? 'ఒక కోటి' : `${convertNumberToTelugu(crores)} కోట్ల`;
  if (remainder === 0) return cPrefix;
  return `${cPrefix} ${convertNumberToTelugu(remainder)}`;
}

export function replaceNumbersInTeluguText(text: string): string {
  // Matches currency like ₹500 or రూ. 500 or Rs. 500
  let processed = text.replace(/(?:₹|రూ\.?|Rs\.?)\s*(\d+)/gi, (_, numStr) => {
    const num = parseInt(numStr, 10);
    if (!isNaN(num)) {
      return `${convertNumberToTelugu(num)} రూపాయలు`;
    }
    return _;
  });

  // Matches percentage like 50%
  processed = processed.replace(/(\d+)\s*%/g, (_, numStr) => {
    const num = parseInt(numStr, 10);
    if (!isNaN(num)) {
      return `${convertNumberToTelugu(num)} శాతం`;
    }
    return _;
  });

  // Matches standalone integers
  processed = processed.replace(/\b\d+\b/g, (match) => {
    const num = parseInt(match, 10);
    if (!isNaN(num) && num >= 0 && num <= 999999999) {
      return convertNumberToTelugu(num);
    }
    return match;
  });

  return processed;
}
