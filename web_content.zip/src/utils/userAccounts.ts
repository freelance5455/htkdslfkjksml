import { UserProfile } from '../types';
import { saveUserProfileToFirestore } from './firebaseSync';

export interface StoredAccount extends UserProfile {
  passwordHash?: string;
  email?: string;
}

const STORAGE_KEY = 'tabeona_registered_accounts';
const CURRENT_USER_KEY = 'tabeona_active_user_id';

export const DEMO_ACCOUNTS: StoredAccount[] = [
  {
    id: '78453',
    name: 'Player 1 (المالك 👑)',
    email: 'alali8f790@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop',
    title: 'الماستر الملكي 👑',
    level: 14,
    xp: 4250,
    nextLevelXp: 5000,
    coins: 5400,
    gems: 125,
    realCashBalance: 1250,
    kycVerified: true,
    vipLevel: 3,
    isVip: true,
    accountGroup: {
      groupId: 'grp-78453',
      accountsCount: 1,
      maxAllowed: 4,
      accountIndex: 1,
    },
    role: 'OWNER', // Grants Owner rights -> Admin Panel button VISIBLE
  },
  {
    id: '62194',
    name: 'سامي (كاشير دبي 💼)',
    email: 'cashier@tabeona.vip',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
    title: 'كاشير معتمد 💼',
    level: 19,
    xp: 8500,
    nextLevelXp: 10000,
    coins: 25000,
    gems: 500,
    realCashBalance: 3500,
    kycVerified: true,
    vipLevel: 2,
    isVip: true,
    accountGroup: {
      groupId: 'grp-62194',
      accountsCount: 1,
      maxAllowed: 4,
      accountIndex: 1,
    },
    role: 'CASHIER', // Cashier privileges -> Cashier Desk VISIBLE, Admin Panel HIDDEN
  },
  {
    id: '33910',
    name: 'فارس الليل (لاعب)',
    email: 'player@tabeona.vip',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop',
    title: 'فارس طرنيب 🃏',
    level: 8,
    xp: 1800,
    nextLevelXp: 2500,
    coins: 3000,
    gems: 30,
    realCashBalance: 0,
    kycVerified: false,
    vipLevel: 0,
    isVip: false,
    accountGroup: {
      groupId: 'grp-33910',
      accountsCount: 1,
      maxAllowed: 4,
      accountIndex: 1,
    },
    role: 'PLAYER', // Regular Player -> Admin Panel HIDDEN, "تفعيل كاشير" VISIBLE
  },
];

export function getRegisteredAccounts(): StoredAccount[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEMO_ACCOUNTS));
      return DEMO_ACCOUNTS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEMO_ACCOUNTS;
  } catch {
    return DEMO_ACCOUNTS;
  }
}

export function saveRegisteredAccounts(accounts: StoredAccount[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(accounts));
  } catch (err) {
    console.error('Error saving accounts:', err);
  }
}

export function registerNewAccount(
  name: string,
  emailOrPhone: string,
  _password: string,
  avatar?: string
): StoredAccount {
  const accounts = getRegisteredAccounts();
  const newId = Math.floor(10000 + Math.random() * 90000).toString();

  const newAcc: StoredAccount = {
    id: newId,
    name: name.trim(),
    email: emailOrPhone.trim(),
    avatar:
      avatar ||
      `https://images.unsplash.com/photo-${1534528741775 + Math.floor(Math.random() * 1000)}?w=150&h=150&fit=crop`,
    title: 'لاعب جديد 🌟',
    level: 1,
    xp: 0,
    nextLevelXp: 500,
    coins: 5000, // 5,000 Coins Welcome Bonus
    gems: 50, // 50 Gems Welcome Bonus
    realCashBalance: 0,
    kycVerified: false,
    vipLevel: 0,
    isVip: false,
    accountGroup: {
      groupId: `grp-${newId}`,
      accountsCount: 1,
      maxAllowed: 4,
      accountIndex: 1,
    },
    role: 'PLAYER', // Default regular player role
  };

  const updated = [newAcc, ...accounts];
  saveRegisteredAccounts(updated);
  saveUserProfileToFirestore(newAcc);
  return newAcc;
}

export function getActiveUserId(): string {
  try {
    return localStorage.getItem(CURRENT_USER_KEY) || '78453';
  } catch {
    return '78453';
  }
}

export function setActiveUserId(id: string): void {
  try {
    localStorage.setItem(CURRENT_USER_KEY, id);
  } catch (err) {
    console.error('Error setting active user id:', err);
  }
}
