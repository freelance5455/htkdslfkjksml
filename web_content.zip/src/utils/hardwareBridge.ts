/**
 * Hardware bridge for Android devices
 * Handles Flashlight (Torch), Haptic Vibration, Battery, Geolocation,
 * Audio Synthesizer sound effects, and Web Notifications.
 */

class HardwareBridgeService {
  private torchStream: MediaStream | null = null;
  private torchTrack: MediaStreamTrack | null = null;
  private audioCtx: AudioContext | null = null;

  // Initialize Web Audio Context lazily on user gesture
  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.audioCtx = new AudioCtx();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Real Android Flashlight / Torch via Camera API
   */
  async setFlashlight(enabled: boolean): Promise<boolean> {
    try {
      if (enabled) {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          return false;
        }
        if (!this.torchStream) {
          this.torchStream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: 'environment',
            },
          });
          this.torchTrack = this.torchStream.getVideoTracks()[0];
        }

        if (this.torchTrack) {
          const capabilities = (this.torchTrack.getCapabilities && this.torchTrack.getCapabilities()) || {};
          if ('torch' in capabilities) {
            await (this.torchTrack as any).applyConstraints({
              advanced: [{ torch: true }],
            });
            return true;
          }
        }
      } else {
        if (this.torchTrack) {
          try {
            await (this.torchTrack as any).applyConstraints({
              advanced: [{ torch: false }],
            });
          } catch {
            // ignore
          }
          this.torchTrack.stop();
          this.torchTrack = null;
        }
        if (this.torchStream) {
          this.torchStream.getTracks().forEach((t) => t.stop());
          this.torchStream = null;
        }
        return false;
      }
    } catch (err) {
      console.warn('Torch control unavailable or permission denied:', err);
      return enabled; // Return simulated state
    }
    return enabled;
  }

  /**
   * Real Android Haptic Vibration
   */
  vibrate(pattern: number | number[] = 50): void {
    try {
      if (typeof window !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(pattern);
      }
    } catch {
      // ignore
    }
  }

  vibrateSuccess(): void {
    this.vibrate([40, 30, 40]);
  }

  vibrateAlert(): void {
    this.vibrate([80, 50, 120]);
  }

  vibrateNotification(): void {
    this.vibrate([100, 80, 100, 80, 150]);
  }

  /**
   * Sound FX Synthesizer using Web Audio API
   */
  playJarvisTone(type: 'wake' | 'ack' | 'alert' | 'complete' | 'call'): void {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'wake') {
        // High-tech rising dual beep
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      } else if (type === 'ack') {
        // Crisp acknowledgment ping
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(880, now + 0.08); // A5
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'alert') {
        // Warning chime for upcoming schedule
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(659.25, now); // E5
        osc.frequency.exponentialRampToValueAtTime(523.25, now + 0.18); // C5
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'complete') {
        // Harmonic major triad
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.08); // E5
        osc.frequency.setValueAtTime(783.99, now + 0.16); // G5
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'call') {
        // Phone ringback tone
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.setValueAtTime(0.1, now + 0.4);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
      }
    } catch {
      // Audio context might be restricted
    }
  }

  /**
   * Request Notification Permission & Send Notification
   */
  async requestNotificationPermission(): Promise<boolean> {
    if (typeof window === 'undefined' || !('Notification' in window)) return false;
    if (Notification.permission === 'granted') return true;
    try {
      const perm = await Notification.requestPermission();
      return perm === 'granted';
    } catch {
      return false;
    }
  }

  sendDeviceNotification(title: string, body: string): void {
    this.vibrateNotification();
    this.playJarvisTone('alert');

    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`JARVIS: ${title}`, {
          body,
          icon: '/icon.svg',
          badge: '/icon.svg',
          silent: false,
        });
      } catch {
        // In case serviceWorker registration is needed on mobile
      }
    }
  }

  /**
   * Read Battery status
   */
  async getBatteryStatus(): Promise<{ level: number; charging: boolean } | null> {
    try {
      if (typeof window !== 'undefined' && 'getBattery' in navigator) {
        const battery: any = await (navigator as any).getBattery();
        return {
          level: Math.round(battery.level * 100),
          charging: battery.charging,
        };
      }
    } catch {
      // Battery API not supported
    }
    return null;
  }

  /**
   * Read GPS Geolocation
   */
  async getCoordinates(): Promise<{ latitude: number; longitude: number } | null> {
    if (typeof window === 'undefined' || !('geolocation' in navigator)) return null;
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          resolve({
            latitude: parseFloat(pos.coords.latitude.toFixed(4)),
            longitude: parseFloat(pos.coords.longitude.toFixed(4)),
          });
        },
        () => resolve(null),
        { timeout: 5000 }
      );
    });
  }

  /**
   * Open Android App or Intent
   */
  launchAndroidApp(intentUrl: string, webFallback: string): void {
    if (typeof window === 'undefined') return;
    this.vibrateSuccess();
    this.playJarvisTone('ack');

    // Attempt to open deep link
    try {
      window.location.href = intentUrl;
    } catch {
      // Fallback
      if (webFallback && !webFallback.startsWith('#')) {
        window.open(webFallback, '_blank');
      }
    }
  }
}

export const hardwareBridge = new HardwareBridgeService();
