import { Ledger, StockItem, Voucher } from '../types/tally';

export interface LedgerBalanceSummary {
  ledger: Ledger;
  debitTotal: number;
  creditTotal: number;
  closingBalance: number;
  closingType: 'Dr' | 'Cr';
}

export function formatINR(amount: number, showDecimals = true): string {
  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);
  
  const parts = absAmount.toFixed(showDecimals ? 2 : 0).split('.');
  let integerPart = parts[0];
  const decimalPart = parts[1];

  // Indian currency formatting: last 3 digits, then pairs of 2 digits
  let lastThree = integerPart.substring(integerPart.length - 3);
  const otherNumbers = integerPart.substring(0, integerPart.length - 3);
  if (otherNumbers !== '') {
    lastThree = ',' + lastThree;
  }
  const formattedInteger = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;

  const result = showDecimals ? `${formattedInteger}.${decimalPart}` : formattedInteger;
  return isNegative ? `-${result}` : result;
}

export function formatCurrency(amount: number, symbol = '₹'): string {
  return `${symbol} ${formatINR(amount)}`;
}

export function formatDateDisplay(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  if (!year || !month || !day) return dateStr;
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthName = months[parseInt(month, 10) - 1] || month;
  return `${day}-${monthName}-${year}`;
}

/**
 * Recalculates current balances for all ledgers based on opening balances + vouchers
 */
export function calculateLedgerBalances(ledgers: Ledger[], vouchers: Voucher[]): Ledger[] {
  const debitMap: Record<string, number> = {};
  const creditMap: Record<string, number> = {};

  // Initialize
  for (const led of ledgers) {
    debitMap[led.id] = led.openingBalanceType === 'Dr' ? led.openingBalance : 0;
    creditMap[led.id] = led.openingBalanceType === 'Cr' ? led.openingBalance : 0;
  }

  // Helper to add
  const addDebit = (id?: string, amt = 0) => {
    if (!id || !amt) return;
    debitMap[id] = (debitMap[id] || 0) + amt;
  };
  const addCredit = (id?: string, amt = 0) => {
    if (!id || !amt) return;
    creditMap[id] = (creditMap[id] || 0) + amt;
  };

  for (const vch of vouchers) {
    if (vch.voucherType === 'sales') {
      // Debtor Dr (Total Amount)
      addDebit(vch.partyLedgerId, vch.totalAmount);
      // Sales Cr (Taxable)
      addCredit(vch.salesPurchaseLedgerId, vch.taxableAmount);
      // Taxes Cr
      if (vch.cgstAmount > 0) addCredit('led_tax_cgst_out', vch.cgstAmount);
      if (vch.sgstAmount > 0) addCredit('led_tax_sgst_out', vch.sgstAmount);
      if (vch.igstAmount > 0) addCredit('led_tax_igst_out', vch.igstAmount);
      if (vch.roundOff !== 0) {
        if (vch.roundOff > 0) addCredit('led_round_off', vch.roundOff);
        else addDebit('led_round_off', Math.abs(vch.roundOff));
      }
    } else if (vch.voucherType === 'purchase') {
      // Creditor Cr (Total Amount)
      addCredit(vch.partyLedgerId, vch.totalAmount);
      // Purchase Dr (Taxable)
      addDebit(vch.salesPurchaseLedgerId, vch.taxableAmount);
      // Taxes Dr
      if (vch.cgstAmount > 0) addDebit('led_tax_cgst_in', vch.cgstAmount);
      if (vch.sgstAmount > 0) addDebit('led_tax_sgst_in', vch.sgstAmount);
      if (vch.igstAmount > 0) addDebit('led_tax_igst_in', vch.igstAmount);
      if (vch.roundOff !== 0) {
        if (vch.roundOff > 0) addDebit('led_round_off', vch.roundOff);
        else addCredit('led_round_off', Math.abs(vch.roundOff));
      }
    } else if (vch.rows && vch.rows.length > 0) {
      // Standard Dr/Cr vouchers (Payment, Receipt, Contra, Journal)
      for (const row of vch.rows) {
        if (row.type === 'Dr') {
          addDebit(row.ledgerId, row.amount);
        } else {
          addCredit(row.ledgerId, row.amount);
        }
      }
    }
  }

  return ledgers.map((led) => {
    const totalDr = debitMap[led.id] || 0;
    const totalCr = creditMap[led.id] || 0;

    let balance = 0;
    let balanceType: 'Dr' | 'Cr' = 'Dr';

    if (totalDr >= totalCr) {
      balance = totalDr - totalCr;
      balanceType = 'Dr';
    } else {
      balance = totalCr - totalDr;
      balanceType = 'Cr';
    }

    return {
      ...led,
      currentBalance: balance,
      currentBalanceType: balanceType,
    };
  });
}

/**
 * Calculates updated stock item quantities based on inward and outward movements
 */
export function calculateStockQuantities(stockItems: StockItem[], vouchers: Voucher[]): StockItem[] {
  const inwardMap: Record<string, number> = {};
  const outwardMap: Record<string, number> = {};

  for (const vch of vouchers) {
    if (vch.items && vch.items.length > 0) {
      for (const item of vch.items) {
        if (vch.voucherType === 'purchase') {
          inwardMap[item.itemId] = (inwardMap[item.itemId] || 0) + item.qty;
        } else if (vch.voucherType === 'sales') {
          outwardMap[item.itemId] = (outwardMap[item.itemId] || 0) + item.qty;
        }
      }
    }
  }

  return stockItems.map((item) => {
    const inward = inwardMap[item.id] || 0;
    const outward = outwardMap[item.id] || 0;
    const currentQty = Math.max(0, item.openingQty + inward - outward);
    return {
      ...item,
      currentQty,
    };
  });
}

export function computeClosingStockValue(stockItems: StockItem[]): number {
  return stockItems.reduce((acc, item) => acc + item.currentQty * item.openingRate, 0);
}

export function computeOpeningStockValue(stockItems: StockItem[]): number {
  return stockItems.reduce((acc, item) => acc + item.openingQty * item.openingRate, 0);
}

export interface PnLReportData {
  openingStock: number;
  purchases: number;
  directExpenses: number;
  sales: number;
  closingStock: number;
  grossProfit: number;
  grossLoss: number;
  indirectIncomes: number;
  indirectExpensesList: { name: string; amount: number }[];
  indirectExpensesTotal: number;
  netProfit: number;
  netLoss: number;
}

export function computeProfitAndLoss(ledgers: Ledger[], stockItems: StockItem[]): PnLReportData {
  const openingStock = computeOpeningStockValue(stockItems);
  const closingStock = computeClosingStockValue(stockItems);

  // Sales
  const sales = ledgers
    .filter((l) => l.group === 'Sales Accounts')
    .reduce((sum, l) => sum + (l.currentBalanceType === 'Cr' ? l.currentBalance : -l.currentBalance), 0);

  // Purchases
  const purchases = ledgers
    .filter((l) => l.group === 'Purchase Accounts')
    .reduce((sum, l) => sum + (l.currentBalanceType === 'Dr' ? l.currentBalance : -l.currentBalance), 0);

  // Direct expenses
  const directExpenses = ledgers
    .filter((l) => l.group === 'Direct Expenses')
    .reduce((sum, l) => sum + (l.currentBalanceType === 'Dr' ? l.currentBalance : -l.currentBalance), 0);

  // Direct incomes
  const directIncomes = ledgers
    .filter((l) => l.group === 'Direct Incomes')
    .reduce((sum, l) => sum + (l.currentBalanceType === 'Cr' ? l.currentBalance : -l.currentBalance), 0);

  // Trading Calculation
  const tradingCredit = sales + closingStock + directIncomes;
  const tradingDebit = openingStock + purchases + directExpenses;
  const grossDiff = tradingCredit - tradingDebit;
  const grossProfit = grossDiff > 0 ? grossDiff : 0;
  const grossLoss = grossDiff < 0 ? Math.abs(grossDiff) : 0;

  // Indirect Expenses
  const indirectExpensesLedgers = ledgers.filter(
    (l) => l.group === 'Indirect Expenses' && l.currentBalance > 0
  );
  const indirectExpensesList = indirectExpensesLedgers.map((l) => ({
    name: l.name,
    amount: l.currentBalance,
  }));
  const indirectExpensesTotal = indirectExpensesList.reduce((acc, curr) => acc + curr.amount, 0);

  // Indirect Incomes
  const indirectIncomes = ledgers
    .filter((l) => l.group === 'Indirect Incomes')
    .reduce((sum, l) => sum + (l.currentBalanceType === 'Cr' ? l.currentBalance : -l.currentBalance), 0);

  // Net Profit
  const netCredit = grossProfit + indirectIncomes;
  const netDebit = grossLoss + indirectExpensesTotal;
  const netDiff = netCredit - netDebit;

  const netProfit = netDiff > 0 ? netDiff : 0;
  const netLoss = netDiff < 0 ? Math.abs(netDiff) : 0;

  return {
    openingStock,
    purchases,
    directExpenses,
    sales,
    closingStock,
    grossProfit,
    grossLoss,
    indirectIncomes,
    indirectExpensesList,
    indirectExpensesTotal,
    netProfit,
    netLoss,
  };
}

export interface BalanceSheetData {
  capital: {
    baseAmount: number;
    netProfitAddition: number;
    drawings: number;
    totalCapital: number;
  };
  loansLiability: number;
  currentLiabilities: {
    sundryCreditors: number;
    dutiesAndTaxes: number;
    provisions: number;
    total: number;
    creditorsList: { name: string; amount: number }[];
  };
  totalLiabilities: number;

  fixedAssets: {
    total: number;
    list: { name: string; amount: number }[];
  };
  currentAssets: {
    closingStock: number;
    sundryDebtors: number;
    bankAccounts: number;
    cashInHand: number;
    total: number;
    debtorsList: { name: string; amount: number }[];
    banksList: { name: string; amount: number }[];
  };
  totalAssets: number;
  workingCapital: number;
  isBalanced: boolean;
  difference: number;
}

export function computeBalanceSheet(
  ledgers: Ledger[],
  stockItems: StockItem[]
): BalanceSheetData {
  const pnl = computeProfitAndLoss(ledgers, stockItems);
  const closingStock = pnl.closingStock;

  // Capital Account
  const capLedgers = ledgers.filter((l) => l.group === 'Capital Account');
  const baseCapital = capLedgers.reduce(
    (sum, l) => sum + (l.currentBalanceType === 'Cr' ? l.currentBalance : -l.currentBalance),
    0
  );
  const netProfitAddition = pnl.netProfit - pnl.netLoss;
  const totalCapital = baseCapital + netProfitAddition;

  // Loans
  const loansLiability = ledgers
    .filter((l) => l.group === 'Loans (Liability)')
    .reduce((sum, l) => sum + l.currentBalance, 0);

  // Sundry Creditors
  const creditorsLedgers = ledgers.filter((l) => l.group === 'Sundry Creditors');
  const creditorsList = creditorsLedgers.map((l) => ({
    name: l.name,
    amount: l.currentBalance,
  }));
  const sundryCreditors = creditorsList.reduce((acc, curr) => acc + curr.amount, 0);

  // Duties & Taxes (GST)
  // Output taxes are Cr, Input taxes are Dr
  const outputTaxes = ledgers
    .filter((l) => l.group === 'Duties & Taxes' && l.name.includes('Output'))
    .reduce((acc, l) => acc + l.currentBalance, 0);
  const inputTaxes = ledgers
    .filter((l) => l.group === 'Duties & Taxes' && l.name.includes('Input'))
    .reduce((acc, l) => acc + l.currentBalance, 0);
  const netDutiesAndTaxes = Math.max(0, outputTaxes - inputTaxes);

  const currentLiabilitiesTotal = sundryCreditors + netDutiesAndTaxes;

  // Fixed Assets
  const fixedAssetsLedgers = ledgers.filter((l) => l.group === 'Fixed Assets');
  const fixedAssetsList = fixedAssetsLedgers.map((l) => ({
    name: l.name,
    amount: l.currentBalance,
  }));
  const fixedAssetsTotal = fixedAssetsList.reduce((acc, curr) => acc + curr.amount, 0);

  // Sundry Debtors
  const debtorsLedgers = ledgers.filter((l) => l.group === 'Sundry Debtors');
  const debtorsList = debtorsLedgers.map((l) => ({
    name: l.name,
    amount: l.currentBalance,
  }));
  const sundryDebtors = debtorsList.reduce((acc, curr) => acc + curr.amount, 0);

  // Bank Accounts
  const bankLedgers = ledgers.filter((l) => l.group === 'Bank Accounts');
  const banksList = bankLedgers.map((l) => ({
    name: l.name,
    amount: l.currentBalance,
  }));
  const bankAccounts = banksList.reduce((acc, curr) => acc + curr.amount, 0);

  // Cash in hand
  const cashLedgers = ledgers.filter((l) => l.group === 'Cash-in-hand');
  const cashInHand = cashLedgers.reduce((acc, l) => acc + l.currentBalance, 0);

  // If input tax credit exceeds output tax, remaining ITC is a Current Asset!
  const excessITC = inputTaxes > outputTaxes ? inputTaxes - outputTaxes : 0;

  const currentAssetsTotal = closingStock + sundryDebtors + bankAccounts + cashInHand + excessITC;

  const totalLiabilities = totalCapital + loansLiability + currentLiabilitiesTotal;
  const totalAssets = fixedAssetsTotal + currentAssetsTotal;

  const difference = Math.abs(totalLiabilities - totalAssets);
  const isBalanced = difference < 0.01;

  const workingCapital = currentAssetsTotal - currentLiabilitiesTotal;

  return {
    capital: {
      baseAmount: baseCapital,
      netProfitAddition,
      drawings: 0,
      totalCapital,
    },
    loansLiability,
    currentLiabilities: {
      sundryCreditors,
      dutiesAndTaxes: netDutiesAndTaxes,
      provisions: 0,
      total: currentLiabilitiesTotal,
      creditorsList,
    },
    totalLiabilities,

    fixedAssets: {
      total: fixedAssetsTotal,
      list: fixedAssetsList,
    },
    currentAssets: {
      closingStock,
      sundryDebtors,
      bankAccounts,
      cashInHand,
      total: currentAssetsTotal,
      debtorsList,
      banksList,
    },
    totalAssets,
    workingCapital,
    isBalanced,
    difference,
  };
}

export interface GSTReportSummary {
  outwardTaxable: number;
  outputCGST: number;
  outputSGST: number;
  outputIGST: number;
  totalOutputTax: number;
  inwardTaxable: number;
  inputCGST: number;
  inputSGST: number;
  inputIGST: number;
  totalInputTax: number;
  netTaxPayable: number;
  b2bCount: number;
}

export function computeGSTSummary(vouchers: Voucher[]): GSTReportSummary {
  let outwardTaxable = 0;
  let outputCGST = 0;
  let outputSGST = 0;
  let outputIGST = 0;
  let b2bCount = 0;

  let inwardTaxable = 0;
  let inputCGST = 0;
  let inputSGST = 0;
  let inputIGST = 0;

  for (const vch of vouchers) {
    if (vch.voucherType === 'sales') {
      outwardTaxable += vch.taxableAmount;
      outputCGST += vch.cgstAmount;
      outputSGST += vch.sgstAmount;
      outputIGST += vch.igstAmount;
      b2bCount++;
    } else if (vch.voucherType === 'purchase') {
      inwardTaxable += vch.taxableAmount;
      inputCGST += vch.cgstAmount;
      inputSGST += vch.sgstAmount;
      inputIGST += vch.igstAmount;
    }
  }

  const totalOutputTax = outputCGST + outputSGST + outputIGST;
  const totalInputTax = inputCGST + inputSGST + inputIGST;
  const netTaxPayable = Math.max(0, totalOutputTax - totalInputTax);

  return {
    outwardTaxable,
    outputCGST,
    outputSGST,
    outputIGST,
    totalOutputTax,
    inwardTaxable,
    inputCGST,
    inputSGST,
    inputIGST,
    totalInputTax,
    netTaxPayable,
    b2bCount,
  };
}

/**
 * Converts Indian currency numbers to words for Tax Invoices
 */
export function numberToWordsINR(num: number): string {
  const rounded = Math.round(num);
  if (rounded === 0) return 'Zero Rupees Only';

  const units = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'
  ];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertTwoDigits(n: number): string {
    if (n < 20) return units[n];
    return `${tens[Math.floor(n / 10)]} ${units[n % 10]}`.trim();
  }

  function convertThreeDigits(n: number): string {
    let str = '';
    if (Math.floor(n / 100) > 0) {
      str += `${units[Math.floor(n / 100)]} Hundred `;
      n %= 100;
    }
    if (n > 0) {
      str += convertTwoDigits(n);
    }
    return str.trim();
  }

  let crore = Math.floor(rounded / 10000000);
  let remainder = rounded % 10000000;
  let lakh = Math.floor(remainder / 100000);
  remainder %= 100000;
  let thousand = Math.floor(remainder / 1000);
  remainder %= 1000;

  let words = '';
  if (crore > 0) words += `${convertTwoDigits(crore)} Crore `;
  if (lakh > 0) words += `${convertTwoDigits(lakh)} Lakh `;
  if (thousand > 0) words += `${convertTwoDigits(thousand)} Thousand `;
  if (remainder > 0) words += `${convertThreeDigits(remainder)} `;

  return `Rupees ${words.trim()} Only`;
}
