export interface FlutterProjectFile {
  path: string;
  name: string;
  category: 'Root' | 'Models' | 'Services' | 'Screens' | 'Widgets' | 'Utils' | 'Android' | 'iOS' | 'Config';
  content: string;
}

export const FLUTTER_FILES: FlutterProjectFile[] = [
  {
    path: 'pubspec.yaml',
    name: 'pubspec.yaml',
    category: 'Root',
    content: `name: safeher_ai
description: "AI-Powered Women Safety and Emergency Response System"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.6
  firebase_core: ^2.32.0
  firebase_auth: ^4.19.7
  firebase_database: ^10.5.7
  geolocator: ^11.0.0
  url_launcher: ^6.3.0
  speech_to_text: ^6.6.1
  share_plus: ^9.0.0
  permission_handler: ^11.3.1
  intl: ^0.19.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true`,
  },
  {
    path: 'lib/main.dart',
    name: 'main.dart',
    category: 'Root',
    content: `import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'firebase_options.dart';
import 'screens/splash_screen.dart';
import 'utils/constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppConstants.surfaceDark,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint('Firebase initialization notice: $e');
  }

  runApp(const SafeHerAiApp());
}

class SafeHerAiApp extends StatelessWidget {
  const SafeHerAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppConstants.surfaceDark,
        colorScheme: const ColorScheme.dark(
          primary: AppConstants.primaryRed,
          secondary: Color(0xFFFB7185),
          surface: AppConstants.cardDark,
          error: AppConstants.accentAlert,
          onPrimary: Colors.white,
          onSurface: Colors.white,
        ),
        fontFamily: 'Roboto',
      ),
      home: const SplashScreen(),
    );
  }
}`,
  },
  {
    path: 'lib/firebase_options.dart',
    name: 'firebase_options.dart',
    category: 'Config',
    content: `import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError('DefaultFirebaseOptions are not supported for this platform.');
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDemoDummyKey-ReplaceWithYourOwn-FlutterFire',
    appId: '1:1234567890:web:abcdef123456',
    messagingSenderId: '1234567890',
    projectId: 'safeher-ai-demo',
    authDomain: 'safeher-ai-demo.firebaseapp.com',
    databaseURL: 'https://safeher-ai-demo-default-rtdb.firebaseio.com',
    storageBucket: 'safeher-ai-demo.appspot.com',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDemoDummyKey-ReplaceWithYourOwn-FlutterFire',
    appId: '1:1234567890:android:abcdef123456',
    messagingSenderId: '1234567890',
    projectId: 'safeher-ai-demo',
    databaseURL: 'https://safeher-ai-demo-default-rtdb.firebaseio.com',
    storageBucket: 'safeher-ai-demo.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDemoDummyKey-ReplaceWithYourOwn-FlutterFire',
    appId: '1:1234567890:ios:abcdef123456',
    messagingSenderId: '1234567890',
    projectId: 'safeher-ai-demo',
    databaseURL: 'https://safeher-ai-demo-default-rtdb.firebaseio.com',
    storageBucket: 'safeher-ai-demo.appspot.com',
    iosBundleId: 'com.example.safeherai',
  );
}`,
  },
  {
    path: 'firebase_database_rules.json',
    name: 'firebase_database_rules.json',
    category: 'Config',
    content: `{
  "rules": {
    "users": {
      "$uid": {
        ".read": "auth != null && auth.uid == $uid",
        ".write": "auth != null && auth.uid == $uid",
        "contacts": {
          "$contactId": {
            ".validate": "newData.hasChildren(['name', 'phone', 'relationship'])"
          }
        },
        "sosAlerts": {
          "$alertId": {
            ".validate": "newData.hasChildren(['latitude', 'longitude', 'locationUrl', 'time', 'source', 'status'])"
          }
        }
      }
    }
  }
}`,
  },
  {
    path: 'android/app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    category: 'Android',
    content: `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.safeherai">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.CALL_PHONE" />

    <queries>
        <intent>
            <action android:name="android.intent.action.DIAL" />
            <data android:scheme="tel" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
    </queries>

    <application
        android:label="SafeHer AI"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
</manifest>`,
  },
  {
    path: 'ios/Runner/Info.plist',
    name: 'Info.plist',
    category: 'iOS',
    content: `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDisplayName</key>
	<string>SafeHer AI</string>
	<key>CFBundleIdentifier</key>
	<string>com.example.safeherai</string>
	<key>NSLocationWhenInUseUsageDescription</key>
	<string>SafeHer AI requires location access to send your real-time coordinates to emergency services and trusted contacts during an SOS event.</string>
	<key>NSLocationAlwaysUsageDescription</key>
	<string>SafeHer AI requires background location access to monitor your safety during active emergency SOS alerts.</string>
	<key>NSMicrophoneUsageDescription</key>
	<string>SafeHer AI uses the microphone for hands-free speech recognition to detect emergency distress keywords.</string>
	<key>NSSpeechRecognitionUsageDescription</key>
	<string>SafeHer AI analyzes spoken phrases on-device to trigger instant safety protocols when distress words are detected.</string>
</dict>
</plist>`,
  },
  {
    path: 'lib/models/emergency_contact.dart',
    name: 'emergency_contact.dart',
    category: 'Models',
    content: `class EmergencyContact {
  final String id;
  final String name;
  final String phone;
  final String relationship;

  EmergencyContact({
    required this.id,
    required this.name,
    required this.phone,
    required this.relationship,
  });

  Map<String, dynamic> toMap() => {
    'name': name,
    'phone': phone,
    'relationship': relationship,
  };

  factory EmergencyContact.fromMap(String id, Map<dynamic, dynamic> map) {
    return EmergencyContact(
      id: id,
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      relationship: map['relationship'] ?? '',
    );
  }
}`,
  },
  {
    path: 'lib/models/sos_alert.dart',
    name: 'sos_alert.dart',
    category: 'Models',
    content: `class SosAlert {
  final String id;
  final double latitude;
  final double longitude;
  final String locationUrl;
  final String time;
  final String source;
  final String status;

  SosAlert({
    required this.id,
    required this.latitude,
    required this.longitude,
    required this.locationUrl,
    required this.time,
    required this.source,
    required this.status,
  });

  Map<String, dynamic> toMap() => {
    'latitude': latitude,
    'longitude': longitude,
    'locationUrl': locationUrl,
    'time': time,
    'source': source,
    'status': status,
  };

  factory SosAlert.fromMap(String id, Map<dynamic, dynamic> map) {
    return SosAlert(
      id: id,
      latitude: (map['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (map['longitude'] as num?)?.toDouble() ?? 0.0,
      locationUrl: map['locationUrl'] ?? '',
      time: map['time'] ?? '',
      source: map['source'] ?? 'manual-sos',
      status: map['status'] ?? 'activated',
    );
  }
}`,
  },
  {
    path: 'lib/services/auth_service.dart',
    name: 'auth_service.dart',
    category: 'Services',
    content: `import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseDatabase _db = FirebaseDatabase.instance;

  User? get currentUser => _auth.currentUser;

  Future<UserCredential> registerWithEmail({
    required String name,
    required String email,
    required String password,
  }) async {
    final credential = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final uid = credential.user?.uid;
    if (uid != null) {
      await _auth.currentUser?.updateDisplayName(name.trim());
      await _db.ref('users/$uid').set({
        'name': name.trim(),
        'email': email.trim(),
        'createdAt': DateTime.now().toIso8601String(),
      });
    }
    return credential;
  }

  Future<UserCredential> loginWithEmail({
    required String email,
    required String password,
  }) async {
    return await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
  }

  Future<void> sendPasswordReset(String email) async {
    await _auth.sendPasswordResetEmail(email: email.trim());
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }
}`,
  },
  {
    path: 'lib/services/firebase_service.dart',
    name: 'firebase_service.dart',
    category: 'Services',
    content: `import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import '../models/emergency_contact.dart';
import '../models/sos_alert.dart';

class FirebaseService {
  final FirebaseDatabase _db = FirebaseDatabase.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? get currentUid => _auth.currentUser?.uid;

  Stream<List<EmergencyContact>> getContactsStream() {
    final uid = currentUid;
    if (uid == null) return Stream.value([]);
    return _db.ref('users/$uid/contacts').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return [];
      final List<EmergencyContact> list = [];
      if (data is Map) {
        data.forEach((key, val) {
          if (val is Map) list.add(EmergencyContact.fromMap(key.toString(), val));
        });
      }
      return list;
    });
  }

  Future<void> addContact(String name, String phone, String relationship) async {
    final uid = currentUid;
    if (uid == null) throw 'User not authenticated.';
    final newRef = _db.ref('users/$uid/contacts').push();
    await newRef.set({
      'name': name.trim(),
      'phone': phone.trim(),
      'relationship': relationship.trim(),
    });
  }

  Future<void> deleteContact(String contactId) async {
    final uid = currentUid;
    if (uid == null) throw 'User not authenticated.';
    await _db.ref('users/$uid/contacts/$contactId').remove();
  }

  Future<String> saveSosAlert({
    required double latitude,
    required double longitude,
    required String locationUrl,
    required String source,
  }) async {
    final uid = currentUid;
    if (uid == null) throw 'User not authenticated.';
    final alertRef = _db.ref('users/$uid/sosAlerts').push();
    final alertId = alertRef.key ?? DateTime.now().millisecondsSinceEpoch.toString();
    await alertRef.set({
      'latitude': latitude,
      'longitude': longitude,
      'locationUrl': locationUrl,
      'time': DateTime.now().toIso8601String(),
      'source': source,
      'status': 'activated',
    });
    return alertId;
  }

  Stream<List<SosAlert>> getSosAlertsStream() {
    final uid = currentUid;
    if (uid == null) return Stream.value([]);
    return _db.ref('users/$uid/sosAlerts').orderByChild('time').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return [];
      final List<SosAlert> list = [];
      if (data is Map) {
        data.forEach((key, val) {
          if (val is Map) list.add(SosAlert.fromMap(key.toString(), val));
        });
      }
      list.sort((a, b) => b.time.compareTo(a.time));
      return list;
    });
  }
}`,
  },
  {
    path: 'lib/services/location_service.dart',
    name: 'location_service.dart',
    category: 'Services',
    content: `import 'package:geolocator/geolocator.dart';

class LocationService {
  Future<Position> getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) throw 'Location services are disabled on this device.';

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) throw 'Location permission denied.';
    }
    if (permission == LocationPermission.deniedForever) {
      throw 'Location permissions permanently denied.';
    }
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
      timeLimit: const Duration(seconds: 10),
    );
  }

  String getGoogleMapsUrl(double latitude, double longitude) {
    return 'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';
  }
}`,
  },
  {
    path: 'lib/services/sos_service.dart',
    name: 'sos_service.dart',
    category: 'Services',
    content: `import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'firebase_service.dart';
import 'location_service.dart';

class SosService {
  final LocationService _locationService = LocationService();
  final FirebaseService _firebaseService = FirebaseService();

  Future<Map<String, dynamic>> activateSos({required String source}) async {
    double latitude = 0.0;
    double longitude = 0.0;
    String locationUrl = '';

    try {
      final position = await _locationService.getCurrentLocation();
      latitude = position.latitude;
      longitude = position.longitude;
      locationUrl = _locationService.getGoogleMapsUrl(latitude, longitude);
    } catch (e) {
      locationUrl = 'Location unavailable ($e)';
    }

    final alertId = await _firebaseService.saveSosAlert(
      latitude: latitude,
      longitude: longitude,
      locationUrl: locationUrl,
      source: source,
    );

    return {
      'alertId': alertId,
      'latitude': latitude,
      'longitude': longitude,
      'locationUrl': locationUrl,
      'time': DateTime.now().toIso8601String(),
      'source': source,
    };
  }

  Future<void> shareEmergencyLocation({
    required double latitude,
    required double longitude,
    required String locationUrl,
  }) async {
    final String message =
        'EMERGENCY ALERT: I may need immediate help! My current GPS location is:\\n$locationUrl\\n\\nSent via SafeHer AI Safety System.';
    await Share.share(message, subject: 'URGENT: SafeHer AI Emergency Alert');
  }

  Future<bool> makePhoneCall(String phoneNumber) async {
    final Uri uri = Uri(scheme: 'tel', path: phoneNumber.replaceAll(RegExp(r'[^0-9+]'), ''));
    if (await canLaunchUrl(uri)) {
      return await launchUrl(uri);
    }
    throw 'Could not launch dialer for number $phoneNumber';
  }
}`,
  },
  {
    path: 'lib/services/voice_service.dart',
    name: 'voice_service.dart',
    category: 'Services',
    content: `import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../utils/constants.dart';

class VoiceService {
  final SpeechToText _speechToText = SpeechToText();
  bool _isInitialized = false;

  bool get isListening => _speechToText.isListening;

  Future<bool> initialize() async {
    if (_isInitialized) return true;
    try {
      _isInitialized = await _speechToText.initialize();
      return _isInitialized;
    } catch (_) {
      return false;
    }
  }

  Future<void> startListening({
    required Function(String recognizedWords) onResult,
    required Function(String detectedPhrase) onEmergencyDetected,
  }) async {
    if (!_isInitialized) await initialize();
    await _speechToText.listen(
      onResult: (result) {
        final words = result.recognizedWords;
        onResult(words);
        final detected = detectEmergencyIntent(words);
        if (detected != null) onEmergencyDetected(detected);
      },
      listenFor: const Duration(seconds: 60),
      pauseFor: const Duration(seconds: 5),
      partialResults: true,
    );
  }

  Future<void> stopListening() async {
    if (_speechToText.isListening) await _speechToText.stop();
  }

  String? detectEmergencyIntent(String text) {
    if (text.trim().isEmpty) return null;
    final normalized = text.toLowerCase();
    for (final keyword in AppConstants.distressKeywords) {
      if (normalized.contains(keyword.toLowerCase())) return keyword;
    }
    return null;
  }
}`,
  },
  {
    path: 'lib/utils/constants.dart',
    name: 'constants.dart',
    category: 'Utils',
    content: `import 'package:flutter/material.dart';

class AppConstants {
  static const String appName = 'SafeHer AI';
  static const String appSubtitle = 'AI-Powered Women Safety & Emergency Response';
  static const String packageName = 'com.example.safeherai';

  static const Color primaryRed = Color(0xFFE11D48);
  static const Color accentAlert = Color(0xFFDC2626);
  static const Color surfaceDark = Color(0xFF0F172A);
  static const Color cardDark = Color(0xFF1E293B);
  static const Color textMuted = Color(0xFF94A3B8);
  static const Color safetyGreen = Color(0xFF10B981);
  static const Color warningAmber = Color(0xFFF59E0B);

  static const List<String> distressKeywords = [
    'help', 'save me', 'emergency', 'danger', 'attack',
    'someone is following me', "i'm being followed", 'im being followed',
    'please help', 'call police', "i'm scared", 'im scared',
    'leave me alone', 'stop', 'help me'
  ];

  static const String projectTitle = 'AI-Powered Women Safety and Emergency Response System';
  static const String projectDomain = 'Artificial Intelligence and Machine Learning (AIML)';
  static const String academicStudentLevel = 'B.Tech CSE (AIML) 3rd Year Mini-Project';
  static const String academicDisclaimer =
      'This application is an academic prototype designed to demonstrate AI-assisted safety and emergency response features. '
      'It is not a replacement for official emergency services. Always contact appropriate emergency services during a real emergency.';
}`,
  },
  {
    path: 'lib/utils/emergency_numbers.dart',
    name: 'emergency_numbers.dart',
    category: 'Utils',
    content: `class EmergencyServiceInfo {
  final String title;
  final String number;
  final String description;
  final String iconName;

  const EmergencyServiceInfo({
    required this.title,
    required this.number,
    required this.description,
    required this.iconName,
  });
}

class EmergencyNumbers {
  static const List<EmergencyServiceInfo> services = [
    EmergencyServiceInfo(
      title: 'Police',
      number: '100',
      description: 'Immediate law enforcement & crime prevention',
      iconName: 'local_police',
    ),
    EmergencyServiceInfo(
      title: 'National Emergency',
      number: '112',
      description: 'Unified all-in-one national helpline',
      iconName: 'emergency',
    ),
    EmergencyServiceInfo(
      title: 'Ambulance',
      number: '108',
      description: 'Medical & emergency medical response',
      iconName: 'medical_services',
    ),
    EmergencyServiceInfo(
      title: 'Fire Brigade',
      number: '101',
      description: 'Fire & rescue emergency response',
      iconName: 'local_fire_department',
    ),
    EmergencyServiceInfo(
      title: 'Women Helpline',
      number: '1091',
      description: '24/7 dedicated women distress & safety support',
      iconName: 'support_agent',
    ),
  ];
}`,
  },
  {
    path: 'README.md',
    name: 'README.md',
    category: 'Root',
    content: `# SafeHer AI: Flutter Mobile Application
Package Name: com.example.safeherai
Domain: B.Tech CSE (AIML) Mini-Project

## Quick Start:
1. flutter pub get
2. flutterfire configure
3. flutter run
4. flutter build apk --release`,
  },
];
