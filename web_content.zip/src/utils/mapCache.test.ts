import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDistanceKm,
  generateFlightArc,
  createDefaultTripMapData,
  saveTripMapCache,
  loadTripMapCache,
  clearTripMapCache,
  isTripMapCached,
} from './mapCache';

// Mock localStorage for node:test environment if not present
if (typeof globalThis.localStorage === 'undefined') {
  const memoryStore = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => memoryStore.get(key) || null,
    setItem: (key: string, val: string) => { memoryStore.set(key, val); },
    removeItem: (key: string) => { memoryStore.delete(key); },
    clear: () => { memoryStore.clear(); },
    key: (i: number) => Array.from(memoryStore.keys())[i] || null,
    length: 0,
  } as unknown as Storage;
}

test('Map Cache & Route Geometry Utility', async (t) => {
  await t.test('calculates accurate distance between Algiers (ALG) and Istanbul (IST)', () => {
    // Algiers ~36.69, 3.21 -> Istanbul ~41.27, 28.75
    const dist = calculateDistanceKm(36.691, 3.2154, 41.2753, 28.7519);
    // Real great-circle distance is ~2,280 km
    assert.ok(dist >= 2200 && dist <= 2350, `Distance was ${dist}`);
  });

  await t.test('generates flight arc coordinates with apex curve', () => {
    const origin = { lat: 36.691, lng: 3.2154 };
    const dest = { lat: 41.2753, lng: 28.7519 };
    const arc = generateFlightArc(origin, dest, 10);

    assert.equal(arc.length, 11);
    // Origin check
    assert.equal(arc[0].lat, 36.691);
    assert.equal(arc[0].lng, 3.2154);
    // Midpoint should have higher latitude due to curvature offset
    const midpoint = arc[5];
    assert.ok(midpoint.lat > 36.691 && midpoint.lat > 40.0);
    // Destination check
    assert.equal(arc[10].lat, 41.2753);
    assert.equal(arc[10].lng, 28.7519);
  });

  await t.test('creates default trip map data with airport pins, hotel, and attractions', () => {
    const data = createDefaultTripMapData('trip-ist-2026');

    assert.equal(data.tripId, 'trip-ist-2026');
    assert.equal(data.flightRoute.origin.code, 'ALG');
    assert.equal(data.flightRoute.destination.code, 'IST');
    assert.equal(data.cityMap.hotel.type, 'hotel');
    assert.ok(data.cityMap.attractions.length >= 4);
    assert.ok(data.flightRoute.waypoints.length > 10);
    assert.equal(data.isOfflineAvailable, true);
  });

  await t.test('correctly persists and retrieves map cache from localStorage', () => {
    const tripId = 'trip-test-cache-001';
    clearTripMapCache(tripId);
    assert.equal(isTripMapCached(tripId), false);

    const fresh = createDefaultTripMapData(tripId);
    const saved = saveTripMapCache(tripId, fresh);
    assert.equal(saved, true);
    assert.equal(isTripMapCached(tripId), true);

    const loaded = loadTripMapCache(tripId);
    assert.ok(loaded);
    assert.equal(loaded.tripId, tripId);
    assert.equal(loaded.flightRoute.origin.code, 'ALG');
    assert.equal(loaded.cityMap.hotel.title.includes('سويسوتيل'), true);

    // Clean up
    clearTripMapCache(tripId);
    assert.equal(isTripMapCached(tripId), false);
  });
});
