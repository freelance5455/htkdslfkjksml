export interface DailyActivityPoint {
  dateKey: string; // YYYY-MM-DD
  label: string; // e.g. "Nov 16"
  signups: number;
  quizAttempts: number;
}

export function extractTimestampMillis(ts: unknown): number | null {
  if (ts === null || ts === undefined) return null;
  if (typeof ts === 'number') {
    return Number.isFinite(ts) && ts > 0 ? ts : null;
  }
  if (ts instanceof Date) {
    const ms = ts.getTime();
    return Number.isFinite(ms) ? ms : null;
  }
  if (typeof ts === 'string') {
    const ms = Date.parse(ts);
    return Number.isFinite(ms) ? ms : null;
  }
  if (typeof ts === 'object') {
    const obj = ts as {
      toMillis?: () => number;
      toDate?: () => Date;
      seconds?: number;
      _seconds?: number;
      nanoseconds?: number;
    };
    if (typeof obj.toMillis === 'function') {
      const ms = obj.toMillis();
      return Number.isFinite(ms) ? ms : null;
    }
    if (typeof obj.toDate === 'function') {
      const d = obj.toDate();
      const ms = d instanceof Date ? d.getTime() : NaN;
      return Number.isFinite(ms) ? ms : null;
    }
    const secs =
      typeof obj.seconds === 'number'
        ? obj.seconds
        : typeof obj._seconds === 'number'
          ? obj._seconds
          : null;
    if (secs !== null && Number.isFinite(secs)) {
      const nanos = typeof obj.nanoseconds === 'number' ? obj.nanoseconds : 0;
      return secs * 1000 + Math.floor(nanos / 1_000_000);
    }
  }
  return null;
}

function toLocalDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function formatShortDay(date: Date): string {
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

/**
 * Aggregates real student signup timestamps and quiz attempt timestamps into a
 * contiguous daily time series ending on `referenceDate` (defaults to today).
 */
export function buildDailyActivitySeries(params: {
  students: ReadonlyArray<{ createdAt?: unknown }>;
  quizAttempts: ReadonlyArray<{ updatedAt?: unknown }>;
  days?: number;
  referenceDate?: Date;
}): DailyActivityPoint[] {
  const totalDays = Math.max(1, Math.min(90, Math.round(params.days ?? 14)));
  const anchor = params.referenceDate ? new Date(params.referenceDate) : new Date();
  anchor.setHours(0, 0, 0, 0);

  const buckets = new Map<string, DailyActivityPoint>();
  const orderedKeys: string[] = [];

  for (let offset = totalDays - 1; offset >= 0; offset -= 1) {
    const d = new Date(anchor);
    d.setDate(anchor.getDate() - offset);
    const key = toLocalDateKey(d);
    orderedKeys.push(key);
    buckets.set(key, {
      dateKey: key,
      label: formatShortDay(d),
      signups: 0,
      quizAttempts: 0,
    });
  }

  for (const student of params.students) {
    const ms = extractTimestampMillis(student.createdAt);
    if (ms === null) continue;
    const key = toLocalDateKey(new Date(ms));
    const bucket = buckets.get(key);
    if (bucket) {
      bucket.signups += 1;
    }
  }

  for (const attempt of params.quizAttempts) {
    const ms = extractTimestampMillis(attempt.updatedAt);
    if (ms === null) continue;
    const key = toLocalDateKey(new Date(ms));
    const bucket = buckets.get(key);
    if (bucket) {
      bucket.quizAttempts += 1;
    }
  }

  return orderedKeys.map((k) => buckets.get(k)!);
}
