import JSZip from 'jszip';
import type { ComicEntry, LibraryFolder } from '../types/comic';
import { scanComicArchive } from './archiveEngine';
import { saveComic, saveFolder, saveOfflineArchive } from './libraryDb';

import coverRainUrl from '../assets/images/comic_cover_rain_archive_1795095570855.jpg';
import pageRooftopUrl from '../assets/images/comic_page_rooftop_ink_1795095572854.jpg';
import coverValleyUrl from '../assets/images/comic_cover_iron_valley_1795095571461.jpg';
import stripTrailUrl from '../assets/images/comic_strip_valley_trail_1795095571462.jpg';

async function fetchAssetBytes(url: string): Promise<Uint8Array> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch sample asset: ${url}`);
  return new Uint8Array(await res.arrayBuffer());
}

async function renderEditorialPanelPage(opts: {
  width: number;
  height: number;
  bg: string;
  fg: string;
  accent: string;
  chapter: string;
  title: string;
  caption: string;
  panels: number;
  mime?: 'image/webp' | 'image/png';
}): Promise<Uint8Array> {
  const canvas = document.createElement('canvas');
  canvas.width = opts.width;
  canvas.height = opts.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new Uint8Array();

  ctx.fillStyle = opts.bg;
  ctx.fillRect(0, 0, opts.width, opts.height);

  const pad = 48;
  const headerH = 110;

  ctx.fillStyle = opts.accent;
  ctx.font = '600 22px sans-serif';
  ctx.fillText(opts.chapter.toUpperCase(), pad, pad + 26);

  ctx.fillStyle = opts.fg;
  ctx.font = '700 40px sans-serif';
  ctx.fillText(opts.title, pad, pad + 78);

  const bodyTop = pad + headerH;
  const bodyH = opts.height - bodyTop - pad - 56;
  const gap = 24;
  const panelH = (bodyH - gap * (opts.panels - 1)) / opts.panels;

  for (let i = 0; i < opts.panels; i++) {
    const y = bodyTop + i * (panelH + gap);
    ctx.strokeStyle = opts.fg;
    ctx.lineWidth = 4;
    ctx.strokeRect(pad, y, opts.width - pad * 2, panelH);

    // Architectural framing lines inside panel
    ctx.fillStyle = i % 2 === 0 ? 'rgba(128,128,140,0.12)' : 'rgba(128,128,140,0.06)';
    ctx.fillRect(pad + 6, y + 6, opts.width - pad * 2 - 12, panelH - 12);

    ctx.fillStyle = opts.fg;
    ctx.globalAlpha = 0.72;
    ctx.font = '500 22px sans-serif';
    ctx.fillText(
      i === 0 ? opts.caption : `Scene ${i + 1} · Continuous ink panel composition`,
      pad + 28,
      y + panelH / 2 + 8,
    );
    ctx.globalAlpha = 1;
  }

  ctx.fillStyle = opts.fg;
  ctx.globalAlpha = 0.45;
  ctx.font = '500 18px monospace';
  ctx.fillText('KOMA SAMPLE EDITION', pad, opts.height - 28);
  ctx.globalAlpha = 1;

  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error('Canvas encode failed'))),
      opts.mime || 'image/webp',
      0.9,
    );
  });
  return new Uint8Array(await blob.arrayBuffer());
}

/**
 * Generates an authentic 900x4800px tall vertical strip image to demonstrate
 * Koma Reader's hardware-accelerated GPU strip slicing without scroll lag.
 */
async function renderLongVerticalStripPage(): Promise<Uint8Array> {
  const width = 900;
  const height = 4600;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new Uint8Array();

  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, '#eef2f0');
  grad.addColorStop(0.5, '#dfe7e3');
  grad.addColorStop(1, '#18221e');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  const beats = [
    '01 · Ridge Descent — Continuous 4600px vertical strip',
    '02 · Cedar Canopy — Auto-sliced into GPU 2048px tiles',
    '03 · Stone Steps — Zero-seam margin-aware scrolling',
    '04 · River Crossing — Smooth hardware acceleration',
    '05 · Twilight Lanterns — End of Chapter II',
  ];

  beats.forEach((label, idx) => {
    const y = 160 + idx * 880;
    ctx.fillStyle = idx < 3 ? '#1e2925' : '#f1f5f3';
    ctx.strokeStyle = idx < 3 ? '#2c3e37' : '#94b0a5';
    ctx.lineWidth = 4;
    ctx.strokeRect(72, y, width - 144, 680);

    ctx.font = '600 26px sans-serif';
    ctx.fillText(label, 108, y + 72);

    // Subtle geometric horizon illustration
    ctx.beginPath();
    ctx.moveTo(108, y + 480);
    ctx.bezierCurveTo(280, y + 310, 560, y + 540, width - 108, y + 360);
    ctx.lineWidth = 3;
    ctx.stroke();
  });

  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('Strip encode failed'))), 'image/webp', 0.88);
  });
  return new Uint8Array(await blob.arrayBuffer());
}

export async function seedSampleLibrary(): Promise<{ folder: LibraryFolder; comics: ComicEntry[] }> {
  const folderId = 'sample-local-shelf';
  const folder: LibraryFolder = {
    id: folderId,
    name: 'Sample Shelf (Offline)',
    sourceType: 'sample',
    comicCount: 2,
    lastScannedAt: Date.now(),
    permissionState: 'granted',
  };
  await saveFolder(folder);

  const [rainCover, rooftopPage, valleyCover, trailStrip] = await Promise.all([
    fetchAssetBytes(coverRainUrl),
    fetchAssetBytes(pageRooftopUrl),
    fetchAssetBytes(coverValleyUrl),
    fetchAssetBytes(stripTrailUrl),
  ]);

  // Sample 1: Rain Terminal (Graphic Novel with ComicInfo.xml <Pages Bookmark="..."> + <Bookmarks>)
  const zip1 = new JSZip();
  zip1.file('000_cover.jpg', rainCover);
  zip1.file(
    '001_prologue.webp',
    await renderEditorialPanelPage({
      width: 1000,
      height: 1400,
      bg: '#f4f1ea',
      fg: '#18181b',
      accent: '#e11d48',
      chapter: 'Prologue',
      title: 'Platform Four, 18:42',
      caption: 'The last local train arrives through warm amber mist.',
      panels: 3,
    }),
  );
  zip1.file('002_rooftop.jpg', rooftopPage);
  zip1.file(
    '003_chapter1.webp',
    await renderEditorialPanelPage({
      width: 1000,
      height: 1400,
      bg: '#16171b',
      fg: '#f4f4f5',
      accent: '#38bdf8',
      chapter: 'Chapter 1',
      title: 'Signal Across the Overpass',
      caption: 'Horizontal page-wise or continuous scroll ready.',
      panels: 4,
    }),
  );
  zip1.file(
    '004_epilogue.webp',
    await renderEditorialPanelPage({
      width: 1000,
      height: 1400,
      bg: '#f4f1ea',
      fg: '#18181b',
      accent: '#e11d48',
      chapter: 'Afterword',
      title: 'Station Notes & Sketches',
      caption: 'Tap the Bookmark icon in the top bar to jump via TOC.',
      panels: 2,
    }),
  );
  zip1.file(
    'ComicInfo.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<ComicInfo>
  <Title>Rain Terminal</Title>
  <Series>Metropolitan Nocturnes</Series>
  <Number>01</Number>
  <Volume>1</Volume>
  <Count>4</Count>
  <Year>2026</Year>
  <Writer>K. Takahashi</Writer>
  <Penciller>M. Sato</Penciller>
  <Publisher>Sumi Press</Publisher>
  <Genre>Drama, Slice of Life</Genre>
  <Tags>Graphic Novel, Offline Demo, ComicInfo</Tags>
  <LanguageISO>en</LanguageISO>
  <Manga>No</Manga>
  <Summary>An archival commuter graphic novel demonstrating ComicInfo.xml chapter bookmarks, horizontal page-wise navigation, and custom zoom presets for smaller Android tablets.</Summary>
  <Pages>
    <Page Image="0" Type="FrontCover" Bookmark="Cover · Rain Terminal" />
    <Page Image="1" Type="Story" Bookmark="Prologue: Platform Four" />
    <Page Image="2" Type="Story" />
    <Page Image="3" Type="Story" Bookmark="Chapter 1: Signal Across the Overpass" />
    <Page Image="4" Type="BackCover" Bookmark="Afterword &amp; Notes" />
  </Pages>
  <Bookmarks>
    <Bookmark Page="2" Title="Scene: Twilight Rooftop" />
  </Bookmarks>
</ComicInfo>`,
  );

  const cbz1Blob = await zip1.generateAsync({ type: 'blob' });
  const scan1 = await scanComicArchive(cbz1Blob, 'Rain Terminal Vol 01.cbz');

  const comic1: ComicEntry = {
    id: 'sample-rain-terminal',
    fileName: 'Rain Terminal Vol 01.cbz',
    displayTitle: scan1.comicInfo?.title || 'Rain Terminal',
    folderId,
    folderName: folder.name,
    relativePath: 'Sample Shelf/Rain Terminal Vol 01.cbz',
    format: 'cbz',
    fileSize: cbz1Blob.size,
    lastModified: Date.now() - 86400_000,
    pageCount: scan1.pageCount,
    coverBlob: scan1.coverBlob,
    comicInfo: scan1.comicInfo,
    currentPage: 0,
    scrollProgress: 0,
    addedAt: Date.now(),
    isOfflineCached: true,
    isSample: true,
    userBookmarks: [],
    imageFormatsFound: scan1.imageFormatsFound,
  };

  // Sample 2: Cedar Ridge (Vertical Webtoon with a 900x4600px long strip + Bookmarks tag)
  const zip2 = new JSZip();
  zip2.file('000_cover.jpg', valleyCover);
  zip2.file('001_trail.jpg', trailStrip);
  zip2.file('002_long_strip.webp', await renderLongVerticalStripPage());
  zip2.file(
    '003_camp.webp',
    await renderEditorialPanelPage({
      width: 900,
      height: 1600,
      bg: '#131917',
      fg: '#e4ece8',
      accent: '#10b981',
      chapter: 'Episode 2',
      title: 'Campfire Above the Mist',
      caption: 'Try adjusting Left & Right Margins in Vertical Scroll mode.',
      panels: 3,
    }),
  );
  zip2.file(
    'ComicInfo.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<ComicInfo>
  <Title>Cedar Ridge</Title>
  <Series>Iron Valley Chronicles</Series>
  <Number>12</Number>
  <Volume>2</Volume>
  <Year>2026</Year>
  <Writer>A. Lin</Writer>
  <Colorist>H. Park</Colorist>
  <Publisher>Koma Webtoon Studio</Publisher>
  <Genre>Adventure, Webtoon</Genre>
  <Tags>Vertical Strip, Long Image Slicer, WebP</Tags>
  <LanguageISO>en</LanguageISO>
  <Manga>Yes</Manga>
  <Summary>A vertical-scroll webtoon episode containing a 4600px continuous strip image automatically tiled for smooth hardware-accelerated Android scrolling.</Summary>
  <Pages>
    <Page Image="0" Type="FrontCover" Bookmark="Cover · Cedar Ridge" />
    <Page Image="1" Type="Story" Bookmark="Episode 1: Valley Descent" />
    <Page Image="2" Type="Story" Bookmark="Episode 1 (Long Strip 4600px)" />
    <Page Image="3" Type="Story" Bookmark="Episode 2: Campfire Above the Mist" />
  </Pages>
</ComicInfo>`,
  );

  const cbz2Blob = await zip2.generateAsync({ type: 'blob' });
  const scan2 = await scanComicArchive(cbz2Blob, 'Cedar Ridge Ep 12.cbz');

  const comic2: ComicEntry = {
    id: 'sample-cedar-ridge',
    fileName: 'Cedar Ridge Ep 12.cbz',
    displayTitle: scan2.comicInfo?.title || 'Cedar Ridge',
    folderId,
    folderName: folder.name,
    relativePath: 'Sample Shelf/Cedar Ridge Ep 12.cbz',
    format: 'cbz',
    fileSize: cbz2Blob.size,
    lastModified: Date.now(),
    pageCount: scan2.pageCount,
    coverBlob: scan2.coverBlob,
    comicInfo: scan2.comicInfo,
    currentPage: 0,
    scrollProgress: 0,
    addedAt: Date.now(),
    isOfflineCached: true,
    isSample: true,
    userBookmarks: [],
    imageFormatsFound: scan2.imageFormatsFound,
  };

  await Promise.all([
    saveComic(comic1),
    saveOfflineArchive(comic1.id, comic1.fileName, cbz1Blob),
    saveComic(comic2),
    saveOfflineArchive(comic2.id, comic2.fileName, cbz2Blob),
  ]);

  return { folder, comics: [comic1, comic2] };
}
