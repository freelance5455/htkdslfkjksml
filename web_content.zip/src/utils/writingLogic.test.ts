import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildDiffSegments,
  containsTargetWord,
  CURATED_ARTICLES,
  lookupWordInStore,
  PICTURE_SCENES,
  tokenizeArticleParagraph,
  WRITING_TOPICS,
} from './writingLogic';
import { parseTSVToStore } from './vocabLogic';
import { STARTER_VOCAB_TSV } from '../data/starterVocab';

test('containsTargetWord enforces target word strictly including valid English inflections', () => {
  assert.equal(containsTargetWord('I have a new book today.', 'have'), true);
  assert.equal(containsTargetWord('She has two cats at home.', 'have'), true);
  assert.equal(containsTargetWord('They had dinner together.', 'have'), true);
  assert.equal(containsTargetWord('We walked to school yesterday.', 'walk'), true);
  assert.equal(containsTargetWord('He is studying hard for the test.', 'study'), true);

  // Must NOT match substring inside an unrelated word
  assert.equal(containsTargetWord('This category is very broad.', 'cat'), false);
  assert.equal(containsTargetWord('I like reading books every evening.', 'travel'), false);

  // Multi-word phrase support
  assert.equal(containsTargetWord('I woke up very early this morning.', 'wake up'), true);
});

test('buildDiffSegments flags erroneous words for red underlining while preserving valid text', () => {
  const segs = buildDiffSegments(
    'She go to school yesterday.',
    'She went to school yesterday.',
    ['go']
  );
  const errorTexts = segs.filter((s) => s.isError).map((s) => s.text.trim());
  assert.ok(errorTexts.includes('go'), `Expected "go" to be underlined, got ${JSON.stringify(segs)}`);

  const cleanSegs = buildDiffSegments(
    'She went to school yesterday.',
    'She went to school yesterday.',
    []
  );
  assert.equal(cleanSegs.some((s) => s.isError), false);
});

test('tokenizeArticleParagraph preserves punctuation and whitespace while marking words clickable', () => {
  const sample = "Arthur's shop opened at seven, didn't it?";
  const tokens = tokenizeArticleParagraph(sample);
  const reconstructed = tokens.map((t) => t.text).join('');
  assert.equal(reconstructed, sample);

  const words = tokens.filter((t) => t.isWord).map((t) => t.cleanWord);
  assert.deepEqual(words, ["arthur's", 'shop', 'opened', 'at', 'seven', "didn't", 'it']);
});

test('lookupWordInStore finds exact and inflected English words in dictionary store', () => {
  const store = parseTSVToStore(STARTER_VOCAB_TSV);
  const first = store.words[0];
  assert.ok(first);
  const hit = lookupWordInStore(first.en, store);
  assert.ok(hit);
  assert.equal(hit.en.toLowerCase(), first.en.toLowerCase());
});

test('curated scenes, writing topics, and reading articles are rich and well-formed', () => {
  assert.ok(PICTURE_SCENES.length >= 6);
  assert.ok(WRITING_TOPICS.length >= 5);
  assert.ok(CURATED_ARTICLES.length >= 6);
  for (const art of CURATED_ARTICLES) {
    assert.ok(art.paragraphs.length >= 3);
    assert.ok(art.title.length > 5);
    assert.ok(art.titleAr.length > 3);
  }
});
