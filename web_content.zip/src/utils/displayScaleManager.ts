import { useState, useEffect } from "react";
import { DisplayScaleConfig, DisplayScalePreset } from "../types";

export const DEFAULT_DISPLAY_SCALE_CONFIG: DisplayScaleConfig = {
  uiScale: 1.0,           // 100% (Range: 0.75 - 1.75)
  typographyScale: 1.0,   // 100% (Range: 0.75 - 1.75)
  toolDockScale: 1.0,     // 100% (Range: 0.75 - 1.75)
  canvasScale: 1.0,       // 100% (Range: 0.75 - 1.75)
  autoSystemFontScale: false,
  minTouchTargetSize: 48, // 48px WCAG AA touch target minimum
  safeLayoutMode: true,   // Prevents overflow by wrapping & dynamic clamping
};

export const SCALE_PRESETS: Record<DisplayScalePreset, { label: string; desc: string; config: Partial<DisplayScaleConfig> }> = {
  compact: {
    label: "Kompakt (%85)",
    desc: "Yüksek yoğunluklu ekranlar, geniş veri görünümü",
    config: {
      uiScale: 0.85,
      typographyScale: 0.90,
      toolDockScale: 0.85,
      canvasScale: 0.90,
    },
  },
  standard: {
    label: "Standart / Dengeli (%100)",
    desc: "Tasarımcı standardı, tüm cihazlar için ideal",
    config: {
      uiScale: 1.0,
      typographyScale: 1.0,
      toolDockScale: 1.0,
      canvasScale: 1.0,
    },
  },
  comfortable: {
    label: "Büyük & Rahat (%125)",
    desc: "Tablet ve dokunmatik ekranlar için geniş tutma payı",
    config: {
      uiScale: 1.25,
      typographyScale: 1.20,
      toolDockScale: 1.20,
      canvasScale: 1.15,
    },
  },
  accessible: {
    label: "Erişilebilir (%150)",
    desc: "Okuma kolaylığı ve büyük butonlar, sıfır göz yorgunluğu",
    config: {
      uiScale: 1.50,
      typographyScale: 1.50,
      toolDockScale: 1.40,
      canvasScale: 1.25,
    },
  },
};

const STORAGE_KEY = "noteflow_display_scale_config_v2";

/**
 * 2. GLOBAL DYNAMIC SCALE ENGINE (MATH FORMULAS)
 * Mathematical scaling functions with hard bounds & clamps to ensure
 * touch targets never shrink below 48dp and elements never collide.
 */

/**
 * Calculates scaled Density-Independent Pixels (DP) for UI elements, padding, buttons.
 */
export function scaledDp(
  baseDp: number,
  multiplier: number = 1.0,
  minClamp: number = 4,
  maxClamp: number = 600
): number {
  const scaled = Math.round(baseDp * multiplier);
  return Math.min(maxClamp, Math.max(minClamp, scaled));
}

/**
 * Calculates scaled Scale-Independent Pixels (SP) for typography and text.
 */
export function scaledSp(
  baseSp: number,
  multiplier: number = 1.0,
  minClamp: number = 10,
  maxClamp: number = 72
): number {
  const scaled = Math.round(baseSp * multiplier);
  return Math.min(maxClamp, Math.max(minClamp, scaled));
}

/**
 * Calculates scaled Tool Dock & Brush Icon size with mandatory min 48dp touch target guarantee.
 */
export function scaledToolSize(
  baseSize: number,
  multiplier: number = 1.0,
  minTouchTarget: number = 48
): { iconSize: number; targetSize: number } {
  const iconSize = Math.round(baseSize * multiplier);
  const targetSize = Math.max(minTouchTarget, Math.round((baseSize + 16) * multiplier));
  return { iconSize, targetSize };
}

/**
 * 4. TUVAL (CANVAS) VE VEKTÖREL MATRİS KALİTE KORUMASI:
 * Physical Canvas Resolution = Logical Bounds * DevicePixelRatio * canvasScaleMultiplier
 * Prevents any blur, pixelation, or fuzziness regardless of zoom or canvas scale!
 */
export function calculateCanvasHiDpiMatrix(
  logicalWidth: number,
  logicalHeight: number,
  canvasScaleMultiplier: number = 1.0
): {
  bufferWidth: number;
  bufferHeight: number;
  effectiveDpr: number;
} {
  const baseDpr = typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1;
  // Multiply DPR with canvas scale for razor-sharp vector rendering
  const effectiveDpr = Math.max(1, baseDpr * canvasScaleMultiplier);
  const bufferWidth = Math.round(logicalWidth * effectiveDpr);
  const bufferHeight = Math.round(logicalHeight * effectiveDpr);

  return {
    bufferWidth,
    bufferHeight,
    effectiveDpr,
  };
}

/**
 * Injects CSS Custom Properties into documentElement for zero-cost reactive styling.
 */
function applyScaleToDocument(config: DisplayScaleConfig) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;

  root.style.setProperty("--scale-ui", config.uiScale.toFixed(3));
  root.style.setProperty("--scale-text", config.typographyScale.toFixed(3));
  root.style.setProperty("--scale-tool", config.toolDockScale.toFixed(3));
  root.style.setProperty("--scale-canvas", config.canvasScale.toFixed(3));
  root.style.setProperty("--min-touch-target", `${config.minTouchTargetSize}px`);

  // Document Root Font Size adjustment for rem calculations
  if (config.autoSystemFontScale) {
    root.style.fontSize = `${16 * config.typographyScale}px`;
  } else {
    root.style.fontSize = "";
  }
}

/**
 * DisplayScaleManager Singleton
 * Reactive State & persistence engine for categorical global scaling.
 */
export class DisplayScaleManager {
  private static config: DisplayScaleConfig = DisplayScaleManager.loadConfig();
  private static listeners: Set<(config: DisplayScaleConfig) => void> = new Set();
  private static isInitialized = false;

  private static loadConfig(): DisplayScaleConfig {
    if (typeof localStorage === "undefined") return { ...DEFAULT_DISPLAY_SCALE_CONFIG };
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          ...DEFAULT_DISPLAY_SCALE_CONFIG,
          ...parsed,
          // Clamps to ensure values are always valid numbers within bounds
          uiScale: Math.min(1.75, Math.max(0.75, Number(parsed.uiScale) || 1.0)),
          typographyScale: Math.min(1.75, Math.max(0.75, Number(parsed.typographyScale) || 1.0)),
          toolDockScale: Math.min(1.75, Math.max(0.75, Number(parsed.toolDockScale) || 1.0)),
          canvasScale: Math.min(1.75, Math.max(0.75, Number(parsed.canvasScale) || 1.0)),
        };
      }
    } catch (e) {
      console.warn("Failed to load display scale config, using defaults", e);
    }
    return { ...DEFAULT_DISPLAY_SCALE_CONFIG };
  }

  public static initialize(): void {
    if (this.isInitialized) return;
    this.isInitialized = true;
    applyScaleToDocument(this.config);
  }

  public static getConfig(): DisplayScaleConfig {
    return { ...this.config };
  }

  public static updateConfig(partial: Partial<DisplayScaleConfig>): void {
    const updated: DisplayScaleConfig = {
      ...this.config,
      ...partial,
      uiScale: partial.uiScale !== undefined ? Math.min(1.75, Math.max(0.75, partial.uiScale)) : this.config.uiScale,
      typographyScale: partial.typographyScale !== undefined ? Math.min(1.75, Math.max(0.75, partial.typographyScale)) : this.config.typographyScale,
      toolDockScale: partial.toolDockScale !== undefined ? Math.min(1.75, Math.max(0.75, partial.toolDockScale)) : this.config.toolDockScale,
      canvasScale: partial.canvasScale !== undefined ? Math.min(1.75, Math.max(0.75, partial.canvasScale)) : this.config.canvasScale,
    };

    this.config = updated;
    applyScaleToDocument(updated);

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn("Failed to save display scale config", e);
    }

    this.listeners.forEach((listener) => {
      try {
        listener(updated);
      } catch (err) {
        console.error("Error in display scale listener", err);
      }
    });
  }

  public static applyPreset(presetKey: DisplayScalePreset): void {
    const preset = SCALE_PRESETS[presetKey];
    if (preset) {
      this.updateConfig(preset.config);
    }
  }

  public static resetToDefaults(): void {
    this.updateConfig({ ...DEFAULT_DISPLAY_SCALE_CONFIG });
  }

  public static subscribe(listener: (config: DisplayScaleConfig) => void): () => void {
    this.listeners.add(listener);
    listener(this.config);
    return () => {
      this.listeners.delete(listener);
    };
  }
}

// Auto-initialize on module load if in browser
if (typeof window !== "undefined") {
  DisplayScaleManager.initialize();
}

/**
 * React Hook: useDisplayScale
 * Grants component-level reactivity to global display scaling
 */
export function useDisplayScale() {
  const [scaleConfig, setScaleConfig] = useState<DisplayScaleConfig>(() =>
    DisplayScaleManager.getConfig()
  );

  useEffect(() => {
    const unsub = DisplayScaleManager.subscribe((newConfig) => {
      setScaleConfig(newConfig);
    });
    return unsub;
  }, []);

  return {
    scaleConfig,
    updateScale: DisplayScaleManager.updateConfig.bind(DisplayScaleManager),
    resetToDefaults: DisplayScaleManager.resetToDefaults.bind(DisplayScaleManager),
    applyPreset: DisplayScaleManager.applyPreset.bind(DisplayScaleManager),
    // Helper math functions bound to current configuration
    dp: (base: number, min?: number, max?: number) =>
      scaledDp(base, scaleConfig.uiScale, min, max),
    sp: (base: number, min?: number, max?: number) =>
      scaledSp(base, scaleConfig.typographyScale, min, max),
    toolSize: (base: number) =>
      scaledToolSize(base, scaleConfig.toolDockScale, scaleConfig.minTouchTargetSize),
    canvasResolution: (w: number, h: number) =>
      calculateCanvasHiDpiMatrix(w, h, scaleConfig.canvasScale),
  };
}
