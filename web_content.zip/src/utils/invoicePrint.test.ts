import test from 'node:test';
import assert from 'node:assert/strict';
import {
  sortInvoiceLines,
  moveInvoiceLine,
  calculatePrintableTotals,
  buildPrintableFromSalesGroup,
  buildPrintableFromPurchasesGroup,
  type PrintableInvoiceLine,
} from './invoicePrint';

const sampleLines: PrintableInvoiceLine[] = [
  {
    id: '1',
    barcode: '6291100123456',
    medicineName: 'Panadol Extra',
    unit: 'باكيت',
    qty: 10,
    unitPrice: 2500,
    expiryDate: '2027-05-01',
  },
  {
    id: '2',
    barcode: '5000158068942',
    medicineName: 'Augmentin 1g',
    unit: 'باكيت',
    qty: 50,
    unitPrice: 8500,
    expiryDate: '2026-12-01',
  },
  {
    id: '3',
    barcode: '6214000100124',
    medicineName: 'Concor 5mg',
    unit: 'باكيت',
    qty: 20,
    unitPrice: 6000,
    expiryDate: '2028-01-15',
  },
];

test('sortInvoiceLines sorts by quantity descending and expiry ascending', () => {
  const byQty = sortInvoiceLines(sampleLines, 'qty_desc');
  assert.equal(byQty[0].id, '2'); // 50
  assert.equal(byQty[1].id, '3'); // 20
  assert.equal(byQty[2].id, '1'); // 10

  const byExpiry = sortInvoiceLines(sampleLines, 'expiry_asc');
  assert.equal(byExpiry[0].id, '2'); // 2026-12-01
  assert.equal(byExpiry[1].id, '1'); // 2027-05-01
  assert.equal(byExpiry[2].id, '3'); // 2028-01-15
});

test('moveInvoiceLine moves items up and down safely without mutating out of bounds', () => {
  const movedDown = moveInvoiceLine(sampleLines, 0, 'down');
  assert.equal(movedDown[0].id, '2');
  assert.equal(movedDown[1].id, '1');

  const movedUp = moveInvoiceLine(movedDown, 1, 'up');
  assert.equal(movedUp[0].id, '1');
  assert.equal(movedUp[1].id, '2');

  const outOfBounds = moveInvoiceLine(sampleLines, 0, 'up');
  assert.equal(outOfBounds[0].id, '1');
});

test('calculatePrintableTotals computes subtotal, discount, netTotal, and remaining accurately', () => {
  // Line 1: 10 * 2500 = 25,000
  // Line 2: 50 * 8500 = 425,000
  // Line 3: 20 * 6000 = 120,000
  // Subtotal = 570,000, totalQty = 80
  const res = calculatePrintableTotals(sampleLines, 20000, 400000);
  assert.equal(res.subtotal, 570000);
  assert.equal(res.totalQty, 80);
  assert.equal(res.discount, 20000);
  assert.equal(res.netTotal, 550000);
  assert.equal(res.paid, 400000);
  assert.equal(res.remaining, 150000);
});

test('buildPrintableFromSalesGroup and buildPrintableFromPurchasesGroup populate custom issuer and supplier/buyer names', () => {
  const salePrint = buildPrintableFromSalesGroup(
    {
      date: '2026-10-20',
      buyer: 'صيدلية الشفاء - الكرادة',
      invoiceTag: 'SINV-101',
      items: [
        {
          id: 's1',
          date: '2026-10-20',
          buyer: 'صيدلية الشفاء - الكرادة',
          barcode: '6291100123456',
          medicineName: 'Panadol Extra',
          qty: 30,
          unitPrice: 3000,
          totalAmount: 90000,
          avgCostAtSale: 2250,
          amountPaid: 50000,
          remainingUnpaid: 40000,
          createdAt: 1000,
        },
      ],
      totalAmount: 90000,
      amountPaid: 50000,
    },
    'مذخر النور الدوائي'
  );

  assert.equal(salePrint.issuerName, 'مذخر النور الدوائي');
  assert.equal(salePrint.recipientName, 'صيدلية الشفاء - الكرادة');
  assert.equal(salePrint.lines.length, 1);

  const purchasePrint = buildPrintableFromPurchasesGroup(
    {
      date: '2026-10-20',
      supplier: 'مذخر الرشيد - السعدون',
      invoiceTag: 'INV-202',
      items: [
        {
          id: 'p1',
          date: '2026-10-20',
          supplier: 'مذخر الرشيد - السعدون',
          barcode: '5000158068942',
          medicineName: 'Augmentin 1g',
          qty: 40,
          unitPrice: 8500,
          totalAmount: 340000,
          expiryDate: '2027-08-01',
          amountPaid: 340000,
          remainingUnpaid: 0,
          createdAt: 2000,
        },
      ],
      totalAmount: 340000,
      amountPaid: 340000,
    },
    'صيدلية الحياة'
  );

  assert.equal(purchasePrint.issuerName, 'صيدلية الحياة');
  assert.equal(purchasePrint.recipientName, 'مذخر الرشيد - السعدون');
  assert.equal(purchasePrint.lines[0].qty, 40);
});
