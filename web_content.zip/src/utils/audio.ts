let audioCtx: AudioContext | null = null;
let cachedEnVoice: SpeechSynthesisVoice | null = null;
let activeFallbackAudio: HTMLAudioElement | null = null;
let ttsTimer: ReturnType<typeof setTimeout> | null = null;

export type SfxType = 'ok' | 'err' | 'tap' | 'win';

let lastTapTs = 0;

export function triggerHaptic(type: SfxType = 'tap'): void {
  try {
    if (typeof navigator === 'undefined' || typeof navigator.vibrate !== 'function') return;
    if (type === 'tap') navigator.vibrate(8);
    else if (type === 'ok') navigator.vibrate([12, 24, 16]);
    else if (type === 'err') navigator.vibrate([26, 20, 26]);
    else if (type === 'win') navigator.vibrate([16, 30, 16, 30, 28]);
  } catch {
    // Ignore on browsers without vibration support (e.g. desktop / iOS Safari)
  }
}

export function playSfx(type: SfxType, enabled: boolean): void {
  if (type === 'tap') {
    const nowMs = Date.now();
    if (nowMs - lastTapTs < 45) return;
    lastTapTs = nowMs;
  }
  triggerHaptic(type);
  if (!enabled) return;
  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    if (!audioCtx) audioCtx = new AudioContextClass();
    if (audioCtx.state === 'suspended') {
      void audioCtx.resume();
    }
    const now = audioCtx.currentTime;
    if (type === 'win') {
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
        if (!audioCtx) return;
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.connect(g);
        g.connect(audioCtx.destination);
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, now + i * 0.08);
        g.gain.setValueAtTime(0.085, now + i * 0.08);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.22);
        o.start(now + i * 0.08);
        o.stop(now + i * 0.08 + 0.23);
      });
      return;
    }

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    if (type === 'ok') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.11);
      gain.gain.setValueAtTime(0.09, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.start(now);
      osc.stop(now + 0.19);
    } else if (type === 'err') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(240, now);
      osc.frequency.exponentialRampToValueAtTime(150, now + 0.15);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.19);
      osc.start(now);
      osc.stop(now + 0.2);
    } else if (type === 'tap') {
      // Soft, pleasant crisp UI tick
      osc.type = 'sine';
      osc.frequency.setValueAtTime(640, now);
      osc.frequency.exponentialRampToValueAtTime(360, now + 0.028);
      gain.gain.setValueAtTime(0.032, now);
      gain.gain.exponentialRampToValueAtTime(0.0008, now + 0.034);
      osc.start(now);
      osc.stop(now + 0.038);
    }
  } catch {
    // Ignore audio errors on restricted autoplay environments
  }
}

function pickEnglishVoice(): SpeechSynthesisVoice | null {
  try {
    if (!('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices() || [];
    if (!voices.length) return null;
    cachedEnVoice =
      voices.find((v) => /^en[-_]US$/i.test(v.lang) && !v.localService) ||
      voices.find((v) => /^en[-_]US$/i.test(v.lang)) ||
      voices.find((v) => /^en[-_]GB$/i.test(v.lang)) ||
      voices.find((v) => /^en/i.test(v.lang)) ||
      null;
    return cachedEnVoice;
  } catch {
    return null;
  }
}

if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  pickEnglishVoice();
  try {
    window.speechSynthesis.onvoiceschanged = pickEnglishVoice;
  } catch {
    // Ignore
  }
}

async function playDictMp3Fallback(
  text: string,
  ttsRate: number,
  onToast?: (msg: string) => void
): Promise<boolean> {
  const clean = String(text || '').trim();
  if (!clean || clean.split(/\s+/).length > 2) {
    onToast?.('فعّل محرك الصوت في الجهاز لقراءة الجمل الكاملة');
    return false;
  }
  try {
    if (activeFallbackAudio) {
      activeFallbackAudio.pause();
      activeFallbackAudio = null;
    }
    const r = await fetch('/api/dictionary?word=' + encodeURIComponent(clean.toLowerCase()));
    if (r.ok) {
      const entries = (await r.json()) as Array<{ phonetics?: Array<{ audio?: string }> }>;
      const urls: string[] = [];
      if (Array.isArray(entries)) {
        entries.forEach((en) =>
          (en.phonetics || []).forEach((p) => {
            if (p && p.audio) urls.push(p.audio.startsWith('//') ? 'https:' + p.audio : p.audio);
          })
        );
      }
      const mp3 =
        urls.find((u) => /-us\.mp3$/i.test(u)) ||
        urls.find((u) => /-uk\.mp3$/i.test(u)) ||
        urls[0];
      if (mp3) {
        const audio = new Audio(mp3);
        audio.playbackRate = ttsRate || 0.92;
        activeFallbackAudio = audio;
        await audio.play();
        return true;
      }
    }
  } catch {
    // Ignore
  }
  onToast?.('تعذر النطق: تأكد من تفعيل محرك الصوت أو الاتصال بالإنترنت');
  return false;
}

export function speakEn(text: string, ttsRate = 0.92, onToast?: (msg: string) => void): void {
  const clean = String(text || '').trim();
  if (!clean) return;
  try {
    const win = window as unknown as {
      AndroidTTS?: { speak: (t: string, r: number) => void };
      _activeUtterance?: SpeechSynthesisUtterance;
    };
    if (win.AndroidTTS && typeof win.AndroidTTS.speak === 'function') {
      win.AndroidTTS.speak(clean, ttsRate || 0.92);
      return;
    }
    if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
      void playDictMp3Fallback(clean, ttsRate, onToast);
      return;
    }
    const synth = window.speechSynthesis;
    const wasBusy = synth.speaking || synth.pending;
    if (ttsTimer) clearTimeout(ttsTimer);
    try {
      synth.resume();
    } catch {
      // Ignore
    }
    if (wasBusy) {
      try {
        synth.cancel();
      } catch {
        // Ignore
      }
    }
    const voice = cachedEnVoice || pickEnglishVoice();
    ttsTimer = setTimeout(() => {
      try {
        const u = new SpeechSynthesisUtterance(clean);
        win._activeUtterance = u;
        if (voice) u.voice = voice;
        u.lang = (voice && voice.lang) || 'en-US';
        u.rate = ttsRate || 0.92;
        u.onerror = () => {
          void playDictMp3Fallback(clean, ttsRate, onToast);
        };
        synth.speak(u);
      } catch {
        void playDictMp3Fallback(clean, ttsRate, onToast);
      }
    }, wasBusy ? 75 : 15);
  } catch {
    void playDictMp3Fallback(clean, ttsRate, onToast);
  }
}

function pickVoiceForAccent(accent: 'us' | 'uk'): SpeechSynthesisVoice | null {
  try {
    if (!('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices() || [];
    if (!voices.length) return null;
    const primary = accent === 'uk' ? /^en[-_]GB$/i : /^en[-_]US$/i;
    const secondary = accent === 'uk' ? /^en[-_](GB|AU|IE)/i : /^en[-_](US|CA)/i;
    return (
      voices.find((v) => primary.test(v.lang) && !v.localService) ||
      voices.find((v) => primary.test(v.lang)) ||
      voices.find((v) => secondary.test(v.lang)) ||
      voices.find((v) => /^en/i.test(v.lang)) ||
      null
    );
  } catch {
    return null;
  }
}

export function playAccentAudio(
  text: string,
  accent: 'us' | 'uk',
  mp3Url?: string,
  ttsRate = 0.92,
  onToast?: (msg: string) => void
): void {
  const clean = String(text || '').trim();
  if (!clean) return;

  // Prefer authentic dictionary studio MP3 for US/UK when available
  if (mp3Url && /^https?:\/\//i.test(mp3Url)) {
    try {
      if (activeFallbackAudio) {
        activeFallbackAudio.pause();
        activeFallbackAudio = null;
      }
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      const audio = new Audio(mp3Url);
      audio.playbackRate = Math.min(1.25, Math.max(0.7, ttsRate || 0.95));
      activeFallbackAudio = audio;
      void audio.play().catch(() => {
        speakWithAccentTts(clean, accent, ttsRate, onToast);
      });
      return;
    } catch {
      // Fall through to accent TTS
    }
  }

  speakWithAccentTts(clean, accent, ttsRate, onToast);
}

function speakWithAccentTts(
  clean: string,
  accent: 'us' | 'uk',
  ttsRate: number,
  onToast?: (msg: string) => void
): void {
  try {
    if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
      void playDictMp3Fallback(clean, ttsRate, onToast);
      return;
    }
    const synth = window.speechSynthesis;
    const wasBusy = synth.speaking || synth.pending;
    if (ttsTimer) clearTimeout(ttsTimer);
    try {
      synth.resume();
    } catch {
      // Ignore
    }
    if (wasBusy) {
      try {
        synth.cancel();
      } catch {
        // Ignore
      }
    }
    const voice = pickVoiceForAccent(accent);
    ttsTimer = setTimeout(() => {
      try {
        const u = new SpeechSynthesisUtterance(clean);
        if (voice) u.voice = voice;
        u.lang = accent === 'uk' ? 'en-GB' : 'en-US';
        u.rate = ttsRate || 0.92;
        u.onerror = () => {
          void playDictMp3Fallback(clean, ttsRate, onToast);
        };
        synth.speak(u);
      } catch {
        void playDictMp3Fallback(clean, ttsRate, onToast);
      }
    }, wasBusy ? 65 : 15);
  } catch {
    void playDictMp3Fallback(clean, ttsRate, onToast);
  }
}

