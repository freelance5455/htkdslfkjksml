import { TimerChimeStyle, TimerHapticStyle } from '../types';

// Web Audio API Synthesizer for workout cues & haptics

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playCountdownTick() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(450, ctx.currentTime + 0.08);

    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.08);
  } catch {
    // Audio context may be restricted before user gesture
  }
}

export function playTimerFinishSound(style: TimerChimeStyle = 'singing-bowl') {
  try {
    if (style === 'silent') return;
    const ctx = getAudioContext();
    if (!ctx) return;

    const playTone = (
      freq: number,
      startDelay: number,
      duration: number,
      oscType: OscillatorType = 'triangle',
      peakGain = 0.22
    ) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = oscType;
      osc.frequency.setValueAtTime(freq, ctx.currentTime + startDelay);

      gain.gain.setValueAtTime(peakGain, ctx.currentTime + startDelay);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + startDelay + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + startDelay);
      osc.stop(ctx.currentTime + startDelay + duration);
    };

    if (style === 'singing-bowl') {
      // Subtle harmonic Zen bell chime (528Hz fundamental + 792Hz fifth + 1056Hz shimmer)
      playTone(528, 0, 0.95, 'sine', 0.22);
      playTone(792, 0.04, 0.75, 'sine', 0.12);
      playTone(1056, 0.08, 0.55, 'triangle', 0.08);
    } else if (style === 'double-pulse') {
      // Crisp two-tap acoustic chime
      playTone(659.25, 0, 0.16, 'sine', 0.22);
      playTone(880, 0.18, 0.28, 'sine', 0.24);
    } else if (style === 'crisptick') {
      // Minimalist studio woodblock / focus click + subtle high tone
      playTone(800, 0, 0.07, 'triangle', 0.25);
      playTone(1200, 0.08, 0.12, 'sine', 0.2);
    } else {
      // 'power-chord': Ascending power chime: C5 -> E5 -> G5 -> C6
      playTone(523.25, 0, 0.15, 'triangle', 0.24);
      playTone(659.25, 0.12, 0.15, 'triangle', 0.24);
      playTone(783.99, 0.24, 0.15, 'triangle', 0.24);
      playTone(1046.5, 0.36, 0.4, 'triangle', 0.25);
    }
  } catch {
    // Ignored
  }
}

export function triggerTimerZeroHaptic(style: TimerHapticStyle = 'subtle-pulse') {
  if (style === 'off') return;
  if (style === 'subtle-pulse') {
    triggerHaptic([65, 55, 110]);
  } else if (style === 'double-tap') {
    triggerHaptic([45, 70, 45]);
  } else if (style === 'heartbeat') {
    triggerHaptic([55, 75, 115, 160, 65]);
  }
}

export function playSetCompleteSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12);

    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.12);
  } catch {
    // Ignored
  }
}

export function playCelebrationSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const notes = [440, 554.37, 659.25, 880];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.1);
      gain.gain.setValueAtTime(0.2, ctx.currentTime + idx * 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + idx * 0.1);
      osc.stop(ctx.currentTime + idx * 0.1 + 0.35);
    });
  } catch {
    // Ignored
  }
}

/**
 * Crisp tactile bubble/badge pop sound for UI pop-ins, badges, modals, and set variations
 */
export function playPopSound(variant: 'soft' | 'bright' | 'overload' | 'habit' | 'theme-light' | 'theme-dark' = 'bright') {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (variant === 'soft') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(640, now + 0.055);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.06);
    } else if (variant === 'habit') {
      // Crisp droplet pop + harmonic sparkle
      osc.type = 'sine';
      osc.frequency.setValueAtTime(420, now);
      osc.frequency.exponentialRampToValueAtTime(980, now + 0.085);
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.09);

      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(1318.5, now + 0.05);
      gain2.gain.setValueAtTime(0.1, now + 0.05);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.05);
      osc2.stop(now + 0.16);
    } else if (variant === 'overload') {
      // Double ascending power pop for +Reps / +Sets / Overload
      [523.25, 783.99].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'triangle';
        o.frequency.setValueAtTime(freq * 0.85, now + i * 0.055);
        o.frequency.exponentialRampToValueAtTime(freq, now + i * 0.055 + 0.07);
        g.gain.setValueAtTime(0.16, now + i * 0.055);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.055 + 0.08);
        o.connect(g);
        g.connect(ctx.destination);
        o.start(now + i * 0.055);
        o.stop(now + i * 0.055 + 0.08);
      });
    } else if (variant === 'theme-light') {
      // Sunny upward pop
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.09);
      gain.gain.setValueAtTime(0.14, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (variant === 'theme-dark') {
      // Cool nocturnal pop
      osc.type = 'sine';
      osc.frequency.setValueAtTime(659.25, now);
      osc.frequency.exponentialRampToValueAtTime(392, now + 0.09);
      gain.gain.setValueAtTime(0.14, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.1);
    } else {
      // 'bright' default pop
      osc.type = 'sine';
      osc.frequency.setValueAtTime(380, now);
      osc.frequency.exponentialRampToValueAtTime(760, now + 0.065);
      gain.gain.setValueAtTime(0.16, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.07);
    }
  } catch {
    // Ignored
  }
}

/**
 * Celebratory confetti burst & Level-Up pop fanfare
 */
export function playConfettiPopSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Initial crisp pop burst
    playPopSound('bright');

    // Sparkling chord arpeggio: C5 -> E5 -> G5 -> B5 -> C6
    const chord = [523.25, 659.25, 783.99, 987.77, 1046.5];
    chord.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + 0.04 + idx * 0.065);
      gain.gain.setValueAtTime(0.18, now + 0.04 + idx * 0.065);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04 + idx * 0.065 + 0.32);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + 0.04 + idx * 0.065);
      osc.stop(now + 0.04 + idx * 0.065 + 0.32);
    });
  } catch {
    // Ignored
  }
}

export function triggerHaptic(pattern: number | number[] = 50) {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignored
    }
  }
}
