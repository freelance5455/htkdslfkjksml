// Web Audio API Chimes & Screen Wake Lock Manager

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Play a futuristic pleasant wake-word chime when "Hey Nova" is heard
 */
export function playWakeChime(): void {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    // Dual-tone harmonic chime (C6 -> G6)
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sine';
    osc2.type = 'triangle';

    osc1.frequency.setValueAtTime(1046.5, now); // C6
    osc1.frequency.exponentialRampToValueAtTime(1567.98, now + 0.18); // G6

    osc2.frequency.setValueAtTime(523.25, now); // C5
    osc2.frequency.exponentialRampToValueAtTime(783.99, now + 0.18); // G5

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.5);
    osc2.stop(now + 0.5);
  } catch (e) {
    console.debug('Chime playback error:', e);
  }
}

/**
 * Play a confirmation beep when an action executes (e.g. Opening YouTube)
 */
export function playSuccessChime(): void {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, now); // A5
    osc.frequency.setValueAtTime(1760, now + 0.09); // A6

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.3);
  } catch (e) {
    console.debug('Success chime error:', e);
  }
}

// Screen Wake Lock Handler
let wakeLockSentinel: unknown = null;

export async function requestScreenWakeLock(): Promise<boolean> {
  try {
    if ('wakeLock' in navigator && navigator.wakeLock) {
      wakeLockSentinel = await (navigator.wakeLock as { request: (type: string) => Promise<unknown> }).request('screen');
      console.log('Screen Wake Lock acquired: Phone display will stay awake during voice mode.');
      return true;
    }
  } catch (err) {
    console.warn('Wake Lock request failed or not supported:', err);
  }
  return false;
}

export async function releaseScreenWakeLock(): Promise<void> {
  try {
    if (wakeLockSentinel && typeof (wakeLockSentinel as { release?: () => Promise<void> }).release === 'function') {
      await (wakeLockSentinel as { release: () => Promise<void> }).release();
      wakeLockSentinel = null;
      console.log('Screen Wake Lock released.');
    }
  } catch (err) {
    console.warn('Error releasing wake lock:', err);
  }
}
