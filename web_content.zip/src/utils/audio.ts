/**
 * Lightweight mechanical calculator click sounds using Web Audio API
 * No external audio files or network requests required.
 */

class AudioService {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public playClick(type: 'number' | 'operator' | 'action' | 'equals') {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      let freq = 600;
      let duration = 0.025;
      let peakGain = 0.08;

      if (type === 'number') {
        freq = 750;
        duration = 0.02;
        peakGain = 0.05;
        osc.type = 'sine';
      } else if (type === 'operator') {
        freq = 950;
        duration = 0.03;
        peakGain = 0.07;
        osc.type = 'triangle';
      } else if (type === 'action') {
        freq = 450;
        duration = 0.035;
        peakGain = 0.06;
        osc.type = 'sine';
      } else if (type === 'equals') {
        freq = 1100;
        duration = 0.05;
        peakGain = 0.1;
        osc.type = 'triangle';
      }

      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.5, now + duration);

      gain.gain.setValueAtTime(peakGain, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + duration);
    } catch {
      // AudioContext might be blocked until user gesture, safely ignore
    }
  }
}

export const soundFx = new AudioService();
