/**
 * Synthesized Web Audio API sound effects and Fantasy RPG Background Music engine.
 * Completely self-contained, responsive, zero-external-assets, and hermetic.
 * Theme: "Echoes of the Mana Spire" - Medieval Celtic Lute, Ethereal Ambient Pad, and Arcane Chimes.
 */

// Note frequencies (Hz) for authentic fantasy tunings
const NOTE_FREQS: Record<string, number> = {
  D2: 73.42,
  E2: 82.41,
  F2: 87.31,
  G2: 98.0,
  A2: 110.0,
  Bb2: 116.54,
  C3: 130.81,
  D3: 146.83,
  E3: 164.81,
  F3: 174.61,
  G3: 196.0,
  A3: 220.0,
  Bb3: 233.08,
  C4: 261.63,
  D4: 293.66,
  E4: 329.63,
  F4: 349.23,
  G4: 392.0,
  A4: 440.0,
  Bb4: 466.16,
  C5: 523.25,
  D5: 587.33,
  E5: 659.25,
  F5: 698.46,
  G5: 783.99,
  A5: 880.0,
  Bb5: 932.33,
  C6: 1046.5,
  D6: 1174.66,
};

// 32-beat Fantasy RPG Theme Composition ("Echoes of the Mana Spire")
// Tempo: 72 BPM
interface MelodyNote {
  note: string;
  duration: number; // in beats
}

interface StepData {
  bassNote?: string;
  padChord?: string[];
  melodyNotes?: MelodyNote[];
  chimeNote?: string;
}

// 32 quarter-note steps (each step = 1 beat, subdivided as needed)
const FANTASY_RPG_THEME: StepData[] = [
  // --- Section 1: D Minor (The Whispering Glade) ---
  {
    bassNote: 'D2',
    padChord: ['D3', 'F3', 'A3'],
    melodyNotes: [{ note: 'D4', duration: 0.9 }],
    chimeNote: 'D5',
  },
  { melodyNotes: [{ note: 'F4', duration: 0.8 }] },
  { melodyNotes: [{ note: 'A4', duration: 0.9 }] },
  { melodyNotes: [{ note: 'D5', duration: 0.9 }] },

  // --- Section 2: Bb Major 7 (Ancient Guildhall) ---
  {
    bassNote: 'Bb2',
    padChord: ['D3', 'F3', 'Bb3'],
    melodyNotes: [{ note: 'C5', duration: 1.2 }],
    chimeNote: 'F5',
  },
  { melodyNotes: [{ note: 'Bb4', duration: 0.8 }] },
  { melodyNotes: [{ note: 'A4', duration: 0.9 }] },
  { melodyNotes: [{ note: 'F4', duration: 0.8 }] },

  // --- Section 3: F Major / C Major (The Sunlit Spires) ---
  {
    bassNote: 'F2',
    padChord: ['C3', 'F3', 'A3'],
    melodyNotes: [{ note: 'G4', duration: 1.2 }],
  },
  { melodyNotes: [{ note: 'A4', duration: 0.8 }] },
  {
    bassNote: 'C3',
    padChord: ['E3', 'G3', 'C4'],
    melodyNotes: [{ note: 'C5', duration: 1.0 }],
    chimeNote: 'E5',
  },
  { melodyNotes: [{ note: 'E4', duration: 0.8 }] },

  // --- Section 4: A Minor (Runes of Old) ---
  {
    bassNote: 'A2',
    padChord: ['C3', 'E3', 'A3'],
    melodyNotes: [{ note: 'D4', duration: 0.8 }],
  },
  { melodyNotes: [{ note: 'E4', duration: 0.8 }] },
  { melodyNotes: [{ note: 'F4', duration: 0.9 }] },
  { melodyNotes: [{ note: 'E4', duration: 0.8 }] },

  // --- Section 5: D Minor (Arcane Invocations) ---
  {
    bassNote: 'D2',
    padChord: ['D3', 'F3', 'A3'],
    melodyNotes: [{ note: 'F4', duration: 1.0 }],
    chimeNote: 'A5',
  },
  { melodyNotes: [{ note: 'A4', duration: 0.8 }] },
  { melodyNotes: [{ note: 'D5', duration: 1.2 }] },
  { melodyNotes: [{ note: 'E5', duration: 0.8 }] },

  // --- Section 6: G Minor 7 (Tavern Hearth) ---
  {
    bassNote: 'G2',
    padChord: ['D3', 'G3', 'Bb3'],
    melodyNotes: [{ note: 'F5', duration: 1.0 }],
    chimeNote: 'D6',
  },
  { melodyNotes: [{ note: 'D5', duration: 0.8 }] },
  { melodyNotes: [{ note: 'Bb4', duration: 0.9 }] },
  { melodyNotes: [{ note: 'G4', duration: 0.8 }] },

  // --- Section 7: C Major -> A Minor (Celestial Archon Light) ---
  {
    bassNote: 'C3',
    padChord: ['E3', 'G3', 'C4'],
    melodyNotes: [{ note: 'A4', duration: 1.2 }],
    chimeNote: 'C6',
  },
  { melodyNotes: [{ note: 'G4', duration: 0.8 }] },
  {
    bassNote: 'A2',
    padChord: ['C3', 'E3', 'A3'],
    melodyNotes: [{ note: 'F4', duration: 1.0 }],
  },
  { melodyNotes: [{ note: 'E4', duration: 0.8 }] },

  // --- Section 8: Cadence back to Dm (The Sovereign's Ascent) ---
  {
    bassNote: 'D2',
    padChord: ['D3', 'F3', 'A3'],
    melodyNotes: [{ note: 'D4', duration: 1.6 }],
    chimeNote: 'D5',
  },
  { melodyNotes: [{ note: 'A4', duration: 0.8 }] },
  { melodyNotes: [{ note: 'F4', duration: 0.8 }] },
  { melodyNotes: [{ note: 'E4', duration: 0.9 }] },
];

const BPM = 72;
const SEC_PER_BEAT = 60 / BPM;

class SoundEngine {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;
  public volume: number = 0.5;

  // Background Music state
  public musicEnabled: boolean = true;
  public musicVolume: number = 0.35;
  private musicMasterGain: GainNode | null = null;
  private isBgmPlaying: boolean = false;
  private currentStepIndex: number = 0;
  private nextStepTime: number = 0;
  private schedulerTimer: ReturnType<typeof setInterval> | null = null;
  private onPlayingStateChange?: (isPlaying: boolean) => void;

  public initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
  }

  /**
   * Resumes AudioContext safely upon user gesture
   */
  public async ensureActive(): Promise<boolean> {
    this.initCtx();
    if (!this.ctx) return false;

    if (this.ctx.state === 'suspended') {
      try {
        await this.ctx.resume();
      } catch {
        return false;
      }
    }

    if (this.ctx && !this.musicMasterGain) {
      this.musicMasterGain = this.ctx.createGain();
      this.musicMasterGain.gain.setValueAtTime(this.musicVolume * 0.45, this.ctx.currentTime);
      this.musicMasterGain.connect(this.ctx.destination);
    }

    // If music should be playing but was waiting for user gesture, kick off clock
    if (this.musicEnabled && !this.isBgmPlaying) {
      this.startBgm();
    }

    return this.ctx.state === 'running';
  }

  // --- Background Music Control ---

  public startBgm() {
    if (!this.musicEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    if (!this.musicMasterGain) {
      this.musicMasterGain = this.ctx.createGain();
      this.musicMasterGain.gain.setValueAtTime(this.musicVolume * 0.45, this.ctx.currentTime);
      this.musicMasterGain.connect(this.ctx.destination);
    } else {
      // Restore volume if faded
      this.musicMasterGain.gain.cancelScheduledValues(this.ctx.currentTime);
      this.musicMasterGain.gain.setValueAtTime(this.musicVolume * 0.45, this.ctx.currentTime);
    }

    if (this.isBgmPlaying && this.schedulerTimer) {
      return;
    }

    this.isBgmPlaying = true;
    this.currentStepIndex = 0;
    this.nextStepTime = this.ctx.currentTime + 0.08;

    if (this.onPlayingStateChange) {
      this.onPlayingStateChange(true);
    }

    // Precise lookahead clock scheduler (50ms interval, 300ms lookahead)
    if (this.schedulerTimer) clearInterval(this.schedulerTimer);
    this.schedulerTimer = setInterval(() => {
      this.clockTick();
    }, 50);

    // Initial immediate tick
    this.clockTick();
  }

  public stopBgm() {
    this.isBgmPlaying = false;
    if (this.schedulerTimer) {
      clearInterval(this.schedulerTimer);
      this.schedulerTimer = null;
    }

    if (this.onPlayingStateChange) {
      this.onPlayingStateChange(false);
    }

    if (this.musicMasterGain && this.ctx) {
      const now = this.ctx.currentTime;
      this.musicMasterGain.gain.cancelScheduledValues(now);
      this.musicMasterGain.gain.setValueAtTime(this.musicMasterGain.gain.value, now);
      this.musicMasterGain.gain.linearRampToValueAtTime(0.0001, now + 0.25);
    }
  }

  public toggleMusic(): boolean {
    this.musicEnabled = !this.musicEnabled;
    if (this.musicEnabled) {
      this.ensureActive();
      this.startBgm();
    } else {
      this.stopBgm();
    }
    return this.musicEnabled;
  }

  public setMusicVolume(vol: number) {
    this.musicVolume = Math.max(0, Math.min(1, vol));
    if (this.musicMasterGain && this.ctx) {
      this.musicMasterGain.gain.cancelScheduledValues(this.ctx.currentTime);
      this.musicMasterGain.gain.setValueAtTime(this.musicVolume * 0.45, this.ctx.currentTime);
    }
  }

  public isMusicPlaying(): boolean {
    return this.isBgmPlaying && this.ctx?.state === 'running';
  }

  private clockTick() {
    if (!this.ctx || !this.musicMasterGain || !this.isBgmPlaying) return;

    if (this.ctx.state === 'suspended') {
      return;
    }

    const lookAheadTime = 0.35; // 350ms buffer
    const currentTime = this.ctx.currentTime;

    // Guard against time skips (e.g. background tab sleep)
    if (this.nextStepTime < currentTime) {
      this.nextStepTime = currentTime + 0.05;
    }

    while (this.nextStepTime < currentTime + lookAheadTime) {
      const step = FANTASY_RPG_THEME[this.currentStepIndex];
      this.scheduleStep(step, this.nextStepTime);

      this.nextStepTime += SEC_PER_BEAT;
      this.currentStepIndex = (this.currentStepIndex + 1) % FANTASY_RPG_THEME.length;
    }
  }

  private scheduleStep(step: StepData, time: number) {
    if (!this.ctx || !this.musicMasterGain) return;

    // 1. Plucked Celtic Lute / Harp melody
    if (step.melodyNotes) {
      step.melodyNotes.forEach((m) => {
        const freq = NOTE_FREQS[m.note];
        if (freq) {
          this.playCelticLute(freq, time, m.duration * SEC_PER_BEAT);
        }
      });
    }

    // 2. Warm ambient ethereal pad chord
    if (step.padChord) {
      this.playEtherealPad(step.padChord, time, SEC_PER_BEAT * 4);
    }

    // 3. Subterranean deep bass drone
    if (step.bassNote) {
      const bassFreq = NOTE_FREQS[step.bassNote];
      if (bassFreq) {
        this.playMedievalBass(bassFreq, time, SEC_PER_BEAT * 3.8);
      }
    }

    // 4. Starlight chime / celestial sparkle
    if (step.chimeNote) {
      const chimeFreq = NOTE_FREQS[step.chimeNote];
      if (chimeFreq) {
        this.playArcaneChime(chimeFreq, time);
      }
    }
  }

  /**
   * Synthesizes a plucked Celtic Lute / Harp string tone
   */
  private playCelticLute(freq: number, startTime: number, duration: number) {
    if (!this.ctx || !this.musicMasterGain) return;

    try {
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const noteGain = this.ctx.createGain();

      // Osc 1: Warm wooden triangle fundamental
      osc1.type = 'triangle';
      osc1.frequency.setValueAtTime(freq, startTime);

      // Osc 2: Gentle crystalline octave overtone
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(freq * 2, startTime);

      // Pluck filter envelope
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(2400, startTime);
      filter.frequency.exponentialRampToValueAtTime(650, startTime + Math.min(duration, 0.4));
      filter.Q.setValueAtTime(1.8, startTime);

      // Pluck amp envelope: instant snappy attack + musical ring
      noteGain.gain.setValueAtTime(0.0001, startTime);
      noteGain.gain.linearRampToValueAtTime(0.24, startTime + 0.012);
      noteGain.gain.exponentialRampToValueAtTime(0.001, startTime + Math.max(duration, 0.3));

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(noteGain);
      noteGain.connect(this.musicMasterGain);

      const stopTime = startTime + Math.max(duration, 0.3) + 0.05;
      osc1.start(startTime);
      osc2.start(startTime);
      osc1.stop(stopTime);
      osc2.stop(stopTime);
    } catch {}
  }

  /**
   * Warm subterranean drone bass
   */
  private playMedievalBass(freq: number, startTime: number, duration: number) {
    if (!this.ctx || !this.musicMasterGain) return;

    try {
      const osc = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(240, startTime);

      gain.gain.setValueAtTime(0.0001, startTime);
      gain.gain.linearRampToValueAtTime(0.2, startTime + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.musicMasterGain);

      osc.start(startTime);
      osc.stop(startTime + duration + 0.05);
    } catch {}
  }

  /**
   * Celestial ethereal ambient choir pad
   */
  private playEtherealPad(notes: string[], startTime: number, duration: number) {
    if (!this.ctx || !this.musicMasterGain) return;

    notes.forEach((noteName, idx) => {
      const freq = NOTE_FREQS[noteName];
      if (!freq) return;

      try {
        const osc = this.ctx!.createOscillator();
        const filter = this.ctx!.createBiquadFilter();
        const gain = this.ctx!.createGain();

        osc.type = 'sine';
        // Subtle micro-detune for lush chorus warmth
        const detune = idx % 2 === 0 ? 3.5 : -3.5;
        osc.frequency.setValueAtTime(freq, startTime);
        osc.detune.setValueAtTime(detune, startTime);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(550, startTime);

        // Soft ambient swell and gentle breath release
        gain.gain.setValueAtTime(0.0001, startTime);
        gain.gain.linearRampToValueAtTime(0.045, startTime + 0.8);
        gain.gain.setValueAtTime(0.045, startTime + duration - 0.7);
        gain.gain.linearRampToValueAtTime(0.0001, startTime + duration);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicMasterGain!);

        osc.start(startTime);
        osc.stop(startTime + duration + 0.1);
      } catch {}
    });
  }

  /**
   * Arcane crystalline bell chime (mana particle sparkle)
   */
  private playArcaneChime(freq: number, startTime: number) {
    if (!this.ctx || !this.musicMasterGain) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.0001, startTime);
      gain.gain.linearRampToValueAtTime(0.08, startTime + 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.8);

      osc.connect(gain);
      gain.connect(this.musicMasterGain);

      osc.start(startTime);
      osc.stop(startTime + 0.85);
    } catch {}
  }

  // --- Sound Effects System ---

  public playCoin() {
    if (!this.enabled) return;
    this.ensureActive();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(987.77, now); // B5
      osc.frequency.exponentialRampToValueAtTime(1318.51, now + 0.08); // E6

      gain.gain.setValueAtTime(this.volume * 0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.12);
    } catch {}
  }

  public playOrbClick() {
    if (!this.enabled) return;
    this.ensureActive();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.exponentialRampToValueAtTime(1046.5, now + 0.1); // C6

      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(659.25, now); // E5
      osc2.frequency.exponentialRampToValueAtTime(1318.51, now + 0.1);

      gain.gain.setValueAtTime(this.volume * 0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc2.start(now);
      osc.stop(now + 0.15);
      osc2.stop(now + 0.15);
    } catch {}
  }

  public playMultiTouch(fingerCount: number) {
    if (!this.enabled) return;
    this.ensureActive();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const baseFreqs = [523.25, 659.25, 783.99, 1046.5, 1318.51];
      const freqs = baseFreqs.slice(0, Math.min(fingerCount + 1, baseFreqs.length));

      freqs.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.5, now + 0.12);

        gain.gain.setValueAtTime(this.volume * 0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(now);
        osc.stop(now + 0.16);
      });
    } catch {}
  }

  public playBuy() {
    if (!this.enabled) return;
    this.ensureActive();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.06);

      gain.gain.setValueAtTime(this.volume * 0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.09);
    } catch {}
  }

  public playMilestone() {
    if (!this.enabled) return;
    this.ensureActive();
    if (!this.ctx) return;

    try {
      const notes = [523.25, 659.25, 783.99, 1046.5];
      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const start = this.ctx!.currentTime + idx * 0.06;

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, start);

        gain.gain.setValueAtTime(this.volume * 0.3, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.18);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(start);
        osc.stop(start + 0.2);
      });
    } catch {}
  }

  public playManagerHire() {
    if (!this.enabled) return;
    this.ensureActive();
    if (!this.ctx) return;

    try {
      const notes = [293.66, 392.0, 493.88, 587.33];
      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const start = this.ctx!.currentTime + idx * 0.08;

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, start);

        gain.gain.setValueAtTime(this.volume * 0.35, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.25);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(start);
        osc.stop(start + 0.3);
      });
    } catch {}
  }

  public playAscension() {
    if (!this.enabled) return;
    this.ensureActive();
    if (!this.ctx) return;

    try {
      const freqs = [220, 277.18, 329.63, 440, 554.37, 659.25, 880];
      freqs.forEach((freq) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const now = this.ctx!.currentTime;

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(this.volume * 0.15, now + 0.2);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.8);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.start(now);
        osc.stop(now + 1.8);
      });
    } catch {}
  }

  public playFrenzy() {
    if (!this.enabled) return;
    this.ensureActive();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.3);

      gain.gain.setValueAtTime(this.volume * 0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.35);
    } catch {}
  }
}

export const sound = new SoundEngine();
