// Audio utilities for Sosiska AI: Text-to-Speech and Speech-to-Text

export function speakText(text: string, onEnd?: () => void, onError?: () => void): () => void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onError?.();
    return () => {};
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  // Strip code blocks and markdown symbols for clean speech
  const cleanedText = text
    .replace(/```[\s\S]*?```/g, ' [Блок кода опущен] ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/[*#_~>]/g, '')
    .trim();

  if (!cleanedText) {
    onEnd?.();
    return () => {};
  }

  const utterance = new SpeechSynthesisUtterance(cleanedText);
  utterance.rate = 1.05;
  utterance.pitch = 1.0;

  // Try to find Russian voice
  const voices = window.speechSynthesis.getVoices();
  const ruVoice = voices.find((v) => v.lang.startsWith('ru'));
  if (ruVoice) {
    utterance.voice = ruVoice;
  }
  utterance.lang = 'ru-RU';

  utterance.onend = () => {
    onEnd?.();
  };

  utterance.onerror = () => {
    onError?.();
  };

  window.speechSynthesis.speak(utterance);

  // Return cancel function
  return () => {
    window.speechSynthesis.cancel();
    onEnd?.();
  };
}

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
}

export function createSpeechRecognizer(
  onResult: (transcript: string) => void,
  onError: (error: string) => void,
  onEnd: () => void
) {
  if (!isSpeechRecognitionSupported()) {
    onError('Распознавание речи не поддерживается в этом браузере');
    return null;
  }

  const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  const recognition = new SpeechRecognition();

  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = 'ru-RU';

  recognition.onresult = (event: any) => {
    let transcript = '';
    for (let i = event.resultIndex; i < event.results.length; ++i) {
      transcript += event.results[i][0].transcript;
    }
    onResult(transcript);
  };

  recognition.onerror = (event: any) => {
    console.warn('Speech recognition error:', event.error);
    onError(event.error);
  };

  recognition.onend = () => {
    onEnd();
  };

  return recognition;
}
