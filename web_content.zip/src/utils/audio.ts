// Web Audio API Multi-Instrument Synthesizer for rhythmic, high-energy puzzle game BGM & loud, crisp SFX

class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private sfxGain: GainNode | null = null;
  private bgmGain: GainNode | null = null;

  private isSoundEnabled = true;
  private isMusicEnabled = true;
  private isHapticsEnabled = true;
  private soundVolume = 1.0; // 0.0 to 1.0
  private musicVolume = 0.9; // 0.0 to 1.0

  private pourOsc: OscillatorNode | null = null;
  private pourLfo: OscillatorNode | null = null;
  private pourGain: GainNode | null = null;

  // Background Music Sequencer State
  private bgmInterval: number | null = null;
  private isBgmPlaying = false;
  private wasBgmPlayingBeforeBackground = false;
  private isSuspendedForBackground = false;
  private bgmStep = 0;
  private nextStepTime = 0;

  constructor() {
    if (typeof window !== 'undefined' && typeof document !== 'undefined') {
      // Automatic detection when user locks phone, minimizes browser, or switches apps
      const handleVisibilityChange = () => {
        if (document.hidden || document.visibilityState === 'hidden') {
          this.handleBackgroundPause();
        } else if (document.visibilityState === 'visible') {
          this.handleForegroundResume();
        }
      };

      const handlePageHide = () => {
        this.handleBackgroundPause();
      };

      const handleWindowBlur = () => {
        // If window lost focus, verify if page is hidden
        if (document.hidden || document.visibilityState === 'hidden') {
          this.handleBackgroundPause();
        }
      };

      const handleWindowFocus = () => {
        if (document.visibilityState === 'visible') {
          this.handleForegroundResume();
        }
      };

      document.addEventListener('visibilitychange', handleVisibilityChange);
      window.addEventListener('pagehide', handlePageHide);
      window.addEventListener('blur', handleWindowBlur);
      window.addEventListener('focus', handleWindowFocus);
      window.addEventListener('beforeunload', handlePageHide);
    }
  }

  public handleBackgroundPause() {
    this.isSuspendedForBackground = true;
    this.stopPour();

    if (this.isBgmPlaying) {
      this.wasBgmPlayingBeforeBackground = true;
      this.stopBgm();
    }

    if (this.ctx && this.ctx.state === 'running') {
      this.ctx.suspend().catch(() => {});
    }
  }

  public handleForegroundResume() {
    this.isSuspendedForBackground = false;

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    if (this.isMusicEnabled && (this.wasBgmPlayingBeforeBackground || !this.isBgmPlaying)) {
      this.wasBgmPlayingBeforeBackground = false;
      this.startBgm();
    }
  }

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtxClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtxClass) {
        this.ctx = new AudioCtxClass();
      }
    }

    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }

      // Initialize Master Audio Routing Chain if not created
      if (!this.masterGain) {
        // Dynamics Compressor to boost loudness and prevent clipping
        this.compressor = this.ctx.createDynamicsCompressor();
        this.compressor.threshold.setValueAtTime(-14, this.ctx.currentTime);
        this.compressor.knee.setValueAtTime(8, this.ctx.currentTime);
        this.compressor.ratio.setValueAtTime(4, this.ctx.currentTime);
        this.compressor.attack.setValueAtTime(0.003, this.ctx.currentTime);
        this.compressor.release.setValueAtTime(0.12, this.ctx.currentTime);

        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(1.4, this.ctx.currentTime); // High-volume boost

        this.sfxGain = this.ctx.createGain();
        this.sfxGain.gain.setValueAtTime(this.isSoundEnabled ? this.soundVolume * 1.5 : 0, this.ctx.currentTime);

        this.bgmGain = this.ctx.createGain();
        this.bgmGain.gain.setValueAtTime(this.isMusicEnabled ? this.musicVolume * 1.3 : 0, this.ctx.currentTime);

        // Connections: sfx -> compressor, bgm -> compressor -> masterGain -> destination
        this.sfxGain.connect(this.compressor);
        this.bgmGain.connect(this.compressor);
        this.compressor.connect(this.masterGain);
        this.masterGain.connect(this.ctx.destination);
      }
    }
  }

  public setSoundEnabled(enabled: boolean) {
    this.isSoundEnabled = enabled;
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setValueAtTime(
        enabled ? this.soundVolume * 1.5 : 0,
        this.ctx.currentTime
      );
    }
  }

  public setMusicEnabled(enabled: boolean) {
    this.isMusicEnabled = enabled;
    if (this.bgmGain && this.ctx) {
      this.bgmGain.gain.setValueAtTime(
        enabled ? this.musicVolume * 1.3 : 0,
        this.ctx.currentTime
      );
    }
    if (enabled) {
      if (!this.isBgmPlaying) {
        this.startBgm();
      }
    } else {
      this.stopBgm();
    }
  }

  public setSoundVolume(volume: number) {
    this.soundVolume = Math.max(0, Math.min(1, volume));
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setValueAtTime(
        this.isSoundEnabled ? this.soundVolume * 1.5 : 0,
        this.ctx.currentTime
      );
    }
  }

  public setMusicVolume(volume: number) {
    this.musicVolume = Math.max(0, Math.min(1, volume));
    if (this.bgmGain && this.ctx) {
      this.bgmGain.gain.setValueAtTime(
        this.isMusicEnabled ? this.musicVolume * 1.3 : 0,
        this.ctx.currentTime
      );
    }
  }

  public setHapticsEnabled(enabled: boolean) {
    this.isHapticsEnabled = enabled;
  }

  public vibrate(pattern: number | number[] = 15) {
    if (!this.isHapticsEnabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      navigator.vibrate(pattern);
    } catch {
      // ignore
    }
  }

  // =========================================================================
  // MULTI-INSTRUMENT ORCHESTRATED GAME BGM ENGINE (UPBEAT 126 BPM)
  // Instruments: Kick, Snare, Hi-Hats, Bongos, Shakers, Slap Bass,
  //              Electric Rhodes Keys, Marimba Lead, Flute Harmony, Chimes
  // =========================================================================
  public startBgm() {
    if (!this.isMusicEnabled || this.isBgmPlaying || this.isSuspendedForBackground) return;
    this.initCtx();
    if (!this.ctx || !this.bgmGain) return;

    this.isBgmPlaying = true;
    this.bgmStep = 0;

    // 126 BPM -> 1 beat = 0.476s, 1 sixteenth-note step = ~0.119s
    const stepDuration = 0.119;
    this.nextStepTime = this.ctx.currentTime + 0.05;

    // 64-step (4-bar, 16 beats) Chord Progression:
    // Bar 1 (0-15):  C Maj9   (Root C3 = 130.81Hz)
    // Bar 2 (16-31): A min9   (Root A2 = 110.00Hz)
    // Bar 3 (32-47): F Maj9   (Root F2 = 87.31Hz)
    // Bar 4 (48-63): G9 / G13 (Root G2 = 98.00Hz)
    const chords = [
      {
        bass: 130.81,
        keys: [261.63, 329.63, 392.0, 493.88, 587.33], // C4, E4, G4, B4, D5 (Cmaj9)
        arpeggio: [523.25, 659.25, 783.99, 987.77, 1046.5],
      },
      {
        bass: 110.0,
        keys: [220.0, 261.63, 329.63, 392.0, 493.88],  // A3, C4, E4, G4, B4 (Amin9)
        arpeggio: [440.0, 523.25, 659.25, 783.99, 880.0],
      },
      {
        bass: 87.31,
        keys: [174.61, 220.0, 261.63, 329.63, 392.0],  // F3, A3, C4, E4, G4 (Fmaj9)
        arpeggio: [349.23, 440.0, 523.25, 659.25, 698.46],
      },
      {
        bass: 98.0,
        keys: [196.0, 246.94, 293.66, 349.23, 440.0],  // G3, B3, D4, F4, A4 (G9)
        arpeggio: [392.0, 493.88, 587.33, 698.46, 783.99],
      },
    ];

    // Frequencies
    const C4 = 261.63, D4 = 293.66, E4 = 329.63, F4 = 349.23, G4 = 392.0, A4 = 440.0, B4 = 493.88;
    const C5 = 523.25, D5 = 587.33, E5 = 659.25, F5 = 698.46, G5 = 783.99, A5 = 880.0, B5 = 987.77;
    const C6 = 1046.5, D6 = 1174.66, E6 = 1318.51;

    // 64-step Catchy Marimba & Steel-Pan Melody Line
    const melodyPattern = [
      // Bar 1 (Cmaj9) - Playful hook
      E5, 0, G5, 0, C6, 0, A5, 0,  G5, E5, 0, G5, A5, 0, G5, 0,
      // Bar 2 (Amin9) - Syncopated jump
      E5, 0, C5, 0, A5, 0, G5, 0,  E5, 0, D5, E5, G5, E5, D5, 0,
      // Bar 3 (Fmaj9) - Uplifting melodic lift
      C5, 0, F5, 0, A5, 0, C6, 0,  D6, C6, A5, 0, G5, A5, G5, 0,
      // Bar 4 (G9) - Cheerful resolution
      B5, 0, G5, 0, D5, 0, E5, 0,  G5, 0, A5, B5, C6, 0, 0, 0,
    ];

    // Flute / Whistle Harmony on accents
    const harmonyPattern = [
      0, 0, C5, 0, E5, 0, 0, 0,    0, 0, 0, 0, C5, 0, 0, 0,
      0, 0, 0, 0, E5, 0, 0, 0,    0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, A4, 0, C5, 0, E5, 0,   F5, 0, 0, 0, 0, 0, 0, 0,
      0, 0, D5, 0, 0, 0, 0, 0,    D5, 0, 0, 0, E5, 0, 0, 0,
    ];

    const scheduleStep = (t: number, step: number) => {
      if (!this.ctx || !this.bgmGain || !this.isBgmPlaying) return;

      const barIndex = Math.floor((step % 64) / 16);
      const stepInBar = step % 16;
      const curChord = chords[barIndex];

      // ====================================================
      // 1. DRUMS & PERCUSSION SECTION (Lively energetic Taal)
      // ====================================================

      // A. Punchy Kick Drum (Steps 0, 6, 8, 14)
      if (stepInBar === 0 || stepInBar === 6 || stepInBar === 8 || stepInBar === 14) {
        const kickOsc = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kickOsc.type = 'sine';
        kickOsc.frequency.setValueAtTime(135, t);
        kickOsc.frequency.exponentialRampToValueAtTime(42, t + 0.08);

        kickGain.gain.setValueAtTime(0.24, t);
        kickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);

        kickOsc.connect(kickGain);
        kickGain.connect(this.bgmGain);
        kickOsc.start(t);
        kickOsc.stop(t + 0.11);
      }

      // B. Snappy Snare + Rimshot (Steps 4 and 12 - Beats 2 & 4)
      if (stepInBar === 4 || stepInBar === 12) {
        // Snare body tone
        const snareOsc = this.ctx.createOscillator();
        const snareGain = this.ctx.createGain();
        snareOsc.type = 'triangle';
        snareOsc.frequency.setValueAtTime(190, t);
        snareOsc.frequency.exponentialRampToValueAtTime(85, t + 0.07);

        snareGain.gain.setValueAtTime(0.14, t);
        snareGain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);

        snareOsc.connect(snareGain);
        snareGain.connect(this.bgmGain);
        snareOsc.start(t);
        snareOsc.stop(t + 0.1);

        // Crisp snap noise burst
        const snapOsc = this.ctx.createOscillator();
        const snapFilter = this.ctx.createBiquadFilter();
        const snapGain = this.ctx.createGain();

        snapOsc.type = 'square';
        snapOsc.frequency.setValueAtTime(950 + Math.random() * 200, t);
        snapFilter.type = 'bandpass';
        snapFilter.frequency.setValueAtTime(2400, t);
        snapFilter.Q.setValueAtTime(1.8, t);

        snapGain.gain.setValueAtTime(0.08, t);
        snapGain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);

        snapOsc.connect(snapFilter);
        snapFilter.connect(snapGain);
        snapGain.connect(this.bgmGain);
        snapOsc.start(t);
        snapOsc.stop(t + 0.07);
      }

      // C. Latin Percussion: Bongos & Congas (Steps 2, 7, 10, 15)
      if (stepInBar === 2 || stepInBar === 10) {
        // High Bongo tap
        const bongoOsc = this.ctx.createOscillator();
        const bongoGain = this.ctx.createGain();
        bongoOsc.type = 'sine';
        bongoOsc.frequency.setValueAtTime(420, t);
        bongoOsc.frequency.exponentialRampToValueAtTime(260, t + 0.05);

        bongoGain.gain.setValueAtTime(0.1, t);
        bongoGain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);

        bongoOsc.connect(bongoGain);
        bongoGain.connect(this.bgmGain);
        bongoOsc.start(t);
        bongoOsc.stop(t + 0.07);
      } else if (stepInBar === 7 || stepInBar === 15) {
        // Low Conga resonance
        const congaOsc = this.ctx.createOscillator();
        const congaGain = this.ctx.createGain();
        congaOsc.type = 'sine';
        congaOsc.frequency.setValueAtTime(240, t);
        congaOsc.frequency.exponentialRampToValueAtTime(160, t + 0.07);

        congaGain.gain.setValueAtTime(0.09, t);
        congaGain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);

        congaOsc.connect(congaGain);
        congaGain.connect(this.bgmGain);
        congaOsc.start(t);
        congaOsc.stop(t + 0.09);
      }

      // D. Shaker / Tambourine (Every 16th step with accents)
      const shakerOsc = this.ctx.createOscillator();
      const shakerFilter = this.ctx.createBiquadFilter();
      const shakerGain = this.ctx.createGain();

      const isAccent = stepInBar % 4 === 2;
      shakerOsc.type = 'square';
      shakerOsc.frequency.setValueAtTime(3600 + (step % 4) * 200, t);

      shakerFilter.type = 'highpass';
      shakerFilter.frequency.setValueAtTime(5800, t);

      shakerGain.gain.setValueAtTime(isAccent ? 0.035 : 0.018, t);
      shakerGain.gain.exponentialRampToValueAtTime(0.0005, t + (isAccent ? 0.045 : 0.025));

      shakerOsc.connect(shakerFilter);
      shakerFilter.connect(shakerGain);
      shakerGain.connect(this.bgmGain);
      shakerOsc.start(t);
      shakerOsc.stop(t + 0.05);

      // E. Crash Cymbal splash at the start of loop / bars (Step 0 of each 32 steps)
      if (step % 32 === 0) {
        const crashOsc = this.ctx.createOscillator();
        const crashFilter = this.ctx.createBiquadFilter();
        const crashGain = this.ctx.createGain();

        crashOsc.type = 'square';
        crashOsc.frequency.setValueAtTime(4800, t);
        crashFilter.type = 'highpass';
        crashFilter.frequency.setValueAtTime(6500, t);

        crashGain.gain.setValueAtTime(0.06, t);
        crashGain.gain.exponentialRampToValueAtTime(0.0005, t + 0.35);

        crashOsc.connect(crashFilter);
        crashFilter.connect(crashGain);
        crashGain.connect(this.bgmGain);
        crashOsc.start(t);
        crashOsc.stop(t + 0.36);
      }

      // ====================================================
      // 2. FUNKY & BOUNCY SLAP BASSLINE
      // ====================================================
      // Hits on 0, 3, 6, 8, 11, 14
      const bassHits = [true, false, false, true, false, false, true, false, true, false, false, true, false, false, true, false];
      if (bassHits[stepInBar]) {
        const bassOsc = this.ctx.createOscillator();
        const subOsc = this.ctx.createOscillator();
        const bassFilter = this.ctx.createBiquadFilter();
        const bassGain = this.ctx.createGain();

        // Walking note variations
        let baseFreq = curChord.bass;
        if (stepInBar === 3) baseFreq *= 1.25; // 3rd
        else if (stepInBar === 6) baseFreq *= 1.5; // 5th
        else if (stepInBar === 11) baseFreq *= 2.0; // Octave pop
        else if (stepInBar === 14) baseFreq *= 1.78; // 7th

        bassOsc.type = 'sawtooth';
        bassOsc.frequency.setValueAtTime(baseFreq, t);

        subOsc.type = 'sine';
        subOsc.frequency.setValueAtTime(baseFreq, t);

        bassFilter.type = 'lowpass';
        bassFilter.frequency.setValueAtTime(750, t);
        bassFilter.frequency.exponentialRampToValueAtTime(160, t + 0.13);

        bassGain.gain.setValueAtTime(0.12, t);
        bassGain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);

        bassOsc.connect(bassFilter);
        subOsc.connect(bassFilter);
        bassFilter.connect(bassGain);
        bassGain.connect(this.bgmGain);

        bassOsc.start(t);
        subOsc.start(t);
        bassOsc.stop(t + 0.16);
        subOsc.stop(t + 0.16);
      }

      // ====================================================
      // 3. ELECTRIC RHODES & ACOUSTIC CHORD STABS
      // ====================================================
      // Offbeat syncopated chords on steps 2, 6, 10, 14
      if (stepInBar === 2 || stepInBar === 6 || stepInBar === 10 || stepInBar === 14) {
        curChord.keys.forEach((freq, idx) => {
          if (!this.ctx || !this.bgmGain) return;
          const keyOsc = this.ctx.createOscillator();
          const keyGain = this.ctx.createGain();

          keyOsc.type = 'triangle';
          keyOsc.frequency.setValueAtTime(freq, t);

          keyGain.gain.setValueAtTime(0.0001, t);
          keyGain.gain.linearRampToValueAtTime(0.032 - idx * 0.004, t + 0.008);
          keyGain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

          keyOsc.connect(keyGain);
          keyGain.connect(this.bgmGain);
          keyOsc.start(t);
          keyOsc.stop(t + 0.14);
        });
      }

      // ====================================================
      // 4. TROPICAL MARIMBA & STEEL-PAN MELODY LEAD
      // ====================================================
      const melNote = melodyPattern[step % 64];
      if (melNote > 0) {
        // Dual harmonic rich wooden mallet tone
        [melNote, melNote * 2.003].forEach((freq, i) => {
          if (!this.ctx || !this.bgmGain) return;
          const melOsc = this.ctx.createOscillator();
          const melGain = this.ctx.createGain();

          melOsc.type = i === 0 ? 'sine' : 'triangle';
          melOsc.frequency.setValueAtTime(freq, t);

          const vol = i === 0 ? 0.08 : 0.025;
          melGain.gain.setValueAtTime(0.0001, t);
          melGain.gain.linearRampToValueAtTime(vol, t + 0.008);
          melGain.gain.exponentialRampToValueAtTime(0.0005, t + 0.22);

          melOsc.connect(melGain);
          melGain.connect(this.bgmGain);
          melOsc.start(t);
          melOsc.stop(t + 0.24);
        });
      }

      // ====================================================
      // 5. AIRY FLUTE / SYNTH WHISTLE HARMONY
      // ====================================================
      const harmNote = harmonyPattern[step % 64];
      if (harmNote > 0) {
        const fluteOsc = this.ctx.createOscillator();
        const fluteGain = this.ctx.createGain();

        fluteOsc.type = 'sine';
        fluteOsc.frequency.setValueAtTime(harmNote, t);

        fluteGain.gain.setValueAtTime(0.0001, t);
        fluteGain.gain.linearRampToValueAtTime(0.04, t + 0.03);
        fluteGain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);

        fluteOsc.connect(fluteGain);
        fluteGain.connect(this.bgmGain);
        fluteOsc.start(t);
        fluteOsc.stop(t + 0.3);
      }

      // ====================================================
      // 6. SPARKLY GLOCKENSPIEL / ARPEGGIO CHIME (Steps 1, 5, 9, 13)
      // ====================================================
      if (stepInBar % 4 === 1) {
        const arpNote = curChord.arpeggio[(stepInBar + step) % curChord.arpeggio.length];
        const arpOsc = this.ctx.createOscillator();
        const arpGain = this.ctx.createGain();

        arpOsc.type = 'sine';
        arpOsc.frequency.setValueAtTime(arpNote * 1.5, t);

        arpGain.gain.setValueAtTime(0.0001, t);
        arpGain.gain.linearRampToValueAtTime(0.02, t + 0.005);
        arpGain.gain.exponentialRampToValueAtTime(0.0005, t + 0.15);

        arpOsc.connect(arpGain);
        arpGain.connect(this.bgmGain);
        arpOsc.start(t);
        arpOsc.stop(t + 0.16);
      }
    };

    // Lookahead sequencer scheduler
    const sequencerLoop = () => {
      if (!this.isBgmPlaying || !this.ctx) return;
      const currentTime = this.ctx.currentTime;
      while (this.nextStepTime < currentTime + 0.25) {
        scheduleStep(this.nextStepTime, this.bgmStep);
        this.nextStepTime += stepDuration;
        this.bgmStep++;
      }
    };

    this.bgmInterval = window.setInterval(sequencerLoop, 60);
    sequencerLoop();
  }

  public stopBgm() {
    this.isBgmPlaying = false;
    if (this.bgmInterval) {
      clearInterval(this.bgmInterval);
      this.bgmInterval = null;
    }
  }

  // =========================================================================
  // LOUD, CLEAR & SATISFYING GAMEPLAY SOUND EFFECTS
  // =========================================================================

  // 1. Crystal Glass Tube Select Ping
  public playSelect() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.vibrate(12);

    const now = this.ctx.currentTime;
    [580, 1160].forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.08, now + 0.08);

      gain.gain.setValueAtTime(i === 0 ? 0.35 : 0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now);
      osc.stop(now + 0.16);
    });
  }

  // 2. Invalid Move Warning Thud
  public playError() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.vibrate([25, 40, 25]);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.linearRampToValueAtTime(100, now + 0.18);

    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.2);
  }

  // 3. Magical Crystal Liquid Water Pouring (Satisfying Bloop, Trickle & Gurgle ASMR)
  private pourIntervalId: number | null = null;
  private pourActiveGain: GainNode | null = null;

  public startPour() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.stopPour();

    try {
      const now = this.ctx.currentTime;
      const masterPourGain = this.ctx.createGain();
      masterPourGain.gain.setValueAtTime(0.001, now);
      masterPourGain.gain.linearRampToValueAtTime(0.28, now + 0.05);
      masterPourGain.connect(this.sfxGain);
      this.pourActiveGain = masterPourGain;

      // Melodic Water Drop Notes (Pentatonic crystal water scale)
      const waterNotes = [480, 560, 640, 720, 840, 960, 1120, 1280];
      let dropStep = 0;

      const triggerWaterDrop = () => {
        if (!this.ctx || !this.pourActiveGain) return;
        const t = this.ctx.currentTime;

        // Base frequency of this liquid drop with slight organic pitch variation
        const baseFreq = waterNotes[dropStep % waterNotes.length] * (0.96 + Math.random() * 0.08);
        dropStep++;

        // A. Resonant Glass Liquid Drop (Sine with rising bloop curve)
        const dropOsc = this.ctx.createOscillator();
        const dropGain = this.ctx.createGain();

        dropOsc.type = 'sine';
        // Rising pitch curve creates that signature authentic water "bloop" sound
        dropOsc.frequency.setValueAtTime(baseFreq * 0.75, t);
        dropOsc.frequency.exponentialRampToValueAtTime(baseFreq * 1.35, t + 0.045);
        dropOsc.frequency.exponentialRampToValueAtTime(baseFreq, t + 0.09);

        dropGain.gain.setValueAtTime(0.001, t);
        dropGain.gain.linearRampToValueAtTime(0.18, t + 0.012);
        dropGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.085);

        dropOsc.connect(dropGain);
        dropGain.connect(this.pourActiveGain);

        dropOsc.start(t);
        dropOsc.stop(t + 0.09);

        // B. Crystal Glass Resonance (High soft ping harmonic)
        const glassHarmonic = this.ctx.createOscillator();
        const glassHarmonicGain = this.ctx.createGain();

        glassHarmonic.type = 'triangle';
        glassHarmonic.frequency.setValueAtTime(baseFreq * 2.5, t);
        glassHarmonicGain.gain.setValueAtTime(0.03, t);
        glassHarmonicGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);

        glassHarmonic.connect(glassHarmonicGain);
        glassHarmonicGain.connect(this.pourActiveGain);

        glassHarmonic.start(t);
        glassHarmonic.stop(t + 0.07);

        // Occasional sub-bubble trickle
        if (Math.random() < 0.4) {
          const subBubble = this.ctx.createOscillator();
          const subGain = this.ctx.createGain();
          const subT = t + 0.025;

          subBubble.type = 'sine';
          subBubble.frequency.setValueAtTime(320 + Math.random() * 180, subT);
          subBubble.frequency.exponentialRampToValueAtTime(540 + Math.random() * 200, subT + 0.035);

          subGain.gain.setValueAtTime(0.08, subT);
          subGain.gain.exponentialRampToValueAtTime(0.0001, subT + 0.05);

          subBubble.connect(subGain);
          subGain.connect(this.pourActiveGain);

          subBubble.start(subT);
          subBubble.stop(subT + 0.06);
        }
      };

      // Play immediate first drop
      triggerWaterDrop();

      // Continuous rapid water trickling stream (every 50-65ms for a fluid cascade)
      this.pourIntervalId = window.setInterval(() => {
        triggerWaterDrop();
      }, 55);
    } catch {
      // ignore
    }
  }

  public stopPour() {
    if (this.pourIntervalId !== null) {
      clearInterval(this.pourIntervalId);
      this.pourIntervalId = null;
    }

    if (this.pourActiveGain && this.ctx) {
      const now = this.ctx.currentTime;
      try {
        this.pourActiveGain.gain.linearRampToValueAtTime(0.0001, now + 0.08);
      } catch {
        // ignore
      }
      setTimeout(() => {
        if (this.pourActiveGain) {
          try {
            this.pourActiveGain.disconnect();
          } catch {
            // ignore
          }
          this.pourActiveGain = null;
        }
      }, 100);
    }
  }

  // 4. Water Splash Droplet Impact & Glass Resonance
  public playSplash() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.vibrate(10);

    const now = this.ctx.currentTime;

    // Splash pop droplets
    [820, 640, 480, 950].forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const t = now + idx * 0.022;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.45, t + 0.08);

      gain.gain.setValueAtTime(0.24, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.08);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + 0.09);
    });

    // Glass acoustic ringing ping
    const glassOsc = this.ctx.createOscillator();
    const glassGain = this.ctx.createGain();
    glassOsc.type = 'triangle';
    glassOsc.frequency.setValueAtTime(1480, now);
    glassGain.gain.setValueAtTime(0.12, now);
    glassGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.14);
    glassOsc.connect(glassGain);
    glassGain.connect(this.sfxGain);
    glassOsc.start(now);
    glassOsc.stop(now + 0.15);
  }

  // 5. Sparkle Particle Chime
  public playSparkle() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const sparkleNotes = [1046.5, 1318.51, 1567.98, 2093.0];
    sparkleNotes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const t = now + idx * 0.04;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.18, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + 0.2);
    });
  }

  // 6. Complete Tube Grand Fanfare
  public playTubeComplete() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.vibrate([15, 30, 20]);
    this.playSparkle();

    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51];
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const startTime = now + idx * 0.055;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.28, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.32);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(startTime);
      osc.stop(startTime + 0.35);
    });
  }

  // 7. Level Win Royal Celebration
  public playWin() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.vibrate([30, 50, 40, 60, 80]);

    const now = this.ctx.currentTime;
    const chords = [
      { notes: [523.25, 659.25, 783.99], time: 0, dur: 0.22 },
      { notes: [587.33, 739.99, 880.0], time: 0.2, dur: 0.22 },
      { notes: [659.25, 830.61, 987.77], time: 0.4, dur: 0.22 },
      { notes: [783.99, 987.77, 1174.66, 1567.98], time: 0.62, dur: 0.8 },
    ];

    chords.forEach((chord) => {
      chord.notes.forEach((freq) => {
        if (!this.ctx || !this.sfxGain) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const t = now + chord.time;

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t);

        gain.gain.setValueAtTime(0.24, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + chord.dur);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(t);
        osc.stop(t + chord.dur);
      });
    });
  }

  // 8. Coin Pickup Bell
  public playCoin() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.vibrate(10);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(987.77, now);
    osc.frequency.setValueAtTime(1318.51, now + 0.06);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.22);
  }

  // 9. Lucky Wheel Tick
  public playSpinTick() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.vibrate(8);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(850, now);
    osc.frequency.exponentialRampToValueAtTime(220, now + 0.035);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.04);
  }

  // 10. UI Button Click
  public playClick() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.vibrate(6);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(680, now);
    osc.frequency.exponentialRampToValueAtTime(340, now + 0.04);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.04);
  }

  // 11. Shop Unlock Item Melody
  public playUnlock() {
    if (!this.isSoundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    this.vibrate([20, 30, 40]);

    const now = this.ctx.currentTime;
    [440, 554.37, 659.25, 880].forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const t = now + idx * 0.08;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.24, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + 0.3);
    });
  }
}

export const sound = new AudioManager();
