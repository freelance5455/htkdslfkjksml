// Lightweight Web Audio beat generator & speech synthesis for song rehearsing

class RhythmPlayer {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private timerId: number | null = null;
  private currentBeat: number = 0;
  private bpm: number = 115;
  private onBeatChange?: (beat: number) => void;

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setBpm(newBpm: number) {
    this.bpm = Math.max(60, Math.min(180, newBpm));
  }

  public getBpm(): number {
    return this.bpm;
  }

  public start(bpm: number, onBeat?: (beat: number) => void) {
    this.stop();
    this.bpm = bpm;
    this.onBeatChange = onBeat;
    this.initCtx();
    this.isPlaying = true;
    this.currentBeat = 0;

    const intervalMs = (60 / this.bpm) * 1000;
    this.playClick(0);

    this.timerId = window.setInterval(() => {
      this.currentBeat = (this.currentBeat + 1) % 4;
      this.playClick(this.currentBeat);
      if (this.onBeatChange) {
        this.onBeatChange(this.currentBeat);
      }
    }, intervalMs);
  }

  public stop() {
    this.isPlaying = false;
    if (this.timerId !== null) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  public getStatus(): boolean {
    return this.isPlaying;
  }

  private playClick(beat: number) {
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      const now = this.ctx.currentTime;
      // High pitch on beat 1 (downbeat), soft woodblock / percussion click on beats 2, 3, 4
      if (beat === 0) {
        osc.frequency.setValueAtTime(880, now);
        gain.gain.setValueAtTime(0.35, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      } else {
        osc.frequency.setValueAtTime(440, now);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      }

      osc.start(now);
      osc.stop(now + 0.09);
    } catch {
      // AudioContext policy handled gracefully
    }
  }
}

export const rhythmPlayer = new RhythmPlayer();

// Text to speech helper
export function speakText(
  text: string,
  onStart?: () => void,
  onEnd?: () => void
) {
  if (!('speechSynthesis' in window)) return null;

  window.speechSynthesis.cancel();
  // Strip markdown formatting for cleaner audio reading
  const cleanText = text
    .replace(/[#*_`[\]()]/g, '')
    .replace(/[-*]\s/g, '')
    .slice(0, 1500); // keep reasonable audio length

  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.rate = 1.0;
  utterance.pitch = 0.95; // slightly deeper charismatic tone

  if (onStart) utterance.onstart = onStart;
  if (onEnd) utterance.onend = onEnd;
  utterance.onerror = () => {
    if (onEnd) onEnd();
  };

  window.speechSynthesis.speak(utterance);
  return utterance;
}

export function stopSpeaking() {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}
