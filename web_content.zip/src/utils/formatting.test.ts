import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildCleanPlainText,
  containsRtlCharacters,
  countWords,
  formatLocalFallbackText,
  getTextDirection,
  getTranscriptFontClass,
  stitchTranscriptChunk,
} from './formatting';
import { downsampleFloat32 } from './audioUtils';

test('RTL detection handles Urdu, Arabic, English, and Auto-Detect mixed scripts', () => {
  assert.equal(getTextDirection('ur-PK'), 'rtl');
  assert.equal(getTextDirection('ar-SA'), 'rtl');
  assert.equal(getTextDirection('en-US'), 'ltr');
  assert.equal(containsRtlCharacters('آج میٹنگ ہے'), true);
  assert.equal(containsRtlCharacters('Hello world'), false);
  assert.equal(getTextDirection('auto', 'یہ ٹیسٹ ہے'), 'rtl');
  assert.equal(getTextDirection('auto', 'English transcript'), 'ltr');
  assert.equal(getTranscriptFontClass('ur-PK'), 'font-urdu');
  assert.equal(getTranscriptFontClass('ar-SA'), 'font-arabic');
  assert.equal(getTranscriptFontClass('en-US'), 'font-sans');
});

test('stitchTranscriptChunk joins chunks cleanly without duplicating overlapping words', () => {
  assert.equal(stitchTranscriptChunk('', 'السلام علیکم'), 'السلام علیکم');
  assert.equal(
    stitchTranscriptChunk('آج موسم بہت اچھا', 'بہت اچھا ہے'),
    'آج موسم بہت اچھا ہے'
  );
  assert.equal(
    stitchTranscriptChunk('We need to finish', 'to finish this today'),
    'We need to finish this today'
  );
  assert.equal(
    stitchTranscriptChunk('Hello world', 'Hello world'),
    'Hello world'
  );
  assert.equal(
    stitchTranscriptChunk('First sentence.', 'Second sentence.'),
    'First sentence. Second sentence.'
  );
});

test('countWords accurately counts multilingual words', () => {
  assert.equal(countWords(''), 0);
  assert.equal(countWords('   '), 0);
  assert.equal(countWords('السلام علیکم دوستو'), 3);
  assert.equal(countWords('Hello world from Sk Voice'), 5);
});

test('downsampleFloat32 converts 48kHz audio buffers accurately to 16kHz', () => {
  const input = new Float32Array(480);
  input.fill(0.5);
  const down = downsampleFloat32(input, 48000, 16000);
  assert.equal(down.length, 160);
  assert.ok(Math.abs(down[0] - 0.5) < 0.001);

  const passthrough = downsampleFloat32(input, 16000, 16000);
  assert.equal(passthrough.length, 480);
});

test('formatLocalFallbackText cleans spacing, capitalization, and punctuation offline', () => {
  assert.equal(
    formatLocalFallbackText('  hello   world . i am testing   this ', 'en-US'),
    'Hello world. I am testing this.'
  );
  assert.equal(
    formatLocalFallbackText('آج   موسم بہت اچھا ہے', 'ur-PK'),
    'آج موسم بہت اچھا ہے۔'
  );
});

test('buildCleanPlainText merges and normalizes text cleanly for copy and .txt download', () => {
  assert.equal(
    buildCleanPlainText('  First   line.\r\n\r\n\r\nSecond   line.  ', '  Live   tail  '),
    'First line.\n\nSecond line.\n\nLive tail'
  );
  assert.equal(buildCleanPlainText('', ''), '');
});
