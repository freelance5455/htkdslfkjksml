import JSZip from 'jszip';
import type { WorkspaceFile } from '../types/mycode';

const WORKSPACE_STORAGE_KEY = 'mycode_workspace_files_v1';
const CHAT_STORAGE_KEY = 'mycode_chat_messages_v1';

const EXT_TO_LANG: Record<string, string> = {
  ts: 'typescript',
  tsx: 'tsx',
  js: 'javascript',
  jsx: 'jsx',
  py: 'python',
  html: 'html',
  htm: 'html',
  css: 'css',
  scss: 'css',
  json: 'json',
  md: 'markdown',
  markdown: 'markdown',
  sh: 'bash',
  bash: 'bash',
  zsh: 'bash',
  yml: 'yaml',
  yaml: 'yaml',
  sql: 'sql',
  rs: 'rust',
  go: 'go',
  java: 'java',
  kt: 'kotlin',
  kts: 'kotlin',
  xml: 'xml',
  svg: 'xml',
  txt: 'text',
  env: 'bash',
};

const TEXT_EXTENSIONS = new Set([
  ...Object.keys(EXT_TO_LANG),
  'c',
  'cpp',
  'h',
  'hpp',
  'cs',
  'rb',
  'php',
  'swift',
  'dart',
  'toml',
  'ini',
  'cfg',
  'conf',
  'dockerfile',
  'gitignore',
  'csv',
  'mjs',
  'cjs',
]);

export function inferLanguageFromPath(filePath: string): string {
  const base = filePath.split('/').pop()?.toLowerCase() || '';
  if (base === 'dockerfile') return 'bash';
  if (base === 'makefile') return 'bash';
  const ext = base.includes('.') ? base.split('.').pop() || '' : '';
  return EXT_TO_LANG[ext] || 'text';
}

export function normalizeWorkspacePath(rawPath: string): string {
  return rawPath
    .trim()
    .replace(/^['"`]+|['"`]+$/g, '')
    .replace(/^\.\/+/, '')
    .replace(/^\/+/, '');
}

export function loadWorkspaceFiles(): Record<string, WorkspaceFile> {
  try {
    const raw = localStorage.getItem(WORKSPACE_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? (parsed as Record<string, WorkspaceFile>) : {};
  } catch {
    return {};
  }
}

export function saveWorkspaceFiles(files: Record<string, WorkspaceFile>): void {
  localStorage.setItem(WORKSPACE_STORAGE_KEY, JSON.stringify(files));
}

export function loadSavedMessages<T>(): T[] {
  try {
    const raw = localStorage.getItem(CHAT_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as T[]) : [];
  } catch {
    return [];
  }
}

export function saveChatMessages<T>(messages: T[]): void {
  try {
    // Strip large image preview blobs if quota is tight, keep clean text + metadata
    localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages));
  } catch {
    // Ignore storage quota errors gracefully
  }
}

export function buildWorkspaceContextSummary(files: Record<string, WorkspaceFile>): string {
  const paths = Object.keys(files).sort();
  if (paths.length === 0) return '';

  const chunks: string[] = [];
  let charBudget = 24000;

  for (const p of paths) {
    const f = files[p];
    const block = `--- FILE: ${f.path} ---\n${f.content}\n`;
    if (charBudget - block.length < 0 && chunks.length > 0) {
      chunks.push(`... (${paths.length - chunks.length} additional file(s) omitted for length: ${paths.slice(chunks.length).join(', ')})`);
      break;
    }
    chunks.push(block);
    charBudget -= block.length;
  }

  return chunks.join('\n');
}

export async function exportWorkspaceAsZip(
  files: Record<string, WorkspaceFile>,
  zipFileName = 'mycode-project.zip'
): Promise<number> {
  const entries = Object.values(files);
  const zip = new JSZip();

  if (entries.length === 0) {
    zip.file(
      'README.md',
      '# MyCode Project\n\nNo files have been generated yet. Ask MyCode to create files and export again.\n'
    );
  } else {
    for (const file of entries) {
      zip.file(file.path, file.content);
    }
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = zipFileName;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return entries.length;
}

export async function extractTextFilesFromZip(
  zipFile: File
): Promise<Array<{ path: string; content: string; language: string }>> {
  const arrayBuffer = await zipFile.arrayBuffer();
  const zip = await JSZip.loadAsync(arrayBuffer);
  const extracted: Array<{ path: string; content: string; language: string }> = [];

  const entries = Object.values(zip.files);
  for (const entry of entries) {
    if (entry.dir) continue;
    const normalized = normalizeWorkspacePath(entry.name);
    if (
      !normalized ||
      normalized.startsWith('__MACOSX/') ||
      normalized.includes('/node_modules/') ||
      normalized.startsWith('node_modules/') ||
      normalized.includes('/.git/') ||
      normalized.startsWith('.git/')
    ) {
      continue;
    }

    const base = normalized.split('/').pop()?.toLowerCase() || '';
    const ext = base.includes('.') ? base.split('.').pop() || '' : '';
    if (ext && !TEXT_EXTENSIONS.has(ext) && base !== 'dockerfile' && base !== 'makefile') {
      continue;
    }

    const content = await entry.async('string');
    if (content.includes('\u0000')) continue; // skip binary content

    extracted.push({
      path: normalized,
      content,
      language: inferLanguageFromPath(normalized),
    });
  }

  return extracted;
}
