import { Student, Lesson } from '../types';

export interface CalculatedAlert {
  id: string;
  type: 'payment_lesson' | 'upcoming_lesson' | 'overdue_unpaid' | 'milestone';
  severity: 'critical' | 'warning' | 'info';
  title: string;
  message: string;
  studentId?: string;
  studentName?: string;
  lessonId?: string;
  amount?: number;
  currency?: 'TL' | 'USD';
  badge: string;
  actionText?: string;
  actionType?: 'mark_paid' | 'open_schedule' | 'open_student';
}

export const getNextUpcomingLesson = (lessons: Lesson[]): Lesson | null => {
  const now = new Date();
  
  // Filter scheduled lessons that are either today or in the future
  const upcoming = lessons
    .filter((l) => l.status === 'scheduled')
    .map((l) => {
      const [year, month, day] = l.date.split('-').map(Number);
      const [hour, minute] = l.time.split(':').map(Number);
      const lessonDate = new Date(year, month - 1, day, hour, minute);
      return { lesson: l, lessonDate };
    })
    .filter((item) => item.lessonDate.getTime() > now.getTime() - 60 * 60 * 1000) // within the last hour or future
    .sort((a, b) => a.lessonDate.getTime() - b.lessonDate.getTime());

  return upcoming.length > 0 ? upcoming[0].lesson : null;
};

export const calculateAlerts = (students: Student[], lessons: Lesson[]): CalculatedAlert[] => {
  const alerts: CalculatedAlert[] = [];
  const now = new Date();

  // 1. Ödenmemiş Dersler Uyarısı (Otomatik Takip)
  // Durum A: Tamamlanmış ancak ödenmemiş ödeme dersi olanlar
  const unpaidCompletedLessons = lessons.filter(
    (l) => l.status === 'completed' && l.isPaymentLesson && l.paymentStatus === 'unpaid'
  );

  unpaidCompletedLessons.forEach((lesson) => {
    const student = students.find((s) => s.id === lesson.studentId);
    const amount = student ? student.hourlyRate * student.paymentFrequency : lesson.rate;
    const currency = student ? student.currency : lesson.currency;

    alerts.push({
      id: `unpaid-completed-${lesson.id}`,
      type: 'overdue_unpaid',
      severity: 'critical',
      title: '⚠️ Ödenmemiş Ders Uyarısı!',
      message: `${lesson.studentName} öğrencisinin ${lesson.date} tarihindeki tamamlanan ${lesson.cycleNumber}. ders paketi henüz ödenmedi.`,
      studentId: lesson.studentId,
      studentName: lesson.studentName,
      lessonId: lesson.id,
      amount,
      currency,
      badge: 'Acil Tahsilat',
      actionText: 'Ödeme Alındı İşaretle',
      actionType: 'mark_paid',
    });
  });

  // Durum B: Öğrencinin döngüsü dolmuş ancak ödeme yapılmamış
  students.forEach((student) => {
    if (student.lessonsInCurrentCycle >= student.paymentFrequency && student.status === 'active') {
      const alreadyReported = alerts.some((a) => a.studentId === student.id && a.type === 'overdue_unpaid');
      if (!alreadyReported) {
        const totalDue = student.hourlyRate * student.paymentFrequency;
        alerts.push({
          id: `cycle-overdue-${student.id}`,
          type: 'overdue_unpaid',
          severity: 'critical',
          title: '🚨 Tahsilat Zamanı Geldi / Gecikti',
          message: `${student.name} ${student.paymentFrequency} derslik döngüsünü tamamladı (${student.lessonsInCurrentCycle}/${student.paymentFrequency}). Toplam ${totalDue.toLocaleString('tr-TR')} ${student.currency === 'USD' ? '$' : 'TL'} tahsil edilmeli.`,
          studentId: student.id,
          studentName: student.name,
          amount: totalDue,
          currency: student.currency,
          badge: 'Ödenmemiş Döngü',
          actionText: 'Ödeme Alındı İşaretle',
          actionType: 'mark_paid',
        });
      }
    }
  });

  // 2. Sıradaki Ders ve Ödeme Dersi Uyarısı
  const nextLesson = getNextUpcomingLesson(lessons);
  if (nextLesson) {
    const student = students.find((s) => s.id === nextLesson.studentId);
    
    // Eğer sıradaki ders Ödeme Dersi ise:
    if (nextLesson.isPaymentLesson) {
      const cycleTotal = student ? student.hourlyRate * student.paymentFrequency : nextLesson.rate;
      alerts.push({
        id: `payment-lesson-${nextLesson.id}`,
        type: 'payment_lesson',
        severity: 'warning',
        title: '💰 ÖNEMLİ: Yaklaşan Ders Ödeme Dersi!',
        message: `${nextLesson.studentName} ile sıradaki ders ${nextLesson.cycleNumber}. ders ve bu derste ${cycleTotal.toLocaleString('tr-TR')} ${nextLesson.currency === 'USD' ? '$' : 'TL'} tahsil edilecek. Ders öncesinde öğrenciye hatırlatma yapabilirsiniz.`,
        studentId: nextLesson.studentId,
        studentName: nextLesson.studentName,
        lessonId: nextLesson.id,
        amount: cycleTotal,
        currency: nextLesson.currency,
        badge: 'Ödeme Dersi',
        actionText: 'Ders Detayını Aç',
        actionType: 'open_schedule',
      });
    } else {
      // Normal yaklaşan ders
      alerts.push({
        id: `upcoming-${nextLesson.id}`,
        type: 'upcoming_lesson',
        severity: 'info',
        title: '📅 Sıradaki Ders Yaklaşıyor',
        message: `${nextLesson.studentName} - ${nextLesson.subject === 'english' ? 'İngilizce' : 'Türkçe'} dersi (${nextLesson.date} saat ${nextLesson.time}). Döngü: ${nextLesson.cycleNumber}/${student ? student.paymentFrequency : '?'}. ders.`,
        studentId: nextLesson.studentId,
        studentName: nextLesson.studentName,
        lessonId: nextLesson.id,
        badge: 'Sıradaki Ders',
        actionText: 'Ders Planına Git',
        actionType: 'open_schedule',
      });
    }
  }

  return alerts;
};
