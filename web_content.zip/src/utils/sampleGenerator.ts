import { SourceMedia } from '../types/editor';

// Procedural video generator for offline, instant sample clips
export async function generateSampleVideo(
  title: string,
  theme: 'sunset' | 'cyberpunk' | 'skate',
  durationSec: number = 5
): Promise<SourceMedia> {
  const width = 640;
  const height = 360;
  const fps = 30;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Create audio context for ambient sound
  const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const audioCtx = new AudioContextClass();
  const audioDest = audioCtx.createMediaStreamDestination();

  // Create synth tone
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = theme === 'sunset' ? 'sine' : theme === 'cyberpunk' ? 'sawtooth' : 'triangle';
  osc.frequency.setValueAtTime(theme === 'sunset' ? 220 : theme === 'cyberpunk' ? 110 : 330, audioCtx.currentTime);
  gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
  osc.connect(gain);
  gain.connect(audioDest);
  osc.start();

  const canvasStream = canvas.captureStream(fps);
  const combinedStream = new MediaStream([
    ...canvasStream.getVideoTracks(),
    ...audioDest.stream.getAudioTracks(),
  ]);

  let mimeType = 'video/webm;codecs=vp9,opus';
  if (!MediaRecorder.isTypeSupported(mimeType)) {
    mimeType = 'video/webm';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'video/mp4';
    }
  }

  const recorder = new MediaRecorder(combinedStream, {
    mimeType: MediaRecorder.isTypeSupported(mimeType) ? mimeType : undefined,
  });

  const chunks: Blob[] = [];
  recorder.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };

  const totalFrames = durationSec * fps;
  let currentFrame = 0;

  return new Promise((resolve) => {
    recorder.onstop = async () => {
      osc.stop();
      audioCtx.close();
      const blob = new Blob(chunks, { type: 'video/mp4' });
      const url = URL.createObjectURL(blob);

      // Generate a thumbnail image
      const thumbUrl = canvas.toDataURL('image/jpeg', 0.85);

      resolve({
        id: `sample-${theme}-${Date.now()}`,
        name: title,
        url,
        duration: durationSec,
        width,
        height,
        fps,
        thumbnailUrl: thumbUrl,
        isSample: true,
      });
    };

    recorder.start();

    const renderLoop = () => {
      const progress = currentFrame / totalFrames;
      const t = currentFrame / fps;

      // Draw background theme
      if (theme === 'sunset') {
        const grad = ctx.createLinearGradient(0, 0, 0, height);
        grad.addColorStop(0, '#1a0b2e');
        grad.addColorStop(0.5, '#7b2cbf');
        grad.addColorStop(0.7, '#ff6b6b');
        grad.addColorStop(1, '#ffa94d');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        // Sun
        ctx.beginPath();
        const sunY = height * 0.55 + Math.sin(t * 0.5) * 10;
        ctx.arc(width / 2, sunY, 60, 0, Math.PI * 2);
        ctx.fillStyle = '#fff3bf';
        ctx.shadowColor = '#ff6b6b';
        ctx.shadowBlur = 30;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Ocean waves
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.moveTo(0, height * 0.75);
        for (let x = 0; x <= width; x += 10) {
          const y = height * 0.75 + Math.sin(x * 0.02 + t * 4) * 8;
          ctx.lineTo(x, y);
        }
        ctx.lineTo(width, height);
        ctx.lineTo(0, height);
        ctx.closePath();
        ctx.fill();
      } else if (theme === 'cyberpunk') {
        // Grid & neon perspective
        ctx.fillStyle = '#080811';
        ctx.fillRect(0, 0, width, height);

        // Neon grid lines
        ctx.strokeStyle = '#00f2fe';
        ctx.lineWidth = 1.5;
        const horizon = height * 0.6;
        for (let x = -width; x < width * 2; x += 40) {
          ctx.beginPath();
          ctx.moveTo(width / 2, horizon);
          ctx.lineTo(x + (t * 60) % 40, height);
          ctx.stroke();
        }

        // Horizontal grid
        for (let y = horizon; y <= height; y += (y - horizon + 5) * 0.25) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
          ctx.stroke();
        }

        // Neon skyline
        ctx.fillStyle = '#111827';
        for (let i = 0; i < 8; i++) {
          const bw = 60;
          const bh = 80 + (i * 37) % 100;
          const bx = i * 85 - 20;
          ctx.fillRect(bx, horizon - bh, bw, bh);
          ctx.strokeStyle = '#f43f5e';
          ctx.strokeRect(bx, horizon - bh, bw, bh);
        }
      } else {
        // Skatepark / Sport theme
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, width, height);

        // Ramp
        ctx.beginPath();
        ctx.moveTo(50, 100);
        ctx.quadraticCurveTo(width / 2, height - 40, width - 50, 100);
        ctx.lineTo(width - 50, height);
        ctx.lineTo(50, height);
        ctx.closePath();
        ctx.fillStyle = '#334155';
        ctx.fill();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 4;
        ctx.stroke();

        // Skater / ball motion
        const ballX = width / 2 + Math.sin(t * 3) * 180;
        const ballY = height * 0.65 - Math.abs(Math.cos(t * 3)) * 60;
        ctx.beginPath();
        ctx.arc(ballX, ballY, 18, 0, Math.PI * 2);
        ctx.fillStyle = '#fbbf24';
        ctx.fill();
      }

      // Title HUD Overlay
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      ctx.fillRect(20, 20, 260, 48);
      ctx.strokeStyle = '#00e5ff';
      ctx.lineWidth = 1;
      ctx.strokeRect(20, 20, 260, 48);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(title, 32, 44);

      ctx.font = '12px "JetBrains Mono", monospace';
      ctx.fillStyle = '#00e5ff';
      ctx.fillText(`00:0${Math.floor(t)}.${Math.floor((t % 1) * 100)} / 00:0${durationSec}.00`, 32, 60);

      currentFrame++;
      if (currentFrame <= totalFrames) {
        requestAnimationFrame(renderLoop);
      } else {
        recorder.stop();
      }
    };

    renderLoop();
  });
}

// Extract metadata and generate thumbnails from user uploaded video
export async function processUploadedVideo(file: File): Promise<SourceMedia> {
  const url = URL.createObjectURL(file);
  const video = document.createElement('video');
  video.preload = 'metadata';
  video.src = url;
  video.muted = true;
  video.playsInline = true;

  return new Promise((resolve, reject) => {
    video.onloadedmetadata = async () => {
      const duration = video.duration || 5;
      const width = video.videoWidth || 1280;
      const height = video.videoHeight || 720;

      // Seek to 1 second to grab clean thumbnail
      video.currentTime = Math.min(1.0, duration / 2);
      video.onseeked = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 320;
        canvas.height = Math.round((320 * height) / width);
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        }
        const thumbUrl = canvas.toDataURL('image/jpeg', 0.85);

        resolve({
          id: `video-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          name: file.name.replace(/\.[^/.]+$/, ''),
          url,
          duration,
          width,
          height,
          fps: 30,
          thumbnailUrl: thumbUrl,
          file,
        });
      };
    };

    video.onerror = () => {
      reject(new Error('Failed to load video file. Please check video codec support.'));
    };
  });
}

// Generate multiple thumbnail frames for filmstrip representation
export async function generateFilmstripThumbnails(
  videoUrl: string,
  duration: number,
  count: number = 8
): Promise<string[]> {
  const video = document.createElement('video');
  video.preload = 'auto';
  video.src = videoUrl;
  video.muted = true;
  video.playsInline = true;

  await new Promise((res) => {
    video.onloadedmetadata = res;
    video.onerror = res;
  });

  const thumbs: string[] = [];
  const canvas = document.createElement('canvas');
  canvas.width = 120;
  canvas.height = 70;
  const ctx = canvas.getContext('2d');

  for (let i = 0; i < count; i++) {
    const targetTime = (duration / (count + 1)) * (i + 1);
    video.currentTime = targetTime;
    await new Promise((res) => {
      video.onseeked = res;
      setTimeout(res, 80); // Safety timeout
    });

    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      thumbs.push(canvas.toDataURL('image/jpeg', 0.6));
    }
  }

  return thumbs;
}
