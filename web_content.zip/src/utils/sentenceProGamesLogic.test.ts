import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  buildChatReplyRound,
  buildClozeQuestion,
  buildFirstLetterHint,
  buildSentenceBlitzQuestion,
  buildVanishStage,
  CURATED_CHAT_DIALOGUES,
  CURATED_PRACTICE_SENTENCES,
} from './sentenceProGamesLogic';

describe('sentenceProGamesLogic', () => {
  it('builds 3 progressive Vanishing Sentence stages (0%, ~35%, ~70%) with matching chips', () => {
    const sentence = 'We should leave early to avoid the morning traffic.';
    const s1 = buildVanishStage(sentence, 1, 10);
    const s2 = buildVanishStage(sentence, 2, 10);
    const s3 = buildVanishStage(sentence, 3, 10);

    assert.equal(s1.blankIndices.length, 0);
    assert.ok(s2.blankIndices.length >= 2 && s2.blankIndices.length < s3.blankIndices.length);
    assert.equal(s2.chips.length, s2.blankIndices.length);
    assert.equal(s3.chips.length, s3.blankIndices.length);
  });

  it('builds valid Smart Cloze questions with 4 unique options including target word', () => {
    const entries = CURATED_PRACTICE_SENTENCES.map((c, idx) => ({ id: idx, num: c.num, en: c.en }));
    const arMap = Object.fromEntries(CURATED_PRACTICE_SENTENCES.map((c) => [c.en, c.ar]));
    const q = buildClozeQuestion(entries[0], entries, arMap, 123);
    assert.ok(q);
    assert.equal(q.options.length, 4);
    assert.ok(q.options.includes(q.targetWord));
    assert.equal(new Set(q.options.map((o) => o.toLowerCase())).size, 4);
    assert.ok(q.ar.length > 0);
  });

  it('provides 40+ curated Quick Chat Reply dialogues and valid 4-option rounds', () => {
    assert.ok(CURATED_CHAT_DIALOGUES.length >= 40);
    const round = buildChatReplyRound('travel', 6, 55);
    assert.equal(round.length, 6);
    for (const q of round) {
      assert.equal(q.options.length, 4);
      assert.equal(q.options.filter((o) => o.isCorrect).length, 1);
      assert.ok(q.dialogue.incomingAr.length > 0);
      assert.ok(q.dialogue.replyAr.length > 0);
    }
  });

  it('formats Speak to Unlock first-letter memory hints while preserving punctuation', () => {
    assert.equal(buildFirstLetterHint('How are you?'), 'H__ a__ y__?');
    assert.equal(buildFirstLetterHint('I am ready!'), 'I a_ r____!');
  });

  it('builds Sentence Speed Blitz questions switching EN->AR and AR->EN every 5 rounds', () => {
    const pool = CURATED_PRACTICE_SENTENCES.map((c, id) => ({
      sentence: { id, num: c.num, en: c.en },
      ar: c.ar,
    }));
    const q0 = buildSentenceBlitzQuestion(pool, 0, 11);
    const q5 = buildSentenceBlitzQuestion(pool, 5, 22);
    assert.ok(q0 && q5);
    assert.equal(q0.direction, 'en2ar');
    assert.equal(q5.direction, 'ar2en');
    assert.equal(q0.options.length, 4);
    assert.equal(q5.options.filter((o) => o.isCorrect).length, 1);
  });
});
