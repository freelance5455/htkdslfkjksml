import { Difficulty, PrayerTimeInfo, Priority, ScheduleItem, Subject } from '../types';

export interface ScheduleConflict {
  itemA: ScheduleItem;
  itemB: ScheduleItem;
  reason: string;
}

export function timeToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minutesToTime(minutes: number): string {
  const norm = ((minutes % (24 * 60)) + (24 * 60)) % (24 * 60);
  const h = Math.floor(norm / 60);
  const m = norm % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

// Check if two time intervals overlap
export function intervalsOverlap(startA: string, endA: string, startB: string, endB: string): boolean {
  const sA = timeToMinutes(startA);
  const eA = timeToMinutes(endA);
  const sB = timeToMinutes(startB);
  const eB = timeToMinutes(endB);
  return sA < eB && sB < eA;
}

// Detect conflicts among schedule items on same day
export function detectScheduleConflicts(items: ScheduleItem[]): ScheduleConflict[] {
  const conflicts: ScheduleConflict[] = [];

  for (let i = 0; i < items.length; i++) {
    for (let j = i + 1; j < items.length; j++) {
      const a = items[i];
      const b = items[j];

      // If items share same day of week (or exact date)
      const sameDay = a.dayOfWeek === b.dayOfWeek && (!a.date || !b.date || a.date === b.date);
      if (sameDay && intervalsOverlap(a.startTime, a.endTime, b.startTime, b.endTime)) {
        conflicts.push({
          itemA: a,
          itemB: b,
          reason: `تعارض زمني بين "${a.title}" (${a.startTime} - ${a.endTime}) و "${b.title}" (${b.startTime} - ${b.endTime})`,
        });
      }
    }
  }

  return conflicts;
}

// Check conflict with prayer times (buffer 20 mins)
export function checkPrayerConflict(
  item: ScheduleItem,
  prayers: PrayerTimeInfo[],
  bufferMinutes: number = 20
): { prayer: PrayerTimeInfo; conflict: boolean } | null {
  const itemStart = timeToMinutes(item.startTime);
  const itemEnd = timeToMinutes(item.endTime);

  for (const p of prayers) {
    if (p.id === 'sunrise') continue;
    const pMinutes = timeToMinutes(p.time);
    const pStart = pMinutes - 5;
    const pEnd = pMinutes + bufferMinutes;

    if (itemStart < pEnd && pStart < itemEnd) {
      return { prayer: p, conflict: true };
    }
  }
  return null;
}

export interface SmartPlanOptions {
  availableHoursPerDay: Record<number, number>; // dayOfWeek (0-6) -> hours
  sessionDurationMinutes: number; // e.g. 45
  breakDurationMinutes: number; // e.g. 15
  startHour: number; // e.g. 9 (09:00 AM)
  endHour: number; // e.g. 23 (11:00 PM)
  respectPrayerTimes: boolean;
  prayerTimes: PrayerTimeInfo[];
}

export function generateSmartStudySchedule(
  subjects: Subject[],
  existingFixedItems: ScheduleItem[], // fixed lectures, sections, commitments
  options: SmartPlanOptions
): ScheduleItem[] {
  const generatedItems: ScheduleItem[] = [];

  // 1. Calculate subject importance score
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const scoredSubjects = subjects.map((sub) => {
    let priorityWeight = 1;
    if (sub.priority === 'high') priorityWeight = 3.5;
    else if (sub.priority === 'medium') priorityWeight = 2;

    let difficultyWeight = 1;
    if (sub.difficulty === 'hard') difficultyWeight = 3;
    else if (sub.difficulty === 'medium') difficultyWeight = 2;

    let daysUntilExam = 30;
    if (sub.examDate) {
      const exam = new Date(sub.examDate);
      exam.setHours(0, 0, 0, 0);
      const diffDays = Math.ceil((exam.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      daysUntilExam = Math.max(1, diffDays);
    }

    // Proximity factor: the closer the exam, the higher the score
    const urgency = 30 / Math.min(daysUntilExam, 30);
    const totalScore = priorityWeight * difficultyWeight * urgency;

    // Remaining items to cover
    const remainingLectures = sub.items.filter((it) => it.type === 'lecture' && !it.isCompleted);
    const remainingSections = sub.items.filter((it) => it.type === 'section' && !it.isCompleted);

    return {
      subject: sub,
      score: totalScore,
      remainingLectures,
      remainingSections,
    };
  });

  // Sort descending by score
  scoredSubjects.sort((a, b) => b.score - a.score);

  // Build queue of study tasks
  const taskQueue: Array<{
    subject: Subject;
    title: string;
    type: 'study';
    itemId?: string;
    duration: number;
  }> = [];

  for (const s of scoredSubjects) {
    // Add lecture reviews
    for (const lec of s.remainingLectures) {
      taskQueue.push({
        subject: s.subject,
        title: `مذاكرة: ${s.subject.name} - ${lec.title}`,
        type: 'study',
        itemId: lec.id,
        duration: options.sessionDurationMinutes,
      });
    }
    // Add section exercises
    for (const sec of s.remainingSections) {
      taskQueue.push({
        subject: s.subject,
        title: `حل تمارين وسكشن: ${s.subject.name} - ${sec.title}`,
        type: 'study',
        itemId: sec.id,
        duration: options.sessionDurationMinutes,
      });
    }

    // If no explicit items, create general revision blocks
    if (s.remainingLectures.length === 0 && s.remainingSections.length === 0) {
      taskQueue.push({
        subject: s.subject,
        title: `مراجعة شاملة وتطبيقات: ${s.subject.name}`,
        type: 'study',
        duration: options.sessionDurationMinutes,
      });
      taskQueue.push({
        subject: s.subject,
        title: `حل أسئلة امتحانات: ${s.subject.name}`,
        type: 'study',
        duration: options.sessionDurationMinutes,
      });
    }
  }

  // Days of week: 0 to 6 (Sunday to Saturday)
  const days = [0, 1, 2, 3, 4, 5, 6];

  // Helper to check if a candidate slot collides with existing items or prayers
  const isSlotFree = (
    day: number,
    startM: number,
    endM: number,
    currentAllocated: ScheduleItem[]
  ): boolean => {
    const sStr = minutesToTime(startM);
    const eStr = minutesToTime(endM);

    // Check fixed items on this day
    const dayFixed = existingFixedItems.filter((i) => i.dayOfWeek === day);
    for (const f of dayFixed) {
      if (intervalsOverlap(sStr, eStr, f.startTime, f.endTime)) return false;
    }

    // Check already generated items on this day
    const dayAllocated = currentAllocated.filter((i) => i.dayOfWeek === day);
    for (const g of dayAllocated) {
      if (intervalsOverlap(sStr, eStr, g.startTime, g.endTime)) return false;
    }

    // Check prayers if required (buffer 20 mins)
    if (options.respectPrayerTimes && options.prayerTimes?.length > 0) {
      for (const p of options.prayerTimes) {
        if (p.id === 'sunrise') continue;
        const pM = timeToMinutes(p.time);
        const pStart = pM - 5;
        const pEnd = pM + 25;
        if (startM < pEnd && pStart < endM) return false;
      }
    }

    return true;
  };

  let queueIdx = 0;

  for (const day of days) {
    const dailyTargetMinutes = (options.availableHoursPerDay[day] ?? 4) * 60;
    let scheduledMinutesToday = 0;

    let pointerMinutes = options.startHour * 60;
    const maxDayMinutes = options.endHour * 60;

    while (
      pointerMinutes + options.sessionDurationMinutes <= maxDayMinutes &&
      scheduledMinutesToday + options.sessionDurationMinutes <= dailyTargetMinutes &&
      queueIdx < taskQueue.length
    ) {
      const candidateEnd = pointerMinutes + options.sessionDurationMinutes;

      if (isSlotFree(day, pointerMinutes, candidateEnd, generatedItems)) {
        const task = taskQueue[queueIdx];
        generatedItems.push({
          id: `smart_study_${day}_${pointerMinutes}_${task.subject.id}`,
          title: task.title,
          type: 'study',
          subjectId: task.subject.id,
          dayOfWeek: day,
          startTime: minutesToTime(pointerMinutes),
          endTime: minutesToTime(candidateEnd),
          durationMinutes: options.sessionDurationMinutes,
          locationOrNotes: `مخطط ذكي للمادة: ${task.subject.code} (${task.subject.priority === 'high' ? 'أولوية قصوى' : 'أولوية اعتيادية'})`,
          isCompleted: false,
          isAutoGenerated: true,
        });

        scheduledMinutesToday += options.sessionDurationMinutes;
        queueIdx++;

        // Insert break
        pointerMinutes = candidateEnd + options.breakDurationMinutes;
      } else {
        // Step forward by 15 mins to search next free opening
        pointerMinutes += 15;
      }
    }
  }

  return generatedItems;
}

// Redistribute uncompleted past tasks into open slots
export function redistributeUncompletedTasks(
  allScheduleItems: ScheduleItem[],
  options: SmartPlanOptions
): { updatedItems: ScheduleItem[]; rescheduledCount: number } {
  const now = new Date();
  const currentDay = now.getDay();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  let rescheduledCount = 0;
  const fixedAndCompleted: ScheduleItem[] = [];
  const tasksToReschedule: ScheduleItem[] = [];

  allScheduleItems.forEach((item) => {
    const isPast =
      item.dayOfWeek < currentDay ||
      (item.dayOfWeek === currentDay && timeToMinutes(item.endTime) < currentMinutes);

    if (item.type === 'study' && !item.isCompleted && isPast) {
      tasksToReschedule.push(item);
      rescheduledCount++;
    } else {
      fixedAndCompleted.push(item);
    }
  });

  if (tasksToReschedule.length === 0) {
    return { updatedItems: allScheduleItems, rescheduledCount: 0 };
  }

  // Distribute tasksToReschedule starting from today forward
  const updatedItems = [...fixedAndCompleted];
  const targetDays = [currentDay, (currentDay + 1) % 7, (currentDay + 2) % 7, (currentDay + 3) % 7];

  let taskIdx = 0;
  for (const day of targetDays) {
    let pointer = day === currentDay ? Math.max(currentMinutes + 15, options.startHour * 60) : options.startHour * 60;
    const maxM = options.endHour * 60;

    while (pointer + options.sessionDurationMinutes <= maxM && taskIdx < tasksToReschedule.length) {
      const candidateEnd = pointer + options.sessionDurationMinutes;
      const sStr = minutesToTime(pointer);
      const eStr = minutesToTime(candidateEnd);

      const hasConflict = updatedItems.some(
        (it) => it.dayOfWeek === day && intervalsOverlap(sStr, eStr, it.startTime, it.endTime)
      );

      if (!hasConflict) {
        const item = tasksToReschedule[taskIdx];
        updatedItems.push({
          ...item,
          dayOfWeek: day,
          startTime: sStr,
          endTime: eStr,
          locationOrNotes: `${item.locationOrNotes || ''} (أُعيدت جدولتها تلقائياً)`.trim(),
        });
        taskIdx++;
        pointer = candidateEnd + options.breakDurationMinutes;
      } else {
        pointer += 15;
      }
    }
    if (taskIdx >= tasksToReschedule.length) break;
  }

  return { updatedItems, rescheduledCount };
}
