import {
  Loan,
  LoanRepayment,
  LoanDisbursement,
  LoanCalculationResult,
  AnniversaryYearReport,
  InterestTimelineEvent,
  RatePeriod,
  CompoundingFrequency,
  InterestType
} from '../types';

/**
 * Checks if a given year is a leap year (Gregorian calendar standard)
 * 1. Divisible by 4
 * 2. If divisible by 100, must also be divisible by 400
 */
export function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}

/**
 * Total days in a specific calendar year
 */
export function getDaysInCalendarYear(year: number): number {
  return isLeapYear(year) ? 366 : 365;
}

/**
 * Parse YYYY-MM-DD into a UTC Date object at 00:00:00 to avoid timezone DST shifts
 */
export function parseDateUTC(dateStr: string): Date {
  const parts = dateStr.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);
  return new Date(Date.UTC(year, month, day, 0, 0, 0, 0));
}

/**
 * Format UTC Date to YYYY-MM-DD
 */
export function formatDateUTC(date: Date): string {
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, '0');
  const d = String(date.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Adds exact days to a date string
 */
export function addDays(dateStr: string, days: number): string {
  const d = parseDateUTC(dateStr);
  d.setUTCDate(d.getUTCDate() + days);
  return formatDateUTC(d);
}

/**
 * Adds exact years to an anniversary start date, preserving the start day
 * e.g. 2024-02-29 + 1 year = 2025-02-28
 * 2024-03-15 + 1 year = 2025-03-15
 */
export function addYearsAnniversary(dateStr: string, years: number): string {
  const d = parseDateUTC(dateStr);
  const origDay = d.getUTCDate();
  const newYear = d.getUTCFullYear() + years;
  const month = d.getUTCMonth();

  const target = new Date(Date.UTC(newYear, month, 1));
  // check max days in target month
  const maxDays = new Date(Date.UTC(newYear, month + 1, 0)).getUTCDate();
  target.setUTCDate(Math.min(origDay, maxDays));
  return formatDateUTC(target);
}

/**
 * Count calendar days between two dates [startDate, endDate)
 */
export function getExactDaysBetween(startDateStr: string, endDateStr: string): number {
  const d1 = parseDateUTC(startDateStr);
  const d2 = parseDateUTC(endDateStr);
  const diffMs = d2.getTime() - d1.getTime();
  return Math.round(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Check if the period between startDate and endDate includes a February 29th
 */
export function hasLeapDayBetween(startDateStr: string, endDateStr: string): boolean {
  const start = parseDateUTC(startDateStr);
  const end = parseDateUTC(endDateStr);
  let curYear = start.getUTCFullYear();
  const endYear = end.getUTCFullYear();

  while (curYear <= endYear) {
    if (isLeapYear(curYear)) {
      const feb29 = new Date(Date.UTC(curYear, 1, 29)); // month 1 = Feb
      if (feb29 >= start && feb29 < end) {
        return true;
      }
    }
    curYear++;
  }
  return false;
}

/**
 * Calculates interest accrued between two dates [fromDate, toDate) for a given principal.
 * Uses exact calendar year denominator for each day:
 * - 1 day in a leap year = 1 / 366 of annual rate
 * - 1 day in a non-leap year = 1 / 365 of annual rate
 * Rate can be yearly (% p.a.) or monthly (% per month).
 * If monthly, annual rate is (monthly rate * 12).
 */
export function calculateExactPeriodInterest(
  principal: number,
  fromDateStr: string,
  toDateStr: string,
  rate: number,
  ratePeriod: RatePeriod
): { interest: number; totalDays: number; leapDaysCount: number; nonLeapDaysCount: number } {
  if (principal <= 0 || rate <= 0 || fromDateStr >= toDateStr) {
    return { interest: 0, totalDays: 0, leapDaysCount: 0, nonLeapDaysCount: 0 };
  }

  // Convert to annual nominal decimal rate
  // E.g. 12% p.a. -> 0.12. Or 2% monthly -> 24% p.a. -> 0.24
  const annualRateDecimal = (ratePeriod === 'monthly' ? rate * 12 : rate) / 100;

  let cur = parseDateUTC(fromDateStr);
  const end = parseDateUTC(toDateStr);

  let leapDaysCount = 0;
  let nonLeapDaysCount = 0;
  let accruedInterest = 0;

  // Day-by-day exact summation guarantees 100% accuracy across year boundaries & leap years
  while (cur < end) {
    const yr = cur.getUTCFullYear();
    const daysInYr = getDaysInCalendarYear(yr);
    const dayInterest = (principal * annualRateDecimal) / daysInYr;
    accruedInterest += dayInterest;

    if (daysInYr === 366) {
      leapDaysCount++;
    } else {
      nonLeapDaysCount++;
    }

    cur.setUTCDate(cur.getUTCDate() + 1);
  }

  return {
    interest: accruedInterest,
    totalDays: leapDaysCount + nonLeapDaysCount,
    leapDaysCount,
    nonLeapDaysCount
  };
}

/**
 * Determine compounding dates between two dates for Compound Interest
 */
function getNextCompoundingDate(curDateStr: string, frequency: CompoundingFrequency, loanStartDay: number): string {
  const d = parseDateUTC(curDateStr);

  if (frequency === 'daily') {
    d.setUTCDate(d.getUTCDate() + 1);
    return formatDateUTC(d);
  }

  if (frequency === 'monthly') {
    // next month on the anniversary day-of-month
    let nextMonth = d.getUTCMonth() + 1;
    let nextYear = d.getUTCFullYear();
    if (nextMonth > 11) {
      nextMonth = 0;
      nextYear += 1;
    }
    const maxDays = new Date(Date.UTC(nextYear, nextMonth + 1, 0)).getUTCDate();
    const targetDay = Math.min(loanStartDay, maxDays);
    return formatDateUTC(new Date(Date.UTC(nextYear, nextMonth, targetDay)));
  }

  if (frequency === 'quarterly') {
    let nextMonth = d.getUTCMonth() + 3;
    let nextYear = d.getUTCFullYear();
    if (nextMonth > 11) {
      nextYear += Math.floor(nextMonth / 12);
      nextMonth = nextMonth % 12;
    }
    const maxDays = new Date(Date.UTC(nextYear, nextMonth + 1, 0)).getUTCDate();
    const targetDay = Math.min(loanStartDay, maxDays);
    return formatDateUTC(new Date(Date.UTC(nextYear, nextMonth, targetDay)));
  }

  // yearly
  const nextYear = d.getUTCFullYear() + 1;
  const month = d.getUTCMonth();
  const maxDays = new Date(Date.UTC(nextYear, month + 1, 0)).getUTCDate();
  const targetDay = Math.min(loanStartDay, maxDays);
  return formatDateUTC(new Date(Date.UTC(nextYear, month, targetDay)));
}

/**
 * Main simulation function for a Loan.
 * - Handles simple vs compound interest
 * - Leap year precision (365 vs 366)
 * - The loan start day is the beginning of the anniversary year
 * - Repayment: Interest cleared first, then remaining amount deducted from principal
 * - Interest continues on remaining balance from that specific day onwards
 * - Produces full anniversary year report and timeline
 */
export function calculateLoanDetailed(loan: Loan, asOfDateParam?: string): LoanCalculationResult {
  const todayStr = formatDateUTC(new Date());
  const asOfDate = asOfDateParam || (loan.settledDate ? loan.settledDate : todayStr);

  // If loan start date is in the future compared to asOfDate
  if (loan.startDate > asOfDate) {
    return {
      loanId: loan.id,
      asOfDate,
      currentPrincipal: loan.initialPrincipal,
      currentAccruedInterest: 0,
      totalBalanceRemaining: loan.initialPrincipal,
      totalRepaid: 0,
      totalInterestRepaid: 0,
      totalPrincipalRepaid: 0,
      totalInterestAccruedAllTime: 0,
      isSettled: false,
      anniversaryYears: [],
      timeline: [
        {
          id: 'start',
          date: loan.startDate,
          type: 'start',
          title: 'લોન શરૂઆત / Loan Started',
          description: `મુદ્દલ / Principal: ₹${loan.initialPrincipal.toLocaleString('en-IN')}`,
          principalBefore: 0,
          interestBefore: 0,
          principalAfter: loan.initialPrincipal,
          interestAfter: 0,
          totalBalanceAfter: loan.initialPrincipal
        }
      ]
    };
  }

  // Prepare chronological events:
  // 1. Repayments
  // 2. Disbursements (additional principal)
  // 3. Anniversary marks (Year 1 end, Year 2 end...)
  // 4. Compounding marks (if compound interest)
  // 5. Final asOfDate

  const startDay = parseDateUTC(loan.startDate).getUTCDate();

  // Build anniversary year boundaries:
  // Anniversary Year 1: startDate -> startDate + 1 yr
  // Anniversary Year 2: startDate + 1 yr -> startDate + 2 yr ...
  const anniversaryDates: string[] = [];
  let yr = 1;
  while (true) {
    const annivDate = addYearsAnniversary(loan.startDate, yr);
    anniversaryDates.push(annivDate);
    if (annivDate > asOfDate) {
      break;
    }
    yr++;
  }

  // Repayments sorted by date
  const repayments = [...(loan.repayments || [])]
    .filter((r) => r.date <= asOfDate && r.date >= loan.startDate)
    .sort((a, b) => a.date.localeCompare(b.date));

  // Additional disbursements
  const disbursements = [...(loan.disbursements || [])]
    .filter((d) => d.date <= asOfDate && d.date >= loan.startDate)
    .sort((a, b) => a.date.localeCompare(b.date));

  // We walk forward from loan.startDate to asOfDate day by day or event by event.
  // To preserve 100% precision with simple vs compound and partial payments:
  let curDate = loan.startDate;
  let curPrincipal = loan.initialPrincipal;
  let curAccruedInterest = 0;
  let totalInterestAccruedAllTime = 0;
  let totalRepaid = 0;
  let totalInterestRepaid = 0;
  let totalPrincipalRepaid = 0;

  const timeline: InterestTimelineEvent[] = [
    {
      id: `start-${loan.startDate}`,
      date: loan.startDate,
      type: 'start',
      title: 'લોન શરૂઆત / Loan Started',
      description: `આરંભિક મુદ્દલ: ₹${loan.initialPrincipal.toLocaleString('en-IN')}`,
      principalBefore: 0,
      interestBefore: 0,
      principalAfter: loan.initialPrincipal,
      interestAfter: 0,
      totalBalanceAfter: loan.initialPrincipal
    }
  ];

  // Helper to step interest forward from curDate to targetDate
  const stepInterestForward = (targetDate: string, eventReason: string) => {
    if (targetDate <= curDate) return;

    if (loan.interestType === 'simple') {
      const calc = calculateExactPeriodInterest(
        curPrincipal,
        curDate,
        targetDate,
        loan.interestRate,
        loan.ratePeriod
      );
      if (calc.interest > 0) {
        curAccruedInterest += calc.interest;
        totalInterestAccruedAllTime += calc.interest;
        timeline.push({
          id: `accrual-${curDate}-${targetDate}`,
          date: targetDate,
          type: 'interest_accrual',
          title: `વ્યાજ ગણતરી (${calc.totalDays} દિવસ) / Interest Accrual`,
          description: `${calc.totalDays} દિવસનું વ્યાજ (${calc.leapDaysCount > 0 ? `લીપ વર્ષ: ${calc.leapDaysCount} દિવસ, ` : ''}મુદ્દલ: ₹${Math.round(curPrincipal).toLocaleString('en-IN')})`,
          daysCount: calc.totalDays,
          isLeapPeriod: calc.leapDaysCount > 0,
          principalBefore: curPrincipal,
          interestBefore: curAccruedInterest - calc.interest,
          amountChanged: calc.interest,
          principalAfter: curPrincipal,
          interestAfter: curAccruedInterest,
          totalBalanceAfter: curPrincipal + curAccruedInterest
        });
      }
      curDate = targetDate;
    } else {
      // Compound interest: we must advance through compounding intervals!
      let subCur = curDate;
      while (subCur < targetDate) {
        const nextCompound = getNextCompoundingDate(subCur, loan.compoundingFrequency, startDay);
        const nextStop = nextCompound < targetDate ? nextCompound : targetDate;

        const calc = calculateExactPeriodInterest(
          curPrincipal,
          subCur,
          nextStop,
          loan.interestRate,
          loan.ratePeriod
        );

        curAccruedInterest += calc.interest;
        totalInterestAccruedAllTime += calc.interest;

        // If we reached a compounding mark, compound accrued interest into principal!
        if (nextStop === nextCompound && nextStop <= targetDate) {
          const interestToCompound = curAccruedInterest;
          const oldPrincipal = curPrincipal;
          curPrincipal += interestToCompound;
          curAccruedInterest = 0;

          timeline.push({
            id: `compound-${nextStop}`,
            date: nextStop,
            type: 'anniversary_mark',
            title: 'ચક્રવૃદ્ધિ વ્યાજ મુદ્દલમાં ઉમેરાયું / Interest Compounded',
            description: `વ્યાજ ₹${Math.round(interestToCompound).toLocaleString('en-IN')} મુદ્દલમાં ઉમેરી નવું મુદ્દલ ₹${Math.round(curPrincipal).toLocaleString('en-IN')} થયું`,
            daysCount: calc.totalDays,
            principalBefore: oldPrincipal,
            interestBefore: interestToCompound,
            amountChanged: interestToCompound,
            principalAfter: curPrincipal,
            interestAfter: 0,
            totalBalanceAfter: curPrincipal
          });
        }

        subCur = nextStop;
      }
      curDate = targetDate;
    }
  };

  // Merge all events: repayments, disbursements, anniversary dates, and asOfDate
  interface QueuedEvent {
    date: string;
    type: 'repayment' | 'disbursement' | 'anniversary' | 'asOfDate';
    repayment?: LoanRepayment;
    disbursement?: LoanDisbursement;
    annivIndex?: number;
  }

  const eventQueue: QueuedEvent[] = [];

  repayments.forEach((r) => {
    eventQueue.push({ date: r.date, type: 'repayment', repayment: r });
  });

  disbursements.forEach((d) => {
    eventQueue.push({ date: d.date, type: 'disbursement', disbursement: d });
  });

  anniversaryDates.forEach((annivDate, idx) => {
    if (annivDate <= asOfDate) {
      eventQueue.push({ date: annivDate, type: 'anniversary', annivIndex: idx + 1 });
    }
  });

  eventQueue.push({ date: asOfDate, type: 'asOfDate' });

  // Sort chronologically. If on same date: disbursements first, then interest/anniversary, then repayments
  const priority = {
    disbursement: 1,
    anniversary: 2,
    repayment: 3,
    asOfDate: 4
  };

  eventQueue.sort((a, b) => {
    if (a.date !== b.date) return a.date.localeCompare(b.date);
    return priority[a.type] - priority[b.type];
  });

  // Track anniversary years data
  const anniversaryReports: AnniversaryYearReport[] = [];
  let currentAnnivYearIndex = 1;
  let annivYearStartDate = loan.startDate;
  let annivOpeningPrincipal = loan.initialPrincipal;
  let annivInterestAccrued = 0;
  let annivRepaidTotal = 0;
  let annivRepaidInterest = 0;
  let annivRepaidPrincipal = 0;

  let lastTrackedAllTimeInterest = 0;

  for (const ev of eventQueue) {
    if (ev.date > curDate) {
      const interestBeforeStep = totalInterestAccruedAllTime;
      stepInterestForward(ev.date, ev.type);
      const interestAddedInStep = totalInterestAccruedAllTime - interestBeforeStep;
      annivInterestAccrued += interestAddedInStep;
    }

    if (ev.type === 'repayment' && ev.repayment) {
      const payAmount = ev.repayment.amount;
      totalRepaid += payAmount;
      annivRepaidTotal += payAmount;

      // RULE: Interest cleared first, then remaining deducted from principal
      let clearedInterest = 0;
      let deductedPrincipal = 0;

      const pBefore = curPrincipal;
      const iBefore = curAccruedInterest;

      if (payAmount <= curAccruedInterest) {
        clearedInterest = payAmount;
        curAccruedInterest -= payAmount;
      } else {
        clearedInterest = curAccruedInterest;
        const remainder = payAmount - curAccruedInterest;
        curAccruedInterest = 0;
        deductedPrincipal = Math.min(curPrincipal, remainder);
        curPrincipal -= deductedPrincipal;
      }

      totalInterestRepaid += clearedInterest;
      totalPrincipalRepaid += deductedPrincipal;
      annivRepaidInterest += clearedInterest;
      annivRepaidPrincipal += deductedPrincipal;

      // Save inside repayment object for reference
      ev.repayment.clearedInterest = clearedInterest;
      ev.repayment.deductedPrincipal = deductedPrincipal;

      timeline.push({
        id: `repayment-${ev.repayment.id}-${ev.date}`,
        date: ev.date,
        type: 'repayment',
        title: `જમા ચૂકવણી / Repayment (₹${payAmount.toLocaleString('en-IN')})`,
        description: `વ્યાજ પેટે ચૂકવ્યા: ₹${Math.round(clearedInterest).toLocaleString('en-IN')} | મુદ્દલમાંથી કપાત: ₹${Math.round(deductedPrincipal).toLocaleString('en-IN')}`,
        principalBefore: pBefore,
        interestBefore: iBefore,
        amountChanged: -payAmount,
        clearedInterest,
        deductedPrincipal,
        principalAfter: curPrincipal,
        interestAfter: curAccruedInterest,
        totalBalanceAfter: curPrincipal + curAccruedInterest
      });
    } else if (ev.type === 'disbursement' && ev.disbursement) {
      const pBefore = curPrincipal;
      const iBefore = curAccruedInterest;
      curPrincipal += ev.disbursement.amount;

      timeline.push({
        id: `disbursement-${ev.disbursement.id}-${ev.date}`,
        date: ev.date,
        type: 'disbursement',
        title: `વધારાની રકમ આપી / Added Disbursement (₹${ev.disbursement.amount.toLocaleString('en-IN')})`,
        description: `નવી મુદ્દલ: ₹${Math.round(curPrincipal).toLocaleString('en-IN')}`,
        principalBefore: pBefore,
        interestBefore: iBefore,
        amountChanged: ev.disbursement.amount,
        principalAfter: curPrincipal,
        interestAfter: curAccruedInterest,
        totalBalanceAfter: curPrincipal + curAccruedInterest
      });
    } else if (ev.type === 'anniversary' && ev.annivIndex) {
      // Anniversary cycle reached!
      const annivEndDate = ev.date;
      const daysInThisYear = getExactDaysBetween(annivYearStartDate, annivEndDate);
      const isLeap = hasLeapDayBetween(annivYearStartDate, annivEndDate) || daysInThisYear === 366;

      anniversaryReports.push({
        yearIndex: currentAnnivYearIndex,
        startDate: annivYearStartDate,
        endDate: annivEndDate,
        daysInYear: daysInThisYear,
        isLeapYear: isLeap,
        openingPrincipal: annivOpeningPrincipal,
        interestAccrued: annivInterestAccrued,
        repaymentsTotal: annivRepaidTotal,
        repaymentsToInterest: annivRepaidInterest,
        repaymentsToPrincipal: annivRepaidPrincipal,
        closingPrincipal: curPrincipal,
        closingAccruedInterest: curAccruedInterest,
        closingTotalDue: curPrincipal + curAccruedInterest
      });

      timeline.push({
        id: `anniv-close-${ev.annivIndex}`,
        date: ev.date,
        type: 'anniversary_mark',
        title: `વર્ષ ${currentAnnivYearIndex} પૂર્ણ / Year ${currentAnnivYearIndex} Anniversary (${daysInThisYear} Days ${isLeap ? '★ લીપ વર્ષ' : ''})`,
        description: `વાર્ષિક વ્યાજ: ₹${Math.round(annivInterestAccrued).toLocaleString('en-IN')} | બાકી મુદ્દલ: ₹${Math.round(curPrincipal).toLocaleString('en-IN')} | બાકી વ્યાજ: ₹${Math.round(curAccruedInterest).toLocaleString('en-IN')}`,
        principalBefore: curPrincipal,
        interestBefore: curAccruedInterest,
        principalAfter: curPrincipal,
        interestAfter: curAccruedInterest,
        totalBalanceAfter: curPrincipal + curAccruedInterest
      });

      // Prepare for next year
      currentAnnivYearIndex++;
      annivYearStartDate = annivEndDate;
      annivOpeningPrincipal = curPrincipal;
      annivInterestAccrued = 0;
      annivRepaidTotal = 0;
      annivRepaidInterest = 0;
      annivRepaidPrincipal = 0;
    }
  }

  // If there's an ongoing year up to asOfDate that hasn't completed a full anniversary
  if (curDate > annivYearStartDate) {
    const daysInThisPeriod = getExactDaysBetween(annivYearStartDate, curDate);
    const isLeap = hasLeapDayBetween(annivYearStartDate, curDate);

    anniversaryReports.push({
      yearIndex: currentAnnivYearIndex,
      startDate: annivYearStartDate,
      endDate: curDate,
      daysInYear: daysInThisPeriod,
      isLeapYear: isLeap,
      openingPrincipal: annivOpeningPrincipal,
      interestAccrued: annivInterestAccrued,
      repaymentsTotal: annivRepaidTotal,
      repaymentsToInterest: annivRepaidInterest,
      repaymentsToPrincipal: annivRepaidPrincipal,
      closingPrincipal: curPrincipal,
      closingAccruedInterest: curAccruedInterest,
      closingTotalDue: curPrincipal + curAccruedInterest
    });
  }

  const isSettled = loan.status === 'settled' || (curPrincipal <= 0.01 && curAccruedInterest <= 0.01);

  return {
    loanId: loan.id,
    asOfDate,
    currentPrincipal: Math.max(0, Math.round(curPrincipal * 100) / 100),
    currentAccruedInterest: Math.max(0, Math.round(curAccruedInterest * 100) / 100),
    totalBalanceRemaining: Math.max(0, Math.round((curPrincipal + curAccruedInterest) * 100) / 100),
    totalRepaid: Math.round(totalRepaid * 100) / 100,
    totalInterestRepaid: Math.round(totalInterestRepaid * 100) / 100,
    totalPrincipalRepaid: Math.round(totalPrincipalRepaid * 100) / 100,
    totalInterestAccruedAllTime: Math.round(totalInterestAccruedAllTime * 100) / 100,
    isSettled,
    anniversaryYears: anniversaryReports,
    timeline
  };
}

/**
 * Quick Interest Calculator Helper (for standalone on-the-spot calculations)
 */
export function quickCalculateInterest(params: {
  principal: number;
  startDate: string;
  endDate: string;
  interestType: InterestType;
  interestRate: number;
  ratePeriod: RatePeriod;
  compoundingFrequency?: CompoundingFrequency;
  payments?: { date: string; amount: number }[];
}): LoanCalculationResult {
  const dummyLoan: Loan = {
    id: 'quick-calc',
    userId: 'guest',
    type: 'lent',
    partyName: 'Calculator Party',
    initialPrincipal: params.principal,
    startDate: params.startDate,
    interestType: params.interestType,
    interestRate: params.interestRate,
    ratePeriod: params.ratePeriod,
    compoundingFrequency: params.compoundingFrequency || 'yearly',
    status: 'active',
    repayments: (params.payments || []).map((p, i) => ({
      id: `p-${i}`,
      date: p.date,
      amount: p.amount,
      createdAt: new Date().toISOString()
    })),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  return calculateLoanDetailed(dummyLoan, params.endDate);
}
