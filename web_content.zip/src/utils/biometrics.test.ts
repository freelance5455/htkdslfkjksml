/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_BIOMETRIC_SETTINGS,
  DEFAULT_PIN,
  getBiometricSettings,
  saveBiometricSettings,
  isSectionLocked,
  unlockSection,
  lockSection,
  verifyPin,
  performBiometricScan,
  BiometricSettings,
} from './biometrics.ts';

class MockStorage implements Storage {
  private store: Map<string, string> = new Map();

  get length(): number {
    return this.store.size;
  }

  clear(): void {
    this.store.clear();
  }

  getItem(key: string): string | null {
    return this.store.get(key) ?? null;
  }

  key(index: number): string | null {
    const keys = Array.from(this.store.keys());
    return keys[index] ?? null;
  }

  removeItem(key: string): void {
    this.store.delete(key);
  }

  setItem(key: string, value: string): void {
    this.store.set(key, String(value));
  }
}

describe('Biometrics Utility', () => {
  it('returns default settings when storage is empty', () => {
    const mockStorage = new MockStorage();
    const settings = getBiometricSettings(mockStorage);
    assert.equal(settings.enabled, true);
    assert.equal(settings.pin, DEFAULT_PIN);
    assert.equal(settings.method, 'faceid');
    assert.equal(settings.lastUnlockedAt.wallet, null);
    assert.equal(settings.lastUnlockedAt.profile, null);
  });

  it('correctly persists and retrieves modified settings', () => {
    const mockStorage = new MockStorage();
    saveBiometricSettings(
      {
        enabled: true,
        method: 'touchid',
        pin: '9876',
        autoLockMinutes: 5,
      },
      mockStorage
    );

    const retrieved = getBiometricSettings(mockStorage);
    assert.equal(retrieved.method, 'touchid');
    assert.equal(retrieved.pin, '9876');
    assert.equal(retrieved.autoLockMinutes, 5);
  });

  it('determines locked state based on requirement, enablement, and timeout', () => {
    const mockStorage = new MockStorage();
    const baseSettings: BiometricSettings = {
      ...DEFAULT_BIOMETRIC_SETTINGS,
      enabled: true,
      requireForWallet: true,
      requireForProfile: true,
      autoLockMinutes: 10,
      lastUnlockedAt: {
        wallet: null,
        profile: null,
      },
    };

    // Initially locked because lastUnlockedAt is null
    assert.equal(isSectionLocked('wallet', baseSettings, Date.now()), true);
    assert.equal(isSectionLocked('profile', baseSettings, Date.now()), true);

    // If biometric is disabled, never locked
    const disabledSettings = { ...baseSettings, enabled: false };
    assert.equal(isSectionLocked('wallet', disabledSettings, Date.now()), false);

    // If section requirement is disabled, not locked
    const noWalletReqSettings = { ...baseSettings, requireForWallet: false };
    assert.equal(isSectionLocked('wallet', noWalletReqSettings, Date.now()), false);

    // If unlocked recently, should not be locked
    const now = 10000000;
    const recentlyUnlocked: BiometricSettings = {
      ...baseSettings,
      lastUnlockedAt: {
        wallet: now - 60000, // 1 minute ago, limit is 10 min
        profile: null,
      },
    };
    assert.equal(isSectionLocked('wallet', recentlyUnlocked, now), false);

    // If timeout expired (11 minutes ago with 10 min timeout), should be locked
    const expiredUnlock: BiometricSettings = {
      ...baseSettings,
      lastUnlockedAt: {
        wallet: now - 11 * 60 * 1000,
        profile: null,
      },
    };
    assert.equal(isSectionLocked('wallet', expiredUnlock, now), true);
  });

  it('unlocks and locks sections correctly', () => {
    const mockStorage = new MockStorage();
    const now = 500000;

    // Unlock wallet
    unlockSection('wallet', mockStorage, now);
    let s = getBiometricSettings(mockStorage);
    assert.equal(s.lastUnlockedAt.wallet, now);
    assert.equal(s.lastUnlockedAt.profile, null);

    // Unlock profile
    unlockSection('profile', mockStorage, now + 100);
    s = getBiometricSettings(mockStorage);
    assert.equal(s.lastUnlockedAt.profile, now + 100);

    // Lock single section
    lockSection('wallet', mockStorage);
    s = getBiometricSettings(mockStorage);
    assert.equal(s.lastUnlockedAt.wallet, null);
    assert.equal(s.lastUnlockedAt.profile, now + 100);

    // Lock all sections
    lockSection(undefined, mockStorage);
    s = getBiometricSettings(mockStorage);
    assert.equal(s.lastUnlockedAt.wallet, null);
    assert.equal(s.lastUnlockedAt.profile, null);
  });

  it('verifies PIN code accurately', () => {
    assert.equal(verifyPin('1234', '1234'), true);
    assert.equal(verifyPin(' 1234 ', '1234'), true);
    assert.equal(verifyPin('0000', '1234'), false);
    assert.equal(verifyPin('', '1234'), false);
    assert.equal(verifyPin('abcd', '1234'), false);
  });

  it('performs biometric scan simulation fallback successfully', async () => {
    const result = await performBiometricScan('faceid');
    assert.equal(result.success, true);
    assert.equal(result.methodUsed, 'faceid');
  });
});
