import test from 'node:test';
import assert from 'node:assert/strict';
import type { VocabEntry, VocabStore, WordHubData } from '../types';
import {
  buildOfflineWordRelationships,
  enrichWordHubWithOfflineRelationships,
} from './wordRelationshipsOffline';

function makeMockStore(entries: Array<{ en: string; ar: string; band?: VocabEntry['band'] }>): VocabStore {
  const words: VocabEntry[] = entries.map((e, id) => ({
    id,
    en: e.en,
    ar: e.ar,
    band: e.band || 'A1',
  }));
  const byBand: VocabStore['byBand'] = {
    A0: [],
    A1: [],
    A2: [],
    B1: [],
    B2: [],
    C1: [],
    C2: [],
  };
  for (const w of words) {
    byBand[w.band].push(w.id);
  }
  return {
    words,
    byBand,
    normEn: words.map((w) => w.en.toLowerCase()),
    normAr: words.map((w) => w.ar),
  };
}

test('curated function word "the" returns immediate offline relationships without store', () => {
  const rel = buildOfflineWordRelationships({ word: 'the', ar: 'الـ', band: 'A0' });
  assert.ok(rel.synonyms.length >= 2);
  assert.ok(rel.antonyms.some((a) => a.word === 'a'));
  assert.ok(rel.relatedWords.length >= 2);
});

test('VocabStore offline engine discovers verified synonyms, antonyms, and morphological derivatives', () => {
  const store = makeMockStore([
    { en: 'create', ar: 'ينشئ، يبتكر', band: 'A2' },
    { en: 'creative', ar: 'مبدع، مبتكر', band: 'B1' },
    { en: 'creation', ar: 'إنشاء، إبداع', band: 'B1' },
    { en: 'creator', ar: 'مبتكر، صانع', band: 'B1' },
    { en: 'invent', ar: 'يبتكر، يخترع', band: 'B1' },
    { en: 'destroy', ar: 'يدمر', band: 'B1' },
    { en: 'design', ar: 'يصمم', band: 'A2' },
  ]);

  const rel = buildOfflineWordRelationships({
    word: 'create',
    ar: 'ينشئ، يبتكر',
    band: 'A2',
    store,
  });

  assert.ok(
    rel.synonyms.some((s) => s.word === 'invent'),
    'should discover synonym via shared Arabic gloss'
  );
  assert.ok(
    rel.antonyms.some((a) => a.word === 'destroy'),
    'should discover verified antonym pair'
  );
  const famWords = rel.wordFamily.map((f) => f.word);
  assert.ok(famWords.includes('creative'), 'should include verified derivative "creative"');
  assert.ok(famWords.includes('creation'), 'should include verified derivative "creation"');
  assert.ok(famWords.includes('creator'), 'should include verified derivative "creator"');
});

test('negative prefix antonym detection works offline only for real words in store', () => {
  const store = makeMockStore([
    { en: 'polite', ar: 'مهذب', band: 'B1' },
    { en: 'impolite', ar: 'غير مهذب', band: 'B2' },
    { en: 'rude', ar: 'وقح', band: 'B1' },
    { en: 'politely', ar: 'بأدب', band: 'B1' },
    { en: 'politeness', ar: 'أدب، تهذيب', band: 'B2' },
  ]);

  const rel = buildOfflineWordRelationships({
    word: 'polite',
    ar: 'مهذب',
    band: 'B1',
    store,
  });

  const antWords = rel.antonyms.map((a) => a.word);
  assert.ok(antWords.includes('rude'));
  assert.ok(antWords.includes('impolite'));
  assert.ok(rel.wordFamily.some((f) => f.word === 'politely'));
});

test('enrichWordHubWithOfflineRelationships preserves AI/dictionary items first without duplicates', () => {
  const store = makeMockStore([
    { en: 'happy', ar: 'سعيد', band: 'A1' },
    { en: 'cheerful', ar: 'سعيد، مبتهج', band: 'B1' },
  ]);
  const existing: WordHubData = {
    word: 'happy',
    posEn: 'adjective',
    posAr: 'صفة',
    ipaUs: '/ˈhæpi/',
    ipaUk: '/ˈhæpi/',
    definitionEn: 'feeling pleasure',
    definitionAr: 'سعيد',
    synonyms: [{ word: 'glad', ar: 'مسرور', nuanceAr: 'custom nuance', exampleEn: 'I am glad.', exampleAr: 'أنا مسرور.' }],
    antonyms: [],
    wordFamily: [],
    relatedWords: [],
    collocations: [],
    examples: [],
    commonMistakes: [],
    usageNotes: [],
    formalVsInformal: null,
    idioms: [],
    phrasalVerbs: [],
    wordOrigin: '',
    memoryTip: '',
    source: 'dictionary+ai',
  };

  const merged = enrichWordHubWithOfflineRelationships(existing, {
    word: 'happy',
    ar: 'سعيد',
    band: 'A1',
    store,
  });

  assert.equal(merged.synonyms[0].word, 'glad');
  assert.equal(merged.synonyms[0].nuanceAr, 'custom nuance');
  const gladCount = merged.synonyms.filter((s) => s.word.toLowerCase() === 'glad').length;
  assert.equal(gladCount, 1, 'must deduplicate synonyms');
  assert.ok(merged.antonyms.some((a) => a.word === 'sad'));
  assert.ok(merged.wordFamily.some((f) => f.word === 'happiness'));
});
