export type MindMapLayoutType = "radial" | "vertical_tree" | "fishbone" | "freeform";
export type MindMapLineStyle = "curved" | "straight" | "dashed" | "neon";
export type MindMapSummaryDepth = "surface" | "detailed" | "academic";

export interface MindMapSettings {
  layoutType: MindMapLayoutType;
  lineStyle: MindMapLineStyle;
  summaryDepth: MindMapSummaryDepth;
  nodeColorTheme: "gradient_emerald" | "neon_cyber" | "pastel_soft" | "classic_slate";
  autoExpandBranches: boolean;
  showTimestamps: boolean;
}

export interface MindMapNode {
  id: string;
  label: string;
  type: "root" | "branch" | "leaf";
  details?: string;
  timestamp?: string; // e.g., "02:14" for media
  children?: MindMapNode[];
  x?: number;
  y?: number;
}

export const DEFAULT_MIND_MAP_SETTINGS: MindMapSettings = {
  layoutType: "radial",
  lineStyle: "curved",
  summaryDepth: "detailed",
  nodeColorTheme: "gradient_emerald",
  autoExpandBranches: true,
  showTimestamps: true,
};

const STORAGE_KEY = "noteflow_mindmap_settings_v1";

export function getStoredMindMapSettings(): MindMapSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_MIND_MAP_SETTINGS;
    return { ...DEFAULT_MIND_MAP_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    return DEFAULT_MIND_MAP_SETTINGS;
  }
}

export function saveStoredMindMapSettings(settings: MindMapSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch (e) {
    console.warn("Failed to save MindMap settings:", e);
  }
}

/**
 * Extract structured concept nodes from plain text / markdown / HTML
 */
export function extractMindMapFromText(
  rawText: string,
  settings: MindMapSettings = getStoredMindMapSettings()
): MindMapNode {
  const cleanText = rawText.replace(/<[^>]*>/g, " ").trim();
  if (!cleanText) {
    return {
      id: "root-empty",
      label: "Boş Not",
      type: "root",
      children: [{ id: "branch-1", label: "İçerik Girilmedi", type: "leaf" }],
    };
  }

  const lines = cleanText.split(/\n+/).map((l) => l.trim()).filter(Boolean);
  const rootLabel = lines[0]?.substring(0, 40) || "Ana Not Konusu";

  // Determine branch limit based on summary depth
  const maxBranches = settings.summaryDepth === "surface" ? 3 : settings.summaryDepth === "academic" ? 8 : 5;
  const maxLeavesPerBranch = settings.summaryDepth === "surface" ? 2 : settings.summaryDepth === "academic" ? 5 : 3;

  const sentenceRegex = /[^.!?]+[.!?]+/g;
  const sentences = cleanText.match(sentenceRegex) || [cleanText];

  const branches: MindMapNode[] = [];

  for (let i = 0; i < Math.min(sentences.length, maxBranches); i++) {
    const sentence = sentences[i].trim();
    if (!sentence) continue;

    const words = sentence.split(/\s+/);
    const branchTitle = words.slice(0, 4).join(" ");

    const leaves: MindMapNode[] = [];
    for (let j = 4; j < Math.min(words.length, 4 + maxLeavesPerBranch * 4); j += 4) {
      const leafTitle = words.slice(j, j + 4).join(" ");
      if (leafTitle) {
        leaves.push({
          id: `leaf-${i}-${j}`,
          label: leafTitle,
          type: "leaf",
        });
      }
    }

    branches.push({
      id: `branch-${i}`,
      label: branchTitle || `Kavram ${i + 1}`,
      type: "branch",
      details: sentence,
      children: leaves,
    });
  }

  return {
    id: `root-${Date.now()}`,
    label: rootLabel,
    type: "root",
    children: branches,
  };
}

/**
 * Extract structured MindMap from Audio or Video Media transcript / metadata
 */
export function extractMindMapFromAudioVideo(
  mediaTitle: string,
  transcriptOrNotes: string,
  durationSec: number = 180,
  settings: MindMapSettings = getStoredMindMapSettings()
): MindMapNode {
  const rootTitle = `🎙️ ${mediaTitle || "Medya Kaydı Konusu"}`;
  const cleanTranscript = transcriptOrNotes.replace(/<[^>]*>/g, " ").trim();

  // Divide total duration into timeline segments
  const numSegments = settings.summaryDepth === "surface" ? 3 : settings.summaryDepth === "academic" ? 6 : 4;
  const segmentDuration = durationSec / numSegments;

  const words = cleanTranscript ? cleanTranscript.split(/\s+/) : ["Medya", "Ses", "Kayıt", "Analiz", "İçerik", "Deşifre"];
  const wordsPerSegment = Math.ceil(words.length / numSegments);

  const branches: MindMapNode[] = [];

  for (let i = 0; i < numSegments; i++) {
    const startSec = Math.floor(i * segmentDuration);
    const mins = Math.floor(startSec / 60).toString().padStart(2, "0");
    const secs = Math.floor(startSec % 60).toString().padStart(2, "0");
    const timeFormatted = `${mins}:${secs}`;

    const segWords = words.slice(i * wordsPerSegment, (i + 1) * wordsPerSegment);
    const branchLabel = segWords.slice(0, 4).join(" ") || `Bölüm ${i + 1}`;

    const leaves: MindMapNode[] = [];
    if (segWords.length > 4) {
      for (let k = 4; k < segWords.length; k += 4) {
        const sub = segWords.slice(k, k + 3).join(" ");
        if (sub) {
          leaves.push({
            id: `media-leaf-${i}-${k}`,
            label: sub,
            type: "leaf",
            timestamp: timeFormatted,
          });
        }
      }
    }

    branches.push({
      id: `media-branch-${i}`,
      label: branchLabel,
      type: "branch",
      timestamp: timeFormatted,
      details: segWords.join(" "),
      children: leaves,
    });
  }

  return {
    id: `media-root-${Date.now()}`,
    label: rootTitle,
    type: "root",
    children: branches,
  };
}
