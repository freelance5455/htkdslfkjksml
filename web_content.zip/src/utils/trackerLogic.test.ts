import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDaysLeft,
  calculateOverallStats,
  calculateSubjectStats,
  getActiveStreakCount,
  getBacklogItems,
  getChapterMaterials,
  getMaterialPriority,
  getSubjectChapterProgress,
  isChapterStarted,
  makeStatusKey,
  mergeTrackerData,
  migrateChapterData,
  parseStatusKey,
  updateStreak,
} from './trackerLogic';

test('status key serialization and parsing', () => {
  const key = makeStatusKey('phy', 'Vectors', 'DPP');
  assert.equal(key, 'phy|Vectors|DPP');
  const parsed = parseStatusKey(key);
  assert.deepEqual(parsed, { subject: 'phy', chapter: 'Vectors', material: 'DPP' });
});

test('chapter start and stats calculation', () => {
  const startedStore = { phy: ['Vectors'] };
  assert.equal(isChapterStarted(startedStore, 'phy', 'Vectors'), true);
  assert.equal(isChapterStarted(startedStore, 'phy', 'Kinematics'), false);

  const statusStore: Record<string, 'done' | 'partial' | 'pending'> = {
    'phy|Vectors|DPP': 'done',
    'phy|Vectors|Class Questions': 'partial',
  };

  const phyStats = calculateSubjectStats('phy', statusStore, startedStore);
  assert.equal(phyStats.done, 1);
  assert.equal(phyStats.partial, 1);
  assert.equal(phyStats.pending, 8); // 10 items total in Physics (Lectures + 9 materials)
  assert.equal(phyStats.total, 10);
  assert.equal(phyStats.percent, 15); // (1 + 0.5) / 10 = 15%

  const overall = calculateOverallStats(statusStore, startedStore);
  assert.equal(overall.startedChapters, 1);
  assert.equal(overall.done, 1);
  assert.equal(overall.partial, 1);
  assert.equal(overall.total, 10);
  assert.equal(overall.percent, 15);
});

test('streak calculation handles same-day and consecutive days', () => {
  const day1 = new Date('2026-10-20T10:00:00');
  const day2 = new Date('2026-10-21T10:00:00');
  const day3 = new Date('2026-10-23T10:00:00'); // gap of 2 days

  let s = updateStreak(null, day1);
  assert.equal(s.n, 1);
  assert.equal(s.d, '2026-10-20');

  // Same day update should not increase count
  s = updateStreak(s, day1);
  assert.equal(s.n, 1);

  // Consecutive day increases count
  s = updateStreak(s, day2);
  assert.equal(s.n, 2);
  assert.equal(s.d, '2026-10-21');

  // Gap resets streak to 1
  s = updateStreak(s, day3);
  assert.equal(s.n, 1);
  assert.equal(s.d, '2026-10-23');

  // Check active count
  assert.equal(getActiveStreakCount(s, day3), 1);
});

test('countdown calculation', () => {
  const target = '2027-05-04';
  const today = new Date('2027-05-01T00:00:00');
  const days = calculateDaysLeft(target, today);
  assert.equal(days, 3);
});

test('chapter migration mapping', () => {
  const oldStatus = {
    'phy|Units & Measurements|DPP': 'done' as const,
  };
  const oldStarted = {
    phy: ['Units & Measurements'],
  };
  const migrated = migrateChapterData(oldStatus, {}, oldStarted);

  assert.equal(
    migrated.statusStore['phy|Units and Measurements|DPP'],
    'done'
  );
  assert.deepEqual(migrated.startedStore['phy'], ['Units and Measurements']);
});

test('backlog item aggregation identifies pending tasks and sorts by priority tier', () => {
  const started = { phy: ['Vectors'], zoo: ['Animal Kingdom'], bot: ['Cell: The Unit of Life'] };
  const subItems = {
    phy: {
      Vectors: {
        Lectures: [
          { name: 'Lecture 1', done: true },
          { name: 'Lecture 2', done: false },
        ],
        DPP: [
          { name: 'DPP 1', done: false },
          { name: 'DPP 2', done: true },
        ],
      },
    },
  };
  const status = {
    'phy|Vectors|Class Questions': 'partial' as const,
  };

  const backlog = getBacklogItems(status, subItems, started, {}, '2026-10-23');
  assert.ok(backlog.length > 0);
  const lectureBacklog = backlog.find((x) => x.kd === 'Lecture' && x.s === 'phy');
  assert.ok(lectureBacklog);
  assert.equal(lectureBacklog.d, 'Lecture 2');
  assert.equal(lectureBacklog.priorityTier, 1);

  const dppBacklog = backlog.find((x) => x.m === 'DPP' && x.s === 'phy');
  assert.ok(dppBacklog);
  assert.equal(dppBacklog.d, 'DPP 1');

  // Verify strict ascending priorityRank order across the entire backlog
  for (let i = 1; i < backlog.length; i++) {
    assert.ok(
      backlog[i].priorityRank >= backlog[i - 1].priorityRank,
      `Expected item ${i} (rank ${backlog[i].priorityRank}) >= item ${i - 1} (rank ${backlog[i - 1].priorityRank})`
    );
  }

  // Verify specific material tiers
  assert.equal(getMaterialPriority('Lectures').tier, 1);
  assert.equal(getMaterialPriority('DPP').tier, 1);
  assert.equal(getMaterialPriority('KPP Practice Sheet').tier, 1);
  assert.equal(getMaterialPriority('Class Questions').tier, 2);
  assert.equal(getMaterialPriority('Red Sheet (Tulki Mam)').tier, 2);
  assert.equal(getMaterialPriority('Question Practice Lecture').tier, 2);
  assert.equal(getMaterialPriority('Module').tier, 3);
});

test('subject chapter progress calculates completed, active chapters and ring percentage', () => {
  const startedStore = {
    bot: ['Cell - The Unit of Life', 'Cell Cycle and Cell Division'],
  };
  const statusStore: Record<string, 'done' | 'partial' | 'pending'> = {
    // Complete all 8 items (Lectures + 7 materials) for 'Cell - The Unit of Life'
    'bot|Cell - The Unit of Life|Lectures': 'done',
    'bot|Cell - The Unit of Life|DPP': 'done',
    'bot|Cell - The Unit of Life|Class Questions': 'done',
    'bot|Cell - The Unit of Life|Question Practice Lecture': 'done',
    'bot|Cell - The Unit of Life|Kattar': 'done',
    'bot|Cell - The Unit of Life|PYQ Practice Sheet': 'done',
    'bot|Cell - The Unit of Life|Module': 'done',
    'bot|Cell - The Unit of Life|NBT': 'done',
    // Half done (4 of 8) for 'Cell Cycle and Cell Division'
    'bot|Cell Cycle and Cell Division|Lectures': 'done',
    'bot|Cell Cycle and Cell Division|DPP': 'done',
    'bot|Cell Cycle and Cell Division|Class Questions': 'done',
    'bot|Cell Cycle and Cell Division|Question Practice Lecture': 'done',
  };

  const botProg = getSubjectChapterProgress('bot', startedStore, statusStore);
  assert.equal(botProg.totalChapters, 17);
  assert.equal(botProg.completedChapters, 1);
  assert.equal(botProg.activeChapters, 1);
  // 1.5 / 17 = 8.82% -> 9%
  assert.equal(botProg.percent, 9);
});

test('overall progress updates immediately on lecture and sub-item ticks', () => {
  const startedStore = {
    phy: ['Basic Maths & Calculus (Mathematical Tools)'],
  };
  const subItemStore = {
    phy: {
      'Basic Maths & Calculus (Mathematical Tools)': {
        Lectures: [
          { name: 'Lecture 1', done: true },
          { name: 'Lecture 2', done: false },
        ],
        DPP: [
          { name: 'DPP 1', done: true },
          { name: 'DPP 2', done: false },
        ],
      },
    },
  };
  const statusStore: Record<string, 'done' | 'partial' | 'pending'> = {
    'phy|Basic Maths & Calculus (Mathematical Tools)|Lectures': 'partial',
    'phy|Basic Maths & Calculus (Mathematical Tools)|DPP': 'partial',
  };

  const overall = calculateOverallStats(statusStore, startedStore, subItemStore);
  assert.equal(overall.total, 10);
  assert.equal(overall.done, 0);
  assert.equal(overall.partial, 2);
  // 0.5 + 0.5 = 1.0 out of 10 = 10%
  assert.equal(overall.percent, 10);

  const phyProg = getSubjectChapterProgress('phy', startedStore, statusStore, subItemStore);
  assert.ok(phyProg.percent >= 1);
});

test('inorganic chemistry chapters use Om Pandey materials instead of Motikitab', () => {
  const inorganicMats = getChapterMaterials('chem', 'Chemical Bonding and Molecular Structure');
  assert.ok(inorganicMats.includes('Goat Sheet by Om Pandey'));
  assert.ok(inorganicMats.includes('Most Expected Questions by Om Pandey'));
  assert.ok(!inorganicMats.includes('Motikitab NEET'));
  assert.ok(!inorganicMats.includes('Motikitab JEE Mains'));

  const physicalMats = getChapterMaterials('chem', 'Thermodynamics & Thermochemistry');
  assert.ok(physicalMats.includes('Motikitab NEET'));
  assert.ok(physicalMats.includes('Motikitab JEE Mains'));
  assert.ok(!physicalMats.includes('Goat Sheet by Om Pandey'));
});

test('mergeTrackerData losslessly merges local and cloud progress on sign-in or update', () => {
  const local = {
    statusStore: {
      'phy|Vectors|Class Questions': 'done' as const,
      'phy|Vectors|Module': 'partial' as const,
    },
    subItemStore: {
      phy: {
        Vectors: {
          Lectures: [
            { name: 'Lecture 1', done: true },
            { name: 'Lecture 2', done: false },
          ],
        },
      },
    },
    startedStore: {
      phy: ['Vectors'],
    },
    streak: { n: 3, d: '2026-10-24' },
    testStore: {},
    targetDate: '2027-05-04',
  };

  const cloud = {
    statusStore: {
      'phy|Vectors|Module': 'done' as const,
      'chem|Chemical Bonding and Molecular Structure|Goat Sheet by Om Pandey': 'done' as const,
    },
    subItemStore: {
      phy: {
        Vectors: {
          Lectures: [
            { name: 'Lecture 1', done: false },
            { name: 'Lecture 2', done: true },
          ],
        },
      },
    },
    startedStore: {
      chem: ['Chemical Bonding and Molecular Structure'],
    },
    streak: { n: 2, d: '2026-10-23' },
    testStore: {
      nbts01: { s: 1, p: 170, c: 165, b: 350, t: 685 },
    },
    targetDate: '2027-05-02',
  };

  const merged = mergeTrackerData(local, cloud);

  // Keeps highest status between local and cloud
  assert.equal(merged.statusStore['phy|Vectors|Class Questions'], 'done');
  assert.equal(merged.statusStore['phy|Vectors|Module'], 'done');
  assert.equal(
    merged.statusStore['chem|Chemical Bonding and Molecular Structure|Goat Sheet by Om Pandey'],
    'done'
  );

  // Merges sub-items so both Lecture 1 and Lecture 2 are marked done -> Lectures status becomes 'done'
  assert.deepEqual(merged.subItemStore.phy.Vectors.Lectures, [
    { name: 'Lecture 1', done: true },
    { name: 'Lecture 2', done: true },
  ]);
  assert.equal(merged.statusStore['phy|Vectors|Lectures'], 'done');

  // Unions started chapters across subjects
  assert.deepEqual(merged.startedStore.phy, ['Vectors']);
  assert.deepEqual(merged.startedStore.chem, ['Chemical Bonding and Molecular Structure']);

  // Preserves newer streak and custom target date
  assert.deepEqual(merged.streak, { n: 3, d: '2026-10-24' });
  assert.equal(merged.targetDate, '2027-05-02');
  assert.equal(merged.testStore.nbts01?.t, 685);
});

