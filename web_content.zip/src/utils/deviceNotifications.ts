/**
 * KBSSN Native Mobile Device Notifications Service
 * Integrates Web Notifications API and Service Worker Notifications
 * to deliver native push-style alerts to the phone's notification tray.
 */

const NOTIF_PREF_KEY = 'kbssn_device_notifications_enabled';

export type NotificationPermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

export interface DeviceNotificationPayload {
  title: string;
  body: string;
  type?: 'homework' | 'note' | 'announcement' | 'general';
  tag?: string;
  url?: string;
}

class DeviceNotificationManager {
  /**
   * Check if the browser / mobile environment supports Notifications
   */
  public isSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return 'Notification' in window && 'serviceWorker' in navigator;
  }

  /**
   * Current notification permission status
   */
  public getPermission(): NotificationPermissionState {
    if (!this.isSupported()) return 'unsupported';
    return Notification.permission as NotificationPermissionState;
  }

  /**
   * Check if user has explicitly enabled notifications in app preferences
   */
  public isUserEnabled(): boolean {
    try {
      const stored = localStorage.getItem(NOTIF_PREF_KEY);
      if (stored === null) {
        // Defaults to true if system permission is already granted
        return this.getPermission() === 'granted';
      }
      return stored === 'true';
    } catch {
      return false;
    }
  }

  public setUserEnabled(enabled: boolean): void {
    try {
      localStorage.setItem(NOTIF_PREF_KEY, enabled ? 'true' : 'false');
    } catch {
      // ignore
    }
  }

  /**
   * Prompt user for notification permission in their mobile browser
   */
  public async requestPermission(): Promise<NotificationPermissionState> {
    if (!this.isSupported()) {
      return 'unsupported';
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        this.setUserEnabled(true);
      } else {
        this.setUserEnabled(false);
      }
      return permission as NotificationPermissionState;
    } catch (err) {
      console.warn('[DeviceNotification] Error requesting permission:', err);
      return this.getPermission();
    }
  }

  /**
   * Send native notification to the phone's notification shade / tray
   */
  public async sendNotification(payload: DeviceNotificationPayload): Promise<boolean> {
    if (!this.isSupported()) return false;
    if (this.getPermission() !== 'granted') return false;
    if (!this.isUserEnabled()) return false;

    const iconUrl = '/pwa-192x192.png';
    const tag = payload.tag || `kbssn-${payload.type || 'alert'}-${Date.now()}`;

    try {
      // 1. Prefer Service Worker registration (native mobile status bar banner)
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        if (registration && 'showNotification' in registration) {
          await (registration as any).showNotification(payload.title, {
            body: payload.body,
            icon: iconUrl,
            badge: iconUrl,
            tag,
            vibrate: [200, 100, 200],
            data: {
              url: payload.url || window.location.origin,
              timestamp: Date.now(),
            },
          });
          return true;
        }
      }

      // 2. Fallback to standard Window Notification
      const notif = new Notification(payload.title, {
        body: payload.body,
        icon: iconUrl,
        badge: iconUrl,
        tag,
      });

      notif.onclick = () => {
        window.focus();
        notif.close();
      };

      return true;
    } catch (err) {
      console.warn('[DeviceNotification] Could not display system notification:', err);
      return false;
    }
  }

  /**
   * Send an immediate test alert to verify the phone's notification bar
   */
  public async sendTestNotification(): Promise<boolean> {
    const perm = await this.requestPermission();
    if (perm !== 'granted') return false;

    return this.sendNotification({
      title: 'KBSSN • Mobile Notification Active',
      body: '🔔 Device notifications are verified! You will now receive instant alerts for new class notes, homework, and notices on your phone.',
      type: 'general',
      tag: 'kbssn-test',
    });
  }
}

export const DeviceNotifications = new DeviceNotificationManager();
