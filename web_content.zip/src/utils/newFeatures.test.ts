import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createInitialSrsCard,
  formatIntervalAr,
  getSrsStats,
  orderPoolForSrs,
  previewSrsIntervals,
  reviewSrsCard,
} from './srsLogic';
import {
  buildErrorDetectionRound,
  buildErrorQuestionFromSentence,
  buildSentenceOrderQuestion,
  buildSentenceOrderRound,
  checkSentenceOrder,
  tokenizeSentenceForOrder,
} from './sentenceGamesLogic';

test('Anki SRS reviewSrsCard transitions across all 4 ratings cleanly', () => {
  const now = 1_700_000_000_000;
  const init = createInitialSrsCard(10, now);

  // Good on new card -> 1 day, rep 1
  const r1 = reviewSrsCard(init, 10, 'good', now);
  assert.equal(r1.intervalDays, 1);
  assert.equal(r1.repetitions, 1);
  assert.ok(r1.dueAt > now);

  // Good again -> 6 days, rep 2
  const r2 = reviewSrsCard(r1, 10, 'good', now);
  assert.equal(r2.intervalDays, 6);
  assert.equal(r2.repetitions, 2);

  // Easy -> grows interval & increases ease factor
  const r3 = reviewSrsCard(r2, 10, 'easy', now);
  assert.ok(r3.intervalDays > r2.intervalDays);
  assert.ok(r3.easeFactor > r2.easeFactor);

  // Again -> resets repetitions to 0, increments lapses, interval 0 (< 10 min)
  const rFail = reviewSrsCard(r3, 10, 'again', now);
  assert.equal(rFail.repetitions, 0);
  assert.equal(rFail.lapses, 1);
  assert.equal(rFail.intervalDays, 0);
  assert.equal(formatIntervalAr(rFail.intervalDays), '< 10 دقائق');

  const previews = previewSrsIntervals(init, 10, now);
  assert.equal(previews.again, '< 10 دقائق');
  assert.equal(previews.good, 'يوم واحد');
  assert.equal(previews.easy, '4 أيام');
});

test('orderPoolForSrs puts due cards first, then unseen, then upcoming', () => {
  const now = 1_700_000_000_000;
  const srsCards = {
    1: { ...createInitialSrsCard(1, now), dueAt: now + 86_400_000, lastReviewedAt: now - 1000 },
    2: { ...createInitialSrsCard(2, now), dueAt: now - 5_000, lastReviewedAt: now - 10_000 },
    3: { ...createInitialSrsCard(3, now), dueAt: now - 50_000, lastReviewedAt: now - 60_000 },
  };
  const ordered = orderPoolForSrs([1, 2, 3, 4], srsCards, now);
  // 3 (most overdue), 2 (overdue), 4 (unseen), 1 (upcoming)
  assert.deepEqual(ordered, [3, 2, 4, 1]);

  const stats = getSrsStats(srsCards, now);
  assert.equal(stats.totalTracked, 3);
  assert.equal(stats.dueNow, 2);
});

test('Sentence ordering builds shuffled tiles and checks exact order', () => {
  const q = buildSentenceOrderQuestion(
    { id: 1, num: 1, en: 'I love learning English every day.' },
    'أحب تعلم الإنجليزية كل يوم.',
    42
  );
  assert.ok(q);
  assert.deepEqual(q.targetWords, ['I', 'love', 'learning', 'English', 'every', 'day']);
  assert.equal(q.tiles.length, 6);
  assert.equal(checkSentenceOrder(q.targetWords, q.targetWords), true);
  assert.equal(
    checkSentenceOrder(['love', 'I', 'learning', 'English', 'every', 'day'], q.targetWords),
    false
  );
  assert.deepEqual(tokenizeSentenceForOrder("Don't forget your passport!"), [
    "Don't",
    'forget',
    'your',
    'passport',
  ]);
});

test('Sentence error detection always produces 4 distinct underlined words with 1 error', () => {
  const round = buildErrorDetectionRound(30, 'all', 123);
  assert.ok(round.length >= 25);

  for (const q of round) {
    assert.equal(q.underlinedIndices.length, 4);
    assert.equal(new Set(q.underlinedIndices).size, 4, 'Must have 4 unique underlined indices');
    assert.ok(
      q.underlinedIndices.includes(q.errorIndex),
      'errorIndex must be one of the 4 underlined indices'
    );
    assert.ok(q.explanationAr.length > 5);
    assert.ok(q.ar.length > 3);
  }

  // Verify all 3 error categories are represented
  const types = new Set(round.map((q) => q.errorType));
  assert.ok(types.has('grammar'));
  assert.ok(types.has('spelling'));
  assert.ok(types.has('meaning'));

  // Test dynamic generator on arbitrary corpus sentence
  const dyn = buildErrorQuestionFromSentence(
    'She is reading a very interesting book in the garden.',
    'هي تقرأ كتاباً ممتعاً جداً في الحديقة.',
    99
  );
  assert.ok(dyn);
  assert.equal(dyn.underlinedIndices.length, 4);
  assert.ok(dyn.underlinedIndices.includes(dyn.errorIndex));
  assert.equal(dyn.errorType, 'grammar');
});

test('buildSentenceOrderRound returns a full round of valid shuffled sentences with Arabic translations', () => {
  const round = buildSentenceOrderRound(10, 777);
  assert.equal(round.length, 10);
  for (const q of round) {
    assert.ok(q.targetWords.length >= 4, `Expected >= 4 words, got ${q.targetWords.length}`);
    assert.equal(q.tiles.length, q.targetWords.length);
    assert.ok(q.ar.trim().length > 5);
    assert.equal(
      checkSentenceOrder(q.targetWords, q.targetWords),
      true
    );
  }
});

