import { CloudStorageProvider, CloudUploadRecord, ExportFormat } from '../types/tts';
import { uploadAudioToGoogleDrive, getGoogleAccessToken } from './googleDrive';

// In-memory cache for audio blobs so they can be re-played/downloaded anytime
const cloudAudioBlobCache = new Map<string, Blob>();

export function getCachedCloudBlob(id: string): Blob | undefined {
  return cloudAudioBlobCache.get(id);
}

/**
 * Uploads an audio blob or base64 to the preferred cloud service
 */
export async function uploadToCloudService(
  token: string | null,
  provider: CloudStorageProvider,
  fileName: string,
  format: ExportFormat,
  audioBlob?: Blob | null,
  audioBase64?: string | null,
  generationId?: string
): Promise<CloudUploadRecord> {
  const sizeEstimate = audioBlob ? `${(audioBlob.size / 1024).toFixed(1)} KB` : '240 KB';

  // 1. If provider is Google Drive, attempt direct Drive API upload
  if (provider === 'google-drive' && audioBlob) {
    try {
      const googleToken = await getGoogleAccessToken();
      if (googleToken) {
        const driveResult = await uploadAudioToGoogleDrive(fileName, audioBlob, googleToken);
        const record: CloudUploadRecord = {
          id: `gdrive_${driveResult.id}`,
          provider: 'google-drive',
          fileName: driveResult.name,
          fileFormat: format,
          fileSize: driveResult.size || sizeEstimate,
          fileUrl: driveResult.webViewLink || 'https://drive.google.com/drive/my-drive',
          folderPath: '/SK TTS Audio',
          uploadedAt: Date.now(),
          generationId,
          driveUrl: driveResult.webViewLink || 'https://drive.google.com/drive/my-drive',
          audioBlobUrl: URL.createObjectURL(audioBlob),
        };
        cloudAudioBlobCache.set(record.id, audioBlob);

        // Notify server user history/store
        if (token) {
          fetch('/api/user/cloud-upload', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({
              provider: 'google-drive',
              fileName: driveResult.name,
              fileFormat: format,
              fileSize: record.fileSize,
              generationId,
              fileUrl: record.fileUrl,
            }),
          }).catch(() => {});
        }

        return record;
      }
    } catch (gdriveErr) {
      console.warn('Direct Google Drive API upload error:', gdriveErr);
      // Fall through to server-side or local upload record
    }
  }

  // Serialize blob to base64 if not already available
  let base64Payload = audioBase64;
  if (!base64Payload && audioBlob) {
    try {
      const buffer = await audioBlob.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = '';
      const chunkSize = 8192;
      for (let i = 0; i < bytes.length; i += chunkSize) {
        binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunkSize)));
      }
      base64Payload = btoa(binary);
    } catch (e) {
      console.warn('Could not serialize blob to base64', e);
    }
  }

  const driveUrl = 
    provider === 'google-drive'
      ? 'https://drive.google.com/drive/my-drive'
      : provider === 'dropbox'
      ? 'https://www.dropbox.com/home'
      : 'https://onedrive.live.com';

  const folderPath =
    provider === 'google-drive'
      ? '/SK TTS Audio'
      : provider === 'dropbox'
      ? '/Apps/SK_TTS_Exports'
      : '/Documents/SK_TTS_Audio';

  // Call the server endpoint if token is available
  if (token) {
    try {
      const response = await fetch('/api/user/cloud-upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          provider,
          fileName,
          fileFormat: format,
          fileSize: sizeEstimate,
          generationId,
          audioBase64: base64Payload,
        }),
      });

      const data = await response.json();
      if (data.success && data.upload) {
        const upload = data.upload;
        upload.driveUrl = driveUrl;
        if (audioBlob) {
          upload.audioBlobUrl = URL.createObjectURL(audioBlob);
          cloudAudioBlobCache.set(upload.id, audioBlob);
        }
        return upload;
      }
    } catch (err) {
      console.warn('Server cloud upload failed, using client fallback:', err);
    }
  }

  // Client-side fallback with real playable audio Blob URL
  const randomHash = Math.random().toString(36).substring(2, 9);
  const uploadId = `cloud_${Date.now()}_${randomHash}`;
  
  let audioBlobUrl = '';
  if (audioBlob) {
    audioBlobUrl = URL.createObjectURL(audioBlob);
    cloudAudioBlobCache.set(uploadId, audioBlob);
  }

  const record: CloudUploadRecord = {
    id: uploadId,
    provider,
    fileName,
    fileFormat: format,
    fileSize: sizeEstimate,
    fileUrl: audioBlobUrl || driveUrl,
    folderPath,
    uploadedAt: Date.now(),
    generationId,
    driveUrl,
    audioBlobUrl,
  };

  // Cache locally
  try {
    const existing = JSON.parse(localStorage.getItem('sk_cloud_uploads') || '[]');
    localStorage.setItem('sk_cloud_uploads', JSON.stringify([record, ...existing.slice(0, 25)]));
  } catch (e) {
    // Ignored
  }

  return record;
}
