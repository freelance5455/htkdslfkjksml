/**
 * Cryptographic helpers for secure password hashing and verification.
 * Adheres strictly to the requirement that company access passwords/codes
 * are NEVER stored or exposed in plaintext.
 */

export async function hashCompanyPassword(
  password: string,
  existingSalt?: string
): Promise<{ hash: string; salt: string }> {
  const salt = existingSalt || generateSalt();
  const encoder = new TextEncoder();
  const data = encoder.encode(`${salt}:${password.trim()}`);

  const cryptoObj = typeof window !== 'undefined' ? window.crypto : (globalThis as any).crypto;
  const hashBuffer = await cryptoObj.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hash = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');

  return { hash, salt };
}

export async function verifyCompanyPassword(
  inputPassword: string,
  storedHash: string,
  salt: string
): Promise<boolean> {
  if (!inputPassword || !storedHash || !salt) return false;
  const { hash } = await hashCompanyPassword(inputPassword, salt);
  return hash === storedHash;
}

export function generateSalt(byteLength: number = 16): string {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : (globalThis as any).crypto;
  const bytes = new Uint8Array(byteLength);
  cryptoObj.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}
