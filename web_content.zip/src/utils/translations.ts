import { Language } from '../types';

export const translations = {
  en: {
    appName: "E SPORTS TOUR",
    developerBy: "Developed by X SABBIR",
    home: "Home",
    tournaments: "Tournaments",
    myMatches: "My Matches",
    results: "Results",
    leaderboard: "Leaderboard",
    wallet: "Wallet",
    profile: "Profile",
    support: "Help & Support",
    notifications: "Notifications",
    terms: "Terms & Conditions",
    privacy: "Privacy Policy",
    responsibleGaming: "Responsible Gaming",
    adminDashboard: "Admin Suite",
    
    // Balance cards
    totalBalance: "Total Balance",
    winningsBalance: "Winnings Balance",
    depositBalance: "Deposit Balance",
    bonusCoins: "Bonus Coins",
    addMoney: "Add Money",
    withdraw: "Withdraw",
    allTransactions: "Transactions",
    
    // Tournaments
    featuredTournaments: "Featured Tournaments",
    allCategories: "All Matches",
    solo: "Solo",
    duo: "Duo",
    squad: "Squad",
    clashSquad: "CS 4v4",
    prizePool: "Prize Pool",
    entryFee: "Entry Fee",
    perKill: "Per Kill",
    type: "Type",
    map: "Map",
    version: "Perspective",
    time: "Schedule",
    spotsLeft: "Spots Left",
    joinNow: "Join Tournament",
    joined: "Registered",
    viewDetails: "Match Details",
    matchStatusUpcoming: "Upcoming",
    matchStatusOngoing: "Live Now",
    matchStatusCompleted: "Completed",
    
    // Room ID
    roomId: "Custom Room ID",
    roomPassword: "Password",
    copyRoom: "Copy Room ID",
    copyPass: "Copy Password",
    roomGuide: "Enter Free Fire > Custom > Join Room with these credentials 10 mins before start.",
    roomHidden: "Room ID & Password unlocks 15 minutes before match start for registered participants.",
    
    // WhatsApp Support
    contactWhatsApp: "Contact Support on WhatsApp",
    supportNumber: "Support Hotline",
    supportSubtext: "Immediate assistance with deposits, withdrawals, room access, or disputed results.",
    openWhatsApp: "Open WhatsApp Chat",
    openBrowser: "Open in Web Browser",
    
    // Auth & General
    login: "Log In",
    register: "Create Account",
    logout: "Log Out",
    ffIgnLabel: "Free Fire In-Game Name (IGN)",
    ffUidLabel: "Free Fire Player UID",
    phoneLabel: "Mobile Number (bKash/Nagad)",
    
    // Load Testing
    loadTestingTitle: "100K Concurrent User Verification",
    runStressTest: "Simulate 100K Concurrent Traffic",
  },
  bn: {
    appName: "E SPORTS TOUR",
    developerBy: "ডেভেলপার: X SABBIR",
    home: "হোম",
    tournaments: "টুর্নামেন্ট",
    myMatches: "আমার ম্যাচ",
    results: "ফলাফল",
    leaderboard: "লিডারবোর্ড",
    wallet: "ওয়ালেট",
    profile: "প্রোফাইল",
    support: "হেল্প ও সাপোর্ট",
    notifications: "নোটিফিকেশন",
    terms: "শর্তাবলী ও নিয়ম",
    privacy: "প্রাইভেসি পলিসি",
    responsibleGaming: "দায়িত্বশীল গেমিং",
    adminDashboard: "অ্যাডমিন প্যানেল",
    
    // Balance cards
    totalBalance: "মোট ব্যালেন্স",
    winningsBalance: "উইনিং ব্যালেন্স",
    depositBalance: "ডিপোজিট ব্যালেন্স",
    bonusCoins: "বোনাস কয়েন",
    addMoney: "টাকা জমা দিন",
    withdraw: "উইথড্র করুন",
    allTransactions: "লেনদেন হিস্ট্রি",
    
    // Tournaments
    featuredTournaments: "ফিচার্ড টুর্নামেন্ট",
    allCategories: "সকল ম্যাচ",
    solo: "সোলো",
    duo: "ডুও",
    squad: "স্কোয়াড",
    clashSquad: "সিএস ৪ বনাম ৪",
    prizePool: "পুরস্কার পুল",
    entryFee: "এন্ট্রি ফি",
    perKill: "প্রতি কিল",
    type: "ধরণ",
    map: "ম্যাপ",
    version: "ভিউ মোড",
    time: "সময়সূচী",
    spotsLeft: "বাকি স্লট",
    joinNow: "অংশগ্রহণ করুন",
    joined: "রেজিস্টার্ড",
    viewDetails: "ম্যাচ বিস্তারিত",
    matchStatusUpcoming: "আসন্ন",
    matchStatusOngoing: "চলমান",
    matchStatusCompleted: "সম্পন্ন",
    
    // Room ID
    roomId: "কাস্টম রুম আইডি",
    roomPassword: "পাসওয়ার্ড",
    copyRoom: "রুম আইডি কপি করুন",
    copyPass: "পাসওয়ার্ড কপি করুন",
    roomGuide: "ফ্রি ফায়ারে যান > কাস্টম > ম্যাচ শুরুর ১০ মিনিট পূর্বে রুম আইডি ও পাসওয়ার্ড দিন।",
    roomHidden: "রেজিস্টার্ড প্লেয়ারদের জন্য ম্যাচ শুরুর ১৫ মিনিট পূর্বে রুম আইডি ও পাসওয়ার্ড প্রকাশ করা হয়।",
    
    // WhatsApp Support
    contactWhatsApp: "হোয়াটসঅ্যাপে সাপোর্ট নিন",
    supportNumber: "সাপোর্ট হেল্পলাইন",
    supportSubtext: "ডিপোজিট, উইথড্র, রুম এক্সেস বা যেকোনো সমস্যায় তাৎক্ষণিক সহায়তা পান।",
    openWhatsApp: "হোয়াটসঅ্যাপ চ্যাট খুলুন",
    openBrowser: "ব্রাউজারে খুলুন",
    
    // Auth & General
    login: "লগইন",
    register: "অ্যাকাউন্ট খুলুন",
    logout: "লগআউট",
    ffIgnLabel: "ফ্রি ফায়ার গেমের নাম (IGN)",
    ffUidLabel: "ফ্রি ফায়ার প্লেয়ার ইউআইডি (UID)",
    phoneLabel: "মোবাইল নম্বর (বিকাশ/নগদ)",
    
    // Load Testing
    loadTestingTitle: "১০০,০০০ কনকারেন্ট ইউজার ভেরিফিকেশন",
    runStressTest: "১০০কে ট্রাফিক সিমুলেশন চালু করুন",
  }
};

export const getTranslation = (lang: Language, key: keyof typeof translations['en']): string => {
  return translations[lang][key] || translations['en'][key] || '';
};
