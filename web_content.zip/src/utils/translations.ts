export type Language = 'en' | 'hinglish' | 'hi';

export interface Translations {
  // Common & Navigation
  appName: string;
  tagline: string;
  home: string;
  explore: string;
  add: string;
  chat: string;
  games: string;
  profile: string;
  referral: string;
  leaderboard: string;
  back: string;
  backToFeeds: string;
  searchPlaceholder: string;
  verify: string;
  coins: string;
  exitFrame: string;
  smartphoneMode: string;
  safetyConsole: string;
  rnGuide: string;

  // Language screen
  selectLanguageTitle: string;
  selectLanguageSubtitle: string;
  continueBtn: string;

  // Auth / Onboarding
  createIdTab: string;
  loginTab: string;
  personaTitle: string;
  reroll: string;
  phoneNumber: string;
  phonePlaceholder: string;
  emailAddress: string;
  emailPlaceholder: string;
  password: string;
  passwordPlaceholder: string;
  collegeCode: string;
  collegeCodePlaceholder: string;
  chooseCollegeHint: string;
  classInfo: string;
  classInfoPlaceholder: string;
  privacyPledge: string;
  createIdBtn: string;
  loginBtn: string;
  instantDemoLogin: string;
  orQuickTesting: string;
  alreadyHaveAccount: string;
  needAccount: string;

  // Feeds
  trending: string;
  latest: string;
  myCampus: string;
  saved: string;
  allWhispers: string;
  secrets: string;
  love: string;
  funny: string;
  stress: string;
  hottake: string;
  campusLife: string;
  dropSecret: string;
  dailyThemeTitle: string;
  dailyThemeDesc: string;
  whisperCTA: string;
  noWhispersFound: string;
  noWhispersSub: string;

  // Confession Card
  anonymous: string;
  comments: string;
  share: string;
  report: string;
  directWhisper: string;
  writeComment: string;
  sendComment: string;
  boosted: string;

  // Create Confession
  createWhisperTitle: string;
  createWhisperSub: string;
  confessionPlaceholder: string;
  campusOnlyToggle: string;
  campusOnlySub: string;
  publishBtn: string;
  cancel: string;

  // Referral Engine
  referralTitle: string;
  referralSubtitle: string;
  yourDeepLink: string;
  copyLink: string;
  linkCopied: string;
  whatsappInvite: string;
  telegramInvite: string;
  testSimulateInvite: string;
  exclusiveBadges: string;
  rewardsShop: string;
  friendsInvited: string;
  balance: string;

  // Profile
  myAnonymousId: string;
  karma: string;
  secretCoins: string;
  inviteAndEarn: string;
  logout: string;
  currentCollege: string;
  batchInfo: string;
  unlockedBadges: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  en: {
    appName: 'Secret Gossip',
    tagline: 'Where campus secrets find a voice.',
    home: 'Home',
    explore: 'Explore',
    add: 'Add',
    chat: 'Chat',
    games: 'Games',
    profile: 'Profile',
    referral: 'Refer & Earn',
    leaderboard: 'Hall of Fame',
    back: 'Back',
    backToFeeds: 'Back to Feeds',
    searchPlaceholder: 'Search secrets, campus crushes & banter...',
    verify: 'Verify Campus',
    coins: 'Coins',
    exitFrame: 'Exit Frame',
    smartphoneMode: 'Smartphone Device Shell Active',
    safetyConsole: 'Safety Console',
    rnGuide: 'React Native APK Guide',
    selectLanguageTitle: 'Choose Your Language',
    selectLanguageSubtitle: 'Select how you want to experience Secret Gossip across campus.',
    continueBtn: 'Continue with',
    createIdTab: 'Create Anonymous ID',
    loginTab: 'Sign In (Login)',
    personaTitle: 'Your Disguise Persona',
    reroll: 'Reroll',
    phoneNumber: 'Phone Number',
    phonePlaceholder: '+91 98765 43210',
    emailAddress: 'College / Personal Email',
    emailPlaceholder: 'student@university.edu',
    password: 'Password',
    passwordPlaceholder: 'At least 6 characters',
    collegeCode: 'College Code',
    collegeCodePlaceholder: 'e.g. DU-NORTH or IITD-2026',
    chooseCollegeHint: 'Tap below to select',
    classInfo: 'Class / Degree Info',
    classInfoPlaceholder: "e.g. B.Tech Computer Science '26",
    privacyPledge: 'Zero-Knowledge Privacy: Your email & phone are one-way hashed. Professors & college admins can never trace your name.',
    createIdBtn: 'Create ID & Enter Secret Gossip',
    loginBtn: 'Login to Account',
    instantDemoLogin: '1-Click Instant Student Demo Login',
    orQuickTesting: 'OR QUICK TESTING',
    alreadyHaveAccount: 'Already have an ID? Login',
    needAccount: 'New student? Create your ID',
    trending: 'Trending 🔥',
    latest: 'Latest ⏱️',
    myCampus: 'My Campus 🎓',
    saved: 'Saved 🔖',
    allWhispers: 'All Whispers',
    secrets: 'Secrets 🤫',
    love: 'Love ❤️',
    funny: 'Funny 😂',
    stress: 'Study Stress 📚',
    hottake: 'Hot Takes 🔥',
    campusLife: 'Campus Life 🏛️',
    dropSecret: 'Drop a Secret',
    dailyThemeTitle: 'Campus Theme: Funny Friday',
    dailyThemeDesc: "What's the funniest blunder you saw in the campus mess or lecture?",
    whisperCTA: 'Whisper',
    noWhispersFound: 'No whispers found in this filter.',
    noWhispersSub: 'Be the first student to drop an anonymous confession in this category!',
    anonymous: 'Anonymous Student',
    comments: 'Comments',
    share: 'Share',
    report: 'Report',
    directWhisper: 'Direct Whisper',
    writeComment: 'Reply anonymously...',
    sendComment: 'Reply',
    boosted: 'BOOSTED #1 🚀',
    createWhisperTitle: 'Whisper a Confession',
    createWhisperSub: '100% anonymous • Zero tracking • Masked identity',
    confessionPlaceholder: 'Confess what happened in the canteen, library, hostel or exam...',
    campusOnlyToggle: 'Campus-Only Visibility',
    campusOnlySub: 'Restricts post to verified students in your college',
    publishBtn: 'Publish Whisper',
    cancel: 'Cancel',
    referralTitle: 'Campus Referral Engine',
    referralSubtitle: 'Invite college friends to join your private campus feed and earn Secret Coins & VIP badges!',
    yourDeepLink: 'Your Unique Campus Deep-Link',
    copyLink: 'Copy Link',
    linkCopied: 'Copied Link!',
    whatsappInvite: 'WhatsApp Invite',
    telegramInvite: 'Telegram Channel',
    testSimulateInvite: 'Test Simulate Invite (+100 🪙)',
    exclusiveBadges: 'Exclusive Profile Badges & Milestones',
    rewardsShop: 'Secret Coins Rewards Shop',
    friendsInvited: 'Friends Invited',
    balance: 'Balance',
    myAnonymousId: 'My Anonymous ID',
    karma: 'Total Karma',
    secretCoins: 'Secret Coins',
    inviteAndEarn: 'Invite & Earn 🎁',
    logout: 'Switch / Logout Account',
    currentCollege: 'Verified Campus',
    batchInfo: 'Batch & Degree',
    unlockedBadges: 'Unlocked Badges',
  },
  hinglish: {
    appName: 'Secret Gossip',
    tagline: 'Jahan campus gossip aur secrets ko aawaz milti hai.',
    home: 'Home',
    explore: 'Explore',
    add: 'Add Karein',
    chat: 'Rooms',
    games: 'Arcade',
    profile: 'Profile',
    referral: 'Coins Jeeto',
    leaderboard: 'Rankings',
    back: 'Peeche',
    backToFeeds: 'Wapas Feeds Par',
    searchPlaceholder: 'Secrets, crush aur campus banter search karein...',
    verify: 'College Verify',
    coins: 'Coins',
    exitFrame: 'Frame Hatayein',
    smartphoneMode: 'Mobile Device Mode On Hai',
    safetyConsole: 'Safety Console',
    rnGuide: 'React Native APK Guide',
    selectLanguageTitle: 'Apni Pasand Ki Bhasha Chunein',
    selectLanguageSubtitle: 'Secret Gossip ko kis bhasha mein use karna chahte hain?',
    continueBtn: 'Aage Badhein',
    createIdTab: 'Nayi ID Banaye (Sign Up)',
    loginTab: 'Login Karein (Sign In)',
    personaTitle: 'Aapka Secret Mask (Disguise)',
    reroll: 'Badlein (Reroll)',
    phoneNumber: 'Mobile Phone Number',
    phonePlaceholder: '+91 98765 43210',
    emailAddress: 'College / Personal Email',
    emailPlaceholder: 'student@university.edu',
    password: 'Password',
    passwordPlaceholder: 'Kam se kam 6 characters',
    collegeCode: 'College Code',
    collegeCodePlaceholder: 'jaise DU-NORTH ya IITD-2026',
    chooseCollegeHint: 'Neeche se tap karke chunein',
    classInfo: 'Class / Course aur Year',
    classInfoPlaceholder: "jaise B.Tech Computer Science '26",
    privacyPledge: 'Zero-Knowledge Privacy: Aapka email aur phone hash ho jata hai. Kisi bhi professor ya admin ko aapka asli naam nahi dikhega.',
    createIdBtn: 'ID Banaye & Campus Mein Ghusein',
    loginBtn: 'Account Mein Login Karein',
    instantDemoLogin: '1-Click Instant Student Demo Login',
    orQuickTesting: 'YA DIRECT TESTING KE LIYE',
    alreadyHaveAccount: 'Pehle se ID hai? Login karein',
    needAccount: 'Naye student hain? ID banayein',
    trending: 'Trending 🔥',
    latest: 'Latest ⏱️',
    myCampus: 'Apna College 🎓',
    saved: 'Saved 🔖',
    allWhispers: 'Sabhi Secrets',
    secrets: 'Secrets 🤫',
    love: 'Crush & Love ❤️',
    funny: 'Komedie 😂',
    stress: 'Padhai Ka Stress 📚',
    hottake: 'Hot Takes 🔥',
    campusLife: 'Hostel & Campus 🏛️',
    dropSecret: 'Secret Post Karein',
    dailyThemeTitle: 'Friday Masti: Campus Comedy',
    dailyThemeDesc: 'Canteen, mess ya lecture hall ka sabse funny kaand yahan confess karein!',
    whisperCTA: 'Whisper',
    noWhispersFound: 'Is category mein koi secret nahi mila.',
    noWhispersSub: 'Sabse pehle aap hi secret whisper post karke shuruat karein!',
    anonymous: 'Anonymous Student',
    comments: 'Replies',
    share: 'Share',
    report: 'Report',
    directWhisper: 'Direct DM',
    writeComment: 'Anonymous reply likhein...',
    sendComment: 'Bhejein',
    boosted: 'BOOSTED #1 🚀',
    createWhisperTitle: 'Apna Secret Whisper Karein',
    createWhisperSub: '100% anonymous • Zero tracking • Masked identity',
    confessionPlaceholder: 'Canteen, library, hostel ya exam ka koi bhi secret likhein...',
    campusOnlyToggle: 'Sirf Apne College Ko Dikhana Hai',
    campusOnlySub: 'Post sirf aapke college ke verified students ko dikhega',
    publishBtn: 'Secret Post Karein 🚀',
    cancel: 'Cancel',
    referralTitle: 'Campus Referral Engine',
    referralSubtitle: 'College ke dosto ko invite karein, Secret Coins kamayein aur exclusive VIP badges unlock karein!',
    yourDeepLink: 'Aapka Unique Campus Deep-Link',
    copyLink: 'Link Copy Karein',
    linkCopied: 'Link Copy Ho Gaya!',
    whatsappInvite: 'WhatsApp Par Bhejein',
    telegramInvite: 'Telegram Channel',
    testSimulateInvite: 'Invite Test Karein (+100 🪙)',
    exclusiveBadges: 'Exclusive Profile Badges & Milestones',
    rewardsShop: 'Secret Coins Reward Dukaan',
    friendsInvited: 'Dost Jo Join Hue',
    balance: 'Coins Balance',
    myAnonymousId: 'Mera Anonymous Identity',
    karma: 'Total Karma Score',
    secretCoins: 'Secret Coins',
    inviteAndEarn: 'Dosto Ko Bulao 🎁',
    logout: 'Switch / Logout Karein',
    currentCollege: 'Verified College',
    batchInfo: 'Batch aur Degree',
    unlockedBadges: 'Unlocked Badges',
  },
  hi: {
    appName: 'Secret Gossip',
    tagline: 'जहाँ कैंपस के सीक्रेट्स को आवाज़ मिलती है।',
    home: 'होम',
    explore: 'एक्सप्लोर',
    add: 'पोस्ट करें',
    chat: 'कमरे',
    games: 'गेम्स',
    profile: 'प्रोफाइल',
    referral: 'सिक्के कमाएं',
    leaderboard: 'रैंकिंग',
    back: 'पीछे',
    backToFeeds: 'वापस फीड पर',
    searchPlaceholder: 'सीक्रेट्स, क्रश और बातें खोजें...',
    verify: 'कॉलेज वेरीफाई करें',
    coins: 'सिक्के',
    exitFrame: 'फ़्रेम हटाएं',
    smartphoneMode: 'मोबाइल डिवाइस मोड सक्रिय',
    safetyConsole: 'सुरक्षा कंसोल',
    rnGuide: 'रिएक्ट नेटिव गाइड',
    selectLanguageTitle: 'अपनी भाषा चुनें',
    selectLanguageSubtitle: 'आप सीक्रेट गॉसिप को किस भाषा में इस्तेमाल करना चाहते हैं?',
    continueBtn: 'आगे बढ़ें',
    createIdTab: 'आईडी बनाएं (साइन अप)',
    loginTab: 'लॉग इन करें',
    personaTitle: 'आपका गुप्त मुखौटा',
    reroll: 'बदलें',
    phoneNumber: 'फ़ोन नंबर',
    phonePlaceholder: '+91 98765 43210',
    emailAddress: 'कॉलेज / पर्सनल ईमेल',
    emailPlaceholder: 'student@university.edu',
    password: 'पासवर्ड',
    passwordPlaceholder: 'कम से कम 6 अक्षर',
    collegeCode: 'कॉलेज कोड',
    collegeCodePlaceholder: 'जैसे DU-NORTH या IITD-2026',
    chooseCollegeHint: 'चुनने के लिए नीचे टैप करें',
    classInfo: 'कक्षा / कोर्स और वर्ष',
    classInfoPlaceholder: "जैसे B.Tech Computer Science '26",
    privacyPledge: 'जीरो-नॉलेज प्राइवेसी: आपका ईमेल और फोन हैश हो जाता है। किसी भी प्रोफेसर या एडमिन को आपका असली नाम नहीं दिखेगा।',
    createIdBtn: 'आईडी बनाएं और प्रवेश करें',
    loginBtn: 'अकाउंट में लॉग इन करें',
    instantDemoLogin: '1-क्लिक इंस्टेंट स्टूडेंट डेमो लॉगिन',
    orQuickTesting: 'या त्वरित टेस्टिंग के लिए',
    alreadyHaveAccount: 'पहले से आईडी है? लॉग इन करें',
    needAccount: 'नए छात्र हैं? आईडी बनाएं',
    trending: 'ट्रेंडिंग 🔥',
    latest: 'नवीनतम ⏱️',
    myCampus: 'मेरा कॉलेज 🎓',
    saved: 'सेव्ड 🔖',
    allWhispers: 'सभी सीक्रेट्स',
    secrets: 'सीक्रेट्स 🤫',
    love: 'क्रश और प्यार ❤️',
    funny: 'मजेदार 😂',
    stress: 'पढ़ाई का तनाव 📚',
    hottake: 'हॉट टेक्स 🔥',
    campusLife: 'कैंपस लाइफ 🏛️',
    dropSecret: 'सीक्रेट पोस्ट करें',
    dailyThemeTitle: 'कैंपस थीम: फनी फ्राइडे',
    dailyThemeDesc: 'कैंटीन, मेस या क्लास का सबसे मजेदार किस्सा शेयर करें!',
    whisperCTA: 'विस्पर',
    noWhispersFound: 'इस फ़िल्टर में कोई सीक्रेट नहीं मिला।',
    noWhispersSub: 'सबसे पहले आप ही कोई गुमनाम सीक्रेट पोस्ट करें!',
    anonymous: 'गुमनाम छात्र',
    comments: 'टिप्पणियां',
    share: 'शेयर करें',
    report: 'रिपोर्ट करें',
    directWhisper: 'सीधी गुप्त बात',
    writeComment: 'गुमनाम उत्तर लिखें...',
    sendComment: 'भेजें',
    boosted: 'बूस्टेड #1 🚀',
    createWhisperTitle: 'सीक्रेट विस्पर करें',
    createWhisperSub: '100% गुमनाम • जीरो ट्रैकिंग • सुरक्षित',
    confessionPlaceholder: 'कैंटीन, लाइब्रेरी, हॉस्टल या परीक्षा का कोई सीक्रेट लिखें...',
    campusOnlyToggle: 'केवल कॉलेज के लिए',
    campusOnlySub: 'केवल आपके कॉलेज के छात्रों को दिखेगा',
    publishBtn: 'पोस्ट करें 🚀',
    cancel: 'रद्द करें',
    referralTitle: 'कैंपस रेफरल प्रोग्राम',
    referralSubtitle: 'दोस्तों को इनवाइट करें और सिक्के व वीआईपी बैज पाएं!',
    yourDeepLink: 'आपका अनोखा लिंक',
    copyLink: 'लिंक कॉपी करें',
    linkCopied: 'लिंक कॉपी हो गया!',
    whatsappInvite: 'व्हाट्सएप इनवाइट',
    telegramInvite: 'टेलीग्राम चैनल',
    testSimulateInvite: 'टेस्ट इनवाइट (+100 🪙)',
    exclusiveBadges: 'विशेष बैज और माइलस्टोन',
    rewardsShop: 'रिवार्ड्स स्टोर',
    friendsInvited: 'शामिल हुए दोस्त',
    balance: 'बैलेंस',
    myAnonymousId: 'मेरी गुप्त आईडी',
    karma: 'कुल कर्मा',
    secretCoins: 'सीक्रेट सिक्के',
    inviteAndEarn: 'इनवाइट करें और कमाएं 🎁',
    logout: 'लॉग आउट',
    currentCollege: 'वेरीफाइड कॉलेज',
    batchInfo: 'बैच और डिग्री',
    unlockedBadges: 'अनलॉक किए गए बैज',
  }
};
