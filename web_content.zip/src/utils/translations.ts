import { Language } from '../types';

export const translations = {
  // App Branding & Navigation
  appTitle: {
    en: 'Khatavahi',
    gu: 'ખાતાવહી'
  },
  appSubtitle: {
    en: 'Digital Bahi-Khata & Interest Ledger',
    gu: 'ડિજિટલ ચોપડા અને વ્યાજ ખાતાવહી'
  },
  auspiciousHeader: {
    en: '|| Shree Ganeshay Namah || Shubh-Labh ||',
    gu: '|| શ્રી ગણેશાય નમઃ || શુભ-લાભ || શ્રી સવા ||'
  },
  navKhatavahi: {
    en: 'Khatavahi (Daily)',
    gu: 'ખાતાવહી (આવક/ખર્ચ)'
  },
  navVyajKhatu: {
    en: 'Vyaj / Loan Book',
    gu: 'વ્યાજ ખાતું (ધીરેલ/લીધેલ)'
  },
  navAccounts: {
    en: 'Cash & Banks',
    gu: 'રોકડ અને બેંક'
  },
  navBalanceSheet: {
    en: 'Balance Sheet',
    gu: 'સરવૈયું (રિપોર્ટ)'
  },
  navSettings: {
    en: 'Settings & Backup',
    gu: 'સેટિંગ્સ અને બેકઅપ'
  },

  // Security & Lock
  pinLockedTitle: {
    en: 'Khatavahi is Locked',
    gu: 'ખાતાવહી લોક કરેલ છે'
  },
  enterPin: {
    en: 'Enter your 4-digit PIN',
    gu: 'તમારો 4-અંકનો પિન દાખલ કરો'
  },
  unlock: {
    en: 'Unlock',
    gu: 'અનલોક કરો'
  },
  lockNow: {
    en: 'Lock Khatavahi',
    gu: 'હમણાં લોક કરો'
  },
  incorrectPin: {
    en: 'Incorrect PIN. Please try again.',
    gu: 'ખોટો પિન! કૃપા કરીને ફરી પ્રયાસ કરો.'
  },
  forgotPin: {
    en: 'Forgot PIN?',
    gu: 'પિન ભૂલી ગયા?'
  },
  resetWithAnswer: {
    en: 'Reset with Security Question',
    gu: 'સુરક્ષા પ્રશ્નથી પિન બદલો'
  },

  // General Actions
  add: {
    en: 'Add',
    gu: 'ઉમેરો'
  },
  edit: {
    en: 'Edit',
    gu: 'ફેરફાર કરો'
  },
  delete: {
    en: 'Delete',
    gu: 'કાઢી નાખો'
  },
  save: {
    en: 'Save',
    gu: 'સાચવો'
  },
  cancel: {
    en: 'Cancel',
    gu: 'રદ કરો'
  },
  confirm: {
    en: 'Confirm',
    gu: 'ખાતરી કરો'
  },
  search: {
    en: 'Search...',
    gu: 'શોધો...'
  },
  filter: {
    en: 'Filter',
    gu: 'ફિલ્ટર'
  },
  print: {
    en: 'Print Statement',
    gu: 'પ્રિન્ટ પત્રક'
  },
  exportCsv: {
    en: 'Export Excel/CSV',
    gu: 'એક્સેલ/CSV ડાઉનલોડ'
  },
  date: {
    en: 'Date',
    gu: 'તારીખ'
  },
  amount: {
    en: 'Amount (₹)',
    gu: 'રકમ (₹)'
  },
  notes: {
    en: 'Notes / Remarks',
    gu: 'વિગત / નોંધ'
  },
  status: {
    en: 'Status',
    gu: 'સ્થિતિ'
  },
  active: {
    en: 'Active',
    gu: 'ચાલુ'
  },
  settled: {
    en: 'Settled',
    gu: 'ચૂકતે (પૂરું)'
  },
  all: {
    en: 'All',
    gu: 'બધા'
  },

  // Income / Expense
  income: {
    en: 'Income (Jama)',
    gu: 'આવક (જમા)'
  },
  expense: {
    en: 'Expense (Udhar)',
    gu: 'ખર્ચ (ઉધાર)'
  },
  jama: {
    en: 'Jama (Credit)',
    gu: 'જમા'
  },
  udhar: {
    en: 'Udhar (Debit)',
    gu: 'ઉધાર'
  },
  totalIncome: {
    en: 'Total Income',
    gu: 'કુલ આવક (જમા)'
  },
  totalExpense: {
    en: 'Total Expense',
    gu: 'કુલ ખર્ચ (ઉધાર)'
  },
  netSurplus: {
    en: 'Net Savings / Surplus',
    gu: 'ચોખ્ખી બચત / નફો'
  },
  category: {
    en: 'Category',
    gu: 'કેટેગરી'
  },
  allCategories: {
    en: 'All Categories',
    gu: 'તમામ કેટેગરી'
  },
  account: {
    en: 'Account / Wallet',
    gu: 'ખાતું / રોકડ'
  },
  partyName: {
    en: 'Party / Person Name',
    gu: 'નામ / વેપારી / વ્યક્તિ'
  },
  newTransaction: {
    en: 'New Daily Entry',
    gu: 'નવી દૈનિક નોંધણી'
  },

  // Vyaj & Loan
  lentLoans: {
    en: 'Money Lent (Given on Interest)',
    gu: 'ધીરેલ નાણાં (લેણું)'
  },
  borrowedLoans: {
    en: 'Money Borrowed (Taken on Interest)',
    gu: 'લીધેલ નાણાં (દેવું)'
  },
  lentBadge: {
    en: 'Lent (Asset)',
    gu: 'ધીરેલ (લેણું)'
  },
  borrowedBadge: {
    en: 'Borrowed (Liability)',
    gu: 'લીધેલ (દેવું)'
  },
  newLoan: {
    en: 'New Loan / Vyaj Entry',
    gu: 'નવું વ્યાજ/લોન ખાતું'
  },
  principal: {
    en: 'Principal Amount',
    gu: 'મુદ્દલ રકમ'
  },
  initialPrincipal: {
    en: 'Original Principal',
    gu: 'મૂળ મુદ્દલ'
  },
  currentPrincipal: {
    en: 'Current Principal Remaining',
    gu: 'હાલની બાકી મુદ્દલ'
  },
  interestRate: {
    en: 'Interest Rate',
    gu: 'વ્યાજનો દર'
  },
  ratePeriod: {
    en: 'Rate Frequency',
    gu: 'વ્યાજ ગણતરી સમય'
  },
  yearlyRate: {
    en: '% per Year (p.a.)',
    gu: '% વાર્ષિક'
  },
  monthlyRate: {
    en: '% per Month (Taka / સવા-દોઢ-બે ટકા)',
    gu: '% માસિક (ટકા)'
  },
  interestType: {
    en: 'Interest Type',
    gu: 'વ્યાજનો પ્રકાર'
  },
  simpleInterest: {
    en: 'Simple Interest (સાદું વ્યાજ)',
    gu: 'સાદું વ્યાજ'
  },
  compoundInterest: {
    en: 'Compound Interest (ચક્રવૃદ્ધિ વ્યાજ)',
    gu: 'ચક્રવૃદ્ધિ વ્યાજ'
  },
  compoundingFrequency: {
    en: 'Compounding Frequency',
    gu: 'ચક્રવૃદ્ધિનો ગાળો'
  },
  daily: {
    en: 'Daily',
    gu: 'દૈનિક'
  },
  monthly: {
    en: 'Monthly',
    gu: 'માસિક'
  },
  quarterly: {
    en: 'Quarterly',
    gu: 'ત્રિમાસિક'
  },
  yearly: {
    en: 'Yearly (Anniversary)',
    gu: 'વાર્ષિક'
  },
  startDate: {
    en: 'Start Date (Beginning of Year)',
    gu: 'શરૂઆતની તારીખ (વર્ષનો પ્રારંભ)'
  },
  anniversaryNote: {
    en: 'Accrues on 365/366 days leap-year basis starting from this exact day.',
    gu: 'આ તારીખથી વાર્ષિક ચક્ર ગણાશે. લીપ વર્ષમાં 366 દિવસની 100% ચોકસાઈ સાથે વ્યાજ ગણાય છે.'
  },
  accruedInterest: {
    en: 'Accrued Interest',
    gu: 'ચડેલ વ્યાજ'
  },
  totalOutstanding: {
    en: 'Total Outstanding Balance',
    gu: 'કુલ બાકી રકમ (મુદ્દલ + વ્યાજ)'
  },
  recordRepayment: {
    en: 'Record Repayment (જમા રકમ)',
    gu: 'જમા / હપ્તો નોંધો'
  },
  repaymentRule: {
    en: 'Priority: Payment clears interest first, then remaining reduces principal.',
    gu: 'નિયમ: ચૂકવેલ રકમમાંથી પ્રથમ વ્યાજ કપાય છે, વધેલી રકમ મુદ્દલમાંથી બાદ થાય છે.'
  },
  clearedInterestLabel: {
    en: 'Cleared Interest',
    gu: 'કપાયેલ વ્યાજ'
  },
  deductedPrincipalLabel: {
    en: 'Deducted from Principal',
    gu: 'મુદ્દલમાંથી કપાત'
  },
  annualInterestReport: {
    en: 'Annual Interest Report',
    gu: 'વાર્ષિક વ્યાજ અહેવાલ'
  },
  anniversaryYear: {
    en: 'Anniversary Year',
    gu: 'વાર્ષિક વર્ષ'
  },
  openingPrincipal: {
    en: 'Opening Principal',
    gu: 'આરંભિક મુદ્દલ'
  },
  yearInterest: {
    en: 'Interest Accrued',
    gu: 'વાર્ષિક વ્યાજ'
  },
  paymentsReceived: {
    en: 'Repayments Paid',
    gu: 'ચૂકવેલ રકમ'
  },
  closingPrincipal: {
    en: 'Closing Principal',
    gu: 'આખરની મુદ્દલ'
  },
  closingInterest: {
    en: 'Closing Interest',
    gu: 'આખરનું વ્યાજ'
  },
  totalRepaid: {
    en: 'Total Repaid',
    gu: 'કુલ પરત મળેલ/ચૂકવેલ'
  },
  leapYearBadge: {
    en: 'Leap Year (366 Days)',
    gu: 'લીપ વર્ષ (366 દિવસ)'
  },
  regularYearBadge: {
    en: '365 Days',
    gu: '365 દિવસ'
  },
  instantCalculator: {
    en: 'Vyaj Calculator Tool',
    gu: 'વ્યાજ કેલ્ક્યુલેટર સાધન'
  },

  // Accounts
  bankAccounts: {
    en: 'Bank Accounts & Cash Books',
    gu: 'બેંક ખાતાઓ અને રોકડ મેળ'
  },
  addAccount: {
    en: 'Add Account / Bank',
    gu: 'નવું ખાતું ઉમેરો'
  },
  accountName: {
    en: 'Account / Wallet Name',
    gu: 'ખાતાનું નામ (દા.ત. SBI, રોકડ)'
  },
  accountType: {
    en: 'Type',
    gu: 'પ્રકાર'
  },
  cash: {
    en: 'Cash in Hand (રોકડ મેળ)',
    gu: 'હાથ પર રોકડ'
  },
  bank: {
    en: 'Bank Account (બેંક)',
    gu: 'બેંક ખાતું'
  },
  wallet: {
    en: 'Digital Wallet / UPI',
    gu: 'ડિજિટલ વોલેટ'
  },
  initialBalance: {
    en: 'Opening Balance (શરૂઆતની સિલક)',
    gu: 'શરૂઆતની સિલક (₹)'
  },
  currentBalance: {
    en: 'Current Balance',
    gu: 'હાલની સિલક'
  },
  transferFunds: {
    en: 'Transfer Between Accounts',
    gu: 'ખાતાઓ વચ્ચે ફેરબદલ (ટ્રાન્સફર)'
  },
  fromAccount: {
    en: 'From Account',
    gu: 'ક્યા ખાતામાંથી'
  },
  toAccount: {
    en: 'To Account',
    gu: 'ક્યા ખાતામાં'
  },

  // Balance sheet
  balanceSheetTitle: {
    en: 'Comprehensive Khatavahi Balance Sheet',
    gu: 'સંપૂર્ણ ખાતાવહી સરવૈયું (બેલેન્સ શીટ)'
  },
  assets: {
    en: 'Assets (લેણું / સંપત્તિ)',
    gu: 'સંપત્તિ / કુલ લેણું'
  },
  liabilities: {
    en: 'Liabilities (દેવું / જવાબદારી)',
    gu: 'દેવું / કુલ જવાબદારી'
  },
  netWorth: {
    en: 'Net Worth / Capital',
    gu: 'શુદ્ધ મૂડી (ચોખ્ખી સંપત્તિ)'
  },
  cashAndBankTotal: {
    en: 'Cash & Bank Balances',
    gu: 'રોકડ અને બેંક સિલક'
  },
  lentLoansTotal: {
    en: 'Money Lent + Accrued Vyaj',
    gu: 'ધીરેલ રકમ + ચડેલ વ્યાજ'
  },
  borrowedLoansTotal: {
    en: 'Money Borrowed + Accrued Vyaj',
    gu: 'લીધેલ રકમ + ચૂકવવાપાત્ર વ્યાજ'
  },
  incomeExpenseSummary: {
    en: 'Income & Expense Statement',
    gu: 'આવક-ખર્ચ નફા-તોટા પત્રક'
  },

  // Categories & Settings
  categoriesTitle: {
    en: 'Income & Expense Categories',
    gu: 'આવક અને ખર્ચ કેટેગરીઝ'
  },
  addCategory: {
    en: 'Add Category',
    gu: 'નવી કેટેગરી ઉમેરો'
  },
  categoryNameEn: {
    en: 'Category Name (English)',
    gu: 'કેટેગરી નામ (અંગ્રેજી)'
  },
  categoryNameGu: {
    en: 'Category Name (Gujarati)',
    gu: 'કેટેગરી નામ (ગુજરાતી)'
  },
  securitySettings: {
    en: 'Security & PIN Lock',
    gu: 'સુરક્ષા અને પિન લોક'
  },
  enablePin: {
    en: 'Enable 4-digit PIN Protection',
    gu: '4-અંકનું પિન રક્ષણ ચાલુ કરો'
  },
  setPin: {
    en: 'Set New PIN',
    gu: 'નવો પિન સેટ કરો'
  },
  confirmPin: {
    en: 'Confirm PIN',
    gu: 'પિન ખાતરી કરો'
  },
  securityQuestion: {
    en: 'Security Question (for recovery)',
    gu: 'સુરક્ષા પ્રશ્ન (રિકવરી માટે)'
  },
  securityAnswer: {
    en: 'Your Answer',
    gu: 'તમારો જવાબ'
  },
  multiUserTitle: {
    en: 'Multi-User Profiles',
    gu: 'વપરાશકર્તા પ્રોફાઇલ (મલ્ટી-યુઝર)'
  },
  switchUser: {
    en: 'Switch Profile',
    gu: 'પ્રોફાઇલ બદલો'
  },
  addUser: {
    en: 'Create New Profile',
    gu: 'નવી પ્રોફાઇલ બનાવો'
  },
  profileName: {
    en: 'Profile Name (e.g. Personal, Vyapar)',
    gu: 'પ્રોફાઇલ નામ (દા.ત. અંગત, વ્યાપાર, ખેતી)'
  },
  dataBackupTitle: {
    en: 'Offline Data Backup & Restore',
    gu: 'ઓફલાઇન ડેટા બેકઅપ અને પુનઃસ્થાપિત'
  },
  backupDescription: {
    en: '100% offline with zero tracking. Download your entire ledger database anytime.',
    gu: '૧૦૦% ઓફલાઇન અને શૂન્ય ટ્રેકિંગ. તમારા તમામ ખાતાવહી ડેટાનો બેકઅપ સુરક્ષિત ડાઉનલોડ કરો.'
  },
  downloadBackup: {
    en: 'Download Backup File (.json)',
    gu: 'બેકઅપ ડાઉનલોડ કરો (.json)'
  },
  restoreBackup: {
    en: 'Restore from Backup File',
    gu: 'બેકઅપ ફાઇલમાંથી પુનઃસ્થાપિત કરો'
  },
  restoreSuccess: {
    en: 'Data successfully restored!',
    gu: 'ડેટા સફળતાપૂર્વક પુનઃસ્થાપિત થયો!'
  },
  restoreWarning: {
    en: 'Restoring a file will replace current data. Please download a backup first if needed.',
    gu: 'ચેતવણી: બેકઅપ રિસ્ટોર કરવાથી વર્તમાન ડેટા બદલાઈ જશે. પ્રથમ નવો બેકઅપ લઈ લેવો સલાહભર્યું છે.'
  },
  sampleDataLoader: {
    en: 'Load Gujarati Sample Business Ledger',
    gu: 'ગુજરાતી ડેમો ખાતાવહી ડેટા ભરો'
  },
  downloadAppModalTitle: {
    en: 'Download Khatavahi App (APK & EXE)',
    gu: 'ખાતાવહી એપ ડાઉનલોડ (APK અને EXE)'
  },
  downloadApkTitle: {
    en: 'Android Mobile App (.APK)',
    gu: 'એન્ડ્રોઇડ મોબાઇલ એપ (.APK)'
  },
  downloadApkButton: {
    en: 'Download Android APK (v2.0.0)',
    gu: 'એન્ડ્રોઇડ APK ડાઉનલોડ કરો (v2.0.0)'
  },
  downloadExeTitle: {
    en: 'Windows PC Desktop App (.EXE)',
    gu: 'વિન્ડોઝ કોમ્પ્યુટર એપ (.EXE)'
  },
  downloadExeButton: {
    en: 'Download Windows Setup (x64 .exe)',
    gu: 'વિન્ડોઝ સેટઅપ ડાઉનલોડ કરો (.exe)'
  },
  exportMenuTitle: {
    en: 'Export & App Downloads',
    gu: 'એક્સપોર્ટ અને એપ ડાઉનલોડ'
  },
  projectFilesNotice: {
    en: 'APK & EXE installer files generated directly in project files (/downloads/)',
    gu: 'APK અને EXE ફાઇલો પ્રોજેક્ટ ફોલ્ડર (/downloads/) માં તૈયાર છે'
  }
};

export function t(key: keyof typeof translations, lang: Language): string {
  const item = translations[key];
  if (!item) return key;
  return item[lang] || item['en'] || key;
}

/**
 * Format Indian currency with ₹ and Lakhs/Crores commas
 */
export function formatCurrency(amount: number, _lang: Language = 'gu', includeSymbol = true): string {
  if (isNaN(amount) || amount === null || amount === undefined) {
    return includeSymbol ? '₹0' : '0';
  }

  const isNeg = amount < 0;
  const absAmount = Math.abs(amount);

  // Standard Indian formatting
  const formatted = absAmount.toLocaleString('en-IN', {
    maximumFractionDigits: 2,
    minimumFractionDigits: absAmount % 1 !== 0 ? 2 : 0
  });

  const prefix = isNeg ? '-' : '';
  const sym = includeSymbol ? '₹' : '';

  return `${prefix}${sym}${formatted}`;
}

/**
 * Format date nicely in both Gujarati and English
 */
export function formatDateDisplay(dateStr: string, lang: Language = 'gu'): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  if (!year || !month || !day) return dateStr;

  const monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthsGu = [
    'જાન્યુઆરી', 'ફેબ્રુઆરી', 'માર્ચ', 'એપ્રિલ', 'મે', 'જૂન',
    'જુલાઈ', 'ઓગસ્ટ', 'સપ્ટેમ્બર', 'ઓક્ટોબર', 'નવેમ્બર', 'ડિસેમ્બર'
  ];

  const mIndex = parseInt(month, 10) - 1;
  const monthName = lang === 'gu' ? monthsGu[mIndex] || month : monthsEn[mIndex] || month;

  return `${parseInt(day, 10)} ${monthName} ${year}`;
}
