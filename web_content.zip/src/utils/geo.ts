// Geographic coordinates and distance utility for Pakistani cities & neighborhoods

export interface KarachiArea {
  id: string;
  name: string;
  urduName: string;
  zone: string;
  lat: number;
  lng: number;
}

export const KARACHI_AREAS: KarachiArea[] = [
  { id: 'gulshan', name: 'Gulshan-e-Iqbal', urduName: 'گلشنِ اقبال', zone: 'East', lat: 24.9207, lng: 67.0924 },
  { id: 'clifton', name: 'Clifton', urduName: 'کلفٹن', zone: 'South', lat: 24.8138, lng: 67.0299 },
  { id: 'dha', name: 'DHA (Defence)', urduName: 'ڈی ایچ اے', zone: 'South', lat: 24.8016, lng: 67.0674 },
  { id: 'pechs', name: 'PECHS', urduName: 'پی ای سی ایچ ایس', zone: 'East', lat: 24.8693, lng: 67.0664 },
  { id: 'nazimabad', name: 'North Nazimabad', urduName: 'نارتھ ناظم آباد', zone: 'Central', lat: 24.9422, lng: 67.0428 },
  { id: 'jauhar', name: 'Gulistan-e-Jauhar', urduName: 'گلستانِ جوہر', zone: 'East', lat: 24.9180, lng: 67.1352 },
  { id: 'saddar', name: 'Saddar / Cantt', urduName: 'صدر / کینٹ', zone: 'South', lat: 24.8564, lng: 67.0253 },
  { id: 'fbarea', name: 'Federal B Area', urduName: 'فیڈرل بی ایریا', zone: 'Central', lat: 24.9317, lng: 67.0700 },
  { id: 'malir', name: 'Malir Cantt', urduName: 'ملیر کینٹ', zone: 'Malir', lat: 24.9333, lng: 67.1895 },
  { id: 'korangi', name: 'Korangi', urduName: 'کورنگی', zone: 'Korangi', lat: 24.8384, lng: 67.1209 },
  { id: 'bahria', name: 'Bahria Town Karachi', urduName: 'بحریہ ٹاؤن', zone: 'Suburban', lat: 25.0118, lng: 67.3328 },
];

export const OTHER_CITIES = [
  { id: 'karachi', name: 'Karachi', nameUrdu: 'کراچی', active: true },
  { id: 'lahore', name: 'Lahore (Coming soon)', nameUrdu: 'لاہور', active: false },
  { id: 'islamabad', name: 'Islamabad (Coming soon)', nameUrdu: 'اسلام آباد', active: false },
  { id: 'rawalpindi', name: 'Rawalpindi (Coming soon)', nameUrdu: 'راولپنڈی', active: false },
  { id: 'faisalabad', name: 'Faisalabad (Coming soon)', nameUrdu: 'فیصل آباد', active: false },
  { id: 'multan', name: 'Multan (Coming soon)', nameUrdu: 'ملتان', active: false },
  { id: 'peshawar', name: 'Peshawar (Coming soon)', nameUrdu: 'پشاور', active: false },
  { id: 'quetta', name: 'Quetta (Coming soon)', nameUrdu: 'کوئٹہ', active: false },
];

/**
 * Calculates distance between two latitude/longitude points in kilometers using the Haversine formula
 */
export function calculateDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  return Math.round(distance * 10) / 10; // Round to 1 decimal place
}

function toRad(degrees: number): number {
  return (degrees * Math.PI) / 180;
}

export function formatDistance(distanceKm: number): string {
  if (distanceKm < 1) {
    return `${Math.round(distanceKm * 1000)} m`;
  }
  return `${distanceKm.toFixed(1)} km`;
}

export function formatCurrencyPKR(amount: number): string {
  return `Rs. ${amount.toLocaleString('en-PK')}`;
}
