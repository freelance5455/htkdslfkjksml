// Real Google AdMob Configuration & Service Integration for Liquid Color Sort
// Fully integrated with Google Mobile Ads SDK (@capacitor-community/admob & Android Native)

import {
  AdMob,
  BannerAdPosition,
  BannerAdSize,
  BannerAdPluginEvents,
  InterstitialAdPluginEvents,
  RewardAdPluginEvents,
  RewardInterstitialAdPluginEvents,
  AppOpenAdPluginEvents,
  AdMobRewardItem,
  AdMobRewardInterstitialItem,
  AdMobError,
} from '@capacitor-community/admob';
import { Capacitor } from '@capacitor/core';

export type AdType = 'banner' | 'interstitial' | 'rewarded' | 'rewarded_interstitial' | 'app_open' | 'native_advanced';

export type RewardType = 'hint' | 'extraTube' | 'coins' | 'spin' | 'double_level_reward' | 'daily_attempt';

export interface AdRewardInfo {
  type: RewardType;
  amount: number;
  label: string;
}

export const ADMOB_CONFIG = {
  // Real Production Google AdMob App ID
  appId: 'ca-app-pub-5327937366293342~8893862202',

  // Real Production Google AdMob Unit IDs (Actively Loaded in Production)
  appOpenId: 'ca-app-pub-5327937366293342/7316679358',
  bannerId: 'ca-app-pub-5327937366293342/6076127176',
  interstitialId: 'ca-app-pub-5327937366293342/5408701313',
  rewardedInterstitialId: 'ca-app-pub-5327937366293342/2564362778',
  rewardId: 'ca-app-pub-5327937366293342/4839172324',
  nativeAdvancedId: 'ca-app-pub-5327937366293342/9994813581',

  // Google Official Sample / Test Ad Unit IDs (Reference constants only - NOT loaded in production)
  testAppOpenId: 'ca-app-pub-3940256099942544/9257395921',
  testBannerId: 'ca-app-pub-3940256099942544/6300978111',
  testInterstitialId: 'ca-app-pub-3940256099942544/1033173712',
  testRewardedInterstitialId: 'ca-app-pub-3940256099942544/5354046379',
  testRewardId: 'ca-app-pub-3940256099942544/5224354917',
  testNativeAdvancedId: 'ca-app-pub-3940256099942544/2247696110',
};

export interface ActiveAdState {
  isOpen: boolean;
  type: AdType;
  rewardInfo?: AdRewardInfo;
  isLoading?: boolean;
  loadError?: string | null;
  rewardVerified?: boolean;
  onRewarded?: () => void;
  onClosed?: (wasRewarded?: boolean) => void;
  onEarlyClose?: () => void;
}

class AdMobService {
  private isInitialized: boolean = false;
  private isInitInProgress: boolean = false;
  private levelCompletionsCount: number = 0;
  private hasShownAppOpenOnLaunch: boolean = false;
  private adListeners: Array<(state: ActiveAdState | null) => void> = [];
  private currentAdState: ActiveAdState | null = null;

  // Real Preload Status
  private isInterstitialLoaded: boolean = false;
  private isInterstitialLoading: boolean = false;
  private isRewardedLoaded: boolean = false;
  private isRewardedLoading: boolean = false;
  private isRewardedInterstitialLoaded: boolean = false;
  private isRewardedInterstitialLoading: boolean = false;
  private isAppOpenLoaded: boolean = false;
  private isAppOpenLoading: boolean = false;
  private isBannerShowing: boolean = false;

  // Active Reward & Dismiss Callbacks for Real Google Mobile Ads
  private activeRewardedCallback: (() => void) | null = null;
  private activeRewardedClosedCallback: ((wasRewarded: boolean) => void) | null = null;
  private activeRewardedEarned: boolean = false;

  private activeRewardedInterstitialCallback: (() => void) | null = null;
  private activeRewardedInterstitialClosedCallback: ((wasRewarded: boolean) => void) | null = null;
  private activeRewardedInterstitialEarned: boolean = false;

  private activeInterstitialClosedCallback: (() => void) | null = null;
  private activeAppOpenClosedCallback: (() => void) | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      // Hook Android WebView JavascriptInterface events if present
      window.addEventListener('admob:rewardEarned', ((event: CustomEvent) => {
        this.onNativeRewardEarned(event.detail);
      }) as EventListener);

      (window as unknown as Record<string, unknown>).onAdMobRewardEarned = (rewardType: string, amount: number) => {
        this.onNativeRewardEarned({ type: rewardType, amount });
      };

      // Auto-initialize real Google Mobile Ads SDK on native platform
      this.initialize();
    }
  }

  // Initialize real Google Mobile Ads SDK
  public async initialize(): Promise<void> {
    if (this.isInitialized || this.isInitInProgress) return;
    this.isInitInProgress = true;

    try {
      if (Capacitor.isNativePlatform()) {
        await AdMob.initialize({
          initializeForTesting: false,
        });

        this.setupAdListeners();
        this.isInitialized = true;

        // Preload formats for instant availability
        this.preloadAppOpen();
        this.preloadInterstitial();
        this.preloadRewarded();
        this.preloadRewardedInterstitial();
      }
    } catch (err) {
      console.warn('[Google AdMob] Native SDK init check:', err);
    } finally {
      this.isInitInProgress = false;
    }
  }

  private setupAdListeners(): void {
    if (!Capacitor.isNativePlatform()) return;

    // 1. Interstitial Events
    AdMob.addListener(InterstitialAdPluginEvents.Loaded, () => {
      this.isInterstitialLoaded = true;
      this.isInterstitialLoading = false;
    });
    AdMob.addListener(InterstitialAdPluginEvents.FailedToLoad, (error: AdMobError) => {
      this.isInterstitialLoaded = false;
      this.isInterstitialLoading = false;
      console.warn('[Google AdMob] Interstitial failed to load:', error);
    });
    AdMob.addListener(InterstitialAdPluginEvents.Dismissed, () => {
      this.isInterstitialLoaded = false;
      const cb = this.activeInterstitialClosedCallback;
      this.activeInterstitialClosedCallback = null;
      this.currentAdState = null;
      this.notify();
      cb?.();
      this.preloadInterstitial();
    });

    // 2. Rewarded Video Events
    AdMob.addListener(RewardAdPluginEvents.Loaded, () => {
      this.isRewardedLoaded = true;
      this.isRewardedLoading = false;
    });
    AdMob.addListener(RewardAdPluginEvents.FailedToLoad, (error: AdMobError) => {
      this.isRewardedLoaded = false;
      this.isRewardedLoading = false;
      console.warn('[Google AdMob] Rewarded failed to load:', error);
    });
    // Critical: Reward granted ONLY upon verified completion from Google Mobile Ads SDK
    AdMob.addListener(RewardAdPluginEvents.Rewarded, (_item: AdMobRewardItem) => {
      this.activeRewardedEarned = true;
      if (this.activeRewardedCallback) {
        this.activeRewardedCallback();
      }
    });
    AdMob.addListener(RewardAdPluginEvents.Dismissed, () => {
      this.isRewardedLoaded = false;
      const wasRewarded = this.activeRewardedEarned;
      const closedCb = this.activeRewardedClosedCallback;
      this.activeRewardedCallback = null;
      this.activeRewardedClosedCallback = null;
      this.activeRewardedEarned = false;
      this.currentAdState = null;
      this.notify();
      closedCb?.(wasRewarded);
      this.preloadRewarded();
    });

    // 3. Rewarded Interstitial Events
    AdMob.addListener(RewardInterstitialAdPluginEvents.Loaded, () => {
      this.isRewardedInterstitialLoaded = true;
      this.isRewardedInterstitialLoading = false;
    });
    AdMob.addListener(RewardInterstitialAdPluginEvents.FailedToLoad, (error: AdMobError) => {
      this.isRewardedInterstitialLoaded = false;
      this.isRewardedInterstitialLoading = false;
      console.warn('[Google AdMob] Rewarded Interstitial failed to load:', error);
    });
    AdMob.addListener(RewardInterstitialAdPluginEvents.Rewarded, (_item: AdMobRewardInterstitialItem) => {
      this.activeRewardedInterstitialEarned = true;
      if (this.activeRewardedInterstitialCallback) {
        this.activeRewardedInterstitialCallback();
      }
    });
    AdMob.addListener(RewardInterstitialAdPluginEvents.Dismissed, () => {
      this.isRewardedInterstitialLoaded = false;
      const wasRewarded = this.activeRewardedInterstitialEarned;
      const closedCb = this.activeRewardedInterstitialClosedCallback;
      this.activeRewardedInterstitialCallback = null;
      this.activeRewardedInterstitialClosedCallback = null;
      this.activeRewardedInterstitialEarned = false;
      this.currentAdState = null;
      this.notify();
      closedCb?.(wasRewarded);
      this.preloadRewardedInterstitial();
    });

    // 4. App Open Events
    AdMob.addListener(AppOpenAdPluginEvents.Loaded, () => {
      this.isAppOpenLoaded = true;
      this.isAppOpenLoading = false;
    });
    AdMob.addListener(AppOpenAdPluginEvents.FailedToLoad, (error: AdMobError) => {
      this.isAppOpenLoaded = false;
      this.isAppOpenLoading = false;
      console.warn('[Google AdMob] App Open failed to load:', error);
    });
    AdMob.addListener(AppOpenAdPluginEvents.Closed, () => {
      this.isAppOpenLoaded = false;
      const cb = this.activeAppOpenClosedCallback;
      this.activeAppOpenClosedCallback = null;
      this.currentAdState = null;
      this.notify();
      cb?.();
      this.preloadAppOpen();
    });

    // 5. Banner Events
    AdMob.addListener(BannerAdPluginEvents.Loaded, () => {
      this.isBannerShowing = true;
    });
    AdMob.addListener(BannerAdPluginEvents.FailedToLoad, (error: AdMobError) => {
      this.isBannerShowing = false;
      console.warn('[Google AdMob] Banner failed to load:', error);
    });
  }

  // Preload Methods
  public async preloadInterstitial(): Promise<void> {
    if (!Capacitor.isNativePlatform() || this.isInterstitialLoaded || this.isInterstitialLoading) return;
    this.isInterstitialLoading = true;
    try {
      await AdMob.prepareInterstitial({
        adId: ADMOB_CONFIG.interstitialId,
        isTesting: false,
      });
      this.isInterstitialLoaded = true;
    } catch (err) {
      console.warn('[Google AdMob] Prepare interstitial error:', err);
    } finally {
      this.isInterstitialLoading = false;
    }
  }

  public async preloadRewarded(): Promise<void> {
    if (!Capacitor.isNativePlatform() || this.isRewardedLoaded || this.isRewardedLoading) return;
    this.isRewardedLoading = true;
    try {
      await AdMob.prepareRewardVideoAd({
        adId: ADMOB_CONFIG.rewardId,
        isTesting: false,
      });
      this.isRewardedLoaded = true;
    } catch (err) {
      console.warn('[Google AdMob] Prepare rewarded video error:', err);
    } finally {
      this.isRewardedLoading = false;
    }
  }

  public async preloadRewardedInterstitial(): Promise<void> {
    if (!Capacitor.isNativePlatform() || this.isRewardedInterstitialLoaded || this.isRewardedInterstitialLoading) return;
    this.isRewardedInterstitialLoading = true;
    try {
      await AdMob.prepareRewardInterstitialAd({
        adId: ADMOB_CONFIG.rewardedInterstitialId,
        isTesting: false,
      });
      this.isRewardedInterstitialLoaded = true;
    } catch (err) {
      console.warn('[Google AdMob] Prepare rewarded interstitial error:', err);
    } finally {
      this.isRewardedInterstitialLoading = false;
    }
  }

  public async preloadAppOpen(): Promise<void> {
    if (!Capacitor.isNativePlatform() || this.isAppOpenLoaded || this.isAppOpenLoading) return;
    this.isAppOpenLoading = true;
    try {
      await AdMob.loadAppOpen({
        adId: ADMOB_CONFIG.appOpenId,
      });
      this.isAppOpenLoaded = true;
    } catch (err) {
      console.warn('[Google AdMob] Load App Open error:', err);
    } finally {
      this.isAppOpenLoading = false;
    }
  }

  private onNativeRewardEarned(detail: { type?: string; amount?: number } | undefined) {
    if (this.activeRewardedCallback) {
      this.activeRewardedEarned = true;
      this.activeRewardedCallback();
      this.activeRewardedCallback = null;
    }
    if (this.activeRewardedInterstitialCallback) {
      this.activeRewardedInterstitialEarned = true;
      this.activeRewardedInterstitialCallback();
      this.activeRewardedInterstitialCallback = null;
    }
    if (this.currentAdState && (this.currentAdState.type === 'rewarded' || this.currentAdState.type === 'rewarded_interstitial')) {
      this.currentAdState.rewardVerified = true;
      this.currentAdState.onRewarded?.();
      this.closeCurrentAd(true);
    }
  }

  public isOnline(): boolean {
    if (typeof navigator !== 'undefined' && typeof navigator.onLine === 'boolean') {
      return navigator.onLine;
    }
    return true;
  }

  public getAdUnitId(type: AdType): string {
    switch (type) {
      case 'banner':
        return ADMOB_CONFIG.bannerId;
      case 'interstitial':
        return ADMOB_CONFIG.interstitialId;
      case 'rewarded':
        return ADMOB_CONFIG.rewardId;
      case 'rewarded_interstitial':
        return ADMOB_CONFIG.rewardedInterstitialId;
      case 'app_open':
        return ADMOB_CONFIG.appOpenId;
      case 'native_advanced':
        return ADMOB_CONFIG.nativeAdvancedId;
    }
  }

  public isTestMode(): boolean {
    return false;
  }

  public setTestMode(_enabled: boolean): void {
    // Production IDs are strictly maintained
  }

  public subscribe(listener: (state: ActiveAdState | null) => void): () => void {
    this.adListeners.push(listener);
    listener(this.currentAdState);
    return () => {
      this.adListeners = this.adListeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.adListeners.forEach((l) => l(this.currentAdState));
  }

  // 1. APP OPEN AD: Shows real Google Mobile Ads App Open ad
  public showAppOpenAd(onClosed?: () => void): boolean {
    if (!this.isOnline()) {
      onClosed?.();
      return false;
    }

    this.hasShownAppOpenOnLaunch = true;

    // A. Native Capacitor Platform
    if (Capacitor.isNativePlatform()) {
      this.activeAppOpenClosedCallback = onClosed || null;
      (async () => {
        try {
          if (!this.isAppOpenLoaded) {
            await AdMob.loadAppOpen({ adId: ADMOB_CONFIG.appOpenId });
            this.isAppOpenLoaded = true;
          }
          await AdMob.showAppOpen();
        } catch (err) {
          console.warn('[Google AdMob] Show App Open error:', err);
          const cb = this.activeAppOpenClosedCallback;
          this.activeAppOpenClosedCallback = null;
          cb?.();
        }
      })();
      return true;
    }

    // B. Android WebView JavascriptInterface bridge
    const win = typeof window !== 'undefined' ? (window as unknown as Record<string, unknown>) : {};
    if (win.AndroidAdMob && typeof (win.AndroidAdMob as Record<string, unknown>).showAppOpenAd === 'function') {
      try {
        ((win.AndroidAdMob as Record<string, unknown>).showAppOpenAd as (id: string) => void)(ADMOB_CONFIG.appOpenId);
        onClosed?.();
        return true;
      } catch (err) {
        console.warn('[Google AdMob] Android bridge App Open error:', err);
      }
    }

    // C. Web Preview fallback (safely proceed without fake ad screen)
    onClosed?.();
    return false;
  }

  public shouldShowAppOpenOnLaunch(): boolean {
    return !this.hasShownAppOpenOnLaunch;
  }

  // 2. INTERSTITIAL AD: Shows real Google Mobile Ads Interstitial ad
  public onLevelCompleted(): void {
    this.levelCompletionsCount++;
  }

  public shouldShowLevelTransitionInterstitial(): boolean {
    return this.levelCompletionsCount > 0 && this.levelCompletionsCount % 2 === 0;
  }

  public showInterstitialAd(onClosed?: () => void): boolean {
    if (!this.isOnline()) {
      onClosed?.();
      return false;
    }

    // A. Native Capacitor Platform
    if (Capacitor.isNativePlatform()) {
      this.activeInterstitialClosedCallback = onClosed || null;
      (async () => {
        try {
          if (!this.isInterstitialLoaded) {
            await AdMob.prepareInterstitial({
              adId: ADMOB_CONFIG.interstitialId,
              isTesting: false,
            });
            this.isInterstitialLoaded = true;
          }
          await AdMob.showInterstitial();
        } catch (err) {
          console.warn('[Google AdMob] Show Interstitial error:', err);
          const cb = this.activeInterstitialClosedCallback;
          this.activeInterstitialClosedCallback = null;
          cb?.();
          this.preloadInterstitial();
        }
      })();
      return true;
    }

    // B. Android WebView JavascriptInterface bridge
    const win = typeof window !== 'undefined' ? (window as unknown as Record<string, unknown>) : {};
    if (win.AndroidAdMob && typeof (win.AndroidAdMob as Record<string, unknown>).showInterstitial === 'function') {
      try {
        ((win.AndroidAdMob as Record<string, unknown>).showInterstitial as (id: string) => void)(ADMOB_CONFIG.interstitialId);
        onClosed?.();
        return true;
      } catch (err) {
        console.warn('[Google AdMob] Android bridge Interstitial error:', err);
      }
    }

    // C. Web Preview fallback: Safely proceed to next level without blocking
    onClosed?.();
    return false;
  }

  // 3. REWARDED AD: Uses real Google Mobile Ads Rewarded Ad
  // Reward is granted ONLY upon real SDK reward callback
  public showRewardedAd(
    reward: AdRewardInfo,
    onRewarded: () => void,
    onClosed?: (wasRewarded?: boolean) => void,
    onEarlyClose?: () => void,
    onLoadError?: (err: string) => void
  ): boolean {
    if (!this.isOnline()) {
      onLoadError?.('No internet connection. Google AdMob rewarded ad could not be loaded.');
      onClosed?.(false);
      return false;
    }

    // A. Native Capacitor Platform
    if (Capacitor.isNativePlatform()) {
      this.activeRewardedEarned = false;
      this.activeRewardedCallback = onRewarded;
      this.activeRewardedClosedCallback = (wasRewarded) => {
        if (!wasRewarded) {
          onEarlyClose?.();
        }
        onClosed?.(wasRewarded);
      };

      (async () => {
        try {
          if (!this.isRewardedLoaded) {
            await AdMob.prepareRewardVideoAd({
              adId: ADMOB_CONFIG.rewardId,
              isTesting: false,
            });
            this.isRewardedLoaded = true;
          }
          const result = await AdMob.showRewardVideoAd();
          if (result && !this.activeRewardedEarned) {
            this.activeRewardedEarned = true;
            onRewarded();
          }
        } catch (err) {
          console.warn('[Google AdMob] Show Rewarded error:', err);
          onLoadError?.('Failed to load Google AdMob Rewarded Ad. Please try again.');
          const cb = this.activeRewardedClosedCallback;
          this.activeRewardedCallback = null;
          this.activeRewardedClosedCallback = null;
          cb?.(false);
          this.preloadRewarded();
        }
      })();
      return true;
    }

    // B. Android WebView JavascriptInterface bridge
    const win = typeof window !== 'undefined' ? (window as unknown as Record<string, unknown>) : {};
    if (win.AndroidAdMob && typeof (win.AndroidAdMob as Record<string, unknown>).showRewardedAd === 'function') {
      try {
        this.activeRewardedCallback = onRewarded;
        this.activeRewardedClosedCallback = onClosed || null;
        ((win.AndroidAdMob as Record<string, unknown>).showRewardedAd as (id: string, type: string) => void)(
          ADMOB_CONFIG.rewardId,
          reward.type
        );
        return true;
      } catch (err) {
        onLoadError?.('AdMob native ad display error: ' + String(err));
        onClosed?.(false);
        return false;
      }
    }

    // C. Web Preview fallback: Reward is strictly not granted without real ad completion
    onLoadError?.('Google AdMob Rewarded Ads are available on Android devices.');
    onClosed?.(false);
    return false;
  }

  // 4. REWARDED INTERSTITIAL AD: Uses real Google Mobile Ads Rewarded Interstitial format
  public showRewardedInterstitialAd(
    reward: AdRewardInfo,
    onRewarded: () => void,
    onClosed?: (wasRewarded?: boolean) => void,
    onEarlyClose?: () => void,
    onLoadError?: (err: string) => void
  ): boolean {
    if (!this.isOnline()) {
      onLoadError?.('No internet connection. Google AdMob rewarded interstitial could not be loaded.');
      onClosed?.(false);
      return false;
    }

    // A. Native Capacitor Platform
    if (Capacitor.isNativePlatform()) {
      this.activeRewardedInterstitialEarned = false;
      this.activeRewardedInterstitialCallback = onRewarded;
      this.activeRewardedInterstitialClosedCallback = (wasRewarded) => {
        if (!wasRewarded) {
          onEarlyClose?.();
        }
        onClosed?.(wasRewarded);
      };

      (async () => {
        try {
          if (!this.isRewardedInterstitialLoaded) {
            await AdMob.prepareRewardInterstitialAd({
              adId: ADMOB_CONFIG.rewardedInterstitialId,
              isTesting: false,
            });
            this.isRewardedInterstitialLoaded = true;
          }
          const result = await AdMob.showRewardInterstitialAd();
          if (result && !this.activeRewardedInterstitialEarned) {
            this.activeRewardedInterstitialEarned = true;
            onRewarded();
          }
        } catch (err) {
          console.warn('[Google AdMob] Show Rewarded Interstitial error:', err);
          onLoadError?.('Failed to load Google AdMob Rewarded Interstitial. Please try again.');
          const cb = this.activeRewardedInterstitialClosedCallback;
          this.activeRewardedInterstitialCallback = null;
          this.activeRewardedInterstitialClosedCallback = null;
          cb?.(false);
          this.preloadRewardedInterstitial();
        }
      })();
      return true;
    }

    // B. Android WebView JavascriptInterface bridge
    const win = typeof window !== 'undefined' ? (window as unknown as Record<string, unknown>) : {};
    if (win.AndroidAdMob && typeof (win.AndroidAdMob as Record<string, unknown>).showRewardedInterstitial === 'function') {
      try {
        this.activeRewardedInterstitialCallback = onRewarded;
        this.activeRewardedInterstitialClosedCallback = onClosed || null;
        ((win.AndroidAdMob as Record<string, unknown>).showRewardedInterstitial as (id: string, type: string) => void)(
          ADMOB_CONFIG.rewardedInterstitialId,
          reward.type
        );
        return true;
      } catch (err) {
        onLoadError?.('AdMob native ad display error: ' + String(err));
        onClosed?.(false);
        return false;
      }
    }

    // C. Web Preview fallback
    onLoadError?.('Google AdMob Rewarded Ads are available on Android devices.');
    onClosed?.(false);
    return false;
  }

  // 5. BANNER AD: Real Google Mobile Ads Banner
  public async showBanner(): Promise<void> {
    if (!this.isOnline()) return;

    if (Capacitor.isNativePlatform()) {
      try {
        await AdMob.showBanner({
          adId: ADMOB_CONFIG.bannerId,
          adSize: BannerAdSize.BANNER,
          position: BannerAdPosition.BOTTOM_CENTER,
          margin: 0,
          isTesting: false,
        });
        this.isBannerShowing = true;
      } catch (err) {
        console.warn('[Google AdMob] Show banner error:', err);
      }
      return;
    }

    const win = typeof window !== 'undefined' ? (window as unknown as Record<string, unknown>) : {};
    if (win.AndroidAdMob && typeof (win.AndroidAdMob as Record<string, unknown>).showBanner === 'function') {
      try {
        ((win.AndroidAdMob as Record<string, unknown>).showBanner as (id: string) => void)(ADMOB_CONFIG.bannerId);
        this.isBannerShowing = true;
      } catch (err) {
        console.warn('[Google AdMob] Android bridge banner error:', err);
      }
    }
  }

  public async hideBanner(): Promise<void> {
    if (Capacitor.isNativePlatform()) {
      try {
        await AdMob.hideBanner();
        this.isBannerShowing = false;
      } catch (err) {
        console.warn('[Google AdMob] Hide banner error:', err);
      }
    }
  }

  public async resumeBanner(): Promise<void> {
    if (Capacitor.isNativePlatform()) {
      try {
        await AdMob.resumeBanner();
        this.isBannerShowing = true;
      } catch (err) {
        console.warn('[Google AdMob] Resume banner error:', err);
      }
    }
  }

  public async removeBanner(): Promise<void> {
    if (Capacitor.isNativePlatform()) {
      try {
        await AdMob.removeBanner();
        this.isBannerShowing = false;
      } catch (err) {
        console.warn('[Google AdMob] Remove banner error:', err);
      }
    }
  }

  public isBannerVisible(): boolean {
    return this.isBannerShowing;
  }

  // Backward compatibility stubs for UI state synchronization
  public markAdLoaded(): void {
    if (this.currentAdState) {
      this.currentAdState.isLoading = false;
      this.notify();
    }
  }

  public markAdLoadFailed(error: string): void {
    if (this.currentAdState) {
      this.currentAdState.isLoading = false;
      this.currentAdState.loadError = error;
      this.notify();
    }
  }

  public confirmAdMobReward(): boolean {
    return false;
  }

  public closeCurrentAd(wasRewarded: boolean = false): void {
    if (this.currentAdState) {
      const closedCb = this.currentAdState.onClosed;
      this.currentAdState = null;
      this.notify();
      closedCb?.(wasRewarded);
    }
  }

  public earlyCloseCurrentAd(): void {
    if (this.currentAdState) {
      const earlyCb = this.currentAdState.onEarlyClose;
      const closedCb = this.currentAdState.onClosed;
      this.currentAdState = null;
      this.notify();
      if (earlyCb) {
        earlyCb();
      } else {
        closedCb?.(false);
      }
    }
  }
}

export const admob = new AdMobService();
