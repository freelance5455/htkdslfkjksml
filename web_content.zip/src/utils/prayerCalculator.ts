import { PrayerSettings, PrayerTimeInfo } from '../types';

export interface CityPreset {
  nameAr: string;
  nameEn: string;
  countryAr: string;
  lat: number;
  lng: number;
  defaultMethod: PrayerSettings['method'];
}

export const POPULAR_CITIES: CityPreset[] = [
  { nameAr: 'القاهرة', nameEn: 'Cairo', countryAr: 'مصر', lat: 30.0444, lng: 31.2357, defaultMethod: 'Egypt' },
  { nameAr: 'الإسكندرية', nameEn: 'Alexandria', countryAr: 'مصر', lat: 31.2001, lng: 29.9187, defaultMethod: 'Egypt' },
  { nameAr: 'المنصورة', nameEn: 'Mansoura', countryAr: 'مصر', lat: 31.0409, lng: 31.3785, defaultMethod: 'Egypt' },
  { nameAr: 'أسيوط', nameEn: 'Assiut', countryAr: 'مصر', lat: 27.1809, lng: 31.1837, defaultMethod: 'Egypt' },
  { nameAr: 'مكة المكرمة', nameEn: 'Makkah', countryAr: 'السعودية', lat: 21.4225, lng: 39.8262, defaultMethod: 'Makkah' },
  { nameAr: 'المدينة المنورة', nameEn: 'Madinah', countryAr: 'السعودية', lat: 24.5247, lng: 39.5692, defaultMethod: 'Makkah' },
  { nameAr: 'الرياض', nameEn: 'Riyadh', countryAr: 'السعودية', lat: 24.7136, lng: 46.6753, defaultMethod: 'Makkah' },
  { nameAr: 'جدة', nameEn: 'Jeddah', countryAr: 'السعودية', lat: 21.5433, lng: 39.1728, defaultMethod: 'Makkah' },
  { nameAr: 'الدمام', nameEn: 'Dammam', countryAr: 'السعودية', lat: 26.4207, lng: 50.0888, defaultMethod: 'Makkah' },
  { nameAr: 'دبي', nameEn: 'Dubai', countryAr: 'الإمارات', lat: 25.2048, lng: 55.2708, defaultMethod: 'MWL' },
  { nameAr: 'أبوظبي', nameEn: 'Abu Dhabi', countryAr: 'الإمارات', lat: 24.4539, lng: 54.3773, defaultMethod: 'MWL' },
  { nameAr: 'الدوحة', nameEn: 'Doha', countryAr: 'قطر', lat: 25.2854, lng: 51.5310, defaultMethod: 'MWL' },
  { nameAr: 'الكويت', nameEn: 'Kuwait City', countryAr: 'الكويت', lat: 29.3759, lng: 47.9774, defaultMethod: 'Makkah' },
  { nameAr: 'المنامة', nameEn: 'Manama', countryAr: 'البحرين', lat: 26.2285, lng: 50.5860, defaultMethod: 'MWL' },
  { nameAr: 'مسقط', nameEn: 'Muscat', countryAr: 'عُمان', lat: 23.5880, lng: 58.3829, defaultMethod: 'MWL' },
  { nameAr: 'عمان', nameEn: 'Amman', countryAr: 'الأردن', lat: 31.9454, lng: 35.9284, defaultMethod: 'MWL' },
  { nameAr: 'القدس', nameEn: 'Jerusalem', countryAr: 'فلسطين', lat: 31.7683, lng: 35.2137, defaultMethod: 'MWL' },
  { nameAr: 'بغداد', nameEn: 'Baghdad', countryAr: 'العراق', lat: 33.3152, lng: 44.3661, defaultMethod: 'MWL' },
  { nameAr: 'دمشق', nameEn: 'Damascus', countryAr: 'سوريا', lat: 33.5138, lng: 36.2765, defaultMethod: 'MWL' },
  { nameAr: 'بيروت', nameEn: 'Beirut', countryAr: 'لبنان', lat: 33.8938, lng: 35.5018, defaultMethod: 'MWL' },
  { nameAr: 'طرابلس', nameEn: 'Tripoli', countryAr: 'ليبيا', lat: 32.8872, lng: 13.1913, defaultMethod: 'MWL' },
  { nameAr: 'تونس', nameEn: 'Tunis', countryAr: 'تونس', lat: 36.8065, lng: 10.1815, defaultMethod: 'MWL' },
  { nameAr: 'الجزائر', nameEn: 'Algiers', countryAr: 'الجزائر', lat: 36.7538, lng: 3.0588, defaultMethod: 'MWL' },
  { nameAr: 'الرباط', nameEn: 'Rabat', countryAr: 'المغرب', lat: 34.0209, lng: -6.8416, defaultMethod: 'MWL' },
  { nameAr: 'الخرطوم', nameEn: 'Khartoum', countryAr: 'السودان', lat: 15.5007, lng: 32.5599, defaultMethod: 'Egypt' },
  { nameAr: 'إسطنبول', nameEn: 'Istanbul', countryAr: 'تركيا', lat: 41.0082, lng: 28.9784, defaultMethod: 'MWL' },
];

export const CALCULATION_METHOD_NAMES: Record<PrayerSettings['method'], string> = {
  Egypt: 'الهيئة المصرية العامة للمساحة',
  Makkah: 'جامعة أم القرى - مكة المكرمة',
  MWL: 'رابطة العالم الإسلامي',
  Karachi: 'جامعة العلوم الإسلامية بكراتشي',
  ISNA: 'الاتحاد الإسلامي لأمريكا الشمالية',
};

// Math helpers for solar astronomy
const d2r = (deg: number) => (deg * Math.PI) / 180.0;
const r2d = (rad: number) => (rad * 180.0) / Math.PI;

function getJulianDay(date: Date): number {
  const year = date.getFullYear();
  let month = date.getMonth() + 1;
  const day = date.getDate();

  let y = year;
  let m = month;
  if (month <= 2) {
    y -= 1;
    m += 12;
  }
  const a = Math.floor(y / 100);
  const b = 2 - a + Math.floor(a / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + b - 1524.5;
}

interface SolarPosition {
  declination: number; // in radians
  equationOfTime: number; // in hours
}

function getSolarPosition(jd: number): SolarPosition {
  const d = jd - 2451545.0;
  const g = 357.529 + 0.98560028 * d;
  const q = 280.459 + 0.98564736 * d;
  const l = q + 1.915 * Math.sin(d2r(g)) + 0.02 * Math.sin(d2r(2 * g));

  const e = 23.439 - 0.00000036 * d;
  const ra = r2d(Math.atan2(Math.cos(d2r(e)) * Math.sin(d2r(l)), Math.cos(d2r(l)))) / 15.0;

  const declination = Math.asin(Math.sin(d2r(e)) * Math.sin(d2r(l)));
  const equationOfTime = q / 15.0 - (ra < 0 ? ra + 24 : ra);

  return { declination, equationOfTime };
}

// Compute sun angle time offset in hours
function getHourAngleForElevation(latRad: number, decRad: number, angleDeg: number): number | null {
  const sinAlpha = Math.sin(d2r(angleDeg));
  const cosH = (sinAlpha - Math.sin(latRad) * Math.sin(decRad)) / (Math.cos(latRad) * Math.cos(decRad));
  if (cosH > 1.0 || cosH < -1.0) return null; // Extreme latitudes
  return r2d(Math.acos(cosH)) / 15.0;
}

// Asr angle
function getAsrHourAngle(latRad: number, decRad: number, shadowFactor: number): number {
  const cotA = shadowFactor + Math.tan(Math.abs(latRad - decRad));
  const elevationDeg = r2d(Math.atan(1.0 / cotA));
  const sinAlpha = Math.sin(d2r(elevationDeg));
  const cosH = (sinAlpha - Math.sin(latRad) * Math.sin(decRad)) / (Math.cos(latRad) * Math.cos(decRad));
  const clampedCosH = Math.max(-1, Math.min(1, cosH));
  return r2d(Math.acos(clampedCosH)) / 15.0;
}

export function formatTime24to12(timeStr: string): string {
  if (!timeStr) return '';
  const [hourStr, minStr] = timeStr.split(':');
  let h = parseInt(hourStr, 10);
  const m = minStr.padStart(2, '0');
  const period = h >= 12 ? 'م' : 'ص';
  h = h % 12;
  if (h === 0) h = 12;
  return `${h}:${m} ${period}`;
}

export function calculatePrayerTimes(
  date: Date,
  settings: PrayerSettings,
  completedPrayerIds: string[] = []
): PrayerTimeInfo[] {
  const jd = getJulianDay(date);
  const timezoneOffsetHours = -date.getTimezoneOffset() / 60; // local timezone hours offset
  const { declination, equationOfTime } = getSolarPosition(jd);

  const latRad = d2r(settings.lat);

  // Solar noon in local hours
  const solarNoon = 12 + timezoneOffsetHours - settings.lng / 15.0 - equationOfTime;

  // Method parameters
  let fajrAngle = 19.5;
  let ishaAngle = 17.5;
  let ishaFixedMinutesAfterMaghrib: number | null = null;

  switch (settings.method) {
    case 'Egypt':
      fajrAngle = 19.5;
      ishaAngle = 17.5;
      break;
    case 'Makkah':
      fajrAngle = 18.5;
      ishaFixedMinutesAfterMaghrib = 90;
      break;
    case 'MWL':
      fajrAngle = 18.0;
      ishaAngle = 17.0;
      break;
    case 'Karachi':
      fajrAngle = 18.0;
      ishaAngle = 18.0;
      break;
    case 'ISNA':
      fajrAngle = 15.0;
      ishaAngle = 15.0;
      break;
  }

  // Sunrise & Sunset angle is -0.833°
  const sunriseOffset = getHourAngleForElevation(latRad, declination, -0.833) || 6.0;
  const fajrOffset = getHourAngleForElevation(latRad, declination, -fajrAngle) || 7.0;

  const shadowFactor = settings.asrJuristic === 'Hanafi' ? 2 : 1;
  const asrOffset = getAsrHourAngle(latRad, declination, shadowFactor);

  const fajrHours = solarNoon - fajrOffset;
  const sunriseHours = solarNoon - sunriseOffset;
  const dhuhrHours = solarNoon + 0.02; // Small 1-2 min buffer past zenith
  const asrHours = solarNoon + asrOffset;
  const maghribHours = solarNoon + sunriseOffset;

  let ishaHours: number;
  if (ishaFixedMinutesAfterMaghrib !== null) {
    ishaHours = maghribHours + ishaFixedMinutesAfterMaghrib / 60.0;
  } else {
    const ishaOffset = getHourAngleForElevation(latRad, declination, -ishaAngle) || 7.0;
    ishaHours = solarNoon + ishaOffset;
  }

  function hoursToHHMM(h: number): string {
    let normalized = h % 24;
    if (normalized < 0) normalized += 24;
    const hours = Math.floor(normalized);
    const minutes = Math.round((normalized - hours) * 60);
    const finalHours = minutes === 60 ? (hours + 1) % 24 : hours;
    const finalMinutes = minutes === 60 ? 0 : minutes;
    return `${String(finalHours).padStart(2, '0')}:${String(finalMinutes).padStart(2, '0')}`;
  }

  const rawPrayers = [
    { id: 'fajr', nameAr: 'الفجر', nameEn: 'Fajr', hours: fajrHours },
    { id: 'sunrise', nameAr: 'الشروق', nameEn: 'Sunrise', hours: sunriseHours },
    { id: 'dhuhr', nameAr: 'الظهر', nameEn: 'Dhuhr', hours: dhuhrHours },
    { id: 'asr', nameAr: 'العصر', nameEn: 'Asr', hours: asrHours },
    { id: 'maghrib', nameAr: 'المغرب', nameEn: 'Maghrib', hours: maghribHours },
    { id: 'isha', nameAr: 'العشاء', nameEn: 'Isha', hours: ishaHours },
  ];

  const now = new Date();
  const dateStr = date.toISOString().split('T')[0];
  const isToday = now.toISOString().split('T')[0] === dateStr;
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  let nextPrayerAssigned = false;

  return rawPrayers.map((p) => {
    const time = hoursToHHMM(p.hours);
    const [h, m] = time.split(':').map(Number);
    const prayerMinutes = h * 60 + m;

    let isPassed = false;
    let isNext = false;

    if (isToday) {
      if (currentMinutes >= prayerMinutes) {
        isPassed = true;
      } else if (!nextPrayerAssigned && p.id !== 'sunrise') {
        isNext = true;
        nextPrayerAssigned = true;
      }
    }

    return {
      id: p.id,
      nameAr: p.nameAr,
      nameEn: p.nameEn,
      time,
      formattedTime: formatTime24to12(time),
      dateStr,
      isPassed,
      isNext,
      isCompleted: completedPrayerIds.includes(p.id),
    };
  });
}

// Format countdown helper
export function getTimeUntilNextPrayer(prayer: PrayerTimeInfo): { hours: number; minutes: number; seconds: number; totalSeconds: number } {
  const [h, m] = prayer.time.split(':').map(Number);
  const now = new Date();
  const target = new Date();
  target.setHours(h, m, 0, 0);

  if (target.getTime() <= now.getTime()) {
    // Tomorrow's Fajr
    target.setDate(target.getDate() + 1);
  }

  const diffMs = Math.max(0, target.getTime() - now.getTime());
  const totalSeconds = Math.floor(diffMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return { hours, minutes, seconds, totalSeconds };
}
